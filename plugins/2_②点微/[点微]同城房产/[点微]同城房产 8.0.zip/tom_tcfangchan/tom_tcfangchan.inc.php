<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = '20210825';
$fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
if (!$fangchanSetting || $fangchanSetting['id'] <= 0) {
	$insertData = array();
	$insertData['id'] = 1;
	C::t('#tom_tcfangchan#tom_tcfangchan_setting')->insert($insertData);
	$fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
}
if (!file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/tom_tongcheng.inc.php')) {
	echo ' no install https://dism.taobao.com/?@tom_tongcheng.plugin';
	exit(0);
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/class/function.core.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcfangchanConfig['wx_share_title'];
$shareDesc = $tcfangchanConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=index');
$shareLogo = $tcfangchanConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
$tcadminConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcadmin/tom_tcadmin.inc.php')) {
	$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
$__ShowXiaofenlei = 0;
$xiaofenleiConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_xiaofenlei/tom_xiaofenlei.inc.php')) {
	$xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
	$__ShowXiaofenlei = 1;
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$__ShowVideo = 0;
if ($fangchanSetting['open_video'] == 1) {
	if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/video.inc.php')) {
		$__ShowVideo = 1;
	}
}
$__ShowTcsign = 0;
$tcsignConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcsign/tom_tcsign.inc.php')) {
	$tcsignConfig = $_G['cache']['plugin']['tom_tcsign'];
	if ($tcsignConfig['open_tcsign'] == 1) {
		$__ShowTcsign = 1;
	}
}
$__ShowFcpc = 0;
$fcpcConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_fcpc/tom_fcpc.inc.php')) {
	$fcpcConfig = $_G['cache']['plugin']['tom_fcpc'];
	if ($fcpcConfig['open_fcpc'] == 1) {
		$__ShowFcpc = 1;
	}
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/config/config.data.php';
$__TjHehuorenId = 0;
if ($__UserInfo['id'] > 0) {
	if ($__ShowTchehuoren == 1) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$__TjHehuorenId = $tchehuorenInfoTmp['id'];
			$shareUrl = $shareUrl . ('&tjid=' . $__TjHehuorenId);
		}
	}
}
$footer_nav_content_name = $footer_nav_content_link = $footer_nav_content_ico = '';
if ($tcfangchanConfig['footer_nav_mod'] == 1) {
	if (!empty($tcfangchanConfig['footer_nav_content'])) {
		$footer_nav_content = explode('|', $tcfangchanConfig['footer_nav_content']);
		$footer_nav_content_name = $footer_nav_content[0];
		$footer_nav_content_link = $footer_nav_content[1];
		$footer_nav_content_link = str_replace('{site}', $site_id, $footer_nav_content_link);
		if (isset($footer_nav_content[2]) && !empty($footer_nav_content[2])) {
			$footer_nav_content_ico = $footer_nav_content[2];
		}
	}
}
$__CommonInfo = C::t('#tom_tcfangchan#tom_tcfangchan_common')->fetch_by_site_id($site_id);
if (!$__CommonInfo) {
	$insertData = array();
	$insertData['site_id'] = $site_id;
	C::t('#tom_tcfangchan#tom_tcfangchan_common')->insert($insertData);
}
$loginUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=personal';
$searchUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=get_search_url';
$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
$ajaxUpdateCommonClicksUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_common_clicks&formhash=' . $formhash;
$ajaxUpdateTopExpireStatusUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_top_expire_status&formhash=' . $formhash;
$ajaxUpdateOverExpireStatus3Url = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_over_expire_status3&formhash=' . $formhash;
$ajaxUpdateNewhousesTopStatusUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_newhouses_top_status&formhash=' . $formhash;
$ajaxUpdateMendianExpireStatusUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_mendian_expire_status&formhash=' . $formhash;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
$ajaxUpdateNeedsTopExpireStatusUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_needs_top_expire_status&formhash=' . $formhash;
if ($_GET['mod'] == 'index') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/site_ibs.php';
	$focuspicListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' AND type = 1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_focuspic')->fetch_all_list(' AND site_id=1 AND type = 1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	if (is_array($focuspicListTmp) && !empty($focuspicListTmp)) {
		foreach ($focuspicListTmp as $key => $value) {
			$focuspicList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$focuspicList[$key]['picurl'] = $picurl;
		}
	}
	$commonClicks = C::t('#tom_tcfangchan#tom_tcfangchan_common')->fetch_all_sun_clicks(' AND site_id IN(' . $sql_in_site_ids . ') ');
	$clicksNum = $commonClicks + $tcfangchanConfig['virtual_clicks'];
	$clicksNumTxt = $clicksNum;
	if ($clicksNum > 10000) {
		$clicksNumTmp = $clicksNum / 10000;
		$clicksNumTxt = number_format($clicksNumTmp, 2, '.', '');
	}
	$fangchanNum = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count(' AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) AND site_id IN(' . $sql_in_site_ids . ') ');
	$fangchanNum = $fangchanNum + $tcfangchanConfig['virtual_fangchan_num'];
	$fangchanNumTxt = $fangchanNum;
	if ($fangchanNum > 10000) {
		$fangchanNumTmp = $fangchanNum / 10000;
		$fangchanNumTxt = number_format($fangchanNumTmp, 2);
	}
	$diyListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_diynav')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY dsort ASC,id DESC ', 0, 100);
	if (!is_array($diyListTmp) || empty($diyListTmp)) {
		$diyListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_diynav')->fetch_all_list(' AND site_id=1 ', ' ORDER BY dsort ASC,id DESC ', 0, 100);
	}
	$diyList = array();
	$i = 1;
	$navCount = 0;
	if (is_array($diyListTmp) && !empty($diyListTmp)) {
		foreach ($diyListTmp as $key => $value) {
			$diyList[$key] = $value;
			$diyList[$key]['i'] = $i;
			$diyList[$key]['link'] = str_replace('{site}', $site_id, $diyList[$key]['link']);
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$diyList[$key]['picurl'] = $picurl;
			if ($value['type'] == 1) {
				if ($value['model_id'] == 'newhouses') {
					$diyList[$key]['link'] = 'plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=newhouseslist';
				} elseif ($value['model_id'] == 'qiugou') {
					$diyList[$key]['link'] = 'plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=needslist&type=1';
				} elseif ($value['model_id'] == 'qiuzu') {
					$diyList[$key]['link'] = 'plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=needslist&type=2';
				} else {
					$diyList[$key]['link'] = 'plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=list&model_id=' . $value['model_id'];
				}
			}
			$i++;
			$navCount++;
		}
	}
	$guanggaoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_guanggao')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY gsort ASC,id DESC ', 0, 10);
	if (!is_array($guanggaoListTmp) || empty($guanggaoListTmp)) {
		$guanggaoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_guanggao')->fetch_all_list(' AND site_id=1 ', ' ORDER BY gsort ASC,id DESC ', 0, 10);
	}
	$guanggaoList = array();
	if (is_array($guanggaoListTmp) && !empty($guanggaoListTmp)) {
		foreach ($guanggaoListTmp as $key => $value) {
			$guanggaoList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$guanggaoList[$key]['picurl'] = $picurl;
		}
	}
	if ($tcfangchanConfig['open_index_mendian'] == 1) {
		$mendianListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_list(' AND site_id IN(' . $sql_in_site_ids . ') AND shenhe_status = 1 ', 'ORDER BY top_status DESC,house_num DESC,id DESC', 0, 10);
		$mendianList = array();
		if (is_array($mendianListTmp) && !empty($mendianListTmp)) {
			foreach ($mendianListTmp as $key => $value) {
				$mendianList[$key] = $value;
				$photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(' AND mendian_id = ' . $value['id'] . ' AND type = 5 ', 'ORDER BY id ASC', 0, 1);
				$picurlTmp = '';
				if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
					$picurlTmp = $photoInfoTmp[0]['picurlTmp'];
				}
				$mendianList[$key]['picurl'] = $picurlTmp;
			}
		}
	}
	if ($tcfangchanConfig['open_index_agent'] == 1) {
		$agentListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_agent_list(' AND site_id IN(' . $sql_in_site_ids . ') AND shenhe_status = 1 AND is_ok = 1 ', 'ORDER BY top_status DESC, id DESC', 0, 10);
		$agentList = array();
		if (is_array($agentListTmp) && !empty($agentListTmp)) {
			foreach ($agentListTmp as $key => $value) {
				$agentList[$key] = $value;
				$mendianInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($value['mendian_id']);
				if (!preg_match('/^http/', $value['avatar'])) {
					if (strpos($value['avatar'], 'source/plugin/tom_') === false) {
						$avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['avatar'];
					} else {
						$avatar = $_G['siteurl'] . $value['avatar'];
					}
				} else {
					$avatar = $value['avatar'];
				}
				$agentList[$key]['avatar'] = $avatar;
				$agentList[$key]['mendianInfo'] = $mendianInfoTmp;
			}
		}
	}
	if ($tcfangchanConfig['open_qiugou'] == 1 || $tcfangchanConfig['open_qiuzu'] == 1) {
		$needsListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_like_list(' AND site_id IN(' . $sql_in_site_ids . ') AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ', 'ORDER BY top_status DESC,top_time DESC,refresh_time DESC,id DESC', 0, 10, '');
		$needsList = array();
		foreach ($needsListTmp as $key => $value) {
			if ($tcfangchanConfig['open_contact_needs_price'] == 1) {
				$value['content'] = preg_replace('/\\d{7}/', '*****', $value['content']);
			}
			$needsList[$key] = $value;
			$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$needsList[$key]['userInfo'] = $userInfoTmp;
			$needsList[$key]['refresh_time'] = dgmdate($value['refresh_time'], 'm-d', $tomSysOffset);
		}
	}
	$tcfangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list(' AND site_id IN(' . $sql_in_site_ids . ') AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) ', ' ORDER BY id DESC ', 0, 10);
	$tcfangchanList = array();
	if (is_array($tcfangchanListTmp) && !empty($tcfangchanListTmp)) {
		foreach ($tcfangchanListTmp as $key => $value) {
			$tcfangchanList[$key] = $value;
			if ($value['source_type'] == 1) {
				$agentInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($value['user_id']);
				$nicknameTmp = $agentInfoTmp['name'];
			} elseif ($value['source_type'] == 2) {
				$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
				$nicknameTmp = $userInfoTmp['nickname'];
			}
			$nicknameTmp = cutstr($nicknameTmp, 10, '...');
			$tcfangchanList[$key]['nickname'] = $nicknameTmp;
		}
	}
	$newhousesList = array();
	if ($tcfangchanConfig['index_newhouses_num'] > 0) {
		$newhousesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_list(' AND status = 1 AND site_id IN(' . $sql_in_site_ids . ')', 'ORDER BY top_status DESC,id DESC', 0, $tcfangchanConfig['index_newhouses_num']);
		if (is_array($newhousesListTmp) && !empty($newhousesListTmp)) {
			foreach ($newhousesListTmp as $key => $value) {
				$newhousesList[$key] = $value;
				$teseTagsArr = explode('|', trim($value['tese_tags'], '|'));
				$typeList = array();
				if (!empty($value['type'])) {
					$typeListTmp = explode('|', trim($value['type'], '|'));
					if (is_array($typeListTmp) && !empty($typeListTmp)) {
						foreach ($typeListTmp as $k => $v) {
							if (!empty($v)) {
								$typeList[] = $houseTypeArr[$v];
							}
						}
					}
				}
				if (!empty($value['vr_link'])) {
					$photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list('AND newhouses_id = ' . $value['id'] . ' AND type = 2 ', 'ORDER BY id ASC', 0, 1);
				} else {
					$photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list('AND newhouses_id = ' . $value['id'] . ' AND type = 1 ', 'ORDER BY id ASC', 0, 1);
				}
				$picurlTmp = '';
				if (is_array($photoInfoTmp) && !empty($photoInfoTmp[0])) {
					$picurlTmp = $photoInfoTmp[0]['picurlTmp'];
				}
				$newhousesList[$key]['liulan_status'] = 0;
				if ($__UserInfo['id'] > 0) {
					$historyInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_history')->fetch_all_list('AND newhouses_id = ' . $value['id'] . ' AND user_id = ' . $__UserInfo['id'] . ' AND last_time = ' . $nowDayTime . ' ', 'ORDER BY id ASC', 0, 1);
					if (is_array($historyInfoTmp) && !empty($historyInfoTmp[0])) {
						$newhousesList[$key]['liulan_status'] = 1;
					}
				}
				$newhousesList[$key]['teseTagsList'] = $teseTagsArr;
				$newhousesList[$key]['typeList'] = $typeList;
				$newhousesList[$key]['picurl'] = $picurlTmp;
			}
		}
	}
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tcfangchan/images/index.js';
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=index'));
	$searchUrl = 'plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=list&';
	$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
	$ajaxNewHousesListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=newhouseslist&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcfangchan:index');
	echo '<script src="source/plugin/tom_tcfangchan/images/index.js"></script>';
} elseif ($_GET['mod'] == 'list') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$model_id = isset($_GET['model_id']) ? addslashes($_GET['model_id']) : 'ershoufang';
	$url = '&model_id=' . $model_id;
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$url .= '&keyword=' . urlencode(trim($keyword));
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$url .= '&area_id=' . $area_id;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$url .= '&street_id=' . $street_id;
	$houses_min_price = intval($_GET['houses_min_price']) > 0 ? intval($_GET['houses_min_price']) : 0;
	$url .= '&houses_min_price=' . $houses_min_price;
	$houses_max_price = intval($_GET['houses_max_price']) > 0 ? intval($_GET['houses_max_price']) : 0;
	$url .= '&houses_max_price=' . $houses_max_price;
	$house_type = intval($_GET['house_type']) > 0 ? intval($_GET['house_type']) : 0;
	$url .= '&house_type=' . $house_type;
	$source_type = intval($_GET['source_type']) > 0 ? intval($_GET['source_type']) : 0;
	$url .= '&source_type=' . $source_type;
	$min_mianji = intval($_GET['min_mianji']) > 0 ? intval($_GET['min_mianji']) : 0;
	$url .= '&min_mianji=' . $min_mianji;
	$max_mianji = intval($_GET['max_mianji']) > 0 ? intval($_GET['max_mianji']) : 0;
	$url .= '&max_mianji=' . $max_mianji;
	$chaoxiang_type = intval($_GET['chaoxiang_type']) > 0 ? intval($_GET['chaoxiang_type']) : 0;
	$url .= '&chaoxiang_type=' . $chaoxiang_type;
	$tesetags = isset($_GET['tesetags']) ? addslashes($_GET['tesetags']) : '';
	$url .= '&tesetags=' . $tesetags;
	$zhuangxiu_type = intval($_GET['zhuangxiu_type']) > 0 ? intval($_GET['zhuangxiu_type']) : 0;
	$url .= '&zhuangxiu_type=' . $zhuangxiu_type;
	$elevator = intval($_GET['elevator']) > 0 ? intval($_GET['elevator']) : 0;
	$url .= '&elevator=' . $elevator;
	$paixu_type = intval($_GET['paixu_type']) > 0 ? intval($_GET['paixu_type']) : 0;
	$url .= '&paixu_type=' . $paixu_type;
	$min_rent = intval($_GET['min_rent']) > 0 ? intval($_GET['min_rent']) : 0;
	$url .= '&min_rent=' . $min_rent;
	$max_rent = intval($_GET['max_rent']) > 0 ? intval($_GET['max_rent']) : 0;
	$url .= '&max_rent=' . $max_rent;
	$lease = intval($_GET['lease']) > 0 ? intval($_GET['lease']) : 0;
	$url .= '&lease=' . $lease;
	$rent_type = intval($_GET['rent_type']) > 0 ? intval($_GET['rent_type']) : 0;
	$url .= '&rent_type=' . $rent_type;
	$fangchan_nature = intval($_GET['fangchan_nature']) > 0 ? intval($_GET['fangchan_nature']) : 0;
	$url .= '&fangchan_nature=' . $fangchan_nature;
	$shi = intval($_GET['shi']) > 0 ? intval($_GET['shi']) : 0;
	$url .= '&shi=' . $shi;
	$trade_name = isset($_GET['trade_name']) ? daddslashes(urldecode($_GET['trade_name'])) : '';
	if (!empty($trade_name)) {
		$keyword = $trade_name;
		$url .= '&keyword=' . urlencode(trim($trade_name));
	}
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$cityList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$cityList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$teseTagListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_all_list(' AND model_id = \'' . $model_id . '\' ', 'ORDER BY tsort ASC,id DESC', 0, 30);
	$teseTagList = array();
	if (is_array($teseTagListTmp) && !empty($teseTagListTmp)) {
		foreach ($teseTagListTmp as $key => $value) {
			$teseTagList[$value['id']] = $value['name'];
		}
	}
	$teseList = array();
	if (!empty($tesetags)) {
		$teseList = explode(',', $tesetags);
	}
	$teseTypeList = array();
	if (is_array($teseTagList) && !empty($teseTagList)) {
		foreach ($teseTagList as $key => $value) {
			$teseTypeList[$key]['name'] = $value;
			if (in_array($key, $teseList)) {
				$teseTypeList[$key]['selected'] = 1;
			} else {
				$teseTypeList[$key]['selected'] = 0;
			}
		}
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=list&' . $url));
	$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=list&' . $url . '&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$fangchanlistUrl = 'plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=list&';
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=list&model_id=' . $model_id . '&tjid=' . $__TjHehuorenId . '&s=1');
	if ($model_id == 'ershoufang') {
		$configListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config')->fetch_all_list(' AND type IN(1,4) ', 'ORDER BY csort ASC,id DESC', 0, 20);
		$priceList = $mianjiList = array();
		if (is_array($configListTmp) && !empty($configListTmp)) {
			foreach ($configListTmp as $key => $value) {
				if ($value['type'] == 1) {
					$priceList[$key] = $value;
				} elseif ($value['type'] == 4) {
					$mianjiList[$key] = $value;
				}
			}
		}
		$priceName = '';
		if ($houses_min_price > 0 && $houses_max_price > 0) {
			$priceName = $houses_min_price . '-' . $houses_max_price . lang('plugin/tom_tcfangchan', 'wan');
		} else {
			if ($houses_min_price > 0 && $houses_max_price == 0) {
				$priceName = $houses_min_price . lang('plugin/tom_tcfangchan', 'list_wan_yishang');
			} else {
				if ($houses_min_price == 0 && $houses_max_price > 0) {
					$priceName = $houses_max_price . lang('plugin/tom_tcfangchan', 'list_wan_yixia');
				}
			}
		}
		$fangchanCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_user_houses_count(' AND model_id = \'' . $model_id . '\' AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) AND finish = 0  ');
		if (!empty($tcfangchanConfig['ershoufang_list_share_title'])) {
			$shareTitle = $tcfangchanConfig['ershoufang_list_share_title'];
			$shareTitle = str_replace('{MODELNAME}', lang('plugin/tom_tcfangchan', $model_id), $shareTitle);
			$shareTitle = str_replace('{NUM}', $fangchanCount, $shareTitle);
			$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
		}
		if (!empty($tcfangchanConfig['ershoufang_list_share_desc'])) {
			$shareDesc = $tcfangchanConfig['ershoufang_list_share_desc'];
			$shareDesc = str_replace('{MODELNAME}', lang('plugin/tom_tcfangchan', $model_id), $shareDesc);
			$shareDesc = str_replace('{NUM}', $fangchanCount, $shareDesc);
			$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
		}
		if (!empty($tcfangchanConfig['ershoufang_list_share_pic'])) {
			$shareLogo = $tcfangchanConfig['ershoufang_list_share_pic'];
		}
		$isGbk = false;
		if (CHARSET == 'gbk') {
			$isGbk = true;
		}
		include template('tom_tcfangchan:list/ershoufanglist');
	} elseif ($model_id == 'chuzu') {
		$priceListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config')->fetch_all_list(' AND type = 3', 'ORDER BY csort ASC,id DESC', 0, 20);
		$priceList = array();
		if (is_array($priceListTmp) && !empty($priceListTmp)) {
			foreach ($priceListTmp as $key => $value) {
				$priceList[$key] = $value;
			}
		}
		$rentName = '';
		if ($min_rent > 0 && $max_rent > 0) {
			$rentName = $min_rent . '-' . $max_rent . lang('plugin/tom_tcfangchan', 'yuan');
		} else {
			if ($min_rent > 0 && $max_rent == 0) {
				$rentName = $min_rent . lang('plugin/tom_tcfangchan', 'list_yuan_yishang');
			} else {
				if ($min_rent == 0 && $max_rent > 0) {
					$rentName = $max_rent . lang('plugin/tom_tcfangchan', 'list_yuan_yixia');
				}
			}
		}
		$fangchanCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_user_houses_count(' AND model_id = \'' . $model_id . '\' AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) AND finish = 0  ');
		if (!empty($tcfangchanConfig['chuzu_list_share_title'])) {
			$shareTitle = $tcfangchanConfig['chuzu_list_share_title'];
			$shareTitle = str_replace('{MODELNAME}', lang('plugin/tom_tcfangchan', $model_id), $shareTitle);
			$shareTitle = str_replace('{NUM}', $fangchanCount, $shareTitle);
			$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
		}
		if (!empty($tcfangchanConfig['chuzu_list_share_desc'])) {
			$shareDesc = $tcfangchanConfig['chuzu_list_share_desc'];
			$shareDesc = str_replace('{MODELNAME}', lang('plugin/tom_tcfangchan', $model_id), $shareDesc);
			$shareDesc = str_replace('{NUM}', $fangchanCount, $shareDesc);
			$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
		}
		if (!empty($tcfangchanConfig['chuzu_list_share_pic'])) {
			$shareLogo = $tcfangchanConfig['chuzu_list_share_pic'];
		}
		$isGbk = false;
		if (CHARSET == 'gbk') {
			$isGbk = true;
		}
		include template('tom_tcfangchan:list/chuzulist');
	} elseif ($model_id == 'shangpu') {
		$mianjiListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config')->fetch_all_list(' AND type = 5 ', 'ORDER BY csort ASC,id DESC', 0, 20);
		$mianjiList = array();
		if (is_array($mianjiListTmp) && !empty($mianjiListTmp)) {
			foreach ($mianjiListTmp as $key => $value) {
				$mianjiList[$key] = $value;
			}
		}
		$mianjiName = '';
		if ($min_mianji > 0 && $max_mianji > 0) {
			$mianjiName = $min_mianji . '-' . $max_mianji . lang('plugin/tom_tcfangchan', 'pingmi');
		} else {
			if ($min_mianji > 0 && $max_mianji == 0) {
				$mianjiName = $min_mianji . lang('plugin/tom_tcfangchan', 'list_pingmi_yishang');
			} else {
				if ($min_mianji == 0 && $max_mianji > 0) {
					$mianjiName = $max_mianji . lang('plugin/tom_tcfangchan', 'list_pingmi_yixia');
				}
			}
		}
		$isGbk = false;
		if (CHARSET == 'gbk') {
			$isGbk = true;
		}
		include template('tom_tcfangchan:list/shangpulist');
	} elseif ($model_id == 'xiezilou') {
		$mianjiListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config')->fetch_all_list(' AND type = 5 ', 'ORDER BY csort ASC,id DESC', 0, 20);
		$mianjiList = array();
		if (is_array($mianjiListTmp) && !empty($mianjiListTmp)) {
			foreach ($mianjiListTmp as $key => $value) {
				$mianjiList[$key] = $value;
			}
		}
		$mianjiName = '';
		if ($min_mianji > 0 && $max_mianji > 0) {
			$mianjiName = $min_mianji . '-' . $max_mianji . lang('plugin/tom_tcfangchan', 'pingmi');
		} else {
			if ($min_mianji > 0 && $max_mianji == 0) {
				$mianjiName = $min_mianji . lang('plugin/tom_tcfangchan', 'list_pingmi_yishang');
			} else {
				if ($min_mianji == 0 && $max_mianji > 0) {
					$mianjiName = $max_mianji . lang('plugin/tom_tcfangchan', 'list_pingmi_yixia');
				}
			}
		}
		$isGbk = false;
		if (CHARSET == 'gbk') {
			$isGbk = true;
		}
		include template('tom_tcfangchan:list/xieziloulist');
	} elseif ($model_id == 'changfang') {
		$mianjiListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config')->fetch_all_list(' AND type = 6 ', 'ORDER BY csort ASC,id DESC', 0, 20);
		$mianjiList = array();
		if (is_array($mianjiListTmp) && !empty($mianjiListTmp)) {
			foreach ($mianjiListTmp as $key => $value) {
				$mianjiList[$key] = $value;
			}
		}
		$mianjiName = '';
		if ($min_mianji > 0 && $max_mianji > 0) {
			$mianjiName = $min_mianji . '-' . $max_mianji . lang('plugin/tom_tcfangchan', 'pingmi');
		} else {
			if ($min_mianji > 0 && $max_mianji == 0) {
				$mianjiName = $min_mianji . lang('plugin/tom_tcfangchan', 'list_pingmi_yishang');
			} else {
				if ($min_mianji == 0 && $max_mianji > 0) {
					$mianjiName = $max_mianji . lang('plugin/tom_tcfangchan', 'list_pingmi_yixia');
				}
			}
		}
		$isGbk = false;
		if (CHARSET == 'gbk') {
			$isGbk = true;
		}
		include template('tom_tcfangchan:list/changfanglist');
	} elseif ($model_id == 'cangku') {
		$mianjiListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config')->fetch_all_list(' AND type = 6 ', 'ORDER BY csort ASC,id DESC', 0, 20);
		$mianjiList = array();
		if (is_array($mianjiListTmp) && !empty($mianjiListTmp)) {
			foreach ($mianjiListTmp as $key => $value) {
				$mianjiList[$key] = $value;
			}
		}
		$mianjiName = '';
		if ($min_mianji > 0 && $max_mianji > 0) {
			$mianjiName = $min_mianji . '-' . $max_mianji . lang('plugin/tom_tcfangchan', 'pingmi');
		} else {
			if ($min_mianji > 0 && $max_mianji == 0) {
				$mianjiName = $min_mianji . lang('plugin/tom_tcfangchan', 'list_pingmi_yishang');
			} else {
				if ($min_mianji == 0 && $max_mianji > 0) {
					$mianjiName = $max_mianji . lang('plugin/tom_tcfangchan', 'list_pingmi_yixia');
				}
			}
		}
		$isGbk = false;
		if (CHARSET == 'gbk') {
			$isGbk = true;
		}
		include template('tom_tcfangchan:list/cangkulist');
	} elseif ($model_id == 'tudi') {
		$mianjiListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config')->fetch_all_list(' AND type = 6 ', 'ORDER BY csort ASC,id DESC', 0, 20);
		$mianjiList = array();
		if (is_array($mianjiListTmp) && !empty($mianjiListTmp)) {
			foreach ($mianjiListTmp as $key => $value) {
				$mianjiList[$key] = $value;
			}
		}
		$mianjiName = '';
		if ($min_mianji > 0 && $max_mianji > 0) {
			$mianjiName = $min_mianji . '-' . $max_mianji . lang('plugin/tom_tcfangchan', 'pingmi');
		} else {
			if ($min_mianji > 0 && $max_mianji == 0) {
				$mianjiName = $min_mianji . lang('plugin/tom_tcfangchan', 'list_pingmi_yishang');
			} else {
				if ($min_mianji == 0 && $max_mianji > 0) {
					$mianjiName = $max_mianji . lang('plugin/tom_tcfangchan', 'list_pingmi_yixia');
				}
			}
		}
		$isGbk = false;
		if (CHARSET == 'gbk') {
			$isGbk = true;
		}
		include template('tom_tcfangchan:list/tudilist');
	}
} elseif ($_GET['mod'] == 'info') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$tcfangchan_id = intval($_GET['tcfangchan_id']) > 0 ? intval($_GET['tcfangchan_id']) : 0;
	$tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
	if (!is_array($tcfangchanInfo) || empty($tcfangchanInfo) || $tcfangchanInfo['shenhe_status'] != 1 || $tcfangchanInfo['status'] != 1 || $tcfangchanInfo['pay_status'] != 0 && $tcfangchanInfo['pay_status'] != 2) {
		if ($tcfangchanInfo['id'] > 0) {
			if ($__UserInfo['groupid'] != 1 && $__UserInfo['groupid'] != 2) {
				if ($__UserInfo['id'] != $tcfangchanConfig['fcmanage_user_id']) {
					tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=index'));
					exit(0);
				}
			}
		} else {
			tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=index'));
			exit(0);
		}
	}
	$model_name = lang('plugin/tom_tcfangchan', $tcfangchanInfo['model_id']);
	$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcfangchanInfo['user_id']);
	$agentStatus = 0;
	if ($tcfangchanInfo['source_type'] == 1) {
		$agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
		if ($agentInfo['id'] > 0) {
			$agentStatus = 1;
			$mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($agentInfo['mendian_id']);
			if (!preg_match('/^http/', $agentInfo['avatar'])) {
				if (strpos($agentInfo['avatar'], 'source/plugin/tom_') === false) {
					$avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $agentInfo['avatar'];
				} else {
					$avatar = $agentInfo['avatar'];
				}
			} else {
				$avatar = $agentInfo['avatar'];
			}
			if (!preg_match('/^http/', $agentInfo['wx_qrcode'])) {
				if (strpos($agentInfo['wx_qrcode'], 'source/plugin/tom_') === false) {
					$wxQrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $agentInfo['wx_qrcode'];
				} else {
					$wxQrcode = $agentInfo['wx_qrcode'];
				}
			} else {
				$wxQrcode = $agentInfo['wx_qrcode'];
			}
		}
	}
	if ($tcfangchanInfo['houses_id'] > 0) {
		$housesInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($tcfangchanInfo['houses_id']);
		$housesInfo = array();
		if ($housesInfoTmp['status'] == 1 && $housesInfoTmp['shenhe_status'] == 1) {
			$housesInfo = $housesInfoTmp;
		}
	}
	$attrInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_attr')->fetch_all_list(' AND tcfangchan_id = ' . $tcfangchan_id . ' ', 'ORDER BY attr_id DESC', 0, 1);
	$attrInfo = array();
	if (is_array($attrInfoTmp) && !empty($attrInfoTmp[0])) {
		$attrInfo = $attrInfoTmp[0];
	}
	$chuzuPeitaoList = array();
	if (!empty($attrInfo['attr_peitao_tags'])) {
		$attrPeitaoTagsList = explode('|', trim($attrInfo['attr_peitao_tags'], '|'));
		if (is_array($chuzuPeitaoArr) && !empty($chuzuPeitaoArr)) {
			foreach ($chuzuPeitaoArr as $key => $value) {
				$chuzuPeitaoList[$key] = $value;
				$chuzuPeitaoList[$key]['status'] = 0;
				if (in_array($value['name'], $attrPeitaoTagsList)) {
					$chuzuPeitaoList[$key]['status'] = 1;
				}
			}
		}
	}
	$attrTeseTagsList = array();
	if (!empty($attrInfo['attr_tese_tags'])) {
		$attrTeseTagsList = explode('|', trim($attrInfo['attr_tese_tags'], '|'));
	}
	$tcfangchanInfo['content'] = stripslashes($tcfangchanInfo['content']);
	$average_price = intval($tcfangchanInfo['price'] / $tcfangchanInfo['mianji'] * 10000);
	$photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(' AND tcfangchan_id=' . $tcfangchan_id . ' AND type IN(1,2,4) ', ' ORDER BY type DESC,psort ASC,id ASC ', 0, 20);
	$photoList = array();
	$vrPicurl = $videoPicurl = $haibaoPicurl = '';
	$i = 1;
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			$picurlTmp = $value['picurlTmp'];
			if ($value['type'] == 1) {
				$photoList[] = $picurlTmp;
			}
			if ($value['type'] == 2) {
				$vrPicurl = $picurlTmp;
			}
			if ($value['type'] == 4) {
				$videoPicurl = $picurlTmp;
			}
			if ($i == 1) {
				$shareLogo = $picurlTmp;
			}
			if (empty($haibaoPicurl) && $value['type'] == 1) {
				if (!preg_match('/^http/', $value['picurl'])) {
					if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
						$haibaoPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
					} else {
						$haibaoPicurl = $value['picurl'];
					}
				} else {
					$haibaoPicurl = $value['picurl'];
				}
			}
			$i++;
		}
	}
	$photoListStr = implode('|', $photoList);
	if (empty($haibaoPicurl)) {
		$haibaoPicurl = $tcfangchanConfig['default_fangchan_photo'];
	}
	$guanzuStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$guanzuInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_guanzu')->fetch_all_list(' AND tcfangchan_id = ' . $tcfangchan_id . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
		if (is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])) {
			$guanzuStatus = 1;
		}
	}
	$baiduMapToName = $tcfangchanInfo['title'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tcfangchanInfo['latitude'] . ',' . $tcfangchanInfo['longitude'] . '&title=' . $baiduMapToName . '&content=&output=html';
	$contentTmp = strip_tags($tcfangchanInfo['content']);
	$contentTmp = str_replace("\r\n", '', $contentTmp);
	$contentTmp = str_replace("\n", '', $contentTmp);
	$contentTmp = str_replace("\r", '', $contentTmp);
	$tcfangchanInfo['content'] = str_replace("\r\n", '<br/>', $tcfangchanInfo['content']);
	$tcfangchanInfo['content'] = str_replace("\n", '<br/>', $tcfangchanInfo['content']);
	$tcfangchanInfo['content'] = str_replace("\r", '<br/>', $tcfangchanInfo['content']);
	$fangchanNatureMsg = '';
	if ($tcfangchanInfo['fangchan_nature'] == 1) {
		$fangchanNatureMsg = lang('plugin/tom_tcfangchan', 'list_fangchan_nature_1');
	} elseif ($tcfangchanInfo['fangchan_nature'] == 2) {
		$fangchanNatureMsg = lang('plugin/tom_tcfangchan', 'list_fangchan_nature_2');
	} elseif ($tcfangchanInfo['fangchan_nature'] == 3) {
		$fangchanNatureMsg = lang('plugin/tom_tcfangchan', 'list_fangchan_nature_3');
	}
	$shareTitle = $tcfangchanInfo['title'];
	if (!empty($tcfangchanConfig['info_share_title'])) {
		$shareTitle = $tcfangchanConfig['info_share_title'];
		$shareTitle = str_replace('{MODEL}', lang('plugin/tom_tcfangchan', $tcfangchanInfo['model_id']) . $fangchanNatureMsg, $shareTitle);
		$shareTitle = str_replace('{TITLE}', $tcfangchanInfo['title'], $shareTitle);
		$shareTitle = str_replace('{AREANAME}', $tcfangchanInfo['area_name'], $shareTitle);
		$shareTitle = str_replace('{STREETNAME}', $tcfangchanInfo['street_name'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	$shareDesc = cutstr($contentTmp, 80, '...');
	if (!empty($tcfangchanConfig['info_share_desc'])) {
		$shareDesc = $tcfangchanConfig['info_share_desc'];
		$shareDesc = str_replace('{MODEL}', lang('plugin/tom_tcfangchan', $tcfangchanInfo['model_id']) . $fangchanNatureMsg, $shareDesc);
		$shareDesc = str_replace('{TITLE}', $tcfangchanInfo['title'], $shareDesc);
		$shareDesc = str_replace('{AREANAME}', $tcfangchanInfo['area_name'], $shareDesc);
		$shareDesc = str_replace('{STREETNAME}', $tcfangchanInfo['street_name'], $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=info&tcfangchan_id=' . $tcfangchan_id . '&tjid=' . $__TjHehuorenId . '&s=1');
	if ($tcfangchanConfig['info_tj_type'] == 2) {
		$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=list&model_id=' . $tcfangchanInfo['model_id'] . '&paixu_type=1&latitude=' . $tcfangchanInfo['latitude'] . '&longitude=' . $tcfangchanInfo['longitude'] . '&user_id=' . $tcfangchanInfo['user_id'] . '&formhash=' . $formhash;
	} else {
		$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=list&model_id=' . $tcfangchanInfo['model_id'] . '&paixu_type=1&latitude=' . $tcfangchanInfo['latitude'] . '&longitude=' . $tcfangchanInfo['longitude'] . '&formhash=' . $formhash;
	}
	$messageUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&to_user_id=' . $tcfangchanInfo['user_id'] . '&formhash=' . FORMHASH . '&tcfangchan_id=' . $tcfangchan_id;
	$ajaxUpdateClickUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_fangchan_clicks&user_id=' . $__UserInfo['id'] . '&tcfangchan_id=' . $tcfangchan_id . '&formhash=' . $formhash;
	$ajaxUpdateGuanzuUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_fangchan_guanzu&user_id=' . $__UserInfo['id'] . '&tcfangchan_id=' . $tcfangchan_id . '&formhash=' . $formhash;
	$ajaxJubaoUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=fangchan_jubao&jubao_type=1&tcfangchan_id=' . $tcfangchan_id . '&user_id=' . $__UserInfo['id'] . '&formhash=' . $formhash;
	$ajaxVisitorLogUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=visitor_log&tcfangchan_id=' . $tcfangchan_id . '&user_id=' . $__UserInfo['id'] . '&formhash=' . $formhash;
	$ajaxTuiDoTzUrl = '';
	if ($__ShowTchehuoren == 1 && file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tui_do.php')) {
		include DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tui_do.php';
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcfangchan:info');
} elseif ($_GET['mod'] == 'info_vr') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/info_vr.php';
} elseif ($_GET['mod'] == 'info_video') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/info_video.php';
} elseif ($_GET['mod'] == 'houseslist') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$url = '&keyword=' . urlencode(trim($keyword));
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$url .= '&area_id=' . $area_id;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$url .= '&street_id=' . $street_id;
	$min_average_price = intval($_GET['min_average_price']) > 0 ? intval($_GET['min_average_price']) : 0;
	$url .= '&min_average_price=' . $min_average_price;
	$max_average_price = intval($_GET['max_average_price']) > 0 ? intval($_GET['max_average_price']) : 0;
	$url .= '&max_average_price=' . $max_average_price;
	$house_type = intval($_GET['house_type']) > 0 ? intval($_GET['house_type']) : 0;
	$url .= '&house_type=' . $house_type;
	$paixu_type = intval($_GET['paixu_type']) > 0 ? intval($_GET['paixu_type']) : 1;
	$url .= '&paixu_type=' . $paixu_type;
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$cityList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$cityList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$priceListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config')->fetch_all_list(' AND type = 2 ', 'ORDER BY csort ASC,id DESC', 0, 20);
	$priceList = array();
	if (is_array($priceListTmp) && !empty($priceListTmp)) {
		foreach ($priceListTmp as $key => $value) {
			$priceList[$key] = $value;
		}
	}
	$priceName = '';
	if ($min_average_price > 0 && $max_average_price > 0) {
		$priceName = $min_average_price . '-' . $max_average_price . lang('plugin/tom_tcfangchan', 'yuan');
	} else {
		if ($min_average_price > 0 && $max_average_price == 0) {
			$priceName = $min_average_price . lang('plugin/tom_tcfangchan', 'list_yuan_yishang');
		} else {
			if ($min_average_price == 0 && $max_average_price > 0) {
				$priceName = $max_average_price . lang('plugin/tom_tcfangchan', 'list_yuan_yixia');
			}
		}
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=list&' . $url));
	$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=houseslist&' . $url . '&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$houseslistUrl = 'plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=houseslist&';
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=houseslist&tjid=' . $__TjHehuorenId . '&s=1');
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcfangchan:houseslist');
} elseif ($_GET['mod'] == 'housesinfo') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$houses_id = intval($_GET['houses_id']) > 0 ? intval($_GET['houses_id']) : 0;
	$housesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($houses_id);
	if (!is_array($housesInfo) || empty($housesInfo) || $housesInfo['status'] != 1 || $housesInfo['shenhe_status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$nowTime = TIMESTAMP;
	$sellFangchanCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count('  AND houses_id = ' . $houses_id . ' AND model_id = \'ershoufang\' AND status=1 AND shenhe_status=1 AND finish = 0 AND ((pay_status = 0) OR (pay_status = 2)) ');
	$chuzuFangchanCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count('  AND houses_id = ' . $houses_id . ' AND model_id = \'chuzu\' AND status=1 AND shenhe_status=1 AND finish = 0 AND ((pay_status = 0) OR (pay_status = 2)) ');
	if ($housesInfo['open_auto_average'] == 1) {
		if (TIMESTAMP > $housesInfo['last_auto_time'] + 7 * 86400) {
			$sanMonthTime = TIMESTAMP - 90 * 86400;
			$totalInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_houses_average_price_sum_list('AND houses_id = ' . $housesInfo['id'] . ' AND model_id = \'ershoufang\' AND refresh_time > ' . $sanMonthTime . ' AND shenhe_status = 1 AND status = 1 AND finish = 0 AND (pay_status = 0 OR pay_status = 2) ');
			$average_price_tmp = 0;
			if (is_array($totalInfo) && !empty($totalInfo)) {
				$average_price_tmp = $totalInfo['totalprice'] * 10000 / $totalInfo['totalmanji'];
				$average_price_tmp = intval($average_price_tmp);
				$updateData = array();
				$updateData['average_price'] = $average_price_tmp;
				$updateData['last_auto_time'] = TIMESTAMP;
				C::t('#tom_tcfangchan#tom_tcfangchan_houses')->update($housesInfo['id'], $updateData);
			}
			$housesInfo['average_price'] = $average_price_tmp;
		}
	}
	$housesTypeStr = '';
	if (!empty($housesInfo['type'])) {
		$typeArr = explode('|', trim($housesInfo['type'], '|'));
		$housesTypeList = array();
		if (is_array($houseTypeArr) && !empty($houseTypeArr)) {
			foreach ($houseTypeArr as $key => $value) {
				if (in_array($key, $typeArr)) {
					$housesTypeList[] = $value;
				}
			}
		}
		$housesTypeStr = implode(' ', $housesTypeList);
	}
	$photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(' AND houses_id=' . $houses_id . ' AND type  = 1 ', ' ORDER BY type DESC,psort ASC,id ASC ', 0, 20);
	$photoList = array();
	$i = 1;
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			$picurlTmp = $value['picurlTmp'];
			$photoList[] = $picurlTmp;
			if ($i == 1) {
				$shareLogo = $picurlTmp;
			}
			$i++;
		}
	} else {
		if (!preg_match('/^http/', $tcfangchanConfig['default_houses_photo'])) {
			if (strpos($tcfangchanConfig['default_houses_photo'], 'source/plugin/tom_') === false) {
				$default_houses_photo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcfangchanConfig['default_houses_photo'];
			} else {
				$default_houses_photo = $_G['siteurl'] . $tcfangchanConfig['default_houses_photo'];
			}
		} else {
			$default_houses_photo = $tcfangchanConfig['default_houses_photo'];
		}
		$photoList[] = $default_houses_photo;
	}
	$photoCount = count($photoList);
	$photoListStr = implode('|', $photoList);
	$guanzuStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$guanzuInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_houses_guanzu')->fetch_all_list(' AND houses_id = ' . $houses_id . ' AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
		if (is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])) {
			$guanzuStatus = 1;
		}
	}
	$shareTitle = $housesInfo['name'] . '-' . $tcfangchanConfig['plugin_name'];
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=housesinfo&houses_id=' . $houses_id . '&tjid=' . $__TjHehuorenId . '&s=1');
	$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=houseslist&paixu_type=1&latitude=' . $housesInfo['latitude'] . '&longitude=' . $housesInfo['longitude'] . '&formhash=' . $formhash;
	$ajaxUpdateHousesClickUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_houses_clicks&houses_id=' . $houses_id . '&formhash=' . $formhash;
	$ajaxUpdateGuanzuUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_houses_guanzu&user_id=' . $__UserInfo['id'] . '&houses_id=' . $houses_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcfangchan:housesinfo');
} elseif ($_GET['mod'] == 'housesfangchanlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/housesfangchanlist.php';
} elseif ($_GET['mod'] == 'newhouseslist') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$url = '&keyword=' . urlencode(trim($keyword));
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$url .= '&area_id=' . $area_id;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$url .= '&street_id=' . $street_id;
	$min_average_price = intval($_GET['min_average_price']) > 0 ? intval($_GET['min_average_price']) : 0;
	$url .= '&min_average_price=' . $min_average_price;
	$max_average_price = intval($_GET['max_average_price']) > 0 ? intval($_GET['max_average_price']) : 0;
	$url .= '&max_average_price=' . $max_average_price;
	$house_type = intval($_GET['house_type']) > 0 ? intval($_GET['house_type']) : 0;
	$url .= '&house_type=' . $house_type;
	$sell_status = intval($_GET['sell_status']) > 0 ? intval($_GET['sell_status']) : 0;
	$url .= '&sell_status=' . $sell_status;
	$tesetags = isset($_GET['tesetags']) ? addslashes($_GET['tesetags']) : '';
	$url .= '&tesetags=' . $tesetags;
	$paixu_type = intval($_GET['paixu_type']) > 0 ? intval($_GET['paixu_type']) : 0;
	$url .= '&paixu_type=' . $paixu_type;
	$focuspicListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' AND type = 2 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_focuspic')->fetch_all_list(' AND site_id=1 AND type = 2 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	if (is_array($focuspicListTmp) && !empty($focuspicListTmp)) {
		foreach ($focuspicListTmp as $key => $value) {
			$focuspicList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$focuspicList[$key]['picurl'] = $picurl;
		}
	}
	$focuspicCount = count($focuspicList);
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$cityList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$cityList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$priceListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config')->fetch_all_list(' AND type = 2 ', 'ORDER BY csort ASC,id DESC', 0, 20);
	$priceList = array();
	if (is_array($priceListTmp) && !empty($priceListTmp)) {
		foreach ($priceListTmp as $key => $value) {
			$priceList[$key] = $value;
		}
	}
	$teseTagListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_all_list(' AND model_id = \'newhouses\' ', 'ORDER BY tsort ASC,id DESC', 0, 30);
	$teseTagList = array();
	if (is_array($teseTagListTmp) && !empty($teseTagListTmp)) {
		foreach ($teseTagListTmp as $key => $value) {
			$teseTagList[$value['id']] = $value['name'];
		}
	}
	$teseList = array();
	if (!empty($tesetags)) {
		$teseList = explode(',', $tesetags);
	}
	$teseTypeList = array();
	if (is_array($teseTagList) && !empty($teseTagList)) {
		foreach ($teseTagList as $key => $value) {
			$teseTypeList[$key]['name'] = $value;
			if (in_array($key, $teseList)) {
				$teseTypeList[$key]['selected'] = 1;
			} else {
				$teseTypeList[$key]['selected'] = 0;
			}
		}
	}
	$priceName = '';
	if ($min_average_price > 0 && $max_average_price > 0) {
		$priceName = $min_average_price . '-' . $max_average_price . lang('plugin/tom_tcfangchan', 'yuan');
	} else {
		if ($min_average_price > 0 && $max_average_price == 0) {
			$priceName = $min_average_price . lang('plugin/tom_tcfangchan', 'list_yuan_yishang');
		} else {
			if ($min_average_price == 0 && $max_average_price > 0) {
				$priceName = $max_average_price . lang('plugin/tom_tcfangchan', 'list_yuan_yixia');
			}
		}
	}
	$newhousesCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_count(' ');
	if (!empty($tcfangchanConfig['newhouses_list_share_title'])) {
		$shareTitle = $tcfangchanConfig['newhouses_list_share_title'];
		$shareTitle = str_replace('{MODELNAME}', lang('plugin/tom_tcfangchan', 'newhouses'), $shareTitle);
		$shareTitle = str_replace('{NUM}', $newhousesCount, $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($tcfangchanConfig['newhouses_list_share_desc'])) {
		$shareDesc = $tcfangchanConfig['newhouses_list_share_desc'];
		$shareDesc = str_replace('{MODELNAME}', lang('plugin/tom_tcfangchan', 'newhouses'), $shareDesc);
		$shareDesc = str_replace('{NUM}', $newhousesCount, $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	if (!empty($tcfangchanConfig['newhouses_list_share_pic'])) {
		$shareLogo = $tcfangchanConfig['newhouses_list_share_pic'];
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=newhouseslist&' . $url));
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=newhouseslist&' . $url . '&formhash=' . $formhash;
	$newhouseslistUrl = 'plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=newhouseslist&';
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=newhouseslist&' . $url . '&tjid=' . $__TjHehuorenId . '&s=1');
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcfangchan:newhouseslist');
} elseif ($_GET['mod'] == 'newhousesinfo') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$newhouses_id = intval($_GET['newhouses_id']) > 0 ? intval($_GET['newhouses_id']) : 0;
	$s_adviser_id = intval($_GET['s_adviser_id']) > 0 ? intval($_GET['s_adviser_id']) : 0;
	$newhousesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_by_id($newhouses_id);
	if (!is_array($newhousesInfo) || empty($newhousesInfo)) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$housesTypeList = array();
	if (!empty($newhousesInfo['type'])) {
		$typeArr = explode('|', trim($newhousesInfo['type'], '|'));
		if (is_array($houseTypeArr) && !empty($houseTypeArr)) {
			foreach ($houseTypeArr as $key => $value) {
				if (in_array($key, $typeArr)) {
					$housesTypeList[] = $value;
				}
			}
		}
	}
	$teseTagsList = array();
	if (!empty($newhousesInfo['tese_tags'])) {
		$teseTagsList = explode('|', trim($newhousesInfo['tese_tags'], '|'));
	}
	$photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(' AND newhouses_id=' . $newhouses_id . ' ', ' ORDER BY type DESC,psort ASC,id ASC ', 0, 100);
	$photoList = $huxingList = array();
	$vr_picurl = '';
	$i = 1;
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			$picurlTmp = $value['picurlTmp'];
			if ($value['type'] == 1) {
				$photoList[] = $picurlTmp;
				if ($i == 1) {
					$shareLogo = $picurlTmp;
				}
				$i++;
			} elseif ($value['type'] == 2) {
				$vr_picurl = $picurlTmp;
			} elseif ($value['type'] == 3) {
				$huxingList[$key] = $value;
				$huxingList[$key]['picurl'] = $picurlTmp;
			}
		}
	}
	$huxingCount = count($huxingList);
	$photoListStr = implode('|', $photoList);
	$shareAdviserId = 0;
	if ($tcfangchanConfig['open_newhouses_sale_adviser'] == 1 && $newhousesInfo['open_sale_adviser'] == 1) {
		if ($s_adviser_id > 0) {
			dsetcookie('tom_tcfangchan_s_adviser_id_' . $newhouses_id, $s_adviser_id, 3600);
		} else {
			$cookiesShareAdviserId = getcookie('tom_tcfangchan_s_adviser_id_' . $newhouses_id);
			if (!empty($cookiesShareAdviserId)) {
				$s_adviser_id = $cookiesShareAdviserId;
			}
		}
		$nowTime = TIMESTAMP;
		$adviserListTmp = array();
		if ($s_adviser_id > 0) {
			$adviserListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_list(' AND id = ' . $s_adviser_id . ' AND newhouses_id=' . $newhouses_id . ' AND status = 1 AND shenhe_status = 1 AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > ' . $nowTime . ')) ', ' ORDER BY asort ASC,id ASC ', 0, 1);
		}
		if (is_array($adviserListTmp) && !empty($adviserListTmp) && $adviserListTmp[0]['id'] > 0) {
			$shareAdviserId = $s_adviser_id;
		} else {
			$adviserListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_list(' AND newhouses_id=' . $newhouses_id . ' AND status = 1 AND shenhe_status = 1 AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > ' . $nowTime . ')) ', ' ORDER BY asort ASC,id ASC ');
		}
		$adviserList = array();
		if (is_array($adviserListTmp) && !empty($adviserListTmp)) {
			foreach ($adviserListTmp as $key => $value) {
				$adviserList[$key] = $value;
				if ($__UserInfo['id'] > 0 && $value['user_id'] == $__UserInfo['id']) {
					$shareAdviserId = $value['id'];
				}
				if (!empty($value['avatar'])) {
					if (!preg_match('/^http/', $value['avatar'])) {
						if (strpos($value['avatar'], 'source/plugin/tom_') === false) {
							$avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['avatar'];
						} else {
							$avatarTmp = $value['avatar'];
						}
					} else {
						$avatarTmp = $value['avatar'];
					}
				}
				if (!empty($value['wx_qrcode'])) {
					if (!preg_match('/^http/', $value['wx_qrcode'])) {
						if (strpos($value['wx_qrcode'], 'source/plugin/tom_') === false) {
							$wxQrcodeTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['wx_qrcode'];
						} else {
							$wxQrcodeTmp = $value['wx_qrcode'];
						}
					} else {
						$wxQrcodeTmp = $value['wx_qrcode'];
					}
				}
				$adviserList[$key]['avatar'] = $avatarTmp;
				$adviserList[$key]['wx_qrcode_pic'] = $wxQrcodeTmp;
			}
		}
		$adviserCount = count($adviserList);
	}
	$back_url = $weixinClass->get_url();
	$back_url = urlencode($back_url);
	$guanzuStatus = 0;
	if ($__UserInfo['id'] > 0) {
		$guanzuInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_guanzu')->fetch_all_list(' AND newhouses_id = ' . $newhouses_id . ' AND user_id = ' . $__UserInfo['id'] . ' AND type = 1 ', 'ORDER BY id DESC', 0, 1);
		if (is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])) {
			$guanzuStatus = 1;
		}
	}
	$newhousesInfo['content'] = stripslashes($newhousesInfo['content']);
	$newhousesInfo['content'] = str_replace("\r\n", '<br/>', $newhousesInfo['content']);
	$newhousesInfo['content'] = str_replace("\n", '<br/>', $newhousesInfo['content']);
	$newhousesInfo['content'] = str_replace("\r", '<br/>', $newhousesInfo['content']);
	$baiduMapToName = $newhousesInfo['name'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $newhousesInfo['latitude'] . ',' . $newhousesInfo['longitude'] . '&title=' . $baiduMapToName . '&content=&output=html';
	$shareTitle = $newhousesInfo['name'] . '-' . $tcfangchanConfig['plugin_name'];
	if (!empty($newhousesInfo['content'])) {
		$contentTmp = strip_tags($newhousesInfo['content']);
		$contentTmp = str_replace("\r\n", '', $contentTmp);
		$contentTmp = str_replace("\n", '', $contentTmp);
		$contentTmp = str_replace("\r", '', $contentTmp);
		$shareDesc = cutstr($contentTmp, 80, '...');
		$shareDesc = str_replace('&nbsp;', '', $shareDesc);
		$shareDesc = str_replace('&quot;', '', $shareDesc);
	}
	if ($shareAdviserId > 0) {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=newhousesinfo&newhouses_id=' . $newhouses_id . '&tjid=' . $__TjHehuorenId . '&s=1&s_adviser_id=' . $shareAdviserId);
	} else {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=newhousesinfo&newhouses_id=' . $newhouses_id . '&tjid=' . $__TjHehuorenId . '&s=1');
	}
	$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=newhouseslist&paixu_type=1&latitude=' . $newhousesInfo['latitude'] . '&longitude=' . $newhousesInfo['longitude'] . '&no_newhouses_id=' . $newhouses_id . '&formhash=' . $formhash;
	$ajaxUpdateNewHousesClickUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_newhouses_clicks&newhouses_id=' . $newhouses_id . '&formhash=' . $formhash;
	$ajaxUpdateGuanzuUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_newhouses_guanzu&user_id=' . $__UserInfo['id'] . '&newhouses_id=' . $newhouses_id . '&formhash=' . $formhash;
	$ajaxUpdateBianjiaUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_newhouses_bianjia&user_id=' . $__UserInfo['id'] . '&newhouses_id=' . $newhouses_id . '&formhash=' . $formhash;
	$ajaxUpdateOpenpanUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_newhouses_openpan&user_id=' . $__UserInfo['id'] . '&newhouses_id=' . $newhouses_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcfangchan:newhousesinfo');
} elseif ($_GET['mod'] == 'newhousesinfo_vr') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/newhousesinfo_vr.php';
} elseif ($_GET['mod'] == 'newhousesxiangqing') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/newhousesxiangqing.php';
} elseif ($_GET['mod'] == 'newhouseshuxing') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/newhouseshuxing.php';
} elseif ($_GET['mod'] == 'agentlist') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$url .= '&keyword=' . urlencode(trim($keyword));
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$url .= '&area_id=' . $area_id;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$url .= '&street_id=' . $street_id;
	$paixu_type = intval($_GET['paixu_type']) > 0 ? intval($_GET['paixu_type']) : 0;
	$url .= '&paixu_type=' . $paixu_type;
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$cityList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$cityList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($__UserInfo['id']);
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=agentlist&' . $url));
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=agentlist&tjid=' . $__TjHehuorenId . '&s=1');
	$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=agentlist&' . $url . '&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$agentlistUrl = 'plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=agentlist&';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcfangchan:agentlist');
} elseif ($_GET['mod'] == 'agentinfo') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$agent_id = intval($_GET['agent_id']) > 0 ? intval($_GET['agent_id']) : 0;
	$agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_id($agent_id);
	if (!is_array($agentInfo) || empty($agentInfo) || $agentInfo['shenhe_status'] != 1 || $agentInfo['is_ok'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($agentInfo['mendian_id']);
	$housesCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count(' AND user_id = ' . $agentInfo['user_id'] . ' AND status=1 AND shenhe_status=1 AND finish = 0 ');
	if (!preg_match('/^http/', $agentInfo['avatar'])) {
		if (strpos($agentInfo['avatar'], 'source/plugin/tom_') === false) {
			$avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $agentInfo['avatar'];
		} else {
			$avatar = $_G['siteurl'] . $agentInfo['avatar'];
		}
	} else {
		$avatar = $agentInfo['avatar'];
	}
	if (!preg_match('/^http/', $agentInfo['wx_qrcode'])) {
		if (strpos($agentInfo['wx_qrcode'], 'source/plugin/tom_') === false) {
			$wxQrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $agentInfo['wx_qrcode'];
		} else {
			$wxQrcode = $_G['siteurl'] . $agentInfo['wx_qrcode'];
		}
	} else {
		$wxQrcode = $agentInfo['wx_qrcode'];
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=agentinfo&agent_id=' . $agentInfo['id']));
	$shareLogo = $avatar;
	$shareTitle = $agentInfo['name'] . '-' . $tcfangchanConfig['plugin_name'];
	if (!empty($fangchanSetting['agentinfo_share_title'])) {
		$shareTitle = $fangchanSetting['agentinfo_share_title'];
		$shareTitle = str_replace('{NAME}', $agentInfo['name'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($fangchanSetting['agentinfo_share_desc'])) {
		$shareDesc = $fangchanSetting['agentinfo_share_desc'];
		$shareDesc = str_replace('{NAME}', $agentInfo['name'], $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=agentinfo&agent_id=' . $agentInfo['id'] . '&tjid=' . $__TjHehuorenId . '&s=1');
	$messageUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&to_user_id=' . $agentInfo['user_id'] . '&formhash=' . FORMHASH;
	$ajaxUpdateAgentClickUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_agent_clicks&agent_id=' . $agentInfo['id'] . '&formhash=' . $formhash;
	$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=list&user_id=' . $agentInfo['user_id'] . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcfangchan:agentinfo');
} elseif ($_GET['mod'] == 'mendianlist') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$url .= '&keyword=' . urlencode(trim($keyword));
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$url .= '&area_id=' . $area_id;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$url .= '&street_id=' . $street_id;
	$paixu_type = intval($_GET['paixu_type']) > 0 ? intval($_GET['paixu_type']) : 0;
	$url .= '&paixu_type=' . $paixu_type;
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$cityList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$cityList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_user_id($__UserInfo['id']);
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=mendianlist&' . $url));
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=mendianlist&tjid=' . $__TjHehuorenId . '&s=1');
	$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=mendianlist&' . $url . '&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$mendianlistUrl = 'plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=mendianlist&';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcfangchan:mendianlist');
} elseif ($_GET['mod'] == 'mendianinfo') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$mendian_id = intval($_GET['mendian_id']) > 0 ? intval($_GET['mendian_id']) : 0;
	$mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($mendian_id);
	if (!is_array($mendianInfo) || empty($mendianInfo) || $mendianInfo['shenhe_status'] != 1) {
		if ($mendianInfo['id'] > 0) {
			if ($__UserInfo['groupid'] != 1 && $__UserInfo['groupid'] != 2) {
				if ($__UserInfo['id'] != $tcfangchanConfig['fcmanage_user_id']) {
					tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=index'));
					exit(0);
				}
			}
		} else {
			tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=index'));
			exit(0);
		}
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$ershoufangCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_agent_houses_count(' AND m.id = ' . $mendian_id . ' AND t.model_id = \'ershoufang\' AND t.status=1 AND t.shenhe_status=1 AND t.finish = 0');
	$chuzuCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_agent_houses_count(' AND m.id = ' . $mendian_id . ' AND t.model_id = \'chuzu\' AND t.status=1 AND t.shenhe_status=1 AND t.finish = 0 ');
	$otherCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_agent_houses_count(' AND m.id = ' . $mendian_id . ' AND t.model_id IN(\'shangpu\',\'xiezilou\',\'changfang\',\'cangku\',\'tudi\') AND t.status=1 AND t.shenhe_status=1 AND t.finish = 0 ');
	$agentCountTmp = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_count(' AND mendian_id = ' . $mendian_id . ' AND shenhe_status = 1 ');
	if ($mendianInfo['house_num'] != $ershoufangCount + $chuzuCount + $otherCount || $mendianInfo['agent_num'] != $agentCountTmp) {
		$updateData = array();
		$updateData['house_num'] = $ershoufangCount + $chuzuCount + $otherCount;
		$updateData['agent_num'] = $agentCountTmp;
		C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendian_id, $updateData);
		$mendianInfo['house_num'] = $ershoufangCount + $chuzuCount + $otherCount;
		$mendianInfo['agent_num'] = $agentCountTmp;
	}
	$photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(' AND mendian_id=' . $mendianInfo['id'] . ' AND type IN (5,6,7) ', ' ORDER BY type DESC,psort ASC,id ASC ', 0, 20);
	$photoList = array();
	$logo_picurl = $business_licence_picurl = '';
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			if ($value['type'] == 5) {
				$logo_picurl = $value['picurlTmp'];
			} elseif ($value['type'] == 6) {
				$photoList[] = $value['picurlTmp'];
			} elseif ($value['type'] == 7) {
				$business_licence_picurl = $value['picurlTmp'];
			}
		}
	}
	$agentListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_list(' AND t.mendian_id = ' . $mendianInfo['id'] . ' AND t.shenhe_status = 1 AND t.is_ok = 1 ', ' ORDER BY t.clicks DESC,t.id DESC', 0, 5);
	$agentList = array();
	if (is_array($agentListTmp) && !empty($agentListTmp)) {
		foreach ($agentListTmp as $key => $value) {
			$agentList[$key] = $value;
			if (!preg_match('/^http/', $value['avatar'])) {
				if (strpos($value['avatar'], 'source/plugin/tom_') === false) {
					$avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['avatar'];
				} else {
					$avatarTmp = $_G['siteurl'] . $value['avatar'];
				}
			} else {
				$avatarTmp = $value['avatar'];
			}
			$agentList[$key]['avatar'] = $avatarTmp;
		}
	}
	$agentCount = count($agentList);
	$content = stripslashes($mendianInfo['content']);
	if ($mendianInfo['admin_edit'] == 0) {
		$content = str_replace("\r\n", '<br/>', $content);
		$content = str_replace("\n", '<br/>', $content);
		$content = str_replace("\r", '<br/>', $content);
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=mendianinfo&mendian_id=' . $mendianInfo['id']));
	$shareLogo = $logo_picurl;
	$shareTitle = $mendianInfo['name'] . '-' . $tcfangchanConfig['plugin_name'];
	if (!empty($fangchanSetting['mendianinfo_share_title'])) {
		$shareTitle = $fangchanSetting['mendianinfo_share_title'];
		$shareTitle = str_replace('{NAME}', $mendianInfo['name'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($fangchanSetting['mendianinfo_share_desc'])) {
		$shareDesc = $fangchanSetting['mendianinfo_share_desc'];
		$shareDesc = str_replace('{NAME}', $mendianInfo['name'], $shareDesc);
		$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=mendianinfo&mendian_id=' . $mendianInfo['id'] . '&tjid=' . $__TjHehuorenId . '&s=1');
	$ajaxClicksUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=update_mendian_clicks&mendian_id=' . $mendianInfo['id'] . '&formhash=' . FORMHASH;
	$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=list&mendian_id=' . $mendianInfo['id'] . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcfangchan:mendianinfo');
} elseif ($_GET['mod'] == 'needslist') {
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$url .= '&keyword=' . urlencode(trim($keyword));
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$url .= '&area_id=' . $area_id;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$url .= '&street_id=' . $street_id;
	$paixu_type = intval($_GET['paixu_type']) > 0 ? intval($_GET['paixu_type']) : 1;
	$url .= '&paixu_type=' . $paixu_type;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$url .= '&type=' . $type;
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$cityList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$cityList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=needslist&' . $url));
	$shareTitle = lang('plugin/tom_tcfangchan', 'needslist_title') . ' - ' . $tcfangchanConfig['plugin_name'];
	if ($type == 1) {
		$shareTitle = lang('plugin/tom_tcfangchan', 'needslist_qiugou_title') . ' - ' . $tcfangchanConfig['plugin_name'];
	} elseif ($type == 2) {
		$shareTitle = lang('plugin/tom_tcfangchan', 'needslist_qiuzu_title') . ' - ' . $tcfangchanConfig['plugin_name'];
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=needslist&type=' . $type . '{&tjid=' . $__TjHehuorenId . '&s=1');
	$ajaxListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=needslist&' . $url . '&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tcfangchan:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$needslistUrl = 'plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=needslist&';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcfangchan:needslist');
} elseif ($_GET['mod'] == 'mendianagentlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/mendianagentlist.php';
} elseif ($_GET['mod'] == 'mendianhouseslist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/mendianhouseslist.php';
} elseif ($_GET['mod'] == 'baidumap') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/baidumap.php';
} elseif ($_GET['mod'] == 'calculator') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/calculator.php';
} elseif ($_GET['mod'] == 'calculator_xiangqing') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/calculator_xiangqing.php';
} elseif ($_GET['mod'] == 'my') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/my.php';
} elseif ($_GET['mod'] == 'agentvip') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/agentvip.php';
} elseif ($_GET['mod'] == 'agentbuytop') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/agentbuytop.php';
} elseif ($_GET['mod'] == 'mymendian') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/mymendian.php';
} elseif ($_GET['mod'] == 'mendianvip') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/mendianvip.php';
} elseif ($_GET['mod'] == 'mendianchoose') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/mendianchoose.php';
} elseif ($_GET['mod'] == 'agentruzhu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/agentruzhu.php';
} elseif ($_GET['mod'] == 'agentedit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/agentedit.php';
} elseif ($_GET['mod'] == 'mendianruzhu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/mendianruzhu.php';
} elseif ($_GET['mod'] == 'mendianedit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/mendianedit.php';
} elseif ($_GET['mod'] == 'mendianbuytop') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/mendianbuytop.php';
} elseif ($_GET['mod'] == 'myguanzufangchan') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/myguanzufangchan.php';
} elseif ($_GET['mod'] == 'myguanzuhouses') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/myguanzuhouses.php';
} elseif ($_GET['mod'] == 'myguanzunewhouses') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/myguanzunewhouses.php';
} elseif ($_GET['mod'] == 'myvisitorlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/myvisitorlist.php';
} elseif ($_GET['mod'] == 'myagent') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/myagent.php';
} elseif ($_GET['mod'] == 'fabu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/fabu.php';
} elseif ($_GET['mod'] == 'myfangchanlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/myfangchanlist.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/edit.php';
} elseif ($_GET['mod'] == 'buytop') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/buytop.php';
} elseif ($_GET['mod'] == 'buyxufei') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/buyxufei.php';
} elseif ($_GET['mod'] == 'myhouseslist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/myhouseslist.php';
} elseif ($_GET['mod'] == 'mynewhouseslist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/mynewhouseslist.php';
} elseif ($_GET['mod'] == 'myadviserlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/myadviserlist.php';
} elseif ($_GET['mod'] == 'adviserruzhu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/adviserruzhu.php';
} elseif ($_GET['mod'] == 'adviseradd') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/adviseradd.php';
} elseif ($_GET['mod'] == 'adviseredit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/adviseredit.php';
} elseif ($_GET['mod'] == 'adviserbuy') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/adviserbuy.php';
} elseif ($_GET['mod'] == 'housesadd') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/housesadd.php';
} elseif ($_GET['mod'] == 'housesedit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/housesedit.php';
} elseif ($_GET['mod'] == 'newhousesadd') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/newhousesadd.php';
} elseif ($_GET['mod'] == 'newhousesedit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/newhousesedit.php';
} elseif ($_GET['mod'] == 'newhousesaddhuxing') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/newhousesaddhuxing.php';
} elseif ($_GET['mod'] == 'mynewhousesguanzu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/mynewhousesguanzu.php';
} elseif ($_GET['mod'] == 'managerList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/managerList.php';
} elseif ($_GET['mod'] == 'managerMendianList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/managerMendianList.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/upload.php';
} elseif ($_GET['mod'] == 'fabu_needs') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/fabu_needs.php';
} elseif ($_GET['mod'] == 'edit_needs') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/edit_needs.php';
} elseif ($_GET['mod'] == 'myfabu_needs') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/myfabu_needs.php';
} elseif ($_GET['mod'] == 'needsinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/needsinfo.php';
} elseif ($_GET['mod'] == 'managerNeedsList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/managerNeedsList.php';
} elseif ($_GET['mod'] == 'buyneedstop') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/buyneedstop.php';
} elseif ($_GET['mod'] == 'buyneedsxufei') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/buyneedsxufei.php';
} elseif ($_GET['mod'] == 'managerAgentList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcfangchan/module/managerAgentList.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcfangchan&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();