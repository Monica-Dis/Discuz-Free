<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20210319";

$fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
if($fangchanSetting && $fangchanSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_setting')->insert($insertData);
    $fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
}

$pcadminUrl = 'plugin.php?id=tom_tcfangchan:pcadmin';
$ajaxUrl = 'plugin.php?id=tom_admin:ajax';
$fangchanAjaxUrl = 'plugin.php?id=tom_tcfangchan:pcadminAjax';
$uploadUrl = 'plugin.php?id=tom_admin:upload';
$baidumapUrl = 'plugin.php?id=tom_admin:baidumap';

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/config/pcadmin.lang.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/config/config.data.php';
$weixinClass = new weixinClass($appid,$appsecret);

$Lang = $pcadminLang;

include DISCUZ_ROOT.'./source/plugin/tom_admin/login_check.php';

if($_GET['tmod'] == 'list'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/list.php';
}else if($_GET['tmod'] == 'add'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/add.php';
}else if($_GET['tmod'] == 'edit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/edit.php';
}else if($_GET['tmod'] == 'doDaoFangchan'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/doDaoFangchan.php';
}else if($_GET['tmod'] == 'needs'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/needs.php';
}else if($_GET['tmod'] == 'needsadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/needsadd.php';
}else if($_GET['tmod'] == 'needsedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/needsedit.php';
}else if($_GET['tmod'] == 'newhouses'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/newhouses.php';
}else if($_GET['tmod'] == 'newhousesadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/newhousesadd.php';
}else if($_GET['tmod'] == 'newhousesedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/newhousesedit.php';
}else if($_GET['tmod'] == 'adviser'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/adviser.php';
}else if($_GET['tmod'] == 'adviseradd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/adviseradd.php';
}else if($_GET['tmod'] == 'adviseredit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/adviseredit.php';
}else if($_GET['tmod'] == 'houses'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/houses.php';
}else if($_GET['tmod'] == 'housesadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/housesadd.php';
}else if($_GET['tmod'] == 'housesedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/housesedit.php';
}else if($_GET['tmod'] == 'trade'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/trade.php';
}else if($_GET['tmod'] == 'mendian'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/mendian.php';
}else if($_GET['tmod'] == 'mendianadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/mendianadd.php';
}else if($_GET['tmod'] == 'mendianedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/mendianedit.php';
}else if($_GET['tmod'] == 'viplog'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/viplog.php';
}else if($_GET['tmod'] == 'agent'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/agent.php';
}else if($_GET['tmod'] == 'agentadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/agentadd.php';
}else if($_GET['tmod'] == 'agentedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/agentedit.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/order.php';
}else if($_GET['tmod'] == 'choose_houses'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/choose_houses.php';
}else if($_GET['tmod'] == 'guanzulist'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/guanzulist.php';
}else if($_GET['tmod'] == 'doDaoNewhousesGuanzu'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/doDaoNewhousesGuanzu.php';
}else if($_GET['tmod'] == 'newhouses_guanzulist'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/newhouses_guanzulist.php';
}else if($_GET['tmod'] == 'houses_guanzulist'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/houses_guanzulist.php';
}else if($_GET['tmod'] == 'guanggao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/guanggao.php';
}else if($_GET['tmod'] == 'guanggaoadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/guanggaoadd.php';
}else if($_GET['tmod'] == 'guanggaoedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/guanggaoedit.php';
}else if($_GET['tmod'] == 'jubao'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/jubao.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/focuspic.php';
}else if($_GET['tmod'] == 'focuspicadd'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/focuspicadd.php';
}else if($_GET['tmod'] == 'focuspicedit'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/focuspicedit.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/pcadmin/list.php';
}