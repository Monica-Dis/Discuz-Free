<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$needs_id   = intval($_GET['needs_id'])>0? intval($_GET['needs_id']):0;

$needsInfo  = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($needs_id);

if($needsInfo['status'] == 1 && $needsInfo['shenhe_status'] == 1){
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
}

$userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);

if($needsInfo['area_id'] > 0){
    $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($needsInfo['area_id']);
    $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($needsInfo['street_id']);
}

$content = stripslashes($needsInfo['content']);
$content = str_replace("\r\n","<br/>",$content);
$content = str_replace("\n","<br/>",$content);
$content = str_replace("\r","<br/>",$content);
if($tcfangchanConfig['open_contact_needs_price'] == 1){
    $content = preg_replace("/\d{7}/", '*****', $content);
}

$add_time   = dgmdate($needsInfo['add_time'], 'u','9999','m-d H:i');

$open_wx_map = 0;
if($__IsWeixin == 1 && $tcfangchanConfig['open_wx_map'] == 1){
    $open_wx_map = 1;
}

$baiduMapToName =$userInfo['nickname'];
$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
$baiduMapToName = urlencode($baiduMapToName);
$baiduMapToAddress = $needsInfo['address'];
$baiduMapToAddress = diconv($baiduMapToAddress, CHARSET, 'utf-8');
$baiduMapToAddress = urlencode($baiduMapToAddress);
$baiduMapUrl = "http://api.map.baidu.com/marker?location={$needsInfo['latitude']},{$needsInfo['longitude']}&title={$baiduMapToName}&content={$baiduMapToAddress}&output=html";

$contentTmp = strip_tags($needsInfo['content']);
$contentTmp = str_replace("\r\n","",$contentTmp);
$contentTmp = str_replace("\n","",$contentTmp);
$contentTmp = str_replace("\r","",$contentTmp);
if($tcfangchanConfig['open_contact_needs_price'] == 1){
    $contentTmp = preg_replace("/\d{7}/", '*****', $contentTmp);
}

$title  = cutstr($contentTmp,50,"...");
$desc   = cutstr($contentTmp,100,"...");

$shareTitle = $tcfangchanConfig['needsinfo_share_title'];
$shareTitle = str_replace('{TITLE}', $title, $shareTitle);
$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);

$shareDesc  = $tcfangchanConfig['needsinfo_share_desc'];
$shareDesc = str_replace('{TITLE}', $desc, $shareDesc);
$shareDesc = str_replace('{SITENAME}', $__SitesInfo['name'], $shareDesc);

if(strpos($userInfo['picurl'], 'data/attachment/tomwx') !== false){
    $shareLogo  = $_G['siteurl'].$userInfo['picurl'];
}else if(strpos($userInfo['picurl'], 'uc_server/') !== false){
    $shareLogo  = $_G['siteurl'].$userInfo['picurl'];
}else{
    $shareLogo  = $userInfo['picurl'];
}

$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=needsinfo&needs_id=".$needs_id;

$orderContactInfo = array();
if($__UserInfo['id'] > 0){
    $orderContactInfo   = C::t('#tom_tcfangchan#tom_tcfangchan_order')->fetch_all_list("AND type = 11 AND order_status = 2 AND needs_id = {$needs_id} AND user_id = {$__UserInfo['id']}");
}
$manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);

$pay_price = 0;
$showTelBtn = 1;
if($tcfangchanConfig['open_contact_needs_price'] == 1 && $tcfangchanConfig['contact_needs_price'] > 0){
    $pay_price = $tcfangchanConfig['contact_needs_price'];
    $showTelBtn = 2;
    if($needsInfo['user_id'] == $__UserInfo['id'] || $__UserInfo['editor'] == 1 || (is_array($orderContactInfo) && !empty($orderContactInfo[0])) ){
        $showTelBtn =  1;
    }
}

$payUrl             = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=pay_needs_contact";
$messageUrl         = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=message&act=create&to_user_id=".$needsInfo['user_id'].'&formhash='.FORMHASH;
$ajaxClicksUrl      = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=needs_clicks&needs_id={$needs_id}&formhash={$formhash}";
$ajaxListUrl        = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=needslist&type={$needsInfo['type']}&no_needs_id={$needs_id}&formhash=".$formhash;

$ajaxJubaoUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=fangchan_jubao&jubao_type=2&needs_id={$needs_id}&user_id={$__UserInfo['id']}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:needsinfo");