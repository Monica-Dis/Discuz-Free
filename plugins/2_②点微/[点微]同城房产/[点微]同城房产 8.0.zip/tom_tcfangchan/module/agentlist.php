<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword            = isset($_GET['keyword'])? daddslashes(urldecode($_GET['keyword'])):'';
$mendian_id         = intval($_GET['mendian_id'])>0? intval($_GET['mendian_id']):0;
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):0;

$page               = intval($_GET['page'])>0? intval($_GET['page']):0;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND t.shenhe_status=1 AND t.is_ok=1 ';

if(!empty($sql_in_site_ids)){
    $whereStr.= " AND t.site_id IN({$sql_in_site_ids}) ";
}

if($mendian_id > 0){
    $whereStr.= " AND t.mendian_id = {$mendian_id} ";
}

if($area_id > 0){
    $whereStr.= " AND m.area_id = {$area_id} ";
}

if($street_id > 0){
    $whereStr.= " AND m.street_id = {$street_id} ";
}

$nearby = 0;
$orderByWhere = " ORDER BY t.top_status DESC,t.clicks DESC,t.id DESC";
if($paixu_type == 1){
    $orderByWhere = " ORDER BY t.add_time DESC,t.id DESC";
}

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
$agentList = array();
$agentListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_list($whereStr, $orderByWhere, $start, $pagesize, $keyword);
if(is_array($agentListTmp) && !empty($agentListTmp)){
    foreach ($agentListTmp as $key => $value) {
        $agentList[$key] = $value;

        $avatarTmp = '';
        if(!empty($value['avatar'])){
            if(!preg_match('/^http/', $value['avatar']) ){
                if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                    $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
                }else{
                    $avatarTmp = $value['avatar'];
                }
            }else{
                $avatarTmp = $value['avatar'];
            }
        }

        $wxQrcodeTmp = '';
        if(!empty($value['wx_qrcode'])){
            if(!preg_match('/^http/', $value['wx_qrcode']) ){
                if(strpos($value['wx_qrcode'], 'source/plugin/tom_') === FALSE){
                    $wxQrcodeTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['wx_qrcode'];
                }else{
                    $wxQrcodeTmp = $value['wx_qrcode'];
                }
            }else{
                $wxQrcodeTmp = $value['wx_qrcode'];
            }
        }
        
        $tcfangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$value['user_id']} AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) ");

        $agentList[$key]['avatar']          = $avatarTmp;
        $agentList[$key]['wx_qrcode']       = $wxQrcodeTmp;
        $agentList[$key]['tcfangchanCount'] = $tcfangchanCount;
    }
}

if(is_array($agentList) && !empty($agentList)){
    foreach ($agentList as $key => $val) {
        $outStr .= '<div class="agent-list__item dislay-flex">';
            $outStr .= '<a class="pic" href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=agentinfo&agent_id='.$val['id'].'"><img src="'.$val['avatar'].'"></a>';
            $outStr .= '<a class="content flex"  href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=agentinfo&agent_id='.$val['id'].'">';
                if($val['top_status'] == 1 && $val['top_time'] > TIMESTAMP){
                    $outStr .= '<div class="name"><span class="top">'.lang('plugin/tom_tcfangchan', 'zhiding').'</span>'.$val['name'].'</div>';
                }else{
                    $outStr .= '<div class="name">'.$val['name'].'</div>';
                }
                if(!empty($val['m_name'])){
                    $outStr .= '<div class="location">'.$val['m_name'].'</div>';
                }else{
                    $outStr .= '<div class="location">'.$val['mendian_name'].'</div>';
                }
                $outStr .= '<div class="jointime">'.lang('plugin/tom_tcfangchan', 'agentlist_have_fangchan_1').'<span>'.$val['tcfangchanCount'].'</span>'.lang('plugin/tom_tcfangchan', 'tao').'</div>';
            $outStr .= '</a>';
            $outStr .= '<div class="contact">';
                $outStr .= '<a href="tel:'.$val['tel'].'"><i class="tciconfont tcicon-dianhua"></i></a>';
                if($val['wx_qrcode']){
                    $outStr .= '<i class="tciconfont tcicon-weixin id-show__wxqrcode" data-wxqrcode="'.$val['wx_qrcode'].'"></i>';
                }
            $outStr .= '</div>';
        $outStr .= '</div>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;