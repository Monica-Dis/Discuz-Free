<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword            = isset($_GET['keyword'])? daddslashes(urldecode($_GET['keyword'])):'';
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$min_average_price  = intval($_GET['min_average_price'])>0? intval($_GET['min_average_price']):0;
$max_average_price  = intval($_GET['max_average_price'])>0? intval($_GET['max_average_price']):0;
$house_type         = intval($_GET['house_type'])>0? intval($_GET['house_type']):0;
$sell_status        = intval($_GET['sell_status'])>0? intval($_GET['sell_status']):0;
$tesetags           = isset($_GET['tesetags'])? addslashes($_GET['tesetags']):'';
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):0;
$latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
$longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
$no_newhouses_id    = intval($_GET['no_newhouses_id'])>0? intval($_GET['no_newhouses_id']):0;

$page               = intval($_GET['page'])>0? intval($_GET['page']):0;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = " AND status = 1 ";
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}

if($area_id > 0){
    $whereStr.= " AND area_id = {$area_id} ";
}

if($street_id > 0){
    $whereStr.= " AND street_id = {$street_id} ";
}

if($min_average_price > 0){
    $whereStr.= " AND average_price >= {$min_average_price} ";
}

if($max_average_price > 0){
    $whereStr.= " AND average_price <= {$max_average_price} ";
}

if($sell_status > 0){
    $whereStr.= " AND sell_status = {$sell_status} ";
}

if($no_newhouses_id > 0){
    $whereStr .= " AND id != {$no_newhouses_id} ";
}

if(!empty($tesetags)){
    $teseTagsList = explode(',', $tesetags);
    $teseTagsIdsArr = array();
    if(is_array($teseTagsList) && !empty($teseTagsList)){
        foreach($teseTagsList as $key => $value){
            if(intval($value) > 0){
                $teseTagsIdsArr[] = intval($value);
            }
        }
    }
    
    $teseTagsIdsStr = implode(',', $teseTagsIdsArr);

    $tagListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_tag")->fetch_all_list(" AND config_tag_id IN ({$teseTagsIdsStr}) "," GROUP BY `newhouses_id` ORDER BY id DESC");
    $tagList = array();
    if(is_array($tagListTmp) && !empty($tagListTmp)){
        foreach($tagListTmp as $key => $value){
            
            $configTagIdsArr = array();
            if(!empty($value['config_tag_ids'])){
                $configTagIdsArr = explode(',', $value['config_tag_ids']);
            }
            if(is_array($configTagIdsArr) && !empty($configTagIdsArr)){
                foreach($configTagIdsArr as $k => $v){
                    $tagList[$value['newhouses_id']][] = $v;
                }
            }
        }
    }

    $newhousesIdsArr = array();
    if(is_array($tagList) && !empty($tagList)){
        foreach($tagList as $key => $value){
            $diff = array_diff($teseTagsIdsArr,$value);
            if(empty($diff)){
                $newhousesIdsArr[] = $key;
            }
        }
    }    
    if(is_array($newhousesIdsArr) && !empty($newhousesIdsArr)){
        $newhousesIdsStr = implode(',', $newhousesIdsArr);
        $whereStr.= " AND id IN ({$newhousesIdsStr}) ";
    }else{
        $outStr = '205';
        echo json_encode($outStr); exit;
    }
}

$nearby = 0;
$orderByWhere = "ORDER BY top_status DESC,clicks DESC,id DESC";
if($paixu_type > 0){
    if($paixu_type == 1){
        $nearby = 1;
    }else if($paixu_type == 2){
        $orderByWhere = "ORDER BY top_status DESC,average_price ASC,update_time DESC,id DESC";
    }else if($paixu_type == 3){
        $orderByWhere = "ORDER BY top_status DESC,average_price DESC,update_time DESC,id DESC";
    }else if($paixu_type == 4){
        $orderByWhere = "ORDER BY top_status DESC,start_time ASC,update_time DESC,id DESC";
    }else if($paixu_type == 5){
        $orderByWhere = "ORDER BY top_status DESC,start_time DESC,update_time DESC,id DESC";
    }
}

if(empty($latitude)){
    $latitude = getcookie('tom_tongcheng_user_latitude');
    $longitude = getcookie('tom_tongcheng_user_longitude');
}

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
$newhousesList = array();
if($nearby == 1 && !empty($latitude) && !empty($longitude)){
    $newhousesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_list($whereStr, $orderByWhere, $start, $pagesize, $keyword , $house_type,$latitude,$longitude);
}else{
    $newhousesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_list($whereStr, $orderByWhere, $start, $pagesize, $keyword , $house_type);
}
if(is_array($newhousesListTmp) && !empty($newhousesListTmp)){
    foreach ($newhousesListTmp as $key => $value) {
        $newhousesList[$key] = $value;

        $teseTagsArr = explode('|', trim($value['tese_tags'], '|'));

        $typeList = array();
        if(!empty($value['type'])){
            $typeListTmp = explode('|', trim($value['type'], '|'));
            if(is_array($typeListTmp) && !empty($typeListTmp)){
                foreach ($typeListTmp as $k => $v){
                    if(!empty($v)){
                        $typeList[] = $houseTypeArr[$v];
                    }
                }
            }
        }

        if(!empty($value['vr_link'])){
            $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND newhouses_id = {$value['id']} AND type = 2 ", 'ORDER BY id ASC', 0, 1);
        }else{
            $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND newhouses_id = {$value['id']} AND type = 1 ", 'ORDER BY id ASC', 0, 1);
        }
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }

        $newhousesList[$key]['liulan_status']   = 0;
        if($__UserInfo['id'] > 0){
            $historyInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_history")->fetch_all_list("AND newhouses_id = {$value['id']} AND user_id = {$__UserInfo['id']} AND last_time = {$nowDayTime} ", 'ORDER BY id ASC', 0, 1);
            if(is_array($historyInfoTmp) && !empty($historyInfoTmp[0])){
                $newhousesList[$key]['liulan_status']   = 1;
            }
        }

        $newhousesList[$key]['teseTagsList']    = $teseTagsArr;
        $newhousesList[$key]['typeList']        = $typeList;
        $newhousesList[$key]['picurl']          = $picurlTmp;
    }
}

if(is_array($newhousesList) && !empty($newhousesList)){
    foreach ($newhousesList as $key => $val) {
        $outStr .= '<a class="newhouses-list__item dislay-flex" href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=newhousesinfo&newhouses_id='.$val['id'].'">';
            $outStr .= '<div class="pic">';
                $outStr .= '<div class="pic-hd">';
                    $outStr .= '<img src="'.$val['picurl'].'">';
                    if(!empty($val['vr_link'])){
                        $outStr .= '<span class="vr"><i></i></span>';
                    }
                    if($val['top_status'] == 1 && $val['top_time'] > TIMESTAMP){
                        $outStr .= '<span class="top">'.lang("plugin/tom_tcfangchan", 'top').'</span>';
                    }
                $outStr .= '</div>';
                if($val['liulan_status']  == 1){
                    $outStr .= '<div class="pic-bd">'.lang('plugin/tom_tcfangchan', 'newhouseslist_today_liulan_it').'</div>';
                }
            $outStr .= '</div>';
            $outStr .= '<div class="content">';
                $outStr .= '<div class="name">'.$val['name'].'</div>';
                $outStr .= '<div class="desc">'.$val['sub_title'].'</div>';
                $outStr .= '<div class="weizi clearfix">';
                    if(is_array($val['typeList']) && !empty($val['typeList'])){
                        foreach($val['typeList'] as $k => $v){
                            $outStr .= '<span>'.$v.'</span>';
                        }
                    }
                    $outStr .= '<span>'.$val['area_name'].'</span><span>'.$val['street_name'].'</span>';
                $outStr .= '</div>';
                $outStr .= '<div class="tags clearfix">';
                    if($val['sell_status'] == 1){
                        $outStr .= '<span class="sell_1">'.lang('plugin/tom_tcfangchan', 'newhouseslist_sell_status_1').'</span>';
                    }else if($val['sell_status'] == 2){
                        $outStr .= '<span class="sell_2">'.lang('plugin/tom_tcfangchan', 'newhouseslist_sell_status_2').'</span>';
                    }else if($val['sell_status'] == 3){
                        $outStr .= '<span class="sell_2">'.lang('plugin/tom_tcfangchan', 'newhouseslist_sell_status_3').'</span>';
                    }
                    if(is_array($val['teseTagsList']) && !empty($val['teseTagsList'])){
                        foreach($val['teseTagsList'] as $k => $v){
                            $outStr .= '<span class="tag">'.$v.'</span>';
                        }
                    }
                $outStr .= '</div>';
                $outStr .= '<div class="jianzu">';
                    if($val['average_price'] > 0){
                        $outStr .= '<span class="junjia">'.$val['average_price'].'<span class="unit">'.lang('plugin/tom_tcfangchan', 'list_price_pingmi_unit').'</span></span>';
                    }else{
                        $outStr .= '<span class="junjia">'.lang('plugin/tom_tcfangchan', 'newhouseslist_daiding_price').'</span>';
                    }
                    $outStr .= '<span class="junmianji">'.lang('plugin/tom_tcfangchan', 'newhouseslist_house_mianji').$val['house_total_mianji'].lang('plugin/tom_tcfangchan', 'pingmi').'</span>';
                $outStr .= '</div>';
            $outStr .= '</div>';
        $outStr .= '</a>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;