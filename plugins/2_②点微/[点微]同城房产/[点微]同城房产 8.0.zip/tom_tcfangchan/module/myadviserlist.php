<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$keyword        = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$adviser_id     = intval($_GET['adviser_id'])>0? intval($_GET['adviser_id']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$type           = intval($_GET['type'])>0? intval($_GET['type']):0;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND user_id={$__UserInfo['id']}";

if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND newhouses_name LIKE '%{$keyword}%'";
}
if($adviser_id > 0){
    $where .= " AND id = {$adviser_id}";
}

$order = " ORDER BY id DESC ";
if($type == 1){
    $where.= " AND status = 1 AND shenhe_status = 1 AND ((pay_status = 0 && expire_status = 3) OR (pay_status = 2 && expire_status = 1)) ";
}
if($type == 2){
    $where.= " AND pay_status = 1 ";
}
if($type == 3){
    $where.= " AND (shenhe_status=2 OR shenhe_status=3) ";
    $order = " ORDER BY shenhe_status ASC,id DESC ";
}

$count = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count($where);
$adviserListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_list($where,$order,$start,$pagesize);
$adviserList = array();
if(is_array($adviserListTmp) && !empty($adviserListTmp)){
    foreach ($adviserListTmp as $key => $value){
        $adviserList[$key] = $value;
        
        $newhousesInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($value['newhouses_id']);
        if(!empty($newhousesInfoTmp['vr_link'])){
            $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND newhouses_id = {$value['newhouses_id']} AND type = 2 ", "ORDER BY id ASC", 0, 1);
        }else{
            $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND newhouses_id = {$value['newhouses_id']} AND type = 1 ", "ORDER BY id ASC", 0, 1);
        }
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $avatarTmp = '';
        if(!empty($value['avatar'])){
            if(!preg_match('/^http/', $value['avatar']) ){
                if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                    $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
                }else{
                    $avatarTmp = $value['avatar'];
                }
            }else{
                $avatarTmp = $value['avatar'];
            }
        }

        $adviserList[$key]['avatar']        = $avatarTmp;
        $adviserList[$key]['newhousesInfo'] = $newhousesInfoTmp;
        $adviserList[$key]['newhousesInfo']['picurl'] = $picurlTmp;
        
        if($value['expire_status'] == 1 && $value['expire_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['expire_status']    = 2;
            $updateData['status']           = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->update($value['id'], $updateData);
        }
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myadviserlist&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myadviserlist&type={$type}&page={$nextPage}";

$back_url = $weixinClass->get_url();
$back_url = urlencode($back_url);

$payUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=adviser_pay&back_url={$back_url}&formhash=".$formhash;
$ajaxUpdateStatusUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=updateAdviserStatus&&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=get_myadviserlist_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:myadviserlist");