<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword            = isset($_GET['keyword'])? daddslashes(urldecode($_GET['keyword'])):'';
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):1;
$type               = intval($_GET['type'])>0? intval($_GET['type']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;
$no_needs_id        = intval($_GET['no_needs_id'])>0? intval($_GET['no_needs_id']):0;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$whereStr = ' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if($type > 0){
    $whereStr.= " AND type={$type} ";
}
if($area_id > 0){
    $whereStr.= " AND area_id={$area_id} ";
}
if($street_id > 0){
    $whereStr.= " AND street_id={$street_id} ";
}
if($no_needs_id > 0){
    $whereStr .= " AND id !={$no_needs_id} ";
}

if($paixu_type == 1){
    $orderStr = "ORDER BY top_status DESC,top_time DESC,refresh_time DESC,id DESC";
}elseif($paixu_type == 2){
    $orderStr = " ORDER BY refresh_time DESC,top_status DESC,top_time DESC,id DESC";
}elseif($paixu_type == 3){
    $orderStr = " ORDER BY clicks DESC,top_status DESC,top_time DESC,id DESC";
}

$pagesize       = $pagesize;
$start          = ($page - 1)*$pagesize;

if($paixu_type == 4 && !empty($latitude) && !empty($longitude)){
    $needsListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_nearby_list($whereStr,$start,$pagesize,$latitude,$longitude);
}else{
    $needsListTmp  = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_like_list($whereStr,$orderStr,$start,$pagesize,$keyword);
}

$needsList = array();
foreach ($needsListTmp as $key => $value){
    
    if($tcfangchanConfig['open_contact_needs_price'] == 1){
        $value['content'] = preg_replace("/\d{7}/", '*****', $value['content']);
    }

    $needsList[$key] = $value;

    $userInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $areaInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
    $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
    $needsList[$key]['userInfo']   = $userInfoTmp;
    $needsList[$key]['areaInfo']   = $areaInfoTmp;
    $needsList[$key]['streetInfo'] = $streetInfoTmp;
    $needsList[$key]['link'] = 'plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=needsinfo&needs_id='.$value['id'];

}

if(is_array($needsList) && !empty($needsList)){
    foreach ($needsList as $key => $val){
        $outStr .= '<a href="'.$val['link'].'">';
        $outStr .= '<div class="needs-item">';
            $outStr .= '<div class="needs-item_top dislay-flex">';
                $outStr .= '<div class="needs-item_top_left">';
                    $outStr .= '<img src="'.$val['userInfo']['picurl'].'">';
                $outStr .= '</div>';
                $outStr .= '<div class="needs-item_top_right">';
                    $outStr .= '<div class="needs-xm">';
                        if($val['top_status'] == 1){
                             $outStr.= '<span class="top">'.lang('plugin/tom_tongcheng', 'top').'</span>';
                        }
                        if($val['type'] == 1){
                            $outStr .= '<span class="left">'.lang('plugin/tom_tcfangchan', 'qiugou').'</span>';
                        }elseif($val['type'] == 2){
                            $outStr .= '<span class="left">'.lang('plugin/tom_tcfangchan', 'qiuzu').'</span>';
                        }
                        $outStr .= '<span class="right">'.$val['userInfo']['nickname'].'</span>';
                    $outStr .= '</div>';
                    $outStr .= '<div class="needs-address dislay-flex">';
                        if($val['area_id'] > 0){
                            $outStr .= '<span class="needs-area">'.$val['areaInfo']['name'].$val['streetInfo']['name'].'</span>';
                        }
                        if($val['area_id'] > 0){
                            $outStr .= '<span class="needs-time area">'.dgmdate($val['refresh_time'], 'u','9999','m-d H:i').'</span>';
                        }else{
                            $outStr .= '<span class="needs-time">'.dgmdate($val['refresh_time'], 'u','9999','m-d H:i').'</span>';
                        }
                        if($paixu_type == 4 && !empty($latitude) && !empty($longitude)){
                            $juli = tomGetDistance($longitude, $latitude, $val['longitude'], $val['latitude']);
                            $outStr .= '<span class="needs-time area" style="border-left: 1px solid #9a9a9a;margin-left: 8px;">'.$juli.'km</span>';
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
                $outStr .= '<div class="needs-item_top_tel">';
                    $outStr .= '<span class="needs-tel tc-template__color tc-template__border"><i class="tciconfont tcicon-dianhua"></i> '.lang('plugin/tom_tcfangchan', 'needslist_contact').'</span>';
                $outStr .= '</div>';
            $outStr .= '</div>';
            $outStr .= '<div class="needs-item_content">';
                $outStr .= '<div class="needs-item_content_msg">'.$val['content'].'</div>';
            $outStr .= '</div>';
        $outStr .= '</div>';
        $outStr .= '</a>';
    }
}else{
    $outStr = '205';
}
$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;