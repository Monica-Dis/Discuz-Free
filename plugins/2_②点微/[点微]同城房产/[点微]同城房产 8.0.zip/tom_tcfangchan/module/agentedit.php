<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$s              = intval($_GET['s'])? intval($_GET['s']):0;
$agent_id       = intval($_GET['agent_id'])? intval($_GET['agent_id']):0;
$act            = !empty($_GET['act'])? addslashes($_GET['act']):'';
$back_url       = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_id($agent_id);

$quanxianStatus = 0;
if($agentInfo['id'] > 0 && $agentInfo['user_id'] == $__UserInfo['id']){ 
    $quanxianStatus = 1;
}
$mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_user_id($__UserInfo['id']);
if($mendianInfo['id'] > 0 && $mendianInfo['id'] == $agentInfo['mendian_id']){
    $quanxianStatus = 2;
}
# check start
if($quanxianStatus == 0){
    if($__UserInfo['id'] == $tcfangchanConfig['fcmanage_user_id']){
        $quanxianStatus = 3;
    }else{
        if($__UserInfo['groupid'] == 1){
            $quanxianStatus = 3;
        }else if($__UserInfo['groupid'] == 2){
            if($tcfangchanInfo['site_id'] == $__UserInfo['groupsiteid']){
                $quanxianStatus = 3;
            }
        }
    }
}
# check end
if($quanxianStatus == 0){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");exit;
}

if($act == "save" && submitcheck('name')){

    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $mendian_id             = intval($_GET['mendian_id'])? intval($_GET['mendian_id']):0;

    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name                   = dhtmlspecialchars($name);
    $tel                    = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                    = dhtmlspecialchars($tel);
    $mendian_name           = isset($_GET['mendian_name'])? addslashes($_GET['mendian_name']):'';
    $mendian_name           = dhtmlspecialchars($mendian_name);
    $avatar                 = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $avatar                 = dhtmlspecialchars($avatar);
    $wx_qrcode              = isset($_GET['wx_qrcode'])? addslashes($_GET['wx_qrcode']):'';
    $wx_qrcode              = dhtmlspecialchars($wx_qrcode);
    
    $editMendianId = 0;
    if($agentInfo['mendian_id'] != $mendian_id){
        $editMendianId = 1;
    }
    
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($mendian_id);
    if($quanxianStatus == 1 && $editMendianId == 1){
        if($mendianInfo && $mendianInfo['id'] > 0 && $tcfangchanConfig['open_mendian_vip'] == 1 && $tcfangchanConfig['open_mendian_vip_agent'] == 1){
            $mendian_agent_num_tmp = $tcfangchanConfig['default_mendian_vip_agent_num'];
            if($mendianInfo['vip_id'] > 0 && $mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
                $vipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
                $mendian_agent_num_tmp = intval($vipInfo['agent_num']);
            }
            $agentCount = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_count( " AND mendian_id = {$mendianInfo['id']} ");
            if($agentCount >= $mendian_agent_num_tmp){
                $outArr = array(
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }
        }
    }

    $updateData = array();
    if($quanxianStatus == 1 && $editMendianId == 1){
        if($mendianInfo && $mendianInfo['id'] > 0){
            $updateData['site_id']              = $mendianInfo['site_id'];
            $updateData['mendian_id']           = 0;
            $updateData['mendian_name']         = $mendianInfo['name'];
        }else{
            $updateData['mendian_id']           = 0;
            $updateData['mendian_name']         = $mendian_name;
        }
    }
    $updateData['name']                 = $name;
    $updateData['tel']                  = $tel;
    $updateData['avatar']               = $avatar;
    $updateData['wx_qrcode']            = $wx_qrcode;
    $updateData['is_ok']                = 1;
    if($quanxianStatus == 1 && $editMendianId == 1){
        if($mendianInfo && $mendianInfo['id'] > 0){
            $updateData['mendian_shenhe_status']    = 2;
            $updateData['mendian_shenhe_id']        = $mendianInfo['id'];
        }else{
            $updateData['mendian_shenhe_status']    = 0;
            $updateData['mendian_shenhe_id']        = 0;
        }
    }
    if($agentInfo['shenhe_status'] == 3){
        $updateData['shenhe_status']    = 2;
    }
    $updateData['part1']              = TIMESTAMP;
    if(C::t("#tom_tcfangchan#tom_tcfangchan_agent")->update($agent_id, $updateData)){
        
        if(!empty($tongchengConfig['template_id'])){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            if($quanxianStatus == 1 && $editMendianId == 1){
                if($mendianInfo && $mendianInfo['id'] > 0){
                    $mendianUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($mendianInfo['user_id']);
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($mendianUserInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myagent");
                        $smsData = array(
                            'first'         => lang('plugin/tom_tcfangchan', 'template_ruzhu_agent_shenhe_msg'),
                            'keyword1'      => $tcfangchanConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );

                        @$r = $templateSmsClass->sendSms01($mendianUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                    }
                }
            }
            
        }
    }
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}

$mendian_id     = intval($_GET['mendian_id'])? intval($_GET['mendian_id']):0;
$no_mendian     = intval($_GET['no_mendian'])? intval($_GET['no_mendian']):0;

if($no_mendian == 1){
    $mendian_id = 0;
}else{
    if($agentInfo['mendian_id'] > 0){
        $mendian_id = $agentInfo['mendian_id'];
    }else if($agentInfo['mendian_shenhe_id'] > 0){
        $mendian_id = $agentInfo['mendian_shenhe_id'];
    }
}

$mendianInfo = array();
if($mendian_id > 0){
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($mendian_id);
}

if(!preg_match('/^http/', $agentInfo['avatar']) ){
    if(strpos($agentInfo['avatar'], 'source/plugin/tom_') === FALSE){
        $avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$agentInfo['avatar'];
    }else{
        $avatar = $_G['siteurl'].$agentInfo['avatar'];
    }
}else{
    $avatar = $agentInfo['avatar'];
}

if(!preg_match('/^http/', $agentInfo['wx_qrcode']) ){
    if(strpos($agentInfo['wx_qrcode'], 'source/plugin/tom_') === FALSE){
        $wxQrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$agentInfo['wx_qrcode'];
    }else{
        $wxQrcode = $_G['siteurl'].$agentInfo['wx_qrcode'];
    }
}else{
    $wxQrcode = $agentInfo['wx_qrcode'];
}

$t_back             = $weixinClass->get_url();
$t_back             = preg_replace('/&mendian_id=[0-9]*/', '', $t_back);
$t_back             = preg_replace('/&no_mendian=[0-9]*/', '', $t_back);
$t_back             = preg_replace('/&prand=[0-9]*/', '', $t_back);
$t_back             = urlencode($t_back);
$mendianchooseUrl   = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mendianchoose&t_back={$t_back}";

if(!empty($back_url)){
    $jumpUrl = $back_url;
}else{
    $jumpUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my";
}

$wxUploadUrl = "plugin.php?id=tom_tcfangchan:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$uploadUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=upload&act=photo&formhash={$formhash}&suffix=";
$saveUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=agentedit";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:agentedit");