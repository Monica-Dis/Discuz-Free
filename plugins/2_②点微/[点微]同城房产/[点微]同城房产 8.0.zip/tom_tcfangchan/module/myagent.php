<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$keyword        = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$type           = intval($_GET['type'])>0? intval($_GET['type']):0;

$mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_user_id($__UserInfo['id']);
if(is_array($mendianInfo) && !empty($mendianInfo)){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mymendian");exit;
}

$where = " AND (mendian_id = {$mendianInfo['id']} OR mendian_shenhe_id = {$mendianInfo['id']}) ";

if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND (name LIKE '%{$keyword}%' OR tel LIKE '%{$keyword}%')";
}
if($type == 1){
    $where.= " AND mendian_shenhe_status = 2 ";
}
if($type == 2){
    $where.= " AND mendian_shenhe_status = 1 ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_all_count($where);
$agentListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_agent_list($where,"ORDER BY id DESC" ,$start ,$pagesize);
$agentList = array();
if(is_array($agentListTmp) && !empty($agentListTmp)){
    foreach ($agentListTmp as $key => $value){
        $agentList[$key] = $value;
        
        $ershoufangCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_user_houses_count(" AND user_id = {$value['user_id']} AND model_id = 'ershoufang' AND status=1 AND shenhe_status=1 AND finish = 0 ");
        $chuzuCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_user_houses_count(" AND user_id = {$value['user_id']} AND model_id = 'chuzu' AND status=1 AND shenhe_status=1 AND finish = 0 ");
        $otherCount = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_user_houses_count(" AND user_id = {$value['user_id']} AND model_id IN('shangpu','xiezilou','changfang','cangku','tudi') AND status=1 AND shenhe_status=1 AND finish = 0 ");
        
        if(!preg_match('/^http/', $value['avatar']) ){
            if(strpos($value['avatar'], 'source/plugin/tom_') === FALSE){
                $avatarTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['avatar'];
            }else{
                $avatarTmp = $_G['siteurl'].$value['avatar'];
            }
        }else{
            $avatarTmp = $value['avatar'];
        }
        
        $agentList[$key]['ershoufangCount'] = $ershoufangCount;
        $agentList[$key]['chuzuCount']      = $chuzuCount;
        $agentList[$key]['otherCount']      = $otherCount;
        $agentList[$key]['avatar']          = $avatarTmp;
    }
}
$agentCount = count($agentList);

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myagent&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myagent&type={$type}&page={$nextPage}";

$back_url = $weixinClass->get_url();
$back_url = urlencode($back_url);

$ajaxUpdateShenheStatusUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=updateAgentShenheStatus&formhash=".$formhash;
$ajaxDelAgentStatusUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=delAgentStatus&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=get_myagent_search_url&mendian_id={$mendianInfo['id']}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:myagent");