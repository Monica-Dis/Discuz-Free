<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_user_id($__UserInfo['id']);
if(is_array($mendianInfo) && !empty($mendianInfo)){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");exit;
}

$vipEndStatus = 0;
if($tcfangchanConfig['open_mendian_vip'] == 1 && $mendianInfo['vip_id'] > 0){
    $vipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);

    if(!preg_match('/^http/', $vipInfo['logo']) ){
        if(strpos($vipInfo['logo'], 'source/plugin/tom_') === FALSE){
            $vipLogo = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vipInfo['logo'];
        }else{
            $vipLogo = $_G['siteurl'].$vipInfo['logo'];
        }
    }else{
        $vipLogo = $vipInfo['logo'];
    }
    $vipList[$key]['logo'] = $logoTmp;

    if($tcfangchanConfig['open_mendian_vip_agent'] == 1 && $mendianInfo['vip_id'] > 0){
        if($mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
        }else{
            $agentCountTmp = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_count( " AND mendian_id = {$mendianInfo['id']} ");
            if($agentCountTmp > $tcfangchanConfig['default_mendian_vip_agent_num']){
                $vipEndStatus = 1;
            }
        }
    }
    
    if($mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] < TIMESTAMP){
        DB::query("UPDATE ".DB::table('tom_tcfangchan_mendian')." SET expire_status=0,expire_time=0 WHERE id = {$mendianInfo['id']} ", 'UNBUFFERED');
        $mendianInfo['expire_status'] = 0;
        $mendianInfo['expire_time'] = 0;
    }
}

$photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND mendian_id={$mendianInfo['id']} AND type = 5 "," ORDER BY type DESC,psort ASC,id ASC ",0,1);
$logo_picurl = '';
if(is_array($photoListTmp) && !empty($photoListTmp)){
    $logo_picurl = $photoListTmp[0]['picurlTmp'];
}

$ershoufangCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_agent_houses_count( " AND m.id = {$mendianInfo['id']} AND t.model_id = 'ershoufang' AND t.status=1 AND t.shenhe_status=1 AND t.finish = 0 ");
$chuzuCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_agent_houses_count( " AND m.id = {$mendianInfo['id']} AND t.model_id = 'chuzu' AND t.status=1 AND t.shenhe_status=1 AND t.finish = 0 ");
$otherCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_agent_houses_count( " AND m.id = {$mendianInfo['id']} AND t.model_id IN('shangpu','xiezilou','changfang','cangku','tudi') AND t.status=1 AND t.shenhe_status=1 AND t.finish = 0 ");
$shenheAgentCount = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_count( " AND mendian_id = {$mendianInfo['id']} AND mendian_shenhe_status = 2 ");
$agentCount = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_count( " AND mendian_id = {$mendianInfo['id']} AND shenhe_status = 1 ");

if($mendianInfo['house_num'] != ($ershoufangCount + $chuzuCount + $otherCount) || $mendianInfo['agent_num'] != $agentCount){
    $updateData = array();
    $updateData['house_num']    = $ershoufangCount + $chuzuCount + $otherCount;
    $updateData['agent_num']    = $agentCount;
    C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->update($mendianInfo['id'], $updateData);
}

$ajaxCheckSubscribeUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=check_subscribe&formhash='.$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:mymendian");