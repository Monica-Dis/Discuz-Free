<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
if(is_array($agentInfo) && !empty($agentInfo)){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");exit;
}

$topZhekou = 0;
if($tcfangchanConfig['open_agent_vip'] == 1 && $agentInfo['vip_id'] > 0 && $agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP){
    $agentVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
    if(is_array($agentVipInfo) && !empty($agentVipInfo) && $agentVipInfo['top_zhekou'] > 0){
        $topZhekou = $agentVipInfo['top_zhekou'];
    }
}
$topZhekou = $topZhekou / 100;

$agentTopList = array();
$agent_top_list_str = str_replace("\r\n","{n}",$tcfangchanConfig['agent_top_list']); 
$agent_top_list_str = str_replace("\n","{n}",$agent_top_list_str);
$agent_top_list_arr = explode("{n}", $agent_top_list_str);
if(is_array($agent_top_list_arr) && !empty($agent_top_list_arr)){
    foreach ($agent_top_list_arr as $key => $value){
        $arr = explode("|", $value);;
        
        $agentTopList[$key]['day']      = $arr[0];
        $agentTopList[$key]['price']    = $arr[1];
        $agentTopList[$key]['score']    = 0;
        $agentTopList[$key]['score_pay'] = 0;
        
        if($topZhekou > 0){
            $arr[1] = $arr[1] * $topZhekou;
            $arr[1] = round($arr[1], 2);
            if($arr[1] <= 0){
                $arr[1] = 0.01;
            }
            $agentTopList[$key]['price'] = $arr[1];
        }
        
        if($tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){

            $scorePayNum = intval($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($scorePayNum > 0 && $__UserInfo['score'] >= $scorePayNum){
                $agentTopList[$key]['score'] = $scorePayNum;
                $agentTopList[$key]['score_pay'] = 1;
            }
        }
    }
}

$payTopUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=agent_top_pay&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:agentbuytop");