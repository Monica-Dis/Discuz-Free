<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$adviser_id     = intval($_GET['adviser_id'])>0 ?intval($_GET['adviser_id']):0;
$back_url       = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$adviserInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->fetch_by_id($adviser_id);
if($adviserInfo['id'] > 0 && $adviserInfo['user_id'] == $__UserInfo['id']){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myadviserlist");exit;
}

$newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($adviserInfo['newhouses_id']);

$sale_adviser_price_list_str = str_replace("\r\n","{n}",$newhousesInfo['sale_adviser_price_list']);
$sale_adviser_price_list_str = str_replace("\n","{n}",$sale_adviser_price_list_str);
$sale_adviser_price_list_arr = explode("{n}", $sale_adviser_price_list_str);
$saleAdviserPriceList = array();
if(is_array($sale_adviser_price_list_arr) && !empty($sale_adviser_price_list_arr)){
    foreach($sale_adviser_price_list_arr as $key => $value){
        if(!empty($value)){
            $arrTmp = explode('|', $value);
            $saleAdviserPriceList[$key]['days'] = $arrTmp[0];
            $saleAdviserPriceList[$key]['price'] = $arrTmp[1];
        }
    }
}

$showSaleAdviserXianzhiBtn = 0;
if($adviserInfo['expire_status'] == 2){
    if($tcfangchanConfig['newhouses_sale_adviser_max_num'] > 0){
        $nowTime = TIMESTAMP;
        $adviserCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) ");
        if($adviserCount >= $tcfangchanConfig['newhouses_sale_adviser_max_num']){
            $showSaleAdviserXianzhiBtn = 1;
        }
    }
}

$payXufeiUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=adviser_xufei_pay&back_url=".urlencode($back_url)."&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:adviserbuy");