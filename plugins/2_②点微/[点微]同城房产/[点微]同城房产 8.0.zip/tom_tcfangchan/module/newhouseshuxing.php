<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$newhouses_id = intval($_GET['newhouses_id'])>0? intval($_GET['newhouses_id']):0;
$newhousesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_by_id($newhouses_id);
if(is_array($newhousesInfo) && !empty($newhousesInfo)){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
}

$teseTagsList = array();
if(!empty($newhousesInfo['tese_tags'])){
    $teseTagsList = explode('|', trim($newhousesInfo['tese_tags'], '|'));
}


$photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND newhouses_id={$newhouses_id} AND type IN(1,3) "," ORDER BY type DESC,psort ASC,id ASC ",0,20);
$huxingList = $photoList = array();
$i = 1;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];

        if($value['type'] == 1 && $i == 1){
            $shareLogo = $picurlTmp;
            $i++;
        }

        if($value['type'] == 3){
            $photoList[] = $picurlTmp;
            $huxingList[$key] = $value;
            $huxingList[$key]['picurl'] = $picurlTmp;
        }
    }
}

$photoListStr = implode('|', $photoList);


$guanzuStatus = 0;
if($__UserInfo['id'] > 0){
    $guanzuInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_guanzu")->fetch_all_list(" AND newhouses_id = {$newhouses_id} AND user_id = {$__UserInfo['id']} AND type = 1 ", 'ORDER BY id DESC', 0, 1);
    if(is_array($guanzuInfoTmp) && !empty($guanzuInfoTmp[0])){
        $guanzuStatus = 1;
    }
}

$shareTitle = $newhousesInfo['name'];
$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesinfo&newhouses_id={$newhouses_id}&tjid={$__TjHehuorenId}&s=1";

$ajaxUpdateNewHousesClickUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=update_newhouses_clicks&newhouses_id={$newhouses_id}&formhash={$formhash}";
$ajaxUpdateGuanzuUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=update_newhouses_guanzu&user_id={$__UserInfo['id']}&newhouses_id={$newhouses_id}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:newhouseshuxing");