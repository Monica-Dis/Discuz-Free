<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$model_id       = isset($_GET['model_id'])? addslashes($_GET['model_id']):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND g.user_id={$__UserInfo['id']}";
if(!empty($model_id)){
    $where .= " AND t.model_id='{$model_id}' ";
}
$order = " ORDER BY g.id DESC ";

$count = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_guanzu_count(" {$where} ");
$tcfangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_guanzu_list(" {$where} "," {$order} ",$start,$pagesize);
$tcfangchanList = array();
if(is_array($tcfangchanListTmp) && !empty($tcfangchanListTmp)){
    foreach ($tcfangchanListTmp as $key => $value){
        $tcfangchanList[$key] = $value;
        
        $teseTagsArr = explode('|', trim($value['attr_tese_tags'], '|'));
        
        if(!empty($value['vr_link'])){
            $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id = {$value['id']} AND type = 2 ", "ORDER BY id ASC", 0, 1);
        }else{
            $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id = {$value['id']} AND type = 1 ", "ORDER BY id ASC", 0, 1);
        }
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $fangchanStatus = 1;
        if($value['status'] != 1){
            $fangchanStatus = 2;
        }
        if($value['shenhe_status'] != 1){
            $fangchanStatus = 2;
        }
        if($value['expire_status'] == 2){
            $fangchanStatus = 2;
        }
        if($value['finish'] == 1){
            $fangchanStatus = 3;
        }

        $tcfangchanList[$key]['teseTagsList']   = $teseTagsArr;
        $tcfangchanList[$key]['picurl']         = $picurlTmp;
        $tcfangchanList[$key]['fangchanStatus'] = $fangchanStatus;
        $tcfangchanList[$key]['average_price']  = intval($value['price']/$value['mianji']*10000);
        
        if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value['id'], $updateData);
            update_fangchan_tongcheng($value['id']);
        }

        if($value['expire_status'] == 1 && $value['expire_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['expire_status']    = 2;
            $updateData['expire_time']      = 0;
            $updateData['status']           = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value['id'], $updateData);
            update_fangchan_tongcheng($value['id']);
        }
    }
}
$tcfangchanCount = count($tcfangchanList);

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myguanzufangchan&model_id={$model_id}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myguanzufangchan&model_id={$model_id}&page={$nextPage}";

$md5HostUrl = md5($_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myguanzufangchan");

$ajaxCancelGuanzuUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=cancel_fangchan_guanzu&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:myguanzufangchan");