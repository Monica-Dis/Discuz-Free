<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$tcfangchanIdsListTmp = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_id_list(" AND user_id = {$__UserInfo['id']} ");
$tcfangchanIdsList = array();
if(is_array($tcfangchanIdsListTmp) && !empty($tcfangchanIdsListTmp)){
    foreach($tcfangchanIdsListTmp as $key => $value){
        $tcfangchanIdsList[] = $value['id'];
    }
}

if(is_array($tcfangchanIdsList) && !empty($tcfangchanIdsList)){
    
    $tcfangchanIdStr = implode(',', $tcfangchanIdsList);
    $where = " AND tcfangchan_id IN({$tcfangchanIdStr})";
}else{
    $where = " AND tcfangchan_id = 0";
}

$order = " ORDER BY update_time DESC, id DESC ";

$count = C::t('#tom_tcfangchan#tom_tcfangchan_visitor_log')->fetch_all_count($where);
$visitorLogListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_visitor_log')->fetch_all_list($where,$order,$start,$pagesize);
$visitorLogList = array();
if(is_array($visitorLogListTmp) && !empty($visitorLogListTmp)){
    foreach ($visitorLogListTmp as $key => $value){
        $visitorLogList[$key] = $value;
        
        $tcfangchanInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($value['tcfangchan_id']);
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        
        $fangchanStatus = 1;
        if($tcfangchanInfoTmp['status'] != 1){
            $fangchanStatus = 2;
        }
        if($tcfangchanInfoTmp['shenhe_status'] != 1){
            $fangchanStatus = 2;
        }
        if($tcfangchanInfoTmp['expire_status'] == 2){
            $fangchanStatus = 2;
        }
        if($tcfangchanInfoTmp['finish'] == 1){
            $fangchanStatus = 3;
        }

        $visitorLogList[$key]['tcfangchanInfo'] = $tcfangchanInfoTmp;
        $visitorLogList[$key]['fangchanStatus'] = $fangchanStatus;
        $visitorLogList[$key]['userInfo'] = $userInfoTmp;
    }
}
$visitorLogCount = count($visitorLogList);

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myvisitorlist&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myvisitorlist&page={$nextPage}";

$md5HostUrl = md5($_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myvisitorlist");

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:myvisitorlist");