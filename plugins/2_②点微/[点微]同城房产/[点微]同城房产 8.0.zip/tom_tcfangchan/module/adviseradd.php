<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$newhouses_id   = intval($_GET['newhouses_id'])>0 ? intval($_GET['newhouses_id']):0;
$back_url       = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($newhouses_id);

$adviserInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_list(" AND newhouses_id = {$newhouses_id} AND user_id = {$__UserInfo['id']} ", "ORDER BY id ASC", 0, 1);
if(is_array($adviserInfoTmp) && !empty($adviserInfoTmp)){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myadviserlist&adviser_id={$adviserInfoTmp[0]['id']}");exit;
}

$sale_adviser_price_list_str = str_replace("\r\n","{n}",$newhousesInfo['sale_adviser_price_list']);
$sale_adviser_price_list_str = str_replace("\n","{n}",$sale_adviser_price_list_str);
$sale_adviser_price_list_arr = explode("{n}", $sale_adviser_price_list_str);
$saleAdviserPriceList = array();
if(is_array($sale_adviser_price_list_arr) && !empty($sale_adviser_price_list_arr)){
    foreach($sale_adviser_price_list_arr as $key => $value){
        if(!empty($value)){
            $arrTmp = explode('|', $value);
            $saleAdviserPriceList[$key]['days'] = $arrTmp[0];
            $saleAdviserPriceList[$key]['price'] = $arrTmp[1];
        }
    }
}

$__CommonInfo = C::t('#tom_tcfangchan#tom_tcfangchan_common')->fetch_by_id(1);
if(!$__CommonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_common')->insert($insertData);
}
$xieyi_txt = stripslashes($__CommonInfo['xieyi_txt']);

$showSaleAdviserXianzhiBtn = 0;
if($tcfangchanConfig['newhouses_sale_adviser_max_num'] > 0){
    $nowTime = TIMESTAMP;
    $adviserCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) ");
    if($adviserCount >= $tcfangchanConfig['newhouses_sale_adviser_max_num']){
        $showSaleAdviserXianzhiBtn = 1;
    }
}

$showMustPhoneBtn = 0;
if(empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$wxUploadUrl = "plugin.php?id=tom_tcfangchan:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$uploadUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=upload&act=photo&formhash={$formhash}&suffix=";
$payUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&back_url=".urlencode($back_url);

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:adviseradd");