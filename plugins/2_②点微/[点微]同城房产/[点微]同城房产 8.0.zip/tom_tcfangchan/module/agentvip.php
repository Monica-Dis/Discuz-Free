<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
if(is_array($agentInfo) && !empty($agentInfo)){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
}

$vipListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_all_list(" ", "ORDER BY vsort ASC, id DESC", 0, 100);
$vipList = array();
if(is_array($vipListTmp) && !empty($vipListTmp)){
    foreach($vipListTmp as $key => $value){

        if(!preg_match('/^http/', $value['logo']) ){
            if(strpos($value['logo'], 'source/plugin/tom_') === FALSE){
                $logoTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['logo'];
            }else{
                $logoTmp = $_G['siteurl'].$value['logo'];
            }
        }else{
            $logoTmp = $value['logo'];
        }
        
        $top_zhekou = $value['top_zhekou'] / 10;
        $top_zhekou = trim($top_zhekou, '.0');
        
        $allowBuyVip = 1;
        if($value['max_num'] > 0){
            $userVipCount = C::t("#tom_tcfangchan#tom_tcfangchan_order")->fetch_all_count( " AND user_id = {$__UserInfo['id']} AND agent_vip_id = {$value['id']} AND type = 7 AND order_status = 2 ");
            if($userVipCount >= $value['max_num']){
                $allowBuyVip = 0;
            }
        }
        
        if($value['status'] == 1 && $allowBuyVip == 1){
            $vipList[$key] = $value;
            $vipList[$key]['logo'] = $logoTmp;
            $vipList[$key]['top_zhekou'] = $top_zhekou;
        }
        
        if($agentInfo['vip_id'] > 0 && $agentInfo['vip_id'] == $value['id']){
            $vipInfo = $value;
            $vipInfo['logo'] = $logoTmp;
        }
    }
}

$vipDays = 0 ;
if($vipInfo['id'] > 0 && $agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP){
    $vipDays = $vipInfo['days'];
}

$avatar = '';
if(!preg_match('/^http/', $agentInfo['avatar']) ){
    if(strpos($agentInfo['avatar'], 'source/plugin/tom_') === FALSE){
        $avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$agentInfo['avatar'];
    }else{
        $avatar = $_G['siteurl'].$agentInfo['avatar'];
    }
}else{
    $avatar = $agentInfo['avatar'];
}

$payVipUrl = $_G['siteurl']."plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=vip_agent_pay";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:agentvip");