<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ?intval($_GET['tcfangchan_id']):0;
$back_url       = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($tcfangchan_id);

if($tcfangchanInfo['id'] > 0 && $tcfangchanInfo['user_id'] == $__UserInfo['id']){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
}

$topZhekou = 0;
$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
if($agentInfo['id'] > 0 && $agentInfo['shenhe_status'] == 1){
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);

    if($tcfangchanConfig['open_mendian_vip'] == 1 && $mendianInfo['vip_id'] > 0 && $mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
        $mendianVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
        if(is_array($mendianVipInfo) && !empty($mendianVipInfo) && $mendianVipInfo['top_zhekou'] > 0){
            $topZhekou = $mendianVipInfo['top_zhekou'];
        }
    }

    if($tcfangchanConfig['open_agent_vip'] == 1 && $agentInfo['vip_id'] > 0 && $agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP){
        $agentVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
        if(is_array($agentVipInfo) && !empty($agentVipInfo) && $agentVipInfo['top_zhekou'] > 0){
            if($topZhekou == 0){
                $topZhekou = $agentVipInfo['top_zhekou'];
            }else if($agentVipInfo['top_zhekou'] < $topZhekou){
                $topZhekou = $agentVipInfo['top_zhekou'];
            }
        }
    }
    $topZhekou = $topZhekou / 100;
    
}

$fangchanTopList = array();
$fangchan_top_list_str = str_replace("\r\n","{n}",$tcfangchanConfig['fangchan_top_list']); 
$fangchan_top_list_str = str_replace("\n","{n}",$fangchan_top_list_str);
$fangchan_top_list_arr = explode("{n}", $fangchan_top_list_str);
if(is_array($fangchan_top_list_arr) && !empty($fangchan_top_list_arr)){
    foreach ($fangchan_top_list_arr as $key => $value){
        $arr = explode("|", $value);;
        
        $fangchanTopList[$key]['day'] = $arr[0];
        $fangchanTopList[$key]['price'] = $arr[1];
        $fangchanTopList[$key]['score'] = 0;
        $fangchanTopList[$key]['score_pay'] = 0;
        
        if($topZhekou > 0){
            
            $arr[1] = $arr[1] * $topZhekou;
            $arr[1] = round($arr[1], 2);
            if($arr[1] <= 0){
                $arr[1] = 0.01;
            }
            $fangchanTopList[$key]['price'] = $arr[1];
        }
        
        if($tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){

            $scorePayNum = intval($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($scorePayNum > 0 && $__UserInfo['score'] >= $scorePayNum){
                $fangchanTopList[$key]['score'] = $scorePayNum;
                $fangchanTopList[$key]['score_pay'] = 1;
            }
        }
    }
}

$model_name = '';
if($tcfangchanInfo['model_id'] == 'ershoufang'){
    $model_name = lang('plugin/tom_tcfangchan', 'ershoufang');
    
}else if($tcfangchanInfo['model_id'] == 'chuzu'){
    $model_name = lang('plugin/tom_tcfangchan', 'chuzu');
    
}else if($tcfangchanInfo['model_id'] == 'shangpu'){
    $model_name = lang('plugin/tom_tcfangchan', 'shangpu');
    
}else if($tcfangchanInfo['model_id'] == 'xiezilou'){
    $model_name = lang('plugin/tom_tcfangchan', 'xiezilou');
   
}else if($tcfangchanInfo['model_id'] == 'changfang'){
    $model_name = lang('plugin/tom_tcfangchan', 'changfang');
    
}else if($tcfangchanInfo['model_id'] == 'cangku'){
    $model_name = lang('plugin/tom_tcfangchan', 'cangku');
    
}else if($tcfangchanInfo['model_id'] == 'tudi'){
    $model_name = lang('plugin/tom_tcfangchan', 'tudi');
}

$payTopUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=fangchan_top_pay&back_url=".urlencode($back_url)."&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:buytop");