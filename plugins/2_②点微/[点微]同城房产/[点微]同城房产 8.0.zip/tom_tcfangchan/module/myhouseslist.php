<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$keyword        = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$type           = intval($_GET['type'])>0? intval($_GET['type']):0;

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
if($agentInfo['id'] > 0 && $agentInfo['shenhe_status'] == 1){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");exit;
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND user_id={$__UserInfo['id']}";

$order = " ORDER BY id DESC ";
if($type == 1){
    $where.= " AND status = 1 AND shenhe_status = 1 ";
}
if($type == 2){
    $where.= " AND shenhe_status = 2 ";
}
if($type == 3){
    $where.= " AND (shenhe_status=2 OR shenhe_status=3) ";
    $order = " ORDER BY shenhe_status ASC,id DESC ";
}

$count = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_count($where, $keyword);
$housesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_list($where,$order,$start,$pagesize, $keyword);
$housesList = array();
if(is_array($housesListTmp) && !empty($housesListTmp)){
    foreach ($housesListTmp as $key => $value){
        $housesList[$key] = $value;
        
        $typeList = array();
        if(!empty($value['type'])){
            $typeListTmp = explode('|', trim($value['type'], '|'));
            if(is_array($typeListTmp) && !empty($typeListTmp)){
                foreach ($typeListTmp as $k => $v){
                    if(!empty($v)){
                        $typeList[] = $houseTypeArr[$v];
                    }
                }
            }
        }

        $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND houses_id = {$value['id']} AND type = 1 ", 'ORDER BY id ASC', 0, 1);
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }else{
            $picurlTmp = $tcfangchanConfig['default_houses_photo'];
        }
        
        if($value['open_auto_average'] == 1){
            if(TIMESTAMP > ($value['last_auto_time'] + 7 * 86400)){
                $sanMonthTime = TIMESTAMP - 90 * 86400;
                $totalInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_houses_average_price_sum_list("AND houses_id = {$value['id']} AND model_id = 'ershoufang' AND refresh_time > {$sanMonthTime} AND shenhe_status = 1 AND status = 1 AND finish = 0 AND (pay_status = 0 OR pay_status = 2) ");
                $average_price_tmp = 0;
                if(is_array($totalInfo) && !empty($totalInfo)){
                    $average_price_tmp = ($totalInfo['totalprice'] * 10000)/$totalInfo['totalmanji'];
                    $average_price_tmp = intval($average_price_tmp);
                    $updateData = array();
                    $updateData['average_price'] = $average_price_tmp;
                    $updateData['last_auto_time'] = TIMESTAMP;
                    C::t('#tom_tcfangchan#tom_tcfangchan_houses')->update($value['id'], $updateData);
                }
                $housesList[$key]['average_price'] = $average_price_tmp;
            }
        }

        $housesList[$key]['typeList']   = $typeList;
        $housesList[$key]['picurl']     = $picurlTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myhouseslist&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myhouseslist&type={$type}&page={$nextPage}";

$back_url = $weixinClass->get_url();
$back_url = urlencode($back_url);

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=updateHousesStatus&&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=get_myhouseslist_search_url&model_id={$model_id}&mendian_id={$mendian_id}";


$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:myhouseslist");