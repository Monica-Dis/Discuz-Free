<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$keyword        = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$type           = intval($_GET['type'])>0? intval($_GET['type']):0;

$newhousesManageInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_manage")->fetch_by_user_id($__UserInfo['id']);
if($newhousesManageInfo['id'] > 0){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");exit;
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND user_id={$__UserInfo['id']}";

$order = " ORDER BY id DESC ";
if($type == 1){
    $where.= " AND status = 1 ";
}
if($type == 2){
    $where.= " AND status = 0 ";
}

$count = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_count($where, $keyword);
$newhousesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_list($where,$order,$start,$pagesize, $keyword);
$newhousesList = array();
if(is_array($newhousesListTmp) && !empty($newhousesListTmp)){
    foreach ($newhousesListTmp as $key => $value){
        $newhousesList[$key] = $value;
        
        $teseTagsArr = explode('|', trim($value['tese_tags'], '|'));
        
        $typeList = array();
        if(!empty($value['type'])){
            $typeListTmp = explode('|', trim($value['type'], '|'));
            if(is_array($typeListTmp) && !empty($typeListTmp)){
                foreach ($typeListTmp as $k => $v){
                    if(!empty($v)){
                        $typeList[] = $houseTypeArr[$v];
                    }
                }
            }
        }

        if(!empty($value['vr_link'])){
            $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND newhouses_id = {$value['id']} AND type = 2 ", 'ORDER BY id ASC', 0, 1);
        }else{
            $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND newhouses_id = {$value['id']} AND type = 1 ", 'ORDER BY id ASC', 0, 1);
        }
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }

        $newhousesList[$key]['teseTagsList']    = $teseTagsArr;
        $newhousesList[$key]['typeList']        = $typeList;
        $newhousesList[$key]['picurl']          = $picurlTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mynewhouseslist&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mynewhouseslist&type={$type}&page={$nextPage}";

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=updateNewhousesStatus&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=get_mynewhouseslist_search_url";


$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:mynewhouseslist");