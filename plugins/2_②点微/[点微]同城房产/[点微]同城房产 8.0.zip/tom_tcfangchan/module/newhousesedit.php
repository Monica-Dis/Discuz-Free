<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$newhouses_id   = intval($_GET['newhouses_id'])>0? intval($_GET['newhouses_id']):0;
$act            = !empty($_GET['act'])? addslashes($_GET['act']):'';

$newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($newhouses_id);
$newhousesManageInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_manage")->fetch_by_user_id($__UserInfo['id']);
if($newhousesManageInfo['id'] > 0 && $__UserInfo['id'] == $newhousesInfo['user_id']){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");exit;
}

if($act == "save" && submitcheck('name')){

    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name                   = dhtmlspecialchars($name);
    $sub_title              = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $sub_title              = dhtmlspecialchars($sub_title);
    $type_ids               = isset($_GET['type_ids'])? addslashes($_GET['type_ids']):'';
    $type_ids               = dhtmlspecialchars($type_ids);
    $sell_status            = intval($_GET['sell_status'])>0? intval($_GET['sell_status']):0;
    $start_time             = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time             = str_replace("T", " ", $start_time);
    $start_time             = strtotime($start_time);
    $jiaofang_time          = isset($_GET['jiaofang_time'])? addslashes($_GET['jiaofang_time']):'';
    $jiaofang_time          = str_replace("T", " ", $jiaofang_time);
    $jiaofang_time          = strtotime($jiaofang_time);
    $city_id                = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id                = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $area_name              = isset($_GET['area_name'])? addslashes($_GET['area_name']):'';
    $area_name              = dhtmlspecialchars($area_name);
    $street_id              = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $street_name            = isset($_GET['street_name'])? addslashes($_GET['street_name']):'';
    $street_name            = dhtmlspecialchars($street_name);
    $address                = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address                = dhtmlspecialchars($address);
    $average_price          = intval($_GET['average_price'])>0? intval($_GET['average_price']):0;
    $zhuangxiu_type         = intval($_GET['zhuangxiu_type'])>0? intval($_GET['zhuangxiu_type']):0;
    $chanquan               = intval($_GET['chanquan'])>0? intval($_GET['chanquan']):0;
    $sales_tel              = isset($_GET['sales_tel'])? addslashes($_GET['sales_tel']):'';
    $sales_tel              = dhtmlspecialchars($sales_tel);
    $sales_address          = isset($_GET['sales_address'])? addslashes($_GET['sales_address']):'';
    $sales_address          = dhtmlspecialchars($sales_address);
    $latitude               = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $latitude               = dhtmlspecialchars($latitude);
    $longitude              = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $longitude              = dhtmlspecialchars($longitude);
    $developer_company      = isset($_GET['developer_company'])? addslashes($_GET['developer_company']):'';
    $developer_company      = dhtmlspecialchars($developer_company);
    $parking_space          = intval($_GET['parking_space'])>0? intval($_GET['parking_space']):0;
    $plot_ratio             = floatval($_GET['plot_ratio'])>0? floatval($_GET['plot_ratio']):0.0;
    $greening_rate          = intval($_GET['greening_rate'])>0? intval($_GET['greening_rate']):0;
    $households_num         = intval($_GET['households_num'])>0? intval($_GET['households_num']):0;
    $land_mianji            = intval($_GET['land_mianji'])>0? intval($_GET['land_mianji']):0;
    $house_total_mianji     = intval($_GET['house_total_mianji'])>0? intval($_GET['house_total_mianji']):0;
    $huode_ratio            = intval($_GET['huode_ratio'])>0? intval($_GET['huode_ratio']):0;
    $property_company       = isset($_GET['property_company'])? addslashes($_GET['property_company']):'';
    $property_company       = dhtmlspecialchars($property_company);
    $property_price         = floatval($_GET['property_price'])>0? floatval($_GET['property_price']):0.00;
    $property_tel           = isset($_GET['property_tel'])? addslashes($_GET['property_tel']):'';
    $property_tel           = dhtmlspecialchars($property_tel);
    $content                = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content                = dhtmlspecialchars($content);
    $vr_link                = isset($_GET['vr_link'])? addslashes($_GET['vr_link']):'';
    $vr_link                = dhtmlspecialchars($vr_link);
    $vr_picurl              = isset($_GET['vr_picurl'])? addslashes($_GET['vr_picurl']):'';
    $vr_picurl              = dhtmlspecialchars($vr_picurl);
    
    $teseTagsIdsArr = array();
    if(is_array($_GET['attr_tese_tags']) && !empty($_GET['attr_tese_tags'])){
        foreach($_GET['attr_tese_tags'] as $key => $value){
            if(intval($value) > 0){
                $teseTagsIdsArr[] = intval($value);
            }
        }
    }
    $configTagList = array();
    $attrTeseTagsStr = $attrTeseTagsIdsStr = '';
    if(is_array($teseTagsIdsArr) && !empty($teseTagsIdsArr)){
        $teseTagsIdsCount = count($teseTagsIdsArr);
        $attrTeseTagsIdsStr = implode(',', $teseTagsIdsArr);
        $configTagListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_all_list(" AND id IN({$attrTeseTagsIdsStr}) ", 'ORDER BY tsort ASC,id DESC', 0, $teseTagsIdsCount);
        $configTagNameArr = array();
        if(is_array($configTagListTmp) && !empty($configTagListTmp)){
            foreach($configTagListTmp as $key => $value){
                $configTagList[$key] = $value;
                $configTagNameArr[] = $value['name'];
            }
        }
        
        if(is_array($configTagNameArr) && !empty($configTagNameArr)){
            $attrTeseTagsStr = '|'.implode('|', $configTagNameArr).'|';
        }
    }
    
    $photolist = array();
    if(is_array($_GET['photolist']) && !empty($_GET['photolist'])){
        foreach($_GET['photolist'] as $key => $value){
            if(!empty($value)){
                $photolist[] = addslashes($value);
            }
        }
    }
    
    $typeStr = '';
    if(!empty($type_ids)){
        $typeIdsArr = explode(',', $type_ids);
        $typeArr = array();
        if(is_array($typeIdsArr) && !empty($typeIdsArr)){
            foreach($typeIdsArr as $key => $value){
                $value = intval($value);
                if(!empty($value)){
                    $typeArr[] = $value;
                }
            }
            $typeStr = '|'.implode('|', $typeArr).'|';
        }
    }

    $updateData = array();
    $updateData['name']                 = $name;
    $updateData['sub_title']            = $sub_title;
    $updateData['type']                 = $typeStr;
    $updateData['tese_tags']            = $attrTeseTagsStr;
    $updateData['city_id']              = $city_id;
    $updateData['area_id']              = $area_id;
    $updateData['area_name']            = $area_name;
    $updateData['street_id']            = $street_id;
    $updateData['street_name']          = $street_name;
    $updateData['average_price']        = $average_price;
    $updateData['chanquan']             = $chanquan;
    $updateData['zhuangxiu_type']       = $zhuangxiu_type;
    $updateData['address']              = $address;
    $updateData['latitude']             = $latitude;
    $updateData['longitude']            = $longitude;
    $updateData['sales_tel']            = $sales_tel;
    $updateData['sales_address']        = $sales_address;
    $updateData['developer_company']    = $developer_company;
    $updateData['parking_space']        = $parking_space;
    $updateData['plot_ratio']           = $plot_ratio;
    $updateData['greening_rate']        = $greening_rate;
    $updateData['households_num']       = $households_num;
    $updateData['land_mianji']          = $land_mianji;
    $updateData['house_mianji']         = $house_mianji;
    $updateData['house_total_mianji']   = $house_total_mianji;
    $updateData['huode_ratio']          = $huode_ratio;
    $updateData['property_company']     = $property_company;
    $updateData['property_price']       = $property_price;
    $updateData['property_tel']         = $property_tel;
    if($newhousesInfo['admin_edit'] == 0){
        $updateData['content']              = $content;
    }
    $updateData['vr_link']              = $vr_link;
    $updateData['sell_status']          = $sell_status;
    $updateData['start_time']           = $start_time;
    $updateData['jiaofang_time']        = $jiaofang_time;
    $updateData['update_time']          = TIMESTAMP;
    if(C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->update($newhouses_id, $updateData)){
        
        C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_newhouses_id($newhouses_id);
        C::t("#tom_tcfangchan#tom_tcfangchan_tag")->delete_by_newhouses_id($newhouses_id);

        if(is_array($photolist) && !empty($photolist)){
            foreach($photolist as $key => $value){
                $insertData = array();
                $insertData['newhouses_id']     = $newhouses_id;
                $insertData['type']             = 1;
                $insertData['picurl']           = $value;
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
        }
        if(!empty($vr_picurl)){
            $insertData = array();
            $insertData['newhouses_id']     = $newhouses_id;
            $insertData['type']             = 2;
            $insertData['picurl']           = $vr_picurl;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        
        if(is_array($configTagList) && !empty($configTagList)){
            foreach($configTagList as $key => $value){
                $insertData = array();
                $insertData['newhouses_id']     = $newhouses_id;
                $insertData['config_tag_id']    = $value['id'];
                $insertData['config_tag_ids']   = $attrTeseTagsIdsStr;
                $insertData['name']             = $value['name'];
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_tag")->insert($insertData);
            }
        }
            
        if(!empty($tongchengConfig['template_id'])){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

            $fabuNewhousesSms = str_replace('{NAME}', $__UserInfo['nickname'], lang('plugin/tom_tcfangchan', 'template_edit_newhouses_msg'));
            $fabuNewhousesSms = str_replace('{NEWHOUSES}', $name, $fabuNewhousesSms);
            
            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesinfo&newhouses_id={$newhouses_id}");
                $smsData = array(
                    'first'         => $fabuNewhousesSms,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($fcmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesinfo&newhouses_id={$newhouses_id}");
                $smsData = array(
                    'first'         => $fabuNewhousesSms,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    $outArr = array(
        'status'=> 1,
    );
    echo json_encode($outArr); exit;

}

$photoListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list(" AND newhouses_id={$newhouses_id} AND type IN(1,2) ", 'ORDER BY psort ASC,id ASC', 0, 50);
$photoList = $vrInfo = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];
        if($value['type'] == 1){
            $photoList[$key] = $value;
            $photoList[$key]['picurl_link'] = $picurlTmp;
            
        }else if($value['type'] == 2){
            $vrInfo['picurl'] = $value['picurl'];
            $vrInfo['picurl_link'] = $picurlTmp;
        }
    }
}
$photoCount = count($photoList);

$typeStr = trim($newhousesInfo['type'], '|');
$typeArr = explode('|', $typeStr);
$typeIdsStr = implode(',', $typeArr);

$houseTypeList = $typeNameArr = array();
$i = 0;
if(is_array($houseTypeArr) && !empty($houseTypeArr)){
    foreach ($houseTypeArr as $key => $value){
        
        if(in_array($key, $typeArr)){
            $typeNameArr[] = $value;
        }
        
        $houseTypeList[$i]['value'] = $key;
        $houseTypeList[$i]['title'] = diconv($value,CHARSET,'utf-8');
        $i++;
    }
}
$typeNameStr = implode(',', $typeNameArr);
$houseTypeData = urlencode(json_encode($houseTypeList));

$start_time     = dgmdate($newhousesInfo['start_time'],'Y-m-d H:i:s',$tomSysOffset);
$start_time     = str_replace(" ", "T", $start_time);
$jiaofang_time  = dgmdate($newhousesInfo['jiaofang_time'],'Y-m-d H:i:s',$tomSysOffset);
$jiaofang_time  = str_replace(" ", "T", $jiaofang_time);

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($newhousesInfo['city_id']);
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$teseTagsStr = trim($newhousesInfo['tese_tags'], '|');
$teseTagsArr = explode('|', $teseTagsStr);
$teseTagListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config_tag")->fetch_all_list(" AND model_id = 'newhouses' ", 'ORDER BY tsort ASC,id DESC', 0, 30);
$teseTagList = array();
if(is_array($teseTagListTmp) && !empty($teseTagListTmp)){
    foreach($teseTagListTmp as $key => $value){
        $teseTagList[$value['id']]['name'] = $value['name'];
        if(in_array($value['name'] ,$teseTagsArr)){
            $teseTagList[$value['id']]['checked'] = 1;
        }
    }
}

$jumpUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mynewhouseslist";

$ossBatchUrl = 'plugin.php?id=tom_tcfangchan:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcfangchan:qiniuBatch';
$wxUploadUrl = "plugin.php?id=tom_tcfangchan:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$uploadUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=upload&act=photo&formhash={$formhash}&suffix=";
$saveUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesedit";
    
$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:newhousesedit");