<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$act = !empty($_GET['act'])? addslashes($_GET['act']):'';

$newhousesManageInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_manage")->fetch_by_user_id($__UserInfo['id']);
if($newhousesManageInfo['id'] > 0){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");exit;
}

if($act == "save" && submitcheck('name')){

    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name                   = dhtmlspecialchars($name);
    $sub_title              = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $sub_title              = dhtmlspecialchars($sub_title);
    $type_ids               = isset($_GET['type_ids'])? addslashes($_GET['type_ids']):'';
    $type_ids               = dhtmlspecialchars($type_ids);
    $sell_status            = intval($_GET['sell_status'])>0? intval($_GET['sell_status']):0;
    $start_time             = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time             = str_replace("T", " ", $start_time);
    $start_time             = strtotime($start_time);
    $jiaofang_time          = isset($_GET['jiaofang_time'])? addslashes($_GET['jiaofang_time']):'';
    $jiaofang_time          = str_replace("T", " ", $jiaofang_time);
    $jiaofang_time          = strtotime($jiaofang_time);
    $city_id                = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id                = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $area_name              = isset($_GET['area_name'])? addslashes($_GET['area_name']):'';
    $area_name              = dhtmlspecialchars($area_name);
    $street_id              = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $street_name            = isset($_GET['street_name'])? addslashes($_GET['street_name']):'';
    $street_name            = dhtmlspecialchars($street_name);
    $address                = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address                = dhtmlspecialchars($address);
    $average_price          = intval($_GET['average_price'])>0? intval($_GET['average_price']):0;
    $zhuangxiu_type         = intval($_GET['zhuangxiu_type'])>0? intval($_GET['zhuangxiu_type']):0;
    $chanquan               = intval($_GET['chanquan'])>0? intval($_GET['chanquan']):0;
    $sales_tel              = isset($_GET['sales_tel'])? addslashes($_GET['sales_tel']):'';
    $sales_tel              = dhtmlspecialchars($sales_tel);
    $sales_address          = isset($_GET['sales_address'])? addslashes($_GET['sales_address']):'';
    $sales_address          = dhtmlspecialchars($sales_address);
    $latitude               = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $latitude               = dhtmlspecialchars($latitude);
    $longitude              = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $longitude              = dhtmlspecialchars($longitude);
    $developer_company      = isset($_GET['developer_company'])? addslashes($_GET['developer_company']):'';
    $developer_company      = dhtmlspecialchars($developer_company);
    $parking_space          = intval($_GET['parking_space'])>0? intval($_GET['parking_space']):0;
    $plot_ratio             = floatval($_GET['plot_ratio'])>0? floatval($_GET['plot_ratio']):0.0;
    $greening_rate          = intval($_GET['greening_rate'])>0? intval($_GET['greening_rate']):0;
    $households_num         = intval($_GET['households_num'])>0? intval($_GET['households_num']):0;
    $land_mianji            = intval($_GET['land_mianji'])>0? intval($_GET['land_mianji']):0;
    $house_total_mianji     = intval($_GET['house_total_mianji'])>0? intval($_GET['house_total_mianji']):0;
    $huode_ratio            = intval($_GET['huode_ratio'])>0? intval($_GET['huode_ratio']):0;
    $property_company       = isset($_GET['property_company'])? addslashes($_GET['property_company']):'';
    $property_company       = dhtmlspecialchars($property_company);
    $property_price         = floatval($_GET['property_price'])>0? floatval($_GET['property_price']):0.00;
    $property_tel           = isset($_GET['property_tel'])? addslashes($_GET['property_tel']):'';
    $property_tel           = dhtmlspecialchars($property_tel);
    $content                = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content                = dhtmlspecialchars($content);
    $vr_link                = isset($_GET['vr_link'])? addslashes($_GET['vr_link']):'';
    $vr_link                = dhtmlspecialchars($vr_link);
    $vr_picurl              = isset($_GET['vr_picurl'])? addslashes($_GET['vr_picurl']):'';
    $vr_picurl              = dhtmlspecialchars($vr_picurl);
    
    $teseTagsIdsArr = array();
    if(is_array($_GET['attr_tese_tags']) && !empty($_GET['attr_tese_tags'])){
        foreach($_GET['attr_tese_tags'] as $key => $value){
            if(intval($value) > 0){
                $teseTagsIdsArr[] = intval($value);
            }
        }
    }
    $configTagList = array();
    $attrTeseTagsStr = $attrTeseTagsIdsStr = '';
    if(is_array($teseTagsIdsArr) && !empty($teseTagsIdsArr)){
        $teseTagsIdsCount = count($teseTagsIdsArr);
        $attrTeseTagsIdsStr = implode(',', $teseTagsIdsArr);
        $configTagListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_all_list(" AND id IN({$attrTeseTagsIdsStr}) ", 'ORDER BY tsort ASC,id DESC', 0, $teseTagsIdsCount);
        $configTagNameArr = array();
        if(is_array($configTagListTmp) && !empty($configTagListTmp)){
            foreach($configTagListTmp as $key => $value){
                $configTagList[$key] = $value;
                $configTagNameArr[] = $value['name'];
            }
        }
        
        if(is_array($configTagNameArr) && !empty($configTagNameArr)){
            $attrTeseTagsStr = '|'.implode('|', $configTagNameArr).'|';
        }
    }
    
    $photolist = array();
    if(is_array($_GET['photolist']) && !empty($_GET['photolist'])){
        foreach($_GET['photolist'] as $key => $value){
            if(!empty($value)){
                $photolist[] = addslashes($value);
            }
        }
    }
    
    $typeStr = '';
    if(!empty($type_ids)){
        $typeIdsArr = explode(',', $type_ids);
        $typeArr = array();
        if(is_array($typeIdsArr) && !empty($typeIdsArr)){
            foreach($typeIdsArr as $key => $value){
                $value = intval($value);
                if(!empty($value)){
                    $typeArr[] = $value;
                }
            }
            $typeStr = '|'.implode('|', $typeArr).'|';
        }
    }

    $insertData = array();
    $insertData['site_id']              = $site_id;
    $insertData['user_id']              = $__UserInfo['id'];
    $insertData['name']                 = $name;
    $insertData['sub_title']            = $sub_title;
    $insertData['type']                 = $typeStr;
    $insertData['tese_tags']            = $attrTeseTagsStr;
    $insertData['city_id']              = $city_id;
    $insertData['area_id']              = $area_id;
    $insertData['area_name']            = $area_name;
    $insertData['street_id']            = $street_id;
    $insertData['street_name']          = $street_name;
    $insertData['average_price']        = $average_price;
    $insertData['chanquan']             = $chanquan;
    $insertData['zhuangxiu_type']       = $zhuangxiu_type;
    $insertData['address']              = $address;
    $insertData['latitude']             = $latitude;
    $insertData['longitude']            = $longitude;
    $insertData['sales_tel']            = $sales_tel;
    $insertData['sales_address']        = $sales_address;
    $insertData['developer_company']    = $developer_company;
    $insertData['parking_space']        = $parking_space;
    $insertData['plot_ratio']           = $plot_ratio;
    $insertData['greening_rate']        = $greening_rate;
    $insertData['households_num']       = $households_num;
    $insertData['land_mianji']          = $land_mianji;
    $insertData['house_mianji']         = $house_mianji;
    $insertData['house_total_mianji']   = $house_total_mianji;
    $insertData['huode_ratio']          = $huode_ratio;
    $insertData['property_company']     = $property_company;
    $insertData['property_price']       = $property_price;
    $insertData['property_tel']         = $property_tel;
    $insertData['content']              = $content;
    $insertData['vr_link']              = $vr_link;
    $insertData['sell_status']          = $sell_status;
    $insertData['start_time']           = $start_time;
    $insertData['jiaofang_time']        = $jiaofang_time;
    $insertData['status']               = 1;
    $insertData['admin_edit']           = 0;
    $insertData['update_time']          = TIMESTAMP;
    $insertData['add_time']             = TIMESTAMP;
    if(C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->insert($insertData)){
        
        $newhouses_id = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->insert_id();

        if(is_array($photolist) && !empty($photolist)){
            foreach($photolist as $key => $value){
                $insertData = array();
                $insertData['newhouses_id']     = $newhouses_id;
                $insertData['type']             = 1;
                $insertData['picurl']           = $value;
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
        }
        if(!empty($vr_picurl)){
            $insertData = array();
            $insertData['newhouses_id']     = $newhouses_id;
            $insertData['type']             = 2;
            $insertData['picurl']           = $vr_picurl;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        
        if(is_array($configTagList) && !empty($configTagList)){
            foreach($configTagList as $key => $value){
                $insertData = array();
                $insertData['newhouses_id']     = $newhouses_id;
                $insertData['config_tag_id']    = $value['id'];
                $insertData['config_tag_ids']   = $attrTeseTagsIdsStr;
                $insertData['name']             = $value['name'];
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_tag")->insert($insertData);
            }
        }

        if(!empty($tongchengConfig['template_id'])){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

            $fabuNewhousesSms = str_replace('{NAME}', $__UserInfo['nickname'], lang('plugin/tom_tcfangchan', 'template_fabu_newhouses_msg'));
            $fabuNewhousesSms = str_replace('{NEWHOUSES}', $name, $fabuNewhousesSms);
            
            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesinfo&newhouses_id={$newhouses_id}");
                $smsData = array(
                    'first'         => $fabuNewhousesSms,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($fcmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesinfo&newhouses_id={$newhouses_id}");
                $smsData = array(
                    'first'         => $fabuNewhousesSms,
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    $outArr = array(
        'status'=> 1,
    );
    echo json_encode($outArr); exit;

}

$houseTypeList = array();
$i = 0;
if(is_array($houseTypeArr) && !empty($houseTypeArr)){
    foreach ($houseTypeArr as $key => $value){
        
        $houseTypeList[$i]['value'] = $key;
        $houseTypeList[$i]['title'] = diconv($value,CHARSET,'utf-8');
        $i++;
    }
}
$houseTypeData = urlencode(json_encode($houseTypeList));

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$teseTagListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config_tag")->fetch_all_list(" AND model_id = 'newhouses' ", 'ORDER BY tsort ASC,id DESC', 0, 30);
$teseTagList = array();
if(is_array($teseTagListTmp) && !empty($teseTagListTmp)){
    foreach($teseTagListTmp as $key => $value){
        $teseTagList[$value['id']] = $value['name'];
    }
}

$__CommonInfo = C::t('#tom_tcfangchan#tom_tcfangchan_common')->fetch_by_id(1);
if(!$__CommonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_common')->insert($insertData);
}
$xieyi_txt = stripslashes($__CommonInfo['xieyi_txt']);

$showMustPhoneBtn = 0;
if($tcfangchanConfig['fangchan_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$jumpUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mynewhouseslist";

$ossBatchUrl = 'plugin.php?id=tom_tcfangchan:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcfangchan:qiniuBatch';
$wxUploadUrl = "plugin.php?id=tom_tcfangchan:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$uploadUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=upload&act=photo&formhash={$formhash}&suffix=";
$saveUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesadd";
    
$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:newhousesadd");