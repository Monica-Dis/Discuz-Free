<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = "AND status = 1 AND open_sale_adviser = 1 ";
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND name LIKE '%{$keyword}%'";
}

$order = " ORDER BY id DESC ";

$count = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_count($where);
$newhousesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_all_list($where, $order, $start, $pagesize);
$newhousesList = array();
if(is_array($newhousesListTmp) && !empty($newhousesListTmp)){
    foreach ($newhousesListTmp as $key => $value){
        $newhousesList[$key] = $value;
        
        $teseTagsArr = explode('|', trim($value['tese_tags'], '|'));
        
        $typeList = array();
        if(!empty($value['type'])){
            $typeListTmp = explode('|', trim($value['type'], '|'));
            if(is_array($typeListTmp) && !empty($typeListTmp)){
                foreach ($typeListTmp as $k => $v){
                    if(!empty($v)){
                        $typeList[] = $houseTypeArr[$v];
                    }
                }
            }
        }
        
        if(!empty($value['vr_link'])){
            $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND newhouses_id = {$value['id']} AND type = 2 ", "ORDER BY id ASC", 0, 1);
        }else{
            $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND newhouses_id = {$value['id']} AND type = 1 ", "ORDER BY id ASC", 0, 1);
        }
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $nowTime = TIMESTAMP;
        $ruzhuStatus = 0;
        $adviserInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_list(" AND newhouses_id = {$value['id']} AND user_id = {$__UserInfo['id']} AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) ", "ORDER BY id ASC", 0, 1);
        if(is_array($adviserInfoTmp) && !empty($adviserInfoTmp)){
            $ruzhuStatus = 1;
        }
        $syAdviserNum = 0;
        if($value['sale_adviser_num'] > 0){
            $adviserCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count(" AND newhouses_id = {$value['id']} AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) ");
            $syAdviserNum = $value['sale_adviser_num'] - $adviserCount;
            if($ruzhuStatus == 0 && $syAdviserNum <= 0){
                $ruzhuStatus = 2;
            }
        }else{
            $ruzhuStatus = 2;
        }
        
        $newhousesList[$key]['teseTagsList']    = $teseTagsArr;
        $newhousesList[$key]['typeList']        = $typeList;
        $newhousesList[$key]['picurl']          = $picurlTmp;
        $newhousesList[$key]['ruzhuStatus']     = $ruzhuStatus;
        $newhousesList[$key]['syAdviserNum']    = $syAdviserNum;
        
        if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->update($value['id'], $updateData);
        }
    }
}
$newhousesCount = count($newhousesList);

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=adviserruzhu&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=adviserruzhu&page={$nextPage}";

$showSaleAdviserXianzhiBtn = 0;
if($tcfangchanConfig['newhouses_sale_adviser_max_num'] > 0){
    $nowTime = TIMESTAMP;
    $adviserCount = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND ((pay_status = 0 AND expire_status = 3 ) OR (pay_status = 2 AND expire_status = 1 AND expire_time > {$nowTime})) ");
    if($adviserCount >= $tcfangchanConfig['newhouses_sale_adviser_max_num']){
        $showSaleAdviserXianzhiBtn = 1;
    }
}

$back_url = $weixinClass->get_url();
$back_url = urlencode($back_url);

$ajaxCancelGuanzuUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=cancel_newhouses_guanzu&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=get_myadviserruzhu_search_url";

$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=adviserruzhu";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:adviserruzhu");