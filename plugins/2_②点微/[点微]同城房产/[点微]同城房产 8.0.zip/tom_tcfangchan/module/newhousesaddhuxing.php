<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$act            = !empty($_GET['act'])? addslashes($_GET['act']):'';
$newhouses_id   = intval($_GET['newhouses_id'])>0? intval($_GET['newhouses_id']):0;

$newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($newhouses_id);
$newhousesManageInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_manage")->fetch_by_user_id($__UserInfo['id']);
if($newhousesManageInfo['id'] > 0 && $newhousesInfo['user_id'] == $__UserInfo['id']){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mynewhouseslist");exit;
}

if($act == 'add_huxing' && $_GET['formhash'] == FORMHASH){
    $outStr = '';
     
    $insertData= array();
    $insertData['newhouses_id'] = $newhouses_id;
    $insertData['type']         = 3;
    $insertData['add_time']     = TIMESTAMP;
    C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
    $huxing_id = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert_id();
    
    $outStr = $huxing_id;
    $outStr = diconv($outStr,CHARSET,'utf-8');
    echo json_encode($outStr); exit;

}else if($act == 'del' && $_GET['formhash'] == FORMHASH){
    
    $huxing_id = intval($_GET['huxing_id'])>0? intval($_GET['huxing_id']): 0;
    
    C::t("#tom_tcfangchan#tom_tcfangchan_photo")->delete_by_id($huxing_id);
    echo 200;exit;

}else if($act == "save_huxing" && submitcheck('huxing_id')){

    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $huxing_id              = intval($_GET['huxing_id'])>0? intval($_GET['huxing_id']):0;
    $picurl                 = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $picurl                 = dhtmlspecialchars($picurl);
    $huxing                 = isset($_GET['huxing'])? addslashes($_GET['huxing']):'';
    $huxing                 = dhtmlspecialchars($huxing);
    $mianji                 = floatval($_GET['mianji'])>0? floatval($_GET['mianji']):0.00;
    $psort                  = intval($_GET['psort'])>0? intval($_GET['psort']):0;
    

    $updateData = array();
    $updateData['picurl']               = $picurl;
    $updateData['house_huxing']         = $huxing;
    $updateData['house_mianji']         = $mianji;
    $updateData['psort']                = $psort;
    C::t("#tom_tcfangchan#tom_tcfangchan_photo")->update($huxing_id, $updateData);
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
    
}

$photoListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list(" AND newhouses_id={$newhouses_id} AND type = 3 ", 'ORDER BY psort ASC,id ASC', 0, 50);
$photoList = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];
        $photoList[$key] = $value;
        $photoList[$key]['picurl_link'] = $picurlTmp;
    }
}

$jumpUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mynewhouseslist";

$ossBatchUrl = 'plugin.php?id=tom_tcfangchan:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcfangchan:qiniuBatch';
$wxUploadUrl = "plugin.php?id=tom_tcfangchan:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$uploadUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=upload&act=photo&formhash={$formhash}&suffix=";

$addHuxingUrl = "plugin.php?id=tom_tcfangchan&mod=newhousesaddhuxing&act=add_huxing&newhouses_id={$newhouses_id}&formhash={$formhash}";
$saveHuxingUrl = "plugin.php?id=tom_tcfangchan&mod=newhousesaddhuxing&act=save_huxing&newhouses_id={$newhouses_id}&formhash={$formhash}";
$delHuxingUrl = "plugin.php?id=tom_tcfangchan&mod=newhousesaddhuxing&act=del&newhouses_id={$newhouses_id}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:newhousesaddhuxing");