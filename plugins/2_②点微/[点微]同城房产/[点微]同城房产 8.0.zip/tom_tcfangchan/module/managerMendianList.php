<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    if($__UserInfo['id'] != $tcfangchanConfig['fcmanage_user_id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
    }
}
# check end

if($_GET['act'] == 'shenhe' && submitcheck('mendian_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $mendian_id     = intval($_GET['mendian_id'])>0? intval($_GET['mendian_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0? intval($_GET['shenhe_status']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($mendian_id);
    
    $updateData = array();
    $updateData['shenhe_status'] = $shenhe_status;
    C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendianInfo['id'],$updateData);
    
    update_mendian_tcshop($mendian_id);
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($mendianInfo['user_id']);
    
    if($mendianInfo){
        
        if($shenhe_status == 1){
            $shenhe = str_replace('{NAME}', $mendianInfo['name'], lang('plugin/tom_tcfangchan', 'index_template_mendian_shenhe_ok'));
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=mendianinfo&mendian_id='.$mendianInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }else if($shenhe_status == 3){
            $shenhe = str_replace('{NAME}', $mendianInfo['name'], lang('plugin/tom_tcfangchan', 'index_template_mendian_shenhe_no'));
            $tzShenhe = $shenhe.'<br/><font color="#8e8e8e">'.$content.'</font><br/><a href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=mendianedit&mendian_id='.$mendianInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }
        
        $insertData = array();
        $insertData['user_id']      = $toUser['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    
    $nextSmsTime = $toUser['last_smstp_time'] + 0;
    if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime){
        if($shenhe_status == 1){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$mendianInfo['site_id']}&mod=mendianinfo&mendian_id=".$mendianInfo['id']);
        }else if($shenhe_status == 3){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$mendianInfo['site_id']}&mod=mendianedit&mendian_id=".$mendianInfo['id']);
        }
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcfangchanConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $updateData = array();
            $updateData['last_smstp_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList&keyword=".urlencode(trim($keyword));
    
    echo $url;exit;
    
}else if($_GET['act'] == 'del' && submitcheck('mendian_id')){
    
    $mendian_id = intval($_GET['mendian_id'])>0? intval($_GET['mendian_id']):0;
    $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($mendian_id);
    
    C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->delete_by_id($mendian_id);
    
    $agentList = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_agent_list(" AND mendian_id = {$mendian_id} ");
    
    if(is_array($agentList) && !empty($agentList)){
        foreach($agentList as $key => $value){
            DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET source_type=2 WHERE user_id = {$value['user_id']} ", 'UNBUFFERED');
        }
    }
    C::t('#tom_tcfangchan#tom_tcfangchan_agent')->delete_by_mendian_id($mendian_id);
    C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_mendian_id($mendian_id);
    
    echo 200;exit;

}else if($_GET['act'] == 'shenhe_show'){
    
    $mendian_id     = intval($_GET['mendian_id'])>0? intval($_GET['mendian_id']):0;
    $fromtype       = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage       = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_id($mendian_id);

    $mendian_shenhe_fail_str = str_replace("\r\n","{n}",$tcfangchanConfig['mendian_shenhe_fail_text']); 
    $mendian_shenhe_fail_str = str_replace("\n","{n}",$mendian_shenhe_fail_str);
    $mendianShenheFailArray = explode("{n}", $mendian_shenhe_fail_str);

    $ajaxShenheUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList&act=shenhe&";
    $backUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList&type={$fromtype}&page={$frompage}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:managerMendianShenhe");exit;
    
}

$keyword  = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page  = intval($_GET['page'])>0? intval($_GET['page']):1;
$type  = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = " ";
if($type == 1){
    $where .= " AND shenhe_status=2 ";
}
if($type == 2){
    $where .= " AND shenhe_status=3 ";
}
if($__UserInfo['groupid'] == 2){
    $where .= " AND site_id={$site_id} ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_count($where, $keyword);
$mendianListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_list($where," ORDER BY add_time DESC,id DESC ",$start,$pagesize,$keyword);
$mendianList = array();
foreach ($mendianListTmp as $key => $value) {
    $mendianList[$key] = $value;
    
    $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND mendian_id = {$value['id']} AND type = 5 ", "ORDER BY id ASC", 0, 1);
    $picurlTmp = '';
    if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
        $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
    }

    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    
    $mendianList[$key]['userInfo']           = $userInfoTmp;
    $mendianList[$key]['logoPicurl']         = $picurlTmp;
    
    if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
        $updateData = array();
        $updateData['top_status']   = 0;
        $updateData['top_time']     = 0;
        C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($value['id'], $updateData);
        update_mendian_tcshop($value['id']);
    }

    if($value['expire_status'] == 1 && $value['expire_time'] <= TIMESTAMP){
        $updateData = array();
        $updateData['expire_status']    = 0;
        $updateData['expire_time']      = 0;
        C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($value['id'], $updateData);
        update_mendian_tcshop($value['id']);
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];

$ajaxShenheUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList&act=shenhe&formhash=".$formhash;
$ajaxDelUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList&act=del&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList&act=get_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:managerMendianList");