<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$adviser_id     = intval($_GET['adviser_id'])>0 ? intval($_GET['adviser_id']):0;
$act            = !empty($_GET['act'])? addslashes($_GET['act']):'';
$back_url       = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$adviserInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->fetch_by_id($adviser_id);
if($adviserInfo['user_id'] > 0 && $adviserInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myadviserlist");exit;
}

if($act == "save" && submitcheck('adviser_id')){

    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name                   = dhtmlspecialchars($name);
    $tel                    = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                    = dhtmlspecialchars($tel);
    $sub_desc               = isset($_GET['sub_desc'])? addslashes($_GET['sub_desc']):'';
    $sub_desc               = dhtmlspecialchars($sub_desc);
    $avatar                 = isset($_GET['avatar'])? addslashes($_GET['avatar']):'';
    $avatar                 = dhtmlspecialchars($avatar);
    $wx_qrcode              = isset($_GET['wx_qrcode'])? addslashes($_GET['wx_qrcode']):'';
    $wx_qrcode              = dhtmlspecialchars($wx_qrcode);
    $work_picurl            = isset($_GET['work_picurl'])? addslashes($_GET['work_picurl']):'';
    $work_picurl            = dhtmlspecialchars($work_picurl);

    $updateData = array();
    $updateData['name']                 = $name;  
    $updateData['sub_desc']             = $sub_desc;  
    $updateData['tel']                  = $tel;
    $updateData['avatar']               = $avatar;
    $updateData['work_picurl']          = $work_picurl;
    $updateData['wx_qrcode']            = $wx_qrcode;
    $updateData['shenhe_status']        = 2;
    $updateData['part1']                = TIMESTAMP;
    C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->update($adviser_id, $updateData);
    
    if(!empty($tongchengConfig['template_id'])){
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($manageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
            $smsData = array(
                'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_adviser_shenhe_msg'),
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }

        $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($fcmanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
            $smsData = array(
                'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_adviser_shenhe_msg'),
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}

$newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($adviserInfo['newhouses_id']);

if(!preg_match('/^http/', $adviserInfo['avatar']) ){
    if(strpos($adviserInfo['avatar'], 'source/plugin/tom_') === FALSE){
        $avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$adviserInfo['avatar'];
    }else{
        $avatar = $_G['siteurl'].$adviserInfo['avatar'];
    }
}else{
    $avatar = $adviserInfo['avatar'];
}

if(!preg_match('/^http/', $adviserInfo['wx_qrcode']) ){
    if(strpos($adviserInfo['wx_qrcode'], 'source/plugin/tom_') === FALSE){
        $wx_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$adviserInfo['wx_qrcode'];
    }else{
        $wx_qrcode = $_G['siteurl'].$adviserInfo['wx_qrcode'];
    }
}else{
    $wx_qrcode = $adviserInfo['wx_qrcode'];
}

if(!preg_match('/^http/', $adviserInfo['work_picurl']) ){
    if(strpos($adviserInfo['work_picurl'], 'source/plugin/tom_') === FALSE){
        $work_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$adviserInfo['work_picurl'];
    }else{
        $work_picurl = $_G['siteurl'].$adviserInfo['work_picurl'];
    }
}else{
    $work_picurl = $adviserInfo['work_picurl'];
}

$wxUploadUrl = "plugin.php?id=tom_tcfangchan:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$uploadUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=upload&act=photo&formhash={$formhash}&suffix=";
$saveUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=adviseredit";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:adviseredit");