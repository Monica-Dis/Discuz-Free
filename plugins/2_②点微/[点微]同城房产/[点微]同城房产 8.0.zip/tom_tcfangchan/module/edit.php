<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$tcfangchan_id  = intval($_GET['tcfangchan_id'])? intval($_GET['tcfangchan_id']):0;
$fromlist       = !empty($_GET['fromlist'])? addslashes($_GET['fromlist']):'';
$fromtype       = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
$frompage       = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
$act            = !empty($_GET['act'])? addslashes($_GET['act']):'';
$back_url       = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($tcfangchan_id);

$quanxianStatus = 0;
if($tcfangchanInfo['id'] > 0 && $tcfangchanInfo['user_id'] == $__UserInfo['id']){ 
    $quanxianStatus = 1;
}else{
    $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);
    if($agentInfo['id'] > 0){
        $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
        if($mendianInfo['id'] > 0 && $mendianInfo['user_id'] == $__UserInfo['id']){
            $quanxianStatus = 1;
        }
    }
}

# check start
if($quanxianStatus == 0){
    if($__UserInfo['id'] == $tcfangchanConfig['fcmanage_user_id']){
        $quanxianStatus = 2;
    }else{
        if($__UserInfo['groupid'] == 1){
            $quanxianStatus = 2;
        }else if($__UserInfo['groupid'] == 2){
            if($tcfangchanInfo['site_id'] == $__UserInfo['groupsiteid']){
                $quanxianStatus = 2;
            }
        }
    }
}
# check end

if($quanxianStatus == 0){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
}

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($tcfangchanInfo['user_id']);

if($act == "save" && submitcheck('tcfangchan_id')){

    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $title                  = isset($_GET['title'])? addslashes($_GET['title']):'';
    $title                  = dhtmlspecialchars($title);
    $houses_id              = intval($_GET['houses_id'])>0? intval($_GET['houses_id']):0;
    $houses_name            = isset($_GET['houses_name'])? addslashes($_GET['houses_name']):'';
    $houses_name            = dhtmlspecialchars($houses_name);
    $area_id                = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $area_name              = isset($_GET['area_name'])? addslashes($_GET['area_name']):'';
    $area_name              = dhtmlspecialchars($area_name);
    $street_id              = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $street_name            = isset($_GET['street_name'])? addslashes($_GET['street_name']):'';
    $street_name            = dhtmlspecialchars($street_name);
    $address                = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address                = dhtmlspecialchars($address);
    $latitude               = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $latitude               = dhtmlspecialchars($latitude);
    $longitude              = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $longitude              = dhtmlspecialchars($longitude);
    $trade_id               = intval($_GET['trade_id'])>0? intval($_GET['trade_id']):0;
    $mianji                 = floatval($_GET['mianji'])>0? floatval($_GET['mianji']):0.00;
    $price                  = floatval($_GET['price'])>0? floatval($_GET['price']):0.00;
    $xm                     = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $xm                     = dhtmlspecialchars($xm);
    $tel                    = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                    = dhtmlspecialchars($tel);
    $wx                     = isset($_GET['wx'])? addslashes($_GET['wx']):'';
    $wx                     = dhtmlspecialchars($wx);
    $house_tel              = isset($_GET['house_tel'])? addslashes($_GET['house_tel']):'';
    $house_tel              = dhtmlspecialchars($house_tel);
    $house_no               = isset($_GET['house_no'])? addslashes($_GET['house_no']):'';
    $house_no               = dhtmlspecialchars($house_no);
    $attr_zhuangxiu_type    = intval($_GET['attr_zhuangxiu_type'])>0? intval($_GET['attr_zhuangxiu_type']):0;
    $attr_house_type        = intval($_GET['attr_house_type'])>0? intval($_GET['attr_house_type']):0;
    $attr_chaoxiang_type    = intval($_GET['attr_chaoxiang_type'])>0? intval($_GET['attr_chaoxiang_type']):0;
    $attr_shi               = intval($_GET['attr_shi'])>0? intval($_GET['attr_shi']):0;
    $attr_ting              = intval($_GET['attr_ting'])>0? intval($_GET['attr_ting']):0;
    $attr_wei               = intval($_GET['attr_wei'])>0? intval($_GET['attr_wei']):0;
    $attr_louceng           = intval($_GET['attr_louceng'])>0? intval($_GET['attr_louceng']):0;
    $attr_cengshu           = intval($_GET['attr_cengshu'])>0? intval($_GET['attr_cengshu']):0;
    $attr_chanquan          = intval($_GET['attr_chanquan'])>0? intval($_GET['attr_chanquan']):0;
    $attr_elevator          = intval($_GET['attr_elevator'])>0? intval($_GET['attr_elevator']):0;
    $content                = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content                = dhtmlspecialchars($content);
    $video_url              = isset($_GET['video_url'])? addslashes($_GET['video_url']):'';
    $video_url              = dhtmlspecialchars($video_url);
    $video_pic              = isset($_GET['video_pic'])? addslashes($_GET['video_pic']):'';
    $video_pic              = dhtmlspecialchars($video_pic);
    $vr_link                = isset($_GET['vr_link'])? addslashes($_GET['vr_link']):'';
    $vr_link                = dhtmlspecialchars($vr_link);
    $vr_picurl              = isset($_GET['vr_picurl'])? addslashes($_GET['vr_picurl']):'';
    $vr_picurl              = dhtmlspecialchars($vr_picurl);
    
    $rent                   = intval($_GET['rent'])>0? intval($_GET['rent']):0.00;
    $attr_lease_type        = intval($_GET['attr_lease_type'])>0? intval($_GET['attr_lease_type']):0;
    $attr_rent_type         = intval($_GET['attr_rent_type'])>0? intval($_GET['attr_rent_type']):0;
    $attr_rent_unit         = intval($_GET['attr_rent_unit'])>0? intval($_GET['attr_rent_unit']):1;
    
    $fangchan_nature        = intval($_GET['fangchan_nature'])>0? intval($_GET['fangchan_nature']):0;
    $zhuanrang_price        = floatval($_GET['zhuanrang_price'])>0? floatval($_GET['zhuanrang_price']):0.00;
    $attr_shangpu_type      = intval($_GET['attr_shangpu_type'])>0? intval($_GET['attr_shangpu_type']):0;
    
    if($trade_id > 0){
        $tradeInfo = C::t('#tom_tcfangchan#tom_tcfangchan_trade')->fetch_by_id($trade_id);
    }

    $teseTagsIdsArr = array();
    if(is_array($_GET['attr_tese_tags']) && !empty($_GET['attr_tese_tags'])){
        foreach($_GET['attr_tese_tags'] as $key => $value){
            if(intval($value) > 0){
                $teseTagsIdsArr[] = intval($value);
            }
        }
    }

    $configTagList = array();
    $attrTeseTagsStr = $attrTeseTagsIdsStr = '';
    if(is_array($teseTagsIdsArr) && !empty($teseTagsIdsArr)){
        $teseTagsIdsCount = count($teseTagsIdsArr);
        $attrTeseTagsIdsStr = implode(',', $teseTagsIdsArr);
        $configTagListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_config_tag')->fetch_all_list(" AND id IN({$attrTeseTagsIdsStr}) ", 'ORDER BY tsort ASC,id DESC', 0, $teseTagsIdsCount);
        $configTagNameArr = array();
        if(is_array($configTagListTmp) && !empty($configTagListTmp)){
            foreach($configTagListTmp as $key => $value){
                $configTagList[$key] = $value;
                $configTagNameArr[] = $value['name'];
            }
        }

        if(is_array($configTagNameArr) && !empty($configTagNameArr)){
            $attrTeseTagsStr = '|'.implode('|', $configTagNameArr).'|';
        }
    }

    $attrPeitaoTagsArr = array();
    if(is_array($_GET['attr_peitao_tags']) && !empty($_GET['attr_peitao_tags'])){
        foreach($_GET['attr_peitao_tags'] as $key => $value){
            if(!empty($value)){
                $attrPeitaoTagsArr[] = addslashes($chuzuPeitaoArr[$value]['name']);
            }
        }
    }
    
    $attrPeitaoTagsStr = '';
    if(is_array($attrPeitaoTagsArr) && !empty($attrPeitaoTagsArr)){
        $attrPeitaoTagsStr = '|'.implode('|', $attrPeitaoTagsArr).'|';
    }

    $photolist = array();
    if(is_array($_GET['photolist']) && !empty($_GET['photolist'])){
        foreach($_GET['photolist'] as $key => $value){
            if(!empty($value)){
                $photolist[] = addslashes($value);
            }
        }
    }

    if($houses_id > 0){
        $housesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_by_id($houses_id);
        if(!$housesInfo){
            $outArr = array(
                'status'=> 404,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $checkSafeText = $title.$houses_name.$address.$xm.$content;
    $__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
    if(!empty($__CommonInfo['forbid_word'])){
        $forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
        $forbid_word = str_replace(array("\\*"), array('.*'), $forbid_word);
        $forbid_word = '.*('.$forbid_word.').*';
        $forbid_word = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word).')$/i';
        $contentTmpTmp = $checkSafeText;
        $contentTmpTmp = str_replace("\r\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\r","",$contentTmpTmp);
        if(@preg_match($forbid_word, $contentTmpTmp,$matches)) {
            $i = count($matches)-1;
            $word = '';
            if(isset($matches[$i]) && !empty($matches[$i])){
                $word = diconv($matches[$i],CHARSET,'utf-8');
            }
            if($tongchengConfig['safe_words_do'] == 1){
                $tcfangchanConfig['fangchan_must_shenhe'] = 1;
            }else{
                $outArr = array(
                    'status'=> 505,
                    'word'=> $word,
                );
                echo json_encode($outArr); exit;
            }
        }
    }
    if($__ShowXiaofenlei == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php';
        if($xiaofenleiConfig['open_msgseccheck'] == 1){
            @$s_m_r = wx_msgSecCheck($checkSafeText);
            if($s_m_r['code'] == 100){
                $tcfangchanConfig['fangchan_must_shenhe'] = 1;
            }
            if($s_m_r['code'] == 500){
                $outArr = array(
                    'status'=> 505,
                    'word'=> $s_m_r['word'],
                );
                echo json_encode($outArr); exit;
            }
        }
        $imgseccheck_listArr = unserialize($xiaofenleiConfig['imgseccheck_list']);
        if(array_search('2',$imgseccheck_listArr) !== false && $xiaofenleiConfig['open_imgseccheck'] == 1){
            if(is_array($photolist) && !empty($photolist)){
                foreach ($photolist as $kk => $vv){
                    if(!preg_match('/^http/', $vv['picurl']) ){
                        if(strpos($vv['picurl'], 'source/plugin/tom_') === false){    
                            $check_picurl_tmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                        }else{
                            $check_picurl_tmp = $_G['siteurl'].$vv['picurl'];
                        }
                    }else{
                        $check_picurl_tmp = $vv['picurl'];
                    }
                    @$s_i_r = wx_imgSecCheck($check_picurl_tmp);
                    if($s_i_r['code'] == 500){
                        $tcfangchanConfig['fangchan_must_shenhe'] = 1;
                    }
                }
            }
        }
    }

    $freeShenheStatus = 0;
    if($agentInfo['id'] > 0 && $agentInfo['shenhe_status'] == 1){
        $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
        
        $mendianVipInfo = array();
        if($tcfangchanConfig['open_mendian_vip'] == 1 && $mendianInfo['vip_id'] > 0 && $mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
            $mendianVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
            if(is_array($mendianVipInfo) && !empty($mendianVipInfo)){
                if($mendianVipInfo['free_shenhe'] == 1){
                    $freeShenheStatus = 1;
                }
            }
        }

        $agentVipInfo = array();
        if($tcfangchanConfig['open_agent_vip'] == 1 && $agentInfo['vip_id'] > 0 && $agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP){
            $agentVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
            if(is_array($agentVipInfo) && !empty($agentVipInfo)){
                if($agentVipInfo['free_shenhe'] == 1){
                    $freeShenheStatus = 1;
                }
            }
        }
    }
    
    $searchText = $title.'|++++|'.$house_no.'|++++|'.$houses_name;

    $updateData = array();
    $updateData['title']                = $title;
    if($trade_id > 0 && $tradeInfo['id'] > 0){
        $searchText .= '|++++|'.$tradeInfo['name'];

        $updateData['trade_id']             = $tradeInfo['id'];
        $updateData['trade_name']           = $tradeInfo['name'];
    }else{
        $updateData['trade_id']             = 0;
        $updateData['trade_name']           = '';
    }
    if($houses_id > 0){
        $updateData['city_id']              = $housesInfo['city_id'];
        $updateData['area_id']              = $housesInfo['area_id'];
        $updateData['area_name']            = $housesInfo['area_name'];
        $updateData['street_id']            = $housesInfo['street_id'];
        $updateData['street_name']          = $housesInfo['street_name'];
        $updateData['address']              = $housesInfo['address'];
        $updateData['latitude']             = $housesInfo['latitude'];
        $updateData['longitude']            = $housesInfo['longitude'];
        $updateData['houses_id']            = $housesInfo['id'];
    }else{
        $updateData['area_id']              = $area_id;
        $updateData['area_name']            = $area_name;
        $updateData['street_id']            = $street_id;
        $updateData['street_name']          = $street_name;
        $updateData['address']              = $address;
        $updateData['latitude']             = $latitude;
        $updateData['longitude']            = $longitude;
        $updateData['houses_id']            = 0;
    }
    $updateData['mianji']                   = $mianji;
    
    if($fangchan_nature > 0){
        $updateData['fangchan_nature']      = $fangchan_nature;
        if($fangchan_nature == 1){
            $updateData['rent']                 = $rent;
            $updateData['price']                = 0;
            $updateData['zhuanrang_price']      = 0;
        }else if($fangchan_nature == 2){
            $updateData['price']                = $price;
            $updateData['rent']                 = 0;
            $updateData['zhuanrang_price']      = 0;
        }else if($fangchan_nature == 3){
            $updateData['zhuanrang_price']      = $zhuanrang_price;
            $updateData['price']                = 0;
            $updateData['rent']                 = 0;
        }
    }
    
    if($tcfangchanInfo['model_id'] == 'ershoufang'){
        
        $updateData['houses_name']          = $houses_name;
        $updateData['price']                = $price;
        
    }else if($tcfangchanInfo['model_id'] == 'chuzu'){
        
        $updateData['houses_name']          = $houses_name;
        $updateData['rent']                 = $rent;
        
    }
    
    $updateData['video_url']            = $video_url;
    $updateData['vr_link']              = $vr_link;
    if($agentInfo['id'] > 0){  }else{
        $updateData['xm']                   = $xm;
        $updateData['tel']                  = $tel;
        $updateData['wx']                   = $wx;
    }
    $updateData['house_tel']            = $house_tel;
    $updateData['house_no']             = $house_no;
    $updateData['search_text']          = $searchText;
    $updateData['content']              = $content;
    if($freeShenheStatus == 0 && $tcfangchanConfig['fangchan_must_shenhe'] == 1 && $quanxianStatus == 1){
        $updateData['shenhe_status']              = 2;
    }
    $updateData['part1']                = TIMESTAMP;
    if(C::t("#tom_tcfangchan#tom_tcfangchan")->update($tcfangchan_id, $updateData)){
        C::t("#tom_tcfangchan#tom_tcfangchan_attr")->delete_by_tcfangchan_id($tcfangchan_id);
        C::t("#tom_tcfangchan#tom_tcfangchan_photo")->delete_by_tcfangchan_id($tcfangchan_id);
        C::t("#tom_tcfangchan#tom_tcfangchan_tag")->delete_by_tcfangchan_id($tcfangchan_id);

        $insertData = array();
        $insertData['tcfangchan_id']        = $tcfangchan_id;
        
        if($tcfangchanInfo['model_id'] == 'ershoufang'){
            
            $insertData['attr_zhuangxiu_type']  = $attr_zhuangxiu_type;
            $insertData['attr_house_type']      = $attr_house_type;
            $insertData['attr_chaoxiang_type']  = $attr_chaoxiang_type;
            $insertData['attr_shi']             = $attr_shi;
            $insertData['attr_ting']            = $attr_ting;
            $insertData['attr_wei']             = $attr_wei;
            $insertData['attr_louceng']         = $attr_louceng;
            $insertData['attr_cengshu']         = $attr_cengshu;
            $insertData['attr_chanquan']        = $attr_chanquan;
            $insertData['attr_elevator']        = $attr_elevator;
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;
            
        }else if($tcfangchanInfo['model_id'] == 'chuzu'){
            
            $insertData['attr_zhuangxiu_type']  = $attr_zhuangxiu_type;
            $insertData['attr_house_type']      = $attr_house_type;
            $insertData['attr_chaoxiang_type']  = $attr_chaoxiang_type;
            $insertData['attr_shi']             = $attr_shi;
            $insertData['attr_ting']            = $attr_ting;
            $insertData['attr_wei']             = $attr_wei;
            $insertData['attr_louceng']         = $attr_louceng;
            $insertData['attr_cengshu']         = $attr_cengshu;
            $insertData['attr_lease_type']      = $attr_lease_type;
            $insertData['attr_rent_type']       = $attr_rent_type;
            $insertData['attr_rent_unit']       = $attr_rent_unit;
            $insertData['attr_elevator']        = $attr_elevator;
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;
            $insertData['attr_peitao_tags']     = $attrPeitaoTagsStr;
            
        }else if($tcfangchanInfo['model_id'] == 'shangpu'){
            
            if($fangchan_nature == 1){
                $insertData['attr_rent_type']       = $attr_rent_type;
                $insertData['attr_rent_unit']       = $attr_rent_unit;
            }
            $insertData['attr_shangpu_type']    = $attr_shangpu_type;
            $insertData['attr_louceng']         = $attr_louceng;
            $insertData['attr_cengshu']         = $attr_cengshu;
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;
            
        }else if($tcfangchanInfo['model_id'] == 'xiezilou'){
            
            if($fangchan_nature == 1){
                $insertData['attr_rent_type']       = $attr_rent_type;
                $insertData['attr_rent_unit']       = $attr_rent_unit;
            }
            $insertData['attr_louceng']         = $attr_louceng;
            $insertData['attr_cengshu']         = $attr_cengshu;
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;
            
        }else if($tcfangchanInfo['model_id'] == 'changfang'){
            
            if($fangchan_nature == 1){
                $insertData['attr_rent_type']       = $attr_rent_type;
                $insertData['attr_rent_unit']       = $attr_rent_unit;
            }
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;
            
            if($fangchan_nature == 1){
                $insertData['attr_rent_type']       = $attr_rent_type;
                $insertData['attr_rent_unit']       = $attr_rent_unit;
            }
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;
            
        }else if($tcfangchanInfo['model_id'] == 'tudi'){
            
            if($fangchan_nature == 1){
                $insertData['attr_rent_type']       = $attr_rent_type;
                $insertData['attr_rent_unit']       = $attr_rent_unit;
            }
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;
            
        }else if($tcfangchanInfo['model_id'] == 'cangku'){
            
            if($fangchan_nature == 1){
                $insertData['attr_rent_type']       = $attr_rent_type;
                $insertData['attr_rent_unit']       = $attr_rent_unit;
            }
            $insertData['attr_tese_tags']       = $attrTeseTagsStr;
            
        }
        
        $insertData['attr_time']            = TIMESTAMP;
        C::t("#tom_tcfangchan#tom_tcfangchan_attr")->insert($insertData);

        if(is_array($photolist) && !empty($photolist)){
            foreach($photolist as $key => $value){
                $insertData = array();
                $insertData['tcfangchan_id']    = $tcfangchan_id;
                $insertData['type']             = 1;
                $insertData['picurl']           = $value;
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
        }

        if(is_array($configTagList) && !empty($configTagList)){
            foreach($configTagList as $key => $value){
                $insertData = array();
                $insertData['tcfangchan_id']    = $tcfangchan_id;
                $insertData['config_tag_id']    = $value['id'];
                $insertData['config_tag_ids']   = $attrTeseTagsIdsStr;
                $insertData['name']             = $value['name'];
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_tag")->insert($insertData);
            }
        }

        if(!empty($vr_picurl)){
            $insertData = array();
            $insertData['tcfangchan_id']    = $tcfangchan_id;
            $insertData['type']             = 2;
            $insertData['picurl']           = $vr_picurl;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        if(!empty($video_pic)){
            $insertData = array();
            $insertData['tcfangchan_id']    = $tcfangchan_id;
            $insertData['type']             = 4;
            $insertData['picurl']           = $video_pic;
            $insertData['oss_picurl']       = $video_pic;
            $insertData['oss_status']       = 1;
            $insertData['qiniu_picurl']     = $video_pic;
            $insertData['qiniu_status']     = 1;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }

        update_fangchan_tongcheng($tcfangchan_id);

        if(!empty($tongchengConfig['template_id']) && $tcfangchanConfig['fangchan_must_shenhe'] == 1 && $quanxianStatus == 1 && $freeShenheStatus == 0){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_fangchan_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($fcmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_fangchan_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    $outArr = array(
        'status'=> 1,
    );
    echo json_encode($outArr); exit;

}

$attrInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_attr")->fetch_all_list(" AND tcfangchan_id={$tcfangchan_id} ", 'ORDER BY attr_id DESC', 0, 1);
$attrInfo = array();
if(is_array($attrInfoTmp) && !empty($attrInfoTmp[0])){
    $attrInfo = $attrInfoTmp[0];
}

$teseTagListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config_tag")->fetch_all_list(" AND model_id = '{$tcfangchanInfo['model_id']}' ", 'ORDER BY tsort ASC,id DESC', 0, 30);
$teseTagList = array();
if(is_array($teseTagListTmp) && !empty($teseTagListTmp)){
    foreach($teseTagListTmp as $key => $value){
        $teseTagList[$value['id']] = $value['name'];
    }
}

$teseStr = trim($attrInfo['attr_tese_tags'], '|');
$teseArr = explode('|', $teseStr);
$teseTypeList = array();
if(is_array($teseTagList) && !empty($teseTagList)){
    foreach($teseTagList as $key => $value){
        $teseTypeList[$key]['name'] = $value;
        if(in_array($value ,$teseArr)){
            $teseTypeList[$key]['checked'] = 1;
        }
    }
}

$photoListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list(" AND tcfangchan_id={$tcfangchan_id} ", 'ORDER BY psort ASC,id ASC', 0, 50);
$photoList = array();
$vrInfo = array();
$video_pic = '';
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];
        
        if($value['type'] == 1){
            $photoList[$key] = $value;
            $photoList[$key]['picurl_link'] = $picurlTmp;
            
        }else if($value['type'] == 2){
            $vrInfo['picurl'] = $value['picurl'];
            $vrInfo['picurl_link'] = $picurlTmp;
        }else if($value['type'] == 4){
            $video_pic = $value['picurl'];
        }
    }
}
$photoCount = count($photoList);

$housesListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_houses")->fetch_all_name(" AND status = 1 AND site_id IN({$sql_in_site_ids}) ", 'ORDER BY id DESC');
$housesList = $housesArr = array();
$i = 0;
if(is_array($housesListTmp) && !empty($housesListTmp)){
    foreach($housesListTmp as $key => $value){
        $housesList[$key] = $value;
        
        $housesArr[$i]['id'] = $value['id'];
        $housesArr[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $i++;
    }
}
$housesData = urlencode(json_encode($housesArr));

$tradeListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_trade")->fetch_all_list(" AND site_id IN({$sql_in_site_ids}) ", 'ORDER BY tsort ASC,id DESC');
$tradeList = array();
if(is_array($tradeListTmp) && !empty($tradeListTmp)){
    foreach($tradeListTmp as $key => $value){
        $tradeList[$key] = $value;
    }
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($tcfangchanInfo['city_id']);
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

if($fromlist == 'managerList'){
    $jumpUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList&type={$fromtype}&page={$frompage}";
}else{
    $jumpUrl = $back_url;
}
$ossBatchUrl = 'plugin.php?id=tom_tcfangchan:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcfangchan:qiniuBatch';
$wxUploadUrl = "plugin.php?id=tom_tcfangchan:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$uploadUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=upload&act=photo&formhash={$formhash}&suffix=";
$ajaxLoadHousesListUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=load_houseslist&formhash=".$formhash;
$saveUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=edit";

if($tcfangchanInfo['model_id'] == 'ershoufang'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:edit/ershoufang");
    
}else if($tcfangchanInfo['model_id'] == 'chuzu'){
    
    
    $chuzuPeitaoStr = trim($attrInfo['attr_peitao_tags'], '|');
    $chuzuPeitaoArray = explode('|', $chuzuPeitaoStr);
    $chuzuPeitaoList = array();
    if(is_array($chuzuPeitaoArr) && !empty($chuzuPeitaoArr)){
        foreach($chuzuPeitaoArr as $key => $value){
            $chuzuPeitaoList[$key]['name'] = $value['name'];
            if(in_array($value['name'] ,$chuzuPeitaoArray)){
                $chuzuPeitaoList[$key]['checked'] = 1;
            }
        }
    }
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:edit/chuzu");
    
}else if($tcfangchanInfo['model_id'] == 'shangpu'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:edit/shangpu");
    
}else if($tcfangchanInfo['model_id'] == 'xiezilou'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:edit/xiezilou");
    
}else if($tcfangchanInfo['model_id'] == 'changfang'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:edit/changfang");
    
}else if($tcfangchanInfo['model_id'] == 'cangku'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:edit/cangku");
    
}else if($tcfangchanInfo['model_id'] == 'tudi'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:edit/tudi");
    
}else{
    
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
    
}