<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$s = intval($_GET['s'])>0 ? intval($_GET['s']):0;

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
$vipEndStatus = $openVisitorStatus = 0;
$mendianInfo = array();
if($agentInfo['id'] > 0){
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
    if(!preg_match('/^http/', $agentInfo['avatar']) ){
        if(strpos($agentInfo['avatar'], 'source/plugin/tom_') === FALSE){
            $avatar = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$agentInfo['avatar'];
        }else{
            $avatar = $_G['siteurl'].$agentInfo['avatar'];
        }
    }else{
        $avatar = $agentInfo['avatar'];
    }
    
    if($tcfangchanConfig['open_agent_vip'] == 1 && $agentInfo['vip_id'] > 0){
        $agentVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
        if($agentVipInfo['open_visitor'] == 1){
            $openVisitorStatus = 1;
        }
    }
    
    if($tcfangchanConfig['open_mendian_vip'] == 1 && $mendianInfo['id'] > 0 && $mendianInfo['vip_id'] > 0){
        $vipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
        if($vipInfo['open_visitor'] == 1){
            $openVisitorStatus = 1;
        }
        
        if($tcfangchanConfig['open_mendian_vip_agent'] == 1 && $mendianInfo['user_id'] == $__UserInfo['id']){
            if($mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
            }else{
                $agentCount = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_count( " AND mendian_id = {$mendianInfo['id']} ");
                if($agentCount > $tcfangchanConfig['default_mendian_vip_agent_num']){
                    $vipEndStatus = 1;
                }
            }
        }
    }
    
    if($openVisitorStatus == 1){
        
        $tcfangchanIdsArrTmp =  C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_id_list("AND user_id = {$__UserInfo['id']}");
        $tcfangchanIdsArr = array();
        if(is_array($tcfangchanIdsArrTmp) && !empty($tcfangchanIdsArrTmp)){
            foreach($tcfangchanIdsArrTmp as $key => $value){
                $tcfangchanIdsArr[] = $value['id'];
            }
        }
        
        $visitorCount = 0;
        if(is_array($tcfangchanIdsArr) && !empty($tcfangchanIdsArr)){
            $tcfangchanIdsStr = implode(',', $tcfangchanIdsArr);
            $visitorCount = C::t("#tom_tcfangchan#tom_tcfangchan_visitor_log")->fetch_all_count(" AND tcfangchan_id IN({$tcfangchanIdsStr}) ");
        }
    }
}

$fangchanGuanzuCount = C::t("#tom_tcfangchan#tom_tcfangchan_guanzu")->fetch_all_count(" AND user_id = {$__UserInfo['id']} ");
$newhousesGuanzuCount = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_guanzu")->fetch_all_count(" AND user_id = {$__UserInfo['id']} ");
$housesGuanzuCount = C::t("#tom_tcfangchan#tom_tcfangchan_houses_guanzu")->fetch_all_count(" AND user_id = {$__UserInfo['id']} ");

$ershoufangCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'ershoufang' AND deleted = 0 ");
$chuzuCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'chuzu' AND deleted = 0 ");
$shangpuCount  = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'shangpu' AND deleted = 0 ");
$xiezilouCount  = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'xiezilou' AND deleted = 0 ");
$changfangCount  = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'changfang' AND deleted = 0 ");
$cangkuCount  = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'cangku' AND deleted = 0 ");
$tudiCount  = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_user_houses_count(" AND user_id = {$__UserInfo['id']} AND model_id = 'tudi' AND deleted = 0 ");
$qiugouCount  = C::t("#tom_tcfangchan#tom_tcfangchan_needs")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND type = 1 ");
$qiuzuCount   = C::t("#tom_tcfangchan#tom_tcfangchan_needs")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND type = 2 ");

$showNewhousesManage = 0;
$newhousesManageInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_manage")->fetch_by_user_id($__UserInfo['id']);
if(is_array($newhousesManageInfo) && !empty($newhousesManageInfo)){
    $showNewhousesManage = 1;
}

$kefuQrcodeSrc = $tongchengConfig['kefu_qrcode'];
if($__SitesInfo['id'] > 1){
    if(!preg_match('/^http/', $__SitesInfo['kefu_qrcode'])){
        if(strpos($__SitesInfo['kefu_qrcode'], 'source/plugin/tom_tongcheng/') === FALSE){
            $kefuQrcodeSrc = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$__SitesInfo['kefu_qrcode'];
        }else{
            $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
        }
    }else{
        $kefuQrcodeSrc = $__SitesInfo['kefu_qrcode'];
    }
}

$tcfangchanConfig['kefu_qrcode'] = trim($tcfangchanConfig['kefu_qrcode']);
if(!empty($tcfangchanConfig['kefu_qrcode'])){
    $kefuQrcodeSrc = $tcfangchanConfig['kefu_qrcode'];
}

$phone_back_url = $weixinClass->get_url();
$phone_back_url = urlencode($phone_back_url);
$phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";

$fcpc_url = '';
if($__ShowFcpc == 1){
    $fcpc_url = $_G['siteurl']."plugin.php?id=tom_fcpc:zj";
    $fcpcConfig['fangchan_hosts']    = trim($fcpcConfig['fangchan_hosts']);
    if(!empty($fcpcConfig['fangchan_hosts'])){
        $fcpc_url = $fcpcConfig['fangchan_hosts']."plugin.php?id=tom_fcpc:zj";
    }
}

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my&tjid={$__TjHehuorenId}&s=1";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:my");