<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword            = isset($_GET['keyword'])? daddslashes(urldecode($_GET['keyword'])):'';
$model_id           = isset($_GET['model_id'])? addslashes($_GET['model_id']):'';
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$houses_min_price   = intval($_GET['houses_min_price'])>0? intval($_GET['houses_min_price']):0;
$houses_max_price   = intval($_GET['houses_max_price'])>0? intval($_GET['houses_max_price']):0;
$house_type         = intval($_GET['house_type'])>0? intval($_GET['house_type']):0;
$shi                = intval($_GET['shi'])>0? intval($_GET['shi']):0;
$source_type        = intval($_GET['source_type'])>0? intval($_GET['source_type']):0;
$min_mianji         = intval($_GET['min_mianji'])>0? intval($_GET['min_mianji']):0;
$max_mianji         = intval($_GET['max_mianji'])>0? intval($_GET['max_mianji']):0;
$chaoxiang_type     = intval($_GET['chaoxiang_type'])>0? intval($_GET['chaoxiang_type']):0;
$tesetags           = isset($_GET['tesetags'])? addslashes($_GET['tesetags']):'';
$zhuangxiu_type     = intval($_GET['zhuangxiu_type'])>0? intval($_GET['zhuangxiu_type']):0;
$elevator           = intval($_GET['elevator'])>0? intval($_GET['elevator']):0;
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):0;

$min_rent           = intval($_GET['min_rent'])>0? intval($_GET['min_rent']):0;
$max_rent           = intval($_GET['max_rent'])>0? intval($_GET['max_rent']):0;
$lease              = intval($_GET['lease'])>0? intval($_GET['lease']):0;
$rent_type          = intval($_GET['rent_type'])>0? intval($_GET['rent_type']):0;

$fangchan_nature    = intval($_GET['fangchan_nature'])>0? intval($_GET['fangchan_nature']):0;
$houses_id          = intval($_GET['houses_id'])>0? intval($_GET['houses_id']):0;
$user_id            = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;

$mendian_id         = intval($_GET['mendian_id'])>0? intval($_GET['mendian_id']):0;
$no_tcfangchan_id   = intval($_GET['no_tcfangchan_id'])>0? intval($_GET['no_tcfangchan_id']):0;
$latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
$longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';

$page               = intval($_GET['page'])>0? intval($_GET['page']):0;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND status=1 AND shenhe_status=1 AND ((pay_status = 0) OR (pay_status = 2)) ';
if($tcfangchanConfig['open_finish_ok_fangchan'] == 1){
}else{
    $whereStr .= ' AND finish = 0 ';
}
if(!empty($sql_in_site_ids)){
    $whereStr .= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($model_id)){
    $whereStr .= " AND model_id = '{$model_id}' ";
}
if($area_id > 0){
    $whereStr .= " AND area_id={$area_id} ";
}
if($street_id > 0){
    $whereStr .= " AND street_id={$street_id} ";
}
if($houses_min_price > 0){
    $whereStr .= " AND price>={$houses_min_price} ";
}
if($houses_max_price > 0){
    $whereStr .= " AND price<={$houses_max_price} ";
}
if($source_type > 0){
    $whereStr .= " AND source_type ={$source_type} ";
}
if($min_mianji > 0){
    $whereStr .= " AND mianji >={$min_mianji} ";
}
if($max_mianji > 0){
    $whereStr .= " AND mianji <={$max_mianji} ";
}
if($min_rent > 0){
    $whereStr .= " AND rent>={$min_rent} ";
}
if($max_rent > 0){
    $whereStr .= " AND rent<={$max_rent} ";
}

if($fangchan_nature > 0){
    $whereStr .= " AND fangchan_nature ={$fangchan_nature} ";
}

if($houses_id > 0){
    $whereStr .= " AND houses_id ={$houses_id} ";
}

if($user_id > 0){
    $whereStr .= " AND user_id ={$user_id} ";
}

if($no_tcfangchan_id > 0){
    $whereStr .= " AND id !={$no_tcfangchan_id} ";
}


$attrWhereStr = '';
if($house_type > 0){
    $attrWhereStr .= " AND attr_house_type ={$house_type} ";
}
if($shi > 0){
    if($shi == 99){
        $attrWhereStr .= " AND attr_shi > 5 ";
    }else{
        $attrWhereStr .= " AND attr_shi ={$shi} ";
    }
}
if($chaoxiang_type > 0){
    $attrWhereStr .= " AND attr_chaoxiang_type ={$chaoxiang_type} ";
}
if($zhuangxiu_type > 0){
    $attrWhereStr .= " AND attr_zhuangxiu_type ={$zhuangxiu_type} ";
}
if($elevator > 0){
    $attrWhereStr .= " AND attr_elevator ={$elevator} ";
}
if($lease > 0){
    $attrWhereStr .= " AND attr_lease_type ={$lease} ";
}
if($rent_type > 0){
    $attrWhereStr .= " AND attr_rent_type ={$rent_type} ";
}

$tcfangchanIdsList = array();
if(!empty($attrWhereStr)){
    $tcfangchanIdsListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_attr")->fetch_all_tcfangchan_id($attrWhereStr,"ORDER BY attr_id DESC");
    
    $tcfangchanIdsArr = array();
    if(is_array($tcfangchanIdsListTmp) && !empty($tcfangchanIdsListTmp)){
        foreach($tcfangchanIdsListTmp as $key => $value){
            $tcfangchanIdsArr[$value['tcfangchan_id']] = $value['tcfangchan_id'];
        }
    }
    
    if(is_array($tcfangchanIdsArr) && !empty($tcfangchanIdsArr)){
        $tcfangchanIdsList = $tcfangchanIdsArr;
    }else{
        $outStr = '205';
        echo json_encode($outStr); exit;
    }
}

if(!empty($tesetags)){
    $teseTagsList = explode(',', $tesetags);
    $teseTagsIdsArr = array();
    if(is_array($teseTagsList) && !empty($teseTagsList)){
        foreach($teseTagsList as $key => $value){
            if(intval($value) > 0){
                $teseTagsIdsArr[] = intval($value);
            }
        }
    }
    
    $teseTagsIdsStr = implode(',', $teseTagsIdsArr);
    
    $tagListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_tag")->fetch_all_list(" AND config_tag_id IN ({$teseTagsIdsStr}) "," GROUP BY `tcfangchan_id` ORDER BY id DESC");
    $tagList = array();
    if(is_array($tagListTmp) && !empty($tagListTmp)){
        foreach($tagListTmp as $key => $value){
            
            $configTagIdsArr = array();
            if(!empty($value['config_tag_ids'])){
                $configTagIdsArr = explode(',', $value['config_tag_ids']);
            }
            if(is_array($configTagIdsArr) && !empty($configTagIdsArr)){
                foreach($configTagIdsArr as $k => $v){
                    $tagList[$value['tcfangchan_id']][] = $v;
                }
            }
        }
    }
    
    $tcfangchanIdsArr = array();
    if(is_array($tagList) && !empty($tagList)){
        foreach($tagList as $key => $value){
            $diff = array_diff($teseTagsIdsArr,$value);
            if(empty($diff)){
                $tcfangchanIdsArr[$key] = $key;
            }
        }
    }
    if(is_array($tcfangchanIdsArr) && !empty($tcfangchanIdsArr)){
        $tcfangchanIdsList = array_merge($tcfangchanIdsList,$tcfangchanIdsArr);
    }else{
        $outStr = '205';
        echo json_encode($outStr); exit;
    }
}

if(is_array($tcfangchanIdsList) && !empty($tcfangchanIdsList)){
    $tcfangchanIdsStr = implode(',', $tcfangchanIdsList);
    $whereStr.= " AND id IN ({$tcfangchanIdsStr}) ";
}

if($mendian_id > 0){
    $agentListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_user_id(" AND mendian_id={$mendian_id} ","ORDER BY id DESC");
    $agentUserIdArr = array();
    if(is_array($agentListTmp) && !empty($agentListTmp)){
        foreach($agentListTmp as $key => $value){
            $agentUserIdArr[] = $value['user_id'];
        }
    }
    if(is_array($agentUserIdArr) && !empty($agentUserIdArr)){
        $agentUserIdStr = implode(',', $agentUserIdArr);
        $whereStr.= " AND user_id IN ({$agentUserIdStr}) ";
    }else{
        $outStr = '205';
        echo json_encode($outStr); exit;
    }
}

$nearby = 0;
$orderByWhere = "ORDER BY finish ASC,top_status DESC,refresh_time DESC,id DESC";
if($paixu_type > 0){
    if($paixu_type == 1){
        $nearby = 1;
    }else if($paixu_type == 2){
        $orderByWhere = "ORDER BY finish ASC,top_status DESC,price ASC,refresh_time DESC,id DESC";
    }else if($paixu_type == 3){
        $orderByWhere = "ORDER BY finish ASC,top_status DESC,price DESC,refresh_time DESC,id DESC";
    }else if($paixu_type == 4){
        $orderByWhere = "ORDER BY finish ASC,top_status DESC,mianji ASC,refresh_time DESC,id DESC";
    }else if($paixu_type == 5){
        $orderByWhere = "ORDER BY finish ASC,top_status DESC,mianji DESC,refresh_time DESC,id DESC";
    }
}

if(empty($latitude)){
    $latitude = getcookie('tom_tongcheng_user_latitude');
    $longitude = getcookie('tom_tongcheng_user_longitude');
}

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
$tcfangchanList = array();
if($nearby == 1 && !empty($latitude) && !empty($longitude)){
    $tcfangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($whereStr, $orderByWhere, $start, $pagesize, $keyword,$latitude,$longitude);
}else{
    $tcfangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($whereStr, $orderByWhere, $start, $pagesize, $keyword);
}
if(is_array($tcfangchanListTmp) && !empty($tcfangchanListTmp)){
    foreach ($tcfangchanListTmp as $key => $value) {
        $tcfangchanList[$key] = $value;
        
        $attrInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_attr")->fetch_by_tcfangchan_id($value['id']);
        
        $teseTagsArr = explode('|', trim($attrInfoTmp['attr_tese_tags'], '|'));
        
        if(!empty($value['vr_link'])){
            $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND tcfangchan_id = {$value['id']} AND type = 2 ", 'ORDER BY id ASC', 0, 1);
        }else if(!empty($value['video_url'])){
            $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND tcfangchan_id = {$value['id']} AND type = 4 ", 'ORDER BY id ASC', 0, 1);
        }else{
            $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND tcfangchan_id = {$value['id']} AND type = 1 ", 'ORDER BY id ASC', 0, 1);
        }
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }else{
            $picurlTmp = $tcfangchanConfig['default_fangchan_photo'];
        }

        $tcfangchanList[$key]['attrInfo']        = $attrInfoTmp;
        $tcfangchanList[$key]['teseTagsList']    = $teseTagsArr;
        $tcfangchanList[$key]['picurl']          = $picurlTmp;
        $tcfangchanList[$key]['average_price']   = intval($value['price']/$value['mianji']*10000);
    }
}

if(is_array($tcfangchanList) && !empty($tcfangchanList)){
    foreach($tcfangchanList as $key => $val){
        $huxingMsg = '';
        if($val['attrInfo']['attr_shi'] > 0){
            $huxingMsg .= $val['attrInfo']['attr_shi'].lang('plugin/tom_tcfangchan', 'shi');
        }
        if($val['attrInfo']['attr_ting'] > 0){
            $huxingMsg .= $val['attrInfo']['attr_ting'].lang('plugin/tom_tcfangchan', 'ting');
        }
        if($val['attrInfo']['attr_wei'] > 0){
            $huxingMsg .= $val['attrInfo']['attr_wei'].lang('plugin/tom_tcfangchan', 'wei');
        }
        
        $fangchanNatureMsg = '';
        if($val['fangchan_nature'] == 1){
            $fangchanNatureMsg = lang('plugin/tom_tcfangchan', 'list_fangchan_nature_1');
        }else if($val['fangchan_nature'] == 2){
            $fangchanNatureMsg = lang('plugin/tom_tcfangchan', 'list_fangchan_nature_2');
        }else if($val['fangchan_nature'] == 3){
            $fangchanNatureMsg = lang('plugin/tom_tcfangchan', 'list_fangchan_nature_3');
        }
        
        if($val['model_id'] == 'ershoufang'){
            $outStr .= '<a class="fangchan-list__item dislay-flex" href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=info&tcfangchan_id='.$val['id'].'">';
                $outStr .= '<div class="pic">';
                    $outStr .= '<img src="'.$val['picurl'].'">';
                    if(!empty($val['vr_link'])){
                        $outStr .= '<span class="vr"><i></i></span>';
                    }else if(!empty($val['video_url'])){
                        $outStr .= '<span class="video"><i class="tciconfont tcicon-bofang"></i></span>';
                    }
                    if($val['finish'] == 1){
                        $outStr .= '<span class="expire">'.lang('plugin/tom_tcfangchan', 'list_finish_ok').'</span>';
                    }
                    if($val['top_status'] == 1 && $val['top_time'] > TIMESTAMP){
                        $outStr .= '<span class="top">'.lang("plugin/tom_tcfangchan", 'top').'</span>';
                    }
                $outStr .= '</div>';
                $outStr .= '<div class="content">';
                    $outStr .= '<div class="title"><span class="model model_ershoufang">'.lang('plugin/tom_tcfangchan', 'ershoufang').'</span>'.$val['title'].'</div>';
                    $outStr .= '<div class="desc">'.$huxingMsg.'/'.$val['mianji'].lang('plugin/tom_tcfangchan', 'pingmi').'/'.$val['houses_name'].'</div>';
                    if(!empty($val['attrInfo']['attr_tese_tags'])){
                        $outStr .= '<div class="taglist clearfix">';
                            if(is_array($val['teseTagsList']) && !empty($val['teseTagsList'])){
                                foreach($val['teseTagsList'] as $k => $v){
                                    $outStr .= '<span>'.$v.'</span>';
                                }
                            }
                        $outStr .= '</div>';
                    }
                    $outStr .= '<div class="price-xq">';
                        if($val['price'] > 0){
                            $outStr .= '<span class="price"><b>'.$val['price'].'</b>'.lang('plugin/tom_tcfangchan', 'wan').'</span>';
                            $outStr .= '<span class="danjia">'.$val['average_price'].lang('plugin/tom_tcfangchan', 'yuan').'/'.lang('plugin/tom_tcfangchan', 'pingmi').'</span> ';
                        }else{
                            $outStr .= '<span class="price"><b>'.lang('plugin/tom_tcfangchan', 'mianyi').'</b></span>';
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
            $outStr .= '</a>';
        }else if($val['model_id'] == 'chuzu'){
            
            $attrLeaseMsg = '';
            if($val['attrInfo']['attr_lease_type'] == 1){
                $attrLeaseMsg = lang('plugin/tom_tcfangchan', 'list_attr_lease_type_1').'/';
            }else if($val['attrInfo']['attr_lease_type'] == 2){
                $attrLeaseMsg = lang('plugin/tom_tcfangchan', 'list_attr_lease_type_2').'/';
            }
            $outStr .= '<a class="fangchan-list__item dislay-flex" href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=info&tcfangchan_id='.$val['id'].'">';
                $outStr .= '<div class="pic">';
                    $outStr .= '<img src="'.$val['picurl'].'">';
                    if(!empty($val['vr_link'])){
                        $outStr .= '<span class="vr"><i></i></span>';
                    }else if(!empty($val['video_url'])){
                        $outStr .= '<span class="video"><i class="tciconfont tcicon-bofang"></i></span>';
                    }
                    if($val['top_status'] == 1 && $val['top_time'] > TIMESTAMP){
                        $outStr .= '<span class="top">'.lang("plugin/tom_tcfangchan", 'top').'</span>';
                    }
                    if($val['finish'] == 1){
                        $outStr .= '<span class="expire">'.lang('plugin/tom_tcfangchan', 'list_finish_ok').'</span>';
                    }
                $outStr .= '</div>';
                $outStr .= '<div class="content">';
                    $outStr .= '<div class="title"><span class="model model_chuzu">'.lang('plugin/tom_tcfangchan', 'chuzu').'</span>'.$val['title'].'</div>';
                    $outStr .= '<div class="desc">'.$attrLeaseMsg.$huxingMsg.'/'.$val['mianji'].lang('plugin/tom_tcfangchan', 'pingmi').'/'.$val['houses_name'].'</div>';
                    if(!empty($val['attrInfo']['attr_tese_tags'])){
                        $outStr .= '<div class="taglist clearfix">';
                            if(is_array($val['teseTagsList']) && !empty($val['teseTagsList'])){
                                foreach($val['teseTagsList'] as $k => $v){
                                    $outStr .= '<span>'.$v.'</span>';
                                }
                            }
                        $outStr .= '</div>';
                    }
                    $outStr .= '<div class="price-xq">';
                        if($val['rent'] > 0){
                            $outStr .= '<span class="price"><b>'.$val['rent'].'</b>'.$rentUnitArr[$val['attrInfo']['attr_rent_unit']].'</span>';
                        }else{
                            $outStr .= '<span class="price">'.lang('plugin/tom_tcfangchan', 'list_mianyi').'</span>';
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
            $outStr .= '</a>';
            
        }else if($val['model_id'] == 'shangpu'){
            
            $outStr .= '<a class="fangchan-list__item dislay-flex" href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=info&tcfangchan_id='.$val['id'].'">';
                $outStr .= '<div class="pic">';
                    $outStr .= '<img src="'.$val['picurl'].'">';
                    if(!empty($val['vr_link'])){
                        $outStr .= '<span class="vr"><i></i></span>';
                    }else if(!empty($val['video_url'])){
                        $outStr .= '<span class="video"><i class="tciconfont tcicon-bofang"></i></span>';
                    }
                    if($val['top_status'] == 1 && $val['top_time'] > TIMESTAMP){
                        $outStr .= '<span class="top">'.lang("plugin/tom_tcfangchan", 'top').'</span>';
                    }
                    if($val['finish'] == 1){
                        $outStr .= '<span class="expire">'.lang('plugin/tom_tcfangchan', 'list_finish_ok').'</span>';
                    }
                $outStr .= '</div>';
                $outStr .= '<div class="content">';
                    $outStr .= '<div class="title"><span class="model model_shangpu">'.lang('plugin/tom_tcfangchan', 'shangpu').$fangchanNatureMsg.'</span>'.$val['title'].'</div>';
                    $outStr .= '<div class="desc">'.$fangchanNatureMsg.'/'.$val['mianji'].lang('plugin/tom_tcfangchan', 'pingmi').'/'.$val['area_name'].'-'.$val['street_name'].'</div>';
                    if(!empty($val['attrInfo']['attr_tese_tags'])){
                        $outStr .= '<div class="taglist clearfix">';
                            if(is_array($val['teseTagsList']) && !empty($val['teseTagsList'])){
                                foreach($val['teseTagsList'] as $k => $v){
                                    $outStr .= '<span>'.$v.'</span>';
                                }
                            }
                        $outStr .= '</div>';
                    }
                    $outStr .= '<div class="price-xq">';
                        if($val['fangchan_nature'] == 1){
                            if($val['rent'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['rent'].'</b>'.$rentUnitArr[$val['attrInfo']['attr_rent_unit']].'</span>';
                            }else{
                                $outStr .= '<span class="price">'.lang('plugin/tom_tcfangchan', 'list_mianyi').'</span>';
                            }
                        }else if($val['fangchan_nature'] == 2){
                            if($val['price'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['price'].'</b>'.lang('plugin/tom_tcfangchan', 'list_price_unit').'</span>';
                            }else{
                                $outStr .= '<span class="price"><b>'.lang('plugin/tom_tcfangchan', 'mianyi').'</b></span>';
                            }
                        }else if($val['fangchan_nature'] == 3){
                            if($val['zhuanrang_price'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['zhuanrang_price'].'</b>'.lang('plugin/tom_tcfangchan', 'list_price_unit').'</span>';
                            }else{
                                $outStr .= '<span class="price"><b>'.lang('plugin/tom_tcfangchan', 'mianyi').'</b></span>';
                            }
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
            $outStr .= '</a>';
            
        }else if($val['model_id'] == 'xiezilou'){
            
            $outStr .= '<a class="fangchan-list__item dislay-flex" href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=info&tcfangchan_id='.$val['id'].'">';
                $outStr .= '<div class="pic">';
                    $outStr .= '<img src="'.$val['picurl'].'">';
                    if(!empty($val['vr_link'])){
                        $outStr .= '<span class="vr"><i></i></span>';
                    }else if(!empty($val['video_url'])){
                        $outStr .= '<span class="video"><i class="tciconfont tcicon-bofang"></i></span>';
                    }
                    if($val['top_status'] == 1 && $val['top_time'] > TIMESTAMP){
                        $outStr .= '<span class="top">'.lang("plugin/tom_tcfangchan", 'top').'</span>';
                    }
                    if($val['finish'] == 1){
                        $outStr .= '<span class="expire">'.lang('plugin/tom_tcfangchan', 'list_finish_ok').'</span>';
                    }
                $outStr .= '</div>';
                $outStr .= '<div class="content">';
                    $outStr .= '<div class="title"><span class="model model_xiezilou">'.lang('plugin/tom_tcfangchan', 'xiezilou').$fangchanNatureMsg.'</span>'.$val['title'].'</div>';
                    $outStr .= '<div class="desc">'.$fangchanNatureMsg.'/'.$val['mianji'].lang('plugin/tom_tcfangchan', 'pingmi').'/'.$val['area_name'].'-'.$val['street_name'].'</div>';
                    if(!empty($val['attrInfo']['attr_tese_tags'])){
                        $outStr .= '<div class="taglist clearfix">';
                            if(is_array($val['teseTagsList']) && !empty($val['teseTagsList'])){
                                foreach($val['teseTagsList'] as $k => $v){
                                    $outStr .= '<span>'.$v.'</span>';
                                }
                            }
                        $outStr .= '</div>';
                    }
                    $outStr .= '<div class="price-xq">';
                        if($val['fangchan_nature'] == 1){
                            if($val['rent'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['rent'].'</b>'.$rentUnitArr[$val['attrInfo']['attr_rent_unit']].'</span>';
                            }else{
                                $outStr .= '<span class="price">'.lang('plugin/tom_tcfangchan', 'list_mianyi').'</span>';
                            }
                        }else if($val['fangchan_nature'] == 2){
                            if($val['price'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['price'].'</b>'.lang('plugin/tom_tcfangchan', 'list_price_unit').'</span>';
                            }else{
                                $outStr .= '<span class="price"><b>'.lang('plugin/tom_tcfangchan', 'mianyi').'</b></span>';
                            }
                        }else if($val['fangchan_nature'] == 3){
                            if($val['zhuanrang_price'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['zhuanrang_price'].'</b>'.lang('plugin/tom_tcfangchan', 'list_price_unit').'</span>';
                            }else{
                                $outStr .= '<span class="price"><b>'.lang('plugin/tom_tcfangchan', 'mianyi').'</b></span>';
                            }
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
            $outStr .= '</a>';
            
        }else if($val['model_id'] == 'changfang'){
            
            $outStr .= '<a class="fangchan-list__item dislay-flex" href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=info&tcfangchan_id='.$val['id'].'">';
                $outStr .= '<div class="pic">';
                    $outStr .= '<img src="'.$val['picurl'].'">';
                    if(!empty($val['vr_link'])){
                        $outStr .= '<span class="vr"><i></i></span>';
                    }else if(!empty($val['video_url'])){
                        $outStr .= '<span class="video"><i class="tciconfont tcicon-bofang"></i></span>';
                    }
                    if($val['top_status'] == 1 && $val['top_time'] > TIMESTAMP){
                        $outStr .= '<span class="top">'.lang("plugin/tom_tcfangchan", 'top').'</span>';
                    }
                    if($val['finish'] == 1){
                        $outStr .= '<span class="expire">'.lang('plugin/tom_tcfangchan', 'list_finish_ok').'</span>';
                    }
                $outStr .= '</div>';
                $outStr .= '<div class="content">';
                    $outStr .= '<div class="title"><span class="model model_changfang">'.lang('plugin/tom_tcfangchan', 'changfang').$fangchanNatureMsg.'</span>'.$val['title'].'</div>';
                    $outStr .= '<div class="desc">'.$fangchanNatureMsg.'/'.$val['mianji'].lang('plugin/tom_tcfangchan', 'pingmi').'/'.$val['area_name'].'-'.$val['street_name'].'</div>';
                    if(!empty($val['attrInfo']['attr_tese_tags'])){
                        $outStr .= '<div class="taglist clearfix">';
                            if(is_array($val['teseTagsList']) && !empty($val['teseTagsList'])){
                                foreach($val['teseTagsList'] as $k => $v){
                                    $outStr .= '<span>'.$v.'</span>';
                                }
                            }
                        $outStr .= '</div>';
                    }
                    $outStr .= '<div class="price-xq">';
                        if($val['fangchan_nature'] == 1){
                            if($val['rent'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['rent'].'</b>'.$rentUnitArr[$val['attrInfo']['attr_rent_unit']].'</span>';
                            }else{
                                $outStr .= '<span class="price">'.lang('plugin/tom_tcfangchan', 'list_mianyi').'</span>';
                            }
                        }else if($val['fangchan_nature'] == 2){
                            if($val['price'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['price'].'</b>'.lang('plugin/tom_tcfangchan', 'list_price_unit').'</span>';
                            }else{
                                $outStr .= '<span class="price"><b>'.lang('plugin/tom_tcfangchan', 'mianyi').'</b></span>';
                            }
                        }else if($val['fangchan_nature'] == 3){
                            if($val['zhuanrang_price'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['zhuanrang_price'].'</b>'.lang('plugin/tom_tcfangchan', 'list_price_unit').'</span>';
                            }else{
                                $outStr .= '<span class="price"><b>'.lang('plugin/tom_tcfangchan', 'mianyi').'</b></span>';
                            }
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
            $outStr .= '</a>';
            
        }else if($val['model_id'] == 'cangku'){
            
            $outStr .= '<a class="fangchan-list__item dislay-flex" href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=info&tcfangchan_id='.$val['id'].'">';
                $outStr .= '<div class="pic">';
                    $outStr .= '<img src="'.$val['picurl'].'">';
                    if(!empty($val['vr_link'])){
                        $outStr .= '<span class="vr"><i></i></span>';
                    }else if(!empty($val['video_url'])){
                        $outStr .= '<span class="video"><i class="tciconfont tcicon-bofang"></i></span>';
                    }
                    if($val['top_status'] == 1 && $val['top_time'] > TIMESTAMP){
                        $outStr .= '<span class="top">'.lang("plugin/tom_tcfangchan", 'top').'</span>';
                    }
                    if($val['finish'] == 1){
                        $outStr .= '<span class="expire">'.lang('plugin/tom_tcfangchan', 'list_finish_ok').'</span>';
                    }
                $outStr .= '</div>';
                $outStr .= '<div class="content">';
                    $outStr .= '<div class="title"><span class="model model_cangku">'.lang('plugin/tom_tcfangchan', 'cangku').$fangchanNatureMsg.'</span>'.$val['title'].'</div>';
                    $outStr .= '<div class="desc">'.$fangchanNatureMsg.'/'.$val['mianji'].lang('plugin/tom_tcfangchan', 'pingmi').'/'.$val['area_name'].'-'.$val['street_name'].'</div>';
                    if(!empty($val['attrInfo']['attr_tese_tags'])){
                        $outStr .= '<div class="taglist clearfix">';
                            if(is_array($val['teseTagsList']) && !empty($val['teseTagsList'])){
                                foreach($val['teseTagsList'] as $k => $v){
                                    $outStr .= '<span>'.$v.'</span>';
                                }
                            }
                        $outStr .= '</div>';
                    }
                    $outStr .= '<div class="price-xq">';
                        if($val['fangchan_nature'] == 1){
                            if($val['rent'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['rent'].'</b>'.$rentUnitArr[$val['attrInfo']['attr_rent_unit']].'</span>';
                            }else{
                                $outStr .= '<span class="price">'.lang('plugin/tom_tcfangchan', 'list_mianyi').'</span>';
                            }
                        }else if($val['fangchan_nature'] == 2){
                            if($val['price'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['price'].'</b>'.lang('plugin/tom_tcfangchan', 'list_price_unit').'</span>';
                            }else{
                                $outStr .= '<span class="price"><b>'.lang('plugin/tom_tcfangchan', 'mianyi').'</b></span>';
                            }
                        }else if($val['fangchan_nature'] == 3){
                            if($val['zhuanrang_price'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['zhuanrang_price'].'</b>'.lang('plugin/tom_tcfangchan', 'list_price_unit').'</span>';
                            }else{
                                $outStr .= '<span class="price"><b>'.lang('plugin/tom_tcfangchan', 'mianyi').'</b></span>';
                            }
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
            $outStr .= '</a>';
            
        }else if($val['model_id'] == 'tudi'){
            
            $outStr .= '<a class="fangchan-list__item dislay-flex" href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=info&tcfangchan_id='.$val['id'].'">';
                $outStr .= '<div class="pic">';
                    $outStr .= '<img src="'.$val['picurl'].'">';
                    if(!empty($val['vr_link'])){
                        $outStr .= '<span class="vr"><i></i></span>';
                    }else if(!empty($val['video_url'])){
                        $outStr .= '<span class="video"><i class="tciconfont tcicon-bofang"></i></span>';
                    }
                    if($val['top_status'] == 1 && $val['top_time'] > TIMESTAMP){
                        $outStr .= '<span class="top">'.lang("plugin/tom_tcfangchan", 'top').'</span>';
                    }
                    if($val['finish'] == 1){
                        $outStr .= '<span class="expire">'.lang('plugin/tom_tcfangchan', 'list_finish_ok').'</span>';
                    }
                $outStr .= '</div>';
                $outStr .= '<div class="content">';
                    $outStr .= '<div class="title"><span class="model model_tudi">'.lang('plugin/tom_tcfangchan', 'tudi').$fangchanNatureMsg.'</span>'.$val['title'].'</div>';
                    $outStr .= '<div class="desc">'.$fangchanNatureMsg.'/'.$val['mianji'].lang('plugin/tom_tcfangchan', 'pingmi').'/'.$val['area_name'].'-'.$val['street_name'].'</div>';
                    if(!empty($val['attrInfo']['attr_tese_tags'])){
                        $outStr .= '<div class="taglist clearfix">';
                            if(is_array($val['teseTagsList']) && !empty($val['teseTagsList'])){
                                foreach($val['teseTagsList'] as $k => $v){
                                    $outStr .= '<span>'.$v.'</span>';
                                }
                            }
                        $outStr .= '</div>';
                    }
                    $outStr .= '<div class="price-xq">';
                        if($val['fangchan_nature'] == 1){
                            if($val['rent'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['rent'].'</b>'.$rentUnitArr[$val['attrInfo']['attr_rent_unit']].'</span>';
                            }else{
                                $outStr .= '<span class="price">'.lang('plugin/tom_tcfangchan', 'list_mianyi').'</span>';
                            }
                        }else if($val['fangchan_nature'] == 2){
                            if($val['price'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['price'].'</b>'.lang('plugin/tom_tcfangchan', 'list_price_unit').'</span>';
                            }else{
                                $outStr .= '<span class="price"><b>'.lang('plugin/tom_tcfangchan', 'mianyi').'</b></span>';
                            }
                        }else if($val['fangchan_nature'] == 3){
                            if($val['zhuanrang_price'] > 0){
                                $outStr .= '<span class="price"><b>'.$val['zhuanrang_price'].'</b>'.lang('plugin/tom_tcfangchan', 'list_price_unit').'</span>';
                            }else{
                                $outStr .= '<span class="price"><b>'.lang('plugin/tom_tcfangchan', 'mianyi').'</b></span>';
                            }
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
            $outStr .= '</a>';
        }
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;