<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$act = !empty($_GET['act'])? addslashes($_GET['act']):'';

$mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_user_id($__UserInfo['id']);
if(is_array($mendianInfo) && !empty($mendianInfo)){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mymendian");exit;
}
$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
if(is_array($agentInfo) && !empty($agentInfo)){
    if($agentInfo['mendian_id'] > 0){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");exit;
    }else if($agentInfo['mendian_shenhe_status'] == 2 && $agentInfo['mendian_shenhe_id'] > 0){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");exit;
    }
}

if($act == "save" && submitcheck('name')){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name               = dhtmlspecialchars($name);
    $city_id            = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $area_name          = isset($_GET['area_name'])? addslashes($_GET['area_name']):'';
    $area_name          = dhtmlspecialchars($area_name);
    $street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $street_name        = isset($_GET['street_name'])? addslashes($_GET['street_name']):'';
    $street_name        = dhtmlspecialchars($street_name);
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address            = dhtmlspecialchars($address);
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $latitude           = dhtmlspecialchars($latitude);
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $longitude          = dhtmlspecialchars($longitude);
    $business_hours     = isset($_GET['business_hours'])? addslashes($_GET['business_hours']):'';
    $business_hours     = dhtmlspecialchars($business_hours);
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                = dhtmlspecialchars($tel);
    $shopkeeper_tel     = isset($_GET['shopkeeper_tel'])? addslashes($_GET['shopkeeper_tel']):'';
    $shopkeeper_tel     = dhtmlspecialchars($shopkeeper_tel);
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content            = dhtmlspecialchars($content);
    $logo               = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    $logo               = dhtmlspecialchars($logo);
    $business_licence   = isset($_GET['business_licence'])? addslashes($_GET['business_licence']):'';
    $business_licence   = dhtmlspecialchars($business_licence);
    
    $photolist = array();
    if(is_array($_GET['photolist']) && !empty($_GET['photolist'])){
        foreach($_GET['photolist'] as $key => $value){
            if(!empty($value)){
                $photolist[] = addslashes($value);
            }
        }
    }
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['user_id']          = $__UserInfo['id'];
    $insertData['name']             = $name;
    $insertData['city_id']          = $city_id;
    $insertData['area_id']          = $area_id;
    $insertData['area_name']        = $area_name;
    $insertData['street_id']        = $street_id;
    $insertData['street_name']      = $street_name;
    $insertData['address']          = $address;
    $insertData['latitude']         = $latitude;
    $insertData['longitude']        = $longitude;
    $insertData['business_hours']   = $business_hours;
    $insertData['tel']              = $tel;
    $insertData['shopkeeper_tel']   = $shopkeeper_tel;
    $insertData['content']          = $content;
    $insertData['search_text']      = $name.'|++++|'.$tel.'|++++|'.$address;
    if($tcfangchanConfig['mendian_must_shenhe'] == 1){
        $insertData['shenhe_status']    = 2;
    }else{
        $insertData['shenhe_status']    = 1;
    }
    $insertData['add_time']         = TIMESTAMP;
    if(C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->insert($insertData)){
        
        $mendian_id = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->insert_id();
        
        if(!empty($logo)){
            $insertData = array();
            $insertData['mendian_id']       = $mendian_id;
            $insertData['type']             = 5;
            $insertData['picurl']           = $logo;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        if(is_array($photolist) && !empty($photolist)){
            foreach($photolist as $key => $value){
                $insertData = array();
                $insertData['mendian_id']       = $mendian_id;
                $insertData['type']             = 6;
                $insertData['picurl']           = $value;
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
        }
        if(!empty($business_licence)){
            $insertData = array();
            $insertData['mendian_id']       = $mendian_id;
            $insertData['type']             = 7;
            $insertData['picurl']           = $business_licence;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        
        if(is_array($agentInfo) && !empty($agentInfo)){
            $updateData = array();
            $updateData['site_id']                  = $site_id;
            $updateData['mendian_id']               = $mendian_id;
            $updateData['mendian_name']             = $name;
            $updateData['mendian_shenhe_status']    = 1;
            $updateData['mendian_shenhe_id']        = 0;
            C::t("#tom_tcfangchan#tom_tcfangchan_agent")->update($agentInfo['id'], $updateData);
        }else{
            $insertData = array();
            $insertData['site_id']              = $site_id;
            $insertData['mendian_id']           = $mendian_id;
            $insertData['user_id']              = $__UserInfo['id'];
            $insertData['avatar']               = $tcfangchanConfig['default_agent_avatar'];
            $insertData['name']                 = $__UserInfo['nickname'];
            $insertData['tel']                  = $__UserInfo['tel'];
            $insertData['shenhe_status']        = 1;
            $insertData['is_ok']                = 0;
            $insertData['add_time']             = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_agent")->insert($insertData);
            
            $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
            
            DB::query("UPDATE ".DB::table('tom_tcfangchan')." SET source_type=1 WHERE user_id = {$__UserInfo['id']} ", 'UNBUFFERED');
        }

        if(!empty($tongchengConfig['template_id'])){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

            if($agentInfo['is_ok'] == 0){
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($__UserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=agentedit&agent_id={$agentInfo['id']}&s=1");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcfangchan', 'template_ruzhu_mendian_agent_shenhe_msg'),
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($__UserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }

            if($tcfangchanConfig['mendian_must_shenhe'] == 1){

                $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($manageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcfangchan', 'template_ruzhu_mendian_shenhe_msg'),
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }

                $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($fcmanageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList");
                    $smsData = array(
                        'first'         => lang('plugin/tom_tcfangchan', 'template_ruzhu_mendian_shenhe_msg'),
                        'keyword1'      => $tcfangchanConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }
        }

        if($tcfangchanConfig['mendian_must_shenhe'] == 0){
            update_mendian_tcshop($mendian_id);
        }

        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }

    $outArr = array(
        'status'=> 1,
    );
    echo json_encode($outArr); exit;
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$__CommonInfo = C::t('#tom_tcfangchan#tom_tcfangchan_common')->fetch_by_id(1);
if(!$__CommonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_common')->insert($insertData);
}
$xieyi_txt = stripslashes($__CommonInfo['xieyi_txt']);

$showMustPhoneBtn = 0;
if($tcfangchanConfig['mendian_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$jumpUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mymendian";
$saveUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mendianruzhu&act=save";
$ossBatchUrl = 'plugin.php?id=tom_tcfangchan:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcfangchan:qiniuBatch';
$wxUploadUrl = "plugin.php?id=tom_tcfangchan:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$uploadUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=upload&act=photo&formhash={$formhash}&suffix=";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:mendianruzhu");