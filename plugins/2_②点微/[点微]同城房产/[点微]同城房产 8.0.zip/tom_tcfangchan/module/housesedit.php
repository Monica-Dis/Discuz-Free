<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$houses_id      = intval($_GET['houses_id'])? intval($_GET['houses_id']):0;
$act            = !empty($_GET['act'])? addslashes($_GET['act']):'';

$housesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_houses")->fetch_by_id($houses_id);

if($housesInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");exit;
}

if($act == "save" && submitcheck('name')){

    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $name                   = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name                   = dhtmlspecialchars($name);
    $type_ids               = isset($_GET['type_ids'])? addslashes($_GET['type_ids']):'';
    $type_ids               = dhtmlspecialchars($type_ids);
    $city_id                = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id                = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $area_name              = isset($_GET['area_name'])? addslashes($_GET['area_name']):'';
    $area_name              = dhtmlspecialchars($area_name);
    $street_id              = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $street_name            = isset($_GET['street_name'])? addslashes($_GET['street_name']):'';
    $street_name            = dhtmlspecialchars($street_name);
    $address                = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address                = dhtmlspecialchars($address);
    $latitude               = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $latitude               = dhtmlspecialchars($latitude);
    $longitude              = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $longitude              = dhtmlspecialchars($longitude);
    $year                   = intval($_GET['year'])>0? intval($_GET['year']):0;
    $average_price          = intval($_GET['average_price'])>0? intval($_GET['average_price']):0;
    $open_auto_average      = intval($_GET['open_auto_average'])>0? intval($_GET['open_auto_average']):0;
    $chanquan               = intval($_GET['chanquan'])>0? intval($_GET['chanquan']):0;
    $developer_company      = isset($_GET['developer_company'])? addslashes($_GET['developer_company']):'';
    $developer_company      = dhtmlspecialchars($developer_company);
    $parking_space          = intval($_GET['parking_space'])>0? intval($_GET['parking_space']):0;
    $plot_ratio             = floatval($_GET['plot_ratio'])>0? floatval($_GET['plot_ratio']):0.00;
    $greening_rate          = intval($_GET['greening_rate'])>0? intval($_GET['greening_rate']):0;
    $property_company       = isset($_GET['property_company'])? addslashes($_GET['property_company']):'';
    $property_company       = dhtmlspecialchars($property_company);
    $property_price         = floatval($_GET['property_price'])>0? floatval($_GET['property_price']):0.00;
    $property_tel           = isset($_GET['property_tel'])? addslashes($_GET['property_tel']):'';
    $property_tel           = dhtmlspecialchars($property_tel);

    $photolist = array();
    if(is_array($_GET['photolist']) && !empty($_GET['photolist'])){
        foreach($_GET['photolist'] as $key => $value){
            if(!empty($value)){
                $photolist[] = addslashes($value);
            }
        }
    }
    
    $typeStr = '';
    if(!empty($type_ids)){
        $typeIdsArr = explode(',', $type_ids);
        $typeArr = array();
        if(is_array($typeIdsArr) && !empty($typeIdsArr)){
            foreach($typeIdsArr as $key => $value){
                $value = intval($value);
                if(!empty($value)){
                    $typeArr[] = $value;
                }
            }
            $typeStr = '|'.implode('|', $typeArr).'|';
        }
    }
    

    $updateData = array();
    $updateData['site_id']              = $site_id;
    $updateData['name']                 = $name;
    $updateData['type']                 = $typeStr;
    $updateData['city_id']              = $city_id;
    $updateData['area_id']              = $area_id;
    $updateData['area_name']            = $area_name;
    $updateData['street_id']            = $street_id;
    $updateData['street_name']          = $street_name;
    $updateData['year']                 = $year;
    $updateData['average_price']        = $average_price;
    $updateData['open_auto_average']    = $open_auto_average;
    $updateData['chanquan']             = $chanquan;
    $updateData['address']              = $address;
    $updateData['latitude']             = $latitude;
    $updateData['longitude']            = $longitude;
    $updateData['developer_company']    = $developer_company;
    $updateData['parking_space']        = $parking_space;
    $updateData['plot_ratio']           = $plot_ratio;
    $updateData['greening_rate']        = $greening_rate;
    $updateData['property_company']     = $property_company;
    $updateData['property_price']       = $property_price;
    $updateData['property_tel']         = $property_tel;
    $updateData['shenhe_status']        = 2;
    $updateData['update_time']          = TIMESTAMP;
    if(C::t("#tom_tcfangchan#tom_tcfangchan_houses")->update($houses_id,$updateData)){
        
        C::t("#tom_tcfangchan#tom_tcfangchan_photo")->delete_by_houses_id($houses_id);

        if(is_array($photolist) && !empty($photolist)){
            foreach($photolist as $key => $value){
                $insertData = array();
                $insertData['houses_id']        = $houses_id;
                $insertData['type']             = 1;
                $insertData['picurl']           = $value;
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
        }

        if(!empty($tongchengConfig['template_id'])){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_houses_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($fcmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_houses_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }
    $outArr = array(
        'status'=> 1,
    );
    echo json_encode($outArr); exit;
    
    
}

$photoListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list(" AND houses_id={$houses_id} ", 'ORDER BY psort ASC,id ASC', 0, 50);
$photoList = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];
        if($value['type'] == 1){
            $photoList[$key] = $value;
            $photoList[$key]['picurl_link'] = $picurlTmp;
            
        }
    }
}
$photoCount = count($photoList);

$typeStr = trim($housesInfo['type'], '|');
$typeArr = explode('|', $typeStr);
$typeIdsStr = implode(',', $typeArr);

$houseTypeList = $typeNameArr = array();
$i = 0;
if(is_array($houseTypeArr) && !empty($houseTypeArr)){
    foreach ($houseTypeArr as $key => $value){
        
        if(in_array($key, $typeArr)){
            $typeNameArr[] = $value;
        }
        
        $houseTypeList[$i]['value'] = $key;
        $houseTypeList[$i]['title'] = diconv($value,CHARSET,'utf-8');
        $i++;
    }
}
$typeNameStr = implode(',', $typeNameArr);
$houseTypeData = urlencode(json_encode($houseTypeList));

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($housesInfo['city_id']);
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$jumpUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myhouseslist";

$ossBatchUrl = 'plugin.php?id=tom_tcfangchan:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcfangchan:qiniuBatch';
$wxUploadUrl = "plugin.php?id=tom_tcfangchan:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$uploadUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=upload&act=photo&formhash={$formhash}&suffix=";
$saveUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=housesedit";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:housesedit");