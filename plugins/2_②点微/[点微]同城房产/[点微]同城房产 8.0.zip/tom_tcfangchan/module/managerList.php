<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    if($__UserInfo['id'] != $tcfangchanConfig['fcmanage_user_id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
    }
}
# check end

if($_GET['act'] == 'shenhe' && submitcheck('tcfangchan_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0? intval($_GET['tcfangchan_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0? intval($_GET['shenhe_status']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    
    $updateData = array();
    $updateData['shenhe_status'] = $shenhe_status;
    if($shenhe_status == 1){
        $updateData['status'] = 1;
    }
    C::t('#tom_tcfangchan#tom_tcfangchan')->update($tcfangchanInfo['id'],$updateData);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
    
    update_fangchan_tongcheng($tcfangchan_id);
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcfangchanInfo['user_id']);
    
    if($tcfangchanInfo){
        
        if($shenhe_status == 1){
            $shenhe = str_replace('{TITLE}', $tcfangchanInfo['title'], lang('plugin/tom_tcfangchan', 'index_template_tcfangchan_shenhe_ok'));
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=info&tcfangchan_id='.$tcfangchanInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }else if($shenhe_status == 3){
            $shenhe = str_replace('{TITLE}', $tcfangchanInfo['title'], lang('plugin/tom_tcfangchan', 'index_template_tcfangchan_shenhe_no'));
            $tzShenhe = $shenhe.'<br/><font color="#8e8e8e">'.$content.'</font><br/><a href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=edit&tcfangchan_id='.$tcfangchanInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }
        
        $insertData = array();
        $insertData['user_id']      = $toUser['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcfangchanConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    
    $nextSmsTime = $toUser['last_smstp_time'] + 0;
    if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime){
        if($shenhe_status == 1){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$tcfangchanInfo['site_id']}&mod=info&tcfangchan_id=".$tcfangchanInfo['id']);
        }else if($shenhe_status == 3){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$tcfangchanInfo['site_id']}&mod=edit&tcfangchan_id=".$tcfangchanInfo['id']);
        }
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcfangchanConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $updateData = array();
            $updateData['last_smstp_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList&keyword=".urlencode(trim($keyword));
    
    echo $url;exit;
    
}else if($_GET['act'] == 'del' && submitcheck('tcfangchan_id')){
    
    $tcfangchan_id = intval($_GET['tcfangchan_id'])>0? intval($_GET['tcfangchan_id']):0;
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
    
    C::t('#tom_tcfangchan#tom_tcfangchan')->delete_by_id($tcfangchan_id);
    C::t('#tom_tcfangchan#tom_tcfangchan_attr')->delete_by_tcfangchan_id($tcfangchan_id);
    C::t('#tom_tcfangchan#tom_tcfangchan_photo')->delete_by_tcfangchan_id($tcfangchan_id);
    C::t("#tom_tcfangchan#tom_tcfangchan_tag")->delete_by_tcfangchan_id($tcfangchan_id);
    
    if($tcfangchanInfo['source_type'] == 1){
        $agentInfo = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($tcfangchanInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
    delete_fangchan_tongcheng($tcfangchan_id);
    echo 200;exit;

}else if($_GET['act'] == 'shenhe_show'){
    
    $tcfangchan_id  = intval($_GET['tcfangchan_id'])>0? intval($_GET['tcfangchan_id']):0;
    $fromtype       = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage       = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);

    $fangchan_shenhe_fail_str = str_replace("\r\n","{n}",$tcfangchanConfig['fangchan_shenhe_fail_text']); 
    $fangchan_shenhe_fail_str = str_replace("\n","{n}",$fangchan_shenhe_fail_str);
    $fangchanShenheFailArray = explode("{n}", $fangchan_shenhe_fail_str);
    
    $ajaxShenheUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList&act=shenhe&";
    $backUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList&type={$fromtype}&page={$frompage}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:managerShenhe");exit;
}

$keyword  = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page  = intval($_GET['page'])>0? intval($_GET['page']):1;
$type  = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = " AND finish = 0 AND pay_status != 1 AND deleted = 0 ";
if($type == 1){
    $where .= " AND shenhe_status=2 ";
}
if($type == 2){
    $where .= " AND shenhe_status=3 ";
}
if($__UserInfo['groupid'] == 2){
    $where .= " AND site_id={$site_id} ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count($where, $keyword);
$tcfangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list($where," ORDER BY refresh_time DESC,id DESC ",$start,$pagesize,$keyword);
$tcfangchanList = array();
foreach ($tcfangchanListTmp as $key => $value) {
    $tcfangchanList[$key] = $value;
    
    if(!empty($value['vr_link'])){
        $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id = {$value['id']} AND type = 2 ", "ORDER BY id ASC", 0, 1);
    }else{
        $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id = {$value['id']} AND type = 1 ", "ORDER BY id ASC", 0, 1);
    }

    $picurlTmp = '';
    if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
        $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
    }else{
        $picurlTmp = $tcfangchanConfig['default_fangchan_photo'];
    }

    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $agentInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_agent')->fetch_by_user_id($value['user_id']);
    
    $tcfangchanList[$key]['userInfo']           = $userInfoTmp;
    $tcfangchanList[$key]['agentInfo']          = $agentInfoTmp;
    $tcfangchanList[$key]['picurl']             = $picurlTmp;
        
    if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
        $updateData = array();
        $updateData['top_status']   = 0;
        $updateData['top_time']     = 0;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($value['id'], $updateData);
        update_fangchan_tongcheng($value['id']);
    }

    if($value['expire_status'] == 1 && $value['expire_time'] <= TIMESTAMP){
        $updateData = array();
        $updateData['expire_status']    = 2;
        $updateData['expire_time']      = 0;
        $updateData['status']           = 0;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($value['id'], $updateData);
        update_fangchan_tongcheng($value['id']);
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];

$ajaxShenheUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList&act=shenhe&formhash=".$formhash;
$ajaxDelUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList&act=del&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList&act=get_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:managerList");