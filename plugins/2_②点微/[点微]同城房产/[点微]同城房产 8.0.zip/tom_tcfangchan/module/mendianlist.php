<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword            = isset($_GET['keyword'])? daddslashes(urldecode($_GET['keyword'])):'';
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):0;

$page               = intval($_GET['page'])>0? intval($_GET['page']):0;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND shenhe_status=1 ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}

if($area_id > 0){
    $whereStr.= " AND area_id = {$area_id} ";
}

if($street_id > 0){
    $whereStr.= " AND street_id = {$street_id} ";
}

$nearby = 0;
$orderByWhere = " ORDER BY top_status DESC, clicks DESC,id DESC";
if($paixu_type > 0){
    if($paixu_type == 1){
        $nearby = 1;
    }else if($paixu_type == 2){
        $orderByWhere = " ORDER BY house_num DESC,top_status DESC, clicks DESC,id DESC ";
    }else if($paixu_type == 3){
        $orderByWhere = " ORDER BY house_num ASC,top_status DESC, clicks DESC,id DESC ";
    }else if($paixu_type == 4){
        $orderByWhere = " ORDER BY add_time ASC,top_status DESC, clicks DESC,id DESC ";
    }else if($paixu_type == 5){
        $orderByWhere = " ORDER BY add_time DESC,top_status DESC, clicks DESC,id DESC ";
    }
}

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
$mendianList = array();
if($nearby == 1 && !empty($latitude) && !empty($longitude)){
    $mendianListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_list($whereStr, $orderByWhere, $start, $pagesize, $keyword ,$latitude,$longitude);
}else{
    $mendianListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_all_list($whereStr, $orderByWhere, $start, $pagesize, $keyword );
}
if(is_array($mendianListTmp) && !empty($mendianListTmp)){
    foreach ($mendianListTmp as $key => $value) {
        $mendianList[$key] = $value;

        $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND mendian_id = {$value['id']} AND type = 5 ", "ORDER BY id ASC", 0, 1);
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }

        $mendianList[$key]['picurl'] = $picurlTmp;
        update_mendian_xinxi($value['id']);
    }
}

if(is_array($mendianList) && !empty($mendianList)){
    foreach ($mendianList as $key => $val) {

        $outStr .= '<a class="mendian-list__item dislay-flex" href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=mendianinfo&mendian_id='.$val['id'].'">';
            $outStr .= '<div class="pic">';
                $outStr .= '<img src="'.$val['picurl'].'">';
                if($val['top_status'] == 1 && $val['top_time'] > TIMESTAMP){
                    $outStr .= '<span class="top">'.lang("plugin/tom_tcfangchan", 'top').'</span>';
                }
            $outStr .= '</div>';

            $outStr .= '<div class="content flex">';
                $outStr .= '<div class="name">'.$val['name'].'</div>';
                $outStr .= '<div class="location">'.$val['address'].'</div>';
                $outStr .= '<div class="xinxi clearfix">';
                    $outStr .= '<span class="xinxi-item">'.lang('plugin/tom_tcfangchan', 'mendianlist_fangyuan').'<span class="num"> '.$val['house_num'].' </span>'.lang('plugin/tom_tcfangchan', 'mendianlist_tao').'</span>';
                    $outStr .= '<span class="xinxi-item">'.lang('plugin/tom_tcfangchan', 'mendianlist_agent').'<span class="num"> '.$val['agent_num'].' </span>'.lang('plugin/tom_tcfangchan', 'mendianlist_ren').'</span>';
                    $outStr .= '<span class="xinxi-item">'.lang('plugin/tom_tcfangchan', 'mendianlist_liulan').'<span class="num"> '.$val['clicks'].' </span>'.lang('plugin/tom_tcfangchan', 'mendianlist_ci').'</span>';
                $outStr .= '</div>';
            $outStr .= '</div>';
        $outStr .= '</a>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;