<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcfangchan_id  = intval($_GET['tcfangchan_id'])>0 ?intval($_GET['tcfangchan_id']):0;
$back_url       = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($tcfangchan_id);

if($tcfangchanInfo['id'] > 0 && $tcfangchanInfo['user_id'] == $__UserInfo['id']){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
}

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
if($agentInfo['mendian_id'] > 0){
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
}

if($agentInfo['id'] > 0){
    
    $xufeiStatus = 1;
    if($agentInfo['shenhe_status'] == 1 && $mendianInfo['id'] > 0){
        $mendian_fabu_num_tmp = $tcfangchanConfig['default_mendian_vip_agent_fabu_num'];
        if($tcfangchanConfig['open_mendian_vip'] == 1 && $mendianInfo['vip_id'] > 0 && $mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
            $mendianVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
            $mendian_fabu_num_tmp = intval($mendianVipInfo['agent_fabu_num']);
            if($mendianVipInfo['total_agent_fabu_num'] > 0){
                $mendianFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND expire_status = 3 AND pay_type = 3 ");
                if($mendianFangchanCount >= $mendianVipInfo['total_agent_fabu_num']){
                    $mendian_fabu_num_tmp = 0;
                }
            }
        }
        
        if($mendian_fabu_num_tmp > 0){
            $mendianFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND mendian_id = {$mendianInfo['id']} AND type = 1 AND today_time = {$nowDayTime} ");
            if($mendian_fabu_num_tmp > $mendianFabuCount){
                $xufeiStatus = 2;
            }
        }
    }
    
    if($xufeiStatus == 1 && $tcfangchanConfig['open_agent_vip'] == 1 && $agentInfo['vip_id'] > 0 && $agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP){
        $agentVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
        $agent_fabu_num_tmp = intval($agentVipInfo['fabu_num']);
        
        if($agentVipInfo['total_fabu_num'] > 0){
            $agentFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND expire_status = 3 AND pay_type = 4 ");
            if($agentFangchanCount >= $agentVipInfo['total_fabu_num']){
                $agent_fabu_num_tmp = 0;
            }
        }
        
        if($agent_fabu_num_tmp > 0){
            $agentFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND agent_id = {$agentInfo['id']} AND type = 5 AND today_time = {$nowDayTime} ");
            if($agent_fabu_num_tmp > $agentFabuCount){
                $xufeiStatus = 3;
            }
        }
    }
    
    if($xufeiStatus == 1 && $tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
        $xufeiPayScore = ceil($tcfangchanConfig['fangchan_agent_fabu_price'] * $tongchengConfig['pay_score_yuan']);
        if($xufeiPayScore > 0 && $__UserInfo['score'] > $xufeiPayScore){
            $xufeiStatus = 4;
        }
    }
    
}else{
    
    $fangchanFabuList = array();
    $fangchan_fabu_list_str = str_replace("\r\n","{n}",$tcfangchanConfig['fangchan_fabu_list']); 
    $fangchan_fabu_list_str = str_replace("\n","{n}",$fangchan_fabu_list_str);
    $fangchan_fabu_list_arr = explode("{n}", $fangchan_fabu_list_str);
    if(is_array($fangchan_fabu_list_arr) && !empty($fangchan_fabu_list_arr)){
        foreach ($fangchan_fabu_list_arr as $key => $value){
            $arr = array();
            $fangchanFabuList[$key] = $arr = explode("|", $value);
            $fangchanFabuList[$key]['score'] = 0;
            $fangchanFabuList[$key]['score_pay'] = 0;

            if($tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){

                $scorePayNum = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
                if($scorePayNum > 0 && $__UserInfo['score'] >= $scorePayNum){
                    $fangchanFabuList[$key]['score'] = $scorePayNum;
                    $fangchanFabuList[$key]['score_pay'] = 1;
                }
            }
        }
    }
}

$model_name = '';
if($tcfangchanInfo['model_id'] == 'ershoufang'){
    $model_name = lang('plugin/tom_tcfangchan', 'ershoufang');
    
}else if($tcfangchanInfo['model_id'] == 'chuzu'){
    $model_name = lang('plugin/tom_tcfangchan', 'chuzu');
    
}else if($tcfangchanInfo['model_id'] == 'shangpu'){
    $model_name = lang('plugin/tom_tcfangchan', 'shangpu');
    
}else if($tcfangchanInfo['model_id'] == 'xiezilou'){
    $model_name = lang('plugin/tom_tcfangchan', 'xiezilou');
   
}else if($tcfangchanInfo['model_id'] == 'changfang'){
    $model_name = lang('plugin/tom_tcfangchan', 'changfang');
    
}else if($tcfangchanInfo['model_id'] == 'cangku'){
    $model_name = lang('plugin/tom_tcfangchan', 'cangku');
    
}else if($tcfangchanInfo['model_id'] == 'tudi'){
    $model_name = lang('plugin/tom_tcfangchan', 'tudi');
}

if($agentInfo['id'] > 0){
    $payXufeiUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=fangchan_agent_xufei_pay&back_url=".urlencode($back_url)."&formhash=".$formhash;
}else{
    $payXufeiUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=fangchan_xufei_pay&back_url=".urlencode($back_url)."&formhash=".$formhash;
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:buyxufei");