<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$needs_id = intval($_GET['needs_id'])>0? intval($_GET['needs_id']):0;

$needsInfo = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($needs_id);

# check start
if($needsInfo['user_id'] != $__UserInfo['id']){
    if($__UserInfo['id'] == $tcfangchanConfig['fcmanage_user_id']){
    }else{
        if($__UserInfo['groupid'] == 1){
        }else if($__UserInfo['groupid'] == 2){
            if($needsInfo['site_id'] == $__UserInfo['groupsiteid']){
            }else{
                tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
            }
        }else{
            tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
        }
    }
}
# check end

if($_GET['act'] == 'save' && submitcheck('tel')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $xm                 = isset($_GET['xm'])? daddslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? daddslashes($_GET['tel']):'';
    $wx                 = isset($_GET['wx'])? daddslashes($_GET['wx']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $city_id            = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    
    $checkSafeText = $content.$xm.$tel.$wx.$address;
    $__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
    if(!empty($__CommonInfo['forbid_word'])){
        $forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
        $forbid_word = str_replace(array("\\*"), array('.*'), $forbid_word);
        $forbid_word = '.*('.$forbid_word.').*';
        $forbid_word = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word).')$/i';
        $contentTmpTmp = $checkSafeText;
        $contentTmpTmp = str_replace("\r\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\n","",$contentTmpTmp);
        $contentTmpTmp = str_replace("\r","",$contentTmpTmp);
        if(@preg_match($forbid_word, $contentTmpTmp,$matches)) {
            $i = count($matches)-1;
            $word = '';
            if(isset($matches[$i]) && !empty($matches[$i])){
                $word = diconv($matches[$i],CHARSET,'utf-8');
            }
            $outArr = array(
                'status'=> 505,
                'word'=> $word,
            );
            echo json_encode($outArr); exit;
        }
                
    }
    
    if($__ShowXiaofenlei == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/secure.func.php';
        if($xiaofenleiConfig['open_msgseccheck'] == 1){
            @$s_m_r = wx_msgSecCheck($checkSafeText);
            if($s_m_r['code'] == 100){
                $tcfangchanConfig['fabu_needs_must_shenhe'] = 1;
            }
            if($s_m_r['code'] == 500){
                $outArr = array(
                    'status'=> 505,
                    'word'=> $s_m_r['word'],
                );
                echo json_encode($outArr); exit;
            }
        }
    }
  
    $updateData = array();
    if($needsInfo['admin_edit'] == 0){
        $updateData['content']        = dhtmlspecialchars($content);
    }
    $updateData['xm']             = $xm;
    $updateData['tel']            = $tel;
    $updateData['wx']             = $wx;
    $updateData['city_id']        = $city_id;
    $updateData['area_id']        = $area_id;
    $updateData['street_id']      = $street_id;
    $updateData['address']        = $address;
    $updateData['latitude']       = $latitude;
    $updateData['longitude']      = $longitude;
    
    if($tcfangchanConfig['fabu_needs_must_shenhe'] == 1 ){
        $updateData['shenhe_status']       = 2;
    }else{
        $updateData['shenhe_status']       = 1;
    }
    $updateData['refresh_time']      = TIMESTAMP;
    if(C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($needs_id,$updateData)){
        
        $needsInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_by_id($needs_id);
        
        update_needs_tongcheng($needs_id);
        
        if(!empty($tongchengConfig['template_id']) && $tcfangchanConfig['fabu_needs_must_shenhe'] == 1 ){
            $toUser = array();
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $toUser = $toUserTmp;
            }

            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();

            if($access_token && !empty($toUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerNeedsList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan','fangchan_fubuneeds_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }

            $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($fcmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerNeedsList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'fangchan_fubuneeds_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
            'needs_id'=> $needs_id,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

if($needsInfo['area_id'] > 0){
    $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($needsInfo['area_id']);
    $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($needsInfo['street_id']);
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$cityList = array();
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$saveUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=edit_needs&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:edit_needs");