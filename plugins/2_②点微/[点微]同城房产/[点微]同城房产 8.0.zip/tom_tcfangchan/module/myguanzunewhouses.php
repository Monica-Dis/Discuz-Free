<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page = intval($_GET['page'])>0? intval($_GET['page']):1;
$type = intval($_GET['type'])>0? intval($_GET['type']):1;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND g.user_id={$__UserInfo['id']} AND g.type={$type}";
$order = " ORDER BY g.id DESC ";

$count = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_guanzu_count($where, $keyword);
$newhousesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_guanzu_list($where, $order, $start, $pagesize, $keyword);
$newhousesList = array();
if(is_array($newhousesListTmp) && !empty($newhousesListTmp)){
    foreach ($newhousesListTmp as $key => $value){
        $newhousesList[$key] = $value;
        
        $teseTagsArr = explode('|', trim($value['tese_tags'], '|'));
        
        $typeList = array();
        if(!empty($value['type'])){
            $typeListTmp = explode('|', trim($value['type'], '|'));
            if(is_array($typeListTmp) && !empty($typeListTmp)){
                foreach ($typeListTmp as $k => $v){
                    if(!empty($v)){
                        $typeList[] = $houseTypeArr[$v];
                    }
                }
            }
        }
        
        if(!empty($value['vr_link'])){
            $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND newhouses_id = {$value['id']} AND type = 2 ", "ORDER BY id ASC", 0, 1);
        }else{
            $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND newhouses_id = {$value['id']} AND type = 1 ", "ORDER BY id ASC", 0, 1);
        }
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $newhousesList[$key]['teseTagsList']    = $teseTagsArr;
        $newhousesList[$key]['typeList']        = $typeList;
        $newhousesList[$key]['picurl']          = $picurlTmp;
        
        if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->update($value['id'], $updateData);
        }
    }
}
$newhousesCount = count($newhousesList);

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myguanzunewhouses&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myguanzunewhouses&page={$nextPage}";

$ajaxCancelGuanzuUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=cancel_newhouses_guanzu&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:myguanzunewhouses");