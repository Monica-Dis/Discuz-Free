<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$mendian_id     = intval($_GET['mendian_id'])>0? intval($_GET['mendian_id']):0;
$model_id       = isset($_GET['model_id'])? addslashes($_GET['model_id']):'';
$keyword        = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$type           = intval($_GET['type'])>0? intval($_GET['type']):0;

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
$mendianInfo = array();
if($agentInfo['mendian_id'] > 0){
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
}

$pagesize = 8;
if(!empty($keyword)){
    $pagesize = 100;
}
$start = ($page - 1)*$pagesize;

$where = ' AND deleted = 0 ';
if($mendian_id > 0){
    if($mendianInfo['id'] == $mendian_id && $mendianInfo['user_id'] == $__UserInfo['id']){ }else{
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mymendian");exit;
    }
    
    $agentListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_user_id(" AND mendian_id={$mendian_id} ","ORDER BY id DESC");
    
    $agentUserIdArr = array();
    if(is_array($agentListTmp) && !empty($agentListTmp)){
        foreach($agentListTmp as $key => $value){
            $agentUserIdArr[] = $value['user_id'];
        }
    }
    if(is_array($agentUserIdArr) && !empty($agentUserIdArr)){
        $agentUserIdStr = implode(',', $agentUserIdArr);
        $where.= " AND user_id IN ({$agentUserIdStr}) ";
    }else{
        $where .= " AND user_id={$__UserInfo['id']}";
    }
    
}else{
    $where .= " AND user_id={$__UserInfo['id']}";
}
if(!empty($model_id)){
    $where .= " AND model_id='{$model_id}' ";
}
$order = " ORDER BY refresh_time DESC,id DESC ";
if($type == 1){
    $where.= " AND status = 1 AND shenhe_status = 1 AND finish = 0 AND ((pay_status = 0) OR (pay_status = 2)) ";
}
if($type == 2){
    $where.= " AND pay_status = 1 ";
}
if($type == 3){
    $where.= " AND (shenhe_status=2 OR shenhe_status=3) ";
    $order = " ORDER BY shenhe_status ASC,id DESC ";
}
if($type == 4){
    $where.= " AND ((pay_status = 0) OR (pay_status = 2)) AND expire_status = 2 ";
}

$count = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_count(" {$where} ", $keyword);
$tcfangchanListTmp = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_all_list(" {$where} "," {$order} ",$start,$pagesize, $keyword);
$tcfangchanList = array();
if(is_array($tcfangchanListTmp) && !empty($tcfangchanListTmp)){
    foreach ($tcfangchanListTmp as $key => $value){
        $tcfangchanList[$key] = $value;
        
        if(!empty($value['vr_link'])){
            $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id = {$value['id']} AND type = 2 ", "ORDER BY id ASC", 0, 1);
        }else{
            $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND tcfangchan_id = {$value['id']} AND type = 1 ", "ORDER BY id ASC", 0, 1);
        }
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }else{
            $picurlTmp = $tcfangchanConfig['default_fangchan_photo'];
        }
        
        $tcfangchanList[$key]['picurl']     = $picurlTmp;
        $tcfangchanList[$key]['model_name'] = lang("plugin/tom_tcfangchan", $value['model_id']);
        
        if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
            $updateData = array();
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value['id'], $updateData);
            update_fangchan_tongcheng($value['id']);
        }

        if($value['expire_status'] == 1 && $value['expire_time'] <= TIMESTAMP && $value['top_status'] == 0){
            $updateData = array();
            $updateData['expire_status']    = 2;
            $updateData['expire_time']      = 0;
            $updateData['status']           = 0;
            C::t('#tom_tcfangchan#tom_tcfangchan')->update($value['id'], $updateData);
            update_fangchan_tongcheng($value['id']);
        }
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfangchanlist&model_id={$model_id}&mendian_id={$mendian_id}&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfangchanlist&model_id={$model_id}&mendian_id={$mendian_id}&type={$type}&page={$nextPage}";

$mendianVipInfo = $agentVipInfo = array();
$mendianFangchanCount = $syMendianTotalFabuNum = $agentFangchanCount = $syAgentTotalFabuNum = $agentShengyuDays = 0;
if($agentInfo['id'] > 0 && $agentInfo['shenhe_status'] == 1){
    
    if($mendianInfo['id'] > 0){
        if($tcfangchanConfig['open_mendian_vip'] == 1 && $mendianInfo['vip_id'] > 0 && $mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
            $mendianVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
            
            if($mendianVipInfo['total_agent_fabu_num'] > 0){
                $mendianFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND expire_status = 3 AND pay_type = 3 AND add_time > {$mendianInfo['vip_add_time']}  ");
                if($mendianVipInfo['total_agent_fabu_num'] > $mendianFangchanCount){
                    $syMendianTotalFabuNum = $mendianVipInfo['total_agent_fabu_num'] - $mendianFangchanCount;
                }
            }
        }
    }

    if($tcfangchanConfig['open_agent_vip'] == 1 && $agentInfo['vip_id'] > 0 && $agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP){
        $agentVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
        
        if($agentVipInfo['total_fabu_num'] > 0){
            $agentFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND expire_status = 3 AND pay_type = 4 AND add_time > {$agentInfo['vip_add_time']}  ");
            if($agentVipInfo['total_fabu_num'] > $agentFangchanCount){
                $syAgentTotalFabuNum = $agentVipInfo['total_fabu_num'] - $agentFangchanCount;
            }
        }
        
        $agentShengyuDays = ceil(($agentInfo['expire_time'] - TIMESTAMP)/86400);
        
    }
    
}

$refreshStatus = 0;
if($tcfangchanConfig['fangchan_refresh_price'] > 0){
    $refreshStatus = 1;
    
    if($tcfangchanConfig['free_refresh_num'] > 0){
        $freeRefreshCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND type = 4 AND today_time = {$nowDayTime} ");
        if($tcfangchanConfig['free_refresh_num'] > $freeRefreshCount){
            $refreshStatus = 2;
            $syFreeRefreshNum = $tcfangchanConfig['free_refresh_num'] - $freeRefreshCount;
        }
    }
    
    if($agentInfo['id'] > 0 && $agentInfo['shenhe_status'] == 1){

        if($refreshStatus == 1 && $mendianInfo['id'] > 0){
            $mendian_refresh_num_tmp = $tcfangchanConfig['default_mendian_vip_agent_refresh_num'];
            if(is_array($mendianVipInfo) && !empty($mendianVipInfo)){
                $mendian_refresh_num_tmp = intval($mendianVipInfo['agent_refresh_num']);
            }

            $mendianRefreshCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND mendian_id = {$mendianInfo['id']} AND type = 2 AND today_time = {$nowDayTime} ");
            if($mendian_refresh_num_tmp > $mendianRefreshCount){
                $refreshStatus = 3;
                $syMendianRefreshNum = $mendian_refresh_num_tmp - $mendianRefreshCount;
            }
        }
    
        if($refreshStatus == 1 && is_array($agentVipInfo) && !empty($agentVipInfo)){
            $agent_refresh_num_tmp = intval($agentVipInfo['refresh_num']);
            $agentRefreshCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND agent_id = {$agentInfo['id']} AND type = 6 AND today_time = {$nowDayTime} ");
            if($agent_refresh_num_tmp > $agentRefreshCount){
                $syAgentRefreshNum = $agent_refresh_num_tmp - $agentRefreshCount;
                $refreshStatus = 4;
            }
        }
        
    }
    
    if($refreshStatus == 1 && $tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
        $refreshPayScore = ceil($tcfangchanConfig['fangchan_refresh_price'] * $tongchengConfig['pay_score_yuan']);
        if($refreshPayScore > 0 && $__UserInfo['score'] > $refreshPayScore){
            $refreshStatus = 5;
        }
    }
}

$title = '';
if($model_id == 'ershoufang'){
    $title = lang('plugin/tom_tcfangchan', 'ershoufang');
    
}else if($model_id == 'chuzu'){
    $title = lang('plugin/tom_tcfangchan', 'chuzu');
    
}else if($model_id == 'shangpu'){
    $title = lang('plugin/tom_tcfangchan', 'shangpu');
    
}else if($model_id == 'xiezilou'){
    $title = lang('plugin/tom_tcfangchan', 'xiezilou');
   
}else if($model_id == 'changfang'){
    $title = lang('plugin/tom_tcfangchan', 'changfang');
    
}else if($model_id == 'cangku'){
    $title = lang('plugin/tom_tcfangchan', 'cangku');
    
}else if($model_id == 'tudi'){
    $title = lang('plugin/tom_tcfangchan', 'tudi');
    
}

$back_url = $weixinClass->get_url();
$back_url = urlencode($back_url);

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=updateFangchanStatus&&formhash=".$formhash;
$ajaxUpdateFinishUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=updateFangchanFinish&&formhash=".$formhash;
$ajaxDelUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=fangchanDel&&formhash=".$formhash;
$payRefreshUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=fangchan_refresh_pay&user_id={$__UserInfo['id']}&back_url={$back_url}&formhash=".$formhash;
$payXufeiUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=fangchan_agent_xufei_pay&user_id={$__UserInfo['id']}&back_url={$back_url}&formhash=".$formhash;
$payUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=fangchan_pay&user_id={$__UserInfo['id']}&back_url={$back_url}&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=get_myfangchanlist_search_url&model_id={$model_id}&mendian_id={$mendian_id}";


$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:myfangchanlist");