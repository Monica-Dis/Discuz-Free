<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$model_id  = !empty($_GET['model_id'])? addslashes($_GET['model_id']):'ershoufang';

$agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($__UserInfo['id']);
$syMendianFabuNum = $syAgentFabuNum = $vipEndStatus = 0;
$topZhekou = 0;
if($__UserInfo['editor'] == 0 && $agentInfo['id'] > 0 && $agentInfo['shenhe_status'] == 1){
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($agentInfo['mendian_id']);
    if($mendianInfo['id'] > 0){
        $mendian_fabu_num_tmp = $tcfangchanConfig['default_mendian_vip_agent_fabu_num'];
        $mendian_total_fabu_num = 0;
        if($tcfangchanConfig['open_mendian_vip'] == 1 && $mendianInfo['vip_id'] > 0){
            $mendianVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
            if($mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
                $mendian_fabu_num_tmp = intval($mendianVipInfo['agent_fabu_num']);
                $mendian_total_fabu_num = intval($mendianVipInfo['total_agent_fabu_num']);
                if($mendianVipInfo['top_zhekou'] > 0){
                    $topZhekou = $mendianVipInfo['top_zhekou'];
                }
            }else{
                if($tcfangchanConfig['open_mendian_vip_agent'] == 1){
                    $agentCount = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_all_count( " AND mendian_id = {$mendianInfo['id']} ");
                    if($agentCount > $tcfangchanConfig['default_mendian_vip_agent_num']){
                        $vipEndStatus = 1;
                    }
                }
            }
        }
        
        if($mendian_total_fabu_num > 0){
            $mendianFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND expire_status = 3 AND pay_type = 3 AND add_time > {$mendianInfo['vip_add_time']} ");
            if($mendianVipInfo['total_agent_fabu_num'] > $mendianFangchanCount){
                $syMendianTotalFabuNum = $mendianVipInfo['total_agent_fabu_num'] - $mendianFangchanCount;
                
                $mendianDayFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND mendian_id = {$mendianInfo['id']} AND type = 1 AND today_time = {$nowDayTime} ");
                if($mendian_fabu_num_tmp > $mendianDayFabuCount){
                    $syMendianFabuNum = $mendian_fabu_num_tmp - $mendianDayFabuCount;
                    if($syMendianFabuNum > $syMendianTotalFabuNum){
                        $syMendianFabuNum = $syMendianTotalFabuNum;
                    }
                }
            }
            
        }else{
            $mendianDayFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND mendian_id = {$mendianInfo['id']} AND type = 1 AND today_time = {$nowDayTime} ");
            if($mendian_fabu_num_tmp > $mendianDayFabuCount){
                $syMendianFabuNum = $mendian_fabu_num_tmp - $mendianDayFabuCount;
            }
        }
        
    }
    
    if($tcfangchanConfig['open_agent_vip'] == 1 && $agentInfo['vip_id'] > 0 && $agentInfo['expire_status'] == 1 && $agentInfo['expire_time'] > TIMESTAMP){
        $agentVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($agentInfo['vip_id']);
        $agent_fabu_num_tmp = intval($agentVipInfo['fabu_num']);
        
        if($agentVipInfo['total_fabu_num'] > 0){
            $agentFangchanCount = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND expire_status = 3  AND pay_type = 4 AND add_time > {$agentInfo['vip_add_time']}  ");
            if($agentVipInfo['total_fabu_num'] > $agentFangchanCount){
                $syAgentTotalFabuNum = $agentVipInfo['total_fabu_num'] - $agentFangchanCount;
                
                $agentFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND agent_id = {$agentInfo['id']} AND type = 5 AND today_time = {$nowDayTime} ");
                if($agent_fabu_num_tmp > $agentFabuCount){
                    $syAgentFabuNum  = $agent_fabu_num_tmp - $agentFabuCount;
                    if($syAgentFabuNum > $syAgentTotalFabuNum){
                        $syAgentFabuNum = $syAgentTotalFabuNum;
                    }
                }
            }
        }else{
            $agentFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND agent_id = {$agentInfo['id']} AND type = 5 AND today_time = {$nowDayTime} ");
            if($agent_fabu_num_tmp > $agentFabuCount){
                $syAgentFabuNum  = $agent_fabu_num_tmp - $agentFabuCount;
            }
        }
        
        if($agentVipInfo['top_zhekou'] > 0){
            if($topZhekou == 0){
                $topZhekou = $agentVipInfo['top_zhekou'];
            }else if($agentVipInfo['top_zhekou'] < $topZhekou){
                $topZhekou = $agentVipInfo['top_zhekou'];
            }
        }
    }
    $top_zhekou = $topZhekou / 10;
    $top_zhekou = trim($top_zhekou, '.0');
}

$syTotalFabuNum = $syMendianFabuNum + $syAgentFabuNum;

$housesListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_houses")->fetch_all_name(" AND status = 1 AND site_id IN({$sql_in_site_ids}) ", 'ORDER BY id DESC');
$housesList = $housesArr = array();
$i = 0;
if(is_array($housesListTmp) && !empty($housesListTmp)){
    foreach($housesListTmp as $key => $value){
        $housesList[$key] = $value;
        
        $housesArr[$i]['id'] = $value['id'];
        $housesArr[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $i++;
    }
}
$housesData = urlencode(json_encode($housesArr));

if($tcfangchanConfig['open_trade'] == 1){
    $tradeListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_trade")->fetch_all_list(" AND site_id IN({$sql_in_site_ids}) ", 'ORDER BY tsort ASC,id DESC');
    $tradeList = array();
    if(is_array($tradeListTmp) && !empty($tradeListTmp)){
        foreach($tradeListTmp as $key => $value){
            $tradeList[$key] = $value;
        }
    }
}

$freeFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND type = 3  ");
$syFreeFabuNum = $tcfangchanConfig['free_fabu_num'] - $freeFabuCount;
$syFreeFabuNum = intval($syFreeFabuNum);
if($syFreeFabuNum < 0){
    $syFreeFabuNum = 0;
}

$fangchanFabuList = array();
$fangchan_fabu_list_str = str_replace("\r\n","{n}",$tcfangchanConfig['fangchan_fabu_list']);
$fangchan_fabu_list_str = str_replace("\n","{n}",$fangchan_fabu_list_str);
$fangchan_fabu_list_arr = explode("{n}", $fangchan_fabu_list_str);
$i = 0;
if(is_array($fangchan_fabu_list_arr) && !empty($fangchan_fabu_list_arr)){
    foreach ($fangchan_fabu_list_arr as $key => $value){
        $arr = explode("|", $value);
        
        $fangchanFabuList[$key]['days']             = $arr[0];
        $fangchanFabuList[$key]['price']            = $arr[1];
        $fangchanFabuList[$key]['desc']             = $arr[2];
        $fangchanFabuList[$key]['pay_score_status'] = 0;
        $fangchanFabuList[$key]['pay_score']        = 0;
        $fangchanFabuList[$key]['free_status']      = 0;
        
        if($i == 0 && $syFreeFabuNum > 0){
            $fangchanFabuList[$key]['free_status'] = 1;
        }
        
        if($tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $fabu_pay_score = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($fabu_pay_score > 0 && $__UserInfo['score'] >= $fabu_pay_score){
                $fangchanFabuList[$key]['pay_score_status'] = 1;
                $fangchanFabuList[$key]['pay_score'] = $fabu_pay_score;
            }
        }
        $i++;
    }
}

$fangchanTopList = array();
$fangchan_top_list_str = str_replace("\r\n","{n}",$tcfangchanConfig['fangchan_top_list']); 
$fangchan_top_list_str = str_replace("\n","{n}",$fangchan_top_list_str);
$fangchan_top_list_arr = explode("{n}", $fangchan_top_list_str);
if(is_array($fangchan_top_list_arr) && !empty($fangchan_top_list_arr)){
    foreach ($fangchan_top_list_arr as $key => $value){
        $arr = explode("|", $value);
        
        $fangchanTopList[$key]['days']             = $arr[0];
        $fangchanTopList[$key]['price']            = $arr[1];
        $fangchanTopList[$key]['desc']             = $arr[2];
        
        $fangchanTopList[$key]['pay_score_status'] = 0;
        $fangchanTopList[$key]['pay_score'] = 0;
        
        if($topZhekou > 0){
            $fangchanTopList[$key]['desc'] = $fangchanTopList[$key]['desc']."(".$top_zhekou.lang('plugin/tom_tcfangchan', 'zhe').")";
        }
        
        if($tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $top_pay_score = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($top_pay_score > 0){
                $fangchanTopList[$key]['pay_score_status'] = 1;
                $fangchanTopList[$key]['pay_score'] = $top_pay_score;
            }
        }
    }
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$teseTagListTmp = C::t("#tom_tcfangchan#tom_tcfangchan_config_tag")->fetch_all_list(" AND model_id = '{$model_id}' ", 'ORDER BY tsort ASC,id DESC', 0, 30);
$teseTagList = array();
if(is_array($teseTagListTmp) && !empty($teseTagListTmp)){
    foreach($teseTagListTmp as $key => $value){
        $teseTagList[$value['id']] = $value['name'];
    }
}

$__CommonInfo = C::t('#tom_tcfangchan#tom_tcfangchan_common')->fetch_by_id(1);
if(!$__CommonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_common')->insert($insertData);
}
$xieyi_txt = stripslashes($__CommonInfo['xieyi_txt']);

$showMustPhoneBtn = 0;
if($tcfangchanConfig['fangchan_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

if($model_id == 'ershoufang' || $model_id == 'chuzu'){
    $defaultHousesName = '';
    $defaultHousesId = 0;
    $defaultAreaId = 0;
    $defaultAreaName = '';
    $defaultStreetId = 0;
    $defaultStreetName = '';
    $defaultAddress = '';
    $defaultLatitude = '';
    $defaultLongitude = '';
    
    $tcfangchanInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND model_id = '{$model_id}' ", 'ORDER BY id DESC', 0, 1);
    if(is_array($tcfangchanInfoTmp) && !empty($tcfangchanInfoTmp[0])){
        $tcfangchanInfo = $tcfangchanInfoTmp[0];
        $defaultHousesName = $tcfangchanInfo['houses_name'];
        if($tcfangchanConfig['open_houses'] == 1){
            $defaultHousesId = $tcfangchanInfo['houses_id'];
        }
        $defaultAreaId      = $tcfangchanInfo['area_id'];
        $defaultAreaName    = $tcfangchanInfo['area_name'];
        $defaultStreetId    = $tcfangchanInfo['street_id'];
        $defaultStreetName  = $tcfangchanInfo['street_name'];
        $defaultAddress     = $tcfangchanInfo['address'];
        $defaultLatitude    = $tcfangchanInfo['latitude'];
        $defaultLongitude   = $tcfangchanInfo['longitude'];
    }
}

$ossBatchUrl = 'plugin.php?id=tom_tcfangchan:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcfangchan:qiniuBatch';
$jumpUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfangchanlist";
$wxUploadUrl = "plugin.php?id=tom_tcfangchan:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$uploadUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=upload&act=photo&formhash={$formhash}&suffix=";
$ajaxLoadHousesListUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=load_houseslist&formhash=".$formhash;
$payUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&model_id={$model_id}";

if($model_id == 'ershoufang'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:fabu/ershoufang");
    
}else if($model_id == 'chuzu'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:fabu/chuzu");
    
}else if($model_id == 'shangpu'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:fabu/shangpu");
    
}else if($model_id == 'xiezilou'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:fabu/xiezilou");
    
}else if($model_id == 'changfang'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:fabu/changfang");
    
}else if($model_id == 'cangku'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:fabu/cangku");
    
}else if($model_id == 'tudi'){
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcfangchan:fabu/tudi");
    
}else{
    
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
    
}