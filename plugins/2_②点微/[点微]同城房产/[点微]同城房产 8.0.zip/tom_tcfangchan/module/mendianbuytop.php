<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_user_id($__UserInfo['id']);
if(is_array($mendianInfo) && !empty($mendianInfo)){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mymendian");exit;
}

$topZhekou = 0;
if($tcfangchanConfig['open_mendian_vip'] == 1 && $mendianInfo['vip_id'] > 0 && $mendianInfo['expire_status'] == 1 && $mendianInfo['expire_time'] > TIMESTAMP){
    $mendianVipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($mendianInfo['vip_id']);
    if(is_array($mendianVipInfo) && !empty($mendianVipInfo) && $mendianVipInfo['top_zhekou'] > 0){
        $topZhekou = $mendianVipInfo['top_zhekou'];
    }
}
$topZhekou = $topZhekou / 100;

$mendianTopList = array();
$mendian_top_list_str = str_replace("\r\n","{n}",$tcfangchanConfig['mendian_top_list']); 
$mendian_top_list_str = str_replace("\n","{n}",$mendian_top_list_str);
$mendian_top_list_arr = explode("{n}", $mendian_top_list_str);
if(is_array($mendian_top_list_arr) && !empty($mendian_top_list_arr)){
    foreach ($mendian_top_list_arr as $key => $value){
        $arr = explode("|", $value);;
        
        $mendianTopList[$key]['day'] = $arr[0];
        $mendianTopList[$key]['price'] = $arr[1];
        $mendianTopList[$key]['score'] = 0;
        $mendianTopList[$key]['score_pay'] = 0;
        
        if($topZhekou > 0){
            $arr[1] = $arr[1] * $topZhekou;
            $arr[1] = round($arr[1], 2);
            if($arr[1] <= 0){
                $arr[1] = 0.01;
            }
            $mendianTopList[$key]['price'] = $arr[1];
        }
        
        if($tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){

            $scorePayNum = intval($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($scorePayNum > 0 && $__UserInfo['score'] >= $scorePayNum){
                $mendianTopList[$key]['score'] = $scorePayNum;
                $mendianTopList[$key]['score_pay'] = 1;
            }
        }
    }
}

$payTopUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=mendian_top_pay&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:mendianbuytop");