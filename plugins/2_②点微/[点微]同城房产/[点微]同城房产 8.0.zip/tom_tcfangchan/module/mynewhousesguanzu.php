<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$newhouses_id   = intval($_GET['newhouses_id'])>0? intval($_GET['newhouses_id']):0;
$type           = intval($_GET['type'])>0? intval($_GET['type']):2;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;

$newhousesInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses")->fetch_by_id($newhouses_id);
$newhousesManageInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_manage")->fetch_by_user_id($__UserInfo['id']);
if($newhousesManageInfo['id'] > 0 && $__UserInfo['id'] == $newhousesInfo['user_id']){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=my");exit;
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND newhouses_id={$newhouses_id} AND type={$type}";
$order = " ORDER BY id DESC ";
$count = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_guanzu')->fetch_all_count($where);
$guanzuListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_guanzu')->fetch_all_list($where, $order, $start, $pagesize);
$guanzuList = array();
if(is_array($guanzuListTmp) && !empty($guanzuListTmp)){
    foreach ($guanzuListTmp as $key => $value){
        $guanzuList[$key] = $value;
        
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        
        $guanzuList[$key]['userInfo'] = $userInfoTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mynewhousesguanzu&page={$prePage}&type={$type}&newhouses_id={$newhouses_id}";
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mynewhousesguanzu&page={$nextPage}&type={$type}&newhouses_id={$newhouses_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:mynewhousesguanzu");