<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$newhouses_id = intval($_GET['newhouses_id'])>0? intval($_GET['newhouses_id']):0;
$newhousesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_by_id($newhouses_id);
if(is_array($newhousesInfo) && !empty($newhousesInfo)){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
}

$housesTypeStr = '';
if(!empty($newhousesInfo['type'])){
    $housesTypeList = array();
    $typeArr = explode('|', trim($newhousesInfo['type'], '|'));
    if(is_array($houseTypeArr) && !empty($houseTypeArr)){
        foreach($houseTypeArr as $key => $value){
            if(in_array($key, $typeArr)){
                $housesTypeList[] = $value;
            }
        }
        $housesTypeStr = implode(' ', $housesTypeList);
    }
}

$photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND newhouses_id={$newhouses_id} AND type = 1 "," ORDER BY type DESC,psort ASC,id ASC ",0,1);
if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
    $shareLogo = $photoInfoTmp[0]['picurlTmp'];
}

$teseTagsList = array();
if(!empty($newhousesInfo['tese_tags'])){
    $teseTagsList = explode('|', trim($newhousesInfo['tese_tags'], '|'));
}

$disclaimer_text = dhtmlspecialchars($tcfangchanConfig['disclaimer_text']);

$shareTitle = $newhousesInfo['name'];
$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=newhousesinfo&newhouses_id={$newhouses_id}&tjid={$__TjHehuorenId}";

$ajaxUpdateNewHousesClickUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=update_newhouses_clicks&newhouses_id={$newhouses_id}&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:newhousesxiangqing");