<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$needs_type = intval($_GET['needs_type'])>0? intval($_GET['needs_type']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';

$whereStr = " AND user_id = {$__UserInfo['id']} ";
if($needs_type == 1){
    $whereStr.=" AND type = 1 ";
}else if($needs_type == 2){
    $whereStr.=" AND type = 2 ";
}
if($type == 1){
    $whereStr.=" AND status = 1 AND shenhe_status = 1 ";
}else if($type == 2){
    $whereStr.=" AND status != 1 AND shenhe_status = 1 ";
}else if($type == 3){
    $whereStr.=" AND (shenhe_status = 2 OR shenhe_status = 3 ) ";
}

$pagesize     = 8;
$start        = ($page - 1)*$pagesize;
$order        = " ORDER BY refresh_time DESC,id DESC ";
$count        = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_count($whereStr,$keyword);
$needsListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_like_list($whereStr,$order,$start,$pagesize,$keyword);
$needsList = array();
foreach ($needsListTmp as $key => $value){
    $needsList[$key] = $value;
    if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
        $updateData = array();
        $updateData['top_status']   = 0;
        $updateData['top_time']     = 0;
        C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($value['id'], $updateData);
        update_needs_tongcheng($value['id']);
    }
    
    if($value['expire_status'] == 1 && $value['expire_time'] <= TIMESTAMP && $value['top_status'] == 0){
        $updateData = array();
        $updateData['expire_status']    = 2;
        $updateData['expire_time']      = 0;
        $updateData['status']           = 0;
        C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($value['id'], $updateData);
        update_needs_tongcheng($value['id']);
    }
    $userInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $areaInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
    $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
    $needsList[$key]['areaInfo']   = $areaInfoTmp;
    $needsList[$key]['streetInfo'] = $streetInfoTmp;
    $needsList[$key]['userInfo'] = $userInfoTmp;
    $needsList[$key]['expire_time'] = dgmdate($value['expire_time'], 'Y-m-d H:i',$tomSysOffset);
    $needsList[$key]['link']   = 'plugin.php?id=tom_tcfangchan&site='.$value['site_id'].'&mod=needsinfo&needs_id='.$value['id'];
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfabu_needs&type={$type}&page={$prePage}&keyword={$keyword}";
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfabu_needs&type={$type}&page={$nextPage}&keyword={$keyword}";
$pageUrl     = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfabu_needs&type={$type}&keyword={$keyword}";

$ajaxUpdateneedsStatusUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=updateneedsStatus&&formhash=".$formhash;
$ajaxRefreshneedsUrl      = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=refreshNeeds&&formhash=".$formhash;

$back_url = $weixinClass->get_url();
$back_url = urlencode($back_url);

$searchUrl  = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=get_myneedslist_search_url&type={$type}&keyword={$keyword}";
$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tcfangchan&site=".$site_id."&mod=myfabu_needs";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:myfabu_needs");