<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type   = intval($_GET['type'])>0? intval($_GET['type']):0;

if($tcfangchanConfig['open_fabu_needs_money'] == 1){

    $freeFabuCount = C::t("#tom_tcfangchan#tom_tcfangchan_log")->fetch_all_count(" AND user_id = {$__UserInfo['id']} AND type = 7  ");
    $syFreeFabuNum = $tcfangchanConfig['free_fabu_needs_num'] - $freeFabuCount;
    $syFreeFabuNum = intval($syFreeFabuNum);
    if($syFreeFabuNum < 0){
        $syFreeFabuNum = 0;
    }
    
    $needsFabuList = array();
    $needs_fabu_list_str = str_replace("\r\n","{n}",$tcfangchanConfig['needs_fabu_list']);
    $needs_fabu_list_str = str_replace("\n","{n}",$needs_fabu_list_str);
    $needs_fabu_list_arr = explode("{n}", $needs_fabu_list_str);
    $i = 0;
    if(is_array($needs_fabu_list_arr) && !empty($needs_fabu_list_arr)){
        foreach ($needs_fabu_list_arr as $key => $value){
            $arr = explode("|", $value);

            $needsFabuList[$key]['days']             = $arr[0];
            $needsFabuList[$key]['price']            = $arr[1];
            $needsFabuList[$key]['desc']             = $arr[2];
            $needsFabuList[$key]['pay_score_status'] = 0;
            $needsFabuList[$key]['pay_score']        = 0;
            $needsFabuList[$key]['free_status']      = 0;

            if($i == 0 && $syFreeFabuNum > 0){
                $needsFabuList[$key]['free_status'] = 1;
            }

            if($tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                $fabu_pay_score = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
                if($fabu_pay_score > 0 && $__UserInfo['score'] >= $fabu_pay_score){
                    $needsFabuList[$key]['pay_score_status'] = 1;
                    $needsFabuList[$key]['pay_score'] = $fabu_pay_score;
                }
            }
            $i++;
        }
    }
}

$needsTopList = array();
$needs_top_list_str = str_replace("\r\n","{n}",$tcfangchanConfig['needs_top_list']); 
$needs_top_list_str = str_replace("\n","{n}",$needs_top_list_str);
$needs_top_list_arr = explode("{n}", $needs_top_list_str);
if(is_array($needs_top_list_arr) && !empty($needs_top_list_arr)){
    foreach ($needs_top_list_arr as $key => $value){
        $arr = explode("|", $value);
        
        $needsTopList[$key]['days']             = $arr[0];
        $needsTopList[$key]['price']            = $arr[1];
        $needsTopList[$key]['desc']             = $arr[2];
        
        $needsTopList[$key]['pay_score_status'] = 0;
        $needsTopList[$key]['pay_score'] = 0;
        
        if($tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $top_pay_score = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($top_pay_score > 0){
                $needsTopList[$key]['pay_score_status'] = 1;
                $needsTopList[$key]['pay_score'] = $top_pay_score;
            }
        }
    }
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$cityList = array();
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$payUrl  = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}";
$jumpUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myfabu_needs";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:fabu_needs");