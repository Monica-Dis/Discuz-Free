<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword            = isset($_GET['keyword'])? daddslashes(urldecode($_GET['keyword'])):'';
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$min_average_price  = intval($_GET['min_average_price'])>0? intval($_GET['min_average_price']):0;
$max_average_price  = intval($_GET['max_average_price'])>0? intval($_GET['max_average_price']):0;
$house_type         = intval($_GET['house_type'])>0? intval($_GET['house_type']):0;
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):0;
$latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
$longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
$no_houses_id       = intval($_GET['no_houses_id'])>0? intval($_GET['no_houses_id']):0;

$page               = intval($_GET['page'])>0? intval($_GET['page']):0;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND status = 1 AND shenhe_status = 1';
if(!empty($sql_in_site_ids)){
    $whereStr .= " AND site_id IN({$sql_in_site_ids}) ";
}

if($area_id > 0){
    $whereStr.= " AND area_id = {$area_id} ";
}

if($street_id > 0){
    $whereStr .= " AND street_id = {$street_id} ";
}

if($min_average_price > 0){
    $whereStr .= " AND average_price >= {$min_average_price} ";
}

if($max_average_price > 0){
    $whereStr .= " AND average_price <= {$max_average_price} ";
}

if($no_houses_id > 0){
    $whereStr .= " AND id != {$no_houses_id} ";
}

$nearby = 0;
$orderByWhere = "ORDER BY update_time DESC,clicks DESC,id DESC";

if($paixu_type > 0){
    if($paixu_type == 1){
        $nearby = 1;
    }else if($paixu_type == 2){
        $orderByWhere = "ORDER BY average_price ASC,update_time DESC,id DESC";
    }else if($paixu_type == 3){
        $orderByWhere = "ORDER BY average_price DESC,update_time DESC,id DESC";
    }
}

if(empty($latitude)){
    $latitude = getcookie('tom_tongcheng_user_latitude');
    $longitude = getcookie('tom_tongcheng_user_longitude');
}

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
$housesList = array();
if($nearby == 1 && !empty($latitude) && !empty($longitude)){
    $housesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_list($whereStr, $orderByWhere, $start, $pagesize, $keyword , $house_type,$latitude,$longitude);
}else{
    $housesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_all_list($whereStr, $orderByWhere, $start, $pagesize, $keyword , $house_type);
}
if(is_array($housesListTmp) && !empty($housesListTmp)){
    foreach ($housesListTmp as $key => $value) {
        $housesList[$key] = $value;

        $typeList = array();
        if(!empty($value['type'])){
            $typeListTmp = explode('|', trim($value['type'], '|'));
            if(is_array($typeListTmp) && !empty($typeListTmp)){
                foreach ($typeListTmp as $k => $v){
                    if(!empty($v)){
                        $typeList[] = $houseTypeArr[$v];
                    }
                }
            }
        }

        $photoInfoTmp = C::t("#tom_tcfangchan#tom_tcfangchan_photo")->fetch_all_list("AND houses_id = {$value['id']} AND type = 1 ", 'ORDER BY id ASC', 0, 1);
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }else{
            $picurlTmp = $tcfangchanConfig['default_houses_photo'];
        }

        if($value['open_auto_average'] == 1){
            if(TIMESTAMP > ($value['last_auto_time'] + 7 * 86400)){
                $sanMonthTime = TIMESTAMP - 90 * 86400;
                $totalInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_houses_average_price_sum_list(" AND price > 0 AND houses_id = {$value['id']} AND model_id = 'ershoufang' AND refresh_time > {$sanMonthTime} AND shenhe_status = 1 AND status = 1 AND finish = 0 AND (pay_status = 0 OR pay_status = 2) ");
                $average_price_tmp = 0;
                if(is_array($totalInfo) && !empty($totalInfo)){
                    $average_price_tmp = ($totalInfo['totalprice'] * 10000)/$totalInfo['totalmanji'];
                    $average_price_tmp = intval($average_price_tmp);
                    $updateData = array();
                    $updateData['average_price'] = $average_price_tmp;
                    $updateData['last_auto_time'] = TIMESTAMP;
                    C::t('#tom_tcfangchan#tom_tcfangchan_houses')->update($value['id'], $updateData);
                }
                $housesList[$key]['average_price'] = $average_price_tmp;
            }
        }

        $housesList[$key]['typeList']   = $typeList;
        $housesList[$key]['picurl']     = $picurlTmp;
    }
}

if(is_array($housesList) && !empty($housesList)){
    foreach ($housesList as $key => $val) {
        $outStr .= '<a class="houses-list__item dislay-flex" href="plugin.php?id=tom_tcfangchan&site='.$site_id.'&mod=housesinfo&houses_id='.$val['id'].'">';
            $outStr .= '<div class="list-item__lt"><img src="'.$val['picurl'].'"></div>';
            $outStr .= '<div class="list-item__rt flex">';
                $outStr .= '<div class="item-rt__title">'.$val['name'].'</div>';
                $outStr .= '<div class="item-rt__xq">';
                    $outStr .= '<span>'.$val['area_name'].'-'.$val['street_name'].'</span>';
                    if(is_array($val['typeList']) && !empty($val['typeList'])){
                        foreach($val['typeList'] as $k => $v){
                            $outStr .= '<span>'.$v.'</span>';
                        }
                    }
                $outStr .= '</div>';
                if($val['year'] > 0){
                    $outStr .= '<div class="item-rt__year">'.$val['year'].lang('plugin/tom_tcfangchan', 'list_year_jiancheng').'</div>';
                }
                if($val['average_price'] > 0){
                    $outStr .= '<div class="item-rt__price">'.$val['average_price'].lang('plugin/tom_tcfangchan', 'list_price_pingmi_unit').'</div>';
                }else{
                    $outStr .= '<div class="item-rt__price">'.lang('plugin/tom_tcfangchan', 'list_weizhi').'</div>';
                }
            $outStr .= '</div>';
        $outStr .= '</a>';
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;