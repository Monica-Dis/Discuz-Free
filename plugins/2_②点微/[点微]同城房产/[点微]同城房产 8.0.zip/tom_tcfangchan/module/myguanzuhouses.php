<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$where = " AND g.user_id={$__UserInfo['id']}";
$order = " ORDER BY g.id DESC ";

$count = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_guanzu_count($where, $keyword);
$housesListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_houses')->fetch_guanzu_list($where, $order, $start, $pagesize, $keyword);
$housesList = array();
if(is_array($housesListTmp) && !empty($housesListTmp)){
    foreach ($housesListTmp as $key => $value){
        $housesList[$key] = $value;
        
        $typeList = array();
        if(!empty($value['type'])){
            $typeListTmp = explode('|', trim($value['type'], '|'));
            if(is_array($typeListTmp) && !empty($typeListTmp)){
                foreach ($typeListTmp as $k => $v){
                    if(!empty($v)){
                        $typeList[] = $houseTypeArr[$v];
                    }
                }
            }
        }
        
        $photoInfoTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND houses_id = {$value['id']} AND type = 1 ", "ORDER BY id ASC", 0, 1);
        $picurlTmp = '';
        if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
            $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
        }
        
        $housesList[$key]['typeList']   = $typeList;
        $housesList[$key]['picurl']     = $picurlTmp;
    }
}
$housesCount = count($housesList);

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myguanzuhouses&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=myguanzuhouses&page={$nextPage}";

$ajaxCancelGuanzuUrl = "plugin.php?id=tom_tcfangchan:ajax&site={$site_id}&act=cancel_houses_guanzu&formhash=".$formhash;


$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:myguanzuhouses");