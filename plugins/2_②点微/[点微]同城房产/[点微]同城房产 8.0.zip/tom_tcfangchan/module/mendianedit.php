<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$act        = !empty($_GET['act'])? addslashes($_GET['act']):'';
$mendian_id = intval($_GET['mendian_id'])>0? intval($_GET['mendian_id']):0;
$fromlist   = !empty($_GET['fromlist'])? addslashes($_GET['fromlist']):'';
$fromtype   = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
$frompage   = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;

$quanxianStatus = 0;
if($mendian_id > 0){
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($mendian_id);
    if($mendianInfo['user_id'] > 0 && $mendianInfo['user_id'] == $__UserInfo['id']){
        $quanxianStatus = 1;
    }
    # check start
    if($quanxianStatus == 0){
        if($__UserInfo['id'] == $tcfangchanConfig['fcmanage_user_id']){
            $quanxianStatus = 2;
        }else{
            if($__UserInfo['groupid'] == 1){
                $quanxianStatus = 2;
            }else if($__UserInfo['groupid'] == 2){
                if($tcfangchanInfo['site_id'] == $__UserInfo['groupsiteid']){
                    $quanxianStatus = 2;
                }
            }
        }
    }
    # check end
    
}else{
    $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_user_id($__UserInfo['id']);
    if(is_array($mendianInfo) && !empty($mendianInfo)){ 
        $quanxianStatus = 1;
    }
}

if($quanxianStatus == 0){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
}

if($act == "save" && submitcheck('name')){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }

    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name               = dhtmlspecialchars($name);
    $city_id            = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $area_name          = isset($_GET['area_name'])? addslashes($_GET['area_name']):'';
    $area_name          = dhtmlspecialchars($area_name);
    $street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $street_name        = isset($_GET['street_name'])? addslashes($_GET['street_name']):'';
    $street_name        = dhtmlspecialchars($street_name);
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address            = dhtmlspecialchars($address);
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $latitude           = dhtmlspecialchars($latitude);
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $longitude          = dhtmlspecialchars($longitude);
    $business_hours     = isset($_GET['business_hours'])? addslashes($_GET['business_hours']):'';
    $business_hours     = dhtmlspecialchars($business_hours);
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $tel                = dhtmlspecialchars($tel);
    $shopkeeper_tel     = isset($_GET['shopkeeper_tel'])? addslashes($_GET['shopkeeper_tel']):'';
    $shopkeeper_tel     = dhtmlspecialchars($shopkeeper_tel);
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content            = dhtmlspecialchars($content);
    $logo               = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    $logo               = dhtmlspecialchars($logo);
    $business_licence   = isset($_GET['business_licence'])? addslashes($_GET['business_licence']):'';
    $business_licence   = dhtmlspecialchars($business_licence);
    
    $photolist = array();
    if(is_array($_GET['photolist']) && !empty($_GET['photolist'])){
        foreach($_GET['photolist'] as $key => $value){
            if(!empty($value)){
                $photolist[] = addslashes($value);
            }
        }
    }
    
    $updateData = array();
    $updateData['site_id']          = $site_id;
    $updateData['name']             = $name;
    $updateData['city_id']          = $city_id;
    $updateData['area_id']          = $area_id;
    $updateData['area_name']        = $area_name;
    $updateData['street_id']        = $street_id;
    $updateData['street_name']      = $street_name;
    $updateData['address']          = $address;
    $updateData['latitude']         = $latitude;
    $updateData['longitude']        = $longitude;
    $updateData['business_hours']   = $business_hours;
    $updateData['tel']              = $tel;
    $updateData['shopkeeper_tel']   = $shopkeeper_tel;
    $updateData['content']          = $content;
    $updateData['admin_edit']       = 0;
    $updateData['search_text']      = $name.'|++++|'.$tel.'|++++|'.$address;
    if($tcfangchanConfig['mendian_must_shenhe'] == 1){
        $updateData['shenhe_status']    = 2;
    }
    $updateData['part1']            = TIMESTAMP;
    if(C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->update($mendianInfo['id'],$updateData)){
        
        C::t("#tom_tcfangchan#tom_tcfangchan_photo")->delete_by_mendian_id($mendianInfo['id']);
        
        if(!empty($logo)){
            $insertData = array();
            $insertData['mendian_id']       = $mendianInfo['id'];
            $insertData['type']             = 5;
            $insertData['picurl']           = $logo;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        if(is_array($photolist) && !empty($photolist)){
            foreach($photolist as $key => $value){
                $insertData = array();
                $insertData['mendian_id']       = $mendianInfo['id'];
                $insertData['type']             = 6;
                $insertData['picurl']           = $value;
                $insertData['add_time']         = TIMESTAMP;
                C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
            }
        }
        if(!empty($business_licence)){
            $insertData = array();
            $insertData['mendian_id']       = $mendianInfo['id'];
            $insertData['type']             = 7;
            $insertData['picurl']           = $business_licence;
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcfangchan#tom_tcfangchan_photo")->insert($insertData);
        }
        
        if(!empty($tongchengConfig['template_id']) && $tcfangchanConfig['mendian_must_shenhe'] == 1){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'template_ruzhu_mendian_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($fcmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'template_ruzhu_mendian_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }

        if($tcfangchanConfig['mendian_must_shenhe'] == 0){
            update_mendian_tcshop($mendianInfo['id']);
        }

        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }

    $outArr = array(
        'status'=> 1,
    );
    echo json_encode($outArr); exit;
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($mendianInfo['city_id']);
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$photoListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_photo')->fetch_all_list(" AND mendian_id={$mendianInfo['id']} AND type IN (5,6,7) "," ORDER BY type DESC,psort ASC,id ASC ",0,20);
$photoList = array();
$logo = $logo_picurl = $business_licence = $business_licence_picurl = '';
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        if($value['type'] == 5){
            $logo = $value['picurl'];
            $logo_picurl = $value['picurlTmp'];
        }else if($value['type'] == 6){
            $photoList[$key]['picurl'] = $value['picurl'];
            $photoList[$key]['picurlTmp'] = $value['picurlTmp'];
        }else if($value['type'] == 7){
            $business_licence = $value['picurl'];
            $business_licence_picurl = $value['picurlTmp'];
        }
    }
}
$photoCount = count($photoList);

$mendianInfo['content'] = strip_tags($mendianInfo['content']);

if($fromlist == 'managerMendianList'){
    $jumpUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerMendianList&type={$fromtype}&page={$frompage}";
}else{
    $jumpUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mymendian";
}
$saveUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mendianedit&act=save&mendian_id={$mendian_id}";
$ossBatchUrl = 'plugin.php?id=tom_tcfangchan:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcfangchan:qiniuBatch';
$wxUploadUrl = "plugin.php?id=tom_tcfangchan:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$uploadUrl = "plugin.php?id=tom_tcfangchan&site={$site_id}&mod=upload&act=photo&formhash={$formhash}&suffix=";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:mendianedit");