<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$needs_id   = intval($_GET['needs_id'])>0 ?intval($_GET['needs_id']):0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$needsInfo = C::t("#tom_tcfangchan#tom_tcfangchan_needs")->fetch_by_id($needs_id);

if($needsInfo['id'] > 0 && $needsInfo['user_id'] == $__UserInfo['id']){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");exit;
}

$needsTopList = array();
$needs_top_list_str = str_replace("\r\n","{n}",$tcfangchanConfig['needs_top_list']); 
$needs_top_list_str = str_replace("\n","{n}",$needs_top_list_str);
$needs_top_list_arr = explode("{n}", $needs_top_list_str);
if(is_array($needs_top_list_arr) && !empty($needs_top_list_arr)){
    foreach ($needs_top_list_arr as $key => $value){
        $arr = explode("|", $value);;
        
        $needsTopList[$key]['day'] = $arr[0];
        $needsTopList[$key]['price'] = $arr[1];
        $needsTopList[$key]['score'] = 0;
        $needsTopList[$key]['score_pay'] = 0;
        
        if($tcfangchanConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){

            $scorePayNum = intval($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($scorePayNum > 0 && $__UserInfo['score'] >= $scorePayNum){
                $needsTopList[$key]['score'] = $scorePayNum;
                $needsTopList[$key]['score_pay'] = 1;
            }
        }
    }
}

$model_name = '';
if($needsInfo['type'] == 1){
    $model_name = lang('plugin/tom_tcfangchan', 'qiugou');
    
}else if($needsInfo['type'] == 2){
    $model_name = lang('plugin/tom_tcfangchan', 'chuzu');
    
}

$payTopUrl = "plugin.php?id=tom_tcfangchan:pay&site={$site_id}&act=needs_top_pay&back_url=".urlencode($back_url)."&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcfangchan:buyneedstop");