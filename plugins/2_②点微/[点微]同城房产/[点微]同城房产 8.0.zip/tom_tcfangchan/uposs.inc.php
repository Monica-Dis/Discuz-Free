<?php

/*
   Copyright 2001-2099 DisM!Ӧ������.
   ���²����http://t.cn/Aiux1Jx1
   �ƴ���״̬���ýű�
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/plugin');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    DB::query("UPDATE ".DB::table('tom_tcfangchan_photo')." SET qiniu_status=0,oss_status=0 WHERE qiniu_status=1 OR oss_status=1 ", 'UNBUFFERED');

    echo 'oss reset OK';exit;
    
}else{
    exit('Access Denied');
}