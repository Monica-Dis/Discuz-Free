<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);
$tcfangchanConfig   = $_G['cache']['plugin']['tom_tcfangchan'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';

if('utf-8' != CHARSET) {
    if(defined('IN_MOBILE')) {}else{
        foreach($_POST AS $pk => $pv) {
            if(!is_numeric($pv)) {
                $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
            }
        }
    }
}

$share_url      = isset($_GET['share_url'])? daddslashes($_GET['share_url']):'';
$tcfangchan_id  = isset($_GET['tcfangchan_id'])? intval($_GET['tcfangchan_id']):0;
$user_id        = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$firstPhotoUrl  = isset($_GET['firstPhotoUrl'])? daddslashes($_GET['firstPhotoUrl']):'';

$tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($tcfangchan_id);
$userInfo  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
    include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
}else{
    echo 'QR|phpqrcode';exit;
}

if(!preg_match('/^http/', $firstPhotoUrl) ){
    $firstPhotoUrl = DISCUZ_ROOT.$firstPhotoUrl;
}

$firstPhotoUrlImg = DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/data/haibao/'.md5($firstPhotoUrl).'_firstPhotoUrl.png';
$firstPhotoUrlUrl = 'source/plugin/tom_tcfangchan/data/haibao/'.md5($firstPhotoUrl).'_firstPhotoUrl.png';

$qrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/data/haibao/'.md5($share_url).'_qrcode.png';
$qrcodeUrl = 'source/plugin/tom_tcfangchan/data/haibao/'.md5($share_url).'_qrcode.png';

$wxqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/data/haibao/'.md5($share_url).'_wxqrcode'.date("Ymd").'.png';
$wxqrcodeUrl = 'source/plugin/tom_tcfangchan/data/haibao/'.md5($share_url).'_wxqrcode'.date("Ymd").'.png';

$tempDir = "/source/plugin/tom_tcfangchan/data/haibao/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0777); 
}

if(file_exists($firstPhotoUrlImg)){
}else{
    
    if(!preg_match('/^http/', $firstPhotoUrl) ){
        $first_pic_content = file_get_contents($firstPhotoUrl);
    }else{
        $first_pic_content = tom_html_get($firstPhotoUrl);
    }
    
    if(false === file_put_contents($firstPhotoUrlImg,$first_pic_content)){
        $firstPhotoUrlImg = $firstPhotoUrl;
    }
}

$outQrcodeUrl = '';
if($tcfangchanConfig['open_wxqrcode'] == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_weixin/tom_weixin.inc.php')){
    
    $qrcodeKey  = md5($share_url);
    $qrcodeInfo = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_by_qkey($qrcodeKey);
    $qrcodeId = 0;
    if($qrcodeInfo){
        $qrcodeId = $qrcodeInfo['id'];
        $updateData = array();
        $updateData['title']  = $tcfangchanInfo['title'];
        $updateData['picurl'] = $_G['siteurl'].$firstPhotoUrlUrl;
        $updateData['desc']   = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        C::t('#tom_weixin#tom_weixin_qrcode')->update($qrcodeId,$updateData);
    }else{
        $insertData = array();
        $insertData['qkey']     = $qrcodeKey;
        $insertData['title']    = $tcfangchanInfo['title'];
        $insertData['picurl']   = $_G['siteurl'].$firstPhotoUrlUrl;
        $insertData['desc']     = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        $insertData['link']     = $share_url;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_weixin#tom_weixin_qrcode')->insert($insertData);
        $qrcodeId = C::t('#tom_weixin#tom_weixin_qrcode')->insert_id();
    }
    
    if(file_exists($wxqrcodeImg)){
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        $access_token = $weixinClass->get_access_token();

        $dateStr = '{"expire_seconds": 2592000, "action_name": "QR_SCENE", "action_info": {"scene": {"scene_id": '.$qrcodeId.'}}}';
        $response   = tom_html_post($dateStr, 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token);
        $returnData = json_decode($response,true);
        if(isset($returnData['ticket']) &&  !empty($returnData['ticket'])){
            $wx_pic_content = tom_html_get('https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$returnData['ticket']);
            if(false === file_put_contents($wxqrcodeImg,$wx_pic_content)){
            }
        }
    }
    
    $outQrcodeUrl = $wxqrcodeUrl;
}else{
    if(file_exists($qrcodeImg)){
    }else{
        QRcode::png($share_url,$qrcodeImg,'H',5,2);
    }
    $outQrcodeUrl = $qrcodeUrl;
}

echo 'OK|'.$firstPhotoUrlUrl.'|'.$outQrcodeUrl;exit;

function wx_iconv_recurrence($value) {
	if(is_array($value)) {
		foreach($value AS $key => $val) {
			$value[$key] = wx_iconv_recurrence($val);
		}
	} else {
		$value = diconv($value, 'utf-8', CHARSET);
	}
	return $value;
}