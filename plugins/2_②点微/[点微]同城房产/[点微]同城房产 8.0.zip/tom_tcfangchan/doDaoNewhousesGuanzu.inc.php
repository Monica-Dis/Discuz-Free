<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
$tomSysOffset = getglobal('setting/timeoffset');

$fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
if($fangchanSetting && $fangchanSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_setting')->insert($insertData);
    $fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
}

$page           = isset($_GET['page'])? intval($_GET['page']):1;
$type           = isset($_GET['type'])? intval($_GET['type']):1;
$newhouses_id   = isset($_GET['newhouses_id'])? intval($_GET['newhouses_id']):0;
$days           = isset($_GET['days'])? intval($_GET['days']):0;
$from           = isset($_GET['from'])? addslashes($_GET['from']):'';

$where = " AND newhouses_id = {$newhouses_id} ";

if($type > 0){
    $where.= " AND type = {$type} ";
}

if($days > 0){
    $minTime = TIMESTAMP - $days * 86400;
    $where.= " AND add_time > {$minTime} ";
}

$order = "ORDER BY id DESC ";

$pagesize = 1000;
$start = ($page-1)*$pagesize;
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

$quanXianStatus = false;
if($from == 'tom_admin'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_pc.php';
    $adminConfig = $_G['cache']['plugin']['tom_admin'];
    if(!empty($adminConfig['manage_user_id']) && $adminConfig['manage_user_id'] == $__UserInfo['id']){
        $quanXianStatus = true;
    }else{
        $addminManagerInfo = C::t("#tom_admin#tom_admin_manager")->fetch_by_user_id($__UserInfo['id']);
        if(empty($addminManagerInfo)){
            include template("tom_admin:error");exit;
        }
        
        $powerListTmp = C::t("#tom_admin#tom_admin_role_power")->fetch_all_list(" AND plugin_id = 'fangchan' AND role_id={$addminManagerInfo['role_id']} ", "ORDER BY id ASC");
        if(!empty($powerListTmp)){
            foreach($powerListTmp as $key => $value){
                $powerList[] = $value['type'];
            }
        }
        
        if(in_array('newhouses', $powerList)){
            $quanXianStatus = true;
        }
        
    }
}else if($from == 'tom_fcpc'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_pc.php';
    
    $newhousesInfo = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses')->fetch_by_id($newhouses_id);
    $newhousesManageInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_manage")->fetch_by_user_id($__UserInfo['id']);

    if($newhousesManageInfo['id'] > 0 && $__UserInfo['id'] == $newhousesInfo['user_id']){ 
        $quanXianStatus = true;
    }
    
}else{
    if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
        $quanXianStatus = true;
    }
}

if($quanXianStatus === true){
    
    $guanzuListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_guanzu')->fetch_all_list($where,$order,$start,$pagesize);
    $guanzuList = array();
    foreach ($guanzuListTmp as $key => $value) {
        $guanzuList[$key] = $value;
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $guanzuList[$key]['user_id'] = $userInfo['nickname'].'(ID:'.$value['user_id'].')';
        
        if($value['type'] == 1){
            $guanzuList[$key]['type'] = lang('plugin/tom_tcfangchan','doDao_guanzu_type_1');
        }else if($value['type'] == 2){
            $guanzuList[$key]['type'] = lang('plugin/tom_tcfangchan','doDao_guanzu_type_2');
        }else if($value['type'] == 3){
            $guanzuList[$key]['type'] = lang('plugin/tom_tcfangchan','doDao_guanzu_type_3');
        }

        $guanzuList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
        
    }

    $do_user_id = lang('plugin/tom_tcfangchan','user_id');
    $do_type = lang('plugin/tom_tcfangchan','doDao_guanzu_type');
    $do_tel = lang('plugin/tom_tcfangchan','doDao_guanzu_tel');
    $add_time = lang('plugin/tom_tcfangchan','add_time');
    
        
    $listData[] = array(
        $do_user_id,
        $do_type,
        $do_tel,
        $add_time,
    ); 
    foreach ($guanzuList as $v){
        $lineData = array();
        $lineData[] = $v['user_id'];
        $lineData[] = $v['type'];
        $lineData[] = "'".$v['tel'];
        $lineData[] = "'".$v['add_time'];
        $listData[] = $lineData;
    }
    
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=exportNewhousesGuanzu.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}