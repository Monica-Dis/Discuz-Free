<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);

$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tcfangchanConfig = $_G['cache']['plugin']['tom_tcfangchan'];
$tomSysOffset = getglobal('setting/timeoffset');

$fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
if($fangchanSetting && $fangchanSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_setting')->insert($insertData);
    $fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
}

$showQrcode = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
    $showQrcode = 1;
    include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
}

$tempDir = "/source/plugin/tom_tcfangchan/data/infoqrcode/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0755); 
}

include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/config/config.data.php';

$colorArr = array();
$colorArr[1] = 'rgb(236, 75, 10)';
$colorArr[2] = 'rgb(234, 186, 0)';
$colorArr[3] = 'rgb(31, 199, 3)';
$colorArr[4] = 'rgb(3, 199, 137)';
$colorArr[5] = 'rgb(3, 143, 199)';

$page        = isset($_GET['page'])? intval($_GET['page']):1;
$day_type    = isset($_GET['day_type'])? intval($_GET['day_type']):1;
$days        = isset($_GET['days'])? intval($_GET['days']):0;
$type        = isset($_GET['type'])? intval($_GET['type']):1;
$dao_tel     = isset($_GET['dao_tel'])? intval($_GET['dao_tel']):0;

$dao_type    = isset($_GET['dao_type'])? intval($_GET['dao_type']):0;

$site_ids   = isset($_GET['site_ids'])? addslashes($_GET['site_ids']):'';
$site_ids_tmp = explode('_', $site_ids);
$site_ids_arr = array();
if(is_array($site_ids_tmp) && !empty($site_ids_tmp)){
    foreach ($site_ids_tmp as $key => $value){
        $value = intval($value);
        if($value > 0){
            $site_ids_arr[] = $value;
        }
    }
}

$where = " AND shenhe_status = 1 AND status = 1 AND ((pay_status = 0) OR (pay_status = 2)) AND ((expire_status = 1 AND expire_time > ".TIMESTAMP.") OR (expire_status = 3)) ";

if(!empty($site_ids_arr)){
    $where.= " AND site_id IN (".implode(',',$site_ids_arr).") ";
}
if(!empty($type)){
    $where.= " AND type = '{$type}' ";
}

if($days > 0){
    $minTime = TIMESTAMP - $days * 86400;
    if($day_type == 1){
        $where.= " AND (refresh_time > {$minTime} OR top_status = 1 ) ";
    }else{
        $where.= " AND (add_time > {$minTime} OR top_status = 1 ) ";
    }
}

$order = " ORDER BY top_status DESC,refresh_time DESC,id DESC ";
if($day_type == 2){
    $order = " ORDER BY top_status DESC,add_time DESC,id DESC ";
}

$pagesize = 1000;
$start = ($page-1)*$pagesize;
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $needsListTmp = C::t('#tom_tcfangchan#tom_tcfangchan_needs')->fetch_all_list($where,$order,$start,$pagesize);
    $needsList = array();
    foreach ($needsListTmp as $key => $value) {
        $needsList[$key] = $value;
        
        if($value['site_id'] == 1){
            $needsList[$key]['site_id'] = $tongchengConfig['plugin_name'];
        }else if($value['site_id'] == 1){
            $siteList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
            $needsList[$key]['site_id'] = $value['name'];
        }
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $areaInfo   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
        $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
        $needsList[$key]['user_id'] = $userInfo['nickname'].'(ID:'.$value['user_id'].')';
        
        $needsList[$key]['quyu'] = $areaInfo['name'] .'-'.$streetInfo['name'];
        
        if($value['type'] == 1){
            $needsList[$key]['type'] = lang('plugin/tom_tcfangchan','qiugou');
        }elseif($value['type'] == 2){
            $needsList[$key]['type'] = lang('plugin/tom_tcfangchan','qiuzu');
        }
        
        $infoqrcodeUrl = '';
        if($showQrcode == 1){
            $infoUrlTmp = $_G['siteurl'].'plugin.php?id=tom_tcfangchan&site='.$value['site_id'].'&mod=needsinfo&needs_id='.$value['id'];
            $infoqrcodeUrl = 'source/plugin/tom_tcfangchan/data/infoqrcode/'.md5($infoUrlTmp).'.png';
            $infoqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/data/infoqrcode/'.md5($infoUrlTmp).'.png';
            if(file_exists($infoqrcodeImg)){
            }else{
                QRcode::png($infoUrlTmp,$infoqrcodeImg,'H',5,2);
            }
        }
        $needsList[$key]['qrcode'] = $infoqrcodeUrl;
    }
    
    $doDao_site_id = lang('plugin/tom_tcfangchan','sites_title');
    $doDao_content = lang('plugin/tom_tcfangchan','doDao_needs_content');
    $doDao_user_id = lang('plugin/tom_tcfangchan','user_id');
    $doDao_type = lang('plugin/tom_tcfangchan','doDao_type');
    $doDao_quyu = lang('plugin/tom_tcfangchan','doDao_quyu');
    $doDao_address = lang('plugin/tom_tcfangchan','doDao_address');
    $doDao_xm = lang('plugin/tom_tcfangchan','doDao_xm');
    $doDao_tel = lang('plugin/tom_tcfangchan','doDao_tel');
    $doDao_wx = lang('plugin/tom_tcfangchan','doDao_wx');
    
    if($dao_type == 1){

        $listData = array();
        if($type == 1){

            $listData[] = array(
                'ID',
                $doDao_site_id,
                $doDao_content,
                $doDao_user_id,
                $doDao_type,
                $doDao_quyu,
                $doDao_address,
                $doDao_xm,
                $doDao_tel,
                $doDao_wx,
            ); 
            foreach ($needsList as $v){
                $lineData = array();
                $lineData[] = $v['id'];
                $lineData[] = $v['site_id'];
                $lineData[] = $v['content'];
                $lineData[] = $v['user_id'];
                $lineData[] = $v['type'];
                $lineData[] = $v['quyu'];
                $v['address'] = str_replace("\r\n", "", $v['address']);
                $v['address'] = str_replace("\n", "", $v['address']);
                $lineData[] = $v['address'];
                $lineData[] = $v['xm'];
                $lineData[] = "'".$v['tel'];
                $lineData[] = "'".$v['wx'];
                $listData[] = $lineData;
            }
        }else if($type == 2){

            $listData[] = array(
                'ID',
                $doDao_site_id,
                $doDao_content,
                $doDao_user_id,
                $doDao_type,
                $doDao_quyu,
                $doDao_address,
                $doDao_xm,
                $doDao_tel,
                $doDao_wx,
            );
            foreach ($needsList as $v){
                $lineData = array();
                $lineData[] = $v['id'];
                $lineData[] = $v['site_id'];
                $lineData[] = $v['content'];
                $lineData[] = $v['user_id'];
                $lineData[] = $v['type'];
                $lineData[] = $v['quyu'];
                $v['address'] = str_replace("\r\n", "", $v['address']);
                $v['address'] = str_replace("\n", "", $v['address']);
                $lineData[] = $v['address'];
                $lineData[] = $v['xm'];
                $lineData[] = "'".$v['tel'];
                $lineData[] = "'".$v['wx'];
                $listData[] = $lineData;
            }

        }
        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition:filename=exportNeeds.xls");

        foreach ($listData as $fields){
            foreach ($fields as $k=> $v){
                $str = @diconv("$v",CHARSET,"GB2312");
                echo $str ."\t";
            }
            echo "\n";
        }
        exit;
        
    }else if($dao_type == 2){
        
        $fenhao = lang('plugin/tom_tcfangchan', 'fenghao');
        
        if (CHARSET == 'gbk'){
            $outStr = '<meta charset="gbk" /> ';
        }else{
            $outStr = '<meta charset="utf-8" /> ';
        }
        $outStr.= '<section style="font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px;">';
             $outStr.= '<p style="white-space: normal;"><br /></p> ';
             $outStr.= '<p style="max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);">';
               $outStr.= '<span style="max-width: 100%; color: rgb(255, 255, 255); box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(236, 101, 5);">'.lang('plugin/tom_tongcheng', 'doDao_msg1').'</span>';
             $outStr.= '</p> ';
             $outStr.= '<p style="max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);"> ';
               $outStr.= '<span style="max-width: 100%; color: rgb(255, 255, 255); box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(236, 101, 5);">'.lang('plugin/tom_tongcheng', 'doDao_msg2').'</span> ';
             $outStr.= '</p> ';
             $outStr.= '<p style="max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);">'; 
               $outStr.= '<span style="max-width: 100%; color: rgb(236, 101, 5); font-size: 12px; line-height: 19.2px; box-sizing: border-box !important; word-wrap: break-word !important;">'.lang('plugin/tom_tongcheng', 'doDao_jian').'</span> ';
             $outStr.= '</p> ';
             $outStr.= '<p style="margin: 0px;max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);">';
               $outStr.= '<img style="max-width: 60%;" src="'.$tongchengConfig['fwh_qrcode'].'"/>';
             $outStr.= '</p> <br /> ';
        $outStr.= '</section> ';

        $outStr.= '<section style="margin: 2em 0em; padding: 0.5em 0.8em; white-space: normal; border: 1px solid '.$colorArr[1].';border-radius: 6px; font-size: 1em; font-family: inherit; font-weight: inherit; text-decoration: inherit; color: rgb(166, 166, 166); background-color: rgb(255, 255, 255);"> ';
            $outStr.= '<section style="margin-top: -1.4em; text-align: center; border: none; line-height: 1.4;"> ';
               $outStr.= '<section style="padding-right: 24px; padding-left: 24px; color: '.$colorArr[1].'; font-size: 30px; font-family: inherit; text-decoration: inherit; border-color: rgb(255, 255, 255); display: inline-block; background-color: rgb(254, 255, 255); "> ';
                  if($type == 1){
                      $outStr.= '<section>'.lang('plugin/tom_tcfangchan', 'qiugou').'</section> ';
                  }else if($type == 2){
                      $outStr.= '<section>'.lang('plugin/tom_tcfangchan','qiuzu' ).'</section> ';
                  }
               $outStr.= '</section> ';
            $outStr.= '</section> ';
            $outStr.= '<section style="padding: 16px 0px; color: rgb(32, 32, 32); line-height: 2; font-family: inherit;"> ';
            
            $color_i = 2;
            foreach ($needsList as $key => $value){
                $content = lang('plugin/tom_tongcheng', 'doDao_left').$value['content'].lang('plugin/tom_tongcheng', 'doDao_right');
                $top_status_text = '';
                if($value['top_status'] == 1 && $value['top_time'] > TIMESTAMP){
                    $top_status_text = '<span style="color:#f00;">'.lang('plugin/tom_tongcheng', 'doDao_left').lang('plugin/tom_tongcheng', 'doDao_top_title').lang('plugin/tom_tongcheng', 'doDao_right').'</span>';
                }
                
                $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                    $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;"><span style="color: '.$colorArr[$color_i].';">'.lang('plugin/tom_tongcheng', 'doDao_jian').$top_status_text.$content.'</span></span> ';
                $outStr.= '</p> ';
                
                if($dao_tel == 1){
                    $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                        $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$doDao_tel.$fenhao.$value['tel'].'</span> ';
                    $outStr.= '</p> ';
                }
                $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                    $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$doDao_wx.$fenhao.$value['wx'].'</span> ';
                $outStr.= '</p> ';
                $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                    $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$doDao_address.$fenhao.$value['address'].'</span> ';
                $outStr.= '</p> ';
                
                if(!empty($value['qrcode'])){
                    $outStr.= '<span style="display: block;text-align: center;"><img style="width:120px;" src="'.$value['qrcode'].'"/></span> ';
                    $outStr.= '<span style="display: block;text-align: center;color:#999;font-size: 12px;">'.lang('plugin/tom_tongcheng', 'doDao_qrcode_msg').'</span> ';
                }
                
                $color_i++;
                if($color_i == 6){
                    $color_i = 1;
                }
            }
            $outStr.= '</section>';
        $outStr.= '</section>';
        
        $doDao_msg3 = lang('plugin/tom_tongcheng', 'doDao_msg3');
        $doDao_msg3 = str_replace('{SITENAME}', $tongchengConfig['plugin_name'], $doDao_msg3);
        $outStr.= '<span style="color:#999;font-size: 14px;"><span style="color:red"> '.lang('plugin/tom_tongcheng', 'doDao_msg_mz').'</span><br /> '.$doDao_msg3.'</span><br /><br />';
        
        echo $outStr;
        exit;
    }
}else{
    exit('Access Denied');
}