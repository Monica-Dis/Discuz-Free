<?php

/*
   Copyright 2001-2099 DisM!Ӧ������.
   ���²����http://t.cn/Aiux1Jx1
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tcfangchanConfig   = $_G['cache']['plugin']['tom_tcfangchan'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset       = getglobal('setting/timeoffset');
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);

$fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
if($fangchanSetting && $fangchanSetting['id'] > 0){}else{
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcfangchan#tom_tcfangchan_setting')->insert($insertData);
    $fangchanSetting = C::t('#tom_tcfangchan#tom_tcfangchan_setting')->fetch_by_id(1);
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass        = new weixinClass($appid,$appsecret);

$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcadmin start
$__ShowTcadmin = 0;
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
    if($tcadminConfig['open_fc'] == 1){
        $__ShowTcadmin = 1;
    }
}
## tcadmin end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcfangchan/class/function.core.php';

$tongbuParamArr = array();
$tongbuParamArr['tcfangchanConfig']     = $tcfangchanConfig;
$tongbuParamArr['tongchengConfig']      = $tongchengConfig;
$tongbuParamArr['zhuangxiuTypeArr']     = $zhuangxiuTypeArr;
$tongbuParamArr['houseTypeArr']         = $houseTypeArr;
$tongbuParamArr['chaoxiangTypeArr']     = $chaoxiangTypeArr;
$tongbuParamArr['rentTypeArr']          = $rentTypeArr;
$tongbuParamArr['shangpuTypeArr']       = $shangpuTypeArr;
$tongbuParamArr['rentUnitArr']          = $rentUnitArr;

$orderInfo = C::t('#tom_tcfangchan#tom_tcfangchan_order')->fetch_by_order_no($order_no);
if($orderInfo && $orderInfo['order_status'] == 1){
    
    $updateData = array();
    $updateData['order_status'] = 2;
    $updateData['pay_time'] = TIMESTAMP;
    C::t('#tom_tcfangchan#tom_tcfangchan_order')->update($orderInfo['id'],$updateData);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
    
    if($orderInfo['type'] == 1){
        $tcfangchanInfo = C::t('#tom_tcfangchan#tom_tcfangchan')->fetch_by_id($orderInfo['tcfangchan_id']); 
        
        $updateData = array();
        if($orderInfo['top_days'] > 0){
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
            
            $updateData['top_status']   = 1;
            $updateData['top_time']     = $top_time;
        }
        
        if($tcfangchanInfo['source_type'] == 1){
            $updateData['expire_status']   = 3;
        }else if($tcfangchanInfo['source_type'] == 2 && $orderInfo['fabu_days'] > 0){
            $fabu_time = $orderInfo['fabu_days'] * 86400 + TIMESTAMP;
            
            $updateData['expire_status']   = 1;
            $updateData['expire_time']     = $fabu_time;
        }
        if($tcfangchanConfig['fangchan_must_shenhe'] == 0){
            $updateData['status']           = 1;
        }
        $updateData['pay_status']       = 2;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($orderInfo['tcfangchan_id'],$updateData);
        
        update_fangchan_tongcheng($orderInfo['tcfangchan_id'],$tongbuParamArr);
        
    }else if($orderInfo['type'] == 2){
        
        $tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($orderInfo['tcfangchan_id']);
        if($tcfangchanInfo['top_time'] > TIMESTAMP){
            $top_time = $orderInfo['top_days'] * 86400 + $tcfangchanInfo['top_time'];
        }else{
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($orderInfo['tcfangchan_id'], $updateData);
        
        update_fangchan_tongcheng($orderInfo['tcfangchan_id'],$tongbuParamArr);
        
    }else if($orderInfo['type'] == 3){
        
        $tcfangchanInfo = C::t("#tom_tcfangchan#tom_tcfangchan")->fetch_by_id($orderInfo['tcfangchan_id']);
        if($tcfangchanInfo['expire_time'] > TIMESTAMP){
            $fabu_time = $orderInfo['fabu_days'] * 86400 + $tcfangchanInfo['expire_time'];
        }else{
            $fabu_time = $orderInfo['fabu_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        if($tcfangchanInfo['source_type'] == 1){
            $updateData['expire_status']   = 3;
        }else{
            $updateData['expire_status']   = 1;
            $updateData['expire_time']     = $fabu_time;
        }
        $updateData['pay_type']         = 2;
        $updateData['status']           = 1;
        $updateData['refresh_time']     = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($orderInfo['tcfangchan_id'], $updateData);
        
        update_fangchan_tongcheng($orderInfo['tcfangchan_id'],$tongbuParamArr);
        
    }else if($orderInfo['type'] == 4){
        
        $updateData = array();
        $updateData['refresh_time']     = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan')->update($orderInfo['tcfangchan_id'], $updateData);
        
        update_fangchan_tongcheng($orderInfo['tcfangchan_id'],$tongbuParamArr);
        
    }else if($orderInfo['type'] == 5){
        
        $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_user_id($userInfo['id']);
        $vipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian_vip")->fetch_by_id($orderInfo['mendian_vip_id']);
        if($mendianInfo['expire_time'] > TIMESTAMP){
            $vip_time = $vipInfo['days'] * 86400 + $mendianInfo['expire_time'];
        }else{
            $vip_time = $vipInfo['days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['vip_id']          = $vipInfo['id'];
        $updateData['expire_status']   = 1;
        $updateData['expire_time']     = $vip_time;
        $updateData['vip_add_time']    = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendianInfo['id'], $updateData);
        
    }else if($orderInfo['type'] == 6){
        
        $mendianInfo = C::t("#tom_tcfangchan#tom_tcfangchan_mendian")->fetch_by_id($orderInfo['mendian_id']);
        if($mendianInfo['top_time'] > TIMESTAMP){
            $top_time = $orderInfo['top_days'] * 86400 + $mendianInfo['top_time'];
        }else{
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->update($mendianInfo['id'], $updateData);
        
    }else if($orderInfo['type'] == 7){
        
        $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($userInfo['id']);
        $vipInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent_vip")->fetch_by_id($orderInfo['agent_vip_id']);
        if($agentInfo['expire_time'] > TIMESTAMP){
            $vip_time = $vipInfo['days'] * 86400 + $agentInfo['expire_time'];
        }else{
            $vip_time = $vipInfo['days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['vip_id']          = $vipInfo['id'];
        $updateData['expire_status']   = 1;
        $updateData['expire_time']     = $vip_time;
        $updateData['vip_add_time']    = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($agentInfo['id'], $updateData);
        
    }else if($orderInfo['type'] == 8){
        
        $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_id($orderInfo['agent_id']);
        if($agentInfo['top_time'] > TIMESTAMP){
            $top_time = $orderInfo['top_days'] * 86400 + $agentInfo['top_time'];
        }else{
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcfangchan#tom_tcfangchan_agent')->update($agentInfo['id'], $updateData);
        
    }else if($orderInfo['type'] == 9){
        
        $adviserInfo = C::t("#tom_tcfangchan#tom_tcfangchan_newhouses_adviser")->fetch_by_id($orderInfo['adviser_id']);
        if($adviserInfo['expire_time'] > TIMESTAMP){
            $fabu_time = $orderInfo['fabu_days'] * 86400 + $adviserInfo['expire_time'];
        }else{
            $fabu_time = $orderInfo['fabu_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['pay_status']       = 2;
        $updateData['expire_status']    = 1;
        $updateData['expire_time']      = $fabu_time;
        C::t('#tom_tcfangchan#tom_tcfangchan_newhouses_adviser')->update($orderInfo['adviser_id'], $updateData);
        
    }else if($orderInfo['type'] == 10){
        $updateData = array();
        if($orderInfo['top_days'] > 0){
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
            
            $updateData['top_status']   = 1;
            $updateData['top_time']     = $top_time;
        }
        
        if($orderInfo['fabu_days'] > 0){
            $fabu_time = $orderInfo['fabu_days'] * 86400 + TIMESTAMP;
            
            $updateData['expire_status']   = 1;
            $updateData['expire_time']     = $fabu_time;
        }
        $updateData['status']           = 1;
        $updateData['pay_status']       = 2;
        C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($orderInfo['needs_id'],$updateData);
        update_needs_tongcheng($orderInfo['needs_id'],$tongbuParamArr);
        
    }else if($orderInfo['type'] == 12){
        
        $needsInfo = C::t("#tom_tcfangchan#tom_tcfangchan_needs")->fetch_by_id($orderInfo['needs_id']);
        if($needsInfo['top_time'] > TIMESTAMP){
            $top_time = $orderInfo['top_days'] * 86400 + $needsInfo['top_time'];
        }else{
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($orderInfo['needs_id'], $updateData);
        update_needs_tongcheng($orderInfo['needs_id'],$tongbuParamArr);
        
    }else if($orderInfo['type'] == 13){
        
        $needsInfo = C::t("#tom_tcfangchan#tom_tcfangchan_needs")->fetch_by_id($orderInfo['needs_id']);
        if($needsInfo['expire_time'] > TIMESTAMP){
            $fabu_time = $orderInfo['fabu_days'] * 86400 + $needsInfo['expire_time'];
        }else{
            $fabu_time = $orderInfo['fabu_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['expire_status']   = 1;
        $updateData['expire_time']     = $fabu_time;
        $updateData['status']           = 1;
        $updateData['refresh_time']     = TIMESTAMP;
        C::t('#tom_tcfangchan#tom_tcfangchan_needs')->update($orderInfo['needs_id'], $updateData);
        update_needs_tongcheng($orderInfo['needs_id'],$tongbuParamArr);
        
    }
        
    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($orderInfo['order_no'])));

    if($tcfangchanConfig['open_back_score'] == 1){
        
        $score_yuan = $tongchengConfig['score_yuan'];
        
        $score = ceil($orderInfo['pay_price']*$score_yuan);
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] + $score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 34;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    }
    
    # fc start
    $adminFc = false;
    if($__ShowTchehuoren == 1 && $userInfo['tj_hehuoren_id'] > 0){

        $shenyu_money = $orderInfo['pay_price'];
        $child_site_fc_money = $tchehuoren_fc_money = $tctchehuorenParent_fc_money = 0;
        
        $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($userInfo['tj_hehuoren_id']);
        if($tchehuorenInfo){
            $tchehuorenDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
            $tchehuorenUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tchehuorenInfo['openid']);
        }
        
        $tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
        if($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1){
            $tctchehuorenParentInfo = C::t("#tom_tchehuoren#tom_tchehuoren")->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
            $tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
            $tctchehuorenParentUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tctchehuorenParentInfo['openid']);
        }
        
        if($tchehuorenInfo && $tchehuorenInfo['status'] == 1 && $tchehuorenDengji['fc_fc_open'] == 1){
            if($orderInfo['site_id'] > 1 && $tcfangchanConfig['zizhandi_fc'] == 1){
                $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                $sitename = $sitesInfo['name'];
                if($__ShowTcadmin && $sitesInfo['hehuoren_fc_open'] == 1){
                    
                    $tchehuoren_fc_money = $orderInfo['pay_price'] * ($tchehuorenDengji['fc_fc_scale']/100);
                    $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2, '.', '');
                    
                    $fc_scale = $tcadminConfig['fc_scale'];
                    if($sitesInfo['fc_fc_scale'] > 0){
                        $fc_scale = $sitesInfo['fc_fc_scale'];
                    }
                    $child_site_fc_money = $orderInfo['pay_price'] * ($fc_scale/100);
                    $child_site_fc_money = number_format($child_site_fc_money,2, '.', '');
                    $child_site_fc_money = $child_site_fc_money - $tchehuoren_fc_money;
                    
                    if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                        $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                        if($tchehuorenConfig['subordinate_moneytype'] == 1){
                            $child_site_fc_money   = $child_site_fc_money - $tctchehuorenParent_fc_money;
                        }else{
                            $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                        }
                    }
                    
                    $shenyu_money = $shenyu_money - $child_site_fc_money - $tchehuoren_fc_money;

                }else{
                    if($__ShowTcadmin == 1 && $tcfangchanConfig['zizhandi_fc'] == 1){
                        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                        $fc_scale = $tcadminConfig['fc_scale'];
                        if($sitesInfo['fc_fc_scale'] > 0){
                            $fc_scale = $sitesInfo['fc_fc_scale'];
                        }
                        $child_site_fc_money = $orderInfo['pay_price'] * ($fc_scale/100);
                        $child_site_fc_money = number_format($child_site_fc_money,2, '.', '');
                    }
                    
                    $shenyu_money = $shenyu_money - $child_site_fc_money;
                    
                }
                
            }else{
                $sitename = $tcfangchanConfig['plugin_name'];
                $tchehuoren_fc_money = $orderInfo['pay_price'] * ($tchehuorenDengji['fc_fc_scale']/100);
                $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2, '.', '');
                
                if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                    $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                    $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                    if($tchehuorenConfig['subordinate_moneytype'] == 1){
                    }else{
                        $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                    }
                }
                
                $shenyu_money = $shenyu_money - $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
            }
            
            Log::DEBUG("update shenyu_money:" . $shenyu_money);
            Log::DEBUG("update child_site_fc_money:" . $child_site_fc_money);
            Log::DEBUG("update tchehuoren_fc_money:" . $tchehuoren_fc_money);
            Log::DEBUG("update TCtchehuoren_fc_money:" . $tctchehuorenParent_fc_money);
            
            if($orderInfo['pay_price'] >= ($child_site_fc_money +  $tchehuoren_fc_money + $tctchehuorenParent_fc_money)){  
                
                $mendianInfo = C::t('#tom_tcfangchan#tom_tcfangchan_mendian')->fetch_by_user_id($orderInfo['user_id']);
                
                $content = '';
                if($orderInfo['type'] == 1 || $orderInfo['type'] == 2 || $orderInfo['type'] == 3 || $orderInfo['type'] == 4){
                    $content = lang('plugin/tom_tcfangchan', 'paynotify_fangchan_hehuoren_beizu_1') . $orderInfo['tcfangchan_id'] . lang('plugin/tom_tcfangchan', 'paynotify_hehuoren_beizu_2') . $userInfo['nickname'];
                }else if($orderInfo['type'] == 5 || $orderInfo['type'] == 6){
                    $content = lang('plugin/tom_tcfangchan', 'paynotify_mendian_hehuoren_beizu_1') . $mendianInfo['id'] . lang('plugin/tom_tcfangchan', 'paynotify_hehuoren_beizu_2') . $userInfo['nickname'];
                }else if($orderInfo['type'] == 10 || $orderInfo['type'] == 12 || $orderInfo['type'] == 13){
                    $content = lang('plugin/tom_tcfangchan', 'paynotify_needs_hehuoren_beizu_1') . $orderInfo['needs_id'] . lang('plugin/tom_tcfangchan', 'paynotify_hehuoren_beizu_2') . $userInfo['nickname'];
                }
                
                if($child_site_fc_money > 0){
                    $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);
                    
                    $old_money = 0;
                    if($walletInfo){
                        $old_money = $walletInfo['account_balance'];

                        $updateData = array();
                        $updateData['account_balance']  = $walletInfo['account_balance'] + $child_site_fc_money;
                        $updateData['total_income']     = $walletInfo['total_income'] + $child_site_fc_money;
                        C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
                    }else{
                        $insertData = array();
                        $insertData['site_id']              = $orderInfo['site_id'];
                        $insertData['account_balance']      = $child_site_fc_money;
                        $insertData['total_income']         = $child_site_fc_money;
                        $insertData['add_time']             = TIMESTAMP;
                        C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
                    }

                    $insertData = array();
                    $insertData['site_id']      = $orderInfo['site_id'];
                    $insertData['log_type']     = 1;
                    $insertData['change_money'] = $child_site_fc_money;
                    $insertData['old_money']    = $old_money;
                    $insertData['beizu']        = $content;
                    $insertData['order_no']     = $orderInfo['order_no'];
                    $insertData['order_type']   = $orderInfo['type'];
                    $insertData['log_ip']       = $_G['clientip'];
                    $insertData['log_time']     = TIMESTAMP;
                    C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData); 
                }
                
                $type = '';
                if($orderInfo['type'] == 1){
                    $type = lang('plugin/tom_tcfangchan', 'order_type_1');
                }else if($orderInfo['type'] == 2){
                    $type = lang('plugin/tom_tcfangchan', 'order_type_2');
                }else if($orderInfo['type'] == 3){
                    $type = lang('plugin/tom_tcfangchan', 'order_type_3');
                }else if($orderInfo['type'] == 4){
                    $type = lang('plugin/tom_tcfangchan', 'order_type_4');
                }else if($orderInfo['type'] == 5){
                    $type = lang('plugin/tom_tcfangchan', 'order_type_5');
                }else if($orderInfo['type'] == 6){
                    $type = lang('plugin/tom_tcfangchan', 'order_type_6');
                }else if($orderInfo['type'] == 7){
                    $type = lang('plugin/tom_tcfangchan', 'order_type_7');
                }else if($orderInfo['type'] == 8){
                    $type = lang('plugin/tom_tcfangchan', 'order_type_8');
                }else if($orderInfo['type'] == 10){
                    $type = lang('plugin/tom_tcfangchan', 'order_type_10');
                }else if($orderInfo['type'] == 11){
                    $type = lang('plugin/tom_tcfangchan', 'order_type_11');
                }else if($orderInfo['type'] == 12){
                    $type = lang('plugin/tom_tcfangchan', 'order_type_12');
                }else if($orderInfo['type'] == 13){
                    $type = lang('plugin/tom_tcfangchan', 'order_type_13');
                }
                
                $sendTemplateTchehuoren = false;
                if($tchehuoren_fc_money > 0){
                    $sendTemplateTchehuoren = true;
                    
                    $insertData = array();
                    $insertData['order_no']         = $orderInfo['order_no'];
                    $insertData['hehuoren_id']      = $tchehuorenInfo['id'];
                    $insertData['ly_user_id']       = $userInfo['id'];
                    $insertData['child_hehuoren_id'] = 0;
                    $insertData['today_time']       = $nowDayTime;
                    $insertData['week_time']        = $nowWeekTime;
                    $insertData['month_time']       = $nowMonthTime;
                    $insertData['type']             = $type;
                    $insertData['shouyi_price']     = $tchehuoren_fc_money;
                    $insertData['content']          = $content;
                    $insertData['shouyi_status']    = 1;
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                }
                
                $sendTemplateTchehuorenParent = false;
                if($tctchehuorenParent_fc_money > 0){
                    $sendTemplateTchehuorenParent = true;
                    
                    $insertData = array();
                    $insertData['order_no']         = $orderInfo['order_no'];
                    $insertData['hehuoren_id']      = $tctchehuorenParentInfo['id'];
                    $insertData['ly_user_id']       = $userInfo['id'];
                    $insertData['child_hehuoren_id'] = $tchehuorenInfo['id'];
                    $insertData['today_time']       = $nowDayTime;
                    $insertData['week_time']        = $nowWeekTime;
                    $insertData['month_time']       = $nowMonthTime;
                    $insertData['type']             = $type;
                    $insertData['shouyi_price']     = $tctchehuorenParent_fc_money;
                    $insertData['content']          = $content;
                    $insertData['shouyi_status']    = 1;
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                }
                
                if($sendTemplateTchehuoren == true){
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($tchehuorenInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                        $shouyiText = str_replace("{NICKNAME}",$userInfo['nickname'], lang('plugin/tom_tongcheng', 'paynotify_hehuoren_template'));
                        $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                        $shouyiText = str_replace("{TYPE}",$type, $shouyiText);
                        $shouyiText = str_replace("{MONEY}",$tchehuoren_fc_money, $shouyiText);
                        $smsData = array(
                            'first'         => $shouyiText,
                            'keyword1'      => $tchehuorenConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );
                        if(!empty($tchehuorenConfig['template_id'])){
                            $template_id = $tchehuorenConfig['template_id'];
                        }else{
                            $template_id = $tongchengConfig['template_id'];
                        }
                        @$r = $templateSmsClass->sendSms01($tchehuorenInfo['openid'], $template_id, $smsData);
                    }
                }
                
                if($sendTemplateTchehuorenParent == true){
                    
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($tctchehuorenParentInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                        $shouyiText = str_replace("{TCHEHUOREN}",$tchehuorenInfo['xm'], lang('plugin/tom_tongcheng', 'paynotify_hehuorenparent_template'));
                        $shouyiText = str_replace("{NICKNAME}",$userInfo['nickname'], $shouyiText);
                        $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                        $shouyiText = str_replace("{TYPE}",$type, $shouyiText);
                        $shouyiText = str_replace("{MONEY}",$tctchehuorenParent_fc_money, $shouyiText);
                        $smsData = array(
                            'first'         => $shouyiText,
                            'keyword1'      => $tchehuorenConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );
                        if(!empty($tchehuorenConfig['template_id'])){
                            $template_id = $tchehuorenConfig['template_id'];
                        }else{
                            $template_id = $tongchengConfig['template_id'];
                        }
                        @$r = $templateSmsClass->sendSms01($tctchehuorenParentInfo['openid'], $template_id, $smsData);
                    }
                }
            }
            
        }else{
            $adminFc = true;
        }
    }else{
        $adminFc = true;
    }
    
    if($__ShowTcadmin == 1 && $adminFc && $tcfangchanConfig['zizhandi_fc'] == 1){

        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
        $fc_scale = $tcadminConfig['fc_scale'];
        if($sitesInfo['fc_fc_scale'] > 0){
            $fc_scale = $sitesInfo['fc_fc_scale'];
        }
        $fc_money = $orderInfo['pay_price']*($fc_scale/100);
        $fc_money = number_format($fc_money,2, '.', '');

        Log::DEBUG("update fc_money:" . $fc_money);

        $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);

        $old_money = 0;
        if($walletInfo){
            $old_money = $walletInfo['account_balance'];

            $updateData = array();
            $updateData['account_balance']   = $walletInfo['account_balance'] + $fc_money;
            $updateData['total_income']   = $walletInfo['total_income'] + $fc_money;
            C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
        }else{
            $insertData = array();
            $insertData['site_id']              = $orderInfo['site_id'];
            $insertData['account_balance']      = $fc_money;
            $insertData['total_income']         = $fc_money;
            $insertData['add_time']             = TIMESTAMP;
            C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
        }
        
        $beizu = '';
        if($orderInfo['type'] == 1 || $orderInfo['type'] == 2 || $orderInfo['type'] == 3 || $orderInfo['type'] == 4){
            $beizu = lang('plugin/tom_tcfangchan', 'paynotify_fangchan_hehuoren_beizu_1') . $orderInfo['tcfangchan_id'] . lang('plugin/tom_tcfangchan', 'paynotify_hehuoren_beizu_2') . $userInfo['nickname'];
        }else if($orderInfo['type'] == 5 || $orderInfo['type'] == 6){
            $beizu = lang('plugin/tom_tcfangchan', 'paynotify_mendian_hehuoren_beizu_1') . $mendianInfo['id'] . lang('plugin/tom_tcfangchan', 'paynotify_hehuoren_beizu_2') . $userInfo['nickname'];
        }

        $insertData = array();
        $insertData['site_id']      = $orderInfo['site_id'];
        $insertData['log_type']     = 1;
        $insertData['change_money'] = $fc_money;
        $insertData['old_money']    = $old_money;
        $insertData['beizu']        = $beizu;
        $insertData['order_no']     = $orderInfo['order_no'];
        $insertData['order_type']   = $orderInfo['order_type'];
        $insertData['log_ip']       = $_G['clientip'];
        $insertData['log_time']     = TIMESTAMP;
        C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData);
        Log::DEBUG("update fc_end:" . $fc_money);
    }
    # fc end
    
    if(!empty($tongchengConfig['template_id']) && $tcfangchanConfig['fangchan_must_shenhe'] == 1 && $orderInfo['type'] == 1){
        
        if($tcfangchanInfo['shenhe_status'] == 2){
            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_fangchan_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($fcmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerList");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_fangchan_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
    }else{
        $agentInfo = C::t("#tom_tcfangchan#tom_tcfangchan_agent")->fetch_by_user_id($orderInfo['user_id']);
        if($agentInfo['id'] > 0){
            update_mendian_xinxi($agentInfo['mendian_id']);
        }
    }
    
    if(!empty($tongchengConfig['template_id']) && $orderInfo['type'] == 5){
        Log::DEBUG("update type11:" . $orderInfo['type']);
        
        $openVipMsg = str_replace('{NAME}', $mendianInfo['name'], lang('plugin/tom_tcfangchan', 'template_mendian_open_vip_msg'));
        $openVipMsg = str_replace('{PRICE}', $orderInfo['pay_price'], $openVipMsg);
        $openVipMsg = str_replace('{VIP}', $vipInfo['name'], $openVipMsg);
        
        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($manageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
            $smsData = array(
                'first'         => $openVipMsg,
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
        
        $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($fcmanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
            $smsData = array(
                'first'         => $openVipMsg,
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
        
        $userOpenVipMsg = str_replace('{VIP}', $vipInfo['name'], lang('plugin/tom_tcfangchan', 'template_user_open_vip_msg'));
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($userInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=mymendian");
            $smsData = array(
                'first'         => $userOpenVipMsg,
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
        
    }
    
    if(!empty($tongchengConfig['template_id']) && $orderInfo['type'] == 9){
        if(!empty($tongchengConfig['template_id'])){
            
            $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($manageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_adviser_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($fcmanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcfangchan', 'template_fabu_adviser_shenhe_msg'),
                    'keyword1'      => $tcfangchanConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
    }
    
    if(!empty($tongchengConfig['template_id']) && $tcfangchanConfig['fabu_needs_must_shenhe'] == 1 && $orderInfo['type'] == 10){
                
        $toUser = array();
        $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
        if($toUserTmp && !empty($toUserTmp['openid'])){
            $toUser = $toUserTmp;
        }
        $access_token = $weixinClass->get_access_token();

        if($access_token && !empty($toUser['openid'])  ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerNeedsList");
            $smsData = array(
                'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcfangchan','shenhe_needs_template_first'),
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
        }

        $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($fcmanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=managerNeedsList");
            $smsData = array(
                'first'         => lang('plugin/tom_tcfangchan', 'shenhe_needs_template_first'),
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    if(!empty($tongchengConfig['template_id']) && $orderInfo['type'] == 11){
        
        $needsInfo = C::t("#tom_tcfangchan#tom_tcfangchan_needs")->fetch_by_id($orderInfo['needs_id']);
        
        $contact = str_replace('{NAME}', $userInfo['nickname'], lang('plugin/tom_tcfangchan', 'template_needs_contact_msg'));
        $contact = str_replace('{CONTENT}', $needsInfo['content'], $contact);

        $manageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tongchengConfig['manage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($manageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
            $smsData = array(
                'first'         => $contact,
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($manageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }

        $fcmanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcfangchanConfig['fcmanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($fcmanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcfangchan&site={$site_id}&mod=index");
            $smsData = array(
                'first'         => $contact,
                'keyword1'      => $tcfangchanConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($fcmanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
}