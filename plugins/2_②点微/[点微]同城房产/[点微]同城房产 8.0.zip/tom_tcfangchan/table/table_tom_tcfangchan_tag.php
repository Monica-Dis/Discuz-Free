<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tcfangchan_tag extends discuz_table{
	public function __construct() {
        parent::__construct();
		$this->_table = 'tom_tcfangchan_tag';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
    
    public function fetch_all_list($condition = '',$orders = '',$start = 0,$limit = 10) {
        if($limit > 0){
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        }else{
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT",array($this->_table,$condition));
        }
        return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition = '') {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
	
	public function delete_by_tcfangchan_id($tcfangchan_id) {
        if($tcfangchan_id > 0){
            return DB::query("DELETE FROM %t WHERE tcfangchan_id=%d", array($this->_table, $tcfangchan_id));
        }else{
            return false;
        }
	}
	
	public function delete_by_newhouses_id($newhouses_id) {
        if($newhouses_id > 0){
            return DB::query("DELETE FROM %t WHERE newhouses_id=%d", array($this->_table, $newhouses_id));
        }else{
            return false;
        }
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

}