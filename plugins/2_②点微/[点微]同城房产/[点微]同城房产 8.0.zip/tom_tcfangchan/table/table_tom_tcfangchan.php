<?php

/*
   Copyright 2001-2099 DisM!Ӧ������.
   ���²����http://t.cn/Aiux1Jx1
 * 
 * fangchan_nature   1������  2������  3��ת�� 
 * 
 * pay_type   1 ��ѷ���  2 ���ѷ���  3 �ŵ�VIP  4 ������VIP  5 ��ҷ���
 * 
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tcfangchan extends discuz_table{
	public function __construct() {
        parent::__construct();
		$this->_table = 'tom_tcfangchan';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
        $data = DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
        
        $data['price']              = floatval($data['price']);
        $data['mianji']             = floatval($data['mianji']);
        $data['zhuanrang_price']    = floatval($data['zhuanrang_price']);
        
		return $data;
	}
    
    public function fetch_all_list($condition='',$orders = '',$start = 0,$limit = 10,$keyword='',$lat='',$lng=''){
        
        $where = '';
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $where .= " AND search_text LIKE '%{$keyword}%'";
        }
        
        if(!empty($lat) && !empty($lng)){
            $data = DB::fetch_all("SELECT *, acos(cos($lat*pi()/180 )*cos(latitude*pi()/180)*cos($lng*pi()/180 - longitude*pi()/180)+sin($lat*pi()/180 )*sin(latitude*pi()/180))*6370996.81/1000 as distance FROM ".DB::table("tom_tcfangchan")." WHERE 1 {$condition} {$where} ORDER BY distance ASC,id DESC LIMIT $start,$limit");
        }else{
            $data = DB::fetch_all("SELECT *  FROM ".DB::table("tom_tcfangchan")." WHERE 1 {$condition} {$where} $orders LIMIT $start,$limit");
        }
        
        if(is_array($data) && !empty($data)){
            foreach($data as $key => $value){
                $data[$key]['price']              = floatval($value['price']);
                $data[$key]['mianji']             = floatval($value['mianji']);
                $data[$key]['zhuanrang_price']    = floatval($value['zhuanrang_price']);
            }
        }
        
        return $data;
	}
    
    public function fetch_guanzu_list($condition='',$orders = '',$start = 0,$limit = 10,$keyword=''){
        
        $where = '';
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $where .= " AND t.search_text LIKE '%{$keyword}%'";
        }
        
        $attrWhere = ",a.attr_tese_tags,a.attr_shi,a.attr_ting,a.attr_wei,a.attr_chaoxiang_type,a.attr_rent_type";
        $data = DB::fetch_all("SELECT t.*{$attrWhere},g.id as guanzu_id  FROM ".DB::table("tom_tcfangchan")." t LEFT JOIN ".DB::table("tom_tcfangchan_attr")." a on a.tcfangchan_id=t.id LEFT JOIN ".DB::table("tom_tcfangchan_guanzu")." g on g.tcfangchan_id=t.id  WHERE 1 {$condition} {$where} $orders LIMIT $start,$limit");
        
        if(is_array($data) && !empty($data)){
            foreach($data as $key => $value){
                $data[$key]['price']              = floatval($value['price']);
                $data[$key]['mianji']             = floatval($value['price']);
                $data[$key]['zhuanrang_price']    = floatval($value['price']);
            }
        }
        
        return $data;
	}
    
    public function fetch_all_search_list($condition='') {
        $data = DB::fetch_all("SELECT id,title,house_no FROM %t WHERE 1 %i ",array($this->_table,$condition));
        return $data;
	}
    
    public function fetch_houses_average_price_sum_list($condition='') {
        $return = DB::fetch_first("SELECT SUM(mianji) AS totalmanji,SUM(price) AS totalprice FROM ".DB::table($this->_table)." WHERE 1 $condition LIMIT 0,20");
		return $return;
	}
    
    public function fetch_all_id_list($condition='') {
        $data = DB::fetch_all("SELECT id FROM %t WHERE 1 %i ",array($this->_table,$condition));
        return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_user_houses_count($condition='') {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
    
    public function fetch_all_count($condition='',$keyword='') {
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition AND search_text LIKE '%{$keyword}%' ");
        }else{
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
        }
		return $return['num'];
	}
    
    public function fetch_guanzu_count($condition='',$keyword='') {
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." t LEFT JOIN ".DB::table("tom_tcfangchan_attr")." a on a.tcfangchan_id=t.id LEFT JOIN ".DB::table("tom_tcfangchan_guanzu")." g on g.tcfangchan_id=t.id WHERE 1 $condition AND t.search_text LIKE '%{$keyword}%' ");
        }else{
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." t LEFT JOIN ".DB::table("tom_tcfangchan_attr")." a on a.tcfangchan_id=t.id LEFT JOIN ".DB::table("tom_tcfangchan_guanzu")." g on g.tcfangchan_id=t.id WHERE 1 $condition ");
        }
		return $return['num'];
	}
    
    public function fetch_agent_houses_count($condition='',$keyword='') {
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." t LEFT JOIN ".DB::table("tom_tcfangchan_agent")." a on a.user_id=t.user_id LEFT JOIN ".DB::table("tom_tcfangchan_mendian")." m on m.id=a.mendian_id WHERE 1 $condition AND t.search_text LIKE '%{$keyword}%' ");
        }else{
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." t LEFT JOIN ".DB::table("tom_tcfangchan_agent")." a on a.user_id=t.user_id LEFT JOIN ".DB::table("tom_tcfangchan_mendian")." m on m.id=a.mendian_id WHERE 1 $condition ");
        }
		return $return['num'];
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

}