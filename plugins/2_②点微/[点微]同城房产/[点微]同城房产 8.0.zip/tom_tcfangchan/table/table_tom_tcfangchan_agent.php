<?php

/*
   Copyright 2001-2099 DisM!Ӧ������.
   ���²����http://t.cn/Aiux1Jx1
 * 
 * shenhe_status   1�����ͨ��  2�������  3���¼�
 * 
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tcfangchan_agent extends discuz_table{
	public function __construct() {
        parent::__construct();
		$this->_table = 'tom_tcfangchan_agent';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}

    public function fetch_by_user_id($user_id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE user_id=%d", array($this->_table, $user_id));
	}
    
    public function fetch_all_list($condition='',$orders = '',$start = 0,$limit = 10,$keyword=''){
        
        $where = '';
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $where .= " AND (t.name LIKE '%{$keyword}%' OR t.mendian_name LIKE '%{$keyword}%' OR t.tel LIKE '%{$keyword}%' OR m.name LIKE '%{$keyword}%')";
        }
        
        $mendianWhere = ",m.name as m_name,m.area_id as m_area_id,m.street_id as m_street_id,m.address as m_address";
        $data = DB::fetch_all("SELECT t.*{$mendianWhere}  FROM ".DB::table($this->_table)." t LEFT JOIN ".DB::table("tom_tcfangchan_mendian")." m on m.id=t.mendian_id WHERE 1 {$condition} {$where} $orders LIMIT $start,$limit");
        
        return $data;
	}
    
    public function fetch_all_user_id($condition = '',$orders = '') {
        $data = DB::fetch_all("SELECT user_id FROM %t WHERE 1 %i $orders ",array($this->_table,$condition));
        return $data;
	}
    
    public function fetch_all_agent_list($condition = '',$orders = '',$start = 0,$limit = 0) {
        if($limit > 0){
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        }else{
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders ",array($this->_table,$condition));
        }
        return $data;
	}
    
    public function fetch_all_agent_count($condition = '') {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition = '') {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
    
    public function fetch_all_count2($condition='',$keyword='') {
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $keyword = " AND (t.name LIKE '%{$keyword}%' OR t.mendian_name LIKE '%{$keyword}%' OR t.tel LIKE '%{$keyword}%' OR m.name LIKE '%{$keyword}%')";
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." t LEFT JOIN ".DB::table("tom_tcfangchan_mendian")." m on m.id=t.mendian_id WHERE 1 $condition $keyword ");
        }else{
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." t LEFT JOIN ".DB::table("tom_tcfangchan_mendian")." m on m.id=t.mendian_id WHERE 1 $condition ");
        }
		return $return['num'];
	} 
	
	public function delete_by_mendian_id($mendian_id) {
		return DB::query("DELETE FROM %t WHERE mendian_id=%d", array($this->_table, $mendian_id));
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

}