<?php

/*
   Copyright 2001-2099 DisM!Ӧ������.
   ���²����http://t.cn/Aiux1Jx1
 * 
 * sell_status    1������  2������  3��δ����
 * 
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tcfangchan_newhouses extends discuz_table{
	public function __construct() {
        parent::__construct();
		$this->_table = 'tom_tcfangchan_newhouses';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
    
    public function fetch_all_list($condition='',$orders = '',$start = 0,$limit = 10,$keyword='', $house_type=0,$lat='',$lng=''){
        
        $searchWhere = '';
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $searchWhere .= " AND name LIKE '%{$keyword}%'";
        }
        if($house_type > 0){
            $house_type = str_replace(array('%', '_'),'',$house_type);
            $searchWhere .= " AND type LIKE '%|{$house_type}|%'";
        }

        $limitWhere = '';
        if($limit > 0){
            $limitWhere = "LIMIT {$start},{$limit}";
        }
        
        if(!empty($lat) && !empty($lng)){
            $data = DB::fetch_all("SELECT *,acos(cos($lat*pi()/180 )*cos(latitude*pi()/180)*cos($lng*pi()/180 - longitude*pi()/180)+sin($lat*pi()/180 )*sin(latitude*pi()/180))*6370996.81/1000 as distance FROM %t WHERE 1 %i %i ORDER BY distance ASC,id DESC $limitWhere",array($this->_table,$condition, $searchWhere));
        }else{
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i %i $orders $limitWhere",array($this->_table,$condition,$searchWhere));
        }
        
        return $data;
	}
    
    public function fetch_guanzu_list($condition='',$orders = '',$start = 0,$limit = 10,$keyword=''){
        
        $where = '';
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $where .= " AND t.name LIKE '%{$keyword}%'";
        }
        
        $data = DB::fetch_all("SELECT t.*,g.id as guanzu_id  FROM ".DB::table($this->_table)." t LEFT JOIN ".DB::table("tom_tcfangchan_newhouses_guanzu")." g on g.newhouses_id=t.id  WHERE 1 {$condition} {$where} $orders LIMIT $start,$limit");
        
        return $data;
	}
    
    public function fetch_guanzu_count($condition='',$keyword='') {
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." t LEFT JOIN ".DB::table("tom_tcfangchan_newhouses_guanzu")." g on g.newhouses_id=t.id WHERE 1 $condition AND name LIKE '%{$keyword}%' ");
        }else{
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." t LEFT JOIN ".DB::table("tom_tcfangchan_newhouses_guanzu")." g on g.newhouses_id=t.id WHERE 1 $condition ");
        }
		return $return['num'];
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition = '',$keyword = '') {
        if(!empty($keyword)){
            $keyword = str_replace(array('%', '_'),'',$keyword);
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition  AND name LIKE '%{$keyword}%' ");
        }else{
            $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
        }
		return $return['num'];
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

}