<?php

/*
   Copyright 2001-2099 DisM!Ӧ������.
   ���²����http://t.cn/Aiux1Jx1
 * 
 * type  1����ͨͷͼ   2��VR����   3������   4����Ƶ����   5���ŵ�logo   6���ŵ����  7���ŵ�Ӫҵִ��
 * 
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tcfangchan_photo extends discuz_table{
	public function __construct() {
        parent::__construct();
		$this->_table = 'tom_tcfangchan_photo';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
    
    public function fetch_all_list($condition = '',$orders = '',$start = 0,$limit = 10) {
        global $_G,$tongchengConfig;
        
        $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        if(is_array($data) && !empty($data)){
            foreach($data as $key => $value){
                if($tongchengConfig['open_yun'] == 2 && !empty($value['oss_picurl']) && $value['oss_status'] == 1){
                    $picurlTmp = $value['oss_picurl'];
                }else if($tongchengConfig['open_yun'] == 3 && !empty($value['qiniu_picurl']) && $value['qiniu_status'] == 1){
                    $picurlTmp = $value['qiniu_picurl'];
                }else{
                    if(!preg_match('/^http/', $value['picurl']) ){
                        if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                            $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                        }else{
                            $picurlTmp = $_G['siteurl'].$value['picurl'];
                        }
                    }else{
                        $picurlTmp = $value['picurl'];
                    }
                }
                $data[$key]['house_mianji'] = floatval($value['house_mianji']);
                $data[$key]['picurlTmp'] = $picurlTmp;
            }
        }
        
        return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition = '') {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		return $return['num'];
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function delete_all_list($condition = '') {
		return DB::query("DELETE FROM %t WHERE 1 %i", array($this->_table, $condition));
	}
	
	public function delete_by_houses_id($houses_id) {
        if($houses_id > 0){
            return DB::query("DELETE FROM %t WHERE houses_id=%d", array($this->_table, $houses_id));
        }else{
            return false;
        }
	}
	
	public function delete_by_newhouses_id($newhouses_id) {
        if($newhouses_id > 0){
            return DB::query("DELETE FROM %t WHERE newhouses_id=%d AND type IN(1,2) ", array($this->_table, $newhouses_id));
        }else{
            return false;
        }
	}
    
    public function delete_by_newhouseshuxing_id($newhouses_id) {
        if($newhouses_id > 0){
            return DB::query("DELETE FROM %t WHERE newhouses_id=%d AND type = 3 ", array($this->_table, $newhouses_id));
        }else{
            return false;
        }
	}
    
    public function delete_by_newhousesall_id($newhouses_id) {
        if($newhouses_id > 0){
            return DB::query("DELETE FROM %t WHERE newhouses_id=%d ", array($this->_table, $newhouses_id));
        }else{
            return false;
        }
	}
	
	public function delete_by_tcfangchan_id($tcfangchan_id) {
        if($tcfangchan_id > 0){
            return DB::query("DELETE FROM %t WHERE tcfangchan_id=%d", array($this->_table, $tcfangchan_id));
        }else{
            return false;
        }
	}
	
	public function delete_by_mendian_id($mendian_id) {
        if($mendian_id > 0){
            return DB::query("DELETE FROM %t WHERE mendian_id=%d", array($this->_table, $mendian_id));
        }else{
            return false;
        }
	}

}