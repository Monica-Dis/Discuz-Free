<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/plugin');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $sql = '';
    
    if (!empty($sql)) {
        runquery($sql);
    }
    
    $sql = <<<EOF
    CREATE TABLE IF NOT EXISTS `pre_tom_xiaofenlei_sites` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `name` varchar(255) DEFAULT NULL,
      `wxpay_appid` varchar(255) DEFAULT NULL,
      `wxpay_appsecret` varchar(255) DEFAULT NULL,
      `wxpay_mchid` varchar(255) DEFAULT NULL,
      `wxpay_key` varchar(255) DEFAULT NULL,
      `add_time` int(11) DEFAULT '0',
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;

    CREATE TABLE IF NOT EXISTS `pre_tom_xiaofenlei_zhibo` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `name` varchar(255) DEFAULT NULL,
      `roomid` int(11) DEFAULT '0',
      `cover_img` varchar(255) DEFAULT NULL,
      `live_status` int(11) DEFAULT '0',
      `start_time` int(11) DEFAULT '0',
      `end_time` int(11) DEFAULT '0',
      `anchor_name` varchar(255) DEFAULT NULL,
      `anchor_img` varchar(255) DEFAULT NULL,
      `add_time` int(11) DEFAULT '0',
      `part1` varchar(255) DEFAULT NULL,
      `part2` varchar(255) DEFAULT NULL,
      `part3` int(11) DEFAULT NULL,
      PRIMARY KEY (`id`)
    ) ENGINE=MyISAM;
EOF;

    runquery($sql);
    
    $sql = '';
    $tom_xiaofenlei_zhibo_field = C::t('#tom_xiaofenlei#tom_xiaofenlei_zhibo')->fetch_all_field();
    if (!isset($tom_xiaofenlei_zhibo_field['admin_cover_img'])) {
        $sql .= "ALTER TABLE `pre_tom_xiaofenlei_zhibo` ADD `admin_cover_img` tinyint(4) DEFAULT '0';\n";
    }

    if (!empty($sql)) {
        runquery($sql);
    }

    echo 'OK';exit;
    
}else{
    exit('Access Denied');
}