<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$test = intval($_GET['test'])>0? intval($_GET['test']):0;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
$tomSysOffset = getglobal('setting/timeoffset');
$appid = trim($xiaofenleiConfig['wxpay_appid']);  
$appsecret = trim($xiaofenleiConfig['wxpay_appsecret']);

$r = xiaoGetCode("pages/zhibo/index",'1_1',640);

if(isset($r['code']) && $r['code'] == 0 && !empty($r['src']) && $test == 0){
    echo '<img src="'.$r['src'].'">';exit;
}else{
    var_dump($r);exit;
}

function xiaoGetCode($page,$scene,$width){
    global $_G;
    
    $r = array(
        'code' => 0,
        'src' => '',
    );
    
    $xiaofenleiConfig   = $_G['cache']['plugin']['tom_xiaofenlei'];
    $appid              = trim($xiaofenleiConfig['wxpay_appid']);  
    $appsecret          = trim($xiaofenleiConfig['wxpay_appsecret']);
    
    if($xiaofenleiConfig['open_sites_zhibo'] == 1){
        $xiaoSitesInfo = C::t('#tom_xiaofenlei#tom_xiaofenlei_sites')->fetch_by_id($xiaofenleiConfig['sites_zhibo_sid']);
        if($xiaoSitesInfo){
            $appid = trim($xiaoSitesInfo['wxpay_appid']);  
            $appsecret = trim($xiaoSitesInfo['wxpay_appsecret']);
        }
    }
    
    $postData  = '{"page":"'.$page.'","scene":"'.$scene.'","width":'.$width.'}';
    $imageDir  = "/source/plugin/tom_xiaofenlei/data/qrcode/".date("Ym")."/".date("d")."/";
    $imageName = "source/plugin/tom_xiaofenlei/data/qrcode/".date("Ym")."/".date("d")."/".md5($postData.$appid).".png";
    $imageImg  = DISCUZ_ROOT."./".$imageName;
    
    if(file_exists($imageImg)){
        $r = array(
            'code' => 0,
            'src' => $imageName,
        );
        return $r;
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/class/xiao.class.php';
    $xiaoClass = new xiaoClass($appid,$appsecret);
    $access_token = $xiaoClass->get_access_token();
    
    $getwxacode_url = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token={$access_token}";
    $return = xiaoHttpPost($getwxacode_url, $postData);
    
    $content = json_decode($return,true);
    if(is_array($content) && !empty($content) && isset($content['errcode']) && !empty($content['errcode'])){
        
        $r = array(
            'code' => $content['errcode'],
            'msg'  => $content['errmsg'],
        );
        return $r;
        
    }else{
        
        $tomDir = DISCUZ_ROOT.'.'.$imageDir;
        if(!is_dir($tomDir)){
            mkdir($tomDir, 0777,true);
        }else{
            chmod($tomDir, 0777);
        }
        if(false !== file_put_contents(DISCUZ_ROOT.'./'.$imageName, $return)){
            $r = array(
                'code' => 0,
                'src' => $imageName,
            );
            return $r;
        }else{
            $r = array(
                'code' => 301,
            );
            return $r;
        }
    }
}