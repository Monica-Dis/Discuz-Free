<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=zhibo';
$modListUrl = $adminListUrl.'&tmod=zhibo';
$modFromUrl = $adminFromUrl.'&tmod=zhibo';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

if($_GET['act'] == 'edit'){
    
    $zhiboInfo = C::t('#tom_xiaofenlei#tom_xiaofenlei_zhibo')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $cover_img        = tomuploadFile("cover_img",$zhiboInfo['cover_img']);
        
        $updateData = array();
        $updateData['cover_img']          = $cover_img;
        $updateData['admin_cover_img']    = 1;
        C::t('#tom_xiaofenlei#tom_xiaofenlei_zhibo')->update($zhiboInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        
        if(!preg_match('/^http/', $zhiboInfo['cover_img']) ){
            if(strpos($zhiboInfo['cover_img'], 'source/plugin/tom_') === FALSE){
                $cover_img = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$zhiboInfo['cover_img'];
            }else{
                $cover_img = rtrim($_G['siteurl'], "/").'/'.$zhiboInfo['cover_img'];
            }
        }
        
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'].'&formhash='.FORMHASH,'enctype');
        showtableheader(); /*dism��taobao��com*/
        echo '<tr><th colspan="15" class="partition">' .$zhiboInfo['name'].'&nbsp;>>&nbsp;'.$Lang['edit_zhibo_cover_img']. '</th></tr>';
        showsetting($Lang['zhibo_cover_img'],'cover_img', $zhiboInfo['cover_img'], 'filetext',0,0,'<a target="_blank" href="'.$cover_img.'"><img src="'.$cover_img.'" width="150" /></a>');
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism - taobao - com*/
        showformfooter(); /*dism _ taobao _ com*/
    }
    
}else if($_GET['act'] == 'getzhibolist'){
    
    $appid = trim($xiaofenleiConfig['wxpay_appid']);  
    $appsecret = trim($xiaofenleiConfig['wxpay_appsecret']);
    
    if($xiaofenleiConfig['open_sites_zhibo'] == 1){
        $xiaoSitesInfo = C::t('#tom_xiaofenlei#tom_xiaofenlei_sites')->fetch_by_id($xiaofenleiConfig['sites_zhibo_sid']);
        if($xiaoSitesInfo){
            $appid = trim($xiaoSitesInfo['wxpay_appid']);  
            $appsecret = trim($xiaoSitesInfo['wxpay_appsecret']);
        }
    }
    
    $access_token = '';
    
    $getAccessTokenUrl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={$appid}&secret={$appsecret}";
    $return = tom_html_get($getAccessTokenUrl);
    if(!empty($return)){
        $content = json_decode($return,true);
        if(is_array($content) && !empty($content) && isset($content['access_token']) && !empty($content['access_token'])){
            $access_token = $content['access_token'];
        }else{
            cpmsg($return, $modListUrl, 'error');
        }
    }else{
        cpmsg($return, $modListUrl, 'error');
    }
    
    $r = tom_html_post('{"start": 0, "limit": 100}', "https://api.weixin.qq.com/wxa/business/getliveinfo?access_token=".$access_token);
    
    $zhiboList = array();
    if(!empty($r)){
        $c = json_decode($r,true);
        if(is_array($c) && !empty($c) && isset($c['errmsg']) && $c['errmsg'] == 'ok' && !empty($c['room_info'])){
            $zhiboList = $c['room_info'];
        }else{
            cpmsg($r, $modListUrl, 'error');
        }
    }
    
    if (CHARSET == 'gbk') {
        $zhiboList = tom_iconv($zhiboList, 'utf-8', 'gbk');
    }
    
    if(is_array($zhiboList) && !empty($zhiboList)){
        foreach ($zhiboList AS $key => $value){
            
            $zhiboInfoTmp = C::t('#tom_xiaofenlei#tom_xiaofenlei_zhibo')->fetch_by_roomid($value['roomid']);
            
            $picurl_content = tom_html_get($value['cover_img']);

            $imageDir = "/source/plugin/tom_xiaofenlei/data/zhibo/".date("Ym")."/".date("d")."/";
            $imageName = "source/plugin/tom_xiaofenlei/data/zhibo/".date("Ym")."/".date("d")."/".md5($value['cover_img']).".jpg";
            $tomDir = DISCUZ_ROOT.'.'.$imageDir;
            if(!is_dir($tomDir)){
                mkdir($tomDir, 0777,true);
            }else{
                chmod($tomDir, 0777);
            }
            if(false !== file_put_contents(DISCUZ_ROOT.'./'.$imageName, $picurl_content)){
                $value['cover_img'] = $imageName;
            }
            
            if($zhiboInfoTmp){
                $updateData = array();
                $updateData['name']             = $value['name'];
                $updateData['roomid']           = $value['roomid'];
                if($zhiboInfoTmp['admin_cover_img'] == 0){
                    $updateData['cover_img']        = $value['cover_img'];
                }
                $updateData['live_status']      = $value['live_status'];
                $updateData['start_time']       = $value['start_time'];
                $updateData['end_time']         = $value['end_time'];
                $updateData['anchor_name']      = $value['anchor_name'];
                $updateData['anchor_img']       = $value['anchor_img'];
                $updateData['add_time']         = TIMESTAMP;
                C::t('#tom_xiaofenlei#tom_xiaofenlei_zhibo')->update($zhiboInfoTmp['id'],$updateData);
            }else{
                $insertData = array();
                $insertData['name']             = $value['name'];
                $insertData['roomid']           = $value['roomid'];
                $insertData['cover_img']        = $value['cover_img'];
                $insertData['live_status']      = $value['live_status'];
                $insertData['start_time']       = $value['start_time'];
                $insertData['end_time']         = $value['end_time'];
                $insertData['anchor_name']      = $value['anchor_name'];
                $insertData['anchor_img']       = $value['anchor_img'];
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_xiaofenlei#tom_xiaofenlei_zhibo')->insert($insertData);
            }
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_xiaofenlei#tom_xiaofenlei_zhibo')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    $where = "";
    
    $pagesize = 10;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_xiaofenlei#tom_xiaofenlei_zhibo')->fetch_all_count($where);
    $zhiboList = C::t('#tom_xiaofenlei#tom_xiaofenlei_zhibo')->fetch_all_list($where,"ORDER BY live_status ASC,id DESC",$start,$pagesize);
    
    showtableheader(); /*dism��taobao��com*/
    $Lang['zhibo_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['zhibo_help_1']);
    $Lang['zhibo_help_2']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['zhibo_help_2']);
    $Lang['zhibo_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['zhibo_help_3']);
    $Lang['xiao_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['xiao_help_3']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['zhibo_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['zhibo_help_1'] . '</li>';
    echo '<li>' . $Lang['zhibo_help_4'] . '</li>';
    echo '<li>' . $Lang['zhibo_help_2'] . '</li>';
    echo '<li>' . $Lang['zhibo_help_3'] . '</li>';
    echo '<li>' . $Lang['xiao_help_3'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism - taobao - com*/
    
    tomshownavheader();
    tomshownavli($Lang['getzhibolist_btn'],$modBaseUrl."&act=getzhibolist",false);
    tomshownavfooter();
    
    showtableheader(); /*dism��taobao��com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['zhibo_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['zhibo_name'] . '</th>';
    echo '<th>' . $Lang['zhibo_roomid'] . '</th>';
    echo '<th>' . $Lang['zhibo_cover_img'] . '</th>';
    echo '<th>' . $Lang['zhibo_live_status'] . '</th>';
    echo '<th>' . $Lang['zhibo_start_time'] . '</th>';
    echo '<th>' . $Lang['zhibo_end_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($zhiboList as $key => $value){
        
        if(!preg_match('/^http/', $value['cover_img']) ){
            if(strpos($value['cover_img'], 'source/plugin/tom_') === FALSE){
                $value['cover_img'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['cover_img'];
            }else{
                $value['cover_img'] = rtrim($_G['siteurl'], "/").'/'.$value['cover_img'];
            }
        }
        
        echo '<tr>';
        echo '<td>'.$value['name'].'</td>';
        echo '<td>'.$value['roomid'].'</td>';
        echo '<td><img src="'.$value['cover_img'].'" width="40" /></td>';
        if($value['live_status'] == 101){
            echo '<td><font color="#238206">'.$Lang['live_status_101'].'</font></td>';
        }else if($value['live_status'] == 102){
            echo '<td><font color="#fd0d0d">'.$Lang['live_status_102'].'</font></td>';
        }else if($value['live_status'] == 103){
            echo '<td><font color="#fd0d0d">'.$Lang['live_status_103'].'</font></td>';
        }else if($value['live_status'] == 104){
            echo '<td><font color="#8e8e8e">'.$Lang['live_status_104'].'</font></td>';
        }else if($value['live_status'] == 105){
            echo '<td><font color="#fd0d0d">'.$Lang['live_status_105'].'</font></td>';
        }else if($value['live_status'] == 106){
            echo '<td><font color="#8e8e8e">'.$Lang['live_status_106'].'</font></td>';
        }else if($value['live_status'] == 107){
            echo '<td><font color="#8e8e8e">'.$Lang['live_status_107'].'</font></td>';
        }
        echo '<td>'.dgmdate($value['start_time'],"Y-m-d H:i",$tomSysOffset).'</td>';
        echo '<td>'.dgmdate($value['end_time'],"Y-m-d H:i",$tomSysOffset).'</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_zhibo_cover_img']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter(); /*dism - taobao - com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}