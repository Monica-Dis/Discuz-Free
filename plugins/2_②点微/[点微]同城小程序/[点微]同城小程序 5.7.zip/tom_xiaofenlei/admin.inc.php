<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$LangTmp = $scriptlang['tom_xiaofenlei'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_xiaofenlei&pmod=admin'; 
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_xiaofenlei&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_xiaofenlei&pmod=admin';

$tomSysOffset = getglobal('setting/timeoffset');

$pluginVarList = C::t('common_pluginvar')->fetch_all_by_pluginid($pluginid);
$xiaofenleiConfig = array();
foreach ($pluginVarList as $vark => $varv){
    $xiaofenleiConfig[$varv['variable']] = $varv['value'];
}

$Lang  = array();
if(is_array($LangTmp) && !empty($LangTmp)){
    foreach ($LangTmp as $key => $value){
        $Lang[$key] = htmlspecialchars_decode($value);
    }
}

include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/class/function.admin.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';

if($_GET['tmod'] == 'index'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/user.php';
    
}else if($_GET['tmod'] == 'zhibo'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/zhibo.php';
    
}else if($_GET['tmod'] == 'sites'){
    
    if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/sites1000.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/sites1000.php';
    }else if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/sites100.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/sites100.php';
    }else if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/sites50.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/sites50.php';
    }else if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/sites30.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/sites30.php';
    }else if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/sites10.php')){
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/sites10.php';
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/nosites.php';
    }
    
}else{
    
    include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/admin/user.php';
    
}