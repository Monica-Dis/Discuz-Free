<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_xiaofenlei_user`;
CREATE TABLE `pre_tom_xiaofenlei_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `utoken` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `unionid` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_openid` (`openid`),
  KEY `idx_userid` (`user_id`),
  KEY `idx_tel` (`tel`),
  KEY `idx_utoken` (`utoken`),
  KEY `idx_unionid` (`unionid`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_xiaofenlei_sites`;
CREATE TABLE `pre_tom_xiaofenlei_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `wxpay_appid` varchar(255) DEFAULT NULL,
  `wxpay_appsecret` varchar(255) DEFAULT NULL,
  `wxpay_mchid` varchar(255) DEFAULT NULL,
  `wxpay_key` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_xiaofenlei_zhibo`;
CREATE TABLE `pre_tom_xiaofenlei_zhibo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `roomid` int(11) DEFAULT '0',
  `cover_img` varchar(255) DEFAULT NULL,
  `admin_cover_img` tinyint(4) DEFAULT '0',
  `live_status` int(11) DEFAULT '0',
  `start_time` int(11) DEFAULT '0',
  `end_time` int(11) DEFAULT '0',
  `anchor_name` varchar(255) DEFAULT NULL,
  `anchor_img` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
