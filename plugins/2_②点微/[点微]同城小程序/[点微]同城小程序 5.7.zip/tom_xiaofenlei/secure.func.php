<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/class/xiao.class.php';

function wx_msgSecCheck($text){
    global $_G;
    
    $r = array(
        'code' => 0,
        'word' => '',
    );
    
    $xiaofenleiConfig   = $_G['cache']['plugin']['tom_xiaofenlei'];
    $appid              = trim($xiaofenleiConfig['wxpay_appid']);  
    $appsecret          = trim($xiaofenleiConfig['wxpay_appsecret']);
    
    $client_msg_id = md5($appid);
    
    $text = diconv($text,CHARSET,'utf-8');
    
    $postData  = '{"service": "wxee446d7507c68b11","api": "msgSecCheck","client_msg_id" : "'.$client_msg_id.'","data": {"Action": "TextApproval","Text": "'.$text.'"}}';
    
    $xiaoClass = new xiaoClass($appid,$appsecret);
    $access_token = $xiaoClass->get_access_token();
    
    $geturl = "https://api.weixin.qq.com/wxa/servicemarket?access_token={$access_token}";
    $return = xiaoHttpPost($geturl, $postData);
    $content = json_decode($return,true);
    
    if(is_array($content) && !empty($content) && isset($content['errmsg']) && $content['errmsg'] == 'ok'){
        
        $data = json_decode($content['data'],true);
        $status = $data['Response']['EvilTokens'][0];
        if($status['EvilFlag'] == 0){
            $r['code'] = 200;
        }else if($status['EvilFlag'] == 2){
            $r['code'] = 100;
        }else{
            $r['code'] = 500;
            if(is_array($status['EvilKeywords']) && !empty($status['EvilKeywords'])){
                foreach ($status['EvilKeywords'] as $key => $value){
                    $r['word'] = $r['word'].' '.$value;
                }
            }
        }
    }
    
    return $r;
}

function wx_imgSecCheck($picurl){
    global $_G;
    
    $r = array(
        'code' => 0,
    );
    
    $xiaofenleiConfig   = $_G['cache']['plugin']['tom_xiaofenlei'];
    $appid              = trim($xiaofenleiConfig['wxpay_appid']);  
    $appsecret          = trim($xiaofenleiConfig['wxpay_appsecret']);
    
    $client_msg_id = md5($appid);
    
    $postData  = '{
          "service": "wxee446d7507c68b11",
          "api": "imgSecCheck",
          "client_msg_id" : "'.$client_msg_id.'",
          "data": {
            "Action": "ImageModeration",
            "Scenes": ["PORN", "POLITICS", "TERRORISM", "TEXT"],
            "ImageUrl": "'.$picurl.'",
            "ImageBase64": "",
            "Config": "",
            "Extra": ""
          }
    }';
    
    $xiaoClass = new xiaoClass($appid,$appsecret);
    $access_token = $xiaoClass->get_access_token();
    
    $geturl = "https://api.weixin.qq.com/wxa/servicemarket?access_token={$access_token}";
    $return = xiaoHttpPost($geturl, $postData);
    $content = json_decode($return,true);
    
    if(is_array($content) && !empty($content) && isset($content['errmsg']) && $content['errmsg'] == 'ok'){
        $data = json_decode($content['data'],true);
        $status = $data['Response'];
        if($status['Suggestion'] == 'PASS'){
            $r['code'] = 200;
        }else{
            $r['code'] = 500;
        }
    }
    
    return $r;
}