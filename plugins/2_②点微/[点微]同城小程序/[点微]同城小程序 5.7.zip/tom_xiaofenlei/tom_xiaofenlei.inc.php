<?php

/**
   This is NOT a freeware, use is subject to license terms
   Ӧ�ø���֧�֣�https://dism.taobao.com
   ���²����http://t.cn/Aiux1Jx1
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$xiaofenleiConfig = $_G['cache']['plugin']['tom_xiaofenlei'];
$tomSysOffset = getglobal('setting/timeoffset');
$appid = trim($xiaofenleiConfig['wxpay_appid']);  
$appsecret = trim($xiaofenleiConfig['wxpay_appsecret']);
$cssJsVersion = "20170719";

include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';


$utoken         = !empty($_GET['utoken'])? addslashes($_GET['utoken']):'';

$mustLoginModArr = array('save_fabu','get_userinfo','update_status','get_my_list','get_fabu_input');

$__XiaoUserInfo = C::t('#tom_xiaofenlei#tom_xiaofenlei_user')->fetch_by_utoken($utoken);
if($__XiaoUserInfo && $__XiaoUserInfo['id'] > 0){
    $__UserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($__XiaoUserInfo['user_id']); 
}else{
    if(in_array($_GET['mod'], $mustLoginModArr)){
        $outArr = array(
            'code'  => 2,
        );
        echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    }
}

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

## tcshop start
$__ShowTcshop = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcshop/tom_tcshop.inc.php')){
    $tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
    if($tcshopConfig['open_tcshop'] == 1){
        $__ShowTcshop = 1;
    }
}
## tcshop end

if($_GET['mod'] == 'get_list'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $tcshop_id = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    $model_id = intval($_GET['model_id'])>0? intval($_GET['model_id']):0;
    $type_id  = intval($_GET['type_id'])>0? intval($_GET['type_id']):0;
    $cate_id  = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
    $user_id  = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $city_id  = intval($_GET['city_id'])>0? intval($_GET['city_id']):0;
    $area_id  = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id  = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    $page  = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize  = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):6;
    $ordertype  = !empty($_GET['ordertype'])? addslashes($_GET['ordertype']):'new';

    $whereStr = ' AND status=1 AND shenhe_status=1 ';
    if(!empty($sql_in_site_ids)){
        $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
    }
    if(!empty($tcshop_id)){
        $whereStr.= " AND tcshop_id={$tcshop_id} ";
    }
    if(!empty($model_id)){
        $whereStr.= " AND model_id={$model_id} ";
    }
    if(!empty($type_id)){
        $whereStr.= " AND type_id={$type_id} ";
    }
    if(!empty($cate_id)){
        $whereStr.= " AND cate_id={$cate_id} ";
    }
    if(!empty($user_id)){
        $whereStr.= " AND user_id={$user_id} ";
    }
    if(!empty($city_id)){
        $whereStr.= " AND city_id={$city_id} ";
    }
    if(!empty($area_id)){
        $whereStr.= " AND area_id={$area_id} ";
    }
    if(!empty($street_id)){
        $whereStr.= " AND street_id={$street_id} ";
    }
    
    $orderStr = " ORDER BY refresh_time DESC,id DESC ";
    $showTop = 0;
    if(!empty($model_id) || !empty($type_id) || !empty($cate_id) || !empty($keyword)){
        $showTop = 1;
        $orderStr = " ORDER BY topstatus DESC, refresh_time DESC,id DESC ";
    }
    if($tongchengConfig['new_show_top'] == 1){
        $showTop = 1;
        $orderStr = " ORDER BY topstatus DESC, refresh_time DESC,id DESC ";
    }
    
    $pagesize = $pagesize;
    $start = ($page - 1)*$pagesize;
    $tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list($whereStr,$orderStr,$start,$pagesize,$keyword);
    
    $tongchengList = array();
    foreach ($tongchengListTmp as $key => $value) {

        $tongchengList[$key] = $value;
        $tongchengList[$key]['content'] = contentFormat($value['content']);
        $tongchengList[$key]['showTop'] = $showTop;
        
        $typeInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($value['type_id']);

        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        if(!preg_match('/^http/', $userInfoTmp['picurl']) ){
            $userInfoTmp['picurl'] = rtrim($_G['siteurl'], "/").'/'.$userInfoTmp['picurl'];
        }
        $siteInfoTmp = array('id'=>1,'name'=>$tongchengConfig['plugin_name']);
        if($value['site_id'] > 1){
            $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        }

        $tongchengAttrListTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY paixu ASC,id DESC ",0,50);
        $tongchengTagListTmp = C::t('#tom_tongcheng#tom_tongcheng_tag')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY id DESC ",0,50);
        $tongchengPhotoListTmpTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY id ASC ",0,50);
        $tongchengPhotoListTmp = array();
        if(is_array($tongchengPhotoListTmpTmp) && !empty($tongchengPhotoListTmpTmp)){
            foreach ($tongchengPhotoListTmpTmp as $kk => $vv){
                if($tongchengConfig['open_yun'] == 2 && !empty($vv['oss_picurl'])){
                    $picurl = $vv['oss_picurl'];
                }else if($tongchengConfig['open_yun'] == 3 && !empty($vv['qiniu_picurl'])){
                    $picurl = $vv['qiniu_picurl'];
                }else{
                    if(!preg_match('/^http/', $vv['picurl']) ){
                        if(strpos($vv['picurl'], 'source/plugin/tom_tongcheng/data/') === false){
                            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                        }else{
                            $picurl = $_G['siteurl'].$vv['picurl'];
                        }
                    }else{
                        $picurl = $vv['picurl'];
                    }
                }
                $tongchengPhotoListTmp[] = $picurl;
            }
        }
        $tongchengList[$key]['userInfo'] = $userInfoTmp;
        $tongchengList[$key]['typeInfo'] = $typeInfoTmp;
        $tongchengList[$key]['attrList'] = $tongchengAttrListTmp;
        $tongchengList[$key]['tagList']  = $tongchengTagListTmp;
        $tongchengList[$key]['photoList'] = $tongchengPhotoListTmp;
        $tongchengList[$key]['siteInfo'] = $siteInfoTmp;
        
    }
    
    $outArr['data'] = $tongchengList;
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_info'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $tongcheng_id = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;

    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    
    if(!$tongchengInfo){
        $outArr = array(
            'code'  => 404,
            'msg'   => lang("plugin/tom_xiaofenlei", "detail_404"),
        );
        echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    }

    if($tongchengInfo['shenhe_status'] != 1){
        $outArr = array(
            'code'  => 404,
            'msg'   => lang("plugin/tom_xiaofenlei", "detail_404"),
        );
        echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    }

    $content = contentFormat($tongchengInfo['content']);
    $tongchengInfo['content'] = $content;
    
    $contentTmp = strip_tags($content);
    $contentTmp = str_replace("\r\n","",$contentTmp);
    $contentTmp = str_replace("\n","",$contentTmp);
    $contentTmp = str_replace("\r","",$contentTmp);
    $title = cutstr($contentTmp,60,"...");
    $desc = cutstr($contentTmp,80,"...");
    if(empty($tongchengInfo['title'])){
        $tongchengInfo['title'] = cutstr($contentTmp,50,"...");
    }
    if($tongchengConfig['open_fabu_title'] == 0){
        $tongchengInfo['title'] = cutstr($contentTmp,50,"...");
    }
    
    DB::query("UPDATE ".DB::table('tom_tongcheng')." SET clicks=clicks+1 WHERE id='$tongcheng_id' ", 'UNBUFFERED');

    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengInfo['user_id']);
    if(!preg_match('/^http/', $userInfo['picurl']) ){
        $userInfo['picurl'] = rtrim($_G['siteurl'], "/").'/'.$userInfo['picurl'];
    }
    $modelInfo = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($tongchengInfo['model_id']);
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($tongchengInfo['type_id']);
    $cateInfo = array();
    if($tongchengInfo['cate_id'] > 0){
        $cateInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_by_id($tongchengInfo['cate_id']);
        if($cateInfoTmp){
            $cateInfo = $cateInfoTmp;
        }
    }
    $siteInfo = array('id'=>1,'name'=>$tongchengConfig['plugin_name']);
    if($tongchengInfo['site_id'] > 1){
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($tongchengInfo['site_id']);
    }

    $attrList = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY paixu ASC,id DESC ",0,50);
    $tagList = C::t('#tom_tongcheng#tom_tongcheng_tag')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id DESC ",0,50);
    $photoCount = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_count(" AND tongcheng_id={$tongchengInfo['id']} ");
    $photoListTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$tongchengInfo['id']} "," ORDER BY id ASC ",0,50);
    $photoList = array();
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach ($photoListTmp as $kk => $vv){
            if($tongchengConfig['open_yun'] == 2 && !empty($vv['oss_picurl'])){
                $picurl = $vv['oss_picurl'];
            }else if($tongchengConfig['open_yun'] == 3 && !empty($vv['qiniu_picurl'])){
                $picurl = $vv['qiniu_picurl'];
            }else{
                if(!preg_match('/^http/', $vv['picurl']) ){
                    if(strpos($vv['picurl'], 'source/plugin/tom_tongcheng/data/') === false){
                        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                    }else{
                        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$vv['picurl'];
                    }
                }else{
                    $picurl = $vv['picurl'];
                }
            }
            $photoList[$kk] = $picurl;
        }
    }
    
    $outArr['data'] = $tongchengInfo;
    $outArr['data']['userInfo'] = $userInfo;
    $outArr['data']['modelInfo'] = $modelInfo;
    $outArr['data']['typeInfo'] = $typeInfo;
    $outArr['data']['cateInfo'] = $cateInfo;
    $outArr['data']['siteInfo'] = $siteInfo;
    $outArr['data']['attrList'] = $attrList;
    $outArr['data']['tagList'] = $tagList;
    $outArr['data']['photoList'] = $photoList;
    $outArr['data']['shareTitle'] = $title;
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_fabu_model'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    if($__UserInfo['editor'] == 1){
        $modelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list("  AND is_show=1 AND sites_show=0 "," ORDER BY paixu ASC,id DESC ",0,50);
    }else{
        $modelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list(" AND only_editor=0  AND is_show=1 AND sites_show=0 "," ORDER BY paixu ASC,id DESC ",0,50);
    }
    
    $modelList = array();
    if(is_array($modelListTmp) && !empty($modelListTmp)){
        foreach ($modelListTmp as $key => $value){
            $modelList[$key] = $value;
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_tongcheng/') === FALSE){
                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurl = rtrim($_G['siteurl'], "/").'/'.$value['picurl'];
                }
            }else{
                $picurl = $value['picurl'];
            }
            $modelList[$key]['picurl'] = $picurl;
            
            $typeListTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_all_list(" AND model_id={$value['id']} "," ORDER BY paixu ASC,id DESC ",0,20);
            $modelList[$key]['showType'] = 0;
            if(count($typeListTmp) > 1){
                $modelList[$key]['showType'] = 1;
            }
            $modelList[$key]['childs'] = $typeListTmp;
        }
    }
    
    $outArr['data'] = $modelList;
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_index_focuspic'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $focuspicListTmp = C::t('#tom_tongcheng#tom_tongcheng_focuspic')->fetch_all_list(" AND site_id=1 "," ORDER BY fsort ASC,id DESC ",0,10);
    $focuspicList = array();
    foreach ($focuspicListTmp as $key => $value) {   
        if(!preg_match('/^http/', $value['picurl']) ){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $picurl = $value['picurl'];
        }
        $focuspicList[] = $picurl;
    }
    $outArr['data'] = $focuspicList;
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_index_tongji'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $commonClicks = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_all_sun_clicks(" AND id IN({$sql_in_site_ids}) ");
    $fabuNum = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_count("  AND status=1 AND site_id IN({$sql_in_site_ids}) ");
    
    $clicksNum = $commonClicks + $tongchengConfig['virtual_clicks'];
    $fabuNum = $fabuNum + $tongchengConfig['virtual_fabunum'];
    
    $clicksNumTxt = $clicksNum;
    if($clicksNum>10000){
        $clicksNumTmp = $clicksNum/10000;
        $clicksNumTxt = number_format($clicksNumTmp,2).lang("plugin/tom_xiaofenlei", "wan"); 
    }else if($clicksNum>1000000){
        $clicksNumTmp = $clicksNum/10000;
        $clicksNumTxt = number_format($clicksNumTmp,0).lang("plugin/tom_xiaofenlei", "wan");
    }
    
    $outArr['data']['clicksNum'] = $clicksNumTxt;
    $outArr['data']['fabuNum'] = $fabuNum;
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_index_categorys'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $modelListTmp = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_all_list("  AND is_show=1 AND sites_show=0 "," ORDER BY paixu ASC,id DESC ",0,50);

    if(is_array($modelListTmp) && !empty($modelListTmp)){
        foreach ($modelListTmp as $key => $value){
            $outArrItem = array();
                    
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_tongcheng/') === FALSE){
                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurl = rtrim($_G['siteurl'], "/").'/'.$value['picurl'];
                }
            }else{
                $picurl = $value['picurl'];
            }
            
            $outArrItem['id']        = $value['id'];
            $outArrItem['title']     = $value['name'];
            $outArrItem['picurl']    = $picurl;
            
            $outArr['data'][$key] = $outArrItem;

        }
    }
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_index_topnews'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $whereStr = ' AND status=1 AND shenhe_status=1 ';
    $orderStr = " ORDER BY id DESC ";
    
    $tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list($whereStr,$orderStr,0,10);
    if(is_array($tongchengListTmp) && !empty($tongchengListTmp)){
        foreach ($tongchengListTmp as $key => $value){
            $outArrItem = array();
            $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
            if($userInfoTmp){
                $outArrItem['id'] = $value['id'];
                $outArrItem['time'] = dgmdate($value['add_time'],"[m-d]",$tomSysOffset);
                $userInfoTmp['nickname'] = cutstr($userInfoTmp['nickname'], 14, '...');
                $outArrItem['nickname'] = $userInfoTmp['nickname'];
            }
            $outArr['data'][] = $outArrItem;
        }
    }
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_fabu_input'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $type_id = intval($_GET['type_id'])>0? intval($_GET['type_id']):0;
    
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($type_id);
    $modelInfo = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($typeInfo['model_id']);
    $cateList = C::t('#tom_tongcheng#tom_tongcheng_model_cate')->fetch_all_list(" AND type_id={$type_id}  "," ORDER BY paixu ASC,id DESC ",0,50);
    
    $tagListTmp = C::t('#tom_tongcheng#tom_tongcheng_model_tag')->fetch_all_list(" AND type_id={$type_id} "," ORDER BY paixu ASC,id DESC ",0,50);
    $tagList = array();
    if(is_array($tagListTmp) && !empty($tagListTmp)){
        foreach ($tagListTmp as $key => $value){
            $tagList[$key]['name'] = $value['name'];
            $tagList[$key]['value'] = $value['id'];
            $tagList[$key]['checked'] = false;
        }
    }
    
    $attrListTmp = C::t('#tom_tongcheng#tom_tongcheng_model_attr')->fetch_all_list(" AND type_id={$type_id} "," ORDER BY paixu ASC,id DESC ",0,50);
    
    $attrList = array();
    if(is_array($attrListTmp) && !empty($attrListTmp)){
        foreach ($attrListTmp as $key => $value){
            $attrList[$key] = $value;
            if($value['type'] == 2){
                $value_listStr = str_replace("\r\n","{n}",$value['value']); 
                $value_listStr = str_replace("\n","{n}",$value_listStr);
                $attrList[$key]['list'] = explode("{n}", $value_listStr);
            }
        }
    }
    
    $outArr['data']['mustBindTel'] = 0;
    if(empty($__XiaoUserInfo['tel']) && empty($__UserInfo['tel'])){
        if($xiaofenleiConfig['must_bind_tel'] == 1){
            $outArr['data']['mustBindTel'] = 1;
        }
    }else if(!empty($__UserInfo['tel']) && empty($__XiaoUserInfo['tel'])){
        $updateData           = array();
        $updateData['tel']    = $__UserInfo['tel'];
        C::t('#tom_xiaofenlei#tom_xiaofenlei_user')->update($__XiaoUserInfo['id'],$updateData);
    }
    $outArr['data']['userInfo']     = $__UserInfo;
    $outArr['data']['typeInfo']     = $typeInfo;
    $outArr['data']['modelInfo']    = $modelInfo;
    $outArr['data']['cateList']     = $cateList;
    $outArr['data']['tagList']      = $tagList;
    $outArr['data']['attrList']     = $attrList;
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'save_fabu'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = xiao_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id    = $__UserInfo['id'];
    $type_id    = isset($_GET['type_id'])? intval($_GET['type_id']):0;
    $cate_id    = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $city_id    = isset($_GET['city_id'])? intval($_GET['city_id']):0;
    $area_id    = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id  = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $xm         = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel        = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $content    = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $typeInfo = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($type_id);
    $model_id = $typeInfo['model_id'];
    $modelInfo = C::t('#tom_tongcheng#tom_tongcheng_model')->fetch_by_id($typeInfo['model_id']);
    
    if(empty($userInfo) || empty($typeInfo)){
        $outArr = array(
            'code'  => 500,
            'msg'   => lang("plugin/tom_xiaofenlei", "save_fabu_error500"),
        );
        echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'code'  => 301,
            'msg'   => lang("plugin/tom_xiaofenlei", "save_fabu_error301"),
        );
        echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    }
    
    $lastTongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list(" AND user_id={$user_id} "," ORDER BY id DESC ",0,1);
    if($lastTongchengListTmp && $lastTongchengListTmp[0]['add_time'] > 0 && $userInfo['editor']==0){
        $nextFabuTime = $lastTongchengListTmp[0]['add_time'] + $tongchengConfig['fabu_next_minute']*60;
        $save_fabu_error302 = lang("plugin/tom_xiaofenlei", "save_fabu_error302");
        $save_fabu_error302 = str_replace("{MINUTE}",$tongchengConfig['fabu_next_minute'],$save_fabu_error302);
        if($nextFabuTime > TIMESTAMP){
            $outArr = array(
                'code'  => 302,
                'msg'   => $save_fabu_error302,
            );
            echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
        }
    }
    
    $__CommonInfo = C::t('#tom_tongcheng#tom_tongcheng_common')->fetch_by_id(1);
    if(!empty($__CommonInfo['forbid_word'])){
        $forbid_word = preg_quote(trim($__CommonInfo['forbid_word']), '/');
        $forbid_word = str_replace(array("\\*"), array('.*'), $forbid_word);
        $forbid_word = '.*('.$forbid_word.').*';
        $forbid_word = '/^('.str_replace(array("\r\n", ' '), array(').*|.*(', ''), $forbid_word).')$/i';
        if(@preg_match($forbid_word, $content,$matches)) {
            $i = count($matches)-1;
            $word = '';
            if(isset($matches[$i]) && !empty($matches[$i])){
                $word = $matches[$i];
            }
            $save_fabu_error303 = lang("plugin/tom_xiaofenlei", "save_fabu_error303");
            $save_fabu_error303 = str_replace("{WORD}",$word,$save_fabu_error303);
            $outArr = array(
                'status'=> 303,
                'word'=> $save_fabu_error303,
            );
            echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
        }
                
    }
    
    $attrnameArr = $attrArr = $attrunitArr = $attrpaixuArr = $attrdateArr = $tagnameArr = $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "attrname_") !== false){
            $attr_id = intval(ltrim($key, 'attrname_'));
            $attrnameArr[$attr_id] = addslashes($value);
        }
        if(strpos($key, "attrpaixu_") !== false){
            $attr_id = intval(ltrim($key, 'attrpaixu_'));
            $attrpaixuArr[$attr_id] = addslashes($value);
        }
        if(strpos($key, "attrunit_") !== false){
            $attr_id = intval(ltrim($key, 'attrunit_'));
            $attrunitArr[$attr_id] = addslashes($value);
        }
        if(strpos($key, "attr_") !== false){
            $attr_id = intval(ltrim($key, 'attr_'));
            $attrArr[$attr_id] = addslashes($value);
        }
        if(strpos($key, "attrdate_") !== false){
            $attr_id = intval(ltrim($key, 'attrdate_'));
            $attrdateArr[$attr_id] = addslashes($value);
        }
        if(strpos($key, "tagname_") !== false){
            $tag_id = intval(ltrim($key, 'tagname_'));
            $tagnameArr[$tag_id] = addslashes($value);
        }
    }
    
    $tagArr = array();
    if(isset($_GET['tag']) && !empty($_GET['tag'])){
        $tagArrTmp = explode(',', $_GET['tag']);
        if(is_array($tagArrTmp) && !empty($tagArrTmp)){
            foreach ($tagArrTmp as $key => $value){
                if(is_numeric($value)){
                    $tagArr[] = $value;
                }
            }
        }
    }
    
    $photoArr = array();
    if(is_array($_GET['photo']) && !empty($_GET['photo'])){
        foreach ($_GET['photo'] as $key => $value){
            if(!empty($value)){
                $photoArr[] = $value;
            }
        }
        
    }
    
    $search_content = '';
    if(is_array($attrArr) && !empty($attrArr)){
        foreach ($attrArr as $key => $value){
            $search_content.=''.$attrnameArr[$key].$value.'';
        }
    }
    if(is_array($tagArr) && !empty($tagArr)){
        foreach ($tagArr as $key => $value){
            $search_content.=''.$tagnameArr[$value].'';
        }
    }

    # check input start
    if(empty($xm)){
        $outArr = array(
            'code'  => 201,
            'msg'   => lang("plugin/tom_xiaofenlei", "save_must_error201"),
        );
        echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    }
    if(empty($tel)){
        $outArr = array(
            'code'  => 202,
            'msg'   => lang("plugin/tom_xiaofenlei", "save_must_error202"),
        );
        echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    }
    if($tongchengConfig['fabu_phone_check'] == 1){
        if(preg_match("#^[1][3|8|4|5|7][0-9]{9}$#", $tel)){
        }else{
            $outArr = array(
                'code'  => 204,
                'msg'   => lang("plugin/tom_xiaofenlei", "save_must_error204"),
            );
            echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
        }
    }
    if(empty($content)){
        $outArr = array(
            'code'  => 203,
            'msg'   => lang("plugin/tom_xiaofenlei", "save_must_error203"),
        );
        echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    }
    if(is_array($attrArr) && !empty($attrArr)){
        foreach ($attrArr as $key => $value){
            $attrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_attr')->fetch_by_id($key);
            if($attrInfoTmp['is_must'] == 1){
                if(empty($value)){
                    $outArr = array(
                        'code'  => 209,
                        'msg'   => lang("plugin/tom_xiaofenlei", "save_must_error").$attrnameArr[$key],
                    );
                    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
                }
            }
        }
    }
    if(is_array($attrdateArr) && !empty($attrdateArr)){
        foreach ($attrdateArr as $key => $value){
            $attrInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_attr')->fetch_by_id($key);
            if($attrInfoTmp['is_must'] == 1){
                if(empty($value)){
                    $outArr = array(
                        'code'  => 208,
                        'msg'   => lang("plugin/tom_xiaofenlei", "save_must_error").$attrnameArr[$key],
                    );
                    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
                }
            }
            if(!empty($value)){
                if(preg_match("#^\d{4}-\d{1,2}-\d{1,2}$#", $value)){
                }else{
                    $outArr = array(
                        'code'  => 209,
                        'msg'   => $attrnameArr[$key].lang("plugin/tom_xiaofenlei", "save_must_error209"),
                    );
                    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
                }
            }
        }
    }
    # check input end
    
    $fabuPayStatus = 0;
    if($typeInfo['free_status'] == 2 && $typeInfo['fabu_price'] > 0 && $userInfo['editor']==0){
        $fabuPayStatus = 1;
    }
    
    $insertData = array();
    $insertData['site_id']      = $site_id;
    $insertData['user_id']      = $user_id;
    $insertData['model_id']     = $model_id;
    $insertData['type_id']      = $type_id;
    $insertData['cate_id']      = $cate_id;
    $insertData['city_id']      = $city_id;
    $insertData['area_id']      = $area_id;
    $insertData['street_id']    = $street_id;
    $insertData['tcshop_id']    = 0;
    $insertData['title']        = $title;
    $insertData['xm']           = $xm;
    $insertData['tel']          = $tel;
    $insertData['content']      = $content.'|+|+|+|+|+|+|+|+|+|'.$search_content.'-'.$xm.'-'.$tel;
    $insertData['refresh_time'] = TIMESTAMP;
    $insertData['add_time']     = TIMESTAMP;
    if($fabuPayStatus == 1){
        $insertData['status']       = 2;
        $insertData['pay_status']   = 1;
    }else{
        $insertData['status']       = 1;
        $insertData['pay_status']   = 0;
    }
    if($modelInfo['must_shenhe'] == 1 && $userInfo['editor']==0){
        $insertData['shenhe_status']       = 2;
    }else{
        $insertData['shenhe_status']       = 1;
    }
    if(C::t('#tom_tongcheng#tom_tongcheng')->insert($insertData)){
        
        $tongchengId = C::t('#tom_tongcheng#tom_tongcheng')->insert_id();
        
        if(is_array($attrArr) && !empty($attrArr)){
            foreach ($attrArr as $key => $value){
                if(!empty($attrnameArr[$key]) && !empty($value)){
                    $insertData = array();
                    $insertData['model_id']     = $model_id;
                    $insertData['type_id']      = $type_id;
                    $insertData['tongcheng_id'] = $tongchengId;
                    $insertData['attr_id']      = $key;
                    $insertData['attr_name']    = $attrnameArr[$key];
                    $insertData['value']        = $value;
                    $insertData['unit']         = $attrunitArr[$key];
                    $insertData['paixu']        = $attrpaixuArr[$key];
                    $insertData['add_time']     = TIMESTAMP;
                    C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData);
                }
            }
        }
        
        if(is_array($attrdateArr) && !empty($attrdateArr)){
            foreach ($attrdateArr as $key => $value){
                if(!empty($attrnameArr[$key]) && !empty($value)){
                    $insertData = array();
                    $insertData['model_id']     = $model_id;
                    $insertData['type_id']      = $type_id;
                    $insertData['tongcheng_id'] = $tongchengId;
                    $insertData['attr_id']      = $key;
                    $insertData['attr_name']    = $attrnameArr[$key];
                    $insertData['value']        = $value;
                    $insertData['time_value']   = strtotime($value);
                    $insertData['unit']         = $attrunitArr[$key];
                    $insertData['paixu']        = $attrpaixuArr[$key];
                    $insertData['add_time']     = TIMESTAMP;
                    C::t('#tom_tongcheng#tom_tongcheng_attr')->insert($insertData); 
                }
            }
        }
        
        if(is_array($tagArr) && !empty($tagArr)){
            foreach ($tagArr as $key => $value){
                if(!empty($tagnameArr[$value]) && !empty($value)){
                    $insertData = array();
                    $insertData['model_id']     = $model_id;
                    $insertData['type_id']      = $type_id;
                    $insertData['tongcheng_id'] = $tongchengId;
                    $insertData['tag_id']       = $value;
                    $insertData['tag_name']     = $tagnameArr[$value];
                    $insertData['add_time']     = TIMESTAMP;
                    C::t('#tom_tongcheng#tom_tongcheng_tag')->insert($insertData);
                }
            }
        }
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                if(!empty($value)){
                    $insertData = array();
                    $insertData['tongcheng_id'] = $tongchengId;
                    $insertData['picurl']       = $value;
                    $insertData['add_time']     = TIMESTAMP;
                    C::t('#tom_tongcheng#tom_tongcheng_photo')->insert($insertData);
                }
            }
        }
        
        $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongchengId);
        $outArr = array(
            'code'   => 1,
            'data'   => $tongchengInfo,
        );
        echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
        
    }else{
        $outArr = array(
            'code'  => 404,
            'msg'   => lang("plugin/tom_xiaofenlei", "save_fabu_error404"),
        );
        echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    }
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_userinfo'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $userInfo = C::t('#tom_xiaofenlei#tom_xiaofenlei_user')->fetch_by_utoken($utoken);
    
    $outArr['data'] = $userInfo;
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_config'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $help_txt = str_replace("\r\n","{n}",$xiaofenleiConfig['help_txt']);
    $help_txt = str_replace("\n","{n}",$help_txt);
    $help_txt = str_replace("\r","{n}",$help_txt);
    
    $help_txt = str_replace("{n}","\n",$help_txt);
    
    $outArr['data']['xiao_name'] = $xiaofenleiConfig['xiao_name'];
    $outArr['data']['tcshop_name'] = $xiaofenleiConfig['tcshop_name'];
    $outArr['data']['zhibo_name'] = $xiaofenleiConfig['zhibo_name'];
    $outArr['data']['kefu_tel'] = $xiaofenleiConfig['kefu_tel'];
    $outArr['data']['help_txt'] = $help_txt;
    $outArr['data']['share_title'] = $xiaofenleiConfig['share_title'];
    $outArr['data']['share_desc'] = $xiaofenleiConfig['share_desc'];
    $outArr['data']['tx_map_key'] = $xiaofenleiConfig['tx_map_key'];
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_my_list'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $page  = intval($_GET['page'])>0? intval($_GET['page']):1;
    $type  = intval($_GET['type'])>1? intval($_GET['type']):1;

    $where = " AND user_id={$__UserInfo['id']} ";
    $order = " ORDER BY refresh_time DESC,id DESC ";
    if($type == 2){
        $where.= " AND status=1 ";
    }
    if($type == 3){
        $where.= " AND pay_status=1 ";
    }
    if($type == 4){
        $where.= " AND (shenhe_status=2 OR shenhe_status=3) AND (pay_status=0 OR pay_status=2) ";
        $order = " ORDER BY shenhe_status ASC,id DESC ";
    }
    
    $pagesize = 8;
    $start = ($page - 1)*$pagesize;
    $tongchengListTmp = C::t('#tom_tongcheng#tom_tongcheng')->fetch_all_list(" {$where} "," {$order} ",$start,$pagesize);
    
    $tongchengList = array();
    foreach ($tongchengListTmp as $key => $value) {
        
        $tongchengList[$key] = $value;
        $tongchengList[$key]['content'] = contentFormat($value['content']);
        $tongchengList[$key]['showTop'] = $showTop;

        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        if(!preg_match('/^http/', $userInfoTmp['picurl']) ){
            $userInfoTmp['picurl'] = rtrim($_G['siteurl'], "/").'/'.$userInfoTmp['picurl'];
        }
        $siteInfoTmp = array('id'=>1,'name'=>$tongchengConfig['plugin_name']);
        if($value['site_id'] > 1){
            $siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        }

        $typeInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_model_type')->fetch_by_id($value['type_id']);
        $tongchengAttrListTmp = C::t('#tom_tongcheng#tom_tongcheng_attr')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY paixu ASC,id DESC ",0,50);
        $tongchengTagListTmp = C::t('#tom_tongcheng#tom_tongcheng_tag')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY id DESC ",0,50);
        $tongchengPhotoListTmpTmp = C::t('#tom_tongcheng#tom_tongcheng_photo')->fetch_all_list(" AND tongcheng_id={$value['id']} "," ORDER BY id ASC ",0,50);
        $tongchengPhotoListTmp = array();
        if(is_array($tongchengPhotoListTmpTmp) && !empty($tongchengPhotoListTmpTmp)){
            foreach ($tongchengPhotoListTmpTmp as $kk => $vv){
                if($tongchengConfig['open_yun'] == 2 && !empty($vv['oss_picurl'])){
                    $picurl = $vv['oss_picurl'];
                }else if($tongchengConfig['open_yun'] == 3 && !empty($vv['qiniu_picurl'])){
                    $picurl = $vv['qiniu_picurl'];
                }else{
                    if(!preg_match('/^http/', $vv['picurl']) ){
                        if(strpos($vv['picurl'], 'source/plugin/tom_tongcheng/data/') === false){
                            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                        }else{
                            $picurl = $_G['siteurl'].$vv['picurl'];
                        }
                    }else{
                        $picurl = $vv['picurl'];
                    }
                }
                $tongchengPhotoListTmp[] = $picurl;
            }
        }
        $tongchengList[$key]['userInfo'] = $userInfoTmp;
        $tongchengList[$key]['typeInfo'] = $typeInfoTmp;
        $tongchengList[$key]['attrList'] = $tongchengAttrListTmp;
        $tongchengList[$key]['tagList']  = $tongchengTagListTmp;
        $tongchengList[$key]['photoList'] = $tongchengPhotoListTmp;
        $tongchengList[$key]['siteInfo'] = $siteInfoTmp;
        
    }
    
    $outArr['data'] = $tongchengList;
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'update_status'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $tongcheng_id   = intval($_GET['tongcheng_id'])>0? intval($_GET['tongcheng_id']):0;
    
    $tongchengInfo = C::t('#tom_tongcheng#tom_tongcheng')->fetch_by_id($tongcheng_id);
    
    if($_GET['status'] == 1){
        $updateData = array();
        $updateData['status'] = 1;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id,$updateData);
    }else if($_GET['status'] == 2){
        $updateData = array();
        $updateData['status'] = 2;
        C::t('#tom_tongcheng#tom_tongcheng')->update($tongcheng_id,$updateData);
    }
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
        
}else if($_GET['mod'] == 'get_shop_index_focuspic' && $__ShowTcshop == 1){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $focuspicListTmp = C::t('#tom_tcshop#tom_tcshop_focuspic')->fetch_all_list(" AND site_id={$site_id} "," ORDER BY fsort ASC,id DESC ",0,6);
    if(is_array($focuspicListTmp) && !empty($focuspicListTmp)){
    }else{
        $focuspicListTmp = C::t('#tom_tcshop#tom_tcshop_focuspic')->fetch_all_list(" AND site_id=1 "," ORDER BY fsort ASC,id DESC ",0,6);
    }
    $focuspicList = array();
    foreach ($focuspicListTmp as $key => $value) {
        if(!preg_match('/^http/', $value['picurl']) ){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $picurl = $value['picurl'];
        }
        $focuspicList[] = $picurl;
    }
    
    $outArr['data'] = $focuspicList;
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/

}else if($_GET['mod'] == 'get_shop_index_categorys' && $__ShowTcshop == 1){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $cateListTmp = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_all_list(" AND parent_id=0 "," ORDER BY csort ASC,id DESC ",0,50);
    $i = 1;
    $navCount = 0;
    if(is_array($cateListTmp) && !empty($cateListTmp)){
        foreach ($cateListTmp as $key => $value){
            $outArrItem = array();
            
            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_tcshop/') === FALSE){
                    $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurl = rtrim($_G['siteurl'], "/").'/'.$value['picurl'];
                }
            }else{
                $picurl = $value['picurl'];
            }
            
            $outArrItem['id']        = $value['id'];
            $outArrItem['title']     = $value['name'];
            $outArrItem['picurl']    = $picurl;
            
            $outArr['data'][$key] = $outArrItem;
        }
    }
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/

}else if($_GET['mod'] == 'get_shop_index_topnews' && $__ShowTcshop == 1){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $newTcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND site_id IN({$sql_in_site_ids}) "," ORDER BY id DESC ",0,10);
    if(is_array($newTcshopListTmp) && !empty($newTcshopListTmp)){
        foreach ($newTcshopListTmp as $key => $value){
            $outArrItem = array();
            
            $outArrItem['id'] = $value['id'];
            $outArrItem['name'] = $value['name'];
                
            $outArr['data'][] = $outArrItem;
        }
    }
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_shop_list' && $__ShowTcshop == 1){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $tab            = intval($_GET['tab'])>0? intval($_GET['tab']):1;
    $user_id        = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
    $no_tcshop_id   = intval($_GET['no_tcshop_id'])>0? intval($_GET['no_tcshop_id']):0;
    $area_id        = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id      = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $cate_id        = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
    $cate_child_id  = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
    $vip_level      = intval($_GET['vip_level'])>0? intval($_GET['vip_level']):0;
    $keyword        = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    $tabs           = isset($_GET['tabs'])? daddslashes(urldecode($_GET['tabs'])):'';
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;
    $latitude       = isset($_GET['latitude'])? daddslashes(($_GET['latitude'])):'';
    $longitude      = isset($_GET['longitude'])? daddslashes(($_GET['longitude'])):'';
    
    if($tab == 2){
        $ordertype = 'new';
    }else if($tab == 3){
        $ordertype = 'lbs';
    }else{
        $ordertype = '';
    }
    
    $tcshopList = array();
    
    $geotableFilename = DISCUZ_ROOT.'.'."/source/plugin/tom_tcshop/config/baidulbs.php";
    
    if($ordertype == 'lbs' && file_exists($geotableFilename) && !empty($latitude) && !empty($longitude)){
        
        include DISCUZ_ROOT.'./source/plugin/tom_tcshop/class/function.lbs.php';
        $geotableData = include DISCUZ_ROOT."./source/plugin/tom_tcshop/config/baidulbs.php";
        
        $filter = '';
        if(!empty($cate_id)){
            $filter= "&filter=cate_id:{$cate_id}";
        }
        if(!empty($cate_child_id)){
            $filter= "&filter=cate_child_id:{$cate_child_id}";
        }
        
        $q = '';
        if(!empty($keyword)){
            $keywordTmp = diconv($keyword, CHARSET, 'utf-8');
            $keywordTmp = urlencode($keywordTmp);
            $q= "&q={$keywordTmp}";
        }
        
        $page_index = $page -1;
        $baiduSearchApi = "http://api.map.baidu.com/geosearch/v3/nearby?ak={$tcshopConfig['baidu_ak']}&geotable_id={$geotableData['geotable_id']}&location={$longitude},{$latitude}&radius=5000000&sortby=distance:1{$filter}{$q}&page_index={$page_index}&page_size={$pagesize}"; 
        $content = lbsGetHtml($baiduSearchApi);
        $return = json_decode($content, true);
        $return = lbs_iconv_recurrence($return);
        
        if(is_array($return) && $return['status']==0 && !empty($return['contents'])){
            foreach ($return['contents'] as $key => $value){
                
                $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
                if($tcshopInfoTmp && $tcshopInfoTmp['status']==1 && $tcshopInfoTmp['shenhe_status']==1 && in_array($tcshopInfoTmp['site_id'], $citySitesArr) ){
                    if(!preg_match('/^http/', $tcshopInfoTmp['picurl']) ){
                        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfoTmp['picurl'];
                    }else{
                        $picurl = $tcshopInfoTmp['picurl'];
                    }
                    $tcshopList[$tcshopInfoTmp['id']] = $tcshopInfoTmp;
                    $tcshopList[$tcshopInfoTmp['id']]['picurl'] = $picurl;
                    $distance = '';
                    if($value['distance'] > 1000){
                        $distance = $value['distance']/1000;
                        $distance = number_format($distance,2).'km';
                    }else{
                        $distance = $value['distance'].'m';
                    }
                    $tcshopList[$tcshopInfoTmp['id']]['distance'] = $distance;
                    
                }
            }
        }
        
    }else{
        
        $searchAddress = '';
        if($tcshopConfig['open_ruzhu_area'] == 0){
            if(!empty($street_id)){
                $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
                $searchAddress = $streetInfo['name'];
            }else if(!empty($area_id)){
                $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
                $searchAddress = $areaInfo['name'];
            }
        }
        
        $whereStr = ' AND status=1 AND shenhe_status=1 ';
        if(!empty($sql_in_site_ids)){
            $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
        }
        if(!empty($user_id)){
            $whereStr.= " AND user_id={$user_id} ";
        }
        if(!empty($cate_id)){
            $whereStr.= " AND cate_id={$cate_id} ";
        }
        if(!empty($cate_child_id)){
            $whereStr.= " AND cate_child_id={$cate_child_id} ";
        }
        if(!empty($area_id)){
            $whereStr.= " AND area_id={$area_id} ";
        }
        if(!empty($street_id)){
            $whereStr.= " AND street_id={$street_id} ";
        }
        if(!empty($vip_level)){
            $whereStr.= " AND vip_level>0 ";
        }

        $orderStr = " ORDER BY topstatus DESC, vip_level DESC,clicks DESC,id DESC ";
        if($ordertype == 'new'){
            $orderStr = " ORDER BY id DESC ";
        }

        $pagesize       = $pagesize;
        $start          = ($page - 1)*$pagesize;
        $tcshopListTmp  = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list($whereStr,$orderStr,$start,$pagesize,$keyword,$searchAddress,$tabs);
        foreach ($tcshopListTmp as $key => $value){
            $tcshopList[$key] = $value;
            if(!preg_match('/^http/', $value['picurl']) ){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
            $tcshopList[$key]['picurl'] = $picurl;
        }
        
    }
    
    
    if(is_array($tcshopList) && !empty($tcshopList)){
        foreach ($tcshopList as $key => $val){
            $outArrItem = array();
            
            if(empty($no_tcshop_id) || $no_tcshop_id != $val['id'] ){
                $tabsStr = str_replace("    "," ",$val['tabs']);
                $tabsStr = str_replace("   "," ",$tabsStr);
                $tabsStr = str_replace("  "," ",$tabsStr);
                $tabsArrTmp = explode(' ', $tabsStr);
                $tabsArr = array();
                if(is_array($tabsArrTmp) && !empty($tabsArrTmp)){
                    foreach ($tabsArrTmp as $kk => $vv){
                        $vv = trim($vv);
                        if(!empty($vv)){
                            $tabsArr[] = $vv;
                        }
                    }
                }
                
                $areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($val['area_id']);
                $streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($val['street_id']);
                
                $outArrItem['id']           = $val['id'];
                $outArrItem['picurl']       = $val['picurl'];
                $outArrItem['vip_level']    = $val['vip_level'];
                $outArrItem['topstatus']    = $val['topstatus'];
                $outArrItem['name']         = $val['name'];
                $outArrItem['tabsList']     = $tabsArr;
                $outArrItem['business_hours'] = lang('plugin/tom_tcshop','template_list_business_hours_title').''.$val['business_hours'];
                $outArrItem['tel']          = $val['tel'];
                $outArrItem['clicks']       = $val['clicks'];
                $outArrItem['tab']          = $tab;
                $outArrItem['distance']     = $val['distance'];
                
                if($tcshopConfig['open_list_area'] == 1){
                    $outArrItem['address']  = $val['address'];
                }else if($tcshopConfig['open_list_area'] == 2){
                    $outArrItem['address']  = $areaInfo['name'].' '.$streetInfo['name'];
                }
                
                $outArr['data'][] = $outArrItem;    
            }
        }
    }
            
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_shop_location' && $__ShowTcshop == 1){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $latitude       = isset($_GET['latitude'])? daddslashes(($_GET['latitude'])):'';
    $longitude      = isset($_GET['longitude'])? daddslashes(($_GET['longitude'])):'';
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcshop/class/function.lbs.php';
    
    $baiduSearchApi = "http://api.map.baidu.com/geoconv/v1/?coords={$longitude},{$latitude}&from=1&to=5&ak={$tcshopConfig['baidu_ak']}";
    $content = lbsGetHtml($baiduSearchApi);
    $return = json_decode($content, true);
    $return = lbs_iconv_recurrence($return);
    
    $outArr['data']['status']       = $return['status'];
    $outArr['data']['longitude']    = $return['result'][0]['x'];
    $outArr['data']['latitude']     = $return['result'][0]['y'];
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_shop_info' && $__ShowTcshop == 1){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $tcshop_id = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;

    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    if($tcshopInfo['status'] == 1 && $tcshopInfo['shenhe_status'] == 1){
        
    }else{
        $outArr = array(
            'code'  => 404,
            'msg'   => lang("plugin/tom_xiaofenlei", "shop_detail_404"),
        );
        echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    }
    
    $cateInfo = C::t('#tom_tcshop#tom_tcshop_cate')->fetch_by_id($tcshopInfo['cate_id']);

    $photoListTmp = C::t('#tom_tcshop#tom_tcshop_photo')->fetch_all_list(" AND tcshop_id={$tcshop_id} ","ORDER BY id ASC",0,20);
    $photoList = $photoThumbList = array();
    $i = 1;
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach ($photoListTmp as $key => $value){
            if($tongchengConfig['open_yun'] == 2 && !empty($value['oss_picurl'])){
                $picurlTmp = $value['oss_picurl'];
                $picurlTmp2 = $value['oss_picurl'].'?x-oss-process=image/resize,m_fill,h_120,w_120';
            }else if($tongchengConfig['open_yun'] == 3 && !empty($value['qiniu_picurl'])){
                $picurlTmp = $value['qiniu_picurl'];
                $picurlTmp2 = $value['qiniu_picurl'].'?imageView2/1/w/120/h/120';
            }else{
                if(!preg_match('/^http/', $value['picurl']) ){
                    if(strpos($value['picurl'], 'source/plugin/tom_tcshop/') === FALSE){
                        $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                        $picurlTmp2 = $picurlTmp;
                    }else{
                        $picurlTmp = $_G['siteurl'].$value['picurl'];
                        $picurlTmp2 = $picurlTmp;
                    }
                }else{
                    $picurlTmp = $value['picurl'];
                    $picurlTmp2 = $picurlTmp;
                }
            }

            $photoList[] = $picurlTmp;

            if($i <= 3){
                if(file_exists(DISCUZ_ROOT.'./'.$value['thumb'])){
                    $photoThumbList[] = $_G['siteurl'].$value['thumb'];
                }
            }
            
            $i++;
        }
    }

    $gonggao = $tcshopInfo['gonggao'];
    $content = stripslashes($tcshopInfo['content']);
    $content = strip_tags($content);
    $contentTmp = str_replace("\r\n","",$content);
    $contentTmp = str_replace("\n","",$contentTmp);
    $contentTmp = str_replace("\r","",$contentTmp);

    if($tcshopInfo['admin_edit'] == 0){
        $content = str_replace("\r\n","<br/>",$content);
        $content = str_replace("\n","<br/>",$content);
        $content = str_replace("\r","<br/>",$content);
    }

    $tabsStr = str_replace("    "," ",$tcshopInfo['tabs']);
    $tabsStr = str_replace("   "," ",$tabsStr);
    $tabsStr = str_replace("  "," ",$tabsStr);
    $tabsArrTmp = explode(' ', $tabsStr);
    $tabsArr = array();
    $i = 0;
    if(is_array($tabsArrTmp) && !empty($tabsArrTmp)){
        foreach ($tabsArrTmp as $kk => $vv){
            $vv = trim($vv);
            if(!empty($vv)){
                $tabsArr[$kk]['i'] = $i;
                $tabsArr[$kk]['txt'] = $vv;
                $tabsArr[$kk]['url'] = "lists?tabs=".urlencode(trim($vv));
                $i++;
            }
        }
    }

    if(!preg_match('/^http/', $tcshopInfo['picurl']) ){
        if(strpos($tcshopInfo['picurl'], 'source/plugin/tom_tcshop/') === FALSE){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['picurl'];
        }else{
            $picurl = $_G['siteurl'].$tcshopInfo['picurl'];
        }
    }else{
        $picurl = $tcshopInfo['picurl'];
    }

    if(!preg_match('/^http/', $tcshopInfo['kefu_qrcode']) ){
        if(strpos($tcshopInfo['kefu_qrcode'], 'source/plugin/tom_tcshop/') === FALSE){
            $kefu_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$tcshopInfo['kefu_qrcode'];
        }else{
            $kefu_qrcode = $_G['siteurl'].$tcshopInfo['kefu_qrcode'];
        }
    }else{
        $kefu_qrcode = $tcshopInfo['kefu_qrcode'];
    }

    $tcshopTuwenList = array();
    if($tcshopInfo['admin_edit'] == 0){
        $tcshopTuwenListTmp = C::t('#tom_tcshop#tom_tcshop_tuwen')->fetch_all_list(" AND tcshop_id={$tcshopInfo['id']} "," ORDER BY paixu ASC,id ASC ",0,50);
        if(is_array($tcshopTuwenListTmp) && !empty($tcshopTuwenListTmp)){
            foreach ($tcshopTuwenListTmp as $kk => $vv){
                if(!preg_match('/^http/', $vv['picurl']) ){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vv['picurl'];
                }else{
                    $picurlTmp = $vv['picurl'];
                }
                $tcshopTuwenList[$kk]['picurl'] = $picurlTmp;
                $tcshopTuwenList[$kk]['picurlList'][] = $picurlTmp;
                $tcshopTuwenList[$kk]['txt'] = $vv['txt'];
            }
        }
    }

    $isGuanzu = 0;
    if(!empty($__UserInfo['id'])){
        $guanzuListTmp = C::t('#tom_tcshop#tom_tcshop_guanzu')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND tcshop_id={$tcshop_id} "," ORDER BY id DESC ",0,1);
        if(is_array($guanzuListTmp) && !empty($guanzuListTmp)){
            $isGuanzu = 1;
        }
    }
    
    $outArr['data'] = $tcshopInfo;
    $outArr['data']['cateInfo']     = $cateInfo;
    $outArr['data']['photoList']    = $photoList;
    $outArr['data']['focuspic']     = $photoThumbList;
    $outArr['data']['gonggao']      = $gonggao;
    $outArr['data']['content']      = $content;
    $outArr['data']['tcshopTuwenList'] = $tcshopTuwenList;
    $outArr['data']['tabsArr']      = $tabsArr;
    $outArr['data']['picurl']       = $picurl;
    $outArr['data']['isGuanzu']     = $isGuanzu;
    $outArr['data']['youhui_model_id']      = $tcshopConfig['youhui_model_id'];
    $outArr['data']['zhaopin_model_id']     = $tcshopConfig['zhaopin_model_id'];
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
  
}else if($_GET['mod'] == 'get_shop_clicks' && $__ShowTcshop == 1){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $tcshop_id = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    
    DB::query("UPDATE ".DB::table('tom_tcshop')." SET clicks=clicks+1 WHERE id='$tcshop_id' ", 'UNBUFFERED');
    $outArr['data']['tcshop_id'] = $tcshop_id;
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_shop_guanzu' && $__ShowTcshop == 1){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'=> array(),
    );
    
    $tcshop_id      = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;

    $guanzuListTmp = C::t('#tom_tcshop#tom_tcshop_guanzu')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND tcshop_id={$tcshop_id} "," ORDER BY id DESC ",0,1);
    
    if(is_array($guanzuListTmp) && !empty($guanzuListTmp)){
        $outArr['data']['status'] = 2;
        $outArr['data']['title'] = lang('plugin/tom_xiaofenlei', 'shop_guanzu_2');
        echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    }
    
    $insertData = array();
    $insertData['user_id']      = $__UserInfo['id'];
    $insertData['tcshop_id']    = $tcshop_id;
    $insertData['add_time']     = TIMESTAMP;
    if(C::t('#tom_tcshop#tom_tcshop_guanzu')->insert($insertData)){
        DB::query("UPDATE ".DB::table('tom_tcshop')." SET guanzu=guanzu+1 WHERE id='$tcshop_id' ", 'UNBUFFERED');
        $outArr['data']['status'] = 1;
        $outArr['data']['title'] = lang('plugin/tom_xiaofenlei', 'shop_guanzu_1');
    }
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_shop_distance' && $__ShowTcshop == 1){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'=> array(),
    );
    
    $tcshop_id      = intval($_GET['tcshop_id'])>0? intval($_GET['tcshop_id']):0;
    $longitude      = !empty($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $latitude       = !empty($_GET['latitude'])? addslashes($_GET['latitude']):'';

    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcshop/class/function.lbs.php';
    if(!empty($longitude) && !empty($latitude) && !empty($tcshopInfo['latitude']) && !empty($tcshopInfo['longitude'])){
        
        $distanceApi = "http://api.map.baidu.com/routematrix/v2/driving?output=json&origins={$latitude},{$longitude}&destinations={$tcshopInfo['latitude']},{$tcshopInfo['longitude']}&ak={$tcshopConfig['baidu_ak']}";
        $content = lbsGetHtml($distanceApi);
        $return = json_decode($content, true);
        $return = lbs_iconv_recurrence($return);
        if(is_array($return) && $return['status'] == 0 && !empty($return['result'])){
            $outArr['data'] = lang('plugin/tom_tcshop','template_distance_msg_1').$return['result'][0]['distance']['text'].lang('plugin/tom_tcshop','template_distance_msg_2').$return['result'][0]['duration']['text'];
        }

    }
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else if($_GET['mod'] == 'get_zhibo_list'){
    
    $outArr = array(
        'code'  => 1,
        'msg'   => '',
        'data'  => array(),
    );
    
    $page  = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize  = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):6;

    $whereStr = " AND live_status IN(101,102,103,105) ";
    
    $orderStr = " ORDER BY live_status ASC,id DESC ";
    $pagesize = $pagesize;
    $start = ($page - 1)*$pagesize;
    $zhiboListTmp = C::t('#tom_xiaofenlei#tom_xiaofenlei_zhibo')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);
    
    $zhiboList = array();
    foreach ($zhiboListTmp as $key => $value) {

        $zhiboList[$key] = $value;
        
        if(!preg_match('/^http/', $value['cover_img']) ){
            if(strpos($value['cover_img'], 'source/plugin/tom_') === FALSE){
                $zhiboList[$key]['cover_img'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['cover_img'];
            }else{
                $zhiboList[$key]['cover_img'] = rtrim($_G['siteurl'], "/").'/'.$value['cover_img'];
            }
        }
        
        $zhiboList[$key]['start_time'] = dgmdate($value['start_time'],"Y-m-d H:i",$tomSysOffset);
        
    }
    
    $outArr['data'] = $zhiboList;
    
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
    
}else{
    $outArr = array(
        'code'  => 0,
        'msg'   => 'no mod',
    );
    echo tom_json_encode($outArr);exit; /*dism��taobao��com*/
}