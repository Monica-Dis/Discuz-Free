<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$kuaidiConfig = $_G['cache']['plugin']['tom_kuaidi'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$cssJsVersion = "20200324";

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_ucenter/tom_ucenter.inc.php')){
}else{
    echo '<a href="https://addon.dismall.com/?tom_ucenter.plugin">https://addon.dismall.com/?tom_ucenter.plugin</a>';exit;
}

include DISCUZ_ROOT.'./source/plugin/tom_kuaidi/kuaidi.class.php';

$appcode = $kuaidiConfig['appcode'];

$kuaidi = new AliKuaidi($appcode);

/********************* kuaidiinfo ***********************/
if($_GET['mod'] == 'kuaidiinfo'){
    
    $address_id = intval($_GET['address_id'])>0? intval($_GET['address_id']):0;
    $no         = !empty($_GET['no'])? addslashes($_GET['no']):'';
    $type       = !empty($_GET['type'])? addslashes($_GET['type']):'';

    $addressInfo = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
    
    $kdSmsArr = $kuaidi->query($no, $type);
    $resultArr = array();
    if($kdSmsArr && $kdSmsArr['status'] == 0 && $kdSmsArr['msg'] == 'ok'){
        $resultArrTmp = $kdSmsArr['result'];
        
        $resultCount = count($resultArrTmp['list']);
        $i = 1;
        foreach($resultArrTmp['list'] as $key => $value){
            $timeTmp = strtotime($value['time']);
            
            $statusTmp = $value['status'];
            preg_match_all('/1[34578][0-9]{8,10}/', $statusTmp, $match);
            foreach($match[0] as $k => $v){ 
                $telTmp = '<a href="tel:'.$v.'">'.$v.'</a>';
                $statusTmp = str_replace($v,$telTmp,$statusTmp);
            }
            $resultArrTmp['list'][$key]['time_hd']  = dgmdate($timeTmp, 'm-d',$tomSysOffset);
            $resultArrTmp['list'][$key]['time_bd']  = dgmdate($timeTmp, 'H:i',$tomSysOffset);
            $resultArrTmp['list'][$key]['status']   = $statusTmp;
            $resultArrTmp['list'][$key]['on']       = '';
            $resultArrTmp['list'][$key]['first']    = 0;
            if($i == 1){
                $resultArrTmp['list'][$key]['on']       = 'on';
            }else if($i == $resultCount){
                $resultArrTmp['list'][$key]['first']    = 1;
            }
            $i++;
        }
        $resultArr = $resultArrTmp;
    }
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_kuaidi:kuaidiinfo");
    
    
    
}else {
    echo 'tom kuaidi';exit;
}