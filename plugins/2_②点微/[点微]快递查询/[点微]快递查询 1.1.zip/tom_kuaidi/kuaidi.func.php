<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.cn
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$kuaidiConfig = $_G['cache']['plugin']['tom_kuaidi'];
include DISCUZ_ROOT.'./source/plugin/tom_kuaidi/kuaidi.class.php';

function query_kuaidi($no,$type){
    global $_G,$kuaidiConfig;
    
    $appcode = $kuaidiConfig['appcode'];

    $kuaidi = new AliKuaidi($appcode);
    $kdSmsArr = $kuaidi->query($no, $type);
    if($kdSmsArr && $kdSmsArr['status'] == 0 && $kdSmsArr['msg'] == 'ok'){
        $resultArr = array();
        $resultArr['status']    = $kdSmsArr['result']['list'][0]['status'];
        $resultArr['time']      = $kdSmsArr['result']['list'][0]['time'];
        
        return $resultArr;
    }else{
        return false;
    }
}