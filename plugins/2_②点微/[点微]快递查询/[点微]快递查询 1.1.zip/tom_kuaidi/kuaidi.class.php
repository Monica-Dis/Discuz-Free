<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.cn
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class AliKuaidi {
    
    private $appcode;
    
    public function __construct($appCode){
        $this->appcode = $appCode;
    }
	
	public function query($no='', $type=''){
        
        if(empty($no)){
			return false;
		}
        
        $host   = "https://wuliu.market.alicloudapi.com"; //api��������
        $path   = "/kdi"; //API���ʺ�׺
        $method = "GET";
    
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $this->appcode);
        
        $querys = "no={$no}";
        if(!empty($type)){
            $querys .= "&type={$type}";
        }
        
        $bodys = "";
        $url = $host . $path . "?" . $querys;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        //curl_setopt($curl, CURLOPT_HEADER, true); �粻���json, ������д��룬��ӡ����ͷ��״̬�롣
        //״̬��: 200 ������400 URL��Ч��401 appCode���� 403 �������ꣻ 500 API���ܴ���
        if (1 == strpos("$".$host, "https://")){
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }
        $content = curl_exec($curl);
        $content = json_decode($content, true);
        $content = $this->kdiconv($content);
        return $content;
	}
    
    private function kdiconv($date){
        if(is_array($date)) {
            foreach($date AS $key => $val) {
                $date[$key] = $this->kdiconv($val);
            }
        } else {
            $date = diconv($date, 'utf-8', CHARSET);
        }
        return $date;
    }
}