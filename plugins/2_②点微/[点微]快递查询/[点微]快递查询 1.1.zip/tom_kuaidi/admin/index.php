<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.cn
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_kuaidi_admin_index_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_kuaidi#tom_kuaidi')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao-com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $kuaidiInfo = C::t('#tom_kuaidi#tom_kuaidi')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($kuaidiInfo);
        C::t('#tom_kuaidi#tom_kuaidi')->update($kuaidiInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($kuaidiInfo);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism_taobao-com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_kuaidi#tom_kuaidi')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    set_list_url("tom_kuaidi_admin_index_list");
    
    $page   = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    
    $order = "ORDER BY sort ASC,id DESC";
    
    $pagesize = 50;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_kuaidi#tom_kuaidi')->fetch_all_count($where);
    $kuaidiList  = C::t('#tom_kuaidi#tom_kuaidi')->fetch_all_list($where,$order,$start,$pagesize);

//    showtableheader();
//    $Lang['index_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_1']);
//    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
//    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
//    echo '<li>' . $Lang['index_help_1'] . '</li>';
//    echo '</ul></td></tr>';
//    showtablefooter();/*Dism_taobao-com*/

    $modBasePageUrl = $modBaseUrl;
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th>' . $Lang['index_name'] . '</th>';
    echo '<th>' . $Lang['index_type'] . '</th>';
    echo '<th>' . $Lang['sort'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    $i = 1;
    foreach ($kuaidiList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['type'] . '</td>';
        echo '<td>' . $value['sort'] . '</td>';
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d",$tomSysOffset) . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'">' . $Lang['edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a><br/>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism_taobao-com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name       = isset($_GET['name'])? addslashes($_GET['name']):'';
    $type       = isset($_GET['type'])? addslashes($_GET['type']):'';
    $sort       = intval($_GET['sort'])>0? intval($_GET['sort']):1;
    
    $data['name']       = $name;
    $data['type']       = $type;
    $data['sort']       = $sort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'          => '',
        'type'          => '',
        'sort'          => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['index_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['index_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['index_type_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'sort','value'=>$options['sort'],'msg'=>$Lang['sort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',false);
        tomshownavli($Lang['edit'],$modBaseUrl.'&act=edit',true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl.'&act=add',false);
    }
    tomshownavfooter();
}