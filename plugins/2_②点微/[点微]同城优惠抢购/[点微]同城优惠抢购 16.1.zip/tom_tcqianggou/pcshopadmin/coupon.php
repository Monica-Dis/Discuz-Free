<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=coupon";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if(!empty($act) && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;
    
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
    if($goodsInfo){
        if($__UserInfo['id'] != $goodsInfo['user_id']){
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['no_quanxian_error'],CHARSET,'utf-8'),
            );    
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'code'=> 1001,
            'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
        );    
        echo json_encode($outArr); exit;
    }
    
    if($act == 'show'){

        $updateData = array();
        $updateData['status'] = 1;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($goods_id, $updateData);
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }else if($act == 'hide'){

        $updateData = array();
        $updateData['status'] = 2;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($goods_id, $updateData);
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
    }
}

$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$type_id            = isset($_GET['type_id'])? intval($_GET['type_id']):0;
$trade_id           = isset($_GET['trade_id'])? intval($_GET['trade_id']):0;
$cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
$goods_title        = isset($_GET['goods_title'])? addslashes($_GET['goods_title']):'';
$tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
$status             = isset($_GET['status'])? intval($_GET['status']):0;
$shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(" AND user_id = {$__UserInfo['id']}  AND (pay_status = 0 OR pay_status = 2) "," ORDER BY id DESC ",0,10000);
$tcshopList = array();
if(!empty($tcshopListTmp)){
    foreach($tcshopListTmp as $key => $value){
        $tcshopList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_cate')->fetch_all_list(" "," ORDER BY csort ASC, id DESC ",0,10000);
$cateList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$value['id']] = $value;
    }
}

$tradeListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_trade')->fetch_all_list(" "," ORDER BY tsort ASC, id DESC ");
$tradeList = array();
if(!empty($tradeListTmp)){
    foreach($tradeListTmp as $key => $value){
        $tradeList[$value['id']] = $value;
    }
}

$where = " AND user_id = {$__UserInfo['id']} AND open_duo_shop = 0 ";

if($site_id > 0){
    $where.= " AND site_id={$site_id} ";
}
if($type_id > 0){
    $where.= " AND type_id={$type_id} ";
}else{
    $where.= " AND type_id IN(2,3,4) ";
}
if($trade_id > 0){
    $where.= " AND trade_id={$trade_id} ";
}
if($cate_id > 0){
    $where.= " AND cate_id={$cate_id} ";
}
if($status > 0){
    $where.= " AND status={$status} ";
}
if($shenhe_status > 0){
    $where.= " AND shenhe_status={$shenhe_status} ";
}
if($tcshop_id > 0){
    $where.= " AND tcshop_id={$tcshop_id} ";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_count($where,$goods_title);
$goodsListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_list($where," ORDER BY id DESC ",$start,$pagesize,$goods_title);
$goodsList = array();
if(!empty($goodsListTmp)){
    foreach ($goodsListTmp as $key => $value) {
        $goodsList[$key] = $value;
        
        $siteInfoTmp        = $sitesList[$value['site_id']];
        $cateInfoTmp        = $cateList[$value['cate_id']];
        $tcshopInfoTmp      = $tcshopList[$value['tcshop_id']];
        $tradeInfoTmp       = $tradeList[$value['trade_id']];
        
        $orderCountTmp      = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(" AND goods_id = {$value['id']} "); 
        
        $goodsList[$key]['picurl']          = get_file_url($value['picurl']);
        $goodsList[$key]['siteInfo']        = $siteInfoTmp;
        $goodsList[$key]['cateInfo']        = $cateInfoTmp;
        $goodsList[$key]['tradeInfo']       = $tradeInfoTmp;
        $goodsList[$key]['tcshopInfo']      = $tcshopInfoTmp;
        $goodsList[$key]['orderCount']      = intval($orderCountTmp);
        $goodsList[$key]['hexiao_start_time'] = dgmdate($value['hexiao_start_time'],"Y-m-d H:i",$tomSysOffset);
        $goodsList[$key]['hexiao_time']     = dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
        $goodsList[$key]['add_time']        = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl."&site_id={$site_id}&type_id={$type_id}&cate_id={$cate_id}&trade_id={$trade_id}&goods_title={$goods_title}&status={$status}&shenhe_status={$shenhe_status}&tcshop_id={$tcshop_id}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcshopadmin/coupon");