<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=order";

$site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$goods_id           = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$order_no           = isset($_GET['order_no'])? addslashes($_GET['order_no']):'';
$tel                = !empty($_GET['tel'])? trim(addslashes($_GET['tel'])):'';
$hexiao_code        = !empty($_GET['hexiao_code'])? trim(addslashes($_GET['hexiao_code'])):'';
$hexiao_user_id     = isset($_GET['hexiao_user_id'])? intval($_GET['hexiao_user_id']):0;
$order_status       = isset($_GET['order_status'])? intval($_GET['order_status']):0;
$start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
$end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
$shenqing_refund    = isset($_GET['shenqing_refund'])? intval($_GET['shenqing_refund']):0;

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$kuaidiList = array();
if($__ShowKuaidi == 1){
    include DISCUZ_ROOT.'./source/plugin/tom_kuaidi/kuaidi.func.php';
    $kuaidiListTmp = C::t("#tom_kuaidi#tom_kuaidi")->fetch_all_list(" ", 'ORDER BY sort ASC, id DESC');
    if(is_array($kuaidiListTmp) && !empty($kuaidiListTmp)){
        foreach($kuaidiListTmp as $key => $value){
            $kuaidiList[$key] = $value;
        }
    }
}

$where = "";
$urlStr = "";
$tcshopIdsListTmp = C::t("#tom_tcshop#tom_tcshop")->fetch_all_field_list(" AND user_id = {$__UserInfo['id']} ", 'id');
$tcshopIdsList = array();
if(!empty($tcshopIdsListTmp)){
    foreach($tcshopIdsListTmp as $key => $value){
        $tcshopIdsList[] = $value['id'];
    }
}
if(!empty($tcshopIdsList)){
    $tcshopIdsStr = implode(',', $tcshopIdsList);
    $where .= " AND tcshop_id IN({$tcshopIdsStr}) ";
}else{
    $where .= " AND tcshop_id = 999999999 ";
}
if(!empty($user_id)){
    $where.= " AND user_id={$user_id} ";
    $urlStr.="&user_id={$user_id}";
}
if(!empty($site_id)){
    $where.= " AND site_id={$site_id} ";
    $urlStr.="&site_id={$site_id}";
}
if(!empty($goods_id)){
    $where.= " AND goods_id={$goods_id} ";
    $urlStr.="&goods_id={$goods_id}";
}
if(!empty($order_no)){
    $where.= " AND order_no='{$order_no}' ";
    $urlStr.="&order_no={$order_no}";
}
if(!empty($hexiao_user_id)){
    $where.=" AND hexiao_user_id={$hexiao_user_id} ";
    $urlStr.="&hexiao_user_id={$hexiao_user_id}";
}
if(!empty($tel)){
    $where.= " AND tel='{$tel}' ";
    $urlStr.="&tel={$tel}";
}
if(!empty($hexiao_code)){
    $where.= " AND hexiao_code='{$hexiao_code}' ";
    $urlStr.="&hexiao_code={$hexiao_code}";
}
if(!empty($order_status)){
    $where.= " AND order_status={$order_status} ";
    $urlStr.="&order_status={$order_status}";
}
if(!empty($start_time)){
    $startTime = strtotime($start_time);
    $where.=" AND order_time >=  {$startTime} ";
    $urlStr.="&start_time=".urlencode($start_time);
}
if(!empty($end_time)){
    $endTime = strtotime($end_time);
    $where.=" AND order_time < {$endTime} ";
    $urlStr.="&end_time=".urlencode($end_time);
}
if(!empty($shenqing_refund)){
    $where.= " AND order_status=2 AND use_num=0 AND shenqing_refund=1 ";
    $urlStr.="&shenqing_refund={$shenqing_refund}";
}

$start = ($page-1)*$pagesize;
$count = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count($where);
$orderListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
$orderList = array();
if(!empty($orderListTmp)){
    foreach($orderListTmp as $key => $value){
        $orderList[$key] = $value;
        
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $hexiaoUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['hexiao_user_id']);
        $goodsInfoTmp = C::t("#tom_tcqianggou#tom_tcqianggou_goods")->fetch_by_id($value['goods_id']);
        $goodsInfoTmp['picurl'] = get_file_url($goodsInfoTmp['picurl']);
        
        $site_name_tmp = $Lang['sites_one'];
        if($value['site_id'] > 1){
            $siteInfoTmp = $sitesList[$value['site_id']];
            $site_name_tmp = $siteInfoTmp['name'];
        }
        
        $allowQianshou = 0;
        if($value['peisong_status'] == 1 && $value['peisong_time'] > 0){
            if(TIMESTAMP > ($value['peisong_time'] + 86400*$tcqianggouConfig['shop_qianshou_days'])){
                $allowQianshou = 1;
            }
        }
        
        $showPeisongBox = 1;
        if($value['peisong_type'] == 3){
            if($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList) && empty($value['peisong_info'])){
                $showPeisongBox = 2;
            }
            if($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList) && !empty($value['kuaidi_no']) && !empty($value['kuaidi_type'])){
                $showPeisongBox = 2;
            }
        }
        
        $orderList[$key]['userInfo']        = $userInfoTmp;
        $orderList[$key]['hexiaoUserInfo']  = $hexiaoUserInfoTmp;
        $orderList[$key]['goodsInfo']       = $goodsInfoTmp;
        $orderList[$key]['site_name']       = $site_name_tmp;
        $orderList[$key]['allowQianshou']   = $allowQianshou;
        $orderList[$key]['showPeisongBox']  = $showPeisongBox;
        $orderList[$key]['orderTime']       = dgmdate($value['order_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $orderList[$key]['payTime']         = dgmdate($value['pay_time'], 'Y-m-d H:i:s',$tomSysOffset);
        $orderList[$key]['hexiaoTime']      = dgmdate($value['hexiao_time'], 'Y-m-d H:i:s',$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl.$urlStr;

$countShenqingRefund = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(" AND shenqing_refund=1 AND order_status=2 AND use_num=0 ");

if($goods_id > 0 && !empty($orderList)){
    $countOrderStatus1 = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=1 ");
    $countOrderStatus2 = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=2 ");
    $countOrderStatus2_uses = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_use_num(" AND goods_id={$goods_id} AND order_status=2 ");
    $countOrderStatus2 = $countOrderStatus2 - $countOrderStatus2_uses;
    $countOrderStatus3 = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=3 ");
    $countOrderStatus3 = $countOrderStatus3 + $countOrderStatus2_uses;
    $countOrderStatus4 = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=4 ");
    $countOrderStatus5 = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_goods_num(" AND goods_id={$goods_id} AND order_status=5 ");
}

$fahuoUrl = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=orderinfo&act=fahuo&formhash='.$formhash;
$qianshouUrl = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=orderinfo&act=qianshou&formhash='.$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcshopadmin/order");