<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$orderStatusArray = array(
    1 => '待支付',
    2 => '已支付,待消费',
    3 => '已核销',
    4 => '交易已取消',
    5 => '已退款',
);

$orderStatusColorArray = array(
    1 => '#fd0303',
    2 => '#1e9203',
    3 => '#1e9203',
    4 => '#0585d6',
    5 => '#ff6203',
);

$tabsArray = array(
    1 => '不支持退款',
    2 => '免预约',
    3 => '免费停车',
    4 => 'WIFI',
);

$typeArray = array(
    1 => '商品抢购',
    2 => '优惠券',
    3 => '折扣券',
    4 => '代金券',
);

$typeColorArray = array(
    1 => '#fd0303',
    2 => '#1e9203',
    3 => '#1e9203',
    4 => '#0585d6',
);