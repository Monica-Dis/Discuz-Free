<?php

/*
   Ӧ�ø���֧�֣�https://dism.taobao.com
   ���²����http://t.cn/Aiux1Jx1
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

$appid = trim($tongchengConfig['wxpay_appid']);  
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcchoujiang start
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')){
    $tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
    if($tcchoujiangConfig['open_tcchoujiang'] == 1){
        $__ShowTcchoujiang = 1;
    }
}
## tcchoujiang end
## print start
$__ShowPrint = 0;
$printConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_print/tom_print.inc.php')){
    $printConfig = $_G['cache']['plugin']['tom_print'];
    if($printConfig['open_print'] == 1){
        $__ShowPrint = 1;
    }
}
## print end
## tcyuyue start
$__ShowTcyuyue = 0;
$tcyuyueConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/tom_tcyuyue.inc.php')){
    $tcyuyueConfig = $_G['cache']['plugin']['tom_tcyuyue'];
    if($tcyuyueConfig['open_tcyuyue'] == 1){
        $__ShowTcyuyue = 1;
    }
}
## tcyuyue end

$orderInfo = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_by_order_no($order_no);
if($orderInfo && $orderInfo['order_status'] == 1){
    $updateData = array();
    $updateData['order_status'] = 2;
    $updateData['pay_time'] = TIMESTAMP;
    C::t('#tom_tcqianggou#tom_tcqianggou_order')->update($orderInfo['id'],$updateData);

    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($orderInfo['order_no'])));
    
    if($orderInfo['code_order'] == 1){
        DB::query("UPDATE ".DB::table('tom_tcqianggou_code')." SET code_status=2 WHERE goods_id={$orderInfo['goods_id']} AND order_id={$orderInfo['id']} AND code_status=1 ", 'UNBUFFERED');
    }

    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($orderInfo['goods_id']);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
    
    Log::DEBUG("update score_num:" . $orderInfo['score_num']);
    if($orderInfo['score_num'] > 0){
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $orderInfo['score_num'];
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
        
        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $orderInfo['score_num'];
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 68;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
    }
    
    if($tcqianggouConfig['open_back_score'] == 1){
        
        $userScoreInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
        
        $score_yuan = $tongchengConfig['score_yuan'];
        if(!empty($tcqianggouConfig['score_yuan'])){
            $score_yuan = $tcqianggouConfig['score_yuan'];
        }
        
        $score = ceil($orderInfo['pay_price']*$score_yuan);
        
        $updateData = array();
        $updateData['score'] = $userScoreInfoTmp['score'] + $score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userScoreInfoTmp['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $orderInfo['user_id'];
        $insertData['score_value']      = $score;
        $insertData['old_value']        = $userScoreInfoTmp['score'];
        $insertData['log_type']         = 7;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);

    }
    
    if($__ShowTcyuyue == 1 && $orderInfo['tcyuyue_log_id'] > 0){
        $tcyuyueLogInfo = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_by_id($orderInfo['tcyuyue_log_id']);
        $tcyuyueInfo = C::t("#tom_tcyuyue#tom_tcyuyue")->fetch_by_id($tcyuyueLogInfo['tcyuyue_id']);
        $updateData = array();
        if($tcyuyueInfo['open_yuyue_queren'] == 1){
            $updateData['yuyue_status']         = 3;
        }else{
            $updateData['yuyue_status']         = 1;
        }
        C::t("#tom_tcyuyue#tom_tcyuyue_log")->update($orderInfo['tcyuyue_log_id'], $updateData);
    }
    
    if($__ShowTcchoujiang == 1 && $goodsInfo['tcchoujiang_id'] > 0){
        $choujiangInfo    = C::t('#tom_tcchoujiang#tom_tcchoujiang')->fetch_by_id($goodsInfo['tcchoujiang_id']);
        if($choujiangInfo['status'] == 1 && $choujiangInfo['shenhe_status'] == 1 && $choujiangInfo['type'] == 3){
            $choujiangBmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($goodsInfo['tcchoujiang_id'],$userInfo['id']);
            if($choujiangBmInfo){
                DB::query("UPDATE ".DB::table('tom_tcchoujiang_bm')." SET cj_times=cj_times+1 WHERE id='".$choujiangBmInfo['id']."' ", 'UNBUFFERED');
            }else{
                $insertData = array();
                $insertData['tcchoujiang_id']          = $goodsInfo['tcchoujiang_id'];
                $insertData['user_id']                 = $userInfo['id'];
                $insertData['xm']                      = $userInfo['nickname'];
                $insertData['tel']                     = $userInfo['tel'];
                $insertData['cj_times']                = 1;
                $insertData['time_key']                = $nowDayTime;
                $insertData['add_time']                = TIMESTAMP;
                C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->insert($insertData);
            }
        }
    }
    
    if($__ShowTchehuoren == 1 && $tcqianggouConfig['open_qianggou_hehuoren'] == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/class/function.hehuoren.php';
        add_hehuoren($orderInfo['user_id'], $orderInfo['tj_hehuoren_id']);
    }
    
    if($orderInfo['balance_status'] == 0){
        if($goodsInfo['goods_balance_type'] == 2 || $goodsInfo['goods_balance_type'] == 3){
            if($goodsInfo['open_duo_shop'] == 1){
                $duo_balance_type = 2;
                include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/module/duo_balance.php';
            }else{
                $hexiaoStatus = 1;
                $goods_balance_rukou = 1;
                include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/module/balance.php';
            }
        }else{
            if($orderInfo['tj_hehuoren_id'] > 0){
                include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/module/yu_balance.php';
            }
        }
    }
    
    if($__ShowPrint == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_print/print.func.php';
        @add_qianggou_print($order_no);
        @qianggou_print($order_no);
    }
    
    if(!empty($tcqianggouConfig['template_neworder']) || !empty($tcqianggouConfig['template_buy'])){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        
        if($goodsInfo['open_duo_shop'] == 1){
            $orderShopUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']); 
            $template_sms = lang('plugin/tom_tcqianggou','template_neworder_duo_first');
        }else{
            $orderTcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($orderInfo['tcshop_id']);
            $orderShopUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderTcshopInfoTmp['user_id']); 
            $template_sms = lang('plugin/tom_tcqianggou','template_neworder_first');
        }
        
        if($access_token && !empty($orderShopUserInfoTmp['openid']) && !empty($tcqianggouConfig['template_neworder']) ){
            $tomSysOffset = getglobal('setting/timeoffset');
            if($goodsInfo['open_duo_shop'] == 1){
                $templateSmsClass = new qgTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$orderInfo['site_id']}&mod=details&goods_id=".$goodsInfo['id']);
            }else{
                $templateSmsClass = new qgTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$orderInfo['site_id']}&mod=personal&act=shop");
            }
            $smsData = array(
                'first'         => lang('plugin/tom_tcqianggou','template_neworder_first'),
                'keyword1'      => $orderInfo['goods_title'],
                'keyword2'      => $orderInfo['pay_price'],
                'keyword3'      => $orderInfo['xm'],
                'keyword4'      => $orderInfo['tel'],
                'keyword5'      => $orderInfo['order_no'],
                'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
            );
            $r = $templateSmsClass->sendSmsNewOrder($orderShopUserInfoTmp['openid'],$tcqianggouConfig['template_neworder'],$smsData);
        }
        
        $orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($orderUserInfoTmp['openid']) && !empty($tcqianggouConfig['template_buy']) ){
            $tomSysOffset = getglobal('setting/timeoffset');
            if($goodsInfo['open_duo_shop'] == 1){
                $templateSmsClass = new qgTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$orderInfo['site_id']}&mod=hexiao_duo&order_no=".$orderInfo['order_no']);
            }else{
                $templateSmsClass = new qgTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$orderInfo['site_id']}&mod=hexiao&order_no=".$orderInfo['order_no']);
            }
            $smsData = array(
                'first'         => lang('plugin/tom_tcqianggou','template_buyorder_first'),
                'keyword1'      => $orderInfo['goods_title'],
                'keyword2'      => $orderInfo['order_no'],
                'keyword3'      => $orderInfo['pay_price'],
                'keyword4'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSmsBuy($orderUserInfoTmp['openid'],$tcqianggouConfig['template_buy'],$smsData);
        }
    }
    
    if($__ShowTcyuyue == 1 && $orderInfo['tcyuyue_log_id'] > 0){
        if(!empty($tongchengConfig['template_id'])){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcyuyueLogInfo['user_id']);
            
            if($tcyuyueInfo['open_yuyue_queren'] == 1){
                $template_sms = str_replace("{NAME}",$userInfo['nickname'], lang('plugin/tom_tcyuyue','shenhe_yuyue_queren_template'));
            }else{
                $template_sms = str_replace("{NAME}",$userInfo['nickname'], lang('plugin/tom_tcyuyue','shenhe_yuyue_template'));
            }
            $template_sms = str_replace("{TITLE}",$tcyuyueInfo['title'], $template_sms);

            $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcyuyueInfo['user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($toUser['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyueInfo['id']}");
                $smsData = array(
                    'first'         => $template_sms,
                    'keyword1'      => $tcqianggouConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
            }
            if($tcyuyueInfo['tongzhi_clerk_id'] > 0){
                $shopClerkInfoTmp = C::t("#tom_tcshop#tom_tcshop_clerk")->fetch_all_list(" AND tcshop_id = {$tcyuyueInfo['tcshop_id']} AND id = {$tcyuyueInfo['tongzhi_clerk_id']} ", 'ORDER BY id DESC', 0, 1);
                if(is_array($shopClerkInfoTmp) && !empty($shopClerkInfoTmp[0])){
                    $shopClerkUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($shopClerkInfoTmp[0]['user_id']);
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($shopClerkUserInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyueInfo['id']}");
                        $smsData = array(
                            'first'         => $template_sms,
                            'keyword1'      => $tcqianggouConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );
                        @$r = $templateSmsClass->sendSms01($shopClerkUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                    }
                }
            }
            if($tcyuyueLogInfo['clerk_id'] > 0){
                $clerkInfo = C::t("#tom_tcyuyue#tom_tcyuyue_clerk")->fetch_by_id($tcyuyueLogInfo['clerk_id']);
                if(is_array($clerkInfo) && !empty($clerkInfo)){
                    $clerkUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($clerkInfo['user_id']);
                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($clerkUserInfo['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcyuyue&site={$site_id}&mod=myyuyue&tcyuyue_id={$tcyuyueInfo['id']}");
                        $smsData = array(
                            'first'         => $template_sms,
                            'keyword1'      => $tcqianggouConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );

                        @$r = $templateSmsClass->sendSms01($clerkUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                    }
                }
            }
            
        }
    }
}