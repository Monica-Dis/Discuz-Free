<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcqianggou'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcqianggou&pmod=admin'; 
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcqianggou&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcqianggou&pmod=admin';

$tomSysOffset = getglobal('setting/timeoffset');

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/config/config.utf8.php';
}

include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/class/function.admin.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/class/function.core.php';
$tcqianggouConfig = get_tcqianggou_config($pluginid);
$Lang = formatLang($Lang);

$tcyikatongPlugin = C::t('#tom_tcshop#common_plugin')->fetch_by_identifier('tom_tcyikatong');
$tcyikatongConfig = get_plugin_config($tcyikatongPlugin['pluginid']);

$tongchengPlugin = C::t('#tom_tcshop#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);

if($_GET['tmod'] == 'goods'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/goods.php';
}else if($_GET['tmod'] == 'option'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/option.php';
}else if($_GET['tmod'] == 'goods_shop'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/goods_shop.php';
}else if($_GET['tmod'] == 'code'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/code.php';
}else if($_GET['tmod'] == 'order'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/order.php';
}else if($_GET['tmod'] == 'cate'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/cate.php';
}else if($_GET['tmod'] == 'focuspic'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/focuspic.php';
}else if($_GET['tmod'] == 'popup'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/popup.php';
}else if($_GET['tmod'] == 'recom_cate'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/recom_cate.php';
}else if($_GET['tmod'] == 'goods_tz'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/goods_tz.php';
}else if($_GET['tmod'] == 'group_qrcode'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/group_qrcode.php';
}else if($_GET['tmod'] == 'trade'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/trade.php';
}else if($_GET['tmod'] == 'addon'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/addon.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/admin/goods.php';
}