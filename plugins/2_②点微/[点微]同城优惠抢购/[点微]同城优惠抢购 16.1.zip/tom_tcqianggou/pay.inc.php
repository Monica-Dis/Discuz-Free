<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/class/function.core.php';

## tcyikatong start
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
    $tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $__ShowTcyikatong = 1;
    }
}
## tcyikatong end

if($_GET['act'] == "pay_qiang" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $goods_id           = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $option_id          = isset($_GET['option_id'])? intval($_GET['option_id']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $goods_num          = intval($_GET['goods_num'])>0? intval($_GET['goods_num']):1;
    $xm                 = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $address_id         = isset($_GET['address_id'])? intval($_GET['address_id']):0;
    $order_beizu        = isset($_GET['order_beizu'])? addslashes($_GET['order_beizu']):'';
    $tj_hehuoren_id     = isset($_GET['tj_hehuoren_id'])? intval($_GET['tj_hehuoren_id']):0;
    $user_open_dikou    = isset($_GET['user_open_dikou'])? intval($_GET['user_open_dikou']):0;
    $tcyuyue_log_id     = isset($_GET['tcyuyue_log_id'])? intval($_GET['tcyuyue_log_id']):0;
    
    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $goodsInfo  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
    
    $addressInfo = array('xm'=>'','tel'=>'','area_str'=>'','info'=>'');
    if($address_id > 0){
        $addressInfo = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
    }
    
    if(empty($userInfo) || empty($goodsInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['open_duo_shop'] == 0){
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
        if(empty($tcshopInfo)){
            $outArr = array(
                'status'=> 500,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['min_num'] > 0){
        if($goods_num < $goodsInfo['min_num']){
            $goods_num = $goodsInfo['min_num'];
        }
    }
    if($goodsInfo['open_duo_shop'] == 1){
        $goods_num = 1;
    }
    
    $buy_price      = $goodsInfo['buy_price'];
    $vip_price      = $goodsInfo['vip_price'];
    $before_price   = $goodsInfo['before_price'];
    $stock_num      = $goodsInfo['stock_num'];
    $sale_num       = $goodsInfo['sale_num'];
    if($goodsInfo['hasoption'] == 1){
        $optionInfo  = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($option_id);
        if(is_array($optionInfo) && !empty($optionInfo)){
            $buy_price      = $optionInfo['buy_price'];
            $vip_price      = $optionInfo['vip_price'];
            $before_price   = $optionInfo['before_price'];
            $stock_num      = $optionInfo['stock_num'];
            $sale_num       = $optionInfo['sale_num'];
        }else{
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($goodsInfo['open_xubuy'] == 1){
        $qiangListCount  = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(" AND goods_id={$goods_id} AND type_id=2 ");
        $goodsInfo['sale_num'] = $goodsInfo['sale_num'] + $qiangListCount;
        if($goodsInfo['hasoption'] == 1){
            $qiangOptionListCount  = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(" AND goods_id={$goods_id} AND type_id=2 AND option_id = {$option_id} ");
            $sale_num = $sale_num + $qiangOptionListCount;
        }else{
            $sale_num = $sale_num + $qiangListCount;
        }
    }
    
    $tcyikatongPayStatus = 0;
    if($__ShowTcyikatong == 1 && $goodsInfo['open_vip'] == 1){
        $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($userInfo['id']);
        if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
            $tcyikatongPayStatus = 1;
        }
    }
    $showBeforeBuyStatus = 0;
    if($goodsInfo['open_before'] == 1 && $before_price > 0 && $goodsInfo['before_num'] > 0  && $goodsInfo['type_id'] == 1){
        $userBeforeOrderInfoTmp = C::t("#tom_tcqianggou#tom_tcqianggou_order")->fetch_all_List(" AND goods_id={$goodsInfo['id']} AND before_pay_status = 1 AND order_status IN(1,2,3) AND user_id = {$userInfo['id']} ",'ORDER BY id DESC', 0, 1);
        if(is_array($userBeforeOrderInfoTmp) && !empty($userBeforeOrderInfoTmp[0])){ }else{
            $before_sale_count = C::t("#tom_tcqianggou#tom_tcqianggou_order")->fetch_all_count(" AND goods_id={$goodsInfo['id']} AND before_pay_status = 1 AND order_status IN(1,2,3) ");
            if($before_sale_count < $goodsInfo['before_num']){
                $tcyikatongPayStatus = 0;
                $showBeforeBuyStatus = 1;
            }
        }
    }
    
    $pay_price = 0;
    if($goodsInfo['type_id'] == 1){
        if($tcqianggouConfig['open_ding_price'] == 1 && $goodsInfo['open_ding_pay'] == 1 ){
            $pay_price = $goodsInfo['ding_price'];
        }else{
            if($tcyikatongPayStatus == 1){
                $pay_price = $vip_price;
            }else if($showBeforeBuyStatus == 1){
                $pay_price = $before_price;
            }else{
                $pay_price = $buy_price;
            }
        }
    }else{
        if($goodsInfo['coupon_is_buy'] == 1){
            if($tcyikatongPayStatus == 1){
                $pay_price = $vip_price;
            }else{
                $pay_price = $goodsInfo['coupon_buy_price'];
            }
        }
    }
    
    if($pay_price <= 0){
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    if($stock_num <= $sale_num){
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    if($goods_num > ($stock_num - $sale_num)){
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['open_code'] == 1){
        $codeCount = C::t('#tom_tcqianggou#tom_tcqianggou_code')->fetch_all_count(" AND goods_id={$goodsInfo['id']} AND code_status=0 AND option_id={$option_id} ");
        if($codeCount < $goods_num){
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($goodsInfo['xiangou_num'] > 0){
        $myHaveOrderCountTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_goods_num(" AND goods_id={$goodsInfo['id']} AND user_id={$userInfo['id']} AND order_status IN(1,2,3) ");
        $goods_xiangou_num_tmp = $goodsInfo['xiangou_num'] - $myHaveOrderCountTmp;
        if($goods_num > $goods_xiangou_num_tmp){
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $score_num = $score_dikou_price = 0;
    if($goodsInfo['open_score_dikou'] == 1 && $user_open_dikou == 1){
        $score_goods_num = 1;
        if($tcqianggouConfig['open_goods_num_dikou_score'] == 1){
            $score_goods_num = $goods_num;
        }

        $score_num = $goodsInfo['score_num'] * $score_goods_num;
        $score_dikou_price = $goodsInfo['score_dikou_price'] * $score_goods_num;
        $one_score_dikou_price = $goodsInfo['score_dikou_price'];
        if($goodsInfo['hasoption'] == 1){
            $score_num = $optionInfo['score_num'] * $score_goods_num;
            $score_dikou_price = $optionInfo['score_dikou_price'] * $score_goods_num;
            $one_score_dikou_price = $optionInfo['score_dikou_price'];
        }
        
        if($score_num <= 0 || $score_dikou_price <= 0){
            $outArr = array(
                'status'=> 308,
            );
            echo json_encode($outArr); exit;
        }

        if($one_score_dikou_price >= $pay_price){
            $outArr = array(
                'status'=> 309,
            );
            echo json_encode($outArr); exit;
        }
        
        if($userInfo['score'] < $score_num){
            $outArr = array(
                'status'=> 310,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    $one_price = $pay_price;
    $pay_price = $pay_price*$goods_num;
    $pay_price = $pay_price - $score_dikou_price;
    
    $auto_id = 0;
    $autoidTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->fetch_all_list(""," ORDER BY id DESC ",0,1);
    if(is_array($autoidTmp) && !empty($autoidTmp) && !empty($autoidTmp[0]['id'])){
        if($autoidTmp[0]['id'] > 999990 && $autoidTmp[0]['id'] < 10101000 ){
            $insertData = array();
            $insertData['id']               = 10101011;
            $insertData['add_time']         = TIMESTAMP;
            if(C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert($insertData)){
                $auto_id = C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert_id();
            }
        }else{
            $insertData = array();
            $insertData['add_time']         = TIMESTAMP;
            if(C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert($insertData)){
                $auto_id = C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert_id();
            }
        }
    }else{
        $insertData = array();
        $insertData['id']               = 101011;
        $insertData['add_time']         = TIMESTAMP;
        if(C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert($insertData)){
            $auto_id = C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert_id();
        }
    }
    
    $hexiao_code = '';
    $auto_id_str = strval($auto_id);
    if($auto_id > 10101000){
        $rand_num1 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[0].$auto_id_str[1].$rand_num1;
        $rand_num2 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[2].$auto_id_str[3].$rand_num2;
        $rand_num3 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[4].$auto_id_str[5].$rand_num3;
        $rand_num4 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[6].$auto_id_str[7].$rand_num4;
    }else{
        $rand_num1 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[0].$auto_id_str[1].$rand_num1;
        $rand_num2 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[2].$auto_id_str[3].$rand_num2;
        $rand_num3 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[4].$auto_id_str[5].$rand_num3;
    }
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    if($goodsInfo['open_duo_shop'] == 0){
        $insertData['tcshop_id']        = $tcshopInfo['id'];
    }
    $insertData['order_no']         = $order_no;
    $insertData['hexiao_code']      = $hexiao_code;
    $insertData['type_id']          = $goodsInfo['type_id'];
    $insertData['goods_id']         = $goodsInfo['id'];
    $insertData['goods_title']      = $goodsInfo['title'];
    if($goodsInfo['hasoption'] == 1){
        $insertData['option_id']        = $option_id;
        $insertData['option_name']      = $optionInfo['name'];
    }
    $insertData['goods_num']        = $goods_num;
    $insertData['one_price']        = $one_price;
    $insertData['score_num']        = $score_num;
    $insertData['score_dikou_price']= $score_dikou_price;
    $insertData['user_id']          = $user_id;
    $insertData['tcyuyue_log_id']   = $tcyuyue_log_id;
    if($address_id > 0 && $goodsInfo['peisong_type'] == 3){
        $insertData['address_id']   = $address_id;
    }
    if($goodsInfo['peisong_type'] == 2 || $goodsInfo['peisong_type'] == 3){
        $insertData['xm']               = $addressInfo['xm'];
        $insertData['tel']              = $addressInfo['tel'];
        $insertData['address']          = $addressInfo['area_str']." ".$addressInfo['info'];
    }else{
        $insertData['xm']               = $xm;
        $insertData['tel']              = $tel;
        $insertData['address']          = '';
    }
    $insertData['order_beizu']      = $order_beizu;
    $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
    $insertData['openid']           = $userInfo['openid'];
    $insertData['pay_price']        = $pay_price;
    if($tcyikatongPayStatus == 1){
        $insertData['vip_pay_status'] = 1;
    }
    if($showBeforeBuyStatus == 1){
        $insertData['before_pay_status'] = 1;
    }
    if($goodsInfo['open_code'] == 1){
        $insertData['code_order'] = 1;
    }
    $insertData['peisong_type']     = $goodsInfo['peisong_type'];
    $insertData['peisong_status']   = 0;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcqianggou#tom_tcqianggou_order')->insert($insertData)){
        $orderId = C::t('#tom_tcqianggou#tom_tcqianggou_order')->insert_id();
        
        DB::query("UPDATE ".DB::table('tom_tcqianggou_goods')." SET sale_num=sale_num+{$goods_num} WHERE id='{$goodsInfo['id']}' ", 'UNBUFFERED');
        if($goodsInfo['hasoption'] == 1){
            DB::query("UPDATE ".DB::table('tom_tcqianggou_goods_option')." SET sale_num=sale_num+{$goods_num} WHERE id='{$option_id}' ", 'UNBUFFERED');
        }
        
        
        if($goodsInfo['open_code'] == 1){
            DB::query("UPDATE ".DB::table('tom_tcqianggou_code')." SET order_id={$orderId},order_no='{$order_no}',user_id={$user_id},code_status=1 WHERE goods_id={$goodsInfo['id']} AND option_id={$option_id} AND code_status=0  LIMIT {$goods_num} ", 'UNBUFFERED');
        }
        
        if($goodsInfo['type_id'] == 1){
            $goods_url = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=details&goods_id='.$goodsInfo['id'];
            $back_url = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=mylist&type=1";
        }else{
            $goods_url = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=coupon&goods_id='.$goodsInfo['id'];
            $back_url = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=mylist&type=2";
        }
        
        if($tcyuyue_log_id > 0){
            $updateData = array();
            $updateData['order_no']     = $order_no;
            $updateData['xm']           = $xm;
            $updateData['tel']          = $tel;
            $updateData['beizu']        = $order_beizu;
            C::t("#tom_tcyuyue#tom_tcyuyue_log")->update($tcyuyue_log_id, $updateData);
        }
        
        $insertData = array();
        $insertData['plugin_id']       = 'tom_tcqianggou';          
        $insertData['order_no']        = $order_no;                 
        $insertData['goods_id']        = $goodsInfo['id'];         
        $insertData['goods_name']      = $goodsInfo['title'];      
        $insertData['goods_beizu']     = $goodsInfo['title'];      
        $insertData['goods_url']       = $goods_url;               
        $insertData['succ_back_url']   = $back_url; 
        $insertData['fail_back_url']   = $back_url;  
        $insertData['allow_alipay']    = 1;             
        $insertData['pay_price']       = $pay_price;    
        $insertData['order_status']    = 1;             
        $insertData['add_time']        = TIMESTAMP;     
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'    => 200,
                'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($_GET['act'] == "pay_ling" && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id                = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $goods_id               = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $option_id              = isset($_GET['option_id'])? intval($_GET['option_id']):0;
    $tcshop_id              = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $xm                     = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                    = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $address_id             = isset($_GET['address_id'])? intval($_GET['address_id']):0;
    $order_beizu            = isset($_GET['order_beizu'])? addslashes($_GET['order_beizu']):'';
    $tj_hehuoren_id         = isset($_GET['tj_hehuoren_id'])? intval($_GET['tj_hehuoren_id']):0;
    
    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $goodsInfo  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
    
    $addressInfo = array('xm'=>'','tel'=>'','area_str'=>'','info'=>'');
    if($address_id > 0){
        $addressInfo = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
    }
    
    if(empty($userInfo) || empty($goodsInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['open_duo_shop'] == 0){
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
        if(empty($tcshopInfo)){
            $outArr = array(
                'status'=> 500,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $buy_price      = $goodsInfo['buy_price'];
    $vip_price      = $goodsInfo['vip_price'];
    $before_price   = $goodsInfo['before_price'];
    $stock_num      = $goodsInfo['stock_num'];
    $sale_num       = $goodsInfo['sale_num'];
    if($goodsInfo['hasoption'] == 1){
        $optionInfo  = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($option_id);
        if(is_array($optionInfo) && !empty($optionInfo)){
            $buy_price      = $optionInfo['buy_price'];
            $vip_price      = $optionInfo['vip_price'];
            $before_price   = $optionInfo['before_price'];
            $stock_num      = $optionInfo['stock_num'];
            $sale_num       = $optionInfo['sale_num'];
        }else{
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($stock_num <= $sale_num){
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
    if($goodsInfo['open_code'] == 1){
        $codeCount = C::t('#tom_tcqianggou#tom_tcqianggou_code')->fetch_all_count(" AND goods_id={$goodsInfo['id']} AND code_status=0 AND option_id={$option_id} ");
        if($codeCount < 1){
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if($goodsInfo['xiangou_num'] > 0){
        $myHaveOrderCount  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_goods_num(" AND goods_id={$goodsInfo['id']} AND user_id={$userInfo['id']} AND order_status IN(1,2,3) ");
        if($myHaveOrderCount >= $goodsInfo['xiangou_num']){
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $tcyikatongPayStatus = 0;
    if($__ShowTcyikatong == 1 && $goodsInfo['open_vip'] == 1 && $goodsInfo['type_id'] == 1){
        $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($userInfo['id']);
        if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
            $tcyikatongPayStatus = 1;
        }
    }
    
    $showBeforeBuyStatus = 0;
    if($goodsInfo['open_before'] == 1 && $before_price > 0 && $goodsInfo['before_num'] > 0  && $goodsInfo['type_id'] == 1){
        $userBeforeOrderInfoTmp = C::t("#tom_tcqianggou#tom_tcqianggou_order")->fetch_all_List(" AND goods_id={$goodsInfo['id']} AND before_pay_status = 1 AND order_status IN(1,2,3) AND user_id = {$userInfo['id']} ",'ORDER BY id DESC', 0, 1);
        if(is_array($userBeforeOrderInfoTmp) && !empty($userBeforeOrderInfoTmp[0])){ }else{
            $before_sale_count = C::t("#tom_tcqianggou#tom_tcqianggou_order")->fetch_all_count(" AND goods_id={$goodsInfo['id']} AND before_pay_status = 1 AND order_status IN(1,2,3) ");
            if($before_sale_count < $goodsInfo['before_num']){
                $tcyikatongPayStatus = 0;
                $showBeforeBuyStatus = 1;
            }
        }
    }
    
    $pay_price = 0;
    if($goodsInfo['type_id'] == 1){
        if($tcqianggouConfig['open_ding_price'] == 1 && $goodsInfo['open_ding_pay'] == 1){
            $pay_price = $goodsInfo['ding_price'];
        }else{
            if($tcyikatongPayStatus == 1){
                $pay_price = $vip_price;
            }else if($showBeforeBuyStatus == 1){
                $pay_price = $before_price;
            }else{
                $pay_price = $buy_price;
            }
        }
    }else{
        if($goodsInfo['coupon_is_buy'] == 1){
            if($tcyikatongPayStatus == 1){
                $pay_price = $vip_price;
            }else{
                $pay_price = $goodsInfo['coupon_buy_price'];
            }
        }
    }
    
    if($pay_price > 0){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    $auto_id = 0;
    $autoidTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->fetch_all_list(""," ORDER BY id DESC ",0,1);
    if(is_array($autoidTmp) && !empty($autoidTmp) && !empty($autoidTmp[0]['id'])){
        if($autoidTmp[0]['id'] > 999990 && $autoidTmp[0]['id'] < 10101000 ){
            $insertData = array();
            $insertData['id']               = 10101011;
            $insertData['add_time']         = TIMESTAMP;
            if(C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert($insertData)){
                $auto_id = C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert_id();
            }
        }else{
            $insertData = array();
            $insertData['add_time']         = TIMESTAMP;
            if(C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert($insertData)){
                $auto_id = C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert_id();
            }
        }
    }else{
        $insertData = array();
        $insertData['id']               = 101011;
        $insertData['add_time']         = TIMESTAMP;
        if(C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert($insertData)){
            $auto_id = C::t('#tom_tcqianggou#tom_tcqianggou_autoid')->insert_id();
        }
    }
    
    $hexiao_code = '';
    $auto_id_str = strval($auto_id);
    if($auto_id > 10101000){
        $rand_num1 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[0].$auto_id_str[1].$rand_num1;
        $rand_num2 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[2].$auto_id_str[3].$rand_num2;
        $rand_num3 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[4].$auto_id_str[5].$rand_num3;
        $rand_num4 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[6].$auto_id_str[7].$rand_num4;
    }else{
        $rand_num1 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[0].$auto_id_str[1].$rand_num1;
        $rand_num2 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[2].$auto_id_str[3].$rand_num2;
        $rand_num3 = mt_rand(1, 9);
        $hexiao_code.= $auto_id_str[4].$auto_id_str[5].$rand_num3;
    }
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    if($goodsInfo['open_duo_shop'] == 0){
        $insertData['tcshop_id']        = $tcshopInfo['id'];
    }
    $insertData['order_no']         = $order_no;
    $insertData['hexiao_code']      = $hexiao_code;
    $insertData['type_id']          = $goodsInfo['type_id'];
    $insertData['goods_id']         = $goodsInfo['id'];
    $insertData['goods_title']      = $goodsInfo['title'];
    if($goodsInfo['hasoption'] == 1){
        $insertData['option_id']        = $option_id;
        $insertData['option_name']      = $optionInfo['name'];
    }
    $insertData['goods_num']        = 1;
    $insertData['user_id']          = $user_id;
    if($address_id > 0 && $goodsInfo['peisong_type'] == 3){
        $insertData['address_id']   = $address_id;
    }
    if($goodsInfo['peisong_type'] == 2 || $goodsInfo['peisong_type'] == 3){
        $insertData['xm']               = $addressInfo['xm'];
        $insertData['tel']              = $addressInfo['tel'];
        $insertData['address']          = $addressInfo['area_str']." ".$addressInfo['info'];
    }else{
        $insertData['xm']               = $xm;
        $insertData['tel']              = $tel;
        $insertData['address']          = '';
    }
    $insertData['order_beizu']      = $order_beizu;
    $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
    $insertData['openid']           = $userInfo['openid'];
    $insertData['pay_price']        = 0;
    if($tcyikatongPayStatus == 1){
        $insertData['vip_pay_status'] = 1;
    }
    if($goodsInfo['open_code'] == 1){
        $insertData['code_order'] = 1;
    }
    $insertData['peisong_type']     = $goodsInfo['peisong_type'];
    $insertData['peisong_status']   = 0;
    $insertData['order_status']     = 2;
    $insertData['pay_time']         = TIMESTAMP;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcqianggou#tom_tcqianggou_order')->insert($insertData)){
        $orderId = C::t('#tom_tcqianggou#tom_tcqianggou_order')->insert_id();
        
        DB::query("UPDATE ".DB::table('tom_tcqianggou_goods')." SET sale_num=sale_num+1 WHERE id='{$goodsInfo['id']}' ", 'UNBUFFERED');
        if($goodsInfo['hasoption'] == 1){
            DB::query("UPDATE ".DB::table('tom_tcqianggou_goods_option')." SET sale_num=sale_num+1 WHERE id='{$option_id}' ", 'UNBUFFERED');
        }
        
        if($goodsInfo['open_code'] == 1){
            DB::query("UPDATE ".DB::table('tom_tcqianggou_code')." SET order_id={$orderId},order_no='{$order_no}',user_id={$user_id},code_status=2 WHERE goods_id={$goodsInfo['id']} AND option_id={$option_id} AND code_status=0  LIMIT 1 ", 'UNBUFFERED');
        }
        
        if($goodsInfo['type_id'] == 1){
            $jump_url = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=mylist&type=1";
        }else{
            $jump_url = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=mylist&type=2";
        }
        
        if(!empty($tcqianggouConfig['template_neworder']) || !empty($tcqianggouConfig['template_buy'])){
            include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();
            
            if($goodsInfo['peisong_type'] == 2 || $goodsInfo['peisong_type'] == 3){
                $xm     = $addressInfo['xm'];
                $tel    = $addressInfo['tel'];
            }
            if($goodsInfo['open_duo_shop'] == 1){
                $shopUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']); 
                $template_sms = lang('plugin/tom_tcqianggou','template_neworder_duo_first');
            }else{
                $shopUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfo['user_id']); 
                $template_sms = lang('plugin/tom_tcqianggou','template_neworder_first');
            }
            if($access_token && !empty($shopUserInfoTmp['openid']) && !empty($tcqianggouConfig['template_neworder']) ){
                $tomSysOffset = getglobal('setting/timeoffset');
                if($goodsInfo['open_duo_shop'] == 1){
                    $templateSmsClass = new qgTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=details&goods_id=".$goodsInfo['id']);
                }else{
                    $templateSmsClass = new qgTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=personal&act=shop");
                }
                $smsData = array(
                    'first'         => $template_sms,
                    'keyword1'      => $goodsInfo['title'],
                    'keyword2'      => 0,
                    'keyword3'      => $xm,
                    'keyword4'      => $tel,
                    'keyword5'      => $order_no,
                    'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
                );
                $r = $templateSmsClass->sendSmsNewOrder($shopUserInfoTmp['openid'],$tcqianggouConfig['template_neworder'],$smsData);
            }

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid']) && !empty($tcqianggouConfig['template_neworder']) ){
                $tomSysOffset = getglobal('setting/timeoffset');
                if($goodsInfo['open_duo_shop'] == 1){
                    $templateSmsClass = new qgTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=hexiao_duo&order_no=".$order_no);
                }else{
                    $templateSmsClass = new qgTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=hexiao&order_no=".$order_no);
                }
                $smsData = array(
                    'first'         => lang('plugin/tom_tcqianggou','template_buyorder_first'),
                    'keyword1'      => $goodsInfo['title'],
                    'keyword2'      => $order_no,
                    'keyword3'      => 0,
                    'keyword4'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSmsBuy($userInfo['openid'],$tcqianggouConfig['template_buy'],$smsData);
            }
        }
        
        $outArr = array(
            'status'    => 200,
            'jump_url'  => $jump_url,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($_GET['act'] == "cancelpay" && $_GET['formhash'] == FORMHASH){
    
    $order_no  = isset($_GET['order_no'])? addslashes($_GET['order_no']):'';

    $orderInfo = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_by_order_no($order_no);
    
    if($orderInfo && $orderInfo['order_status'] == 1){
        
        DB::query("UPDATE ".DB::table('tom_tcqianggou_goods')." SET sale_num=sale_num-{$orderInfo['goods_num']} WHERE id='{$orderInfo['goods_id']}' ", 'UNBUFFERED');
        DB::query("UPDATE ".DB::table('tom_tcqianggou_order')." SET order_status=4 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
        if($orderInfo['option_id'] > 0){
            DB::query("UPDATE ".DB::table('tom_tcqianggou_goods_option')." SET sale_num=sale_num-{$orderInfo['goods_num']} WHERE id='{$orderInfo['option_id']}' ", 'UNBUFFERED');
        }
        if($orderInfo['code_order'] == 1){
            DB::query("UPDATE ".DB::table('tom_tcqianggou_code')." SET order_id=0,order_no='',user_id=0,code_status=0 WHERE goods_id={$orderInfo['goods_id']} AND order_id={$orderInfo['id']} ", 'UNBUFFERED');
        }
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}