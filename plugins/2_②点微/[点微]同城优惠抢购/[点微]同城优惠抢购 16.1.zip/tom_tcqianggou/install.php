<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcqianggou_autoid`;
CREATE TABLE `pre_tom_tcqianggou_autoid` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcqianggou_cate`;
CREATE TABLE `pre_tom_tcqianggou_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `picurl_hover` varchar(255) DEFAULT NULL,
  `csort` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcqianggou_focuspic`;
CREATE TABLE `pre_tom_tcqianggou_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '1',
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcqianggou_goods`;
CREATE TABLE `pre_tom_tcqianggou_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `trade_id` int(11) DEFAULT '0',
  `cate_id` int(11) DEFAULT '0',
  `type_id` int(11) DEFAULT '0',
  `tcchoujiang_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `yongjin_type` tinyint(4) DEFAULT '1',
  `yongjin_bili` decimal(10,2) DEFAULT '0.00',
  `picurl` varchar(255) DEFAULT NULL,
  `toppic` varchar(255) DEFAULT NULL,
  `tabs` varchar(255) DEFAULT NULL,
  `admin_edit` int(11) DEFAULT '0',
  `xuzhi` mediumtext,
  `content` mediumtext,
  `open_xubuy` int(11) DEFAULT '0',
  `market_price` decimal(10,2) DEFAULT '0.00',
  `buy_price` decimal(10,2) DEFAULT '0.00',
  `open_ding_pay` int(11) DEFAULT '0',
  `ding_price` decimal(10,2) DEFAULT '0.00',
  `open_vip` int(11) DEFAULT '0',
  `vip_price` decimal(10,2) DEFAULT '0.00',
  `open_before` int(11) DEFAULT '0',
  `before_price` decimal(10,2) DEFAULT '0.00',
  `before_num` int(11) DEFAULT '0',
  `coupon_price` int(11) DEFAULT '0',
  `coupon_limit` int(11) DEFAULT '0',
  `coupon_zhekou` decimal(10,1) DEFAULT '0.0',
  `coupon_is_buy` int(11) DEFAULT '0',
  `coupon_buy_price` decimal(10,2) DEFAULT '0.00',
  `coupon_msg` varchar(255) DEFAULT NULL,
  `open_yuyue` int(11) DEFAULT '0',
  `tcyuyue_id` int(11) DEFAULT '0',
  `yuyue_type` tinyint(4) DEFAULT '1',
  `yuyue_xm` varchar(255) DEFAULT NULL,
  `yuyue_tel` varchar(255) DEFAULT NULL,
  `stock_num` int(11) DEFAULT '0',
  `sale_num` int(11) DEFAULT '0',
  `xiangou_num` int(11) DEFAULT '0',
  `min_num` int(11) DEFAULT '0',
  `start_time` int(11) DEFAULT '0',
  `end_time` int(11) DEFAULT '0',
  `haibao_type` int(11) DEFAULT '1',
  `haibao_picurl` varchar(255) DEFAULT NULL,
  `haibao_msg` varchar(255) DEFAULT NULL,
  `haibao_text_color` varchar(255) DEFAULT NULL,
  `qrcode_location` int(11) DEFAULT '0',
  `hexiao_start_time` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `open_hexiao_valid` tinyint(4) DEFAULT '0',
  `hexiao_valid_days` int(11) DEFAULT '0',
  `hexiao_pwd` varchar(255) DEFAULT NULL,
  `hehuoren_tg_open` int(11) DEFAULT '2',
  `hehuoren_tg_haibao` varchar(255) DEFAULT NULL,
  `chuji_fc_scale` decimal(10,2) DEFAULT '0.00',
  `zhongji_fc_scale` decimal(10,2) DEFAULT '0.00',
  `gaoji_fc_scale` decimal(10,2) DEFAULT '0.00',
  `chuji_fc_scale2` decimal(10,2) DEFAULT '0.00',
  `zhongji_fc_scale2` decimal(10,2) DEFAULT '0.00',
  `gaoji_fc_scale2` decimal(10,2) DEFAULT '0.00',
  `clicks` int(11) DEFAULT '0',
  `virtual_clicks` int(11) DEFAULT '0',
  `peisong_type` int(11) DEFAULT '1',
  `share_title` varchar(255) DEFAULT NULL,
  `share_desc` varchar(255) DEFAULT NULL,
  `allow_refund` int(11) DEFAULT '0',
  `open_code` tinyint(4) DEFAULT '0',
  `code_help_msg` text,
  `mp3_link` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `qiang_status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `hasoption` tinyint(4) DEFAULT '0',
  `show_market_price` decimal(10,2) DEFAULT '0.00',
  `show_before_price` decimal(10,2) DEFAULT '0.00',
  `show_buy_price` decimal(10,2) DEFAULT '0.00',
  `show_vip_price` decimal(10,2) DEFAULT '0.00',
  `open_duo_shop` tinyint(4) DEFAULT '0',
  `duo_hexiao_num` int(11) DEFAULT '0',
  `duo_shop_jiesuan` tinyint(4) DEFAULT '0',
  `goods_balance_type` tinyint(4) DEFAULT '1',
  `open_shop_yongjin` tinyint(4) DEFAULT '0',
  `shop_yongjin` decimal(10,2) DEFAULT '0.00',
  `qianggou_ids` varchar(255) DEFAULT NULL,
  `recom_cate_id` int(11) DEFAULT '0',
  `zhibo_roomid` int(11) DEFAULT '0',
  `open_score_dikou` tinyint(4) DEFAULT '0',
  `score_num` int(11) DEFAULT '0',
  `score_dikou_price` decimal(10,2) DEFAULT '0.00',
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '1000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcqianggou_goods_photo`;
CREATE TABLE `pre_tom_tcqianggou_goods_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `oss_picurl` varchar(255) DEFAULT NULL,
  `oss_status` tinyint(4) DEFAULT '0',
  `qiniu_picurl` varchar(255) DEFAULT NULL,
  `qiniu_status` tinyint(4) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcqianggou_goods_shop`;
CREATE TABLE `pre_tom_tcqianggou_goods_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `market_price` decimal(10,2) DEFAULT '0.00',
  `stock_num` int(11) DEFAULT '0',
  `sale_num` int(11) DEFAULT '0',
  `xian_use_num` int(11) DEFAULT '0',
  `one_jiesuan_price` decimal(10,2) DEFAULT '0.00',
  `hexiao_pwd` varchar(255) DEFAULT NULL,
  `content` text,
  `ssort` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcqianggou_order`;
CREATE TABLE `pre_tom_tcqianggou_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `site_id` int(11) DEFAULT '1',
  `tcshop_id` int(11) DEFAULT '0',
  `order_no` varchar(255) DEFAULT NULL,
  `hexiao_code` varchar(255) DEFAULT NULL,
  `type_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `goods_title` varchar(255) DEFAULT NULL,
  `goods_num` int(11) DEFAULT '0',
  `one_price` decimal(10,2) DEFAULT '0.00',
  `option_id` int(11) DEFAULT '0',
  `option_name` varchar(255) DEFAULT NULL,
  `score_num` int(11) DEFAULT '0',
  `score_dikou_price` decimal(10,2) DEFAULT '0.00',
  `user_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `address_id` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `order_beizu` varchar(255) DEFAULT NULL,
  `openid` varchar(255) DEFAULT NULL,
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `vip_pay_status` int(11) DEFAULT '0',
  `before_pay_status` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `pay_time` int(11) DEFAULT '0',
  `peisong_type` int(11) DEFAULT '1',
  `peisong_status` int(11) DEFAULT '0',
  `peisong_info` varchar(255) DEFAULT NULL,
  `peisong_time` int(11) DEFAULT '0',
  `order_status` int(11) DEFAULT '0',
  `balance_status` int(11) DEFAULT '0',
  `refund_type` int(11) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `kuaidi_type` varchar(255) DEFAULT NULL,
  `kuaidi_no` varchar(255) DEFAULT NULL,
  `use_num` int(11) DEFAULT '0',
  `code_order` tinyint(4) DEFAULT '0',
  `shenqing_refund` tinyint(4) DEFAULT '0',
  `shenqing_refund_msg` varchar(255) DEFAULT NULL,
  `tcyuyue_log_id` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_hexiao_code` (`hexiao_code`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcqianggou_stock_log`;
CREATE TABLE `pre_tom_tcqianggou_stock_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `is_admin` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '1',
  `change_num` int(11) DEFAULT '0',
  `change_time` int(11) DEFAULT '0',
  `is_option` tinyint(4) DEFAULT '0',
  `beizu` text,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqianggou_xubuy`;
CREATE TABLE `pre_tom_tcqianggou_xubuy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) DEFAULT '0',
  `order_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `option_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `goods_num` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqianggou_goods_option`;
CREATE TABLE `pre_tom_tcqianggou_goods_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `market_price` decimal(10,2) DEFAULT '0.00',
  `buy_price` decimal(10,2) DEFAULT '0.00',
  `vip_price` decimal(10,2) DEFAULT '0.00',
  `before_price` decimal(10,2) DEFAULT '0.00',
  `shop_yongjin` decimal(10,2) DEFAULT '0.00',
  `stock_num` int(11) DEFAULT '0',
  `sale_num` int(11) DEFAULT '0',
  `score_num` int(11) DEFAULT '0',
  `score_dikou_price` decimal(10,2) DEFAULT '0.00',
  `osort` int(11) DEFAULT '10',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqianggou_order_use_log`;
CREATE TABLE `pre_tom_tcqianggou_order_use_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `goods_shop_id` int(11) DEFAULT '0',
  `use_num` int(11) DEFAULT NULL,
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqianggou_code`;
CREATE TABLE `pre_tom_tcqianggou_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `option_id` int(11) DEFAULT '0',
  `order_id` int(11) DEFAULT '0',
  `order_no` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `code_value` varchar(255) DEFAULT NULL,
  `code_status` tinyint(4) DEFAULT '0',
  `use_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqianggou_recom_cate`;
CREATE TABLE `pre_tom_tcqianggou_recom_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '0',
  `template_type` tinyint(4) DEFAULT '1',
  `toppic` varchar(255) DEFAULT NULL,
  `index_show_num` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `csort` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqianggou_goods_tz`;
CREATE TABLE `pre_tom_tcqianggou_goods_tz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `order_no` varchar(255) DEFAULT NULL,
  `tz_status` tinyint(4) DEFAULT '1',
  `tz_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqianggou_group_qrcode`;
CREATE TABLE `pre_tom_tcqianggou_group_qrcode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `qrcode` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `tishi_msg` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqianggou_popup`;
CREATE TABLE `pre_tom_tcqianggou_popup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_ids` text,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `clicks` int(11) DEFAULT '0',
  `show_num` int(11) unsigned DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqianggou_popup_log`;
CREATE TABLE `pre_tom_tcqianggou_popup_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `popup_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `num` int(11) DEFAULT '0',
  `log_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqianggou_trade`;
CREATE TABLE `pre_tom_tcqianggou_trade` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `is_recommend` tinyint(4) DEFAULT '0',
  `tsort` int(11) DEFAULT '100',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqianggou_goods_clicks`;
CREATE TABLE `pre_tom_tcqianggou_goods_clicks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `clicks_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$finish = TRUE;