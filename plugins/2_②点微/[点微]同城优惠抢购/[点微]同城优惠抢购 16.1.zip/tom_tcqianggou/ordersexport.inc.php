<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/config/config.utf8.php';
}

$tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
$tomSysOffset = getglobal('setting/timeoffset');

$site_id  = isset($_GET['site_id'])? intval($_GET['site_id']):0;
$user_id  = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$goods_id  = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
$hexiao_user_id = isset($_GET['hexiao_user_id'])? intval($_GET['hexiao_user_id']):0;
$tel = !empty($_GET['tel'])? trim(addslashes($_GET['tel'])):'';
$hexiao_code = !empty($_GET['hexiao_code'])? trim(addslashes($_GET['hexiao_code'])):'';
$order_status  = isset($_GET['order_status'])? intval($_GET['order_status']):0;
$start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
$end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
$from           = isset($_GET['from'])? addslashes($_GET['from']):'';
$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$goodsInfo = C::t("#tom_tcqianggou#tom_tcqianggou_goods")->fetch_by_id($goods_id);

$daoQuanXianStatus = 0;
if($from == 'myfabu'){
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';
    
    if($__UserInfo['id'] > 0 && $goodsInfo['user_id'] == $__UserInfo['id']){
        $daoQuanXianStatus = 1;
    }
    
}else{
    if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
        $daoQuanXianStatus = 1;
    }
}

$pagesize = 5000;
$start = ($page-1)*$pagesize;

if($daoQuanXianStatus == 1){
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    if(!empty($goods_id)){
        $where.= " AND goods_id={$goods_id} ";
    }
    if(!empty($hexiao_user_id)){
        $where.=" AND hexiao_user_id={$hexiao_user_id} ";
    }
    if(!empty($tel)){
        $where.= " AND tel='{$tel}' ";
    }
    if(!empty($hexiao_code)){
        $where.= " AND hexiao_code='{$hexiao_code}' ";
    }
    if(!empty($order_status)){
        $where.= " AND order_status={$order_status} ";
    }
    if(!empty($start_time)){
        $startTime = strtotime($start_time);
        $where.=" AND order_time >=  {$startTime} ";
    }
    if(!empty($end_time)){
        $endTime = strtotime($end_time);
        $where.=" AND order_time < {$endTime} ";
    }
    
    $ordersListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
    $orderList = array();
    foreach ($ordersListTmp as $key => $value) {
        $orderList[$key] = $value;
        
        $orderList[$key]['order_status'] = $orderStatusArray[$value['order_status']];
        if($value['peisong_type'] == 1){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tcqianggou','goods_peisong_type_1');
        }else if($value['peisong_type'] == 2){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tcqianggou','goods_peisong_type_2');
        }else if($value['peisong_type'] == 3){
            $orderList[$key]['peisong_type'] = lang('plugin/tom_tcqianggou','goods_peisong_type_3');
        }else{
            $orderList[$key]['peisong_type'] = '-';
        }
        
        if($value['order_status'] == 3){
            $orderList[$key]['use_num'] = $value['goods_num'];
        }
        
        $orderList[$key]['order_time'] = dgmdate($value['order_time'],"Y-m-d H:i:s",$tomSysOffset);
        if($value['pay_time'] > 0){
            $orderList[$key]['pay_time'] = dgmdate($value['pay_time'],"Y-m-d H:i:s",$tomSysOffset);
        }else{
            $orderList[$key]['pay_time'] = '-';
        }
        if($value['hexiao_time'] > 0){
            $orderList[$key]['hexiao_time'] = dgmdate($value['hexiao_time'],"Y-m-d H:i:s",$tomSysOffset);
        }else{
            $orderList[$key]['hexiao_time'] = '-';
        }
        if($value['vip_pay_status'] == 1){
            $orderList[$key]['vip_pay_status'] = lang('plugin/tom_tcqianggou','order_vip_pay_status_1');
        }else{
            $orderList[$key]['vip_pay_status'] = lang('plugin/tom_tcqianggou','order_vip_pay_status_0');
        }
        
        if($value['hexiao_user_id'] > 0){
            $hexiaoUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['hexiao_user_id']);
            $orderList[$key]['hexiao_user_name'] = $hexiaoUserInfo['nickname'];
        }else{
            $orderList[$key]['hexiao_user_name'] = '-';
        }
        
    }

    $order_no = lang('plugin/tom_tcqianggou','order_order_no');
    $hexiao_code = lang('plugin/tom_tcqianggou','order_hexiao_code');
    $goods_id = lang('plugin/tom_tcqianggou','order_goods_id');
    $goods_title = lang('plugin/tom_tcqianggou','order_goods_title');
    $option_name = lang('plugin/tom_tcqianggou','order_option_name');
    $user_xm = lang('plugin/tom_tcqianggou','order_user_xm');
    $user_tel = lang('plugin/tom_tcqianggou','order_user_tel');
    $user_address = lang('plugin/tom_tcqianggou','order_user_address');
    $pay_price = lang('plugin/tom_tcqianggou','order_pay_price');
    $goods_num = lang('plugin/tom_tcqianggou','order_goods_num');
    $use_num = lang('plugin/tom_tcqianggou','order_use_num');
    $vip_pay_status = lang('plugin/tom_tcqianggou','order_vip_pay_status');
    $order_status = lang('plugin/tom_tcqianggou','order_order_status');
    $order_beizu = lang('plugin/tom_tcqianggou','order_beizu');
    $order_hexiao_user_id = lang('plugin/tom_tcqianggou','order_hexiao_user_id');
    $order_hexiao_user_name = lang('plugin/tom_tcqianggou','order_hexiao_user_name');
    $tj_hehuoren_id = lang('plugin/tom_tcqianggou','order_tj_hehuoren_id');
    $peisong_type = lang('plugin/tom_tcqianggou','goods_peisong_type');
    $order_time = lang('plugin/tom_tcqianggou','order_order_time');
    $pay_time = lang('plugin/tom_tcqianggou','order_pay_time');
    $hexiao_time = lang('plugin/tom_tcqianggou','order_hexiao_time');

    $listData[] = array(
        $order_no,
        $hexiao_code,
        $goods_id,
        $goods_title,
        $option_name,
        $user_xm,
        $user_tel,
        $user_address,
        $pay_price,
        $goods_num,
        $use_num,
        $vip_pay_status,
        $order_status,
        $order_beizu,
        $order_hexiao_user_id,
        $order_hexiao_user_name,
        $tj_hehuoren_id,
        $peisong_type,
        $order_time,
        $pay_time,
        $hexiao_time,
    ); 
    foreach ($orderList as $v){
        $lineData = array();
        $lineData[] = $v['order_no'];
        if($from == 'myfabu'){
            $lineData[] = "'";
        }else{
            $lineData[] = "'".$v['hexiao_code'];
        }
        $lineData[] = $v['goods_id'];
        $lineData[] = $v['goods_title'];
        if(!empty($v['option_name'])){
            $lineData[] = $v['option_name'];
        }else{
            $lineData[] = '-';
        }
        $lineData[] = $v['xm'];
        $lineData[] = "'".$v['tel'];
        $lineData[] = $v['address'];
        $v['address'] = str_replace("\r\n", "", $v['address']);
        $v['address'] = str_replace("\n", "", $v['address']);
        $lineData[] = $v['pay_price'];
        $lineData[] = $v['goods_num'];
        $lineData[] = $v['use_num'];
        $lineData[] = $v['vip_pay_status'];
        $lineData[] = $v['order_status'];
        $lineData[] = "'".$v['order_beizu'];
        $lineData[] = $v['hexiao_user_id'];
        $lineData[] = $v['hexiao_user_name'];
        $lineData[] = $v['tj_hehuoren_id'];
        $lineData[] = $v['peisong_type'];
        $lineData[] = $v['order_time'];
        $lineData[] = $v['pay_time'];
        $lineData[] = $v['hexiao_time'];
        $listData[] = $lineData;
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=exportQianggouOrders.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}