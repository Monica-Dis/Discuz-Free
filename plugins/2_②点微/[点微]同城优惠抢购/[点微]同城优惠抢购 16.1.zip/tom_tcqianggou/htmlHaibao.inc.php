<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(0);
$tcqianggouConfig   = $_G['cache']['plugin']['tom_tcqianggou'];
$tongchengConfig    = $_G['cache']['plugin']['tom_tongcheng'];
$appid              = trim($tongchengConfig['wxpay_appid']);
$appsecret          = trim($tongchengConfig['wxpay_appsecret']);

$__IsMiniprogram = 0;
$cookie_tom_miniprogram = getcookie('tom_miniprogram');
if($cookie_tom_miniprogram == 1){ 
    $__IsMiniprogram = 1;
}

if('utf-8' != CHARSET) {
    if(defined('IN_MOBILE')) {}else{
        foreach($_POST AS $pk => $pv) {
            if(!is_numeric($pv)) {
                $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
            }
        }
    }
}

$share_url          = isset($_GET['share_url'])? daddslashes($_GET['share_url']):'';
$goods_id           = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
$user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
$tj_hehuoren_id     = isset($_GET['tj_hehuoren_id'])? intval($_GET['tj_hehuoren_id']):0;

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
$userInfo  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);

if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
    include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
}else{
    echo 'QR|phpqrcode';exit;
}

$toppic = '';
if(!preg_match('/^http/', $goodsInfo['toppic']) ){
    if(strpos($goodsInfo['toppic'], 'source/plugin/tom_') === FALSE){
        $toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['toppic'];
        if(strpos($toppic, $_G['siteurl']) !== false){
            $toppic = str_replace($_G['siteurl'], "", $toppic);
            $toppic = DISCUZ_ROOT.$toppic;
        }
    }else{
        $toppic = DISCUZ_ROOT.$goodsInfo['toppic'];
    }
}else{
    $toppic = $goodsInfo['toppic'];
}

$haibao_picurl = '';
if(!preg_match('/^http/', $goodsInfo['haibao_picurl']) ){
    if(strpos($goodsInfo['haibao_picurl'], 'source/plugin/tom_') === FALSE){
        $haibao_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['haibao_picurl'];
        if(strpos($haibao_picurl, $_G['siteurl']) !== false){
            $haibao_picurl = str_replace($_G['siteurl'], "", $haibao_picurl);
            $haibao_picurl = DISCUZ_ROOT.$haibao_picurl;
        }
    }else{
        $haibao_picurl = DISCUZ_ROOT.$goodsInfo['haibao_picurl'];
    }
}else{
    $haibao_picurl = $goodsInfo['haibao_picurl'];
}

if(strpos($userInfo['picurl'], 'data/attachment/tomwx') !== false){
    $userpic  = $_G['siteurl'].$userInfo['picurl'];
}else if(strpos($userInfo['picurl'], 'uc_server/') !== false){
    $userpic  = $_G['siteurl'].$userInfo['picurl'];
}else{
    $userpic  = $userInfo['picurl'];
}

$toppicImg = DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/data/haibao/'.md5($toppic).'_toppic.png';
$toppicUrl = 'source/plugin/tom_tcqianggou/data/haibao/'.md5($toppic).'_toppic.png';

$haibaoPicurlImg = DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/data/haibao/'.md5($haibao_picurl).'_haibao_picurl.png';
$haibaoPicurlUrl = 'source/plugin/tom_tcqianggou/data/haibao/'.md5($haibao_picurl).'_haibao_picurl.png';

$qrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/data/haibao/'.md5($share_url).'_qrcode.png';
$qrcodeUrl = 'source/plugin/tom_tcqianggou/data/haibao/'.md5($share_url).'_qrcode.png';

$wxqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/data/haibao/'.md5($share_url).'_wxqrcode'.date("Ymd").'.png';
$wxqrcodeUrl = 'source/plugin/tom_tcqianggou/data/haibao/'.md5($share_url).'_wxqrcode'.date("Ymd").'.png';

$userpicImg = DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/data/haibao/'.md5($userpic).'_userpic.png';
$userpicUrl = 'source/plugin/tom_tcqianggou/data/haibao/'.md5($userpic).'_userpic.png';

$tempDir = "/source/plugin/tom_tcqianggou/data/haibao/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0755); 
}

if(file_exists($toppicImg)){
}else{
    $top_pic_content = file_get_contents($toppic);
    if(false === file_put_contents($toppicImg,$top_pic_content)){
        $toppicImg = $toppic;
    }
}

if(file_exists($haibaoPicurlImg)){
}else if($goodsInfo['haibao_type'] == 2){
    $haibao_picurl_pic_content = file_get_contents($haibao_picurl);
    if(false === file_put_contents($haibaoPicurlImg,$haibao_picurl_pic_content)){
        $haibaoPicurlImg = $haibao_picurl;
    }
}

if(file_exists($userpicImg)){
}else{
    $user_pic_content = file_get_contents($userpic);
    if(false === file_put_contents($userpicImg,$user_pic_content)){
        $userpicImg = $userpic;
    }
}

$outQrcodeUrl = '';
if(($tcqianggouConfig['open_xiaoqrcode'] == 1 || ($tcqianggouConfig['open_xiaoqrcode'] == 2 && $__IsMiniprogram == 1 )) && file_exists(DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/qrcode.func.php')){
    
    include DISCUZ_ROOT.'./source/plugin/tom_xiaofenlei/qrcode.func.php';
    if($goodsInfo['type_id'] == 1){
        $xiaor = xiaoGetwxacodeunlimit("pages/wxacode/qianggou",$goodsInfo['site_id'].'_'.$goods_id.'_'.$tj_hehuoren_id,430);
    }else{
        $xiaor = xiaoGetwxacodeunlimit("pages/wxacode/coupon",$goodsInfo['site_id'].'_'.$goods_id.'_'.$tj_hehuoren_id,430);
    }
    
    if(isset($xiaor['code']) && $xiaor['code'] == 0 && !empty($xiaor['src'])){
        $outQrcodeUrl = $xiaor['src'];
    }else{
        echo 'XIAO|'.$xiaor['code'].'|'.$xiaor['msg'];exit;
    }
    
}else if($tcqianggouConfig['open_wxqrcode'] == 1 && file_exists(DISCUZ_ROOT.'./source/plugin/tom_weixin/tom_weixin.inc.php')){
    
    $qrcodeKey  = md5($share_url);
    $qrcodeInfo = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_by_qkey($qrcodeKey);
    $qrcodeId = 0;
    if($qrcodeInfo){
        $qrcodeId = $qrcodeInfo['id'];
        $updateData = array();
        $updateData['title']  = $goodsInfo['title'];
        $updateData['picurl'] = $_G['siteurl'].$toppicUrl;
        $updateData['desc']   = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        $updateData['link']   = $share_url;
        C::t('#tom_weixin#tom_weixin_qrcode')->update($qrcodeId,$updateData);
    }else{
        
        $qrcodeList = C::t('#tom_weixin#tom_weixin_qrcode')->fetch_all_list(" ","ORDER BY id DESC",0,1);
        $qrcodeId = 100001;
        if(is_array($qrcodeList) && !empty($qrcodeList) && isset($qrcodeList['0']) && $qrcodeList['0']['id']>100000){
            $qrcodeId = $qrcodeList['0']['id']+1;
        }
        
        $insertData = array();
        $insertData['id']       = $qrcodeId;
        $insertData['qkey']     = $qrcodeKey;
        $insertData['title']    = $goodsInfo['title'];
        $insertData['picurl']   = $_G['siteurl'].$toppicUrl;
        $insertData['desc']     = lang('plugin/tom_tongcheng', 'wxqrcode_desc');
        $insertData['link']     = $share_url;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_weixin#tom_weixin_qrcode')->insert($insertData);
        $qrcodeId = C::t('#tom_weixin#tom_weixin_qrcode')->insert_id();
    }
    
    if(file_exists($wxqrcodeImg)){
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        $access_token = $weixinClass->get_access_token();

        $dateStr = '{"expire_seconds": 2592000, "action_name": "QR_SCENE", "action_info": {"scene": {"scene_id": '.$qrcodeId.'}}}';
        $response   = postDataCurl($dateStr, 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token);
        $returnData = json_decode($response,true);
        if(isset($returnData['ticket']) &&  !empty($returnData['ticket'])){
            $wx_pic_content = getHtml('https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.$returnData['ticket']);
            if(false === file_put_contents($wxqrcodeImg,$wx_pic_content)){
            }
        }
    }
    
    $outQrcodeUrl = $wxqrcodeUrl;
}else{
    if(file_exists($qrcodeImg)){
    }else{
        QRcode::png($share_url,$qrcodeImg,'H',5,2);
    }
    $outQrcodeUrl = $qrcodeUrl;
}

echo 'OK|'.$toppicUrl.'|'.$userpicUrl.'|'.$outQrcodeUrl.'|'.$haibaoPicurlUrl;exit;

function wx_iconv_recurrence($value) {
	if(is_array($value)) {
		foreach($value AS $key => $val) {
			$value[$key] = wx_iconv_recurrence($val);
		}
	} else {
		$value = diconv($value, 'utf-8', CHARSET);
	}
	return $value;
}

function getHtml($url){
    if(function_exists('curl_init')){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $return = curl_exec($ch);
        curl_close($ch); 
        return $return;
    }
    return false;
}

function postDataCurl($data, $url){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,FALSE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $return = curl_exec($ch);
    if($return){
        curl_close($ch);
        return $return;
    } else { 
        $error = curl_errno($ch);
        curl_close($ch);
        return false;
    }
}