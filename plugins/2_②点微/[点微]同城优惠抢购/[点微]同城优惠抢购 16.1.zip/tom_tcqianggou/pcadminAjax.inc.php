<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
if($_GET['act'] == 'tcqianggou_trade' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'code'=> 1,
    );

    $tcshop_id  = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
    $site_id    = intval($_GET['site_id'])>0 ? intval($_GET['site_id']):1;
    
    if($tcshop_id > 0){
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
        if(!empty($tcshopInfo) && $tcshopInfo['site_id'] > 0){
            $site_id = $tcshopInfo['site_id'];
        }else{
            $site_id = 0;
        }
    }
    
    $tradeListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_trade')->fetch_all_list(" AND site_id = {$site_id} "," ORDER BY tsort ASC,id DESC ");
    $tradeList = array();
    if(!empty($tradeListTmp)){
        foreach($tradeListTmp as $key => $value){
            $tradeList[$key] = $value;
        }
    }
    
    $list = iconv_to_utf8($tradeList);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'tcqianggou_recom_cate' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );

    $tcshop_id  = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
    $type_id    = intval($_GET['type_id'])>0 ? intval($_GET['type_id']):1;
    $site_id    = intval($_GET['site_id'])>0 ? intval($_GET['site_id']):1;
    
    if($tcshop_id > 0){
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
        if(!empty($tcshopInfo) && $tcshopInfo['site_id'] > 0){
            $site_id = $tcshopInfo['site_id'];
        }
    }
    
    $where = "";
    if($type_id == 1){
        $where .= ' AND type = 1 ';
    }else{
        $where .= ' AND type = 2 ';
    }
    $recomCateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_list($where." AND site_id = {$site_id} "," ORDER BY csort ASC, id DESC ",0,1000);
    if(is_array($recomCateListTmp) && !empty($recomCateListTmp)){ }else{
        $recomCateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_list($where." AND site_id = 1 "," ORDER BY csort ASC, id DESC ",0,1000);
    }
    
    $recomCateList = array();
    if(!empty($recomCateListTmp)){
        foreach($recomCateListTmp as $key => $value){
            $recomCateList[$key] = $value;
        }
    }
    
    $list = iconv_to_utf8($recomCateList);
    
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'load_yuyue' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'code'=> 1,
    );

    $tcshop_id = intval($_GET['tcshop_id'])>0 ? intval($_GET['tcshop_id']):0;
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $tcyuyueList = array();
    if($tcshopInfo){
        $tcyuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list("AND tcshop_id = {$tcshop_id} AND type = 2 AND status = 1 AND shenhe_status = 1 ");
        foreach($tcyuyueListTmp as $key => $value){
            $tcyuyueList[$key] = $value;
        }
    }
    
    $list = iconv_to_utf8($tcyuyueList);
    $outArr = array(
        'code'  => 200,
        'list'  => $list,
    );
    echo json_encode($outArr); exit;
}else{
    echo 'error';exit;
}