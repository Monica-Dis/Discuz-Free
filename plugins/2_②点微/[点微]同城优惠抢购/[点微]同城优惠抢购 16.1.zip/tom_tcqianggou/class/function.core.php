<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


function wx_iconv_recurrence($value) {
    if(is_array($value)) {
        foreach($value AS $key => $val) {
            $value[$key] = wx_iconv_recurrence($val);
        }
    } else {
        $value = diconv($value, 'utf-8', CHARSET);
    }
    return $value;
}

function update_qiang_status($goodsInfo = array()){
    
    $qiang_status = 1;
    
    if($goodsInfo['type_id']==1 && TIMESTAMP < $goodsInfo['start_time']){
        $qiang_status = 2;
    }
    
    if($goodsInfo['type_id']==1 && TIMESTAMP > $goodsInfo['end_time']){
        $qiang_status = 3;
    }

    if($goodsInfo['stock_num'] <= $goodsInfo['sale_num']){
        $qiang_status= 3;
    }
    
    if($goodsInfo['open_code'] == 1){
        $codeCount = C::t('#tom_tcqianggou#tom_tcqianggou_code')->fetch_all_count(" AND goods_id={$goodsInfo['id']} AND code_status=0 ");
        if($codeCount < 1){
            $qiang_status = 3;
        }
    }

    if($goodsInfo['open_hexiao_valid'] == 0){
        if($goodsInfo['hexiao_time'] < TIMESTAMP){
            $qiang_status = 3;
        }
    }
    
    if($qiang_status != $goodsInfo['qiang_status']){
        $updateData  = array();
        $updateData['qiang_status']  = $qiang_status;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($goodsInfo['id'],$updateData);
    }
    
    return $qiang_status;
} 

/**
 * ���������������֮��ľ���
 * @param  Decimal $longitude1 ��㾭��
 * @param  Decimal $latitude1  ���γ��
 * @param  Decimal $longitude2 �յ㾭��
 * @param  Decimal $latitude2  �յ�γ��
 * @param  Int     $unit       ��λ 1:�� 2:����
 * @param  Int     $decimal    ���� ����С��λ��
 * @return Decimal
 */
function tomGetDistance($longitude1, $latitude1, $longitude2, $latitude2, $unit=2, $decimal=1){

    $EARTH_RADIUS = 6370.996; // ����뾶ϵ��
    $PI = 3.1415926;

    $radLat1 = $latitude1 * $PI / 180.0;
    $radLat2 = $latitude2 * $PI / 180.0;

    $radLng1 = $longitude1 * $PI / 180.0;
    $radLng2 = $longitude2 * $PI / 180.0;

    $a = $radLat1 - $radLat2;
    $b = $radLng1 - $radLng2;

    $distance = 2 * asin(sqrt(pow(sin($a/2),2) + cos($radLat1) * cos($radLat2) * pow(sin($b/2),2)));
    $distance = $distance * $EARTH_RADIUS * 1000;

    if($unit==2){
        $distance = $distance / 1000;
    }

    return round($distance, $decimal);

}

/**
 * ��ɫ16���� ת RGB
 */
function hex2rgbstr($hexColor){
    
    $color = str_replace('#','',$hexColor);
    if (strlen($color)> 3){
         $rgb = array(
              'r'=>hexdec(substr($color,0,2)),
              'g'=>hexdec(substr($color,2,2)),
              'b'=>hexdec(substr($color,4,2))
         );
    }else{
         $r = substr($color,0,1). substr($color,0,1);
         $g = substr($color,1,1). substr($color,1,1);
         $b = substr($color,2,1). substr($color,2,1);
         $rgb = array( 
              'r'=>hexdec($r),
              'g'=>hexdec($g),
              'b'=>hexdec($b)
         );
    }
    return $rgb['r'].','.$rgb['g'].','.$rgb['b'];
 
}