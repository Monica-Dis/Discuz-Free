<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS pre_tom_tcqianggou_autoid;
DROP TABLE IF EXISTS pre_tom_tcqianggou_cate;
DROP TABLE IF EXISTS pre_tom_tcqianggou_focuspic;
DROP TABLE IF EXISTS pre_tom_tcqianggou_goods;
DROP TABLE IF EXISTS pre_tom_tcqianggou_goods_photo;
DROP TABLE IF EXISTS pre_tom_tcqianggou_order;
DROP TABLE IF EXISTS pre_tom_tcqianggou_stock_log;
DROP TABLE IF EXISTS pre_tom_tcqianggou_xubuy;
DROP TABLE IF EXISTS pre_tom_tcqianggou_goods_option;
DROP TABLE IF EXISTS pre_tom_tcqianggou_order_use_log;
DROP TABLE IF EXISTS pre_tom_tcqianggou_code;
DROP TABLE IF EXISTS pre_tom_tcqianggou_goods_shop;
DROP TABLE IF EXISTS pre_tom_tcqianggou_recom_cate;
DROP TABLE IF EXISTS pre_tom_tcqianggou_goods_tz;
DROP TABLE IF EXISTS pre_tom_tcqianggou_group_qrcode;
DROP TABLE IF EXISTS pre_tom_tcqianggou_popup;
DROP TABLE IF EXISTS pre_tom_tcqianggou_popup_log;
DROP TABLE IF EXISTS pre_tom_tcqianggou_trade;
DROP TABLE IF EXISTS pre_tom_tcqianggou_goods_clicks;

EOF;

runquery($sql);

$finish = TRUE;