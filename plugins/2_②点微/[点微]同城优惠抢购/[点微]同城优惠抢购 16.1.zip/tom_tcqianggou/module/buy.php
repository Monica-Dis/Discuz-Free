<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id           = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
$option_id          = intval($_GET['option_id'])>0? intval($_GET['option_id']):0;
$number             = intval($_GET['number'])>0? intval($_GET['number']):1;
$address_id         = isset($_GET['address_id'])? intval($_GET['address_id']):0;
$tj_hehuoren_id     = intval($_GET['tj_hehuoren_id'])>0? intval($_GET['tj_hehuoren_id']):0;
$tcyuyue_log_id     = isset($_GET['tcyuyue_log_id'])? intval($_GET['tcyuyue_log_id']):0;

$back_url = $weixinClass->get_url();
$back_url = preg_replace('/&address_id=[0-9]*/', '', $back_url);
$back_url = preg_replace('/&tcyuyue_log_id=[0-9]*/', '', $back_url);
$back_url = urlencode($back_url);

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);

if($goodsInfo['min_num'] > 0 && $number < $goodsInfo['min_num']){
    $number = $goodsInfo['min_num'];
}

$buy_price      = $goodsInfo['buy_price'];
$vip_price      = $goodsInfo['vip_price'];
$before_price   = $goodsInfo['before_price'];
$stock_num      = $goodsInfo['stock_num'];
$sale_num       = $goodsInfo['sale_num'];

$score_num          = $goodsInfo['score_num'];
$score_dikou_price  = $goodsInfo['score_dikou_price'];
if($goodsInfo['hasoption'] == 1){
    $optionInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($option_id);
    if(is_array($optionInfo) && !empty($optionInfo) && $optionInfo['id'] > 0){
        $buy_price      = $optionInfo['buy_price'];
        $vip_price      = $optionInfo['vip_price'];
        $before_price   = $optionInfo['before_price'];
        $stock_num      = $optionInfo['stock_num'];
        $sale_num       = $optionInfo['sale_num'];

        $score_num          = $optionInfo['score_num'];
        $score_dikou_price  = $optionInfo['score_dikou_price'];
    }
}

$score_goods_num = 1;
if($tcqianggouConfig['open_goods_num_dikou_score'] == 1){
    $score_goods_num = $number;
}
$total_score_num = $score_num * $score_goods_num;
$total_score_dikou_price = $score_dikou_price * $score_goods_num;

if(!preg_match('/^http/', $goodsInfo['picurl']) ){
    if(strpos($goodsInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['picurl'];
    }else{
        $picurl = $goodsInfo['picurl'];
    }
}else{
    $picurl = $goodsInfo['picurl'];
}

if($goodsInfo['open_xubuy'] == 1){
    $qiangListCount  = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(" AND goods_id={$goods_id} AND type_id=2 ");
    $goodsInfo['sale_num'] = $goodsInfo['sale_num'] + $qiangListCount;
    if($goodsInfo['hasoption'] == 1){
        $qiangOptionListCount  = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(" AND goods_id={$goods_id} AND type_id=2 AND option_id = {$option_id}");
        $sale_num = $sale_num + $qiangOptionListCount;
    }else{
        $sale_num = $sale_num + $qiangListCount;
    }
}

$goodsInfo['qiang_status'] = update_qiang_status($goodsInfo);

$setAddressStatus = 0;
$setAddressUrl = '';
$addressListCount = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_count(" AND uid={$__MemberInfo['uid']} ");
if($addressListCount == 0){
    $setAddressStatus = 1;
    $setAddressUrl = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=address&act=add&buying=1&address_back_url={$back_url}";
}
$addressInfo = array();
$addressInfoTmp = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
if($addressInfoTmp && !empty($addressInfoTmp['id'])){
    $address_id  = $addressInfoTmp['id'];
    $addressInfo = $addressInfoTmp;
}else{
    $defaultAddressList = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_list(" AND uid={$__MemberInfo['uid']} AND default_id=1 ","ORDER BY id DESC",0,1);
    if($defaultAddressList && !empty($defaultAddressList['0']['id'])){
        $address_id = $defaultAddressList['0']['id'];
        $addressInfo = $defaultAddressList['0'];
    }else{
        $setAddressStatus = 1;
        $setAddressUrl = $_G['siteurl']."plugin.php?id=tom_tongcheng&site={$site_id}&mod=address&act=add&buying=1&address_back_url={$back_url}";
    }
}
$changeAddressUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=address&buying=1&address_id={$address_id}&address_back_url={$back_url}";

$tcyikatongPayStatus = 0;
if($__ShowTcyikatong == 1 && $goodsInfo['open_vip'] == 1){
    if($__CardInfo['status'] == 1){
        $tcyikatongPayStatus = 1;
    }
}
$showBeforeBuyStatus = 0;
if($goodsInfo['open_before'] == 1 && $before_price > 0 && $goodsInfo['before_num'] > 0  && $goodsInfo['type_id'] == 1){
    $userBeforeOrderInfoTmp = C::t("#tom_tcqianggou#tom_tcqianggou_order")->fetch_all_List(" AND goods_id={$goodsInfo['id']} AND before_pay_status = 1 AND order_status IN(1,2,3) AND user_id = {$__UserInfo['id']} ",'ORDER BY id DESC', 0, 1);
    if(is_array($userBeforeOrderInfoTmp) && !empty($userBeforeOrderInfoTmp[0])){ }else{
        $before_sale_count = C::t("#tom_tcqianggou#tom_tcqianggou_order")->fetch_all_count(" AND goods_id={$goodsInfo['id']} AND before_pay_status = 1 AND order_status IN(1,2,3) ");
        if($before_sale_count < $goodsInfo['before_num']){
            $tcyikatongPayStatus = 0;
            $showBeforeBuyStatus = 1;
        }
    }
}

$pay_price      = 0;
$shenyu_price   = 0;
$ding_price_status = 0;
if($goodsInfo['type_id'] == 1){
    if( $tcqianggouConfig['open_ding_price'] == 1 && $goodsInfo['open_ding_pay'] == 1){
        $ding_price_status = 1;
        $pay_price = $goodsInfo['ding_price'];

        if($tcyikatongPayStatus == 1){
            $shenyu_price = $vip_price - $goodsInfo['ding_price'];
        }else if($showBeforeBuyStatus == 1){
            $shenyu_price = $before_price - $goodsInfo['ding_price'];
        }else{
            $shenyu_price = $buy_price - $goodsInfo['ding_price'];
        }
    }else{
        if($tcyikatongPayStatus == 1){
            $pay_price = $vip_price;
        }else if($showBeforeBuyStatus == 1){
            $pay_price = $before_price;
        }else{
            $pay_price = $buy_price;
        }
    }
}else{
    if($goodsInfo['coupon_is_buy'] == 1){
        if($tcyikatongPayStatus == 1){
            $pay_price = $vip_price;
        }else{
            $pay_price = $goodsInfo['coupon_buy_price'];
        }
    }
}

$pay_price_arr = array();
$shenyu_price_arr = array();
for($i=1;$i<=100;$i++){
    $pay_price_arr[$i] = ($pay_price*$i);
    $shenyu_price_arr[$i] = ($shenyu_price*$i);
}

$isShowRandBtn = 0;
$randSecond = rand(3, 5);
if(($stock_num - $sale_num) <= 3){
    $isShowRandBtn = 1;
}

$orderListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list(" AND goods_id={$goodsInfo['id']} AND order_status=1 "," ORDER BY id DESC ",0,20);
if(is_array($orderListTmp) && !empty($orderListTmp)){
    foreach ($orderListTmp as $key => $value){
        if($value['order_status'] == 1){
            if((TIMESTAMP - $value['order_time']) > 3600){
                DB::query("UPDATE ".DB::table('tom_tcqianggou_goods')." SET sale_num=sale_num - {$value['goods_num']} WHERE id='{$value['goods_id']}' ", 'UNBUFFERED');
                DB::query("UPDATE ".DB::table('tom_tcqianggou_order')." SET order_status=4 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                if($value['option_id'] > 0){
                    DB::query("UPDATE ".DB::table('tom_tcqianggou_goods_option')." SET sale_num=sale_num - {$value['goods_num']} WHERE id='{$value['option_id']}' ", 'UNBUFFERED');
                }
                if($value['code_order'] == 1){
                    DB::query("UPDATE ".DB::table('tom_tcqianggou_code')." SET order_id=0,order_no='',user_id=0,code_status=0 WHERE goods_id={$value['goods_id']} AND order_id={$value['id']} ", 'UNBUFFERED');
                }
            }
        }
    }
}

$noPayOrderListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list(" AND goods_id={$goodsInfo['id']} AND user_id={$__UserInfo['id']} AND order_status=1 "," ORDER BY id DESC ",0,10);
$isHaveNoPay = 0;
if(is_array($noPayOrderListTmp) && !empty($noPayOrderListTmp)){
    foreach ($noPayOrderListTmp as $key => $value){
        if($value['order_status'] == 1){
            if((TIMESTAMP - $value['order_time']) > 3600){
                DB::query("UPDATE ".DB::table('tom_tcqianggou_goods')." SET sale_num=sale_num - {$value['goods_num']} WHERE id='{$value['goods_id']}' ", 'UNBUFFERED');
                DB::query("UPDATE ".DB::table('tom_tcqianggou_order')." SET order_status=4 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                if($value['option_id'] > 0){
                    DB::query("UPDATE ".DB::table('tom_tcqianggou_goods_option')." SET sale_num=sale_num - {$value['goods_num']} WHERE id='{$value['option_id']}' ", 'UNBUFFERED');
                }
                if($value['code_order'] == 1){
                    DB::query("UPDATE ".DB::table('tom_tcqianggou_code')." SET order_id=0,order_no='',user_id=0,code_status=0 WHERE goods_id={$value['goods_id']} AND order_id={$value['id']} ", 'UNBUFFERED');
                }
            }else{
                $isHaveNoPay = 1;
            }
        }
    }
}

$xiangouStatus = 0;
$goods_xiangou_num = 0;
if($goodsInfo['xiangou_num'] > 0){
    $myHaveOrderCount  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_goods_num(" AND goods_id={$goodsInfo['id']} AND user_id={$__UserInfo['id']} AND order_status IN(1,2,3) ");
    $goods_xiangou_num = $goodsInfo['xiangou_num'] - $myHaveOrderCount;
    if($myHaveOrderCount >= $goodsInfo['xiangou_num']){
        $xiangouStatus = 1;
    }
}

$tcyuyueStatus = 0;
if($__ShowTcyuyue == 1 && $goodsInfo['peisong_type'] == 1 && $goodsInfo['open_yuyue'] == 1 && $goodsInfo['yuyue_type'] == 2){
    $tcyuyueStatus = 1;
    $tcyuyueUrl = "plugin.php?id=tom_tcyuyue&site={$site_id}&mod=info&goods_id={$goods_id}&tcyuyue_log_id={$tcyuyue_log_id}&yuyue_type=qianggou&buy_status=1&back_url={$back_url}";
    $tcyuyueLogInfo = C::t('#tom_tcyuyue#tom_tcyuyue_log')->fetch_by_id($tcyuyue_log_id);
    if($tcyuyueLogInfo && $tcyuyueLogInfo['user_id'] == $__UserInfo['id'] && $tcyuyueLogInfo['goods_id'] == $goodsInfo['id']){
        $tcyuyueStatus = 2;
        $tcyuyueInfo = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_by_id($tcyuyueLogInfo['tcyuyue_id']);
        $yuyue_start_time = $tcyuyueLogInfo['time_start_stamp'] + $tcyuyueLogInfo['yuyue_daytime'];
        $tcyuyueLogInfo['yuyue_start_time']  = dgmdate($yuyue_start_time, 'Y-m-d',$tomSysOffset);
    }
}

$xm = $tel = "";
if($goodsInfo['peisong_type'] == 2 || $goodsInfo['peisong_type'] == 3){
    $userOrderTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND peisong_type IN(2,3)  AND order_status IN(2,3) "," ORDER BY id DESC ",0,1);
}else{
    $userOrderTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND order_status IN(2,3) "," ORDER BY id DESC ",0,1);
}
if(is_array($userOrderTmp) && !empty($userOrderTmp) && !empty($userOrderTmp[0]['tel'])){
    $xm = $userOrderTmp[0]['xm'];
    $tel = $userOrderTmp[0]['tel'];
}
if(empty($tel)){
    $tel = $__UserInfo['tel'];
}

$showMustPhoneBtn = 0;
if($tcqianggouConfig['buy_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

if($pay_price > 0){
    $qiangUrl = "plugin.php?id=tom_tcqianggou:pay&site={$site_id}&act=pay_qiang";
}else{
    $qiangUrl = "plugin.php?id=tom_tcqianggou:pay&site={$site_id}&act=pay_ling";
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:buy");