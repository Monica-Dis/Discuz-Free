<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$hexiao_code    = !empty($_GET['hexiao_code'])? addslashes($_GET['hexiao_code']):'';
$goods_shop_id  = intval($_GET['goods_shop_id'])? intval($_GET['goods_shop_id']):0;
$hxback         = intval($_GET['hxback'])? intval($_GET['hxback']):0;

$orderInfo = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_by_hexiao_code($hexiao_code);
$goodsInfo  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($orderInfo['goods_id']);
$goodsShopInfo  = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->fetch_by_id($goods_shop_id);

if($orderInfo['goods_id'] != $goodsShopInfo['goods_id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");exit;
}

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsShopInfo['tcshop_id']);
if($tcshopInfo['hexiao_type'] > 0){
    $tcqianggouConfig['hexiao_type'] = $tcshopInfo['hexiao_type'];
}

if($_GET['act'] == 'hexiao' && $_GET['formhash'] == FORMHASH){

    $hexiao_pwd = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';

    if($tcqianggouConfig['hexiao_type'] == 2){
        if(empty($goodsShopInfo['hexiao_pwd'])){
            echo 301;exit;
        }
        if($goodsShopInfo['hexiao_pwd'] != $hexiao_pwd){
            echo 302;exit;
        }
    }

    $syStockNum = $goodsShopInfo['stock_num'] - $goodsShopInfo['sale_num'];
    if($syStockNum < 1){
        echo 304;exit;
    }

    $sytotal_hexiao_num = 0;
    if($goodsInfo['duo_hexiao_num'] > 0){
        $sytotal_hexiao_num = $goodsInfo['duo_hexiao_num'] - $orderInfo['use_num'];
        if($sytotal_hexiao_num < 1){
            echo 303;exit;
        }
    }

    $use_num = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_sum_use_num(" AND user_id = {$orderInfo['user_id']} AND order_id = {$orderInfo['id']} AND goods_shop_id = {$goodsShopInfo['id']} ");
    $syUseNum = $goodsShopInfo['xian_use_num'] - $use_num;
    if($syUseNum < 1){
        echo 303;exit;
    }

    $hexiaoStatus = 1;
    if($goodsInfo['duo_hexiao_num'] > 0){
        if($sytotal_hexiao_num > 1){
            $hexiaoStatus = 2;
        }
        if($sytotal_hexiao_num == 1){
            $hexiaoStatus = 3;
        }
    }else{
        $hexiaoStatus = 2;
    }

    $insertData = array();
    $insertData['order_id']         = $orderInfo['id'];
    $insertData['user_id']          = $orderInfo['user_id'];
    $insertData['goods_shop_id']    = $goods_shop_id;
    $insertData['use_num']          = 1;
    $insertData['hexiao_user_id']   = $__UserInfo['id'];
    $insertData['hexiao_time']      = TIMESTAMP;
    C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->insert($insertData);

    $updateData = array();
    if($hexiaoStatus == 2){
        $updateData['use_num']          = $orderInfo['use_num'] + 1;
    }else{
        $updateData['use_num']          = $orderInfo['use_num'] + 1;
        $updateData['order_status']     = 3;
        $updateData['hexiao_user_id']   = $__UserInfo['id'];
        $updateData['hexiao_time']      = TIMESTAMP;
    }
    C::t('#tom_tcqianggou#tom_tcqianggou_order')->update($orderInfo['id'],$updateData);

    DB::query("UPDATE ".DB::table('tom_tcqianggou_goods_shop')." SET sale_num=sale_num+1 WHERE id={$goods_shop_id} ", 'UNBUFFERED');

    if($orderInfo['balance_status'] == 0){
        $duo_balance_type = 1;
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/module/duo_balance.php';
    }

    echo 200;exit;

}

if($orderInfo && $orderInfo['goods_id'] > 0 && $goodsShopInfo['goods_id'] > 0){

    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($orderInfo['goods_id']);

    $allowHexiao = 1;
    $clerkListTmp  = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(" AND tcshop_id={$goodsShopInfo['tcshop_id']} AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,1);
    if(!empty($clerkListTmp[0]['id']) || $tcshopInfo['user_id'] == $__UserInfo['id'] ){
        $allowHexiao = 1;
    }else if($tcqianggouConfig['hexiao_type'] == 1){
        $allowHexiao = 2;
    }

    if(!preg_match('/^http/', $goodsShopInfo['picurl']) ){
        if(strpos($goodsShopInfo['picurl'], 'source/plugin/tom_') === FALSE){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsShopInfo['picurl'];
        }else{
            $picurl = $goodsShopInfo['picurl'];
        }
    }else{
        $picurl = $goodsShopInfo['picurl'];
    }

    $contentTmp = strip_tags($goodsShopInfo['content']);
    $contentTmp = str_replace("\r\n","",$contentTmp);
    $contentTmp = str_replace("\n","",$contentTmp);
    $contentTmp = str_replace("\r","",$contentTmp);
    $content = stripslashes($goodsShopInfo['content']);

    $hexiaoTimeStatus = 1;
    if(TIMESTAMP > $goodsInfo['hexiao_time']){
        $hexiaoTimeStatus = 2;
    }

    $hexiaoUserInfo = array();
    if($orderInfo['order_status'] == 3){
        $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']); 
    }

    $useLogListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_all_list(" AND order_id = {$orderInfo['id']} AND goods_shop_id = {$goodsShopInfo['id']} ", 'ORDER BY id DESC', 0, 100);
    $useLogList = array();
    if(is_array($useLogListTmp) && !empty($useLogListTmp)){
        foreach($useLogListTmp as $key => $value){
            $useLogList[$key] = $value;
            $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
            $useLogList[$key]['userInfo'] = $userInfoTmp;
        }
    }
    $useLogCount = count($useLogList);

    $use_num = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_sum_use_num(" AND user_id = {$orderInfo['user_id']} AND order_id = {$orderInfo['id']} AND goods_shop_id = {$goodsShopInfo['id']} ");
    $use_num = intval($use_num);

    $hexiaoStatus = 1;
    if($goodsInfo['duo_hexiao_num'] > 0){
        $sytotal_hexiao_num = $goodsInfo['duo_hexiao_num'] - $orderInfo['use_num'];
        if($sytotal_hexiao_num <= 0){
            $hexiaoStatus = 2;
        }
    }
    
    $syUseNum = $goodsShopInfo['xian_use_num'] - $use_num;
    if($syUseNum < 1){
        $hexiaoStatus = 3;
    }

    $syStockNum = $goodsShopInfo['stock_num'] - $goodsShopInfo['sale_num'];
    if($syStockNum <= 0){
        $hexiaoStatus = 4;
    }
}

$hexiaoUrl = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=orderhexiao_duo&act=hexiao&goods_shop_id='.$goods_shop_id;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:orderhexiao_duo");