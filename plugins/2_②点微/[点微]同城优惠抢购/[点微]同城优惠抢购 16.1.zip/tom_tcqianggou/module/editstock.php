<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");exit;
}

if($goodsInfo['open_xubuy'] == 1){
    $qiangListCount  = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(" AND goods_id={$goods_id} AND type_id=2 ");
    $goodsInfo['sale_num'] = $goodsInfo['sale_num'] + $qiangListCount;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $stock_num          = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
    
    if($stock_num < $goodsInfo['sale_num']){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $updateData = array();
    $updateData['stock_num']      = $stock_num;
    if(C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($goods_id,$updateData)){
        
        $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
        update_qiang_status($goodsInfoTmp);
        
        $insertData = array();
        $insertData['is_admin']     = 0;
        $insertData['goods_id']     = $goods_id;
        $insertData['change_num']   = $stock_num;
        $insertData['change_time']  = TIMESTAMP;
        C::t('#tom_tcqianggou#tom_tcqianggou_stock_log')->insert($insertData);
        
        $outArr = array(
            'status'=> 200,
            'goods_id'=> $goods_id,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}


$saveUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=editstock&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:editstock");