<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");exit;
}

$act = isset($_GET['act'])? addslashes($_GET['act']):'';
if($act == 'remove_option' && $_GET['formhash'] == FORMHASH){
    
    $option_id = intval($_GET['option_id'])>0? intval($_GET['option_id']): 0;
    
    C::t("#tom_tcqianggou#tom_tcqianggou_goods_option")->delete_by_id($option_id);
    
    $optionListTmp = C::t("#tom_tcqianggou#tom_tcqianggou_goods_option")->fetch_all_list(" AND goods_id = {$goods_id} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_market_price = $show_buy_price = $stock_num = 0;
        foreach($optionListTmp as $key => $value){
            $stock_num = $stock_num + $value['stock_num'];
            if($show_buy_price == 0){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
            }else if($value['buy_price'] < $show_buy_price){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
            }
        }
        if($show_buy_price > 0){
            $updateData = array();
            $updateData['show_market_price']    = $show_market_price;
            $updateData['show_buy_price']       = $show_buy_price;
            $updateData['stock_num']            = $stock_num;
            $updateData['part1']                = TIMESTAMP;
            C::t("#tom_tcqianggou#tom_tcqianggou_goods")->update($goods_id,$updateData);
        }
        $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
        update_qiang_status($goodsInfoTmp);
    }
    
    echo 1;exit;

}else if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $option_id          = intval($_GET['option_id'])> 0? intval($_GET['option_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):"";
    $market_price       = floatval($_GET['market_price'])> 0? floatval($_GET['market_price']):0.00;
    $buy_price          = floatval($_GET['buy_price'])> 0? floatval($_GET['buy_price']):0.00;
    $score_num          = intval($_GET['score_num'])> 0? intval($_GET['score_num']):0;
    $score_dikou_price  = floatval($_GET['score_dikou_price'])> 0? floatval($_GET['score_dikou_price']):0.00;
    $stock_num          = floatval($_GET['stock_num'])> 0? floatval($_GET['stock_num']):0.00;
    
    if($option_id > 0){
        $optionInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($option_id);
        
        if($stock_num < $optionInfo['sale_num']){
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
        
        $updateData = array();
        $updateData['name']                 = $name;
        $updateData['market_price']         = $market_price;
        $updateData['buy_price']            = $buy_price;
        $updateData['score_num']            = $score_num;
        $updateData['score_dikou_price']    = $score_dikou_price;
        $updateData['stock_num']            = $stock_num;
        $updateData['part1']                = TIMESTAMP;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->update($option_id,$updateData);
    }else{
        $insertData = array();
        $insertData['goods_id']             = $goods_id;
        $insertData['name']                 = $name;
        $insertData['market_price']         = $market_price;
        $insertData['buy_price']            = $buy_price;
        $updateData['score_num']            = $score_num;
        $updateData['score_dikou_price']    = $score_dikou_price;
        $insertData['stock_num']            = $stock_num;
        $insertData['add_time']             = TIMESTAMP;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->insert($insertData);
        $option_id = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->insert_id();
    }
    
    $beizu = 'ID:&nbsp;<font color="#0a9409">'.$option_id.'</font> '.lang('plugin/tom_tcqianggou', 'option_name').' <font color="#0a9409">'.$name.'</font>: '.lang('plugin/tom_tcqianggou', 'option_stock_num').'<font color="#fd0d0d">'.$stock_num.'</font> '.lang('plugin/tom_tcqianggou', 'option_market_price').'<font color="#fd0d0d">'.$market_price.'</font> '.lang('plugin/tom_tcqianggou', 'option_buy_price').'<font color="#fd0d0d">'.$buy_price.'</font><br/>';
    
    $insertData = array();
    $insertData['is_admin']     = 0;
    $insertData['is_option']    = 1;
    $insertData['goods_id']     = $goods_id;
    $insertData['beizu']        = $beizu;
    $insertData['change_num']   = $stock_num;
    $insertData['change_time']  = TIMESTAMP;
    C::t("#tom_tcqianggou#tom_tcqianggou_stock_log")->insert($insertData);
    
    $optionListTmp = C::t("#tom_tcqianggou#tom_tcqianggou_goods_option")->fetch_all_list(" AND goods_id = {$goods_id} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_market_price = $show_buy_price = $stock_num = 0;
        foreach($optionListTmp as $key => $value){
            $stock_num = $stock_num + $value['stock_num'];
            if($show_buy_price == 0){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
            }else if($value['buy_price'] < $show_buy_price){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
            }
        }
        if($show_buy_price > 0){
            $updateData = array();
            $updateData['show_market_price']    = $show_market_price;
            $updateData['show_buy_price']       = $show_buy_price;
            $updateData['stock_num']            = $stock_num;
            $updateData['part1']                = TIMESTAMP;
            C::t("#tom_tcqianggou#tom_tcqianggou_goods")->update($goods_id,$updateData);
        }
    }
    
    $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
    update_qiang_status($goodsInfoTmp);
    
    $outArr = array(
        'status'=> 200,
        'option_id'=> $option_id,
    );
    echo json_encode($outArr); exit;

}

$optionListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_all_list(" AND goods_id = {$goods_id}", 'ORDER BY osort ASC,id ASC', 0, 100);
$optionList = array();
if(is_array($optionListTmp) && !empty($optionListTmp)){
    foreach($optionListTmp as $key => $value){
        $optionList[$key] = $value;
    }
}

$saveUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=editoption&goods_id={$goods_id}&act=save&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:editoption");