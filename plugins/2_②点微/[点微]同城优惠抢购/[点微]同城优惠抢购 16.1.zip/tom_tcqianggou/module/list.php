<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword            = addslashes($_GET['keyword'])? addslashes($_GET['keyword']):'';
$user_id            = intval($_GET['user_id'])>0? intval($_GET['user_id']):0;
$trade_id           = intval($_GET['trade_id'])>0? intval($_GET['trade_id']):0;
$cate_id            = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$recom_cate_id      = intval($_GET['recom_cate_id'])>0? intval($_GET['recom_cate_id']):0;
$qiang_status       = intval($_GET['qiang_status'])>0? intval($_GET['qiang_status']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;
$no_goods_id        = intval($_GET['no_goods_id'])>0? intval($_GET['no_goods_id']):0;
$qianggou_ids       = addslashes($_GET['qianggou_ids'])? addslashes($_GET['qianggou_ids']):'';
$qiang_list_type    = intval($_GET['qiang_list_type'])>0? intval($_GET['qiang_list_type']):0;
$is_vip             = intval($_GET['is_vip'])>0? intval($_GET['is_vip']):0;
$order_type         = addslashes($_GET['order_type'])? addslashes($_GET['order_type']):'default';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$whereStr = ' AND status=1 AND shenhe_status=1 AND type_id=1 ';
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if(!empty($user_id)){
    $whereStr.= " AND user_id={$user_id} ";
}
if(!empty($no_goods_id)){
    $whereStr.= " AND id != {$no_goods_id} ";
    if(!empty($qianggou_ids)){
        $qianggouIdsArrTmp = explode('|', $qianggou_ids);
        $qianggouIdsArr = array();
        foreach($qianggouIdsArrTmp as $key => $value){
            $value = intval($value);
            if($value > 0){
                $qianggouIdsArr[] = $value;
            }
        }
        $qianggouIdsStr = implode(',', $qianggouIdsArr);
        $whereStr.= " AND id IN({$qianggouIdsStr}) ";
    }
}
if(!empty($trade_id)){
    $whereStr.= " AND trade_id={$trade_id} ";
}
if(!empty($cate_id)){
    $whereStr.= " AND cate_id={$cate_id} ";
}
if($recom_cate_id > 0){
    $whereStr.= " AND recom_cate_id={$recom_cate_id} ";
}
if(!empty($qiang_status)){
    $whereStr.= " AND qiang_status={$qiang_status} ";
}

if($qiang_list_type > 0){
    $tcqianggouConfig['qiang_list_type'] = $qiang_list_type;
}

if($is_vip == 1){
    $whereStr.= " AND open_vip=1 ";
}

$orderStr = " ORDER BY qiang_status ASC,paixu ASC,id DESC ";

$pagesize       = $pagesize;
$start          = ($page - 1)*$pagesize;

if($order_type == 'nearby' && !empty($latitude) && !empty($longitude)){
    $tcqianggouListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_nearby_list($whereStr,$start,$pagesize,$latitude,$longitude,$keyword);
}else{
    $order_type = 'default';
    $tcqianggouListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_list($whereStr,$orderStr,$start,$pagesize,$keyword);
}
$tcqianggouList = array();
foreach ($tcqianggouListTmp as $key => $value){

    if($value['show_buy_price'] <= 0){
        $value['show_buy_price']    = $value['buy_price'];
        $value['show_vip_price']    = $value['vip_price'];
        $value['show_market_price'] = $value['market_price'];
    }

    if($value['open_xubuy'] == 1){
        $qiangListCount  = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(" AND goods_id={$value['id']} AND type_id=2 ");
        $value['sale_num'] = $value['sale_num'] + $qiangListCount;
    }

    $tcqianggouList[$key] = $value;
    if(!preg_match('/^http/', $value['picurl']) ){
        if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $picurl = $value['picurl'];
        }
    }else{
        $picurl = $value['picurl'];
    }
    
    if($value['open_duo_shop'] == 0 && $value['tcshop_id'] > 0){
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        if(!empty($tcshopInfoTmp['latitude']) && !empty($tcshopInfoTmp['longitude']) && ($tcshopInfoTmp['latitude'] != $value['latitude'] || $tcshopInfoTmp['longitude'] != $value['longitude'])){
            $updateData = array();
            $updateData['latitude']     = $tcshopInfoTmp['latitude'];
            $updateData['longitude']    = $tcshopInfoTmp['longitude'];
            C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($value['id'], $updateData);
        }
    }
    
    $juliTmp = 0;
    if($order_type == 'nearby'){
        $juliTmp = tomGetDistance($longitude, $latitude, $value['longitude'], $value['latitude']);
    }
        
    $tcqianggouList[$key]['picurl'] = $picurl;
    $tcqianggouList[$key]['juli']   = $juliTmp;
    $tcqianggouList[$key]['link']   = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=details&goods_id='.$value['id'];
    $tcqianggouList[$key]['clicks'] = $value['clicks'] + $value['virtual_clicks'];
    
    update_qiang_status($value);
}

if(is_array($tcqianggouList) && !empty($tcqianggouList)){
    foreach ($tcqianggouList as $key => $val){
        
        if($tcqianggouConfig['qiang_list_type'] == 2){
            $outStr.= '<div class="rec_big_area">';
                $outStr.= '<div class="big_area__hd">';
                    $outStr.= '<a href="'.$val['link'].'"><img src="'.$val['picurl'].'"></a>';
                    $shengyu_num = $val['stock_num'] - $val['sale_num'];
                    if($shengyu_num > 0){}else{
                        $shengyu_num = 0;
                    }
                    if($val['qiang_status'] == 1){
                        $outStr.= '<div class="num_ts">'.lang('plugin/tom_tcqianggou','template_ajax_shengyu_num1').''.$shengyu_num.''.lang('plugin/tom_tcqianggou','template_ajax_shengyu_num2').'</div>';
                    }
                    $outStr.= '<div class="times_ts">';
                        if($val['qiang_status'] == 2){
                            if($val['start_time'] > TIMESTAMP){
                                $syTime = ($val['start_time'] - TIMESTAMP)*1000;
                                $outStr.= ''.lang('plugin/tom_tcqianggou','template_ajax_julistart').'&nbsp;<span class="daojishi" data-time="'.$syTime.'">-</span>';
                            }else{
                                $outStr.= '<span>'.lang('plugin/tom_tcqianggou','template_ajax_no_start').'</span>';
                            }
                        }else if($val['qiang_status'] == 3){
                            $outStr.= '<span>'.lang('plugin/tom_tcqianggou','template_ajax_end').'</span>';
                        }else{
                            if($val['end_time'] > TIMESTAMP){
                                $syTime = ($val['end_time'] - TIMESTAMP)*1000;
                                $outStr.= ''.lang('plugin/tom_tcqianggou','template_ajax_julijiesu').'&nbsp;<span class="daojishi" data-time="'.$syTime.'">-</span>';
                            }
                        }
                        if($order_type == 'nearby' && $val['juli'] > 0){
                            $outStr.= '<div class="guanzu">'.lang('plugin/tom_tcqianggou','template_ajax_juli').''.$val['juli'].'km</div>';
                        }else{
                            $outStr.= '<span class="guanzu"><em class="tciconfont tcicon-hot"></em>&nbsp;'.lang('plugin/tom_tcqianggou','template_ajax_clicks').''.$val['clicks'].'</span>';
                        }
                    $outStr.= '</div>';
                $outStr.= '</div>';
                $outStr.= '<div class="big_area__bd">';
                    $outStr.= '<div class="bd-content">';
                        $outStr.= '<h5><a href="'.$val['link'].'">'.$val['title'].'</a></h5>';
                        if($tcqianggouConfig['open_ding_price'] == 1 && $val['open_ding_pay'] == 1){
                            $outStr.= '<p class="price">';
                                $outStr.= '<span class="now_price">'.lang('plugin/tom_tcqianggou','yuan_ico').'<span>'.floatval($val['ding_price']).'</span>'.lang('plugin/tom_tcqianggou','dingjing').'</span>&nbsp;';
                                $outStr.= '<span class="old_price">'.lang('plugin/tom_tcqianggou','yuan_ico').''.floatval($val['show_market_price']).'</span>';
                            $outStr.= '</p>';
                        }else{
                            if($__ShowTcyikatong == 1 && $val['open_vip'] == 1){
                                $lijianPrice = $val['show_buy_price'] - $val['show_vip_price'];
                                $outStr.= '<div class="vip-price"><a href="'.$val['link'].'"><span class="vip">'.$tcyikatongConfig['card_name'].'</span><span class="lijian">'.lang('plugin/tom_tcqianggou', 'template_ajax_lijian').$lijianPrice.lang('plugin/tom_tcqianggou','yuan').'</span></a></div>';
                            }
                            $outStr.= '<p class="price">';
                                $outStr.= '<span class="now_price">'.lang('plugin/tom_tcqianggou','yuan_ico').'<span>'.floatval($val['show_buy_price']).'</span></span>&nbsp;';
                                $outStr.= '<span class="old_price">'.lang('plugin/tom_tcqianggou','yuan_ico').''.floatval($val['show_market_price']).'</span>';
                            $outStr.= '</p>';
                        }
                        if($val['qiang_status'] == 1){
                            $outStr.= '<div class="button"><a href="'.$val['link'].'">'.lang('plugin/tom_tcqianggou','template_ajax_qiang_btn').'</a></div>';
                        }else if($val['qiang_status'] == 2){
                            $outStr.= '<div class="button" style="background: #dadada;"><a href="javascript:;" >'.lang('plugin/tom_tcqianggou','template_ajax_no_start').'</a></div>';
                        }else if($val['qiang_status'] == 3){
                            $outStr.= '<div class="button" style="background: #dadada;"><a href="javascript:;" >'.lang('plugin/tom_tcqianggou','template_ajax_end').'</a></div>';
                        }
                    $outStr.= '</div>';
                $outStr.= '</div>';
            $outStr.= '</div>';
        }else if($tcqianggouConfig['qiang_list_type'] == 3){
            $outStr.= '<a class="list-item__box" href="'.$val['link'].'">';
                $outStr.= '<div class="item-hd">';
                    $outStr.= '<img src="'.$val['picurl'].'">';
                    if($val['qiang_status'] == 1){
                        $syTime = ($val['end_time'] - TIMESTAMP)*1000;
                        $outStr.= '<div class="times_ts"><span class="daojishi" data-time="'.$syTime.'">-</span><span class="guanzu"></div>';
                    }
                    if($val['qiang_status'] == 2){
                        $outStr.= '<div class="item-hd__icon"><i class="tciconfont tcicon-no_start"></i></div>';
                    }else if($val['qiang_status'] == 3){
                        $outStr.= '<div class="item-hd__icon"><i class="tciconfont tcicon-end"></i></div>';
                    }
                $outStr.= '</div>';
                $outStr.= '<div class="item-bd">';
                    $outStr.= '<div class="item-bd__title">'.$val['title'].'</div>';
                    $outStr.= '<div class="item-bd__price dislay-flex">';
                        if($tcqianggouConfig['open_ding_price'] == 1 && $val['open_ding_pay'] == 1){
                            $outStr.= '<div class="now-price"><span class="icon">'.lang('plugin/tom_tcqianggou','yuan_ico').'</span>'.floatval($val['ding_price']).'<span class="vip-dingjing">'.lang('plugin/tom_tcqianggou','dingjing').'</span></div>';
                        }else{
                            $outStr.= '<div class="now-price flex"><span class="icon">'.lang('plugin/tom_tcqianggou','yuan_ico').'</span>'.floatval($val['show_buy_price']).'</div>';
                            if($__ShowTcyikatong == 1 && $val['open_vip'] == 1){
                                $lijianPrice = $val['show_buy_price'] - $val['show_vip_price'];
                                $lijianPrice = intval($lijianPrice);
                                if($lijianPrice > 0){
                                    $outStr.= '<div class="vip-price"><span class="vip">'.cutstr($tcyikatongConfig['card_name'], 8, '').'</span><span class="lijian-pirce">'.lang('plugin/tom_tcqianggou', 'template_ajax_lijian').$lijianPrice.lang('plugin/tom_tcqianggou','yuan').'</span></div>';
                                }
                            }
                        }
                    $outStr.= '</div>';
                    $outStr.= '<div class="item-bd__oldprice dislay-flex">';
                        $outStr.= '<div class="old-price flex">'.lang('plugin/tom_tcqianggou','yuan_ico').''.floatval($val['show_market_price']).'</div>';
                        
                        if($order_type == 'nearby' && $val['juli'] > 0){
                            $outStr.= '<div class="yiqiang">'.lang('plugin/tom_tcqianggou','template_ajax_juli').''.$val['juli'].'km</div>';
                        }else{
                            $outStr.= '<div class="yiqiang">'.lang('plugin/tom_tcqianggou','template_ajax_yiqiang').''.$val['sale_num'].'</div>';
                        }
            
                    $outStr.= '</div>';
                $outStr.= '</div>';
            $outStr.= '</a>';
        }else{
            $outStr.= '<div class="rec_area">';
                $outStr.= '<div class="rec_hd">';
                    if($val['qiang_status'] == 2){
                        if($val['start_time'] > TIMESTAMP){
                            $syTime = ($val['start_time'] - TIMESTAMP)*1000;
                            $outStr.= '<i></i>'.lang('plugin/tom_tcqianggou','template_ajax_julistart').'&nbsp;<span style="color:#FF8989;" class="daojishi" data-time="'.$syTime.'">-</span>';
                        }else{
                            $outStr.= '<i></i><span style="color:#f00;">'.lang('plugin/tom_tcqianggou','template_ajax_no_start').'</span>';
                        }
                    }else if($val['qiang_status'] == 3){
                        $outStr.= '<i></i><span style="color:#f00;">'.lang('plugin/tom_tcqianggou','template_ajax_end').'</span>';
                    }else{
                        if($val['end_time'] > TIMESTAMP){
                            $syTime = ($val['end_time'] - TIMESTAMP)*1000;
                            $outStr.= '<i></i>'.lang('plugin/tom_tcqianggou','template_ajax_julijiesu').'&nbsp;<span style="color:#FF8989;" class="daojishi" data-time="'.$syTime.'">-</span>';
                        }
                    }
                    if($order_type == 'nearby' && $val['juli'] > 0){
                        $outStr.= '<div class="guanzu">'.lang('plugin/tom_tcqianggou','template_ajax_juli').''.$val['juli'].'km</div>';
                    }else{
                        $outStr.= '<span class="guanzu"><em class="tciconfont tcicon-hot"></em>&nbsp;'.lang('plugin/tom_tcqianggou','template_ajax_clicks').''.$val['clicks'].'</span>';
                    }
                $outStr.= '</div>';

                $outStr.= '<div class="rec_bd clearfix">';
                    $outStr.= '<a href="'.$val['link'].'">';
                        $outStr.= '<div class="bd-img">';
                            $outStr.= '<img src="'.$val['picurl'].'">';
                        $outStr.= '</div>';
                    $outStr.= '</a>';
                    $outStr.= '<div class="bd-content">';
                        $outStr.= '<h5><a href="'.$val['link'].'">'.$val['title'].'</a></h5>';
                        $outStr.= '<p class="price">';
                            if($tcqianggouConfig['open_ding_price'] == 1 && $val['open_ding_pay'] == 1){
                                $outStr.= '<span class="now_price"><span>'.lang('plugin/tom_tcqianggou','yuan_ico').''.floatval($val['ding_price']).'</span>'.lang('plugin/tom_tcqianggou','dingjing').'</span>&nbsp;';
                            }else{
                                $outStr.= '<span class="now_price"><span>'.lang('plugin/tom_tcqianggou','yuan_ico').''.floatval($val['show_buy_price']).'</span></span>&nbsp;';
                                if($__ShowTcyikatong == 1 && $val['open_vip'] == 1){
                                    $outStr.= '<span class="ykt_price"><span>'.cutstr($tcyikatongConfig['card_name'], 8, '').'</span>'.lang('plugin/tom_tcqianggou','yuan_ico').floatval($val['show_vip_price']).'</span>&nbsp;';
                                }
                            }
                            $outStr.= '<span class="old_price">'.lang('plugin/tom_tcqianggou','yuan_ico').''.floatval($val['show_market_price']).'</span>';
                        $outStr.= '</p>';
                        if($val['qiang_status'] == 1 || $val['qiang_status'] == 2){
                            $outStr.= '<p class="process">';
                                $process_ts = ($val['sale_num']/$val['stock_num'])*100;
                                $process_ts = ceil($process_ts);
                                $outStr.= '<span class="bottom"><span style="width:'.$process_ts.'%;"></span></span>';
                                $outStr.= '<span class="process_ts" >'.lang('plugin/tom_tcqianggou','template_ajax_yiqiang').''.$process_ts.'%</span>';
                            $outStr.= '</p>';
                        }
                        if($val['qiang_status'] == 1){
                            $outStr.= '<div class="button"><a href="'.$val['link'].'">'.lang('plugin/tom_tcqianggou','template_ajax_qiang_btn').'</a></div>';
                        }else if($val['qiang_status'] == 2){
                            $outStr.= '<div class="button" style="background: #dadada;"><a href="javascript:;" >'.lang('plugin/tom_tcqianggou','template_ajax_no_start').'</a></div>';
                        }else if($val['qiang_status'] == 3){
                            $outStr.= '<div class="button" style="background: #dadada;"><a href="javascript:;" >'.lang('plugin/tom_tcqianggou','template_ajax_end').'</a></div>';
                        }

                    $outStr.= '</div>';
                $outStr.= '</div>';
            $outStr.= '</div>';
        }
    }
}else{
    $outStr = '205';
}
$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;