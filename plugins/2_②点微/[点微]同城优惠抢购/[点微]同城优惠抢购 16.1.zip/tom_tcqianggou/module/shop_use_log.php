<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id       = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);

$tcshopIdsListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(" AND user_id = {$__UserInfo['id']} ", 'ORDER BY id DESC', 0, 500);
$tcshopIdsStr = 0;
if(is_array($tcshopIdsListTmp) && !empty($tcshopIdsListTmp)){
    $tcshopIdsList = array();
    foreach($tcshopIdsListTmp as $key => $value){
        $tcshopIdsList[] = $value['id'];
    }
    $tcshopIdsStr = implode(',', $tcshopIdsList);
}

$goodsShopIdsListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->fetch_all_ids(" AND goods_id = {$goods_id} AND tcshop_id IN({$tcshopIdsStr}) ");
$goodsShopIdsStr = 0;
if(is_array($goodsShopIdsListTmp) && !empty($goodsShopIdsListTmp)){
    $goodsShopIdsList = array();
    foreach($goodsShopIdsListTmp as $key => $value){
        $goodsShopIdsList[] = $value['id'];
    }
    $goodsShopIdsStr = implode(',', $goodsShopIdsList);
}

if(!empty($goodsShopIdsList)){
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");exit;
}

$pagesize   = 10;
$start      = ($page - 1)*$pagesize;
$count = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_all_count(" AND goods_shop_id IN({$goodsShopIdsStr}) ");
$useLogListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_all_list(" AND goods_shop_id IN({$goodsShopIdsStr}) ", 'ORDER BY id DESC', $start, $pagesize);
$useLogList = array();
if(is_array($useLogListTmp) && !empty($useLogListTmp)){
    foreach($useLogListTmp as $key => $value){
        $useLogList[$key] = $value;
        $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $hexiaoUserInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['hexiao_user_id']);
        $goodsShopInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->fetch_by_id($value['goods_shop_id']);

        $useLogList[$key]['userInfo'] = $userInfoTmp;
        $useLogList[$key]['hexiaoUserInfo'] = $hexiaoUserInfoTmp;
        $useLogList[$key]['goodsShopInfo'] = $goodsShopInfoTmp;
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=shop_use_log&goods_id={$goods_id}&goods_shop_id={$goods_shop_id}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=shop_use_log&goods_id={$goods_id}&goods_shop_id={$goods_shop_id}&page={$nextPage}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:shop_use_log");