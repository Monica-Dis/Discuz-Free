<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$hexiao_code      = !empty($_GET['hexiao_code'])? addslashes($_GET['hexiao_code']):'';

$orderInfo = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_by_hexiao_code($hexiao_code);
$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($orderInfo['goods_id']);

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
if($tcshopInfo['hexiao_type'] > 0){
    $tcqianggouConfig['hexiao_type'] = $tcshopInfo['hexiao_type'];
}

if($_GET['act'] == 'hexiao' && $_GET['formhash'] == FORMHASH){

    $hexiao_pwd = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $hexiao_num = intval($_GET['num'])>0 ? intval($_GET['num']):1;

    if($tcqianggouConfig['hexiao_type'] == 2){
        if(empty($goodsInfo['hexiao_pwd'])){
            echo 301;exit;
        }
        if($goodsInfo['hexiao_pwd'] != $hexiao_pwd){
            echo 302;exit;
        }
    }

    $hexiaoStatus = 1;
    if($goodsInfo['peisong_type'] == 1){
        $syUseNum = $orderInfo['goods_num'] - $orderInfo['use_num'];

        if($hexiao_num > $syUseNum){
            echo 303;exit;
        }

        if($syUseNum > $hexiao_num){
            $hexiaoStatus = 2;
        }

        if($syUseNum == $hexiao_num){
            $hexiaoStatus = 3;
        }
    }

    $insertData = array();
    $insertData['order_id']         = $orderInfo['id'];
    $insertData['user_id']          = $orderInfo['user_id'];
    $insertData['use_num']          = $hexiao_num;
    $insertData['hexiao_user_id']   = $__UserInfo['id'];
    $insertData['hexiao_time']      = TIMESTAMP;
    C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->insert($insertData);

    $updateData = array();
    if($hexiaoStatus == 2){
        $updateData['use_num']          = $orderInfo['use_num'] + $hexiao_num;
    }else{
        $updateData['use_num']          = $orderInfo['goods_num'];
        $updateData['order_status']     = 3;
        $updateData['hexiao_user_id']   = $__UserInfo['id'];
        $updateData['hexiao_time']      = TIMESTAMP;
    }
    C::t('#tom_tcqianggou#tom_tcqianggou_order')->update($orderInfo['id'],$updateData);

    if($__ShowTcyuyue == 1 && $orderInfo['tcyuyue_log_id'] > 0){
        $updateData = array();
        $updateData['yuyue_status']     = 2;
        $updateData['hexiao_user_id']   = $__UserInfo['id'];
        $updateData['hexiao_time']      = TIMESTAMP;
        C::t('#tom_tcyuyue#tom_tcyuyue_log')->update($orderInfo['tcyuyue_log_id'],$updateData);
    }
    
    if($orderInfo['balance_status'] == 0 && ($goodsInfo['goods_balance_type'] == 1 || $goodsInfo['goods_balance_type'] == 3)){
        $goods_balance_rukou = 2;
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/module/balance.php';
    }

    echo 200;exit;

}

if($orderInfo && $orderInfo['goods_id'] > 0){
    
    if($goodsInfo['hasoption'] == 1 && $orderInfo['option_id'] > 0){
        $optionInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($orderInfo['option_id']);
        if(is_array($optionInfo) && !empty($optionInfo) && $optionInfo['id'] > 0){
            $goodsInfo['buy_price']      = $optionInfo['buy_price'];
            $goodsInfo['vip_price']      = $optionInfo['vip_price'];
            $goodsInfo['before_price']   = $optionInfo['before_price'];
        }
    }

    $ding_shenyu_price  = 0;
    $ding_price_status  = 0;
    if($goodsInfo['type_id'] == 1){
        if($tcqianggouConfig['open_ding_price'] == 1 && $goodsInfo['open_ding_pay'] == 1){
            $ding_price_status = 1;
            if($orderInfo['vip_pay_status'] == 1){
                $ding_shenyu_price = $goodsInfo['vip_price']*$orderInfo['goods_num'] - $orderInfo['pay_price'];
            }else if($orderInfo['before_pay_status'] == 1){
                $ding_shenyu_price = $goodsInfo['before_price']*$orderInfo['goods_num']  - $orderInfo['pay_price'];
            }else{
                $ding_shenyu_price = $goodsInfo['buy_price']*$orderInfo['goods_num'] - $orderInfo['pay_price'];
            }
        }
    }

    $allowHexiao = 1;
    $clerkListTmp  = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(" AND tcshop_id={$orderInfo['tcshop_id']} AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,1);
    if(!empty($clerkListTmp[0]['id']) || $tcshopInfo['user_id'] == $__UserInfo['id'] ){
        $allowHexiao = 1;
    }else if($tcqianggouConfig['hexiao_type'] == 1){
        $allowHexiao = 2;
    }

    if(!preg_match('/^http/', $goodsInfo['picurl']) ){
        if(strpos($goodsInfo['picurl'], 'source/plugin/tom_') === FALSE){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['picurl'];
        }else{
            $picurl = $goodsInfo['picurl'];
        }
    }else{
        $picurl = $goodsInfo['picurl'];
    }

    $hexiaoTimeStatus = 1;
    if(TIMESTAMP > $goodsInfo['hexiao_time']){
        $hexiaoTimeStatus = 2;
    }

    $hexiaoUserInfo = array();
    if($orderInfo['order_status'] == 3){
        $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']); 
    }

    $syUseNum = $orderInfo['goods_num'] - $orderInfo['use_num'];

    $useLogListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 100);
    $useLogList = array();
    if(is_array($useLogListTmp) && !empty($useLogListTmp)){
        foreach($useLogListTmp as $key => $value){
            $useLogList[$key] = $value;
        }
    }
    $useLogCount = count($useLogList);

}

$searchUrl = 'plugin.php?id=tom_tcqianggou:ajax&site='.$site_id.'&act=get_hexiao_search_url';
$hexiaoUrl = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=orderhexiao&act=hexiao';

$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=orderhexiao";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:orderhexiao");