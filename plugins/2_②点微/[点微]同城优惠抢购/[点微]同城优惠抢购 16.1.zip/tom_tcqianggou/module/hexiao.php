<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_no      = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';

$orderInfo = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_by_order_no($order_no);

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($orderInfo['goods_id']);

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);

$tcshopUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfo['user_id']); 

if($orderInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'qianshou' && $_GET['formhash'] == FORMHASH){

    if($orderInfo['peisong_type'] == 2 || $orderInfo['peisong_type'] == 3){}else{
        echo 500;exit;
    }
    if($orderInfo['peisong_status'] == 1){}else{
        echo 500;exit;
    }
    $updateData = array();
    $updateData['use_num']          = $orderInfo['goods_num'];
    $updateData['order_status']     = 3;
    $updateData['peisong_status']   = 2;
    $updateData['hexiao_user_id']   = $__UserInfo['id'];
    $updateData['hexiao_time']      = TIMESTAMP;
    C::t('#tom_tcqianggou#tom_tcqianggou_order')->update($orderInfo['id'],$updateData);

    if($orderInfo['balance_status'] == 0 && ($goodsInfo['goods_balance_type'] == 1 || $goodsInfo['goods_balance_type'] == 3)){
        $hexiaoStatus = 1;
        $goods_balance_rukou = 2;
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/module/balance.php';
    }

    echo 200;exit;

}else if($_GET['act'] == 'code' && $_GET['formhash'] == FORMHASH){

    $code_id = intval($_GET['code_id'])>0 ? intval($_GET['code_id']):0;

    $codeInfo = C::t('#tom_tcqianggou#tom_tcqianggou_code')->fetch_by_id($code_id);

    if($codeInfo['id'] > 0){}else{
        echo 500;exit;
    }

    if($codeInfo['order_id'] != $orderInfo['id'] || $codeInfo['code_status'] != 2){
        echo 500;exit;
    }

    $hexiaoStatus   = 1;
    $hexiao_num     = 1;
    $syUseNum       = $orderInfo['goods_num'] - $orderInfo['use_num'];

    if($hexiao_num > $syUseNum){
        echo 303;exit;
    }

    if($syUseNum > $hexiao_num){
        $hexiaoStatus = 2;
    }

    if($syUseNum == $hexiao_num){
        $hexiaoStatus = 3;
    }

    $insertData = array();
    $insertData['order_id']         = $orderInfo['id'];
    $insertData['user_id']          = $orderInfo['user_id'];
    $insertData['use_num']          = $hexiao_num;
    $insertData['hexiao_user_id']   = $__UserInfo['id'];
    $insertData['hexiao_time']      = TIMESTAMP;
    C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->insert($insertData);

    $updateData = array();
    if($hexiaoStatus == 2){
        $updateData['use_num']          = $orderInfo['use_num'] + $hexiao_num;
    }else{
        $updateData['use_num']          = $orderInfo['goods_num'];
        $updateData['order_status']     = 3;
        $updateData['hexiao_user_id']   = $__UserInfo['id'];
        $updateData['hexiao_time']      = TIMESTAMP;
    }
    C::t('#tom_tcqianggou#tom_tcqianggou_order')->update($orderInfo['id'],$updateData);

    $updateData = array();
    $updateData['code_status']      = 3;
    $updateData['use_time']         = TIMESTAMP;
    C::t('#tom_tcqianggou#tom_tcqianggou_code')->update($codeInfo['id'],$updateData);

    if($orderInfo['balance_status'] == 0 && ($goodsInfo['goods_balance_type'] == 1 || $goodsInfo['goods_balance_type'] == 3)){
        $goods_balance_rukou = 2;
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/module/balance.php';
    }

    echo 200;exit;

}else if($_GET['act'] == 'refund' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    if($orderInfo['shenqing_refund'] == 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    if($orderInfo['order_status'] == 2 && $orderInfo['use_num'] == 0){
    }else{
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }

    $shenqing_refund_msg        = isset($_GET['shenqing_refund_msg'])? addslashes($_GET['shenqing_refund_msg']):'';

    $updateData = array();
    $updateData['shenqing_refund']     = 1;
    $updateData['shenqing_refund_msg']   = $shenqing_refund_msg;
    C::t('#tom_tcqianggou#tom_tcqianggou_order')->update($orderInfo['id'],$updateData);

    $toUser = array();
    $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
    if($toUserTmp && !empty($toUserTmp['openid'])){
        $toUser = $toUserTmp;
    }

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($toUser['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");
        $smsData = array(
            'first'         => lang('plugin/tom_tcqianggou','shenhe_template_refund_first'),
            'keyword1'      => $tongchengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
    }
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcshopUserInfo['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=&mod=orderinfo&order_no=".$order_no);
        $smsData = array(
            'first'         => '['.$tcshopInfo['name'].']'.lang('plugin/tom_tcqianggou','shenhe_template_refund_first'),
            'keyword1'      => $tongchengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($tcshopUserInfo['openid'],$tongchengConfig['template_id'],$smsData);
    }

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}

if(!preg_match('/^http/', $goodsInfo['picurl']) ){
    if(strpos($goodsInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['picurl'];
    }else{
        $picurl = $goodsInfo['picurl'];
    }
}else{
    $picurl = $goodsInfo['picurl'];
}

if($goodsInfo['hasoption'] == 1 && $orderInfo['option_id'] > 0){
    $optionInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($orderInfo['option_id']);
    if(is_array($optionInfo) && !empty($optionInfo) && $optionInfo['id'] > 0){
        $goodsInfo['buy_price']      = $optionInfo['buy_price'];
        $goodsInfo['vip_price']      = $optionInfo['vip_price'];
        $goodsInfo['before_price']   = $optionInfo['before_price'];
    }
}

$ding_shenyu_price  = 0;
$ding_price_status  = 0;
if($goodsInfo['type_id'] == 1){
    if($tcqianggouConfig['open_ding_price'] == 1 && $goodsInfo['open_ding_pay'] == 1){
        $ding_price_status = 1;
        if($orderInfo['vip_pay_status'] == 1){
            $ding_shenyu_price = $goodsInfo['vip_price']*$orderInfo['goods_num'] - $orderInfo['pay_price'];
        }else if($orderInfo['before_pay_status'] == 1){
            $ding_shenyu_price = $goodsInfo['before_price']*$orderInfo['goods_num']  - $orderInfo['pay_price'];
        }else{
            $ding_shenyu_price = $goodsInfo['buy_price']*$orderInfo['goods_num'] - $orderInfo['pay_price'];
        }
    }
}

if($orderInfo['order_status'] == 3){
    $useNum = $orderInfo['goods_num'];
}else{
    $useNum = $orderInfo['use_num'];
}

$qrcodeImg = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=orderhexiao&hexiao_code={$orderInfo['hexiao_code']}");

$arr = strval($orderInfo['hexiao_code']);
if($orderInfo['hexiao_code'] > 10101000){
    $hexiao_code_str = $arr[0].$arr[1].$arr[2]." ".$arr[3].$arr[4].$arr[5]." ".$arr[6].$arr[7].$arr[8]." ".$arr[9].$arr[10].$arr[11];
}else{
    $hexiao_code_str = $arr[0].$arr[1].$arr[2]." ".$arr[3].$arr[4].$arr[5]." ".$arr[6].$arr[7].$arr[8];
}

$codeList = array();
if($orderInfo['code_order'] == 1){
    $codeListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_code')->fetch_all_list(" AND goods_id={$orderInfo['goods_id']} AND order_id={$orderInfo['id']} AND code_status IN(2,3) "," ORDER BY id DESC ",0,100);
    $i = 1;
    if(is_array($codeListTmp) && !empty($codeListTmp)){
        foreach ($codeListTmp as $key => $value){
            $codeList[$key] = $value;
            $codeList[$key]['i'] = $i;
            if($value['code_status'] == 2){
                $codeList[$key]['code_value'] = substr($value['code_value'], 0, 4)."****";
            }
            $i++;
        }
    }
}

$content = stripslashes($goodsInfo['content']);
$code_help_msg = stripslashes($goodsInfo['code_help_msg']);
$hexiao_start_time = dgmdate($goodsInfo['hexiao_start_time'],'Y'.lang("plugin/tom_tcqianggou", "year").'m'.lang("plugin/tom_tcqianggou", "month").'d'.lang("plugin/tom_tcqianggou", "day"),$tomSysOffset);
$hexiao_time = dgmdate($goodsInfo['hexiao_time'],'Y'.lang("plugin/tom_tcqianggou", "year").'m'.lang("plugin/tom_tcqianggou", "month").'d'.lang("plugin/tom_tcqianggou", "day"),$tomSysOffset);

if($goodsInfo['open_hexiao_valid'] == 1){
    $hexiao_valid_time = $orderInfo['pay_time'] + $goodsInfo['hexiao_valid_days'] * 86400;
    $hexiao_valid_time = dgmdate($hexiao_valid_time,'Y'.lang("plugin/tom_tcqianggou", "year").'m'.lang("plugin/tom_tcqianggou", "month").'d'.lang("plugin/tom_tcqianggou", "day").' H'.lang("plugin/tom_tcqianggou", "hour").'i'.lang("plugin/tom_tcqianggou", "minute"),$tomSysOffset);
}

$hexiaoTimeStatus = 1;
if($goodsInfo['open_hexiao_valid'] == 1){
    if(TIMESTAMP > ($orderInfo['pay_time'] + $goodsInfo['hexiao_valid_days'] * 86400)){
        $hexiaoTimeStatus = 2;
    }
}else{
    if(TIMESTAMP > $goodsInfo['hexiao_time']){
        $hexiaoTimeStatus = 2;
    }
    if($goodsInfo['hexiao_start_time'] > 0 && $goodsInfo['hexiao_start_time'] > TIMESTAMP){
        $hexiaoTimeStatus = 3;
    }
}

$showChoujiang = 0;
if($__ShowTcchoujiang == 1 && $goodsInfo['tcchoujiang_id'] > 0){
    $choujiangBmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($goodsInfo['tcchoujiang_id'],$__UserInfo['id']);
    if($choujiangBmInfo['id'] > 0 && $choujiangBmInfo['cj_times'] > 0){
        $showChoujiang = 1;
    }
}

if($orderInfo['peisong_type'] == 3){
    $kuaidiSmsList = array();
    if(!empty($orderInfo['kuaidi_no']) && !empty($orderInfo['kuaidi_type']) && $__ShowKuaidi == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_kuaidi/kuaidi.func.php';
        $kuaidiNoArr = explode(' ', $orderInfo['kuaidi_no']);
        if(is_array($kuaidiNoArr) && !empty($kuaidiNoArr)){
            foreach($kuaidiNoArr as $key => $value){
                $value = trim($value);
                if(!empty($value)){
                    $kuaidiArr = query_kuaidi($value, $orderInfo['kuaidi_type']);
                    if($kuaidiArr){
                        $kuaidiSmsList[$key] = $kuaidiArr;
                        $kuaidiSmsList[$key]['kuaidi_no'] = $value;
                    }
                }
            }
        }
    }
}

$back_url = $weixinClass->get_url();

$tcyuyueStatus = 0;
if($__ShowTcyuyue == 1 && $orderInfo['order_status'] == 2 && $orderInfo['peisong_type'] == 1 && $goodsInfo['open_yuyue'] == 1 && ($goodsInfo['yuyue_type'] == 2 || $goodsInfo['yuyue_type'] == 3) && $goodsInfo['tcyuyue_id'] > 0){
    $tcyuyueStatus = 1;
    $hexiaoTimeStatus = 3;
    
    $tcyuyueUrl = "plugin.php?id=tom_tcyuyue&site_id={$site_id}&mod=info&order_no={$orderInfo['order_no']}&yuyue_type=qianggou&buy_status=2&back_url=".urlencode($back_url);
    
    $updateYuyueStatusUrl = 'plugin.php?id=tom_tcyuyue:ajax&site='.$site_id.'&act=update_yuyue_status&formhash='.$formhash;
    
    if($orderInfo['tcyuyue_log_id'] > 0){
        
        $tcyuyueLogInfo = C::t("#tom_tcyuyue#tom_tcyuyue_log")->fetch_by_id($orderInfo['tcyuyue_log_id']);
        if($tcyuyueLogInfo && ($tcyuyueLogInfo['yuyue_status'] == 1 || $tcyuyueLogInfo['yuyue_status'] == 3)){
            $tcyuyueStatus = 2;
            $tcyuyueInfo = C::t("#tom_tcyuyue#tom_tcyuyue")->fetch_by_id($tcyuyueLogInfo['tcyuyue_id']);
            
            $tcyuyueEditUrl = "plugin.php?id=tom_tcyuyue&site_id={$site_id}&mod=info&order_no={$orderInfo['order_no']}&tcyuyue_log_id={$orderInfo['tcyuyue_log_id']}&yuyue_type=qianggou&buy_status=2&back_url=".urlencode($back_url);

            $tcyuyueLogInfo['yuyue_start_time'] = $tcyuyueLogInfo['time_start_stamp'] + $tcyuyueLogInfo['yuyue_daytime'];
            $tcyuyueLogInfo['yuyue_end_time'] = $tcyuyueLogInfo['time_end_stamp'] + $tcyuyueLogInfo['yuyue_daytime'];
            if(TIMESTAMP >= $tcyuyueLogInfo['yuyue_start_time'] && TIMESTAMP < $tcyuyueLogInfo['yuyue_end_time']){
                $tcyuyueStatus = 3;
                $hexiaoTimeStatus = 1;
            }
            $tcyuyueLogInfo['start_time']         = dgmdate($tcyuyueLogInfo['yuyue_start_time'],"Y-m-d H:i",$tomSysOffset);
            $tcyuyueLogInfo['end_time']           = dgmdate($tcyuyueLogInfo['yuyue_end_time'],"H:i",$tomSysOffset);
            if($tcyuyueLogInfo['clerk_id'] > 0){
                $clerkInfo = C::t('#tom_tcyuyue#tom_tcyuyue_clerk')->fetch_by_id($tcyuyueLogInfo['clerk_id']);
                if(!preg_match('/^http/', $clerkInfo['picurl']) ){
                    if(strpos($clerkInfo['picurl'], 'source/plugin/tom_') === FALSE){
                        $clerkInfo['picurl'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$clerkInfo['picurl'];
                    }else{
                        $clerkInfo['picurl'] = $_G['siteurl'].$clerkInfo['picurl'];
                    }
                }else{
                    $clerkInfo['picurl'] = $clerkInfo['picurl'];
                }
            }
            $attrListTmp = C::t('#tom_tcyuyue#tom_tcyuyue_log_attr')->fetch_all_list(" AND tcyuyue_log_id = {$tcyuyueLogInfo['id']} ", " ORDER BY paixu ASC,id DESC ");
            $yuyueAttrList = array();
            if(is_array($attrListTmp) && !empty($attrListTmp)){
                foreach($attrListTmp as $k => $v){
                    $yuyueAttrList[$k] = $v;
                    if($v['attr_type'] == 4){
                        $yuyueAttrList[$k]['valueList'] = explode('|', $v['value']);
                    }
                }
            }
        }
    }
}

$qianshouUrl = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=hexiao&act=qianshou&formhash='.$formhash;
$codeUrl = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=hexiao&act=code&formhash='.$formhash;
$refundUrl = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=hexiao&act=refund';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:hexiao");