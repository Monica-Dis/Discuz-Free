<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);

if($__UserInfo['id'] != $tcshopInfo['user_id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $trade_id           = isset($_GET['trade_id'])? intval($_GET['trade_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $xiangou_num        = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $xuzhi              = isset($_GET['xuzhi'])? addslashes($_GET['xuzhi']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    $market_price       = isset($_GET['market_price'])? addslashes($_GET['market_price']):'';
    $buy_price          = isset($_GET['buy_price'])? addslashes($_GET['buy_price']):'';
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? addslashes($_GET['ding_price']):'';
    $coupon_price       = isset($_GET['coupon_price'])? addslashes($_GET['coupon_price']):'';
    $coupon_limit       = isset($_GET['coupon_limit'])? addslashes($_GET['coupon_limit']):'';
    $coupon_zhekou      = isset($_GET['coupon_zhekou'])? addslashes($_GET['coupon_zhekou']):'';
    $coupon_is_buy      = isset($_GET['coupon_is_buy'])? intval($_GET['coupon_is_buy']):0;
    $coupon_buy_price   = isset($_GET['coupon_buy_price'])? addslashes($_GET['coupon_buy_price']):'';
    $coupon_msg         = isset($_GET['coupon_msg'])? addslashes($_GET['coupon_msg']):'';
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = str_replace("T", " ", $start_time);
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = str_replace("T", " ", $end_time);
    $end_time           = strtotime($end_time);
    $hexiao_start_time        = isset($_GET['hexiao_start_time'])? addslashes($_GET['hexiao_start_time']):'';
    $hexiao_start_time        = str_replace("T", " ", $hexiao_start_time);
    $hexiao_start_time        = strtotime($hexiao_start_time);
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = str_replace("T", " ", $hexiao_time);
    $hexiao_time        = strtotime($hexiao_time);
    $open_hexiao_valid  = isset($_GET['open_hexiao_valid'])? intval($_GET['open_hexiao_valid']):0;
    $hexiao_valid_days  = isset($_GET['hexiao_valid_days'])? intval($_GET['hexiao_valid_days']):0;
    $open_score_dikou   = isset($_GET['open_score_dikou'])? intval($_GET['open_score_dikou']):0;
    $score_num          = isset($_GET['score_num'])? intval($_GET['score_num']):0;
    $score_dikou_price  = isset($_GET['score_dikou_price'])? floatval($_GET['score_dikou_price']):0.00;
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    
    $peisong_type    = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $open_yuyue      = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $yuyue_xm        = isset($_GET['yuyue_xm'])? addslashes($_GET['yuyue_xm']):'';
    $yuyue_tel       = isset($_GET['yuyue_tel'])? addslashes($_GET['yuyue_tel']):'';
    $yuyue_type      = isset($_GET['yuyue_type'])? intval($_GET['yuyue_type']):1;
    $tcyuyue_id      = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
    
    $allow_refund    = isset($_GET['allow_refund'])? intval($_GET['allow_refund']):0;
    $mp3_link        = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $share_title     = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc      = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $updateData = array();
    $updateData['cate_id']        = $cate_id;
    $updateData['trade_id']       = $trade_id;
    $updateData['title']          = $title;
    if($goodsInfo['admin_edit'] == 0){
        $updateData['xuzhi']          = dhtmlspecialchars($xuzhi);
        $updateData['content']        = dhtmlspecialchars($content);
    }
    $updateData['hasoption']      = $hasoption;
    $updateData['xiangou_num']    = $xiangou_num;
    $updateData['picurl']         = $picurl;
    $updateData['toppic']         = $toppic;
    $updateData['market_price']   = $market_price;
    $updateData['buy_price']      = $buy_price;
    $updateData['open_ding_pay']  = $open_ding_pay;
    $updateData['ding_price']     = $ding_price;
    $updateData['coupon_price']   = $coupon_price;
    $updateData['coupon_limit']   = $coupon_limit;
    $updateData['coupon_zhekou']  = $coupon_zhekou;
    $updateData['coupon_is_buy']  = $coupon_is_buy;
    $updateData['coupon_buy_price']  = $coupon_buy_price;
    $updateData['coupon_msg']     = $coupon_msg;
    
    $updateData['peisong_type']   = $peisong_type;
    $updateData['open_yuyue']     = $open_yuyue;
    $updateData['yuyue_xm']       = $yuyue_xm;
    $updateData['yuyue_tel']      = $yuyue_tel;
    $updateData['yuyue_type']     = $yuyue_type;
    $updateData['tcyuyue_id']     = $tcyuyue_id;
    $updateData['start_time']     = $start_time;
    $updateData['end_time']       = $end_time;
    
    $updateData['hexiao_start_time']    = $hexiao_start_time;
    $updateData['hexiao_time']          = $hexiao_time;
    $updateData['open_hexiao_valid']    = $open_hexiao_valid;
    $updateData['hexiao_valid_days']    = $hexiao_valid_days;
    $updateData['open_score_dikou']     = $open_score_dikou;
    $updateData['score_num']            = $score_num;
    $updateData['score_dikou_price']    = $score_dikou_price;
    $updateData['allow_refund']         = $allow_refund;
    $updateData['mp3_link']             = $mp3_link;
    $updateData['share_title']          = $share_title;
    $updateData['share_desc']           = $share_desc;
    if($hasoption == 0){
        $updateData['show_market_price'] = $market_price;
        $updateData['show_buy_price']    = $buy_price;
    }
    $updateData['part1']          = TIMESTAMP;
    if(C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($goods_id,$updateData)){
        
        $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
        update_qiang_status($goodsInfoTmp);
        
        C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->delete_by_goods_id($goods_id);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id'] = $goods_id;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->insert($insertData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
            'goods_id'=> $goods_id,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}

if(!preg_match('/^http/', $goodsInfo['picurl']) ){
    if(strpos($goodsInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['picurl'];
    }else{
        $picurl = $goodsInfo['picurl'];
    }
}else{
    $picurl = $goodsInfo['picurl'];
}

if(!preg_match('/^http/', $goodsInfo['toppic']) ){
    if(strpos($goodsInfo['toppic'], 'source/plugin/tom_') === FALSE){
        $toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['toppic'];
    }else{
        $toppic = $goodsInfo['toppic'];
    }
}else{
    $toppic = $goodsInfo['toppic'];
}


$goodsPhotoListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->fetch_all_list(" AND goods_id={$goodsInfo['id']} "," ORDER BY id ASC ",0,50);
$goodsPhotoList = array();
$photoCount = 0;
if(is_array($goodsPhotoListTmp) && !empty($goodsPhotoListTmp)){
    foreach ($goodsPhotoListTmp as $kk => $vv){
        $photoCount++;
        $goodsPhotoList[$kk] = $vv;
        $goodsPhotoList[$kk]['li_i'] = $photoCount;

    }
}

$start_time = '';
if($goodsInfo['start_time'] > 0){
    $start_time = dgmdate($goodsInfo['start_time'],'Y-m-d H:i:s',$tomSysOffset);
    $start_time = str_replace(" ", "T", $start_time);
}

$end_time = '';
if($goodsInfo['end_time'] > 0){
    $end_time = dgmdate($goodsInfo['end_time'],'Y-m-d H:i:s',$tomSysOffset);
    $end_time = str_replace(" ", "T", $end_time);
}

$hexiao_start_time = '';
if($goodsInfo['hexiao_start_time'] > 0){
    $hexiao_start_time = dgmdate($goodsInfo['hexiao_start_time'],'Y-m-d H:i:s',$tomSysOffset);
    $hexiao_start_time = str_replace(" ", "T", $hexiao_start_time);
}

$hexiao_time = '';
if($goodsInfo['hexiao_time'] > 0){
    $hexiao_time = dgmdate($goodsInfo['hexiao_time'],'Y-m-d H:i:s',$tomSysOffset);
    $hexiao_time = str_replace(" ", "T", $hexiao_time);
}

$cateList = C::t('#tom_tcqianggou#tom_tcqianggou_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,100);

$tradeListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_trade')->fetch_all_list(" AND site_id = {$goodsInfo['site_id']} "," ORDER BY tsort ASC,id DESC ",0,1000);
$tradeList = array();
if(!empty($tradeListTmp)){
    foreach($tradeListTmp as $key => $value){
        $tradeList[$key] = $value;
    }
}

if($__ShowTcyuyue == 1){
    $tcyuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list(" AND tcshop_id = {$tcshopInfo['id']} AND type = 2 AND status = 1 AND shenhe_status = 1 ");
    $tcyuyueList = array();
    foreach($tcyuyueListTmp as $key => $value){
        $tcyuyueList[$key] = $value;
    }
}

if($__Ios == 0 && $__Android == 0){
    $tongchengConfig['open_many_pic_upload'] = 0;
}

$ossBatchUrl = 'plugin.php?id=tom_tcqianggou:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcqianggou:qiniuBatch';
$uploadUrl1 = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2 = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=upload&act=toppic&formhash=".FORMHASH;
$uploadUrl3 = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tcqianggou:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";

$saveUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=edit&act=save";

$shareLinkUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=details&goods_id=";
$buyLinkUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=buy&goods_id=";
$myListUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=mylist&type=2";
$myListAllUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=mylist";

##

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:edit");