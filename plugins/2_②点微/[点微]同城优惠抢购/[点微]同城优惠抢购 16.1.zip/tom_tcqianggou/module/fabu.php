<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_GET['act'] == 'save' && $_GET['formhash'] == FORMHASH){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $trade_id           = isset($_GET['trade_id'])? intval($_GET['trade_id']):0;
    $type_id            = isset($_GET['type_id'])? intval($_GET['type_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $xuzhi              = isset($_GET['xuzhi'])? addslashes($_GET['xuzhi']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    $stock_num          = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
    $xiangou_num        = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $market_price       = isset($_GET['market_price'])? addslashes($_GET['market_price']):'';
    $buy_price          = isset($_GET['buy_price'])? addslashes($_GET['buy_price']):'';
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? addslashes($_GET['ding_price']):'';
    $coupon_price       = isset($_GET['coupon_price'])? addslashes($_GET['coupon_price']):'';
    $coupon_limit       = isset($_GET['coupon_limit'])? addslashes($_GET['coupon_limit']):'';
    $coupon_zhekou      = isset($_GET['coupon_zhekou'])? addslashes($_GET['coupon_zhekou']):'';
    $coupon_is_buy      = isset($_GET['coupon_is_buy'])? intval($_GET['coupon_is_buy']):0;
    $coupon_buy_price   = isset($_GET['coupon_buy_price'])? addslashes($_GET['coupon_buy_price']):'';
    $coupon_msg         = isset($_GET['coupon_msg'])? addslashes($_GET['coupon_msg']):'';
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = str_replace("T", " ", $start_time);
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = str_replace("T", " ", $end_time);
    $end_time           = strtotime($end_time);
    $hexiao_start_time  = isset($_GET['hexiao_start_time'])? addslashes($_GET['hexiao_start_time']):'';
    $hexiao_start_time  = str_replace("T", " ", $hexiao_start_time);
    $hexiao_start_time  = strtotime($hexiao_start_time);
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = str_replace("T", " ", $hexiao_time);
    $hexiao_time        = strtotime($hexiao_time);
    $open_hexiao_valid  = isset($_GET['open_hexiao_valid'])? intval($_GET['open_hexiao_valid']):0;
    $hexiao_valid_days  = isset($_GET['hexiao_valid_days'])? intval($_GET['hexiao_valid_days']):0;
    $open_score_dikou   = isset($_GET['open_score_dikou'])? intval($_GET['open_score_dikou']):0;
    $score_num          = isset($_GET['score_num'])? intval($_GET['score_num']):0;
    $score_dikou_price  = isset($_GET['score_dikou_price'])? floatval($_GET['score_dikou_price']):0.00;
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    
    $peisong_type    = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $open_yuyue      = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $yuyue_xm        = isset($_GET['yuyue_xm'])? addslashes($_GET['yuyue_xm']):'';
    $yuyue_tel       = isset($_GET['yuyue_tel'])? addslashes($_GET['yuyue_tel']):'';
    $yuyue_type      = isset($_GET['yuyue_type'])? intval($_GET['yuyue_type']):1;
    $tcyuyue_id      = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
    
    $allow_refund    = isset($_GET['allow_refund'])? intval($_GET['allow_refund']):0;
    $mp3_link        = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $share_title     = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc      = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    if($__UserInfo['id'] != $tcshopInfo['user_id']){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($coupon_is_buy == 1){
        if(empty($coupon_buy_price)){
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $insertData = array();
    $insertData['site_id']        = $tcshopInfo['site_id'];
    $insertData['latitude']       = $tcshopInfo['latitude'];
    $insertData['longitude']      = $tcshopInfo['longitude'];
    $insertData['user_id']        = $user_id;
    $insertData['cate_id']        = $cate_id;
    $insertData['tcshop_id']      = $tcshop_id;
    $insertData['trade_id']       = $trade_id;
    $insertData['type_id']        = $type_id;
    $insertData['title']          = $title;
    $insertData['xuzhi']          = $xuzhi;
    $insertData['content']        = $content;
    $insertData['hasoption']      = $hasoption;
    $insertData['stock_num']      = $stock_num;
    $insertData['xiangou_num']    = $xiangou_num;
    $insertData['picurl']         = $picurl;
    $insertData['toppic']         = $toppic;
    $insertData['market_price']   = $market_price;
    $insertData['buy_price']      = $buy_price;
    $insertData['open_ding_pay']  = $open_ding_pay;
    $insertData['ding_price']     = $ding_price;
    $insertData['coupon_price']   = $coupon_price;
    $insertData['coupon_limit']   = $coupon_limit;
    $insertData['coupon_zhekou']  = $coupon_zhekou;
    $insertData['coupon_is_buy']  = $coupon_is_buy;
    $insertData['coupon_buy_price']  = $coupon_buy_price;
    $insertData['coupon_msg']     = $coupon_msg;
    $insertData['peisong_type']   = $peisong_type;
    $insertData['open_yuyue']     = $open_yuyue;
    $insertData['yuyue_xm']       = $yuyue_xm;
    $insertData['yuyue_tel']      = $yuyue_tel;
    $insertData['yuyue_type']     = $yuyue_type;
    $insertData['tcyuyue_id']     = $tcyuyue_id;
    $insertData['start_time']     = $start_time;
    $insertData['end_time']       = $end_time;
    
    $insertData['hexiao_start_time']    = $hexiao_start_time;
    $insertData['hexiao_time']          = $hexiao_time;
    $insertData['open_hexiao_valid']    = $open_hexiao_valid;
    $insertData['open_score_dikou']     = $open_score_dikou;
    if($open_score_dikou == 1){
        $insertData['score_num']            = $score_num;
        $insertData['score_dikou_price']    = $score_dikou_price;
    }
    $insertData['hexiao_valid_days']    = $hexiao_valid_days;
    $insertData['allow_refund']         = $allow_refund;
    $insertData['mp3_link']             = $mp3_link;
    $insertData['share_title']          = $share_title;
    $insertData['share_desc']           = $share_desc;
    if($hasoption == 0){
        $insertData['show_market_price'] = $market_price;
        $insertData['show_buy_price']    = $buy_price;
    }
    $insertData['status']         = 1;
    if($tcqianggouConfig['must_shenhe'] == 1){
        $insertData['shenhe_status']       = 2;
    }else{
        $insertData['shenhe_status']       = 1;
    }
    $insertData['add_time']          = TIMESTAMP;
    if(C::t('#tom_tcqianggou#tom_tcqianggou_goods')->insert($insertData)){
        
        $goods_id = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->insert_id();
        
        $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
        update_qiang_status($goodsInfoTmp);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']  = $goods_id;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->insert($insertData);
            }
        }
        
        $insertData = array();
        $insertData['is_admin']     = 0;
        $insertData['goods_id']     = $goods_id;
        $insertData['change_num']   = $stock_num;
        $insertData['change_time']  = TIMESTAMP;
        C::t('#tom_tcqianggou#tom_tcqianggou_stock_log')->insert($insertData);
        
        if($tcqianggouConfig['must_shenhe'] == 1){
            $toUser = array();
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $toUser = $toUserTmp;
            }

            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            $access_token = $weixinClass->get_access_token();

            if($access_token && !empty($toUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");
                $smsData = array(
                    'first'         => '['.$tcshopInfo['name'].']'.lang('plugin/tom_tcqianggou','shenhe_template_first'),
                    'keyword1'      => $tongchengConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
            'goods_id'=> $goods_id,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}

$type         = isset($_GET['type'])? addslashes($_GET['type']):'qianggou';
$type_id      = intval($_GET['type_id'])>0? intval($_GET['type_id']):0;

if($type != 'kaquan' && $type != 'qianggou'){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");exit;
}

if($type == 'kaquan' && $tcqianggouConfig['open_kajuan'] == 0){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");exit;
}

if($type == 'qianggou' && $type_id == 0){
    $type_id = 1;
}else if($type == 'kaquan' && $type_id == 0){
    $type_id = 2;
}

$typeNewArray = array();
if($type == 'qianggou'){
    $typeNewArray[1] = $typeArray[1];
}else if($type == 'kaquan'){
    $typeNewArray[2] = $typeArray[2];
    $typeNewArray[3] = $typeArray[3];
    $typeNewArray[4] = $typeArray[4];
}

$allTcshopCount = C::t('#tom_tcshop#tom_tcshop')->fetch_all_count(" AND user_id={$__UserInfo['id']} ");

$tcshopList = array();
if($type == 'qianggou'){
    $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$__UserInfo['id']} AND v.open_tcqianggou=1 "," ORDER BY s.id DESC ",0,100);
}else if($type == 'kaquan'){
    $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list_by_vip(" AND s.status=1 AND s.shenhe_status=1 AND s.vip_status=1 AND s.user_id={$__UserInfo['id']} AND v.open_coupon=1 "," ORDER BY s.id DESC ",0,100);
}
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach ($tcshopListTmp as $key => $value){
        $tcshopList[$key] = $value;
    }
}
$tcshopCount = count($tcshopList);

$cateList = C::t('#tom_tcqianggou#tom_tcqianggou_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ",0,100);

$tradeListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_trade')->fetch_all_list(" AND site_id = {$site_id} "," ORDER BY tsort ASC,id DESC ",0,1000);
$tradeList = array();
if(!empty($tradeListTmp)){
    foreach($tradeListTmp as $key => $value){
        $tradeList[$key] = $value;
    }
}

$ajaxLoadYuyueUrl = 'plugin.php?id=tom_tcqianggou:ajax&site='.$site_id.'&act=load_yuyue&formhash='.$formhash;

if($__Ios == 0 && $__Android == 0){
    $tongchengConfig['open_many_pic_upload'] = 0;
}

$ossBatchUrl = 'plugin.php?id=tom_tcqianggou:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcqianggou:qiniuBatch';
$uploadUrl1 = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=upload&act=picurl&formhash=".FORMHASH;
$uploadUrl2 = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=upload&act=toppic&formhash=".FORMHASH;
$uploadUrl3 = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tcqianggou:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";

$saveUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=fabu&act=save";


if($type == 'qianggou'){
    $myListUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=myfabu&t_id=1";
}else if($type == 'kaquan'){
    $myListUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=myfabu&t_id=2";
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:fabu");