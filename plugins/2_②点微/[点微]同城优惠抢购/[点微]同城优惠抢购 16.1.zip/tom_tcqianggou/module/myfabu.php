<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$t_id       = intval($_GET['t_id'])>0? intval($_GET['t_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

$whereStr = " AND user_id = {$__UserInfo['id']} ";
$orderStr = " ORDER BY id DESC ";

if($t_id == 1){
    $whereStr.= " AND type_id = 1";
}else if($t_id == 2){
    $whereStr.= " AND (type_id = 2 OR type_id = 3 OR type_id = 4) ";
}else if($t_id == 3){
    $whereStr.= " AND (shenhe_status = 2 OR shenhe_status = 3)";
    $orderStr = " ORDER BY shenhe_status ASC, id DESC ";
}

$pagesize       = 8;
$start          = ($page - 1)*$pagesize;
$count = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_count(" {$whereStr} ");
$goodsListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);
$goodsList = array();
foreach ($goodsListTmp as $key => $value){
    $goodsList[$key] = $value;

    if(!preg_match('/^http/', $value['picurl']) ){
        if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $picurl = $value['picurl'];
        }
    }else{
        $picurl = $value['picurl'];
    }
    $goodsList[$key]['picurl'] = $picurl;

    $goodsList[$key]['hexiao_time'] = dgmdate($value['hexiao_time'],"Y-m-d",$tomSysOffset);

    if($value['type_id'] == 1){
        $goodsList[$key]['link'] = 'plugin.php?id=tom_tcqianggou&site='.$value['site_id'].'&mod=details&goods_id='.$value['id'];
    }else{
        $goodsList[$key]['link'] = 'plugin.php?id=tom_tcqianggou&site='.$value['site_id'].'&mod=coupon&goods_id='.$value['id'];
    }

    $orderCount = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(" AND goods_id = {$value['id']} AND order_status IN(2,3) ");
    $goodsList[$key]['orderCount'] = $orderCount;
    
    $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
    $goodsList[$key]['tcshopInfo'] = $tcshopInfoTmp;
    
    
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=myfabu&t_id={$t_id}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=myfabu&t_id={$t_id}&page={$nextPage}";

$ajaxUpdateStatusUrl = "plugin.php?id=tom_tcqianggou:ajax&site={$site_id}&act=updateStatus&&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:myfabu");