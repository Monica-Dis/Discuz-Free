<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);

if(!preg_match('/^http/', $goodsInfo['picurl']) ){
    if(strpos($goodsInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['picurl'];
    }else{
        $picurl = $goodsInfo['picurl'];
    }
}else{
    $picurl = $goodsInfo['picurl'];
}


$goodsInfo['qiang_status'] = update_qiang_status($goodsInfo);

$isShowRandBtn = 0;
$randSecond = rand(3, 5);
if(($goodsInfo['stock_num'] - $goodsInfo['sale_num']) <= 3){
    $isShowRandBtn = 1;
}

$xiangouStatus = 0;
if($goodsInfo['xiangou_num'] > 0){
    $myHaveOrderCount  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_goods_num(" AND goods_id={$goodsInfo['id']} AND user_id={$__UserInfo['id']} AND order_status IN(1,2,3) ");
    if($myHaveOrderCount >= $goodsInfo['xiangou_num']){
        $xiangouStatus = 1;
    }
}

$xm = $tel = "";
$userOrderTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND order_status IN(2,3) "," ORDER BY id DESC ",0,1);
if(is_array($userOrderTmp) && !empty($userOrderTmp) && !empty($userOrderTmp[0]['tel'])){
    $xm = $userOrderTmp[0]['xm'];
    $tel = $userOrderTmp[0]['tel'];
}
if(empty($tel)){
    $tel = $__UserInfo['tel'];
}

$lingUrl = "plugin.php?id=tom_tcqianggou:pay&site={$site_id}&act=pay_ling";

$showMustPhoneBtn = 0;
if($tcqianggouConfig['buy_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor']==0 && $__UserInfo['is_majia']==0){
    $showMustPhoneBtn = 1;
    $phone_back_url = $weixinClass->get_url();
    $phone_back_url = urlencode($phone_back_url);
    $phoneUrl = "plugin.php?id=tom_tongcheng&site={$site_id}&mod=phone&phone_back={$phone_back_url}";
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:ling");