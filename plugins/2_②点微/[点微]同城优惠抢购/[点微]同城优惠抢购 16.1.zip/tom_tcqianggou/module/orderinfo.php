<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_no      = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';

$orderInfo = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_by_order_no($order_no);

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($orderInfo['goods_id']);

$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);

$clerkAllowTmp  = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(" AND tcshop_id={$orderInfo['tcshop_id']} AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,1);
if(!empty($clerkAllowTmp[0]['id']) || $tcshopInfo['user_id'] == $__UserInfo['id'] ){
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'fahuo' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 1,
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $peisong_info   = isset($_GET['peisong_info'])? addslashes($_GET['peisong_info']):'';
    $kuaidi_type    = isset($_GET['kuaidi_type'])? addslashes($_GET['kuaidi_type']):'';
    $kuaidi_no      = isset($_GET['kuaidi_no'])? addslashes($_GET['kuaidi_no']):'';

    if($orderInfo['peisong_type'] == 3 && $__ShowKuaidi == 1 && !empty($kuaidi_type)){
        $kuaidiInfo = C::t("#tom_kuaidi#tom_kuaidi")->fetch_by_type($kuaidi_type);
        if(is_array($kuaidiInfo) && !empty($kuaidiInfo)){
            $peisong_info = $kuaidiInfo['name'].' '.$kuaidi_no;
        }
    }
    
    $updateData = array();
    $updateData['peisong_info']     = $peisong_info;
    if($orderInfo['peisong_type'] == 3){
        $updateData['kuaidi_type']      = $kuaidi_type;
        $updateData['kuaidi_no']        = $kuaidi_no;
    }
    $updateData['peisong_status']   = 1;
    $updateData['peisong_time']     = TIMESTAMP;
    C::t('#tom_tcqianggou#tom_tcqianggou_order')->update($orderInfo['id'],$updateData);

    if(!empty($tcqianggouConfig['template_fahuo'])){

        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();

        $orderUserInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 

        if($access_token && !empty($orderUserInfoTmp['openid']) ){
            $templateSmsClass = new qgTemplateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=hexiao&order_no={$order_no}");
            $smsData = array(
                'first'         => lang('plugin/tom_tcqianggou','template_fahuo_first'),
                'keyword1'      => $orderInfo['order_no'],
                'keyword2'      => $orderInfo['goods_title'],
                'keyword3'      => $orderInfo['goods_num'],
                'keyword4'      => $orderInfo['pay_price'],
                'remark'        => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset)
            );
            $r = $templateSmsClass->sendSmsFahuo($orderUserInfoTmp['openid'],$tcqianggouConfig['template_fahuo'],$smsData);
        }
    }

    $outArr = array(
        'code'=> 200,
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($_GET['act'] == 'qianshou' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
        'status'=> 1,
    );

    if($orderInfo['peisong_status'] == 1){}else{
        echo 500;exit;
    }
    $updateData = array();
    $updateData['use_num']          = $orderInfo['goods_num'];
    $updateData['order_status']     = 3;
    $updateData['peisong_status']   = 2;
    $updateData['hexiao_user_id']   = $__UserInfo['id'];
    $updateData['hexiao_time']      = TIMESTAMP;
    C::t('#tom_tcqianggou#tom_tcqianggou_order')->update($orderInfo['id'],$updateData);

    if($orderInfo['balance_status'] == 0 && ($goodsInfo['goods_balance_type'] == 1 || $goodsInfo['goods_balance_type'] == 3)){
        $hexiaoStatus = 1;
        $goods_balance_rukou = 2;
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/module/balance.php';
    }

    $outArr = array(
        'code'=> 200,
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
}

if(!preg_match('/^http/', $goodsInfo['picurl']) ){
    if(strpos($goodsInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['picurl'];
    }else{
        $picurl = $goodsInfo['picurl'];
    }
}else{
    $picurl = $goodsInfo['picurl'];
}

$hexiaoTimeStatus = 1;
if(TIMESTAMP > $goodsInfo['hexiao_time']){
    $hexiaoTimeStatus = 2;
}

$hexiaoUserInfo = array();
if($orderInfo['order_status'] == 3){
    $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']); 
}

$allowQianshou = 0;
if($orderInfo['peisong_status'] == 1 && $orderInfo['peisong_time'] > 0){
    if(TIMESTAMP > ($orderInfo['peisong_time'] + 86400*$tcqianggouConfig['shop_qianshou_days'])){
        $allowQianshou = 1;
    }
}

$useLogListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_all_list(" AND order_id = {$orderInfo['id']} ", 'ORDER BY id DESC', 0, 100);
$useLogList = array();
if(is_array($useLogListTmp) && !empty($useLogListTmp)){
    foreach($useLogListTmp as $key => $value){
        $useLogList[$key] = $value;
    }
}
$useLogCount = count($useLogList);

$kuaidiList = array();
if($orderInfo['peisong_type'] == 3 && $__ShowKuaidi == 1){
    $kuaidiListTmp = C::t("#tom_kuaidi#tom_kuaidi")->fetch_all_list(" ", 'ORDER BY sort ASC, id DESC');
    if(is_array($kuaidiListTmp) && !empty($kuaidiListTmp)){
        foreach($kuaidiListTmp as $key => $value){
            $kuaidiList[$key] = $value;
        }
    }
}

$showPeisongBox = 1;
if($orderInfo['peisong_type'] == 3){
    if($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList) && empty($orderInfo['peisong_info'])){
        $showPeisongBox = 2;
    }
    if($__ShowKuaidi == 1 && is_array($kuaidiList) && !empty($kuaidiList) && !empty($orderInfo['kuaidi_no']) && !empty($orderInfo['kuaidi_type'])){
        $showPeisongBox = 2;
    }
    
    $kuaidiSmsList = array();
    if(!empty($orderInfo['kuaidi_no']) && !empty($orderInfo['kuaidi_type']) && $__ShowKuaidi == 1){
        include DISCUZ_ROOT.'./source/plugin/tom_kuaidi/kuaidi.func.php';
        $kuaidiNoArr = explode(' ', $orderInfo['kuaidi_no']);
        if(is_array($kuaidiNoArr) && !empty($kuaidiNoArr)){
            foreach($kuaidiNoArr as $key => $value){
                $value = trim($value);
                if(!empty($value)){
                    $kuaidiArr = query_kuaidi($value, $orderInfo['kuaidi_type']);
                    if($kuaidiArr){
                        $kuaidiSmsList[$key] = $kuaidiArr;
                        $kuaidiSmsList[$key]['kuaidi_no'] = $value;
                    }
                }
            }
        }
    }
}

$fahuoUrl = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=orderinfo&act=fahuo&formhash='.$formhash;
$qianshouUrl = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=orderinfo&act=qianshou&formhash='.$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:orderinfo");