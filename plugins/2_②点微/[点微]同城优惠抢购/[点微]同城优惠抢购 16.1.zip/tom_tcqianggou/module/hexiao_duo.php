<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_no = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';

$orderInfo = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_by_order_no($order_no);

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($orderInfo['goods_id']);

if($orderInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'refund' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    if($orderInfo['shenqing_refund'] == 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    if($orderInfo['order_status'] == 2 && $orderInfo['use_num'] == 0){
    }else{
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }

    $shenqing_refund_msg        = isset($_GET['shenqing_refund_msg'])? addslashes($_GET['shenqing_refund_msg']):'';

    $updateData = array();
    $updateData['shenqing_refund']     = 1;
    $updateData['shenqing_refund_msg']   = $shenqing_refund_msg;
    C::t('#tom_tcqianggou#tom_tcqianggou_order')->update($orderInfo['id'],$updateData);

    $toUser = array();
    $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
    if($toUserTmp && !empty($toUserTmp['openid'])){
        $toUser = $toUserTmp;
    }

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($toUser['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");
        $smsData = array(
            'first'         => lang('plugin/tom_tcqianggou','shenhe_template_refund_first'),
            'keyword1'      => $tongchengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
    }

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}

if(!preg_match('/^http/', $goodsInfo['picurl']) ){
    if(strpos($goodsInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfo['picurl'];
    }else{
        $picurl = $goodsInfo['picurl'];
    }
}else{
    $picurl = $goodsInfo['picurl'];
}

$goodsShopListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->fetch_all_list(" AND goods_id={$goodsInfo['id']} ", ' ORDER BY ssort ASC,id DESC ');
$goodsShopList = $goodsShopIdArr = array();
if(is_array($goodsShopListTmp) && !empty($goodsShopListTmp)){
    foreach($goodsShopListTmp as $key => $value){
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        if($tcshopInfoTmp['status'] == 1 && $tcshopInfoTmp['shenhe_status'] == 1){
            $goodsShopList[$value['id']] = $value;
            $goodsShopList[$value['id']]['tcshopInfo'] = $tcshopInfoTmp;

            $use_num_tmp = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_sum_use_num(" AND order_id = {$orderInfo['id']} AND goods_shop_id = {$value['id']} ");

            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurlTmp = $value['picurl'];
                }
            }else{
                $picurlTmp = $value['picurl'];
            }

            $contentTmp = strip_tags($value['content']);
            $contentTmp = str_replace("\r\n","",$contentTmp);
            $contentTmp = str_replace("\n","",$contentTmp);
            $contentTmp = str_replace("\r","",$contentTmp);

            $goodsShopList[$value['id']]['contentTmp'] = $contentTmp;
            $goodsShopList[$value['id']]['content'] = stripslashes($value['content']);
            $goodsShopList[$value['id']]['use_num'] = intval($use_num_tmp);
            $goodsShopList[$value['id']]['sy_num'] = $value['stock_num'] - $value['sale_num'];
            $goodsShopList[$value['id']]['picurl'] = $picurlTmp;
            $goodsShopList[$value['id']]['qrcode'] = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=orderhexiao_duo&hexiao_code={$orderInfo['hexiao_code']}&goods_shop_id={$value['id']}");

            $goodsShopIdArr[] = $value['id'];
        }
    }
}
$goodsShopCount = count($goodsShopList);

$useLogList = array();
if(is_array($goodsShopIdArr) && !empty($goodsShopIdArr)){
    $goodsShopIdStr = implode(',', $goodsShopIdArr);
    $useLogListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_all_list(" AND user_id = {$__UserInfo['id']} AND order_id = {$orderInfo['id']} AND goods_shop_id IN({$goodsShopIdStr}) ", 'ORDER BY id DESC', 0, 200);
    if(is_array($useLogListTmp) && !empty($useLogListTmp)){
        foreach($useLogListTmp as $key => $value){
            $useLogList[$key] = $value;
            $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
            $useLogList[$key]['userInfo'] = $userInfoTmp;
            $useLogList[$key]['goods_title'] = $goodsShopList[$value['goods_shop_id']]['title'];
            $useLogList[$key]['goods_picurl'] = $goodsShopList[$value['goods_shop_id']]['picurl'];
        }
    }
}
$useLogCount = count($useLogList);

$content = stripslashes($goodsInfo['content']);
$hexiao_start_time = dgmdate($goodsInfo['hexiao_start_time'],'Y'.lang("plugin/tom_tcqianggou", "year").'m'.lang("plugin/tom_tcqianggou", "month").'d'.lang("plugin/tom_tcqianggou", "day"),$tomSysOffset);
$hexiao_time = dgmdate($goodsInfo['hexiao_time'],'Y'.lang("plugin/tom_tcqianggou", "year").'m'.lang("plugin/tom_tcqianggou", "month").'d'.lang("plugin/tom_tcqianggou", "day"),$tomSysOffset);
if($goodsInfo['open_hexiao_valid'] == 1){
    $hexiao_valid_time = $orderInfo['pay_time'] + $goodsInfo['hexiao_valid_days'] * 86400;
    $hexiao_valid_time = dgmdate($hexiao_valid_time,'Y'.lang("plugin/tom_tcqianggou", "year").'m'.lang("plugin/tom_tcqianggou", "month").'d'.lang("plugin/tom_tcqianggou", "day").' H'.lang("plugin/tom_tcqianggou", "hour").'i'.lang("plugin/tom_tcqianggou", "minute"),$tomSysOffset);
}

$hexiaoTimeStatus = 1;
if($goodsInfo['open_hexiao_valid'] == 1){
    if(TIMESTAMP > ($orderInfo['pay_time'] + $goodsInfo['hexiao_valid_days'] * 86400)){
        $hexiaoTimeStatus = 2;
    }
}else{
    if(TIMESTAMP > $goodsInfo['hexiao_time']){
        $hexiaoTimeStatus = 2;
    }
    if($goodsInfo['hexiao_start_time'] > 0 && $goodsInfo['hexiao_start_time'] > TIMESTAMP){
        $hexiaoTimeStatus = 3;
    }
}

$showChoujiang = 0;
if($__ShowTcchoujiang == 1 && $goodsInfo['tcchoujiang_id'] > 0){
    $choujiangBmInfo = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($goodsInfo['tcchoujiang_id'],$__UserInfo['id']);
    if($choujiangBmInfo['id'] > 0 && $choujiangBmInfo['cj_times'] > 0){
        $showChoujiang = 1;
    }
}

$refundUrl = 'plugin.php?id=tom_tcqianggou&site='.$site_id.'&mod=hexiao&act=refund';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:hexiao_duo");