<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcadmin start
$__ShowTcadmin = 0;
$tcadminConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcadmin/tom_tcadmin.inc.php')){
    $tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
    if($tcadminConfig['open_fc'] == 1){
        $__ShowTcadmin = 1;
    }
}
## tcadmin end

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

$goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($orderInfo['goods_id']);
$orderTcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsShopInfo['tcshop_id']);
$orderUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderTcshopInfo['user_id']); 

if($goodsInfo['duo_shop_jiesuan'] == 3 && $duo_balance_type == 1){
    
    $shop_money = $goodsShopInfo['one_jiesuan_price'];

    $insertData = array();
    $insertData['user_id']          = $orderTcshopInfo['user_id'];
    $insertData['type_id']          = 2;
    $insertData['change_money']     = $shop_money;
    $insertData['old_money']        = $orderUserInfo['shop_money'];
    $insertData['business_id']      = 'tcqianggou';
    $insertData['business_user_id'] = $orderInfo['user_id'];
    $insertData['title']            = $orderInfo['goods_title'];
    $insertData['order_no']         = $orderInfo['order_no'];
    $insertData['log_year']         = dgmdate($_G['timestamp'], 'Y',$tomSysOffset);
    $insertData['log_month']        = dgmdate($_G['timestamp'], 'm',$tomSysOffset);
    $insertData['log_day']          = dgmdate($_G['timestamp'], 'd.0',$tomSysOffset);
    $insertData['log_ip']           = $_G['clientip'];
    $insertData['log_time']         = TIMESTAMP;
    C::t('#tom_tcshop#tom_tcshop_money_log')->insert($insertData);

    DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET shop_money = shop_money + {$shop_money} WHERE id='{$orderUserInfo['id']}'", 'UNBUFFERED');

    if($hexiaoStatus == 3){
        $updateData = array();
        $updateData['balance_status'] = 1;
        C::t('#tom_tcqianggou#tom_tcqianggou_order')->update($orderInfo['id'],$updateData);
    }
}

$hehuorenJiesuanFlag = 0;
if($goodsInfoTmp['goods_balance_type'] == 1 && $duo_balance_type == 1){
    $hehuorenJiesuanFlag = 1;
}
if($goodsInfoTmp['goods_balance_type'] == 2 && $duo_balance_type == 2){
    $hehuorenJiesuanFlag = 1;
}
if($orderInfo['use_num'] == 0 && $orderInfo['pay_price'] >= 0.1 && $hehuorenJiesuanFlag == 1){
    
    $yongjin_bili = $tcqianggouConfig['yongjin_bili'];
    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
    if($goodsInfoTmp['yongjin_bili'] > 0){
        $yongjin_bili = $goodsInfoTmp['yongjin_bili'];
    }
    
    if(($goodsInfoTmp['yongjin_type'] == 1 && $yongjin_bili <= 100) || ($goodsInfoTmp['yongjin_type'] == 2 && $yongjin_bili <= $orderInfo['pay_price'])){
        
        $pt_money = $orderInfo['pay_price'];
        if($goodsInfoTmp['yongjin_type'] == 2){
            $pt_money = $goodsInfoTmp['yongjin_bili'];
        }else{
            $pt_money = $orderInfo['pay_price']*($yongjin_bili/100);
            $pt_money = number_format($pt_money,2, '.', '');
        }
        
        if($pt_money >= 0.1){
            # fc start
            $adminFc = false;
            if($__ShowTchehuoren == 1 && $orderInfo['tj_hehuoren_id'] > 0){
                
                $shenyu_money = $pt_money;
                $child_site_fc_money = $tchehuoren_fc_money = $tctchehuorenParent_fc_money = 0;

                $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($orderInfo['tj_hehuoren_id']);
                if($tchehuorenInfo){
                    $tchehuorenDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
                    $tchehuorenUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tchehuorenInfo['openid']);
                }

                $tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
                if($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1){
                    $tctchehuorenParentInfo = C::t("#tom_tchehuoren#tom_tchehuoren")->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
                    $tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
                    $tctchehuorenParentUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_openid($tctchehuorenParentInfo['openid']);
                }

                if($tchehuorenInfo && $tchehuorenInfo['status'] == 1 && $tchehuorenDengji['qg_fc_open'] == 1){
                    if($orderInfo['site_id'] > 1 && $tcqianggouConfig['zizhandi_fc'] == 1){
                        $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                        $sitename = $sitesInfo['name'];
                        if($__ShowTcadmin && $sitesInfo['hehuoren_fc_open'] == 1){
                            
                            if($tchehuorenDengji['level'] == 1){
                                if($goodsInfoTmp['yongjin_type'] == 2){
                                    $tchehuoren_fc_money = 1 * $goodsInfoTmp['chuji_fc_scale'];
                                }else{
                                    $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['chuji_fc_scale']/100);
                                }
                            }else if($tchehuorenDengji['level'] == 2){
                                if($goodsInfoTmp['yongjin_type'] == 2){
                                    $tchehuoren_fc_money = 1 * $goodsInfoTmp['zhongji_fc_scale'];
                                }else{
                                    $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['zhongji_fc_scale']/100);
                                }
                            }else if($tchehuorenDengji['level'] == 3){
                                if($goodsInfoTmp['yongjin_type'] == 2){
                                    $tchehuoren_fc_money = 1 * $goodsInfoTmp['gaoji_fc_scale'];
                                }else{
                                    $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['gaoji_fc_scale']/100);
                                }
                            }
                            $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2, '.', '');
                            
                            $fc_scale = $sitesInfo['qg_fc_scale'];
                            if($fc_scale > 0){
                                $child_site_fc_money = $pt_money * ($fc_scale/100);
                                $child_site_fc_money = number_format($child_site_fc_money,2, '.', '');
                                $child_site_fc_money = $child_site_fc_money - $tchehuoren_fc_money;
                            }
                            if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                                if($tctchehuorenParentDengji['level'] == 1){
                                    if($goodsInfoTmp['yongjin_type'] == 2){
                                        $tctchehuorenParent_fc_money = 1 * $goodsInfoTmp['chuji_fc_scale2'];
                                    }else if($goodsInfoTmp['chuji_fc_scale2'] > 0 && $goodsInfoTmp['chuji_fc_scale2'] < 100){
                                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($goodsInfoTmp['chuji_fc_scale2']/100);
                                    }else{
                                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                                    }
                                }else if($tctchehuorenParentDengji['level'] == 2){
                                    if($goodsInfoTmp['yongjin_type'] == 2){
                                        $tctchehuorenParent_fc_money = 1 * $goodsInfoTmp['zhongji_fc_scale2'];
                                    }else if($goodsInfoTmp['zhongji_fc_scale2'] > 0 && $goodsInfoTmp['zhongji_fc_scale2'] < 100){
                                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($goodsInfoTmp['zhongji_fc_scale2']/100);
                                    }else{
                                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                                    }
                                }else if($tctchehuorenParentDengji['level'] == 3){
                                    if($goodsInfoTmp['yongjin_type'] == 2){
                                        $tctchehuorenParent_fc_money = 1 * $goodsInfoTmp['gaoji_fc_scale2'];
                                    }else if($goodsInfoTmp['gaoji_fc_scale2'] > 0 && $goodsInfoTmp['gaoji_fc_scale2'] < 100){
                                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($goodsInfoTmp['gaoji_fc_scale2']/100);
                                    }else{
                                        $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                                    }
                                }
                                $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                                if($tchehuorenConfig['subordinate_moneytype'] == 1){
                                    $child_site_fc_money   = $child_site_fc_money - $tctchehuorenParent_fc_money;
                                }else{
                                    $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                                }
                            }

                            $shenyu_money = $shenyu_money - $child_site_fc_money - $tchehuoren_fc_money;

                        }else{
                            if($__ShowTcadmin == 1 && $tcqianggouConfig['zizhandi_fc'] == 1){
                                $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                                $fc_scale = $sitesInfo['qg_fc_scale'];
                                if($fc_scale > 0){
                                    $child_site_fc_money = $pt_money * ($fc_scale/100);
                                    $child_site_fc_money = number_format($child_site_fc_money,2, '.', '');
                                }
                            }

                            $shenyu_money = $shenyu_money - $child_site_fc_money;

                        }

                    }else{
                        $sitename = $tongchengConfig['plugin_name'];
                        if($tchehuorenDengji['level'] == 1){
                            if($goodsInfoTmp['yongjin_type'] == 2){
                                $tchehuoren_fc_money = 1 * $goodsInfoTmp['chuji_fc_scale'];
                            }else{
                                $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['chuji_fc_scale']/100);
                            }
                        }else if($tchehuorenDengji['level'] == 2){
                            if($goodsInfoTmp['yongjin_type'] == 2){
                                $tchehuoren_fc_money = 1 * $goodsInfoTmp['zhongji_fc_scale'];
                            }else{
                                $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['zhongji_fc_scale']/100);
                            }
                        }else if($tchehuorenDengji['level'] == 3){
                            if($goodsInfoTmp['yongjin_type'] == 2){
                                $tchehuoren_fc_money = 1 * $goodsInfoTmp['gaoji_fc_scale'];
                            }else{
                                $tchehuoren_fc_money = $pt_money * ($goodsInfoTmp['gaoji_fc_scale']/100);
                            }
                        }
                        $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2, '.', '');

                        if(!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1){
                            if($tctchehuorenParentDengji['level'] == 1){
                                if($goodsInfoTmp['yongjin_type'] == 2){
                                    $tctchehuorenParent_fc_money = 1 * $goodsInfoTmp['chuji_fc_scale2'];
                                }else if($goodsInfoTmp['chuji_fc_scale2'] > 0 && $goodsInfoTmp['chuji_fc_scale2'] < 100){
                                    $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($goodsInfoTmp['chuji_fc_scale2']/100);
                                }else{
                                    $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                                }
                            }else if($tctchehuorenParentDengji['level'] == 2){
                                if($goodsInfoTmp['yongjin_type'] == 2){
                                    $tctchehuorenParent_fc_money = 1 * $goodsInfoTmp['zhongji_fc_scale2'];
                                }else if($goodsInfoTmp['zhongji_fc_scale2'] > 0 && $goodsInfoTmp['zhongji_fc_scale2'] < 100){
                                    $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($goodsInfoTmp['zhongji_fc_scale2']/100);
                                }else{
                                    $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                                }
                            }else if($tctchehuorenParentDengji['level'] == 3){
                                if($goodsInfoTmp['yongjin_type'] == 2){
                                    $tctchehuorenParent_fc_money = 1 * $goodsInfoTmp['gaoji_fc_scale2'];
                                }else if($goodsInfoTmp['gaoji_fc_scale2'] > 0 && $goodsInfoTmp['gaoji_fc_scale2'] < 100){
                                    $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($goodsInfoTmp['gaoji_fc_scale2']/100);
                                }else{
                                    $tctchehuorenParent_fc_money = $tchehuoren_fc_money * ($tctchehuorenParentDengji['tuijian_fc_scale']/100);
                                }
                            }
                            $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                            if($tchehuorenConfig['subordinate_moneytype'] == 1){
                            }else{
                                $tchehuoren_fc_money   = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                            }
                        }

                        $shenyu_money = $shenyu_money - $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                    }

                    if($pt_money >= ($child_site_fc_money +  $tchehuoren_fc_money + $tctchehuorenParent_fc_money)){  

                        if($child_site_fc_money > 0){
                            $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);
                            
                            $old_money = 0;
                            if($walletInfo){
                                $old_money = $walletInfo['account_balance'];

                                $updateData = array();
                                $updateData['account_balance']   = $walletInfo['account_balance'] + $child_site_fc_money;
                                $updateData['total_income']   = $walletInfo['total_income'] + $child_site_fc_money;
                                C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
                            }else{
                                $insertData = array();
                                $insertData['site_id']              = $orderInfo['site_id'];
                                $insertData['account_balance']      = $child_site_fc_money;
                                $insertData['total_income']         = $child_site_fc_money;
                                $insertData['add_time']             = TIMESTAMP;
                                C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
                            }

                            $insertData = array();
                            $insertData['site_id']      = $orderInfo['site_id'];
                            $insertData['log_type']     = 1;
                            $insertData['change_money'] = $child_site_fc_money;
                            $insertData['old_money']    = $old_money;
                            $insertData['beizu']        = lang('plugin/tom_tcqianggou', 'beizu_wallet_log');
                            $insertData['order_no']     = $orderInfo['order_no'];
                            $insertData['order_type']   = 99;
                            $insertData['log_ip']       = $_G['clientip'];
                            $insertData['log_time']     = TIMESTAMP;
                            C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData); 
                        }

                        $sendTemplateTchehuoren = false;
                        if($tchehuoren_fc_money > 0){
                            $sendTemplateTchehuoren = true;

                            $insertData = array();
                            $insertData['order_no']         = $orderInfo['order_no'];
                            $insertData['hehuoren_id']      = $tchehuorenInfo['id'];
                            $insertData['ly_user_id']       = $userInfoTmp['id'];
                            $insertData['child_hehuoren_id'] = 0;
                            $insertData['today_time']       = $nowDayTime;
                            $insertData['week_time']        = $nowWeekTime;
                            $insertData['month_time']       = $nowMonthTime;
                            $insertData['title']            = $goodsInfoTmp['title'];
                            $insertData['type']             = lang('plugin/tom_tcqianggou', 'hehuoren_tag_qg');
                            $insertData['shouyi_price']     = $tchehuoren_fc_money;
                            $insertData['content']          = lang('plugin/tom_tcqianggou', 'hehuoren_beizu_1') . $orderInfo['order_no'] . lang('plugin/tom_tcqianggou', 'hehuoren_beizu_2') . $userInfoTmp['nickname'];
                            $insertData['shouyi_status']    = 1;
                            $insertData['add_time']         = TIMESTAMP;
                            C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                        }

                        $sendTemplateTchehuorenParent = false;
                        if($tctchehuorenParent_fc_money > 0){
                            $sendTemplateTchehuorenParent = true;

                            $insertData = array();
                            $insertData['order_no']         = $orderInfo['order_no'];
                            $insertData['hehuoren_id']      = $tctchehuorenParentInfo['id'];
                            $insertData['ly_user_id']       = $userInfoTmp['id'];
                            $insertData['child_hehuoren_id'] = $tchehuorenInfo['id'];
                            $insertData['today_time']       = $nowDayTime;
                            $insertData['week_time']        = $nowWeekTime;
                            $insertData['month_time']       = $nowMonthTime;
                            $insertData['title']            = $goodsInfoTmp['title'];
                            $insertData['type']             = lang('plugin/tom_tcqianggou', 'hehuoren_tag_qg');
                            $insertData['shouyi_price']     = $tctchehuorenParent_fc_money;
                            $insertData['content']          = lang('plugin/tom_tcqianggou', 'hehuoren_beizu_1') . $orderInfo['order_no'] . lang('plugin/tom_tcqianggou', 'hehuoren_beizu_2') . $userInfoTmp['nickname'];
                            $insertData['shouyi_status']    = 1;
                            $insertData['add_time']         = TIMESTAMP;
                            C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                        }
                    }

                }else{
                    $adminFc = true;
                }
            }else{
                $adminFc = true;
            }
            
            if($__ShowTcadmin == 1 && $adminFc && $tcqianggouConfig['zizhandi_fc'] == 1){
                $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
                $fc_scale = $sitesInfo['qg_fc_scale'];
                
                if($fc_scale> 0){
                    
                    $fc_money = $pt_money*($fc_scale/100);
                    $fc_money = number_format($fc_money,2, '.', '');
                    
                    $walletInfo = C::t('#tom_tcadmin#tom_tcadmin_wallet')->fetch_by_site_id($orderInfo['site_id']);
                
                    $old_money = 0;
                    if($walletInfo){
                        $old_money = $walletInfo['account_balance'];

                        $updateData = array();
                        $updateData['account_balance']      = $walletInfo['account_balance'] + $fc_money;
                        $updateData['total_income']         = $walletInfo['total_income'] + $fc_money;
                        C::t('#tom_tcadmin#tom_tcadmin_wallet')->update($walletInfo['id'],$updateData);
                    }else{
                        $insertData = array();
                        $insertData['site_id']              = $orderInfo['site_id'];
                        $insertData['account_balance']      = $fc_money;
                        $insertData['total_income']         = $fc_money;
                        $insertData['add_time']             = TIMESTAMP;
                        C::t('#tom_tcadmin#tom_tcadmin_wallet')->insert($insertData);
                    }

                    $insertData = array();
                    $insertData['site_id']      = $orderInfo['site_id'];
                    $insertData['log_type']     = 1;
                    $insertData['change_money'] = $fc_money;
                    $insertData['old_money']    = $old_money;
                    $insertData['beizu']        = lang('plugin/tom_tcqianggou', 'beizu_wallet_log');
                    $insertData['order_no']     = $orderInfo['order_no'];
                    $insertData['order_type']   = 99;
                    $insertData['log_ip']       = $_G['clientip'];
                    $insertData['log_time']     = TIMESTAMP;
                    C::t('#tom_tcadmin#tom_tcadmin_wallet_log')->insert($insertData);
                }
            }
            # fc end
        }
        
        if($sendTemplateTchehuoren == true){
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($tchehuorenInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                $shouyiText = str_replace("{NICKNAME}",$userInfoTmp['nickname'], lang('plugin/tom_tongcheng', 'paynotify_hehuoren_template'));
                $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                $shouyiText = str_replace("{TYPE}",lang('plugin/tom_tcqianggou', 'hehuoren_tag_qg'), $shouyiText);
                $shouyiText = str_replace("{MONEY}",$tchehuoren_fc_money, $shouyiText);
                $smsData = array(
                    'first'         => $shouyiText,
                    'keyword1'      => $tchehuorenConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                if(!empty($tchehuorenConfig['template_id'])){
                    $template_id = $tchehuorenConfig['template_id'];
                }else{
                    $template_id = $tongchengConfig['template_id'];
                }
                @$r = $templateSmsClass->sendSms01($tchehuorenInfo['openid'], $template_id, $smsData);
            }
        }

        if($sendTemplateTchehuorenParent == true){
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($tctchehuorenParentInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
                $shouyiText = str_replace("{TCHEHUOREN}",$tchehuorenInfo['xm'], lang('plugin/tom_tongcheng', 'paynotify_hehuorenparent_template'));
                $shouyiText = str_replace("{NICKNAME}",$userInfoTmp['nickname'], $shouyiText);
                $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
                $shouyiText = str_replace("{TYPE}",lang('plugin/tom_tcqianggou', 'hehuoren_tag_qg'), $shouyiText);
                $shouyiText = str_replace("{MONEY}",$tctchehuorenParent_fc_money, $shouyiText);
                $smsData = array(
                    'first'         => $shouyiText,
                    'keyword1'      => $tchehuorenConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                if(!empty($tchehuorenConfig['template_id'])){
                    $template_id = $tchehuorenConfig['template_id'];
                }else{
                    $template_id = $tongchengConfig['template_id'];
                }
                @$r = $templateSmsClass->sendSms01($tctchehuorenParentInfo['openid'], $template_id, $smsData);
            }
        }
        
    }
}