<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       = intval($_GET['type'])>0? intval($_GET['type']):1;
$t_id       = intval($_GET['t_id'])>0? intval($_GET['t_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

$whereStr = " AND user_id = {$__UserInfo['id']} ";
$orderStr = " ORDER BY id DESC ";

if($type == 1){
    $whereStr.=" AND type_id=1 ";
}else{
    $whereStr.=" AND type_id IN(2,3,4) ";
}

if($t_id == 1){
    $whereStr.=" AND order_status=2 ";
}else if($t_id == 2){
    $whereStr.=" AND order_status=1 ";
}else if($t_id == 3){
    $whereStr.=" AND order_status=3 ";
}else{
    $whereStr.=" AND order_status IN(1,2,3) ";
}

$pagesize       = 8;
$start          = ($page - 1)*$pagesize;
$count  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count($whereStr);
$orderListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);
$orderList = array();
$choujiangIdArr = array();
$noNoPay = 0;
foreach ($orderListTmp as $key => $value){

    $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($value['goods_id']);

    if($goodsInfoTmp && $goodsInfoTmp['id'] > 0){

        if($goodsInfoTmp['show_buy_price'] <= 0){
            $goodsInfoTmp['show_buy_price']    = $goodsInfoTmp['buy_price'];
            $goodsInfoTmp['show_vip_price']    = $goodsInfoTmp['vip_price'];
            $goodsInfoTmp['show_market_price'] = $goodsInfoTmp['market_price'];
        }

        if($value['option_id'] > 0){
            $optionInfoTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($value['option_id']);
            if(is_array($optionInfoTmp) && !empty($optionInfoTmp) && $optionInfoTmp['id'] > 0){
                $goodsInfoTmp['show_buy_price']      = $optionInfoTmp['buy_price'];
                $goodsInfoTmp['show_vip_price']      = $optionInfoTmp['vip_price'];
                $goodsInfoTmp['show_market_price']   = $optionInfoTmp['market_price'];
            }
        }

        $orderList[$key] = $value;
        if(!preg_match('/^http/', $goodsInfoTmp['picurl']) ){
            if(strpos($goodsInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfoTmp['picurl'];
            }else{
                $picurl = $goodsInfoTmp['picurl'];
            }
        }else{
            $picurl = $goodsInfoTmp['picurl'];
        }

        if($value['order_status'] == 3){
            $orderList[$key]['use_num'] = $value['goods_num'];
        }

        $orderList[$key]['goodsInfo'] = $goodsInfoTmp;
        $orderList[$key]['goodsInfo']['picurl'] = $picurl;
        $orderList[$key]['goodsInfo']['hexiao_time'] = dgmdate($goodsInfoTmp['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
        if($goodsInfoTmp['open_hexiao_valid'] == 1){
            $hexiao_valid_time = $value['pay_time'] + $goodsInfoTmp['hexiao_valid_days'] * 86400;
            $orderList[$key]['goodsInfo']['hexiao_valid_time'] = dgmdate($hexiao_valid_time,"Y-m-d H:i",$tomSysOffset);
        }

        if($value['type_id'] == 1){
            $orderList[$key]['goodsInfo']['link'] = 'plugin.php?id=tom_tcqianggou&site='.$value['site_id'].'&mod=details&goods_id='.$goodsInfoTmp['id'];
        }else{
            $orderList[$key]['goodsInfo']['link'] = 'plugin.php?id=tom_tcqianggou&site='.$value['site_id'].'&mod=coupon&goods_id='.$goodsInfoTmp['id'];
        }

        if($goodsInfoTmp['open_duo_shop'] == 1){
            $orderList[$key]['hexiao'] = 'plugin.php?id=tom_tcqianggou&site='.$value['site_id'].'&mod=hexiao_duo&order_no='.$value['order_no'];
        }else{
            $orderList[$key]['hexiao'] = 'plugin.php?id=tom_tcqianggou&site='.$value['site_id'].'&mod=hexiao&order_no='.$value['order_no'];
        }

        $orderList[$key]['choujiang'] = 0;
        if($__ShowTcchoujiang == 1 && $goodsInfoTmp['tcchoujiang_id'] > 0){
            $choujiangBmInfoTmp = C::t('#tom_tcchoujiang#tom_tcchoujiang_bm')->fetch_by_tcchoujiang_id_user_id($goodsInfoTmp['tcchoujiang_id'],$value['user_id']);
            if($choujiangBmInfoTmp['id'] > 0 && $choujiangBmInfoTmp['cj_times'] > 0){
                if(!in_array($goodsInfoTmp['tcchoujiang_id'], $choujiangIdArr)){
                    $orderList[$key]['choujiang'] = 1;
                    $choujiangIdArr[] = $goodsInfoTmp['tcchoujiang_id'];
                }
            }
        }

        if($value['order_status'] == 1){
            $noNoPay = 1;
            if((TIMESTAMP - $value['order_time']) > 3590){
                DB::query("UPDATE ".DB::table('tom_tcqianggou_goods')." SET sale_num=sale_num-{$value['goods_num']} WHERE id='{$value['goods_id']}' ", 'UNBUFFERED');
                DB::query("UPDATE ".DB::table('tom_tcqianggou_order')." SET order_status=4 WHERE id='{$value['id']}' ", 'UNBUFFERED');
                if($value['option_id'] > 0){
                    DB::query("UPDATE ".DB::table('tom_tcqianggou_goods_option')." SET sale_num=sale_num - {$value['goods_num']} WHERE id='{$value['option_id']}' ", 'UNBUFFERED');
                }
                if($value['code_order'] == 1){
                    DB::query("UPDATE ".DB::table('tom_tcqianggou_code')." SET order_id=0,order_no='',user_id=0,code_status=0 WHERE goods_id={$value['goods_id']} AND order_id={$value['id']} ", 'UNBUFFERED');
                }
                $orderList[$key]['order_status'] = 4;
            }
        }

    }

}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=mylist&type={$type}&t_id={$t_id}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=mylist&type={$type}&t_id={$t_id}&page={$nextPage}";

$ajaxCancelPayUrl = "plugin.php?id=tom_tcqianggou:pay&site={$site_id}&act=cancelpay&formhash=".FORMHASH;

$subscribeFlag = 0;
if($type == 1 && $tcqianggouConfig['mylist_guanzu_type'] > 1 && $count > 0 && $noNoPay == 0){
    $access_token = $weixinClass->get_access_token();
    if(!empty($__UserInfo['openid']) && !empty($access_token)){
        $get_user_info_url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token={$access_token}&openid={$__UserInfo['openid']}&lang=zh_CN";
        $return = get_html($get_user_info_url);
        if(!empty($return)){
            $content = json_decode($return,true);
            if(is_array($content) && !empty($content) && isset($content['subscribe'])){
                if($content['subscribe'] == 1){
                    $subscribeFlag = 1;
                }else{
                    $subscribeFlag = 2;
                }
            }
        }
    }
}
$guanzuShareUrl   = $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=mylist&type={$type}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:mylist");