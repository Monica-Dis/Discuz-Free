<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id   = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
$type       = intval($_GET['type'])>0? intval($_GET['type']):1;
$t_id       = intval($_GET['t_id'])>0? intval($_GET['t_id']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$keyword  = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';

$tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(" AND user_id={$__UserInfo['id']} "," ORDER BY id DESC ",0,100);
$tcshopListId = array();
if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
    foreach ($tcshopListTmp as $key => $value){
        $tcshopListId[] = $value['id'];
    }
}

$tcshopListIdStr = '99999999999';
if(is_array($tcshopListId) && !empty($tcshopListId)){
    $tcshopListIdStr = implode(',', $tcshopListId);
}

$whereStr = " AND tcshop_id IN({$tcshopListIdStr}) ";
$whereTjStr = " AND tcshop_id IN({$tcshopListIdStr}) ";

$orderStr = " ORDER BY id DESC ";

if(!empty($goods_id) && $goods_id > 0){
    $whereStr.= " AND goods_id={$goods_id} ";
    $whereTjStr.= " AND goods_id={$goods_id} ";
}

if($type == 1){
    $whereStr.=" AND type_id=1 ";
    $whereTjStr.=" AND type_id=1 ";
}else{
    $whereStr.=" AND type_id IN(2,3,4) ";
    $whereTjStr.=" AND type_id IN(2,3,4) ";
}

if($t_id == 1){
    $whereStr.=" AND order_status=2 ";
}else if($t_id == 2){
    $whereStr.=" AND order_status=1 ";
}else if($t_id == 3){
    $whereStr.=" AND order_status=3 ";
}else{
    $whereStr.=" AND order_status IN(1,2,3) ";
}

if(!empty($keyword)){
    $whereStr.=" AND tel='{$keyword}' ";
    $whereTjStr.=" AND tel='{$keyword}' ";
}

if($t_id == 3){
    $orderStr = " ORDER BY hexiao_time DESC,id DESC ";
}

$pagesize       = 8;
$start          = ($page - 1)*$pagesize;
$count = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(" {$whereStr} ");
$count2 = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_goods_num(" {$whereTjStr} AND order_status=2 ");
$count2_uses = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_use_num(" {$whereTjStr} AND order_status=2 ");
$count2 = $count2 - $count2_uses;
$count3 = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_goods_num(" {$whereTjStr} AND order_status=3 ");
$count3 = $count3 + $count2_uses;
$orderListTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);
$orderList = array();
foreach ($orderListTmp as $key => $value){

    $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($value['goods_id']);
    if($goodsInfoTmp && $goodsInfoTmp['id'] > 0){
        $orderList[$key] = $value;
        if(!preg_match('/^http/', $goodsInfoTmp['picurl']) ){
            if(strpos($goodsInfoTmp['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$goodsInfoTmp['picurl'];
            }else{
                $picurl = $goodsInfoTmp['picurl'];
            }
        }else{
            $picurl = $goodsInfoTmp['picurl'];
        }

        $orderList[$key]['goodsInfo'] = $goodsInfoTmp;

        $orderList[$key]['goodsInfo']['picurl'] = $picurl;

        $orderList[$key]['pay_time'] = dgmdate($goodsInfoTmp['pay_time'],"Y-m-d H:i",$tomSysOffset);

        if($value['type_id'] == 1){
            $orderList[$key]['goodsInfo']['link'] = 'plugin.php?id=tom_tcqianggou&site='.$value['site_id'].'&mod=details&goods_id='.$goodsInfoTmp['id'];
        }else{
            $orderList[$key]['goodsInfo']['link'] = 'plugin.php?id=tom_tcqianggou&site='.$value['site_id'].'&mod=coupon&goods_id='.$goodsInfoTmp['id'];
        }

        $orderList[$key]['url'] = 'plugin.php?id=tom_tcqianggou&site='.$value['site_id'].'&mod=orderinfo&order_no='.$value['order_no'];
    }

}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=order&goods_id={$goods_id}&type={$type}&t_id={$t_id}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcqianggou&site={$site_id}&mod=order&goods_id={$goods_id}&type={$type}&t_id={$t_id}&page={$nextPage}";

$clerkListCountList = array();
if($goods_id > 0){
    $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
    $clerkListTmp  = C::t('#tom_tcshop#tom_tcshop_clerk')->fetch_all_list(" AND tcshop_id={$goodsInfoTmp['tcshop_id']} "," ORDER BY id DESC ",0,20);
    if(is_array($clerkListTmp) && !empty($clerkListTmp)){
        foreach ($clerkListTmp as $key => $value){
            $countTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_sun_goods_num(" AND hexiao_user_id={$value['user_id']} AND order_status=3 ");
            $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
            $clerkListCountList[$key]['nickname'] = $userInfoTmp['nickname'];
            $clerkListCountList[$key]['num'] = $countTmp;
        }
    }
}

$searchUrl = 'plugin.php?id=tom_tcqianggou:ajax&site='.$site_id.'&act=get_order_search_url';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:order");