<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = '';

$tom_tcqianggou_goods_field = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_field();
if (!isset($tom_tcqianggou_goods_field['open_ding_pay'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `open_ding_pay` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['open_yuyue'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `open_yuyue` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['yuyue_xm'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `yuyue_xm` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['yuyue_tel'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `yuyue_tel` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['xiangou_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `xiangou_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['virtual_clicks'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `virtual_clicks` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['paixu'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `paixu` int(11) DEFAULT '1000';\n";
}
if (!isset($tom_tcqianggou_goods_field['peisong_type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `peisong_type` int(11) DEFAULT '1';\n";
}
if (!isset($tom_tcqianggou_goods_field['yongjin_bili'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `yongjin_bili` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['hehuoren_tg_open'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `hehuoren_tg_open` int(11) DEFAULT '2';\n";
}
if (!isset($tom_tcqianggou_goods_field['hehuoren_tg_haibao'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `hehuoren_tg_haibao` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['chuji_fc_scale'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `chuji_fc_scale` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['zhongji_fc_scale'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `zhongji_fc_scale` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['gaoji_fc_scale'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `gaoji_fc_scale` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['open_vip'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `open_vip` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['vip_price'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `vip_price` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_goods_field['hexiao_pwd'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `hexiao_pwd` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['open_before'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `open_before` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['before_price'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `before_price` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_goods_field['before_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `before_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['open_xubuy'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `open_xubuy` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['hasoption'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `hasoption` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['show_market_price'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `show_market_price` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_goods_field['show_before_price'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `show_before_price` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_goods_field['show_buy_price'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `show_buy_price` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_goods_field['show_vip_price'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `show_vip_price` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_goods_field['share_title'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `share_title` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['share_desc'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `share_desc` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['allow_refund'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `allow_refund` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['min_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `min_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['haibao_type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `haibao_type` int(11) DEFAULT '1';\n";
}
if (!isset($tom_tcqianggou_goods_field['haibao_picurl'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `haibao_picurl` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['qrcode_location'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `qrcode_location` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['tcchoujiang_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `tcchoujiang_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['yongjin_type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `yongjin_type` tinyint(4) DEFAULT '1';\n";
}
if (!isset($tom_tcqianggou_goods_field['chuji_fc_scale2'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `chuji_fc_scale2` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_goods_field['zhongji_fc_scale2'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `zhongji_fc_scale2` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_goods_field['gaoji_fc_scale2'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `gaoji_fc_scale2` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_goods_field['open_code'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `open_code` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['code_help_msg'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `code_help_msg` text;\n";
}
if (!isset($tom_tcqianggou_goods_field['xuzhi'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `xuzhi` mediumtext;\n";
}
if (!isset($tom_tcqianggou_goods_field['hexiao_start_time'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `hexiao_start_time` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['mp3_link'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `mp3_link` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['open_duo_shop'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `open_duo_shop` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['duo_hexiao_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `duo_hexiao_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['duo_shop_jiesuan'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `duo_shop_jiesuan` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['goods_balance_type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `goods_balance_type` tinyint(4) DEFAULT '1';\n";
}
if (!isset($tom_tcqianggou_goods_field['open_shop_yongjin'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `open_shop_yongjin` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['shop_yongjin'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `shop_yongjin` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_goods_field['qianggou_ids'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `qianggou_ids` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['recom_cate_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `recom_cate_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['haibao_msg'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `haibao_msg` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['zhibo_roomid'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `zhibo_roomid` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['trade_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `trade_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['haibao_text_color'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `haibao_text_color` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['latitude'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `latitude` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['longitude'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `longitude` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_field['hexiao_valid_days'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `hexiao_valid_days` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['open_hexiao_valid'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `open_hexiao_valid` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['open_score_dikou'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `open_score_dikou` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['score_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `score_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_field['score_dikou_price'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `score_dikou_price` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_goods_field['yuyue_type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `yuyue_type` tinyint(4) DEFAULT '1';\n";
}
if (!isset($tom_tcqianggou_goods_field['tcyuyue_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." ADD `tcyuyue_id` int(11) DEFAULT '0';\n";
}

$tom_tcqianggou_order_field = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_field();
if (!isset($tom_tcqianggou_order_field['address'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `address` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_order_field['peisong_type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `peisong_type` int(11) DEFAULT '1';\n";
}
if (!isset($tom_tcqianggou_order_field['peisong_status'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `peisong_status` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_order_field['peisong_info'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `peisong_info` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_order_field['peisong_time'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `peisong_time` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_order_field['tj_hehuoren_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `tj_hehuoren_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_order_field['vip_pay_status'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `vip_pay_status` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_order_field['order_beizu'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `order_beizu` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_order_field['before_pay_status'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `before_pay_status` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_order_field['option_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `option_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_order_field['option_name'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `option_name` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_order_field['use_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `use_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_order_field['one_price'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `one_price` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_order_field['refund_type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `refund_type` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_order_field['code_order'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `code_order` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_order_field['shenqing_refund'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `shenqing_refund` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_order_field['shenqing_refund_msg'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `shenqing_refund_msg` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_order_field['kuaidi_type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `kuaidi_type` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_order_field['kuaidi_no'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `kuaidi_no` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_order_field['address_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `address_id` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_order_field['score_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `score_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_order_field['score_dikou_price'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `score_dikou_price` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_order_field['tcyuyue_log_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order')." ADD `tcyuyue_log_id` int(11) DEFAULT '0';\n";
}

$tom_tcqianggou_stock_log_field = C::t('#tom_tcqianggou#tom_tcqianggou_stock_log')->fetch_all_field();
if (!isset($tom_tcqianggou_stock_log_field['is_option'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_stock_log')." ADD `is_option` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_stock_log_field['beizu'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_stock_log')." ADD `beizu` text;\n";
}

if (!empty($sql)) {
	runquery($sql);
}


$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_tom_tcqianggou_xubuy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) DEFAULT '0',
  `order_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `option_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `goods_num` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcqianggou_goods_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `market_price` decimal(10,2) DEFAULT '0.00',
  `buy_price` decimal(10,2) DEFAULT '0.00',
  `vip_price` decimal(10,2) DEFAULT '0.00',
  `before_price` decimal(10,2) DEFAULT '0.00',
  `shop_yongjin` decimal(10,2) DEFAULT '0.00',
  `stock_num` int(11) DEFAULT '0',
  `sale_num` int(11) DEFAULT '0',
  `osort` int(11) DEFAULT '10',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcqianggou_order_use_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `use_num` int(11) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcqianggou_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `order_id` int(11) DEFAULT '0',
  `order_no` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `code_value` varchar(255) DEFAULT NULL,
  `code_status` tinyint(4) DEFAULT '0',
  `use_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcqianggou_goods_shop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `market_price` decimal(10,2) DEFAULT '0.00',
  `stock_num` int(11) DEFAULT '0',
  `sale_num` int(11) DEFAULT '0',
  `xian_use_num` int(11) DEFAULT '0',
  `one_jiesuan_price` decimal(10,2) DEFAULT '0.00',
  `hexiao_pwd` varchar(255) DEFAULT NULL,
  `content` text,
  `ssort` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcqianggou_recom_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '0',
  `template_type` tinyint(4) DEFAULT '1',
  `toppic` varchar(255) DEFAULT NULL,
  `index_show_num` int(11) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `csort` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcqianggou_goods_tz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `order_no` varchar(255) DEFAULT NULL,
  `tz_status` tinyint(4) DEFAULT '1',
  `tz_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcqianggou_group_qrcode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `qrcode` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `tishi_msg` varchar(255) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcqianggou_popup` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_ids` text,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `clicks` int(11) DEFAULT '0',
  `show_num` int(11) unsigned DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcqianggou_popup_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `popup_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `num` int(11) DEFAULT '0',
  `log_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcqianggou_trade` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `is_recommend` tinyint(4) DEFAULT '0',
  `tsort` int(11) DEFAULT '100',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_tom_tcqianggou_goods_clicks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `clicks_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$sql = '';
$tom_tcqianggou_xubuy_field = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_field();
if (!isset($tom_tcqianggou_xubuy_field['option_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_xubuy')." ADD `option_id` int(11) DEFAULT '0';\n";
}

$tom_tcqianggou_goods_field = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_field();
if (isset($tom_tcqianggou_goods_field['yongjin_bili']) && $tom_tcqianggou_goods_field['yongjin_bili']['Type'] == 'int(11)') {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." CHANGE `yongjin_bili` `yongjin_bili` decimal(10,2) DEFAULT '0.00';\n";
}
if (isset($tom_tcqianggou_goods_field['chuji_fc_scale']) && $tom_tcqianggou_goods_field['chuji_fc_scale']['Type'] == 'int(11)') {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." CHANGE `chuji_fc_scale` `chuji_fc_scale` decimal(10,2) DEFAULT '0.00';\n";
}
if (isset($tom_tcqianggou_goods_field['zhongji_fc_scale']) && $tom_tcqianggou_goods_field['zhongji_fc_scale']['Type'] == 'int(11)') {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." CHANGE `zhongji_fc_scale` `zhongji_fc_scale` decimal(10,2) DEFAULT '0.00';\n";
}
if (isset($tom_tcqianggou_goods_field['gaoji_fc_scale']) && $tom_tcqianggou_goods_field['gaoji_fc_scale']['Type'] == 'int(11)') {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods')." CHANGE `gaoji_fc_scale` `gaoji_fc_scale` decimal(10,2) DEFAULT '0.00';\n";
}

$tom_tcqianggou_code_field = C::t('#tom_tcqianggou#tom_tcqianggou_code')->fetch_all_field();
if (!isset($tom_tcqianggou_code_field['option_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_code')." ADD `option_id` int(11) DEFAULT '0';\n";
}

$tom_tcqianggou_order_use_log_field = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_all_field();
if (!isset($tom_tcqianggou_order_use_log_field['goods_shop_id'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_order_use_log')." ADD `goods_shop_id` int(11) DEFAULT '0';\n";
}

$tom_tcqianggou_goods_option_field = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_all_field();
if (!isset($tom_tcqianggou_goods_option_field['shop_yongjin'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods_option')." ADD `shop_yongjin` decimal(10,2) DEFAULT '0.00';\n";
}
if (!isset($tom_tcqianggou_goods_option_field['score_num'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods_option')." ADD `score_num` int(11) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_option_field['score_dikou_price'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods_option')." ADD `score_dikou_price` decimal(10,2) DEFAULT '0.00';\n";
}

$tom_tcqianggou_goods_photo_field = C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->fetch_all_field();
if (!isset($tom_tcqianggou_goods_photo_field['oss_picurl'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods_photo')." ADD `oss_picurl` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_photo_field['oss_status'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods_photo')." ADD `oss_status` tinyint(4) DEFAULT '0';\n";
}
if (!isset($tom_tcqianggou_goods_photo_field['qiniu_picurl'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods_photo')." ADD `qiniu_picurl` varchar(255) DEFAULT NULL;\n";
}
if (!isset($tom_tcqianggou_goods_photo_field['qiniu_status'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_goods_photo')." ADD `qiniu_status` tinyint(4) DEFAULT '0';\n";
}

$tom_tcqianggou_focuspic_field = C::t('#tom_tcqianggou#tom_tcqianggou_focuspic')->fetch_all_field();
if (!isset($tom_tcqianggou_focuspic_field['type'])) {
    $sql .= "ALTER TABLE ".DB::table('tom_tcqianggou_focuspic')." ADD `type` tinyint(4) DEFAULT '1';\n";
}

if (!empty($sql)) {
    @runquery($sql);
}

$finish = TRUE;