<?php

/*
   Ӧ�ø���֧�֣�https://dism.taobao.com
   ���²����http://t.cn/Aiux1Jx1
   
   unionid ͬ���ű�

*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

set_time_limit(3600);

$payConfig = $_G['cache']['plugin']['tom_pay'];
$tomSysOffset = getglobal('setting/timeoffset');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    $orderList = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list(" AND order_status = 4 ","ORDER BY id DESC",0,10000);
    if(is_array($orderList) && !empty($orderList)){
        foreach ($orderList as $key => $value){
            $payOrderInfo = C::t('#tom_pay#tom_pay_order')->fetch_by_order_no($value['order_no']);
            if($payOrderInfo && $payOrderInfo['order_status'] == 2){
                echo $value['order_no'].'<hr>';
            }
        }
    }
    echo 'ok';
}else{
    exit('Access Denied');
}





