<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0, 0, 0, dgmdate($_G['timestamp'], 'n', $tomSysOffset), dgmdate($_G['timestamp'], 'j', $tomSysOffset), dgmdate($_G['timestamp'], 'Y', $tomSysOffset)) - $tomSysOffset * 3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = '20210426';
if (CHARSET == 'gbk') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/config/config.gbk.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/config/config.utf8.php';
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/qqface.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcqianggouConfig['wx_share_title'];
$shareDesc = $tcqianggouConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=index');
$shareLogo = $tcqianggouConfig['wx_share_pic'];
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')) {
	$tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
	if ($tcyikatongConfig['open_tcyikatong'] == 1) {
		$__ShowTcyikatong = 1;
	}
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$__ShowTcmall = 0;
$tcmallConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcmall/tom_tcmall.inc.php')) {
	$tcmallConfig = $_G['cache']['plugin']['tom_tcmall'];
	if ($tcmallConfig['open_tcmall'] == 1) {
		$__ShowTcmall = 1;
	}
}
$__ShowTcsign = 0;
$tcsignConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcsign/tom_tcsign.inc.php')) {
	$tcsignConfig = $_G['cache']['plugin']['tom_tcsign'];
	$__ShowTcsign = 1;
}
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')) {
	$tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
	if ($tcchoujiangConfig['open_tcchoujiang'] == 1) {
		$__ShowTcchoujiang = 1;
	}
}
$__ShowKuaidi = 0;
$kuaidiConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_kuaidi/tom_kuaidi.inc.php')) {
	$__ShowKuaidi = 1;
	$kuaidiConfig = $_G['cache']['plugin']['tom_kuaidi'];
}
$__ShowTcyuyue = 0;
$tcyuyueConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcyuyue/tom_tcyuyue.inc.php')) {
	$tcyuyueConfig = $_G['cache']['plugin']['tom_tcyuyue'];
	if ($tcyuyueConfig['open_tcyuyue'] == 1) {
		$__ShowTcyuyue = 1;
	}
}
$tcadminConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcadmin/tom_tcadmin.inc.php')) {
	$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
$__ShowZhibo = 0;
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_xiaofenlei/admin/zhibo.php')) {
	$__ShowZhibo = 1;
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$ajaxCommonClicksUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=commonClicks&formhash=' . $formhash;
$ajaxLoadPopupUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=load_popup&&formhash=' . $formhash;
$ajaxClosePopupUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=close_popup&&formhash=' . $formhash;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
$__CardInfo = array();
if ($__ShowTcyikatong == 1 && $__UserInfo['id'] > 0) {
	$cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($__UserInfo['id']);
	if (is_array($cardInfoTmp) && !empty($cardInfoTmp)) {
		$__CardInfo = $cardInfoTmp;
	}
}
if ($__ShowTcyikatong == 1) {
	$card_name = cutstr($tcyikatongConfig['card_name'], 6, '');
	$buyVipUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=card';
	if ($tcqianggouConfig['open_one_mode'] == 1) {
		$buyVipUrl = 'plugin.php?id=tom_tcyikatong&site=' . $site_id . '&mod=card&vfrom=qianggou';
	}
}
$template_color_rgb = '';
if (!empty($tcqianggouConfig['template_color'])) {
	$template_color_rgb = hex2rgbstr($tcqianggouConfig['template_color']);
}
if ($_GET['mod'] == 'index') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/site_ibs.php';
	$tj_hehuoren_id = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		if ($tchehuorenConfig['tcqianggou_type'] == 1 || $tchehuorenConfig['tcqianggou_type'] == 3) {
			if ($tj_hehuoren_id > 0) {
				$lifeTime = 86400;
				dsetcookie('tom_tcqianggou_tj_hehuoren_id', $tj_hehuoren_id, $lifeTime);
			} else {
				$cookie_tj_hehuoren_id = getcookie('tom_tcqianggou_tj_hehuoren_id');
				if ($cookie_tj_hehuoren_id > 0) {
					$tj_hehuoren_id = $cookie_tj_hehuoren_id;
				}
			}
		}
		if ($tchehuorenConfig['tcqianggou_type'] == 2 && $__UserInfo['tj_hehuoren_id'] > 0) {
			$tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
		}
		if ($tchehuorenConfig['tcqianggou_type'] == 3 && $__UserInfo['tj_hehuoren_id'] > 0 && $tj_hehuoren_id == 0) {
			$tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
		}
	}
	$focuspicListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY fsort ASC,id DESC ', 0, 20);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_focuspic')->fetch_all_list(' AND site_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 20);
	}
	$focuspicTopList = $focuspicZhongList = array();
	foreach ($focuspicListTmp as $key => $value) {
		if (!preg_match('/^http/', $value['picurl'])) {
			if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
				$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
			} else {
				$picurl = $value['picurl'];
			}
		} else {
			$picurl = $value['picurl'];
		}
		$linkTmp = str_replace('{site}', $site_id, $value['link']);
		if ($value['type'] == 1) {
			$focuspicTopList[$key] = $value;
			$focuspicTopList[$key]['picurl'] = $picurl;
			$focuspicTopList[$key]['link'] = $linkTmp;
		} elseif ($value['type'] == 2) {
			$focuspicZhongList[$key] = $value;
			$focuspicZhongList[$key]['picurl'] = $picurl;
			$focuspicZhongList[$key]['link'] = $linkTmp;
		}
	}
	$focuspicTopCount = count($focuspicTopList);
	$str_replace_search_array = array('{YIKATONG}', '{KANJIA}', '{PINTUAN}', '{QIANGGOU}', '{HAODIAN}', '{COUPON}', '{CHOUJIANG}', '{MALL}');
	$str_replace_search_replace = array($buyVipUrl, 'plugin.php?id=tom_tckjia&site=' . $site_id . '&mod=index', 'plugin.php?id=tom_tcptuan&site=' . $site_id . '&mod=index', 'plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=qianggoulist', 'plugin.php?id=tom_tcshop&site=' . $site_id . '&mod=index', 'plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=couponlist', 'plugin.php?id=tom_tcchoujiang&site=' . $site_id . '&mod=index', 'plugin.php?id=tom_tcmall&site=' . $site_id . '&mod=index');
	$menuList = array();
	$i = 1;
	if (!empty($tcqianggouConfig['index_nav'])) {
		$index_menu_str = str_replace($str_replace_search_array, $str_replace_search_replace, $tcqianggouConfig['index_nav']);
		$index_menu_str = str_replace('{site}', $site_id, $index_menu_str);
		$index_menu_str = str_replace("\r\n", '{n}', $index_menu_str);
		$index_menu_str = str_replace("\n", '{n}', $index_menu_str);
		$index_menu_arr = explode('{n}', $index_menu_str);
		if (is_array($index_menu_arr) && !empty($index_menu_arr)) {
			foreach ($index_menu_arr as $key => $value) {
				$menuList[$i] = explode('|', $value);
				$i++;
			}
		}
	}
	$menuCount = count($menuList);
	$line4NavList = array();
	if (!empty($tcqianggouConfig['index_line4_nav'])) {
		$index_line4_str = str_replace("\r\n", '{n}', trim($tcqianggouConfig['index_line4_nav']));
		$index_line4_str = str_replace("\n", '{n}', $index_line4_str);
		$index_line4_str = str_replace('{site}', $site_id, $index_line4_str);
		$index_line4_arr = explode('{n}', $index_line4_str);
		if (is_array($index_line4_arr) && !empty($index_line4_arr)) {
			foreach ($index_line4_arr as $key => $value) {
				$line4NavList[] = explode('|', $value);
			}
		}
	}
	$line4NavCount = count($line4NavList);
	$tradeList = array();
	if ($tcqianggouConfig['open_index_trade'] == 1) {
		$tradeWhereStr = ' AND is_recommend = 1 ';
		if ($tcqianggouConfig['open_trade_sites'] == 1 && !empty($sql_in_site_ids)) {
			$tradeWhereStr .= ' AND site_id IN(' . $sql_in_site_ids . ') ';
		} else {
			$tradeWhereStr .= ' AND site_id = ' . $site_id . ' ';
		}
		$tradeListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_trade')->fetch_all_list($tradeWhereStr, ' ORDER BY tsort ASC,id DESC ', 0, 100);
		foreach ($tradeListTmp as $key => $value) {
			$tradeList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$tradeList[$key]['picurl'] = $picurlTmp;
		}
	}
	$tradeCount = count($tradeList);
	$noStartQgGoodsList = array();
	if ($tcqianggouConfig['open_show_nostart_qianggou'] == 1) {
		$noStartQgGoodsListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list(' AND qiang_status = 2 AND site_id IN(' . $sql_in_site_ids . ') AND status=1 AND shenhe_status=1 AND type_id=1', 'ORDER BY paixu ASC,id DESC', 0, 10);
		if (is_array($noStartQgGoodsListTmp) && !empty($noStartQgGoodsListTmp)) {
			foreach ($noStartQgGoodsListTmp as $key => $value) {
				$qiang_status = update_qiang_status($value);
				if ($qiang_status == 2) {
					if ($value['show_buy_price'] <= 0) {
						$value['show_buy_price'] = floatval($value['buy_price']);
						$value['show_vip_price'] = floatval($value['vip_price']);
						$value['show_market_price'] = floatval($value['market_price']);
					} else {
						$value['show_buy_price'] = floatval($value['show_buy_price']);
						$value['show_vip_price'] = floatval($value['show_vip_price']);
						$value['show_market_price'] = floatval($value['show_market_price']);
					}
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					$noStartQgGoodsList[$key] = $value;
					$noStartQgGoodsList[$key]['picurl'] = $picurlTmp;
					$noStartQgGoodsList[$key]['ding_price'] = floatval($value['ding_price']);
				}
			}
		}
	}
	$noStartQgGoodsCount = count($noStartQgGoodsList);
	$recomCateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_list(' AND status = 1 AND site_id = ' . $site_id . ' ', 'ORDER BY csort asc,id DESC');
	if (!is_array($recomCateListTmp) || empty($recomCateListTmp)) {
		if ($site_id != 1) {
			$recomCateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_list(' AND status = 1 AND site_id = 1 ', 'ORDER BY csort asc,id DESC');
		}
	}
	$recomCateList = array();
	if (is_array($recomCateListTmp) && !empty($recomCateListTmp)) {
		foreach ($recomCateListTmp as $key => $value) {
			if ($value['type'] == 1) {
				if ($value['template_type'] == 2) {
					$recomGoodsListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list(' AND site_id IN(' . $sql_in_site_ids . ') AND recom_cate_id = ' . $value['id'] . ' AND status=1 AND shenhe_status=1 AND type_id=1', 'ORDER BY qiang_status ASC,paixu ASC,id DESC', 0, 100);
				} else {
					$recomGoodsListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list(' AND site_id IN(' . $sql_in_site_ids . ') AND recom_cate_id = ' . $value['id'] . ' AND status=1 AND shenhe_status=1 AND type_id=1', 'ORDER BY qiang_status ASC,paixu ASC,id DESC', 0, $value['index_show_num']);
				}
				$recomGoodsList = array();
				foreach ($recomGoodsListTmp as $k => $v) {
					if ($v['show_buy_price'] <= 0) {
						$v['show_buy_price'] = floatval($v['buy_price']);
						$v['show_vip_price'] = floatval($v['vip_price']);
						$v['show_market_price'] = floatval($v['market_price']);
					} else {
						$v['show_buy_price'] = floatval($v['show_buy_price']);
						$v['show_vip_price'] = floatval($v['show_vip_price']);
						$v['show_market_price'] = floatval($v['show_market_price']);
					}
					if ($v['open_xubuy'] == 1) {
						$qiangListCount = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(' AND goods_id=' . $v['id'] . ' AND type_id=2 ');
						$v['sale_num'] = $v['sale_num'] + $qiangListCount;
					}
					if (!preg_match('/^http/', $v['picurl'])) {
						if (strpos($v['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $v['picurl'];
						} else {
							$picurlTmp = $v['picurl'];
						}
					} else {
						$picurlTmp = $v['picurl'];
					}
					$shengyuNumTmp = $v['stock_num'] - $v['sale_num'];
					if ($shengyuNumTmp < 0) {
						$shengyuNumTmp = 0;
					}
					$lijian_price = $v['show_buy_price'] - $v['show_vip_price'];
					$recomGoodsList[$k] = $v;
					$recomGoodsList[$k]['picurl'] = $picurlTmp;
					$recomGoodsList[$k]['shengyu_num'] = $shengyuNumTmp;
					$recomGoodsList[$k]['sy_start_time'] = ($v['start_time'] - TIMESTAMP) * 1000;
					$recomGoodsList[$k]['sy_end_time'] = ($v['end_time'] - TIMESTAMP) * 1000;
					$recomGoodsList[$k]['ding_price'] = floatval($v['ding_price']);
					$recomGoodsList[$k]['clicks'] = $v['clicks'] + $v['virtual_clicks'];
					$recomGoodsList[$k]['lijian_price'] = intval($lijian_price);
					update_qiang_status($v);
				}
			} elseif ($value['type'] == 2) {
				$recomGoodsListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list(' AND recom_cate_id = ' . $value['id'] . ' AND status=1 AND shenhe_status=1 AND type_id IN(2,3,4) AND site_id IN(' . $sql_in_site_ids . ')  ', ' ORDER BY qiang_status ASC,paixu ASC,id DESC ', 0, $value['index_show_num']);
				$recomGoodsList = array();
				foreach ($recomGoodsListTmp as $k => $v) {
					$recomGoodsList[$k] = $v;
					if (!preg_match('/^http/', $v['picurl'])) {
						if (strpos($v['picurl'], 'source/plugin/tom_') === false) {
							$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $v['picurl'];
						} else {
							$picurl = $v['picurl'];
						}
					} else {
						$picurl = $v['picurl'];
					}
					$processTsTmp = $v['sale_num'] / $v['stock_num'] * 100;
					$processTsTmp = ceil($processTsTmp);
					$recomGoodsList[$k]['picurl'] = $picurl;
					$recomGoodsList[$k]['coupon_price'] = floatval($v['coupon_price']);
					$recomGoodsList[$k]['coupon_limit'] = floatval($v['coupon_limit']);
					$recomGoodsList[$k]['coupon_zhekou'] = floatval($v['coupon_zhekou']);
					$recomGoodsList[$k]['clicks'] = $v['clicks'] + $v['virtual_clicks'];
					$recomGoodsList[$k]['process_ts'] = $processTsTmp;
					if ($v['coupon_buy_price'] >= 10) {
						$recomGoodsList[$k]['coupon_buy_price'] = number_format($v['coupon_buy_price'], 0, '.', '');
					}
					update_qiang_status($v);
				}
			}
			$recomGoodsCount = count($recomGoodsList);
			if ($recomGoodsCount > 0) {
				$recomCateList[$key] = $value;
				if ($value['type'] == 1) {
					$recomCateList[$key]['tcqianggouList'] = $recomGoodsList;
				} elseif ($value['type'] == 2) {
					$recomCateList[$key]['couponList'] = $recomGoodsList;
				}
			}
		}
	}
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tcqianggou/images/index.js';
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=index'));
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=index');
	$ajaxIndexLoadListUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
	if ($__ShowTchehuoren == 1) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$shareUrl = $shareUrl . ('&tjid=' . $tchehuorenInfoTmp['id']);
		}
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqianggou:index');
	echo '<script src="source/plugin/tom_tcqianggou/images/index.js"></script>';
} elseif ($_GET['mod'] == 'details') {
	$goods_id = intval($_GET['goods_id']) > 0 ? intval($_GET['goods_id']) : 0;
	$tz_gzh_status = intval($_GET['tz_gzh_status']) > 0 ? intval($_GET['tz_gzh_status']) : 0;
	$tj_hehuoren_id = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		if ($tchehuorenConfig['tcqianggou_type'] == 1 || $tchehuorenConfig['tcqianggou_type'] == 3) {
			if ($tj_hehuoren_id > 0) {
				$lifeTime = 86400;
				dsetcookie('tom_tcqianggou_tj_hehuoren_id', $tj_hehuoren_id, $lifeTime);
			} else {
				$cookie_tj_hehuoren_id = getcookie('tom_tcqianggou_tj_hehuoren_id');
				if ($cookie_tj_hehuoren_id > 0) {
					$tj_hehuoren_id = $cookie_tj_hehuoren_id;
				}
			}
		}
		if ($tchehuorenConfig['tcqianggou_type'] == 2 && $__UserInfo['tj_hehuoren_id'] > 0) {
			$tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
		}
		if ($tchehuorenConfig['tcqianggou_type'] == 3 && $__UserInfo['tj_hehuoren_id'] > 0 && $tj_hehuoren_id == 0) {
			$tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
		}
		if ($tcqianggouConfig['open_hehuoren_self_sheng'] == 1) {
			$tchehuorenInfoTmpTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
			if ($tchehuorenInfoTmpTmp && $tchehuorenInfoTmpTmp['status'] == 1) {
				$tj_hehuoren_id = $tchehuorenInfoTmpTmp['id'];
			}
		}
	}
	$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
	if ($goodsInfo['id'] <= 0) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$is_duo_shop_manager = 0;
	if ($goodsInfo['open_duo_shop'] == 1) {
		$goodsShopListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->fetch_all_list(' AND goods_id=' . $goodsInfo['id'] . ' ', ' ORDER BY ssort ASC,id DESC ');
		$goodsShopList = array();
		if (is_array($goodsShopListTmp) && !empty($goodsShopListTmp)) {
			foreach ($goodsShopListTmp as $key => $value) {
				$tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
				if ($tcshopInfoTmp['status'] == 1 && $tcshopInfoTmp['shenhe_status'] == 1) {
					if ($tcshopInfoTmp['user_id'] == $__UserInfo['id']) {
						$is_duo_shop_manager = $value['id'];
					}
					$goodsShopList[$key] = $value;
					$goodsShopList[$key]['tcshopInfo'] = $tcshopInfoTmp;
					if (!preg_match('/^http/', $value['picurl'])) {
						if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
							$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
						} else {
							$picurlTmp = $value['picurl'];
						}
					} else {
						$picurlTmp = $value['picurl'];
					}
					$contentTmp = strip_tags($value['content']);
					$contentTmp = str_replace("\r\n", '', $contentTmp);
					$contentTmp = str_replace("\n", '', $contentTmp);
					$contentTmp = str_replace("\r", '', $contentTmp);
					$goodsShopList[$key]['picurl'] = $picurlTmp;
					$goodsShopList[$key]['contentTmp'] = $contentTmp;
					$goodsShopList[$key]['content'] = stripslashes($value['content']);
				}
			}
		}
		$goodsShopCount = count($goodsShopList);
	} else {
		$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
		if ($tcshopInfo['status'] == 1 && $tcshopInfo['shenhe_status'] == 1) {
			if (!empty($tcshopInfo['latitude']) && !empty($tcshopInfo['longitude']) && ($tcshopInfo['latitude'] != $goodsInfo['latitude'] || $tcshopInfo['longitude'] != $goodsInfo['longitude'])) {
				$updateData = array();
				$updateData['latitude'] = $tcshopInfo['latitude'];
				$updateData['longitude'] = $tcshopInfo['longitude'];
				C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($goodsInfo['id'], $updateData);
			}
		} else {
			if ($tcshopInfo['id'] > 0) {
				DB::query('UPDATE ' . DB::table('tom_tcqianggou_goods') . (' SET status=2 WHERE tcshop_id=' . $tcshopInfo['id'] . ' '), 'UNBUFFERED');
			} else {
				DB::query('UPDATE ' . DB::table('tom_tcqianggou_goods') . (' SET status=2 WHERE id=' . $goodsInfo['id'] . ' '), 'UNBUFFERED');
			}
			tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=index'));
			exit(0);
		}
	}
	if ($goodsInfo['show_buy_price'] <= 0) {
		$goodsInfo['show_buy_price'] = $goodsInfo['buy_price'];
		$goodsInfo['show_vip_price'] = $goodsInfo['vip_price'];
		$goodsInfo['show_market_price'] = $goodsInfo['market_price'];
		$goodsInfo['show_before_price'] = $goodsInfo['before_price'];
	}
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/tom_') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$picurl = $_G['siteurl'] . $goodsInfo['picurl'];
		}
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	if (!preg_match('/^http/', $goodsInfo['haibao_picurl'])) {
		if (strpos($goodsInfo['haibao_picurl'], 'source/plugin/tom_') === false) {
			$haibao_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['haibao_picurl'];
		} else {
			$haibao_picurl = $goodsInfo['haibao_picurl'];
		}
	} else {
		$haibao_picurl = $goodsInfo['haibao_picurl'];
	}
	if (empty($goodsInfo['haibao_text_color'])) {
		$goodsInfo['haibao_text_color'] = '#ffffff';
	}
	if (!preg_match('/^http/', $goodsInfo['toppic'])) {
		if (strpos($goodsInfo['toppic'], 'source/plugin/tom_') === false) {
			$toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['toppic'];
		} else {
			$toppic = $goodsInfo['toppic'];
		}
	} else {
		$toppic = $goodsInfo['toppic'];
	}
	if ($goodsInfo['open_xubuy'] == 1) {
		$qiangListCount = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(' AND goods_id=' . $goods_id . ' AND type_id=2 ');
		$goodsInfo['sale_num'] = $goodsInfo['sale_num'] + $qiangListCount;
	}
	DB::query('UPDATE ' . DB::table('tom_tcqianggou_goods') . (' SET clicks=clicks + 1 WHERE id=\'' . $goods_id . '\' '), 'UNBUFFERED');
	if ($goodsInfo['admin_edit'] == 1) {
		$content = stripslashes($goodsInfo['content']);
		$xuzhi = stripslashes($goodsInfo['xuzhi']);
	} else {
		$content = stripslashes($goodsInfo['content']);
		$content = strip_tags($content);
		$content = str_replace("\r\n", '<br/>', $content);
		$content = str_replace("\n", '<br/>', $content);
		$content = str_replace("\r", '<br/>', $content);
		$xuzhi = stripslashes($goodsInfo['xuzhi']);
		$xuzhi = strip_tags($xuzhi);
		$xuzhi = str_replace("\r\n", '<br/>', $xuzhi);
		$xuzhi = str_replace("\n", '<br/>', $xuzhi);
		$xuzhi = str_replace("\r", '<br/>', $xuzhi);
	}
	$goodsInfo['clicks'] = $goodsInfo['clicks'] + $goodsInfo['virtual_clicks'];
	$shengyu_stock_num = $goodsInfo['stock_num'] - $goodsInfo['sale_num'];
	if ($shengyu_stock_num < 0) {
		$shengyu_stock_num = 0;
	}
	$hexiao_start_time = dgmdate($goodsInfo['hexiao_start_time'], 'Y' . lang('plugin/tom_tcqianggou', 'year') . 'm' . lang('plugin/tom_tcqianggou', 'month') . 'd' . lang('plugin/tom_tcqianggou', 'day'), $tomSysOffset);
	$hexiao_time = dgmdate($goodsInfo['hexiao_time'], 'Y' . lang('plugin/tom_tcqianggou', 'year') . 'm' . lang('plugin/tom_tcqianggou', 'month') . 'd' . lang('plugin/tom_tcqianggou', 'day'), $tomSysOffset);
	if ($__CardInfo['status'] == 1 && $goodsInfo['open_vip'] == 1) {
		$shenyu_price = $goodsInfo['show_vip_price'] - $goodsInfo['ding_price'];
	} else {
		$shenyu_price = $goodsInfo['show_buy_price'] - $goodsInfo['ding_price'];
	}
	$end_time = dgmdate($goodsInfo['end_time'], 'Y-m-d', $tomSysOffset);
	$hb_hexiao_time = dgmdate($goodsInfo['hexiao_time'], 'Y-m-d', $tomSysOffset);
	$yushouStatus = 0;
	if ($goodsInfo['peisong_type'] == 1 && $goodsInfo['hexiao_start_time'] > 0 && $goodsInfo['hexiao_start_time'] > TIMESTAMP) {
		$yushouStatus = 1;
	}
	$score_yuan = $tongchengConfig['score_yuan'];
	if (!empty($tcqianggouConfig['score_yuan'])) {
		$score_yuan = $tcqianggouConfig['score_yuan'];
	}
	$pay_price_tmp = 0;
	if ($goodsInfo['type_id'] == 1) {
		if ($tcqianggouConfig['open_ding_price'] == 1 && $goodsInfo['open_ding_pay'] == 1) {
			$pay_price_tmp = $goodsInfo['ding_price'];
		} else {
			$pay_price_tmp = $goodsInfo['show_buy_price'];
		}
	} elseif ($goodsInfo['coupon_is_buy'] == 1) {
		$pay_price_tmp = $goodsInfo['coupon_buy_price'];
	}
	$back_score = ceil($pay_price_tmp * $score_yuan);
	$daojishiBox = 0;
	$syTime = 0;
	$tzShowBtn = 0;
	$tzUserStatus = 0;
	$subscribeStatus = 0;
	if (TIMESTAMP < $goodsInfo['start_time']) {
		$daojishiBox = 1;
		$syTime = ($goodsInfo['start_time'] - TIMESTAMP) * 1000;
		$tzShowBtn = 1;
		if ($__UserInfo['id'] > 0) {
			$goodsTzInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_tz')->fetch_by(' AND user_id = ' . $__UserInfo['id'] . ' AND goods_id = ' . $goodsInfo['id'] . ' AND type = 1 ');
			if (is_array($goodsTzInfo) && !empty($goodsTzInfo)) {
				$tzShowBtn = 2;
			}
			if ($tz_gzh_status == 1 && $tzShowBtn == 1) {
				$insertData = array();
				$insertData['goods_id'] = $goods_id;
				$insertData['type'] = 1;
				$insertData['user_id'] = $__UserInfo['id'];
				$insertData['openid'] = $__UserInfo['openid'];
				$insertData['add_time'] = TIMESTAMP;
				C::t('#tom_tcqianggou#tom_tcqianggou_goods_tz')->insert($insertData);
				$tzShowBtn = 2;
				$tzUserStatus = 1;
				$ajaxGzSendTemplateQianggouUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=gz_send_nostart_template_sms&goods_id=' . $goods_id . '&formhash=' . $formhash;
			}
			$access_token = $weixinClass->get_access_token();
			if (!empty($__UserInfo['openid']) && !empty($access_token)) {
				$get_user_info_url = 'https://api.weixin.qq.com/cgi-bin/user/info?access_token=' . $access_token . '&openid=' . $__UserInfo['openid'] . '&lang=zh_CN';
				$return = get_html($get_user_info_url);
				if (!empty($return)) {
					$tcContent = json_decode($return, true);
					if (is_array($tcContent) && !empty($tcContent) && isset($tcContent['subscribe'])) {
						if ($tcContent['subscribe'] == 1) {
							$subscribeStatus = 1;
						} else {
							$tzShowBtn = 1;
						}
					}
				}
			}
			$gzhQrcodeUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=details&goods_id=' . $goods_id . '&tz_gzh_status=1');
			$gzhQrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($gzhQrcodeUrl);
			$ajaxGzQianggouUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=gz_nostart_goods&goods_id=' . $goods_id . '&formhash=' . $formhash;
		}
	} else {
		if (TIMESTAMP > $goodsInfo['end_time']) {
			$daojishiBox = 2;
		} else {
			if ($goodsInfo['end_time'] > TIMESTAMP) {
				$daojishiBox = 3;
				$syTime = ($goodsInfo['end_time'] - TIMESTAMP) * 1000;
			}
		}
	}
	$goodsInfo['qiang_status'] = update_qiang_status($goodsInfo);
	$showBuyBtn = 0;
	if ($goodsInfo['status'] == 1 && $goodsInfo['shenhe_status'] == 1 && $goodsInfo['qiang_status'] == 1) {
		$showBuyBtn = 1;
	}
	$showTopTuijianBox = 0;
	if ($daojishiBox == 2 || $daojishiBox == 3 && $showBuyBtn == 0) {
		$tjGoodsListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_list(' AND site_id = ' . $site_id . ' AND status=1 AND shenhe_status=1 AND type_id=1 AND qiang_status=1 ', 'ORDER BY qiang_status ASC,paixu ASC,id DESC', 0, 4);
		$tjGoodsList = array();
		foreach ($tjGoodsListTmp as $key => $value) {
			if ($value['show_buy_price'] <= 0) {
				$value['show_buy_price'] = floatval($value['buy_price']);
				$value['show_vip_price'] = floatval($value['vip_price']);
				$value['show_market_price'] = floatval($value['market_price']);
			} else {
				$value['show_buy_price'] = floatval($value['show_buy_price']);
				$value['show_vip_price'] = floatval($value['show_vip_price']);
				$value['show_market_price'] = floatval($value['show_market_price']);
			}
			if ($value['open_xubuy'] == 1) {
				$qiangListCount = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(' AND goods_id=' . $value['id'] . ' AND type_id=2 ');
				$value['sale_num'] = $value['sale_num'] + $qiangListCount;
			}
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurlTmp = $value['picurl'];
				}
			} else {
				$picurlTmp = $value['picurl'];
			}
			$tjGoodsList[$key] = $value;
			$tjGoodsList[$key]['sy_time'] = ($value['end_time'] - TIMESTAMP) * 1000;
			$tjGoodsList[$key]['picurl'] = $picurlTmp;
			$tjGoodsList[$key]['ding_price'] = floatval($value['ding_price']);
			$tjGoodsList[$key]['clicks'] = $value['clicks'] + $value['virtual_clicks'];
			$tjGoodsList[$key]['lijian_price'] = $value['show_buy_price'] - $value['show_vip_price'];
			update_qiang_status($value);
		}
		$tjGoodsCount = count($tjGoodsList);
		if ($tjGoodsCount > 0) {
			$showTopTuijianBox = 1;
		}
	}
	$show_max_buy_price = 0;
	$show_max_market_price = 0;
	$show_max_vip_price = 0;
	$show_max_before_price = 0;
	if ($goodsInfo['hasoption'] == 1) {
		$optionListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_all_list('AND goods_id = ' . $goodsInfo['id'], 'ORDER BY osort ASC, id ASC', 0, 100);
		$optionList = array();
		if (is_array($optionListTmp) && !empty($optionListTmp)) {
			foreach ($optionListTmp as $key => $value) {
				if ($goodsInfo['open_xubuy'] == 1) {
					$optionQiangListCount = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count(' AND goods_id=' . $goods_id . ' AND type_id=2 AND option_id = ' . $value['id'] . ' ');
					$value['sale_num'] = $value['sale_num'] + $optionQiangListCount;
				}
				$optionList[$key] = $value;
				$syStockTmp = $value['stock_num'] - $value['sale_num'];
				if ($syStockTmp < 0) {
					$syStockTmp = 0;
				}
				$optionList[$key]['sy_stock'] = $syStockTmp;
				if ($value['buy_price'] > $show_max_buy_price) {
					$show_max_buy_price = $value['buy_price'];
				}
				if ($value['market_price'] > $show_max_market_price) {
					$show_max_market_price = $value['market_price'];
				}
				if ($value['vip_price'] > $show_max_vip_price) {
					$show_max_vip_price = $value['vip_price'];
				}
				if ($value['before_price'] > $show_max_before_price) {
					$show_max_before_price = $value['before_price'];
				}
			}
		}
		$optionCount = count($optionList);
	}
	if ($goodsInfo['show_vip_price'] > 100 && $goodsInfo['hasoption'] == 1) {
		$goodsInfo['show_vip_price'] = intval($goodsInfo['show_vip_price']);
	}
	if ($show_max_vip_price > 100 && $goodsInfo['hasoption'] == 1) {
		$show_max_vip_price = intval($show_max_vip_price);
	}
	$showVipPriceStatus = 0;
	if ($__ShowTcyikatong == 1 && $goodsInfo['open_vip'] == 1) {
		$showVipPriceStatus = 1;
	}
	$photoListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->fetch_all_list(' AND goods_id=' . $goods_id . ' ', 'ORDER BY id ASC', 0, 50);
	$photoList = array();
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			$photoList[$key] = $value;
		}
	}
	$qiangListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list(' AND goods_id=' . $goods_id . ' AND order_status IN(2,3) ', ' ORDER BY id DESC ', 0, 5);
	$qiangCount = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(' AND goods_id=' . $goods_id . ' AND order_status IN(2,3) ');
	$qiangList = array();
	if ($goodsInfo['open_xubuy'] == 1) {
		if (is_array($qiangListTmp) && !empty($qiangListTmp)) {
			foreach ($qiangListTmp as $key => $value) {
				$xubuyInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_by_order_id($value['id']);
				if (!$xubuyInfoTmp || $xubuyInfoTmp['id'] <= 0) {
					$insertData = array();
					$insertData['goods_id'] = $value['goods_id'];
					$insertData['type_id'] = 1;
					$insertData['order_id'] = $value['id'];
					$insertData['user_id'] = $value['user_id'];
					$insertData['goods_num'] = $value['goods_num'];
					$insertData['order_time'] = $value['order_time'];
					C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->insert($insertData);
				}
			}
		}
		$qiangListTmp = array();
		$qiangListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_list(' AND goods_id=' . $goods_id . ' ', ' ORDER BY order_time DESC,id DESC ', 0, 5);
		$qiangCount = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_list(' AND goods_id=' . $goods_id . ' ');
	}
	if (is_array($qiangListTmp) && !empty($qiangListTmp)) {
		foreach ($qiangListTmp as $key => $value) {
			$qiangList[$key] = $value;
			$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$qiangList[$key]['userInfo'] = $userInfoTmp;
		}
	}
	if ($tcqianggouConfig['info_can_list_type'] == 2) {
		$clicksListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_clicks')->fetch_all_list(' AND goods_id=' . $goods_id . ' ', ' ORDER BY id DESC ', 0, 5);
		$clicksCount = C::t('#tom_tcqianggou#tom_tcqianggou_goods_clicks')->fetch_all_count(' AND goods_id=' . $goods_id . ' ');
		$clicksList = array();
		if (is_array($clicksListTmp) && !empty($clicksListTmp)) {
			foreach ($clicksListTmp as $key => $value) {
				$clicksList[$key] = $value;
				$userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
				$clicksList[$key]['userInfo'] = $userInfoTmp;
			}
		}
	}
	$qrcodeInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->fetch_by(' AND goods_id = ' . $goods_id . ' AND site_id = ' . $site_id . ' AND status = 1 ');
	if (!is_array($qrcodeInfoTmp) || empty($qrcodeInfoTmp)) {
		$qrcodeInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->fetch_by(' AND goods_id = 0 AND site_id = ' . $site_id . ' AND status = 1 ');
		if (!is_array($qrcodeInfoTmp) || empty($qrcodeInfoTmp)) {
			if ($site_id != 1) {
				$qrcodeInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->fetch_by(' AND goods_id = 0 AND site_id = 1 AND status = 1 ');
			}
		}
	}
	$qrcodeInfo = array();
	if (is_array($qrcodeInfoTmp) && !empty($qrcodeInfoTmp)) {
		$qrcodeInfo = $qrcodeInfoTmp;
		if (!preg_match('/^http/', $qrcodeInfoTmp['logo'])) {
			if (strpos($qrcodeInfoTmp['logo'], 'source/plugin/tom_') === false) {
				$qrcodeInfo['logo'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $qrcodeInfoTmp['logo'];
			} else {
				$qrcodeInfo['logo'] = $qrcodeInfoTmp['logo'];
			}
		} else {
			$qrcodeInfo['logo'] = $qrcodeInfoTmp['logo'];
		}
		if (!preg_match('/^http/', $qrcodeInfoTmp['qrcode'])) {
			if (strpos($qrcodeInfoTmp['qrcode'], 'source/plugin/tom_') === false) {
				$qrcodeInfo['qrcode'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $qrcodeInfoTmp['qrcode'];
			} else {
				$qrcodeInfo['qrcode'] = $qrcodeInfoTmp['qrcode'];
			}
		} else {
			$qrcodeInfo['qrcode'] = $qrcodeInfoTmp['qrcode'];
		}
	}
	if (!preg_match('/^http/', $tcshopInfo['kefu_qrcode'])) {
		if (strpos($tcshopInfo['kefu_qrcode'], 'source/plugin/tom_') === false) {
			$kefu_qrcode = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $tcshopInfo['kefu_qrcode'];
		} else {
			$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
		}
	} else {
		$kefu_qrcode = $tcshopInfo['kefu_qrcode'];
	}
	$orderListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list(' AND goods_id=' . $goodsInfo['id'] . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 6);
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tcqianggou_goods') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcqianggou_order') . (' SET order_status=4 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
					if ($value['option_id'] > 0) {
						DB::query('UPDATE ' . DB::table('tom_tcqianggou_goods_option') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['option_id'] . '\' '), 'UNBUFFERED');
					}
					if ($value['code_order'] == 1) {
						DB::query('UPDATE ' . DB::table('tom_tcqianggou_code') . (' SET order_id=0,order_no=\'\',user_id=0,code_status=0 WHERE goods_id=' . $value['goods_id'] . ' AND order_id=' . $value['id'] . ' '), 'UNBUFFERED');
					}
				}
			}
		}
	}
	$showTgButton = 0;
	if ($__ShowTchehuoren == 1 && $goodsInfo['hehuoren_tg_open'] == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfo['id'] > 0) {
			if ($tchehuorenInfo['status'] == 1) {
				$dengjiInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
				$dengjiInfo = array();
				if (is_array($dengjiInfoTmp) && !empty($dengjiInfoTmp)) {
					$dengjiInfo = $dengjiInfoTmp;
				}
				if ($dengjiInfo['qg_fc_open'] == 1) {
					if ($goodsInfo['site_id'] > 1) {
						$siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($goodsInfo['site_id']);
						if ($siteInfoTmp['hehuoren_fc_open'] == 1) {
							$showTgButton = 1;
						}
					} else {
						if ($goodsInfo['site_id'] == 1) {
							$showTgButton = 1;
						}
					}
				}
				if ($showTgButton == 1) {
					$needPrice = 0;
					$yongjin_bili = $tcqianggouConfig['yongjin_bili'];
					if ($goodsInfo['yongjin_bili'] > 0) {
						$yongjin_bili = $goodsInfo['yongjin_bili'];
					}
					$pay_price = 0;
					if ($goodsInfo['type_id'] == 1) {
						if ($tcqianggouConfig['open_ding_price'] == 1 && $goodsInfo['open_ding_pay'] == 1) {
							$pay_price = $goodsInfo['ding_price'];
						} else {
							$pay_price = $goodsInfo['show_buy_price'];
						}
					} elseif ($goodsInfo['coupon_is_buy'] == 1) {
						$pay_price = $goodsInfo['coupon_buy_price'];
					}
					$pt_money = $pay_price;
					if ($goodsInfo['open_shop_yongjin'] == 1) {
						$pt_money = $pay_price - $goodsInfo['shop_yongjin'];
					} else {
						if ($goodsInfo['yongjin_type'] == 2) {
							$pt_money = $goodsInfo['yongjin_bili'];
						} else {
							$pt_money = $pay_price * ($yongjin_bili / 100);
							$pt_money = number_format($pt_money, 2, '.', '');
						}
					}
					$min_num = 1;
					if ($goodsInfo['min_num'] > 1) {
						$min_num = $goodsInfo['min_num'];
					}
					if ($dengjiInfo['level'] == 1) {
						if ($goodsInfo['yongjin_type'] == 2) {
							$needPrice = $goodsInfo['chuji_fc_scale'];
						} else {
							$needPrice = $pt_money * ($goodsInfo['chuji_fc_scale'] / 100);
						}
					} elseif ($dengjiInfo['level'] == 2) {
						if ($goodsInfo['yongjin_type'] == 2) {
							$needPrice = $goodsInfo['zhongji_fc_scale'];
						} else {
							$needPrice = $pt_money * ($goodsInfo['zhongji_fc_scale'] / 100);
						}
					} elseif ($dengjiInfo['level'] == 3) {
						if ($goodsInfo['yongjin_type'] == 2) {
							$needPrice = $goodsInfo['gaoji_fc_scale'];
						} else {
							$needPrice = $pt_money * ($goodsInfo['gaoji_fc_scale'] / 100);
						}
					}
					$needPrice = number_format($needPrice * $min_num, 2, '.', '');
					$tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
					if ($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1) {
						$tctchehuorenParentInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
						$tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
					}
					if (!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1) {
						if ($tctchehuorenParentDengji['level'] == 1) {
							if ($goodsInfo['yongjin_type'] == 2) {
								$tctchehuorenParent_fc_money = $goodsInfo['chuji_fc_scale2'];
							} else {
								if ($goodsInfo['chuji_fc_scale2'] > 0 && $goodsInfo['chuji_fc_scale2'] < 100) {
									$tctchehuorenParent_fc_money = $needPrice * ($goodsInfo['chuji_fc_scale2'] / 100);
								} else {
									$tctchehuorenParent_fc_money = $needPrice * ($tctchehuorenParentDengji['tuijian_fc_scale'] / 100);
								}
							}
						} elseif ($tctchehuorenParentDengji['level'] == 2) {
							if ($goodsInfo['yongjin_type'] == 2) {
								$tctchehuorenParent_fc_money = $goodsInfo['zhongji_fc_scale2'];
							} else {
								if ($goodsInfo['zhongji_fc_scale2'] > 0 && $goodsInfo['zhongji_fc_scale2'] < 100) {
									$tctchehuorenParent_fc_money = $needPrice * ($goodsInfo['zhongji_fc_scale2'] / 100);
								} else {
									$tctchehuorenParent_fc_money = $needPrice * ($tctchehuorenParentDengji['tuijian_fc_scale'] / 100);
								}
							}
						} elseif ($tctchehuorenParentDengji['level'] == 3) {
							if ($goodsInfo['yongjin_type'] == 2) {
								$tctchehuorenParent_fc_money = $goodsInfo['gaoji_fc_scale2'];
							} else {
								if ($goodsInfo['gaoji_fc_scale2'] > 0 && $goodsInfo['gaoji_fc_scale2'] < 100) {
									$tctchehuorenParent_fc_money = $needPrice * ($goodsInfo['gaoji_fc_scale2'] / 100);
								} else {
									$tctchehuorenParent_fc_money = $needPrice * ($tctchehuorenParentDengji['tuijian_fc_scale'] / 100);
								}
							}
						}
						$tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money, 2, '.', '');
						if ($tchehuorenConfig['subordinate_moneytype'] != 1) {
							$needPrice = $needPrice - $tctchehuorenParent_fc_money;
						}
					}
					$tchehuorenUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=details&goods_id=' . $goods_id . '&tj_hehuoren_id=' . $tchehuorenInfo['id']);
				}
			}
		} else {
			if ($tcqianggouConfig['open_hehuoren_add'] == 1) {
				if ($goodsInfo['site_id'] > 1) {
					$siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($goodsInfo['site_id']);
					if ($siteInfoTmp['hehuoren_fc_open'] == 1) {
						$showTgButton = 2;
					}
				} else {
					if ($goodsInfo['site_id'] == 1) {
						$showTgButton = 2;
					}
				}
				if ($showTgButton == 2) {
					$needPrice = 0;
					$yongjin_bili = $tcqianggouConfig['yongjin_bili'];
					if ($goodsInfo['yongjin_bili'] > 0) {
						$yongjin_bili = $goodsInfo['yongjin_bili'];
					}
					$pay_price = 0;
					if ($goodsInfo['type_id'] == 1) {
						if ($tcqianggouConfig['open_ding_price'] == 1 && $goodsInfo['open_ding_pay'] == 1) {
							$pay_price = $goodsInfo['ding_price'];
						} else {
							$pay_price = $goodsInfo['show_buy_price'];
						}
					} elseif ($goodsInfo['coupon_is_buy'] == 1) {
						$pay_price = $goodsInfo['coupon_buy_price'];
					}
					$pt_money = $pay_price;
					if ($goodsInfo['open_shop_yongjin'] == 1) {
						$pt_money = $pay_price - $goodsInfo['shop_yongjin'];
					} else {
						if ($goodsInfo['yongjin_type'] == 2) {
							$pt_money = $goodsInfo['yongjin_bili'];
						} else {
							$pt_money = $pay_price * ($yongjin_bili / 100);
							$pt_money = number_format($pt_money, 2, '.', '');
						}
					}
					$min_num = 1;
					if ($goodsInfo['min_num'] > 1) {
						$min_num = $goodsInfo['min_num'];
					}
					if ($goodsInfo['yongjin_type'] == 2) {
						$needPrice = $goodsInfo['chuji_fc_scale'] * $min_num;
					} else {
						$needPrice = $pt_money * ($goodsInfo['chuji_fc_scale'] / 100) * $min_num;
					}
					$needPrice = number_format($needPrice, 2, '.', '');
				}
			}
		}
	}
	$cookiesHehuorenAdd = getcookie('tom_tcqianggou_hehuoren_add_close');
	if ($cookiesHehuorenAdd == 1) {
		$showHehuorenAddStatus = 0;
	} else {
		$showHehuorenAddStatus = 1;
	}
	$ajaxCloseHehuorenAddUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=hide_hehuoren_add&formhash=' . $formhash;
	$showTcyikatongBtn = 0;
	if ($__ShowTcyikatong == 1 && $goodsInfo['open_vip'] == 1 && $goodsInfo['type_id'] == 1) {
		$showTcyikatongBtn = 1;
		$lijian_vip_price = intval($goodsInfo['show_buy_price'] * 100 - $goodsInfo['show_vip_price'] * 100) / 100;
		$lijian_max_vip_price = intval($show_max_buy_price * 100 - $show_max_vip_price * 100) / 100;
	}
	$showBeforeBuyBox = 0;
	$shengyuBeforeNum = 0;
	if ($goodsInfo['open_before'] == 1 && $goodsInfo['show_before_price'] > 0 && $goodsInfo['before_num'] > 0 && $goodsInfo['type_id'] == 1) {
		$userBeforeOrderInfoTmp = array();
		if ($__UserInfo['id'] > 0) {
			$userBeforeOrderInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_List(' AND goods_id=' . $goodsInfo['id'] . ' AND before_pay_status = 1 AND order_status IN(1,2,3) AND user_id = ' . $__UserInfo['id'] . ' ', 'ORDER BY id DESC', 0, 1);
		}
		if (!is_array($userBeforeOrderInfoTmp) || empty($userBeforeOrderInfoTmp[0])) {
			$before_sale_count = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(' AND goods_id=' . $goodsInfo['id'] . ' AND before_pay_status = 1 AND order_status IN(1,2,3) ');
			if ($before_sale_count < $goodsInfo['before_num']) {
				$shengyuBeforeNum = $goodsInfo['before_num'] - $before_sale_count;
				$showBeforeBuyBox = 1;
				$showTcyikatongBtn = 0;
				$showVipPriceStatus = 0;
			}
		}
	}
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tcshopConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$baiduMapToName = $tcshopInfo['name'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tcshopInfo['latitude'] . ',' . $tcshopInfo['longitude'] . '&title=' . $baiduMapToName . '&content=&output=html';
	$ajaxLoadQiangListUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=qianglist&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$showMoreQianggouStatus = 0;
	if ($tcqianggouConfig['open_details_more'] == 1) {
		$showMoreQianggouStatus = 1;
		$ajaxIndexLoadListUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=list&tongcheng_show=3&no_goods_id=' . $goods_id . '&qiang_status=1&formhash=' . $formhash;
	}
	if (!empty($goodsInfo['qianggou_ids'])) {
		$showMoreQianggouStatus = 1;
		$ajaxIndexLoadListUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=list&tongcheng_show=3&no_goods_id=' . $goods_id . '&qianggou_ids=' . $goodsInfo['qianggou_ids'] . '&formhash=' . $formhash;
	}
	$ptkefuSmsUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&&to_user_id=' . $tongchengConfig['manage_user_id'] . '&tcqianggou_goods_id=' . $goods_id . '&formhash=' . FORMHASH;
	$kefuSmsUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&&to_user_id=' . $tcshopInfo['user_id'] . '&tcqianggou_goods_id=' . $goods_id . '&formhash=' . FORMHASH;
	if (!empty($goodsInfo['share_title'])) {
		$shareTitle = $goodsInfo['share_title'];
	} else {
		$shareTitle = str_replace('{TITLE}', $goodsInfo['title'], $tcqianggouConfig['details_share_title']);
		$shareTitle = str_replace('{SHOPNAME}', $tcshopInfo['name'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($goodsInfo['share_desc'])) {
		$shareDesc = $goodsInfo['share_desc'];
	} else {
		$contentTmp = strip_tags($content);
		$contentTmp = str_replace("\r\n", '', $contentTmp);
		$contentTmp = str_replace("\n", '', $contentTmp);
		$contentTmp = str_replace("\r", '', $contentTmp);
		$shareDesc = cutstr($contentTmp, 80, '...');
	}
	$shareLogo = $picurl;
	if ($showTgButton == 1) {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=details&goods_id=' . $goods_id . '&tj_hehuoren_id=' . $tchehuorenInfo['id']);
	} else {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=details&goods_id=') . $goods_id;
	}
	if ($tj_hehuoren_id > 0 && $goodsInfo['hehuoren_tg_open'] == 1) {
		$qianggouUrl = 'plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=buy&goods_id=' . $goods_id . '&tj_hehuoren_id=' . $tj_hehuoren_id;
	} else {
		$qianggouUrl = 'plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=buy&goods_id=' . $goods_id;
	}
	$haibaoQrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($shareUrl);
	$haibaoNickname = cutstr($__UserInfo['nickname'], 12, '...');
	$ajaxGoodsClickUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=goods_click&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$showZhiboBox = 0;
	if ($__ShowZhibo == 1 && $goodsInfo['zhibo_roomid'] > 0) {
		$zhiboInfo = C::t('#tom_xiaofenlei#tom_xiaofenlei_zhibo')->fetch_by_roomid($goodsInfo['zhibo_roomid']);
		if ($zhiboInfo && $zhiboInfo['id'] > 0 && $zhiboInfo['end_time'] > TIMESTAMP) {
			$showZhiboBox = 1;
			if (!preg_match('/^http/', $zhiboInfo['cover_img'])) {
				if (strpos($zhiboInfo['cover_img'], 'source/plugin/tom_') === false) {
					$zhiboInfo['cover_img'] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $zhiboInfo['cover_img'];
				} else {
					$zhiboInfo['cover_img'] = rtrim($_G['siteurl'], '/') . '/' . $zhiboInfo['cover_img'];
				}
			}
		}
	}
	if ($__ShowTcsign == 1) {
		include DISCUZ_ROOT . './source/plugin/tom_tcsign/renwu/qianggou.php';
	}
	$detailsXuzhiAdsInfo = array();
	if (!empty($tcqianggouConfig['details_xuzhi_ads'])) {
		$details_xuzhi_ads = str_replace('{site}', $site_id, trim($tcqianggouConfig['details_xuzhi_ads']));
		$detailsXuzhiAdsInfo = explode('|', $details_xuzhi_ads);
	}
	$detailsJiesaoAdsInfo = array();
	if (!empty($tcqianggouConfig['details_jiesao_ads'])) {
		$details_jiesao_ads = str_replace('{site}', $site_id, trim($tcqianggouConfig['details_jiesao_ads']));
		$detailsJiesaoAdsInfo = explode('|', $details_jiesao_ads);
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqianggou:details');
} elseif ($_GET['mod'] == 'qianglist') {
	$goods_id = intval($_GET['goods_id']) > 0 ? intval($_GET['goods_id']) : 0;
	$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	$ajaxLoadQiangListUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=qianglist&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqianggou:qianglist');
} elseif ($_GET['mod'] == 'coupon') {
	$goods_id = intval($_GET['goods_id']) > 0 ? intval($_GET['goods_id']) : 0;
	$tj_hehuoren_id = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		if ($tchehuorenConfig['tcqianggou_type'] == 1 || $tchehuorenConfig['tcqianggou_type'] == 3) {
			if ($tj_hehuoren_id > 0) {
				$lifeTime = 86400;
				dsetcookie('tom_tcqianggou_tj_hehuoren_id', $tj_hehuoren_id, $lifeTime);
			} else {
				$cookie_tj_hehuoren_id = getcookie('tom_tcqianggou_tj_hehuoren_id');
				if ($cookie_tj_hehuoren_id > 0) {
					$tj_hehuoren_id = $cookie_tj_hehuoren_id;
				}
			}
		}
		if ($tchehuorenConfig['tcqianggou_type'] == 2 && $__UserInfo['tj_hehuoren_id'] > 0) {
			$tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
		}
		if ($tchehuorenConfig['tcqianggou_type'] == 3 && $__UserInfo['tj_hehuoren_id'] > 0 && $tj_hehuoren_id == 0) {
			$tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
		}
		if ($tcqianggouConfig['open_hehuoren_self_sheng'] == 1) {
			$tchehuorenInfoTmpTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
			if ($tchehuorenInfoTmpTmp && $tchehuorenInfoTmpTmp['status'] == 1) {
				$tj_hehuoren_id = $tchehuorenInfoTmpTmp['id'];
			}
		}
	}
	$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
	$tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
	if (!empty($tcshopInfo['latitude']) && !empty($tcshopInfo['longitude']) && ($tcshopInfo['latitude'] != $goodsInfo['latitude'] || $tcshopInfo['longitude'] != $goodsInfo['longitude'])) {
		$updateData = array();
		$updateData['latitude'] = $tcshopInfo['latitude'];
		$updateData['longitude'] = $tcshopInfo['longitude'];
		C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($goodsInfo['id'], $updateData);
	}
	if (!preg_match('/^http/', $goodsInfo['picurl'])) {
		if (strpos($goodsInfo['picurl'], 'source/plugin/tom_') === false) {
			$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['picurl'];
		} else {
			$picurl = $_G['siteurl'] . $goodsInfo['picurl'];
		}
	} else {
		$picurl = $goodsInfo['picurl'];
	}
	if (!preg_match('/^http/', $goodsInfo['toppic'])) {
		if (strpos($goodsInfo['toppic'], 'source/plugin/tom_') === false) {
			$toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['toppic'];
		} else {
			$toppic = $goodsInfo['toppic'];
		}
	} else {
		$toppic = $goodsInfo['toppic'];
	}
	DB::query('UPDATE ' . DB::table('tom_tcqianggou_goods') . (' SET clicks=clicks + 1 WHERE id=\'' . $goods_id . '\' '), 'UNBUFFERED');
	if ($goodsInfo['admin_edit'] == 1) {
		$content = stripslashes($goodsInfo['content']);
	} else {
		$content = stripslashes($goodsInfo['content']);
		$content = strip_tags($content);
		$content = str_replace("\r\n", '<br/>', $content);
		$content = str_replace("\n", '<br/>', $content);
		$content = str_replace("\r", '<br/>', $content);
	}
	$back_score = $goodsInfo['coupon_price'] * $tongchengConfig['score_yuan'];
	$shengyu_stock_num = $goodsInfo['stock_num'] - $goodsInfo['sale_num'];
	if ($shengyu_stock_num < 0) {
		$shengyu_stock_num = 0;
	}
	$hexiao_start_time = dgmdate($goodsInfo['hexiao_start_time'], 'Y' . lang('plugin/tom_tcqianggou', 'year') . 'm' . lang('plugin/tom_tcqianggou', 'month') . 'd' . lang('plugin/tom_tcqianggou', 'day'), $tomSysOffset);
	$hexiao_time = dgmdate($goodsInfo['hexiao_time'], 'Y' . lang('plugin/tom_tcqianggou', 'year') . 'm' . lang('plugin/tom_tcqianggou', 'month') . 'd' . lang('plugin/tom_tcqianggou', 'day'), $tomSysOffset);
	$goodsInfo['qiang_status'] = update_qiang_status($goodsInfo);
	$showBuyBtn = 0;
	if ($goodsInfo['status'] == 1 && $goodsInfo['shenhe_status'] == 1 && $goodsInfo['qiang_status'] == 1) {
		$showBuyBtn = 1;
	}
	if (!$ucenterfilenameExists) {
		$showBuyBtn = 2;
	}
	$showTcyikatongBtn = 0;
	if ($__ShowTcyikatong == 1 && $goodsInfo['open_vip'] == 1) {
		$showTcyikatongBtn = 1;
	}
	$photoListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->fetch_all_list(' AND goods_id=' . $goods_id . ' ', 'ORDER BY id ASC', 0, 10);
	$photoList = array();
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			$photoList[$key] = $value;
		}
	}
	$orderListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list(' AND goods_id=' . $goodsInfo['id'] . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 6);
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tcqianggou_goods') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcqianggou_order') . (' SET order_status=4 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
					if ($value['option_id'] > 0) {
						DB::query('UPDATE ' . DB::table('tom_tcqianggou_goods_option') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['option_id'] . '\' '), 'UNBUFFERED');
					}
					if ($value['code_order'] == 1) {
						DB::query('UPDATE ' . DB::table('tom_tcqianggou_code') . (' SET order_id=0,order_no=\'\',user_id=0,code_status=0 WHERE goods_id=' . $value['goods_id'] . ' AND order_id=' . $value['id'] . ' '), 'UNBUFFERED');
					}
				}
			}
		}
	}
	$showTgButton = 0;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0 && $goodsInfo['hehuoren_tg_open'] == 1 && $goodsInfo['coupon_is_buy'] == 1) {
		$tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfo['id'] > 0 && $tchehuorenInfo['status'] == 1) {
			$dengjiInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
			$dengjiInfo = array();
			if (is_array($dengjiInfoTmp) && !empty($dengjiInfoTmp)) {
				$dengjiInfo = $dengjiInfoTmp;
			}
			if ($dengjiInfo['qg_fc_open'] == 1) {
				if ($goodsInfo['site_id'] > 1) {
					$siteInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($goodsInfo['site_id']);
					if ($siteInfoTmp['hehuoren_fc_open'] == 1) {
						$showTgButton = 1;
					}
				} else {
					if ($goodsInfo['site_id'] == 1) {
						$showTgButton = 1;
					}
				}
			}
			if ($showTgButton == 1) {
				$needPrice = 0;
				$yongjin_bili = $tcqianggouConfig['yongjin_bili'];
				if ($goodsInfo['yongjin_bili'] > 0) {
					$yongjin_bili = $goodsInfo['yongjin_bili'];
				}
				$pay_price = $goodsInfo['coupon_buy_price'];
				$pt_money = $pay_price;
				if ($goodsInfo['open_shop_yongjin'] == 1) {
					$pt_money = $pay_price - $goodsInfo['shop_yongjin'];
				} else {
					if ($goodsInfo['yongjin_type'] == 2) {
						$pt_money = $goodsInfo['yongjin_bili'];
					} else {
						$pt_money = $pay_price * ($yongjin_bili / 100);
						$pt_money = number_format($pt_money, 2, '.', '');
					}
				}
				if ($dengjiInfo['level'] == 1) {
					if ($goodsInfo['yongjin_type'] == 2) {
						$needPrice = $goodsInfo['chuji_fc_scale'];
					} else {
						$needPrice = $pt_money * ($goodsInfo['chuji_fc_scale'] / 100);
					}
				} elseif ($dengjiInfo['level'] == 2) {
					if ($goodsInfo['yongjin_type'] == 2) {
						$needPrice = $goodsInfo['zhongji_fc_scale'];
					} else {
						$needPrice = $pt_money * ($goodsInfo['zhongji_fc_scale'] / 100);
					}
				} elseif ($dengjiInfo['level'] == 3) {
					if ($goodsInfo['yongjin_type'] == 2) {
						$needPrice = $goodsInfo['gaoji_fc_scale'];
					} else {
						$needPrice = $pt_money * ($goodsInfo['gaoji_fc_scale'] / 100);
					}
				}
				$needPrice = number_format($needPrice, 2, '.', '');
				$tctchehuorenParentInfo = $tctchehuorenParentDengji = $tctchehuorenParentUserInfo = array();
				if ($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1) {
					$tctchehuorenParentInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
					$tctchehuorenParentDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tctchehuorenParentInfo['dengji_id']);
				}
				if (!empty($tctchehuorenParentInfo) && $tctchehuorenParentInfo['status'] == 1) {
					if ($tctchehuorenParentDengji['level'] == 1) {
						if ($goodsInfo['yongjin_type'] == 2) {
							$tctchehuorenParent_fc_money = $goodsInfo['chuji_fc_scale2'];
						} else {
							if ($goodsInfo['chuji_fc_scale2'] > 0 && $goodsInfo['chuji_fc_scale2'] < 100) {
								$tctchehuorenParent_fc_money = $needPrice * ($goodsInfo['chuji_fc_scale2'] / 100);
							} else {
								$tctchehuorenParent_fc_money = $needPrice * ($tctchehuorenParentDengji['tuijian_fc_scale'] / 100);
							}
						}
					} elseif ($tctchehuorenParentDengji['level'] == 2) {
						if ($goodsInfo['yongjin_type'] == 2) {
							$tctchehuorenParent_fc_money = $goodsInfo['zhongji_fc_scale2'];
						} else {
							if ($goodsInfo['zhongji_fc_scale2'] > 0 && $goodsInfo['zhongji_fc_scale2'] < 100) {
								$tctchehuorenParent_fc_money = $needPrice * ($goodsInfo['zhongji_fc_scale2'] / 100);
							} else {
								$tctchehuorenParent_fc_money = $needPrice * ($tctchehuorenParentDengji['tuijian_fc_scale'] / 100);
							}
						}
					} elseif ($tctchehuorenParentDengji['level'] == 3) {
						if ($goodsInfo['yongjin_type'] == 2) {
							$tctchehuorenParent_fc_money = $goodsInfo['gaoji_fc_scale2'];
						} else {
							if ($goodsInfo['gaoji_fc_scale2'] > 0 && $goodsInfo['gaoji_fc_scale2'] < 100) {
								$tctchehuorenParent_fc_money = $needPrice * ($goodsInfo['gaoji_fc_scale2'] / 100);
							} else {
								$tctchehuorenParent_fc_money = $needPrice * ($tctchehuorenParentDengji['tuijian_fc_scale'] / 100);
							}
						}
					}
					$tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money, 2, '.', '');
					if ($tchehuorenConfig['subordinate_moneytype'] != 1) {
						$needPrice = $needPrice - $tctchehuorenParent_fc_money;
					}
				}
				$tchehuorenUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=coupon&goods_id=' . $goods_id . '&tj_hehuoren_id=' . $tchehuorenInfo['id']);
			}
		}
	}
	if (!empty($goodsInfo['share_title'])) {
		$shareTitle = $goodsInfo['share_title'];
	} else {
		$shareTitle = str_replace('{TITLE}', $goodsInfo['title'], $tcqianggouConfig['coupon_share_title']);
		$shareTitle = str_replace('{SHOPNAME}', $tcshopInfo['name'], $shareTitle);
		$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	}
	if (!empty($goodsInfo['share_desc'])) {
		$shareDesc = $goodsInfo['share_desc'];
	} else {
		$contentTmp = strip_tags($content);
		$contentTmp = str_replace("\r\n", '', $contentTmp);
		$contentTmp = str_replace("\n", '', $contentTmp);
		$contentTmp = str_replace("\r", '', $contentTmp);
		$shareDesc = cutstr($contentTmp, 80, '...');
	}
	$shareLogo = $picurl;
	if ($showTgButton == 1) {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=coupon&goods_id=' . $goods_id . '&tj_hehuoren_id=' . $tchehuorenInfo['id']);
	} else {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=coupon&goods_id=') . $goods_id;
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqianggou:coupon');
} elseif ($_GET['mod'] == 'recomlist') {
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$recom_cate_id = intval($_GET['recom_cate_id']) > 0 ? intval($_GET['recom_cate_id']) : 0;
	$recomCateInfo = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_by_id($recom_cate_id);
	if (!$recomCateInfo || $recomCateInfo['status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	if (!preg_match('/^http/', $recomCateInfo['toppic'])) {
		if (strpos($recomCateInfo['toppic'], 'source/plugin/tom_') === false) {
			$topPicurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $recomCateInfo['toppic'];
		} else {
			$topPicurl = $_G['siteurl'] . $recomCateInfo['toppic'];
		}
	} else {
		$topPicurl = $recomCateInfo['toppic'];
	}
	$shareTitle = $recomCateInfo['name'];
	$shareDesc = $recomCateInfo['sub_title'];
	if (!empty($recomCateInfo['toppic'])) {
		$shareLogo = $topPicurl;
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=recomlist&recom_cate_id=' . $recom_cate_id . '&s=1');
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=recomlist&recom_cate_id=' . $recom_cate_id));
	if ($recomCateInfo['type'] == 1) {
		$ajaxLoadUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=list&recom_cate_id=' . $recom_cate_id . '&qiang_list_type=3&formhash=' . $formhash;
	} else {
		$ajaxLoadUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=couponlist&recom_cate_id=' . $recom_cate_id . '&formhash=' . $formhash;
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqianggou:recomlist');
} elseif ($_GET['mod'] == 'qianggoulist') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$is_vip = intval($_GET['is_vip']) > 0 ? intval($_GET['is_vip']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$trade_id = intval($_GET['trade_id']) > 0 ? intval($_GET['trade_id']) : 0;
	$order_type = isset($_GET['order_type']) ? addslashes($_GET['order_type']) : 'default';
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$cateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_cate')->fetch_all_list(' ', ' ORDER BY csort ASC,id DESC ');
	$cateList = array();
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		$i = 1;
		foreach ($cateListTmp as $key => $value) {
			$cateList[$i] = $value;
			$i++;
		}
	}
	$cateCount = count($cateList);
	$tradeWhereStr = '';
	if ($tcqianggouConfig['open_trade_sites'] == 1 && !empty($sql_in_site_ids)) {
		$tradeWhereStr .= ' AND site_id IN(' . $sql_in_site_ids . ') ';
	} else {
		$tradeWhereStr .= ' AND site_id = ' . $site_id . ' ';
	}
	$tradeListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_trade')->fetch_all_list($tradeWhereStr, ' ORDER BY tsort ASC,id DESC ');
	$tradeList = array();
	if (is_array($tradeListTmp) && !empty($tradeListTmp)) {
		$i = 1;
		foreach ($tradeListTmp as $key => $value) {
			$tradeList[$i] = $value;
			$i++;
		}
	}
	$tradeCount = count($tradeList);
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=qianggoulist&keyword=' . $keyword . '&cate_id=' . $cate_id . '&trade_id=' . $trade_id . '&order_type=' . $order_type));
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=qianggoulist&s=1&is_vip=' . $is_vip . '&cate_id=' . $cate_id . '&trade_id=' . $trade_id . '&order_type=' . $order_type);
	$ajaxLoadUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=list&keyword=' . $keyword . '&is_vip=' . $is_vip . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqianggou:qianggoulist');
} elseif ($_GET['mod'] == 'search') {
	$qianggou_search_arr = explode('|', $tcqianggouConfig['qianggou_search_list']);
	$qianggouSearchList = array();
	if (is_array($qianggou_search_arr) && !empty($qianggou_search_arr)) {
		foreach ($qianggou_search_arr as $key => $value) {
			if (!empty($value)) {
				$qianggouSearchList[] = trim($value);
			}
		}
	}
	$searchUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=get_search_url&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqianggou:search');
} elseif ($_GET['mod'] == 'couponlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$type_id = intval($_GET['type_id']) > 0 ? intval($_GET['type_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$trade_id = intval($_GET['trade_id']) > 0 ? intval($_GET['trade_id']) : 0;
	$order_type = isset($_GET['order_type']) ? addslashes($_GET['order_type']) : 'default';
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	$cateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_cate')->fetch_all_list(' ', ' ORDER BY csort ASC,id DESC ');
	$cateList = array();
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		$i = 1;
		foreach ($cateListTmp as $key => $value) {
			$cateList[$i] = $value;
			$i++;
		}
	}
	$cateCount = count($cateList);
	$tradeWhereStr = '';
	if ($tcqianggouConfig['open_trade_sites'] == 1 && !empty($sql_in_site_ids)) {
		$tradeWhereStr .= ' AND site_id IN(' . $sql_in_site_ids . ') ';
	} else {
		$tradeWhereStr .= ' AND site_id = ' . $site_id . ' ';
	}
	$tradeListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_trade')->fetch_all_list($tradeWhereStr, ' ORDER BY tsort ASC,id DESC ');
	$tradeList = array();
	if (is_array($tradeListTmp) && !empty($tradeListTmp)) {
		$i = 1;
		foreach ($tradeListTmp as $key => $value) {
			$tradeList[$i] = $value;
			$i++;
		}
	}
	$tradeCount = count($tradeList);
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=couponlist&keyword=' . $keyword . '&type_id=' . $type_id . '&cate_id=' . $cate_id . '&trade_id=' . $trade_id . '&order_type=' . $order_type));
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=couponlist&s=1&type_id=' . $type_id . '&cate_id=' . $cate_id . '&trade_id=' . $trade_id . '&order_type=' . $order_type);
	$ajaxLoadUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=couponlist&keyword=' . $keyword . '&type_id=' . $type_id . '&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqianggou:couponlist');
} elseif ($_GET['mod'] == 'couponsearch') {
	$coupon_search_arr = explode('|', $tcqianggouConfig['coupon_search_list']);
	$couponSearchList = array();
	if (is_array($coupon_search_arr) && !empty($coupon_search_arr)) {
		foreach ($coupon_search_arr as $key => $value) {
			if (!empty($value)) {
				$couponSearchList[] = trim($value);
			}
		}
	}
	$searchUrl = 'plugin.php?id=tom_tcqianggou:ajax&site=' . $site_id . '&act=get_coupon_search_url&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqianggou:couponsearch');
} elseif ($_GET['mod'] == 'buy') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/buy.php';
} elseif ($_GET['mod'] == 'ling') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/ling.php';
} elseif ($_GET['mod'] == 'hexiao') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/hexiao.php';
} elseif ($_GET['mod'] == 'my') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/my.php';
} elseif ($_GET['mod'] == 'mylist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/mylist.php';
} elseif ($_GET['mod'] == 'myfabu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/myfabu.php';
} elseif ($_GET['mod'] == 'daoorder') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/daoorder.php';
} elseif ($_GET['mod'] == 'order') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/order.php';
} elseif ($_GET['mod'] == 'orderinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/orderinfo.php';
} elseif ($_GET['mod'] == 'orderhexiao') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/orderhexiao.php';
} elseif ($_GET['mod'] == 'shop_use_log') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/shop_use_log.php';
} elseif ($_GET['mod'] == 'hexiao_duo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/hexiao_duo.php';
} elseif ($_GET['mod'] == 'orderhexiao_duo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/orderhexiao_duo.php';
} elseif ($_GET['mod'] == 'fabu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/fabu.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/edit.php';
} elseif ($_GET['mod'] == 'editstock') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/editstock.php';
} elseif ($_GET['mod'] == 'editoption') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/editoption.php';
} elseif ($_GET['mod'] == 'editpwd') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/editpwd.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqianggou/module/upload.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcqianggou&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();