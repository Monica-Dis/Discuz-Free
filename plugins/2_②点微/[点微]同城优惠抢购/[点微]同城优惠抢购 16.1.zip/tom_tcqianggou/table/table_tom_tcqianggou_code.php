<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_tom_tcqianggou_code extends discuz_table{
	public function __construct() {
        parent::__construct(); //d'.'is'.'m.ta'.'obao.com
		$this->_table = 'tom_tcqianggou_code';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
    
    public function fetch_by_order_id($order_id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE order_id=%d", array($this->_table, $order_id));
	}
    
    public function fetch_by_code_value($code_value,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE code_value=%s", array($this->_table, $code_value));
	}
	
    public function fetch_all_list($condition,$orders = '',$start = 0,$limit = 10) {
		$data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
		return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition) {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
        if($return['num'] > 0){
            return $return['num'];
        }else{
            return 0;
        }
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
    
    public function delete_all($condition) {
		return DB::query("DELETE FROM %t WHERE 1 %i", array($this->_table, $condition));
	}

}