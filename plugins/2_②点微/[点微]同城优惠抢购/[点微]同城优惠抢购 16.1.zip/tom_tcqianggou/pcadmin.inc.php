<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$adminConfig = $_G['cache']['plugin']['tom_admin'];
$tcqianggouConfig = $_G['cache']['plugin']['tom_tcqianggou'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$prand = rand(1, 1000);
$cssJsVersion = "20201022";

$pcadminUrl = 'plugin.php?id=tom_tcqianggou:pcadmin';
$ajaxUrl = 'plugin.php?id=tom_admin:ajax';
$qianggouAjaxUrl = 'plugin.php?id=tom_tcqianggou:pcadminAjax';
$uploadUrl = 'plugin.php?id=tom_admin:upload';
$baidumapUrl = 'plugin.php?id=tom_admin:baidumap';

include DISCUZ_ROOT.'./source/plugin/tom_admin/class/function.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/config/pcadmin.lang.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

$Lang = $pcadminLang;

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/config/config.utf8.php';
}

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end
## tcchoujiang start
$__ShowTcchoujiang = 0;
$tcchoujiangConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcchoujiang/tom_tcchoujiang.inc.php')){
    $tcchoujiangConfig = $_G['cache']['plugin']['tom_tcchoujiang'];
    if($tcchoujiangConfig['open_tcchoujiang'] == 1){
        $__ShowTcchoujiang = 1;
    }
}
## tcchoujiang end
## tcyikatong start
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
    $tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $__ShowTcyikatong = 1;
    }
}
## tcyikatong end
## kuaidi start
$__ShowKuaidi = 0;
$kuaidiConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_kuaidi/tom_kuaidi.inc.php')){
    $__ShowKuaidi = 1;
    $kuaidiConfig = $_G['cache']['plugin']['tom_kuaidi'];
}
## kuaidi end
## tcyuyue start
$__ShowTcyuyue = 0;
$tcyuyueConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyuyue/tom_tcyuyue.inc.php')){
    $tcyuyueConfig = $_G['cache']['plugin']['tom_tcyuyue'];
    if($tcyuyueConfig['open_tcyuyue'] == 1){
        $__ShowTcyuyue = 1;
    }
}
## tcyuyue end

include DISCUZ_ROOT.'./source/plugin/tom_admin/login_check.php';

if($__Admin['admin'] == 'shopadmin'){
    
    if($_GET['tmod'] == 'list'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcshopadmin/list.php';
    }else if($_GET['tmod'] == 'add'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/add.php';
    }else if($_GET['tmod'] == 'edit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/edit.php';
    }else if($_GET['tmod'] == 'stocklog'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/stocklog.php';
    }else if($_GET['tmod'] == 'option'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/option.php';
    }else if($_GET['tmod'] == 'coupon'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcshopadmin/coupon.php';
    }else if($_GET['tmod'] == 'couponadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/couponadd.php';
    }else if($_GET['tmod'] == 'couponedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/couponedit.php';
    }else if($_GET['tmod'] == 'order'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcshopadmin/order.php';
    }else if($_GET['tmod'] == 'orderinfo'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcshopadmin/orderinfo.php';
    }else if($_GET['tmod'] == 'orderuselog'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/orderuselog.php';
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcshopadmin/list.php';
    }
    
}else if($__Admin['admin'] == 'admin'){

    if($_GET['tmod'] == 'list'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/list.php';
    }else if($_GET['tmod'] == 'coupon'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/coupon.php';
    }else if($_GET['tmod'] == 'add'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/add.php';
    }else if($_GET['tmod'] == 'edit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/edit.php';
    }else if($_GET['tmod'] == 'couponadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/couponadd.php';
    }else if($_GET['tmod'] == 'couponedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/couponedit.php';
    }else if($_GET['tmod'] == 'stocklog'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/stocklog.php';
    }else if($_GET['tmod'] == 'option'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/option.php';
    }else if($_GET['tmod'] == 'goodsshop'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/goodsshop.php';
    }else if($_GET['tmod'] == 'goodsshopadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/goodsshopadd.php';
    }else if($_GET['tmod'] == 'goodsshopedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/goodsshopedit.php';
    }else if($_GET['tmod'] == 'goodsshopuselog'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/goodsshopuselog.php';
    }else if($_GET['tmod'] == 'code'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/code.php';
    }else if($_GET['tmod'] == 'xubuy'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/xubuy.php';
    }else if($_GET['tmod'] == 'order'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/order.php';
    }else if($_GET['tmod'] == 'orderinfo'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/orderinfo.php';
    }else if($_GET['tmod'] == 'orderuselog'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/orderuselog.php';
    }else if($_GET['tmod'] == 'popup'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/popup.php';
    }else if($_GET['tmod'] == 'popupadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/popupadd.php';
    }else if($_GET['tmod'] == 'popupedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/popupedit.php';
    }else if($_GET['tmod'] == 'group'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/group.php';
    }else if($_GET['tmod'] == 'groupadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/groupadd.php';
    }else if($_GET['tmod'] == 'groupedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/groupedit.php';
    }else if($_GET['tmod'] == 'focuspic'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/focuspic.php';
    }else if($_GET['tmod'] == 'focuspicadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/focuspicadd.php';
    }else if($_GET['tmod'] == 'focuspicedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/focuspicedit.php';
    }else if($_GET['tmod'] == 'recom_cate'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/recom_cate.php';
    }else if($_GET['tmod'] == 'recom_cate_add'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/recom_cate_add.php';
    }else if($_GET['tmod'] == 'recom_cate_edit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/recom_cate_edit.php';
    }else if($_GET['tmod'] == 'trade'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/trade.php';
    }else if($_GET['tmod'] == 'tradeadd'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/tradeadd.php';
    }else if($_GET['tmod'] == 'tradeedit'){
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/tradeedit.php';
    }else{
        include DISCUZ_ROOT.'./source/plugin/tom_tcqianggou/pcadmin/list.php';
    }
}