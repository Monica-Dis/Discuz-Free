<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=goods';
$modListUrl = $adminListUrl.'&tmod=goods';
$modFromUrl = $adminFromUrl.'&tmod=goods';

$get_list_url_value = get_list_url("tom_tcqianggou_admin_goods_list");
if($get_list_url_value && $_GET['act'] != 'xubuy'){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $type_id        = isset($_GET['type_id'])? intval($_GET['type_id']):0;
        $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
        $tcshop_id      = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
        $cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
        $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
        $open_duo_shop  = isset($_GET['open_duo_shop'])? intval($_GET['open_duo_shop']):0;
        
        if($open_duo_shop == 0){
            
            $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);

            if($tcshopInfo && $tcshopInfo['status'] == 1){
            }else{
                cpmsg($Lang['goods_add_error_500'], $modListUrl.'&act=add', 'error');
            }
        }
        
        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['user_id']          = $tcshopInfo['user_id'];
        $insertData['tcshop_id']        = $tcshopInfo['id'];
        $insertData['type_id']          = $type_id;
        $insertData['cate_id']          = $cate_id;
        $insertData['title']            = $title;
        if($type_id == 1){
            $insertData['open_duo_shop']    = $open_duo_shop;
        }
        $insertData['status']           = 2;
        $insertData['shenhe_status']    = 1;
        $insertData['add_time']         = TIMESTAMP;
        if(C::t('#tom_tcqianggou#tom_tcqianggou_goods')->insert($insertData)){
            $goods_id = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->insert_id();
            cpmsg($Lang['act_success'], $modListUrl.'&act=edit&id='.$goods_id, 'succeed');
        }else{
            cpmsg($Lang['goods_add_error'], $modListUrl.'&act=add', 'error');
        }
        
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=add&formhash='.FORMHASH);
        showtableheader(); //dism��taobao��com
        echo '<tr><th colspan="15" class="partition">' . $Lang['goods_add'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['goods_type_id'],'name'=>'type_id','value'=>1,'msg'=>$Lang['goods_type_id_msg'],'item'=>$typeArray),"radio");
        tomshowsetting(true,array('title'=>$Lang['goods_site_id'],'name'=>'site_id','value'=>1,'msg'=>$Lang['goods_site_id_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['goods_tcshop_id'],'name'=>'tcshop_id','value'=>0,'msg'=>$Lang['goods_tcshop_id_msg']),"input");
        $open_duo_shop_item = array(0=>$Lang['goods_open_duo_shop_0'],1=>$Lang['goods_open_duo_shop_1']);
        tomshowsetting(true,array('title'=>$Lang['goods_open_duo_shop'],'name'=>'open_duo_shop','value'=>$options['open_duo_shop'],'msg'=>$Lang['goods_open_duo_shop_msg'],'item'=>$open_duo_shop_item),"radio");
        $cateList = C::t('#tom_tcqianggou#tom_tcqianggou_cate')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
        $cateStr = '<tr class="header"><th>'.$Lang['goods_cate_id'].'</th><th></th></tr>';
        $cateStr.= '<tr><td width="300"><select style="width: 260px;" name="cate_id" id="cate_id">';
        foreach ($cateList as $key => $value){
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
        $cateStr.= '</select></td><td></td></tr>';
        echo $cateStr;
        tomshowsetting(true,array('title'=>$Lang['goods_title'],'name'=>'title','value'=>'','msg'=>$Lang['goods_title_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }
    
}else if($_GET['act'] == 'edit'){
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $data = __get_post_data($goodsInfo);
        
        if($data['hasoption'] == 0 && $data['open_shop_yongjin'] == 1){
            $shop_yongjin = $data['shop_yongjin'];

            if($goodsInfo['type_id'] == 1){

                if($data['buy_price'] > 0 && $shop_yongjin > $data['buy_price']){
                    cpmsg($Lang['goods_shop_yongjin_error_301'], $modListUrl."&act=edit&id={$_GET['id']}".'&formhash='.FORMHASH, 'error');exit;
                }
                if($data['buy_price'] > 0 && $data['open_ding_pay'] == 1 && $shop_yongjin > $data['ding_price']){
                    cpmsg($Lang['goods_shop_yongjin_error_302'], $modListUrl."&act=edit&id={$_GET['id']}".'&formhash='.FORMHASH, 'error');exit;
                }
                if($data['buy_price'] > 0 && $data['open_before'] == 1 && $shop_yongjin > $data['before_price']){
                    cpmsg($Lang['goods_shop_yongjin_error_303'], $modListUrl."&act=edit&id={$_GET['id']}".'&formhash='.FORMHASH, 'error');exit;
                }
                if($data['buy_price'] > 0 && $data['open_vip'] == 1 && $shop_yongjin > $data['vip_price']){
                    cpmsg($Lang['goods_shop_yongjin_error_304'], $modListUrl."&act=edit&id={$_GET['id']}".'&formhash='.FORMHASH, 'error');exit;
                }

            }else{

                if($data['coupon_is_buy'] == 1 && $shop_yongjin > $data['coupon_buy_price']){
                    cpmsg($Lang['goods_shop_yongjin_error_305'], $modListUrl."&act=edit&id={$_GET['id']}", 'error');exit;
                }
                if($data['coupon_is_buy'] == 1 && $data['open_vip'] == 1 && $shop_yongjin > $data['vip_price']){
                    cpmsg($Lang['goods_shop_yongjin_error_304'], $modListUrl."&act=edit&id={$_GET['id']}", 'error');exit;
                }

            }
        }
        
        $updateData = array();
        $updateData = $data;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($goodsInfo['id'],$updateData);
        
        $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goodsInfo['id']);
        update_qiang_status($goodsInfoTmp);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); //dism��taobao��com
        __create_info_html($goodsInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe'){
    
    $shenhe_status     = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):1;
    
    $updateData = array();
    $updateData['shenhe_status']     = $shenhe_status;
    C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status'] = 1;
    C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($_GET['id'],$updateData);
    
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']);

    $shenhe = str_replace('{TITLE}', $goodsInfo['title'], $Lang['template_tcqianggou_shenhe_ok']);
    $cpmsg = $Lang['tcqianggou_shenhe_tz_succ'];
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $weixinClass = new weixinClass($appid,$appsecret);
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        if($goodsInfo['type_id'] == 1){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$goodsInfo['site_id']}&mod=details&goods_id=".$goodsInfo['id']);
        }else{
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$goodsInfo['site_id']}&mod=coupon&goods_id=".$goodsInfo['id']);
        }
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcqianggouConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
        }else{
            $cpmsg = $Lang['tcqianggou_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcqianggouConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($_GET['id'],$updateData);
        
        $shenhe = str_replace('{TITLE}', $goodsInfo['title'], $Lang['template_tcqianggou_shenhe_no']);
        $cpmsg = $Lang['tcqianggou_shenhe_tz_succ'];
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$goodsInfo['site_id']}&mod=edit&goods_id=".$goodsInfo['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcqianggouConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
            }else{
                $cpmsg = $Lang['tcqianggou_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcqianggouConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tcqianggou_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader(); //dism��taobao��com
        tomshowsetting(true,array('title'=>$Lang['tcqianggou_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcqianggou_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status']     = 2;
    C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $goods_id  = isset($_GET['id'])? intval($_GET['id']):0;
    $count = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(" AND goods_id={$goods_id} ");
    if($count > 0){
        cpmsg($Lang['act_del_goods_error'], $modListUrl, 'error');
    }
    
    C::t('#tom_tcqianggou#tom_tcqianggou_goods')->delete_by_id($_GET['id']);
    C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->delete_by_goods_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editstock'){
    $info = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $stock_num     = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
        
        if($stock_num < $info['sale_num']){
            $stock_num = $info['sale_num'];
        }
        
        $updateData = array();
        $updateData['stock_num'] = $stock_num;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($_GET['id'],$updateData);
        
        $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['id']);
        update_qiang_status($goodsInfoTmp);
        
        $insertData = array();
        $insertData['is_admin']     = 1;
        $insertData['goods_id']     = $_GET['id'];
        $insertData['change_num']   = $stock_num;
        $insertData['change_time']  = TIMESTAMP;
        C::t('#tom_tcqianggou#tom_tcqianggou_stock_log')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editstock&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader(); //dism��taobao��com
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_stock_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_stock_num'],'name'=>'stock_num','value'=>$info['stock_num'],'msg'=>$Lang['edit_stock_num_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
        
        tomshownavheader();
        tomshownavli($Lang['stocklog_list_title'],"",true);
        tomshownavfooter();

        $stockyLogList = C::t('#tom_tcqianggou#tom_tcqianggou_stock_log')->fetch_all_list(" AND goods_id={$info['id']} AND is_option=0 "," ORDER BY id DESC ",0,500);
        showtableheader(); //dism��taobao��com
        echo '<tr class="header">';
        echo '<th>' . $Lang['stocklog_is_admin'] . '</th>';
        echo '<th>' . $Lang['stocklog_change_num'] . '</th>';
        echo '<th>' . $Lang['stocklog_change_time'] . '</th>';
        echo '</tr>';

        $i = 1;
        foreach ($stockyLogList as $key => $value) {
            echo '<tr>';
            if($value['is_admin'] == 1){
                echo '<td>' . $Lang['stocklog_is_admin_1'] . '</td>';
            }else{
                echo '<td>' . $Lang['stocklog_is_admin_0'] . '</td>';
            }
            echo '<td>' . $value['change_num'] . '</td>';
            echo '<td>' . dgmdate($value['change_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
            echo '</tr>';
            $i++;
        }
        showtablefooter(); //Dism��taobao��com
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editrecom'){

    $info = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['goods_id']);
    if(submitcheck('submit')){
        
        $recom_cate_id = isset($_GET['recom_cate_id'])? intval($_GET['recom_cate_id']):0;
        
        $updateData = array();
        $updateData['recom_cate_id'] = $recom_cate_id;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($_GET['goods_id'],$updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editrecom&goods_id='.$_GET['goods_id'].'&formhash='.FORMHASH);
        showtableheader(); //dism��taobao��com 
        echo '<tr><th colspan="15" class="partition">'.$info['title'] .'&gt;&gt;'. $Lang['edit_recom_title'] .'</th></tr>';
        
        $where = "";
        if($info['type_id'] == 1){
            $where .= ' AND type = 1 ';
        }else{
            $where .= ' AND type = 2 ';
        }
        $recomCateList = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_list($where." AND site_id = {$info['site_id']} "," ORDER BY csort ASC, id DESC ",0,1000);
        if(is_array($recomCateList) && !empty($recomCateList)){ }else{
            $recomCateList = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_list($where." AND site_id = 1 "," ORDER BY csort ASC, id DESC ",0,1000);
        }
        $recomCateStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_recom_cate_id'].'</b></td>';
        $recomCateStr.= '<td><select style="width: 260px;" name="recom_cate_id" id="recom_cate_id">';
        $recomCateStr.=  '<option value="0">'.$Lang['goods_recom_cate_id_0'].'</option>';
        foreach($recomCateList as $key => $value){
            if($info['recom_cate_id'] == $value['id']){
                $recomCateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $recomCateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $recomCateStr.= '</select></td></tr>';
        echo $recomCateStr;
        
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }

}else if($_GET['act'] == 'photo'){
    
    $goods_id = $_GET['goods_id'];
    
    if(submitcheck('submit')){
        
        if($_FILES["picurl"]['tmp_name']) {
            $upload = new tom_upload();
            if(!$upload->init($_FILES["picurl"], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }

            $picurl = $upload->attach['attachment'];
        }else{
            $picurl = addslashes($_GET["picurl"]);
        }
        
        $insertData = array();
        $insertData['goods_id']     = $goods_id;
        $insertData['picurl']       = $picurl;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl."&act=photo&goods_id=".$_GET['goods_id'], 'succeed');
    }
    
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['goods_id']);
    
    $photoList = C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->fetch_all_list(" AND goods_id={$goods_id} ","ORDER BY id ASC",0,100);
    __create_nav_html();
    showformheader($modFromUrl.'&act=photo&goods_id='.$goods_id,'enctype');
    showtableheader(); //dism��taobao��com
    tomshowsetting(true,array('title'=>$Lang['goods_photo_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['goods_photo_picurl_msg']),"file");
    showsubmit('submit', 'submit');
    showtablefooter(); //Dism��taobao��com
    showformfooter(); //Dism_taobao_com
    
    showtableheader(); //dism��taobao��com
    echo '<tr class="header">';
    echo '<th>' . $Lang['goods_photo_picurl'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($photoList as $key => $value) {
        echo '<tr>';
        echo '<td><img src="' . tomgetfileurl($value['picurl']) . '" width="60" /></td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&goods_id='.$goods_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter(); //Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl."&act=photo&goods_id=".$_GET['goods_id'], 'succeed');
    
}else if($_GET['act'] == 'xubuy'){
    
    $goods_id  = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
    
    if(submitcheck('submit')){
        
        $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
        $option_id          = isset($_GET['option_id'])? intval($_GET['option_id']):0;
        $order_time         = isset($_GET['order_time'])? addslashes($_GET['order_time']):'';
        $order_time         = strtotime($order_time);
        
        if($order_time > TIMESTAMP){
            cpmsg($Lang['xubuy_order_time_error'], $modListUrl."&act=xubuy&goods_id=".$_GET['goods_id'], 'error');
        }
        
        $insertData = array();
        $insertData['goods_id']     = $goods_id;
        $insertData['option_id']    = $option_id;
        $insertData['type_id']      = 2;
        $insertData['user_id']      = $user_id;
        $insertData['goods_num']    = 1;
        $insertData['order_time']   = $order_time;
        C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl."&act=xubuy&goods_id=".$_GET['goods_id'], 'succeed');
    }
    
    $csstr = <<<EOF
<style type="text/css">
.pns input{width: 20px;}
</style>
EOF;
    echo $csstr;
    tomloadcalendarjs();
    __create_nav_html();
    showformheader($modFromUrl.'&act=xubuy&goods_id='.$goods_id,'enctype');
    showtableheader(); //dism��taobao��com
    $userList = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_like_list(' AND is_majia = 1 ',"ORDER BY id DESC",0,1000,'');
    $userStr = '<tr class="header"><th>'.$Lang['xubuy_user_id'].'</th><th></th></tr>';
    $userStr.= '<tr><td width="300"><select style="width: 260px;" name="user_id" id="user_id">';
    foreach ($userList as $key => $value){
        $userStr.=  '<option value="'.$value['id'].'">'.$value['nickname'].'(ID:'.$value['id'].')</option>';
    }
    $userStr.= '</select></td><td></td></tr>';
    echo $userStr;
    
    if($goodsInfo['hasoption'] == 1){
        $optionList = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_all_list(" AND goods_id = {$goods_id} ", 'ORDER BY osort ASC,id ASC', 0, 100);
        $optionStr = '<tr class="header"><th>'.$Lang['xubuy_option'].'</th><th></th></tr>';
        $optionStr.= '<tr><td width="300"><select style="width: 260px;" name="option_id" id="option_id">';
        foreach ($optionList as $key => $value){
            $optionStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
        $optionStr.= '</select></td><td></td></tr>';
        echo $optionStr;
    }
    
    tomshowsetting(true,array('title'=>$Lang['xubuy_order_time'],'name'=>'order_time','value'=>$options['order_time'],'msg'=>$Lang['xubuy_order_time_msg']),"calendar");
    showsubmit('submit', 'submit');
    showtablefooter(); //Dism��taobao��com
    showformfooter(); //Dism_taobao_com
    
    $xubuyList = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_list(" AND goods_id={$goods_id} AND type_id=2 ","ORDER BY order_time DESC,id ASC",0,1000);
    
    showtableheader(); //dism��taobao��com
    echo '<tr class="header">';
    echo '<th>UID</th>';
    echo '<th>' . $Lang['xubuy_user_id'] . '</th>';
    if($goodsInfo['hasoption'] == 1){
        echo '<th>' . $Lang['xubuy_option'] . '</th>';
    }
    echo '<th>' . $Lang['xubuy_goods_num'] . '</th>';
    echo '<th>' . $Lang['xubuy_order_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($xubuyList as $key => $value) {
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']); 
        echo '<tr>';
        echo '<td>' . $userInfo['id'] . '</td>';
        echo '<td>' . $userInfo['nickname'] . '</td>';
        if($goodsInfo['hasoption'] == 1){
            $optionInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($value['option_id']);
            echo '<th>' . $optionInfo['name'] . '</th>';
        }
        echo '<td>' . $value['goods_num'] . '</td>';
        echo '<td>' . dgmdate($value['order_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delxubuy&id='.$value['id'].'&goods_id='.$goods_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter(); //Dism��taobao��com
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delxubuy'){
    
    C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl."&act=xubuy&goods_id=".$_GET['goods_id'], 'succeed');
    
}else if($_GET['act'] == 'update_goods_balance_type'){
    
    if(submitcheck('submit')){
        
        $goods_balance_type = intval($_GET['goods_balance_type'])>0 ? intval($_GET['goods_balance_type']):0;
        
        $updateData = array();
        $updateData['goods_balance_type'] = $goods_balance_type;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($_GET['id'], $updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }
    
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['id']);
    
    showformheader($modFromUrl.'&act=update_goods_balance_type&id='.$_GET['id'],'enctype');
    showtableheader(); //dism��taobao��com
    echo '<tr><th colspan="15" class="partition">' .$goodsInfo['title'].'&nbsp;&gt;&gt;&nbsp;'. $Lang['goods_goods_balance_type'] . '</th></tr>';
    if($goodsInfo['open_duo_shop'] == 1){
        $goods_balance_type_item = array(1=>$Lang['goods_goods_balance_type_1'],2=>$Lang['goods_goods_balance_type_2']);
    }else{
        $goods_balance_type_item = array(1=>$Lang['goods_goods_balance_type_1'],2=>$Lang['goods_goods_balance_type_2'],3=>$Lang['goods_goods_balance_type_3']);
    }
    tomshowsetting(true,array('title'=>$Lang['goods_goods_balance_type'],'name'=>'goods_balance_type','value'=>$goodsInfo['goods_balance_type'],'msg'=>$Lang['goods_goods_balance_type_msg'],'item'=>$goods_balance_type_item,'width'=>450),"radio");
    showsubmit('submit', 'submit');
    showtablefooter(); //Dism��taobao��com
    showformfooter(); //Dism_taobao_com
    
}else{  
    
    if(isset($_GET['goods_title']) && !empty($_GET['goods_title'])){
    }else{
        set_list_url("tom_tcqianggou_admin_goods_list");
    }
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ width: 100px;float: left;list-style-type: none;height: 32px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;color: #6a6d6a;width: 90px;height: 25px;line-height: 25px;display: block;text-align: center; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
</style>
EOF;
    echo $csstr;
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $type_id            = isset($_GET['type_id'])? intval($_GET['type_id']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $recom_cate_id      = isset($_GET['recom_cate_id'])? intval($_GET['recom_cate_id']):0;
    $goods_title        = isset($_GET['goods_title'])? addslashes($_GET['goods_title']):'';
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($type_id)){
        $where.= " AND type_id={$type_id} ";
    }
    if(!empty($cate_id)){
        $where.= " AND cate_id={$cate_id} ";
    }
    if(!empty($recom_cate_id)){
        $where.= " AND recom_cate_id={$recom_cate_id} ";
    }
    if(!empty($status)){
        $where.= " AND status={$status} ";
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_count($where,$goods_title);
    $goodsList = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_all_like_list($where," ORDER BY id DESC ",$start,$pagesize,$goods_title);
    
    showtableheader(); //dism��taobao��com
    $Lang['tcqianggou_help_0']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcqianggou_help_0']);
    $Lang['tcqianggou_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcqianggou_help_3']);
    $Lang['tcqianggou_help_4']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcqianggou_help_4']);
    $Lang['tcqianggou_help_5']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcqianggou_help_5']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['tcqianggou_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['tcqianggou_help_0'] . '</li>';
    echo '<li>' . $Lang['tcqianggou_help_3'] . '</li>';
    if($tongchengConfig['open_yun'] == 2){
        echo '<li>' . $Lang['tcqianggou_help_4'] . '</li>';
    }
    if($tongchengConfig['open_yun'] == 3){
        echo '<li>' . $Lang['tcqianggou_help_5'] . '</li>';
    }
    echo '</ul></td></tr>';
    showtablefooter(); //Dism��taobao��com
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&type_id={$type_id}&status={$status}&shenhe_status={$shenhe_status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); //dism��taobao��com
    echo '<tr><th colspan="15" class="partition">' . $Lang['tcqianggou_search_title'] . '</th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,10000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $typeStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_type_id'].'</b></td>';
    $typeStr.= '<td><select style="width: 260px;" name="type_id" id="type_id">';
    $typeStr.=  '<option value="0">'.$Lang['goods_type_id'].'</option>';
    foreach ($typeArray as $key => $value){
        if($type_id == $key){
            $typeStr.=  '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            $typeStr.=  '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    $typeStr.= '</select></td></tr>';
    echo $typeStr;
    
    echo '<tr><td width="100" align="right"><b>' . $Lang['goods_title'] . '</b></td><td><input name="goods_title" type="text" value="'.$goods_title.'" style="width: 260px;" /></td></tr>';
    
    $cateList = C::t('#tom_tcqianggou#tom_tcqianggou_cate')->fetch_all_list(" "," ORDER BY csort ASC, id DESC ",0,10000);
    $cateStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_cate_id'].'</b></td>';
    $cateStr.= '<td><select style="width: 260px;" name="cate_id" id="cate_id">';
    $cateStr.=  '<option value="0">'.$Lang['select_all'].'</option>';
    foreach($cateList as $key => $value){
        if($cate_id == $value['id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select></td></tr>';
    echo $cateStr;
    
    $recomCateList = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_list(" "," ORDER BY csort ASC, id DESC ",0,10000);
    $recomCateStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_recom_cate_id'].'</b></td>';
    $recomCateStr.= '<td><select style="width: 260px;" name="recom_cate_id" id="recom_cate_id">';
    $recomCateStr.=  '<option value="0">'.$Lang['select_all'].'</option>';
    foreach($recomCateList as $key => $value){
        if($recom_cate_id == $value['id']){
            $recomCateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $recomCateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $recomCateStr.= '</select></td></tr>';
    echo $recomCateStr;
    
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['goods_status'].'</option>';
    $statusStr.=  '<option value="1">'.$Lang['goods_status_1'].'</option>';
    $statusStr.=  '<option value="2">'.$Lang['goods_status_2'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['goods_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1">'.$Lang['goods_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2">'.$Lang['goods_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3">'.$Lang['goods_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    showsubmit('submit', 'submit');
    showtablefooter(); //Dism��taobao��com
    showformfooter(); //Dism_taobao_com
    
    __create_nav_html();
    showtableheader(); //dism��taobao��com
    echo '<tr class="header">';
    echo '<th style="width: 60px;">' . $Lang['sites_title'] . '</th>';
    echo '<th style="width: 60px;">' . $Lang['goods_picurl'] . '</th>';
    echo '<th style="width: 180px;">' . $Lang['goods_info'] . '</th>';
    echo '<th style="width: 150px;">' . $Lang['shop_info'] . '</th>';
    echo '<th>' . $Lang['goods_stock_num'] . '</th>';
    echo '<th>' . $Lang['goods_sale_num'] . '</th>';
    echo '<th>' . $Lang['goods_price'] . '</th>';
    echo '<th>' . $Lang['goods_status2'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($goodsList as $key => $value) {
        
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        $tcshopUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcshopInfoTmp['user_id']); 
        $orderCount = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(" AND goods_id = {$value['id']} "); 
        $cateInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_cate')->fetch_by_id($value['cate_id']);
        
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        echo '<tr style="border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #70b4e6;">';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td><img src="'.$picurl.'" width="40" /></td>';
        
        echo '<td><div class="tc_content_box"><ul>';
        echo '<li><b>'.$Lang['goods_type_id'].'&nbsp;:&nbsp;</b><font color="'.$typeColorArray[$value['type_id']].'">' . $typeArray[$value['type_id']] . '</font></li>';
        echo '<li><b>'.$Lang['order_goods_id'].'&nbsp;:&nbsp;</b>' . $value['id'] . '</li>';
        echo '<li><b>'.$Lang['goods_title'].'&nbsp;:&nbsp;</b>' . $value['title'] . '</li>';
        echo '<li><b>'.$Lang['goods_cate_id'].'&nbsp;:&nbsp;</b>' . $cateInfoTmp['name'] . '</li>';
        if($value['recom_cate_id'] > 0){
            $recomCateInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_by_id($value['recom_cate_id']);
            echo '<li><b>'.$Lang['goods_recom_cate_id'].'&nbsp;:&nbsp;</b>' . $recomCateInfoTmp['name'] . '</li>';
        }
        echo '</ul></div></td>';
        
        if($value['open_duo_shop'] == 1){ 
            echo '<td><b><font color="#0894fb">'.$Lang['goods_open_duo_shop_title1'].'</font></b></td>';
        }else{
            echo '<td><div class="tc_content_box"><ul>';
            echo '<li><b>'.$Lang['goods_tcshop_id'].'&nbsp;:&nbsp;</b>' . $tcshopInfoTmp['id'] . '</li>';
            echo '<li><b>'.$Lang['goods_tcshop_name'].'&nbsp;:&nbsp;</b>' . $tcshopInfoTmp['name'] . '</li>';
            echo '<li><b>'.$Lang['goods_tcshop_balance_user_id'].'&nbsp;:&nbsp;</b>' . $tcshopUserInfo['id'] . '</li>';
            echo '<li><b>'.$Lang['goods_tcshop_balance_nickname'].'&nbsp;:&nbsp;</b>' . $tcshopUserInfo['nickname'] . '</li>';
            echo '</ul></div></td>';
        }
        
        echo '<td><font color="#fd0d0d">' . $value['stock_num'] . '</font></td>';
        echo '<td><font color="#238206">' . $value['sale_num'] . '</font></td>';
        echo '<td><div class="tc_content_box"><ul>';
        if($value['type_id'] == 1 ){
            if($value['show_market_price'] > 0){
                echo '<li>'.$Lang['goods_market_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['show_market_price']. '</font></li>';
                echo '<li>'.$Lang['goods_buy_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['show_buy_price']. '</font></li>';
                if($value['open_vip'] == 1 && $tcyikatongConfig['open_tcyikatong'] == 1){
                    echo '<li>'.$Lang['goods_vip_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['show_vip_price']. '</font></li>';
                }
            }else{
                echo '<li>'.$Lang['goods_market_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['market_price']. '</font></li>';
                echo '<li>'.$Lang['goods_buy_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['buy_price']. '</font></li>';
                if($value['open_vip'] == 1 && $tcyikatongConfig['open_tcyikatong'] == 1){
                    echo '<li>'.$Lang['goods_vip_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['vip_price']. '</font></li>';
                }
            }
            echo '<li>'.$Lang['goods_ding_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['ding_price']. '</font></li>';
        }
        if($value['type_id'] == 2 || $value['type_id'] == 4 ){
            echo '<li>'.$Lang['goods_coupon_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['coupon_price']. '</font></li>';
            echo '<li>'.$Lang['goods_coupon_limit'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['coupon_limit']. '</font></li>';
        }
        if($value['type_id'] == 3 ){
            echo '<li>'.$Lang['goods_coupon_zhekou'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['coupon_zhekou']. '</font></li>';
        }
        if($value['type_id'] == 2 || $value['type_id'] == 3 || $value['type_id'] == 4 ){
            if($value['coupon_is_buy'] == 1){
                echo '<li>'.$Lang['goods_coupon_buy_price'].'&nbsp;:&nbsp;<font color="#fd0d0d">' . $value['coupon_buy_price']. '</font></li>';
            }
        }
        echo '</ul></div></td>';
        
        echo '<td><div class="tc_content_box"><ul>';
        if($value['hehuoren_tg_open'] == 1){
            echo '<li><b>'.$Lang['goods_hehuoren_tg'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['open'] . '</font></li>';
        }else{
            echo '<li><b>'.$Lang['goods_hehuoren_tg'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['close'] . '</font></li>';
        }
        if($orderCount > 0){
            $goodsHexiaoBtnStr = '';
        }else{
            $goodsHexiaoBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=update_goods_balance_type&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_genggai_btn']. '</a>)';
        }
        if($value['goods_balance_type'] == 1 ){
            echo '<li><b>'.$Lang['goods_goods_balance_type'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['goods_goods_balance_type_1'] . '</font>'.$goodsHexiaoBtnStr.'</li>';
        }else if($value['goods_balance_type'] == 2){
            echo '<li><b>'.$Lang['goods_goods_balance_type'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['goods_goods_balance_type_2'] . '</font>'.$goodsHexiaoBtnStr.'</li>';
        }else if($value['goods_balance_type'] == 3){
            echo '<li><b>'.$Lang['goods_goods_balance_type'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['goods_goods_balance_type_3'] . '</font>'.$goodsHexiaoBtnStr.'</li>';
        }
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_shenhe_btn_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_shenhe_btn_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<li><b>'.$Lang['goods_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['goods_shenhe_status_1'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 2){
            echo '<li><b>'.$Lang['goods_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['goods_shenhe_status_2'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 3){
            echo '<li><b>'.$Lang['goods_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['goods_shenhe_status_3'] . '</font>'.$sheheBtnStr.'</li>';
        }
        if($value['status'] == 1 ){
            echo '<li><b>'.$Lang['goods_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['goods_status_1'] . '</font></li>';
        }else{
            echo '<li><b>'.$Lang['goods_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['goods_status_2'] . '</font></li>';
        }
        if($value['open_hexiao_valid'] == 1){
            echo '<li><b>'.$Lang['goods_hexiao_valid_days'].'&nbsp;:&nbsp;</b><font color="#fd0d0d">' . $value['hexiao_valid_days'] . ''.$Lang['tian'].'</font></li>';
        }
        if($value['type_id'] == 1 ){
            echo '<li><b>'.$Lang['goods_start_time'].'&nbsp;:&nbsp;</b>' . dgmdate($value['start_time'],"Y-m-d H:i",$tomSysOffset) . '</li>';
            echo '<li><b>'.$Lang['goods_end_time'].'&nbsp;:&nbsp;</b>' . dgmdate($value['end_time'],"Y-m-d H:i",$tomSysOffset) . '</li>';
        }
        if($value['open_hexiao_valid'] == 0 && $value['hexiao_start_time'] > 0){
            echo '<li><b>'.$Lang['goods_hexiao_start_time'].'&nbsp;:&nbsp;</b>' . dgmdate($value['hexiao_start_time'],"Y-m-d H:i",$tomSysOffset) . '</li>';
        }
        if($value['open_hexiao_valid'] == 0){
            echo '<li><b>'.$Lang['goods_hexiao_time'].'&nbsp;:&nbsp;</b>' . dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset) . '</li>';
        }
        echo '</ul></div></td>';
        
        echo '<td><div class="tc_content_box_handle"><ul>';
        echo '<li><a style="border: 1px solid #07981f;color:#fff;background-color: #07981f;" href="'.$modBaseUrl.'&act=editrecom&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_recom_title']. '</a></li>';
        if($value['open_duo_shop'] == 1){
            echo '<li><a style="border: 1px solid #ff4141;color:#fff;background-color: #ff4141;" href="'.$adminBaseUrl.'&tmod=goods_shop&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_open_duo_shop_title']. '</a></li>';
        }
        echo '<li><a style="border: 1px solid #c1b303;color:#fff;background-color: #c1b303;" href="'.$adminBaseUrl.'&tmod=goods_tz&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_good_tz_title']. '</a></li>';
        if($value['open_code'] == 1){
            echo '<li><a style="border: 1px solid #1ea0ff;color:#fff;background-color: #1ea0ff;" href="'.$adminBaseUrl.'&tmod=code&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['code_list_title']. '</a></li>';
        }
        if($value['open_xubuy'] == 1 ){
            echo '<li><a style="border: 1px solid #f60;color:#fff;background-color: #f60;" href="'.$modBaseUrl.'&act=xubuy&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['xubuy_title']. '</a></li>';
        }
        if($value['status'] == 1 ){
            echo '<li><a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_status_2']. '</a></li>';
        }else{
            echo '<li><a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_status_1']. '</a></li>';
        }
        if($value['open_duo_shop'] == 0 && $value['hasoption'] == 1){
            echo '<li><a href="'.$adminBaseUrl.'&tmod=option&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_option_title']. '</a></li>';
        }else{
            echo '<li><a href="'.$modBaseUrl.'&act=editstock&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_stock_title']. '</a></li>';
        }
        echo '<li><a href="'.$modBaseUrl.'&act=photo&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_photo']. '</a></li>';
        echo '<li><a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_edit']. '</a></li>';
        echo '<li><a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a></li>';
        echo '</ul></div></td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); //Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $tcchoujiang_id     = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $yongjin_type       = isset($_GET['yongjin_type'])? intval($_GET['yongjin_type']):1;
    $yongjin_bili       = isset($_GET['yongjin_bili'])? floatval($_GET['yongjin_bili']):0;
    $open_shop_yongjin  = isset($_GET['open_shop_yongjin'])? intval($_GET['open_shop_yongjin']):0;
    $shop_yongjin       = isset($_GET['shop_yongjin'])? floatval($_GET['shop_yongjin']):0;
    $xuzhi              = isset($_GET['xuzhi'])? addslashes($_GET['xuzhi']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $xiangou_num        = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $min_num            = isset($_GET['min_num'])? intval($_GET['min_num']):0;
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    $open_xubuy         = isset($_GET['open_xubuy'])? intval($_GET['open_xubuy']):0;
    $market_price       = isset($_GET['market_price'])? addslashes($_GET['market_price']):'';
    $buy_price          = isset($_GET['buy_price'])? addslashes($_GET['buy_price']):'';
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? addslashes($_GET['ding_price']):'';
    $open_vip           = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $vip_price          = isset($_GET['vip_price'])? addslashes($_GET['vip_price']):'';
    $open_before        = isset($_GET['open_before'])? intval($_GET['open_before']):0;
    $before_price       = isset($_GET['before_price'])? addslashes($_GET['before_price']):'';
    $before_num         = isset($_GET['before_num'])? intval($_GET['before_num']):0;
    $coupon_price       = isset($_GET['coupon_price'])? addslashes($_GET['coupon_price']):'';
    $coupon_limit       = isset($_GET['coupon_limit'])? addslashes($_GET['coupon_limit']):'';
    $coupon_zhekou      = isset($_GET['coupon_zhekou'])? addslashes($_GET['coupon_zhekou']):'';
    $coupon_is_buy      = isset($_GET['coupon_is_buy'])? intval($_GET['coupon_is_buy']):0;
    $coupon_buy_price   = isset($_GET['coupon_buy_price'])? addslashes($_GET['coupon_buy_price']):'';
    $coupon_msg         = isset($_GET['coupon_msg'])? addslashes($_GET['coupon_msg']):'';
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = strtotime($end_time);
    $hexiao_start_time  = isset($_GET['hexiao_start_time'])? addslashes($_GET['hexiao_start_time']):'';
    $hexiao_start_time  = strtotime($hexiao_start_time);
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = strtotime($hexiao_time);
    $open_hexiao_valid  = isset($_GET['open_hexiao_valid'])? intval($_GET['open_hexiao_valid']):0;
    $hexiao_valid_days  = isset($_GET['hexiao_valid_days'])? intval($_GET['hexiao_valid_days']):0;
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $haibao_type        = isset($_GET['haibao_type'])? intval($_GET['haibao_type']):1;
    $haibao_msg         = isset($_GET['haibao_msg'])? addslashes($_GET['haibao_msg']):'';
    $qianggou_ids       = isset($_GET['qianggou_ids'])? addslashes($_GET['qianggou_ids']):'';
    $qrcode_location    = isset($_GET['qrcode_location'])? intval($_GET['qrcode_location']):1;
    $haibao_text_color  = isset($_GET['haibao_text_color'])? addslashes($_GET['haibao_text_color']):'';
    $hehuoren_tg_open   = isset($_GET['hehuoren_tg_open'])? intval($_GET['hehuoren_tg_open']):2;
    $chuji_fc_scale     = isset($_GET['chuji_fc_scale'])? floatval($_GET['chuji_fc_scale']):0;
    $zhongji_fc_scale   = isset($_GET['zhongji_fc_scale'])? floatval($_GET['zhongji_fc_scale']):0;
    $gaoji_fc_scale     = isset($_GET['gaoji_fc_scale'])? floatval($_GET['gaoji_fc_scale']):0;
    $chuji_fc_scale2     = isset($_GET['chuji_fc_scale2'])? floatval($_GET['chuji_fc_scale2']):0;
    $zhongji_fc_scale2   = isset($_GET['zhongji_fc_scale2'])? floatval($_GET['zhongji_fc_scale2']):0;
    $gaoji_fc_scale2     = isset($_GET['gaoji_fc_scale2'])? floatval($_GET['gaoji_fc_scale2']):0;
    
    $allow_refund    = isset($_GET['allow_refund'])? intval($_GET['allow_refund']):0;
    
    $zhibo_roomid    = isset($_GET['zhibo_roomid'])? intval($_GET['zhibo_roomid']):0;
    
    $mp3_link        = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $share_title     = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc      = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    
    $open_code    = isset($_GET['open_code'])? intval($_GET['open_code']):0;
    $code_help_msg     = isset($_GET['code_help_msg'])? addslashes($_GET['code_help_msg']):'';
    
    $peisong_type    = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $open_yuyue      = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $yuyue_xm        = isset($_GET['yuyue_xm'])? addslashes($_GET['yuyue_xm']):'';
    $yuyue_tel       = isset($_GET['yuyue_tel'])? addslashes($_GET['yuyue_tel']):'';
    $virtual_clicks  = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $paixu           = isset($_GET['paixu'])? intval($_GET['paixu']):1000;
    
    if($open_code == 1){
        $peisong_type = 1;
    }
    if($open_duo_shop == 1){
        $peisong_type = 1;
        $tcshop_id = 0;
    }
    
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    
    $picurl = $hehuoren_tg_haibao = $toppic = $haibao_picurl = "";
    if($_GET['act'] == 'add'){
        $picurl             = tomuploadFile("picurl");
        $toppic             = tomuploadFile("toppic");
        $hehuoren_tg_haibao = tomuploadFile("hehuoren_tg_haibao");
        $haibao_picurl      = tomuploadFile("haibao_picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl             = tomuploadFile("picurl",$infoArr['picurl']);
        $toppic             = tomuploadFile("toppic",$infoArr['toppic']);
        $hehuoren_tg_haibao = tomuploadFile("hehuoren_tg_haibao",$infoArr['hehuoren_tg_haibao']);
        $haibao_picurl      = tomuploadFile("haibao_picurl",$infoArr['haibao_picurl']);
    }
    
    $data['user_id']            = $tcshopInfo['user_id'];
    $data['tcshop_id']          = $tcshopInfo['id'];
    $data['latitude']           = $tcshopInfo['latitude'];
    $data['longitude']          = $tcshopInfo['longitude'];
    $data['cate_id']            = $cate_id;
    $data['tcchoujiang_id']     = $tcchoujiang_id;
    $data['title']              = $title;
    $data['yongjin_type']       = $yongjin_type;
    $data['yongjin_bili']       = $yongjin_bili;
    $data['open_shop_yongjin']  = $open_shop_yongjin;
    $data['shop_yongjin']       = $shop_yongjin;
    $data['admin_edit']         = $admin_edit;
    $data['xuzhi']              = $xuzhi;
    $data['content']            = $content;
    $data['xiangou_num']        = $xiangou_num;
    $data['min_num']            = $min_num;
    $data['hasoption']          = $hasoption;
    $data['open_xubuy']         = $open_xubuy;
    $data['picurl']             = $picurl;
    $data['toppic']             = $toppic;
    $data['market_price']       = $market_price;
    $data['buy_price']          = $buy_price;
    $data['open_ding_pay']      = $open_ding_pay;
    $data['ding_price']         = $ding_price;
    $data['open_vip']           = $open_vip;
    $data['vip_price']          = $vip_price;
    $data['open_before']        = $open_before;
    $data['before_price']       = $before_price;
    $data['before_num']         = $before_num;
    $data['coupon_price']       = $coupon_price;
    $data['coupon_limit']       = $coupon_limit;
    $data['coupon_zhekou']      = $coupon_zhekou;
    $data['coupon_is_buy']      = $coupon_is_buy;
    $data['coupon_buy_price']   = $coupon_buy_price;
    $data['coupon_msg']         = $coupon_msg;
    $data['start_time']         = $start_time;
    $data['end_time']           = $end_time;
    $data['hexiao_start_time']  = $hexiao_start_time;
    $data['hexiao_time']        = $hexiao_time;
    $data['open_hexiao_valid']  = $open_hexiao_valid;
    $data['hexiao_valid_days']  = $hexiao_valid_days;
    $data['hexiao_pwd']         = $hexiao_pwd;
    $data['haibao_type']        = $haibao_type;
    $data['haibao_msg']         = $haibao_msg;
    $data['qianggou_ids']       = $qianggou_ids;
    $data['haibao_picurl']      = $haibao_picurl;
    $data['qrcode_location']    = $qrcode_location;
    $data['haibao_text_color']  = $haibao_text_color;
    $data['hehuoren_tg_open']   = $hehuoren_tg_open;
    $data['hehuoren_tg_haibao'] = $hehuoren_tg_haibao;
    $data['chuji_fc_scale']     = $chuji_fc_scale;
    $data['zhongji_fc_scale']   = $zhongji_fc_scale;
    $data['gaoji_fc_scale']     = $gaoji_fc_scale;
    $data['chuji_fc_scale2']     = $chuji_fc_scale2;
    $data['zhongji_fc_scale2']   = $zhongji_fc_scale2;
    $data['gaoji_fc_scale2']     = $gaoji_fc_scale2;
    $data['peisong_type']       = $peisong_type;
    $data['open_yuyue']         = $open_yuyue;
    $data['yuyue_xm']           = $yuyue_xm;
    $data['yuyue_tel']          = $yuyue_tel;
    $data['virtual_clicks']     = $virtual_clicks;
    if($hasoption == 0){
        $data['show_market_price']          = $market_price;
        $data['show_before_price']          = $before_price;
        $data['show_buy_price']             = $buy_price;
        $data['show_vip_price']             = $vip_price;
    }
    $data['mp3_link']           = $mp3_link;
    $data['share_title']        = $share_title;
    $data['share_desc']         = $share_desc;
    $data['allow_refund']       = $allow_refund;
    $data['open_code']          = $open_code;
    $data['code_help_msg']      = $code_help_msg;
    $data['zhibo_roomid']       = $zhibo_roomid;
    $data['paixu']              = $paixu;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$typeArray,$tcyikatongConfig;
    $options = array(
        'cate_id'           => 0,
        'tcchoujiang_id'    => 0,
        'title'             => '',
        'yongjin_type'      => 0,
        'yongjin_bili'      => 0,
        'open_shop_yongjin' => 0,
        'shop_yongjin'      => 0,
        'xiangou_num'       => 0,
        'min_num'           => 0,
        'hasoption'         => 0,
        'picurl'            => '',
        'toppic'            => '',
        'open_xubuy'        => 0,
        'market_price'      => '',
        'buy_price'         => '',
        'open_ding_pay'     => 0,
        'ding_price'        => '',
        'open_vip'          => 0,
        'vip_price'         => '',
        'open_before'       => 0,
        'before_price'      => '',
        'before_num'        => '',
        'coupon_price'      => '',
        'coupon_limit'      => '',
        'coupon_zhekou'     => '',
        'coupon_is_buy'     => 0,
        'coupon_buy_price'  => '',
        'coupon_msg'        => '',
        'start_time'        => '',
        'end_time'          => '',
        'hexiao_start_time' => '',
        'hexiao_time'       => '',
        'open_hexiao_valid' => 0,
        'hexiao_valid_days' => 0,
        'hexiao_pwd'        => '',
        'admin_edit'        => 0,
        'peisong_type'      => 1,
        'open_yuyue'        => 0,
        'yuyue_xm'          => '',
        'yuyue_tel'         => '',
        'virtual_clicks'    => 0,
        'qianggou_ids'      => '',
        'haibao_type'       => 1,
        'haibao_msg'        => '',
        'haibao_picurl'     => '',
        'qrcode_location'   => 1,
        'haibao_text_color' => '#ffffff',
        'hehuoren_tg_open'  => 2,
        'hehuoren_tg_haibao'=> '',
        'chuji_fc_scale'    => 0,
        'zhongji_fc_scale'  => 0,
        'gaoji_fc_scale'    => 0,
        'chuji_fc_scale2'    => 0,
        'zhongji_fc_scale2'  => 0,
        'gaoji_fc_scale2'    => 0,
        'mp3_link'          => '',
        'share_title'       => '',
        'share_desc'        => '',
        'allow_refund'      => 0,
        'open_code'         => 0,
        'code_help_msg'     => '',
        'zhibo_roomid'      => 0,
        'paixu'             => 1000,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['goods_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['goods_tcshop_id_msg2']),"input");

    $cateList = C::t('#tom_tcqianggou#tom_tcqianggou_cate')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $cateStr = '<tr class="header"><th>'.$Lang['goods_cate_id'].'</th><th></th></tr>';
    $cateStr.= '<tr><td width="300"><select style="width: 260px;" name="cate_id" id="cate_id">';
    foreach ($cateList as $key => $value){
        if($value['id'] == $options['cate_id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select></td><td></td></tr>';
    echo $cateStr;
    
    tomshowsetting(true,array('title'=>$Lang['goods_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['goods_title_msg']),"input");
    $open_shop_yongjin_item = array(1=>$Lang['goods_open_shop_yongjin_1'],0=>$Lang['goods_open_shop_yongjin_0']);
    tomshowsetting(true,array('title'=>$Lang['goods_open_shop_yongjin'],'name'=>'open_shop_yongjin','value'=>$options['open_shop_yongjin'],'msg'=>$Lang['goods_open_shop_yongjin_msg'],'item'=>$open_shop_yongjin_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_shop_yongjin'],'name'=>'shop_yongjin','value'=>$options['shop_yongjin'],'msg'=>$Lang['goods_shop_yongjin_msg']),"input");
    $goods_yongjin_type_item = array(1=>$Lang['goods_yongjin_type_1'],2=>$Lang['goods_yongjin_type_2']);
    tomshowsetting(true,array('title'=>$Lang['goods_yongjin_type'],'name'=>'yongjin_type','value'=>$options['yongjin_type'],'msg'=>$Lang['goods_yongjin_type_msg'],'item'=>$goods_yongjin_type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_yongjin_bili'],'name'=>'yongjin_bili','value'=>$options['yongjin_bili'],'msg'=>$Lang['goods_yongjin_bili_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_tcchoujiang_id'],'name'=>'tcchoujiang_id','value'=>$options['tcchoujiang_id'],'msg'=>$Lang['goods_tcchoujiang_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['goods_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['goods_toppic'],'name'=>'toppic','value'=>$options['toppic'],'msg'=>$Lang['goods_toppic_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['goods_xiangou_num'],'name'=>'xiangou_num','value'=>$options['xiangou_num'],'msg'=>$Lang['goods_xiangou_num_msg']),"input");
    if($options['type_id'] == 1){
        tomshowsetting(true,array('title'=>$Lang['goods_min_num'],'name'=>'min_num','value'=>$options['min_num'],'msg'=>$Lang['goods_min_num_msg']),"input");
        $goods_hasoption_item = array(0=>$Lang['goods_hasoption_0'],1=>$Lang['goods_hasoption_1']);
        tomshowsetting(true,array('title'=>$Lang['goods_hasoption'],'name'=>'hasoption','value'=>$options['hasoption'],'msg'=>$Lang['goods_hasoption_msg'],'item'=>$goods_hasoption_item),"radio");
        $open_xubuy_item = array(0=>$Lang['goods_open_xubuy_0'],1=>$Lang['goods_open_xubuy_1']);
        tomshowsetting(true,array('title'=>$Lang['goods_open_xubuy'],'name'=>'open_xubuy','value'=>$options['open_xubuy'],'msg'=>$Lang['goods_open_xubuy_msg'],'item'=>$open_xubuy_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['goods_market_price'],'name'=>'market_price','value'=>$options['market_price'],'msg'=>$Lang['goods_market_price_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['goods_buy_price'],'name'=>'buy_price','value'=>$options['buy_price'],'msg'=>$Lang['goods_buy_price_msg']),"input");
        $open_ding_pay_item = array(0=>$Lang['goods_open_ding_pay_0'],1=>$Lang['goods_open_ding_pay_1']);
        tomshowsetting(true,array('title'=>$Lang['goods_open_ding_pay'],'name'=>'open_ding_pay','value'=>$options['open_ding_pay'],'msg'=>$Lang['goods_open_ding_pay_msg'],'item'=>$open_ding_pay_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['goods_ding_price'],'name'=>'ding_price','value'=>$options['ding_price'],'msg'=>$Lang['goods_ding_price_msg']),"input");

        $open_before_item = array(0=>$Lang['goods_open_before_0'],1=>$Lang['goods_open_before_1']);
        tomshowsetting(true,array('title'=>$Lang['goods_open_before'],'name'=>'open_before','value'=>$options['open_before'],'msg'=>$Lang['goods_open_before_msg'],'item'=>$open_before_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['goods_before_price'],'name'=>'before_price','value'=>$options['before_price'],'msg'=>$Lang['goods_before_price_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['goods_before_num'],'name'=>'before_num','value'=>$options['before_num'],'msg'=>$Lang['goods_before_num_msg']),"input");
    }
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $open_vip_item = array(0=>$Lang['goods_open_vip_0'],1=>$Lang['goods_open_vip_1']);
        tomshowsetting(true,array('title'=>$Lang['goods_open_vip'],'name'=>'open_vip','value'=>$options['open_vip'],'msg'=>$tcyikatongConfig['plugin_name'].$Lang['goods_open_vip_msg'],'item'=>$open_vip_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['goods_vip_price'],'name'=>'vip_price','value'=>$options['vip_price'],'msg'=>$tcyikatongConfig['plugin_name'].$Lang['goods_vip_price_msg']),"input");
    }
    if($options['type_id'] == 2 || $options['type_id'] == 4){
        tomshowsetting(true,array('title'=>$Lang['goods_coupon_price'],'name'=>'coupon_price','value'=>$options['coupon_price'],'msg'=>$Lang['goods_coupon_price_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['goods_coupon_limit'],'name'=>'coupon_limit','value'=>$options['coupon_limit'],'msg'=>$Lang['goods_coupon_limit_msg']),"input");
    }
    if($options['type_id'] == 3){
        tomshowsetting(true,array('title'=>$Lang['goods_coupon_zhekou'],'name'=>'coupon_zhekou','value'=>$options['coupon_zhekou'],'msg'=>$Lang['goods_coupon_zhekou_msg']),"input");
    }
    if($options['type_id'] == 2 || $options['type_id'] == 3 || $options['type_id'] == 4){
        tomshowsetting(true,array('title'=>$Lang['goods_coupon_msg'],'name'=>'coupon_msg','value'=>$options['coupon_msg'],'msg'=>$Lang['goods_coupon_msg_msg']),"input");
    }
    if($options['type_id'] == 1){
        tomshowsetting(true,array('title'=>$Lang['goods_start_time'],'name'=>'start_time','value'=>$options['start_time'],'msg'=>$Lang['goods_start_time_msg']),"calendar");
        tomshowsetting(true,array('title'=>$Lang['goods_end_time'],'name'=>'end_time','value'=>$options['end_time'],'msg'=>$Lang['goods_end_time_msg']),"calendar");
    }
    
    tomshowsetting(true,array('title'=>$Lang['goods_hexiao_pwd'],'name'=>'hexiao_pwd','value'=>$options['hexiao_pwd'],'msg'=>$Lang['goods_hexiao_pwd_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_hexiao_start_time'],'name'=>'hexiao_start_time','value'=>$options['hexiao_start_time'],'msg'=>$Lang['goods_hexiao_start_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['goods_hexiao_time'],'name'=>'hexiao_time','value'=>$options['hexiao_time'],'msg'=>$Lang['goods_hexiao_time_msg']),"calendar");
    
    $open_hexiao_valid_item = array(0=>$Lang['goods_open_hexiao_valid_0'],1=>$Lang['goods_open_hexiao_valid_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_open_hexiao_valid'],'name'=>'open_hexiao_valid','value'=>$options['open_hexiao_valid'],'msg'=>$Lang['goods_open_hexiao_valid_msg'],'item'=>$open_hexiao_valid_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_hexiao_valid_days'],'name'=>'hexiao_valid_days','value'=>$options['hexiao_valid_days'],'msg'=>$Lang['goods_hexiao_valid_days_msg']),"input");
    
    if($options['type_id'] == 2 || $options['type_id'] == 3 || $options['type_id'] == 4){
        $coupon_is_buy_item = array(0=>$Lang['goods_coupon_is_buy_0'],1=>$Lang['goods_coupon_is_buy_1']);
        tomshowsetting(true,array('title'=>$Lang['goods_coupon_is_buy'],'name'=>'coupon_is_buy','value'=>$options['coupon_is_buy'],'msg'=>$Lang['goods_coupon_is_buy_msg'],'item'=>$coupon_is_buy_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['goods_coupon_buy_price'],'name'=>'coupon_buy_price','value'=>$options['coupon_buy_price'],'msg'=>$Lang['goods_coupon_buy_price_msg']),"input");
    }  
    if($options['type_id'] == 1){
        
        tomshowsetting(true,array('title'=>$Lang['goods_qianggou_ids'],'name'=>'qianggou_ids','value'=>$options['qianggou_ids'],'msg'=>$Lang['goods_qianggou_ids_msg']),"input");
        $haibao_type_item = array(1=>$Lang['goods_haibao_type_1'],2=>$Lang['goods_haibao_type_2']);
        tomshowsetting(true,array('title'=>$Lang['goods_haibao_type'],'name'=>'haibao_type','value'=>$options['haibao_type'],'msg'=>$Lang['goods_haibao_type_msg'],'item'=>$haibao_type_item),"radio");
    }
    
    tomshowsetting(true,array('title'=>$Lang['goods_haibao_msg'],'name'=>'haibao_msg','value'=>$options['haibao_msg'],'msg'=>$Lang['goods_haibao_msg_msg']),"input");
    
    if($options['type_id'] == 1){
        tomshowsetting(true,array('title'=>$Lang['goods_haibao_picurl'],'name'=>'haibao_picurl','value'=>$options['haibao_picurl'],'msg'=>$Lang['goods_haibao_picurl_msg']),"file");
        $qrcode_location_item = array(1=>$Lang['goods_qrcode_location_1'],2=>$Lang['goods_qrcode_location_2']);
        tomshowsetting(true,array('title'=>$Lang['goods_qrcode_location'],'name'=>'qrcode_location','value'=>$options['qrcode_location'],'msg'=>$Lang['goods_qrcode_location_msg'],'item'=>$qrcode_location_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['goods_haibao_text_color'],'name'=>'haibao_text_color','value'=>$options['haibao_text_color'],'msg'=>$Lang['goods_haibao_text_color_msg']),"input");
    }
    $open_hehuoren_tg_item = array(1=>$Lang['open'],2=>$Lang['close']);
    tomshowsetting(true,array('title'=>$Lang['goods_hehuoren_tg_open'],'name'=>'hehuoren_tg_open','value'=>$options['hehuoren_tg_open'],'msg'=>$Lang['goods_hehuoren_tg_open_msg'],'item'=>$open_hehuoren_tg_item),"radio");
    //tomshowsetting(true,array('title'=>$Lang['goods_hehuoren_tg_haibao'],'name'=>'hehuoren_tg_haibao','value'=>$options['hehuoren_tg_haibao'],'msg'=>$Lang['goods_hehuoren_tg_haibao_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['goods_chuji_fc_scale'],'name'=>'chuji_fc_scale','value'=>$options['chuji_fc_scale'],'msg'=>$Lang['goods_chuji_fc_scale_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_zhongji_fc_scale'],'name'=>'zhongji_fc_scale','value'=>$options['zhongji_fc_scale'],'msg'=>$Lang['goods_zhongji_fc_scale_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_gaoji_fc_scale'],'name'=>'gaoji_fc_scale','value'=>$options['gaoji_fc_scale'],'msg'=>$Lang['goods_gaoji_fc_scale_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_chuji_fc_scale2'],'name'=>'chuji_fc_scale2','value'=>$options['chuji_fc_scale2'],'msg'=>$Lang['goods_chuji_fc_scale2_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_zhongji_fc_scale2'],'name'=>'zhongji_fc_scale2','value'=>$options['zhongji_fc_scale2'],'msg'=>$Lang['goods_zhongji_fc_scale2_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_gaoji_fc_scale2'],'name'=>'gaoji_fc_scale2','value'=>$options['gaoji_fc_scale2'],'msg'=>$Lang['goods_gaoji_fc_scale2_msg']),"input");

    if($options['type_id'] == 1){
        $peisong_type_item = array(1=>$Lang['goods_peisong_type_1'],2=>$Lang['goods_peisong_type_2'],3=>$Lang['goods_peisong_type_3']);
        tomshowsetting(true,array('title'=>$Lang['goods_peisong_type'],'name'=>'peisong_type','value'=>$options['peisong_type'],'msg'=>$Lang['goods_peisong_type_msg'],'item'=>$peisong_type_item),"radio");
        $open_yuyue_item = array(0=>$Lang['goods_open_yuyue_0'],1=>$Lang['goods_open_yuyue_1']);
        tomshowsetting(true,array('title'=>$Lang['goods_open_yuyue'],'name'=>'open_yuyue','value'=>$options['open_yuyue'],'msg'=>$Lang['goods_open_yuyue_msg'],'item'=>$open_yuyue_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['goods_yuyue_xm'],'name'=>'yuyue_xm','value'=>$options['yuyue_xm'],'msg'=>$Lang['goods_yuyue_xm_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['goods_yuyue_tel'],'name'=>'yuyue_tel','value'=>$options['yuyue_tel'],'msg'=>$Lang['goods_yuyue_tel_msg']),"input");
    }
    tomshowsetting(true,array('title'=>$Lang['goods_zhibo_roomid'],'name'=>'zhibo_roomid','value'=>$options['zhibo_roomid'],'msg'=>$Lang['goods_zhibo_roomid_msg']),"input");
    if($options['type_id'] == 1){
        $allow_refund_item = array(0=>$Lang['goods_allow_refund_0'],1=>$Lang['goods_allow_refund_1']);
        tomshowsetting(true,array('title'=>$Lang['goods_allow_refund'],'name'=>'allow_refund','value'=>$options['allow_refund'],'msg'=>$Lang['goods_allow_refund_msg'],'item'=>$allow_refund_item),"radio");

        $open_code_item = array(0=>$Lang['goods_open_code_0'],1=>$Lang['goods_open_code_1']);
        tomshowsetting(true,array('title'=>$Lang['goods_open_code'],'name'=>'open_code','value'=>$options['open_code'],'msg'=>$Lang['goods_open_code_msg'],'item'=>$open_code_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['goods_code_help_msg'],'name'=>'code_help_msg','value'=>$options['code_help_msg'],'msg'=>$Lang['goods_code_help_msg_msg']),"textarea");

        tomshowsetting(true,array('title'=>$Lang['goods_mp3_link'],'name'=>'mp3_link','value'=>$options['mp3_link'],'msg'=>$Lang['goods_mp3_link_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['goods_virtual_clicks'],'name'=>'virtual_clicks','value'=>$options['virtual_clicks'],'msg'=>$Lang['goods_virtual_clicks_msg']),"input");
    }
    tomshowsetting(true,array('title'=>$Lang['goods_share_title'],'name'=>'share_title','value'=>$options['share_title'],'msg'=>$Lang['goods_share_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_share_desc'],'name'=>'share_desc','value'=>$options['share_desc'],'msg'=>$Lang['goods_share_desc_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['goods_paixu_msg']),"input");

    $admin_edit_item = array(0=>$Lang['goods_admin_edit_0'],1=>$Lang['goods_admin_edit_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_admin_edit'],'name'=>'admin_edit','value'=>$options['admin_edit'],'msg'=>$Lang['goods_admin_edit_msg'],'item'=>$admin_edit_item),"radio");
    if($options['type_id'] == 1){
        tomshowsetting(true,array('title'=>$Lang['goods_xuzhi'],'name'=>'xuzhi','value'=>$options['xuzhi'],'msg'=>$Lang['goods_xuzhi_msg']),"text");
    }
    tomshowsetting(true,array('title'=>$Lang['goods_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['goods_content_msg']),"text");
        
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['goods_edit'],"",true);
    }else if($_GET['act'] == 'photo'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_photo'],"",true);
    }else{
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}