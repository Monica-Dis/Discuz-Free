<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=goods_tz&goods_id='.$_GET['goods_id'];
$modListUrl = $adminListUrl.'&tmod=goods_tz&goods_id='.$_GET['goods_id'];
$modFromUrl = $adminFromUrl.'&tmod=goods_tz&goods_id='.$_GET['goods_id'];

if($_GET['act'] == 'send'){
    
    $goodsTzInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_tz')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $remark = '';
        if($goodsTzInfo['type'] == 2){
            $remark = $Lang['goods_tz_send_type_2_msg'];
        }
        
        $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goodsTzInfo['goods_id']);
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsTzInfo['user_id']);
        
        $tz_cpmsg = $Lang['goods_tz_send_err'];
        
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            if($goodsInfo['type_id'] == 1){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$goodsInfo['site_id']}&mod=details&goods_id=".$goodsInfo['id']);
            }else{
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$goodsInfo['site_id']}&mod=coupon&goods_id=".$goodsInfo['id']);
            }
            $smsData = array(
                'first'         => $text,
                'keyword1'      => $tcqianggouConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $remark
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            
            $updateData = array();
            if($r){
                $tz_cpmsg = $Lang['goods_tz_send_succ'];
                $updateData['tz_status'] = 2;
                $updateData['tz_time'] = TIMESTAMP;
            }else{
                $updateData['tz_status'] = 3;
                $updateData['tz_time'] = TIMESTAMP;
            }
            C::t('#tom_tcqianggou#tom_tcqianggou_goods_tz')->update($goodsTzInfo['id'],$updateData);
        }
        
        cpmsg($tz_cpmsg, $modListUrl, 'succeed');
    }else{
        
        tomloadcalendarjs();
        loadeditorjs();
        showformheader($modFromUrl.'&act=send&id='.$_GET['id'],'enctype');
        showtableheader(); //dism��taobao��com
        tomshowsetting(true,array('title'=>$Lang['goods_tz_send_text_title'],'name'=>'text','value'=>'','msg'=>$Lang['goods_tz_send_text_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }

}else if($_GET['act'] == 'qun_send'){
    
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['goods_id']);
    
    if(submitcheck('submit')){
        
        $send_type  = intval($_GET['send_type'])>0? intval($_GET['send_type']):1;
        $text       = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $sendCount = 0;
        if($send_type == 1){
            $sendCount = C::t('#tom_tcqianggou#tom_tcqianggou_goods_tz')->fetch_all_count("AND goods_id = {$goodsInfo['id']} AND type = 1 "); 
            if($sendCount <= 0){
                cpmsg($Lang['goods_tz_send_err_301'], $modListUrl.'&act=qun_send&goods_id='.$goodsInfo['id'], 'error');exit;
            }
        }else if($send_type == 2){
            $sendCount = C::t('#tom_tcshop#tom_tcshop_guanzu')->fetch_all_count(" AND tcshop_id = {$goodsInfo['tcshop_id']} ");
            if($sendCount <= 0){
                cpmsg($Lang['goods_tz_send_err_302'], $modListUrl.'&act=qun_send&goods_id='.$goodsInfo['id'], 'error');exit;
            }
        }else if($send_type == 3){
            $sendCount = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(" AND goods_id = {$goodsInfo['id']} AND order_status=2 ");
            if($sendCount <= 0){
                cpmsg($Lang['goods_tz_send_err_303'], $modListUrl.'&act=qun_send&goods_id='.$goodsInfo['id'], 'error');exit;
            }
        }
        
        $modQunfaListUrl = $modBaseUrl."&act=doqunfa&send_type={$send_type}&text={$text}&formhash=".FORMHASH;
        
        showtableheader(); //dism��taobao��com
        echo '<tr><th colspan="15" class="partition">' . $goodsInfo['title'] .'&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;'.$Lang['goods_tz_send_qunfa_title']. '</th></tr>';
        
        echo '<tr class="header">';
        echo '<td width="150px">'.$Lang['goods_tz_send_type'].$Lang['fenghao'].'</td>';
        if($send_type == 1){
            echo '<td>' . $Lang['goods_tz_send_type_1'] . '</td>';
        }else if($send_type == 2){
            echo '<td>' . $Lang['goods_tz_send_type_2'] . '</td>';
        }else if($send_type == 3){
            echo '<td>' . $Lang['goods_tz_send_type_3'] . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        echo '</tr>';
        
        echo '<tr class="header">';
        echo '<td width="80px">'.$Lang['goods_tz_send_qunfa_text'].'</td>';
        echo '<td>' . $text . '</td>';
        echo '</tr>';
        
        echo '<tr class="header">';
        echo '<td width="80px">'.$Lang['goods_tz_send_qunfa_num'].'</td>';
        echo '<td>' . $sendCount . '</td>';
        echo '</tr>';
        
        echo '<tr>';
        echo '<td colspan="15"><a href="'.$modQunfaListUrl.'" style="color: #FA6A03; padding:2px 7px; font-weight:600; margin-left: 10px; border-radius: 5px; border: 1px solid #FA6A03;">'.$Lang['goods_tz_send_qunfa_btn'].'</a></td>';
        echo '</tr>';
        showtablefooter(); //Dism��taobao��com
        
    }else{
        
        tomloadcalendarjs();
        loadeditorjs();
        
        showtableheader(); //dism��taobao��com
        echo '<tr><th colspan="15" class="partition">' . $goodsInfo['title'] .'&nbsp;&nbsp;&gt;&gt;&nbsp;&nbsp;'.$Lang['goods_tz_send_qunfa_title']. '</th></tr>';
        showtablefooter(); //Dism��taobao��com
        
        showformheader($modFromUrl.'&act=qun_send&goods_id='.$_GET['goods_id'],'enctype');
        showtableheader(); //dism��taobao��com
        
        if($goodsInfo['open_duo_shop'] == 1){
            $send_type_item = array(1=>$Lang['goods_tz_send_type_1'],3=>$Lang['goods_tz_send_type_3']);
        }else{
            $send_type_item = array(1=>$Lang['goods_tz_send_type_1'],2=>$Lang['goods_tz_send_type_2'],3=>$Lang['goods_tz_send_type_3']);
        }
        
        tomshowsetting(true,array('title'=>$Lang['goods_tz_send_type'],'name'=>'send_type','value'=>1,'msg'=>$Lang['goods_tz_send_type_msg'],'item'=>$send_type_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['goods_tz_send_text_title'],'name'=>'text','value'=>'','msg'=>$Lang['goods_tz_send_text_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'doqunfa'){
    
    $send_type  = intval($_GET['send_type'])>0? intval($_GET['send_type']):1;
    $goods_id   = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    $text       = isset($_GET['text'])? addslashes($_GET['text']):'';
    $page       = isset($_GET['page'])? intval($_GET['page']):1;
    $nextpage   = $page + 1;
    
    $pagesize = 5;
    $start = ($page-1)*$pagesize;	
    
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
    $tcshopInfo = array();
    if($goodsInfo['tcshop_id'] > 0){
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
    }
    
    $remark = '';
    $tzList = array();
    $count  = 0;
    if($send_type == 1){
        $count  = C::t('#tom_tcqianggou#tom_tcqianggou_goods_tz')->fetch_all_count("AND goods_id = {$goodsInfo['id']} AND type = 1 "); 
        $tzList = C::t('#tom_tcqianggou#tom_tcqianggou_goods_tz')->fetch_all_list("AND goods_id = {$goodsInfo['id']} AND type = 1 ", 'ORDER BY id DESC', $start, $pagesize); 
    }else if($send_type == 2){
        $remark = $Lang['goods_tz_send_type_2_msg'];
        $count  = C::t('#tom_tcshop#tom_tcshop_guanzu')->fetch_all_count(" AND tcshop_id = {$goodsInfo['tcshop_id']} ");
        $tzList = C::t('#tom_tcshop#tom_tcshop_guanzu')->fetch_all_list(" AND tcshop_id = {$goodsInfo['tcshop_id']} ", 'ORDER BY id DESC', $start, $pagesize);
    }else if($send_type == 3){
        $count  = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_count(" AND goods_id = {$goodsInfo['id']} AND order_status=2 ");
        $tzList = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_all_list(" AND goods_id = {$goodsInfo['id']} AND order_status=2 ", 'ORDER BY id DESC', $start, $pagesize);
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $weixinClass = new weixinClass($appid,$appsecret);
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    
    $allPageNum = ceil($count/$pagesize);
    
    if($page <= $allPageNum){
        
        if(is_array($tzList) && !empty($tzList)){
            foreach($tzList as $key => $value){
                
                $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
                
                if($send_type == 2 || $send_type == 3){
                    if($send_type == 2){
                        $tzInfoTmp  = C::t("#tom_tcqianggou#tom_tcqianggou_goods_tz")->fetch_by(" AND user_id = {$value['user_id']} AND goods_id = {$goodsInfo['id']} AND type = 2 ");
                    }else if($send_type == 3){
                        $tzInfoTmp  = C::t("#tom_tcqianggou#tom_tcqianggou_goods_tz")->fetch_by(" AND user_id = {$value['user_id']} AND goods_id = {$goodsInfo['id']} AND type = 3 ");
                    }
                    if(is_array($tzInfoTmp) && !empty($tzInfoTmp)){
                    }else{
                        $insertData = array();
                        $insertData['goods_id']     = $goods_id;
                        if($send_type == 2){
                            $insertData['type']     = 2;
                        }else if($send_type == 3){
                            $insertData['order_no'] = $value['order_no'];
                            $insertData['type']     = 3;
                        }
                        $insertData['user_id']      = $userInfoTmp['id'];
                        $insertData['openid']       = $userInfoTmp['openid'];
                        $insertData['add_time']     = TIMESTAMP;
                        if(C::t('#tom_tcqianggou#tom_tcqianggou_goods_tz')->insert($insertData)){
                            $tz_id      = C::t('#tom_tcqianggou#tom_tcqianggou_goods_tz')->insert_id();
                            $tzInfoTmp  = C::t('#tom_tcqianggou#tom_tcqianggou_goods_tz')->fetch_by_id($tz_id);
                        }
                    }
                }else{
                    $tzInfoTmp = $value;
                }
                
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($userInfoTmp['openid'])){
                    if($send_type == 3){
                        $templateSmsClass   = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$goodsInfo['site_id']}&mod=mylist&type=1&t_id=1");
                    }else{
                        if($goodsInfo['type_id'] == 1){
                            $templateSmsClass   = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$goodsInfo['site_id']}&mod=details&goods_id={$goods_id}");
                        }else{
                            $templateSmsClass   = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$goodsInfo['site_id']}&mod=coupon&goods_id={$goods_id}");
                        }
                    }
                    $smsData = array(
                        'first'         => $text,
                        'keyword1'      => $tcqianggouConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                        'remark'        => $remark
                    );
                    if($send_type == 2){
                        $smsData['keyword1'] = $tcshopInfo['name'];
                    }
                    @$r = $templateSmsClass->sendSms01($userInfoTmp['openid'], $tongchengConfig['template_id'],$smsData);
                    $updateData = array();
                    if($r){
                        $updateData['tz_status'] = 2;
                    }else{
                        $updateData['tz_status'] = 3;
                    }
                    $updateData['tz_time'] = TIMESTAMP;
                     C::t('#tom_tcqianggou#tom_tcqianggou_goods_tz')->update($tzInfoTmp['id'], $updateData);
                }
            }
        }
        
        $qunfa_do_msg = str_replace("{PAGES}", $page, $Lang['qunfa_do_msg']);
        $qunfa_do_msg = str_replace("{COUNT}", $allPageNum, $qunfa_do_msg);
        
        $modQunfaListUrl = $modListUrl."&act=doqunfa&page={$nextpage}&send_type={$send_type}&text={$text}&goods_id={$goodsInfo['id']}&formhash=".FORMHASH;
        cpmsg($qunfa_do_msg, $modQunfaListUrl, 'loadingform');
        
    }else{
        cpmsg($Lang['qunfa_do_success'], $modListUrl."&goods_id={$goodsInfo['id']}", 'succeed');
    }
    
}else{
    
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $goods_id   = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
    $status     = intval($_GET['status'])>0? intval($_GET['status']):0;
    $type       = intval($_GET['type'])>0? intval($_GET['type']):0;
    
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
    
    $where = " AND goods_id = {$goods_id} ";
    if($status > 0){
        $where .= " AND tz_status = {$status} ";
    }
    if($type > 0){
        $where .= " AND type = {$type} ";
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $goodsTzList = C::t('#tom_tcqianggou#tom_tcqianggou_goods_tz')->fetch_all_list($where," ORDER BY tz_time DESC,id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&goods_id={$goods_id}&status={$status}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); //dism��taobao��com
    echo '<tr><th colspan="15" class="partition">' . $Lang['tcqianggou_search_title'] . '</th></tr>';
    $type_1 = $type_2 = $type_3 = '';
    if($type == 1){
        $type_1 = 'selected';
    }else if($type == 2){
        $type_2 = 'selected';
    }else if($type == 3){
        $type_3 = 'selected';
    }
    $typeStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_tz_type'].'</b></td>';
    $typeStr.= '<td><select style="width: 260px;" name="type" id="type">';
    $typeStr.=  '<option value="0">'.$Lang['goods_tz_type_all'].'</option>';
    $typeStr.=  '<option value="1" '.$type_1.'>'.$Lang['goods_tz_type_1'].'</option>';
    $typeStr.=  '<option value="2" '.$type_2.'>'.$Lang['goods_tz_type_2'].'</option>';
    $typeStr.=  '<option value="3" '.$type_3.'>'.$Lang['goods_tz_type_3'].'</option>';
    $typeStr.= '</select></td></tr>';
    echo $typeStr;
    $status_1 = $status_2 = $status_3 = '';
    if($status == 1){
        $status_1 = 'selected';
    }else if($status == 2){
        $status_2 = 'selected';
    }else if($status == 3){
        $status_3 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_tz_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
    $statusStr.=  '<option value="0">'.$Lang['goods_tz_status_all'].'</option>';
    $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['goods_tz_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['goods_tz_status_2'].'</option>';
    $statusStr.=  '<option value="3" '.$status_3.'>'.$Lang['goods_tz_status_3'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter(); //Dism��taobao��com
    showformfooter(); //Dism_taobao_com
    
    tomshownavheader();
    tomshownavli($Lang['goods_tz_list_title'],$modBaseUrl,true);
    if($_GET['goods_id'] > 0){
        tomshownavli($Lang['goods_tz_send_qunfa_title'],$modBaseUrl.'&act=qun_send&goods_id='.$_GET['goods_id'].'&formhash='.FORMHASH,false);
    }
    tomshownavfooter();
    
    showtableheader(); //dism��taobao��com
    echo '<tr class="header">';
    echo '<th width="200px">' . $Lang['goods_tz_goods_title'] . '</th>';
    echo '<th>' . $Lang['goods_tz_user'] . '</th>';
    echo '<th>' . $Lang['goods_tz_type'] . '</th>';
    echo '<th>' . $Lang['goods_tz_order_no'] . '</th>';
    echo '<th>' . $Lang['goods_tz_status'] . '</th>';
    echo '<th>' . $Lang['goods_tz_time'] . '</th>';
    echo '<th>' . $Lang['goods_tz_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($goodsTzList as $key => $value) {
        
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $goodsInfo = C::t("#tom_tcqianggou#tom_tcqianggou_goods")->fetch_by_id($value['goods_id']);
        
        echo '<tr>';
        echo '<td>' . $goodsInfo['title'] . '<font color="#f00">(ID:'.$value['goods_id'].')</font></td>';
        echo '<td>' . $userInfo['nickname'] . '<font color="#f00">(ID:'.$value['user_id'].')</font></td>';
        
        if($value['type'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['goods_tz_type_1'] . '</font></td>';
            echo '<td> -- </td>';
        }else if($value['type'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['goods_tz_type_2'] . '</font></td>';
            echo '<td> -- </td>';
        }else if($value['type'] == 3){
            echo '<td><font color="#0a9409">' . $Lang['goods_tz_type_3'] . '</font></td>';
            echo '<td><font color="#0a9409">' . $value['order_no'] . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if($value['tz_status'] == 1){
            echo '<td><font color="#f70404">' . $Lang['goods_tz_status_1'] . '</font></td>';
        }else if($value['tz_status'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['goods_tz_status_2'] . '</font></td>';
        }else if($value['tz_status'] == 3){
            echo '<td><font color="#f70404">' . $Lang['goods_tz_status_3'] . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if($value['tz_time'] > 0){
            echo '<td>' . dgmdate($value['tz_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        }else{
            echo '<td> -- </td>';
        }
        
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=send&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_tz_send'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); //Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}