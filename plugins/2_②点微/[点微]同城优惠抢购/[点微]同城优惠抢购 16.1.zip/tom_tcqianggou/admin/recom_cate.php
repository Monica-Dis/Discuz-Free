<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=recom_cate';
$modListUrl = $adminListUrl.'&tmod=recom_cate';
$modFromUrl = $adminFromUrl.'&tmod=recom_cate';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); //dism��taobao��com
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }
    
}else if($_GET['act'] == 'edit'){
    $cateInfo = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($cateInfo);
        C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->update($cateInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); //dism��taobao��com
        __create_info_html($cateInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'update_status'){
    
    $updateData = array();
    $updateData['status'] = $_GET['status'];
    C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    $site_id    = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $type       = intval($_GET['type'])>0? intval($_GET['type']):0;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if($site_id > 0){
        $where.= " AND site_id={$site_id} ";
    }
    if($type > 0){
        $where.= " AND type={$type} ";
    }
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_count($where);
    $cateList = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_list($where," ORDER BY site_id ASC,csort ASC,id DESC ",$start,$pagesize);
    
    showtableheader(); //dism��taobao��com
    echo '<tr><th colspan="15" class="partition">' . $Lang['recom_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['recom_help_1'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter(); //Dism��taobao��com
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&type={$type}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); //dism��taobao��com
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    if($site_id == 1){
        $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    }else{
        $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    }
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $type_1 = $type_2 = '';
    if($type == 1){
        $type_1 = 'selected';
    }else if($type == 2){
        $type_2 = 'selected';
    }
    $typeStr = '<tr><td width="100" align="right"><b>'.$Lang['recom_type'].'</b></td>';
    $typeStr.= '<td><select style="width: 260px;" name="type" id="type">';
    $typeStr.= '<option value="0">'.$Lang['sites_all'].'</option>';
    $typeStr.= '<option value="1" '.$type_1.'>'.$Lang['recom_type_1'].'</option>';
    $typeStr.= '<option value="2" '.$type_2.'>'.$Lang['recom_type_2'].'</option>';
    $typeStr.= '</select></td></tr>';
    echo $typeStr;
    showsubmit('submit', 'submit');
    showtablefooter(); //Dism��taobao��com
    showformfooter(); //Dism_taobao_com
    
    __create_nav_html();
    showtableheader(); //dism��taobao��com
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['recom_name'] . '</th>';
    echo '<th>' . $Lang['recom_sub_title'] . '</th>';
    echo '<th>' . $Lang['recom_type'] . '</th>';
    echo '<th>' . $Lang['recom_template_type'] . '</th>';
    echo '<th>' . $Lang['recom_index_show_num'] . '</th>';
    echo '<th>' . $Lang['recom_toppic'] . '</th>';
    echo '<th>' . $Lang['recom_status'] . '</th>';
    echo '<th>' . $Lang['recom_csort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($cateList as $key => $value) {
        
        if(!preg_match('/^http/', $value['toppic']) ){
            if(strpos($value['toppic'], 'source/plugin/tom_') === FALSE){
                $toppic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['toppic'];
            }else{
                $toppic = $value['toppic'];
            }
        }else{
            $toppic = $value['toppic'];
        }
        
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 1){
            echo '<td><font color="#0a9409">' . $siteInfo['name'] . '</font></td>';
        }else{
            echo '<td><font color="#0a9409">' . $Lang['sites_one'] . '</font></td>';
        }
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['sub_title'] . '</td>';
        
        if($value['type'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['recom_type_1'] . '</font></td>';
        }else if($value['type'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['recom_type_2'] . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if($value['template_type'] == 1){
            echo '<td><font color="#0a9409">' . $Lang['recom_template_type_1'] . '</font></td>';
        }else if($value['template_type'] == 2){
            echo '<td><font color="#0a9409">' . $Lang['recom_template_type_2'] . '</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        echo '<td>' . $value['index_show_num'] . '</td>';
        if(!empty($value['toppic'])){
            echo '<td><a href="'.$toppic.'" target="_blank"><img src="'.$toppic.'" width="40" /></a></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['recom_status_1'] . '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=update_status&status=0&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['recom_status_0']. '</a>&nbsp;)</td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['recom_status_0'] . '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=update_status&status=1&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['recom_status_1']. '</a>&nbsp;)</td>';
        }
        
        echo '<td>' . $value['csort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['recom_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); //Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;

}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $sub_title      = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $type           = isset($_GET['type'])? intval($_GET['type']):1;
    $template_type  = isset($_GET['template_type'])? intval($_GET['template_type']):1;
    $index_show_num = isset($_GET['index_show_num'])? intval($_GET['index_show_num']):0;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $csort          = isset($_GET['csort'])? intval($_GET['csort']):10;
    
    $toppic = "";
    if($_GET['act'] == 'add'){
        $toppic         = tomuploadFile("toppic");
    }else if($_GET['act'] == 'edit'){
        $toppic         = tomuploadFile("toppic",$infoArr['toppic']);
    }
    
    $data['site_id']            = $site_id;
    $data['name']               = $name;
    $data['sub_title']          = $sub_title;
    $data['type']               = $type;
    $data['template_type']      = $template_type;
    $data['index_show_num']     = $index_show_num;
    $data['toppic']             = $toppic;
    $data['status']             = $status;
    $data['csort']              = $csort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'site_id'        => 1,
        'name'           => '',
        'sub_title'      => '',
        'type'           => 1,
        'template_type'  => 1,
        'index_show_num' => 4,
        'toppic'         => '',
        'status'         => 1,
        'csort'          => 10,
    );
    $options = array_merge($options, $infoArr);
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    $type_item = array(1=>$Lang['recom_type_1'],2=>$Lang['recom_type_2']);
    tomshowsetting(true,array('title'=>$Lang['recom_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['recom_type_msg'],'item'=>$type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['recom_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['recom_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['recom_sub_title'],'name'=>'sub_title','value'=>$options['sub_title'],'msg'=>$Lang['recom_sub_title_msg']),"input");
    $template_type_item = array(1=>$Lang['recom_template_type_1'],2=>$Lang['recom_template_type_2']);
    tomshowsetting(true,array('title'=>$Lang['recom_template_type'],'name'=>'template_type','value'=>$options['template_type'],'msg'=>$Lang['recom_template_type_msg'],'item'=>$template_type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['recom_index_show_num'],'name'=>'index_show_num','value'=>$options['index_show_num'],'msg'=>$Lang['recom_index_show_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['recom_toppic'],'name'=>'toppic','value'=>$options['toppic'],'msg'=>$Lang['recom_toppic_msg']),"file");
    $recom_status_item = array(1=>$Lang['recom_status_1'],0=>$Lang['recom_status_0']);
    tomshowsetting(true,array('title'=>$Lang['recom_status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['recom_status_msg'],'item'=>$recom_status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['recom_csort'],'name'=>'csort','value'=>$options['csort'],'msg'=>$Lang['recom_csort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['recom_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['recom_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['recom_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['recom_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['recom_edit'],"",true);
    }else{
        tomshownavli($Lang['recom_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['recom_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}