<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=group_qrcode';
$modListUrl = $adminListUrl.'&tmod=group_qrcode';
$modFromUrl = $adminFromUrl.'&tmod=group_qrcode';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['status']   = 1;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); //dism��taobao��com
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }
    
}else if($_GET['act'] == 'edit'){
    $qrcodeInfo = C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($qrcodeInfo);
        C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->update($qrcodeInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); //dism��taobao��com
        __create_info_html($qrcodeInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'update_status'){
    
    $updateData = array();
    $updateData['status'] = $_GET['status'];
    C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    showtableheader(); //dism��taobao��com
    echo '<tr><th colspan="15" class="partition">' . $Lang['qrcode_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><font color="#F60">'.$Lang['qrcode_help_title_1'].'</font></li>';
    echo '</ul></td></tr>';
    showtablefooter(); //Dism��taobao��com
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->fetch_all_count(" ");
    $qrcodeList = C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->fetch_all_list(" "," ORDER BY id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader(); //dism��taobao��com
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['qrcode_name'] . '</th>';
    echo '<th>' . $Lang['qrcode_goods'] . '</th>';
    echo '<th>' . $Lang['qrcode_logo'] . '</th>';
    echo '<th>' . $Lang['qrcode_qrcode'] . '</th>';
    echo '<th width="200px">' . $Lang['qrcode_desc'] . '</th>';
    echo '<th width="200px">' . $Lang['qrcode_tishi'] . '</th>';
    echo '<th>' . $Lang['qrcode_status'] . '</th>';
    echo '<th>' . $Lang['qrcode_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($qrcodeList as $key => $value) {
        
        $logo = tomgetfileurl($value['logo']);
        $qrcode = tomgetfileurl($value['qrcode']);
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($value['goods_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $value['name'] . '</td>';
        
        if($value['goods_id'] > 0){
            echo '<td>' . $goodsInfo['title'] . '<font color="#f00">(ID:'.$value['goods_id'].')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        
        echo '<td><a href="'.$logo.'" target="_blank"><img src="'.$logo.'" width="40" /></a></td>';
        echo '<td><a href="'.$qrcode.'" target="_blank"><img src="'.$qrcode.'" width="40" /></a></td>';
        echo '<td>' . $value['desc'] . '</td>';
        echo '<td>' . $value['tishi_msg'] . '</td>';
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['qrcode_status_1'] . '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=update_status&status=0&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['qrcode_status_0']. '</a>&nbsp;)</td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['qrcode_status_0'] . '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=update_status&status=1&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['qrcode_status_1']. '</a>&nbsp;)</td>';
        }
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); //Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $desc           = isset($_GET['desc'])? addslashes($_GET['desc']):'';
    $tishi_msg      = isset($_GET['tishi_msg'])? addslashes($_GET['tishi_msg']):'';
    
    $logo = $qrcode = "";
    if($_GET['act'] == 'add'){
        $logo       = tomuploadFile("logo");
        $qrcode     = tomuploadFile("qrcode");
    }else if($_GET['act'] == 'edit'){
        $logo       = tomuploadFile("logo",$infoArr['logo']);
        $qrcode     = tomuploadFile("qrcode",$infoArr['qrcode']);
    }
    
    $data['site_id']            = $site_id;
    $data['goods_id']           = $goods_id;
    $data['name']               = $name;
    $data['logo']               = $logo;
    $data['qrcode']             = $qrcode;
    $data['desc']               = $desc;
    $data['tishi_msg']          = $tishi_msg;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'site_id'       => 1,
        'goods_id'      => 0,
        'name'          => '',
        'logo'          => '',
        'qrcode'        => '',
        'desc'          => '',
        'tishi_msg'     => '',
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['qrcode_site_id'],'name'=>'site_id','value'=>$options['site_id'],'msg'=>$Lang['qrcode_site_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['qrcode_goods_id'],'name'=>'goods_id','value'=>$options['goods_id'],'msg'=>$Lang['qrcode_goods_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['qrcode_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['qrcode_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['qrcode_logo'],'name'=>'logo','value'=>$options['logo'],'msg'=>$Lang['qrcode_logo_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['qrcode_qrcode'],'name'=>'qrcode','value'=>$options['qrcode'],'msg'=>$Lang['qrcode_qrcode_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['qrcode_desc'],'name'=>'desc','value'=>$options['desc'],'msg'=>$Lang['qrcode_desc_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['qrcode_tishi'],'name'=>'tishi_msg','value'=>$options['tishi_msg'],'msg'=>$Lang['qrcode_tishi_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['qrcode_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['qrcode_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['qrcode_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['qrcode_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['edit'],"",true);
    }else{
        tomshownavli($Lang['qrcode_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['qrcode_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}