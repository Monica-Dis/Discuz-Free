<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=option&goods_id='.$_GET['goods_id'];
$modListUrl = $adminListUrl.'&tmod=option&goods_id='.$_GET['goods_id'];
$modFromUrl = $adminFromUrl.'&tmod=option&goods_id='.$_GET['goods_id'];
    
$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['goods_id']);

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $data = __get_post_data();
        
        if($goodsInfo['open_shop_yongjin'] == 1){
            
            $shop_yongjin = 0;
            if($data['shop_yongjin'] > 0){
                $shop_yongjin = $data['shop_yongjin'];
            }
            if($data['buy_price'] > 0 && $shop_yongjin > $data['buy_price']){
                cpmsg($Lang['goods_shop_yongjin_error_301'], $modListUrl, 'error');exit;
            }
            if($data['buy_price'] > 0 && $goodsInfo['open_vip'] == 1 && $shop_yongjin > $data['vip_price']){
                cpmsg($Lang['goods_shop_yongjin_error_304'], $modListUrl, 'error');exit;
            }
            if($data['buy_price'] > 0 && $goodsInfo['open_before'] == 1 && $shop_yongjin > $data['before_price']){
                cpmsg($Lang['goods_shop_yongjin_error_303'], $modListUrl, 'error');exit;
            }
            if($goodsInfo['open_ding_pay'] == 1 && $shop_yongjin > $goodsInfo['ding_price']){
                cpmsg($Lang['goods_shop_yongjin_error_302'], $modListUrl, 'error');exit;
            }
        }
        
        $insertData = array();
        $insertData = $data;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->insert($insertData);
        $option_id = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->insert_id();
        
        updateStocklog($option_id);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); //dism��taobao��com
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }
    
}else if($_GET['act'] == 'edit'){
    $optionInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $data = __get_post_data($optionInfo);
        
        if($goodsInfo['open_shop_yongjin'] == 1){
            
            $shop_yongjin = 0;
            if($data['shop_yongjin'] > 0){
                $shop_yongjin = $data['shop_yongjin'];
            }
            if($data['buy_price'] > 0 && $shop_yongjin > $data['buy_price']){
                cpmsg($Lang['goods_shop_yongjin_error_301'], $modListUrl."&act=edit&id={$_GET['id']}".'&formhash='.FORMHASH, 'error');exit;
            }
            if($data['buy_price'] > 0 && $goodsInfo['open_before'] == 1 && $shop_yongjin > $data['before_price']){
                cpmsg($Lang['goods_shop_yongjin_error_303'], $modListUrl."&act=edit&id={$_GET['id']}".'&formhash='.FORMHASH, 'error');exit;
            }
            if($data['buy_price'] > 0 && $goodsInfo['open_vip'] == 1 && $shop_yongjin > $data['vip_price']){
                cpmsg($Lang['goods_shop_yongjin_error_304'], $modListUrl."&act=edit&id={$_GET['id']}".'&formhash='.FORMHASH, 'error');exit;
            }
            if($goodsInfo['open_ding_pay'] == 1 && $shop_yongjin > $goodsInfo['ding_price']){
                cpmsg($Lang['goods_shop_yongjin_error_302'], $modListUrl."&act=edit&id={$_GET['id']}".'&formhash='.FORMHASH, 'error');exit;
            }
        }
        
        $updateData = array();
        $updateData = $data;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->update($optionInfo['id'],$updateData);
        updateStocklog($optionInfo['id']);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); //dism��taobao��com
        __create_info_html($optionInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $optionInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($_GET['id']);
    
    C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->delete_by_id($_GET['id']);
    
    $optionListTmp = C::t("#tom_tcqianggou#tom_tcqianggou_goods_option")->fetch_all_list(" AND goods_id = {$optionInfo['goods_id']} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_market_price = $show_buy_price = $show_vip_price = $show_before_price = $stock_num = 0;
        foreach($optionListTmp as $key => $value){
            $stock_num = $stock_num + $value['stock_num'];
            if($show_buy_price == 0){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
                $show_vip_price     = $value['vip_price'];
                $show_before_price  = $value['before_price'];
            }else if($value['buy_price'] < $show_buy_price){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
                $show_vip_price     = $value['vip_price'];
                $show_before_price  = $value['before_price'];
            }
        }
        if($show_buy_price > 0){
            $updateData = array();
            $updateData['show_market_price']    = $show_market_price;
            $updateData['show_buy_price']       = $show_buy_price;
            $updateData['show_vip_price']       = $show_vip_price;
            $updateData['show_before_price']    = $show_before_price;
            $updateData['stock_num']            = $stock_num;
            $updateData['part1']                = TIMESTAMP;
            C::t("#tom_tcqianggou#tom_tcqianggou_goods")->update($optionInfo['goods_id'],$updateData);
        }
        $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($optionInfo['goods_id']);
        update_qiang_status($goodsInfoTmp);
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['act'] == 'stock_log'){

    showtableheader(); //dism��taobao��com
    echo '<tr><th colspan="15" class="partition">' . $goodsInfo['title'] .'&nbsp;&nbsp;&gt;&nbsp;&nbsp;'.$Lang['option_stock_log']. '</th></tr>';
    showtablefooter(); //Dism��taobao��com
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $stockLogList = C::t('#tom_tcqianggou#tom_tcqianggou_stock_log')->fetch_all_list(" AND goods_id = {$goodsInfo['id']} AND is_option = 1 "," ORDER BY change_time DESC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader(); //dism��taobao��com
    echo '<tr class="header">';
    echo '<th>' . $Lang['stocklog_is_admin'] . '</th>';
    echo '<th>' . $Lang['stocklog_is_option'] . '</th>';
    echo '<th>' . $Lang['stocklog_change_num'] . '</th>';
    echo '<th>' . $Lang['stocklog_beizu'] . '</th>';
    echo '<th>' . $Lang['stocklog_change_time'] . '</th>';
    echo '</tr>';

    $i = 1;
    foreach ($stockLogList as $key => $value){
        echo '<tr>';
        if($value['is_admin'] == 1){
            echo '<td>' . $Lang['stocklog_is_admin_1'] . '</td>';
        }else{
            echo '<td>' . $Lang['stocklog_is_admin_0'] . '</td>';
        }
        if($value['is_option'] == 1){
            echo '<td>' . $Lang['stocklog_is_option_1'] . '</td>';
        }else{
            echo '<td>' . $Lang['stocklog_is_option_0'] . '</td>';
        }
        echo '<td>' . $value['change_num'] . '</td>';
        echo '<th>' . $value['beizu'] . '</th>';
        echo '<td>' . dgmdate($value['change_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); //Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    showtableheader(); //dism��taobao��com
    echo '<tr><th colspan="15" class="partition">' . $goodsInfo['title'] .'&nbsp;&nbsp;&gt;&nbsp;&nbsp;'.$Lang['option_list_title']. '</th></tr>';
    showtablefooter(); //Dism��taobao��com
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $optionList = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_all_list(" AND goods_id = {$goodsInfo['id']} "," ORDER BY osort ASC,id ASC ",$start,$pagesize);
    __create_nav_html();
    showtableheader(); //dism��taobao��com
    echo '<tr class="header">';
    echo '<th>' . $Lang['option_name'] . '</th>';
    echo '<th>' . $Lang['option_market_price'] . '</th>';
    echo '<th>' . $Lang['option_buy_price'] . '</th>';
    echo '<th>' . $Lang['option_before_price'] . '</th>';
    echo '<th>' . $Lang['option_vip_price'] . '</th>';
    echo '<th>' . $Lang['option_shop_yongjin'] . '</th>';
    echo '<th>' . $Lang['option_stock_num'] . '</th>';
    echo '<th>' . $Lang['goods_sale_num'] . '</th>';
    echo '<th>' . $Lang['paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($optionList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['market_price'] . '</td>';
        echo '<td>' . $value['buy_price'] . '</td>';
        echo '<td>' . $value['before_price'] . '</td>';
        echo '<td>' . $value['vip_price'] . '</td>';
        echo '<td>' . $value['shop_yongjin'] . '</td>';
        echo '<td><font color="#fd0d0d">' . $value['stock_num'] . '</font></td>';
        echo '<td><font color="#238206">' . $value['sale_num'] . '</font></td>';
        echo '<td>' . $value['osort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['option_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); //Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $goods_id           = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $market_price       = isset($_GET['market_price'])? floatval($_GET['market_price']):0.00;
    $buy_price          = isset($_GET['buy_price'])? floatval($_GET['buy_price']):0.00;
    $before_price       = isset($_GET['before_price'])? floatval($_GET['before_price']):0.00;
    $vip_price          = isset($_GET['vip_price'])? floatval($_GET['vip_price']):0.00;
    $stock_num          = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
    $shop_yongjin       = isset($_GET['shop_yongjin'])? floatval($_GET['shop_yongjin']):0;
    $osort              = isset($_GET['osort'])? intval($_GET['osort']):10;

    if($_GET['act'] == 'edit'){
        if($infoArr['sale_num'] > $stock_num){
            $stock_num = $infoArr['sale_num'];
        }
    }
    
    $data['goods_id']       = $goods_id;
    $data['name']           = $name;
    $data['market_price']   = $market_price;
    $data['buy_price']      = $buy_price;
    $data['before_price']   = $before_price;
    $data['vip_price']      = $vip_price;
    $data['stock_num']      = $stock_num;
    $data['shop_yongjin']   = $shop_yongjin;
    $data['osort']          = $osort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'              => '',
        'market_price'      => '',
        'buy_price'         => '',
        'before_price'      => '',
        'vip_price'         => '',
        'stock_num'         => '',
        'shop_yongjin'      => 0,
        'osort'             => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['option_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['option_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_market_price'],'name'=>'market_price','value'=>$options['market_price'],'msg'=>$Lang['option_market_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_buy_price'],'name'=>'buy_price','value'=>$options['buy_price'],'msg'=>$Lang['option_buy_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_before_price'],'name'=>'before_price','value'=>$options['before_price'],'msg'=>$Lang['option_before_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_vip_price'],'name'=>'vip_price','value'=>$options['vip_price'],'msg'=>$Lang['option_vip_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_stock_num'],'name'=>'stock_num','value'=>$options['stock_num'],'msg'=>$Lang['option_stock_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_shop_yongjin'],'name'=>'shop_yongjin','value'=>$options['shop_yongjin'],'msg'=>$Lang['option_shop_yongjin_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['paixu'],'name'=>'osort','value'=>$options['osort'],'msg'=>$Lang['option_osort_msg']),"input");
    
    return;
}

function updateStocklog($option_id){
    global $Lang;
    $optionInfo = C::t("#tom_tcqianggou#tom_tcqianggou_goods_option")->fetch_by_id($option_id);
    
    $beizu = 'ID:&nbsp;<font color="#0a9409">'.$option_id.'</font> '.$Lang['option_name'].' <font color="#0a9409">'.$optionInfo['name'].'</font>: '.$Lang['option_stock_num'].'<font color="#fd0d0d">'.$optionInfo['stock_num'].'</font> '.$Lang['option_market_price'].'<font color="#fd0d0d">'.$optionInfo['market_price'].'</font> '.$Lang['option_buy_price'].'<font color="#fd0d0d">'.$optionInfo['buy_price'].'</font> '.$Lang['option_before_price'].'<font color="#fd0d0d">'.$optionInfo['before_price'].'</font> '.$Lang['option_vip_price'].'<font color="#fd0d0d">'.$optionInfo['vip_price'].'</font><br/>';
    
    $insertData = array();
    $insertData['is_admin']     = 1;
    $insertData['is_option']    = 1;
    $insertData['goods_id']     = $optionInfo['goods_id'];
    $insertData['beizu']        = $beizu;
    $insertData['change_num']   = $optionInfo['stock_num'];
    $insertData['change_time']  = TIMESTAMP;
    C::t("#tom_tcqianggou#tom_tcqianggou_stock_log")->insert($insertData);
    
    $optionListTmp = C::t("#tom_tcqianggou#tom_tcqianggou_goods_option")->fetch_all_list(" AND goods_id = {$optionInfo['goods_id']} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_market_price = $show_buy_price = $show_vip_price = $show_before_price = $stock_num = 0;
        foreach($optionListTmp as $key => $value){
            $stock_num = $stock_num + $value['stock_num'];
            if($show_buy_price == 0){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
                $show_vip_price     = $value['vip_price'];
                $show_before_price  = $value['before_price'];
            }else if($value['buy_price'] < $show_buy_price){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
                $show_vip_price     = $value['vip_price'];
                $show_before_price  = $value['before_price'];
            }
        }
        if($show_buy_price >= 0){
            $updateData = array();
            $updateData['show_market_price']    = $show_market_price;
            $updateData['show_buy_price']       = $show_buy_price;
            $updateData['show_vip_price']       = $show_vip_price;
            $updateData['show_before_price']    = $show_before_price;
            $updateData['stock_num']            = $stock_num;
            $updateData['part1']                = TIMESTAMP;
            C::t("#tom_tcqianggou#tom_tcqianggou_goods")->update($optionInfo['goods_id'],$updateData);
        }
        $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($optionInfo['goods_id']);
        update_qiang_status($goodsInfoTmp);
    }
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['option_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['option_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['option_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['option_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['option_edit'],"",true);
    }else if($_GET['act'] == 'stock_log'){
        tomshownavli($Lang['option_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['option_stock_log'],$modBaseUrl."&act=stock_log",true);
    }else{
        tomshownavli($Lang['option_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['option_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['option_stock_log'],$modBaseUrl."&act=stock_log",false);
    }
    tomshownavfooter();
}