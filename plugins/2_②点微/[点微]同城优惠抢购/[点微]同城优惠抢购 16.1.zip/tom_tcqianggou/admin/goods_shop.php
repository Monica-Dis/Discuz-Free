<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=goods_shop&goods_id='.$_GET['goods_id'];
$modListUrl = $adminListUrl.'&tmod=goods_shop&goods_id='.$_GET['goods_id'];
$modFromUrl = $adminFromUrl.'&tmod=goods_shop&goods_id='.$_GET['goods_id'];

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $data = __get_post_data();
        
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($data['tcshop_id']);
        
        if($tcshopInfo && $tcshopInfo['status'] == 1){
        }else{
            cpmsg($Lang['goods_add_error_500'], $modListUrl.'&act=add', 'error');
        }
        
        $insertData = array();
        $insertData = $data;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->insert($insertData);
        $goods_shop_id = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->insert_id();
        
        updateStocklog($goods_shop_id);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); //dism��taobao��com
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }
    
}else if($_GET['act'] == 'edit'){
    $goodsShopInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($goodsShopInfo);
        C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->update($goodsShopInfo['id'],$updateData);
        updateStocklog($goodsShopInfo['id']);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); //dism��taobao��com
        __create_info_html($goodsShopInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }
    
}else if($_GET['act'] == 'editgoods'){
    
    if(submitcheck('submit')){
        
        $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['goods_id']);
        
        $goods_id                   = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
        $duo_hexiao_num             = isset($_GET['duo_hexiao_num'])? intval($_GET['duo_hexiao_num']):0;
        $duo_shop_jiesuan           = isset($_GET['duo_shop_jiesuan'])? intval($_GET['duo_shop_jiesuan']):1;
        
        $updateData = array();
        $updateData['duo_hexiao_num']               = $duo_hexiao_num;
        $updateData['duo_shop_jiesuan']             = $duo_shop_jiesuan;
        C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($goods_id, $updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $goodsShopInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->fetch_by_id($_GET['id']);
    
    C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->delete_by_id($_GET['id']);
    
    $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goodsShopInfo['goods_id']);
    
    update_qiang_status($goodsInfoTmp);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['act'] == 'stock_log'){
    
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['goods_id']);

    showtableheader(); //dism��taobao��com
    echo '<tr><th colspan="15" class="partition">' . $goodsInfo['title'] .'&nbsp;&nbsp;&gt;&nbsp;&nbsp;'.$Lang['option_stock_log']. '</th></tr>';
    showtablefooter(); //Dism��taobao��com
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $stockLogList = C::t('#tom_tcqianggou#tom_tcqianggou_stock_log')->fetch_all_list(" AND goods_id = {$goodsInfo['id']} AND is_option = 1 "," ORDER BY change_time DESC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader(); //dism��taobao��com
    echo '<tr class="header">';
    echo '<th>' . $Lang['stocklog_is_admin'] . '</th>';
    echo '<th>' . $Lang['stocklog_change_num'] . '</th>';
    echo '<th>' . $Lang['stocklog_beizu'] . '</th>';
    echo '<th>' . $Lang['stocklog_change_time'] . '</th>';
    echo '</tr>';

    $i = 1;
    foreach ($stockLogList as $key => $value){
        echo '<tr>';
        if($value['is_admin'] == 1){
            echo '<td>' . $Lang['stocklog_is_admin_1'] . '</td>';
        }else{
            echo '<td>' . $Lang['stocklog_is_admin_0'] . '</td>';
        }
        echo '<td>' . $value['change_num'] . '</td>';
        echo '<th>' . $value['beizu'] . '</th>';
        echo '<td>' . dgmdate($value['change_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); //Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);

}else if($_GET['act'] == 'use_log'){
    
    $goodsShopInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->fetch_by_id($_GET['goods_shop_id']);

    showtableheader(); //dism��taobao��com
    echo '<tr><th colspan="15" class="partition">' . $goodsShopInfo['title'] .'&nbsp;&nbsp;&gt;&nbsp;&nbsp;'.$Lang['goods_shop_use_log']. '</th></tr>';
    showtablefooter(); //Dism��taobao��com
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $useLogList = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_all_list(" AND goods_shop_id = {$_GET['goods_shop_id']}  "," ORDER BY id DESC ",$start,$pagesize);
    showtableheader(); //dism��taobao��com
    echo '<tr class="header">';
    echo '<th>' . $Lang['use_log_order_no'] . '</th>';
    echo '<th>' . $Lang['use_log_user_id'] . '</th>';
    echo '<th>' . $Lang['use_log_use_num'] . '</th>';
    echo '<th>' . $Lang['use_log_hexiao_user_id'] . '</th>';
    echo '<th>' . $Lang['use_log_hexiao_time'] . '</th>';
    echo '</tr>';

    $i = 1;
    foreach ($useLogList as $key => $value){
        
        $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
        $hexiaoUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['hexiao_user_id']);
        $orderInfo = C::t("#tom_tcqianggou#tom_tcqianggou_order")->fetch_by_id($value['order_id']);
        
        echo '<tr>';
        echo '<td>' . $orderInfo['order_no'] .'</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color="#f00">(ID:'.$value['user_id'].')</font></td>';
        echo '<td>' . $value['use_num'] .'</td>';
        echo '<td>' . $hexiaoUserInfo['nickname'] .'<font color="#f00">(ID:'.$value['hexiao_user_id'].')</font></td>';
        echo '<td>' . dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset) . '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); //Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}else{
    
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($_GET['goods_id']);

    showtableheader(); //dism��taobao��com
    echo '<tr><th colspan="15" class="partition">' . $goodsInfo['title'] .'&nbsp;&nbsp;&gt;&nbsp;&nbsp;'.$Lang['goods_open_duo_shop_title']. '</th></tr>';
    showtablefooter(); //Dism��taobao��com
    
    tomloadcalendarjs();
    showformheader($modFromUrl.'&act=editgoods&formhash='.FORMHASH);
    showtableheader(); //dism��taobao��com
    tomshowsetting(true,array('title'=>$Lang['goods_duo_hexiao_num'],'name'=>'duo_hexiao_num','value'=>$goodsInfo['duo_hexiao_num'],'msg'=>$Lang['goods_duo_hexiao_num_msg']),"input");
    $duo_shop_jiesuan_item = array(1=>$Lang['goods_duo_shop_jiesuan_1'],2=>$Lang['goods_duo_shop_jiesuan_2'],3=>$Lang['goods_duo_shop_jiesuan_3']);
    tomshowsetting(true,array('title'=>$Lang['goods_duo_shop_jiesuan'],'name'=>'duo_shop_jiesuan','value'=>$goodsInfo['duo_shop_jiesuan'],'msg'=>$Lang['goods_duo_shop_jiesuan_msg'],'item'=>$duo_shop_jiesuan_item),"radio");
    showsubmit('submit', 'submit');
    showtablefooter(); //Dism��taobao��com
    showformfooter(); //Dism_taobao_com
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $goodsShopList = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->fetch_all_list(" AND goods_id = {$goodsInfo['id']} "," ORDER BY ssort ASC,id ASC ",$start,$pagesize);
    __create_nav_html();
    showtableheader(); //dism��taobao��com
    echo '<tr class="header">';
    echo '<th>ID</th>';
    echo '<th>' . $Lang['goods_shop_title'] . '</th>';
    echo '<th>' . $Lang['goods_shop_tcshop_id'] . '</th>';
    echo '<th>' . $Lang['goods_shop_picurl'] . '</th>';
    echo '<th>' . $Lang['goods_shop_price'] . '</th>';
    echo '<th>' . $Lang['goods_shop_stock_num'] . '</th>';
    echo '<th>' . $Lang['goods_shop_sale_num'] . '</th>';
    echo '<th>' . $Lang['goods_shop_xian_use_num'] . '</th>';
    echo '<th>' . $Lang['goods_shop_one_jiesuan_price'] . '</th>';
    echo '<th>' . $Lang['paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($goodsShopList as $key => $value) {
        
        $tcshopInfo = C::t("#tom_tcshop#tom_tcshop")->fetch_by_id($value['tcshop_id']);
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $value['title'] . '</td>';
        echo '<td>' . $tcshopInfo['name'] .'<font color="#f00">(ID:'.$value['tcshop_id']. ')</font></td>';
        echo '<td><a href="' . tomgetfileurl($value['picurl']) . '" target="_blank"><img width="40" src="' . tomgetfileurl($value['picurl']) . '"></a></td>';
        echo '<td>' . $value['market_price'] . '</td>';
        echo '<td><font color="#fd0d0d">' . $value['stock_num'] . '</font></td>';
        echo '<td><font color="#238206">' . $value['sale_num'] . '</font></td>';
        echo '<td>' . $value['xian_use_num'] . '</td>';
        echo '<td>' . $value['one_jiesuan_price'] . '</td>';
        echo '<td>' . $value['ssort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=use_log&goods_shop_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_shop_use_log']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); //Dism��taobao��com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $goods_id           = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $market_price       = isset($_GET['market_price'])? floatval($_GET['market_price']):0.00;
    $stock_num          = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
    $xian_use_num       = isset($_GET['xian_use_num'])? intval($_GET['xian_use_num']):0;
    $one_jiesuan_price  = isset($_GET['one_jiesuan_price'])? floatval($_GET['one_jiesuan_price']):0;
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $ssort              = isset($_GET['ssort'])? intval($_GET['ssort']):10;
    
    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    if($_GET['act'] == 'edit'){
        if($infoArr['sale_num'] > $stock_num){
            $stock_num = $infoArr['sale_num'];
        }
    }
    
    $data['goods_id']           = $goods_id;
    $data['title']              = $title;
    $data['tcshop_id']          = $tcshop_id;
    $data['market_price']       = $market_price;
    $data['stock_num']          = $stock_num;
    $data['xian_use_num']       = $xian_use_num;
    $data['one_jiesuan_price']  = $one_jiesuan_price;
    $data['picurl']             = $picurl;
    $data['hexiao_pwd']         = $hexiao_pwd;
    $data['content']            = $content;
    $data['ssort']              = $ssort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'title'             => '',
        'tcshop_id'         => 0,
        'picurl'            => '',
        'market_price'      => 0.00,
        'stock_num'         => 0,
        'xian_use_num'      => 1,
        'one_jiesuan_price' => 0.00,
        'hexiao_pwd'        => '',
        'content'           => '',
        'ssort'             => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['goods_shop_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['goods_shop_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_shop_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['goods_shop_tcshop_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_shop_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['goods_shop_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['goods_shop_price'],'name'=>'market_price','value'=>$options['market_price'],'msg'=>$Lang['goods_shop_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_shop_stock_num'],'name'=>'stock_num','value'=>$options['stock_num'],'msg'=>$Lang['goods_shop_stock_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_shop_xian_use_num'],'name'=>'xian_use_num','value'=>$options['xian_use_num'],'msg'=>$Lang['goods_shop_xian_use_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_shop_one_jiesuan_price'],'name'=>'one_jiesuan_price','value'=>$options['one_jiesuan_price'],'msg'=>$Lang['goods_shop_one_jiesuan_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_hexiao_pwd'],'name'=>'hexiao_pwd','value'=>$options['hexiao_pwd'],'msg'=>$Lang['goods_hexiao_pwd_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_shop_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['goods_shop_content_msg']),"text");
    tomshowsetting(true,array('title'=>$Lang['paixu'],'name'=>'ssort','value'=>$options['ssort'],'msg'=>$Lang['option_osort_msg']),"input");
    
    return;
}

function updateStocklog($goods_shop_id){
    global $Lang;
    $goodsShopInfo = C::t("#tom_tcqianggou#tom_tcqianggou_goods_shop")->fetch_by_id($goods_shop_id);
    
    $beizu = 'ID&nbsp;<font color="#0a9409">'.$goods_shop_id.'</font> '.$Lang['goods_shop_title'].' <font color="#0a9409">'.$goodsShopInfo['title'].'</font> '.$Lang['goods_shop_tcshop_id'].' <font color="#fd0d0d">'.$goodsShopInfo['tcshop_id'].'</font> '.$Lang['goods_shop_stock_num'].' <font color="#fd0d0d">'.$goodsShopInfo['stock_num'].' </font> '.$Lang['goods_shop_xian_use_num'].' <font color="#fd0d0d">'.$goodsShopInfo['xian_use_num'].'</font> '.$Lang['goods_shop_one_jiesuan_price'].' <font color="#fd0d0d">'.$goodsShopInfo['one_jiesuan_price'].'</font>';
    
    $insertData = array();
    $insertData['is_admin']     = 1;
    $insertData['is_option']    = 1;
    $insertData['goods_id']     = $goodsShopInfo['goods_id'];
    $insertData['beizu']        = $beizu;
    $insertData['change_num']   = $goodsShopInfo['stock_num'];
    $insertData['change_time']  = TIMESTAMP;
    C::t("#tom_tcqianggou#tom_tcqianggou_stock_log")->insert($insertData);
    
    $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goodsShopInfo['goods_id']);
    
    update_qiang_status($goodsInfoTmp);
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['goods_shop_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_shop_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['goods_shop_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_shop_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['option_edit'],"",true);
    }else if($_GET['act'] == 'stock_log'){
        tomshownavli($Lang['goods_shop_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_shop_stock_log'],$modBaseUrl."&act=stock_log",true);
    }else{
        tomshownavli($Lang['goods_shop_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['goods_shop_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['goods_shop_stock_log'],$modBaseUrl."&act=stock_log",false);
    }
    tomshownavfooter();
}