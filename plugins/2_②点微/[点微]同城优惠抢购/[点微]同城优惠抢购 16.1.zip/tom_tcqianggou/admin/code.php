<?php

/*
   This is NOT a freeware, use is subject to license terms
   ��Ȩ���У�TOM΢�� www.tomwx.net
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=code&goods_id='.$_GET['goods_id'];
$modListUrl = $adminListUrl.'&tmod=code&goods_id='.$_GET['goods_id'];
$modFromUrl = $adminFromUrl.'&tmod=code&goods_id='.$_GET['goods_id'];

$goods_id   = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;

$goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
update_qiang_status($goodsInfoTmp);

if($_GET['act'] == 'add'){
    
    if(submitcheck('submit')){
        
        $option_id          = isset($_GET['option_id'])? intval($_GET['option_id']):0;
        $code_value         = isset($_GET['code_value'])? addslashes($_GET['code_value']):'';
        
        $codeListStr = str_replace("\r\n","{n}",trim($code_value));
        $codeListStr = str_replace("\n","{n}",$codeListStr);
        $codeListArr = explode("{n}", $codeListStr);
        
        foreach($codeListArr as $key => $value){
            $value = trim($value);
            $codeInfo = C::t('#tom_tcqianggou#tom_tcqianggou_code')->fetch_by_code_value($value);
            if($codeInfo){
            }else{
                $insertData = array();
                $insertData['goods_id']         = $goods_id;
                if($goodsInfoTmp['hasoption'] == 1){
                    $insertData['option_id']        = $option_id;
                }
                $insertData['code_value']       = $value;
                $insertData['code_status']      = 0;
                $insertData['add_time']         = TIMESTAMP;
                C::t('#tom_tcqianggou#tom_tcqianggou_code')->insert($insertData);
            }
        }

        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); //dism��taobao��com
        if($goodsInfoTmp['hasoption'] == 1){
            $optionList = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_all_list(" AND goods_id = {$goodsInfoTmp['id']} "," ORDER BY osort ASC,id ASC ",0,100);
            $optionStr = '<tr class="header"><th>'.$Lang['code_option'].'</th><th></th></tr>';
            $optionStr.= '<tr><td width="300"><select style="width: 260px;" name="option_id" id="option_id">';
            foreach ($optionList as $key => $value){
                $optionStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
            $optionStr.= '</select></td><td></td></tr>';
            echo $optionStr;
        }
        
        echo '<tr class="header"><th>'.$Lang['code_code_value'].'</th><th></th></tr>';
        echo '<tr><td width="300"><textarea rows="30" name="code_value" cols="50" ></textarea></td><td>'.$Lang['code_code_value_msg'].'</td></tr>';
        showsubmit('submit', 'submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $codeInfo = C::t('#tom_tcqianggou#tom_tcqianggou_code')->fetch_by_id($_GET['id']);
    if($codeInfo['code_status'] == 1 || $codeInfo['code_status'] == 2 || $codeInfo['code_status'] == 3){
        cpmsg($Lang['code_del_error'], $modListUrl, 'error');exit;
    }
    
    C::t('#tom_tcqianggou#tom_tcqianggou_code')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_del'){
    
    $delIdsArr = array();
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach($_GET['ids'] as $key => $value){
            $id = intval($value);
            if($id > 0){
                $delIdsArr[] = $id;
            }
        }
    }
    if(!empty($delIdsArr)){
        $delIdsStr = implode(',', $delIdsArr);
        C::t("#tom_tcqianggou#tom_tcqianggou_code")->delete_all(" AND id IN({$delIdsStr}) AND code_status = 0 ");
    }
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{

    showtableheader(); //dism��taobao��com
    echo '<tr><th colspan="15" class="partition">' . $Lang['code_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><font color="#F60">'.$Lang['code_help_title_1'].'</font></li>';
    echo '</ul></td></tr>';
    showtablefooter(); //Dism��taobao��com
    
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    $order_no           = isset($_GET['order_no'])? addslashes($_GET['order_no']):'';
    $code_value         = isset($_GET['code_value'])? addslashes($_GET['code_value']):'';
    $code_status        = isset($_GET['code_status'])? intval($_GET['code_status']):0;
    $option_id          = isset($_GET['option_id'])? intval($_GET['option_id']):0;
    
    $where = " AND goods_id={$goods_id} ";
    if(!empty($order_no)){
        $where.= " AND order_no='{$order_no}' ";
    }
    if(!empty($code_value)){
        $where.= " AND code_value='{$code_value}' ";
    }
    if(!empty($code_status)){
        $where.= " AND code_status={$code_status} ";
    }
    if($option_id > 0){
        $where.= " AND option_id={$option_id} ";
    }
    
    $pagesize = 20;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcqianggou#tom_tcqianggou_code')->fetch_all_count(" {$where} ");
    $codeList = C::t('#tom_tcqianggou#tom_tcqianggou_code')->fetch_all_list(" {$where} "," ORDER BY id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&code_value={$code_value}&code_status={$code_status}&option_id={$option_id}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); //dism��taobao��com
    echo '<tr><th colspan="15" class="partition">' . $Lang['code_help_search'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['code_order_no'] . '</b></td><td><input name="order_no" type="text" value="'.$order_no.'" style="width: 260px;" /></td></tr>';
    echo '<tr><td width="100" align="right"><b>' . $Lang['code_code_value'] . '</b></td><td><input name="code_value" type="text" value="'.$code_value.'" style="width: 260px;" /></td></tr>';
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['code_code_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="code_status" id="code_status">';
    $statusStr.=  '<option value="0">'.$Lang['code_code_status'].'</option>';
    $statusStr.=  '<option value="1">'.$Lang['code_code_status_1'].'</option>';
    $statusStr.=  '<option value="2">'.$Lang['code_code_status_2'].'</option>';
    $statusStr.=  '<option value="3">'.$Lang['code_code_status_3'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    if($goodsInfoTmp['hasoption'] == 1){
        $optionList = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_all_list(" AND goods_id = {$goodsInfoTmp['id']} "," ORDER BY osort ASC,id ASC ",0,100);
        $optionStr = '<tr><td width="100" align="right"><b>'.$Lang['code_option'].'</b></td>';
        $optionStr.= '<td><select style="width: 260px;" name="option_id" id="option_id">';
        $optionStr.=  '<option value="0">'.$Lang['code_option'].'</option>';
        foreach ($optionList as $key => $value){
            $optionStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
        $optionStr.= '</select></td></tr>';
        echo $optionStr;
    }
    
    showsubmit('submit', 'submit');
    showtablefooter(); //Dism��taobao��com
    showformfooter(); //Dism_taobao_com

    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return order_form();">'.
		'<input type="hidden" name="formhash" value="'.FORMHASH.'" />'.
    __create_nav_html();
    showtableheader(); //dism��taobao��com
    echo '<tr class="header">';
    echo '<th> ID </th>';
    if($goodsInfoTmp['hasoption'] == 1){
        echo '<th>' . $Lang['code_option'] . '</th>';
    }
    echo '<th>' . $Lang['code_order_no'] . '</th>';
    echo '<th>' . $Lang['code_code_value'] . '</th>';
    echo '<th>' . $Lang['code_user_id'] . '</th>';
    echo '<th>' . $Lang['code_code_status'] . '</th>';
    echo '<th>' . $Lang['code_use_time'] . '</th>';
    echo '<th>' . $Lang['code_add_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($codeList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $orderInfo = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_by_id($value['order_id']);
        
        echo '<tr>';
        if($value['code_status'] > 0){
            echo '<td>' . $value['id'] . '</td>';
        }else{
            echo '<td><label><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" >' . $value['id'] . '</label></td>';
        }
        if($goodsInfoTmp['hasoption'] == 1){
            $optionInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($value['option_id']);
            if($value['option_id'] > 0){
                echo '<td>' . $optionInfo['name'] . '</td>';
            }else{
                echo '<td>-</td>';
            }
        }
        
        if(!empty($value['order_no'])){
            echo '<td>' . $value['order_no'] . '</td>';
        }else{
            echo '<td>-</td>';
        }
        echo '<td>' . $value['code_value'] . '</td>';
        if($userInfo){
            echo '<td>' . $userInfo['nickname'] .'<font color="#0a9409">(UID:'.$userInfo['id']. ')</font></td>';
        }else{
            echo '<td> -- </td>';
        }
        if($value['code_status'] == 1){
            echo '<td><font color="#fd0d0d">' . $Lang['code_code_status_1'] . '</font></td>';
        }else if($value['code_status'] == 2){
            echo '<td><font color="#0894fb">' . $Lang['code_code_status_2'] . '</font></td>';
        }else if($value['code_status'] == 3){
            echo '<td><font color="#238206">' . $Lang['code_code_status_3'] . '</font></td>';
        }else{
            echo '<td><font color="#8e8e8e">' . $Lang['code_code_status_0'] . '</font></td>';
        }
        if($value['use_time'] > 0){
            echo '<td>' . dgmdate($value['use_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        }else{
            echo '<td>-</td>';
        }
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    
    $formstr = <<<EOF
        <tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="batch_del">{$Lang['del']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>
        <script type="text/javascript">
        function order_form(){
          var r = confirm("{$Lang['batch_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        function del_confirm(url){
        var r = confirm("{$Lang['makesure_del_msg']}")
          if (r == true){
            window.location = url;
          }else{
            return false;
          }
        }
        </script>
EOF;
    
    echo $formstr;
    showtablefooter(); //Dism��taobao��com
    showformfooter(); //Dism_taobao_com
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['code_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['code_add'],"",true);
    }else{
        tomshownavli($Lang['code_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['code_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}