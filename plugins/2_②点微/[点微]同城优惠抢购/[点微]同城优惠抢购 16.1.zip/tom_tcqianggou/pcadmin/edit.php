<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
if(empty($goodsInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($__UserInfo['id'] != $goodsInfo['user_id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=edit&goods_id={$goods_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $open_duo_shop      = isset($_GET['open_duo_shop'])? intval($_GET['open_duo_shop']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $trade_id           = isset($_GET['trade_id'])? intval($_GET['trade_id']):0;
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $recom_cate_id      = isset($_GET['recom_cate_id'])? intval($_GET['recom_cate_id']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $tcchoujiang_id     = isset($_GET['tcchoujiang_id'])? intval($_GET['tcchoujiang_id']):0;
    $xiangou_num        = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $min_num            = isset($_GET['min_num'])? intval($_GET['min_num']):0;
    $market_price       = isset($_GET['market_price'])? floatval($_GET['market_price']):'';
    $buy_price          = isset($_GET['buy_price'])? floatval($_GET['buy_price']):'';
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? floatval($_GET['ding_price']):'';
    $open_before        = isset($_GET['open_before'])? intval($_GET['open_before']):0;
    $before_price       = isset($_GET['before_price'])? floatval($_GET['before_price']):'';
    $before_num         = isset($_GET['before_num'])? intval($_GET['before_num']):0;
    $open_vip           = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $vip_price          = isset($_GET['vip_price'])? floatval($_GET['vip_price']):'';
    $open_score_dikou   = isset($_GET['open_score_dikou'])? intval($_GET['open_score_dikou']):0;
    $score_num          = isset($_GET['score_num'])? intval($_GET['score_num']):0;
    $score_dikou_price  = isset($_GET['score_dikou_price'])? floatval($_GET['score_dikou_price']):0.00;
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $start_time         = strtotime($start_time);
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $end_time           = strtotime($end_time);
    $hexiao_start_time  = isset($_GET['hexiao_start_time'])? addslashes($_GET['hexiao_start_time']):'';
    $hexiao_start_time  = strtotime($hexiao_start_time);
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = strtotime($hexiao_time);
    $open_hexiao_valid  = isset($_GET['open_hexiao_valid'])? intval($_GET['open_hexiao_valid']):0;
    $hexiao_valid_days  = isset($_GET['hexiao_valid_days'])? intval($_GET['hexiao_valid_days']):0;
    $peisong_type       = isset($_GET['peisong_type'])? intval($_GET['peisong_type']):1;
    $open_yuyue         = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $yuyue_xm           = isset($_GET['yuyue_xm'])? addslashes($_GET['yuyue_xm']):'';
    $yuyue_tel          = isset($_GET['yuyue_tel'])? addslashes($_GET['yuyue_tel']):'';
    $yuyue_type         = isset($_GET['yuyue_type'])? intval($_GET['yuyue_type']):1;
    $tcyuyue_id         = isset($_GET['tcyuyue_id'])? intval($_GET['tcyuyue_id']):0;
    $open_code          = isset($_GET['open_code'])? intval($_GET['open_code']):0;
    $code_help_msg      = isset($_GET['code_help_msg'])? addslashes($_GET['code_help_msg']):'';
    $virtual_clicks     = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $paixu              = isset($_GET['paixu'])? intval($_GET['paixu']):1000;
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $xuzhi              = isset($_GET['xuzhi'])? addslashes($_GET['xuzhi']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    
    $open_xubuy         = isset($_GET['open_xubuy'])? intval($_GET['open_xubuy']):0;
    $qianggou_ids       = isset($_GET['qianggou_ids'])? addslashes($_GET['qianggou_ids']):'';
    $haibao_type        = isset($_GET['haibao_type'])? intval($_GET['haibao_type']):1;
    $haibao_msg         = isset($_GET['haibao_msg'])? addslashes($_GET['haibao_msg']):'';
    $haibao_picurl      = isset($_GET['haibao_picurl'])? addslashes($_GET['haibao_picurl']):'';
    $haibao_text_color  = isset($_GET['haibao_text_color'])? addslashes($_GET['haibao_text_color']):'';
    $qrcode_location    = isset($_GET['qrcode_location'])? intval($_GET['qrcode_location']):1;
    $zhibo_roomid       = isset($_GET['zhibo_roomid'])? intval($_GET['zhibo_roomid']):0;
    $allow_refund       = isset($_GET['allow_refund'])? intval($_GET['allow_refund']):0;
    $mp3_link           = isset($_GET['mp3_link'])? addslashes($_GET['mp3_link']):'';
    $share_title        = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc         = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    $open_shop_yongjin  = isset($_GET['open_shop_yongjin'])? intval($_GET['open_shop_yongjin']):0;
    $shop_yongjin       = isset($_GET['shop_yongjin'])? floatval($_GET['shop_yongjin']):0;
    $yongjin_type       = isset($_GET['yongjin_type'])? intval($_GET['yongjin_type']):1;
    $yongjin_bili       = isset($_GET['yongjin_bili'])? floatval($_GET['yongjin_bili']):0;
    
    $hehuoren_tg_open   = isset($_GET['hehuoren_tg_open'])? intval($_GET['hehuoren_tg_open']):2;
    $chuji_fc_scale     = isset($_GET['chuji_fc_scale'])? floatval($_GET['chuji_fc_scale']):0;
    $zhongji_fc_scale   = isset($_GET['zhongji_fc_scale'])? floatval($_GET['zhongji_fc_scale']):0;
    $gaoji_fc_scale     = isset($_GET['gaoji_fc_scale'])? floatval($_GET['gaoji_fc_scale']):0;
    $chuji_fc_scale2    = isset($_GET['chuji_fc_scale2'])? floatval($_GET['chuji_fc_scale2']):0;
    $zhongji_fc_scale2  = isset($_GET['zhongji_fc_scale2'])? floatval($_GET['zhongji_fc_scale2']):0;
    $gaoji_fc_scale2    = isset($_GET['gaoji_fc_scale2'])? floatval($_GET['gaoji_fc_scale2']):0;
    
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    $stock_num          = isset($_GET['stock_num'])? addslashes($_GET['stock_num']):0;

    if($open_code == 1){
        $peisong_type = 1;
    }
    if($open_duo_shop == 1){
        $peisong_type = 1;
        $tcshop_id = 0;
    }
    
    $photoArr = array();
    foreach($_GET['photo'] as $key => $value){
        $value = addslashes($value);
        if(!empty($value)){
            $photoArr[] = $value;
        }
    }
    
    if($stock_num < $goodsInfo['sale_num']){
        $stock_num = $goodsInfo['sale_num'];
    }
    
    if($hasoption == 1){
        $optionList = array();
        foreach($_GET as $key => $value){
            if(strpos($key, "option_id_") !== false){
                $key = intval(ltrim($key, "option_id_"));
                $optionList[$key]['id'] = intval($value);
            }
            if(strpos($key, "option_name_") !== false){
                $key = intval(ltrim($key, "option_name_"));
                $optionList[$key]['name'] = addslashes($value);
            }
            if(strpos($key, "option_market_price_") !== false){
                $key = intval(ltrim($key, "option_market_price_"));
                $optionList[$key]['market_price'] = addslashes($value);
            }
            if(strpos($key, "option_buy_price_") !== false){
                $key = intval(ltrim($key, "option_buy_price_"));
                $optionList[$key]['buy_price'] = addslashes($value);
            }
            if(strpos($key, "option_before_price_") !== false){
                $key = intval(ltrim($key, "option_before_price_"));
                $optionList[$key]['before_price'] = addslashes($value);
            }
            if(strpos($key, "option_vip_price_") !== false){
                $key = intval(ltrim($key, "option_vip_price_"));
                $optionList[$key]['vip_price'] = addslashes($value);
            }
            if(strpos($key, "option_score_num_") !== false){
                $key = intval(ltrim($key, "option_score_num_"));
                $optionList[$key]['score_num'] = addslashes($value);
            }
            if(strpos($key, "option_score_dikou_price_") !== false){
                $key = intval(ltrim($key, "option_score_dikou_price_"));
                $optionList[$key]['score_dikou_price'] = addslashes($value);
            }
            if(strpos($key, "option_stock_num_") !== false){
                $key = intval(ltrim($key, "option_stock_num_"));
                $optionList[$key]['stock_num'] = addslashes($value);
            }
            if(strpos($key, "option_shop_yongjin_") !== false){
                $key = intval(ltrim($key, "option_shop_yongjin_"));
                $optionList[$key]['shop_yongjin'] = addslashes($value);
            }
            if(strpos($key, "option_sort_") !== false){
                $key = intval(ltrim($key, "option_sort_"));
                $optionList[$key]['osort'] = addslashes($value);
            }
        }
        
        if(empty($optionList)){
            $outArr = array(
                'code'=> 200,
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
        
        foreach($optionList as $key => $value){
            if(empty($value['name'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }
            if(empty($value['market_price'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }
            if(empty($value['buy_price'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 304,
                );
                echo json_encode($outArr); exit;
            }
            if($open_vip == 1 && empty($value['vip_price'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 305,
                );
                echo json_encode($outArr); exit;
            }
            if($open_before == 1 && empty($value['before_price'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
            if(empty($value['stock_num'])){
                $outArr = array(
                    'code'=> 200,
                    'status'=> 307,
                );
                echo json_encode($outArr); exit;
            }
            
            if($__Admin['admin'] == 'admin'){
                if($open_shop_yongjin == 1 && empty($value['shop_yongjin'])){
                    $outArr = array(
                        'code'=> 200,
                        'status'=> 308,
                    );
                    echo json_encode($outArr); exit;
                }
            }
            
            if($open_score_dikou == 1){
                if(empty($value['score_num'])){
                    $outArr = array(
                        'code'=> 200,
                        'status'=> 309,
                    );
                    echo json_encode($outArr); exit;
                }

                if(empty($value['score_dikou_price'])){
                    $outArr = array(
                        'code'=> 200,
                        'status'=> 310,
                    );
                    echo json_encode($outArr); exit;
                }
            }
        }
    }
    
    if($__Admin['admin'] == 'shopadmin'){
        $tcshop_id = $goodsInfo['tcshop_id'];
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
        $open_duo_shop = 0;
        if($tcshopInfo['user_id'] != $__UserInfo['id']){
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    }
    
    $updateData = array();
    $updateData['type_id']              = 1;
    $updateData['title']                = $title;
    $updateData['open_duo_shop']        = $open_duo_shop;
    if($open_duo_shop == 1){
        $updateData['site_id']          = $site_id;
    }else{
        $updateData['site_id']          = $tcshopInfo['site_id'];
        $updateData['user_id']          = $tcshopInfo['user_id'];
        $updateData['tcshop_id']        = $tcshop_id;
        $updateData['latitude']         = $tcshopInfo['latitude'];
        $updateData['longitude']        = $tcshopInfo['longitude'];
    }
    $updateData['cate_id']              = $cate_id;
    $updateData['trade_id']             = $trade_id;
    $updateData['xiangou_num']          = $xiangou_num;
    $updateData['min_num']              = $min_num;
    $updateData['market_price']         = $market_price;
    $updateData['buy_price']            = $buy_price;
    if($tcqianggouConfig['open_ding_price'] == 1){
        $updateData['open_ding_pay']        = $open_ding_pay;
        $updateData['ding_price']           = $ding_price;
    }
    $updateData['start_time']           = $start_time;
    $updateData['end_time']             = $end_time;
    $updateData['hexiao_start_time']    = $hexiao_start_time;
    $updateData['hexiao_time']          = $hexiao_time;
    $updateData['open_hexiao_valid']    = $open_hexiao_valid;
    $updateData['hexiao_valid_days']    = $hexiao_valid_days;
    $updateData['hexiao_pwd']           = $hexiao_pwd;
    if($tcqianggouConfig['open_peisong_type'] == 1 || $__Admin['admin'] == 'admin'){
        $updateData['peisong_type']         = $peisong_type;
    }
    $updateData['open_yuyue']           = $open_yuyue;
    $updateData['yuyue_xm']             = $yuyue_xm;
    $updateData['yuyue_tel']            = $yuyue_tel;
    $updateData['yuyue_type']           = $yuyue_type;
    $updateData['tcyuyue_id']           = $tcyuyue_id;
    $updateData['admin_edit']           = $admin_edit;
    $updateData['xuzhi']                = $xuzhi;
    $updateData['content']              = $content;
    $updateData['picurl']               = $picurl;
    $updateData['toppic']               = $toppic;
    $updateData['allow_refund']         = $allow_refund;
    $updateData['mp3_link']             = $mp3_link;
    $updateData['share_title']          = $share_title;
    $updateData['share_desc']           = $share_desc;
    $updateData['open_score_dikou']     = $open_score_dikou;
    if($open_score_dikou == 1){
        $updateData['score_num']            = $score_num;
        $updateData['score_dikou_price']    = $score_dikou_price;
    }
    
    if($__Admin['admin'] == 'admin'){
        $updateData['recom_cate_id']        = $recom_cate_id;
        $updateData['tcchoujiang_id']       = $tcchoujiang_id;
        $updateData['open_before']          = $open_before;
        $updateData['before_price']         = $before_price;
        $updateData['before_num']           = $before_num;
        $updateData['open_vip']             = $open_vip;
        $updateData['vip_price']            = $vip_price;
        $updateData['open_code']            = $open_code;
        $updateData['code_help_msg']        = $code_help_msg;
        $updateData['virtual_clicks']       = $virtual_clicks;
        $updateData['paixu']                = $paixu;
        $updateData['open_xubuy']           = $open_xubuy;
        $updateData['qianggou_ids']         = $qianggou_ids;
        $updateData['haibao_type']          = $haibao_type;
        $updateData['haibao_msg']           = $haibao_msg;
        $updateData['haibao_picurl']        = $haibao_picurl;
        $updateData['haibao_text_color']    = $haibao_text_color;
        $updateData['qrcode_location']      = $qrcode_location;
        $updateData['zhibo_roomid']         = $zhibo_roomid;
        $updateData['open_shop_yongjin']    = $open_shop_yongjin;
        $updateData['shop_yongjin']         = $shop_yongjin;
        $updateData['yongjin_type']         = $yongjin_type;
        $updateData['yongjin_bili']         = $yongjin_bili;
        $updateData['hehuoren_tg_open']     = $hehuoren_tg_open;
        $updateData['chuji_fc_scale']       = $chuji_fc_scale;
        $updateData['zhongji_fc_scale']     = $zhongji_fc_scale;
        $updateData['gaoji_fc_scale']       = $gaoji_fc_scale;
        $updateData['chuji_fc_scale2']      = $chuji_fc_scale2;
        $updateData['zhongji_fc_scale2']    = $zhongji_fc_scale2;
        $updateData['gaoji_fc_scale2']      = $gaoji_fc_scale2;
    }
    
    $updateData['hasoption']            = $hasoption;
    if($hasoption == 0){
        $updateData['stock_num']                  = $stock_num;
        $updateData['show_market_price']          = $market_price;
        $updateData['show_before_price']          = $before_price;
        $updateData['show_buy_price']             = $buy_price;
        $updateData['show_vip_price']             = $vip_price;
    }
    if($__Admin['admin'] == 'shopadmin' && $tcqianggouConfig['must_shenhe'] == 1){
        $updateData['shenhe_status']        = 2;
    }
    $updateData['part1']            = TIMESTAMP;
    if(C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($goods_id, $updateData)){
        
        C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->delete_by_goods_id($goods_id);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']     = $goods_id;
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->insert($insertData);
            }
        }
        
        if($hasoption == 1){
            if(is_array($optionList) && !empty($optionList)){
                foreach ($optionList as $key => $value){
                    
                    $optionInfo = array();
                    if($value['id'] > 0){
                        $optionInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($value['id']);
                    }
                    if(!empty($optionInfo)){
                        
                        if($optionInfo['sale_num'] > $value['stock_num']){
                            $value['stock_num'] = $optionInfo['sale_num'];
                        }
                        
                        $updateData = array();
                        $updateData['name']             = $value['name'];
                        $updateData['market_price']     = $value['market_price'];
                        $updateData['buy_price']        = $value['buy_price'];
                        if($__Admin['admin'] == 'admin'){
                            $updateData['before_price']     = $value['before_price'];
                            $updateData['vip_price']        = $value['vip_price'];
                        }
                        $updateData['score_num']        = $value['score_num'];
                        $updateData['score_dikou_price']= $value['score_dikou_price'];
                        $updateData['stock_num']        = $value['stock_num'];
                        $updateData['shop_yongjin']     = $value['shop_yongjin'];
                        $updateData['osort']            = $value['osort'];
                        C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->update($optionInfo['id'], $updateData);
                        $option_id = $optionInfo['id'];
                    }else{
                        $insertData = array();
                        $insertData['goods_id']         = $goods_id;
                        $insertData['name']             = $value['name'];
                        $insertData['market_price']     = $value['market_price'];
                        $insertData['buy_price']        = $value['buy_price'];
                        if($__Admin['admin'] == 'admin'){
                            $insertData['before_price']     = $value['before_price'];
                            $insertData['vip_price']        = $value['vip_price'];
                        }
                        $insertData['score_num']        = $value['score_num'];
                        $insertData['score_dikou_price']= $value['score_dikou_price'];
                        $insertData['stock_num']        = $value['stock_num'];
                        $insertData['shop_yongjin']     = $value['shop_yongjin'];
                        $insertData['osort']            = $value['osort'];
                        $insertData['add_time']         = TIMESTAMP;
                        $option_id = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->insert($insertData, true);
                    }
                    
                    if($option_id > 0){
                        $beizu = 'ID:&nbsp;<font color="#0a9409">'.$option_id.'</font> '
                                .lang('plugin/tom_tcqianggou', 'option_name').' <font color="#0a9409">'.$value['name'].'</font>: '
                                .lang('plugin/tom_tcqianggou', 'option_stock_num').'<font color="#fd0d0d">'.$value['stock_num'].'</font> '
                                .lang('plugin/tom_tcqianggou', 'option_market_price').'<font color="#fd0d0d">'.$value['market_price'].'</font> '
                                .lang('plugin/tom_tcqianggou', 'option_buy_price').'<font color="#fd0d0d">'.$value['buy_price'].'</font>'
                                .$Lang['add_option_before_price'].'<font color="#fd0d0d">'.$value['before_price'].'</font> '
                                .$Lang['add_option_vip_price'].'<font color="#fd0d0d">'.$value['vip_price'].'</font><br/>'
                                .$Lang['add_score_num'].'<font color="#fd0d0d">'.$value['score_num'].'</font><br/>'
                                .$Lang['add_score_dikou_price'].'<font color="#fd0d0d">'.$value['score_dikou_price'].'</font><br/>';

                        $insertData = array();
                        $insertData['is_admin']     = 0;
                        $insertData['is_option']    = 1;
                        $insertData['goods_id']     = $goods_id;
                        $insertData['beizu']        = $beizu;
                        $insertData['change_num']   = $value['stock_num'];
                        $insertData['change_time']  = TIMESTAMP;
                        C::t("#tom_tcqianggou#tom_tcqianggou_stock_log")->insert($insertData);
                    }
                }
                
                $optionListTmp = C::t("#tom_tcqianggou#tom_tcqianggou_goods_option")->fetch_all_list(" AND goods_id = {$goods_id} ", 'ORDER BY id DESC', 0, 100);
                if(is_array($optionListTmp) && !empty($optionListTmp)){
                    $show_market_price = $show_buy_price = $show_vip_price = $show_before_price = $stock_num = 0;
                    foreach($optionListTmp as $key => $value){
                        $stock_num = $stock_num + $value['stock_num'];
                        if($show_buy_price == 0){
                            $show_market_price  = $value['market_price'];
                            $show_buy_price     = $value['buy_price'];
                            $show_vip_price     = $value['vip_price'];
                            $show_before_price  = $value['before_price'];
                        }else if($value['buy_price'] < $show_buy_price){
                            $show_market_price  = $value['market_price'];
                            $show_buy_price     = $value['buy_price'];
                            $show_vip_price     = $value['vip_price'];
                            $show_before_price  = $value['before_price'];
                        }
                    }
                    if($show_buy_price > 0){
                        $updateData = array();
                        $updateData['show_market_price']    = $show_market_price;
                        $updateData['show_buy_price']       = $show_buy_price;
                        $updateData['show_vip_price']       = $show_vip_price;
                        $updateData['show_before_price']    = $show_before_price;
                        $updateData['stock_num']            = $stock_num;
                        $updateData['part1']                = TIMESTAMP;
                        C::t("#tom_tcqianggou#tom_tcqianggou_goods")->update($goods_id,$updateData);
                    }
                    $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
                    update_qiang_status($goodsInfoTmp);
                }
            }
        }else{
            
            $insertData = array();
            if($__Admin['admin'] == 'admin'){
                $insertData['is_admin']     = 1;
            }
            $insertData['goods_id']     = $goods_id;
            $insertData['change_num']   = $stock_num;
            $insertData['change_time']  = TIMESTAMP;
            C::t('#tom_tcqianggou#tom_tcqianggou_stock_log')->insert($insertData);
            
            C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->delete_by_goods_id($goods_id);
            $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
            update_qiang_status($goodsInfoTmp);
        }
        
        if($__Admin['admin'] == 'shopadmin' && $tcqianggouConfig['must_shenhe'] == 1){
            $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUser && !empty($toUser['openid'])){
            
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                $access_token = $weixinClass->get_access_token();

                if($access_token && !empty($toUser['openid'])  ){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");
                    $smsData = array(
                        'first'         => '['.$tcshopInfo['name'].']'.$Lang['template_shenhe_template_edit'],
                        'keyword1'      => $tongchengConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                        'remark'        => ''
                    );
                    $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}else if($act == 'del_option' && submitcheck('option_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $option_id = intval($_GET['option_id'])>0? intval($_GET['option_id']): 0;
    
    $optionInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($option_id);
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($optionInfo['goods_id']);
    
    if($__Admin['admin'] == 'shopadmin'){
        if($goodsInfo['user_id'] != $__UserInfo['id']){
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
            );
            echo json_encode($outArr); exit;
        }
    }
    
    
    C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->delete_by_id($option_id);
    
    $optionListTmp = C::t("#tom_tcqianggou#tom_tcqianggou_goods_option")->fetch_all_list(" AND goods_id = {$optionInfo['goods_id']} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_market_price = $show_buy_price = $show_vip_price = $show_before_price = $stock_num = 0;
        foreach($optionListTmp as $key => $value){
            $stock_num = $stock_num + $value['stock_num'];
            if($show_buy_price == 0){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
                $show_vip_price     = $value['vip_price'];
                $show_before_price  = $value['before_price'];
            }else if($value['buy_price'] < $show_buy_price){
                $show_market_price  = $value['market_price'];
                $show_buy_price     = $value['buy_price'];
                $show_vip_price     = $value['vip_price'];
                $show_before_price  = $value['before_price'];
            }
        }
        if($show_buy_price > 0){
            $updateData = array();
            $updateData['show_market_price']    = $show_market_price;
            $updateData['show_buy_price']       = $show_buy_price;
            $updateData['show_vip_price']       = $show_vip_price;
            $updateData['show_before_price']    = $show_before_price;
            $updateData['stock_num']            = $stock_num;
            $updateData['part1']                = TIMESTAMP;
            C::t("#tom_tcqianggou#tom_tcqianggou_goods")->update($optionInfo['goods_id'],$updateData);
        }
        update_qiang_status($goodsInfo);
    }
    
    $outArr = array(
        'code' => 200,
    );
    echo json_encode($outArr); exit;
}

if($__Admin['admin'] == 'shopadmin'){
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY paixu ASC,id ASC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$cateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_cate')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
$cateList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$value['id']] = $value;
    }
}

$recomCateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_list("AND type = 1 AND site_id = {$goodsInfo['site_id']} "," ORDER BY csort ASC, id DESC ",0,1000);
if(is_array($recomCateListTmp) && !empty($recomCateListTmp)){ }else{
    $recomCateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_list($where." AND site_id = 1 "," ORDER BY csort ASC, id DESC ",0,1000);
}
$recomCateList = array();
if(!empty($recomCateListTmp)){
    foreach($recomCateListTmp as $key => $value){
        $recomCateList[$value['id']] = $value;
    }
}

$tradeListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_trade')->fetch_all_list(" AND site_id = {$goodsInfo['site_id']} "," ORDER BY tsort ASC,id DESC ");
$tradeList = array();
if(!empty($tradeListTmp)){
    foreach($tradeListTmp as $key => $value){
        $tradeList[$key] = $value;
    }
}

$photoListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->fetch_all_list(" AND goods_id={$goods_id} ","ORDER BY id ASC",0,50);
$photoList = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach ($photoListTmp as $key => $value){
        $photoList[$key] = $value;
        $photoList[$key]['picurlTmp'] = get_file_url($value['picurl']);
    }
}

$picurl         = get_file_url($goodsInfo['picurl']);
$toppic         = get_file_url($goodsInfo['toppic']);
$haibao_picurl  = get_file_url($goodsInfo['haibao_picurl']);

if($goodsInfo['hasoption'] == 1){
    $optionListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_all_list("AND goods_id = {$goods_id}", 'ORDER BY osort ASC, id ASC', 0, 100);
    $optionList = array();
    $option_num = 1;
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        foreach($optionListTmp as $key => $value){
            $optionList[$key] = $value;
            $optionList[$key]['option_num'] = $option_num;
            $option_num++;
        }
    }
}

$goodsInfo['xuzhi'] = stripcslashes($goodsInfo['xuzhi']);
$goodsInfo['content'] = stripcslashes($goodsInfo['content']);

$start_time = '';
if($goodsInfo['start_time'] > 0){
    $start_time = dgmdate($goodsInfo['start_time'],"Y-m-d H:i:s",$tomSysOffset);
}
$end_time = '';
if($goodsInfo['end_time'] > 0){
    $end_time = dgmdate($goodsInfo['end_time'],"Y-m-d H:i:s",$tomSysOffset);
}
$hexiao_start_time = '';
if($goodsInfo['hexiao_start_time'] > 0){
    $hexiao_start_time = dgmdate($goodsInfo['hexiao_start_time'],"Y-m-d H:i:s",$tomSysOffset);
}
$hexiao_time = '';
if($goodsInfo['hexiao_time'] > 0){
    $hexiao_time = dgmdate($goodsInfo['hexiao_time'],"Y-m-d H:i:s",$tomSysOffset);
}

if($__ShowTcyuyue == 1){
    $tcyuyueListTmp = C::t('#tom_tcyuyue#tom_tcyuyue')->fetch_all_list("AND tcshop_id = {$goodsInfo['tcshop_id']}  AND type = 2 AND status = 1 AND shenhe_status = 1 ");
    $tcyuyueList = array();
    if(is_array($tcyuyueListTmp) && !empty($tcyuyueListTmp)){
        foreach($tcyuyueListTmp as $key => $value){
            $tcyuyueList[$key] = $value;
        }
    }
}

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/edit");