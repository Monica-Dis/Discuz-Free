<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$recom_cate_id = intval($_GET['recom_cate_id'])>0 ? intval($_GET['recom_cate_id']):0;
$recomCateInfo = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_by_id($recom_cate_id);
if(empty($recomCateInfo)){
    dheader('location:'.$pcadminUrl."&tmod=recom_cate");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=recom_cate_edit&recom_cate_id={$recom_cate_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $sub_title      = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $type           = isset($_GET['type'])? intval($_GET['type']):1;
    $template_type  = isset($_GET['template_type'])? intval($_GET['template_type']):1;
    $toppic         = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    $index_show_num = isset($_GET['index_show_num'])? intval($_GET['index_show_num']):0;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $csort          = isset($_GET['csort'])? intval($_GET['csort']):10;
    
    $updateData = array();
    $updateData['site_id']          = $site_id;
    $updateData['name']             = $name;
    $updateData['sub_title']        = $sub_title;
    $updateData['type']             = $type;
    $updateData['template_type']    = $template_type;
    $updateData['toppic']           = $toppic;
    $updateData['index_show_num']   = $index_show_num;
    $updateData['status']           = $status;
    $updateData['csort']            = $csort;
    if(C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->update($recomCateInfo['id'], $updateData)){
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$toppic = get_file_url($recomCateInfo['toppic']);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/recom_cate_edit");