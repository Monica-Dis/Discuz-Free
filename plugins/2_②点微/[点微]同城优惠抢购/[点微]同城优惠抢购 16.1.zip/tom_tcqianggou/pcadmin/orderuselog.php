<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_id = intval($_GET['order_id'])>0? intval($_GET['order_id']):0;
$orderInfo = C::t('#tom_tcqianggou#tom_tcqianggou_order')->fetch_by_id($order_id);
if(empty($orderInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    $goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($orderInfo['goods_id']);
    if($__UserInfo['id'] != $goodsInfo['user_id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=orderuselog&order_id={$order_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'list' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $page       = intval($_GET['page'])>0 ? intval($_GET['page']) :1;
    $pagesize   = intval($_GET['pagesize'])>0 ? intval($_GET['pagesize']) :10;
    
    $where = "AND order_id = {$order_id}";
    
    $start = ($page-1)*$pagesize;
    
    $count = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_all_count($where);
    $useLogListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_order_use_log')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    $useLogList = array();
    if(!empty($useLogListTmp)){
        foreach($useLogListTmp as $key => $value){
            $useLogList[$key] = $value;
            
            $userInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['user_id']);
            $hexiaoUserInfoTmp = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['hexiao_user_id']);
            $orderInfoTmp = C::t("#tom_tcqianggou#tom_tcqianggou_order")->fetch_by_id($value['order_id']);
            
            $useLogList[$key]['userInfo']       = $userInfoTmp;
            $useLogList[$key]['hexiaoUserInfo'] = $hexiaoUserInfoTmp;
            $useLogList[$key]['orderInfo']      = $orderInfoTmp;
            $useLogList[$key]['hexiao_time']    = dgmdate($value['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
        }
    }
    
    $list = iconv_to_utf8($useLogList);
    
    $outArr = array(
        'code'  => 0,
        'msg'   => '',
        'count' => $count,
        'data'  => $list,
    );
    echo json_encode($outArr); exit;
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/orderuselog");