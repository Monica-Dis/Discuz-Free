<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$trade_id = intval($_GET['trade_id'])>0 ? intval($_GET['trade_id']):0;

$tradeInfo = C::t('#tom_tcqianggou#tom_tcqianggou_trade')->fetch_by_id($trade_id);
if(empty($tradeInfo)){
    dheader('location:'.$pcadminUrl."&tmod=trade");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=tradeedit&trade_id={$trade_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $is_recommend   = isset($_GET['is_recommend'])? intval($_GET['is_recommend']):0;
    $tsort          = isset($_GET['tsort'])? intval($_GET['tsort']):0;
    
    $updateData = array();
    $updateData['site_id']          = $site_id;
    $updateData['name']             = $name;
    $updateData['picurl']           = $picurl;
    $updateData['is_recommend']     = $is_recommend;
    $updateData['tsort']            = $tsort;
    C::t('#tom_tcqianggou#tom_tcqianggou_trade')->update($trade_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$picurl = get_file_url($tradeInfo['picurl']);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/tradeedit");