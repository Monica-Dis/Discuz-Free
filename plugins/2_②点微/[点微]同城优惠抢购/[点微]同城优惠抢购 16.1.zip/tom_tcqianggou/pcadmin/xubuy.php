<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
if(empty($goodsInfo) || $goodsInfo['open_xubuy'] == 0){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=xubuy&goods_id={$goods_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'add' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $option_id          = isset($_GET['option_id'])? intval($_GET['option_id']):0;
    $order_time         = isset($_GET['order_time'])? addslashes($_GET['order_time']):'';
    $order_time         = strtotime($order_time);

    if($order_time > TIMESTAMP){
        $outArr = array(
            'code'=> 200,
            'status'=> 301,
        );    
        echo json_encode($outArr); exit;
    }
    
    $insertData = array();
    $insertData['goods_id']     = $goods_id;
    $insertData['option_id']    = $option_id;
    $insertData['type_id']      = 2;
    $insertData['user_id']      = $user_id;
    $insertData['goods_num']    = 1;
    $insertData['order_time']   = $order_time;
    C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->insert($insertData);

    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $xubuy_id = intval($_GET['xubuy_id'])>0 ? intval($_GET['xubuy_id']):0; 
    
    C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->delete_by_id($xubuy_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

if($goodsInfo['hasoption'] == 1){
    $optionListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_all_list(" AND goods_id = {$goodsInfo['id']} "," ORDER BY osort ASC,id ASC ",0,100);
    $optionList = array();
    if(!empty($optionListTmp)){
        foreach($optionListTmp as $key => $value){
            $optionList[$value['id']] = $value;
        }
    }
}

$majiaList = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_all_like_list(' AND is_majia = 1 ',"ORDER BY id DESC",0,1000,'');

$where = "AND goods_id={$goods_id} AND type_id=2";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_count($where);
$xubuyListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_xubuy')->fetch_all_list($where,"ORDER BY order_time DESC,id ASC",$start,$pagesize);
$xubuyList = array();
if(!empty($xubuyListTmp)){
    foreach ($xubuyListTmp as $key => $value) {
        $xubuyList[$key] = $value;
        
        $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        
        $optionInfoTmp = array(); 
       if($goodsInfo['hasoption'] == 1){
            $optionInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_by_id($value['option_id']);
        }
        
        $xubuyList[$key]['userInfo']        = $userInfoTmp;
        $xubuyList[$key]['optionInfo']      = $optionInfoTmp;
        $xubuyList[$key]['order_time']      = dgmdate($value['order_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/xubuy");