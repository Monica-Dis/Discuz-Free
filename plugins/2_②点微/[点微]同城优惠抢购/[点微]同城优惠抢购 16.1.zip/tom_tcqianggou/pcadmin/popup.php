<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=popup";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'hide' && submitcheck('popup_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $popup_id = intval($_GET['popup_id'])>0 ? intval($_GET['popup_id']):0; 
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcqianggou#tom_tcqianggou_popup')->update($popup_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('popup_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $popup_id = intval($_GET['popup_id'])>0 ? intval($_GET['popup_id']):0; 
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcqianggou#tom_tcqianggou_popup')->update($popup_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('popup_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $popup_id = intval($_GET['popup_id'])>0 ? intval($_GET['popup_id']):0; 
    
    C::t('#tom_tcqianggou#tom_tcqianggou_popup')->delete_by_id($popup_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = "";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcqianggou#tom_tcqianggou_popup')->fetch_all_count($where);
$popupListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_popup')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$popupList = array();
if(!empty($popupListTmp)){
    foreach ($popupListTmp as $key => $value) {
        $popupList[$key] = $value;
        
        $popupList[$key]['picurlTmp']   = get_file_url($value['picurl']);
        $popupList[$key]['add_time']    = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/popup");