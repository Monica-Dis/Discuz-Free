<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
if(empty($goodsInfo) || $goodsInfo['open_duo_shop'] == 0){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=goodsshopadd&goods_id={$goods_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $market_price       = isset($_GET['market_price'])? floatval($_GET['market_price']):0.00;
    $stock_num          = isset($_GET['stock_num'])? intval($_GET['stock_num']):0;
    $xian_use_num       = isset($_GET['xian_use_num'])? intval($_GET['xian_use_num']):0;
    $one_jiesuan_price  = isset($_GET['one_jiesuan_price'])? floatval($_GET['one_jiesuan_price']):0;
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $ssort              = isset($_GET['ssort'])? intval($_GET['ssort']):10;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $insertData = array();
    $insertData['goods_id']             = $goods_id;
    $insertData['title']                = $title;
    $insertData['tcshop_id']            = $tcshop_id;
    $insertData['picurl']               = $picurl;
    $insertData['market_price']         = $market_price;
    $insertData['stock_num']            = $stock_num;
    $insertData['xian_use_num']         = $xian_use_num;
    $insertData['one_jiesuan_price']    = $one_jiesuan_price;
    $insertData['hexiao_pwd']           = $hexiao_pwd;
    $insertData['ssort']                = $ssort;
    $insertData['content']              = $content;
    $insertData['add_time']             = TIMESTAMP;
    $goods_shop_id = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->insert($insertData, true);
    if($goods_shop_id > 0){
    
        $beizu = 'ID&nbsp;<font color="#0a9409">'.$goods_shop_id.'</font> '
                .$Lang['goodsshopadd_tit'].' <font color="#0a9409">'.$title.'</font> '
                .$Lang['goodsshopadd_tcshop_id'].' <font color="#fd0d0d">'.$tcshop_id.'</font> '
                .$Lang['goodsshopadd_stock_num'].' <font color="#fd0d0d">'.$stock_num.' </font> '
                .$Lang['goodsshopadd_xian_use_num'].' <font color="#fd0d0d">'.$xian_use_num.'</font> '
                .$Lang['goodsshopadd_one_jiesuan_price'].' <font color="#fd0d0d">'.$one_jiesuan_price.'</font>';

        $insertData = array();
        $insertData['is_admin']     = 1;
        $insertData['is_option']    = 1;
        $insertData['goods_id']     = $goods_id;
        $insertData['beizu']        = $beizu;
        $insertData['change_num']   = $stock_num;
        $insertData['change_time']  = TIMESTAMP;
        C::t("#tom_tcqianggou#tom_tcqianggou_stock_log")->insert($insertData);

        update_qiang_status($goodsInfo);
        
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/goodsshopadd");