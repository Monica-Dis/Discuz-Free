<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=trade";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'update_is_recommend' && submitcheck('trade_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $trade_id       = intval($_GET['trade_id'])>0 ? intval($_GET['trade_id']):0;
    $is_recommend   = intval($_GET['is_recommend'])>0 ? intval($_GET['is_recommend']):0;
    
    $updateData = array();
    $updateData['is_recommend'] = $is_recommend;
    C::t('#tom_tcqianggou#tom_tcqianggou_trade')->update($trade_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('trade_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $trade_id = intval($_GET['trade_id'])>0 ? intval($_GET['trade_id']):0;
    
    C::t('#tom_tcqianggou#tom_tcqianggou_trade')->delete_by_id($trade_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$site_id            = intval($_GET['site_id'])>0? intval($_GET['site_id']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = "";
if($site_id > 0){
    $where .= "AND site_id = {$site_id}";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcqianggou#tom_tcqianggou_trade')->fetch_all_count($where);
$tradeListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_trade')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$tradeList = array();
if(!empty($tradeListTmp)){
    foreach ($tradeListTmp as $key => $value) {
        $tradeList[$key] = $value;
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        
        $tradeList[$key]['picurlTmp']   = get_file_url($value['picurl']);
        $tradeList[$key]['siteInfo']    = $siteInfoTmp;
        $tradeList[$key]['add_time']    = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/trade");