<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$group_qrcode_id = intval($_GET['group_qrcode_id'])>0 ? intval($_GET['group_qrcode_id']):0;

$groupQrcodeInfo = C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->fetch_by_id($group_qrcode_id);
if(empty($groupQrcodeInfo)){
    dheader('location:'.$pcadminUrl."&tmod=group");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=groupedit&group_qrcode_id={$group_qrcode_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $logo           = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    $qrcode         = isset($_GET['qrcode'])? addslashes($_GET['qrcode']):'';
    $desc           = isset($_GET['desc'])? addslashes($_GET['desc']):'';
    $tishi_msg      = isset($_GET['tishi_msg'])? addslashes($_GET['tishi_msg']):'';
    
    $siteIdsArr = array();
    if(is_array($_GET['sites']) && !empty($_GET['sites'])){
        foreach($_GET['sites'] as $key => $value){
            $value = intval($value);
            if($value > 0){
                $siteIdsArr[] = '['.$value.']';
            }
        }
    }
    $siteIdsStr = implode(',', $siteIdsArr);
    
    $updateData = array();
    $updateData['site_id']      = $site_id;
    $updateData['goods_id']     = $goods_id;
    $updateData['name']         = $name;
    $updateData['logo']         = $logo;
    $updateData['qrcode']       = $qrcode;
    $updateData['desc']         = $desc;
    $updateData['tishi_msg']    = $tishi_msg;
    $updateData['add_time']     = TIMESTAMP;
    if(C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->update($group_qrcode_id, $updateData)){
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$logo = get_file_url($groupQrcodeInfo['logo']);
$qrcode = get_file_url($groupQrcodeInfo['qrcode']);

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/groupedit");