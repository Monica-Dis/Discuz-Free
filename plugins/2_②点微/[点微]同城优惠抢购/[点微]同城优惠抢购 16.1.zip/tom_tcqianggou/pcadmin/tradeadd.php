<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=tradeadd";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('name')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $picurl         = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $is_recommend   = isset($_GET['is_recommend'])? intval($_GET['is_recommend']):0;
    $tsort          = isset($_GET['tsort'])? intval($_GET['tsort']):100;
    
    $insertData = array();
    $insertData['site_id']      = $site_id;
    $insertData['name']         = $name;
    $insertData['picurl']       = $picurl;
    $insertData['is_recommend'] = $is_recommend;
    $insertData['tsort']        = $tsort;
    $insertData['add_time']     = TIMESTAMP;
    if(C::t('#tom_tcqianggou#tom_tcqianggou_trade')->insert($insertData)){
        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list("  "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/tradeadd");