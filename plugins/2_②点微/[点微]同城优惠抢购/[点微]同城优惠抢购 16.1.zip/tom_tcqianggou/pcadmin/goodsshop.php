<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
if(empty($goodsInfo) || $goodsInfo['open_duo_shop'] == 0){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

$modPcadminUrl = $pcadminUrl."&tmod=goodsshop&goods_id={$goods_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('goods_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $duo_hexiao_num     = isset($_GET['duo_hexiao_num'])? intval($_GET['duo_hexiao_num']):0;
    $duo_shop_jiesuan   = isset($_GET['duo_shop_jiesuan'])? intval($_GET['duo_shop_jiesuan']):1;

    $updateData = array();
    $updateData['duo_hexiao_num']               = $duo_hexiao_num;
    $updateData['duo_shop_jiesuan']             = $duo_shop_jiesuan;
    C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($goods_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('shop_goods_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $shop_goods_id = intval($_GET['shop_goods_id'])>0? intval($_GET['shop_goods_id']):0;
    
    C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->delete_by_id($shop_goods_id);
    
    update_qiang_status($goodsInfo);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):20;

$where = "AND goods_id = {$goodsInfo['id']}";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->fetch_all_count($where);
$goodsShopListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_shop')->fetch_all_list($where," ORDER BY ssort ASC,id ASC ",$start,$pagesize);
$goodsShopList = array();
if(!empty($goodsShopListTmp)){
    foreach ($goodsShopListTmp as $key => $value) {
        $goodsShopList[$key] = $value;
        
        $tcshopInfoTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($value['tcshop_id']);
        
        $goodsShopList[$key]['picurl']      = get_file_url($value['picurl']);
        $goodsShopList[$key]['tcshopInfo']  = $tcshopInfoTmp;
        $goodsShopList[$key]['add_time']    = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/goodsshop");