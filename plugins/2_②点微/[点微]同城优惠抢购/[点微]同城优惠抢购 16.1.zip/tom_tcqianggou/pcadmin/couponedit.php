<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
if(empty($goodsInfo)){
    dheader('location:'.$pcadminUrl."&tmod=list");exit;
}

if($__Admin['admin'] == 'shopadmin'){
    if($__UserInfo['id'] != $goodsInfo['user_id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=couponedit&goods_id={$goods_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'save' && submitcheck('title')){
    $outArr = array(
        'code'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $type_id            = isset($_GET['type_id'])? intval($_GET['type_id']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $recom_cate_id      = isset($_GET['recom_cate_id'])? intval($_GET['recom_cate_id']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $trade_id           = isset($_GET['trade_id'])? intval($_GET['trade_id']):0;
    $xiangou_num        = isset($_GET['xiangou_num'])? intval($_GET['xiangou_num']):0;
    $coupon_zhekou      = isset($_GET['coupon_zhekou'])? addslashes($_GET['coupon_zhekou']):'';
    $coupon_price       = isset($_GET['coupon_price'])? addslashes($_GET['coupon_price']):'';
    $coupon_limit       = isset($_GET['coupon_limit'])? addslashes($_GET['coupon_limit']):'';
    $coupon_msg         = isset($_GET['coupon_msg'])? addslashes($_GET['coupon_msg']):'';
    $hexiao_pwd         = isset($_GET['hexiao_pwd'])? addslashes($_GET['hexiao_pwd']):'';
    $hexiao_start_time  = isset($_GET['hexiao_start_time'])? addslashes($_GET['hexiao_start_time']):'';
    $hexiao_start_time  = strtotime($hexiao_start_time);
    $hexiao_time        = isset($_GET['hexiao_time'])? addslashes($_GET['hexiao_time']):'';
    $hexiao_time        = strtotime($hexiao_time);
    $open_hexiao_valid  = isset($_GET['open_hexiao_valid'])? intval($_GET['open_hexiao_valid']):0;
    $hexiao_valid_days  = isset($_GET['hexiao_valid_days'])? intval($_GET['hexiao_valid_days']):0;
    $coupon_is_buy      = isset($_GET['coupon_is_buy'])? intval($_GET['coupon_is_buy']):0;
    $coupon_buy_price   = isset($_GET['coupon_buy_price'])? addslashes($_GET['coupon_buy_price']):'';
    $open_vip           = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $vip_price          = isset($_GET['vip_price'])? floatval($_GET['vip_price']):0.00;
    $open_score_dikou   = isset($_GET['open_score_dikou'])? intval($_GET['open_score_dikou']):0;
    $score_num          = isset($_GET['score_num'])? intval($_GET['score_num']):0;
    $score_dikou_price  = isset($_GET['score_dikou_price'])? floatval($_GET['score_dikou_price']):0.00;
    $paixu              = isset($_GET['paixu'])? intval($_GET['paixu']):1000;
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $stock_num          = isset($_GET['stock_num'])? addslashes($_GET['stock_num']):0;
    
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $toppic             = isset($_GET['toppic'])? addslashes($_GET['toppic']):'';
    
    $haibao_msg         = isset($_GET['haibao_msg'])? addslashes($_GET['haibao_msg']):'';
    $share_title        = isset($_GET['share_title'])? addslashes($_GET['share_title']):'';
    $share_desc         = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
    
    $open_shop_yongjin  = isset($_GET['open_shop_yongjin'])? intval($_GET['open_shop_yongjin']):0;
    $shop_yongjin       = isset($_GET['shop_yongjin'])? floatval($_GET['shop_yongjin']):0;
    $yongjin_type       = isset($_GET['yongjin_type'])? intval($_GET['yongjin_type']):1;
    $yongjin_bili       = isset($_GET['yongjin_bili'])? floatval($_GET['yongjin_bili']):0;
    
    $hehuoren_tg_open   = isset($_GET['hehuoren_tg_open'])? intval($_GET['hehuoren_tg_open']):2;
    $chuji_fc_scale     = isset($_GET['chuji_fc_scale'])? floatval($_GET['chuji_fc_scale']):0;
    $zhongji_fc_scale   = isset($_GET['zhongji_fc_scale'])? floatval($_GET['zhongji_fc_scale']):0;
    $gaoji_fc_scale     = isset($_GET['gaoji_fc_scale'])? floatval($_GET['gaoji_fc_scale']):0;
    $chuji_fc_scale2    = isset($_GET['chuji_fc_scale2'])? floatval($_GET['chuji_fc_scale2']):0;
    $zhongji_fc_scale2  = isset($_GET['zhongji_fc_scale2'])? floatval($_GET['zhongji_fc_scale2']):0;
    $gaoji_fc_scale2    = isset($_GET['gaoji_fc_scale2'])? floatval($_GET['gaoji_fc_scale2']):0;
    
    $photoArr = array();
    foreach($_GET['photo'] as $key => $value){
        $value = addslashes($value);
        if(!empty($value)){
            $photoArr[] = $value;
        }
    }
    
    if($__Admin['admin'] == 'shopadmin'){
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
        if($tcshopInfo['user_id'] != $__UserInfo['id']){
            $outArr = array(
                'code'=> 1001,
                'msg'=> diconv($Lang['error'],CHARSET,'utf-8'),
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($tcshop_id);
    }
    
    if($stock_num < $goodsInfo['sale_num']){
        $stock_num = $goodsInfo['sale_num'];
    }
    
    $updateData = array();
    $updateData['title']                = $title;
    $updateData['cate_id']              = $cate_id;
    $updateData['trade_id']             = $trade_id;
    $updateData['xiangou_num']          = $xiangou_num;
    $updateData['hexiao_start_time']    = $hexiao_start_time;
    $updateData['hexiao_time']          = $hexiao_time;
    $updateData['open_hexiao_valid']    = $open_hexiao_valid;
    $updateData['hexiao_valid_days']    = $hexiao_valid_days;
    $updateData['hexiao_pwd']           = $hexiao_pwd;
    $updateData['admin_edit']           = $admin_edit;
    $updateData['content']              = $content;
    $updateData['picurl']               = $picurl;
    $updateData['toppic']               = $toppic;
    $updateData['stock_num']            = $stock_num;
    $updateData['open_score_dikou']     = $open_score_dikou;
    if($open_score_dikou == 1){
        $updateData['score_num']            = $score_num;
        $updateData['score_dikou_price']    = $score_dikou_price;
    }
    $updateData['latitude']             = $tcshopInfo['latitude'];
    $updateData['longitude']            = $tcshopInfo['longitude'];
    
    if($__Admin['admin'] == 'admin'){
        $updateData['site_id']              = $tcshopInfo['site_id'];
        $updateData['user_id']              = $tcshopInfo['user_id'];
        $updateData['tcshop_id']            = $tcshop_id;
        $updateData['type_id']              = $type_id;
        $updateData['open_vip']             = $open_vip;
        $updateData['vip_price']            = $vip_price;
        $updateData['recom_cate_id']        = $recom_cate_id;
        $updateData['paixu']                = $paixu;
        $updateData['haibao_msg']           = $haibao_msg;
        $updateData['open_shop_yongjin']    = $open_shop_yongjin;
        $updateData['shop_yongjin']         = $shop_yongjin;
        $updateData['yongjin_type']         = $yongjin_type;
        $updateData['yongjin_bili']         = $yongjin_bili;
        $updateData['hehuoren_tg_open']     = $hehuoren_tg_open;
        $updateData['chuji_fc_scale']       = $chuji_fc_scale;
        $updateData['zhongji_fc_scale']     = $zhongji_fc_scale;
        $updateData['gaoji_fc_scale']       = $gaoji_fc_scale;
        $updateData['chuji_fc_scale2']      = $chuji_fc_scale2;
        $updateData['zhongji_fc_scale2']    = $zhongji_fc_scale2;
        $updateData['gaoji_fc_scale2']      = $gaoji_fc_scale2;
    }
    
    $updateData['share_title']          = $share_title;
    $updateData['share_desc']           = $share_desc;
    $updateData['coupon_price']         = $coupon_price;
    $updateData['coupon_limit']         = $coupon_limit;
    $updateData['coupon_zhekou']        = $coupon_zhekou;
    $updateData['coupon_is_buy']        = $coupon_is_buy;
    $updateData['coupon_buy_price']     = $coupon_buy_price;
    $updateData['coupon_msg']           = $coupon_msg;
    
    if($__Admin['admin'] == 'shopadmin' && $tcqianggouConfig['must_shenhe'] == 1){
        $updateData['shenhe_status']        = 2;
    }
    
    $updateData['part1']                = TIMESTAMP;
    if(C::t('#tom_tcqianggou#tom_tcqianggou_goods')->update($goods_id, $updateData)){
        
        C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->delete_by_goods_id($goods_id);
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']     = $goods_id;
                $insertData['picurl']       = $value;
                $insertData['add_time']     = TIMESTAMP;
                C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->insert($insertData);
            }
        }
        
        $insertData = array();
        if($__Admin['admin'] == 'admin'){
            $insertData['is_admin']     = 1;
        }
        $insertData['goods_id']     = $goods_id;
        $insertData['change_num']   = $stock_num;
        $insertData['change_time']  = TIMESTAMP;
        C::t('#tom_tcqianggou#tom_tcqianggou_stock_log')->insert($insertData);
        
        $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);
        update_qiang_status($goodsInfoTmp);
        
        if($__Admin['admin'] == 'shopadmin' && $tcqianggouConfig['must_shenhe'] == 1){
            $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUser && !empty($toUser['openid'])){
            
                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                $access_token = $weixinClass->get_access_token();

                if($access_token && !empty($toUser['openid'])  ){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqianggou&site={$site_id}&mod=index");
                    $smsData = array(
                        'first'         => '['.$tcshopInfo['name'].']'.$Lang['template_shenhe_template_kaquan_edit'],
                        'keyword1'      => $tongchengConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                        'remark'        => ''
                    );
                    $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
                }
            }
        }

        $outArr = array(
            'code'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'code'=> 404,
        );
        echo json_encode($outArr); exit;
    }
}

if($__Admin['admin'] == 'shopadmin'){
    $tcshopInfo = C::t('#tom_tcshop#tom_tcshop')->fetch_by_id($goodsInfo['tcshop_id']);
}

$cateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_cate')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
$cateList = array();
if(!empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$value['id']] = $value;
    }
}

$recomCateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_list("AND type = 2 AND site_id = {$goodsInfo['site_id']} "," ORDER BY csort ASC, id DESC ",0,1000);
$recomCateList = array();
if(!empty($recomCateListTmp)){
    foreach($recomCateListTmp as $key => $value){
        $recomCateList[$value['id']] = $value;
    }
}

$tradeListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_trade')->fetch_all_list("AND site_id = {$goodsInfo['site_id']} "," ORDER BY tsort ASC,id DESC ");
$tradeList = array();
if(!empty($tradeListTmp)){
    foreach($tradeListTmp as $key => $value){
        $tradeList[$key] = $value;
    }
};

$photoListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_photo')->fetch_all_list(" AND goods_id={$goods_id} ","ORDER BY id ASC",0,50);
$photoList = array();
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach ($photoListTmp as $key => $value){
        $photoList[$key] = $value;
        $photoList[$key]['picurlTmp'] = get_file_url($value['picurl']);
    }
}

$picurl         = get_file_url($goodsInfo['picurl']);
$toppic         = get_file_url($goodsInfo['toppic']);

$goodsInfo['content'] = stripcslashes($goodsInfo['content']);

$hexiao_start_time = '';
if($goodsInfo['hexiao_start_time'] > 0){
    $hexiao_start_time = dgmdate($goodsInfo['hexiao_start_time'],"Y-m-d H:i:s",$tomSysOffset);
}
$hexiao_time = '';
if($goodsInfo['hexiao_time'] > 0){
    $hexiao_time = dgmdate($goodsInfo['hexiao_time'],"Y-m-d H:i:s",$tomSysOffset);
}
    
$saveUrl = $modPcadminUrl."&act=save";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/couponedit");