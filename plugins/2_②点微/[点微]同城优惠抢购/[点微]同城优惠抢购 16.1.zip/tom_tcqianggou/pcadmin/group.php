<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=group";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'hide' && submitcheck('group_qrcode_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $group_qrcode_id = intval($_GET['group_qrcode_id'])>0 ? intval($_GET['group_qrcode_id']):0;
    
    $updateData = array();
    $updateData['status'] = 0;
    C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->update($group_qrcode_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'show' && submitcheck('group_qrcode_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $group_qrcode_id = intval($_GET['group_qrcode_id'])>0 ? intval($_GET['group_qrcode_id']):0;
    
    $updateData = array();
    $updateData['status'] = 1;
    C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->update($group_qrcode_id, $updateData);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('group_qrcode_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $group_qrcode_id = intval($_GET['group_qrcode_id'])>0 ? intval($_GET['group_qrcode_id']):0;
    
    C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->delete_by_id($group_qrcode_id);
    
    $outArr = array(
        'code'=> 200,
    );    
    echo json_encode($outArr); exit;
}

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = "";

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->fetch_all_count($where);
$qrcodeListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_group_qrcode')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
$qrcodeList = array();
if(!empty($qrcodeListTmp)){
    foreach ($qrcodeListTmp as $key => $value) {
        $qrcodeList[$key] = $value;
        
        $siteInfoTmp = $sitesList[$value['site_id']];
        $goodsInfoTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($value['goods_id']);
        
        $qrcodeList[$key]['logoTmp']    = get_file_url($value['logo']);
        $qrcodeList[$key]['qrcodeTmp']  = get_file_url($value['qrcode']);
        $qrcodeList[$key]['siteInfo']   = $siteInfoTmp;
        $qrcodeList[$key]['goodsInfo']  = $goodsInfoTmp;
        $qrcodeList[$key]['add_time']   = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/group");