<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;
$goodsInfo = C::t('#tom_tcqianggou#tom_tcqianggou_goods')->fetch_by_id($goods_id);

if($__Admin['admin'] == 'shopadmin'){
    if($__UserInfo['id'] != $goodsInfo['user_id']){
        dheader('location:'.$pcadminUrl."&tmod=list");exit;
    }
}

$modPcadminUrl = $pcadminUrl."&tmod=option&goods_id={$goods_id}";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'list' && $_GET['formhash'] == FORMHASH){
    $outArr = array(
        'code'=> 1,
    );
    
    $page       = intval($_GET['page'])>0 ? intval($_GET['page']) :1;
    $pagesize   = intval($_GET['pagesize'])>0 ? intval($_GET['pagesize']) :10;
    
    $where = " AND goods_id={$goods_id} ";
    
    $start = ($page-1)*$pagesize;
    
    $count = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_all_count($where);
    $optionListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_goods_option')->fetch_all_list($where, 'ORDER BY osort ASC, id ASC', $start, $pagesize);
    $optionList = array();
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        foreach($optionListTmp as $key => $value){
            $optionList[$key] = $value;
            $optionList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i",$tomSysOffset);
        }
    }
    
    $list = iconv_to_utf8($optionList);
    
    $outArr = array(
        'code'  => 0,
        'msg'   => '',
        'count' => $count,
        'data'  => $list,
    );
    echo json_encode($outArr); exit;
}

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/option");