<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$modPcadminUrl = $pcadminUrl."&tmod=recom_cate";

$act = isset($_GET['act'])? addslashes($_GET['act']):'';

if($act == 'show' && submitcheck('recom_cate_id')){
    $outArr = array(
        'code'=> 1,
    );

    $recom_cate_id = intval($_GET['recom_cate_id'])>0 ? intval($_GET['recom_cate_id']):0;

    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->update($recom_cate_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'hide' && submitcheck('recom_cate_id')){
    $outArr = array(
        'code'=> 1,
    );

    $recom_cate_id = intval($_GET['recom_cate_id'])>0 ? intval($_GET['recom_cate_id']):0;

    $updateData = array();
    $updateData['status']     = 2;
    C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->update($recom_cate_id, $updateData);
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}else if($act == 'del' && submitcheck('recom_cate_id')){
    $outArr = array(
        'code'=> 1,
    );
    
    $recom_cate_id = intval($_GET['recom_cate_id'])>0 ? intval($_GET['recom_cate_id']):0;
    
    C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->delete_by_id($recom_cate_id);
    
    $outArr = array(
        'code'=> 200,
    );
    echo json_encode($outArr); exit;
}

$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize   = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):10;
$site_id    = intval($_GET['site_id'])>0? intval($_GET['site_id']):0;
$type       = intval($_GET['type'])>0? intval($_GET['type']):0;

$sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
$sitesList = array();
if(!empty($sitesListTmp)){
    foreach($sitesListTmp as $key => $value){
        $sitesList[$value['id']] = $value;
    }
}

$where = "";
if($site_id > 0){
    $where .= " AND site_id={$site_id} ";
}
if($type > 0){
    $where .= " AND type={$type} ";
}

$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_count($where);
$recomCateListTmp = C::t('#tom_tcqianggou#tom_tcqianggou_recom_cate')->fetch_all_list($where," ORDER BY site_id ASC,csort ASC,id DESC ",$start,$pagesize);
$recomCateList = array();
if(!empty($recomCateListTmp)){
    foreach ($recomCateListTmp as $key => $value) {
        $recomCateList[$key] = $value;
        
        $recomCateList[$key]['toppicTmp']   = get_file_url($value['toppic']);
        $recomCateList[$key]['siteInfo']    = $sitesList[$value['site_id']];
        $recomCateList[$key]['add_time']    = dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset);
    }
}

$pageUrl = $modPcadminUrl;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true; //dism��taobao��com
include template("tom_tcqianggou:pcadmin/recom_cate");