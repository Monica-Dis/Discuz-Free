<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcqun`;
CREATE TABLE `pre_tom_tcqun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `cate_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `tcshop_id` int(11) DEFAULT '0',
  `logo` varchar(255) DEFAULT NULL,
  `qrcode` varchar(255) DEFAULT NULL,
  `qunzhu_qrcode` varchar(255) DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `street_id` int(11) DEFAULT '0',
  `longitude` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `kouling` varchar(255) DEFAULT NULL,
  `allow_distance` decimal(10,1) DEFAULT '0.0',
  `open_addpay` tinyint(4) DEFAULT '0',
  `addpay_price` decimal(10,2) DEFAULT '0.00',
  `content` text,
  `shenhe_status` tinyint(4) DEFAULT '0',
  `status` tinyint(4) DEFAULT '0',
  `pay_status` tinyint(4) DEFAULT '0',
  `top_status` tinyint(4) DEFAULT '0',
  `top_time` int(11) unsigned DEFAULT '0',
  `expire_status` tinyint(4) DEFAULT '0',
  `expire_time` int(11) unsigned DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `virtual_clicks` int(11) DEFAULT '0',
  `sort` int(11) DEFAULT '10000',
  `refresh_time` int(11) unsigned DEFAULT '0',
  `update_time` int(11) unsigned DEFAULT '0',
  `qrcode_update_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_pay_status` (`pay_status`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_expire_status` (`expire_status`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqun_cate`;
CREATE TABLE `pre_tom_tcqun_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `csort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqun_common`;
CREATE TABLE `pre_tom_tcqun_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `clicks` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqun_focuspic`;
CREATE TABLE `pre_tom_tcqun_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT '1',
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqun_order`;
CREATE TABLE `pre_tom_tcqun_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `order_no` varchar(255) DEFAULT NULL,
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `order_type` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `tcqun_id` int(11) DEFAULT '0',
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `pay_time` int(11) DEFAULT '0',
  `top_days` int(11) DEFAULT '0',
  `top_price` decimal(10,2) DEFAULT '0.00',
  `fabu_days` int(11) DEFAULT '0',
  `fabu_price` decimal(10,2) DEFAULT '0.00',
  `order_status` int(11) DEFAULT '0',
  `order_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcqun_photo`;
CREATE TABLE `pre_tom_tcqun_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tcqun_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `psort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tcqun_id` (`tcqun_id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;