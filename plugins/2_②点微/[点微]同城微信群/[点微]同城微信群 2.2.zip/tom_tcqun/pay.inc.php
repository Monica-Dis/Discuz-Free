<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tcqunConfig = $_G['cache']['plugin']['tom_tcqun'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

include DISCUZ_ROOT.'./source/plugin/tom_tcqun/class/function.core.php';

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end

$act = isset($_GET['act'])? addslashes($_GET['act']):"";

$tjTchehuorenId = 0;
if($__ShowTchehuoren == 1){
    if($__UserInfo['tj_hehuoren_id'] > 0){
        $tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($__UserInfo['tj_hehuoren_id']);
        if($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1){
            $tjTchehuorenId = $__UserInfo['tj_hehuoren_id'];
        }
    }
}

if($act == "fabu" && submitcheck('user_id')){
   
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name               = dhtmlspecialchars($name);
    $sub_title          = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $sub_title          = dhtmlspecialchars($sub_title);
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $city_id            = isset($_GET['city_id'])? intval($_GET['city_id']):0;
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $lng                = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address            = dhtmlspecialchars($address);
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content            = filterEmoji($content);
    $content            = dhtmlspecialchars($content);
    $logo               = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    $qrcode             = isset($_GET['qrcode'])? addslashes($_GET['qrcode']):'';
    $qunzhu_qrcode      = isset($_GET['qunzhu_qrcode'])? addslashes($_GET['qunzhu_qrcode']):'';
    $fabu_days          = isset($_GET['fabu_days'])? intval($_GET['fabu_days']):0;
    $top_days           = isset($_GET['top_days'])? intval($_GET['top_days']):0;
    
    $open_addpay        = isset($_GET['open_addpay'])? intval($_GET['open_addpay']):0;
    $addpay_price       = isset($_GET['addpay_price'])? floatval($_GET['addpay_price']):0;
    
    $kouling            = isset($_GET['kouling'])? addslashes($_GET['kouling']):'';
    $kouling            = dhtmlspecialchars($kouling);
    $allow_distance     = isset($_GET['allow_distance'])? floatval($_GET['allow_distance']):0;

    $photoList = array();
    if(is_array($_GET['photo']) && !empty($_GET['photo'])){
        foreach($_GET['photo'] as $key => $value){
            $picurlTmp = addslashes($value);
            if(!empty($picurlTmp)){
                $photoList[] = $picurlTmp;
            }
        }
    }
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    if(empty($userInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $fabu_pay_price = $fabu_pay_score = 0;
    if($fabu_days > 0){
        $qun_fabu_list_str = str_replace("\r\n","{n}",$tcqunConfig['qun_fabu_list']); 
        $qun_fabu_list_str = str_replace("\n","{n}",$qun_fabu_list_str);
        $qun_fabu_list_arr = explode("{n}", $qun_fabu_list_str);
        if(is_array($qun_fabu_list_arr) && !empty($qun_fabu_list_arr)){
            foreach ($qun_fabu_list_arr as $key => $value){
                $qunFabuInfoTmp = array();
                $qunFabuInfoTmp = explode("|", $value);
                
                if($qunFabuInfoTmp[0] == $fabu_days){
                    $fabu_pay_price = $qunFabuInfoTmp[1];
                }
                
            }
        }
        
        if($tcqunConfig['open_fabu_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $fabu_pay_score = ceil($fabu_pay_price * $tongchengConfig['pay_score_yuan']);
        }
        
        if($fabu_pay_price > 0){}else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 306,
        );
        echo json_encode($outArr); exit;
    }
    
    if($top_days > 0){
        $top_pay_price = $top_pay_score = 0;
        $qun_top_list_str = str_replace("\r\n","{n}",$tcqunConfig['qun_top_list']);
        $qun_top_list_str = str_replace("\n","{n}",$qun_top_list_str);
        $qun_top_list_arr = explode("{n}", $qun_top_list_str);
        if(is_array($qun_top_list_arr) && !empty($qun_top_list_arr)){
            foreach ($qun_top_list_arr as $key => $value){
                $qunTopInfoTmp = array();
                $qunTopInfoTmp = explode("|", $value);
                
                if($qunTopInfoTmp[0] == $top_days){
                    $top_pay_price = $qunTopInfoTmp[1];
                }
            }
        }
        
        if($tcqunConfig['open_top_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $top_pay_score = ceil($top_pay_price * $tongchengConfig['pay_score_yuan']);
        }
        if($top_pay_price > 0){}else{
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $fabuPayStatus = 1;
    if($fabu_pay_score > 0 && $userInfo['score'] >= $fabu_pay_score){
        $fabuPayStatus = 2;
    }
    
    $topPayStatus = 0;
    if($top_days > 0){
        $topPayStatus = 1;
        
        if($fabuPayStatus == 2){
            $all_pay_score = $fabu_pay_score + $top_pay_score;
        }else{
            $all_pay_score = $top_pay_score;
        }
        if($top_pay_score > 0 && $userInfo['score'] >= $all_pay_score){
            $topPayStatus = 2;
        }
    }
    
    $pay_price = 0;
    if($fabuPayStatus == 1){
        $pay_price = $fabu_pay_price;
    }
    if($topPayStatus == 1){
        $pay_price = $pay_price + $top_pay_price;
    }
    
    $pay_score = 0;
    if($fabuPayStatus == 2){
        $pay_score = $fabu_pay_score;
    }
    if($topPayStatus == 2){
        $pay_score = $pay_score + $top_pay_score;
    }
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['user_id']          = $user_id;
    $insertData['name']             = $name;
    $insertData['sub_title']        = $sub_title;
    $insertData['cate_id']          = $cate_id;
    $insertData['tcshop_id']        = $tcshop_id;
    $insertData['logo']             = $logo;
    $insertData['qrcode']           = $qrcode;
    $insertData['qunzhu_qrcode']    = $qunzhu_qrcode;
    $insertData['city_id']          = $city_id;
    $insertData['area_id']          = $area_id;
    $insertData['street_id']        = $street_id;
    $insertData['longitude']        = $lng;
    $insertData['latitude']         = $lat;
    $insertData['address']          = $address;
    $insertData['open_addpay']      = $open_addpay;
    $insertData['addpay_price']     = $addpay_price;
    $insertData['kouling']          = $kouling;
    $insertData['allow_distance']   = $allow_distance;
    $insertData['content']          = $content;
    if($tcqunConfig['qun_must_shenhe'] == 1){
        $insertData['shenhe_status']    = 2;
    }else{
        $insertData['shenhe_status']    = 1;
    }
    $insertData['status']           = 0;
    if($fabuPayStatus == 1){
        $insertData['pay_status']       = 1;
    }else{
        $insertData['pay_status']       = 0;
    }
    $insertData['expire_status']        = 2;
    $insertData['refresh_time']         = TIMESTAMP;
    $insertData['qrcode_update_time']   = TIMESTAMP;
    $insertData['update_time']          = TIMESTAMP;
    $insertData['add_time']             = TIMESTAMP;
    if(C::t('#tom_tcqun#tom_tcqun')->insert($insertData)){
        $tcqun_id = C::t('#tom_tcqun#tom_tcqun')->insert_id();
        
        if(is_array($photoList) && !empty($photoList)){
            foreach($photoList as $key => $value){
                $insertData = array();
                $insertData['tcqun_id'] = $tcqun_id;
                $insertData['picurl']   = $value;
                $insertData['add_time'] = TIMESTAMP;
                C::t('#tom_tcqun#tom_tcqun_photo')->insert($insertData);
            }
        }
        
        if($pay_score > 0){
            
            $updateData = array();
            $updateData['score'] = $userInfo['score'] - $pay_score;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
            
            if($fabuPayStatus == 2){
                $updateData = array();
                $updateData['expire_status'] = 1;
                $updateData['expire_time']   = TIMESTAMP + $fabu_days*86400;
                C::t('#tom_tcqun#tom_tcqun')->update($tcqun_id,$updateData);
            }

            if($topPayStatus == 2){
                $updateData = array();
                $updateData['top_status'] = 1;
                $updateData['top_time']   = TIMESTAMP + $top_days*86400;
                C::t('#tom_tcqun#tom_tcqun')->update($tcqun_id,$updateData);
            }
            
            $insertData = array();
            $insertData['user_id']          = $userInfo['id'];
            $insertData['score_value']      = $pay_score;
            $insertData['old_value']        = $userInfo['score'];
            $insertData['log_type']         = 40;
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        }
        
        ## pay start
        if($pay_price > 0){
            
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }
            
            $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
            
            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['order_no']         = $order_no;
            $insertData['tj_hehuoren_id']   = $tjTchehuorenId;
            $insertData['order_type']       = 1;
            $insertData['user_id']          = $user_id;
            $insertData['openid']           = $userInfo['openid'];
            $insertData['tcqun_id']         = $tcqun_id;
            $insertData['pay_price']        = $pay_price;
            if($fabuPayStatus == 1){
                $insertData['fabu_days']        = $fabu_days;
                $insertData['fabu_price']       = $fabu_pay_price;
            }
            if($topPayStatus == 1){
                $insertData['top_days']         = $top_days;
                $insertData['top_price']        = $top_pay_price;
            }
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tcqun#tom_tcqun_order')->insert($insertData)){

                $insertData = array();
                $insertData['plugin_id']       = 'tom_tcqun';      
                $insertData['order_no']        = $order_no;            
                $insertData['goods_id']        = $tcqun_id;           
                $insertData['goods_name']      = $name;
                $insertData['goods_beizu']     = lang('plugin/tom_tcqun','pay_order_type_1');
                $insertData['goods_url']       = "plugin.php?id=tom_tcqun&site={$site_id}&mod=info&tcqun_id={$tcqunId}";
                $insertData['succ_back_url']   = "plugin.php?id=tom_tcqun&site={$site_id}&mod=mylist&fromlist=mylist";
                $insertData['fail_back_url']   = "plugin.php?id=tom_tcqun&site={$site_id}&mod=mylist&fromlist=mylist";
                $insertData['allow_alipay']    = 1;         
                $insertData['pay_price']       = $pay_price;    
                $insertData['order_status']    = 1;             
                $insertData['add_time']        = TIMESTAMP;     
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    $outArr = array(
                        'pay_status' => 1,
                        'status'    => 200,
                        'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                    );
                    echo json_encode($outArr); exit;
                    
                }else{
                    $outArr = array(
                        'status'=> 303,
                    );
                    echo json_encode($outArr); exit;
                }

            }else{
                $outArr = array(
                    'status'=> 304,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            
            if(!empty($tongchengConfig['template_id']) && $tcqunConfig['qun_must_shenhe'] == 1){

                if($site_id > 1){
                    $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
                    $manage_user_id = $siteInfo['manage_user_id'];
                }else{
                    $manage_user_id = $tongchengConfig['manage_user_id'];
                }

                $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($manage_user_id);
                
                $template_first = str_replace("{NAME}",$name, lang('plugin/tom_tcqun','shenhe_template_first'));
                
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($toUser['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqun&site={$site_id}&mod=managerList");
                    $smsData = array(
                        'first'         => $template_first,
                        'keyword1'      => $tcqunConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
                }

                if($tcqunConfig['qmanage_user_id'] > 0){
                    $qManageUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcqunConfig['qmanage_user_id']);

                    $access_token = $weixinClass->get_access_token();
                    if($access_token && !empty($qManageUser['openid'])){
                        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqun&site={$site_id}&mod=managerList");
                        $smsData = array(
                            'first'         => $template_first,
                            'keyword1'      => $tcqunConfig['plugin_name'],
                            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                            'remark'        => ''
                        );

                        @$r = $templateSmsClass->sendSms01($qManageUser['openid'], $tongchengConfig['template_id'], $smsData);
                    }
                }

            }
            $outArr = array(
                'status'=> 200,
            );
            echo json_encode($outArr); exit;
            
        }
        ## pay end
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "pay" && $_GET['formhash'] == FORMHASH){
    
    $tcqun_id = isset($_GET['tcqun_id'])? intval($_GET['tcqun_id']):0;
    $back_url = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
    
    $tcqunInfo = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($tcqun_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcqunInfo['user_id']); 
    
    $pay_price = 0;
    $orderInfoTmp = C::t('#tom_tcqun#tom_tcqun_order')->fetch_all_list(" AND tcqun_id={$tcqun_id} AND user_id={$userInfo['id']} AND order_type=1 AND order_status=1 ","ORDER BY id DESC",0,1);
    $orderInfo = array();
    if(is_array($orderInfoTmp) && !empty($orderInfoTmp)){
        $orderInfo = $orderInfoTmp[0];
        $pay_price = $orderInfo['pay_price'];
    }
    
    if($pay_price > 0){
        
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        
        $insertData = array();
        $insertData['site_id']          = $tcqunInfo['site_id'];
        $insertData['order_no']         = $order_no;
        $insertData['tj_hehuoren_id']   = $tjTchehuorenId;
        $insertData['order_type']       = 1;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['tcqun_id']         = $tcqun_id;
        $insertData['pay_price']        = $pay_price;
        $insertData['fabu_days']        = $orderInfo['fabu_days'];
        $insertData['fabu_price']       = $orderInfo['fabu_price'];
        $insertData['top_days']         = $orderInfo['top_days'];
        $insertData['top_price']        = $orderInfo['top_price'];
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcqun#tom_tcqun_order')->insert($insertData)){
            
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcqun';      
            $insertData['order_no']        = $order_no;            
            $insertData['goods_id']        = $tcqun_id;           
            $insertData['goods_name']      = $tcqunInfo['name'];
            $insertData['goods_beizu']     = lang('plugin/tom_tcqun','pay_order_type_1');
            $insertData['goods_url']       = "plugin.php?id=tom_tcqun&site={$site_id}&mod=info&tcqun_id={$tcqun_id}";
            $insertData['succ_back_url']   = $back_url;
            $insertData['fail_back_url']   = $back_url;
            $insertData['allow_alipay']    = 1;         
            $insertData['pay_price']       = $pay_price;    
            $insertData['order_status']    = 1;             
            $insertData['add_time']        = TIMESTAMP;     
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'pay_status' => 1,
                    'status'    => 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
                
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }
            
        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }
    
    }else{
        $outArr = array(
            'status'=> 400,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($act == "top_pay" && $_GET['formhash'] == FORMHASH){
    
    $tcqun_id   = isset($_GET['tcqun_id'])? intval($_GET['tcqun_id']):0;
    $top_days   = isset($_GET['top_days'])? intval($_GET['top_days']):0;
    $back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
    
    $tcqunInfo = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($tcqun_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcqunInfo['user_id']);
    
    if($tcqunInfo['expire_time'] < TIMESTAMP){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    $pay_price = 0;
    $qun_top_list_str = str_replace("\r\n","{n}",$tcqunConfig['qun_top_list']); 
    $qun_top_list_str = str_replace("\n","{n}",$qun_top_list_str);
    $qun_top_list_arr = explode("{n}", $qun_top_list_str);
    if(is_array($qun_top_list_arr) && !empty($qun_top_list_arr)){
        foreach ($qun_top_list_arr as $key => $value){
            $qunTopInfoTmp = array();
            $qunTopInfoTmp = explode("|", $value);

            if($qunTopInfoTmp[0] == $top_days){
                $pay_price = $qunTopInfoTmp[1];
            }
        }
    }
    
    if($pay_price > 0){ }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $topPayStatus = 1;
    $pay_score = 0;
    if($tcqunConfig['open_top_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
        $top_pay_score = ceil($pay_price * $tongchengConfig['pay_score_yuan']);
        if($top_pay_score > 0 && $userInfo['score'] >= $top_pay_score){
            $pay_score = $top_pay_score;
            $topPayStatus = 2;
        }
    }
    
    if($topPayStatus == 1){
        
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        
        $insertData = array();  
        $insertData['site_id']          = $tcqunInfo['site_id'];
        $insertData['order_no']         = $order_no;
        $insertData['tj_hehuoren_id']   = $tjTchehuorenId;
        $insertData['order_type']       = 3;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['tcqun_id']         = $tcqun_id;
        $insertData['pay_price']        = $pay_price;
        $insertData['top_days']         = $top_days;
        $insertData['top_price']        = $pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcqun#tom_tcqun_order')->insert($insertData)){

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcqun';
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $tcqun_id;
            $insertData['goods_name']      = $tcqunInfo['name'];
            $insertData['goods_beizu']     = lang('plugin/tom_tcqun','pay_order_type_3');
            $insertData['goods_url']       = "plugin.php?id=tom_tcqun&site={$site_id}&mod=info&tcqun_id={$tcqun_id}";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tcqun&site={$site_id}&mod=buytop&tcqun_id={$tcqun_id}&back_url=".urlencode($back_url);
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcqun&site={$site_id}&mod=buytop&tcqun_id={$tcqun_id}&back_url=".urlencode($back_url);
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'pay_status' => 1,
                    'status'    => 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }

    }else if($topPayStatus == 2){
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
        
        if($tcqunInfo['top_status'] == 1 && $tcqunInfo['top_time'] > TIMESTAMP){
            $top_time = $tcqunInfo['top_time'] + $top_days*86400;
        }else{
            $top_time = TIMESTAMP + $top_days*86400;
        }
        
        $updateData = array();
        $updateData['top_status'] = 1;
        $updateData['top_time']   = $top_time;
        C::t('#tom_tcqun#tom_tcqun')->update($tcqun_id,$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 41;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        $outArr = array(
            'pay_status' => 0,
            'status'    => 200,
        );
        echo json_encode($outArr); exit;
    }
    
    $outArr = array(
        'status'=> 1,
    );
    echo json_encode($outArr); exit;
    
}else if($act == "xufei_pay" && $_GET['formhash'] == FORMHASH){
    
    $tcqun_id   = isset($_GET['tcqun_id'])? intval($_GET['tcqun_id']):0;
    $fabu_days  = isset($_GET['fabu_days'])? intval($_GET['fabu_days']):0;
    $back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
    
    $tcqunInfo = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($tcqun_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcqunInfo['user_id']);
    
    $pay_price = 0;
    $qun_fabu_list_str = str_replace("\r\n","{n}",$tcqunConfig['qun_fabu_list']); 
    $qun_fabu_list_str = str_replace("\n","{n}",$qun_fabu_list_str);
    $qun_fabu_list_arr = explode("{n}", $qun_fabu_list_str);
    if(is_array($qun_fabu_list_arr) && !empty($qun_fabu_list_arr)){
        foreach ($qun_fabu_list_arr as $key => $value){
            $qunFabuInfoTmp = array();
            $qunFabuInfoTmp = explode("|", $value);

            if($qunFabuInfoTmp[0] == $fabu_days){
                $pay_price = $qunFabuInfoTmp[1];
            }
        }
    }
    
    if($pay_price > 0){ }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $xufeiPayStatus = 1;
    $pay_score = 0;
    if($tcqunConfig['open_xufei_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
        $fabu_pay_score = ceil($pay_price * $tongchengConfig['pay_score_yuan']);
        if($fabu_pay_score > 0 && $userInfo['score'] >= $fabu_pay_score){
            $pay_score = $fabu_pay_score;
            $xufeiPayStatus = 2;
        }
    }
    
    if($xufeiPayStatus == 1){
        
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        
        $insertData = array();
        $insertData['site_id']          = $tcqunInfo['site_id'];
        $insertData['order_no']         = $order_no;
        $insertData['tj_hehuoren_id']   = $tjTchehuorenId;
        $insertData['order_type']       = 2;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['tcqun_id']         = $tcqun_id;
        $insertData['pay_price']        = $pay_price;
        $insertData['fabu_days']        = $fabu_days;
        $insertData['fabu_price']       = $pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcqun#tom_tcqun_order')->insert($insertData)){

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcqun';
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $tcqun_id;
            $insertData['goods_name']      = $tcqunInfo['name'];
            $insertData['goods_beizu']     = lang('plugin/tom_tcqun','pay_order_type_2');
            $insertData['goods_url']       = "plugin.php?id=tom_tcqun&site={$site_id}&mod=info&tcqun_id={$tcqun_id}";
            $insertData['succ_back_url']   = "plugin.php?id=tom_tcqun&site={$site_id}&mod=buyxufei&tcqun_id={$tcqun_id}&back_url=".urlencode($back_url);
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcqun&site={$site_id}&mod=buyxufei&tcqun_id={$tcqun_id}&back_url=".urlencode($back_url);
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'pay_status' => 1,
                    'status'    => 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }

    }else if($xufeiPayStatus == 2){
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);
        
        if($tcqunInfo['expire_status'] == 1 && $tcqunInfo['expire_time'] > TIMESTAMP){
            $expire_time = $tcqunInfo['expire_time'] + $fabu_days*86400;
        }else{
            $expire_time = TIMESTAMP + $fabu_days*86400;
        }
        
        $updateData = array();
        $updateData['expire_status'] = 1;
        $updateData['expire_time']   = $expire_time;
        C::t('#tom_tcqun#tom_tcqun')->update($tcqun_id,$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 42;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        $outArr = array(
            'pay_status' => 0,
            'status'    => 200,
        );
        echo json_encode($outArr); exit;
    }
    
    $outArr = array(
        'status'=> 1,
    );
    echo json_encode($outArr); exit;
    
}else if($act == "refresh_pay" && $_GET['formhash'] == FORMHASH){
    
    $tcqun_id   = isset($_GET['tcqun_id'])? intval($_GET['tcqun_id']):0;
    $back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
    
    $tcqunInfo = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($tcqun_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcqunInfo['user_id']);
    
    $pay_price = $tcqunConfig["qun_refresh_price"];
    
    if($pay_price > 0){ }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $refreshPayStatus = 1;
    $pay_score = 0;
    if($tcqunConfig['open_refresh_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
        $refreshPayScore =  ceil($tcqunConfig["qun_refresh_price"] * $tongchengConfig['pay_score_yuan']);
        if($refreshPayScore > 0 && $userInfo['score'] >= $refreshPayScore){
            $refreshPayStatus = 2;
            $pay_score = $refreshPayScore;
        }
    }
    
    if($refreshPayStatus == 1){
        
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
            $outArr = array(
                'status'=> 302,
            );
            echo json_encode($outArr); exit;
        }
        
        $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
        
        $insertData = array();
        $insertData['site_id']          = $tcqunInfo['site_id'];
        $insertData['order_no']         = $order_no;
        $insertData['tj_hehuoren_id']   = $tjTchehuorenId;
        $insertData['order_type']       = 4;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['tcqun_id']         = $tcqun_id;
        $insertData['pay_price']        = $pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcqun#tom_tcqun_order')->insert($insertData)){

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcqun';
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $tcqun_id;
            $insertData['goods_name']      = $tcqunInfo['name'];
            $insertData['goods_beizu']     = lang('plugin/tom_tcqun','pay_order_type_4');
            $insertData['goods_url']       = "plugin.php?id=tom_tcqun&site={$site_id}&mod=info&tcqun_id={$tcqun_id}";
            $insertData['succ_back_url']   = $back_url;
            $insertData['fail_back_url']   = $back_url;
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'pay_status' => 1,
                    'status'    => 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            $outArr = array(
                'status'=> 304,
            );
            echo json_encode($outArr); exit;
        }

    }else if($refreshPayStatus == 2){
            
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);


        $updateData = array();
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tcqun#tom_tcqun')->update($tcqun_id,$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 43;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        $outArr = array(
            'pay_status' => 0,
            'status'    => 200,
        );
        echo json_encode($outArr); exit;
    }
    
    $outArr = array(
        'status'=> 1,
    );
    echo json_encode($outArr); exit;
}else if($act == "addpay" && $_GET['formhash'] == FORMHASH){
    
    $tcqun_id   = isset($_GET['tcqun_id'])? intval($_GET['tcqun_id']):0;
    $user_id    = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    
    $tcqunInfo = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($tcqun_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    $pay_price = $tcqunInfo["addpay_price"];
    
    if($pay_price > 0){ }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    
        
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }

    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

    $insertData = array();
    $insertData['site_id']          = $tcqunInfo['site_id'];
    $insertData['order_no']         = $order_no;
    $insertData['tj_hehuoren_id']   = $tjTchehuorenId;
    $insertData['order_type']       = 5;
    $insertData['user_id']          = $userInfo['id'];
    $insertData['openid']           = $userInfo['openid'];
    $insertData['tcqun_id']         = $tcqun_id;
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcqun#tom_tcqun_order')->insert($insertData)){

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tcqun';
        $insertData['order_no']        = $order_no;
        $insertData['goods_id']        = $tcqun_id;
        $insertData['goods_name']      = $tcqunInfo['name'];
        $insertData['goods_beizu']     = lang('plugin/tom_tcqun','pay_order_type_5');
        $insertData['goods_url']       = "plugin.php?id=tom_tcqun&site={$site_id}&mod=info&tcqun_id={$tcqun_id}";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tcqun&site={$site_id}&mod=info&tcqun_id={$tcqun_id}";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tcqun&site={$site_id}&mod=info&tcqun_id={$tcqun_id}";
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $pay_price;
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'    => 200,
                'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }

    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }

    
    $outArr = array(
        'status'=> 1,
    );
    echo json_encode($outArr); exit;
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}