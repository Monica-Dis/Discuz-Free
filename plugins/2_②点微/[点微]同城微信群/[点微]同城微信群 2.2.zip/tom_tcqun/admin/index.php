<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=index';
$modListUrl = $adminListUrl.'&tmod=index';
$modFromUrl = $adminFromUrl.'&tmod=index';

$get_list_url_value = get_list_url("tom_tcqun_admin_index_list");
if($get_list_url_value){
    $modListUrl = $get_list_url_value;
}

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time']             = TIMESTAMP;
        $insertData['refresh_time']         = TIMESTAMP;
        $insertData['update_time']          = TIMESTAMP;
        $insertData['qrcode_update_time']   = TIMESTAMP;
        $insertData['shenhe_status']        = 1;
        $insertData['pay_status']           = 0;
        C::t('#tom_tcqun#tom_tcqun')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
        
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader();
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['act'] == 'edit'){
    $info = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $data = __get_post_data($info);
        
        $updateData = array();
        $updateData = $data;
        $updateData['update_time'] = TIMESTAMP;
        $updateData['refresh_time'] = TIMESTAMP;
        if($data['qrcode'] != $info['qrcode']){
            $updateData['qrcode_update_time'] = TIMESTAMP;
        }
        C::t('#tom_tcqun#tom_tcqun')->update($info['id'],$updateData);
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        __create_info_html($info);
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['status']            = 1;
    $updateData['shenhe_status']     = 1;
    C::t('#tom_tcqun#tom_tcqun')->update($_GET['id'],$updateData);
    
    $tcqunInfo = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcqunInfo['user_id']);

    $shenhe = str_replace('{NAME}', $tcqunInfo['name'], $Lang['template_tcqun_shenhe_ok']);

    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqun&site={$tcqunInfo['site_id']}&mod=info&tcqun_id=".$tcqunInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcqunConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $cpmsg = $Lang['tcqun_shenhe_tz_succ'];
        }else{
            $cpmsg = $Lang['tcqun_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcqunConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $tcqunInfo = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcqunInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcqun#tom_tcqun')->update($_GET['id'],$updateData);
        
        $shenhe = str_replace('{NAME}', $tcqunInfo['name'], $Lang['template_tcqun_shenhe_no']);
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqun&site={$tcqunInfo['site_id']}&mod=mylist");
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcqunConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
                $cpmsg = $Lang['tcqun_shenhe_tz_succ'];
            }else{
                $cpmsg = $Lang['tcqun_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcqunConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tcqun_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader();
        tomshowsetting(true,array('title'=>$Lang['tcqun_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcqun_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tcqun#tom_tcqun')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status']     = 0;
    C::t('#tom_tcqun#tom_tcqun')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcqun#tom_tcqun')->delete_by_id($_GET['id']);
    C::t('#tom_tcqun#tom_tcqun_photo')->delete_by_tcqun_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'pay'){
    
    $pay_status = isset($_GET['pay_status'])? intval($_GET['pay_status']):1;
    
    $updateData = array();
    $updateData['pay_status'] = $pay_status;
    C::t('#tom_tcqun#tom_tcqun')->update($_GET['id'],$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'edit_top'){
    
    $info = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $top_time     = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
        $top_time     = strtotime($top_time);
        $updateData = array();
        if($top_time < TIMESTAMP){
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
        }else{
            $updateData['top_status']   = 1;
            $updateData['top_time']     = $top_time;
        }
        C::t('#tom_tcqun#tom_tcqun')->update($_GET['id'],$updateData);
    
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edit_top&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['index_edit_top'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['index_top_time'],'name'=>'top_time','value'=>$info['top_time'],'msg'=>$Lang['index_top_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'edit_expire'){
    
    $info = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $expire_time = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
        $expire_time = strtotime($expire_time);
        $updateData = array();
        if($expire_time < TIMESTAMP){
            $updateData['expire_status']   = 2;
            $updateData['expire_time']     = 0;
        }else{
            $updateData['expire_status']   = 1;
            $updateData['expire_time']     = $expire_time;
        }
        C::t('#tom_tcqun#tom_tcqun')->update($_GET['id'],$updateData);
    
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edit_expire&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' . $Lang['index_edit_expire'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['index_expire_time'],'name'=>'expire_time','value'=>$info['expire_time'],'msg'=>$Lang['index_expire_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refresh'){
    
    $updateData = array();
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tcqun#tom_tcqun')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['act'] == 'photo'){
    
    if(submitcheck('submit')){
        
        $id             = isset($_GET['id'])? intval($_GET['id']):0;
        $psort          = isset($_GET['psort'])? intval($_GET['psort']):10;
        $picurl         = tomuploadFile("picurl");
        
        $insertData = array();
        $insertData['tcqun_id']         = $id;
        $insertData['picurl']           = $picurl;
        $insertData['psort']            = $psort;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#tom_tcqun#tom_tcqun_photo')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl.'&act=photo&id='.$id, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        tomshownavheader();
        tomshownavli($Lang['index_photo_add'],'',true);
        tomshownavfooter();
        showformheader($modFromUrl.'&act=photo&id='.$_GET['id'],'enctype');
        showtableheader();
        
        tomshowsetting(true,array('title'=>$Lang['index_photo'],'name'=>'picurl','value'=>'','msg'=>$Lang['index_photo_msg']),"file");
        tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'psort','value'=>10,'msg'=>$Lang['sort_msg']),"input");
        
        showsubmit('submit', 'submit');
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }
    
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $id         = intval($_GET['id'])>0? intval($_GET['id']):0;
    
    $pagesize = 20;
    $start = ($page-1)*$pagesize;	
    $tcqunInfo = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($id);
    $count = C::t('#tom_tcqun#tom_tcqun_photo')->fetch_all_count(" AND tcqun_id = {$id} ");
    $photoList = C::t('#tom_tcqun#tom_tcqun_photo')->fetch_all_list(" AND tcqun_id = {$id} "," ORDER BY psort ASC,id ASC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&act=photo&site_id={$site_id}";
    showtableheader();
    echo '<tr><th colspan="15" class="partition">' .$tcqunInfo['name'].'&gt;'. $Lang['index_photo_title'] . '</th></tr>';
    showtablefooter();/*Dism��taobao��com*/
    showtableheader();
    echo '<tr class="header">';
    echo '<th> ID </th>';
    echo '<th>' . $Lang['index_photo'] . '</th>';
    echo '<th>' . $Lang['index_paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($photoList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a href="' . tomgetfileurl($value['picurl']) . '" target="_blank"><img height="40" src="' . tomgetfileurl($value['picurl']) . '"></a></td>';
        echo '<td>' . $value['psort'] . '</td>';
        echo '<td>';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&tcqun_id='.$id.'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tcqun#tom_tcqun_photo')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl.'&act=photo&id='.$_GET['tcqun_id'], 'succeed');
    
}else{
    
    set_list_url("tom_tcqun_admin_index_list");
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ list-style-type: none; height: 25px; line-height: 25px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;padding: 3px 10px;color: #6a6d6a; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
</style>
EOF;
    echo $csstr;
    
    $search             = intval($_GET['search'])>0? intval($_GET['search']):0;
    $keyword            = isset($_GET['keyword'])? addslashes($_GET['keyword']):'';
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $tcqun_id           = isset($_GET['tcqun_id'])? intval($_GET['tcqun_id']):0;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $pay_status         = isset($_GET['pay_status'])? intval($_GET['pay_status']):0;
    $top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $expire_status      = isset($_GET['expire_status'])? intval($_GET['expire_status']):0;
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($keyword)){
        $keyword = str_replace(array('%', '_'),'',$keyword);
        $where .= " AND (name LIKE '%{$keyword}%' OR content LIKE '%{$keyword}%')";
    }
    if(!empty($tcqun_id)){
        $where.= " AND id={$tcqun_id} ";
    }
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($cate_id)){
        $where.= " AND cate_id={$cate_id} ";
    }
    if(!empty($status)){
        if($status == 1){
            $where.= " AND status=1 ";
        }else if($status == 2){
            $where.= " AND status != 1 ";
        }
    }
    if(!empty($pay_status)){
        $where.= " AND pay_status={$pay_status} ";
    }
    if($top_status > 0){
        if($top_status == 1){
            $where.= " AND top_status=1 ";
        }else if($top_status == 2){
            $where.= " AND top_status != 1 ";
        }
    }
    if(!empty($expire_status)){
        $where.= " AND expire_status={$expire_status} ";
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    
    $order = "ORDER BY add_time DESC,id DESC";
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $count      = C::t('#tom_tcqun#tom_tcqun')->fetch_all_count($where);
    $tcqunList  = C::t('#tom_tcqun#tom_tcqun')->fetch_all_list($where,$order,$start,$pagesize);

    showtableheader();
    $Lang['index_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_1']);
    $Lang['index_help_2']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['index_help_2']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['index_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['index_help_1'] . '</li>';
    echo '<li>' . $Lang['index_help_2'] . '</li>';
    echo '</ul></td></tr>';
    showtablefooter();/*Dism��taobao��com*/
    
    $modBasePageUrl = $modBaseUrl."&keyword={$keyword}&site_id={$site_id}&tcqun_id={$tcqun_id}&cate_id={$cate_id}&status={$status}&top_status={$top_status}&pay_status={$pay_status}&expire_status={$expire_status}&shenhe_status={$shenhe_status}&search={$search}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader();
    
    $site_1 = '';
    if($site_id == 1){
        $site_1 = 'selected';
    }
    echo '<tr><th colspan="15" class="partition">' . $Lang['search_title'] . '(<a href="'.$modBaseUrl.'&search=1"><font color="#F90B0B">' . $Lang['gaoji_search'] . '</font></a>)</th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    echo '<input type="hidden" name="search" value="'.$search.'">';
    
    $keywordStr = '<tr><td width="100" align="right"><b>'.$Lang['search_keyword'].'</b></td>';
    $keywordStr.= '<td><input style="width:260px" type="text" value="'.$keyword.'" name="keyword"></td></tr>';
    echo $keywordStr;
    
    $qunIdStr = '<tr><td width="100" align="right"><b>'.$Lang['index_search_qun_id'].'</b></td>';
    $qunIdStr.= '<td><input style="width:260px" type="text" value="'.$tcqun_id.'" name="tcqun_id"></td></tr>';
    echo $qunIdStr;
    
    if($search == 1){
        $cateList   = C::t('#tom_tcqun#tom_tcqun_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ");
        $cateStr = '<tr><td width="100" align="right"><b>'.$Lang['index_search_cate'].'</b></td>';
        $cateStr.= '<td ><select style="width: 260px;" name="cate_id" id="cate_id">';
        $cateStr.=  '<option value="0">'.$Lang['all'].'</option>';
        foreach ($cateList as $key => $value){
            if($cate_id == $value['id']){
                $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $cateStr.= '</select></td></tr>';
        echo $cateStr;

        $status_1 = $status_2 = '';
        if($status == 1){
            $status_1 = 'selected';
        }else if($status == 2){
            $status_2 = 'selected';
        }
        $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['status'].'</b></td>';
        $statusStr.= '<td><select style="width: 260px;" name="status" id="status">';
        $statusStr.=  '<option value="0">'.$Lang['all'].'</option>';
        $statusStr.=  '<option value="1" '.$status_1.'>'.$Lang['status_1'].'</option>';
        $statusStr.=  '<option value="2" '.$status_2.'>'.$Lang['status_0'].'</option>';
        $statusStr.= '</select></td></tr>';
        echo $statusStr;

        $top_status_1 = $top_status_2 = '';
        if($top_status == 1){
            $top_status_1 = 'selected';
        }else if($top_status == 2){
            $top_status_2 = 'selected';
        }
        $topStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['top_status'].'</b></td>';
        $topStatusStr.= '<td><select style="width: 260px;" name="top_status" id="top_status">';
        $topStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
        $topStatusStr.=  '<option value="1" '.$top_status_1.'>'.$Lang['top_status_1'].'</option>';
        $topStatusStr.=  '<option value="2" '.$top_status_2.'>'.$Lang['top_status_0'].'</option>';
        $topStatusStr.= '</select></td></tr>';
        echo $topStatusStr;

        $pay_status_1 = $pay_status_2 = '';
        if($pay_status == 1){
            $pay_status_1 = 'selected';
        }else if($pay_status == 2){
            $pay_status_2 = 'selected';
        }
        $payStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['pay_status'].'</b></td>';
        $payStatusStr.= '<td><select style="width: 260px;" name="pay_status" id="pay_status">';
        $payStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
        $payStatusStr.=  '<option value="1" '.$pay_status_1.'>'.$Lang['pay_status_1'].'</option>';
        $payStatusStr.=  '<option value="2" '.$pay_status_2.'>'.$Lang['pay_status_2'].'</option>';
        $payStatusStr.= '</select></td></tr>';
        echo $payStatusStr;

        $expire_status_1 = $expire_status_2 = '';
        if($expire_status == 1){
            $expire_status_1 = 'selected';
        }else if($expire_status == 2){
            $expire_status_2 = 'selected';
        }
        $expireStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['expire_status'].'</b></td>';
        $expireStatusStr.= '<td><select style="width: 260px;" name="expire_status" id="expire_status">';
        $expireStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
        $expireStatusStr.=  '<option value="1" '.$expire_status_1.'>'.$Lang['expire_status_1'].'</option>';
        $expireStatusStr.=  '<option value="2" '.$expire_status_2.'>'.$Lang['expire_status_2'].'</option>';
        $expireStatusStr.= '</select></td></tr>';
        echo $expireStatusStr;
    }
    
    $status_shenhe_1 = $status_shenhe_2 = $status_shenhe_3 = '';
    if($shenhe_status == 1){
        $status_shenhe_1 = 'selected';
    }else if($shenhe_status == 2){
        $status_shenhe_2 = 'selected';
    }else if($shenhe_status == 3){
        $status_shenhe_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['all'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$status_shenhe_1.'>'.$Lang['shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$status_shenhe_2.'>'.$Lang['shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$status_shenhe_3.'>'.$Lang['shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    showsubmit('submit', 'submit');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();
    
    __create_nav_html();
    showtableheader();
    echo '<tr class="header">';
    echo '<th > ID </th>';
    echo '<th style="width: 60px;">' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['index_name'] . '</th>';
    echo '<th>' . $Lang['index_user'] . '</th>';
    echo '<th>' . $Lang['index_logo'] . '</th>';
    echo '<th>' . $Lang['index_qrcode'] . '</th>';
    echo '<th>' . $Lang['index_qunzhu_qrcode'] . '</th>';
    echo '<th>' . $Lang['index_cate'] . '</th>';
    echo '<th>' . $Lang['clicks'] . '</th>';
    echo '<th>' . $Lang['status'] . '</th>';
    echo '<th>' . $Lang['refresh_time'] . '</th>';
    echo '<th style="width: 100px;">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($tcqunList as $key => $value) {
        
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $cateInfo = C::t('#tom_tcqun#tom_tcqun_cate')->fetch_by_id($value['cate_id']);
        
        $qunQrcodeEndTime = 7 * 86400 + $value['qrcode_update_time'] - 3600;
        
        echo '<tr style="border-bottom-width: 1px; border-bottom-style: solid; border-bottom-color: #70b4e6;">';
        echo '<td>' . $value['id'] . '</td>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $userInfo['nickname'] .'<font color=#f00"">(ID:'.$value['user_id']. ')</font></td>';
        echo '<td><a href="'.tomgetfileurl($value['logo']).'" target="_blank"><img src="'.tomgetfileurl($value['logo']).'" width="40" /></a></td>';
        echo '<td><a href="'.tomgetfileurl($value['qrcode']).'" target="_blank"><img src="'.tomgetfileurl($value['qrcode']).'" width="40" /></a><br/><font color="#f00">('.dgmdate($qunQrcodeEndTime, 'Y-m-d H:i',$tomSysOffset).$Lang['index_qunzhu_qrcode_end_msg'].')</font></td>';
        echo '<td><a href="'.tomgetfileurl($value['qunzhu_qrcode']).'" target="_blank"><img src="'.tomgetfileurl($value['qunzhu_qrcode']).'" width="40" /></a></td>';
        echo '<td>' . $cateInfo['name'] . '</td>';
        echo '<td>' . $value['clicks'] . '</td>';
        echo '<td style="line-height: 25px;">';
        if($value['status'] == 1 ){
            echo '<b>'.$Lang['status'] .':</b>&nbsp;&nbsp;<font color="#0a9409">'.$Lang['status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['status_0']. ')</font></a><br/>';
        }else{
            echo '<b>'.$Lang['status'] .':</b>&nbsp;&nbsp;<font color="#f70404">'.$Lang['status_0'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['status_1']. ')</font></a><br/>';
        }
        if($value['top_status'] == 1){
            echo '<b>'.$Lang['top_status'] .':</b>&nbsp;&nbsp;<font color="#0a9409">'.$Lang['top_status_1'].'</font> <font color="#f70404">('.dgmdate($value['top_time'], 'Y-m-d H:i',$tomSysOffset).')</font><br/>';
        }else{
            echo '<b>'.$Lang['top_status'] .':</b>&nbsp;&nbsp;<font color="#f70404">'.$Lang['top_status_0'].'</font><br/>';
        }
        $payBtnStr = '&nbsp;(&nbsp;<a href="javascript:;" onclick="pay_confirm(\''.$modBaseUrl.'&act=pay&id='.$value['id'].'&pay_status=1&formhash='.FORMHASH.'\', \''.$Lang['index_pay_status_1_msg'].'\');">' . $Lang['pay_status_1']. '</a>&nbsp;|&nbsp;<a href="javascript:;" onclick="pay_confirm(\''.$modBaseUrl.'&act=pay&id='.$value['id'].'&pay_status=2&formhash='.FORMHASH.'\', \''.$Lang['index_pay_status_2_msg'].'\');">' . $Lang['pay_status_2']. '</a>)';
        if($value['pay_status'] == 1){
            echo '<b>'.$Lang['pay_status'] .':</b>&nbsp;&nbsp;<font color="#f00">' . $Lang['pay_status_1'] . $payBtnStr . '</font><br/>';
        }else if($value['pay_status'] == 2){
            echo '<b>'.$Lang['pay_status'] .':</b>&nbsp;&nbsp;<font color="#0a9409">' . $Lang['pay_status_2'] . $payBtnStr . '</font><br/>';
        }else{
            echo '<b>'.$Lang['pay_status'] .':</b>&nbsp;&nbsp;<font color="#0a9409"> -- </font><br/>';
        }
        
        if($value['expire_status'] == 1){
            echo '<b>'.$Lang['expire_status'] .':</b>&nbsp;&nbsp;<font color="#0a9409">'.$Lang['expire_status_1'].'</font><font color="#f70404">('.dgmdate($value['expire_time'], 'Y-m-d H:i',$tomSysOffset).')</font><br/>';
        }else if($value['expire_status'] == 2){
            echo '<b>'.$Lang['expire_status'] .':</b>&nbsp;&nbsp;<font color="#f70404">'.$Lang['expire_status_2'].'</font><br/>';
        }else{
            echo '<b>'.$Lang['expire_status'] .':</b>&nbsp;&nbsp; -- <br/>';
        }
        
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_status_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_status_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<b>'.$Lang['shenhe_status'] .':</b>&nbsp;&nbsp;<font color="#0a9409">' . $Lang['shenhe_status_1'] . '</font>'.$sheheBtnStr.'<br/>';
        }else if($value['shenhe_status'] == 2){
            echo '<b>'.$Lang['shenhe_status'] .':</b>&nbsp;&nbsp;<font color="#f70404">' . $Lang['shenhe_status_2'] . '</font>'.$sheheBtnStr.'<br/>';
        }else if($value['shenhe_status'] == 3){
            echo '<b>'.$Lang['shenhe_status'] .':</b>&nbsp;&nbsp;<font color="#f70404">' . $Lang['shenhe_status_3'] . '</font>'.$sheheBtnStr.'<br/>';
        }
        echo '</td>';
        echo '<td>'.dgmdate($value['refresh_time'], 'Y-m-d H:i',$tomSysOffset).'</td>';
        
        echo '<td><div class="tc_content_box_handle"><ul>';
        echo '<li><a href="'.$modBaseUrl.'&act=refresh&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['refresh']. '</a></li>';
        echo '<li><a href="'.$modBaseUrl.'&act=edit_top&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_edit_top']. '</a></li>';
        echo '<li><a href="'.$modBaseUrl.'&act=edit_expire&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_edit_expire']. '</a></li>';
        echo '<li><a href="'.$modBaseUrl.'&act=photo&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_photo_title']. '</a></li>';
        echo '<li><a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a></li>';
        echo '<li><a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a></li>';
        echo '</ul></div></td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter();/*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}

function pay_confirm(url,msg){
  var r = confirm(msg)
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
}

function __get_post_data($infoArr = array()){
    global $tcqunConfig,$tongchengConfig;
    $data = array();
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):1;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $sub_title          = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $top_time           = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
    $top_time           = strtotime($top_time);
    $expire_status      = isset($_GET['expire_status'])? intval($_GET['expire_status']):2;
    $expire_time        = isset($_GET['expire_time'])? addslashes($_GET['expire_time']):'';
    $expire_time        = strtotime($expire_time);
    $virtual_clicks     = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $sort               = isset($_GET['sort'])? intval($_GET['sort']):10000;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    
    $open_addpay        = isset($_GET['open_addpay'])? intval($_GET['open_addpay']):0;
    $addpay_price       = isset($_GET['addpay_price'])? floatval($_GET['addpay_price']):0;
    
    $kouling            = isset($_GET['kouling'])? addslashes($_GET['kouling']):'';
    $allow_distance     = isset($_GET['allow_distance'])? floatval($_GET['allow_distance']):0;

    $logo = $qrcode = $qunzhu_qrcode = "";
    if($_GET['act'] == 'add'){
        $logo           = tomuploadFile("logo");
        $qrcode         = tomuploadFile("qrcode");
        $qunzhu_qrcode  = tomuploadFile("qunzhu_qrcode");
    }else if($_GET['act'] == 'edit'){
        $logo           = tomuploadFile("logo",$infoArr['logo']);
        $qrcode         = tomuploadFile("qrcode",$infoArr['qrcode']);
        $qunzhu_qrcode  = tomuploadFile("qunzhu_qrcode",$infoArr['qunzhu_qrcode']);
    }
    
    $city_id = 0;
    if($site_id > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $city_id = $__SitesInfo['city_id'];
            }
        }
    }else if($site_id == 1){
        if(!empty($tongchengConfig['city_id'])){
                $city_id = $tongchengConfig['city_id'];
        }
    }
    
    $data['site_id']            = $site_id;
    $data['user_id']            = $user_id;
    $data['name']               = $name;
    $data['sub_title']          = $sub_title;
    $data['cate_id']            = $cate_id;
    $data['tcshop_id']          = $tcshop_id;
    $data['city_id']            = $city_id;
    $data['area_id']            = $area_id;
    $data['street_id']          = $street_id;
    $data['logo']               = $logo;
    $data['qrcode']             = $qrcode;
    $data['qunzhu_qrcode']      = $qunzhu_qrcode;
    $data['longitude']          = $longitude;
    $data['latitude']           = $latitude;
    $data['address']            = $address;
    $data['open_addpay']        = $open_addpay;
    $data['addpay_price']       = $addpay_price;
    $data['kouling']            = $kouling;
    $data['allow_distance']     = $allow_distance;
    $data['status']             = $status;
    if($top_status == 1 && $top_time > TIMESTAMP){
        $data['top_status']         = 1;
        $data['top_time']           = $top_time;
    }else{
        $data['top_status']         = 0;
        $data['top_time']           = 0;
    }
    if($expire_status == 1 && $expire_time > TIMESTAMP){
        $data['expire_status']      = 1;
        $data['expire_time']        = $expire_time;
    }else{
        $data['expire_status']      = 2;
        $data['expire_time']        = 0;
    }
    
    $data['virtual_clicks']     = $virtual_clicks;
    $data['content']            = $content;
    $data['sort']               = $sort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$tongchengConfig;
    $options = array(
        'site_id'           => 1,
        'user_id'           => 0,
        'name'              => '',
        'sub_title'         => '',
        'cate_id'           => 0,
        'tcshop_id'         => 0,
        'area_id'           => 0,
        'street_id'         => 0,
        'logo'              => '',
        'qrcode'            => '',
        'qunzhu_qrcode'     => '',
        'longitude'         => '',
        'latitude'          => '',
        'address'           => '',
        'open_addpay'       => '',
        'addpay_price'      => '',
        'kouling'           => '',
        'allow_distance'    => '',
        'status'            => 0,
        'top_status'        => 0,
        'top_time'          => time(),
        'expire_status'     => 1,
        'expire_time'       => time(),
        'virtual_clicks'    => 0,
        'sort'              => 10000,
        'content'           => '',
        
    );
    $options = array_merge($options, $infoArr);
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id" onchange="getCity()">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    
    tomshowsetting(true,array('title'=>$Lang['index_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['index_user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['index_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_sub_title'],'name'=>'sub_title','value'=>$options['sub_title'],'msg'=>$Lang['index_sub_title_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_tcshop_id'],'name'=>'tcshop_id','value'=>$options['tcshop_id'],'msg'=>$Lang['index_tcshop_id_msg']),"input");
    
    $cateList = C::t('#tom_tcqun#tom_tcqun_cate')->fetch_all_list("  "," ORDER BY csort ASC,id DESC ");
    $catesStr = '<tr class="header"><th>'.$Lang['index_cate_id'].'</th><th></th></tr>';
    $catesStr.= '<tr><td width="300"><select style="width: 150px;" name="cate_id" id="cate_id" ">';
    $catesStr.=  '<option value="0">'.$Lang['index_cate_id'].'</option>';
    foreach ($cateList as $key => $value){
        if($value['id'] == $options['cate_id']){
            $catesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $catesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $catesStr.= '</select></td><td>'.$Lang['index_cate_id_msg'].'</td></tr>';
    echo $catesStr;
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($options['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($options['site_id']);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
        }
    }else if($options['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
    $areaStr.= '<tr><td width="100" ><b>'.$Lang['index_quyu'].'</b></td></tr>';
    $areaStr.= '<tr><td ><select style="width: 130px;" name="area_id" id="area_id" onChange="getStreet();">';
    $areaStr.=  '<option value="0">'.$Lang['index_quyu'].'</option>';
    foreach ($areaList as $key => $value){
        if($options['area_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select>';

    $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($options['area_id']);
    $areaStr.= '<select style="width: 130px;" name="street_id" id="street_id">';
    $areaStr.=  '<option value="0">'.$Lang['index_quyu'].'</option>';
    foreach ($streetList as $key => $value){
        if($options['street_id'] == $value['id']){
            $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $areaStr.= '</select></td><td>'.$Lang['index_quyu_msg'].'</td></tr>';
    echo $areaStr;
    
    tomshowsetting(true,array('title'=>$Lang['index_logo'],'name'=>'logo','value'=>$options['logo'],'msg'=>$Lang['index_logo_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_qrcode'],'name'=>'qrcode','value'=>$options['qrcode'],'msg'=>$Lang['index_qrcode_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_qunzhu_qrcode'],'name'=>'qunzhu_qrcode','value'=>$options['qunzhu_qrcode'],'msg'=>$Lang['index_qunzhu_qrcode_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_longitude'],'name'=>'longitude','value'=>$options['longitude'],'msg'=>$Lang['index_longitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_latitude'],'name'=>'latitude','value'=>$options['latitude'],'msg'=>$Lang['index_latitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['index_address_msg']),"input");
    
    $open_addpay_item = array(0=>$Lang['index_open_addpay_0'], 1=>$Lang['index_open_addpay_1']);
    tomshowsetting(true,array('title'=>$Lang['index_open_addpay'],'name'=>'open_addpay','value'=>$options['open_addpay'],'msg'=>$Lang['index_open_addpay_msg'],'item'=>$open_addpay_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_addpay_price'],'name'=>'addpay_price','value'=>$options['addpay_price'],'msg'=>$Lang['index_addpay_price_msg']),"input");
    
    tomshowsetting(true,array('title'=>$Lang['index_kouling'],'name'=>'kouling','value'=>$options['kouling'],'msg'=>$Lang['index_kouling_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_allow_distance'],'name'=>'allow_distance','value'=>$options['allow_distance'],'msg'=>$Lang['index_allow_distance_msg']),"input");
    
    $status_item = array(1=>$Lang['status_1'], 0=>$Lang['status_0']);
    tomshowsetting(true,array('title'=>$Lang['status'],'name'=>'status','value'=>$options['status'],'msg'=>$Lang['status_msg'],'item'=>$status_item),"radio");
    $top_status_item = array(1=>$Lang['top_status_1'], 0=>$Lang['top_status_0']);
    tomshowsetting(true,array('title'=>$Lang['top_status'],'name'=>'top_status','value'=>$options['top_status'],'msg'=>$Lang['top_status_msg'],'item'=>$top_status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_top_time'],'name'=>'top_time','value'=>$options['top_time'],'msg'=>$Lang['index_top_time_msg']),"calendar");
    $expire_status_item = array(1=>$Lang['expire_status_1'], 2=>$Lang['expire_status_2']);
    tomshowsetting(true,array('title'=>$Lang['expire_status'],'name'=>'expire_status','value'=>$options['expire_status'],'msg'=>$Lang['expire_status_msg'],'item'=>$expire_status_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_expire_time'],'name'=>'expire_time','value'=>$options['expire_time'],'msg'=>$Lang['index_expire_time_msg']),"calendar");
    tomshowsetting(true,array('title'=>$Lang['index_virtual_clicks'],'name'=>'virtual_clicks','value'=>$options['virtual_clicks'],'msg'=>$Lang['index_virtual_clicks_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['sort'],'name'=>'sort','value'=>$options['sort'],'msg'=>$Lang['sort_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['index_content_msg']),"text");
    
    return;
}

$jsstr = <<<EOF
<script type="text/javascript">
function getCity(){
  var site_id = jq("#site_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcqun:ajax",
        data: "act=admin_area&site="+site_id,
        dataType : "json",
        success: function(json){
            var areaHtml = '<option value="0">{$Lang['index_quyu']}</option>';
            jq.each(json,function(k,v){
                areaHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#area_id").html(areaHtml);
            jq("#area_id").show();
        }
    });
}
function getStreet(){
  var area_id = jq("#area_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcqun:ajax",
        data: "act=admin_street&area_id="+area_id,
        dataType : "json",
        success: function(json){
            var streetHtml = '<option value="0">{$Lang['index_quyu']}</option>';
            jq.each(json,function(k,v){
                streetHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            console.log(streetHtml);
            jq("#street_id").html(streetHtml);
            jq("#street_id").show();
        }
    });
}
</script>
EOF;
echo $jsstr;

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['edit'],"",true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}