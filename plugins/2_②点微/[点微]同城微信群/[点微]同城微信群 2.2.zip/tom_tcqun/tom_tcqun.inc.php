<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcqunConfig = $_G['cache']['plugin']['tom_tcqun'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = '20200421';
if (!file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/tom_tongcheng.inc.php')) {
	echo '<a href="https://addon.discuz.com/?@tom_tongcheng.plugin">https://addon.discuz.com/?@tom_tongcheng.plugin</a>';
	exit(0);
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tcqun/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcqunConfig['wx_share_title'];
$shareDesc = $tcqunConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqun&site=' . $site_id . '&mod=index');
$shareLogo = $tcqunConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
$tcadminConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcadmin/tom_tcadmin.inc.php')) {
	$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
$__ShowTcshop = 0;
$tcshopConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcshop/tom_tcshop.inc.php')) {
	$tcshopConfig = $_G['cache']['plugin']['tom_tcshop'];
	if ($tcshopConfig['open_tcshop'] == 1) {
		$__ShowTcshop = 1;
	}
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
$ajaxLoadListUrl = 'plugin.php?id=tom_tcqun:ajax&site=' . $site_id . '&act=list&formhash=' . $formhash;
$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tcqun:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
$ajaxCommonClicksUrl = 'plugin.php?id=tom_tcqun:ajax&site=' . $site_id . '&act=commonClicks&formhash=' . $formhash;
$ajaxUpdateQunStatusUrl = 'plugin.php?id=tom_tcqun:ajax&site=' . $site_id . '&act=update_qun_status&formhash=' . $formhash;
$searchUrl = 'plugin.php?id=tom_tcqun:ajax&site=' . $site_id . '&act=get_search_url';
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
$__CommonInfo = C::t('#tom_tcqun#tom_tcqun_common')->fetch_by_site_id($site_id);
if (!$__CommonInfo) {
	$insertData = array();
	$insertData['site_id'] = $site_id;
	C::t('#tom_tcqun#tom_tcqun_common')->insert($insertData);
}
$__TjHehuorenId = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
if ($__ShowTchehuoren == 1) {
	if ($__UserInfo['id'] > 0) {
		$tchehuorenInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfoTmp && $tchehuorenInfoTmp['status'] == 1) {
			$__TjHehuorenId = $tchehuorenInfoTmp['id'];
			$shareUrl = $shareUrl . ('&tjid=' . $__TjHehuorenId);
		}
	}
	if ($__TjHehuorenId == 0) {
		$cookiesTjHehuorenId = getcookie('tom_tcqun_tj_hehuoren_id');
		if ($cookiesTjHehuorenId > 0) {
			$__TjHehuorenId = $cookiesTjHehuorenId;
		}
	}
	if ($__TjHehuorenId > 0) {
		dsetcookie('tom_tcqun_tj_hehuoren_id', $__TjHehuorenId, 86400);
	}
}
if ($_GET['mod'] == 'index') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqun/module/site_lbs.php';
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$commonClicks = C::t('#tom_tcqun#tom_tcqun_common')->fetch_all_sun_clicks(' AND site_id IN(' . $sql_in_site_ids . ') ');
	$clicksNum = $commonClicks + $tcqunConfig['virtual_clicks_num'];
	$clicksNumTxt = $clicksNum;
	if ($clicksNum > 10000) {
		$clicksNumTmp = $clicksNum / 10000;
		$clicksNumTxt = number_format($clicksNumTmp, 2);
	}
	$ruzhuNum = C::t('#tom_tcqun#tom_tcqun')->fetch_all_count(' AND status=1 AND site_id IN(' . $sql_in_site_ids . ') ');
	$ruzhuNum = $ruzhuNum + $tcqunConfig['virtual_ruzhu_num'];
	$ruzhuNumTxt = $ruzhuNum;
	if ($ruzhuNum > 10000) {
		$ruzhuNumTmp = $ruzhuNum / 10000;
		$ruzhuNumTxt = number_format($ruzhuNumTmp, 2);
	}
	$focuspicListTmp = C::t('#tom_tcqun#tom_tcqun_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY fsort ASC,id DESC ');
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		if ($site_id != 1) {
			$focuspicListTmp = C::t('#tom_tcqun#tom_tcqun_focuspic')->fetch_all_list(' AND site_id=1 ', ' ORDER BY fsort ASC,id DESC ');
		}
	}
	$focuspicList = $zhongFocuspicList = array();
	if (is_array($focuspicListTmp) && !empty($focuspicListTmp)) {
		foreach ($focuspicListTmp as $key => $value) {
			if ($value['type'] == 1) {
				$focuspicList[$key] = $value;
				$focuspicList[$key]['picurl'] = tomGetPicUrl($value['picurl']);
				$focuspicList[$key]['link'] = str_replace('{site}', $site_id, $value['link']);
			} elseif ($value['type'] == 2) {
				$zhongFocuspicList[$key] = $value;
				$zhongFocuspicList[$key]['picurl'] = tomGetPicUrl($value['picurl']);
				$zhongFocuspicList[$key]['link'] = str_replace('{site}', $site_id, $value['link']);
			}
		}
	}
	$focuspicCount = count($focuspicList);
	$zhongFocuspicCount = count($zhongFocuspicList);
	$cateListTmp = C::t('#tom_tcqun#tom_tcqun_cate')->fetch_all_list(' ', ' ORDER BY csort ASC,id DESC ');
	$cateList = array();
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		$i = 1;
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			$cateList[$key]['i'] = $i;
			$cateList[$key]['picurl'] = tomGetPicUrl($value['picurl']);
			$i = $i + 1;
		}
	}
	$cateCount = count($cateList);
	$indexJsFile = DISCUZ_ROOT . './source/plugin/tom_tcqun/images/index.js';
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcqun&site=' . $site_id . '&mod=index'));
	$searchUrl = 'plugin.php?id=tom_tcqun:ajax&site=' . $site_id . '&act=get_search_url';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqun:index');
	echo '<script src="source/plugin/tom_tcqun/images/index.js"></script>';
} elseif ($_GET['mod'] == 'info') {
	$tcqun_id = intval($_GET['tcqun_id']) > 0 ? intval($_GET['tcqun_id']) : 0;
	$s = intval($_GET['s']) > 0 ? intval($_GET['s']) : 0;
	$tcqunInfo = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($tcqun_id);
	if ($tcqunInfo['status'] != 1 || $tcqunInfo['shenhe_status'] != 1 || $tcqunInfo['expire_status'] != 1 || $tcqunInfo['pay_status'] == 1) {
		if ($__UserInfo['groupid'] != 1 && $__UserInfo['groupid'] != 2) {
			if ($__UserInfo['id'] != $tcqunConfig['qmanage_user_id']) {
				tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcqun&site=' . $site_id . '&mod=index'));
				exit(0);
			}
		}
	}
	$cateInfo = C::t('#tom_tcqun#tom_tcqun_cate')->fetch_by_id($tcqunInfo['cate_id']);
	if ($tcqunInfo['area_id'] > 0) {
		$areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tcqunInfo['area_id']);
		$streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tcqunInfo['street_id']);
	}
	$qrcodeEndTime = 7 * 86400 + $tcqunInfo['qrcode_update_time'] - 3600;
	$logo = tomGetPicUrl($tcqunInfo['logo']);
	if (!empty($tcqunInfo['qrcode']) && $qrcodeEndTime > TIMESTAMP) {
		$qrcode = tomGetPicUrl($tcqunInfo['qrcode']);
	} else {
		$qrcode = tomGetPicUrl($tcqunInfo['qunzhu_qrcode']);
	}
	$clicks = intval($tcqunInfo['clicks'] + $tcqunInfo['virtual_clicks']);
	$content = stripslashes($tcqunInfo['content']);
	$photoListTmp = C::t('#tom_tcqun#tom_tcqun_photo')->fetch_all_list(' AND tcqun_id = ' . $tcqunInfo['id'] . ' ', ' ORDER BY psort ASC,id ASC ');
	$photoList = array();
	if (is_array($photoListTmp) && !empty($photoListTmp)) {
		foreach ($photoListTmp as $key => $value) {
			$photoList[] = tomGetPicUrl($value['picurl']);
		}
	}
	$photoCount = count($photoList);
	$photoListStr = implode('|', $photoList);
	$latitude = getcookie('tom_tongcheng_user_latitude');
	$longitude = getcookie('tom_tongcheng_user_longitude');
	$showLbsMap = 0;
	if (!empty($tcqunInfo['latitude']) && !empty($tcqunInfo['longitude'])) {
		$showLbsMap = 1;
	}
	$baiduMapToName = $tcqunInfo['name'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $tcqunInfo['latitude'] . ',' . $tcqunInfo['longitude'] . '&title=' . $baiduMapToName . '&content=&output=html';
	$ajaxLoadFlListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&user_id=' . $tcqunInfo['user_id'] . '&act=list&formhash=' . $formhash;
	$ajaxLoadShopListUrl = 'plugin.php?id=tom_tcshop:ajax&site=' . $site_id . '&act=list&user_id=' . $tcqunInfo['user_id'] . '&formhash=' . $formhash;
	$ajaxClicksUrl = 'plugin.php?id=tom_tcqun:ajax&site=' . $site_id . '&act=clicks&tcqun_id=' . $tcqun_id . '&formhash=' . FORMHASH;
	$show_add_btn = 1;
	if ($tcqunInfo['open_addpay'] == 1 && $tcqunInfo['addpay_price'] > 0) {
		if ($__UserInfo['id'] > 0) {
			$show_add_btn = 2;
			$addpayOrderInfoTmp = C::t('#tom_tcqun#tom_tcqun_order')->fetch_all_list(' AND tcqun_id=' . $tcqunInfo['id'] . ' AND user_id=' . $__UserInfo['id'] . ' AND order_type=5 AND order_status=2 ', 'ORDER BY id DESC', 0, 1);
			if (is_array($addpayOrderInfoTmp) && !empty($addpayOrderInfoTmp) && $addpayOrderInfoTmp[0]['id'] > 0) {
				$show_add_btn = 1;
			}
			if ($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 || $__UserInfo['id'] == $tcqunConfig['qmanage_user_id'] || $__UserInfo['id'] == $tcqunInfo['user_id']) {
				$show_add_btn = 1;
			}
			$addpayUrl = 'plugin.php?id=tom_tcqun:pay&site=' . $site_id . '&act=addpay&&user_id=' . $__UserInfo['id'] . '&formhash=' . $formhash;
		} else {
			$show_add_btn = 3;
		}
	}
	$shareTitle = str_replace('{NAME}', $tcqunInfo['name'], $tcqunConfig['info_share_title']);
	$shareTitle = str_replace('{SITENAME}', $__SitesInfo['name'], $shareTitle);
	$shareDesc = $tcqunInfo['sub_title'];
	if (!empty($tcqunInfo['logo'])) {
		$shareLogo = $logo;
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqun&site=' . $site_id . '&mod=info&tcqun_id=' . $tcqun_id . '&tj_hehuoren_id=' . $__TjHehuorenId . '&s=1');
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tcqunConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqun:info');
} elseif ($_GET['mod'] == 'list') {
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$order_type = isset($_GET['order_type']) ? addslashes($_GET['order_type']) : 'hot';
	$keyword = isset($_GET['keyword']) ? addslashes(urldecode($_GET['keyword'])) : '';
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	if ($cate_id > 0) {
		$cateInfo = C::t('#tom_tcqun#tom_tcqun_cate')->fetch_by_id($cate_id);
	}
	$areaInfo = array();
	if (!empty($area_id)) {
		$areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($area_id);
	}
	$streetInfo = array();
	if (!empty($street_id)) {
		$streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($street_id);
	}
	$whereStr = '  AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND expire_status = 1 ';
	if (!empty($sql_in_site_ids)) {
		$whereStr .= ' AND site_id IN(' . $sql_in_site_ids . ') ';
	}
	if ($cate_id > 0) {
		$whereStr .= ' AND cate_id=' . $cate_id . ' ';
	}
	$tcqunListCount = C::t('#tom_tcqun#tom_tcqun')->fetch_all_count($whereStr);
	$cateListTmp = C::t('#tom_tcqun#tom_tcqun_cate')->fetch_all_list('', 'ORDER BY csort ASC,id DESC');
	$cateList = array();
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
		}
	}
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		$areaList = $areaListTmp;
	}
	$ajaxGetStreetUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=list_get_street&formhash=' . $formhash;
	$shareTitle = lang('plugin/tom_tcqun', 'list_title') . '-' . $__SitesInfo['name'];
	if ($cateInfo && $cateInfo['id'] > 0) {
		$shareTitle = $cateInfo['name'] . '-' . $__SitesInfo['name'];
	}
	$url = $weixinClass->get_url();
	$md5HostUrl = md5($url);
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcqun&site=' . $site_id . '&mod=list&cate_id=' . $cate_id . '&tj_hehuoren_id=' . $__TjHehuorenId);
	$searchUrl = 'plugin.php?id=tom_tcqun:ajax&site=' . $site_id . '&act=get_search_url&cate_id=' . $cate_id . '&area_id=' . $area_id . '&street_id=' . $street_id . '&order_type=' . $order_type;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqun:list');
} elseif ($_GET['mod'] == 'mylist') {
	$page = intval($_GET['page']) > 0 ? intval($_GET['page']) : 1;
	$type = intval($_GET['type']) > 0 ? intval($_GET['type']) : 0;
	$pagesize = 8;
	$start = ($page - 1) * $pagesize;
	$where = ' AND user_id=' . $__UserInfo['id'] . ' ';
	$order = ' ORDER BY id DESC ';
	if ($type == 1) {
		$where .= ' AND pay_status=1 ';
	}
	if ($type == 2) {
		$where .= ' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND expire_status = 1 ';
	}
	if ($type == 3) {
		$where .= ' AND expire_status = 0 ';
	}
	$count = C::t('#tom_tcqun#tom_tcqun')->fetch_all_count($where);
	$tcqunListTmp = C::t('#tom_tcqun#tom_tcqun')->fetch_all_list($where, $order, $start, $pagesize);
	$tcqunList = array();
	if (is_array($tcqunListTmp) && !empty($tcqunListTmp)) {
		foreach ($tcqunListTmp as $key => $value) {
			$tcqunList[$key] = $value;
			$tcqunList[$key]['logo'] = tomGetPicUrl($value['logo']);
			$qrcodeEndTime = 7 * 86400 + $value['qrcode_update_time'] - 3600;
			$tcqunList[$key]['qrcodeEndTime'] = $qrcodeEndTime;
		}
	}
	$showNextPage = 1;
	if ($start + $pagesize >= $count) {
		$showNextPage = 0;
	}
	$allPageNum = ceil($count / $pagesize);
	$prePage = $page - 1;
	$nextPage = $page + 1;
	$prePageUrl = 'plugin.php?id=tom_tcqun&site=' . $site_id . '&mod=mylist&type=' . $type . '&page=' . $prePage;
	$nextPageUrl = 'plugin.php?id=tom_tcqun&site=' . $site_id . '&mod=mylist&type=' . $type . '&page=' . $nextPage;
	$refreshPayStatus = 1;
	if ($tcqunConfig['open_refresh_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0) {
		$refreshPayScore = ceil($tcqunConfig['qun_refresh_price'] * $tongchengConfig['pay_score_yuan']);
		if ($refreshPayScore > 0 && $__UserInfo['score'] >= $refreshPayScore) {
			$refreshPayStatus = 2;
		}
	}
	$back_url = $weixinClass->get_url();
	$back_url = urlencode($back_url);
	$payUrl = 'plugin.php?id=tom_tcqun:pay&site=' . $site_id . '&act=pay&back_url=' . $back_url . '&formhash=' . $formhash;
	$refreshPayUrl = 'plugin.php?id=tom_tcqun:pay&site=' . $site_id . '&act=refresh_pay&back_url=' . $back_url . '&formhash=' . $formhash;
	$ajaxUpdateStatusUrl = 'plugin.php?id=tom_tcqun:ajax&site=' . $site_id . '&act=updateStatus&&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqun:mylist');
} elseif ($_GET['mod'] == 'baidumap') {
	$lat = !empty($_GET['lat']) ? addslashes($_GET['lat']) : '';
	$lng = !empty($_GET['lng']) ? addslashes($_GET['lng']) : '';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcqun:baidumap');
} elseif ($_GET['mod'] == 'add') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqun/module/add.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqun/module/edit.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqun/module/upload.php';
} elseif ($_GET['mod'] == 'buytop') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqun/module/buytop.php';
} elseif ($_GET['mod'] == 'buyxufei') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqun/module/buyxufei.php';
} elseif ($_GET['mod'] == 'managerList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcqun/module/managerList.php';
} else {
	tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcqun&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();