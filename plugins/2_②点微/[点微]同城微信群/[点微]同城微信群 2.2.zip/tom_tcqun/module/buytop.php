<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tcqun_id   = intval($_GET['tcqun_id'])>0 ?intval($_GET['tcqun_id']):0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';

$tcqunInfo = C::t("#tom_tcqun#tom_tcqun")->fetch_by_id($tcqun_id);

if($tcqunInfo['id'] > 0 && $tcqunInfo['user_id'] == $__UserInfo['id']){ }else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqun&site={$site_id}&mod=mylist");exit;
}

$cateInfo = C::t("#tom_tcqun#tom_tcqun_cate")->fetch_by_id($tcqunInfo['cate_id']);

$qunTopList = array();
$qun_top_list_str = str_replace("\r\n","{n}",$tcqunConfig['qun_top_list']); 
$qun_top_list_str = str_replace("\n","{n}",$qun_top_list_str);
$qun_top_list_arr = explode("{n}", $qun_top_list_str);
if(is_array($qun_top_list_arr) && !empty($qun_top_list_arr)){
    foreach ($qun_top_list_arr as $key => $value){
        $arr = explode("|", $value);;
        
        $qunTopList[$key]['day'] = $arr[0];
        $qunTopList[$key]['price'] = $arr[1];
        $qunTopList[$key]['pay_score_status'] = 0;
        $qunTopList[$key]['pay_score']        = 0;
        
        if($tcqunConfig['open_top_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $top_pay_score = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($top_pay_score > 0 && $__UserInfo['score'] > $top_pay_score){
                $qunTopList[$key]['pay_score_status'] = 1;
                $qunTopList[$key]['pay_score'] = $top_pay_score;
            }
        }
    }
}

$payTopUrl = "plugin.php?id=tom_tcqun:pay&site={$site_id}&act=top_pay&back_url=".urlencode($back_url)."&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcqun:buytop");