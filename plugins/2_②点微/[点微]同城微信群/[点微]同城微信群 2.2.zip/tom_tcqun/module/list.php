<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword        = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$cate_id        = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$area_id        = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id      = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$page           = intval($_GET['page'])>0? intval($_GET['page']):1;
$order_type     = isset($_GET['order_type'])? addslashes($_GET['order_type']):'hot';
$pagesize       = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):20;
$from           = isset($_GET['from'])? addslashes($_GET['from']):'';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$where = ' AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) AND expire_status = 1 ';
if(!empty($sql_in_site_ids)){
    $where .= " AND site_id IN({$sql_in_site_ids}) ";
}
if($cate_id > 0){
    $where .= " AND cate_id={$cate_id} ";
}
if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND (name LIKE '%{$keyword}%' OR content LIKE '%{$keyword}%')";
}

if(!empty($area_id)){
    $where .= " AND area_id={$area_id} ";
}
if(!empty($street_id)){
    $where .= " AND street_id={$street_id} ";
}

if($order_type == 'new'){
    $orderStr = " ORDER BY id DESC ";
}else if($order_type == 'hot'){
    $orderStr = " ORDER BY top_status DESC,refresh_time DESC,sort ASC,id DESC ";
}else{
    $orderStr = " ORDER BY top_status DESC,refresh_time DESC,sort ASC,id DESC ";
}

$pagesize = $pagesize;
$start = ($page - 1)*$pagesize;
if($order_type == 'fujin' && !empty($longitude) && !empty($latitude)){
    $tcqunListTmp = C::t('#tom_tcqun#tom_tcqun')->fetch_all_nearby_list($where,$start,$pagesize,$latitude,$longitude);
}else{
    $tcqunListTmp = C::t('#tom_tcqun#tom_tcqun')->fetch_all_list($where,$orderStr,$start,$pagesize);
}
$tcqunList = array();
foreach ($tcqunListTmp as $key => $value) {
    $tcqunList[$key] = $value;

    $cateInfoTmp = C::t("#tom_tcqun#tom_tcqun_cate")->fetch_by_id($value['cate_id']);
    
    $qrcodeEndTime = 7 * 86400 + $value['qrcode_update_time'] - 3600;
    
    $tcqunList[$key]['logo']    = tomGetPicUrl($value['logo']);
    if(!empty($value['qrcode']) && $qrcodeEndTime > TIMESTAMP){
        $tcqunList[$key]['qrcode']  = tomGetPicUrl($value['qrcode']);
    }else{
        $tcqunList[$key]['qrcode']  = tomGetPicUrl($value['qunzhu_qrcode']);
    }
    $tcqunList[$key]['cateInfo'] = $cateInfoTmp;
}

if(is_array($tcqunList) && !empty($tcqunList)){
    foreach ($tcqunList as $key => $val){
        if($tcqunConfig['open_load_list_clicks'] == 1){
            DB::query("UPDATE ".DB::table('tom_tcqun')." SET clicks=clicks+1 WHERE id='{$val['id']}' ", 'UNBUFFERED');
        }

        $outStr .= '<div class="qunlist-item dislay-flex">';
            $outStr .= '<a class="item-qunlogo" href="plugin.php?id=tom_tcqun&site='.$site_id.'&mod=info&tcqun_id='.$val['id'].'">';
                $outStr .= '<img src="'.$val['logo'].'">';
            $outStr .= '</a>';
            $outStr .= '<a class="item-content flex" href="plugin.php?id=tom_tcqun&site='.$site_id.'&mod=info&tcqun_id='.$val['id'].'">';
                $topStr = $shopStr = '';
                if($val['top_status'] == 1 && $val['top_time'] > TIMESTAMP){
                    $topStr = '<span class="top">'.lang('plugin/tom_tcqun', 'top').'</span>';
                }
                if($__ShowTcshop == 1 && $val['tcshop_id'] > 0){
                    $shopStr = '<span class="shop">'.lang('plugin/tom_tcqun', 'shop').'</span>';
                }
                $outStr .= '<div class="item-qunname">'.$topStr.$shopStr.$val['name'].'</div>';
                $outStr .= '<div class="item-qunsub">'.$val['sub_title'].'</div>';
            $outStr .= '</a>';
            if($from == 'tongcheng' || $val['open_addpay'] == 1 || $val['allow_distance'] > 0){
                if(isset($val['distance'])){
                    $juli = tomGetDistance($longitude, $latitude, $val['longitude'], $val['latitude']);
                    $outStr .= '<a class="item-btn" href="plugin.php?id=tom_tcqun&site='.$site_id.'&mod=info&tcqun_id='.$val['id'].'" style="margin-top: -5px;">'.lang('plugin/tom_tcqun', 'list_shenqing_btn').'</a>';
                    $outStr.= '<div class="distance">'.$juli.'km</div>';
                }else{
                    $outStr .= '<a class="item-btn" href="plugin.php?id=tom_tcqun&site='.$site_id.'&mod=info&tcqun_id='.$val['id'].'">'.lang('plugin/tom_tcqun', 'list_shenqing_btn').'</a>';
                }
            }else{
                if(isset($val['distance'])){
                    $juli = tomGetDistance($longitude, $latitude, $val['longitude'], $val['latitude']);
                    $outStr .= '<a class="item-btn show_qrcode_btn" data-qrcode="'.$val['qrcode'].'" href="javascript:;void(0)" style="margin-top: -5px;">'.lang('plugin/tom_tcqun', 'list_shenqing_btn').'</a>';
                    $outStr.= '<div class="distance">'.$juli.'km</div>';
                }else{
                    $outStr .= '<a class="item-btn show_qrcode_btn" data-qrcode="'.$val['qrcode'].'" href="javascript:;void(0)">'.lang('plugin/tom_tcqun', 'list_shenqing_btn').'</a>';
                }
                
            }
            
        $outStr .= '</div>';
    }
    
    if($tcqunConfig['open_load_list_clicks'] == 1 && $tcqunConfig['open_tj_commonclicks'] == 1){
        $tcqunCount = count($tcqunList);
        DB::query("UPDATE ".DB::table('tom_tcqun_common')." SET clicks=clicks+{$tcqunCount} WHERE site_id='$site_id' ", 'UNBUFFERED');
    }
}else{
    $outStr = '205';
}

$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;