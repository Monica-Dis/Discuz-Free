<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# lbs start
if($tcadminConfig['open_sites_lbs'] > 1){
    $tcadminConfig['open_sites'] = 1;
}
if(empty($tongchengConfig['baidu_js_ak'])){
    $tcadminConfig['open_sites_lbs'] = 1;
}
if($site_id > 1 && $__SitesInfo['open_sites'] == 0){
    $tcadminConfig['open_sites'] = 0;
    $tcadminConfig['open_sites_lbs'] = 1;
}
$hotSitesList = $cateSitesList = array();
if($tcadminConfig['open_sites'] == 1){
    $hotSitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 AND is_hot=1 AND open_sites=1 "," ORDER BY paixu ASC,id DESC ",0,1000);
    $cateSitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites_cate')->fetch_all_list(" "," ORDER BY paixu ASC,id DESC ",0,100);
    if(is_array($cateSitesListTmp) && !empty($cateSitesListTmp)){
        foreach ($cateSitesListTmp as $key => $value){
            $cateSitesList[$key] = $value;
            $sitesListTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 AND cate_id={$value['id']} AND open_sites=1 "," ORDER BY paixu ASC,id DESC ",0,1000);
            $cateSitesList[$key]['sites'] = $sitesListTmp;
        }
    }
}
$ajaxLbsCheckUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=lbs_check&cfrom=tcqun';
$ajaxLbsCloseUrl = 'plugin.php?id=tom_tongcheng:ajax&site='.$site_id.'&act=lbs_close&formhash='.$formhash;
if($_GET['lbs_must'] == 1){}else{
    $cookie_lbs = getcookie('tom_tongcheng_sites_lbs');
    if($cookie_lbs && $cookie_lbs == 1){
        $tcadminConfig['open_sites_lbs'] = 1;
    }
}
if($_GET['lbs_no'] == 1){
    $lifeTime = $tcadminConfig['sites_lbs_time'];
    dsetcookie('tom_tongcheng_sites_lbs', 1, $lifeTime);
    $tcadminConfig['open_sites_lbs'] = 1;
    if($__UserInfo['id'] > 0){
        $__UserInfo['site_id']  = $site_id;

        $updateData             = array();
        $updateData['site_id']  = $site_id;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($__UserInfo['id'],$updateData);
    }
}
$lbs_show = 0;
if($_GET['lbs_show'] == 1){
    $lbs_show = 1;
}
if($_GET['lbs_must'] == 1 || $_GET['lbs_show'] == 1){}else{
    if($site_id == 1 && $tcadminConfig['open_memory'] == 1 && $__UserInfo['id'] > 0 && $__UserInfo['site_id'] > 1){
        $memorySitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($__UserInfo['site_id']);
        if($memorySitesInfoTmp['status'] == 1 && $memorySitesInfoTmp['open_sites'] == 1 ){
            tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqun&site={$__UserInfo['site_id']}&mod=index");exit;
        }
    }
}
# lbs end