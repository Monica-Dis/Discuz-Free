<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    if($__UserInfo['id'] != $tcqunConfig['qmanage_user_id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqun&site={$site_id}&mod=index");exit;
    }
}
# check end

if($_GET['act'] == 'shenhe' && submitcheck('tcqun_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $tcqun_id       = intval($_GET['tcqun_id'])>0? intval($_GET['tcqun_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0? intval($_GET['shenhe_status']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $tcqunInfo = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($tcqun_id);
    
    $updateData = array();
    $updateData['shenhe_status'] = $shenhe_status;
    if($shenhe_status == 1){
        $updateData['status'] = 1;
    }
    C::t('#tom_tcqun#tom_tcqun')->update($tcqunInfo['id'],$updateData);
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcqunInfo['user_id']);
    
    if($tcqunInfo){
        
        if($shenhe_status == 1){
            $shenhe = str_replace('{NAME}', $tcqunInfo['name'], lang('plugin/tom_tcqun', 'template_tcqun_shenhe_ok'));
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcqun&site='.$site_id.'&mod=info&tcqun_id='.$tcqunInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }else if($shenhe_status == 3){
            $shenhe = str_replace('{NAME}', $tcqunInfo['name'], lang('plugin/tom_tcqun', 'template_tcqun_shenhe_no'));
            $tzShenhe = $shenhe.'<br/><font color="#8e8e8e">'.$content.'</font><br/><a href="plugin.php?id=tom_tcqun&site='.$site_id.'&mod=edit&tcqun_id='.$tcqunInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }
        
        $insertData = array();
        $insertData['user_id']      = $toUser['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcqunConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
    }
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $access_token = $weixinClass->get_access_token();
    
    $nextSmsTime = $toUser['last_smstp_time'] + 0;
    if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime){
        if($shenhe_status == 1){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqun&site={$tcqunInfo['site_id']}&mod=info&tcqun_id=".$tcqunInfo['id']);
        }else if($shenhe_status == 3){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqun&site={$tcqunInfo['site_id']}&mod=mylist");
        }
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcqunConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $updateData = array();
            $updateData['last_smstp_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tcqun&site={$site_id}&mod=managerList&keyword=".urlencode(trim($keyword));
    
    echo $url;exit;
    
}else if($_GET['act'] == 'del' && submitcheck('tcqun_id')){
    
    $tcqun_id = intval($_GET['tcqun_id'])>0? intval($_GET['tcqun_id']):0;
    
    C::t('#tom_tcqun#tom_tcqun')->delete_by_id($tcqun_id);
    C::t('#tom_tcqun#tom_tcqun_photo')->delete_by_tcqun_id($tcqun_id);
    echo 200;exit;

}else if($_GET['act'] == 'shenhe_show'){
    
    $tcqun_id   = intval($_GET['tcqun_id'])>0? intval($_GET['tcqun_id']):0;
    $back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
    
    $tcqunInfo = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($tcqun_id);

    $qun_shenhe_fail_str = str_replace("\r\n","{n}",$tcqunConfig['qun_shenhe_fail_text']); 
    $qun_shenhe_fail_str = str_replace("\n","{n}",$qun_shenhe_fail_str);
    $qunShenheFailArray = explode("{n}", $qun_shenhe_fail_str);
    
    $ajaxShenheUrl = "plugin.php?id=tom_tcqun&site={$site_id}&mod=managerList&act=shenhe&";
    $backUrl = $back_url;
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcqun:managerShenhe");exit;
}

$keyword  = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page  = intval($_GET['page'])>0? intval($_GET['page']):1;
$type  = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = " AND pay_status != 1 ";
if($type == 1){
    $where .= " AND shenhe_status=2 ";
}
if($type == 2){
    $where .= " AND shenhe_status=3 ";
}
if($__UserInfo['groupid'] == 2){
    $where .= " AND site_id={$site_id} ";
}

if(!empty($keyword)){
    $keyword = str_replace(array('%', '_'),'',$keyword);
    $where .= " AND (name LIKE '%{$keyword}%' OR content LIKE '%{$keyword}%')";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count = C::t('#tom_tcqun#tom_tcqun')->fetch_all_count($where);
$tcqunListTmp = C::t('#tom_tcqun#tom_tcqun')->fetch_all_list($where," ORDER BY refresh_time DESC,id DESC ",$start,$pagesize);
$tcqunList = array();
foreach ($tcqunListTmp as $key => $value) {
    $tcqunList[$key] = $value;
    
    $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    
    $tcqunList[$key]['userInfo']    = $userInfoTmp;
    $tcqunList[$key]['logo']        = tomGetPicUrl($value['logo']);
        
    if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
        $updateData = array();
        $updateData['top_status']   = 0;
        $updateData['top_time']     = 0;
        C::t('#tom_tcqun#tom_tcqun')->update($value['id'], $updateData);
    }

    if($value['expire_status'] == 1 && $value['expire_time'] <= TIMESTAMP){
        $updateData = array();
        $updateData['expire_status']    = 2;
        $updateData['expire_time']      = 0;
        $updateData['status']           = 0;
        C::t('#tom_tcqun#tom_tcqun')->update($value['id'], $updateData);
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl = "plugin.php?id=tom_tcqun&site={$site_id}&mod=managerList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tcqun&site={$site_id}&mod=managerList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];

$back_url = $weixinClass->get_url();
$back_url = urlencode($back_url);

$ajaxShenheUrl = "plugin.php?id=tom_tcqun&site={$site_id}&mod=managerList&act=shenhe&formhash=".$formhash;
$ajaxDelUrl = "plugin.php?id=tom_tcqun&site={$site_id}&mod=managerList&act=del&formhash=".$formhash;
$searchUrl = "plugin.php?id=tom_tcqun&site={$site_id}&mod=managerList&act=get_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcqun:managerList");