<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$test       = intval($_GET['test'])>0 ? intval($_GET['test']):0;
$tcqun_id   = intval($_GET['tcqun_id'])>0? intval($_GET['tcqun_id']):0;
$back_url   = isset($_GET['back_url'])? addslashes($_GET['back_url']):'';
$fromlist   = isset($_GET['fromlist'])? addslashes($_GET['fromlist']):'';

$tcqunInfo = C::t('#tom_tcqun#tom_tcqun')->fetch_by_id($tcqun_id);

$quanxianStatus = 0;
if($tcqunInfo['id'] > 0 && $tcqunInfo['user_id'] == $__UserInfo['id']){ 
    $quanxianStatus = 1;
}
# check start
if($__UserInfo['id'] == $tcqunConfig['qmanage_user_id']){
    $quanxianStatus = 2;
}else{
    if($__UserInfo['groupid'] == 1){
        $quanxianStatus = 2;
    }else if($__UserInfo['groupid'] == 2){
        if($tcqunInfo['site_id'] == $__UserInfo['groupsiteid']){
            $quanxianStatus = 2;
        }
    }
}
# check end

if($quanxianStatus == 0){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqun&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && submitcheck('tcqun_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $name               = dhtmlspecialchars($name);
    $sub_title          = isset($_GET['sub_title'])? addslashes($_GET['sub_title']):'';
    $sub_title          = dhtmlspecialchars($sub_title);
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $tcshop_id          = isset($_GET['tcshop_id'])? intval($_GET['tcshop_id']):0;
    $city_id            = isset($_GET['city_id'])? intval($_GET['city_id']):0;
    $area_id            = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id          = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $lng                = isset($_GET['lng'])? addslashes($_GET['lng']):'';
    $lat                = isset($_GET['lat'])? addslashes($_GET['lat']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $address            = dhtmlspecialchars($address);
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $content            = filterEmoji($content);
    $content            = dhtmlspecialchars($content);
    $logo               = isset($_GET['logo'])? addslashes($_GET['logo']):'';
    $qrcode             = isset($_GET['qrcode'])? addslashes($_GET['qrcode']):'';
    $qunzhu_qrcode      = isset($_GET['qunzhu_qrcode'])? addslashes($_GET['qunzhu_qrcode']):'';
    
    $open_addpay        = isset($_GET['open_addpay'])? intval($_GET['open_addpay']):0;
    $addpay_price       = isset($_GET['addpay_price'])? floatval($_GET['addpay_price']):0;
    
    $kouling            = isset($_GET['kouling'])? addslashes($_GET['kouling']):'';
    $kouling            = dhtmlspecialchars($kouling);
    $allow_distance     = isset($_GET['allow_distance'])? floatval($_GET['allow_distance']):0;
    
    $photoList = array();
    if(is_array($_GET['photo']) && !empty($_GET['photo'])){
        foreach($_GET['photo'] as $key => $value){
            $picurlTmp = addslashes($value);
            if(!empty($picurlTmp)){
                $photoList[] = $picurlTmp;
            }
        }
    }
    
    $updateData = array();
    $updateData['name']             = $name;
    $updateData['sub_title']        = $sub_title;
    $updateData['cate_id']          = $cate_id;
    $updateData['tcshop_id']        = $tcshop_id;
    $updateData['city_id']          = $city_id;
    $updateData['area_id']          = $area_id;
    $updateData['street_id']        = $street_id;
    $updateData['latitude']         = $lat;
    $updateData['longitude']        = $lng;
    $updateData['address']          = $address;
    $updateData['open_addpay']      = $open_addpay;
    $updateData['addpay_price']     = $addpay_price;
    $updateData['kouling']          = $kouling;
    $updateData['allow_distance']   = $allow_distance;
    $updateData['content']          = $content;
    $updateData['logo']             = $logo;
    $updateData['qrcode']           = $qrcode;
    if($qrcode != $tcqunInfo['qrcode']){
        $updateData['qrcode_update_time']      = TIMESTAMP;
    }
    $updateData['qunzhu_qrcode']    = $qunzhu_qrcode;
    if($tcqunConfig['qun_must_shenhe'] == 1 && $quanxianStatus == 1){
        $updateData['shenhe_status']              = 2;
    }
    $updateData['update_time']      = TIMESTAMP;
    if(C::t('#tom_tcqun#tom_tcqun')->update($tcqun_id,$updateData)){
        C::t('#tom_tcqun#tom_tcqun_photo')->delete_by_tcqun_id($tcqun_id);
        
        if(is_array($photoList) && !empty($photoList)){
            foreach($photoList as $key => $value){
                $insertData = array();
                $insertData['tcqun_id'] = $tcqun_id;
                $insertData['picurl']   = $value;
                $insertData['add_time'] = TIMESTAMP;
                C::t('#tom_tcqun#tom_tcqun_photo')->insert($insertData);
            }
        }
        
        if(!empty($tongchengConfig['template_id']) && $tcqunConfig['qun_must_shenhe'] == 1 && $quanxianStatus == 1){
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

            if($site_id > 1){
                $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
                $manage_user_id = $siteInfo['manage_user_id'];
            }else{
                $manage_user_id = $tongchengConfig['manage_user_id'];
            }

            $template_first = str_replace("{NAME}",$name, lang('plugin/tom_tcqun','shenhe_template_first'));

            $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($manage_user_id);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($toUser['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqun&site={$site_id}&mod=managerList");
                $smsData = array(
                    'first'         => $template_first,
                    'keyword1'      => $tcqunConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
            }
            
            if($tcqunConfig['qmanage_user_id'] > 0){
                $qManageUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tcqunConfig['qmanage_user_id']);

                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($qManageUser['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcqun&site={$site_id}&mod=managerList");
                    $smsData = array(
                        'first'         => $template_first,
                        'keyword1'      => $site_name,
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );
                    @$r = $templateSmsClass->sendSms01($qManageUser['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }
        }
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}

if($tcqunInfo['pay_status'] == 1){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcqun&site={$site_id}&mod=mylist");exit;
}

$logo = tomGetPicUrl($tcqunInfo['logo']);
$qrcode = tomGetPicUrl($tcqunInfo['qrcode']);
$qunzhuQrcode = tomGetPicUrl($tcqunInfo['qunzhu_qrcode']);

$photoList = array();
if($tcqunConfig['open_qun_album'] == 1){
    $photoListTmp = C::t("#tom_tcqun#tom_tcqun_photo")->fetch_all_list(" AND tcqun_id = {$tcqun_id} ", 'ORDER BY id DESC');
    if(is_array($photoListTmp) && !empty($photoListTmp)){
        foreach($photoListTmp as $key => $value){
            $photoList[$key] = $value;
            $photoList[$key]['picurlTmp'] = tomGetPicUrl($value['picurl']);
        }
    }
}
$photoCount = count($photoList);

if($__ShowTcshop == 1){
    $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND user_id={$__UserInfo['id']}"," ORDER BY id DESC ",0,100);
    $tcshopList = array();
    if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
        foreach($tcshopListTmp as $key => $value){
            $tcshopList[$key] = $value;
        }
    }
    $tcshopCount = count($tcshopList);
}

$cateListTmp = C::t('#tom_tcqun#tom_tcqun_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ");
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach ($cateListTmp as $key => $value){
        $cateList[$key] = $value;
    }
}
$cateData = urlencode(json_encode($cateArr));

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$cityList = array();
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$tcqunInfo['content'] = strip_tags($tcqunInfo['content']);

$areaName = '';
if(!empty($tcqunInfo['area_id'])){
    $areaInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tcqunInfo['area_id']);
    $areaName = $areaInfoTmp['name'];
}

$streetName = '';
if(!empty($tcqunInfo['street_id'])){
    $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tcqunInfo['street_id']);
    $streetName = $streetInfoTmp['name'];
}

$saveUrl = "plugin.php?id=tom_tcqun&site={$site_id}&mod=edit&act=save";
$uploadUrl = "plugin.php?id=tom_tcqun&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tcqun:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcqun:edit");