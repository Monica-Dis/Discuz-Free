<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: [DisM!] (C)2001-2099 DisM Inc..
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$test = intval($_GET['test'])>0 ? intval($_GET['test']):0;

if($__ShowTcshop == 1){
    $tcshopListTmp = C::t('#tom_tcshop#tom_tcshop')->fetch_all_list(" AND status=1 AND shenhe_status=1 AND user_id={$__UserInfo['id']}"," ORDER BY id DESC ",0,100);
    $tcshopList = array();
    if(is_array($tcshopListTmp) && !empty($tcshopListTmp)){
        foreach($tcshopListTmp as $key => $value){
            $tcshopList[$key] = $value;
        }
    }
    $tcshopCount = count($tcshopList);
}

$cateArr = array();
$cateListTmp = C::t('#tom_tcqun#tom_tcqun_cate')->fetch_all_list(" "," ORDER BY csort ASC,id DESC ");
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach($cateListTmp as $key => $value){
        $cateList[$key] = $value;
    }
}

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$cityList = array();
$i = 0;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$xieyi_txt = stripslashes($tcqunConfig['xieyi_txt']);

$qunFabuList = array();
$qun_fabu_list_str = str_replace("\r\n","{n}",$tcqunConfig['qun_fabu_list']);
$qun_fabu_list_str = str_replace("\n","{n}",$qun_fabu_list_str);
$qun_fabu_list_arr = explode("{n}", $qun_fabu_list_str);
if(is_array($qun_fabu_list_arr) && !empty($qun_fabu_list_arr)){
    foreach ($qun_fabu_list_arr as $key => $value){
        $arr = explode("|", $value);

        $qunFabuList[$key]['days']             = $arr[0];
        $qunFabuList[$key]['price']            = $arr[1];
        $qunFabuList[$key]['desc']             = $arr[2];
        $qunFabuList[$key]['pay_score_status'] = 0;
        $qunFabuList[$key]['pay_score']        = 0;
        
        if($tcqunConfig['open_fabu_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $fabu_pay_score = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($fabu_pay_score > 0 && $__UserInfo['score'] > $fabu_pay_score){
                $qunFabuList[$key]['pay_score_status'] = 1;
                $qunFabuList[$key]['pay_score'] = $fabu_pay_score;
            }
        }
    }
}

$qunTopList = array();
$qun_top_list_str = str_replace("\r\n","{n}",$tcqunConfig['qun_top_list']); 
$qun_top_list_str = str_replace("\n","{n}",$qun_top_list_str);
$qun_top_list_arr = explode("{n}", $qun_top_list_str);
if(is_array($qun_top_list_arr) && !empty($qun_top_list_arr)){
    foreach ($qun_top_list_arr as $key => $value){
        $arr = explode("|", $value);
        $qunTopList[$key]['days']             = $arr[0];
        $qunTopList[$key]['price']            = $arr[1];
    }
}

$subscribeFlag = 0;
$open_subscribe = 0;
$access_token = $weixinClass->get_access_token();
if($tongchengConfig['open_subscribe']==1 && $tongchengConfig['open_child_subscribe_sites']==1){
    $open_subscribe = 1;
}else if($tongchengConfig['open_subscribe']==1 && $site_id==1){
    $open_subscribe = 1;
}
if($open_subscribe==1 && !empty($__UserInfo['openid']) && !empty($access_token)){
    $get_user_info_url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token={$access_token}&openid={$__UserInfo['openid']}&lang=zh_CN";
    $return = get_html($get_user_info_url);
    if(!empty($return)){
        $tcContent = json_decode($return,true);
        if(is_array($tcContent) && !empty($tcContent) && isset($tcContent['subscribe'])){
            if($tcContent['subscribe'] == 1){
                $subscribeFlag = 1;
            }else{
                $subscribeFlag = 2;
            }
        }
    }
}

$showGuanzuBox = 0;
$tcqunListTmp = C::t('#tom_tcqun#tom_tcqun')->fetch_all_list(" AND user_id={$__UserInfo['id']} AND shenhe_status = 2 ", " ORDER BY id DESC ", 0, 1);
if(is_array($tcqunListTmp) && !empty($tcqunListTmp[0]) && $subscribeFlag == 2){
    $subscribeFlag = 0;
    $showGuanzuBox = 1;
}

$shareUrl = $_G['siteurl']."plugin.php?id=tom_tcqun&site={$site_id}&mod=add";

$payUrl = "plugin.php?id=tom_tcqun:pay&site={$site_id}";
$backLinkUrl = "plugin.php?id=tom_tcqun&site={$site_id}&mod=mylist&fromlist=mylist";
$uploadUrl = "plugin.php?id=tom_tcqun&site={$site_id}&mod=upload&act=photo&formhash=".FORMHASH;
$wxUploadUrl = "plugin.php?id=tom_tcqun:wxMediaDowmload&site={$site_id}&act=photo&formhash=".FORMHASH;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcqun:add");