<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$needs_id    = intval($_GET['needs_id'])>0? intval($_GET['needs_id']):0;

$needsInfo   = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($needs_id);

if($needsInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
}

$type         = intval($_GET['type'])> 0? intval($_GET['type']):0;
$page         = intval($_GET['page'])>0? intval($_GET['page']):1;

$whereStr     = " AND needs_id = {$needs_id} ";

if($type == 1){
    $whereStr .= " AND status = 0 ";
}else if($type == 2){
    $whereStr .= " AND status = 1 ";
}else if($type == 3){
    $whereStr .= " AND status = 2 ";
}

$pagesize     = 8;
$start        = ($page - 1)*$pagesize;
$order        = " ORDER BY refresh_time DESC,id DESC ";
$count        = C::t('#tom_tcdaojia#tom_tcdaojia_needs_jie')->fetch_all_count($whereStr);

$needs_jieListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_needs_jie')->fetch_all_list($whereStr,$order,$start,$pagesize);
$needs_jieList = array();
if(is_array($needs_jieListTmp) && !empty($needs_jieListTmp)){
    foreach ($needs_jieListTmp as $key => $value){
        $needs_jieList[$key] = $value;
        
        $servicerInfoTmp       = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($value['servicer_id']);
        $servicerUserInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfoTmp['user_id']);
        $vipInfoTmp   = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_by_id($servicerInfoTmp['vip_id']);
        $orderCount   = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_count("AND servicer_id = {$value['servicer_id']} AND order_status =4 ");
        
        $companyInfoTmp = $personalInfoTmp = array();
        if($__ShowTcrenzheng == 1){
            $companyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($servicerInfoTmp['user_id']);
            $personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_user_id($servicerInfoTmp['user_id']);
        }
        
        $needs_jieList[$key]['servicerUserInfo'] = $servicerUserInfoTmp;
        $needs_jieList[$key]['servicerInfo']     = $servicerInfoTmp;
        $needs_jieList[$key]['orderCount']       = $orderCount;
        $needs_jieList[$key]['vipInfo']          = $vipInfoTmp;
        if($__ShowTcrenzheng == 1){
            $needs_jieList[$key]['personalInfo'] = $personalInfoTmp;
            $needs_jieList[$key]['companyInfo']  = $companyInfoTmp;
        }
        $needs_jieList[$key]['refresh_time'] = dgmdate($value['refresh_time'],"Y-m-d H:i",$tomSysOffset);
        $needs_jieList[$key]['link']         = 'plugin.php?id=tom_tcdaojia&site='.$value['site_id'].'&mod=needsinfo&needs_id='.$value['needs_id'];
    }
}

$noPayOrderListTmp  = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_list(" AND needs_id={$needs_id} AND user_id={$__UserInfo['id']} AND order_status=1 "," ORDER BY id DESC ",0,10);
$isHaveNoPay = 0;
if(is_array($noPayOrderListTmp) && !empty($noPayOrderListTmp)){
    foreach ($noPayOrderListTmp as $key => $value){
        if($value['order_status'] == 1){
            if((TIMESTAMP - $value['order_time']) > 3600){
                DB::query("UPDATE ".DB::table('tom_tcdaojia_order')." SET order_status=6 WHERE id='{$value['id']}' ", 'UNBUFFERED');
            }else{
                $isHaveNoPay = 1;
            }
        }
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=needs_jielist&needs_id={$needs_id}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=needs_jielist&needs_id={$needs_id}&page={$nextPage}";
$pageUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=needs_jielist&needs_id={$needs_id}";

$ajaxQuxiaoStatusUrl = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&act=needs_jie_quxiao&type=2&formhash=".$formhash;
$payUrl = "plugin.php?id=tom_tcdaojia:pay&site={$site_id}&act=pay_needs&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:needs_jielist");