<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_no   = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';

$orderInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($order_no);

if($orderInfo['is_weikuan'] == 1){
    $upOrderInfo = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_sub_order_no($orderInfo['order_no']);
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=orderinfo&order_no={$upOrderInfo['order_no']}");exit;
}

if($orderInfo['goods_id'] > 0){
    $goodsInfo      = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($orderInfo['goods_id']);
}
if($orderInfo['needs_id'] > 0){
    $needsInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($orderInfo['needs_id']);
}

if($orderInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'wancheng' && submitcheck('order_no')){

    $servicerInfo   = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($orderInfo['servicer_id']);

    $updateData = array();
    $updateData['order_status']     = 4;
    $updateData['hexiao_user_id']   = $orderInfo['user_id'];
    $updateData['hexiao_time']      = TIMESTAMP;
    C::t('#tom_tcdaojia#tom_tcdaojia_order')->update($orderInfo['id'],$updateData);
    
    $insertData = array();
    $insertData['order_id']        = $orderInfo['id'];
    $insertData['user_id']         = $orderInfo['user_id'];
    $insertData['hexiao_num']      = $orderInfo['goods_num'];
    $insertData['hexiao_user_id']  = $__UserInfo['id'];
    $insertData['hexiao_time']     = TIMESTAMP;
    C::t('#tom_tcdaojia#tom_tcdaojia_order_hexiao_log')->insert($insertData);
    
    DB::query("UPDATE ".DB::table('tom_tcdaojia_servicer')." SET jie_num=jie_num + 1 WHERE id = {$orderInfo['servicer_id']} ", 'UNBUFFERED');
    
    update_vip_id($orderInfo['servicer_id']);
    
    if($orderInfo['balance_status'] == 0){
        include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/module/balance.php';
    }
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']);
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($toUser['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=myorder");
        $smsData = array(
            'first'         => lang('plugin/tom_tcdaojia','template_wancheng_service'),
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
    }
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'refund' && submitcheck('shenqing_refund_msg')){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    if($orderInfo['shenqing_refund'] == 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    if($orderInfo['order_status'] == 2 || $orderInfo['order_status'] == 3){
    }else{
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $shenqing_refund_msg        = isset($_GET['shenqing_refund_msg'])? addslashes($_GET['shenqing_refund_msg']):'';

    $updateData = array();
    $updateData['shenqing_refund']       = 1;
    $updateData['shenqing_refund_msg']   = $shenqing_refund_msg;
    C::t('#tom_tcdaojia#tom_tcdaojia_order')->update($orderInfo['id'],$updateData);
    
    $servicerInfo       = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($orderInfo['servicer_id']); 
    $saleUserInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']); 
    
    $toUser = array();
    $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
    if($toUserTmp && !empty($toUserTmp['openid'])){
        $toUser = $toUserTmp;
    }

    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($toUser['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");
        $smsData = array(
            'first'         => lang('plugin/tom_tcdaojia','shenhe_template_refund_first'),
            'keyword1'      => $tongchengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
    }
    
    $daojiamanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcdaojiaConfig['daojiamanage_user_id']);
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($daojiamanageUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");
        $smsData = array(
            'first'         => lang('plugin/tom_tcdaojia', 'shenhe_template_refund_first'),
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($daojiamanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
    }
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($saleUserInfo['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=&mod=myorder");
        $smsData = array(
            'first'         => lang('plugin/tom_tcdaojia','shenhe_template_refund_first'),
            'keyword1'      => $tongchengConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($saleUserInfo['openid'],$tongchengConfig['template_id'],$smsData);
    }

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'change_fuwutime' && submitcheck('user_id')){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    if($orderInfo['user_id'] != $__UserInfo['id']){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }

    $fuwu_time          = isset($_GET['fuwu_time'])? addslashes($_GET['fuwu_time']):'';
    $fuwu_time          = str_replace("T", " ", $fuwu_time);
    $fuwu_time          = strtotime($fuwu_time);

    DB::query("UPDATE ".DB::table('tom_tcdaojia_order')." SET fuwu_time={$fuwu_time} WHERE id = {$orderInfo['id']} ", 'UNBUFFERED');
    
    $servicerInfo       = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($orderInfo['servicer_id']); 
    $servicerUserInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']); 
        
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($servicerUserInfo['openid']) ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=myorderinfo&order_no={$order_no}");
        $smsData = array(
            'first'         => lang('plugin/tom_tcdaojia','template_tcdaojia_change'),
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($servicerUserInfo['openid'],$tongchengConfig['template_id'],$smsData);
    }
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}

if(empty($orderInfo['hexiao_no'])){
    $hexiao_no = date("YmdHis")."-".mt_rand(111111, 666666);
    $updateData = array();
    $updateData['hexiao_no'] = $hexiao_no;
    C::t('#tom_tcdaojia#tom_tcdaojia_order')->update($orderInfo['id'],$updateData);
    $orderInfo['hexiao_no']  = $hexiao_no;
}

$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
$servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($orderInfo['servicer_id']);

if($orderInfo['goods_id'] > 0 ){
    $photoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list("AND goods_id = {$goodsInfo['id']} AND type = 1","",0,1);
}elseif($orderInfo['needs_id'] > 0){
    $photoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list("AND needs_id = {$needsInfo['id']} AND type = 6","",0,1);
}

if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
    $picurl = $photoInfoTmp[0]['picurlTmp'];
}else{
    $picurl = $userInfo['picurl'];
}

$order_time    = dgmdate($orderInfo['order_time'],"Y-m-d H:i",$tomSysOffset);
$hexiao_time   = dgmdate($orderInfo['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
$fuwu_time     = dgmdate($orderInfo['fuwu_time'],"Y-m-d H:i",$tomSysOffset);

$subOrderInfo = array();
if(!empty($orderInfo['sub_order_no'])){
    $subOrderInfo = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($orderInfo['sub_order_no']); 
}

$pay_weikuan_status = 0;
if($orderInfo['pay_ding_status'] == 1){
    $pay_weikuan_status = 1;
    if(!empty($subOrderInfo) && $subOrderInfo['order_status'] == 2){
        $pay_weikuan_status = 0;
    }
}

$hexiaoUserInfo = array();
if($orderInfo['order_status'] == 4){
    $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']); 
}

$minDateTime = TIMESTAMP-60;
if($goodsInfo['open_yuyue'] == 1 && $goodsInfo['yuyue_time'] > 0 && $orderInfo['goods_id'] > 0){
    $minDateTime = TIMESTAMP + $goodsInfo['yuyue_time'] * 3600;
}else{
    $minDateTime = TIMESTAMP + $tcdaojiaConfig['yuyue_time'] * 3600;
}
$minDateTime = dgmdate($minDateTime,"Y-m-d H:0:0",$tomSysOffset);
$maxDateTime = TIMESTAMP + 365*86400;
$maxDateTime = dgmdate($maxDateTime,"Y-m-d H:i:s",$tomSysOffset);

if($orderInfo['team_status'] == 1){
    $teamInfo = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_by_id($orderInfo['team_id']);
    $team_pic = '';
    if(!preg_match('/^http/', $teamInfo['picurl']) ){
        if(strpos($teamInfo['picurl'], 'source/plugin/tom_') === FALSE){
            $team_pic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$teamInfo['picurl'];
        }else{
            $team_pic = $teamInfo['picurl'];
        }
    }else{
        $team_pic = $teamInfo['picurl'];
    }
}

$allowHexiaoQrcode = 0;
if($orderInfo['order_status'] == 2 || $orderInfo['order_status'] == 3){
    if($orderInfo['pay_ding_status'] == 1){
        if($subOrderInfo['id'] > 0 && $subOrderInfo['order_status'] == 2){
            $allowHexiaoQrcode = 1;
        }
    }else{
        $allowHexiaoQrcode = 1;
    }
}

$qrcodeImg = $_G['siteurl']."plugin.php?id=tom_qrcode&data=".urlencode($_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=orderhexiao&hexiao_no={$orderInfo['hexiao_no']}");

$ajaxhexiaologlistUrl  = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&order_no={$orderInfo['order_no']}&act=hexiaologlist";
$changeTimeUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=orderinfo&act=change_fuwutime&order_no={$order_no}";
$refundUrl   = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=orderinfo&act=refund&order_no={$order_no}";
$wanchengUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=orderinfo&act=wancheng&order_no={$order_no}&formhash={$formhash}";
$payGoodsWeikuanUrl   = "plugin.php?id=tom_tcdaojia:pay&site={$site_id}&act=pay_goods_weikuan&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:orderinfo");