<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$servicerInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_user_id($__UserInfo['id']);
if($servicerInfo && $servicerInfo['id'] > 0){
}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=my");exit;
}

$servicerLogoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list("AND servicer_id = {$servicerInfo['id']} AND type = 3","ORDER BY id ASC",0,1);
$servicerLogo = '';
if(is_array($servicerLogoTmp) && !empty($servicerLogoTmp)){
    foreach($servicerLogoTmp as $kk => $vv){
        $servicerLogo = $vv['picurlTmp'];
    }
}

$vip_pic = $tcdaojiaConfig['vip_picurl'];
$vipInfo = array();
if($servicerInfo['vip_id'] > 0){
    $vipInfo = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_by_id($servicerInfo['vip_id']);
    if(!preg_match('/^http/', $vipInfo['picurl']) ){
        if(strpos($vipInfo['picurl'], 'source/plugin/tom_') === FALSE){
            $vip_pic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$vipInfo['picurl'];
        }else{
            $vip_pic = $vipInfo['picurl'];
        }
    }else{
        $vip_pic = $vipInfo['picurl'];
    }
}

$myorderCount       = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_count("AND servicer_id = {$servicerInfo['id']} AND type IN(1,2,3) ");
$myneedsCount       = C::t('#tom_tcdaojia#tom_tcdaojia_needs_jie')->fetch_all_count(" AND servicer_id = {$servicerInfo['id']} ");
$mygoodsCount       = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_count(" AND servicer_id = {$servicerInfo['id']} ");

$companyRenzhengStatus = $personalRenzhengStatus = $depositStatus = 0;
if($__ShowTcrenzheng == 1){
    $companyInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_company")->fetch_by_user_id($servicerInfo['user_id']);
    if(is_array($companyInfoTmp) && $companyInfoTmp['shenhe_status'] == 1){
        $companyRenzhengStatus = 1;
    }
    $personalInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_personal")->fetch_by_user_id($servicerInfo['user_id']);
    if(is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1){
        $personalRenzhengStatus = 1;
    }
    $depositInfoTmp = C::t("#tom_tcrenzheng#tom_tcrenzheng_deposit")->fetch_by_user_id($servicerInfo['user_id']);
    if(is_array($depositInfoTmp) && $depositInfoTmp['order_status'] == 2){
        $depositStatus = 1;
    }
}

if($tcdaojiaConfig['open_ruzhu_pay_money'] == 1 && $servicerInfo['dengji_id'] > 0){
    $dengji_time    = dgmdate($servicerInfo['dengji_time'],"Y-m-d",$tomSysOffset);
    $dengjiInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_by_id($servicerInfo['dengji_id']);
}

$depositurl   = "plugin.php?id=tom_tcrenzheng&site={$site_id}&mod=deposit";
$ajaxUpdateJieStatusUrl = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&act=updatejieStatus&&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:myservicer");