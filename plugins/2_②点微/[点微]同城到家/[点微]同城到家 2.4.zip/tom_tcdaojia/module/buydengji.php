<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$servicer_id  = intval($_GET['servicer_id'])>0? intval($_GET['servicer_id']):0;

$servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($servicer_id);

$dengjiName = '';
$where = "AND status = 1 ";

$dengjiListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_all_list($where, 'ORDER BY dsort ASC, id DESC');
$dengjiList = $dengjiArr = array();
if(is_array($dengjiListTmp) && !empty($dengjiListTmp)){
    foreach($dengjiListTmp as $key => $value){
        
        if($value['xiangou_num'] > 0){
            $dengjiLogCount = C::t('#tom_tcdaojia#tom_tcdaojia_dengji_log')->fetch_all_count(" AND dengji_id = {$value['id']} AND user_id = {$__UserInfo['id']} AND type = 1 ");
            if($dengjiLogCount >= $value['xiangou_num']){
                continue;
            }
        }
        
        $dengjiArr[] = $value;
        $dengjiList[$key] = $value;
        $dengjiList[$key]['price'] = floatval($value['price']);
        
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurlTmp = $value['picurl'];
            }
        }else{
            $picurlTmp = $value['picurl'];
        }
        
        $dengjiList[$key]['picurl'] = $picurlTmp;
        
        if($servicerInfo['dengji_id'] == $value['id']){
            $dengjiName = $value['name'];
        }
    }
}

$dengjitime = dgmdate($servicerInfo['dengji_time'],"Y-m-d",$tomSysOffset);

$payDengjiUrl = "plugin.php?id=tom_tcdaojia:pay&site={$site_id}&act=dengji&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:buydengji");