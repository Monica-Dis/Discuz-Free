<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    if($__UserInfo['id'] != $tcdaojiaConfig['daojiamanage_user_id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
    }
}
# check end

if($_GET['act'] == 'shenhe' && submitcheck('needs_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $needs_id       = intval($_GET['needs_id'])>0? intval($_GET['needs_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0? intval($_GET['shenhe_status']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $needsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($needs_id);
    
    $updateData = array();
    $updateData['shenhe_status'] = $shenhe_status;
    if($shenhe_status == 1){
        $updateData['status']    = 1;
    }
    C::t('#tom_tcdaojia#tom_tcdaojia_needs')->update($needs_id,$updateData);
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);
    
    if($needsInfo){
        
        if($shenhe_status == 1){
            $shenhe = str_replace('{TITLE}', $needsInfo['content'], lang('plugin/tom_tcdaojia', 'template_tcdaojia_needs_shenhe_ok'));
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=$needsInfo&needs_id='.$needsInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }else if($shenhe_status == 3){
            $shenhe = str_replace('{TITLE}', $needsInfo['content'], lang('plugin/tom_tcdaojia', 'template_tcdaojia_needs_shenhe_no'));
            $tzShenhe = $shenhe.'<br/><font color="#8e8e8e">'.$content.'</font><br/><a href="plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=edit&needs_id='.$needsInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }
        
        $insertData = array();
        $insertData['user_id']      = $toUser['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcdaojiaConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
    }
    
    if($shenhe_status == 1 && $tcdaojiaConfig['open_auto_qunfa'] == 1){
        $qunfa_ch = curl_init();
        curl_setopt($qunfa_ch, CURLOPT_URL, $_G['siteurl']."plugin.php?id=tom_tcdaojia:qunfa&site={$site_id}&act=qunfa&needs_id={$needs_id}");
        curl_setopt($qunfa_ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($qunfa_ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($qunfa_ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($qunfa_ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($qunfa_ch, CURLOPT_HEADER, 0);
        $qunfa_return = curl_exec($qunfa_ch);
        curl_close($qunfa_ch); 
    }
        
    $access_token = $weixinClass->get_access_token();
    
    $nextSmsTime = $toUser['last_smstp_time'] + 0;
    if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime ){
        if($shenhe_status == 1){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$needsInfo['site_id']}&mod=needsinfo&needs_id=".$needsInfo['id']);
        }else if($shenhe_status == 3){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$needsInfo['site_id']}&mod=editneeds&needs_id=".$needsInfo['id']);
        }
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $updateData = array();
            $updateData['last_smstp_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerNeedsList&keyword=".urlencode(trim($keyword));
    
    echo $url;exit;
    
}else if($_GET['act'] == 'del' && submitcheck('needs_id')){
    
    $needs_id = intval($_GET['needs_id'])>0? intval($_GET['needs_id']):0;
    
    C::t('#tom_tcdaojia#tom_tcdaojia_needs')->delete_by_id($needs_id);
    C::t('#tom_tcdaojia#tom_tcdaojia_photo')->delete_by_needs_id($needs_id);    
    
    echo 200;exit;

}else if($_GET['act'] == 'shenhe_show'){
    
    $needs_id    = intval($_GET['needs_id'])>0? intval($_GET['needs_id']):0;
    $fromtype    = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage    = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $needsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($needs_id);

    $needs_shenhe_fail_str = str_replace("\r\n","{n}",$tcdaojiaConfig['needs_shenhe_fail_text']); 
    $needs_shenhe_fail_str = str_replace("\n","{n}",$needs_shenhe_fail_str);
    $needsShenheFailArray  = explode("{n}", $needs_shenhe_fail_str);

    $ajaxShenheUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerNeedsList&act=shenhe&";
    $backUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerNeedsList&type={$fromtype}&page={$frompage}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcdaojia:managerNeedsShenhe");exit;
    
}

$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$type       = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = "";
if($type == 1){
    $where.= " AND shenhe_status=2 ";
}
if($type == 2){
    $where.= " AND shenhe_status=3 ";
}
if($__UserInfo['groupid'] == 2){
    $where.= " AND site_id={$site_id} ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count         = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_all_count(" {$where} ",$keyword);
$needsListTmp  = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_all_like_list(" {$where} "," ORDER BY refresh_time DESC,id DESC ",$start,$pagesize,$keyword);
$needsList     = array();
foreach ($needsListTmp as $key => $value) {
    $needsList[$key] = $value;
    
    $cateInfoTmp      = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($value['cate_id']);
    $catechildInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($value['cate_child_id']);
    $userInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $areaInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
    $streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
    $needsphotoListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND needs_id = {$value['id']} AND type = 6 "," ORDER BY id ASC ",0,3);
    $needsphotoList = array();
    if(is_array($needsphotoListTmp) && !empty($needsphotoListTmp)){
        foreach($needsphotoListTmp as $kk => $vv){
            $picurlTmp = $vv['picurlTmp'];
            $needsphotoList[] = $picurlTmp;
        }
    }

    $needsList[$key]['photoList'] = $needsphotoList;

    $needsList[$key]['cateInfo']       = $cateInfoTmp;
    $needsList[$key]['catechildInfo']  = $catechildInfoTmp;
    $needsList[$key]['userInfo']       = $userInfoTmp;
    $needsList[$key]['areaInfo']       = $areaInfoTmp;
    $needsList[$key]['streetInfo']     = $streetInfoTmp;
    $needsList[$key]['link']           = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=needsinfo&needs_id='.$value['id'];

}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerNeedsList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerNeedsList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];
$pageUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerNeedsList&type={$type}&keyword={$keyword}";

$ajaxShenheUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerNeedsList&act=shenhe&&formhash=".$formhash;
$ajaxDelUrl    = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerNeedsList&act=del&&formhash=".$formhash;
$searchUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerNeedsList&act=get_search_url";
$ajaxQunfaUrl  = "plugin.php?id=tom_tcdaojia:qunfa&site={$site_id}&act=qunfa";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:managerNeedsList");