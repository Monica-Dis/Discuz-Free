<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$nowDayTime   = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = dgmdate($_G['timestamp'], 'Ym',$tomSysOffset);
$nowWeekTime  = dgmdate($_G['timestamp'], 'YW',$tomSysOffset);

## tchehuoren start
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')){
    $tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
    if($tchehuorenConfig['open_tchehuoren'] == 1){
        $__ShowTchehuoren = 1;
    }
}
## tchehuoren end

$money = 0;
if($orderInfo['goods_id'] > 0){
    $goodsInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($orderInfo['goods_id']);
    $sitesInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($orderInfo['site_id']);
    $sitename = $sitesInfo['name'];
    $subOrderInfoTmp = array();
    if($orderInfo['pay_ding_status'] == 1){
        $subOrderInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($orderInfo['sub_order_no']);
        if($subOrderInfoTmp && $subOrderInfoTmp['id'] > 0 && $subOrderInfoTmp['order_status'] == 2){
            $money = $orderInfo['pay_price'] + $subOrderInfoTmp['pay_price'];
        }else{
            $money = $orderInfo['pay_price'];
        }
    }else{
        $money = $orderInfo['pay_price'];
    }
    $title = $goodsInfoTmp['title'];
}elseif($orderInfo['needs_id'] > 0){
    $needsInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($orderInfo['needs_id']);
    $money = $orderInfo['pay_price'];
    $title = $needsInfoTmp['content'];
}

if($money >= 0.1){
    
    $servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($orderInfo['servicer_id']);
    $servicerVipInfo   = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_by_id($servicerInfo['vip_id']);
    $userInfoTmp  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
    
    $yongjin_bili = $tcdaojiaConfig['yongjin_bili'];
    if($servicerVipInfo && $servicerVipInfo['id'] > 0){
        $yongjin_bili = $servicerVipInfo['yongjin_bili'];
    }
    
    if($yongjin_bili <= 100){
        
        $balanceServicerUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']); 
        
        $pt_money = $money*($yongjin_bili/100);
        $pt_money = number_format($pt_money,2, '.', '');
        
        $servicer_money = $money - $pt_money;
        $fc_money = $servicer_money;
        
        if($__ShowTchehuoren == 1 && $orderInfo['tj_hehuoren_id'] > 0  && $goodsInfoTmp['hehuoren_tg_open'] == 1){
           
            $tchehuoren_fc_money = $tctchehuorenParent_fc_money = 0;
            $tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_id($orderInfo['tj_hehuoren_id']);
            if($tchehuorenInfo){
                $tchehuorenDengji = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
                if($tchehuorenInfo && $tchehuorenInfo['status'] == 1 && $tchehuorenDengji['daojia_fc_open'] == 1){
                    
                    if($goodsInfoTmp['hehuoren_tg_type'] == 1){
                        $tchehuoren_fc_money = $goodsInfoTmp['hehuoren_fc_scale'];
                    }elseif($goodsInfoTmp['hehuoren_tg_type'] == 2 && ($goodsInfoTmp['hehuoren_fc_scale'] > 0 && $goodsInfoTmp['hehuoren_fc_scale'] < 100)){
                        $tchehuoren_fc_money = $servicer_money*($goodsInfoTmp['hehuoren_fc_scale']/100);
                        $tchehuoren_fc_money = number_format($tchehuoren_fc_money,2, '.', '');
                    }
                    
                    $servicer_money = $servicer_money - $tchehuoren_fc_money;
                    
                    if($tcdaojiaConfig['subordinate_moneytype'] == 1){
                        if($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1 && $servicer_money > 0){
                            $tctchehuorenParentInfo = C::t("#tom_tchehuoren#tom_tchehuoren")->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
                            if($tctchehuorenParentInfo){
                                if($goodsInfoTmp['hehuoren_tg_type'] == 1){
                                    $tctchehuorenParent_fc_money = $goodsInfoTmp['hehuoren_fc_scale2'];
                                }elseif($goodsInfoTmp['hehuoren_tg_type'] == 2 && ($goodsInfoTmp['hehuoren_fc_scale2'] > 0 && $goodsInfoTmp['hehuoren_fc_scale2'] < 100)){
                                    $tctchehuorenParent_fc_money = $servicer_money*($goodsInfoTmp['hehuoren_fc_scale2']/100);
                                    $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                                }

                                $servicer_money = $servicer_money - $tctchehuorenParent_fc_money;
                            }
                        }
                    }elseif($tcdaojiaConfig['subordinate_moneytype'] == 2){
                        if($tchehuorenInfo['tj_hehuoren_id'] > 0 && $tchehuorenConfig['open_subordinate'] == 1 && $tchehuoren_fc_money > 0){
                            $tctchehuorenParentInfo = C::t("#tom_tchehuoren#tom_tchehuoren")->fetch_by_id($tchehuorenInfo['tj_hehuoren_id']);
                            if($tctchehuorenParentInfo){
                                if($goodsInfoTmp['hehuoren_tg_type'] == 1){
                                    $tctchehuorenParent_fc_money = $goodsInfoTmp['hehuoren_fc_scale2'];
                                }elseif($goodsInfoTmp['hehuoren_tg_type'] == 2 && ($goodsInfoTmp['hehuoren_fc_scale2'] > 0 && $goodsInfoTmp['hehuoren_fc_scale2'] < 100)){
                                    $tctchehuorenParent_fc_money = $servicer_money*($goodsInfoTmp['hehuoren_fc_scale2']/100);
                                    $tctchehuorenParent_fc_money = number_format($tctchehuorenParent_fc_money,2, '.', '');
                                }
                                if($tchehuoren_fc_money >= $tctchehuorenParent_fc_money){
                                    $tchehuoren_fc_money = $tchehuoren_fc_money - $tctchehuorenParent_fc_money;
                                }else{
                                    $tctchehuorenParent_fc_money = 0;
                                }
                            }
                        }
                    }
                }
            }

            if($fc_money >= ($tchehuoren_fc_money + $tctchehuorenParent_fc_money)){  

                $sendTemplateTchehuoren = false;
                if($tchehuoren_fc_money > 0){
                    $sendTemplateTchehuoren = true;

                    $insertData = array();
                    $insertData['order_no']         = $orderInfo['order_no'];
                    $insertData['hehuoren_id']      = $tchehuorenInfo['id'];
                    $insertData['ly_user_id']       = $userInfoTmp['id'];
                    $insertData['child_hehuoren_id'] = 0;
                    $insertData['today_time']       = $nowDayTime;
                    $insertData['week_time']        = $nowWeekTime;
                    $insertData['month_time']       = $nowMonthTime;
                    $insertData['title']            = $title;
                    $insertData['type']             = lang('plugin/tom_tcdaojia', 'hehuoren_tag_daojia');
                    $insertData['shouyi_price']     = $tchehuoren_fc_money;
                    $insertData['content']          = lang('plugin/tom_tcdaojia', 'hehuoren_beizu_1') . $orderInfo['order_no'] . lang('plugin/tom_tcdaojia', 'hehuoren_beizu_2') . $userInfoTmp['nickname'];
                    $insertData['shouyi_status']    = 1;
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                }

                $sendTemplateTchehuorenParent = false;
                if($tctchehuorenParent_fc_money > 0){
                    $sendTemplateTchehuorenParent = true;

                    $insertData = array();
                    $insertData['order_no']         = $orderInfo['order_no'];
                    $insertData['hehuoren_id']      = $tctchehuorenParentInfo['id'];
                    $insertData['ly_user_id']       = $userInfoTmp['id'];
                    $insertData['child_hehuoren_id'] = $tchehuorenInfo['id'];
                    $insertData['today_time']       = $nowDayTime;
                    $insertData['week_time']        = $nowWeekTime;
                    $insertData['month_time']       = $nowMonthTime;
                    $insertData['title']            = $title;
                    $insertData['type']             = lang('plugin/tom_tcdaojia', 'hehuoren_tag_daojia');
                    $insertData['shouyi_price']     = $tctchehuorenParent_fc_money;
                    $insertData['content']          = lang('plugin/tom_tcdaojia', 'hehuoren_beizu_1') . $orderInfo['order_no'] . lang('plugin/tom_tcdaojia', 'hehuoren_beizu_2') . $userInfoTmp['nickname'];
                    $insertData['shouyi_status']    = 1;
                    $insertData['add_time']         = TIMESTAMP;
                    C::t('#tom_tchehuoren#tom_tchehuoren_shouyi')->insert($insertData);
                }
            }
        }
        
        if($servicer_money > 0){
            $insertData = array();
            $insertData['user_id']          = $balanceServicerUserInfo['id'];
            $insertData['type_id']          = 4;
            $insertData['change_money']     = $servicer_money;
            $insertData['old_money']        = $balanceServicerUserInfo['money'];
            $insertData['tag']              = lang('plugin/tom_tcdaojia', 'daojia_money_log_tag');
            $insertData['beizu']            = lang('plugin/tom_tcdaojia', 'beizu_order_no') . $orderInfo['order_no'].'|||'.$title;
            $insertData['log_time']         = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_money_log')->insert($insertData);

            DB::query("UPDATE ".DB::table('tom_tongcheng_user')." SET money = money + {$servicer_money} WHERE id='{$balanceServicerUserInfo['id']}'", 'UNBUFFERED');
        }
        
    }

    $updateData = array();
    $updateData['balance_status'] = 1;
    C::t('#tom_tcdaojia#tom_tcdaojia_order')->update($orderInfo['id'],$updateData);
    
    if($sendTemplateTchehuoren == true){
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tchehuorenInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
            $shouyiText = str_replace("{NICKNAME}",$userInfoTmp['nickname'], lang('plugin/tom_tongcheng', 'paynotify_hehuoren_template'));
            $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
            $shouyiText = str_replace("{TYPE}",lang('plugin/tom_tcdaojia', 'hehuoren_tag_daojia'), $shouyiText);
            $shouyiText = str_replace("{MONEY}",$tchehuoren_fc_money, $shouyiText);
            $smsData = array(
                'first'         => $shouyiText,
                'keyword1'      => $tchehuorenConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );
            if(!empty($tchehuorenConfig['template_id'])){
                $template_id = $tchehuorenConfig['template_id'];
            }else{
                $template_id = $tongchengConfig['template_id'];
            }
            @$r = $templateSmsClass->sendSms01($tchehuorenInfo['openid'], $template_id, $smsData);
        }
    }

    if($sendTemplateTchehuorenParent == true){
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tctchehuorenParentInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tchehuoren&site={$orderInfo['site_id']}&mod=index");
            $shouyiText = str_replace("{TCHEHUOREN}",$tchehuorenInfo['xm'], lang('plugin/tom_tongcheng', 'paynotify_hehuorenparent_template'));
            $shouyiText = str_replace("{NICKNAME}",$userInfoTmp['nickname'], $shouyiText);
            $shouyiText = str_replace("{TONGCHNEG}",$sitename, $shouyiText);
            $shouyiText = str_replace("{TYPE}",lang('plugin/tom_tcdaojia', 'hehuoren_tag_daojia'), $shouyiText);
            $shouyiText = str_replace("{MONEY}",$tctchehuorenParent_fc_money, $shouyiText);
            $smsData = array(
                'first'         => $shouyiText,
                'keyword1'      => $tchehuorenConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );
            if(!empty($tchehuorenConfig['template_id'])){
                $template_id = $tchehuorenConfig['template_id'];
            }else{
                $template_id = $tongchengConfig['template_id'];
            }
            @$r = $templateSmsClass->sendSms01($tctchehuorenParentInfo['openid'], $template_id, $smsData);
        }
    }
}