<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$team_id      = intval($_GET['team_id'])>0? intval($_GET['team_id']):0;
$teamInfo     = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_by_id($team_id);

$servicerInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($teamInfo['servicer_id']);

if($servicerInfo['user_id'] ==  $__UserInfo['id']){}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
}

if($_GET['act'] == 'save' && submitcheck('user_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id       = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $xm            = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel           = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $desc          = isset($_GET['desc'])? addslashes($_GET['desc']):'';
    $picurl        = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';

    $updateData = array();
    $updateData['user_id']        = $user_id;
    $updateData['xm']             = $xm;
    $updateData['tel']            = $tel;
    $updateData['desc']           = $desc;
    $updateData['picurl']         = $picurl;
    if(C::t('#tom_tcdaojia#tom_tcdaojia_team')->update($team_id,$updateData)){
        
        $outArr = array(
            'status'        => 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'        => 404,
        );
        echo json_encode($outArr); exit;
    }
}

$picurl = '';
if(!preg_match('/^http/', $teamInfo['picurl']) ){
    if(strpos($teamInfo['picurl'], 'source/plugin/tom_') === FALSE){
        $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$teamInfo['picurl'];
    }else{
        $picurl = $teamInfo['picurl'];
    }
}else{
    $picurl = $teamInfo['picurl'];
}

$saveUrl       = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=edit_team&act=save";
$uploadUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=upload&act=team_pic&formhash=".FORMHASH;
$wxUploadUrl   = "plugin.php?id=tom_tcdaojia:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:edit_team");