<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$needs_id  = intval($_GET['needs_id'])>0? intval($_GET['needs_id']):0;

$needsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($needs_id);

# check start
if($needsInfo['user_id'] != $__UserInfo['id']){
    if($__UserInfo['id'] == $tcdaojiaConfig['daojiamanage_user_id']){
    }else{
        if($__UserInfo['groupid'] == 1){
        }else if($__UserInfo['groupid'] == 2){
            if($needsInfo['site_id'] == $__UserInfo['groupsiteid']){
            }else{
                tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
            }
        }else{
            tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
        }
    }
}
# check end

if($_GET['act'] == 'save' && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):1;
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
    $street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
    $price              = isset($_GET['price'])? addslashes($_GET['price']):'';
    $xm                 = isset($_GET['xm'])? daddslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? daddslashes($_GET['tel']):'';
    $wx                 = isset($_GET['wx'])? daddslashes($_GET['wx']):0;
    $fuwu_time          = isset($_GET['fuwu_time'])? addslashes($_GET['fuwu_time']):'';
    $fuwu_time          = str_replace("T", " ", $fuwu_time);
    $fuwu_time          = strtotime($fuwu_time);
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $vip_id             = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';

    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }

    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    if(!$userInfo){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
        
    $updateData = array();
    $updateData['site_id']          = $site_id;
    $updateData['type']             = $type;
    if($type == 1){
        $updateData['price']        = $price;
    }
    $updateData['xm']               = $xm;
    $updateData['tel']              = $tel;
    $updateData['wx']               = $wx;
    $updateData['fuwu_time']        = $fuwu_time;
    $updateData['vip_id']           = $vip_id;
    if($needsInfo['admin_edit'] == 0){
        $updateData['content']      = dhtmlspecialchars($content);
    }
    $updateData['area_id']          = $area_id;
    $updateData['street_id']        = $street_id;
    $updateData['address']          = $address;
    $updateData['latitude']         = $latitude;
    $updateData['longitude']        = $longitude;
    $updateData['status']           = 1;
    if($tcdaojiaConfig['fabu_needs_must_shenhe'] == 1){
        $updateData['shenhe_status']       = 2;
    }else{
        $updateData['shenhe_status']       = 1;
    }
    $updateData['refresh_time']          = TIMESTAMP;
    if(C::t('#tom_tcdaojia#tom_tcdaojia_needs')->update($needsInfo['id'],$updateData)){
        
        C::t('#tom_tcdaojia#tom_tcdaojia_photo')->delete_by_needs_id($needsInfo['id']);
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['needs_id']  = $needs_id;
                $insertData['type']      = 6;
                $insertData['picurl']    = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcdaojia#tom_tcdaojia_photo')->insert($insertData);
            }
        }
        
        if(!empty($tongchengConfig['template_id']) && $tcdaojiaConfig['fabu_needs_must_shenhe'] == 1 ){
            $toUser = array();
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $toUser = $toUserTmp;
            }

            $access_token = $weixinClass->get_access_token();

            if($access_token && !empty($toUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerNeedsList");
                $smsData = array(
                    'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcdaojia','daojia_editneeds_shenhe_msg'),
                    'keyword1'      => $tcdaojiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }

            $daojiamanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcdaojiaConfig['daojiamanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($daojiamanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerNeedsList");
                $smsData = array(
                    'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcdaojia','daojia_editneeds_shenhe_msg'),
                    'keyword1'      => $tcdaojiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($daojiamanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
}

$fuwu_time        = dgmdate($needsInfo['fuwu_time'],'Y-m-d H:i:s',$tomSysOffset);
$fuwu_time        = str_replace(" ", "T", $fuwu_time);

$photoListTmp = C::t("#tom_tcdaojia#tom_tcdaojia_photo")->fetch_all_list(" AND needs_id={$needs_id} AND type = 6 ", 'ORDER BY id ASC', 0, 50);
$photoList = array();
$photoCount = 0;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];
        $photoList[$key] = $value;
        $photoList[$key]['picurlTmp'] = $picurlTmp;
        $photoCount++;
        $photoList[$key]['li_i'] = $photoCount;
        
    }
}

$vipListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_all_list(" "," ORDER BY vsort ASC,id DESC ",0,50);
$vipList = array();
if(is_array($vipListTmp) && !empty($vipListTmp)){
    foreach ($vipListTmp as $key => $value){
        $vipList[$key] = $value;
    }
}

$cateInfo = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($needsInfo['cate_id']);
$cateChildInfo = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($needsInfo['cate_child_id']);

$cateArr = array();
$cateList = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,100);
$i = 0;
if(is_array($cateList) && !empty($cateList)){
    foreach ($cateList as $key => $value){
        $cateArr[$i]['id'] = $value['id'];
        $cateArr[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $childCateList = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid={$value['id']} "," ORDER BY csort ASC,id DESC ",0,100);
        $j = 0;
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $kk => $vv){
                $cateArr[$i]['sub'][$j]['id'] = $vv['id'];
                $cateArr[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cateData = urlencode(json_encode($cateArr));

$areaInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($needsInfo['area_id']);
$streetInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($needsInfo['street_id']);

$areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$cityList = array();
$cityList[0]['id'] = 0;
$cityList[0]['name'] = diconv(lang('plugin/tom_tcdaojia', 'buxian'),CHARSET,'utf-8');
$cityList[0]['sub'][0]['id'] = 0;
$cityList[0]['sub'][0]['name'] = '';
$i = 1;
if(is_array($areaList) && !empty($areaList)){
    foreach ($areaList as $key => $value){
        $cityList[$i]['id'] = $value['id'];
        $cityList[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $j = 0;
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $cityList[$i]['sub'][$j]['id'] = $vv['id'];
                $cityList[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cityData = urlencode(json_encode($cityList));

$minDateTime = TIMESTAMP-60;
$minDateTime = dgmdate($minDateTime,"Y-m-d H:0:0",$tomSysOffset);
$maxDateTime = TIMESTAMP + 365*86400;
$maxDateTime = dgmdate($maxDateTime,"Y-m-d H:i:s",$tomSysOffset);

$saveUrl        = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=editneeds&needs_id={$needs_id}&act=save";
$uploadUrl3     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=upload&act=needs_photo&formhash=".FORMHASH;
$wxUploadUrl    = "plugin.php?id=tom_tcdaojia:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$ossBatchUrl    = 'plugin.php?id=tom_tcdaojia:ossBatch';
$qiniuBatchUrl  = 'plugin.php?id=tom_tcdaojia:qiniuBatch';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:editneeds");