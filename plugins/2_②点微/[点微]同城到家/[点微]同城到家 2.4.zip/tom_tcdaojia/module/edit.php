<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$servicer_id  = isset($_GET['servicer_id'])? intval($_GET['servicer_id']):'';
$servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($servicer_id);

# check start
if($servicerInfo['user_id'] != $__UserInfo['id']){
    if($__UserInfo['id'] == $tcdaojiaConfig['daojiamanage_user_id']){
    }else{
        if($__UserInfo['groupid'] == 1){
        }else if($__UserInfo['groupid'] == 2){
            if($servicerInfo['site_id'] == $__UserInfo['groupsiteid']){
            }else{
                tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
            }
        }else{
            tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
        }
    }
}
# check end

if($_GET['act'] == 'save' && submitcheck('user_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):1;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $xm                 = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $wxpicurl           = isset($_GET['wxpicurl'])? addslashes($_GET['wxpicurl']):'';
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    
    $cate_ids = '';
    if(is_array($_GET['cate_ids']) && !empty($_GET['cate_ids'])){
        $cate_ids = implode('|', $_GET['cate_ids']);
    }
    
    $area_ids = '';
    if(is_array($_GET['area_ids']) && !empty($_GET['area_ids'])){
        $area_ids_arr = array_unique($_GET['area_ids']);
        $area_ids = implode('|', $area_ids_arr);
    }
    
    $street_ids = '';
    if(is_array($_GET['street_ids']) && !empty($_GET['street_ids'])){
        $street_ids_arr = array_unique($_GET['street_ids']);
        $street_ids = implode('|', $street_ids_arr);
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
   
    $updateData = array();
    $updateData['site_id']            = $site_id;
    $updateData['user_id']            = $servicerInfo['user_id'];
    $updateData['type']               = $type;
    $updateData['name']               = $name;
    $updateData['xm']                 = $xm;
    $updateData['tel']                = $tel;
    $updateData['start_time']         = $start_time;
    $updateData['end_time']          = $end_time;
    $updateData['cate_ids']           = '|'.$cate_ids.'|';
    $updateData['address']            = $address;
    $updateData['latitude']           = $latitude;
    $updateData['longitude']          = $longitude;
    if($servicerInfo['admin_edit'] == 0){
        $updateData['content']        = dhtmlspecialchars($content);
    }
    $updateData['area_ids']           = '|'.$area_ids.'|';
    $updateData['street_ids']         = '|'.$street_ids.'|';
    $updateData['status']             = 1;
    if($tcdaojiaConfig['ruzhu_must_shenhe'] == 1){
        $updateData['shenhe_status']       = 2;
    }else{
        $updateData['shenhe_status']       = 1;
    }
    $updateData['refresh_time']           = TIMESTAMP;

    if(C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->update($servicerInfo['id'],$updateData)){

        $servicerInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($servicerInfo['id']);
        
        C::t('#tom_tcdaojia#tom_tcdaojia_photo')->delete_by_servicer_id($servicerInfo['id']);
        
        DB::query("UPDATE ".DB::table('tom_tcdaojia_goods')." SET latitude='{$servicerInfo['latitude']}',longitude='{$servicerInfo['longitude']}',address='{$servicerInfo['address']}' WHERE servicer_id = {$servicerInfo['id']} ", 'UNBUFFERED');
        
        if(!empty($picurl)){
            $insertData = array();
            $insertData['servicer_id']  = $servicerInfoTmp['id'];
            $insertData['type']         = 3;
            $insertData['picurl']       = $picurl;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tcdaojia#tom_tcdaojia_photo')->insert($insertData);
        }
        
        if(!empty($wxpicurl)){
            $insertData = array();
            $insertData['servicer_id']  = $servicerInfoTmp['id'];
            $insertData['type']         = 4;
            $insertData['picurl']       = $wxpicurl;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tcdaojia#tom_tcdaojia_photo')->insert($insertData);
        }

        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['servicer_id']   = $servicerInfoTmp['id'];
                $insertData['type']          = 5;
                $insertData['picurl']        = $value;
                $insertData['add_time']      = TIMESTAMP;
                C::t('#tom_tcdaojia#tom_tcdaojia_photo')->insert($insertData);
            }
        }

        if(!empty($tongchengConfig['template_id']) && $tcdaojiaConfig['ruzhu_must_shenhe'] == 1 ){
            $toUser = array();
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $toUser = $toUserTmp;
            }

            $access_token = $weixinClass->get_access_token();

            if($access_token && !empty($toUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList");
                $smsData = array(
                    'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcdaojia','daojia_edit_shenhe_msg'),
                    'keyword1'      => $tcdaojiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }

            $daojiamanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcdaojiaConfig['daojiamanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($daojiamanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList");
                $smsData = array(
                    'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcdaojia','daojia_edit_shenhe_msg'),
                    'keyword1'      => $tcdaojiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($daojiamanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }

        $outArr = array(
            'status'        => 200,
            'servicer_id'  => $servicerInfoTmp['id'],
        );
        echo json_encode($outArr); exit;

    }else{
        $outArr = array(
            'status'        => 404,
        );
        echo json_encode($outArr); exit;
    }
}

$photoListTmp = C::t("#tom_tcdaojia#tom_tcdaojia_photo")->fetch_all_list(" AND servicer_id={$servicerInfo['id']} ", 'ORDER BY id ASC', 0, 50);
$photoList = array();
$picurl  = $picurl_src = $wxpicurl  = $wxpicurl_src = '';
$photoCount = 0;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];
        if($value['type'] == 3){
            $picurl = $value['picurl'];
            $picurl_src = $value['picurlTmp'];
        }else if($value['type'] == 4){
            $wxpicurl = $value['picurl'];
            $wxpicurl_src = $value['picurlTmp'];
        }else if($value['type'] == 5){
            $photoList[$key] = $value;
            $photoList[$key]['picurlTmp'] = $picurlTmp;
            $photoCount++;
            $photoList[$key]['li_i'] = $photoCount;
        }
    }
}

$cate_ids_str = $servicerInfo['cate_ids'];
$cate_ids_str = substr($cate_ids_str, 1, -1);
$cate_ids_arr = array();
if(!empty($servicerInfo['cate_ids'])){
    $cate_ids_arr = explode('|', $cate_ids_str);
}

$cateListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid = 0 ", "ORDER BY csort ASC,id ASC", 0, 100);
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach ($cateListTmp as $key => $value){
        $cateList[$key] = $value;
        if(in_array($value['id'], $cate_ids_arr)){
            $cateList[$key]['status'] = 1;
        }
    }
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$areaList = array();
if(is_array($areaListTmp) && !empty($areaListTmp)){
    foreach ($areaListTmp as $key => $value){
        $areaList[$key] = $value;

        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $streetList = array();
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $streetList[$kk] = $vv;
            }
        }
        $areaList[$key]['streetList'] = $streetList;
        
    }
}


$street_ids = substr($servicerInfo['street_ids'], 1, -1);
$street_ids_arr = explode("|", $street_ids);
$street_ids = str_replace("all", "", $street_ids);
$street_ids = str_replace("|", ",", $street_ids);

$area_street_list = array();
if(!empty($street_ids)){
    $streetsList = array();
    $streetsListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_list(" AND id IN ({$street_ids}) ");
    if(is_array($streetsListTmp) && !empty($streetsListTmp)){
        foreach ($streetsListTmp as $key => $value) {
            $streetsList[$value['id']] = $value;
        }
    }
}

$area_num  = 0;
if(is_array($street_ids_arr) && !empty($street_ids_arr)){
    foreach ($street_ids_arr as $key => $value) {
        if(strpos($value, "all") !== false){
            $value = str_replace("all", "", $value);
            if(isset($streetsList[$value])){
                $area_street_list[$key] = $streetsList[$value];
                $area_street_list[$key]['all'] = 1;
                $area_num++;
            }
        }else if(isset($streetsList[$value])){
            $area_street_list[$key] = $streetsList[$value];
            $area_num++;
        }
    }
}

$saveUrl       = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=edit&act=save";
$uploadUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=upload&act=servicer_wxpic&formhash=".FORMHASH;
$uploadUrl1    = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=upload&act=servicer_pic&formhash=".FORMHASH;
$uploadUrl2    = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=upload&act=servicer_photo&formhash=".FORMHASH;
$wxUploadUrl   = "plugin.php?id=tom_tcdaojia:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$ossBatchUrl   = 'plugin.php?id=tom_tcdaojia:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcdaojia:qiniuBatch';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:edit");