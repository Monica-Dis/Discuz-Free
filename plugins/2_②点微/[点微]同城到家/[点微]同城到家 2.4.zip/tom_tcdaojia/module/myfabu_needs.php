<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       = intval($_GET['type'])>0? intval($_GET['type']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';

$whereStr = " AND user_id = {$__UserInfo['id']} ";

if($type == 1){
    $whereStr.=" AND status = 1 AND shenhe_status = 1 ";
}else if($type == 2){
    $whereStr.=" AND status != 1 AND shenhe_status = 1 ";
}else if($type == 3){
    $whereStr.=" AND (shenhe_status = 2 OR shenhe_status = 3 ) ";
}

$pagesize     = 8;
$start        = ($page - 1)*$pagesize;
$order        = " ORDER BY refresh_time DESC,id DESC ";
$count        = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_all_count($whereStr,$keyword);
$needsListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_all_like_list($whereStr,$order,$start,$pagesize,$keyword);
$needsList = array();
foreach ($needsListTmp as $key => $value){
    $needsList[$key] = $value;
    if($value['top_status'] == 1 && $value['top_time'] <= TIMESTAMP){
        $updateData = array();
        $updateData['top_status']   = 0;
        $updateData['top_time']     = 0;
        C::t('#tom_tcdaojia#tom_tcdaojia_needs')->update($value['id'], $updateData);
    }
    $needsphotoListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND needs_id = {$value['id']} AND type = 6 "," ORDER BY id ASC ",0,3);
    $needsphotoList = array();
    if(is_array($needsphotoListTmp) && !empty($needsphotoListTmp)){
        foreach($needsphotoListTmp as $kk => $vv){
            $picurlTmp = $vv['picurlTmp'];
            $needsphotoList[] = $picurlTmp;
        }
    }

    $needsList[$key]['photoList'] = $needsphotoList;
    $userInfoTmp  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $jieCount     = C::t('#tom_tcdaojia#tom_tcdaojia_needs_jie')->fetch_all_count("AND needs_id = {$value['id']}");
    $needsList[$key]['userInfo'] = $userInfoTmp;
    $needsList[$key]['jieCount'] = $jieCount;
    $needsList[$key]['refresh_time'] = dgmdate($value['refresh_time'], 'm-d H:i:s',$tomSysOffset);
    $needsList[$key]['link']   = 'plugin.php?id=tom_tcdaojia&site='.$value['site_id'].'&mod=needsinfo&needs_id='.$value['id'];
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=myfabu_needs&type={$type}&page={$prePage}&keyword={$keyword}";
$nextPageUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=myfabu_needs&type={$type}&page={$nextPage}&keyword={$keyword}";
$pageUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=myfabu_needs&type={$type}&keyword={$keyword}";

$ajaxUpdateneedsStatusUrl = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&act=updateneedsStatus&&formhash=".$formhash;
$ajaxRefreshneedsUrl      = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&act=refreshNeeds&&formhash=".$formhash;

$searchUrl  = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&act=get_myneedslist_search_url&type={$type}&keyword={$keyword}";
$shareUrl   = $_G['siteurl']."plugin.php?id=tom_tcdaojia&site=".$site_id."&mod=myfabu";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:myfabu_needs");