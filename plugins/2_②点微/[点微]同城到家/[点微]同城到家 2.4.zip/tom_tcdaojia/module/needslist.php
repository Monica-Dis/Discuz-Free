<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword            = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$cate_id            = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$cate_child_id      = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):1;
$needs_type         = intval($_GET['needs_type'])>0? intval($_GET['needs_type']):0;
$vip_id             = intval($_GET['vip_id'])>0? intval($_GET['vip_id']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$latitude  = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$whereStr = " AND status=1 AND shenhe_status=1  ";

if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if($area_id > 0){
    $whereStr.= " AND area_id = {$area_id}";
}
if($street_id > 0){
    $whereStr .= " AND street_id = {$street_id}";
}
if($cate_id > 0){
    $whereStr .= " AND cate_id = {$cate_id}";
}
if($cate_child_id > 0){
    $whereStr .= " AND cate_child_id = {$cate_child_id}";
}
if($needs_type > 0){
    $whereStr .= " AND type = {$needs_type}";
}
if($vip_id > 0){
    $whereStr .= " AND vip_id = {$vip_id}";
}

if($paixu_type == 1){
    $orderStr = "ORDER BY top_status DESC,finish ASC,refresh_time DESC,id DESC";
}elseif($paixu_type == 2){
    $orderStr = "ORDER BY refresh_time DESC,id DESC";
}

$pagesize       = $pagesize;
$start          = ($page - 1)*$pagesize;

if($paixu_type == 3 && !empty($latitude) && !empty($longitude)){
    $needsListTmp  = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_all_nearby_list($whereStr,$start,$pagesize,$latitude,$longitude);
}else{
    $needsListTmp  = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_all_like_list($whereStr,$orderStr,$start,$pagesize,$keyword);
}

$needsList = array();
foreach ($needsListTmp as $key => $value){

    $needsList[$key] = $value;

    $userInfoTmp      = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $catechildInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($value['cate_child_id']);
    $areaInfoTmp      = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['area_id']);
    $streetInfoTmp    = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($value['street_id']);
    $vipInfoTmp       = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_by_id($value['vip_id']);

    $needsphotoListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND needs_id = {$value['id']} AND type = 6 "," ORDER BY id ASC ",0,10);
    $needsphotoList = array();
    $needsphotoListStr = '';
    if(is_array($needsphotoListTmp) && !empty($needsphotoListTmp)){
        foreach($needsphotoListTmp as $kk => $vv){
            $picurlTmp = $vv['picurlTmp'];
            $needsphotoList[] = $picurlTmp;
        }
        $needsphotoListStr = implode('|', $needsphotoList);
    }

    $needsList[$key]['photoList'] = $needsphotoList;
    $needsList[$key]['vipInfo']   = $vipInfoTmp;
    $needsList[$key]['catechildInfo']   = $catechildInfoTmp;
    $needsList[$key]['areaInfo']   = $areaInfoTmp;
    $needsList[$key]['streetInfo'] = $streetInfoTmp;
    $needsList[$key]['userInfo']   = $userInfoTmp;
    $needsList[$key]['link'] = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=needsinfo&needs_id='.$value['id'];
}

if(is_array($needsList) && !empty($needsList)){
    foreach ($needsList as $key => $val){

        $outStr .= '<div class="needs-item">';
            $outStr .= '<a href="'.$val['link'].'">';
            $outStr .= '<div class="needs-item_top dislay-flex">';
                $outStr .= '<div class="needs-item_top_left">';
                    $outStr .= '<img src="'.$val['userInfo']['picurl'].'">';
                $outStr .= '</div>';
                $outStr .= '<div class="needs-item_top_right">';
                    $outStr .= '<div class="needs-xm">';
                        if($val['top_status'] == 1){
                             $outStr.= '<span class="top">'.lang('plugin/tom_tongcheng', 'top').'</span>';
                        }
                        $outStr .= '<span class="right">'.$val['userInfo']['nickname'].'</span>';
                    $outStr .= '</div>';
                    $outStr .= '<div class="needs-address dislay-flex">';
                        if($val['area_id'] > 0){
                            $outStr .= '<span class="needs-area">'.$val['areaInfo']['name'].$val['streetInfo']['name'].'</span>';
                        }
                        if($val['area_id'] > 0){
                            $outStr .= '<span class="needs-time area">'.dgmdate($val['add_time'], 'u','9999','m-d H:i').'</span>';
                        }else{
                            $outStr .= '<span class="needs-time">'.dgmdate($val['add_time'], 'u','9999','m-d H:i').'</span>';
                        }
                        if($paixu_type == 3 && !empty($latitude) && !empty($longitude)){
                            $juli = tomGetDistance($longitude, $latitude, $val['longitude'], $val['latitude']);
                            $outStr .= '<span class="needs-time area" style="border-left: 1px solid #9a9a9a;margin-left: 8px;">'.$juli.'km</span>';
                        }
                    $outStr .= '</div>';
                $outStr .= '</div>';
                $outStr .= '<div class="needs-item_top_cate">';
                    $outStr .= '<span class="needs-cate" style="color: '.$tcdaojiaConfig['template_color'].';">'.$val['catechildInfo']['name'].'';
                    $outStr .= '</span>';
                $outStr .= '</div>';
            $outStr .= '</div>';
            if($val['fuwu_time'] > 0){
                $outStr .= '<div class="needs-item_fuwu_time">';
                    $outStr .= '<span class="left">'.lang("plugin/tom_tcdaojia", 'needs_fuwu_time').':</span>';
                    $outStr .= '<span class="right">'.dgmdate($val['fuwu_time'], 'Y-m-d H:s',$tomSysOffset).'</span>';
                $outStr .= '</div>';
            }
            $outStr .= '<div class="needs-item_content_msg">'.$val['content'].'</div>';
            $outStr .= '</a>';
            if(is_array($val['photoList']) && !empty($val['photoList'])){
                $photoListCount = count($val['photoList']);
                $outStr.= '<div class="needs-item_pic clearfix"><input type="hidden" name="photo_list" class="photo_list" value="'.implode('|', $val['photoList']).'">';

                $list_xz_pic_num = 3;
                $i_photo = 0;

                foreach ($val['photoList'] as $k3 => $v3){
                    $i_photo++;
                    if($i_photo == $list_xz_pic_num && $photoListCount > $list_xz_pic_num){
                        $outStr.= '<a href="javascript:void(0);" onclick="showPicList($(this),'.($i_photo - 1).');"><img src="'.$v3.'"><span class="more-pic">'.lang("plugin/tom_tongcheng", 'template_more_pic_1').'<br/>'.lang("plugin/tom_tongcheng", 'template_more_pic_2').'</span></a>';
                    }else if($i_photo >= ($list_xz_pic_num + 1)){
                        continue;
                    }else{
                        $outStr.= '<a href="javascript:void(0);" onclick="showPicList($(this),'.($i_photo - 1).');"><img src="'.$v3.'"></a>';
                    }
                }
                $outStr.= '</div>';
            }
            $outStr .= '<a href="'.$val['link'].'">';
            $outStr .= '<div class="needs-item_bottom dislay-flex">';
                $outStr .= '<div class="needs_price flex">';
                if($val['type'] == 1){
                    $outStr .= '<span class="left">'.lang('plugin/tom_tcdaojia','needs_type_1').'</span>';
                    if($val['price'] > 0){
                        $outStr .= '<span class="icon">'.lang('plugin/tom_tcdaojia','yuan_ico').'</span>';
                        $outStr .= '<span class="right">'.$val['price'].'</span>';
                    }
                }else if($val['type'] == 2){
                    $outStr .= '<span class="left needs_type2">'.lang('plugin/tom_tcdaojia','needs_type_2').'</span>';
                }
                $outStr .= '</div>';
                if($val['finish'] == 1){
                    $outStr .= '<div class="needs_finish">';
                        $outStr .= '<span>'.lang('plugin/tom_tcdaojia','needslist_finish').'</span>';
                    $outStr .= '</div>';
                }else{
                    $outStr .= '<div class="needs_contact">';
                        $outStr .= '<span>'.lang('plugin/tom_tcdaojia','needslist_go_servicer').'</span>';
                    $outStr .= '</div>';
                }
            $outStr .= '</div>';
            $outStr .= '</a>';
        $outStr .= '</div>';
    }
}else{
    $outStr = '205';
}
$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;