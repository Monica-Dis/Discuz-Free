<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_no   = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';

$orderInfo     = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($order_no);
$servicerInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($orderInfo['servicer_id']);

if($orderInfo['is_weikuan'] == 1){
    $upOrderInfo = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_sub_order_no($orderInfo['order_no']);
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=myorderinfo&order_no={$upOrderInfo['order_no']}");exit;
}

if($servicerInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
}

if($orderInfo['goods_id'] > 0){
    $goodsInfo      = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($orderInfo['goods_id']);
}
if($orderInfo['needs_id'] > 0){
    $needsInfo      = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($orderInfo['needs_id']);
}

if($_GET['act'] == 'queren' && submitcheck('order_no')){
    
    DB::query("UPDATE ".DB::table('tom_tcdaojia_order')." SET order_status=3 WHERE id = {$orderInfo['id']} ", 'UNBUFFERED');

    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
    
    $template_queren_first = str_replace("{XM}",$servicerInfo['name'], lang('plugin/tom_tcdaojia','template_tcdaojia_queren'));
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($toUser['openid']) ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=order&type=3");
        $smsData = array(
            'first'         => $template_queren_first,
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
    }
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'wancheng' && submitcheck('order_no')){
    
    $updateData = array();
    $updateData['order_status']     = 4;
    $updateData['hexiao_user_id']   = $__UserInfo['id'];
    $updateData['hexiao_time']      = TIMESTAMP;
    C::t('#tom_tcdaojia#tom_tcdaojia_order')->update($orderInfo['id'],$updateData);
    
    $insertData = array();
    $insertData['order_id']        = $orderInfo['id'];
    $insertData['user_id']         = $orderInfo['user_id'];
    $insertData['hexiao_num']      = $orderInfo['goods_num'];
    $insertData['hexiao_user_id']  = $__UserInfo['id'];
    $insertData['hexiao_time']     = TIMESTAMP;
    C::t('#tom_tcdaojia#tom_tcdaojia_order_hexiao_log')->insert($insertData);
    
    DB::query("UPDATE ".DB::table('tom_tcdaojia_servicer')." SET jie_num=jie_num + 1 WHERE id = {$orderInfo['servicer_id']} ", 'UNBUFFERED');
    
    update_vip_id($orderInfo['servicer_id']);
    
    if($orderInfo['balance_status'] == 0){
        include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/module/balance.php';
    }
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']);
    
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($toUser['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=myorder");
        $smsData = array(
            'first'         => lang('plugin/tom_tcdaojia','template_wancheng_service'),
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
    }
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'change_fuwutime' && submitcheck('fuwu_time')){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $fuwu_time          = isset($_GET['fuwu_time'])? addslashes($_GET['fuwu_time']):'';
    $fuwu_time          = str_replace("T", " ", $fuwu_time);
    $fuwu_time          = strtotime($fuwu_time);

    DB::query("UPDATE ".DB::table('tom_tcdaojia_order')." SET fuwu_time={$fuwu_time} WHERE id = {$orderInfo['id']} ", 'UNBUFFERED');
    
    $toUser   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
        
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($toUser['openid']) ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=orderinfo&order_no={$order_no}");
        $smsData = array(
            'first'         => lang('plugin/tom_tcdaojia','template_tcdaojia_servicer_change'),
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
    }
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}else if($_GET['act'] == 'change_wei_price' && submitcheck('wei_price')){
    $outArr = array(
        'status'=> 1,
    );

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $wei_price  = isset($_GET['wei_price'])? floatval($_GET['wei_price']):0;

    DB::query("UPDATE ".DB::table('tom_tcdaojia_order')." SET wei_price={$wei_price} WHERE id = {$orderInfo['id']} ", 'UNBUFFERED');
    
    $toUser   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']); 
        
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($toUser['openid']) ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=orderinfo&order_no={$order_no}");
        $smsData = array(
            'first'         => lang('plugin/tom_tcdaojia','template_tcdaojia_servicer_change_wei_price'),
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
    }
    
    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;

}

$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);

if($orderInfo['goods_id'] > 0 ){
    $photoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list("AND goods_id = {$goodsInfo['id']} AND type = 1","",0,1);
}elseif($orderInfo['needs_id'] > 0){
    $photoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list("AND needs_id = {$needsInfo['id']} AND type = 6","",0,1);
}

if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
    $picurl = $photoInfoTmp[0]['picurlTmp'];
}else{
    $picurl = $userInfo['picurl'];
}

$order_time    = dgmdate($orderInfo['order_time'],"Y-m-d H:i",$tomSysOffset);
$hexiao_time   = dgmdate($orderInfo['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
$fuwu_time     = dgmdate($orderInfo['fuwu_time'],"Y-m-d H:i",$tomSysOffset);

$minDateTime = TIMESTAMP-60;
$minDateTime = dgmdate($minDateTime,"Y-m-d H:0:0",$tomSysOffset);
$maxDateTime = TIMESTAMP + 365*86400;
$maxDateTime = dgmdate($maxDateTime,"Y-m-d H:i:s",$tomSysOffset);

$showWanchengBtn = 0;
if($orderInfo['order_status'] == 3){
    if(TIMESTAMP > ($orderInfo['fuwu_time'] + 86400 * $tcdaojiaConfig['shop_wancheng_days'])){
        $showWanchengBtn = 1;
    }
}

$subOrderInfo = array();
if(!empty($orderInfo['sub_order_no'])){
    $subOrderInfo = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($orderInfo['sub_order_no']); 
}

$hexiaoUserInfo = array();
if($orderInfo['order_status'] == 4){
    $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']); 
}

$open_wx_map = 0;
if($__IsWeixin == 1 && $tcdaojiaConfig['open_wx_map'] == 1){
    $open_wx_map = 1;
}

if($orderInfo['needs_id'] > 0){
    $baiduMapToName = $needsInfo['content'];
    $latitude  =  $needsInfo['latitude'];
    $longitude =  $needsInfo['longitude'];
    $address   =  $needsInfo['address'];
}
$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
$baiduMapToName = urlencode($baiduMapToName);
if($orderInfo['needs_id'] > 0){
    $baiduMapToAddress = $needsInfo['address'];
}
$baiduMapToAddress = diconv($baiduMapToAddress, CHARSET, 'utf-8');
$baiduMapToAddress = urlencode($baiduMapToAddress);
if($orderInfo['needs_id'] > 0){
    $baiduMapUrl = "http://api.map.baidu.com/marker?location={$needsInfo['latitude']},{$needsInfo['longitude']}&title={$baiduMapToName}&content={$baiduMapToAddress}&output=html";
}

$teamCount = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_all_count("AND servicer_id = {$servicerInfo['id']} ");
$teamListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_all_list("AND servicer_id = {$servicerInfo['id']} AND is_hidden = 0");

$teamList = array();
$i = 1;
foreach ($teamListTmp as $key => $value){
    $teamList[$key] = $value;
    if($i == 1){
        $teamList[$key]['checked'] = 1;
    }
    $i++;
    if(!preg_match('/^http/', $value['picurl']) ){
        if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
            $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $picurlTmp = $value['picurl'];
        }
    }else{
        $picurlTmp = $value['picurl'];
    }

    $teamList[$key]['picurl'] = $picurlTmp;
}

if($orderInfo['team_status'] == 1){
    $teamInfo = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_by_id($orderInfo['team_id']);
    $team_pic = '';
    if(!preg_match('/^http/', $teamInfo['picurl']) ){
        if(strpos($teamInfo['picurl'], 'source/plugin/tom_') === FALSE){
            $team_pic = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$teamInfo['picurl'];
        }else{
            $team_pic = $teamInfo['picurl'];
        }
    }else{
        $team_pic = $teamInfo['picurl'];
    }
}

$ajaxhexiaologlistUrl  = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&order_no={$orderInfo['order_no']}&act=hexiaologlist";
$changeTimeUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=myorderinfo&act=change_fuwutime&order_no={$order_no}";
$changeWei_priceUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=myorderinfo&act=change_wei_price&order_no={$order_no}";
$querenUrl   = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=myorderinfo&act=queren&order_no='.$order_no.'&formhash='.$formhash;
$wanchengUrl = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=myorderinfo&act=wancheng&order_no='.$order_no.'&formhash='.$formhash;
$chooseAjaxUrl = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&act=chooseTeam&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:myorderinfo");