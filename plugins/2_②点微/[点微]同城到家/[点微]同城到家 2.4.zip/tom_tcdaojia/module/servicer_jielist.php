<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type = intval($_GET['type'])> 0? intval($_GET['type']):0;
$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$servicerInfo    = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_user_id($__UserInfo['id']);

$whereStr = " AND servicer_id = {$servicerInfo['id']}  ";
if($type == 1){
    $whereStr .= " AND status = 0 ";
}else if($type == 2){
    $whereStr .= " AND status = 1 ";
}else if($type == 3){
    $whereStr .= " AND status = 2 ";
}

$orderStr = " ORDER BY refresh_time DESC,id DESC ";

$pagesize = 10;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcdaojia#tom_tcdaojia_needs_jie')->fetch_all_count($whereStr);
$jielogListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_needs_jie')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);

$jielogList = array();
foreach ($jielogListTmp as $key => $value){
    $jielogList[$key] = $value;

    $needsInfoTmp      = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($value['needs_id']);
    $catechildInfoTmp  = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($needsInfoTmp['cate_child_id']);
   
    $jielogList[$key]['needsInfo']       = $needsInfoTmp;
    $jielogList[$key]['catechildInfo']   = $catechildInfoTmp;
    $jielogList[$key]['fuwu_time']       = dgmdate($needsInfoTmp['fuwu_time'],"Y-m-d H:i",$tomSysOffset);
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum  = ceil($count/$pagesize);
$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=order&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=order&type={$type}&page={$nextPage}";
$pageUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=order&type={$type}";

$ajaxQuxiaoStatusUrl = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&act=needs_jie_quxiao&type=1&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:servicer_jielist");