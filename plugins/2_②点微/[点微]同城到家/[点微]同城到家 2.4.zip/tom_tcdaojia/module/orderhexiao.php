<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$hexiao_no  = isset($_GET['hexiao_no'])? addslashes($_GET['hexiao_no']):'';

$orderInfo     = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_hexiao_no($hexiao_no);
$servicerInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($orderInfo['servicer_id']);

if($orderInfo['is_weikuan'] == 1){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
}

if($orderInfo && $orderInfo['id'] > 0){}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
}

if($orderInfo['goods_id'] > 0){
    $goodsInfo      = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($orderInfo['goods_id']);
}
if($orderInfo['needs_id'] > 0){
    $needsInfo      = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($orderInfo['needs_id']);
}

$showHexiaoBox = 2;
if($orderInfo['team_status'] == 1 && $orderInfo['team_id'] > 0){
    $teamInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_by_id($orderInfo['team_id']);
    if($teamInfo['user_id'] == $__UserInfo['id']){
        $showHexiaoBox = 1;
    }
}
if($servicerInfo['user_id'] == $__UserInfo['id']){
    $showHexiaoBox = 1;
}

if($_GET['act'] == 'hexiao' && $showHexiaoBox ==  1 && $_GET['formhash'] == FORMHASH){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $hexiao_beizu    = isset($_GET['hexiao_beizu'])? addslashes($_GET['hexiao_beizu']):'';
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $updateData = array();
    $updateData['order_status']     = 4;
    $updateData['hexiao_user_id']   = $__UserInfo['id'];
    $updateData['hexiao_time']      = TIMESTAMP;
    C::t('#tom_tcdaojia#tom_tcdaojia_order')->update($orderInfo['id'],$updateData);

    $insertData = array();
    $insertData['order_id']        = $orderInfo['id'];
    $insertData['user_id']         = $orderInfo['user_id'];
    $insertData['hexiao_num']      = $orderInfo['goods_num'];
    $insertData['hexiao_user_id']  = $__UserInfo['id'];
    $insertData['hexiao_beizu']    = $hexiao_beizu;
    $insertData['hexiao_time']     = TIMESTAMP;
    C::t('#tom_tcdaojia#tom_tcdaojia_order_hexiao_log')->insert($insertData);
    $hexiao_log_id = C::t('#tom_tcdaojia#tom_tcdaojia_order_hexiao_log')->insert_id();

    if(is_array($photoArr) && !empty($photoArr)){
        foreach ($photoArr as $key => $value){
            $insertData = array();
            $insertData['hexiao_log_id']  = $hexiao_log_id;
            $insertData['type']      = 7;
            $insertData['picurl']    = $value;
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcdaojia#tom_tcdaojia_photo')->insert($insertData);
        }
    }

    DB::query("UPDATE ".DB::table('tom_tcdaojia_servicer')." SET jie_num=jie_num + 1 WHERE id = {$orderInfo['servicer_id']} ", 'UNBUFFERED');

    update_vip_id($orderInfo['servicer_id']);

    if($orderInfo['balance_status'] == 0){
        include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/module/balance.php';
    }

    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']);

    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($toUser['openid'])  ){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=myorder");
        $smsData = array(
            'first'         => lang('plugin/tom_tcdaojia','template_wancheng_service'),
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
            'remark'        => ''
        );
        $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
    }
    echo 200;exit;
}

$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);

if($orderInfo['goods_id'] > 0 ){
    $photoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list("AND goods_id = {$goodsInfo['id']} AND type = 1","",0,1);
}elseif($orderInfo['needs_id'] > 0){
    $photoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list("AND needs_id = {$needsInfo['id']} AND type = 6","",0,1);
}

if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
    $picurl = $photoInfoTmp[0]['picurlTmp'];
}else{
    $picurl = $userInfo['picurl'];
}

$order_time    = dgmdate($orderInfo['order_time'],"Y-m-d H:i",$tomSysOffset);
$hexiao_time   = dgmdate($orderInfo['hexiao_time'],"Y-m-d H:i",$tomSysOffset);
$fuwu_time     = dgmdate($orderInfo['fuwu_time'],"Y-m-d H:i",$tomSysOffset);

$subOrderInfo = array();
if(!empty($orderInfo['sub_order_no'])){
    $subOrderInfo = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($orderInfo['sub_order_no']); 
}

$hexiaoUserInfo = array();
if($orderInfo['order_status'] == 4){
    $hexiaoUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['hexiao_user_id']); 
}

$ajaxhexiaologlistUrl  = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&order_no={$orderInfo['order_no']}&act=hexiaologlist";
$hexiaoUrl     = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=orderhexiao&act=hexiao&formhash='.$formhash;
$uploadUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=upload&act=hexiao_pic&formhash=".FORMHASH;
$wxUploadUrl   = "plugin.php?id=tom_tcdaojia:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$ossBatchUrl   = 'plugin.php?id=tom_tcdaojia:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcdaojia:qiniuBatch';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:orderhexiao");