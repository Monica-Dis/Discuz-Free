<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$order_no = isset($_GET['order_no'])? daddslashes($_GET['order_no']):'';
$orderInfo = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($order_no);

if($orderInfo['goods_id'] > 0){
    $goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($orderInfo['goods_id']);
    
    $goodsPhotoTmp  = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND goods_id = {$goodsInfo['id']} AND type =1", 'ORDER BY id ASC',0,1);
    $goods_pic = '';
    if(is_array($goodsPhotoTmp) && !empty($goodsPhotoTmp[0])){
        $goods_pic = $goodsPhotoTmp[0]['picurlTmp'];
    }
}

if($orderInfo['needs_id'] > 0){
    $needsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($orderInfo['needs_id']);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);
    
    $needsPhotoTmp  = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND needs_id = {$needsInfo['id']} AND type =6", 'ORDER BY id DESC',0,1);
    $needs_pic = '';
    if(is_array($needsPhotoTmp) && !empty($needsPhotoTmp[0])){
        $needs_pic = $needsPhotoTmp[0]['picurlTmp'];
    }else{
        $needs_pic = $userInfo['picurl'];
    }
}

$ajaxSavePinglunUrl = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&act=save_pinglun&formhash={$formhash}";
$uploadUrl      = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=upload&act=pinglun_pic&formhash=".FORMHASH;
$wxUploadUrl    = "plugin.php?id=tom_tcdaojia:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:pinglun");