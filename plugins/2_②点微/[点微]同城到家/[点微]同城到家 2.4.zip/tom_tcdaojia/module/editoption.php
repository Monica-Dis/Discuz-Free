<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id  = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($goods_id);

if($__UserInfo['id'] != $goodsInfo['user_id']){
    dheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
}

$act = isset($_GET['act'])? addslashes($_GET['act']):'';
if($act == 'remove_option' && $_GET['formhash'] == FORMHASH){
    
    $option_id = intval($_GET['option_id'])>0? intval($_GET['option_id']): 0;
    
    C::t("#tom_tcdaojia#tom_tcdaojia_goods_option")->delete_by_id($option_id);
    
    $optionListTmp = C::t("#tom_tcdaojia#tom_tcdaojia_goods_option")->fetch_all_list(" AND goods_id = {$goods_id} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_price = $show_vip_price = 0;
        foreach($optionListTmp as $key => $value){
            if($show_price == 0){
                $show_price         = $value['price'];
                $show_vip_price     = $value['vip_price'];
            }else if($value['price'] < $show_price){
                $show_price         = $value['price'];
                $show_vip_price     = $value['vip_price'];
            }
        }
        if($show_price > 0){
            $updateData = array();
            $updateData['price']                = $show_price;
            $updateData['vip_price']            = $show_vip_price;
            $updateData['part1']                = TIMESTAMP;
            C::t("#tom_tcdaojia#tom_tcdaojia_goods")->update($goods_id,$updateData);
        }
        $goodsInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($goods_id);
    }
    
    echo 1;exit;

}else if($_GET['act'] == 'save' && submitcheck('name')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);
                }
            }
        }
    }
    
    $option_id      = intval($_GET['option_id'])> 0? intval($_GET['option_id']):0;
    $name           = isset($_GET['name'])? addslashes($_GET['name']):"";
    $price          = floatval($_GET['price'])> 0? floatval($_GET['price']):0.00;
    $vip_price      = floatval($_GET['vip_price'])> 0? floatval($_GET['vip_price']):0.00;
    $osort          = intval($_GET['osort'])> 0? intval($_GET['osort']):0;
    
    if($option_id > 0){
        $optionInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->fetch_by_id($option_id);
 
        $updateData = array();
        $updateData['name']         = $name;
        $updateData['price']        = $price;
        $updateData['vip_price']    = $vip_price;
        $updateData['osort']        = $osort;
        $updateData['part1']        = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->update($option_id,$updateData);
    }else{
        $insertData = array();
        $insertData['goods_id']     = $goods_id;
        $insertData['name']         = $name;
        $insertData['price']        = $price;
        $insertData['vip_price']    = $vip_price;
        $insertData['osort']        = $osort;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->insert($insertData);
        $option_id = C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->insert_id();
    }
    
    $optionListTmp = C::t("#tom_tcdaojia#tom_tcdaojia_goods_option")->fetch_all_list(" AND goods_id = {$goods_id} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_price = $show_vip_price = 0;
        foreach($optionListTmp as $key => $value){
            if($show_price == 0){
                $show_price         = $value['price'];
                $show_vip_price     = $value['vip_price'];
            }else if($value['price'] < $show_price){
                $show_price         = $value['price'];
                $show_vip_price     = $value['vip_price'];
            }
        }
        $updateData = array();
        $updateData['price']      = $show_price;
        $updateData['vip_price']  = $show_vip_price;
        $updateData['part1']      = TIMESTAMP;
        C::t("#tom_tcdaojia#tom_tcdaojia_goods")->update($goods_id,$updateData);
    }
    
    $goodsInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($goods_id);
    
    $outArr = array(
        'status'=> 200,
        'option_id'=> $option_id,
    );
    echo json_encode($outArr); exit;

}

$optionListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->fetch_all_list(" AND goods_id = {$goods_id}", 'ORDER BY osort ASC,id DESC', 0, 100);
$optionList = array();
if(is_array($optionListTmp) && !empty($optionListTmp)){
    foreach($optionListTmp as $key => $value){
        $optionList[$key] = $value;
    }
}

$saveUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=editoption&goods_id={$goods_id}&act=save&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:editoption");