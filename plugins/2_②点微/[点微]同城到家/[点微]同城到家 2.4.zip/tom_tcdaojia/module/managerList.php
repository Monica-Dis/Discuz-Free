<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

# check start
if($__UserInfo['groupid'] == 1 || $__UserInfo['groupid'] == 2 ){
}else{
    if($__UserInfo['id'] != $tcdaojiaConfig['daojiamanage_user_id']){
        tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
    }
}
# check end

if($_GET['act'] == 'shenhe' && submitcheck('servicer_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $servicer_id    = intval($_GET['servicer_id'])>0? intval($_GET['servicer_id']):0;
    $shenhe_status  = intval($_GET['shenhe_status'])>0? intval($_GET['shenhe_status']):0;
    $content        = isset($_GET['content'])? daddslashes($_GET['content']):'';
    
    $servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($servicer_id);
    
    $updateData = array();
    $updateData['shenhe_status'] = $shenhe_status;
    if($shenhe_status == 1){
        $updateData['status']    = 1;
    }
    C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->update($servicer_id,$updateData);
    
    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']);
    
    if($servicerInfo){
        
        if($shenhe_status == 1){
            $shenhe = str_replace('{XM}', $servicerInfo['name'], lang('plugin/tom_tcdaojia', 'template_daojia_shenhe_ok'));
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=$servicerInfo&servicer_id='.$servicerInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }else if($shenhe_status == 3){
            $shenhe = str_replace('{XM}', $servicerInfo['name'], lang('plugin/tom_tcdaojia', 'template_daojia_shenhe_no'));
            $tzShenhe = $shenhe.'<br/><font color="#8e8e8e">'.$content.'</font><br/><a href="plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=edit&servicer_id='.$servicerInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';
        }
        
        $insertData = array();
        $insertData['user_id']      = $toUser['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcdaojiaConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
    }
    
    $access_token = $weixinClass->get_access_token();
    
    $nextSmsTime = $toUser['last_smstp_time'] + 0;
    if($access_token && !empty($toUser['openid']) && TIMESTAMP > $nextSmsTime ){
        if($shenhe_status == 1){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$servicerInfo['site_id']}&mod=servicerinfo&servicer_id=".$servicerInfo['id']);
        }else if($shenhe_status == 3){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$servicerInfo['site_id']}&mod=edit&servicer_id={$servicerInfo['id']}");
        }
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
            'remark'        => $content
        );
        @$r = $templateSmsClass->sendSms01($toUser['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
            $updateData = array();
            $updateData['last_smstp_time'] = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_user')->update($toUser['id'],$updateData);
        }
    }
    
    echo 200;exit;
    
}else if($_GET['act'] == 'get_search_url' && $_GET['formhash'] == FORMHASH){
    
    $keyword = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
    
    $url = $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList&keyword=".urlencode(trim($keyword));
    
    echo $url;exit;
    
}else if($_GET['act'] == 'del' && submitcheck('needs_id')){
    
    $servicer_id = intval($_GET['servicer_id'])>0? intval($_GET['servicer_id']):0;
    
    C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->delete_by_id($servicer_id);
    C::t('#tom_tcdaojia#tom_tcdaojia_photo')->delete_by_servicer_id($servicer_id);    
    
    echo 200;exit;

}else if($_GET['act'] == 'shenhe_show'){
    
    $servicer_id     = intval($_GET['servicer_id'])>0? intval($_GET['servicer_id']):0;
    $fromtype    = intval($_GET['fromtype'])>0? intval($_GET['fromtype']):0;
    $frompage    = intval($_GET['frompage'])>0? intval($_GET['frompage']):1;
    
    $servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($servicer_id);

    $servicer_shenhe_fail_str = str_replace("\r\n","{n}",$tcdaojiaConfig['servicer_shenhe_fail_text']); 
    $servicer_shenhe_fail_str = str_replace("\n","{n}",$servicer_shenhe_fail_str);
    $servicerShenheFailArray  = explode("{n}", $servicer_shenhe_fail_str);

    $ajaxShenheUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList&act=shenhe&";
    $backUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList&type={$fromtype}&page={$frompage}";
    
    $isGbk = false;
    if (CHARSET == 'gbk') $isGbk = true;
    include template("tom_tcdaojia:managerShenhe");exit;
    
}

$keyword    = isset($_GET['keyword'])? addslashes(urldecode($_GET['keyword'])):'';
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;
$type       = intval($_GET['type'])>0? intval($_GET['type']):0;

$where = " AND (pay_status = 0 OR pay_status = 2) ";
if($type == 1){
    $where.= " AND shenhe_status=2 ";
}
if($type == 2){
    $where.= " AND shenhe_status=3 ";
}
if($__UserInfo['groupid'] == 2){
    $where.= " AND site_id={$site_id} ";
}

$pagesize = 8;
$start = ($page - 1)*$pagesize;

$count            = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_all_count(" {$where} ",$keyword);
$servicerListTmp  = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_all_list(" {$where} "," ORDER BY refresh_time DESC,id DESC ",$start,$pagesize,$keyword);
$servicerList     = array();
foreach ($servicerListTmp as $key => $value) {
    $servicerList[$key] = $value;
    
    $userInfoTmp   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $photoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND servicer_id = {$value['id']} AND type = 3 "," ORDER BY id ASC ",0,1);
    if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
        $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
    }
    
    $cate_ids_str = $value['cate_ids'];
    $cate_ids_str = substr($cate_ids_str, 1, -1);
    $cate_list = array();
    if(!empty($cate_ids_str)){
        $cate_ids_sql = str_replace("|", ",", $cate_ids_str);
        $cate_list = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND id IN({$cate_ids_sql}) ", "ORDER BY csort ASC,id ASC", 0, 100);
    }
    $servicerList[$key]['cate_list']      = $cate_list;
    $servicerList[$key]['picurl']         = $picurlTmp;
    $servicerList[$key]['userInfo']       = $userInfoTmp;
    $servicerList[$key]['link']           = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=servicerinfo&servicer_id='.$value['id'];

}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum = ceil($count/$pagesize);

$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}
$prePage = $page - 1;
$nextPage = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList&type={$type}&page={$prePage}&keyword=".$_GET['keyword'];
$nextPageUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList&type={$type}&page={$nextPage}&keyword=".$_GET['keyword'];
$pageUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList&type={$type}&keyword={$keyword}";

$ajaxShenheUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList&act=shenhe&&formhash=".$formhash;
$ajaxDelUrl    = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList&act=del&&formhash=".$formhash;
$searchUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList&act=get_search_url";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:managerList");