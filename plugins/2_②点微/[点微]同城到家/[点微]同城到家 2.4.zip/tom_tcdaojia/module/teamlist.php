<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$servicer_id  = intval($_GET['servicer_id'])>0? intval($_GET['servicer_id']):0;

$servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($servicer_id);

if($servicerInfo['user_id'] != $__UserInfo['id']){
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
}

$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$whereStr = " AND servicer_id = {$servicer_id}  ";
$orderStr = " ORDER BY id DESC ";

$pagesize = 10;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_all_count($whereStr);
$teamListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);

$teamList = array();
foreach ($teamListTmp as $key => $value){
    $teamList[$key] = $value;
    if(!preg_match('/^http/', $value['picurl']) ){
        if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
            $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
        }else{
            $picurl = $value['picurl'];
        }
    }else{
        $picurl = $value['picurl'];
    }

    $teamList[$key]['picurl'] = $picurl;
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum  = ceil($count/$pagesize);
$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=teamlist&servicer_id={$servicer_id}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=teamlist&servicer_id={$servicer_id}&page={$nextPage}";
$pageUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=teamlistservicer_id={$servicer_id}";

$ajaxUpdateteamStatusUrl = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&act=updateteamStatus&&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:teamlist");