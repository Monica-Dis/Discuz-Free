<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type       = intval($_GET['type'])> 0? intval($_GET['type']):0;
$page       = intval($_GET['page'])>0? intval($_GET['page']):1;

$teamInfo = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_by_user_id($__UserInfo['id']);

if($teamInfo && $teamInfo['id'] > 0){}else{
    tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
}

$whereStr = "AND team_id ={$teamInfo['id']} AND type IN (1,2,3)";

if($type == 1){
    $whereStr .= " AND order_status = 3 ";
}else if($type == 2){
    $whereStr .= " AND order_status = 4 ";
}

$orderStr = " ORDER BY order_time DESC,id DESC ";

$pagesize = 10;
$start = ($page - 1)*$pagesize;
$count = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_count($whereStr);
$orderListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);
$orderList = array();
foreach ($orderListTmp as $key => $value){
    $orderList[$key] = $value;    

    $goodsInfoTmp    = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($value['goods_id']);
    $needsInfoTmp    = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($value['needs_id']);
    $servicerInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($value['servicer_id']);
    $userInfoTmp     = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    
    if($value['type'] == 1 || $value['type'] == 2){
        $photoInfoTmp       = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list("AND needs_id = {$value['needs_id']} AND type = 6","",0,1);
    }elseif($value['type'] == 3){
        $photoInfoTmp       = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list("AND goods_id = {$value['goods_id']} AND type = 1","",0,1);
    }
    if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
        $picurlTmp = $photoInfoTmp[0]['picurlTmp'];
    }else{
        $picurlTmp = $userInfoTmp['picurl'];
    }
    
    $orderList[$key]['picurl']          = $picurlTmp;
    $orderList[$key]['goodsInfo']       = $goodsInfoTmp;
    $orderList[$key]['userInfo']        = $userInfoTmp;
    $orderList[$key]['needsInfo']       = $needsInfoTmp;
    $orderList[$key]['servicerInfo']    = $servicerInfoTmp;
    $orderList[$key]['order_time']   = dgmdate($value['order_time'],"Y-m-d H:i",$tomSysOffset);
    $orderList[$key]['fuwu_time']    = dgmdate($value['fuwu_time'],"Y-m-d H:i",$tomSysOffset);
    if($value['pay_time'] > 0){
        $orderList[$key]['pay_time'] = dgmdate($value['pay_time'],"Y-m-d H:i",$tomSysOffset);
    }
}

$showNextPage = 1;
if(($start + $pagesize) >= $count){
    $showNextPage = 0;
}
$allPageNum  = ceil($count/$pagesize);
$allPageList = array();
for($i = 1; $i <= $allPageNum; $i++){
    $allPageList[] = $i;
}

$prePage     = $page - 1;
$nextPage    = $page + 1;
$prePageUrl  = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=team_order&type={$type}&page={$prePage}";
$nextPageUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=team_order&type={$type}&page={$nextPage}";
$pageUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=team_order&type={$type}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:team_order");