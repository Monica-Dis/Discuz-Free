<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id  = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;

$goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($goods_id);

# check start
if($goodsInfo['user_id'] != $__UserInfo['id']){
    if($__UserInfo['id'] == $tcdaojiaConfig['daojiamanage_user_id']){
    }else{
        if($__UserInfo['groupid'] == 1){
        }else if($__UserInfo['groupid'] == 2){
            if($goodsInfo['site_id'] == $__UserInfo['groupsiteid']){
            }else{
                tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
            }
        }else{
            tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
        }
    }
}
# check end

if($_GET['act'] == 'save' && submitcheck('tuiguang_form')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
   
    $hehuoren_tg_open    = isset($_GET['hehuoren_tg_open'])? intval($_GET['hehuoren_tg_open']):0;
    $hehuoren_tg_type    = isset($_GET['hehuoren_tg_type'])? intval($_GET['hehuoren_tg_type']):0;
    $hehuoren_fc_scale   = isset($_GET['hehuoren_fc_scale'])? floatval($_GET['hehuoren_fc_scale']):0;
    $hehuoren_fc_scale2  = isset($_GET['hehuoren_fc_scale2'])? floatval($_GET['hehuoren_fc_scale2']):0;

    $updateData = array();
    $updateData['hehuoren_tg_open']      = $hehuoren_tg_open;
    $updateData['hehuoren_tg_type']      = $hehuoren_tg_type;
    $updateData['hehuoren_fc_scale']     = $hehuoren_fc_scale;
    $updateData['hehuoren_fc_scale2']    = $hehuoren_fc_scale2;
    C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($goodsInfo['id'],$updateData);

    $outArr = array(
        'status'=> 200,
    );
    echo json_encode($outArr); exit;
}

$saveUrl = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=edit_tuiguang&goods_id={$goods_id}&act=save&formhash={$formhash}";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:edit_tuiguang");