<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id      = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;

$goodsInfo     = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($goods_id);
$servicerInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($goodsInfo['servicer_id']);

# check start
if($goodsInfo['user_id'] != $__UserInfo['id']){
    if($__UserInfo['id'] == $tcdaojiaConfig['daojiamanage_user_id']){
    }else{
        if($__UserInfo['groupid'] == 1){
        }else if($__UserInfo['groupid'] == 2){
            if($goodsInfo['site_id'] == $__UserInfo['groupsiteid']){
            }else{
                tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
            }
        }else{
            tomheader('location:'.$_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");exit;
        }
    }
}
# check end

if($_GET['act'] == 'save' && submitcheck('user_id')){
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $price              = isset($_GET['price'])? addslashes($_GET['price']):'';
    $open_vip           = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $vip_price          = isset($_GET['vip_price'])? addslashes($_GET['vip_price']):'';
    $open_yuyue         = isset($_GET['open_yuyue'])? intval($_GET['open_yuyue']):0;
    $yuyue_time         = isset($_GET['yuyue_time'])? intval($_GET['yuyue_time']):0;
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? addslashes($_GET['ding_price']):'';
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';

    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $updateData = array();
    $updateData['site_id']            = $site_id;
    $updateData['title']              = $title;
    $updateData['cate_id']            = $cate_id;
    $updateData['cate_child_id']      = $cate_child_id;
    $updateData['price']              = $price;
    $updateData['open_vip']           = $open_vip;
    $updateData['vip_price']          = $vip_price;
    $updateData['open_yuyue']         = $open_yuyue;
    $updateData['yuyue_time']         = $yuyue_time;
    $updateData['open_ding_pay']      = $open_ding_pay;
    $updateData['ding_price']         = $ding_price;
    $updateData['hasoption']          = $hasoption;
    $insertData['address']            = $servicerInfo['address'];
    $insertData['latitude']           = $servicerInfo['latitude'];
    $insertData['longitude']          = $servicerInfo['longitude'];
    if($goodsInfo['admin_edit'] == 0){
        $updateData['content']      = dhtmlspecialchars($content);
    }
    $updateData['status']             = 1;
    if($tcdaojiaConfig['fabu_goods_must_shenhe'] == 1){
        $updateData['shenhe_status']       = 2;
    }else{
        $updateData['shenhe_status']       = 1;
    }
    $updateData['refresh_time']       = TIMESTAMP;

    if(C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($goods_id,$updateData)){
        
        $goodsInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($goods_id);
        
        C::t('#tom_tcdaojia#tom_tcdaojia_photo')->delete_by_goods_id($goods_id);
        
        if(!empty($picurl)){
            $insertData = array();
            $insertData['goods_id']  = $goods_id;
            $insertData['type']      = 1;
            $insertData['picurl']    = $picurl;
            $insertData['add_time']  = TIMESTAMP;
            C::t('#tom_tcdaojia#tom_tcdaojia_photo')->insert($insertData);
        }
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['goods_id']        = $goods_id;
                $insertData['type']            = 2;
                $insertData['picurl']          = $value;
                $insertData['add_time']  = TIMESTAMP;
                C::t('#tom_tcdaojia#tom_tcdaojia_photo')->insert($insertData);
            }
        }
        
        if(!empty($tongchengConfig['template_id'])){
            
            $toUser = array();
            $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
            if($toUserTmp && !empty($toUserTmp['openid'])){
                $toUser = $toUserTmp;
            }

            $access_token = $weixinClass->get_access_token();

            if($access_token && !empty($toUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerGoodsList");
                $smsData = array(
                    'first'         => '['.$servicerInfo['name'].']'.lang('plugin/tom_tcdaojia','daojia_editgoods_shenhe_msg'),
                    'keyword1'      => $tcdaojiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
            }

            $daojiamanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcdaojiaConfig['daojiamanage_user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($daojiamanageUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerGoodsList");
                $smsData = array(
                    'first'         => '['.$servicerInfo['name'].']'.lang('plugin/tom_tcdaojia', 'daojia_editgoods_shenhe_msg'),
                    'keyword1'      => $tcdaojiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($daojiamanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
        }

        $outArr = array(
            'status'        => 200,
            'goods_id'  => $goods_id,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'        => 404,
        );
        echo json_encode($outArr); exit;
    }
}

$cateInfo = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($goodsInfo['cate_id']);
$cateChildInfo = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($goodsInfo['cate_child_id']);

$cateArr = array();
$cateList = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,100);
$i = 0;
if(is_array($cateList) && !empty($cateList)){
    foreach ($cateList as $key => $value){
        $cateArr[$i]['id'] = $value['id'];
        $cateArr[$i]['name'] = diconv($value['name'],CHARSET,'utf-8');
        $childCateList = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid={$value['id']} "," ORDER BY csort ASC,id DESC ",0,100);
        $j = 0;
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $kk => $vv){
                $cateArr[$i]['sub'][$j]['id'] = $vv['id'];
                $cateArr[$i]['sub'][$j]['name'] = diconv($vv['name'],CHARSET,'utf-8');
                $j++;
            }
        }
        $i++;
    }
}
$cateData = urlencode(json_encode($cateArr));

$photoListTmp = C::t("#tom_tcdaojia#tom_tcdaojia_photo")->fetch_all_list(" AND goods_id={$goods_id} ", 'ORDER BY id ASC', 0, 50);
$photoList = array();
$picurl  = $picurl_src = '';
$photoCount = 0;
if(is_array($photoListTmp) && !empty($photoListTmp)){
    foreach($photoListTmp as $key => $value){
        $picurlTmp = $value['picurlTmp'];
        if($value['type'] == 1){
            $picurl = $value['picurl'];
            $picurl_src = $value['picurlTmp'];
        }else if($value['type'] == 2){
            $photoList[$key] = $value;
            $photoList[$key]['picurlTmp'] = $picurlTmp;
            $photoCount++;
            $photoList[$key]['li_i'] = $photoCount;
        }
    }
}

$yuyueGoodsList = array();
$yueyue_goods_list_str = str_replace("\r\n","{n}",$tcdaojiaConfig['yuyue_goods_list']); 
$yueyue_goods_list_str = str_replace("\n","{n}",$yueyue_goods_list_str);
$yuyue_goods_list_arr = explode("{n}", $yueyue_goods_list_str);
if(is_array($yuyue_goods_list_arr) && !empty($yuyue_goods_list_arr)){
    foreach ($yuyue_goods_list_arr as $key => $value){
        $arr = array();
        $yuyueGoodsList[$key] = $arr = explode("|", $value);
    }
}

$saveUrl       = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=editgoods&act=save";
$uploadUrl1    = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=upload&act=goods_pic&formhash=".FORMHASH;
$uploadUrl2    = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=upload&act=goods_photo&formhash=".FORMHASH;
$wxUploadUrl   = "plugin.php?id=tom_tcdaojia:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$ossBatchUrl   = 'plugin.php?id=tom_tcdaojia:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcdaojia:qiniuBatch';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:editgoods");