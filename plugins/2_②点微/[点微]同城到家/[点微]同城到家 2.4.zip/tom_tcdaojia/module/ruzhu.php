<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_user_id($__UserInfo['id']);

$i = 1;
$cateListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid = 0 ", "ORDER BY csort ASC,id ASC", 0, 100);
$cateList = array();
if(is_array($cateListTmp) && !empty($cateListTmp)){
    foreach ($cateListTmp as $key => $value){
        $cateList[$key] = $value;
        $cateList[$key]['i'] = $i;
        $i++;
    }
}

$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
$areaList = array();
if(is_array($areaListTmp) && !empty($areaListTmp)){
    foreach ($areaListTmp as $key => $value){
        $areaList[$key] = $value;

        $streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($value['id']);
        $streetList = array();
        if(is_array($streetListTmp) && !empty($streetListTmp)){
            foreach ($streetListTmp as $kk => $vv){
                $streetList[$kk] = $vv;
                
            }
        }
        $areaList[$key]['streetList'] = $streetList;
        
    }
}

$__CommonInfo = C::t('#tom_tcdaojia#tom_tcdaojia_common')->fetch_by_id(1);
if(!$__CommonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcdaojia#tom_tcdaojia_common')->insert($insertData);
    $__CommonInfo = C::t('#tom_tcdaojia#tom_tcdaojia_common')->fetch_by_id(1);
}

$servicer_xieyi  = stripslashes($__CommonInfo['servicer_xieyi']);

if($tcdaojiaConfig['open_ruzhu_pay_money'] == 1){
    
    $dengjiListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_all_list(" AND status = 1 ", 'ORDER BY dsort ASC, id DESC');
    $dengjiList = $dengjiArr = array();
    if(is_array($dengjiListTmp) && !empty($dengjiListTmp)){
        foreach($dengjiListTmp as $key => $value){

            $dengjiArr[] = $value;
            $dengjiList[$key] = $value;
            $dengjiList[$key]['price'] = floatval($value['price']);

            if(!preg_match('/^http/', $value['picurl']) ){
                if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                    $picurlTmp = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
                }else{
                    $picurlTmp = $value['picurl'];
                }
            }else{
                $picurlTmp = $value['picurl'];
            }

            $dengjiList[$key]['picurl'] = $picurlTmp;
        }
    }
}

$ajaxDengjiCodeUrl = "plugin.php?id=tom_tcdaojia:ajax&site={$site_id}&act=dengji_code&formhash=".FORMHASH;
$payUrl        = "plugin.php?id=tom_tcdaojia:pay&site={$site_id}";
$uploadUrl     = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=upload&act=servicer_wxpic&formhash=".FORMHASH;
$uploadUrl1    = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=upload&act=servicer_pic&formhash=".FORMHASH;
$uploadUrl2    = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=upload&act=servicer_photo&formhash=".FORMHASH;
$wxUploadUrl   = "plugin.php?id=tom_tcdaojia:wxMediaDowmload&site={$site_id}&act=photo&formhash={$formhash}&suffix=";
$ossBatchUrl   = 'plugin.php?id=tom_tcdaojia:ossBatch';
$qiniuBatchUrl = 'plugin.php?id=tom_tcdaojia:qiniuBatch';

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:ruzhu");