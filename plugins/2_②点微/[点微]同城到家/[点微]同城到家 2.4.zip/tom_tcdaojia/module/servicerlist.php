<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$whereStr = " AND status=1 AND shenhe_status=1 AND (pay_status = 0 OR pay_status = 2) ";
if($tcdaojiaConfig['open_ruzhu_pay_money'] == 1){
    $whereStr.= " AND dengji_id > 0 ";
}

if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}

$orderStr = "ORDER BY top_status DESC,`rank` DESC,refresh_time DESC,id DESC";

$pagesize       = $pagesize;
$start          = ($page - 1)*$pagesize;

$servicerListTmp  = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_all_list($whereStr,$orderStr,$start,$pagesize);

$servicerList = array();
foreach ($servicerListTmp as $key => $value){

    $servicerList[$key] = $value;

    $photoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND servicer_id = {$value['id']} AND type = 3 "," ORDER BY id ASC ",0,1);
    if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
        $picurl = $photoInfoTmp[0]['picurlTmp'];
    }
    $orderCount = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_count(" AND servicer_id = {$value['id']} AND order_status IN (2,3,4)");
    $virtualSaleNumCount = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_sun_virtual_sale_num(" AND servicer_id = {$value['id']} AND status=1 AND shenhe_status=1 ");
    $servicerList[$key]['picurl'] = $picurl;
    $servicerList[$key]['orderCount'] = $orderCount + $virtualSaleNumCount;
    $servicerList[$key]['link'] = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=servicerinfo&servicer_id='.$value['id'];

}

if(is_array($servicerList) && !empty($servicerList)){
    foreach ($servicerList as $key => $val){
        $outStr .= '<a class="servicer-item" href="'.$val['link'].'">';
            $outStr .= '<div class="servicer-pic">';
                $outStr .= '<img src="'.$val['picurl'].'">';
            $outStr .= '</div>';
            $outStr .= '<div class="servicer-cont">';
                $outStr .= '<div class="servicer_title">';
                    $outStr .= $val['name'];
                $outStr .= '</div>';
                $outStr .= '<div class="times">';
                    $outStr .= '<span class="left">'.lang('plugin/tom_tcdaojia', 'service').$val['orderCount'].lang('plugin/tom_tcdaojia', 'ci').'</span>';
                    if($val['grade'] > 0){
                        $outStr .= ' | <span class="right">'.$val['grade'].lang('plugin/tom_tcdaojia', 'grade').'</span>';
                    }
                $outStr .= '</div>';
            $outStr .= '</div>';
        $outStr .= '</a>';
    }
}else{
    $outStr = '205';
}
$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;