<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$goods_id  = intval($_GET['goods_id'])>0? intval($_GET['goods_id']):0;

$goodsInfo = C::t("#tom_tcdaojia#tom_tcdaojia_goods")->fetch_by_id($goods_id);
$cateInfo  = C::t("#tom_tcdaojia#tom_tcdaojia_cate")->fetch_by_id($goodsInfo['cate_child_id']);

if($goodsInfo['top_status'] == 1 && $goodsInfo['top_time'] <= TIMESTAMP){
    $updateData = array();
    $updateData['top_status']   = 0;
    $updateData['top_time']     = 0;
    C::t("#tom_tcdaojia#tom_tcdaojia_goods")->update($goods_id, $updateData);
    $goodsInfo['top_status'] = 0;
}

$goodsTopList = array();
$goods_top_list_str = str_replace("\r\n","{n}",$tcdaojiaConfig['goods_top_list']); 
$goods_top_list_str = str_replace("\n","{n}",$goods_top_list_str);
$goods_top_list_arr = explode("{n}", $goods_top_list_str);
if(is_array($goods_top_list_arr) && !empty($goods_top_list_arr)){
    foreach ($goods_top_list_arr as $key => $value){
        $arr = array();
        $goodsTopList[$key] = $arr = explode("|", $value);
        $goodsTopList[$key]['score_pay'] = 0;
        $goodsTopList[$key]['score'] = 0;

        if($tcdaojiaConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $scorePayNum = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($scorePayNum > 0 && $__UserInfo['score'] >= $scorePayNum){
                $goodsTopList[$key]['score'] = $scorePayNum;
                $goodsTopList[$key]['score_pay'] = 1;
            }
        }

    }
}

$payTopUrl = "plugin.php?id=tom_tcdaojia:pay&site={$site_id}&act=goods_top_pay&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:buygoods");