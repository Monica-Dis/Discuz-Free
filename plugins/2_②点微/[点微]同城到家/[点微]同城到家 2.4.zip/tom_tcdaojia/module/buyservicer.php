<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$servicerInfo   = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_user_id($__UserInfo['id']);

if($servicerInfo['top_status'] == 1 && $servicerInfo['top_time'] <= TIMESTAMP){
    $updateData = array();
    $updateData['top_status']   = 0;
    $updateData['top_time']     = 0;
    C::t("#tom_tcdaojia#tom_tcdaojia_servicer")->update($servicerInfo['id'], $updateData);
    $servicerInfo['top_status'] = 0;
}

$servicerTopList = array();
$servicer_top_list_str = str_replace("\r\n","{n}",$tcdaojiaConfig['servicer_top_list']); 
$servicer_top_list_str = str_replace("\n","{n}",$servicer_top_list_str);
$servicer_top_list_arr = explode("{n}", $servicer_top_list_str);
if(is_array($servicer_top_list_arr) && !empty($servicer_top_list_arr)){
    foreach ($servicer_top_list_arr as $key => $value){
        $arr = array();
        $servicerTopList[$key] = $arr = explode("|", $value);
        $servicerTopList[$key]['score_pay'] = 0;
        $servicerTopList[$key]['score'] = 0;

        if($tcdaojiaConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
            $scorePayNum = ceil($arr[1] * $tongchengConfig['pay_score_yuan']);
            if($scorePayNum > 0 && $__UserInfo['score'] >= $scorePayNum){
                $servicerTopList[$key]['score'] = $scorePayNum;
                $servicerTopList[$key]['score_pay'] = 1;
            }
        }
    }
}

$payTopUrl = "plugin.php?id=tom_tcdaojia:pay&site={$site_id}&act=servicer_top_pay&formhash=".$formhash;

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:buyservicer");