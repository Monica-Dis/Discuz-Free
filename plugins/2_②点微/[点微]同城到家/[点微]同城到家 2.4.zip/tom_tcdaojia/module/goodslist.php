<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$outStr = '';

$keyword            = isset($_GET['keyword'])? daddslashes(diconv(urldecode($_GET['keyword']),'utf-8')):'';
$cate_id            = intval($_GET['cate_id'])>0? intval($_GET['cate_id']):0;
$cate_child_id      = intval($_GET['cate_child_id'])>0? intval($_GET['cate_child_id']):0;
$area_id            = intval($_GET['area_id'])>0? intval($_GET['area_id']):0;
$street_id          = intval($_GET['street_id'])>0? intval($_GET['street_id']):0;
$paixu_type         = intval($_GET['paixu_type'])>0? intval($_GET['paixu_type']):1;
$servicer_id        = intval($_GET['servicer_id'])>0? intval($_GET['servicer_id']):0;
$page               = intval($_GET['page'])>0? intval($_GET['page']):1;
$pagesize           = intval($_GET['pagesize'])>0? intval($_GET['pagesize']):8;
$template_type      = intval($_GET['template_type'])>0? intval($_GET['template_type']):1;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/sitesids.php';

$latitude = getcookie('tom_tongcheng_user_latitude');
$longitude = getcookie('tom_tongcheng_user_longitude');

$whereArea = "";
if($area_id > 0 && $street_id == 0){
    $whereArea = " AND status=1 AND shenhe_status=1 AND (area_ids LIKE '%|{$area_id}|%' ) ";
}
if($street_id > 0 && $area_id > 0){
    $whereArea = " AND status=1 AND shenhe_status=1 AND (street_ids LIKE '%|{$street_id}|%' OR street_ids LIKE '%|all{$area_id}|%' )";
}
$servicer_id_str = '';
if(!empty($whereArea)){
    $servicerListTmp  = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_all_list($whereArea,"ORDER BY id DESC",0,100);
    $servicer_id_arr = array();
    foreach ($servicerListTmp as $key => $value){
        $servicer_id_arr[] = $value['id'];
    }
    $servicer_id_str = implode(",", $servicer_id_arr);
}

$whereStr = " AND status=1 AND shenhe_status=1  ";
if(!empty($sql_in_site_ids)){
    $whereStr.= " AND site_id IN({$sql_in_site_ids}) ";
}
if($area_id > 0){
    if(!empty($servicer_id_str)){
        $whereStr.= " AND servicer_id IN({$servicer_id_str}) ";
    }else{
        $whereStr.= " AND servicer_id = 9999999 ";
   }
}else if($servicer_id > 0){
    $whereStr.= " AND servicer_id = {$servicer_id} ";
}
if($cate_id > 0){
    $whereStr .= " AND cate_id = {$cate_id}";
}
if($cate_child_id > 0){
    $whereStr .= " AND cate_child_id = {$cate_child_id} ";
}

if($paixu_type == 1){
    if($cate_child_id > 0){
        $orderStr = "ORDER BY top_status DESC,servicer_rank DESC,refresh_time DESC,id DESC";
    }else{
        $orderStr = "ORDER BY top_status DESC,refresh_time DESC,id DESC";
    }
}elseif($paixu_type == 3){
    $orderStr = "ORDER BY refresh_time DESC,id DESC";
}

$pagesize       = $pagesize;
$start          = ($page - 1)*$pagesize;

if($paixu_type == 2 && !empty($latitude) && !empty($longitude)){
    $goodsListTmp  = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_nearby_list($whereStr,$start,$pagesize,$latitude,$longitude);
}else{
    $goodsListTmp  = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_list($whereStr,$orderStr,$start,$pagesize,$keyword);
}

$goodsList = array();
foreach ($goodsListTmp as $key => $value){

    $goodsList[$key] = $value;

    $servicerInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($value['servicer_id']);
    $goodsPicListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND goods_id = {$value['id']}  AND type = 1 ","ORDER BY id ASC",0,1);
    $servicerPicListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND servicer_id = {$value['servicer_id']}  AND type = 3 ","ORDER BY id ASC",0,1);
    $picurl = $servicer_pic  = '';
    if(is_array($goodsPicListTmp) && !empty($goodsPicListTmp) && isset($goodsPicListTmp[0])){
        $picurl = $goodsPicListTmp[0]['picurlTmp'];
    }
    if(is_array($servicerPicListTmp) && !empty($servicerPicListTmp) && isset($servicerPicListTmp[0])){
        $servicer_pic = $servicerPicListTmp[0]['picurlTmp'];
    }
    
    $contentTmp = strip_tags($value['content']);
    $contentTmp = str_replace("\r\n","",$contentTmp);
    $contentTmp = str_replace("\n","",$contentTmp);
    $contentTmp = str_replace("\r","",$contentTmp);
    
    $goodsList[$key]['servicerInfo'] = $servicerInfoTmp;
    $goodsList[$key]['picurl'] = $picurl;
    $goodsList[$key]['content'] = $contentTmp;
    $goodsList[$key]['servicer_pic'] = $servicer_pic;
    $goodsList[$key]['sale_num'] = $value['sale_num'] + $value['virtual_sale_num'];
    $goodsList[$key]['link'] = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=goodsinfo&goods_id='.$value['id'];

}

if(is_array($goodsList) && !empty($goodsList)){
    foreach ($goodsList as $key => $val){
        if($template_type == 1){
            $outStr .= '<a class="goods-item" href="'.$val['link'].'">';
                $outStr .= '<div class="goods-pic">';
                    $outStr .= '<img src="'.$val['picurl'].'">';
                $outStr .= '</div>';
                $outStr .= '<div class="goods-cont">';
                    $outStr .= '<div class="goods_title">';
                        $outStr .= $val['title'];
                    $outStr .= '</div>';
                    $outStr .= '<div class="goods_sale_num">';
                        $outStr .= '<span>'.lang('plugin/tom_tcdaojia', 'sale_num_msg').$val['sale_num'].'</span>';
                    $outStr .= '</div>';
                    $outStr .= '<div class="goods-price dislay-flex">';
                        $outStr .= '<div class="goods-price_left">';
                            if($val['open_ding_pay'] == 1){
                                $outStr .= '<span class="left">'.$val['ding_price'].'</span>';
                            }else{
                                $outStr .= '<span class="left">'.$val['price'].'</span>';
                            }
                            $outStr .= '<span class="right">'.lang('plugin/tom_tcdaojia', 'yuan').'</span>';
                        $outStr .= '</div>';
                        $outStr .= '<div class="goods-price_right" onClick="delshoucang('.$val['id'].');">';
                            if($paixu_type == 2 && !empty($latitude) && !empty($longitude)){
                                $juli = tomGetDistance($longitude, $latitude, $val['longitude'], $val['latitude']);
                                $outStr.= '<span>'.$juli.'km</span>';
                            }
                        $outStr .= '</div>';
                    $outStr .= '</div>';
                $outStr .= '</div>';
            $outStr .= '</a>';
        }else if($template_type == 2){
            $outStr .= '<a href="'.$val['link'].'">';
            $outStr .= '<div class="goods_item clearfix">';
                $outStr .= '<div class="goods_item_left">';
                    $outStr .= '<img src="'.$val['picurl'].'">';
                $outStr .= '</div>';
                $outStr .= '<div class="goods_item_right">';
                    $outStr .= '<div class="goods_item_title">'.$val['title'].'</div>';
                    $outStr .= '<div class="goods_item_content">'.$val['content'].'</div>';
                    $outStr .= '<div class="goods_item_price">';
                        if($val['open_ding_pay'] == 1){
                            $outStr .= '<span class="price">'.lang("plugin/tom_tcdaojia", 'yuan_ico').$val['ding_price'].'</span>';
                        }else{
                            $outStr .= '<span class="price">'.lang("plugin/tom_tcdaojia", 'yuan_ico').$val['price'].'</span>';
                        }
                        if($paixu_type == 2 && !empty($latitude) && !empty($longitude)){
                            $juli = tomGetDistance($longitude, $latitude, $val['longitude'], $val['latitude']);
                            $outStr.= '<span class="juli">'.$juli.'km</span>';
                        }
                    $outStr .= '</div>';
                    $outStr .= '<a href="plugin.php?id=tom_tcdaojia&site='.$goodsInfo['site_id'].'&mod=servicerinfo&servicer_id='.$val['servicerInfo']['id'].'">';
                    $outStr .= '<div class="goods_item_bottom clearfix">';
                        $outStr .= '<span class="left">';
                            $outStr .= '<img src="'.$val['servicer_pic'].'">'.$val['servicerInfo']['name'].'<i></i>';
                        $outStr .= '</span>';
                        $outStr .= '<span class="right">'.lang("plugin/tom_tcdaojia", 'sale_num_msg').$val['sale_num'].'</span>';
                    $outStr .= '</div>';
                    $outStr .= '</a>';
                $outStr .= '</div>';
            $outStr .= '</div>';
            $outStr .= '</a>';
        }
    }
}else{
    $outStr = '205';
}
$outStr = tom_link_replace($outStr);
$outStr = diconv($outStr,CHARSET,'utf-8');
echo json_encode($outStr); exit;