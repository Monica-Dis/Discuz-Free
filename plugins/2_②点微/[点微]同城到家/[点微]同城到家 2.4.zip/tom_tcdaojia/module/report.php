<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$report_user_id = isset($_GET['report_user_id'])? intval($_GET['report_user_id']):0;

$goods_id       = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
$needs_id       = isset($_GET['needs_id'])? intval($_GET['needs_id']):0;

$reportUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($report_user_id);

$act            = isset($_GET['act'])? trim($_GET['act']):'';
$report_from    = isset($_GET['report_from'])? daddslashes($_GET['report_from']):'';

if($act == 'save' && submitcheck('report_user_id')){

    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }

    $outArr = array(
        'status'=> 200,
    );

    $report_user_id = isset($_GET['report_user_id'])? intval($_GET['report_user_id']):0;
    $report_content = isset($_GET['report_content'])? addslashes($_GET['report_content']):'';

    $bmpicliArr = array();
    if(is_array($_GET['bmpicli']) && !empty($_GET['bmpicli'])){
        foreach($_GET['bmpicli'] as $key => $value){
            $bmpicliArr[] = daddslashes($value);
        }
    }

    $insertData = array();
    $insertData['user_id']          = $__UserInfo['id'];
    if($goods_id > 0){
        $insertData['goods_id']     = $goods_id;
        $insertData['type']         = 1;
    }
    if($needs_id > 0){
        $insertData['needs_id']     = $needs_id;
        $insertData['type']         = 2;
    }
   
    $insertData['report_user_id']   = $report_user_id;
    $insertData['report_content']   = $report_content;
    $insertData['report_pic_1']     = $bmpicliArr[0];
    $insertData['report_pic_2']     = $bmpicliArr[1];
    $insertData['report_time']      = TIMESTAMP;
    C::t('#tom_tcdaojia#tom_tcdaojia_report')->insert($insertData);

    $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);

    $access_token = $weixinClass->get_access_token();
    $smsContent = strip_tags($report_content);

    if($access_token && !empty($toUser['openid'])){
        if($goods_id > 0){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$reportUserInfo['site_id']}&mod=goodsinfo&goods_id={$goods_id}");
        }
        if($needs_id > 0){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$reportUserInfo['site_id']}&mod=needsinfo&needs_id={$needs_id}");
        }
       
        $template_first = str_replace("{NAME}",$__UserInfo['nickname'], lang('plugin/tom_tcdaojia','report_template_first'));
        $template_first = str_replace("{REPORTNAME}",$reportUserInfo['nickname'],$template_first);

        $smsData = array(
            'first'         => $template_first,
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => $smsContent
        );

        @$r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);

    }

    $tcdaojiamanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcdaojiaConfig['daojiamanage_user_id']);
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcdaojiamanageUserInfo['openid'])){
        if($goods_id > 0){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$reportUserInfo['site_id']}&mod=goodsinfo&goods_id={$goods_id}");
        }
        if($needs_id > 0){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$reportUserInfo['site_id']}&mod=needsinfo&needs_id={$needs_id}");
        }
       
        $template_first = str_replace("{NAME}",$__UserInfo['nickname'], lang('plugin/tom_tcdaojia','report_template_first'));
        $template_first = str_replace("{REPORTNAME}",$reportUserInfo['nickname'],$template_first);

        $smsData = array(
            'first'         => $template_first,
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => $smsContent
        );

        @$r = $templateSmsClass->sendSms01($tcdaojiamanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
    }

    echo json_encode($outArr); exit;

}

$uploadUrl       = "plugin.php?id=tom_tcdaojia&mod=upload&act=report&formhash=".FORMHASH;
$reportUrl       = "plugin.php?id=tom_tcdaojia&mod=report";
$wxUploadUrl2     = "plugin.php?id=tom_tcdaojia:wxMediaDowmload&site={$site_id}&act=pic&formhash={$formhash}&suffix=";

$isGbk = false;
if (CHARSET == 'gbk') $isGbk = true;
include template("tom_tcdaojia:report");