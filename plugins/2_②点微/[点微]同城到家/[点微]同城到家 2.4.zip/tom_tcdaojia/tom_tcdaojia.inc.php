<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$site_id = intval($_GET['site']) > 0 ? intval($_GET['site']) : 1;
session_start();
define('TPL_DEFAULT', true);
$formhash = FORMHASH;
$tcdaojiaConfig = $_G['cache']['plugin']['tom_tcdaojia'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
require_once libfile('function/discuzcode');
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;
$prand = rand(1, 1000);
$cssJsVersion = '20200720';
if (!file_exists(DISCUZ_ROOT . './source/plugin/tom_tongcheng/tom_tongcheng.inc.php')) {
	echo '<a href="https://addon.discuz.com/?@tom_tongcheng.plugin">https://addon.discuz.com/?@tom_tongcheng.plugin</a>';
	exit(0);
}
if (CHARSET == 'gbk') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/config/config.gbk.php';
} else {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/config/config.utf8.php';
}
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid, $appsecret);
include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/class/function.core.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/link.func.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/nofind.php';
$wxJssdkConfig = array();
$wxJssdkConfig['appId'] = '';
$wxJssdkConfig['timestamp'] = time();
$wxJssdkConfig['nonceStr'] = '';
$wxJssdkConfig['signature'] = '';
$wxJssdkConfig = $weixinClass->get_jssdk_config();
$shareTitle = $tcdaojiaConfig['wx_share_title'];
$shareDesc = $tcdaojiaConfig['wx_share_desc'];
$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=index');
$shareLogo = $tcdaojiaConfig['wx_share_pic'];
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesinfo.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/login.php';
include DISCUZ_ROOT . './source/plugin/tom_tongcheng/class/templatesms.class.php';
$tcadminConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcadmin/tom_tcadmin.inc.php')) {
	$tcadminConfig = $_G['cache']['plugin']['tom_tcadmin'];
}
$__ShowTcrenzheng = 0;
$tcrenzhengConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcrenzheng/tom_tcrenzheng.inc.php')) {
	$tcrenzhengConfig = $_G['cache']['plugin']['tom_tcrenzheng'];
	if ($tcrenzhengConfig['open_tcrenzheng'] == 1) {
		$__ShowTcrenzheng = 1;
	}
}
$__ShowTchehuoren = 0;
$tchehuorenConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tchehuoren/tom_tchehuoren.inc.php')) {
	$tchehuorenConfig = $_G['cache']['plugin']['tom_tchehuoren'];
	if ($tchehuorenConfig['open_tchehuoren'] == 1) {
		$__ShowTchehuoren = 1;
	}
}
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if (file_exists(DISCUZ_ROOT . './source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')) {
	$tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
	if ($tcyikatongConfig['open_tcyikatong'] == 1) {
		$__ShowTcyikatong = 1;
	}
}
$__CardInfo = array();
$__CardExpire = '00/00/00';
if ($__ShowTcyikatong == 1 && $__UserInfo['id'] > 0) {
	$cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($__UserInfo['id']);
	if (is_array($cardInfoTmp) && !empty($cardInfoTmp)) {
		$__CardInfo = $cardInfoTmp;
		$__CardExpire = dgmdate($__CardInfo['expire_time'], 'Y/m/d', $tomSysOffset);
		$__CardInfo['cardTypeInfo'] = C::t('#tom_tcyikatong#tom_tcyikatong_card_type')->fetch_by_id($__CardInfo['card_type_id']);
	}
}
$__ServicerInfo = array();
$__ServicerStatus = 0;
if ($__UserInfo['id'] > 0) {
	$servicerInfoTmpTmp = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_user_id($__UserInfo['id']);
	if ($servicerInfoTmpTmp && $servicerInfoTmpTmp['id'] > 0) {
		$__ServicerInfo = $servicerInfoTmpTmp;
		$__ServicerStatus = 1;
	}
}
$__ClicksInfo = C::t('#tom_tcdaojia#tom_tcdaojia_clicks')->fetch_by_site_id($site_id);
if (!$__ClicksInfo || $__ClicksInfo['id'] <= 0) {
	$insertData = array();
	$insertData['site_id'] = $site_id;
	C::t('#tom_tcdaojia#tom_tcdaojia_clicks')->insert($insertData);
}
$renzheng_back_url = $weixinClass->get_url();
$renzheng_back_url = urlencode($renzheng_back_url);
$personalRenzhengUrl = 'plugin.php?id=tom_tcrenzheng&site=' . $site_id . '&mod=personal&renzheng_back=' . $renzheng_back_url;
$companyRenzhengurl = 'plugin.php?id=tom_tcrenzheng&site=' . $site_id . '&mod=company&renzheng_back=' . $renzheng_back_url;
$depositUrl = 'plugin.php?id=tom_tcrenzheng&site=' . $site_id . '&mod=deposit&renzheng_back=' . $renzheng_back_url;
$ajaxUpdateGoodsTopStatusUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=update_goods_top_status&formhash=' . $formhash;
$ajaxUpdateNeedsTopStatusUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=update_needs_top_status&formhash=' . $formhash;
$ajaxUpdateServicerTopStatusUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=update_servicer_top_status&formhash=' . $formhash;
$ajaxUpdateServicerDengjiStatusUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=update_servicer_dengji_status&formhash=' . $formhash;
$vipUpdateUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=vipUpdate&formhash=' . $formhash;
$ajaxUpdateLbsUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=update_lbs&formhash=' . $formhash;
$ajaxGoodsAutoPinglunUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=goods_auto_pinglun&formhash=' . $formhash;
$ajaxCommonClicksUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=clicks&formhash=' . $formhash;
$ajaxGlobalTopnavLoadListUrl = 'plugin.php?id=tom_tongcheng:ajax&site=' . $site_id . '&act=global_topnav_list&&formhash=' . $formhash;
if ($_GET['mod'] == 'index') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/site_ibs.php';
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$focuspicListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_focuspic')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	if (!is_array($focuspicListTmp) || empty($focuspicListTmp)) {
		$focuspicListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_focuspic')->fetch_all_list(' AND site_id=1 ', ' ORDER BY fsort ASC,id DESC ', 0, 10);
	}
	$focuspicList = array();
	$focuspicCount = 0;
	if (is_array($focuspicListTmp) && !empty($focuspicListTmp)) {
		foreach ($focuspicListTmp as $key => $value) {
			$focuspicList[$key] = $value;
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$focuspicList[$key]['picurl'] = $picurl;
			$focuspicList[$key]['link'] = str_replace('{site}', $site_id, $focuspicList[$key]['link']);
			$focuspicCount++;
		}
	}
	$diyListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_diynav')->fetch_all_list(' AND site_id=' . $site_id . ' ', ' ORDER BY dsort ASC,id DESC ', 0, 100);
	if (!is_array($diyListTmp) || empty($diyListTmp)) {
		$diyListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_diynav')->fetch_all_list(' AND site_id=1 ', ' ORDER BY dsort ASC,id DESC ', 0, 100);
	}
	$diyList = array();
	$i = 1;
	$navCount = 0;
	if (is_array($diyListTmp) && !empty($diyListTmp)) {
		foreach ($diyListTmp as $key => $value) {
			$diyList[$key] = $value;
			$diyList[$key]['i'] = $i;
			$diyList[$key]['link'] = str_replace('{site}', $site_id, $diyList[$key]['link']);
			if (!preg_match('/^http/', $value['picurl'])) {
				if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
					$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
				} else {
					$picurl = $value['picurl'];
				}
			} else {
				$picurl = $value['picurl'];
			}
			$diyList[$key]['picurl'] = $picurl;
			$i++;
			$navCount++;
		}
	}
	$tuiList = array();
	$i = 1;
	if (!empty($tcdaojiaConfig['index_tui_list'])) {
		$index_tui_str = str_replace('{site}', $site_id, $tcdaojiaConfig['index_tui_list']);
		$index_tui_str = str_replace("\r\n", '{n}', $index_tui_str);
		$index_tui_str = str_replace("\n", '{n}', $index_tui_str);
		$index_tui_arr = explode('{n}', $index_tui_str);
		if (is_array($index_tui_arr) && !empty($index_tui_arr)) {
			foreach ($index_tui_arr as $key => $value) {
				$tuiList[$i] = explode('|', $value);
				$i++;
			}
		}
	}
	$tuiCount = count($tuiList);
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=goodslist&template_type=1&formhash=' . $formhash;
	$ajaxLoadServicerListUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=servicerlist&formhash=' . $formhash;
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=index'));
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcdaojia:index');
} elseif ($_GET['mod'] == 'goodslist') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$paixu_type = intval($_GET['paixu_type']) > 0 ? intval($_GET['paixu_type']) : 1;
	$cateName = '';
	$cateList = array();
	$cateListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(' AND pid = 0 ', 'ORDER BY csort ASC,id DESC', 0, 100);
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			if ($cate_id == $value['id']) {
				$cateName = $value['name'];
			}
		}
	}
	$cateChildName = '';
	if ($cate_child_id > 0) {
		$cateChildInfo = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($cate_child_id);
		if ($cateChildInfo['id'] > 0) {
			$cate_id = $cateChildInfo['pid'];
			$cateChildName = $cateChildInfo['name'];
		}
	}
	if ($cate_id > 0) {
		$cateChildListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(' AND pid = ' . $cate_id . ' ', 'ORDER BY csort ASC,id DESC', 0, 100);
		$cateChildList = array();
		if (is_array($cateChildListTmp) && !empty($cateChildListTmp)) {
			foreach ($cateChildListTmp as $key => $value) {
				$cateChildList[$key] = $value;
				if (!preg_match('/^http/', $value['picurl'])) {
					if (strpos($value['picurl'], 'source/plugin/tom_') === false) {
						$picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $value['picurl'];
					} else {
						$picurl = $value['picurl'];
					}
				} else {
					$picurl = $value['picurl'];
				}
				$cateChildList[$key]['picurl'] = $picurl;
				if ($cate_child_id == $value['id']) {
					$cateName = $value['name'];
				}
			}
		}
	}
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$areaList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$goodslistUrl = 'plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=goodslist&';
	$ajaxLoadCateListUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=load_cate_item_list&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$ajaxListUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=goodslist&template_type=2&formhash=' . $formhash;
	$shareTitle = lang('plugin/tom_tcdaojia', 'goodslist_title') . '-' . $tcdaojiaConfig['plugin_name'];
	if (!empty($cateChildName)) {
		$shareTitle = $cateChildName . '-' . $tcdaojiaConfig['plugin_name'];
	} else {
		if (!empty($cateName)) {
			$shareTitle = $cateName . '-' . $tcdaojiaConfig['plugin_name'];
		}
	}
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=goodslist&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&area_id=' . $area_id . '&street_id=' . $street_id);
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=goodslist&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&area_id=' . $area_id . '&street_id=' . $street_id));
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcdaojia:goodslist');
} elseif ($_GET['mod'] == 'search_goods') {
	$searchArr = array();
	$goodsSearchArr = explode('|', $tcdaojiaConfig['default_search_goods_str']);
	if (is_array($goodsSearchArr) && !empty($goodsSearchArr)) {
		foreach ($goodsSearchArr as $key => $value) {
			$searchArr[] = daddslashes($value);
		}
	}
	$searchCount = count($searchArr);
	$ajaxSearchUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=get_search_goods_url&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcdaojia:search_goods');
} elseif ($_GET['mod'] == 'goodsinfo') {
	$goods_id = intval($_GET['goods_id']) > 0 ? intval($_GET['goods_id']) : 0;
	$goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($goods_id);
	$servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($goodsInfo['servicer_id']);
	$servicerVipInfo = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_by_id($servicerInfo['vip_id']);
	if ($goodsInfo['status'] != 1 || $goodsInfo['shenhe_status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	if (!$servicerInfo || $servicerInfo['id'] <= 0) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	$tj_hehuoren_id = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
	if ($__ShowTchehuoren == 1 && $__UserInfo['id'] > 0) {
		if ($tchehuorenConfig['tcdaojia_type'] == 1 || $tchehuorenConfig['tcdaojia_type'] == 3) {
			if ($tj_hehuoren_id > 0) {
				$lifeTime = 86400;
				dsetcookie('tom_tcdaojia_tj_hehuoren_id', $tj_hehuoren_id, $lifeTime);
			} else {
				$cookie_tj_hehuoren_id = getcookie('tom_tcdaojia_tj_hehuoren_id');
				if ($cookie_tj_hehuoren_id > 0) {
					$tj_hehuoren_id = $cookie_tj_hehuoren_id;
				}
			}
		}
		if ($tchehuorenConfig['tcdaojia_type'] == 2 && $__UserInfo['tj_hehuoren_id'] > 0) {
			$tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
		}
		if ($tchehuorenConfig['tcdaojia_type'] == 3 && $__UserInfo['tj_hehuoren_id'] > 0 && $tj_hehuoren_id == 0) {
			$tj_hehuoren_id = $__UserInfo['tj_hehuoren_id'];
		}
	}
	$goodsInfo['sale_num'] = $goodsInfo['sale_num'] + $goodsInfo['virtual_sale_num'];
	$orderCount = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_count('AND order_status IN (2,3,4) AND servicer_id = ' . $goodsInfo['servicer_id']);
	$virtualSaleNumCount = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_sun_virtual_sale_num(' AND servicer_id = ' . $goodsInfo['servicer_id'] . ' AND status=1 AND shenhe_status=1 ');
	$orderCount = $orderCount + $virtualSaleNumCount;
	$servicerCount = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_count('AND servicer_id = ' . $goodsInfo['servicer_id']);
	$goodPinglunCount = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun')->fetch_all_count('AND grade >= 4 AND servicer_id=' . $servicerInfo['id']);
	$pinglunCount = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun')->fetch_all_count('AND servicer_id=' . $servicerInfo['id'] . ' ');
	$goodPinglun = $goodPinglunCount / $pinglunCount * 100;
	$goodPinglun = round($goodPinglun, 2);
	$showVipPriceStatus = 0;
	if ($__ShowTcyikatong == 1 && $goodsInfo['open_vip'] == 1) {
		$showVipPriceStatus = 1;
	}
	$goodsPhotoListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(' AND goods_id = ' . $goods_id . ' AND type IN (1,2) ', 'ORDER BY id ASC', 0, 100);
	$goods_pic = $servicer_pic = $servicer_wxpic = '';
	$goodsphotoList = array();
	$goodsphotoListStr = '';
	if (is_array($goodsPhotoListTmp) && !empty($goodsPhotoListTmp)) {
		foreach ($goodsPhotoListTmp as $kk => $vv) {
			if ($vv['type'] == 1) {
				$goods_pic = $vv['picurlTmp'];
			} elseif ($vv['type'] == 2) {
				$goodsphotoList[] = $vv['picurlTmp'];
			}
		}
		$goodsphotoListStr = implode('|', $goodsphotoList);
	}
	$servicerPhotoListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(' AND servicer_id = ' . $servicerInfo['id'] . ' AND type IN (3,4) ', 'ORDER BY id ASC', 0, 100);
	if (is_array($servicerPhotoListTmp) && !empty($servicerPhotoListTmp)) {
		foreach ($servicerPhotoListTmp as $kk => $vv) {
			if ($vv['type'] == 3) {
				$servicer_pic = $vv['picurlTmp'];
			} elseif ($vv['type'] == 4) {
				$servicer_wxpic = $vv['picurlTmp'];
			}
		}
	}
	$noPayOrderListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_list(' AND goods_id=' . $goods_id . ' AND order_status=1 AND type = 3', ' ORDER BY id DESC ', 0, 10);
	if (is_array($noPayOrderListTmp) && !empty($noPayOrderListTmp)) {
		foreach ($noPayOrderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tcdaojia_order') . (' SET order_status=6 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcdaojia_goods') . (' SET sale_num=sale_num - 1 WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
				}
			}
		}
	}
	$isClerk = 0;
	if ($servicerInfo['user_id'] == $__UserInfo['id']) {
		$isClerk = 1;
	}
	if ($__UserInfo['id'] > 0) {
		$isCollect = C::t('#tom_tcdaojia#tom_tcdaojia_collect')->fetch_all_list('AND user_id = ' . $__UserInfo['id'] . ' AND goods_id =' . $goods_id, ' ORDER BY id DESC ', 0, 1);
	}
	$pinglunCount = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun')->fetch_all_count(' AND goods_id = ' . $goods_id . ' ');
	$pinglunListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun')->fetch_all_list(' AND goods_id = ' . $goods_id . ' ', 'ORDER BY id DESC', 0, 1);
	$pinglunList = array();
	if (is_array($pinglunListTmp) && !empty($pinglunListTmp)) {
		foreach ($pinglunListTmp as $key => $value) {
			$pinglunList[$key] = $value;
			$pinglunUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
			$pinglunPhotoListTmpTmp = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun_photo')->fetch_all_list(' AND pinglun_id = ' . $value['id'] . ' ', 'ORDER BY id DESC', 0, 100);
			$pinglunPhotoListTmp = array();
			if (is_array($pinglunPhotoListTmpTmp) && !empty($pinglunPhotoListTmpTmp)) {
				foreach ($pinglunPhotoListTmpTmp as $pk => $pv) {
					if (!preg_match('/^http/', $pv['picurl'])) {
						if (strpos($pv['picurl'], 'source/plugin/') === false) {
							$pinglunPhotoListTmp[] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $pv['picurl'];
						} else {
							$pinglunPhotoListTmp[] = $pv['picurl'];
						}
					} else {
						$pinglunPhotoListTmp[] = $pv['picurl'];
					}
				}
			}
			$replyPinglunListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun_reply')->fetch_all_list(' AND pinglun_id = ' . $value['id'] . ' ', 'ORDER BY id ASC', 0, 10);
			$pinglunList[$key]['userInfo'] = $pinglunUserInfo;
			$pinglunList[$key]['photoList'] = $pinglunPhotoListTmp;
			$pinglunList[$key]['photoStr'] = implode('|', $pinglunPhotoListTmp);
			$pinglunList[$key]['replyList'] = $replyPinglunListTmp;
		}
	}
	$companyRenzhengStatus = $personalRenzhengStatus = 0;
	if ($__ShowTcrenzheng == 1) {
		$companyInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_user_id($servicerInfo['user_id']);
		if (is_array($companyInfoTmp) && $companyInfoTmp['shenhe_status'] == 1) {
			$companyRenzhengStatus = 1;
		}
		$personalInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_user_id($servicerInfo['user_id']);
		if (is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1) {
			$personalRenzhengStatus = 1;
		}
	}
	$optionListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->fetch_all_list('AND goods_id = ' . $goods_id, 'ORDER BY osort ASC,id DESC', 0, 20);
	$optionList = array();
	if (is_array($optionListTmp) && !empty($optionListTmp)) {
		foreach ($optionListTmp as $key => $value) {
			$optionList[$key] = $value;
		}
	}
	$optionCount = count($optionList);
	$content = stripslashes($goodsInfo['content']);
	$content = str_replace("\r\n", '<br/>', $content);
	$content = str_replace("\n", '<br/>', $content);
	$content = str_replace("\r", '<br/>', $content);
	$area_id = str_replace('|', ',', $servicerInfo['area_ids']);
	$area_id = str_replace('all', '', $area_id);
	$area_id = substr($area_id, 1);
	$area_id = substr($area_id, 0, 0 - 1);
	$areaList = array();
	if (!empty($area_id)) {
		$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_list('AND id IN (' . $area_id . ') ');
		if (is_array($areaListTmp) && !empty($areaListTmp)) {
			foreach ($areaListTmp as $key => $value) {
				$areaList[$key] = $value;
			}
		}
	}
	$goodsCount = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_count('AND id != ' . $goods_id . ' AND status =1 AND shenhe_status = 1 AND cate_id = ' . $goodsInfo['cate_id'] . ' ');
	$goodsListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_list(' AND id != ' . $goods_id . ' AND status =1 AND shenhe_status = 1 AND cate_id = ' . $goodsInfo['cate_id'] . ' ', 'ORDER BY add_time ASC,paixu ASC,id DESC', 0, 6);
	$goodsList = array();
	foreach ($goodsListTmp as $key => $value) {
		$goodsList[$key] = $value;
		$servicerInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($value['servicer_id']);
		$goodsPicListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(' AND goods_id = ' . $value['id'] . '  AND type = 1 ', 'ORDER BY id ASC', 0, 1);
		$servicerPicListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(' AND servicer_id = ' . $value['servicer_id'] . '  AND type = 3 ', 'ORDER BY id ASC', 0, 1);
		$goodsPicurl = $servicerPicurl = '';
		if (is_array($goodsPicListTmp) && !empty($goodsPicListTmp) && isset($goodsPicListTmp[0])) {
			$goodsPicurl = $goodsPicListTmp[0]['picurlTmp'];
		}
		if (is_array($servicerPicListTmp) && !empty($servicerPicListTmp) && isset($servicerPicListTmp[0])) {
			$servicerPicurl = $servicerPicListTmp[0]['picurlTmp'];
		}
		$goodsList[$key]['servicerInfo'] = $servicerInfoTmp;
		$goodsList[$key]['picurl'] = $goodsPicurl;
		$goodsList[$key]['servicerPicurl'] = $servicerPicurl;
		$goodsList[$key]['link'] = 'plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=goodsinfo&goods_id=' . $value['id'];
	}
	if (!preg_match('/^http/', $goodsInfo['haibao_picurl'])) {
		if (strpos($goodsInfo['haibao_picurl'], 'source/plugin/tom_') === false) {
			$haibao_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']) . $_G['setting']['attachurl'] . 'tomwx/' . $goodsInfo['haibao_picurl'];
		} else {
			$haibao_picurl = $goodsInfo['haibao_picurl'];
		}
	} else {
		$haibao_picurl = $goodsInfo['haibao_picurl'];
	}
	$showTgButton = $pay_price = $pt_money = $servicer_money = $needPrice = 0;
	if ($__ShowTchehuoren == 1 && $goodsInfo['hehuoren_tg_open'] == 1 && $__UserInfo['id'] > 0) {
		$tchehuorenInfo = C::t('#tom_tchehuoren#tom_tchehuoren')->fetch_by_user_id($__UserInfo['id']);
		if ($tchehuorenInfo['id'] > 0 && $tchehuorenInfo['status'] == 1) {
			$dengjiInfoTmp = C::t('#tom_tchehuoren#tom_tchehuoren_dengji')->fetch_by_id($tchehuorenInfo['dengji_id']);
			$dengjiInfo = array();
			if (is_array($dengjiInfoTmp) && !empty($dengjiInfoTmp)) {
				$dengjiInfo = $dengjiInfoTmp;
			}
			if ($dengjiInfo['daojia_fc_open'] == 1) {
				$showTgButton = 1;
				if ($goodsInfo['price'] > 0) {
					$pay_price = $goodsInfo['price'];
				} else {
					if ($goodsInfo['open_ding_pay'] == 1) {
						$pay_price = $goodsInfo['ding_price'];
					}
				}
				$yongjin_bili = $tcdaojiaConfig['yongjin_bili'];
				if ($servicerVipInfo && $servicerVipInfo['id'] > 0) {
					$yongjin_bili = $servicerVipInfo['yongjin_bili'];
				}
				$pt_money = $pay_price * ($yongjin_bili / 100);
				$pt_money = number_format($pt_money, 2, '.', '');
				$servicer_money = $pay_price - $pt_money;
				if ($goodsInfo['hehuoren_tg_type'] == 1) {
					$needPrice = $goodsInfo['hehuoren_fc_scale'];
				} elseif ($goodsInfo['hehuoren_tg_type'] == 2) {
					$needPrice = $servicer_money * ($goodsInfo['hehuoren_fc_scale'] / 100);
					$needPrice = number_format($needPrice, 2, '.', '');
				}
			}
		}
	}
	$showBuyBtn = 1;
	if ($servicerInfo['jie_status'] != 1) {
		$showBuyBtn = 2;
	}
	if ($tcdaojiaConfig['open_ruzhu_pay_money'] == 1 && $servicerInfo['dengji_id'] <= 0) {
		$showBuyBtn = 3;
	}
	$buy_goods_know_txt = discuzcode($tcdaojiaConfig['buy_goods_know'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);
	$add_time = dgmdate($goodsInfo['add_time'], 'm-d H:i', $tomSysOffset);
	$ajaxAddShoucangUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=addshoucang';
	$replyPinglunUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=reply_pinglun&goods_id=' . $goods_id . '&servicer_id=' . $servicerInfo['id'] . '&formhash=' . $formhash;
	$tousuUrl = 'plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=report&report_user_id=' . $goodsInfo['user_id'] . '&goods_id=' . $goodsInfo['id'];
	$kefuSmsUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&&to_user_id=' . $servicerInfo['user_id'] . '&formhash=' . FORMHASH;
	$ajaxClicksUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=goods_clicks&goods_id=' . $goods_id . '&formhash=' . $formhash;
	$shareTitle = $goodsInfo['title'] . '-' . $tcdaojiaConfig['plugin_name'];
	$shareLogo = $goods_pic;
	if ($showTgButton == 1) {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=goodsinfo&goods_id=' . $goods_id . '&tj_hehuoren_id=' . $tchehuorenInfo['id']);
	} else {
		$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=goodsinfo&goods_id=' . $goods_id);
	}
	if ($tj_hehuoren_id > 0 && $goodsInfo['hehuoren_tg_open'] == 1) {
		$buyUrl = 'plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=buy&goods_id=' . $goods_id . '&tj_hehuoren_id=' . $tj_hehuoren_id;
	} else {
		$buyUrl = 'plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=buy&goods_id=' . $goods_id;
	}
	$haibaoQrcodeImg = $_G['siteurl'] . 'plugin.php?id=tom_qrcode&data=' . urlencode($shareUrl);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcdaojia:goodsinfo');
} elseif ($_GET['mod'] == 'needslist') {
	include DISCUZ_ROOT . './source/plugin/tom_tongcheng/sitesids.php';
	$keyword = isset($_GET['keyword']) ? daddslashes(diconv(urldecode($_GET['keyword']), 'utf-8')) : '';
	$area_id = intval($_GET['area_id']) > 0 ? intval($_GET['area_id']) : 0;
	$street_id = intval($_GET['street_id']) > 0 ? intval($_GET['street_id']) : 0;
	$cate_id = intval($_GET['cate_id']) > 0 ? intval($_GET['cate_id']) : 0;
	$cate_child_id = intval($_GET['cate_child_id']) > 0 ? intval($_GET['cate_child_id']) : 0;
	$paixu_type = intval($_GET['paixu_type']) > 0 ? intval($_GET['paixu_type']) : 1;
	$needs_type = intval($_GET['needs_type']) > 0 ? intval($_GET['needs_type']) : 0;
	$vip_id = intval($_GET['vip_id']) > 0 ? intval($_GET['vip_id']) : 0;
	$cateName = '';
	$cateList = array();
	$cateListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(' AND pid = 0 ', 'ORDER BY csort ASC,id DESC', 0, 100);
	if (is_array($cateListTmp) && !empty($cateListTmp)) {
		foreach ($cateListTmp as $key => $value) {
			$cateList[$key] = $value;
			if ($cate_id == $value['id']) {
				$cateName = $value['name'];
			}
		}
	}
	if ($cate_child_id > 0) {
		$cateChildInfo = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($cate_child_id);
		if ($cateChildInfo['id'] > 0) {
			$cate_id = $cateChildInfo['pid'];
		}
	}
	if ($cate_id > 0) {
		$cateChildListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(' AND pid = ' . $cate_id . ' ', 'ORDER BY csort ASC,id DESC', 0, 100);
		$cateChildList = array();
		if (is_array($cateChildListTmp) && !empty($cateChildListTmp)) {
			foreach ($cateChildListTmp as $key => $value) {
				$cateChildList[$key] = $value;
				if ($cate_child_id == $value['id']) {
					$cateName = $value['name'];
				}
			}
		}
	}
	$areaName = '';
	$areaListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
	$areaList = array();
	if (is_array($areaListTmp) && !empty($areaListTmp)) {
		foreach ($areaListTmp as $key => $value) {
			$areaList[$key] = $value;
			if ($value['id'] == $area_id) {
				$areaName = $value['name'];
			}
		}
	}
	if ($area_id > 0) {
		$streetListTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
		$streetList = array();
		if (is_array($streetListTmp) && !empty($streetListTmp)) {
			foreach ($streetListTmp as $key => $value) {
				$streetList[$key] = $value;
				if ($value['id'] == $street_id) {
					$areaName = $value['name'];
				}
			}
		}
	}
	$vipListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_all_list('');
	$vipList = array();
	if (is_array($vipListTmp) && !empty($vipListTmp)) {
		foreach ($vipListTmp as $key => $value) {
			$vipList[$key] = $value;
		}
	}
	$needslistUrl = 'plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=needslist&';
	$ajaxLoadCateListUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=load_cate_list&formhash=' . $formhash;
	$ajaxLoadStreetListUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=load_street_list&formhash=' . $formhash;
	$ajaxListUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=needslist&formhash=' . $formhash;
	$ajaxDingyueUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&user_id=' . $__UserInfo['id'] . '&cate_id=' . $cate_id . '&formhash=' . $formhash;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=needslist&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&area_id=' . $area_id . '&street_id=' . $street_id);
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=needslist&cate_id=' . $cate_id . '&cate_child_id=' . $cate_child_id . '&area_id=' . $area_id . '&street_id=' . $street_id));
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcdaojia:needslist');
} elseif ($_GET['mod'] == 'search_needs') {
	$searchArr = array();
	$needsSearchArr = explode('|', $tcdaojiaConfig['default_search_needs_str']);
	if (is_array($needsSearchArr) && !empty($needsSearchArr)) {
		foreach ($needsSearchArr as $key => $value) {
			$searchArr[] = daddslashes($value);
		}
	}
	$searchCount = count($searchArr);
	$ajaxSearchUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=get_search_needs_url&formhash=' . $formhash;
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcdaojia:search_needs');
} elseif ($_GET['mod'] == 'needsinfo') {
	$needs_id = intval($_GET['needs_id']) > 0 ? intval($_GET['needs_id']) : 0;
	$needsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($needs_id);
	$userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);
	if ($needsInfo['status'] != 1 || $needsInfo['shenhe_status'] != 1) {
		tomheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=index'));
		exit(0);
	}
	if ($needsInfo['area_id'] > 0) {
		$areaInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($needsInfo['area_id']);
		$streetInfo = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($needsInfo['street_id']);
	}
	if ($needsInfo['cate_id'] > 0) {
		$cateInfo = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($needsInfo['cate_id']);
		$catechildInfo = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($needsInfo['cate_child_id']);
	}
	$servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_all_list('AND user_id = ' . $__UserInfo['id'] . ' AND shenhe_status = 1 AND status = 1', '', 0, 1);
	$needs_jieInfo = array();
	if ($servicerInfo && $servicerInfo[0]['id'] > 0) {
		$needs_jieInfo = C::t('#tom_tcdaojia#tom_tcdaojia_needs_jie')->fetch_all_list('AND needs_id =' . $needs_id . ' AND servicer_id = ' . $servicerInfo[0]['id'] . ' AND status = 0', '', 0, 1);
	}
	$vipInfo = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_by_id($needsInfo['vip_id']);
	$content = stripslashes($needsInfo['content']);
	$content = str_replace("\r\n", '<br/>', $content);
	$content = str_replace("\n", '<br/>', $content);
	$content = str_replace("\r", '<br/>', $content);
	$title = strip_tags($content);
	$title = str_replace("\r\n", '', $title);
	$title = str_replace("\n", '', $title);
	$title = str_replace("\r", '', $title);
	$needsphotoListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list('AND needs_id = ' . $needs_id . ' AND type = 6', 'ORDER BY id ASC', 0, 100);
	$needsphotoList = array();
	$needsphotoListStr = '';
	if (is_array($needsphotoListTmp) && !empty($needsphotoListTmp)) {
		foreach ($needsphotoListTmp as $kk => $vv) {
			$picurlTmp = $vv['picurlTmp'];
			$needsphotoList[] = $picurlTmp;
		}
		$needsphotoListStr = implode('|', $needsphotoList);
	}
	$needs_jieListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_needs_jie')->fetch_all_list('AND needs_id =' . $needs_id . ' ', 'ORDER BY price DESC,id DESC', 0, 20);
	$needs_jieList = array();
	if (is_array($needs_jieListTmp) && !empty($needs_jieListTmp)) {
		foreach ($needs_jieListTmp as $key => $value) {
			$needs_jieList[$key] = $value;
			$servicerInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($value['servicer_id']);
			$needs_jieList[$key]['servicerInfo'] = $servicerInfoTmp;
			$needs_jieList[$key]['refresh_time'] = dgmdate($value['refresh_time'], 'Y-m-d H:i', $tomSysOffset);
			$servicerLogoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list('AND servicer_id = ' . $value['servicer_id'] . ' AND type = 3', 'ORDER BY id ASC', 0, 1);
			$needs_jieList[$key]['servicerlogo'] = $servicerLogoTmp[0]['picurlTmp'];
		}
	}
	$needs_jieCount = count($needs_jieList);
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tcdaojiaConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$is_servicer = 0;
	if (is_array($servicerInfo) && !empty($servicerInfo)) {
		$is_servicer = 1;
	}
	$baiduMapToName = $needsInfo['content'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapToAddress = $needsInfo['address'];
	$baiduMapToAddress = diconv($baiduMapToAddress, CHARSET, 'utf-8');
	$baiduMapToAddress = urlencode($baiduMapToAddress);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $needsInfo['latitude'] . ',' . $needsInfo['longitude'] . '&title=' . $baiduMapToName . '&content=' . $baiduMapToAddress . '&output=html';
	$add_time = dgmdate($needsInfo['add_time'], 'm-d H:i', $tomSysOffset);
	$fuwu_time = dgmdate($needsInfo['fuwu_time'], 'Y-m-d H:i', $tomSysOffset);
	$jingjiaUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=needs_jingjia_save&servicer_id=' . $servicerInfo[0]['id'] . '&needs_id=' . $needs_id . '&formhash=' . $formhash;
	$yikoujiaUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=needs_yikoujia_save&servicer_id=' . $servicerInfo[0]['id'] . '&needs_id=' . $needs_id . '&formhash=' . $formhash;
	$tousuUrl = 'plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=report&report_user_id=' . $needsInfo['user_id'] . '&needs_id=' . $needsInfo['id'];
	$ajaxClicksUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=needs_clicks&needs_id=' . $needs_id . '&formhash=' . $formhash;
	$kefuSmsUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&&to_user_id=' . $needsInfo['user_id'] . '&formhash=' . FORMHASH;
	$shareTitle = $title . '-' . $tcdaojiaConfig['plugin_name'];
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=needsinfo&needs_id=' . $needs_id);
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcdaojia:needsinfo');
} elseif ($_GET['mod'] == 'servicerinfo') {
	$servicer_id = intval($_GET['servicer_id']) > 0 ? intval($_GET['servicer_id']) : 0;
	$servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($servicer_id);
	$companyRenzhengStatus = $personalRenzhengStatus = 0;
	if ($__ShowTcrenzheng == 1) {
		$companyInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_company')->fetch_by_user_id($servicerInfo['user_id']);
		if (is_array($companyInfoTmp) && $companyInfoTmp['shenhe_status'] == 1) {
			$companyRenzhengStatus = 1;
		}
		$personalInfoTmp = C::t('#tom_tcrenzheng#tom_tcrenzheng_personal')->fetch_by_user_id($servicerInfo['user_id']);
		if (is_array($personalInfoTmp) && $personalInfoTmp['shenhe_status'] == 1) {
			$personalRenzhengStatus = 1;
		}
	}
	$servicerLogoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list('AND servicer_id = ' . $servicer_id . ' AND type = 3', 'ORDER BY id ASC', 0, 1);
	$servicerLogo = '';
	if (is_array($servicerLogoTmp) && !empty($servicerLogoTmp)) {
		foreach ($servicerLogoTmp as $kk => $vv) {
			$servicerLogo = $vv['picurlTmp'];
		}
	}
	$servicerphotoListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list('AND servicer_id = ' . $servicer_id . ' AND type = 5', 'ORDER BY id ASC', 0, 100);
	$servicerphotoList = array();
	$servicerphotoListStr = '';
	if (is_array($servicerphotoListTmp) && !empty($servicerphotoListTmp)) {
		foreach ($servicerphotoListTmp as $kk => $vv) {
			$picurlTmp = $vv['picurlTmp'];
			$servicerphotoList[] = $picurlTmp;
		}
		$servicerphotoListStr = implode('|', $servicerphotoList);
	}
	$open_wx_map = 0;
	if ($__IsWeixin == 1 && $tcdaojiaConfig['open_wx_map'] == 1) {
		$open_wx_map = 1;
	}
	$content = stripslashes($servicerInfo['content']);
	$content = str_replace("\r\n", '<br/>', $content);
	$content = str_replace("\n", '<br/>', $content);
	$content = str_replace("\r", '<br/>', $content);
	$baiduMapToName = $servicerInfo['name'];
	$baiduMapToName = diconv($baiduMapToName, CHARSET, 'utf-8');
	$baiduMapToName = urlencode($baiduMapToName);
	$baiduMapToAddress = $servicerInfo['address'];
	$baiduMapToAddress = diconv($baiduMapToAddress, CHARSET, 'utf-8');
	$baiduMapToAddress = urlencode($baiduMapToAddress);
	$baiduMapUrl = 'http://api.map.baidu.com/marker?location=' . $servicerInfo['latitude'] . ',' . $servicerInfo['longitude'] . '&title=' . $baiduMapToName . '&content=' . $baiduMapToAddress . '&output=html';
	$ajaxLoadListUrl = 'plugin.php?id=tom_tcdaojia:ajax&site=' . $site_id . '&act=goodslist&servicer_id=' . $servicer_id . '&template_type=2&formhash=' . $formhash;
	$messageUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=message&act=create&to_user_id=' . $servicerInfo['user_id'] . '&formhash=' . FORMHASH;
	$tousuUrl = 'plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=report&report_user_id=' . $servicerInfo['user_id'] . '&servicer_id=' . $servicerInfo['id'];
	$shareTitle = $servicerInfo['name'] . '-' . $tcdaojiaConfig['plugin_name'];
	$shareLogo = $servicerLogo;
	$shareUrl = $_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=servicerinfo&servicer_id=' . $servicer_id);
	$md5HostUrl = md5($_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=servicerinfo&servicer_id=' . $servicer_id));
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcdaojia:servicerinfo');
} elseif ($_GET['mod'] == 'buy') {
	$goods_id = intval($_GET['goods_id']) > 0 ? intval($_GET['goods_id']) : 0;
	$option_id = intval($_GET['option_id']) > 0 ? intval($_GET['option_id']) : 0;
	$number = intval($_GET['number']) > 0 ? intval($_GET['number']) : 1;
	$address_id = isset($_GET['address_id']) ? intval($_GET['address_id']) : 0;
	$tj_hehuoren_id = intval($_GET['tj_hehuoren_id']) > 0 ? intval($_GET['tj_hehuoren_id']) : 0;
	$address_back_url = $weixinClass->get_url();
	$address_back_url = preg_replace('/&address_id=[0-9]*/', '', $address_back_url);
	$address_back_url = urlencode($address_back_url);
	$goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($goods_id);
	$servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($goodsInfo['servicer_id']);
	$price = $goodsInfo['price'];
	$vip_price = $goodsInfo['vip_price'];
	$sale_num = $goodsInfo['sale_num'];
	if ($goodsInfo['hasoption'] == 1) {
		$optionInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->fetch_by_id($option_id);
		if (is_array($optionInfo) && !empty($optionInfo) && $optionInfo['id'] > 0) {
			$price = $optionInfo['price'];
			$vip_price = $optionInfo['vip_price'];
			$sale_num = $optionInfo['sale_num'];
		}
	}
	$goodsPhotoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(' AND goods_id = ' . $goods_id . ' AND type =1', 'ORDER BY id ASC', 0, 1);
	$goods_pic = '';
	if (is_array($goodsPhotoTmp) && !empty($goodsPhotoTmp[0])) {
		$goods_pic = $goodsPhotoTmp[0]['picurlTmp'];
	}
	$setAddressStatus = 0;
	$setAddressUrl = '';
	$addressListCount = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_count(' AND uid=' . $__MemberInfo['uid'] . ' ');
	if ($addressListCount == 0) {
		$setAddressStatus = 1;
		$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $address_back_url);
	}
	$addressInfo = array();
	$addressInfoTmp = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
	if ($addressInfoTmp && !empty($addressInfoTmp['id'])) {
		$address_id = $addressInfoTmp['id'];
		$addressInfo = $addressInfoTmp;
	} else {
		$defaultAddressList = C::t('#tom_ucenter#tom_ucenter_address')->fetch_all_list(' AND uid=' . $__MemberInfo['uid'] . ' AND default_id=1 ', 'ORDER BY id DESC', 0, 1);
		if ($defaultAddressList && !empty($defaultAddressList['0']['id'])) {
			$address_id = $defaultAddressList['0']['id'];
			$addressInfo = $defaultAddressList['0'];
		} else {
			$setAddressStatus = 1;
			$setAddressUrl = $_G['siteurl'] . ('plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&act=add&buying=1&address_back_url=' . $address_back_url);
		}
	}
	$changeAddressUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=address&buying=1&address_id=' . $address_id . '&address_back_url=' . $address_back_url;
	$tcyikatongPayStatus = 0;
	if ($__ShowTcyikatong == 1 && $goodsInfo['open_vip'] == 1) {
		if ($__CardInfo['status'] == 1) {
			$tcyikatongPayStatus = 1;
		}
	}
	$pay_price = 0;
	$shenyu_price = 0;
	$ding_price_status = 0;
	if ($goodsInfo['open_ding_pay'] == 1) {
		$ding_price_status = 1;
		$pay_price = $goodsInfo['ding_price'];
		if ($tcyikatongPayStatus == 1) {
			$shenyu_price = $vip_price - $goodsInfo['ding_price'];
		} else {
			$shenyu_price = $price - $goodsInfo['ding_price'];
		}
		$shenyu_price = number_format($shenyu_price, 2, '.', '');
	} else {
		if ($tcyikatongPayStatus == 1) {
			$pay_price = $vip_price;
		} else {
			$pay_price = $price;
		}
	}
	$pay_price_arr = array();
	$shenyu_price_arr = array();
	for ($i = 1; $i <= 100; $i++) {
		$pay_price_arr[$i] = $pay_price * $i;
		$shenyu_price_arr[$i] = $shenyu_price * $i;
	}
	$orderListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_list(' AND goods_id=' . $goods_id . ' AND order_status=1 ', ' ORDER BY id DESC ', 0, 20);
	if (is_array($orderListTmp) && !empty($orderListTmp)) {
		foreach ($orderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tcdaojia_goods') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcdaojia_order') . (' SET order_status=6 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
					if ($value['option_id'] > 0) {
						DB::query('UPDATE ' . DB::table('tom_tcdaojia_goods_option') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['option_id'] . '\' '), 'UNBUFFERED');
					}
				}
			}
		}
	}
	$noPayOrderListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_list(' AND goods_id=' . $goods_id . ' AND user_id=' . $__UserInfo['id'] . ' AND order_status=1 AND type = 3', ' ORDER BY id DESC ', 0, 10);
	$isHaveNoPay = 0;
	if (is_array($noPayOrderListTmp) && !empty($noPayOrderListTmp)) {
		foreach ($noPayOrderListTmp as $key => $value) {
			if ($value['order_status'] == 1) {
				if (TIMESTAMP - $value['order_time'] > 3600) {
					DB::query('UPDATE ' . DB::table('tom_tcdaojia_goods') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['goods_id'] . '\' '), 'UNBUFFERED');
					DB::query('UPDATE ' . DB::table('tom_tcdaojia_order') . (' SET order_status=6 WHERE id=\'' . $value['id'] . '\' '), 'UNBUFFERED');
					if ($value['option_id'] > 0) {
						DB::query('UPDATE ' . DB::table('tom_tcdaojia_goods_option') . (' SET sale_num=sale_num - ' . $value['goods_num'] . ' WHERE id=\'' . $value['option_id'] . '\' '), 'UNBUFFERED');
					}
				} else {
					$isHaveNoPay = 1;
				}
			}
		}
	}
	$xm = $tel = '';
	$userOrderTmp = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_list(' AND user_id=' . $__UserInfo['id'] . ' AND order_status IN(2,3,4) AND type = 3', ' ORDER BY id DESC ', 0, 1);
	if (is_array($userOrderTmp) && !empty($userOrderTmp) && !empty($userOrderTmp[0]['tel'])) {
		$xm = $userOrderTmp[0]['xm'];
		$tel = $userOrderTmp[0]['tel'];
	}
	if (empty($tel)) {
		$tel = $__UserInfo['tel'];
	}
	$showMustPhoneBtn = 0;
	if ($tcdaojiaConfig['buy_must_phone'] == 1 && empty($__UserInfo['tel']) && $__UserInfo['editor'] == 0 && $__UserInfo['is_majia'] == 0) {
		$showMustPhoneBtn = 1;
		$phone_back_url = $weixinClass->get_url();
		$phone_back_url = urlencode($phone_back_url);
		$phoneUrl = 'plugin.php?id=tom_tongcheng&site=' . $site_id . '&mod=phone&phone_back=' . $phone_back_url;
	}
	$minDateTime = TIMESTAMP - 60;
	if ($goodsInfo['open_yuyue'] == 1 && $goodsInfo['yuyue_time'] > 0) {
		$minDateTime = TIMESTAMP + $goodsInfo['yuyue_time'] * 3600;
	} else {
		$minDateTime = TIMESTAMP + $tcdaojiaConfig['yuyue_time'] * 3600;
	}
	$minDateTime = dgmdate($minDateTime, 'Y-m-d H:0:0', $tomSysOffset);
	$maxDateTime = TIMESTAMP + 365 * 86400;
	$maxDateTime = dgmdate($maxDateTime, 'Y-m-d H:i:s', $tomSysOffset);
	$payUrl = 'plugin.php?id=tom_tcdaojia:pay&site=' . $site_id . '&act=pay_goods';
	$isGbk = false;
	if (CHARSET == 'gbk') {
		$isGbk = true;
	}
	include template('tom_tcdaojia:buy');
} elseif ($_GET['mod'] == 'pinglun') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/pinglun.php';
} elseif ($_GET['mod'] == 'pinglunlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/pinglunlist.php';
} elseif ($_GET['mod'] == 'report') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/report.php';
} elseif ($_GET['mod'] == 'my') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/my.php';
} elseif ($_GET['mod'] == 'order') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/order.php';
} elseif ($_GET['mod'] == 'orderinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/orderinfo.php';
} elseif ($_GET['mod'] == 'myfabu_needs') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/myfabu_needs.php';
} elseif ($_GET['mod'] == 'fabuneeds') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/fabuneeds.php';
} elseif ($_GET['mod'] == 'editneeds') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/editneeds.php';
} elseif ($_GET['mod'] == 'buyneeds') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/buyneeds.php';
} elseif ($_GET['mod'] == 'needs_jielist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/needs_jielist.php';
} elseif ($_GET['mod'] == 'collect') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/collect.php';
} elseif ($_GET['mod'] == 'myservicer') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/myservicer.php';
} elseif ($_GET['mod'] == 'myorder') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/myorder.php';
} elseif ($_GET['mod'] == 'myorderinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/myorderinfo.php';
} elseif ($_GET['mod'] == 'vip') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/vip.php';
} elseif ($_GET['mod'] == 'servicer_jielist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/servicer_jielist.php';
} elseif ($_GET['mod'] == 'myfabu_goods') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/myfabu_goods.php';
} elseif ($_GET['mod'] == 'fabugoods') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/fabugoods.php';
} elseif ($_GET['mod'] == 'editgoods') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/editgoods.php';
} elseif ($_GET['mod'] == 'editoption') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/editoption.php';
} elseif ($_GET['mod'] == 'buygoods') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/buygoods.php';
} elseif ($_GET['mod'] == 'teamlist') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/teamlist.php';
} elseif ($_GET['mod'] == 'fabu_team') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/fabu_team.php';
} elseif ($_GET['mod'] == 'edit_team') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/edit_team.php';
} elseif ($_GET['mod'] == 'buyservicer') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/buyservicer.php';
} elseif ($_GET['mod'] == 'team_order') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/team_order.php';
} elseif ($_GET['mod'] == 'team_orderinfo') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/team_orderinfo.php';
} elseif ($_GET['mod'] == 'ruzhu') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/ruzhu.php';
} elseif ($_GET['mod'] == 'edit') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/edit.php';
} elseif ($_GET['mod'] == 'managerNeedsList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/managerNeedsList.php';
} elseif ($_GET['mod'] == 'managerGoodsList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/managerGoodsList.php';
} elseif ($_GET['mod'] == 'managerList') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/managerList.php';
} elseif ($_GET['mod'] == 'orderhexiao') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/orderhexiao.php';
} elseif ($_GET['mod'] == 'buydengji') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/buydengji.php';
} elseif ($_GET['mod'] == 'edit_tuiguang') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/edit_tuiguang.php';
} elseif ($_GET['mod'] == 'baidumap') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/baidumap.php';
} elseif ($_GET['mod'] == 'upload') {
	include DISCUZ_ROOT . './source/plugin/tom_tcdaojia/module/upload.php';
} else {
	dheader('location:' . $_G['siteurl'] . ('plugin.php?id=tom_tcdaojia&site=' . $site_id . '&mod=index'));
	exit(0);
}
tomoutput();