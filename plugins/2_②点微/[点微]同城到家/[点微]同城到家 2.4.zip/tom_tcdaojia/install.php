<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_tom_tcdaojia_cate`;
CREATE TABLE `pre_tom_tcdaojia_cate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `pid` int(11) DEFAULT '0',
  `csort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_clicks`;
CREATE TABLE `pre_tom_tcdaojia_clicks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `clicks` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_collect`;
CREATE TABLE `pre_tom_tcdaojia_collect` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_diynav`;
CREATE TABLE `pre_tom_tcdaojia_diynav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `add_time` varchar(255) DEFAULT '0',
  `dsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_focuspic`;
CREATE TABLE `pre_tom_tcdaojia_focuspic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `title` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `fsort` int(11) DEFAULT '10',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_goods`;
CREATE TABLE `pre_tom_tcdaojia_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '0',
  `servicer_id` int(11) DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `cate_id` int(11) DEFAULT '0',
  `cate_child_id` int(11) DEFAULT '0',
  `open_vip` int(11) DEFAULT '0',
  `vip_price` decimal(10,2) DEFAULT '0.00',
  `open_ding_pay` int(11) DEFAULT '0',
  `ding_price` decimal(10,2) DEFAULT '0.00',
  `open_yuyue` int(11) DEFAULT '0',
  `yuyue_time` int(11) DEFAULT '0',
  `sale_num` int(11) DEFAULT '0',
  `hasoption` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `admin_edit` int(11) DEFAULT '0',
  `content` text,
  `clicks` int(11) DEFAULT '0',
  `hehuoren_tg_open` tinyint(4) DEFAULT '0',
  `hehuoren_tg_type` int(11) DEFAULT '0',
  `hehuoren_fc_scale` decimal(10,2) DEFAULT '0.00',
  `hehuoren_fc_scale2` decimal(10,2) DEFAULT '0.00',
  `haibao_type` int(11) DEFAULT '1',
  `haibao_picurl` varchar(255) DEFAULT NULL,
  `qrcode_location` int(11) DEFAULT '0',
  `haibao_msg` varchar(255) DEFAULT NULL,
  `top_status` int(11) DEFAULT '0',
  `top_time` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `servicer_rank` tinyint(4) DEFAULT '0',
  `virtual_sale_num` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `refresh_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '1000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_cate_id` (`cate_id`),
  KEY `idx_cate_child_id` (`cate_child_id`),
  KEY `idx_top_status` (`top_status`),
  KEY `idx_refresh_time` (`refresh_time`),
  KEY `idx_servicer_rank` (`servicer_rank`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_goods_option`;
CREATE TABLE `pre_tom_tcdaojia_goods_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `vip_price` decimal(10,2) DEFAULT '0.00',
  `sale_num` int(11) DEFAULT '0',
  `osort` int(11) DEFAULT '10',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_needs`;
CREATE TABLE `pre_tom_tcdaojia_needs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `wx` varchar(255) DEFAULT NULL,
  `fuwu_time` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `street_id` int(11) DEFAULT '0',
  `cate_id` int(11) DEFAULT '0',
  `cate_child_id` int(11) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `vip_id` int(11) DEFAULT '0',
  `admin_edit` int(11) DEFAULT '0',
  `content` text,
  `clicks` int(11) DEFAULT '0',
  `top_status` int(11) DEFAULT '0',
  `top_time` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `qunfa_status` int(11) DEFAULT '0',
  `finish` int(11) DEFAULT '0',
  `refresh_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '10000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_cate_id` (`cate_id`),
  KEY `idx_cate_child_id` (`cate_child_id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_top_status` (`top_status`),
  KEY `idx_finish` (`finish`),
  KEY `idx_refresh_time` (`refresh_time`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_needs_jie`;
CREATE TABLE `pre_tom_tcdaojia_needs_jie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `needs_id` int(11) DEFAULT '0',
  `servicer_id` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT '0.00',
  `beizu` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `refresh_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_order`;
CREATE TABLE `pre_tom_tcdaojia_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '1',
  `tj_hehuoren_id` int(11) DEFAULT '0',
  `order_no` varchar(255) DEFAULT NULL,
  `sub_order_no` varchar(255) DEFAULT NULL,
  `hexiao_no` varchar(255) DEFAULT NULL,
  `goods_id` int(11) DEFAULT '0',
  `needs_id` int(11) DEFAULT '0',
  `servicer_id` int(11) DEFAULT '0',
  `option_id` int(11) DEFAULT '0',
  `option_name` varchar(255) DEFAULT NULL,
  `dengji_id` int(11) DEFAULT '0',
  `goods_num` int(11) DEFAULT '0',
  `one_price` decimal(10,2) DEFAULT '0.00',
  `type` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `pay_price` decimal(10,2) DEFAULT '0.00',
  `wei_price` decimal(10,2) DEFAULT '0.00',
  `vip_pay_status` int(11) DEFAULT '0',
  `address_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `order_time` int(11) DEFAULT '0',
  `pay_time` int(11) DEFAULT '0',
  `fuwu_time` int(11) DEFAULT '0',
  `order_status` int(11) DEFAULT '0',
  `team_id` int(11) DEFAULT '0',
  `team_status` int(11) DEFAULT '0',
  `pay_ding_status` int(11) DEFAULT '0',
  `is_weikuan` int(11) DEFAULT '0',
  `pinglun_status` int(11) DEFAULT '0',
  `balance_status` int(11) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_time` int(11) DEFAULT '0',
  `refund_type` int(11) DEFAULT '0',
  `shenqing_refund` int(11) DEFAULT '0',
  `shenqing_refund_msg` varchar(255) DEFAULT NULL,
  `top_days` int(11) DEFAULT '0',
  `top_price` decimal(10,2) DEFAULT '0.00',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  `order_beizu` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_no` (`order_no`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_photo`;
CREATE TABLE `pre_tom_tcdaojia_photo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `servicer_id` int(11) NOT NULL DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `needs_id` int(11) DEFAULT '0',
  `hexiao_log_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `oss_picurl` varchar(255) DEFAULT NULL,
  `oss_status` int(11) DEFAULT '0',
  `qinniu_status` int(11) DEFAULT '0',
  `qiniu_picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_pinglun`;
CREATE TABLE `pre_tom_tcdaojia_pinglun` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT NULL,
  `servicer_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `grade` tinyint(4) DEFAULT '0',
  `content` text,
  `pinglun_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_pinglun_photo`;
CREATE TABLE `pre_tom_tcdaojia_pinglun_photo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pinglun_id` int(11) DEFAULT '0',
  `picurl` varchar(255) DEFAULT NULL,
  `add_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_pinglun_reply`;
CREATE TABLE `pre_tom_tcdaojia_pinglun_reply` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pinglun_id` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `reply_user_id` int(11) DEFAULT '0',
  `reply_user_nickname` varchar(255) DEFAULT NULL,
  `reply_user_avatar` varchar(255) DEFAULT NULL,
  `content` text,
  `reply_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_qunfa_log`;
CREATE TABLE `pre_tom_tcdaojia_qunfa_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `needs_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `openid` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_report`;
CREATE TABLE `pre_tom_tcdaojia_report` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `report_user_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `goods_id` int(11) DEFAULT '0',
  `needs_id` int(11) DEFAULT '0',
  `report_content` varchar(255) DEFAULT NULL,
  `report_pic_1` varchar(255) DEFAULT NULL,
  `report_pic_2` varchar(255) DEFAULT NULL,
  `report_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_servicer`;
CREATE TABLE `pre_tom_tcdaojia_servicer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `type` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `start_time` varchar(255) DEFAULT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `cate_ids` varchar(255) DEFAULT NULL,
  `area_ids` varchar(255) DEFAULT NULL,
  `street_ids` varchar(255) DEFAULT NULL,
  `vip_id` int(11) DEFAULT '0',
  `dengji_id` int(11) DEFAULT '0',
  `dengji_time` int(11) DEFAULT '0',
  `dengji_status` int(11) DEFAULT '0',
  `clicks` int(11) DEFAULT '0',
  `virtual_clicks` int(11) DEFAULT '0',
  `jie_num` int(11) DEFAULT '0',
  `grade` decimal(10,1) DEFAULT '0.0',
  `rank` tinyint(4) DEFAULT '0',
  `address` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `admin_edit` int(11) DEFAULT '0',
  `content` text,
  `jie_status` int(11) DEFAULT '1',
  `pay_status` int(11) DEFAULT '0',
  `top_status` int(11) DEFAULT '0',
  `top_time` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `shenhe_status` int(11) DEFAULT '0',
  `refresh_time` int(11) DEFAULT '0',
  `add_time` int(11) DEFAULT '0',
  `paixu` int(11) DEFAULT '10000',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_site_id` (`site_id`),
  KEY `idx_status` (`status`),
  KEY `idx_shenhe_status` (`shenhe_status`),
  KEY `idx_top_status` (`top_status`),
  KEY `idx_rank` (`rank`),
  KEY `idx_refresh_time` (`refresh_time`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_team`;
CREATE TABLE `pre_tom_tcdaojia_team` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `servicer_id` int(11) DEFAULT '0',
  `xm` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `is_hidden` int(11) DEFAULT '0',
  `tsort` int(11) DEFAULT '100',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_vip`;
CREATE TABLE `pre_tom_tcdaojia_vip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `up_jie_num` int(11) DEFAULT '0',
  `up_grade` decimal(10,1) DEFAULT '0.0',
  `yongjin_bili` int(11) DEFAULT '0',
  `rank` tinyint(4) DEFAULT '0',
  `vsort` int(11) DEFAULT '100',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_tom_tcdaojia_common`;
CREATE TABLE `pre_tom_tcdaojia_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `servicer_xieyi` mediumtext,
  `needs_xieyi` mediumtext,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
       
DROP TABLE IF EXISTS `pre_tom_tcdaojia_dengji`;
CREATE TABLE `pre_tom_tcdaojia_dengji` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `days` int(11) DEFAULT '0',
  `days_msg` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `fabu_goods_num` int(11) DEFAULT '0',
  `xiangou_num` int(11) DEFAULT '0',
  `status` tinyint(4) unsigned DEFAULT '0',
  `dsort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
  
DROP TABLE IF EXISTS `pre_tom_tcdaojia_dengji_code`;
CREATE TABLE `pre_tom_tcdaojia_dengji_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dengji_id` int(11) DEFAULT '0',
  `code` varchar(255) DEFAULT NULL,
  `use_status` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `servicer_id` int(11) DEFAULT '0',
  `use_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
DROP TABLE IF EXISTS `pre_tom_tcdaojia_dengji_log`;
CREATE TABLE `pre_tom_tcdaojia_dengji_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `servicer_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `dengji_id` int(11) DEFAULT '0',
  `dengji_code_id` int(11) DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
   
DROP TABLE IF EXISTS `pre_tom_tcdaojia_order_hexiao_log`;
CREATE TABLE `pre_tom_tcdaojia_order_hexiao_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `hexiao_num` int(11) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_beizu` text,
  `hexiao_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$finish = TRUE;