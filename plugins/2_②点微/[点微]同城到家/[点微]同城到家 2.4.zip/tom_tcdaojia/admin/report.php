<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=report';
$modListUrl = $adminListUrl.'&tmod=report';
$modFromUrl = $adminFromUrl.'&tmod=report';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

$pagesize = 100;
$page = intval($_GET['page'])>0? intval($_GET['page']):1;
$start = ($page-1)*$pagesize;	
$count = C::t('#tom_tcdaojia#tom_tcdaojia_report')->fetch_all_count("");
$reportList = C::t('#tom_tcdaojia#tom_tcdaojia_report')->fetch_all_list("","ORDER BY id DESC",$start,$pagesize);
showtableheader(); /*DisM.Taobao.Com*/
echo '<tr><th colspan="15" class="partition">' . $Lang['report_list'] . '</th></tr>';
echo '<tr class="header">';
echo '<th>ID</th>';
echo '<th>' . $Lang['re_user_id'] . '</th>';
echo '<th>' . $Lang['report_user_id'] . '</th>';
echo '<th>' . $Lang['report_content'] . '</th>';
echo '<th>' . $Lang['report_type'] . '</th>';
echo '<th>' . $Lang['report_pic'] . '</th>';
echo '<th>' . $Lang['report_time'] . '</th>';
echo '</tr>';
foreach ($reportList as $key => $value){
    if($value['goods_id'] > 0){
        $goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($value['goods_id']);
    }
    if($value['needs_id'] > 0){
        $needsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($value['needs_id']);
    }
    if($value['servicer_id'] > 0){
        $servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($value['servicer_id']);
    }
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
    $reportUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['report_user_id']);
    
    if(!empty($value['report_pic_1'])){
        if(!preg_match('/^http/', $value['report_pic_1'])){
            if(strpos($value['report_pic_1'], 'source/plugin/tom_') === false){
                $report_pic_1 = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['report_pic_1'];
            }else{
                $report_pic_1 = $value['report_pic_1'];
            }
        }else{
            $report_pic_1 = $value['report_pic_1'];
        }
        $report_pic_1 = '<a target="_blank" href="'.$report_pic_1.'"><img src="'.$report_pic_1.'" width="40" height="40"></a>';
    }else{
        $report_pic_1 = '';
    }

    if(!empty($value['report_pic_2'])){
        if(!preg_match('/^http/', $value['report_pic_2'])){
            if(strpos($value['report_pic_2'], 'source/plugin/tom_') === false){
                $report_pic_2 = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['report_pic_2'];
            }else{
                $report_pic_2 = $value['report_pic_2'];
            }
        }else{
            $report_pic_2 = $value['report_pic_2'];
        }
        $report_pic_2 = '<a target="_blank" href="'.$report_pic_2.'"><img src="'.$report_pic_2.'" width="40" height="40"></a>';
    }else{
        $report_pic_2 = '';
    }

    echo '<tr>';
    echo '<td>' . $value['id'] . '</td>';
    echo '<td>' . $userInfo['nickname'] . '<font color="#f00">(UID:'.$userInfo['id'].')</font>'.'</td>';
    echo '<td>' . $reportUserInfo['nickname'] . '<font color="#f00">(UID:'.$reportUserInfo['id'].')</font>'.'</td>';
    echo '<td>' . $value['report_content'] . '</td>';
    if($value['type'] == 1){
        echo '<td>' . $Lang['report_type_1'] . '(<a target="_blank" href="'.$adminBaseUrl.'&tmod=goods&goods_id='.$value['goods_id'].'&formhash='.FORMHASH.'">' . $goodsInfo['title'] . ')</a></td>';
    }elseif($value['type'] == 2){
         echo '<td>' . $Lang['report_type_2'] . '(<a target="_blank" href="'.$adminBaseUrl.'&tmod=needs&needs_id='.$value['needs_id'].'&formhash='.FORMHASH.'">' . $needsInfo['content'] . ')</a></td>';
    }elseif($value['type'] == 3){
         echo '<td>' . $Lang['report_type_3'] . '(<a target="_blank" href="'.$adminBaseUrl.'&tmod=index&servicer_id='.$value['servicer_id'].'&formhash='.FORMHASH.'">' . $servicerInfo['name'] . ')</a></td>';
    }
    echo '<td>' . $report_pic_1 .'-'. $report_pic_2 . '</td>';
    echo '<td>' . dgmdate($value['report_time'], 'Y-m-d H:i:s',$tomSysOffset) . '</td>';
    echo '</tr>';
}
showtablefooter(); /*dism _taobao _com*/
$multi = multi($count, $pagesize, $page, $modBaseUrl);	
showsubmit('', '', '', '', $multi, false);