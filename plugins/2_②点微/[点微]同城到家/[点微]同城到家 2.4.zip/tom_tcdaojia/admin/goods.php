<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=goods';
$modListUrl = $adminListUrl.'&tmod=goods';
$modFromUrl = $adminFromUrl.'&tmod=goods';

$get_list_url_value = get_list_url("tom_tcdaojia_admin_goods_list");

if($_GET['act'] == 'pinglun_list'){

    $page          = intval($_GET['page'])>0? intval($_GET['page']):1;
    $goods_id      = $_GET['goods_id'];
    $goodsInfo     = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($_GET['goods_id']);
    
    $modBasePageUrl = $modBaseUrl."&act=pinglun_list&goods_id={$goods_id}";
    
    $pagesize = 20;
    $start = ($page - 1) * $pagesize;
    $count = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun')->fetch_all_count(" AND goods_id={$goods_id} ");
    $pinglunList = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun')->fetch_all_list(" AND goods_id={$goods_id} ","ORDER BY id ASC", $start, $pagesize);

    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr><th colspan="15" class="partition">'.$goodsInfo['title'] ."&nbsp;&nbsp;--&gt;&gt;&nbsp;&nbsp;" . $Lang['pinglun_list'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['pinglun_user_id'] . '</th>';
    echo '<th>' . $Lang['pinglun_grade'] . '</th>';
    echo '<th width="240px">' . $Lang['pinglun_content'] . '</th>';
    echo '<th>' . $Lang['pinglun_photo'] . '</th>';
    echo '<th>' . $Lang['pinglun_time'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($pinglunList as $key => $value) {
        $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $replyList = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun_reply')->fetch_all_list(" AND pinglun_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);
        $pinglunPhotoListTmpTmp = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun_photo')->fetch_all_list(" AND pinglun_id = {$value['id']} ", 'ORDER BY id DESC', 0, 100);
        $pinglunPhotoListTmp = array();
        if(is_array($pinglunPhotoListTmpTmp) && !empty($pinglunPhotoListTmpTmp)){
            foreach($pinglunPhotoListTmpTmp as $pk => $pv){
                if(!preg_match('/^http/', $pv['picurl']) ){
                    if(strpos($pv['picurl'], 'source/plugin/tom_') === FALSE){
                        $pinglunPhotoListTmp[] = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$pv['picurl'];
                    }else{
                        $pinglunPhotoListTmp[] = $pv['picurl'];
                    }
                }else{
                    $pinglunPhotoListTmp[] = $pv['picurl'];
                }

            }
        }
        
        echo '<tr>';
        echo '<td>' .$userInfo['nickname'].'('.$value['user_id']. ')</td>';
        echo '<td><font color="#009900">' .$value['grade'].$Lang['score_unit'].'('.$pinglunStatusArray[$value['grade']].')</font></td>';
        echo '<td>' .$value['content'].'</td>';
        echo '<td>';
        if(is_array($pinglunPhotoListTmp) && !empty($pinglunPhotoListTmp)){
            foreach ($pinglunPhotoListTmp as $k3 => $v3){
                echo '<a href="'.$v3.'" target="_blank"><img src="'.$v3.'" width="40" height="40" />&nbsp;</a>';
            }
        }
        echo '</td>';
        echo '<td>' .dgmdate($value['pinglun_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delpinglun&id='.$value['id'].'&goods_id='.$goods_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        foreach($replyList as $rk => $rv){
            echo '<tr>';
            echo '<td style="text-align:right;"> --&gt;&gt;&nbsp;&nbsp; </td>';
            echo '<td colspan="2">'.$rv['reply_user_nickname'].' '.$Lang['pinglun_kefu_reply'].$rv['content'].'</td>';
            echo '<td> &nbsp; </td>';
            echo '<td>' .dgmdate($rv['reply_time'], 'Y-m-d H:i:s',$tomSysOffset).'</td>';
            echo '<td>';
            echo '<a href="'.$modBaseUrl.'&act=delpinglun_reply&id='.$rv['id'].'&goods_id='.$goods_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
            echo '</td>';
            echo '</tr>';
        }
    }
    showtablefooter(); /*dism _taobao _com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delpinglun'){
    
    $pinglunInfo = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun')->fetch_by_id($_GET['id']);
    $servicer_id = $pinglunInfo['servicer_id'];
    
    C::t('#tom_tcdaojia#tom_tcdaojia_pinglun')->delete($_GET['id']);
    C::t('#tom_tcdaojia#tom_tcdaojia_pinglun_photo')->delete_by_pinglun_id($_GET['id']);
    C::t('#tom_tcdaojia#tom_tcdaojia_pinglun_reply')->delete_by_pinglun_id($_GET['id']);
  
    $pinglunCount = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun')->fetch_all_count("AND servicer_id = {$servicer_id} ");
    if($pinglunCount > 0){
        $allgrade     = C::t('#tom_tcdaojia#tom_tcdaojia_pinglun')->fetch_all_sun_grade("AND servicer_id = {$servicer_id}");
        $grade = $allgrade/$pinglunCount;
        $grade = round($grade, 1);
        DB::query("UPDATE ".DB::table('tom_tcdaojia_servicer')." SET grade={$grade} WHERE id = {$servicer_id} ", 'UNBUFFERED');
        update_vip_id($servicer_id);
    }
    
    cpmsg($Lang['act_success'], $adminListUrl.'&tmod=goods'."&act=pinglun_list&goods_id=".$_GET['goods_id'], 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delpinglun_reply'){

    C::t('#tom_tcdaojia#tom_tcdaojia_pinglun_reply')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $adminListUrl.'&tmod=goods'."&act=pinglun_list&goods_id=".$_GET['goods_id'], 'succeed');
    
}else if($_GET['act'] == 'photo'){
    
    $goods_id  = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    
    if(submitcheck('submit')){
        
        if($_FILES["picurl"]['tmp_name']) {
            $upload = new tom_upload();
            if(!$upload->init($_FILES["picurl"], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }
            $picurl = $upload->attach['attachment'];
        }else{
            $picurl = addslashes($_GET["picurl"]);
        }
        
        $insertData = array();
        $insertData['goods_id']           = $goods_id;
        $insertData['type']               = 2;
        $insertData['picurl']             = $picurl;
        $insertData['add_time']           = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_photo')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl."&act=photo&goods_id=".$_GET['goods_id'], 'succeed');
    }
    
    $photoList = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND goods_id={$goods_id} AND type = 2","ORDER BY id ASC",0,100);
    
    __create_nav_html();
    showformheader($modFromUrl.'&act=photo&goods_id='.$goods_id,'enctype');
    showtableheader(); /*DisM.Taobao.Com*/
    tomshowsetting(true,array('title'=>$Lang['index_photo_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['index_photo_picurl_msg']),"file");
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism _taobao _com*/
    showformfooter(); /*dism��taobao��com*/
    
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['index_photo_picurl'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($photoList as $key => $value) {
        echo '<tr>';
        echo '<td><img src="' . tomgetfileurl($value['picurl']) . '" width="60" /></td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&goods_id='.$goods_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter(); /*dism _taobao _com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tcdaojia#tom_tcdaojia_photo')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl."&act=photo&goods_id=".$_GET['goods_id'], 'succeed');
    
}else if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $data = __get_post_data();
        if(empty($data['servicerInfo'])){
            cpmsg($Lang['goods_servicer_error'], $modListUrl, 'error');exit;
        }
        $insertData                    = $data['goodsInfo'];
        $insertData['status']          = 2;
        $insertData['shenhe_status']   = 1;
        $insertData['add_time']        = TIMESTAMP;
        $insertData['refresh_time']    = TIMESTAMP;
        if(C::t('#tom_tcdaojia#tom_tcdaojia_goods')->insert($insertData)){
            $goods_id = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->insert_id();
        }
        if(!empty($data['picurl'])){
            $insertData = array();
            $insertData['goods_id']         = $goods_id;
            $insertData['type']             = 1;
            $insertData['picurl']           = $data['picurl'];
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcdaojia#tom_tcdaojia_photo")->insert($insertData);
        }
        
        cpmsg($Lang['act_success'], $modListUrl.'&act=edit&id='.$goods_id, 'succeed');
        
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add&id='.$_GET['id'],'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html($goodsInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $data = __get_post_data($goodsInfo);
        if(empty($data['servicerInfo'])){
            cpmsg($Lang['goods_servicer_error'], $modListUrl, 'error');exit;
        }

        $updateData = $data['goodsInfo'];
        $updateData['add_time']     = TIMESTAMP;
        $updateData['refresh_time'] = TIMESTAMP;
      
        C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($goodsInfo['id'],$updateData);
        
         if($goodsInfo['id'] > 0){
            C::t('#tom_tcdaojia#tom_tcdaojia_photo')->delete_all_list(" AND goods_id={$goodsInfo['id']} AND type IN(1) ");
        }
        
        $goodsInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($goodsInfo['id']);
        
        if(!empty($data['picurl'])){
            $insertData = array();
            $insertData['goods_id']         = $goodsInfo['id'];
            $insertData['type']             = 1;
            $insertData['picurl']           = $data['picurl'];
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcdaojia#tom_tcdaojia_photo")->insert($insertData);
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html($goodsInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_ok'){

    $updateData = array();
    $updateData['shenhe_status'] = 1;
    $updateData['status']        = 1;
    C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($_GET['id'],$updateData);
        
    $goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($_GET['id']);
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']);

    $shenhe = str_replace('{TITLE}', $goodsInfo['title'], $Lang['template_tcdaojia_goods_shenhe_ok']);
    $cpmsg = $Lang['tcdaojia_shenhe_tz_succ'];
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$goodsInfo['site_id']}&mod=goodsinfo&goods_id=".$goodsInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $tcdaojiaConfig['plugin_name'],
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
        }else{
            $cpmsg = $Lang['tcdaojia_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcdaojiaConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenhe_no'){
    
    $goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']);
        
        $updateData = array();
        $updateData['shenhe_status']     = 3;
        C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($_GET['id'],$updateData);
                
        $shenhe = str_replace('{TITLE}', $goodsInfo['title'], $Lang['template_tcdaojia_goods_shenhe_no']);
        $cpmsg = $Lang['tcdaojia_shenhe_tz_succ'];
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$goodsInfo['site_id']}&mod=editgoods&goods_id=".$goodsInfo['id']);
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $tcdaojiaConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
            }else{
                $cpmsg = $Lang['tcdaojia_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcdaojiaConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tcdaojia_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenhe_no&id='.$_GET['id'],'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        tomshowsetting(true,array('title'=>$Lang['tcdaojia_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcdaojia_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    $updateData = array();
    $updateData['status']     = 1;
    C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($_GET['id'],$updateData);
        
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    $updateData = array();
    $updateData['status']     = 0;
    C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $goods_id  = isset($_GET['id'])? intval($_GET['id']):0;
    
    C::t('#tom_tcdaojia#tom_tcdaojia_goods')->delete_by_id($_GET['id']);
    C::t('#tom_tcdaojia#tom_tcdaojia_photo')->delete_by_goods_id($_GET['id']);
    C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->delete_by_goods_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'refresh'){
    
    $updateData = array();
    $updateData['refresh_time'] = TIMESTAMP;
    C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($_GET['id'],$updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'edittop'){
    $info = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $top_time     = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
        $top_time     = strtotime($top_time);
        $updateData = array();
        if($top_time < TIMESTAMP){
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
        }else{
            $updateData['top_status']   = 1;
            $updateData['refresh_time'] = TIMESTAMP;
            $updateData['top_time']     = $top_time;
        }
        C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($_GET['id'],$updateData);
            
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edittop&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader(); /*DisM.Taobao.Com*/
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_top_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_top_time'],'name'=>'top_time','value'=>$info['top_time'],'msg'=>$Lang['edit_top_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_refresh'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['refresh_time']     = TIMESTAMP;
            C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($value,$updateData);
            
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_shenhe1'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
        
            $updateData = array();
            $updateData['shenhe_status']    = 1;
            $updateData['status']           = 1;
            C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($value,$updateData);
            
            $goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($value);
            $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']);

            $shenhe = str_replace('{TITLE}', $goodsInfo['title'], $Lang['template_tcdaojia_goods_shenhe_ok']);
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcdaojia&site='.$goodsInfo['site_id'].'&mod=goodsinfo&goods_id='.$goodsInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($tcUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$goodsInfo['site_id']}&mod=goodsinfo&goods_id=".$goodsInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcdaojiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }

            $insertData = array();
            $insertData['user_id']      = $tcUserInfo['id'];
            $insertData['type']         = 1;
            $insertData['content']      = '<font color="#238206">'.$tcdaojiaConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
            $insertData['is_read']      = 0;
            $insertData['tz_time']      = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
            
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_shenhe3'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            
            $goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($value);
            $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($goodsInfo['user_id']);

            $updateData = array();
            $updateData['shenhe_status']    = 3;
            C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($value,$updateData);

            $shenhe = str_replace('{TITLE}', $goodsInfo['title'], $Lang['template_tcdaojia_goods_shenhe_no']);
            $tzShenhe = $shenhe.'<br/><a href="plugin.php?id=tom_tcdaojia&site='.$goodsInfo['site_id'].'&mod=edit&goods_id='.$goodsInfo['id'].'">['.lang("plugin/tom_tongcheng", "template_dianjichakan").']</a>';

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($tcUserInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$goodsInfo['site_id']}&mod=edit&goods_id=".$goodsInfo['id']);
                $smsData = array(
                    'first'         => $shenhe,
                    'keyword1'      => $tcdaojiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );
                @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                if($r){
                    $cpmsg = $Lang['tcdaojia_shenhe_tz_succ'];
                }else{
                    $cpmsg = $Lang['tcdaojia_shenhe_tz_fail'];
                }
            }

            $insertData = array();
            $insertData['user_id']      = $tcUserInfo['id'];
            $insertData['type']         = 1;
            $insertData['content']      = '<font color="#238206">'.$tcdaojiaConfig['plugin_name'].'</font><br/>'.$tzShenhe.'<br/>'.$Lang['tcdaojia_shenhe_fail_title'].'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
            $insertData['is_read']      = 0;
            $insertData['tz_time']      = TIMESTAMP;
            C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);

        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_del'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            C::t('#tom_tcdaojia#tom_tcdaojia_goods')->delete_by_id($value);
            C::t('#tom_tcdaojia#tom_tcdaojia_photo')->delete_by_goods_id($value);
            C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->delete_by_goods_id($value);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_show'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['status'] = 1;
            C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($value,$updateData);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'batch_hide'){
    
    if(is_array($_GET['ids']) && !empty($_GET['ids'])){
        foreach ($_GET['ids'] as $key => $value){
            $updateData = array();
            $updateData['status'] = 0;
            C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($value,$updateData);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{  
 
    set_list_url("tom_tcdaojia_admin_goods_list");
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ width: 100px;float: left;list-style-type: none;height: 32px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;color: #6a6d6a;width: 90px;height: 25px;line-height: 25px;display: block;text-align: center; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
</style>
EOF;
    echo $csstr;
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $goods_id           = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $status             = isset($_GET['status'])? intval($_GET['status']):0;
    $shenhe_status      = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $top_status         = isset($_GET['top_status'])? intval($_GET['top_status']):0;
    $search             = isset($_GET['search'])? intval($_GET['search']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = "";
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    if(!empty($goods_id)){
        $where.= " AND id={$goods_id} ";
    }
    if($cate_id > 0){
        $where.= " AND cate_id = {$cate_id} ";
    }
    if($cate_child_id > 0){
        $where.= " AND cate_child_id = {$cate_child_id} ";
    }
    if($status == 1){
        $where.= " AND status=1 ";
    }else if($status == 2){
        $where.= " AND status=0 ";
    }
    if(!empty($shenhe_status)){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    if($top_status > 0){
        if($top_status == 1){
            $where.= " AND top_status = 1 ";
        }else if($top_status == 2){
            $where.= " AND top_status = 0 ";
        }
    }
    
    $pagesize = 15;
    $start = ($page-1)*$pagesize;
    $count = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_count($where);
    $goodsList = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_list($where," ORDER BY id DESC ",$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&user_id={$user_id}&status={$status}&shenhe_status={$shenhe_status}&top_status={$top_status}&search={$search}&cate_id={$cate_id}&cate_child_id={$cate_child_id}";
    
    showformheader($modFromUrl."&search={$search}&formhash=".FORMHASH);
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '<a href="'.$modBaseUrl.'&search=1"><font color="#F90B0B">('.$Lang['search_gaoji'].')</font></a></th></tr>';
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,10000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    echo '<tr><td width="100" align="right"><b>'.$Lang['goods_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="goods_id" value="'.$goods_id.'"></td></tr>';
    
    $cateList = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,100);
    $cate_list_item = array();
    if(is_array($cateList) && !empty($cateList)){
        foreach ($cateList as $key => $value){
            $cate_list_item[$value['id']] = $value['name'];
        }
    }
    echo '<tr><td width="100" align="right"><b>' . $Lang['goods_cate_id'] . '</b></td><td><select name="cate_id" id="cate_id" onchange="getChildCates();" >';
    echo '<option value="0">'.$Lang['goods_cate_id'].'</option>';
    foreach ($cate_list_item as $key => $value){
        if($key == $cate_id){
            echo '<option value="'.$key.'" selected>'.$value.'</option>';
        }else{
            echo '<option value="'.$key.'">'.$value.'</option>';
        }
    }
    echo '</select>&nbsp;&nbsp;<select name="cate_child_id" id="cate_child_id">';
    echo '<option value="0">'.$Lang['goods_cate_child_id'].'</option>';
    if($cate_id > 0){
        $childCateList = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid={$cate_id} "," ORDER BY csort ASC,id DESC ",0,50);
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $key => $value) {
                if($value['id'] == $cate_child_id){
                    echo  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
                }else{
                    echo  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                }
            }
        }
    }
    echo '</select></td></tr>';
    
    echo '<tr><td width="100" align="right"><b>'.$Lang['goods_title'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="title" value="'.$title.'"></td></tr>';
    if($search == 1){
        echo '<tr><td width="100" align="right"><b>'.$Lang['user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';

        $__CityInfo  = array('id'=>0,'name'=>'');
        if($site_id > 1){
            $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($site_id);
            if($sitesInfoTmp){
                $__SitesInfo = $sitesInfoTmp;
                if(!empty($__SitesInfo['city_id'])){
                    $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                    if($cityInfoTmp){
                        $__CityInfo = $cityInfoTmp;
                    }
                }
            }
        }else if($site_id == 1){
            $cityInfoTmp = array();
            if(!empty($tongchengConfig['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
            }
            if(!empty($cityInfoTmp)){
                $__CityInfo = $cityInfoTmp;
            }
        }
    }
    
    $statusStr = '<tr><td width="100" align="right"><b>' . $Lang['goods_status'] . '</b></td><td><select style="width:260px;" name="status" >';
    $statusStr.= '<option value="0">'.$Lang['goods_status'].'</option>';
    $status1_selected = $status2_selected = "";
    if(1 == $status){
        $status1_selected = "selected";
    }
    if(2 == $status){
        $status2_selected = "selected";
    }
    $statusStr.= '<option value="1" '.$status1_selected.'>'.$Lang['goods_status_1'].'</option>';
    $statusStr.= '<option value="2" '.$status2_selected.'>'.$Lang['goods_status_2'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    $shenhe_status_1 = $shenhe_status_2 = $shenhe_status_3 = '';
    if($shenhe_status == 1){
        $shenhe_status_1 = 'selected';
    }else if($shenhe_status == 2){
        $shenhe_status_2 = 'selected';
    }else if($shenhe_status == 3){
        $shenhe_status_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['goods_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$shenhe_status_1.'>'.$Lang['goods_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$shenhe_status_2.'>'.$Lang['goods_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$shenhe_status_3.'>'.$Lang['goods_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    
    $top_status_1 = $top_status_0 = '';
    if($top_status == 1){
        $top_status_1 = 'selected';
    }else if($top_status == 2){
        $top_status_0 = 'selected';
    }
    $topStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['top_status'].'</b></td>';
    $topStatusStr.= '<td><select style="width: 260px;" name="top_status" id="top_status">';
    $topStatusStr.=  '<option value="0">'.$Lang['select_all'].'</option>';
    $topStatusStr.=  '<option value="1" '.$top_status_1.'>'.$Lang['top_status_1'].'</option>';
    $topStatusStr.=  '<option value="2" '.$top_status_0.'>'.$Lang['top_status_0'].'</option>';
    $topStatusStr.= '</select></td></tr>';
    echo $topStatusStr;
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism _taobao _com*/
    showformfooter(); /*dism��taobao��com*/
    
    __create_nav_html();
    echo '<form name="cpform2" id="cpform2" method="post" autocomplete="off" action="'.ADMINSCRIPT.'?action='.$modFromUrl.'&formhash='.FORMHASH.'" onsubmit="return batch_do();">'.
        '<input type="hidden" name="formhash" value="'.FORMHASH.'" />';
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr class="header">';
    echo '<th style="width: 60px;">' . $Lang['goods_id'] . '</th>';
    echo '<th style="width: 60px;">' . $Lang['sites_title'] . '</th>';
    echo '<th>' .$Lang['goods_picurl'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['goods_info'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['goods_user_info'] . '</th>';
    echo '<th>' . $Lang['goods_sale_num'] . '</th>';
    echo '<th>' . $Lang['goods_status2'] . '</th>';
    echo '<th>' . $Lang['refresh_time'] . '</th>';
    echo '<th>' . $Lang['add_time'] . '</th>';
    echo '<th style="width: 200px;">' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($goodsList as $key => $value) {
        
        $cateInfo           = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($value['cate_id']);
        $cateChildInfo      = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($value['cate_child_id']);
        $userInfoTmp        = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $servicerInfoTmp    = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($value['servicer_id']);
        $goodsphotoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list("AND goods_id = {$value['id']} AND type = 1","",0,1);
        if(is_array($goodsphotoInfoTmp) && !empty($goodsphotoInfoTmp[0])){
            $picurl = $goodsphotoInfoTmp[0]['picurlTmp'];
        }
        
        echo '<tr>';
        echo '<td><label><input class="checkbox" type="checkbox" name="ids[]" value="' . $value['id'] . '" >' . $value['id'] . '</label></td>';
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td><img src="'.$picurl.'" width="40" /></td>';
        echo '<td><div class="tc_content_box" style="width:200px;"><ul>';
        echo '<li><b>'.$Lang['goods_title'].'&nbsp;:&nbsp;</b>' .$value['title'] . '</li>';
        echo '<li><b>'.$Lang['goods_price'].'&nbsp;:&nbsp;</b>' .$value['price'] . '</li>';
        if($value['open_ding_pay'] == 1){
            echo '<li><b>'.$Lang['goods_ding_price'].'&nbsp;:&nbsp;</b>' . $value['ding_price'] . '</li>';
        }
        echo '</ul></div></td>';
        echo '<td><div class="tc_content_box" style="width:200px;"><ul>';
        echo '<li>'.$Lang['goods_fabu_user_id'].'&nbsp;:&nbsp;<font color="#0a9409">' . $userInfoTmp['nickname'] . '</font><font color="#f70404">(UID:'.$value['user_id'].')</font></li>';
        echo '<li>'.$Lang['goods_daojia_name'].'&nbsp;:&nbsp;<font color="#0a9409">' . $servicerInfoTmp['name'] . '</font><font color="#f70404">(ID:'.$value['servicer_id'].')</font></li>';
        echo '</ul></div></td>';
        echo '<td><font color="#238206">' . $value['sale_num'] . '</font></td>';
        echo '<td><div class="tc_content_box"><ul>';
        if($value['top_status'] == 1){
            echo '<p style="line-height:20px;">' . $Lang['top_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['top_status_1'].'</font> <font color="#f70404">('.dgmdate($value['top_time'], 'Y-m-d H:i',$tomSysOffset).')</font></p>';
        }else{
            echo '<p style="line-height:20px;">' . $Lang['top_status'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['top_status_0'].'</font></p>';
        }
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_ok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_shenhe_btn_1']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenhe_no&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_shenhe_btn_3']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<p style="line-height:20px;">' . $Lang['goods_shenhe_status'].$Lang['fenghao']. '<font color="#0a9409">' . $Lang['goods_shenhe_btn_1']. '</font>'.$sheheBtnStr.'</p>';
        }else if($value['shenhe_status'] == 2 ){
            echo '<p style="line-height:20px;">' . $Lang['goods_shenhe_status'].$Lang['fenghao']. '<font color="#f70404">' . $Lang['goods_shenhe_btn_2']. '</font>'.$sheheBtnStr.'</p>';
        }else if($value['shenhe_status'] == 3 ){
            echo '<p style="line-height:20px;">' . $Lang['goods_shenhe_status'].$Lang['fenghao']. '<font color="#f70404">' . $Lang['goods_shenhe_btn_3']. '</font>'.$sheheBtnStr.'</p>';
        }
        if($value['status'] == 1 ){
            echo '<p style="line-height:20px;">' . $Lang['goods_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['goods_status_1'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['goods_status_2']. ')</font></a></p>';
        }else{
            echo '<p style="line-height:20px;">' . $Lang['goods_status'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['goods_status_2'].'</font>&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'"><font color="#2366A8">(' . $Lang['goods_status_1']. ')</font></a></p>';
        }
        echo '</ul></div></td>';
        echo '<td>' . dgmdate($value['refresh_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i:s",$tomSysOffset) . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['goods_edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=photo&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_photo']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=refresh&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['refresh']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=edittop&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_top_title']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=pinglun_list&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['pinglun_list']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        if($value['hasoption'] == 1){
            echo '<a href="'.$adminBaseUrl.'&tmod=option&goods_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_option_title']. '</a><br/>';
        }
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism _taobao _com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function pay_confirm(url){
  var r = confirm("{$Lang['makesure_pay_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function getChildCates(){
  var cate_id = jq("#cate_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcdaojia:ajax",
        data: "act=childcates&pid="+cate_id,
        dataType : "json",
        success: function(json){
            var cateChildHtml = '<option value="0">{$Lang['goods_cate_child_id']}</option>';
            jq.each(json,function(k,v){
                cateChildHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#cate_child_id").html(cateChildHtml);
            jq("#cate_child_id").show();
        }
    });
}
            
</script>
EOF;
    echo $jsstr;
    
    $formstr = <<<EOF
        <tr>
            <td class="td25">
                <input type="checkbox" name="chkall" id="chkallFh9R" class="checkbox" onclick="checkAll('prefix', this.form, 'ids')" />
                <label for="chkallFh9R">{$Lang['checkall']}</label>
            </td>
            <td class="td25">
                <select name="act" >
                    <option value="batch_refresh">{$Lang['batch_refresh']}</option>
                    <option value="batch_shenhe1">{$Lang['batch_shenhe1']}</option>
                    <option value="batch_shenhe3">{$Lang['batch_shenhe3']}</option>
                    <option value="batch_del">{$Lang['batch_del']}</option>
                    <option value="batch_show">{$Lang['batch_show']}</option>
                    <option value="batch_hide">{$Lang['batch_hide']}</option>
                </select>
            </td>
            <td colspan="15">
                <div class="fixsel"><input type="submit" class="btn" id="submit_announcesubmit" name="announcesubmit" value="{$Lang['batch_btn']}" /></div>
            </td>
        </tr>
        <script type="text/javascript">
        function batch_do(){
          var r = confirm("{$Lang['batch_make_sure']}")
          if (r == true){
            return true;
          }else{
            return false;
          }
        }
        </script>
EOF;
    echo $formstr;
    showformfooter(); /*dism��taobao��com*/
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $servicer_id        = isset($_GET['servicer_id'])? intval($_GET['servicer_id']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):0;
    $title              = isset($_GET['title'])? addslashes($_GET['title']):'';
    $cate_id            = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $cate_child_id      = isset($_GET['cate_child_id'])? intval($_GET['cate_child_id']):0;
    $price              = isset($_GET['price'])? addslashes($_GET['price']):'';
    $open_vip           = isset($_GET['open_vip'])? intval($_GET['open_vip']):0;
    $vip_price          = isset($_GET['vip_price'])? addslashes($_GET['vip_price']):'';
    $open_ding_pay      = isset($_GET['open_ding_pay'])? intval($_GET['open_ding_pay']):0;
    $ding_price         = isset($_GET['ding_price'])? addslashes($_GET['ding_price']):'';
    $hasoption          = isset($_GET['hasoption'])? intval($_GET['hasoption']):0;
    $haibao_type        = isset($_GET['haibao_type'])? intval($_GET['haibao_type']):1;
    $haibao_msg         = isset($_GET['haibao_msg'])? addslashes($_GET['haibao_msg']):'';
    $qrcode_location    = isset($_GET['qrcode_location'])? intval($_GET['qrcode_location']):1;
    $hehuoren_tg_open   = isset($_GET['hehuoren_tg_open'])? intval($_GET['hehuoren_tg_open']):0;
    $hehuoren_tg_type   = isset($_GET['hehuoren_tg_type'])? intval($_GET['hehuoren_tg_type']):0;
    $hehuoren_fc_scale  = isset($_GET['hehuoren_fc_scale'])? floatval($_GET['hehuoren_fc_scale']):0;
    $hehuoren_fc_scale2 = isset($_GET['hehuoren_fc_scale2'])? floatval($_GET['hehuoren_fc_scale2']):0;
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $admin_edit         = isset($_GET['admin_edit'])? intval($_GET['admin_edit']):0;
    $virtual_sale_num   = isset($_GET['virtual_sale_num'])? intval($_GET['virtual_sale_num']):0;
    $paixu              = isset($_GET['paixu'])? intval($_GET['paixu']):1000;
    
    $picurl =  $haibao_picurl = "";"";
    if($_GET['act'] == 'add'){
        $picurl             = tomuploadFile("picurl");
        $haibao_picurl      = tomuploadFile("haibao_picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl             = tomuploadFile("picurl",$infoArr['picurl']);
        $haibao_picurl      = tomuploadFile("haibao_picurl",$infoArr['haibao_picurl']);
    }
    
    $servicerInfo    = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($servicer_id);
    
    $goodsInfo  = array();

    $goodsInfo['site_id']            = $site_id;
    $goodsInfo['cate_id']            = $cate_id;
    $goodsInfo['cate_child_id']      = $cate_child_id;
    $goodsInfo['servicer_id']        = $servicer_id;
    $goodsInfo['user_id']            = $servicerInfo['user_id'];
    $goodsInfo['title']              = $title;
    $goodsInfo['price']              = $price;
    $goodsInfo['open_vip']           = $open_vip;
    $goodsInfo['vip_price']          = $vip_price;
    $goodsInfo['open_ding_pay']      = $open_ding_pay;
    $goodsInfo['ding_price']         = $ding_price;
    $goodsInfo['hasoption']          = $hasoption;
    $goodsInfo['haibao_type']        = $haibao_type;
    $goodsInfo['haibao_msg']         = $haibao_msg;
    $goodsInfo['haibao_picurl']      = $haibao_picurl;
    $goodsInfo['qrcode_location']    = $qrcode_location;
    $goodsInfo['hehuoren_tg_open']   = $hehuoren_tg_open;
    $goodsInfo['hehuoren_tg_type']   = $hehuoren_tg_type;
    $goodsInfo['hehuoren_fc_scale']  = $hehuoren_fc_scale;
    $goodsInfo['hehuoren_fc_scale2'] = $hehuoren_fc_scale2;
    $goodsInfo['content']            = $content;
    $goodsInfo['admin_edit']         = $admin_edit;
    $goodsInfo['servicer_id']        = $servicerInfo['id'];
    $goodsInfo['address']            = $servicerInfo['address'];
    $goodsInfo['latitude']           = $servicerInfo['latitude'];
    $goodsInfo['longitude']          = $servicerInfo['longitude'];
    $goodsInfo['paixu']              = $paixu;
    $goodsInfo['virtual_sale_num']   = $virtual_sale_num;
    $data['picurl']                  = $picurl;
    $data['goodsInfo']               = $goodsInfo;
    $data['servicerInfo']            = $servicerInfo;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$tongchengConfig,$tcdaojiaConfig,$tcyikatongConfig;
    $options = array(
        'site_id'           => 0,
        'servicer_id'       => '',
        'user_id'           => '',
        'type'              => 0,
        'cate_id'           => 0,
        'cate_child_id'     => 0,
        'title'             => '',
        'price'             => '',
        'open_vip'          => 0,
        'vip_price'         => '',
        'open_ding_pay'     => 0,
        'ding_price'        => '',
        'hasoption'         => 0,
        'haibao_type'       => 1,
        'haibao_msg'        => '',
        'haibao_picurl'     => '',
        'qrcode_location'   => 1,
        'hehuoren_tg_open'  => 0,
        'hehuoren_tg_type'  => 0,
        'hehuoren_fc_scale' => 0,
        'hehuoren_fc_scale2'  => 0,
        'content'           => '',
        'admin_edit'        => 0,
        'paixu'             => 1000,
        'virtual_sale_num'  => 0,
        'picurl'            => '',
    );
    $options = array_merge($options, $infoArr);
    
    $picurl = '';
    if($options['id'] > 0){
        $photoListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND goods_id={$options['id']} AND type = 1 "," ORDER BY type DESC,id ASC ",0,1);
        if(is_array($photoListTmp) && !empty($photoListTmp)){
            foreach($photoListTmp as $key => $value){
                $picurl = $value['picurl'];
            }
        }
    }
    
    $__CityInfo  = array('id'=>0,'name'=>'');
    if($options['site_id'] > 1){
        $sitesInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($options['site_id']);
        if($sitesInfoTmp){
            $__SitesInfo = $sitesInfoTmp;
            if(!empty($__SitesInfo['city_id'])){
                $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($__SitesInfo['city_id']);
                if($cityInfoTmp){
                    $__CityInfo = $cityInfoTmp;
                }
            }
        }
    }else if($options['site_id'] == 1){
        $cityInfoTmp = array();
        if(!empty($tongchengConfig['city_id'])){
            $cityInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_by_id($tongchengConfig['city_id']);
        }
        if(!empty($cityInfoTmp)){
            $__CityInfo = $cityInfoTmp;
        }
    }
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" AND status=1 "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr class="header"><th>'.$Lang['sites_title'].'</th><th></th></tr>';
    $sitesStr.= '<tr><td width="300"><select style="width: 260px;" name="site_id" id="site_id" onChange="getCity();">';
    $sitesStr.=  '<option value="1">'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($value['id'] == $options['site_id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td><td></td></tr>';
    echo $sitesStr;
    tomshowsetting(true,array('title'=>$Lang['goods_servicer_id'],'name'=>'servicer_id','value'=>$options['servicer_id'],'msg'=>$Lang['goods_servicer_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_price'],'name'=>'price','value'=>$options['price'],'msg'=>$Lang['goods_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_title'],'name'=>'title','value'=>$options['title'],'msg'=>$Lang['goods_title_msg']),"input");
    
    $cateList = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",0,100);
    $catesStr = '<tr class="header"><th>'.$Lang['goods_cate_id'].'</th><th></th></tr>';
    $catesStr.= '<tr><td width="300"><select style="width: 150px;" name="cate_id" id="cate_id" onchange="getChild();">';
    $catesStr.=  '<option value="0">'.$Lang['goods_cate_id'].'</option>';
    foreach ($cateList as $key => $value){
        if($value['id'] == $options['cate_id']){
            $catesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $catesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $catesStr.= '</select>&nbsp;&nbsp;<select style="width: 150px;" name="cate_child_id" id="cate_child_id">';
    $catesStr.=  '<option value="0">'.$Lang['goods_cate_child_id'].'</option>';
    if($options['cate_id'] > 0){
        $childCateList = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid={$options['cate_id']} "," ORDER BY csort ASC,id DESC ",0,100);
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $key => $value) {
                if($value['id'] == $options['cate_child_id']){
                    $catesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
                }else{
                    $catesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                }
            }
        }
    }
    $catesStr.= '</select></td><td>'.$Lang['goods_cate_id_msg'].'</td></tr>';
    echo $catesStr;
    
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $open_vip_item = array(0=>$Lang['goods_open_vip_0'],1=>$Lang['goods_open_vip_1']);
        tomshowsetting(true,array('title'=>$Lang['goods_open_vip'],'name'=>'open_vip','value'=>$options['open_vip'],'msg'=>$tcyikatongConfig['plugin_name'].$Lang['goods_open_vip_msg'],'item'=>$open_vip_item),"radio");
        tomshowsetting(true,array('title'=>$Lang['goods_vip_price'],'name'=>'vip_price','value'=>$options['vip_price'],'msg'=>$tcyikatongConfig['plugin_name'].$Lang['goods_vip_price_msg']),"input");
    }
    $open_ding_pay_item = array(0=>$Lang['goods_open_ding_pay_0'],1=>$Lang['goods_open_ding_pay_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_open_ding_pay'],'name'=>'open_ding_pay','value'=>$options['open_ding_pay'],'msg'=>$Lang['goods_open_ding_pay_msg'],'item'=>$open_ding_pay_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_ding_price'],'name'=>'ding_price','value'=>$options['ding_price'],'msg'=>$Lang['goods_ding_price_msg']),"input");
    $goods_hasoption_item = array(0=>$Lang['goods_hasoption_0'],1=>$Lang['goods_hasoption_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_hasoption'],'name'=>'hasoption','value'=>$options['hasoption'],'msg'=>$Lang['goods_hasoption_msg'],'item'=>$goods_hasoption_item),"radio");
    $haibao_type_item = array(1=>$Lang['goods_haibao_type_1'],2=>$Lang['goods_haibao_type_2']);
    tomshowsetting(true,array('title'=>$Lang['goods_haibao_type'],'name'=>'haibao_type','value'=>$options['haibao_type'],'msg'=>$Lang['goods_haibao_type_msg'],'item'=>$haibao_type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_haibao_msg'],'name'=>'haibao_msg','value'=>$options['haibao_msg'],'msg'=>$Lang['goods_haibao_msg_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_haibao_picurl'],'name'=>'haibao_picurl','value'=>$options['haibao_picurl'],'msg'=>$Lang['goods_haibao_picurl_msg']),"file");
    $qrcode_location_item = array(1=>$Lang['goods_qrcode_location_1'],2=>$Lang['goods_qrcode_location_2']);
    tomshowsetting(true,array('title'=>$Lang['goods_qrcode_location'],'name'=>'qrcode_location','value'=>$options['qrcode_location'],'msg'=>$Lang['goods_qrcode_location_msg'],'item'=>$qrcode_location_item),"radio");
    $goods_hehuoren_tg_open_item = array(0=>$Lang['goods_hehuoren_tg_open_0'],1=>$Lang['goods_hehuoren_tg_open_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_hehuoren_tg_open'],'name'=>'hehuoren_tg_open','value'=>$options['hehuoren_tg_open'],'msg'=>$Lang['goods_hehuoren_tg_open_msg'],'item'=>$goods_hehuoren_tg_open_item),"radio");
    $goods_hehuoren_tg_type_item = array(1=>$Lang['goods_hehuoren_tg_type_1'],2=>$Lang['goods_hehuoren_tg_type_2']);
    tomshowsetting(true,array('title'=>$Lang['goods_hehuoren_tg_type'],'name'=>'hehuoren_tg_type','value'=>$options['hehuoren_tg_type'],'msg'=>$Lang['goods_hehuoren_tg_type_msg'],'item'=>$goods_hehuoren_tg_type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_hehuoren_fc_scale'],'name'=>'hehuoren_fc_scale','value'=>$options['hehuoren_fc_scale'],'msg'=>$Lang['goods_hehuoren_fc_scale_msg']),"input");
    if ($tcdaojiaConfig['subordinate_moneytype'] != 0){
        tomshowsetting(true,array('title'=>$Lang['goods_hehuoren_fc_scale2'],'name'=>'hehuoren_fc_scale2','value'=>$options['hehuoren_fc_scale2'],'msg'=>$Lang['goods_hehuoren_fc_scale2_msg']),"input");
    }
    tomshowsetting(true,array('title'=>$Lang['goods_picurl'],'name'=>'picurl','value'=>$picurl,'msg'=>$Lang['goods_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['goods_virtual_sale_num'],'name'=>'virtual_sale_num','value'=>$options['virtual_sale_num'],'msg'=>$Lang['goods_virtual_sale_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['goods_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['goods_paixu_msg']),"input");
    $admin_edit_item = array(0=>$Lang['goods_admin_edit_0'],1=>$Lang['goods_admin_edit_1']);
    tomshowsetting(true,array('title'=>$Lang['goods_admin_edit'],'name'=>'admin_edit','value'=>$options['admin_edit'],'msg'=>$Lang['goods_admin_edit_msg'],'item'=>$admin_edit_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['goods_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['goods_content_msg']),"text");
    
    $jsstr = <<<EOF
<script type="text/javascript">
function getChild(){
  var cate_id = jq("#cate_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcdaojia:ajax",
        data: "act=childcates&pid="+cate_id,
        dataType : "json",
        success: function(json){
            var cateChildHtml = '<option value="0">{$Lang['goods_cate_child_id']}</option>';
            jq.each(json,function(k,v){
                cateChildHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#cate_child_id").html(cateChildHtml);
            jq("#cate_child_id").show();
        }
    });
}
</script>
EOF;
    echo $jsstr;
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['goods_edit'],"",true);
    }else{
        tomshownavli($Lang['goods_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['goods_add'],$modBaseUrl."&act=add",false);
        //tomshownavli($Lang['doDao_title_1'],$adminBaseUrl.'&tmod=doDaoGoods',false);
    }
    tomshownavfooter();
}