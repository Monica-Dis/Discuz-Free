<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=dengji';
$modListUrl = $adminListUrl.'&tmod=dengji';
$modFromUrl = $adminFromUrl.'&tmod=dengji';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $dengjiInfo = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($dengjiInfo);
        if(C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->update($dengjiInfo['id'],$updateData)){
            $dengjiInfo = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_by_id($dengjiInfo['id']);
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html($dengjiInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $servicerCount = C::t("#tom_tcdaojia#tom_tcdaojia_servicer")->fetch_all_count(" AND dengji_id = {$_GET['id']} ");
    if($servicerCount > 0){
        cpmsg($Lang['dengji_no_remove_error'], $modListUrl, 'error');exit;
    }
    
    C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->delete_by_id($_GET['id']);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'import'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/config/import.data.php';
    
    foreach ($dengjiArr as $key => $value){
        $insertData = array();
        $insertData = $value;
        $insertData['dsort']    = $key;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->insert($insertData);
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'update_status'){
    
    $updateData = array();
    $updateData['status'] = $_GET['status'];
    C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->update($_GET['id'], $updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else{
    
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['dengji_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=import&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['dengji_import'].'</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism _taobao _com*/
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $pagesize = 100;
    $start = ($page-1)*$pagesize;
    $dengjiList = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_all_list(""," ORDER BY dsort ASC,id DESC ",$start,$pagesize);
    
    __create_nav_html();
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr class="header">';
    echo '<th> ID </th>';
    //echo '<th>' . $Lang['dengji_picurl'] . '</th>';
    echo '<th>' . $Lang['dengji_name'] . '</th>';
    echo '<th>' . $Lang['dengji_days'] . '</th>';
    echo '<th>' . $Lang['dengji_days_msg'] . '</th>';
    echo '<th>' . $Lang['dengji_price'] . '</th>';
    echo '<th>' . $Lang['dengji_fabu_goods_num'] . '</th>';
    echo '<th>' . $Lang['dengji_xiangou_num'] . '</th>';
    echo '<th>' . $Lang['dengji_status'] . '</th>';
    echo '<th>' . $Lang['dengji_dsort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($dengjiList as $key => $value) {
        
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        //echo '<td><img src="'.$picurl.'" width="40" /></td>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['days'] . '</td>';
        echo '<td>' . $value['days_msg'] . '</td>';
        echo '<td><font color="#fd0d0d">' . $value['price'] . '</font></td>';
        echo '<td>' . $value['fabu_goods_num'] . '</td>';
        if($value['xiangou_num'] > 0){
            echo '<td>' . $value['xiangou_num'] . '</td>';
        }else{
            echo '<td><font color="#0a9409">' . $Lang['dengji_xiangou_num_0'] . '</font></td>';
        }
        if($value['status'] == 1 ){
            echo '<td><font color="#0a9409">' . $Lang['dengji_status_1'] . '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=update_status&status=0&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['dengji_status_0']. '</a>)</td>';
        }else{
            echo '<td><font color="#f70404">' . $Lang['dengji_status_0'] . '</font>&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=update_status&status=1&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['dengji_status_1']. '</a>)</td>';
        }
        echo '<td>' . $value['dsort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism _taobao _com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
  
function import_confirm(url){
  var r = confirm("{$Lang['makesure_import_dengji_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $days           = intval($_GET['days'])>0? intval($_GET['days']):0;
    $days_msg       = isset($_GET['days_msg'])? addslashes($_GET['days_msg']):'';
    $price          = floatval($_GET['price'])>0? floatval($_GET['price']):0.00;
    $fabu_goods_num = intval($_GET['fabu_goods_num'])>0? intval($_GET['fabu_goods_num']):0;
    $xiangou_num    = intval($_GET['xiangou_num'])>0? intval($_GET['xiangou_num']):0;
    $dsort          = intval($_GET['dsort'])>0? intval($_GET['dsort']):10;

    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    $data['name']           = $name;
    //$data['picurl']         = $picurl;
    $data['days']           = $days;
    $data['days_msg']       = $days_msg;
    $data['price']          = $price;
    $data['fabu_goods_num'] = $fabu_goods_num;
    $data['xiangou_num']    = $xiangou_num;
    $data['dsort']          = $dsort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'              => '',
        'picurl'            => '',
        'days'              => 0,
        'days_msg'          => '',
        'price'             => 0.00,
        'fabu_goods_num'    => 0,
        'xiangou_num'       => 0,
        'dsort'             => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['dengji_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['dengji_name_msg']),"input");
    //tomshowsetting(true,array('title'=>$Lang['dengji_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['dengji_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['dengji_days'],'name'=>'days','value'=>$options['days'],'msg'=>$Lang['dengji_day_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['dengji_days_msg'],'name'=>'days_msg','value'=>$options['days_msg'],'msg'=>$Lang['dengji_days_msg_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['dengji_price'],'name'=>'price','value'=>$options['price'],'msg'=>$Lang['dengji_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['dengji_fabu_goods_num'],'name'=>'fabu_goods_num','value'=>$options['fabu_goods_num'],'msg'=>$Lang['dengji_fabu_goods_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['dengji_xiangou_num'],'name'=>'xiangou_num','value'=>$options['xiangou_num'],'msg'=>$Lang['dengji_xiangou_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['dengji_dsort'],'name'=>'dsort','value'=>$options['dsort'],'msg'=>$Lang['dengji_dsort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['dengji_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['dengji_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['dengji_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['dengji_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['dengji_edit'],"",true);
    }else{
        tomshownavli($Lang['dengji_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['dengji_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['dengji_code_title'],$adminBaseUrl."&tmod=dengji_code",false);
    }
    tomshownavfooter();
}