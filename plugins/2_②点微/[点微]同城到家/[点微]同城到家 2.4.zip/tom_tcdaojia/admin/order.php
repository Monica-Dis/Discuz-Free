<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=order'; 
$modListUrl = $adminListUrl.'&tmod=order';
$modFromUrl = $adminFromUrl.'&tmod=order';

$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';

if($formhash == FORMHASH && $act == 'info'){
    
}else{
    
    $site_id            = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):0;
    $order_status       = isset($_GET['order_status'])? intval($_GET['order_status']):0;
    $page               = intval($_GET['page'])>0? intval($_GET['page']):1;
    
    $where = " AND type IN (5,6,7,8,9) ";
   
    if(!empty($site_id)){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($user_id)){
        $where.= " AND user_id={$user_id} ";
    }
    if($type > 0){
        $where.= " AND type={$type} ";
    }
    if($order_status > 0){
        $where.= " AND order_status={$order_status} ";
    }
    
    $order = "ORDER BY order_time DESC,id DESC";
    
    $pagesize = 30;
    $start = ($page-1)*$pagesize;	
    $count = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_count($where);
    $orderList = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_list($where,$order,$start,$pagesize);
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&user_id={$user_id}&order_status={$order_status}&type={$type}";
    
    showformheader($modFromUrl.'&formhash='.FORMHASH);
    showtableheader(); /*DisM.Taobao.Com*/
    $site_1 = '';
    if($site_id == 1){
        $site_1 = 'selected';
    }
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '</th></tr>';
    echo '<tr><td width="100" align="right"><b>'.$Lang['user_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="user_id" value="'.$user_id.'"></td></tr>';
    
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,100);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$site_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $order_type_5 = $order_type_6  = $order_type_7 = $order_type_8 = $order_type_9 = '';
    if($type == 5){
        $order_type_5 = 'selected';
    }else if($type == 6){
        $order_type_6 = 'selected';
    }else if($type == 7){
        $order_type_7 = 'selected';
    }else if($type == 8){
        $order_type_8 = 'selected';
    }else if($type == 9){
        $order_type_9 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['order_type'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="type">';
    $statusStr.=  '<option value="0">'.$Lang['select_all'].'</option>';
    $statusStr.=  '<option value="5" '.$order_type_5.'>'.$Lang['order_type_5'].'</option>';
    $statusStr.=  '<option value="6" '.$order_type_6.'>'.$Lang['order_type_6'].'</option>';
    $statusStr.=  '<option value="7" '.$order_type_7.'>'.$Lang['order_type_7'].'</option>';
    $statusStr.=  '<option value="8" '.$order_type_8.'>'.$Lang['order_type_8'].'</option>';
    $statusStr.=  '<option value="9" '.$order_type_9.'>'.$Lang['order_type_9'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    
    $order_status_1 = $order_status_2 = '';
    if($order_status == 1){
        $order_status_1 = 'selected';
    }else if($order_status == 2){
        $order_status_2 = 'selected';
    }
    $statusStr = '<tr><td width="100" align="right"><b>'.$Lang['order_status'].'</b></td>';
    $statusStr.= '<td><select style="width: 260px;" name="order_status">';
    $statusStr.=  '<option value="0">'.$Lang['select_all'].'</option>';
    $statusStr.=  '<option value="1" '.$order_status_1.'>'.$Lang['order_status_1'].'</option>';
    $statusStr.=  '<option value="2" '.$order_status_2.'>'.$Lang['order_status_2'].'</option>';
    $statusStr.= '</select></td></tr>';
    echo $statusStr;
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism _taobao _com*/
    showformfooter(); /*dism��taobao��com*/
    
    $todayPayPrice = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_sun_pay_price(" AND pay_time > $nowDayTime AND order_status=2 AND type IN (5,6,7,8,9)");
    $monthPayPrice = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_sun_pay_price(" AND pay_time > $nowMonthTime AND order_status=2 AND type IN (5,6,7,8,9)");
    $allPayPrice = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_sun_pay_price(" AND order_status=2 AND type IN (5,6,7,8,9) ");
    echo '<div style="background-color: #f1f1f1;line-height: 30px;height: 30px;" >&nbsp;&nbsp;';
    echo $Lang['today_pay_price_title'].'<font color="#fd0d0d">('.$todayPayPrice.')</font>&nbsp;&nbsp;';
    echo $Lang['month_pay_price_title'].'<font color="#fd0d0d">('.$monthPayPrice.')</font>&nbsp;&nbsp;';
    echo $Lang['all_pay_price_title'].'<font color="#fd0d0d">('.$allPayPrice.')</font>&nbsp;&nbsp;';
    echo '</div>';
    
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['order_list_title'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' . $Lang['user_picurl'] . '</th>';
    echo '<th>' . $Lang['user_nickname'] . '</th>';
    echo '<th>' . $Lang['order_order_no'] . '</th>';
    echo '<th>' . $Lang['order_type'] . '</th>';
    echo '<th>' . $Lang['order_about'] . '</th>';
    echo '<th>' . $Lang['order_pay_price'] . '</th>';
    echo '<th>' . $Lang['order_order_status'] . '</th>';
    echo '<th>' . $Lang['order_time'] . '</th>';
    echo '<th>' . $Lang['order_order_pay_time'] . '</th>';
    echo '</tr>';
    foreach ($orderList as $key => $value){
        $modelUrl     = $adminBaseUrl.'&tmod=index';
        $goodsInfo    = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($value['goods_id']);
        $needsInfo    = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($value['needs_id']);
        $servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($value['servicer_id']);
        $userInfo     = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $siteInfoTmp  = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        
        $title   = cutstr($goodsInfo['title'],30,"...");
        $content = cutstr($needsInfo['content'],30,"...");
        
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td><font color="#0894fb"><b>' . $siteInfoTmp['name'] . '</b></font></td>';
        }else{
            echo '<td><font color="#0894fb"><b>' . $Lang['sites_one'] . '</b></font></td>';
        }
        echo '<td><img src="'.$userInfo['picurl'].'" width="40" /></td>';
        echo '<td>'.$userInfo['nickname'].'</td>';
        echo '<td>'.$value['order_no'].'</td>';
        if($value['type'] == 5){
            $order_type_5_msg = str_replace("{DAYS}", $value['top_days'], $Lang['order_type_5_msg']);
            echo '<td>'.$Lang['order_type_5'].$order_type_5_msg.'</td>';
        }else if($value['type'] == 6){
            $order_type_6_msg = str_replace("{DAYS}", $value['top_days'], $Lang['order_type_6_msg']);
            echo '<td>'.$Lang['order_type_6'].$order_type_6_msg.'</td>';
        }else if($value['type'] == 7){
            $order_type_7_msg = str_replace("{DAYS}", $value['top_days'], $Lang['order_type_7_msg']);
            echo '<td>'.$Lang['order_type_7'].$order_type_6_msg.'</td>';
        }else if($value['type'] == 8){
            $dengjiInfo = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_by_id($value['dengji_id']);
            echo '<td>'.$Lang['order_type_8'].'<font color="#fd0d0d">('.$dengjiInfo['name'].')</font></td>';
        }else if($value['type'] == 9){
            $dengjiInfo = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_by_id($value['dengji_id']);
            echo '<td>'.$Lang['order_type_9'].'<font color="#fd0d0d">('.$dengjiInfo['name'].')</font></td>';
        }else{
            echo '<td>-</td>';
        }
        if($value['goods_id'] > 0){
            echo '<td>' .'<a target="_blank" href="'.$adminBaseUrl.'&tmod=goods&goods_id='.$value['goods_id'].'&formhash='.FORMHASH.'">' . $title . '</a></td>';
        }else if($value['needs_id'] > 0){
            echo '<td>' .'<a target="_blank" href="'.$adminBaseUrl.'&tmod=needs&needs_id='.$value['needs_id'].'&formhash='.FORMHASH.'">' . $content . '</a></td>';
        }else if($value['servicer_id'] > 0){
            echo '<td>' .'<a target="_blank" href="'.$adminBaseUrl.'&tmod=index&servicer_id='.$value['servicer_id'].'&formhash='.FORMHASH.'">' . $servicerInfo['name'] . '</a></td>';
        }
        echo '<td><font color="#0a9409">'.$value['pay_price'].'</font></td>';
        if($value['order_status'] == 1){
            echo '<td><font color="#f00">'.$Lang['order_status_1'].'</font></td>';
        }else if($value['order_status'] == 2){
            echo '<td><font color="#0a9409">'.$Lang['order_status_2'].'</font></td>';
        }else{
            echo '<td>-</td>';
        }
        echo '<td>'.dgmdate($value['order_time'],"Y-m-d H:i",$tomSysOffset).'</td>';
        if($value['pay_time'] > 0){
            echo '<td>'.dgmdate($value['pay_time'],"Y-m-d H:i",$tomSysOffset).'</td>';
        }else{
            echo '<td>-</td>';
        }
        
        echo '</tr>';
    }
    showtablefooter(); /*dism _taobao _com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
}