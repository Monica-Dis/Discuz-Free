<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=vip';
$modListUrl = $adminListUrl.'&tmod=vip';
$modFromUrl = $adminFromUrl.'&tmod=vip';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tcdaojia#tom_tcdaojia_vip')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else if($_GET['act'] == 'edit'){
    
    $vipInfo = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_by_id($_GET['id']);

    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($vipInfo);
        C::t('#tom_tcdaojia#tom_tcdaojia_vip')->update($vipInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html($vipInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcdaojia#tom_tcdaojia_vip')->delete_by_id($_GET['id']);
    
    DB::query("UPDATE ".DB::table('tom_tcdaojia_servicer')." SET vip_id=0,`rank`=0 WHERE vip_id = {$_GET['id']} ", 'UNBUFFERED');
    
    $servicerListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_all_list(" AND vip_id = {$_GET['id']} "," ORDER BY id DESC ",0,10000);
    $servicerListIds = array();
    $servicerListIdsStr = '';
    if(is_array($servicerListTmp) && !empty($servicerListTmp)){
        foreach ($servicerListTmp as $key => $value){
            $servicerListIds[] = $value['id'];
        }
        $servicerListIdsStr = implode(',', $goodsListIds);
        DB::query("UPDATE ".DB::table('tom_tcdaojia_goods')." SET servicer_rank={$newVip['rank']} WHERE servicer_id IN({$servicerListIdsStr}) ", 'UNBUFFERED');
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'import'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/config/import.data.php';
    
    foreach ($vipArr as $key => $value){
        $insertData = array();
        $insertData['name']         = $value['name'];
        $insertData['picurl']       = $value['picurl'];
        $insertData['up_jie_num']   = $value['up_jie_num'];
        $insertData['up_grade']     = $value['up_grade'];
        $insertData['yongjin_bili'] = $value['yongjin_bili'];
        $insertData['rank']         = $value['rank'];
        $insertData['vsort']        = $key;
        C::t('#tom_tcdaojia#tom_tcdaojia_vip')->insert($insertData);
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else {
    
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['vip_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=import&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['vip_import'].'</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism _taobao _com*/
    
    $pagesize   = 10;
    $page       = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start      = ($page-1)*$pagesize;	
    $count      = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_all_count("");
    $vipList    = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_all_list(""," ORDER BY vsort ASC,id DESC ",$start,$pagesize);
  
    __create_nav_html();
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['vip_picurl'] . '</th>';
    echo '<th>' . $Lang['vip_name'] . '</th>';
    echo '<th>' . $Lang['vip_up_jie_num'] . '</th>';
    echo '<th>' . $Lang['vip_up_grade'] . '</th>';
    echo '<th>' . $Lang['vip_yongjin_bili'] . '</th>';
    echo '<th>' . $Lang['vip_rank'] . '</th>';
    echo '<th>' . $Lang['paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    $i = 1;
    foreach ($vipList as $key => $value) {
        if(!preg_match('/^http/', $value['picurl'])){
            if(strpos($value['picurl'], 'source/plugin/') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        echo '<tr>';
        echo '<td>' . '<img style="height:40px;width:40px;" src="' .$picurl. '">' . '</td>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td><font color="#fd0d0d">&ge;</font> ' . $value['up_jie_num'] . '</td>';
        echo '<td><font color="#fd0d0d">&ge;</font> ' . $value['up_grade'] . '</td>';
        echo '<td>' . '<font color="#0a9409">' . $value['yongjin_bili'] . '%</font> '. '</td>';
        echo '<td>' . $value['rank'] . '</td>';
        echo '<td>' . $value['vsort'] . '</td>';
        echo '<td style="line-height: 25px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['vip_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); /*dism _taobao _com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function import_confirm(url){
  var r = confirm("{$Lang['makesure_import_vip_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;

}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name           = isset($_GET['name'])? addslashes($_GET['name']):'';
    $price          = isset($_GET['price'])? floatval($_GET['price']):0.00;
    $up_jie_num     = isset($_GET['up_jie_num'])? intval($_GET['up_jie_num']):0;
    $up_grade       = isset($_GET['up_grade'])? intval($_GET['up_grade']):0;
    $yongjin_bili   = isset($_GET['yongjin_bili'])? intval($_GET['yongjin_bili']):0;
    $rank           = isset($_GET['rank'])? intval($_GET['rank']):0;
    $vsort          = isset($_GET['vsort'])? intval($_GET['vsort']):100;
    
    $picurl     = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    $data['name']             = $name;
    $data['picurl']           = $picurl;
    $data['up_jie_num']       = $up_jie_num;
    $data['up_grade']         = $up_grade;
    $data['yongjin_bili']     = $yongjin_bili;
    $data['rank']             = $rank;
    $data['vsort']            = $vsort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'           => '',
        'picurl'         => '',
        'up_jie_num'     => 0,
        'up_grade'       => 0,
        'yongjin_bili'   => '',
        'rank'           => 0,
        'vsort'          => 0,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['vip_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['vip_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['vip_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['vip_up_jie_num'],'name'=>'up_jie_num','value'=>$options['up_jie_num'],'msg'=>$Lang['vip_up_jie_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_up_grade'],'name'=>'up_grade','value'=>$options['up_grade'],'msg'=>$Lang['vip_up_grade_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_yongjin_bili'],'name'=>'yongjin_bili','value'=>$options['yongjin_bili'],'msg'=>$Lang['vip_yongjin_bili_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_rank'],'name'=>'rank','value'=>$options['rank'],'msg'=>$Lang['vip_rank_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['vip_vsort'],'name'=>'vsort','value'=>$options['vsort'],'msg'=>$Lang['vip_vsort_msg']),"input");
    return;
}
function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['vip_type'],$modBaseUrl,false);
        tomshownavli($Lang['vip_add_type'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['vip_type'],$modBaseUrl,false);
        tomshownavli($Lang['vip_add_type'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['vip_edit_type'],"",true);
    }else{
        tomshownavli($Lang['vip_type'],$modBaseUrl,true);
        tomshownavli($Lang['vip_add_type'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}