<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$modBaseUrl = $adminBaseUrl.'&tmod=servicer'; 
$modListUrl = $adminListUrl.'&tmod=servicer';
$modFromUrl = $adminFromUrl.'&tmod=servicer';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $data = __get_post_data();
        $insertData                    = $data['servicerInfo'];
        $insertData['status']          = 2;
        $insertData['shenhe_status']   = 1;
        $insertData['add_time']        = TIMESTAMP;
        $insertData['refresh_time']    = TIMESTAMP;
        if(C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->insert($insertData)){
            $servicer_id = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->insert_id();
        }
        if(!empty($data['picurl'])){
            $insertData = array();
            $insertData['servicer_id']      = $servicer_id;
            $insertData['type']             = 3;
            $insertData['picurl']           = $data['picurl'];
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcdaojia#tom_tcdaojia_photo")->insert($insertData);
        }
        
        cpmsg($Lang['act_success'], $modListUrl.'&act=edit&id='.$servicer_id, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add&id='.$_GET['id'],'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
}else if($_GET['act'] == 'edit'){
    
    $servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($_GET['id']);
    
    if(submitcheck('submit')){
        
        $data = __get_post_data($servicerInfo);
        $updateData = $data['servicerInfo'];
        $updateData['add_time']     = TIMESTAMP;
        $updateData['refresh_time'] = TIMESTAMP;
       
        C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->update($servicerInfo['id'],$updateData);
        
        if($servicerInfo['id'] > 0){
            C::t('#tom_tcdaojia#tom_tcdaojia_photo')->delete_all_list(" AND servicer_id={$servicerInfo['id']} AND type IN(3) ");
        }
        
        $servicerInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($servicerInfo['id']);
        
        DB::query("UPDATE ".DB::table('tom_tcdaojia_goods')." SET latitude='{$servicerInfo['latitude']}',longitude='{$servicerInfo['longitude']}',address='{$servicerInfo['address']}' WHERE servicer_id = {$servicerInfo['id']} ", 'UNBUFFERED');
        
        if(!empty($data['picurl'])){
            $insertData = array();
            $insertData['servicer_id']      = $servicerInfo['id'];
            $insertData['type']             = 3;
            $insertData['picurl']           = $data['picurl'];
            $insertData['add_time']         = TIMESTAMP;
            C::t("#tom_tcdaojia#tom_tcdaojia_photo")->insert($insertData);
        }
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html($servicerInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
    DB::query("UPDATE ".DB::table('tom_tcdaojia_servicer')." SET status=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    DB::query("UPDATE ".DB::table('tom_tcdaojia_servicer')." SET status=2 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show_jiestatus'){
    
    DB::query("UPDATE ".DB::table('tom_tcdaojia_servicer')." SET jie_status=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide_jiestatus'){
    
    DB::query("UPDATE ".DB::table('tom_tcdaojia_servicer')." SET jie_status=0 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'pay_ok'){
    
    $updateData = array();
    $updateData['pay_status'] = 2;
    C::t("#tom_tcdaojia#tom_tcdaojia_servicer")->update($_GET['id'], $updateData);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenheok'){
    
    DB::query("UPDATE ".DB::table('tom_tcdaojia_servicer')." SET shenhe_status=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    $servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($_GET['id']);
    if($servicerInfo['site_id'] == 1){
        $sitename = $tongchengConfig['plugin_name'];
    }else{
        $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($servicerInfo['site_id']);
        $sitename = $siteInfo['name'];
    }
    $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']);

    $shenhe = str_replace('{XM}', $servicerInfo['name'], $Lang['template_daojia_shenhe_ok']);
    $cpmsg = $Lang['tcdaojia_shenhe_tz_succ'];
    $access_token = $weixinClass->get_access_token();
    if($access_token && !empty($tcUserInfo['openid'])){
        $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$servicerInfo['site_id']}&mod=servicerinfo&servicer_id=".$servicerInfo['id']);
        $smsData = array(
            'first'         => $shenhe,
            'keyword1'      => $sitename,
            'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
            'remark'        => ''
        );

        @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        if($r){
        }else{
            $cpmsg = $Lang['tcdaojia_shenhe_tz_fail'];
        }
    }

    $insertData = array();
    $insertData['user_id']      = $tcUserInfo['id'];
    $insertData['type']         = 1;
    $insertData['content']      = '<font color="#238206">'.$tcdaojiaConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset);
    $insertData['is_read']      = 0;
    $insertData['tz_time']      = TIMESTAMP;
    C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
    
    cpmsg($cpmsg, $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'shenheno'){
    
    if(submitcheck('submit')){
        $text = isset($_GET['text'])? addslashes($_GET['text']):'';
        
        DB::query("UPDATE ".DB::table('tom_tcdaojia_servicer')." SET shenhe_status=3 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
        
        $servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($_GET['id']);
        if($servicerInfo['site_id'] == 1){
            $sitename = $tongchengConfig['plugin_name'];
        }else{
            $siteInfo = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($servicerInfo['site_id']);
            $sitename = $siteInfo['name'];
        }
        $tcUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']);
        
        $shenhe = str_replace('{XM}', $servicerInfo['name'], $Lang['template_daojia_shenhe_no']);
        $cpmsg = $Lang['tcdaojia_shenhe_tz_succ'];
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
        $weixinClass = new weixinClass($appid,$appsecret);
        include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($tcUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$servicerInfo['site_id']}&mod=edit&servicer_id={$servicerInfo['id']}");
            $smsData = array(
                'first'         => $shenhe,
                'keyword1'      => $sitename,
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => $text
            );
            @$r = $templateSmsClass->sendSms01($tcUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
            if($r){
            }else{
                $cpmsg = $Lang['tcdaojia_shenhe_tz_fail'];
            }
        }
        
        $insertData = array();
        $insertData['user_id']      = $tcUserInfo['id'];
        $insertData['type']         = 1;
        $insertData['content']      = '<font color="#238206">'.$tcdaojiaConfig['plugin_name'].'</font><br/>'.$shenhe.'<br/>'.$Lang['tcdaojia_shenhe_fail_title'].$text.'<br/>'.dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset);
        $insertData['is_read']      = 0;
        $insertData['tz_time']      = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_tz')->insert($insertData);
        
        cpmsg($cpmsg, $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=shenheno&id='.$_GET['id'],'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        tomshowsetting(true,array('title'=>$Lang['tcdaojia_shenhe_fail_title'],'name'=>'text','value'=>'','msg'=>$Lang['tcdaojia_shenhe_fail_title_msg']),"textarea");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->delete_by_id($_GET['id']);
    C::t('#tom_tcdaojia#tom_tcdaojia_team')->delete_by_servicer_id($_GET['id']);
    C::t('#tom_tcdaojia#tom_tcdaojia_photo')->delete_by_servicer_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editvip'){
    
    $servicer_id  = isset($_GET['servicer_id'])? intval($_GET['servicer_id']):0;
    
    $servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($servicer_id);
    
    if(submitcheck('submit')){
        $vip_id       = intval($_GET['vip_id']);
        
        $updateData = array();
        $updateData['vip_id']   = $vip_id;
        C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->update($servicer_id,$updateData);

        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editvip&servicer_id='.$_GET['servicer_id'].'&formhash='.FORMHASH);
        showtableheader(); /*DisM.Taobao.Com*/
        $vipList = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_all_list("");
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_vip_title'] .'('.$servicerInfo['name']. ')</th></tr>';
        echo '<tr><td width="100" ><b>' . $Lang['vip_id'] . '</b><tr></tr><td><select  style="width: 260px;" name="vip_id" >';
        echo '<option value="0">'.$Lang['edit_vip_id_0'].'</option>';
        if(is_array($vipList) && !empty($vipList)){
            foreach ($vipList as $key => $value){
                if($value['id'] == $servicerInfo['vip_id']){
                    echo  '<option value='.$value['id'].' selected>'.$value['name'].'</option>';
                }else{
                    echo  '<option value='.$value['id'].'>'.$value['name'].'</option>';
                }
            }
        }
        echo '</select></td>';
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'edittop'){
    $info = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $top_time     = isset($_GET['top_time'])? addslashes($_GET['top_time']):'';
        $top_time     = strtotime($top_time);
        $updateData = array();
        if($top_time < TIMESTAMP){
            $updateData['top_status']   = 0;
            $updateData['top_time']     = 0;
        }else{
            $updateData['top_status']   = 1;
            $updateData['refresh_time'] = TIMESTAMP;
            $updateData['top_time']     = $top_time;
        }
        C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->update($_GET['id'],$updateData);
            
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=edittop&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader(); /*DisM.Taobao.Com*/
        echo '<tr><th colspan="15" class="partition">' . $Lang['edit_top_title'] .'</th></tr>';
        tomshowsetting(true,array('title'=>$Lang['edit_top_time'],'name'=>'top_time','value'=>$info['top_time'],'msg'=>$Lang['edit_top_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else if($_GET['act'] == 'photo'){
    
    $servicer_id = $_GET['servicer_id'];
    
    if(submitcheck('submit')){
        
        if($_FILES["picurl"]['tmp_name']) {
            $upload = new tom_upload();
            if(!$upload->init($_FILES["picurl"], 'tomwx', random(3, 1), random(8)) || !$upload->save()) {
                cpmsg($upload->errormessage(), '', 'error');
            }

            $picurl = $upload->attach['attachment'];
        }else{
            $picurl = addslashes($_GET["picurl"]);
        }
        
        $insertData = array();
        $insertData['servicer_id']  = $servicer_id;
        $insertData['picurl']       = $picurl;
        $insertData['type']         = 5;
        $insertData['add_time']     = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_photo')->insert($insertData);
        
        cpmsg($Lang['act_success'], $modListUrl."&act=photo&servicer_id=".$_GET['servicer_id'], 'succeed');
    }
    
    $goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_by_id($_GET['goods_id']);
    
    $photoList = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND servicer_id={$servicer_id} AND type = 5 ","ORDER BY id ASC",0,100);
    __create_nav_html();
    showformheader($modFromUrl.'&act=photo&servicer_id='.$servicer_id,'enctype');
    showtableheader(); /*DisM.Taobao.Com*/
    tomshowsetting(true,array('title'=>$Lang['index_photo_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['index_photo_picurl_msg']),"file");
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism _taobao _com*/
    showformfooter(); /*dism��taobao��com*/
    
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['index_photo_picurl'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    foreach ($photoList as $key => $value) {
        echo '<tr>';
        echo '<td><img src="' . tomgetfileurl($value['picurl']) . '" width="60" /></td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=delphoto&id='.$value['id'].'&servicer_id='.$servicer_id.'&formhash='.FORMHASH.'">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter(); /*dism _taobao _com*/
    $multi = multi($count, $pagesize, $page, $modBaseUrl);
    showsubmit('', '', '', '', $multi, false);
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delphoto'){
    
    C::t('#tom_tcdaojia#tom_tcdaojia_photo')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl."&act=photo&servicer_id=".$_GET['servicer_id'], 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'editdengji'){
    $info = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $dengji_id       = intval($_GET['dengji_id'])>0? intval($_GET['dengji_id']):0;
        $dengji_time     = isset($_GET['dengji_time'])? addslashes($_GET['dengji_time']):'';
        $dengji_time     = strtotime($dengji_time);
        
        $dengjiInfo = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_by_id($dengji_id);
        
        $updateData = array();
        if($dengji_time > TIMESTAMP){
            $updateData['dengji_status'] = 1;
        }else{
            $updateData['dengji_status'] = 2;
        }
        $updateData['dengji_id']   = $dengji_id;
        $updateData['dengji_time'] = $dengji_time;
        C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->update($_GET['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        showformheader($modFromUrl.'&act=editdengji&id='.$_GET['id'].'&formhash='.FORMHASH);
        showtableheader(); /*DisM.Taobao.Com*/
        echo '<tr><th colspan="15" class="partition"><font color="#238206">'.$info['name'].'</font>&nbsp;>&nbsp;' . $Lang['edit_dengji_title'] .'</th></tr>';
        
        $dengjiList = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_all_list(""," ORDER BY dsort ASC,id DESC ",0,100);
        $dengjiStr = '<tr class="header"><th>'.$Lang['edit_dengji_msg'].'</th><th></th></tr>';
        $dengjiStr.= '<tr><td width="300"><select style="width: 260px;" name="dengji_id" id="dengji_id">';
        foreach ($dengjiList as $key => $value){
            if($info['vip_id'] == $value['id']){
                $dengjiStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $dengjiStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $dengjiStr.= '</select></td><td></td></tr>';
        echo $dengjiStr;
        
        tomshowsetting(true,array('title'=>$Lang['edit_dengji_time'],'name'=>'dengji_time','value'=>$info['dengji_time'],'msg'=>$Lang['edit_dengji_time_msg']),"calendar");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else{
   
    set_list_url("tom_tcdaojia_admin_index_list");
    
    $csstr = <<<EOF
<style type="text/css">
.tc_content_box li{ list-style-type: none; min-height: 25px; line-height: 25px; }
.tc_content_box li span{ color: #666; }
.tc_content_box_handle li{ list-style-type: none; height: 25px; line-height: 25px; }
.tc_content_box_handle li a{ border: 1px solid #d6d4d3;padding: 3px 10px;color: #6a6d6a; }
.tc_content_box_handle li a:hover{color: #F75000;border: 1px solid #F75000;}
</style>
EOF;
    echo $csstr;
    
    $site_id        = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $servicer_id    = isset($_GET['servicer_id'])? intval($_GET['servicer_id']):0;
    $vip_id         = isset($_GET['vip_id'])? intval($_GET['vip_id']):0;
    $cate_id        = isset($_GET['cate_id'])? intval($_GET['cate_id']):0;
    $area_id        = isset($_GET['area_id'])? intval($_GET['area_id']):0;
    $street_id      = isset($_GET['street_id'])? intval($_GET['street_id']):0;
    $status         = isset($_GET['status'])? intval($_GET['status']):0;
    $jie_status     = isset($_GET['jie_status'])? intval($_GET['jie_status']):0;
    $pay_status     = isset($_GET['pay_status'])? intval($_GET['pay_status']):0;
    $shenhe_status  = isset($_GET['shenhe_status'])? intval($_GET['shenhe_status']):0;
    $type           = isset($_GET['type'])? intval($_GET['type']):0;
    $search         = isset($_GET['search'])? intval($_GET['search']):0;
    $page           = intval($_GET['page'])>0? intval($_GET['page']):1;

    $where = "";
    if($site_id > 0){
        $where.= " AND site_id={$site_id} ";
    }
    if(!empty($servicer_id)){
        $where.= " AND id= {$servicer_id}";
    }
    if(!empty($vip_id)){
        $where.= " AND vip_id= {$vip_id}";
    }
    if($cate_id > 0){
        $where.= " AND (cate_ids LIKE '%|$cate_id|%' )";
    }
    if($area_id > 0 && $street_id <= 0){
        $where.= " AND (area_ids LIKE '%|$area_id|%' )";
    }
    if($street_id > 0){
        $where.= " AND (street_ids LIKE '%|$street_id|%' )";
    }
    if($status == 1){
        $where.= " AND status=1 ";
    }else if($status == 2){
        $where.= " AND status=2 ";
    }
    if($jie_status == 1){
        $where.= " AND jie_status=0 ";
    }else if($jie_status == 2){
        $where.= " AND jie_status=1 ";
    }
    if($pay_status > 0){
        $where.= " AND pay_status = {$pay_status} ";
    }
    if($shenhe_status > 0){
        $where.= " AND shenhe_status={$shenhe_status} ";
    }
    if($type == 1){
        $where.= " AND type=1 ";
    }else if($type == 2){
        $where.= " AND type=2 ";
    }
    
    $sort = " ORDER BY id DESC ";
    $pagesize = 15;
    $start = ($page - 1)*$pagesize;	
    $count       = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_all_count($where);
    $servicerlist = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_all_list("{$where}",$sort,$start,$pagesize);
    
    showtableheader(); /*DisM.Taobao.Com*/
    $Lang['tcdaojia_help_1']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcdaojia_help_1']);
    $Lang['tcdaojia_help_3']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcdaojia_help_3']);
    $Lang['tcdaojia_help_4']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcdaojia_help_4']);
    $Lang['tcdaojia_help_5']  = str_replace("{SITEURL}", $_G['siteurl'], $Lang['tcdaojia_help_5']);
    echo '<tr><th colspan="15" class="partition">' . $Lang['tcdaojia_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li>' . $Lang['tcdaojia_help_1'] . '</li>';
    echo '<li>' . $Lang['tcdaojia_help_3'] . '</li>';
    if($tongchengConfig['open_yun'] == 2){
        echo '<li>' . $Lang['tcdaojia_help_4'] . '</li>';
    }
    if($tongchengConfig['open_yun'] == 3){
        echo '<li>' . $Lang['tcdaojia_help_5'] . '</li>';
    }
    echo '</ul></td></tr>';
    showtablefooter(); /*dism _taobao _com*/
    
    $modBasePageUrl = $modBaseUrl."&site_id={$site_id}&search={$search}&vip_id={$vip_id}&cate_id={$cate_id}&area_id={$area_id}&street_id={$street_id}&pay_status={$pay_status}&status={$status}&shenhe_status={$shenhe_status}&type={$type}";
    
    showformheader($modFromUrl."&search={$search}&formhash=".FORMHASH);
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['search'] . '<a href="'.$modBaseUrl.'&search=1"><font color="#F90B0B">('.$Lang['search_gaoji'].')</font></a></th></tr>';
    
    $selected_1 = '';
    if($site_id == 1){
        $selected_1 = 'selected';
    }
    $sitesList = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_all_list(" "," ORDER BY id DESC ",0,1000);
    $sitesStr = '<tr><td width="100" align="right"><b>'.$Lang['sites_title'].'</b></td>';
    $sitesStr.= '<td width="100"><select style="width: 260px;" name="site_id" id="site_id">';
    $sitesStr.=  '<option value="0">'.$Lang['sites_all'].'</option>';
    $sitesStr.=  '<option value="1" '.$selected_1.'>'.$Lang['sites_one'].'</option>';
    foreach ($sitesList as $key => $value){
        if($site_id == $value['id']){
            $sitesStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $sitesStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $sitesStr.= '</select></td></tr>';
    echo $sitesStr;
    
    $cateList = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list("AND pid = 0 "," ORDER BY csort ASC, id DESC ",0,10000);
    $cateStr = '<tr><td width="100" align="right"><b>'.$Lang['goods_cate_id'].'</b></td>';
    $cateStr.= '<td><select style="width: 260px;" name="cate_id" id="cate_id">';
    $cateStr.=  '<option value="0">'.$Lang['select_all'].'</option>';
    foreach($cateList as $key => $value){
        if($cate_id == $value['id']){
            $cateStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
        }else{
            $cateStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
    }
    $cateStr.= '</select></td></tr>';
    echo $cateStr;
    if($search == 1){
        echo '<tr><td width="100" align="right"><b>'.$Lang['servicer_id'].'</b></td><td width="100"><input type="text" style="width: 260px;" name="servicer_id" value="'.$servicer_id.'"></td></tr>';
        
        $areaList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($__CityInfo['id']);
        $areaStr.= '<tr><td width="100" align="right"><b>'.$Lang['needs_search_diqu'].'</b></td>';
        $areaStr.= '<td ><select style="width: 130px;" name="area_id" id="area_id" onChange="getStreet();">';
        $areaStr.=  '<option value="0">'.$Lang['select_all'].'</option>';
        foreach ($areaList as $key => $value){
            if($area_id == $value['id']){
                $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $areaStr.= '</select>';

        $streetList = C::t('#tom_tongcheng#tom_tongcheng_district')->fetch_all_by_upid($area_id);
        $areaStr.= '<select style="width: 130px;" name="street_id" id="street_id">';
        $areaStr.=  '<option value="0">'.$Lang['select_all'].'</option>';
        foreach ($streetList as $key => $value){
            if($street_id == $value['id']){
                $areaStr.=  '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
            }else{
                $areaStr.=  '<option value="'.$value['id'].'">'.$value['name'].'</option>';
            }
        }
        $areaStr.= '</select></td></tr>';
        echo $areaStr;
        
        echo '<tr><td width="100" align="right"><b>' . $Lang['index_type'] . '</b></td><td><select style="width: 260px;" name="type" >';
        echo '<option value="0">'.$Lang['quanbu'].'</option>';
        $type1_selected = $type2_selected = "";
        if(1 == $type){
            $type1_selected = "selected";
        }
        if(2 == $type){
            $type2_selected = "selected";
        }
        echo '<option value="1" '.$type1_selected.'>'.$Lang['index_type_msg_1'].'</option>';
        echo '<option value="2" '.$type2_selected.'>'.$Lang['index_type_msg_2'].'</option>';
        echo '</select></td></tr>';
        
        echo '<tr><td width="100" align="right"><b>' . $Lang['index_jie_status'] . '</b></td><td><select style="width: 260px;" name="jie_status" >';
        echo '<option value="0">'.$Lang['index_jie_status'].'</option>';
        $jiestatus0_selected = $jiestatus1_selected = "";
        if(1 == $jie_status){
            $jiestatus0_selected = "selected";
        }
        if(2 == $jie_status){
            $jiestatus1_selected = "selected";
        }
        echo '<option value="1" '.$jiestatus0_selected.'>'.$Lang['index_jie_status_0'].'</option>';
        echo '<option value="2" '.$jiestatus1_selected.'>'.$Lang['index_jie_status_1'].'</option>';
        echo '</select></td></tr>';
        
        $pay_status_1 = $pay_status_2 = '';
        if($pay_status == 1){
            $pay_status_1 = 'selected';
        }else if($pay_status == 2){
            $pay_status_2 = 'selected';
        }
        $payStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['pay_status'].'</b></td>';
        $payStatusStr.= '<td><select style="width: 260px;" name="pay_status" id="pay_status">';
        $payStatusStr.=  '<option value="0">'.$Lang['select_all'].'</option>';
        $payStatusStr.=  '<option value="1" '.$pay_status_1.'>'.$Lang['pay_status_1'].'</option>';
        $payStatusStr.=  '<option value="2" '.$pay_status_2.'>'.$Lang['pay_status_2'].'</option>';
        $payStatusStr.= '</select></td></tr>';
        echo $payStatusStr;
    }
    
    $vipList = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_all_list(""," ORDER BY id DESC ",0,20);
    echo '<tr><td width="100" align="right"><b>' . $Lang['vip_id'] . '</b></td><td><select  style="width: 260px;" name="vip_id" >';
    echo '<option value="0">'.$Lang['edit_vip_id_0'].'</option>';
    if(is_array($vipList) && !empty($vipList)){
        foreach ($vipList as $key => $value){
            if($value['id'] == $vip_id){
                echo  '<option value='.$value['id'].' selected>'.$value['name'].'</option>';
            }else{
                echo  '<option value='.$value['id'].'>'.$value['name'].'</option>';
            }
        }
    }
    echo '</select></td></tr>';
    
    $shenhe_status_1 = $shenhe_status_2 = $shenhe_status_3 = '';
    if($shenhe_status == 1){
        $shenhe_status_1 = 'selected';
    }else if($shenhe_status == 2){
        $shenhe_status_2 = 'selected';
    }else if($shenhe_status == 3){
        $shenhe_status_3 = 'selected';
    }
    $shenheStatusStr = '<tr><td width="100" align="right"><b>'.$Lang['index_shenhe_status'].'</b></td>';
    $shenheStatusStr.= '<td><select style="width: 260px;" name="shenhe_status" id="shenhe_status">';
    $shenheStatusStr.=  '<option value="0">'.$Lang['index_shenhe_status'].'</option>';
    $shenheStatusStr.=  '<option value="1" '.$shenhe_status_1.'>'.$Lang['index_shenhe_status_1'].'</option>';
    $shenheStatusStr.=  '<option value="2" '.$shenhe_status_2.'>'.$Lang['index_shenhe_status_2'].'</option>';
    $shenheStatusStr.=  '<option value="3" '.$shenhe_status_3.'>'.$Lang['index_shenhe_status_3'].'</option>';
    $shenheStatusStr.= '</select></td></tr>';
    echo $shenheStatusStr;
    echo '<tr><td width="100" align="right"><b>' . $Lang['index_status'] . '</b></td><td><select style="width: 260px;" name="status" >';
    echo '<option value="0">'.$Lang['index_status'].'</option>';
    $status1_selected = $status2_selected = "";
    if(1 == $status){
        $status1_selected = "selected";
    }
    if(2 == $status){
        $status2_selected = "selected";
    }
    echo '<option value="1" '.$status1_selected.'>'.$Lang['index_status_1'].'</option>';
    echo '<option value="2" '.$status2_selected.'>'.$Lang['index_status_2'].'</option>';
    echo '</select></td></tr>';
    
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism _taobao _com*/
    showformfooter(); /*dism��taobao��com*/
    
    __create_nav_html();
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['sites_title'] . '</th>';
    echo '<th>' .$Lang['index_servicer_id'] . '</th>';
    echo '<th>' .$Lang['index_picurl'] . '</th>';
    echo '<th>' . $Lang['index_servicerinfo'] . '</th>';
    echo '<th>' . $Lang['index_xm'] . '</th>';
    echo '<th>' . $Lang['index_tel'] . '</th>';
    echo '<th>' . $Lang['index_vip_id'] . '</th>';
    if($tcdaojiaConfig['open_ruzhu_pay_money'] == 1 ){
        echo '<th>' . $Lang['index_dengji_id'] . '</th>';
    }
    echo '<th>' . $Lang['index_jie_num'] . '</th>';
    echo '<th>' . $Lang['index_status_0'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($servicerlist as $key => $value) {
        
        $servicerlist[$key] = $value;
        
        $shenhe_status = '';
        if($value['shenhe_status'] == 1){
            $shenhe_status = $Lang['indexshenhe_ok'];
        }else if($value['shenhe_status'] == 2){
            $shenhe_status = $Lang['indexshenhe_ing'];
        }else if($value['shenhe_status'] == 3){
            $shenhe_status = $Lang['indexshenhe_no'];
        }else{
            $shenhe_status = '-';
        }
        $status = '';
        if($value['status'] == 1){
            $status = $Lang['status_yes'];
        }else{
            $status = $Lang['status_no'];
        }
        
        $siteInfo          = C::t('#tom_tongcheng#tom_tongcheng_sites')->fetch_by_id($value['site_id']);
        $userInfo          = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
        $vipInfo           = C::t('#tom_tcdaojia#tom_tcdaojia_vip')->fetch_by_id($value['vip_id']); 
        $dengjiInfo         = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_by_id($value['dengji_id']);
        
        $servicerphotoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list("AND servicer_id = {$value['id']} AND type = 3","",0,1);
        if(is_array($servicerphotoInfoTmp) && !empty($servicerphotoInfoTmp[0])){
            $picurl = $servicerphotoInfoTmp[0]['picurlTmp'];
        }
        
        echo '<tr>';
        if($value['site_id'] > 1){
            echo '<td>' . $siteInfo['name'] . '</td>';
        }else{
            echo '<td>' . $Lang['sites_one'] . '</td>';
        }
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><img src="'.$picurl.'" width="40" /></td>';
        echo '<td><div class="tc_content_box"><ul>';
        if($value['type'] == 1 ){
            echo '<li><b><font color="#238206">'.$Lang['index_type_1'].'</font>' . '</b></li>';
        }elseif($value['type'] == 2 ){
            echo '<li><b><font color="#0894fb">'.$Lang['index_type_2'].'</font>' . '</b></li>';
        }
        echo '<li>' . $value['name'].'</li>';
        echo '<li>' . $userInfo['nickname'].'(<font color="#fd0d0d">UID:'.$value['user_id'].'</font>)</li>';
        echo '</ul></div></td>'; 
        echo '<td style="max-width:300px;">' . $value['xm'].'</td>';
        echo '<td style="max-width:300px;">' . $value['tel'].'</td>';
        if($vipInfo['id'] > 0){
            echo '<td style="max-width:300px;">' . $vipInfo['name'].'</td>';
        }else{
            echo '<td style="max-width:300px;">' . $Lang['edit_vip_id_0'].'</td>';
        }
        if($tcdaojiaConfig['open_ruzhu_pay_money'] == 1 ){
            if($dengjiInfo['id'] > 0){
                echo '<td>' . $dengjiInfo['name'] . '<br/><font color="#f70404">('.dgmdate($value['dengji_time'], 'Y-m-d H:i',$tomSysOffset).$Lang['index_dengji_id_msg'] . ')</font></td>';
            }else{
                echo '<td><font color="#fd0d0d">' . $Lang['index_dengji_id_0'] . '</font></td>';
            }
        }
        echo '<td style="max-width:300px;">' . $value['jie_num'].'</td>';
        echo '<td><div class="tc_content_box"><ul>';
        if($value['top_status'] == 1){
            echo '<p style="line-height:20px;">' . $Lang['top_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['top_status_1'].'</font> <font color="#f70404">('.dgmdate($value['top_time'], 'Y-m-d H:i',$tomSysOffset).')</font></p>';
        }else{
            echo '<p style="line-height:20px;">' . $Lang['top_status'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['top_status_0'].'</font></p>';
        }
        $sheheBtnStr = '&nbsp;(&nbsp;<a href="'.$modBaseUrl.'&act=shenheok&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_ok']. '</a>&nbsp;|&nbsp;<a href="'.$modBaseUrl.'&act=shenheno&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['shenhe_no']. '</a>)';
        if($value['shenhe_status'] == 1 ){
            echo '<p style="line-height:20px;">'.$Lang['index_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#0a9409">' . $Lang['index_shenhe_status_1'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 2){
            echo '<p style="line-height:20px;">'.$Lang['index_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['index_shenhe_status_2'] . '</font>'.$sheheBtnStr.'</li>';
        }else if($value['shenhe_status'] == 3){
            echo '<p style="line-height:20px;">'.$Lang['index_shenhe_status'].'&nbsp;:&nbsp;</b><font color="#f70404">' . $Lang['index_shenhe_status_3'] . '</font>'.$sheheBtnStr.'</li>';
        }
        if($value['status'] == 1 ){
            $statusBtnStr = '(&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['status_no']. '</a>)';
        }else{
            $statusBtnStr = '(&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['status_yes']. '</a>)';
        }
        if($value['status'] == 1 ){
            echo '<p style="line-height:20px;">'.$Lang['status_show'].'&nbsp;:&nbsp;<font color="#0a9409">' . $Lang['status_yes'] . '</font>'.$statusBtnStr.'</p>';
        }else{
            echo '<p style="line-height:20px;">'.$Lang['status_show'].'&nbsp;:&nbsp;<font color="#f70404">' . $Lang['status_no'] . '</font>'.$statusBtnStr.'</p>';
        }
        if($value['jie_status'] == 1 ){
            $jiestatusBtnStr = '(&nbsp;<a href="'.$modBaseUrl.'&act=hide_jiestatus&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['jie_status_no']. '</a>)';
        }else{
            $jiestatusBtnStr = '(&nbsp;<a href="'.$modBaseUrl.'&act=show_jiestatus&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['jie_status_yes']. '</a>)';
        }
        if($value['jie_status'] == 1 ){
            echo '<p style="line-height:20px;">'.$Lang['jie_status_show'].'&nbsp;:&nbsp;<font color="#0a9409">' . $Lang['jie_status_yes'] . '</font>'.$jiestatusBtnStr.'</p>';
        }else{
            echo '<p style="line-height:20px;">'.$Lang['jie_status_show'].'&nbsp;:&nbsp;<font color="#f70404">' . $Lang['jie_status_no'] . '</font>'.$jiestatusBtnStr.'</p>';
        }
        if($value['pay_status'] == 1){
            echo '<p style="line-height:20px;">' . $Lang['pay_status'].$Lang['fenghao']. '<font color="#f70404">'.$Lang['pay_status_1'].'</font><a href="javascript:void(0);" onclick="pay_confirm(\''.$modBaseUrl.'&act=pay_ok&id='.$value['id'].'&formhash='.FORMHASH.'\');">('.$Lang['pay_status_2'].')</a></p>';
        }else if($value['pay_status'] == 2){
            echo '<p style="line-height:20px;">' . $Lang['pay_status'].$Lang['fenghao']. '<font color="#0a9409">'.$Lang['pay_status_2'].'</font></p>';
        }
        echo '</ul></div></td>';
        echo '<td style="line-height: 30px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_edit']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        echo '<a href="'.$modBaseUrl.'&act=editvip&servicer_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_vip_title'] . '</a><br/>';
        if($tcdaojiaConfig['open_ruzhu_pay_money'] == 1 ){
            echo '<a href="'.$modBaseUrl.'&act=editdengji&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_dengji_title'] . '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        }
        echo '<a href="'.$modBaseUrl.'&act=photo&servicer_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['index_photo']. '</a><br/>';
        echo '<a href="'.$modBaseUrl.'&act=edittop&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_top_title']. '</a>&nbsp;&nbsp;|&nbsp;&nbsp;';
        if($value['type'] == 2){
            echo '<a href="'.$adminBaseUrl.'&tmod=team&servicer_id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['edit_team_title']. '</a><br/>';
        }
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*dism _taobao _com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
}

$jsstr = <<<EOF
<script type="text/javascript">
function getCity(){
  var site_id = jq("#site_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcdaojia:ajax",
        data: "act=admin_area&site="+site_id,
        dataType : "json",
        success: function(json){
            var areaHtml = '<option value="0">{$Lang['select_all']}</option>';
            jq.each(json,function(k,v){
                areaHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            jq("#area_id").html(areaHtml);
            jq("#area_id").show();
        }
    });
}
function getStreet(){
  var area_id = jq("#area_id").val();
  jq.ajax({
        type: "GET",
        url: "plugin.php?id=tom_tcdaojia:ajax",
        data: "act=admin_street&area_id="+area_id,
        dataType : "json",
        success: function(json){
            var streetHtml = '<option value="0">{$Lang['select_all']}</option>';
            jq.each(json,function(k,v){
                streetHtml+= '<option value="'+v.id+'">'+v.name+'</option>';
            })
            console.log(streetHtml);
            jq("#street_id").html(streetHtml);
            jq("#street_id").show();
        }
    });
}
</script>
EOF;
echo $jsstr;

function __get_post_data($infoArr = array()){
    $data = array();
    
    $type                    = isset($_GET['type'])? intval($_GET['type']):0;
    $site_id                 = isset($_GET['site_id'])? intval($_GET['site_id']):0;
    $user_id                 = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $name                    = isset($_GET['name'])? addslashes($_GET['name']):'';
    $xm                      = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                     = isset($_GET['tel'])? daddslashes($_GET['tel']):'';
    $start_time              = isset($_GET['start_time'])? daddslashes($_GET['start_time']):'';
    $end_time                = isset($_GET['end_time'])? daddslashes($_GET['end_time']):'';
    $address                 = isset($_GET['address'])? addslashes($_GET['address']):'';
    $longitude               = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $latitude                = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $content                 = isset($_GET['content'])? addslashes($_GET['content']):'';
    //$jie_num                 = isset($_GET['jie_num'])? addslashes($_GET['jie_num']):'';
    $virtual_clicks          = isset($_GET['virtual_clicks'])? intval($_GET['virtual_clicks']):0;
    $paixu                   = isset($_GET['paixu'])? addslashes($_GET['paixu']):'';
    
    if(is_array($_GET['cate_ids']) && !empty($_GET['cate_ids'])){
        $cate_ids = implode('|', $_GET['cate_ids']);
    }
    
    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl             = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl             = tomuploadFile("picurl",$infoArr['picurl']);
    }
    
    $servicerInfo  = array();
    
    $servicerInfo['type']               = $type;
    $servicerInfo['site_id']            = $site_id;
    $servicerInfo['user_id']            = $user_id;
    $servicerInfo['name']               = $name;
    $servicerInfo['cate_ids']           = "|".$cate_ids."|";
    $servicerInfo['xm']                 = $xm;
    $servicerInfo['tel']                = $tel;
    $servicerInfo['start_time']         = $start_time;
    $servicerInfo['end_time']           = $end_time;
    $servicerInfo['address']            = $address;
    $servicerInfo['longitude']          = $longitude;
    $servicerInfo['latitude']           = $latitude;
    $servicerInfo['content']            = $content;
    //$servicerInfo['jie_num']            = $jie_num;
    $servicerInfo['virtual_clicks']     = $virtual_clicks;
    $servicerInfo['paixu']              = $paixu;
    $data['picurl']                     = $picurl;
    $data['servicerInfo']               = $servicerInfo;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang,$tcdaojiaConfig;
    $options = array(
        'site_id'           => 1,
        'type'              => 2,
        'user_id'           => '',
        'name'              => '',
        'cate_ids'          => '',
        'xm'                => '',
        'tel'               => '',
        'start_time'        => '',
        'end_time'          => '',
        'cate_id'           => 0,
        'address'           => '',
        'longitude'         => '',
        'latitude'          => '',
        'content'           => '',
        'jie_num'           => 0,
        'virtual_clicks'    => '',
        'paixu'             => '',
        'picurl'            => '',
    );
    $options = array_merge($options, $infoArr);
    
    $picurl = '';
    if($options['id'] > 0){
        $photoListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND servicer_id={$options['id']} AND type = 3 "," ORDER BY type DESC,id ASC ",0,1);
        if(is_array($photoListTmp) && !empty($photoListTmp)){
            foreach($photoListTmp as $key => $value){
                $picurl = $value['picurl'];
            }
        }
    }
    
    $type_item = array(1=>$Lang['index_type_1'],2=>$Lang['index_type_2']);
    tomshowsetting(true,array('title'=>$Lang['index_type'],'name'=>'type','value'=>$options['type'],'msg'=>$Lang['index_type_msg'],'item'=>$type_item),"radio");
    tomshowsetting(true,array('title'=>$Lang['index_site_id'],'name'=>'site_id','value'=>$options['site_id'],'msg'=>$Lang['index_site_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['index_user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['index_name_msg']),"input");
    
    $cate_ids_str = $options['cate_ids'];
    $cate_ids_str = substr($cate_ids_str, 1, -1);
    $cate_ids_arr = array();
    if(!empty($options['cate_ids'])){
        $cate_ids_arr = explode('|', $cate_ids_str);
    }
    $cateList = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid = 0 "," ORDER BY csort ASC,id DESC ",0,1000);
    $cateStr  = '<tr class="header"><th>'.$Lang['daDao_cates'].'</th><th></th></tr>';
    $cateStr.= '<tr><td width="800" style="line-height: 30px;">';
    foreach ($cateList as $key => $value){
        if(in_array($value['id'], $cate_ids_arr)){
            $cateStr.=  '<label><input name="cate_ids[]" type="checkbox" value="'.$value['id'].'" checked />'.$value['name'].'</label>&nbsp;&nbsp;';
        }else{
            $cateStr.=  '<label><input name="cate_ids[]" type="checkbox" value="'.$value['id'].'" />'.$value['name'].'</label>&nbsp;&nbsp;';
        }
    }
    $cateStr.= '</td><td></td></tr>';
    echo $cateStr;
    
    tomshowsetting(true,array('title'=>$Lang['index_xm'],'name'=>'xm','value'=>$options['xm'],'msg'=>$Lang['index_xm_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_tel'],'name'=>'tel','value'=>$options['tel'],'msg'=>$Lang['index_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_start_time'],'name'=>'start_time','value'=>$options['start_time'],'msg'=>$Lang['index_start_time_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_end_time'],'name'=>'end_time','value'=>$options['end_time'],'msg'=>$Lang['index_end_time_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_picurl'],'name'=>'picurl','value'=>$picurl,'msg'=>$Lang['index_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['index_address'],'name'=>'address','value'=>$options['address'],'msg'=>$Lang['index_address_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_latitude'],'name'=>'latitude','value'=>$options['latitude'],'msg'=>$Lang['index_latitude_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_longitude'],'name'=>'longitude','value'=>$options['longitude'],'msg'=>$Lang['index_longitude_msg']),"input");
    //tomshowsetting(true,array('title'=>$Lang['index_jie_num'],'name'=>'jie_num','value'=>$options['jie_num'],'msg'=>$Lang['index_jie_num_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_virtual_clicks'],'name'=>'virtual_clicks','value'=>$options['virtual_clicks'],'msg'=>$Lang['index_virtual_clicks_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_paixu'],'name'=>'paixu','value'=>$options['paixu'],'msg'=>$Lang['index_paixu_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['index_content'],'name'=>'content','value'=>$options['content'],'msg'=>$Lang['index_content_msg']),"text");
    
    return;
}

$jsstr = <<<EOF
<script type="text/javascript">
function _confirm(url, msg){
  var r = confirm(msg)
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
  
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
  
function pay_confirm(url){
  var r = confirm("{$Lang['makesure_pay_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}

</script>
EOF;
echo $jsstr;

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['index_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['index_edit'],"",true);
    }else{
        tomshownavli($Lang['index_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['index_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['servicer_xieyi_title'],$adminBaseUrl.'&tmod=common',false);
    }
    tomshownavfooter();
}