<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=option&goods_id='.$_GET['goods_id'];
$modListUrl = $adminListUrl.'&tmod=option&goods_id='.$_GET['goods_id'];
$modFromUrl = $adminFromUrl.'&tmod=option&goods_id='.$_GET['goods_id'];
    
$goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($_GET['goods_id']);

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $data = __get_post_data();
        
        $insertData = array();
        $insertData = $data;
        $insertData['add_time'] = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->insert($insertData);
        $option_id = C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->insert_id();
        
        updatePrice($option_id);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $optionInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $data = __get_post_data($optionInfo);
        
        $updateData = array();
        $updateData = $data;
        C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->update($optionInfo['id'],$updateData);
        updatePrice($optionInfo['id']);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html($optionInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $optionInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->fetch_by_id($_GET['id']);
    
    C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->delete_by_id($_GET['id']);
    
    $optionListTmp = C::t("#tom_tcdaojia#tom_tcdaojia_goods_option")->fetch_all_list(" AND goods_id = {$optionInfo['goods_id']} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
        $show_price  = $show_vip_price = 0;
        foreach($optionListTmp as $key => $value){
            if($show_price == 0){
                $show_price       = $value['price'];
                $show_vip_price   = $value['vip_price'];
            }else if($value['price'] < $show_price){
                $show_price       = $value['price'];
                $show_vip_price   = $value['vip_price'];
            }
        }
        if($show_price > 0){
            $updateData = array();
            $updateData['price']           = $show_price;
            $updateData['vip_price']       = $show_vip_price;
            $updateData['part1']           = TIMESTAMP;
            C::t("#tom_tcdaojia#tom_tcdaojia_goods")->update($optionInfo['goods_id'],$updateData);
        }
        $goodsInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($optionInfo['goods_id']);
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else{
    
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr><th colspan="15" class="partition">' . $goodsInfo['title'] .'&nbsp;&nbsp;&gt;&nbsp;&nbsp;'.$Lang['option_list_title']. '</th></tr>';
    showtablefooter(); /*dism _taobao _com*/
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $optionList = C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->fetch_all_list(" AND goods_id = {$goodsInfo['id']} "," ORDER BY osort ASC,id ASC ",$start,$pagesize);
    __create_nav_html();
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['option_name'] . '</th>';
    echo '<th>' . $Lang['option_price'] . '</th>';
    echo '<th>' . $Lang['option_vip_price'] . '</th>';
    echo '<th>' . $Lang['goods_sale_num'] . '</th>';
    echo '<th>' . $Lang['paixu'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($optionList as $key => $value) {
        
        echo '<tr>';
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['price'] . '</td>';
        echo '<td>' . $value['vip_price'] . '</td>';
        echo '<td><font color="#238206">' . $value['sale_num'] . '</font></td>';
        echo '<td>' . $value['osort'] . '</td>';
        echo '<td>';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['option_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); /*dism _taobao _com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $goods_id           = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $price              = isset($_GET['price'])? floatval($_GET['price']):0.00;
    $vip_price          = isset($_GET['vip_price'])? floatval($_GET['vip_price']):0.00;
    $osort              = isset($_GET['osort'])? intval($_GET['osort']):10;

    $data['goods_id']   = $goods_id;
    $data['name']       = $name;
    $data['price']      = $price;
    $data['vip_price']  = $vip_price;
    $data['osort']      = $osort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'              => '',
        'price'             => '',
        'vip_price'         => '',
        'osort'             => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['option_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['option_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_price'],'name'=>'price','value'=>$options['price'],'msg'=>$Lang['option_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['option_vip_price'],'name'=>'vip_price','value'=>$options['vip_price'],'msg'=>$Lang['option_vip_price_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['paixu'],'name'=>'osort','value'=>$options['osort'],'msg'=>$Lang['option_osort_msg']),"input");
    
    return;
}

function updatePrice($option_id){
    global $Lang;
    $optionInfo = C::t("#tom_tcdaojia#tom_tcdaojia_goods_option")->fetch_by_id($option_id);
  
    $optionListTmp = C::t("#tom_tcdaojia#tom_tcdaojia_goods_option")->fetch_all_list(" AND goods_id = {$optionInfo['goods_id']} ", 'ORDER BY id DESC', 0, 100);
    if(is_array($optionListTmp) && !empty($optionListTmp)){
       $show_price = $show_vip_price = 0;
        foreach($optionListTmp as $key => $value){
            if($show_price == 0){
                $show_price         = $value['price'];
                $show_vip_price     = $value['vip_price'];
            }else if($value['price'] < $show_price){
                $show_price     = $value['price'];
                $show_vip_price     = $value['vip_price'];
            }
        }
        
        $updateData = array();
        $updateData['price']               = $show_price;
        $updateData['vip_price']           = $show_vip_price;
        $updateData['part1']               = TIMESTAMP;
        C::t("#tom_tcdaojia#tom_tcdaojia_goods")->update($optionInfo['goods_id'],$updateData);
            
        $goodsInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($optionInfo['goods_id']);
    }
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['option_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['option_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['option_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['option_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['option_edit'],"",true);
    }else{
        tomshownavli($Lang['option_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['option_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}