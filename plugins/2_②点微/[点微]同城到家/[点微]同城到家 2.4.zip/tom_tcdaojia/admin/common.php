<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=common'; 
$modListUrl = $adminListUrl.'&tmod=common';
$modFromUrl = $adminFromUrl.'&tmod=common';

$commonInfo = C::t('#tom_tcdaojia#tom_tcdaojia_common')->fetch_by_id(1);
if(!$commonInfo){
    $insertData = array();
    $insertData['id']      = 1;
    C::t('#tom_tcdaojia#tom_tcdaojia_common')->insert($insertData);
}
if(submitcheck('submit')){
    $updateData = array();
    $updateData = __get_post_data($commonInfo);
    C::t('#tom_tcdaojia#tom_tcdaojia_common')->update(1,$updateData);
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    tomloadcalendarjs();
    loadeditorjs();
    __create_nav_html();
    showformheader($modFromUrl,'enctype');
    showtableheader(); /*DisM.Taobao.Com*/

    __create_info_html($commonInfo);
    showsubmit('submit', 'submit');
    showtablefooter(); /*dism _taobao _com*/
    showformfooter(); /*dism��taobao��com*/
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $servicer_xieyi   = isset($_GET['servicer_xieyi'])? addslashes($_GET['servicer_xieyi']):'';
    $needs_xieyi      = isset($_GET['needs_xieyi'])? addslashes($_GET['needs_xieyi']):'';
  
    $data['servicer_xieyi']   = $servicer_xieyi;
    $data['needs_xieyi']      = $needs_xieyi;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'servicer_xieyi'      => '',
        'needs_xieyi'         => '',
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['servicer_xieyi_title'],'name'=>'servicer_xieyi','value'=>$options['servicer_xieyi'],'msg'=>''),"text");
    //tomshowsetting(true,array('title'=>$Lang['needs_xieyi_title'],'name'=>'needs_xieyi','value'=>$options['needs_xieyi'],'msg'=>''),"text");
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    tomshownavli($Lang['common_title'],"",true);
    tomshownavfooter();
}