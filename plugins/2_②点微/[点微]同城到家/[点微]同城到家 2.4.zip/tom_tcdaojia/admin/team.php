<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=team&servicer_id='.$_GET['servicer_id'];
$modListUrl = $adminListUrl.'&tmod=team&servicer_id='.$_GET['servicer_id'];
$modFromUrl = $adminFromUrl.'&tmod=team&servicer_id='.$_GET['servicer_id'];
    
$servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($_GET['servicer_id']);

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        
        $data = __get_post_data();
        
        $insertData = array();
        $insertData = $data;
        C::t('#tom_tcdaojia#tom_tcdaojia_team')->insert($insertData);
        $team_id = C::t('#tom_tcdaojia#tom_tcdaojia_team')->insert_id();
        
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $teamInfo = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $data = __get_post_data($teamInfo);
        
        $updateData = array();
        $updateData = $data;
        C::t('#tom_tcdaojia#tom_tcdaojia_team')->update($teamInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html($teamInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    $teamInfo = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_by_id($_GET['id']);
    
    C::t('#tom_tcdaojia#tom_tcdaojia_team')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'show'){
    
   
    DB::query("UPDATE ".DB::table('tom_tcdaojia_team')." SET is_hidden=0 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'hide'){
    
    DB::query("UPDATE ".DB::table('tom_tcdaojia_team')." SET is_hidden=1 WHERE id='{$_GET['id']}' ", 'UNBUFFERED');
    
    cpmsg($Lang['act_success'],$modListUrl, 'succeed');
    
}else{
    
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr><th colspan="15" class="partition">' . $servicerInfo['name'] .'&nbsp;&nbsp;&gt;&nbsp;&nbsp;'.$Lang['team_list_title']. '</th></tr>';
    showtablefooter(); /*dism _taobao _com*/
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $teamList = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_all_list(" AND servicer_id = {$servicerInfo['id']} "," ORDER BY tsort ASC,id ASC ",$start,$pagesize);
    __create_nav_html();
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr class="header">';
    echo '<th>' . $Lang['team_id'] . '</th>';
    echo '<th>' . $Lang['team_user_id'] . '</th>';
    echo '<th>' . $Lang['team_picurl'] . '</th>';
    echo '<th>' . $Lang['team_xm'] . '</th>';
    echo '<th>' . $Lang['team_tel'] . '</th>';
    echo '<th>' . $Lang['team_desc'] . '</th>';
    echo '<th>' . $Lang['team_is_hidden'] . '</th>';
    echo '<th>' . $Lang['team_tsort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($teamList as $key => $value) {
        
        if(!preg_match('/^http/', $value['picurl'])){
            if(strpos($value['picurl'], 'source/plugin/') === false){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $_G['siteurl'].$value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td>' . $value['user_id'] . '</td>';
        echo '<td>' . '<img style="height:40px;width:40px;" src="' .$picurl. '">' . '</td>';
        echo '<td>' . $value['xm'] . '</td>';
        echo '<td>' . $value['tel'] . '</td>';
        echo '<td>' . $value['desc'] . '</td>';
        echo '<td><div class="tc_content_box"><ul>';
        if($value['is_hidden'] == 0 ){
            $hiddenBtnStr = '(&nbsp;<a href="'.$modBaseUrl.'&act=hide&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['team_is_hidden_1']. '</a>)';
        }else if($value['is_hidden'] == 1){
            $hiddenBtnStr = '(&nbsp;<a href="'.$modBaseUrl.'&act=show&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['team_is_hidden_0']. '</a>)';
        }
        if($value['is_hidden'] == 0 ){
            echo '<p style="line-height:20px;">'.$Lang['team_is_hidden_title'].'&nbsp;:&nbsp;<font color="#0a9409">' . $Lang['team_is_hidden_0'] . '</font>'.$hiddenBtnStr.'</p>';
        }else if($value['is_hidden'] == 1 ){
            echo '<p style="line-height:20px;">'.$Lang['team_is_hidden_title'].'&nbsp;:&nbsp;<font color="#f70404">' . $Lang['team_is_hidden_1'] . '</font>'.$hiddenBtnStr.'</p>';
        }
        echo '</ul></div></td>';
        echo '<td>' . $value['tsort'] . '</td>';
        echo '<td style="line-height: 30px;">';
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['team_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $i++;
    }
    showtablefooter(); /*dism _taobao _com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $servicer_id        = isset($_GET['servicer_id'])? intval($_GET['servicer_id']):0;
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $xm                 = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $desc               = isset($_GET['desc'])? addslashes($_GET['desc']):'';
    $tsort              = isset($_GET['tsort'])? intval($_GET['tsort']):10;
    
    $picurl     = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }

    $data['servicer_id']  = $servicer_id;
    $data['user_id']      = $user_id;
    $data['xm']           = $xm;
    $data['tel']          = $tel;
    $data['desc']         = $desc;
    $data['picurl']       = $picurl;
    $data['tsort']        = $tsort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'user_id'           => '',
        'xm'                => '',
        'tel'               => '',
        'desc'              => '',
        'tsort'             => '',
        'picurl'            => '',
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['team_user_id'],'name'=>'user_id','value'=>$options['user_id'],'msg'=>$Lang['team_user_id_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['team_xm'],'name'=>'xm','value'=>$options['xm'],'msg'=>$Lang['team_xm_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['team_tel'],'name'=>'tel','value'=>$options['tel'],'msg'=>$Lang['team_tel_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['team_desc'],'name'=>'desc','value'=>$options['desc'],'msg'=>$Lang['team_desc_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['team_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['team_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['team_tsort'],'name'=>'tsort','value'=>$options['tsort'],'msg'=>$Lang['team_tsort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['team_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['team_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['team_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['team_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['team_edit'],"",true);
    }else{
        tomshownavli($Lang['team_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['team_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}