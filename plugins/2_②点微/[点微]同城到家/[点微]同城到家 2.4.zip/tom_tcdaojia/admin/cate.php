<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$modBaseUrl = $adminBaseUrl.'&tmod=cate';
$modListUrl = $adminListUrl.'&tmod=cate';
$modFromUrl = $adminFromUrl.'&tmod=cate';

if($_GET['act'] == 'add'){
    if(submitcheck('submit')){
        $insertData = array();
        $insertData = __get_post_data();
        C::t('#tom_tcdaojia#tom_tcdaojia_cate')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=add','enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html();
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else if($_GET['act'] == 'addchild'){
    $pid       = isset($_GET['pid'])? intval($_GET['pid']):0;
    if(submitcheck('submit')){
        
        $name        = isset($_GET['name'])? addslashes($_GET['name']):'';
        $csort       = isset($_GET['csort'])? intval($_GET['csort']):10;
        
        $picurl      = tomuploadFile("picurl");
        
        $insertData = array();
        $insertData['name']         = $name;
        $insertData['picurl']       = $picurl;
        $insertData['csort']        = $csort;
        $insertData['pid']          = $pid;
        C::t('#tom_tcdaojia#tom_tcdaojia_cate')->insert($insertData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=addchild&pid='.$pid,'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        tomshowsetting(true,array('title'=>$Lang['cate_name'],'name'=>'name','value'=>'','msg'=>$Lang['cate_name_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['cate_picurl'],'name'=>'picurl','value'=>'','msg'=>$Lang['cate_picurl_msg']),"file");
        tomshowsetting(true,array('title'=>$Lang['cate_csort'],'name'=>'csort','value'=>10,'msg'=>$Lang['cate_csort_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else if($_GET['act'] == 'edit'){
    $cateInfo = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        $updateData = array();
        $updateData = __get_post_data($cateInfo);
        C::t('#tom_tcdaojia#tom_tcdaojia_cate')->update($cateInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=edit&id='.$_GET['id'],'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        __create_info_html($cateInfo);
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
}else if($_GET['act'] == 'editchild'){
    $cateInfo = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($_GET['id']);
    if(submitcheck('submit')){
        
        $name        = isset($_GET['name'])? addslashes($_GET['name']):'';
        $csort       = isset($_GET['csort'])? intval($_GET['csort']):10;
        
        $picurl        = tomuploadFile("picurl",$cateInfo['picurl']);
        
        $updateData = array();
        $updateData['name']         = $name;
        $updateData['picurl']       = $picurl;
        $updateData['csort']        = $csort;
        C::t('#tom_tcdaojia#tom_tcdaojia_cate')->update($cateInfo['id'],$updateData);
        cpmsg($Lang['act_success'], $modListUrl, 'succeed');
    }else{
        tomloadcalendarjs();
        loadeditorjs();
        __create_nav_html();
        showformheader($modFromUrl.'&act=editchild&id='.$_GET['id'],'enctype');
        showtableheader(); /*DisM.Taobao.Com*/
        tomshowsetting(true,array('title'=>$Lang['cate_name'],'name'=>'name','value'=>$cateInfo['name'],'msg'=>$Lang['cate_name_msg']),"input");
        tomshowsetting(true,array('title'=>$Lang['cate_picurl'],'name'=>'picurl','value'=>$cateInfo['picurl'],'msg'=>$Lang['cate_picurl_msg']),"file");
        tomshowsetting(true,array('title'=>$Lang['cate_csort'],'name'=>'csort','value'=>$cateInfo['csort'],'msg'=>$Lang['cate_csort_msg']),"input");
        showsubmit('submit', 'submit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism��taobao��com*/
    }
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'import'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/config/import.data.php';
    
    foreach ($catesArr as $key => $value){
        $insertData = array();
        $insertData['name']     = $value['name'];
        $insertData['picurl']   = $value['picurl'];
        $insertData['csort']    = $key;
        C::t('#tom_tcdaojia#tom_tcdaojia_cate')->insert($insertData);
        
        $parent_id = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->insert_id();
        
        foreach ($value['childs'] as $k1 => $v1){
            $insertData = array();
            $insertData['pid']     = $parent_id;
            $insertData['name']    = $v1['name'];
            $insertData['picurl']  = $v1['picurl'];
            $insertData['csort']   = $k1;
            C::t('#tom_tcdaojia#tom_tcdaojia_cate')->insert($insertData);
        }
    }
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    
    C::t('#tom_tcdaojia#tom_tcdaojia_cate')->delete_by_id($_GET['id']);
    C::t('#tom_tcdaojia#tom_tcdaojia_cate')->delete_by_pid($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delchild'){
    
    C::t('#tom_tcdaojia#tom_tcdaojia_cate')->delete_by_id($_GET['id']);
    
    cpmsg($Lang['act_success'], $modListUrl, 'succeed');
}else{
    
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr><th colspan="15" class="partition">' . $Lang['cate_help_title'] . '</th></tr>';
    echo '<tr><td  class="tipsblock" s="1"><ul id="tipslis">';
    echo '<li><a href="javascript:void(0);" onclick="import_confirm(\''.$modBaseUrl.'&act=import&formhash='.FORMHASH.'\');" class="addtr" ><font color="#F60">'.$Lang['cate_import'].'</font></a></li>';
    echo '</ul></td></tr>';
    showtablefooter(); /*dism _taobao _com*/
    
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $pagesize = 100;
    $start = ($page-1)*$pagesize;	
    $cateList = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid=0 "," ORDER BY csort ASC,id DESC ",$start,$pagesize);
    __create_nav_html();
    showtableheader(); /*DisM.Taobao.Com*/
    echo '<tr class="header">';
    echo '<th>ID</th>';
    echo '<th>' . $Lang['cate_picurl'] . '</th>';
    echo '<th>' . $Lang['cate_name'] . '</th>';
    echo '<th>' . $Lang['cate_csort'] . '</th>';
    echo '<th>' . $Lang['handle'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($cateList as $key => $value) {
        
        if(!preg_match('/^http/', $value['picurl']) ){
            if(strpos($value['picurl'], 'source/plugin/tom_') === FALSE){
                $picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$value['picurl'];
            }else{
                $picurl = $value['picurl'];
            }
        }else{
            $picurl = $value['picurl'];
        }
        
        echo '<tr>';
        echo '<td>' . $value['id'] . '</td>';
        if(!empty($value['picurl'])){
            echo '<td><img src="'.$picurl.'" width="40" /></td>';
        }else{
            echo '<td><img src="source/plugin/tom_tcdaojia/images/no_cate_picurl.png" width="40" /></td>';
        }
        echo '<td>' . $value['name'] . '</td>';
        echo '<td>' . $value['csort'] . '</td>';
        echo '<td>';
        if($value['pid'] == 0){
            echo '<a href="'.$modBaseUrl.'&act=addchild&pid='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['cate_addchild']. '</a>&nbsp;|&nbsp;';
        }
        echo '<a href="'.$modBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $Lang['cate_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        
        $childCateList = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_all_list(" AND pid={$value['id']} "," ORDER BY csort ASC,id DESC ",0,1000);
        if(is_array($childCateList) && !empty($childCateList)){
            foreach ($childCateList as $k => $v){
                if(!preg_match('/^http/', $v['picurl']) ){
                    if(strpos($v['picurl'], 'source/plugin/tom_tcdaojia/') === FALSE){
                        $child_picurl = (preg_match('/^http/', $_G['setting']['attachurl']) ? '' : $_G['siteurl']).$_G['setting']['attachurl'].'tomwx/'.$v['picurl'];
                    }else{
                        $child_picurl = $v['picurl'];
                    }
                }else{
                    $child_picurl = $v['picurl'];
                }
                echo '<tr style="background-color: #f7f7f7;">';
                echo '<td>' . $v['id'] . '</td>';
                if(!empty($v['picurl'])){
                    echo '<td><img src="'.$child_picurl.'" width="40" /></td>';
                }else{
                    echo '<td><img src="source/plugin/tom_tcdaojia/images/no_cate_picurl.png" width="40" /></td>';
                }
                echo '<td><img src="source/plugin/tom_tcdaojia/images/cates_admin_ico.png" style="vertical-align: bottom;margin-right: 5px;"/>' . $v['name'] . '</td>';
                echo '<td>' . $v['csort'] . '</td>';
                echo '<td>';
                echo '<a href="'.$modBaseUrl.'&act=editchild&id='.$v['id'].'&formhash='.FORMHASH.'">' . $Lang['cate_editchild']. '</a>&nbsp;|&nbsp;';
                echo '<a href="javascript:void(0);" onclick="del_confirm(\''.$modBaseUrl.'&act=delchild&id='.$v['id'].'&formhash='.FORMHASH.'\');">' . $Lang['delete'] . '</a>';
                echo '</td>';
                echo '</tr>';
            }
        }
        $i++;
    }
    showtablefooter(); /*dism _taobao _com*/
    $multi = multi($count, $pagesize, $page, $modBasePageUrl);	
    showsubmit('', '', '', '', $multi, false);
    
    $jsstr = <<<EOF
<script type="text/javascript">
function del_confirm(url){
  var r = confirm("{$Lang['makesure_del_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
function import_confirm(url){
  var r = confirm("{$Lang['makesure_import_msg']}")
  if (r == true){
    window.location = url;
  }else{
    return false;
  }
}
</script>
EOF;
    echo $jsstr;
    
}

function __get_post_data($infoArr = array()){
    $data = array();
    
    $name        = isset($_GET['name'])? addslashes($_GET['name']):'';
    $csort       = isset($_GET['csort'])? intval($_GET['csort']):10;
    
    $picurl = "";
    if($_GET['act'] == 'add'){
        $picurl        = tomuploadFile("picurl");
    }else if($_GET['act'] == 'edit'){
        $picurl        = tomuploadFile("picurl",$infoArr['picurl']);
    }

    $data['name']       = $name;
    $data['picurl']     = $picurl;
    $data['csort']      = $csort;
    
    return $data;
}

function __create_info_html($infoArr = array()){
    global $Lang;
    $options = array(
        'name'           => '',
        'picurl'         => '',
        'csort'          => 10,
    );
    $options = array_merge($options, $infoArr);
    
    tomshowsetting(true,array('title'=>$Lang['cate_name'],'name'=>'name','value'=>$options['name'],'msg'=>$Lang['cate_name_msg']),"input");
    tomshowsetting(true,array('title'=>$Lang['cate_picurl'],'name'=>'picurl','value'=>$options['picurl'],'msg'=>$Lang['cate_picurl_msg']),"file");
    tomshowsetting(true,array('title'=>$Lang['cate_csort'],'name'=>'csort','value'=>$options['csort'],'msg'=>$Lang['cate_csort_msg']),"input");
    
    return;
}

function __create_nav_html($infoArr = array()){
    global $Lang,$modBaseUrl,$adminBaseUrl;
    tomshownavheader();
    if($_GET['act'] == 'add'){
        tomshownavli($Lang['cate_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['cate_add'],"",true);
    }else if($_GET['act'] == 'edit'){
        tomshownavli($Lang['cate_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['cate_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['cate_edit'],"",true);
    }else if($_GET['act'] == 'addchild'){
        tomshownavli($Lang['cate_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['cate_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['cate_addchild'],"",true);
    }else if($_GET['act'] == 'editchild'){
        tomshownavli($Lang['cate_list_title'],$modBaseUrl,false);
        tomshownavli($Lang['cate_add'],$modBaseUrl."&act=add",false);
        tomshownavli($Lang['cate_editchild'],"",true);
    }else{
        tomshownavli($Lang['cate_list_title'],$modBaseUrl,true);
        tomshownavli($Lang['cate_add'],$modBaseUrl."&act=add",false);
    }
    tomshownavfooter();
}