<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$catesArr = array();

$catesArr[1] = array(
    'name'   => '��ͥ����',
    'picurl' => 'source/plugin/tom_tcdaojia/images/cates/1.png',
    'childs' => array(
        1 => array(
            'name'   => '�ճ�����',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/1/1.jpg',
        ),
        2 => array(
            'name'   => '��ȱ���',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/1/2.jpg',
        ),
        3 => array(
            'name'   => '���ı���',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/1/3.jpg',
        ),
        4 => array(
            'name'   => '������',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/1/4.jpg',
        ),
        5 => array(
            'name'   => '�Ҿ�����',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/1/5.jpg',
        ),
        6 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/1/6.jpg',
        ),
        7 => array(
            'name'   => 'ɱ������',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/1/7.jpg',
        ),
        8 => array(
            'name'   => '����ȩ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/1/8.jpg',
        ),
    )
);

$catesArr[2] = array(
    'name'   => '����ά��',
    'picurl' => 'source/plugin/tom_tcdaojia/images/cates/2.png',
    'childs' => array(
        1 => array(
            'name'   => '�ҵ�ά��',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/2/1.jpg',
        ),
        2 => array(
            'name'   => '�ֻ�ά��',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/2/2.jpg',
        ),
        3 => array(
            'name'   => '����ά��',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/2/3.jpg',
        ),
        4 => array(
            'name'   => '����ά��',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/2/4.jpg',
        ),
        5 => array(
            'name'   => '�ܵ���ͨ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/2/5.jpg',
        ),
        6 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/2/6.jpg',
        ),
    )
);

$catesArr[3] = array(
    'name'   => '�ҵ���ϴ',
    'picurl' => 'source/plugin/tom_tcdaojia/images/cates/3.png',
    'childs' => array(
        1 => array(
            'name'   => '�յ���ϴ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/3/1.jpg',
        ),
        2 => array(
            'name'   => '���̻���ϴ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/3/2.jpg',
        ),
        3 => array(
            'name'   => 'ϴ�»���ϴ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/3/3.jpg',
        ),
        4 => array(
            'name'   => '������ϴ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/3/4.jpg',
        ),
        5 => array(
            'name'   => '��ˮ����ϴ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/3/5.jpg',
        ),
        6 => array(
            'name'   => 'ȼ������ϴ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/3/6.jpg',
        ),
    )
);

$catesArr[4] = array(
    'name'   => '��һ���',
    'picurl' => 'source/plugin/tom_tcdaojia/images/cates/4.png',
    'childs' => array(
        1 => array(
            'name'   => '���',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/4/1.jpg',
        ),
        2 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/4/2.jpg',
        ),
    )
);

$catesArr[5] = array(
    'name'   => '��ķ��ɩ',
    'picurl' => 'source/plugin/tom_tcdaojia/images/cates/5.png',
    'childs' => array(
        1 => array(
            'name'   => '��ķ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/5/1.jpg',
        ),
        2 => array(
            'name'   => '��ɩ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/5/2.jpg',
        ),
        3 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/5/3.jpg',
        ),
    )
);

$catesArr[6] = array(
    'name'   => '���Ű�װ',
    'picurl' => 'source/plugin/tom_tcdaojia/images/cates/6.png',
    'childs' => array(
        1 => array(
            'name'   => '�ҵ簲װ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/6/1.jpg',
        ),
        2 => array(
            'name'   => '�Ҿ߰�װ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/6/2.jpg',
        ),
        3 => array(
            'name'   => '�Ҽ���װ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/6/3.jpg',
        ),
        4 => array(
            'name'   => '�ƾ߰�װ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/6/4.jpg',
        ),
        5 => array(
            'name'   => '��߰�װ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/6/5.jpg',
        ),
        6 => array(
            'name'   => '��װ���',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/6/6.jpg',
        ),
    )
);

$catesArr[7] = array(
    'name'   => '������ҵ',
    'picurl' => 'source/plugin/tom_tcdaojia/images/cates/7.png',
    'childs' => array(
        1 => array(
            'name'   => '���Ż�ױ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/7/1.jpg',
        ),
    )
);

$catesArr[8] = array(
    'name'   => '����ϴ��',
    'picurl' => 'source/plugin/tom_tcdaojia/images/cates/8.png',
    'childs' => array(
        1 => array(
            'name'   => 'ϴ��',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/8/1.jpg',
        ),
        2 => array(
            'name'   => 'ϴЬ��Ь',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/8/2.jpg',
        ),
        3 => array(
            'name'   => '�ҷ���ϴ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/8/3.jpg',
        ),
        4 => array(
            'name'   => '���ϴ��',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/8/4.jpg',
        ),
    )
);

$catesArr[9] = array(
    'name'   => '��������',
    'picurl' => 'source/plugin/tom_tcdaojia/images/cates/9.png',
    'childs' => array(
        1 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/9/1.jpg',
        ),
        2 => array(
            'name'   => '������Ԯ',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/9/2.jpg',
        ),
        3 => array(
            'name'   => '�������',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/9/3.jpg',
        ),
    )
);

$catesArr[10] = array(
    'name'   => '��������',
    'picurl' => 'source/plugin/tom_tcdaojia/images/cates/10.png',
    'childs' => array(
        1 => array(
            'name'   => '���Ż���',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/10/1.jpg',
        ),
        2 => array(
            'name'   => '��������',
            'picurl' => 'source/plugin/tom_tcdaojia/images/cates/10/2.jpg',
        ),
    )
);

$divnavArr = array();
$divnavArr[1] = array(
    'title'     => '��ͥ����',
    'picurl'    => 'source/plugin/tom_tcdaojia/images/cates/1.png',
    'link'      => 'plugin.php?id=tom_tcdaojia&site={site}&mod=goodslist&cate_id=1',
);
$divnavArr[2] = array(
    'title'     => '����ά��',
    'picurl'    => 'source/plugin/tom_tcdaojia/images/cates/2.png',
    'link'      => 'plugin.php?id=tom_tcdaojia&site={site}&mod=goodslist&cate_id=10',
);
$divnavArr[3] = array(
    'title'     => '�ҵ���ϴ',
    'picurl'    => 'source/plugin/tom_tcdaojia/images/cates/3.png',
    'link'      => 'plugin.php?id=tom_tcdaojia&site={site}&mod=goodslist&cate_id=17',
);
$divnavArr[4] = array(
    'title'     => '��һ���',
    'picurl'    => 'source/plugin/tom_tcdaojia/images/cates/4.png',
    'link'      => 'plugin.php?id=tom_tcdaojia&site={site}&mod=goodslist&cate_id=24',
);
$divnavArr[5] = array(
    'title'     => '��ķ��ɩ',
    'picurl'    => 'source/plugin/tom_tcdaojia/images/cates/5.png',
    'link'      => 'plugin.php?id=tom_tcdaojia&site={site}&mod=goodslist&cate_id=27',
);
$divnavArr[6] = array(
    'title'     => '���Ű�װ',
    'picurl'    => 'source/plugin/tom_tcdaojia/images/cates/6.png',
    'link'      => 'plugin.php?id=tom_tcdaojia&site={site}&mod=goodslist&cate_id=31',
);
$divnavArr[7] = array(
    'title'     => '������ҵ',
    'picurl'    => 'source/plugin/tom_tcdaojia/images/cates/7.png',
    'link'      => 'plugin.php?id=tom_tcdaojia&site={site}&mod=goodslist&cate_id=38',
);
$divnavArr[8] = array(
    'title'     => '����ϴ��',
    'picurl'    => 'source/plugin/tom_tcdaojia/images/cates/8.png',
    'link'      => 'plugin.php?id=tom_tcdaojia&site={site}&mod=goodslist&cate_id=40',
);
$divnavArr[9] = array(
    'title'     => '��������',
    'picurl'    => 'source/plugin/tom_tcdaojia/images/cates/9.png',
    'link'      => 'plugin.php?id=tom_tcdaojia&site={site}&mod=goodslist&cate_id=45',
);
$divnavArr[10] = array(
    'title'     => '��������',
    'picurl'    => 'source/plugin/tom_tcdaojia/images/cates/10.png',
    'link'      => 'plugin.php?id=tom_tcdaojia&site={site}&mod=goodslist&cate_id=49',
);

$vipArr = array();
$vipArr[1] = array(
    'name'          => '���Ʒ�����',
    'picurl'        => 'source/plugin/tom_tcdaojia/images/vip/vip1.png',
    'up_jie_num'    => '5',
    'up_grade'      => '3',
    'yongjin_bili'  => '8',
    'rank'          => '1',
);
$vipArr[2] = array(
    'name'          => '���Ʒ�����',
    'picurl'        => 'source/plugin/tom_tcdaojia/images/vip/vip2.png',
    'up_jie_num'    => '10',
    'up_grade'      => '4',
    'yongjin_bili'  => '6',
    'rank'          => '2',
);
$vipArr[3] = array(
    'name'          => '��ʯ������',
    'picurl'        => 'source/plugin/tom_tcdaojia/images/vip/vip3.png',
    'up_jie_num'    => '20',
    'up_grade'      => '4',
    'yongjin_bili'  => '2',
    'rank'          => '3',
);

$dengjiArr = array();
$dengjiArr[1] = array(
    'name'              => '�����ײ�',
    'picurl'            => 'source/plugin/tom_tcdaojia/images/dengji/dengji0.png',
    'days'              => 7,
    'days_msg'          => '7��',
    'price'             => 10,
    'fabu_goods_num'    => 1,
    'xiangou_num'       => 1,
);
$dengjiArr[2] = array(
    'name'              => '�����ײ�',
    'picurl'            => 'source/plugin/tom_tcdaojia/images/dengji/dengji1.png',
    'days'              => 365,
    'days_msg'          => '1��',
    'price'             => 100,
    'fabu_goods_num'    => 3,
    'xiangou_num'       => 0,
);
$dengjiArr[3] = array(
    'name'              => '�߼��ײ�',
    'picurl'            => 'source/plugin/tom_tcdaojia/images/dengji/dengji2.png',
    'days'              => 730,
    'days_msg'          => '2��',
    'price'             => 300,
    'fabu_goods_num'    => 5,
    'xiangou_num'       => 0,
);

if (CHARSET == 'utf-8') {
    $catesArr   = tom_iconv($catesArr,'gbk','utf-8');
    $divnavArr  = tom_iconv($divnavArr,'gbk','utf-8');
    $vipArr  = tom_iconv($vipArr,'gbk','utf-8');
    $dengjiArr  = tom_iconv($dengjiArr,'gbk','utf-8');
}