<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tcdaojiaConfig = $_G['cache']['plugin']['tom_tcdaojia'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/class/function.core.php';

## tcyikatong start
$__ShowTcyikatong = 0;
$tcyikatongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
    $tcyikatongConfig = $_G['cache']['plugin']['tom_tcyikatong'];
    if($tcyikatongConfig['open_tcyikatong'] == 1){
        $__ShowTcyikatong = 1;
    }
}
## tcyikatong end

if($_GET['act'] == "pay_goods" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $goods_id           = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
    $option_id          = isset($_GET['option_id'])? intval($_GET['option_id']):0;
    $goods_num          = intval($_GET['goods_num'])>0? intval($_GET['goods_num']):1;
    $address_id         = isset($_GET['address_id'])? intval($_GET['address_id']):0;
    $order_beizu        = isset($_GET['order_beizu'])? addslashes($_GET['order_beizu']):'';    
    $fuwu_time          = isset($_GET['fuwu_time'])? addslashes($_GET['fuwu_time']):'';
    $fuwu_time          = str_replace("T", " ", $fuwu_time);
    $fuwu_time          = strtotime($fuwu_time);
    $tj_hehuoren_id     = isset($_GET['tj_hehuoren_id'])? intval($_GET['tj_hehuoren_id']):0;

    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    $goodsInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($goods_id);
    $servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($goodsInfo['servicer_id']);
    
    $addressInfo = array('xm'=>'','tel'=>'','area_str'=>'','info'=>'');
    if($address_id > 0){
        $addressInfo = C::t('#tom_ucenter#tom_ucenter_address')->fetch_by_id($address_id);
    }
    
    if(empty($userInfo) || empty($goodsInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if($servicerInfo['jie_status'] != 1){
        $outArr = array(
            'status'=> 306,
        );
        echo json_encode($outArr); exit;
    }
    
    if( $tcdaojiaConfig['open_ruzhu_pay_money'] == 1 && $servicerInfo['dengji_id'] <= 0){
        $outArr = array(
            'status'=> 307,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $buy_price      = $goodsInfo['price'];
    $vip_price      = $goodsInfo['vip_price'];
    
    if($goodsInfo['hasoption'] == 1){
        $optionInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->fetch_by_id($option_id);
        if(is_array($optionInfo) && !empty($optionInfo)){
            $buy_price      = $optionInfo['price'];
            $vip_price      = $optionInfo['vip_price'];
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $tcyikatongPayStatus = 0;
    if($__ShowTcyikatong == 1 && $goodsInfo['open_vip'] == 1){
        $cardInfoTmp = C::t('#tom_tcyikatong#tom_tcyikatong_card')->fetch_by_user_id($userInfo['id']);
        if(is_array($cardInfoTmp) && !empty($cardInfoTmp) && $cardInfoTmp['status'] == 1){
            $tcyikatongPayStatus = 1;
        }
    }
    
    $pay_price = 0;
    if($goodsInfo['open_ding_pay'] == 1){
        $pay_price = $goodsInfo['ding_price'];
    }else{
        if($tcyikatongPayStatus == 1){
            $pay_price = $vip_price;
        }else{
            $pay_price = $buy_price;
        }
    }
    
    $order_no  = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    $hexiao_no = date("YmdHis")."-".mt_rand(111111, 666666);
    $one_price = $pay_price;
    $pay_price = $pay_price*$goods_num;
    
    $wei_price = 0;
    if($goodsInfo['open_ding_pay'] == 1){
        if($tcyikatongPayStatus == 1){
            if($vip_price > 0){
                $wei_price = ($vip_price -  $goodsInfo['ding_price']) * $goods_num;
            }
        }else{
            if($buy_price > 0){
                $wei_price = ($buy_price -  $goodsInfo['ding_price']) * $goods_num;
            }
        }
        if($wei_price <= 0){
            $wei_price = 0;
        }
    }

    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['tj_hehuoren_id']   = $tj_hehuoren_id;
    $insertData['order_no']         = $order_no;
    $insertData['hexiao_no']        = $hexiao_no;
    if($goodsInfo['hasoption'] == 1){
        $insertData['option_id']        = $option_id;
        $insertData['option_name']      = $optionInfo['name'];
    }
    $insertData['goods_num']        = $goods_num;
    $insertData['one_price']        = $one_price;
    $insertData['goods_id']         = $goodsInfo['id'];
    $insertData['servicer_id']      = $goodsInfo['servicer_id'];
    $insertData['type']             = 3;
    $insertData['user_id']          = $user_id;
    if($address_id > 0 ){
        $insertData['address_id']   = $address_id;
    }
    $insertData['xm']               = $addressInfo['xm'];
    $insertData['tel']              = $addressInfo['tel'];
    $insertData['address']          = $addressInfo['area_str']." ".$addressInfo['info'];
    $insertData['order_beizu']      = $order_beizu;
    $insertData['fuwu_time']        = $fuwu_time;
    $insertData['openid']           = $userInfo['openid'];
    $insertData['pay_price']        = $pay_price;
    if($tcyikatongPayStatus == 1){
        $insertData['vip_pay_status'] = 1;
    }
    $insertData['wei_price']        = $wei_price;
    if($goodsInfo['open_ding_pay'] == 1){
        $insertData['pay_ding_status']   = 1;
    }
    if($pay_price > 0){
        $insertData['order_status']     = 1;
    }else{
        if($goodsInfo['open_yuyue'] == 1){
            $insertData['order_status'] = 2;
        }else{
            $insertData['order_status'] = 3;
        }
        $insertData['pay_time'] = TIMESTAMP;
    }
    
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert($insertData)){
        $orderId = C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert_id();
        
        DB::query("UPDATE ".DB::table('tom_tcdaojia_goods')." SET sale_num=sale_num+{$goods_num} WHERE id='{$goodsInfo['id']}' ", 'UNBUFFERED');
        if($goodsInfo['hasoption'] == 1 && $option_id > 0){
            DB::query("UPDATE ".DB::table('tom_tcdaojia_goods_option')." SET sale_num=sale_num+{$goods_num} WHERE id='{$option_id}' ", 'UNBUFFERED');
        }
        
        if($pay_price > 0){
            
            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcdaojia';          
            $insertData['order_no']        = $order_no;                 
            $insertData['goods_id']        = $goodsInfo['id'];         
            $insertData['goods_name']      = $goodsInfo['title'];      
            $insertData['goods_beizu']     = $goodsInfo['title'];      
            $insertData['goods_url']       = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=goodsinfo&goods_id='.$goodsInfo['id'];              
            $insertData['succ_back_url']   = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=order";
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=order";
            $insertData['allow_alipay']    = 1;             
            $insertData['pay_price']       = $pay_price;    
            $insertData['order_status']    = 1;             
            $insertData['add_time']        = TIMESTAMP;     
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'pay_status'=> 1,
                    'status'    => 200,
                    'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 303,
                );
                echo json_encode($outArr); exit;
            }
            
        }else{
            
            include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
            
            $servicerUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']);

            $template_goods_first = str_replace("{XM}",$userInfo['nickname'], lang('plugin/tom_tcdaojia','template_tcdaojia_goods_pay'));
            $template_goods_first = str_replace("{TITLE}",$goodsInfo['title'],$template_goods_first);

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($servicerUserInfo['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$needsInfo['site_id']}&mod=myorder");
                $smsData = array(
                    'first'         => $template_goods_first,
                    'keyword1'      => $tcdaojiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                    'remark'        => ''
                );
                @$r = $templateSmsClass->sendSms01($servicerUserInfo['openid'],$tongchengConfig['template_id'],$smsData);
            }

            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($userInfo['openid'])){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$goodsInfo['site_id']}&mod=order");
                $smsData = array(
                    'first'         => lang('plugin/tom_tcdaojia','template_tcdaojia_buy_goods'),
                    'keyword1'      => $tcdaojiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                    'remark'        => ''
                );

                @$r = $templateSmsClass->sendSms01($userInfo['openid'], $tongchengConfig['template_id'], $smsData);
            }
            
            $outArr = array(
                'pay_status'=> 0,
                'status'    => 200,
            );
            echo json_encode($outArr); exit;
            
        }
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($_GET['act'] == "pay_goods_weikuan" && submitcheck('order_no')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $order_no          = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
    
    $orderInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($order_no);
    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
    $goodsInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($orderInfo['goods_id']);
   
    if(empty($userInfo) || empty($goodsInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $pay_price = $orderInfo['wei_price'];
    
    if($pay_price <= 0){
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!empty($orderInfo['sub_order_no'])){
        $subOrderInfo = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($orderInfo['sub_order_no']);
        if($subOrderInfo['id'] > 0 && $subOrderInfo['order_status'] == 2){
            $outArr = array(
                'status'=> 500,
            );
            echo json_encode($outArr); exit;
        }
        if($subOrderInfo['id'] > 0 && $subOrderInfo['order_status'] == 1){
            $updateData = array();
            $updateData['order_status'] = 6;
            C::t('#tom_tcdaojia#tom_tcdaojia_order')->update($subOrderInfo['id'],$updateData);
        }
    }
    
    $sub_order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    $insertData = array();
    $insertData['site_id']          = $orderInfo['site_id'];
    $insertData['tj_hehuoren_id']   = $orderInfo['tj_hehuoren_id'];
    $insertData['order_no']         = $sub_order_no;
    $insertData['goods_id']         = $goodsInfo['id'];
    $insertData['servicer_id']      = $goodsInfo['servicer_id'];
    $insertData['type']             = 4;
    $insertData['user_id']          = $orderInfo['user_id'];
    $insertData['openid']           = $orderInfo['openid'];
    $insertData['pay_price']        = $pay_price;
    $insertData['pay_ding_status']  = $orderInfo['pay_ding_status'];
    $insertData['is_weikuan']       = 1;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert($insertData)){
        $orderId = C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert_id();
        
        $updateData = array();
        $updateData['sub_order_no'] = $sub_order_no;
        C::t('#tom_tcdaojia#tom_tcdaojia_order')->update($orderInfo['id'],$updateData);
        
        $goods_url = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=goodsinfo&goods_id='.$goodsInfo['id'];
        $back_url = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=order";
        
        $insertData = array();
        $insertData['plugin_id']       = 'tom_tcdaojia';          
        $insertData['order_no']        = $sub_order_no;                 
        $insertData['goods_id']        = $goodsInfo['id'];         
        $insertData['goods_name']      = $goodsInfo['title'];      
        $insertData['goods_beizu']     = $goodsInfo['title'];      
        $insertData['goods_url']       = $goods_url;               
        $insertData['succ_back_url']   = $back_url; 
        $insertData['fail_back_url']   = $back_url;  
        $insertData['allow_alipay']    = 1;             
        $insertData['pay_price']       = $pay_price;    
        $insertData['order_status']    = 1;             
        $insertData['add_time']        = TIMESTAMP;     
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'    => 200,
                'payurl' => "plugin.php?id=tom_pay&order_no=".$sub_order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($_GET['act'] == "pay_needs" && submitcheck('jie_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $jie_id     = isset($_GET['jie_id'])? intval($_GET['jie_id']):0;
    
    $jieInfo    = C::t('#tom_tcdaojia#tom_tcdaojia_needs_jie')->fetch_by_id($jie_id);
    $needsInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($jieInfo['needs_id']);
    $userInfo   = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);
  
    if(empty($userInfo) || empty($needsInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    $pay_price = $jieInfo['price'];
    
    if($pay_price <= 0){
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
    
    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    $hexiao_no = date("YmdHis")."-".mt_rand(111111, 666666);
    
    $insertData = array();
    $insertData['site_id']          = $site_id;
    $insertData['order_no']         = $order_no;
    $insertData['hexiao_no']        = $hexiao_no;
    $insertData['needs_id']         = $jieInfo['needs_id'];
    $insertData['servicer_id']      = $jieInfo['servicer_id'];
    if($needsInfo['type'] == 1){
        $insertData['type']             = 1;
    }elseif($needsInfo['type'] == 2){
        $insertData['type']             = 2;
    }
    $insertData['user_id']          = $userInfo['id'];
    $insertData['goods_num']        = 1;
    $insertData['xm']               = $needsInfo['xm'];
    $insertData['tel']              = $needsInfo['tel'];
    $insertData['address']          = $needsInfo['address'];
    $insertData['fuwu_time']        = $needsInfo['fuwu_time'];
    $insertData['openid']           = $userInfo['openid'];
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert($insertData)){
        $orderId = C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert_id();
        
        $goods_url = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=goodsinfo&goods_id='.$goodsInfo['id'];
        $back_url = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=order";
        
        $insertData = array();
        $insertData['plugin_id']       = 'tom_tcdaojia';          
        $insertData['order_no']        = $order_no;                 
        $insertData['goods_id']        = $needsInfo['id'];         
        $insertData['goods_name']      = cutstr($needsInfo['content'],30,"");    
        $insertData['goods_url']       = $goods_url;               
        $insertData['succ_back_url']   = $back_url; 
        $insertData['fail_back_url']   = $back_url;  
        $insertData['allow_alipay']    = 1;             
        $insertData['pay_price']       = $pay_price;    
        $insertData['order_status']    = 1;             
        $insertData['add_time']        = TIMESTAMP;     
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'    => 200,
                'payurl'        => "plugin.php?id=tom_pay&order_no=".$order_no,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($_GET['act'] == "pay" && submitcheck('order_no')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $order_no   = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
    
    $orderInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($order_no);
    
    if($orderInfo['goods_id'] > 0){
        $goodsInfo  = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($orderInfo['goods_id']);
    }
    if($orderInfo['needs_id'] > 0){
        $needsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($orderInfo['needs_id']);
    }
    
    $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
    
    if($orderInfo && $orderInfo['order_status'] == 1){
        
        DB::query("UPDATE ".DB::table('tom_tcdaojia_order')." SET order_no='{$order_no}' WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tcdaojia';          
        $insertData['order_no']        = $order_no;                 
        $insertData['goods_id']        = $orderInfo['goods_id'];
        if($orderInfo['goods_id'] > 0){
            $insertData['goods_name']      = $goodsInfo['title'];
            $insertData['goods_beizu']     = $goodsInfo['title']; 
        }
        if($orderInfo['needs_id'] > 0){
            $insertData['goods_name']      = cutstr($needsInfo['content'],30,"");
        }
        $insertData['goods_url']       = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=goodsinfo&goods_id={$orderInfo['goods_id']}";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=order";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=order"; 
        $insertData['allow_alipay']    = 1;    
        $insertData['pay_price']       = $orderInfo['pay_price'];
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        C::t('#tom_pay#tom_pay_order')->insert($insertData);
        
        $outArr = array(
            'status'    => 200,
            'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }

}else if($_GET['act'] == "cancelpay" && submitcheck('order_no')){
    
    $order_no  = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
   
    $orderInfo = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($order_no);

    if($orderInfo && $orderInfo['order_status'] == 1 ){
        
        if($orderInfo['needs_id'] > 0){
            $jieInfo = C::t('#tom_tcdaojia#tom_tcdaojia_needs_jie')->fetch_all_list("AND needs_id = {$orderInfo['needs_id']} AND servicer_id = {$orderInfo['servicer_id']}","",0,1);
            if($jieInfo[0]['id'] > 0){
                DB::query("UPDATE ".DB::table('tom_tcdaojia_needs_jie')." SET status=0 WHERE id = {$jieInfo[0]['id']} ", 'UNBUFFERED');
            }
        }

        if($orderInfo['goods_id'] > 0){
            DB::query("UPDATE ".DB::table('tom_tcdaojia_goods')." SET sale_num=sale_num-1 WHERE id='{$orderInfo['goods_id']}' ", 'UNBUFFERED');
            if($orderInfo['option_id'] > 0){
                DB::query("UPDATE ".DB::table('tom_tcdaojia_goods_option')." SET sale_num=sale_num-{$orderInfo['goods_num']} WHERE id='{$orderInfo['option_id']}' ", 'UNBUFFERED');
            }
        }
        
        DB::query("UPDATE ".DB::table('tom_tcdaojia_order')." SET order_status=6 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($_GET['act'] == "weikuan_cancelpay" && submitcheck('order_no')){
    
    $order_no  = !empty($_GET['order_no'])? addslashes($_GET['order_no']):'';
   
    $orderInfo = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($order_no);
    
    $goodsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_by_id($orderInfo['goods_id']);

    if(($orderInfo['order_status'] == 2 || $orderInfo['order_status'] == 3) && $orderInfo['pay_ding_status'] == 1){
        
        DB::query("UPDATE ".DB::table('tom_tcdaojia_goods')." SET sale_num=sale_num-1 WHERE id='{$orderInfo['goods_id']}' ", 'UNBUFFERED');

        if($orderInfo['option_id'] > 0){
            DB::query("UPDATE ".DB::table('tom_tcdaojia_goods_option')." SET sale_num=sale_num-{$orderInfo['goods_num']} WHERE id='{$orderInfo['option_id']}' ", 'UNBUFFERED');
        }
        
        DB::query("UPDATE ".DB::table('tom_tcdaojia_order')." SET order_status=6 WHERE id='{$orderInfo['id']}' ", 'UNBUFFERED');
        
        include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/module/balance.php';
        
        $outArr = array(
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
    }else{
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($_GET['act'] == "needs_top_pay" && submitcheck('needs_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $needs_id       = intval($_GET['needs_id'])>0 ? intval($_GET['needs_id']):0;
    $top_days       = intval($_GET['top_days'])>0 ? intval($_GET['top_days']):0;
    
    $needsInfo = C::t("#tom_tcdaojia#tom_tcdaojia_needs")->fetch_by_id($needs_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($needsInfo['user_id']);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($needsInfo) && $needsInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $top_pay_price = $top_pay_score = 0;
    $top_pay_price_msg = '';
    $needs_top_list_str = str_replace("\r\n","{n}",$tcdaojiaConfig['needs_top_list']); 
    $needs_top_list_str = str_replace("\n","{n}",$needs_top_list_str);
    $needs_top_list_arr = explode("{n}", $needs_top_list_str);
    if(is_array($needs_top_list_arr) && !empty($needs_top_list_arr)){
        foreach ($needs_top_list_arr as $key => $value){
            $needsTopInfoTmp = array();
            $needsTopInfoTmp = explode("|", $value);
            if($needsTopInfoTmp[0] == $top_days){
                $top_pay_price = $needsTopInfoTmp[1];
                $top_pay_price_msg = $needsTopInfoTmp[2];
                if($tcdaojiaConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                    $top_pay_score = ceil($top_pay_price * $tongchengConfig['pay_score_yuan']);
                }
            }
        }
    }
    
    if($top_pay_price <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['score'] >= $top_pay_score && $top_pay_score > 0){
        $pay_score = $top_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 64;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        $needsInfo = C::t("#tom_tcdaojia#tom_tcdaojia_needs")->fetch_by_id($needs_id);
        if($needsInfo['top_time'] > TIMESTAMP){
            $top_time = $top_days * 86400 + $needsInfo['top_time'];
        }else{
            $top_time = $top_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcdaojia#tom_tcdaojia_needs')->update($needs_id,$updateData);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $pay_price = $top_pay_price;

        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['needs_id']         = $needs_id;
        $insertData['type']             = 5;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['top_days']         = $top_days;
        $insertData['top_price']        = $top_pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert($insertData)){
            $order_id = C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcdaojia';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = lang('plugin/tom_tcdaojia', 'fabu_needs_top');
            $insertData['goods_beizu']     = lang('plugin/tom_tcdaojia','needs_top').$top_pay_price_msg;
            $insertData['goods_url']       = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=needsinfo&needs_id='.$needs_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=buyneeds&needs_id='.$needs_id;
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=buyneeds&needs_id={$needs_id}";
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
}else if($_GET['act'] == "goods_top_pay" && submitcheck('goods_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $goods_id       = intval($_GET['goods_id'])>0 ? intval($_GET['goods_id']):0;
    $top_days       = intval($_GET['top_days'])>0 ? intval($_GET['top_days']):0;
    
    $goodsInfo = C::t("#tom_tcdaojia#tom_tcdaojia_goods")->fetch_by_id($goods_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($goodsInfo['user_id']);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($goodsInfo) && $goodsInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $top_pay_price = $top_pay_score = 0;
    $top_pay_price_msg = '';
    $goods_top_list_str = str_replace("\r\n","{n}",$tcdaojiaConfig['goods_top_list']); 
    $goods_top_list_str = str_replace("\n","{n}",$goods_top_list_str);
    $goods_top_list_arr = explode("{n}", $goods_top_list_str);
    if(is_array($goods_top_list_arr) && !empty($goods_top_list_arr)){
        foreach ($goods_top_list_arr as $key => $value){
            $goodsTopInfoTmp = array();
            $goodsTopInfoTmp = explode("|", $value);
            if($goodsTopInfoTmp[0] == $top_days){
                $top_pay_price = $goodsTopInfoTmp[1];
                $top_pay_price_msg = $goodsTopInfoTmp[2];
                if($tcdaojiaConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                    $top_pay_score = ceil($top_pay_price * $tongchengConfig['pay_score_yuan']);
                }
            }
        }
    }
    
    if($top_pay_price <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['score'] >= $top_pay_score && $top_pay_score > 0){
        $pay_score = $top_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 65;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        $goodsInfo = C::t("#tom_tcdaojia#tom_tcdaojia_goods")->fetch_by_id($goods_id);
        if($goodsInfo['top_time'] > TIMESTAMP){
            $top_time = $top_days * 86400 + $goodsInfo['top_time'];
        }else{
            $top_time = $top_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($goods_id,$updateData);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $pay_price = $top_pay_price;

        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['goods_id']         = $goods_id;
        $insertData['type']             = 6;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['top_days']         = $top_days;
        $insertData['top_price']        = $top_pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert($insertData)){
            $order_id = C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcdaojia';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = lang('plugin/tom_tcdaojia', 'fabu_goods_top');
            $insertData['goods_beizu']     = lang('plugin/tom_tcdaojia','goods_top').$top_pay_price_msg;
            $insertData['goods_url']       = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=goodsinfo&goods_id='.$goods_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=buygoods&goods_id='.$goods_id;
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=buygoods&goods_id={$goods_id}";
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
}else if($_GET['act'] == "servicer_top_pay" && submitcheck('servicer_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    $servicer_id        = intval($_GET['servicer_id'])>0 ? intval($_GET['servicer_id']):0;
    $top_days       = intval($_GET['top_days'])>0 ? intval($_GET['top_days']):0;
    
    $servicerInfo = C::t("#tom_tcdaojia#tom_tcdaojia_servicer")->fetch_by_id($servicer_id);
    $userInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($servicerInfo['user_id']);
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    if(is_array($servicerInfo) && $servicerInfo['id'] > 0){ }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    $top_pay_price = $top_pay_score = 0;
    $top_pay_price_msg = '';
    $servicer_top_list_str = str_replace("\r\n","{n}",$tcdaojiaConfig['servicer_top_list']); 
    $servicer_top_list_str = str_replace("\n","{n}",$servicer_top_list_str);
    $servicer_top_list_arr = explode("{n}", $servicer_top_list_str);
    if(is_array($servicer_top_list_arr) && !empty($servicer_top_list_arr)){
        foreach ($servicer_top_list_arr as $key => $value){
            $servicerTopInfoTmp = array();
            $servicerTopInfoTmp = explode("|", $value);
            if($servicerTopInfoTmp[0] == $top_days){
                $top_pay_price = $servicerTopInfoTmp[1];
                $top_pay_price_msg = $servicerTopInfoTmp[2];
                if($tcdaojiaConfig['open_score_pay'] == 1 && $tongchengConfig['pay_score_yuan'] > 0){
                    $top_pay_score = ceil($top_pay_price * $tongchengConfig['pay_score_yuan']);
                }
            }
        }
    }
 
    if($top_pay_price <= 0){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['score'] >= $top_pay_score && $top_pay_score > 0){
        $pay_score = $top_pay_score;
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] - $pay_score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $userInfo['id'];
        $insertData['score_value']      = $pay_score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 66;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);
        
        $servicerInfo = C::t("#tom_tcdaojia#tom_tcdaojia_servicer")->fetch_by_id($servicer_id);
        if($servicerInfo['top_time'] > TIMESTAMP){
            $top_time = $top_days * 86400 + $servicerInfo['top_time'];
        }else{
            $top_time = $top_days * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->update($servicer_id,$updateData);
        
        $outArr = array(
            'status'        => 200,
            'pay_status'    => 0,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $pay_price = $top_pay_price;

        $order_no   = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

        $insertData = array();
        $insertData['site_id']          = $site_id;
        $insertData['servicer_id']      = $servicer_id;
        $insertData['type']             = 7;
        $insertData['user_id']          = $userInfo['id'];
        $insertData['openid']           = $userInfo['openid'];
        $insertData['order_no']         = $order_no;
        $insertData['pay_price']        = $pay_price;
        $insertData['top_days']         = $top_days;
        $insertData['top_price']        = $top_pay_price;
        $insertData['order_status']     = 1;
        $insertData['order_time']       = TIMESTAMP;
        if(C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert($insertData)){
            $order_id = C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert_id();

            $insertData = array();
            $insertData['plugin_id']       = 'tom_tcdaojia';          
            $insertData['order_no']        = $order_no;
            $insertData['goods_id']        = $order_id;         
            $insertData['goods_name']      = lang('plugin/tom_tcdaojia', 'fabu_servicer_top');
            $insertData['goods_beizu']     = lang('plugin/tom_tcdaojia','servicer_top').$top_pay_price_msg;
            $insertData['goods_url']       = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=servicerinfo&servicer_id='.$servicer_id;
            $insertData['succ_back_url']   = 'plugin.php?id=tom_tcdaojia&site='.$site_id.'&mod=buyservicer&servicer_id='.$servicer_id;
            $insertData['fail_back_url']   = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=buyservicer&servicer_id={$servicer_id}";
            $insertData['allow_alipay']    = 1;
            $insertData['pay_price']       = $pay_price;
            $insertData['order_status']    = 1;
            $insertData['add_time']        = TIMESTAMP;
            if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                $outArr = array(
                    'status'        => 200,
                    'pay_status'    => 1,
                    'payurl'        => $pay_hosts."plugin.php?id=tom_pay&order_no=".$order_no,
                );
                echo json_encode($outArr); exit;
            }else{
                $outArr = array(
                    'status'=> 306,
                );
                echo json_encode($outArr); exit;
            }
        }else{
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
}else if($_GET['act'] == "ruzhu" && submitcheck('user_id')){
    
    $outArr = array(
        'status'=> 1,
    );
    
    if('utf-8' != CHARSET) {
        if(defined('IN_MOBILE')){
        }else{
            foreach($_POST AS $pk => $pv) {
                if(!is_numeric($pv)) {
                    $_GET[$pk] = $_POST[$pk] = wx_iconv_recurrence($pv);	
                }
            }
        }
    }
    
    $user_id            = isset($_GET['user_id'])? intval($_GET['user_id']):0;
    $type               = isset($_GET['type'])? intval($_GET['type']):1;
    $name               = isset($_GET['name'])? addslashes($_GET['name']):'';
    $xm                 = isset($_GET['xm'])? addslashes($_GET['xm']):'';
    $tel                = isset($_GET['tel'])? addslashes($_GET['tel']):'';
    $start_time         = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
    $end_time           = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
    $address            = isset($_GET['address'])? addslashes($_GET['address']):'';
    $latitude           = isset($_GET['latitude'])? addslashes($_GET['latitude']):'';
    $longitude          = isset($_GET['longitude'])? addslashes($_GET['longitude']):'';
    $content            = isset($_GET['content'])? addslashes($_GET['content']):'';
    $picurl             = isset($_GET['picurl'])? addslashes($_GET['picurl']):'';
    $wxpicurl           = isset($_GET['wxpicurl'])? addslashes($_GET['wxpicurl']):'';
    $dengji_id          = isset($_GET['dengji_id'])? intval($_GET['dengji_id']):0;
    $code               = isset($_GET['code'])? addslashes($_GET['code']):'';
    
    $cate_ids = '';
    if(is_array($_GET['cate_ids']) && !empty($_GET['cate_ids'])){
        $cate_ids = implode('|', $_GET['cate_ids']);
    }
    
    $area_ids = '';
    if(is_array($_GET['area_ids']) && !empty($_GET['area_ids'])){
        $area_ids_arr = array_unique($_GET['area_ids']);
        $area_ids = implode('|', $area_ids_arr);
    }
    
    $street_ids = '';
    if(is_array($_GET['street_ids']) && !empty($_GET['street_ids'])){
        $street_ids_arr = array_unique($_GET['street_ids']);
        $street_ids = implode('|', $street_ids_arr);
    }
    
    $photoArr = array();
    foreach($_GET as $key => $value){
        if(strpos($key, "photo_") !== false){
            $kk = intval(ltrim($key, "photo_"));
            $photoArr[$kk] = addslashes($value);
        }
    }
    
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($user_id);
    if(empty($userInfo)){
        $outArr = array(
            'status'=> 500,
        );
        echo json_encode($outArr); exit;
    }
    
    if($userInfo['status'] != 1){
        $outArr = array(
            'status'=> 301,
        );
        echo json_encode($outArr); exit;
    }
    
    $fabuPayStatus = 0;
    if($tcdaojiaConfig['open_ruzhu_pay_money'] == 1 && empty($code)){
        $fabuPayStatus = 1;
    }
    
    $pay_price = 0;
   
    if($fabuPayStatus == 1){
        $dengjiInfo = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_by_id($dengji_id);
        if(empty($dengjiInfo)){
            $outArr = array(
                'status'=> 500,
            );
            echo json_encode($outArr); exit;
        }
        $pay_price = $dengjiInfo['price'];
        if($pay_price <= 0){
            $outArr = array(
                'status'=> 305,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    if(!empty($code)){
        $dengjiCodeInfo = C::t('#tom_tcdaojia#tom_tcdaojia_dengji_code')->fetch_by_code($code);
        if(empty($dengjiCodeInfo)){
            $outArr = array(
                'status'=> 306,
            );
            echo json_encode($outArr); exit;
        }
        if($dengjiCodeInfo['use_status'] == 1){
            $outArr = array(
                'status'=> 307,
            );
            echo json_encode($outArr); exit;
        }
        $dengjiInfo = C::t("#tom_tcdaojia#tom_tcdaojia_dengji")->fetch_by_id($dengjiCodeInfo['dengji_id']);
        if(is_array($dengjiInfo) && !empty($dengjiInfo)){
            $fabuPayStatus = 2;
        }else{
            $outArr = array(
                'status'=> 308,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $insertData = array();
    $insertData['site_id']            = $site_id;
    $insertData['user_id']            = $user_id;
    $insertData['type']               = $type;
    $insertData['name']               = $name;
    $insertData['xm']                 = $xm;
    $insertData['tel']                = $tel;
    $insertData['start_time']         = $start_time;
    $insertData['end_time']           = $end_time;
    $insertData['cate_ids']           = '|'.$cate_ids.'|';
    $insertData['vip_id']             = 0;
    if($dengjiInfo['id'] > 0){
        $insertData['dengji_id']          = $dengjiInfo['id'];
    }
    $insertData['area_ids']           = '|'.$area_ids.'|';
    $insertData['street_ids']         = '|'.$street_ids.'|';
    $insertData['address']            = $address;
    $insertData['latitude']           = $latitude;
    $insertData['longitude']          = $longitude;
    $insertData['content']            = $content;
    if($fabuPayStatus == 1){
        $insertData['pay_status']     = 1;
    }else{
        $insertData['pay_status']     = 0;
    }
    $insertData['status']             = 1;
    if($tcdaojiaConfig['ruzhu_must_shenhe'] == 1){
        $insertData['shenhe_status']       = 2;
    }else{
        $insertData['shenhe_status']       = 1;
    }
    $insertData['refresh_time']       = TIMESTAMP;
    $insertData['add_time']           = TIMESTAMP;
    if(C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->insert($insertData)){

        $servicer_id = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->insert_id();
        
        if(!empty($picurl)){
            $insertData = array();
            $insertData['servicer_id']  = $servicer_id;
            $insertData['type']         = 3;
            $insertData['picurl']       = $picurl;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tcdaojia#tom_tcdaojia_photo')->insert($insertData);
        }
        
        if(!empty($wxpicurl)){
            $insertData = array();
            $insertData['servicer_id']  = $servicer_id;
            $insertData['type']         = 4;
            $insertData['picurl']       = $wxpicurl;
            $insertData['add_time']     = TIMESTAMP;
            C::t('#tom_tcdaojia#tom_tcdaojia_photo')->insert($insertData);
        }
        
        if(is_array($photoArr) && !empty($photoArr)){
            foreach ($photoArr as $key => $value){
                $insertData = array();
                $insertData['servicer_id']   = $servicer_id;
                $insertData['type']          = 5;
                $insertData['picurl']        = $value;
                $insertData['add_time']      = TIMESTAMP;
                C::t('#tom_tcdaojia#tom_tcdaojia_photo')->insert($insertData);
            }
        }
        
        ## pay start
        if($fabuPayStatus == 1){
            
            if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
                $outArr = array(
                    'status'=> 302,
                );
                echo json_encode($outArr); exit;
            }
            
            $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);
            
            $insertData = array();
            $insertData['site_id']          = $site_id;
            $insertData['order_no']         = $order_no;
            $insertData['type']             = 8;
            $insertData['user_id']          = $user_id;
            $insertData['openid']           = $userInfo['openid'];
            $insertData['servicer_id']      = $servicer_id;
            $insertData['dengji_id']        = $dengjiInfo['id'];
            $insertData['pay_price']        = $pay_price;
            $insertData['order_status']     = 1;
            $insertData['order_time']       = TIMESTAMP;
            if(C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert($insertData)){
                $order_id = C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert_id();

                $insertData = array();
                $insertData['plugin_id']       = 'tom_tcdaojia';      
                $insertData['order_no']        = $order_no;            
                $insertData['goods_id']        = $order_id;           
                $insertData['goods_name']      = lang('plugin/tom_tcdaojia','ruzhu_servicer');
                $insertData['goods_beizu']     = lang('plugin/tom_tcdaojia','ruzhu_servicer');
                $insertData['goods_url']       = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=servicerinfo&servicer_id={$servicer_id}";
                $insertData['succ_back_url']   = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=edit&servicer_id={$servicer_id}&fromlist=mylist";
                $insertData['fail_back_url']   = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=ruzhu";
                $insertData['allow_alipay']    = 1;         
                $insertData['pay_price']       = $pay_price;    
                $insertData['order_status']    = 1;             
                $insertData['add_time']        = TIMESTAMP;     
                if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
                    $outArr = array(
                        'pay_status' => 1,
                        'status'    => 200,
                        'payurl' => "plugin.php?id=tom_pay&order_no=".$order_no,
                    );
                    echo json_encode($outArr); exit;
                    
                }else{
                    $outArr = array(
                        'status'=> 303,
                    );
                    echo json_encode($outArr); exit;
                }

            }else{
                $outArr = array(
                    'status'=> 304,
                );
                echo json_encode($outArr); exit;
            }

        }else{
            
            if($fabuPayStatus == 2){
                $updateData = array();
                $updateData['dengji_status']   = 1;
                $updateData['dengji_time']     = TIMESTAMP + 86400 * $dengjiInfo['days'];
                C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->update($servicer_id, $updateData);
                
                $updateData = array();
                $updateData['use_status']   = 1;
                $updateData['user_id']      = $user_id;
                $updateData['servicer_id']  = $servicer_id;
                $updateData['use_time']     = TIMESTAMP;
                C::t('#tom_tcdaojia#tom_tcdaojia_dengji_code')->update($dengjiCodeInfo['id'], $updateData);

                $insertData = array();
                $insertData['user_id']          = $user_id;
                $insertData['servicer_id']      = $servicer_id;
                $insertData['type']             = 2;
                $insertData['dengji_code_id']   = $dengjiCodeInfo['id'];
                $insertData['log_time']         = TIMESTAMP;
                C::t('#tom_tcdaojia#tom_tcdaojia_dengji_log')->insert($insertData);
            }
            
            if(!empty($tongchengConfig['template_id']) && $tcdaojiaConfig['ruzhu_must_shenhe'] == 1 ){
                
                $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);

                include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
                $access_token = $weixinClass->get_access_token();

                if($access_token && !empty($toUser['openid'])  ){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList");
                    $smsData = array(
                        'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcdaojia','shenhe_ruzhu_template_first'),
                        'keyword1'      => $tcdaojiaConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                        'remark'        => ''
                    );
                    $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
                }

                $daojiamanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcdaojiaConfig['daojiamanage_user_id']);
                $access_token = $weixinClass->get_access_token();
                if($access_token && !empty($daojiamanageUserInfo['openid'])){
                    $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList");
                    $smsData = array(
                        'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcdaojia','shenhe_ruzhu_template_first'),
                        'keyword1'      => $tcdaojiaConfig['plugin_name'],
                        'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                        'remark'        => ''
                    );

                    @$r = $templateSmsClass->sendSms01($daojiamanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
                }
            }
        }
        
        ## pay end
        $outArr = array(
            'pay_status' => 0,
            'status'=> 200,
        );
        echo json_encode($outArr); exit;
        
    }else{
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
}else if($_GET['act'] == "dengji" && submitcheck('dengji_id')){
    
    $servicer_id   = isset($_GET['servicer_id'])? intval($_GET['servicer_id']):0;
    $dengji_id     = isset($_GET['dengji_id'])? intval($_GET['dengji_id']):0;
    
    $servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($servicer_id);
    $userInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']);
    $dengjiInfo = C::t('#tom_tcdaojia#tom_tcdaojia_dengji')->fetch_by_id($dengji_id);
    
    if(empty($dengjiInfo) || empty($userInfo) || empty($servicerInfo)){
        $outArr = array(
            'status'=> 404,
        );
        echo json_encode($outArr); exit;
    }
    
    if($dengjiInfo['xiangou_num'] > 0){
        $dengjiLogCount = C::t('#tom_tcdaojia#tom_tcdaojia_dengji_log')->fetch_all_count(" AND dengji_id = {$dengjiInfo['id']} AND user_id = {$userInfo['id']} AND type = 1 ");
        if($dengjiLogCount >= $dengjiInfo['xiangou_num']){
            $outArr = array(
                'status'=> 301,
            );
            echo json_encode($outArr); exit;
        }
    }
    
    $pay_price = $dengjiInfo['price'];
    
    if($pay_price <= 0){
        $outArr = array(
            'status'=> 305,
        );
        echo json_encode($outArr); exit;
    }
    
    if(!file_exists(DISCUZ_ROOT.'./source/plugin/tom_pay/tom_pay.inc.php')){
        $outArr = array(
            'status'=> 302,
        );
        echo json_encode($outArr); exit;
    }

    $order_no = "TC".date("YmdHis")."-".mt_rand(111111, 666666);

    $insertData = array();
    $insertData['site_id']          = $servicerInfo['site_id'];
    $insertData['order_no']         = $order_no;
    $insertData['type']             = 9;
    $insertData['user_id']          = $userInfo['id'];
    $insertData['openid']           = $userInfo['openid'];
    $insertData['servicer_id']      = $servicer_id;
    $insertData['dengji_id']        = $dengjiInfo['id'];
    $insertData['pay_price']        = $pay_price;
    $insertData['order_status']     = 1;
    $insertData['order_time']       = TIMESTAMP;
    if(C::t('#tom_tcdaojia#tom_tcdaojia_order')->insert($insertData)){

        $insertData = array();
        $insertData['plugin_id']       = 'tom_tcdaojia';
        $insertData['order_no']        = $order_no;
        $insertData['goods_id']        = $servicer_id;
        $insertData['goods_name']      = lang('plugin/tom_tcdaojia','servicer_buy_dengji');
        $insertData['goods_beizu']     = lang('plugin/tom_tcdaojia','servicer_buy_dengji');
        $insertData['goods_url']       = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=buydengji&servicer_id={$servicer_id}";
        $insertData['succ_back_url']   = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=buydengji&servicer_id={$servicer_id}";
        $insertData['fail_back_url']   = "plugin.php?id=tom_tcdaojia&site={$site_id}&mod=buydengji&servicer_id={$servicer_id}";
        $insertData['allow_alipay']    = 1;
        $insertData['pay_price']       = $pay_price;
        $insertData['order_status']    = 1;
        $insertData['add_time']        = TIMESTAMP;
        if(C::t('#tom_pay#tom_pay_order')->insert($insertData)){
            $outArr = array(
                'status'    => 200,
                'payurl'    => "plugin.php?id=tom_pay&order_no=".$order_no,
                'pay_status'=> 1,
            );
            echo json_encode($outArr); exit;
        }else{
            $outArr = array(
                'status'=> 303,
            );
            echo json_encode($outArr); exit;
        }

    }else{
        $outArr = array(
            'status'=> 304,
        );
        echo json_encode($outArr); exit;
    }
}else{
    $outArr = array(
        'status'=> 111111,
    );
    echo json_encode($outArr); exit;
}