<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$Lang = $scriptlang['tom_tcdaojia'];
$adminBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcdaojia&pmod=admin'; 
$adminListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=tom_tcdaojia&pmod=admin';
$adminFromUrl = 'plugins&operation=config&do=' . $pluginid . '&identifier=tom_tcdaojia&pmod=admin';

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$nowMonthTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),1,dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;


if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tongcheng/tom_tongcheng.inc.php')){
}else{
    echo '<a href="https://dism.taobao.com/?@tom_tongcheng.plugin">https://dism.taobao.com/?@tom_tongcheng.plugin</a>';exit;
}

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/config/config.utf8.php';
}

include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/class/tom.form.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/class/function.a.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/tom.upload.php';
include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/class/function.core.php';
$tcdaojiaConfig = get_tcdaojia_config($pluginid);
$Lang = formatLang($Lang);

$tcyikatongConfig = array();
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_tcyikatong/tom_tcyikatong.inc.php')){
    $tcyikatongPlugin = C::t('#tom_tcdaojia#common_plugin')->fetch_by_identifier('tom_tcyikatong');
    $tcyikatongConfig = get_plugin_config($tcyikatongPlugin['pluginid']);
}
$tongchengPlugin = C::t('#tom_tcdaojia#common_plugin')->fetch_by_identifier('tom_tongcheng');
$tongchengConfig = get_plugin_config($tongchengPlugin['pluginid']);
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
$weixinClass = new weixinClass($appid,$appsecret);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';

if($_GET['tmod'] == 'servicer'){
   
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/servicer.php';

}else if($_GET['tmod'] == 'needs'){
   
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/needs.php';

}else if($_GET['tmod'] == 'goods'){
   
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/goods.php';

}else if($_GET['tmod'] == 'cate'){
   
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/cate.php';

}else if($_GET['tmod'] == 'focuspic'){
  
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/focuspic.php';
    
}else if($_GET['tmod'] == 'diynav'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/diynav.php';
    
}else if($_GET['tmod'] == 'vip'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/vip.php';
    
}else if($_GET['tmod'] == 'order'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/order.php';
    
}else if($_GET['tmod'] == 'service_order'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/service_order.php';
    
}else if($_GET['tmod'] == 'pinglun'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/pinglun.php';
    
}else if($_GET['tmod'] == 'report'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/report.php';
    
}else if($_GET['tmod'] == 'option'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/option.php';
    
}else if($_GET['tmod'] == 'team'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/team.php';
    
}else if($_GET['tmod'] == 'doDaoGoods'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/doDaoGoods.php';
    
}else if($_GET['tmod'] == 'doDaoNeeds'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/doDaoNeeds.php';
    
}else if($_GET['tmod'] == 'pinglunReply'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/pinglunReply.php';
    
}else if($_GET['tmod'] == 'common'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/common.php';
    
}else if($_GET['tmod'] == 'dengji'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/dengji.php';
    
}else if($_GET['tmod'] == 'dengji_code'){
    
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/dengji_code.php';
    
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/admin/servicer.php';
}