<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/plugin');

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $sql = '';
    
    $tom_tcdaojia_order_field = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_field();
    if (!isset($tom_tcdaojia_order_field['wei_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_order` ADD `wei_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcdaojia_order_field['hexiao_no'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_order` ADD `hexiao_no` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcdaojia_order_field['dengji_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_order` ADD `dengji_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcdaojia_order_field['tj_hehuoren_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_order` ADD `tj_hehuoren_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcdaojia_order_field['vip_pay_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_order` ADD `vip_pay_status` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcdaojia_order_field['is_weikuan'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_order` ADD `is_weikuan` int(11) DEFAULT '0';\n";
    }
    
    $tom_tcdaojia_photo_field = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_field();
    if (!isset($tom_tcdaojia_photo_field['hexiao_log_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_photo` ADD `hexiao_log_id` int(11) DEFAULT '0';\n";
    }
    
    $tom_tcdaojia_servicer_field = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_all_field();
    if (!isset($tom_tcdaojia_servicer_field['dengji_id'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_servicer` ADD `dengji_id` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcdaojia_servicer_field['dengji_time'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_servicer` ADD `dengji_time` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcdaojia_servicer_field['dengji_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_servicer` ADD `dengji_status` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcdaojia_servicer_field['jie_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_servicer` ADD `jie_status` int(11) DEFAULT '1';\n";
    }
    if (!isset($tom_tcdaojia_servicer_field['pay_status'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_servicer` ADD `pay_status` int(11) DEFAULT '0';\n";
    }
    
    $tom_tcdaojia_goods_field = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_field();
    if (!isset($tom_tcdaojia_goods_field['hehuoren_tg_open'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_goods` ADD `hehuoren_tg_open` tinyint(4) DEFAULT '0';\n";
    }
    if (!isset($tom_tcdaojia_goods_field['hehuoren_tg_type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_goods` ADD `hehuoren_tg_type` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcdaojia_goods_field['hehuoren_fc_scale'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_goods` ADD `hehuoren_fc_scale` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcdaojia_goods_field['hehuoren_fc_scale2'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_goods` ADD `hehuoren_fc_scale2` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcdaojia_goods_field['open_vip'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_goods` ADD `open_vip` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcdaojia_goods_field['vip_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_goods` ADD `vip_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    if (!isset($tom_tcdaojia_goods_field['haibao_type'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_goods` ADD `haibao_type` int(11) DEFAULT '1';\n";
    }
    if (!isset($tom_tcdaojia_goods_field['haibao_picurl'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_goods` ADD `haibao_picurl` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcdaojia_goods_field['qrcode_location'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_goods` ADD `qrcode_location` int(11) DEFAULT '0';\n";
    }
    if (!isset($tom_tcdaojia_goods_field['haibao_msg'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_goods` ADD `haibao_msg` varchar(255) DEFAULT NULL;\n";
    }
    if (!isset($tom_tcdaojia_goods_field['virtual_sale_num'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_goods` ADD `virtual_sale_num` int(11) DEFAULT '0';\n";
    }

    $tom_tcdaojia_goods_option_field = C::t('#tom_tcdaojia#tom_tcdaojia_goods_option')->fetch_all_field();
    if (!isset($tom_tcdaojia_goods_option_field['vip_price'])) {
        $sql .= "ALTER TABLE `pre_tom_tcdaojia_goods_option` ADD `vip_price` decimal(10,2) DEFAULT '0.00';\n";
    }
    
    if (!empty($sql)){
        runquery($sql);
    }

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_tom_tcdaojia_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `servicer_xieyi` mediumtext,
  `needs_xieyi` mediumtext,
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
        
CREATE TABLE IF NOT EXISTS `pre_tom_tcdaojia_dengji` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `days` int(11) DEFAULT '0',
  `days_msg` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `fabu_goods_num` int(11) DEFAULT '0',
  `xiangou_num` int(11) DEFAULT '0',
  `status` tinyint(4) unsigned DEFAULT '0',
  `dsort` int(11) DEFAULT '10',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
   
CREATE TABLE IF NOT EXISTS `pre_tom_tcdaojia_dengji_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dengji_id` int(11) DEFAULT '0',
  `code` varchar(255) DEFAULT NULL,
  `use_status` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `servicer_id` int(11) DEFAULT '0',
  `use_time` int(11) unsigned DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
       
CREATE TABLE IF NOT EXISTS `pre_tom_tcdaojia_dengji_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `servicer_id` int(11) DEFAULT '0',
  `type` tinyint(4) DEFAULT '0',
  `dengji_id` int(11) DEFAULT '0',
  `dengji_code_id` int(11) DEFAULT '0',
  `log_time` int(11) unsigned DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
       
CREATE TABLE IF NOT EXISTS `pre_tom_tcdaojia_order_hexiao_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `hexiao_num` int(11) DEFAULT '0',
  `hexiao_user_id` int(11) DEFAULT '0',
  `hexiao_beizu` text,
  `hexiao_time` int(11) DEFAULT '0',
  `part1` varchar(255) DEFAULT NULL,
  `part2` varchar(255) DEFAULT NULL,
  `part3` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

    runquery($sql);
    

    echo 'OK';exit;
    
}else{
    exit('Access Denied');
}