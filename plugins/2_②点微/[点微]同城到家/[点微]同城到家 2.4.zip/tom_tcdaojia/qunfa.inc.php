<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$site_id = intval($_GET['site'])>0? intval($_GET['site']):1;

session_start();
loaducenter();
$formhash = FORMHASH;
$tcdaojiaConfig = $_G['cache']['plugin']['tom_tcdaojia'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;
$appid = trim($tongchengConfig['wxpay_appid']);
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
$sql_in_site_ids = $site_id;

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/link.func.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/login_ajax.php';

include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.html.php';

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/config/config.utf.php';
}

if($_GET['act'] == 'qunfa'){

    $needs_id = isset($_GET['needs_id'])? intval($_GET['needs_id']): 0;
    
    $needsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($needs_id);
    
    if($needsInfo['qunfa_status'] == 1){
        echo '100';exit;
    }
    
    $templateSmsRunUrl = $_G['siteurl']."plugin.php?id=tom_tcdaojia:qunfa&site={$site_id}&act=qunfa_run&needs_id={$needs_id}";
    
    if(isset($_SESSION['tom_tcdaojia_needs_id'.$needs_id]) && $_SESSION['tom_tcdaojia_needs_id'.$needs_id] == 1){
        echo '100';exit;
    }else{
        $_SESSION['tom_tcdaojia_needs_id'.$needs_id] = 1;
    }
    
    $whereArea = "";
    if($needsInfo['area_id'] > 0 && $needsInfo['street_id'] == 0){
        $whereArea = " AND (area_ids LIKE '%|{$needsInfo['area_id']}|%' ) ";
    }
    if($needsInfo['area_id'] > 0 && $needsInfo['street_id'] > 0){
        $whereArea = " AND (street_ids LIKE '%|{$needsInfo['street_id']}|%' OR street_ids LIKE '%|all{$needsInfo['area_id']}|%' )";
    }
    
    $servicerListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_all_list(" AND jie_status=1 AND status=1 AND shenhe_status=1 AND cate_ids LIKE '%|{$needsInfo['cate_id']}|%' {$whereArea} ", 'ORDER BY id DESC', 0, 1000);
    if(is_array($servicerListTmp) && !empty($servicerListTmp)){
        
        foreach($servicerListTmp as $key => $value){
            $qunfaLogInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_qunfa_log')->fetch_all_list(" AND user_id = {$value['user_id']} AND needs_id = {$needs_id} ");
            if($qunfaLogInfoTmp && $qunfaLogInfoTmp['0']['id'] > 0){ }else{
                
                $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
                
                $insertData = array();
                $insertData['needs_id']     = $needs_id;
                $insertData['user_id']      = $value['user_id'];
                $insertData['openid']       = $userInfoTmp['openid'];
                $insertData['status']       = 0;
                C::t('#tom_tcdaojia#tom_tcdaojia_qunfa_log')->insert($insertData);
            }
        }
        
        DB::query("UPDATE ".DB::table('tom_tcdaojia_needs')." SET qunfa_status=1 WHERE id='{$needs_id}'", 'UNBUFFERED');
    
        tom_html_get($templateSmsRunUrl);
        
    }
    
    $_SESSION['tom_tcdaojia_needs_id'.$needs_id] = 0;
    
    echo '200';exit;
    
}else if($_GET['act'] == 'admin_qunfa'){
    
    if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    }else{
        echo 'no uid';exit;
    }

    $needs_id = isset($_GET['needs_id'])? intval($_GET['needs_id']): 0;

    $needsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($needs_id);
    
    $templateSmsRunUrl = $_G['siteurl']."plugin.php?id=tom_tcdaojia:qunfa&site={$site_id}&act=qunfa_run&needs_id={$needs_id}";
    
    if(isset($_SESSION['tom_tcdaojia_needs_id'.$needs_id]) && $_SESSION['tom_tcdaojia_needs_id'.$needs_id] == 1){
        echo '100';exit;
    }else{
        $_SESSION['tom_tcdaojia_needs_id'.$needs_id] = 1;
    }
    
    $whereArea = "";
    if($needsInfo['area_id'] > 0 && $needsInfo['street_id'] == 0){
        $whereArea = " AND (area_ids LIKE '%|{$needsInfo['area_id']}|%' ) ";
    }
    if($needsInfo['area_id'] > 0 && $needsInfo['street_id'] > 0){
        $whereArea = " AND (street_ids LIKE '%|{$needsInfo['street_id']}|%' OR street_ids LIKE '%|all{$needsInfo['area_id']}|%' )";
    }
    
    $servicerListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_all_list(" AND jie_status=1 AND status=1 AND shenhe_status=1 AND cate_ids LIKE '%|{$needsInfo['cate_id']}|%' {$whereArea} ", 'ORDER BY id DESC', 0, 1000);
    if(is_array($servicerListTmp) && !empty($servicerListTmp)){
        
        foreach($servicerListTmp as $key => $value){
            $qunfaLogInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_qunfa_log')->fetch_all_list(" AND user_id = {$value['user_id']} AND needs_id = {$needs_id} ");
            if($qunfaLogInfoTmp && $qunfaLogInfoTmp['0']['id'] > 0){ }else{
                
                $userInfoTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($value['user_id']);
                
                $insertData = array();
                $insertData['needs_id']     = $needs_id;
                $insertData['user_id']      = $value['user_id'];
                $insertData['openid']       = $userInfoTmp['openid'];
                $insertData['status']       = 0;
                C::t('#tom_tcdaojia#tom_tcdaojia_qunfa_log')->insert($insertData);
            }
        }
        
        DB::query("UPDATE ".DB::table('tom_tcdaojia_needs')." SET qunfa_status=1 WHERE id='{$needs_id}'", 'UNBUFFERED');
    
        $return = tom_html_get($templateSmsRunUrl);
        
    }
    
    $_SESSION['tom_tcdaojia_needs_id'.$needs_id] = 0;
    
    if($return){
        echo $return;exit;
    }else{
        var_dump($return);exit;
    }
    
}else if($_GET['act'] == 'qunfa_run'){

    ignore_user_abort(true);
    set_time_limit(0);

    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/class/log.class.php';

    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $needs_id = isset($_GET['needs_id'])? intval($_GET['needs_id']): 0;
    
    if($page == 1){
        Log::DEBUG("[sms]--------------------- new -------------------------");
    }else if($page == 101){
        Log::DEBUG("[sms]--------------------- over 101 -------------------------");
        exit;
    }
    Log::DEBUG("[sms]needs_id id:" .$needs_id);
    Log::DEBUG("[sms]page:" .$page);
    Log::DEBUG("[sms]client IP:" .$_G['clientip']);
    Log::DEBUG("[sms]start:" .time());
    $start_time = time();

    $pagesize = 10;
    $start = ($page-1)*$pagesize;
    $needsInfo = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_by_id($needs_id);
    $qunfaLogListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_qunfa_log')->fetch_all_list(" AND needs_id = {$needs_id} ", 'ORDER BY id DESC', $start, $pagesize); 
    
    $appid = trim($tongchengConfig['wxpay_appid']);  
    $appsecret = trim($tongchengConfig['wxpay_appsecret']);
    
    $template_id = $tongchengConfig['template_id'];
    
    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
    $weixinClass = new weixinClass($appid,$appsecret);

    include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
    $all_num = $run_num = $ok_num = $no_num = 0;
    $overStatus = 0;
    if(is_array($qunfaLogListTmp) && !empty($qunfaLogListTmp)){
        foreach($qunfaLogListTmp as $key => $value){
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($value['openid']) && $value['status'] == 0){
                
                $tcdaojia_template_url     = tom_link_replace($_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=needsinfo&needs_id={$needs_id}");
                $templateSmsClass          = new templateSms($access_token, $tcdaojia_template_url);
                $needs_tz_template_first   = str_replace("{TITLE}",$needsInfo['content'], lang('plugin/tom_tcdaojia', 'qunfa_template_sms'));

                $smsData = array(
                    'first'         => $needs_tz_template_first,
                    'keyword1'      => $tcdaojiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i",$tomSysOffset),
                    'remark'        => lang('plugin/tom_tcdaojia', 'qunfa_template_remark')
                );
                @$r = $templateSmsClass->sendSms01($value['openid'], $template_id,$smsData);
                if($r){
                    $ok_num ++;
                    $updateData = array();
                    $updateData['status']   = 1;
                    $updateData['log_time'] = TIMESTAMP;
                    C::t('#tom_tcdaojia#tom_tcdaojia_qunfa_log')->update($value['id'], $updateData);
                }else{
                    $updateData = array();
                    $updateData['status']   = 2;
                    $updateData['log_time'] = TIMESTAMP;
                    C::t('#tom_tcdaojia#tom_tcdaojia_qunfa_log')->update($value['id'], $updateData);
                }
                
                $run_num ++;
            }
            $all_num++;
        }
    }else{
        $overStatus = 1;
    }
    
    $end_time = time();
    $run_time = $end_time - $start_time;
    
    Log::DEBUG("[sms]all num:" .$all_num);
    Log::DEBUG("[sms]run num:" .$run_num);
    Log::DEBUG("[sms]ok num:" .$ok_num);
    Log::DEBUG("[sms]no num:" .$no_num);
    Log::DEBUG("[sms]run time:" .$run_time);
    Log::DEBUG("[sms]end:" .time());
    
    if($overStatus == 0){
        $page++;
        $templateSmsRunUrl = $_G['siteurl']."plugin.php?id=tom_tcdaojia:qunfa&site={$site_id}&act=qunfa_run&needs_id={$needs_id}&page={$page}";

        Log::DEBUG("[sms]page:" .$templateSmsRunUrl);
        
        $return = tom_html_get($templateSmsRunUrl);
        
        var_dump($return);
    }else{
        Log::DEBUG("[sms]over:" .time());
    }
    
    echo '1';exit;
}