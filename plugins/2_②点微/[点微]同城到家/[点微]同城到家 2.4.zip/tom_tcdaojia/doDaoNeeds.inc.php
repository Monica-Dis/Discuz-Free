<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tcdaojiaConfig  = $_G['cache']['plugin']['tom_tcdaojia'];
$tomSysOffset    = getglobal('setting/timeoffset');

if (CHARSET == 'gbk'){
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/config/config.utf.php';
}

$showQrcode = 0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php')){
    $showQrcode = 1;
    include DISCUZ_ROOT.'./source/plugin/tom_qrcode/phpqrcode/phpqrcode.php';
}

$tempDir = "/source/plugin/tom_tcdaojia/data/infoqrcode/";
$tempDir = DISCUZ_ROOT.'.'.$tempDir;
if(!is_dir($tempDir)){
    mkdir($tempDir, 0777,true);
}else{
    chmod($tempDir, 0755); 
}

$colorArr = array();
$colorArr[1] = 'rgb(236, 75, 10)';
$colorArr[2] = 'rgb(234, 186, 0)';
$colorArr[3] = 'rgb(31, 199, 3)';
$colorArr[4] = 'rgb(3, 199, 137)';
$colorArr[5] = 'rgb(3, 143, 199)';

$page        = isset($_GET['page'])? intval($_GET['page']):1;
$day_type    = isset($_GET['day_type'])? intval($_GET['day_type']):1;
$days        = isset($_GET['days'])? intval($_GET['days']):0;
$hidetel     = isset($_GET['hidetel'])? intval($_GET['hidetel']):0;
$showpic     = isset($_GET['showpic'])? intval($_GET['showpic']):0;

$site_ids   = isset($_GET['site_ids'])? addslashes($_GET['site_ids']):'';
$site_ids_tmp = explode('_', $site_ids);
$site_ids_arr = array();
if(is_array($site_ids_tmp) && !empty($site_ids_tmp)){
    foreach ($site_ids_tmp as $key => $value){
        $value = intval($value);
        if($value > 0){
            $site_ids_arr[] = $value;
        }
    }
}

$cate_ids   = isset($_GET['cate_ids'])? addslashes($_GET['cate_ids']):'';
$cate_ids_tmp = explode('_', $cate_ids);
$cate_ids_arr = array();
if(is_array($cate_ids_tmp) && !empty($cate_ids_tmp)){
    foreach ($cate_ids_tmp as $key => $value){
        $value = intval($value);
        if($value > 0){
            $cate_ids_arr[] = $value;
        }
    }
}

$where = " AND shenhe_status = 1 AND status = 1 ";

if(!empty($site_ids_arr)){
    $where.= " AND site_id IN (".implode(',',$site_ids_arr).") ";
}else if($site_id){
    $where.= " AND site_id = {$site_id} ";
}
if(!empty($cate_ids_arr)){
    $where.= " AND cate_id IN (".implode(',',$cate_ids_arr).") ";
}
if($days > 0){
    $minTime = TIMESTAMP - $days * 86400;
    if($day_type == 1){
        $where.= " AND (refresh_time > {$minTime} OR top_status = 1 ) ";
    }else{
        $where.= " AND (add_time > {$minTime} OR top_status = 1 ) ";
    }
}

$order = " ORDER BY top_status DESC,refresh_time DESC,id DESC ";
if($day_type == 2){
    $order = " ORDER BY top_status DESC,add_time DESC,id DESC ";
}

$pagesize = 1000;
$start = ($page-1)*$pagesize;
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/function.core.php';

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $needsListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_needs')->fetch_all_like_list($where,$order,$start,$pagesize);
    
    $topList = array();
    $needsList = array();
    foreach ($needsListTmp as $key => $value) {
        
        $cateInfo = C::t('#tom_tcdaojia#tom_tcdaojia_cate')->fetch_by_id($value['cate_id']);
        
        $content = lang('plugin/tom_tongcheng', 'doDao_left').$value['content'].lang('plugin/tom_tongcheng', 'doDao_right');
        
        $price = '';
        if($value['price'] > 0){
            $price = '<span style="font-size: 20px;color: rgb(255, 84, 0);">'.$value['price'].lang('plugin/tom_tcdaojia', 'doDao_yuan').'</span>&nbsp;&nbsp;';
        }

        if($hidetel == 1){
            $value['tel'] = substr($value['tel'], 0, 3)."*******";
        }
        
        $firstPicurl = '';
        if($showpic == 1){
            $photoInfoTmp = C::t('#tom_tcdaojia#tom_tcdaojia_photo')->fetch_all_list(" AND needs_id = {$value['id']} AND type = 6"," ORDER BY id ASC ", 0, 1);
            if(is_array($photoInfoTmp) && !empty($photoInfoTmp[0])){
                $firstPicurl = $photoInfoTmp[0]['picurlTmp'];
            }
        }
        
        $address = lang('plugin/tom_tcdaojia', 'doDao_needs_address').$value['address'].'&nbsp;&nbsp;';
        
        $infoqrcodeUrl = '';
        if($showQrcode == 1){
            $infoUrlTmp = $_G['siteurl'].'plugin.php?id=tom_tcdaojia&site='.$value['site_id'].'&mod=needsinfo&needs_id='.$value['id'];
            $infoqrcodeUrl = 'source/plugin/tom_tcdaojia/data/infoqrcode/'.md5($infoUrlTmp).'.png';
            $infoqrcodeImg = DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/data/infoqrcode/'.md5($infoUrlTmp).'.png';
            if(file_exists($infoqrcodeImg)){
            }else{
                QRcode::png($infoUrlTmp,$infoqrcodeImg,'H',5,2);
            }
        }
        
        if($value['top_status'] == 1){
            $topList[$key]['price'] = $price;
            $topList[$key]['content'] = $content;
            $topList[$key]['address'] = $address;
            $topList[$key]['first_picurl'] = $firstPicurl;
            $topList[$key]['tel'] = $value['tel'];
            $topList[$key]['qrcode'] = $infoqrcodeUrl;
        }else{
            $needsList[$cateInfo['id']]['name'] = $cateInfo['name'];
            $needsList[$cateInfo['id']]['data'][$key]['price'] = $price;
            $needsList[$cateInfo['id']]['data'][$key]['address'] = $address;
            $needsList[$cateInfo['id']]['data'][$key]['content'] = $content;
            $needsList[$cateInfo['id']]['data'][$key]['first_picurl'] = $firstPicurl;
            $needsList[$cateInfo['id']]['data'][$key]['tel'] = $value['tel'];
            $needsList[$cateInfo['id']]['data'][$key]['qrcode'] = $infoqrcodeUrl;
        }
    }
    
    $newList = array();
    
    if(is_array($cate_ids_arr) && !empty($cate_ids_arr)){
        foreach ($cate_ids_arr as $key => $value){
            if(isset($needsList[$value])){
                $newList[$value] = $needsList[$value];
            }
        }
    }
    
    if (CHARSET == 'gbk'){
        $outStr = '<meta charset="gbk" /> ';
    }else{
        $outStr = '<meta charset="utf-8" /> ';
    }
    $outStr.= '<section style="font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px;">';
         $outStr.= '<p style="white-space: normal;"><br /></p> ';
         $outStr.= '<p style="max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);">';
           $outStr.= '<span style="max-width: 100%; color: rgb(255, 255, 255); box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(236, 101, 5);">'.lang('plugin/tom_tongcheng', 'doDao_msg1').'</span>';
         $outStr.= '</p> ';
         $outStr.= '<p style="max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);"> ';
           $outStr.= '<span style="max-width: 100%; color: rgb(255, 255, 255); box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(236, 101, 5);">'.lang('plugin/tom_tongcheng', 'doDao_msg2').'</span> ';
         $outStr.= '</p> ';
         $outStr.= '<p style="max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);">'; 
           $outStr.= '<span style="max-width: 100%; color: rgb(236, 101, 5); font-size: 12px; line-height: 19.2px; box-sizing: border-box !important; word-wrap: break-word !important;">'.lang('plugin/tom_tongcheng', 'doDao_jian').'</span> ';
         $outStr.= '</p> ';
         $outStr.= '<p style="margin: 0px;max-width: 100%; min-height: 1em; color: rgb(62, 62, 62); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; letter-spacing: 1px; line-height: 25.6px; white-space: normal; text-align: center; box-sizing: border-box !important; word-wrap: break-word !important; background-color: rgb(255, 255, 255);">';
           $outStr.= '<img style="max-width: 60%;" src="'.$tongchengConfig['fwh_qrcode'].'"/>';
         $outStr.= '</p> <br /> ';
    $outStr.= '</section> ';
    
    if(is_array($topList) && !empty($topList)){
        $outStr.= '<section style="margin: 2em 0em; padding: 0.5em 0.8em; white-space: normal; border: 1px solid '.$colorArr[1].';border-radius: 6px; font-size: 1em; font-family: inherit; font-weight: inherit; text-decoration: inherit; color: rgb(166, 166, 166); background-color: rgb(255, 255, 255);"> ';
           $outStr.= '<section style="margin-top: -1.4em; text-align: center; border: none; line-height: 1.4;"> ';
              $outStr.= '<section style="padding-right: 24px; padding-left: 24px; color: '.$colorArr[1].'; font-size: 30px; font-family: inherit; text-decoration: inherit; border-color: rgb(255, 255, 255); display: inline-block; background-color: rgb(254, 255, 255); "> ';
                 $outStr.= '<section>'.lang('plugin/tom_tongcheng', 'doDao_top_title').'</section> ';
              $outStr.= '</section> ';
           $outStr.= '</section> ';
           $outStr.= '<section style="padding: 16px 0px; color: rgb(32, 32, 32); line-height: 2; font-family: inherit;"> ';
           foreach ($topList as $kk => $vv){
                $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                  $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;"><span style="color: '.$colorArr[1].';">'.lang('plugin/tom_tongcheng', 'doDao_jian').$vv['content'].'</span>'.$vv['price'].'</span> ';
                $outStr.= '</p> ';
                $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                  $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$vv['address'].'<b style="color:#222">'.lang('plugin/tom_tongcheng', 'doDao_msg_lianxi_1').$vv['tel'].lang('plugin/tom_tongcheng', 'doDao_msg_lianxi_2').'</b></span> ';
                $outStr.= '</p> ';
                if(!empty($vv['first_picurl'])){
                    $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                      $outStr.= '<span style="display: block;text-align: center;"><img style="max-width: 100%;" src="'.$vv['first_picurl'].'"/></span> ';
                    $outStr.= '</p> ';
                }
                if(!empty($vv['qrcode'])){
                      $outStr.= '<span style="display: block;text-align: center;"><img style="width:120px;" src="'.$vv['qrcode'].'"/></span> ';
                      $outStr.= '<span style="display: block;text-align: center;color:#999;font-size: 12px;">'.lang('plugin/tom_tongcheng', 'doDao_qrcode_msg').'</span> ';
                  }
           }
           $outStr.= '</section>';
        $outStr.= '</section>';
    }
    
    $color_i = 2;
    if(is_array($newList) && !empty($newList)){
        foreach ($newList as $key => $value){
            $outStr.= '<section style="margin: 2em 0em; padding: 0.5em 0.8em; white-space: normal; border: 1px solid '.$colorArr[$color_i].';border-radius: 6px; font-size: 1em; font-family: inherit; font-weight: inherit; text-decoration: inherit; color: rgb(166, 166, 166); background-color: rgb(255, 255, 255);"> ';
               $outStr.= '<section style="margin-top: -1.4em; text-align: center; border: none; line-height: 1.4;"> ';
                  $outStr.= '<section style="padding-right: 24px; padding-left: 24px; color: '.$colorArr[$color_i].'; font-size: 30px; font-family: inherit; text-decoration: inherit; border-color: rgb(255, 255, 255); display: inline-block; background-color: rgb(254, 255, 255); "> ';
                     $outStr.= '<section>'.$value['name'].'</section> ';
                  $outStr.= '</section> ';
               $outStr.= '</section> ';
               $outStr.= '<section style="padding: 16px 0px; color: rgb(32, 32, 32); line-height: 2; font-family: inherit;"> ';
               foreach ($value['data'] as $kk => $vv){
                    $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                      $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;"><span style="color: '.$colorArr[$color_i].';">'.lang('plugin/tom_tongcheng', 'doDao_jian').$vv['content'].'</span>'.$vv['price'].'</span> ';
                    $outStr.= '</p> ';
                    $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                      $outStr.= '<span style="color: rgb(32, 32, 32); font-family: '.lang('plugin/tom_tongcheng', 'doDao_font_family').'; font-size: 16px; line-height: 2; background-color: rgb(255, 255, 255); word-wrap: break-word; text-decoration: inherit;">'.$vv['address'].'<b style="color:#222">'.lang('plugin/tom_tongcheng', 'doDao_msg_lianxi_1').$vv['tel'].lang('plugin/tom_tongcheng', 'doDao_msg_lianxi_2').'</b></span> ';
                    $outStr.= '</p> ';
                    if(!empty($vv['first_picurl'])){
                        $outStr.= '<p style="word-break:break-all;word-wrap:break-word;border-bottom: 1px dashed rgb(225, 225, 225);margin: 5px 0px;padding-bottom: 5px;"> ';
                          $outStr.= '<span style="display: block;text-align: center;"><img style="max-width: 100%;" src="'.$vv['first_picurl'].'"/></span> ';
                        $outStr.= '</p> ';
                    }
                    if(!empty($vv['qrcode'])){
                        $outStr.= '<span style="display: block;text-align: center;"><img style="width:120px;" src="'.$vv['qrcode'].'"/></span> ';
                        $outStr.= '<span style="display: block;text-align: center;color:#999;font-size: 12px;">'.lang('plugin/tom_tongcheng', 'doDao_qrcode_msg').'</span> ';
                    }
               }
               $outStr.= '</section>';
            $outStr.= '</section>';
            $color_i++;
            if($color_i == 6){
                $color_i = 1;
            }
        }
    }
    
    $doDao_msg3 = lang('plugin/tom_tongcheng', 'doDao_msg3');
    $doDao_msg3 = str_replace('{SITENAME}', $tongchengConfig['plugin_name'], $doDao_msg3);
    $outStr.= '<span style="color:#999;font-size: 14px;"><span style="color:red"> '.lang('plugin/tom_tongcheng', 'doDao_msg_mz').'</span><br /> '.$doDao_msg3.'</span><br /><br />';
    
    echo $outStr;
    exit;
}else{
    exit('Access Denied');
}