<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_tom_tcdaojia_needs extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dism - taobao - com*/
		$this->_table = 'tom_tcdaojia_needs';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
    public function fetch_all_like_list($condition,$orders = '',$start = 0,$limit = 10,$content='') {
        if(!empty($content)){
            $content = str_replace(array('%', '_'),'',$content);
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i AND content LIKE %s $orders LIMIT $start,$limit",array($this->_table,$condition,'%'.$content.'%'));
        }else{
            $data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
        }
		
		return $data;
	}
    
    public function fetch_all_nearby_list($condition,$start = 0,$limit = 10,$lat='',$lng='') {
        $data = DB::fetch_all("SELECT *,acos(cos($lat*pi()/180 )*cos(latitude*pi()/180)*cos($lng*pi()/180 -longitude*pi()/180)+sin($lat*pi()/180 )*sin(latitude*pi()/180))*6370996.81/1000  as distance FROM %t WHERE latitude IS NOT NULL AND longitude IS NOT NULL %i ORDER BY distance ASC,id DESC  LIMIT $start,$limit",array($this->_table,$condition));
		return $data;
	}
    
    public function insert_id() {
		return DB::insert_id();
	}
    
    public function fetch_all_count($condition,$content='') {
        if(!empty($content)){
            $content = str_replace(array('%', '_'),'',$content);
            $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i AND content LIKE %s ",array($this->_table,$condition,'%'.$content.'%'));
        }else{
            $return = DB::fetch_first("SELECT count(*) AS num FROM %t WHERE 1 %i ",array($this->_table,$condition));
        }
		return $return['num'];
	}
	
	public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
}