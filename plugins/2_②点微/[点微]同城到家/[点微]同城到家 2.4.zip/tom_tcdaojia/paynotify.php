<?php

/**
    Copyright 2001-2099 DisM!Ӧ������.
   This is NOT a freeware, use is subject to license terms
   Ӧ�ø���֧�֣�https://dism.taobao.com
   ���²����http://t.cn/Aiux1Jx1
   ΢��֧���ص��ӿ��ļ�
*/

if(!defined('IN_DISCUZ') || !defined('IN_TOM_PAY')) {
	exit('Access Denied');
}

$tcdaojiaConfig = $_G['cache']['plugin']['tom_tcdaojia'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];

$tomSysOffset = getglobal('setting/timeoffset');
$nowDayTime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$tomSysOffset),dgmdate($_G['timestamp'], 'j',$tomSysOffset),dgmdate($_G['timestamp'], 'Y',$tomSysOffset)) - $tomSysOffset*3600;

$appid = trim($tongchengConfig['wxpay_appid']);  
$appsecret = trim($tongchengConfig['wxpay_appsecret']);
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/weixin.class.php';
include DISCUZ_ROOT.'./source/plugin/tom_tongcheng/class/templatesms.class.php';
$weixinClass = new weixinClass($appid,$appsecret);

include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/class/function.core.php';

$orderInfo = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_order_no($order_no);
if($orderInfo && $orderInfo['order_status'] == 1){
    
    $userInfo  = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
    if($orderInfo['needs_id'] > 0){
        $needsInfo = C::t("#tom_tcdaojia#tom_tcdaojia_needs")->fetch_by_id($orderInfo['needs_id']);
    }
    if($orderInfo['goods_id'] > 0){
        $goodsInfo = C::t("#tom_tcdaojia#tom_tcdaojia_goods")->fetch_by_id($orderInfo['goods_id']);
    }
    if($orderInfo['servicer_id'] > 0){
        $servicerInfo = C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->fetch_by_id($orderInfo['servicer_id']);
    }
    
    if($orderInfo['type'] == 1 || $orderInfo['type'] == 2){
        
        $updateData = array();
        $updateData['order_status'] = 3;
        $updateData['pay_time'] = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_order')->update($orderInfo['id'],$updateData);
        
        DB::query("UPDATE ".DB::table('tom_tcdaojia_needs')." SET finish=1 WHERE id = {$needsInfo['id']} ", 'UNBUFFERED');
        
        $nees_jieInfo = C::t("#tom_tcdaojia#tom_tcdaojia_needs_jie")->fetch_all_list("AND needs_id = {$orderInfo['needs_id']} AND servicer_id = {$orderInfo['servicer_id']}","",0,1);
        
        $updateData = array();
        $updateData['status'] = 1;
        $updateData['refresh_time'] = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_needs_jie')->update($nees_jieInfo[0]['id'],$updateData);

        DB::query("UPDATE ".DB::table('tom_tcdaojia_needs_jie')." SET status=2 WHERE needs_id = {$needsInfo['id']} AND servicer_id != {$orderInfo['servicer_id']}  ", 'UNBUFFERED');
    }
    
    if($orderInfo['type'] == 3){
        
        $updateData = array();
        if($goodsInfo['open_yuyue'] == 1){
            $updateData['order_status'] = 2;
        }else{
            $updateData['order_status'] = 3;
        }
        $updateData['pay_time'] = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_order')->update($orderInfo['id'],$updateData);
    }
    
    if($orderInfo['type'] == 4){
        
        $updateData = array();
        $updateData['order_status'] = 2;
        $updateData['pay_time'] = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_order')->update($orderInfo['id'],$updateData);
    }
    
    if($orderInfo['type'] == 5 || $orderInfo['type'] == 6 || $orderInfo['type'] == 7 || $orderInfo['type'] == 8 || $orderInfo['type'] == 9){
        $updateData = array();
        $updateData['order_status'] = 2;
        $updateData['pay_time'] = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_order')->update($orderInfo['id'],$updateData);
    }
    
    if($orderInfo['type'] == 5){
        
        if($needsInfo['top_time'] > TIMESTAMP){
            $top_time = $orderInfo['top_days'] * 86400 + $needsInfo['top_time'];
        }else{
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcdaojia#tom_tcdaojia_needs')->update($orderInfo['needs_id'],$updateData);
        
    }
    if($orderInfo['type'] == 6){
        
        if($goodsInfo['top_time'] > TIMESTAMP){
            $top_time = $orderInfo['top_days'] * 86400 + $goodsInfo['top_time'];
        }else{
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcdaojia#tom_tcdaojia_goods')->update($orderInfo['goods_id'],$updateData);
        
    }
    if($orderInfo['type'] == 7){
        
        if($servicerInfo['top_time'] > TIMESTAMP){
            $top_time = $orderInfo['top_days'] * 86400 + $servicerInfo['top_time'];
        }else{
            $top_time = $orderInfo['top_days'] * 86400 + TIMESTAMP;
        }
        
        $updateData = array();
        $updateData['top_status']   = 1;
        $updateData['top_time']     = $top_time;
        C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->update($orderInfo['servicer_id'],$updateData);
        
    }
    if($orderInfo['type'] == 8){
        
        $dengjiInfo = C::t("#tom_tcdaojia#tom_tcdaojia_dengji")->fetch_by_id($orderInfo['dengji_id']);
        
        $updateData = array();
        $updateData['dengji_id']       = $dengjiInfo['id'];
        $updateData['dengji_status']   = 1;
        $updateData['dengji_time']     = TIMESTAMP + 86400 * $dengjiInfo['days'];
        $updateData['pay_status']      = 2;
        C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->update($orderInfo['servicer_id'],$updateData);
        
        $insertData = array();
        $insertData['user_id']      = $orderInfo['user_id'];
        $insertData['servicer_id']  = $orderInfo['servicer_id'];
        $insertData['type']         = 1;
        $insertData['dengji_id']    = $dengjiInfo['id'];
        $insertData['log_time']     = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_dengji_log')->insert($insertData);
        
    }
    if($orderInfo['type'] == 9){
        
        $dengjiInfo = C::t("#tom_tcdaojia#tom_tcdaojia_dengji")->fetch_by_id($orderInfo['dengji_id']);

        if($servicerInfo['dengji_time'] > TIMESTAMP ){
            $dengji_time = $servicerInfo['dengji_time'] + $dengjiInfo['days']*86400;
        }else{
            $dengji_time = TIMESTAMP + $dengjiInfo['days']*86400;
        }
        
        $updateData = array();
        $updateData['dengji_id']       = $dengjiInfo['id'];
        $updateData['dengji_status']   = 1;
        $updateData['dengji_time']     = $dengji_time;
        $updateData['pay_status']      = 2;
        C::t('#tom_tcdaojia#tom_tcdaojia_servicer')->update($servicerInfo['id'],$updateData);
        
        $insertData = array();
        $insertData['user_id']      = $orderInfo['user_id'];
        $insertData['servicer_id']  = $orderInfo['servicer_id'];
        $insertData['type']         = 1;
        $insertData['dengji_id']    = $dengjiInfo['id'];
        $insertData['log_time']     = TIMESTAMP;
        C::t('#tom_tcdaojia#tom_tcdaojia_dengji_log')->insert($insertData);
        
    }
    
    Log::DEBUG("update order:" . json_encode(iconv_to_utf8($orderInfo['order_no'])));
    
    if($tcdaojiaConfig['open_back_score'] == 1){
        
        $score_yuan = $tongchengConfig['score_yuan'];
        if(!empty($tcdaojiaConfig['score_yuan'])){
            $score_yuan = $tcdaojiaConfig['score_yuan'];
        }
        
        $score = ceil($orderInfo['pay_price']*$score_yuan);
        
        $updateData = array();
        $updateData['score'] = $userInfo['score'] + $score;
        C::t('#tom_tongcheng#tom_tongcheng_user')->update($userInfo['id'],$updateData);

        $insertData = array();
        $insertData['user_id']          = $orderInfo['user_id'];
        $insertData['score_value']      = $score;
        $insertData['old_value']        = $userInfo['score'];
        $insertData['log_type']         = 67;
        $insertData['log_time']         = TIMESTAMP;
        C::t('#tom_tongcheng#tom_tongcheng_score_log')->insert($insertData);

    }
    
    if(($orderInfo['type'] == 1 || $orderInfo['type'] == 2) && !empty($tongchengConfig['template_id'])){
        $toUser = array();
        $toUserTmp = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
        if($toUserTmp && !empty($toUserTmp['openid'])){
            $toUser = $toUserTmp;
        }
        
        $needsUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($needsInfo['user_id']);

        $template_first = str_replace("{XM}",$needsUserInfo['nickname'], lang('plugin/tom_tcdaojia','template_tcdaojia_needs_pay'));
        $template_first = str_replace("{TITLE}",$needsInfo['content'],$template_first);

        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($toUser['openid'])  ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$needsInfo['site_id']}&mod=managerNeedsList");
            $smsData = array(
                'first'         => $template_first,
                'keyword1'      => $tcdaojiaConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
        }

        $daojiamanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcdaojiaConfig['daojiamanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($daojiamanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$needsInfo['site_id']}&mod=managerNeedsList");
            $smsData = array(
                'first'         => $template_first,
                'keyword1'      => $tcdaojiaConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($daojiamanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
        
        $servicerUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($servicerInfo['user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($servicerUserInfo['openid'])){
            $template_servicer_first = str_replace('{TITLE}', $needsInfo['content'], lang('plugin/tom_tcdaojia', 'template_tcdaojia_needs_servicer'));
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$needsInfo['site_id']}&mod=myorder");
            $smsData = array(
                'first'         => $template_servicer_first,
                'keyword1'      => $tcdaojiaConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($servicerUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
    if($orderInfo['type'] == 3 && (!empty($tongchengConfig['template_id']))){
        
        $buyUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
        $saleUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']);

        $template_goods_first = str_replace("{XM}",$buyUserInfo['nickname'], lang('plugin/tom_tcdaojia','template_tcdaojia_goods_pay'));
        $template_goods_first = str_replace("{TITLE}",$goodsInfo['title'],$template_goods_first);

        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($saleUserInfo['openid'])  ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$needsInfo['site_id']}&mod=myorder");
            $smsData = array(
                'first'         => $template_goods_first,
                'keyword1'      => $tcdaojiaConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSms01($saleUserInfo['openid'],$tongchengConfig['template_id'],$smsData);
        }
        
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($buyUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$goodsInfo['site_id']}&mod=order");
            $smsData = array(
                'first'         => lang('plugin/tom_tcdaojia','template_tcdaojia_buy_goods'),
                'keyword1'      => $tcdaojiaConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($buyUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
    if($orderInfo['type'] == 4 && (!empty($tongchengConfig['template_id']))){
        
        $buyUserInfo = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($orderInfo['user_id']);
        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($servicerInfo['user_id']);
        
        $template_weikuan_first = str_replace("{XM}",$buyUserInfo['nickname'], lang('plugin/tom_tcdaojia','template_weikuan_service_msg'));
        
        $upOrderInfo = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_by_sub_order_no($orderInfo['order_no']);
    
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($toUser['openid'])  ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=myorderinfo&order_no={$upOrderInfo['order_no']}");
            $smsData = array(
                'first'         => $template_weikuan_first,
                'keyword1'      => $tcdaojiaConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
                'remark'        => ''
            );
            @$r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
        }
        
        if($upOrderInfo['team_status'] == 1){
            $teamInfo = C::t('#tom_tcdaojia#tom_tcdaojia_team')->fetch_by_id($upOrderInfo['team_id']);
            $teamUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($teamInfo['user_id']);
            $access_token = $weixinClass->get_access_token();
            if($access_token && !empty($teamUser['openid'])  ){
                $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=team_orderinfo&order_no={$upOrderInfo['order_no']}");
                $smsData = array(
                    'first'         => $template_weikuan_first,
                    'keyword1'      => $tcdaojiaConfig['plugin_name'],
                    'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i',$tomSysOffset),
                    'remark'        => ''
                );
                @$r = $templateSmsClass->sendSms01($teamUser['openid'],$tongchengConfig['template_id'],$smsData);
            }
        }
        
    }
    
    if($orderInfo['type'] == 8 && !empty($tongchengConfig['template_id']) && $tcdaojiaConfig['ruzhu_must_shenhe'] == 1 ){
        
        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);

        $access_token = $weixinClass->get_access_token();

        if($access_token && !empty($toUser['openid'])  ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList");
            $smsData = array(
                'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcdaojia','shenhe_ruzhu_template_first'),
                'keyword1'      => $tcdaojiaConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
        }

        $daojiamanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcdaojiaConfig['daojiamanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($daojiamanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=managerList");
            $smsData = array(
                'first'         => '['.$userInfo['nickname'].']'.lang('plugin/tom_tcdaojia','shenhe_ruzhu_template_first'),
                'keyword1'      => $tcdaojiaConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($daojiamanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
    
    if($orderInfo['type'] == 9 && !empty($tongchengConfig['template_id']) ){
        
        $toUser = C::t('#tom_tongcheng#tom_tongcheng_user')->fetch_by_id($tongchengConfig['manage_user_id']);
        
        $template_first = str_replace("{NAME}",$servicerInfo['name'], lang('plugin/tom_tcdaojia','dengji_template_first'));
        $template_first = str_replace("{MONEY}",$orderInfo['pay_price'], $template_first);

        $access_token = $weixinClass->get_access_token();

        if($access_token && !empty($toUser['openid'])  ){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");
            $smsData = array(
                'first'         => $template_first,
                'keyword1'      => $tcdaojiaConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP, 'Y-m-d H:i:s',$tomSysOffset),
                'remark'        => ''
            );
            $r = $templateSmsClass->sendSms01($toUser['openid'],$tongchengConfig['template_id'],$smsData);
        }

        $daojiamanageUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($tcdaojiaConfig['daojiamanage_user_id']);
        $access_token = $weixinClass->get_access_token();
        if($access_token && !empty($daojiamanageUserInfo['openid'])){
            $templateSmsClass = new templateSms($access_token, $_G['siteurl']."plugin.php?id=tom_tcdaojia&site={$site_id}&mod=index");
            $smsData = array(
                'first'         => $template_first,
                'keyword1'      => $tcdaojiaConfig['plugin_name'],
                'keyword2'      => dgmdate(TIMESTAMP,"Y-m-d H:i:s",$tomSysOffset),
                'remark'        => ''
            );

            @$r = $templateSmsClass->sendSms01($daojiamanageUserInfo['openid'], $tongchengConfig['template_id'], $smsData);
        }
    }
}