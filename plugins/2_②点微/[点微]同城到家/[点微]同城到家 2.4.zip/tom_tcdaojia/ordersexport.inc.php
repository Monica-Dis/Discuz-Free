<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

if (CHARSET == 'gbk') {
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/config/config.gbk.php';
}else{
    include DISCUZ_ROOT.'./source/plugin/tom_tcdaojia/config/config.utf8.php';
}

$tcdaojiaConfig = $_G['cache']['plugin']['tom_tcdaojia'];
$tongchengConfig = $_G['cache']['plugin']['tom_tongcheng'];
$tomSysOffset = getglobal('setting/timeoffset');

$goods_id     = isset($_GET['goods_id'])? intval($_GET['goods_id']):0;
$servicer_id  = isset($_GET['servicer_id'])? intval($_GET['servicer_id']):0;
$page = intval($_GET['page'])>0? intval($_GET['page']):1;

$goodsInfo = C::t("#tom_tcdaojia#tom_tcdaojia_goods")->fetch_by_id($goods_id);

$pagesize = 5000;
$start = ($page-1)*$pagesize;

if(isset($_G['uid']) && $_G['uid'] > 0 && $_G['groupid'] == 1){
    
    $where = " AND type IN (1,2,3,4) ";
    if(!empty($goods_id)){
        $where.= " AND goods_id={$goods_id} ";
    }elseif(!empty($servicer_id)){
        $goodslist = C::t('#tom_tcdaojia#tom_tcdaojia_goods')->fetch_all_list("AND servicer_id = {$servicer_id}","ORDER BY id DESC",0,100);
        
        $goods_idArr = array();
         foreach ($goodslist as $key => $value){
             $goods_idArr[] = $value['id'];
        }
        $goods_id_str = implode(',', $goods_idArr);
        $where.= " AND goods_id IN ({$goods_id_str}) ";
    }
    
    $ordersListTmp = C::t('#tom_tcdaojia#tom_tcdaojia_order')->fetch_all_list($where,"ORDER BY id DESC",$start,$pagesize);
    $orderList = array();
    foreach ($ordersListTmp as $key => $value) {
        $orderList[$key] = $value;
        
        $orderList[$key]['order_status'] = $orderStatusArray[$value['order_status']];
       
        if(!empty($goodsInfo['title'])){
            $orderList[$key]['goods_title'] = $goodsInfo['title'];
        }else{
            $orderList[$key]['goods_title'] = '-';
        }
        $orderList[$key]['order_time'] = dgmdate($value['order_time'],"Y-m-d H:i:s",$tomSysOffset);
        if($value['pay_time'] > 0){
            $orderList[$key]['pay_time'] = dgmdate($value['pay_time'],"Y-m-d H:i:s",$tomSysOffset);
        }else{
            $orderList[$key]['pay_time'] = '-';
        }
        if($value['hexiao_time'] > 0){
            $orderList[$key]['hexiao_time'] = dgmdate($value['hexiao_time'],"Y-m-d H:i:s",$tomSysOffset);
        }else{
            $orderList[$key]['hexiao_time'] = '-';
        }
        
        if($value['vip_pay_status'] == 1){
            $orderList[$key]['vip_pay_status'] = lang('plugin/tom_tcdaojia','order_vip_pay_status_1');
        }else{
            $orderList[$key]['vip_pay_status'] = lang('plugin/tom_tcdaojia','order_vip_pay_status_0');
        }
        if($value['is_weikuan'] == 1){
            $orderList[$key]['is_weikuan'] = lang('plugin/tom_tcdaojia','order_is_weikuan_1');
        }else{
            $orderList[$key]['is_weikuan'] = lang('plugin/tom_tcdaojia','order_is_weikuan_0');
        }
        if($value['hexiao_user_id'] > 0){
            $hexiaoUserInfo = C::t("#tom_tongcheng#tom_tongcheng_user")->fetch_by_id($value['hexiao_user_id']);
            $orderList[$key]['hexiao_user_name'] = $hexiaoUserInfo['nickname'];
        }else{
            $orderList[$key]['hexiao_user_name'] = '-';
        }
    }

    $order_no = lang('plugin/tom_tcdaojia','order_order_no');
    $sub_order_no = lang('plugin/tom_tcdaojia','order_sub_order_no');
    $servicer_id = lang('plugin/tom_tcdaojia','servicer_id');
    $goods_id = lang('plugin/tom_tcdaojia','order_goods_id');
    $goods_title = lang('plugin/tom_tcdaojia','order_goods_title_msg');
    $option_name = lang('plugin/tom_tcdaojia','order_option_name');
    $user_xm = lang('plugin/tom_tcdaojia','order_user_xm');
    $user_tel = lang('plugin/tom_tcdaojia','order_user_tel');
    $user_address = lang('plugin/tom_tcdaojia','order_user_address');
    $pay_price = lang('plugin/tom_tcdaojia','order_pay_price');
    $goods_num = lang('plugin/tom_tcdaojia','order_goods_num');
    $vip_pay_status = lang('plugin/tom_tcdaojia','order_vip_pay_status');
    $is_weikuan = lang('plugin/tom_tcdaojia','order_is_weikuan');
    $order_status = lang('plugin/tom_tcdaojia','order_order_status');
    $order_beizu = lang('plugin/tom_tcdaojia','order_beizu');
    $order_hexiao_user_id = lang('plugin/tom_tcdaojia','order_hexiao_user_id');
    $order_hexiao_user_name = lang('plugin/tom_tcdaojia','order_hexiao_user_name');
    $tj_hehuoren_id = lang('plugin/tom_tcdaojia','order_tj_hehuoren_id');
    $order_time = lang('plugin/tom_tcdaojia','order_time');
    $pay_time = lang('plugin/tom_tcdaojia','order_order_pay_time');
    $hexiao_time = lang('plugin/tom_tcdaojia','order_order_hexiao_time');

    $listData[] = array(
        $order_no,
        $sub_order_no,
        $servicer_id,
        $goods_id,
        $goods_title,
        $option_name,
        $user_xm,
        $user_tel,
        $user_address,
        $pay_price,
        $goods_num,
        $vip_pay_status,
        $is_weikuan,
        $order_status,
        $order_beizu,
        $order_hexiao_user_id,
        $order_hexiao_user_name,
        $tj_hehuoren_id,
        $order_time,
        $pay_time,
        $hexiao_time,
    ); 
    foreach ($orderList as $v){
        $lineData = array();
        $lineData[] = $v['order_no'];
        if(!empty($v['sub_order_no'])){
            $lineData[] = $v['sub_order_no'];
        }else{
            $lineData[] = '-';
        }
        $lineData[] = $v['servicer_id'];
        $lineData[] = $v['goods_id'];
        $lineData[] = $v['goods_title'];
        if(!empty($v['option_name'])){
            $lineData[] = $v['option_name'];
        }else{
            $lineData[] = '-';
        }
        $lineData[] = $v['xm'];
        $lineData[] = "'".$v['tel'];
        $lineData[] = $v['address'];
        $v['address'] = str_replace("\r\n", "", $v['address']);
        $v['address'] = str_replace("\n", "", $v['address']);
        $lineData[] = $v['pay_price'];
        $lineData[] = $v['goods_num'];
        $lineData[] = $v['vip_pay_status'];
        $lineData[] = $v['is_weikuan'];
        $lineData[] = $v['order_status'];
        $lineData[] = $v['order_beizu'];
        $lineData[] = $v['hexiao_user_id'];
        $lineData[] = $v['hexiao_user_name'];
        $lineData[] = $v['tj_hehuoren_id'];
        $lineData[] = $v['order_time'];
        $lineData[] = $v['pay_time'];
        $lineData[] = $v['hexiao_time'];
        $listData[] = $lineData;
    }
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition:filename=exportDaojiaOrders.xls");

    foreach ($listData as $fields){
        foreach ($fields as $k=> $v){
            $str = @diconv("$v",CHARSET,"GB2312");
            echo $str ."\t";
        }
        echo "\n";
    }
    exit;
}else{
    exit('Access Denied');
}