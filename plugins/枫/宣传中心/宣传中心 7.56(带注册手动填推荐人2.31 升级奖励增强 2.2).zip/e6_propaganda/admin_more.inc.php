<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
header("Location: http://addon.dismall.com/?@1790.developer");
exit;
?>