<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require 'e6_propaganda.func.php';
print <<<EOT
<link rel="stylesheet" href="source/plugin/e6_propaganda/static/css/extra.css?version={$version}">
<script src="source/plugin/e6_propaganda/static/js/j.js?version={$version}"></script>
EOT;
$extra_arr = array(
	'activation'=>	array(
		'id'			=>	'49849',
		'title'			=>	$e6_lang['extra_activation_title'],
		'description'	=>	$e6_lang['extra_activation'],
		
	),
	'condition'=>	array(
		'id'			=>	'73650',
		'title'			=>	$e6_lang['extra_condition_title'],
		'description'	=>	$e6_lang['extra_condition'],	
	),
	'vip'		=>	array(
		'id'			=>	'49797',
		'title'			=>	$e6_lang['extra_vip_title'],
		'description'	=>	$e6_lang['extra_vip'],
	),
	'area'		=>	array(
		'id'			=>	'50037',
		'title'			=>	$e6_lang['extra_area_title'],
		'description'	=>	$e6_lang['extra_area'],
	),
	'withdraw'	=>	array(
		'id'			=>	'50060',
		'title'			=>	$e6_lang['extra_withdraw_title'],
		'description'	=>	$e6_lang['extra_withdraw'],
	),
	'register'	=>	array(
		'id'			=>	'50242',
		'title'			=>	$e6_lang['extra_register_title'],
		'description'	=>	$e6_lang['extra_register'],
	),
	'top'		=>	array(
		'id'			=>	'64285',
		'title'			=>	$e6_lang['extra_top_title'],
		'description'	=>	$e6_lang['extra_top'],
	),
	'domain'	=>	array(
		'id'			=>	'66368',
		'title'			=>	$e6_lang['extra_domain_title'],
		'description'	=>	$e6_lang['extra_domain'],
	),
	'reward'	=>	array(
		'id'			=>	'66733',
		'title'			=>	$e6_lang['extra_reward_title'],
		'description'	=>	$e6_lang['extra_reward'],
	),
);
foreach ($extra_arr as $key => $value) {
	if (file_exists(DISCUZ_ROOT . "source/plugin/e6_propaganda/static/js/{$key}.js")) {
		echo "<script src=\"source/plugin/e6_propaganda/static/js/{$key}.js?version={$version}\"></script>";
	}
	if (file_exists(DISCUZ_ROOT . "source/plugin/e6_propaganda/static/css/{$key}.css")) {
		echo "<link rel=\"stylesheet\" href=\"source/plugin/e6_propaganda/static/css/{$key}.css?version={$version}\">";
	}
}
if (submitcheck('e6_submit')) {
	!$e6_propaganda && $e6_propaganda = array();
	!$_GET['setting'] && $_GET['setting'] = array();
	$msg = 'setting_update_succeed';
	foreach ($extra_arr as $key => $value) {
		if (file_exists($pro_module . $key . '_extra.php')) {
			require $pro_module . $key . '_extra.php';
			if (function_exists('pro_' . $key . '_extra_admin_submit')){
				call_user_func('pro_' . $key . '_extra_admin_submit');
			}
		}
	}
	pro_save_setting($e6_propaganda, $_GET['setting'], $msg);
}
$text = dfsockopen('http://addon.dismall.com/?@e6_propaganda.plugin.doc/HuoDong', 0, '', '', false, '', 999);
if ($_G['charset'] == 'utf-8') {
	$text = iconv("GB2312//IGNORE", "UTF-8", $text);
}
preg_match('/__(.+?)__/i', $text, $new_text);
showformheader('plugins&'.cpurl(false, array('action')));
if ($new_text[1]) {
	require_once libfile('function/discuzcode');
	$new_text = discuzcode(strip_tags($new_text[1]), 1, 0);
	showtableheader("<div style=\"text-align:center;color:red;\">{$new_text}</div>");
}
foreach ($extra_arr as $key => $value) {
	showtableheader($value['title']);
	if (file_exists($pro_module . $key . '_extra.php')) {
		require $pro_module . $key . '_extra.php';
		call_user_func('pro_' . $key . '_extra_admin');
	} else {
		$html = <<<EOT
		<span>{$value['description']}</span>
		<span><a href="http://addon.dismall.com/?@e6_propaganda.plugin.{$value['id']}">{$e6_lang['extra_get']}</a></span>
EOT;
		showtablerow('class="noborder"', 'class="vtop rowform e6_td" colspan="2"', $html);
	}
}
showsubmit('e6_submit');
showtablefooter();
showformfooter();
?>