<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
!$fromversion && $fromversion = $_GET['fromversion'];
if ($fromversion < 5.0) {
	$sql = <<<SQL
	ALTER TABLE `pre_e6_pro_credit` DROP `username`;
	ALTER TABLE `pre_e6_pro_task` CHANGE `grouplimit` `grouplimit` TEXT NOT NULL;
SQL;
	runquery($sql);
	if (file_exists(DISCUZ_ROOT . "data/e6_propaganda.config.php")) {
		include DISCUZ_ROOT . "data/e6_propaganda.config.php";
		C::t('common_setting')->update_batch(array('e6_propaganda' => serialize(daddslashes($e6_propaganda))));
		updatecache('setting');
		@unlink(DISCUZ_ROOT . '/data/e6_propaganda.config.php');
	}
}
if ($fromversion < 5.1) {
	$sql = <<<SQL
	ALTER TABLE `pre_e6_pro_task` CHANGE `grouplimit` `grouplimit` TEXT NOT NULL;
SQL;
	runquery($sql);	
}
if ($fromversion < 5.4) {
	$username_column = DB::result_first("Describe ".DB::table('e6_pro_credit')." username");
	if ($username_column) {
		runquery("ALTER TABLE `pre_e6_pro_credit` DROP `username`;");
	}
}
if ($fromversion < 5.8) {
	$sql = <<<SQL
	CREATE TABLE IF NOT EXISTS `pre_e6_pro_extra_top` (
	  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
	  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
	  `toptype` tinyint(2) unsigned NOT NULL DEFAULT '0',
	  `money` mediumint(6) NOT NULL DEFAULT '0',
	  `date` int(10) unsigned NOT NULL DEFAULT '0',
	  PRIMARY KEY (`id`),
	  KEY `uid` (`uid`),
	  KEY `toptype` (`toptype`)
	) ENGINE=MyISAM;
SQL;
	runquery($sql);	
}
if ($fromversion < 6.2) {
	!$e6_propaganda && $e6_propaganda = unserialize($_G['setting']['e6_propaganda']);
	$url = preg_replace('/(.*)\/admin\.php\?/i', '', $_SERVER['REQUEST_URI']);
	$step = intval($_GET['step']);
	!$step && $step = 0;
	$url = preg_replace('/&step=' . $step . '/i', '', $url);
	$limit_num = 200;
	$startlimit = $step * $limit_num;
	$endlimit = ($step+1) * $limit_num;
	$limit = "LIMIT {$startlimit},{$endlimit}";
	$step++;
	if (empty($_GET['step'])) {
		$sql = <<<SQL
		ALTER TABLE `pre_e6_pro_user` ADD `vip_arr` TEXT NOT NULL;
		ALTER TABLE `pre_e6_pro_clientorder` CHANGE `price` `price` DECIMAL(9,2) UNSIGNED NOT NULL;
SQL;
		runquery($sql);
	}
	$query = DB::query("SELECT m.uid,m.groupid,m.extgroupids,f.groupterms FROM ".DB::table('e6_pro_user')." p LEFT JOIN ".DB::table('common_member')." m ON p.uid=m.uid LEFT JOIN ".DB::table('common_member_field_forum')."	f ON p.uid=f.uid WHERE p.vip=1 {$limit}");
	while ($rt = DB::fetch($query)) {
		$rt['vip_overdate'] = dunserialize($rt['groupterms']);
		$rt['vip_date'] = $rt['vip_overdate']['ext'];
		if(in_array($rt['groupid'], $e6_propaganda['group_id']) && !array_key_exists($rt['groupid'], $rt['vip_date'])){
			$rt['vip_date'][$rt['groupid']] = '';
		}
		$rt['arr'] = serialize($rt['vip_date']);
		DB::query("UPDATE ".DB::table('e6_pro_user')." SET `vip_arr`='{$rt['arr']}' WHERE `uid`='{$rt['uid']}'");
		$Y = 1;
	}
	if ($Y) {
		cpmsg('&#26356;&#26032;&#20013;......&#31532;'.$step.'&#27493;', "{$url}&step={$step}", 'succeed');
	} else {
		$finish = true;
	}
}
if ($fromversion < 7.0) {
	runquery("ALTER TABLE `pre_e6_pro_user_count` ADD `verify` VARCHAR(255) NOT NULL AFTER `active`;");
	if (!function_exists('pro_save_setting')) {
		require DISCUZ_ROOT . './source/plugin/e6_propaganda/e6_propaganda.func.php';
	}
	$new_setting = current(C::t('common_setting')->fetch_all('e6_propaganda', true));
	$new_setting['global_n'] = 3;
	$new_setting['send_mode'] = 0;
	pro_save_setting(array(), $new_setting, $msg = '');
}
if (file_exists( DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php')) {
	$pluginid = 'e6_propaganda';
	$Hooks = array(
		'forumdisplay_sideBar',
		'forumdisplay_topBar',
	);
	$data = array();
	foreach ($Hooks as $Hook) {
		$data[] = array($Hook => array('plugin' => $pluginid, 'include' => 'api.class.php', 'class' => $pluginid . '_api', 'method' => $Hook));
	}
	require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
	$e6_wechat = new WeChatHook;
	if (method_exists($e6_wechat, 'updateAPIHook')) {
		WeChatHook::updateAPIHook($data);
	}
}
$finish = TRUE;
?>