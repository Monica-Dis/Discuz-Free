e6(function(){
	e6(".itemtitle .tab1 a span").eq(10).append('<img src="source/plugin/e6_propaganda/static/image/new.gif" style="vertical-align:text-top">').css({'color':'red'});
});