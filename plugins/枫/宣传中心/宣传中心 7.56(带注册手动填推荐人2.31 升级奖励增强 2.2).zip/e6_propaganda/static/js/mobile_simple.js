!function(win) {
	var doc = win.document;
	var html = doc.documentElement;
	win.recalc = function() {
		var width = html.clientWidth;
		width && (html.style.fontSize = width / 320 * 100 + "px");
	};
	doc.addEventListener && (win.addEventListener("orientationchange" in win ? "orientationchange": "resize", win.recalc, !1), doc.addEventListener("DOMContentLoaded", win.recalc, !1), win.recalc())
} (this);