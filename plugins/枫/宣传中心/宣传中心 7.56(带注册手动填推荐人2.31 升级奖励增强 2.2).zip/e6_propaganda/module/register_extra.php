<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!function_exists('pro_check_url') && function_exists('pro_lang')) {
	exit(pro_lang('exit'));
}
function pro_register_extra_admin(){
	global $e6_propaganda, $e6_lang;
	showsetting($e6_lang['register_extra'], 'setting[register_extra]', $e6_propaganda['register_extra'], 'radio', 0, 0, $e6_lang['register_extra_comment']);
	showsetting($e6_lang['register_must'], 'setting[register_must]', $e6_propaganda['register_must'], 'radio', 0, 0, $e6_lang['register_must_comment']);
	showsetting($e6_lang['register_username'], 'setting[register_username]', $e6_propaganda['register_username'], 'text', 0, 0, $e6_lang['register_username_comment']);
}
function pro_register_extra_index() {
	global $_G, $config;
	if ($GLOBALS['x'] = $x = intval(getcookie('pro_x'))) {
		$user = C::t('common_member')->fetch($x);
		$pro_user = $user['username'];
	} else {
		$pro_user = $config['register_username'];
	}
	$recommend = lang('plugin/e6_propaganda', 'recommend');
	if ($config['register_must']) {
		$rq = '<span class="rq">*</span>';
		$required = 'required="required"';
	}
	if (defined('IN_MOBILE')) {
		$register_mobile_tip = lang('plugin/e6_propaganda', 'register_mobile_tip');
		return <<<EOT
		<li style="border-top: 1px solid #DDD;">{$recommend}: <input type="text" tabindex="40" class="px p_fre" size="30" autocomplete="off" value="{$pro_user}" name="pro_user" placeholder="{$register_mobile_tip}" fwin="login"></li>
EOT;
	} else {
		$register_pc_tip = lang('plugin/e6_propaganda', 'register_pc_tip');
		return <<<EOT
		<div class="rfm">
			<table>
				<tbody>
					<tr>
						<th>{$rq}{$recommend}:</th>
						<td><input type="text" name="pro_user" autocomplete="off" size="25" tabindex="1" class="px" value="{$pro_user}" {$required}></td>
						<td class="tipcol" style="color:#999;"> {$register_pc_tip} </td>
					</tr>
				</tbody>
			</table>
		</div>
EOT;
	}
}
function pro_register_extra_submit() {
	global $_G, $config, $_GET;
	if (!$_G['uid'] && $_GET['regsubmit'] && $config['register_extra']) {
		if ($_GET['pro_user']) {
			if (is_numeric($_GET['pro_user'])) {
				$Y = C::t('common_member')->fetch($_GET['pro_user']);
				if ($Y) {
					$x = $Y['uid'];
				} else {
					$x = C::t('common_member')->fetch_uid_by_username($_GET['pro_user']);
				}
			} else {
				$x = C::t('common_member')->fetch_uid_by_username($_GET['pro_user']);
			}
			if (!$x) {
				if ($config['register_must']) Showmessage(lang('plugin/e6_propaganda', 'register_no_user'));
			} else {
				if ($config['cookie'] == '-1' or !getcookie('pro')) {
					$ok = 1;
				} else {
					$user = C::t('common_member')->fetch(getcookie('pro'));
					C::t('#e6_propaganda#e6_pro_credit')->insert(array(
						'uid'		=>	$x,
						'logtype'	=>	'9',
						'date'		=>	$_G['timestamp'],
						'ip'		=>	$_G['clientip'],
						'describe'	=>	pro_lang('log_9i', array('ip'=>$_G['clientip'],'username'=>$user['username']))));
				}	
				if ($ok == 1) {
					$fuser = C::t('#e6_propaganda#e6_pro_user')->fetch($x);
					if (!$fuser) pro_add_user($x);
					if ($config['ip']) {
						$overdate = $_G['timestamp'] - ($config['ip'] * 3600);
						C::t('#e6_propaganda#e6_pro_visit')->delete_by_ip("`date`<'{$overdate}'");
						$ip_uid = C::t('#e6_propaganda#e6_pro_visit')->fetch_uid_by_ip($_G['clientip']);
						if (!$ip_uid or getcookie('pro_x')) {
							if ($config['interval'] or $config['ipsection']) {
								$ip_y = C::t('#e6_propaganda#e6_pro_visit')->fetch($x);
								if ($config['interval']) {
									if (($_G['timestamp'] - $ip_y['date']) < $config['interval']) {
										if($config['cheatlog']) {
											C::t('#e6_propaganda#e6_pro_credit')->insert(array(
												'uid'		=>	$x,
												'logtype'	=>	'9',
												'date'		=>	$_G['timestamp'],
												'ip'		=>	$_G['clientip'],
												'describe'	=>	pro_lang('log_9j', array('ip'=>$_G['clientip'], 'second'=>$config['interval']))));
										}
										$pro_no = 1;
									}
								}
								if (!$pro_no && $config['ipsection']) {
									$ip_arr1 = explode('.', $ip_y['ip']);
									$ip_arr2 = explode('.', $_G['clientip']);
									if ($ip_arr1[0] == $ip_arr2[0] && $ip_arr1[1] == $ip_arr2[1]) {
										if ($config['cheatlog']) {
											C::t('#e6_propaganda#e6_pro_credit')->insert(array(
												'uid'		=>	$x,
												'logtype'	=>	'9',
												'date'		=>	$_G['timestamp'],
												'ip'		=>	$_G['clientip'],
												'describe'	=>	pro_lang('log_9k', array('ip'=>$_G['clientip'], 'oldip'=>$ip_y['ip']))));
										}
										$pro_no = 1;
									}
								}
							}
							if (!$pro_no) {
								dsetcookie('pro_x',$x ,315360000);
								C::t('#e6_propaganda#e6_pro_visit')->insert(array(
									'uid'	=>	$x,
									'ip'	=>	$_G['clientip'],
									'date'	=>	$_G['timestamp']));
								$ok = 2;
							}	
						} else {
							if ($config['cheatlog']) {
								$ip_user = C::t('common_member')->fetch($ip_uid);
								C::t('#e6_propaganda#e6_pro_credit')->insert(array(
									'uid'		=>	$x,
									'logtype'	=>	'9',
									'date'		=>	$_G['timestamp'],
									'ip'		=>	$_G['clientip'],
									'describe'	=>	pro_lang('log_9i', array('ip'=>$_G['clientip'], 'username'=>$ip_user['username']))));
							}
						}	
					} else {
						dsetcookie('pro_x',$x ,315360000);
						$ok = 2;
					}
					if ($config['cookie'] && $config['cookie'] != '-1') {
						$cookie_time = $config['cookie'] * 86400;
						dsetcookie('pro', $x, $cookie_time);
					} else {
						dsetcookie('pro', $x, 315360000);
					}
				}
				$user = C::t('common_member')->fetch($x);
				if (!$config['group'] or in_array($user['groupid'], $config['group'])) {
					if ($ok == 2) {
						dsetcookie('pro_x',$x ,315360000);
					}
				} else {
					if ($config['register_must']) Showmessage(lang('plugin/e6_propaganda', 'register_no_group', array('username' => $_GET['pro_user'])));
				}	
			}
		} else {
			if ($config['register_must']) Showmessage(lang('plugin/e6_propaganda', 'register_must_user'));
		}
	}
}
?>