<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (file_exists("{$pro_module}activation_extra.php")) {
	if (!function_exists('pro_activation_extra_top_show')) {
		require "{$pro_module}activation_extra.php";
	}
	$activation_extra_top = pro_activation_extra_top_show();
}
$page = $_GET['page'] ? intval($_GET['page']) : 1;
defined('IN_MOBILE') ? $perpage = 20 : $perpage = 15;
$start = ($page - 1) * $perpage;
$conditions = " AND fuid1='{$_G['uid']}'";
$count = C::t('#e6_propaganda#e6_pro_user')->count_by_search($conditions);
if ($count) {
	$group_list = C::t('common_usergroup')->fetch_all_by_type();
	$status = array(pro_lang('no_reward'), pro_lang('yes_reward'));
	$son_arr = C::t('#e6_propaganda#e6_pro_user')->fetch_all_by_son($conditions, $start, $perpage);
	$n = ($page-1) * $perpage + 1;
	foreach($son_arr as $v) {		
		if (!$v['username']) {
			pro_del_user($v['uid']);
			continue;
		}
		$v['n'] = $n;
		$v['groupid'] = $group_list[$v['groupid']]['grouptitle'];
		$v['date'] = dgmdate($v['regdate'], 'Y-m-d');
		if (defined('IN_MOBILE')) {
			$v['regdate'] = $v['date'];
		} else {
			$v['regdate'] = dgmdate($v['regdate']);
		}
		$v['region'] = $status[$v['region']];
		$v['activation1'] = $status[$v['activation1']];
		$v['activation2'] = $status[$v['activation2']];
		$v['activation3'] = $status[$v['activation3']];
		$v['activation4'] = $status[$v['activation4']];
		$v['activation5'] = $status[$v['activation5']];
		$v['activation6'] = $status[$v['activation6']];
		$v['activation7'] = $status[$v['activation7']];
		$v['activation8'] = $status[$v['activation8']];
		$v['activation9'] = $status[$v['activation9']];
		$v['activation10']= $status[$v['activation10']];
		if ($v['verify']) {
			$v['verify_arr'] = dunserialize($v['verify']);
			foreach ($v['verify_arr'] as $key => $value) {
				$v[$key] = $value;
			}
		}
		$n++;
		$son_list[] = $v;
	}
	for ($n = 1; $n <= $e6_propaganda['active_num']; $n++) {
		$active_title[$n] = pro_lang('active_n', array('n'=>$n));
	}
	if (function_exists('pro_activation_extra_show')) {
		$activation_extra_con = pro_activation_extra_show($son_list);
	}
	if (defined('IN_MOBILE') && $_GET['page']) {
		$list_str = "";
		if (function_exists('pro_activation_extra_show')) {
			$list_str = pro_activation_extra_show($son_list);
		}
		if (!$list_str) {
			foreach ($son_list as $v) {
				if ($e6_propaganda['template'] == 'simple' || !$e6_propaganda['template']) {
					$list_str .= "<tr><td>{$v['username']}</td><td>{$v['groupid']}</td><td>{$v['date']}</td></tr>";
				} else {
					$list_str .= "<li class=\"e6_li\"><span>{$v['username']}</span><span>{$v['groupid']}</span><span>{$v['date']}</span></li>";
				}
			}
		}
		print $list_str;
		exit;
	}
	$multi = multi($count, $perpage, $page, $nav_url.'#e6_propaganda');
}
if (defined('IN_MOBILE') && $_GET['page']) {
	exit;
}
$allpage = ceil($count/$perpage);
?>