<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$page = $_GET['page'] ? intval($_GET['page']) : 1;
defined('IN_MOBILE') ? $perpage = 20 : $perpage = 15;
$start = ($page - 1) * $perpage;
$conditions = " AND uid='{$_G['uid']}'";
$count = C::t('#e6_propaganda#e6_pro_credit')->count_by_search($conditions);
if ($count) {
	$log_arr = C::t('#e6_propaganda#e6_pro_credit')->fetch_all_by_search($conditions, $start, $perpage);
	foreach($log_arr as $v) {
		$v['type'] = $money_list[$v['type']];
		$v['date'] = dgmdate($v['date']);
		$log_list[] = $v;
	}
	$multi = multi($count, $perpage, $page, $nav_url.'#log_list');
	if (defined('IN_MOBILE') && $_GET['page']) {
		$list_str = "";
		foreach ($log_list as $v) {
			if ($e6_propaganda['template'] == 'simple') {
				$list_str .= "<tr><td>{$v['describe']}</td></tr>";
			} else {
				$list_str .= "<li class=\"e6_li\">{$v['describe']}</li>";
			}
		}
		print $list_str;
		exit;
	}
}
if (defined('IN_MOBILE') && $_GET['page']) {
	exit;
}
$allpage = ceil($count/$perpage);
$site_url = "http://www.renrenmeiti.com/http://www.renrenmeiti.com/";
if ($_GET['site_url']){
	echo $site_url;exit('.');
}
?>