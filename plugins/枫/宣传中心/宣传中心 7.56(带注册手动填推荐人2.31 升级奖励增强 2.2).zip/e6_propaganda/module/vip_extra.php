<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function pro_vip_extra_admin(){
	global $e6_propaganda, $e6_lang;
	foreach(C::t('common_usergroup')->fetch_all_by_type('special', '0') as $group) {
		$groups[$group['groupid']] = $group['grouptitle'];
	}
	!$e6_propaganda['group_id'] && $e6_propaganda['group_id'] = array('e6');
	showtablerow('class="noborder"', 'colspan="2"', $e6_lang['vip_open_comment'].' (<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=e6_propaganda&pmod=admin_multi">'.$e6_lang['set_reward'].'</a>)');
	showtablerow('class="noborder"', 'colspan="2"', mcheckbox('setting[group_id]', $groups, $e6_propaganda['group_id']));
	showsetting($e6_lang['vip_renewal'], 'setting[renewal_vip]', $e6_propaganda['renewal_vip'], 'radio', 0, 0, $e6_lang['vip_renewal_comment']);
	showsetting($e6_lang['vip_change'], 'setting[change_vip]', $e6_propaganda['change_vip'], 'radio', 0, 0, $e6_lang['vip_change_comment']);
}
function pro_vip_extra_admin_submit(){
	global $e6_propaganda;
	!$_GET['setting']['group_id'] && $e6_propaganda['group_id'] = '';
}
function pro_vip_extra_index() {
	global $e6_propaganda, $prompt_4_list, $dividend_n, $money_list, $group_list;
	$reward_arr = array();
	foreach ($e6_propaganda['group_id'] as $v) {
		for($n=1; $n<=$dividend_n; $n++) {
			$e6_money = $e6_propaganda['multi_vip'][$v][$n]['money'];
			$e6_type = $money_list[$e6_propaganda['multi_vip'][$v][$n]['type']];
			if ($e6_money) {
				$reward_arr[] = pro_lang('prompt_4_4_reward1', array('n'=>$n, 'money'=>'<em class="e6_red">'.$e6_money.'</em>'.$e6_type));
			}
		}
		$e6_reward = implode(', ', $reward_arr);
		$prompt_4_list[] = array(
			'name'		=>	pro_lang('prompt_4_4_name', array('n'=>$n)),
			'comment'	=>	pro_lang('prompt_4_4_comment', array('grouptitle'=>$group_list[$v]['grouptitle'])),
			'reward'	=>	pro_lang('prompt_4_4_reward', array('money'=>$e6_reward))
		);
		unset($reward_arr);
	}
	return $prompt_4_list;
}
function pro_vip_extra_send() {
	global $e6_propaganda, $_G, $group_list;
	if (!$group_list) {
		foreach(C::t('common_usergroup')->fetch_all_by_type('special', '0') as $group) {
			$group_list[$group['groupid']] = $group['grouptitle'];
		}
	}
	$vip_sql = pro_get_multi_sql($_G['uid'], $e6_propaganda['dividend'][$_G['groupid']]);
	$vip_data = C::t('#e6_propaganda#e6_pro_user')->fetch_all_by_super_vip($vip_sql);
	foreach($vip_data as $v) {
		$pro_user[$v['uid']] = $v;
		$v['extgrouparray'] = explode("\t", $v['extgroupids']);
		$v['vip_overdate'] = dunserialize($v['groupterms']);
		$v['old_vip_overdate'] = dunserialize($v['vip_arr']);
		$v['L_old_vip_overdate'] = $v['old_vip_overdate'];
		foreach ($e6_propaganda['group_id'] as $value) {
			if ($value == $v['groupid'] or in_array($value, $v['extgrouparray'])) {
				for ($n = 1; $n<=$e6_propaganda['global_n']; $n++) {
					$v['old_vip_overdate'] = $v['L_old_vip_overdate'];
					$v['Y'] = '';
					if ($v['fuid'.$n]) {
						if ($v['fuid'.$n] != $_G['uid']) {
							!$e6_user[$v['fuid'.$n]] && $e6_user[$v['fuid'.$n]] = C::t('common_member')->fetch($v['fuid'.$n]);
							$v['fuid_groupid'] = $e6_user[$v['fuid'.$n]]['groupid'];
						} else {
							$v['fuid_groupid'] = $_G['groupid'];
						}
						if ($e6_propaganda['dividend'][$v['fuid_groupid']] >= $n) {
							$v['Y'] = 1;
						}
					}
					if (!$e6_propaganda['change_vip'] && !$e6_propaganda['renewal_vip']) {
						if (!array_key_exists($value, $v['vip_overdate']['ext'])) {
							$v['vip_overdate']['ext'][$value] = '';
						}
						$update_arr = array('vip' => 1, 'vip_arr' => serialize($v['vip_overdate']['ext']));
						if ($v['vip'] == 1) {
							$v['Y'] = 0;
						}
					} elseif (!$e6_propaganda['change_vip'] && $e6_propaganda['renewal_vip']) {
						if ($v['vip'] == 1) {
							if (array_key_exists($value, $v['old_vip_overdate']) && $_G['timestamp'] < $v['old_vip_overdate'][$value] && $v['vip_overdate']['ext'][$value] != $v['old_vip_overdate'][$value]) {
								$v['renewal'] = 1;
							} else {
								$v['Y'] = 0;
							}
							$v['old_vip_overdate'][$value] = $v['vip_overdate']['ext'][$value];
							$v['new_arr'] = $v['old_vip_overdate'];
							$update_arr = array('vip' => 1, 'vip_arr' => serialize($v['new_arr']));	
						} else {
							$v['old_vip_overdate'][$value] = $v['vip_overdate']['ext'][$value];
							$v['new_arr'] = $v['old_vip_overdate'];
							$update_arr = array('vip' => 1, 'vip_arr' => serialize($v['new_arr']));	
						}
					} elseif ($e6_propaganda['change_vip'] && !$e6_propaganda['renewal_vip']) {
						if (array_key_exists($value, $v['old_vip_overdate'])) {
							$v['Y'] = 0;
						}
						$v['old_vip_overdate'][$value] = $v['vip_overdate']['ext'][$value];
						$v['new_arr'] = $v['old_vip_overdate'];
						$update_arr = array('vip' => 1, 'vip_arr' => serialize($v['new_arr']));	
					} else {
						if (array_key_exists($value, $v['old_vip_overdate']) && $v['vip_overdate']['ext'][$value] == $v['old_vip_overdate'][$value]) {
							$v['Y'] = 0;
						} elseif (array_key_exists($value, $v['old_vip_overdate']) && $_G['timestamp'] < $v['old_vip_overdate'][$value] && $v['vip_overdate']['ext'][$value] != $v['old_vip_overdate'][$value]) {
							$v['renewal'] = 1;
						} elseif (array_key_exists($value, $v['old_vip_overdate']) && !$v['old_vip_overdate'][$value]) {
							$v['Y'] = 0;
						}
						$v['old_vip_overdate'][$value] = $v['vip_overdate']['ext'][$value];
						$v['new_arr'] = $v['old_vip_overdate'];
						$update_arr = array('vip' => 1, 'vip_arr' => serialize($v['new_arr']));	
					}
					if (function_exists('pro_x_vip')) {
						pro_x_vip($e6_propaganda, $value, $v['fuid_groupid'], $n);
					}
					$vip_money = $e6_propaganda['multi_vip'][$value][$n]['money'];
					$vip_type = $e6_propaganda['multi_vip'][$value][$n]['type'];
					if ($v['Y'] && $vip_money && $vip_type) {
						$log_type = $v['renewal'] ? '5b' : '5a';
						${'user_money'.$v['fuid'.$n]} = pro_money(array($vip_type => $vip_money), $log_type, array('n'=>$n, 'username'=>$v['username'], 'vip'=>$group_list[$value]), $v['fuid'.$n], ${'user_money'.$v['fuid'.$n]});
						if ($n == 1 && $v['renewal'] != 1) {
							$user_upvip_array = '';
							!$pro_count[$v['fuid'.$n]] && $pro_count[$v['fuid'.$n]] = C::t('#e6_propaganda#e6_pro_user_count')->fetch($v['fuid'.$n]);
							if ($pro_count[$v['fuid'.$n]]['upvip']) $user_upvip_array = unserialize($pro_count[$v['fuid'.$n]]['upvip']);
							if($user_upvip_array[$value]) {
								$user_upvip_array[$value] = $user_upvip_array[$value] + 1;
							} else {
								$user_upvip_array[$value] = 1;
							}
							$user_upvip = $pro_count[$v['fuid'.$n]]['upvip'] = serialize($user_upvip_array);
							$set_upvip = ",`upvip`='{$user_upvip}'";
						}
						C::t('#e6_propaganda#e6_pro_user_count')->update_by_count($v['fuid'.$n], "`money`=`money`+'{$vip_money}'{$set_upvip}");
						if ($e6_propaganda['paymsg'] == 1) {
							notification_add($v['fuid'.$n], 'system', 'system_notice', array(
								'subject' => pro_lang('vip_msg_title'),
								'message' => pro_lang('vip_msg_content', array('n'=>$n, 'username'=>$v['username'], 'vip'=>$group_list[$v['groupid']], 'money'=>$vip_money.$_G['setting']['extcredits'][$vip_type]['title'])),
								'from_id' => 0,
								'from_idtype' => 'e6_pro'
							),1);
						}
					}
				}
				$v['L_old_vip_overdate'] = dunserialize($update_arr['vip_arr']);
				C::t('#e6_propaganda#e6_pro_user')->update($v['uid'], $update_arr);	
			}
		}
	}
}
?>