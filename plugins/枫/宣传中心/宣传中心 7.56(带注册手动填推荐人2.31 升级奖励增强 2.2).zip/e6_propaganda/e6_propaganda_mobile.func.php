<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function e6_propaganda_mobile() {}
?>