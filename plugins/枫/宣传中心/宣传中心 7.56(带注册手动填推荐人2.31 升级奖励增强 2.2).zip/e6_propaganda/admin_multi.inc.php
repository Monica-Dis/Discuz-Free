<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require 'e6_propaganda.func.php';
if (submitcheck('e6_submit')) {
	!$e6_propaganda && $e6_propaganda = array();
	!$_GET['setting'] && $_GET['setting'] = array();
	pro_save_setting($e6_propaganda, $_GET['setting'], $msg);
}
print <<<EOT
<script src="source/plugin/e6_propaganda/static/js/j.js?version={$version}"></script>
<script src="source/plugin/e6_propaganda/static/js/admin.js?version={$version}"></script>
EOT;
showformheader('plugins&'. cpurl(false, array('action')));
showtableheader($e6_lang['multi_title']);
if ($e6_propaganda['registertype'] == 2) {
	showtablerow('', 'class="td27"', $e6_lang['multi_reg']);
	$html = '<ul class="nofloat" style="width:100%">';
	for ($n=1; $n<=$e6_propaganda['global_n']; $n++) {
		$html .= '<li style="float:left; width:33%;">';
		$html .= $n.$e6_lang['multi_reg_title']."<input name=\"setting[multi_reg][{$n}][money]\" value=\"{$e6_propaganda['multi_reg'][$n]['money']}\" style=\"width:30px;\"> ";
		$html .= "<select name=\"setting[multi_reg][{$n}][type]\" style=\"width:80px;\">";
		foreach($_G['setting']['extcredits'] as $k => $v) {
			$html .= '<option value="'.$k.'" '.($k == $e6_propaganda['multi_reg'][$n]['type'] ? 'selected' : '').'>'.$v['title'].'</option>';
		}
		$html .= '</select>';
		$html .= '</li>';
	}
	$html .= '</ul>';
	showtablerow('class="noborder"', 'class="vtop rowform" colspan="2" style="width:100%"', $html);
}
if ($e6_propaganda['paytype'] > 0) {
	showtablerow('', array('class="td27"', 'class="vtop tips2"'), array($e6_lang['multi_pay'], $e6_lang['multi_pay_comment'].' (<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&operation=config&do='.$plugin['pluginid'].'&identifier=e6_propaganda&pmod=admin_high">'.$e6_lang['multi_pay_setting'].'</a>)'));
	$html = '<ul class="nofloat" style="width:100%">';
	for ($n=1; $n<=$e6_propaganda['global_n']; $n++) {
		$html .= '<li style="float:left; width:33%;">'.$n.$e6_lang['multi_pay_title'];
		if ($e6_propaganda['paytype'] == 1) {
			$html .= "<input name=\"setting[multi_pay][{$n}][money]\" value=\"{$e6_propaganda['multi_pay'][$n]['money']}\" style=\"width:30px;\"> ";
			$html .= "<select name=\"setting[multi_pay][{$n}][type]\" style=\"width:80px;\">";
			foreach($_G['setting']['extcredits'] as $k => $v) {
				$html .= '<option value="'.$k.'" '.($k == $e6_propaganda['multi_pay'][$n]['type'] ? 'selected' : '').'>'.$v['title'].'</option>';
			}
			$html .= '</select>';
		} else {
			$html .= "<input name=\"setting[multi_pay][{$n}][percentage]\" value=\"{$e6_propaganda['multi_pay'][$n]['percentage']}\" style=\"width:30px;\"> <span>%</span>";
		}
		$html .= '</li>';
	}
	$html .= '</ul>';
	showtablerow('class="noborder"', 'class="vtop rowform" colspan="2" style="width:100%"', $html);
}
foreach(C::t('common_usergroup')->range() as $group) {
	$groups[$group['groupid']] = $group['grouptitle'];
}
if ($e6_propaganda['vip_open'] > 0) {
	foreach ($e6_propaganda['group_id'] as $value) {
		showtablerow('', 'class="td27"', $e6_lang['multi_vip'].'<span style="color:red"> '.$groups[$value].' </span>'.$e6_lang['multi_vip_reward']);
		$html = '<ul class="nofloat" style="width:100%">';
		for ($n=1; $n<=$e6_propaganda['global_n']; $n++) {
			$html .= '<li style="float:left; width:33%;">';
			$html .= $n.$e6_lang['multi_vip_title'].": <input name=\"setting[multi_vip][{$value}][{$n}][money]\" value=\"{$e6_propaganda['multi_vip'][$value][$n]['money']}\" style=\"width:30px;\"> ";
			$html .= "<select name=\"setting[multi_vip][{$value}][{$n}][type]\" style=\"width:80px;\">";
			foreach($_G['setting']['extcredits'] as $k => $v) {
				$html .= '<option value="'.$k.'" '.($k == $e6_propaganda['multi_vip'][$value][$n]['type'] ? 'selected' : '').'>'.$v['title'].'</option>';
			}
			$html .= '</select>';
			$html .= '</li>';
		}
		$html .= '</ul>';
		showtablerow('class="noborder"', 'class="vtop rowform" colspan="2" style="width:100%"', $html);
	}
}
if (file_exists("{$pro_module}reward_extra.php")) {
	if (!function_exists('pro_reward_extra_multi_admin')) {
		require "{$pro_module}reward_extra.php";
	}
	pro_reward_extra_multi_admin();
}
showsubmit('e6_submit');
showtablefooter();
showformfooter();
?>