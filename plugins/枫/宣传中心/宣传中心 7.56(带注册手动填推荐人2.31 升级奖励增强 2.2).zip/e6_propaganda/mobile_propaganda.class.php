<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class mobileplugin_e6_propaganda {
	function mobileplugin_e6_propaganda() {
        global $_G;
		if (!function_exists('e6_propaganda')) {
			require DISCUZ_ROOT.'source/plugin/e6_propaganda/e6_propaganda.func.php';
		}
		include DISCUZ_ROOT . "data/e6_propaganda.config.php";
		$this->config = $e6_propaganda;
		$this->pro_module = DISCUZ_ROOT . 'source/plugin/e6_propaganda/module/';
	}
	function common() {
		global $_G, $_GET;
		$_GET['x'] && $GLOBALS['x'] = $x = intval($_GET['x']);
		if (file_exists("{$this->pro_module}domain_extra.php") && !$_GET['x']) {
			if (!function_exists('pro_get_domain')) {
				require "{$this->pro_module}domain_extra.php";
			}
			$GLOBALS['x'] = $x = pro_get_domain($this->config);
		}
		$_GET['regsubmit'] && $e6_reg = 1;
		if ($_G['uid'] && getcookie('pro_x')) {
			if (!$_G['member']['regdate']) $user = C::t('common_member')->fetch($_G['uid']);
			$regdate = $_G['member']['regdate'] ? $_G['member']['regdate'] : $user['regdate'];
			if (($_G['timestamp'] - $regdate) < 600 && ($_G['timestamp'] - $regdate) > 1) {
				$pro_reg = C::t('#e6_propaganda#e6_pro_user')->fetch($_G['uid']);
				if (!$pro_reg) {
					$e6_reg = 1;
				}
			}
		}
		$GLOBALS['config'] = $config = $this->config;
		if (file_exists("{$this->pro_module}register_extra.php") && $this->config['register_extra']) {
			if (!function_exists('pro_register_extra_submit')) {
				require "{$this->pro_module}register_extra.php";
			}
			pro_register_extra_submit();	
		}
		if ($x or ($e6_reg && $_G['uid'] && getcookie('pro_x'))) {
			!$GLOBALS['e6_propaganda_x'] && @include DISCUZ_ROOT . 'source/plugin/e6_propaganda/x.php';
		}
		if (!$this->config['send_mode']) {
			@include DISCUZ_ROOT.'source/plugin/e6_propaganda/send.php';
		}
	}
	function index_top_mobile() {
		global $_G, $_GET;
		if ($_GET['mobile'] == 1) {
			$left = '<span class="pipe">|</span>';
		} else {
			$left = '&nbsp;&nbsp;&nbsp;';
		}
		//return $left.'<a href="plugin.php?id=e6_propaganda">'.lang('plugin/e6_propaganda', 'title').'</a>';
	}
	function global_footer_mobile() {
		global $_G;
		if ($this->config['wxshare_open'] != 1) {
			return '';
		}
		$signPackage = $this->GetSignPackage();
		$location_url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$location_url = preg_replace('/&extra=(.*)/', '', $location_url);
		$location_url = preg_replace('/&mobile=\d+/', '', $location_url);
		if (strpos($location_url, '?') === false) {
			$location_url = $location_url.'?x='.$_G['uid'];
		} else {
			$location_url = $location_url.'&x='.$_G['uid'];
		}
		return <<<EOT
<script src="http://res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
<script>
wx.config({
	debug: false,
	appId: '{$signPackage["appId"]}',
	timestamp: {$signPackage["timestamp"]},
	nonceStr: '{$signPackage["nonceStr"]}',
	signature: '{$signPackage["signature"]}',
	jsApiList: [
		'checkJsApi',
		'onMenuShareTimeline',
		'onMenuShareAppMessage',
		'onMenuShareQQ',
		'onMenuShareWeibo'
	]
});
window.share_config = {
	"share": {
        "link": '{$location_url}',
        "success":function(){},
        'cancel': function () {}
	}
};  
wx.ready(function () {
    wx.onMenuShareAppMessage(share_config.share);
    wx.onMenuShareTimeline(share_config.share);
    wx.onMenuShareQQ(share_config.share);
	wx.onMenuShareWeibo(share_config.share);
});
</script>
EOT;
	}
	public function getSignPackage() {
		$jsapiTicket = $this->getJsApiTicket();
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		$url = "{$protocol}{$_SERVER[HTTP_HOST]}{$_SERVER[REQUEST_URI]}";
		$timestamp = time();
		$nonceStr = $this->createNonceStr();
		$string = "jsapi_ticket={$jsapiTicket}&noncestr={$nonceStr}&timestamp={$timestamp}&url=$url";
		$signature = sha1($string);
		$signPackage = array(
			"appId"     => $this->config['appid'],
			"nonceStr"  => $nonceStr,
			"timestamp" => $timestamp,
			"url"       => $url,
			"signature" => $signature,
			"rawString" => $string
		);
		return $signPackage; 
	}
	private function createNonceStr($length = 16) {
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$str = "";
		for ($i = 0; $i < $length; $i++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}
	private function getJsApiTicket() {
		global $_G;
		loadcache('e6_jsapi_ticket');
		$data = $_G['cache']['e6_jsapi_ticket'];
		if ($data['expire_time'] < time()) {
			$accessToken = $this->getAccessToken();
			$url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token={$accessToken}";
			$res = json_decode($this->httpGet($url));
			$ticket = $res->ticket;
			if ($ticket) {
				$data['expire_time'] = time() + 7000;
				$data['e6_jsapi_ticket'] = $ticket;
				savecache('e6_jsapi_ticket', $data);
			}
		} else {
			$ticket = $data['e6_jsapi_ticket'];
		}
		return $ticket;
	}
	private function getAccessToken() {
		global $_G;
		loadcache('e6_access_token');
		$data = $_G['cache']['e6_access_token'];
		if ($data['expire_time'] < time()) {
			$url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={$this->config['appid']}&secret={$this->config['appsecret']}";
			$res = json_decode($this->httpGet($url));
			$access_token = $res->access_token;
			if ($access_token) {
				$data['expire_time'] = time() + 7000;
				$data['e6_access_token'] = $access_token;
				savecache('e6_access_token', $data);
			}
		} else {
			$access_token = $data['e6_access_token'];
		}
		return $access_token;
	}
	private function httpGet($url) {
		//return dfsockopen($url);//
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_TIMEOUT, 500);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_URL, $url);
		$res = curl_exec($curl);
		curl_close($curl);
		return $res;
	}
}
class mobileplugin_e6_propaganda_forum extends mobileplugin_e6_propaganda {
	function forumdisplay_top_mobile() {
		global $_G;
		$e6_propaganda = $this->config;
		if (file_exists("{$this->pro_module}condition_extra.php")) {
			if (!function_exists('pro_condition_extra_show')) {
				require "{$this->pro_module}condition_extra.php";
				pro_condition_extra_show(1);
			}
		}
	}
	function forumdisplay_bottom_mobile() {
		return self::forumdisplay_top_mobile();
	}
	function viewthread_top_mobile() {
		return self::forumdisplay_top_mobile();
	}
	function viewthread_bottom_mobile() {
		return self::forumdisplay_top_mobile();
	}
	function attachment_condition(){
		global $_G;
		$e6_propaganda = $this->config;
		if (file_exists("{$this->pro_module}condition_extra.php")) {
			if (!function_exists('pro_condition_extra_show')) {
				require "{$this->pro_module}condition_extra.php";
				pro_condition_extra_show(2);
			}
		}
	}
}
class mobileplugin_e6_propaganda_member extends mobileplugin_e6_propaganda {
	function register_input_output() {
		$GLOBALS['config'] = $config = $this->config;
		if (file_exists("{$this->pro_module}register_extra.php") && $this->config['register_extra']) {
			if (!function_exists('pro_register_extra_index')) {
				require "{$this->pro_module}register_extra.php";
			}
			return pro_register_extra_index();	
		} else {
			if ($x = intval(getcookie('pro_x'))) {
				$user = C::t('common_member')->fetch($x);
				$pro_user = $user['username'];
			}
			$recommend = lang('plugin/e6_propaganda', 'recommend');
			return <<<EOT
			<li style="border-top: 1px solid #DDD;">{$recommend}: {$pro_user}</li>
EOT;
		}
	}
}
?>