<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require 'e6_box.class.php';

if ($_GET['deldate'] && $_GET['formhash'] == formhash()) {
    $olddate = $_G['timestamp'] - intval($_GET['deldate']) * 86400;
    C::t('#e6_box#e6_box_winning_user')->delete_by_box($olddate);
    cpmsg($e6_lang['a_b_1'], cpurl(false, ['deldate']), 'succeed');
} elseif (submitcheck('dellog')) {
    if (is_array($_GET['log_id'])) {
        C::t('#e6_box#e6_box_winning_user')->delete($_GET['log_id']);
        cpmsg($e6_lang['a_b_1'], cpurl(false), 'succeed');
    }
}
showformheader('plugins&identifier=e6_box&pmod=admin_box');
$html = $e6_lang['a_b_2'] .
    '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&identifier=e6_box&pmod=admin_box&deldate=30&do=' . $plugin['pluginid'] . '&formhash=' . FORMHASH . '" onclick="return confirm(\'' . $e6_lang['a_b_3'] . '\');">' . $e6_lang['a_b_4'] . '</a> | ' .
    '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&identifier=e6_box&pmod=admin_box&deldate=7&do=' . $plugin['pluginid'] . '&formhash=' . FORMHASH . '" onclick="return confirm(\'' . $e6_lang['a_b_3'] . '\');">' . $e6_lang['a_b_5'] . '</a> | ' .
    '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&identifier=e6_box&pmod=admin_box&deldate=1&do=' . $plugin['pluginid'] . '&formhash=' . FORMHASH . '" onclick="return confirm(\'' . $e6_lang['a_b_3'] . '\');">' . $e6_lang['a_b_6'] . '</a>';
showtableheader($html);

$box_type = $e6_box->setting_type;

$box_option = "<option value=''>{$e6_lang['a_b_7']}</option>";
foreach ($box_type as $k => $v) {
    $box_option .= "<option value=\"{$k}\">{$v}</option>";
}
$num_option = "<option value=''>{$e6_lang['a_b_7']}</option>";
for ($n = 1; $n <= 8; $n++) {
    $num_option .= "<option value=\"{$n}\">{$n}{$e6_lang['a_b_8']}</option>";
}
print '<script src="static/js/calendar.js" type="text/javascript"></script>';
showtablerow('',
    ['width="140"', 'width="130"', 'width="150"', 'width="320"'],
    [
        $e6_lang['a_b_9'] . ': <input type="text" name="username" style="width:65px;">',
        $e6_lang['a_b_10'] . ': <select name="box">' . $box_option . '</select>',
        $e6_lang['a_b_11'] . ': <select name="num">' . $num_option . '</select>',
        $e6_lang['a_b_12'] . ': <input type="text" name="sdate" style="width: 108px;" onclick="showcalendar(event, this)"> -- <input type="text" name="edate" style="width: 108px;" onclick="showcalendar(event, this)">',
        "<input class=\"btn\" type=\"submit\" value=\"$lang[search]\" />"
    ]
);
showtablefooter();/*Dism_taobao_com*/
showtableheader();/*Dism��taobao��com*/
$tabletop = [
    'ID',
    $e6_lang['a_b_13'],
    $e6_lang['a_b_12'],
    $e6_lang['a_b_10'],
    $e6_lang['a_b_11'],
    $e6_lang['a_b_14'],
    $e6_lang['a_b_15']
];
showsubtitle($tabletop);
$perpage = 20;
$start   = ($page - 1) * $perpage;
if ($_GET['username']) {
    $uid = C::t('common_member')->fetch_uid_by_username(daddslashes($_GET['username']));
    $conditions .= " AND c.uid='{$uid}'";
    $theurl .= '&username=' . rawurlencode($_GET['username']);
}
if ($_GET['box'] != '') {
    $conditions .= " AND `box`='" . dintval($_GET['box']) . "'";
    $theurl .= '&box=' . rawurlencode($_GET['box']);
}
if ($_GET['num'] != '') {
    $conditions .= " AND `num`='" . dintval($_GET['num']) . "'";
    $theurl .= '&num=' . rawurlencode($_GET['num']);
}
if ($_GET['sdate']) {
    $sdate = strtotime($_GET['sdate']);
    $conditions .= " AND `date`>'" . strtotime($_GET['sdate']) . "'";
    $theurl .= '&sdate=' . rawurlencode($_GET['sdate']);
}
if ($_GET['edate']) {
    $edate = strtotime($_GET['edate']);
    $conditions .= " AND `date`<'" . strtotime($_GET['edate']) . "'";
    $theurl .= '&edate=' . rawurlencode($_GET['edate']);
}
$boxcount = C::t('#e6_box#e6_box_winning_user')->count_by_search($conditions);
if ($boxcount) {
    $n = ($page - 1) * $perpage + 1;
    foreach (C::t('#e6_box#e6_box_winning_user')->fetch_all_by_search($conditions, $start, $perpage) as $v) {
        showtablerow('', '', [
            $n,
            $v['username'],
            dgmdate($v['date']),
            $box_type[$v['box']],
            $v['num'] . $e6_lang['a_b_8'],
            $v['describe'],
            '<input class="checkbox" type="checkbox" id="log_id" name="log_id[]" value="' . $v['id'] . '" />'
        ]);
        $n++;
    }
    $multi = multi($boxcount, $perpage, $page, ADMINSCRIPT . '?' . cpurl(false) . $theurl);
}
showtablefooter();/*Dism_taobao_com*/
showsubmit('', '', '', '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'log_id\')" /><label for="chkall">' . cplang('select_all') . '</label>&nbsp;&nbsp;<input type="submit" onclick="return confirm(\'' . $e6_lang['a_b_3'] . '\');" class="btn" name="dellog" value="' . $e6_lang['a_b_15'] . '" />', $multi);
showformfooter();
