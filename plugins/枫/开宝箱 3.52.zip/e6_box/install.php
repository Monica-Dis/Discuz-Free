<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL
DROP TABLE IF EXISTS `pre_e6_box_count`;
CREATE TABLE `pre_e6_box_count`  (
  `type` varchar(20) NOT NULL,
  `n` mediumint(8) NOT NULL DEFAULT -1,
  PRIMARY KEY (`type`) USING BTREE
) ENGINE = MyISAM;

DROP TABLE IF EXISTS `pre_e6_box_credit`;
CREATE TABLE `pre_e6_box_credit`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `type` tinyint(2) UNSIGNED NOT NULL DEFAULT 0,
  `logtype` tinyint(2) UNSIGNED NOT NULL DEFAULT 0,
  `smoney` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `emoney` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `change` mediumint(6) NOT NULL DEFAULT 0,
  `date` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `ip` varchar(15) NOT NULL,
  `describe` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `uid`(`uid`) USING BTREE
) ENGINE = MyISAM;

DROP TABLE IF EXISTS `pre_e6_box_free_user`;
CREATE TABLE `pre_e6_box_free_user`  (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) NOT NULL,
  `date` int(10) NOT NULL,
  `type1` smallint(5) NOT NULL,
  `type2` smallint(5) NOT NULL,
  `type3` smallint(5) NOT NULL,
  `num1` smallint(5) NOT NULL,
  `num2` smallint(5) NOT NULL,
  `num3` smallint(5) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `uid`(`uid`) USING BTREE
) ENGINE = MyISAM;

DROP TABLE IF EXISTS `pre_e6_box_last_time`;
CREATE TABLE `pre_e6_box_last_time`  (
  `last_time` int(10) UNSIGNED NULL DEFAULT NULL
) ENGINE = MyISAM;

DROP TABLE IF EXISTS `pre_e6_box_limit_user`;
CREATE TABLE `pre_e6_box_limit_user`  (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) NOT NULL,
  `date` int(10) NOT NULL,
  `number` smallint(5) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `uid`(`uid`) USING BTREE
) ENGINE = MyISAM;

DROP TABLE IF EXISTS `pre_e6_box_magapp_price`;
CREATE TABLE `pre_e6_box_magapp_price`  (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) UNSIGNED NOT NULL,
  `price` decimal(10, 2) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `order` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM;

DROP TABLE IF EXISTS `pre_e6_box_winning_user`;
CREATE TABLE `pre_e6_box_winning_user`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `box` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `num` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `date` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `describe` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `uid`(`uid`) USING BTREE
) ENGINE = MyISAM;

SQL;
runquery($sql);
$finish = true;
