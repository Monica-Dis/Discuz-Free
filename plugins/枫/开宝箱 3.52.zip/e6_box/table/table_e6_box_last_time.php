<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_e6_box_last_time extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'e6_box_last_time';
        $this->_pk    = 'last_time';
        parent::__construct();/*http://t.cn/Aiux1Qh0*/
    }

    public function last_time()
    {
    	return DB::result_first("SELECT `last_time` FROM %t", [$this->_table]);
    }

    public function update_last_time()
    {
    	return DB::query("UPDATE %t SET `last_time`=%d", [$this->_table, TIMESTAMP]);
    }
}
