<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_e6_box_magapp_price extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'e6_box_magapp_price';
        $this->_pk    = 'id';
        parent::__construct();/*http://t.cn/Aiux1Qh0*/
    }

    public function fetch_first()
    {
        $data = DB::fetch_first("SELECT * FROM %t ORDER BY `id` ASC LIMIT 1", [$this->_table]);
        return $data;
    }
}
