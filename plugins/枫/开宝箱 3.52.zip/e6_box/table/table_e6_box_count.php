<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_e6_box_count extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'e6_box_count';
        $this->_pk    = 'type';
        parent::__construct();/*http://t.cn/Aiux1Qh0*/
    }

    public function fetch_all()
    {
        $query = DB::query('SELECT * FROM %t ', [$this->_table]);
        while ($rt = DB::fetch($query)) {
            $list[$rt['type']] = $rt['n'];
        }
        return $list;
    }

    public function update_all($data)
    {
        foreach ($data as $k => $v) {
        	if ($this->fetch($k)) {
        		DB::update($this->_table, ['n' => dintval($v)], DB::field($this->_pk, $k));
        	} else {
        		DB::insert($this->_table, ['type' => $k, 'n' => dintval($v)]);
        	}
        }
    }

    public function update_by_num($type, $sql)
    {
        DB::query("UPDATE %t SET %i WHERE `type`='%i'", [$this->table, $sql, $type]);
    }

    public function get_number($type)
    {
        return DB::result_first("SELECT `n` FROM %t WHERE `type`='%d'", [$this->_table, $type]);
    }
}
