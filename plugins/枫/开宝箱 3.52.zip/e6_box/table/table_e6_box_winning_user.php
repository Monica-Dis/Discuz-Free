<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_e6_box_winning_user extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'e6_box_winning_user';
        $this->_pk    = 'id';
        parent::__construct();/*http://t.cn/Aiux1Qh0*/
    }

    public function count_by_search($conditions = '')
    {
        return DB::result_first('SELECT COUNT(*) FROM %t c WHERE 1 %i ', [$this->_table, $conditions]);
    }

    public function fetch_all_by_search($conditions = '', $start, $limit)
    {
        return DB::fetch_all('SELECT m.username,c.* FROM %t c ' .
            ' LEFT JOIN ' . DB::table('common_member') . ' m ON c.uid=m.uid WHERE 1 %i ' .
            ' ORDER BY c.id DESC ' . DB::limit($start, $limit), [$this->_table, $conditions]);
    }

    public function delete_by_box($date)
    {
        return DB::delete($this->_table, "`date`<{$date}");
    }

    public function last_log($uid = 0)
    {
        if ($uid > 0) {
            return DB::fetch_first("SELECT * FROM %t WHERE `uid`='%d' ORDER BY `id` DESC LIMIT 1", [$this->_table, $uid]);
        } else {
            return DB::fetch_first("SELECT * FROM %t WHERE `describe`<>'" . lang('plugin/e6_box', 'table_1') . "' ORDER BY `id` DESC LIMIT 1", [$this->_table]);
        }
    }

    public function fetch_all_top_limit($num, $limit)
    {
        return DB::fetch_all('SELECT m.username,c.* FROM %t c ' .
            ' LEFT JOIN ' . DB::table('common_member') . " m ON c.uid=m.uid WHERE c.num<='{$num}' " .
            ' ORDER BY c.num ASC ' . DB::limit(0, $limit), [$this->_table]);
    }
}
