<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_e6_box_limit_user extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'e6_box_limit_user';
        $this->_pk    = 'uid';
        parent::__construct();/*http://t.cn/Aiux1Qh0*/
    }

    public function get_limit_number($uid)
    {
        $today = strtotime(dgmdate(TIMESTAMP, 'Y-m-d'));

        $data = $this->fetch($uid);

        if (empty($data)) {
            $this->insert([
                'uid'    => $uid,
                'date'   => $today,
                'number' => 0
            ]);
            return 0;
        } elseif ($data['date'] < $today) {
            $this->update($uid, [
                'date'   => $today,
                'number' => 0
            ]);
            return 0;
        } else {
        	return $data['number'];
        }
    }

    public function increase_number($uid)
    {
    	DB::query("UPDATE %t SET `number`=`number`+1 WHERE `uid`='%d'", [$this->_table, $uid]);
    }
}
