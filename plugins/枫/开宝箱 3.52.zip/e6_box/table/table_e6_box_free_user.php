<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_e6_box_free_user extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'e6_box_free_user';
        $this->_pk    = 'uid';
        parent::__construct();/*http://t.cn/Aiux1Qh0*/
    }

    public function get_free_number($uid)
    {
        $today = strtotime(dgmdate(TIMESTAMP, 'Y-m-d'));

        $data = $this->fetch($uid);

        if (empty($data)) {
            $this->insert([
                'uid'   => $uid,
                'date'  => $today,
                'type1' => 0,
                'type2' => 0,
                'type3' => 0
            ]);

        } elseif ($data['date'] < $today) {
            $this->update($uid, [
                'date'  => $today,
                'type1' => 0,
                'type2' => 0,
                'type3' => 0
            ]);
        }

        return $this->fetch($uid);
    }

    public function increase_number($uid, $type)
    {
        DB::query("UPDATE %t SET `type%d`=`type%d`+1 WHERE `uid`='%d'", [$this->_table, $type, $type, $uid]);
    }

    public function decrease_number($uid, $type)
    {
        DB::query("UPDATE %t SET `num%d`=`num%d`-1 WHERE `uid`='%d'", [$this->_table, $type, $type, $uid]);
    }

    public function increase_free_number($uid, $type, $number)
    {
        DB::query('UPDATE %t Set `num%d`=`num%d`+%d WHERE `uid`=%d', [$this->_table, $type, $type, $number, $uid]);
    }
}
