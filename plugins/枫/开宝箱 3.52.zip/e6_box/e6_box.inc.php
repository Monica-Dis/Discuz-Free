<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require 'e6_box.class.php';

!$e6_box->config['open'] && Showmessage($e6_box->lang('box_1'));

$spent_money = $e6_box->spent_money();

if ($_GET['open_box'] == 1) {
    $e6_box->open_box($_GET['type']);
    die;
}

$page    = $_GET['page'] ? intval($_GET['page']) : 1;
$perpage = 10;

$count = $e6_box->my_winning_list_count();
if ($count) {
    $my_winning_list = $e6_box->my_winning_list($perpage, $page);
}

if ($count <= $perpage) {
    $end = 1;
} else {
    $end = 0;
}

if ($page > 1) {
    foreach ($my_winning_list as $v) {
        $content .= <<<EOT
		<tr>
			<td class="td1">{$v['content']}</td>
			<td>{$v['date']}</td>
		</tr>
EOT;
    }

    print $content;
    die;
} else {
    $all_winning_list = $e6_box->all_winning_list();
}

@include template('e6_box:index');
