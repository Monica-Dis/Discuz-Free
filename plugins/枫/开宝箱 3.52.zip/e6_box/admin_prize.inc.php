<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require 'e6_box.class.php';

if (submitcheck('e6_submit')) {
    C::t('#e6_box#e6_box_count')->update_all(daddslashes($_GET['box_number']));
    $e6_box->save_setting();
}

$prize_number = C::t('#e6_box#e6_box_count')->fetch_all();
$magic_list   = C::t('common_magic')->fetch_all_name_by_available();
$medal_list   = C::t('forum_medal')->fetch_all_name_by_available();
foreach (C::t('common_usergroup')->fetch_all_by_type('special', '0') as $group) {
    $vip_groups[$group['groupid']] = $group['grouptitle'];
}

showformheader('plugins&' . cpurl(false, ['action']));
showtableheader($e6_lang['a_p_1']);

print <<<EOT
<script type="text/javascript" src="source/plugin/e6_box/static/js/jquery.min.js?v={$e6_box->version}"></script>
<script type="text/javascript" src="source/plugin/e6_box/static/js/admin.js?v={$e6_box->version}"></script>
EOT;

foreach ($e6_box->setting_type as $key => $value) {
    showtablerow('', ['class="td27"', 'class="vtop tips2"'], ['<span style="color:red">' . $value . $e6_lang['a_p_2'] . '</span>', $e6_lang['a_p_3']]);
    for ($n = 1; $n <= 8; $n++) {
        $html = '';
        $html .= '<span style="color:blue;">' . $n . $e6_lang['a_p_4'] . '</span><span> 10000 / </span>';
        $html .= '<input name="setting[' . $key . '_winning_rate' . $n . ']" value="' . $e6_box->config[$key . '_winning_rate' . $n] . '" type="text" style="width:50px;">';
        $html .= '<span>' . $e6_lang['a_p_5'] . '</span> ';
        $html .= '<input name="box_number[' . $key . $n . ']" value="' . $prize_number[$key . $n] . '" type="text" style="width:50px;">';
        $html .= '<span> (' . $e6_lang['a_p_6'] . ' <span style="color:red;">-1</span>)</span><br />';
        $html .= '<span>' . $n . $e6_lang['a_p_7'] . '</span> ';
        $prize_option = '';
        foreach ($e6_box->prize_type() as $k => $v) {
            $prize_option .= '<option value="' . $k . '" ' . ($k == $e6_box->config[$key . '_winning_prize' . $n] ? 'selected' : '') . '>' . $v . '</option>';
        }
        $html .= "<select name=\"setting[{$key}_winning_prize{$n}]\" onchange=\"show_type('{$key}_winning_prize{$n}',this);\" id=\"{$key}_winning_prize{$n}type\" style=\"width:120px;\">{$prize_option}</select>";
        $html .= "<input name=\"setting[{$key}_winning_prize{$n}_money]\" value=\"{$e6_box->config[$key . '_winning_prize' . $n . '_money']}\" type=\"text\" style=\"width:80px;display:none;\" class=\"{$key}_winning_prize{$n} id1 txt\">";
        $money_option = '';
        foreach ($e6_box->money_list() as $k => $v) {
            $money_option .= '<option value="' . $k . '" ' . ($k == $e6_box->config[$key . '_winning_prize' . $n . '_money_type'] ? 'selected' : '') . '>' . $v . '</option>';
        }
        $html .= "<select name=\"setting[{$key}_winning_prize{$n}_money_type]\" class=\"{$key}_winning_prize{$n} id1\" style=\"width:120px;display:none;\">{$money_option}</select>";
        if ($magic_list) {
            $html .= "<input name=\"setting[{$key}_winning_prize{$n}_magic_num]\" value=\"{$e6_box->config[$key . '_winning_prize' . $n . '_magic_num']}\" type=\"text\" class=\"{$key}_winning_prize{$n} id2\" style=\"width:80px;display:none;\" /> ";
            $html .= "<span class=\"{$key}_winning_prize{$n} id2\" style=\"display:none;\">{$e6_lang['a_p_17']} &nbsp;</span> ";
            $magic_option = '';
            foreach ($magic_list as $v) {
                $magic_option .= '<option value="' . $v['magicid'] . '" ' . ($v['magicid'] == $e6_box->config[$key . '_winning_prize' . $n . '_magic'] ? 'selected' : '') . '>' . $v['name'] . '</option>';
            }
            $html .= "<select name=\"setting[{$key}_winning_prize{$n}_magic]\" class=\"{$key}_winning_prize{$n} id2\" style=\"width:120px;display:none;\">{$magic_option}</select>";
        } else {
            $html .= "<span style=\"display:none;color:red;\" class=\"{$key}_winning_prize{$n} id2\">{$e6_lang['a_p_8']}(<a href=\"" . ADMINSCRIPT . '?action=magics&operation=admin" style="color:blue;">' . $e6_lang['a_p_9'] . '</a>)</span>';
        }
        if ($medal_list) {
            $medal_option = '';
            foreach ($medal_list as $v) {
                $medal_option .= '<option value="' . $v['medalid'] . '" ' . ($v['medalid'] == $e6_box->config[$key . '_winning_prize' . $n . '_medal'] ? 'selected' : '') . '>' . $v['name'] . '</option>';
            }
            $html .= "<select name=\"setting[{$key}_winning_prize{$n}_medal]\" style=\"width:120px;display:none;\" class=\"{$key}_winning_prize{$n} id3\">{$medal_option}</select>";
        } else {
            $html .= "<span style=\"color:red;display:none;\" class=\"{$key}_winning_prize{$n} id3\">{$e6_lang['a_p_10']}(<a href=\"" . ADMINSCRIPT . "?action=medals\" style=\"color:blue;\">{$e6_lang['a_p_9']}</a>)</span>";
        }
        if ($vip_groups) {
            $group_option = '';
            foreach ($vip_groups as $k => $v) {
                $group_option .= '<option value="' . $k . '" ' . ($k == $e6_box->config[$key . '_winning_prize' . $n . '_group'] ? 'selected' : '') . '>' . $v . '</option>';
            }
            $html .= "<select name=\"setting[{$key}_winning_prize{$n}_group]\" style=\"width:120px;display:none;\" class=\"{$key}_winning_prize{$n} id4\">{$group_option}</select>";
            $html .= "<input name=\"setting[{$key}_winning_prize{$n}_group_day]\" value=\"{$e6_box->config[$key . '_winning_prize' . $n . '_group_day']}\" type=\"text\" class=\"{$key}_winning_prize{$n} id4\" style=\"width:80px;display:none;\" /> ";
            $html .= "<span class=\"{$key}_winning_prize{$n} id4\" style=\"display:none;\"> {$e6_lang['a_p_11']}</span>";
        } else {
            $html .= "<span style=\"color:red;display:none;\" class=\"{$key}_winning_prize{$n} id4\">{$e6_lang['a_p_12']}(<a href=\"" . ADMINSCRIPT . "?action=usergroups\" style=\"color:blue;\">{$e6_lang['a_p_13']}</a>)</span>";
        }
        $html .= "<input name=\"setting[{$key}_winning_prize{$n}_magapp]\" value=\"{$e6_box->config[$key . '_winning_prize' . $n . '_magapp']}\" type=\"text\" class=\"{$key}_winning_prize{$n} id5\" style=\"width:80px;display:none;\" /> <span class=\"{$key}_winning_prize{$n} id5\" style=\"display:none;\">{$e6_lang['a_p_14']}</span>";
        $html .= "<span style=\"display:none;\" class=\"{$key}_winning_prize{$n} id6\">{$e6_lang['a_p_15']}: </span>";
        $html .= "<input name=\"setting[{$key}_winning_prize{$n}_custom]\" value=\"{$e6_box->config[$key . '_winning_prize' . $n . '_custom']}\" type=\"text\" class=\"{$key}_winning_prize{$n} id6\" style=\"width:300px;display:none;\" /> ";
        $html .= "<span class=\"{$key}_winning_prize{$n} id7\" style=\"display:none;\" />{$e6_lang['a_p_16']}</span>";
        showtablerow('class="noborder"', 'class="vtop rowform" colspan="2" style="width:100%"', $html);
    }
}
showsubmit('e6_submit');
showtablefooter();/*Dism_taobao_com*/
showformfooter();
