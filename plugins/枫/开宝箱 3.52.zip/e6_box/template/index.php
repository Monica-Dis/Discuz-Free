<?php exit('QQ:66698899'); ?>
<!--{template common/header}-->
<script src="source/plugin/e6_box/static/js/jquery.min.js"></script>
<script src="source/plugin/e6_box/static/js/jCarouselLite.js"></script>
<script src="source/plugin/e6_box/static/js/pc.js?v={$e6_box->version}"></script>
<link rel="stylesheet" href="source/plugin/e6_box/static/css/pc.css?v={$e6_box->version}" />

<div class="wrap" id="app" formhash="{FORMHASH}" uid="{$_G['uid']}" style="padding-bottom:20px;">
	<div class="main">
        <div class="decorate">
            <i class="icon_line"></i>
            <i class="icon_cir"></i>
        </div>
    	<div class="banner">
            <div class="ban_tit">
				<!--{if ($e6_box->today_limit() != 'unlimited')}-->
				<div class="ban_tit_bottom">
                	<i class="eye_nor eye_1"></i>
                	<i class="eye_nor eye_2"></i>
                	<i class="eye_nor eye_3"></i>
                	<div class="today_limit"><!--{eval echo $e6_box->today_limit()}--></div> 
                </div>
				<!--{else}-->
				<i class="eye_nor eye_1"></i>
            	<i class="eye_nor eye_2"></i>
            	<i class="eye_nor eye_3"></i>
				<!--{/if}-->
            </div>
    	</div>
        <div class="cont1">
            <div class="c1_top">
                <ul class="box_list">
                    <li>
                        <div class="box_nop" id="box3">
                            <a href="javascript:;" class="btn_nbox btn_bnor" type="3">{lang e6_box:pc_1}</a>
                            <i class="icon_lqp icon_qp"></i>
                            <i class="icon_rqp icon_qp"></i>
                            <div class="icon_boxn3 icon_box_nor">
                                <span class="mon_tips">{$spent_money[3]}</span>
                            </div>
                        </div>
                        <div class="box_oped" id="open3">
                            <div class="icon_boxo3 icon_box_nor">
                                <i class="icon_coin3"></i>
                            </div>
                            <a href="javascript:;" class="btn_obox btn_bnor btn_opened">{lang e6_box:pc_2}</a>
                        </div>
                        <!--{if $spent_money[6]}-->
                        <p class="box_tip2 spent_money3">{$spent_money[6]}</p>
						<!--{/if}-->
                    </li>
                    <li>
                        <div class="box_nop" id="box2">
                            <a href="javascript:;" class="btn_nbox btn_bnor" type="2">{lang e6_box:pc_1}</a>
                            <i class="icon_lqp icon_qp"></i>
                            <i class="icon_rqp icon_qp"></i>
                            <div class="icon_boxn1 icon_box_nor">
                                <span class="mon_tips">{$spent_money[2]}</span>
                            </div>
                        </div>
                        <div class="box_oped" id="open2">
                            <div class="icon_boxo2 icon_box_nor">
                                <i class="icon_coin3"></i>
                            </div>
                            <a href="javascript:;" class="btn_obox btn_bnor btn_opened">{lang e6_box:pc_2}</a>
                        </div>
                        <!--{if $spent_money[5]}-->
                        <p class="box_tip2 spent_money2">{$spent_money[5]}</p>
						<!--{/if}-->
                    </li>
                    <li>
                        <div class="box_nop" id="box1">
                            <a href="javascript:;" class="btn_nbox btn_bnor" type="1">{lang e6_box:pc_1}</a>
                            <i class="icon_lqp icon_qp"></i>
                            <i class="icon_rqp icon_qp"></i>
                            <div class="icon_boxn2 icon_box_nor">
                                <span class="mon_tips">{$spent_money[1]}</span>
                            </div>
                        </div>
                        <div class="box_oped" id="open1">
                            <div class="icon_boxo3 icon_box_nor">
                                <i class="icon_coin3"></i>
                            </div>
                            <a href="javascript:;" class="btn_obox btn_bnor btn_opened">{lang e6_box:pc_2}</a>
                        </div>
                        <!--{if $spent_money[4]}-->
                        <p class="box_tip2 spent_money1">{$spent_money[4]}</p>
						<!--{/if}-->
                    </li>
                </ul>
            </div>
            <div class="c1_bot">
                <div class="c1_bot_main">
                    <h4 class="c1_bot_tit">{lang e6_box:pc_3}</h4>
                    <div class="wp_pri_list">
                        <ul class="pri_list">
                            <!--{loop $all_winning_list $v}-->
                            <li>
                                {lang e6_box:pc_4}<span class="fc_yel"> {$v['username']} </span> <span>{lang e6_box:pc_5}<span class="fc_yel">{$v['describe']}</span>
                            </li>
					       <!--{/loop}-->
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
        <div class="cont3">
            <div class="log_list">
                <h4 class="c1_bot_tit">{lang e6_box:pc_6}</h4>
                <div class="log_content">
                    <!--{if $my_winning_list}-->
                    <table>
                        <tbody id="my-award-content">
                            <!--{loop $my_winning_list $v}-->
                            <tr>
                                <td class="td1">{$v['content']}</td>
                                <td>{$v['date']}</td>
                            </tr>
                            <!--{/loop}-->
                        </tbody>
                    </table>
                    <div id="list-more" page="{$page}" end="{$end}">{lang e6_box:pc_7} >>> </div>
                    <!--{else}-->
                    <div id="no-my-award">{lang e6_box:pc_8}</div>
                    <!--{/if}-->
                </div>
            </div>
        </div>
        <div class="cont2">
           <div class="rule">
               <h3 class="rule_tit">{lang e6_box:pc_9}</h3>
               <div class="rule_main">
                   <ol class="rule_list">
                       {$e6_box->config['rules']}
                   </ol>
               </div>
           </div>
        </div>
    </div>
    <div class="toast" style="display: none;">
        <div class="toast-wrapper toast--hidden toast--visible">
            <div class="toast-notice toast-info">
                <div class="toast-text"></div>
            </div>
        </div>
        <div class="toast-mask"></div>
    </div>
</div>
<!--{template common/footer}-->