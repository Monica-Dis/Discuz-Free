<?php exit('QQ:66698899'); ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<meta charset="{CHARSET}">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="format-detection" content="telephone=no">
	<title>{lang e6_box:m_1}</title>
	<meta name="keywords" content="{lang e6_box:m_1}">
	<meta name="description" content="{lang e6_box:m_1}">
	<script src="source/plugin/e6_box/static/js/jquery.min.js"></script>
	<script src="source/plugin/e6_box/static/js/flexible.js"></script>
	<script src="source/plugin/e6_box/static/js/jCarouselLite.js"></script>
	<script src="source/plugin/e6_box/static/js/mobile.js?v={$e6_box->version}"></script>
	<link rel="stylesheet" href="source/plugin/e6_box/static/css/mobile.css?v={$e6_box->version}" />
</head>
<body>
<div id="app" formhash="{FORMHASH}" uid="{$_G['uid']}">
	<div id="app-header">
		<a href="#rules" class="link-rule">{lang e6_box:m_2}</a>
	</div>
	<div id="box">
		<div class="box-box">
			<!--{if ($e6_box->today_limit() != 'unlimited')}-->
			<div class="today_limit"><!--{eval echo $e6_box->today_limit()}--></div>
			<!--{/if}-->
			<div class="hd-boxs">
				<div class="hd-box hd-box-copper" type="3">
					<button class="kaixiang copper"></button>
				</div>
				<div class="hd-box hd-box-silver" type="2">
					<button class="kaixiang silver"></button>
				</div>
				<div class="hd-box hd-box-gold" type="1">
					<button class="kaixiang gold"></button>
				</div>
			</div>
			<div class="box-instructions">
				<div class="box-instruction spent_money3">{$spent_money[3]}</div>
				<div class="box-instruction spent_money2">{$spent_money[2]}</div>
				<div class="box-instruction spent_money1">{$spent_money[1]}</div>
			</div>
			<!-- 我的宝箱 -->
			<div class="all-award">
			<!--{if $all_winning_list}-->
			<div class="all-award-list">
				<ul>
					<!--{loop $all_winning_list $v}-->
					<li>{lang e6_box:m_3}<span class="l-left"> {$v['username']} </span> <span>{lang e6_box:m_4}<span class="l-right">{$v['describe']}</span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{else}-->
				<div class="no-all-award">{lang e6_box:m_5}</div>
			<!--{/if}-->
			</div>
		</div>
	</div>
	<div class="act-box" id="record">
		<div class="act-head">
			<h2 class="act-title">{lang e6_box:m_6}</h2>
		</div>
		<div class="act-body">
			<div class="act-content">
				<div class="my-award">
					<!--{if $my_winning_list}-->
					<table>
                        <tbody id="my-award-content">
						<!--{loop $my_winning_list $v}-->
						<tr>
							<td class="td1">{$v['content']}</td>
							<td>{$v['date']}</td>
						</tr>
						<!--{/loop}-->
                        </tbody>
                    </table>
					<div id="list-more" page="{$page}" end="{$end}">{lang e6_box:m_7} >>> </div>
					<!--{else}-->
					<div class="no-list">{lang e6_box:m_8}</div>
					<!--{/if}-->
				</div>
			</div>
		</div>
	</div>
	<div class="act-fanli">
		<div class="act-box" id="rules">
			<div class="act-head">
				<h2 class="act-title">{lang e6_box:m_9}</h2>
			</div>
			<div class="act-body">
				<div class="act-content">
					<div class="rule-box">
						<div class="rule-list">
							<ul>{$e6_box->config['rules']}</ul>
						</div>
					</div>
				</div>
			</div>
		</div>					
	</div>
</div>
<div class="toast" style="display: none;">
	<div class="toast-wrapper toast--hidden toast--visible">
    	<div class="toast-notice toast-info">
      		<div class="toast-text"></div>
    	</div>
  	</div>
  	<div class="toast-mask"></div>
</div>
<div class="wd-overlay hd-overlay" style="display: none;">
	<div class="overlay-mask overlay--visible"></div>
	<div class="overlay-wrapper overlay--visible">
		<div class="overlay-content">
			<div class="hd-box">
				<div class="hd-content">
      				<div class="cash-coupon-box">
        				<div class="hd-label"><b></b></div>
        				<a class="hd-btn">{lang e6_box:m_10}</a>
      				</div>
				</div>
				<button class="hd-close"><i class="icon-guanbi"></i></button>
			</div>
		</div>
	</div>
</div>
</body>
</html>