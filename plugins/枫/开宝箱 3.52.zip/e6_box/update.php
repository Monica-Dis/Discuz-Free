<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

!$fromversion && $fromversion = $_GET['fromversion'];

if ($fromversion < 3.5) {

  $sql = <<<SQL
ALTER TABLE `pre_e6_box_user` RENAME TO `pre_e6_box_winning_user`;
DROP TABLE `pre_e6_box_free_setting`;

DROP TABLE IF EXISTS `pre_e6_box_last_time`;
CREATE TABLE `pre_e6_box_last_time`  (
  `last_time` int(10) UNSIGNED NULL DEFAULT NULL
) ENGINE = MyISAM;

DROP TABLE IF EXISTS `pre_e6_box_limit_user`;
CREATE TABLE `pre_e6_box_limit_user`  (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) NOT NULL,
  `date` int(10) NOT NULL,
  `number` smallint(5) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `uid`(`uid`) USING BTREE
) ENGINE = MyISAM;

DROP TABLE IF EXISTS `pre_e6_box_magapp_price`;
CREATE TABLE `pre_e6_box_magapp_price`  (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` mediumint(8) UNSIGNED NOT NULL,
  `price` decimal(10, 2) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `order` varchar(255) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM;

SQL;
	runquery($sql);
}
$finish = TRUE;
?>