<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$sql = "DROP TABLE `pre_e6_box_count`, `pre_e6_box_credit`, `pre_e6_box_free_user`, `pre_e6_box_last_time`, `pre_e6_box_limit_user`, `pre_e6_box_magapp_price`, `pre_e6_box_winning_user`;";
runquery($sql);

@unlink(DISCUZ_ROOT . '/data/e6_box.config.php');
$finish = TRUE;
?>