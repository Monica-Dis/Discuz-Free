<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require 'e6_box.class.php';

if ($_GET['deldate'] && $_GET['formhash'] == formhash()) {
    $olddate = $_G['timestamp'] - intval($_GET['deldate']) * 86400;
    C::t('#e6_box#e6_box_credit')->delete_by_log($olddate);
    cpmsg($e6_lang['a_o_1'], cpurl(false, ['deldate']), 'succeed');
} elseif (submitcheck('dellog')) {
    if (is_array($_GET['log_id'])) {
        C::t('#e6_box#e6_box_credit')->delete($_GET['log_id']);
        cpmsg($e6_lang['a_o_1'], cpurl(false), 'succeed');
    }
}
showformheader('plugins&identifier=e6_box&pmod=admin_log');
$html = $e6_lang['a_o_2'] .
    '<a href="' . ADMINSCRIPT . '?action=plugins&identifier=e6_box&operation=config&pmod=admin_log&deldate=30&do=' . $plugin['pluginid'] . '&formhash=' . FORMHASH . '" onclick="return confirm(\''.$e6_lang['a_o_3'].'\');">'.$e6_lang['a_o_4'].'</a> | ' .
    '<a href="' . ADMINSCRIPT . '?action=plugins&identifier=e6_box&operation=config&pmod=admin_log&deldate=7&do=' . $plugin['pluginid'] . '&formhash=' . FORMHASH . '" onclick="return confirm(\''.$e6_lang['a_o_3'].'\');">'.$e6_lang['a_o_5'].'</a> | ' .
    '<a href="' . ADMINSCRIPT . '?action=plugins&identifier=e6_box&operation=config&pmod=admin_log&deldate=1&do=' . $plugin['pluginid'] . '&formhash=' . FORMHASH . '" onclick="return confirm(\''.$e6_lang['a_o_3'].'\');">'.$e6_lang['a_o_6'].'</a>';

showtableheader($html);
$type_option = "<option value=''>{$e6_lang['a_o_7']}</option>";
foreach ($_G['setting']['extcredits'] as $k => $v) {
    $type_option .= "<option value=\"{$k}\">{$v['title']}</option>";
}
$log_type       = [1 => $e6_lang['a_o_8'], 2 => $e6_lang['a_o_9']];
$logtype_option = "<option value=''>{$e6_lang['a_o_7']}</option>";
foreach ($log_type as $k => $v) {
    $logtype_option .= "<option value=\"{$k}\">{$v}</option>";
}
print '<script src="static/js/calendar.js" type="text/javascript"></script>';
showtablerow('',
    ['width="125"', 'width="125"', 'width="160"', 'width="320"'],
    [
        $e6_lang['a_o_10'].': <input type="text" name="username" style="width:65px;">',
        $e6_lang['a_o_11'].': <select name="type">' . $type_option . '</select>',
        $e6_lang['a_o_12'].': <select name="logtype">' . $logtype_option . '</select>',
        $e6_lang['a_o_13'].': <input type="text" name="sdate" style="width: 108px;" onclick="showcalendar(event, this)"> -- <input type="text" name="edate" style="width: 108px;" onclick="showcalendar(event, this)">',
        "<input class=\"btn\" type=\"submit\" value=\"$lang[search]\" />"
    ]
);
showtablefooter();/*Dism_taobao_com*/
showtableheader();/*Dism��taobao��com*/
$tabletop = [
    'ID',
    $e6_lang['a_o_10'],
    $e6_lang['a_o_14'],
    $e6_lang['a_o_15'],
    $e6_lang['a_o_16'],
    $e6_lang['a_o_17'],
    $e6_lang['a_o_12'],
    $e6_lang['a_o_13'],
    'IP',
    $e6_lang['a_o_18'],
    $e6_lang['a_o_19']
];
showsubtitle($tabletop);
$perpage = 20;
$start   = ($page - 1) * $perpage;
if ($_GET['username']) {
    $uid = C::t('common_member')->fetch_uid_by_username($_GET['username']);
    $conditions .= " AND c.uid='{$uid}'";
    $theurl .= '&username=' . $_GET['username'];
}
if ($_GET['type'] != '') {
    $conditions .= " AND `type`='" . dintval($_GET['type']) . "'";
    $theurl .= '&type=' . $_GET['type'];
}
if ($_GET['logtype'] != '') {
    $conditions .= " AND `logtype`='" . dintval($_GET['logtype']) . "'";
    $theurl .= '&logtype=' . $_GET['logtype'];
}
if ($_GET['sdate']) {
    $sdate = strtotime($_GET['sdate']);
    $conditions .= " AND `date`>'" . strtotime($_GET['sdate']) . "'";
    $theurl .= '&sdate=' . $_GET['sdate'];
}
if ($_GET['edate']) {
    $edate = strtotime($_GET['edate']);
    $conditions .= " AND `date`<'" . strtotime($_GET['edate']) . "'";
    $theurl .= '&edate=' . $_GET['edate'];
}
$logcount = C::t('#e6_box#e6_box_credit')->count_by_search($conditions);
if ($logcount) {
    $n = ($page - 1) * $perpage + 1;
    foreach (C::t('#e6_box#e6_box_credit')->fetch_all_by_search($conditions, $start, $perpage) as $v) {
        showtablerow('', '', [
            $n,
            $v['username'],
            $_G['setting']['extcredits'][$v['type']]['title'],
            $v['smoney'],
            $v['change'],
            $v['emoney'],
            $log_type[$v['logtype']],
            dgmdate($v['date']),
            $v['ip'],
            $v['describe'],
            '<input class="checkbox" type="checkbox" id="log_id" name="log_id[]" value="' . $v['id'] . '" />'
        ]);
        $n++;
    }
    $multi = multi($logcount, $perpage, $page, ADMINSCRIPT . '?' . cpurl(false) . $theurl);
}
showtablefooter();/*Dism_taobao_com*/
showsubmit('', '', '', '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'log_id\')" /><label for="chkall">' . cplang('select_all') . '</label>&nbsp;&nbsp;<input type="submit" onclick="return confirm(\''.$e6_lang['a_o_3'].'\');" class="btn" name="dellog" value="'.$e6_lang['a_o_19'].'" />', $multi);
showformfooter();
