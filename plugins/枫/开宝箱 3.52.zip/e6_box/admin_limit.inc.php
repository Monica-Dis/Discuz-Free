<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require 'e6_box.class.php';

if (submitcheck('e6_submit')) {
    $e6_box->save_setting();
}

foreach (C::t('common_usergroup')->range() as $group) {
    $groups[$group['groupid']] = $group['grouptitle'];
}

showformheader('plugins&' . cpurl(false, ['action']));
showtableheader($e6_lang['a_l_1']);

showsetting($e6_lang['a_l_2'], 'setting[limit][all]', $e6_box->config['limit']['all'], 'text', 0, 0, $e6_lang['a_l_3']);

foreach ($groups as $key => $value) {
    showsetting($value, "setting[limit][{$key}]", $e6_box->config['limit'][$key], 'text', 0, 0, $e6_lang['a_l_3']);
}
showsubmit('e6_submit');
showtablefooter();/*Dism_taobao_com*/
showformfooter();
