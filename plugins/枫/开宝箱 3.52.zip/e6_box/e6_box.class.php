<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class e6_box
{
    public $config = [];

    public $version = '3.52';

    private static $instance;

    public $setting_type = [];

    final private function __construct()
    {
        @include DISCUZ_ROOT . 'data/e6_box.config.php';
        if ($config) {
            $this->config = $config;
        }

        $this->setting_type = [
            1 => $this->lang('class_1'),
            2 => $this->lang('class_2'),
            3 => $this->lang('class_3')
        ];
    }

    public static function getInstance()
    {
        if (empty(self::$instance)) {
            self::$instance = new e6_box();
        }
        return self::$instance;
    }

    public function lang($str, $arr = [])
    {
        return lang('plugin/e6_box', $str, $arr);
    }

    public function export($str, $indent = '')
    {
        switch (gettype($str)) {
            case 'string':
                return "'" . str_replace(['\\', "'"], ['\\\\', "\'"], $str) . "'";
            case 'array':
                $output = "array(\r\n";
                foreach ($str as $key => $value) {
                    $output .= $indent . "\t" . $this->export($key, $indent . "\t") . ' => ' . $this->export($value, $indent . "\t");
                    $output .= ",\r\n";
                }
                $output .= $indent . ')';
                return $output;
            case 'boolean':
                return $str ? 'true' : 'false';
            case 'NULL':
                return 'NULL';
            case 'integer':
            case 'double':
            case 'float':
                return "'" . (string) $str . "'";
        }
        return 'NULL';
        uc_user_synlogout();
    }

    public function writeover($filename, $data, $method = 'rb+', $iflock = 1, $check = 1, $chmod = 1)
    {
        if ($check && strpos($filename, '..') !== false) {
            return false;
        }
        touch($filename);
        $handle = fopen($filename, $method);
        $iflock && flock($handle, LOCK_EX);
        fwrite($handle, $data);
        $method == 'rb+' && ftruncate($handle, strlen($data));
        fclose($handle);
        $chmod && @chmod($filename, 0777);
    }

    public function save_setting()
    {
        !$_GET['setting'] && $_GET['setting'] = [];
        $config                               = array_merge($this->config, $_GET['setting']);
        if (count($config) > 0) {
            $data = $this->export($config);
            $data = "\$config = $data;\r\n";
            $this->writeover(DISCUZ_ROOT . 'data/e6_box.config.php', "<?php\r\n" . $data . '?>');
            cpmsg('setting_update_succeed', cpurl(false), 'succeed');
        } else {
            cpmsg($this->lang('class_4'), cpurl(false), 'succeed');
        }
    }

    public function prize_type($key = null)
    {
        $prize_type = [
            0 => $this->lang('class_5'),
            1 => $this->lang('class_6'),
            2 => $this->lang('class_7'),
            3 => $this->lang('class_8'),
            4 => $this->lang('class_9'),
            5 => $this->lang('class_10'),
            6 => $this->lang('class_11'),
            7 => $this->lang('class_12')
        ];

        if ($this->config['magapp_open'] != 1) {
            unset($prize_type[5]);
        }

        return ($key ? $prize_type[$key] : $prize_type);
    }

    public function money_list($key = null)
    {
        global $_G;
        foreach ($_G['setting']['extcredits'] as $k => $v) {
            $money_list[$k] = $v['title'];
        }
        return ($key ? $money_list[$key] : $money_list);
    }

    public function today_limit()
    {
        global $_G;

        if (empty($_G['uid'])) {
            return $this->lang('class_13');
        }
        if ($this->config['limit'][$_G['groupid']] > 0 || $this->config['limit']['all'] > 0) {

            $today_limit = $this->get_limit_number();

            if ($today_limit > 0) {
                return $this->lang('class_14', ['today_limit' => $today_limit]);
            } else {
                return $this->lang('class_15');
            }

        } else {
            return 'unlimited';
        }
    }

    public function get_limit_number()
    {
        global $_G;

        if ($this->config['limit'][$_G['groupid']] > 0 || $this->config['limit']['all'] > 0) {

            if ($this->config['limit'][$_G['groupid']] > 0) {
                $limit = $this->config['limit'][$_G['groupid']];
            } else {
                $limit = $this->config['limit']['all'];
            }

            $today_number = C::t('#e6_box#e6_box_limit_user')->get_limit_number($_G['uid']);

            $today_limit = $limit - $today_number;

            return $today_limit;

        } else {

            return 0;
        }
    }

    public function increase_today_number()
    {
        global $_G;
        C::t('#e6_box#e6_box_limit_user')->increase_number($_G['uid']);
    }

    public function user_free_number()
    {
        global $_G;
        if ($_G['uid'] && in_array($_G['groupid'], $this->config['group'])) {

            for ($i = 1; $i <= 3; $i++) {
                $data[$i] = intval($this->config['free'][$_G['groupid']][$i] ? $this->config['free'][$_G['groupid']][$i] : $this->config['free']['all'][$i]);
            }

            $my_free_number = C::t('#e6_box#e6_box_free_user')->get_free_number($_G['uid']);

            for ($i = 1; $i <= 3; $i++) {
                $free_number = $data[$i] - $my_free_number['type' . $i];
                if ($free_number < 0) {
                    $free_number = 0;
                }
                $my_number[$i] = $free_number + $my_free_number['num' . $i];
            }
            return $my_number;
        } else {
            return [0, 0, 0];
        }
    }

    public function spent_money()
    {

        $free_data = $this->user_free_number();

        if (defined('IN_MOBILE')) {
            for ($i = 1; $i <= 3; $i++) {
                if ($free_data[$i] > 0) {
                    $spent_money[$i] = $this->lang('class_16', ['free_data' => $free_data[$i]]);
                } else {
                    $spent_money[$i] = $this->config['money' . $i] . $this->money_list($this->config['type' . $i]) . $this->lang('class_17');
                }
            }

        } else {

            for ($i = 1; $i <= 3; $i++) {
                $spent_money[$i] = $this->config['money' . $i] . $this->money_list($this->config['type' . $i]);
                if ($free_data[$i] > 0) {
                    $n               = $i + 3;
                    $spent_money[$n] = $this->lang('class_18', ['free_data' => $free_data[$i]]);
                }
            }
        }

        return $spent_money;
    }

    public function error($msg)
    {
        print json_encode(['status' => 'error', 'msg' => $this->transcoding($msg)]);die;
    }

    public function success($msg, $data = [])
    {
        $msg_data = ['status' => 'success', 'msg' => $msg];
        $new_data = array_merge($msg_data, $data);
        print json_encode($this->transcoding($new_data));die;
    }

    public function transcoding($data)
    {
        global $_G;
        if ($_G['charset'] == 'gbk') {
            if (!is_array($data)) {
                $data = iconv('GB2312//IGNORE', 'UTF-8', $data);
            } else {
                foreach ($data as $key => $value) {
                    if (is_array($value)) {
                        foreach ($value as $k => $v) {
                            $new_data[$key][$k] = iconv('GB2312//IGNORE', 'UTF-8', $v);
                        }
                    } else {
                        $new_data[$key] = iconv('GB2312//IGNORE', 'UTF-8', $value);
                    }
                }
                $data = $new_data;
            }
        }
        return $data;
    }

    public function check_user_money($money, $type)
    {
        global $_G;

        $user = C::t('common_member_count')->fetch($_G['uid']);

        if ($money >= $user['extcredits' . $type]) {
            return false;
        } else {
            return true;
        }
    }

    public function decrease_free_number($type)
    {
        global $_G;

        $free_number = intval($this->config['free'][$_G['groupid']][$type] ? $this->config['free'][$_G['groupid']][$type] : $this->config['free']['all'][$type]);

        $my_free_number = C::t('#e6_box#e6_box_free_user')->get_free_number($_G['uid']);

        if ($my_free_number['type' . $type] >= $free_number) {
            C::t('#e6_box#e6_box_free_user')->decrease_number($_G['uid'], $type);
        }

        C::t('#e6_box#e6_box_free_user')->increase_number($_G['uid'], $type);
    }

    public function update_money($money_arr = [], $log_type, $lang_arr = [], $uid, $e6_user = [])
    {
        global $_G;
        if ($money_arr) {
            $money_arr = array_filter($money_arr);
        }

        if ($money_arr) {
            foreach ($money_arr as $k => $v) {
                $e6_money['extcredits' . $k] = $v;
            }
            if (!$e6_user) {
                $e6_user = C::t('common_member_count')->fetch($uid);
            }

            updatemembercount($uid, $e6_money);
        }
        foreach ($money_arr as $k => $v) {
            $money_lang = ['money' => $v . $_G['setting']['extcredits'][$k]['title']];
            $lang_arr   = $lang_arr ? array_merge($money_lang, $lang_arr) : $money_lang;
            C::t('#e6_box#e6_box_credit')->insert([
                'uid'      => $uid,
                'type'     => $k,
                'logtype'  => (float) $log_type,
                'smoney'   => $e6_user['extcredits' . $k],
                'emoney'   => $e6_user['extcredits' . $k] + $v,
                'change'   => $v,
                'date'     => $_G['timestamp'],
                'ip'       => $_G['clientip'],
                'describe' => $this->lang('log_' . $log_type, $lang_arr)
            ]);
            $e6_user['extcredits' . $k] = $e6_user['extcredits' . $k] + $v;
        }
        return $e6_user;
    }

    public function open_box($type)
    {
        global $_G;

        if (!submitcheck('formhash')) {
            $this->error($this->lang('class_19'));
        }

        if (empty($_G['uid'])) {
            $this->error($this->lang('class_20'));
        }
        if (!in_array($_G['groupid'], $this->config['group'])) {
            $this->error($this->lang('class_21'));
        }

        $type = intval($type);

        if ($type < 1 || $type > 3) {
            $this->error($this->lang('class_19'));
        }

        $free_data   = $this->user_free_number();
        $free_number = $free_data[$type];

        if ($this->config['limit'][$_G['groupid']] > 0 || $this->config['limit']['all'] > 0) {
            $limit_number = $this->get_limit_number();
            if ($limit_number < 1 && $free_number < 1) {
                $this->error($this->lang('class_22'));
            }
        }

        if ($free_number < 1 && !$this->check_user_money($this->config['money' . $type], $this->config['type' . $type])) {
            $this->error($this->lang('class_23'));
        }

        if ($free_number > 0) {
            $this->decrease_free_number($type);

        } else {
            $this->increase_today_number();
            $box_title = $this->setting_type[$type];
            $this->update_money([$this->config['type' . $type] => -$this->config['money' . $type]], 1, ['title' => $box_title], $_G['uid']);
        }

        $reward_rate = rand(1, 10000);

        $M1 = $this->config[$type . '_winning_rate1'];
        for ($n = 1; $n <= 8; $n++) {
            $rate = $this->config[$type . '_winning_rate' . $n];

            $M += intval($rate);
            if ($n != 1) {
                $i          = $n - 1;
                ${'M' . $n} = ${'M' . $i}+$rate;
            }
        }
        if ($reward_rate > $M) {
            $this->success($this->lang('class_24'));
        } else {

            for ($n = 1; $n <= 8; $n++) {
                $rate      = $this->config[$type . '_winning_rate' . $n];
                $prize_num = C::t('#e6_box#e6_box_count')->get_number($type . $n);

                if ($n == 1) {
                    if ($reward_rate <= $M1) {

                        if ($rate && ($prize_num > 0 or $prize_num == -1)) {
                            $msg_data = $this->send_reward($type, $n);
                            break;
                        } else {
                            continue;
                        }
                    }
                } else {
                    $i = $n - 1;

                    if ($reward_rate > ${'M' . $i} && $reward_rate <= ${'M' . $n}) {

                        if ($rate && ($prize_num > 0 or $prize_num == -1)) {
                            $msg_data = $this->send_reward($type, $n);
                            break;
                        } else {
                            continue;
                        }
                    }
                }
            }

            if ($msg_data) {

                $this->send_msg($type, $msg_data[0], $msg_data[1]);
                $this->insert_winning_log($type, $msg_data[0], $msg_data[1]);
                $data = $this->get_last_update_content();
                $this->success($this->lang('class_25', ['msg1' => $msg_data[0], 'msg2' => $msg_data[1]]), $data);
            } else {
                $this->success($this->lang('class_26'));
            }
        }
    }

    public function insert_winning_log($type, $num, $describe)
    {
        global $_G;
        C::t('#e6_box#e6_box_winning_user')->insert([
            'uid'      => $_G['uid'],
            'box'      => $type,
            'num'      => $num,
            'date'     => TIMESTAMP,
            'describe' => $describe
        ]);
    }

    public function send_msg($type, $num, $describe)
    {
        $message = $this->lang('class_27', ['type' => $this->setting_type[$type], 'describe' => $describe]);
        if ($this->config['magapp_open'] == 1) {
            $this->send_magapp_user_msg($uid, $message);
        } else {
            notification_add($uid, 'system', 'system_notice', [
                'subject'     => $this->lang('class_28'),
                'message'     => $message,
                'from_id'     => 0,
                'from_idtype' => 'e6_box'
            ], 1);
        }
    }

    public function send_reward($type, $n)
    {

        global $_G;

        $prize_type = $this->config[$type . '_winning_prize' . $n];

        switch ($prize_type) {
            case '1':
                $money      = $this->config[$type . '_winning_prize' . $n . '_money'];
                $money_type = $this->config[$type . '_winning_prize' . $n . '_money_type'];
                $js_msg     = $money . $this->money_list($money_type);

                $this->update_money([$money_type => $money], 2, ['title' => $this->setting_type[$type]], $_G['uid']);
                break;

            case '2':
                $number = $this->config[$type . '_winning_prize' . $n . '_magic_num'];
                $magic  = C::t('common_magic')->fetch($this->config[$type . '_winning_prize' . $n . '_magic']);
                $js_msg = $number . $this->lang('class_29') . $magic['name'];

                $this->send_magic($_G['uid'], $magic['magicid'], $number);
                break;
            case '3':
                $medal  = C::t('forum_medal')->fetch($this->config[$type . '_winning_prize' . $n . '_medal']);
                $js_msg = $medal['name'] . $this->lang('class_30');

                $this->send_medal($_G['uid'], $medal['medalid']);
                break;
            case '4':

                $groupid    = $this->config[$type . '_winning_prize' . $n . '_group'];
                $group_date = $this->config[$type . '_winning_prize' . $n . '_group_day'];

                $group            = C::t('common_usergroup')->fetch($groupid);
                $group_date_title = $group_date ? $group_date . $this->lang('class_31') : $this->lang('class_32');
                $js_msg           = $this->lang('class_33') . "{$group['grouptitle']} ({$group_date_title})";

                $this->send_group($_G['uid'], $groupid, $group_date);

                break;
            case '5':
                $price  = $this->config[$type . '_winning_prize' . $n . '_magapp'];
                $remark = $this->lang('class_34');
                $js_msg = $price . $this->lang('class_35');

                $this->send_magapp_price($_G['uid'], $price, $remark);
                break;
            case '6':
                $reward = $this->config[$type . '_winning_prize' . $n . '_custom'];
                $js_msg = $reward;
                break;
            case '7':
                $js_msg = $this->lang('class_36');

                $this->send_once_more($_G['uid'], $type, 1);
                break;
            default:
                return false;
                break;
        }

        $prize_arr = C::t('#e6_box#e6_box_count')->fetch($type . $n);
        if ($prize_arr['n'] > 0) {
            C::t('#e6_box#e6_box_count')->update_by_num($type . $n, '`n`=`n`-1');
        }

        return [$n, $js_msg];
    }

    public function send_magapp_user_msg($uid, $message)
    {
        global $_G;
        $url = $this->config['magapp_url'] . '/mag/operative/v1/assistant/sendAssistantMsg?user_id=' . $uid . '&type=text&content={"type":"text","content":"' . urlencode($message) . '"}&secret=' . $this->config['magapp_secret'] . '&is_push=1' . '&assistant_secret=' . $this->config['assistant_secret'];
        dfsockopen($url);
    }

    public function send_magic($uid, $magicid, $num = 1)
    {
        $data = C::t('common_member_magic')->fetch($uid, $magicid);
        if ($data) {
            C::t('common_member_magic')->increase($uid, $magicid, ['num' => $num]);
        } else {
            C::t('common_member_magic')->insert([
                'uid'     => $uid,
                'magicid' => $magicid,
                'num'     => $num]);
        }
        require_once libfile('function/magic');
        updatemagiclog($magicid, '3', $num, '', $uid);
    }

    public function send_medal($uid, $medalid)
    {
        $user = C::t('common_member_field_forum')->fetch($uid);
        if ($user['medals']) {
            $my_medal_arr = explode("\t", $user['medals']);
            if (!in_array($medalid, $my_medal_arr)) {
                $new_medal = $medalid . "\t" . $user['medals'];
            }
        } else {
            $new_medal = $medalid;
        }
        if ($new_medal) {
            C::t('common_member_field_forum')->update($uid, ['medals' => $new_medal], true);
            $data = [
                'uid'        => $uid,
                'medalid'    => $medalid,
                'type'       => 0,
                'dateline'   => TIMESTAMP,
                'expiration' => 0,
                'status'     => 0
            ];
            C::t('forum_medallog')->insert($data);
            C::t('common_member_medal')->insert(['uid' => $uid, 'medalid' => $medalid], 0, 1);
        }
    }

    public function send_group($uid, $groupid, $date = null)
    {
        $user       = C::t('common_member')->fetch($uid);
        $user_field = C::t('common_member_field_forum')->fetch($uid);
        if (!$user['extgroupids']) {
            $user['extgroupids'] = $user['groupid'];
        } else {
            $user['extgroupids'] .= "\t" . $user['groupid'];
        }
        $group_arr = explode("\t", $user['extgroupids']);
        if (!in_array($groupid, $group_arr)) {
            $group_arr[] = $groupid;
            $no_old      = 1;
        }
        if ($user_field) {
            $groupterms = dunserialize($user_field['groupterms']);
        }

        if ($date) {
            if ($groupterms['ext'][$groupid] && $groupterms['ext'][$groupid] > TIMESTAMP) {
                $expiry = $groupterms['ext'][$groupid] + ($date * 86400);
            }
            if ($no_old or $groupterms['ext'][$groupid]) {
                !$expiry && $expiry          = (TIMESTAMP + ($date * 86400));
                $groupterms['ext'][$groupid] = $expiry;
            }
        } else {
            unset($groupterms['ext'][$groupid]);
        }
        if ($user['groupid'] == $groupid) {
            $groupterms['main'] = ['time' => $expiry];
        }
        if (!function_exists('groupexpiry')) {
            require_once libfile('function/forum');
        }
        $grouptermsnew  = serialize($groupterms);
        $groupexpirynew = groupexpiry($groupterms);
        $extgroupidsnew = implode("\t", $group_arr);
        C::t('common_member')->update($uid, ['extgroupids' => $extgroupidsnew, 'groupexpiry' => $groupexpirynew]);
        if ($user_field) {
            C::t('common_member_field_forum')->update($uid, ['groupterms' => $grouptermsnew]);
        } else {
            C::t('common_member_field_forum')->insert(['uid' => $uid, 'groupterms' => $grouptermsnew]);
        }
    }

    public function send_magapp_price($uid, $price, $remark)
    {
        global $_G;

        $order = TIMESTAMP . rand(1, 100000);
        C::t('#e6_box#e6_box_magapp_price')->insert([
            'uid'    => $uid,
            'price'  => $price,
            'remark' => $remark,
            'order'  => $order
        ]);

        $url = $_G['siteurl'] . 'plugin.php?id=e6_box:magapp';
        $ext = stream_context_create(['http' => ['timeout' => 3]]);
        $url && @file_get_contents($url, false, $ext);
    }

    public function send_once_more($uid, $type, $number = 1)
    {
        C::t('#e6_box#e6_box_free_user')->increase_free_number($uid, $type, $number);
    }

    public function my_winning_list($limit = 10, $page = 1)
    {
        global $_G;
        $conditions = " AND c.uid='{$_G['uid']}' ";
        $start      = ($page - 1) * $limit;

        $data = C::t('#e6_box#e6_box_winning_user')->fetch_all_by_search($conditions, $start, $limit);
        foreach ($data as $v) {

            if (defined('IN_MOBILE')) {
                $v['date'] = dgmdate($v['date'], 'm-d H:i');

            } else {
                $v['date'] = dgmdate($v['date'], 'Y-m-d H:i');
            }

            $v['content'] = $this->lang('class_37', ['box' => $this->setting_type[$v['box']], 'describe' => $v['describe']]);
            $list[]       = $v;
        }
        return $list;
    }

    public function my_winning_list_count()
    {
        global $_G;
        $count = C::t('#e6_box#e6_box_winning_user')->count_by_search(" AND c.uid='{$_G['uid']}'");
        return intval($count);
    }

    public function all_winning_list()
    {
        global $_G;

        $limit = 10;

        $conditions = " AND c.describe<>'" . $this->lang('class_38')."'";

        if ($this->config['top'] > 0) {
            $top_list = C::t('#e6_box#e6_box_winning_user')->fetch_all_top_limit($this->config['top'], 5);
            if ($top_list) {
                foreach ($top_list as $v) {
                    $list[]    = $v;
                    $top_ids[] = $v['id'];
                }
                $top_where = implode(',', $top_ids);
                $conditions .= " AND c.id NOT IN ({$top_where})";
            }
        }
        $data = C::t('#e6_box#e6_box_winning_user')->fetch_all_by_search($conditions, 0, $limit);
        foreach ($data as $v) {
            $list[] = $v;
        }

        return $list;
    }

    public function get_last_update_content()
    {
        global $_G;

        $data['today_limit'] = $this->today_limit();
        $spent_money         = $this->spent_money();

        if (defined('IN_MOBILE')) {
            $data['spent_money3'] = $spent_money[3];
            $data['spent_money2'] = $spent_money[2];
            $data['spent_money1'] = $spent_money[1];
        } else {
            $data['spent_money3'] = $spent_money[6];
            $data['spent_money2'] = $spent_money[5];
            $data['spent_money1'] = $spent_money[4];
        }

        $last_data             = C::t('#e6_box#e6_box_winning_user')->last_log();
        $last_data['username'] = DB::result_first('SELECT `username` FROM ' . DB::table('common_member') . " WHERE `uid`='{$last_data['uid']}'");
        $data['last_data']     = '<li>' . $this->lang('class_39') . "<span class=\"l-left\"> {$last_data['username']} </span> <span>" . $this->lang('class_40') . "<span class=\"l-right\">{$last_data['describe']}</span></li>";

        $my_last_data = C::t('#e6_box#e6_box_winning_user')->last_log($_G['uid']);

        if (defined('IN_MOBILE')) {
            $my_last_data['date'] = dgmdate($my_last_data['date'], 'm-d H:i');

        } else {
            $my_last_data['date'] = dgmdate($my_last_data['date'], 'Y-m-d H:i');
        }

        $my_last_data['content'] = $this->lang('class_41', ['box' => $this->setting_type[$my_last_data['box']], 'describe' => $my_last_data['describe']]);

        $data['my_last_data'] = "<tr><td class=\"td1\">{$my_last_data['content']}</td><td>{$my_last_data['date']}</td></tr>";

        return $data;
    }
}

$e6_box = e6_box::getInstance();
if (defined('IN_ADMINCP')) {
    $e6_lang = $scriptlang['e6_box'];
}
