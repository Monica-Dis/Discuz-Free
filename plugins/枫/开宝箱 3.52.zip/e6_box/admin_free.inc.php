<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require 'e6_box.class.php';

if (submitcheck('e6_submit')) {
    $e6_box->save_setting();
}

foreach (C::t('common_usergroup')->range() as $group) {
    $groups[$group['groupid']] = $group['grouptitle'];
}

showformheader('plugins&' . cpurl(false, ['action']));
showtableheader($e6_lang['a_f_1']);

showtablerow('', ['class="td27"', 'class="vtop tips2"'], [$e6_lang['a_f_2']]);
$html = '<ul class="nofloat" style="width:100%">';
foreach ($e6_box->setting_type as $k => $v) {
    $html .= <<<EOT
    <li style="float:left; width:33%;">
        {$v}: <input name="setting[free][all][{$k}]" value="{$e6_box->config['free']['all'][$k]}" style="width:30px;"> {$e6_lang['a_f_3']}
    </li>
EOT;
}
$html .= '</ul>';
showtablerow('class="noborder"', 'class="vtop rowform" colspan="2" style="width:100%"', $html);

foreach ($groups as $key => $value) {
    showtablerow('', ['class="td27"', 'class="vtop tips2"'], [$value]);
    $html = '<ul class="nofloat" style="width:100%">';
    foreach ($e6_box->setting_type as $k => $v) {
        $html .= <<<EOT
    <li style="float:left; width:33%;">
        {$v}: <input name="setting[free][{$key}][{$k}]" value="{$e6_box->config['free'][$key][$k]}" style="width:30px;"> {$e6_lang['a_f_3']}
    </li>
EOT;
    }
    $html .= '</ul>';
    showtablerow('class="noborder"', 'class="vtop rowform" colspan="2" style="width:100%"', $html);
}
showsubmit('e6_submit');
showtablefooter();/*Dism_taobao_com*/
showformfooter();
