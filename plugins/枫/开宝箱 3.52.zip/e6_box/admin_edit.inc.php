<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require 'e6_box.class.php';

if (submitcheck('e6_submit')) {
    $e6_box->save_setting();
}

!$e6_box->config['rules'] && $e6_box->config['rules'] = "<li>{$e6_lang['a_e_1']}1</li>\r\n<li>{$e6_lang['a_e_1']}2</li>";
showformheader('plugins&' . cpurl(false, ['action']));
showtableheader($e6_lang['a_e_2']);
showsetting($e6_lang['a_e_3'], 'setting[open]', $e6_box->config['open'], 'radio', 0, 0, '<a href="https://addon.dismall.com/?@e6_box.plugin.doc/help" target="_blank">' . $e6_lang['a_e_4'] . '</a>');
foreach (C::t('common_usergroup')->range() as $group) {
    $groups[] = [$group['groupid'], $group['grouptitle']];
}
showsetting($e6_lang['a_e_5'], ['setting[group]', $groups], $e6_box->config['group'], 'mcheckbox');
foreach ($e6_box->setting_type as $key => $value) {
    foreach ($_G['setting']['extcredits'] as $k => $v) {
        ${'option' . $key} .= '<option value="' . $k . '" ' . ($k == $e6_box->config['type' . $key] ? 'selected' : '') . '>' . $v['title'] . '</option>';
    }
    showtablerow('', ['class="td27"', 'class="vtop tips2"'], [$e6_lang['a_e_6'] . $value . $e6_lang['a_e_7']]);
    $html = '<input name="setting[money' . $key . ']" value="' . $e6_box->config['money' . $key] . '" type="text" style="width:50px;" /> ';
    $html .= '<select name="setting[type' . $key . ']" style="width:120px;">' . ${'option' . $key} . '</select>';
    showtablerow('class="noborder"', 'class="vtop rowform" colspan="2" style="width:100%"', $html);
}
showsetting($e6_lang['a_e_8'], 'setting[rules]', $e6_box->config['rules'], 'textarea', 0, 0, $e6_lang['a_e_9']);

for ($n=1; $n<=8; $n++) {
    $num_arr[$n] = array($n, '>='.$n.$e6_lang['prize_num']);
}
showsetting($e6_lang['a_e_16'], array('setting[top]', $num_arr), $e6_box->config['top'], 'select', 0, 0, $e6_lang['a_e_17']);
showsetting($e6_lang['a_e_10'], 'setting[magapp_open]', $e6_box->config['magapp_open'], 'radio', 0, 0, $e6_lang['a_e_11']);
showsetting($e6_lang['a_e_12'], 'setting[magapp_host]', $e6_box->config['magapp_host'], 'text', 0, 0, $e6_lang['a_e_13']);
showsetting($e6_lang['a_e_14'], 'setting[magapp_secret]', $e6_box->config['magapp_secret'], 'text');
showsetting($e6_lang['a_e_15'], 'setting[magapp_assistant_secret]', $e6_box->config['magapp_assistant_secret'], 'text');
showsubmit('e6_submit');
showtablefooter();/*Dism_taobao_com*/
showformfooter();
