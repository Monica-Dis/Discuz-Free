<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

@ignore_user_abort(true);
@set_time_limit(600);
header('Connection: close');
header('HTTP/1.1 200 OK');
ob_start();
print 'ok';
$size = ob_get_length();
header("Content-Length: $size");
ob_end_flush();
flush();

if (function_exists('fastcgi_finish_request')) {
    fastcgi_finish_request();
}

$last_time = C::t('#e6_box#e6_box_last_time')->last_time();
if (($_G['timestamp'] - 5) > $last_time) {
    @ignore_user_abort(true);
    @set_time_limit(600);
    C::t('#e6_box#e6_box_last_time')->update_last_time();
    e6_send_magapp_price();
}

@include DISCUZ_ROOT . 'data/e6_box.config.php';

function e6_send_magapp_price()
{
    global $config;
    if (empty($config)) {
        return false;
    }
    $data = C::t('#e6_box#e6_box_magapp_price')->fetch_first();
    if ($data) {

        $url = $config['magapp_host'] . '/core/pay/pay/accountTransfer?secret=' . $config['magapp_secret'] . '&user_id=' . $data['uid'] . '&amount=' . $data['price'] . '&remark=' . $data['remark'] . '&out_trade_code=' . $data['order'];

        $output = dfsockopen($url);

        $js_data = json_decode($output, true);
        if ($js_data['success'] == 1) {
            C::t('e6_box#e6_box_magapp_price')->delete($data['id']);
        }
        sleep(3);
        e6_send_magapp_price();
    } else {
        return false;
    }
}
