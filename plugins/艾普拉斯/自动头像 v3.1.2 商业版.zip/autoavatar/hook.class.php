<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_autoavatar {
	function __construct(){
		global $_G;	
		loadcache('plugin');
		$vars=$_G['cache']['plugin']['autoavatar'];
		$this->cachetime=intval($vars['cachetime']);
		if(!$this->cachetime) $this->cachetime=300;
		$this->open=intval($vars['open']);
		$this->domain=trim($vars['domain']);
		if(!$this->domain) $this->open=0;
		$this->ucdir=trim($vars['ucdir']);
	}
	
	function avatar($v){
		global $_G;	
		$filepath=DISCUZ_ROOT.'./data/sysdata/cache_autoavatar.php';
		if((time()-filemtime($filepath)>=3600)||!file_exists($filepath)){
			$this->scanfile();
		}
		//var_dump($v);
		$uid = intval($v['param'][0]);
		$size= $v['param'][1]? $v['param'][1]:'middle';
		$returnsrc=$v['param'][2];
		$real=$v['param'][3];
		$static=$v['param'][4];
		$ucenterurl=$v['param'][4];
		$ucenterurl = empty($ucenterurl) ? $_G['setting']['ucenterurl'] : $ucenterurl;
		$uid = sprintf("%09d", $uid);
		$dir1 = substr($uid, 0, 3);
		$dir2 = substr($uid, 3, 2);
		$dir3 = substr($uid, 5, 2);
		$avatarfile = $ucenterurl.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).($real ? '_real' : '').'_avatar_'.$size.'.jpg';
		if($_GET['ac']!='avatar'){
			if($uid&&file_exists($filepath)){
				@require $filepath;
				$num=count($avatar);
				$src=$avatar[$uid%$num];
				if(!file_exists($src)){//ͷ���ļ���ɾ���򱻸���
					$this->scanfile();
					@require $filepath;
					$num=count($avatar);
					$src=$avatar[$uid%$num];
				}
				if($this->open) $src=str_replace('source/plugin/autoavatar/avatar/',$this->domain,$src);
				if($returnsrc){
					if($this->ucdir){//�������ļ��ж�
						$avatarpath=DISCUZ_ROOT.'./'.$this->ucdir.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).($real ? '_real' : '').'_avatar_'.$size.'.jpg';
						if(file_exists($avatarpath)) return '';//�����ϴ�ͷ��
					}else{
						loaducenter();
						if(uc_check_avatar($uid, 'middle')){//uc������װ��uc_check_avatar�жϣ���uc_fopen��һ���ɿ�������
							return '';
						}
					}
					$_G['hookavatar']=$src;
				}else{
					$_G['hookavatar']='<img src="'.$avatarfile.'" onerror="this.onerror=null;this.src=\''.$src.'\'" noerror="true"/>';		
				}	
			}
		}
		return '';
	}
	
	function scanfile(){
		global $_G;
		$dir = DISCUZ_ROOT.'./source/plugin/autoavatar/avatar/';
		$handle=opendir($dir); 
		$avatar=array();
		while(false!==($file=readdir($handle))){ 
			if(substr_count($file,'.jpg')){
				if(substr($file,0,5)!='hash_'){
					if(file_exists(DISCUZ_ROOT.'./source/plugin/autoavatar/libs/ext.lib.php')){
						@require DISCUZ_ROOT.'./source/plugin/autoavatar/libs/ext.lib.php';
					}
				}else{
					$img='source/plugin/autoavatar/avatar/'.$file;
				}
				$avatar[]=$img;
			}
		}
		@require_once libfile('function/cache');
		$cacheArray .= "\$avatar=".arrayeval($avatar).";\n";
		writetocache('autoavatar', $cacheArray);		
	}
}

?>