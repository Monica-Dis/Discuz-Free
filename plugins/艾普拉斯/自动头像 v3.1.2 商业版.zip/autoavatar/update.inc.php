<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$langvar=lang('plugin/autoavatar');
if($_GET['op']=='update'){
	scanfile();
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/autoavatar/libs/ext.lib.php')){
		cpmsg($langvar['update_error'],'action=plugins&operation=config&identifier=autoavatar&pmod=update', 'succeed');
	}else{
		cpmsg($langvar['update_ok'],'action=plugins&operation=config&identifier=autoavatar&pmod=update', 'succeed');
	}
}else{
	showtableheader($langvar['appname']);
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		$langvar['tip_1']
	));
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		$langvar['tip_2']
	));
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		$langvar['tip_3']
	));
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/autoavatar/libs/ext.lib.php')){
		showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
			'<font color="red">'.$langvar['tip_4'].'</font>'
		));
	}	
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=autoavatar&pmod=update&op=update"><strong>'.$langvar['update'].'</strong></a>'
	));
	
	showtablefooter();
}

function scanfile(){
	global $_G;
	$dir = DISCUZ_ROOT.'./source/plugin/autoavatar/avatar/';
	$handle=opendir($dir); 
	$avatar=array();
	while(false!==($file=readdir($handle))){ 
		if(substr_count($file,'.jpg')){
			if(substr($file,0,5)!='hash_'){
				if(file_exists(DISCUZ_ROOT.'./source/plugin/autoavatar/libs/ext.lib.php')){
					@require DISCUZ_ROOT.'./source/plugin/autoavatar/libs/ext.lib.php';
				}
			}else{
				$img='source/plugin/autoavatar/avatar/'.$file;
			}
			$avatar[]=$img;
		}
	}
	@require_once libfile('function/cache');
	$cacheArray .= "\$avatar=".arrayeval($avatar).";\n";
	writetocache('autoavatar', $cacheArray);		
}
//From: Dism_taobao_com
?>