<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

?>
<iframe src="https://dism.taobao.com/?@8000.developer#from=autoavatar" width="100%" height="2000" frameborder="0" scrolling="no" style="min-width:870px;margin-left:-3px; background:#F4FAFD" ></iframe> 