<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_iplus_pages {

}

class plugin_iplus_pages_forum extends plugin_iplus_pages{
	function viewthread_modaction(){
		global $_G;
		loadcache('plugin');
		$tid=$_G['tid'];
		$page=max(1,intval($_GET['page']));
		if($tid&&$page==1){
			$isforum=intval($_G['cache']['plugin']['iplus_pages']['isforum']);
			$rank=intval($_G['cache']['plugin']['iplus_pages']['rank']);
			if($isforum==1&&$_G['fid']){
				$where='and fid='.$_G['fid'];
			}else $where='';
			$thread = DB::fetch_first("SELECT tid,subject FROM ".DB::table('forum_thread')." where displayorder>=0 and tid<$tid $where ORDER BY tid DESC  LIMIT 0,1");
			if($thread) $unto='<a href="forum.php?mod=viewthread&tid='.$thread['tid'].'" target="_blank">'.$thread['subject'].'</a>';
			else $unto=lang('plugin/iplus_pages','nocontent');
			
			$thread = DB::fetch_first("SELECT tid,subject FROM ".DB::table('forum_thread')." where displayorder>=0 and tid>$tid $where ORDER BY tid ASC  LIMIT 0,1");
			if($thread) $next='<a href="forum.php?mod=viewthread&tid='.$thread['tid'].'" target="_blank">'.$thread['subject'].'</a>';
			else $next=lang('plugin/iplus_pages','nocontent');
			if($rank==1) return lang('plugin/iplus_pages','unto').$unto.'<br>'.lang('plugin/iplus_pages','next').$next;
			else return lang('plugin/iplus_pages','unto').$next.'<br>'.lang('plugin/iplus_pages','next').$unto;
		}
		return '';
	}
}

class plugin_iplus_pages_group extends plugin_iplus_pages_forum{
}
//From: Dism_taobao_com
?>