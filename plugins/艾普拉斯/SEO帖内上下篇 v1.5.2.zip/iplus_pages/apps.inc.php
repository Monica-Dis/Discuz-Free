<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//From: Dism��taobao��com
?>
<iframe src="https://dism.taobao.com/?@8000.developer" width="100%" height="2000" frameborder="0" scrolling="no" style="min-width:870px;margin-left:-3px; background:#F4FAFD" ></iframe> 