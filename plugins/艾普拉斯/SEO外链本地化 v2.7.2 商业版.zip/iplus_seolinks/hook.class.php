<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_iplus_seolinks {
	function global_header(){
	    loadcache('plugin');
		global $_G,$postlist;
		unset($_G['setting']['output']['preg']['search']['plugin']);
		unset($_G['setting']['output']['preg']['replace']['plugin']);
		if($this->openStation(1)&&CURSCRIPT=='forum'&&CURMODULE=='viewthread'){
			foreach($postlist as $pid=>$post){
				$link='';
				$word='';
				$strResult='';
				preg_match_all('/<a.*?(?: |\\t|\\r|\\n)?href=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>(.+?)<\/a.*?>/sim', $postlist[$pid]['message'], $strResult, PREG_PATTERN_ORDER);
				for($i=0;$i<count($strResult[1]);$i++){
					$link=$strResult[1][$i];
					$word=$strResult[2][$i];
					if(substr($link,0,4)=='http'&&strlen($link)>11&&$this->_goodUrl($link)==0) $postlist[$pid]['message']=str_replace("<a href=\"".$link."\"", "<a href=\"plugin.php?id=iplus_seolinks:links&url=".$this->seoUrlEncode($link)."\"", $postlist[$pid]['message']);
				}
				$link='';
				$word='';
				$strResult='';
				preg_match_all('/<a.*?(?: |\\t|\\r|\\n)?href=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>(.+?)<\/a.*?>/sim', $postlist[$pid]['signature'], $strResult, PREG_PATTERN_ORDER);
				for($i=0;$i<count($strResult[1]);$i++){
					$link=$strResult[1][$i];
					$word=$strResult[2][$i];
					if(substr($link,0,4)=='http'&&strlen($link)>11&&$this->_goodUrl($link)==0) $postlist[$pid]['signature']=str_replace("<a href=\"".$link."\"", "<a href=\"plugin.php?id=iplus_seolinks:links&url=".$this->seoUrlEncode($link)."\"", $postlist[$pid]['signature']);
				}				
			}
		}
		if($this->openStation(2)&&CURSCRIPT=='group'&&CURMODULE=='viewthread'){//Ⱥ������
			if(file_exists(DISCUZ_ROOT.'./source/plugin/iplus_seolinks/lib/group.lib.php')){
				@include DISCUZ_ROOT . './source/plugin/iplus_seolinks/lib/group.lib.php';
			}
		}		
		if($this->openStation(3)&&CURSCRIPT=='portal'&&CURMODULE=='view'){//�Ż�����
			global $content;
			if(file_exists(DISCUZ_ROOT.'./source/plugin/iplus_seolinks/lib/portal.lib.php')){
				@include DISCUZ_ROOT . './source/plugin/iplus_seolinks/lib/portal.lib.php';
			}
		}
		if($this->openStation(4)&&CURSCRIPT=='home'&&CURMODULE=='space'&&$_GET['do']=='blog'){//��԰��־
			global $blog;
			if(file_exists(DISCUZ_ROOT.'./source/plugin/iplus_seolinks/lib/home.lib.php')){
				@include DISCUZ_ROOT . './source/plugin/iplus_seolinks/lib/home.lib.php';
			}
		}
	}
	
	function openStation($id){
		global $_G;
		$var = $_G['cache']['plugin']['iplus_seolinks'];
		$station=unserialize($var['station']);
		if(in_array($id,$station)) return 1;
		else return 0;
	}
	function _goodUrl($url){
		global $_G;
	    if(substr($url,0,9)=='forum.php') return 1;//���θ�������
		else{
	        $var = $_G['cache']['plugin']['iplus_seolinks'];
	        $goodurl=$var['goodurl'];
	        $arr=explode(",",$goodurl);
		    $t=0;
		    for($i=0;$i<count($arr);$i++){
		        if(stripos($url,$arr[$i])==false) $t=$t+0;
			    else{
					$t=$t+1;
					break;
				}
		    }
	        if($t==0) return 0;//0��ʾ���ڰ�������
		    else return 1;
		}
	}
	
	function seoUrlEncode($url){
		$url=base64_encode($url);
		return $url;
	}
}
//From: Dism��taobao��com
?>