<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$op=trim($_GET['op']);
$delid=intval($_GET['delid']);
if($op=='del'&&$delid&&$_GET['hash']==formhash()){
	DB::update('iplus_seolinks',array('status'=>-1),array('id'=>$delid));
	cpmsg(lang('plugin/iplus_seolinks','del_ok'),'action=plugins&operation=config&identifier=iplus_seolinks&pmod=data', 'succeed');
}
if($op=='undel'&&$delid&&$_GET['hash']==formhash()){
	DB::update('iplus_seolinks',array('status'=>0),array('id'=>$delid));
	cpmsg(lang('plugin/iplus_seolinks','del_ok2'),'action=plugins&operation=config&identifier=iplus_seolinks&pmod=data', 'succeed');
}
showformheader("plugins&operation=config&identifier=iplus_seolinks&pmod=data");
showtableheader(lang('plugin/iplus_seolinks','s_title'), 'nobottom');
showsetting(lang('plugin/iplus_seolinks','s_url'), 'url',$_GET['url'], 'text', '', 0,lang('plugin/iplus_seolinks','s_url_info'), 1);
showsubmit('editsubmit');
showtablefooter();/*Dism-taobao_com*/
showformfooter();
$pagenum = 20;
$page=max(1,intval($_GET['page']));
$where='';
if($_GET['url']){
	$url=trim($_GET['url']);
	$where=" and url like '%$url%'";
}
$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('iplus_seolinks')." WHERE 1 $where");
$query = DB::query("SELECT * FROM ".DB::table('iplus_seolinks')." WHERE 1 $where ORDER BY id DESC LIMIT ".(($page - 1) * $pagenum).",$pagenum");
showtableheader(lang('plugin/iplus_seolinks', 'data_log').$op_title, '');
showsubtitle(array( 'ID','URL',lang('plugin/iplus_seolinks','item_views'), lang('plugin/iplus_seolinks','item_dateline'), lang('plugin/iplus_seolinks','item_status'), lang('plugin/iplus_seolinks','item_op'), lang('plugin/iplus_seolinks','item_unop')));
while($result = DB::fetch($query)) {
	showtablerow(NULL,NULL,
	array(
	$result['id'],
	'<a href="plugin.php?id=iplus_seolinks:links&url='.seoUrlEncode($result['url']).'" title="'.$result['url'].'" target="_blank">'.cutstr($result['url'],80,'..')."</a>",
	$result['views'],
	dgmdate($result['dateline'],'u'),
	$result['status']==0? lang('plugin/iplus_seolinks','item_status_0'):lang('plugin/iplus_seolinks','item_status_1'),
	$result['status']==0? '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=iplus_seolinks&pmod=data&op=del&delid='.$result['id'].'&hash='.FORMHASH.'">'.lang('plugin/iplus_seolinks','item_op').'</a>':'/',
	$result['status']==0? '/':'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=iplus_seolinks&pmod=data&op=undel&delid='.$result['id'].'&hash='.FORMHASH.'">'.lang('plugin/iplus_seolinks','item_unop').'</a>',
	));
}
showtablerow();
showtablefooter();/*Dism-taobao_com*/
echo multi($count, $pagenum, $page, ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=iplus_seolinks&pmod=data&url='.$url);

function seoUrlEncode($url){
	$url=base64_encode($url);
	return $url;
}
//From: Dism_taobao_com
?>