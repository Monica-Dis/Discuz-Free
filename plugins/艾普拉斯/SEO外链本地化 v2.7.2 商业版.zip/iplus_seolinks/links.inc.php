<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
$style=$_G['cache']['plugin']['iplus_seolinks']['style'];
$diytitle=$_G['cache']['plugin']['iplus_seolinks']['title'];
$url=seoUrlDecode($_GET['url']);
$url=str_replace('&amp;','&',$url);
$item=DB::fetch_first("SELECT id,status FROM ".DB::table('iplus_seolinks')." WHERE url='".addslashes($url)."'");
if($item['status']==-1||_badUrl($url)){
	showmessage($_G['cache']['plugin']['iplus_seolinks']['tips']);
	exit;
}
if($item['id']){
	DB::query("UPDATE ".DB::table('iplus_seolinks')." SET views=views+1,dateline='".$_G['timestamp']."' WHERE id='$item[id]'", 'UNBUFFERED');
}else{
	$data=array(
		'url'=>addslashes($url),
		'views'=>'1',
		'dateline'=>$_G['timestamp'],
	);
	DB::insert('iplus_seolinks',$data);
}
$http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https' : 'http';
if($http_type=='https'&&strtolower(substr($url,0,5))!='https'){//https网站iframe嵌入http资源暂时方案
	dheader("location:$url");
}
if($style==2&&file_exists(DISCUZ_ROOT.'./source/plugin/iplus_seolinks/lib/url.lib.php')){
	@include DISCUZ_ROOT . './source/plugin/iplus_seolinks/lib/url.lib.php';
}else{
	dheader("location:$url");
	
}

function _badUrl($url){
	global $_G;
	loadcache('plugin');
	$var = $_G['cache']['plugin']['iplus_seolinks'];
	$badurl=$var['badurl'];
	$arr=explode(",",$badurl);
	$t=0;
	for($i=0;$i<count($arr);$i++){
		if(stripos($url,$arr[$i])==false) $t=$t+0;
		else{
			$t=$t+1;
			break;
		}
	}
	if($t==0) return 0;//0表示不在黑名单中
	else return 1;
}


function seoUrlDecode($url){
	$url=base64_decode($url);
	return $url;
}
//From: Dism_taobao_com
?>