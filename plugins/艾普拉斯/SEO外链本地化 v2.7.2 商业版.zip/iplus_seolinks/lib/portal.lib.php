<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
			preg_match_all('/<a.*?(?: |\\t|\\r|\\n)?href=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>(.+?)<\/a.*?>/sim', $content['content'], $strResult, PREG_PATTERN_ORDER);
			for($i=0;$i<count($strResult[1]);$i++){
				$link=$strResult[1][$i];
				$word=$strResult[2][$i];
				if(substr($link,0,4)=='http'&&strlen($link)>11&&$this->_goodUrl($link)==0) $content['content']=str_replace("<a href=\"".$link."\"", "<a target=\"_blank\" href=\"plugin.php?id=iplus_seolinks:links&url=".$this->seoUrlEncode($link)."\"", $content['content']);
			}
//From: Dism_taobao_com
?>