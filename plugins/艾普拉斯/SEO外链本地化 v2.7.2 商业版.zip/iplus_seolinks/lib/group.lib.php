<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
			foreach($postlist as $pid=>$post){
				$link='';
				$word='';
				$strResult='';
				preg_match_all('/<a.*?(?: |\\t|\\r|\\n)?href=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>(.+?)<\/a.*?>/sim', $postlist[$pid]['message'], $strResult, PREG_PATTERN_ORDER);
				for($i=0;$i<count($strResult[1]);$i++){
					$link=$strResult[1][$i];
					$word=$strResult[2][$i];
					if(substr($link,0,4)=='http'&&strlen($link)>11&&$this->_goodUrl($link)==0) $postlist[$pid]['message']=str_replace("<a href=\"".$link."\"", "<a href=\"plugin.php?id=iplus_seolinks:links&url=".$this->seoUrlEncode($link)."\"", $postlist[$pid]['message']);
				}
				$link='';
				$word='';
				$strResult='';
				preg_match_all('/<a.*?(?: |\\t|\\r|\\n)?href=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>(.+?)<\/a.*?>/sim', $postlist[$pid]['signature'], $strResult, PREG_PATTERN_ORDER);
				for($i=0;$i<count($strResult[1]);$i++){
					$link=$strResult[1][$i];
					$word=$strResult[2][$i];
					if(substr($link,0,4)=='http'&&strlen($link)>11&&$this->_goodUrl($link)==0) $postlist[$pid]['signature']=str_replace("<a href=\"".$link."\"", "<a href=\"plugin.php?id=iplus_seolinks:links&url=".$this->seoUrlEncode($link)."\"", $postlist[$pid]['signature']);
				}				
			}
//From: Dism_taobao_com
?>