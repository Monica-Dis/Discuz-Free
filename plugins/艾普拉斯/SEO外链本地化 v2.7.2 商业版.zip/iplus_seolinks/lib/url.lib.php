<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($diytitle) $title=$diytitle.'('.$url.') - '.$_G['setting']['bbname'];
else $title=lang('plugin/iplus_seolinks','appname').'('.$url.') - '.$_G['setting']['bbname'];
$meta['keywords']=dhtmlspecialchars($metakeywords);
$meta['description']=dhtmlspecialchars($metadescription);
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset={CHARSET}" />
    <meta http-equiv="Content-Language" content="zh-cn" />
    <title><?php echo $title;?></title>
    <meta content="<?php echo $meta['keywords'];?>" name="keywords" />
    <meta content="<?php echo $meta['description'];?>" name="description" />
	<meta name="robots" content="nofollow" />	
</head>
<body leftmargin="0" topmargin="0" style="overflow-x:hidden;overflow-y:hidden;width:100%;margin-top: 0;">
	<div style="height:0%;"></div>
    <div class="style1">
        <iframe framespacing='0' scrolling="yes" frameborder='0' marginheight="0" marginwidth="0" border="0" width="100%" height="100%" name="iplus_seolinks" src='<?php echo $url;?>'>
        </iframe>
    </div>
<div style="display:none;">
<?php
if($_G['setting']['statcode']){
	echo $_G['setting']['statcode'];
}
//From: Dism_taobao_com
?>
</div>
</body>
</html>