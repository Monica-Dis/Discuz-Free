<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$upgrade_style=0;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('iplus_seolinks'));
while($temp = DB::fetch($query)) {
	if($temp['Field']== 'status') {
		$upgrade_style=1;
		break;
	}
}
if($upgrade_style==0){
	DB::query("ALTER table ".DB::table('iplus_seolinks')." ADD `status` tinyint(1) NOT NULL DEFAULT 0;");
}
/* 删除文件 */
$identifier = 'iplus_seolinks';
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');
@unlink($entrydir.'/upgrade.php');
/* 删除文件 */
$finish = TRUE;
?>