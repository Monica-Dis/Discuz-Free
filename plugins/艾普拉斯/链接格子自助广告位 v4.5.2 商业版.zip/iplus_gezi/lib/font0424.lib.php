<?php
$fontarr['fontcolor']=$_POST['info']['Gzfontcolor'];
$fontarr['fontweight']=$_POST['info']['highlight_style'][1];
$fontarr['fontstyle']=$_POST['info']['highlight_style'][2];
$fontarr['textdecoration']=$_POST['info']['highlight_style'][3];
?>