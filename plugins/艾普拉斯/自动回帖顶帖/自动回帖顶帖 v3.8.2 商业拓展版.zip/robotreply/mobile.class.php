<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_robotreply {
	public function __construct(){
		global $_G;
		loadcache('plugin');
		if($_GET['mod']=='viewthread'&&$_G['tid']&&$_G['fid']){
			$this->lang=lang('plugin/robotreply');
			$this->_date=date('Y-m-d',time());
			$this->_week=$this->lang['week_'.date('w')];
			$this->_forum=$_G['forum']['name'];
			$this->_author=$_G['thread']['author'];
			$this->_myname='';
			$this->_myuid='';
			$this->days=intval($_G['cache']['plugin']['robotreply']['days']);
		}
	}
	
	function global_header_mobile(){
		global $_G,$postlist;
		loadcache('plugin');
		$forums =unserialize($_G['cache']['plugin']['robotreply']['forums']);
		if($_GET['mod']=='viewthread'&&$_G['tid']&&$_G['fid']&&in_array($_G['fid'],$forums)){
			if($this->days){
				if(time()-$_G['thread']['dateline']>$this->days*86400) return '';
			}
			$gl=intval($_G['cache']['plugin']['robotreply']['gl']);
			$gl=$gl<1? 1:$gl;
			$gl=$gl>1000? 1000:$gl;
			if(rand(1,1000)>=$gl){//数字越大，概率越低
				$num=C::t('#robotreply#robotreply_replylog')->count_by_tid($_G['tid']);
				if($_G['cache']['plugin']['robotreply']['replynum']&&$_G['cache']['plugin']['robotreply']['replynum']<=$num) return '';
				$user=$this->getReplyUser();
				$data=$this->getReplyContent();
				$content=$data['content'];
				$cid=$data['cid'];
				if($this->_myname&&$this->_myuid&&$content){
					$num=C::t('#robotreply#robotreply_replylog')->count_by_tid_cid($_G['tid'],$cid);
					if($num) return '';
					if(file_exists(DISCUZ_ROOT.'./source/plugin/robotreply/libs/vars.lib.php')){
						@include DISCUZ_ROOT . './source/plugin/robotreply/libs/vars.lib.php';
						$content=vars_replace($content,array('{author}'=>$this->_author,'{date}'=>$this->_date,'{forum}'=>$this->_forum,'{myname}'=>$this->_myname,'{week}'=>$this->_week));
					}
					$pid=$this->replyThis($_G['fid'],$_G['tid'],$this->_myuid,$this->_myname,$content,$cid);
					if($pid&&intval($_G['cache']['plugin']['robotreply']['credit'])&&intval($_G['cache']['plugin']['robotreply']['creditnum'])){
						updatemembercount($this->_myuid, array(intval($_G['cache']['plugin']['robotreply']['credit'])=>intval($_G['cache']['plugin']['robotreply']['creditnum'])));
					}
				}	
			}
		}
		return '';
	}
	
	function getReplyContent(){
		$replylist=array();
		if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_robotreply.php')){
			@require_once DISCUZ_ROOT.'./data/sysdata/cache_robotreply.php';
			$data=$replylist[rand(0,(count($replylist)-1))];
		}else{
			$data=C::t('#robotreply#robotreply_content')->getitem_by_rand();
		}
		if(isset($data['content'])) $data['content']=base64_decode($data['content']);
		return $data;
	}
	
	function getReplyUser(){
		loadcache('plugin');
		global $_G;
		$user=array();
		$uids=(array)explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$_G['cache']['plugin']['robotreply']['uids']));
		$uids=$uids[rand(0,intval(count($uids)-1))];
		if($uids){
			$uids=(array)explode("-",$uids);
			if(count($uids)==1){
				$user=C::t('#robotreply#common_member')->fetch_all_username_by_uid($uids);
				$user[0]=array('uid'=>$uids[0],'username'=>$user[$uids[0]]);
				unset($user[$uids[0]]);
				
			}
			if(intval($uids[0])&&intval($uids[1])){
				$user=C::t('#robotreply#common_member')->range_by_uid(rand(intval($uids[0]),intval($uids[1])),1);
			}
		}
		if(count($user)==1){
			$user=reset($user);
			$this->_myname=$user['username'];
			$this->_myuid=$user['uid'];
		}else{
			$this->_myname='';
			$this->_myuid='';
		}
	}
	
	function replyThis($fid,$tid,$uid,$username,$content,$cid){
		global $_G;
		require_once libfile('function/post');
		require_once libfile('function/forum');
		$pid = insertpost(array(
			'fid' => $fid,
			'tid' => $tid,
			'first' => '0',
			'author' => $username,
			'authorid' => $uid,
			'subject' => '',
			'dateline' => time(),
			'message' => htmlspecialchars_decode($content,ENT_QUOTES),
			'useip' => $_G['clientip'],//,
			'invisible' => 0,
			'anonymous' => 0,
			'usesig' => 0,
			'htmlon' => 0,
			'bbcodeoff' => 0,
			'smileyoff' => 0,
			'parseurloff' => 0,
			'attachment' => 0,
			'tags' => '',
			'replycredit' => 0,
			'status' => 0
		 ));
		C::t('common_member_count')->increase(array($uid),array('posts'=>1));
		$postionid=C::t('forum_post')->fetch_maxposition_by_tid($_G['thread']['posttableid'],$tid);		
		C::t('forum_thread')->update($tid,array('`maxposition`='.$postionid,'`replies`=`replies`+1','`views`=`views`+1','`heats`=`heats`+1','`lastpost`='.time(),'lastposter=\''.$username.'\''),false,false,0,true);
		C::t('forum_forum')->update_forum_counter($fid,0,1,1);
		$subject=htmlspecialchars_decode($_G['thread']['subject']);
		$lastpost = "$tid\t$subject\t".time()."\t".$username;
		C::t('forum_forum')->update(array('fid'=>$fid),array('lastpost'=>$lastpost));

		if($pid){
			$log=array(
				'cid'=>$cid,
				'pid'=>$pid,  
				'tid'=>$tid,
				'uid'=>$uid,
				'username'=>$username,
				'dateline'=>time()
			);
			C::t('#robotreply#robotreply_replylog')->insert($log);
			return $pid;
		}else{
			return 0;
		}
	}	
}
//From: Dism·taobao·com
?>