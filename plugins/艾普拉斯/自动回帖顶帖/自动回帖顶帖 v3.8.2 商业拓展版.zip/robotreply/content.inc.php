<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$langvar= lang('plugin/robotreply');
if(file_exists(DISCUZ_ROOT.'./source/plugin/robotreply/libs/cache.lib.php')){
	@include DISCUZ_ROOT . './source/plugin/robotreply/libs/cache.lib.php';
}
$op=$_GET['op'];
if($op=='clear'&&$_GET['formhash']==formhash()){
	C::t('#robotreply#robotreply_content')->clear();
	if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_robotreply.php')){
		unlink(DISCUZ_ROOT.'./data/sysdata/cache_robotreply.php');
	}
	cpmsg($langvar['ok'],'action=plugins&operation=config&identifier=robotreply&pmod=content', 'succeed');
}elseif($op=='add'){
	$style=$_GET['style'];
	if($style=='code'){
		if(submitcheck('addsubmit')){
			$data=array();
			$data['content']=base64_encode($_POST['content']);
			if(empty($data['content'])){
				cpmsg($langvar['nocontent']);
				exit;
			}
			C::t('#robotreply#robotreply_content')->insert($data);
			updateReplyCache();
			cpmsg($langvar['ok'],'action=plugins&operation=config&identifier=robotreply&pmod=content', 'succeed');
		}else{
			showformheader("plugins&operation=config&identifier=robotreply&pmod=content&op=add&style=code");
			showtableheader($langvar['addcontent'], 'nobottom');		
			showsetting($langvar['replycontent'],'content','','textarea','', 0,$langvar['replycontentinfo']);
			showsubmit('addsubmit');
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*DISM-TAOBAO-COM*/
		}	
	}
}elseif($op=='edit'){
	$adid=intval($_GET['adid']);
	if($_GET['style']=='code'){
		if(submitcheck('editsubmit')){
			$data=array();
			$data['content']=base64_encode($_POST['content']);
			if(empty($data['content'])){
				cpmsg($langvar['nocontent']);
				exit;
			}
			C::t('#robotreply#robotreply_content')->update($adid,$data);
			updateReplyCache();
			cpmsg($langvar['ok'],'action=plugins&operation=config&identifier=robotreply&pmod=content', 'succeed');
		}else{
			$ad=C::t('#robotreply#robotreply_content')->getitem_by_cid($adid);
			showformheader("plugins&operation=config&identifier=robotreply&pmod=content&op=edit&style=".$_GET['style']."&adid=".$adid);
			showtableheader($langvar['editcontent'], 'nobottom');	
			showsetting($langvar['replycontent'],'content',base64_decode($ad['content']),'textarea','', 0,$langvar['replycontentinfo']);
			showsubmit('editsubmit');
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*DISM-TAOBAO-COM*/
		}
	}
}else{//�б�
	if(submitcheck('submit')){
		foreach($_POST['delete'] as $k=>$v){
			if($k) C::t('#robotreply#robotreply_content')->delete(intval($k));
		}
		updateReplyCache();
		cpmsg($langvar['ok'],'action=plugins&operation=config&identifier=robotreply&pmod=content', 'succeed');
	}else{
		$pagenum=20;
		$page=max(1,intval($_GET['page']));
		$count=C::t('#robotreply#robotreply_content')->count();	
		showformheader('plugins&operation=config&identifier=robotreply&pmod=content');
		showtableheader($langvar['replyadmin'].'[<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=robotreply&pmod=content&op=clear&formhash='.FORMHASH.'&style=code"><font color="blue">'.$langvar['clearcontent'].'</font></a>]&nbsp;&nbsp;[<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=robotreply&pmod=content&op=add&style=code"><font color="red">'.$langvar['addcontent'].'</font></a>]', 'nobottom');
		showsubtitle(array('',$langvar['replycontent'],$langvar['op']));
		//$items = C::t('#robotreply#robotreply_content')->fetch_all_item();
		$items = C::t('#robotreply#robotreply_content')->fetch_all_by_range(($page-1)*$pagenum,$pagenum);
		foreach($items as $adid=>$item){
			showtablerow('',array(), array(
						"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[".$item['cid']."]\" value=\"".$item['cid']."\">",
						base64_decode($item['content']),
						'<a href="###" onclick="location.href=\''.ADMINSCRIPT.'?action=plugins&operation=config&identifier=robotreply&pmod=content&op=edit&style=code&adid='.$item['cid'].'\'">'.$langvar['edit'].'</a>',
					));
		}	
		showsubmit('submit',$langvar['submit'],$langvar['del'], '','');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*DISM-TAOBAO-COM*/
		echo multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=robotreply&pmod=content");
	}
}

function loadAdCache(){
	$replylist=array();
	if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_robotreply.php')) @require_once DISCUZ_ROOT.'./data/sysdata/cache_robotreply.php';
	return $replylist;
}

if(!function_exists('updateReplyCache')){
	function updateReplyCache(){
	}
}
//From: Dism_taobao_com
?>