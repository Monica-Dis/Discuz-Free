<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$langvar= lang('plugin/robotreply');
$pagenum=20;
$page=max(1,intval($_GET['page']));
$count=C::t('#robotreply#robotreply_replylog')->count();
showtableheader($langvar['replylist'], 'nobottom');
showsubtitle(array($langvar['replyuser'],$langvar['replycontent'],$langvar['replytime'],$langvar['toreply']));
$items = C::t('#robotreply#robotreply_replylog')->fetch_all_by_range(($page-1)*$pagenum,$pagenum);
foreach($items as $adid=>$item){
	showtablerow('',array(), array(
				'<a href="home.php?mod=space&uid='.$item['uid'].'" target="_blank">'.$item['username'].'</a>',
				getContent($item['cid']),
				date('Y-m-d H:i:s',$item['dateline']),
				'<a href="forum.php?mod=redirect&goto=findpost&ptid='.$item['tid'].'&pid='.$item['pid'].'" target="_blank">'.$langvar['toreply'].'</a>',
			));
}
showtablefooter(); /*dism·taobao·com*/
echo multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=robotreply&pmod=replydata");

function getContent($cid){
	global $langvar;
	$item=C::t('#robotreply#robotreply_content')->getitem_by_cid($cid);
	if(isset($item['content'])) return base64_decode($item['content']);
	else return '<font color="red">'.$langvar['errorcontent'].'</font>';

}
//From: Dism_taobao_com
?>