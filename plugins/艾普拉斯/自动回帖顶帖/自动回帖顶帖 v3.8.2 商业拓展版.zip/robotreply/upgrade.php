<?php

//升级，修复大型网站字段长度错误

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
ALTER TABLE `pre_robotreply_content`
MODIFY COLUMN `cid`  int(11) NOT NULL AUTO_INCREMENT FIRST ,
MODIFY COLUMN `content`  text NOT NULL;
ALTER TABLE `pre_robotreply_replylog`
MODIFY COLUMN `logid`  int(11) UNSIGNED NOT NULL AUTO_INCREMENT FIRST ,
MODIFY COLUMN `cid`  int(11) UNSIGNED NOT NULL,
MODIFY COLUMN `pid`  int(11) UNSIGNED NOT NULL DEFAULT 0,
MODIFY COLUMN `tid`  int(11) UNSIGNED NOT NULL DEFAULT 0,
MODIFY COLUMN `uid`  int(11) UNSIGNED NOT NULL,
MODIFY COLUMN `username`  varchar(45) NOT NULL,
MODIFY COLUMN `dateline`  int(11) UNSIGNED NOT NULL DEFAULT 0;
EOF;
runquery($sql);
/* 删除文件 */
$identifier = 'robotreply';
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');
@unlink($entrydir.'/upgrade.php');
/* 删除文件 */
$finish = true;