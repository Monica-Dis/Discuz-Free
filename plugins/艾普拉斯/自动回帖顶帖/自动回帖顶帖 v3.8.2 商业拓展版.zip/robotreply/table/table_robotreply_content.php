<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_robotreply_content  extends discuz_table {
	public function __construct() {

		$this->_table = 'robotreply_content';
		$this->_pk    = 'cid';

		parent::__construct(); /*dism · taoabo · com*/
	}

	public function fetch_all_item() {
		return DB::fetch_all("SELECT * FROM %t WHERE 1 order by cid desc", array($this->_table));
	}

	public function getitem_by_cid($cid) {
		return DB::fetch_first("SELECT * FROM %t WHERE cid=%d", array($this->_table, $cid));
	}
	
	public function getitem_by_rand() {
		return DB::fetch_first("SELECT * FROM %t order by rand()", array($this->_table));
	}
	
	public function fetch_all_by_range($start,$end) {
		return DB::fetch_all('SELECT * FROM %t ORDER BY cid DESC LIMIT %d,%d', array($this->_table,$start,$end), $this->_pk);
	}
	
	public function clear() {
		return DB::query('delete FROM %t', array($this->_table));
	}
	
	public function count() {
		return DB::result_first('SELECT COUNT(*) FROM %t', array($this->_table));
	}
}
//From: Dism·taobao·com
?>