<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_robotreply_replylog extends discuz_table{
	public function __construct() {

		$this->_table = 'robotreply_replylog';
		$this->_pk    = 'logid';
		$this->_pre_cache_key = 'robotreply_replylog_';

		parent::__construct(); /*dism · taoabo · com*/
	}
	
	public function count_by_tid_cid($tid,$cid) {
		return DB::result_first('SELECT COUNT(*) FROM %t where tid=%d and cid=%d', array($this->_table,$tid,$cid));
	}
	
	public function count_by_tid($tid) {
		return DB::result_first('SELECT COUNT(*) FROM %t where tid=%d', array($this->_table,$tid));
	}
	
	public function fetch_all_by_range($start,$end) {
		return DB::fetch_all('SELECT * FROM %t ORDER BY logid DESC LIMIT %d,%d', array($this->_table,$start,$end), $this->_pk);
	}
}
//From: Dism·taobao·com
?>