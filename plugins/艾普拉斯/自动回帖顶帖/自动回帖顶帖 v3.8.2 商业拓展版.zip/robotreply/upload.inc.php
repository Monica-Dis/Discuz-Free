<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(file_exists(DISCUZ_ROOT.'./source/plugin/robotreply/libs/upload.lib.php')){
	@include DISCUZ_ROOT . './source/plugin/robotreply/libs/upload.lib.php';
}else{
	cpmsg(lang('plugin/robotreply','noupload'),'action=plugins&operation=config&do='.$pluginid.'&identifier=robotreply&pmod=status', 'error');
}
//From: Dism_taobao_com
?>