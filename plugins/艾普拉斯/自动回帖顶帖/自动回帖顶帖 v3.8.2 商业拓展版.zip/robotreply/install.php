<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_robotreply_content` (
  `cid` int(11) NOT NULL auto_increment,
  `content` text NOT NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_robotreply_replylog` (
  `logid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) unsigned NOT NULL,
  `pid` int(11) unsigned NOT NULL default '0',   
  `tid` int(11) unsigned NOT NULL default '0',   
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(45) NOT NULL, 
  `dateline` int(11) unsigned NOT NULL default '0',  
  PRIMARY KEY (`logid`)
);
EOF;

runquery($sql);
/* 删除文件 */
$identifier = 'robotreply';
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');
@unlink($entrydir.'/upgrade.php');
/* 删除文件 */
$finish = TRUE;

?>