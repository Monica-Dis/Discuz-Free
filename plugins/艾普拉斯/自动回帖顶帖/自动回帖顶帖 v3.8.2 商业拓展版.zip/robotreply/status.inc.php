<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$libs=array(
	0=>'cache',
	1=>'vars',
	2=>'upload',
	3=>'post',
);

showtableheader(lang('plugin/robotreply','tips'));
showsubtitle(array(lang('plugin/robotreply','name'),lang('plugin/robotreply','info'),lang('plugin/robotreply','status'),lang('plugin/robotreply','down')));
foreach($libs as $k=>$lib) {
	if(file_exists(DISCUZ_ROOT.'./source/plugin/robotreply/libs/'.$lib.'.lib.php')) $status='<font color="green">'.lang('plugin/robotreply','status_1').'</font>';
	else $status='<font color="red">'.lang('plugin/robotreply','status_2').'</font>';
	showtablerow('', array('class="td_k"', 'class="td_k"', 'class="td_l"'), array(
		lang('plugin/robotreply',$lib),
		lang('plugin/robotreply',$lib.'info'),	
		$status,
		'<a href="https://dism.taobao.com/?@robotreply.plugin">'.lang('plugin/robotreply','down').'</a>',
	));
}
showtablefooter(); /*dism·taobao·com*/
?>