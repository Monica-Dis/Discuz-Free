<?php
/*
 * 主页：https://addon.dismall.com/?@8000.developer
 * 艾普拉斯：Discuz!应用中心认证开发者！
 * 插件定制 联系QQ2589897411
 * 承接各类插件定制开发业务！
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$version=$_G['setting']['plugins']['version']['robotreply'];
if(substr($version,-1)==2&&file_exists(DISCUZ_ROOT.'./source/plugin/robotreply/libs/vars.lib.php')){
	include DISCUZ_ROOT.'./source/plugin/robotreply/libs/vars.lib.php';
}
if(submitcheck('postsubmit')){
	$tid=intval($_GET['tid']);
	$num=intval($_GET['num']);
	if($tid&&$num){
		$thread=C::t('forum_thread')->fetch($tid);	
		if($thread){
			$forum=DB::result_first("select name from ".DB::table('forum_forum')." where fid='".$thread['fid']."'");
			$try=0;
			$succeed=0;
			for($i=1;$i<=$num;$i++){
				$user=getReplyUser();
				$data=getReplyContent();				
				if($user&&$data){
					if(substr($version,-1)==2&&file_exists(DISCUZ_ROOT.'./source/plugin/robotreply/libs/vars.lib.php')){
						$data['content']=vars_replace($data['content'],array(
							'{author}'=>$thread['author'],
							'{date}'=>date('Y-m-d',time()),
							'{forum}'=>$forum,
							'{myname}'=>$user['username'],
							'{week}'=>lang('plugin/robotreply','week_'.date('w'))
						));
					}				
					$pid=replyThis($thread['fid'],$tid,$user['uid'],$user['username'],$data['content'],$data['cid']);
					if(!$pid){
						$try++;
						$i--;
					}else{
						$succeed++;
					}
				}else{
					$try++;
					$i--;
				}
				if((!$succeed&&$try>=20)||$try>=100){
					cpmsg(lang('plugin/robotreply','post_empty_try'));
					break;
				}
			}
			if($succeed){
				$postionid=C::t('forum_post')->fetch_maxposition_by_tid($thread['posttableid'], $thread['tid']);
				DB::update('forum_thread',array('maxposition'=>$postionid),array('tid'=>$tid));
			}
			cpmsg(lang('plugin/robotreply','post_ok'),'action=plugins&operation=config&identifier=robotreply&pmod=post', 'succeed');
		}else{
			cpmsg(lang('plugin/robotreply','post_empty_thread'));
		}
	}else{
		cpmsg(lang('plugin/robotreply','post_empty'));
	}
}else{
	showformheader("plugins&operation=config&identifier=robotreply&pmod=post");
	showtableheader(lang('plugin/robotreply','post_title'), 'nobottom');		
	showsetting(lang('plugin/robotreply','post_tid'),'tid','','text','', 0,lang('plugin/robotreply','post_tid_info'));
	showsetting(lang('plugin/robotreply','post_num'),'num','','text','', 0,lang('plugin/robotreply','post_num_info'));
	showsubmit('postsubmit');
	showtablefooter();
	showformfooter();
}


function getReplyContent(){
	global $replylist;
	if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_robotreply.php')){
		@require_once DISCUZ_ROOT.'./data/sysdata/cache_robotreply.php';
		$data=$replylist[rand(0,(count($replylist)-1))];
	}else{
		$data=C::t('#robotreply#robotreply_content')->getitem_by_rand();
	}
	if(isset($data['content'])){
		$data['content']=base64_decode($data['content']);
	}	
	return $data;
}

function getReplyUser(){
	loadcache('plugin');
	global $_G;
	$user=array();
	$uids=(array)explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$_G['cache']['plugin']['robotreply']['uids']));
	$uids=$uids[rand(0,intval(count($uids)-1))];
	if($uids){
		$uids=(array)explode("-",$uids);
		if(count($uids)==1){
			$user=C::t('#robotreply#common_member')->fetch_all_username_by_uid($uids);
			$user[0]=array('uid'=>$uids[0],'username'=>$user[$uids[0]]);
			unset($user[$uids[0]]);
		}
		if(intval($uids[0])&&intval($uids[1])){
			$user=C::t('#robotreply#common_member')->range_by_uid(rand(intval($uids[0]),intval($uids[1])),1);
		}
	}
	if(count($user)==1){
		$user=reset($user);
	}
	return $user;
}

function replyThis($fid,$tid,$uid,$username,$content,$cid){
	global $_G;
	require_once libfile('function/post');
	require_once libfile('function/forum');
	$pid = insertpost(array(
		'fid' => $fid,
		'tid' => $tid,
		'first' => '0',
		'author' => $username,
		'authorid' => $uid,
		'subject' => '',
		'dateline' => time(),
		'message' => htmlspecialchars_decode($content,ENT_QUOTES),
		'useip' => $_G['clientip'],//,
		'invisible' => 0,
		'anonymous' => 0,
		'usesig' => 0,
		'htmlon' => 0,
		'bbcodeoff' => 0,
		'smileyoff' => 0,
		'parseurloff' => 0,
		'attachment' => 0,
		'tags' => '',
		'replycredit' => 0,
		'status' => 0
	 ));
	C::t('common_member_count')->increase(array($uid),array('posts'=>1));
	C::t('forum_thread')->update($tid,array('`replies`=`replies`+1','`views`=`views`+1','`lastpost`='.time(),'lastposter=\''.$username.'\''),false,false,0,true);
	C::t('forum_forum')->update_forum_counter($fid,0,1,1);
	$subject=htmlspecialchars_decode($_G['thread']['subject']);
	$lastpost = "$tid\t$subject\t".time()."\t".$username;
	C::t('forum_forum')->update(array('fid'=>$fid),array('lastpost'=>$lastpost));

	if($pid){
		$log=array(
			'cid'=>$cid,
			'pid'=>$pid,  
			'tid'=>$tid,
			'uid'=>$uid,
			'username'=>$username,
			'dateline'=>time()
		);
		C::t('#robotreply#robotreply_replylog')->insert($log);
		return $pid;
	}else{
		return 0;
	}
}
?>