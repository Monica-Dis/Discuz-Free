<?php
/*
 * 主页：http://addon.dismall.com/?@8000.developer
 * 艾普拉斯：Discuz!应用中心认证开发者！
 * 插件定制 联系QQ2589897411
 * 承接各类插件定制开发业务！
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$langvar= lang('plugin/robotreply');
if(file_exists(DISCUZ_ROOT.'./source/plugin/robotreply/libs/cache.lib.php')){
	@include DISCUZ_ROOT . './source/plugin/robotreply/libs/cache.lib.php';
}
if(submitcheck('uploadsubmit')){
	if(strtolower(substr($_FILES['csvfile']['name'],-3))!='csv'){
		cpmsg($langvar['nocsv']);
		exit;
	}
	$file = fopen($_FILES['csvfile']['tmp_name'],"r");
	setlocale(LC_ALL,array('chs','zh_CN','Chinese'));
	while($content=fgetcsv($file)){
		if($content[0]){
			$data=array();
			if(strtolower(CHARSET) == 'utf-8') $content[0]=iconv ("gb2312","UTF-8",$content[0]);
			$data['content']=base64_encode($content[0]);
			C::t('#robotreply#robotreply_content')->insert($data);			
		}
	}
	updateReplyCache();
	cpmsg($langvar['ok'],'action=plugins&operation=config&identifier=robotreply&pmod=content', 'succeed');	
}else{
	showformheader("plugins&operation=config&identifier=robotreply&pmod=upload",'enctype="multipart/form-data"');
	showtableheader($langvar['uploadcontent'], 'nobottom');		
	showsetting($langvar['uploadfile'],'csvfile','','file','', 0,$langvar['uploadfileinfo']);
	showsubmit('uploadsubmit');
	showtablefooter();
	showformfooter();
}

if(!function_exists('updateReplyCache')){
	function updateReplyCache(){
	}
}
?>