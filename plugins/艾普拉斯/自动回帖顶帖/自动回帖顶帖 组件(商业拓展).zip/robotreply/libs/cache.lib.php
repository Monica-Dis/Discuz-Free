<?php
/*
 * 主页：https://addon.dismall.com/?@8000.developer
 * 艾普拉斯：Discuz!应用中心认证开发者！
 * 插件定制 联系QQ2589897411
 * 承接各类插件定制开发业务！
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function updateReplyCache(){
	$data= C::t('#robotreply#robotreply_content')->fetch_all_item();
	@require_once libfile('function/cache');
	$cacheArray .= "\$replylist=".arrayeval($data).";\n";
	writetocache('robotreply', $cacheArray);	
}
$cacheon=1;
?>