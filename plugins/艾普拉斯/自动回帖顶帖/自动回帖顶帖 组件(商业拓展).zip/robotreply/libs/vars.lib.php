<?php
/*
 * 主页：https://addon.dismall.com/?@8000.developer
 * 艾普拉斯：Discuz!应用中心认证开发者！
 * 插件定制 联系QQ2589897411
 * 承接各类插件定制开发业务！
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
 
function vars_replace($content,$words){
	if(count($words)){
		$find=array();
		$replace=array();
		foreach($words as $k=>$v){
			$find[]=$k;
			$replace[]=$v;
		}
		$content=str_replace($find,$replace,$content);
	}
	//return '123';
	return $content;
}
?>