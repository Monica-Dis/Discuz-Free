<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_iplus_changeauthor {

}

class plugin_iplus_changeauthor_forum extends plugin_iplus_changeauthor {
	function viewthread_useraction(){
		global $_G;
		if(!$_G['uid']) return '';
		loadcache('plugin');
		$vars = $_G['cache']['plugin']['iplus_changeauthor'];
		$forums=unserialize($vars['forums']);
		$groups=unserialize($vars['groups']);
		if(!in_array($_G['fid'],$forums)) return '';
		if(!in_array($_G['groupid'],$groups)) return '';
		
		return '<a id="iplus_changeauthor" href="plugin.php?id=iplus_changeauthor:do&ac=reply&tid='.$_G['tid'].'" onclick="showWindow(this.id,this.href)"><i><img src="static/image/common/online_moderator.gif" alt="'.lang('plugin/iplus_changeauthor','appname').'">'.lang('plugin/iplus_changeauthor','appname').'</i></a>';
	}
}
//From: Dism_taobao_com
?>