<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_iplus_changeauthor_log` (
  `id` int unsigned NOT NULL auto_increment,
  `uid1` int(11) unsigned NOT NULL,
  `username1` varchar(50) NOT NULL default '',
  `uid2` int(11) unsigned NOT NULL,
  `username2` varchar(50) NOT NULL default '',  
  `tid` int(11) unsigned NOT NULL,
  `subject` varchar(255) NOT NULL default '',  
  `dateline` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY  (`id`)
)ENGINE=MyISAM;
EOF;

runquery($sql);
/* 删除文件 */
$identifier = 'iplus_changeauthor';
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');
@unlink($entrydir.'/upgrade.php');
/* 删除文件 */
$finish = TRUE;

?>