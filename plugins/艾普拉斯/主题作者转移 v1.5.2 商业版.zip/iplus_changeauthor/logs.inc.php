<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if($_GET['doing']=='delete'&&$_GET['formhash']==formhash()){
	$id=intval($_GET['oid']);
	DB::delete('iplus_changeauthor_log',array('id'=>$id));
	cpmsg(lang('plugin/iplus_changeauthor','delok'),'action=plugins&operation=config&identifier=iplus_changeauthor&pmod=logs', 'succeed');
	exit;
}
$pagenum=20;
$page=max(1,intval($_GET['page']));
$count=DB::result_first("select count(*) from ".DB::table("iplus_changeauthor_log")." where 1 order by id desc");
$data=DB::fetch_all("select * from ".DB::table("iplus_changeauthor_log")." where 1 order by id desc limit ".($page-1)*$pagenum.",$pagenum");
showtableheader(lang('plugin/iplus_changeauthor','m_title'));
showsubtitle(array('ID',lang('plugin/iplus_changeauthor','m_subject'),lang('plugin/iplus_changeauthor','m_u1'),lang('plugin/iplus_changeauthor','m_u2'),lang('plugin/iplus_changeauthor','m_dateline'),lang('plugin/iplus_changeauthor','m_del')));
foreach($data as $item) {
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		$item['id'],
		'<a href="forum.php?mod=viewthread&tid='.$item['tid'].'" target="_blank">'.$item['subject'].'</a>',
		'<a href="home.php?mod=space&uid='.$item['uid1'].'" target="_blank">'.$item['username1'].'</a>',
		'<a href="home.php?mod=space&uid='.$item['uid2'].'" target="_blank">'.$item['username2'].'</a>',
		date('Y-m-d H:i:s',$item['dateline']),
		'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=iplus_changeauthor&pmod=logs&doing=delete&oid='.$item['id'].'&formhash='.FORMHASH.'">'.lang('plugin/iplus_changeauthor','m_del').'</a>'
	));
			
}
showtablefooter();/*Dism-taobao_com*/
echo multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=iplus_changeauthor&pmod=logs");



?>