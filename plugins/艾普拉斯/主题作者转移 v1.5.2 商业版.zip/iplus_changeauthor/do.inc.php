<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$_G['uid']){//δ��½����
	showmessage(lang('plugin/iplus_changeauthor','nouid'), '', array(), array('login' => true));
}
loadcache('plugin');
$vars = $_G['cache']['plugin']['iplus_changeauthor'];
$forums=unserialize($vars['forums']);
$groups=unserialize($vars['groups']);
if(!in_array($_G['groupid'],$groups)) showmessage(lang('plugin/iplus_changeauthor','nogroup'));
$tid=intval($_GET['tid']);
$thread=DB::fetch_first("select tid,subject,authorid,author,posttableid,dateline from ".DB::table('forum_thread')." where tid='$tid' order by tid");
if(!$thread){
	showmessage(lang('plugin/iplus_changeauthor','nothread'));
}
if(submitcheck('submit')){
	$new_uid=intval(trim($_POST['new_uid']));
	$new_username=DB::result_first("select username from ".DB::table('common_member')." where uid='$new_uid'");
	if(!$new_uid||!$new_username){
		showmessage(lang('plugin/iplus_changeauthor','uidempty'));
	}else{
		$log=array(
			'uid1'=>$thread['authorid'],
			'username1'=>$thread['author'],
			'uid2'=>$new_uid,
			'username2'=>$new_username,			
			'tid'=>$tid,
			'subject'=>$thread['subject'],
			'dateline'=>$_G['timestamp'],
			'status'=>3,
		);
		$oid=DB::insert('iplus_changeauthor_log',$log,true);
		//��ʼ�Զ�ת��
		DB::update('forum_thread',array('author'=>$new_username,'authorid'=>$new_uid),array('tid'=>$tid));
		DB::update('forum_thread',array('lastposter'=>$new_username),array('tid'=>$tid,'lastposter'=>$thread['author']));
		$posttableid=intval($thread['posttableid']);
		$num=DB::update('forum_post'.($posttableid? '_'.$posttableid:''),array('author'=>$new_username,'authorid'=>$new_uid),array('tid'=>$tid,'authorid'=>$thread['authorid']));//���¥����¥���Ļظ�
		updateAttachment($thread['authorid'],$new_uid,$tid);
		updateCount($thread['authorid'],$new_uid,$num);
		C::t('forum_thread')->clear_cache($tid);
		showmessage(lang('plugin/iplus_changeauthor','changeok'),'forum.php?mod=viewthread&tid='.$tid, array (), array (
			'locationtime' => true,
			'refreshtime' => 3,
			'showdialog' => 1,
			'showmsg' => true
		));
	}
}else{
	include template('iplus_changeauthor:push');
}

function updateAttachment($ouid,$tuid,$tid){
	DB::update('forum_attachment',array('uid'=>$tuid),array('tid'=>$tid,'uid'=>$ouid));
	DB::update('forum_attachment_'.($tid%10),array('uid'=>$tuid),array('tid'=>$tid,'uid'=>$ouid));
}
function updateCount($ouid,$tuid,$num){
	DB::query("update ".DB::table('common_member_count')." set posts=posts-$num,threads=threads-1 where uid='$ouid'");
	DB::query("update ".DB::table('common_member_count')." set posts=posts+$num,threads=threads+1 where uid='$tuid'");
}
//From: Dism_taobao_com
?>