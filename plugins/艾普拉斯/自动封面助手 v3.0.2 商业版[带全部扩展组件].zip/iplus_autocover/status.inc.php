<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$libs=array(
	0=>'remote',
	1=>'img'
);
$ids=array(
	0=>'21723',
	1=>'21724',
);

showtableheader(lang('plugin/iplus_autocover','tips'));
showsubtitle(array(lang('plugin/iplus_autocover','name'),lang('plugin/iplus_autocover','info'),lang('plugin/iplus_autocover','status'),lang('plugin/iplus_autocover','down')));
foreach($libs as $k=>$lib) {
	if(file_exists(DISCUZ_ROOT.'./source/plugin/iplus_autocover/lib/'.$lib.'.lib.php')) $status='<font color="green">'.lang('plugin/iplus_autocover','status_1').'</font>';
	else $status='<font color="red">'.lang('plugin/iplus_autocover','status_2').'</font>';
	showtablerow('', array('class="td_k"', 'class="td_k"', 'class="td_l"'), array(
		lang('plugin/iplus_autocover',$lib),
		lang('plugin/iplus_autocover',$lib.'info'),	
		$status,
		'<a href="http://addon.dismall.com/?@iplus_autocover.plugin.'.$ids[$k].'">'.lang('plugin/iplus_autocover','down').'</a>',
	));
			
}
showtablefooter(); /*DISM _ TAOBAO _ COM*/
?>