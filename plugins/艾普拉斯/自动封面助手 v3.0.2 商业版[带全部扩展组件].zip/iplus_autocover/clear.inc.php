<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(submitcheck('searchsubmit')){//搜索结果
	$tid=intval(trim($_GET['tid']));
	if($tid){
		$filepath=DISCUZ_ROOT.'./data/sysdata/cache_cover_'.$tid.'.php';
		file_exists($filepath)&&@unlink($filepath.$file);
	}else{
		$filepath=DISCUZ_ROOT.'./data/sysdata/';
		$handle=opendir($filepath); 
		while(false!==($file=readdir($handle))){ 
			if(substr_count($file,'cache_cover_')){
				@unlink($filepath.$file);
			}
		}
	}
	cpmsg(lang('plugin/iplus_autocover','update_ok'),'action=plugins&operation=config&do='.$pluginid.'&identifier=iplus_autocover&pmod=clear', 'succeed');
}else{//搜索界面
	showformheader("plugins&operation=config&do=$pluginid&identifier=iplus_autocover&pmod=clear");
	showtableheader(lang('plugin/iplus_autocover','s_title'), 'nobottom');	
	showsetting(lang('plugin/iplus_autocover','s_title_tid'),'tid','','text','', 0,lang('plugin/iplus_autocover','s_title_tid_info'));			
	showsubmit('searchsubmit');
	showtablefooter(); /*DISM _ TAOBAO _ COM*/
	showformfooter();	
}
//From: Dism_taobao-com
?>