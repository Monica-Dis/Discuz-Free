<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function comiis_app_comiis_weixinupload_data($plugin_id)
{
	global $_G;
			$comiis_upload = 1;
		if (!isset($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
}