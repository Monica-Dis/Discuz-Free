<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {exit('Access Denied');}
$finish = TRUE;
class plugin_comiis_jrrd {
	function global_footer(){
		global $_G;
		$forum = $sortadd = $filteradd = $tids = '';
		$comiis_jrrd_txtlist = $comiis_jrrd_list =  array();
		$comiis_jrrd = $_G['cache']['plugin']['comiis_jrrd'];

		if(($comiis_jrrd['comiis_jrrd_list'] && $_G['basescript'] == 'forum' && CURMODULE == 'forumdisplay') || ($comiis_jrrd['comiis_jrrd_view'] && $_G['basescript'] == 'forum' && CURMODULE == 'viewthread')){
			$forum = $comiis_jrrd['comiis_jrrd_forum'];
			$forum = empty($forum) ? array() : unserialize($forum);
			if(!is_array($forum)) $forum = array();
			if(!(empty($forum[0]) || in_array($_G['fid'],$forum))){
				return;
			}
			$comiis_jrrd_cache = 'comiis_jrrd_data'. intval($_G['fid']);
			foreach($comiis_jrrd as $k => $v) {
				if($k != 'md5' || $k != 'time'){
					$md5 .= $k.'='.$v;
				}
			}
			$md5 = md5($md5);
			loadcache($comiis_jrrd_cache);
			if(is_array($_G['cache'][$comiis_jrrd_cache])){
				if($_G['cache'][$comiis_jrrd_cache]['md5'] != $md5 || $_G['cache'][$comiis_jrrd_cache]['time'] < time() - intval($comiis_jrrd['comiis_jrrd_cache'])){
					$comiis_jrrd_txtlist['data'] = $this->_comiis_jrrd_read();
					$comiis_jrrd_txtlist['time'] = time();
					$comiis_jrrd_txtlist['md5'] =  $md5;
					save_syscache($comiis_jrrd_cache, $comiis_jrrd_txtlist);
				}else{
					$comiis_jrrd_txtlist = $_G['cache'][$comiis_jrrd_cache];
				}
			}else{
				$comiis_jrrd_txtlist['data'] = $this->_comiis_jrrd_read();
				$comiis_jrrd_txtlist['time'] = time();
				$comiis_jrrd_txtlist['md5'] =  $md5;
				save_syscache($comiis_jrrd_cache, $comiis_jrrd_txtlist);
			}
			$comiis_jrrd_list = $comiis_jrrd_txtlist['data'];
			$comiis_jrrd = dhtmlspecialchars($comiis_jrrd);
			include_once template('comiis_jrrd:comiis_html');
			return '<script type="text/javascript" src="./source/plugin/comiis_jrrd/image/comiis.js"></script>
<script>
var intervalId = setInterval(function() {
	if($("pt")){
		clearInterval(intervalId);
		var ndiv=document.createElement("div");
		ndiv.className = "comiis_jrrd y";
		ndiv.innerHTML=\''. addcslashes($return, "\r\n\t\'") .'\';
		$("pt").appendChild(ndiv);
		var comiis_jrrd = new ScrollPic();
		comiis_jrrd.scrollContId = "comiis_jrrd_over";
		comiis_jrrd.frameWidth = "'.$comiis_jrrd['comiis_jrrd_width'].'";
		comiis_jrrd.pageWidth = "'.$comiis_jrrd['comiis_jrrd_width'].'";
		comiis_jrrd.speed = 30;
		comiis_jrrd.space = 1;
		comiis_jrrd.autoPlay = true;
		comiis_jrrd.autoPlayTime = 5;
		comiis_jrrd.initialize();
	}
}, 100);  
</script>';
		}
	}
	function _comiis_getstyle($highlight) {
		$rt = array();
		$style = '';
		if($highlight) {
			$color = array('', '#EE1B2E', '#EE5023', '#996600', '#3C9D40', '#2897C5', '#2B65B7', '#8F2A90', '#EC1282');
			$string = sprintf('%02d', $highlight);
			$stylestr = sprintf('%03b', $string[0]);
			$stylestr[0] ? ($style .= 'font-weight: 900;') : '';
			$stylestr[1] ? ($style .= 'font-style: italic;') : '';
			$stylestr[2] ? ($style .= 'text-decoration: underline;') : '';
			$string[1] ? ($style .= 'color: '.$color[$string[1]].';') : '';
		}
		return $style;
	}
	function _comiis_jrrd_read() {
		global $_G;
		$forum = $sortadd = $filteradd = $tids = '';
		$comiis_jrrd_txtlist = array();
		$comiis_jrrd = $_G['cache']['plugin']['comiis_jrrd'];
		$forum = $comiis_jrrd['comiis_jrrd_forum'];
		$sortadd = !in_array($comiis_jrrd['comiis_jrrd_cd'], array('dateline', 'lastpost', 'views', 'replies', 'digest', 'displayorder')) ? 'dateline' : $comiis_jrrd['comiis_jrrd_cd'];
		$tids = !empty($comiis_jrrd['comiis_jrrd_tid']) ? explode(',', $comiis_jrrd['comiis_jrrd_tid']) : array();
		if($tids){
			$filteradd = 'tid IN ('.dimplode($tids).') and ';
			$sortadd = "dateline";
		}else{
			$forum = array();
			$forum = empty($comiis_jrrd['comiis_jrrd_readforum']) ? array() : unserialize($comiis_jrrd['comiis_jrrd_readforum']);
			if(!is_array($forum)) $forum = array();
			if(isset($forum[0]) && $forum[0] == '') {
				unset($forum[0]);
			}
			if($comiis_jrrd['comiis_jrrd_read'] && $_G['fid']){
				$filteradd = 'fid IN ('.intval($_G['fid']).') and ';
			}elseif($forum){
				$filteradd = 'fid IN ('.dimplode($forum).') and ';
			}
			if($comiis_jrrd['comiis_jrrd_cd'] == 'lastpost'){
				$filteradd .= "replies>'0' and ";
			}elseif($comiis_jrrd['comiis_jrrd_cd'] == 'digest'){
				$filteradd .= "digest>'0' and ";
				$sortadd = "dateline";
			}elseif($comiis_jrrd['comiis_jrrd_cd'] == 'displayorder'){
				$filteradd .= "displayorder IN (1, 2, 3, 4) and ";
				$sortadd = "dateline";
			}							
		}
		$mysql = "select tid,subject,highlight from ".DB::table('forum_thread')." where {$filteradd}displayorder>='0' ORDER BY {$sortadd} desc limit ".intval($comiis_jrrd['comiis_jrrd_mun']);
		$query = DB::query($mysql);
		while ($temp=DB::fetch($query)){
			if($temp['highlight'] && $comiis_jrrd['comiis_jrrd_style']) {
				$temp['style'] = $this->_comiis_getstyle($temp['highlight']);
			}else{
				$temp['style'] = '';
			}
			$comiis_jrrd_txtlist[]=$temp;
		}
		return $comiis_jrrd_txtlist;
	}
}
//From: Dism��taobao��com
?>