<?php
if(!defined('IN_DISCUZ')){exit('Access Denied');}
$comiis_time = array('dateline'=>'{ADDONVAR:RevisionDateline}', 'md5'=>'{ADDONVAR:MD5}');