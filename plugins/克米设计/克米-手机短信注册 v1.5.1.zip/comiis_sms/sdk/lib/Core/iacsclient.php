<?php

interface IAcsClient
{
	public function doAction($requst);
}