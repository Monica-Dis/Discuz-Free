<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	if (!empty($_GET["inajax"]) && $_GET["comiis_poster"] == "yes") {
		global $_G;
		global $comiis_poster_data;
		global $comiis_poster_mob;
		global $comiis_poster_url;
		global $comiis_poster;
		$_var_5 = "comiis_poster";
		global $comiis_poster_time;
		global $comiis_poster_info;
		global $comiis_poster_lang;
		global $comiis_poster;
		loadcache("plugin");
		$_var_10 = 0;
		$comiis_poster_mob = "view";
		$comiis_poster_data = array();
		loadcache("plugin");
		$comiis_poster = $_G["cache"]["plugin"]["comiis_poster"];
		$comiis_poster["bodybyte"] = intval($comiis_poster["bodybyte"]) ? intval($comiis_poster["bodybyte"]) : 300;
		if ($comiis_poster["code"]) {
			$comiis_poster_url = urlencode($comiis_poster["code"]);
		} else {
			$comiis_poster_url = urlencode((!empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off" || $_SERVER["SERVER_PORT"] == 443 ? "https://" : "http://") . $_SERVER["HTTP_HOST"] . str_replace(array("?comiis_poster=yes&inajax=1", "&comiis_poster=yes&inajax=1"), '', $_SERVER["REQUEST_URI"]));
		}
		if (intval($_GET["pid"]) && intval($_GET["pid"]) == $_var_11["id"]) {
			$comiis_poster_mob = "comiis_app_portal";
			$_var_12 = array("title" => $_var_11["title"] ? $_var_11["title"] : ($_var_11["name"] ? $_var_11["name"] : $_G["setting"]["sitename"]), "image" => $_var_11["image"]);
		} else {
			if ($_G["basescript"] == "forum" || $_G["basescript"] == "group") {
				if (CURMODULE == "forumdisplay") {
					$comiis_poster_mob = "list";
				} else {
					if (CURMODULE == "viewthread") {
						global $postlist;
						global $threadsortshow;
						$_var_15 = '';
						$_var_16 = array();
						if ($_G["forum_thread"]["special"] == 2) {
							global $trade;
							global $trades;
							if ($_GET["do"] == "tradeinfo") {
								$_var_15 = $trade["thumb"];
							} else {
								if (is_array($trades)) {
									foreach ($trades as $_var_19) {
										if ($_var_19["attachurl"]) {
											$_var_15 = $_var_19["attachurl"];
											break;
										}
									}
								}
							}
						} else {
							if ($_G["forum_thread"]["special"] == 4) {
								global $activity;
								$_var_15 = $activity["thumb"];
							} else {
								if (is_array($threadsortshow["optionlist"])) {
									foreach ($threadsortshow["optionlist"] as $_var_19) {
										if ($_var_19["type"] == "image") {
											$_var_15 = $_var_19["value"];
											break;
										}
									}
								}
							}
						}
						foreach ($postlist as $_var_21) {
							if ($_var_21["first"]) {
								foreach ($_var_21["attachments"] as $_var_19) {
									if ($_var_19["isimage"] == "1" || $_var_19["isimage"] == "-1") {
										$_var_16 = $_var_19;
										break;
									}
								}
								$_var_22 = messagecutstr(str_replace(array("\r\n", "\r", "\n", "replyreload += ',' + " . $_var_21[pid] . ";", "'", "'"), '', strip_tags($_var_21["message"])), $comiis_poster["bodybyte"]);
								break;
							}
						}
						$comiis_poster_data = array("pic" => $_var_15 ? $_var_15 : $_var_16["url"] . $_var_16["attachment"], "title" => $_G["forum_thread"]["subject"], "icon" => '', "user" => '', "time" => dgmdate($_G["forum_thread"]["dateline"], "u", "9999", "d<\\s\\p\\a\\n>Y/m</\\s\\p\\a\\n>"), "message" => $_var_22);
						if ($comiis_poster["isusername"] == 1) {
							$comiis_poster_data["icon"] = $_G["setting"]["ucenterurl"] . "/avatar.php?uid=" . ($_G["forum_thread"]["author"] ? $_G["forum_thread"]["authorid"] : 0) . "&size=small";
							$comiis_poster_data["user"] = $_G["forum_thread"]["author"];
						} else {
							if ($comiis_poster["isusername"] == 2) {
								$comiis_poster_data["icon"] = $_G["forum"]["icon"] ? get_forumimg($_G["forum"]["icon"]) : '';
								$comiis_poster_data["user"] = $_G["forum"]["name"];
							}
						}
					}
				}
			} else {
				if ($_G["basescript"] == "portal" && CURMODULE == "view") {
					global $article;
					global $cat;
					$comiis_poster_data = array("pic" => $article["thumb"] == 1 ? str_replace(".thumb.jpg", '', $article["pic"]) : '', "title" => $article["title"], "icon" => '', "user" => '', "time" => '', "message" => cutstr($article["summary"], $comiis_poster["bodybyte"]));
					if ($comiis_poster["isusername"] == 1) {
						$comiis_poster_data["icon"] = $_G["setting"]["ucenterurl"] . "/avatar.php?uid=" . $article["uid"] . "&size=small";
						$comiis_poster_data["user"] = $article["username"];
					} else {
						if ($comiis_poster["isusername"] == 2) {
							$comiis_poster_data["icon"] = $comiis_poster["logoimg"] ? $comiis_poster["logoimg"] : "./source/plugin/comiis_poster/image/logo.png";
							$comiis_poster_data["user"] = $cat["catname"];
						}
					}
				} else {
					if ($_G["basescript"] == "home" && CURMODULE == "space") {
						if ($_GET["do"] == "blog" && !empty($_GET["id"])) {
							global $blog;
							$comiis_poster_data = array("pic" => $blog["pic"] ? "data/attachment/album/" . str_replace(".thumb.jpg", '', $blog["pic"]) : '', "title" => $blog["subject"], "icon" => '', "user" => '', "time" => dgmdate($blog["dateline"], "u", "9999", "d<\\s\\p\\a\\n>Y/m</\\s\\p\\a\\n>"), "message" => cutstr(strip_tags($blog["message"]), $comiis_poster["bodybyte"]));
							if ($comiis_poster["isusername"] == 0) {
								$comiis_poster_data["icon"] = '';
								$comiis_poster_data["user"] = '';
							}
						} else {
							if ($_GET["do"] == "album" && !empty($_GET["id"])) {
								global $album;
								global $list;
								$comiis_poster_data = array("pic" => $list[0]["pic"] ? str_replace(".thumb.jpg", '', $list[0]["pic"]) : '', "title" => $album["albumname"], "icon" => $_G["setting"]["ucenterurl"] . "/avatar.php?uid=" . $album["uid"] . "&size=small", "user" => $album["username"], "time" => dgmdate($album["dateline"], "u", "9999", "d<\\s\\p\\a\\n>Y/m</\\s\\p\\a\\n>"), "message" => cutstr(strip_tags($album["depict"]), $comiis_poster["bodybyte"]));
								if ($comiis_poster["isusername"] == 0) {
									$comiis_poster_data["icon"] = '';
									$comiis_poster_data["user"] = '';
								}
							} else {
								if ($_GET["do"] == "album" && !empty($_GET["picid"])) {
									global $pic;
									global $album;
									$comiis_poster_data = array("pic" => $pic["pic"] ? $pic["pic"] : '', "title" => $album["albumname"], "icon" => $_G["setting"]["ucenterurl"] . "/avatar.php?uid=" . $album["uid"] . "&size=small", "user" => $album["username"], "time" => dgmdate($album["dateline"], "u", "9999", "d<\\s\\p\\a\\n>Y/m</\\s\\p\\a\\n>"), "message" => cutstr(strip_tags($album["depict"]), $comiis_poster["bodybyte"]));
									if ($comiis_poster["isusername"] == 0) {
										$comiis_poster_data["icon"] = '';
										$comiis_poster_data["user"] = '';
									}
								}
							}
						}
					}
				}
			}
		}
		if ($comiis_poster_mob == "view") {
			if ($comiis_poster["o_image"] == 1) {
				$comiis_poster_data["pic"] = '';
			} else {
				if ($comiis_poster["openimage"] == 1) {
					$_var_29 = md5($comiis_poster_data["pic"]) . ".jpg";
					$_var_30 = substr($_var_29, 0, 1);
					if (file_exists(DISCUZ_ROOT . "./source/plugin/comiis_poster/cache/" . $_var_30 . "/" . $_var_29)) {
						$comiis_poster_data["pic"] = "./source/plugin/comiis_poster/cache/" . $_var_30 . "/" . $_var_29;
					} else {
						if (substr($comiis_poster_data["pic"], 0, 7) == "http://" || substr($comiis_poster_data["pic"], 0, 7) == "https:/" || substr($comiis_poster_data["pic"], 0, 2) == "//") {
							$_var_31 = explode("\n", str_replace("\r\n", "\n", $_G["cache"]["plugin"]["comiis_poster"]["openimage_url"]));
							if (is_array($_var_31)) {
								foreach ($_var_31 as $_var_19) {
									$_var_19 = trim($_var_19);
									if (strlen($_var_19) && substr($comiis_poster_data["pic"], 0, strlen($_var_19)) == $_var_19) {
										if (!is_dir(DISCUZ_ROOT . "./source/plugin/comiis_poster/cache/" . $_var_30)) {
											mkdir(DISCUZ_ROOT . "./source/plugin/comiis_poster/cache/" . $_var_30, 493, true);
										}
										if ($_var_32 = @fopen(DISCUZ_ROOT . "./source/plugin/comiis_poster/cache/" . $_var_30 . "/" . $_var_29, "wb")) {
											fwrite($_var_32, file_get_contents($comiis_poster_data["pic"]));
											fclose($_var_32);
										}
										$comiis_poster_data["pic"] = "./source/plugin/comiis_poster/cache/" . $_var_30 . "/" . $_var_29;
									}
								}
							}
						}
					}
					if ($comiis_poster_data["icon"]) {
						$comiis_poster_data["icon"] = "./plugin.php?id=comiis_poster:comiis_poster_image&src=" . urlencode($comiis_poster_data["icon"]);
					}
				}
			}
		}
	}