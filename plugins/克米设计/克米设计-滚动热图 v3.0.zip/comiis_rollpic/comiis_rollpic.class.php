<?php
/**
 * 
 * ���׳�Ʒ ������Ʒ
 * ������ƹ����� ��Ȩ���� http:// www.Comiis.com
 * רҵ��̳��ҳ���������, ҳ���������, ���ݰ��/����, ������ο���, ��վЧ��ͼ���, ҳ���׼DIV+CSS����, �������С����ҵ��վ���...
 * ����������Ϊ��ҵ�ṩ������վ���衢��վ�ƹ㡢��վ�Ż������򿪷�������ע�ᡢ���������ȷ���
 * һ����ƺͽ������Ϊ��ҵ���������ʺ��Լ��������վ��Ӫƽ̨������޶ȵ�ʹ��ҵ����Ϣʱ�����������̻���
 *
 *    TEL: 13450110120 15813025137
 *     QQ: 21400445 8821775 11012081 327460889
 * E-mail: ceo@comiis.com
 *
 * ��������û�����Ⱥ: ��Ⱥ83667771 ��Ⱥ83667772 ��Ⱥ83667773 ��Ⱥ110900020 ��Ⱥ110900021 ��Ⱥ70068388 ��Ⱥ110899987
 * ����ʱ��: ��һ����������09:00-11:00, ����03:00-05:00, ����08:30-10:30(����������Ϣ)
 * 
 */
 
if(!defined('IN_DISCUZ')) {exit('Access Denied');}
$finish = TRUE;
class plugin_comiis_rollpic { }
class plugin_comiis_rollpic_forum extends plugin_comiis_rollpic{
	function _output($mod){
		global $_G;
		$open = $comiis_rollpictime = $stratcache = 0;
		$retype = $filteradd = $sortadd = $comiis_cachename = "";
		$pic_list = array();
		loadcache('forums');
		@extract($_G['cache']['plugin']['comiis_rollpic']);
		if($_G['basescript'] == 'forum'){
			$filteradd = "t.fid = '{$_G[fid]}' AND ";
			if(CURMODULE == 'index' && $inbbs){
				if($mod == 'index_top' && $bbshook == 1){
					$open = 1;
				}elseif($mod == 'index_middle' && $bbshook == 2){
					$open = 1;
				}
				$retype = $bbstype;
				if(!empty($indextype)) {
					$indextype = unserialize($indextype);
					if(isset($indextype[0]) && $indextype[0] == '') {
						$filteradd = "";
					}else{
						$filteradd = $indextype ? 't.fid IN ('.dimplode($indextype).') AND ' : '';
					}
				}
				$comiis_rollpictime = $bbstime;
				$comiis_cachename = "comiis_rollpic_bbs";
			}elseif(CURMODULE == 'forumdisplay' && in_array($_G['fid'], (array)unserialize($inforum))){
				if($mod == 'forumdisplay_top' && $listhook == 1){
					$open = 1;
				}elseif($mod == 'forumdisplay_bottom' && $listhook == 2){
					$open = 1;
				}
				$retype = $listtype;
				$comiis_rollpictime = $listtime;
				$comiis_cachename = "comiis_rollpic_list". $_G['fid'];
			}elseif(CURMODULE == 'viewthread' && in_array($_G['fid'], (array)unserialize($inviews))){
				if($mod == 'viewthread_top' && $viewshook == 1){
					$open = 1;
				}elseif($mod == 'viewthread_bottom' && $viewshook == 2){
					$open = 1;
				}
				$retype = $viewstype;
				$comiis_rollpictime = $viewtime;
				$comiis_cachename = "comiis_rollpic_view". $_G['fid'];
			}
			if($open == 1){
				$isloop = $loop = 0;
				switch($looppattern){
					case 1:
						$loop = "1";
						break;
					case 2:
						$loop = "-1";
						break;
					case 3:
						$loop = "0";
						break;
					case 4:
						$loop = "1";
						$isloop = 1;
						break;
					case 5:
						$loop = "-1";
						$isloop = 1;
						break;
				}
				$margin_top = ($showheight - 50) / 2;
				$span_width = $showwidth - 20;
				loadcache(array($comiis_cachename, 'databasemaxid'));
				if(TIMESTAMP - $_G['cache'][$comiis_cachename]['cachetime'] < $cachetime) {
					$stratcache = 0;
					$pic_list = $_G['cache'][$comiis_cachename]['data'];
				} else {
					$stratcache = 1;
				}
				$showtids = !empty($showtid) ? explode(',', $showtid) : array();
				if($stratcache == 1){
					if($showtids){
						$filteradd = "t.tid in(". dimplode($showtids) .") AND ";
					}
					$pic_list = array();
					if(!in_array($retype, array('dateline', 'lastpost', 'views', 'replies', 'digest', 'displayorder'))) $retype = 'dateline';
					$sortadd = $retype;
					if($retype == 'lastpost'){
						$filteradd .= "t.replies>'0' AND ";
					}elseif($retype == 'digest'){
						$filteradd .= "t.digest>'0' AND ";
						$sortadd = "dateline";
					}elseif($retype == 'displayorder'){
						$filteradd .= "t.displayorder IN (1, 2, 3, 4) AND ";
						$sortadd = "dateline";
					}
					if($comiis_rollpictime > 0){
						$filteradd .= "t.dateline >= '". (TIMESTAMP - $comiis_rollpictime) ."' AND ";
					}
					$btids = !empty($tids) ? explode(',', $tids) : array();
					if($btids){
						$filteradd .= "t.tid not in(". dimplode($btids) .") AND ";
					}
					
					$filteradd = ($maxid = $_G['cache']['databasemaxid']['thread']['id'] - ($_G['setting']['blockmaxaggregationitem'] ? $_G['setting']['blockmaxaggregationitem'] : 20000)) > 0 ? 't.tid > \''. $maxid. '\' AND '. $filteradd : $filteradd;
					$mysql="select t.authorid, t.author, t.tid, t.fid, t.dateline, t.subject, a.attachment, a.remote from ". DB::table('forum_thread'). " t INNER JOIN ". DB::table('forum_threadimage'). " a ON a.tid = t.tid where {$filteradd} t.attachment = '2' AND t.displayorder >= '0' ORDER BY t.{$sortadd} desc limit $readpicnum";
					$query = DB::query($mysql);
					while($temp = DB::fetch($query)){
						$temp['all_subject'] = $temp['subject'];
						$temp['subject'] = cutstr($temp['subject'], $titlenum,'');
						$temp['image'] = $this->_comiis_rollpic_image(array(
							'tid' => $temp['tid'],
							'pic' => $temp['attachment'],
							'remote' => $temp['remote'],
							'w' => $showwidth,
							'h' => $showheight,
							'type' => 2,
						));
						$temp['dateline'] = dgmdate($temp['dateline'], 'u', '9999', 'm-d h:i');
						$temp['url'] = str_ireplace('{id}', $temp['tid'], $url);
						$pic_list[] = $temp;
					}
					$_G['cache'][$comiis_cachename]['cachetime'] = TIMESTAMP;
					$_G['cache'][$comiis_cachename]['data'] = $pic_list;
					save_syscache($comiis_cachename, $_G['cache'][$comiis_cachename]);
				}
				$css = strip_tags($css);
				include template('comiis_rollpic:comiis_rollimgs');
				return $return;
			}
		}
	}
	function index_top_output(){
		return $this->_output('index_top');
	}
	function index_middle_output(){
		return $this->_output('index_middle');
	}
	function forumdisplay_top_output(){
		return $this->_output('forumdisplay_top');
	}
	function forumdisplay_bottom_output(){
		return $this->_output('forumdisplay_bottom');
	}
	function viewthread_top_output(){
		return $this->_output('viewthread_top');
	}
	function viewthread_bottom_output(){
		return $this->_output('viewthread_bottom');
	}
	function viewthread(){
		global $_G;
		$_G['forum']['picstyle'] = 1;
	}
	function _comiis_rollpic_image($data = array()){
		global $_G;
		$tid = intval($data['tid']);
		$pic = $data['pic'];
		$remote = $data['remote'] ? 1 : 0;
		$w = intval($data['w']);
		$h = intval($data['h']);
		$type = intval($data['type']);
		$attachurl = $this->_attachpreurl();
		$thumbfile = 'comiis_rollpic/'. $this->_makethumbpath($tid, $w, $h, substr(md5($pic), -5));
		if(file_exists($_G['setting']['attachdir']. $thumbfile)) {
			return $attachurl. $thumbfile;
		}
		$filename = ($remote ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachdir']). 'forum/'. $pic;
		require_once libfile('class/image');
		$img = new image;
		if($img->Thumb($filename, $thumbfile, $w, $h, $type)) {
			return $attachurl. $thumbfile;
		} else {
			return $attachurl. 'forum/'. $pic;
		}
	}
	function _makethumbpath($id, $w, $h, $md5){
		$dw = intval($w);
		$dh = intval($h);
		$_daid = sprintf("%09d", $id);
		$dir1 = substr($_daid, 0, 3);
		$dir2 = substr($_daid, 3, 2);
		$dir3 = substr($_daid, 5, 2);
		return $dir1.'/'.$dir2.'/'.$dir3.'/'.substr($_daid, -2).'_'.$dw.'_'.$dh.'_'.$md5.'.jpg';
	}
	function _attachpreurl() {
		static $attachurl = null;
		if($attachurl === null) {
			global $_G;
			$parse = parse_url($_G['setting']['attachurl']);
			$attachurl = !isset($parse['host']) ? $_G['siteurl'].$_G['setting']['attachurl'] : $_G['setting']['attachurl'];
		}
		return $attachurl;
	}
}
//From: Dism��taobao��com
?>