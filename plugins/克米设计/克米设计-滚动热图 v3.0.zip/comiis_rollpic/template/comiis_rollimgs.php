<?PHP exit('Access Denied');?>
<!--{block return}-->
<link rel="stylesheet" type="text/css" href="./source/plugin/comiis_rollpic/image/comiis.css?1314" charset="UTF-8" />
<style>
.comiis_rollpic_bt span.kmleft::before {background:{if $titlecolor}{$titlecolor}{else}#0299ff{/if}}
{if $radius}#comiis_rollpic, .comiis_rollpic_bt span.kmleft::before, .comiis_picdiv, .comiis_rollpic li, .comiis_rollpic li a img {border-radius:{$radius}}{/if}
.comiis_rollpic_bt {background:{if $kmtitlebg}{$kmtitlebg}{else}#f9f9f9{/if}}
#comiis_rollpic {border:1px solid {if $bordercolor}{$bordercolor}{else}#eeeeee{/if};background:{if $kmbodybg}{$kmbodybg}{else}#ffffff{/if}}
.comiis_rollpic_bt {border-bottom:1px solid {if $bordercolor}{$bordercolor}{else}#eeeeee{/if}}
.comiis_rollpic_bt span.kmright, .comiis_rollpic_bt span.kmright a, .comiis_rollpic_bt span.kmccwezd {color:{if $kmcolor}{$kmcolor}{else}#999999{/if}}
{if $looppattern == 3}.comiis_picdiv {margin:7px}{/if}
.comiis_rollpic li a {width:{$showwidth}px;height:{$showheight}px}
.comiis_rollpic li a img {width:{$showwidth}px;height:{$showheight}px}
.comiis_rollpic li a span.kmtit, .comiis_rollpic li a .kmbox {width:{$span_width}px;background:linear-gradient(rgba(0,0,0,0),{if $kmigtitbg}{$kmigtitbg}{else}rgba(0,0,0,0.9){/if});color:{if $kmigtitcolor}{$kmigtitcolor}{else}#ffffff{/if}}
.comiis_pic {{if $isloop}width:100%;{/if}overflow:hidden;position:relative}
.comiis_lico a {top:{$margin_top}px}
{if $imgstyle == 1}
.comiis_lico a {left:10px;margin-top:5px;width:40px;height:40px;border-radius:50%}
.comiis_lico a img {margin-top:10px}
.comiis_lico a.kmyk {left:auto;right:10px}
{/if}
{$css}
</style>
<div style="overflow:hidden;" id="comiis_rollpic"{if $kmstyle == 2} class="comiis_rollpicv2"{/if}>
<!--{if $istitle}-->
<div class="comiis_rollpic_bt cl">
	<span class="kmleft">{if CURMODULE == 'index'}{$showtitle}{elseif CURMODULE == 'forumdisplay'}{$showtitle_list}{elseif CURMODULE == 'viewthread'}{$showtitle_view}{/if}</span>
	<span class="kmright">{$showhtml}</span>
</div>
<!--{/if}-->
<div class="comiis_picdiv cl">
	<!--{if $pic_list}-->
		<!--{if $isloop}--><div class="comiis_lico z"><a href="javascript:" onClick="loop_left()"><img src="source/plugin/comiis_rollpic/image/comiis_lico.svg" alt="left"></a></div><!--{/if}-->
		<div class="comiis_pic z" id="twtloop">
			<div class="comiis_rollpic" id="picloop">
				<ul>
					<!--{loop $pic_list $temp}-->
						<!--{if $imgstyle == 1}-->
						<li>
							<a href="{$temp['url']}" title="{$temp['all_subject']}" target="_blank"><img src="$temp['image']" width="{$showwidth}" height="{$showheight}" alt="{$temp['all_subject']}" class="kmimg">
							<!--{if CURMODULE == 'index' || count($showtids)}--><div class="kmfid"><img src="source/plugin/comiis_rollpic/image/comiis_fidico.svg">{$_G['cache']['forums'][$temp['fid']]['name']}</div><!--{/if}-->
							<div class="kmbox ybphtl">
								<span class="kmtits">{$temp['all_subject']}</span>
								<span class="kmuser"><em class="kmtx"><img src="{$_G['setting']['ucenterurl']}/avatar.php?uid={$temp['authorid']}&size=small"></em><em class="kmtxt">{$temp['author']}</em><em class="kmtxt">{$temp['dateline']}</em></span>
							</div>
							</a>
						</li>
						<!--{else}-->
						<li><a href="{$temp[url]}" title="{$temp[all_subject]}" target="_blank"><img src="$temp['image']" width="{$showwidth}" height="{$showheight}" alt="{$temp['all_subject']}" class="kmimg"><span class="kmtit guah">{$temp['subject']}</span></a></li>
						<!--{/if}-->
					<!--{/loop}-->
					
				</ul>
			</div>
		</div>
		<!--{if $isloop}--><div class="comiis_lico z"><a href="javascript:" onClick="loop_right()" class="kmyk"><img src="source/plugin/comiis_rollpic/image/comiis_rico.svg" alt="right"></a></div><!--{/if}-->
	<!--{else}-->
		<div class="kmnodata xg1">{$kmnodata}</div>
	<!--{/if}-->
</div>
</div>
<!--{if $loop != '0' && $pic_list}-->
<SCRIPT type="text/javascript">
var ctwidth = 0;
var step = {$loop};
var speed = 30;
var kmdiv = $("twtloop");
var picdiv = $("picloop");
var a_id = picdiv.getElementsByTagName("li");
var a_width = a_id[0].offsetWidth;
var all_width = (a_width + 10) * a_id.length;
picdiv.style.width = (all_width * 10) + "px" ;
picdiv.innerHTML += picdiv.innerHTML;
function Marquee(){
	if(step == 1 && kmdiv.scrollLeft >= all_width){
		kmdiv.scrollLeft = 0;
	}else if(step == -1 && kmdiv.scrollLeft <= 0){
		kmdiv.scrollLeft = all_width;
	}
	var ctwidths = $("comiis_rollpic") ? $("comiis_rollpic").offsetWidth : ($("pgt") ? $("pgt").offsetWidth : $("ct").offsetWidth);
	if(ctwidth!=ctwidths){
		kmdiv.style.width=(ctwidths<!--{if $isloop}-->{if $kmstyle == 2}-0{else}-22{/if}<!--{/if}-->)+"px";
		ctwidth=ctwidths;
	}
	kmdiv.scrollLeft += step;
}
var MyMar=setInterval(Marquee,speed);
kmdiv.onmouseover=function() {clearInterval(MyMar)}
kmdiv.onmouseout=function() {MyMar=setInterval(Marquee,speed)}
function loop_left(){step = 1;}
function loop_right(){step = -1;}
</SCRIPT>
<!--{/if}-->
<!--{/block}-->