<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function comiis_app_load_app_activity_data($plugin_id)
{
	global $_G;
	$comiis_system_key = 0;
	$comiis_md5file = $comiis_system_config = $comiis_info = array();
	loadcache(array('comiis_app_switch'));
	$comiis_upload = 0;
}