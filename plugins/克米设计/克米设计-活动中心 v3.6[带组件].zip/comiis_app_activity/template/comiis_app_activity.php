<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{subtemplate common/header}-->
<style id="diy_style" type="text/css"></style>
<link rel="stylesheet" type="text/css" href="source/plugin/comiis_app_activity/style/comiis_pc.css?{VERHASH}gzon" />
<style>
body {
--comiis-bodybg:<!--{if $comiis_app_activity_set['pc_bodybg']}-->{$comiis_app_activity_set['pc_bodybg']}<!--{else}-->#ffffff<!--{/if}-->;
--comiis-color:<!--{if $comiis_app_activity_set['pc_color']}-->{$comiis_app_activity_set['pc_color']}<!--{else}-->#0299ff<!--{/if}-->;
--comiis-colora:<!--{if $comiis_app_activity_set['pc_colora']}-->{$comiis_app_activity_set['pc_colora']}<!--{else}-->#fcad30<!--{/if}-->;
--comiis-border:<!--{if $comiis_app_activity_set['pc_border']}-->{$comiis_app_activity_set['pc_border']}<!--{else}-->#eeeeee<!--{/if}-->;
--comiis-zyw:<!--{if $comiis_app_activity_set['pc_zyw']}-->{$comiis_app_activity_set['pc_zyw']}<!--{else}-->12<!--{/if}-->px;
--comiis-zywx:<!--{if $comiis_app_activity_set['pc_zyw']}-->{echo $comiis_app_activity_set['pc_zyw']/2;}<!--{/if}-->px;
--comiis-btnbg:<!--{if $comiis_app_activity_set['pc_qianbg']}-->{$comiis_app_activity_set['pc_qianbg']}<!--{else}-->#f3f3f3<!--{/if}-->;
}
.comiis_app_activity_right {width:<!--{if $comiis_app_activity_set['pc_rwidth']}-->{$comiis_app_activity_set['pc_rwidth']}<!--{else}-->300<!--{/if}-->px}
<!--{if $comiis_app_activity_set['pc_liststyle'] == 2}-->.comiis_app_activity_right .kmpost a {border-radius:6px}<!--{/if}-->
<!--{if $comiis_app_activity_set['pc_rorl'] == 2}-->.comiis_app_activity_right {float:left;margin-left:0;margin-right:var(--comiis-zyw)}<!--{/if}-->
<!--{if $comiis_app_activity_set['pc_pt'] == 0}-->.comiis_app_activity {margin-top:var(--comiis-zyw)}<!--{/if}-->
<!--{if $comiis_app_activity_set['pc_style'] == 2}-->.comiis_app_activity_list, .comiis_app_activity_box, .comiis_app_activity .comiis_okbox {border:none}
<!--{elseif $comiis_app_activity_set['pc_style'] == 3}-->
.comiis_app_activity {margin:5px auto}
.comiis_app_activity_list, .comiis_app_activity_box, .comiis_app_activity .comiis_okbox {border:none}
.comiis_app_activity_listnv, .comiis_app_activity_my, .comiis_app_activity_right .kmpost a {margin:0}
.comiis_app_activity_box, .comiis_app_activity_listbox, .comiis_app_activity .comiis_okbox, .comiis_app_activity_listnv, .comiis_app_activity_piclist {padding:0}
.comiis_app_activity_right <!--{if $comiis_app_activity_set['pc_rorl'] == 2}-->{margin-left:0;margin-right:20px}<!--{else}-->{margin-left:20px}<!--{/if}-->
<!--{/if}-->
<!--{if $comiis_app_activity_set['pc_imgwz'] == 2}-->	
.comiis_app_activity_listbox .kmimg {float:right;margin-right:0;margin-left:var(--comiis-zyw)}
.comiis_app_activity_listbox .kmstyle {position:absolute;top:var(--comiis-zyw);margin-right:10px;right:0}
.comiis_app_activity_listbox .kmstyle span {background:rgb(0,0,0,.5)}
.comiis_app_activity_listbox .kmbtn {position:absolute;bottom:var(--comiis-zyw);right:auto;left:0}
.comiis_app_activity_listbox .kmbtn em {border-radius:4px}
<!--{/if}-->
<!--{if $comiis_app_activity_set['pc_css']}-->{echo strip_tags($comiis_app_activity_set['pc_css']);}<!--{/if}-->
</style>
<!--{if $comiis_app_activity_set['pc_pt'] == 1}-->
<div id="pt" class="bm cl">
	<div class=" z"><a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a><em>&raquo;</em>{$comiis_app_activity_set['name']}</div>
</div>
<!--{/if}-->
<div style="clear:both;"></div>
<div class="comiis_app_activity giwmzkb cl">
	<!--[diy=comiis_app_activity_topdiy]--><div id="comiis_app_activity_topdiy" class="area"></div><!--[/diy]-->
	<!--{if $comiis_app_activity_set['pc_rorl'] != 3}-->
	<div class="comiis_app_activity_right cl">
		<!--[diy=comiis_app_activity_rdiya]--><div id="comiis_app_activity_rdiya" class="area"></div><!--[/diy]-->
		<!--{if $comiis_app_activity_set['post_url']}-->
			<div class="comiis_app_activity_box kmpost cl">
				<a href="{$comiis_app_activity_set['post_url']}" title="{$comiis_app_ac_lang['17']}" target="_blank">{$comiis_app_ac_lang['17']}</a>
			</div>
		<!--{/if}-->
		<!--[diy=comiis_app_activity_rdiyb]--><div id="comiis_app_activity_rdiyb" class="area"></div><!--[/diy]-->
	</div>
	<!--{/if}-->
	<div class="comiis_app_activity_left cl">
		<!--[diy=comiis_app_activity_ldiya]--><div id="comiis_app_activity_ldiya" class="area"></div><!--[/diy]-->		
		<div class="comiis_app_activity_list aedxd cl">		
			<div class="comiis_app_activity_listnv cl">
				<a href="plugin.php?id=comiis_app_activity"{if empty($comiis_app_activityclass)} class="kmon"{/if}>{$comiis_app_ac_lang['01']}</a>
				<!--{loop $activitytypelist $temp}-->
				<a href="plugin.php?id=comiis_app_activity&class={echo urlencode($temp);}{if $comiis_app_activitytype}&type={$comiis_app_activitytype}{/if}""{if $comiis_app_activityclass == $temp} class="kmon"{/if}>{$temp}</a>
				<!--{/loop}-->
			</div>
			<div class="comiis_app_activity_my edxveef cl">
				<ul>
					<li><a href="plugin.php?id=comiis_app_activity{if $comiis_app_activityclass}&class={echo urlencode($comiis_app_activityclass);}{/if}&type=start" class="{if $comiis_app_activitytype == 'start'}kmon{else}xg1{/if}">{$comiis_app_ac_lang['02']}</a></li>
					<li><a href="plugin.php?id=comiis_app_activity{if $comiis_app_activityclass}&class={echo urlencode($comiis_app_activityclass);}{/if}&type=end" class="{if $comiis_app_activitytype == 'end'}kmon{else}xg1{/if}">{$comiis_app_ac_lang['03']}</a></li>
					<li><a {if $_G['uid']}href="plugin.php?id=comiis_app_activity{if $comiis_app_activityclass}&class={echo urlencode($comiis_app_activityclass);}{/if}&type=participate"{else}href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)"{/if} class="{if $comiis_app_activitytype == 'participate'}kmon{else}xg1{/if}">{$comiis_app_ac_lang['04']}</a></li>
					<li><a {if $_G['uid']}href="plugin.php?id=comiis_app_activity{if $comiis_app_activityclass}&class={echo urlencode($comiis_app_activityclass);}{/if}&type=launched"{else}href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)"{/if} class="{if $comiis_app_activitytype == 'launched'}kmon{else}xg1{/if}">{$comiis_app_ac_lang['05']}</a></li>
				</ul>
			</div>
			<!--[diy=comiis_app_activity_ldiyb]--><div id="comiis_app_activity_ldiyb" class="area"></div><!--[/diy]-->
			<!--{if count($comiis_app_activity)}-->
				<!--{if $comiis_app_activity_set['pc_liststyle'] == 2}-->
					<div class="comiis_app_activity_piclist cl">
						<ul>
						<!--{loop $comiis_app_activity $key $temp}-->
							<li>
								<div class="kmstyle"><span>{$temp['class']}</span></div>								
								<a href="forum.php?mod=viewthread&tid={$temp['tid']}" target="_blank" class="kmimg"><img src="<!--{if $temp['aid']}-->{echo getforumimg($temp['aid'], '0', '480', '250')}<!--{else}-->source/plugin/comiis_app_activity/style/comiis_noimg.jpg<!--{/if}-->" class="vm"></a>
								<div class="kmbox cl">
									<a href="forum.php?mod=viewthread&tid={$temp['tid']}" title="{$temp['subject']}" target="_blank" class="kmtit">{$temp['subject']}</a>
									<div class="kmtxt litime xg1">{$comiis_app_ac_lang['07']}: {echo dgmdate($temp['starttimefrom'], 'u', '9999', 'Y-m-d');}{if $temp['starttimeto']} - {echo dgmdate($temp['starttimeto'], 'u', '9999', 'Y-m-d');}{/if}</div>
									<div class="kmtxt liplace xg1">{$comiis_app_ac_lang['16']}: {$temp['place']}</div>									
									{echo $temp['starttimeto'] > 0 ? ($temp['starttimeto'] > TIMESTAMP ? (intval($temp['expiration']) && $temp['expiration'] < TIMESTAMP ? '<div class="kmtxt liviews xg1">'.$comiis_app_ac_lang['19'].'</div>' : '<div class="kmtxt liviews xg1">'.$comiis_app_ac_lang['11'].' <span>'.$temp['views'].'</span> '.$comiis_app_ac_lang['12'].'</div>') : '<div class="kmtxt liviews xg1">'.$comiis_app_ac_lang['11'].' <span>'.$temp['views'].'</span> '.$comiis_app_ac_lang['12'].'</div>') : ($temp['starttimefrom'] > TIMESTAMP ? (intval($temp['expiration']) && $temp['expiration'] < TIMESTAMP ? '<div class="kmtxt liviews xg1">'.$comiis_app_ac_lang['19'].'</div>' : '<div class="kmtxt liviews xg1">'.$comiis_app_ac_lang['11'].' <span>'.$temp['views'].'</span> '.$comiis_app_ac_lang['12'].'</div>') : '<div class="kmtxt liviews xg1">'.$comiis_app_ac_lang['19'].'</div>');}
								</div>
								<a href="forum.php?mod=viewthread&tid={$temp['tid']}" target="_blank" class="kmbtn">{echo $temp['starttimeto'] > 0 ? ($temp['starttimeto'] > TIMESTAMP ? (intval($temp['expiration']) && $temp['expiration'] < TIMESTAMP ? '<em class="acbg_0">'.$comiis_app_ac_lang['18'].'</em>' : '<em class="acbg_a">'.$comiis_app_ac_lang['09'].'</em>') : '<em class="acbg_b xg1">'.$comiis_app_ac_lang['10'].'</em>') : ($temp['starttimefrom'] > TIMESTAMP ? (intval($temp['expiration']) && $temp['expiration'] < TIMESTAMP ? '<em class="acbg_0">'.$comiis_app_ac_lang['18'].'</em>' : '<em class="acbg_a">'.$comiis_app_ac_lang['09'].'</em>') : '<em class="acbg_0">'.$comiis_app_ac_lang['18'].'</em>');}</a>
							</li>
						<!--{/loop}-->
						</ul>
					</div>
				<!--{else}-->
					<div class="comiis_app_activity_listbox cl">
						<ul>
						<!--{loop $comiis_app_activity $key $temp}-->
							<li>
								<a href="forum.php?mod=viewthread&tid={$temp['tid']}" target="_blank" class="kmimg"><img src="<!--{if $temp['aid']}-->{echo getforumimg($temp['aid'], '0', '480', '250')}<!--{else}-->source/plugin/comiis_app_activity/style/comiis_noimg.jpg<!--{/if}-->" class="vm"></a>
								<a href="forum.php?mod=viewthread&tid={$temp['tid']}" title="{$temp['subject']}" target="_blank" class="kmtit">{$temp['subject']}</a>
								<div class="kmstyle"><span>{$temp['class']}</span></div>
								<div class="kmtxt litime xg1">{$comiis_app_ac_lang['07']}: {echo dgmdate($temp['starttimefrom'], 'u', '9999', 'Y-m-d');}{if $temp['starttimeto']} - {echo dgmdate($temp['starttimeto'], 'u', '9999', 'Y-m-d');}{/if}</div>
								<div class="kmtxt liplace xg1">{$comiis_app_ac_lang['16']}: {$temp['place']}</div>
								{echo $temp['starttimeto'] > 0 ? ($temp['starttimeto'] > TIMESTAMP ? (intval($temp['expiration']) && $temp['expiration'] < TIMESTAMP ? '<div class="kmtxt liviews xg1">'.$comiis_app_ac_lang['19'].'</div>' : '<div class="kmtxt liviews xg1">'.$comiis_app_ac_lang['11'].' <span>'.$temp['views'].'</span> '.$comiis_app_ac_lang['12'].'</div>') : '<div class="kmtxt liviews xg1">'.$comiis_app_ac_lang['11'].' <span>'.$temp['views'].'</span> '.$comiis_app_ac_lang['12'].'</div>') : ($temp['starttimefrom'] > TIMESTAMP ? (intval($temp['expiration']) && $temp['expiration'] < TIMESTAMP ? '<div class="kmtxt liviews xg1">'.$comiis_app_ac_lang['19'].'</div>' : '<div class="kmtxt liviews xg1">'.$comiis_app_ac_lang['11'].' <span>'.$temp['views'].'</span> '.$comiis_app_ac_lang['12'].'</div>') : '<div class="kmtxt liviews xg1">'.$comiis_app_ac_lang['19'].'</div>');}
								<a href="forum.php?mod=viewthread&tid={$temp['tid']}" target="_blank" class="kmbtn">{echo $temp['starttimeto'] > 0 ? ($temp['starttimeto'] > TIMESTAMP ? (intval($temp['expiration']) && $temp['expiration'] < TIMESTAMP ? '<em class="acbg_0">'.$comiis_app_ac_lang['18'].'</em>' : '<em class="acbg_a">'.$comiis_app_ac_lang['09'].'</em>') : '<em class="acbg_b xg1">'.$comiis_app_ac_lang['10'].'</em>') : ($temp['starttimefrom'] > TIMESTAMP ? (intval($temp['expiration']) && $temp['expiration'] < TIMESTAMP ? '<em class="acbg_0">'.$comiis_app_ac_lang['18'].'</em>' : '<em class="acbg_a">'.$comiis_app_ac_lang['09'].'</em>') : '<em class="acbg_0">'.$comiis_app_ac_lang['18'].'</em>');}</a>
							</li>
						<!--{/loop}-->
						</ul>
					</div>
				<!--{/if}-->		
			<!--{else}-->
				<div class="comiis_app_activity_nodata xg1 cl">{$comiis_app_activity_set['no_ac']}</div>
			<!--{/if}-->
		</div>
		<!--[diy=comiis_app_activity_ldiyc]--><div id="comiis_app_activity_ldiyc" class="area"></div><!--[/diy]-->
		<!--{if count($comiis_app_activity)}--><div class="comiis_pg cl">$multipage</div><!--{/if}-->
		<!--[diy=comiis_app_activity_ldiyd]--><div id="comiis_app_activity_ldiyd" class="area"></div><!--[/diy]-->
	</div>
	<!--[diy=comiis_app_activity_footdiy]--><div id="comiis_app_activity_footdiy" class="area"></div><!--[/diy]-->
</div>
<!--{subtemplate common/footer}-->
<!--{eval exit();}-->