function cloud_outside_upload(client_id,access_token,cloudUploadSuccess){
  paramInit();
  var startnum = 0;
  function paramInit() {
    var selectfiles = document.getElementById('selectfiles');
    selectfiles.addEventListener('change', function(e){
			if (selectfiles.files && selectfiles.files[0]) {
				e.preventDefault();
				if(client_id == '' || access_token == ''){
          comiis_video_tipbox('请先设置优酷云信息!');
          return;
				}
				var name = selectfiles.files && selectfiles.files[0].name;
				name = name.substring(0, name.lastIndexOf("."));
				var names = (jQuery("input[name='topicsubmit']").length > 0 ? jQuery("#needsubject").val() : (jQuery("#postsubmit").length > 0 ? jQuery("#subject").val() : name));
				var newNames = substr((names ? names : name), 20);
				jQuery("#input01").val(newNames);
				jQuery("#input02").val(newNames);
				jQuery("#textarea").val(name);
		    postfiles();
      }
    });
  }  
    function postfiles() {
			startnum++;
			jQuery('.comiis_post_mp4').hide();
			jQuery('#comiis_post_mp4_up').show();
      var uploadFlag = true;
      var ossFile = '';
      var filename = '';
      if (selectfiles.files && selectfiles.files[0]) {
        ossFile = selectfiles.files[0];
        filename = ossFile.name;
        var filesize = ossFile.size;
        var filetype = ossFile.type;
        var filemd5 = '';
        var title = jQuery('input[name=title]').val();
        var tags = jQuery('input[name=tags]').val();
        var category = jQuery('#category-node option:selected').val();
        var copyright_type = jQuery('input[name=copyright_type]:checked').val();
        var public_type = jQuery('input[name=public_type]:checked').val();
        var description = jQuery('textarea[name=description]').val();
        var watch_password = '';
        if (filesize > 4294967296) {
          comiis_video_tipbox('文件过大!');
          return;
        }
        browserMD5File(ossFile, function(err, md5){
           filemd5 = md5;
           if(filemd5){
             if (!filename) {
               comiis_video_tipbox('请选择上传文件!');
               return;
             }
              jQuery.ajax({
                 type: 'GET',
                 url: '//api.youku.com/uploads/create.json',
                 data: {
                   client_id: client_id,
                   access_token: access_token,
                   file_name: filename,
                   file_size: filesize,
                   title: title,
                   tags: tags,
                   category: category,
                   file_md5: filemd5,
                   copyright_type: copyright_type,
                   public_type: public_type,
                   watch_password: watch_password,
                   description: description,
                   isweb: 1,
                   isnew: 1
                 },
                 dataType: 'JSON',
                 success: function(res) {
                   if (res) {
											if(res.error){
												if(startnum < 2){
													jQuery.ajax({
														 type: 'GET',
														 url: './plugin.php?id=comiis_app_video:comiis_app_video_up&up=comiis_up_token',
														 dataType:'xml',
														 success: function(s) {
																if(s.lastChild.firstChild.nodeValue){
																	access_token = s.lastChild.firstChild.nodeValue;
																	postfiles();
																}
														 }
													 });
													return;
												}else{
													comiis_video_tipbox('优酷云信息错误或已过期!');
													return;
												}
											}
                     var accessid = res.temp_access_id;
                     var accesskey = res.temp_access_secret;
                     var oss_bucket = res.oss_bucket;
                     var oss_object = res.oss_object;
                     var security_token = res.security_token;
                     var host = res.endpoint;
                     uploadToken = res.upload_token;
                     var video_id = res.video_id;
                     browserAliOss(accessid, accesskey, security_token, oss_bucket, oss_object, ossFile);
                   } else {
                     comiis_video_tipbox('create接口返回失败,请重试!');
                     return;
                   }
                 },
                 error: function(error) {
                   comiis_video_tipbox('create接口返回失败,' + error);
                 }
               });
           }else{
             comiis_video_tipbox('md5加密失败！');
             return;
           }
        })
        var ossProgress = document.getElementById('oss-progress');
        var ossfileInfor = document.getElementById('ossfileInfor');
        ossfileInfor.innerText = filename + ' (' + Math.ceil(filesize / 1024 / 1024) + 'MB)';
      } else {
        comiis_video_tipbox('请选择上传文件!');
        return;
      }
    };
  function browserAliOss(accessKeyId, accessKeySecret, stsToken, bucket, oss_object, ossFile) {
    var client = new OSS({
      region: 'oss-cn-shanghai',
      accessKeyId: accessKeyId,
      accessKeySecret: accessKeySecret,
      stsToken: stsToken,
      bucket: bucket
    });
    var result = client.multipartUpload(oss_object, ossFile, {
      progress: function(p, c, r) {
        if (p == 0) {
          p = 0.01;
        }
        var ossProgress = document.getElementById('oss-progress');
        ossProgress.style.display = 'block';
        var progressBar = document.getElementsByClassName('bar');
        if (progressBar) {
          progressBar[0].style.width = p * 100 + '%';
        }
      },
      parallel: 2,
      partSize: 20971520,
      mime: 'video/*'
    }).then(function(result) {
      if (result && result.res.status == 200) {
        var requestUrls = result.res.requestUrls;
        jQuery.ajax({
          url: '//api.youku.com/uploads/commit.json',
          type: 'POST',
          data: {
            client_id: client_id,
            access_token: access_token,
            upload_token: uploadToken,
            upload_server_name: requestUrls
          },
          dataType: 'JSON',
          success: function(res) {
            if (res) {
              cloudUploadSuccess(res);
            } else {
              comiis_video_tipbox('commit接口返回失败!');
            }
          },
          error: function(res) {
            comiis_video_tipbox('上传失败！' + res);
          }
        })
      } else {
        comiis_video_tipbox('上传失败:' + JSON.stringify(result));
      }
    }).then(function(err) {
      comiis_video_tipbox('error:' + JSON.stringify(err));
    })
  }
}
window.substr = substr;
function substr(str, len){
	if(!str || !len) {
			return ''; 
		}      
		var a = 0;
		var i = 0;      
		var temp = '';      
		for (i=0;i<str.length;i++){         
			if (str.charCodeAt(i)>255){                   
				a+=2;         
			}         
			else         
			{             
				a++;         
			}         
			if(a > len) { 
				return temp; 
			}          
			temp += str.charAt(i);     
		}      
		return str; 
}
function comiis_video_tipbox(a){
	if (typeof popup == "undefined") { 
		showDialog(a, 'right');
		hideWindow('comiis_up_video_box');
	}else{
		popup.open(a, 'alert');
	}
}

