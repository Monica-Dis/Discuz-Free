<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function comiis_video($a)
{
	global $_G;
	if ($_G['comiis_video'] == 1) {
		if ($a[1] == 'flash') {
			list(, $comiis_w, $comiis_h) = explode(',', $a[2]);
		} else {
			list(, $comiis_w, $comiis_h) = explode(',', $a[2]);
		}
	}
	if (!$comiis_w || !$comiis_h || $comiis_w > 1500 || $comiis_h > 1500) {
		$comiis_w = 500;
		$comiis_h = 375;
	}
	$iframe_src = '';
	$url = $a['3'];
	$plugin_id = 'comiis_app_video';
	$comiis_md5file = $comiis_system_config = $comiis_info = array();
	loadcache('plugin');
	if ($_G['cache']['plugin']['comiis_app_video']['comiis_miniProgram_video'] == 2 && (strpos($_SERVER['HTTP_USER_AGENT'], 'miniProgram') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'miniprogram') !== false)) {
		if (strpos($a[0], '[attach') !== false) {
			if (is_array($_G['comiis_video_attach'][$a[3]])) {
				$info = pathinfo($_G['comiis_video_attach'][$a[3]]['filename']);
				$info['extension'] = strtolower($info['extension']);
				if (in_array($info['extension'], array('mp4', 'ogv', 'webm', 'mp3', 'ogg', 'wav'))) {
					return '<div id="comiis_video_copy_btn" data-clipboard-text=""><img src="source/plugin/comiis_app_video/static/' . ($a['1'] == 'audio' ? 'no_audio' : 'no_video') . '.png"></div>';
				}
			}
		} else {
			return '<div id="comiis_video_copy_btn" data-clipboard-text=""><img src="source/plugin/comiis_app_video/static/' . ($a['1'] == 'audio' ? 'no_audio' : 'no_video') . '.png"></div>';
		}
	}
	$match = array();
	if ($a['1'] == 'audio') {
		if (strpos($url, 'attach://') !== false) {
			if (preg_match('/attach:\\/\\/(.*?)\\./i', $url, $matches)) {
				$aid = intval($matches[1]);
				if (is_array($_G['comiis_video_attach'][$aid]) && $_G['comiis_video_attach'][$aid]['isimage'] == 0) {
					$_G['comiis_video_attach_aid'][$aid] = $aid;
					$url = ($_G['comiis_video_attach'][$aid]['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']) . 'forum/' . $_G['comiis_video_attach'][$aid]['attachment'];
				}
			}
		}
		return '<audio ' . ($_G['comiis_video'] == 1 ? 'style="width:500px"' : 'style="width:100%"') . ' src="' . $url . '" controls="controls"></audio>';
	}
	$exp = pathinfo($url);
	$iframe_src = '';
	if (strpos($url, 'attach://') !== false) {
		if (preg_match('/attach:\\/\\/(.*?)\\./i', $url, $matches)) {
			$aid = intval($matches[1]);
			if (is_array($_G['comiis_video_attach'][$aid]) && $_G['comiis_video_attach'][$aid]['isimage'] == 0) {
				$_G['comiis_video_attach_aid'][$aid] = $aid;
				$url = ($_G['comiis_video_attach'][$aid]['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']) . 'forum/' . $_G['comiis_video_attach'][$aid]['attachment'];
			}
			return '<video src="' . $url . '" controls="controls" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></video>';
		}
	} else {
		if (is_array($_G['comiis_video_attach'][$url])) {
			$aid = intval($url);
			$info = pathinfo($_G['comiis_video_attach'][$aid]['filename']);
			$info['extension'] = strtolower($info['extension']);
			if (is_array($_G['comiis_video_attach'][$aid]) && $_G['comiis_video_attach'][$aid]['isimage'] == 0 && in_array($info['extension'], array('mp4', 'ogv', 'webm', 'mp3', 'ogg', 'wav'))) {
				$urls = ($_G['comiis_video_attach'][$aid]['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']) . 'forum/' . $_G['comiis_video_attach'][$aid]['attachment'];
				if (in_array($info['extension'], array('mp4', 'ogv', 'webm'))) {
					return '<video src="' . $urls . '" controls="controls" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:500px;height:375px"' : '') . '></video>';
				}
				if (in_array($info['extension'], array('mp3', 'ogg', 'wav'))) {
					return '<audio ' . ($_G['comiis_video'] == 1 ? 'style="width:500px"' : 'style="width:100%"') . ' src="' . $urls . '" controls="controls"></audio>';
				}
			} else {
				return '[attach]' . $url . '[/attach]';
			}
		} else {
			if (intval($url) === $url) {
				return '[attach]' . $url . '[/attach]';
			}
			if (in_array(strtolower($exp['extension']), array('mp4', 'ogv', 'webm'))) {
				return '<video src="' . $url . '" controls="controls" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></video>';
			}
		}
	}
	if ($_G['cache']['plugin']['comiis_app_video']['comiis_miniProgram_video'] == 1 && (strpos($_SERVER['HTTP_USER_AGENT'], 'miniProgram') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'miniprogram') !== false)) {
		return '<div id="comiis_video_copy_btn" data-clipboard-text=""><img src="source/plugin/comiis_app_video/static/' . ($a['1'] == 'audio' ? 'no_audio' : 'no_video') . '.png"></div>';
	}
	if (strpos($url, 'qiyi.com') !== false) {
		if (strpos($url, 'player_js/coopPlayerIndex.html') !== false) {
			$iframe_src = $url;
		} elseif (preg_match('/\\.com\\/([^\\/|]*)\\/.*-tvId=(.*)-isPurchase/i', $url, $matches)) {
			$iframe_src = '//open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid=' . $matches[1] . '&tvId=' . $matches[2] . '&accessToken=2.ef9c39d6c7f1d5b44768e38e5243157d&appKey=8c634248790d4343bcae1f66129c1010&appId=1368';
		} elseif (preg_match('/vid=([a-zA-Z0-9]+).*tvId=([0-9]+)/i', $url, $matches)) {
			$iframe_src = '//open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid=' . $matches[1] . '&tvId=' . $matches[2] . '&accessToken=2.ef9c39d6c7f1d5b44768e38e5243157d&appKey=8c634248790d4343bcae1f66129c1010&appId=1368';
		} elseif (strpos($url, 'iqiyi.com/v_') !== false) {
			$return = comiis_video_get_cache($url);
			if (!$return) {
				$api = dfsockopen($url);
				if (!empty($api) && preg_match_all('/[\'|.](t)?vid(\'\\])? = "([a-zA-Z0-9-]+)";/i', $api, $matches)) {
					$iframe_src = '//open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid=' . $matches[3][1] . '&tvId=' . $matches[3][0] . '&accessToken=2.ef9c39d6c7f1d5b44768e38e5243157d&appKey=8c634248790d4343bcae1f66129c1010&appId=1368';
					comiis_video_set_cache($url, $iframe_src);
				}
			} else {
				$iframe_src = $return;
			}
		}
		if ($iframe_src) {
			return '<iframe src="' . $iframe_src . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
	} elseif (strpos($url, 'ixigua.com') !== false) {
		if (preg_match('/ixigua\\.com\\/([a-zA-Z0-9]+)/i', $url, $matches)) {
			return '<iframe src="https://www.ixigua.com/iframe/' . $matches[1] . '?autoplay=0" frameborder="0" allowfullscreen="true" referrerpolicy="unsafe-url" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
		if (preg_match('/ixigua\\.com\\/(video\\/|i)?(\\d+)/i', $url, $matches)) {
			return '<iframe src="https://www.ixigua.com/iframe/' . $matches[2] . '?autoplay=0" frameborder="0" allowfullscreen="true" referrerpolicy="unsafe-url" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
		if (preg_match('/ixigua\\.com\\/embed\\?group_id=?(\\d+)/i', $url, $matches)) {
			return '<iframe src="https://www.ixigua.com/iframe/' . $matches[1] . '?autoplay=0" frameborder="0" allowfullscreen="true" referrerpolicy="unsafe-url" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
	} elseif (strpos($url, 'video.sina.com.cn') !== false) {
		if (preg_match('/\\/share\\/video\\/(\\d+)\\.swf/i', $url, $matches)) {
			$url = 'https://video.sina.com.cn/view/' . $matches[1] . '.html';
		}
		$return = comiis_video_get_cache($url);
		if (!$return) {
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0');
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			$output = curl_exec($ch);
			curl_close($ch);
			preg_match('/vid:(\\d+),/', $output, $data);
			if ($data[1]) {
				$aa = 'https://ask.ivideo.sina.com.cn/v_play_ipad.php?vid=' . $data[1];
				comiis_video_set_cache($url, $aa);
				return '<iframe src="' . $aa . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
			}
		} else {
			return '<iframe src="' . $return . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
	} elseif (strpos($url, 'weibo.com') !== false) {
		if (preg_match('/weibo\\.com\\/tv\\/show\\/(\\d+:\\d+)/i', $url, $matches)) {
			$return = comiis_video_get_cache($url);
			if (!$return) {
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0');
				curl_setopt($ch, CURLOPT_URL, 'https://m.weibo.cn/s/video/object?object_id=' . $matches[1]);
				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
				$output = curl_exec($ch);
				curl_close($ch);
				$output = json_decode($output, true);
				if ($output['data']['object']['stream']['hd_url']) {
					comiis_video_set_cache($url, $output['data']['object']['stream']['hd_url']);
					return '<video class="comiis_video comiis_no_width" controls name="media" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '><source src=' . $output['data']['object']['stream']['hd_url'] . ' type="video/mp4"></source></video>';
				}
			} else {
				return '<video class="comiis_video comiis_no_width" controls name="media" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '><source src=' . $return . ' type="video/mp4"></source></video>';
			}
		}
	} elseif (strpos($url, 'acfun.cn') !== false || strpos($url, 'aixifan.com') !== false) {
		if (preg_match('/[acfun\\.cn|aixifan\\.com]\\/v\\/(\\w+)/i', $url, $matches)) {
			return '<iframe src="https://www.acfun.cn/player/' . $matches[1] . '?autoplay=0" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
		if (preg_match('/m.acfun.cn\\/v\\/\\?ac=(\\d+)/i', $url, $matches)) {
			return '<iframe src="https://www.acfun.cn/player/ac' . $matches[1] . '?autoplay=0" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
		if (preg_match('/cdn.aixifan.com\\/player\\/[^\\?]+\\.swf\\?vid=(\\d+)/i', $url, $matches)) {
			return '<iframe src="https://www.acfun.cn/player/ac' . $matches[1] . '?autoplay=0" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
	} elseif (strpos($url, 'tudou.com') !== false) {
		if (preg_match('/\\/v_show\\/id_(\\w+)==\\.html/i', $url, $match)) {
			return '<iframe src="https://player.youku.com/embed/' . $match[1] . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
		if (preg_match('/\\/v\\/([^\\/]+)\\.html/i', $url, $match)) {
			return '<iframe src="https://player.youku.com/embed/' . $match[1] . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
	} elseif (strpos($url, 'youku.com') !== false) {
		if (preg_match('/(\\/sid\\/|\\/id_)([^\\/]+)(\\/v\\.swf|\\.html)/i', $url, $match)) {
			$iframe_src = 'https://player.youku.com/embed/' . $match[2];
		} elseif (preg_match('/\\/embed\\/([^\\/]+)==/i', $url, $match)) {
			$iframe_src = 'https://player.youku.com/embed/' . $match[1] . '==';
		}
		if ($iframe_src) {
			return '<iframe src="' . $iframe_src . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
	} elseif (strpos($url, 'qq.com') !== false) {
		if (strpos($url, 'v.qq.com/iframe/player.html?vid=') !== false) {
			$iframe_src = $url;
		} else {
			if (preg_match('/vid=(.*?)(&|$)/i', $url, $matches)) {
				$iframe_src = 'https://v.qq.com/txp/iframe/player.html?vid=' . $matches[1] . '&auto=0';
			} else {
				if (strpos($url, 'v.qq.com/x/cover/') !== false || strpos($url, 'v.qq.com/x/page/') !== false) {
					$url_array = array_filter(explode('/', $url));
					$iframe_src = array_filter(explode('.html', $url_array[count($url_array)]));
					$iframe_src = $iframe_src[0];
					$iframe_src = 'https://v.qq.com/txp/iframe/player.html?vid=' . $iframe_src . '&auto=0';
				}
			}
		}
		if ($iframe_src) {
			return '<iframe src="' . $iframe_src . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
	} elseif (strpos($url, 'sohu.com') !== false) {
		if (preg_match('/(share\\.vrs\\.sohu\\.com\\/|share_play\\.html#|\\&id=|&amp;id=|\\/us\\/[0-9]+\\/)([0-9]+)(\\/v\\.swf|_|&amp;|\\.shtml)/i', $url, $matches)) {
			$iframe_src = 'https://tv.sohu.com/s/sohuplayer/iplay.html?vid=' . $matches[2];
		} else {
			if (strpos($url, '.shtml') !== false) {
				$return = comiis_video_get_cache($url);
				if (!$return) {
					$api = dfsockopen($url);
					if (!empty($api) && preg_match('/var vid="([0-9]+)";/i', $api, $matches)) {
						$iframe_src = 'https://tv.sohu.com/s/sohuplayer/iplay.html?vid=' . $matches[1];
						comiis_video_set_cache($url, $iframe_src);
					}
				} else {
					$iframe_src = $return;
				}
			}
		}
		if ($iframe_src) {
			return '<iframe src="' . $iframe_src . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
	} elseif (strpos($url, 'douyu.com') !== false) {
		if (preg_match('/(douyu.com\\/show\\/|vid\\=)(\\w+)/i', $url, $match)) {
			return '<iframe src="https://v.douyu.com/video/videoshare/index?vid=' . $match[2] . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
	} elseif (strpos($url, 'bilibili.com') !== false) {
		if (preg_match('/video\\/(BV\\w+|av\\d+)/i', $url, $matches)) {
			return '<iframe src="//player.bilibili.com/player.html?' . (substr($matches[1], 0, 2) == 'BV' ? 'bvid=' . $matches[1] : 'aid=' . str_replace('av', '', $matches[1])) . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
	} elseif (strpos($url, 'miaopai.com') !== false) {
		if (preg_match('/show\\/(.*?)\\.htm/i', $url, $matches)) {
			return '<video src="https://gslb.miaopai.com/stream/' . $matches[1] . '.mp4" controls="controls" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></video>';
		}
	} elseif (strpos($url, 'wasu.cn/Play/') !== false) {
		if (preg_match('/\\/id\\/(.*)$/i', $url, $matches)) {
			$iframe_src = 'https://www.wasu.cn/Play/iframe/id/' . $matches[1] . '&auto=0';
			return '<iframe src="' . $iframe_src . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
	} elseif (strpos($url, 'ifeng.com') !== false) {
		$return = comiis_video_get_cache($url);
		if (!$return) {
			if (preg_match('/[\\/|#|guid=]([a-zA-Z0-9\\-]{36})/i', $url, $matches)) {
				$api = dfsockopen('https://vxml.ifengimg.com/video_info_new/' . substr($matches[1], 0 - 2, 1) . '/' . substr($matches[1], 0 - 2) . '/' . $matches[1] . '.xml');
				if (!empty($api) && preg_match('/Name="(.+?)"(.+)BigPosterUrl="(.+?)"(?:.+)VideoPlayUrl="(.+?)" PlayerUrl="(.+?)"/i', $api, $matches)) {
					$iframe_src = str_replace('http://', 'https://', $matches[4]);
					comiis_video_set_cache($url, $iframe_src);
					return '<video class="comiis_video comiis_no_width" controls name="media" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '><source src=' . $iframe_src . ' type="video/mp4"></source></video>';
				}
				$api = dfsockopen('https://v.ifeng.com/video_info_new/' . substr($matches[1], 0 - 2, 1) . '/' . substr($matches[1], 0 - 2) . '/' . $matches[1] . '.xml');
				if (!empty($api) && preg_match('/Name="(.+?)"(.+)BigPosterUrl="(.+?)"(?:.+)VideoPlayUrl="(.+?)" PlayerUrl="(.+?)"/i', $api, $matches)) {
					$iframe_src = str_replace('http://', 'https://', $matches[4]);
					comiis_video_set_cache($url, $iframe_src);
					return '<video class="comiis_video comiis_no_width" controls name="media" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '><source src=' . $iframe_src . ' type="video/mp4"></source></video>';
				}
			} else {
				if (strpos($url, '.shtml') !== false) {
					$api = dfsockopen($url);
					if (!empty($api) && preg_match('/"vid": "([a-zA-Z0-9\\-]{36})",/i', $api, $matches)) {
						$api = dfsockopen('https://vxml.ifengimg.com/video_info_new/' . substr($matches[1], 0 - 2, 1) . '/' . substr($matches[1], 0 - 2) . '/' . $matches[1] . '.xml');
						if (!empty($api) && preg_match('/Name="(.+?)"(.+)BigPosterUrl="(.+?)"(?:.+)VideoPlayUrl="(.+?)" PlayerUrl="(.+?)"/i', $api, $matches)) {
							$iframe_src = str_replace('http://', 'https://', $matches[4]);
							comiis_video_set_cache($url, $iframe_src);
							return '<video class="comiis_video comiis_no_width" controls name="media" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '><source src=' . $iframe_src . ' type="video/mp4"></source></video>';
						}
					}
				}
			}
		} else {
			return '<video class="comiis_video comiis_no_width" controls name="media" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '><source src=' . $return . ' type="video/mp4"></source></video>';
		}
	} elseif (strpos($url, 'static.hdslb.com/miniloader.swf?aid=') !== false) {
		if (preg_match('/aid=([0-9]+)&/i', $url, $matches)) {
			$return = comiis_video_get_cache($url);
			if (!$return) {
				$purl_token = 'bilibili_' . TIMESTAMP;
				$token = md5($purl_token);
				$api = dfsockopen('https://api.bilibili.com/playurl?callback=callbackfunction&aid=' . $matches[1] . '&page=1&platform=html5&quality=1&vtype=mp4&type=json&token=' . $token, '', '', 'purl_token=' . $purl_token . ';');
				$data = json_decode($api, true);
				if ($data['durl']['0']['url']) {
					$iframe_src = str_replace('http://', 'https://', $data['durl']['0']['url']);
					comiis_video_set_cache($url, $iframe_src);
					return '<video src="' . $iframe_src . '" controls="controls" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></video>';
				}
			} else {
				return '<video src="' . $return . '" controls="controls" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></video>';
			}
		}
	} elseif (strpos($url, 'meipai.com') !== false) {
		$return = comiis_video_get_cache($url);
		if (!$return) {
			$api = dfsockopen($url);
			if (preg_match('/data-video="(.*?)"/i', $api, $matches)) {
				$datavideo = $matches[1];
				$b = comiis_getHex($datavideo);
				$c = comiis_getDec($b['hex']);
				$d = comiis_dsubstr($b['str'], $c['pre']);
				$mp4Url = base64_decode(comiis_dsubstr($d, comiis_getPos($d, $c['tail'])));
				if ($mp4Url) {
					$meipaiarray = array_filter(explode('?', $mp4Url));
					$return = str_replace('http://', 'https://', $meipaiarray[0]);
					comiis_video_set_cache($url, $return);
					return '<video src="' . $return . '" controls="controls" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></video>';
				}
			}
		} else {
			return '<video src="' . $return . '" controls="controls" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></video>';
		}
	} elseif (strpos($url, 'youtube.') !== false || strpos($url, 'youtu.be') !== false) {
		if (preg_match('/(v=|embed\\/)([a-zA-Z0-9-_]+)/i', $url, $match)) {
			return '<iframe src="https://www.youtube.com/embed/' . $match[2] . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
		}
	} elseif (strpos($url, 'ku6.com') !== false) {
		$return = comiis_video_get_cache($url);
		if (!$return) {
			$api = dfsockopen($url);
			if (preg_match('/flvURL: "(.*?)",/i', $api, $matches)) {
				comiis_video_set_cache($url, $matches[1]);
				return '<video src="' . $matches[1] . '" controls="controls" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></video>';
			}
		} else {
			return '<video src="' . $return . '" controls="controls" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></video>';
		}
	}
	if ($_G['comiis_video'] == 1) {
		return $a[0];
	}
	$return = comiis_video_get_cache($url);
	if (!$return) {
		if (strpos($url, 'player.hoge.cn') !== false) {
			if (preg_match('/video=([0-9]+)&.+extendParam=([0-9]+)&/i', $url, $matches)) {
				$api = dfsockopen('http://www.grtn.cn/m2o/player/video.php?extend=' . $matches[2] . '&id=' . $matches[1]);
				if (!empty($api) && preg_match('/<video url="(.*?)"\\/>/i', $api, $matches)) {
					$api = dfsockopen($matches[1]);
					if (!empty($api)) {
						$data = explode("\n", trim($api));
						$len = count($data) - 2;
						$video = $data[$len];
						if (strpos($video, 'vfile.grtn.cn') !== false && preg_match('/(.*?),(.*?),(.*?)\\.ts/i', $video, $matches)) {
							$return = $matches[1] . ',0,' . ($matches[2] + $matches[3]) . '.ts';
							comiis_video_set_cache($url, $return);
							return '<video class="comiis_video comiis_no_width" controls name="media"><source src="' . $return . '" type="video/mp4" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></source></video>';
						}
					}
				}
			}
		} else {
			if (strpos($url, 'gdtv.cn') !== false || strpos($url, 'grtn.cn') !== false) {
				$api = dfsockopen($url);
				if (!empty($api) && preg_match('/value="(.*?)\\.m3u8"/i', $api, $matches)) {
					$api = dfsockopen($matches[1] . '.m3u8');
					if (!empty($api)) {
						$data = explode("\n", trim($api));
						$len = count($data) - 2;
						$video = $data[$len];
						if (strpos($video, 'vfile.grtn.cn') !== false && preg_match('/(.*?),(.*?),(.*?)\\.ts/i', $video, $matches)) {
							$return = $matches[1] . ',0,' . ($matches[2] + $matches[3]) . '.ts';
							comiis_video_set_cache($url, $return);
							return '<video class="comiis_video comiis_no_width" controls name="media" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '><source src="' . $return . '" type="video/mp4"></source></video>';
						}
					}
				}
			}
		}
	} else {
		return '<video src="' . $return . '" controls="controls" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></video>';
	}
	if ($iframe_src) {
		$return = '<iframe src="' . $iframe_src . '" frameborder="0" allowfullscreen="true" class="comiis_video comiis_no_width" ' . ($_G['comiis_video'] == 1 ? 'style="width:' . $comiis_w . 'px;height:' . $comiis_h . 'px"' : '') . '></iframe>';
	} else {
		if (dstrpos($a[0], '[/attach]') !== false) {
			$return = $a[0];
		} else {
			$return = '<a href="' . $url . '" >[' . $url . ']</a>';
		}
	}
	return $return;
}
function comiis_video_get_cache($url)
{
	$comiis_video_cache_file = md5($url);
	if (file_exists(DISCUZ_ROOT . './source/plugin/comiis_app_video/cache/' . $comiis_video_cache_file . '.txt')) {
		$file_data = implode('', @file(DISCUZ_ROOT . './source/plugin/comiis_app_video/cache/' . $comiis_video_cache_file . '.txt'));
		if ($file_data) {
			return $file_data;
		}
	}
	return false;
}
function comiis_video_set_cache($url, $data)
{
	$comiis_video_cache_file = md5($url);
	if ($fp = fopen(DISCUZ_ROOT . './source/plugin/comiis_app_video/cache/' . $comiis_video_cache_file . '.txt', 'w')) {
		fwrite($fp, $data);
		fclose($fp);
	} else {
		exit('Can not write to cache files, please check directory ./source/plugin/comiis_app_video/cache/ .');
	}
}
function comiis_getHex($str)
{
	$return = array();
	$return['str'] = substr($str, 4);
	$hex = array_reverse(str_split(substr($str, 0, 4)));
	$return['hex'] = implode('', $hex);
	return $return;
}
function comiis_getDec($hex)
{
	$str = (string) intval($hex, 16);
	$return = array();
	$return['pre'] = str_split(substr($str, 0, 2));
	$return['tail'] = str_split(substr($str, 2));
	return $return;
}
function comiis_dsubstr($str, $pre)
{
	$f = substr($str, 0, $pre[0]);
	$g = substr($str, $pre[0], $pre[1]);
	return $f . str_replace($g, '', substr($str, $pre[0]));
}
function comiis_getPos($str, $tail)
{
	$tail[0] = strlen($str) - $tail[0] - $tail[1];
	return $tail;
}
function comiis_discuzcode($data, $param)
{
	global $_G;
	if (defined('IN_MOBILE') && ($_G['cache']['plugin']['comiis_app_video']['comiis_group'] && $_G['cache']['plugin']['comiis_app_video']['comiis_group_video'] && $_G['forum_thread']['isgroup'] || in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_view_video'])))) {
		if ($param['param'][15] == 1 && preg_match('/\\[(media|flash|attach)\\=?([\\w,]*)\\]\\s*(.*?)\\s*\\[\\/(media|flash|attach)\\]/i', $data, $matches)) {
			$comiis_get_view = comiis_video($matches);
			$comiis_get_ex = substr($comiis_get_view, 0, 3);
			if ($comiis_get_ex == '<vi' || $comiis_get_ex == '<if') {
				$data = str_replace($matches[0], '', $data);
				$_G['setting']['pluginhooks']['viewthread_top_mobile'] = ($_G['cache']['plugin']['comiis_app_video']['comiis_view_video_top'] == 1 ? '<div class="comiis_video_height"><div class="comiis_scrollTop_box"><div class="comiis_video_views">' . $comiis_get_view . '</div></div></div>' : '<div class="comiis_video_views">' . $comiis_get_view . '</div>') . $_G['setting']['pluginhooks']['viewthread_top_mobile'];
			}
		}
	}
	return preg_replace_callback('/\\[(media|flash|audio|attach)\\=?([\\w,]*)\\]\\s*(.*?)\\s*\\[\\/(media|flash|audio|attach)\\]/', 'comiis_video', $data);
}
function _comiis_forumdisplay_video_list()
{
	global $_G;
	$comiis_return = $comiis_tids = array();
	if (count($_G['forum_threadlist'])) {
		if (!function_exists('array_column')) {
			foreach ($_G['forum_threadlist'] as $thread) {
				$comiis_tids[] = $thread['tid'];
			}
		} else {
			$comiis_tids = array_column($_G['forum_threadlist'], 'tid');
		}
		$message = DB::fetch_all('SELECT tid, message, pid FROM %t WHERE tid IN (' . dimplode($comiis_tids) . ') AND first=1', array('forum_post'), 'tid');
		foreach ($message as $temp) {
			$comiis_picid_array[getattachtableid($temp['tid'])][] = $temp['pid'];
		}
		foreach ($comiis_picid_array as $tableid => $pids) {
			if ($tableid >= 0 && $tableid < 10) {
				$query = DB::query('SELECT * FROM `' . DB::table('forum_attachment_' . intval($tableid)) . '` WHERE pid IN (' . dimplode($pids) . ') AND isimage=\'0\'');
				while ($temp = DB::fetch($query)) {
					$_G['comiis_video_attach'][$temp['aid']] = $temp;
				}
			}
		}
		foreach ($_G['forum_threadlist'] as $thread) {
			if (dstrpos($message[$thread['tid']]['message'], array('[/media]', '[/flash]', '[/audio]', '[/attach]')) !== false) {
				$is_video_post = 0;
				if (preg_match('/\\[(media|flash|audio)\\=?([\\w,]*)\\]\\s*(.*?)\\s*\\[\\/(media|flash|audio)\\]/i', $message[$thread['tid']]['message'], $matches)) {
					$is_video_post = 1;
				} elseif (preg_match('/\\[attach\\=?([\\w,]*)\\]\\s*(.*?)\\s*\\[\\/attach\\]/i', $message[$thread['tid']]['message'], $matches)) {
					$is_video_post = 1;
				}
				if ($is_video_post == 1) {
					$comiis_get_view = comiis_video($matches);
					$comiis_get_ex = substr($comiis_get_view, 0, 3);
					if ($comiis_get_ex != '<a ') {
						if ($comiis_get_ex == '<au') {
							if ($_G['is_comiis_portal'] == 1 || in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_forum_audio'])) || ($_G['forum_thread']['isgroup'] || $_G['basescript'] == 'group') && $_G['cache']['plugin']['comiis_app_video']['comiis_group_list_audio']) {
								$comiis_return[] = '<div class="comiis_audio_list">' . $comiis_get_view . '</div>';
							} else {
								$comiis_return[] = '';
							}
						} else {
							if ($comiis_get_ex == '<vi' || $comiis_get_ex == '<if') {
								if ($_G['is_comiis_portal'] == 1 || in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_forum_video'])) || ($_G['forum_thread']['isgroup'] || $_G['basescript'] == 'group') && $_G['cache']['plugin']['comiis_app_video']['comiis_group_list']) {
									$comiis_return[] = '<div class="comiis_video_list">' . $comiis_get_view . '</div><script>comiis_setvideowidth();</script>';
								}
							} else {
								$comiis_return[] = '';
							}
						}
					} else {
						$comiis_return[] = '';
					}
				} else {
					$comiis_return[] = '';
				}
			} else {
				$comiis_return[] = '';
			}
		}
	}
	return $comiis_return;
}
function _comiis_getyoukukey($up = 0)
{
	global $_G;
	$comiis_youku_token = array();
	if (!$_G['cache']['plugin']['comiis_app_video']['refresh_token'] || !$_G['cache']['plugin']['comiis_app_video']['access_token']) {
		return NULL;
	}
	$md5 = md5($_G['cache']['plugin']['comiis_app_video']['refresh_token'] . $_G['cache']['plugin']['comiis_app_video']['access_token']);
	if (file_exists(DISCUZ_ROOT . './source/plugin/comiis_app_video/cache/token.php')) {
		include DISCUZ_ROOT . './source/plugin/comiis_app_video/cache/token.php';
	}
	if ($comiis_youku_token['md5'] != $md5 || $comiis_youku_token['timeout'] < time()) {
		$up = 1;
	}
	if ($up == 1) {
		$re_data = _comiis_load_youku('https://api.youku.com/oauth2/token.json', array('client_id' => $_G['cache']['plugin']['comiis_app_video']['clientid'], 'grant_type' => 'refresh_token', 'refresh_token' => $_G['cache']['plugin']['comiis_app_video']['refresh_token']));
		$re_data = (array) $re_data;
		if ($re_data['token_type'] == 'bearer') {
			$comiis_youku_token = array('refresh_token' => $re_data['refresh_token'], 'access_token' => $re_data['access_token']);
			$video_plugin_id = C::t('common_plugin')->fetch_by_identifier('comiis_app_video');
			if ($video_plugin_id['pluginid']) {
				C::t('common_pluginvar')->update_by_variable($video_plugin_id['pluginid'], 'access_token', array('value' => $comiis_youku_token['access_token']));
				C::t('common_pluginvar')->update_by_variable($video_plugin_id['pluginid'], 'refresh_token', array('value' => $comiis_youku_token['refresh_token']));
			}
			if ($fp = @fopen(DISCUZ_ROOT . './source/plugin/comiis_app_video/cache/token.php', 'wb')) {
				fwrite($fp, '<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined(\'IN_DISCUZ\')){exit(\'Access Denied\');}
$comiis_youku_token = array(\'refresh_token\'=>\'' . $comiis_youku_token['refresh_token'] . '\', \'access_token\'=>\'' . $comiis_youku_token['access_token'] . '\', \'timeout\'=>' . (time() + 86400) . ', \'md5\'=>\'' . md5($re_data['refresh_token'] . $re_data['access_token']) . '\');');
				fclose($fp);
			} else {
				exit('Can not write to cache files! please check directory ./source/plugin/comiis_app_video/cache/ .');
			}
		}
	}
	return $comiis_youku_token['access_token'] ? $comiis_youku_token['access_token'] : $_G['cache']['plugin']['comiis_app_video']['access_token'];
}
function _comiis_load_youku($url, $post)
{
	$ch = curl_init();
	if ($post) {
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
	}
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$result = curl_exec($ch);
	return json_decode($result);
}