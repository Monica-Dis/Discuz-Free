<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class mobileplugin_comiis_app_video{
	function discuzcode($param){
		global $_G, $pid;
		if($param['caller'] == 'discuzcode'){
			if(($_G['forum_thread']['isgroup'] || ($_G['basescript']=='forum' && CURMODULE=='viewthread')) && dstrpos($_G['discuzcodemessage'], array('[/img]')) !== FALSE){
				if(preg_match_all("/\[img\=?([\w,]*)\]\s*(.*?)\s*\[\/img\]/is", $_G['discuzcodemessage'], $matches)) {
					foreach($matches[2] as $key => $img){
						$_G['discuzcodemessage'] = str_replace($matches[0][$key], '<img src="'.$matches[2][$key].'" style="max-width:100%" />', $_G['discuzcodemessage']); 
					}
				}
			}
			if(($_G['forum_thread']['isgroup'] && $_G['cache']['plugin']['comiis_app_video']['comiis_group']) || ($_G['basescript']=='forum' && CURMODULE=='viewthread' && in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_forum'])))){
				if(dstrpos($_G['discuzcodemessage'], array('[/media]', '[/flash]', '[/audio]', '[/attach]')) !== FALSE){
					$_G['comiis_video_attach'] = C::t('forum_attachment_n')->fetch_all_by_id(getattachtableid($_G['tid']), 'pid', $pid);
					include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/comiis_app_video.fun.php';
					$_G['discuzcodemessage'] = comiis_discuzcode($_G['discuzcodemessage'], $param);
				}
			}
		}
	}
	function global_comiis_var(){
		global $_G, $postlist;
		foreach($postlist as $key => $temp){
			foreach($_G['comiis_video_attach_aid'] as $keys => $temps){
				if(is_array($postlist[$key]['attachments'][$keys])){
					unset($postlist[$key]['attachments'][$keys]);
				}
			}
		}
	}
	function global_header_mobile(){
		global $_G;
		if($_GET['mod'] == 'guide' || $_GET['id'] == 'comiis_app_portal' || $_G['is_comiis_portal'] == 1 || $_GET['pid'] || (($_G['forum_thread']['isgroup'] || $_G['basescript'] == 'group') && ($_G['cache']['plugin']['comiis_app_video']['comiis_group'] || $_G['cache']['plugin']['comiis_app_video']['comiis_group_list'])) || ($_G['basescript']=='forum' && CURMODULE=='viewthread' && in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_forum']))) || ($_G['basescript']=='forum' && CURMODULE=='forumdisplay' && in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_forum_video']))) || ($_G['basescript']=='home' && CURMODULE=='space' && $_G['cache']['plugin']['comiis_app_video']['comiis_blog']) || ($_G['basescript']=='portal' && CURMODULE=='view' && $_G['cache']['plugin']['comiis_app_video']['comiis_portal'])){
			return '<style>.comiis_video{width:100%;height:100%;}</style>
			<script>    
			var comiis_document_log_height = 0;
			$(function(){
				comiis_set_width();
				$(window).scroll(function() {
					if($(document).height() != comiis_document_log_height){
						comiis_document_log_height = $(document).height();
						comiis_set_width();
					}
				});
			});
			function comiis_set_width(){
				$(".comiis_no_width").each(function(){
					var comiis_tempheight = $(this).width() / parseFloat("'.$_G['cache']['plugin']['comiis_app_video']['comiis_scale'].'");
					$(this).css("height", (comiis_tempheight > $(this).width() ? $(this).width() : comiis_tempheight)).removeClass("comiis_no_width");
					'.(($_G['basescript']=='forum' && CURMODULE=='viewthread') ? '$(".comiis_video_height").css("height", $(window).width() / parseFloat("'.$_G['cache']['plugin']['comiis_app_video']['comiis_scale'].'"));' : '').'
				});		
			}
			function comiis_setvideowidth(){
				comiis_set_width();
			}
			comiis_set_width();
			</script>
			';
		}
	}
	function global_footer_mobile(){
		if(strpos($_SERVER['HTTP_USER_AGENT'], 'miniProgram') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'miniprogram') !== false){
			include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/language/language.'.currentlang().'.php';
			$return = '<script>
				if(document.getElementById(\'comiis_video_copy_btn\')){
					$(\'#comiis_video_copy_btn\').attr("data-clipboard-text", window.location.href);
					function comiis_video_copyurl(){
						var btn = document.getElementById(\'comiis_video_copy_btn\');
						var clipboard = new ClipboardJS(btn);
						clipboard.on(\'success\', function(e) {
							popup.open(\''.$comiis_app_video_lang['020'].'\', \'alerts\');
						});
						clipboard.on(\'error\', function(e) {
							popup.open(\''.$comiis_app_video_lang['021'].'\', \'alerts\');
						});
					}
					if(typeof(ClipboardJS) == \'undefined\') {
						$.getScript("./source/plugin/comiis_app_video/static/clipboard.min.js").done(function(){
							comiis_video_copyurl();
						});
					}else{
						comiis_video_copyurl();
					}
				}
				</script>';
		}
		return $return. '<script>setTimeout(function(){jQuery.ajax({type:\'GET\', url: \'./plugin.php?id=comiis_app_video:comiis_app_video_up\', dataType:\'html\'});}, 3000);</script>';
	}
  function global_comiis_forumdisplay_list_bottom(){
		global $_G;
		if(($_G['basescript'] == 'plugin' && CURMODULE=='comiis_app_portal') || ($_G['basescript']=='forum' || $_G['basescript'] == 'group') && CURMODULE=='forumdisplay' && $_G['style']['directory'] == './template/comiis_app' && (in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_forum_audio'])) || in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_forum_video'])) || (($_G['basescript'] == 'group' && $_G['cache']['plugin']['comiis_app_video']['comiis_group_list']) || ($_G['basescript'] == 'group' && $_G['cache']['plugin']['comiis_app_video']['comiis_group_list_audio'])))){
			include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/comiis_app_video.fun.php';
			return _comiis_forumdisplay_video_list();
		}
	}
	function global_comiis_video_box(){
		global $_G;
		if($_G['style']['directory'] == './template/comiis_app' && ($_G['basescript'] == 'forum' || $_G['basescript'] == 'group') && CURMODULE == 'post'){
			$users = unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_upload_group']);
			if(isset($users[0]) && ($users[0] == '0' || $users[0] == '')){
				unset($users[0]);
			}
			if(($_G['basescript'] == 'group' && $_G['cache']['plugin']['comiis_app_video']['comiis_group_uploadvideo']) || in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_upload_video'])) && count($users) && in_array($_G['member']['groupid'], $users)){
			
				$uptype = intval($_G['cache']['plugin']['comiis_app_video']['uptype']);
				if($uptype){
					include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/comiis_app_video.fun.php';
					$_G['comiis_video_is_comiis'] = 1;
					$_G['comiis_video_access_token'] = _comiis_getyoukukey();
					include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/language/language.'.currentlang().'.php';
					include template('comiis_app_video:hook');
					return $html;
				}
			}
		}
	}
}
class mobileplugin_comiis_app_video_forum extends mobileplugin_comiis_app_video{
    function viewthread_postbottom_mobile(){
		global $_G;
		if($_G['is_comiis_portal'] == 1 || (($_G['forum_thread']['isgroup'] || $_G['basescript'] == 'group') && ($_G['cache']['plugin']['comiis_app_video']['comiis_group'] || $_G['cache']['plugin']['comiis_app_video']['comiis_group_list'])) || ($_G['basescript']=='forum' && CURMODULE=='viewthread' && in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_forum']))) || ($_G['basescript']=='forum' && CURMODULE=='forumdisplay' && in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_forum_video'])))){
			$re_js = '<script>comiis_set_width();</script>';
			return array($re_js, $re_js, $re_js, $re_js, $re_js);
		}
	}
    function forumdisplay_thread_mobile_output(){
		global $_G;
		if($_G['basescript']=='forum' && CURMODULE=='forumdisplay' && $_G['style']['directory'] != './template/comiis_app' && (in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_forum_audio'])) || in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_forum_video'])) || ($_G['forum_thread']['isgroup'] && ($_G['cache']['plugin']['comiis_app_video']['comiis_group_list'] || $_G['cache']['plugin']['comiis_app_video']['comiis_group_list_audio'])))){
			include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/comiis_app_video.fun.php';
			return _comiis_forumdisplay_video_list();
		}
	}
	function post_bottom_mobile_output(){
		global $_G;
		if($_G['style']['directory'] != './template/comiis_app'){
			$users = unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_upload_group']);
			if(isset($users[0]) && ($users[0] == '0' || $users[0] == '')){
				unset($users[0]);
			}
			if(($_G['basescript'] == 'group' && $_G['cache']['plugin']['comiis_app_video']['comiis_group_uploadvideo']) || in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_upload_video'])) && count($users) && in_array($_G['member']['groupid'], $users)){
				include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/comiis_app_video.fun.php';
				$_G['comiis_video_is_comiis'] = 0;
				$_G['comiis_video_access_token'] = _comiis_getyoukukey();
				include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/language/language.'.currentlang().'.php';
				include template('comiis_app_video:hook');
				return $html;
			}
		}
	}
}
class mobileplugin_comiis_app_video_portal extends mobileplugin_comiis_app_video {
	public function view_article_output() {
		global $_G, $content;
		if($_G['cache']['plugin']['comiis_app_video']['comiis_portal'] && $content){
			include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/comiis_app_video.fun.php';
			$content['content'] = preg_replace("/<div id=\".*?\" class=\"media\"><div id=\".*? class=\"media_tips\"><a href=\"(.*?)\".*?\"\);<\/script>/i", "[media=x,500,375]\\1[/media]", $content['content']); 
			$content['content'] = preg_replace_callback("/\[(media|flash|audio|attach)\=?([\w,]*)\]\s*(.*?)\s*\[\/(media|flash|audio|attach)\]/", "comiis_video", $content['content']);
			return;
		}
	}	
}
class mobileplugin_comiis_app_video_home extends mobileplugin_comiis_app_video {
	public function space_blog_output() {
		global $_G, $blog;
		if($_G['cache']['plugin']['comiis_app_video']['comiis_blog'] && $blog){
			include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/comiis_app_video.fun.php';
			$blog['message'] = preg_replace("/<div id=\".*?\" class=\"media\"><div id=\".*? class=\"media_tips\"><a href=\"(.*?)\".*?\"\);<\/script>/i", "[media=x,500,375]\\1[/media]", $blog['message']); 
			$blog['message'] = preg_replace_callback("/\[(media|flash|audio|attach)\=?([\w,]*)\]\s*(.*?)\s*\[\/(media|flash|audio|attach)\]/", "comiis_video", $blog['message']);
			return;
		}
	}	
}
