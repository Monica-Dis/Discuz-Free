<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_comiis_app_video{
	function discuzcode($param){
		global $_G, $pid;
		if($param['caller'] == 'discuzcode'){
			if($_G['forum_thread']['isgroup'] || ($_G['basescript']=='forum' && CURMODULE=='viewthread' && in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_forum'])))){
				if(dstrpos($_G['discuzcodemessage'], array('[/media]', '[/flash]', '[/audio]', '[/attach]')) !== FALSE){
					$_G['comiis_video'] = 1;
					$_G['comiis_video_attach'] = C::t('forum_attachment_n')->fetch_all_by_id(getattachtableid($_G['tid']), 'pid', $pid);
					include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/comiis_app_video.fun.php';
					$_G['discuzcodemessage'] = comiis_discuzcode($_G['discuzcodemessage'], $param);
				}
			}
		}
	}
	function global_comiis_var(){
		global $_G, $postlist;
		foreach($postlist as $key => $temp){
			foreach($_G['comiis_video_attach_aid'] as $keys => $temps){
				if(is_array($postlist[$key]['attachments'][$keys])){
					unset($postlist[$key]['attachments'][$keys]);
				}
			}
		}
	}
	function global_header(){
		global $_G;
		if(($_G['basescript']=='forum' || $_G['basescript']=='group') && CURMODULE=='post'){
			return '<script src="./source/plugin/comiis_app_video/static/jquery.min.js"></script><script>jQuery.noConflict();</script>
<script type="text/javascript" src="https://cloud.youku.com/assets/js/browser-md5-file.min.js"></script>
<script type="text/javascript" src="https://gosspublic.alicdn.com/aliyun-oss-sdk-6.1.0.min.js"></script>
<script src="./source/plugin/comiis_app_video/static/cloud-upload.js" charset="utf-8"></script>
';
		}
	}
	function global_footer(){
		return '<script type="text/javascript" src="./plugin.php?id=comiis_app_video:comiis_app_video_up"></script>';
	}
}
class plugin_comiis_app_video_forum extends plugin_comiis_app_video{
    function post_editorctrl_left(){
        global $_G;
		$users = unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_upload_group']);
		if(isset($users[0]) && ($users[0] == '0' || $users[0] == '')){
			unset($users[0]);
		}
		if(($_G['basescript'] == 'group' && $_G['cache']['plugin']['comiis_app_video']['comiis_group_uploadvideo']) || in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_upload_video'])) && count($users) && in_array($_G['member']['groupid'], $users)){
			include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/language/language.'.currentlang().'.php';
			include template('comiis_app_video:comiis_upkey');
			return $html;
		}
    }
}
class plugin_comiis_app_video_group extends plugin_comiis_app_video {
	function post_editorctrl_left(){
        global $_G;
		$users = unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_upload_group']);
		if(isset($users[0]) && ($users[0] == '0' || $users[0] == '')){
			unset($users[0]);
		}
		if(($_G['basescript'] == 'group' && $_G['cache']['plugin']['comiis_app_video']['comiis_group_uploadvideo']) || in_array($_G['fid'], unserialize($_G['cache']['plugin']['comiis_app_video']['comiis_upload_video'])) && count($users) && in_array($_G['member']['groupid'], $users)){
			include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/language/language.'.currentlang().'.php';
			include template('comiis_app_video:comiis_upkey');
			return $html;
		}
	}
}
class plugin_comiis_app_video_portal extends plugin_comiis_app_video {
	public function view_article_content_output() {
		global $_G, $content;
		if($_G['cache']['plugin']['comiis_app_video']['comiis_portal'] && $content){
			$_G['comiis_video'] = 1;
			include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/comiis_app_video.fun.php';
			$content['content'] = preg_replace("/<div id=\".*?\" class=\"media\"><div id=\".*? class=\"media_tips\"><a href=\"(.*?)\".*?\"\);<\/script>/i", "[media=x,500,375]\\1[/media]", $content['content']); 
			$content['content'] = preg_replace_callback("/\[(media|flash|audio|attach)\=?([\w,]*)\]\s*(.*?)\s*\[\/(media|flash|audio|attach)\]/", "comiis_video", $content['content']);
			return;
		}
	}	
}
class plugin_comiis_app_video_home extends plugin_comiis_app_video {
	public function space_blog_title_output() {
		global $_G, $blog;
		if($_G['cache']['plugin']['comiis_app_video']['comiis_blog'] && $blog){
			$_G['comiis_video'] = 1;
			include_once DISCUZ_ROOT.'./source/plugin/comiis_app_video/comiis_app_video.fun.php';
			$blog['message'] = preg_replace("/<div id=\".*?\" class=\"media\"><div id=\".*? class=\"media_tips\"><a href=\"(.*?)\".*?\"\);<\/script>/i", "[media=x,500,375]\\1[/media]", $blog['message']); 
			$blog['message'] = preg_replace_callback("/\[(media|flash|audio|attach)\=?([\w,]*)\]\s*(.*?)\s*\[\/(media|flash|audio|attach)\]/", "comiis_video", $blog['message']);
			return;
		}
	}	
}