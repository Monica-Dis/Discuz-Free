<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ')) {exit('Access Denied');}
$finish = TRUE;
class plugin_comiis_kx {
	function global_footer(){
		global $_G;
		$mysql = $sortadd = $filteradd = '';
		$forum = $list = array();
		$plugindata = $_G['cache']['plugin']['comiis_kx'];
		$plugindata['open'] = 'bmbzg';
		$comiis_kx_retime = intval($plugindata['comiis_kx_retime']);
		$comiis_kx_tidtime = intval($plugindata['comiis_kx_tidtime']);
		if($plugindata['comiis_kx_open'] == 0 || getcookie('comiis_kx_close') || !(($plugindata['comiis_kx_bbsopen'] == 'bbs' && $_G['basescript'] == 'forum') || ($plugindata['comiis_kx_bbsopen'] == 'bbsindex' && $_G['basescript'] == 'forum' && CURMODULE == 'index') || ($plugindata['comiis_kx_bbsopen'] == 'portalindex' && $_G['basescript'] == 'portal' && CURMODULE == 'index') || $plugindata['comiis_kx_bbsopen'] == 'all' || ($plugindata['comiis_kx_bbsopen'] == 'bbsportalindex' && ($_G['basescript'] == 'portal' || $_G['basescript'] == 'forum') && CURMODULE == 'index'))){
			return;
		}
		if(!empty($plugindata['comiis_kx_aid'])){
			$aids = explode(',', $plugindata['comiis_kx_aid']);
			$mysql = "select aid as tid,title as subject from ".DB::table('portal_article_title')." where aid IN (".dimplode($aids).")";
			$query=DB::query($mysql);
			while ($temp = DB::fetch($query)){
				$list[] = $temp;
			}
		}else{
			$sortadd = !in_array($plugindata['comiis_kx_type'], array('dateline', 'lastpost', 'views', 'replies', 'digest', 'displayorder')) ? 'dateline' : $plugindata['comiis_kx_type'];
			$tids = !empty($plugindata['comiis_kx_tid']) ? explode(',', $plugindata['comiis_kx_tid']) : array();
			if($tids){
				$filteradd = 'tid IN ('.dimplode($tids).') and ';
			}else{
				$forum = empty($plugindata['comiis_kx_forum']) ? array() : dunserialize($plugindata['comiis_kx_forum']);
				if(!is_array($forum)) $forum = array();
				if(isset($forum[0]) && $forum[0] == '') {
					unset($forum[0]);
				}
				if($forum){
					$filteradd = 'fid IN ('.dimplode($forum).') and ';
				}
				if($comiis_kx_retime > 0){
					$filteradd .= "lastpost >= '". (time() - $comiis_kx_retime) ."' and ";
				}
				if($comiis_kx_tidtime > 0){
					$filteradd .= "dateline >= '". (time() - $comiis_kx_tidtime) ."' and ";
				}
			}
			if($plugindata['comiis_kx_type'] == 'lastpost'){
				$filteradd .= "replies>'0' and ";
			}elseif($plugindata['comiis_kx_type'] == 'digest'){
				$filteradd .= "digest>'0' and ";
				$sortadd = "dateline";
			}elseif($plugindata['comiis_kx_type'] == 'displayorder'){
				$filteradd .= "displayorder IN (1, 2, 3, 4) and ";
				$sortadd = "dateline";
			}
			$mysql = "select tid,subject from ".DB::table('forum_thread')." where {$filteradd}displayorder>='0' ORDER BY {$sortadd} desc limit ". intval($plugindata['comiis_kx_readmun']);
			$query=DB::query($mysql);
			while ($temp = DB::fetch($query)){
				$list[] = $temp;
			}
		}
		$plugindata = dhtmlspecialchars($plugindata);
		include_once template('comiis_kx:comiis_kxs');
		return $return;
	}
}
