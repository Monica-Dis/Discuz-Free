function comiis_kx_show() {
	document.getElementById('comiis_kx').style.transform = "translateY(-"+comiis_kx_bottom+"px)";
	if(comiis_kx_loop == 1){
		comiis_kx_marquee(20, 20, comiis_kx_title_time, 'comiis_kx_text');
	}
	if(comiis_kx_closes == 1){
		setTimeout(comiis_kx_hidde, comiis_kx_hide_time);
	}
}
function comiis_kx_hidde() {
	document.getElementById('comiis_kx').style.transform = "translateY(50px)";
}
function comiis_kx_close(comiis_kx_closetime) {
	if(comiis_kx_closetime){
		setcookie('comiis_kx_close', 1, comiis_kx_closetime);
	}
	comiis_kx_hidde();
}
function comiis_kx_marquee(h, speed, delay, sid) {
	var t = null;
	var p = false;
	var o = document.getElementById(sid);
	o.innerHTML += o.innerHTML;
	o.onmouseover = function() {p = true}
	o.onmouseout = function() {p = false}
	o.scrollTop = 0;
	function start() {
		t = setInterval(scrolling, speed);
		if(!p) o.scrollTop += 2;
	}
	function scrolling() {
		if(p) return;
		if(o.scrollTop % h != 0) {
			o.scrollTop += 2;
			if(o.scrollTop >= o.scrollHeight/2) o.scrollTop = 0;
		} else {
			clearInterval(t);
			setTimeout(start, delay);
		}
	}
	setTimeout(start, delay);
}
setTimeout(comiis_kx_show, comiis_kx_show_time);
