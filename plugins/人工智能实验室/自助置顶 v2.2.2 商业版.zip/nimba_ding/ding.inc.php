<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$lang= lang('plugin/nimba_ding');
if(!$_G['uid']){//�ο�
	showmessage(lang('plugin/nimba_ding', 'userlogin'), '', array(), array('login' => true));
}
loadcache('plugin');
$uid=$_G['uid'];
$vars=$_G['cache']['plugin']['nimba_ding'];
$open=$vars['open'];
$op=$vars['op'];//1=ֻ���������Լ�������
$item=$vars['item'];//1=Сʱ 2=��
$max=$vars['max'];
$jf=$vars['jf'];
$value1=$vars['value1'];
$value2=$vars['value2'];
$value3=$vars['value3'];
$groups=unserialize($vars['groups']);
$itemname=($item==1)? $lang['item1']:$lang['item2'];
$jfname=$_G['setting']['extcredits'][$jf]['title'];
$credit_max = getuserprofile('extcredits'.$jf); 
$right=1;
if($op){
	$thread=C::t('forum_thread')->fetch(intval($_GET['tid']));
	if($thread['authorid']!=$uid) $right=0;
}
if(submitcheck('submit')){	
	if(empty($_G['uid'])||$open==0||!in_array($_G['groupid'],$groups)||$right==0) showmessage($lang['m2'],"forum.php?mod=viewthread&tid=".$_POST['tid']);
	else{
		$tid=intval($_POST['tid']);
		if($tid) $displayorder=C::t('forum_thread')->fetch_by_tid_displayorder($tid,1);
		if($displayorder){
			showmessage($lang['m1'],"forum.php?mod=viewthread&tid=".$tid);	
		}else{
			$style=intval($_POST['style']);
			$long=max(0,intval($_POST['long']));
			if($long==0){
					showmessage($lang['long_error']);
			}
			if($style==1){
				$howmuch=$long*$value1;
			}elseif($style==2){
				$howmuch=$long*$value2;
			}elseif($style==3){
				$howmuch=$long*$value3;
			}else{
				showmessage($lang['style_error']);
			}
			if($credit_max<$howmuch){
				showmessage($lang['howmuch_error']);
			}
			$endtime=($item==1)? $_G['timestamp']+$long*3600:$_G['timestamp']+$long*86400;
			updatemembercount($_G['uid'],array($jf=>-$howmuch),true,'',$tid,$lang['appname'],$lang['appname'],$lang['appname']);
			C::t('forum_thread')->update($tid, array('displayorder' =>$style, 'moderated' => 1));
			C::t('#nimba_ding#nimba_ding')->insert(array('tid'=>$tid,'buy'=>$howmuch,'uid'=>$uid,'username'=>$_G['username'],'dateline'=>$_G['timestamp'],'endtime'=>$endtime,'style'=>'','status'=>0));
			//��ԭ�ö�����ʧЧ�����������¼�¼
			C::t('forum_threadmod')->update_by_tid_action($tid,'EST',array('status'=>0));
			C::t('forum_threadmod')->insert(array('tid' =>$tid,'uid'=>$uid,'username'=>$_G['username'],'dateline'=>$_G['timestamp'],'expiration'=>$endtime,'action'=>'EST','status'=>1,'reason'=>$lang['reason']));
			//�����ö�����
			require_once libfile('function/cache');
			updatecache('globalstick');			
			C::t('forum_thread')->clear_cache($tid);	
			showmessage($lang['m3'].$long.$itemname.$lang['m4'].$howmuch.$jfname,"forum.php?mod=viewthread&tid=$tid");
		}
	}
}else{
	$longs=range(1,$max);
	$maxcredit=getuserprofile('extcredits'.$jf);
	include template('nimba_ding:ding');
}
//From: Dism_taobao-com
?>