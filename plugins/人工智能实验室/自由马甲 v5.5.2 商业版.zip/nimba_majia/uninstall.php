<?php
/*
 * 主页：http://dism.taobao.com/?@ailab
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
DB::query("DROP TABLE IF EXISTS ".DB::table('nimba_majia')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('nimba_forumupdate')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('nimba_noticeupdate')."");
$identifier = 'nimba_majia';
if(!function_exists('cloudaddons_deltree')) require libfile('function/cloudaddons');
cloudaddons_deltree(DISCUZ_ROOT .'./source/plugin/'.$identifier.'/');
$finish = TRUE;
?>