<?php
/*
 * 主页：http://dism.taobao.com/?@ailab
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(isset($_GET['op_delete'])){
	$uid=intval($_GET['uid']);
	$useruid=intval($_GET['useruid']);
	DB::delete('nimba_majia',array(
		'uid'=>$uid,
		'useruid'=>$useruid,
	));
	cpmsg(lang('plugin/nimba_majia','op_delete_ok'),'action=plugins&operation=config&identifier=nimba_majia&pmod=data', 'succeed');
}else{
	$pagenum=20;
	$page=max(1,intval($_GET['page']));
	$uasrname=array();
	$count=DB::result_first("select count(*) from ".DB::table("nimba_majia")." ");
	$data=DB::fetch_all("select * from ".DB::table("nimba_majia")." order by uid asc limit ".($page-1)*$pagenum.",$pagenum");
	showtableheader(lang('plugin/nimba_majia', 'appname'));
	showsubtitle(array('',lang('plugin/nimba_majia', 'mainuser'),lang('plugin/nimba_majia', 'repeat'),lang('plugin/nimba_majia', 'op_delete'),''));
	foreach($data as $item) {
		if(!isset($uasrname[$item['uid']])) $uasrname[$item['uid']]=DB::result_first("SELECT username FROM ".DB::table('common_member')." WHERE uid='".intval($item['uid'])."'");
		showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
			'',
			'<a href="home.php?mod=space&uid='.$item['uid'].'" target="_blank">'.$uasrname[$item['uid']].'</a>',
			'<a href="home.php?mod=space&uid='.$item['useruid'].'" target="_blank">'.$item['username'].'</a>',
			'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_majia&pmod=data&op_delete=yes&uid='.$item['uid'].'&useruid='.$item['useruid'].'">'.lang('plugin/nimba_majia', 'op_delete').'</a>',
			'',
		));
				
	}
	showtablefooter(); /*dism _ taobao _ com*/
	echo multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_majia&pmod=data");	
}


?>