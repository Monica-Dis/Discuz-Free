<?php
/*
 * ��ҳ��http://dism.taobao.com/?@ailab
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ������� ��ϵDISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
error_reporting(0);
loadcache('plugin');
$groups = unserialize($_G['cache']['plugin']['nimba_majia']['groups']);
$creditcost = intval($_G['cache']['plugin']['nimba_majia']['creditcost']);
$creditid = intval($_G['cache']['plugin']['nimba_majia']['creditid']);
$creditnum = intval($_G['cache']['plugin']['nimba_majia']['creditnum']);
if(!$creditid||!$creditnum){
	$creditcost=0;
}else{
	$jfname=$_G['setting']['extcredits'][$creditid]['title'];
	$jfmax = getuserprofile('extcredits'.$creditid);	
}
if(!$_G['uid']||!in_array($_G['groupid'], $groups)) {
	showmessage('nimba_majia:usergroup_disabled');
}
if($_GET['pluginop'] == 'add' && submitcheck('adduser')) {
	if($creditcost&&$jfmax<$creditnum){//���ֲ���
		showmessage(lang('plugin/nimba_majia','crediterror',array('jfname'=>$jfname)));//���ֲ���
	}
	loaducenter();
	$_GET['usernamenew']=addslashes($_GET['usernamenew']);
	$_GET['passwordnew']=addslashes($_GET['passwordnew']);
	if($_GET['questionidnew']) $_GET['questionidnew']=daddslashes($_GET['passwordnew']);
	$ucresult = $_GET['questionidnew']? uc_user_login($_GET['usernamenew'], $_GET['passwordnew']):uc_user_login($_GET['usernamenew'], $_GET['passwordnew'],0,1,$_GET['questionidnew'],$_GET['answernew']);
	if(empty($_GET['passwordnew']) || ($_GET['questionidnew'] && empty($_GET['answernew'])) || $ucresult[0]<=0) {
		showmessage('nimba_majia:adduser_fail',"javascript:history.back()");
	}
	$useruid=$ucresult[0];
	$log=DB::result_first("select * from ".DB::table('nimba_majia')." where uid='$_G[uid]' and useruid='$useruid'");
	if($log){
		showmessage('nimba_majia:adduser_inlist',"javascript:history.back()");
	}
	$usernamenew = strip_tags($_GET['usernamenew']);
	DB::insert('nimba_majia',array('uid'=>$_G['uid'],'username'=>$usernamenew,'useruid'=>$useruid));
	if($creditcost){
		updatemembercount($_G['uid'], array($creditid=>-$creditnum),true,'',$_G['uid'],lang('plugin/nimba_majia','appname'),lang('plugin/nimba_majia','appname'),lang('plugin/nimba_majia','appname'));
	}
	$usernamenew = dhtmlspecialchars(stripslashes($usernamenew));
	showmessage('nimba_majia:adduser_succeed', 'home.php?mod=spacecp&ac=plugin&id=nimba_majia:admincp', array('usernamenew' => $usernamenew));
	
}elseif(!empty($_GET['delete'])&&$_GET['formhash'] == FORMHASH) {
	$_GET['delete']=daddslashes($_GET['delete']);
	$uids=implode(',',$_GET['delete']);
	DB::query("DELETE FROM ".DB::table('nimba_majia')." WHERE uid='$_G[uid]' AND useruid in($uids)");
	showmessage('nimba_majia:updateuser_succeed', 'home.php?mod=spacecp&ac=plugin&id=nimba_majia:admincp');
}
//�����б�
$repeatusers=DB::fetch_all("SELECT * FROM ".DB::table('nimba_majia')." WHERE uid='$_G[uid]'");
$creditinfo=lang('plugin/nimba_majia','creditinfo',array('jfname'=>$jfname,'creditnum'=>$creditnum))
?>