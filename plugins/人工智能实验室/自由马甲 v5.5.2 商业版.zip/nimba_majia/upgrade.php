<?php
/*
 * Copyright 2001-2099 DisM!应用中心.
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//清除不用的低版本数据表
DB::query("DROP TABLE IF EXISTS ".DB::table('nimba_forumupdate')."");
DB::query("DROP TABLE IF EXISTS ".DB::table('nimba_noticeupdate')."");
$sql = <<<EOF
ALTER TABLE `pre_nimba_majia`
MODIFY COLUMN `uid`  int(11) UNSIGNED NOT NULL,
MODIFY COLUMN `useruid`  int(11) UNSIGNED NOT NULL;
EOF;

runquery($sql);

/* 删除文件 */
$identifier = 'nimba_views';
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');
@unlink($entrydir.'/upgrade.php');
/* 删除文件 */
$finish = TRUE;
?>