<?php
/*
 * 主页：https://dism.taobao.com/?@1552.developer
 * 人工智能实验室：Discuz!应用中心十大优秀开发者！
 * 插件定制 联系QQ594941227
 * From www.ailab.cn
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//删除历史字段
$upgrade_tobaidu=0;
$upgrade_todate=0;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('forum_thread'));
while($temp = DB::fetch($query)) {
	if($temp['Field']== 'tobaidu') {
		$upgrade_tobaidu=1;
	}
	if($temp['Field']== 'todate') {
		$upgrade_todate=1;
	}	
}
if($upgrade_tobaidu){
	DB::query("ALTER table ".DB::table('forum_thread')." DROP COLUMN `tobaidu`;");
}
if($upgrade_todate){
	DB::query("ALTER table ".DB::table('forum_thread')." DROP COLUMN `todate`;");
}
//删除数据表
$sql = <<<SQL
DROP TABLE IF EXISTS pre_baidusitemap;
SQL;
runquery($sql);
if(file_exists(DISCUZ_ROOT.'./data/cache/cache_baidusitemap_over.php')) @unlink($filepath);
if(file_exists(DISCUZ_ROOT.'./data/cache/cache_baidusitemap_remain.php')) @unlink($filepath);
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_baidusitemap_over.php')) @unlink($filepath);
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_baidusitemap_remain.php')) @unlink($filepath);

if(file_exists(DISCUZ_ROOT.'./data/cache/cache_baidusitemap_dailysubmit_over.php')) @unlink($filepath);
if(file_exists(DISCUZ_ROOT.'./data/cache/cache_baidusitemap_dailysubmit_remain.php')) @unlink($filepath);
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_baidusitemap_dailysubmit_over.php')) @unlink($filepath);
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_baidusitemap_dailysubmit_remain.php')) @unlink($filepath);
/* 删除文件 */
$identifier = 'baidusitemap';
if(!function_exists('cloudaddons_deltree')) require libfile('function/cloudaddons');
cloudaddons_deltree(DISCUZ_ROOT .'./source/plugin/'.$identifier.'/');
/* 删除文件 */
$finish = TRUE;
