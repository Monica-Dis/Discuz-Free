<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
if($_GET['start']) $start=strtotime($_GET['start'].':00');
else $start=strtotime(dgmdate(TIMESTAMP,'Y-m').'-1 00:00:00');
if($_GET['end']) $end=strtotime($_GET['end'].':00');
else $end=time();
showformheader("plugins&operation=config&identifier=baidusitemap&pmod=logs");
showtableheader(lang('plugin/baidusitemap','s_title'), 'nobottom');
showsetting(lang('plugin/baidusitemap','s_start'), 'start',dgmdate($start,'Y-m-d H:i'), 'calendar', '', 0,'', 1);	
showsetting(lang('plugin/baidusitemap','s_end'), 'end',dgmdate($end,'Y-m-d H:i'), 'calendar', '', 0,'', 1);	
showsubmit('editsubmit');
showtablefooter(); /*Dism·taobao·com*/
showformfooter(); /*Dism_taobao_com*/
$where="dateline>$start and dateline<$end";
if(DISCUZ_VERSION=='X2'){
	$filepath=DISCUZ_ROOT.'./data/cache/cache_baidusitemap_remain.php';
}else{
	$filepath=DISCUZ_ROOT.'./data/sysdata/cache_baidusitemap_remain.php';
}
if(file_exists($filepath)){
	@require_once $filepath;
	$doing=true;
}else{
	$doing=false;
}

$pagenum=50;
$page=max(1,intval($_GET['page']));
$count=DB::result_first("select count(*) from ".DB::table('baidusitemap')." where $where order by dateline desc");

if($doing){
	$addtitle=lang('plugin/baidusitemap','addtitle',array(
		'max'=>$max,
		'remain'=>$remain,
	));
}else{
	$addtitle=lang('plugin/baidusitemap','addtitle2');
}

showtableheader(lang('plugin/baidusitemap','title').$addtitle);
showsubtitle(array(
	lang('plugin/baidusitemap','pushtype'),
	lang('plugin/baidusitemap','type'),
	lang('plugin/baidusitemap','subject'),
	lang('plugin/baidusitemap','todate'),
));

$list=DB::fetch_all("select * from ".DB::table('baidusitemap')." where $where order by dateline desc ".DB::limit(($page-1)*$pagenum,$pagenum));
$tids=$aids=$blogids=array();
foreach($list as $k=>$v){
	if($v['idtype']=='tid') $tids[]=$v['id'];
	if($v['idtype']=='aid') $aids[]=$v['id'];
	if($v['idtype']=='blogid') $blogids[]=$v['id'];
}
if(count($tids)){
	$threadlist=DB::fetch_all("select tid,subject from ".DB::table('forum_thread')." where tid in(".implode(',',$tids).")",null,'tid');
}
if(count($aids)){
	$articlelist=DB::fetch_all("select aid,title from ".DB::table('portal_article_title')." where aid in(".implode(',',$aids).")",null,'aid');
}
if(count($blogids)){
	$bloglist=DB::fetch_all("select blogid,uid,subject from ".DB::table('home_blog')." where blogid in(".implode(',',$blogids).")",null,'blogid');
}
foreach($list as $data) {
	if($data['idtype']=='tid'){
		showtablerow('', array('class="td_k"', 'class="td_k"', 'class="td_l"'), array(
			lang('plugin/baidusitemap','pushtype_'.$data['pushtype']),
			lang('plugin/baidusitemap','type_'.$data['idtype']),
			'<a href="forum.php?mod=viewthread&tid='.$data['id'].'" target="_blank">'.$threadlist[$data['id']]['subject'].'</a>',
			dgmdate($data['dateline'],'Y-m-d H:i:s'),
		));
	}elseif($data['idtype']=='aid'){
		showtablerow('', array('class="td_k"', 'class="td_k"', 'class="td_l"'), array(
			lang('plugin/baidusitemap','pushtype_'.$data['pushtype']),
			lang('plugin/baidusitemap','type_'.$data['idtype']),
			'<a href="portal.php?mod=view&aid='.$data['id'].'" target="_blank">'.$articlelist[$data['id']]['title'].'</a>',
			dgmdate($data['dateline'],'Y-m-d H:i:s'),
		));	
	}elseif($data['idtype']=='blogid'){
		showtablerow('', array('class="td_k"', 'class="td_k"', 'class="td_l"'), array(
			lang('plugin/baidusitemap','pushtype_'.$data['pushtype']),
			lang('plugin/baidusitemap','type_'.$data['idtype']),
			'<a href="home.php?mod=space&uid='.$bloglist[$data['id']]['uid'].'&do=blog&id='.$data['id'].'" target="_blank">'.$bloglist[$data['id']]['subject'].'</a>',
			dgmdate($data['dateline'],'Y-m-d H:i:s'),
		));	
	}	
}
showtablefooter(); /*Dism·taobao·com*/
echo multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=baidusitemap&pmod=logs&start=".date('Y-m-d H:i',$start).'&end='.date('Y-m-d H:i',$end));
?>