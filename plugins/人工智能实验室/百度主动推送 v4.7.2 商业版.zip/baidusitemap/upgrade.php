<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//升级为数据表记录方式
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_baidusitemap` (
  `id` int(11) unsigned NOT NULL,
  `idtype` varchar(15) NOT NULL,
  `pushtype`  tinyint(1) NOT NULL DEFAULT 0,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`, `idtype`, `pushtype`)
);
EOF;
runquery($sql);
//增加字段 pushtype
$upgrade_pushtype=true;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('baidusitemap'));
while($temp = DB::fetch($query)) {
	if($temp['Field']== 'pushtype') {
		$upgrade_pushtype=false;
		break;
	}
}
if($upgrade_pushtype){
$sql = <<<EOF
ALTER TABLE `pre_baidusitemap`
ADD COLUMN `pushtype`  tinyint(1) NOT NULL DEFAULT 0;
EOF;
runquery($sql);	
}

//删除历史字段
$upgrade_tobaidu=0;
$upgrade_todate=0;
$query = DB::query("SHOW COLUMNS FROM ".DB::table('forum_thread'));
while($temp = DB::fetch($query)) {
	if($temp['Field']== 'tobaidu') {
		$upgrade_tobaidu=1;
	}
	if($temp['Field']== 'todate') {
		$upgrade_todate=1;
	}	
}
if($upgrade_tobaidu){
	DB::query("ALTER table ".DB::table('forum_thread')." DROP COLUMN `tobaidu`;");
}
if($upgrade_todate){
	DB::query("ALTER table ".DB::table('forum_thread')." DROP COLUMN `todate`;");
}

//修复主键问题
$sql = <<<EOF
ALTER TABLE `pre_baidusitemap`
DROP PRIMARY KEY,
ADD PRIMARY KEY (`id`, `idtype`, `pushtype`);
EOF;
runquery($sql);



/* 删除文件 */
$identifier = 'baidusitemap';
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');
@unlink($entrydir.'/upgrade.php');
/* 删除文件 */
$finish = TRUE;

?>