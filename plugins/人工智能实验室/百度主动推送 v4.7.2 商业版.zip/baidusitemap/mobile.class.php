<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_baidusitemap {
	function  __construct() {
		global $_G;
		loadcache('plugin');
		//自动获取当前域名
		$this->domain=dhtmlspecialchars(($_G['isHTTPS'] ? 'https://' : '').$_SERVER['HTTP_HOST']);
		$this->pushtype=1;//dailysubmit
		$this->day=intval($_G['cache']['plugin']['baidusitemap']['day']);
	}
}

class mobileplugin_baidusitemap_forum extends mobileplugin_baidusitemap{
	function viewthread_top_mobile_output(){
		global $_G;
		if($this->day&&TIMESTAMP-$_G['thread']['dateline']>(86400*$this->day)) return '';
		if(!$_G['tid']||!$_G['thread']['tid']) return '';//文章不存在
		if($_G['thread']['displayorder']<0) return '<!--BS-'.$this->pushtype.' displayorder Error -->';//displayorder<0 推送
		if(!function_exists('curl_init')||!function_exists('curl_setopt_array')||!function_exists('curl_exec')) return '<!--BS-'.$this->pushtype.' No CURL-->';//环境不支持
		loadcache('plugin');
		$vars=$_G['cache']['plugin']['baidusitemap'];
		/* filter start */
		$forums=unserialize($vars['forums']);
		if(!in_array($_G['fid'],$forums)) return '<!--BS-'.$this->pushtype.' filter forums -->';//该版块未开启
		/* filter end */
		$token=trim($vars['token']);
		if(!$token) return '<!-- Error Setting-->';//配置缺失
		$dailysubmit=intval($vars['dailysubmit']);
		if(!$dailysubmit) $this->pushtype=0;
		if($dailysubmit&&$this->pushtype==1){//快速收录检查
			$over='';
			//检查快速收录余额
			if(DISCUZ_VERSION=='X2'){
				$filepath=DISCUZ_ROOT.'./data/cache/cache_baidusitemap_dailysubmit_over.php';
			}else{
				$filepath=DISCUZ_ROOT.'./data/sysdata/cache_baidusitemap_dailysubmit_over.php';
			}
			if(file_exists($filepath)){
				@require_once $filepath;
			}
			if($over==date('Ymd')) $this->pushtype=0;//当日推送已满		
		}
		
		//检查主动推送余额
		if($this->pushtype==0){
			$filepath='';
			$over='';
			if(DISCUZ_VERSION=='X2'){
				$filepath=DISCUZ_ROOT.'./data/cache/cache_baidusitemap_over.php';
			}else{
				$filepath=DISCUZ_ROOT.'./data/sysdata/cache_baidusitemap_over.php';
			}
			if(file_exists($filepath)){
				@require_once $filepath;
			}
			if($over==date('Ymd')) return '<!--BS-'.$this->pushtype.' Over Quota -->';//当日推送已满	
		}
		if(memory('check')){
			$logtime=memory('get','baidusitemap:tid:'.$this->pushtype.':'.$_G['tid']);
			if(!$logtime){//可能被清理了
				$logtime=DB::result_first("select dateline from ".DB::table('baidusitemap')." where id='$_G[tid]' and idtype='tid' and pushtype='".$this->pushtype."'");
				memory('set','baidusitemap:tid:'.$this->pushtype.':'.$_G['tid'],$logtime);
			}
		}else{
			$logtime=DB::result_first("select dateline from ".DB::table('baidusitemap')." where id='$_G[tid]' and idtype='tid' and pushtype='".$this->pushtype."'");
		}
		if($logtime) return '<!--BS-'.$this->pushtype.' To Baidu OK @'.date('Y-m-d H:i:s',$logtime).'-->';//已经成功推送		
		if(in_array('forum_viewthread',$_G['setting']['rewritestatus'])){
			$url=$_G['siteurl'].str_replace(array('{tid}','{page}','{prevpage}'),array($_G['tid'],1,1),$_G['setting']['rewriterule']['forum_viewthread']);
		}else{
			$url=$_G['siteurl'].'forum.php?mod=viewthread&tid='.$_G['tid'];
		}
		$api = 'http://data.zz.baidu.com/urls?site='.$this->domain.'&token='.$token.($this->pushtype? '&type=daily':'');
		$ch = curl_init();
		$options =  array(
			CURLOPT_URL => $api,
			CURLOPT_POST => true,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POSTFIELDS => $url,
			CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
		);
		curl_setopt_array($ch, $options);
		$result = curl_exec($ch);
		$json=json_decode($result,true);
		if(isset($json['success'])&&$json['success']==1){
			DB::insert('baidusitemap',array(
				'id'=>$_G['tid'],
				'pushtype'=>$this->pushtype,
				'idtype'=>'tid',
				'dateline'=>TIMESTAMP,
			));
			memory('set','baidusitemap:tid:'.$this->pushtype.':'.$_G['tid'],TIMESTAMP);
			if(isset($json['remain'])&&$this->pushtype==0){
				$max=0;
				if(DISCUZ_VERSION=='X2'){
					$filepath=DISCUZ_ROOT.'./data/cache/cache_baidusitemap_remain.php';
				}else{
					$filepath=DISCUZ_ROOT.'./data/sysdata/cache_baidusitemap_remain.php';
				}
				if(file_exists($filepath)){
					@require_once $filepath;
				}
				$remain=intval($json['remain']);
				$max=max($remain+1,$max);
				@require_once libfile('function/cache');
				$cacheArray = "\$remain=".$remain.";\n";
				$cacheArray.= "\$max=".$max.";\n";
				writetocache('baidusitemap_remain',$cacheArray);//记录每日运行推送最大数，可近日剩余数
			}elseif(isset($json['remain'])&&$this->pushtype==1){
				@require_once libfile('function/cache');
				$cacheArray = "\$result=".$result.";\n";
				writetocache('baidusitemap'.($this->pushtype? '_dailysubmit':'').'_remain',$cacheArray);//记录
			}
			return '<!--BS-'.$this->pushtype.' Doing To Baidu -->';			
		}elseif(isset($json['error'])&&$json['error']=='400'&&$json['message']=='over quota'){//当日推送已满
			@require_once libfile('function/cache');
			$cacheArray= "\$over='".date('Ymd')."';\n";
			writetocache('baidusitemap'.($this->pushtype? '_dailysubmit':'').'_over',$cacheArray);
			return '<!--BS-'.$this->pushtype.' over quota : '.$result.' -->';
		}else{//其他错误 
			return '<!--BS-'.$this->pushtype.' Other Error : '.$result.' -->';
		}
		return '';
	}
}

