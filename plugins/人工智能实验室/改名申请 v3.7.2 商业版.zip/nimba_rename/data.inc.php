<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$pagenum=20;
$page=max(1,intval($_GET['page']));
$count=C::t('#nimba_rename#nimba_rename')->count();
showtableheader(); //dism·taobao·com
showsubtitle(array(lang('plugin/nimba_rename','username'),lang('plugin/nimba_rename','newname'),lang('plugin/nimba_rename','dateline'),lang('plugin/nimba_rename','reason'),lang('plugin/nimba_rename','status')));
$data=C::t('#nimba_rename#nimba_rename')->fetch_all_by_range(($page - 1)*$pagenum,$pagenum);
foreach($data as $user) {
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		'<a href="home.php?mod=space&uid='.$user['uid'].'" target="_blank">'.$user['username'].'</a>',
		$user['newname'],	
		dgmdate($user['dateline'],'Y-m-d H:i:s'),
		$user['reason'],
		lang('plugin/nimba_rename','status'.$user['status']),
	));
			
}
showtablefooter(); //Dism·taobao·com
echo multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_rename&pmod=data");