<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$op=addslashes($_GET['op']);
$id=intval($_GET['id']);
$uid=intval($_GET['uid']);
$note_1=$_G['cache']['plugin']['nimba_rename']['note_1'];
$note_2=$_G['cache']['plugin']['nimba_rename']['note_2'];
if($op&&$id){
	ajaxshowheader();
	if($op=='yes'){
		//����+�޸�״̬
		$newname=C::t('#nimba_rename#nimba_rename')->fetch_newname_by_id($id);
		$status=C::t('#nimba_rename#nimba_rename')->update_username_by_uid_newname($uid,$newname);	
		//$status=1;		
		if($status){
			C::t('#nimba_rename#nimba_rename')->update_status_by_id($id,array('status'=>1));
			notification_add($uid,'system',$note_1);//֪ͨ��Ϣ
			//���»���
			if(memory('check')){
				C::memory()->clear();	
			}
			//�������ݻ���
			@require_once libfile('function/cache');
			updatecache();
			require_once libfile('function/group');
			$groupindex['randgroupdata'] = $randgroupdata = grouplist('lastupdate', array('ff.membernum', 'ff.icon'), 80);
			$groupindex['topgrouplist'] = $topgrouplist = grouplist('activity', array('f.commoncredits', 'ff.membernum', 'ff.icon'), 10);
			$groupindex['updateline'] = TIMESTAMP;
			$groupdata = C::t('forum_forum')->fetch_group_counter();
			$groupindex['todayposts'] = $groupdata['todayposts'];
			$groupindex['groupnum'] = $groupdata['groupnum'];
			savecache('groupindex', $groupindex);
			C::t('forum_groupfield')->truncate();
			savecache('forum_guide', '');
			if($_G['setting']['grid']['showgrid']){
				savecache('grids', array());
			}			
			echo lang('plugin/nimba_rename','status1');
		}else{
			echo lang('plugin/nimba_rename','status3');
		}
	}elseif($op=='no'){
		notification_add($uid,'system',$note_2);//֪ͨ��Ϣ
		C::t('#nimba_rename#nimba_rename')->update_status_by_id($id,array('status'=>2));
		echo lang('plugin/nimba_rename','status2');
	}else echo 'error';
	ajaxshowfooter();
}else{
$pagenum=20;
$page=max(1,intval($_GET['page']));
$count=C::t('#nimba_rename#nimba_rename')->count_by_status(0);
showtableheader(); //dism��taobao��com
showsubtitle(array(lang('plugin/nimba_rename','username'),lang('plugin/nimba_rename','newname'),lang('plugin/nimba_rename','dateline'),lang('plugin/nimba_rename','reason'),lang('plugin/nimba_rename','op')));
$data=C::t('#nimba_rename#nimba_rename')->fetch_all_by_status_range(0,($page - 1)*$pagenum,$pagenum);
foreach($data as $user) {	
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		'<a href="home.php?mod=space&uid='.$user['uid'].'" target="_blank">'.$user['username'].'</a>',
		$user['newname'],	
		date('Y-m-d H:i:s',$user['dateline']),
		$user['reason'],
		'<span id="'.$user['id'].'"><a onclick="ajaxget(\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_rename&pmod=admincp&op=yes&uid='.$user['uid'].'&id='.$user['id'].'\',\''.$user['id'].'\',\''.$user['id'].'\',\'loading\',\'\',\'recall\');return false" href="#">'.lang('plugin/nimba_rename','yes').'</a> | <a onclick="ajaxget(\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_rename&pmod=admincp&op=no&uid='.$user['uid'].'&id='.$user['id'].'\',\''.$user['id'].'\',\''.$user['id'].'\',\'loading\',\'\',\'recall\');return false" href="#">'.lang('plugin/nimba_rename','no').'</a></span>',
	));
			
}
showtablefooter(); //Dism��taobao��com
echo multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_rename&pmod=admincp");
}
//From: Dism_taobao-com
?>