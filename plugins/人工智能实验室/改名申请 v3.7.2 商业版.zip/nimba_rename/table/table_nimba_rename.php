<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_nimba_rename extends discuz_table{
	public function __construct() {

		$this->_table = 'nimba_rename';
		$this->_pk    = 'id';
		$this->_pre_cache_key = 'nimba_rename_';

		parent::__construct(); //d'.'is'.'m.ta'.'obao.com
	}
	public function count(){
		$count = DB::result_first('SELECT COUNT(*) FROM %t', array($this->_table));
		return $count;
	}
	public function count_by_status($status){
		$count = DB::result_first('SELECT COUNT(*) FROM %t where status=%d', array($this->_table,$status));
		return $count;
	}
	public function count_by_uid_status($uid,$status){
		$count = DB::result_first('SELECT COUNT(*) FROM %t where uid=%d and status=%d', array($this->_table,$uid,$status));
		return $count;
	}	
	public function max_id() {
		return DB::result_first('SELECT MAX(id) FROM %t', array($this->_table));
	}

	public function fetch_all_by_status_range($status,$start,$end) {
		return DB::fetch_all('SELECT * FROM %t where status=%d ORDER BY id DESC LIMIT %d,%d', array($this->_table,$status,$start,$end), $this->_pk);
	}
	public function fetch_all_by_range($start,$end) {
		return DB::fetch_all('SELECT * FROM %t ORDER BY id DESC LIMIT %d,%d', array($this->_table,$start,$end), $this->_pk);
	}	
	public function drop() {
		return DB::query('DROP TABLE IF EXISTS %t',array($this->_table));
	}
	public function update_status_by_id($id,$data){
		if($id&&!empty($data)&&is_array($data)) {
			DB::update($this->_table, $data, DB::field('id', $id), 'UNBUFFERED');
		}	
	
	}
	public function fetch_newname_by_id($id) {
		return DB::result_first('SELECT newname FROM %t WHERE id=%d', array($this->_table, $id));
	}
	public function update_username_by_uid_newname($uid,$newname) {
		global $_G;
		require_once DISCUZ_ROOT.'./config/config_ucenter.php';
		if($_G['config']['db'][1]['dbhost']==UC_DBHOST&&$_G['config']['db'][1]['dbuser']==UC_DBUSER){//UC与dz同库的情况
			DB::query("UPDATE ".UC_DBTABLEPRE."members SET username='".$newname."' WHERE uid='$uid'", 'UNBUFFERED');
		}else{
			//开始 UC与dz 不同库的情况
			if(function_exists("mysql_connect")) {
				require_once DISCUZ_ROOT.'./uc_client/lib/db.class.php';
			} else {
				require_once DISCUZ_ROOT.'./uc_client/lib/dbi.class.php';
			}
			$uc_db = new ucclient_db();
			$uc_db->connect(UC_DBHOST, UC_DBUSER, UC_DBPW, '', UC_DBCHARSET, UC_DBCONNECT, UC_DBTABLEPRE);
			if($uc_db){
				$uc_db->query("UPDATE ".UC_DBTABLEPRE."members SET username='".$newname."' WHERE uid='$uid'", 'UNBUFFERED');
			}else{
				return false;
			}
			//结束
		}
		$tables = array(
			'common_block' => array('id' => 'uid', 'name' => 'username'),
			'common_invite' => array('id' => 'fuid', 'name' => 'fusername'),
			'common_member' => array('id' => 'uid', 'name' => 'username'),
			'common_member_security' => array('id' => 'uid', 'name' => 'username'),
			'common_mytask' => array('id' => 'uid', 'name' => 'username'),
			'common_report' => array('id' => 'uid', 'name' => 'username'),
			'forum_thread' => array('id' => 'authorid', 'name' => 'author'),
			'forum_post' => array('id' => 'authorid', 'name' => 'author'),
			'forum_activityapply' => array('id' => 'uid', 'name' => 'username'),
			'forum_groupuser' => array('id' => 'uid', 'name' => 'username'),
			'forum_pollvoter' => array('id' => 'uid', 'name' => 'username'),
			'forum_postcomment' => array('id' => 'authorid', 'name' => 'author'),
			'forum_ratelog' => array('id' => 'uid', 'name' => 'username'),
			'home_album' => array('id' => 'uid', 'name' => 'username'),
			'home_blog' => array('id' => 'uid', 'name' => 'username'),
			'home_clickuser' => array('id' => 'uid', 'name' => 'username'),
			'home_docomment' => array('id' => 'uid', 'name' => 'username'),
			'home_doing' => array('id' => 'uid', 'name' => 'username'),
			'home_feed' => array('id' => 'uid', 'name' => 'username'),
			'home_feed_app' => array('id' => 'uid', 'name' => 'username'),
			'home_friend' => array('id' => 'fuid', 'name' => 'fusername'),
			'home_friend_request' => array('id' => 'fuid', 'name' => 'fusername'),
			'home_notification' => array('id' => 'authorid', 'name' => 'author'),
			'home_pic' => array('id' => 'uid', 'name' => 'username'),
			'home_poke' => array('id' => 'fromuid', 'name' => 'fromusername'),
			'home_share' => array('id' => 'uid', 'name' => 'username'),
			'home_show' => array('id' => 'uid', 'name' => 'username'),
			'home_specialuser' => array('id' => 'uid', 'name' => 'username'),
			'home_visitor' => array('id' => 'vuid', 'name' => 'vusername'),
			'portal_article_title' => array('id' => 'uid', 'name' => 'username'),
			'portal_comment' => array('id' => 'uid', 'name' => 'username'),
			'portal_topic' => array('id' => 'uid', 'name' => 'username'),
			'portal_topic_pic' => array('id' => 'uid', 'name' => 'username'),
		);
		foreach($tables as $table => $conf) {
			DB::query("UPDATE ".DB::table($table)." SET `".$conf['name']."`='$newname' WHERE `".$conf['id']."`='$uid'");
		}
		return true;
	}	
}
//dis'.'m.t'.'ao'.'bao.com
?>