<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_nimba_rename {
	public $open=0;
	public $groups=array();
	public $nav=0;
	public $name='';
	
	function  __construct() {
	    loadcache('plugin');
		global $_G;
		$this->vars = $_G['cache']['plugin']['nimba_rename'];
		$this->groups=unserialize($this->vars['groups']);
		$this->nav=$this->vars['nav'];
		$this->name=$this->vars['name'];
		$this->open=$this->vars['open'];
		$this->mobile=$this->vars['mobile'];
	}	
	
	function global_cpnav_extra1() {
		loadcache('plugin');
		global $_G;
		if($this->open&&in_array($_G['groupid'],$this->groups)&&$this->nav==2) return '<a href="javascript:;" onclick=showWindow(\'nimba_rename\',\'plugin.php?id=nimba_rename\')>'.$this->name.'</a>';
	}

	function global_nav_extra(){
		loadcache('plugin');
		global $_G;
		if($this->open&&in_array($_G['groupid'],$this->groups)&&$this->nav==3) return '<ul><li><a href="javascript:;" onclick=showWindow(\'nimba_rename\',\'plugin.php?id=nimba_rename\')>'.$this->name.'</a></ul></li>';	
	}
	
	function global_footerlink(){
		loadcache('plugin');
		global $_G;
		if($this->open&&in_array($_G['groupid'],$this->groups)&&$this->nav==4) return '<span class="pipe">|</span><a href="javascript:;" onclick=showWindow(\'nimba_rename\',\'plugin.php?id=nimba_rename\')>'.$this->name.'</a>';	
	}
	
	function global_usernav_extra2(){
		loadcache('plugin');
		global $_G;
		if($this->open&&in_array($_G['groupid'],$this->groups)&&$this->nav==5) return '<span class="pipe">|</span><a href="javascript:;" onclick=showWindow(\'nimba_rename\',\'plugin.php?id=nimba_rename\')>'.$this->name.'</a>';		
	}
}

class mobileplugin_nimba_rename extends plugin_nimba_rename{
	function global_footer_mobile(){
		global $_G;
		if($_G['uid']&&$this->mobile&&CURSCRIPT=='home'&&$_GET['mod']=='space'&&$_GET['uid']==$_G['uid']){
			return '<center><a href="plugin.php?id=nimba_rename">'.$this->name.'</a></center>';
		}
		return '';
	}

}