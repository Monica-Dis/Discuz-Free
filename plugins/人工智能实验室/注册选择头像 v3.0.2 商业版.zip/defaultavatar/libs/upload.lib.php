<?php
/*
 * Copyright 2001-2099 DisM!Ӧ������.
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ������� ��ϵDISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(submitcheck('addsubmit')){
	if($_FILES['avatar']){
		$tmp=$_FILES['avatar']['tmp_name'];
		$pinfo=pathinfo($_FILES['avatar']['name']);
		$ftype=strtolower($pinfo['extension']);
		if($ftype!='jpg') cpmsg($langvars['error_1']);
		$time=TIMESTAMP;
		$cache='./source/plugin/defaultavatar/avatar/avatar_'.$time.'.'.$ftype;
		$r=move_uploaded_file($tmp,DISCUZ_ROOT.$cache);
		if(file_exists(DISCUZ_ROOT.$cache)){
			$config[]=array('name'=>'avatar_'.$time.'.'.$ftype,'status'=>1);
			updateImgCache($config);
		}else{
			cpmsg($langvars['error_2']);
		}
	}else{
		cpmsg($langvars['error_2']);
	}
	cpmsg($langvars['ok'],'action=plugins&operation=config&identifier=defaultavatar&pmod=upload', 'succeed');
}else{
	showformheader("plugins&operation=config&identifier=defaultavatar&pmod=upload&op=addtask","enctype=\"multipart/form-data\"");
	showtableheader($langvars['avatar_new_title'], 'nobottom');	
	showsetting($langvars['avatar_new'], 'avatar','', 'file','',0,$langvars['avatar_new_tips']);
	showsubmit('addsubmit');
	showtablefooter(); /*dism _ taobao _ com*/
	showformfooter(); /*dism - taobao - com*/
}
//From: Dism��taobao��com
?>