<?php
/*
 * Copyright 2001-2099 DisM!Ӧ������.
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ������� ��ϵDISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$langvar=lang('plugin/defaultavatar');
if($_GET['update']==formhash()){
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/defaultavatar/libs/upload.lib.php')){
		cpmsg($langvar['update_error'],'action=plugins&operation=config&identifier=defaultavatar&pmod=fastupload', 'succeed');
	}else{
		//@2019.03.27 �ĳɷ�������
		$page=max(1,intval($_GET['page']));
		$pagenum=100;
		$num=scanfile();
		if($num>=100){
			updateImgCache();
			cpmsg($langvar['update_next'].($pagenum*($page-1)+$num),'action=plugins&operation=config&identifier=defaultavatar&pmod=fastupload&update='.FORMHASH.'&page='.($page+1), 'succeed');
		}else{
			updateImgCache();
			cpmsg($langvar['update_ok'],'action=plugins&operation=config&identifier=defaultavatar&pmod=fastupload', 'succeed');
		}
	}
}else{
	$config=array();
	if(!file_exists(DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php')){//upgrade
		$pics=array(
			'avatar_1403071383.jpg',
			'avatar_1403071725.jpg',
			'avatar_1403071735.jpg',
			'avatar_1403071746.jpg',
			'avatar_1403071764.jpg',
			'avatar_1403071782.jpg',
			'avatar_1403071798.jpg',
			'avatar_1403071814.jpg',
			'avatar_1403071832.jpg',
			'avatar_1403071844.jpg',
		);
		foreach($pics as $k=>$pic){
			if(file_exists(DISCUZ_ROOT.'./source/plugin/defaultavatar/avatar/default/'.$pic)){
				copy(DISCUZ_ROOT.'./source/plugin/defaultavatar/avatar/default/'.$pic,DISCUZ_ROOT.'./source/plugin/defaultavatar/avatar/'.$pic);
				$config[]=$item=array('name'=>$pic,'status'=>1,'dateline'=>TIMESTAMP);
				DB::insert('defaultavatar',$item);
			}
		}
		if($config&&count($config)){
			updateImgCache();
		}
	}else{
		@require_once DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php';
		//��ת����
		$count=DB::result_first("select count(*) from ".DB::table('defaultavatar')."");
		if($count==0&&count($config)){//@2019.03.27 �������
			cpmsg($langvars['update_do'],'action=plugins&operation=config&identifier=defaultavatar&pmod=upload&update='.FORMHASH, 'succeed');
		}
	}	
	showtableheader($langvar['fastupload']);
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		$langvar['tip_1']
	));
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		$langvar['tip_2']
	));
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		$langvar['tip_3']
	));
	if(!file_exists(DISCUZ_ROOT.'./source/plugin/defaultavatar/libs/upload.lib.php')){
		showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
			'<font color="red">'.$langvar['tip_4'].'</font>'
		));
	}	
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=defaultavatar&pmod=fastupload&update='.FORMHASH.'"><strong>'.$langvar['update'].'</strong></a>'
	));
	showtablefooter(); /*dism _ taobao _ com*/
}

function scanfile(){
	global $_G,$config;
	$dir = DISCUZ_ROOT.'./source/plugin/defaultavatar/fastupload/';
	$handle=opendir($dir); 
	$avatar=array();
	$index=0;
	while(false!==($file=readdir($handle))){ 
		if(substr_count(strtolower($file),'.jpg')){
			$r=@rename($dir.$file,DISCUZ_ROOT.'./source/plugin/defaultavatar/avatar/auto_'.md5($file).'.jpg');
			if($r){
				$config[]=$item=array('name'=>'auto_'.md5($file).'.jpg','status'=>1,'dateline'=>TIMESTAMP);
				DB::insert('defaultavatar',$item);
				$index++;
				if(file_exists($dir.$file)){//����δ��ɾ�������
					@unlink($dir.$file);
				}
			}
		}
		if($index>=100) break;//ÿ��ֻ����100��
	}
	return $index;
}

function updateImgCache(){
	$config=DB::fetch_all("select id,name,status from ".DB::table('defaultavatar')." where status=1",null,'id');
	@require_once libfile('function/cache');
	$cacheArray .= "\$config=".arrayeval($config).";\n";
	writetocache('defaultavatar_config', $cacheArray);
}
//From: Dism��taobao��com
?>