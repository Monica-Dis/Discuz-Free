<?php
/*
 * Copyright 2001-2099 DisM!Ӧ������.
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ������� ��ϵDISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
C::t('common_setting')->delete('defaultavatar');
updatecache('setting');
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php')){
	@unlink(DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php');
}
$sql = <<<SQL
DROP TABLE IF EXISTS pre_defaultavatar;
SQL;
runquery($sql);
$finish = TRUE;
?>