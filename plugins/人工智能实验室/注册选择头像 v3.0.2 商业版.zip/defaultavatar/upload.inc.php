<?php
/*
 * Copyright 2001-2099 DisM!应用中心.
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$langvars=lang('plugin/defaultavatar');
//2019.3.27升级流程开始
if($_GET['update']==formhash()&&file_exists(DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php')){
	@require_once DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php';
	$page=max(1,intval($_GET['page']));
	$pagenum=100;
	$config_sub=array_slice($config,$pagenum*($page-1),$pagenum);
	foreach($config_sub as $k=>$pic){
		if(substr($pic['name'],0,5)=='auto_'){
			$f_name=substr($pic['name'],38);
			$dateline=intval(str_replace('.jpg','',$f_name));
		}else{
			$dateline=intval(str_replace(array('avatar_','.jpg'),'',$pic['name']));
		}		
		$pic['dateline']=$dateline;
		DB::insert('defaultavatar',$pic);
	}
	if(count($config_sub)==0){
		updateImgCache();
		cpmsg($langvars['update_ok'],'action=plugins&operation=config&identifier=defaultavatar&pmod=upload', 'succeed');
	}else{
		cpmsg($langvars['update_next'].($pagenum*($page-1)+count($config_sub)),'action=plugins&operation=config&identifier=defaultavatar&pmod=upload&update='.FORMHASH.'&page='.($page+1), 'succeed');
	}	
}
//2019.3.27升级流程结束

$config=array();
if(!file_exists(DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php')){//初始10个头像
	$pics=array(
		'avatar_1403071383.jpg',
		'avatar_1403071725.jpg',
		'avatar_1403071735.jpg',
		'avatar_1403071746.jpg',
		'avatar_1403071764.jpg',
		'avatar_1403071782.jpg',
		'avatar_1403071798.jpg',
		'avatar_1403071814.jpg',
		'avatar_1403071832.jpg',
		'avatar_1403071844.jpg',
	);
	foreach($pics as $k=>$pic){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/defaultavatar/avatar/default/'.$pic)){
			copy(DISCUZ_ROOT.'./source/plugin/defaultavatar/avatar/default/'.$pic,DISCUZ_ROOT.'./source/plugin/defaultavatar/avatar/'.$pic);
			$config[]=$item=array('name'=>$pic,'status'=>1,'dateline'=>TIMESTAMP);
			DB::insert('defaultavatar',$item);
		}
	}
	if($config&&count($config)){
		updateImgCache();
	}
}else{
	@require_once DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php';
}
if(!$_GET['update']&&!submitcheck('submit')){//部分情况下隐藏
	if(file_exists(DISCUZ_ROOT.'./source/plugin/defaultavatar/libs/upload.lib.php')){
		@require_once DISCUZ_ROOT.'./source/plugin/defaultavatar/libs/upload.lib.php';
	}else{
		showformheader("plugins&operation=config&identifier=defaultavatar&pmod=upload&op=addtask","enctype=\"multipart/form-data\" onsubmit=\"retrun false;\"");
		showtableheader($langvars['avatar_new_title'], 'nobottom');	
		showsetting($langvars['avatar_new'], 'avatar','', 'file','',0,$langvars['avatar_new_tips'].'<br><font color="red">'.$langvars['avatar_new_tips_error'].'</font>','onclick="alert(\''.$langvars['avatar_new_tips_error'].'\');return false;"');
		showsubmit('addsubmit');
		showtablefooter(); /*dism _ taobao _ com*/
		showformfooter(); /*dism - taobao - com*/
	}
}

$pagenum=100;
$page=max(1,intval($_GET['page']));
if(submitcheck('submit')){
	$upnum=0;
	foreach($_POST['ids'] as $_id=>$unuse){
		if($_POST['delete'][$_id]){
			@unlink(DISCUZ_ROOT.'./source/plugin/defaultavatar/avatar/'.$v['name']);
			DB::delete('defaultavatar',array('id'=>$_id));
			$upnum++;
			continue;
		}
		if($_POST['select'][$_id]){
			if($config[$_id]['status']==0){
				DB::update('defaultavatar',array('status'=>1),array('id'=>$_id));
				$upnum++;
			}	
		}else{
			if($config[$_id]['status']==1){
				DB::update('defaultavatar',array('status'=>0),array('id'=>$_id));
				$upnum++;
			}	
		}
	}
	if($upnum) updateImgCache();
	cpmsg($langvars['ok'],'action=plugins&operation=config&identifier=defaultavatar&pmod=upload&page='.$page, 'succeed');
}else{
	$count=DB::result_first("select count(*) from ".DB::table('defaultavatar')."");
	if($count==0&&count($config)){//@2019.03.27 升级入库
		cpmsg($langvars['update_do'],'action=plugins&operation=config&identifier=defaultavatar&pmod=upload&update='.FORMHASH, 'succeed');
	}
	$piclist=DB::fetch_all("select * from ".DB::table('defaultavatar')." order by id desc limit ".($pagenum*($page-1)).",$pagenum",null,'id');
	showformheader('plugins&operation=config&identifier=defaultavatar&pmod=upload&page='.$page);
	showtableheader($langvars['config_title'], 'nobottom');
	showsubtitle(array($langvars['key'],$langvars['pic'],$langvars['dateline'],$langvars['status']));
	foreach($piclist as $_id=>$pic){
		if($pic['status']) $check='checked';
		else $check='';
		showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
			"<input class=\"text\" type=\"hidden\" name=\"ids[".$_id."]\" value=\"1\"><input class=\"checkbox\" type=\"checkbox\" name=\"delete[".$_id."]\" value=\"1\">",
			'<img width="48" src="'.$_G['siteurl'].'source/plugin/defaultavatar/avatar/'.$pic['name'].'">',
			dgmdate($pic['dateline'],'Y-m-d H:i:s'),
			"<input class=\"checkbox\" type=\"checkbox\" name=\"select[".$_id."]\" value=\"".$_id."\" $check>",
		));
	}
	showsubmit('submit',$langvars['submit'],$langvars['del'].'<input class="checkbox" type="checkbox" name="groupall" onclick="checkAll(\'prefix\', this.form, \'delete\', \'groupall\')">', '','');
	showtablefooter(); /*dism _ taobao _ com*/
	showformfooter(); /*dism - taobao - com*/
	echo multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=defaultavatar&pmod=upload");
}

function updateImgCache(){
	$config=DB::fetch_all("select id,name,status from ".DB::table('defaultavatar')." where status=1",null,'id');
	@require_once libfile('function/cache');
	$cacheArray .= "\$config=".arrayeval($config).";\n";
	writetocache('defaultavatar_config', $cacheArray);
}
//From: Dism·taobao·com
?>