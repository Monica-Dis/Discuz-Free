<?php
/*
 * Copyright 2001-2099 DisM!Ӧ������.
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ������� ��ϵDISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!file_exists(DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php')){//�ɰ�����
	$config=array();
	if($_G['setting']['defaultavatar']&&$_G['setting']['defaultavatar']!='a:0:{}'){
		$config=unserialize($_G['setting']['defaultavatar']);
	}
	if(count($config)){
		@require_once libfile('function/cache');
		$cacheArray .= "\$config=".arrayeval($config).";\n";
		writetocache('defaultavatar_config', $cacheArray);
	}
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_defaultavatar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL default '0',
  `dateline` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`) USING BTREE
);
EOF;

runquery($sql);
$finish = TRUE;
?>