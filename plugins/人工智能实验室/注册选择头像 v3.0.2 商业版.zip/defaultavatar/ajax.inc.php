<?php
/*
 * Copyright 2001-2099 DisM!应用中心.
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$vars = $_G['cache']['plugin']['defaultavatar'];
if(!checkmobile()) include template('common/header_ajax');
$config=array();
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php')){
	@require_once DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php';
}
$avatars=$config;
foreach($avatars as $k=>$avatar){
	if(!$avatars[$k]['status']) unset($avatars[$k]);
}
if($vars['rand']){
	$vars['randnum']=intval($vars['randnum']);
	if($vars['randnum']&&$vars['randnum']<count($avatars)){
		$rand_keys=array_rand($avatars,$vars['randnum']);
		$a=array();
		foreach($rand_keys as $k=>$v){
			$a[]=$avatars[$v];
		
		}
		$avatars=$a;
	}
}
include template('defaultavatar:ajax');
if(!checkmobile()) include template('common/footer_ajax');
?>