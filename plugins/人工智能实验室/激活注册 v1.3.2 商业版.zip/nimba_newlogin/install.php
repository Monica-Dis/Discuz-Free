<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_nimba_newlogin_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fuid` int(11) NOT NULL,
  `fusername` varchar(25) DEFAULT NULL,  
  `cuid` int(11) NOT NULL,
  `cusername` varchar(25) DEFAULT NULL,    
  `ip` varchar(25) DEFAULT NULL,    
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fuid` (`fuid`) USING BTREE,
  KEY `ip` (`ip`) USING HASH  
);
EOF;
runquery($sql);
$finish = TRUE;

?>