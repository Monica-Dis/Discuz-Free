<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$vars = $_G['cache']['plugin']['nimba_newlogin'];
$starttime=strtotime(trim($vars['starttime']));
$page=max(1,intval($_GET['page']));
$pagenum=20;
if($_GET['uid']){
	$uid=intval(trim($_GET['uid']));
	$fp=intval(trim($_GET['fp']));
	$count=DB::result_first("select count(*) from ".DB::table('nimba_newlogin_logs')." where fuid='$uid'");
	$clickList=DB::fetch_all("select * from ".DB::table('nimba_newlogin_logs')." where fuid='$uid' order by id desc limit ".($pagenum*($page-1)).",$pagenum");
	showtableheader(lang('plugin/nimba_newlogin','title_1').'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do=$pluginid&identifier=nimba_newlogin&pmod=logs&page='.$fp.'"><font color="red">'.lang('plugin/nimba_newlogin','title_2').'</font></a>'.lang('plugin/nimba_newlogin','title_3'), 'nobottom');
	showsubtitle(array(lang('plugin/nimba_newlogin','m_index'),lang('plugin/nimba_newlogin','m_fuser'),lang('plugin/nimba_newlogin','m_cuser'),lang('plugin/nimba_newlogin','m_cip'),lang('plugin/nimba_newlogin','m_ctime')));
	require_once libfile('function/misc');	
	foreach($clickList as $k=>$log){
		$myadd=convertip($log['ip']);
		$myadd=str_replace('-','',$myadd);
		$myadd=str_replace(' ','',$myadd);		
		showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"','','',''), array(
			$k+1+($page-1)*$pagenum,
			'<a href="home.php?mod=space&uid='.$log['fuid'].'" target="_blank">'.$log['fusername'].'</a>',
			$log['cuid']? '<a href="home.php?mod=space&uid='.$log['cuid'].'" target="_blank">'.$log['cusername'].'</a>':lang('plugin/nimba_newlogin','youke'),
			$log['ip'].'('.$myadd.')',
			dgmdate($log['dateline'],'Y-m-d H:i:s'),
		));
	}
	showtablefooter(); /*Dism��taobao��com*/	
	echo multi($count, $pagenum, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_newlogin&pmod=logs&fp=$fp&uid=$uid");
}else{
	$count=DB::result_first("select count(*) from ".DB::table('common_member')." where regdate>='$starttime' ");
	$memberlist=DB::fetch_all("select uid,username,regdate from ".DB::table('common_member')." where regdate>='$starttime' order by uid desc limit ".($pagenum*($page-1)).",$pagenum");
	showtableheader(lang('plugin/nimba_newlogin','title_4'), 'nobottom');
	showsubtitle(array('UID',lang('plugin/nimba_newlogin','m_user'),lang('plugin/nimba_newlogin','m_regdate'),lang('plugin/nimba_newlogin','m_click'),lang('plugin/nimba_newlogin','m_detail')));
	foreach($memberlist as $k=>$log){
		$clicknum=DB::result_first("select count(*) from ".DB::table('nimba_newlogin_logs')." where fuid='$log[uid]'");
		showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"','','',''), array(
			$log['uid'],
			'<a href="home.php?mod=space&uid='.$log['uid'].'" target="_blank">'.$log['username'].'</a>',
			dgmdate($log['regdate'],'Y-m-d H:i:s'),
			$clicknum,
			'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do=$pluginid&identifier=nimba_newlogin&pmod=logs&fp='.$page.'&uid='.$log['uid'].'">'.lang('plugin/nimba_newlogin','m_view').'</a>',
		));
	}
	showtablefooter(); /*Dism��taobao��com*/	
	echo multi($count, $pagenum, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_newlogin&pmod=logs");
}
//From: Dism_taobao-com
?>