<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_nimba_romotepic {
	function  __construct() {
	    loadcache('plugin');
		global $_G;
		$vars = $_G['cache']['plugin']['nimba_romotepic'];
		$this->uids=explode(",",$this->vars['uids']);
		$this->open=intval($vars['open']);
		$this->portal=intval($vars['portal']);
		$this->portalpic=intval($vars['portalpic']);
		$this->selection=intval($vars['selection']);
		$this->minsize=intval($vars['minsize'])*1024;
		$this->siteurl=trim($vars['siteurl']);
		$this->forum=unserialize($vars['forum']);
		$this->group=unserialize($vars['group']);
		$this->timeDir=dgmdate(TIMESTAMP,'Ym/d/');
		$this->timeDirPath=dgmdate(TIMESTAMP,'Ym/d/His');
	}
	
	function downloadpic($src,$localurl){
	    if(!(file_exists($localurl)||copy($src,$localurl))){
			$content=dfsockopen($src);
			$this->pluginCache('src_content','content',strlen($content),0);
			if($content){
				$fp=fopen($localurl,"w");
				fwrite($fp,$content);
				fclose($fp);
			}
	    }
		if(file_exists($localurl)){
			if($content) return strlen($content);
			else return filesize($localurl);
		}
	    return false;
    }
	
	function fileext($filename) {
		return addslashes(strtolower(substr(strrchr($filename, '.'), 1, 10)));
	}	
	
	function pluginCache($cacheName,$varName,$data,$isarray){
		@require_once libfile('function/cache');
		if($isarray){
			$cacheArray .= "\$$varName=".arrayeval($data).";\n";
			writetocache($cacheName, $cacheArray);
		}else{
			$cacheArray .= "\$$varName=".$data.";\n";
			writetocache($cacheName, $cacheArray);
		}
	}	
}

class plugin_nimba_romotepic_forum extends plugin_nimba_romotepic{
	function loadForumCheckbox(){
		global $_G;
		$return = '';		
		if($_G['uid']&&$this->open&&in_array($_G['groupid'],$this->group)&&in_array($_G['fid'],$this->forum)){
		    include template('nimba_romotepic:post_newthread');
		}
		return $return;
	}
	
	function post_middle_output(){//��������ҳ,�ظ�ҳ
		return $this->loadForumCheckbox();
	}
	
	function forumdisplay_fastpost_btn_extra_output(){//�б�ҳ���ٷ���
		return $this->loadForumCheckbox();
	}

	function viewthread_fastpost_btn_extra(){//����ҳ���ٻظ�
		return $this->loadForumCheckbox();
	}
	
    function post_getromotepic(){
	    global $_G;
		$down=intval($_GET['romotepic']);		
		$siteurl=$this->siteurl? $_G['siteurl']:$this->siteurl;
		if($down&&$this->open&&in_array($_G['groupid'],$this->group)&&in_array($_G['fid'],$this->forum)){
		   if(preg_match_all("/\[img[^\]]*\](.*)\[\/img\]/isU",$_GET['message'],$result)){//ƥ��[img]
				$this->pluginCache('src_result','result',$result,1);
			    foreach ($result[1] as $key=>$src){
				    $src=trim($src);
					if(substr($src,0,2)=='//') $src='http:'.$src;//ǿ��ʹ��http
				    if((stripos($src,$siteurl)==true)||(substr($src,0,7)!='http://'&&substr($src,0,8)!='https://')) continue;
					$ext=$this->fileext($src);
					if (!in_array($ext, array('jpg','jpeg','gif','png','bmp'))) {
						$ext = 'jpg';
					}
					require_once libfile('class/image');
					$romoteimage = new image;
					$this->checkattachdir();
					$localattachment=$this->timeDirPath.strtolower(random(16)).'.'.$ext;
					$localurl=$_G['setting']['attachdir']."/forum/".$localattachment;//���·��
					$attachsavedsize=$this->downloadpic($src,$localurl);
					if($attachsavedsize){
						$watermarkstatus=unserialize($_G['setting']['watermarkstatus']);
						if($watermarkstatus['forum'] && empty($_G['forum']['disablewatermark'])) {
							$romoteimage->Watermark($localurl);
						}
						//��֯����	
						$pinfo=getimagesize($localurl);
						$width=$pinfo[0];
						$path_parts = pathinfo($src);
						$filename=$path_parts['filename'].'.'.$ext;//ԭʼ�ļ���
						$filesize=$attachsavedsize;
						$isimage=1;
						$remote=0;
						$thumb=0;
						//���븽��
						$aid=C::t('forum_attachment')->insert(array('aid'=>NULL,'tid'=>'0','pid'=>'0','uid'=>$_G['uid'],'tableid'=>'127','downloads'=>'0'),true);
						C::t('forum_attachment_unused')->insert(array('aid'=>$aid,'uid'=>$_G['uid'],'dateline'=>$_G['timestamp'],'filename'=>$filename,'filesize'=>$filesize,'attachment'=>$localattachment,'remote'=>$remote,'isimage'=>$isimage,'width'=>$width,'thumb'=>$thumb));
						$_GET['attachnew'][$aid]=array();
						$strfirst = strpos($_GET['message'],$result[0][$key]);
						if ($strfirst !== false){
							$_GET['message']=substr_replace($_GET['message'],'[attachimg]'.$aid.'[/attachimg]', $strfirst, strlen($result[0][$key]));
						}
					}				
			    }
		    }
		}
	}
	
	function checkattachdir() {
	    global $_G;
		if(!is_dir($_G['setting']['attachdir']."/forum/".$this->timeDir)) dmkdir($_G['setting']['attachdir']."/forum/".$this->timeDir);
	}
}

class plugin_nimba_romotepic_group extends plugin_nimba_romotepic_forum{
	function loadGroupCheckbox(){
		global $_G;
		$return = '';		
		if($_G['uid']&&$this->open&&in_array($_G['groupid'],$this->group)){
		    include template('nimba_romotepic:post_newthread');
		}
		return $return;
	}
	
	function post_middle_output(){//��������ҳ,�ظ�ҳ
		return $this->loadGroupCheckbox();
	}
	
	function forumdisplay_fastpost_btn_extra_output(){//�б�ҳ���ٷ���
		return $this->loadGroupCheckbox();
	}

	function viewthread_fastpost_btn_extra(){//����ҳ���ٻظ�
		return $this->loadGroupCheckbox();
	}
	
    function post_getromotepic(){
	    global $_G;
		$down=intval($_GET['romotepic']);		
		$siteurl=$this->siteurl? $_G['siteurl']:$this->siteurl;
		if($down==1&&$this->open&&in_array($_G['groupid'],$this->group)){
		   if(preg_match_all("/\[img[^\]]*\](.*)\[\/img\]/isU",$_GET['message'],$result)){//ƥ��[img]
			    foreach ($result[1] as $key=>$src){
				    $src=trim($src);
					if(substr($src,0,2)=='//') $src='http:'.$src;//ǿ��ʹ��http
				    if((stripos($src,$siteurl)==true)||(substr($src,0,7)!='http://'&&substr($src,0,8)!='https://')) continue;
					$ext=$this->fileext($src);
					if (!in_array($ext, array('jpg','jpeg','gif','png','bmp'))) {
						$ext = 'jpg';
					}
					require_once libfile('class/image');
					$romoteimage = new image;
					$this->checkattachdir();
					$localattachment=$this->timeDirPath.strtolower(random(16)).'.'.$ext;
					$localurl=$_G['setting']['attachdir']."/forum/".$localattachment;//���·��
					$attachsavedsize=$this->downloadpic($src,$localurl);
					if($attachsavedsize){
						$watermarkstatus=unserialize($_G['setting']['watermarkstatus']);
						if($watermarkstatus['forum'] && empty($_G['forum']['disablewatermark'])) {
							$romoteimage->Watermark($localurl);
						}
						//��֯����							
						$pinfo=getimagesize($localurl);
						$width=$pinfo[0];
						$path_parts = pathinfo($src);
						$filename=$path_parts['filename'].'.'.$ext;//ԭʼ�ļ���
						$filesize=$attachsavedsize;
						$isimage=1;
						$remote=0;
						$thumb = $romoteimage->Thumb($localurl,'',$_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], $_G['setting']['thumbsource'])? 1:0;
						//���븽��
						$aid=C::t('forum_attachment')->insert(array('aid'=>NULL,'tid'=>'0','pid'=>'0','uid'=>$_G['uid'],'tableid'=>'127','downloads'=>'0'),true);
						C::t('forum_attachment_unused')->insert(array('aid'=>$aid,'uid'=>$_G['uid'],'dateline'=>$_G['timestamp'],'filename'=>$filename,'filesize'=>$filesize,'attachment'=>$localattachment,'remote'=>$remote,'isimage'=>$isimage,'width'=>$width,'thumb'=>$thumb));
						$_GET['attachnew'][$aid]=array();
						$strfirst = strpos($_GET['message'],$result[0][$key]);
						if ($strfirst !== false){
							$_GET['message']=substr_replace($_GET['message'],'[attachimg]'.$aid.'[/attachimg]', $strfirst, strlen($result[0][$key]));
						}
					}				
			    }
		    }
		}
	}
}

class plugin_nimba_romotepic_portal extends plugin_nimba_romotepic{
	function portalcp_middle(){
		global $_G;
		$return = '';
		if($_G['uid']&&$this->open&&$this->portal){
		    include template('nimba_romotepic:post_newthread');
		}
		return $return;
	}
	
	function portalcp_fromthread_output($var){
		global $_G,$aid,$op;
		$down=intval($_POST['romotepic']);
		$siteurl=$this->siteurl? $_G['siteurl']:$this->siteurl;
		if(submitcheck('articlesubmit')){
			if($op=='add_success'&&$aid&&$down){
				$pic='';
				$con=C::t('portal_article_content')->fetch_all($aid);
				foreach($con as $k=>$p){
					$content=$p['content'];
					$page=intval($p['pageorder']);
					if(preg_match_all("/<img([^>]*)\s*src=['|\"]([^'\"]+)['|\"]/isU",$content,$result)){//ƥ��[img]
						foreach ($result[2] as $key=>$src){
							if(substr($src,0,2)=='//') $src='http:'.$src;//ǿ��ʹ��http
							if((stripos($src,$siteurl)==true)||(substr($src,0,7)!='http://'&&substr($src,0,8)!='https://')) continue;
							$ext=$this->fileext($src);
							if (!in_array($ext, array('jpg','jpeg','gif','png','bmp'))) {
								$ext = 'jpg';
							}	
							require_once libfile('class/image');
							$romoteimage = new image();
							$this->checkPortalAttachDir();
							$localattachment=$this->timeDirPath.strtolower(random(16)).'.'.$ext;
							$localurl=$_G['setting']['attachdir']."/portal/".$localattachment;//���·��
							$attachsavedsize=$this->downloadpic($src,$localurl);
							if($attachsavedsize){//��֯����
								$watermarkstatus=unserialize($_G['setting']['watermarkstatus']);
								if($watermarkstatus['portal']){
									$romoteimage->Watermark($localurl);
								}
								$thumbimgwidth = $_G['setting']['portalarticleimgthumbwidth'] ? $_G['setting']['portalarticleimgthumbwidth'] : 300;
								$thumbimgheight = $_G['setting']['portalarticleimgthumbheight'] ? $_G['setting']['portalarticleimgthumbheight'] : 300;	
								$isthumb = $romoteimage->Thumb($localurl, '', $thumbimgwidth, $thumbimgheight, 2);
								$path_parts = pathinfo($src);
								$picname=$path_parts['filename'];
								$filename=$picname.'.'.$ext;//ԭʼ�ļ���
								$data=array(
									'uid'=>$_G['uid'],
									'dateline'=>time(),
									'filename'=>$filename,
									'filetype'=>'jpg',
									'filesize'=>$attachsavedsize,
									'attachment'=>$localattachment,
									'thumb'=>$isthumb,
									'isimage'=>'1',
									'aid'=>$aid,
								);
								//���븽��
								$attachid=C::t('portal_attachment')->insert($data,true);
								$content=str_replace($src,'data/attachment/portal/'.$localattachment,$content);
								if(!$pic) $pic='portal/'.$localattachment.($isthumb? '.thumb.jpg':'');
							}											
						}
						DB::update('portal_article_content',array('content'=>$content), array('aid' => $aid,'pageorder'=>$page));
					}
				}
				if($pic&&$this->portalpic) DB::update('portal_article_title',array('pic'=>$pic), array('aid' => $aid));
			}
		}
	}
	

	
	function checkPortalAttachDir() {
	    global $_G;
		if(!is_dir($_G['setting']['attachdir']."/portal/".$this->timeDir)) dmkdir($_G['setting']['attachdir']."/portal/".$this->timeDir);
	}	
}
//From: d'.'is'.'m.ta'.'obao.com
?>