<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_nimba_spider {
	function global_footer_mobile(){
		loadcache('plugin');
		global $_G;
		$var= $_G['cache']['plugin']['nimba_spider'];
		if($var['open']){
			$mod='';//记录版块和帖子备用
			if($_GET['mod']=='forumdisplay'&&!empty($_G['fid'])) $mod='forum';
			if($_GET['mod']=='viewthread'&&!empty($_G['tid'])) $mod='thread';
			include_once 'libs/spider.lib.php';
		}
	}
}
//From: Dism·taobao·com
?>