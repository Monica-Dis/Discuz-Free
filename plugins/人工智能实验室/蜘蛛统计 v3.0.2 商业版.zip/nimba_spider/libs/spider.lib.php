<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$agent=$_SERVER['HTTP_USER_AGENT'];
$referer=$_SERVER['HTTP_REFERER'];
$domain=$_SERVER['HTTP_HOST'];
$url=$_SERVER['REQUEST_URI'];
$ip=empty($_SERVER['HTTP_X_FORWARDED_FOR'])? $_G['clientip']:$_SERVER['HTTP_X_FORWARDED_FOR'];
$dateline=time();
$baidu=stristr($agent,"Baiduspider");
$google=stristr($agent,"Googlebot");
$youdao=stristr($agent,"YoudaoBot");
$bing=stristr($agent,"bingbot");
$sogou=stristr($agent,"Sogou web spider");
$yahoo=stristr($agent,"Yahoo! Slurp");
$Alexa=stristr($agent,"Alexa");
$so=stristr($agent,"HaoSouSpider")+stristr($agent,"360spider");
$sm=stristr($agent,"YisouSpider");
$toutiao=stristr($agent,"Bytespider");
if($baidu){
    if($var['baidu']) $agent="baidu";
	else $agent=null;
}
elseif($google){
    if($var['google']) $agent="Google";
	else $agent=null;
}
elseif($youdao){
    if($var['youdao']) $agent="youdao";
	else $agent=null;
}
elseif($bing){
    if($var['bing']) $agent="bing";
	else $agent=null;
}
elseif($sogou){
    if($var['sogou']) $agent="sogou";
	else $agent=null;
}
elseif($yahoo){
    if($var['yahoo']) $agent="yahoo";
	else $agent=null;
}
elseif($Alexa){
    if($var['alexa']) $agent="Alexa";
	else $agent=null;
}
elseif($so){
    if($var['s360']) $agent="so";
	else $agent=null;
}
elseif($sm){
    if($var['sm']) $agent="sm";
	else $agent=null;
}
elseif($so){
    if($var['toutiao']) $agent="toutiao";
	else $agent=null;
}elseif($spiderlist=trim($var['spiderlist'])){
	$spiderlist=explode('/hhf/',str_replace(array("\r\n","\r","\n"),'/hhf/',$spiderlist));
	foreach($spiderlist as $k=>$line){
		$line=explode('|',trim($line));
		$line[0]=trim($line[0]);
		if($line[0]&&stristr($agent,$line[0])){
			$zdy=$line[0];
			break;
		}
	}
	if($zdy) $agent=$zdy;
	else $agent=null;
}else{
    $agent=null;
}

//$test=array('baidu','google','sogou','yahoo','bing','youdao','alexa','so','sm','toutiao','Applebot','YandexBot','DotBot','testBot');
//if(!$agent) $agent=$test[rand(0,count($test)-1)];

if(!substr_count($url,'misc.php')&&$agent){
	$fid=0;
	$tid=0;
	if($mod=='forum') $fid=$_G['fid'];
	if($mod=='thread') $tid=$_G['tid'];
	$isHTTPS = ($_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) != 'off') ? true : false;
	$http_type = 'http'.($isHTTPS ? 's://' : '://');		
	$url=$http_type.$domain.$url;
	DB::query("insert into ".DB::table('nimba_spider')." (spidername,spiderip,dateline,url,fid,tid,status) values ('$agent','$ip','$dateline','$url','$fid','$tid',1)");
}
//From: dis'.'m.tao'.'bao.com
?>