<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sipders=array('baidu','google','sogou','yahoo','bing','youdao','alexa','so','sm','toutiao');
loadcache('plugin');
$spiderlist=trim($_G['cache']['plugin']['nimba_spider']['spiderlist']);
$spiderlist=explode('/hhf/',str_replace(array("\r\n","\r","\n"),'/hhf/',$spiderlist));
$spidertitle=array();
foreach($spiderlist as $k=>$line){
	$line=explode('|',trim($line));
	$line[0]=trim($line[0]);
	$line[1]=trim($line[1]);
	if(!$line[1]) $line[1]=$line[0];
	if($line[0]){
		$sipders[]=$line[0];
		$spidertitle[$line[0]]=$line[1];
	}
}
if($_G['cache']['plugin']['nimba_spider']['startday']){
	$mindateline=strtotime($_G['cache']['plugin']['nimba_spider']['startday']);
}else{
	$mindateline=intval(DB::result_first("SELECT min(dateline) FROM ".DB::table('nimba_spider')." "));
}


echo '<table class="tb tb2 " id="tips">
	<tr>
	<th  class="partition">'.lang('plugin/nimba_spider','tip3').date('Y-m-d H:i:s',$mindateline).lang('plugin/nimba_spider','tip2').date('Y-m-d H:i:s',TIMESTAMP).' 
	</th>
	</tr>
	</table>';
$sipderdata=array();
$max=1;
$allnum=0;
foreach($sipders as $k=>$sipder){
	$sipderdata[$sipder]=intval(DB::result_first("SELECT COUNT(*) FROM ".DB::table('nimba_spider')." WHERE spidername='$sipder' and dateline>='$mindateline'"));/*+rand(1,$k*10000)*/
	$allnum+=$sipderdata[$sipder];
	$max=max($max,$sipderdata[$sipder]);
}
//From: dis'.'m.tao'.'bao.com
?>
<style>
.graph{width:100%;background: #FBFCE2;padding:30px 20px;}
.slist{}
.slist td{color:#333;height:30px;margin:50px;}
.slist td span.right{color:#fff;float:right;padding-right:10px;}
.slist .itag-0{background-color:#4083AF}
.slist .itag-1{background-color:#29B60D}
.slist .itag-2{background-color:#6D3353}
.slist .itag-3{background-color:#FF6600}
.slist .itag-4{background-color:#2D89EF}
.slist .itag-5{background-color:#2B9646}
.slist .itag-6{background-color:#D30D15}
.slist .itag-7{background-color:#D1AD03}
.slist .itag-8{background-color:#567E95}
.slist .itag-9{background-color:#00ABA9}
.slist .itag-10{background-color:#FB4F4F}
.slist .itag-11{background-color:#FFAA7F}
.slist .itag-12{background-color:#8B8B8B}
.slist .itag-13{background-color:#4BD352}
.slist .itag-14{background-color:#FF09FF}
.slist .itag-15{background-color:#FF6A6A}
.slist .itag-16{background-color:#00B700}
.slist .itag-17{background-color:#0080FF}
.slist .itag-18{background-color:#8080C0}
.slist .itag-19{background-color:#804040}
</style>
	<div class="graph">
		<table class="slist" border="1" bordercolor="#cccccc" style="border-collapse:collapse;">
<?php 
$rate=array();
$index=0;
foreach($sipderdata as $sipder=>$data){
	echo '<tr><td width=100><span class="left">'.($spidertitle[$sipder]? $spidertitle[$sipder]:lang('plugin/nimba_spider',$sipder)).'('.$data.')</span></td>';
	$rate[$sipder]=round(100*$data/$max,2);
	if($data) echo '<td width=760><div class="itag-'.($index%20).'" style="width:'.$rate[$sipder].'%;">&nbsp;<span class="right">'.$data.'</span></div></td></tr>';
	else echo '<td width=760></td></tr>';
	$index++;
}
//From: dis'.'m.tao'.'bao.com
?>
		</table>
	</div>

