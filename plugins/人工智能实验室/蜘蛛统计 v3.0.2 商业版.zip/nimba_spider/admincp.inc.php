<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$op=addslashes($_GET['op']);
if($op=='deleteall'){
	$query = DB::query("TRUNCATE TABLE ".DB::table('nimba_spider')."");
	ajaxshowheader();
	echo lang('plugin/nimba_spider','deleted');
	ajaxshowfooter();
}elseif($op=='delete'){
	DB::delete('nimba_spider',array('id'=>intval($_GET['id'])));
	ajaxshowheader();
	echo lang('plugin/nimba_spider','deleted');
	ajaxshowfooter();
}else{
	$pagenum = 20;
	$page=max(1,intval($_GET['page']));
	$i=1;
	$resultempty = FALSE;
	$where=$extra='';
	if(!empty($_GET['spider'])) {
		$spider = addslashes($_GET['spider']);
		$where = " AND spidername='$spider'";
		$extra = '&spider='.$spider;
	}else{
		$spider='';
	}
	$spiderlist=trim($_G['cache']['plugin']['nimba_spider']['spiderlist']);
	$spiderlist=explode('/hhf/',str_replace(array("\r\n","\r","\n"),'/hhf/',$spiderlist));
	$title_add='';
	foreach($spiderlist as $k=>$line){
		$line=explode('|',trim($line));
		$line[0]=trim($line[0]);
		$line[1]=trim($line[1]);
		if(!$line[1]) $line[1]=$line[0];
		if($line[0]){
			$title_add.=' | <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&spider='.$line[0].'"><font color="'.mkcolor($line[0],$spider).'">'.$line[1].'</font></a>';
		}
	}	
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('nimba_spider')." WHERE 1 $where");
	$data = DB::fetch_all("SELECT * FROM ".DB::table('nimba_spider')." WHERE 1 $where ORDER BY id DESC LIMIT ".(($page - 1) * $pagenum).",$pagenum");
	showtableheader(lang('plugin/nimba_spider','tip').' 
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp"><font color="'.mkcolor('',$spider).'">'.lang('plugin/nimba_spider','all').'</font></a> | 
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&spider=baidu"><font color="'.mkcolor('baidu',$spider).'">'.lang('plugin/nimba_spider','baidu').'</font></a> | 
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&spider=google"><font color="'.mkcolor('google',$spider).'">'.lang('plugin/nimba_spider','google').'</font></a> | 
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&spider=sogou"><font color="'.mkcolor('sogou',$spider).'">'.lang('plugin/nimba_spider','sogou').'</font></a> | 
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&spider=yahoo"><font color="'.mkcolor('yahoo',$spider).'">'.lang('plugin/nimba_spider','yahoo').'</font></a> | 
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&spider=bing"><font color="'.mkcolor('bing',$spider).'">'.lang('plugin/nimba_spider','bing').'</font></a> | 
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&spider=youdao"><font color="'.mkcolor('youdao',$spider).'">'.lang('plugin/nimba_spider','youdao').'</font></a> | 
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&spider=Alexa"><font color="'.mkcolor('Alexa',$spider).'">'.lang('plugin/nimba_spider','alexa').'</font></a> | 
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&spider=so"><font color="'.mkcolor('so',$spider).'">'.lang('plugin/nimba_spider','s360').'</font></a> | 
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&spider=sm"><font color="'.mkcolor('sm',$spider).'">'.lang('plugin/nimba_spider','sm').'</font></a> | 
		<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&spider=toutiao"><font color="'.mkcolor('toutiao',$spider).'">'.lang('plugin/nimba_spider','toutiao').'</font></a>'.$title_add);
		
	showsubtitle(array(lang('plugin/nimba_spider','type'),lang('plugin/nimba_spider','ip'),lang('plugin/nimba_spider','dateline'),lang('plugin/nimba_spider','url'),'<a id="p'.$i.'" onclick="ajaxget(this.href, this.id, \'\');return false" href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&op=deleteall">'.lang('plugin/nimba_spider','deleteall').'</a>'));
	foreach($data as $item){
		showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
			$item['spidername'],
			$item['spiderip'],
			date('Y-m-d H:i:s',$item['dateline']),
			'<a href='.$item['url'].' target="_blank">'.$item['url'].'</a></td>',
			'<a id="s'.$i.'" onclick="ajaxget(this.href, this.id, \'\');return false" href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_spider&pmod=admincp&op=delete&id='.$item['id'].'">'.lang('plugin/nimba_spider','delete').'</a>',
		));
		$i++;
	}
	showtablefooter();/*dism _ taobao _ com*/
	echo multi($count, $pagenum, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_spider&pmod=admincp$extra");
}

function mkcolor($local,$now){
	if($local==$now){
		return 'red';
	}else{
		return 'blue';
	}
}
//From: dis'.'m.tao'.'bao.com
?>