<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//From: dis'.'m.tao'.'bao.com
?>
<iframe src="http://api.open.ailab.cn/addon/?from=nimba_addclick" width="100%" height="2000" frameborder="0" scrolling="no" style="min-width:870px;margin-left:-3px; background:#F4FAFD" ></iframe> 