<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_nimba_addclick {
	function  __construct() {
		global $_G;
	    loadcache('plugin');
		$this->vars = $_G['cache']['plugin']['nimba_addclick'];
		$this->thread=intval($this->vars['thread']);
		$this->article=intval($this->vars['article']);
		$this->forums=unserialize($this->vars['forums']);
		$this->addnum=intval($this->vars['addnum']);
		$this->forumnum=trim($this->vars['forumnum']);
		$this->addrand=intval($this->vars['addrand']);
		$this->maxnum=intval($this->vars['maxnum']);
		$this->clearcache=intval($this->vars['clearcache']);
		$this->noreload=intval($this->vars['noreload']);
		$this->uids=explode(',',trim($this->vars['uids']));
		$this->tids=explode(',',trim($this->vars['tids']));
		$this->forumnum();
	}
	function forumnum(){
		$res=array();
		$this->forumnum= explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$this->forumnum));
		foreach($this->forumnum as $k=>$f){
			$f=explode('=',trim($f));
			if(count($f)==2){
				$res[intval($f[0])]=intval($f[1]);
			}
		}
		$this->forumnum=$res;
	}
	
	function doClick($id,$mod){
		global $_G;
		if(rand(1,100)>$this->addrand) return '';
		if($mod=='thread'){
			$add=isset($this->forumnum[$_G['fid']])? $this->forumnum[$_G['fid']]:$this->addnum;
			$this->_viewthread_updateviews($_G['forum_thread']['threadtableid'],$add);
		}elseif($mod=='article'){
			if(!$this->noreload || $_G['cookie']['nimba_addclick_view_aid'] != 'aid_'.$id) {//防刷新
				$add=$this->addnum;
				C::t('portal_article_count')->increase(array($id), array('viewnum'=>$add));
				dsetcookie('nimba_addclick_view_aid', 'aid_'.$id);
			}
		}
	}
	
	function _viewthread_updateviews($tableid,$add) {
		global $_G;
		if(!$tableid&&!$add) return '';
		if(!$this->noreload || $_G['cookie']['nimba_addclick_viewid'] != 'tid_'.$_G['tid']) {//防刷新
			if(!$tableid && $_G['setting']['optimizeviews']) {
				if($_G['forum_thread']['addviews']) {
					if($_G['forum_thread']['addviews'] < 100) {
						C::t('forum_threadaddviews')->update_by_tid($_G['tid']);
					} else {
						if(!discuz_process::islocked('update_thread_view')) {
							$row = C::t('forum_threadaddviews')->fetch($_G['tid']);
							C::t('forum_threadaddviews')->update($_G['tid'], array('addviews' => 0));
							C::t('forum_thread')->increase($_G['tid'], array('views' => $row['addviews']+$add), true);
							discuz_process::unlock('update_thread_view');
						}
					}
				} else {
					C::t('forum_threadaddviews')->insert(array('tid' => $_G['tid'], 'addviews' => $add), false, true);
				}
			} else {
				C::t('forum_thread')->increase($_G['tid'], array('views' => $add), true, $tableid);
			}
		}
		dsetcookie('nimba_addclick_viewid', 'tid_'.$_G['tid']);
	}
}

class mobileplugin_nimba_addclick_forum extends mobileplugin_nimba_addclick{
	function viewthread_top_mobile(){//手机版 帖子
		global $_G;
		if($this->thread==0) return '';
		if(!in_array($_G['fid'],$this->forums)) return '';
		if($this->maxnum!=0&&$_G['thread']['views']>=$this->maxnum) return '';
		if($this->uids&&in_array($_G['thread']['authorid'],$this->uids)) return '';
		if($this->tids&&in_array($_G['thread']['tid'],$this->tids)) return '';		
		$this->doClick($_G['tid'],'thread');
		if($this->clearcache) C::t('forum_thread')->clear_cache($_G['tid']);
		return '';	
	}
}

class mobileplugin_nimba_addclick_portal extends mobileplugin_nimba_addclick{
	function view_article_content_mobile_output(){//手机版 文章
		global $_G,$content,$article;
		if($this->article==0) return '';
		if($this->maxnum!=0&&$article['viewnum']>=$this->maxnum) return '';
		$aid=intval($_GET['aid']);
		if(!$aid) return '';
		$this->doClick($aid,'article');
		if($this->clearcache) C::t('portal_article_count')->clear_cache($aid);
		return '';
	}
}
//From: Dism·taobao·com
?>