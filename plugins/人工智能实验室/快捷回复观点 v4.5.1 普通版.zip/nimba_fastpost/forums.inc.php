<?php
/*
 * 主页：https://dism.taobao.com/?@1552.developer
 * 人工智能实验室：Discuz!应用中心十大优秀开发者！
 * 插件定制 联系QQ594941227
 * From www.ailab.cn
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/discuz_version.php';
loadcache('plugin');
$cachename='vipforums';
$filepath=DISCUZ_ROOT.'./data/sysdata/cache_nimba_vipforums.php';
if(DISCUZ_VERSION=='X2') $filepath=DISCUZ_ROOT.'./data/cache/cache_nimba_vipforums.php';
if(file_exists($filepath)) @include_once $filepath;
$forumarray=(array)unserialize($_G['cache']['plugin']['nimba_fastpost']['forum']);
$forums=(array)unserialize($_G['cache']['plugin']['nimba_fastpost']['vipforums']);
if(submitcheck('forumssubmit')){
	foreach($forums as $k=>$fid){
		$forum['fid']=$fid;
		$forum['forumtips']=trim($_POST['forumtip'.$fid]);
		if($forum['forumtips']) $vipforums[$fid]=$forum;
		else unset($vipforums[$fid]);
	}
	if($vipforums) wcache($cachename,$vipforums);
	cpmsg(lang('plugin/nimba_fastpost','updated'),'action=plugins&operation=config&do=$pluginid&identifier=nimba_fastpost&pmod=forums', 'succeed');
}else{
	if(file_exists(DISCUZ_ROOT.'source/plugin/nimba_fastpost/libs/forums.lib.php')){
		include DISCUZ_ROOT.'source/plugin/nimba_fastpost/libs/forums.lib.php';	
	}else{
		echo lang('plugin/nimba_fastpost','noright');
	}
}

function wcache($name,$data,$uid=''){
	@require_once libfile('function/cache');
	$cacheArray .= "\$$name=".arrayeval($data).";\n";
	writetocache('nimba_'.$name.$uid, $cacheArray);		
}
//From: Dism_taobao_com
?>