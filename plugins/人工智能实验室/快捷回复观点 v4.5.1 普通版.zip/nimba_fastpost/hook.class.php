<?php
/*
 * 主页：https://dism.taobao.com/?@1552.developer
 * 人工智能实验室：Discuz!应用中心十大优秀开发者！
 * 插件定制 联系QQ594941227
 * From www.ailab.cn
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_nimba_fastpost{
	function  __construct() {
		global $_G;
	    loadcache('plugin');
		$vars = $_G['cache']['plugin']['nimba_fastpost'];
		$this->open=intval($vars['open']);
		if($this->open){
			$this->tip=lang('plugin/nimba_fastpost','tip');
			$this->tip2=lang('plugin/nimba_fastpost','tip2');
			$this->tiplist=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$vars['fasttip']));
			$this->group=unserialize($vars['group']);
			$this->forum =unserialize($vars['forum']);
			$this->vipforums =unserialize($vars['vipforums']);
			if(in_array($_G['groupid'],$this->group)&&in_array($_G['fid'],$this->forum)){
				require_once DISCUZ_ROOT.'./source/discuz_version.php';
				$filepath=DISCUZ_ROOT.'./data/sysdata/cache_nimba_vipforums.php';
				if(DISCUZ_VERSION=='X2') $filepath=DISCUZ_ROOT.'./data/cache/cache_nimba_vipforums.php';
				if(file_exists($filepath)&&file_exists(DISCUZ_ROOT.'source/plugin/nimba_fastpost/libs/forums.lib.php')){
					@include_once $filepath;	
					if($_G['fid']&&in_array($_G['fid'],$this->vipforums)&&in_array($_G['fid'],$this->forum)){
						if($vipforums[$_G['fid']]['forumtips']){
							$this->tiplist=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',trim($vipforums[$_G['fid']]['forumtips'])));
						}
					}
				}
			}
			$this->style=intval($vars['style']);
			$this->rand=intval($vars['rand']);
			if($this->rand){
				shuffle($this->tiplist);
				//var_dump($this->tiplist);
			}
		}
	} 
}

class plugin_nimba_fastpost_forum extends plugin_nimba_fastpost{ 
    function viewthread_fastpost_content(){
		global $_G;
		$return='';
		if($this->open&&in_array($_G['groupid'],$this->group)&&in_array($_G['fid'],$this->forum)){
			include template('nimba_fastpost:fastpost');
		}
		return $return;
	}
	
    function post_infloat_top(){
		global $_G;	
		$return='';
		if($this->open&&in_array($_G['groupid'],$this->group)&&in_array($_G['fid'],$this->forum)){
			include template('nimba_fastpost:float');
		}
		return $return;
	}
}
//From: Dism·taobao·com
?>