<?php
/*
 * 主页：https://dism.taobao.com/?@1552.developer
 * 人工智能实验室：Discuz!应用中心十大优秀开发者！
 * 插件定制 联系QQ594941227
 * From www.ailab.cn
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(file_exists(DISCUZ_ROOT.'./data/cache/cache_nimba_vipforums.php')) @unlink(DISCUZ_ROOT.'./data/cache/cache_nimba_vipforums.php');
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_nimba_vipforums.php')) @unlink(DISCUZ_ROOT.'./sysdata/cache/cache_nimba_vipforums.php');
$identifier = 'nimba_fastpost';
if(!function_exists('cloudaddons_deltree')) require libfile('function/cloudaddons');
cloudaddons_deltree(DISCUZ_ROOT .'./source/plugin/'.$identifier.'/');
$finish = TRUE;

?>