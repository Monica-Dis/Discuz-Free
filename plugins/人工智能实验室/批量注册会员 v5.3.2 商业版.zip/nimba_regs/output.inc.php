<?php
/*
 * 主页：https://dism.taobao.com/?@1552.developer
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(file_exists(DISCUZ_ROOT.'./source/plugin/nimba_regs/libs/output.lib.php')){
	@require_once DISCUZ_ROOT . './source/plugin/nimba_regs/libs/output.lib.php';
}else{
	cpmsg(lang('plugin/nimba_regs','output_error'),'action=plugins&operation=config&identifier=nimba_regs&pmod=status','succeed');
}
//From: Dism·taobao·com
?>