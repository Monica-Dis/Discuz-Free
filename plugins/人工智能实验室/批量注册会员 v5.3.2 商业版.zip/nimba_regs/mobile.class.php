<?php
/*
 * 主页：https://dism.taobao.com/?@1552.developer
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_nimba_regs {
	function global_footer_mobile(){
		global $_G,$xing,$ming;
		loadcache('plugin');
		$vars=$_G['cache']['plugin']['nimba_regs'];
		$open=intval($vars['open']);
		$regs_rq=intval($vars['regs_rq']);
		$regs_rq_style=intval($vars['regs_rq_style']);
		$regs_group=empty($vars['regs_group'])? 10:$vars['regs_group'];
		$regs_pl=empty($vars['regs_pl'])? 10:$vars['regs_pl'];
		if($open&&$regs_rq&&rand(1,100)<$regs_pl){
			require_once DISCUZ_ROOT.'./source/plugin/nimba_regs/function/regs.fun.php';
			@creatuser($regs_rq_style,$regs_group);
		}
		return '';
	}
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>