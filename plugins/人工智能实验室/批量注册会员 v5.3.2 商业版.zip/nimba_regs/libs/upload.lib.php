<?php
/*
 * ��ҳ��https://dism.taobao.com/?@1552.developer
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ������� ��ϵDISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
} 
 	if(submitcheck('submit')){
	    loadcache('plugin');
		$error='';
		$connect=array();
		$filepath=DISCUZ_ROOT.'./data/sysdata/cache_connect_addon.php';
		if(file_exists($filepath)){
			@include $filepath;
		}
		$vars=$_G['cache']['plugin']['nimba_regs'];	
		$group=empty($vars['regs_group'])? 10:$vars['regs_group'];
		$data= explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$_POST['uploaddata']));
		foreach($data as $k=>$v){
			$v=trim($v);
			if($v){
				$load=explode("=",$v);
				$username=addslashes(trim($load[0]));
				$email=addslashes(strtolower(trim($load[1])));//����ֻ����Сд
				if($email=='#'){//��������
					$email=createmail();//var_dump($email);
				}
				$password=addslashes(trim($load[2]));
				if($password=='#'){//��������
					$password=substr(md5(creatname(5)),0,8);
				}
				if($username&&$email&&$password){
					$uid=creat_new($username,$password,$email,$group);
					if($uid>1){
						C::t('#nimba_regs#nimba_member')->insert($uid, $username, $password, $email,time());						
					}else{
						$error.="$v,ErrorCode($uid)\r\n";
					}
				}
			}
		}
		@file_put_contents(DISCUZ_ROOT.'./data/nimba_regs.cache',$error);
		echo ishow($langvar['added'], ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_regs&pmod=pregs');
	}else{
		$error='';
		$tip='';
		if(file_exists(DISCUZ_ROOT.'./data/nimba_regs.cache')){
			$error=@file_get_contents(DISCUZ_ROOT.'./data/nimba_regs.cache');
			if($error){
				$filemtime=filemtime(DISCUZ_ROOT.'./data/nimba_regs.cache');
				$error=lang('plugin/nimba_regs','upload_addon_error',array('filemtime'=>date('Y-m-d H:i:s',$filemtime),'error'=>str_replace("\r\n",'<br>',$error)));
				$tip=lang('plugin/nimba_regs','upload_addon_tip');
			}
		}
		include template('nimba_regs:upload');
	}
//From: Dism��taobao��com
?>