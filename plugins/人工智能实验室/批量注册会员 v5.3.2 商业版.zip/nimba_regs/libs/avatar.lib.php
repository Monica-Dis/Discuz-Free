<?php
/*
 * 主页：https://dism.taobao.com/?@1552.developer
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$config=array();
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php')){
	@require_once DISCUZ_ROOT.'./data/sysdata/cache_defaultavatar_config.php';
}
$avatars=$config;
if(!$avatars||!count($avatars)){
	cpmsg(lang('plugin/nimba_regs','defaultavatar_error'),'action=plugins&operation=config&identifier=nimba_regs&pmod=status','succeed');
}else{
	if($_GET['start']||submitcheck('addsubmit')){
		$start=max(1,intval($_GET['start']));
		$avatar=$avatars[array_rand($avatars,1)];
		$uid=DB::result_first("SELECT uid  FROM ".DB::table('common_member')." where avatarstatus=0 and status=0 order by uid desc");
		if($uid){
			$dir=sprintf("%09d",$uid);
			$root=checkAvatarDir($dir);
			createAvatar(DISCUZ_ROOT.'./source/plugin/defaultavatar/avatar/'.$avatar['name'],$root.substr($dir,-2).'_avatar_big.jpg','big');
			createAvatar(DISCUZ_ROOT.'./source/plugin/defaultavatar/avatar/'.$avatar['name'],$root.substr($dir,-2).'_avatar_middle.jpg','middle');
			createAvatar(DISCUZ_ROOT.'./source/plugin/defaultavatar/avatar/'.$avatar['name'],$root.substr($dir,-2).'_avatar_small.jpg','small');	
			DB::update('common_member',array('avatarstatus'=>1),array('uid'=>$uid));
			$start++;
			echo lang('plugin/nimba_regs','avatar_tip_3').$start.lang('plugin/nimba_regs','avatar_tip_4').$uid.lang('plugin/nimba_regs','avatar_tip_5');
			echo "<script>window.location.href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_regs&pmod=avatar&start=".$start."';</script>";
		}else{
			cpmsg(lang('plugin/nimba_regs','avatar_tip_6'),'action=plugins&operation=config&identifier=nimba_regs&pmod=avatar', 'succeed');
		}
	}else{
		$count=DB::result_first("SELECT count(*)  FROM ".DB::table('common_member')." where avatarstatus=0 and status=0");
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=nimba_regs&pmod=avatar');	
		showtableheader(lang('plugin/nimba_regs','avatar_title'),'nobottom');
		showsetting(lang('plugin/nimba_regs','avatar_tip'), 'avatar','',lang('plugin/nimba_regs','avatar_tip_1').$count.lang('plugin/nimba_regs','avatar_tip_2'),'',0,'');
		showsubmit('addsubmit',lang('plugin/nimba_regs','avatar_submit'));	
		showtablefooter(); /*dism _ taobao _ com*/
		showformfooter(); /*dism - taobao - com*/
	}
}

function createAvatar($img,$dir,$size){
	$image_size = getimagesize($img);
	$width=array('big'=>200,'middle'=>120,'small'=>48);
	$from=imagecreatefromjpeg($img);
	if($image_size[0]>$image_size[1]){
		$w=$width[$size]*$image_size[1]/$image_size[0];
		$h=$width[$size];
	}elseif($image_size[0]<$image_size[1]){
		$w=$width[$size];
		$h=$width[$size]*$image_size[0]/$image_size[1];
	}else{
		$w=$width[$size];
		$h=$width[$size];	
	}
	$new=imagecreatetruecolor($w,$h);
	imagecopyresized($new,$from,0,0,0,0,$w,$h,$image_size[0],$image_size[1]);
	imagejpeg($new,$dir);
}

function checkAvatarDir($dir){
	$root=DISCUZ_ROOT.'/uc_server/data/avatar/';
	$dir1 = substr($dir, 0, 3);
	$dir2 = substr($dir, 3, 2);
	$dir3 = substr($dir, 5, 2);
	$root.=$dir1.'/';
	if(!is_dir($root)) mkdir($root);
	$root.=$dir2.'/';
	if(!is_dir($root)) mkdir($root);
	$root.=$dir3.'/';
	if(!is_dir($root)) mkdir($root);
	return $root;
}
//From: Dism·taobao·com
?>