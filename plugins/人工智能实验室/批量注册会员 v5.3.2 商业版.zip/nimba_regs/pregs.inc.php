<?php
/*
 * 主页：https://dism.taobao.com/?@1552.developer
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
@require_once DISCUZ_ROOT.'./source/discuz_version.php';
@require_once DISCUZ_ROOT.'./source/plugin/nimba_regs/function/regs.fun.php';
$langvar=lang('plugin/nimba_regs');
if(substr($plugin['version'],-1,1)==2&&file_exists(DISCUZ_ROOT.'./source/plugin/nimba_regs/libs/upload.lib.php')){
	$uploadon=1;
	@require_once DISCUZ_ROOT . './source/plugin/nimba_regs/libs/upload.lib.php';
}else{
 	$uploadon=0; 
	if(submitcheck('submit')){
		echo ishow($langvar['error3'], ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_regs&pmod=pregs');
	}else include template('nimba_regs:upload'); 
}
//From: Dism·taobao·com
?>