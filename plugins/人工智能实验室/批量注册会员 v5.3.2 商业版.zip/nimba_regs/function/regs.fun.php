<?php
/*
 * ��ҳ��https://dism.taobao.com/?@1552.developer
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ������� ��ϵDISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//������չ���԰�
if(file_exists(DISCUZ_ROOT.'./source/plugin/nimba_regs/language.'.currentlang().'.php')){
	include DISCUZ_ROOT.'./source/plugin/nimba_regs/language.'.currentlang().'.php';
}elseif(file_exists(DISCUZ_ROOT.'./source/plugin/nimba_regs/language.php')){
	include DISCUZ_ROOT.'./source/plugin/nimba_regs/language.php';
}else{
	echo lang('plugin/nimba_regs','error_addonlang');
	exit();
}

$xing=explode(',',$_addonlang['nimba_regs']['xing']);
$ming=explode(',',$_addonlang['nimba_regs']['ming']);
$word5000=explode(',',$_addonlang['nimba_regs']['word5000']);
function creatname($sj){
	global $_G,$xing,$ming,$word5000;
	//�����û��� 5���
	//1 ������
	//2 ��Ӣ��
	//3 ����+����
	//4 Ӣ��+����
	if($sj==5) $sj=rand(1,4);
	$zm=array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');

	if($sj==1){
		$t=time()%3;
		if($t==0) return $xing[rand(0,count($xing)-1)].$ming[rand(0,count($ming)-1)];
		elseif($t==1) return $word5000[rand(0,count($word5000)-1)].$word5000[rand(0,count($word5000)-1)];
		else return $word5000[rand(0,count($word5000)-1)].$word5000[rand(0,count($word5000)-1)].$word5000[rand(0,count($word5000)-1)];
	}elseif($sj==2) return $zm[rand(0,25)].$zm[rand(0,25)].$zm[rand(0,25)].$zm[rand(0,25)].$zm[rand(0,25)].$zm[rand(0,25)].$zm[rand(0,25)].$zm[rand(0,25)].$zm[rand(0,25)].$zm[rand(0,25)];
	elseif($sj==3){
		$t=time()%3;
		if($t==0) return $ming[rand(0,count($ming)-1)].rand(100,9999);
		elseif($t==1) return $xing[rand(0,count($xing)-1)].rand(100,9999);
		else $word5000[rand(0,count($word5000)-1)].rand(100,9999);
	}
	if($sj==4){
		$re='';
		for($i=0;$i<10;$i++){
			$k=rand(0,1);
			if($k) $re.=$zm[rand(0,25)];
			else $re.=rand(0,9);
		}
		return $re;
	}
}

function createmail(){
	global $_G;
	$domain='';
	$mlist=array(
		1=>'@qq.com',
		2=>'@163.com',
		3=>'@126.com',
		4=>'@yeah.net',
		5=>'@sina.com',
		6=>'@sohu.com',
		7=>'@139.com',
		8=>'@gmail.com',
		9=>'@hotmail.com',
		10=>'@21cn.com',
		11=>'@189.cn',
		12=>'@139.com',
	);	
	loadcache('plugin');
	$vars=$_G['cache']['plugin']['nimba_regs'];	
	$emails_plus=trim($vars['emails_plus']);
	if($emails_plus){//����ʹ���Զ���������
		$emails_plus=explode('/hhf/',str_replace(array("\r\n","\r","\n"),'/hhf/',$emails_plus));
		$domain=$emails_plus[rand(0,count($emails_plus)-1)];
	}
	if(!$domain){
		$emails=unserialize($vars['emails']);
		$domain=$mlist[$emails[rand(0,count($emails)-1)]];
	}
	if(!$domain) $domain='@qq.com';
	return TIMESTAMP.rand(11,99).$domain;
}

function creatuser($sj,$group=10,$pw=''){
	$user=array();
	$user['username']=creatname($sj);
	$username=$user['username'];
	$password=empty($pw)? substr(md5(creatname(4)),0,8):$pw;
	$email=(string)createmail();
	//$group=10;	
	$uid=intval(creat_new($username,$password,$email,$group));
 	if($uid>1){	
		C::t('#nimba_regs#nimba_member')->insert($uid, $username, $password, $email,time());
		
	}
	return $uid;
}
function creat_new($username,$password,$email,$group){
	global $_G;
	loaducenter();
	$uid=0;
	$uid = uc_user_register($username, $password, $email);
	/*
	-1 : �û������Ϸ�
	-2 : ����������ע��Ĵ���
	-3 : �û����Ѿ�����
	-4 : email ��ʽ����
	-5 : email ������ע��
	-6 : �� email �Ѿ���ע��
	>1 : ��ʾ�ɹ�����ֵΪ UID
	*/
	if($uid > 0) {
		$pwd=md5(random(10));
		$profile=array('profile'=>array('gender'=>rand(1,2)));
		C::t('common_member')->insert($uid,$username,$pwd,$email,creatip(),$group,$profile);//$_G['clientip']
		loadcache('plugin');
		$var=$_G['cache']['plugin']['nimba_regs'];
		//$var['credit']=1;
		//$var['creditnum']=rand(10,5000);
		if($var['credit']&&$var['creditnum']){
			updatemembercount($uid, array($var['credit']=>$var['creditnum']),true,'',$uid,lang('plugin/nimba_regs','credit_init'),lang('plugin/nimba_regs','credit_init'),lang('plugin/nimba_regs','credit_init'));
		}
	}
	require_once libfile('cache/userstats', 'function');
	build_cache_userstats();
	return $uid;
}

function creatip(){
	global $_G;
	loadcache('plugin');
	$ips=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',trim($_G['cache']['plugin']['nimba_regs']['ips'])));
	$newips=array();
	foreach($ips as $k=>$ipStr){
		if($ipStr&&substr_count($ipStr,'.')==3) $newips[]=$ipStr;
	}
	$ipLen=count($newips);
	if($ipLen){
		$ipArr=explode('.',$newips[rand(0,($ipLen-1))]);
		$ip='';
		for($i=0;$i<4;$i++){
			$ipArr[$i]=intval($ipArr[$i]);
			if($ipArr[$i]) $ip.=empty($ip)? $ipArr[$i]:'.'.$ipArr[$i];
			else $ip.=empty($ip)? rand(0,255):'.'.rand(0,255);
		}
		return $ip;
	}else{
		$first=array('113','222','119','121','58','122','125','219','61','116','123','218','59','221','124','27','60','183','202','114','120','112','115','117','180','210','220','74','111','165','182','72','110','211','14','159','161','169','175','187','207','81','86');
		return $first[rand(0,count($first)-1)].'.'.rand(0,255).'.'.rand(0,255).'.'.rand(0,255);
	}
}
function auto_charset($fContents,$from='gbk',$to='utf-8'){
    $from = strtoupper($from) == 'UTF8' ? 'utf-8' : $from;
    $to = strtoupper($to) == 'UTF8' ? 'utf-8' : $to;
    if (strtoupper($from) === strtoupper($to) || empty($fContents) || (is_scalar($fContents) && !is_string($fContents))) {
        return $fContents;
    }
    if (is_string($fContents)) {
        if (function_exists('mb_convert_encoding')) {
            return mb_convert_encoding($fContents, $to, $from);
        } elseif (function_exists('iconv')) {
            return iconv($from, $to, $fContents);
        } else {
            return $fContents;
        }
    } elseif (is_array($fContents)) {
        foreach ($fContents as $key => $val) {
            $_key = auto_charset($key, $from, $to);
            $fContents[$_key] = auto_charset($val, $from, $to);
            if ($key != $_key)
                unset($fContents[$key]);
        }
        return $fContents;
    }
    else {
        return $fContents;
    }
}

function ishow($message,$url){
	return "<script>alert('$message');window.location.href='$url';</script>";
}
//From: Dism��taobao��com
?>