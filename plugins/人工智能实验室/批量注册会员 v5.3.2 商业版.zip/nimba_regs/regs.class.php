<?php
/*
 * 主页：https://dism.taobao.com/?@1552.developer
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_nimba_regs {
	function global_header(){
		global $_G,$xing,$ming;
		loadcache('plugin');
		$vars=$_G['cache']['plugin']['nimba_regs'];
		$open=intval($vars['open']);
		$regs_rq=intval($vars['regs_rq']);
		$regs_rq_style=intval($vars['regs_rq_style']);
		$regs_group=empty($vars['regs_group'])? 10:$vars['regs_group'];
		$regs_pl=empty($vars['regs_pl'])? 10:$vars['regs_pl'];
		if($open&&$regs_rq&&rand(1,100)<$regs_pl){
			require_once DISCUZ_ROOT.'./source/plugin/nimba_regs/function/regs.fun.php';
			@creatuser($regs_rq_style,$regs_group);
		}
		return '';
	}
}

class plugin_nimba_regs_forum extends plugin_nimba_regs{
	function index_status_extra_output(){
		loadcache('plugin');
		global $_G,$membercount,$guestcount,$onlinenum,$onlineinfo,$whosonline,$detailstatus;
		$vars=$_G['cache']['plugin']['nimba_regs'];
		$num=intval($vars['regs_num']);
		if($vars['regs_on']&&$num){
			if(file_exists(DISCUZ_ROOT.'./source/plugin/nimba_regs/libs/majia.lib.php')){
				require_once DISCUZ_ROOT . './source/plugin/nimba_regs/libs/majia.lib.php';
			}			
		}

	}
}
//From: Dism·taobao·com
?>