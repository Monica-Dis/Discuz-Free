<?php
/*
 * 主页：https://dism.taobao.com/?@1552.developer
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
@require_once DISCUZ_ROOT.'./source/discuz_version.php';
@require_once DISCUZ_ROOT.'./source/plugin/nimba_regs/function/regs.fun.php';
$langvar=lang('plugin/nimba_regs');
$pagenum=20;
$page=max(1,intval($_GET['page']));
$count=C::t('#nimba_regs#nimba_member')->count();
showtableheader(); /*dism·taobao·com*/
showsubtitle(array('UID',$langvar['username'],$langvar['email'],$langvar['pw1'],$langvar['time']));
$data=C::t('#nimba_regs#nimba_member')->fetch_all_by_range(($page - 1)*$pagenum,$pagenum);
foreach($data as $user) {
	showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
		$user['uid'],
		'<a href="home.php?mod=space&uid='.$user['uid'].'" target="_blank">'.$user['username'].'</a>',
		$user['email'],		
		$user['password'],
		date('Y-m-d H:i:s',$user['dateline']),
	));
			
}
showtablefooter(); /*dism _ taobao _ com*/
echo multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_regs&pmod=data");
?>