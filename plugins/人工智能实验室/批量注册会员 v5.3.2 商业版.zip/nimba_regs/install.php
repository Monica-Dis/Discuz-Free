<?php
/*
 * 主页：https://dism.taobao.com/?@1552.developer
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
DROP TABLE IF EXISTS `pre_nimba_member`;
CREATE TABLE `pre_nimba_member` (
  `uid` int(11) unsigned NOT NULL, 
  `username` char(25) NOT NULL DEFAULT '',
  `password` char(64) NOT NULL DEFAULT '',
  `email` char(40) NOT NULL DEFAULT '',  
  `dateline` int(111) unsigned NOT NULL default '0',
  PRIMARY KEY (`uid`)
);
EOF;
runquery($sql);
/* 删除文件 */
$identifier = 'nimba_regs';
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');
@unlink($entrydir.'/upgrade.php');
/* 删除文件 */
$finish = TRUE;

?>