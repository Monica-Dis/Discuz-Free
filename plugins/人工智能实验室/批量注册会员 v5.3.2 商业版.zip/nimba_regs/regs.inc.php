<?php
/*
 * 主页：https://dism.taobao.com/?@1552.developer
 * 应用更新支持：https://dism.taobao.com
 * 插件定制 联系DISM.TAOBAO.COM
 * From dis'.'m.tao'.'bao.com
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
@require_once DISCUZ_ROOT.'./source/discuz_version.php';
@require_once DISCUZ_ROOT.'./source/plugin/nimba_regs/function/regs.fun.php';
$langvar=lang('plugin/nimba_regs');
loadcache('plugin');
$vars=$_G['cache']['plugin']['nimba_regs'];	
$group=empty($vars['regs_group'])? 10:$vars['regs_group'];
echo '<table class="tb tb2 " id="tips">
	<tr>
		<th  class="partition">'.$langvar['tips'].'</th>
	</tr>
	<tr>
		<td class="tipsblock" s="1">
			<ul id="tipslis">
				<li>'.$langvar['tip1'].'</li>
				<li>'.$langvar['tip2'].'</li>
				<li>'.$langvar['tip3'].'</li>
			</ul>
		</td>
	</tr>
</table><br>';
if($_POST['regnum']||$_GET['reging']){
	echo '<br>';
	if(submitcheck('submit')&&!$_GET['reging']){
		$usertype=empty($_POST['usertype'])? 5:intval($_POST['usertype']);
		if(empty($_POST['pw'])) $pw='';
		else $pw=addslashes($_POST['pw']);
		$reging=intval($_POST['regnum']);
		echo "<script>window.location.href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_regs&pmod=regs&reging=$reging&pw=$pw&usertype=$usertype&num=0&dateline=".time()."';</script>";
	}else{
		$reging=intval($_GET['reging']);
		$usertype=intval($_GET['usertype']);
		$pw=addslashes($_GET['pw']);
		$num=intval($_GET['num']);
		$dateline=intval($_GET['dateline']);
		if($num<$reging){
			echo $langvar['tip4'].($num+1).$langvar['tip5'];
			$uid=@creatuser($usertype,$group,$pw);
			if($uid>0){
				$num++;
				echo "<script>window.location.href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_regs&pmod=regs&reging=$reging&pw=$pw&usertype=$usertype&num=$num&dateline=$dateline';</script>";
			}else{
				$error=lang('plugin/nimba_regs','error_'.(-1*$uid));
				if($error){
					echo $error.lang('plugin/nimba_regs','error_tip_2');
				}else{
					echo $error.lang('plugin/nimba_regs','error_tip_1');
				}
				echo "<script>window.location.href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_regs&pmod=regs&reging=$reging&pw=$pw&usertype=$usertype&num=$num&dateline=$dateline';</script>";
			}
		}else{
			echo $langvar['tip6'].(time()-$dateline).$langvar['tip7'].'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_regs&pmod=regs">'.$langvar['tip8'].'</a>';
		}
	}
}else include template('nimba_regs:regs');
?>