<?php 
/*
 * Copyright (c) 2020 by dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * From: Dism_taobao-com
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$fuid=intval($_GET['uid']);
if(!$fuid) showmessage(lang('plugin/nimba_newlogin','url_nofuid'));
if($fuid==$_G['uid']){
	showmessage(lang('plugin/nimba_newlogin','url_sameuid'));
}
$log=DB::fetch_first("select * from ".DB::table('nimba_newlogin_logs')." where fuid='$fuid' and ip='$_G[clientip]'");
if($log){
	showmessage(lang('plugin/nimba_newlogin','url_haslog'));
}else{
	loadcache('plugin');
	$vars = $_G['cache']['plugin']['nimba_newlogin'];
	$starttime=strtotime(trim($vars['starttime']));
	$member=DB::fetch_first("select username,regdate from ".DB::table('common_member')." where uid='$fuid'");
	if(!$member){
		showmessage(lang('plugin/nimba_newlogin','url_nomember'));
	}
	if($member['regdate']<$starttime){
		showmessage(lang('plugin/nimba_newlogin','url_regdate_error'));
	}
	$log=array(
		'fuid'=>$fuid,
		'fusername'=>$member['username'],
		'cuid'=>$_G['uid'],
		'cusername'=>$_G['username'],		
		'ip'=>$_G['clientip'],		
		'dateline'=>TIMESTAMP,
	);
	DB::insert('nimba_newlogin_logs',$log);
	showmessage(lang('plugin/nimba_newlogin','url_ok'),$_G['siteurl'], array (), array (
		'locationtime' => true,
		'refreshtime' => 3,
		'showdialog' => 1,
		'showmsg' => true
	));	
	
}

//From: dis'.'m.tao'.'bao.com
?>