<?php
/*
 * Copyright (c) 2020 by dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * From: Dism_taobao-com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_nimba_newlogin {
	function global_header_mobile(){
		global $_G;
		//return '';//free
		if(!$_G['uid']) return '';//游客不弹出
		if(CURSCRIPT=='plugin'&&$_GET['id']=='nimba_newlogin') return '';
		loadcache('plugin');
		$vars = $_G['cache']['plugin']['nimba_newlogin'];
		$starttime=strtotime(trim($vars['starttime']));
		if($_G['member']['regdate']>=$starttime){//从starttime设置的时间之后注册的会员会被强制要求激活！
			if($_COOKIE['nimba_newlogin_'.$_G['uid']]==md5($_G['uid'].'|'.$_G['config']['security']['authkey'])) return '';//已经激活
			$ipnum=trim($vars['ipnum']);
			$count=DB::result_first("select count(*) from ".DB::table('nimba_newlogin_logs')." where fuid='$_G[uid]'");
			if($count>=$ipnum){//达到激活IP数 写入cookie 加密
				setcookie('nimba_newlogin_'.$_G['uid'],md5($_G['uid'].'|'.$_G['config']['security']['authkey']));
				return '';
			}
			$info=trim($vars['info']);
			$tips=trim($vars['tips']);
			$url=$_G['siteurl'].'plugin.php?id=nimba_newlogin&uid='.$_G['uid'];
			$info=str_replace('{username}',$_G['username'],$info);
			$info=str_replace('{ipnum}',$ipnum,$info);
			$info=str_replace('{url}',$url,$info);
			include template('nimba_newlogin:newlogin');
			return $return;
		}
		return '';
	}
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>