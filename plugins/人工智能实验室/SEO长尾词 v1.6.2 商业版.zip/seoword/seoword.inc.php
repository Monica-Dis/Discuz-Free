<?php 
/*
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com $
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT.'./source/plugin/seoword/functions.php';
if($_GET['formhash']==formhash()){
	loadcache('plugin');
	$type=trim($_GET['type']);
	if($type=='thread'){
		$tid=intval($_GET['tid']);
		$tid==0&&exit('/* error:tid=0 */');
		$thread=C::t('forum_thread')->fetch($tid);
		!$thread&&exit('/* error:unget thread */');
		$subject=$thread['subject'];
		!$subject&&exit('/* error:unget subject */');
		$forums=unserialize($_G['cache']['plugin']['seoword']['forums']);	
		$group=intval($_G['cache']['plugin']['seoword']['group']);	
		if(in_array($thread['fid'],$forums)||($group==1&&$thread['isgroup'])){
			$api=intval($_G['cache']['plugin']['seoword']['api']);	
			if($api==4) $api=rand(1,3);//随机接口
			if($api==1) $keywords=baidu_getSEOWord($subject);
			elseif($api==2) $keywords=so_getSEOWord($subject);
			elseif($api==3) $keywords=sogou_getSEOWord($subject);
			if(!$keywords) $keywords='#unget#'.TIMESTAMP;//少量会获取失败，留个标记
			C::t('#seoword#seoword')->delete_by_tid($tid);
			C::t('#seoword#seoword')->insert(array('tid'=>$tid,'keywords'=>$keywords));
			exit('/* Dong thread over */');	
		}else{
			exit('/* error:forum not open fid='.$thread['fid'].' or group not open */');
		}
	}elseif($type=='article'){
		$portal=intval($_G['cache']['plugin']['seoword']['portal']);
		$portal==0&&exit('/* error:portal closed */');		
		$aid=intval($_GET['aid']);
		$aid==0&&exit('/* error:aid=0 */');
		$article=C::t('portal_article_title')->fetch($aid);
		!$article&&exit('/* error:unget article */');
		$title=$article['title'];
		!$title&&exit('/* error:unget title */');
		$keywords=baidu_getSEOWord($title);
		if(!$keywords) $keywords='#unget#'.TIMESTAMP;//少量会获取失败，留个标记
		C::t('#seoword#seoword_article')->delete_by_aid($aid);
		C::t('#seoword#seoword_article')->insert(array('aid'=>$aid,'keywords'=>$keywords));
		exit('/* Dong article over */');
	}else{
		exit('/* type error*/');
	}
}else{
	exit('/* hash error*/');
}

exit;



?>