<?php
/*
 * 应用中心[DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com $
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
C::t('#seoword#seoword')->drop();
C::t('#seoword#seoword_article')->drop();
$identifier = 'seoword';
if(!function_exists('cloudaddons_deltree')) require libfile('function/cloudaddons');
cloudaddons_deltree(DISCUZ_ROOT .'./source/plugin/'.$identifier.'/');
$finish = TRUE;
?>