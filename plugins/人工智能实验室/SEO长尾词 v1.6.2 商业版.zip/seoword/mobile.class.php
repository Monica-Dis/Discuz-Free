<?php

 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_seoword {
	function __construct(){
		global $_G;
		loadcache('plugin');
		$this->vars = $_G['cache']['plugin']['seoword'];
		$this->forums=unserialize($this->vars['forums']);
		$this->portal=intval($this->vars['portal']);
		$this->group=intval($this->vars['group']);
		$this->delay=intval($this->vars['delay']);
	}
	
	function deletethread($value){//主题删除执行
		global $_G;
		if($value['step']=='delete'){
			foreach($value['param'][0] as $k=>$tid){
				C::t('#seoword#seoword')->delete_by_tid($tid);
			}
		}
		return '';
	}	
}

class mobileplugin_seoword_forum extends mobileplugin_seoword{
	function viewthread_top_mobile_output(){
		global $_G,$metakeywords;
		if($_G['thread']['displayorder']<0) return '';
		if(in_array($_G['fid'],$this->forums)||($this->group&&$_G['thread']['isgroup']==1)){
			$item=C::t('#seoword#seoword')->fetch_by_tid($_G['tid']);
			if($item){
				if(substr($item['keywords'],0,7)!='#unget#'){
					$metakeywords=dhtmlspecialchars($item['keywords']).','.$metakeywords;			
				}else{
					$lasttime=intval(trim(str_replace('#unget#','',$item['keywords'])));
					if($this->delay&&TIMESTAMP-$lasttime>$this->delay){
						return '<script src="'.$_G['siteurl'].'plugin.php?id=seoword&type=thread&tid='.$_G['tid'].'&formhash='.FORMHASH.'" type="text/javascript"></script>';
					}else{
						return '<!-- seoword:'.dgmdate($lasttime,'Y-m-d H:i:s').'-->';
					}
				}				
			}else{
				return '<script src="'.$_G['siteurl'].'plugin.php?id=seoword&type=thread&tid='.$_G['tid'].'&formhash='.FORMHASH.'" type="text/javascript"></script>';
			}	
		}
		return '';		
	}
}	

class mobileplugin_seoword_group extends mobileplugin_seoword_forum {
	//方法继承
}

class mobileplugin_seoword_portal extends mobileplugin_seoword {
	function portalcp_article_delete(){
		global $_G;
		//portal.php?mod=portalcp&ac=article&op=delete&aid=
		$aid=intval($_GET['aid']);
		if($aid&&$_GET['op']=='delete'&&isset($_GET['optype'])&&$_GET['formhash']==formhash()){//提交删除
			C::t('#seoword#seoword_article')->delete_by_aid($aid);
		}
		return '';
	}
	
	function view_article_top_mobile_output(){//手机版需要第三方手机门户版本有对应的嵌入点支持，否则无效
		global $_G,$aid,$metakeywords;
		if(!$this->portal) return '';
		if(!$aid) $aid=intval($_GET['aid']);
		$item=C::t('#seoword#seoword_article')->fetch_by_aid($aid);
		if($item){
			if(substr($item['keywords'],0,7)!='#unget#'){
				$metakeywords=dhtmlspecialchars($item['keywords']).','.$metakeywords;			
			}else{
				$lasttime=intval(trim(str_replace('#unget#','',$item['keywords'])));
				if($this->delay&&TIMESTAMP-$lasttime>$this->delay){
					return '<script src="'.$_G['siteurl'].'plugin.php?id=seoword&type=article&aid='.$aid.'&formhash='.FORMHASH.'" type="text/javascript"></script>';
				}else{
					return '<!-- seoword:'.dgmdate($lasttime,'Y-m-d H:i:s').'-->';
				}
			}
		}else{
			return '<script src="'.$_G['siteurl'].'plugin.php?id=seoword&type=article&aid='.$aid.'&formhash='.FORMHASH.'" type="text/javascript"></script>';
		}
		return '';		
		
	}
}
//From: Dism_taobao_com
?>