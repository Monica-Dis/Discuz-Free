<?php
/*
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com $
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_seoword_article extends discuz_table{
	public function __construct() {

		$this->_table = 'seoword_article';
		$this->_pk    = 'id';
		$this->_pre_cache_key = 'seoword_article_';

		parent::__construct();
	}
	public function count(){
		$count = DB::result_first('SELECT COUNT(*) FROM %t', array($this->_table));
		return $count;
	}
	
	public function max_id() {
		return DB::result_first('SELECT MAX(id) FROM %t', array($this->_table));
	}

	public function fetch_by_aid($aid) {
		return DB::fetch_first('SELECT * FROM %t where aid=%d order by id desc', array($this->_table,$aid), $this->_pk);
	}

	public function fetch_all_by_range($start,$end) {
		return DB::fetch_all('SELECT * FROM %t ORDER BY id DESC LIMIT %d,%d', array($this->_table,$start,$end), $this->_pk);
	}	
	public function drop() {
		return DB::query('DROP TABLE IF EXISTS %t',array($this->_table));
	}
	public function update_by_aid($aid,$data){
		if($aid&&!empty($data)&&is_array($data)) {
			DB::update($this->_table, $data, DB::field('aid', $aid), 'UNBUFFERED');
		}	
	
	}
	public function delete_by_aid($aid){
		if($tid) {
			DB::delete($this->_table,DB::field('aid',$aid));
		}	
	}		
}
//From: Dism_taobao_com
?>