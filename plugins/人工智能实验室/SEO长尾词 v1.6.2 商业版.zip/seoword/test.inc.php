<?php
/*
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com $
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT.'./source/plugin/seoword/functions.php';
if(submitcheck('testsubmit')){//搜索结果
	$title=trim($_GET['title']);
	if($title){
		$api_1=baidu_getSEOWord($title);if(!$api_1) $api_1=lang('plugin/seoword','tr_nodata');
		$api_2=so_getSEOWord($title);if(!$api_2) $api_2=lang('plugin/seoword','tr_nodata');
		$api_3=sogou_getSEOWord($title);if(!$api_3) $api_3=lang('plugin/seoword','tr_nodata');
		$item=C::t('#seoword#seoword')->fetch_by_tid($tid);
		if(substr($item['keywords'],0,7)=='#unget#') $item['keywords']='';
		showtableheader(lang('plugin/seoword','tr_title'));
		showsetting(lang('plugin/seoword','tr_title_title'),'title',$title,'text','', 0,"");
		showsetting(lang('plugin/seoword','tr_title_word_1'),'newwords',stripslashes($api_1),'textarea','', 0,'');
		showsetting(lang('plugin/seoword','tr_title_word_2'),'newwords',stripslashes($api_2),'textarea','', 0,'');
		showsetting(lang('plugin/seoword','tr_title_word_3'),'newwords',stripslashes($api_3),'textarea','', 0,'');
		showtablefooter();
		echo '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=seoword&pmod=test">'.lang('plugin/seoword','tr_title_up').'</a>';
	}else{
		cpmsg(lang('plugin/seoword','tr_errotr_tid'));
	}
}else{//搜索界面
	showformheader("plugins&operation=config&do=$pluginid&identifier=seoword&pmod=test");
	showtableheader(lang('plugin/seoword','t_title'), 'nobottom');	
	showsetting(lang('plugin/seoword','t_title_tid'),'title','','text','', 0,lang('plugin/seoword','t_title_tid_info'));			
	showsubmit('testsubmit');
	showtablefooter();
	showformfooter();	
}


?>