<?php
/*
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com $
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_seoword {
	function __construct(){
		global $_G;
		loadcache('plugin');
		$this->vars = $_G['cache']['plugin']['seoword'];
		$this->forums=unserialize($this->vars['forums']);
		$this->portal=intval($this->vars['portal']);
		$this->group=intval($this->vars['group']);
		$this->delay=intval($this->vars['delay']);
		
	}
	
	function deletethread($value){//����ɾ��ִ��
		global $_G;
		if($value['step']=='delete'){
			foreach($value['param'][0] as $k=>$tid){
				C::t('#seoword#seoword')->delete_by_tid($tid);
			}
		}
		return '';
	}
}

class plugin_seoword_forum extends plugin_seoword {
	function viewthread_top_output(){
		global $_G,$metakeywords,$postlist;
		if($_G['thread']['displayorder']<0) return '';
		if(in_array($_G['fid'],$this->forums)||($this->group&&$_G['thread']['isgroup']==1)){
			$item=C::t('#seoword#seoword')->fetch_by_tid($_G['tid']);
			if($item){
				if(substr($item['keywords'],0,7)!='#unget#'){
					$metakeywords=dhtmlspecialchars($item['keywords']).','.$metakeywords;
				}else{
					$lasttime=intval(trim(str_replace('#unget#','',$item['keywords'])));
					if($this->delay&&TIMESTAMP-$lasttime>$this->delay){
						return '<script src="'.$_G['siteurl'].'plugin.php?id=seoword&type=thread&tid='.$_G['tid'].'&formhash='.FORMHASH.'" type="text/javascript"></script>';
					}else{
						return '<!-- seoword:'.dgmdate($lasttime,'Y-m-d H:i:s').'-->';
					}
				}	
			}else{
				return '<script src="'.$_G['siteurl'].'plugin.php?id=seoword&type=thread&tid='.$_G['tid'].'&formhash='.FORMHASH.'" type="text/javascript"></script>';
			}	
		}
		return '';
	}
}
class plugin_seoword_group extends plugin_seoword_forum {
	//�����̳�
}	

class plugin_seoword_portal extends plugin_seoword {
	function portalcp_article_delete(){
		global $_G;
		//portal.php?mod=portalcp&ac=article&op=delete&aid=
		$aid=intval($_GET['aid']);
		if($aid&&$_GET['op']=='delete'&&isset($_GET['optype'])&&$_GET['formhash']==formhash()){//�ύɾ��
			C::t('#seoword#seoword_article')->delete_by_aid($aid);
		}
		return '';
	}
	
	function view_article_top_output(){
		global $_G,$aid,$metakeywords,$content;
		if(!$this->portal) return '';
		if(!$aid) $aid=intval($_GET['aid']);
		$item=C::t('#seoword#seoword_article')->fetch_by_aid($aid);
		if($item){
			if(substr($item['keywords'],0,7)!='#unget#'){
				$metakeywords=dhtmlspecialchars($item['keywords']).','.$metakeywords;			
			}else{
				$lasttime=intval(trim(str_replace('#unget#','',$item['keywords'])));
				if($this->delay&&TIMESTAMP-$lasttime>$this->delay){
					return '<script src="'.$_G['siteurl'].'plugin.php?id=seoword&type=article&aid='.$aid.'&formhash='.FORMHASH.'" type="text/javascript"></script>';
				}else{
					return '<!-- seoword:'.dgmdate($lasttime,'Y-m-d H:i:s').'-->';
				}
			}	
		}else{
			return '<script src="'.$_G['siteurl'].'plugin.php?id=seoword&type=article&aid='.$aid.'&formhash='.FORMHASH.'" type="text/javascript"></script>';
		}
		return '';		
		
	}
}
//From: Dism��taobao��com
?>