<?php
/*
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com $
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(submitcheck('search2submit')){//�������
	$aid=intval(trim($_GET['aid']));
	if($aid){
		$article=C::t('portal_article_title')->fetch($aid);
		if(!$article){
			cpmsg(lang('plugin/seoword','r_error_article'));
		}else{
			$item=C::t('#seoword#seoword_article')->fetch_by_aid($aid);
			if(substr($item['keywords'],0,7)=='#unget#') $item['keywords']='';
			showformheader('plugins&operation=config&do='.$pluginid.'&identifier=seoword&pmod=search2&aid='.$aid);
			showtableheader(lang('plugin/seoword','r_title2'));
			showsetting(lang('plugin/seoword','r_title_title2'),'title',$article['title'],'text','', 0,"aid=$aid");
			showsetting(lang('plugin/seoword','r_title_word2'),'newwords',stripslashes($item['keywords']),'textarea','', 0,'<font color="red">'.lang('plugin/seoword','r_title_word_info').'</font>');
			showsubmit('changesubmit', 'submit', '','<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=seoword&pmod=search2">'.lang('plugin/seoword','r_title_up').'</a>');
			showtablefooter();
			showformfooter();
		}

	}else{
		cpmsg(lang('plugin/seoword','r_error_aid'));
	}
}elseif(submitcheck('changesubmit')){//�޸�
	$aid=intval(trim($_GET['aid']));
	$item=C::t('#seoword#seoword_article')->fetch_by_aid($aid);
	$keywords=addslashes(trim($_POST['newwords']));
	if(!$keywords) $keywords='#unget#'.TIMESTAMP;
	if($item){
		C::t('#seoword#seoword_article')->update_by_aid($aid,array('keywords'=>$keywords));
	}else{
		C::t('#seoword#seoword_article')->insert(array('aid'=>$aid,'keywords'=>$keywords));
	}
	cpmsg(lang('plugin/seoword','update_ok'),'action=plugins&operation=config&do='.$pluginid.'&identifier=seoword&pmod=search2&aid='.$aid.'&resulthash='.FORMHASH.'', 'succeed');
}else{//��������
	showformheader("plugins&operation=config&do=$pluginid&identifier=seoword&pmod=search2");
	showtableheader(lang('plugin/seoword','s_title2'), 'nobottom');	
	showsetting(lang('plugin/seoword','s_title_aid'),'aid','','text','', 0,lang('plugin/seoword','s_title_aid_info'));			
	showsubmit('search2submit');
	showtablefooter();
	showformfooter();	
}
//From: Dism��taobao��com
?>