<?php
/*
 * 应用中心[DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com $
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_seoword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tid` int(11) unsigned NOT NULL default '0',
  `keywords` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tid` (`tid`) USING BTREE
)ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_seoword_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) unsigned NOT NULL default '0',
  `keywords` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tid` (`aid`) USING BTREE
)ENGINE=MyISAM;
EOF;

runquery($sql);
/* 删除文件 */
$identifier = 'seoword';
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');
@unlink($entrydir.'/upgrade.php');
/* 删除文件 */
$finish = TRUE;

?>