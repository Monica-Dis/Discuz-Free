<?php
/*
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!Ӧ������ dism.taobao.com $
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(submitcheck('searchsubmit')){//�������
	$tid=intval(trim($_GET['tid']));
	if($tid){
		$thread=C::t('forum_thread')->fetch($tid);
		if(!$thread){
			cpmsg(lang('plugin/seoword','r_error_thread'));
		}else{
			$item=C::t('#seoword#seoword')->fetch_by_tid($tid);
			if(substr($item['keywords'],0,7)=='#unget#') $item['keywords']='';
			showformheader('plugins&operation=config&do='.$pluginid.'&identifier=seoword&pmod=search&tid='.$tid);
			showtableheader(lang('plugin/seoword','r_title'));
			showsetting(lang('plugin/seoword','r_title_title'),'title',$thread['subject'],'text','', 0,"tid=$tid");
			showsetting(lang('plugin/seoword','r_title_word'),'newwords',stripslashes($item['keywords']),'textarea','', 0,'<font color="red">'.lang('plugin/seoword','r_title_word_info').'</font>');
			showsubmit('changesubmit', 'submit', '','<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=seoword&pmod=search">'.lang('plugin/seoword','r_title_up').'</a>');
			showtablefooter();
			showformfooter();
		}

	}else{
		cpmsg(lang('plugin/seoword','r_error_tid'));
	}
}elseif(submitcheck('changesubmit')){//�޸�
	$tid=intval(trim($_GET['tid']));
	$item=C::t('#seoword#seoword')->fetch_by_tid($tid);
	$keywords=addslashes(trim($_POST['newwords']));
	if(!$keywords) $keywords='#unget#'.TIMESTAMP;
	if($item){
		C::t('#seoword#seoword')->update_by_tid($tid,array('keywords'=>$keywords));
	}else{
		C::t('#seoword#seoword')->insert(array('tid'=>$tid,'keywords'=>$keywords));
	}
	cpmsg(lang('plugin/seoword','update_ok'),'action=plugins&operation=config&do='.$pluginid.'&identifier=seoword&pmod=search&tid='.$tid.'&resulthash='.FORMHASH.'', 'succeed');
}else{//��������
	showformheader("plugins&operation=config&do=$pluginid&identifier=seoword&pmod=search");
	showtableheader(lang('plugin/seoword','s_title'), 'nobottom');	
	showsetting(lang('plugin/seoword','s_title_tid'),'tid','','text','', 0,lang('plugin/seoword','s_title_tid_info'));			
	showsubmit('searchsubmit');
	showtablefooter();
	showformfooter();	
}
//From: Dism��taobao��com
?>