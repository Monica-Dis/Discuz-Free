<?php
/*
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com $
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//From: Dism·taobao·com
?>
<iframe src="https://api.open.ailab.cn/addon/?from=seoword" width="100%" height="2000" frameborder="0" scrolling="no" style="min-width:870px;margin-left:-3px; background:#F4FAFD" ></iframe> 