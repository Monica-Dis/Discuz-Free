<?php 
/*
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com $
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function baidu_getSEOWord($title){
	$title=urlencode($title);
	$url="http://www.baidu.com/s?wd=$title%20site%3Aabc.com";//加site:abc.com 可得空搜索列表，限制返回网页大小
	$html=dfsockopen($url);
	if(!$html){
		$html=@file_get_contents($url);//dfsockopen偶尔会出现抓不到的情况，用file_get_contents重试一次
	}
	$charset=strtolower(CHARSET);
	if($charset=='gbk')	$html=diconv($html,'UTF-8');
	$st=strpos($html,'<div id="rs">');
	if($st){
		$html=substr($html,$st);
		$sp=strpos($html,'</table>');
		$html=substr($html,0,$sp);
		$partern='/<a href="([^<>]+)">([^<>]+)<\/a>/';
		if(preg_match_all($partern,$html,$result)){
			return implode(',', $result[2]);
		}
	}
	return '';
}

function so_getSEOWord($title){
	$title=urlencode($title);
	$url="https://www.so.com/s?q=$title";
	$html=dfsockopen($url);
	$charset=strtolower(CHARSET);
	if($charset=='gbk')	$html=diconv($html,'UTF-8');
	if(substr_count($html,'hot-search-discuss')){
		$st=strpos($html,'id="rel-search"');
		$html=substr($html,$st);
		$sp=strpos($html,'hot-search-discuss');
		$html=substr($html,0,$sp);
	}else{
		$st=strpos($html,'<div id="rs"');
		$html=substr($html,$st);
		$st=strpos($html,'<table>');
		$sp=strpos($html,'</table>');
		$html=substr($html,$st,$sp-$st);
	}
	if($st&&$sp&&$html){
		if(preg_match_all('#<a.+?href="([^"]+)".*?>(.+?)</a>#is',$html,$result)){
			foreach($result[2] as $k=>$v){
				if(is_numeric($v)){
					unset($result[2][$k]);//过滤纯数字
				}
			}
			return implode(',', $result[2]);
		}
	}
	return '';	
}

function sogou_getSEOWord($title){
	$title=urlencode($title);
	$url="https://www.sogou.com/web?query=$title";
	$html=dfsockopen($url);
	$charset=strtolower(CHARSET);
	if($charset=='gbk')	$html=diconv($html,'UTF-8');
	$st=strpos($html,'id="hint_container"');
	$html=substr($html,$st);
	$sp=strpos($html,'</table>');
	$html=substr($html,0,$sp);
	$partern='/<a href="([^<>]+)">([^<>]+)<\/a>/';
	if(preg_match_all($partern,$html,$result)){
		return implode(',', $result[2]);
	}
	return '';
} 
 