<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_nimba_goto {
	function common(){
		global $_G;
		loadcache('plugin');
		if($_GET['mod']=='viewthread'&&$_G['tid']){
			$vars = $_G['cache']['plugin']['nimba_goto'];
			$open=intval($vars['open']);
			$delay=intval($vars['delay']);
			if(!$open) return '';
			if($delay&&$_G['uid']&&($_G['adminid']==1||$_G['thread']['authorid']==$_G['uid'])) return '';//�ӳ���ת ���ڴ˴�����
			$log=C::t('#nimba_goto#nimba_goto')->fetch_url_by_tid($_G['tid']);
			if($log['url']){
				$url='plugin.php?id=nimba_goto:url&tid='.$_G['tid'];
				echo '<script>window.location.href=\''.$url.'\';</script> ';			
				exit;
			}
		}
		return '';
	}
	
	function deletethread($var){//ǰ̨ɾ������
		global $_G;
		if($var['step']=='delete'){
			foreach($var['param'][0] as $k=>$tid){
				C::t('#nimba_goto#nimba_goto')->delete_by_tid($tid);
			}
		}
	}
}

class plugin_nimba_goto_forum extends plugin_nimba_goto{
	function viewthread_top_output(){//������ʾ�ӳ�
		global $_G,$postlist;
		loadcache('plugin');
		$vars = $_G['cache']['plugin']['nimba_goto'];
		$open=intval($vars['open']);
		$delay=intval($vars['delay']);
		$delaytime=intval($vars['delaytime']);
		if($open&&$delay&&$delaytime>0&&$_G['uid']&&($_G['adminid']==1||$_G['thread']['authorid']==$_G['uid'])){//�����ӳ�
			$log=C::t('#nimba_goto#nimba_goto')->fetch_url_by_tid($_G['tid']);
			if($log['url']){
				$url='plugin.php?id=nimba_goto:url&tid='.$_G['tid'];
				foreach($postlist as $pid=>$post){
					if($post['first']==0) return '';//��������	
					
					if($_G['uid']==$_G['thread']['authorid']){//�����Լ�
						$postlist[$pid]['message']='<div class="pct"><style type="text/css">.pcb{margin-right:0}</style><div class="pcb"><div class="locked">'.lang('plugin/nimba_goto','tip_1').'<font color="red">'.lang('plugin/nimba_goto','tip_2').'</font>'.lang('plugin/nimba_goto','tip_4').'&nbsp;<span class="rq" id="delaytime">'.$delaytime.'</span>&nbsp;'.lang('plugin/nimba_goto','tip_5').'</div></div></div>'.$postlist[$pid]['message'].'
<script type="text/javascript">
var goto = setTimeout("delayGoTo()",1000);
function delayGoTo() { 
	var objDelayTime=document.getElementById("delaytime");
	var delay = objDelayTime.innerHTML;
	if (delay > 0) {
		delay--;
		objDelayTime.innerHTML = delay;
	}else{
		clearTimeout(goto); 
		window.location.href=\''.$url.'\';
	}
	goto = setTimeout("delayGoTo()",1000);
} 
</script>';
					}elseif($_G['adminid']==1){//����Ա
						$postlist[$pid]['message']='<div class="pct"><style type="text/css">.pcb{margin-right:0}</style><div class="pcb"><div class="locked">'.lang('plugin/nimba_goto','tip_1').'<font color="red">'.lang('plugin/nimba_goto','tip_3').'</font>'.lang('plugin/nimba_goto','tip_4').'&nbsp;<span class="rq" id="delaytime">'.$delaytime.'</span>&nbsp;'.lang('plugin/nimba_goto','tip_5').'</div></div></div>'.$postlist[$pid]['message'].'
<script type="text/javascript">
var goto = setTimeout("delayGoTo()",1000);
function delayGoTo() { 
	var objDelayTime=document.getElementById("delaytime");
	var delay = objDelayTime.innerHTML;
	if (delay > 0) {
		delay--;
		objDelayTime.innerHTML = delay;
	}else{
		clearTimeout(goto); 
		window.location.href=\''.$url.'\';
	}
	goto = setTimeout("delayGoTo()",1000);
} 
</script>';					
					}
					break;
				}
			}			
		}
		return '';
	}
	
	function post_middle_output(){
		global $_G;
		loadcache('plugin');
		$var = $_G['cache']['plugin']['nimba_goto'];
		$open=$var['open'];
		$forums=unserialize($var['forums']);
		if($open&&$_G['fid']&&in_array($_G['fid'],$forums)){
			$langvar= lang('plugin/nimba_goto');		
			if(file_exists(DISCUZ_ROOT.'source/plugin/nimba_goto/goto.lib.php')){
				//��ҵ��
				include 'goto.lib.php';	
				return $return;
			}else{
				$uids= explode(",",trim($var['uids']));
				if($_G['uid']&&in_array($_G['uid'],$uids)){
					if($_G['tid']){//�༭״̬
						$log=C::t('#nimba_goto#nimba_goto')->fetch_url_by_tid($_G['tid']);
						$url=$log['url'];
						$urlm=$log['urlm'];
					}
					include template('nimba_goto:post_middle');
					return $return;	
				}
			}
		}	
	}
	
	function post_feedlog_message($var){
		global $_G,$thread,$tid,$pid;
		$tid = $var['param'][2]['tid'];
		$action=$var['param'][0];	
		$_GET['gotourl']=addslashes(trim($_GET['gotourl']));
		$_GET['gotourlm']=addslashes(trim($_GET['gotourlm']));
		if(($action=='post_newthread_succeed'||$action=='post_newthread_mod_succeed')&&($_GET['gotourl']||$_GET['gotourlm'])){//����
			$arr=array(
				'tid'=>$tid,  
				'uid'=>$_G['uid'],
				'dateline'=>TIMESTAMP,
				'endtime'=>'0',
				'url'=>$_GET['gotourl'],
				'urlm'=>$_GET['gotourlm'],
				'views'=>'0',
				'status'=>'0',
			);
			C::t('#nimba_goto#nimba_goto')->insert($arr);
		}
		
		if($action=='post_edit_succeed'||$action=='edit_newthread_mod_succeed'){//�༭
			$log=C::t('#nimba_goto#nimba_goto')->fetch_url_by_tid($tid);
			if($log&&($_GET['gotourl']||$_GET['gotourlm'])){
				if($_GET['gotourl']!=$log['url']||$_GET['gotourlm']!=$log['urlm']){
					C::t('#nimba_goto#nimba_goto')->update_url_by_tid($tid,$_GET['gotourl'],$_GET['gotourlm']);
				}
			}elseif(!$log&&($_GET['gotourl']||$_GET['gotourlm'])){//����
				$arr=array(
					'tid'=>$tid,  
					'uid'=>$_G['uid'],
					'dateline'=>TIMESTAMP,
					'endtime'=>'0',
					'url'=>$_GET['gotourl'],
					'urlm'=>$_GET['gotourlm'],
					'views'=>'0',
					'status'=>'0',
				);
				C::t('#nimba_goto#nimba_goto')->insert($arr);			
			}elseif($log&&!$_GET['gotourl']&&!$_GET['gotourlm']){//ɾ��
				C::t('#nimba_goto#nimba_goto')->delete_by_tid($tid);
			}
		}
		return '';
	}
}

class plugin_nimba_goto_group extends plugin_nimba_goto_forum{
	function post_middle_output(){
		global $_G;
		loadcache('plugin');
		$var = $_G['cache']['plugin']['nimba_goto'];
		$open=$var['open'];
		$opengroup=$var['opengroup'];
		if($opengroup&&$open&&$_G['fid']){
			$langvar= lang('plugin/nimba_goto');		
			if(file_exists(DISCUZ_ROOT.'source/plugin/nimba_goto/goto.lib.php')){
				//��ҵ��
				include 'goto.lib.php';	
				return $return;
			}else{
				$uids= explode(",",trim($var['uids']));
				if($_G['uid']&&in_array($_G['uid'],$uids)){
					if($_G['tid']){//�༭״̬
						$log=C::t('#nimba_goto#nimba_goto')->fetch_url_by_tid($_G['tid']);
						$url=$log['url'];
						$urlm=$log['urlm'];
					}
					include template('nimba_goto:post_middle');
					return $return;	
				}
			}
		}	
	}
	
	function post_feedlog_message($var){
		global $_G,$thread,$tid,$pid;
		$tid = $var['param'][2]['tid'];
		$action=$var['param'][0];	
		$_GET['gotourl']=addslashes(trim($_GET['gotourl']));
		$_GET['gotourlm']=addslashes(trim($_GET['gotourlm']));
		if($action=='post_newthread_succeed'&&($_GET['gotourl']||$_GET['gotourlm'])){//����
			$arr=array(
				'tid'=>$tid,  
				'uid'=>$_G['uid'],
				'dateline'=>TIMESTAMP,
				'endtime'=>'0',
				'url'=>$_GET['gotourl'],
				'urlm'=>$_GET['gotourlm'],
				'views'=>'0',
				'status'=>'0',
			);
			C::t('#nimba_goto#nimba_goto')->insert($arr);
		}
		
		if($action=='post_edit_succeed'){//�༭
			$log=C::t('#nimba_goto#nimba_goto')->fetch_url_by_tid($tid);
			if($log&&($_GET['gotourl']||$_GET['gotourlm'])){
				if($_GET['gotourl']!=$log['url']||$_GET['gotourlm']!=$log['urlm']){
					C::t('#nimba_goto#nimba_goto')->update_url_by_tid($tid,$_GET['gotourl'],$_GET['gotourlm']);
				}
			}elseif(!$url&&($_GET['gotourl']||$_GET['gotourlm'])){//����
				$arr=array(
					'tid'=>$tid,  
					'uid'=>$_G['uid'],
					'dateline'=>TIMESTAMP,
					'endtime'=>'0',
					'url'=>$_GET['gotourl'],
					'urlm'=>$_GET['gotourlm'],
					'views'=>'0',
					'status'=>'0',
				);
				C::t('#nimba_goto#nimba_goto')->insert($arr);			
			}elseif($url&&!$_GET['gotourl']&&!$_GET['gotourlm']){//ɾ��
				C::t('#nimba_goto#nimba_goto')->delete_by_tid($tid);
			}
		}
		return '';
	}
}
//From: Dism_taobao-com
?>