<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$langvar= lang('plugin/nimba_goto');
if($_GET['op']=='del'&&$_GET['formhash']==formhash()){
	$tid=intval($_GET['tid']);
	C::t('#nimba_goto#nimba_goto')->delete_by_tid($tid);
	cpmsg($langvar['updated'],'action=plugins&operation=config&do=$pluginid&identifier=nimba_goto&pmod=admincp','succeed');
}elseif($_GET['op']=='edit'){
	if(submitcheck('submit')){
		$tid=intval($_POST['tid']);
		$url=addslashes($_POST['url']);
		$urlm=addslashes($_POST['urlm']);
		$subject=addslashes($_POST['subject']);
		if($subject){
			C::t('#nimba_goto#nimba_goto')->update_url_by_tid($tid,$url,$urlm);
			C::t('forum_thread')->update($tid,array('subject'=>$subject));
		}
		cpmsg($langvar['updated'],'action=plugins&operation=config&do=$pluginid&identifier=nimba_goto&pmod=admincp','succeed');
	}else{
		$tid=intval($_GET['tid']);
		$log=C::t('#nimba_goto#nimba_goto')->fetch_url_by_tid($tid);
		$th=C::t('forum_thread')->fetch($tid);
		$subject=$th['subject'];
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=nimba_goto&pmod=admincp&op=edit');
		showtableheader(); //dism��taobao��com
			showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
				$langvar['subject'],
				'<input type="hidden" name="formhash" value="'.FORMHASH.'"><input type="hidden" name="tid" value="'.$tid.'"><input type="text" size="100" value="'.$subject.'" name="subject"/>',
			));	
			showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
				$langvar['url'],
				'<input type="text" size="100" value="'.$log['url'].'" name="url"/>',
			));	
			showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
				$langvar['urlm'],
				'<input type="text" size="100" value="'.$log['urlm'].'" name="urlm"/>',
			));				
		showsubmit('submit', $langvar['submit'], $langvar['del']);
		showtablefooter(); //Dism��taobao��com
		showformfooter(); //Dism_taobao_com	
	}
}else{
	$pagenum=20;
	$page=max(1,intval($_GET['page']));
	$count=C::t('#nimba_goto#nimba_goto')->count();
	showtableheader(); //dism��taobao��com
	showsubtitle(array('ID',$langvar['subject'],$langvar['url'],$langvar['urlm'],$langvar['views'],$langvar['time'],$langvar['op'],$langvar['op_del']));
	$data=C::t('#nimba_goto#nimba_goto')->fetch_all_by_range(($page - 1)*$pagenum,$pagenum);
	foreach($data as $user) {
		$th=C::t('forum_thread')->fetch($user['tid']);
		showtablerow('', array('class="td25"', 'class="td_k"', 'class="td_l"'), array(
			$user['id'],
			'<a href="forum.php?mod=viewthread&tid='.$user['tid'].'" target="_blank">'.$th['subject'].'</a>',
			$user['url']? '<a href="'.$user['url'].'" target="_blank">'.$user['url'].'</a>':'/',	
			$user['urlm']? '<a href="'.$user['urlm'].'" target="_blank">'.$user['urlm'].'</a>':'/',	
			$user['views'],
			date('Y-m-d H:i:s',$user['dateline']),
			'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_goto&pmod=admincp&op=edit&tid='.$user['tid'].'">'.$langvar['op'].'</a>',
			'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=nimba_goto&pmod=admincp&op=del&tid='.$user['tid'].'&formhash='.FORMHASH.'">'.$langvar['op_del'].'</a>',			
		));
				
	}
	showtablefooter(); //Dism��taobao��com
	echo multi($count,$pagenum,$page,ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=nimba_goto&pmod=admincp");
}
//From: Dism_taobao-com
?>