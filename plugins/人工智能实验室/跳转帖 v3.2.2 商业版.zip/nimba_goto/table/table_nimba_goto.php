<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_nimba_goto extends discuz_table{
	public function __construct() {

		$this->_table = 'nimba_goto';
		$this->_pk    = 'id';
		$this->_pre_cache_key = 'nimba_goto_';

		parent::__construct(); //d'.'is'.'m.ta'.'obao.com
	}
	public function count(){
		$count = DB::result_first('SELECT COUNT(*) FROM %t where 1', array($this->_table));
		return $count;
	}
	public function max_id() {
		return DB::result_first('SELECT MAX(id) FROM %t', array($this->_table));
	}

	public function fetch_all_by_range($start,$end) {
		return DB::fetch_all('SELECT * FROM %t where 1 ORDER BY id DESC LIMIT %d,%d', array($this->_table,$start,$end), $this->_pk);
	}
	public function fetch_url_by_tid($tid) {
		return DB::fetch_first("SELECT url,urlm FROM %t where tid='%d'",array($this->_table,$tid));
	}
	public function fetch_id_by_tid($tid) {
		return DB::result_first("SELECT id FROM %t where tid='%d'",array($this->_table,$tid));
	}	
	public function update_url_by_tid($tid,$url,$urlm) {
		$tid = dintval($tid,true);
		if($tid){
			DB::query('UPDATE %t SET url=%s,urlm=%s WHERE tid=%d',array($this->_table,$url,$urlm,$tid));
		}
	}
	public function update_views_by_tid($tid) {
		$tid = dintval($tid,true);
		if($tid){
			DB::query('UPDATE %t SET views=views+1 WHERE tid=%d',array($this->_table,$tid));
		}
	}
	public function delete_by_tid($tid) {
		$tid = dintval($tid,true);
		if($tid){
			DB::query('delete from %t WHERE tid=%d',array($this->_table,$tid));
		}
	}	
	public function drop() {
		return DB::query('DROP TABLE IF EXISTS %t',array($this->_table));
	}
}
//dis'.'m.t'.'ao'.'bao.com
?>