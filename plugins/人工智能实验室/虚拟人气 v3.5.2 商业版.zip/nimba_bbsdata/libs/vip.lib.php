<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
		if($vars['forumtodaypost']){//�������
			$forumtodaypost=explode("\n",str_replace("\r\n", "\n",$vars['forumtodaypost']));
			foreach($forumtodaypost as $k=>$addondata){
				$addon=explode('|',$addondata);
				$addon[0]=intval(trim($addon[0]));
				$addon[1]=trim($addon[1]);
				$addon[2]=intval(trim($addon[2]));
				if($forumlist[$addon[0]]&&$addon[0]&&$addon[1]&&$addon[2]&&in_array($addon[1],array('+','-','*','/','='))){
					switch($addon[1]){
						case '+':$forumlist[$addon[0]]['todayposts']=$forumlist[$addon[0]]['todayposts']+$addon[2];break;
						case '-':$forumlist[$addon[0]]['todayposts']=$forumlist[$addon[0]]['todayposts']-$addon[2];break;
						case '*':$forumlist[$addon[0]]['todayposts']=$forumlist[$addon[0]]['todayposts']*$addon[2];break;
						case '/':$forumlist[$addon[0]]['todayposts']=round($forumlist[$addon[0]]['todayposts']/$addon[2]);break;
						case '=':$forumlist[$addon[0]]['todayposts']=$addon[2];break;
					}
					if($favforumlist[$addon[0]]) $favforumlist[$addon[0]]['todayposts']=$forumlist[$addon[0]]['todayposts'];
				}
			}
		}
		if($vars['forumposts']){//���������
			$forumposts=explode("\n",str_replace("\r\n", "\n",$vars['forumposts']));
			foreach($forumposts as $k=>$addondata){
				$addon=explode('|',$addondata);
				$addon[0]=intval(trim($addon[0]));
				$addon[1]=trim($addon[1]);
				$addon[2]=intval(trim($addon[2]));
				if($forumlist[$addon[0]]&&$addon[0]&&$addon[1]&&$addon[2]&&in_array($addon[1],array('+','-','*','/','='))){
					switch($addon[1]){
						case '+':$forumlist[$addon[0]]['posts']=$forumlist[$addon[0]]['posts']+$addon[2];break;
						case '-':$forumlist[$addon[0]]['posts']=$forumlist[$addon[0]]['posts']-$addon[2];break;
						case '*':$forumlist[$addon[0]]['posts']=$forumlist[$addon[0]]['posts']*$addon[2];break;
						case '/':$forumlist[$addon[0]]['posts']=round($forumlist[$addon[0]]['posts']/$addon[2]);break;
						case '=':$forumlist[$addon[0]]['posts']=$addon[2];break;
					}
					if($favforumlist[$addon[0]]) $favforumlist[$addon[0]]['posts']=$forumlist[$addon[0]]['posts'];
				}
			}
		}
		if($detailstatus){
			if($vars['membercount']) $membercount=$this->mixvelue($membercount,$vars['membercount']);
			if($vars['guestcount']) $guestcount=$this->mixvelue($guestcount,$vars['guestcount']);
			if($vars['membercount']||$vars['guestcount']) $onlinenum=$membercount+$guestcount;
		}else{//�۵�������ʾ״̬
			if($vars['membercount']&&$membercount) $membercount=$this->mixvelue($membercount,$vars['membercount']);
			if($vars['guestcount']&&$guestcount) $guestcount=$this->mixvelue($guestcount,$vars['guestcount']);		
			if($onlinenum){
				if((substr_count($vars['membercount'],'+')||substr_count($vars['membercount'],'-'))&&(substr_count($vars['guestcount'],'+')||substr_count($vars['guestcount'],'-'))){
					if($vars['membercount']) $onlinenum=$this->mixvelue($onlinenum,$vars['membercount']);
					if($vars['guestcount']) $onlinenum=$this->mixvelue($onlinenum,$vars['guestcount']);
				}else{//ֻ��һ��
					if($vars['membercount']) $onlinenum=$this->mixvelue($onlinenum,$vars['membercount']);
					elseif($vars['guestcount']) $onlinenum=$this->mixvelue($onlinenum,$vars['guestcount']);				
				}
			}
		}
		if($vars['maxcount']) $onlineinfo[0]=$this->mixvelue($onlineinfo[0],$vars['maxcount']);
		if($vars['maxday']) $onlineinfo[1]=trim($vars['maxday']);
		if($onlineinfo[0]<$onlinenum) $onlineinfo[0] = $onlinenum + 1;		
		$num=intval($membercount-count($whosonline));
		if($_G['setting']['whosonlinestatus']&&$detailstatus&&$membercount&&$num>0){//�����߻�Ա�б���ʾ��ʱ������$num�������û�
			$query=DB::query("select groupid,uid,username from ".DB::table('common_member')." WHERE status=0 and groupid>=9 order by rand() limit 0,$num");
			$now=time();
			while($user=DB::fetch($query)){
				$user['lastactivity']=date('H:i',rand($now-86400,$now));
				$user['icon']='online_member.gif';
				$whosonline[]=$user;
			}
			//var_dump($whosonline);
		}
//From: Dism_taobao-com
?>