<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
		$vars=$_G['cache']['plugin']['nimba_bbsdata'];
		if($vars['opentime']){
			if($vars['starttime']>$vars['endtime']) $vars['opentime']=0;//����������Ч ��������ʱ
			else{
				$h=intval(date('H',time()));
				if($h>=$vars['starttime']&&$h<($vars['endtime']+1)) $open=1;//����ʱ���� ������ʱ
				else $open=0;
			}
		}
		if(($vars['opentime']==1&&$open==1)||$vars['opentime']==0){
			if($_G['fid']&&substr_count($_G['cache']['plugin']['nimba_bbsdata']['forumtodaypost'],$_G['fid'].'|')){
				$forumtodaypost=explode("\n",str_replace("\r\n", "\n",$_G['cache']['plugin']['nimba_bbsdata']['forumtodaypost']));
				foreach($forumtodaypost as $k=>$addondata){
					if(substr_count($addondata,$_G['fid'].'|')){
						$addon=explode('|',$addondata);
						$addon[0]=intval(trim($addon[0]));
						$addon[1]=trim($addon[1]);
						$addon[2]=intval(trim($addon[2]));
						if($addon[0]&&$addon[1]&&$addon[2]&&in_array($addon[1],array('+','-','*','/','='))){
							switch($addon[1]){
								case '+':$_G['forum']['todayposts']=$_G['forum']['todayposts']+$addon[2];break;
								case '-':$_G['forum']['todayposts']=$_G['forum']['todayposts']-$addon[2];break;
								case '*':$_G['forum']['todayposts']=$_G['forum']['todayposts']*$addon[2];break;
								case '/':$_G['forum']['todayposts']=round($_G['forum']['todayposts']/$addon[2]);break;
								case '=':$_G['forum']['todayposts']=$addon[2];break;
							}				
						}				
					}
				}
			}
			if($vars['forumtodaypost']){//�������
				$forumtodaypost=explode("\n",str_replace("\r\n", "\n",$vars['forumtodaypost']));
				$subdata=array();
				foreach($forumtodaypost as $k=>$addondata){
					$addon=explode('|',$addondata);
					$addon[0]=intval(trim($addon[0]));
					$addon[1]=trim($addon[1]);
					$addon[2]=intval(trim($addon[2]));
					$subdata[$addon[0]]=$addon;
				}
				foreach($sublist as $k=>$sub){
					$fid=$sub['fid'];
					if($subdata[$fid]){
						$addon=$subdata[$fid];	
						if($addon[1]&&$addon[2]&&in_array($addon[1],array('+','-','*','/','='))){
							switch($addon[1]){
								case '+':$sublist[$k]['todayposts']=$sublist[$k]['todayposts']+$addon[2];break;
								case '-':$sublist[$k]['todayposts']=$sublist[$k]['todayposts']-$addon[2];break;
								case '*':$sublist[$k]['todayposts']=$sublist[$k]['todayposts']*$addon[2];break;
								case '/':$sublist[$k]['todayposts']=round($sublist[$k]['todayposts']/$addon[2]);break;
								case '=':$sublist[$k]['todayposts']=$addon[2];break;
							}				
						}					
					}
				}			
			}	
			if($vars['forumposts']){//�������
				$forumposts=explode("\n",str_replace("\r\n", "\n",$vars['forumposts']));
				$subdata=array();
				foreach($forumposts as $k=>$addondata){
					$addon=explode('|',$addondata);
					$addon[0]=intval(trim($addon[0]));
					$addon[1]=trim($addon[1]);
					$addon[2]=intval(trim($addon[2]));
					$subdata[$addon[0]]=$addon;
				}
				foreach($sublist as $k=>$sub){
					$fid=$sub['fid'];
					if($subdata[$fid]){
						$addon=$subdata[$fid];	
						if($addon[1]&&$addon[2]&&in_array($addon[1],array('+','-','*','/','='))){
							switch($addon[1]){
								case '+':$sublist[$k]['posts']=$sublist[$k]['posts']+$addon[2];break;
								case '-':$sublist[$k]['posts']=$sublist[$k]['posts']-$addon[2];break;
								case '*':$sublist[$k]['posts']=$sublist[$k]['posts']*$addon[2];break;
								case '/':$sublist[$k]['posts']=round($sublist[$k]['posts']/$addon[2]);break;
								case '=':$sublist[$k]['posts']=$addon[2];break;
							}				
						}					
					}
				}			
			}			
		}
		
?>