<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_nimba_bbsdata {
	function global_header_mobile(){
		global $_G,$todayposts,$postdata,$posts,$onlinenum,$forumlist;
		if(CURSCRIPT=='forum'&&(CURMODULE=='index'||CURMODULE=='forumdisplay')){//进入作用范围
			loadcache('plugin');
			$vars=$_G['cache']['plugin']['nimba_bbsdata'];
			if($vars['opentime']){
				if($vars['starttime']>$vars['endtime']) $vars['opentime']=0;//参数设置无效 不开启定时
				else{
					$h=intval(date('H',time()));
					if($h>=$vars['starttime']&&$h<($vars['endtime']+1)) $open=1;//设置时间内 开启定时
					else $open=0;
				}
			}
			if(($vars['opentime']==1&&$open==1)||$vars['opentime']==0){
				if($vars['todayposts']) $todayposts=$this->mixvelue($todayposts,$vars['todayposts']);//今日
				if($vars['yestodayposts']) $postdata[0]=$this->mixvelue($postdata[0],$vars['yestodayposts']);//昨天
				if($vars['totalposts']) $posts=$this->mixvelue($posts,$vars['totalposts']);//总帖数
				if($vars['totalmembers']) $_G['cache']['userstats']['totalmembers']=$this->mixvelue($_G['cache']['userstats']['totalmembers'],$vars['totalmembers']);//总会员数
				if($vars['membercount']) $onlinenum=$this->mixvelue($onlinenum,$vars['membercount']);//在线	
				if($vars['forumtodaypost']){//版块新帖
					$forumtodaypost=explode("\n",str_replace("\r\n", "\n",$vars['forumtodaypost']));
					foreach($forumtodaypost as $k=>$addondata){
						$addon=explode('|',$addondata);
						$addon[0]=intval(trim($addon[0]));
						$addon[1]=trim($addon[1]);
						$addon[2]=intval(trim($addon[2]));
						if($forumlist[$addon[0]]&&$addon[0]&&$addon[1]&&$addon[2]&&in_array($addon[1],array('+','-','*','/','='))){
							switch($addon[1]){
								case '+':$forumlist[$addon[0]]['todayposts']=$forumlist[$addon[0]]['todayposts']+$addon[2];break;
								case '-':$forumlist[$addon[0]]['todayposts']=$forumlist[$addon[0]]['todayposts']-$addon[2];break;
								case '*':$forumlist[$addon[0]]['todayposts']=$forumlist[$addon[0]]['todayposts']*$addon[2];break;
								case '/':$forumlist[$addon[0]]['todayposts']=round($forumlist[$addon[0]]['todayposts']/$addon[2]);break;
								case '=':$forumlist[$addon[0]]['todayposts']=$addon[2];break;
							}				
						}
					}
				}
				if($vars['forumposts']){//版块总帖数
					$forumposts=explode("\n",str_replace("\r\n", "\n",$vars['forumposts']));
					foreach($forumposts as $k=>$addondata){
						$addon=explode('|',$addondata);
						$addon[0]=intval(trim($addon[0]));
						$addon[1]=trim($addon[1]);
						$addon[2]=intval(trim($addon[2]));
						if($forumlist[$addon[0]]&&$addon[0]&&$addon[1]&&$addon[2]&&in_array($addon[1],array('+','-','*','/','='))){
							switch($addon[1]){
								case '+':$forumlist[$addon[0]]['posts']=$forumlist[$addon[0]]['posts']+$addon[2];break;
								case '-':$forumlist[$addon[0]]['posts']=$forumlist[$addon[0]]['posts']-$addon[2];break;
								case '*':$forumlist[$addon[0]]['posts']=$forumlist[$addon[0]]['posts']*$addon[2];break;
								case '/':$forumlist[$addon[0]]['posts']=round($forumlist[$addon[0]]['posts']/$addon[2]);break;
								case '=':$forumlist[$addon[0]]['posts']=$addon[2];break;
							}
						}
					}
				}			
			}			
		}
		return '';
	}
	
	function mixvelue($oldvalue,$addondata){
		$newvalue=$oldvalue;
 		if(!empty($addondata)){
			$addon=explode('|',$addondata);
			$addon[0]=trim($addon[0]);
			$addon[1]=intval(trim($addon[1]));
			if($addon[0]&&$addon[1]&&in_array($addon[0],array('+','-','*','/','='))){
				switch($addon[0]){
					case '+':$newvalue=$newvalue+$addon[1];break;
					case '-':$newvalue=$newvalue-$addon[1];break;
					case '*':$newvalue=$newvalue*$addon[1];break;
					case '/':$newvalue=round($newvalue/$addon[1]);break;
					case '=':$newvalue=$addon[1];break;
				}		
			
			}
		}
		return $newvalue;
	}	
}

class mobileplugin_nimba_bbsdata_forum extends mobileplugin_nimba_bbsdata {
	function forumdisplay_top_mobile_output(){
		loadcache('plugin');
		global $_G,$sublist;
		if(file_exists(DISCUZ_ROOT.'./source/plugin/nimba_bbsdata/libs/forumdisplay.lib.php')){
			@require_once DISCUZ_ROOT . './source/plugin/nimba_bbsdata/libs/forumdisplay.lib.php';
		}
		return '';
	}
}
//From: Dism·taobao·com
?>