<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('nimba_tougao'));
$pagenum=20;
$page=max(1,intval($_GET['page']));
$start=($page-1)*$pagenum;
showtableheader(lang('plugin/nimba_tougao', 'usertougao'), '');
showtableheader();
showsubtitle(array(lang('plugin/nimba_tougao','m_1'),lang('plugin/nimba_tougao','m_2'),lang('plugin/nimba_tougao','m_3'),lang('plugin/nimba_tougao','m_4'),lang('plugin/nimba_tougao','m_5')));
if($count) {
	$query = DB::query("SELECT * FROM ".DB::table('nimba_tougao')." ORDER BY dateline DESC LIMIT $start,$pagenum");
	while($result = DB::fetch($query)) {
		if($result['aid']) $status='<a href="portal.php?mod=view&aid='.$result['aid'].'" target="_blank"><font color="green">'.lang('plugin/nimba_tougao','yishen').'</a></a>';
		else{
			$newaid=DB::result_first("SELECT aid FROM ".DB::table('portal_article_title')." where idtype='tid' and id='".intval($result['tid'])."' ORDER BY aid DESC");
			if($newaid){
				DB::update('nimba_tougao', array('aid'=>$newaid),"tid='".intval($result['tid'])."'");
				$status='<a href="portal.php?mod=view&aid='.$newaid.'" target="_blank"><font color="green">'.lang('plugin/nimba_tougao','yishen').'</a></a>';
			}else{
				$status='<a href="portal.php?mod=portalcp&ac=article&from_idtype=tid&from_id='.$result['tid'].'" target="_blank"><font color="red">'.lang('plugin/nimba_tougao','shenhe').'</a></a>';
			}
		}
		$thread=DB::result_first("select subject from ".DB::table('forum_thread')." where tid=".intval($result['tid']));
		if(!$thread) $thread=lang('plugin/nimba_tougao','nosubject');
		showtablerow(
		NULL,
		NULL,
		array(
			$result['id'],
			'<a href="home.php?mod=space&uid='.$result['uid'].'" target="_blank">'.$result['username'].'</a>',
			'<a href="forum.php?mod=viewthread&tid='.$result['tid'].'" target="_blank">'.$thread.'</a>',
			date('Y-m-d H:i', $result['dateline']),
			$status,
		));
	}
}
showtablerow();
showtablefooter(); /*dism _ taobao _ com*/
echo multi($count, $pagenum, $page, ADMINSCRIPT.'?action=plugins&operation=config&identifier=nimba_tougao&pmod=data');
?>
