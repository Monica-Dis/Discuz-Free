<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_nimba_tougao {
	function __construct(){
	    loadcache('plugin');
		global $_G;
		$this->vars=$_G['cache']['plugin']['nimba_tougao'];
		$this->groups=(array)unserialize($this->vars['groups']);
		$this->autogroups=(array)unserialize($this->vars['autogroups']);
		$this->adminuid=intval($this->vars['adminuid']);
	}
}

class plugin_nimba_tougao_forum extends plugin_nimba_tougao{
	function post_middle_output(){//��������ҳ
		global $_G;
		loadcache('plugin');
		if(in_array($_G['groupid'],$this->groups)&&$_GET['action']=='newthread'){
			$catlist=array();
			if($this->autogroups&&in_array($_G['groupid'],$this->autogroups)){//�������
				$catlist=DB::fetch_all("select catid,catname from ".DB::table('portal_category')." where closed=0 and upid=0");
				$subcatlist=array();
				foreach($catlist as $k=>$cat){
					$sub=DB::fetch_all("select catid,catname from ".DB::table('portal_category')." where closed=0 and upid=".intval($cat['catid'])."");
					if($sub){
						$subcatlist[intval($cat['catid'])]=$sub;
						foreach($sub as $kk=>$subcat){
							$ssub=DB::fetch_all("select catid,catname from ".DB::table('portal_category')." where closed=0 and upid=".intval($subcat['catid'])."");
							if($ssub) $subcatlist[intval($subcat['catid'])]=$ssub;
						}
					}
				}				
			}
			include template('nimba_tougao:post_newthread');
			return $return;
		}else return '';
	}
	
	function forumdisplay_fastpost_btn_extra_output(){//�б�ҳ���ٷ���
		global $_G;
		loadcache('plugin');
		if(in_array($_G['groupid'],$this->groups)){
			$catlist=array();
			if($this->autogroups&&in_array($_G['groupid'],$this->autogroups)){//�������
				$catlist=DB::fetch_all("select catid,catname from ".DB::table('portal_category')." where closed=0 and upid=0");
				$subcatlist=array();
				foreach($catlist as $k=>$cat){
					$sub=DB::fetch_all("select catid,catname from ".DB::table('portal_category')." where closed=0 and upid=".intval($cat['catid'])."");
					if($sub){
						$subcatlist[intval($cat['catid'])]=$sub;
						foreach($sub as $kk=>$subcat){
							$ssub=DB::fetch_all("select catid,catname from ".DB::table('portal_category')." where closed=0 and upid=".intval($subcat['catid'])."");
							if($ssub) $subcatlist[intval($subcat['catid'])]=$ssub;
						}
					}
				}
			}			
			include template('nimba_tougao:post_newthread');
			return $return;
		}else return '';
	}
	
	function post_feedlog_message($var){
		global $_G,$thread,$tid,$pid;
		$tid = $var['param'][2]['tid'];
		$pid = $var['param'][2]['pid'];
		$action=$var['param'][0];
		$tougao=intval($_GET['tougao']);
		
		if($tougao==1&&$_GET['action']=='newthread'){
			if(in_array($_G['groupid'],$this->autogroups)){//�������
				require_once libfile('function/discuzcode');
				require_once libfile('function/post');
				require_once libfile('function/forum');					
				$_GET['message']=str_replace('attachimg','attach',$_GET['message']);
				$catid=intval($_GET['catid']);
					$attach=DB::fetch_first("select * from ".DB::table('forum_attachment_'.($tid%10))." where tid='$tid' and isimage=1");
					if($attach){
						$pic='forum/'.$attach['attachment'];
					}else{
						$pic='';
					}		
				$setarr = array(
					'title' => $_GET['subject'],
					'author' => $_G['username'],
					'from' => '',
					'fromurl' => 'forum.php?mod=viewthread&tid='.$tid,
					'dateline' => TIMESTAMP,
					'url' => '',
					'allowcomment' => '1',
					'summary' => messagecutstr($_GET['message'],200),
					'pic'=>$pic,
					'catid' => $catid,
					'tag' => '',
					'status' => 0,
					'highlight' => '|||',
					'showinnernav' => 0,
					'idtype'=>'tid',
					'id'=>$tid,
				);
				$aid = C::t('portal_article_title')->insert($setarr, 1);
				if($aid){
					$_GET['message']=discuzcode($_GET['message']);
					C::t('portal_article_content')->insert(array('aid' => $aid, 'id' => $setarr['id'], 'idtype' => $setarr['idtype'], 'title' => $setarr['title'], 'content' => $_GET['message'], 'pageorder' => 1, 'dateline' => TIMESTAMP));
					$modarr = array(
						'tid' => $setarr['id'],
						'uid' => $_G['uid'],
						'username' => $_G['username'],
						'dateline' => TIMESTAMP,
						'action' => 'PTA',
						'status' => '1',
						'stamp' => '',
					);
					C::t('forum_threadmod')->insert($modarr);
					C::t('forum_thread')->update($setarr['id'], array('moderated' => 1, 'pushedaid' => $aid));	
					C::t('common_member_status')->update($_G['uid'], array('lastpost' => TIMESTAMP), 'UNBUFFERED');
					C::t('portal_category')->increase($setarr['catid'], array('articles' => 1));
					C::t('portal_category')->update($setarr['catid'], array('lastpublish' => TIMESTAMP));
					C::t('portal_article_count')->insert(array('aid'=>$aid, 'catid'=>$setarr['catid'], 'viewnum'=>1));
				}				
			}else{
				$aid=0;
			}
			$data=array(
				'uid'=>$_G['uid'],
				'username'=>$_G['username'],
				'tid'=>$tid,
				'aid'=>$aid,
				'dateline'=>$_G['timestamp'],
			);
			DB::insert('nimba_tougao',$data);
			if($aid) $message=lang('plugin/nimba_tougao','message_1').'<a href="home.php?mod=space&uid='.$_G['uid'].'" target="_blank">'.$_G['username'].'</a>'.lang('plugin/nimba_tougao','message_2').'<a href="portal.php?mod=view&aid='.$aid.'">'.lang('plugin/nimba_tougao','message_5').'</a>'.lang('plugin/nimba_tougao','message_4').lang('plugin/nimba_tougao','message_6');
			else $message=lang('plugin/nimba_tougao','message_1').'<a href="home.php?mod=space&uid='.$_G['uid'].'" target="_blank">'.$_G['username'].'</a>'.lang('plugin/nimba_tougao','message_2').'<a href="portal.php?mod=portalcp&ac=article&from_idtype=tid&from_id='.$tid.'">'.lang('plugin/nimba_tougao','message_3').'</a>'.lang('plugin/nimba_tougao','message_4');
			notification_add($this->adminuid,'system',$message);
		}
	}
}
class plugin_nimba_tougao_portal extends plugin_nimba_tougao{
	function portalcp_fromthread_output($var){
		global $_G,$aid,$op;
		if(submitcheck('articlesubmit')&&$_POST['from_idtype']=='tid'&&$_POST['from_id']){
			$tid=intval($_POST['from_id']);
			if($op=='add_success'&&$aid){
				$attach=DB::fetch_first("select * from ".DB::table('forum_attachment_'.($tid%10))." where tid='$tid' and isimage=1");
				if($attach){
					$pic='forum/'.$attach['attachment'];
					DB::update('portal_article_title',array('pic'=>$pic),array('aid'=>$aid));
				}		
				DB::query("UPDATE ".DB::table('nimba_tougao')." SET aid=".intval($aid)." WHERE tid='$tid'", 'UNBUFFERED');
			}
		}
	}
}
//From: Dism_taobao-com
?>