<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(submitcheck('submit')){
	$start=trim($_GET['start']);
	$end=trim($_GET['end']);
	$num=intval(trim($_GET['num']));
	if($start&&$end&&$num){
		$start=strtotime($start);
		$end=strtotime($end);
		if($end<=$start){
			cpmsg(lang('plugin/nimba_arcviews','f_time'));
		}else{
			$catid=intval($_GET['catid']);
			$resnum=DB::query("update ".DB::table('portal_article_count')." c join ".DB::table('portal_article_title')." t on c.aid=t.aid set c.viewnum=c.viewnum+".$num." where ".($catid? " t.catid='$catid' and":'')." t.dateline>='$start' and t.dateline<='$end'");
			cpmsg(lang('plugin/nimba_arcviews','m_ok',array('resnum'=>$resnum)),'action=plugins&operation=config&identifier=nimba_arcviews&pmod=cp', 'succeed');	
		}
	}else{
		cpmsg(lang('plugin/nimba_arcviews','m_empty'));
	}
}else{
	include_once libfile('function/portalcp');
	$categoryselect = category_showselect('portal', 'catid', true, $_GET['catid']);
	echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
	showformheader("plugins&operation=config&identifier=nimba_arcviews&pmod=cp");
	showtableheader(lang('plugin/nimba_arcviews','f_title'), 'nobottom');
	showsetting(lang('plugin/nimba_arcviews','f_cat'), 'catid','',$categoryselect, '', 0,lang('plugin/nimba_arcviews','f_cat_info'), 1);	
	showsetting(lang('plugin/nimba_arcviews','f_start'), 'start','', 'calendar', '', 0,lang('plugin/nimba_arcviews','f_start_info'), 1);	
	showsetting(lang('plugin/nimba_arcviews','f_end'), 'end','', 'calendar', '', 0,lang('plugin/nimba_arcviews','f_end_info'), 1);	
	showsetting(lang('plugin/nimba_arcviews','f_num'), 'num','', 'text', '', 0,lang('plugin/nimba_arcviews','f_num_info'), 1);	
	showsubmit('submit');
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*dism _ taobao _com*/
}	
//From: dis'.'m.tao'.'bao.com
?>