<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_nimba_urlsource {
	function deletethread($var){//前台删帖处理
		global $_G;
		if($var['step']=='delete'){
			foreach($var['param'][0] as $k=>$tid){
				C::t('#nimba_urlsource#nimba_urlsource')->delete_by_tid($tid);
			}
		}
	}
}

class mobileplugin_nimba_urlsource_forum extends mobileplugin_nimba_urlsource{
	function viewthread_posttop_mobile_output(){
		global $_G,$postlist;
		$res=array();
		foreach($postlist as $k=>$p){
			if($p['first']==1){
				$source=C::t('#nimba_urlsource#nimba_urlsource')->fetch_by_tid($_G['tid']);
				if($source['stitle']){
					$source['stitle']=dhtmlspecialchars($source['stitle']);
					$source['surl']=dhtmlspecialchars($source['surl']);						
					loadcache('plugin');
					$nofollow=intval($_G['cache']['plugin']['nimba_urlsource']['nofollow']);		
					$spider=intval($_G['cache']['plugin']['nimba_urlsource']['spider']);		
					if(checkrobot()&&$spider){//搜索引擎
						$postlist[$k]['message']=lang('plugin/nimba_urlsource','appname2').$source['stitle'].'<br>'.$postlist[$k]['message'];
					}else{
						$postlist[$k]['message']=lang('plugin/nimba_urlsource','appname2').'<a href="'.$source['surl'].'" class="xi1" target="_blank" '.($nofollow? 'rel="nofollow"':'').'>'.$source['stitle'].'</a><br>'.$postlist[$k]['message'];
					}
				}
			}
			break;
		}
		return $res;
	}
	
	function post_bottom_mobile(){
		global $_G;
		loadcache('plugin');
		$vars = $_G['cache']['plugin']['nimba_urlsource'];
		$forums=unserialize($vars['forums']);
		if($_G['fid']&&in_array($_G['fid'],$forums)){
			$langvar= lang('plugin/nimba_urlsource');		
			if($_G['tid']){//编辑状态
				$source=C::t('#nimba_urlsource#nimba_urlsource')->fetch_by_tid($_G['tid']);
				$source['stitle']=dhtmlspecialchars($source['stitle']);
				$source['surl']=dhtmlspecialchars($source['surl']);					
			}
			include template('nimba_urlsource:post_middle');
			return $return;	
		}	
	}
	
	function post_feedlog_message($var){
		global $_G,$thread,$tid,$pid;
		$tid = $var['param'][2]['tid'];
		$action=$var['param'][0];	
		$_GET['stitle']=addslashes(trim($_GET['stitle']));
		$_GET['surl']=addslashes(trim($_GET['surl']));
		if($_GET['surl']&&!preg_match("/^(http:|https:)\/\/([0-9a-zA-Z][0-9a-zA-Z-]*\.)+[a-zA-Z]{2,}/",$_GET['surl'])){
			$_GET['surl']='';//url不合法
		}		
		if(($action=='post_newthread_succeed'||$action=='post_newthread_mod_succeed')&&($_GET['stitle']||$_GET['surl'])){//发布
			$arr=array(
				'tid'=>$tid,  
				'surl'=>$_GET['surl'],
				'stitle'=>$_GET['stitle'],
			);
			C::t('#nimba_urlsource#nimba_urlsource')->insert($arr);
		}
		
		if($action=='post_edit_succeed'){//编辑
			$source=C::t('#nimba_urlsource#nimba_urlsource')->fetch_by_tid($tid);
			if($source&&($_GET['stitle']||$_GET['surl'])){//检查有误变化
				if($_GET['surl']!=$source['surl']||$_GET['stitle']!=$source['stitle']){
					C::t('#nimba_urlsource#nimba_urlsource')->update_by_tid($tid,array(
						'surl'=>$_GET['surl'],
						'stitle'=>$_GET['stitle'],
					));
				}
			}elseif(!$source&&($_GET['stitle']||$_GET['surl'])){//新增
				$arr=array(
					'tid'=>$tid,  
					'surl'=>$_GET['surl'],
					'stitle'=>$_GET['stitle'],
				);
				C::t('#nimba_urlsource#nimba_urlsource')->insert($arr);			
			}elseif($source&&!($_GET['stitle']||$_GET['surl'])){//删除
				C::t('#nimba_urlsource#nimba_urlsource')->delete_by_tid($tid);
			}
		}
		return '';
	}	

}
//From: Dism·taobao·com
?>