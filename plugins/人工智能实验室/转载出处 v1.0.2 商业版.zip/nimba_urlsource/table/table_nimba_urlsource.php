<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_nimba_urlsource extends discuz_table{
	public function __construct() {

		$this->_table = 'nimba_urlsource';
		$this->_pk    = 'sid';
		$this->_pre_cache_key = 'nimba_urlsource_';

		parent::__construct();
	}
	public function count(){
		$count = DB::result_first('SELECT COUNT(*) FROM %t where url!=\'\'', array($this->_table));
		return $count;
	}

	public function fetch_all_by_range($start,$end) {
		return DB::fetch_all('SELECT * FROM %t where url!=\'\' ORDER BY sid DESC LIMIT %d,%d', array($this->_table,$start,$end), $this->_pk);
	}
	public function fetch_by_tid($tid) {
		return DB::fetch_first("SELECT * FROM %t where tid='%d'",array($this->_table,$tid));
	}	
	public function fetch_url_by_tid($tid) {
		return DB::result_first("SELECT url FROM %t where tid='%d'",array($this->_table,$tid));
	}
	public function fetch_sid_by_tid($tid) {
		return DB::result_first("SELECT sid FROM %t where tid='%d'",array($this->_table,$tid));
	}	
	public function update_by_tid($tid,$arr){
		$tid = dintval($tid,true);
		if($tid){
			DB::query('UPDATE %t SET surl=%s,stitle=%s WHERE tid=%d',array($this->_table,$arr['surl'],$arr['stitle'],$tid));
		}
	}
	public function delete_by_tid($tid) {
		$tid = dintval($tid,true);
		if($tid){
			DB::query('delete from %t WHERE tid=%d',array($this->_table,$tid));
		}
	}	
	public function drop() {
		return DB::query('DROP TABLE IF EXISTS %t',array($this->_table));
	}
}
//From: Dism·taobao·com
?>