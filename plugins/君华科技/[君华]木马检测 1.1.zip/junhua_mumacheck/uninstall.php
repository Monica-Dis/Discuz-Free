<?php 

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

@unlink(DISCUZ_ROOT.'./data/sysdata/cache_junhua_mumacheck_peizhi.php');
@unlink(DISCUZ_ROOT.'./data/sysdata/cache_junhua_mumacheck.php');

$finish = true;
?>