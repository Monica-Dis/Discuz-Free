<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-09-01,10:51:44
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

@include_once DISCUZ_ROOT.'./data/sysdata/cache_junhua_mumaresult.php';


showtableheader();
showsubtitle(array('&#x5e8f;&#x53f7;', '&#x6587;&#x4ef6;&#x8def;&#x5f84;', '&#x5305;&#x542b;&#x7279;&#x5f81;'));

if($junhua_mumaresult) {
	$i = 1;
	foreach($junhua_mumaresult as $key => $value) {
		showtablerow('', array(), array($i,$key,implode('|', array_flip(array_flip($value['code'][0])))));
		$i++;
	}
}else{
	showtablerow('', array(), array(1,"&#x6240;&#x6709;&#x6587;&#x4ef6;&#x90fd;&#x6b63;&#x5e38;"));
}
showtablefooter(); /*Dism��taobao��com*/