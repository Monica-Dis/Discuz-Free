<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-09-01,10:51:44
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

set_time_limit(0);

function junhua_jiadian($v){
	return '.'.$v;
}


//&#x904d;&#x5386;&#x51fd;&#x6570;
function junhua_file_tree($path, $include = array(), $ex = 'php') {
	$files = array();
	if (!empty($include)) {
		$ds = glob($path . '/{' . implode(',', $include) . '}', GLOB_BRACE);
	} else {
		$ds = glob($path . '/*');
	}

	if (is_array($ds)) {
		foreach ($ds as $entry) {
			if (is_file($entry) && dstrpos($entry, array_map("junhua_jiadian", explode('|', $ex)))) {
				$files[] = $entry;
			}
			if (is_dir($entry)) {
				$rs = junhua_file_tree($entry, array(), $ex);
				foreach ($rs as $f) {
					if (dstrpos($f, array_map("junhua_jiadian", explode('|', $ex)))) {
						$files[] = $f;
					}
				}
			}
		}
	}
	
	return $files;
}

$step = max(1, intval($_GET['step']));

@include_once DISCUZ_ROOT.'./data/sysdata/cache_junhua_mumacheck_peizhi.php';


if($step == 2){//&#x626b;&#x63cf;&#x76ee;&#x5f55;

	$path = DISCUZ_ROOT;
	$trees = junhua_file_tree($path, array(), $junhua_mumacheck_peizhi['filetype']);

	writetocache('junhua_mumacheck', getcachevars(array('junhua_mumacheck' => $trees)));
	@include_once DISCUZ_ROOT.'./data/sysdata/cache_junhua_mumacheck.php';

	$badfiles = array();

	writetocache('junhua_mumaresult', getcachevars(array('junhua_mumaresult' => $badfiles)));

	if (isset($junhua_mumacheck) && !empty($junhua_mumacheck) && $junhua_mumacheck_peizhi['featurecode']) {
		foreach ($junhua_mumacheck as $key => $val) {

			$html = file_get_contents($val);
			if (preg_match_all('/('.$junhua_mumacheck_peizhi['featurecode'].')/i', $html, $state)) {
				$badfiles[$val]['code'] = $state;
			}
			$html = '';
		}

		writetocache('junhua_mumaresult', getcachevars(array('junhua_mumaresult' => $badfiles)));
	}

	cpmsg('&#x6b63;&#x5728;&#x641c;&#x7d22;&#x7279;&#x5f81;&#x4ee3;&#x7801;'.$junhua_mumacheck_peizhi['featurecode'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=junhua_mumacheck&pmod=muma&step=3', 'loading', '', FALSE);
}elseif($step == 3){//&#x68c0;&#x6d4b;&#x5f02;&#x5e38;&#x51fd;&#x6570;
	cpmsg('&#x6b63;&#x5728;&#x751f;&#x6210;&#x626b;&#x63cf;&#x62a5;&#x544a;', 'action=plugins&operation=config&do='.$pluginid.'&identifier=junhua_mumacheck&pmod=report', 'loading', '', FALSE);
}




if(submitcheck('menusubmit')) {

	$filetype	= $_GET['filetype'] ? $_GET['filetype'] : 'php';
	$featurecode		= $_GET['featurecode'] ? $_GET['featurecode'] : 'system|exec|eval|cmd|base64_decode|gzuncompress';

	$junhua_mumacheck_peizhi = array(
		'featurecode'	=> $featurecode,
		'filetype'		=> $filetype,
	);

	writetocache('junhua_mumacheck_peizhi', getcachevars(array('junhua_mumacheck_peizhi' => $junhua_mumacheck_peizhi)));

	cpmsg('&#x6b63;&#x5728;&#x8bfb;&#x53d6;&#x6240;&#x6709;'.$filetype.'&#x6587;&#x4ef6;', 'action=plugins&operation=config&do='.$pluginid.'&identifier=junhua_mumacheck&pmod=muma&step=2', 'loading', '', FALSE);
}else{


	$litips = '<li>&#x5982;&#x679c;&#x60a8;&#x7f51;&#x7ad9;&#x6587;&#x4ef6;&#x8f83;&#x591a;&#xff0c;&#x8bf7;&#x5c1d;&#x8bd5;&#x5c3d;&#x53ef;&#x80fd;&#x7684;&#x51cf;&#x5c11;&#x68c0;&#x6d4b;&#x7684;&#x6587;&#x4ef6;&#x7c7b;&#x578b;</li>
				<li>&#x5982;&#x679c;&#x6587;&#x4ef6;&#x8f83;&#x591a;&#xff0c;&#x53ef;&#x80fd;&#x4f1a;&#x68c0;&#x6d4b;&#x65f6;&#x95f4;&#x6bd4;&#x8f83;&#x4e45;&#xff0c;&#x8bf7;&#x52ff;&#x4e2d;&#x9014;&#x5237;&#x65b0;&#x6216;&#x9000;&#x51fa;&#x9875;&#x9762;&#xff01;</li>
				<li>&#x672c;&#x7a0b;&#x5e8f;&#x4e0d;&#x4f1a;&#x5c1d;&#x8bd5;&#x4fee;&#x590d;&#x68c0;&#x6d4b;&#x51fa;&#x6765;&#x7684;&#x6587;&#x4ef6;, &#x68c0;&#x6d4b;&#x5b8c;&#x6210;&#x540e;&#x8bf7;&#x81ea;&#x884c;&#x4f7f;&#x7528;&#x7f16;&#x8f91;&#x5668;&#x67e5;&#x770b;&#x6587;&#x4ef6;&#x662f;&#x5426;&#x771f;&#x7684;&#x6709;&#x5371;&#x9669;&#xff01;</li>';

	showtips($litips);

	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=junhua_mumacheck&pmod=muma');
	showtableheader();

	showtablerow('', array('', ''), array(
		"&#x68c0;&#x6d4b;&#x6587;&#x4ef6;&#x7c7b;&#x578b;",
		"<input type=\"text\" style=\"width:500px\" class=\"txt\" name=\"filetype\" placeholder=\"&#x4e0d;&#x586b;&#x5199;&#x9ed8;&#x8ba4;&#x4e3a;php &#x5982;&#x9700;&#x68c0;&#x6d4b;&#x591a;&#x79cd;&#x7c7b;&#x578b;&#xff0c;&#x8bf7;&#x4ee5;&#x82f1;&#x6587;&#x7ad6;&#x7ebf;&#x5206;&#x9694;&#xff0c;&#x4f8b;&#x5982;php|html|jpg\" value=\"".dhtmlspecialchars($junhua_mumacheck_peizhi['filetype'])."\">",
	));

	showtablerow('', array('', ''), array(
		"&#x68c0;&#x6d4b;&#x5f02;&#x5e38;&#x7279;&#x5f81;&#x7801;",
		"<input type=\"text\" style=\"width:500px\" class=\"txt\" name=\"featurecode\" placeholder=\"&#x4e0d;&#x586b;&#x5199;&#x9ed8;&#x8ba4;&#x4e3a;system|exec|eval|cmd|base64_decode|gzuncompress\" value=\"".dhtmlspecialchars($junhua_mumacheck_peizhi['featurecode'])."\">",
	));

	showsubmit('menusubmit', '&#x7acb;&#x5373;&#x67e5;&#x6740;');
	showtablefooter(); /*Dism��taobao��com*/
	/*Dism_taobao_com*/showformfooter();

}
