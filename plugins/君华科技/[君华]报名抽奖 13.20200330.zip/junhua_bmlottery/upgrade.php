<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql['5.20200219'] = <<<EOF
ALTER TABLE `pre_junhua_bmlottery` ADD COLUMN `qt_cjtj`  varchar(128) DEFAULT '' AFTER `update_time`;
ALTER TABLE `pre_junhua_bmlottery` ADD COLUMN `qt_zjnr`  varchar(128) DEFAULT '' AFTER `qt_cjtj`;
ALTER TABLE `pre_junhua_bmlottery` ADD COLUMN `qt_kjsj`  varchar(128) DEFAULT '' AFTER `qt_zjnr`;
ALTER TABLE `pre_junhua_bmlottery` ADD COLUMN `qt_kjjs`  varchar(128) DEFAULT '' AFTER `qt_kjsj`;
ALTER TABLE `pre_junhua_bmlottery` ADD COLUMN `end_time`  int(10) DEFAULT 0 AFTER `qt_kjjs`;
ALTER TABLE `pre_junhua_bmlottery` ADD COLUMN `is_loop`  tinyint(1) UNSIGNED DEFAULT 0 AFTER `end_time`;
ALTER TABLE `pre_junhua_bmlottery` ADD COLUMN `is_except`  tinyint(1) UNSIGNED DEFAULT 0 AFTER `is_loop`;
ALTER TABLE `pre_junhua_bmlottery` ADD COLUMN `app_tuisong`  varchar(1000) DEFAULT '' AFTER `is_except`;
ALTER TABLE `pre_junhua_bmlottery` ADD COLUMN `lottery_fields`  varchar(1000) DEFAULT '' AFTER `app_tuisong`;
ALTER TABLE `pre_junhua_bmlottery` ADD COLUMN `maga_zhushou_open`  tinyint(1) UNSIGNED DEFAULT 0 AFTER `lottery_fields`;
ALTER TABLE `pre_junhua_bmlottery_baoming` ADD COLUMN `username`  varchar(64) DEFAULT '' AFTER `user_id`;
ALTER TABLE `pre_junhua_bmlottery_baoming` ADD COLUMN `fields`  text AFTER `username`;

CREATE TABLE IF NOT EXISTS `pre_junhua_bmlottery_lucky` (
  `lucky_id` int(11) NOT NULL AUTO_INCREMENT,
  `baoming_id` int(11) DEFAULT '0',
  `lottery_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `username` varchar(64) DEFAULT '',
  `fields` text,
  `baoming_time` int(11) DEFAULT '0',
  `lucky_time` int(11) unsigned DEFAULT '0',
  `lucky_date` int(11) DEFAULT '0',
  PRIMARY KEY (`lucky_id`),
  KEY `user_id` (`user_id`),
  KEY `lottery_id` (`lottery_id`),
  KEY `baoming_id` (`baoming_id`),
  KEY `lucky_time` (`lucky_time`),
  KEY `lucky_date` (`lucky_date`)
) ENGINE=MyISAM AUTO_INCREMENT=1;
EOF;

$sql['6.20200220'] = <<<EOF
ALTER TABLE `pre_junhua_bmlottery`
ADD COLUMN `canjia_num`  varchar(32) NULL DEFAULT '';

ALTER TABLE `pre_junhua_bmlottery`
MODIFY COLUMN `lottery_desc`  text AFTER `lottery_time`;

ALTER TABLE `pre_junhua_bmlottery`
ADD COLUMN `app_bmtuisong`  varchar(1000) NULL DEFAULT '' AFTER `app_tuisong`;
EOF;

$sql['7.20200221'] = <<<EOF
ALTER TABLE `pre_junhua_bmlottery`
ADD COLUMN `share_title`  varchar(256) NULL DEFAULT '' AFTER `canjia_num`,
ADD COLUMN `share_desc`  varchar(256) NULL DEFAULT '' AFTER `share_title`,
ADD COLUMN `share_img`  varchar(256) NULL DEFAULT '' AFTER `share_desc`;
EOF;

$sql['11.20200309'] = <<<EOF
ALTER TABLE `pre_junhua_bmlottery`
ADD COLUMN `lottery_hexiao`  varchar(256) NULL DEFAULT '' AFTER `lottery_src`;

ALTER TABLE `pre_junhua_bmlottery_lucky`
ADD COLUMN `hexiao_time`  int(11) UNSIGNED NULL DEFAULT 0 AFTER `lucky_date`,
ADD COLUMN `hexiao_uid`  int(10) UNSIGNED NULL DEFAULT 0 AFTER `hexiao_time`,
ADD COLUMN `is_hexiao`  tinyint(1) UNSIGNED NULL DEFAULT 0 AFTER `hexiao_uid`;

ALTER TABLE `pre_junhua_bmlottery`
ADD COLUMN `app_bmhxtuisong`  varchar(1000) NULL DEFAULT '' AFTER `app_bmtuisong`;

ALTER TABLE `pre_junhua_bmlottery`
ADD COLUMN `expiry_day`  int(10) NULL DEFAULT 0 AFTER `canjia_num`;

EOF;

$sql['13.20200330'] = <<<EOF
ALTER TABLE `pre_junhua_bmlottery_baoming`
ADD COLUMN `is_pay`  tinyint(1) UNSIGNED NULL DEFAULT 0 AFTER `is_prize`,
ADD COLUMN `pay_time`  int(10) UNSIGNED NULL DEFAULT 0 AFTER `is_pay`;

ALTER TABLE `pre_junhua_bmlottery`
ADD COLUMN `open_pay`  tinyint(1) NULL DEFAULT 0 AFTER `is_except`,
ADD COLUMN `money`  decimal(14,2) NULL DEFAULT 0 AFTER `open_pay`;


ALTER TABLE `pre_junhua_bmlottery_baoming`
ADD COLUMN `total_amount`  decimal(14,2) NULL DEFAULT 0.00 AFTER `is_pay`,
ADD COLUMN `trade_no`  varchar(64) NULL DEFAULT '' AFTER `total_amount`,
ADD COLUMN `out_trade_no`  varchar(64) NULL DEFAULT '' AFTER `trade_no`;

ALTER TABLE `pre_junhua_bmlottery_baoming`
ADD COLUMN `paytype`  tinyint(1) NULL DEFAULT 0 AFTER `out_trade_no`;

ALTER TABLE `pre_junhua_bmlottery`
ADD COLUMN `point`  int(10) NULL DEFAULT 0 AFTER `money`,
ADD COLUMN `point_type`  tinyint(1) NULL DEFAULT 0 AFTER `point`;


EOF;


foreach($sql as $key => $value) {
    if($_GET['fromversion'] < $key) {
        runquery($value);
    }
}

$finish = true;