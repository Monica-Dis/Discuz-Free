<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$ADMINSCRIPT = ADMINSCRIPT;
$siteurl = $_G['siteurl'];

$createtablesql = <<<EOF

DROP TABLE IF EXISTS `pre_junhua_bmlottery`;
CREATE TABLE `pre_junhua_bmlottery` (
  `lottery_id` int(11) NOT NULL AUTO_INCREMENT,
  `lottery_title` varchar(256) DEFAULT '',
  `lottery_renshu` int(10) DEFAULT '0',
  `lottery_yaoqiu` varchar(256) DEFAULT '',
  `lottery_prize` varchar(256) DEFAULT '',
  `lottery_time` int(10) DEFAULT '0',
  `lottery_desc` text,
  `lottery_status` tinyint(1) DEFAULT '0',
  `lottery_users` text,
  `lottery_cover` varchar(256) DEFAULT '',
  `lottery_src` varchar(256) DEFAULT '',
  `lottery_hexiao` varchar(256) DEFAULT '',
  `is_weixin_bm` tinyint(1) DEFAULT '1',
  `is_enable` tinyint(1) DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  `update_time` int(10) unsigned DEFAULT '0',
  `qt_cjtj` varchar(128) DEFAULT '',
  `qt_zjnr` varchar(128) DEFAULT '',
  `qt_kjsj` varchar(128) DEFAULT '',
  `qt_kjjs` varchar(128) DEFAULT '',
  `end_time` int(10) DEFAULT '0',
  `is_loop` tinyint(1) unsigned DEFAULT '0',
  `is_except` tinyint(1) unsigned DEFAULT '0',
  `open_pay` tinyint(1) DEFAULT '0',
  `money` decimal(14,2) DEFAULT '0.00',
  `point` int(10) DEFAULT '0',
  `point_type` tinyint(1) DEFAULT '0',
  `app_tuisong` varchar(1000) DEFAULT '',
  `app_bmtuisong` varchar(1000) DEFAULT '',
  `app_bmhxtuisong` varchar(1000) DEFAULT '',
  `lottery_fields` varchar(1000) DEFAULT '',
  `maga_zhushou_open` tinyint(1) unsigned DEFAULT '0',
  `canjia_num` varchar(32) DEFAULT '',
  `expiry_day` int(10) DEFAULT '0',
  `share_title` varchar(256) DEFAULT '',
  `share_desc` varchar(256) DEFAULT '',
  `share_img` varchar(256) DEFAULT '',
  PRIMARY KEY (`lottery_id`),
  KEY `lottery_status` (`lottery_status`),
  KEY `is_enable` (`is_enable`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


DROP TABLE IF EXISTS `pre_junhua_bmlottery_baoming`;
CREATE TABLE `pre_junhua_bmlottery_baoming` (
  `baoming_id` int(11) NOT NULL AUTO_INCREMENT,
  `lottery_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `username` varchar(64) DEFAULT '',
  `fields` text,
  `is_prize` tinyint(1) DEFAULT '0',
  `is_pay` tinyint(1) unsigned DEFAULT '0',
  `total_amount` decimal(14,2) DEFAULT '0.00',
  `trade_no` varchar(64) DEFAULT '',
  `out_trade_no` varchar(64) DEFAULT '',
  `paytype` tinyint(1) DEFAULT '0',
  `pay_time` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`baoming_id`),
  KEY `user_id` (`user_id`),
  KEY `lottery_id` (`lottery_id`),
  KEY `add_time` (`add_time`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


DROP TABLE IF EXISTS `pre_junhua_bmlottery_lucky`;
CREATE TABLE `pre_junhua_bmlottery_lucky` (
  `lucky_id` int(11) NOT NULL AUTO_INCREMENT,
  `baoming_id` int(11) DEFAULT '0',
  `lottery_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `username` varchar(64) DEFAULT '',
  `fields` text,
  `baoming_time` int(11) DEFAULT '0',
  `lucky_time` int(11) unsigned DEFAULT '0',
  `lucky_date` int(11) DEFAULT '0',
  `hexiao_time` int(11) unsigned DEFAULT '0',
  `hexiao_uid` int(10) unsigned DEFAULT '0',
  `is_hexiao` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`lucky_id`),
  KEY `user_id` (`user_id`),
  KEY `lottery_id` (`lottery_id`),
  KEY `baoming_id` (`baoming_id`),
  KEY `lucky_time` (`lucky_time`),
  KEY `lucky_date` (`lucky_date`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



EOF;

runquery($createtablesql);
$finish = TRUE;
?>