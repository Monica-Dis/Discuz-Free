<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!in_array($a, array('baoming', 'hexiao', 'pay', 'callback'))){
    $a = 'baoming';
}

$lotteryModel = new junhua_model('bmlottery');
$baomingModel = new junhua_model('bmlotteryBaoming');
$LuckyModel = new junhua_model('bmlotteryLucky');

if($a == 'baoming'){

    if(IS_AJAX){
        $lid = junhua_I('lid/s', 0);
        $fields = junhua_I('fields/a', array());
        $where = array();
        $where['lottery_id'] = $lid;

        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        $junhua_bmlottery_setting['manage_group'] = dunserialize($junhua_bmlottery_setting['manage_group']);
        $junhua_bmlottery_setting['manage_group'] = array_filter($junhua_bmlottery_setting['manage_group']);

        if($junhua_bmlottery_setting['manage_group'] && !in_array($_G['groupid'], $junhua_bmlottery_setting['manage_group'])){
            $data = array('code' => 0, 'msg' => '&#x60a8;&#x65e0;&#x6cd5;&#x62a5;&#x540d;&#x53c2;&#x52a0;&#xff0c;&#x8bf7;&#x8054;&#x7cfb;&#x7ba1;&#x7406;&#x5458;&#xff01;');
            junhua_ajaxReturn($data);
        }

        $lotteryInfo = $lotteryModel->find($where);
        if(!$lotteryInfo){
            exit;
        }

        if(!$lotteryInfo){
            $data = array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
            junhua_ajaxReturn($data);
        }

        if($lotteryInfo['is_enable'] == 0){
            $data = array('code' => 0, 'msg' => '&#x6d3b;&#x52a8;&#x4e0d;&#x5b58;&#x5728;');
            junhua_ajaxReturn($data);
        }

        //&#x5224;&#x65ad;&#x662f;&#x5426;&#x5df2;&#x7ecf;&#x53ef;&#x4ee5;&#x7ed3;&#x675f;
        if(($lotteryInfo['is_loop'] == 1 && $lotteryInfo['end_time'] <= $_G['timestamp']) || ($lotteryInfo['is_loop'] == 0 && $_G['timestamp'] >= $lotteryInfo['lottery_time'])){
            $data = array('code' => 0, 'msg' => '&#x6d3b;&#x52a8;&#x5df2;&#x7ed3;&#x675f;');
            junhua_ajaxReturn($data);
        }


        if($lotteryInfo['lottery_status'] == 2){
            $data = array('code' => 0, 'msg' => '&#x6d3b;&#x52a8;&#x5df2;&#x7ed3;&#x675f;');
            junhua_ajaxReturn($data);
        }

        if($lotteryInfo['open_pay'] != 0){
            $baomingInfo = $baomingModel->find(array('user_id' => $uid, 'lottery_id' => $lid, 'is_pay' => 1));
        }else{
            $baomingInfo = $baomingModel->find(array('user_id' => $uid, 'lottery_id' => $lid));
        }

        //&#x9ed8;&#x8ba4;&#x4e0d;&#x9700;&#x8981;&#x652f;&#x4ed8;
        $need_pay = false;

        if($baomingInfo){
            $data = array('code' => 0, 'msg' => '&#x60a8;&#x5df2;&#x62a5;&#x540d;&#xff0c;&#x8bf7;&#x52ff;&#x91cd;&#x590d;&#x62a5;&#x540d;');
            junhua_ajaxReturn($data);
        }else{

            if($lotteryInfo['open_pay'] == 1){ //&#x73b0;&#x91d1;
                $baoming_id = $baomingModel->add(array('user_id' => $uid, 'username' => $_G['username'],  'lottery_id' => $lid, 'fields' => serialize($fields), 'add_time' => $_G['timestamp'], 'out_trade_no' => junhua_getorderno('jbm_'), 'total_amount' => $lotteryInfo['money']));
                $need_pay = true;

            }elseif ($lotteryInfo['open_pay'] == 2 && $lotteryInfo['point_type'] && $lotteryInfo['point']) { //&#x79ef;&#x5206;
                $query = C::t('common_member_count')->fetch($uid);
                $credit = array(
                    '1' => $query['extcredits1'],
                    '2' => $query['extcredits2'],
                    '3' => $query['extcredits3'],
                    '4' => $query['extcredits4'],
                    '5' => $query['extcredits5'],
                    '6' => $query['extcredits6'],
                    '7' => $query['extcredits7'],
                    '8' => $query['extcredits8']
                );

                //&#x5224;&#x65ad;&#x79ef;&#x5206;&#x662f;&#x5426;&#x591f;
                if($lotteryInfo['point'] > $credit[$lotteryInfo['point_type']]){
                    $data = array('code' => 0, 'msg' => '&#x60a8;&#x7684;'.$_G['setting']['extcredits'][$lotteryInfo['point_type']]['title'].'&#x4e0d;&#x8db3;');
                    junhua_ajaxReturn($data);
                }

                //&#x591f;&#x79ef;&#x5206; &#x76f4;&#x63a5;&#x6263;&#x9664;&#x79ef;&#x5206; &#x5e76;&#x4e14;&#x8ba2;&#x5355;&#x72b6;&#x6001;&#x6539;&#x6210;&#x5df2;&#x652f;&#x4ed8;
                updatemembercount($uid, array(
                    $lotteryInfo['point_type'] => -$lotteryInfo['point']
                ), true, '', 0, $lotteryInfo['lottery_title'], $lotteryInfo['lottery_title'],  $lotteryInfo['lottery_title']);

                $baoming_id = $baomingModel->add(array('user_id' => $uid, 'username' => $_G['username'],  'lottery_id' => $lid, 'fields' => serialize($fields), 'add_time' => $_G['timestamp'], 'out_trade_no' => junhua_getorderno('jbm_'), 'total_amount' => $lotteryInfo['point'], 'is_pay' => 1, 'paytype' => 3, 'pay_time' => $_G['timestamp']));
            }elseif ($lotteryInfo['open_pay'] == 3 && $lotteryInfo['point_type'] && $lotteryInfo['point']) { //&#x79ef;&#x5206; &#x73b0;&#x91d1;
                $query = C::t('common_member_count')->fetch($uid);
                $credit = array(
                    '1' => $query['extcredits1'],
                    '2' => $query['extcredits2'],
                    '3' => $query['extcredits3'],
                    '4' => $query['extcredits4'],
                    '5' => $query['extcredits5'],
                    '6' => $query['extcredits6'],
                    '7' => $query['extcredits7'],
                    '8' => $query['extcredits8']
                );

                //&#x5224;&#x65ad;&#x79ef;&#x5206;&#x662f;&#x5426;&#x591f;
                if($lotteryInfo['point'] > $credit[$lotteryInfo['point_type']]){
                    $baoming_id = $baomingModel->add(array('user_id' => $uid, 'username' => $_G['username'],  'lottery_id' => $lid, 'fields' => serialize($fields), 'add_time' => $_G['timestamp'], 'out_trade_no' => junhua_getorderno('jbm_'), 'total_amount' => $lotteryInfo['money']));
                    $need_pay = true;

                }else{

                    //&#x591f;&#x79ef;&#x5206; &#x76f4;&#x63a5;&#x6263;&#x9664;&#x79ef;&#x5206; &#x5e76;&#x4e14;&#x8ba2;&#x5355;&#x72b6;&#x6001;&#x6539;&#x6210;&#x5df2;&#x652f;&#x4ed8;
                    updatemembercount($uid, array(
                        $lotteryInfo['point_type'] => -$lotteryInfo['point']
                    ), true, '', 0, $lotteryInfo['lottery_title'], $lotteryInfo['lottery_title'],  $lotteryInfo['lottery_title']);

                    $baoming_id = $baomingModel->add(array('user_id' => $uid, 'username' => $_G['username'],  'lottery_id' => $lid, 'fields' => serialize($fields), 'add_time' => $_G['timestamp'], 'out_trade_no' => junhua_getorderno('jbm_'), 'total_amount' => $lotteryInfo['point'], 'is_pay' => 1, 'paytype' => 3, 'pay_time' => $_G['timestamp']));
                }
            }else{
                $baoming_id = $baomingModel->add(array('user_id' => $uid, 'username' => $_G['username'],  'lottery_id' => $lid, 'fields' => serialize($fields), 'add_time' => $_G['timestamp'], 'out_trade_no' => junhua_getorderno('jbm_'), 'total_amount' => $lotteryInfo['money']));
            }

        }

        $junhuaApp = new junhua_App($junhua_base_config, $junhua_bmlottery_setting);

        $tuisong_text = $lotteryInfo['app_bmtuisong'];

        if($tuisong_text){

            $tuisong_text = str_replace(array(
                '[choujiangbiaoti]',
                '[choujiangyaoqiu]',
                '[zhongjiangneirong]',
                '[choujiangmiaoshu]',
                '[choujianglianjie]',
                '[kaijiangshijian]',
            ), array(
                $lotteryInfo['lottery_title'],
                $lotteryInfo['lottery_yaoqiu'],
                $lotteryInfo['lottery_prize'],
                $lotteryInfo['lottery_desc'],
                $_G['siteurl'].junhua_url('m/lottery/detail', 'lid='.$lotteryInfo['lottery_id'], 1),
                date('Y-m-d H:i', $lotteryInfo['lottery_time']),
            ), $tuisong_text);

            //&#x53d1;&#x9001;APP&#x901a;&#x77e5;

            $canshu = $fields;

            //&#x83b7;&#x53d6;&#x4e0b;&#x6807;
            $xb = array();
            foreach ($canshu as $kxb => $vxb) {
                $xb[] = '[canshu_'.($kxb+1).']';
            }

            $app_bmtuisong = str_replace(array(
                '[baominghao]',
                '[username]',
            ), array(
                $baoming_id,
                $_G['username'],
            ), $tuisong_text);

            $app_bmtuisong = str_replace($xb, $canshu, $app_bmtuisong);

            //&#x9a6c;&#x7532;&#x6d88;&#x606f;&#x63d0;&#x793a;
            if($junhua_base_config['app_type'] == 1){
                //app&#x901a;&#x77e5;&#x7684;&#x5185;&#x5bb9;&#x7ec4;&#x5408;
                $content = array(
                    'type'   => 'text',
                    'content' => $app_bmtuisong,
                );
                
                $junhuaApp->sendMagaTemplate($uid, $content);
            }elseif($junhua_base_config['app_type'] == 2){
                //app&#x901a;&#x77e5;&#x7684;&#x5185;&#x5bb9;&#x7ec4;&#x5408;

                $showData = array(
                    'title'   => junhua_utf82gbk(junhua_unicodeDecode('&#x62a5;&#x540d;&#x6210;&#x529f;')),
                    'date'    => date('Y-m-d H:i'),
                    'setting' => array(),
                    'content' => $app_bmtuisong,
                    'url'     => $_G['siteurl'].junhua_url('m/lottery/detail', 'lid='.$lotteryInfo['lottery_id'], 1),
                );

                $content = array(
                    'from'     => $junhua_bmlottery_setting['qf_fwhuid'],
                    'target'   => $uid,
                    'msg'      => junhua_utf82gbk(junhua_unicodeDecode('&#x62a5;&#x540d;&#x6210;&#x529f;')),
                    'showData' => junhua_json_encode($showData),
                );

                $junhuaApp->sendQfTemplate($content);
            }
        }

        $data = array('code' => 2, 'msg' => '&#x606d;&#x559c;&#x60a8;&#xff0c;&#x62a5;&#x540d;&#x6210;&#x529f;', 'baoming_id' => $baoming_id, 'need_pay' => $need_pay);
        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}elseif($a == 'hexiao'){

    if(IS_AJAX){
        $lucky_id = junhua_I('luckyid/d', 0);

        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }


        $where = array();
        $where['lucky_id'] = $lucky_id;

        //&#x67e5;&#x8be2;&#x4e2d;&#x5956;&#x4fe1;&#x606f;
        $luckyInfo = $LuckyModel->find($where);
        if(!$luckyInfo){
            $data = array('code' => 0, 'msg' => '&#x65e0;&#x6b64;&#x4fe1;&#x606f;');
            junhua_ajaxReturn($data);
        }

        //&#x67e5;&#x8be2;&#x6d3b;&#x52a8;&#x4fe1;&#x606f;
        $lotteryInfo = $lotteryModel->find(array('lottery_id' => $luckyInfo['lottery_id']));
        if(!$lotteryInfo){
            $data = array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
            junhua_ajaxReturn($data);
        }

        //&#x5224;&#x65ad;&#x6743;&#x9650;
        $uids = explode(",", $lotteryInfo['lottery_hexiao']);
        if( !in_array($uid, $uids)){
            $data = array('code' => 0, 'msg' => '&#x60a8;&#x65e0;&#x6743;&#x6838;&#x9500;');
            junhua_ajaxReturn($data);
        }

        if($luckyInfo['is_hexiao']){
            $data = array('code' => 0, 'msg' => '&#x5df2;&#x6838;&#x9500;');
            junhua_ajaxReturn($data);
        }

        //&#x5224;&#x65ad;&#x662f;&#x5426;&#x6838;&#x9500;&#x8fc7;&#x671f;
        if($lotteryInfo['expiry_day'] != 0){
            $luckyInfo['hexiao_expired'] = $luckyInfo['lucky_time'] + $lotteryInfo['expiry_day'] * 86400;
        }else{
            $luckyInfo['hexiao_expired'] = -1;
        }

        if($luckyInfo['hexiao_expired'] != -1 && $luckyInfo['hexiao_expired'] < $_G['timestamp']){
            $data = array('code' => 0, 'msg' => '&#x6b64;&#x4e8c;&#x7ef4;&#x7801;&#x5df2;&#x8fc7;&#x671f;');
            junhua_ajaxReturn($data);
        }

        //&#x6838;&#x9500;&#x901a;&#x8fc7;
        $LuckyModel->save($where, array('hexiao_time' => $_G['timestamp'], 'is_hexiao' => 1, 'hexiao_uid' => $uid));

        $junhuaApp = new junhua_App($junhua_base_config, $junhua_bmlottery_setting);

        $tuisong_text = $lotteryInfo['app_bmhxtuisong'];

        if($tuisong_text){

            $tuisong_text = str_replace(array(
                '[choujiangbiaoti]',
                '[zhongjiangrenshu]',
                '[choujiangyaoqiu]',
                '[zhongjiangneirong]',
                '[choujiangmiaoshu]',
                '[choujianglianjie]',
                '[kaijiangshijian]',
            ), array(
                $lotteryInfo['lottery_title'],
                $lotteryInfo['lottery_renshu'],
                $lotteryInfo['lottery_yaoqiu'],
                $lotteryInfo['lottery_prize'],
                $lotteryInfo['lottery_desc'],
                $_G['siteurl'].junhua_url('m/lottery/detail', 'lid='.$lotteryInfo['lottery_id'], 1),
                date('Y-m-d H:i', $lotteryInfo['lottery_time']),
            ), $tuisong_text);

            //&#x53d1;&#x9001;APP&#x901a;&#x77e5;
            $canshu = dunserialize($luckyInfo['fields']);

            //&#x83b7;&#x53d6;&#x4e0b;&#x6807;
            $xb = array();
            foreach ($canshu as $kxb => $vxb) {
                $xb[] = '[canshu_'.($kxb+1).']';
            }

            $app_tuisong = str_replace(array(
                '[baominghao]',
                '[zhongjianghao]',
                '[username]',
            ), array(
                $luckyInfo['baoming_id'],
                $luckyInfo['lucky_id'],
                $luckyInfo['username'],
            ), $tuisong_text);

            $app_tuisong = str_replace($xb, $canshu, $app_tuisong);


            //&#x9a6c;&#x7532;&#x6d88;&#x606f;&#x63d0;&#x793a;
            if($junhua_base_config['app_type'] == 1){
                //app&#x901a;&#x77e5;&#x7684;&#x5185;&#x5bb9;&#x7ec4;&#x5408;
                $content = array(
                    'type'   => 'text',
                    'content' => $app_tuisong,
                );

                $junhuaApp->sendMagaTemplate($luckyInfo['user_id'], $content);
            }elseif($junhua_base_config['app_type'] == 2){
                //app&#x901a;&#x77e5;&#x7684;&#x5185;&#x5bb9;&#x7ec4;&#x5408;

                $showData = array(
                    'title'   => junhua_utf82gbk(junhua_unicodeDecode('&#x62a5;&#x540d;&#x6210;&#x529f;')),
                    'date'    => date('Y-m-d H:i'),
                    'setting' => array(),
                    'content' => $app_tuisong,
                    'url'     => $_G['siteurl'].junhua_url('m/lottery/detail', 'lid='.$lotteryInfo['lottery_id'], 1),
                );

                $content = array(
                    'from'     => $junhua_bmlottery_setting['qf_fwhuid'],
                    'target'   => $luckyInfo['user_id'],
                    'msg'      => junhua_utf82gbk(junhua_unicodeDecode('&#x62a5;&#x540d;&#x6210;&#x529f;')),
                    'showData' => junhua_json_encode($showData),
                );

                $junhuaApp->sendQfTemplate($content);
            }
        }

        $data = array('code' => 2, 'msg' => '&#x6838;&#x9500;&#x6210;&#x529f;');
        junhua_ajaxReturn($data);

    }else{
        exit;
    }


}elseif($a == 'pay'){

    if(IS_AJAX){

        $baoming_id = junhua_I('baoming_id/d', 0);

        //&#x63d2;&#x5165;&#x8ba2;&#x5355;
        $baomingInfo = $baomingModel->find(array(
            'baoming_id' => $baoming_id, //&#x5916;&#x90e8;&#x8ba2;&#x5355;
            'user_id'    => $uid,  //&#x7528;&#x6237;UID
        ));

        $lotteryInfo = $lotteryModel->find(array(
            'lottery_id'    => $baomingInfo['lottery_id']
        ));


        if(IS_MAGA){
            $junhuaApp = new junhua_App($junhua_base_config, $junhua_bmlottery_setting);

            $param = array(
                'out_trade_no' => $baomingInfo['out_trade_no'], //&#x5916;&#x90e8;&#x8ba2;&#x5355;
                'money'        => $baomingInfo['total_amount'], //&#x652f;&#x4ed8;&#x91d1;&#x989d;
                'des'          => '', //&#x652f;&#x4ed8;&#x63cf;&#x8ff0;
                'remark'       => '', //&#x652f;&#x4ed8;&#x5907;&#x6ce8;
                'uid'          => $baomingInfo['user_id'],  //&#x7528;&#x6237;UID
                'title'        => $lotteryInfo['lottery_title'], //&#x652f;&#x4ed8;&#x6807;&#x9898;
            );

            $r = $junhuaApp->getMagaCreateOrder($param);

            if(isset($r['data']['unionOrderNum'])){

                $unionOrderNum = $r['data']['unionOrderNum'];

                $baomingModel->save(array(
                    'baoming_id' => $baoming_id, //&#x5916;&#x90e8;&#x8ba2;&#x5355;
                    'user_id'    => $uid,  //&#x7528;&#x6237;UID
                ),array(
                    'trade_no'  => $unionOrderNum
                ));

                junhua_ajaxReturn(array(
                    'status'        => 1,
                    'unionOrderNum' => $unionOrderNum,
                    'out_trade_no'  => $baomingInfo['out_trade_no'],
                    'total_amount'  => $baomingInfo['total_amount'],
                    'title'         => junhua_gbk2utf8($lotteryInfo['lottery_title']),
                    'des'           => '',
                ));

            }else{
                junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;&#xff0c;&#x8bf7;&#x7a0d;&#x540e;&#x518d;&#x8bd5;'));
            }

        }elseif(IS_WEIXIN) {

            include_once('source/plugin/junhua_base/libs/weixin/weixin_pay.php');

            $weixin_appid = $junhua_bmlottery_setting['weixin_appid'] ? trim($junhua_bmlottery_setting['weixin_appid']) : trim($junhua_base_config['weixin_appid']);
            $weixin_appsecret = $junhua_bmlottery_setting['weixin_appsecret'] ? trim($junhua_bmlottery_setting['weixin_appsecret']) : trim($junhua_base_config['weixin_appsecret']);
            $weixin_mchid = $junhua_bmlottery_setting['weixin_mchid'] ? trim($junhua_bmlottery_setting['weixin_mchid']) : trim($junhua_base_config['weixin_mchid']);
            $weixin_key = $junhua_bmlottery_setting['weixin_key'] ? trim($junhua_bmlottery_setting['weixin_key']) : trim($junhua_base_config['weixin_key']);

            $weixin_table  = $junhua_base_config['weixin_table'];
            $weixin_tables = explode(',', $weixin_table);
            $tableName     = str_replace(DB::object()->tablepre, '', $weixin_tables[0]);
            $uidField      = $weixin_tables[1];
            $openidField   = $weixin_tables[2];

            //&#x67e5;&#x8be2;openid
            $wxTableModel = new junhua_model($tableName, '');
            $openid = $wxTableModel->getField(array(
                $uidField => $uid
            ), $openidField);

            if($weixin_appid && $weixin_appsecret && $weixin_mchid && $weixin_key && $openidField){
                $weixin_pay = new WEIXIN_PAY($weixin_appid, $weixin_appsecret, $weixin_mchid, $weixin_key);

                $weixin_pay->body = junhua_gbk2utf8($lotteryInfo['lottery_title']);
                $weixin_pay->out_trade_no = $baomingInfo['out_trade_no'];
                $weixin_pay->total_fee = $baomingInfo['total_amount']*100;    // &#x5355;&#x4f4d;&#x4e3a; &#x201c;&#x5206;&#x201d;, &#x5b57;&#x7b26;&#x4e32;&#x7c7b;&#x578b;
                $weixin_pay->openid = $openid;
                $callback     = $_G['siteurl'].'source/plugin/junhua_bmlottery/wxnotify.php';
                $weixin_pay->notify_url = $callback;

                $payment = $weixin_pay->getConfig();

                junhua_ajaxReturn(array(
                    'status'  => 1,
                    'payment' => $payment,
                ));
            }else{
                junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;&#xff0c;&#x8bf7;&#x7a0d;&#x540e;&#x518d;&#x8bd5;'));
            }
        }

    }

}
else{
	exit;
}