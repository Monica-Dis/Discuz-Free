<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!in_array($a, array('detail', 'qr', 'hexiao'))){
    $a = 'detail';
}

set_time_limit(0);

$lotteryModel = new junhua_model('bmlottery');
$baomingModel = new junhua_model('bmlotteryBaoming');
$LuckyModel = new junhua_model('bmlotteryLucky');
$MemberModel = new junhua_model('commonMember', '');

//&#x5f00;&#x542f;&#x5206;&#x4eab;
$junhua_shareurl = $refererurl;

//&#x5f00;&#x542f;&#x5206;&#x4eab;
if(IS_WEIXIN){
    include_once('source/plugin/junhua_base/jssdk/weixin_jssdk.php');

    $weixin_appid = $junhua_bmlottery_setting['weixin_appid'] ? trim($junhua_bmlottery_setting['weixin_appid']) : trim($junhua_base_config['weixin_appid']);
    $weixin_appsecret = $junhua_bmlottery_setting['weixin_appsecret'] ? trim($junhua_bmlottery_setting['weixin_appsecret']) : trim($junhua_base_config['weixin_appsecret']);
    if($weixin_appid && $weixin_appsecret){
        $jssdk = new WEIXIN_JSSDK($weixin_appid, $weixin_appsecret);
        $signPackage = $jssdk->getSignPackage();
    }
}

//&#x70ae;&#x7070;
if($junhua_bmlottery_setting['weixin_paohui_url']){
    $paohuiUrl = explode("\n", $junhua_bmlottery_setting['weixin_paohui_url']);
    $junhua_shareurl = str_replace($_G['siteurl'], $paohuiUrl[array_rand($paohuiUrl)]."/", $junhua_shareurl);
}

$junhuaApp = new junhua_App($junhua_base_config, $junhua_bmlottery_setting);

//&#x83b7;&#x53d6;&#x9a6c;&#x7532;&#x767b;&#x5f55;
if(IS_MAGA){
    if(!$uid){

        $r = $junhuaApp->getMagaUserInfo();

        if($r['data']['user_id'] > 0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }

            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
        }
    }
}elseif(IS_QF){
    if(!$uid){

        $r = $junhuaApp->getQfUserInfo();

        if($r['data']['id'] > 0){

            $member = getuserbyuid($r['data']['id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }

            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            exit('<script>window.location.reload(true);</script>');
        }
    }
}

if($a == 'detail'){
    $lid = junhua_I('lid/d', 0);
    $lotteryInfo = $lotteryModel->find(array('lottery_id' => $lid, 'is_enable' => 1));
    if(!$lotteryInfo){
        exit;
    }

    $lottery_fields = $lotteryInfo['lottery_fields'];
    $lottery_fields = explode("\n", $lottery_fields);
    $lottery_fields = array_filter($lottery_fields);


    if($lotteryInfo['open_pay'] != 0){
        //&#x5224;&#x65ad;&#x662f;&#x5426;&#x6709;&#x62a5;&#x540d;&#x8bb0;&#x5f55;
        $baomingInfo = $baomingModel->find(array('user_id' => $uid, 'lottery_id' => $lid, 'is_pay' => 1));
    }else{
        //&#x5224;&#x65ad;&#x662f;&#x5426;&#x6709;&#x62a5;&#x540d;&#x8bb0;&#x5f55;
        $baomingInfo = $baomingModel->find(array('user_id' => $uid, 'lottery_id' => $lid));
    }


    //&#x5224;&#x65ad;&#x662f;&#x5426;&#x5df2;&#x7ecf;&#x5f00;&#x5956;&#xff0c;&#x5982;&#x679c;&#x5f00;&#x5956;&#x76f4;&#x63a5;&#x663e;&#x793a;&#x7528;&#x6237;
    $userids = array();
    $lottery_users = array();
    if($lotteryInfo['lottery_status'] == 1 && $lotteryInfo['lottery_users']){
        $userids = $MemberModel->select(array('uid' => array('in', $lotteryInfo['lottery_users'])));
        $lottery_users = explode(',', $lotteryInfo['lottery_users']);
    }

    if($lotteryInfo['open_pay'] != 0){
        //&#x83b7;&#x53d6;&#x603b;&#x62a5;&#x540d;&#x6570;
        $userAllTotalNum =  $baomingModel->count(array('lottery_id' => $lid, 'is_pay' => 1));
    }else{
        //&#x83b7;&#x53d6;&#x603b;&#x62a5;&#x540d;&#x6570;
        $userAllTotalNum =  $baomingModel->count(array('lottery_id' => $lid));
    }


    //&#x83b7;&#x53d6;&#x603b;&#x62a5;&#x540d;&#x6570;
    $luckyAllTotalNum =  $LuckyModel->count(array('lottery_id' => $lid));

    //&#x5224;&#x65ad;&#x81ea;&#x5df1;&#x662f;&#x5426;&#x5df2;&#x7ecf;&#x4e2d;&#x5956;
    $mylucky = $LuckyModel->find(array('user_id' => $uid, 'lottery_id' => $lid), '*',  'lucky_id desc'); 
    
    //&#x7edf;&#x8ba1;&#x6d3b;&#x52a8;&#x6700;&#x65b0;&#x53c2;&#x4e0e;&#x7684; 30 &#x4eba;
    if($lotteryInfo['open_pay'] != 0){
        $newUsers = $baomingModel->select(array('lottery_id' => $lid, 'is_pay' => 1), 'user_id', 'add_time desc', 0, 30);
    }else{
        $newUsers = $baomingModel->select(array('lottery_id' => $lid), 'user_id', 'add_time desc', 0, 30);
    }
    
    //&#x83b7;&#x5f97;&#x6700;&#x8fd1;&#x4e00;&#x6b21;&#x5f00;&#x5956;&#x65f6;&#x95f4;
    $maxRs = $LuckyModel->getField(array('lottery_id' => $lid), 'MAX(lucky_time)', 'lucky_time desc' );
    
    //&#x5217;&#x51fa;&#x6700;&#x8fd1;&#x4e00;&#x6b21;&#x5f00;&#x5956;&#x65f6;&#x95f4;&#x7684;&#x4e2d;&#x5956;&#x7528;&#x6237;

    $fi = explode("\n", $lotteryInfo['lottery_fields']);
    $fk = -1;
    foreach ($fi as $key => $value) {
        if(dstrpos($value, 'mobile') !== false){
            $fk = $key;
            break;
        }
    }

    $luckyUsers = array();
    if($maxRs){
        $luckdatetime = date('Y-m-d H:i', $maxRs);
        $luckyUsers = $LuckyModel->select(array('lottery_id' => $lid, 'lucky_time' => $maxRs), '*', '', 0, 0);
        
        foreach ($luckyUsers as $key => $v) {
            
            if($fk!= -1){
                $sj = dunserialize($v['fields']);
                $luckyUsers[$key]['shoujihao'] = substr_replace($sj[$fk], '****', 3, 4);
            }
            
        }
    }

    //&#x4e2d;&#x5956;&#x4e4b;&#x540e;&#x7684;&#x6838;&#x9500;&#x5730;&#x5740;
    if($mylucky){
        if($lotteryInfo['expiry_day'] != 0){
            $mylucky['hexiao_expired'] = $mylucky['lucky_time'] + $lotteryInfo['expiry_day'] * 86400;
        }else{
            $mylucky['hexiao_expired'] = -1;
        }
        $url = urlencode($_G['siteurl'].junhua_url('m/lottery/hexiao', 'lid='.$lid.'&lkid='.$mylucky['lucky_id'].'&bmid='.$mylucky['baoming_id'], 1));
    }else{
        $url = urlencode($_G['siteurl'].junhua_url('m/lottery/detail', 'lid='.$lid, 1));
    }

    //&#x6700;&#x8fd1;&#x4e00;&#x6b21;&#x4e2d;&#x5956;&#x7528;&#x6237;&#x603b;&#x6570;&#x91cf;
    $luckyNum = count($luckyUsers);

    $maga_paytype = dunserialize($junhua_base_config['maga_paytype']);

    $block_css = '<link rel="stylesheet" href="source/plugin/junhua_bmlottery/static/m/css/style.css">';
}elseif($a == 'hexiao'){
    $lid  = junhua_I('lid/d', 0);
    $lkid = junhua_I('lkid/d', 0);
    $bmid = junhua_I('bmid/d', 0);

    $lotteryInfo = $lotteryModel->find(array('lottery_id' => $lid));
    if(!$lotteryInfo){
        exit;
    }

    if(!$uid){
        dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
        exit();
    }

    //&#x5224;&#x65ad;&#x6743;&#x9650;
    $uids = explode(",", $lotteryInfo['lottery_hexiao']);

    if(!in_array($uid, $uids)){
        dheader('location:' . junhua_url('m/lottery/detail', 'lid='.$lid, 1));
        exit;
    }


    //&#x83b7;&#x53d6;&#x4e2d;&#x5956;&#x4fe1;&#x606f;
    $luckyInfo = $LuckyModel->find(array('lottery_id' => $lid, 'lucky_id' => $lkid, 'baoming_id' => $bmid));
    if($luckyInfo){
        $luckyInfo['fields'] = dunserialize($luckyInfo['fields']);

        if($lotteryInfo['expiry_day'] != 0){
            $luckyInfo['hexiao_expired'] = $luckyInfo['lucky_time'] + $lotteryInfo['expiry_day'] * 86400;
        }else{
            $luckyInfo['hexiao_expired'] = -1;
        }
    }

    $block_css = '<link rel="stylesheet" href="source/plugin/junhua_bmlottery/static/m/css/style.css">';
}elseif($a == 'qr'){

    include_once('source/plugin/junhua_base/libs/qrcode.class.php');

    $url = junhua_I('url', '');
    $url = urldecode($url);
    $url = htmlspecialchars_decode($url);
    if($url){
        QRcode::png($url, false, 'L', 6, 2);
    }
    exit;
}
else{
    exit;
}

$block_content = 'junhua_bmlottery:m/'.$c.'/'.$a;

include template('junhua_bmlottery:m/layout');