<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


if(!in_array($a, array('index'))){
    $a = 'index';
}

$lotteryModel = new junhua_model('bmlottery');
$baomingModel = new junhua_model('bmlotteryBaoming');
$LuckyModel = new junhua_model('bmlotteryLucky');
$MemberModel = new junhua_model('commonMember', '');



if($a == 'index'){
    set_time_limit(0);

    $dz = junhua_I('dz', '');

    if($dz != 'junhua'){
        exit;
    }

    $junhuaApp = new junhua_App($junhua_base_config, $junhua_bmlottery_setting);

    //&#x5224;&#x65ad;&#x81ea;&#x52a8;&#x5f00;&#x5956;
    $prizeList = $lotteryModel->select(array('is_enable' => 1, 'lottery_status' => array('neq', 2),  'lottery_time' => array('elt' , $_G['timestamp'])));

    foreach ($prizeList as $key => $value) {

        //&#x5224;&#x65ad;&#x662f;&#x5426;&#x662f;&#x5faa;&#x73af;&#x7684;&#xff0c;&#x5982;&#x679c;&#x662f;&#x5faa;&#x73af; &#x5219;&#x5f00;&#x4e0b;&#x4e00;&#x8f6e;&#x65f6;&#x95f4;
        if($value['is_loop'] == 1 && $value['lottery_time'] < $_G['timestamp'] && date('Ymd', $value['end_time']) > date('Ymd', $value['lottery_time'])){
            $lotteryModel->save(array('lottery_id' => $value['lottery_id']), array('lottery_time' => strtotime("+1 day", $value['lottery_time'])));
        }

        //&#x83b7;&#x53d6;&#x5fc5;&#x4e2d;&#x7528;&#x6237;
        $uids = (array) $baomingModel->select(array('lottery_id' => $value['lottery_id'], 'is_prize' => 1), 'user_id', '', 0,0,true);


        //&#x5224;&#x65ad;&#x662f;&#x5426;&#x91cd;&#x590d;&#x62bd;&#x5956;
        if($value['is_except'] == 1){
            //&#x83b7;&#x53d6;&#x5168;&#x90e8;&#x7684;&#x4e2d;&#x5956;&#x7528;&#x6237;
            $lucky_uids = (array) $LuckyModel->select(array('lottery_id' => $value['lottery_id']), 'user_id', '', 0,0,true);


            //&#x53bb;&#x6389;&#x5fc5;&#x4e2d;&#x4e2a;&#x6570;
            if($value['open_pay'] != 0){
                $suiji_uids = (array) $baomingModel->select(array('lottery_id' => $value['lottery_id'], 'is_prize' => 0, 'is_pay' => 1), 'user_id', '', 0,0,true);
            }else{
                $suiji_uids = (array) $baomingModel->select(array('lottery_id' => $value['lottery_id'], 'is_prize' => 0), 'user_id', '', 0,0,true);
            }
            //&#x4ea4;&#x96c6;&#x53bb;&#x6389;&#x5df2;&#x7ecf;&#x4e2d;&#x5956;&#x7528;&#x6237;
            $suiji_uids = array_diff($suiji_uids, $lucky_uids);

        }else{
            //&#x53bb;&#x6389;&#x5fc5;&#x4e2d;&#x4e2a;&#x6570;
            if($value['open_pay'] != 0){
                $suiji_uids = (array) $baomingModel->select(array('lottery_id' => $value['lottery_id'], 'is_prize' => 0, 'is_pay' => 1), 'user_id', '', 0,0,true);
            }else{
                $suiji_uids = (array) $baomingModel->select(array('lottery_id' => $value['lottery_id'], 'is_prize' => 0), 'user_id', '', 0,0,true);
            }
        }

        //&#x6253;&#x4e71;&#x6570;&#x7ec4;
        shuffle($suiji_uids);

        $shengyu = $value['lottery_renshu'] - sizeof($uids);

        //&#x83b7;&#x53d6;&#x4e2d;&#x5956;&#x4eba;
        $zhongjian = array_slice($suiji_uids, 0, $shengyu < 0 ? 0 : $shengyu);

        $realZj = array_merge($zhongjian, $uids);

        shuffle($realZj);

        //&#x63d2;&#x5165;&#x4e2d;&#x5956;&#x7528;&#x6237;&#x5230;&#x4e2d;&#x5956;&#x8868;
        $lucky_user = array();

        if(count($realZj)){
            //&#x83b7;&#x5956;&#x7528;&#x6237;&#x4fe1;&#x606f;
            $lucky_user_temp = $baomingModel->select(array('lottery_id' => $value['lottery_id'], 'user_id' => array('in',$realZj)));

            foreach ($lucky_user_temp as $key => $v) {
                $lucky_user[$v['user_id']]['baoming_id']   = $v['baoming_id'];//&#x5f00;&#x5956;&#x7684;&#x65f6;&#x95f4;&#x6233;
                $lucky_user[$v['user_id']]['lottery_id']   = $v['lottery_id'];//&#x5f00;&#x5956;&#x7684;&#x65f6;&#x95f4;&#x6233;
                $lucky_user[$v['user_id']]['user_id']      = $v['user_id'];//&#x5f00;&#x5956;&#x7684;&#x65f6;&#x95f4;&#x6233;
                $lucky_user[$v['user_id']]['username']     = $v['username'];//&#x5f00;&#x5956;&#x7684;&#x65f6;&#x95f4;&#x6233;
                $lucky_user[$v['user_id']]['fields']       = $v['fields'];//&#x5f00;&#x5956;&#x7684;&#x65f6;&#x95f4;&#x6233;
                $lucky_user[$v['user_id']]['baoming_time'] = $v['add_time'];//&#x5f00;&#x5956;&#x7684;&#x65f6;&#x95f4;&#x6233;
                $lucky_user[$v['user_id']]['lucky_time']   = $value['lottery_time'];//&#x5f00;&#x5956;&#x7684;&#x65f6;&#x95f4;&#x6233;
                $lucky_user[$v['user_id']]['lucky_date']   = date("Ymd",$value['lottery_time']);//&#x66f4;&#x65b0;&#x65e5;&#x5386;
            }

            $couNum = $LuckyModel->count(array('lucky_time' => $value['lottery_time'], 'lottery_id' => $value['lottery_id']));
            if(!$couNum){
                $lucky_user = array_values($lucky_user);
                shuffle($lucky_user);
                //&#x4fdd;&#x5b58;&#x6240;&#x6709;&#x4e2d;&#x5956;&#x6570;&#x636e;
                $LuckyModel->addAll($lucky_user);
            }

            $lucky_user = $LuckyModel->select(array('lucky_time' => $value['lottery_time'] ,'lottery_id' => $value['lottery_id'] ));
        }


        $maga_zhushou_open = $value['maga_zhushou_open'];
        $tuisong_text = $value['app_tuisong'];

        if($maga_zhushou_open == 1 && $tuisong_text){

            $tuisong_text = str_replace(array(
                '[choujiangbiaoti]',
                '[zhongjiangrenshu]',
                '[choujiangyaoqiu]',
                '[zhongjiangneirong]',
                '[choujiangmiaoshu]',
                '[choujianglianjie]',
                '[kaijiangshijian]',
            ), array(
                $value['lottery_title'],
                count($lucky_user),
                $value['lottery_yaoqiu'],
                $value['lottery_prize'],
                $value['lottery_desc'],
                $_G['siteurl'].junhua_url('m/lottery/detail', 'lid='.$value['lottery_id'], 1),
                date('Y-m-d H:i', $value['lottery_time']),
            ), $tuisong_text);

            //&#x53d1;&#x9001;APP&#x901a;&#x77e5;
            foreach ($lucky_user as $k => $v) {

                $canshu = dunserialize($v['fields']);

                //&#x83b7;&#x53d6;&#x4e0b;&#x6807;
                $xb = array();
                foreach ($canshu as $kxb => $vxb) {
                    $xb[] = '[canshu_'.($kxb+1).']';
                }

                $app_tuisong = str_replace(array(
                    '[baominghao]',
                    '[zhongjianghao]',
                    '[username]',
                ), array(
                    $v['baoming_id'],
                    $v['lucky_id'],
                    $v['username'],
                ), $tuisong_text);

                $app_tuisong = str_replace($xb, $canshu, $app_tuisong);

                //&#x9a6c;&#x7532;&#x6d88;&#x606f;&#x63d0;&#x793a;
                if($junhua_base_config['app_type'] == 1){
                    //app&#x901a;&#x77e5;&#x7684;&#x5185;&#x5bb9;&#x7ec4;&#x5408;
                    $content = array(
                        'type'   => 'text',
                        'content' => $app_tuisong,
                    );

                    $junhuaApp->sendMagaTemplate($v['user_id'], $content);
                }
            }
        }

        //&#x5224;&#x65ad;&#x662f;&#x5426;&#x5df2;&#x7ecf;&#x53ef;&#x4ee5;&#x7ed3;&#x675f;
        if(($value['is_loop'] == 1 && $value['end_time'] <= $_G['timestamp']) || ($value['is_loop'] == 0 && $_G['timestamp'] >= $value['lottery_time'])){

            $data = array(
                'lottery_status' => 2,
            );
            $lotteryModel->save(array('lottery_id' => $value['lottery_id']), $data);
        }
    }
    
    echo "success";

}
else{
    exit;
}

exit;