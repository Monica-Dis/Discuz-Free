<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array('add', 'edit', 'del', 'index', 'set', 'reset'))){
    $a = 'index';
}

$lotteryModel = new junhua_model('bmlottery');

if($a == 'index'){

    $page = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $theurl = junhua_url('mp/lottery/index', http_build_query($param), true);


    $where = array();
    $totalNum = $lotteryModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $lotteryModel->select($where, '*', 'lottery_id desc', $start, $perpage);

    $block_head_title = '&#x62bd;&#x5956;&#x7ba1;&#x7406;';
    $block_title = '&#x62bd;&#x5956;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {
	if(IS_AJAX){
        
        $lottery_title     = junhua_I('lottery_title', '');
        $lottery_renshu    = junhua_I('lottery_renshu/d', 0);
        $is_weixin_bm      = junhua_I('is_weixin_bm/d', 0);
        $is_loop           = junhua_I('is_loop/d', 0);
        $is_except         = junhua_I('is_except/d', 0);
        $lottery_yaoqiu    = junhua_I('lottery_yaoqiu');
        $lottery_prize     = junhua_I('lottery_prize');
        $lottery_desc      = junhua_I('lottery_desc');
        $lottery_time      = junhua_I('lottery_time');
        $end_time          = junhua_I('end_time');
        $lottery_cover     = junhua_I('lottery_cover');
        $lottery_src       = junhua_I('lottery_src');
        $lottery_fields    = junhua_I('lottery_fields');
        $canjia_num        = junhua_I('canjia_num');
        $share_title       = junhua_I('share_title');
        $share_desc        = junhua_I('share_desc');
        $share_img         = junhua_I('share_img');
        
        $lottery_hexiao    = junhua_I('lottery_hexiao');
        $app_bmhxtuisong   = junhua_I('app_bmhxtuisong');
        $expiry_day        = junhua_I('expiry_day');
        
        $qt_cjtj           = junhua_I('qt_cjtj');
        $qt_zjnr           = junhua_I('qt_zjnr');
        $qt_kjsj           = junhua_I('qt_kjsj');
        $qt_kjjs           = junhua_I('qt_kjjs');
        $app_tuisong       = junhua_I('app_tuisong');
        $app_bmtuisong     = junhua_I('app_bmtuisong');
        $maga_zhushou_open = junhua_I('maga_zhushou_open/d', 0);
        $open_pay          = junhua_I('open_pay/d', 0);
        $point             = junhua_I('point/d', 0);
        $point_type        = junhua_I('point_type/d', 0);
        $money             = junhua_I('money/f', 0);
        $lottery_time      = strtotime($lottery_time);
        $end_time          = strtotime($end_time);


        //&#x8fc7;&#x6ee4;&#x56de;&#x8f66;&#x7a7a;&#x683c;
        $lottery_fields = str_replace("\r", "", $lottery_fields);
        $lottery_fields = explode("\n", $lottery_fields);
        $lottery_fields = array_filter($lottery_fields);
        if($lottery_fields){
            $lottery_fields = array_map("trim", $lottery_fields);
            $lottery_fields = implode("\n", $lottery_fields);
        }else{
            $lottery_fields = '';
        }



		$data = array(
            'lottery_title'     => $lottery_title,
            'lottery_renshu'    => $lottery_renshu,
            'is_weixin_bm'      => $is_weixin_bm,
            'lottery_yaoqiu'    => $lottery_yaoqiu,
            'lottery_prize'     => $lottery_prize,
            'lottery_desc'      => $lottery_desc,
            'lottery_cover'     => $lottery_cover,
            'lottery_src'       => $lottery_src,
            'is_loop'           => $is_loop,
            'is_except'         => $is_except,
            'lottery_fields'    => $lottery_fields,
            'canjia_num'        => $canjia_num,
            'share_title'       => $share_title,
            'share_desc'        => $share_desc,
            'share_img'         => $share_img,
            
            'lottery_hexiao'    => $lottery_hexiao,
            'app_bmhxtuisong'   => $app_bmhxtuisong,
            'expiry_day'        => $expiry_day,
            
            'qt_cjtj'           => $qt_cjtj,
            'qt_zjnr'           => $qt_zjnr,
            'qt_kjsj'           => $qt_kjsj,
            'qt_kjjs'           => $qt_kjjs,
            'app_tuisong'       => $app_tuisong,
            'app_bmtuisong'     => $app_bmtuisong,
            'maga_zhushou_open' => $maga_zhushou_open,
            
            'open_pay'          => $open_pay,
            'money'             => $money,
            'point'             => $point,
            'point_type'        => $point_type,
            
            'lottery_time'      => $lottery_time,
            'end_time'          => $end_time,
            'add_time'          => $_G['timestamp'],
            'update_time'       => $_G['timestamp'],
            'is_enable'         => 1,
		);

		$lotteryModel->add($data);

	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/lottery/index', '', true)));
	}

    $block_head_title = '&#x62bd;&#x5956;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x62bd;&#x5956;';
    $block_css = '';
    $a = 'update';
}elseif ($a == 'edit') {

	$lottery_id = junhua_I('lid/d', 0);

	$where = array('lottery_id' => $lottery_id);
	$lotteryInfo = $lotteryModel->find($where);

	if(!$lotteryInfo){
        dheader('location:' . junhua_url('mp/lottery/index', '', 1));
        exit;
	}

	if(IS_AJAX){

        $lottery_title     = junhua_I('lottery_title', '');
        $lottery_renshu    = junhua_I('lottery_renshu/d', 0);
        $is_weixin_bm      = junhua_I('is_weixin_bm/d', 0);
        $is_loop           = junhua_I('is_loop/d', 0);
        $is_except         = junhua_I('is_except/d', 0);
        $lottery_yaoqiu    = junhua_I('lottery_yaoqiu');
        $lottery_prize     = junhua_I('lottery_prize');
        $lottery_desc      = junhua_I('lottery_desc');
        $lottery_time      = junhua_I('lottery_time');
        $end_time          = junhua_I('end_time');
        $lottery_cover     = junhua_I('lottery_cover');
        $lottery_src       = junhua_I('lottery_src');
        $lottery_fields    = junhua_I('lottery_fields');
        $canjia_num        = junhua_I('canjia_num');
        $share_title       = junhua_I('share_title');
        $share_desc        = junhua_I('share_desc');
        $share_img         = junhua_I('share_img');
        
        $lottery_hexiao    = junhua_I('lottery_hexiao');
        $app_bmhxtuisong   = junhua_I('app_bmhxtuisong');
        $expiry_day        = junhua_I('expiry_day');
        
        
        $qt_cjtj           = junhua_I('qt_cjtj');
        $qt_zjnr           = junhua_I('qt_zjnr');
        $qt_kjsj           = junhua_I('qt_kjsj');
        $qt_kjjs           = junhua_I('qt_kjjs');
        $app_tuisong       = junhua_I('app_tuisong');
        $app_bmtuisong     = junhua_I('app_bmtuisong');
        $maga_zhushou_open = junhua_I('maga_zhushou_open/d', 0);
        $open_pay          = junhua_I('open_pay/d', 0);
        $point             = junhua_I('point/d', 0);
        $point_type        = junhua_I('point_type/d', 0);
        $money             = junhua_I('money/f', 0);
        
        $lottery_time      = strtotime($lottery_time);
        $end_time          = strtotime($end_time);


        //&#x8fc7;&#x6ee4;&#x56de;&#x8f66;&#x7a7a;&#x683c;
        $lottery_fields = str_replace("\r", "", $lottery_fields);
        $lottery_fields = explode("\n", $lottery_fields);
        $lottery_fields = array_filter($lottery_fields);
        if($lottery_fields){
            $lottery_fields = array_map("trim", $lottery_fields);
            $lottery_fields = implode("\n", $lottery_fields);
        }else{
            $lottery_fields = '';
        }
        

		$data = array(
            'lottery_title'     => $lottery_title,
            'lottery_renshu'    => $lottery_renshu,
            'is_weixin_bm'      => $is_weixin_bm,
            'lottery_yaoqiu'    => $lottery_yaoqiu,
            'lottery_prize'     => $lottery_prize,
            'lottery_desc'      => $lottery_desc,
            'lottery_cover'     => $lottery_cover,
            'lottery_src'       => $lottery_src,
            'is_loop'           => $is_loop,
            'is_except'         => $is_except,
            'lottery_fields'    => $lottery_fields,
            'canjia_num'        => $canjia_num,
            'qt_cjtj'           => $qt_cjtj,
            'qt_zjnr'           => $qt_zjnr,
            'qt_kjsj'           => $qt_kjsj,
            'qt_kjjs'           => $qt_kjjs,
            'app_tuisong'       => $app_tuisong,
            'app_bmtuisong'     => $app_bmtuisong,
            'maga_zhushou_open' => $maga_zhushou_open,
            'share_title'       => $share_title,
            'share_desc'        => $share_desc,
            'share_img'         => $share_img,
            
            'open_pay'          => $open_pay,
            'money'             => $money,
            'point'             => $point,
            'point_type'        => $point_type,
            
            'lottery_hexiao'    => $lottery_hexiao,
            'app_bmhxtuisong'   => $app_bmhxtuisong,
            'expiry_day'        => $expiry_day,
            
            'lottery_time'      => $lottery_time,
            'end_time'          => $end_time,
            'update_time'       => $_G['timestamp'],
		);

		$lotteryModel->save($where, $data);
	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/lottery/index', '', 1)));
	}

    $lotteryInfo['lottery_time'] = $lotteryInfo['lottery_time'] ? date('Y-m-d H:i:s', $lotteryInfo['lottery_time']) : '';
    $lotteryInfo['end_time'] = $lotteryInfo['end_time'] ? date('Y-m-d H:i:s', $lotteryInfo['end_time']) : '';

    $block_head_title = '&#x62bd;&#x5956;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x62bd;&#x5956;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'del'){
    if(IS_AJAX){
        $lid = junhua_I('lid/d', 0);

        $where = array(
            'lottery_id'      => $lid
        );

        $lotteryInfo = $lotteryModel->find($where);
        if(!$lotteryInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $lotteryModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'set'){
    if(IS_AJAX){
        $lid = junhua_I('lid/d', 0);

        $where = array(
            'lottery_id'      => $lid
        );

        $lotteryInfo = $lotteryModel->find($where);
        if(!$lotteryInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($lotteryInfo['is_enable'] == 1){
            $is_enable = 0;
        }else{
            $is_enable = 1;
        }

        $lotteryModel->save($where, array('is_enable' => $is_enable));

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'reset'){
    if(IS_AJAX){
        $lid = junhua_I('lid/d', 0);

        $where = array(
            'lottery_id'      => $lid
        );

        $lotteryInfo = $lotteryModel->find($where);
        if(!$lotteryInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($lotteryInfo['lottery_status'] != 2){
            $lotteryModel->save($where, array('lottery_status' => 2));
        }else{
            $lotteryModel->save($where, array('lottery_status' => 0));
        }


        junhua_ajaxReturn(array('status' => 1));
    }
}
else{
	exit;
}

$block_content = 'junhua_bmlottery:mp/'.$c.'/'.$a;

include template('junhua_bmlottery:mp/layout');