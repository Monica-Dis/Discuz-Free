<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array('del', 'index', 'set', 'export'))){
    $a = 'index';
}

$baomingModel = new junhua_model('bmlotteryBaoming');
$lotteryModel = new junhua_model('bmlottery');

if($a == 'index'){

    $lid     = junhua_I('lid/d', '');
    $user_id = junhua_I('user_id/d', '');
    $page    = junhua_I('page/d', 1);
    $is_pay  = junhua_I('is_pay/d', 0);
    $paytype  = junhua_I('paytype/d', 0);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $where = array();

    if($lid){
        $where['lottery_id'] = $lid;
        $param['lid'] = $lid;
    }

    $lotteryInfo = $lotteryModel->find($where);

    if($user_id){
        $where['user_id'] = $user_id;
        $param['user_id'] = $user_id;
    }

    if($is_pay){
        if($is_pay == 1){
            $where['is_pay'] = 1;
        }elseif($is_pay == 2){
            $where['is_pay'] = 0;
        }
        $param['is_pay'] = $is_pay;
    }

    if($paytype){
        $where['paytype'] = $paytype;
        $param['paytype'] = $paytype;
    }

    $param['perpage'] = $perpage;

    $totalNum = $baomingModel->count($where);


    $theurl = junhua_url('mp/baoming/index', http_build_query($param), true);
    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $baomingModel->select($where, '*', 'baoming_id desc', $start, $perpage);

    $exportUrl = junhua_url('mp/baoming/export', http_build_query($param), 1);


    $block_head_title = '&#x62a5;&#x540d;&#x7ba1;&#x7406;';
    $block_title = '&#x62a5;&#x540d;&#x5217;&#x8868;';
    $block_css = '';
}elseif($a == 'set'){
    if(IS_AJAX){
        $bid = junhua_I('bid/d', 0);

        $where = array(
            'baoming_id'      => $bid
        );

        $baomingInfo = $baomingModel->find($where);
        if(!$baomingInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($baomingInfo['is_prize'] == 1){
            $is_prize = 0;
        }else{
            $is_prize = 1;
        }

        $baomingModel->save($where, array('is_prize' => $is_prize));

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'del'){
    if(IS_AJAX){
        $bid = junhua_I('bid/d', 0);

        $where = array(
            'baoming_id'      => $bid
        );

        $baomingInfo = $baomingModel->find($where);
        if(!$baomingInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $baomingModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'export'){

    $lid     = junhua_I('lid/d', '');
    $user_id = junhua_I('user_id/d', '');

    $where = array();

    if($lid){
        $where['lottery_id'] = $lid;
    }

    if($user_id){
        $where['user_id'] = $user_id;
    }

    $filename = date("YmdHis") . '.csv';
    header('Content-Description: File Transfer');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Type: text/comma-separated-values');   
    header('Content-Transfer-Encoding: binary');


    $lists = $baomingModel->select($where, '*', 'baoming_id asc');


    foreach ($lists as $key => $value) {
        if($key == 0){
            $formParams = $value['fields'];
            $formParams = (array) dunserialize($formParams);

            $header = array();
            $header[] = 'baoming_id';
            $header[] = 'lottery_id';
            $header[] = 'user_id';
            $header[] = 'username';

            foreach ($formParams as $k1 => $v1) {
                $header[] = 'canshu_'.($k1+1);
            }

            $header[] = 'add_time';
            echo diconv(implode(',', $header), CHARSET, "GB18030");
        }

        $vl = array();
        $vl['baoming_id']   = $value['baoming_id'];
        $vl['lottery_id']   = $value['lottery_id'];
        $vl['user_id']      = $value['user_id'];
        $vl['username']     = $value['username'];


        $formParams = $value['fields'];
        $formParams = (array) dunserialize($formParams);

        $vl = array_merge($vl, $formParams);

        $vl['add_time'] = date('Y-m-d H:i:s', $value['add_time']);

        echo "\n".diconv(implode(",\t", $vl), CHARSET, "GB18030");
    }
    exit;
}
else{
	exit;
}

$block_content = 'junhua_bmlottery:mp/'.$c.'/'.$a;
include template('junhua_bmlottery:mp/layout');