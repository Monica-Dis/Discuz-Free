<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array('index', 'uploadfile', 'uploadfile_editor'))){
    $a = 'index';
}

loadcache('junhua_bmlottery_system');
$junhua_bmlottery_system = dunserialize($_G['cache']['junhua_bmlottery_system']);

if($a == 'index'){

    if(IS_AJAX){
        
        $bmlottery_appsharehide_open = junhua_I('bmlottery_appsharehide_open/d', 0);
        $bmlottery_weixin_share_open = junhua_I('bmlottery_weixin_share_open/d', 0);
        $bmlottery_share_title       = junhua_I('bmlottery_share_title', '');
        $bmlottery_share_desc        = junhua_I('bmlottery_share_desc', '');
        $bmlottery_share_img         = junhua_I('bmlottery_share_img', '');
        $bmlottery_gongxi_img        = junhua_I('bmlottery_gongxi_img', '');
        $qf_fwhuid                   = junhua_I('qf_fwhuid', '');
        $manage_group                = junhua_I('manage_group/a', array());
        $weixin_appid                = junhua_I('weixin_appid', '');
        $weixin_appsecret            = junhua_I('weixin_appsecret', '');
        $weixin_paohui_url           = junhua_I('weixin_paohui_url', '');

        //&#x8fc7;&#x6ee4;&#x56de;&#x8f66;&#x7a7a;&#x683c;
        $weixin_paohui_url = str_replace("\r", "", $weixin_paohui_url);
        $weixin_paohui_url = explode("\n", $weixin_paohui_url);
        $weixin_paohui_url = array_filter($weixin_paohui_url);
        if($weixin_paohui_url){
            $weixin_paohui_url = array_map("trim", $weixin_paohui_url);
            $weixin_paohui_url = implode("\n", $weixin_paohui_url);
        }else{
            $weixin_paohui_url = '';
        }


        $data = array(
            'bmlottery_appsharehide_open' => $bmlottery_appsharehide_open,
            'bmlottery_weixin_share_open' => $bmlottery_weixin_share_open,
            'bmlottery_share_title'       => $bmlottery_share_title,
            'bmlottery_share_desc'        => $bmlottery_share_desc,
            'bmlottery_share_img'         => $bmlottery_share_img,
            'bmlottery_gongxi_img'        => $bmlottery_gongxi_img,
            'manage_group'                => serialize($manage_group),
            'qf_fwhuid'                   => $qf_fwhuid,
            'weixin_appid'                => $weixin_appid,
            'weixin_appsecret'            => $weixin_appsecret,
            'weixin_paohui_url'           => $weixin_paohui_url,
        );

        savecache('junhua_bmlottery_setting', serialize($data));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x914d;&#x7f6e;&#x6210;&#x529f;'));
    }

    include_once('source/language/lang_admincp.php');

    $junhua_bmlottery_setting['manage_group'] = dunserialize($junhua_bmlottery_setting['manage_group']);

    $groupSelect = '<select class="form-control" name="manage_group[]" size="10" multiple="multiple"><option value=""'.(@in_array('', $junhua_bmlottery_setting['manage_group']) ? ' selected' : '').'>&#x7a7a;</option>';

    $query = C::t('common_usergroup')->range_orderby_credit();
    $groupselect = array();
    foreach($query as $group) {
        $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
        $groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $junhua_bmlottery_setting['manage_group']) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
    }
    $groupSelect .= '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
        ($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
        ($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
        '<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';

    $block_head_title = '&#x7cfb;&#x7edf;&#x914d;&#x7f6e;';
    $block_title = '&#x7cfb;&#x7edf;&#x914d;&#x7f6e;';
    $block_css = '';
}elseif($a == 'uploadfile'){
    include_once('source/plugin/junhua_base/libs/filemanger.class.php');

    if (!IS_POST && isset($_FILES) ? $_FILES : array()) {
        exit;
    }

    $filemanger = new junhua_filemanger('source/plugin/junhua_bmlottery', 'source/plugin/junhua_bmlottery');
    $img_path = $filemanger->uploadJson('Filedata', false);

    junhua_ajaxReturn(array('status' => 1, 'file_path' => $img_path));
}elseif($a == 'uploadfile_editor'){
    include_once('source/plugin/junhua_base/libs/filemanger.class.php');

    if (!IS_POST && isset($_FILES) ? $_FILES : array()) {
        exit;
    }

    $filemanger = new junhua_filemanger('source/plugin/junhua_bmlottery', 'source/plugin/junhua_bmlottery');
    $img_path = $filemanger->uploadJson('imgFile');
    exit;
}
else{
	exit;
}

$block_content = 'junhua_bmlottery:mp/'.$c.'/'.$a;
include template('junhua_bmlottery:mp/layout');