<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array('index', 'del', 'export', 'hexiao'))){
    $a = 'index';
}

$LuckyModel = new junhua_model('bmlotteryLucky');
$lotteryModel = new junhua_model('bmlottery');

if($a == 'index'){

    $lid     = junhua_I('lid/d', '');
    $user_id = junhua_I('user_id/d', '');
    $lucky_id = junhua_I('lucky_id/d', '');
    $page    = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);
    $is_hexiao = junhua_I('is_hexiao/d', 0);

    $start_time  = junhua_I('start_time', '');
    $end_time    = junhua_I('end_time', '');

    $starttime = $start_time ? strtotime($start_time) : '';
    $endtime   = $end_time ? strtotime($end_time) : '';


    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $where = array();


    if($lid){
        $where['lottery_id'] = $lid;
        $param['lid'] = $lid;
    }

    if($user_id){
        $where['user_id'] = $user_id;
        $param['user_id'] = $user_id;
    }

    if($is_hexiao - 1 != -1){
        $where['is_hexiao'] = $is_hexiao - 1;
        $param['is_hexiao'] = $is_hexiao;
    }

    if($lucky_id){
        $where['lucky_id'] = $lucky_id;
        $param['lucky_id'] = $lucky_id;
    }

    if($start_time){
        $param['start_time'] = $start_time;
    }
    if($end_time){
        $param['end_time'] = $end_time;
    }

    $param['perpage'] = $perpage;

    if($starttime && $endtime){
        $where['lucky_time']   = array(array('egt',$starttime),array('elt',$endtime),'and'); 
    }elseif($starttime && !$endtime){
        $where['lucky_time']   = array('egt',$starttime); 
    }elseif(!$starttime && $endtime){
        $where['lucky_time']   = array('elt',$endtime); 
    }

    $theurl = junhua_url('mp/lucky/index', http_build_query($param), true);

    $totalNum = $LuckyModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $LuckyModel->select($where, '*', 'lucky_id desc', $start, $perpage);

    $exportUrl = junhua_url('mp/lucky/export', http_build_query($param), 1);


    $block_head_title = '&#x4e2d;&#x5956;&#x7ba1;&#x7406;';
    $block_title = '&#x4e2d;&#x5956;&#x5217;&#x8868;';
    $block_css = '';
}elseif($a == 'del'){
    if(IS_AJAX){
        $lkid = junhua_I('lkid/d', 0);

        $where = array(
            'lucky_id'      => $lkid
        );

        $luckyInfo = $LuckyModel->find($where);
        if(!$luckyInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $LuckyModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'export'){

    $lid     = junhua_I('lid/d', '');
    $user_id = junhua_I('user_id/d', '');
    $lucky_id = junhua_I('lucky_id/d', '');

    $start_time  = junhua_I('start_time', '');
    $end_time    = junhua_I('end_time', '');

    $starttime = $start_time ? strtotime($start_time) : '';
    $endtime   = $end_time ? strtotime($end_time) : '';

    $where = array();

    if($lid){
        $where['lottery_id'] = $lid;
    }

    if($user_id){
        $where['user_id'] = $user_id;
    }

    if($lucky_id){
        $where['lucky_id'] = $lucky_id;
    }


    if($starttime && $endtime){
        $where['lucky_time']   = array(array('egt',$starttime),array('elt',$endtime),'and'); 
    }elseif($starttime && !$endtime){
        $where['lucky_time']   = array('egt',$starttime); 
    }elseif(!$starttime && $endtime){
        $where['lucky_time']   = array('elt',$endtime); 
    }


    $filename = date("YmdHis") . '.csv';
    header('Content-Description: File Transfer');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Type: text/comma-separated-values');   
    header('Content-Transfer-Encoding: binary');


    $lists = $LuckyModel->select($where, '*', 'lucky_id asc');


    foreach ($lists as $key => $value) {
        if($key == 0){
            $formParams = $value['fields'];
            $formParams = (array) dunserialize($formParams);

            $header = array();
            $header[] = 'lucky_id';
            $header[] = 'baoming_id';
            $header[] = 'lottery_id';
            $header[] = 'user_id';
            $header[] = 'username';


            foreach ($formParams as $k1 => $v1) {
                $header[] = 'canshu_'.($k1+1);
            }

            $header[] = 'baoming_time';
            $header[] = 'lucky_time';
            $header[] = 'hexiao';
            $header[] = 'hexiao_time';
            $header[] = 'hexiao_uid';

            echo diconv(implode(',', $header), CHARSET, "GB18030");
        }

        $vl = array();
        $vl['lucky_id']    = $value['lucky_id'];
        $vl['baoming_id']  = $value['baoming_id'];
        $vl['lottery_id']  = $value['lottery_id'];
        $vl['user_id']     = $value['user_id'];
        $vl['username']    = $value['username'];

        $formParams = $value['fields'];
        $formParams = (array) dunserialize($formParams);

        $vl = array_merge($vl, $formParams);


        $vl['baoming_time'] = date('Y-m-d H:i:s', $value['baoming_time']);
        $vl['lucky_time']   = date('Y-m-d H:i:s', $value['lucky_time']);
        $vl['hexiao']      = $value['is_hexiao'];
        $vl['hexiao_time'] = $value['hexiao_time'] ? date('Y-m-d H:i:s', $value['hexiao_time']) : '';
        $vl['hexiao_uid']  = $value['hexiao_uid'];

        echo "\n".diconv(implode(",\t", $vl), CHARSET, "GB18030");
    }
    exit;
}elseif($a == 'hexiao'){

    if(IS_AJAX){
        $lucky_id = junhua_I('lkid/d', 0);

        $where = array();
        $where['lucky_id'] = $lucky_id;

        //&#x67e5;&#x8be2;&#x4e2d;&#x5956;&#x4fe1;&#x606f;
        $luckyInfo = $LuckyModel->find($where);
        if(!$luckyInfo){
            $data = array('status' => 0, 'msg' => '&#x65e0;&#x6b64;&#x4fe1;&#x606f;');
            junhua_ajaxReturn($data);
        }

        //&#x67e5;&#x8be2;&#x6d3b;&#x52a8;&#x4fe1;&#x606f;
        $lotteryInfo = $lotteryModel->find(array('lottery_id' => $luckyInfo['lottery_id']));
        if(!$lotteryInfo){
            $data = array('status' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
            junhua_ajaxReturn($data);
        }

        //&#x5224;&#x65ad;&#x6743;&#x9650;
        $uids = explode(",", $lotteryInfo['lottery_hexiao']);
        if( !in_array($uid, $uids)){
            $data = array('status' => 0, 'msg' => '&#x60a8;&#x65e0;&#x6743;&#x6838;&#x9500;');
            junhua_ajaxReturn($data);
        }

        if($luckyInfo['is_hexiao']){
            $data = array('status' => 0, 'msg' => '&#x5df2;&#x6838;&#x9500;');
            junhua_ajaxReturn($data);
        }

        //&#x5224;&#x65ad;&#x662f;&#x5426;&#x6838;&#x9500;&#x8fc7;&#x671f;
        if($lotteryInfo['expiry_day'] != 0){
            $luckyInfo['hexiao_expired'] = $luckyInfo['lucky_time'] + $lotteryInfo['expiry_day'] * 86400;
        }else{
            $luckyInfo['hexiao_expired'] = -1;
        }

        if($luckyInfo['hexiao_expired'] != -1 && $luckyInfo['hexiao_expired'] < $_G['timestamp']){
            $data = array('status' => 0, 'msg' => '&#x5df2;&#x8fc7;&#x671f;');
            junhua_ajaxReturn($data);
        }

        //&#x6838;&#x9500;&#x901a;&#x8fc7;
        $LuckyModel->save($where, array('hexiao_time' => $_G['timestamp'], 'is_hexiao' => 1, 'hexiao_uid' => $uid));

        $junhuaApp = new junhua_App($junhua_base_config, $junhua_bmlottery_setting);

        $tuisong_text = $lotteryInfo['app_bmhxtuisong'];

        if($tuisong_text){

            $tuisong_text = str_replace(array(
                '[choujiangbiaoti]',
                '[zhongjiangrenshu]',
                '[choujiangyaoqiu]',
                '[zhongjiangneirong]',
                '[choujiangmiaoshu]',
                '[choujianglianjie]',
                '[kaijiangshijian]',
            ), array(
                $lotteryInfo['lottery_title'],
                $lotteryInfo['lottery_renshu'],
                $lotteryInfo['lottery_yaoqiu'],
                $lotteryInfo['lottery_prize'],
                $lotteryInfo['lottery_desc'],
                $_G['siteurl'].junhua_url('m/lottery/detail', 'lid='.$lotteryInfo['lottery_id'], 1),
                date('Y-m-d H:i', $lotteryInfo['lottery_time']),
            ), $tuisong_text);

            //&#x53d1;&#x9001;APP&#x901a;&#x77e5;
            $canshu = dunserialize($luckyInfo['fields']);

            //&#x83b7;&#x53d6;&#x4e0b;&#x6807;
            $xb = array();
            foreach ($canshu as $kxb => $vxb) {
                $xb[] = '[canshu_'.($kxb+1).']';
            }

            $app_tuisong = str_replace(array(
                '[baominghao]',
                '[zhongjianghao]',
                '[username]',
            ), array(
                $luckyInfo['baoming_id'],
                $luckyInfo['lucky_id'],
                $luckyInfo['username'],
            ), $tuisong_text);

            $app_tuisong = str_replace($xb, $canshu, $app_tuisong);


            //&#x9a6c;&#x7532;&#x6d88;&#x606f;&#x63d0;&#x793a;
            if($junhua_base_config['app_type'] == 1){
                //app&#x901a;&#x77e5;&#x7684;&#x5185;&#x5bb9;&#x7ec4;&#x5408;
                $content = array(
                    'type'   => 'text',
                    'content' => $app_tuisong,
                );

                $junhuaApp->sendMagaTemplate($luckyInfo['user_id'], $content);
            }elseif($junhua_base_config['app_type'] == 2){
                //app&#x901a;&#x77e5;&#x7684;&#x5185;&#x5bb9;&#x7ec4;&#x5408;

                $showData = array(
                    'title'   => junhua_utf82gbk(unicodeDecode('&#x62a5;&#x540d;&#x6210;&#x529f;')),
                    'date'    => date('Y-m-d H:i'),
                    'setting' => array(),
                    'content' => $app_tuisong,
                    'url'     => $_G['siteurl'].junhua_url('m/lottery/detail', 'lid='.$lotteryInfo['lottery_id'], 1),
                );

                $content = array(
                    'from'     => $junhua_bmlottery_setting['qf_fwhuid'],
                    'target'   => $luckyInfo['user_id'],
                    'msg'      => junhua_utf82gbk(unicodeDecode('&#x62a5;&#x540d;&#x6210;&#x529f;')),
                    'showData' => junhua_json_encode($showData),
                );

                $junhuaApp->sendQfTemplate($content);
            }
        }

        $data = array('status' => 1, 'msg' => '&#x6838;&#x9500;&#x6210;&#x529f;');
        junhua_ajaxReturn($data);

    }else{
        exit;
    }





}
else{
	exit;
}

$block_content = 'junhua_bmlottery:mp/'.$c.'/'.$a;

include template('junhua_bmlottery:mp/layout');