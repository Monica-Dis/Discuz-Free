<?php 

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

C::t('common_syscache')->delete('junhua_bmlottery_system');
C::t('common_syscache')->delete('junhua_bmlottery_setting');

$sql = <<<EOF
	DROP TABLE IF EXISTS `pre_junhua_bmlottery`;
	DROP TABLE IF EXISTS `pre_junhua_bmlottery_baoming`;
	DROP TABLE IF EXISTS `pre_junhua_bmlottery_lucky`;
EOF;


runquery($sql);
$finish = true;
?>