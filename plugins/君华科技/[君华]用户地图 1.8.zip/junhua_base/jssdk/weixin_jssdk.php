<?php
class WEIXIN_JSSDK {
  private $appId;
  private $appSecret;
  private $appPath = 'source/plugin/junhua_base/jssdk/';

  public function __construct($appId, $appSecret) {
    $this->appId = $appId;
    $this->appSecret = $appSecret;
  }

  public function getSignPackage() {
    $jsapiTicket = $this->getJsApiTicket();

    // &#x6ce8;&#x610f; URL &#x4e00;&#x5b9a;&#x8981;&#x52a8;&#x6001;&#x83b7;&#x53d6;&#xff0c;&#x4e0d;&#x80fd; hardcode.
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

    $timestamp = time();
    $nonceStr = $this->createNonceStr();

    // &#x8fd9;&#x91cc;&#x53c2;&#x6570;&#x7684;&#x987a;&#x5e8f;&#x8981;&#x6309;&#x7167; key &#x503c; ASCII &#x7801;&#x5347;&#x5e8f;&#x6392;&#x5e8f;
    $string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";

    $signature = sha1($string);

    $signPackage = array(
      "appId"     => $this->appId,
      "nonceStr"  => $nonceStr,
      "timestamp" => $timestamp,
      "url"       => $url,
      "signature" => $signature,
      "rawString" => $string
    );
    return $signPackage; 
  }

  private function createNonceStr($length = 16) {
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    $str = "";
    for ($i = 0; $i < $length; $i++) {
      $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
  }

  private function getJsApiTicket() {
    // jsapi_ticket &#x5e94;&#x8be5;&#x5168;&#x5c40;&#x5b58;&#x50a8;&#x4e0e;&#x66f4;&#x65b0;&#xff0c;&#x4ee5;&#x4e0b;&#x4ee3;&#x7801;&#x4ee5;&#x5199;&#x5165;&#x5230;&#x6587;&#x4ef6;&#x4e2d;&#x505a;&#x793a;&#x4f8b;
    $data = json_decode($this->get_php_file("jsapi_ticket.php"));
    if ($data->expire_time < time()) {
      $accessToken = $this->getAccessToken();
      // &#x5982;&#x679c;&#x662f;&#x4f01;&#x4e1a;&#x53f7;&#x7528;&#x4ee5;&#x4e0b; URL &#x83b7;&#x53d6; ticket
      // $url = "https://qyapi.weixin.qq.com/cgi-bin/get_jsapi_ticket?access_token=$accessToken";
      $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=$accessToken";
      $res = json_decode($this->httpGet($url));
      $ticket = $res->ticket;
      if ($ticket) {
        $data->expire_time = time() + 7000;
        $data->jsapi_ticket = $ticket;
        $this->set_php_file("jsapi_ticket.php", json_encode($data));
      }
    } else {
      $ticket = $data->jsapi_ticket;
    }

    return $ticket;
  }

  private function getAccessToken() {
    // access_token &#x5e94;&#x8be5;&#x5168;&#x5c40;&#x5b58;&#x50a8;&#x4e0e;&#x66f4;&#x65b0;&#xff0c;&#x4ee5;&#x4e0b;&#x4ee3;&#x7801;&#x4ee5;&#x5199;&#x5165;&#x5230;&#x6587;&#x4ef6;&#x4e2d;&#x505a;&#x793a;&#x4f8b;
    $data = json_decode($this->get_php_file("access_token.php"));
    if ($data->expire_time < time()) {
      // &#x5982;&#x679c;&#x662f;&#x4f01;&#x4e1a;&#x53f7;&#x7528;&#x4ee5;&#x4e0b;URL&#x83b7;&#x53d6;access_token
      // $url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=$this->appId&corpsecret=$this->appSecret";
      $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$this->appId&secret=$this->appSecret";
      $res = json_decode($this->httpGet($url));
      $access_token = $res->access_token;
      if ($access_token) {
        $data->expire_time = time() + 7000;
        $data->access_token = $access_token;
        $this->set_php_file("access_token.php", json_encode($data));
      }
    } else {
      $access_token = $data->access_token;
    }
    return $access_token;
  }

  private function httpGet($url) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 500);
    // &#x4e3a;&#x4fdd;&#x8bc1;&#x7b2c;&#x4e09;&#x65b9;&#x670d;&#x52a1;&#x5668;&#x4e0e;&#x5fae;&#x4fe1;&#x670d;&#x52a1;&#x5668;&#x4e4b;&#x95f4;&#x6570;&#x636e;&#x4f20;&#x8f93;&#x7684;&#x5b89;&#x5168;&#x6027;&#xff0c;&#x6240;&#x6709;&#x5fae;&#x4fe1;&#x63a5;&#x53e3;&#x91c7;&#x7528;https&#x65b9;&#x5f0f;&#x8c03;&#x7528;&#xff0c;&#x5fc5;&#x987b;&#x4f7f;&#x7528;&#x4e0b;&#x9762;2&#x884c;&#x4ee3;&#x7801;&#x6253;&#x5f00;ssl&#x5b89;&#x5168;&#x6821;&#x9a8c;&#x3002;
    // &#x5982;&#x679c;&#x5728;&#x90e8;&#x7f72;&#x8fc7;&#x7a0b;&#x4e2d;&#x4ee3;&#x7801;&#x5728;&#x6b64;&#x5904;&#x9a8c;&#x8bc1;&#x5931;&#x8d25;&#xff0c;&#x8bf7;&#x5230; http://curl.haxx.se/ca/cacert.pem &#x4e0b;&#x8f7d;&#x65b0;&#x7684;&#x8bc1;&#x4e66;&#x5224;&#x522b;&#x6587;&#x4ef6;&#x3002;
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_URL, $url);

    $res = curl_exec($curl);
    curl_close($curl);

    return $res;
  }

  private function get_php_file($filename) {
    return trim(substr(file_get_contents($this->appPath.$filename), 15));
  }
  private function set_php_file($filename, $content) {
    $fp = fopen($this->appPath.$filename, "w");
    fwrite($fp, "<?php exit();?>" . $content);
    fclose($fp);
  }
}

