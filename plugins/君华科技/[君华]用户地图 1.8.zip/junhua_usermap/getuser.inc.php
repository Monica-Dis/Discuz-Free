<?php 
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['formhash'] != FORMHASH){
    exit('Access Denied');
}

$base_seting     = $_G['cache']['plugin']['junhua_base'];

//&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x914d;&#x7f6e;&#x9879;
$maga_dataname = $base_seting['maga_dataname'];
$maga_url      = $base_seting['maga_url'];
$maga_qiniu    = $base_seting['maga_qiniu'];
$maga_localhost = $base_seting['maga_localhost'];
$maga_root      = $base_seting['maga_root'];
$maga_password  = $base_seting['maga_password'];


if($maga_localhost && $maga_root && $maga_password){
    $Driver = function_exists('mysql_connect') ? 'db_driver_mysql' : 'db_driver_mysqli';
    $MagDb = new $Driver;

    $DbConfig[1]['dbhost'] = $maga_localhost;
    $DbConfig[1]['dbuser'] = $maga_root;
    $DbConfig[1]['dbpw'] = $maga_password;
    $DbConfig[1]['dbname'] = $maga_dataname;
    $DbConfig[1]['tablepre'] = $TablePre = 'mag_';
    $DbConfig[1]['pconnect'] = '0';
    $DbConfig[1]['dbcharset'] = $_G['charset'];

    $MagDb->set_config($DbConfig);
    $MagDb->connect();
}


$userid = intval($_GET['userid']);

$result = array();
if($MagDb && $maga_dataname){
    $query = $MagDb->query('SELECT u.name,u.head,ue.last_login_time FROM mag_user_extra as ue left join mag_user as u on ue.user_id = u.user_id WHERE u.user_id='.$userid);

    $result = DB::fetch($query);

    if ($result) {
        
        $user['avatar'] = avatar($userid, 'middle', true);

        if (strtolower(CHARSET) == 'gbk') {
            $user['name'] = diconv($result['name'], 'gbk', 'utf-8');
        }else{
            $user['name'] = $result['name'];
        }
        $user['last_login_time'] = date('Y-m-d H:i', $result['last_login_time']);
    }else{
        //&#x5224;&#x65ad;&#x81ea;&#x5df1;&#x7684;&#x662f;&#x5426;&#x6709;&#x6570;&#x636e;

        $userInfo = DB::fetch_first("select * from ".DB::table('junhua_usermap_user')." where user_id = " . $userid);
        if($userInfo){
            $user['avatar'] = avatar($userid, 'middle', true);

            if (strtolower(CHARSET) == 'gbk') {
                $user['name'] = diconv($userInfo['username'], 'gbk', 'utf-8');
            }else{
                $user['name'] = $userInfo['username'];
            }
            $user['last_login_time'] = date('Y-m-d H:i', $userInfo['last_time']);
        }

    }

}elseif(!$MagDb && $maga_dataname){
    $result = Db::fetch_all('SELECT ue.last_login_time,ue.lng,ue.lat,ue.user_id,u.sex FROM '.$maga_dataname.'.mag_user_extra as ue left join '.$maga_dataname.'.mag_user as u on ue.user_id = u.user_id WHERE ue.lng>0');

    if ($result) {

        $user['avatar'] = avatar($userid, 'middle', true);

        if (strtolower(CHARSET) == 'gbk') {
            $user['name'] = diconv($result['name'], 'gbk', 'utf-8');
        }else{
            $user['name'] = $result['name'];
        }
        $user['last_login_time'] = date('Y-m-d H:i', $result['last_login_time']);
    }else{
        $userInfo = DB::fetch_first("select * from ".DB::table('junhua_usermap_user')." where user_id = " . $userid);
        if($userInfo){
            $user['avatar'] = avatar($userid, 'middle', true);

            if (strtolower(CHARSET) == 'gbk') {
                $user['name'] = diconv($userInfo['username'], 'gbk', 'utf-8');
            }else{
                $user['name'] = $userInfo['username'];
            }
            $user['last_login_time'] = date('Y-m-d H:i', $userInfo['last_time']);
        }
    }
}else{
    $userInfo = DB::fetch_first("select * from ".DB::table('junhua_usermap_user')." where user_id = " . $userid);
    if($userInfo){
        $user['avatar'] = avatar($userid, 'middle', true);

        if (strtolower(CHARSET) == 'gbk') {
            $user['name'] = diconv($userInfo['username'], 'gbk', 'utf-8');
        }else{
            $user['name'] = $userInfo['username'];
        }
        $user['last_login_time'] = date('Y-m-d H:i', $userInfo['last_time']);
    }
}


header("Content-type:text/json;charset=utf-8");
echo json_encode($user);