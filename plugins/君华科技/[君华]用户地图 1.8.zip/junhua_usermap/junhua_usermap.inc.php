<?php 
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('REQUEST_METHOD',$_SERVER['REQUEST_METHOD']);
define('IS_POST',       REQUEST_METHOD == 'POST' ? true : false);


$seting		= $_G['cache']['plugin']['junhua_usermap'];
$base_seting     = $_G['cache']['plugin']['junhua_base'];

$baidu_ak       = $base_seting['baidu_ak'];
$maga_localhost = $base_seting['maga_localhost'];
$maga_root      = $base_seting['maga_root'];
$maga_password  = $base_seting['maga_password'];
$maga_dataname  = $base_seting['maga_dataname'];


$xuni_num       = $seting['xuni_num'];
$fw_passopen    = $seting['fw_passopen'];
$fw_pass        = $seting['fw_pass'];
$lnglat_center  = $seting['lnglat_center'];
$map_jibie      = $seting['map_jibie'];
$f_color        = $seting['f_color'];
$m_color        = $seting['m_color'];
$n_color        = $seting['n_color'];
$page_title     = $seting['page_title'];
$open_usermsg   = $seting['open_usermsg'];

$baidu_shapetype   = $seting['baidu_shapetype'] ? $seting['baidu_shapetype'] : 'BMAP_POINT_SHAPE_RHOMBUS';
$baidu_sizetype   = $seting['baidu_sizetype'] ? $seting['baidu_sizetype'] : 'BMAP_POINT_SIZE_NORMAL';

$real = $_GET['real'];

if($fw_passopen == 1){

    if(IS_POST && $_GET['formhash'] != FORMHASH){
        exit('Access Denied');
    }

    if($fw_pass == $_GET['fw_pass']){
        dsetcookie('fw_pass', $fw_pass);
    }

    if(getcookie('fw_pass') != $fw_pass){
        include template('junhua_usermap:pass');
        exit;
    }
}

if($maga_localhost && $maga_root && $maga_password){
    $Driver = function_exists('mysql_connect') ? 'db_driver_mysql' : 'db_driver_mysqli';
    $MagDb = new $Driver;

    $DbConfig[1]['dbhost'] = $maga_localhost;
    $DbConfig[1]['dbuser'] = $maga_root;
    $DbConfig[1]['dbpw'] = $maga_password;
    $DbConfig[1]['dbname'] = $maga_dataname;
    $DbConfig[1]['tablepre'] = $TablePre = 'mag_';
    $DbConfig[1]['pconnect'] = '0';
    $DbConfig[1]['dbcharset'] = $_G['charset'];

    $MagDb->set_config($DbConfig);
    $MagDb->connect();
}


$result = array();
if($MagDb && $maga_dataname){
    $query = $MagDb->query('SELECT ue.last_login_time,ue.lng,ue.lat,ue.user_id,u.sex FROM mag_user_extra as ue left join mag_user as u on ue.user_id = u.user_id WHERE ue.lng>0');

    while($value = DB::fetch($query)) {
        $result[] = $value;
    }

}elseif(!$MagDb && $maga_dataname){
    $result = Db::fetch_all('SELECT ue.last_login_time,ue.lng,ue.lat,ue.user_id,u.sex FROM '.$maga_dataname.'.mag_user_extra as ue left join '.$maga_dataname.'.mag_user as u on ue.user_id = u.user_id WHERE ue.lng>0');
}

$xunis = array();

if($real != 1){
    $xuni = array();
    $xuni_num = str_replace("\r", '', $xuni_num);
    $xuni_num = explode("\n", $xuni_num);

    foreach ($xuni_num as $key => $value) {
    	$xuni[] = explode(',', $value);
    }

    foreach ($xuni as $key => $value) {

    	for ($i=0; $i < $value[2]; $i++) { 

            $xunis[] = array(
                'lng' => $value[0] + rand(-1000000, 1000000)/(1000000 * (100/($value[4] ? $value[4] : 10))) * ($i % 50)/50,
                'lat' => $value[1] + rand(-1000000, 1000000)/(1000000 * (100/($value[4] ? $value[4] : 10))) * ($i % 50)/50,
                'sex' => -1,
                'color' => $value[3],
            );
    	}
    }
}

$bbsarray = Db::fetch_all('SELECT last_time as last_login_time,lng,lat,user_id,sex FROM '.DB::table('junhua_usermap_user').' where lng>0');


$result = array_merge($xunis, $result, $bbsarray);
$result = json_encode($result);

//&#x5f00;&#x59cb;&#x521b;&#x5efa;&#x6570;&#x636e;
include template('junhua_usermap:index');