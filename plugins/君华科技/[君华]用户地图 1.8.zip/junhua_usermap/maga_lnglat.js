if(junhua_uid){
	mag.getLocation(function(res){
		a = new Image();
		a.src = junhua_lnglaturl+'&lat='+res.lat+'&lng='+res.lng+'&uid='+junhua_uid;
	});
}