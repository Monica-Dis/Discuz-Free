if(junhua_uid){
	QFH5.getLocation(function(state,res){
	  if(state==1){
	    //&#x83b7;&#x53d6;&#x6210;&#x529f;
		a = new Image();
		a.src = junhua_lnglaturl+'&lat='+res.latitude+'&lng='+res.longitude+'&uid='+junhua_uid;
	  }
	})
}