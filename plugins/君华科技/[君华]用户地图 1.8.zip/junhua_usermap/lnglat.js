if(junhua_uid){

	var JunhuaCache={
	        type:'session',
	        setType:function(){
	            if(this.type == 'session'){
	                return window.sessionStorage;
	            }
	            if(this.type == 'local'){
	                return window.localStorage;
	            }
	        },
	        set:function($key,$value){
	          this.setType().setItem($key,$value);
	        },
	        get:function($key){
	          return this.setType().getItem($key)
	        }
	    }

	var cacheTime = JunhuaCache.get('junhua_usermap_cachetime');
	var nowTime = new Date().getTime()

	if(cacheTime == null || (nowTime - cacheTime)/1000 - 300 > 0){

		var geolocation = new BMap.Geolocation();
		geolocation.getCurrentPosition(function(r){
			if(this.getStatus() == BMAP_STATUS_SUCCESS){
				a = new Image();
				a.src = junhua_lnglaturl+'&lat='+r.point.lat+'&lng='+r.point.lng+'&uid='+junhua_uid;
				JunhuaCache.set('junhua_usermap_cachetime', nowTime);
			}    
		},{enableHighAccuracy: true})
	}
}