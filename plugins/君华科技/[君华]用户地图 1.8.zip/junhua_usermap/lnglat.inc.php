<?php 
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


//&#x5224;&#x65ad;&#x662f;&#x5426;&#x662f;&#x9a6c;&#x7532;
$uid = $_G['uid'] ? $_G['uid'] : 0;
$puid	= $_GET['uid'];
$lat	= $_GET['lat'];
$lng	= $_GET['lng'];


if($uid && $uid == $puid){

	$sex = DB::fetch_first("select gender from ".DB::table('common_member_profile')." where uid = " . $uid);

	$settings = array(
		'user_id'	=> $uid,
		'username'	=> $_G['username'],
		'lng'		=> $lng,
		'lat'		=> $lat,
		'sex'		=> $sex['gender'],
		'last_time'	=> $_G['timestamp'],
	);

	foreach($settings as $key => $value) {
		$settings[$key] = '\''.addslashes($value).'\'';
	}

	DB::query("REPLACE INTO ".DB::table('junhua_usermap_user')." (`user_id`, `username`, `lng`, `lat`,  `sex`, `last_time`) VALUES (".implode(',', $settings).")");
}