<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$sql['1.4'] = <<<EOF
DROP TABLE IF EXISTS `pre_junhua_usermap_user`;
CREATE TABLE `pre_junhua_usermap_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(128) DEFAULT '',
  `lat` float(11,6) DEFAULT NULL,
  `lng` float(11,6) DEFAULT NULL,
  `sex` tinyint(1) DEFAULT '0',
  `last_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`user_id`),
  KEY `lat` (`lat`),
  KEY `lng` (`lng`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

foreach($sql as $key => $value) {
    if($_GET['fromversion'] < $key) {
        runquery($value);
    }
}

$finish = true;