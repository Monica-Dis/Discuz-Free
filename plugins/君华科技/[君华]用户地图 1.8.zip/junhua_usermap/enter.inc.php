<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
		exit('Access Denied');
	}

	loadcache('plugin');
	$base_seting     = $_G['cache']['plugin']['junhua_base'];

	if(!is_file('source/plugin/junhua_base/index.html') || !in_array('junhua_base', $_G['setting']['plugins']['available'])){
		showmessage('&#x672c;&#x63d2;&#x4ef6;&#x4f9d;&#x8d56;[&#x541b;&#x534e;]&#x57fa;&#x7840;&#x63d2;&#x4ef6;&#xff0c;&#x8bf7;&#x70b9;&#x51fb;&#x4e0b;&#x8f7d;&#x5b89;&#x88c5;&#xff0c;&#x5df2;&#x4e0b;&#x8f7d;&#x7528;&#x6237;&#x8bf7;&#x5f00;&#x542f;&#x3002;', 'https://dism.taobao.com/?@junhua_base.plugin', array(), array('refreshtime' => 5));
	}


	showtableheader();/*Dism_taobao_com*/
	showsetting('&#x5730;&#x56fe;&#x771f;&#x5b9e;&#x6570;&#x636e;&#x94fe;&#x63a5;', 'link', $_G['siteurl'].'plugin.php?id=junhua_usermap&real=1', 'text');
	showsetting('&#x5730;&#x56fe;&#x5305;&#x542b;&#x865a;&#x62df;&#x7528;&#x6237;&#x94fe;&#x63a5;', 'link', $_G['siteurl'].'plugin.php?id=junhua_usermap', 'text');

	$textarea = <<<end

\$is_ajax = ((isset(\$_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower(\$_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') || !empty(\$_POST['ajax']) || !empty(\$_GET['ajax'])) ? true : false;

\$ak = \$_G['cache']['plugin']['junhua_base']['baidu_ak'];
\$bbs_open = \$_G['cache']['plugin']['junhua_usermap']['bbs_open'];

if(!\$is_ajax && \$ak && \$bbs_open == 1){
		\$html = <<<endl
<script type="text/javascript" >
var junhua_uid={\$_G[uid]};
var junhua_lnglaturl='plugin.php?id=junhua_usermap:lnglat';
</script>
<script src="//api.map.baidu.com/api?v=2.0&ak=\$ak" type="text/javascript"></script>
<script src="source/plugin/junhua_usermap/lnglat.js" type="text/javascript" ></script>
endl;

	if(\$identifier != 'junhua_usermap'){
	echo \$html;
	}
}
end;

	showsetting('&#x83b7;&#x53d6;&#x5b9a;&#x4f4d;&#x4ee3;&#x7801;', 'link', $textarea, 'textarea', '', 0, '&#x8bf7;&#x628a;&#x6b64;&#x5904;&#x7684;&#x4ee3;&#x7801;&#x653e;&#x5230;&#x8bba;&#x575b;&#x6839;&#x76ee;&#x5f55;plugin.php&#x6587;&#x4ef6;&#x7684;include DISCUZ_ROOT.$modfile;&#x7684;&#x4e0b;&#x4e00;&#x884c;');

	$baseLink = ADMINSCRIPT.'?action=plugins&operation=config&identifier=junhua_base';

	showsetting('&#x767e;&#x5ea6;&#x5730;&#x56fe;ak', 'link', $base_seting['baidu_ak'], 'text', 1, 0, '&#x8bf7;&#x5230;&#x57fa;&#x7840;&#x63d2;&#x4ef6;&#x90a3;&#x8bbe;&#x7f6e;<a href="'.$baseLink.'"><b style="color:red">&#x7acb;&#x5373;&#x8bbe;&#x7f6e;</b></a>');
	showsetting('&#x9a6c;&#x7532;&#x6570;&#x636e;&#x5e93;&#x94fe;&#x63a5;', 'link', $base_seting['maga_localhost'], 'text', 1, 0, '&#x8bf7;&#x5230;&#x57fa;&#x7840;&#x63d2;&#x4ef6;&#x90a3;&#x8bbe;&#x7f6e;<a href="'.$baseLink.'"><b style="color:red">&#x7acb;&#x5373;&#x8bbe;&#x7f6e;</b></a>');
	showsetting('&#x9a6c;&#x7532;&#x6570;&#x636e;&#x5e93;&#x7528;&#x6237;&#x540d;', 'link', $base_seting['maga_root'], 'text', 1, 0, '&#x8bf7;&#x5230;&#x57fa;&#x7840;&#x63d2;&#x4ef6;&#x90a3;&#x8bbe;&#x7f6e;<a href="'.$baseLink.'"><b style="color:red">&#x7acb;&#x5373;&#x8bbe;&#x7f6e;</b></a>');
	showsetting('&#x9a6c;&#x7532;&#x6570;&#x636e;&#x5e93;&#x5bc6;&#x7801;', 'link', $base_seting['maga_password'], 'text', 1, 0, '&#x8bf7;&#x5230;&#x57fa;&#x7840;&#x63d2;&#x4ef6;&#x90a3;&#x8bbe;&#x7f6e;<a href="'.$baseLink.'"><b style="color:red">&#x7acb;&#x5373;&#x8bbe;&#x7f6e;</b></a>');
	showsetting('&#x9a6c;&#x7532;&#x6570;&#x636e;&#x5e93;&#x540d;', 'link', $base_seting['maga_dataname'], 'text', 1, 0, '&#x8bf7;&#x5230;&#x57fa;&#x7840;&#x63d2;&#x4ef6;&#x90a3;&#x8bbe;&#x7f6e;<a href="'.$baseLink.'"><b style="color:red">&#x7acb;&#x5373;&#x8bbe;&#x7f6e;</b></a>');
	showsetting('&#x9a6c;&#x7532;&#x94fe;&#x63a5;', 'link', $base_seting['maga_url'], 'text', 1, 0, '&#x8bf7;&#x5230;&#x57fa;&#x7840;&#x63d2;&#x4ef6;&#x90a3;&#x8bbe;&#x7f6e;<a href="'.$baseLink.'"><b style="color:red">&#x7acb;&#x5373;&#x8bbe;&#x7f6e;</b></a>');
	showsetting('&#x9a6c;&#x7532;&#x4e03;&#x725b;&#x4e91;&#x94fe;&#x63a5;', 'link', $base_seting['maga_qiniu'], 'text', 1, 0, '&#x8bf7;&#x5230;&#x57fa;&#x7840;&#x63d2;&#x4ef6;&#x90a3;&#x8bbe;&#x7f6e;<a href="'.$baseLink.'"><b style="color:red">&#x7acb;&#x5373;&#x8bbe;&#x7f6e;</b></a>');


	showtablefooter();/*dis'.'m.tao'.'bao.com*/

?>