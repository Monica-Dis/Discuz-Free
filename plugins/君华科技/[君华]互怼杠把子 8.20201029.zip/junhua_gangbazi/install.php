<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$ADMINSCRIPT = ADMINSCRIPT;
$siteurl = $_G['siteurl'];

$createtablesql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_junhua_gangbazi_comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `username` varchar(128) DEFAULT '',
  `avatar` varchar(128) DEFAULT '',
  `pk_id` int(11) DEFAULT '0',
  `comment_content` varchar(1000) DEFAULT '',
  `comment_type` tinyint(1) DEFAULT '0',
  `is_top` tinyint(1) DEFAULT '0',
  `is_enable` tinyint(1) DEFAULT '0',
  `like_num` int(10) DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`comment_id`),
  KEY `pk_id` (`pk_id`),
  KEY `comment_type` (`comment_type`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_gangbazi_like` (
  `like_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `pk_id` int(11) DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`like_id`),
  KEY `pk_id` (`pk_id`),
  KEY `comment_id` (`comment_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_gangbazi_pk` (
  `pk_id` int(11) NOT NULL AUTO_INCREMENT,
  `pk_title` varchar(256) DEFAULT '',
  `pk_cover` varchar(256) DEFAULT '',
  `pk_zhengfang` varchar(256) DEFAULT '',
  `pk_fanfang` varchar(256) DEFAULT '',
  `pk_zfbtn_name` varchar(128) DEFAULT '',
  `pk_zftybtn_name` varchar(128) DEFAULT '',
  `pk_ffbtn_name` varchar(128) DEFAULT '',
  `pk_fftybtn_name` varchar(128) DEFAULT '',
  `pk_zfnum` int(11) DEFAULT '0',
  `pk_ffnum` int(11) DEFAULT '0',
  `pk_wailian` varchar(256) DEFAULT '',
  `pk_miaoshu` varchar(256) DEFAULT '',
  `pk_wyjump` tinyint(1) DEFAULT '0',
  `end_time` int(11) DEFAULT '0',
  `tuisong_uids` varchar(1000) DEFAULT '',
  `is_tuisong` tinyint(1) DEFAULT '0',
  `is_enable` tinyint(1) DEFAULT '0',
  `is_tp_minindex` tinyint(1) DEFAULT '0',
  `comment_open` tinyint(1) DEFAULT '1',
  `comment_jumpurl` varchar(256) DEFAULT '',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`pk_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_gangbazi_pking` (
  `pking_id` int(11) NOT NULL AUTO_INCREMENT,
  `pk_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `pk_type` int(11) DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`pking_id`),
  KEY `pk_id` (`pk_id`),
  KEY `user_id` (`user_id`),
  KEY `pk_type` (`pk_type`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

runquery($createtablesql);

$finish = TRUE;