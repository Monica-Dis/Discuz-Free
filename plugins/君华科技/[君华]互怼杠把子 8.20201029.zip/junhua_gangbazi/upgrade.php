<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$createtablesql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_junhua_gangbazi_comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `username` varchar(128) DEFAULT '',
  `avatar` varchar(128) DEFAULT '',
  `pk_id` int(11) DEFAULT '0',
  `comment_content` varchar(1000) DEFAULT '',
  `comment_type` tinyint(1) DEFAULT '0',
  `is_top` tinyint(1) DEFAULT '0',
  `is_enable` tinyint(1) DEFAULT '0',
  `like_num` int(10) DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`comment_id`),
  KEY `pk_id` (`pk_id`),
  KEY `comment_type` (`comment_type`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_gangbazi_like` (
  `like_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `pk_id` int(11) DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`like_id`),
  KEY `pk_id` (`pk_id`),
  KEY `comment_id` (`comment_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_gangbazi_pk` (
  `pk_id` int(11) NOT NULL AUTO_INCREMENT,
  `pk_title` varchar(256) DEFAULT '',
  `pk_cover` varchar(256) DEFAULT '',
  `pk_zhengfang` varchar(256) DEFAULT '',
  `pk_fanfang` varchar(256) DEFAULT '',
  `pk_zfbtn_name` varchar(128) DEFAULT '',
  `pk_zftybtn_name` varchar(128) DEFAULT '',
  `pk_ffbtn_name` varchar(128) DEFAULT '',
  `pk_fftybtn_name` varchar(128) DEFAULT '',
  `pk_zfnum` int(11) DEFAULT '0',
  `pk_ffnum` int(11) DEFAULT '0',
  `pk_wailian` varchar(256) DEFAULT '',
  `pk_miaoshu` varchar(256) DEFAULT '',
  `pk_wyjump` tinyint(1) DEFAULT '0',
  `end_time` int(11) DEFAULT '0',
  `tuisong_uids` varchar(1000) DEFAULT '',
  `is_tuisong` tinyint(1) DEFAULT '0',
  `is_enable` tinyint(1) DEFAULT '0',
  `is_tp_minindex` tinyint(1) DEFAULT '0',
  `comment_open` tinyint(1) DEFAULT '1',
  `comment_jumpurl` varchar(256) DEFAULT '',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`pk_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_gangbazi_pking` (
  `pking_id` int(11) NOT NULL AUTO_INCREMENT,
  `pk_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `pk_type` int(11) DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`pking_id`),
  KEY `pk_id` (`pk_id`),
  KEY `user_id` (`user_id`),
  KEY `pk_type` (`pk_type`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

runquery($createtablesql);


$updatesql = array ('junhua_gangbazi_comment' => array ('comment_id' => array ('Field' => 'comment_id','Type' => 'int(11)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),'user_id' => array ('Field' => 'user_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'username' => array ('Field' => 'username','Type' => 'varchar(128)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'avatar' => array ('Field' => 'avatar','Type' => 'varchar(128)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'pk_id' => array ('Field' => 'pk_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'comment_content' => array ('Field' => 'comment_content','Type' => 'varchar(1000)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'comment_type' => array ('Field' => 'comment_type','Type' => 'tinyint(1)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'is_top' => array ('Field' => 'is_top','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'is_enable' => array ('Field' => 'is_enable','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'like_num' => array ('Field' => 'like_num','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'add_time' => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),),'junhua_gangbazi_like' => array ('like_id' => array ('Field' => 'like_id','Type' => 'int(11)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),'comment_id' => array ('Field' => 'comment_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'user_id' => array ('Field' => 'user_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'pk_id' => array ('Field' => 'pk_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'add_time' => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),),'junhua_gangbazi_pk' => array ('pk_id' => array ('Field' => 'pk_id','Type' => 'int(11)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),'pk_title' => array ('Field' => 'pk_title','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'pk_cover' => array ('Field' => 'pk_cover','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'pk_zhengfang' => array ('Field' => 'pk_zhengfang','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'pk_fanfang' => array ('Field' => 'pk_fanfang','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'pk_zfbtn_name' => array ('Field' => 'pk_zfbtn_name','Type' => 'varchar(128)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'pk_zftybtn_name' => array ('Field' => 'pk_zftybtn_name','Type' => 'varchar(128)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'pk_ffbtn_name' => array ('Field' => 'pk_ffbtn_name','Type' => 'varchar(128)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'pk_fftybtn_name' => array ('Field' => 'pk_fftybtn_name','Type' => 'varchar(128)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'pk_zfnum' => array ('Field' => 'pk_zfnum','Type' => 'int(11)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'pk_ffnum' => array ('Field' => 'pk_ffnum','Type' => 'int(11)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'pk_wailian' => array ('Field' => 'pk_wailian','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'pk_miaoshu' => array ('Field' => 'pk_miaoshu','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'pk_wyjump' => array ('Field' => 'pk_wyjump','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'end_time' => array ('Field' => 'end_time','Type' => 'int(11)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'tuisong_uids' => array ('Field' => 'tuisong_uids','Type' => 'varchar(1000)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'is_tuisong' => array ('Field' => 'is_tuisong','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'is_enable' => array ('Field' => 'is_enable','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'is_tp_minindex' => array ('Field' => 'is_tp_minindex','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'comment_open' => array ('Field' => 'comment_open','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '1','Extra' => '',),'comment_jumpurl' => array ('Field' => 'comment_jumpurl','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'add_time' => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),),'junhua_gangbazi_pking' => array ('pking_id' => array ('Field' => 'pking_id','Type' => 'int(11)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),'pk_id' => array ('Field' => 'pk_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'user_id' => array ('Field' => 'user_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'pk_type' => array ('Field' => 'pk_type','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'add_time' => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),),);

foreach ($updatesql as $updatesql_key => $updatesql_value) {
    # code...

    $columns_news = $updatesql_value;
    $columns = DB::fetch_all('SHOW COLUMNS FROM %t', array($updatesql_key));
    $columns_ary = array();

    foreach ($columns as $key => $value) {
        if(!isset($columns_news[$value['Field']])){
            $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` DROP COLUMN `'.$value['Field'].'`;';
            runquery($sql);
        }else{
            $columns_ary[$value['Field']] = $value;
        }
    }

    foreach ($columns_news as $key => $value) {
        //&#x65b0;&#x589e;&#x5b57;&#x6bb5;
        if(!isset($columns_ary[$key])){
            $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` ADD COLUMN `'.$key.'` '.$value['Type'].' '.($value['Null'] == 'YES' ? 'NULL' : '').' DEFAULT "'.$value['Default'].'";';
            runquery($sql);
        }else{

            //&#x4fee;&#x6539;&#x5b57;&#x6bb5;
            if($columns_ary[$key]['Field'] != $value['Field'] || $columns_ary[$key]['Type'] != $value['Type'] || $columns_ary[$key]['Default'] != $value['Default'] ){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` MODIFY COLUMN `'.$key.'` '.$value['Type'].' '.($value['Null'] == 'YES' ? 'NULL' : '').' DEFAULT "'.$value['Default'].'";';
                runquery($sql);
            }

            //&#x589e;&#x52a0;&#x7d22;&#x5f15;
            if($columns_ary[$key]['Key'] == '' && $value['Key'] == 'MUL'){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` ADD INDEX `'.$key.'` (`'.$key.'`) USING BTREE;';
                runquery($sql);
            }

            //&#x5220;&#x9664;&#x7d22;&#x5f15;
            if($columns_ary[$key]['Key'] == 'MUL' && $value['Key'] == ''){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` DROP INDEX `'.$key.'`;'; //&#x5220;&#x9664;&#x7d22;&#x5f15;
                runquery($sql);
            }
        }

    }
}

$finish = true;