<?php 

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

C::t('common_syscache')->delete('junhua_base_system');
C::t('common_syscache')->delete('junhua_gangbazi_setting');

$sql = <<<EOF
	DROP TABLE IF EXISTS `pre_junhua_gangbazi_pking`;
	DROP TABLE IF EXISTS `pre_junhua_gangbazi_pk`;
	DROP TABLE IF EXISTS `pre_junhua_gangbazi_comment`;
	DROP TABLE IF EXISTS `pre_junhua_gangbazi_like`;
EOF;


runquery($sql);
$finish = true;
?>