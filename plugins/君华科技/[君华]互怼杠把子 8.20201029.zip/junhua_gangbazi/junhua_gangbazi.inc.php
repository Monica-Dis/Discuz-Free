<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!is_file('source/plugin/junhua_base/index.html')){
	showmessage('&#x672c;&#x63d2;&#x4ef6;&#x4f9d;&#x8d56;[&#x541b;&#x534e;]&#x57fa;&#x7840;&#x63d2;&#x4ef6;&#xff0c;&#x8bf7;&#x70b9;&#x51fb;&#x4e0b;&#x8f7d;&#x5b89;&#x88c5;&#xff0c;&#x5df2;&#x4e0b;&#x8f7d;&#x7528;&#x6237;&#x8bf7;&#x5f00;&#x542f;&#x3002;', 'https://dism.taobao.com/?@junhua_base.plugin', array(), array('refreshtime' => 5));
}

@date_default_timezone_set('Etc/GMT'.($_G['setting']['timeoffset'] > 0 ? '-' : '+').(abs($_G['setting']['timeoffset'])));

include_once('source/plugin/junhua_base/common/common.php');
include_once('source/plugin/junhua_base/libs/model.class.php');
include_once('source/plugin/junhua_base/func/function.php');

$junhua_base_config		= $_G['cache']['plugin']['junhua_base'];
$junhua_gangbazi_config		= $_G['cache']['plugin']['junhua_gangbazi'];

loadcache('junhua_gangbazi_setting');
$junhua_gangbazi_setting = dunserialize($_G['cache']['junhua_gangbazi_setting']);

$uid = $_G['uid'] ? $_G['uid'] : 0;

$gangbazi_uids = $junhua_gangbazi_setting['gangbazi_uids'];
$gangbazi_uids = explode(',', $gangbazi_uids);
        

$m = junhua_I('m');
$c = junhua_I('c');
$a = junhua_I('a');

//&#x64cd;&#x4f5c;&#x6a21;&#x5757;
if(!in_array($m, array('m', 'mp'))){
	$m = 'm';
}

$m_list = array(
	'index',
	'ajax'
);

$mp_list = array(
	'pk',
	'comment',
	'setting',
);


if($m == 'm' && !in_array($c, $m_list)){
	$c = 'index';
}

if($m == 'mp' && !in_array($c, $mp_list)){
	$c = 'pk';
}

$admin_uids = $junhua_gangbazi_config['admin_uids'];
$admin_lists = explode(',', $junhua_gangbazi_config['admin_uids']);


if($m == 'mp'){
	//&#x4e3a;&#x4e86;&#x7ffb;&#x9875;
	if(!defined('IN_ADMINCP')) {
		define('IN_ADMINCP', true);
	}
}

$_G['mobiletpl'][IN_MOBILE]='/';


if((IS_POST || IS_AJAX) && junhua_I('formhash') != FORMHASH){
	exit;
}

//&#x5224;&#x65ad;&#x662f;&#x5426;&#x5b58;&#x5728;&#x6587;&#x4ef6; &#x5b58;&#x5728;&#x76f4;&#x63a5;&#x5f15;&#x5165;
require 'source/plugin/junhua_gangbazi/controller/'.$m.'/'.$c.'.php';
