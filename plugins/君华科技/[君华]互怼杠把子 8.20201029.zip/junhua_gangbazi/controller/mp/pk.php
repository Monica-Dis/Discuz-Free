<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include("common.php");

if(!in_array($a, array('add', 'edit', 'del', 'index', 'set', 'uploadfile', 'win', 'tuisong', 'commentopen'))){
    $a = 'index';
}

$pkModel = new junhua_model('GangbaziPk');
$pkingModel = new junhua_model('GangbaziPking');

if($a == 'index'){

    $page = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $theurl = junhua_url('mp/pk/index', http_build_query($param), true);


    $where = array();
    $totalNum = $pkModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $pkModel->select($where, '*', 'pk_id desc', $start, $perpage);

    $block_head_title = 'PK&#x5217;&#x8868;';
    $block_title = '&#x8bdd;&#x9898;&#x5217;&#x8868;';
    $block_css = '';

}elseif ($a == 'add') {
	if(IS_AJAX){
        
        $pk_title        = junhua_I('pk_title');
        $pk_zhengfang    = junhua_I('pk_zhengfang');
        $pk_zfbtn_name   = junhua_I('pk_zfbtn_name');
        $pk_zftybtn_name = junhua_I('pk_zftybtn_name');
        $pk_ffbtn_name   = junhua_I('pk_ffbtn_name');
        $pk_fftybtn_name = junhua_I('pk_fftybtn_name');
        $pk_fanfang      = junhua_I('pk_fanfang');
        $pk_cover        = junhua_I('pk_cover');
        $pk_ffnum        = junhua_I('pk_ffnum/d', 0);
        $pk_zfnum        = junhua_I('pk_zfnum/d', 0);
        $end_time        = junhua_I('end_time');
        $pk_wyjump       = junhua_I('pk_wyjump/d', 0);
        $pk_miaoshu      = junhua_I('pk_miaoshu');
        $pk_wailian      = junhua_I('pk_wailian');
        $comment_open    = junhua_I('comment_open/d', 0);
        $comment_jumpurl = junhua_I('comment_jumpurl');
        $is_tp_minindex  = junhua_I('is_tp_minindex/d', 0);

        $end_time = strtotime($end_time);

		$data = array(
            'pk_title'        => $pk_title,
            'pk_zhengfang'    => $pk_zhengfang,
            'pk_fanfang'      => $pk_fanfang,
            'pk_cover'        => $pk_cover,
            
            'pk_zfbtn_name'   => $pk_zfbtn_name,
            'pk_zftybtn_name' => $pk_zftybtn_name,
            'pk_ffbtn_name'   => $pk_ffbtn_name,
            'pk_fftybtn_name' => $pk_fftybtn_name,
            'pk_ffnum'        => $pk_ffnum,
            'pk_zfnum'        => $pk_zfnum,
            'end_time'        => $end_time,
            'pk_wyjump'       => $pk_wyjump,
            'pk_wailian'      => $pk_wailian,
            'pk_miaoshu'      => $pk_miaoshu,
            'is_tp_minindex'  => $is_tp_minindex,
            'comment_open'    => $comment_open,
            'comment_jumpurl' => $comment_jumpurl,
            
            'add_time'        => $_G['timestamp'],
            'is_enable'       => 1,
		);

		$pkModel->add($data);
	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/pk/index', '', true)));
	}

    $pkInfo['comment_open'] = 1;

    $block_head_title = 'pk&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;pk';
    $block_css = '';
    $a = 'update';

}elseif ($a == 'edit') {

	$pk_id = junhua_I('pid/d', 0);

	$where = array('pk_id' => $pk_id);
	$pkInfo = $pkModel->find($where);

	if(!$pkInfo){
        dheader('location:' . junhua_url('mp/pk/index', '', 1));
        exit;
	}

	if(IS_AJAX){

        $pk_title        = junhua_I('pk_title');
        $pk_zhengfang    = junhua_I('pk_zhengfang');
        $pk_zfbtn_name   = junhua_I('pk_zfbtn_name');
        $pk_zftybtn_name = junhua_I('pk_zftybtn_name');
        $pk_ffbtn_name   = junhua_I('pk_ffbtn_name');
        $pk_fftybtn_name = junhua_I('pk_fftybtn_name');
        $pk_fanfang      = junhua_I('pk_fanfang');
        $pk_cover        = junhua_I('pk_cover');
        $pk_ffnum        = junhua_I('pk_ffnum/d', 0);
        $pk_zfnum        = junhua_I('pk_zfnum/d', 0);
        $end_time        = junhua_I('end_time');
        $pk_wyjump       = junhua_I('pk_wyjump/d', 0);
        $pk_miaoshu      = junhua_I('pk_miaoshu');
        $pk_wailian      = junhua_I('pk_wailian');
        $is_tp_minindex  = junhua_I('is_tp_minindex/d', 0);
        $comment_open    = junhua_I('comment_open/d', 0);
        $comment_jumpurl = junhua_I('comment_jumpurl');

        $end_time = strtotime($end_time);

		$data = array(
            'pk_title'        => $pk_title,
            'pk_zhengfang'    => $pk_zhengfang,
            'pk_fanfang'      => $pk_fanfang,
            'pk_cover'        => $pk_cover,
            
            'pk_zfbtn_name'   => $pk_zfbtn_name,
            'pk_zftybtn_name' => $pk_zftybtn_name,
            'pk_ffbtn_name'   => $pk_ffbtn_name,
            'pk_fftybtn_name' => $pk_fftybtn_name,
            'pk_ffnum'        => $pk_ffnum,
            'pk_zfnum'        => $pk_zfnum,
            'end_time'        => $end_time,
            'pk_wyjump'       => $pk_wyjump,
            'pk_wailian'      => $pk_wailian,
            'pk_miaoshu'      => $pk_miaoshu,
            'is_tp_minindex'  => $is_tp_minindex,
            'comment_open'    => $comment_open,
            'comment_jumpurl' => $comment_jumpurl,
		);

		$pkModel->save($where, $data);
	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/pk/index', '', 1)));
	}

    $pkInfo['end_time'] = $pkInfo['end_time'] ? date('Y-m-d H:i:s', $pkInfo['end_time']) : '';

    $block_head_title = 'pk&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;pk';
    $block_css = '';
    $a = 'update';

}elseif($a == 'del'){
    if(IS_AJAX){
        $pid = junhua_I('pid/d', 0);

        $where = array(
            'pk_id'      => $pid
        );

        $pkInfo = $pkModel->find($where);
        if(!$pkInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $pkModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }

}elseif($a == 'set'){
    if(IS_AJAX){
        $pid = junhua_I('pid/d', 0);

        $where = array(
            'pk_id'      => $pid
        );

        $pkInfo = $pkModel->find($where);
        if(!$pkInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($pkInfo['is_enable'] == 1){
            $is_enable = 2;
        }else{
            $is_enable = 1;
        }

        $pkModel->save($where, array('is_enable' => $is_enable));

        junhua_ajaxReturn(array('status' => 1));
    }

}elseif($a == 'uploadfile'){
    include_once('source/plugin/junhua_base/libs/filemanger.class.php');

    if (!IS_POST && isset($_FILES) ? $_FILES : array()) {
        exit;
    }

    $filemanger = new junhua_filemanger('source/plugin/junhua_gangbazi', 'source/plugin/junhua_gangbazi');
    $img_path = $filemanger->uploadJson('Filedata', false);

    junhua_ajaxReturn(array('status' => 1, 'file_path' => $img_path));

}elseif($a == 'win'){

    if(IS_AJAX){


        $pk_id = junhua_I('pid/d', 0);

        $where = array('pk_id' => $pk_id);
        $pkInfo = $pkModel->find($where);

        if(!$pkInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;'));
        }

        $where = array();
        $where['pk_id'] = $pk_id;

        if($pkInfo['pk_zfnum'] > $pkInfo['pk_ffnum']){
            $where['pk_type'] = 1;
        }elseif($pkInfo['pk_zfnum'] < $pkInfo['pk_ffnum']){
            $where['pk_type'] = 2;
        }

        $pkingList = $pkingModel->select($where);

        //&#x6253;&#x4e71;&#x6570;&#x7ec4;
        shuffle($pkingList);

        $gangbazi_win_num = $junhua_gangbazi_setting['gangbazi_win_num'] ? $junhua_gangbazi_setting['gangbazi_win_num'] : 10;
        $gangbazi_win_num = count($pkingList) > $gangbazi_win_num ? $gangbazi_win_num : count($pkingList);

        //&#x83b7;&#x53d6;&#x4e2a;&#x6570;
        $uids = array();
        if($pkingList){
            for ($i=0; $i < $gangbazi_win_num; $i++) { 
                $uids[] = $pkingList[$i]['user_id'];
            }
        }

        junhua_ajaxReturn(array('status' => 1, 'uids' => $uids));
    }

}elseif($a == 'tuisong'){

    if(IS_AJAX){
        set_time_limit(0);


        $pk_id = junhua_I('pid/d', 0);

        $where = array('pk_id' => $pk_id);
        $pkInfo = $pkModel->find($where);

        if(!$pkInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;'));
        }

        $tuisong_coin_num = junhua_I('tuisong_coin_num/d', 0);
        $tuisong_text = junhua_I('tuisong_text', '');
        $tuisong_uids = junhua_I('tuisong_uids', '');
        $tuisong_coin = junhua_I('tuisong_coin/d', 0);

        $uids = explode(',', $tuisong_uids);


        //&#x5f00;&#x59cb;&#x63a8;&#x9001;
        $content = array(
            'type'   => 'text',
            'content' => $tuisong_text,
        );

        if($uids){

            foreach ($uids as $key => $value) {
                //&#x6d88;&#x606f;&#x63a8;&#x9001;
                file_get_contents($junhua_base_config['maga_url'].'/mag/operative/v1/assistant/sendAssistantMsg?user_id='.$value.'&type=text&content='.urlencode(junhua_json_encode($content)).'&secret='.$junhua_base_config['maga_appsecret'].'&assistant_secret='.$junhua_base_config['maga_zs_appsecret'].'&is_push=1');

                //&#x5224;&#x65ad;&#x662f;&#x5426;&#x8981;&#x63a8;&#x9001;&#x91d1;&#x5e01;
                if($tuisong_coin && $tuisong_coin_num){
                    file_get_contents($junhua_base_config['maga_url'].'/mag/user/v1/GradeScore/addUserGold?user_id='.$value.'&gold='.$tuisong_coin_num.'&secret='.$junhua_base_config['maga_appsecret']);
                }
            }

        }

        $pkModel->save($where, array('is_tuisong' => 1, 'tuisong_uids' => $tuisong_uids));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x64cd;&#x4f5c;&#x6210;&#x529f;'));
    }

}elseif($a == 'commentopen'){
    if(IS_AJAX){
        $pid = junhua_I('pid/d', 0);

        $where = array(
            'pk_id'      => $pid
        );

        $pkInfo = $pkModel->find($where);
        if(!$pkInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($pkInfo['comment_open'] == 1){
            $comment_open = 0;
        }else{
            $comment_open = 1;
        }

        $pkModel->save($where, array('comment_open' => $comment_open));

        junhua_ajaxReturn(array('status' => 1));
    }

}
else{
	exit;
}

$block_content = 'junhua_gangbazi:mp/pk/'.$a;

include template('junhua_gangbazi:mp/layout');