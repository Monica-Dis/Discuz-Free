<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include("common.php");

if(!in_array($a, array('index'))){
    $a = 'index';
}

loadcache('junhua_base_system');
$junhua_base_system = dunserialize($_G['cache']['junhua_base_system']);

if($a == 'index'){

    if(IS_AJAX){
        
        $gangbazi_appdownload_open    = junhua_I('gangbazi_appdownload_open/d', 0);
        $gangbazi_logo                = junhua_I('gangbazi_logo', '');
        $gangbazi_title               = junhua_I('gangbazi_title', '');
        $gangbazi_indexlist_wybanner  = junhua_I('gangbazi_indexlist_wybanner', '');
        $gangbazi_appcomment_open     = junhua_I('gangbazi_appcomment_open/d', 0);
        $gangbazi_appsharehide_open   = junhua_I('gangbazi_appsharehide_open/d', 0);
        $gangbazi_headhide_open       = junhua_I('gangbazi_headhide_open/d', 0);
        $gangbazi_nomagadownload_open = junhua_I('gangbazi_nomagadownload_open/d', 0);
        $gangbazi_indexlist_style     = junhua_I('gangbazi_indexlist_style/d', 0);
        
        $gangbazi_weixin_share_open   = junhua_I('gangbazi_weixin_share_open/d', 0);
        $gangbazi_weixin_share_title  = junhua_I('gangbazi_weixin_share_title', '');
        $gangbazi_weixin_share_desc   = junhua_I('gangbazi_weixin_share_desc', '');
        $gangbazi_weixin_share_img    = junhua_I('gangbazi_weixin_share_img', '');

        $gangbazi_uids    = junhua_I('gangbazi_uids', '');

        $data = array(
            'gangbazi_appdownload_open'    => $gangbazi_appdownload_open,
            'gangbazi_logo'                => $gangbazi_logo,
            'gangbazi_title'               => $gangbazi_title,
            'gangbazi_appcomment_open'     => $gangbazi_appcomment_open,
            'gangbazi_appsharehide_open'   => $gangbazi_appsharehide_open,
            'gangbazi_headhide_open'       => $gangbazi_headhide_open,
            'gangbazi_nomagadownload_open' => $gangbazi_nomagadownload_open,
            'gangbazi_indexlist_style'     => $gangbazi_indexlist_style,
            'gangbazi_indexlist_wybanner'  => $gangbazi_indexlist_wybanner,
            
            'gangbazi_weixin_share_open'   => $gangbazi_weixin_share_open,
            'gangbazi_weixin_share_title'  => $gangbazi_weixin_share_title,
            'gangbazi_weixin_share_desc'   => $gangbazi_weixin_share_desc,
            'gangbazi_weixin_share_img'    => $gangbazi_weixin_share_img,
            'gangbazi_uids'    => $gangbazi_uids,
        );

        savecache('junhua_gangbazi_setting', serialize($data));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x914d;&#x7f6e;&#x6210;&#x529f;'));
    }

    $block_head_title = '&#x7cfb;&#x7edf;&#x914d;&#x7f6e;';
    $block_title = '&#x7cfb;&#x7edf;&#x914d;&#x7f6e;';
    $block_css = '';
}
else{
	exit;
}

$block_content = 'junhua_gangbazi:mp/setting/'.$a;

include template('junhua_gangbazi:mp/layout');