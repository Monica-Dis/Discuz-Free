<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include("common.php");

if(!in_array($a, array('add', 'edit', 'del', 'index', 'set'))){
    $a = 'index';
}

$commentModel = new junhua_model('GangbaziComment');
$commonMemberModel = new junhua_model('CommonMember', '');
$pkModel = new junhua_model('GangbaziPk');

if($a == 'index'){

    $pid = junhua_I('pid/d', '');
    $page = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $theurl = junhua_url('mp/comment/index', http_build_query($param), true);


    $where = array();

    if($pid){
        $where['pk_id'] = $pid;
    }

    $totalNum = $commentModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $commentModel->select($where, '*', 'comment_id desc', $start, $perpage);

    $block_head_title = '&#x8bc4;&#x8bba;&#x7ba1;&#x7406;';
    $block_title = '&#x8bc4;&#x8bba;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {

    if(IS_AJAX){

        $user_id         = junhua_I('user_id/d', 0);
        $pk_id           = junhua_I('pk_id/d', 0);
        $comment_content = junhua_I('comment_content');
        $comment_type    = junhua_I('comment_type/d', 0);

        $pkInfo = $pkModel->find(array('pk_id' => $pk_id));
        if(!$pkInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => 'pkId&#x4e0d;&#x5b58;&#x5728;'));
        }

        $memberInfo = $commonMemberModel->find(array('uid' => $user_id));
        if(!$memberInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x4f1a;&#x5458;&#x4e0d;&#x5b58;&#x5728;'));
        }

        $data = array(
            'user_id'         => $user_id,
            'username'        => $memberInfo['username'],
            'pk_id'           => $pk_id,
            'comment_type'    => $comment_type,
            'add_time'        => $_G['timestamp'],
            'comment_content' => $comment_content,
            'is_enable'       => 1,
        );

        $commentModel->add($data);
        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/comment/index', '', 1)));
    }

    $block_head_title = '&#x8bc4;&#x8bba;&#x7ba1;&#x7406;';
    $block_title = '&#x65b0;&#x589e;&#x8bc4;&#x8bba;';
    $block_css = '';
}elseif ($a == 'edit') {

    $comment_id = junhua_I('pid/d', 0);

    $where = array('comment_id' => $comment_id);
    $commentInfo = $commentModel->find($where);

    if(!$commentInfo){
        dheader('location:' . junhua_url('mp/comment/index', '', 1));
        exit;
    }

    if(IS_AJAX){

        $comment_content     = junhua_I('comment_content');

        $data = array(
            'comment_content'     => $comment_content,
        );

        $commentModel->save($where, $data);
        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/comment/index', '', 1)));
    }

    $block_head_title = '&#x8bc4;&#x8bba;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x8bc4;&#x8bba;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'del'){
    if(IS_AJAX){
        $pid = junhua_I('pid/d', 0);

        $where = array(
            'comment_id'      => $pid
        );

        $commentInfo = $commentModel->find($where);
        if(!$commentInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $commentModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'set'){
    if(IS_AJAX){
        $pid = junhua_I('pid/d', 0);

        $where = array(
            'comment_id'      => $pid
        );

        $commentInfo = $commentModel->find($where);
        if(!$commentInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($commentInfo['is_enable'] == 1){
            $is_enable = 2;
        }else{
            $is_enable = 1;
        }

        $commentModel->save($where, array('is_enable' => $is_enable));

        junhua_ajaxReturn(array('status' => 1));
    }
}else{
	exit;
}

$block_content = 'junhua_gangbazi:mp/comment/'.$a;

include template('junhua_gangbazi:mp/layout');