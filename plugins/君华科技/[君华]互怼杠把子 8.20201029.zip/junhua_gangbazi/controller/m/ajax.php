<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!in_array($a, array('getpklist', 'getcommentlist', 'addcomment', 'toupiao', 'del', 'top', 'like'))){
    $a = 'getcommentlist';
}


$pkModel = new junhua_model('GangbaziPk');
$commentModel = new junhua_model('GangbaziComment');
$likeModel = new junhua_model('GangbaziLike');
$PkingModel = new junhua_model('GangbaziPking');

if($a == 'getpklist'){

    if(IS_AJAX){
        $page = junhua_I('page/s', 1);
        $perpage = 10;
        if($page < 1) $page = 1;
        $start = ($page-1)*$perpage;

        $where = array(
            'is_enable' => 1
        );

        $total = $pkModel->count($where);
        $pkList = $pkModel->select($where, '*', 'pk_id desc', $start, $perpage);

        foreach ($pkList as $key => $value) {
            $Total = $value['pk_zfnum'] + $value['pk_ffnum'];

            if($Total == 0){
                $ZPercent = 50;
                $FPercent = 50;
            }else{
                $ZPercent = ceil($value['pk_zfnum']/$Total * 100);
                $FPercent = ceil($value['pk_ffnum']/$Total * 100);
            }

            $pkList[$key]['ZPercent'] = $ZPercent;
            $pkList[$key]['FPercent'] = $FPercent;

            //&#x83b7;&#x53d6;&#x591a;&#x5c11;&#x54c1;&#x8bba;&#x6570;
            $pkList[$key]['count'] = $value['pk_zfnum'] + $value['pk_ffnum'];

            $pkList[$key]['pk_zfbtn_name'] = $pkList[$key]['pk_zfbtn_name'] ? $pkList[$key]['pk_zfbtn_name'] : '&#x6295;&#x7968;';
            $pkList[$key]['pk_ffbtn_name'] = $pkList[$key]['pk_ffbtn_name'] ? $pkList[$key]['pk_ffbtn_name'] : '&#x6295;&#x7968;';
            $pkList[$key]['pk_zftybtn_name'] = $pkList[$key]['pk_zftybtn_name'] ? $pkList[$key]['pk_zftybtn_name'] : '&#x5df2;&#x6295;&#x7968;';
            $pkList[$key]['pk_fftybtn_name'] = $pkList[$key]['pk_fftybtn_name'] ? $pkList[$key]['pk_fftybtn_name'] : '&#x5df2;&#x6295;&#x7968;';
            $pkList[$key]['end_time'] = $value['end_time'] ? date('Y-m-d', $value['end_time']).'&#x622a;&#x6b62;': '';
        }


        $data = array (
            'pk'   => $pkList,
            'pageCount'  => ceil($total/$perpage),
            'count'      => $total,
            'code'       => 0,
            'statusCode' => 200,
        );

        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}elseif($a == 'getcommentlist'){

    if(IS_AJAX){
        $page = junhua_I('page/s', 1);
        $perpage = 10;
        if($page < 1) $page = 1;
        $start = ($page-1)*$perpage;


        $pk_id = junhua_I('pk_id/d', 0);

        $where = array(
            'pk_id' => $pk_id
        );

        $total = $commentModel->count($where);
        $msgList = $commentModel->select($where, '*', 'is_top desc, comment_id desc', $start, $perpage);

        $comments = array();

        //&#x83b7;&#x53d6;&#x70b9;&#x8d5e;&#x5217;&#x8868;
        $likeList = $likeModel->select(array('pk_id' => $pk_id, 'user_id' => $uid), 'comment_id', '', 0, 0 , true);

        foreach ($msgList as $key => $value) {
            $comments[] = array (
                'comment_id'   => $value['comment_id'],
                'user_id'      => $value['user_id'],
                'avatar'       => avatar($value['user_id'], 'small', true),
                'username'     => $value['username'],
                'content'      => $value['comment_content'],
                'comment_type' => $value['comment_type'],
                'like'        => in_array($value['comment_id'], $likeList),
                'like_num'      => $value['like_num'],
                'add_time'     => junhua_nicetime($value['add_time']),
            );
        }


        $data = array (
            'comments'   => $comments,
            'pageCount'  => ceil($total/$perpage),
            'count'      => $total,
            'code'       => 0,
            'statusCode' => 200,
        );

        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}elseif($a == 'addcomment'){

    $pk_id = junhua_I('pk_id/d', 0);

    if(IS_AJAX){

        if(!$uid){
            $data = array(
                'message'       => '&#x8bf7;&#x5148;&#x767b;&#x5f55;'
            );

            junhua_ajaxReturn($data);
        }

        //&#x83b7;&#x53d6;&#x89c2;&#x70b9;
        $pkingInfo = $PkingModel->find(array('user_id' => $uid, 'pk_id' => $pk_id));

        if(!$pkingInfo){
            $data = array(
                'message'       => '&#x60a8;&#x8fd8;&#x672a;&#x8868;&#x8fbe;&#x60a8;&#x7684;&#x89c2;&#x70b9;&#xff0c;&#x8bf7;&#x5148;&#x9009;&#x62e9;&#x60a8;&#x7684;&#x89c2;&#x70b9;'
            );

            junhua_ajaxReturn($data);
        }


        $pkInfo = $pkModel->find(array('pk_id' => $pk_id));

        if(!$pkInfo){
            $data = array(
                'message'       => '&#x6570;&#x636e;&#x5f02;&#x5e38;'
            );

            junhua_ajaxReturn($data);
        }

        if($pkInfo['end_time'] > 0 && $pkInfo['end_time'] < $_G['timestamp']){
            $data = array(
                'message'       => '&#x6295;&#x7968;&#x5df2;&#x622a;&#x6b62;'
            );

            junhua_ajaxReturn($data);
        }


        $content = junhua_I('content/s', '');


        loadcache(array('censor', 'bbcodes_display'));

        if(!empty($_G['cache']['censor']['filter'])) {
            $i = 0;
            while($find_words = array_slice($_G['cache']['censor']['filter']['find'], $i, 500)) {
                if(empty($find_words)) break;
                $replace_words = array_slice($_G['cache']['censor']['filter']['replace'], $i, 500);
                $i += 500;
                $content = preg_replace($find_words, $replace_words, $content);
            }
        }

        $is_enable = 1;
        if(!empty($_G['cache']['censor']['mod'])) {
            foreach($_G['cache']['censor']['mod'] as $mod_words) {
                if(preg_match_all($mod_words, $content, $matches)) {
                    $is_enable = 0;
                    break;
                }
            }
        }

        $data = array(
            'pk_id'           => $pk_id,
            'user_id'         => $uid,
            'username'        => $_G['username'],
            'comment_content' => $content,
            'comment_type'    => $pkingInfo['pk_type'],
            'add_time'        => $_G['timestamp'],
            'is_enable'       => $is_enable,
        );

        $comment_id = $commentModel->add($data);

        $data = array (
            'code'       => 0,
            'message'       => '&#x53d1;&#x8868;&#x6210;&#x529f;'
        );

        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}elseif($a == 'toupiao'){

    $pk_id = junhua_I('pk_id/d', 0);
    $type  = junhua_I('t/d', 0);

    if(IS_AJAX){

        if(!in_array($type, array(1,2))){
            $data = array(
                'message'       => '&#x6570;&#x636e;&#x5f02;&#x5e38;'
            );

            junhua_ajaxReturn($data);
        }

        if(!$uid){
            $data = array(
                'code'    => 1,
                'message' => '&#x8bf7;&#x5148;&#x767b;&#x5f55;'
            );

            junhua_ajaxReturn($data);
        }

        //&#x83b7;&#x53d6;&#x89c2;&#x70b9;
        $pkingInfo = $PkingModel->find(array('user_id' => $uid, 'pk_id' => $pk_id));

        if($pkingInfo){
            $data = array(
                'message'       => '&#x60a8;&#x5df2;&#x53c2;&#x4e0e;&#x6295;&#x7968;'
            );

            junhua_ajaxReturn($data);
        }

        $pkInfo = $pkModel->find(array('pk_id' => $pk_id));

        if(!$pkInfo){
            $data = array(
                'message'       => '&#x6570;&#x636e;&#x5f02;&#x5e38;'
            );

            junhua_ajaxReturn($data);
        }

        if($pkInfo['end_time'] > 0 && $pkInfo['end_time'] < $_G['timestamp']){
            $data = array(
                'message'       => '&#x6295;&#x7968;&#x5df2;&#x622a;&#x6b62;'
            );

            junhua_ajaxReturn($data);
        }


        $data = array(
            'pk_id'    => $pk_id,
            'user_id'  => $uid,
            'pk_type'  => $type,
            'add_time' => $_G['timestamp'],
        );

        if($type == 1){
            $pkModel->setInc(array('pk_id' => $pk_id), 'pk_zfnum');
        }else{
            $pkModel->setInc(array('pk_id' => $pk_id), 'pk_ffnum');
        }
        
        $PkingModel->add($data);

        $data = array (
            'code'       => 0,
        );

        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}elseif($a == 'top'){

    $cid = junhua_I('cid/d', 0);
    if(IS_AJAX){

        if(!in_array($uid, $gangbazi_uids)){
            $data = array(
                'message'       => '&#x6743;&#x9650;&#x4e0d;&#x8db3;'
            );

            junhua_ajaxReturn($data);
        }

        $commmentInfo = $commentModel->find(array('comment_id' => $cid));

        if(!$commmentInfo){
            $data = array(
                'message'       => '&#x6570;&#x636e;&#x4e0d;&#x5b58;&#x5728;'
            );

            junhua_ajaxReturn($data);
        }

        $commentModel->save(array('comment_id' => $cid), array('is_top' => ($commmentInfo['is_top'] ? 0 : 1)));

        $data = array (
            'code'       => 1,
            'message'    => '&#x66f4;&#x6539;&#x6210;&#x529f;'
        );

        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}elseif($a == 'del'){

    $cid = junhua_I('cid/d', 0);
    if(IS_AJAX){

        if(!in_array($uid, $gangbazi_uids)){
            $data = array(
                'message'       => '&#x6743;&#x9650;&#x4e0d;&#x8db3;'
            );

            junhua_ajaxReturn($data);
        }

        $commmentInfo = $commentModel->find(array('comment_id' => $cid));

        if(!$commmentInfo){
            $data = array(
                'message'       => '&#x6570;&#x636e;&#x4e0d;&#x5b58;&#x5728;'
            );

            junhua_ajaxReturn($data);
        }

        $commentModel->delete(array('comment_id' => $cid));

        $data = array (
            'code'       => 1,
            'message'    => '&#x5220;&#x9664;&#x6210;&#x529f;'
        );

        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}elseif($a == 'like'){

    $cid = junhua_I('cid/d', 0);

    if(IS_AJAX){

        if(!$uid){
            $data = array(
                'code'    => 1,
                'message' => '&#x8bf7;&#x5148;&#x767b;&#x5f55;'
            );

            junhua_ajaxReturn($data);
        }

        //&#x83b7;&#x53d6;&#x89c2;&#x70b9;
        $commentInfo = $commentModel->find(array('comment_id' => $cid));
        if(!$commentInfo){
            $data = array(
                'message'       => '&#x6570;&#x636e;&#x5f02;&#x5e38;'
            );

            junhua_ajaxReturn($data);
        }


        $likeInfo = $likeModel->find(array('comment_id' => $cid, 'pk_id' => $commentInfo['pk_id'], 'user_id' => $uid));

        if($likeInfo){
            $unlike = 1;
            $likeModel->delete(array('like_id' => $likeInfo['like_id'], 'user_id' => $uid));
            $commentModel->setDec(array('comment_id' => $cid), 'like_num');
        }else{
            $unlike = 0;
            $likeModel->add(array('comment_id' => $cid, 'pk_id' => $commentInfo['pk_id'], 'user_id' => $uid, 'add_time' => $_G['timestamp']));
            $commentModel->setInc(array('comment_id' => $cid), 'like_num');
        }

        $data = array (
            'code'       => 0,
            'unlike'       => $unlike,
        );

        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}

else{
	exit;
}