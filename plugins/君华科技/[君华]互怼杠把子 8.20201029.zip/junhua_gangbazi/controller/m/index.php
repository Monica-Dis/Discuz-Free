<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!in_array($a, array('index', 'detail', 'minindex'))){
    $a = 'index';
}


$pkModel = new junhua_model('GangbaziPk');
$commentModel = new junhua_model('GangbaziComment');
$pkingModel = new junhua_model('GangbaziPking');
$likeModel = new junhua_model('GangbaziLike');

$refererurl = $_G['siteurl'] . 'plugin.php?'.$_SERVER['QUERY_STRING'];

//&#x76f4;&#x63a5;&#x8df3;&#x8f6c;&#x5230;&#x4e0b;&#x8f7d;&#x9875;
if(!IS_MAGA && $junhua_gangbazi_setting['gangbazi_nomagadownload_open'] == 1){
    dheader('location:' . $junhua_base_config['app_download_url']);
    exit;
}

//&#x5f00;&#x542f;&#x5206;&#x4eab;
if($junhua_gangbazi_setting['gangbazi_weixin_share_open'] == 1 && IS_WEIXIN){
    include_once('source/plugin/junhua_base/jssdk/weixin_jssdk.php');
    $jssdk = new WEIXIN_JSSDK($junhua_base_config['weixin_appid'], $junhua_base_config['weixin_appsecret']);
    $signPackage = $jssdk->GetSignPackage();
}


if($a == 'index'){
    //&#x83b7;&#x53d6;&#x804a;&#x5929;
    $pkList = $pkModel->select(array('is_enable' => 1), '*', 'pk_id desc', 0, 10);

    foreach ($pkList as $key => $value) {
        $Total = $value['pk_zfnum'] + $value['pk_ffnum'];

        if($Total == 0){
            $ZPercent = 50;
            $FPercent = 50;
        }else{
            $ZPercent = ceil($value['pk_zfnum']/$Total * 100);
            $FPercent = ceil($value['pk_ffnum']/$Total * 100);
        }

        $pkList[$key]['ZPercent'] = $ZPercent;
        $pkList[$key]['FPercent'] = $FPercent;

        //&#x83b7;&#x53d6;&#x591a;&#x5c11;&#x54c1;&#x8bba;&#x6570;

        $count = $commentModel->count(array('pk_id' => $value['pk_id']));
        $pkList[$key]['count'] = $count;

    }

    if($junhua_gangbazi_setting['gangbazi_indexlist_style'] == 1){
        $a = 'wyindex';
    }

}elseif($a == 'minindex'){
    //&#x83b7;&#x53d6;&#x804a;&#x5929;
    $pid = junhua_I('pid/d', 0);
    $pkInfo = $pkModel->find(array('is_enable' => 1, 'pk_id' => $pid));

    if(!$pkInfo){
        dheader('location:' . junhua_url('m/index/index', '', true));
        exit;
    }

    //&#x83b7;&#x53d6;&#x804a;&#x5929;
    $pkingInfo = $pkingModel->find(array('pk_id' => $pid, 'user_id' => $uid));

    $Total = $pkInfo['pk_zfnum'] + $pkInfo['pk_ffnum'];

    if($Total == 0){
        $ZPercent = 50;
        $FPercent = 50;
    }else{
        $ZPercent = ceil($pkInfo['pk_zfnum']/$Total * 100);
        $FPercent = ceil($pkInfo['pk_ffnum']/$Total * 100);
    }

    $pkInfo['ZPercent'] = $ZPercent;
    $pkInfo['FPercent'] = $FPercent;

    //&#x83b7;&#x53d6;&#x591a;&#x5c11;&#x54c1;&#x8bba;&#x6570;

    $count = $commentModel->count(array('pk_id' => $pkInfo['pk_id']));
    $pkInfo['count'] = $count;


    $a = 'wyindexmin';

}elseif($a == 'detail'){


    //&#x83b7;&#x53d6;&#x9a6c;&#x7532;&#x767b;&#x5f55;
    if(IS_MAGA && !$uid){

        $magaurl        = $junhua_base_config['maga_url'];
        $maga_appsecret = $junhua_base_config['maga_appsecret'];

        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $info      = strstr($userAgent, "MAGAPPX");
        $info      = explode("|",$info);
        $token     = $info[7];

        $appurl = $magaurl.'/mag/cloud/cloud/getUserInfo?token='.$token.'&secret='.$maga_appsecret;
        $appdata = dfsockopen($appurl);
        if (!$appdata) {
            $appdata = file_get_contents($appurl);
        }
        $r =  json_decode($appdata, true);
        if($r['data']['user_id'] > 0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }

            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
        }
    }


    $pid = junhua_I('pid/d', 0);

    $where = array(
        'pk_id'     => $pid,
        'is_enable' => 1,
    );

    $pkInfo = $pkModel->find($where);

    if(!$pkInfo){
        dheader('location:' . junhua_url('m/index/index', '', true));
        exit;
    }

    $pkInfo['pk_zfbtn_name'] = $pkInfo['pk_zfbtn_name'] ? $pkInfo['pk_zfbtn_name'] : '&#x6295;&#x7968;';
    $pkInfo['pk_ffbtn_name'] = $pkInfo['pk_ffbtn_name'] ? $pkInfo['pk_ffbtn_name'] : '&#x6295;&#x7968;';
    $pkInfo['pk_zftybtn_name'] = $pkInfo['pk_zftybtn_name'] ? $pkInfo['pk_zftybtn_name'] : '&#x5df2;&#x6295;&#x7968;';
    $pkInfo['pk_fftybtn_name'] = $pkInfo['pk_fftybtn_name'] ? $pkInfo['pk_fftybtn_name'] : '&#x5df2;&#x6295;&#x7968;';

    //&#x83b7;&#x53d6;&#x804a;&#x5929;
    $commentList = $commentModel->select($where, '*', 'is_top desc, comment_id desc', 0, 10);

    //&#x83b7;&#x53d6;&#x804a;&#x5929;
    $pkingInfo = $pkingModel->find(array('pk_id' => $pid, 'user_id' => $uid));

    //&#x83b7;&#x53d6;&#x70b9;&#x8d5e;&#x5217;&#x8868;
    $likeList = $likeModel->select(array('pk_id' => $pid, 'user_id' => $uid), 'comment_id', '', 0, 0 , true);

    //&#x67e5;&#x8be2;&#x6b63;&#x65b9;&#x6570;&#x91cf;
    $Total = $pkInfo['pk_zfnum'] + $pkInfo['pk_ffnum'];

    if($Total == 0){
        $ZPercent = 50;
        $FPercent = 50;
    }else{
        $ZPercent = ceil($pkInfo['pk_zfnum']/$Total * 100);
        $FPercent = ceil($pkInfo['pk_ffnum']/$Total * 100);
    }

}
else{
	exit;
}

$block_content = 'junhua_gangbazi:m/index/'.$a;
include template($block_content);
