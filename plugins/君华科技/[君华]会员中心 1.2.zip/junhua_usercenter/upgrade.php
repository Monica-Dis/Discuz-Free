<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql['1.1'] = 'ALTER TABLE `pre_junhua_usercenter_config` ADD COLUMN `grids_open`  tinyint(1) DEFAULT 0 AFTER `nav_open`';

foreach($sql as $key => $value) {
    if($_GET['fromversion'] < $key) {
        runquery($value);
    }
}

$finish = true;