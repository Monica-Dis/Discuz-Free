<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once('source/plugin/junhua_usercenter/mp_auth.php');


include_once('source/plugin/junhua_editor/filemanger.class.php');

$filemanger = new Junhua_editor_filemanger('source/plugin/junhua_usercenter', 'source/plugin/junhua_usercenter');

if(!in_array($action, array('index', 'file_manager', 'upload'))){
    $action = 'index';
}

if($action == 'index'){
	header('location: '.junhua_url('mp/nav/index', '', true));
	exit;
}elseif($action == 'upload'){
	$filemanger->uploadJson();
	exit;
}elseif($action == 'file_manager'){
	$filemanger->filemanger();
	exit;
}