$.validator.setDefaults({
    highlight: function (element) {
        $(element).closest('.form-group').addClass('has-error');
    },
    success: function (element) {
        element.closest('.form-group').removeClass('has-error');
    },
    errorElement: "span",
    errorPlacement: function (error, element) {
        if (element.is(":radio") || element.is(":checkbox")) {
            error.appendTo(element.parent().parent().parent());
        } else {
            error.appendTo(element.parent());
        }
    },
    errorClass: "help-block m-b-none error",
});

$.validator.addMethod("isMobile", function(value, element) {
    var length = value.length;
    var mobile = /^(1[35789][0-9]{9})$/;
    return this.optional(element) || (length == 11 && mobile.test(value));
}, "&#x8bf7;&#x6b63;&#x786e;&#x586b;&#x5199;&#x60a8;&#x7684;&#x624b;&#x673a;&#x53f7;&#x7801;");
$.validator.addMethod("isUrl", function(value, element) {
    var length = value.length;
    var url = /^(http|https):\/\/[A-Za-z0-9]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\':+!]*([^<>\"\"])*$/;
    return this.optional(element) || (url.test(value));
}, "&#x8bf7;&#x586b;&#x5199;&#x6b63;&#x786e;&#x7684;&#x7f51;&#x5740;");

$.validator.addMethod("isPrice", function(value, element) {
    var length = value.length;
    var url = /(^[1-9]\d*(\.\d{1,2})?$)|(^[0]{1}(\.\d{1,2})?$)/;
    return this.optional(element) || (url.test(value));
}, "&#x8bf7;&#x586b;&#x5199;&#x6b63;&#x786e;&#x7684;&#x4ef7;&#x683c;");

$.validator.addMethod("isInt", function(value, element) {
    var length = value.length;
    var int = /^-?(\d+)?$/;
    return this.optional(element) || (int.test(value));
}, "&#x8bf7;&#x586b;&#x5199;&#x6b63;&#x786e;&#x7684;&#x6574;&#x6570;");
