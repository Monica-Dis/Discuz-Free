$(function(){

	//&#x6a21;&#x677f;
	var tpl={
		textHtml:$("#tpl_material_text").html()
	};

	//&#x6e32;&#x67d3;&#x6587;&#x672c;&#x9884;&#x89c8;&#x89c6;&#x56fe;
	var reRenderMaterial_Text = function(data){
		if(!data.length) return;
		var html=_.template(tpl.textHtml,{content:data});//&#x6e32;&#x67d3;&#x6a21;&#x677f;
		$("#j-materialPrev").empty().append(html);//&#x63d2;&#x5165;dom
	}


	//&#x7f16;&#x8f91;&#x5668;
    KindEditor.ready(function(K) {
        var editor = K.create('textarea[name="content"]', {
            items : ['link','unlink'],
            afterBlur: function(){
                this.sync();
            },
            afterChange : function() {
                reRenderMaterial_Text(this.html())
            }

        });
    });



})