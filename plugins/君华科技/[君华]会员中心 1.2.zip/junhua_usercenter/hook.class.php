<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

class junhua_usercenter_core {
	public $usercenterConfig = null;
	public function __construct() {
		$configModel = C::t('#junhua_usercenter#junhua_usercenter_config');
		$this->usercenterConfig = $configModel->find(array('config_id' => 1));

	}
}

class mobileplugin_junhua_usercenter extends junhua_usercenter_core {

    function common(){
    	global $_G;

		if($this->usercenterConfig['nav_open'] == 1){
			if($_GET['mod'] == 'space' && $_GET['do'] == 'profile'){
				if($_G['uid'] == $_GET['uid'] || !isset($_GET['uid'])){
					header("location:plugin.php?id=junhua_usercenter:m_home");
					exit;
				}
			}
		}
    }
}
