<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once('source/plugin/junhua_usercenter/mp_auth.php');

if(!in_array($action, array('index'))){
    $action = 'index';
}
$configModel = C::t('#junhua_usercenter#junhua_usercenter_config');

if($action == 'index'){
    $configInfo = $configModel->find(array('config_id' => 1));
    if(IS_AJAX){
        $nav_open = junhua_I('nav_open');
        $grids_open = junhua_I('grids_open');

        $data = array(
            'nav_open' => $nav_open,
            'grids_open' => $grids_open,
        );

        $configModel->save(array('config_id' => 1), $data);

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x4fdd;&#x5b58;&#x6210;&#x529f;'));

    }
}

$block_content = 'junhua_usercenter:mp/system/'.$action;

include template('junhua_usercenter:mp/layout');
