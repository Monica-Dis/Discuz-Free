<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once('source/plugin/junhua_usercenter/class/model.class.php');
class table_junhua_usercenter_config extends junhua_usercenter_model
{
	public function __construct() {
		$this->_table = 'junhua_usercenter_config';
		$this->_pk = 'config_id';
		parent::__construct();
	}
}