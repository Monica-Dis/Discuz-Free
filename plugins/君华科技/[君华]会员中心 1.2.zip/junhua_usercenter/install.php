<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$createtablesql = <<<EOF

DROP TABLE IF EXISTS `pre_junhua_usercenter_nav`;
CREATE TABLE `pre_junhua_usercenter_nav` (
  `nav_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nav_name` varchar(128) DEFAULT '',
  `nav_href` varchar(128) DEFAULT '',
  `nav_icon` varchar(128) DEFAULT '',
  `nav_color` varchar(32) DEFAULT '',
  `order_num` int(10) DEFAULT '0',
  `plugin_name` varchar(64) DEFAULT '',
  `is_enable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`nav_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


DROP TABLE IF EXISTS `pre_junhua_usercenter_config`;
CREATE TABLE `pre_junhua_usercenter_config` (
  `config_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `adminscript` varchar(128) DEFAULT '',
  `nav_open` tinyint(1) DEFAULT '0',
  `grids_open` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`config_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


INSERT INTO `pre_junhua_usercenter_config` (`config_id`, `adminscript`, `nav_open`, `grids_open`) VALUES ('1', 'admin.php', '1', '0');

INSERT INTO `pre_junhua_usercenter_nav` (`nav_name`, `nav_href`, `nav_icon`, `nav_color`, `order_num`, `is_enable`) VALUES ('&#x6211;&#x7684;&#x6536;&#x85cf;', 'home.php?mod=space&do=favorite&view=me&type=thread', 'source/plugin/junhua_usercenter/static/m/img/favorite.png', '', '0', '1');
INSERT INTO `pre_junhua_usercenter_nav` (`nav_name`, `nav_href`, `nav_icon`, `nav_color`, `order_num`, `is_enable`) VALUES ('&#x6211;&#x7684;&#x4e3b;&#x9898;', 'home.php?mod=space&do=thread&view=me', 'source/plugin/junhua_usercenter/static/m/img/me.png', '', '0', '1');
INSERT INTO `pre_junhua_usercenter_nav` (`nav_name`, `nav_href`, `nav_icon`, `nav_color`, `order_num`, `is_enable`) VALUES ('br', '', '', '', '0', '1');
INSERT INTO `pre_junhua_usercenter_nav` (`nav_name`, `nav_href`, `nav_icon`, `nav_color`, `order_num`, `is_enable`) VALUES ('&#x6211;&#x7684;&#x6d88;&#x606f;', 'home.php?mod=space&do=pm', 'source/plugin/junhua_usercenter/static/m/img/pm.png', '', '0', '1');
INSERT INTO `pre_junhua_usercenter_nav` (`nav_name`, `nav_href`, `nav_icon`, `nav_color`, `order_num`, `is_enable`) VALUES ('&#x6211;&#x7684;&#x8d44;&#x6599;', 'home.php?mod=space', 'source/plugin/junhua_usercenter/static/m/img/info.png', '', '0', '1');



EOF;

runquery($createtablesql);
$finish = TRUE;
?>