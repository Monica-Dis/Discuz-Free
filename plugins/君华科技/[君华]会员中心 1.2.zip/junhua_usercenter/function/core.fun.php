<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


/**
&#x6ce8;&#xff1a;strtolower(CHARSET) == 'gbk'  &#x4e3a;&#x4ec0;&#x4e48;&#x52a0;&#x4e0a;&#x6b64;&#x5224;&#x65ad;&#xff0c;&#x662f;&#x4e3a;&#x4e86;&#x8ba9;&#x5e38;&#x91cf;&#x5224;&#x65ad;&#x4e00;&#x5b9a;&#x6b63;&#x786e;
&#x5f53;&#x7136;&#x6b64;&#x5904;&#x4e5f;&#x662f;&#x6a21;&#x4eff;dz&#x6838;&#x5fc3;&#x51fd;&#x6570; dhtmlspecialchars dstrlen cutstr &#x7b49;&#x51fd;&#x6570;&#x4e2d;&#x4e5f;&#x662f;&#x4e3a;&#x4e86;&#x5224;&#x65ad;&#x7684;&#x51c6;&#x786e;&#x6027; &#x52a0;&#x5165;&#x4e86;&#x6b64;&#x5224;&#x65ad;
 */


/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4e3a;&#x4e86;&#x5728;&#x63d2;&#x4ef6;&#x4e2d;&#x5206;&#x6790;&#x548c;&#x751f;&#x6210;url&#x94fe;&#x63a5;&#x3002;
 */

if(!function_exists('junhua_url')){
    function junhua_url($url, $param = '', $isreturn = false){
        $ary = explode('/', $url);
        $url = 'plugin.php?id='.CURMODULE.':'.$ary[0].'_'.$ary[1].'&a='.$ary[2].($param ? '&'.$param : '');
        if($isreturn){
            return $url;
        }else{
            echo $url;
        }
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4e3a;&#x4e86;&#x8f93;&#x51fa;&#x6807;&#x51c6;json&#x683c;&#x5f0f;
 */

if(!function_exists('junhua_ajaxReturn')){
    function junhua_ajaxReturn($data,$type='',$json_option=0) {
        header('Content-Type:application/json; charset=utf-8');
        exit(junhua_json_encode($data,$json_option));
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4e3a;&#x4e86;&#x8f93;&#x51fa;&#x6807;&#x51c6;json&#x683c;&#x5f0f;&#xff0c;&#x56e0;&#x4e3a;&#x5728;gbk&#x6a21;&#x5f0f;&#x4e0b; json&#x5305;&#x542b;&#x4e2d;&#x6587;&#x4f1a;&#x51fa;&#x9519;
 * &#x6545;&#x91cd;&#x5199;json_encode,&#x89e3;&#x51b3;&#x529e;&#x6cd5;&#x5c31;&#x662f;&#x628a;&#x6570;&#x636e;&#x52a0;&#x4e0a;&#x8fc7;&#x6ee4;&#x5668;junhua_gbk2utf8 &#x5982;&#x5b57;&#x9762;&#x610f;&#x601d;&#x5c31;&#x662f;&#x628a;gbk&#x6a21;&#x5f0f;&#x8f6c;&#x4e3a;utf8&#x4e4b;&#x540e;&#x518d;&#x8fd4;&#x56de;json
 */

if(!function_exists('junhua_json_encode')){
    function junhua_json_encode($data, $json_option=0){
        $ret = array();
        if (strtolower(CHARSET) == 'gbk') {
            $ret = junhua_array_map('junhua_gbk2utf8', $data);
        }else{
            $ret = $data;
        }
        return json_encode($ret, $json_option);
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4e3a;&#x4e86;&#x628a;gbk&#x8f6c;&#x6362;&#x6210;utf8 &#xff0c;&#x672c;&#x53ef;&#x4ee5;&#x4f7f;&#x7528;diconv &#x81ea;&#x5e26;&#x51fd;&#x6570;&#xff0c;
 * &#x4f46;&#x56e0;&#x4e3a;&#x9700;&#x8981;&#x642d;&#x914d;junhua_array_map&#x51fd;&#x6570;&#xff0c;&#x4e14;&#x6b64;&#x51fd;&#x6570;&#x8bbe;&#x8ba1;&#x4e3a;&#x6ca1;&#x6cd5;&#x6dfb;&#x52a0;&#x53c2;&#x6570;&#x6a21;&#x5f0f;&#xff0c;&#x6240;&#x4ee5;&#x624d;&#x521b;&#x5efa;&#x6b64;&#x51fd;&#x6570;
 */

if(!function_exists('junhua_gbk2utf8')){
    function junhua_gbk2utf8($pram){
        if (strtolower(CHARSET) == 'gbk') {
            return diconv($pram, 'gbk', 'utf-8');
        }else{
            return $pram;
        }
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4e3a;&#x4e86;&#x628a;utf8 &#x8f6c;&#x6362;&#x6210;gbk&#xff0c;&#x672c;&#x53ef;&#x4ee5;&#x4f7f;&#x7528;diconv &#x81ea;&#x5e26;&#x51fd;&#x6570;&#xff0c;
 * &#x4f46;&#x56e0;&#x4e3a;&#x9700;&#x8981;&#x642d;&#x914d;junhua_array_map&#x51fd;&#x6570;&#xff0c;&#x4e14;&#x6b64;&#x51fd;&#x6570;&#x8bbe;&#x8ba1;&#x4e3a;&#x6ca1;&#x6cd5;&#x6dfb;&#x52a0;&#x53c2;&#x6570;&#x6a21;&#x5f0f;&#xff0c;&#x6240;&#x4ee5;&#x624d;&#x521b;&#x5efa;&#x6b64;&#x51fd;&#x6570;&#x3002;
 */

if(!function_exists('junhua_utf82gbk')){
    function junhua_utf82gbk($pram){
        return diconv($pram, 'utf-8');
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4f5c;&#x7528;&#x4e3a;&#x83b7;&#x53d6;&#x63d0;&#x4ea4;&#x7684;&#x53c2;&#x6570;&#xff0c;&#x672c;&#x76f4;&#x63a5;&#x53ef;&#x4ee5;&#x7528;$_GET&#x65b9;&#x5f0f;&#x83b7;&#x53d6;&#x3002;
 * &#x5c01;&#x88c5;&#x7406;&#x7531;&#x4e3a;&#x5728;gbk&#x6a21;&#x5f0f;&#x4e0b;&#xff0c;&#x5982;&#x679c;&#x63d0;&#x4ea4;&#x7684;&#x662f;utf8&#x7684;&#x683c;&#x5f0f;&#x7684;&#x6570;&#x636e;&#xff0c;&#x90a3;&#x4e48;&#x6570;&#x636e;&#x5c06;&#x4f1a;&#x5168;&#x90e8;&#x53d8;&#x4e3a;&#x4e71;&#x7801;&#xff0c;&#x6545;&#x800c;&#x589e;&#x52a0;&#x8fc7;&#x6ee4;&#x5668;&#x6765;&#x89e3;&#x51b3;&#x6b64;&#x95ee;&#x9898;&#x3002;
 */

if(!function_exists('junhua_I')){
    function junhua_I($name){
        if (strtolower(CHARSET) == 'gbk') {
            $_GET[$name] = is_array($_GET[$name]) ? junhua_array_map('junhua_utf82gbk', $_GET[$name]) : junhua_utf82gbk($_GET[$name]);
            return $_GET[$name];
        }else{
            return $_GET[$name];
        }
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4f5c;&#x7528;&#x4e3a;&#x8fc7;&#x6ee4;&#x5668;&#x51fd;&#x6570;
 */

if(!function_exists('junhua_array_map')){
    function junhua_array_map($filter, $data) {
        $result = array();
        foreach ($data as $key => $val) {
            $result[$key] = is_array($val) ? junhua_array_map($filter, $val) : call_user_func($filter, $val);
        }
        return $result;
    }
}