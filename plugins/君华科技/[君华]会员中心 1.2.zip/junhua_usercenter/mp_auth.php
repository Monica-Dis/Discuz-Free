<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_G['adminid'] != 1){
    showmessage('&#x60a8;&#x65e0;&#x6743;&#x9650;&#x64cd;&#x4f5c;&#xff0c;&#x4ec5;&#x7ba1;&#x7406;&#x5458;&#x53ef;&#x64cd;&#x4f5c;&#xff01;', $_G['siteurl'], array(), array('refreshtime' => 5));
}

include_once('source/plugin/junhua_usercenter/common.php');
include_once('source/plugin/junhua_usercenter/function/core.fun.php');

$a = junhua_I('a');

if(!empty($a)) {
	$action = $action !== NULL ? $action : 	$a;
}

if((IS_POST || IS_AJAX) && junhua_I('formhash') != FORMHASH){
	exit;
}

$_G['mobiletpl'][IN_MOBILE]='/';
