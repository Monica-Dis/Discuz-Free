<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once('source/plugin/junhua_usercenter/m_auth.php');

if(!in_array($action, array('index'))){
    $action = 'index';
}
$navModel		= C::t('#junhua_usercenter#junhua_usercenter_nav');
$configModel = C::t('#junhua_usercenter#junhua_usercenter_config');

if($action == 'index'){

	$navList = $navModel->select(array('is_enable' => 1), '*', 'order_num desc, nav_id desc');
    $configInfo = $configModel->find(array('config_id' => 1));

    $block_head_title = '&#x4f1a;&#x5458;&#x4e2d;&#x5fc3;';
    $block_title = '&#x4f1a;&#x5458;&#x4e2d;&#x5fc3;';

    if($configInfo['grids_open'] == 1){
    	$action = 'grids';
    }
}


$block_content = 'junhua_usercenter:m/home/'.$action;

include template('junhua_usercenter:m/layout');
