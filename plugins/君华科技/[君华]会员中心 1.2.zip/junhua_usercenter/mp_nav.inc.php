<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once('source/plugin/junhua_usercenter/mp_auth.php');

if(!in_array($action, array('index', 'add', 'edit', 'del', 'set'))){
    $action = 'index';
}
$navModel = C::t('#junhua_usercenter#junhua_usercenter_nav');

if($action == 'index'){
    $page = empty($_GET['page']) ? 1 : intval($_GET['page']);
    $perpage = 10;
    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;


    $theurl = junhua_url('mp/nav/index', '', true);

    $where = array();

    $totalRows = $navModel->count($where);

    if($totalRows) {
        $multi = multi($totalRows, $perpage, $page, $theurl);
    }

    $lists = $navModel->select($where, '*', 'order_num desc, nav_id desc', $start, $perpage);

    $block_head_title = '&#x5bfc;&#x822a;&#x7ba1;&#x7406;';
    $block_title = '&#x94fe;&#x63a5;&#x5217;&#x8868;';
    $block_css = '';

}elseif($action == 'add'){

    if(IS_AJAX){
        $nav_name  = junhua_I('nav_name');
        $nav_href  = junhua_I('nav_href');
        $nav_icon  = junhua_I('nav_icon');
        $nav_color = junhua_I('nav_color');
        $order_num  = intval(junhua_I('order_num'));

        $data = array(
            'nav_name'  => $nav_name,
            'nav_href'  => $nav_href,
            'nav_icon'  => $nav_icon,
            'nav_color' => $nav_color,
            'order_num'  => $order_num,
            'is_enable' => 0,
        );

        $navId = $navModel->add($data);

        if($navId){
            junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x4fdd;&#x5b58;&#x6210;&#x529f;', 'url' => junhua_url('mp/nav/index', '', 1)));
        }else{
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x4fdd;&#x5b58;&#x5931;&#x8d25;'));
        }
    }

    $block_head_title = '&#x5bfc;&#x822a;&#x7ba1;&#x7406;';
    $block_title = '&#x65b0;&#x589e;&#x5bfc;&#x822a;';

    $action = 'update';

}elseif($action == 'edit'){

    $nid = junhua_I('nid');
    $nid = intval($nid);

    $navInfo = $navModel->find(array('nav_id' => $nid));

    if(!$navInfo){
        header('location: '.junhua_url('mp/nav/index', '', true));
        exit;
    }


    if(IS_AJAX){
        $nav_name  = junhua_I('nav_name');
        $nav_href  = junhua_I('nav_href');
        $nav_icon  = junhua_I('nav_icon');
        $nav_color = junhua_I('nav_color');
        $order_num  = intval(junhua_I('order_num'));

        $data = array(
            'nav_name'  => $nav_name,
            'nav_href'  => $nav_href,
            'nav_icon'  => $nav_icon,
            'nav_color' => $nav_color,
            'order_num'  => $order_num,
        );

        $navId = $navModel->save(array('nav_id' => $navInfo['nav_id']), $data);

        if($navId){
            junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x4fdd;&#x5b58;&#x6210;&#x529f;', 'url' => junhua_url('mp/nav/index', '', 1)));
        }else{
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x4fdd;&#x5b58;&#x5931;&#x8d25;'));
        }
    }

    $block_head_title = '&#x5bfc;&#x822a;&#x7ba1;&#x7406;';
    $block_title = '&#x7f16;&#x8f91;&#x5bfc;&#x822a;';

    $action = 'update';

}elseif($action == 'del'){
    if(IS_AJAX){
        $nid = intval(junhua_I('nid'));

        $where = array(
            'nav_id'      => $nid
        );

        $navInfo = $navModel->find($where);
        if(!$navInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $navModel->delete($where);

        junhua_ajaxReturn(array('status' => 1));
    }

}elseif($action == 'set'){
    if(IS_AJAX){
        $nid = intval(junhua_I('nid'));

        $where = array(
            'nav_id'      => $nid
        );

        $navInfo = $navModel->find($where);
        if(!$navInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($navInfo['is_enable'] == 1){
            $is_enable = 0;
        }else{
            $is_enable = 1;
        }

        if($navModel->save($where, array('is_enable' => $is_enable))){
            junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x8bbe;&#x7f6e;&#x6210;&#x529f;&#xff01;'));
        }else{
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;&#xff0c;&#x8bf7;&#x7a0d;&#x540e;&#x518d;&#x8bd5;&#xff01;'));
        }
    }

}


$block_content = 'junhua_usercenter:mp/nav/'.$action;

include template('junhua_usercenter:mp/layout');
