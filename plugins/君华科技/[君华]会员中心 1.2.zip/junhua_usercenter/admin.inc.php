<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//&#x5224;&#x65ad;&#x6743;&#x9650;
if($_G['adminid'] != 1){
	cpmsg('&#x60a8;&#x65e0;&#x6743;&#x9650;&#x64cd;&#x4f5c;&#xff0c;&#x4ec5;&#x7ba1;&#x7406;&#x5458;&#x53ef;&#x64cd;&#x4f5c;&#xff01;', $_G['siteurl'], 'error');
}

if(!in_array('junhua_editor', $_G['setting']['plugins']['available'])) {
	cpmsg('&#x672c;&#x63d2;&#x4ef6;&#x4f9d;&#x8d56;[&#x7f16;&#x8f91;&#x5668;]&#x63d2;&#x4ef6;&#xff0c;&#x8bf7;&#x70b9;&#x51fb;&#x4e0b;&#x8f7d;&#x5b89;&#x88c5;&#xff0c;&#x5df2;&#x4e0b;&#x8f7d;&#x7528;&#x6237;&#x8bf7;&#x5f00;&#x542f;&#x3002;', 'action=cloudaddons&id=junhua_editor.plugin', 'error');
}

$configModel = C::t('#junhua_usercenter#junhua_usercenter_config');
$configModel->save(array('config_id' => 1), array('adminscript' => ADMINSCRIPT));

header("location: plugin.php?id=junhua_usercenter:mp_admin");
exit;