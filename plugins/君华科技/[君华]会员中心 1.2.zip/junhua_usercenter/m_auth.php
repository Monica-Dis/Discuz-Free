<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once('source/plugin/junhua_usercenter/common.php');
include_once('source/plugin/junhua_usercenter/function/core.fun.php');


$a = junhua_I('a');
if(!empty($a)) {
	$action = $action !== NULL ? $action : 	$a;
}

if((IS_POST || IS_AJAX) && junhua_I('formhash') != FORMHASH){
	exit;
}

//&#x5224;&#x65ad;&#x662f;&#x5426;&#x5df2;&#x7ecf;&#x767b;&#x5f55;
$uid = $_G['uid'];

if(empty($uid)) {
	header('location: member.php?mod=logging&action=login');
	exit;
}

$_G['mobiletpl'][IN_MOBILE]='/';
