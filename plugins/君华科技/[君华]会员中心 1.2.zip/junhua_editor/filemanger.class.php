<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class Junhua_editor_filemanger {

	public $php_url;
	public $save_path;
	public $save_url;
	public $ext_arr = array(
		'image' => array('gif', 'jpg', 'jpeg', 'png', 'bmp'),
		'flash' => array(),
		'media' => array(),
		'file' => array('doc', 'docx', 'xls', 'xlsx', 'ppt', 'zip', 'rar'),
	);

	//&#x6700;&#x5927;&#x6587;&#x4ef6;&#x5927;&#x5c0f;
	public $max_size = 10000000;

	public function __construct($php_url = 'source/plugin/junhua_editor', $save_path = 'source/plugin/junhua_editor'){

		$this->php_url = $php_url;
		$this->save_path = $save_path.'/upload/';
		//&#x68c0;&#x6d4b;&#x662f;&#x5426;&#x6709;&#x5546;&#x5bb6;&#x76ee;&#x5f55;
		if(!is_dir($this->save_path)){
			 mkdir($this->save_path);
		}
		$this->save_path = $this->save_path;
		$this->save_url = $this->php_url . '/upload/';
		$this->order = empty($_GET['order']) ? 'name' : strtolower($_GET['order']);
	}

	public function uploadJson($filename = 'imgFile', $type="ajax"){
		$this->save_path = realpath($this->save_path) . '/';

		//PHP&#x4e0a;&#x4f20;&#x5931;&#x8d25;
		if (!empty($_FILES[$filename]['error'])) {
			switch($_FILES[$filename]['error']){
				case '1':
					$error = '&#x8d85;&#x8fc7;php.ini&#x5141;&#x8bb8;&#x7684;&#x5927;&#x5c0f;&#x3002;';
					break;
				case '2':
					$error = '&#x8d85;&#x8fc7;&#x8868;&#x5355;&#x5141;&#x8bb8;&#x7684;&#x5927;&#x5c0f;&#x3002;';
					break;
				case '3':
					$error = '&#x56fe;&#x7247;&#x53ea;&#x6709;&#x90e8;&#x5206;&#x88ab;&#x4e0a;&#x4f20;&#x3002;';
					break;
				case '4':
					$error = '&#x8bf7;&#x9009;&#x62e9;&#x56fe;&#x7247;&#x3002;';
					break;
				case '6':
					$error = '&#x627e;&#x4e0d;&#x5230;&#x4e34;&#x65f6;&#x76ee;&#x5f55;&#x3002;';
					break;
				case '7':
					$error = '&#x5199;&#x6587;&#x4ef6;&#x5230;&#x786c;&#x76d8;&#x51fa;&#x9519;&#x3002;';
					break;
				case '8':
					$error = 'File upload stopped by extension&#x3002;';
					break;
				case '999':
				default:
					$error = '&#x672a;&#x77e5;&#x9519;&#x8bef;&#x3002;';
			}
			$this->alert($error);
		}

		//&#x6709;&#x4e0a;&#x4f20;&#x6587;&#x4ef6;&#x65f6;
		if (empty($_FILES) === false) {
			//&#x539f;&#x6587;&#x4ef6;&#x540d;
			$file_name = $_FILES[$filename]['name'];
			//&#x670d;&#x52a1;&#x5668;&#x4e0a;&#x4e34;&#x65f6;&#x6587;&#x4ef6;&#x540d;
			$tmp_name = $_FILES[$filename]['tmp_name'];
			//&#x6587;&#x4ef6;&#x5927;&#x5c0f;
			$file_size = $_FILES[$filename]['size'];
			//&#x68c0;&#x67e5;&#x6587;&#x4ef6;&#x540d;
			if (!$file_name) {
				$this->alert("&#x8bf7;&#x9009;&#x62e9;&#x6587;&#x4ef6;&#x3002;");
			}

			// $imginfo = uploadImg($filename);
			// $file_url = $imginfo['pic_url'];
			// goto a;
			//&#x68c0;&#x67e5;&#x76ee;&#x5f55;
			if (@is_dir($this->save_path) === false) {
				$this->alert("&#x4e0a;&#x4f20;&#x76ee;&#x5f55;&#x4e0d;&#x5b58;&#x5728;&#x3002;");
			}
			//&#x68c0;&#x67e5;&#x76ee;&#x5f55;&#x5199;&#x6743;&#x9650;
			if (@is_writable($this->save_path) === false) {
				$this->alert("&#x4e0a;&#x4f20;&#x76ee;&#x5f55;&#x6ca1;&#x6709;&#x5199;&#x6743;&#x9650;&#x3002;");
			}
			//&#x68c0;&#x67e5;&#x662f;&#x5426;&#x5df2;&#x4e0a;&#x4f20;
			if (@is_uploaded_file($tmp_name) === false) {
				$this->alert("&#x4e0a;&#x4f20;&#x5931;&#x8d25;&#x3002;");
			}
			//&#x68c0;&#x67e5;&#x6587;&#x4ef6;&#x5927;&#x5c0f;
			if ($file_size > $this->max_size) {
				$this->alert("&#x4e0a;&#x4f20;&#x6587;&#x4ef6;&#x5927;&#x5c0f;&#x8d85;&#x8fc7;&#x9650;&#x5236;&#x3002;");
			}
			//&#x68c0;&#x67e5;&#x76ee;&#x5f55;&#x540d;
			$dir_name = empty($_GET['dir']) ? 'image' : trim($_GET['dir']);
			if (empty($this->ext_arr[$dir_name])) {
				$this->alert("&#x76ee;&#x5f55;&#x540d;&#x4e0d;&#x6b63;&#x786e;&#x3002;");
			}
			//&#x83b7;&#x5f97;&#x6587;&#x4ef6;&#x6269;&#x5c55;&#x540d;
			$temp_arr = explode(".", $file_name);
			$file_ext = array_pop($temp_arr);
			$file_ext = trim($file_ext);
			$file_ext = strtolower($file_ext);
			//&#x68c0;&#x67e5;&#x6269;&#x5c55;&#x540d;
			if (in_array($file_ext, $this->ext_arr[$dir_name]) === false) {
				$this->alert("&#x4e0a;&#x4f20;&#x6587;&#x4ef6;&#x6269;&#x5c55;&#x540d;&#x662f;&#x4e0d;&#x5141;&#x8bb8;&#x7684;&#x6269;&#x5c55;&#x540d;&#x3002;\n&#x53ea;&#x5141;&#x8bb8;" . implode(",", $this->ext_arr[$dir_name]) . "&#x683c;&#x5f0f;&#x3002;");
			}
			//&#x521b;&#x5efa;&#x6587;&#x4ef6;&#x5939;
			if ($dir_name !== '') {
				$this->save_path .= $dir_name . "/";
				$this->save_url .= $dir_name . "/";
				if (!file_exists($this->save_path)) {
					mkdir($this->save_path);
				}
			}
			$ymd = date("Ymd");
			$this->save_path .= $ymd . "/";
			$this->save_url .= $ymd . "/";
			if (!file_exists($this->save_path)) {
				mkdir($this->save_path);
			}
			//&#x65b0;&#x6587;&#x4ef6;&#x540d;
			$new_file_name = date("YmdHis") . rand(10000, 99999) . '.' . $file_ext;
			//&#x79fb;&#x52a8;&#x6587;&#x4ef6;
			$file_path = $this->save_path . $new_file_name;
			if (move_uploaded_file($tmp_name, $file_path) === false) {
				$this->alert("&#x4e0a;&#x4f20;&#x6587;&#x4ef6;&#x5931;&#x8d25;&#x3002;");
			}
			@chmod($file_path, 0644);
			$file_url = $this->save_url . $new_file_name;

			// a:
			header('Content-type: text/html; charset=UTF-8');
			if($type == 'ajax'){
				echo json_encode(array('error' => 0, 'url' => $file_url));
				exit;
			}else{
				return $file_url;
			}

		}
	}

	public function alert($msg) {
		header('Content-type: text/html; charset=UTF-8');
		echo json_encode(array('error' => 1, 'message' => $msg));
		exit;
	}

	public function filemanger(){

		//&#x6839;&#x76ee;&#x5f55;&#x8def;&#x5f84;&#xff0c;&#x53ef;&#x4ee5;&#x6307;&#x5b9a;&#x7edd;&#x5bf9;&#x8def;&#x5f84;&#xff0c;&#x6bd4;&#x5982; /var/www/attached/
		$root_path = $this->save_path;
		//&#x6839;&#x76ee;&#x5f55;URL&#xff0c;&#x53ef;&#x4ee5;&#x6307;&#x5b9a;&#x7edd;&#x5bf9;&#x8def;&#x5f84;&#xff0c;&#x6bd4;&#x5982; http://www.yoursite.com/attached/
		$root_url = $this->save_url;
		
		//&#x76ee;&#x5f55;&#x540d;
		$dir_name = empty($_GET['dir']) ? '' : trim($_GET['dir']);
		if (!in_array($dir_name, array('', 'image', 'flash', 'media', 'file'))) {
			echo "Invalid Directory name.";
			exit;
		}
		if ($dir_name !== '') {
			$root_path .= $dir_name . "/";
			$root_url .= $dir_name . "/";
			if (!file_exists($root_path)) {
				mkdir($root_path);
			}
		}

		//&#x6839;&#x636e;path&#x53c2;&#x6570;&#xff0c;&#x8bbe;&#x7f6e;&#x5404;&#x8def;&#x5f84;&#x548c;URL
		if (empty($_GET['path'])) {
			$current_path = realpath($root_path) . '/';
			$current_url = $root_url;
			$current_dir_path = '';
			$moveup_dir_path = '';
		} else {
			$current_path = realpath($root_path) . '/' . $_GET['path'];
			$current_url = $root_url . $_GET['path'];
			$current_dir_path = $_GET['path'];
			$moveup_dir_path = preg_replace('/(.*?)[^\/]+\/$/', '$1', $current_dir_path);
		}
		//echo realpath($root_path);
		//&#x6392;&#x5e8f;&#x5f62;&#x5f0f;&#xff0c;name or size or type
		$order = empty($_GET['order']) ? 'name' : strtolower($_GET['order']);

		//&#x4e0d;&#x5141;&#x8bb8;&#x4f7f;&#x7528;..&#x79fb;&#x52a8;&#x5230;&#x4e0a;&#x4e00;&#x7ea7;&#x76ee;&#x5f55;
		if (preg_match('/\.\./', $current_path)) {
			echo 'Access is not allowed.';
			exit;
		}
		//&#x6700;&#x540e;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;&#x4e0d;&#x662f;/
		if (!preg_match('/\/$/', $current_path)) {
			echo 'Parameter is not valid.';
			exit;
		}
		//&#x76ee;&#x5f55;&#x4e0d;&#x5b58;&#x5728;&#x6216;&#x4e0d;&#x662f;&#x76ee;&#x5f55;
		if (!file_exists($current_path) || !is_dir($current_path)) {
			echo 'Directory does not exist.';
			exit;
		}

		//&#x904d;&#x5386;&#x76ee;&#x5f55;&#x53d6;&#x5f97;&#x6587;&#x4ef6;&#x4fe1;&#x606f;
		$file_list = array();
		if ($handle = opendir($current_path)) {
			$i = 0;
			while (false !== ($filename = readdir($handle))) {
				if ($filename{0} == '.') continue;
				$file = $current_path . $filename;
				if (is_dir($file)) {
					$file_list[$i]['is_dir'] = true; //&#x662f;&#x5426;&#x6587;&#x4ef6;&#x5939;
					$file_list[$i]['has_file'] = true;//(count(scandir($file)) > 2); //&#x6587;&#x4ef6;&#x5939;&#x662f;&#x5426;&#x5305;&#x542b;&#x6587;&#x4ef6;
					$file_list[$i]['filesize'] = 0; //&#x6587;&#x4ef6;&#x5927;&#x5c0f;
					$file_list[$i]['is_photo'] = false; //&#x662f;&#x5426;&#x56fe;&#x7247;
					$file_list[$i]['filetype'] = ''; //&#x6587;&#x4ef6;&#x7c7b;&#x522b;&#xff0c;&#x7528;&#x6269;&#x5c55;&#x540d;&#x5224;&#x65ad;
				} else {
					$file_list[$i]['is_dir'] = false;
					$file_list[$i]['has_file'] = false;
					$file_list[$i]['filesize'] = filesize($file);
					$file_list[$i]['dir_path'] = '';
					$file_ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
					$file_list[$i]['is_photo'] = in_array($file_ext, $this->ext_arr['image']);
					$file_list[$i]['filetype'] = $file_ext;
				}
				$file_list[$i]['filename'] = $filename; //&#x6587;&#x4ef6;&#x540d;&#xff0c;&#x5305;&#x542b;&#x6269;&#x5c55;&#x540d;
				$file_list[$i]['datetime'] = date('Y-m-d H:i:s', filemtime($file)); //&#x6587;&#x4ef6;&#x6700;&#x540e;&#x4fee;&#x6539;&#x65f6;&#x95f4;
				$i++;
			}
			closedir($handle);
		}

		usort($file_list, array('Junhua_editor_filemanger' ,  "cmp_func" ));

		$result = array();
		//&#x76f8;&#x5bf9;&#x4e8e;&#x6839;&#x76ee;&#x5f55;&#x7684;&#x4e0a;&#x4e00;&#x7ea7;&#x76ee;&#x5f55;
		$result['moveup_dir_path'] = $moveup_dir_path;
		//&#x76f8;&#x5bf9;&#x4e8e;&#x6839;&#x76ee;&#x5f55;&#x7684;&#x5f53;&#x524d;&#x76ee;&#x5f55;
		$result['current_dir_path'] = $current_dir_path;
		//&#x5f53;&#x524d;&#x76ee;&#x5f55;&#x7684;URL
		$result['current_url'] = $current_url;
		//&#x6587;&#x4ef6;&#x6570;
		$result['total_count'] = count($file_list);
		//&#x6587;&#x4ef6;&#x5217;&#x8868;&#x6570;&#x7ec4;
		$result['file_list'] = $file_list;

		//&#x8f93;&#x51fa;JSON&#x5b57;&#x7b26;&#x4e32;
		header('Content-type: application/json; charset=UTF-8');
		echo json_encode($result);

	}

	//&#x6392;&#x5e8f;
	public function cmp_func($a, $b) {
		if ($a['is_dir'] && !$b['is_dir']) {
			return -1;
		} else if (!$a['is_dir'] && $b['is_dir']) {
			return 1;
		} else {
			if ($this->order == 'size') {
				if ($a['filesize'] > $b['filesize']) {
					return 1;
				} else if ($a['filesize'] < $b['filesize']) {
					return -1;
				} else {
					return 0;
				}
			} else if ($this->order == 'type') {
				return strcmp($a['filetype'], $b['filetype']);
			} else {
				return strcmp($a['filename'], $b['filename']);
			}
		}
	}


}