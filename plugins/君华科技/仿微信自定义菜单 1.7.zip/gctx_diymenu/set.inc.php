<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$setting = C::t('common_setting')->fetch_all(array('gctx_diymenu'));
$setting = (array)unserialize($setting['gctx_diymenu']);


if(!submitcheck('menusubmit')) {

	showtips(lang('plugin/gctx_diymenu', 'menu_tips'));

	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=gctx_diymenu&pmod=set');
	showtableheader();

	echo '<tr class="header"><th class="td25"></th><th>'.$lang['display_order'].'</th><th style="width:200px">'.lang('plugin/gctx_diymenu', 'gctx_menu_name').'</th><th style="width:200px">'.lang('plugin/gctx_diymenu', 'gctx_menu_keyurl').'</th><th>'.lang('plugin/gctx_diymenu', 'gctx_menu_icon').'</th></tr>';
	foreach($setting['button'] as $k => $button) {
		$disabled = !empty($button['sub_button']) ? 'disabled' : '';
		showtablerow('', array('', 'class="td23 td28"', '', 'class="td29"', 'class="td29"'), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"button[$k][delete]\" value=\"yes\" $disabled>",
			"<input type=\"text\" class=\"txt\" size=\"3\" name=\"button[$k][displayorder]\" value=\"$button[displayorder]\">",
			"<div class=\"parentnode\"><input type=\"text\" class=\"txt\" name=\"button[$k][name]\" value=\"".dhtmlspecialchars($button['name'])."\"></div>",
			"<input type=\"text\" class=\"txt\" name=\"button[$k][keyurl]\" value=\"".dhtmlspecialchars($button['keyurl'])."\">",
			"<input type=\"text\" class=\"txt\" name=\"button[$k][iconurl]\" value=\"".dhtmlspecialchars($button['iconurl'])."\">",
		));
		if(!empty($button['sub_button'])) {
			foreach($button['sub_button'] as $sk => $sub_button) {
				showtablerow('', array('', 'class="td23 td28"', '', 'class="td29"'), array(
					"<input class=\"checkbox\" type=\"checkbox\" name=\"button[$k][sub_button][$sk][delete]\" value=\"yes\">",
					"<input type=\"text\" class=\"txt\" size=\"3\" name=\"button[$k][sub_button][$sk][displayorder]\" value=\"$sub_button[displayorder]\">",
					"<div class=\"node\"><input type=\"text\" class=\"txt\" name=\"button[$k][sub_button][$sk][name]\" value=\"".dhtmlspecialchars($sub_button['name'])."\"></div>",
					"<input type=\"text\" class=\"txt\" name=\"button[$k][sub_button][$sk][keyurl]\" value=\"".dhtmlspecialchars($sub_button['keyurl'])."\">",
					"",
				));
			}
		}
		echo '<tr><td></td><td></td><td colspan="2"><div class="lastnode"><a href="###" onclick="addrow(this, 1, '.$k.')" class="addtr">'.lang('plugin/gctx_diymenu', 'gctx_menu_sub_button').'</a></div></td></tr>';
	}
	echo '<tr><td></td><td class="td23 td28"></td><td colspan="2"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">'.lang('plugin/gctx_diymenu', 'gctx_menu_button').'</a></div></td></tr>';



	echo <<<EOT
<script type="text/JavaScript">
var rowtypedata = [
[[1,''], [1,'<input name="newbutton[displayorder][]" value="" size="3" type="text" class="txt">', 'td23 td28'], [1, '<input name="newbutton[name][]" value="" size="30" type="text" class="txt">'], [1, '<input name="newbutton[keyurl][]" value="" size="30" type="text" class="txt">', 'td29']],
[[1,''], [1,'<input name="newsub_button[{1}][displayorder][]" value="" size="3" type="text" class="txt">', 'td23 td28'], [1, '<div class=\"node\"><input name="newsub_button[{1}][name][]" value="" size="30" type="text" class="txt"></div>'], [1, '<input name="newsub_button[{1}][keyurl][]" value="" size="30" type="text" class="txt">', 'td29']],
];
</script>
EOT;

	showsubmit('menusubmit', lang('plugin/gctx_diymenu', 'gctx_menu_save'), 'del');


	showtablefooter();
	showformfooter();

} else {

	if(!empty($_GET['newbutton'])) {
		foreach($_GET['newbutton']['name'] as $k => $name) {
			$button = array(
				'displayorder' => $_GET['newbutton']['displayorder'][$k],
				'name' => $name,
				'keyurl' => $_GET['newbutton']['keyurl'][$k],
				'iconurl' => $_GET['newbutton']['iconurl'][$k],
			);
			$setting['button'][] = $button;
		}
	}

	foreach($_GET['button'] as $k => $value) {
		if($value['sub_button']) {
			foreach($value['sub_button'] as $sk => $v) {
				if($v['delete']) {
					unset($value['sub_button'][$sk]);
				}
			}
		}
		if($value['delete']) {
			unset($setting['button'][$k]);
			continue;
		}
		$setting['button'][$k] = $value;
		if(!empty($_GET['newsub_button'][$k])) {
			foreach($_GET['newsub_button'][$k]['name'] as $sk => $name) {
				$sub_button = array(
					'displayorder' => $_GET['newsub_button'][$k]['displayorder'][$sk],
					'name' => $name,
					'keyurl' => $_GET['newsub_button'][$k]['keyurl'][$sk],
				);
				$setting['button'][$k]['sub_button'][] = $sub_button;
			}
		}
		if(count($setting['button'][$k]['sub_button']) > 5) {
			cpmsg(lang('plugin/gctx_diymenu', 'gctx_menu_sub_button_max'), '', 'error');
		}
		usort($setting['button'][$k]['sub_button'], 'buttoncmp');
	}

	if(count($setting['button']) > 4) {
		cpmsg(lang('plugin/gctx_diymenu', 'gctx_menu_button_max'), '', 'error');
	}

	usort($setting['button'], 'buttoncmp');

	$settings = array('gctx_diymenu' => serialize($setting));
	C::t('common_setting')->update_batch($settings);
	updatecache('setting');

	cpmsg('setting_update_succeed', 'action=plugins&operation=config&do='.$pluginid.'&identifier=gctx_diymenu&pmod=set', 'succeed');
}


function buttoncmp($a, $b) {
	return $a['displayorder'] > $b['displayorder'] ? 1 : -1;
}