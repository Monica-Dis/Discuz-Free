<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$createtablesql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_junhua_wnbd` (
  `wnbd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(125) DEFAULT '',
  `params` mediumtext,
  `setting` text,
  `add_time` int(10) unsigned DEFAULT '0',
  `edit_time` int(10) unsigned DEFAULT '0',
  `clicknum` int(10) DEFAULT '0',
  `is_enable` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`wnbd_id`),
  KEY `add_time` (`add_time`),
  KEY `is_enable` (`is_enable`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_wnbd_form` (
  `form_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `wnbd_id` int(10) unsigned DEFAULT '0',
  `mobile` varchar(64) DEFAULT '',
  `data` text,
  `add_time` int(10) unsigned DEFAULT '0',
  `is_pay` tinyint(1) unsigned DEFAULT '0',
  `pay_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`form_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_wnbd_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wnbd_id` int(10) unsigned DEFAULT '0',
  `form_id` int(10) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `total_amount` decimal(14,2) DEFAULT '0.00',
  `trade_no` varchar(64) DEFAULT '',
  `out_trade_no` varchar(64) DEFAULT '',
  `paytype` tinyint(1) DEFAULT '0',
  `remark` varchar(256) DEFAULT '',
  `is_pay` tinyint(1) unsigned DEFAULT '0',
  `pay_time` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`order_id`),
  KEY `out_trade_no` (`out_trade_no`),
  KEY `user_id` (`user_id`),
  KEY `wnbd_id` (`wnbd_id`),
  KEY `form_id` (`form_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_wnbd_verify` (
  `verify_id` int(10) NOT NULL AUTO_INCREMENT,
  `verify_from` varchar(32) DEFAULT '',
  `verify_st` varchar(16) DEFAULT '',
  `is_verify` tinyint(1) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`verify_id`),
  KEY `verify_from` (`verify_from`) USING BTREE,
  KEY `verify_st` (`verify_st`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=MyISAM;

EOF;

runquery($createtablesql);

$updatesql = array ('junhua_wnbd' => array ('wnbd_id' => array ('Field' => 'wnbd_id','Type' => 'int(10) unsigned','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),'title' => array ('Field' => 'title','Type' => 'varchar(125)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'params' => array ('Field' => 'params','Type' => 'mediumtext','Null' => 'YES','Key' => '','Default' => NULL,'Extra' => '',),'setting' => array ('Field' => 'setting','Type' => 'text','Null' => 'YES','Key' => '','Default' => NULL,'Extra' => '',),'add_time' => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'edit_time' => array ('Field' => 'edit_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'clicknum' => array ('Field' => 'clicknum','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'is_enable' => array ('Field' => 'is_enable','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),),'junhua_wnbd_form' => array ('form_id' => array ('Field' => 'form_id','Type' => 'int(10) unsigned','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),'user_id' => array ('Field' => 'user_id','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'wnbd_id' => array ('Field' => 'wnbd_id','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'mobile' => array ('Field' => 'mobile','Type' => 'varchar(64)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'data' => array ('Field' => 'data','Type' => 'text','Null' => 'YES','Key' => '','Default' => NULL,'Extra' => '',),'add_time' => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'is_pay' => array ('Field' => 'is_pay','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'pay_time' => array ('Field' => 'pay_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),),'junhua_wnbd_order' => array ('order_id' => array ('Field' => 'order_id','Type' => 'int(10) unsigned','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),'wnbd_id' => array ('Field' => 'wnbd_id','Type' => 'int(10) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'form_id' => array ('Field' => 'form_id','Type' => 'int(10) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'user_id' => array ('Field' => 'user_id','Type' => 'int(10) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'total_amount' => array ('Field' => 'total_amount','Type' => 'decimal(14,2)','Null' => 'YES','Key' => '','Default' => '0.00','Extra' => '',),'trade_no' => array ('Field' => 'trade_no','Type' => 'varchar(64)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'out_trade_no' => array ('Field' => 'out_trade_no','Type' => 'varchar(64)','Null' => 'YES','Key' => 'MUL','Default' => '','Extra' => '',),'paytype' => array ('Field' => 'paytype','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'remark' => array ('Field' => 'remark','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'is_pay' => array ('Field' => 'is_pay','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'pay_time' => array ('Field' => 'pay_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'add_time' => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),),'junhua_wnbd_verify' => array ('verify_id' => array ('Field' => 'verify_id','Type' => 'int(10)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),'verify_from' => array ('Field' => 'verify_from','Type' => 'varchar(32)','Null' => 'YES','Key' => 'MUL','Default' => '','Extra' => '',),'verify_st' => array ('Field' => 'verify_st','Type' => 'varchar(16)','Null' => 'YES','Key' => 'MUL','Default' => '','Extra' => '',),'is_verify' => array ('Field' => 'is_verify','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'user_id' => array ('Field' => 'user_id','Type' => 'int(10) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'add_time' => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),),);

foreach ($updatesql as $updatesql_key => $updatesql_value) {
    # code...

    $columns_news = $updatesql_value;
    $columns = DB::fetch_all('SHOW COLUMNS FROM %t', array($updatesql_key));
    $columns_ary = array();

    foreach ($columns as $key => $value) {
        if(!isset($columns_news[$value['Field']])){
            $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` DROP COLUMN `'.$value['Field'].'`;';
            runquery($sql);
        }else{
            $columns_ary[$value['Field']] = $value;
        }
    }

    foreach ($columns_news as $key => $value) {
        //&#x65b0;&#x589e;&#x5b57;&#x6bb5;
        if(!isset($columns_ary[$key])){
            $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` ADD COLUMN `'.$key.'` '.$value['Type'].' '.($value['Null'] == 'YES' ? 'NULL' : '').' DEFAULT "'.$value['Default'].'";';
            runquery($sql);
        }else{

            //&#x4fee;&#x6539;&#x5b57;&#x6bb5;
            if($columns_ary[$key]['Field'] != $value['Field'] || $columns_ary[$key]['Type'] != $value['Type'] || $columns_ary[$key]['Default'] != $value['Default'] ){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` MODIFY COLUMN `'.$key.'` '.$value['Type'].' '.($value['Null'] == 'YES' ? 'NULL' : '').' DEFAULT "'.$value['Default'].'";';
                runquery($sql);
            }

            //&#x589e;&#x52a0;&#x7d22;&#x5f15;
            if($columns_ary[$key]['Key'] == '' && $value['Key'] == 'MUL'){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` ADD INDEX `'.$key.'` (`'.$key.'`) USING BTREE;';
                runquery($sql);
            }

            //&#x5220;&#x9664;&#x7d22;&#x5f15;
            if($columns_ary[$key]['Key'] == 'MUL' && $value['Key'] == ''){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` DROP INDEX `'.$key.'`;'; //&#x5220;&#x9664;&#x7d22;&#x5f15;
                runquery($sql);
            }
        }

    }
}

$finish = true;