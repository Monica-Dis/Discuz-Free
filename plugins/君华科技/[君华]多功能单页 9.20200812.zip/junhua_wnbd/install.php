<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$ADMINSCRIPT = ADMINSCRIPT;
$siteurl = $_G['siteurl'];

$createtablesql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_junhua_wnbd` (
  `wnbd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(125) DEFAULT '',
  `params` mediumtext,
  `setting` text,
  `add_time` int(10) unsigned DEFAULT '0',
  `edit_time` int(10) unsigned DEFAULT '0',
  `clicknum` int(10) DEFAULT '0',
  `is_enable` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`wnbd_id`),
  KEY `add_time` (`add_time`),
  KEY `is_enable` (`is_enable`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_wnbd_form` (
  `form_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `wnbd_id` int(10) unsigned DEFAULT '0',
  `mobile` varchar(64) DEFAULT '',
  `data` text,
  `add_time` int(10) unsigned DEFAULT '0',
  `is_pay` tinyint(1) unsigned DEFAULT '0',
  `pay_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`form_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_wnbd_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wnbd_id` int(10) unsigned DEFAULT '0',
  `form_id` int(10) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `total_amount` decimal(14,2) DEFAULT '0.00',
  `trade_no` varchar(64) DEFAULT '',
  `out_trade_no` varchar(64) DEFAULT '',
  `paytype` tinyint(1) DEFAULT '0',
  `remark` varchar(256) DEFAULT '',
  `is_pay` tinyint(1) unsigned DEFAULT '0',
  `pay_time` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`order_id`),
  KEY `out_trade_no` (`out_trade_no`),
  KEY `user_id` (`user_id`),
  KEY `wnbd_id` (`wnbd_id`),
  KEY `form_id` (`form_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_wnbd_verify` (
  `verify_id` int(10) NOT NULL AUTO_INCREMENT,
  `verify_from` varchar(32) DEFAULT '',
  `verify_st` varchar(16) DEFAULT '',
  `is_verify` tinyint(1) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`verify_id`),
  KEY `verify_from` (`verify_from`) USING BTREE,
  KEY `verify_st` (`verify_st`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=MyISAM;

EOF;

runquery($createtablesql);
$finish = TRUE;
?>