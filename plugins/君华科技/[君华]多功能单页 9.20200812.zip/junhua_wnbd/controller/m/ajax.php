<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!in_array($a, array('form', 'getsmscode'))){
    $a = 'form';
}

$wnbdModel = new junhua_model('wnbd');
$FormModel = new junhua_model('wnbdForm');
$VerifyModel = new junhua_model('wnbdVerify');
$OrderModel = new junhua_model('wnbdOrder');

function junhua_zkh($a){
    return '['.$a.']';
}

function junhua_imp($a){
    if(is_array($a)){
        return implode(',', $a);
    }
    return $a;
}


if($a == 'form'){
    if(IS_AJAX){

        $dataForm = junhua_I('data/a', array());
        $mobile   = junhua_I('mobile', '');
        $vcode    = junhua_I('vcode', '');
        $wnbd_id  = junhua_I('wnbd_id/d', 0);

        $wnbdInfo = $wnbdModel->find(array('wnbd_id' => $wnbd_id, 'is_enable' => 1));

        if(!$wnbdInfo){
            $data = array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
            junhua_ajaxReturn($data);
        }

        //&#x89e3;&#x6790;&#x5168;&#x90e8;&#x7684;&#x5185;&#x5bb9;
        $params = dunserialize($wnbdInfo['params']);
        //&#x89e3;&#x6790;&#x914d;&#x7f6e;
        $wnbdSetting = dunserialize($wnbdInfo['setting']);

        if($wnbdSetting['post_needlogin'] == 1 && !$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        if($wnbdSetting['stop_repeat_open'] == 1 && $uid){

            $formWhere = array(
                'wnbd_id' => $wnbd_id,
                'user_id' => $uid,
                'is_pay'  => 1,
            );

            if(!$wnbdSetting['money']){
                unset($formWhere['is_pay']);
            }

            $formInfo = $FormModel->find($formWhere);

            if($formInfo){
                $data = array('code' => 0, 'msg' => '&#x60a8;&#x5df2;&#x63d0;&#x4ea4;&#xff0c;&#x8bf7;&#x52ff;&#x91cd;&#x590d;&#x63d0;&#x4ea4;');
                junhua_ajaxReturn($data);
            }

        }

        //&#x9a8c;&#x8bc1;&#x6240;&#x6709;&#x7684;&#x5185;&#x5bb9;
        foreach ($params as $key => $value) {
            if($params[$key]['params']['ischeck'] == 1){

                if(!$dataForm[$key]){
                    $data = array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
                    junhua_ajaxReturn($data);
                }else{
                    if($params[$key]['id'] == "mobile" && $params[$key]['params']['is_vocde'] == 1){

                        if(!$vcode){
                            $data = array('code' => 0, 'msg' => '&#x8bf7;&#x586b;&#x5199;&#x9a8c;&#x8bc1;&#x7801;');
                            junhua_ajaxReturn($data);
                        }else{

                            //&#x67e5;&#x8be2;&#x9a8c;&#x8bc1;&#x7801;&#x662f;&#x5426;&#x88ab;&#x7528;&#x8fc7;
                            $where = array(
                                'verify_from' => $mobile,
                                'verify_st'   => $vcode,
                                'is_verify'   => 0
                            );

                            $VerifyInfo = $VerifyModel->find($where, '*', 'verify_id desc');

                            if($VerifyInfo){
                                //&#x63a7;&#x5236;&#x53d1;&#x9001;&#x7684;&#x9891;&#x7387;
                                $isAllow = $VerifyInfo['add_time'] + 900 - $_G['timestamp'];
                                if($isAllow > 0 ){
                                    $VerifyModel->save($where, array('is_verify' => 1));
                                }else{
                                    junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x5df2;&#x8fc7;&#x671f;&#xff0c;&#x8bf7;&#x91cd;&#x65b0;&#x83b7;&#x53d6;',));
                                }
                            }else{
                                junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x9a8c;&#x8bc1;&#x7801;&#x9519;&#x8bef;'));
                            }
                        }
                    }
                }
            }
        }



        $data = array(
            'user_id'  => $uid,
            'wnbd_id'  => $wnbd_id,
            'mobile'   => $mobile,
            'data'     => serialize($dataForm),
            'add_time' => $_G['timestamp'],
        );

        $form_id = $FormModel->add($data);


        if($wnbdSetting['money'] > 0 && $uid){

            $total_amount = $wnbdSetting['money'];

            $orderData = array(
                'form_id'   => $form_id,
                'user_id'      => $uid,
                'wnbd_id'      => $wnbd_id,
                'total_amount' => $total_amount,
                'out_trade_no' => junhua_getorderno('jwn_'),
                'remark'       => $wnbdInfo['title'], //&#x652f;&#x4ed8;&#x5907;&#x6ce8;
                'paytype'      => IS_MAGA ? 1 : (IS_WEIXIN ? 2 : 0),  //&#x7528;&#x6237;UID
                'add_time'     => $_G['timestamp'],
            );

            $orderId = $OrderModel->add($orderData);

            if(IS_MAGA){
                $junhuaApp = new junhua_App($junhua_base_config, $junhua_wnbd_setting);

                $param = array(
                    'out_trade_no' => $orderData['out_trade_no'], //&#x5916;&#x90e8;&#x8ba2;&#x5355;
                    'money'        => $orderData['total_amount'], //&#x652f;&#x4ed8;&#x91d1;&#x989d;
                    'des'          => '', //&#x652f;&#x4ed8;&#x63cf;&#x8ff0;
                    'remark'       => '', //&#x652f;&#x4ed8;&#x5907;&#x6ce8;
                    'uid'          => $orderData['user_id'],  //&#x7528;&#x6237;UID
                    'title'        => junhua_gbk2utf8($wnbdInfo['title']), //&#x652f;&#x4ed8;&#x6807;&#x9898;
                );

                $r = $junhuaApp->getMagaCreateOrder($param);

                if(isset($r['data']['unionOrderNum'])){

                    $unionOrderNum = $r['data']['unionOrderNum'];

                    $OrderModel->save(array(
                        'order_id' => $orderId, //&#x5916;&#x90e8;&#x8ba2;&#x5355;
                    ),array(
                        'trade_no'  => $unionOrderNum
                    ));

                    junhua_ajaxReturn(array(
                        'code'          => 3,
                        'unionOrderNum' => $unionOrderNum,
                        'out_trade_no'  => $orderData['out_trade_no'],
                        'total_amount'  => $orderData['total_amount'],
                        'title'         => junhua_gbk2utf8($wnbdInfo['title']),
                        'des'           => '',
                    ));

                }else{
                    junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;&#xff0c;&#x8bf7;&#x7a0d;&#x540e;&#x518d;&#x8bd5;'));
                }

            }elseif(IS_WEIXIN) {

                include_once('source/plugin/junhua_base/libs/weixin/weixin_pay.php');

                $weixin_appid     = $junhua_wnbd_setting['weixin_appid'] ? trim($junhua_wnbd_setting['weixin_appid']) : trim($junhua_base_config['weixin_appid']);
                $weixin_appsecret = $junhua_wnbd_setting['weixin_appsecret'] ? trim($junhua_wnbd_setting['weixin_appsecret']) : trim($junhua_base_config['weixin_appsecret']);
                $weixin_mchid     = $junhua_wnbd_setting['weixin_mchid'] ? trim($junhua_wnbd_setting['weixin_mchid']) : trim($junhua_base_config['weixin_mchid']);
                $weixin_key       = $junhua_wnbd_setting['weixin_key'] ? trim($junhua_wnbd_setting['weixin_key']) : trim($junhua_base_config['weixin_key']);

                $weixin_table  = $junhua_base_config['weixin_table'];
                $weixin_tables = explode(',', $weixin_table);
                $tableName     = str_replace(DB::object()->tablepre, '', $weixin_tables[0]);
                $uidField      = $weixin_tables[1];
                $openidField   = $weixin_tables[2];

                //&#x67e5;&#x8be2;openid
                $wxTableModel = new junhua_model($tableName, '');
                $openid = $wxTableModel->getField(array(
                    $uidField => $uid
                ), $openidField);

                if($weixin_appid && $weixin_appsecret && $weixin_mchid && $weixin_key && $openidField){
                    $weixin_pay = new WEIXIN_PAY($weixin_appid, $weixin_appsecret, $weixin_mchid, $weixin_key);

                    $weixin_pay->body = junhua_gbk2utf8(junhua_utf82gbk(junhua_unicodeDecode('&#x53d1;&#x5e03;')));
                    $weixin_pay->out_trade_no = $orderData['out_trade_no'];
                    $weixin_pay->total_fee = $orderData['total_amount']*100;    // &#x5355;&#x4f4d;&#x4e3a; &#x201c;&#x5206;&#x201d;, &#x5b57;&#x7b26;&#x4e32;&#x7c7b;&#x578b;
                    $weixin_pay->openid = $openid;
                    $callback     = $_G['siteurl'].'source/plugin/junhua_wnbd/wxnotify.php';
                    $weixin_pay->notify_url = $callback;

                    $payment = $weixin_pay->getConfig();

                    junhua_ajaxReturn(array(
                        'code'  => 3,
                        'payment' => $payment,
                    ));
                }else{
                    junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;&#xff0c;&#x8bf7;&#x7a0d;&#x540e;&#x518d;&#x8bd5;'));
                }
            }else{
                junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x8bf7;&#x5230;app&#x6216;&#x8005;&#x5fae;&#x4fe1;&#x4e2d;&#x53d1;&#x5e03;'));
            }
        }


        $data = array('code' => 2, 'msg' => '&#x63d0;&#x4ea4;&#x6210;&#x529f;');

        //&#x53d1;&#x7ed9;&#x7528;&#x6237;&#x81ea;&#x5df1;

        $dataForm['pagetitle'] = $params['page']['params']['title'];

        if($wnbdSetting['submit_to_user_sms_open'] && $mobile){

            $smssetting = array(
                'type'            => 'dayu',
                'AccessKeyID'     => $junhua_base_config['dayu_AccessKeyID'],
                'AccessKeySecret' => $junhua_base_config['dayu_AccessKeySecret'],
                'TemplateCode'    => $wnbdSetting['submit_to_user_sms_dayu_TemplateCode'],
                'FreeSignName'    => junhua_gbk2utf8($junhua_wnbd_setting['dayu_FreeSignName']),
            );


            //&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x53d8;&#x91cf;
            $submit_to_user_sms_dayu_remark = str_replace("\r", "", $wnbdSetting['submit_to_user_sms_dayu_remark']);
            $submit_to_user_sms_dayu_remark = explode("\n", $submit_to_user_sms_dayu_remark);
            $submit_to_user_sms_dayu_remark = array_filter($submit_to_user_sms_dayu_remark);

            $sms_param = array();
            foreach ($submit_to_user_sms_dayu_remark as $key => $value) {
                $$value = trim($value);
                $params = explode(":", $value);
                $sms_param[trim($params[0])] = $dataForm[rtrim(ltrim($params[1], '['), ']')];
            }

            $sms_param = array_map('junhua_imp', $sms_param);

            junhua_sendsms($smssetting, $mobile, $sms_param);
        }

        //&#x53d1;&#x7ed9;&#x7ba1;&#x7406;&#x5458;
        if($wnbdSetting['submit_to_admin_sms_open'] && $wnbdSetting['submit_to_admin_mobile']){

            $smssetting = array(
                'type'            => 'dayu',
                'AccessKeyID'     => $junhua_base_config['dayu_AccessKeyID'],
                'AccessKeySecret' => $junhua_base_config['dayu_AccessKeySecret'],
                'TemplateCode'    => $wnbdSetting['submit_to_admin_sms_dayu_TemplateCode'],
                'FreeSignName'    => junhua_gbk2utf8($junhua_wnbd_setting['dayu_FreeSignName']),
            );

            //&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x53d8;&#x91cf;
            $submit_to_admin_sms_dayu_remark = str_replace("\r", "", $wnbdSetting['submit_to_admin_sms_dayu_remark']);
            $submit_to_admin_sms_dayu_remark = explode("\n", $submit_to_admin_sms_dayu_remark);
            $submit_to_admin_sms_dayu_remark = array_filter($submit_to_admin_sms_dayu_remark);

            $sms_param = array();
            foreach ($submit_to_admin_sms_dayu_remark as $key => $value) {
                $$value = trim($value);
                $params = explode(":", $value);
                $sms_param[trim($params[0])] = $dataForm[rtrim(ltrim($params[1], '['), ']')];
            }
            $sms_param = array_map('junhua_imp', $sms_param);

            $submit_to_admin_mobile = explode(',', $wnbdSetting['submit_to_admin_mobile']);
            foreach ($submit_to_admin_mobile as $key => $value) {
                junhua_sendsms($smssetting, $value, $sms_param);
            }
        }

        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}elseif($a == 'getsmscode'){

    if(IS_AJAX){

        $mobile = junhua_I('mobile', '');
        $mobile = trim($mobile);

        if(!$mobile){
            junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x8bf7;&#x586b;&#x5199;&#x624b;&#x673a;&#x53f7;&#x7801;'));
        }

        //&#x67e5;&#x8be2;&#x9a8c;&#x8bc1;&#x7801;&#x662f;&#x5426;&#x88ab;&#x7528;&#x8fc7;
        $where = array(
            'verify_from' => $mobile,
            'user_id'     => $uid,
            'is_verify'   => 0
        );

        $VerifyInfo = $VerifyModel->find($where, '*', 'verify_id desc');

        if($VerifyInfo){
            //&#x63a7;&#x5236;&#x53d1;&#x9001;&#x7684;&#x9891;&#x7387;
            $isAllowTime = $VerifyInfo['add_time'] + 60 - $_G['timestamp'];
            if($isAllowTime > 0 ){
                $ary = array(
                    'code'      => 1,
                    'msg'       => '&#x8bf7;&#x8fc7;'.$isAllowTime.'&#x79d2;&#x4e4b;&#x540e;&#x518d;&#x70b9;&#x51fb;&#x53d1;&#x9001;',
                );

                junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x8bf7;&#x8fc7;'.$isAllowTime.'&#x79d2;&#x4e4b;&#x540e;&#x518d;&#x70b9;&#x51fb;&#x53d1;&#x9001;',));
            }

            $randNum = rand(100000,999999);
            $data = array(
                'verify_from' => $mobile,
                'verify_st'   => $randNum,
                'user_id'     => $uid,
                'add_time'    => $_G['timestamp'],
            );
            
            $VerifyModel->add($data);

        }else{
            $randNum = rand(100000,999999);
            $data = array(
                'verify_from' => $mobile,
                'verify_st'   => $randNum,
                'user_id'     => $uid,
                'add_time'    => $_G['timestamp'],
            );
            $VerifyModel->add($data);
        }

        $smssetting = array(
            'type'            => 'dayu',
            'AccessKeyID'     => $junhua_base_config['dayu_AccessKeyID'],
            'AccessKeySecret' => $junhua_base_config['dayu_AccessKeySecret'],
            'TemplateCode'    => $junhua_wnbd_setting['dayu_TemplateCode'],
            'FreeSignName'    => junhua_gbk2utf8($junhua_wnbd_setting['dayu_FreeSignName']),
        );

        $result = junhua_sendsms($smssetting, $mobile, array('code' => $randNum));

        if($result['Code'] == 'OK'){
            junhua_ajaxReturn(array('code' => 1, 'msg' => '&#x53d1;&#x9001;&#x6210;&#x529f;'));
        }else{
            junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x53d1;&#x9001;&#x5931;&#x8d25;'));
        }

    }else{
        exit;
    }

}
else{
	exit;
}