<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!in_array($a, array('index', 'uploadfile'))){
    $a = 'index';
}

$wnbdModel = new junhua_model('wnbd');

include_once('source/plugin/junhua_wnbd/controller/m/common.php');

if($a == 'index'){

    $wnbd_id = junhua_I('wnbd_id/d', 0);

    $where = array('wnbd_id' => $wnbd_id, 'is_enable' => 1);
    $wnbdInfo = $wnbdModel->find($where);

    if(!$wnbdInfo){
        exit;
    }

    $wnbdSetting = dunserialize($wnbdInfo['setting']);

    //&#x5224;&#x65ad;&#x662f;&#x5426;&#x5f00;&#x542f;&#x4e86;&#x5fc5;&#x987b;&#x767b;&#x5f55;
    if(IS_MAGA){
        if(!$uid){

            $junhuaApp = new junhua_App($junhua_base_config, $junhua_wnbd_setting);
            $r = $junhuaApp->getMagaUserInfo();

            if($r['data']['user_id'] > 0){

                $member = getuserbyuid($r['data']['user_id'], 1);
                if (!$member) {
                    dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                    exit();
                }

                require_once libfile('function/member');
                $cookietime = 1296000;
                setloginstatus($member, $cookietime);
            }else{
                //&#x5f3a;&#x5236;&#x767b;&#x5f55; &#x5fc5;&#x987b;&#x767b;&#x5f55;&#x624d;&#x53ef;&#x4ee5;&#x8bbf;&#x95ee;
                if($wnbdSetting['fangwen_needlogin'] == 1){
                    exit('<script src="https://static.app1.magcloud.net/public/static/dest/js/libs/magjs-x.js"></script><script>
                        mag.toLogin(function(){
                            top.location.href="' . $refererurl . '";
                            mag.newWin(\''.$refererurl.'\');
                            mag.setPageLife({
                                pageAppear: function(){
                                    window.location.reload(true);
                                },
                                pageDisappear: function(){}
                            });
                        });
                        </script>'); 
                }
            }
        }
    }elseif(IS_QF){
        if(!$uid){

            $junhuaApp = new junhua_App($junhua_base_config, $junhua_wnbd_setting);
            $r = $junhuaApp->getQfUserInfo();

            if($r['data']['id'] > 0){

                $member = getuserbyuid($r['data']['id'], 1);
                if (!$member) {
                    dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                    exit();
                }

                require_once libfile('function/member');
                $cookietime = 1296000;
                setloginstatus($member, $cookietime);
                exit('<script>window.location.reload(true);</script>');
            }else{
                //&#x5f3a;&#x5236;&#x767b;&#x5f55; &#x5fc5;&#x987b;&#x767b;&#x5f55;&#x624d;&#x53ef;&#x4ee5;&#x8bbf;&#x95ee;
                if($wnbdSetting['fangwen_needlogin'] == 1){
                    exit('<script>
                    function QFH5ready(){
                        QFH5.jumpLogin(function(state, data){
                            window.location.reload(true);
                        });
                    }
                    </script>'); 
                }
            }
        }
    }else{

        if(!$uid && $wnbdSetting['fangwen_needlogin']){
            dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
            exit();
        }
    }



    $pageDiy = dunserialize($wnbdInfo['params']);
    //&#x89e3;&#x6790;&#x5730;&#x5740; &#x5224;&#x65ad;&#x662f;&#x5426;&#x6709;picker
    $pickers = array();
    $isCity = false;
    $diyPickers = array();
    foreach ($pageDiy as $key => $value) {

        if($value['id'] == 'picker' && $value['params']['type'] == 3){
            $isCity = true;
            $diyPickers[$key] = junhua_select2array($value['params']['diypick']);
        }

        if($value['id'] == 'picker' && $value['params']['type'] == 4){
            $diyPickers[$key] = junhua_select2array($value['params']['diypick']);
        }

    }

    $block_title = '';
    $block_css = '';
}elseif($a == 'uploadfile'){
    include_once('source/plugin/junhua_base/libs/filemanger.class.php');

    if (!IS_POST && isset($_FILES) ? $_FILES : array()) {
        exit;
    }

    $filemanger = new junhua_filemanger('source/plugin/junhua_wnbd', 'source/plugin/junhua_wnbd');
    $img_path = $filemanger->uploadJson('Filedata', false);

    junhua_ajaxReturn(array('status' => 1, 'file_path' => $img_path));
}
else{
    exit;
}

include template('junhua_wnbd:m/index/index');