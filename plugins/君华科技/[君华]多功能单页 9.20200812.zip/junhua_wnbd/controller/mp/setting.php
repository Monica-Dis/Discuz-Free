<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array(
    'index',
    'uploadfile',
    'uploadfile_editor',
))){
    $a = 'index';
}

loadcache('junhua_base_system');
$junhua_base_system = dunserialize($_G['cache']['junhua_base_system']);

$dataOrg = array(
    
    'weixin_share_open' => $junhua_wnbd_setting['weixin_share_open'],
    'weixin_appid'      => $junhua_wnbd_setting['weixin_appid'],
    'weixin_appsecret'  => $junhua_wnbd_setting['weixin_appsecret'],
    'weixin_paohui_url' => $junhua_wnbd_setting['weixin_paohui_url'],
    'weixin_mchid'      => $junhua_wnbd_setting['weixin_mchid'],
    'weixin_key'        => $junhua_wnbd_setting['weixin_key'],
    
    'dayu_FreeSignName' => $junhua_wnbd_setting['dayu_FreeSignName'],
    'dayu_TemplateCode' => $junhua_wnbd_setting['dayu_TemplateCode'],
    
    'share_title'       => $junhua_wnbd_setting['share_title'],
    'share_desc'        => $junhua_wnbd_setting['share_desc'],
    'share_img'         => $junhua_wnbd_setting['share_img'],

);

if($a == 'index'){

    if(IS_AJAX){
        
        $weixin_share_open = junhua_I('weixin_share_open/d', 0);
        $weixin_appid      = junhua_I('weixin_appid', '');
        $weixin_appsecret  = junhua_I('weixin_appsecret', '');
        $weixin_paohui_url = junhua_I('weixin_paohui_url', '');
        $weixin_mchid      = junhua_I('weixin_mchid', '');
        $weixin_key        = junhua_I('weixin_key', '');

        //&#x8fc7;&#x6ee4;&#x56de;&#x8f66;&#x7a7a;&#x683c;
        $weixin_paohui_url = str_replace("\r", "", $weixin_paohui_url);
        $weixin_paohui_url = explode("\n", $weixin_paohui_url);
        $weixin_paohui_url = array_filter($weixin_paohui_url);
        
        if($weixin_paohui_url){
            $weixin_paohui_url = array_map("trim", $weixin_paohui_url);
            $weixin_paohui_url = implode("\n", $weixin_paohui_url);
        }else{
            $weixin_paohui_url = '';
        }

        $share_title       = junhua_I('share_title', '');
        $share_desc        = junhua_I('share_desc', '');
        $share_img         = junhua_I('share_img', '');
        
        
        $dayu_FreeSignName = junhua_I('dayu_FreeSignName', '');
        $dayu_TemplateCode = junhua_I('dayu_TemplateCode', '');
        

        $data = array(
            'weixin_share_open' => $weixin_share_open,
            
            'weixin_appid'      => $weixin_appid,
            'weixin_appsecret'  => $weixin_appsecret,
            'weixin_paohui_url' => $weixin_paohui_url,
            'weixin_mchid'      => $weixin_mchid,
            'weixin_key'        => $weixin_key,
            
            'share_title'       => $share_title,
            'share_desc'        => $share_desc,
            'share_img'         => $share_img,
            
            'dayu_FreeSignName' => $dayu_FreeSignName,
            'dayu_TemplateCode' => $dayu_TemplateCode,
        );

        $data = array_merge($dataOrg, $data);

        savecache('junhua_wnbd_setting', serialize($data));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x914d;&#x7f6e;&#x6210;&#x529f;'));
    }

    $block_head_title = '&#x7cfb;&#x7edf;&#x914d;&#x7f6e;';
    $block_title = '&#x7cfb;&#x7edf;&#x914d;&#x7f6e;';
    $block_css = '';
}elseif($a == 'uploadfile'){
    include_once('source/plugin/junhua_base/libs/filemanger.class.php');

    if (!IS_POST && isset($_FILES) ? $_FILES : array()) {
        exit;
    }

    $filemanger = new junhua_filemanger('source/plugin/junhua_wnbd', 'source/plugin/junhua_wnbd');
    $img_path = $filemanger->uploadJson('Filedata', false);

    junhua_ajaxReturn(array('status' => 1, 'file_path' => $img_path));
}elseif($a == 'uploadfile_editor'){
    include_once('source/plugin/junhua_base/libs/filemanger.class.php');

    if (!IS_POST && isset($_FILES) ? $_FILES : array()) {
        exit;
    }

    $filemanger = new junhua_filemanger('source/plugin/junhua_wnbd', 'source/plugin/junhua_wnbd');
    $img_path = $filemanger->uploadJson('imgFile');
    exit;
}
else{
	exit;
}

$block_content = 'junhua_wnbd:mp/'.$c.'/'.$a;
include template('junhua_wnbd:mp/layout');