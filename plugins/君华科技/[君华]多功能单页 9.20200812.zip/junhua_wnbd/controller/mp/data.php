<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array(
    'index', 'del', 'export', 'info',
))){
    $a = 'index';
}

$wnbdModel = new junhua_model('wnbd');
$FormModel = new junhua_model('wnbdForm');

if($a == 'index'){
    $wnbd_id = junhua_I('wnbd_id/d', '');
    $mobile  = junhua_I('mobile', '');
    $page    = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);



    $start_time  = junhua_I('start_time', '');
    $end_time    = junhua_I('end_time', '');

    $starttime = $start_time ? strtotime($start_time) : '';
    $endtime   = $end_time ? strtotime($end_time) : '';


    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $where = array();

    $where['wnbd_id'] = $wnbd_id;
    $param['wnbd_id'] = $wnbd_id;
    
    $wnbdInfo = $wnbdModel->find($where);

    if(!$wnbdInfo){
        dheader('location:' . junhua_url('mp/wnbd/index', '', 1));
        exit;
    }

    if($mobile){
        $where['mobile'] = array('like', '%'.str_replace(array('_', '%'), array('\_', '\%'), $mobile).'%');
        $param['mobile'] = $mobile;
    }

    $wnbdSetting = dunserialize($wnbdInfo['setting']);
    $wnbdParams = dunserialize($wnbdInfo['params']);


    if($start_time){
        $param['start_time'] = $start_time;
    }
    if($end_time){
        $param['end_time'] = $end_time;
    }

    if($starttime && $endtime){
        $where['add_time']   = array(array('egt',$starttime),array('elt',$endtime),'and'); 
    }elseif($starttime && !$endtime){
        $where['add_time']   = array('egt',$starttime); 
    }elseif(!$starttime && $endtime){
        $where['add_time']   = array('elt',$endtime); 
    }

    $param['perpage'] = $perpage;


    $totalNum = $FormModel->count($where);

    $theurl = junhua_url('mp/data/index', http_build_query($param), true);
    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $FormModel->select($where, '*', 'form_id desc', $start, $perpage);

    $ids = array();
    foreach ($lists as $key => $value) {
        $ids[] = $value['user_id'];
    }
    $grouplist = C::t('common_usergroup')->range_orderby_credit();

    //&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x7528;&#x6237;
    if($ids){
        $commonMembers = C::t('common_member')->fetch_all($ids);
    }

    $exportUrl = junhua_url('mp/data/export', http_build_query($param), 1);

    $block_head_title = '&#x6570;&#x636e;&#x7ba1;&#x7406;';
    $block_title = '&#x6570;&#x636e;&#x5217;&#x8868;';
    $block_css = '';
}elseif($a == 'del'){
    if(IS_AJAX){
        $form_id = junhua_I('form_id/d', 0);

        $where = array(
            'form_id'      => $form_id
        );

        $formInfo = $FormModel->find($where);
        if(!$formInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $FormModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'info'){

    $form_id = junhua_I('form_id/d', 0);

    $where = array('form_id' => $form_id);
    $formInfo = $FormModel->find($where);

    if(!$formInfo){
        dheader('location:' . junhua_url('mp/wnbd/index', '', 1));
        exit;
    }
    
    $params = $wnbdModel->getField(array('wnbd_id' => $formInfo['wnbd_id']), 'params');
    $params = dunserialize($params);

    //&#x503c;
    $formParams = $formInfo['data'];
    $formParams = dunserialize($formParams);

}elseif($a == 'export'){

    $wnbd_id = junhua_I('wnbd_id/d', '');
    $mobile  = junhua_I('mobile', '');

    $start_time  = junhua_I('start_time', '');
    $end_time    = junhua_I('end_time', '');

    $starttime = $start_time ? strtotime($start_time) : '';
    $endtime   = $end_time ? strtotime($end_time) : '';

    $where = array();

    if($wnbd_id){
        $where['wnbd_id'] = $wnbd_id;
    }

    if($mobile){
        $where['mobile'] = array('like', '%'.str_replace(array('_', '%'), array('\_', '\%'), $mobile).'%');
    }

    if($starttime && $endtime){
        $where['add_time']   = array(array('egt',$starttime),array('elt',$endtime),'and'); 
    }elseif($starttime && !$endtime){
        $where['add_time']   = array('egt',$starttime); 
    }elseif(!$starttime && $endtime){
        $where['add_time']   = array('elt',$endtime); 
    }
    
    $wnbdInfo = $wnbdModel->find(array('wnbd_id' => $wnbd_id));

    $params = dunserialize($wnbdInfo['params']);
    $wnbdSetting = dunserialize($wnbdInfo['setting']);

    $filename = date("YmdHis") . '.csv';
    header('Content-Description: File Transfer');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Type: text/comma-separated-values');   
    header('Content-Transfer-Encoding: binary');

    //&#x5934;&#x6587;&#x4ef6;
    $header = array();
    $headerkey = array();
    foreach ($params as $key => $value) {
        if(in_array($value['id'], array('input', 'radio', 'checkbox', 'select', 'textarea', 'picker'))){
            $header[] = $value['params']['text'];
            $headerkey[] = $key;
        }elseif(in_array($value['id'], array('mobile'))){
            $header[] = junhua_utf82gbk(junhua_unicodeDecode('&#x624b;&#x673a;&#x53f7;'));
            $headerkey[] = $key;
        }elseif($value['id'] == 'uploader'){
            $header[] = $value['params']['text'];
            $headerkey[] = $key;
        }
    }

    $header[] = junhua_utf82gbk(junhua_unicodeDecode('&#x63d0;&#x4ea4;&#x65f6;&#x95f4;'));
    if($wnbdSetting['money']){
        $header[] = junhua_utf82gbk(junhua_unicodeDecode('&#x652f;&#x4ed8;&#x72b6;&#x6001;'));
    }

    echo diconv(implode(',', $header), CHARSET, "GB18030");

    $lists = $FormModel->select($where, '*', 'form_id asc');

    foreach ($lists as $key => $value) {
        $formParams = $value['data'];
        $formParams = dunserialize($formParams);

        $vl = array();
        foreach ($params as $k1 => $v1) {
            if(in_array($v1['id'], array('input', 'radio', 'checkbox', 'select', 'textarea', 'picker'))){
                if($v1['id'] == 'checkbox'){
                    $vl[] = str_replace(',', ';', implode(' ', $formParams[$k1]));
                }else{
                    $vl[] = str_replace(',', ';', $formParams[$k1]);
                }
            }elseif(in_array($v1['id'], array('mobile'))){
                $vl[] = str_replace(',', ';', $formParams[$k1]);
            }elseif(($v1['id'] == 'uploader')){
                $formParams[$k1] = junhua_array_map('junhua_imgsrc', $formParams[$k1]);
                $vl[] = str_replace(',', ';', implode(' ', $formParams[$k1]));
            }
        }
        $vl[] = date('Y-m-d H:i:s', $value['add_time']);
        if($wnbdSetting['money']){
            $vl[] = $value['is_pay'] ? junhua_utf82gbk(junhua_unicodeDecode('&#x5df2;&#x652f;&#x4ed8;')) : junhua_utf82gbk(junhua_unicodeDecode('&#x672a;&#x652f;&#x4ed8;'));
        }

        echo "\n".diconv(implode(",\t", $vl), CHARSET, "GB18030");
    }

    exit;

}else{
	exit;
}

$block_content = 'junhua_wnbd:mp/'.$c.'/'.$a;
include template('junhua_wnbd:mp/layout');