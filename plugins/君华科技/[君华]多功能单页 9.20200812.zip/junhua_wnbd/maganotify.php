<?php 

    define('CURSCRIPT', 'api');
    define('DISABLEXSSCHECK', true); 
    define('DISCUZROOT', substr(dirname(__FILE__), 0, -25));
    chdir(DISCUZROOT);

    define('CURMODULE', 'junhua_wnbd');

    $_GET['id'] = 'junhua_wnbd';
    
    require './source/class/class_core.php';

    $discuz = C::app();

	$cachelist = array('plugin');

	$discuz->cachelist = $cachelist;
	$discuz->init();

	//&#x8bbe;&#x7f6e;&#x65f6;&#x533a;
	@date_default_timezone_set('Etc/GMT'.($_G['setting']['timeoffset'] > 0 ? '-' : '+').(abs($_G['setting']['timeoffset'])));

	include_once('./source/plugin/junhua_base/common/common.php');
	include_once('./source/plugin/junhua_base/libs/model.class.php');
	include_once('./source/plugin/junhua_base/func/function.php');
	include_once('./source/plugin/junhua_base/libs/app.class.php');

    function junhua_zkh($a){
        return '['.$a.']';
    }

    function junhua_imp($a){
        if(is_array($a)){
            return implode(',', $a);
        }
        return $a;
    }


	$junhua_base_config		= $_G['cache']['plugin']['junhua_base'];
	$junhua_wnbd_config		= $_G['cache']['plugin']['junhua_wnbd'];

	loadcache('junhua_wnbd_setting');
	$junhua_wnbd_setting = dunserialize($_G['cache']['junhua_wnbd_setting']);

    $junhuaApp = new junhua_App($junhua_base_config, $junhua_wnbd_setting);

    $out_trade_no = junhua_I('o', '');
    $t            = junhua_I('t', '');
    $sign         = junhua_I('sign', '');

    $param = array(
        'out_trade_no' => $out_trade_no,
        't'            => $t,
        'sign'         => $sign,
    );

    if($junhuaApp->getMagaOrderVerify($param)){
        $FormModel  = new junhua_model('wnbdForm');
        $OrderModel = new junhua_model('wnbdOrder');
        $wnbdModel  = new junhua_model('wnbd');


        $orderInfo = $OrderModel->find(array(
            'is_pay'        => 0,
            'out_trade_no'  => $out_trade_no,
        ));

        if($orderInfo){
            $OrderModel->save(array(
                'order_id'      => $orderInfo['order_id']
            ),array(
                'is_pay'    => 1,
                'trade_no'  => $transaction_id,
                'pay_time'  => $_G['timestamp'],
            ));

            $formInfo = $FormModel->find(array(
                'form_id'        => $orderInfo['form_id'],
            ));

            $wnbdInfo = $wnbdModel->find(array(
                'wnbd_id'        => $orderInfo['wnbd_id'],
            ));

            $mobile = $formInfo['mobile'];

            //&#x89e3;&#x6790;&#x5168;&#x90e8;&#x7684;&#x5185;&#x5bb9;
            $params = dunserialize($wnbdInfo['params']);
            //&#x89e3;&#x6790;&#x914d;&#x7f6e;
            $wnbdSetting = dunserialize($wnbdInfo['setting']);

            //&#x53d1;&#x7ed9;&#x7528;&#x6237;&#x81ea;&#x5df1;
            $dataForm['pagetitle'] = $params['page']['params']['title'];

            $FormModel->save(array(
                'form_id'   => $orderInfo['form_id']
            ),array(
                'is_pay'   => 1,
                'pay_time' => $_G['timestamp'],
            ));


            if($wnbdSetting['submit_to_user_sms_open'] && $mobile){

                $smssetting = array(
                    'type'            => 'dayu',
                    'AccessKeyID'     => $junhua_base_config['dayu_AccessKeyID'],
                    'AccessKeySecret' => $junhua_base_config['dayu_AccessKeySecret'],
                    'TemplateCode'    => $wnbdSetting['submit_to_user_sms_dayu_TemplateCode'],
                    'FreeSignName'    => junhua_gbk2utf8($junhua_wnbd_setting['dayu_FreeSignName']),
                );


                //&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x53d8;&#x91cf;
                $submit_to_user_sms_dayu_remark = str_replace("\r", "", $wnbdSetting['submit_to_user_sms_dayu_remark']);
                $submit_to_user_sms_dayu_remark = explode("\n", $submit_to_user_sms_dayu_remark);
                $submit_to_user_sms_dayu_remark = array_filter($submit_to_user_sms_dayu_remark);

                $sms_param = array();
                foreach ($submit_to_user_sms_dayu_remark as $key => $value) {
                    $$value = trim($value);
                    $params = explode(":", $value);
                    $sms_param[trim($params[0])] = $dataForm[rtrim(ltrim($params[1], '['), ']')];
                }

                $sms_param = array_map('junhua_imp', $sms_param);

                junhua_sendsms($smssetting, $mobile, $sms_param);
            }

            //&#x53d1;&#x7ed9;&#x7ba1;&#x7406;&#x5458;
            if($wnbdSetting['submit_to_admin_sms_open'] && $wnbdSetting['submit_to_admin_mobile']){

                $smssetting = array(
                    'type'            => 'dayu',
                    'AccessKeyID'     => $junhua_base_config['dayu_AccessKeyID'],
                    'AccessKeySecret' => $junhua_base_config['dayu_AccessKeySecret'],
                    'TemplateCode'    => $wnbdSetting['submit_to_admin_sms_dayu_TemplateCode'],
                    'FreeSignName'    => junhua_gbk2utf8($junhua_wnbd_setting['dayu_FreeSignName']),
                );

                //&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x53d8;&#x91cf;
                $submit_to_admin_sms_dayu_remark = str_replace("\r", "", $wnbdSetting['submit_to_admin_sms_dayu_remark']);
                $submit_to_admin_sms_dayu_remark = explode("\n", $submit_to_admin_sms_dayu_remark);
                $submit_to_admin_sms_dayu_remark = array_filter($submit_to_admin_sms_dayu_remark);

                $sms_param = array();
                foreach ($submit_to_admin_sms_dayu_remark as $key => $value) {
                    $$value = trim($value);
                    $params = explode(":", $value);
                    $sms_param[trim($params[0])] = $dataForm[rtrim(ltrim($params[1], '['), ']')];
                }
                $sms_param = array_map('junhua_imp', $sms_param);

                $submit_to_admin_mobile = explode(',', $wnbdSetting['submit_to_admin_mobile']);
                foreach ($submit_to_admin_mobile as $key => $value) {
                    junhua_sendsms($smssetting, $value, $sms_param);
                }
            }
        }
    }
?>