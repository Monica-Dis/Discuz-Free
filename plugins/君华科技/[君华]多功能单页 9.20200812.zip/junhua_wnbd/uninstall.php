<?php 

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

C::t('common_syscache')->delete('junhua_base_system');
C::t('common_syscache')->delete('junhua_wnbd_setting');

$sql = <<<EOF
	DROP TABLE IF EXISTS `pre_junhua_wnbd`;
	DROP TABLE IF EXISTS `pre_junhua_wnbd_form`;
    DROP TABLE IF EXISTS `pre_junhua_wnbd_verify`;
	DROP TABLE IF EXISTS `pre_junhua_wnbd_order`;
EOF;


runquery($sql);
$finish = true;
?>