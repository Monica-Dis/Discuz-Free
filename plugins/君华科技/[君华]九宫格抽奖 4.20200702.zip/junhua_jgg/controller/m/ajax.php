<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!in_array($a, array('getlottery', 'getduihuan', 'hexiao', 'exchange'))){
    $a = 'index';
}

$jggModel = new junhua_model('jgg');
$logsModel = new junhua_model('jggLogs');
$GoodsModel = new junhua_model('jggGoods');
$UsernumModel = new junhua_model('jggUsernum');
$CouponModel = new junhua_model('jggCoupon');

if($a == 'getlottery'){

    if(IS_AJAX){
        $jgg_id = junhua_I('jgg_id/d', 0);
        $where = array();
        $where['jgg_id'] = $jgg_id;

        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        $jggInfo = $jggModel->find($where);

        if(!$jggInfo){
            $data = array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
            junhua_ajaxReturn($data);
        }

        if($jggInfo['is_enable'] == 0){
            $data = array('code' => 0, 'msg' => '&#x6d3b;&#x52a8;&#x4e0d;&#x5b58;&#x5728;');
            junhua_ajaxReturn($data);
        }

        //&#x5224;&#x65ad;&#x662f;&#x5426;&#x5df2;&#x7ecf;&#x53ef;&#x4ee5;&#x7ed3;&#x675f;
        if($jggInfo['start_time'] > $_G['timestamp']){
            $data = array('code' => 0, 'msg' => '&#x6d3b;&#x52a8;&#x672a;&#x5f00;&#x59cb;');
            junhua_ajaxReturn($data);
        }


        //&#x5224;&#x65ad;&#x662f;&#x5426;&#x5df2;&#x7ecf;&#x53ef;&#x4ee5;&#x7ed3;&#x675f;
        if($jggInfo['end_time'] <= $_G['timestamp']){
            $data = array('code' => 0, 'msg' => '&#x6d3b;&#x52a8;&#x5df2;&#x7ed3;&#x675f;');
            junhua_ajaxReturn($data);
        }

        if($jggInfo['today_num'] != 0 && $jggInfo['num_type'] == 0){
            //&#x5224;&#x65ad;&#x62bd;&#x5956;&#x6b21;&#x6570;
            $UsernumInfo = $UsernumModel->find(array(
                'jgg_id'    => $jgg_id,
                'user_id'    => $uid,
            ));

            if(!$UsernumInfo){
                $UsernumModel->add(array(
                    'jgg_id'     => $jgg_id,
                    'user_id'    => $uid,
                    'num'        => $jggInfo['today_num'],
                    'today_time' => date('Ymd'),
                ));
            }else{
                if($UsernumInfo['today_time'] < date('Ymd')){
                    $UsernumModel->save(array(
                        'jgg_id'     => $jgg_id,
                        'user_id'    => $uid,
                    ),array(
                        'num'        => $jggInfo['today_num'],
                        'today_time' => date('Ymd'),
                    ));
                }else{
                    if($UsernumInfo['num'] <= 0){
                        $data = array('code' => 0, 'msg' => $jggInfo['zero_text'] ? htmlspecialchars_decode($jggInfo['zero_text']) : '&#x60a8;&#x5df2;&#x8fbe;&#x5230;&#x62bd;&#x5956;&#x6b21;&#x6570;&#xff01;');
                        junhua_ajaxReturn($data);
                    }
                }
            }
        }elseif($jggInfo['num_type'] == 1){
            //&#x5224;&#x65ad;&#x62bd;&#x5956;&#x6b21;&#x6570;
            $UsernumInfo = $UsernumModel->find(array(
                'jgg_id'    => $jgg_id,
                'user_id'    => $uid,
            ));

            if(!$UsernumInfo){
                $jggnum = $jggInfo['today_num'] != 0 ? $jggInfo['today_num'] : 0;

                $UsernumModel->add(array(
                    'jgg_id'     => $jgg_id,
                    'user_id'    => $uid,
                    'num'        => $jggnum ? $jggnum: 0,
                ));

                if($jggnum <= 0){
                    $data = array('code' => 0, 'msg' => $jggInfo['zero_text'] ? htmlspecialchars_decode($jggInfo['zero_text']) : '&#x60a8;&#x5df2;&#x8fbe;&#x5230;&#x62bd;&#x5956;&#x6b21;&#x6570;&#xff01;');
                    junhua_ajaxReturn($data);
                }

            }else{
                if($UsernumInfo['num'] <= 0){
                    $data = array('code' => 0, 'msg' => $jggInfo['zero_text'] ? htmlspecialchars_decode($jggInfo['zero_text']) : '&#x60a8;&#x5df2;&#x8fbe;&#x5230;&#x62bd;&#x5956;&#x6b21;&#x6570;&#xff01;');
                    junhua_ajaxReturn($data);
                }
            }
        }

        //&#x6263;&#x79ef;&#x5206;
        if($jggInfo['point_type'] && $jggInfo['point']){
            $query = C::t('common_member_count')->fetch($uid);
            $credit = array(
                '1' => $query['extcredits1'],
                '2' => $query['extcredits2'],
                '3' => $query['extcredits3'],
                '4' => $query['extcredits4'],
                '5' => $query['extcredits5'],
                '6' => $query['extcredits6'],
                '7' => $query['extcredits7'],
                '8' => $query['extcredits8']
            );

            //&#x5224;&#x65ad;&#x79ef;&#x5206;&#x662f;&#x5426;&#x591f;
            if($jggInfo['point'] >= $credit[$jggInfo['point_type']]){
                $data = array('code' => 0, 'msg' => '&#x60a8;&#x7684;'.$_G['setting']['extcredits'][$jggInfo['point_type']]['title'].'&#x4e0d;&#x8db3;');
                junhua_ajaxReturn($data);
            }

            //&#x591f;&#x79ef;&#x5206; &#x76f4;&#x63a5;&#x6263;&#x9664;&#x79ef;&#x5206; &#x5e76;&#x4e14;&#x8ba2;&#x5355;&#x72b6;&#x6001;&#x6539;&#x6210;&#x5df2;&#x652f;&#x4ed8;
            updatemembercount($uid, array(
                $jggInfo['point_type'] => -$jggInfo['point']
            ), true, '', 0, $jggInfo['jgg_title'], $jggInfo['jgg_title'],  $jggInfo['jgg_title']);
        }

        //&#x83b7;&#x53d6;&#x914d;&#x7f6e;&#x53c2;&#x6570;
        $jgg_setting = dunserialize($jggInfo['jgg_setting']);

        $goodsLists = $GoodsModel->select(array('quantity' => array('gt', 0)), 'goods_id,goods_src,goods_price,goods_name,goods_type,goods_tishi', 'goods_id desc', 0,0,1);

        $total = 0;
        foreach ($jgg_setting as $key => $value) {
            if(isset($goodsLists[$value['goods_id']])){
                $total += $value['lottery_gl'];
            }
        }

        $proArr = array();
        foreach ($jgg_setting as $key => $value) {
            if(isset($goodsLists[$value['goods_id']])){
                $proArr[$key] = round(($value['lottery_gl'] / $total)*10000, 4) * 10000;
            }
        }

        $prize = -1; 

        //&#x6982;&#x7387;&#x6570;&#x7ec4;&#x7684;&#x603b;&#x6982;&#x7387;&#x7cbe;&#x5ea6;
        $proSum = array_sum($proArr); 

        //&#x6982;&#x7387;&#x6570;&#x7ec4;&#x5faa;&#x73af;
        foreach ($proArr as $key => $proCur) { 
            $randNum = mt_rand(1, $proSum); 
            if ($randNum <= $proCur) { 
                $prize = $key; 
                break; 
            } else { 
                $proSum -= $proCur; 
            } 
        }

        $goods_id = $jgg_setting[$prize]['goods_id'];

        $data = array(
            'jgg_id'      => $jgg_id,
            'goods_id'    => $goods_id,
            'date_time'   => date('Ymd', $_G['timestamp']),
            'add_time'    => $_G['timestamp'],
            'user_id'     => $uid,
            'prize'       => $prize,
            'prize_title' => $goodsLists[$goods_id]['goods_name'],
            'prize_type'  => $goodsLists[$goods_id]['goods_type'],
        );

        //&#x5f00;&#x59cb;&#x5224;&#x65ad;&#x662f;&#x5426;&#x662f;&#x79ef;&#x5206;&#x5546;&#x54c1;

        if($goodsLists[$goods_id]['goods_type'] == 2 && $jggInfo['point_type'] && $goodsLists[$goods_id]['goods_price']){

            //&#x591f;&#x79ef;&#x5206; &#x76f4;&#x63a5;&#x6263;&#x9664;&#x79ef;&#x5206; &#x5e76;&#x4e14;&#x8ba2;&#x5355;&#x72b6;&#x6001;&#x6539;&#x6210;&#x5df2;&#x652f;&#x4ed8;
            updatemembercount($uid, array(
                $jggInfo['point_type'] => $goodsLists[$goods_id]['goods_price']
            ), true, '', 0, $jggInfo['jgg_title'], $jggInfo['jgg_title'],  $goodsLists[$goods_id]['goods_tishi']);

            $data['is_hexiao']   = 1;
            $data['hexiao_time'] = $_G['timestamp'];
            $data['hexiao_uid']  = 1;

        }

        //&#x8bb0;&#x5f55;&#x5165;&#x5e93;
        $logsModel->add($data);

        $GoodsModel->setDec(array('goods_id' => $goods_id), 'quantity');

        $UsernumModel->setDec(array(
            'jgg_id'     => $jgg_id,
            'user_id'    => $uid,
        ),'num');


        $data = array('code' => 2, 'msg' => $prize == -1 ? '&#x611f;&#x8c22;&#x60a8;&#x7684;&#x53c2;&#x4e0e;' : $goodsLists[$goods_id]['goods_tishi'] , 'prize' => $prize);
        junhua_ajaxReturn($data);

    }else{
        exit;
    }
}elseif ($a == 'getduihuan') {
    if(IS_AJAX){
        $log_id = junhua_I('log_id/d', 0);

        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }


        $logInfo = $logsModel->find(array(
            'log_id'     => $log_id,
            'user_id'    => $uid,
            'prize_type' => array('neq', 0)
        ));

        if(!$logInfo){
            $data = array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
            junhua_ajaxReturn($data);
        }

        if($logInfo['is_hexiao'] == 1){
            $data = array('code' => 0, 'msg' => '&#x60a8;&#x5df2;&#x6838;&#x9500;');
            junhua_ajaxReturn($data);
        }

        //&#x672a;&#x6838;&#x9500; &#x751f;&#x6210;&#x4e8c;&#x7ef4;&#x7801;
        $sign = md5($logInfo['log_id'].$logInfo['jgg_id'].$logInfo['user_id'].$logInfo['prize'].$logInfo['prize_title'].$logInfo['prize_type'].$logInfo['date_time']);

        $data = array('code' => 2, 'url' => junhua_url('m/jgg/hexiao', 'log_id='.$log_id.'&sign='.$sign, 1));
        junhua_ajaxReturn($data);
        
    }
}elseif($a == 'hexiao'){

    if(IS_AJAX){
        $log_id = junhua_I('log_id/d', 0);
        $sign   = junhua_I('sign', '');

        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }


        $where = array();
        $where['log_id'] = $log_id;

        //&#x67e5;&#x8be2;&#x4e2d;&#x5956;&#x4fe1;&#x606f;
        $logInfo = $logsModel->find($where);
        if(!$logInfo){
            $data = array('code' => 0, 'msg' => '&#x65e0;&#x6b64;&#x4fe1;&#x606f;');
            junhua_ajaxReturn($data);
        }


        $jggInfo = $jggModel->find(array('jgg_id' => $logInfo['jgg_id']));
        if(!$jggInfo){
            $data = array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
            junhua_ajaxReturn($data);
        }


        $md5sign = md5($logInfo['log_id'].$logInfo['jgg_id'].$logInfo['user_id'].$logInfo['prize'].$logInfo['prize_title'].$logInfo['prize_type'].$logInfo['date_time']);

        if($sign != $md5sign){
            $data = array('code' => 0, 'msg' => '&#x975e;&#x6cd5;&#x6838;&#x9500;&#x7801;');
            junhua_ajaxReturn($data);
        }

        //&#x5224;&#x65ad;&#x6743;&#x9650;
        $uids = explode(",", $jggInfo['jgg_hexiao']);
        if( !in_array($uid, $uids)){
            $data = array('code' => 0, 'msg' => '&#x60a8;&#x65e0;&#x6743;&#x6838;&#x9500;');
            junhua_ajaxReturn($data);
        }

        if($logInfo['is_hexiao']){
            $data = array('code' => 0, 'msg' => '&#x5df2;&#x6838;&#x9500;');
            junhua_ajaxReturn($data);
        }

        //&#x6838;&#x9500;&#x901a;&#x8fc7;
        $logsModel->save($where, array('hexiao_time' => $_G['timestamp'], 'is_hexiao' => 1, 'hexiao_uid' => $uid));

        $data = array('code' => 2, 'msg' => '&#x6838;&#x9500;&#x6210;&#x529f;');
        junhua_ajaxReturn($data);

    }else{
        exit;
    }


}elseif($a == 'exchange'){

    if(IS_AJAX){
        $code   = junhua_I('code', '');

        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        if(!$code){
            $data = array('code' => 0, 'msg' => '&#x8bf7;&#x586b;&#x5199;&#x5151;&#x6362;&#x7801;');
            junhua_ajaxReturn($data);
        }

        $where = array();
        $where['coupon_code'] = $code;

        //&#x67e5;&#x8be2;&#x4e2d;&#x5956;&#x4fe1;&#x606f;
        $couponInfo = $CouponModel->find($where);
        if(!$couponInfo){
            $data = array('code' => 0, 'msg' => '&#x65e0;&#x6b64;&#x5151;&#x6362;&#x7801;');
            junhua_ajaxReturn($data);
        }

        if($couponInfo['is_use']){
            $data = array('code' => 0, 'msg' => '&#x5151;&#x6362;&#x7801;&#x5df2;&#x88ab;&#x4f7f;&#x7528;');
            junhua_ajaxReturn($data);
        }

        if($couponInfo['last_time'] < $_G['timestamp']){
            $data = array('code' => 0, 'msg' => '&#x5151;&#x6362;&#x7801;&#x5df2;&#x8fc7;&#x671f;');
            junhua_ajaxReturn($data);
        }

        $jggInfo = $jggModel->find(array(
            'jgg_id'       => $couponInfo['jgg_id']
        ));

        if(!$jggInfo){
            $data = array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
            junhua_ajaxReturn($data);
        }

        if($jggInfo['today_num'] != 0 && $jggInfo['num_type'] == 0){
            //&#x5224;&#x65ad;&#x62bd;&#x5956;&#x6b21;&#x6570;
            $UsernumInfo = $UsernumModel->find(array(
                'jgg_id'    => $couponInfo['jgg_id'],
                'user_id'    => $uid,
            ));

            if(!$UsernumInfo){
                $UsernumModel->add(array(
                    'jgg_id'     => $couponInfo['jgg_id'],
                    'user_id'    => $uid,
                    'num'        => $jggInfo['today_num'],
                    'today_time' => date('Ymd'),
                ));
            }else{
                if($UsernumInfo['today_time'] < date('Ymd')){
                    $UsernumModel->save(array(
                        'jgg_id'     => $couponInfo['jgg_id'],
                        'user_id'    => $uid,
                    ),array(
                        'num'        => $jggInfo['today_num'],
                        'today_time' => date('Ymd'),
                    ));
                }
            }
        }elseif($jggInfo['num_type'] == 1){
            //&#x5224;&#x65ad;&#x62bd;&#x5956;&#x6b21;&#x6570;
            $UsernumInfo = $UsernumModel->find(array(
                'jgg_id'    => $couponInfo['jgg_id'],
                'user_id'    => $uid,
            ));

            if(!$UsernumInfo){
                $jggnum = $jggInfo['today_num'] != 0 ? $jggInfo['today_num'] : 0;

                $UsernumModel->add(array(
                    'jgg_id'     => $couponInfo['jgg_id'],
                    'user_id'    => $uid,
                    'num'        => $jggnum,
                ));

            }
        }

        //&#x6838;&#x9500;&#x901a;&#x8fc7;
        $UsernumModel->setInc(array(
            'user_id' => $uid,
            'jgg_id'  => $couponInfo['jgg_id'],
        ), 'num', $couponInfo['coupon_num']);

        //&#x6838;&#x9500;&#x901a;&#x8fc7;
        $CouponModel->save(array(
            'coupon_id' => $couponInfo['coupon_id'],
            'jgg_id'  => $couponInfo['jgg_id'],
        ), array('user_id' => $uid, 'is_use' => 1, 'use_time' => $_G['timestamp']));

        $data = array('code' => 2, 'msg' => '&#x5151;&#x6362;&#x6210;&#x529f;', 'url' => junhua_url('m/jgg/detail', 'jgg_id='.$couponInfo['jgg_id'], 1));
        junhua_ajaxReturn($data);

    }else{
        exit;
    }


}
else{
	exit;
}