<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!in_array($a, array('detail', 'qr', 'hexiao', 'exchange', 'link'))){
    $a = 'detail';
}

set_time_limit(0);

$jggModel     = new junhua_model('jgg');
$logsModel    = new junhua_model('jggLogs');
$GoodsModel   = new junhua_model('jggGoods');
$LinkModel    = new junhua_model('jggLink');
$LinkLogModel = new junhua_model('jggLinkLog');
$UsernumModel = new junhua_model('jggUsernum');

//&#x5f00;&#x542f;&#x5206;&#x4eab;
$junhua_shareurl = $refererurl;

//&#x5f00;&#x542f;&#x5206;&#x4eab;
if(IS_WEIXIN){
    include_once('source/plugin/junhua_base/jssdk/weixin_jssdk.php');

    $weixin_appid = $junhua_jgg_setting['weixin_appid'] ? trim($junhua_jgg_setting['weixin_appid']) : trim($junhua_base_config['weixin_appid']);
    $weixin_appsecret = $junhua_jgg_setting['weixin_appsecret'] ? trim($junhua_jgg_setting['weixin_appsecret']) : trim($junhua_base_config['weixin_appsecret']);
    if($weixin_appid && $weixin_appsecret){
        $jssdk = new WEIXIN_JSSDK($weixin_appid, $weixin_appsecret);
        $signPackage = $jssdk->getSignPackage();
    }
}

//&#x70ae;&#x7070;
if($junhua_jgg_setting['weixin_paohui_url']){
    $paohuiUrl = explode("\n", $junhua_jgg_setting['weixin_paohui_url']);
    $junhua_shareurl = str_replace($_G['siteurl'], $paohuiUrl[array_rand($paohuiUrl)]."/", $junhua_shareurl);
}

$junhuaApp = new junhua_App($junhua_base_config, $junhua_jgg_setting);

//&#x83b7;&#x53d6;&#x9a6c;&#x7532;&#x767b;&#x5f55;
if(IS_MAGA){
    if(!$uid){

        $r = $junhuaApp->getMagaUserInfo();

        if($r['data']['user_id'] > 0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }

            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
        }
    }
}elseif(IS_QF){
    if(!$uid){

        $r = $junhuaApp->getQfUserInfo();

        if($r['data']['id'] > 0){

            $member = getuserbyuid($r['data']['id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }

            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            exit('<script>window.location.reload(true);</script>');
        }
    }
}

if($a == 'detail'){
    $jgg_id = junhua_I('jgg_id/d', 0);
    $jggInfo = $jggModel->find(array('jgg_id' => $jgg_id, 'is_enable' => 1));
    if(!$jggInfo){
        exit;
    }

    $jggInfo['show_lucknum'] = $jggInfo['show_lucknum'] ? $jggInfo['show_lucknum'] : 10;

    //&#x83b7;&#x53d6;&#x914d;&#x7f6e;&#x53c2;&#x6570;
    $jgg_setting = dunserialize($jggInfo['jgg_setting']);

    //&#x83b7;&#x53d6;&#x5168;&#x90e8;&#x7684;&#x5546;&#x54c1;
    $goodsLists = $GoodsModel->select(array(), 'goods_id,goods_src,goods_name', 'goods_id desc', 0,0,1);

    //&#x83b7;&#x53d6;&#x6211;&#x7684;&#x4e2d;&#x5956;&#x7eaa;&#x5f55;
    $mylist = $logsModel->select(array(
        'user_id'    => $uid,
        'jgg_id'     => $jgg_id,
        'prize_type' => array('neq', 0)
    ), '*', 'log_id asc');

    //&#x83b7;&#x53d6;&#x5168;&#x90e8;&#x7684;&#x4e2d;&#x5956;&#x7eaa;&#x5f55;
    $lucklist = $logsModel->alias('l')->join('left join __JUNHUA_JGG_GOODS__ as g on l.goods_id = g.goods_id')->select(array(
        'jgg_id'     => $jgg_id,
        'l.prize_type' => array('neq', 0),
        'g.is_showluck' => 1,
    ), 'l.*', 'log_id desc', 0, $jggInfo['show_lucknum']);

    $uids = array();
    foreach ($lucklist as $key => $value) {
        $uids[] = $value['user_id'];
    }

    $users = C::t('common_member')->fetch_all_username_by_uid($uids);

}elseif($a == 'hexiao'){
    $log_id = junhua_I('log_id/d', 0);
    $sign   = junhua_I('sign', '');

    $logInfo = $logsModel->find(array('log_id' => $log_id));
    if(!$logInfo){
        exit;
    }

    if(!$uid){
        dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
        exit();
    }

    $jggInfo = $jggModel->find(array('jgg_id' => $logInfo['jgg_id']));
    if(!$jggInfo){
        exit;
    }

    $md5sign = md5($logInfo['log_id'].$logInfo['jgg_id'].$logInfo['user_id'].$logInfo['prize'].$logInfo['prize_title'].$logInfo['prize_type'].$logInfo['date_time']);

    if($sign != $md5sign){
        exit('&#x975e;&#x6cd5;&#x6838;&#x9500;&#x7801;');
    }

    //&#x5224;&#x65ad;&#x6743;&#x9650;
    $uids = explode(",", $jggInfo['jgg_hexiao']);

    if(!in_array($uid, $uids)){
        dheader('location:' . junhua_url('m/jgg/detail', 'jgg_id='.$logInfo['jgg_id'], 1));
        exit;
    }

}elseif($a == 'exchange'){
    $code = junhua_I('code', '');

}elseif($a == 'qr'){

    include_once('source/plugin/junhua_base/libs/qrcode.class.php');

    $url = junhua_I('url', '');
    $url = urldecode($url);
    $url = htmlspecialchars_decode($url);
    if($url){
        QRcode::png($_G['siteurl'].$url, false, 'L', 6, 2);
    }
    exit;
}elseif($a == 'link'){

    //&#x5224;&#x65ad;&#x767b;&#x5f55;
    if(IS_MAGA){
        if(!$uid){
            exit('<script src="https://static.app1.magcloud.net/public/static/dest/js/libs/magjs-x.js"></script><script>
                mag.toLogin(function(){
                    top.location.href="' . $refererurl . '";
                    mag.newWin(\''.$refererurl.'\');
                    mag.setPageLife({
                        pageAppear: function(){
                            window.location.reload(true);
                        },
                        pageDisappear: function(){}
                    });
                });
                </script>'); 
        }
    }elseif(IS_QF){
        if(!$uid){
            exit('<script>
            function QFH5ready(){
                QFH5.jumpLogin(function(state, data){
                    window.location.reload(true);
                });
            }
            </script>'); 
        }
    }else{
        if(!$uid){
            dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
            exit();
        }
    }


    $jgg_id = junhua_I('jgg_id/d', 0);
    $code   = junhua_I('code', '');

    //&#x5224;&#x65ad;&#x662f;&#x5426;&#x6709;&#x8fd9;&#x4e2a;code
    $linkInfo = $LinkModel->find(array(
        'jgg_id'      => $jgg_id,
        'link_code'   => $code,
    ));

    //&#x5b58;&#x5728; &#x53ef;&#x589e;&#x52a0;
    if($linkInfo['expiry_time'] >= $_G['timestamp']){
        //&#x5224;&#x65ad;&#x6b21;&#x6570;&#x662f;&#x5426;&#x5df2;&#x7ecf;&#x8fbe;&#x5230;&#x4e0a;&#x9650;
        $count = $LinkLogModel->count(array(
            'jgg_id'    => $jgg_id,
            'link_code' => $code,
            'user_id'   => $uid,
        ));

        if($count < $linkInfo['link_num']){
            //&#x63d2;&#x5165;&#x8bb0;&#x5f55; &#x5e76;&#x4e14;&#x589e;&#x52a0;&#x6b21;&#x6570;

            $data = array(
                'link_id'   => $linkInfo['link_id'],
                'user_id'   => $uid,
                'jgg_id'    => $linkInfo['jgg_id'],
                'link_code' => $linkInfo['link_code'],
                'add_time'  => $_G['timestamp'],
            );

            $LinkLogModel->add($data);


            //&#x589e;&#x52a0;&#x6b21;&#x6570;
            $UsernumModel->setInc(array(
                'jgg_id'     => $linkInfo['jgg_id'],
                'user_id'    => $uid,
            ),'num', $linkInfo['link_num']);
        }

        dheader('location:' . junhua_url('m/jgg/detail', 'jgg_id='.$linkInfo['jgg_id'], 1));
        exit;
    }else{
        if($linkInfo['jgg_id']){
            dheader('location:' . junhua_url('m/jgg/detail', 'jgg_id='.$linkInfo['jgg_id'], 1));
        }else{
            exit;
        }
    }
}
else{
    exit;
}

$block_content = 'junhua_jgg:m/'.$c.'/'.$a;

include template($block_content);