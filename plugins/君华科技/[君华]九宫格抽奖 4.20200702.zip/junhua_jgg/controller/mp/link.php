<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once('common.php');

if(!in_array($a, array('add', 'del', 'export'))){
    $a = 'index';
}

$LinkModel = new junhua_model('jggLink');
$jggModel = new junhua_model('jgg');
$jggLists = $jggModel->select(array(), 'jgg_id,jgg_title', 'jgg_id desc', 0,0, 1);

if($a == 'index'){
    $page      = junhua_I('page/d', 1);
    $perpage   = junhua_I('perpage/d', 10);
    $is_use    = junhua_I('is_use/d', '');
    $user_id   = junhua_I('user_id/d', '');
    $link_code = junhua_I('link_code', '');
    $jgg_id    = junhua_I('jgg_id/d', '');

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $where = array();

    $param['perpage'] = $perpage;

    if($jgg_id){
        $param['jgg_id'] = $jgg_id;
        $where['jgg_id'] = $jgg_id;
    }

    if($link_code){
        $param['link_code'] = $link_code;
        $where['link_code'] = $link_code;
    }

    if($user_id){
        $param['user_id'] = $user_id;
        $where['user_id'] = $user_id;
    }

    if($is_use){
        $param['is_use'] = $is_use;
        $where['is_use'] = $is_use;
    }

    $theurl = junhua_url('mp/link/index', http_build_query($param), true);
    $totalNum = $LinkModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $LinkModel->select($where, '*', 'link_id desc', $start, $perpage);

    $exportUrl = junhua_url('mp/link/export', http_build_query($param), 1);


    $block_head_title = '&#x94fe;&#x63a5;&#x7ba1;&#x7406;';
    $block_title = '&#x94fe;&#x63a5;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {
    
    if(IS_AJAX){
        
        $jgg_id    = junhua_I('jgg_id/d', 0);
        $link_num  = junhua_I('link_num/d', 0);
        $use_num   = junhua_I('use_num/d', 0);
        $link_code = junhua_I('link_code', '');
        $last_time = junhua_I('last_time/d', 0);

        $last_time = strtotime(date('Y-m-d', $_G['timestamp']). ' 23:59:59') + 86400*$last_time;

        //&#x5224;&#x65ad;&#x7279;&#x5f81;&#x7801;&#x662f;&#x5426;&#x5df2;&#x5b58;&#x5728;
        $linkInfo = $LinkModel->find(array(
            'jgg_id'      => $jgg_id,
            'link_code'   => $link_code,
        ));

        if($linkInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x7279;&#x5f81;&#x7801;&#x5df2;&#x5b58;&#x5728;'));
        }

        $data = array(
            'jgg_id'      => $jgg_id,
            'link_code'   => $link_code,
            'link_num'    => $link_num,
            'use_num'     => $use_num,
            'expiry_time' => $last_time,
            'add_time'    => $_G['timestamp'],
        );

        $LinkModel->add($data);

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/link/index', '', true)));
    }

    $block_head_title = '&#x94fe;&#x63a5;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x94fe;&#x63a5;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'del'){
    if(IS_AJAX){
        $link_id = junhua_I('link_id/d', 0);

        $where = array(
            'link_id'      => $link_id
        );

        $linkInfo = $LinkModel->find($where);
        if(!$linkInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $LinkModel->delete($where);

        junhua_ajaxReturn(array('status' => 1));
    }
}
else{
    exit;
}

$block_content = 'junhua_jgg:mp/'.$c.'/'.$a;

include template('junhua_jgg:mp/layout');