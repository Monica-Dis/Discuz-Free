<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$privs = array();
$privs['01'] = array('id' => '01', 'name' => '&#x5956;&#x54c1;', 'url' => junhua_url('mp/goods/index', '', 1), 'in_menu' => '');
$privs['01']['menu_list'] = array(
        array('id'=> '0101', 'name' => '&#x6dfb;&#x52a0;&#x5956;&#x54c1;', 'url' => junhua_url('mp/goods/add', '', 1), 'in_menu' => '0102'),
        array('id'=> '0102', 'name' => '&#x5956;&#x54c1;&#x5217;&#x8868;', 'url' => junhua_url('mp/goods/index', '', 1), 'in_menu' => ''),
        array('id'=> '0103', 'name' => '&#x7f16;&#x8f91;&#x5956;&#x54c1;', 'url' => junhua_url('mp/goods/edit', '', 1), 'in_menu' => '0102'),
        array('id'=> '0104', 'name' => '&#x5220;&#x9664;&#x5956;&#x54c1;', 'url' => junhua_url('mp/goods/del', '', 1), 'in_menu' => '0102'),
        array('id'=> '0105', 'name' => '&#x8bbe;&#x7f6e;&#x5e78;&#x8fd0;&#x663e;&#x793a;', 'url' => junhua_url('mp/goods/showluck', '', 1), 'in_menu' => '0102'),
);

$privs['02'] = array('id' => '02', 'name' => '&#x62bd;&#x5956;', 'url' => junhua_url('mp/jgg/index', '', 1), 'in_menu' => '');
$privs['02']['menu_list'] = array(
        array('id'=> '0201', 'name' => '&#x6dfb;&#x52a0;&#x62bd;&#x5956;', 'url' => junhua_url('mp/jgg/add', '', 1), 'in_menu' => '0202'),
        array('id'=> '0202', 'name' => '&#x62bd;&#x5956;&#x5217;&#x8868;', 'url' => junhua_url('mp/jgg/index', '', 1), 'in_menu' => ''),
        array('id'=> '0203', 'name' => '&#x7f16;&#x8f91;&#x62bd;&#x5956;', 'url' => junhua_url('mp/jgg/edit', '', 1), 'in_menu' => '0202'),
        array('id'=> '0204', 'name' => '&#x5220;&#x9664;&#x62bd;&#x5956;', 'url' => junhua_url('mp/jgg/del', '', 1), 'in_menu' => '0202'),
        array('id'=> '0205', 'name' => '&#x542f;&#x7528;/&#x7981;&#x7528;&#x62bd;&#x5956;', 'url' => junhua_url('mp/jgg/set', '', 1), 'in_menu' => '0202'),
        array('id'=> '0206', 'name' => '&#x9009;&#x9879;&#x914d;&#x7f6e;', 'url' => junhua_url('mp/jgg/setting', '', 1), 'in_menu' => '0202'),
        array('id'=> '0207', 'name' => '&#x62bd;&#x5956;&#x5217;&#x8868;', 'url' => junhua_url('mp/jgg/logs', '', 1), 'in_menu' => '0202'),
        array('id'=> '0208', 'name' => '&#x5220;&#x9664;&#x65e5;&#x5fd7;', 'url' => junhua_url('mp/jgg/del_logs', '', 1), 'in_menu' => '0202'),
        array('id'=> '0209', 'name' => '&#x4e2d;&#x5956;&#x5217;&#x8868;', 'url' => junhua_url('mp/jgg/lucky', '', 1), 'in_menu' => '0202'),
        array('id'=> '0210', 'name' => '&#x4e2d;&#x5956;&#x5ba1;&#x6838;', 'url' => junhua_url('mp/jgg/shenhe', '', 1), 'in_menu' => '0202'),
);

$privs['03'] = array('id' => '03', 'name' => '&#x5361;&#x5238;', 'url' => junhua_url('mp/coupon/index', '', 1), 'in_menu' => '');
$privs['03']['menu_list'] = array(
        array('id'=> '0301', 'name' => '&#x6dfb;&#x52a0;&#x5361;&#x5238;', 'url' => junhua_url('mp/coupon/add', '', 1), 'in_menu' => '0302'),
        array('id'=> '0302', 'name' => '&#x5361;&#x5238;&#x5217;&#x8868;', 'url' => junhua_url('mp/coupon/index', '', 1), 'in_menu' => ''),
        array('id'=> '0303', 'name' => '&#x5220;&#x9664;&#x5361;&#x5238;', 'url' => junhua_url('mp/coupon/del', '', 1), 'in_menu' => '0302'),
        array('id'=> '0304', 'name' => '&#x5bfc;&#x51fa;&#x5361;&#x5238;', 'url' => junhua_url('mp/coupon/export', '', 1), 'in_menu' => '0302'),
);

$privs['04'] = array('id' => '04', 'name' => '&#x94fe;&#x63a5;', 'url' => junhua_url('mp/link/index', '', 1), 'in_menu' => '');
$privs['04']['menu_list'] = array(
        array('id'=> '0401', 'name' => '&#x6dfb;&#x52a0;&#x94fe;&#x63a5;', 'url' => junhua_url('mp/link/add', '', 1), 'in_menu' => '0402'),
        array('id'=> '0402', 'name' => '&#x94fe;&#x63a5;&#x5217;&#x8868;', 'url' => junhua_url('mp/link/index', '', 1), 'in_menu' => ''),
);


$privs['20'] = array('id' => '20', 'name' => '&#x914d;&#x7f6e;', 'url' => junhua_url('mp/setting/index', '', 1), 'in_menu' => '');
$privs['20']['menu_list'] = array(
        array('id'=> '2001', 'name' => '&#x7cfb;&#x7edf;&#x8bbe;&#x7f6e;', 'url' => junhua_url('mp/setting/index', '', 1), 'in_menu' => ''),
);