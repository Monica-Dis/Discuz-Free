<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once('common.php');

if(!in_array($a, array('add', 'edit', 'del', 'showluck'))){
    $a = 'index';
}

$GoodsModel = new junhua_model('jggGoods');

if($a == 'index'){
    $page    = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);
    $good_id = junhua_I('good_id/d', '');

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $where = array();

    $param['perpage'] = $perpage;

    if($good_id){
        $param['good_id'] = $good_id;
        $where['good_id'] = $good_id;
    }

    $theurl = junhua_url('mp/goods/index', http_build_query($param), true);
    $totalNum = $GoodsModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $GoodsModel->select($where, '*', 'goods_id desc', $start, $perpage);

    $block_head_title = '&#x5956;&#x54c1;&#x7ba1;&#x7406;';
    $block_title = '&#x5956;&#x54c1;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {

    
	if(IS_AJAX){
        
        $goods_name  = junhua_I('goods_name', '');
        $goods_src   = junhua_I('goods_src', '');
        $goods_tishi = junhua_I('goods_tishi', '');
        $goods_price = junhua_I('goods_price/f', 0);
        $goods_type  = junhua_I('goods_type/d', 0);
        $quantity    = junhua_I('quantity/d', 0);

        $data = array(
            'goods_name'  => $goods_name,
            'goods_src'   => $goods_src,
            'goods_tishi' => $goods_tishi,
            'goods_type'  => $goods_type,
            'goods_price' => $goods_price,
            'quantity'    => $quantity,
            'add_time'    => $_G['timestamp'],
            'update_time' => $_G['timestamp'],
        );

        $GoodsModel->add($data);

	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/goods/index', '', true)));
	}

    $block_head_title = '&#x5956;&#x54c1;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x5956;&#x54c1;';
    $block_css = '';
    $a = 'update';
}elseif ($a == 'edit') {

	$goods_id = junhua_I('goods_id/d', 0);

	$where = array('goods_id' => $goods_id);
	$goodsInfo = $GoodsModel->find($where);

	if(!$goodsInfo){
        dheader('location:' . junhua_url('mp/goods/index', '', 1));
        exit;
	}

	if(IS_AJAX){

        $goods_name  = junhua_I('goods_name', '');
        $goods_src   = junhua_I('goods_src', '');
        $goods_tishi = junhua_I('goods_tishi', '');
        $goods_price = junhua_I('goods_price/f', 0);
        $goods_type  = junhua_I('goods_type/d', 0);
        $quantity    = junhua_I('quantity/d', 0);

        $data = array(
            'goods_name'  => $goods_name,
            'goods_src'   => $goods_src,
            'goods_tishi' => $goods_tishi,
            'goods_type'  => $goods_type,
            'goods_price' => $goods_price,
            'quantity'    => $quantity,
            'update_time' => $_G['timestamp'],
        );

		$GoodsModel->save($where, $data);

	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/goods/index', '', 1)));
	}

    $block_head_title = '&#x5956;&#x54c1;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x5956;&#x54c1;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'del'){
    if(IS_AJAX){
        $goods_id = junhua_I('goods_id/d', 0);

        $where = array(
            'goods_id'      => $goods_id
        );

        $goodsInfo = $GoodsModel->find($where);
        if(!$goodsInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $GoodsModel->delete($where);

        $ContentModel->delete(array(
            'goods_id'   => $goodsInfo['goods_id']
        ));

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif ($a == 'showluck'){
    if(IS_AJAX){
        $goods_id = junhua_I('goods_id/d', 0);

        $where = array(
            'goods_id'      => $goods_id
        );

        $goodsInfo = $GoodsModel->find($where);
        if(!$goodsInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($goodsInfo['is_showluck'] == 1){
            $is_showluck = 0;
        }else{
            $is_showluck = 1;
        }

        $GoodsModel->save($where, array('is_showluck' => $is_showluck));

        junhua_ajaxReturn(array('status' => 1));
    }
}
else{
	exit;
}

$block_content = 'junhua_jgg:mp/'.$c.'/'.$a;

include template('junhua_jgg:mp/layout');