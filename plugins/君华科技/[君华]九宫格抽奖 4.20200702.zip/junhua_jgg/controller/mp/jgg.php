<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once('common.php');

if(!in_array($a, array('add', 'edit',  'setting', 'del', 'index', 'set',
'logs', 'del_logs', 'lucky', 'shenhe'
))){
    $a = 'index';
}

$jggModel = new junhua_model('jgg');
$logsModel = new junhua_model('jggLogs');
$GoodsModel = new junhua_model('jggGoods');

if($a == 'index'){

    $page = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $theurl = junhua_url('mp/jgg/index', http_build_query($param), true);


    $where = array();
    $totalNum = $jggModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $jggModel->select($where, '*', 'jgg_id desc', $start, $perpage);

    $block_head_title = '&#x62bd;&#x5956;&#x7ba1;&#x7406;';
    $block_title = '&#x62bd;&#x5956;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {
	if(IS_AJAX){
        
        $jgg_title    = junhua_I('jgg_title', '');
        $jgg_src      = junhua_I('jgg_src', '');
        $jgg_hexiao   = junhua_I('jgg_hexiao', '');
        $start_time   = junhua_I('start_time', '');
        $end_time     = junhua_I('end_time', '');
        $today_num    = junhua_I('today_num/d', 0);
        $point_type   = junhua_I('point_type/d', 0);
        $point        = junhua_I('point/d', 0);
        $num_type     = junhua_I('num_type/d', 0);
        $is_mustapp   = junhua_I('is_mustapp/d', 0);
        $share_title  = junhua_I('share_title', '');
        $share_desc   = junhua_I('share_desc', '');
        $share_img    = junhua_I('share_img', '');
        $jgg_content  = junhua_I('jgg_content', '');
        $background   = junhua_I('background', '');
        $zero_text    = junhua_I('zero_text', '');
        $app_text     = junhua_I('app_text', '');
        $bg1          = junhua_I('bg1', '');
        $bg2          = junhua_I('bg2', '');
        $btn_bg       = junhua_I('btn_bg', '');
        $show_lucknum = junhua_I('show_lucknum/d', 10);
        $start_time  = strtotime($start_time);
        $end_time    = strtotime($end_time);


		$data = array(
            'jgg_title'    => $jgg_title,
            'jgg_src'      => $jgg_src,
            'jgg_hexiao'   => $jgg_hexiao,
            'start_time'   => $start_time,
            'end_time'     => $end_time,
            'today_num'    => $today_num,
            'point_type'   => $point_type,
            'point'        => $point,
            'num_type'     => $num_type,
            'is_mustapp'   => $is_mustapp,
            'share_title'  => $share_title,
            'share_desc'   => $share_desc,
            'share_img'    => $share_img,
            'jgg_content'  => $jgg_content,
            'background'   => $background,
            'zero_text'    => $zero_text,
            'app_text'     => $app_text,
            'bg1'          => $bg1,
            'bg2'          => $bg2,
            'btn_bg'       => $btn_bg,
            'show_lucknum' => $show_lucknum,
            'add_time'     => $_G['timestamp'],
            'update_time'  => $_G['timestamp'],
            'is_enable'    => 1,
		);

		$jgg_id = $jggModel->add($data);

	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/jgg/setting', 'jgg_id='.$jgg_id, true)));
	}

    $block_head_title = '&#x62bd;&#x5956;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x62bd;&#x5956;';
    $block_css = '';
    $a = 'update';
}elseif ($a == 'edit') {

    $jgg_id = junhua_I('jgg_id/d', 0);

    $where = array('jgg_id' => $jgg_id);
    $jggInfo = $jggModel->find($where);

    if(!$jggInfo){
        dheader('location:' . junhua_url('mp/jgg/index', '', 1));
        exit;
    }

    if(IS_AJAX){
        
        $jgg_title    = junhua_I('jgg_title', '');
        $jgg_src      = junhua_I('jgg_src', '');
        $jgg_hexiao   = junhua_I('jgg_hexiao', '');
        $start_time   = junhua_I('start_time', '');
        $end_time     = junhua_I('end_time', '');
        $today_num    = junhua_I('today_num/d', 0);
        $point_type   = junhua_I('point_type/d', 0);
        $point        = junhua_I('point/d', 0);
        $num_type     = junhua_I('num_type/d', 0);
        $is_mustapp   = junhua_I('is_mustapp/d', 0);
        $share_title  = junhua_I('share_title', '');
        $share_desc   = junhua_I('share_desc', '');
        $share_img    = junhua_I('share_img', '');
        $jgg_content  = junhua_I('jgg_content', '');
        $background   = junhua_I('background', '');
        $zero_text    = junhua_I('zero_text', '');
        $app_text     = junhua_I('app_text', '');
        $bg1          = junhua_I('bg1', '');
        $bg2          = junhua_I('bg2', '');
        $btn_bg       = junhua_I('btn_bg', '');
        $show_lucknum = junhua_I('show_lucknum/d', 10);
        $start_time = strtotime($start_time);
        $end_time   = strtotime($end_time);

        $data = array(
            'jgg_title'    => $jgg_title,
            'jgg_src'      => $jgg_src,
            'jgg_hexiao'   => $jgg_hexiao,
            'start_time'   => $start_time,
            'end_time'     => $end_time,
            'today_num'    => $today_num,
            'point_type'   => $point_type,
            'point'        => $point,
            'num_type'     => $num_type,
            'is_mustapp'   => $is_mustapp,
            'share_title'  => $share_title,
            'share_desc'   => $share_desc,
            'share_img'    => $share_img,
            'jgg_content'  => $jgg_content,
            'background'   => $background,
            'zero_text'    => $zero_text,
            'app_text'     => $app_text,
            'bg1'          => $bg1,
            'bg2'          => $bg2,
            'btn_bg'       => $btn_bg,
            'show_lucknum' => $show_lucknum,
            'update_time'  => $_G['timestamp'],
        );

        $jggModel->save($where, $data);
        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/jgg/index', '', 1)));
    }

    $jggInfo['start_time'] = $jggInfo['start_time'] ? date('Y-m-d H:i:s', $jggInfo['start_time']) : '';
    $jggInfo['end_time']   = $jggInfo['end_time'] ? date('Y-m-d H:i:s', $jggInfo['end_time']) : '';

    $block_head_title = '&#x62bd;&#x5956;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x62bd;&#x5956;';
    $block_css = '';
    $a = 'update';
}elseif ($a == 'setting') {

	$jgg_id = junhua_I('jgg_id/d', 0);

	$where = array('jgg_id' => $jgg_id);
	$jggInfo = $jggModel->find($where);

	if(!$jggInfo){
        dheader('location:' . junhua_url('mp/jgg/index', '', 1));
        exit;
	}

	if(IS_AJAX){

        $jgg_setting   = junhua_I('setting/a', array());

		$data = array(
            'jgg_setting'   => serialize($jgg_setting),
		);

		$jggModel->save($where, $data);
	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/jgg/index', '', 1)));
	}

    $setting = dunserialize($jggInfo['jgg_setting']);

    $total = 0;
    foreach ($setting as $key => $value) {
        $total += $value['lottery_gl'];
    }

    //&#x83b7;&#x53d6;&#x5168;&#x90e8;&#x7684;&#x5546;&#x54c1;
    $goodsLists = $GoodsModel->select(array(), '*', 'goods_id desc');

    $block_head_title = '&#x62bd;&#x5956;&#x7ba1;&#x7406;';
    $block_title = '&#x62bd;&#x5956;&#x9009;&#x9879;';
    $block_css = '';
}elseif ($a == 'del'){
    if(IS_AJAX){
        $jgg_id = junhua_I('jgg_id/d', 0);

        $where = array(
            'jgg_id'      => $jgg_id
        );

        $jggInfo = $jggModel->find($where);
        if(!$jggInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $jggModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}elseif ($a == 'set'){
    if(IS_AJAX){
        $jgg_id = junhua_I('jgg_id/d', 0);

        $where = array(
            'jgg_id'      => $jgg_id
        );

        $jggInfo = $jggModel->find($where);
        if(!$jggInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($jggInfo['is_enable'] == 1){
            $is_enable = 0;
        }else{
            $is_enable = 1;
        }

        $jggModel->save($where, array('is_enable' => $is_enable));

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif ($a == 'logs'){

    $jgg_id  = junhua_I('jgg_id/d', 0);
    $user_id = junhua_I('user_id/d', '');

    $where = array('jgg_id' => $jgg_id);
    $jggInfo = $jggModel->find($where);

    if(!$jggInfo){
        dheader('location:' . junhua_url('mp/jgg/index', '', 1));
        exit;
    }

    $page = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();

    $where = array(
        'jgg_id'     => $jgg_id
    );

    $param = array(
        'jgg_id'     => $jgg_id
    );

    if($user_id){
        $where['user_id'] = $user_id;
        $param['user_id'] = $user_id;
    }

    $theurl = junhua_url('mp/jgg/logs', http_build_query($param), true);


    $totalNum = $logsModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $logsModel->select($where, '*', 'log_id desc', $start, $perpage);

    $block_head_title = '&#x62bd;&#x5956;&#x7ba1;&#x7406;';
    $block_title = '&#x65e5;&#x5fd7;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'lucky'){

    $jgg_id  = junhua_I('jgg_id/d', 0);
    $user_id = junhua_I('user_id/d', '');

    $where = array('jgg_id' => $jgg_id);
    $jggInfo = $jggModel->find($where);

    if(!$jggInfo){
        dheader('location:' . junhua_url('mp/jgg/index', '', 1));
        exit;
    }

    $page = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();

    $where = array(
        'jgg_id'     => $jgg_id,
        'prize_type' => array('neq', 0)
    );

    $param = array(
        'jgg_id'     => $jgg_id
    );

    if($user_id){
        $where['user_id'] = $user_id;
        $param['user_id'] = $user_id;
    }

    $theurl = junhua_url('mp/jgg/lucky', http_build_query($param), true);


    $totalNum = $logsModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $logsModel->select($where, '*', 'log_id desc', $start, $perpage);

    $block_head_title = '&#x62bd;&#x5956;&#x7ba1;&#x7406;';
    $block_title = '&#x4e2d;&#x5956;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'del_logs'){
    if(IS_AJAX){
        $log_id = junhua_I('log_id/d', 0);

        $where = array(
            'log_id'      => $log_id
        );

        $logInfo = $logsModel->find($where);
        if(!$logInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $logsModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}elseif ($a == 'shenhe'){
    if(IS_AJAX){
        $log_id = junhua_I('log_id/d', 0);

        $where = array(
            'log_id'     => $log_id,
            'prize_type' => array('neq', 0)
        );

        $logInfo = $logsModel->find($where);
        if(!$logInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x6838;&#x9500;&#x5931;&#x8d25;'));
        }

        if($logInfo['is_hexiao'] == 1){
            $logsModel->save($where, array('hexiao_time' => 0, 'is_hexiao' => 0, 'hexiao_uid' => 0));
        }else{
            $logsModel->save($where, array('hexiao_time' => $_G['timestamp'], 'is_hexiao' => 1, 'hexiao_uid' => $uid));
        }

        junhua_ajaxReturn(array('status' => 1));
    }
}
else{
	exit;
}

$block_content = 'junhua_jgg:mp/'.$c.'/'.$a;

include template('junhua_jgg:mp/layout');