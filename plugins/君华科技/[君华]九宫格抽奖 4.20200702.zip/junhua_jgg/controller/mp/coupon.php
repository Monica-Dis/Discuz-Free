<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once('common.php');

if(!in_array($a, array('add', 'del', 'export'))){
    $a = 'index';
}

$CouponModel = new junhua_model('jggCoupon');
$jggModel = new junhua_model('jgg');
$jggLists = $jggModel->select(array(), 'jgg_id,jgg_title', 'jgg_id desc', 0,0, 1);

if($a == 'index'){
    $page        = junhua_I('page/d', 1);
    $perpage     = junhua_I('perpage/d', 10);
    $is_use      = junhua_I('is_use/d', '');
    $user_id     = junhua_I('user_id/d', '');
    $coupon_code = junhua_I('coupon_code', '');
    $jgg_id      = junhua_I('jgg_id/d', '');

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $where = array();

    $param['perpage'] = $perpage;

    if($jgg_id){
        $param['jgg_id'] = $jgg_id;
        $where['jgg_id'] = $jgg_id;
    }

    if($coupon_code){
        $param['coupon_code'] = $coupon_code;
        $where['coupon_code'] = $coupon_code;
    }

    if($user_id){
        $param['user_id'] = $user_id;
        $where['user_id'] = $user_id;
    }

    if($is_use){
        $param['is_use'] = $is_use;
        $where['is_use'] = $is_use;
    }

    $theurl = junhua_url('mp/coupon/index', http_build_query($param), true);
    $totalNum = $CouponModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $CouponModel->select($where, '*', 'coupon_id desc', $start, $perpage);

    $exportUrl = junhua_url('mp/coupon/export', http_build_query($param), 1);


    $block_head_title = '&#x5361;&#x5238;&#x7ba1;&#x7406;';
    $block_title = '&#x5361;&#x5238;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {

    
	if(IS_AJAX){
        
        $jgg_id     = junhua_I('jgg_id/d', 0);
        $number     = junhua_I('number/d', 0);
        $coupon_num = junhua_I('coupon_num/d', 0);
        $last_time  = junhua_I('last_time/d', 0);

        $data = array();
        $last_time = strtotime(date('Y-m-d', $_G['timestamp']). ' 23:59:59') + 86400*$last_time;

        for ($i=0; $i < $number; $i++) { 
            $data[] = array(
                'jgg_id'      => $jgg_id,
                'coupon_code' => $jgg_id.junhua_randString(16),
                'coupon_num'  => $coupon_num,
                'last_time'   => $last_time,
                'add_time'    => $_G['timestamp'],
                'update_time' => $_G['timestamp'],
            );
        }

        $CouponModel->addAll($data);

	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/coupon/index', '', true)));
	}

    $block_head_title = '&#x5361;&#x5238;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x5361;&#x5238;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'del'){
    if(IS_AJAX){
        $coupon_id = junhua_I('coupon_id/d', 0);

        $where = array(
            'coupon_id'      => $coupon_id
        );

        $couponInfo = $CouponModel->find($where);
        if(!$couponInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $CouponModel->delete($where);

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'export'){

    $is_use      = junhua_I('is_use/d', '');
    $user_id     = junhua_I('user_id/d', '');
    $coupon_code = junhua_I('coupon_code', '');
    $jgg_id      = junhua_I('jgg_id/d', '');

    $where = array();

    if($jgg_id){
        $where['jgg_id'] = $jgg_id;
    }

    if($coupon_code){
        $where['coupon_code'] = $coupon_code;
    }

    if($user_id){
        $where['user_id'] = $user_id;
    }

    if($is_use){
        $where['is_use'] = $is_use;
    }

    $filename = date("YmdHis") . '.csv';
    header('Content-Description: File Transfer');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Type: text/comma-separated-values');   
    header('Content-Transfer-Encoding: binary');


    $lists = $CouponModel->select($where, '*', 'coupon_id desc');


    foreach ($lists as $key => $value) {
        if($key == 0){

            $header = array();
            $header[] = 'bianhao';
            $header[] = 'jgg_id';
            $header[] = 'coupon_code';
            $header[] = 'coupon_num';
            $header[] = 'user_id';
            $header[] = 'use_time';
            $header[] = 'is_use';
            $header[] = 'last_time';

            echo diconv(implode(',', $header), CHARSET, "GB18030");
        }

        $vl = array();
        $vl['bianhao']     = $key+1;
        $vl['jgg_id']      = $value['jgg_id'];
        $vl['coupon_code'] = $value['coupon_code'];
        $vl['coupon_num']  = $value['coupon_num'];
        $vl['user_id']     = $value['user_id'] ? $value['user_id'] : '';
        $vl['use_time']    = $value['use_time'] ? date('Y-m-d H:i:s', $value['use_time']) : '';
        $vl['is_use']      = $value['is_use'] ? 'yes' : 'no';
        $vl['last_time']   = $value['last_time'] ? date('Y-m-d H:i:s', $value['last_time']) : '';

        echo "\n".diconv(implode(",\t", $vl), CHARSET, "GB18030");
    }
    exit;
}
else{
	exit;
}

$block_content = 'junhua_jgg:mp/'.$c.'/'.$a;

include template('junhua_jgg:mp/layout');