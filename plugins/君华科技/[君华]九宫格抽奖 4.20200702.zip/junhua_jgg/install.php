<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$ADMINSCRIPT = ADMINSCRIPT;
$siteurl = $_G['siteurl'];

$createtablesql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_junhua_jgg` (
  `jgg_id` int(11) NOT NULL AUTO_INCREMENT,
  `jgg_title` varchar(256) DEFAULT '',
  `jgg_src` varchar(256) DEFAULT '',
  `jgg_setting` text,
  `jgg_hexiao` varchar(256) DEFAULT '',
  `background` varchar(16) DEFAULT '',
  `today_num` int(10) unsigned DEFAULT '0',
  `num_type` tinyint(1) unsigned DEFAULT '0',
  `point_type` int(10) DEFAULT '0',
  `point` int(10) DEFAULT '0',
  `jgg_content` mediumtext,
  `is_mustapp` tinyint(1) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  `update_time` int(10) unsigned DEFAULT '0',
  `start_time` int(10) unsigned DEFAULT '0',
  `end_time` int(10) unsigned DEFAULT '0',
  `share_title` varchar(256) DEFAULT '',
  `share_desc` varchar(256) DEFAULT '',
  `share_img` varchar(256) DEFAULT '',
  `is_enable` tinyint(1) DEFAULT '0',
  `zero_text` varchar(256) DEFAULT '',
  `app_text` varchar(256) DEFAULT '',
  `bg1` varchar(256) DEFAULT '',
  `bg2` varchar(256) DEFAULT '',
  `show_lucknum` int(10) DEFAULT '0',
  `btn_bg` varchar(256) DEFAULT '',
  PRIMARY KEY (`jgg_id`),
  KEY `is_enable` (`is_enable`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_jgg_coupon` (
  `coupon_id` int(10) NOT NULL AUTO_INCREMENT,
  `jgg_id` int(10) unsigned DEFAULT '0',
  `coupon_code` varchar(32) DEFAULT '',
  `coupon_num` int(10) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `use_time` int(10) unsigned DEFAULT '0',
  `is_use` tinyint(1) unsigned DEFAULT '0',
  `last_time` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  `update_time` int(10) DEFAULT '0',
  PRIMARY KEY (`coupon_id`),
  KEY `coupon_code` (`coupon_code`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `is_use` (`is_use`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_jgg_goods` (
  `goods_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_name` varchar(256) DEFAULT '',
  `goods_src` varchar(256) DEFAULT '',
  `goods_price` decimal(12,2) DEFAULT '0.00',
  `goods_type` tinyint(1) DEFAULT '0',
  `goods_tishi` varchar(128) DEFAULT '',
  `quantity` int(10) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `update_time` int(11) unsigned DEFAULT '0',
  `is_showluck` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`goods_id`),
  KEY `goods_type` (`goods_type`),
  KEY `quantity` (`quantity`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_jgg_link` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `jgg_id` int(11) DEFAULT '0',
  `link_code` varchar(32) DEFAULT '',
  `link_num` int(10) unsigned DEFAULT '0',
  `use_num` int(10) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `expiry_time` int(11) unsigned DEFAULT '0',
  PRIMARY KEY (`link_id`),
  KEY `jgg_id` (`jgg_id`),
  KEY `expiry_time` (`expiry_time`),
  KEY `link_code` (`link_code`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_jgg_link_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `link_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `jgg_id` int(11) DEFAULT '0',
  `link_code` varchar(32) DEFAULT '',
  `add_time` int(11) unsigned DEFAULT '0',
  PRIMARY KEY (`log_id`),
  KEY `link_id` (`link_id`),
  KEY `jgg_id` (`jgg_id`),
  KEY `user_id` (`user_id`),
  KEY `link_code` (`link_code`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_jgg_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `jgg_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `goods_id` int(10) DEFAULT '0',
  `prize` tinyint(1) DEFAULT '0',
  `prize_title` varchar(128) DEFAULT '',
  `prize_type` tinyint(1) DEFAULT '0',
  `date_time` int(8) DEFAULT '0',
  `xingming` varchar(128) DEFAULT '',
  `mobile` varchar(32) DEFAULT '',
  `add_time` int(11) unsigned DEFAULT '0',
  `is_hexiao` tinyint(1) DEFAULT '0',
  `hexiao_time` int(11) unsigned DEFAULT '0',
  `hexiao_uid` int(10) DEFAULT '0',
  PRIMARY KEY (`log_id`),
  KEY `user_id` (`user_id`),
  KEY `lottery_id` (`jgg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_jgg_usernum` (
  `jgg_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `num` int(10) DEFAULT '0',
  `today_time` int(10) unsigned DEFAULT '0',
  KEY `jgg_id` (`jgg_id`),
  KEY `num` (`num`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM;

EOF;

runquery($createtablesql);
$finish = TRUE;
?>