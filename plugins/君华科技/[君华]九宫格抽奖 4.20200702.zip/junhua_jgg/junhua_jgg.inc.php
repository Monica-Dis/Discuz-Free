<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!is_file('source/plugin/junhua_base/index.html')){
	showmessage('&#x672c;&#x63d2;&#x4ef6;&#x4f9d;&#x8d56;[&#x541b;&#x534e;]&#x57fa;&#x7840;&#x63d2;&#x4ef6;&#xff0c;&#x8bf7;&#x70b9;&#x51fb;&#x4e0b;&#x8f7d;&#x5b89;&#x88c5;&#xff0c;&#x5df2;&#x4e0b;&#x8f7d;&#x7528;&#x6237;&#x8bf7;&#x5f00;&#x542f;&#x3002;', 'https://dism.taobao.com/?@junhua_base.plugin', array(), array('refreshtime' => 5));
}

if(!is_file('source/plugin/junhua_editor/index.htm')){
	showmessage('&#x672c;&#x63d2;&#x4ef6;&#x4f9d;&#x8d56;[&#x541b;&#x534e;]&#x7f16;&#x8f91;&#x5668;&#xff0c;&#x8bf7;&#x70b9;&#x51fb;&#x4e0b;&#x8f7d;&#x5b89;&#x88c5;&#x3002;', 'https://dism.taobao.com/?@junhua_editor.plugin', array(), array('refreshtime' => 5));
}

$junhua_base_version = $_G['setting']['plugins']['version']['junhua_base'];

if($junhua_base_version < 26){
	showmessage('&#x8bf7;&#x66f4;&#x65b0;&#x57fa;&#x7840;&#x63d2;&#x4ef6;&#x5230; 26 &#x7248;&#x672c;&#xff0c;&#x8bf7;&#x70b9;&#x51fb;&#x4e0b;&#x8f7d;&#x5b89;&#x88c5;&#xff0c;&#x5df2;&#x4e0b;&#x8f7d;&#x7528;&#x6237;&#x8bf7;&#x5f00;&#x542f;&#x3002;', 'https://dism.taobao.com/?@junhua_base.plugin', array(), array('refreshtime' => 5));
}


//&#x8bbe;&#x7f6e;&#x65f6;&#x533a;
@date_default_timezone_set('Etc/GMT'.($_G['setting']['timeoffset'] > 0 ? '-' : '+').(abs($_G['setting']['timeoffset'])));

include_once('source/plugin/junhua_base/common/common.php');
include_once('source/plugin/junhua_base/libs/model.class.php');
include_once('source/plugin/junhua_base/func/function.php');
include_once('source/plugin/junhua_base/libs/app.class.php');

//&#x83b7;&#x53d6;&#x4e0a;&#x4e00;&#x4e2a;&#x94fe;&#x63a5;
$refererurl = $_G['siteurl'] . 'plugin.php?'.$_SERVER['QUERY_STRING'];


$junhua_base_config		= $_G['cache']['plugin']['junhua_base'];
$junhua_jgg_config		= $_G['cache']['plugin']['junhua_jgg'];

loadcache('junhua_jgg_setting');
$junhua_jgg_setting = dunserialize($_G['cache']['junhua_jgg_setting']);

$uid = $_G['uid'] ? $_G['uid'] : 0;

$m = junhua_I('m');
$c = junhua_I('c');
$a = junhua_I('a');

//&#x64cd;&#x4f5c;&#x6a21;&#x5757;
if(!in_array($m, array('m', 'mp'))){
	$m = 'm';
}

$m_list = array(
	'jgg',
	'ajax'
);

if($m == 'm' && !in_array($c, $m_list)){
	$c = 'jgg';
}

if($m == 'mp' && !$c && !$a){
	$c = 'jgg';
	$a = 'index';
}

$admin_uids = $junhua_fenlei_config['admin_uids'];
$admin_lists = explode(',', $junhua_fenlei_config['admin_uids']);

$_G['mobiletpl'][IN_MOBILE]='/';

if((IS_POST || IS_AJAX) && junhua_I('formhash') != FORMHASH){
	exit();
}

//&#x5224;&#x65ad;&#x662f;&#x5426;&#x5b58;&#x5728;&#x6587;&#x4ef6; &#x5b58;&#x5728;&#x76f4;&#x63a5;&#x5f15;&#x5165;
require 'source/plugin/junhua_jgg/controller/'.$m.'/'.$c.'.php';
