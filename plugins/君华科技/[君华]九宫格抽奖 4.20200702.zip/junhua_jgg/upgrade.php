<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$createtablesql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_junhua_jgg` (
  `jgg_id` int(11) NOT NULL AUTO_INCREMENT,
  `jgg_title` varchar(256) DEFAULT '',
  `jgg_src` varchar(256) DEFAULT '',
  `jgg_setting` text,
  `jgg_hexiao` varchar(256) DEFAULT '',
  `background` varchar(16) DEFAULT '',
  `today_num` int(10) unsigned DEFAULT '0',
  `num_type` tinyint(1) unsigned DEFAULT '0',
  `point_type` int(10) DEFAULT '0',
  `point` int(10) DEFAULT '0',
  `jgg_content` mediumtext,
  `is_mustapp` tinyint(1) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  `update_time` int(10) unsigned DEFAULT '0',
  `start_time` int(10) unsigned DEFAULT '0',
  `end_time` int(10) unsigned DEFAULT '0',
  `share_title` varchar(256) DEFAULT '',
  `share_desc` varchar(256) DEFAULT '',
  `share_img` varchar(256) DEFAULT '',
  `is_enable` tinyint(1) DEFAULT '0',
  `zero_text` varchar(256) DEFAULT '',
  `app_text` varchar(256) DEFAULT '',
  `bg1` varchar(256) DEFAULT '',
  `bg2` varchar(256) DEFAULT '',
  `show_lucknum` int(10) DEFAULT '0',
  `btn_bg` varchar(256) DEFAULT '',
  PRIMARY KEY (`jgg_id`),
  KEY `is_enable` (`is_enable`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_jgg_coupon` (
  `coupon_id` int(10) NOT NULL AUTO_INCREMENT,
  `jgg_id` int(10) unsigned DEFAULT '0',
  `coupon_code` varchar(32) DEFAULT '',
  `coupon_num` int(10) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `use_time` int(10) unsigned DEFAULT '0',
  `is_use` tinyint(1) unsigned DEFAULT '0',
  `last_time` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  `update_time` int(10) DEFAULT '0',
  PRIMARY KEY (`coupon_id`),
  KEY `coupon_code` (`coupon_code`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE,
  KEY `is_use` (`is_use`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_jgg_goods` (
  `goods_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_name` varchar(256) DEFAULT '',
  `goods_src` varchar(256) DEFAULT '',
  `goods_price` decimal(12,2) DEFAULT '0.00',
  `goods_type` tinyint(1) DEFAULT '0',
  `goods_tishi` varchar(128) DEFAULT '',
  `quantity` int(10) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `update_time` int(11) unsigned DEFAULT '0',
  `is_showluck` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`goods_id`),
  KEY `goods_type` (`goods_type`),
  KEY `quantity` (`quantity`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_jgg_link` (
  `link_id` int(11) NOT NULL AUTO_INCREMENT,
  `jgg_id` int(11) DEFAULT '0',
  `link_code` varchar(32) DEFAULT '',
  `link_num` int(10) unsigned DEFAULT '0',
  `use_num` int(10) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `expiry_time` int(11) unsigned DEFAULT '0',
  PRIMARY KEY (`link_id`),
  KEY `jgg_id` (`jgg_id`),
  KEY `expiry_time` (`expiry_time`),
  KEY `link_code` (`link_code`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_jgg_link_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `link_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `jgg_id` int(11) DEFAULT '0',
  `link_code` varchar(32) DEFAULT '',
  `add_time` int(11) unsigned DEFAULT '0',
  PRIMARY KEY (`log_id`),
  KEY `link_id` (`link_id`),
  KEY `jgg_id` (`jgg_id`),
  KEY `user_id` (`user_id`),
  KEY `link_code` (`link_code`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_jgg_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `jgg_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `goods_id` int(10) DEFAULT '0',
  `prize` tinyint(1) DEFAULT '0',
  `prize_title` varchar(128) DEFAULT '',
  `prize_type` tinyint(1) DEFAULT '0',
  `date_time` int(8) DEFAULT '0',
  `xingming` varchar(128) DEFAULT '',
  `mobile` varchar(32) DEFAULT '',
  `add_time` int(11) unsigned DEFAULT '0',
  `is_hexiao` tinyint(1) DEFAULT '0',
  `hexiao_time` int(11) unsigned DEFAULT '0',
  `hexiao_uid` int(10) DEFAULT '0',
  PRIMARY KEY (`log_id`),
  KEY `user_id` (`user_id`),
  KEY `lottery_id` (`jgg_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_jgg_usernum` (
  `jgg_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `num` int(10) DEFAULT '0',
  `today_time` int(10) unsigned DEFAULT '0',
  KEY `jgg_id` (`jgg_id`),
  KEY `num` (`num`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM;

EOF;

runquery($createtablesql);

$updatesql = array (
'junhua_jgg' => array (
    'jgg_id'       => array ('Field' => 'jgg_id','Type' => 'int(11)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),
    'jgg_title'    => array ('Field' => 'jgg_title','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'jgg_src'      => array ('Field' => 'jgg_src','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'jgg_setting'  => array ('Field' => 'jgg_setting','Type' => 'text','Null' => 'YES','Key' => '','Default' => NULL,'Extra' => '',),
    'jgg_hexiao'   => array ('Field' => 'jgg_hexiao','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'background'   => array ('Field' => 'background','Type' => 'varchar(16)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'today_num'    => array ('Field' => 'today_num','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'num_type'     => array ('Field' => 'num_type','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'point_type'   => array ('Field' => 'point_type','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'point'        => array ('Field' => 'point','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'jgg_content'  => array ('Field' => 'jgg_content','Type' => 'mediumtext','Null' => 'YES','Key' => '','Default' => NULL,'Extra' => '',),
    'is_mustapp'   => array ('Field' => 'is_mustapp','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'add_time'     => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'update_time'  => array ('Field' => 'update_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'start_time'   => array ('Field' => 'start_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'end_time'     => array ('Field' => 'end_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'share_title'  => array ('Field' => 'share_title','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'share_desc'   => array ('Field' => 'share_desc','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'share_img'    => array ('Field' => 'share_img','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'is_enable'    => array ('Field' => 'is_enable','Type' => 'tinyint(1)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'zero_text'    => array ('Field' => 'zero_text','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'app_text'     => array ('Field' => 'app_text','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'bg1'          => array ('Field' => 'bg1','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'bg2'          => array ('Field' => 'bg2','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'show_lucknum' => array ('Field' => 'show_lucknum','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'btn_bg'       => array ('Field' => 'btn_bg','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
),
'junhua_jgg_coupon' => array (
    'coupon_id'   => array ('Field' => 'coupon_id','Type' => 'int(10)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),
    'jgg_id'      => array ('Field' => 'jgg_id','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'coupon_code' => array ('Field' => 'coupon_code','Type' => 'varchar(32)','Null' => 'YES','Key' => 'MUL','Default' => '','Extra' => '',),
    'coupon_num'  => array ('Field' => 'coupon_num','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'user_id'     => array ('Field' => 'user_id','Type' => 'int(10) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'use_time'    => array ('Field' => 'use_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'is_use'      => array ('Field' => 'is_use','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'last_time'   => array ('Field' => 'last_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'add_time'    => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'update_time' => array ('Field' => 'update_time','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
),
'junhua_jgg_goods' => array (
    'goods_id'    => array ('Field' => 'goods_id','Type' => 'int(11)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),
    'goods_name'  => array ('Field' => 'goods_name','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'goods_src'   => array ('Field' => 'goods_src','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'goods_price' => array ('Field' => 'goods_price','Type' => 'decimal(12,2)','Null' => 'YES','Key' => '','Default' => '0.00','Extra' => '',),
    'goods_type'  => array ('Field' => 'goods_type','Type' => 'tinyint(1)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'goods_tishi' => array ('Field' => 'goods_tishi','Type' => 'varchar(128)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'quantity'    => array ('Field' => 'quantity','Type' => 'int(10)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'add_time'    => array ('Field' => 'add_time','Type' => 'int(11) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'update_time' => array ('Field' => 'update_time','Type' => 'int(11) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'is_showluck' => array ('Field' => 'is_showluck','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '1','Extra' => '',),
),
'junhua_jgg_link' => array (
    'link_id'     => array ('Field' => 'link_id','Type' => 'int(11)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),
    'jgg_id'      => array ('Field' => 'jgg_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'link_code'   => array ('Field' => 'link_code','Type' => 'varchar(32)','Null' => 'YES','Key' => 'MUL','Default' => '','Extra' => '',),
    'link_num'    => array ('Field' => 'link_num','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'use_num'     => array ('Field' => 'use_num','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'add_time'    => array ('Field' => 'add_time','Type' => 'int(11) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'expiry_time' => array ('Field' => 'expiry_time','Type' => 'int(11) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
),
'junhua_jgg_link_log' => array (
    'log_id'    => array ('Field' => 'log_id','Type' => 'int(11)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),
    'link_id'   => array ('Field' => 'link_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'user_id'   => array ('Field' => 'user_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'jgg_id'    => array ('Field' => 'jgg_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'link_code' => array ('Field' => 'link_code','Type' => 'varchar(32)','Null' => 'YES','Key' => 'MUL','Default' => '','Extra' => '',),
    'add_time'  => array ('Field' => 'add_time','Type' => 'int(11) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
),
'junhua_jgg_logs' => array (
    'log_id'      => array ('Field' => 'log_id','Type' => 'int(11)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),
    'jgg_id'      => array ('Field' => 'jgg_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'user_id'     => array ('Field' => 'user_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'goods_id'    => array ('Field' => 'goods_id','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'prize'       => array ('Field' => 'prize','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'prize_title' => array ('Field' => 'prize_title','Type' => 'varchar(128)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'prize_type'  => array ('Field' => 'prize_type','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'date_time'   => array ('Field' => 'date_time','Type' => 'int(8)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'xingming'    => array ('Field' => 'xingming','Type' => 'varchar(128)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'mobile'      => array ('Field' => 'mobile','Type' => 'varchar(32)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
    'add_time'    => array ('Field' => 'add_time','Type' => 'int(11) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'is_hexiao'   => array ('Field' => 'is_hexiao','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'hexiao_time' => array ('Field' => 'hexiao_time','Type' => 'int(11) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    'hexiao_uid'  => array ('Field' => 'hexiao_uid','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
),
'junhua_jgg_usernum' => array (
    'jgg_id'     => array ('Field' => 'jgg_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'user_id'    => array ('Field' => 'user_id','Type' => 'int(11)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'num'        => array ('Field' => 'num','Type' => 'int(10)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    'today_time' => array ('Field' => 'today_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
));

foreach ($updatesql as $updatesql_key => $updatesql_value) {
    # code...

    $columns_news = $updatesql_value;
    $columns = DB::fetch_all('SHOW COLUMNS FROM %t', array($updatesql_key));
    $columns_ary = array();

    foreach ($columns as $key => $value) {
        if(!isset($columns_news[$value['Field']])){
            $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` DROP COLUMN `'.$value['Field'].'`;';
            runquery($sql);
        }else{
            $columns_ary[$value['Field']] = $value;
        }
    }

    foreach ($columns_news as $key => $value) {
        //&#x65b0;&#x589e;&#x5b57;&#x6bb5;
        if(!isset($columns_ary[$key])){
            $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` ADD COLUMN `'.$key.'` '.$value['Type'].' '.($value['Null'] == 'YES' ? 'NULL' : '').' DEFAULT "'.$value['Default'].'";';
            runquery($sql);
        }else{

            //&#x4fee;&#x6539;&#x5b57;&#x6bb5;
            if($columns_ary[$key]['Field'] != $value['Field'] || $columns_ary[$key]['Type'] != $value['Type'] || $columns_ary[$key]['Default'] != $value['Default'] ){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` MODIFY COLUMN `'.$key.'` '.$value['Type'].' '.($value['Null'] == 'YES' ? 'NULL' : '').' DEFAULT "'.$value['Default'].'";';
                runquery($sql);
            }

            //&#x589e;&#x52a0;&#x7d22;&#x5f15;
            if($columns_ary[$key]['Key'] == '' && $value['Key'] == 'MUL'){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` ADD INDEX `'.$key.'` (`'.$key.'`) USING BTREE;';
                runquery($sql);
            }

            //&#x5220;&#x9664;&#x7d22;&#x5f15;
            if($columns_ary[$key]['Key'] == 'MUL' && $value['Key'] == ''){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` DROP INDEX `'.$key.'`;'; //&#x5220;&#x9664;&#x7d22;&#x5f15;
                runquery($sql);
            }
        }

    }
}

$finish = true;