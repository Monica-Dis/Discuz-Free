<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//&#x987a;&#x5e26;&#x5224;&#x65ad;&#x4e0b;&#x662f;&#x5426;&#x8981;&#x66f4;&#x65b0;

loadcache('junhua_shts_system');
$junhua_shts_system = dunserialize($_G['cache']['junhua_shts_system']);
if(isset($junhua_shts_system['adminscript'])){
	if($junhua_shts_system['adminscript'] != ADMINSCRIPT){
		savecache('junhua_shts_system', serialize(array('adminscript' => ADMINSCRIPT)));
	}
}else{
	savecache('junhua_shts_system', serialize(array('adminscript' => ADMINSCRIPT)));
}

$msg = <<<EOF
<li>&#x5728;&#x4f7f;&#x7528;&#x8fc7;&#x7a0b;&#x4e2d;&#x9047;&#x5230;&#x4efb;&#x4f55;&#x95ee;&#x9898;&#xff0c;&#x8bf7;&#x968f;&#x65f6;&#x4e0e;&#x6211;&#x4eec;&#x8054;&#x7cfb;&#xff0c;QQ: <a href="http://wpa.qq.com/msgrd?@v=3&amp;uin=5375530&amp;site=qq&amp;menu=yes" target="_blank" class="a2" rel="nofollow">5375530</a></li>
<li><a target="_blank" href="plugin.php?id=junhua_shts&m=mp"><b style=color:red>&#x8fdb;&#x5165;&#x524d;&#x53f0;&#x7ba1;&#x7406;</b></a></li>
EOF;

showtips($msg, 'tips', true, '&#x8054;&#x7cfb;&#x6211;&#x4eec;&&#x4f7f;&#x7528;&#x8bf4;&#x660e;');