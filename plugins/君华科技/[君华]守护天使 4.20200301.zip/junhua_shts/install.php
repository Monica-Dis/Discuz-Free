<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$ADMINSCRIPT = ADMINSCRIPT;
$siteurl = $_G['siteurl'];

$createtablesql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_junhua_shts` (
  `shts_id` int(11) NOT NULL AUTO_INCREMENT,
  `shts_title` varchar(256) DEFAULT '',
  `shts_desc` text,
  `share_title` varchar(256) DEFAULT '',
  `share_desc` varchar(256) DEFAULT '',
  `share_img` varchar(256) DEFAULT '',
  `shts_bg` varchar(256) DEFAULT '',
  `shts_ewm` varchar(256) DEFAULT '',
  `shts_zhidao` varchar(1000) DEFAULT '',
  `shts_jiaru` varchar(1000) DEFAULT '',
  `shts_mobile` varchar(32) DEFAULT '',
  `shts_wx` varchar(32) DEFAULT '',
  `shts_color` varchar(128) DEFAULT '',
  `shts_head` varchar(256) DEFAULT '',
  `shts_fields` varchar(1000) DEFAULT '',
  `shts_ewm_text` varchar(128) DEFAULT '',
  `apply_btn_text` varchar(128) DEFAULT '',
  `is_app` tinyint(1) DEFAULT '0',
  `is_enable` tinyint(1) DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  `update_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`shts_id`),
  KEY `is_enable` (`is_enable`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_junhua_shts_shangjia` (
  `shangjia_id` int(11) NOT NULL AUTO_INCREMENT,
  `shts_id` int(10) unsigned DEFAULT '0',
  `shangjia_title` varchar(256) DEFAULT '',
  `shangjia_intro` varchar(256) DEFAULT '',
  `shangjia_details` text,
  `ordernum` int(10) DEFAULT '0',
  `is_enable` tinyint(1) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  `update_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`shangjia_id`),
  KEY `ordernum` (`ordernum`),
  KEY `is_enable` (`is_enable`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_junhua_shts_apply` (
  `apply_id` int(11) NOT NULL AUTO_INCREMENT,
  `shts_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `username` varchar(64) DEFAULT '',
  `fields` text,
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`apply_id`),
  KEY `shts_id` (`shts_id`),
  KEY `user_id` (`user_id`),
  KEY `add_time` (`add_time`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


INSERT INTO `pre_junhua_shts` (`shts_id`, `shts_title`, `shts_desc`, `share_title`, `share_desc`, `share_img`, `shts_bg`, `shts_ewm`, `shts_zhidao`, `shts_jiaru`, `shts_mobile`, `shts_wx`, `shts_color`, `shts_head`, `is_enable`, `add_time`, `update_time`) VALUES ('1', '&#x5b88;&#x62a4;&#x5929;&#x4f7f;', '', '', '', '', '', '', '&#x6307;&#x5bfc;&#x5355;&#x4f4d;&#xff1a;|&#x67d0;&#x67d0;&#x67d0;&#x5355;&#x4f4d;', '&#x8fd9;&#x4e2a;&#x662f;&#x6587;&#x6848;&#x7684;&#x5185;&#x5bb9;', '1588888xxxx', 'wx_xxxxx', '#6403b4', '', '1', '1582554216', '1582615362');

EOF;

runquery($createtablesql);
$finish = TRUE;
?>