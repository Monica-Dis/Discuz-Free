<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql['2.20200226'] = <<<EOF
ALTER TABLE `pre_junhua_shts`
ADD COLUMN `shts_fields`  varchar(1000) NULL DEFAULT '' AFTER `shts_head`,
ADD COLUMN `is_app`  tinyint(1) NULL DEFAULT 0 AFTER `shts_fields`;

ALTER TABLE `pre_junhua_shts`
ADD COLUMN `apply_btn_text`  varchar(128) NULL DEFAULT '' AFTER `shts_fields`;

ALTER TABLE `pre_junhua_shts`
ADD COLUMN `shts_ewm_text`  varchar(128) NULL DEFAULT '' AFTER `shts_fields`;

CREATE TABLE IF NOT EXISTS `pre_junhua_shts_apply` (
  `apply_id` int(11) NOT NULL AUTO_INCREMENT,
  `shts_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `username` varchar(64) DEFAULT '',
  `fields` text,
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`apply_id`),
  KEY `shts_id` (`shts_id`),
  KEY `user_id` (`user_id`),
  KEY `add_time` (`add_time`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;


foreach($sql as $key => $value) {
    if($_GET['fromversion'] < $key) {
        runquery($value);
    }
}

$finish = true;