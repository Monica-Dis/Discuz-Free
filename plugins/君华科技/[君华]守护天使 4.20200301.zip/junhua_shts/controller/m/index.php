<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!in_array($a, array('index', 'qr'))){
    $a = 'index';
}


//&#x5f00;&#x542f;&#x5206;&#x4eab;
$junhua_shareurl = $refererurl;

//&#x5f00;&#x542f;&#x5206;&#x4eab;
if($junhua_shts_setting['weixin_share_open'] == 1 && IS_WEIXIN){
    include_once('source/plugin/junhua_base/jssdk/weixin_jssdk.php');
    $weixin_appid = $junhua_shts_setting['weixin_appid'] ? trim($junhua_shts_setting['weixin_appid']) : trim($junhua_base_config['weixin_appid']);
    $weixin_appsecret = $junhua_shts_setting['weixin_appsecret'] ? trim($junhua_shts_setting['weixin_appsecret']) : trim($junhua_base_config['weixin_appsecret']);
    $jssdk = new WEIXIN_JSSDK($weixin_appid, $weixin_appsecret);
    $signPackage = $jssdk->getSignPackage();

}

//&#x70ae;&#x7070;
if($junhua_shts_setting['weixin_paohui_url']){
    $paohuiUrl = explode("\n", $junhua_shts_setting['weixin_paohui_url']);
    $junhua_shareurl = str_replace($_G['siteurl'], $paohuiUrl[array_rand($paohuiUrl)]."/", $junhua_shareurl);
}

$junhuaApp = new junhua_App($junhua_base_config, $junhua_shts_setting);

//&#x83b7;&#x53d6;&#x9a6c;&#x7532;&#x767b;&#x5f55;
if(IS_MAGA){
    if(!$uid){

        $r = $junhuaApp->getMagaUserInfo();

        if($r['data']['user_id'] > 0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }

            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
        }
    }
}elseif(IS_QF){
    if(!$uid){

        $r = $junhuaApp->getQfUserInfo();

        if($r['data']['id'] > 0){

            $member = getuserbyuid($r['data']['id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }

            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            exit('<script>window.location.reload(true);</script>');
        }
    }
}


$shtsModel = new junhua_model('shts');
$applyModel = new junhua_model('shtsApply');


if($a == 'index'){
    $shts_id = junhua_I('shts_id/d', 0);
    $shtsInfo = $shtsModel->find(array('shts_id' => $shts_id, 'is_enable' => 1));

    if(!$shtsInfo){
        exit;
    }

    $shts_fields = $shtsInfo['shts_fields'];
    $shts_fields = explode("\n", $shts_fields);
    $shts_fields = array_filter($shts_fields);

    //&#x83b7;&#x53d6;&#x62a5;&#x540d;&#x4fe1;&#x606f;
    $applyInfo = $applyModel->find(array('user_id' => $uid, 'shts_id' => $shtsInfo['shts_id']));

}elseif($a == 'qr'){

    include_once('source/plugin/junhua_base/libs/qrcode.class.php');

    $shts_id = junhua_I('shts_id/d', 0);
    $shtsInfo = $shtsModel->find(array('shts_id' => $shts_id, 'is_enable' => 1));

    if(!$shtsInfo){
        exit;
    }

    $shts_fields = $shtsInfo['shts_fields'];
    $shts_fields = explode("\n", $shts_fields);
    $shts_fields = array_filter($shts_fields);

    //&#x83b7;&#x53d6;&#x62a5;&#x540d;&#x4fe1;&#x606f;
    $applyInfo = $applyModel->find(array('user_id' => $uid, 'shts_id' => $shtsInfo['shts_id']));

    if($applyInfo){
        $nr = unserialize($applyInfo['fields']);
        $formData = array();

        foreach ($shts_fields as $key => $value) {
            $vl = explode('|', $value);
            $formData[] = $vl[0] .": ".$nr[$key];
        }

        $formData = implode("\n", $formData);
        QRcode::png($formData, false, 'L', 6, 2);
    }

    exit;
}
else{
    exit;
}

include template('junhua_shts:m/index/index');