<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!in_array($a, array('getsj', 'apply'))){
    $a = 'getsj';
}

$shtsModel = new junhua_model('shts');
$shangjiaModel = new junhua_model('shtsShangjia');
$applyModel = new junhua_model('shtsApply');

if($a == 'getsj'){

    if(IS_AJAX){
        $shts_id = junhua_I('shts_id', 0);

        $where = array();
        $where['is_enable'] = 1;
        $where['shts_id'] = $shts_id;

        $shangjiaList = $shangjiaModel->select($where, '*', 'ordernum desc, shangjia_id desc');

        foreach ($shangjiaList as $key => $value) {
            $shangjiaList[$key]['shangjia_details'] = htmlspecialchars_decode($value['shangjia_details']);
        }

        junhua_ajaxReturn(array('code' => 0, 'list' => $shangjiaList, 'num' => sizeof($shangjiaList)));

    }else{
        exit;
    }

}elseif($a == 'apply'){


    if(IS_AJAX){
        $shts_id = junhua_I('shts_id/s', 0);
        $fields  = junhua_I('fields/a', array());
        
        $where            = array();
        $where['shts_id'] = $shts_id;

        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        $shtsInfo = $shtsModel->find($where);
        if(!$shtsInfo){
            exit;
        }

        if(!$shtsInfo){
            $data = array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
            junhua_ajaxReturn($data);
        }

        if($shtsInfo['is_enable'] == 0){
            $data = array('code' => 0, 'msg' => '&#x6d3b;&#x52a8;&#x4e0d;&#x5b58;&#x5728;');
            junhua_ajaxReturn($data);
        }


        $applyInfo = $applyModel->find(array('user_id' => $uid, 'shts_id' => $shts_id));
        if($applyInfo){
            $data = array('code' => 0, 'msg' => '&#x60a8;&#x5df2;&#x7533;&#x8bf7;&#xff0c;&#x8bf7;&#x52ff;&#x91cd;&#x590d;&#x7533;&#x8bf7;');
            junhua_ajaxReturn($data);
        }else{
            $applyModel->add(array('user_id' => $uid, 'username' => $_G['username'],  'shts_id' => $shts_id, 'fields' => serialize($fields), 'add_time' => $_G['timestamp']));
        }

        $data = array('code' => 2, 'msg' => '&#x606d;&#x559c;&#x60a8;&#xff0c;&#x7533;&#x8bf7;&#x6210;&#x529f;');
        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}
else{
	exit;
}