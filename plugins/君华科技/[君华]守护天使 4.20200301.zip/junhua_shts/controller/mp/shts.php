<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array('add', 'edit', 'del', 'index', 'set'))){
    $a = 'index';
}

$shtsModel = new junhua_model('shts');

if($a == 'index'){

    $page = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $theurl = junhua_url('mp/shts/index', http_build_query($param), true);


    $where = array();
    $totalNum = $shtsModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $shtsModel->select($where, '*', 'shts_id desc', $start, $perpage);

    $block_head_title = '&#x6d3b;&#x52a8;&#x7ba1;&#x7406;';
    $block_title = '&#x6d3b;&#x52a8;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {
	if(IS_AJAX){
        
        $shts_title     = junhua_I('shts_title', '');
        $share_title    = junhua_I('share_title');
        $share_desc     = junhua_I('share_desc');
        $share_img      = junhua_I('share_img');
        $shts_desc      = junhua_I('shts_desc');
        $shts_bg        = junhua_I('shts_bg');
        $shts_ewm       = junhua_I('shts_ewm');
        $shts_zhidao    = junhua_I('shts_zhidao');
        $shts_jiaru     = junhua_I('shts_jiaru');
        $shts_mobile    = junhua_I('shts_mobile');
        $shts_wx        = junhua_I('shts_wx');
        $shts_color     = junhua_I('shts_color');
        $shts_head      = junhua_I('shts_head');
        $shts_fields    = junhua_I('shts_fields');
        $apply_btn_text = junhua_I('apply_btn_text');
        $is_app         = junhua_I('is_app/d', 0);
        
        $shts_zhidao = str_replace("\r", "", $shts_zhidao);
        $shts_zhidao = explode("\n", $shts_zhidao);
        $shts_zhidao = array_filter($shts_zhidao);
        if($shts_zhidao){
            $shts_zhidao = array_map("trim", $shts_zhidao);
            $shts_zhidao = implode("\n", $shts_zhidao);
        }else{
            $shts_zhidao = '';
        }
        
        $shts_fields = str_replace("\r", "", $shts_fields);
        $shts_fields = explode("\n", $shts_fields);
        $shts_fields = array_filter($shts_fields);
        if($shts_fields){
            $shts_fields = array_map("trim", $shts_fields);
            $shts_fields = implode("\n", $shts_fields);
        }else{
            $shts_fields = '';
        }
        
        $data = array(
            'shts_title'     => $shts_title,
            'share_title'    => $share_title,
            'share_desc'     => $share_desc,
            'share_img'      => $share_img,
            'shts_desc'      => $shts_desc,
            'shts_bg'        => $shts_bg,
            'shts_ewm'       => $shts_ewm,
            'shts_zhidao'    => $shts_zhidao,
            'shts_jiaru'     => $shts_jiaru,
            'shts_mobile'    => $shts_mobile,
            'shts_wx'        => $shts_wx,
            'shts_color'     => $shts_color,
            'shts_head'      => $shts_head,
            'shts_fields'    => $shts_fields,
            'apply_btn_text' => $apply_btn_text,
            'is_app'         => $is_app,
            'add_time'       => $_G['timestamp'],
            'update_time'    => $_G['timestamp'],
            'is_enable'      => 1,
		);

		$shtsModel->add($data);

	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/shts/index', '', true)));
	}

    $block_head_title = '&#x6d3b;&#x52a8;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x6d3b;&#x52a8;';
    $block_css = '';
    $a = 'update';
}elseif ($a == 'edit') {

	$shts_id = junhua_I('shts_id/d', 0);

	$where = array('shts_id' => $shts_id);
	$shtsInfo = $shtsModel->find($where);

	if(!$shtsInfo){
        dheader('location:' . junhua_url('mp/shts/index', '', 1));
        exit;
	}

	if(IS_AJAX){

        $shts_title     = junhua_I('shts_title', '');
        $share_title    = junhua_I('share_title');
        $share_desc     = junhua_I('share_desc');
        $share_img      = junhua_I('share_img');
        $shts_desc      = junhua_I('shts_desc');
        $shts_bg        = junhua_I('shts_bg');
        $shts_ewm       = junhua_I('shts_ewm');
        $shts_zhidao    = junhua_I('shts_zhidao');
        $shts_jiaru     = junhua_I('shts_jiaru');
        $shts_mobile    = junhua_I('shts_mobile');
        $shts_wx        = junhua_I('shts_wx');
        $shts_color     = junhua_I('shts_color');
        $shts_head      = junhua_I('shts_head');
        $shts_fields    = junhua_I('shts_fields');
        $apply_btn_text = junhua_I('apply_btn_text');
        $is_app         = junhua_I('is_app/d', 0);

        $shts_zhidao = str_replace("\r", "", $shts_zhidao);
        $shts_zhidao = explode("\n", $shts_zhidao);
        $shts_zhidao = array_filter($shts_zhidao);
        if($shts_zhidao){
            $shts_zhidao = array_map("trim", $shts_zhidao);
            $shts_zhidao = implode("\n", $shts_zhidao);
        }else{
            $shts_zhidao = '';
        }

        $shts_fields = str_replace("\r", "", $shts_fields);
        $shts_fields = explode("\n", $shts_fields);
        $shts_fields = array_filter($shts_fields);
        if($shts_fields){
            $shts_fields = array_map("trim", $shts_fields);
            $shts_fields = implode("\n", $shts_fields);
        }else{
            $shts_fields = '';
        }

		$data = array(
            'shts_title'     => $shts_title,
            'share_title'    => $share_title,
            'share_desc'     => $share_desc,
            'share_img'      => $share_img,
            'shts_desc'      => $shts_desc,
            'shts_bg'        => $shts_bg,
            'shts_ewm'       => $shts_ewm,
            'shts_zhidao'    => $shts_zhidao,
            'shts_jiaru'     => $shts_jiaru,
            'shts_mobile'    => $shts_mobile,
            'shts_wx'        => $shts_wx,
            'shts_color'     => $shts_color,
            'shts_head'      => $shts_head,
            'shts_fields'    => $shts_fields,
            'apply_btn_text' => $apply_btn_text,
            'is_app'         => $is_app,
            'update_time' => $_G['timestamp'],
		);

		$shtsModel->save($where, $data);
	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/shts/index', '', 1)));
	}

    $block_head_title = '&#x6d3b;&#x52a8;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x6d3b;&#x52a8;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'del'){
    if(IS_AJAX){
        $shts_id = junhua_I('shts_id/d', 0);

        $where = array(
            'shts_id'      => $shts_id
        );

        $shtsInfo = $shtsModel->find($where);
        if(!$shtsInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $shtsModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'set'){
    if(IS_AJAX){
        $shts_id = junhua_I('shts_id/d', 0);

        $where = array(
            'shts_id'      => $shts_id
        );

        $shtsInfo = $shtsModel->find($where);
        if(!$shtsInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($shtsInfo['is_enable'] == 1){
            $is_enable = 0;
        }else{
            $is_enable = 1;
        }

        $shtsModel->save($where, array('is_enable' => $is_enable));

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'reset'){
    if(IS_AJAX){
        $shts_id = junhua_I('shts_id/d', 0);

        $where = array(
            'shts_id'      => $shts_id
        );

        $shtsInfo = $shtsModel->find($where);
        if(!$shtsInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        $shtsModel->save($where, array('shts_status' => 0));

        junhua_ajaxReturn(array('status' => 1));
    }
}
else{
	exit;
}

$block_content = 'junhua_shts:mp/'.$c.'/'.$a;

include template('junhua_shts:mp/layout');