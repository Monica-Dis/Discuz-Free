<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array('del', 'index', 'set'))){
    $a = 'index';
}

$applyModel = new junhua_model('shtsApply');

if($a == 'index'){

    $shts_id = junhua_I('shts_id/d', '');
    $user_id = junhua_I('user_id/d', '');
    $page    = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $where = array();

    if($shts_id){
        $where['shts_id'] = $shts_id;
        $param['shts_id'] = $shts_id;
    }

    if($user_id){
        $where['user_id'] = $user_id;
        $param['user_id'] = $user_id;
    }

    $param['perpage'] = $perpage;


    $totalNum = $applyModel->count($where);

    $theurl = junhua_url('mp/apply/index', http_build_query($param), true);
    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $applyModel->select($where, '*', 'apply_id desc', $start, $perpage);

    $block_head_title = '&#x7533;&#x8bf7;&#x7ba1;&#x7406;';
    $block_title = '&#x7533;&#x8bf7;&#x5217;&#x8868;';
    $block_css = '';
}elseif($a == 'set'){
    if(IS_AJAX){
        $apply_id = junhua_I('apply_id/d', 0);

        $where = array(
            'apply_id'      => $apply_id
        );

        $applyInfo = $applyModel->find($where);
        if(!$applyInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($applyInfo['is_prize'] == 1){
            $is_prize = 0;
        }else{
            $is_prize = 1;
        }

        $applyModel->save($where, array('is_prize' => $is_prize));

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'del'){
    if(IS_AJAX){
        $apply_id = junhua_I('apply_id/d', 0);

        $where = array(
            'apply_id'      => $apply_id
        );

        $applyInfo = $applyModel->find($where);
        if(!$applyInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $applyModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}else{
	exit;
}

$block_content = 'junhua_shts:mp/'.$c.'/'.$a;
include template('junhua_shts:mp/layout');