<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array('add', 'edit', 'del', 'index', 'set'))){
    $a = 'index';
}

$shangjiaModel = new junhua_model('shtsShangjia');

if($a == 'index'){

    $shts_id = junhua_I('shts_id/d', 0);
    $page    = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $theurl = junhua_url('mp/shangjia/index', http_build_query($param), true);


    $where = array();
    if($shts_id){
        $where['shts_id'] = $shts_id;
    }
    $totalNum = $shangjiaModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $shangjiaModel->select($where, '*', 'shangjia_id desc', $start, $perpage);

    $block_head_title = '&#x5546;&#x5bb6;&#x7ba1;&#x7406;';
    $block_title = '&#x5546;&#x5bb6;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {
	if(IS_AJAX){

        $shts_id          = junhua_I('shts_id/d', 0);
        $shangjia_title   = junhua_I('shangjia_title', '');
        $shangjia_intro   = junhua_I('shangjia_intro', '');
        $shangjia_details = junhua_I('shangjia_details', '');
        $ordernum         = junhua_I('ordernum/d', 0);

        $shangjia_details = htmlspecialchars_decode($shangjia_details);
        $shangjia_details = preg_replace('/<img src="(.*)source\/plugin\/junhua_shts\/upload\/image/U', '<img src="source/plugin/junhua_shts/upload/image', $shangjia_details);
        $shangjia_details = dhtmlspecialchars($shangjia_details);

		$data = array(
            'shts_id'          => $shts_id,
            'shangjia_title'   => $shangjia_title,
            'shangjia_intro'   => $shangjia_intro,
            'shangjia_details' => $shangjia_details,
            'ordernum'         => $ordernum,
            'add_time'         => $_G['timestamp'],
            'update_time'      => $_G['timestamp'],
            'is_enable'        => 1,
		);

		$shangjiaModel->add($data);

	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/shangjia/index', 'shts_id='.$shts_id, true)));
	}

    $block_head_title = '&#x5546;&#x5bb6;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x5546;&#x5bb6;';
    $block_css = '';
    $a = 'update';
}elseif ($a == 'edit') {

	$shangjia_id = junhua_I('shangjia_id/d', 0);

	$where = array('shangjia_id' => $shangjia_id);
	$shangjiaInfo = $shangjiaModel->find($where);

	if(!$shangjiaInfo){
        dheader('location:' . junhua_url('mp/shangjia/index', '', 1));
        exit;
	}

	if(IS_AJAX){

        $shangjia_title    = junhua_I('shangjia_title', '');
        $shangjia_intro   = junhua_I('shangjia_intro', '');
        $shangjia_details = junhua_I('shangjia_details', '');
        $ordernum         = junhua_I('ordernum/d', 0);
        
        $shangjia_details = htmlspecialchars_decode($shangjia_details);
        $shangjia_details = preg_replace('/<img src="(.*)source\/plugin\/junhua_shts\/upload\/image/U', '<img src="source/plugin/junhua_shts/upload/image', $shangjia_details);
        $shangjia_details = dhtmlspecialchars($shangjia_details);
        

		$data = array(
            'shangjia_title'    => $shangjia_title,
            'shangjia_intro'   => $shangjia_intro,
            'shangjia_details' => $shangjia_details,
            'ordernum'         => $ordernum,
            'update_time'      => $_G['timestamp'],
		);

		$shangjiaModel->save($where, $data);
	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/shangjia/index', 'shts_id='.$shangjiaInfo['shts_id'], 1)));
	}

    $block_head_title = '&#x5546;&#x5bb6;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x5546;&#x5bb6;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'del'){
    if(IS_AJAX){
        $shangjia_id = junhua_I('shangjia_id/d', 0);

        $where = array(
            'shangjia_id'      => $shangjia_id
        );

        $shangjiaInfo = $shangjiaModel->find($where);
        if(!$shangjiaInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $shangjiaModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'set'){
    if(IS_AJAX){
        $shangjia_id = junhua_I('shangjia_id/d', 0);

        $where = array(
            'shangjia_id'      => $shangjia_id
        );

        $shangjiaInfo = $shangjiaModel->find($where);
        if(!$shangjiaInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($shangjiaInfo['is_enable'] == 1){
            $is_enable = 0;
        }else{
            $is_enable = 1;
        }

        $shangjiaModel->save($where, array('is_enable' => $is_enable));

        junhua_ajaxReturn(array('status' => 1));
    }
}
else{
	exit;
}

$block_content = 'junhua_shts:mp/'.$c.'/'.$a;

include template('junhua_shts:mp/layout');