<?php 
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

C::t('common_syscache')->delete('junhua_shts_system');
C::t('common_syscache')->delete('junhua_shts_setting');

$sql = <<<EOF
	DROP TABLE IF EXISTS `pre_junhua_shts`;
	DROP TABLE IF EXISTS `pre_junhua_shts_shangjia`;
	DROP TABLE IF EXISTS `pre_junhua_shts_apply`;
EOF;


runquery($sql);
$finish = true;
?>