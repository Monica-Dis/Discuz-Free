<?php 

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

C::t('common_syscache')->delete('junhua_tkhongbao_system');
C::t('common_syscache')->delete('junhua_tkhongbao_setting');

$sql = <<<EOF
	DROP TABLE IF EXISTS `pre_junhua_tkhongbao_hongbao`;
	DROP TABLE IF EXISTS `pre_junhua_tkhongbao_hongbao_logs`;
	DROP TABLE IF EXISTS `pre_junhua_tkhongbao_hongbao_user`;
	DROP TABLE IF EXISTS `pre_junhua_tkhongbao_hongbao_withdrawal`;
	DROP TABLE IF EXISTS `pre_junhua_tkhongbao_shangjia`;
EOF;


runquery($sql);
$finish = true;
?>