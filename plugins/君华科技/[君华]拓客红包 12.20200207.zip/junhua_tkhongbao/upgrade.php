<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql['1.1'] = <<<EOF
ALTER TABLE `pre_junhua_tkhongbao_hongbao`
ADD COLUMN `hongbao_share_title`  varchar(256) NULL DEFAULT '' AFTER `hongbao_maxnum`,
ADD COLUMN `hongbao_share_desc`  varchar(256) NULL DEFAULT '' AFTER `hongbao_share_title`,
ADD COLUMN `hongbao_share_img`  varchar(256) NULL DEFAULT '' AFTER `hongbao_share_desc`;
EOF;

$sql['1.2'] = <<<EOF
ALTER TABLE `pre_junhua_tkhongbao_hongbao`
ADD COLUMN `hongbao_maxhongbao`  decimal(14,2) NULL DEFAULT 0 AFTER `hongbao_maxnum`;
EOF;

$sql['1.3'] = <<<EOF
ALTER TABLE `pre_junhua_tkhongbao_hongbao`
ADD COLUMN `type`  tinyint(1) NULL DEFAULT 0 AFTER `hongbao_share_img`;
ALTER TABLE `pre_junhua_tkhongbao_hongbao`
ADD COLUMN `hongbao_guding`  varchar(128) NULL DEFAULT '' AFTER `hongbao_share_img`;
EOF;

$sql['1.4'] = <<<EOF
ALTER TABLE `pre_junhua_tkhongbao_hongbao`
ADD COLUMN `start_time`  int(11) UNSIGNED NULL DEFAULT 0 AFTER `hongbao_guding`,
ADD COLUMN `end_time`  int(11) UNSIGNED NULL DEFAULT 0 AFTER `start_time`,
ADD INDEX `start_time` (`start_time`) ,
ADD INDEX `end_time` (`end_time`);

DROP TABLE IF EXISTS `pre_junhua_tkhongbao_shangjia`;
CREATE TABLE `pre_junhua_tkhongbao_shangjia` (
  `shangjia_id` int(11) NOT NULL AUTO_INCREMENT,
  `shangjia_title` varchar(32) DEFAULT '',
  `hongbao_id` int(10) DEFAULT '0',
  `shangjia_time` varchar(256) DEFAULT '',
  `hongbao_share_title` varchar(256) DEFAULT '',
  `hongbao_share_desc` varchar(256) DEFAULT '',
  `hongbao_share_img` varchar(256) DEFAULT '',
  `is_enable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`shangjia_id`),
  KEY `hongbao_id` (`hongbao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

$sql['1.5'] = <<<EOF
ALTER TABLE `pre_junhua_tkhongbao_shangjia`
MODIFY COLUMN `hongbao_id`  varchar(256) NULL DEFAULT '' AFTER `shangjia_title`;
EOF;

$sql['1.6'] = <<<EOF
ALTER TABLE `pre_junhua_tkhongbao_hongbao`
ADD COLUMN `hongbao_kaibg_img`  varchar(256) NULL DEFAULT '' AFTER `hongbao_guding`;
ALTER TABLE `pre_junhua_tkhongbao_shangjia`
ADD COLUMN `hongbao_kaibg_img`  varchar(256) NULL DEFAULT '' AFTER `hongbao_share_img`;
ALTER TABLE `pre_junhua_tkhongbao_hongbao`
ADD COLUMN `hongbao_kaibg_link`  varchar(256) NULL DEFAULT '' AFTER `hongbao_kaibg_img`;
ALTER TABLE `pre_junhua_tkhongbao_shangjia`
ADD COLUMN `hongbao_kaibg_link`  varchar(256) NULL DEFAULT '' AFTER `hongbao_kaibg_img`;
EOF;

$sql['1.7'] = <<<EOF
ALTER TABLE `pre_junhua_tkhongbao_hongbao`
ADD COLUMN `hongbao_share_link`  varchar(256) NULL DEFAULT '' AFTER `hongbao_share_img`;
ALTER TABLE `pre_junhua_tkhongbao_shangjia`
ADD COLUMN `hongbao_share_link`  varchar(256) NULL DEFAULT '' AFTER `hongbao_share_img`;
EOF;

$sql['1.8'] = <<<EOF
ALTER TABLE `pre_junhua_tkhongbao_shangjia`
ADD COLUMN `hongbao_kai_img`  varchar(256) NULL DEFAULT '' AFTER `hongbao_kaibg_link`;
ALTER TABLE `pre_junhua_tkhongbao_hongbao`
ADD COLUMN `hongbao_kai_img`  varchar(256) NULL DEFAULT '' AFTER `hongbao_kaibg_link`;
EOF;

foreach($sql as $key => $value) {
    if($_GET['fromversion'] < $key) {
        runquery($value);
    }
}

$finish = true;