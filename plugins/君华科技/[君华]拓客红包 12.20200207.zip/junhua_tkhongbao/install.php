<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$ADMINSCRIPT = ADMINSCRIPT;
$siteurl = $_G['siteurl'];

$createtablesql = <<<EOF

DROP TABLE IF EXISTS `pre_junhua_tkhongbao_hongbao`;
CREATE TABLE `pre_junhua_tkhongbao_hongbao` (
  `hongbao_id` int(11) NOT NULL AUTO_INCREMENT,
  `hongbao_title` varchar(128) DEFAULT '',
  `hongbao_money` varchar(128) DEFAULT '',
  `hongbao_time` varchar(128) DEFAULT '',
  `hongbao_delay` int(10) DEFAULT '0',
  `order_num` int(10) DEFAULT '0',
  `hongbao_maxnum` int(10) DEFAULT '0',
  `hongbao_maxhongbao` decimal(14,2) DEFAULT '0.00',
  `hongbao_share_title` varchar(256) DEFAULT '',
  `hongbao_share_desc` varchar(256) DEFAULT '',
  `hongbao_share_img` varchar(256) DEFAULT '',
  `hongbao_share_link` varchar(256) DEFAULT '',
  `hongbao_guding` varchar(128) DEFAULT '',
  `hongbao_kaibg_img` varchar(256) DEFAULT '',
  `hongbao_kaibg_link` varchar(256) DEFAULT '',
  `hongbao_kai_img` varchar(256) DEFAULT '',
  `start_time` int(11) unsigned DEFAULT '0',
  `end_time` int(11) unsigned DEFAULT '0',
  `type` tinyint(1) DEFAULT '0',
  `is_enable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`hongbao_id`),
  KEY `start_time` (`start_time`),
  KEY `end_time` (`end_time`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


DROP TABLE IF EXISTS `pre_junhua_tkhongbao_hongbao_logs`;
CREATE TABLE `pre_junhua_tkhongbao_hongbao_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT '0',
  `hongbao_id` int(11) DEFAULT '0',
  `money` decimal(14,2) DEFAULT '0.00',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`log_id`),
  KEY `user_id` (`user_id`),
  KEY `hongbao_id` (`hongbao_id`),
  KEY `add_time` (`add_time`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


DROP TABLE IF EXISTS `pre_junhua_tkhongbao_hongbao_user`;
CREATE TABLE `pre_junhua_tkhongbao_hongbao_user` (
  `user_id` int(11) NOT NULL,
  `money` decimal(14,2) DEFAULT '0.00',
  `money_freeze` decimal(14,2) DEFAULT '0.00',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`user_id`),
  KEY `add_time` (`add_time`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



DROP TABLE IF EXISTS `pre_junhua_tkhongbao_hongbao_withdrawal`;
CREATE TABLE `pre_junhua_tkhongbao_hongbao_withdrawal` (
  `withdrawal_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `order_sn` varchar(32) NOT NULL,
  `money` decimal(14,2) DEFAULT '0.00',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`withdrawal_id`),
  KEY `order_sn` (`order_sn`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


DROP TABLE IF EXISTS `pre_junhua_tkhongbao_shangjia`;
CREATE TABLE `pre_junhua_tkhongbao_shangjia` (
  `shangjia_id` int(11) NOT NULL AUTO_INCREMENT,
  `shangjia_title` varchar(32) DEFAULT '',
  `hongbao_id` varchar(256) DEFAULT '',
  `shangjia_time` varchar(256) DEFAULT '',
  `hongbao_share_title` varchar(256) DEFAULT '',
  `hongbao_share_desc` varchar(256) DEFAULT '',
  `hongbao_share_img` varchar(256) DEFAULT '',
  `hongbao_share_link` varchar(256) DEFAULT '',
  `hongbao_kaibg_img` varchar(256) DEFAULT '',
  `hongbao_kaibg_link` varchar(256) DEFAULT '',
  `hongbao_kai_img` varchar(256) DEFAULT '',
  `is_enable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`shangjia_id`),
  KEY `hongbao_id` (`hongbao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;



INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('1', '0&#x70b9;', '0.01,0.02', '00:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('2', '1&#x70b9;', '0.01,0.02', '01:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('3', '2&#x70b9;', '0.01,0.02', '02:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('4', '3&#x70b9;', '0.01,0.02', '03:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('5', '4&#x70b9;', '0.01,0.02', '04:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('6', '5&#x70b9;', '0.01,0.02', '05:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('7', '6&#x70b9;', '0.01,0.02', '06:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('8', '7&#x70b9;', '0.01,0.02', '07:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('9', '8&#x70b9;', '0.01,0.02', '08:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('10', '9&#x70b9;', '0.01,0.02', '09:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('11', '10&#x70b9;', '0.01,0.02', '10:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('12', '11&#x70b9;', '0.01,0.02', '11:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('13', '12&#x70b9;', '0.01,0.02', '12:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('14', '13&#x70b9;', '0.01,0.02', '13:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('15', '14&#x70b9;', '0.01,0.02', '14:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('16', '15&#x70b9;', '0.01,0.02', '15:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('17', '16&#x70b9;', '0.01,0.02', '16:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('18', '17&#x70b9;', '0.01,0.02', '17:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('19', '18&#x70b9;', '0.01,0.02', '18:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('20', '19&#x70b9;', '0.01,0.02', '19:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('21', '20&#x70b9;', '0.01,0.02', '20:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('22', '21&#x70b9;', '0.01,0.02', '21:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('23', '22&#x70b9;', '0.01,0.02', '22:00', '30', '1', '10', '1');
INSERT INTO `pre_junhua_tkhongbao_hongbao` (`hongbao_id`, `hongbao_title`, `hongbao_money`, `hongbao_time`, `hongbao_delay`, `order_num`, `hongbao_maxnum`, `is_enable`) VALUES ('24', '23&#x70b9;', '0.01,0.02', '23:00', '30', '1', '10', '1');



EOF;

runquery($createtablesql);
$finish = TRUE;
?>