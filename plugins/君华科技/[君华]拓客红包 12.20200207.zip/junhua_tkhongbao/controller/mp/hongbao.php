<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array('index','edit','set','logs'))){
    $a = 'index';
}

$HongbaoModel = new junhua_model('tkhongbaoHongbao');
$HongbaoLogsModel = new junhua_model('tkhongbaoHongbaoLogs');

if($a == 'index'){
    $where = array();
    $lists = $HongbaoModel->select($where, '*', 'order_num asc, hongbao_id asc');

    $block_head_title = '&#x7ea2;&#x5305;&#x7ba1;&#x7406;';
    $block_title = '&#x7ea2;&#x5305;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'edit') {

    $hongbao_id = junhua_I('pid/d', 0);

    $where = array('hongbao_id' => $hongbao_id);
    $hongbaoInfo = $HongbaoModel->find($where);

    if(!$hongbaoInfo){
        dheader('location:' . junhua_url('mp/hongbao/index', '', 1));
        exit;
    }

    if(IS_AJAX){

        $hongbao_title       = junhua_I('hongbao_title');
        $hongbao_money       = junhua_I('hongbao_money');
        $hongbao_time        = junhua_I('hongbao_time');
        $hongbao_delay       = junhua_I('hongbao_delay/d', 0);
        $order_num           = junhua_I('order_num/d', 0);
        $type                = junhua_I('type/d', 0);
        $hongbao_guding      = junhua_I('hongbao_guding', '');
        $hongbao_maxnum      = junhua_I('hongbao_maxnum/d', 0);
        $hongbao_maxhongbao  = junhua_I('hongbao_maxhongbao/f', 0);
        $end_time            = junhua_I('end_time', '');
        $start_time          = junhua_I('start_time', '');
        
        $hongbao_share_title = junhua_I('hongbao_share_title', '');
        $hongbao_share_desc  = junhua_I('hongbao_share_desc', '');
        $hongbao_share_img   = junhua_I('hongbao_share_img', '');
        $hongbao_share_link   = junhua_I('hongbao_share_link', '');
        $hongbao_kaibg_img   = junhua_I('hongbao_kaibg_img', '');
        $hongbao_kai_img   = junhua_I('hongbao_kai_img', '');
        $hongbao_kaibg_link   = junhua_I('hongbao_kaibg_link', '');

        if($end_time){
            $end_time = strtotime($end_time);
        }

        if($start_time){
            $start_time = strtotime($start_time);
        }

        $data = array(
            'hongbao_title'       => $hongbao_title,
            'hongbao_money'       => $hongbao_money,
            'hongbao_time'        => $hongbao_time,
            'hongbao_delay'       => $hongbao_delay,
            'order_num'           => $order_num,
            'hongbao_maxnum'      => $hongbao_maxnum,
            'hongbao_maxhongbao'  => $hongbao_maxhongbao,
            'type'                => $type,
            'hongbao_guding'      => $hongbao_guding,

            'start_time'          => $start_time,
            'end_time'            => $end_time,
            
            'hongbao_share_title' => $hongbao_share_title,
            'hongbao_share_desc'  => $hongbao_share_desc,
            'hongbao_share_img'   => $hongbao_share_img,
            'hongbao_share_link'   => $hongbao_share_link,
            'hongbao_kaibg_img'   => $hongbao_kaibg_img,
            'hongbao_kai_img'   => $hongbao_kai_img,
            'hongbao_kaibg_link'   => $hongbao_kaibg_link,
            
        );

        $HongbaoModel->save($where, $data);
        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/hongbao/index', '', 1)));
    }

    $block_head_title = '&#x7ea2;&#x5305;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x7ea2;&#x5305;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'set'){
    if(IS_AJAX){
        $pid = junhua_I('pid/d', 0);

        $where = array(
            'hongbao_id'      => $pid
        );

        $hongbaoInfo = $HongbaoModel->find($where);
        if(!$hongbaoInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($hongbaoInfo['is_enable'] == 1){
            $is_enable = 2;
        }else{
            $is_enable = 1;
        }

        $HongbaoModel->save($where, array('is_enable' => $is_enable));

        junhua_ajaxReturn(array('status' => 1));
    }

}elseif($a == 'logs'){

    $page = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    $start_time  = junhua_I('start_time', '');
    $end_time    = junhua_I('end_time', '');

    $starttime = $start_time ? strtotime($start_time) : '';
    $endtime   = $end_time ? strtotime($end_time) : '';


    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $param['perpage'] = $perpage;

    if($start_time){
        $param['start_time'] = $start_time;
    }
    if($end_time){
        $param['end_time'] = $end_time;
    }
    
    $theurl = junhua_url('mp/hongbao/logs', http_build_query($param), true);


    $where = array();

    if($starttime && $endtime){
        $where['add_time']   = array(array('egt',$starttime),array('elt',$endtime),'and'); 
    }elseif($starttime && !$endtime){
        $where['add_time']   = array('egt',$starttime); 
    }elseif(!$starttime && $endtime){
        $where['add_time']   = array('elt',$endtime); 
    }


    $totalNum = $HongbaoLogsModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $HongbaoLogsModel->select($where, '*', 'log_id desc', $start, $perpage);

    $block_head_title = '&#x7ea2;&#x5305;&#x7ba1;&#x7406;';
    $block_title = '&#x65e5;&#x5fd7;&#x5217;&#x8868;';
    $block_css = '';
}
else{
	exit;
}

$block_content = 'junhua_tkhongbao:mp/hongbao/'.$a;

include template('junhua_tkhongbao:mp/layout');