<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array('index','add','edit','set','del'))){
    $a = 'index';
}

$HongbaoModel = new junhua_model('tkhongbaoHongbao');
$ShangjiaModel = new junhua_model('tkhongbaoShangjia');

//&#x83b7;&#x53d6;&#x5546;&#x5bb6;&#x5217;&#x8868;
$hlist = $HongbaoModel->select(array(), 'hongbao_id,hongbao_title', '' , 0, 0, 1);

if($a == 'index'){
    //&#x5224;&#x65ad;&#x662f;&#x5426;&#x6709;&#x5546;&#x5bb6;
    $shangjia_title       = junhua_I('shangjia_title');

    $where = array();
    if($shangjia_title){
       $where['shangjia_title']  = array('like', '%'.$shangjia_title.'%');
    }

    $lists = $ShangjiaModel->select($where);


    $block_head_title = '&#x5546;&#x5bb6;&#x7ba1;&#x7406;';
    $block_title = '&#x5546;&#x5bb6;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {

    if(IS_AJAX){
        
        $hongbao_id     = junhua_I('hid/a', array());
        $shangjia_title = junhua_I('shangjia_title');
        $shangjia_time  = junhua_I('shangjia_time');

        $hongbao_share_title = junhua_I('hongbao_share_title', '');
        $hongbao_share_desc  = junhua_I('hongbao_share_desc', '');
        $hongbao_share_img   = junhua_I('hongbao_share_img', '');
        $hongbao_share_link   = junhua_I('hongbao_share_link', '');
        $hongbao_kaibg_img   = junhua_I('hongbao_kaibg_img', '');
        $hongbao_kai_img   = junhua_I('hongbao_kai_img', '');
        $hongbao_kaibg_link   = junhua_I('hongbao_kaibg_link', '');

        $hlistIds = array_keys($hlist); 

        //&#x8fc7;&#x6ee4;&#x6ca1;&#x6709;&#x7684;
        $hongbaoIds = array_intersect($hongbao_id, $hlistIds);

        if(!$hongbaoIds){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x7ea2;&#x5305;&#x4e0d;&#x5b58;&#x5728;'));
        }

        $data = array(
            'hongbao_id'     => serialize($hongbaoIds),
            'shangjia_title' => $shangjia_title,
            'shangjia_time'  => $shangjia_time,

            'hongbao_share_title' => $hongbao_share_title,
            'hongbao_share_desc'  => $hongbao_share_desc,
            'hongbao_share_img'   => $hongbao_share_img,
            'hongbao_share_link'   => $hongbao_share_link,
            'hongbao_kaibg_img'   => $hongbao_kaibg_img,
            'hongbao_kai_img'   => $hongbao_kai_img,
            'hongbao_kaibg_link'   => $hongbao_kaibg_link,

            'is_enable'      => 1,
        );

        $ShangjiaModel->add($data);

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/shangjia/index', '', 1)));
    }

    $block_head_title = '&#x5546;&#x5bb6;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x5546;&#x5bb6;';
    $block_css = '';
    $a = 'update';
}elseif ($a == 'edit') {

    $shangjia_id = junhua_I('shid/d', 0);

    $where = array('shangjia_id' => $shangjia_id);
    $shangjiaInfo = $ShangjiaModel->find($where);

    if(!$shangjiaInfo){
        dheader('location:' . junhua_url('mp/shangjia/index', '', 1));
        exit;
    }

    if(IS_AJAX){
        
        $hongbao_id     = junhua_I('hid/a', array());
        $shangjia_title = junhua_I('shangjia_title');
        $shangjia_time  = junhua_I('shangjia_time');
        
        $hongbao_share_title = junhua_I('hongbao_share_title', '');
        $hongbao_share_desc  = junhua_I('hongbao_share_desc', '');
        $hongbao_share_img   = junhua_I('hongbao_share_img', '');
        $hongbao_share_link   = junhua_I('hongbao_share_link', '');
        $hongbao_kaibg_img   = junhua_I('hongbao_kaibg_img', '');
        $hongbao_kai_img   = junhua_I('hongbao_kai_img', '');
        $hongbao_kaibg_link   = junhua_I('hongbao_kaibg_link', '');

        $hlistIds = array_keys($hlist); 
        //&#x8fc7;&#x6ee4;&#x6ca1;&#x6709;&#x7684;
        $hongbaoIds = array_intersect($hongbao_id, $hlistIds);

        if(!$hongbaoIds){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x7ea2;&#x5305;&#x4e0d;&#x5b58;&#x5728;'));
        }

        $data = array(
            'hongbao_id'     => serialize($hongbaoIds),
            'shangjia_title' => $shangjia_title,
            'shangjia_time'  => $shangjia_time,

            'hongbao_share_title' => $hongbao_share_title,
            'hongbao_share_desc'  => $hongbao_share_desc,
            'hongbao_share_img'   => $hongbao_share_img,
            'hongbao_share_link'   => $hongbao_share_link,
            'hongbao_kaibg_img'   => $hongbao_kaibg_img,
            'hongbao_kai_img'   => $hongbao_kai_img,
            'hongbao_kaibg_link'   => $hongbao_kaibg_link,

        );

        $ShangjiaModel->save(array('shangjia_id' => $shangjia_id), $data);

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/shangjia/index', '', 1)));
    }

    $hongbao_id = dunserialize($shangjiaInfo['hongbao_id']);

    $block_head_title = '&#x5546;&#x5bb6;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x5546;&#x5bb6;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'set'){
    if(IS_AJAX){
        $shid = junhua_I('shid/d', 0);

        $where = array(
            'shangjia_id'      => $shid
        );

        $shangjiaInfo = $ShangjiaModel->find($where);
        if(!$shangjiaInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($shangjiaInfo['is_enable'] == 1){
            $is_enable = 2;
        }else{
            $is_enable = 1;
        }

        $ShangjiaModel->save($where, array('is_enable' => $is_enable));

        junhua_ajaxReturn(array('status' => 1));
    }

}elseif($a == 'del'){
    if(IS_AJAX){
        $shid = junhua_I('shid/d', 0);

        $where = array(
            'shangjia_id'      => $shid
        );

        $shangjiaInfo = $ShangjiaModel->find($where);
        if(!$shangjiaInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $ShangjiaModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}
else{
	exit;
}

$block_content = 'junhua_tkhongbao:mp/shangjia/'.$a;

include template('junhua_tkhongbao:mp/layout');