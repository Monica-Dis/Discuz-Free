<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array('index','nav','uploadfile'))){
    $a = 'index';
}

loadcache('junhua_tkhongbao_system');
$junhua_tkhongbao_system = dunserialize($_G['cache']['junhua_tkhongbao_system']);

$dataOrg = array(

    'tkhongbao_title'                => $junhua_tkhongbao_setting['tkhongbao_title'],
    'tkhongbao_appsharehide_open'    => $junhua_tkhongbao_setting['tkhongbao_appsharehide_open'],
    'maga_share_lingqu'              => $junhua_tkhongbao_setting['maga_share_lingqu'],
    'hongbao_gongxifacai_desc'       => $junhua_tkhongbao_setting['hongbao_gongxifacai_desc'],
    'hongbao_gongxifacai_title'      => $junhua_tkhongbao_setting['hongbao_gongxifacai_title'],
    
    'tkhongbao_weixin_share_open'    => $junhua_tkhongbao_setting['tkhongbao_weixin_share_open'],
    'tkhongbao_weixin_share_title'   => $junhua_tkhongbao_setting['tkhongbao_weixin_share_title'],
    'tkhongbao_weixin_share_desc'    => $junhua_tkhongbao_setting['tkhongbao_weixin_share_desc'],
    'tkhongbao_weixin_share_img'     => $junhua_tkhongbao_setting['tkhongbao_weixin_share_img'],
    'tkhongbao_weixin_download_open' => $junhua_tkhongbao_setting['tkhongbao_weixin_download_open'],
    
    'weixin_appid'                  => $junhua_tkhongbao_setting['weixin_appid'],
    'weixin_appsecret'              => $junhua_tkhongbao_setting['weixin_appsecret'],
    'weixin_paohui_url'             => $junhua_tkhongbao_setting['weixin_paohui_url'],


    'miaoshu'                        => $junhua_tkhongbao_setting['miaoshu'],
    'lang_hongbao'                   => $junhua_tkhongbao_setting['lang_hongbao'],
    'adminhblist_open'               => $junhua_tkhongbao_setting['adminhblist_open'],
    'adminhblist_color'              => $junhua_tkhongbao_setting['adminhblist_color'],
    'static_version'                 => $junhua_tkhongbao_setting['static_version'],
    'manage_group'                   => $junhua_tkhongbao_setting['manage_group'],
    
    'footer_nav'                     => $junhua_tkhongbao_setting['footer_nav'],

);

if($a == 'index'){

    if(IS_AJAX){
        
        $tkhongbao_title                = junhua_I('tkhongbao_title', '');
        $tkhongbao_appsharehide_open    = junhua_I('tkhongbao_appsharehide_open/d', 0);
        $maga_share_lingqu              = junhua_I('maga_share_lingqu/d', 0);
        $hongbao_gongxifacai_desc       = junhua_I('hongbao_gongxifacai_desc', '');
        $hongbao_gongxifacai_title      = junhua_I('hongbao_gongxifacai_title', '');
        
        $tkhongbao_weixin_share_open    = junhua_I('tkhongbao_weixin_share_open/d', 0);
        $tkhongbao_weixin_download_open = junhua_I('tkhongbao_weixin_download_open/d', 0);
        $tkhongbao_weixin_share_title   = junhua_I('tkhongbao_weixin_share_title', '');
        $tkhongbao_weixin_share_desc    = junhua_I('tkhongbao_weixin_share_desc', '');
        $tkhongbao_weixin_share_img     = junhua_I('tkhongbao_weixin_share_img', '');
        
        $lang_hongbao                   = junhua_I('lang_hongbao', '');
        $miaoshu                        = junhua_I('miaoshu', '');
        $adminhblist_open               = junhua_I('adminhblist_open/d', 0);
        $adminhblist_color              = junhua_I('adminhblist_color', '#FF0000');
        $static_version                 = junhua_I('static_version', '');
        $manage_group                   = junhua_I('manage_group/a', array());

        $weixin_appid                  = junhua_I('weixin_appid', '');
        $weixin_appsecret              = junhua_I('weixin_appsecret', '');
        $weixin_paohui_url             = junhua_I('weixin_paohui_url', '');

        //&#x8fc7;&#x6ee4;&#x56de;&#x8f66;&#x7a7a;&#x683c;
        $weixin_paohui_url = str_replace("\r", "", $weixin_paohui_url);
        $weixin_paohui_url = explode("\n", $weixin_paohui_url);
        $weixin_paohui_url = array_filter($weixin_paohui_url);
        if($weixin_paohui_url){
            $weixin_paohui_url = array_map("trim", $weixin_paohui_url);
            $weixin_paohui_url = implode("\n", $weixin_paohui_url);
        }else{
            $weixin_paohui_url = '';
        }


        $data = array(
            'tkhongbao_title'                => $tkhongbao_title,
            'tkhongbao_appsharehide_open'    => $tkhongbao_appsharehide_open,
            'maga_share_lingqu'              => $maga_share_lingqu,
            'hongbao_gongxifacai_desc'       => $hongbao_gongxifacai_desc,
            'hongbao_gongxifacai_title'      => $hongbao_gongxifacai_title,
            
            'tkhongbao_weixin_share_open'    => $tkhongbao_weixin_share_open,
            'tkhongbao_weixin_share_title'   => $tkhongbao_weixin_share_title,
            'tkhongbao_weixin_share_desc'    => $tkhongbao_weixin_share_desc,
            'tkhongbao_weixin_share_img'     => $tkhongbao_weixin_share_img,
            'tkhongbao_weixin_download_open' => $tkhongbao_weixin_download_open,
            
            'miaoshu'                        => $miaoshu,
            'lang_hongbao'                   => $lang_hongbao,
            'adminhblist_open'               => $adminhblist_open,
            'adminhblist_color'              => $adminhblist_color,
            'static_version'                 => $static_version,
            'manage_group'                   => serialize($manage_group),

            'weixin_appid'                  => $weixin_appid,
            'weixin_appsecret'              => $weixin_appsecret,
            'weixin_paohui_url'             => $weixin_paohui_url,


        );

        $data = array_merge($dataOrg, $data);


        savecache('junhua_tkhongbao_setting', serialize($data));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x914d;&#x7f6e;&#x6210;&#x529f;'));
    }

    include_once('source/language/lang_admincp.php');

    $junhua_tkhongbao_setting['manage_group'] = dunserialize($junhua_tkhongbao_setting['manage_group']);

    $groupSelect = '<select class="form-control" name="manage_group[]" size="10" multiple="multiple"><option value=""'.(@in_array('', $junhua_tkhongbao_setting['manage_group']) ? ' selected' : '').'>&#x7a7a;</option>';

    $query = C::t('common_usergroup')->range_orderby_credit();
    $groupselect = array();
    foreach($query as $group) {
        $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
        $groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $junhua_tkhongbao_setting['manage_group']) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
    }
    $groupSelect .= '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
        ($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
        ($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
        '<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';

    $block_head_title = '&#x7cfb;&#x7edf;&#x914d;&#x7f6e;';
    $block_title = '&#x7cfb;&#x7edf;&#x914d;&#x7f6e;';
    $block_css = '';
}elseif($a == 'nav'){

    if(IS_AJAX){
        
        $footer_nav     = junhua_I('footer_nav', '');

        $data = array(
            'footer_nav'     => $footer_nav,
        );

        $data = array_merge($dataOrg, $data);

        savecache('junhua_tkhongbao_setting', serialize($data));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x914d;&#x7f6e;&#x6210;&#x529f;'));
    }


    $block_head_title = '&#x83dc;&#x5355;&#x8bbe;&#x7f6e;';
    $block_title = '&#x83dc;&#x5355;&#x8bbe;&#x7f6e;';
    $block_css = '';
}elseif($a == 'uploadfile'){
    include_once('source/plugin/junhua_base/libs/filemanger.class.php');

    if (!IS_POST && isset($_FILES) ? $_FILES : array()) {
        exit;
    }

    $filemanger = new junhua_filemanger('source/plugin/junhua_tkhongbao', 'source/plugin/junhua_tkhongbao');
    $img_path = $filemanger->uploadJson('Filedata', false);

    junhua_ajaxReturn(array('status' => 1, 'file_path' => $img_path));
}
else{
	exit;
}

$block_content = 'junhua_tkhongbao:mp/setting/'.$a;

include template('junhua_tkhongbao:mp/layout');