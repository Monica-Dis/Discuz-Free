<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!in_array($a, array('index'))){
    $a = 'index';
}

//&#x83b7;&#x53d6;&#x9a6c;&#x7532;&#x767b;&#x5f55;
if(IS_MAGA){
	if(!$uid){
	    $magaurl        = $junhua_base_config['maga_url'];
	    $maga_appsecret = $junhua_base_config['maga_appsecret'];

	    $userAgent = $_SERVER['HTTP_USER_AGENT'];
	    $info      = strstr($userAgent, "MAGAPPX");
	    $info      = explode("|",$info);
	    $token     = $info[7];

	    $appurl = $magaurl.'/mag/cloud/cloud/getUserInfo?token='.$token.'&secret='.$maga_appsecret;
	    $appdata = dfsockopen($appurl);
	    if (!$appdata) {
	        $appdata = file_get_contents($appurl);
	    }
	    $r =  json_decode($appdata, true);
	    if($r['data']['user_id'] > 0){

	        $member = getuserbyuid($r['data']['user_id'], 1);
	        if (!$member) {
	            dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
	            exit();
	        }

	        require_once libfile('function/member');
	        $cookietime = 1296000;
	        setloginstatus($member, $cookietime);
	    }
	}
}else{
	if(!$uid){
	    dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
	    exit();
	}
}


$HongbaoUserModel = new junhua_model('tkhongbaoHongbaoUser');
$HongbaoModel = new junhua_model('tkhongbaoHongbao');
$HongbaoLogsModel = new junhua_model('tkhongbaoHongbaoLogs');

//&#x67e5;&#x8be2;&#x662f;&#x5426;&#x6709;&#x6570;&#x636e;
$userInfo = $HongbaoUserModel->find(array('user_id' => $uid));
if(!$userInfo){
	$HongbaoUserModel->add(array('user_id' => $uid, 'add_time' => $_G['timestamp']));
	$userInfo = array(
		'user_id'		=> $uid,
		'money'			=> '0.00',
		'money_freeze'	=> '0.00',
		'add_time'		=> $_G['timestamp'],
	);
}

if($a == 'index'){
	//&#x83b7;&#x53d6;&#x6628;&#x65e5;&#x6570;&#x636e;
    $where = array();
	$where['user_id']   = $uid; 

	$ljAll = $HongbaoLogsModel->find($where, 'sum(money) as total');

	$where['add_time']  = array(array('egt', strtotime(date('Y-m-d', strtotime('-1 day')))), array('elt', strtotime(date('Y-m-d', strtotime('-1 day')) . ' 23:59:59')),'and'); 
	$yesDayAll = $HongbaoLogsModel->find($where, 'sum(money) as total');

    $block_title = '&#x6211;&#x7684;&#x6218;&#x7ee9;';
    $block_css = '<link rel="stylesheet" href="source/plugin/junhua_tkhongbao/static/m/css/user.css?v='.$junhua_tkhongbao_setting['static_version'].'">';
    
}
else{
	exit;
}

    



$block_content = 'junhua_tkhongbao:m/user/'.$a;
include template('junhua_tkhongbao:m/layout');