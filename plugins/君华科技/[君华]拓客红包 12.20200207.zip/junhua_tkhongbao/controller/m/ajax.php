<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!in_array($a, array('lingqu', 'tixian'))){
    $a = 'lingqu';
}

$HongbaoModel = new junhua_model('tkhongbaoHongbao');
$HongbaoLogsModel = new junhua_model('tkhongbaoHongbaoLogs');
$HongbaoUserModel = new junhua_model('tkhongbaoHongbaoUser');
$HongbaoWithdrawalrModel = new junhua_model('tkhongbaoHongbaoWithdrawal');


function getRandMoney($totalMoney, $num) {
    if ($num == 1) {
        return $totalMoney;
    }
    $min   = 0.01;
    $max   = $totalMoney / $num * 2;
    $money = rand(1, $max*100)/100;
    $money = $money <= $min ? 0.01: $money;
    return $money;
}


if($a == 'lingqu'){

    if(IS_AJAX){
        $hongbao_id = junhua_I('hid/s', 0);

        if(!$uid){
            $data = array (
                'code'  => 1,
                'msg'  => '&#x8bf7;&#x5148;&#x767b;&#x5f55;',
            );

            junhua_ajaxReturn($data);
        }

        $junhua_tkhongbao_setting['manage_group'] = dunserialize($junhua_tkhongbao_setting['manage_group']);
        $junhua_tkhongbao_setting['manage_group'] = array_filter($junhua_tkhongbao_setting['manage_group']);

        if($junhua_tkhongbao_setting['manage_group'] && !in_array($_G['groupid'], $junhua_tkhongbao_setting['manage_group'])){
            $data = array('code' => 2, 'msg' => '&#x60a8;&#x65e0;&#x6cd5;&#x53c2;&#x52a0;&#xff01;');
            junhua_ajaxReturn($data);
        }

        $hongbaoInfo = $HongbaoModel->find(array('hongbao_id' => $hongbao_id, 'is_enable' => 1));
        //&#x5224;&#x65ad;&#x7ea2;&#x5305;&#x662f;&#x5426;&#x5b58;&#x5728;

        $userInfo = $HongbaoUserModel->find(array('user_id' => $uid));
        if(!$userInfo){
            $HongbaoUserModel->add(array('user_id' => $uid, 'add_time' => $_G['timestamp']));
        }

        if(!$hongbaoInfo){
            $data = array (
                'code'  => 2,
                'msg'  => '&#x6570;&#x636e;&#x5f02;&#x5e38;',
            );

            junhua_ajaxReturn($data);
        }

        //&#x5224;&#x65ad;&#x5f00;&#x59cb;&#x6216;&#x8005;&#x7ed3;&#x675f;&#x65f6;&#x95f4;
        if($hongbaoInfo['start_time'] > 0 && $hongbaoInfo['start_time'] > $_G['timestamp']){
            $data = array (
                'code'  => 3,
                'msg'  => '&#x8fd8;&#x672a;&#x5f00;&#x59cb;',
            );

            junhua_ajaxReturn($data);
        }

        if($hongbaoInfo['end_time'] > 0 && $hongbaoInfo['end_time'] < $_G['timestamp']){
            $data = array (
                'code'  => 3,
                'msg'  => '&#x5df2;&#x7ed3;&#x675f;',
            );

            junhua_ajaxReturn($data);
        }

        $time = strtotime(date('Y-m-d', $_G['timestamp']) . ' ' . $hongbaoInfo['hongbao_time']); 

        if($_G['timestamp'] < $time){
            $data = array (
                'code'  => 3,
                'msg'  => '&#x8fd8;&#x672a;&#x5f00;&#x59cb;',
            );

            junhua_ajaxReturn($data);
        }elseif( $time <= $_G['timestamp'] && $_G['timestamp'] <= $time + $hongbaoInfo['hongbao_delay']){
            //&#x5224;&#x65ad;&#x662f;&#x5426;&#x9886;&#x53d6;&#x8fc7;
            $where = array();
            $where['user_id'] = $uid;
            $where['hongbao_id'] = $hongbao_id;
            $where['add_time'] = array('egt', strtotime(date('Y-m-d')));
            $logInfo = $HongbaoLogsModel->find($where);

            if($logInfo){
                $data = array (
                    'code'  => 6,
                    'msg'  => '&#x60a8;&#x5df2;&#x9886;&#x53d6;&#xff0c;&#x8bf7;&#x52ff;&#x91cd;&#x590d;&#x9886;&#x53d6;',
                );

                junhua_ajaxReturn($data);
            }else{
                //&#x5148;&#x5224;&#x65ad;&#x662f;&#x5426;&#x8fd8;&#x53ef;&#x4ee5;&#x9886;&#x53d6;
                $where = array();
                $where['hongbao_id'] = $hongbao_id;
                $where['add_time'] = array('egt', strtotime(date('Y-m-d')));
                $count = $HongbaoLogsModel->count($where);
                $ljAll = $HongbaoLogsModel->find($where, 'sum(money) as total');
                $totalMoney = (float)$ljAll['total'];

                if($count >= $hongbaoInfo['hongbao_maxnum'] || $totalMoney >= $hongbaoInfo['hongbao_maxhongbao']){

                    $data = array (
                        'code'  => 7,
                        'msg'  => '&#x60a8;&#x7684;&#x624b;&#x901f;&#x592a;&#x6162;&#xff0c;&#x5df2;&#x88ab;&#x62a2;&#x5b8c;&#x4e86;',
                    );
                    
                    junhua_ajaxReturn($data);
                }

                //&#x8bbe;&#x7f6e;&#x6a21;&#x5f0f;
                if($hongbaoInfo['type'] == 1){
                    //&#x83b7;&#x53d6;&#x56fa;&#x5b9a;&#x7ea2;&#x5305;
                    $hongbao_guding = $hongbaoInfo['hongbao_guding'];
                    $hongbao_guding = str_replace("\r", "", $hongbao_guding);
                    $hongbao_guding = explode("\n", $hongbao_guding);

                    //&#x8fc7;&#x6ee4;&#x7a7a;&#x7684;
                    $hongbao_guding = array_filter($hongbao_guding);
                    $guding = array();
                    foreach ($hongbao_guding as $key => $value) {
                        $temp = explode(":", $value);
                        $guding[$temp[0]] = $temp[1];
                    }


                    $allMoney = $hongbaoInfo['hongbao_maxhongbao'];
                    //&#x5224;&#x65ad;&#x5269;&#x4f59;&#x91d1;&#x989d;
                    $allMoney = $allMoney - $totalMoney;


                    //&#x5224;&#x65ad;&#x662f;&#x7b2c;&#x51e0;&#x4e2a;
                    $shengxia_num = $hongbaoInfo['hongbao_maxnum'] - $count;

                    if(isset($guding[$count+1])){
                        $money = $guding[$count+1];
                    }else{
                        $money = getRandMoney($allMoney, $shengxia_num);
                        $money = round($money, 2);
                    }

                }else{
                    //&#x968f;&#x673a;&#x83b7;&#x53d6;&#x91d1;&#x989d;
                    $hongbao_money = explode(',', $hongbaoInfo['hongbao_money']);
                    $money = rand($hongbao_money[0]*100, $hongbao_money[1]*100)/100;

                    if($totalMoney + $money > $hongbaoInfo['hongbao_maxhongbao']){
                        $money = $hongbaoInfo['hongbao_maxhongbao']-$totalMoney;
                    }
                }


                $data = array(
                    'user_id'    => $uid,
                    'hongbao_id' => $hongbao_id,
                    'money'      => $money,
                    'add_time'   => $_G['timestamp'],
                );

                $HongbaoLogsModel->add($data);
                $HongbaoUserModel->setInc(array('user_id' => $uid), 'money', $money);

                $data = array (
                    'code'  => 0,
                    'msg'  => '&#x606d;&#x559c;&#x83b7;&#x5f97;'.$money.'&#x5143;&#x5956;&#x91d1;',
                );

                junhua_ajaxReturn($data);
            }

        }else{
            $data = array (
                'code'  => 4,
                'msg'  => '&#x5df2;&#x62a2;&#x5b8c;',
            );

            junhua_ajaxReturn($data);
        }


    }else{
        exit;
    }

}elseif($a == 'tixian'){

    if(IS_AJAX){

        $type = junhua_I('t/s', 0);

        if(!$uid){
            $data = array (
                'code'  => 1,
                'msg'  => '&#x8bf7;&#x5148;&#x767b;&#x5f55;',
            );

            junhua_ajaxReturn($data);
        }

        //&#x6263;&#x7528;&#x6237;&#x94b1;&#x5305;
        $userInfo = $HongbaoUserModel->find(array('user_id' => $uid));

        if($userInfo){
            if($userInfo['money'] > 0){
                //&#x8f6c;&#x94b1;&#x5305;&#x6570;&#x636e;&#x5230;app

                if($type == 1){ //&#x9a6c;&#x7532;app

                    $order_sn = 'jhtk'.date('ymd') . substr(time() , -5) . substr(microtime() , 2, 5);

                    $data = array(
                        'user_id'  => $uid,
                        'order_sn' => $order_sn,
                        'money'    => $userInfo['money'],
                        'add_time' => $_G['timestamp'],
                    );

                    $HongbaoWithdrawalrModel->add($data);

                    $appurl = $junhua_base_config['maga_url']. '/core/pay/pay/accountTransfer?secret='.$junhua_base_config['maga_appsecret'].'&user_id='.$uid.'&amount='.$userInfo['money'].'&remark=junhua_tkhongbao&out_trade_code='.$order_sn;
                    $data = dfsockopen($appurl);
                    if (!$data) {
                        $data = file_get_contents($appurl);
                    }

                    $data = json_decode($data,true);
                    if($data['success'] && $data['code'] == 101){
                        $HongbaoUserModel->setDec(array('user_id' => $uid), 'money', $userInfo['money']);

                        $data = array (
                            'code'  => 0,
                            'msg'  => '&#x94b1;&#x5305;&#x8f6c;&#x5165;&#x6210;&#x529f;',
                        );

                        junhua_ajaxReturn($data);
                    }else{
                        $data = array (
                            'code'  => 2,
                            'msg'  => '&#x94b1;&#x5305;&#x8f6c;&#x5165;&#x5931;&#x8d25;&#xff0c;&#x8bf7;&#x7a0d;&#x540e;&#x518d;&#x8bd5;',
                        );

                        junhua_ajaxReturn($data);
                    }
                }else{
                    $data = array (
                        'code'  => 3,
                        'msg'  => '&#x94b1;&#x5305;&#x8f6c;&#x5165;&#x5931;&#x8d25;&#xff0c;&#x8bf7;&#x4f7f;&#x7528;APP&#x63d0;&#x73b0;',
                    );

                    junhua_ajaxReturn($data);
                }
            }else{
                $data = array (
                    'code'  => 4,
                    'msg'  => '&#x60a8;&#x7684;&#x6218;&#x7ee9;&#x4e3a;0&#xff0c;&#x65e0;&#x6cd5;&#x63d0;&#x73b0;',
                );
                    junhua_ajaxReturn($data);

            }
        }

    }else{
        exit;
    }

}
else{
	exit;
}