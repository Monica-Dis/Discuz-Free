<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!in_array($a, array('index'))){
    $a = 'index';
}

$HongbaoModel = new junhua_model('tkhongbaoHongbao');
$HongbaoLogsModel = new junhua_model('tkhongbaoHongbaoLogs');
$HongbaoUserModel = new junhua_model('tkhongbaoHongbaoUser');
$ShangjiaModel = new junhua_model('tkhongbaoShangjia');


//&#x5f00;&#x542f;&#x5206;&#x4eab;
if($junhua_tkhongbao_setting['tkhongbao_weixin_share_open'] == 1 && IS_WEIXIN){
    include_once('source/plugin/junhua_base/jssdk/weixin_jssdk.php');
    $weixin_appid = $junhua_tkhongbao_setting['weixin_appid'] ? trim($junhua_tkhongbao_setting['weixin_appid']) : trim($junhua_base_config['weixin_appid']);
    $weixin_appsecret = $junhua_tkhongbao_setting['weixin_appsecret'] ? trim($junhua_tkhongbao_setting['weixin_appsecret']) : trim($junhua_base_config['weixin_appsecret']);
    $jssdk = new WEIXIN_JSSDK($weixin_appid, $weixin_appsecret);
    $signPackage = $jssdk->getSignPackage();

}

//&#x70ae;&#x7070;
if($junhua_tkhongbao_setting['weixin_paohui_url']){
    $paohuiUrl = explode("\n", $junhua_tkhongbao_setting['weixin_paohui_url']);
    $junhua_shareurl = str_replace($_G['siteurl'], $paohuiUrl[array_rand($paohuiUrl)]."/", $junhua_shareurl);
}

if(IS_MAGA){
    if(!$uid){

        $junhuaApp = new junhua_App($junhua_base_config, $junhua_tkhongbao_setting);
        $r = $junhuaApp->getMagaUserInfo();

        if($r['data']['user_id'] > 0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }

            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
        }
    }
}

if($a == 'index'){
    $where = array('is_enable' => 1);
    $lists = $HongbaoModel->select($where, '*', 'order_num asc, hongbao_id asc');

    //&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x5546;&#x5bb6;
    $shangjiaList = $ShangjiaModel->select(array('is_enable' => 1));
    $hongbao2shangjia = array();
    foreach ($shangjiaList as $key => $value) {
        $hids = dunserialize($value['hongbao_id']);
        $shangjia_time = str_replace("\r", "", $value['shangjia_time']);
        $shangjia_time = explode("\n", $shangjia_time);

        foreach ($hids as $key1 => $value1) {
            foreach ($shangjia_time as $k => $v) {
                $hongbao2shangjia[$value1][$v] = array(
                    'shangjia_title'      => $value['shangjia_title'],
                    'hongbao_share_title' => $value['hongbao_share_title'],
                    'hongbao_share_desc'  => $value['hongbao_share_desc'],
                    'hongbao_share_img'   => $value['hongbao_share_img'],
                    'hongbao_share_link'  => $value['hongbao_share_link'],
                    'hongbao_kaibg_img'   => $value['hongbao_kaibg_img'],
                    'hongbao_kai_img'     => $value['hongbao_kai_img'],
                    'hongbao_kaibg_link'  => $value['hongbao_kaibg_link'],
                );
            }
        }
    }


    foreach ($lists as $key => $value) {

        $now = date('Ymd');
        $hongbao_time = explode(':', $value['hongbao_time']);
        $lists[$key]['shangjia'] = $hongbao2shangjia[$value['hongbao_id']][$now]['shangjia_title'];
        $lists[$key]['zhengdian'] = $hongbao_time[0];
        $lists[$key]['starttime'] = $value['start_time'];
        $lists[$key]['endtime'] = $value['end_time'];
        $lists[$key]['start_time'] =  strtotime(date('Y-m-d', $_G['timestamp']) . ' ' . $value['hongbao_time']); 
        $lists[$key]['end_time'] =  strtotime(date('Y-m-d', $_G['timestamp']) . ' ' . $value['hongbao_time']) + $value['hongbao_delay']; 

        $lists[$key]['hongbao_share_title'] = $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_share_title'] ? $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_share_title'] : $value['hongbao_share_title'];
        $lists[$key]['hongbao_share_desc'] = $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_share_desc'] ? $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_share_desc'] : $value['hongbao_share_desc'];
        $lists[$key]['hongbao_share_img'] = $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_share_img'] ? $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_share_img'] : $value['hongbao_share_img'];
        $lists[$key]['hongbao_share_link'] = $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_share_link'] ? $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_share_link'] : $value['hongbao_share_link'];
        $lists[$key]['hongbao_kaibg_img'] = $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_kaibg_img'] ? $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_kaibg_img'] : $value['hongbao_kaibg_img'];
        $lists[$key]['hongbao_kai_img'] = $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_kai_img'] ? $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_kai_img'] : $value['hongbao_kai_img'];
        $lists[$key]['hongbao_kaibg_link'] = $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_kaibg_link'] ? $hongbao2shangjia[$value['hongbao_id']][$now]['hongbao_kaibg_link'] : $value['hongbao_kaibg_link'];

    }

    $where = array();
	$where['add_time']  = array(array('egt', strtotime(date('Y-m-d'))), array('elt', strtotime(date('Y-m-d') . ' 23:59:59')),'and'); 
	$where['user_id']   = $uid; 

    //&#x67e5;&#x8be2;&#x4eca;&#x65e5;&#x7684;&#x6240;&#x6709;&#x8bb0;&#x5f55;
    $logsList = $HongbaoLogsModel->select($where, 'hongbao_id,money', '', 0, 0, true);

    
    $block_title = $junhua_tkhongbao_setting['tkhongbao_title'] ? $junhua_tkhongbao_setting['tkhongbao_title'] : '&#x62a2;'.$junhua_tkhongbao_setting['lang_hongbao'];
    $block_css = '<link rel="stylesheet" href="source/plugin/junhua_tkhongbao/static/m/css/index.css?v='.$junhua_tkhongbao_setting['static_version'].'">';
}
else{
	exit;
}

$block_content = 'junhua_tkhongbao:m/index/'.$a;
include template('junhua_tkhongbao:m/layout');