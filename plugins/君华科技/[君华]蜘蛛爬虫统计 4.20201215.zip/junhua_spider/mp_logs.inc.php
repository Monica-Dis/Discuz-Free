<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once('source/plugin/junhua_spider/mp_auth.php');

if(!in_array($action, array('index', 'statistics'))){
    $action = 'index';
}

loadcache('junhua_spider_setting');
$setting = dunserialize($_G['cache']['junhua_spider_setting']);

$logsModel = C::t('#junhua_spider#junhua_spider_logs');

$spiderTypeArrayName = array(
    1 => '&#x8c37;&#x6b4c;',
    2 => '&#x767e;&#x5ea6;',
    3 => '&#x6709;&#x9053;',
    4 => '&#x96c5;&#x864e;',
    5 => '&#x641c;&#x72d7;',
    6 => 'SOSO',
    7 => '360&#x641c;&#x7d22;',
    8 => 'Bing',
);


if($action == 'index'){
    $page = empty($_GET['page']) ? 1 : intval($_GET['page']);
    $perpage = empty($_GET['perpage']) ? 10 : intval($_GET['perpage']);;
    $truncate = intval($_GET['truncate']);

    if($truncate == 1) {
        $query = DB::query("TRUNCATE TABLE ".DB::table('junhua_spider_logs'));
    }

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $spider_type = intval(junhua_I('spider_type'));
    $start_time  = junhua_I('start_time');
    $end_time    = junhua_I('end_time');

    $starttime = $start_time ? strtotime($start_time) : '';
    $endtime   = $end_time ? strtotime($end_time) : '';

    $param = array();
    if($spider_type){
        $param['spider_type'] = $spider_type;
    }
    if($start_time){
        $param['start_time'] = $start_time;
    }
    if($end_time){
        $param['end_time'] = $end_time;
    }
    if($perpage){
        $param['perpage'] = $perpage;
    }


    $theurl = junhua_url('mp/logs/index', http_build_query($param), true);

    $where = array();

    if($starttime && $endtime){
        $where['add_time']   = array(array('egt',$starttime),array('elt',$endtime),'and'); 
    }elseif($starttime && !$endtime){
        $where['add_time']   = array('egt',$starttime); 
    }elseif(!$starttime && $endtime){
        $where['add_time']   = array('elt',$endtime); 
    }

    if($spider_type){
        $where['spider_type'] = $spider_type;
    }

    $totalRows = $logsModel->count($where);

    if($totalRows) {
        $multi = multi($totalRows, $perpage, $page, $theurl);
    }

    $lists = $logsModel->select($where, '*', 'log_id desc', $start, $perpage);

    $block_head_title = '&#x65e5;&#x5fd7;&#x7ba1;&#x7406;';
    $block_title = '&#x65e5;&#x5fd7;&#x5217;&#x8868;';
    $block_css = '';

}elseif($action == 'statistics'){

    $spider_type = intval(junhua_I('spider_type'));
    $start_time  = junhua_I('start_time');
    $end_time    = junhua_I('end_time');

    $starttime = $start_time ? strtotime($start_time) : '';
    $endtime   = $end_time ? strtotime($end_time) : '';

    $where = array();

    if($starttime && $endtime){
        $where['add_time']   = array(array('egt',$starttime),array('elt',$endtime),'and'); 
    }elseif($starttime && !$endtime){
        $where['add_time']   = array('egt',$starttime); 
    }elseif(!$starttime && $endtime){
        $where['add_time']   = array('elt',$endtime); 
    }

    if($spider_type){
        $where['spider_type'] = $spider_type;
    }

    $lists = $logsModel->group("CONCAT(spider_type,FROM_UNIXTIME(add_time,'%H'))")->select($where, 'spider_type, count(1) as _count, add_time', '_count desc');

    $block_head_title = '&#x7edf;&#x8ba1;&#x7ba1;&#x7406;';
    $block_title = '&#x722c;&#x866b;&#x559c;&#x597d;&#x7edf;&#x8ba1;';
    $block_css = '';
}


$block_content = 'junhua_spider:mp/logs/'.$action;

include template('junhua_spider:mp/layout');
