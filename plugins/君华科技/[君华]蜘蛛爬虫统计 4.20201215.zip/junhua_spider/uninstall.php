<?php 

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
    DROP TABLE IF EXISTS `pre_junhua_spider_logs`;
EOF;

C::t('common_syscache')->delete('junhua_spider_setting');

runquery($sql);
$finish = true;
?>