<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once('source/plugin/junhua_spider/mp_auth.php');

if(!in_array($action, array('index', 'firewall'))){
    $action = 'index';
}

loadcache('junhua_spider_setting');

if($action == 'index'){
    if(IS_AJAX){
        $spider_open = junhua_I('spider_open');
        $spider_type = junhua_I('spider_type');
        $spider_ip   = junhua_I('spider_ip');

        $settingdata = dunserialize($_G['cache']['junhua_spider_setting']);
        
        $settingdata['spider_open'] = $spider_open;
        $settingdata['spider_type'] = $spider_type;
        $settingdata['spider_ip']   = $spider_ip;

        savecache('junhua_spider_setting', daddslashes(serialize($settingdata)));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x4fdd;&#x5b58;&#x6210;&#x529f;', 'aa' => $data));

    }

    $setting = dunserialize($_G['cache']['junhua_spider_setting']);

}elseif($action == 'firewall'){
    if(IS_AJAX){
        $firewall_open   = junhua_I('firewall_open');
        $firewall_string = junhua_I('firewall_string');

        $settingdata = dunserialize($_G['cache']['junhua_spider_setting']);

        $settingdata['firewall_open']   = $firewall_open;
        $settingdata['firewall_string'] = $firewall_string;

        savecache('junhua_spider_setting', daddslashes(serialize($settingdata)));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x4fdd;&#x5b58;&#x6210;&#x529f;', 'aa' => $data));

    }

    $setting = dunserialize($_G['cache']['junhua_spider_setting']);

}

$block_content = 'junhua_spider:mp/system/'.$action;

include template('junhua_spider:mp/layout');
