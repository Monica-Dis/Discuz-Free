<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$createtablesql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_junhua_spider_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `spider_type` tinyint(1) unsigned DEFAULT '0',
  `ip` varchar(16) DEFAULT '',
  `xff_ip` varchar(255) DEFAULT '',
  `add_time` int(10) unsigned DEFAULT '0',
  `title` varchar(255) DEFAULT '',
  `url` varchar(255) DEFAULT '',
  PRIMARY KEY (`log_id`),
  KEY `spider_type` (`spider_type`)
) ENGINE=MyISAM AUTO_INCREMENT=1;
EOF;

runquery($createtablesql);


$updatesql = array ('junhua_spider_logs' => array ('log_id' => array ('Field' => 'log_id','Type' => 'int(11)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),'spider_type' => array ('Field' => 'spider_type','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),'ip' => array ('Field' => 'ip','Type' => 'varchar(16)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'xff_ip' => array ('Field' => 'xff_ip','Type' => 'varchar(255)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'add_time' => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),'title' => array ('Field' => 'title','Type' => 'varchar(255)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),'url' => array ('Field' => 'url','Type' => 'varchar(255)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),),);

foreach ($updatesql as $updatesql_key => $updatesql_value) {
    # code...

    $columns_news = $updatesql_value;
    $columns = DB::fetch_all('SHOW COLUMNS FROM %t', array($updatesql_key));
    $columns_ary = array();

    foreach ($columns as $key => $value) {
        if(!isset($columns_news[$value['Field']])){
            $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` DROP COLUMN `'.$value['Field'].'`;';
            runquery($sql);
        }else{
            $columns_ary[$value['Field']] = $value;
        }
    }

    foreach ($columns_news as $key => $value) {
        //&#x65b0;&#x589e;&#x5b57;&#x6bb5;
        if(!isset($columns_ary[$key])){
            $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` ADD COLUMN `'.$key.'` '.$value['Type'].' '.($value['Null'] == 'YES' ? 'NULL' : '').' DEFAULT "'.$value['Default'].'";';
            runquery($sql);
        }else{

            //&#x4fee;&#x6539;&#x5b57;&#x6bb5;
            if($columns_ary[$key]['Field'] != $value['Field'] || $columns_ary[$key]['Type'] != $value['Type'] || $columns_ary[$key]['Default'] != $value['Default'] ){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` MODIFY COLUMN `'.$key.'` '.$value['Type'].' '.($value['Null'] == 'YES' ? 'NULL' : '').' DEFAULT "'.$value['Default'].'";';
                runquery ($sql);
            }

            //&#x589e;&#x52a0;&#x7d22;&#x5f15;
            if($columns_ary[$key]['Key'] == '' && $value['Key'] == 'MUL'){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` ADD INDEX `'.$key.'` (`'.$key.'`) USING BTREE;';
                runquery ($sql);
            }

            //&#x589e;&#x52a0;&#x552f;&#x4e00;&#x7d22;&#x5f15;
            if($columns_ary[$key]['Key'] == '' && $value['Key'] == 'UNI'){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` ADD UNIQUE INDEX `'.$key.'` (`'.$key.'`) USING BTREE;';
                runquery ($sql);
            }

            //&#x5220;&#x9664;&#x7d22;&#x5f15;
            if(($columns_ary[$key]['Key'] == 'MUL' && $value['Key'] == '') || ($columns_ary[$key]['Key'] == 'UNI' && $value['Key'] == '')){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` DROP INDEX `'.$key.'`;'; //&#x5220;&#x9664;&#x7d22;&#x5f15;
                runquery ($sql);
            }

            //&#x5982;&#x679c;&#x7d22;&#x5f15;&#x4e0d;&#x76f8;&#x7b49; &#x5148;&#x5220;&#x7d22;&#x5f15; &#x518d;&#x52a0;
            if($columns_ary[$key]['Key'] != '' && $columns_ary[$key]['Key'] != $value['Key']){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` DROP INDEX `'.$key.'`;'; //&#x5220;&#x9664;&#x7d22;&#x5f15;
                runquery ($sql);
                
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` ADD UNIQUE INDEX `'.$key.'` (`'.$key.'`) USING BTREE;';
                runquery ($sql);
            }
        }

    }
}

$finish = true;