<?php 
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class junhua_spider_model extends discuz_table{

    protected $comparison = array('eq'=>'=','neq'=>'<>','gt'=>'>','egt'=>'>=','lt'=>'<','elt'=>'<=','notlike'=>'NOT LIKE','like'=>'LIKE','in'=>'IN','notin'=>'NOT IN');
	public $options = array();


    /**
     * SQL&#x6307;&#x4ee4;&#x5b89;&#x5168;&#x8fc7;&#x6ee4;
     * @access public
     * @param string $str  SQL&#x5b57;&#x7b26;&#x4e32;
     * @return string
     */
    public function escapeString($str) {
        return addslashes($str);
    }


    protected function parseWhereItem($key,$val) {
        $whereStr = '';
        if(is_array($val)) {
            if(is_string($val[0])) {
                if(preg_match('/^(EQ|NEQ|GT|EGT|LT|ELT)$/i',$val[0])) { 
                    $whereStr .= $key.' '.$this->comparison[strtolower($val[0])].' '.$this->parseValue($val[1]);
                }elseif(preg_match('/^(NOTLIKE|LIKE)$/i',$val[0])){
                    if(is_array($val[1])) {
                        $likeLogic  =   isset($val[2])?strtoupper($val[2]):'OR';
                        if(in_array($likeLogic,array('AND','OR','XOR'))){
                            $likeStr    =   $this->comparison[strtolower($val[0])];
                            $like       =   array();
                            foreach ($val[1] as $item){
                                $like[] = $key.' '.$likeStr.' '.$this->parseValue($item);
                            }
                            $whereStr .= '('.implode(' '.$likeLogic.' ',$like).')';                          
                        }
                    }else{
                        $whereStr .= $key.' '.$this->comparison[strtolower($val[0])].' '.$this->parseValue($val[1]);
                    }
                }elseif('exp'==strtolower($val[0])){ 
                    $whereStr .= $key.' '.$val[1];
                }elseif(preg_match('/IN/i',$val[0])){ 
                    if(isset($val[2]) && 'exp'==$val[2]) {
                        $whereStr .= $key.' '.strtoupper($val[0]).' '.$val[1];
                    }else{
                        if(is_string($val[1])) {
                             $val[1] =  explode(',',$val[1]);
                        }
                        $zone      =   implode(',',$this->parseValue($val[1]));
                        $whereStr .= $key.' '.strtoupper($val[0]).' ('.$zone.')';
                    }
                }elseif(preg_match('/BETWEEN/i',$val[0])){ 
                    $data = is_string($val[1])? explode(',',$val[1]):$val[1];
                    $whereStr .=  $key.' '.strtoupper($val[0]).' '.$this->parseValue($data[0]).' AND '.$this->parseValue($data[1]);
                }else{
                    'Expression errors:'.$val[0];
                }
            }else {
                $count = count($val);
                $rule  = isset($val[$count-1]) ? (is_array($val[$count-1]) ? strtoupper($val[$count-1][0]) : strtoupper($val[$count-1]) ) : '' ; 
                if(in_array($rule,array('AND','OR','XOR'))) {
                    $count  = $count -1;
                }else{
                    $rule   = 'AND';
                }
                for($i=0;$i<$count;$i++) {
                    $data = is_array($val[$i])?$val[$i][1]:$val[$i];
                    if('exp'==strtolower($val[$i][0])) {
                        $whereStr .= $key.' '.$data.' '.$rule.' ';
                    }else{
                        $whereStr .= $this->parseWhereItem($key,$val[$i]).' '.$rule.' ';
                    }
                }
                $whereStr = '( '.substr($whereStr,0,-4).' )';
            }
        }else {
			$whereStr .= $key.' = '.$this->parseValue($val);
        }
        return $whereStr;
    }


    /**
     * &#x5b57;&#x6bb5;&#x540d;&#x5206;&#x6790;
     * @access protected
     * @param string $key
     * @return string
     */
    protected function parseKey(&$key) {
        return $key;
    }

    /**
     * value&#x5206;&#x6790;
     * @access protected
     * @param mixed $value
     * @return string
     */
    protected function parseValue($value) {
        if(is_string($value)) {
            $value =  '\''.$this->escapeString($value).'\'';
        }elseif(isset($value[0]) && is_string($value[0]) && strtolower($value[0]) == 'exp'){
            $value =  $this->escapeString($value[1]);
        }elseif(is_array($value)) {
            $value =  array_map(array($this, 'parseValue'),$value);
        }elseif(is_bool($value)){
            $value =  $value ? '1' : '0';
        }elseif(is_null($value)){
            $value =  'null';
        }
        return $value;
    }


    /**
     * &#x7279;&#x6b8a;&#x6761;&#x4ef6;&#x5206;&#x6790;
     * @access protected
     * @param string $key
     * @param mixed $val
     * @return string
     */
    protected function parseThinkWhere($key,$val) {
        $whereStr   = '';
        switch($key) {
            case '_string':
                
                $whereStr = $val;
                break;
            case '_complex':
                
                $whereStr   =   is_string($val)? $val : substr($this->parseWhere($val),6);
                break;
            case '_query':
                
                parse_str($val,$where);
                if(isset($where['_logic'])) {
                    $op   =  ' '.strtoupper($where['_logic']).' ';
                    unset($where['_logic']);
                }else{
                    $op   =  ' AND ';
                }
                $array   =  array();
                foreach ($where as $field=>$data)
                    $array[] = $this->parseKey($field).' = '.$this->parseValue($data);
                $whereStr   = implode($op,$array);
                break;
        }
        return '( '.$whereStr.' )';
    }


    /**
     * where&#x5206;&#x6790;
     * @access protected
     * @param mixed $where
     * @return string
     */
    public function parseWhere($where) {
        $whereStr = '';
        if(is_string($where)) {
            
            $whereStr = $where;
        }else{ 
            $operate  = isset($where['_logic'])?strtoupper($where['_logic']):'';
            if(in_array($operate,array('AND','OR','XOR'))){
                
                $operate    =   ' '.$operate.' ';
                unset($where['_logic']);
            }else{
                
                $operate    =   ' AND ';
            }
            foreach ($where as $key=>$val){
                if(is_numeric($key)){
                    $key  = '_complex';
                }                    
                if(0===strpos($key,'_')) {
                    
                    $whereStr   .= $this->parseThinkWhere($key,$val);
                }else{
                    
                    if(!preg_match('/^[A-Z_\|\&\-.a-z0-9\(\)\,]+$/',trim($key))){
                        'Expression errors:'.$key;
                    }
                    
                    $multi  = is_array($val) &&  isset($val['_multi']);
                    $key    = trim($key);
                    if(strpos($key,'|')) { 
                        $array =  explode('|',$key);
                        $str   =  array();
                        foreach ($array as $m=>$k){
                            $v =  $multi?$val[$m]:$val;
                            $str[]   = $this->parseWhereItem($this->parseKey($k),$v);
                        }
                        $whereStr .= '( '.implode(' OR ',$str).' )';
                    }elseif(strpos($key,'&')){
                        $array =  explode('&',$key);
                        $str   =  array();
                        foreach ($array as $m=>$k){
                            $v =  $multi?$val[$m]:$val;
                            $str[]   = '('.$this->parseWhereItem($this->parseKey($k),$v).')';
                        }
                        $whereStr .= '( '.implode(' AND ',$str).' )';
                    }else{
                        $whereStr .= $this->parseWhereItem($this->parseKey($key),$val);
                    }
                }
                $whereStr .= $operate;
            }
            $whereStr = substr($whereStr,0,-strlen($operate));
        }
        return empty($whereStr)?'':' WHERE '.$whereStr;
    }

    public function getKeyToValue($field, $result, $sepa){
        if(strpos($field, ',')){
            if(!empty($result)) {
                $_field         =   explode(',', $field);
                $field          =   array_keys($result[0]);
                $key            =   array_shift($field);
                $key2           =   array_shift($field);
                $cols           =   array();
                $count          =   count($_field);
                foreach ($result as $res){
                    $name   =  $res[$key];

                    if(2==$count) {
                        $cols[$name]   =  $res[$key2];
                    }else{
                        $cols[$name]   =  is_string($sepa) ? implode($sepa, array_slice($res, 1)) : $res;
                    }
                }
                return $cols;
            }
        }else{
            if(!empty($result)) {
                foreach ($result as $val){
                    $array[]    =   $val[$field];
                }
                return $array;
            }
        }
    }

    protected function parseGroup($group) {
        return !empty($group)? ' GROUP BY '.$group:'';
    }


    protected function parseJoin($join) {
        $joinStr = '';
        if(!empty($join)) {
            $joinStr    =   ' '.implode(' ',$join).' ';
        }
        return $joinStr;
    }

    public function alias($aliasName = ''){
        if($aliasName){
            $this->_table = $this->_table . ' ' . $aliasName;
        }
        return $this;
    }

    public function join($join,$type='INNER') {
        $prefix =   DB::object()->tablepre;;

        if(is_array($join)) {
            foreach ($join as $key => &$_join){
                $_join  =   preg_replace_callback("/__([A-Z0-9_-]+)__/sU", function($match) use($prefix){ return $prefix.strtolower($match[1]);}, $_join);
                $_join  =   false !== stripos($_join,'JOIN')? $_join : $type.' JOIN ' .$_join;
            }
            $this->options['join']      =   $join;
        }elseif(!empty($join)) {
            $join  = preg_replace_callback("/__([A-Z0-9_-]+)__/sU", function($match) use($prefix){ return $prefix.strtolower($match[1]);}, $join);
            $this->options['join'][]    =   false !== stripos($join,'JOIN')? $join : $type.' JOIN '.$join;
        }
        return $this;
    }

    public function group($join){
        $this->options['group'] = $join;
        return $this;
    }

	public function add($data = array(), $replace = false) {
		$result = DB::insert($this->_table, $data, true, $replace);
		return $result;
	}

    public function addAll($datas, $options=array(), $replace=false) {
        if(!is_array($datas[0])) return false;
        $fields = array_keys($datas[0]);
        $values  =  array();
        foreach ($datas as $data){
            $value   =  array();
            foreach ($data as $key=>$val){
                $val   =  $this->parseValue($val);
                if(is_scalar($val)) { 
                    $value[]   =  $val;
                }
            }
            $values[]    = '('.implode(',', $value).')';
        }
        $sql   =  ($replace?'REPLACE':'INSERT').' INTO %t ('.implode(',', $fields).') VALUES '.implode(',',$values);
        return DB::query($sql, array($this->_table));
    }

	public function delete($where = array()) {
        if(!$where){
            return false;
        }

		return DB::query("DELETE FROM %t %i", array($this->_table, $this->parseWhere($where)));
	}

    public function save($where = array(), $data = array()) {
        $result = DB::query("UPDATE %t SET %i %i", array($this->_table, DB::implode($data), $this->parseWhere($where)));
        return $result;
    }


    public function setInc($where, $field, $step=1) {
        $result = DB::query("UPDATE %t SET %i %i", array($this->_table, $field . ' = '.$field.'+'.$step, $this->parseWhere($where)));
    }

    public function setDec($where, $field,$step=1) {
        $result = DB::query("UPDATE %t SET %i %i", array($this->_table, $field . ' = '.$field.'-'.$step, $this->parseWhere($where)));
    }

	public function getField($where = array(), $field = '*', $order = '') {
        $order = $order ? ' ORDER BY ' . $order : '';
        $joinString = $this->parseJoin(!empty($this->options['join'])?$this->options['join']:'');
		$result = DB::result_first('SELECT '.$field.' FROM %t %i %i '. $order, array($this->_table, $joinString, $this->parseWhere($where)));
		return $result;
	}

    public function find($where = array(), $field = '*', $order = '') {
        $order = $order ? ' ORDER BY ' . $order : '';
        $joinString = $this->parseJoin(!empty($this->options['join'])?$this->options['join']:'');
        $result = (array) DB::fetch_first('SELECT '.$field.' FROM %t %i %i '. $order, array($this->_table, $joinString, $this->parseWhere($where)));
        return $result;
    }


	public function count($where = array()) {
        $joinString = $this->parseJoin(!empty($this->options['join'])?$this->options['join']:'');
		$count = (int) DB::result_first('SELECT count(*) FROM %t %i %i', array($this->_table, $joinString, $this->parseWhere($where)));
		return $count;
	}


	public function select($where = array(), $field = '*', $order = '', $start = 0, $limit = 0, $sepa = null) {

        $order = $order ? ' ORDER BY ' . $order : '';
        $joinString = $this->parseJoin(!empty($this->options['join'])?$this->options['join']:'');

        $groupString = $this->parseGroup(!empty($this->options['group'])?$this->options['group']:'');

		if($start == 0 && $limit == 0){
			$result = (array) DB::fetch_all('SELECT '.$field.' FROM %t %i %i %i '. $order, array($this->_table, $joinString, $this->parseWhere($where), $groupString));
		}else{
			$result = (array) DB::fetch_all('SELECT '.$field.' FROM %t %i %i %i '. $order . ' ' . DB::limit($start, $limit), array($this->_table, $joinString, $this->parseWhere($where), $groupString));
		}

        if($sepa !== null) {
        	$result = $this->getKeyToValue($field, $result, $sepa);
        }

		return $result;
	}
}