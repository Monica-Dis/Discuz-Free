<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}

loadcache('junhua_spider_setting');

class junhua_spider_core {
    function common(){
		global $_G;

    	$setting = dunserialize($_G['cache']['junhua_spider_setting']);

		$firewall_open		= $setting['firewall_open'];
		$firewall_string	= $setting['firewall_string'];

		if($firewall_open != 1 || !$firewall_string){
			return;
		}

		$firewall_array = explode('|', strtolower($firewall_string));

		if(!$firewall_array){
			return;
		}

		$useragent	= strtolower($_SERVER['HTTP_USER_AGENT']);

		if(dstrpos($useragent, $firewall_array)){
			exit('');
		}
    }

    function global_footer(){
		global $_G, $navtitle;

    	$setting = dunserialize($_G['cache']['junhua_spider_setting']);

		$spider_open = $setting['spider_open'];
		$spider_type = $setting['spider_type'];

		if($spider_open != 1){
			return;
		}


		$useragent	= strtolower($_SERVER['HTTP_USER_AGENT']);
		$ip			= $_SERVER['REMOTE_ADDR'];

		$spider_ip = str_replace("\r", "", $setting['spider_ip']);
		$spider_ip = explode("\n", $spider_ip);
		$spider_ip = array_filter($spider_ip);

		$isOk = true;
		foreach ($spider_ip as $key => $value) {
			$value = str_replace('.', '\.', $value);
			$value = str_replace('*', '(\w+)', $value);
			$pattern = '/'.$value.'/';
			if(preg_match($pattern, $ip)){
				$isOk = false;
				break;
			}
		}

		if(!$isOk){
			return;
		}

		$spidername = array(
			'googlebot'				=> 1,
			'baiduspider'			=> 2,
			'yodaobot'				=> 3,
			'youdaobot'				=> 3,
			'yahoo! slurp china'	=> 4,
			'yahoo'					=> 4,
			'sogou spider'			=> 5,
			'sogou web spider'		=> 5,
			'sosospider'			=> 6,
			'sosoimagespider'		=> 6,
			'360spider'				=> 7,
			'qihoobot'				=> 7,
			'bingbot'				=> 8,
		);

		$spiderkey = 0;
		foreach ($spidername AS $key => $value) {
			if (strpos($useragent, $key) !== false) {
				$spiderkey = $value;
				break;
			}
		}

		if(!in_array($spiderkey, $spider_type)){
			return;
		}

		//&#x5f53;&#x524d;&#x57df;&#x540d;
	    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
	    $url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    
		if ($spiderkey) {

			$data = array(
				'spider_type'	=> $spiderkey,
				'ip'			=> $ip,
				'xff_ip'		=> $_SERVER['HTTP_X_FORWARDED_FOR'],
				'add_time'		=> $_G['timestamp'],
				'title'			=> $navtitle,
				'url'			=> $url,
			);

			DB::insert('junhua_spider_logs', $data);
		}

    }
}

class mobileplugin_junhua_spider extends junhua_spider_core {

	function common(){
    	parent::common();
	}

    function global_footer(){
    	parent::global_footer();
    }
}

class plugin_junhua_spider extends junhua_spider_core {

	function common(){
    	parent::common();
	}

    function global_footer(){
    	parent::global_footer();
    }
}
