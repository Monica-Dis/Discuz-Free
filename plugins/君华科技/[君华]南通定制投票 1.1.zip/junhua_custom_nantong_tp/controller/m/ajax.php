<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!in_array($a, array('vote', 'apply'))){
    $a = 'vote';
}

$voteModel  = new junhua_model('customNantongTpVote');
$paramModel = new junhua_model('customNantongTpVoteParam');
$logModel   = new junhua_model('customNantongTpVoteLog');

if($a == 'vote'){

    if(IS_AJAX){

        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }


        $json = junhua_I('json', '');
        $json = str_replace('&quot;', '"', $json);

        $json = json_decode($json, true);

        //&#x5224;&#x65ad; 
        $vote_id = $json['vote_id'];

        $where = array();
        $where['vote_id'] = $vote_id;
        $where['last_time'] = array('gt', $_G['timestamp']);

        $voteInfo = $voteModel->find($where);
        if(!$voteInfo){
            exit;
        }

        //&#x6240;&#x6709;&#x7684;&#x914d;&#x7f6e;
        $setting = dunserialize($voteInfo['setting']);

        //&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x6295;&#x7968;&#x9009;&#x9879;
        $paramlist = $paramModel->select(array(
            'vote_id'       => $vote_id,
        ));

        //&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x6295;&#x7968;&#x9009;&#x9879;
        $loginfo = $logModel->find(array(
            'vote_id'       => $vote_id,
            'user_id'       => $uid,
        ));

        if($loginfo){
            $data = array('code' => 0, 'msg' => '&#x60a8;&#x5df2;&#x6295;&#x7968;&#xff0c;&#x8bf7;&#x52ff;&#x91cd;&#x590d;&#x6295;&#x7968;');
            junhua_ajaxReturn($data);
        }

        $vote = array();
        $isOk = false;

        foreach ($paramlist as $key => $value) {
            if(in_array($key, $json['vote_item'][0]['item_idx_list']['item_idx'])){
                
                $isOk = true;
                $vote[$value['param_id']] = $value['param_id'];

                $paramModel->setInc(array(
                    'param_id'       => $value['param_id'],
                ), 'vote_right');
            }
        }
        //&#x5224;&#x65ad;&#x662f;&#x5426;&#x662f;&#x4e2d;&#x5956;&#x7528;&#x6237;
        if($isOk){
            $logid = $logModel->add(array(
                'vote'     => serialize($vote),
                'user_id'  => $uid,
                'vote_id'  => $vote_id,
                'add_time' => $_G['timestamp'],
            ));
        }

        //&#x83b7;&#x53d6;
        $paiming = $logModel->count(array(
            'vote_id'  => $vote_id,
        ));


        $lottery = $setting['lottery'];
        $lottery = str_replace("\r", "", $lottery);
        $lottery = explode("\n", $lottery);
        $lottery = array_filter($lottery);

        $lotteryData = array();
        foreach ($lottery as $key => $value) {
            $value = explode(":", $value);
            $lotteryData[$value[0]] = $value[1];
        }

        if(isset($lotteryData[$paiming])){

            $logid = $logModel->save(array(
                'log_id'     => $logid,
            ),array(
                'luck_word' => $lotteryData[$paiming],
                'is_luck'   => 1,
            ));

            $data = array('code' => 3, 'msg' => '&#x606d;&#x559c;&#x4e2d;&#x5956;', 'pm' => $paiming, 'lottery' => $lotteryData[$paiming]);
        }else{
            $data = array('code' => 2, 'msg' => '&#x611f;&#x8c22;&#x53c2;&#x4e0e;', 'pm' => $paiming);
        }

        junhua_ajaxReturn($data);

    }else{
        exit;
    }
}elseif($a == 'apply'){

    if(IS_AJAX){

        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        $vote_id  = junhua_I('vote_id/d', 0);
        $xingming = junhua_I('xingming', '');
        $mobile   = junhua_I('mobile', '');

        $where = array();
        $where['vote_id'] = $vote_id;
        $voteInfo = $voteModel->find($where);
        if(!$voteInfo){
            exit;
        }

        $loginfo = $logModel->find(array(
            'vote_id'       => $vote_id,
            'user_id'       => $uid,
            'is_luck'       => 1,
        ));

        if(!$loginfo){
            $data = array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
            junhua_ajaxReturn($data);
        }

        //&#x5224;&#x65ad;&#x662f;&#x5426;&#x662f;&#x4e2d;&#x5956;&#x7528;&#x6237;
        $logModel->save(array(
            'log_id'     => $loginfo['log_id'],
        ),array(
            'xingming' => $xingming,
            'mobile'   => $mobile,
        ));

        $data = array('code' => 2, 'msg' => '&#x63d0;&#x4ea4;&#x6210;&#x529f;');

        junhua_ajaxReturn($data);

    }else{
        exit;
    }
}
else{
	exit;
}