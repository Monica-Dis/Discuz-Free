<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!in_array($a, array('index', 'luck'))){
    $a = 'index';
}

//&#x5f00;&#x542f;&#x5206;&#x4eab;
$junhua_shareurl = $refererurl;

//&#x5f00;&#x542f;&#x5206;&#x4eab;
if(IS_WEIXIN){
    include_once('source/plugin/junhua_base/jssdk/weixin_jssdk.php');
    $weixin_appid = $junhua_custom_nantong_tp_setting['weixin_appid'] ? trim($junhua_custom_nantong_tp_setting['weixin_appid']) : trim($junhua_base_config['weixin_appid']);
    $weixin_appsecret = $junhua_custom_nantong_tp_setting['weixin_appsecret'] ? trim($junhua_custom_nantong_tp_setting['weixin_appsecret']) : trim($junhua_base_config['weixin_appsecret']);
    $jssdk = new WEIXIN_JSSDK($weixin_appid, $weixin_appsecret);
    $signPackage = $jssdk->getSignPackage();

}

//&#x70ae;&#x7070;
if($junhua_custom_nantong_tp_setting['weixin_paohui_url']){
    $paohuiUrl = explode("\n", $junhua_custom_nantong_tp_setting['weixin_paohui_url']);
    $junhua_shareurl = str_replace($_G['siteurl'], $paohuiUrl[array_rand($paohuiUrl)]."/", $junhua_shareurl);
}

$voteModel  = new junhua_model('customNantongTpVote');
$paramModel = new junhua_model('customNantongTpVoteParam');
$logModel   = new junhua_model('customNantongTpVoteLog');


$inwchat = (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
$xigua_login_config = $_G['cache']['plugin']['xigua_login'];
if(
    $xigua_login_config['openautologin'] &&
    !$_G['uid'] &&
    $inwchat
){
    dheader("Location: ".$_G['siteurl'].'plugin.php?id=xigua_login:login&backreferer='.urlencode($refererurl));
    exit;
}


if($a == 'index'){
    $vote_id = junhua_I('vote_id/d', 0);

    //&#x83b7;&#x53d6;&#x6295;&#x7968;&#x7684;&#x8be6;&#x60c5;
    $where = array('vote_id' => $vote_id);
    $voteInfo = $voteModel->find($where);

    $setting = dunserialize($voteInfo['setting']);

    //&#x83b7;&#x53d6;&#x6295;&#x7968;&#x7684;&#x5b50;&#x9879;

    $banners = $setting['banners'];
    $banners = str_replace("\r", "", $banners);
    $banners = explode("\n", $banners);
    $banners = array_filter($banners);

    $bannerList = array();
    foreach ($banners as $key => $value) {
        $bn = explode("|", $value);
        $bannerList[$key]['src'] = $bn[0];
        $bannerList[$key]['link'] = $bn[1];
    }


    //&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x6295;&#x7968;&#x9009;&#x9879;
    $paramlist = $paramModel->select(array(
        'vote_id'       => $vote_id,
    ));

    //&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x6295;&#x7968;&#x9009;&#x9879;
    $votelog = $logModel->find(array(
        'vote_id'       => $vote_id,
        'user_id'       => $uid,
    ));

    $vote = dunserialize($votelog['vote']);

    $datap = array();
    $total_cnt = 0;
    foreach ($paramlist as $key => $value) {
        $datap[] = array(
                "name"     => $value['param_title'],
                "cnt"      => $value['vote_right'],
                "selected" => $vote[$value['param_id']] ? true : false
        );

        $total_cnt += $value['vote_right']; 
    }

    $voteData = array(
        "vote_id"     => $voteInfo['vote_id'],
        "title"       => $voteInfo['vote_title'],
        "expire_time" => $voteInfo['last_time'],
        "is_luck"     => $votelog['is_luck'],
        "mobile"      => $votelog['mobile'],
        "lottery"     => $votelog['luck_word'],
        "xingming"    => $votelog['xingming'],
        "pm"          => 0,
        "vote_subject" => array(
            array(
                "type"      => 2,
                "title"     => $voteInfo['vote_title'],
                "options"   => $datap,
                "total_cnt" => $total_cnt,
            )
        ),
        "del_flag" => 0
    );

    $block_title = $voteInfo['vote_title'];
    $block_css = '';
}elseif($a == 'luck'){
    $vote_id = junhua_I('vote_id/d', 0);

    //&#x83b7;&#x53d6;&#x6295;&#x7968;&#x7684;&#x8be6;&#x60c5;
    $where = array('vote_id' => $vote_id);
    $voteInfo = $voteModel->find($where);

    $setting = dunserialize($voteInfo['setting']);

    //&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x6295;&#x7968;&#x9009;&#x9879;
    $paramlist = $paramModel->select(array(
        'vote_id'       => $vote_id,
    ));

    //&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x6295;&#x7968;&#x9009;&#x9879;
    $votelog = $logModel->find(array(
        'vote_id'       => $vote_id,
        'user_id'       => $uid,
        'is_luck'       => 1,
        'mobile'        => '',
    ));

    if(!$votelog){
        dheader("Location: ".junhua_url('m/index/index', "vote_id=".$vote_id, 1));
        exit;
    }

    $vote = dunserialize($votelog['vote']);

    $datap = array();
    $total_cnt = 0;
    $selectedlist = array();
    foreach ($paramlist as $key => $value) {
        $datap[] = array(
                "name"     => $value['param_title'],
                "cnt"      => $value['vote_right'],
                "selected" => $vote[$value['param_id']] ? true : false
        );

        if($vote[$value['param_id']]){
            $selectedlist[] = $value['param_title'];
        }

        $total_cnt += $value['vote_right']; 
    }

    $paiming = $logModel->count(array(
        'vote_id'  => $vote_id,
        'log_id'  => array('elt', $votelog['log_id']),
    ),'log_id asc');


    $voteData = array(
        "vote_id"     => $voteInfo['vote_id'],
        "title"       => $voteInfo['vote_title'],
        "expire_time" => $voteInfo['last_time'],
        "is_luck"     => $votelog['is_luck'],
        "mobile"      => $votelog['mobile'],
        "lottery"     => $votelog['luck_word'],
        "xingming"    => $votelog['xingming'],
        "pm"          => $paiming,
        "vote_subject" => array(
            array(
                "type"      => 2,
                "title"     => $voteInfo['vote_title'],
                "options"   => $datap,
                "total_cnt" => $total_cnt,
            )
        ),
        "del_flag" => 0
    );

    $block_title = $voteInfo['vote_title'];
    $block_css = '';
}
else{
    exit;
}

include template('junhua_custom_nantong_tp:m/index/'.$a);