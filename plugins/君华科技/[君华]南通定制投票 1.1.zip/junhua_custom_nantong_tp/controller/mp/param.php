<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!in_array($a, array('add', 'edit', 'del', 'index'))){
    $a = 'index';
}

$voteModel  = new junhua_model('customNantongTpVote');
$paramModel = new junhua_model('customNantongTpVoteParam');
$logModel   = new junhua_model('customNantongTpVoteLog');

if($a == 'index'){

    $vote_id = junhua_I('vote_id/d', 1);
    $page    = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 50);

    $where    = array('vote_id' => $vote_id);
    $voteInfo = $voteModel->find($where);

    if(!$voteInfo){
        dheader('location:' . junhua_url('mp/vote/index', '', 1));
        exit;
    }

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $where = array();

    if($vote_id){
        $param['vote_id'] = $vote_id;
        $where['vote_id'] = $vote_id;
    }

    $theurl = junhua_url('mp/param/index', http_build_query($param), true);
    $totalNum = $paramModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $paramModel->select($where, '*', '', $start, $perpage);

    $block_head_title = '&#x9009;&#x9879;&#x7ba1;&#x7406;';
    $block_title = '&#x9009;&#x9879;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {

    $vote_id  = junhua_I('vote_id/d', 0);
    $where    = array('vote_id' => $vote_id);
    $voteInfo = $voteModel->find($where);

    if(!$voteInfo){
        dheader('location:' . junhua_url('mp/vote/index', '', 1));
        exit;
    }

    if(IS_AJAX){

        $param_title = junhua_I('param_title', '');

        $data = array(
            'param_title' => $param_title,
            'vote_id'     => $vote_id,
            'add_time'    => $_G['timestamp'],
        );

        $paramModel->add($data);

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/param/index', 'vote_id='.$vote_id, true)));
    }

    $block_head_title = '&#x9009;&#x9879;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x9009;&#x9879;';
    $block_css = '';
    $a = 'update';
}elseif ($a == 'edit') {

    $param_id = junhua_I('param_id/d', 0);

    $where = array('param_id' => $param_id);
    $paramInfo = $paramModel->find($where);

    if(!$paramInfo){
        dheader('location:' . junhua_url('mp/param/index', 'vote_id='.$paramInfo['vote_id'], 1));
        exit;
    }

    if(IS_AJAX){

        $param_title = junhua_I('param_title', '');

        $data = array(
            'param_title' => $param_title,
        );

        $paramModel->save($where, $data);
        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/param/index', 'vote_id='.$paramInfo['vote_id'], 1)));
    }

    $block_head_title = '&#x9009;&#x9879;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x9009;&#x9879;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'del'){
    if(IS_AJAX){
        $param_id = junhua_I('param_id/d', 0);

        $where = array(
            'param_id'      => $param_id
        );

        $paramInfo = $paramModel->find($where);
        if(!$paramInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $paramModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}
else{
    exit;
}

$block_content = 'junhua_custom_nantong_tp:mp/'.$c.'/'.$a;

include template('junhua_custom_nantong_tp:mp/layout');