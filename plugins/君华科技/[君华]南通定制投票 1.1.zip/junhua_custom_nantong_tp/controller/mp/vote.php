<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array('add', 'edit', 'del', 'index'))){
    $a = 'index';
}

$voteModel  = new junhua_model('customNantongTpVote');
$paramModel = new junhua_model('customNantongTpVoteParam');
$logModel   = new junhua_model('customNantongTpVoteLog');

if($a == 'index'){

    $page = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $theurl = junhua_url('mp/vote/index', http_build_query($param), true);


    $where = array();
    $totalNum = $voteModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $voteModel->select($where, '*', '', $start, $perpage);

    foreach ($lists as $key => $value) {
        $lists[$key]['vote_num'] = (int) $logModel->count(array('vote_id' => $value['vote_id']));
    }


    $block_head_title = '&#x6295;&#x7968;&#x7ba1;&#x7406;';
    $block_title = '&#x6295;&#x7968;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {
	if(IS_AJAX){

        $setting    = junhua_I('setting/a', array());
        $vote_title = junhua_I('vote_title', '');
        $content    = junhua_I('content', '');
        $last_time  = junhua_I('last_time', '');
        $params     = junhua_I('params', '');

        $last_time = strtotime($last_time);
        $data = array(
            'vote_title' => $vote_title,
            'content'    => $content,
            'setting'    => serialize($setting),
            'last_time'  => $last_time,
            'add_time'   => $_G['timestamp'],
		);

		$vote_id = $voteModel->add($data);

        $params = str_replace("\r", "", $params);
        $params = explode("\n", $params);
        $params = array_filter($params);

        $data = array();
        foreach ($params as $key => $value) {
            $data[] = array(
                'vote_id'     => $vote_id,
                'param_title' => $value,
                'vote_right'  => 0,
                'add_time'    => $_G['timestamp'],
            );
        }

        if($data){
            $paramModel->addAll($data);
        }

        include_once('source/plugin/junhua_base/libs/qrcode.class.php');

        QRcode::png($_G['siteurl'].'plugin.php?id=junhua_custom_nantong_tp&vote_id='.$vote_id, 'source/plugin/junhua_custom_nantong_tp/upload/ewm/'.$vote_id.'.png', 'L', 6, 2);

	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/vote/index', '', true)));
	}

    $block_head_title = '&#x6295;&#x7968;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x6295;&#x7968;';
    $block_css = '';
    $a = 'update';
}elseif ($a == 'edit') {

	$vote_id = junhua_I('vote_id/d', 0);

	$where = array('vote_id' => $vote_id);
	$voteInfo = $voteModel->find($where);

	if(!$voteInfo){
        dheader('location:' . junhua_url('mp/vote/index', '', 1));
        exit;
	}

    $voteInfo['last_time'] = date('Y-m-d H:i:s', $voteInfo['last_time']);
    $voteInfo['setting'] = dunserialize($voteInfo['setting']);

    $voteInfo['banners'] = explode("\n", $voteInfo['setting']['banners']);
    $voteInfo['banners'] = array_filter($voteInfo['banners']);

    $banners = array();
    foreach ($voteInfo['banners'] as $key => $value) {
        $bn = explode("|", $value);
        $banners[$key]['src'] = $bn[0];
        $banners[$key]['link'] = $bn[1];
    }

	if(IS_AJAX){

        $setting    = junhua_I('setting/a', array());
        $vote_title = junhua_I('vote_title', '');
        $content    = junhua_I('content', '');
        $last_time  = junhua_I('last_time', '');

        $last_time = strtotime($last_time);


		$data = array(
            'vote_title' => $vote_title,
            'content'    => $content,
            'setting'    => serialize($setting),
            'last_time'  => $last_time,
            'add_time'   => $_G['timestamp'],
		);

		$voteModel->save($where, $data);
	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/vote/index', '', 1)));
	}

    $block_head_title = '&#x6295;&#x7968;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x6295;&#x7968;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'del'){
    if(IS_AJAX){
        $vote_id = junhua_I('vote_id/d', 0);

        $where = array(
            'vote_id'      => $vote_id
        );

        $voteInfo = $voteModel->find($where);
        if(!$voteInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $voteModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}
else{
	exit;
}

$block_content = 'junhua_custom_nantong_tp:mp/'.$c.'/'.$a;

include template('junhua_custom_nantong_tp:mp/layout');