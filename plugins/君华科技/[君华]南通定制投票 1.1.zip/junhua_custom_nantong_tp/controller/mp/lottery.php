<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!in_array($a, array('index', 'set', 'export'))){
    $a = 'index';
}

$voteModel  = new junhua_model('customNantongTpVote');
$paramModel = new junhua_model('customNantongTpVoteParam');
$logModel   = new junhua_model('customNantongTpVoteLog');

if($a == 'index'){

    $vote_id = junhua_I('vote_id/d', 0);
    $page    = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 50);

    $where    = array('vote_id' => $vote_id);
    $voteInfo = $voteModel->find($where);

    if(!$voteInfo){
        dheader('location:' . junhua_url('mp/vote/index', '', 1));
        exit;
    }

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $where = array();

    if($vote_id){
        $param['vote_id'] = $vote_id;
        $where['vote_id'] = $vote_id;
    }

    $where['is_luck'] = 1;

    $theurl = junhua_url('mp/lottery/index', http_build_query($param), true);
    $totalNum = $logModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $logModel->select($where, '*', '', $start, $perpage);

    $exportUrl = junhua_url('mp/lottery/export', http_build_query($param), 1);


    $block_head_title = '&#x4e2d;&#x5956;&#x7ba1;&#x7406;';
    $block_title = '&#x4e2d;&#x5956;&#x5217;&#x8868;';
    $block_css = '';
}elseif($a == 'set'){
    if(IS_AJAX){
        $log_id = junhua_I('log_id/d', 0);

        $where = array(
            'log_id'      => $log_id
        );

        $logInfo = $logModel->find($where);
        if(!$logInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($logInfo['is_lq'] == 1){
            $is_lq = 0;
        }else{
            $is_lq = 1;
        }

        $logModel->save($where, array('is_lq' => $is_lq));

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'export'){

    $vote_id = junhua_I('vote_id/d', 0);
    $where = array();

    $where['vote_id'] = $vote_id;
    $where['is_luck'] = 1;

    $filename = date("YmdHis") . '.csv';
    header('Content-Description: File Transfer');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Type: text/comma-separated-values');   
    header('Content-Transfer-Encoding: binary');


    $lists = $logModel->select($where, '*', 'log_id asc');

    foreach ($lists as $key => $value) {
        if($key == 0){

            $header = array();
            $header[] = junhua_utf82gbk(junhua_unicodeDecode('&#x59d3;&#x540d;'));
            $header[] = junhua_utf82gbk(junhua_unicodeDecode('&#x624b;&#x673a;'));
            $header[] = junhua_utf82gbk(junhua_unicodeDecode('&#x4e2d;&#x5956;&#x5185;&#x5bb9;'));
            $header[] = junhua_utf82gbk(junhua_unicodeDecode('&#x4e2d;&#x5956;&#x65f6;&#x95f4;'));
            $header[] = junhua_utf82gbk(junhua_unicodeDecode('&#x662f;&#x5426;&#x9886;&#x53d6;'));

            echo diconv(implode(',', $header), CHARSET, "GB18030");
        }

        $vl = array();
        $vl['xingming']  = $value['xingming'];
        $vl['mobile']    = $value['mobile'];
        $vl['luck_word'] = $value['luck_word'];
        $vl['add_time']  = date('Y-m-d H:i:s', $value['add_time']);
        $vl['is_lq']     = $value['is_lq'] ? junhua_utf82gbk(junhua_unicodeDecode('&#x5df2;&#x9886;&#x53d6;')) : junhua_utf82gbk(junhua_unicodeDecode('&#x672a;&#x9886;&#x53d6;'));

        echo "\n".diconv(implode(",\t", $vl), CHARSET, "GB18030");
    }
    exit;
}
else{
    exit;
}

$block_content = 'junhua_custom_nantong_tp:mp/'.$c.'/'.$a;

include template('junhua_custom_nantong_tp:mp/layout');