<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array('index', 'uploadfile', 'uploadfile_editor'))){
    $a = 'index';
}

loadcache('junhua_custom_nantong_tp_system');
$junhua_custom_nantong_tp_system = dunserialize($_G['cache']['junhua_custom_nantong_tp_system']);

$dataOrg = array(
    'weixin_appid'      => $junhua_custom_nantong_tp_setting['weixin_appid'],
    'weixin_appsecret'  => $junhua_custom_nantong_tp_setting['weixin_appsecret'],
    'weixin_paohui_url' => $junhua_custom_nantong_tp_setting['weixin_paohui_url'],
    'share_title'       => $junhua_custom_nantong_tp_setting['share_title'],
    'share_desc'        => $junhua_custom_nantong_tp_setting['share_desc'],
    'share_img'         => $junhua_custom_nantong_tp_setting['share_img'],
    'system_title'      => $junhua_custom_nantong_tp_setting['system_title'],
);

if($a == 'index'){

    if(IS_AJAX){
        
        $share_title       = junhua_I('share_title', '');
        $share_desc        = junhua_I('share_desc', '');
        $share_img         = junhua_I('share_img', '');
        $weixin_appid      = junhua_I('weixin_appid', '');
        $weixin_appsecret  = junhua_I('weixin_appsecret', '');
        $weixin_paohui_url = junhua_I('weixin_paohui_url', '');
        $system_title      = junhua_I('system_title', '');

        //&#x8fc7;&#x6ee4;&#x56de;&#x8f66;&#x7a7a;&#x683c;
        $weixin_paohui_url = str_replace("\r", "", $weixin_paohui_url);
        $weixin_paohui_url = explode("\n", $weixin_paohui_url);
        $weixin_paohui_url = array_filter($weixin_paohui_url);
        if($weixin_paohui_url){
            $weixin_paohui_url = array_map("trim", $weixin_paohui_url);
            $weixin_paohui_url = implode("\n", $weixin_paohui_url);
        }else{
            $weixin_paohui_url = '';
        }

        $data = array(
            'weixin_appid'      => $weixin_appid,
            'weixin_appsecret'  => $weixin_appsecret,
            'weixin_paohui_url' => $weixin_paohui_url,
            'share_title'       => $share_title,
            'share_desc'        => $share_desc,
            'share_img'         => $share_img,
            'system_title'      => $system_title,
        );

        $data = array_merge($dataOrg, $data);

        savecache('junhua_custom_nantong_tp_setting', serialize($data));
        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x914d;&#x7f6e;&#x6210;&#x529f;'));
    }

    $block_head_title = '&#x7cfb;&#x7edf;&#x914d;&#x7f6e;';
    $block_title = '&#x7cfb;&#x7edf;&#x914d;&#x7f6e;';
    $block_css = '';
}elseif($a == 'uploadfile'){
    include_once('source/plugin/junhua_base/libs/filemanger.class.php');

    if (!IS_POST && isset($_FILES) ? $_FILES : array()) {
        exit;
    }

    $filemanger = new junhua_filemanger('source/plugin/junhua_custom_nantong_tp', 'source/plugin/junhua_custom_nantong_tp');
    $img_path = $filemanger->uploadJson('Filedata', false);

    junhua_ajaxReturn(array('status' => 1, 'file_path' => $img_path));
}elseif($a == 'uploadfile_editor'){
    include_once('source/plugin/junhua_base/libs/filemanger.class.php');

    if (!IS_POST && isset($_FILES) ? $_FILES : array()) {
        exit;
    }

    $filemanger = new junhua_filemanger('source/plugin/junhua_custom_nantong_tp', 'source/plugin/junhua_custom_nantong_tp');
    $img_path = $filemanger->uploadJson('imgFile');
    exit;
}
else{
	exit;
}

$block_content = 'junhua_custom_nantong_tp:mp/'.$c.'/'.$a;
include template('junhua_custom_nantong_tp:mp/layout');