<?php
/**
 * XML &#x5de5;&#x5177;&#x7c7b;&#xff0c;&#x7528;&#x4e8e;&#x6784;&#x5efa;&#x4e0e;&#x89e3;&#x6790; XML.
 */
class XML
{
    /**
     * XML &#x8f6c;&#x6362;&#x4e3a;&#x6570;&#x7ec4;.
     *
     * @param string $xml XML string
     *
     * @return array
     */
    public static function parse($xml)
    {
        $data = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NOBLANKS);

        if (is_object($data) && get_class($data) === 'SimpleXMLElement') {
            $data = self::arrarval($data);
        }

        return $data;
    }

    /**
     * XML&#x7f16;&#x7801;
     *
     * @param mixed  $data &#x6570;&#x636e;
     * @param string $root &#x6839;&#x8282;&#x70b9;&#x540d;
     * @param string $item &#x6570;&#x5b57;&#x7d22;&#x5f15;&#x7684;&#x5b50;&#x8282;&#x70b9;&#x540d;
     * @param string $attr &#x6839;&#x8282;&#x70b9;&#x5c5e;&#x6027;
     * @param string $id   &#x6570;&#x5b57;&#x7d22;&#x5f15;&#x5b50;&#x8282;&#x70b9;key&#x8f6c;&#x6362;&#x7684;&#x5c5e;&#x6027;&#x540d;
     *
     * @return string
     */
    public static function build(
        $data,
        $root = 'xml',
        $item = 'item',
        $attr = '',
        $id = 'id'
    ) {
        if (is_array($attr)) {
            $_attr = array();

            foreach ($attr as $key => $value) {
                $_attr[] = "{$key}=\"{$value}\"";
            }

            $attr = implode(' ', $_attr);
        }

        $attr = trim($attr);
        $attr = empty($attr) ? '' : " {$attr}";
        $xml = "<{$root}{$attr}>";
        $xml  .= self::data2Xml($data, $item, $id);
        $xml  .= "</{$root}>";

        return $xml;
    }

    /**
     * &#x751f;&#x6210;<![CDATA[%s]]>.
     *
     * @param string $string &#x5185;&#x5bb9;
     *
     * @return string
     */
    public static function cdata($string)
    {
        return sprintf('<![CDATA[%s]]>', $string);
    }

    /**
     * &#x628a;&#x5bf9;&#x8c61;&#x8f6c;&#x6362;&#x6210;&#x6570;&#x7ec4;.
     *
     * @param string $data &#x6570;&#x636e;
     *
     * @return array
     */
    private static function arrarval($data)
    {
        if (is_object($data) && get_class($data) === 'SimpleXMLElement') {
            $data = (array) $data;
        }

        if (is_array($data)) {
            foreach ($data as $index => $value) {
                $data[$index] = self::arrarval($value);
            }
        }

        return $data;
    }

    /**
     * &#x8f6c;&#x6362;&#x6570;&#x7ec4;&#x4e3a;xml.
     *
     * @param array  $data &#x6570;&#x7ec4;
     * @param string $item item&#x7684;&#x5c5e;&#x6027;&#x540d;
     * @param string $id   id&#x7684;&#x5c5e;&#x6027;&#x540d;
     *
     * @return string
     */
    private static function data2Xml($data, $item = 'item', $id = 'id')
    {
        $xml = $attr = '';

        foreach ($data as $key => $val) {
            if (is_numeric($key)) {
                $id && $attr = " {$id}=\"{$key}\"";
                $key = $item;
            }

            $xml .= "<{$key}{$attr}>";

            if ((is_array($val) || is_object($val))) {
                $xml .= self::data2Xml((array) $val, $item, $id);
            } else {
                $xml .= is_numeric($val) ? $val : self::cdata($val);
            }

            $xml .= "</{$key}>";
        }

        return $xml;
    }
}
