<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class junhua_App
{
    private $AppType;
    private $BaseConfig;
    private $PluginConfig;

    private $maga_url;
    private $maga_appsecret;
    private $maga_zs_appsecret;
    
    private $qf_hostname;
    private $qf_secret;
    private $qf_token;


    public function __construct($BaseConfig = array(), $PluginConfig = array()) {
        $this->AppType            = $BaseConfig['app_type'] == 1 ? 'Maga' : ($BaseConfig['app_type'] == 2 ? 'Qf' : '');
        $this->BaseConfig         = $BaseConfig;
        $this->PluginConfig       = $PluginConfig;
        
        $this->maga_url          = $PluginConfig['maga_url'] ? trim($PluginConfig['maga_url']) : trim($BaseConfig['maga_url']);
        $this->maga_appsecret    = $PluginConfig['maga_appsecret'] ? trim($PluginConfig['maga_appsecret']) : trim($BaseConfig['maga_appsecret']);
        $this->maga_zs_appsecret = $PluginConfig['maga_zs_appsecret'] ? trim($PluginConfig['maga_zs_appsecret']) : trim($BaseConfig['maga_zs_appsecret']);

        $this->qf_hostname = $PluginConfig['qf_hostname'] ? trim($PluginConfig['qf_hostname']) : trim($BaseConfig['qf_hostname']);
        $this->qf_secret   = $PluginConfig['qf_secret'] ? trim($PluginConfig['qf_secret']) : trim($BaseConfig['qf_secret']);
        $this->qf_token    = $PluginConfig['qf_token'] ? trim($PluginConfig['qf_token']) : trim($BaseConfig['qf_token']);
        $this->qf_fwhuid   = $PluginConfig['qf_fwhuid'] ? trim($PluginConfig['qf_fwhuid']) : trim($BaseConfig['qf_fwhuid']);

        if($this->AppType == ''){
            return false;
        }
    }

    public function getMagaUserInfo(){

        $userAgent = $_SERVER['HTTP_USER_AGENT'];
        $info      = strstr($userAgent, "MAGAPPX");
        $info      = explode("|", $info);
        $token     = $info[7];

        $appurl = $this->maga_url.'/mag/cloud/cloud/getUserInfo?token='.$info[7].'&secret='.$this->maga_appsecret;
        $appdata = dfsockopen($appurl);
        if (!$appdata) {
            $appdata = file_get_contents($appurl);
        }

        $r =  json_decode($appdata, true);
        return $r;
    }

    public function getQfUserInfo(){
        $appdata = $this->QfRequest('POST', 'users/parse-user', array('wap_token' => $_COOKIE['wap_token']));
        return $appdata;
    }

    //&#x5343;&#x5e06;&#x94b1;&#x5305;&#x4f59;&#x989d;&#x67e5;&#x8be2;
    public function getQfWallets($uid){
        if(is_numeric($uid) && $uid != 0){
            $appdata = $this->QfRequest('GET', 'wallets/'. $uid);
        }elseif (is_string($uid) && $uid != '') {
            $appdata = $this->QfRequest('GET', 'wallets/batch?ids='. $uid);
        }else{
            $appdata = array();
        }
        return $appdata;
    }

    //&#x5343;&#x5e06;&#x94b1;&#x5305;&#x4f59;&#x989d;&#x66f4;&#x6539;
    /**
     * @author Hu Hua Feng
     * @param type  int &#x540e;&#x53f0;&#x7684;type &#x5c0f;&#x540e;&#x53f0; &#x300b;&#x4ea4;&#x6613;&#x7ba1;&#x7406; &#x300b;&#x652f;&#x4ed8;&#x7ba1;&#x7406; &#x300b;&#x8bbe;&#x7f6e; &#x300b;&#x652f;&#x4ed8;&#x8bbe;&#x7f6e; &#x589e;&#x51cf;&#x5fc5;&#x987b;&#x5206;&#x5f00;
     * @param gold  &#x91d1;&#x5e01; +
     * @param cash  &#x94b1;&#x5e01;
     * @return 
     * @todo &#x5343;&#x5e06;&#x94b1;&#x5305;&#x63a5;&#x53e3;
     */

    public function setQfWallets($uid, $data = array()){

        if (strtolower(CHARSET) == 'gbk') {
            $data = junhua_array_map('junhua_gbk2utf8', $data);
        }

        $appdata = $this->QfRequest('PUT', 'wallets/'. $uid, $data);
        return $appdata;
    }

    //&#x83b7;&#x53d6;&#x9a6c;&#x7532;&#x91d1;&#x5e01;&#x6570;
    public function getMagaGold($user_id){

        $url = $this->maga_url.'/mag/user/v1/GradeScore/userGoldGet?user_id='.$user_id.'&secret='.$this->maga_appsecret;

        $appdata = dfsockopen($url);
        if (!$appdata) {
            $appdata = file_get_contents($url);
        }

        $result =  json_decode($appdata, true);
        return $result;
    }

    //&#x83b7;&#x53d6;&#x521b;&#x5efa;&#x8ba2;&#x5355;
    public function getMagaCreateOrder($param = array()){
        global $_G;
        
        if(!$param){
            return false;
        }

        $out_trade_no = $param['out_trade_no']; //&#x5916;&#x90e8;&#x8ba2;&#x5355;
        $money        = $param['money']; //&#x652f;&#x4ed8;&#x91d1;&#x989d;
        $des          = $param['des']; //&#x652f;&#x4ed8;&#x63cf;&#x8ff0;
        $remark       = $param['remark']; //&#x652f;&#x4ed8;&#x5907;&#x6ce8;
        $uid          = $param['uid'];  //&#x7528;&#x6237;UID
        $title        = $param['title']; //&#x652f;&#x4ed8;&#x6807;&#x9898;

        $sign = md5($out_trade_no.CURMODULE.$this->maga_appsecret.CURMODULE);
        $callback     = $param['callback'] ? $param['callback'] : $_G['siteurl'].'source/plugin/'.CURMODULE.'/maganotify.php?o='.$out_trade_no.'&t='.$_G['timestamp'].'&sign='.$sign;
        $callback = urlencode($callback);

        $url = $this->maga_url.'/core/pay/pay/unifiedOrder?trade_no='.$out_trade_no.'&callback='.$callback.'&amount='.$money.'&title='.$title.'&user_id='.$uid.'&des='.$des.'&remark='.$remark.'&secret='.$this->maga_appsecret;

        $appdata = dfsockopen($url);
        if (!$appdata) {
            $appdata = file_get_contents($url);
        }

        $result =  json_decode($appdata, true);
        return $result;
    }

    //&#x9a8c;&#x8bc1;&#x8ba2;&#x5355;
    public function getMagaOrderVerify($param = array()){

        $sign = $param['sign'];
        $out_trade_no = $param['out_trade_no'];

        $verifySign = md5($out_trade_no.CURMODULE.$this->maga_appsecret.CURMODULE);

        if($sign != $verifySign){
            return false;
        }

        return true;
    }

    //&#x8bbe;&#x7f6e;&#x9a6c;&#x7532;&#x91d1;&#x5e01;&#x6570;
    public function setMagaGold($user_id, $gold = 0, $remark = ''){

        $url = $this->maga_url.'/mag/user/v1/GradeScore/addUserGold?user_id='.$user_id.'&gold='.$gold.'&secret='.$this->maga_appsecret.'&remark='.urlencode($remark);

        $appdata = dfsockopen($url);
        if (!$appdata) {
            $appdata = file_get_contents($url);
        }

        $result =  json_decode($appdata, true);
        return $result;
    }

    //&#x9a6c;&#x7532;&#x6a21;&#x7248;&#x6d88;&#x606f;
    public function sendMagaTemplate($user_id, $content = array(), $type = 'text'){

        $tuisong_url = $this->maga_url.'/mag/operative/v1/assistant/sendAssistantMsg?user_id='.$user_id.'&type='.$type.'&content='.urlencode(junhua_json_encode($content)).'&secret='.$this->maga_appsecret.'&assistant_secret='.$this->maga_zs_appsecret.'&is_push=1';

        $appdata = dfsockopen($tuisong_url);
        if (!$appdata) {
            $appdata = file_get_contents($tuisong_url);
        }

        $result =  json_decode($appdata, true);
        return $result;
    }


    //&#x5343;&#x5e06;&#x6a21;&#x7248;&#x6d88;&#x606f;
    public function sendQfTemplate($data = array()){
        $data['from'] = $this->qf_fwhuid;

        if (strtolower(CHARSET) == 'gbk') {
            $data = junhua_array_map('junhua_gbk2utf8', $data);
        }

        $appdata = $this->QfRequest('POST', 'message/template', $data);
        return $appdata;
    }

    private function QfRequest($method, $path, $requestBody){
        $header = array(
            "Authorization: Bearer {$this->qf_token}",
            "Content-Type: application/x-www-form-urlencoded",
            "Cache-Control: no-cache",
            "Accept: application/json",
            "User-Agent: QianFanHttpClient/1.0.0"
        );


        $url = "https://{$this->qf_hostname}.qianfanapi.com/openapi/{$path}";

        $curlHandle = curl_init();
        curl_setopt($curlHandle, CURLOPT_URL, $url);
        curl_setopt($curlHandle, CURLOPT_HEADER, 0);
        curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curlHandle, CURLOPT_HTTPHEADER, $header);
        curl_setopt($curlHandle, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curlHandle, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curlHandle, CURLOPT_CUSTOMREQUEST, $method);
        if (count($requestBody)) {
            curl_setopt($curlHandle, CURLOPT_POST, 1);
            curl_setopt($curlHandle, CURLOPT_POSTFIELDS, http_build_query($requestBody));
        }
        curl_setopt($curlHandle, CURLOPT_CONNECTTIMEOUT, 2); // &#x8fde;&#x63a5;&#x8d85;&#x65f6;
        curl_setopt($curlHandle, CURLOPT_TIMEOUT, 2); // &#x54cd;&#x5e94;&#x8d85;&#x65f6;

        $response = curl_exec($curlHandle);
        curl_close($curlHandle);

        $data = json_decode($response, true);
        return $data;
    }
}
