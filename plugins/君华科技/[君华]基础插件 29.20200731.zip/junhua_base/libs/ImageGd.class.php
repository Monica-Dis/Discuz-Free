<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class junhua_ImageGd{
    /**
     * &#x56fe;&#x50cf;&#x8d44;&#x6e90;&#x5bf9;&#x8c61;
     * @var resource
     */
    private $img;

    /**
     * &#x56fe;&#x50cf;&#x4fe1;&#x606f;&#xff0c;&#x5305;&#x62ec;width,height,type,mime,size
     * @var array
     */
    public $info;

    /**
     * &#x6784;&#x9020;&#x65b9;&#x6cd5;&#xff0c;&#x53ef;&#x7528;&#x4e8e;&#x6253;&#x5f00;&#x4e00;&#x5f20;&#x56fe;&#x50cf;
     * @param string $imgname &#x56fe;&#x50cf;&#x8def;&#x5f84;
     */
    public function __construct($imgname = null) {
        $imgname && $this->open($imgname);
    }

    /**
     * &#x6253;&#x5f00;&#x4e00;&#x5f20;&#x56fe;&#x50cf;
     * @param  string $imgname &#x56fe;&#x50cf;&#x8def;&#x5f84;
     */
    public function open($imgname){
        //&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x6587;&#x4ef6;
        if(!is_file($imgname)) throw new Exception('&#x4e0d;&#x5b58;&#x5728;&#x7684;&#x56fe;&#x50cf;&#x6587;&#x4ef6;');

        //&#x83b7;&#x53d6;&#x56fe;&#x50cf;&#x4fe1;&#x606f;
        $info = getimagesize($imgname);

        //&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x5408;&#x6cd5;&#x6027;
        if(false === $info || (IMAGETYPE_GIF === $info[2] && empty($info['bits']))){
            throw new Exception('&#x975e;&#x6cd5;&#x56fe;&#x50cf;&#x6587;&#x4ef6;');
        }

        //&#x8bbe;&#x7f6e;&#x56fe;&#x50cf;&#x4fe1;&#x606f;
        $this->info = array(
            'width'  => $info[0],
            'height' => $info[1],
            'type'   => image_type_to_extension($info[2], false),
            'mime'   => $info['mime'],
        );

        //&#x9500;&#x6bc1;&#x5df2;&#x5b58;&#x5728;&#x7684;&#x56fe;&#x50cf;
        empty($this->img) || imagedestroy($this->img);

        //&#x6253;&#x5f00;&#x56fe;&#x50cf;
        if('gif' == $this->info['type']){
            return false;
        } else {
            $fun = "imagecreatefrom{$this->info['type']}";
            $this->img = $fun($imgname);
        }
    }

    /**
     * &#x4fdd;&#x5b58;&#x56fe;&#x50cf;
     * @param  string  $imgname   &#x56fe;&#x50cf;&#x4fdd;&#x5b58;&#x540d;&#x79f0;
     * @param  string  $type      &#x56fe;&#x50cf;&#x7c7b;&#x578b;
     * @param  boolean $interlace &#x662f;&#x5426;&#x5bf9;JPEG&#x7c7b;&#x578b;&#x56fe;&#x50cf;&#x8bbe;&#x7f6e;&#x9694;&#x884c;&#x626b;&#x63cf;
     */
    public function save($imgname, $type = null, $interlace = true){
        if(empty($this->img)) throw new Exception('&#x6ca1;&#x6709;&#x53ef;&#x4ee5;&#x88ab;&#x4fdd;&#x5b58;&#x7684;&#x56fe;&#x50cf;&#x8d44;&#x6e90;');

        //&#x81ea;&#x52a8;&#x83b7;&#x53d6;&#x56fe;&#x50cf;&#x7c7b;&#x578b;
        if(is_null($type)){
            $type = $this->info['type'];
        } else {
            $type = strtolower($type);
        }

        //JPEG&#x56fe;&#x50cf;&#x8bbe;&#x7f6e;&#x9694;&#x884c;&#x626b;&#x63cf;
        if('jpeg' == $type || 'jpg' == $type){
            $type = 'jpeg';
            imageinterlace($this->img, $interlace);
        }

        //&#x4fdd;&#x5b58;&#x56fe;&#x50cf;
        if('gif' == $type){
            return false;
        } else {
            $fun = "image{$type}";
            $fun($this->img, $imgname);
        }
    }

    /**
     * &#x8fd4;&#x56de;&#x56fe;&#x50cf;&#x5bbd;&#x5ea6;
     * @return integer &#x56fe;&#x50cf;&#x5bbd;&#x5ea6;
     */
    public function width(){
        if(empty($this->img)) throw new Exception('&#x6ca1;&#x6709;&#x6307;&#x5b9a;&#x56fe;&#x50cf;&#x8d44;&#x6e90;');
        return $this->info['width'];
    }

    /**
     * &#x8fd4;&#x56de;&#x56fe;&#x50cf;&#x9ad8;&#x5ea6;
     * @return integer &#x56fe;&#x50cf;&#x9ad8;&#x5ea6;
     */
    public function height(){
        if(empty($this->img)) throw new Exception('&#x6ca1;&#x6709;&#x6307;&#x5b9a;&#x56fe;&#x50cf;&#x8d44;&#x6e90;');
        return $this->info['height'];
    }

    /**
     * &#x8fd4;&#x56de;&#x56fe;&#x50cf;&#x7c7b;&#x578b;
     * @return string &#x56fe;&#x50cf;&#x7c7b;&#x578b;
     */
    public function type(){
        if(empty($this->img)) throw new Exception('&#x6ca1;&#x6709;&#x6307;&#x5b9a;&#x56fe;&#x50cf;&#x8d44;&#x6e90;');
        return $this->info['type'];
    }

    /**
     * &#x8fd4;&#x56de;&#x56fe;&#x50cf;MIME&#x7c7b;&#x578b;
     * @return string &#x56fe;&#x50cf;MIME&#x7c7b;&#x578b;
     */
    public function mime(){
        if(empty($this->img)) throw new Exception('&#x6ca1;&#x6709;&#x6307;&#x5b9a;&#x56fe;&#x50cf;&#x8d44;&#x6e90;');
        return $this->info['mime'];
    }

    /**
     * &#x8fd4;&#x56de;&#x56fe;&#x50cf;&#x5c3a;&#x5bf8;&#x6570;&#x7ec4; 0 - &#x56fe;&#x50cf;&#x5bbd;&#x5ea6;&#xff0c;1 - &#x56fe;&#x50cf;&#x9ad8;&#x5ea6;
     * @return array &#x56fe;&#x50cf;&#x5c3a;&#x5bf8;
     */
    public function size(){
        if(empty($this->img)) throw new Exception('&#x6ca1;&#x6709;&#x6307;&#x5b9a;&#x56fe;&#x50cf;&#x8d44;&#x6e90;');
        return array($this->info['width'], $this->info['height']);
    }

    /**
     * &#x6dfb;&#x52a0;&#x6c34;&#x5370;
     * @param  string  $source &#x6c34;&#x5370;&#x56fe;&#x7247;&#x8def;&#x5f84;
     * @param  integer $locate &#x6c34;&#x5370;&#x4f4d;&#x7f6e;
     * @param  integer $alpha  &#x6c34;&#x5370;&#x900f;&#x660e;&#x5ea6;
     */
    public function water($source, $locate = 9){
        //&#x8d44;&#x6e90;&#x68c0;&#x6d4b;
        if(empty($this->img)) throw new Exception('&#x6ca1;&#x6709;&#x53ef;&#x4ee5;&#x88ab;&#x6dfb;&#x52a0;&#x6c34;&#x5370;&#x7684;&#x56fe;&#x50cf;&#x8d44;&#x6e90;');
        if(!is_file($source)) throw new Exception('&#x6c34;&#x5370;&#x56fe;&#x50cf;&#x4e0d;&#x5b58;&#x5728;');

        //&#x83b7;&#x53d6;&#x6c34;&#x5370;&#x56fe;&#x50cf;&#x4fe1;&#x606f;
        $info = getimagesize($source);
        if(false === $info || (IMAGETYPE_GIF === $info[2] && empty($info['bits']))){
            throw new Exception('&#x975e;&#x6cd5;&#x6c34;&#x5370;&#x6587;&#x4ef6;');
        }

        //&#x521b;&#x5efa;&#x6c34;&#x5370;&#x56fe;&#x50cf;&#x8d44;&#x6e90;
        $fun   = 'imagecreatefrom' . image_type_to_extension($info[2], false);
        $water = $fun($source);

        //&#x8bbe;&#x5b9a;&#x6c34;&#x5370;&#x56fe;&#x50cf;&#x7684;&#x6df7;&#x8272;&#x6a21;&#x5f0f;
        imagealphablending($water, true);

        /* &#x8bbe;&#x5b9a;&#x6c34;&#x5370;&#x4f4d;&#x7f6e; */
        // 123
        // 456
        // 789
        switch ($locate) {
            case 1:
                $x = $y = 0;
                break;
            case 2:
                $x = ($this->info['width'] - $info[0])/2;
                $y = 0;
                break;
            case 3:
                $x = $this->info['width'] - $info[0];
                $y = 0;
                break;
            case 4:
                $x = 0;
                $y = ($this->info['height'] - $info[1])/2;
                break;
            case 5:
                $x = ($this->info['width'] - $info[0])/2;
                $y = ($this->info['height'] - $info[1])/2;
                break;
            case 6:
                $x = $this->info['width'] - $info[0];
                $y = ($this->info['height'] - $info[1])/2;
                break;
            case 7:
                $x = 0;
                $y = $this->info['height'] - $info[1];
                break;
            case 8:
                $x = ($this->info['width'] - $info[0])/2;
                $y = $this->info['height'] - $info[1];
                break;
            case 9:
                $x = $this->info['width'] - $info[0];
                $y = $this->info['height'] - $info[1];
                break;
            default:
                /* &#x81ea;&#x5b9a;&#x4e49;&#x6c34;&#x5370;&#x5750;&#x6807; */
                if(is_array($locate)){
                    list($x, $y) = $locate;
                } else {
                    throw new Exception('&#x4e0d;&#x652f;&#x6301;&#x7684;&#x6c34;&#x5370;&#x4f4d;&#x7f6e;&#x7c7b;&#x578b;');
                }
        }

        //&#x6dfb;&#x52a0;&#x6c34;&#x5370;
        $src = imagecreatetruecolor($info[0], $info[1]);
        // &#x8c03;&#x6574;&#x9ed8;&#x8ba4;&#x989c;&#x8272;
        $color = imagecolorallocate($src, 255, 255, 255);
        imagefill($src, 0, 0, $color);

        imagecopy($src, $this->img, 0, 0, $x, $y, $info[0], $info[1]);
        imagecopy($src, $water, 0, 0, 0, 0, $info[0], $info[1]);
        imagecopymerge($this->img, $src, $x, $y, 0, 0, $info[0], $info[1], 100);

        //&#x9500;&#x6bc1;&#x96f6;&#x65f6;&#x56fe;&#x7247;&#x8d44;&#x6e90;
        imagedestroy($src);

        //&#x9500;&#x6bc1;&#x6c34;&#x5370;&#x8d44;&#x6e90;
        imagedestroy($water);
    }

    /**
     * &#x6790;&#x6784;&#x65b9;&#x6cd5;&#xff0c;&#x7528;&#x4e8e;&#x9500;&#x6bc1;&#x56fe;&#x50cf;&#x8d44;&#x6e90;
     */
    public function __destruct() {
        empty($this->img) || imagedestroy($this->img);
    }
}