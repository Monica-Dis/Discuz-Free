<?php

include_once('source/plugin/junhua_base/libs/XML.class.php');

class WEIXIN_PAY{

    private $appId;
    private $appSecret;
    private $MchId;
    private $AppKey;
    private $unifiedorderUrl = 'https://api.mch.weixin.qq.com/pay/unifiedorder';
    private $transfersUrl = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers'; //&#x4f01;&#x4e1a;&#x53d1;&#x9001;&#x4e2a;&#x4eba;&#x7ea2;&#x5305;

    private $token = '';
    protected $required = array('body', 'out_trade_no', 'total_fee', 'notify_url');
    protected $optional = array(
        'device_info', 'detail', 'attach', 'fee_type', 'time_start', 'time_expire',
        'goods_tag', 'product_id', 'limit_pay', 'nonce_str', 'spbill_create_ip',
        'trade_type', 'openid',
        'partner_trade_no', 'check_name', 'amount', 'desc',
    );
    protected $params = null;
    protected $attributes = array();
    public $sslcert_path = null;
    public $sslkey_path = null;
    /**
     * &#x65b9;&#x6cd5;&#x540d;&#x8f6c;&#x6362;&#x7f13;&#x5b58;.
     *
     * @var array
     */
    protected $snakeCache = array();

    public function __construct($appId, $appSecret, $mch_id, $app_key){
        $this->appId     = $appId;
        $this->appSecret = $appSecret;
        $this->MchId     = $mch_id;
        $this->AppKey    = $app_key;

        if ($this->params === null) {
            $this->params = array_merge($this->required, $this->optional);
        }

    }

    public function setSslCert($certPath = ''){
        $this->sslcert_path = $certPath;
    }

    public function setSslKey($keyPath = ''){
        $this->sslkey_path = $keyPath;
    }

    /**
     * &#x68c0;&#x6d4b;&#x53c2;&#x6570;&#x503c;&#x662f;&#x5426;&#x6709;&#x6548;.
     * 
     * @throws Exception
     */
    public function checkParams()
    {
        foreach ($this->required as $paramName) {
            if (empty($this->attributes[$paramName])) {
                throw new Exception(sprintf('"%s" is required', $paramName));
            }
        }
    }

    /**
     * &#x8bbe;&#x7f6e;&#x5c5e;&#x6027;.
     *
     * @param string $attribute
     * @param mixed  $value
     *
     * @return MagicAttributes
     */
    public function with($attribute, $value)
    {
        $attribute = $this->snake($attribute);

        $this->attributes[$attribute] = $value;

        return $this;
    }

    /**
     * &#x8f6c;&#x6362;&#x4e3a;&#x4e0b;&#x5212;&#x7ebf;&#x6a21;&#x5f0f;&#x5b57;&#x7b26;&#x4e32;.
     *
     * @param string $value
     * @param string $delimiter
     *
     * @return string
     */
    protected function snake($value, $delimiter = '_')
    {
        $key = $value.$delimiter;

        if (isset($this->snakeCache[$key])) {
            return $this->snakeCache[$key];
        }

        if (!ctype_lower($value)) {
            $value = strtolower(preg_replace('/(.)(?=[A-Z])/', '$1'.$delimiter, $value));
        }

        return $this->snakeCache[$key] = $value;
    }


    public function __set($property, $value)
    {
        if (!in_array($property, $this->params)) {
            throw new Exception(sprintf('"%s" is required', $property));
        }

        return $this->with($property, $value);
    }


    /**
     * &#x8bbe;&#x7f6e;&#x8ba2;&#x5355;.
     *
     * @param Order $order
     *
     * @return $this
     *
     * @throws Exception
     */
    public function setOrder()
    {
        if (!$this->nonce_str) {
            $this->nonce_str = md5(uniqid(microtime()));
        }

        if (!$this->spbill_create_ip) {
            $this->spbill_create_ip = empty($_SERVER['REMOTE_ADDR']) ? '0.0.0.0' : $_SERVER['REMOTE_ADDR'];
        }

        if (!$this->trade_type) {
            if (!$this->attributes['openid']) {
                throw new Exception('openid is required');
            }
            $this->trade_type = 'JSAPI';
        }

        return $this;
    }


    /**
     * &#x83b7;&#x53d6;&#x914d;&#x7f6e;&#x6587;&#x4ef6;&#xff08;&#x7528;&#x4e8e; WeixinJSBridge invoke &#x65b9;&#x5f0f;&#xff09;.
     * 
     * @return array|string
     */
    public function getConfig()
    {
        $config = $this->generateConfig();

        return $config;
    }

    /**
     * &#x83b7;&#x53d6;&#x914d;&#x7f6e;&#x6587;&#x4ef6;&#xff08;&#x7528;&#x4e8e; Jssdk chooseWXPay &#x65b9;&#x5f0f;&#xff09;.
     * 
     * @param bool|true $asJson
     *
     * @return array|string
     */
    public function getConfigJssdk()
    {
        $config = $this->generateConfig();
        $params = array(
            'timestamp' => $config['timeStamp'],
            'nonceStr' => $config['nonceStr'],
            'package' => $config['package'],
            'signType' => $config['signType'],
            'paySign' => $config['paySign'],
        );

        return $params;
    }

    /**
     * &#x751f;&#x6210;&#x914d;&#x7f6e;.
     * 
     * @return array
     *
     * @throws Payment\Exception
     */
    private function generateConfig()
    {
        $this->setOrder();
        $params = $this->attributes;

        $params['appid'] = $this->appId;
        $params['mch_id'] = $this->MchId;
        $params['sign'] = $this->getSignResult($params);;

        $xmlData = XML::build($params);

        $response = $this->postXmlCurl($xmlData, $this->unifiedorderUrl);
        $response = XML::parse($response);

        $config = array(
            'appId' => $this->appId,
            'timeStamp' => (string) time(),
            'nonceStr' => $response['nonce_str'],
            'package' => 'prepay_id='.$response['prepay_id'],
            'signType' => 'MD5',
        );

        $config['paySign'] = $this->getSignResult($config);

        return $config;
    }

    private function getSignResult($param){
        ksort($param);
        $query = http_build_query($param);
        $query = urldecode($query);
        return strtoupper(md5($query.'&key='.$this->AppKey));
    }

    //&#x53d1;&#x9001;&#x73b0;&#x91d1;&#x5230;&#x4f59;&#x989d;
    public function toTransfers(){

        if (!$this->nonce_str) {
            $this->nonce_str = md5(uniqid(microtime()));
        }


        $params = $this->attributes;

        $params['mch_appid'] = $this->appId;
        $params['mchid'] = $this->MchId;
        $params['sign'] = $this->getSignResult($params);;

        $xmlData = XML::build($params);

        $response = $this->postXmlCurl($xmlData, $this->transfersUrl, true);
        $result = XML::parse($response);

        return $result;
    }



    /**
     * &#x9a8c;&#x8bc1;&#x8ba2;&#x5355;&#x6d88;&#x606f;&#x662f;&#x5426;&#x5408;&#x6cd5;,
     * &#x4e0d;&#x5408;&#x6cd5;&#x8fd4;&#x56de;false, &#x5408;&#x6cd5;&#x8fd4;&#x56de;&#x8ba2;&#x5355;&#x4fe1;&#x606f;&#x8be6;&#x60c5;.
     */
    public function verify()
    {
        $xmlInput = isset($GLOBALS['HTTP_RAW_POST_DATA']) ? $GLOBALS['HTTP_RAW_POST_DATA'] : file_get_contents("php://input");

        if (empty($xmlInput)) {
            return false;
        }

        $input = XML::parse($xmlInput);
        if (empty($input) || empty($input['sign'])) {
            return false;
        }

        $sign = $input['sign'];
        unset($input['sign']);
        
        $verifySign = $this->getSignResult($input);
        
        if ($sign !== $verifySign) {
            return false;
        }

        return $input;
    }

    /**
     * &#x56de;&#x590d;&#x6d88;&#x606f;, &#x5982;&#x679c;&#x4e0d;&#x56de;&#x590d;, &#x5fae;&#x4fe1;&#x4f1a;&#x4e00;&#x76f4;&#x53d1;&#x9001;&#x8bf7;&#x6c42;&#x5230;notify_url.
     * 
     * @param string $code
     * @param string $msg
     *
     * @return string
     */
    public function reply($code = 'SUCCESS', $msg = 'OK')
    {
        $params = array(
            'return_code' => $code,
            'return_msg' => $msg,
        );

        return XML::build($params);
    }

    private function postXmlCurl($xmlData, $url, $useCert = false, $second = 30)
    {       
        $ch = curl_init();

        //&#x8bbe;&#x7f6e;&#x8d85;&#x65f6;
        curl_setopt($ch, CURLOPT_TIMEOUT, $second);

        curl_setopt($ch,CURLOPT_URL, $url);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
        curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);//&#x4e25;&#x683c;&#x6821;&#x9a8c;
        //&#x8bbe;&#x7f6e;header
        curl_setopt($ch, CURLOPT_HEADER, FALSE);
        //&#x8981;&#x6c42;&#x7ed3;&#x679c;&#x4e3a;&#x5b57;&#x7b26;&#x4e32;&#x4e14;&#x8f93;&#x51fa;&#x5230;&#x5c4f;&#x5e55;&#x4e0a;
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    
        if($useCert == true){
            //&#x8bbe;&#x7f6e;&#x8bc1;&#x4e66;
            //&#x4f7f;&#x7528;&#x8bc1;&#x4e66;&#xff1a;cert &#x4e0e; key &#x5206;&#x522b;&#x5c5e;&#x4e8e;&#x4e24;&#x4e2a;.pem&#x6587;&#x4ef6;
            curl_setopt($ch,CURLOPT_SSLCERTTYPE,'PEM');
            curl_setopt($ch,CURLOPT_SSLCERT, $this->sslcert_path);
            curl_setopt($ch,CURLOPT_SSLKEYTYPE,'PEM');
            curl_setopt($ch,CURLOPT_SSLKEY,$this->sslkey_path);
        }
        //post&#x63d0;&#x4ea4;&#x65b9;&#x5f0f;
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xmlData);
        //&#x8fd0;&#x884c;curl
        $data = curl_exec($ch);
        //&#x8fd4;&#x56de;&#x7ed3;&#x679c;
        if($data){
            curl_close($ch);
            return $data;
        } else { 
            $error = curl_errno($ch);
            curl_close($ch);
            throw new WxPayException("curl error:$error");
        }
    }
}