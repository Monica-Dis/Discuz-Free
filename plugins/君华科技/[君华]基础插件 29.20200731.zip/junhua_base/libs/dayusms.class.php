<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class junhua_dayusms
{
    private $PhoneNumbers;
    private $SignName;
    private $TemplateCode;
    private $AccessKeyId;
    private $AccessKeySecret;
    private $Action = 'SendSms';
    private $RegionId;
    private $OutId;
    private $SmsUpExtendCode;
    private $TemplateParam;
	private $Version			= '2017-05-25';
	private $Format				= 'JSON';
	private $SignatureMethod	= 'HMAC-SHA1';
	private $Host				= 'https://dysmsapi.aliyuncs.com';
	private $SignatureVersion	= '1.0';

    private $apiParas = array();

	public function __construct($AccessKeyId = "", $AccessKeySecret = ""){
		$this->AccessKeyId = $AccessKeyId;
		$this->AccessKeySecret = $AccessKeySecret;
	}

    public function setAccessKeyId($AccessKeyId)
    {
        $this->AccessKeyId             = $AccessKeyId;
        $this->apiParas["AccessKeyId"] = $AccessKeyId;
    }

    public function getAccessKeyId()
    {
        return $this->AccessKeyId;
    }
    public function setFormat($Format)
    {
        $this->Format             = $Format;
        $this->apiParas["Format"] = $Format;
    }

    public function getFormat()
    {
        return $this->Format;
    }

    public function setRegionId($RegionId)
    {
        $this->RegionId             = $RegionId;
        $this->apiParas["RegionId"] = $RegionId;
    }
    public function getRegionId()
    {
        return $this->RegionId;
    }

    public function setPhoneNumbers($PhoneNumbers)
    {
        $this->PhoneNumbers             = $PhoneNumbers;
        $this->apiParas["PhoneNumbers"] = $PhoneNumbers;
    }

    public function setSignName($SignName)
    {
        $this->SignName             = $SignName;
        $this->apiParas["SignName"] = $SignName;
    }

    public function setTemplateCode($TemplateCode)
    {
        $this->TemplateCode             = $TemplateCode;
        $this->apiParas["TemplateCode"] = $TemplateCode;
    }

    public function setAction($Action)
    {
        $this->Action             = $Action;
        $this->apiParas["Action"] = $Action;
    }
    public function getAction()
    {
        return $this->Action;
    }

    public function setOutId($OutId)
    {
        $this->OutId             = $OutId;
        $this->apiParas["OutId"] = $OutId;
    }

    public function setSmsUpExtendCode($SmsUpExtendCode)
    {
        $this->SmsUpExtendCode             = $SmsUpExtendCode;
        $this->apiParas["SmsUpExtendCode"] = $SmsUpExtendCode;
    }

    public function setTemplateParam($TemplateParam)
    {
        $this->TemplateParam             = $TemplateParam;
        $this->apiParas["TemplateParam"] = $TemplateParam;
    }

    public function getApiParas()
    {
        return $this->apiParas;
    }

    private function Encode($string)
    {
        $string = urlencode($string);
        $string = preg_replace('/\+/', '%20', $string);
        $string = preg_replace('/\*/', '%2A', $string);
        $string = preg_replace('/%7E/', '~', $string);
        return $string;

    }

    private function computeSignature($param, $accessKeySecret)
    {
        ksort($param);
        $canonicalizedQueryString = '';
        foreach ($param as $key => $value) {
            $canonicalizedQueryString .= '&' . $this->Encode($key) . '=' . $this->Encode($value);
        }
        $stringToSign = 'GET&%2F&' . $this->encode(substr($canonicalizedQueryString, 1));
        $signature = base64_encode(hash_hmac('sha1', $stringToSign, $accessKeySecret . '&', true));
        return $signature;
    }

    public function exec($host = '')
    {

		$this->apiParas['AccessKeyId'] = $this->getAccessKeyId();
		$this->apiParas['Action'] = $this->getAction();
		$this->apiParas['SignatureMethod'] = $this->SignatureMethod;
		$this->apiParas['SignatureNonce'] = uniqid();
		$this->apiParas['Timestamp'] = gmdate('Y-m-d\TH:i:s\Z');
		$this->apiParas['Format'] = $this->getFormat();
		$this->apiParas['SignatureVersion'] = $this->SignatureVersion;
		$this->apiParas['Version'] = $this->Version;
		$this->apiParas['Signature'] = $this->computeSignature($this->apiParas, $this->AccessKeySecret);


        $url = ($host ? $host : $this->Host) . '/?' . http_build_query ($this->apiParas);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $result = curl_exec($ch);
        curl_close($ch);
        
        $result = json_decode($result, true);
        return $result;
    }
}
