<?php
/*
* Copyright (c) 2017 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License. You may obtain a copy of
* the License at
*
* Http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/

require_once 'lib/AipBase.php';
class AipBodyAnalysis extends AipBase {

    /**
     * &#x4eba;&#x4f53;&#x5173;&#x952e;&#x70b9;&#x8bc6;&#x522b; body_analysis api url
     * @var string
     */
    private $bodyAnalysisUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/body_analysis';

    /**
     * &#x4eba;&#x4f53;&#x5c5e;&#x6027;&#x8bc6;&#x522b; body_attr api url
     * @var string
     */
    private $bodyAttrUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/body_attr';

    /**
     * &#x4eba;&#x6d41;&#x91cf;&#x7edf;&#x8ba1; body_num api url
     * @var string
     */
    private $bodyNumUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/body_num';

    /**
     * &#x624b;&#x52bf;&#x8bc6;&#x522b; gesture api url
     * @var string
     */
    private $gestureUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/gesture';

    /**
     * &#x4eba;&#x50cf;&#x5206;&#x5272; body_seg api url
     * @var string
     */
    private $bodySegUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/body_seg';

    

    /**
     * &#x4eba;&#x4f53;&#x5173;&#x952e;&#x70b9;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function bodyAnalysis($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->bodyAnalysisUrl, $data);
    }

    /**
     * &#x4eba;&#x4f53;&#x5c5e;&#x6027;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   type gender,<br>age,<br>lower_wear,<br>upper_wear,<br>headwear,<br>glasses,<br>upper_color,<br>lower_color,<br>cellphone,<br>upper_wear_fg,<br>upper_wear_texture,<br>lower_wear_texture,<br>orientation,<br>umbrella,<br>bag,<br>smoke,<br>vehicle,<br>carrying_item,<br>upper_cut,<br>lower_cut,<br>occlusion &#124; 1&#xff09;&#x53ef;&#x9009;&#x503c;&#x8bf4;&#x660e;&#xff1a;<br>gender-&#x6027;&#x522b;&#xff0c;<br>age-&#x5e74;&#x9f84;&#x9636;&#x6bb5;&#xff0c;<br>lower_wear-&#x4e0b;&#x8eab;&#x670d;&#x9970;&#xff0c;<br>upper_wear-&#x4e0a;&#x8eab;&#x670d;&#x9970;&#xff0c;<br>headwear-&#x662f;&#x5426;&#x6234;&#x5e3d;&#x5b50;&#xff0c;<br>glasses-&#x662f;&#x5426;&#x6234;&#x773c;&#x955c;&#xff0c;<br>upper_color-&#x4e0a;&#x8eab;&#x670d;&#x9970;&#x989c;&#x8272;&#xff0c;<br>lower_color-&#x4e0b;&#x8eab;&#x670d;&#x9970;&#x989c;&#x8272;&#xff0c;<br>cellphone-&#x662f;&#x5426;&#x4f7f;&#x7528;&#x624b;&#x673a;&#xff0c;<br>upper_wear_fg-&#x4e0a;&#x8eab;&#x670d;&#x9970;&#x7ec6;&#x5206;&#x7c7b;&#xff0c;<br>upper_wear_texture-&#x4e0a;&#x8eab;&#x670d;&#x9970;&#x7eb9;&#x7406;&#xff0c;<br>orientation-&#x8eab;&#x4f53;&#x671d;&#x5411;&#xff0c;<br>umbrella-&#x662f;&#x5426;&#x6491;&#x4f1e;&#xff1b;<br>bag-&#x80cc;&#x5305;,<br>smoke-&#x662f;&#x5426;&#x5438;&#x70df;,<br>vehicle-&#x4ea4;&#x901a;&#x5de5;&#x5177;,<br>carrying_item-&#x662f;&#x5426;&#x6709;&#x624b;&#x63d0;&#x7269;,<br>upper_cut-&#x4e0a;&#x65b9;&#x622a;&#x65ad;,<br>lower_cut-&#x4e0b;&#x65b9;&#x622a;&#x65ad;,<br>occlusion-&#x906e;&#x6321;<br>2&#xff09;type &#x53c2;&#x6570;&#x503c;&#x53ef;&#x4ee5;&#x662f;&#x53ef;&#x9009;&#x503c;&#x7684;&#x7ec4;&#x5408;&#xff0c;&#x7528;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff1b;**&#x5982;&#x679c;&#x65e0;&#x6b64;&#x53c2;&#x6570;&#x9ed8;&#x8ba4;&#x8f93;&#x51fa;&#x5168;&#x90e8;20&#x4e2a;&#x5c5e;&#x6027;**
     * @return array
     */
    public function bodyAttr($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->bodyAttrUrl, $data);
    }

    /**
     * &#x4eba;&#x6d41;&#x91cf;&#x7edf;&#x8ba1;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   area &#x7279;&#x5b9a;&#x6846;&#x9009;&#x533a;&#x57df;&#x5750;&#x6807;&#xff0c;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x5982;&#x2018;x1,y1,x2,y2,x3,y3...xn,yn'&#xff0c;&#x9ed8;&#x8ba4;&#x5c3e;&#x70b9;&#x548c;&#x9996;&#x70b9;&#x76f8;&#x8fde;&#x505a;&#x95ed;&#x5408;&#xff0c;**&#x6b64;&#x53c2;&#x6570;&#x4e3a;&#x7a7a;&#x6216;&#x65e0;&#x6b64;&#x53c2;&#x6570;&#x9ed8;&#x8ba4;&#x8bc6;&#x522b;&#x6574;&#x4e2a;&#x56fe;&#x7247;&#x7684;&#x4eba;&#x6570;**
     *   show &#x662f;&#x5426;&#x8f93;&#x51fa;&#x6e32;&#x67d3;&#x7684;&#x56fe;&#x7247;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x8fd4;&#x56de;&#xff0c;**&#x9009;true&#x65f6;&#x8fd4;&#x56de;&#x6e32;&#x67d3;&#x540e;&#x7684;&#x56fe;&#x7247;(base64)**&#xff0c;&#x5176;&#x5b83;&#x65e0;&#x6548;&#x503c;&#x6216;&#x4e3a;&#x7a7a;&#x5219;&#x9ed8;&#x8ba4;false
     * @return array
     */
    public function bodyNum($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->bodyNumUrl, $data);
    }

    /**
     * &#x624b;&#x52bf;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function gesture($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->gestureUrl, $data);
    }

    /**
     * &#x4eba;&#x50cf;&#x5206;&#x5272;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function bodySeg($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->bodySegUrl, $data);
    }
}