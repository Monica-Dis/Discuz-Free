<?php
/*
* Copyright (c) 2017 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License. You may obtain a copy of
* the License at
*
* Http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/

require_once 'lib/AipBase.php';

class AipOcr extends AipBase {

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b; general_basic api url
     * @var string
     */
    private $generalBasicUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/general_basic';

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#xff08;&#x9ad8;&#x7cbe;&#x5ea6;&#x7248;&#xff09; accurate_basic api url
     * @var string
     */
    private $accurateBasicUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/accurate_basic';

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#xff08;&#x542b;&#x4f4d;&#x7f6e;&#x4fe1;&#x606f;&#x7248;&#xff09; general api url
     * @var string
     */
    private $generalUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/general';

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#xff08;&#x542b;&#x4f4d;&#x7f6e;&#x9ad8;&#x7cbe;&#x5ea6;&#x7248;&#xff09; accurate api url
     * @var string
     */
    private $accurateUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/accurate';

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#xff08;&#x542b;&#x751f;&#x50fb;&#x5b57;&#x7248;&#xff09; general_enhanced api url
     * @var string
     */
    private $generalEnhancedUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/general_enhanced';

    /**
     * &#x7f51;&#x7edc;&#x56fe;&#x7247;&#x6587;&#x5b57;&#x8bc6;&#x522b; web_image api url
     * @var string
     */
    private $webImageUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/webimage';

    /**
     * &#x8eab;&#x4efd;&#x8bc1;&#x8bc6;&#x522b; idcard api url
     * @var string
     */
    private $idcardUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/idcard';

    /**
     * &#x94f6;&#x884c;&#x5361;&#x8bc6;&#x522b; bankcard api url
     * @var string
     */
    private $bankcardUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/bankcard';

    /**
     * &#x9a7e;&#x9a76;&#x8bc1;&#x8bc6;&#x522b; driving_license api url
     * @var string
     */
    private $drivingLicenseUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/driving_license';

    /**
     * &#x884c;&#x9a76;&#x8bc1;&#x8bc6;&#x522b; vehicle_license api url
     * @var string
     */
    private $vehicleLicenseUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/vehicle_license';

    /**
     * &#x8f66;&#x724c;&#x8bc6;&#x522b; license_plate api url
     * @var string
     */
    private $licensePlateUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/license_plate';

    /**
     * &#x8425;&#x4e1a;&#x6267;&#x7167;&#x8bc6;&#x522b; business_license api url
     * @var string
     */
    private $businessLicenseUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/business_license';

    /**
     * &#x901a;&#x7528;&#x7968;&#x636e;&#x8bc6;&#x522b; receipt api url
     * @var string
     */
    private $receiptUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/receipt';

    /**
     * &#x706b;&#x8f66;&#x7968;&#x8bc6;&#x522b; train_ticket api url
     * @var string
     */
    private $trainTicketUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/train_ticket';

    /**
     * &#x51fa;&#x79df;&#x8f66;&#x7968;&#x8bc6;&#x522b; taxi_receipt api url
     * @var string
     */
    private $taxiReceiptUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/taxi_receipt';

    /**
     * &#x8868;&#x683c;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#x540c;&#x6b65;&#x63a5;&#x53e3; form api url
     * @var string
     */
    private $formUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/form';

    /**
     * &#x8868;&#x683c;&#x6587;&#x5b57;&#x8bc6;&#x522b; table_recognize api url
     * @var string
     */
    private $tableRecognizeUrl = 'https://aip.baidubce.com/rest/2.0/solution/v1/form_ocr/request';

    /**
     * &#x8868;&#x683c;&#x8bc6;&#x522b;&#x7ed3;&#x679c; table_result_get api url
     * @var string
     */
    private $tableResultGetUrl = 'https://aip.baidubce.com/rest/2.0/solution/v1/form_ocr/get_request_result';

    /**
     * &#x589e;&#x503c;&#x7a0e;&#x53d1;&#x7968;&#x8bc6;&#x522b; vat_invoice api url
     * @var string
     */
    private $vatInvoiceUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/vat_invoice';

    /**
     * &#x4e8c;&#x7ef4;&#x7801;&#x8bc6;&#x522b; qrcode api url
     * @var string
     */
    private $qrcodeUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/qrcode';

    /**
     * &#x6570;&#x5b57;&#x8bc6;&#x522b; numbers api url
     * @var string
     */
    private $numbersUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/numbers';

    /**
     * &#x5f69;&#x7968;&#x8bc6;&#x522b; lottery api url
     * @var string
     */
    private $lotteryUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/lottery';

    /**
     * &#x62a4;&#x7167;&#x8bc6;&#x522b; passport api url
     * @var string
     */
    private $passportUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/passport';

    /**
     * &#x540d;&#x7247;&#x8bc6;&#x522b; business_card api url
     * @var string
     */
    private $businessCardUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/business_card';

    /**
     * &#x624b;&#x5199;&#x6587;&#x5b57;&#x8bc6;&#x522b; handwriting api url
     * @var string
     */
    private $handwritingUrl = 'https://aip.baidubce.com/rest/2.0/ocr/v1/handwriting';

    /**
     * &#x81ea;&#x5b9a;&#x4e49;&#x6a21;&#x677f;&#x6587;&#x5b57;&#x8bc6;&#x522b; custom api url
     * @var string
     */
    private $customUrl = 'https://aip.baidubce.com/rest/2.0/solution/v1/iocr/recognise';

    

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   language_type &#x8bc6;&#x522b;&#x8bed;&#x8a00;&#x7c7b;&#x578b;&#xff0c;&#x9ed8;&#x8ba4;&#x4e3a;CHN_ENG&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;&#xff1a;<br>- CHN_ENG&#xff1a;&#x4e2d;&#x82f1;&#x6587;&#x6df7;&#x5408;&#xff1b;<br>- ENG&#xff1a;&#x82f1;&#x6587;&#xff1b;<br>- POR&#xff1a;&#x8461;&#x8404;&#x7259;&#x8bed;&#xff1b;<br>- FRE&#xff1a;&#x6cd5;&#x8bed;&#xff1b;<br>- GER&#xff1a;&#x5fb7;&#x8bed;&#xff1b;<br>- ITA&#xff1a;&#x610f;&#x5927;&#x5229;&#x8bed;&#xff1b;<br>- SPA&#xff1a;&#x897f;&#x73ed;&#x7259;&#x8bed;&#xff1b;<br>- RUS&#xff1a;&#x4fc4;&#x8bed;&#xff1b;<br>- JAP&#xff1a;&#x65e5;&#x8bed;&#xff1b;<br>- KOR&#xff1a;&#x97e9;&#x8bed;&#xff1b;
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     *   detect_language &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x8bed;&#x8a00;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#x3002;&#x5f53;&#x524d;&#x652f;&#x6301;&#xff08;&#x4e2d;&#x6587;&#x3001;&#x82f1;&#x8bed;&#x3001;&#x65e5;&#x8bed;&#x3001;&#x97e9;&#x8bed;&#xff09;
     *   probability &#x662f;&#x5426;&#x8fd4;&#x56de;&#x8bc6;&#x522b;&#x7ed3;&#x679c;&#x4e2d;&#x6bcf;&#x4e00;&#x884c;&#x7684;&#x7f6e;&#x4fe1;&#x5ea6;
     * @return array
     */
    public function basicGeneral($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->generalBasicUrl, $data);
    }

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   language_type &#x8bc6;&#x522b;&#x8bed;&#x8a00;&#x7c7b;&#x578b;&#xff0c;&#x9ed8;&#x8ba4;&#x4e3a;CHN_ENG&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;&#xff1a;<br>- CHN_ENG&#xff1a;&#x4e2d;&#x82f1;&#x6587;&#x6df7;&#x5408;&#xff1b;<br>- ENG&#xff1a;&#x82f1;&#x6587;&#xff1b;<br>- POR&#xff1a;&#x8461;&#x8404;&#x7259;&#x8bed;&#xff1b;<br>- FRE&#xff1a;&#x6cd5;&#x8bed;&#xff1b;<br>- GER&#xff1a;&#x5fb7;&#x8bed;&#xff1b;<br>- ITA&#xff1a;&#x610f;&#x5927;&#x5229;&#x8bed;&#xff1b;<br>- SPA&#xff1a;&#x897f;&#x73ed;&#x7259;&#x8bed;&#xff1b;<br>- RUS&#xff1a;&#x4fc4;&#x8bed;&#xff1b;<br>- JAP&#xff1a;&#x65e5;&#x8bed;&#xff1b;<br>- KOR&#xff1a;&#x97e9;&#x8bed;&#xff1b;
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     *   detect_language &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x8bed;&#x8a00;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#x3002;&#x5f53;&#x524d;&#x652f;&#x6301;&#xff08;&#x4e2d;&#x6587;&#x3001;&#x82f1;&#x8bed;&#x3001;&#x65e5;&#x8bed;&#x3001;&#x97e9;&#x8bed;&#xff09;
     *   probability &#x662f;&#x5426;&#x8fd4;&#x56de;&#x8bc6;&#x522b;&#x7ed3;&#x679c;&#x4e2d;&#x6bcf;&#x4e00;&#x884c;&#x7684;&#x7f6e;&#x4fe1;&#x5ea6;
     * @return array
     */
    public function basicGeneralUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->generalBasicUrl, $data);
    }

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#xff08;&#x9ad8;&#x7cbe;&#x5ea6;&#x7248;&#xff09;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     *   probability &#x662f;&#x5426;&#x8fd4;&#x56de;&#x8bc6;&#x522b;&#x7ed3;&#x679c;&#x4e2d;&#x6bcf;&#x4e00;&#x884c;&#x7684;&#x7f6e;&#x4fe1;&#x5ea6;
     * @return array
     */
    public function basicAccurate($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->accurateBasicUrl, $data);
    }

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#xff08;&#x542b;&#x4f4d;&#x7f6e;&#x4fe1;&#x606f;&#x7248;&#xff09;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   recognize_granularity &#x662f;&#x5426;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;big&#xff1a;&#x4e0d;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;&#x9ed8;&#x8ba4;&#x503c;&#xff1b;small&#xff1a;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;
     *   language_type &#x8bc6;&#x522b;&#x8bed;&#x8a00;&#x7c7b;&#x578b;&#xff0c;&#x9ed8;&#x8ba4;&#x4e3a;CHN_ENG&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;&#xff1a;<br>- CHN_ENG&#xff1a;&#x4e2d;&#x82f1;&#x6587;&#x6df7;&#x5408;&#xff1b;<br>- ENG&#xff1a;&#x82f1;&#x6587;&#xff1b;<br>- POR&#xff1a;&#x8461;&#x8404;&#x7259;&#x8bed;&#xff1b;<br>- FRE&#xff1a;&#x6cd5;&#x8bed;&#xff1b;<br>- GER&#xff1a;&#x5fb7;&#x8bed;&#xff1b;<br>- ITA&#xff1a;&#x610f;&#x5927;&#x5229;&#x8bed;&#xff1b;<br>- SPA&#xff1a;&#x897f;&#x73ed;&#x7259;&#x8bed;&#xff1b;<br>- RUS&#xff1a;&#x4fc4;&#x8bed;&#xff1b;<br>- JAP&#xff1a;&#x65e5;&#x8bed;&#xff1b;<br>- KOR&#xff1a;&#x97e9;&#x8bed;&#xff1b;
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     *   detect_language &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x8bed;&#x8a00;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#x3002;&#x5f53;&#x524d;&#x652f;&#x6301;&#xff08;&#x4e2d;&#x6587;&#x3001;&#x82f1;&#x8bed;&#x3001;&#x65e5;&#x8bed;&#x3001;&#x97e9;&#x8bed;&#xff09;
     *   vertexes_location &#x662f;&#x5426;&#x8fd4;&#x56de;&#x6587;&#x5b57;&#x5916;&#x63a5;&#x591a;&#x8fb9;&#x5f62;&#x9876;&#x70b9;&#x4f4d;&#x7f6e;&#xff0c;&#x4e0d;&#x652f;&#x6301;&#x5355;&#x5b57;&#x4f4d;&#x7f6e;&#x3002;&#x9ed8;&#x8ba4;&#x4e3a;false
     *   probability &#x662f;&#x5426;&#x8fd4;&#x56de;&#x8bc6;&#x522b;&#x7ed3;&#x679c;&#x4e2d;&#x6bcf;&#x4e00;&#x884c;&#x7684;&#x7f6e;&#x4fe1;&#x5ea6;
     * @return array
     */
    public function general($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->generalUrl, $data);
    }

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#xff08;&#x542b;&#x4f4d;&#x7f6e;&#x4fe1;&#x606f;&#x7248;&#xff09;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   recognize_granularity &#x662f;&#x5426;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;big&#xff1a;&#x4e0d;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;&#x9ed8;&#x8ba4;&#x503c;&#xff1b;small&#xff1a;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;
     *   language_type &#x8bc6;&#x522b;&#x8bed;&#x8a00;&#x7c7b;&#x578b;&#xff0c;&#x9ed8;&#x8ba4;&#x4e3a;CHN_ENG&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;&#xff1a;<br>- CHN_ENG&#xff1a;&#x4e2d;&#x82f1;&#x6587;&#x6df7;&#x5408;&#xff1b;<br>- ENG&#xff1a;&#x82f1;&#x6587;&#xff1b;<br>- POR&#xff1a;&#x8461;&#x8404;&#x7259;&#x8bed;&#xff1b;<br>- FRE&#xff1a;&#x6cd5;&#x8bed;&#xff1b;<br>- GER&#xff1a;&#x5fb7;&#x8bed;&#xff1b;<br>- ITA&#xff1a;&#x610f;&#x5927;&#x5229;&#x8bed;&#xff1b;<br>- SPA&#xff1a;&#x897f;&#x73ed;&#x7259;&#x8bed;&#xff1b;<br>- RUS&#xff1a;&#x4fc4;&#x8bed;&#xff1b;<br>- JAP&#xff1a;&#x65e5;&#x8bed;&#xff1b;<br>- KOR&#xff1a;&#x97e9;&#x8bed;&#xff1b;
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     *   detect_language &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x8bed;&#x8a00;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#x3002;&#x5f53;&#x524d;&#x652f;&#x6301;&#xff08;&#x4e2d;&#x6587;&#x3001;&#x82f1;&#x8bed;&#x3001;&#x65e5;&#x8bed;&#x3001;&#x97e9;&#x8bed;&#xff09;
     *   vertexes_location &#x662f;&#x5426;&#x8fd4;&#x56de;&#x6587;&#x5b57;&#x5916;&#x63a5;&#x591a;&#x8fb9;&#x5f62;&#x9876;&#x70b9;&#x4f4d;&#x7f6e;&#xff0c;&#x4e0d;&#x652f;&#x6301;&#x5355;&#x5b57;&#x4f4d;&#x7f6e;&#x3002;&#x9ed8;&#x8ba4;&#x4e3a;false
     *   probability &#x662f;&#x5426;&#x8fd4;&#x56de;&#x8bc6;&#x522b;&#x7ed3;&#x679c;&#x4e2d;&#x6bcf;&#x4e00;&#x884c;&#x7684;&#x7f6e;&#x4fe1;&#x5ea6;
     * @return array
     */
    public function generalUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->generalUrl, $data);
    }

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#xff08;&#x542b;&#x4f4d;&#x7f6e;&#x9ad8;&#x7cbe;&#x5ea6;&#x7248;&#xff09;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   recognize_granularity &#x662f;&#x5426;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;big&#xff1a;&#x4e0d;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;&#x9ed8;&#x8ba4;&#x503c;&#xff1b;small&#xff1a;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     *   vertexes_location &#x662f;&#x5426;&#x8fd4;&#x56de;&#x6587;&#x5b57;&#x5916;&#x63a5;&#x591a;&#x8fb9;&#x5f62;&#x9876;&#x70b9;&#x4f4d;&#x7f6e;&#xff0c;&#x4e0d;&#x652f;&#x6301;&#x5355;&#x5b57;&#x4f4d;&#x7f6e;&#x3002;&#x9ed8;&#x8ba4;&#x4e3a;false
     *   probability &#x662f;&#x5426;&#x8fd4;&#x56de;&#x8bc6;&#x522b;&#x7ed3;&#x679c;&#x4e2d;&#x6bcf;&#x4e00;&#x884c;&#x7684;&#x7f6e;&#x4fe1;&#x5ea6;
     * @return array
     */
    public function accurate($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->accurateUrl, $data);
    }

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#xff08;&#x542b;&#x751f;&#x50fb;&#x5b57;&#x7248;&#xff09;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   language_type &#x8bc6;&#x522b;&#x8bed;&#x8a00;&#x7c7b;&#x578b;&#xff0c;&#x9ed8;&#x8ba4;&#x4e3a;CHN_ENG&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;&#xff1a;<br>- CHN_ENG&#xff1a;&#x4e2d;&#x82f1;&#x6587;&#x6df7;&#x5408;&#xff1b;<br>- ENG&#xff1a;&#x82f1;&#x6587;&#xff1b;<br>- POR&#xff1a;&#x8461;&#x8404;&#x7259;&#x8bed;&#xff1b;<br>- FRE&#xff1a;&#x6cd5;&#x8bed;&#xff1b;<br>- GER&#xff1a;&#x5fb7;&#x8bed;&#xff1b;<br>- ITA&#xff1a;&#x610f;&#x5927;&#x5229;&#x8bed;&#xff1b;<br>- SPA&#xff1a;&#x897f;&#x73ed;&#x7259;&#x8bed;&#xff1b;<br>- RUS&#xff1a;&#x4fc4;&#x8bed;&#xff1b;<br>- JAP&#xff1a;&#x65e5;&#x8bed;&#xff1b;<br>- KOR&#xff1a;&#x97e9;&#x8bed;&#xff1b;
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     *   detect_language &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x8bed;&#x8a00;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#x3002;&#x5f53;&#x524d;&#x652f;&#x6301;&#xff08;&#x4e2d;&#x6587;&#x3001;&#x82f1;&#x8bed;&#x3001;&#x65e5;&#x8bed;&#x3001;&#x97e9;&#x8bed;&#xff09;
     *   probability &#x662f;&#x5426;&#x8fd4;&#x56de;&#x8bc6;&#x522b;&#x7ed3;&#x679c;&#x4e2d;&#x6bcf;&#x4e00;&#x884c;&#x7684;&#x7f6e;&#x4fe1;&#x5ea6;
     * @return array
     */
    public function enhancedGeneral($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->generalEnhancedUrl, $data);
    }

    /**
     * &#x901a;&#x7528;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#xff08;&#x542b;&#x751f;&#x50fb;&#x5b57;&#x7248;&#xff09;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   language_type &#x8bc6;&#x522b;&#x8bed;&#x8a00;&#x7c7b;&#x578b;&#xff0c;&#x9ed8;&#x8ba4;&#x4e3a;CHN_ENG&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;&#xff1a;<br>- CHN_ENG&#xff1a;&#x4e2d;&#x82f1;&#x6587;&#x6df7;&#x5408;&#xff1b;<br>- ENG&#xff1a;&#x82f1;&#x6587;&#xff1b;<br>- POR&#xff1a;&#x8461;&#x8404;&#x7259;&#x8bed;&#xff1b;<br>- FRE&#xff1a;&#x6cd5;&#x8bed;&#xff1b;<br>- GER&#xff1a;&#x5fb7;&#x8bed;&#xff1b;<br>- ITA&#xff1a;&#x610f;&#x5927;&#x5229;&#x8bed;&#xff1b;<br>- SPA&#xff1a;&#x897f;&#x73ed;&#x7259;&#x8bed;&#xff1b;<br>- RUS&#xff1a;&#x4fc4;&#x8bed;&#xff1b;<br>- JAP&#xff1a;&#x65e5;&#x8bed;&#xff1b;<br>- KOR&#xff1a;&#x97e9;&#x8bed;&#xff1b;
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     *   detect_language &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x8bed;&#x8a00;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#x3002;&#x5f53;&#x524d;&#x652f;&#x6301;&#xff08;&#x4e2d;&#x6587;&#x3001;&#x82f1;&#x8bed;&#x3001;&#x65e5;&#x8bed;&#x3001;&#x97e9;&#x8bed;&#xff09;
     *   probability &#x662f;&#x5426;&#x8fd4;&#x56de;&#x8bc6;&#x522b;&#x7ed3;&#x679c;&#x4e2d;&#x6bcf;&#x4e00;&#x884c;&#x7684;&#x7f6e;&#x4fe1;&#x5ea6;
     * @return array
     */
    public function enhancedGeneralUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->generalEnhancedUrl, $data);
    }

    /**
     * &#x7f51;&#x7edc;&#x56fe;&#x7247;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     *   detect_language &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x8bed;&#x8a00;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#x3002;&#x5f53;&#x524d;&#x652f;&#x6301;&#xff08;&#x4e2d;&#x6587;&#x3001;&#x82f1;&#x8bed;&#x3001;&#x65e5;&#x8bed;&#x3001;&#x97e9;&#x8bed;&#xff09;
     * @return array
     */
    public function webImage($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->webImageUrl, $data);
    }

    /**
     * &#x7f51;&#x7edc;&#x56fe;&#x7247;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     *   detect_language &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x8bed;&#x8a00;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#x3002;&#x5f53;&#x524d;&#x652f;&#x6301;&#xff08;&#x4e2d;&#x6587;&#x3001;&#x82f1;&#x8bed;&#x3001;&#x65e5;&#x8bed;&#x3001;&#x97e9;&#x8bed;&#xff09;
     * @return array
     */
    public function webImageUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->webImageUrl, $data);
    }

    /**
     * &#x8eab;&#x4efd;&#x8bc1;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param string $idCardSide - front&#xff1a;&#x8eab;&#x4efd;&#x8bc1;&#x542b;&#x7167;&#x7247;&#x7684;&#x4e00;&#x9762;&#xff1b;back&#xff1a;&#x8eab;&#x4efd;&#x8bc1;&#x5e26;&#x56fd;&#x5fbd;&#x7684;&#x4e00;&#x9762;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     *   detect_risk &#x662f;&#x5426;&#x5f00;&#x542f;&#x8eab;&#x4efd;&#x8bc1;&#x98ce;&#x9669;&#x7c7b;&#x578b;(&#x8eab;&#x4efd;&#x8bc1;&#x590d;&#x5370;&#x4ef6;&#x3001;&#x4e34;&#x65f6;&#x8eab;&#x4efd;&#x8bc1;&#x3001;&#x8eab;&#x4efd;&#x8bc1;&#x7ffb;&#x62cd;&#x3001;&#x4fee;&#x6539;&#x8fc7;&#x7684;&#x8eab;&#x4efd;&#x8bc1;)&#x529f;&#x80fd;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x5f00;&#x542f;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x53ef;&#x9009;&#x503c;:true-&#x5f00;&#x542f;&#xff1b;false-&#x4e0d;&#x5f00;&#x542f;
     * @return array
     */
    public function idcard($image, $idCardSide, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);
        $data['id_card_side'] = $idCardSide;

        $data = array_merge($data, $options);

        return $this->request($this->idcardUrl, $data);
    }

    /**
     * &#x94f6;&#x884c;&#x5361;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function bankcard($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->bankcardUrl, $data);
    }

    /**
     * &#x9a7e;&#x9a76;&#x8bc1;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     * @return array
     */
    public function drivingLicense($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->drivingLicenseUrl, $data);
    }

    /**
     * &#x884c;&#x9a76;&#x8bc1;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     *   accuracy normal &#x4f7f;&#x7528;&#x5feb;&#x901f;&#x670d;&#x52a1;&#xff0c;1200ms&#x5de6;&#x53f3;&#x65f6;&#x5ef6;&#xff1b;&#x7f3a;&#x7701;&#x6216;&#x5176;&#x5b83;&#x503c;&#x4f7f;&#x7528;&#x9ad8;&#x7cbe;&#x5ea6;&#x670d;&#x52a1;&#xff0c;1600ms&#x5de6;&#x53f3;&#x65f6;&#x5ef6;
     * @return array
     */
    public function vehicleLicense($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->vehicleLicenseUrl, $data);
    }

    /**
     * &#x8f66;&#x724c;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   multi_detect &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x591a;&#x5f20;&#x8f66;&#x724c;&#xff0c;&#x9ed8;&#x8ba4;&#x4e3a;false&#xff0c;&#x5f53;&#x7f6e;&#x4e3a;true&#x7684;&#x65f6;&#x5019;&#x53ef;&#x4ee5;&#x5bf9;&#x4e00;&#x5f20;&#x56fe;&#x7247;&#x5185;&#x7684;&#x591a;&#x5f20;&#x8f66;&#x724c;&#x8fdb;&#x884c;&#x8bc6;&#x522b;
     * @return array
     */
    public function licensePlate($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->licensePlateUrl, $data);
    }

    /**
     * &#x8425;&#x4e1a;&#x6267;&#x7167;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function businessLicense($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->businessLicenseUrl, $data);
    }

    /**
     * &#x901a;&#x7528;&#x7968;&#x636e;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   recognize_granularity &#x662f;&#x5426;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;big&#xff1a;&#x4e0d;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;&#x9ed8;&#x8ba4;&#x503c;&#xff1b;small&#xff1a;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;
     *   probability &#x662f;&#x5426;&#x8fd4;&#x56de;&#x8bc6;&#x522b;&#x7ed3;&#x679c;&#x4e2d;&#x6bcf;&#x4e00;&#x884c;&#x7684;&#x7f6e;&#x4fe1;&#x5ea6;
     *   accuracy normal &#x4f7f;&#x7528;&#x5feb;&#x901f;&#x670d;&#x52a1;&#xff0c;1200ms&#x5de6;&#x53f3;&#x65f6;&#x5ef6;&#xff1b;&#x7f3a;&#x7701;&#x6216;&#x5176;&#x5b83;&#x503c;&#x4f7f;&#x7528;&#x9ad8;&#x7cbe;&#x5ea6;&#x670d;&#x52a1;&#xff0c;1600ms&#x5de6;&#x53f3;&#x65f6;&#x5ef6;
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     * @return array
     */
    public function receipt($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->receiptUrl, $data);
    }

    /**
     * &#x706b;&#x8f66;&#x7968;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function trainTicket($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->trainTicketUrl, $data);
    }

    /**
     * &#x51fa;&#x79df;&#x8f66;&#x7968;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function taxiReceipt($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->taxiReceiptUrl, $data);
    }

    /**
     * &#x8868;&#x683c;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#x540c;&#x6b65;&#x63a5;&#x53e3;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function form($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->formUrl, $data);
    }

    /**
     * &#x8868;&#x683c;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function tableRecognitionAsync($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->tableRecognizeUrl, $data);
    }

    /**
     * &#x8868;&#x683c;&#x8bc6;&#x522b;&#x7ed3;&#x679c;&#x63a5;&#x53e3;
     *
     * @param string $requestId - &#x53d1;&#x9001;&#x8868;&#x683c;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#x8bf7;&#x6c42;&#x65f6;&#x8fd4;&#x56de;&#x7684;request id
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   result_type &#x671f;&#x671b;&#x83b7;&#x53d6;&#x7ed3;&#x679c;&#x7684;&#x7c7b;&#x578b;&#xff0c;&#x53d6;&#x503c;&#x4e3a;&#x201c;excel&#x201d;&#x65f6;&#x8fd4;&#x56de;xls&#x6587;&#x4ef6;&#x7684;&#x5730;&#x5740;&#xff0c;&#x53d6;&#x503c;&#x4e3a;&#x201c;json&#x201d;&#x65f6;&#x8fd4;&#x56de;json&#x683c;&#x5f0f;&#x7684;&#x5b57;&#x7b26;&#x4e32;,&#x9ed8;&#x8ba4;&#x4e3a;&#x201d;excel&#x201d;
     * @return array
     */
    public function getTableRecognitionResult($requestId, $options=array()){

        $data = array();
        
        $data['request_id'] = $requestId;

        $data = array_merge($data, $options);

        return $this->request($this->tableResultGetUrl, $data);
    }

    /**
     * &#x589e;&#x503c;&#x7a0e;&#x53d1;&#x7968;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function vatInvoice($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->vatInvoiceUrl, $data);
    }

    /**
     * &#x4e8c;&#x7ef4;&#x7801;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function qrcode($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->qrcodeUrl, $data);
    }

    /**
     * &#x6570;&#x5b57;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   recognize_granularity &#x662f;&#x5426;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;big&#xff1a;&#x4e0d;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;&#x9ed8;&#x8ba4;&#x503c;&#xff1b;small&#xff1a;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;
     *   detect_direction &#x662f;&#x5426;&#x68c0;&#x6d4b;&#x56fe;&#x50cf;&#x671d;&#x5411;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x68c0;&#x6d4b;&#xff0c;&#x5373;&#xff1a;false&#x3002;&#x671d;&#x5411;&#x662f;&#x6307;&#x8f93;&#x5165;&#x56fe;&#x50cf;&#x662f;&#x6b63;&#x5e38;&#x65b9;&#x5411;&#x3001;&#x9006;&#x65f6;&#x9488;&#x65cb;&#x8f6c;90/180/270&#x5ea6;&#x3002;&#x53ef;&#x9009;&#x503c;&#x5305;&#x62ec;:<br>- true&#xff1a;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#xff1b;<br>- false&#xff1a;&#x4e0d;&#x68c0;&#x6d4b;&#x671d;&#x5411;&#x3002;
     * @return array
     */
    public function numbers($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->numbersUrl, $data);
    }

    /**
     * &#x5f69;&#x7968;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   recognize_granularity &#x662f;&#x5426;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;big&#xff1a;&#x4e0d;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;&#x9ed8;&#x8ba4;&#x503c;&#xff1b;small&#xff1a;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;
     * @return array
     */
    public function lottery($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->lotteryUrl, $data);
    }

    /**
     * &#x62a4;&#x7167;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function passport($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->passportUrl, $data);
    }

    /**
     * &#x540d;&#x7247;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function businessCard($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->businessCardUrl, $data);
    }

    /**
     * &#x624b;&#x5199;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   recognize_granularity &#x662f;&#x5426;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;big&#xff1a;&#x4e0d;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;&#xff0c;&#x9ed8;&#x8ba4;&#x503c;&#xff1b;small&#xff1a;&#x5b9a;&#x4f4d;&#x5355;&#x5b57;&#x7b26;&#x4f4d;&#x7f6e;
     * @return array
     */
    public function handwriting($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->handwritingUrl, $data);
    }

    /**
     * &#x81ea;&#x5b9a;&#x4e49;&#x6a21;&#x677f;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param string $templateSign - &#x60a8;&#x5728;&#x81ea;&#x5b9a;&#x4e49;&#x6587;&#x5b57;&#x8bc6;&#x522b;&#x5e73;&#x53f0;&#x5236;&#x4f5c;&#x7684;&#x6a21;&#x677f;&#x7684;ID
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function custom($image, $templateSign, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);
        $data['templateSign'] = $templateSign;

        $data = array_merge($data, $options);

        return $this->request($this->customUrl, $data);
    }

    /**
     * &#x540c;&#x6b65;&#x8bf7;&#x6c42;
     * @param  string $image &#x56fe;&#x50cf;&#x8bfb;&#x53d6;
     * @param  options &#x63a5;&#x53e3;&#x53ef;&#x9009;&#x53c2;&#x6570;
     * @return array
     */
    public function tableRecognition($image, $options=array(), $timeout=10000){
        $result = $this->tableRecognitionAsync($image);
        if(isset($result['error_code'])){
            return $result;
        }
        $requestId = $result['result'][0]['request_id'];
        $count = ceil($timeout / 1000);
        for($i=0; $i<$count; $i++){
            $result = $this->getTableRecognitionResult($requestId, $options);
            // &#x5b8c;&#x6210;
            if($result['result']['ret_code'] == 3){ 
                break;
            }
            sleep(1);
        }
        return $result;
    }

}

