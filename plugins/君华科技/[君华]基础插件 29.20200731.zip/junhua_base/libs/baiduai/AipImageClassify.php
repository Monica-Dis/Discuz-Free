<?php
/*
* Copyright (c) 2017 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License. You may obtain a copy of
* the License at
*
* Http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/

require_once 'lib/AipBase.php';
class AipImageClassify extends AipBase {

    /**
     * &#x901a;&#x7528;&#x7269;&#x4f53;&#x8bc6;&#x522b; advanced_general api url
     * @var string
     */
    private $advancedGeneralUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v2/advanced_general';

    /**
     * &#x83dc;&#x54c1;&#x8bc6;&#x522b; dish_detect api url
     * @var string
     */
    private $dishDetectUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v2/dish';

    /**
     * &#x8f66;&#x8f86;&#x8bc6;&#x522b; car_detect api url
     * @var string
     */
    private $carDetectUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/car';

    /**
     * logo&#x5546;&#x6807;&#x8bc6;&#x522b; logo_search api url
     * @var string
     */
    private $logoSearchUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v2/logo';

    /**
     * logo&#x5546;&#x6807;&#x8bc6;&#x522b;&#x2014;&#x6dfb;&#x52a0; logo_add api url
     * @var string
     */
    private $logoAddUrl = 'https://aip.baidubce.com/rest/2.0/realtime_search/v1/logo/add';

    /**
     * logo&#x5546;&#x6807;&#x8bc6;&#x522b;&#x2014;&#x5220;&#x9664; logo_delete api url
     * @var string
     */
    private $logoDeleteUrl = 'https://aip.baidubce.com/rest/2.0/realtime_search/v1/logo/delete';

    /**
     * &#x52a8;&#x7269;&#x8bc6;&#x522b; animal_detect api url
     * @var string
     */
    private $animalDetectUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/animal';

    /**
     * &#x690d;&#x7269;&#x8bc6;&#x522b; plant_detect api url
     * @var string
     */
    private $plantDetectUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/plant';

    /**
     * &#x56fe;&#x50cf;&#x4e3b;&#x4f53;&#x68c0;&#x6d4b; object_detect api url
     * @var string
     */
    private $objectDetectUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/object_detect';

    /**
     * &#x5730;&#x6807;&#x8bc6;&#x522b; landmark api url
     * @var string
     */
    private $landmarkUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/landmark';

    

    /**
     * &#x901a;&#x7528;&#x7269;&#x4f53;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   baike_num &#x8fd4;&#x56de;&#x767e;&#x79d1;&#x4fe1;&#x606f;&#x7684;&#x7ed3;&#x679c;&#x6570;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x8fd4;&#x56de;
     * @return array
     */
    public function advancedGeneral($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->advancedGeneralUrl, $data);
    }

    /**
     * &#x83dc;&#x54c1;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   top_num &#x8fd4;&#x56de;&#x9884;&#x6d4b;&#x5f97;&#x5206;top&#x7ed3;&#x679c;&#x6570;&#xff0c;&#x9ed8;&#x8ba4;&#x4e3a;5
     *   filter_threshold &#x9ed8;&#x8ba4;0.95&#xff0c;&#x53ef;&#x4ee5;&#x901a;&#x8fc7;&#x8be5;&#x53c2;&#x6570;&#x8c03;&#x8282;&#x8bc6;&#x522b;&#x6548;&#x679c;&#xff0c;&#x964d;&#x4f4e;&#x975e;&#x83dc;&#x8bc6;&#x522b;&#x7387;.
     *   baike_num &#x8fd4;&#x56de;&#x767e;&#x79d1;&#x4fe1;&#x606f;&#x7684;&#x7ed3;&#x679c;&#x6570;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x8fd4;&#x56de;
     * @return array
     */
    public function dishDetect($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->dishDetectUrl, $data);
    }

    /**
     * &#x8f66;&#x8f86;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   top_num &#x8fd4;&#x56de;&#x9884;&#x6d4b;&#x5f97;&#x5206;top&#x7ed3;&#x679c;&#x6570;&#xff0c;&#x9ed8;&#x8ba4;&#x4e3a;5
     *   baike_num &#x8fd4;&#x56de;&#x767e;&#x79d1;&#x4fe1;&#x606f;&#x7684;&#x7ed3;&#x679c;&#x6570;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x8fd4;&#x56de;
     * @return array
     */
    public function carDetect($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->carDetectUrl, $data);
    }

    /**
     * logo&#x5546;&#x6807;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   custom_lib &#x662f;&#x5426;&#x53ea;&#x4f7f;&#x7528;&#x81ea;&#x5b9a;&#x4e49;logo&#x5e93;&#x7684;&#x7ed3;&#x679c;&#xff0c;&#x9ed8;&#x8ba4;false&#xff1a;&#x8fd4;&#x56de;&#x81ea;&#x5b9a;&#x4e49;&#x5e93;+&#x9ed8;&#x8ba4;&#x5e93;&#x7684;&#x8bc6;&#x522b;&#x7ed3;&#x679c;
     * @return array
     */
    public function logoSearch($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->logoSearchUrl, $data);
    }

    /**
     * logo&#x5546;&#x6807;&#x8bc6;&#x522b;&#x2014;&#x6dfb;&#x52a0;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param string $brief - brief&#xff0c;&#x68c0;&#x7d22;&#x65f6;&#x5e26;&#x56de;&#x3002;&#x6b64;&#x5904;&#x8981;&#x4f20;&#x5bf9;&#x5e94;&#x7684;name&#x4e0e;code&#x5b57;&#x6bb5;&#xff0c;name&#x957f;&#x5ea6;&#x5c0f;&#x4e8e;100B&#xff0c;code&#x957f;&#x5ea6;&#x5c0f;&#x4e8e;150B
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function logoAdd($image, $brief, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);
        $data['brief'] = $brief;

        $data = array_merge($data, $options);

        return $this->request($this->logoAddUrl, $data);
    }

    /**
     * logo&#x5546;&#x6807;&#x8bc6;&#x522b;&#x2014;&#x5220;&#x9664;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function logoDeleteByImage($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->logoDeleteUrl, $data);
    }

    /**
     * logo&#x5546;&#x6807;&#x8bc6;&#x522b;&#x2014;&#x5220;&#x9664;&#x63a5;&#x53e3;
     *
     * @param string $contSign - &#x56fe;&#x7247;&#x7b7e;&#x540d;&#xff08;&#x548c;image&#x4e8c;&#x9009;&#x4e00;&#xff0c;image&#x4f18;&#x5148;&#x7ea7;&#x66f4;&#x9ad8;&#xff09;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function logoDeleteBySign($contSign, $options=array()){

        $data = array();
        
        $data['cont_sign'] = $contSign;

        $data = array_merge($data, $options);

        return $this->request($this->logoDeleteUrl, $data);
    }

    /**
     * &#x52a8;&#x7269;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   top_num &#x8fd4;&#x56de;&#x9884;&#x6d4b;&#x5f97;&#x5206;top&#x7ed3;&#x679c;&#x6570;&#xff0c;&#x9ed8;&#x8ba4;&#x4e3a;6
     *   baike_num &#x8fd4;&#x56de;&#x767e;&#x79d1;&#x4fe1;&#x606f;&#x7684;&#x7ed3;&#x679c;&#x6570;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x8fd4;&#x56de;
     * @return array
     */
    public function animalDetect($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->animalDetectUrl, $data);
    }

    /**
     * &#x690d;&#x7269;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   baike_num &#x8fd4;&#x56de;&#x767e;&#x79d1;&#x4fe1;&#x606f;&#x7684;&#x7ed3;&#x679c;&#x6570;&#xff0c;&#x9ed8;&#x8ba4;&#x4e0d;&#x8fd4;&#x56de;
     * @return array
     */
    public function plantDetect($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->plantDetectUrl, $data);
    }

    /**
     * &#x56fe;&#x50cf;&#x4e3b;&#x4f53;&#x68c0;&#x6d4b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   with_face &#x5982;&#x679c;&#x68c0;&#x6d4b;&#x4e3b;&#x4f53;&#x662f;&#x4eba;&#xff0c;&#x4e3b;&#x4f53;&#x533a;&#x57df;&#x662f;&#x5426;&#x5e26;&#x4e0a;&#x4eba;&#x8138;&#x90e8;&#x5206;&#xff0c;0-&#x4e0d;&#x5e26;&#x4eba;&#x8138;&#x533a;&#x57df;&#xff0c;&#x5176;&#x4ed6;-&#x5e26;&#x4eba;&#x8138;&#x533a;&#x57df;&#xff0c;&#x88c1;&#x526a;&#x7c7b;&#x9700;&#x6c42;&#x63a8;&#x8350;&#x5e26;&#x4eba;&#x8138;&#xff0c;&#x68c0;&#x7d22;/&#x8bc6;&#x522b;&#x7c7b;&#x9700;&#x6c42;&#x63a8;&#x8350;&#x4e0d;&#x5e26;&#x4eba;&#x8138;&#x3002;&#x9ed8;&#x8ba4;&#x53d6;1&#xff0c;&#x5e26;&#x4eba;&#x8138;&#x3002;
     * @return array
     */
    public function objectDetect($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->objectDetectUrl, $data);
    }

    /**
     * &#x5730;&#x6807;&#x8bc6;&#x522b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function landmark($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->landmarkUrl, $data);
    }
}