<?php
/*
* Copyright (c) 2017 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License. You may obtain a copy of
* the License at
*
* Http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/

require_once 'lib/AipBase.php';

/**
 * &#x767e;&#x5ea6;&#x8bed;&#x97f3;
 */
class AipSpeech extends AipBase{

    /**
     * url
     * @var string
     */
    public $asrUrl = 'http://vop.baidu.com/server_api';

    /**
     * url
     * @var string
     */
    public $ttsUrl = 'http://tsn.baidu.com/text2audio';

    /**
     * &#x5224;&#x65ad;&#x8ba4;&#x8bc1;&#x662f;&#x5426;&#x6709;&#x6743;&#x9650;
     * @param  array   $authObj 
     * @return boolean          
     */
    protected function isPermission($authObj)
    {
        return true;
    }

    /**
     * &#x5904;&#x7406;&#x8bf7;&#x6c42;&#x53c2;&#x6570;
     * @param string $url
     * @param array $params
     * @param array $data
     * @param array $headers
     */
    protected function proccessRequest($url, &$params, &$data, $headers){

        $token = isset($params['access_token']) ? $params['access_token'] : '';

        if(empty($data['cuid'])){
            $data['cuid'] = md5($token);
        }

        if($url === $this->asrUrl){
            $data['token'] = $token;
            $data = json_encode($data);
        }else{
            $data['tok'] = $token;
        }

        unset($params['access_token']);
    }

    /**
     * &#x683c;&#x5f0f;&#x5316;&#x7ed3;&#x679c;
     * @param $content string
     * @return mixed
     */
    protected function proccessResult($content){
        $obj = json_decode($content, true);

        if($obj === null){
            $obj = array(
                '__json_decode_error' => $content
            );
        }

        return $obj;
    }

    /**
     * @param  string $speech
     * @param  string $format
     * @param  int $rate
     * @param  array $options
     * @return array
     */
    public function asr($speech, $format, $rate, $options=array()){
        $data = array();

        if(!empty($speech)){
            $data['speech'] = base64_encode($speech);
            $data['len'] = strlen($speech);
        }

        $data['format'] = $format;
        $data['rate'] = $rate;
        $data['channel'] = 1;

        $data = array_merge($data, $options);  

        return $this->request($this->asrUrl, $data, array());
    }

    /**
     * @param  string $text
     * @param  string $lang
     * @param  int $ctp
     * @param  array $options
     * @return array
     */
    public function synthesis($text, $lang='zh', $ctp=1, $options=array()){
        $data = array();

        $data['tex'] = $text;
        $data['lan'] = $lang;
        $data['ctp'] = $ctp;

        $data = array_merge($data, $options);  

        $result = $this->request($this->ttsUrl, $data, array());

        if(isset($result['__json_decode_error'])){
            return $result['__json_decode_error'];
        }

        return $result;
    }

}
