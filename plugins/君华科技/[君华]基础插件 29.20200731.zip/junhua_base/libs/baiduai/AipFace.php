<?php
/*
* Copyright (c) 2017 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License. You may obtain a copy of
* the License at
*
* Http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/

require_once 'lib/AipBase.php';
class AipFace extends AipBase {

    /**
     * &#x4eba;&#x8138;&#x68c0;&#x6d4b; detect api url
     * @var string
     */
    private $detectUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/detect';

    /**
     * &#x4eba;&#x8138;&#x641c;&#x7d22; search api url
     * @var string
     */
    private $searchUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/search';

    /**
     * &#x4eba;&#x8138;&#x6ce8;&#x518c; user_add api url
     * @var string
     */
    private $userAddUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/faceset/user/add';

    /**
     * &#x4eba;&#x8138;&#x66f4;&#x65b0; user_update api url
     * @var string
     */
    private $userUpdateUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/faceset/user/update';

    /**
     * &#x4eba;&#x8138;&#x5220;&#x9664; face_delete api url
     * @var string
     */
    private $faceDeleteUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/faceset/face/delete';

    /**
     * &#x7528;&#x6237;&#x4fe1;&#x606f;&#x67e5;&#x8be2; user_get api url
     * @var string
     */
    private $userGetUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/faceset/user/get';

    /**
     * &#x83b7;&#x53d6;&#x7528;&#x6237;&#x4eba;&#x8138;&#x5217;&#x8868; face_getlist api url
     * @var string
     */
    private $faceGetlistUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/faceset/face/getlist';

    /**
     * &#x83b7;&#x53d6;&#x7528;&#x6237;&#x5217;&#x8868; group_getusers api url
     * @var string
     */
    private $groupGetusersUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/faceset/group/getusers';

    /**
     * &#x590d;&#x5236;&#x7528;&#x6237; user_copy api url
     * @var string
     */
    private $userCopyUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/faceset/user/copy';

    /**
     * &#x5220;&#x9664;&#x7528;&#x6237; user_delete api url
     * @var string
     */
    private $userDeleteUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/faceset/user/delete';

    /**
     * &#x521b;&#x5efa;&#x7528;&#x6237;&#x7ec4; group_add api url
     * @var string
     */
    private $groupAddUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/faceset/group/add';

    /**
     * &#x5220;&#x9664;&#x7528;&#x6237;&#x7ec4; group_delete api url
     * @var string
     */
    private $groupDeleteUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/faceset/group/delete';

    /**
     * &#x7ec4;&#x5217;&#x8868;&#x67e5;&#x8be2; group_getlist api url
     * @var string
     */
    private $groupGetlistUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/faceset/group/getlist';

    /**
     * &#x8eab;&#x4efd;&#x9a8c;&#x8bc1; person_verify api url
     * @var string
     */
    private $personVerifyUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/person/verify';

    /**
     * &#x8bed;&#x97f3;&#x6821;&#x9a8c;&#x7801;&#x63a5;&#x53e3; video_sessioncode api url
     * @var string
     */
    private $videoSessioncodeUrl = 'https://aip.baidubce.com/rest/2.0/face/v1/faceliveness/sessioncode';

    

    /**
     * &#x4eba;&#x8138;&#x68c0;&#x6d4b;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x7247;&#x4fe1;&#x606f;(**&#x603b;&#x6570;&#x636e;&#x5927;&#x5c0f;&#x5e94;&#x5c0f;&#x4e8e;10M**)&#xff0c;&#x56fe;&#x7247;&#x4e0a;&#x4f20;&#x65b9;&#x5f0f;&#x6839;&#x636e;image_type&#x6765;&#x5224;&#x65ad;
     * @param string $imageType - &#x56fe;&#x7247;&#x7c7b;&#x578b; **BASE64**:&#x56fe;&#x7247;&#x7684;base64&#x503c;&#xff0c;base64&#x7f16;&#x7801;&#x540e;&#x7684;&#x56fe;&#x7247;&#x6570;&#x636e;&#xff0c;&#x9700;urlencode&#xff0c;&#x7f16;&#x7801;&#x540e;&#x7684;&#x56fe;&#x7247;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;2M&#xff1b;**URL**:&#x56fe;&#x7247;&#x7684; URL&#x5730;&#x5740;( &#x53ef;&#x80fd;&#x7531;&#x4e8e;&#x7f51;&#x7edc;&#x7b49;&#x539f;&#x56e0;&#x5bfc;&#x81f4;&#x4e0b;&#x8f7d;&#x56fe;&#x7247;&#x65f6;&#x95f4;&#x8fc7;&#x957f;)**&#xff1b;FACE_TOKEN**: &#x4eba;&#x8138;&#x56fe;&#x7247;&#x7684;&#x552f;&#x4e00;&#x6807;&#x8bc6;&#xff0c;&#x8c03;&#x7528;&#x4eba;&#x8138;&#x68c0;&#x6d4b;&#x63a5;&#x53e3;&#x65f6;&#xff0c;&#x4f1a;&#x4e3a;&#x6bcf;&#x4e2a;&#x4eba;&#x8138;&#x56fe;&#x7247;&#x8d4b;&#x4e88;&#x4e00;&#x4e2a;&#x552f;&#x4e00;&#x7684;FACE_TOKEN&#xff0c;&#x540c;&#x4e00;&#x5f20;&#x56fe;&#x7247;&#x591a;&#x6b21;&#x68c0;&#x6d4b;&#x5f97;&#x5230;&#x7684;FACE_TOKEN&#x662f;&#x540c;&#x4e00;&#x4e2a;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   face_field &#x5305;&#x62ec;**age,beauty,expression,faceshape,gender,glasses,landmark,race,quality,facetype&#x4fe1;&#x606f;**  <br> &#x9017;&#x53f7;&#x5206;&#x9694;. &#x9ed8;&#x8ba4;&#x53ea;&#x8fd4;&#x56de;face_token&#x3001;&#x4eba;&#x8138;&#x6846;&#x3001;&#x6982;&#x7387;&#x548c;&#x65cb;&#x8f6c;&#x89d2;&#x5ea6;
     *   max_face_num &#x6700;&#x591a;&#x5904;&#x7406;&#x4eba;&#x8138;&#x7684;&#x6570;&#x76ee;&#xff0c;&#x9ed8;&#x8ba4;&#x503c;&#x4e3a;1&#xff0c;&#x4ec5;&#x68c0;&#x6d4b;&#x56fe;&#x7247;&#x4e2d;&#x9762;&#x79ef;&#x6700;&#x5927;&#x7684;&#x90a3;&#x4e2a;&#x4eba;&#x8138;&#xff1b;**&#x6700;&#x5927;&#x503c;10**&#xff0c;&#x68c0;&#x6d4b;&#x56fe;&#x7247;&#x4e2d;&#x9762;&#x79ef;&#x6700;&#x5927;&#x7684;&#x51e0;&#x5f20;&#x4eba;&#x8138;&#x3002;
     *   face_type &#x4eba;&#x8138;&#x7684;&#x7c7b;&#x578b; **LIVE**&#x8868;&#x793a;&#x751f;&#x6d3b;&#x7167;&#xff1a;&#x901a;&#x5e38;&#x4e3a;&#x624b;&#x673a;&#x3001;&#x76f8;&#x673a;&#x62cd;&#x6444;&#x7684;&#x4eba;&#x50cf;&#x56fe;&#x7247;&#x3001;&#x6216;&#x4ece;&#x7f51;&#x7edc;&#x83b7;&#x53d6;&#x7684;&#x4eba;&#x50cf;&#x56fe;&#x7247;&#x7b49;**IDCARD**&#x8868;&#x793a;&#x8eab;&#x4efd;&#x8bc1;&#x82af;&#x7247;&#x7167;&#xff1a;&#x4e8c;&#x4ee3;&#x8eab;&#x4efd;&#x8bc1;&#x5185;&#x7f6e;&#x82af;&#x7247;&#x4e2d;&#x7684;&#x4eba;&#x50cf;&#x7167;&#x7247; **WATERMARK**&#x8868;&#x793a;&#x5e26;&#x6c34;&#x5370;&#x8bc1;&#x4ef6;&#x7167;&#xff1a;&#x4e00;&#x822c;&#x4e3a;&#x5e26;&#x6c34;&#x5370;&#x7684;&#x5c0f;&#x56fe;&#xff0c;&#x5982;&#x516c;&#x5b89;&#x7f51;&#x5c0f;&#x56fe; **CERT**&#x8868;&#x793a;&#x8bc1;&#x4ef6;&#x7167;&#x7247;&#xff1a;&#x5982;&#x62cd;&#x6444;&#x7684;&#x8eab;&#x4efd;&#x8bc1;&#x3001;&#x5de5;&#x5361;&#x3001;&#x62a4;&#x7167;&#x3001;&#x5b66;&#x751f;&#x8bc1;&#x7b49;&#x8bc1;&#x4ef6;&#x56fe;&#x7247; &#x9ed8;&#x8ba4;**LIVE**
     * @return array
     */
    public function detect($image, $imageType, $options=array()){

        $data = array();
        
        $data['image'] = $image;
        $data['image_type'] = $imageType;

        $data = array_merge($data, $options);
        return $this->request($this->detectUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x4eba;&#x8138;&#x641c;&#x7d22;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x7247;&#x4fe1;&#x606f;(**&#x603b;&#x6570;&#x636e;&#x5927;&#x5c0f;&#x5e94;&#x5c0f;&#x4e8e;10M**)&#xff0c;&#x56fe;&#x7247;&#x4e0a;&#x4f20;&#x65b9;&#x5f0f;&#x6839;&#x636e;image_type&#x6765;&#x5224;&#x65ad;
     * @param string $imageType - &#x56fe;&#x7247;&#x7c7b;&#x578b; **BASE64**:&#x56fe;&#x7247;&#x7684;base64&#x503c;&#xff0c;base64&#x7f16;&#x7801;&#x540e;&#x7684;&#x56fe;&#x7247;&#x6570;&#x636e;&#xff0c;&#x9700;urlencode&#xff0c;&#x7f16;&#x7801;&#x540e;&#x7684;&#x56fe;&#x7247;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;2M&#xff1b;**URL**:&#x56fe;&#x7247;&#x7684; URL&#x5730;&#x5740;( &#x53ef;&#x80fd;&#x7531;&#x4e8e;&#x7f51;&#x7edc;&#x7b49;&#x539f;&#x56e0;&#x5bfc;&#x81f4;&#x4e0b;&#x8f7d;&#x56fe;&#x7247;&#x65f6;&#x95f4;&#x8fc7;&#x957f;)**&#xff1b;FACE_TOKEN**: &#x4eba;&#x8138;&#x56fe;&#x7247;&#x7684;&#x552f;&#x4e00;&#x6807;&#x8bc6;&#xff0c;&#x8c03;&#x7528;&#x4eba;&#x8138;&#x68c0;&#x6d4b;&#x63a5;&#x53e3;&#x65f6;&#xff0c;&#x4f1a;&#x4e3a;&#x6bcf;&#x4e2a;&#x4eba;&#x8138;&#x56fe;&#x7247;&#x8d4b;&#x4e88;&#x4e00;&#x4e2a;&#x552f;&#x4e00;&#x7684;FACE_TOKEN&#xff0c;&#x540c;&#x4e00;&#x5f20;&#x56fe;&#x7247;&#x591a;&#x6b21;&#x68c0;&#x6d4b;&#x5f97;&#x5230;&#x7684;FACE_TOKEN&#x662f;&#x540c;&#x4e00;&#x4e2a;
     * @param string $groupIdList - &#x4ece;&#x6307;&#x5b9a;&#x7684;group&#x4e2d;&#x8fdb;&#x884c;&#x67e5;&#x627e; &#x7528;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;**&#x4e0a;&#x9650;20&#x4e2a;**
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   quality_control &#x56fe;&#x7247;&#x8d28;&#x91cf;&#x63a7;&#x5236;  **NONE**: &#x4e0d;&#x8fdb;&#x884c;&#x63a7;&#x5236; **LOW**:&#x8f83;&#x4f4e;&#x7684;&#x8d28;&#x91cf;&#x8981;&#x6c42; **NORMAL**: &#x4e00;&#x822c;&#x7684;&#x8d28;&#x91cf;&#x8981;&#x6c42; **HIGH**: &#x8f83;&#x9ad8;&#x7684;&#x8d28;&#x91cf;&#x8981;&#x6c42; **&#x9ed8;&#x8ba4; NONE**
     *   liveness_control &#x6d3b;&#x4f53;&#x68c0;&#x6d4b;&#x63a7;&#x5236;  **NONE**: &#x4e0d;&#x8fdb;&#x884c;&#x63a7;&#x5236; **LOW**:&#x8f83;&#x4f4e;&#x7684;&#x6d3b;&#x4f53;&#x8981;&#x6c42;(&#x9ad8;&#x901a;&#x8fc7;&#x7387; &#x4f4e;&#x653b;&#x51fb;&#x62d2;&#x7edd;&#x7387;) **NORMAL**: &#x4e00;&#x822c;&#x7684;&#x6d3b;&#x4f53;&#x8981;&#x6c42;(&#x5e73;&#x8861;&#x7684;&#x653b;&#x51fb;&#x62d2;&#x7edd;&#x7387;, &#x901a;&#x8fc7;&#x7387;) **HIGH**: &#x8f83;&#x9ad8;&#x7684;&#x6d3b;&#x4f53;&#x8981;&#x6c42;(&#x9ad8;&#x653b;&#x51fb;&#x62d2;&#x7edd;&#x7387; &#x4f4e;&#x901a;&#x8fc7;&#x7387;) **&#x9ed8;&#x8ba4;NONE**
     *   user_id &#x5f53;&#x9700;&#x8981;&#x5bf9;&#x7279;&#x5b9a;&#x7528;&#x6237;&#x8fdb;&#x884c;&#x6bd4;&#x5bf9;&#x65f6;&#xff0c;&#x6307;&#x5b9a;user_id&#x8fdb;&#x884c;&#x6bd4;&#x5bf9;&#x3002;&#x5373;&#x4eba;&#x8138;&#x8ba4;&#x8bc1;&#x529f;&#x80fd;&#x3002;
     *   max_user_num &#x67e5;&#x627e;&#x540e;&#x8fd4;&#x56de;&#x7684;&#x7528;&#x6237;&#x6570;&#x91cf;&#x3002;&#x8fd4;&#x56de;&#x76f8;&#x4f3c;&#x5ea6;&#x6700;&#x9ad8;&#x7684;&#x51e0;&#x4e2a;&#x7528;&#x6237;&#xff0c;&#x9ed8;&#x8ba4;&#x4e3a;1&#xff0c;&#x6700;&#x591a;&#x8fd4;&#x56de;20&#x4e2a;&#x3002;
     * @return array
     */
    public function search($image, $imageType, $groupIdList, $options=array()){

        $data = array();
        
        $data['image'] = $image;
        $data['image_type'] = $imageType;
        $data['group_id_list'] = $groupIdList;

        $data = array_merge($data, $options);
        return $this->request($this->searchUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x4eba;&#x8138;&#x6ce8;&#x518c;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x7247;&#x4fe1;&#x606f;(**&#x603b;&#x6570;&#x636e;&#x5927;&#x5c0f;&#x5e94;&#x5c0f;&#x4e8e;10M**)&#xff0c;&#x56fe;&#x7247;&#x4e0a;&#x4f20;&#x65b9;&#x5f0f;&#x6839;&#x636e;image_type&#x6765;&#x5224;&#x65ad;
     * @param string $imageType - &#x56fe;&#x7247;&#x7c7b;&#x578b; **BASE64**:&#x56fe;&#x7247;&#x7684;base64&#x503c;&#xff0c;base64&#x7f16;&#x7801;&#x540e;&#x7684;&#x56fe;&#x7247;&#x6570;&#x636e;&#xff0c;&#x9700;urlencode&#xff0c;&#x7f16;&#x7801;&#x540e;&#x7684;&#x56fe;&#x7247;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;2M&#xff1b;**URL**:&#x56fe;&#x7247;&#x7684; URL&#x5730;&#x5740;( &#x53ef;&#x80fd;&#x7531;&#x4e8e;&#x7f51;&#x7edc;&#x7b49;&#x539f;&#x56e0;&#x5bfc;&#x81f4;&#x4e0b;&#x8f7d;&#x56fe;&#x7247;&#x65f6;&#x95f4;&#x8fc7;&#x957f;)**&#xff1b;FACE_TOKEN**: &#x4eba;&#x8138;&#x56fe;&#x7247;&#x7684;&#x552f;&#x4e00;&#x6807;&#x8bc6;&#xff0c;&#x8c03;&#x7528;&#x4eba;&#x8138;&#x68c0;&#x6d4b;&#x63a5;&#x53e3;&#x65f6;&#xff0c;&#x4f1a;&#x4e3a;&#x6bcf;&#x4e2a;&#x4eba;&#x8138;&#x56fe;&#x7247;&#x8d4b;&#x4e88;&#x4e00;&#x4e2a;&#x552f;&#x4e00;&#x7684;FACE_TOKEN&#xff0c;&#x540c;&#x4e00;&#x5f20;&#x56fe;&#x7247;&#x591a;&#x6b21;&#x68c0;&#x6d4b;&#x5f97;&#x5230;&#x7684;FACE_TOKEN&#x662f;&#x540c;&#x4e00;&#x4e2a;
     * @param string $groupId - &#x7528;&#x6237;&#x7ec4;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param string $userId - &#x7528;&#x6237;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   user_info &#x7528;&#x6237;&#x8d44;&#x6599;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;256B
     *   quality_control &#x56fe;&#x7247;&#x8d28;&#x91cf;&#x63a7;&#x5236;  **NONE**: &#x4e0d;&#x8fdb;&#x884c;&#x63a7;&#x5236; **LOW**:&#x8f83;&#x4f4e;&#x7684;&#x8d28;&#x91cf;&#x8981;&#x6c42; **NORMAL**: &#x4e00;&#x822c;&#x7684;&#x8d28;&#x91cf;&#x8981;&#x6c42; **HIGH**: &#x8f83;&#x9ad8;&#x7684;&#x8d28;&#x91cf;&#x8981;&#x6c42; **&#x9ed8;&#x8ba4; NONE**
     *   liveness_control &#x6d3b;&#x4f53;&#x68c0;&#x6d4b;&#x63a7;&#x5236;  **NONE**: &#x4e0d;&#x8fdb;&#x884c;&#x63a7;&#x5236; **LOW**:&#x8f83;&#x4f4e;&#x7684;&#x6d3b;&#x4f53;&#x8981;&#x6c42;(&#x9ad8;&#x901a;&#x8fc7;&#x7387; &#x4f4e;&#x653b;&#x51fb;&#x62d2;&#x7edd;&#x7387;) **NORMAL**: &#x4e00;&#x822c;&#x7684;&#x6d3b;&#x4f53;&#x8981;&#x6c42;(&#x5e73;&#x8861;&#x7684;&#x653b;&#x51fb;&#x62d2;&#x7edd;&#x7387;, &#x901a;&#x8fc7;&#x7387;) **HIGH**: &#x8f83;&#x9ad8;&#x7684;&#x6d3b;&#x4f53;&#x8981;&#x6c42;(&#x9ad8;&#x653b;&#x51fb;&#x62d2;&#x7edd;&#x7387; &#x4f4e;&#x901a;&#x8fc7;&#x7387;) **&#x9ed8;&#x8ba4;NONE**
     * @return array
     */
    public function addUser($image, $imageType, $groupId, $userId, $options=array()){

        $data = array();
        
        $data['image'] = $image;
        $data['image_type'] = $imageType;
        $data['group_id'] = $groupId;
        $data['user_id'] = $userId;

        $data = array_merge($data, $options);
        return $this->request($this->userAddUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x4eba;&#x8138;&#x66f4;&#x65b0;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x7247;&#x4fe1;&#x606f;(**&#x603b;&#x6570;&#x636e;&#x5927;&#x5c0f;&#x5e94;&#x5c0f;&#x4e8e;10M**)&#xff0c;&#x56fe;&#x7247;&#x4e0a;&#x4f20;&#x65b9;&#x5f0f;&#x6839;&#x636e;image_type&#x6765;&#x5224;&#x65ad;
     * @param string $imageType - &#x56fe;&#x7247;&#x7c7b;&#x578b; **BASE64**:&#x56fe;&#x7247;&#x7684;base64&#x503c;&#xff0c;base64&#x7f16;&#x7801;&#x540e;&#x7684;&#x56fe;&#x7247;&#x6570;&#x636e;&#xff0c;&#x9700;urlencode&#xff0c;&#x7f16;&#x7801;&#x540e;&#x7684;&#x56fe;&#x7247;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;2M&#xff1b;**URL**:&#x56fe;&#x7247;&#x7684; URL&#x5730;&#x5740;( &#x53ef;&#x80fd;&#x7531;&#x4e8e;&#x7f51;&#x7edc;&#x7b49;&#x539f;&#x56e0;&#x5bfc;&#x81f4;&#x4e0b;&#x8f7d;&#x56fe;&#x7247;&#x65f6;&#x95f4;&#x8fc7;&#x957f;)**&#xff1b;FACE_TOKEN**: &#x4eba;&#x8138;&#x56fe;&#x7247;&#x7684;&#x552f;&#x4e00;&#x6807;&#x8bc6;&#xff0c;&#x8c03;&#x7528;&#x4eba;&#x8138;&#x68c0;&#x6d4b;&#x63a5;&#x53e3;&#x65f6;&#xff0c;&#x4f1a;&#x4e3a;&#x6bcf;&#x4e2a;&#x4eba;&#x8138;&#x56fe;&#x7247;&#x8d4b;&#x4e88;&#x4e00;&#x4e2a;&#x552f;&#x4e00;&#x7684;FACE_TOKEN&#xff0c;&#x540c;&#x4e00;&#x5f20;&#x56fe;&#x7247;&#x591a;&#x6b21;&#x68c0;&#x6d4b;&#x5f97;&#x5230;&#x7684;FACE_TOKEN&#x662f;&#x540c;&#x4e00;&#x4e2a;
     * @param string $groupId - &#x66f4;&#x65b0;&#x6307;&#x5b9a;groupid&#x4e0b;uid&#x5bf9;&#x5e94;&#x7684;&#x4fe1;&#x606f;
     * @param string $userId - &#x7528;&#x6237;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   user_info &#x7528;&#x6237;&#x8d44;&#x6599;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;256B
     *   quality_control &#x56fe;&#x7247;&#x8d28;&#x91cf;&#x63a7;&#x5236;  **NONE**: &#x4e0d;&#x8fdb;&#x884c;&#x63a7;&#x5236; **LOW**:&#x8f83;&#x4f4e;&#x7684;&#x8d28;&#x91cf;&#x8981;&#x6c42; **NORMAL**: &#x4e00;&#x822c;&#x7684;&#x8d28;&#x91cf;&#x8981;&#x6c42; **HIGH**: &#x8f83;&#x9ad8;&#x7684;&#x8d28;&#x91cf;&#x8981;&#x6c42; **&#x9ed8;&#x8ba4; NONE**
     *   liveness_control &#x6d3b;&#x4f53;&#x68c0;&#x6d4b;&#x63a7;&#x5236;  **NONE**: &#x4e0d;&#x8fdb;&#x884c;&#x63a7;&#x5236; **LOW**:&#x8f83;&#x4f4e;&#x7684;&#x6d3b;&#x4f53;&#x8981;&#x6c42;(&#x9ad8;&#x901a;&#x8fc7;&#x7387; &#x4f4e;&#x653b;&#x51fb;&#x62d2;&#x7edd;&#x7387;) **NORMAL**: &#x4e00;&#x822c;&#x7684;&#x6d3b;&#x4f53;&#x8981;&#x6c42;(&#x5e73;&#x8861;&#x7684;&#x653b;&#x51fb;&#x62d2;&#x7edd;&#x7387;, &#x901a;&#x8fc7;&#x7387;) **HIGH**: &#x8f83;&#x9ad8;&#x7684;&#x6d3b;&#x4f53;&#x8981;&#x6c42;(&#x9ad8;&#x653b;&#x51fb;&#x62d2;&#x7edd;&#x7387; &#x4f4e;&#x901a;&#x8fc7;&#x7387;) **&#x9ed8;&#x8ba4;NONE**
     * @return array
     */
    public function updateUser($image, $imageType, $groupId, $userId, $options=array()){

        $data = array();
        
        $data['image'] = $image;
        $data['image_type'] = $imageType;
        $data['group_id'] = $groupId;
        $data['user_id'] = $userId;

        $data = array_merge($data, $options);
        return $this->request($this->userUpdateUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x4eba;&#x8138;&#x5220;&#x9664;&#x63a5;&#x53e3;
     *
     * @param string $userId - &#x7528;&#x6237;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param string $groupId - &#x7528;&#x6237;&#x7ec4;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param string $faceToken - &#x9700;&#x8981;&#x5220;&#x9664;&#x7684;&#x4eba;&#x8138;&#x56fe;&#x7247;token&#xff0c;&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#x957f;&#x5ea6;&#x9650;&#x5236;64B
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function faceDelete($userId, $groupId, $faceToken, $options=array()){

        $data = array();
        
        $data['user_id'] = $userId;
        $data['group_id'] = $groupId;
        $data['face_token'] = $faceToken;

        $data = array_merge($data, $options);
        return $this->request($this->faceDeleteUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x7528;&#x6237;&#x4fe1;&#x606f;&#x67e5;&#x8be2;&#x63a5;&#x53e3;
     *
     * @param string $userId - &#x7528;&#x6237;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param string $groupId - &#x7528;&#x6237;&#x7ec4;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function getUser($userId, $groupId, $options=array()){

        $data = array();
        
        $data['user_id'] = $userId;
        $data['group_id'] = $groupId;

        $data = array_merge($data, $options);
        return $this->request($this->userGetUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x83b7;&#x53d6;&#x7528;&#x6237;&#x4eba;&#x8138;&#x5217;&#x8868;&#x63a5;&#x53e3;
     *
     * @param string $userId - &#x7528;&#x6237;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param string $groupId - &#x7528;&#x6237;&#x7ec4;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function faceGetlist($userId, $groupId, $options=array()){

        $data = array();
        
        $data['user_id'] = $userId;
        $data['group_id'] = $groupId;

        $data = array_merge($data, $options);
        return $this->request($this->faceGetlistUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x83b7;&#x53d6;&#x7528;&#x6237;&#x5217;&#x8868;&#x63a5;&#x53e3;
     *
     * @param string $groupId - &#x7528;&#x6237;&#x7ec4;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   start &#x9ed8;&#x8ba4;&#x503c;0&#xff0c;&#x8d77;&#x59cb;&#x5e8f;&#x53f7;
     *   length &#x8fd4;&#x56de;&#x6570;&#x91cf;&#xff0c;&#x9ed8;&#x8ba4;&#x503c;100&#xff0c;&#x6700;&#x5927;&#x503c;1000
     * @return array
     */
    public function getGroupUsers($groupId, $options=array()){

        $data = array();
        
        $data['group_id'] = $groupId;

        $data = array_merge($data, $options);
        return $this->request($this->groupGetusersUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x590d;&#x5236;&#x7528;&#x6237;&#x63a5;&#x53e3;
     *
     * @param string $userId - &#x7528;&#x6237;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   src_group_id &#x4ece;&#x6307;&#x5b9a;&#x7ec4;&#x91cc;&#x590d;&#x5236;&#x4fe1;&#x606f;
     *   dst_group_id &#x9700;&#x8981;&#x6dfb;&#x52a0;&#x7528;&#x6237;&#x7684;&#x7ec4;id
     * @return array
     */
    public function userCopy($userId, $options=array()){

        $data = array();
        
        $data['user_id'] = $userId;

        $data = array_merge($data, $options);
        return $this->request($this->userCopyUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x5220;&#x9664;&#x7528;&#x6237;&#x63a5;&#x53e3;
     *
     * @param string $groupId - &#x7528;&#x6237;&#x7ec4;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param string $userId - &#x7528;&#x6237;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function deleteUser($groupId, $userId, $options=array()){

        $data = array();
        
        $data['group_id'] = $groupId;
        $data['user_id'] = $userId;

        $data = array_merge($data, $options);
        return $this->request($this->userDeleteUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x521b;&#x5efa;&#x7528;&#x6237;&#x7ec4;&#x63a5;&#x53e3;
     *
     * @param string $groupId - &#x7528;&#x6237;&#x7ec4;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function groupAdd($groupId, $options=array()){

        $data = array();
        
        $data['group_id'] = $groupId;

        $data = array_merge($data, $options);
        return $this->request($this->groupAddUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x5220;&#x9664;&#x7528;&#x6237;&#x7ec4;&#x63a5;&#x53e3;
     *
     * @param string $groupId - &#x7528;&#x6237;&#x7ec4;id&#xff08;&#x7531;&#x6570;&#x5b57;&#x3001;&#x5b57;&#x6bcd;&#x3001;&#x4e0b;&#x5212;&#x7ebf;&#x7ec4;&#x6210;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x9650;&#x5236;128B
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function groupDelete($groupId, $options=array()){

        $data = array();
        
        $data['group_id'] = $groupId;

        $data = array_merge($data, $options);
        return $this->request($this->groupDeleteUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x7ec4;&#x5217;&#x8868;&#x67e5;&#x8be2;&#x63a5;&#x53e3;
     *
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   start &#x9ed8;&#x8ba4;&#x503c;0&#xff0c;&#x8d77;&#x59cb;&#x5e8f;&#x53f7;
     *   length &#x8fd4;&#x56de;&#x6570;&#x91cf;&#xff0c;&#x9ed8;&#x8ba4;&#x503c;100&#xff0c;&#x6700;&#x5927;&#x503c;1000
     * @return array
     */
    public function getGroupList($options=array()){

        $data = array();
        

        $data = array_merge($data, $options);
        return $this->request($this->groupGetlistUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x8eab;&#x4efd;&#x9a8c;&#x8bc1;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x7247;&#x4fe1;&#x606f;(**&#x603b;&#x6570;&#x636e;&#x5927;&#x5c0f;&#x5e94;&#x5c0f;&#x4e8e;10M**)&#xff0c;&#x56fe;&#x7247;&#x4e0a;&#x4f20;&#x65b9;&#x5f0f;&#x6839;&#x636e;image_type&#x6765;&#x5224;&#x65ad;
     * @param string $imageType - &#x56fe;&#x7247;&#x7c7b;&#x578b; **BASE64**:&#x56fe;&#x7247;&#x7684;base64&#x503c;&#xff0c;base64&#x7f16;&#x7801;&#x540e;&#x7684;&#x56fe;&#x7247;&#x6570;&#x636e;&#xff0c;&#x9700;urlencode&#xff0c;&#x7f16;&#x7801;&#x540e;&#x7684;&#x56fe;&#x7247;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;2M&#xff1b;**URL**:&#x56fe;&#x7247;&#x7684; URL&#x5730;&#x5740;( &#x53ef;&#x80fd;&#x7531;&#x4e8e;&#x7f51;&#x7edc;&#x7b49;&#x539f;&#x56e0;&#x5bfc;&#x81f4;&#x4e0b;&#x8f7d;&#x56fe;&#x7247;&#x65f6;&#x95f4;&#x8fc7;&#x957f;)**&#xff1b;FACE_TOKEN**: &#x4eba;&#x8138;&#x56fe;&#x7247;&#x7684;&#x552f;&#x4e00;&#x6807;&#x8bc6;&#xff0c;&#x8c03;&#x7528;&#x4eba;&#x8138;&#x68c0;&#x6d4b;&#x63a5;&#x53e3;&#x65f6;&#xff0c;&#x4f1a;&#x4e3a;&#x6bcf;&#x4e2a;&#x4eba;&#x8138;&#x56fe;&#x7247;&#x8d4b;&#x4e88;&#x4e00;&#x4e2a;&#x552f;&#x4e00;&#x7684;FACE_TOKEN&#xff0c;&#x540c;&#x4e00;&#x5f20;&#x56fe;&#x7247;&#x591a;&#x6b21;&#x68c0;&#x6d4b;&#x5f97;&#x5230;&#x7684;FACE_TOKEN&#x662f;&#x540c;&#x4e00;&#x4e2a;
     * @param string $idCardNumber - &#x8eab;&#x4efd;&#x8bc1;&#x53f7;&#xff08;&#x771f;&#x5b9e;&#x8eab;&#x4efd;&#x8bc1;&#x53f7;&#x53f7;&#x7801;&#xff09;
     * @param string $name - utf8&#xff0c;&#x59d3;&#x540d;&#xff08;&#x771f;&#x5b9e;&#x59d3;&#x540d;&#xff0c;&#x548c;&#x8eab;&#x4efd;&#x8bc1;&#x53f7;&#x5339;&#x914d;&#xff09;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   quality_control &#x56fe;&#x7247;&#x8d28;&#x91cf;&#x63a7;&#x5236;  **NONE**: &#x4e0d;&#x8fdb;&#x884c;&#x63a7;&#x5236; **LOW**:&#x8f83;&#x4f4e;&#x7684;&#x8d28;&#x91cf;&#x8981;&#x6c42; **NORMAL**: &#x4e00;&#x822c;&#x7684;&#x8d28;&#x91cf;&#x8981;&#x6c42; **HIGH**: &#x8f83;&#x9ad8;&#x7684;&#x8d28;&#x91cf;&#x8981;&#x6c42; **&#x9ed8;&#x8ba4; NONE**
     *   liveness_control &#x6d3b;&#x4f53;&#x68c0;&#x6d4b;&#x63a7;&#x5236;  **NONE**: &#x4e0d;&#x8fdb;&#x884c;&#x63a7;&#x5236; **LOW**:&#x8f83;&#x4f4e;&#x7684;&#x6d3b;&#x4f53;&#x8981;&#x6c42;(&#x9ad8;&#x901a;&#x8fc7;&#x7387; &#x4f4e;&#x653b;&#x51fb;&#x62d2;&#x7edd;&#x7387;) **NORMAL**: &#x4e00;&#x822c;&#x7684;&#x6d3b;&#x4f53;&#x8981;&#x6c42;(&#x5e73;&#x8861;&#x7684;&#x653b;&#x51fb;&#x62d2;&#x7edd;&#x7387;, &#x901a;&#x8fc7;&#x7387;) **HIGH**: &#x8f83;&#x9ad8;&#x7684;&#x6d3b;&#x4f53;&#x8981;&#x6c42;(&#x9ad8;&#x653b;&#x51fb;&#x62d2;&#x7edd;&#x7387; &#x4f4e;&#x901a;&#x8fc7;&#x7387;) **&#x9ed8;&#x8ba4;NONE**
     * @return array
     */
    public function personVerify($image, $imageType, $idCardNumber, $name, $options=array()){

        $data = array();
        
        $data['image'] = $image;
        $data['image_type'] = $imageType;
        $data['id_card_number'] = $idCardNumber;
        $data['name'] = $name;

        $data = array_merge($data, $options);
        return $this->request($this->personVerifyUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x8bed;&#x97f3;&#x6821;&#x9a8c;&#x7801;&#x63a5;&#x53e3;&#x63a5;&#x53e3;
     *
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   appid &#x767e;&#x5ea6;&#x4e91;&#x521b;&#x5efa;&#x5e94;&#x7528;&#x65f6;&#x7684;&#x552f;&#x4e00;&#x6807;&#x8bc6;ID
     * @return array
     */
    public function videoSessioncode($options=array()){

        $data = array();
        

        $data = array_merge($data, $options);
        return $this->request($this->videoSessioncodeUrl, json_encode($data),  array(
            'Content-Type' => 'application/json',
        ));
    }
    /**
     * &#x5728;&#x7ebf;&#x6d3b;&#x4f53;&#x68c0;&#x6d4b; faceverify api url
     * @var string
     */
    private $faceverifyUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/faceverify';

    /**
     * &#x5728;&#x7ebf;&#x6d3b;&#x4f53;&#x68c0;&#x6d4b;&#x63a5;&#x53e3;
     *
     * @param array $images
     * @return array
     */
    public function faceverify($images){

        return $this->request($this->faceverifyUrl, json_encode($images), array(
            'Content-Type' => 'application/json',
        ));
    }

    /**
     * &#x4eba;&#x8138;&#x6bd4;&#x5bf9; match api url
     * @var string
     */
    private $matchUrl = 'https://aip.baidubce.com/rest/2.0/face/v3/match';

    /**
     * &#x4eba;&#x8138;&#x6bd4;&#x5bf9;&#x63a5;&#x53e3;
     *
     * @param array $images
     * @return array
     */
    public function match($images){

        return $this->request($this->matchUrl, json_encode($images), array(
            'Content-Type' => 'application/json',
        ));
    }

}