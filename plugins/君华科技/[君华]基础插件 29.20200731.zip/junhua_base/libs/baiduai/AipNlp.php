<?php
/*
* Copyright (c) 2017 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License. You may obtain a copy of
* the License at
*
* Http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/

require_once 'lib/AipBase.php';
class AipNlp extends AipBase {

    /**
     * &#x8bcd;&#x6cd5;&#x5206;&#x6790; lexer api url
     * @var string
     */
    private $lexerUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v1/lexer';

    /**
     * &#x8bcd;&#x6cd5;&#x5206;&#x6790;&#xff08;&#x5b9a;&#x5236;&#x7248;&#xff09; lexer_custom api url
     * @var string
     */
    private $lexerCustomUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v1/lexer_custom';

    /**
     * &#x4f9d;&#x5b58;&#x53e5;&#x6cd5;&#x5206;&#x6790; dep_parser api url
     * @var string
     */
    private $depParserUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v1/depparser';

    /**
     * &#x8bcd;&#x5411;&#x91cf;&#x8868;&#x793a; word_embedding api url
     * @var string
     */
    private $wordEmbeddingUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v2/word_emb_vec';

    /**
     * DNN&#x8bed;&#x8a00;&#x6a21;&#x578b; dnnlm_cn api url
     * @var string
     */
    private $dnnlmCnUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v2/dnnlm_cn';

    /**
     * &#x8bcd;&#x4e49;&#x76f8;&#x4f3c;&#x5ea6; word_sim_embedding api url
     * @var string
     */
    private $wordSimEmbeddingUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v2/word_emb_sim';

    /**
     * &#x77ed;&#x6587;&#x672c;&#x76f8;&#x4f3c;&#x5ea6; simnet api url
     * @var string
     */
    private $simnetUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v2/simnet';

    /**
     * &#x8bc4;&#x8bba;&#x89c2;&#x70b9;&#x62bd;&#x53d6; comment_tag api url
     * @var string
     */
    private $commentTagUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v2/comment_tag';

    /**
     * &#x60c5;&#x611f;&#x503e;&#x5411;&#x5206;&#x6790; sentiment_classify api url
     * @var string
     */
    private $sentimentClassifyUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v1/sentiment_classify';

    /**
     * &#x6587;&#x7ae0;&#x6807;&#x7b7e; keyword api url
     * @var string
     */
    private $keywordUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v1/keyword';

    /**
     * &#x6587;&#x7ae0;&#x5206;&#x7c7b; topic api url
     * @var string
     */
    private $topicUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v1/topic';

    /**
     * &#x6587;&#x672c;&#x7ea0;&#x9519; ecnet api url
     * @var string
     */
    private $ecnetUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v1/ecnet';

    /**
     * &#x5bf9;&#x8bdd;&#x60c5;&#x7eea;&#x8bc6;&#x522b;&#x63a5;&#x53e3; emotion api url
     * @var string
     */
    private $emotionUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v1/emotion';

    /**
     * &#x65b0;&#x95fb;&#x6458;&#x8981;&#x63a5;&#x53e3; news_summary api url
     * @var string
     */
    private $newsSummaryUrl = 'https://aip.baidubce.com/rpc/2.0/nlp/v1/news_summary';

    /**
     * &#x683c;&#x5f0f;&#x5316;&#x7ed3;&#x679c;
     * @param $content string
     * @return mixed
     */
    protected function proccessResult($content){
        return json_decode(mb_convert_encoding($content, 'UTF8', 'GBK'), true, 512, JSON_BIGINT_AS_STRING);
    }

    /**
     * &#x8bcd;&#x6cd5;&#x5206;&#x6790;&#x63a5;&#x53e3;
     *
     * @param string $text - &#x5f85;&#x5206;&#x6790;&#x6587;&#x672c;&#xff08;&#x76ee;&#x524d;&#x4ec5;&#x652f;&#x6301;GBK&#x7f16;&#x7801;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;65536&#x5b57;&#x8282;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function lexer($text, $options=array()){

        $data = array();
        
        $data['text'] = $text;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->lexerUrl, $data);
    }

    /**
     * &#x8bcd;&#x6cd5;&#x5206;&#x6790;&#xff08;&#x5b9a;&#x5236;&#x7248;&#xff09;&#x63a5;&#x53e3;
     *
     * @param string $text - &#x5f85;&#x5206;&#x6790;&#x6587;&#x672c;&#xff08;&#x76ee;&#x524d;&#x4ec5;&#x652f;&#x6301;GBK&#x7f16;&#x7801;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;65536&#x5b57;&#x8282;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function lexerCustom($text, $options=array()){

        $data = array();
        
        $data['text'] = $text;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->lexerCustomUrl, $data);
    }

    /**
     * &#x4f9d;&#x5b58;&#x53e5;&#x6cd5;&#x5206;&#x6790;&#x63a5;&#x53e3;
     *
     * @param string $text - &#x5f85;&#x5206;&#x6790;&#x6587;&#x672c;&#xff08;&#x76ee;&#x524d;&#x4ec5;&#x652f;&#x6301;GBK&#x7f16;&#x7801;&#xff09;&#xff0c;&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;256&#x5b57;&#x8282;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   mode &#x6a21;&#x578b;&#x9009;&#x62e9;&#x3002;&#x9ed8;&#x8ba4;&#x503c;&#x4e3a;0&#xff0c;&#x53ef;&#x9009;&#x503c;mode=0&#xff08;&#x5bf9;&#x5e94;web&#x6a21;&#x578b;&#xff09;&#xff1b;mode=1&#xff08;&#x5bf9;&#x5e94;query&#x6a21;&#x578b;&#xff09;
     * @return array
     */
    public function depParser($text, $options=array()){

        $data = array();
        
        $data['text'] = $text;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->depParserUrl, $data);
    }

    /**
     * &#x8bcd;&#x5411;&#x91cf;&#x8868;&#x793a;&#x63a5;&#x53e3;
     *
     * @param string $word - &#x6587;&#x672c;&#x5185;&#x5bb9;&#xff08;GBK&#x7f16;&#x7801;&#xff09;&#xff0c;&#x6700;&#x5927;64&#x5b57;&#x8282;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function wordEmbedding($word, $options=array()){

        $data = array();
        
        $data['word'] = $word;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->wordEmbeddingUrl, $data);
    }

    /**
     * DNN&#x8bed;&#x8a00;&#x6a21;&#x578b;&#x63a5;&#x53e3;
     *
     * @param string $text - &#x6587;&#x672c;&#x5185;&#x5bb9;&#xff08;GBK&#x7f16;&#x7801;&#xff09;&#xff0c;&#x6700;&#x5927;512&#x5b57;&#x8282;&#xff0c;&#x4e0d;&#x9700;&#x8981;&#x5207;&#x8bcd;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function dnnlm($text, $options=array()){

        $data = array();
        
        $data['text'] = $text;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->dnnlmCnUrl, $data);
    }

    /**
     * &#x8bcd;&#x4e49;&#x76f8;&#x4f3c;&#x5ea6;&#x63a5;&#x53e3;
     *
     * @param string $word1 - &#x8bcd;1&#xff08;GBK&#x7f16;&#x7801;&#xff09;&#xff0c;&#x6700;&#x5927;64&#x5b57;&#x8282;
     * @param string $word2 - &#x8bcd;1&#xff08;GBK&#x7f16;&#x7801;&#xff09;&#xff0c;&#x6700;&#x5927;64&#x5b57;&#x8282;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   mode &#x9884;&#x7559;&#x5b57;&#x6bb5;&#xff0c;&#x53ef;&#x9009;&#x62e9;&#x4e0d;&#x540c;&#x7684;&#x8bcd;&#x4e49;&#x76f8;&#x4f3c;&#x5ea6;&#x6a21;&#x578b;&#x3002;&#x9ed8;&#x8ba4;&#x503c;&#x4e3a;0&#xff0c;&#x76ee;&#x524d;&#x4ec5;&#x652f;&#x6301;mode=0
     * @return array
     */
    public function wordSimEmbedding($word1, $word2, $options=array()){

        $data = array();
        
        $data['word_1'] = $word1;
        $data['word_2'] = $word2;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->wordSimEmbeddingUrl, $data);
    }

    /**
     * &#x77ed;&#x6587;&#x672c;&#x76f8;&#x4f3c;&#x5ea6;&#x63a5;&#x53e3;
     *
     * @param string $text1 - &#x5f85;&#x6bd4;&#x8f83;&#x6587;&#x672c;1&#xff08;GBK&#x7f16;&#x7801;&#xff09;&#xff0c;&#x6700;&#x5927;512&#x5b57;&#x8282;
     * @param string $text2 - &#x5f85;&#x6bd4;&#x8f83;&#x6587;&#x672c;2&#xff08;GBK&#x7f16;&#x7801;&#xff09;&#xff0c;&#x6700;&#x5927;512&#x5b57;&#x8282;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   model &#x9ed8;&#x8ba4;&#x4e3a;"BOW"&#xff0c;&#x53ef;&#x9009;"BOW"&#x3001;"CNN"&#x4e0e;"GRNN"
     * @return array
     */
    public function simnet($text1, $text2, $options=array()){

        $data = array();
        
        $data['text_1'] = $text1;
        $data['text_2'] = $text2;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->simnetUrl, $data);
    }

    /**
     * &#x8bc4;&#x8bba;&#x89c2;&#x70b9;&#x62bd;&#x53d6;&#x63a5;&#x53e3;
     *
     * @param string $text - &#x8bc4;&#x8bba;&#x5185;&#x5bb9;&#xff08;GBK&#x7f16;&#x7801;&#xff09;&#xff0c;&#x6700;&#x5927;10240&#x5b57;&#x8282;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   type &#x8bc4;&#x8bba;&#x884c;&#x4e1a;&#x7c7b;&#x578b;&#xff0c;&#x9ed8;&#x8ba4;&#x4e3a;4&#xff08;&#x9910;&#x996e;&#x7f8e;&#x98df;&#xff09;
     * @return array
     */
    public function commentTag($text, $options=array()){

        $data = array();
        
        $data['text'] = $text;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->commentTagUrl, $data);
    }

    /**
     * &#x60c5;&#x611f;&#x503e;&#x5411;&#x5206;&#x6790;&#x63a5;&#x53e3;
     *
     * @param string $text - &#x6587;&#x672c;&#x5185;&#x5bb9;&#xff08;GBK&#x7f16;&#x7801;&#xff09;&#xff0c;&#x6700;&#x5927;102400&#x5b57;&#x8282;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function sentimentClassify($text, $options=array()){

        $data = array();
        
        $data['text'] = $text;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->sentimentClassifyUrl, $data);
    }

    /**
     * &#x6587;&#x7ae0;&#x6807;&#x7b7e;&#x63a5;&#x53e3;
     *
     * @param string $title - &#x7bc7;&#x7ae0;&#x7684;&#x6807;&#x9898;&#xff0c;&#x6700;&#x5927;80&#x5b57;&#x8282;
     * @param string $content - &#x7bc7;&#x7ae0;&#x7684;&#x6b63;&#x6587;&#xff0c;&#x6700;&#x5927;65535&#x5b57;&#x8282;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function keyword($title, $content, $options=array()){

        $data = array();
        
        $data['title'] = $title;
        $data['content'] = $content;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->keywordUrl, $data);
    }

    /**
     * &#x6587;&#x7ae0;&#x5206;&#x7c7b;&#x63a5;&#x53e3;
     *
     * @param string $title - &#x7bc7;&#x7ae0;&#x7684;&#x6807;&#x9898;&#xff0c;&#x6700;&#x5927;80&#x5b57;&#x8282;
     * @param string $content - &#x7bc7;&#x7ae0;&#x7684;&#x6b63;&#x6587;&#xff0c;&#x6700;&#x5927;65535&#x5b57;&#x8282;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function topic($title, $content, $options=array()){

        $data = array();
        
        $data['title'] = $title;
        $data['content'] = $content;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->topicUrl, $data);
    }

    /**
     * &#x6587;&#x672c;&#x7ea0;&#x9519;&#x63a5;&#x53e3;
     *
     * @param string $text - &#x5f85;&#x7ea0;&#x9519;&#x6587;&#x672c;&#xff0c;&#x8f93;&#x5165;&#x9650;&#x5236;511&#x5b57;&#x8282;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function ecnet($text, $options=array()){

        $data = array();
        
        $data['text'] = $text;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->ecnetUrl, $data);
    }

    /**
     * &#x5bf9;&#x8bdd;&#x60c5;&#x7eea;&#x8bc6;&#x522b;&#x63a5;&#x53e3;&#x63a5;&#x53e3;
     *
     * @param string $text - &#x5f85;&#x8bc6;&#x522b;&#x60c5;&#x611f;&#x6587;&#x672c;&#xff0c;&#x8f93;&#x5165;&#x9650;&#x5236;512&#x5b57;&#x8282;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   scene default&#xff08;&#x9ed8;&#x8ba4;&#x9879;-&#x4e0d;&#x533a;&#x5206;&#x573a;&#x666f;&#xff09;&#xff0c;talk&#xff08;&#x95f2;&#x804a;&#x5bf9;&#x8bdd;-&#x5982;&#x5ea6;&#x79d8;&#x804a;&#x5929;&#x7b49;&#xff09;&#xff0c;task&#xff08;&#x4efb;&#x52a1;&#x578b;&#x5bf9;&#x8bdd;-&#x5982;&#x5bfc;&#x822a;&#x5bf9;&#x8bdd;&#x7b49;&#xff09;&#xff0c;customer_service&#xff08;&#x5ba2;&#x670d;&#x5bf9;&#x8bdd;-&#x5982;&#x7535;&#x4fe1;/&#x94f6;&#x884c;&#x5ba2;&#x670d;&#x7b49;&#xff09;
     * @return array
     */
    public function emotion($text, $options=array()){

        $data = array();
        
        $data['text'] = $text;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->emotionUrl, $data);
    }

    /**
     * &#x65b0;&#x95fb;&#x6458;&#x8981;&#x63a5;&#x53e3;&#x63a5;&#x53e3;
     *
     * @param string $content - &#x5b57;&#x7b26;&#x4e32;&#xff08;&#x9650;200&#x5b57;&#x7b26;&#x6570;&#xff09;&#x5b57;&#x7b26;&#x4e32;&#x4ec5;&#x652f;&#x6301;GBK&#x7f16;&#x7801;&#xff0c;&#x957f;&#x5ea6;&#x9700;&#x5c0f;&#x4e8e;200&#x5b57;&#x7b26;&#x6570;&#xff08;&#x5373;400&#x5b57;&#x8282;&#xff09;&#xff0c;&#x8bf7;&#x8f93;&#x5165;&#x524d;&#x786e;&#x8ba4;&#x5b57;&#x7b26;&#x6570;&#x6ca1;&#x6709;&#x8d85;&#x9650;&#xff0c;&#x82e5;&#x5b57;&#x7b26;&#x6570;&#x8d85;&#x957f;&#x4f1a;&#x8fd4;&#x56de;&#x9519;&#x8bef;&#x3002;&#x6807;&#x9898;&#x5728;&#x7b97;&#x6cd5;&#x4e2d;&#x5177;&#x6709;&#x91cd;&#x8981;&#x7684;&#x4f5c;&#x7528;&#xff0c;&#x82e5;&#x6587;&#x7ae0;&#x786e;&#x65e0;&#x6807;&#x9898;&#xff0c;&#x8f93;&#x5165;&#x53c2;&#x6570;&#x7684;&#x201c;&#x6807;&#x9898;&#x201d;&#x5b57;&#x6bb5;&#x4e3a;&#x7a7a;&#x5373;&#x53ef;
     * @param integer $maxSummaryLen - &#x6b64;&#x6570;&#x503c;&#x5c06;&#x4f5c;&#x4e3a;&#x6458;&#x8981;&#x7ed3;&#x679c;&#x7684;&#x6700;&#x5927;&#x957f;&#x5ea6;&#x3002;&#x4f8b;&#x5982;&#xff1a;&#x539f;&#x6587;&#x957f;&#x5ea6;1000&#x5b57;&#xff0c;&#x672c;&#x53c2;&#x6570;&#x8bbe;&#x7f6e;&#x4e3a;150&#xff0c;&#x5219;&#x6458;&#x8981;&#x7ed3;&#x679c;&#x7684;&#x6700;&#x5927;&#x957f;&#x5ea6;&#x662f;150&#x5b57;&#xff1b;&#x63a8;&#x8350;&#x6700;&#x4f18;&#x533a;&#x95f4;&#xff1a;200-500&#x5b57;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   title &#x5b57;&#x7b26;&#x4e32;&#xff08;&#x9650;200&#x5b57;&#x7b26;&#x6570;&#xff09;&#x5b57;&#x7b26;&#x4e32;&#x4ec5;&#x652f;&#x6301;GBK&#x7f16;&#x7801;&#xff0c;&#x957f;&#x5ea6;&#x9700;&#x5c0f;&#x4e8e;200&#x5b57;&#x7b26;&#x6570;&#xff08;&#x5373;400&#x5b57;&#x8282;&#xff09;&#xff0c;&#x8bf7;&#x8f93;&#x5165;&#x524d;&#x786e;&#x8ba4;&#x5b57;&#x7b26;&#x6570;&#x6ca1;&#x6709;&#x8d85;&#x9650;&#xff0c;&#x82e5;&#x5b57;&#x7b26;&#x6570;&#x8d85;&#x957f;&#x4f1a;&#x8fd4;&#x56de;&#x9519;&#x8bef;&#x3002;&#x6807;&#x9898;&#x5728;&#x7b97;&#x6cd5;&#x4e2d;&#x5177;&#x6709;&#x91cd;&#x8981;&#x7684;&#x4f5c;&#x7528;&#xff0c;&#x82e5;&#x6587;&#x7ae0;&#x786e;&#x65e0;&#x6807;&#x9898;&#xff0c;&#x8f93;&#x5165;&#x53c2;&#x6570;&#x7684;&#x201c;&#x6807;&#x9898;&#x201d;&#x5b57;&#x6bb5;&#x4e3a;&#x7a7a;&#x5373;&#x53ef;
     * @return array
     */
    public function newsSummary($content, $maxSummaryLen, $options=array()){

        $data = array();
        
        $data['content'] = $content;
        $data['max_summary_len'] = $maxSummaryLen;

        $data = array_merge($data, $options);
        $data = mb_convert_encoding(json_encode($data), 'GBK', 'UTF8');

        return $this->request($this->newsSummaryUrl, $data);
    }
}