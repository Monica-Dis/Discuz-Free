<?php
/*
* Copyright (c) 2017 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License. You may obtain a copy of
* the License at
*
* Http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/

require_once 'lib/AipBase.php';
class AipKg extends AipBase {

    /**
     * &#x521b;&#x5efa;&#x4efb;&#x52a1; create_task api url
     * @var string
     */
    private $createTaskUrl = 'https://aip.baidubce.com/rest/2.0/kg/v1/pie/task_create';

    /**
     * &#x66f4;&#x65b0;&#x4efb;&#x52a1; update_task api url
     * @var string
     */
    private $updateTaskUrl = 'https://aip.baidubce.com/rest/2.0/kg/v1/pie/task_update';

    /**
     * &#x83b7;&#x53d6;&#x4efb;&#x52a1;&#x8be6;&#x60c5; task_info api url
     * @var string
     */
    private $taskInfoUrl = 'https://aip.baidubce.com/rest/2.0/kg/v1/pie/task_info';

    /**
     * &#x4ee5;&#x5206;&#x9875;&#x7684;&#x65b9;&#x5f0f;&#x67e5;&#x8be2;&#x5f53;&#x524d;&#x7528;&#x6237;&#x6240;&#x6709;&#x7684;&#x4efb;&#x52a1;&#x4fe1;&#x606f; task_query api url
     * @var string
     */
    private $taskQueryUrl = 'https://aip.baidubce.com/rest/2.0/kg/v1/pie/task_query';

    /**
     * &#x542f;&#x52a8;&#x4efb;&#x52a1; task_start api url
     * @var string
     */
    private $taskStartUrl = 'https://aip.baidubce.com/rest/2.0/kg/v1/pie/task_start';

    /**
     * &#x67e5;&#x8be2;&#x4efb;&#x52a1;&#x72b6;&#x6001; task_status api url
     * @var string
     */
    private $taskStatusUrl = 'https://aip.baidubce.com/rest/2.0/kg/v1/pie/task_status';

    

    /**
     * &#x521b;&#x5efa;&#x4efb;&#x52a1;&#x63a5;&#x53e3;
     *
     * @param string $name - &#x4efb;&#x52a1;&#x540d;&#x5b57;
     * @param string $templateContent - json string &#x89e3;&#x6790;&#x6a21;&#x677f;&#x5185;&#x5bb9;
     * @param string $inputMappingFile - &#x6293;&#x53d6;&#x7ed3;&#x679c;&#x6620;&#x5c04;&#x6587;&#x4ef6;&#x7684;&#x8def;&#x5f84;
     * @param string $outputFile - &#x8f93;&#x51fa;&#x6587;&#x4ef6;&#x540d;&#x5b57;
     * @param string $urlPattern - url pattern
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   limit_count &#x9650;&#x5236;&#x89e3;&#x6790;&#x6570;&#x91cf;limit_count&#x4e3a;0&#x65f6;&#x8fdb;&#x884c;&#x5168;&#x91cf;&#x4efb;&#x52a1;&#xff0c;limit_count&gt;0&#x65f6;&#x53ea;&#x89e3;&#x6790;limit_count&#x6570;&#x91cf;&#x7684;&#x9875;&#x9762;
     * @return array
     */
    public function createTask($name, $templateContent, $inputMappingFile, $outputFile, $urlPattern, $options=array()){

        $data = array();
        
        $data['name'] = $name;
        $data['template_content'] = $templateContent;
        $data['input_mapping_file'] = $inputMappingFile;
        $data['output_file'] = $outputFile;
        $data['url_pattern'] = $urlPattern;

        $data = array_merge($data, $options);

        return $this->request($this->createTaskUrl, $data);
    }

    /**
     * &#x66f4;&#x65b0;&#x4efb;&#x52a1;&#x63a5;&#x53e3;
     *
     * @param integer $id - &#x4efb;&#x52a1;ID
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   name &#x4efb;&#x52a1;&#x540d;&#x5b57;
     *   template_content json string &#x89e3;&#x6790;&#x6a21;&#x677f;&#x5185;&#x5bb9;
     *   input_mapping_file &#x6293;&#x53d6;&#x7ed3;&#x679c;&#x6620;&#x5c04;&#x6587;&#x4ef6;&#x7684;&#x8def;&#x5f84;
     *   url_pattern url pattern
     *   output_file &#x8f93;&#x51fa;&#x6587;&#x4ef6;&#x540d;&#x5b57;
     * @return array
     */
    public function updateTask($id, $options=array()){

        $data = array();
        
        $data['id'] = $id;

        $data = array_merge($data, $options);

        return $this->request($this->updateTaskUrl, $data);
    }

    /**
     * &#x83b7;&#x53d6;&#x4efb;&#x52a1;&#x8be6;&#x60c5;&#x63a5;&#x53e3;
     *
     * @param integer $id - &#x4efb;&#x52a1;ID
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function getTaskInfo($id, $options=array()){

        $data = array();
        
        $data['id'] = $id;

        $data = array_merge($data, $options);

        return $this->request($this->taskInfoUrl, $data);
    }

    /**
     * &#x4ee5;&#x5206;&#x9875;&#x7684;&#x65b9;&#x5f0f;&#x67e5;&#x8be2;&#x5f53;&#x524d;&#x7528;&#x6237;&#x6240;&#x6709;&#x7684;&#x4efb;&#x52a1;&#x4fe1;&#x606f;&#x63a5;&#x53e3;
     *
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   id &#x4efb;&#x52a1;ID&#xff0c;&#x7cbe;&#x786e;&#x5339;&#x914d;
     *   name &#x4e2d;&#x7f00;&#x6a21;&#x7cca;&#x5339;&#x914d;,abc&#x53ef;&#x4ee5;&#x5339;&#x914d;abc,aaabc,abcde&#x7b49;
     *   status &#x8981;&#x7b5b;&#x9009;&#x7684;&#x4efb;&#x52a1;&#x72b6;&#x6001;
     *   page &#x9875;&#x7801;
     *   per_page &#x9875;&#x7801;
     * @return array
     */
    public function getUserTasks($options=array()){

        $data = array();
        

        $data = array_merge($data, $options);

        return $this->request($this->taskQueryUrl, $data);
    }

    /**
     * &#x542f;&#x52a8;&#x4efb;&#x52a1;&#x63a5;&#x53e3;
     *
     * @param integer $id - &#x4efb;&#x52a1;ID
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function startTask($id, $options=array()){

        $data = array();
        
        $data['id'] = $id;

        $data = array_merge($data, $options);

        return $this->request($this->taskStartUrl, $data);
    }

    /**
     * &#x67e5;&#x8be2;&#x4efb;&#x52a1;&#x72b6;&#x6001;&#x63a5;&#x53e3;
     *
     * @param integer $id - &#x4efb;&#x52a1;ID
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function getTaskStatus($id, $options=array()){

        $data = array();
        
        $data['id'] = $id;

        $data = array_merge($data, $options);

        return $this->request($this->taskStatusUrl, $data);
    }
}