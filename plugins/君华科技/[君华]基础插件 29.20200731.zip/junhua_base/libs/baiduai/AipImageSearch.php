<?php
/*
* Copyright (c) 2017 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License. You may obtain a copy of
* the License at
*
* Http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/

require_once 'lib/AipBase.php';
class AipImageSearch extends AipBase {

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5165;&#x5e93; same_hq_add api url
     * @var string
     */
    private $sameHqAddUrl = 'https://aip.baidubce.com/rest/2.0/realtime_search/same_hq/add';

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x68c0;&#x7d22; same_hq_search api url
     * @var string
     */
    private $sameHqSearchUrl = 'https://aip.baidubce.com/rest/2.0/realtime_search/same_hq/search';

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x66f4;&#x65b0; same_hq_update api url
     * @var string
     */
    private $sameHqUpdateUrl = 'https://aip.baidubce.com/rest/2.0/realtime_search/same_hq/update';

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5220;&#x9664; same_hq_delete api url
     * @var string
     */
    private $sameHqDeleteUrl = 'https://aip.baidubce.com/rest/2.0/realtime_search/same_hq/delete';

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5165;&#x5e93; similar_add api url
     * @var string
     */
    private $similarAddUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/similar/add';

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x68c0;&#x7d22; similar_search api url
     * @var string
     */
    private $similarSearchUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/similar/search';

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x66f4;&#x65b0; similar_update api url
     * @var string
     */
    private $similarUpdateUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/similar/update';

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5220;&#x9664; similar_delete api url
     * @var string
     */
    private $similarDeleteUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/similar/delete';

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x5165;&#x5e93; product_add api url
     * @var string
     */
    private $productAddUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/product/add';

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x68c0;&#x7d22; product_search api url
     * @var string
     */
    private $productSearchUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/product/search';

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x66f4;&#x65b0; product_update api url
     * @var string
     */
    private $productUpdateUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/product/update';

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x5220;&#x9664; product_delete api url
     * @var string
     */
    private $productDeleteUrl = 'https://aip.baidubce.com/rest/2.0/image-classify/v1/realtime_search/product/delete';

    

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5165;&#x5e93;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   brief &#x68c0;&#x7d22;&#x65f6;&#x539f;&#x6837;&#x5e26;&#x56de;,&#x6700;&#x957f;256B&#x3002;
     *   tags 1 - 65535&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#xff0c;tag&#x95f4;&#x4ee5;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x6700;&#x591a;2&#x4e2a;tag&#x3002;&#x6837;&#x4f8b;&#xff1a;"100,11" &#xff1b;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     * @return array
     */
    public function sameHqAdd($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->sameHqAddUrl, $data);
    }

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5165;&#x5e93;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   brief &#x68c0;&#x7d22;&#x65f6;&#x539f;&#x6837;&#x5e26;&#x56de;,&#x6700;&#x957f;256B&#x3002;
     *   tags 1 - 65535&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#xff0c;tag&#x95f4;&#x4ee5;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x6700;&#x591a;2&#x4e2a;tag&#x3002;&#x6837;&#x4f8b;&#xff1a;"100,11" &#xff1b;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     * @return array
     */
    public function sameHqAddUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->sameHqAddUrl, $data);
    }

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x68c0;&#x7d22;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   tags 1 - 65535&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#xff0c;tag&#x95f4;&#x4ee5;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x6700;&#x591a;2&#x4e2a;tag&#x3002;&#x6837;&#x4f8b;&#xff1a;"100,11" &#xff1b;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     *   tag_logic &#x68c0;&#x7d22;&#x65f6;tag&#x4e4b;&#x95f4;&#x7684;&#x903b;&#x8f91;&#xff0c; 0&#xff1a;&#x903b;&#x8f91;and&#xff0c;1&#xff1a;&#x903b;&#x8f91;or
     *   pn &#x5206;&#x9875;&#x529f;&#x80fd;&#xff0c;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;&#xff0c;&#x4f8b;&#xff1a;0&#x3002;&#x672a;&#x6307;&#x5b9a;&#x5206;&#x9875;&#x65f6;&#xff0c;&#x9ed8;&#x8ba4;&#x8fd4;&#x56de;&#x524d;300&#x4e2a;&#x7ed3;&#x679c;&#xff1b;&#x63a5;&#x53e3;&#x8fd4;&#x56de;&#x6570;&#x91cf;&#x6700;&#x5927;&#x9650;&#x5236;1000&#x6761;&#xff0c;&#x4f8b;&#x5982;&#xff1a;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;&#x4e3a;900&#xff0c;&#x622a;&#x53d6;&#x6761;&#x6570;500&#x6761;&#xff0c;&#x63a5;&#x53e3;&#x4e5f;&#x53ea;&#x8fd4;&#x56de;&#x7b2c;900 - 1000&#x6761;&#x7684;&#x7ed3;&#x679c;&#xff0c;&#x5171;&#x8ba1;100&#x6761;
     *   rn &#x5206;&#x9875;&#x529f;&#x80fd;&#xff0c;&#x622a;&#x53d6;&#x6761;&#x6570;&#xff0c;&#x4f8b;&#xff1a;250
     * @return array
     */
    public function sameHqSearch($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->sameHqSearchUrl, $data);
    }

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x68c0;&#x7d22;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   tags 1 - 65535&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#xff0c;tag&#x95f4;&#x4ee5;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x6700;&#x591a;2&#x4e2a;tag&#x3002;&#x6837;&#x4f8b;&#xff1a;"100,11" &#xff1b;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     *   tag_logic &#x68c0;&#x7d22;&#x65f6;tag&#x4e4b;&#x95f4;&#x7684;&#x903b;&#x8f91;&#xff0c; 0&#xff1a;&#x903b;&#x8f91;and&#xff0c;1&#xff1a;&#x903b;&#x8f91;or
     *   pn &#x5206;&#x9875;&#x529f;&#x80fd;&#xff0c;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;&#xff0c;&#x4f8b;&#xff1a;0&#x3002;&#x672a;&#x6307;&#x5b9a;&#x5206;&#x9875;&#x65f6;&#xff0c;&#x9ed8;&#x8ba4;&#x8fd4;&#x56de;&#x524d;300&#x4e2a;&#x7ed3;&#x679c;&#xff1b;&#x63a5;&#x53e3;&#x8fd4;&#x56de;&#x6570;&#x91cf;&#x6700;&#x5927;&#x9650;&#x5236;1000&#x6761;&#xff0c;&#x4f8b;&#x5982;&#xff1a;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;&#x4e3a;900&#xff0c;&#x622a;&#x53d6;&#x6761;&#x6570;500&#x6761;&#xff0c;&#x63a5;&#x53e3;&#x4e5f;&#x53ea;&#x8fd4;&#x56de;&#x7b2c;900 - 1000&#x6761;&#x7684;&#x7ed3;&#x679c;&#xff0c;&#x5171;&#x8ba1;100&#x6761;
     *   rn &#x5206;&#x9875;&#x529f;&#x80fd;&#xff0c;&#x622a;&#x53d6;&#x6761;&#x6570;&#xff0c;&#x4f8b;&#xff1a;250
     * @return array
     */
    public function sameHqSearchUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->sameHqSearchUrl, $data);
    }

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x66f4;&#x65b0;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   brief &#x66f4;&#x65b0;&#x7684;&#x6458;&#x8981;&#x4fe1;&#x606f;&#xff0c;&#x6700;&#x957f;256B&#x3002;&#x6837;&#x4f8b;&#xff1a;{"name":"&#x5468;&#x6770;&#x4f26;", "id":"666"}
     *   tags 1 - 65535&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#xff0c;tag&#x95f4;&#x4ee5;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x6700;&#x591a;2&#x4e2a;tag&#x3002;&#x6837;&#x4f8b;&#xff1a;"100,11" &#xff1b;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     * @return array
     */
    public function sameHqUpdate($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->sameHqUpdateUrl, $data);
    }

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x66f4;&#x65b0;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   brief &#x66f4;&#x65b0;&#x7684;&#x6458;&#x8981;&#x4fe1;&#x606f;&#xff0c;&#x6700;&#x957f;256B&#x3002;&#x6837;&#x4f8b;&#xff1a;{"name":"&#x5468;&#x6770;&#x4f26;", "id":"666"}
     *   tags 1 - 65535&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#xff0c;tag&#x95f4;&#x4ee5;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x6700;&#x591a;2&#x4e2a;tag&#x3002;&#x6837;&#x4f8b;&#xff1a;"100,11" &#xff1b;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     * @return array
     */
    public function sameHqUpdateUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->sameHqUpdateUrl, $data);
    }

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5220;&#x9664;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function sameHqDeleteByImage($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->sameHqDeleteUrl, $data);
    }

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5220;&#x9664;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function sameHqDeleteByUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->sameHqDeleteUrl, $data);
    }

    /**
     * &#x76f8;&#x540c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5220;&#x9664;&#x63a5;&#x53e3;
     *
     * @param string $contSign - &#x56fe;&#x7247;&#x7b7e;&#x540d;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function sameHqDeleteBySign($contSign, $options=array()){

        $data = array();
        
        $data['cont_sign'] = $contSign;

        $data = array_merge($data, $options);

        return $this->request($this->sameHqDeleteUrl, $data);
    }

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5165;&#x5e93;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   brief &#x68c0;&#x7d22;&#x65f6;&#x539f;&#x6837;&#x5e26;&#x56de;,&#x6700;&#x957f;256B&#x3002;
     *   tags 1 - 65535&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#xff0c;tag&#x95f4;&#x4ee5;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x6700;&#x591a;2&#x4e2a;tag&#x3002;&#x6837;&#x4f8b;&#xff1a;"100,11" &#xff1b;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     * @return array
     */
    public function similarAdd($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->similarAddUrl, $data);
    }

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5165;&#x5e93;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   brief &#x68c0;&#x7d22;&#x65f6;&#x539f;&#x6837;&#x5e26;&#x56de;,&#x6700;&#x957f;256B&#x3002;
     *   tags 1 - 65535&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#xff0c;tag&#x95f4;&#x4ee5;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x6700;&#x591a;2&#x4e2a;tag&#x3002;&#x6837;&#x4f8b;&#xff1a;"100,11" &#xff1b;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     * @return array
     */
    public function similarAddUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->similarAddUrl, $data);
    }

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x68c0;&#x7d22;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   tags 1 - 65535&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#xff0c;tag&#x95f4;&#x4ee5;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x6700;&#x591a;2&#x4e2a;tag&#x3002;&#x6837;&#x4f8b;&#xff1a;"100,11" &#xff1b;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     *   tag_logic &#x68c0;&#x7d22;&#x65f6;tag&#x4e4b;&#x95f4;&#x7684;&#x903b;&#x8f91;&#xff0c; 0&#xff1a;&#x903b;&#x8f91;and&#xff0c;1&#xff1a;&#x903b;&#x8f91;or
     *   pn &#x5206;&#x9875;&#x529f;&#x80fd;&#xff0c;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;&#xff0c;&#x4f8b;&#xff1a;0&#x3002;&#x672a;&#x6307;&#x5b9a;&#x5206;&#x9875;&#x65f6;&#xff0c;&#x9ed8;&#x8ba4;&#x8fd4;&#x56de;&#x524d;300&#x4e2a;&#x7ed3;&#x679c;&#xff1b;&#x63a5;&#x53e3;&#x8fd4;&#x56de;&#x6570;&#x91cf;&#x6700;&#x5927;&#x9650;&#x5236;1000&#x6761;&#xff0c;&#x4f8b;&#x5982;&#xff1a;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;&#x4e3a;900&#xff0c;&#x622a;&#x53d6;&#x6761;&#x6570;500&#x6761;&#xff0c;&#x63a5;&#x53e3;&#x4e5f;&#x53ea;&#x8fd4;&#x56de;&#x7b2c;900 - 1000&#x6761;&#x7684;&#x7ed3;&#x679c;&#xff0c;&#x5171;&#x8ba1;100&#x6761;
     *   rn &#x5206;&#x9875;&#x529f;&#x80fd;&#xff0c;&#x622a;&#x53d6;&#x6761;&#x6570;&#xff0c;&#x4f8b;&#xff1a;250
     * @return array
     */
    public function similarSearch($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->similarSearchUrl, $data);
    }

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x68c0;&#x7d22;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   tags 1 - 65535&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#xff0c;tag&#x95f4;&#x4ee5;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x6700;&#x591a;2&#x4e2a;tag&#x3002;&#x6837;&#x4f8b;&#xff1a;"100,11" &#xff1b;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     *   tag_logic &#x68c0;&#x7d22;&#x65f6;tag&#x4e4b;&#x95f4;&#x7684;&#x903b;&#x8f91;&#xff0c; 0&#xff1a;&#x903b;&#x8f91;and&#xff0c;1&#xff1a;&#x903b;&#x8f91;or
     *   pn &#x5206;&#x9875;&#x529f;&#x80fd;&#xff0c;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;&#xff0c;&#x4f8b;&#xff1a;0&#x3002;&#x672a;&#x6307;&#x5b9a;&#x5206;&#x9875;&#x65f6;&#xff0c;&#x9ed8;&#x8ba4;&#x8fd4;&#x56de;&#x524d;300&#x4e2a;&#x7ed3;&#x679c;&#xff1b;&#x63a5;&#x53e3;&#x8fd4;&#x56de;&#x6570;&#x91cf;&#x6700;&#x5927;&#x9650;&#x5236;1000&#x6761;&#xff0c;&#x4f8b;&#x5982;&#xff1a;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;&#x4e3a;900&#xff0c;&#x622a;&#x53d6;&#x6761;&#x6570;500&#x6761;&#xff0c;&#x63a5;&#x53e3;&#x4e5f;&#x53ea;&#x8fd4;&#x56de;&#x7b2c;900 - 1000&#x6761;&#x7684;&#x7ed3;&#x679c;&#xff0c;&#x5171;&#x8ba1;100&#x6761;
     *   rn &#x5206;&#x9875;&#x529f;&#x80fd;&#xff0c;&#x622a;&#x53d6;&#x6761;&#x6570;&#xff0c;&#x4f8b;&#xff1a;250
     * @return array
     */
    public function similarSearchUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->similarSearchUrl, $data);
    }

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x66f4;&#x65b0;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   brief &#x66f4;&#x65b0;&#x7684;&#x6458;&#x8981;&#x4fe1;&#x606f;&#xff0c;&#x6700;&#x957f;256B&#x3002;&#x6837;&#x4f8b;&#xff1a;{"name":"&#x5468;&#x6770;&#x4f26;", "id":"666"}
     *   tags 1 - 65535&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#xff0c;tag&#x95f4;&#x4ee5;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x6700;&#x591a;2&#x4e2a;tag&#x3002;&#x6837;&#x4f8b;&#xff1a;"100,11" &#xff1b;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     * @return array
     */
    public function similarUpdate($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->similarUpdateUrl, $data);
    }

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x66f4;&#x65b0;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   brief &#x66f4;&#x65b0;&#x7684;&#x6458;&#x8981;&#x4fe1;&#x606f;&#xff0c;&#x6700;&#x957f;256B&#x3002;&#x6837;&#x4f8b;&#xff1a;{"name":"&#x5468;&#x6770;&#x4f26;", "id":"666"}
     *   tags 1 - 65535&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#xff0c;tag&#x95f4;&#x4ee5;&#x9017;&#x53f7;&#x5206;&#x9694;&#xff0c;&#x6700;&#x591a;2&#x4e2a;tag&#x3002;&#x6837;&#x4f8b;&#xff1a;"100,11" &#xff1b;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     * @return array
     */
    public function similarUpdateUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->similarUpdateUrl, $data);
    }

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5220;&#x9664;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function similarDeleteByImage($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->similarDeleteUrl, $data);
    }

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5220;&#x9664;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function similarDeleteByUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->similarDeleteUrl, $data);
    }

    /**
     * &#x76f8;&#x4f3c;&#x56fe;&#x68c0;&#x7d22;&#x2014;&#x5220;&#x9664;&#x63a5;&#x53e3;
     *
     * @param string $contSign - &#x56fe;&#x7247;&#x7b7e;&#x540d;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function similarDeleteBySign($contSign, $options=array()){

        $data = array();
        
        $data['cont_sign'] = $contSign;

        $data = array_merge($data, $options);

        return $this->request($this->similarDeleteUrl, $data);
    }

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x5165;&#x5e93;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   brief &#x68c0;&#x7d22;&#x65f6;&#x539f;&#x6837;&#x5e26;&#x56de;,&#x6700;&#x957f;256B&#x3002;**&#x8bf7;&#x6ce8;&#x610f;&#xff0c;&#x68c0;&#x7d22;&#x63a5;&#x53e3;&#x4e0d;&#x8fd4;&#x56de;&#x539f;&#x56fe;&#xff0c;&#x4ec5;&#x53cd;&#x9988;&#x5f53;&#x524d;&#x586b;&#x5199;&#x7684;brief&#x4fe1;&#x606f;&#xff0c;&#x6240;&#x4ee5;&#x8c03;&#x7528;&#x8be5;&#x5165;&#x5e93;&#x63a5;&#x53e3;&#x65f6;&#xff0c;brief&#x4fe1;&#x606f;&#x8bf7;&#x5c3d;&#x91cf;&#x586b;&#x5199;&#x53ef;&#x5173;&#x8054;&#x81f3;&#x672c;&#x5730;&#x56fe;&#x5e93;&#x7684;&#x56fe;&#x7247;id&#x6216;&#x8005;&#x56fe;&#x7247;url&#x3001;&#x56fe;&#x7247;&#x540d;&#x79f0;&#x7b49;&#x4fe1;&#x606f;**
     *   class_id1 &#x5546;&#x54c1;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;1&#xff0c;&#x652f;&#x6301;1-60&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#x3002;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x8be5;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     *   class_id2 &#x5546;&#x54c1;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;1&#xff0c;&#x652f;&#x6301;1-60&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#x3002;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x8be5;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     * @return array
     */
    public function productAdd($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->productAddUrl, $data);
    }

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x5165;&#x5e93;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   brief &#x68c0;&#x7d22;&#x65f6;&#x539f;&#x6837;&#x5e26;&#x56de;,&#x6700;&#x957f;256B&#x3002;**&#x8bf7;&#x6ce8;&#x610f;&#xff0c;&#x68c0;&#x7d22;&#x63a5;&#x53e3;&#x4e0d;&#x8fd4;&#x56de;&#x539f;&#x56fe;&#xff0c;&#x4ec5;&#x53cd;&#x9988;&#x5f53;&#x524d;&#x586b;&#x5199;&#x7684;brief&#x4fe1;&#x606f;&#xff0c;&#x6240;&#x4ee5;&#x8c03;&#x7528;&#x8be5;&#x5165;&#x5e93;&#x63a5;&#x53e3;&#x65f6;&#xff0c;brief&#x4fe1;&#x606f;&#x8bf7;&#x5c3d;&#x91cf;&#x586b;&#x5199;&#x53ef;&#x5173;&#x8054;&#x81f3;&#x672c;&#x5730;&#x56fe;&#x5e93;&#x7684;&#x56fe;&#x7247;id&#x6216;&#x8005;&#x56fe;&#x7247;url&#x3001;&#x56fe;&#x7247;&#x540d;&#x79f0;&#x7b49;&#x4fe1;&#x606f;**
     *   class_id1 &#x5546;&#x54c1;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;1&#xff0c;&#x652f;&#x6301;1-60&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#x3002;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x8be5;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     *   class_id2 &#x5546;&#x54c1;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;1&#xff0c;&#x652f;&#x6301;1-60&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#x3002;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x8be5;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     * @return array
     */
    public function productAddUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->productAddUrl, $data);
    }

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x68c0;&#x7d22;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   class_id1 &#x5546;&#x54c1;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;1&#xff0c;&#x652f;&#x6301;1-60&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#x3002;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x8be5;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     *   class_id2 &#x5546;&#x54c1;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;1&#xff0c;&#x652f;&#x6301;1-60&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#x3002;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x8be5;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     *   pn &#x5206;&#x9875;&#x529f;&#x80fd;&#xff0c;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;&#xff0c;&#x4f8b;&#xff1a;0&#x3002;&#x672a;&#x6307;&#x5b9a;&#x5206;&#x9875;&#x65f6;&#xff0c;&#x9ed8;&#x8ba4;&#x8fd4;&#x56de;&#x524d;300&#x4e2a;&#x7ed3;&#x679c;&#xff1b;&#x63a5;&#x53e3;&#x8fd4;&#x56de;&#x6570;&#x91cf;&#x6700;&#x5927;&#x9650;&#x5236;1000&#x6761;&#xff0c;&#x4f8b;&#x5982;&#xff1a;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;&#x4e3a;900&#xff0c;&#x622a;&#x53d6;&#x6761;&#x6570;500&#x6761;&#xff0c;&#x63a5;&#x53e3;&#x4e5f;&#x53ea;&#x8fd4;&#x56de;&#x7b2c;900 - 1000&#x6761;&#x7684;&#x7ed3;&#x679c;&#xff0c;&#x5171;&#x8ba1;100&#x6761;
     *   rn &#x5206;&#x9875;&#x529f;&#x80fd;&#xff0c;&#x622a;&#x53d6;&#x6761;&#x6570;&#xff0c;&#x4f8b;&#xff1a;250
     * @return array
     */
    public function productSearch($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->productSearchUrl, $data);
    }

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x68c0;&#x7d22;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   class_id1 &#x5546;&#x54c1;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;1&#xff0c;&#x652f;&#x6301;1-60&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#x3002;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x8be5;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     *   class_id2 &#x5546;&#x54c1;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;1&#xff0c;&#x652f;&#x6301;1-60&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#x3002;&#x68c0;&#x7d22;&#x65f6;&#x53ef;&#x5708;&#x5b9a;&#x8be5;&#x5206;&#x7c7b;&#x7ef4;&#x5ea6;&#x8fdb;&#x884c;&#x68c0;&#x7d22;
     *   pn &#x5206;&#x9875;&#x529f;&#x80fd;&#xff0c;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;&#xff0c;&#x4f8b;&#xff1a;0&#x3002;&#x672a;&#x6307;&#x5b9a;&#x5206;&#x9875;&#x65f6;&#xff0c;&#x9ed8;&#x8ba4;&#x8fd4;&#x56de;&#x524d;300&#x4e2a;&#x7ed3;&#x679c;&#xff1b;&#x63a5;&#x53e3;&#x8fd4;&#x56de;&#x6570;&#x91cf;&#x6700;&#x5927;&#x9650;&#x5236;1000&#x6761;&#xff0c;&#x4f8b;&#x5982;&#xff1a;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;&#x4e3a;900&#xff0c;&#x622a;&#x53d6;&#x6761;&#x6570;500&#x6761;&#xff0c;&#x63a5;&#x53e3;&#x4e5f;&#x53ea;&#x8fd4;&#x56de;&#x7b2c;900 - 1000&#x6761;&#x7684;&#x7ed3;&#x679c;&#xff0c;&#x5171;&#x8ba1;100&#x6761;
     *   rn &#x5206;&#x9875;&#x529f;&#x80fd;&#xff0c;&#x622a;&#x53d6;&#x6761;&#x6570;&#xff0c;&#x4f8b;&#xff1a;250
     * @return array
     */
    public function productSearchUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->productSearchUrl, $data);
    }

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x66f4;&#x65b0;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   brief &#x66f4;&#x65b0;&#x7684;&#x6458;&#x8981;&#x4fe1;&#x606f;&#xff0c;&#x6700;&#x957f;256B&#x3002;&#x6837;&#x4f8b;&#xff1a;{"name":"&#x5468;&#x6770;&#x4f26;", "id":"666"}
     *   class_id1 &#x66f4;&#x65b0;&#x7684;&#x5546;&#x54c1;&#x5206;&#x7c7b;1&#xff0c;&#x652f;&#x6301;1-60&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#x3002;
     *   class_id2 &#x66f4;&#x65b0;&#x7684;&#x5546;&#x54c1;&#x5206;&#x7c7b;2&#xff0c;&#x652f;&#x6301;1-60&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#x3002;
     * @return array
     */
    public function productUpdate($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->productUpdateUrl, $data);
    }

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x66f4;&#x65b0;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     *   brief &#x66f4;&#x65b0;&#x7684;&#x6458;&#x8981;&#x4fe1;&#x606f;&#xff0c;&#x6700;&#x957f;256B&#x3002;&#x6837;&#x4f8b;&#xff1a;{"name":"&#x5468;&#x6770;&#x4f26;", "id":"666"}
     *   class_id1 &#x66f4;&#x65b0;&#x7684;&#x5546;&#x54c1;&#x5206;&#x7c7b;1&#xff0c;&#x652f;&#x6301;1-60&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#x3002;
     *   class_id2 &#x66f4;&#x65b0;&#x7684;&#x5546;&#x54c1;&#x5206;&#x7c7b;2&#xff0c;&#x652f;&#x6301;1-60&#x8303;&#x56f4;&#x5185;&#x7684;&#x6574;&#x6570;&#x3002;
     * @return array
     */
    public function productUpdateUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->productUpdateUrl, $data);
    }

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x5220;&#x9664;&#x63a5;&#x53e3;
     *
     * @param string $image - &#x56fe;&#x50cf;&#x6570;&#x636e;&#xff0c;base64&#x7f16;&#x7801;&#xff0c;&#x8981;&#x6c42;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function productDeleteByImage($image, $options=array()){

        $data = array();
        
        $data['image'] = base64_encode($image);

        $data = array_merge($data, $options);

        return $this->request($this->productDeleteUrl, $data);
    }

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x5220;&#x9664;&#x63a5;&#x53e3;
     *
     * @param string $url - &#x56fe;&#x7247;&#x5b8c;&#x6574;URL&#xff0c;URL&#x957f;&#x5ea6;&#x4e0d;&#x8d85;&#x8fc7;1024&#x5b57;&#x8282;&#xff0c;URL&#x5bf9;&#x5e94;&#x7684;&#x56fe;&#x7247;base64&#x7f16;&#x7801;&#x540e;&#x5927;&#x5c0f;&#x4e0d;&#x8d85;&#x8fc7;4M&#xff0c;&#x6700;&#x77ed;&#x8fb9;&#x81f3;&#x5c11;15px&#xff0c;&#x6700;&#x957f;&#x8fb9;&#x6700;&#x5927;4096px,&#x652f;&#x6301;jpg/png/bmp&#x683c;&#x5f0f;&#xff0c;&#x5f53;image&#x5b57;&#x6bb5;&#x5b58;&#x5728;&#x65f6;url&#x5b57;&#x6bb5;&#x5931;&#x6548;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function productDeleteByUrl($url, $options=array()){

        $data = array();
        
        $data['url'] = $url;

        $data = array_merge($data, $options);

        return $this->request($this->productDeleteUrl, $data);
    }

    /**
     * &#x5546;&#x54c1;&#x68c0;&#x7d22;&#x2014;&#x5220;&#x9664;&#x63a5;&#x53e3;
     *
     * @param string $contSign - &#x56fe;&#x7247;&#x7b7e;&#x540d;
     * @param array $options - &#x53ef;&#x9009;&#x53c2;&#x6570;&#x5bf9;&#x8c61;&#xff0c;key: value&#x90fd;&#x4e3a;string&#x7c7b;&#x578b;
     * @description options&#x5217;&#x8868;:
     * @return array
     */
    public function productDeleteBySign($contSign, $options=array()){

        $data = array();
        
        $data['cont_sign'] = $contSign;

        $data = array_merge($data, $options);

        return $this->request($this->productDeleteUrl, $data);
    }
}

