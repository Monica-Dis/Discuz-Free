<?php
/*
* Copyright (c) 2017 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License. You may obtain a copy of
* the License at
*
* Http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/

require_once 'AipHttpClient.php';
require_once 'AipBCEUtil.php';

/**
 * Aip Base &#x57fa;&#x7c7b;
 */
class AipBase {

    /**
     * &#x83b7;&#x53d6;access token url
     * @var string
     */
    protected $accessTokenUrl = 'https://aip.baidubce.com/oauth/2.0/token';

     /**
     * &#x53cd;&#x9988;&#x63a5;&#x53e3;
     * @var string
     */
    protected $reportUrl = 'https://aip.baidubce.com/rpc/2.0/feedback/v1/report';

    /**
     * appId
     * @var string
     */
    protected $appId = '';

    /**
     * apiKey
     * @var string
     */
    protected $apiKey = '';

    /**
     * secretKey
     * @var string
     */
    protected $secretKey = '';

    /**
     * &#x6743;&#x9650;
     * @var array
     */
    protected $scope = 'brain_all_scope';

    /**
     * @param string $appId
     * @param string $apiKey
     * @param string $secretKey
     */
    public function __construct($appId, $apiKey, $secretKey){
        $this->appId = trim($appId);
        $this->apiKey = trim($apiKey);
        $this->secretKey = trim($secretKey);
        $this->isCloudUser = null;
        $this->client = new AipHttpClient();
        $this->version = '2_2_10';
        $this->proxies = array();
    }

    /**
     * &#x67e5;&#x770b;&#x7248;&#x672c;
     * @return string
     *
     */
    public function getVersion(){
        return $this->version;
    }

    /**
     * &#x8fde;&#x63a5;&#x8d85;&#x65f6;
     * @param int $ms &#x6beb;&#x79d2;
     */
    public function setConnectionTimeoutInMillis($ms){
        $this->client->setConnectionTimeoutInMillis($ms);
    }

    /**
     * &#x54cd;&#x5e94;&#x8d85;&#x65f6;
     * @param int $ms &#x6beb;&#x79d2;
     */
    public function setSocketTimeoutInMillis($ms){
        $this->client->setSocketTimeoutInMillis($ms);
    }

    /**
     * &#x4ee3;&#x7406;
     * @param array $proxy
     * @return string
     *
     */
    public function setProxies($proxies){
        $this->client->setConf($proxies);
    }

    /**
     * &#x5904;&#x7406;&#x8bf7;&#x6c42;&#x53c2;&#x6570;
     * @param  string $url
     * @param array $params
     * @param array $data
     * @param array $headers
     */
    protected function proccessRequest($url, &$params, &$data, $headers){
        $params['aipSdk'] = 'php';
        $params['aipSdkVersion'] = $this->version;
    }

    /**
     * Api &#x8bf7;&#x6c42;
     * @param  string $url
     * @param  mixed $data
     * @return mixed
     */
    protected function request($url, $data, $headers=array()){
        try{
            $result = $this->validate($url, $data);
            if($result !== true){
                return $result;
            }

            $params = array();
            $authObj = $this->auth();

            if($this->isCloudUser === false){
                $params['access_token'] = $authObj['access_token'];
            }

            // &#x7279;&#x6b8a;&#x5904;&#x7406;
            $this->proccessRequest($url, $params, $data, $headers);

            $headers = $this->getAuthHeaders('POST', $url, $params, $headers);
            $response = $this->client->post($url, $data, $params, $headers);

            $obj = $this->proccessResult($response['content']);

            if(!$this->isCloudUser && isset($obj['error_code']) && $obj['error_code'] == 110){
                $authObj = $this->auth(true);
                $params['access_token'] = $authObj['access_token'];
                $response = $this->client->post($url, $data, $params, $headers);
                $obj = $this->proccessResult($response['content']);
            }

            if(empty($obj) || !isset($obj['error_code'])){
                $this->writeAuthObj($authObj);
            }
        }catch(Exception $e){
            return array(
                'error_code' => 'SDK108',
                'error_msg' => 'connection or read data timeout',
            );
        }

        return $obj;
    }

    /**
     * Api &#x591a;&#x4e2a;&#x5e76;&#x53d1;&#x8bf7;&#x6c42;
     * @param  string $url
     * @param  mixed $data
     * @return mixed
     */
    protected function multi_request($url, $data){
        try{
            $params = array();
            $authObj = $this->auth();
            $headers = $this->getAuthHeaders('POST', $url);

            if($this->isCloudUser === false){
                $params['access_token'] = $authObj['access_token'];
            }

            $responses = $this->client->multi_post($url, $data, $params, $headers);

            $is_success = false;
            foreach($responses as $response){
                $obj = $this->proccessResult($response['content']);

                if(empty($obj) || !isset($obj['error_code'])){
                    $is_success = true;
                }

                if(!$this->isCloudUser && isset($obj['error_code']) && $obj['error_code'] == 110){
                    $authObj = $this->auth(true);
                    $params['access_token'] = $authObj['access_token'];
                    $responses = $this->client->post($url, $data, $params, $headers);
                    break;
                }
            }

            if($is_success){
                $this->writeAuthObj($authObj);
            }

            $objs = array();
            foreach($responses as $response){
                $objs[] = $this->proccessResult($response['content']);
            }

        }catch(Exception $e){
            return array(
                'error_code' => 'SDK108',
                'error_msg' => 'connection or read data timeout',
            );
        }

        return $objs;
    }

    /**
     * &#x683c;&#x5f0f;&#x68c0;&#x67e5;
     * @param  string $url
     * @param  array $data
     * @return mix
     */
    protected function validate($url, &$data){
        return true;
    }

    /**
     * &#x683c;&#x5f0f;&#x5316;&#x7ed3;&#x679c;
     * @param $content string
     * @return mixed
     */
    protected function proccessResult($content){
        return json_decode($content, true);
    }

    /**
     * &#x8fd4;&#x56de; access token &#x8def;&#x5f84;
     * @return string
     */
    private function getAuthFilePath(){
        return dirname(__FILE__) . DIRECTORY_SEPARATOR . md5($this->apiKey);
    }

    /**
     * &#x5199;&#x5165;&#x672c;&#x5730;&#x6587;&#x4ef6;
     * @param  array $obj
     * @return void
     */
    private function writeAuthObj($obj){
        if($obj === null || (isset($obj['is_read']) && $obj['is_read'] === true)){
            return;
        }

        $obj['time'] = time();
        $obj['is_cloud_user'] = $this->isCloudUser;
        @file_put_contents($this->getAuthFilePath(), json_encode($obj));
    }

    /**
     * &#x8bfb;&#x53d6;&#x672c;&#x5730;&#x7f13;&#x5b58;
     * @return array
     */
    private function readAuthObj(){
        $content = @file_get_contents($this->getAuthFilePath());
        if($content !== false){
            $obj = json_decode($content, true);
            $this->isCloudUser = $obj['is_cloud_user'];
            $obj['is_read'] = true;
            if($this->isCloudUser || $obj['time'] + $obj['expires_in'] - 30 > time()){
                return $obj;
            }
        }

        return null;
    }

    /**
     * &#x8ba4;&#x8bc1;
     * @param bool $refresh &#x662f;&#x5426;&#x5237;&#x65b0;
     * @return array
     */
    private function auth($refresh=false){

        //&#x975e;&#x8fc7;&#x671f;&#x5237;&#x65b0;
        if(!$refresh){
            $obj = $this->readAuthObj();
            if(!empty($obj)){
                return $obj;
            }
        }

        $response = $this->client->get($this->accessTokenUrl, array(
            'grant_type' => 'client_credentials',
            'client_id' => $this->apiKey,
            'client_secret' => $this->secretKey,
        ));

        $obj = json_decode($response['content'], true);

        $this->isCloudUser = !$this->isPermission($obj);
        return $obj;
    }

    /**
     * &#x5224;&#x65ad;&#x8ba4;&#x8bc1;&#x662f;&#x5426;&#x6709;&#x6743;&#x9650;
     * @param  array   $authObj
     * @return boolean
     */
    protected function isPermission($authObj)
    {
        if(empty($authObj) || !isset($authObj['scope'])){
            return false;
        }

        $scopes = explode(' ', $authObj['scope']);

        return in_array($this->scope, $scopes);
    }

    /**
     * @param  string $method HTTP method
     * @param  string $url
     * @param  array $param &#x53c2;&#x6570;
     * @return array
     */
    private function getAuthHeaders($method, $url, $params=array(), $headers=array()){

        //&#x4e0d;&#x662f;&#x4e91;&#x7684;&#x8001;&#x7528;&#x6237;&#x5219;&#x4e0d;&#x7528;&#x5728;header&#x4e2d;&#x7b7e;&#x540d; &#x8ba4;&#x8bc1;
        if($this->isCloudUser === false){
            return $headers;
        }

        $obj = parse_url($url);
        if(!empty($obj['query'])){
            foreach(explode('&', $obj['query']) as $kv){
                if(!empty($kv)){
                    list($k, $v) = explode('=', $kv, 2);
                    $params[$k] = $v;
                }
            }
        }

        //UTC &#x65f6;&#x95f4;&#x6233;
        $timestamp = gmdate('Y-m-d\TH:i:s\Z');
        $headers['Host'] = isset($obj['port']) ? sprintf('%s:%s', $obj['host'], $obj['port']) : $obj['host'];
        $headers['x-bce-date'] = $timestamp;

        //&#x7b7e;&#x540d;
        $headers['authorization'] = AipSampleSigner::sign(array(
            'ak' => $this->apiKey,
            'sk' => $this->secretKey,
        ), $method, $obj['path'], $headers, $params, array(
            'timestamp' => $timestamp,
            'headersToSign' => array_keys($headers),
        ));

        return $headers;
    }

    /**
     * &#x53cd;&#x9988;
     *
     * @param array $feedbacks
     * @return array
     */
    public function report($feedback){

        $data = array();

        $data['feedback'] = $feedback;

        return $this->request($this->reportUrl, $data);
    }

    /**
     * &#x901a;&#x7528;&#x63a5;&#x53e3;
     * @param string $url
     * @param array $data
     * @param array header
     * @return array
     */
    public function post($url, $data, $headers=array()){
        return $this->request($url, $data, $headers);
    }

}
