<?php
/*
* Copyright (c) 2017 Baidu.com, Inc. All Rights Reserved
*
* Licensed under the Apache License, Version 2.0 (the "License"); you may not
* use this file except in compliance with the License. You may obtain a copy of
* the License at
*
* Http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/

/**
 * BCE Util
 */
class AipHttpUtil
{
    // &#x6839;&#x636e;RFC 3986&#xff0c;&#x9664;&#x4e86;&#xff1a;
    //   1.&#x5927;&#x5c0f;&#x5199;&#x82f1;&#x6587;&#x5b57;&#x7b26;
    //   2.&#x963f;&#x62c9;&#x4f2f;&#x6570;&#x5b57;
    //   3.&#x70b9;'.'&#x3001;&#x6ce2;&#x6d6a;&#x7ebf;'~'&#x3001;&#x51cf;&#x53f7;'-'&#x4ee5;&#x53ca;&#x4e0b;&#x5212;&#x7ebf;'_'
    // &#x4ee5;&#x5916;&#x90fd;&#x8981;&#x7f16;&#x7801;
    public static $PERCENT_ENCODED_STRINGS;

    //&#x586b;&#x5145;&#x7f16;&#x7801;&#x6570;&#x7ec4;
    public static function __init()
    {
        AipHttpUtil::$PERCENT_ENCODED_STRINGS = array();
        for ($i = 0; $i < 256; ++$i) {
            AipHttpUtil::$PERCENT_ENCODED_STRINGS[$i] = sprintf("%%%02X", $i);
        }

        //a-z&#x4e0d;&#x7f16;&#x7801;
        foreach (range('a', 'z') as $ch) {
            AipHttpUtil::$PERCENT_ENCODED_STRINGS[ord($ch)] = $ch;
        }

        //A-Z&#x4e0d;&#x7f16;&#x7801;
        foreach (range('A', 'Z') as $ch) {
            AipHttpUtil::$PERCENT_ENCODED_STRINGS[ord($ch)] = $ch;
        }

        //0-9&#x4e0d;&#x7f16;&#x7801;
        foreach (range('0', '9') as $ch) {
            AipHttpUtil::$PERCENT_ENCODED_STRINGS[ord($ch)] = $ch;
        }

        //&#x4ee5;&#x4e0b;4&#x4e2a;&#x5b57;&#x7b26;&#x4e0d;&#x7f16;&#x7801;
        AipHttpUtil::$PERCENT_ENCODED_STRINGS[ord('-')] = '-';
        AipHttpUtil::$PERCENT_ENCODED_STRINGS[ord('.')] = '.';
        AipHttpUtil::$PERCENT_ENCODED_STRINGS[ord('_')] = '_';
        AipHttpUtil::$PERCENT_ENCODED_STRINGS[ord('~')] = '~';
    }

    /**
     * &#x5728;uri&#x7f16;&#x7801;&#x4e2d;&#x4e0d;&#x80fd;&#x5bf9;'/'&#x7f16;&#x7801;
     * @param  string $path
     * @return string
     */
    public static function urlEncodeExceptSlash($path)
    {
        return str_replace("%2F", "/", AipHttpUtil::urlEncode($path));
    }

    /**
     * &#x4f7f;&#x7528;&#x7f16;&#x7801;&#x6570;&#x7ec4;&#x7f16;&#x7801;
     * @param  string $path
     * @return string
     */
    public static function urlEncode($value)
    {
        $result = '';
        for ($i = 0; $i < strlen($value); ++$i) {
            $result .= AipHttpUtil::$PERCENT_ENCODED_STRINGS[ord($value[$i])];
        }
        return $result;
    }

    /**
     * &#x751f;&#x6210;&#x6807;&#x51c6;&#x5316;QueryString
     * @param  array $parameters
     * @return array
     */
    public static function getCanonicalQueryString(array $parameters)
    {
        //&#x6ca1;&#x6709;&#x53c2;&#x6570;&#xff0c;&#x76f4;&#x63a5;&#x8fd4;&#x56de;&#x7a7a;&#x4e32;
        if (count($parameters) == 0) {
            return '';
        }

        $parameterStrings = array();
        foreach ($parameters as $k => $v) {
            //&#x8df3;&#x8fc7;Authorization&#x5b57;&#x6bb5;
            if (strcasecmp('Authorization', $k) == 0) {
                continue;
            }
            if (!isset($k)) {
                throw new \InvalidArgumentException(
                    "parameter key should not be null"
                );
            }
            if (isset($v)) {
                //&#x5bf9;&#x4e8e;&#x6709;&#x503c;&#x7684;&#xff0c;&#x7f16;&#x7801;&#x540e;&#x653e;&#x5728;=&#x53f7;&#x4e24;&#x8fb9;
                $parameterStrings[] = AipHttpUtil::urlEncode($k)
                    . '=' . AipHttpUtil::urlEncode((string) $v);
            } else {
                //&#x5bf9;&#x4e8e;&#x6ca1;&#x6709;&#x503c;&#x7684;&#xff0c;&#x53ea;&#x5c06;key&#x7f16;&#x7801;&#x540e;&#x653e;&#x5728;=&#x53f7;&#x7684;&#x5de6;&#x8fb9;&#xff0c;&#x53f3;&#x8fb9;&#x7559;&#x7a7a;
                $parameterStrings[] = AipHttpUtil::urlEncode($k) . '=';
            }
        }
        //&#x6309;&#x7167;&#x5b57;&#x5178;&#x5e8f;&#x6392;&#x5e8f;
        sort($parameterStrings);

        //&#x4f7f;&#x7528;'&'&#x7b26;&#x53f7;&#x8fde;&#x63a5;&#x5b83;&#x4eec;
        return implode('&', $parameterStrings);
    }

    /**
     * &#x751f;&#x6210;&#x6807;&#x51c6;&#x5316;uri
     * @param  string $path
     * @return string
     */
    public static function getCanonicalURIPath($path)
    {
        //&#x7a7a;&#x8def;&#x5f84;&#x8bbe;&#x7f6e;&#x4e3a;'/'
        if (empty($path)) {
            return '/';
        } else {
            //&#x6240;&#x6709;&#x7684;uri&#x5fc5;&#x987b;&#x4ee5;'/'&#x5f00;&#x5934;
            if ($path[0] == '/') {
                return AipHttpUtil::urlEncodeExceptSlash($path);
            } else {
                return '/' . AipHttpUtil::urlEncodeExceptSlash($path);
            }
        }
    }

    /**
     * &#x751f;&#x6210;&#x6807;&#x51c6;&#x5316;http&#x8bf7;&#x6c42;&#x5934;&#x4e32;
     * @param  array $headers
     * @return array
     */
    public static function getCanonicalHeaders($headers)
    {
        //&#x5982;&#x679c;&#x6ca1;&#x6709;headers&#xff0c;&#x5219;&#x8fd4;&#x56de;&#x7a7a;&#x4e32;
        if (count($headers) == 0) {
            return '';
        }

        $headerStrings = array();
        foreach ($headers as $k => $v) {
            //&#x8df3;&#x8fc7;key&#x4e3a;null&#x7684;
            if ($k === null) {
                continue;
            }
            //&#x5982;&#x679c;value&#x4e3a;null&#xff0c;&#x5219;&#x8d4b;&#x503c;&#x4e3a;&#x7a7a;&#x4e32;
            if ($v === null) {
                $v = '';
            }
            //trim&#x540e;&#x518d;encode&#xff0c;&#x4e4b;&#x540e;&#x4f7f;&#x7528;':'&#x53f7;&#x8fde;&#x63a5;&#x8d77;&#x6765;
            $headerStrings[] = AipHttpUtil::urlEncode(strtolower(trim($k))) . ':' . AipHttpUtil::urlEncode(trim($v));
        }
        //&#x5b57;&#x5178;&#x5e8f;&#x6392;&#x5e8f;
        sort($headerStrings);

        //&#x7528;'\n'&#x628a;&#x5b83;&#x4eec;&#x8fde;&#x63a5;&#x8d77;&#x6765;
        return implode("\n", $headerStrings);
    }
}
AipHttpUtil::__init();


class AipSignOption
{
    const EXPIRATION_IN_SECONDS = 'expirationInSeconds';

    const HEADERS_TO_SIGN = 'headersToSign';

    const TIMESTAMP = 'timestamp';

    const DEFAULT_EXPIRATION_IN_SECONDS = 1800;

    const MIN_EXPIRATION_IN_SECONDS = 300;

    const MAX_EXPIRATION_IN_SECONDS = 129600;
}


class AipSampleSigner
{

    const BCE_AUTH_VERSION = "bce-auth-v1";
    const BCE_PREFIX = 'x-bce-';

    //&#x4e0d;&#x6307;&#x5b9a;headersToSign&#x60c5;&#x51b5;&#x4e0b;&#xff0c;&#x9ed8;&#x8ba4;&#x7b7e;&#x540d;http&#x5934;&#xff0c;&#x5305;&#x62ec;&#xff1a;
    //    1.host
    //    2.content-length
    //    3.content-type
    //    4.content-md5
    public static $defaultHeadersToSign;

    public static function  __init()
    {
        AipSampleSigner::$defaultHeadersToSign = array(
            "host",
            "content-length",
            "content-type",
            "content-md5",
        );
    }

    /**
     * &#x7b7e;&#x540d;
     * @param  array $credentials
     * @param  string $httpMethod
     * @param  string $path
     * @param  array  $headers
     * @param  string $params
     * @param  array  $options
     * @return string
     */
    public static function sign(
        array $credentials,
        $httpMethod,
        $path,
        $headers,
        $params,
        $options = array()
    ) {
        //&#x8bbe;&#x5b9a;&#x7b7e;&#x540d;&#x6709;&#x6548;&#x65f6;&#x95f4;
        if (!isset($options[AipSignOption::EXPIRATION_IN_SECONDS])) {
            //&#x9ed8;&#x8ba4;&#x503c;1800&#x79d2;
            $expirationInSeconds = AipSignOption::DEFAULT_EXPIRATION_IN_SECONDS;
        } else {
            $expirationInSeconds = $options[AipSignOption::EXPIRATION_IN_SECONDS];
        }

        //&#x89e3;&#x6790;ak sk
        $accessKeyId = $credentials['ak'];
        $secretAccessKey = $credentials['sk'];

        //&#x8bbe;&#x5b9a;&#x65f6;&#x95f4;&#x6233;&#xff0c;&#x6ce8;&#x610f;&#xff1a;&#x5982;&#x679c;&#x81ea;&#x884c;&#x6307;&#x5b9a;&#x65f6;&#x95f4;&#x6233;&#x9700;&#x8981;&#x4e3a;UTC&#x65f6;&#x95f4;
        if (!isset($options[AipSignOption::TIMESTAMP])) {
            //&#x9ed8;&#x8ba4;&#x503c;&#x5f53;&#x524d;&#x65f6;&#x95f4;
            $timestamp = gmdate('Y-m-d\TH:i:s\Z');
        } else {
            $timestamp = $options[AipSignOption::TIMESTAMP];
        }

        //&#x751f;&#x6210;authString
        $authString = AipSampleSigner::BCE_AUTH_VERSION . '/' . $accessKeyId . '/'
            . $timestamp . '/' . $expirationInSeconds;

        //&#x4f7f;&#x7528;sk&#x548c;authString&#x751f;&#x6210;signKey
        $signingKey = hash_hmac('sha256', $authString, $secretAccessKey);

        //&#x751f;&#x6210;&#x6807;&#x51c6;&#x5316;URI
        $canonicalURI = AipHttpUtil::getCanonicalURIPath($path);

        //&#x751f;&#x6210;&#x6807;&#x51c6;&#x5316;QueryString
        $canonicalQueryString = AipHttpUtil::getCanonicalQueryString($params);

        //&#x586b;&#x5145;headersToSign&#xff0c;&#x4e5f;&#x5c31;&#x662f;&#x6307;&#x660e;&#x54ea;&#x4e9b;header&#x53c2;&#x4e0e;&#x7b7e;&#x540d;
        $headersToSign = null;
        if (isset($options[AipSignOption::HEADERS_TO_SIGN])) {
            $headersToSign = $options[AipSignOption::HEADERS_TO_SIGN];
        }

        //&#x751f;&#x6210;&#x6807;&#x51c6;&#x5316;header
        $canonicalHeader = AipHttpUtil::getCanonicalHeaders(
            AipSampleSigner::getHeadersToSign($headers, $headersToSign)
        );

        //&#x6574;&#x7406;headersToSign&#xff0c;&#x4ee5;';'&#x53f7;&#x8fde;&#x63a5;
        $signedHeaders = '';
        if ($headersToSign !== null) {
            $signedHeaders = strtolower(
                trim(implode(";", $headersToSign))
            );
        }

        //&#x7ec4;&#x6210;&#x6807;&#x51c6;&#x8bf7;&#x6c42;&#x4e32;
        $canonicalRequest = "$httpMethod\n$canonicalURI\n"
            . "$canonicalQueryString\n$canonicalHeader";

        //&#x4f7f;&#x7528;signKey&#x548c;&#x6807;&#x51c6;&#x8bf7;&#x6c42;&#x4e32;&#x5b8c;&#x6210;&#x7b7e;&#x540d;
        $signature = hash_hmac('sha256', $canonicalRequest, $signingKey);

        //&#x7ec4;&#x6210;&#x6700;&#x7ec8;&#x7b7e;&#x540d;&#x4e32;
        $authorizationHeader = "$authString/$signedHeaders/$signature";

        return $authorizationHeader;
    }

    /**
     * &#x6839;&#x636e;headsToSign&#x8fc7;&#x6ee4;&#x5e94;&#x8be5;&#x53c2;&#x4e0e;&#x7b7e;&#x540d;&#x7684;header
     * @param  array $headers
     * @param  array $headersToSign
     * @return array
     */
    public static function getHeadersToSign($headers, $headersToSign)
    {

        $arr = array();
        foreach ($headersToSign as $value) {
            $arr[] = strtolower(trim($value));
        }

        //value&#x88ab;trim&#x540e;&#x4e3a;&#x7a7a;&#x4e32;&#x7684;header&#x4e0d;&#x53c2;&#x4e0e;&#x7b7e;&#x540d;
        $result = array();
        foreach ($headers as $key => $value) {
            if (trim($value) !== '') {
                $key = strtolower(trim($key));
                if (in_array($key, $arr)) {
                    $result[$key] = $value;
                } 
            }
        }

        //&#x8fd4;&#x56de;&#x9700;&#x8981;&#x53c2;&#x4e0e;&#x7b7e;&#x540d;&#x7684;header
        return $result;
    }

    /**
     * &#x68c0;&#x67e5;header&#x662f;&#x4e0d;&#x662f;&#x9ed8;&#x8ba4;&#x53c2;&#x52a0;&#x7b7e;&#x540d;&#x7684;&#xff1a;
     * 1.&#x662f;host&#x3001;content-type&#x3001;content-md5&#x3001;content-length&#x4e4b;&#x4e00;
     * 2.&#x4ee5;x-bce&#x5f00;&#x5934;
     * @param  array $header
     * @return boolean
     */
    public static function isDefaultHeaderToSign($header)
    {
        $header = strtolower(trim($header));
        if (in_array($header, AipSampleSigner::$defaultHeadersToSign)) {
            return true;
        }
        return substr_compare($header, AipSampleSigner::BCE_PREFIX, 0, strlen(AipSampleSigner::BCE_PREFIX)) == 0;
    }
}
AipSampleSigner::__init();
