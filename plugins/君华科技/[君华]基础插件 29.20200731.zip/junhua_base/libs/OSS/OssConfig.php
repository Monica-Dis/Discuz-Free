<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/XmlConfig.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/Result.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Core/OssException.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Core/MimeTypes.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Http/RequestCore.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Http/RequestCore_Exception.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Http/ResponseCore.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/CorsConfig.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/CnameConfig.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/LoggingConfig.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/LiveChannelConfig.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/LiveChannelInfo.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/LiveChannelListInfo.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/StorageCapacityConfig.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/AclResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/BodyResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/GetCorsResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/GetLifecycleResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/GetLocationResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/GetLoggingResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/GetRefererResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/GetStorageCapacityResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/GetWebsiteResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/GetCnameResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/HeaderResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/InitiateMultipartUploadResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/ListBucketsResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/ListMultipartUploadResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/ListMultipartUploadInfo.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/ListObjectsResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/ListPartsResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/PutSetDeleteResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/DeleteObjectsResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/CopyObjectResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/CallbackResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/ExistResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/PutLiveChannelResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/GetLiveChannelHistoryResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/GetLiveChannelInfoResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/GetLiveChannelStatusResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/ListLiveChannelResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/AppendResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/ObjectListInfo.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/SymlinkResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Result/UploadPartResult.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/BucketListInfo.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/LifecycleConfig.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/RefererConfig.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/WebsiteConfig.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Core/OssUtil.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/ListPartsInfo.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/GetLiveChannelHistory.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/GetLiveChannelInfo.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/GetLiveChannelStatus.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/BucketInfo.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/UploadInfo.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/ObjectInfo.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/PrefixInfo.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/Model/PartInfo.php');
include_once(DISCUZ_ROOT.'source/plugin/junhua_base/libs/OSS/OssClient.php');