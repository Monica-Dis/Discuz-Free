<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!in_array($a, array('index', 'add', 'edit', 'set', 'del', 'gettpmsg', 'gettpmsginfo'))){
    $a = 'index';
}


$tpmsgModel = new junhua_model('tpmsg');
$settingModel = new junhua_model('tpmsgSetting');

if($a == 'index'){

    $where = array(
        'plugin_name' => CURMODULE
    );

    $lists = $settingModel->select($where, '*', 'setting_id desc');

    $block_head_title = '&#x6a21;&#x7248;&#x6d88;&#x606f;&#x7ba1;&#x7406;';
    $block_title = '&#x6a21;&#x7248;&#x6d88;&#x606f;&#x5217;&#x8868;';
    $block_css = '';

}elseif($a == 'add'){

    if(IS_AJAX){
        $setting_bz  = junhua_I('setting_bz', '');
        $template_id = junhua_I('template_id', '');
        $url         = junhua_I('url', '');
        $template    = junhua_I('template/a', array());
        $color       = junhua_I('color/a', array());

        $data = array(
            'setting_bz'  => $setting_bz,
            'template_id' => $template_id,
            'url'         => $url,
            'template'    => serialize($template),
            'color'       => serialize($color),
            'plugin_name' => CURMODULE,
            'add_time'    => $_G['timestamp'],
            'is_enable'   => 1,
        );

        $settingId = $settingModel->add($data);

        if($settingId){
            junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x4fdd;&#x5b58;&#x6210;&#x529f;', 'url' => junhua_url('mp/tpmsg/index', '', 1)));
        }else{
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x4fdd;&#x5b58;&#x5931;&#x8d25;'));
        }
    }


    $noticeList = $tpmsgModel->select();

    $block_head_title = '&#x6a21;&#x7248;&#x6d88;&#x606f;&#x7ba1;&#x7406;';
    $block_title = '&#x65b0;&#x589e;&#x6a21;&#x7248;&#x6d88;&#x606f;';
    $block_css = '<link href="source/plugin/junhua_base/static/plugin/bootstrap_colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">';
    
    //&#x83b7;&#x53d6;&#x5f53;&#x524d;&#x63d2;&#x4ef6;&#x4e2d;&#x7684;&#x6a21;&#x7248;&#x6587;&#x4ef6;
    $tpmsgKeyword = '';
    if(is_file('source/plugin/'.CURMODULE.'/template/mp/tpmsg/keyword.htm')){
        $tpmsgKeyword = file_get_contents('source/plugin/'.CURMODULE.'/template/mp/tpmsg/keyword.htm');
    }

    $a = 'update';

}elseif($a == 'edit'){
    $setting_id = junhua_I('setting_id/d', 0);

    $where = array(
        'setting_id'  => $setting_id,
        'plugin_name' => CURMODULE
    );

    $settingInfo = $settingModel->find($where);

    if(!$settingInfo){
        dheader('location:' . junhua_url('mp/tpmsg/index', '', 1));
        exit;
    }

    if(IS_AJAX){
        if(!$settingInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x6570;&#x636e;&#x4e0d;&#x5b58;&#x5728;'));
        }

        $setting_bz  = junhua_I('setting_bz', '');
        $template_id = junhua_I('template_id', '');
        $url         = junhua_I('url', '');
        $template    = junhua_I('template/a', array());
        $color       = junhua_I('color/a', array());

        $data = array(
            'template_id' => $template_id,
            'setting_bz'  => $setting_bz,
            'url'         => $url,
            'template'    => serialize($template),
            'color'       => serialize($color),
        );

        $where = array(
            'setting_id'    => $setting_id
        );

        $settingModel->save($where, $data);
        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x4fdd;&#x5b58;&#x6210;&#x529f;', 'url' => junhua_url('mp/tpmsg/index', '', 1)));

    }

    $noticeList = $tpmsgModel->select();

    $where = array();
    $where['template_id'] = $settingInfo['template_id'];

    $templateInfo = $tpmsgModel->find($where);

    preg_match_all('/\{\{([\w]+)\.DATA\}\}/', $templateInfo['content'], $matches);

    $templateKey = dunserialize($settingInfo['template']);
    $colorKey = dunserialize($settingInfo['color']);

    if($matches[1]){
        $templateInfo['listkey'] = $matches[1];
    }

    $templateInfo['content'] = preg_replace_callback('/\{\{([\w]+)\.DATA\}\}/', function($a){
        global $templateKey, $colorKey;
        return '<span class="J-'.$a[1].'" style="color:'.$colorKey[$a[1]].'">'.$templateKey[$a[1]].'</span>';
    }, $templateInfo['content']);

    $templateInfo['url'] = $settingInfo['url'];


    $templateInfo = junhua_json_encode($templateInfo);
    $templateKey  = junhua_json_encode($templateKey);
    $colorKey     = junhua_json_encode($colorKey);

    $block_head_title = '&#x6a21;&#x7248;&#x6d88;&#x606f;&#x7ba1;&#x7406;';
    $block_title = '&#x7f16;&#x8f91;&#x6a21;&#x7248;&#x6d88;&#x606f;';

    $block_css = '<link href="source/plugin/junhua_base/static/plugin/bootstrap_colorpicker/css/bootstrap-colorpicker.min.css" rel="stylesheet">';

    //&#x83b7;&#x53d6;&#x5f53;&#x524d;&#x63d2;&#x4ef6;&#x4e2d;&#x7684;&#x6a21;&#x7248;&#x6587;&#x4ef6;
    $tpmsgKeyword = '';
    if(is_file('source/plugin/'.CURMODULE.'/template/mp/tpmsg/keyword.htm')){
        $tpmsgKeyword = file_get_contents('source/plugin/'.CURMODULE.'/template/mp/tpmsg/keyword.htm');
    }

    $a = 'update';

}elseif($a == 'gettpmsginfo'){
    if(IS_AJAX){

        $template_id = junhua_I('template_id');

        $where = array();
        $where['template_id'] = $template_id;

        $templateInfo = $tpmsgModel->find($where);

        if($templateInfo){

            preg_match_all('/\{\{([\w]+)\.DATA\}\}/', $templateInfo['content'], $matches);

            if($matches[1]){
                $templateInfo['listkey'] = $matches[1];
            }

            $templateInfo['content'] = preg_replace('/\{\{([\w]+)\.DATA\}\}/', '<span class="J-$1">$1</span>', $templateInfo['content']);
            junhua_ajaxReturn(array('status' => 1, 'templateInfo' => $templateInfo));
        }else{
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5fae;&#x4fe1;&#x6d88;&#x606f;&#x6a21;&#x7248;&#x4e0d;&#x5b58;&#x5728;'));
        }
    }

}elseif($a == 'gettpmsg'){
    if(IS_AJAX){

        include_once('source/plugin/junhua_base/libs/weixin/weixin_sdk.php');

        $weixin_appid = ${CURMODULE.'_setting'}['weixin_appid'] ? trim(${CURMODULE.'_setting'}['weixin_appid']) : trim($junhua_base_config['weixin_appid']);
        $weixin_appsecret = ${CURMODULE.'_setting'}['weixin_appsecret'] ? trim(${CURMODULE.'_setting'}['weixin_appsecret']) : trim($junhua_base_config['weixin_appsecret']);
        if($weixin_appid && $weixin_appsecret){
            $weixin_sdk = new WEIXIN_SDK($weixin_appid, $weixin_appsecret);
        }else{
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bf7;&#x5148;&#x586b;&#x5199;&#x5fae;&#x4fe1;&#x76f8;&#x5173;&#x914d;&#x7f6e;'));
        }


        $template_list = $weixin_sdk->get_all_private_template();

        $template_list = $template_list['template_list'];
        $template_list = junhua_array_map('junhua_utf82gbk', $template_list);

        if($template_list){

            $template_ids = array();
            foreach ($template_list as $key => $value) {

                if(!$value['primary_industry']){
                    continue;
                }

                $template_ids[] = $value['template_id'];
            }

            //&#x5220;&#x6389;&#x6ca1;&#x6709;&#x7684;
            $tpmsgModel->delete(array('template_id' => array('not in', $template_ids ? $template_ids : array(''))));

            foreach ($template_list as $key => $value) {

                if(!$value['primary_industry']){
                    continue;
                }

                //&#x5b58;&#x5728;&#x4e0d;&#x64cd;&#x4f5c;&#xff0c;&#x4e0d;&#x5b58;&#x5728;&#x63d2;&#x5165;
                $isEx = $tpmsgModel->count(array('template_id' => $value['template_id']));
                if(!$isEx){
                    $data = array(
                        'template_id'      => $value['template_id'],
                        'template_title'   => $value['title'],
                        'primary_industry' => $value['primary_industry'],
                        'deputy_industry'  => $value['deputy_industry'],
                        'content'          => $value['content'],
                        'example'          => $value['example'],
                    );

                    $tpmsgModel->add($data);
                }
            }

            junhua_ajaxReturn(array('status' => 1));
        }else{
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x6a21;&#x7248;&#x6d88;&#x606f;&#x83b7;&#x53d6;&#x5931;&#x8d25;'));

        }
    }

}elseif($a == 'del'){
    if(IS_AJAX){
        $setting_id = junhua_I('setting_id/d', 0);

        $where = array(
            'setting_id'      => $setting_id,
            'plugin_name' => CURMODULE
        );

        $settingInfo = $settingModel->find($where);
        if(!$settingInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x6a21;&#x7248;&#x6d88;&#x606f;&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $settingModel->delete($where);

        junhua_ajaxReturn(array('status' => 1));
    }

}elseif($a == 'set'){
	if(IS_AJAX){
        $setting_id = junhua_I('setting_id/d', 0);

        $where = array(
            'setting_id'      => $setting_id,
            'plugin_name' => CURMODULE
        );

        $settingInfo = $settingModel->find($where);
        if(!$settingInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($settingInfo['is_enable'] == 1){
            $is_enable = 0;
        }else{
            $is_enable = 1;
        }

        if($settingModel->save($where, array('is_enable' => $is_enable))){
            junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x8bbe;&#x7f6e;&#x6210;&#x529f;&#xff01;'));
        }else{
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;&#xff0c;&#x8bf7;&#x7a0d;&#x540e;&#x518d;&#x8bd5;&#xff01;'));
        }
	}

}

$block_content = 'junhua_base:mp/'.$c.'/'.$a;