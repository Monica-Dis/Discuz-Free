<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql['24.20200419'] = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_junhua_tpmsg` (
  `tpmsg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template_id` varchar(128) DEFAULT '',
  `template_title` varchar(128) DEFAULT '',
  `primary_industry` varchar(128) DEFAULT '',
  `deputy_industry` varchar(128) DEFAULT '',
  `example` varchar(1000) DEFAULT '',
  `content` varchar(1000) DEFAULT '',
  PRIMARY KEY (`tpmsg_id`),
  KEY `template_id` (`template_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_junhua_tpmsg_setting` (
  `setting_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_bz` varchar(128) DEFAULT '',
  `plugin_name` varchar(128) DEFAULT '',
  `template_id` varchar(128) DEFAULT '',
  `template` varchar(1000) DEFAULT '',
  `color` varchar(1000) DEFAULT '',
  `add_time` int(10) unsigned DEFAULT '0',
  `url` varchar(255) DEFAULT '',
  `is_enable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`setting_id`),
  KEY `setting_id` (`setting_id`),
  KEY `template_id` (`template_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

foreach($sql as $key => $value) {
    if($_GET['fromversion'] < $key) {
        runquery($value);
    }
}

$finish = true;