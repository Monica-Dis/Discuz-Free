<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$junhua_base_lang = lang('plugin/junhua_base');


/**
&#x6ce8;&#xff1a;strtolower(CHARSET) == 'gbk'  &#x4e3a;&#x4ec0;&#x4e48;&#x52a0;&#x4e0a;&#x6b64;&#x5224;&#x65ad;&#xff0c;&#x662f;&#x4e3a;&#x4e86;&#x8ba9;&#x5e38;&#x91cf;&#x5224;&#x65ad;&#x4e00;&#x5b9a;&#x6b63;&#x786e;
&#x5f53;&#x7136;&#x6b64;&#x5904;&#x4e5f;&#x662f;&#x6a21;&#x4eff;dz&#x6838;&#x5fc3;&#x51fd;&#x6570; dhtmlspecialchars dstrlen cutstr &#x7b49;&#x51fd;&#x6570;&#x4e2d;&#x4e5f;&#x662f;&#x4e3a;&#x4e86;&#x5224;&#x65ad;&#x7684;&#x51c6;&#x786e;&#x6027; &#x52a0;&#x5165;&#x4e86;&#x6b64;&#x5224;&#x65ad;
 */


/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4e3a;&#x4e86;&#x5728;&#x63d2;&#x4ef6;&#x4e2d;&#x5206;&#x6790;&#x548c;&#x751f;&#x6210;url&#x94fe;&#x63a5;&#x3002;
 */

if(!function_exists('junhua_url')){
    function junhua_url($url, $param = '', $isreturn = false){
        $ary = explode('/', $url);
        $url = 'plugin.php?id='.CURMODULE.'&m='.$ary[0].'&c='.$ary[1].'&a='.$ary[2].($param ? '&'.$param : '');
        if($isreturn){
            return $url;
        }else{
            echo $url;
        }
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4e3a;&#x4e86;&#x8f93;&#x51fa;&#x6807;&#x51c6;json&#x683c;&#x5f0f;
 */

if(!function_exists('junhua_ajaxReturn')){
    function junhua_ajaxReturn($data,$type='',$json_option=0) {
        header('Content-Type:application/json; charset=utf-8');
        exit(junhua_json_encode($data,$json_option));
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4e3a;&#x4e86;&#x8f93;&#x51fa;&#x6807;&#x51c6;json&#x683c;&#x5f0f;&#xff0c;&#x56e0;&#x4e3a;&#x5728;gbk&#x6a21;&#x5f0f;&#x4e0b; json&#x5305;&#x542b;&#x4e2d;&#x6587;&#x4f1a;&#x51fa;&#x9519;
 * &#x6545;&#x91cd;&#x5199;json_encode,&#x89e3;&#x51b3;&#x529e;&#x6cd5;&#x5c31;&#x662f;&#x628a;&#x6570;&#x636e;&#x52a0;&#x4e0a;&#x8fc7;&#x6ee4;&#x5668;junhua_gbk2utf8 &#x5982;&#x5b57;&#x9762;&#x610f;&#x601d;&#x5c31;&#x662f;&#x628a;gbk&#x6a21;&#x5f0f;&#x8f6c;&#x4e3a;utf8&#x4e4b;&#x540e;&#x518d;&#x8fd4;&#x56de;json
 */

if(!function_exists('junhua_json_encode')){
    function junhua_json_encode($data, $json_option=0){
        $ret = array();
        if (strtolower(CHARSET) == 'gbk') {
            $ret = junhua_array_map('junhua_gbk2utf8', $data);
        }else{
            $ret = $data;
        }
        return json_encode($ret, $json_option);
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4e3a;&#x4e86;&#x628a;gbk&#x8f6c;&#x6362;&#x6210;utf8 &#xff0c;&#x672c;&#x53ef;&#x4ee5;&#x4f7f;&#x7528;diconv &#x81ea;&#x5e26;&#x51fd;&#x6570;&#xff0c;
 * &#x4f46;&#x56e0;&#x4e3a;&#x9700;&#x8981;&#x642d;&#x914d;junhua_array_map&#x51fd;&#x6570;&#xff0c;&#x4e14;&#x6b64;&#x51fd;&#x6570;&#x8bbe;&#x8ba1;&#x4e3a;&#x6ca1;&#x6cd5;&#x6dfb;&#x52a0;&#x53c2;&#x6570;&#x6a21;&#x5f0f;&#xff0c;&#x6240;&#x4ee5;&#x624d;&#x521b;&#x5efa;&#x6b64;&#x51fd;&#x6570;
 */

if(!function_exists('junhua_gbk2utf8')){
    function junhua_gbk2utf8($pram){
        if (strtolower(CHARSET) == 'gbk') {
            return diconv($pram, 'gbk', 'utf-8');
        }else{
            return $pram;
        }
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4e3a;&#x4e86;&#x628a;utf8 &#x8f6c;&#x6362;&#x6210;gbk&#xff0c;&#x672c;&#x53ef;&#x4ee5;&#x4f7f;&#x7528;diconv &#x81ea;&#x5e26;&#x51fd;&#x6570;&#xff0c;
 * &#x4f46;&#x56e0;&#x4e3a;&#x9700;&#x8981;&#x642d;&#x914d;junhua_array_map&#x51fd;&#x6570;&#xff0c;&#x4e14;&#x6b64;&#x51fd;&#x6570;&#x8bbe;&#x8ba1;&#x4e3a;&#x6ca1;&#x6cd5;&#x6dfb;&#x52a0;&#x53c2;&#x6570;&#x6a21;&#x5f0f;&#xff0c;&#x6240;&#x4ee5;&#x624d;&#x521b;&#x5efa;&#x6b64;&#x51fd;&#x6570;&#x3002;
 */

if(!function_exists('junhua_utf82gbk')){
    function junhua_utf82gbk($pram){

        $encode = mb_detect_encoding($pram, array('UTF-8','GB2312','GBK'));
        $encode = strtolower($encode);
        if($encode == 'utf-8'){
            return diconv($pram, 'utf-8');
        }elseif($encode == 'euc-cn'){
            return $pram;
        }else{
            return $pram;
        }
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4f5c;&#x7528;&#x4e3a;&#x83b7;&#x53d6;&#x63d0;&#x4ea4;&#x7684;&#x53c2;&#x6570;&#xff0c;&#x672c;&#x76f4;&#x63a5;&#x53ef;&#x4ee5;&#x7528;$_GET&#x65b9;&#x5f0f;&#x83b7;&#x53d6;&#x3002;
 * &#x5c01;&#x88c5;&#x7406;&#x7531;&#x4e3a;&#x5728;gbk&#x6a21;&#x5f0f;&#x4e0b;&#xff0c;&#x5982;&#x679c;&#x63d0;&#x4ea4;&#x7684;&#x662f;utf8&#x7684;&#x683c;&#x5f0f;&#x7684;&#x6570;&#x636e;&#xff0c;&#x90a3;&#x4e48;&#x6570;&#x636e;&#x5c06;&#x4f1a;&#x5168;&#x90e8;&#x53d8;&#x4e3a;&#x4e71;&#x7801;&#xff0c;&#x6545;&#x800c;&#x589e;&#x52a0;&#x8fc7;&#x6ee4;&#x5668;&#x6765;&#x89e3;&#x51b3;&#x6b64;&#x95ee;&#x9898;&#x3002;
 */

if(!function_exists('junhua_I')){
    function junhua_I($name, $default = null, $filter = null){

        $name = (string) $name;
        if ('' != $name) {
            // &#x89e3;&#x6790;name
            if (strpos($name, '/')) {
                list($name, $type) = explode('/', $name);
            } else {
                $type = 's';
            }
        }


        if (strtolower(CHARSET) == 'gbk' && !IS_MOBILE && IS_POST) {
            $_GET[$name] = is_array($_GET[$name]) ? junhua_array_map('junhua_utf82gbk', $_GET[$name]) : junhua_utf82gbk($_GET[$name]);
            $data = isset($_GET[$name]) && $_GET[$name] !== '' ? $_GET[$name] : $default;
        }else{
            $data = isset($_GET[$name]) && $_GET[$name] !== '' ? $_GET[$name] : $default;
        }

        $filters    =   isset($filter) ? $filter : 'dhtmlspecialchars';
        if($filters) {
            if(is_string($filters)){
                $filters    =   explode(',',$filters);                    
            }
            
            if(is_array($filters)){
                foreach($filters as $filter){
                    if(function_exists($filter)) {
                        $data   =   is_array($data) ? junhua_array_map_recursive($filter,$data) : $filter($data); // &#x53c2;&#x6570;&#x8fc7;&#x6ee4;
                    }
                }
            }
        }

        if (isset($type) && $data !== $default) {
            // &#x5f3a;&#x5236;&#x7c7b;&#x578b;&#x8f6c;&#x6362;
            $data = junhua_typecast($data, $type);
        }

        return $data;
    }
}

if(!function_exists('junhua_array_map_recursive')){

    function junhua_array_map_recursive($filter, $data) {
        $result = array();
        foreach ($data as $key => $val) {
            $result[$key] = is_array($val)
             ? junhua_array_map_recursive($filter, $val)
             : call_user_func($filter, $val);
        }
        return $result;
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x6b64;&#x51fd;&#x6570;&#x4f5c;&#x7528;&#x4e3a;&#x8fc7;&#x6ee4;&#x5668;&#x51fd;&#x6570;
 */

if(!function_exists('junhua_array_map')){
    function junhua_array_map($filter, $data) {
        $result = array();
        foreach ($data as $key => $val) {
            $result[$key] = is_array($val) ? junhua_array_map($filter, $val) : call_user_func($filter, $val);
        }
        return $result;
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x5f3a;&#x5236;&#x8f6c;&#x5316;&#x7c7b;&#x578b;
 */

if(!function_exists('junhua_typecast')){
    function junhua_typecast($data, $type){
        switch (strtolower($type)) {
            // &#x6570;&#x7ec4;
            case 'a':
                $data = (array) $data;
                break;
            // &#x6570;&#x5b57;
            case 'd':
                $data = (int) $data;
                break;
            // &#x6d6e;&#x70b9;
            case 'f':
                $data = (float) $data;
                break;
            // &#x5e03;&#x5c14;
            case 'b':
                $data = (boolean) $data;
                break;
            // &#x5b57;&#x7b26;&#x4e32;
            case 's':
            default:
                $data = (string) $data;
        }
        return $data;
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x4eff;&#x5fae;&#x4fe1;&#x4eba;&#x6027;&#x5316;&#x65f6;&#x95f4;
 */


if (!function_exists('junhua_nicetime')) {
    function junhua_nicetime($timestamp = 0){
        global $junhua_base_lang;

        $todaytimestamp = time();
        $time = $todaytimestamp - $timestamp;
        if(date('Y-m-d', $timestamp) == date('Y-m-d', $todaytimestamp)) {//&#x5f53;&#x5929;&#x7684;&#x5c55;&#x793a;&#x65f6;&#x5206;
            $return = date('H:i', $timestamp);
        } elseif(date('Y-m-d', $timestamp) == date('Y-m-d', strtotime('-1 days', $todaytimestamp))) {//&#x6628;&#x5929;&#x7684;&#x5c55;&#x793a;&#x6587;&#x5b57;&#x4e3a;&#x6628;&#x5929;
            $return = $junhua_base_lang['yes']. ' '. date('H:i', $timestamp);
        } elseif(date('Ymd', $timestamp) > date('Ymd', strtotime('-7 days', $todaytimestamp))) {//6&#x5929;&#x5185;

            $w = date('N', $timestamp);
            switch ($w) {
                case '1':
                    $weekName = $junhua_base_lang['mon'];
                    break;
                
                case '2':
                    $weekName = $junhua_base_lang['tus'];
                    break;
                
                case '3':
                    $weekName = $junhua_base_lang['wed'];
                    break;
                
                case '4':
                    $weekName = $junhua_base_lang['tur'];
                    break;
                
                case '5':
                    $weekName = $junhua_base_lang['fri'];
                    break;
                
                case '6':
                    $weekName = $junhua_base_lang['sat'];
                    break;
                
                case '7':
                    $weekName = $junhua_base_lang['sun'];
                    break;
            }

            $return = $weekName.' '. date('H:i', $timestamp);
        } else {
            $s = date('Y-m-d H:i', $timestamp);
            $return = $s;
        }
        return $return;
    }
}

/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x83b7;&#x53d6;&#x56fe;&#x7247;&#x94fe;&#x63a5;
 */
if (!function_exists('junhua_imgsrc')) {
    function junhua_imgsrc($src = ''){
        global $_G;

        if(!$src){
            return $src;
        }

        if (dstrpos($src, array('http://', 'https://'))){
            return $src;
        }

        return $_G['siteurl'].$src;
    }
}


/**
 * @author Hu Hua Feng
 * @param 
 * @return 
 * @todo &#x5220;&#x9664;bbcode
 */

if(!function_exists('junhua_removebbcode')){
    function junhua_removebbcode($str, $open = 0){

        if(!$open){
            return $str;
        }

        return str_replace(array(
            '[/color]', '[/backcolor]', '[/size]', '[/font]', '[/align]', '[b]', '[/b]', '[s]', '[/s]', '[hr]', '[/p]',
            '[i=s]', '[i]', '[/i]', '[u]', '[/u]', '[list]', '[list=1]', '[list=a]',
            '[list=A]', "\r\n[*]", '[*]', '[/list]', '[indent]', '[/indent]', '[/float]',
            ), array(
            '', '', '', '', '', '', '', '', '', '', '', '', '',
            '', '', '', '', '', '',
            '', '', '', '', '', '', '', '',
            ), preg_replace(array(
            "/\[color=([#\w]+?)\]/i",
            "/\[img\](\S*)\[\/img\]/Ui",
            "/\[attach\](\d*)\[\/attach\]/Ui",
            "/\[video(\S*)\](\S*)\[\/video\]/Ui",
            "/\[flash\](\S*)\[\/flash\]/Ui",
            "/\[color=((rgb|rgba)\([\d\s,]+?\))\]/i",
            "/\[backcolor=([#\w]+?)\]/i",
            "/\[backcolor=((rgb|rgba)\([\d\s,]+?\))\]/i",
            "/\[size=(\d{1,2}?)\]/i",
            "/\[size=(\d{1,2}(\.\d{1,2}+)?(px|pt)+?)\]/i",
            "/\[font=([^\[\<]+?)\]/i",
            "/\[align=(left|center|right)\]/i",
            "/\[p=(\d{1,2}|null), (\d{1,2}|null), (left|center|right)\]/i",
            "/\[float=left\]/i",
            "/\[float=right\]/i"
            ), array(
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
            ), $str));
    }
}



if (!function_exists('junhua_emoji_filter')) {

    /**
     * &#x8fc7;&#x6ee4;emoji
     */
    function junhua_emoji_filter($nick) {
        $nick = json_encode($nick);
        $nick = preg_replace('/\\\u[e|d][0-9a-f]{3}/i', '', $nick);
        $nick = json_decode($nick);
        return $nick;
    }
}



//&#x7528;&#x6237;&#x6ce8;&#x518c;
if(!function_exists('junhua_register')){
    function junhua_register($username, $groupid = 0) {
        global $_G;

        $username = substr($username, 0, 15);

        loaducenter();

        //&#x9ed8;&#x8ba4;&#x7b49;&#x7ea7;
        $groupid = !$groupid ? $_G['setting']['newusergroupid'] : $groupid;

        $password = md5(random(10));
        $email = 'wx_'.strtolower(random(10)).'@null.null';

        $usernamelen = dstrlen($username);
        if($usernamelen < 3) {
            $username = $username.'_'.random(5);
        }
        if($usernamelen > 15) {
            if(!$return) {
                showmessage('profile_username_toolong');
            } else {
                return;
            }
        }

        $censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';

        if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
            if(!$return) {
                showmessage('profile_username_protect');
            } else {
                return;
            }
        }

        $fromuid = !empty($_G['cookie']['promotion']) && $_G['setting']['creditspolicy']['promotion_register'] ? intval($_G['cookie']['promotion']) : 0;

        //&#x68c0;&#x6d4b;&#x662f;&#x5426;&#x6709;&#x5e10;&#x53f7;
        if($fromuid){
            $member = C::t('common_member')->fetch($fromuid);
            if(!empty($member)) {
                $fromuser = dhtmlspecialchars($member['username']);
            } else {
                $fromuid = 0;
                dsetcookie('promotion', '');
            }
        }

        if($fromuid) {
            updatecreditbyaction('promotion_register', $fromuid);
            dsetcookie('promotion', '');
        }


        $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
        if($uid <= 0) {
            if(!$return) {
                if($uid == -1) {
                    showmessage('profile_username_illegal');
                } elseif($uid == -2) {
                    showmessage('profile_username_protect');
                } elseif($uid == -3) {
                    showmessage('profile_username_duplicate');
                } elseif($uid == -4) {
                    showmessage('profile_email_illegal');
                } elseif($uid == -5) {
                    showmessage('profile_email_domain_illegal');
                } elseif($uid == -6) {
                    showmessage('profile_email_duplicate');
                } else {
                    showmessage('undefined_action');
                }
            } else {
                return;
            }
        }

        $init_arr = array('credits' => explode(',', $_G['setting']['initcredits']));
        C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

        if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
            C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
            if($_G['setting']['regctrl']) {
                C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
            }
        }

        if($_G['setting']['regverify'] == 2) {
            C::t('common_member_validate')->insert(array(
                'uid' => $uid,
                'submitdate' => $_G['timestamp'],
                'moddate' => 0,
                'admin' => '',
                'submittimes' => 1,
                'status' => 0,
                'message' => '',
                'remark' => '',
            ), false, true);
            manage_addnotify('verifyuser');
        }

        include_once libfile('function/member');

        setloginstatus(array(
            'uid' => $uid,
            'username' => $username,
            'password' => $password,
            'groupid' => $groupid,
        ), 0);

        include_once libfile('function/stat');
        updatestat('register');

        if(!function_exists('build_cache_userstats')) {
            require_once libfile('cache/userstats', 'function');
        }
        build_cache_userstats();
    

        return $uid;
    }
}


if(!function_exists('junhua_select2array')){
    function junhua_select2array($selectString = ''){
        if(!$selectString){
            return '';
        }

        $selectString = str_replace("\r", "", $selectString);
        $selectStringAry = array_filter(explode("\n", $selectString));
        $originalAry = array();
        $max = 0;
        foreach ($selectStringAry as $key => $value) {
            $sub = explode("=", $value);
            $originalAry[$sub[0]] = $sub[1];
            if(substr_count($sub[0], '.') > $max){
                $max = substr_count($sub[0], '.');
            }
        }

        $selectAry = array();
        foreach ($originalAry as $key => $value) {
            if(substr_count($key, '.') == 0){
                $children = junhua_select2array_filter($originalAry, substr_count($key, '.') + 1, $key);
                if(!count($children)){
                    $selectAry[] = array(
                        'label' => $value,
                        'value' => $key
                    );
                }else{
                    $selectAry[] = array(
                        'label'    => $value,
                        'value'    => $key,
                        'children' => $children
                    );
                }
            }

        }

        return $selectAry;

    }
}
if(!function_exists('junhua_select2array_filter')){
    function junhua_select2array_filter($ary, $length = 0, $keyV = ''){
        $selectAry = array();
        foreach ($ary as $key => $value) {
            if(substr_count($key, '.') == $length && preg_match('/^'.$keyV.'\./', $key)){
                $children = junhua_select2array_filter($ary, substr_count($key, '.') + 1, $key);

                if(!count($children)){
                    $selectAry[]  = array(
                        'label' => $value,
                        'value' => $key
                    );
                }else{
                    $selectAry[]  = array(
                        'label'    => $value,
                        'value'    => $key,
                        'children' => $children
                    );
                }
            }
        }

        return $selectAry;
    }
}


if(!function_exists('junhua_sendsms')){
    function junhua_sendsms($setting, $mobile, $param){

        if(!$mobile){
            return false;
        }

        if($setting['type'] == 'dayu'){
            include_once('source/plugin/junhua_base/libs/dayusms.class.php');

            $dayusms = new junhua_dayusms($setting['AccessKeyID'], $setting['AccessKeySecret']);
            $dayusms->setPhoneNumbers($mobile);
            $dayusms->setTemplateCode($setting['TemplateCode']);
            $dayusms->setRegionId('cn-hangzhou');
            $dayusms->setTemplateParam(junhua_json_encode($param));
            $dayusms->setSignName($setting['FreeSignName']);
            $result = $dayusms->exec();

            return $result;

        }

        return false;
    }
}

if(!function_exists('junhua_request_post')){
    function junhua_request_post($url = '', $postFields = '', $options = array()) {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0); // &#x663e;&#x793a;&#x8fd4;&#x56de;&#x7684;Header&#x533a;&#x57df;&#x5185;&#x5bb9; 

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        if (is_array($postFields) && 0 < count($postFields)){
            $postBodyString = "";
            foreach ($postFields as $k => $v)
            {
                $postBodyString .= "$k=" . urlencode($v) . "&";
            }
            unset($k, $v);
            curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, substr($postBodyString,0,-1));
        }elseif(is_string($postFields)){
            curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_POST,true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
        }

        if($options['headers']){
            curl_setopt($ch, CURLOPT_HTTPHEADER, $options['headers']);
        }

        curl_setopt($ch, CURLOPT_POST, 1);//post&#x63d0;&#x4ea4;&#x65b9;&#x5f0f;
        $data = curl_exec($ch);//&#x8fd0;&#x884c;curl

        curl_close($ch);
        return $data;
    }
}


if(!function_exists('junhua_unicodeDecode')){
    function junhua_unicodeDecode($unicode_str){
        $unicode_str = preg_replace('/\&#x([\w]{4});/U', '\\u$1', $unicode_str);

        $json = '{"str":"'.$unicode_str.'"}';
        $arr = json_decode($json,true);

        if(empty($arr)) return '';
        return $arr['str'];
    }
}

if(!function_exists('junhua_jsAppJump')){
    function junhua_jsAppJump($refererurl){
        global $_G;
        
        $html = '';

        //&#x975e;APP&#x72b6;&#x6001;&#x4e0b; &#x624d;&#x9700;&#x8981;&#x8df3;&#x8f6c;
        if(!(IS_MAGA || IS_QF)){

            $junhua_base = $_G['cache']['plugin']['junhua_base'];

            $app_type = $junhua_base['app_type'];
            $qf_moblink = $junhua_base['qf_moblink'];

            $html .= "<script>\n";
            $html .= "var app_download_url = '".urlencode($junhua_base['app_download_url'])."';\n";
            $html .= "var referer_url = '".urlencode($refererurl)."';\n";
            $html .= "</script>\n";

            //&#x5343;&#x5e06;&#x72b6;&#x6001;&#x4e0b; &#x5148;&#x5f15;&#x5165;&#x5b89;&#x5353;&#x4e2d;&#x7684;moblink
            if($app_type == 2 && $qf_moblink){
                $html .= "<script src=\"//f.moblink.mob.com/3.0.1/moblink.js?appkey=".$qf_moblink."\"></script>\n";
            }

            $html .= "<script>\n";
            $html .= "function jsAppJump(btn){\n";
            $html .= "var isiOS = !!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);\n";

            //&#x9a6c;&#x7532;&#x914d;&#x7f6e;
            if($app_type == 1){
                if($junhua_base['maga_version'] >= '4.7.3' && $junhua_base['maga_siteid']){
                    $html .= "window.location.href = '".$junhua_base['maga_url']."/magshare/".$junhua_base['maga_siteid']."?jump_url='+referer_url+'&content_url='+app_download_url;\n";
                }else{
                    $html .= "window.location.href = '".$junhua_base['app_download_url']."';\n";
                }
            }

            if($app_type == 2){

                $html .= "if(isiOS){\n";
                $html .= "    window.location.href = 'http://".$junhua_base['qf_hostname'].".qianfanapi.com/".$junhua_base['qf_scheme']."://webview?url=".$refererurl."'\n";
                $html .= "}else{\n";
                $html .= "    MobLink([{\n";
                $html .= "        el: btn,\n";
                $html .= "        path: '/qianfan/webview',\n";
                $html .= "        params: {\n";
                $html .= "            url: '".$refererurl."'\n";
                $html .= "        }\n";
                $html .= "    }])\n";
                $html .= "}\n";
            }

            $html .= "}\n";
            $html .= "</script>\n";
        }

        return $html;
    }
}



if(!function_exists('junhua_jsLogin')){
    function junhua_jsLogin($refererurl){
        global $_G;
        
        $html = '';

        $html .= "<script>\n";
        $html .= "    function js_login(){\n";
        if(IS_MAGA){
            $html .= "        mag.toLogin(function(){\n";
            $html .= "            mag.newWin('".$refererurl."');\n";
            $html .= "            mag.setPageLife({\n";
            $html .= "                pageAppear: function(){\n";
            $html .= "                    window.location.reload(true);\n";
            $html .= "                },\n";
            $html .= "                pageDisappear: function(){}\n";
            $html .= "            });\n";
            $html .= "        });\n";
        }elseif(IS_QF){
            $html .= "            QFH5.jumpLogin(function(state, data){\n";
            $html .= "                window.location.reload(true);\n";
            $html .= "            });\n";
        }else{
            $html .= "        window.location.href='member.php?mod=logging&action=login';\n";
        }
        $html .= "        return false;\n";
        $html .= "    }\n";

        $html .= "</script>\n";

        return $html;
    }
}


if(!function_exists('junhua_jsToast')){
    function junhua_jsToast(){
        global $_G;
        
        $html = <<<html
        <script>
        function js_toast(type, msg, callback, delay){
            if ($('#js_toast').css('display') != 'none') {
                $('#js_toast').hide()
            };

            if(type == 'success'){
                $('#js_toast').find('i').prop('class', 'weui-icon_toast weui-icon-success-no-circle');
            }else if(type == 'loading'){
                $('#js_toast').find('i').prop('class', 'weui-loading weui-icon_toast');
            }else{
                $('#js_toast').find('i').prop('class', 'weui-icon_toast weui-icon-close-thin');
            }
            
            $('#js_toast').find('.weui-toast__content').html(msg);
            $('#js_toast').fadeIn(100);

            if(type != 'loading'){
                setTimeout(function () {
                    $('#js_toast').fadeOut(100);
                    if(typeof callback == 'function'){
                        callback()
                    }
                }, delay || 2000);
            }else{
                if(typeof callback == 'function'){
                    callback()
                }
            }
        }
        </script>

html;
        return $html;
    }
}


if(!function_exists('junhua_jsnicetime')){
    function junhua_jsnicetime(){
        global $junhua_base_lang;
        
        $html = <<<html
        <script>
        function junhua_js_nicetime(timestamp) {
            var timestamp = timestamp * 1000;
            var todaytimestamp = new Date().getTime()
            var time = todaytimestamp - timestamp;

            var ymd = new Date(timestamp);
            var tdymd = new Date(todaytimestamp);
            var ymdString = ymd.getFullYear()+''+ymd.getMonth()+''+ymd.getDate();
            var tdymdString = tdymd.getFullYear()+''+tdymd.getMonth()+''+tdymd.getDate();
            var yesymdString = new Date(todaytimestamp - 86400000);
            var weekymdString = new Date(todaytimestamp - 604800000);

            //&#x5f53;&#x5929;&#x7684;&#x5c55;&#x793a;&#x65f6;&#x5206;
            if(ymdString == tdymdString) {
                var hh = (ymd.getHours() < 10 ? '0' + ymd.getHours() : ymd.getHours()) + ':';
                var mm = (ymd.getMinutes() < 10 ? '0' + ymd.getMinutes() : ymd.getMinutes());
                return hh + mm;

            } else if(ymdString == yesymdString.getFullYear()+''+yesymdString.getMonth()+''+yesymdString.getDate()) {//&#x6628;&#x5929;&#x7684;&#x5c55;&#x793a;&#x6587;&#x5b57;&#x4e3a;&#x6628;&#x5929;
                var hh = (ymd.getHours() < 10 ? '0' + ymd.getHours() : ymd.getHours()) + ':';
                var mm = (ymd.getMinutes() < 10 ? '0' + ymd.getMinutes() : ymd.getMinutes());
                return '$junhua_base_lang[yes] ' +  hh + mm;
            } else if(ymdString > weekymdString.getFullYear()+''+weekymdString.getMonth()+''+weekymdString.getDate()) {//6&#x5929;&#x5185;
                var weekName = '';
                var w = ymd.getDay()
                switch (w) {
                    case 1:
                        weekName = '$junhua_base_lang[mon]';
                        break;
                    
                    case 2:
                        weekName = '$junhua_base_lang[tus]';
                        break;
                    
                    case 3:
                        weekName = '$junhua_base_lang[wed]';
                        break;
                    
                    case 4:
                        weekName = '$junhua_base_lang[tur]';
                        break;
                    
                    case 5:
                        weekName = '$junhua_base_lang[fri]';
                        break;
                    
                    case 6:
                        weekName = '$junhua_base_lang[sat]';
                        break;
                    
                    case 0:
                        weekName = '$junhua_base_lang[sun]';
                        break;
                }
                var hh = (ymd.getHours() < 10 ? '0' + ymd.getHours() : ymd.getHours()) + ':';
                var mm = (ymd.getMinutes() < 10 ? '0' + ymd.getMinutes() : ymd.getMinutes());

                return weekName+' '+ hh + mm;
            } else {
                var YY = ymd.getFullYear() + '-';
                var MM = (ymd.getMonth() + 1 < 10 ? '0' + (ymd.getMonth() + 1) : ymd.getMonth() + 1) + '-';
                var DD = (ymd.getDate() < 10 ? '0' + (ymd.getDate()) : ymd.getDate());
                var hh = (ymd.getHours() < 10 ? '0' + ymd.getHours() : ymd.getHours()) + ':';
                var mm = (ymd.getMinutes() < 10 ? '0' + ymd.getMinutes() : ymd.getMinutes());
                return YY + MM + DD +" "+hh + mm;
            }
        }

        </script>

html;
        return $html;
    }
}


if(!function_exists('junhua_jsApplink')){
    function junhua_jsApplink(){
        
        $html = '';

        if((IS_MAGA || IS_QF)){
            $html .= "<script>\n";
            if(IS_MAGA){
            $html .= "    mag.setTitle($('title').text());\n";
            }
            $html .= "    $(document).on('click',\"a.J-applink\",function(Event){\n";
            $html .= "        Event.stopPropagation();\n";
            $html .= "        var Url = $(this).attr('href');\n";
            $html .= "        if(Url.indexOf('tel:') < 0 && Url.indexOf('sms:') < 0){\n";
            if(IS_MAGA){
            $html .= "            mag.newWin(Url);\n";
            }elseif(IS_QF){
            $html .= "            QFH5.jumpNewWebview(Url);\n";
            }
            $html .= "            return false;\n";
            $html .= "        }\n";
            $html .= "    });\n";
            $html .= "</script>\n";
        }

        return $html;
    }
}


//&#x521b;&#x5efa;&#x552f;&#x4e00;&#x8ba2;&#x5355;&#x53f7;
if (!function_exists('junhua_getorderno')) {
    function junhua_getorderno($prefix = ''){
        return $prefix.date('ymd') . substr(time() , -5) . substr(microtime() , 2, 5);
    }
}


//&#x83b7;&#x53d6;&#x968f;&#x673a;&#x957f;&#x5ea6;&#x5b57;&#x7b26;&#x4e32;
if (!function_exists('junhua_randString')) {
    function junhua_randString($len=6, $type='',$addChars='') {
        $str ='';
        switch($type) {
            case 0:
                $chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.$addChars;
                break;
            case 1:
                $chars= str_repeat('0123456789',3);
                break;
            case 2:
                $chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.$addChars;
                break;
            case 3:
                $chars='abcdefghijklmnopqrstuvwxyz'.$addChars;
                break;
            default :
                // &#x9ed8;&#x8ba4;&#x53bb;&#x6389;&#x4e86;&#x5bb9;&#x6613;&#x6df7;&#x6dc6;&#x7684;&#x5b57;&#x7b26;oOLl&#x548c;&#x6570;&#x5b57;01&#xff0c;&#x8981;&#x6dfb;&#x52a0;&#x8bf7;&#x4f7f;&#x7528;addChars&#x53c2;&#x6570;
                $chars='ABCDEFGHIJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'.$addChars;
                break;
        }
        if($len>10 ) {//&#x4f4d;&#x6570;&#x8fc7;&#x957f;&#x91cd;&#x590d;&#x5b57;&#x7b26;&#x4e32;&#x4e00;&#x5b9a;&#x6b21;&#x6570;
            $chars= $type==1? str_repeat($chars,$len) : str_repeat($chars,5);
        }
            $chars   =   str_shuffle($chars);
            $str     =   substr($chars,0,$len);
        return $str;
    }
}
