<?php 

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

C::t('common_syscache')->delete('junhua_xrzw_system');
C::t('common_syscache')->delete('junhua_xrzw_setting');

$sql = <<<EOF
	DROP TABLE IF EXISTS `pre_junhua_xrzw`;
	DROP TABLE IF EXISTS `pre_junhua_xrzw_classify`;
	DROP TABLE IF EXISTS `pre_junhua_xrzw_users`;
	DROP TABLE IF EXISTS `pre_junhua_xrzw_verify`;
	DROP TABLE IF EXISTS `pre_junhua_xrzw_order`;
EOF;


runquery($sql);
$finish = true;
?>