<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$createtablesql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_junhua_xrzw` (
  `xrzw_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `classify_id` int(10) DEFAULT '0',
  `title` varchar(125) DEFAULT '',
  `faxian_time` int(10) unsigned DEFAULT '0',
  `province_id` varchar(16) DEFAULT '',
  `city_id` varchar(16) DEFAULT '',
  `area_id` varchar(16) DEFAULT '',
  `faxian_address` varchar(255) DEFAULT '',
  `address` varchar(255) DEFAULT '',
  `lat` varchar(32) DEFAULT '',
  `lng` varchar(32) DEFAULT '',
  `mobile` varchar(16) DEFAULT NULL,
  `lianxiren` varchar(64) DEFAULT '',
  `cover_img` varchar(256) DEFAULT '',
  `imgs` varchar(1000) DEFAULT '[]',
  `imgs_zl` varchar(1000) DEFAULT '[]',
  `miaoshu` varchar(1000) DEFAULT '',
  `names` varchar(100) DEFAULT '',
  `sex` tinyint(1) DEFAULT '0',
  `age` int(10) DEFAULT '0',
  `height` int(10) DEFAULT '0',
  `weight` int(10) DEFAULT '0',
  `jiguanids` varchar(256) DEFAULT '',
  `jiguan` varchar(255) DEFAULT '',
  `clicknum` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  `top_time` int(10) unsigned DEFAULT '0',
  `refresh_time` int(10) unsigned DEFAULT '0',
  `is_xunren` tinyint(1) DEFAULT '0',
  `share_num` int(10) DEFAULT '0',
  `is_ren` tinyint(1) unsigned DEFAULT '0',
  `is_enable` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`xrzw_id`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`classify_id`),
  KEY `is_enable` (`is_enable`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_xrzw_classify` (
  `classify_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classify_title` varchar(255) DEFAULT NULL,
  `pid` int(10) DEFAULT NULL,
  `classify_icon` varchar(200) DEFAULT NULL,
  `ordernum` int(10) DEFAULT '0',
  `fields` text,
  `is_xunren` tinyint(1) DEFAULT '0',
  `is_check` tinyint(1) unsigned DEFAULT '0',
  `check_uids` varchar(256) DEFAULT '',
  `check_text` varchar(256) DEFAULT '',
  `check_ts_type` tinyint(1) DEFAULT '0',
  `tpmsg_id` int(10) DEFAULT '0',
  `classify_nopic` varchar(256) DEFAULT '',
  `threshold_num` int(10) DEFAULT '0',
  `is_enable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`classify_id`),
  KEY `orderby` (`ordernum`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_xrzw_users` (
  `xuser_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT '0',
  `mobile` varchar(16) DEFAULT '',
  `openid` varchar(64) DEFAULT '',
  `unionid` varchar(64) DEFAULT '',
  `nickname` varchar(64) DEFAULT '',
  `sex` tinyint(1) DEFAULT '0',
  `language` varchar(32) DEFAULT '',
  `country` varchar(32) DEFAULT '',
  `province` varchar(32) DEFAULT '',
  `city` varchar(32) DEFAULT '',
  `headimgurl` varchar(256) DEFAULT '',
  `subscribe_time` int(11) unsigned DEFAULT '0',
  `unsubscribe_time` int(11) unsigned DEFAULT '0',
  `privilege` varchar(256) DEFAULT '',
  `subscribe` tinyint(1) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `last_time` int(11) unsigned DEFAULT '0',
  `is_enable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`xuser_id`),
  KEY `openid` (`openid`),
  KEY `unionid` (`unionid`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_junhua_xrzw_verify` (
  `verify_id` int(10) NOT NULL AUTO_INCREMENT,
  `verify_from` varchar(32) DEFAULT '',
  `verify_st` varchar(16) DEFAULT '',
  `is_verify` tinyint(1) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`verify_id`),
  KEY `verify_from` (`verify_from`) USING BTREE,
  KEY `verify_st` (`verify_st`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_junhua_xrzw_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `xrzw_id` int(10) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `total_amount` decimal(14,2) DEFAULT '0.00',
  `trade_no` varchar(64) DEFAULT '',
  `out_trade_no` varchar(64) DEFAULT '',
  `type` tinyint(1) DEFAULT '0',
  `top_num` int(10) unsigned DEFAULT '0',
  `paytype` tinyint(1) DEFAULT '0',
  `remark` varchar(256) DEFAULT '',
  `is_pay` tinyint(1) unsigned DEFAULT '0',
  `pay_time` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`order_id`),
  KEY `out_trade_no` (`out_trade_no`),
  KEY `user_id` (`user_id`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

runquery($createtablesql);


$updatesql = array (
    'junhua_xrzw' => array (
        'xrzw_id'        => array ('Field' => 'xrzw_id','Type' => 'int(10) unsigned','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),
        'user_id'        => array ('Field' => 'user_id','Type' => 'int(10) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
        'classify_id'    => array ('Field' => 'classify_id','Type' => 'int(10)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
        'title'          => array ('Field' => 'title','Type' => 'varchar(125)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'faxian_time'    => array ('Field' => 'faxian_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'province_id'    => array ('Field' => 'province_id','Type' => 'varchar(16)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'city_id'        => array ('Field' => 'city_id','Type' => 'varchar(16)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'area_id'        => array ('Field' => 'area_id','Type' => 'varchar(16)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'faxian_address' => array ('Field' => 'faxian_address','Type' => 'varchar(255)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'address'        => array ('Field' => 'address','Type' => 'varchar(255)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'lat'            => array ('Field' => 'lat','Type' => 'varchar(32)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'lng'            => array ('Field' => 'lng','Type' => 'varchar(32)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'mobile'         => array ('Field' => 'mobile','Type' => 'varchar(16)','Null' => 'YES','Key' => '','Default' => NULL,'Extra' => '',),
        'lianxiren'      => array ('Field' => 'lianxiren','Type' => 'varchar(64)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'cover_img'      => array ('Field' => 'cover_img','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'imgs'           => array ('Field' => 'imgs','Type' => 'varchar(1000)','Null' => 'YES','Key' => '','Default' => '[]','Extra' => '',),
        'imgs_zl'        => array ('Field' => 'imgs_zl','Type' => 'varchar(1000)','Null' => 'YES','Key' => '','Default' => '[]','Extra' => '',),
        'miaoshu'        => array ('Field' => 'miaoshu','Type' => 'varchar(1000)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'names'          => array ('Field' => 'names','Type' => 'varchar(100)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'sex'            => array ('Field' => 'sex','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'age'            => array ('Field' => 'age','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'height'         => array ('Field' => 'height','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'weight'         => array ('Field' => 'weight','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'jiguanids'      => array ('Field' => 'jiguanids','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'jiguan'         => array ('Field' => 'jiguan','Type' => 'varchar(255)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'clicknum'       => array ('Field' => 'clicknum','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'add_time'       => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'top_time'       => array ('Field' => 'top_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'refresh_time'   => array ('Field' => 'refresh_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'is_xunren'      => array ('Field' => 'is_xunren','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'share_num'      => array ('Field' => 'share_num','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'is_ren'         => array ('Field' => 'is_ren','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'is_enable'      => array ('Field' => 'is_enable','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
    ),
    'junhua_xrzw_classify' => array (
        'classify_id'    => array ('Field' => 'classify_id','Type' => 'int(10) unsigned','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),
        'classify_title' => array ('Field' => 'classify_title','Type' => 'varchar(255)','Null' => 'YES','Key' => '','Default' => NULL,'Extra' => '',),
        'pid'            => array ('Field' => 'pid','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => NULL,'Extra' => '',),
        'classify_icon'  => array ('Field' => 'classify_icon','Type' => 'varchar(200)','Null' => 'YES','Key' => '','Default' => NULL,'Extra' => '',),
        'ordernum'       => array ('Field' => 'ordernum','Type' => 'int(10)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
        'fields'         => array ('Field' => 'fields','Type' => 'text','Null' => 'YES','Key' => '','Default' => NULL,'Extra' => '',),
        'is_xunren'      => array ('Field' => 'is_xunren','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'is_check'       => array ('Field' => 'is_check','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'check_uids'     => array ('Field' => 'check_uids','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'check_text'     => array ('Field' => 'check_text','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'check_ts_type'  => array ('Field' => 'check_ts_type','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'tpmsg_id'       => array ('Field' => 'tpmsg_id','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'classify_nopic' => array ('Field' => 'classify_nopic','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'threshold_num'  => array ('Field' => 'threshold_num','Type' => 'int(10)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'is_enable'      => array ('Field' => 'is_enable','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    ),
    'junhua_xrzw_order' => array (
        'order_id'     => array ('Field' => 'order_id','Type' => 'int(10) unsigned','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),
        'xrzw_id'      => array ('Field' => 'xrzw_id','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'user_id'      => array ('Field' => 'user_id','Type' => 'int(10) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
        'total_amount' => array ('Field' => 'total_amount','Type' => 'decimal(14,2)','Null' => 'YES','Key' => '','Default' => '0.00','Extra' => '',),
        'trade_no'     => array ('Field' => 'trade_no','Type' => 'varchar(64)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'out_trade_no' => array ('Field' => 'out_trade_no','Type' => 'varchar(64)','Null' => 'YES','Key' => 'MUL','Default' => '','Extra' => '',),
        'type'         => array ('Field' => 'type','Type' => 'tinyint(1)','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
        'top_num'      => array ('Field' => 'top_num','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'paytype'      => array ('Field' => 'paytype','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'remark'       => array ('Field' => 'remark','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'is_pay'       => array ('Field' => 'is_pay','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'pay_time'     => array ('Field' => 'pay_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'add_time'     => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    ),
    'junhua_xrzw_users' => array (
        'xuser_id'         => array ('Field' => 'xuser_id','Type' => 'int(11)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),
        'user_id'          => array ('Field' => 'user_id','Type' => 'int(11) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
        'mobile'           => array ('Field' => 'mobile','Type' => 'varchar(16)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'openid'           => array ('Field' => 'openid','Type' => 'varchar(64)','Null' => 'YES','Key' => 'MUL','Default' => '','Extra' => '',),
        'unionid'          => array ('Field' => 'unionid','Type' => 'varchar(64)','Null' => 'YES','Key' => 'MUL','Default' => '','Extra' => '',),
        'nickname'         => array ('Field' => 'nickname','Type' => 'varchar(64)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'sex'              => array ('Field' => 'sex','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'language'         => array ('Field' => 'language','Type' => 'varchar(32)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'country'          => array ('Field' => 'country','Type' => 'varchar(32)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'province'         => array ('Field' => 'province','Type' => 'varchar(32)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'city'             => array ('Field' => 'city','Type' => 'varchar(32)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'headimgurl'       => array ('Field' => 'headimgurl','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'subscribe_time'   => array ('Field' => 'subscribe_time','Type' => 'int(11) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'unsubscribe_time' => array ('Field' => 'unsubscribe_time','Type' => 'int(11) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'privilege'        => array ('Field' => 'privilege','Type' => 'varchar(256)','Null' => 'YES','Key' => '','Default' => '','Extra' => '',),
        'subscribe'        => array ('Field' => 'subscribe','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'add_time'         => array ('Field' => 'add_time','Type' => 'int(11) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'last_time'        => array ('Field' => 'last_time','Type' => 'int(11) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'is_enable'        => array ('Field' => 'is_enable','Type' => 'tinyint(1)','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
    ),
    'junhua_xrzw_verify' => array (
        'verify_id'   => array ('Field' => 'verify_id','Type' => 'int(10)','Null' => 'NO','Key' => 'PRI','Default' => NULL,'Extra' => 'auto_increment',),
        'verify_from' => array ('Field' => 'verify_from','Type' => 'varchar(32)','Null' => 'YES','Key' => 'MUL','Default' => '','Extra' => '',),
        'verify_st'   => array ('Field' => 'verify_st','Type' => 'varchar(16)','Null' => 'YES','Key' => 'MUL','Default' => '','Extra' => '',),
        'is_verify'   => array ('Field' => 'is_verify','Type' => 'tinyint(1) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),
        'user_id'     => array ('Field' => 'user_id','Type' => 'int(10) unsigned','Null' => 'YES','Key' => 'MUL','Default' => '0','Extra' => '',),
        'add_time'    => array ('Field' => 'add_time','Type' => 'int(10) unsigned','Null' => 'YES','Key' => '','Default' => '0','Extra' => '',),),
);

foreach ($updatesql as $updatesql_key => $updatesql_value) {
    # code...

    $columns_news = $updatesql_value;
    $columns = DB::fetch_all('SHOW COLUMNS FROM %t', array($updatesql_key));
    $columns_ary = array();

    foreach ($columns as $key => $value) {
        if(!isset($columns_news[$value['Field']])){
            $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` DROP COLUMN `'.$value['Field'].'`;';
            runquery($sql);
        }else{
            $columns_ary[$value['Field']] = $value;
        }
    }

    foreach ($columns_news as $key => $value) {
        //&#x65b0;&#x589e;&#x5b57;&#x6bb5;
        if(!isset($columns_ary[$key])){
            $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` ADD COLUMN `'.$key.'` '.$value['Type'].' '.($value['Null'] == 'YES' ? 'NULL' : '').' DEFAULT "'.$value['Default'].'";';
            runquery($sql);
        }else{

            //&#x4fee;&#x6539;&#x5b57;&#x6bb5;
            if($columns_ary[$key]['Field'] != $value['Field'] || $columns_ary[$key]['Type'] != $value['Type'] || $columns_ary[$key]['Default'] != $value['Default'] ){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` MODIFY COLUMN `'.$key.'` '.$value['Type'].' '.($value['Null'] == 'YES' ? 'NULL' : '').' DEFAULT "'.$value['Default'].'";';
                runquery($sql);
            }

            //&#x589e;&#x52a0;&#x7d22;&#x5f15;
            if($columns_ary[$key]['Key'] == '' && $value['Key'] == 'MUL'){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` ADD INDEX `'.$key.'` (`'.$key.'`) USING BTREE;';
                runquery($sql);
            }

            //&#x5220;&#x9664;&#x7d22;&#x5f15;
            if($columns_ary[$key]['Key'] == 'MUL' && $value['Key'] == ''){
                $sql = 'ALTER TABLE `pre_'.$updatesql_key.'` DROP INDEX `'.$key.'`;'; //&#x5220;&#x9664;&#x7d22;&#x5f15;
                runquery($sql);
            }
        }

    }
}

$finish = true;