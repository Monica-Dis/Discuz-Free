<?php 

    define('CURSCRIPT', 'api');
    define('DISABLEXSSCHECK', true); 
    define('DISCUZROOT', substr(dirname(__FILE__), 0, -25));
    chdir(DISCUZROOT);

    define('CURMODULE', 'junhua_xrzw');

    $_GET['id'] = 'junhua_xrzw';
    
    require './source/class/class_core.php';

    $discuz = C::app();

	$cachelist = array('plugin');

	$discuz->cachelist = $cachelist;
	$discuz->init();

	//&#x8bbe;&#x7f6e;&#x65f6;&#x533a;
	@date_default_timezone_set('Etc/GMT'.($_G['setting']['timeoffset'] > 0 ? '-' : '+').(abs($_G['setting']['timeoffset'])));

	include_once('./source/plugin/junhua_base/common/common.php');
	include_once('./source/plugin/junhua_base/libs/model.class.php');
	include_once('./source/plugin/junhua_base/func/function.php');
	include_once('./source/plugin/junhua_base/libs/app.class.php');

	$junhua_base_config		= $_G['cache']['plugin']['junhua_base'];
	$junhua_xrzw_config		= $_G['cache']['plugin']['junhua_xrzw'];

	loadcache('junhua_xrzw_setting');
	$junhua_xrzw_setting = dunserialize($_G['cache']['junhua_xrzw_setting']);

    $junhuaApp = new junhua_App($junhua_base_config, $junhua_xrzw_setting);

    $out_trade_no = junhua_I('o', '');
    $t            = junhua_I('t', '');
    $sign         = junhua_I('sign', '');

    $param = array(
        'out_trade_no' => $out_trade_no,
        't'            => $t,
        'sign'         => $sign,
    );

    if($junhuaApp->getMagaOrderVerify($param)){
        $xrzwModel = new junhua_model('xrzw');
        $OrderModel = new junhua_model('xrzwOrder');

        $orderInfo = $OrderModel->find(array(
            'is_pay'        => 0,
            'out_trade_no'  => $out_trade_no,
        ));

        if($orderInfo){
            $OrderModel->save(array(
                'order_id'      => $orderInfo['order_id']
            ),array(
                'is_pay'    => 1,
                'trade_no'  => $transaction_id,
                'pay_time'  => $_G['timestamp'],
            ));

            $xrzwInfo = $xrzwModel->find(array(
                'xrzw_id'        => $orderInfo['xrzw_id'],
            ));

            //&#x5224;&#x65ad;&#x652f;&#x4ed8;&#x4e4b;&#x540e;&#x7684;&#x7c7b;&#x578b;
            if($orderInfo['type'] == 1){
                $xrzwModel->save(array(
                    'xrzw_id'   => $orderInfo['xrzw_id']
                ),array(
                    'refresh_time'  => $_G['timestamp']
                ));
            }elseif($orderInfo['type'] == 2){

                //&#x83b7;&#x53d6;&#x7f6e;&#x9876;&#x5929;&#x6570;
                $selectString = str_replace("\r", "", $junhua_xrzw_setting['top_setting']);
                $selectStringAry = array_filter(explode("\n", $selectString));

                $topAry = array();
                foreach ($selectStringAry as $key => $value) {
                    $sub = explode("=", $value);
                    $topAry[] = array(
                        'day' => $sub[0],
                        'money' => $sub[1] 
                    );
                }

                $top_time = $xrzwInfo['top_time'];
                if($xrzwInfo['top_time'] > $_G['timestamp']){
                    $top_time = $xrzwInfo['top_time'] + $topAry[$orderInfo['top_num']]['day'] * 86400;
                }else{
                    $top_time = $_G['timestamp'] + $topAry[$orderInfo['top_num']]['day'] * 86400;
                }


                $xrzwModel->save(array(
                    'xrzw_id'   => $orderInfo['xrzw_id']
                ),array(
                    'top_time'  => $top_time 
                ));
            }
        }
    }
//From: Dism��taobao��com
?>