<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$UsersModel = new junhua_model('xrzwUsers');
$classifyModel = new junhua_model('xrzwClassify');

//&#x5982;&#x679c;&#x6709;&#x767b;&#x5f55;&#x4fe1;&#x606f; &#x5148;&#x5165;&#x5e93;
if($uid){
    //&#x5224;&#x65ad;&#x662f;&#x5426;&#x5b58;&#x5728;
    $userInfo = $UsersModel->find(array('user_id' => $uid));
    if(!$userInfo){
        $UsersModel->add(array('user_id' => $uid, 'is_enable' => 1));
        $userInfo = $UsersModel->find(array('user_id' => $uid));
    }
}

$junhua_shareurl = $refererurl;

//&#x5f00;&#x542f;&#x5206;&#x4eab;
if(IS_WEIXIN){
    include_once('source/plugin/junhua_base/jssdk/weixin_jssdk.php');
    $weixin_appid = $junhua_xrzw_setting['weixin_appid'] ? trim($junhua_xrzw_setting['weixin_appid']) : trim($junhua_base_config['weixin_appid']);
    $weixin_appsecret = $junhua_xrzw_setting['weixin_appsecret'] ? trim($junhua_xrzw_setting['weixin_appsecret']) : trim($junhua_base_config['weixin_appsecret']);

    if($weixin_appid && $weixin_appsecret){
        $jssdk = new WEIXIN_JSSDK($weixin_appid, $weixin_appsecret);
        $signPackage = $jssdk->getSignPackage();
    }
}


//&#x70ae;&#x7070;
if($junhua_xrzw_setting['weixin_paohui_url']){
    $paohuiUrl = explode("\n", $junhua_xrzw_setting['weixin_paohui_url']);
    $junhua_shareurl = str_replace($_G['siteurl'], $paohuiUrl[array_rand($paohuiUrl)]."/", $junhua_shareurl);
}

$xrzw_mustlogin_open = $junhua_xrzw_setting['xrzw_mustlogin_open'];

//&#x83b7;&#x53d6;&#x9a6c;&#x7532;&#x767b;&#x5f55;
if(IS_MAGA){
    if(!$uid){

        $junhuaApp = new junhua_App($junhua_base_config, $junhua_xrzw_setting);
        $r = $junhuaApp->getMagaUserInfo();

        if($r['data']['user_id'] > 0){

            $member = getuserbyuid($r['data']['user_id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }

            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
        }else{
            //&#x5f3a;&#x5236;&#x767b;&#x5f55; &#x5fc5;&#x987b;&#x767b;&#x5f55;&#x624d;&#x53ef;&#x4ee5;&#x8bbf;&#x95ee;
            if($xrzw_mustlogin_open == 1){
                exit('<script src="https://static.app1.magcloud.net/public/static/dest/js/libs/magjs-x.js"></script><script>
                    mag.toLogin(function(){
                        top.location.href="' . $refererurl . '";
                        mag.newWin(\''.$refererurl.'\');
                        mag.setPageLife({
                            pageAppear: function(){
                                window.location.reload(true);
                            },
                            pageDisappear: function(){}
                        });
                    });
                    </script>'); 
            }
        }
    }
}elseif(IS_QF){
    if(!$uid){

        $junhuaApp = new junhua_App($junhua_base_config, $junhua_xrzw_setting);
        $r = $junhuaApp->getQfUserInfo();

        if($r['data']['id'] > 0){

            $member = getuserbyuid($r['data']['id'], 1);
            if (!$member) {
                dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
                exit();
            }

            require_once libfile('function/member');
            $cookietime = 1296000;
            setloginstatus($member, $cookietime);
            exit('<script>window.location.reload(true);</script>');
        }else{
            //&#x5f3a;&#x5236;&#x767b;&#x5f55; &#x5fc5;&#x987b;&#x767b;&#x5f55;&#x624d;&#x53ef;&#x4ee5;&#x8bbf;&#x95ee;
            if($xrzw_mustlogin_open == 1){
                exit('<script>
                function QFH5ready(){
                    QFH5.jumpLogin(function(state, data){
                        window.location.reload(true);
                    });
                }
                </script>'); 
            }
        }
    }
}else{

    if(!$uid && $xrzw_mustlogin_open){
        dheader('Location:' . $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl));
        exit();
    }
}

//&#x83b7;&#x53d6;&#x6240;&#x6709;&#x7684;&#x5206;&#x7c7b;
$classifyList = $classifyModel->select(array('is_enable' => 1), 'classify_id,classify_title,classify_icon,ordernum,is_xunren,fields', 'ordernum desc, classify_id desc', 0, 0, true);