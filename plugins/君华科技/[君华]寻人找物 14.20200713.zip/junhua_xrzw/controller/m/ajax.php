<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!in_array($a, array('getList', 'getMyList', 'fabu', 'share', 'getsmscode', 'bindmobile', 'finish', 'audit'
, 'top', 'refresh'
))){
    $a = 'getList';
}


$xrzwModel = new junhua_model('xrzw');
$UsersModel = new junhua_model('xrzwUsers');
$classifyModel = new junhua_model('xrzwClassify');
$VerifyModel = new junhua_model('xrzwVerify');
$OrderModel = new junhua_model('xrzwOrder');

if($a == 'getList'){

    if(IS_AJAX){
        $page = junhua_I('page/s', 1);
        $type = junhua_I('type/s', -1);
        $type = $type + 1;

        $perpage = 10;
        if($page < 1) $page = 1;
        $start = ($page-1)*$perpage;

        $where = array(
            'is_ren'    => 0,
            'is_enable' => 1,
        );

        if($junhua_xrzw_setting['xrzw_isren_show'] == 1){
            unset($where['is_ren']);
        }

        if($type){
            $where['classify_id'] = $type-1;
        }

        $total = $xrzwModel->count($where);
        $xrzwList = $xrzwModel->select($where, '*', 'top_time desc, refresh_time desc, xrzw_id desc', $start, $perpage);
        $classifyList = $classifyModel->select(array('is_enable' => 1), 'classify_id,fields,classify_nopic', 'classify_id desc', 0, 0, true);

        foreach ($xrzwList as $key => $value) {
            //&#x5224;&#x65ad;&#x7f6e;&#x9876;&#x4e4b;&#x95f4;
            if($value['top_time'] < $_G['timestamp']){
                $xrzwModel->save(array(
                    'xrzw_id'   => $value['xrzw_id']
                ),array(
                    'top_time'  => 0
                ));
            }

            $xrzwList[$key]['headimgurl'] = avatar($value['user_id'], 'small', true);
            $xrzwList[$key]['nicetime'] = junhua_nicetime($value['add_time']);
            $xrzwList[$key]['faxian_time'] = date('Y-m-d', $value['faxian_time']);
            $xrzwList[$key]['imgs'] = json_decode($value['imgs']);
            $xrzwList[$key]['fields'] = dunserialize($classifyList[$value['classify_id']]['fields']);
            $xrzwList[$key]['classify_nopic'] = $classifyList[$value['classify_id']]['classify_nopic'] ? $classifyList[$value['classify_id']]['classify_nopic'] : 'source/plugin/junhua_xrzw/static/m/img/nopic.jpg';
        }

        $data = array (
            'lists'     => $xrzwList,
            'pageCount' => ceil($total/$perpage),
            'count'     => $total,
            'code'      => 0,
        );

        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}elseif($a == 'getMyList'){

    if(IS_AJAX){
        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        $page = junhua_I('page/s', 1);
        $type = junhua_I('type/s', 1);

        $perpage = 10;
        if($page < 1) $page = 1;
        $start = ($page-1)*$perpage;

        $where = array(
            'user_id' => $uid,
        );

        if($type == 1){

        }elseif($type == 2){
            $where['is_enable'] = 1;
        }elseif($type == 3){
            $where['is_enable'] = 0;
        }

        $total = $xrzwModel->count($where);
        $xrzwList = $xrzwModel->select($where, '*', 'top_time desc, refresh_time desc, xrzw_id desc', $start, $perpage);

        $classifyList = $classifyModel->select(array('is_enable' => 1), 'classify_id,fields,classify_nopic', 'classify_id desc', 0, 0, true);

        foreach ($xrzwList as $key => $value) {
            //&#x5224;&#x65ad;&#x7f6e;&#x9876;&#x4e4b;&#x95f4;
            if($value['top_time'] < $_G['timestamp']){
                $xrzwModel->save(array(
                    'xrzw_id'   => $value['xrzw_id']
                ),array(
                    'top_time'  => 0
                ));
            }

            $xrzwList[$key]['headimgurl'] = avatar($value['user_id'], 'small', true);
            $xrzwList[$key]['nicetime'] = junhua_nicetime($value['add_time']);
            $xrzwList[$key]['faxian_time'] = date('Y-m-d', $value['faxian_time']);
            $xrzwList[$key]['imgs'] = json_decode($value['imgs']);
            $xrzwList[$key]['fields'] = dunserialize($classifyList[$value['classify_id']]['fields']);
            $xrzwList[$key]['classify_nopic'] = $classifyList[$value['classify_id']]['classify_nopic'] ? $classifyList[$value['classify_id']]['classify_nopic'] : 'source/plugin/junhua_xrzw/static/m/img/nopic.jpg';
        }

        $data = array (
            'lists'     => $xrzwList,
            'pageCount' => ceil($total/$perpage),
            'count'     => $total,
            'code'      => 0,
        );

        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}elseif($a == 'fabu'){

    if(IS_AJAX){
        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        //&#x5224;&#x65ad;&#x6240;&#x6709;&#x7684;&#x5185;&#x5bb9;
        $classify_id    = junhua_I('classify_id/d', 0);
        $title          = junhua_I('title', '');
        $province_id    = junhua_I('province_id', '');
        $city_id        = junhua_I('city_id', '');
        $area_id        = junhua_I('area_id', '');
        $faxian_address = junhua_I('faxian_address', '');
        $address        = junhua_I('address', '');
        $faxian_time    = junhua_I('faxian_time', '');
        $mobile         = junhua_I('mobile', '');
        $lianxiren      = junhua_I('lianxiren', '');
        $miaoshu        = junhua_I('miaoshu', '');
        $imgs           = junhua_I('imgs/a', array());
        $imgs_zl        = junhua_I('imgs_zl/a', array());

        $names     = junhua_I('names', '');
        $sex       = junhua_I('sex/d', 0);
        $age       = junhua_I('age/d', 0);
        $height    = junhua_I('height/d', 0);
        $weight    = junhua_I('weight/d', 0);
        $xunren    = junhua_I('xunren/d', 0);
        $jiguanid1 = junhua_I('jiguanid1', '');
        $jiguanid2 = junhua_I('jiguanid2', '');
        $jiguan    = junhua_I('jiguan', '');


        $faxian_time = strtotime($faxian_time);

        $data = array(
            'user_id'        => $uid,
            'classify_id'    => $classify_id,
            'title'          => $title,
            'faxian_time'    => $faxian_time,
            'province_id'    => $province_id,
            'city_id'        => $city_id,
            'area_id'        => $area_id,
            'faxian_address' => $faxian_address,
            'address'        => $address,
            'mobile'         => $mobile,
            'lianxiren'      => $lianxiren,
            'cover_img'      => $imgs[0],
            'imgs'           => json_encode($imgs),
            'imgs_zl'        => json_encode($imgs_zl),
            'miaoshu'        => $miaoshu,
            
            'names'          => $names,
            'sex'            => $sex,
            'age'            => $age,
            'height'         => $height,
            'weight'         => $weight,
            'is_xunren'      => $xunren,
            'jiguanids'      => serialize(array($jiguanid1, $jiguanid2)),
            'jiguan'         => $jiguan,
            
            'clicknum'       => 0,
            'add_time'       => $_G['timestamp'],
            'refresh_time'   => $_G['timestamp'],
            'is_enable'      => 0,
        );

        $msg = '&#x7b49;&#x5f85;&#x5ba1;&#x6838;';


        $classifyInfo = $classifyModel->find(array('classify_id' => $classify_id), 'is_check,check_uids,check_text,check_ts_type,tpmsg_id,threshold_num');


        //&#x5982;&#x679c;&#x662f;&#x7ba1;&#x7406;&#x5458;&#x53d1;&#x5e03; &#x76f4;&#x63a5;&#x5ffd;&#x7565;
        if(!in_array($uid, $admin_lists)){
            //&#x5224;&#x65ad;&#x6b21;&#x6570;
            if($junhua_xrzw_setting['threshold_num']){
                //&#x67e5;&#x8be2;&#x53d1;&#x5e03;&#x7684;&#x6b21;&#x6570;
                $xrzwNum = $xrzwModel->count(array(
                    'user_id'     => $uid,
                    'is_ren'      => 0,
                    'is_enable'   => 1,
                ));

                $maxNum = (int) $junhua_xrzw_setting['threshold_num'];

                //&#x5224;&#x65ad;&#x6570;&#x91cf;
                if($xrzwNum >= $maxNum){
                    $data = array('code' => 0, 'msg' => '&#x60a8;&#x6700;&#x591a;&#x53ea;&#x80fd;&#x53d1;&#x5e03;'.$maxNum.'&#x6761;&#x4fe1;&#x606f;');
                    junhua_ajaxReturn($data);
                }

            }

            if($classifyInfo['threshold_num']){
                //&#x67e5;&#x8be2;&#x53d1;&#x5e03;&#x7684;&#x6b21;&#x6570;
                $xrzwNum = $xrzwModel->count(array(
                    'user_id'     => $uid,
                    'classify_id' => $classify_id,
                    'is_ren'      => 0,
                    'is_enable'   => 1,
                ));

                $maxNum = (int) $classifyInfo['threshold_num'];

                //&#x5224;&#x65ad;&#x6570;&#x91cf;
                if($xrzwNum >= $maxNum){
                    $data = array('code' => 0, 'msg' => '&#x5f53;&#x524d;&#x5206;&#x7c7b;&#x60a8;&#x6700;&#x591a;&#x53ea;&#x80fd;&#x53d1;&#x5e03;'.$maxNum.'&#x6761;&#x4fe1;&#x606f;');
                    junhua_ajaxReturn($data);
                }

            }
        }

        if($classifyInfo['is_check'] == 1){
            $data['is_enable'] = 1;
            $msg = '&#x53d1;&#x5e03;&#x6210;&#x529f;';
        }

        $xrzwid = $xrzwModel->add($data);

        if($classifyInfo['check_ts_type'] == 1 && $classifyInfo['check_uids']){
            $check_uids = explode(',', $classifyInfo['check_uids']);
            $junhuaApp = new junhua_App($junhua_base_config, $junhua_xrzw_setting);
            foreach ($check_uids as $key => $value) {

                $check_text = str_replace(
                array(
                    '[title]',
                    '[faxian_time]',
                    '[faxian_address]',
                    '[mobile]',
                    '[lianxiren]',
                    '[names]',
                    '[sex]',
                    '[age]',
                    '[height]',
                    '[weight]',
                    '[address]',
                    '[miaoshu]',
                    '[link]',
                    '[jiguan]'
                ),
                array(
                    $data['title'],
                    date('Y-m-d', $data['faxian_time']),
                    $data['faxian_address'],
                    $data['mobile'],
                    $data['lianxiren'],
                    $data['names'],
                    junhua_utf82gbk(junhua_unicodeDecode($data['sex'] == 1 ? '&#x7537;' : '&#x5973;')),
                    $data['age'],
                    $data['height'],
                    $data['weight'],
                    $data['address'],
                    $data['miaoshu'],
                    $_G['siteurl'] . junhua_url('m/xrzw/detail', 'xrzwid='.$xrzwid, 1),
                    $data['jiguan']
                ), $classifyInfo['check_text']);

                $content = array(
                    'type'   => 'text',
                    'content' => $check_text,
                );

                $junhuaApp->sendMagaTemplate($value, $content);
            }

        }elseif($classifyInfo['check_ts_type'] == 3 && $classifyInfo['check_uids'] && $junhua_base_config['weixin_table']){
            
            include_once('source/plugin/junhua_base/libs/weixin/weixin_sdk.php');

            $weixin_appid = $junhua_xrzw_setting['weixin_appid'] ? trim($junhua_xrzw_setting['weixin_appid']) : trim($junhua_base_config['weixin_appid']);
            $weixin_appsecret = $junhua_xrzw_setting['weixin_appsecret'] ? trim($junhua_xrzw_setting['weixin_appsecret']) : trim($junhua_base_config['weixin_appsecret']);

            $weixin_table  = $junhua_base_config['weixin_table'];
            $weixin_tables = explode(',', $weixin_table);
            $tableName     = str_replace(DB::object()->tablepre, '', $weixin_tables[0]);
            $uidField      = $weixin_tables[1];
            $openidField   = $weixin_tables[2];

            if($weixin_appid && $weixin_appsecret && $tableName && $uidField && $openidField){

                $check_uids = explode(',', $classifyInfo['check_uids']);
                $wxTableModel = new junhua_model($tableName, '');

                //&#x83b7;&#x53d6;&#x6a21;&#x7248;&#x6d88;&#x606f;
                $tpmsgSettingModel = new junhua_model('tpmsgSetting');
                
                $weixin_sdk = new WEIXIN_SDK($weixin_appid, $weixin_appsecret);


                foreach ($check_uids as $key => $value) {

                    //&#x67e5;&#x8be2;openid
                    $openid = $wxTableModel->getField(array(
                        $uidField => $value
                    ), $openidField);

                    $where = array(
                        'plugin_name' => CURMODULE,
                        'is_enable'   => 1,
                        'setting_id'  => $classifyInfo['tpmsg_id'],
                    );

                    $tpmsgInfo = $tpmsgSettingModel->find($where);

                    if($openid && $tpmsgInfo){

                        $mbdata   = array();
                        $template = dunserialize($tpmsgInfo['template']);
                        $color    = dunserialize($tpmsgInfo['color']);

                        foreach ($template as $k => $v) {
                            $v = str_replace(
                                array(
                                    '[title]',
                                    '[faxian_time]',
                                    '[faxian_address]',
                                    '[mobile]',
                                    '[lianxiren]',
                                    '[names]',
                                    '[sex]',
                                    '[age]',
                                    '[height]',
                                    '[weight]',
                                    '[address]',
                                    '[miaoshu]',
                                    '[link]',
                                    '[jiguan]'
                                ),
                                array(
                                    $data['title'],
                                    date('Y-m-d', $data['faxian_time']),
                                    $data['faxian_address'],
                                    $data['mobile'],
                                    $data['lianxiren'],
                                    $data['names'],
                                    junhua_utf82gbk(junhua_unicodeDecode($data['sex'] == 1 ? '&#x7537;' : '&#x5973;')),
                                    $data['age'],
                                    $data['height'],
                                    $data['weight'],
                                    $data['address'],
                                    $data['miaoshu'],
                                    $_G['siteurl'] . junhua_url('m/xrzw/detail', 'xrzwid='.$xrzwid, 1),
                                    $data['jiguan']
                                ), $v);

                            $mbdata[$k]['value'] = junhua_gbk2utf8($v);
                            $mbdata[$k]['color'] = $color[$k];
                        }

                        $postData = array(
                           "touser" => $openid,
                           "template_id" => $tpmsgInfo['template_id'],
                           "url" => $_G['siteurl'] . junhua_url('m/xrzw/detail', 'xrzwid='.$xrzwid, 1),
                           "data" => $mbdata
                        );

                        $weixin_sdk->template_send($postData);
                    }
                }

            }

        }


        $data = array('code' => 2, 'msg' => $msg);
        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}elseif($a == 'share'){

    if(IS_AJAX){
        $xrzwid = junhua_I('xrzwid/d', 0);

        $where = array();
        $where['xrzw_id'] = $xrzwid;

        $xrzwInfo = $xrzwModel->find($where);

        if($xrzwInfo){
            $xrzwModel->setInc(array('xrzw_id' => $xrzwid), 'share_num');
        }


        $data = array('code' => 0, 'msg' => '&#x611f;&#x8c22;&#x60a8;&#x7684;&#x7231;&#x5fc3;&#x652f;&#x6301;');
        junhua_ajaxReturn($data);

    }else{
        exit;
    }

}elseif($a == 'getsmscode'){

    if(IS_AJAX){

        if(!$uid){
            $data = array('code' => 0, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        $mobile = junhua_I('mobile', '');
        $mobile = trim($mobile);

        if(!$mobile){
            junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x8bf7;&#x586b;&#x5199;&#x624b;&#x673a;&#x53f7;&#x7801;'));
        }

        $userInfo = $UsersModel->find(array('user_id' => $uid));

        //&#x67e5;&#x8be2;&#x662f;&#x5426;&#x5df2;&#x7ecf;&#x7ed1;&#x5b9a;
        if($userInfo['mobile']){
            junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x60a8;&#x5df2;&#x7ed1;&#x5b9a;&#x8fc7;&#x624b;&#x673a;&#x53f7;&#xff01;'));
        }

        //&#x67e5;&#x8be2;&#x9a8c;&#x8bc1;&#x7801;&#x662f;&#x5426;&#x88ab;&#x7528;&#x8fc7;
        $where = array(
            'verify_from' => $mobile,
            'user_id'     => $uid,
            'is_verify'   => 0
        );

        $VerifyInfo = $VerifyModel->find($where, '*', 'verify_id desc');

        if($VerifyInfo){
            //&#x63a7;&#x5236;&#x53d1;&#x9001;&#x7684;&#x9891;&#x7387;
            $isAllowTime = $VerifyInfo['add_time'] + 60 - $_G['timestamp'];
            if($isAllowTime > 0 ){
                $ary = array(
                    'code'      => 1,
                    'msg'       => '&#x8bf7;&#x8fc7;'.$isAllowTime.'&#x79d2;&#x4e4b;&#x540e;&#x518d;&#x70b9;&#x51fb;&#x53d1;&#x9001;',
                );

                junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x8bf7;&#x8fc7;'.$isAllowTime.'&#x79d2;&#x4e4b;&#x540e;&#x518d;&#x70b9;&#x51fb;&#x53d1;&#x9001;',));
            }

            $randNum = rand(100000,999999);
            $data = array(
                'verify_from' => $mobile,
                'verify_st'   => $randNum,
                'user_id'     => $uid,
                'add_time'    => $_G['timestamp'],
            );
            
            $VerifyModel->add($data);

        }else{
            $randNum = rand(100000,999999);
            $data = array(
                'verify_from' => $mobile,
                'verify_st'   => $randNum,
                'user_id'     => $uid,
                'add_time'    => $_G['timestamp'],
            );
            $VerifyModel->add($data);
        }

        $smssetting = array(
            'type'            => 'dayu',
            'AccessKeyID'     => $junhua_base_config['dayu_AccessKeyID'],
            'AccessKeySecret' => $junhua_base_config['dayu_AccessKeySecret'],
            'TemplateCode'    => $junhua_xrzw_setting['dayu_TemplateCode'],
            'FreeSignName'    => junhua_gbk2utf8($junhua_xrzw_setting['dayu_FreeSignName']),
        );

        $result = junhua_sendsms($smssetting, $mobile, array('code' => $randNum));

        if($result['Code'] == 'OK'){
            junhua_ajaxReturn(array('code' => 1, 'msg' => '&#x53d1;&#x9001;&#x6210;&#x529f;'));
        }else{
            junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x53d1;&#x9001;&#x5931;&#x8d25;'));
        }

    }else{
        exit;
    }

}elseif($a == 'bindmobile'){

    if(IS_AJAX){

        if(!$uid){
            $data = array('code' => 0, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        $mobile = junhua_I('mobile', '');
        $mobile = trim($mobile);

        $code = junhua_I('code', '');
        $code = trim($code);

        if(!$mobile){
            junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x8bf7;&#x586b;&#x5199;&#x624b;&#x673a;&#x53f7;&#x7801;'));
        }

        if(!$code){
            junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x8bf7;&#x586b;&#x5199;&#x9a8c;&#x8bc1;&#x7801;'));
        }

        $userInfo = $UsersModel->find(array('user_id' => $uid));

        //&#x67e5;&#x8be2;&#x662f;&#x5426;&#x5df2;&#x7ecf;&#x7ed1;&#x5b9a;
        if($userInfo['mobile']){
            junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x60a8;&#x5df2;&#x7ed1;&#x5b9a;&#x8fc7;&#x624b;&#x673a;&#x53f7;&#xff01;'));
        }

        //&#x67e5;&#x8be2;&#x9a8c;&#x8bc1;&#x7801;&#x662f;&#x5426;&#x88ab;&#x7528;&#x8fc7;
        $where = array(
            'verify_from' => $mobile,
            'verify_st'   => $code,
            'user_id'     => $uid,
            'is_verify'   => 0
        );

        $VerifyInfo = $VerifyModel->find($where, '*', 'verify_id desc');

        if($VerifyInfo){
            //&#x63a7;&#x5236;&#x53d1;&#x9001;&#x7684;&#x9891;&#x7387;
            $isAllow = $VerifyInfo['add_time'] + 900 - $_G['timestamp'];
            if($isAllow > 0 ){
                //&#x7ed1;&#x5b9a;
                $UsersModel->save(array('user_id' => $uid), array('mobile' => $mobile));
                $VerifyModel->save($where, array('is_verify' => 1));

                junhua_ajaxReturn(array('code' => 1, 'msg' => '&#x7ed1;&#x5b9a;&#x6210;&#x529f;'));
            }else{
                junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x5df2;&#x8fc7;&#x671f;&#xff0c;&#x8bf7;&#x91cd;&#x65b0;&#x83b7;&#x53d6;',));
            }

        }else{
            junhua_ajaxReturn(array('code' => 0, 'msg' => '&#x9a8c;&#x8bc1;&#x7801;&#x9519;&#x8bef;'));
        }

    }else{
        exit;
    }

}elseif($a == 'finish'){

    if(IS_AJAX){

        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        $xrzwid = junhua_I('xrzwid/d', 0);

        $where = array();
        $where['xrzw_id'] = $xrzwid;
        $where['user_id'] = $uid;

        $xrzw_m_adminuids = explode(",", $junhua_xrzw_setting['xrzw_m_adminuids']);
        if(in_array($uid , $xrzw_m_adminuids)){
            unset($where['user_id']);
        }

        $xrzwInfo = $xrzwModel->find($where);

        if($xrzwInfo){
            $xrzwModel->save(array('xrzw_id' => $xrzwid), array('is_ren' => 1));
        }

        $data = array('code' => 2, 'msg' => '&#x64cd;&#x4f5c;&#x5b8c;&#x6210;');
        junhua_ajaxReturn($data);


    }else{
        exit;
    }

}elseif($a == 'audit'){

    if(IS_AJAX){

        if(!$uid){
            $data = array('code' => 1, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        $xrzwid = junhua_I('xrzwid/d', 0);

        $where = array();
        $where['xrzw_id'] = $xrzwid;
        $where['user_id'] = $uid;

        $xrzw_m_adminuids = explode(",", $junhua_xrzw_setting['xrzw_m_adminuids']);
        if(!in_array($uid , $xrzw_m_adminuids)){
            $data = array('code' => 0, 'msg' => '&#x60a8;&#x65e0;&#x6743;&#x9650;&#x64cd;&#x4f5c;');
            junhua_ajaxReturn($data);
        }

        $xrzwInfo = $xrzwModel->find($where);

        if($xrzwInfo){
            $xrzwModel->save(array('xrzw_id' => $xrzwid), array('is_enable' => 1));
        }

        $data = array('code' => 2, 'msg' => '&#x64cd;&#x4f5c;&#x5b8c;&#x6210;');
        junhua_ajaxReturn($data);


    }else{
        exit;
    }

}elseif($a == 'refresh'){
    if(IS_AJAX){


        if(!$uid){
            $data = array('code' => 0, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        $xrzw_id = junhua_I('xrzw_id/d', 0);

        $xrzwInfo = $xrzwModel->find(array(
            'xrzw_id'   => $xrzw_id
        ));

        if(!$xrzwInfo){
            $data = array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
            junhua_ajaxReturn($data);
        }

        $total_amount = $junhua_xrzw_setting['refresh_setting'];

        $orderData = array(
            'xrzw_id'      => $xrzw_id,
            'user_id'      => $uid,
            'total_amount' => $total_amount,
            'out_trade_no' => junhua_getorderno('jxr_'),
            'type'         => 1,
            'remark'       => junhua_utf82gbk(junhua_unicodeDecode('&#x5237;&#x65b0;')), //&#x652f;&#x4ed8;&#x5907;&#x6ce8;
            'paytype'      => IS_MAGA ? 1 : (IS_WEIXIN ? 2 : 0),  //&#x7528;&#x6237;UID
            'add_time'     => $_G['timestamp'],
        );

        $orderId = $OrderModel->add($orderData);

        if(IS_MAGA){
            $junhuaApp = new junhua_App($junhua_base_config, $junhua_xrzw_setting);

            $param = array(
                'out_trade_no' => $orderData['out_trade_no'], //&#x5916;&#x90e8;&#x8ba2;&#x5355;
                'money'        => $orderData['total_amount'], //&#x652f;&#x4ed8;&#x91d1;&#x989d;
                'des'          => '', //&#x652f;&#x4ed8;&#x63cf;&#x8ff0;
                'remark'       => '', //&#x652f;&#x4ed8;&#x5907;&#x6ce8;
                'uid'          => $orderData['user_id'],  //&#x7528;&#x6237;UID
                'title'        => $xrzwInfo['title'].junhua_utf82gbk(junhua_unicodeDecode('&#x5237;&#x65b0;')), //&#x652f;&#x4ed8;&#x6807;&#x9898;
            );

            $r = $junhuaApp->getMagaCreateOrder($param);

            if(isset($r['data']['unionOrderNum'])){

                $unionOrderNum = $r['data']['unionOrderNum'];

                $OrderModel->save(array(
                    'order_id' => $orderId, //&#x5916;&#x90e8;&#x8ba2;&#x5355;
                ),array(
                    'trade_no'  => $unionOrderNum
                ));

                junhua_ajaxReturn(array(
                    'status'        => 1,
                    'unionOrderNum' => $unionOrderNum,
                    'out_trade_no'  => $orderData['out_trade_no'],
                    'total_amount'  => $orderData['total_amount'],
                    'title'         => junhua_gbk2utf8($xrzwInfo['title'].junhua_utf82gbk(junhua_unicodeDecode('&#x5237;&#x65b0;'))),
                    'des'           => '',
                ));

            }else{
                junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;&#xff0c;&#x8bf7;&#x7a0d;&#x540e;&#x518d;&#x8bd5;'));
            }

        }elseif(IS_WEIXIN) {

            include_once('source/plugin/junhua_base/libs/weixin/weixin_pay.php');

            $weixin_appid     = $junhua_xrzw_setting['weixin_appid'] ? trim($junhua_xrzw_setting['weixin_appid']) : trim($junhua_base_config['weixin_appid']);
            $weixin_appsecret = $junhua_xrzw_setting['weixin_appsecret'] ? trim($junhua_xrzw_setting['weixin_appsecret']) : trim($junhua_base_config['weixin_appsecret']);
            $weixin_mchid     = $junhua_xrzw_setting['weixin_mchid'] ? trim($junhua_xrzw_setting['weixin_mchid']) : trim($junhua_base_config['weixin_mchid']);
            $weixin_key       = $junhua_xrzw_setting['weixin_key'] ? trim($junhua_xrzw_setting['weixin_key']) : trim($junhua_base_config['weixin_key']);

            $weixin_table  = $junhua_base_config['weixin_table'];
            $weixin_tables = explode(',', $weixin_table);
            $tableName     = str_replace(DB::object()->tablepre, '', $weixin_tables[0]);
            $uidField      = $weixin_tables[1];
            $openidField   = $weixin_tables[2];

            if($weixin_appid && $weixin_appsecret && $weixin_mchid && $weixin_key && $openidField){

                //&#x67e5;&#x8be2;openid
                $wxTableModel = new junhua_model($tableName, '');
                $openid = $wxTableModel->getField(array(
                    $uidField => $uid
                ), $openidField);
                
                $weixin_pay = new WEIXIN_PAY($weixin_appid, $weixin_appsecret, $weixin_mchid, $weixin_key);

                $weixin_pay->body = junhua_gbk2utf8($xrzwInfo['title'].junhua_utf82gbk(junhua_unicodeDecode('&#x5237;&#x65b0;')));
                $weixin_pay->out_trade_no = $orderData['out_trade_no'];
                $weixin_pay->total_fee = $orderData['total_amount']*100;    // &#x5355;&#x4f4d;&#x4e3a; &#x201c;&#x5206;&#x201d;, &#x5b57;&#x7b26;&#x4e32;&#x7c7b;&#x578b;
                $weixin_pay->openid = $openid;
                $callback     = $_G['siteurl'].'source/plugin/junhua_xrzw/wxnotify.php';
                $weixin_pay->notify_url = $callback;

                $payment = $weixin_pay->getConfig();

                junhua_ajaxReturn(array(
                    'status'  => 1,
                    'payment' => $payment,
                ));
            }else{
                junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;&#xff0c;&#x8bf7;&#x7a0d;&#x540e;&#x518d;&#x8bd5;'));
            }
        }
    }

}elseif($a == 'top'){
    if(IS_AJAX){


        if(!$uid){
            $data = array('code' => 0, 'msg' => '&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;');
            junhua_ajaxReturn($data);
        }

        $xrzw_id = junhua_I('xrzw_id/d', 0);
        $topnum  = junhua_I('topnum/d', 0);

        $xrzwInfo = $xrzwModel->find(array(
            'xrzw_id'   => $xrzw_id
        ));

        if(!$xrzwInfo){
            $data = array('code' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;');
            junhua_ajaxReturn($data);
        }

        //&#x83b7;&#x53d6;&#x7f6e;&#x9876;&#x5929;&#x6570;
        $selectString = str_replace("\r", "", $junhua_xrzw_setting['top_setting']);
        $selectStringAry = array_filter(explode("\n", $selectString));

        $topAry = array();
        foreach ($selectStringAry as $key => $value) {
            $sub = explode("=", $value);
            $topAry[] = array(
                'day' => $sub[0],
                'money' => $sub[1] 
            );
        }

        $total_amount = $topAry[$topnum]['money'];


        $orderData = array(
            'xrzw_id'      => $xrzw_id,
            'user_id'      => $uid,
            'total_amount' => $total_amount,
            'out_trade_no' => junhua_getorderno('jxr_'),
            'type'         => 2,
            'top_num'       => $topnum,
            'remark'       => junhua_utf82gbk(junhua_unicodeDecode('&#x7f6e;&#x9876;')), //&#x652f;&#x4ed8;&#x5907;&#x6ce8;
            'paytype'      => IS_MAGA ? 1 : (IS_WEIXIN ? 2 : 0),  //&#x7528;&#x6237;UID
            'add_time'     => $_G['timestamp'],
        );

        $orderId = $OrderModel->add($orderData);

        if(IS_MAGA){
            $junhuaApp = new junhua_App($junhua_base_config, $junhua_xrzw_setting);

            $param = array(
                'out_trade_no' => $orderData['out_trade_no'], //&#x5916;&#x90e8;&#x8ba2;&#x5355;
                'money'        => $orderData['total_amount'], //&#x652f;&#x4ed8;&#x91d1;&#x989d;
                'des'          => '', //&#x652f;&#x4ed8;&#x63cf;&#x8ff0;
                'remark'       => '', //&#x652f;&#x4ed8;&#x5907;&#x6ce8;
                'uid'          => $orderData['user_id'],  //&#x7528;&#x6237;UID
                'title'        => $xrzwInfo['title'].junhua_utf82gbk(junhua_unicodeDecode('&#x7f6e;&#x9876;')), //&#x652f;&#x4ed8;&#x6807;&#x9898;
            );

            $r = $junhuaApp->getMagaCreateOrder($param);

            if(isset($r['data']['unionOrderNum'])){

                $unionOrderNum = $r['data']['unionOrderNum'];

                $OrderModel->save(array(
                    'order_id' => $orderId, //&#x5916;&#x90e8;&#x8ba2;&#x5355;
                ),array(
                    'trade_no'  => $unionOrderNum
                ));

                junhua_ajaxReturn(array(
                    'status'        => 1,
                    'unionOrderNum' => $unionOrderNum,
                    'out_trade_no'  => $orderData['out_trade_no'],
                    'total_amount'  => $orderData['total_amount'],
                    'title'         => junhua_gbk2utf8($xrzwInfo['title'].junhua_utf82gbk(junhua_unicodeDecode('&#x5237;&#x65b0;'))),
                    'des'           => '',
                ));

            }else{
                junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;&#xff0c;&#x8bf7;&#x7a0d;&#x540e;&#x518d;&#x8bd5;'));
            }

        }elseif(IS_WEIXIN) {

            include_once('source/plugin/junhua_base/libs/weixin/weixin_pay.php');

            $weixin_appid     = $junhua_xrzw_setting['weixin_appid'] ? trim($junhua_xrzw_setting['weixin_appid']) : trim($junhua_base_config['weixin_appid']);
            $weixin_appsecret = $junhua_xrzw_setting['weixin_appsecret'] ? trim($junhua_xrzw_setting['weixin_appsecret']) : trim($junhua_base_config['weixin_appsecret']);
            $weixin_mchid     = $junhua_xrzw_setting['weixin_mchid'] ? trim($junhua_xrzw_setting['weixin_mchid']) : trim($junhua_base_config['weixin_mchid']);
            $weixin_key       = $junhua_xrzw_setting['weixin_key'] ? trim($junhua_xrzw_setting['weixin_key']) : trim($junhua_base_config['weixin_key']);

            $weixin_table  = $junhua_base_config['weixin_table'];
            $weixin_tables = explode(',', $weixin_table);
            $tableName     = str_replace(DB::object()->tablepre, '', $weixin_tables[0]);
            $uidField      = $weixin_tables[1];
            $openidField   = $weixin_tables[2];

            //&#x67e5;&#x8be2;openid
            $wxTableModel = new junhua_model($tableName, '');
            $openid = $wxTableModel->getField(array(
                $uidField => $uid
            ), $openidField);

            if($weixin_appid && $weixin_appsecret && $weixin_mchid && $weixin_key && $openidField){
                $weixin_pay = new WEIXIN_PAY($weixin_appid, $weixin_appsecret, $weixin_mchid, $weixin_key);

                $weixin_pay->body = junhua_gbk2utf8($xrzwInfo['title'].junhua_utf82gbk(junhua_unicodeDecode('&#x7f6e;&#x9876;')));
                $weixin_pay->out_trade_no = $orderData['out_trade_no'];
                $weixin_pay->total_fee = $orderData['total_amount']*100;    // &#x5355;&#x4f4d;&#x4e3a; &#x201c;&#x5206;&#x201d;, &#x5b57;&#x7b26;&#x4e32;&#x7c7b;&#x578b;
                $weixin_pay->openid = $openid;
                $callback     = $_G['siteurl'].'source/plugin/junhua_xrzw/wxnotify.php';
                $weixin_pay->notify_url = $callback;

                $payment = $weixin_pay->getConfig();

                junhua_ajaxReturn(array(
                    'status'  => 1,
                    'payment' => $payment,
                ));
            }else{
                junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x6570;&#x636e;&#x5f02;&#x5e38;&#xff0c;&#x8bf7;&#x7a0d;&#x540e;&#x518d;&#x8bd5;'));
            }
        }
    }
}
else{
	exit;
}