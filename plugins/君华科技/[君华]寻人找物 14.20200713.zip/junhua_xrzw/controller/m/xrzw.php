<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!in_array($a, array('index', 'detail'))){
    $a = 'index';
}

include_once('source/plugin/junhua_xrzw/controller/m/common.php');


$xrzwModel = new junhua_model('xrzw');
$usersModel = new junhua_model('xrzwUsers');
$classifyModel = new junhua_model('xrzwClassify');

if($a == 'index'){


    $block_title = $junhua_xrzw_setting['xrzw_system_title'];
    $block_css = '';
}elseif($a == 'detail'){

    $xrzwid = junhua_I('xrzwid/d', 0);

    $where = array();
    $where['xrzw_id'] = $xrzwid;

    $xrzwInfo = $xrzwModel->find($where);

    if(!$xrzwInfo){
        dheader('Location:' . junhua_url('m/index/index', '', 1));
    }

    $xrzw_m_adminuids = explode(",", $junhua_xrzw_setting['xrzw_m_adminuids']);

    //&#x672a;&#x5ba1;&#x6838;&#x72b6;&#x6001; &#x975e;&#x7ba1;&#x7406;&#x5458; &#x6216;&#x8005; &#x662f;&#x81ea;&#x5df1; &#x53ef;&#x4ee5;&#x67e5;&#x770b;
    if($xrzwInfo['user_id'] != $uid && $xrzwInfo['is_enable'] != 1 && !in_array($uid, $xrzw_m_adminuids)){
        dheader('Location:' . junhua_url('m/index/index', '', 1));
    }

    //&#x81ea;&#x589e;
    $xrzwModel->setInc($where, 'clicknum');

    //&#x5224;&#x65ad;&#x7f6e;&#x9876;&#x4e4b;&#x95f4;
    if($xrzwInfo['top_time'] < $_G['timestamp']){
        $xrzwModel->save(array(
            'xrzw_id'   => $xrzwInfo['xrzw_id']
        ),array(
            'top_time'  => 0
        ));
    }


    //&#x83b7;&#x53d6;&#x5206;&#x7c7b;
    $classifyInfo = $classifyModel->find(array('classify_id' => $xrzwInfo['classify_id']));


    $fields = dunserialize($classifyInfo['fields']);
    $detail_title = str_replace(
            array(
                '[faxian_time]',
                '[faxian_address]',
                '[mobile]',
                '[lianxiren]',
                '[names]',
                '[sex]',
                '[age]',
                '[height]',
                '[weight]',
                '[address]',
                '[jiguan]'
            ),
            array(
                date('Y-m-d', $xrzwInfo['faxian_time']),
                $xrzwInfo['faxian_address'],
                $xrzwInfo['mobile'],
                $xrzwInfo['lianxiren'],
                $xrzwInfo['names'],
                junhua_utf82gbk(junhua_unicodeDecode($xrzwInfo['sex'] == 1 ? '&#x7537;' : '&#x5973;')),
                $xrzwInfo['age'],
                $xrzwInfo['height'],
                $xrzwInfo['weight'],
                $xrzwInfo['address'],
                $xrzwInfo['jiguan']
            ), $fields['detail_title']);

    $detail_share = str_replace(
            array(
                '[faxian_time]',
                '[faxian_address]',
                '[address]',
                '[mobile]',
                '[lianxiren]',
                '[names]',
                '[sex]',
                '[age]',
                '[height]',
                '[weight]',
                '[miaoshu]',
                '[jiguan]'
            ),
            array(
                date('Y-m-d', $xrzwInfo['faxian_time']),
                $xrzwInfo['faxian_address'],
                $xrzwInfo['address'],
                $xrzwInfo['mobile'],
                $xrzwInfo['lianxiren'],
                $xrzwInfo['names'],
                junhua_utf82gbk(junhua_unicodeDecode($xrzwInfo['sex'] == 1 ? '&#x7537;' : '&#x5973;')),
                $xrzwInfo['age'],
                $xrzwInfo['height'],
                $xrzwInfo['weight'],
                $xrzwInfo['miaoshu'],
                $xrzwInfo['jiguan']
            ), $fields['detail_share']);

        $detail_share = str_replace("\r", "", $detail_share);
        $detail_share = str_replace("\n", "", $detail_share);



    $block_title = '&#x8be6;&#x60c5;';
    $block_css = '<link rel="stylesheet" href="source/plugin/junhua_xrzw/static/m/css/detail.css">';
}
else{
	exit;
}


$block_content = 'junhua_xrzw:m/'.$c.'/'.$a;

include template('junhua_xrzw:m/layout');