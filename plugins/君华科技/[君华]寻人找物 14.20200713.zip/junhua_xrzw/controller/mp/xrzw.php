<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array(
    'index', 'add','edit', 'del', 'set', 'ren',
    'classify_list', 'classify_add', 'classify_edit', 'classify_set', 'classify_del', 'classify_xun',
))){
    $a = 'index';
}


loadcache('junhua_xrzw_system');
$junhua_xrzw_system = dunserialize($_G['cache']['junhua_xrzw_system']);

$xrzwModel = new junhua_model('xrzw');
$classifyModel = new junhua_model('xrzwClassify');
$classifyList = $classifyModel->select(array('is_enable' => 1), 'classify_id,classify_title,classify_icon,ordernum,is_xunren,fields', 'ordernum desc, classify_id desc', 0, 0, true);

if($a == 'index'){

    $user_id = junhua_I('user_id/d', '');
    $xrzw_id = junhua_I('xrzw_id/d', '');
    $keyword = junhua_I('keyword', '');
    $page    = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $where = array();

    if($user_id){
        $where['user_id'] = $user_id;
        $param['user_id'] = $user_id;
    }

    if($xrzw_id){
        $where['xrzw_id'] = $xrzw_id;
        $param['xrzw_id'] = $xrzw_id;
    }

    if($keyword){
        $where['title'] = array('like', '%'.str_replace(array('_', '%'), array('\_', '\%'), $keyword).'%');
        $param['keyword'] = $keyword;
    }

    $param['perpage'] = $perpage;


    $totalNum = $xrzwModel->count($where);


    $theurl = junhua_url('mp/xrzw/index', http_build_query($param), true);
    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $xrzwModel->select($where, '*', 'xrzw_id desc', $start, $perpage);

    $block_head_title = '&#x5185;&#x5bb9;&#x7ba1;&#x7406;';
    $block_title = '&#x5185;&#x5bb9;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {
    $classify_id    = junhua_I('classify_id/d', 0);

    if(!$classifyList[$classify_id]){
        dheader('location:' . junhua_url('mp/xrzw/classify_list', '', 1));
        exit;
    }

    if(IS_AJAX){
        
        $is_xunren      = junhua_I('is_xunren/d', 0);
        $title          = junhua_I('title', '');
        $faxian_time    = junhua_I('faxian_time', '');
        $province_id    = junhua_I('province_id', '');
        $city_id        = junhua_I('city_id', '');
        $area_id        = junhua_I('area_id', '');
        $faxian_address = junhua_I('faxian_address', '');
        $address        = junhua_I('address', '');
        $mobile         = junhua_I('mobile', '');
        $lianxiren      = junhua_I('lianxiren', '');
        $cover_img      = junhua_I('cover_img', '');
        $imgs           = junhua_I('imgs', '');
        $imgs_zl           = junhua_I('imgs_zl', '');
        $miaoshu        = junhua_I('miaoshu', '');
        $names          = junhua_I('names', '');
        $sex            = junhua_I('sex/d', 0);
        $age            = junhua_I('age/d', 0);
        $height         = junhua_I('height/d', 0);
        $weight         = junhua_I('weight/d', 0);
        $jiguanid1      = junhua_I('jiguanid1', '');
        $jiguanid2      = junhua_I('jiguanid2', '');
        $jiguan         = junhua_I('jiguan', '');
        $is_ren         = junhua_I('is_ren/d', 0);

        $faxian_time = strtotime($faxian_time);

        $imgs = str_replace("\r", "", $imgs);
        $imgs = explode("\n", $imgs);
        $imgs = array_filter($imgs);
        $imgs = json_encode($imgs);

        $imgs_zl = str_replace("\r", "", $imgs_zl);
        $imgs_zl = explode("\n", $imgs_zl);
        $imgs_zl = array_filter($imgs_zl);
        $imgs_zl = json_encode($imgs_zl);

        $data = array(
            'user_id'        => $_G['uid'],
            'classify_id'    => $classify_id,
            'title'          => $title,
            'faxian_time'    => $faxian_time,
            'province_id'    => $province_id,
            'city_id'        => $city_id,
            'area_id'        => $area_id,
            'faxian_address' => $faxian_address,
            'address'        => $address,
            'mobile'         => $mobile,
            'lianxiren'      => $lianxiren,
            'imgs'           => $imgs,
            'imgs_zl'           => $imgs_zl,
            'miaoshu'        => $miaoshu,
            'names'          => $names,
            'sex'            => $sex,
            'age'            => $age,
            'height'         => $height,
            'weight'         => $weight,
            'jiguanids'      => serialize(array($jiguanid1, $jiguanid2)),
            'jiguan'         => $jiguan,
            'add_time'       => $_G['timestamp'],
            'refresh_time'   => $_G['timestamp'],
            'is_xunren'      => $is_xunren,
            'is_enable'      => 1,
        );

        $xrzwModel->add($data);

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/xrzw/index', '', true)));
    }

    $fields = dunserialize($classifyList[$classify_id]['fields']);

    $block_head_title = '&#x5185;&#x5bb9;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x5185;&#x5bb9;';
    $block_css = '';
    $a = 'update';
}elseif ($a == 'edit') {

    $xrzw_id = junhua_I('xrzwid/d', 0);

    $where = array('xrzw_id' => $xrzw_id);
    $xrzwInfo = $xrzwModel->find($where);

    if(!$xrzwInfo){
        dheader('location:' . junhua_url('mp/xrzw/index', '', 1));
        exit;
    }

    if(IS_AJAX){

        $is_xunren      = junhua_I('is_xunren/d', 0);
        $title          = junhua_I('title', '');
        $faxian_time    = junhua_I('faxian_time', '');
        $province_id    = junhua_I('province_id', '');
        $city_id        = junhua_I('city_id', '');
        $area_id        = junhua_I('area_id', '');
        $faxian_address = junhua_I('faxian_address', '');
        $address        = junhua_I('address', '');
        $mobile         = junhua_I('mobile', '');
        $lianxiren      = junhua_I('lianxiren', '');
        $cover_img      = junhua_I('cover_img', '');
        $imgs           = junhua_I('imgs', '');
        $imgs_zl           = junhua_I('imgs_zl', '');
        $miaoshu        = junhua_I('miaoshu', '');
        $names          = junhua_I('names', '');
        $sex            = junhua_I('sex/d', 0);
        $age            = junhua_I('age/d', 0);
        $height         = junhua_I('height/d', 0);
        $weight         = junhua_I('weight/d', 0);
        $jiguan         = junhua_I('jiguan', '');
        $jiguanid1      = junhua_I('jiguanid1', '');
        $jiguanid2      = junhua_I('jiguanid2', '');
        $is_ren         = junhua_I('is_ren/d', 0);

        $faxian_time = strtotime($faxian_time);


        $imgs = str_replace("\r", "", $imgs);
        $imgs = explode("\n", $imgs);
        $imgs = array_filter($imgs);
        $imgs = json_encode($imgs);

        $imgs_zl = str_replace("\r", "", $imgs_zl);
        $imgs_zl = explode("\n", $imgs_zl);
        $imgs_zl = array_filter($imgs_zl);
        $imgs_zl = json_encode($imgs_zl);


        $data = array(
            'title'          => $title,
            'faxian_time'    => $faxian_time,
            'province_id'    => $province_id,
            'city_id'        => $city_id,
            'area_id'        => $area_id,
            'faxian_address' => $faxian_address,
            'address'        => $address,
            'mobile'         => $mobile,
            'lianxiren'      => $lianxiren,
            'imgs'           => $imgs,
            'imgs_zl'           => $imgs_zl,
            'miaoshu'        => $miaoshu,
            'names'          => $names,
            'sex'            => $sex,
            'age'            => $age,
            'height'         => $height,
            'weight'         => $weight,
            'jiguanids'      => serialize(array($jiguanid1, $jiguanid2)),
            'jiguan'         => $jiguan,
            'add_time'       => $_G['timestamp'],
            'refresh_time'   => $_G['timestamp'],
            'is_xunren'      => $is_xunren,
        );

        $xrzwModel->save($where, $data);
        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/xrzw/index', '', 1)));
    }

    $fields = dunserialize($classifyList[$xrzwInfo['classify_id']]['fields']);
    $jiguanids = dunserialize($xrzwInfo['jiguanids']);

    $xrzwInfo['imgs'] = $xrzwInfo['imgs_ary'] = json_decode($xrzwInfo['imgs'], true);
    $xrzwInfo['imgs'] = implode("\n", $xrzwInfo['imgs'])."\n";

    $xrzwInfo['imgs_zl'] = $xrzwInfo['imgs_zl_ary'] = json_decode($xrzwInfo['imgs_zl'], true);
    $xrzwInfo['imgs_zl'] = implode("\n", $xrzwInfo['imgs_zl'])."\n";


    $block_head_title = '&#x5185;&#x5bb9;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x5185;&#x5bb9;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'set'){
    if(IS_AJAX){
        $xrzwid = junhua_I('xrzwid/d', 0);

        $where = array(
            'xrzw_id'      => $xrzwid
        );

        $xrzwInfo = $xrzwModel->find($where);
        if(!$xrzwInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($xrzwInfo['is_enable'] == 1){
            $is_enable = 0;
        }else{
            $is_enable = 1;
        }

        $xrzwModel->save($where, array('is_enable' => $is_enable));

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'ren'){
    if(IS_AJAX){
        $xrzwid = junhua_I('xrzwid/d', 0);

        $where = array(
            'xrzw_id'      => $xrzwid
        );

        $xrzwInfo = $xrzwModel->find($where);
        if(!$xrzwInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($xrzwInfo['is_ren'] == 1){
            $is_ren = 0;
        }else{
            $is_ren = 1;
        }

        $xrzwModel->save($where, array('is_ren' => $is_ren));

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'del'){
    if(IS_AJAX){
        $xrzwid = junhua_I('xrzwid/d', 0);

        $where = array(
            'xrzw_id'      => $xrzwid
        );

        $xrzwInfo = $xrzwModel->find($where);
        if(!$xrzwInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $xrzwModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'classify_list'){

    $page = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $theurl = junhua_url('mp/xrzw/classify_list', http_build_query($param), true);


    $where = array();
    $totalNum = $classifyModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $classifyModel->select($where, '*', 'ordernum desc, classify_id desc', $start, $perpage);

    $block_head_title = '&#x5206;&#x7c7b;&#x7ba1;&#x7406;';
    $block_title = '&#x5206;&#x7c7b;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'classify_add') {
    if(IS_AJAX){

        $classify_title = junhua_I('classify_title', '');
        $pid            = junhua_I('pid/d', 0);
        $classify_icon  = junhua_I('classify_icon', '');
        $classify_nopic = junhua_I('classify_nopic', '');
        $check_uids     = junhua_I('check_uids', '');
        $check_text     = junhua_I('check_text', '');
        $ordernum       = junhua_I('ordernum/d', 0);
        $is_xunren      = junhua_I('is_xunren/d', 0);
        $is_check       = junhua_I('is_check/d', 0);
        $fields         = junhua_I('fields/a', array());
        $check_ts_type  = junhua_I('check_ts_type/d', 0);
        $tpmsg_id       = junhua_I('tpmsg_id/d', 0);
        $threshold_num  = junhua_I('threshold_num/d', 0);


        $data = array(
            'classify_title' => $classify_title,
            'pid'            => $pid,
            'classify_icon'  => $classify_icon,
            'classify_nopic' => $classify_nopic,
            'check_uids'     => $check_uids,
            'check_text'     => $check_text,
            'ordernum'       => $ordernum,
            'is_xunren'      => $is_xunren,
            'is_check'       => $is_check,
            'fields'         => serialize($fields),
            'check_ts_type'  => $check_ts_type,
            'tpmsg_id'       => $tpmsg_id,
            'threshold_num'  => $threshold_num,
            'is_enable'      => 1,
        );

        $classifyModel->add($data);

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/xrzw/classify_list', '', true)));
    }

    //&#x83b7;&#x53d6;&#x6a21;&#x7248;&#x6d88;&#x606f;
    $tpmsgSettingModel = new junhua_model('tpmsgSetting');
    $where = array(
        'plugin_name' => CURMODULE,
        'is_enable'   => 1,
    );

    $tpmsgList = $tpmsgSettingModel->select($where, '*', 'setting_id desc');

    $block_head_title = '&#x5206;&#x7c7b;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x5206;&#x7c7b;';
    $block_css = '';
    $a = 'classify_update';
}elseif ($a == 'classify_edit') {

    $classify_id = junhua_I('clid/d', 0);

    $where = array('classify_id' => $classify_id);
    $classifyInfo = $classifyModel->find($where);

    if(!$classifyInfo){
        dheader('location:' . junhua_url('mp/xrzw/classify_list', '', 1));
        exit;
    }

    if(IS_AJAX){

        $classify_title = junhua_I('classify_title', '');
        $pid            = junhua_I('pid/d', 0);
        $classify_icon  = junhua_I('classify_icon', '');
        $classify_nopic = junhua_I('classify_nopic', '');
        $check_uids     = junhua_I('check_uids', '');
        $check_text     = junhua_I('check_text', '');
        $ordernum       = junhua_I('ordernum/d', 0);
        $is_xunren      = junhua_I('is_xunren/d', 0);
        $is_check       = junhua_I('is_check/d', 0);
        $fields         = junhua_I('fields/a', array());
        $check_ts_type  = junhua_I('check_ts_type/d', 0);
        $tpmsg_id       = junhua_I('tpmsg_id/d', 0);
        $threshold_num  = junhua_I('threshold_num/d', 0);

        $data = array(
            'classify_title' => $classify_title,
            'pid'            => $pid,
            'classify_icon'  => $classify_icon,
            'classify_nopic' => $classify_nopic,
            'check_uids'     => $check_uids,
            'check_text'     => $check_text,
            'ordernum'       => $ordernum,
            'is_check'       => $is_check,
            'fields'         => serialize($fields),
            'check_ts_type'  => $check_ts_type,
            'tpmsg_id'       => $tpmsg_id,
            'threshold_num'  => $threshold_num,
            'is_xunren'      => $is_xunren,
        );

        $classifyModel->save($where, $data);
        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/xrzw/classify_list', '', 1)));
    }

    $fields = dunserialize($classifyInfo['fields']);

    //&#x83b7;&#x53d6;&#x6a21;&#x7248;&#x6d88;&#x606f;
    $tpmsgSettingModel = new junhua_model('tpmsgSetting');
    $where = array(
        'plugin_name' => CURMODULE,
        'is_enable'   => 1,
    );

    $tpmsgList = $tpmsgSettingModel->select($where, '*', 'setting_id desc');


    $block_head_title = '&#x5206;&#x7c7b;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x5206;&#x7c7b;';
    $block_css = '';
    $a = 'classify_update';
}elseif($a == 'classify_del'){
    if(IS_AJAX){
        $clid = junhua_I('clid/d', 0);

        $where = array(
            'classify_id'      => $clid
        );

        $classifyInfo = $classifyModel->find($where);
        if(!$classifyInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $classifyModel->delete($where);
        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'classify_set'){
    if(IS_AJAX){
        $clid = junhua_I('clid/d', 0);

        $where = array(
            'classify_id'      => $clid
        );

        $classifyInfo = $classifyModel->find($where);
        if(!$classifyInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($classifyInfo['is_enable'] == 1){
            $is_enable = 0;
        }else{
            $is_enable = 1;
        }

        $classifyModel->save($where, array('is_enable' => $is_enable));

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'classify_xun'){
    if(IS_AJAX){
        $clid = junhua_I('clid/d', 0);

        $where = array(
            'classify_id'      => $clid
        );

        $classifyInfo = $classifyModel->find($where);
        if(!$classifyInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($classifyInfo['is_xunren'] == 1){
            $is_xunren = 0;
        }else{
            $is_xunren = 1;
        }

        $classifyModel->save($where, array('is_xunren' => $is_xunren));

        junhua_ajaxReturn(array('status' => 1));
    }
}else{
	exit;
}

$block_content = 'junhua_xrzw:mp/'.$c.'/'.$a;
include template('junhua_xrzw:mp/layout');