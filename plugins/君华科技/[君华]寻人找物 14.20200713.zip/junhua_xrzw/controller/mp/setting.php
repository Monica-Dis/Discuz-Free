<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!in_array($a, array(
    'index',
    'banner',
    'nav',
    'about',
    'notice',
    'top',
    'uploadfile',
    'uploadfile_editor',
))){
    $a = 'index';
}

loadcache('junhua_xrzw_system');
$junhua_xrzw_system = dunserialize($_G['cache']['junhua_xrzw_system']);

$dataOrg = array(
    'xrzw_appsharehide_open'        => $junhua_xrzw_setting['xrzw_appsharehide_open'],
    'xrzw_mustlogin_open'           => $junhua_xrzw_setting['xrzw_mustlogin_open'],
    
    'weixin_appid'                  => $junhua_xrzw_setting['weixin_appid'],
    'weixin_appsecret'              => $junhua_xrzw_setting['weixin_appsecret'],
    'weixin_paohui_url'             => $junhua_xrzw_setting['weixin_paohui_url'],
    
    'xrzw_weixin_share_open'        => $junhua_xrzw_setting['xrzw_weixin_share_open'],
    'xrzw_weixin_gz_open'           => $junhua_xrzw_setting['xrzw_weixin_gz_open'],
    
    'xrzw_gzh_ewm'                  => $junhua_xrzw_setting['xrzw_gzh_ewm'],
    'xrzw_gzh_winpinlv'             => $junhua_xrzw_setting['xrzw_gzh_winpinlv'],
    'xrzw_gzh_win_title'            => $junhua_xrzw_setting['xrzw_gzh_win_title'],
    'xrzw_gzh_win_subtitle'         => $junhua_xrzw_setting['xrzw_gzh_win_subtitle'],
    'xrzw_share_title'              => $junhua_xrzw_setting['xrzw_share_title'],
    'xrzw_share_desc'               => $junhua_xrzw_setting['xrzw_share_desc'],
    'xrzw_share_img'                => $junhua_xrzw_setting['xrzw_share_img'],
    'maga_zhushou_text'             => $junhua_xrzw_setting['maga_zhushou_text'],
    'xrzw_banners'                  => $junhua_xrzw_setting['xrzw_banners'],
    'xrzw_footer_nav'               => $junhua_xrzw_setting['xrzw_footer_nav'],
    'xrzw_nav_show_open'            => $junhua_xrzw_setting['xrzw_nav_show_open'],
    'xrzw_detail_ads'               => $junhua_xrzw_setting['xrzw_detail_ads'],
    
    'xrzw_system_title'             => $junhua_xrzw_setting['xrzw_system_title'],
    'xrzw_about'                    => $junhua_xrzw_setting['xrzw_about'],
    'xrzw_notice'                   => $junhua_xrzw_setting['xrzw_notice'],
    'xrzw_m_adminuids'              => $junhua_xrzw_setting['xrzw_m_adminuids'],
    'xrzw_isren_show'               => $junhua_xrzw_setting['xrzw_isren_show'],
    'xrzw_user_kfimg'               => $junhua_xrzw_setting['xrzw_user_kfimg'],
    'xrzw_user_kfimg_title'         => $junhua_xrzw_setting['xrzw_user_kfimg_title'],
    'xrzw_user_kfimg_subtitle'      => $junhua_xrzw_setting['xrzw_user_kfimg_subtitle'],
    'xrzw_user_jzimg'               => $junhua_xrzw_setting['xrzw_user_jzimg'],
    'xrzw_user_jzimg_title'         => $junhua_xrzw_setting['xrzw_user_jzimg_title'],
    'xrzw_finish_icon'              => $junhua_xrzw_setting['xrzw_finish_icon'],
    'xrzw_user_jzimg_subtitle'      => $junhua_xrzw_setting['xrzw_user_jzimg_subtitle'],
    'xrzw_detail_groupimg'          => $junhua_xrzw_setting['xrzw_detail_groupimg'],
    'xrzw_detail_groupimg_text1'    => $junhua_xrzw_setting['xrzw_detail_groupimg_text1'],
    'xrzw_detail_groupimg_text2'    => $junhua_xrzw_setting['xrzw_detail_groupimg_text2'],
    'xrzw_detail_groupimg_title'    => $junhua_xrzw_setting['xrzw_detail_groupimg_title'],
    'xrzw_detail_groupimg_subtitle' => $junhua_xrzw_setting['xrzw_detail_groupimg_subtitle'],
    'xrzw_address_diy'              => $junhua_xrzw_setting['xrzw_address_diy'],
    'xrzw_address_default'          => $junhua_xrzw_setting['xrzw_address_default'],
    'xrzw_jiguan_diy'               => $junhua_xrzw_setting['xrzw_jiguan_diy'],
    'xrzw_jiguan_default'           => $junhua_xrzw_setting['xrzw_jiguan_default'],
    'xrzw_fabu_need_mobile'         => $junhua_xrzw_setting['xrzw_fabu_need_mobile'],
    
    'dayu_FreeSignName'             => $junhua_xrzw_setting['dayu_FreeSignName'],
    'dayu_TemplateCode'             => $junhua_xrzw_setting['dayu_TemplateCode'],
    
    'xrzw_water_open'               => $junhua_xrzw_setting['xrzw_water_open'],
    'xrzw_water_weizhi'             => $junhua_xrzw_setting['xrzw_water_weizhi'],
    'xrzw_water_img'                => $junhua_xrzw_setting['xrzw_water_img'],
    
    'threshold_num'                 => $junhua_xrzw_setting['threshold_num'],
    
    'top_setting'                   => $junhua_xrzw_setting['top_setting'],
    'refresh_setting'               => $junhua_xrzw_setting['refresh_setting'],
    'weixin_mchid'                  => $junhua_xrzw_setting['weixin_mchid'],
    'weixin_key'                    => $junhua_xrzw_setting['weixin_key'],
);

if($a == 'index'){

    if(IS_AJAX){
        
        $xrzw_appsharehide_open        = junhua_I('xrzw_appsharehide_open/d', 0);
        $xrzw_mustlogin_open           = junhua_I('xrzw_mustlogin_open/d', 0);
        $xrzw_weixin_share_open        = junhua_I('xrzw_weixin_share_open/d', 0);
        $xrzw_weixin_gz_open           = junhua_I('xrzw_weixin_gz_open/d', 0);
        $weixin_appid                  = junhua_I('weixin_appid', '');
        $weixin_appsecret              = junhua_I('weixin_appsecret', '');
        $weixin_paohui_url             = junhua_I('weixin_paohui_url', '');

        //&#x8fc7;&#x6ee4;&#x56de;&#x8f66;&#x7a7a;&#x683c;
        $weixin_paohui_url = str_replace("\r", "", $weixin_paohui_url);
        $weixin_paohui_url = explode("\n", $weixin_paohui_url);
        $weixin_paohui_url = array_filter($weixin_paohui_url);
        if($weixin_paohui_url){
            $weixin_paohui_url = array_map("trim", $weixin_paohui_url);
            $weixin_paohui_url = implode("\n", $weixin_paohui_url);
        }else{
            $weixin_paohui_url = '';
        }

        $xrzw_share_title              = junhua_I('xrzw_share_title', '');
        $xrzw_share_desc               = junhua_I('xrzw_share_desc', '');
        $xrzw_share_img                = junhua_I('xrzw_share_img', '');
        $xrzw_gzh_ewm                  = junhua_I('xrzw_gzh_ewm', '');
        $xrzw_gzh_win_title            = junhua_I('xrzw_gzh_win_title', '');
        $xrzw_gzh_win_subtitle         = junhua_I('xrzw_gzh_win_subtitle', '');
        $xrzw_gzh_winpinlv             = junhua_I('xrzw_gzh_winpinlv/d', 0);
        $maga_zhushou_text             = junhua_I('maga_zhushou_text', '');
        $xrzw_detail_ads               = junhua_I('xrzw_detail_ads', '');
        
        $xrzw_system_title             = junhua_I('xrzw_system_title', '');
        $xrzw_m_adminuids              = junhua_I('xrzw_m_adminuids', '');
        $xrzw_user_kfimg               = junhua_I('xrzw_user_kfimg', '');
        $xrzw_user_kfimg_title         = junhua_I('xrzw_user_kfimg_title', '');
        $xrzw_user_kfimg_subtitle      = junhua_I('xrzw_user_kfimg_subtitle', '');
        $xrzw_user_jzimg               = junhua_I('xrzw_user_jzimg', '');
        $xrzw_user_jzimg_title         = junhua_I('xrzw_user_jzimg_title', '');
        $xrzw_user_jzimg_subtitle      = junhua_I('xrzw_user_jzimg_subtitle', '');
        $xrzw_finish_icon              = junhua_I('xrzw_finish_icon', '');
        $xrzw_isren_show               = junhua_I('xrzw_isren_show/d', 0);
        $xrzw_detail_groupimg          = junhua_I('xrzw_detail_groupimg', '');
        $xrzw_detail_groupimg_text1    = junhua_I('xrzw_detail_groupimg_text1', '');
        $xrzw_detail_groupimg_text2    = junhua_I('xrzw_detail_groupimg_text2', '');
        $xrzw_detail_groupimg_title    = junhua_I('xrzw_detail_groupimg_title', '');
        $xrzw_detail_groupimg_subtitle = junhua_I('xrzw_detail_groupimg_subtitle', '');
        $xrzw_address_diy              = junhua_I('xrzw_address_diy', '');
        $xrzw_address_default          = junhua_I('xrzw_address_default', '');
        $xrzw_jiguan_diy               = junhua_I('xrzw_jiguan_diy', '');
        $xrzw_jiguan_default           = junhua_I('xrzw_jiguan_default', '');
        $xrzw_fabu_need_mobile         = junhua_I('xrzw_fabu_need_mobile/d', 0);
        
        $dayu_FreeSignName             = junhua_I('dayu_FreeSignName', '');
        $dayu_TemplateCode             = junhua_I('dayu_TemplateCode', '');
        
        $xrzw_water_open               = junhua_I('xrzw_water_open/d', 0);
        $xrzw_water_weizhi             = junhua_I('xrzw_water_weizhi/d', 9);
        $xrzw_water_img                = junhua_I('xrzw_water_img', '');
        $threshold_num                 = junhua_I('threshold_num/d', 0);
        $refresh_setting               = junhua_I('refresh_setting/f', 0);
        $weixin_mchid                  = junhua_I('weixin_mchid', '');
        $weixin_key                    = junhua_I('weixin_key', '');


        $data = array(
            'xrzw_appsharehide_open'        => $xrzw_appsharehide_open,
            'xrzw_mustlogin_open'           => $xrzw_mustlogin_open,
            'xrzw_weixin_share_open'        => $xrzw_weixin_share_open,
            'xrzw_weixin_gz_open'           => $xrzw_weixin_gz_open,
            
            'weixin_appid'                  => $weixin_appid,
            'weixin_appsecret'              => $weixin_appsecret,
            'weixin_paohui_url'             => $weixin_paohui_url,
            
            'xrzw_share_title'              => $xrzw_share_title,
            'xrzw_share_desc'               => $xrzw_share_desc,
            'xrzw_share_img'                => $xrzw_share_img,
            'xrzw_gzh_ewm'                  => $xrzw_gzh_ewm,
            'xrzw_gzh_winpinlv'             => $xrzw_gzh_winpinlv,
            'xrzw_gzh_win_title'            => $xrzw_gzh_win_title,
            'xrzw_gzh_win_subtitle'         => $xrzw_gzh_win_subtitle,
            'maga_zhushou_text'             => $maga_zhushou_text,
            'xrzw_system_title'             => $xrzw_system_title,
            'xrzw_m_adminuids'              => $xrzw_m_adminuids,
            'xrzw_isren_show'               => $xrzw_isren_show,
            'xrzw_user_jzimg'               => $xrzw_user_jzimg,
            'xrzw_user_kfimg_title'         => $xrzw_user_kfimg_title,
            'xrzw_user_kfimg_subtitle'      => $xrzw_user_kfimg_subtitle,
            'xrzw_user_kfimg'               => $xrzw_user_kfimg,
            'xrzw_user_jzimg_title'         => $xrzw_user_jzimg_title,
            'xrzw_user_jzimg_subtitle'      => $xrzw_user_jzimg_subtitle,
            'xrzw_finish_icon'              => $xrzw_finish_icon,
            'xrzw_detail_ads'               => $xrzw_detail_ads,
            'xrzw_detail_groupimg'          => $xrzw_detail_groupimg,
            'xrzw_detail_groupimg_text1'    => $xrzw_detail_groupimg_text1,
            'xrzw_detail_groupimg_text2'    => $xrzw_detail_groupimg_text2,
            'xrzw_detail_groupimg_title'    => $xrzw_detail_groupimg_title,
            'xrzw_detail_groupimg_subtitle' => $xrzw_detail_groupimg_subtitle,
            'xrzw_address_diy'              => $xrzw_address_diy,
            'xrzw_address_default'          => $xrzw_address_default,
            'xrzw_jiguan_diy'               => $xrzw_jiguan_diy,
            'xrzw_jiguan_default'           => $xrzw_jiguan_default,
            'xrzw_fabu_need_mobile'         => $xrzw_fabu_need_mobile,
            
            'dayu_FreeSignName'             => $dayu_FreeSignName,
            'dayu_TemplateCode'             => $dayu_TemplateCode,
            'xrzw_water_open'               => $xrzw_water_open,
            'xrzw_water_weizhi'             => $xrzw_water_weizhi,
            'xrzw_water_img'                => $xrzw_water_img,
            'threshold_num'                 => $threshold_num,
            'refresh_setting'               => $refresh_setting,
            'weixin_mchid'                  => $weixin_mchid,
            'weixin_key'                    => $weixin_key,
        );

        $data = array_merge($dataOrg, $data);

        savecache('junhua_xrzw_setting', serialize($data));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x914d;&#x7f6e;&#x6210;&#x529f;'));
    }

    $block_head_title = '&#x7cfb;&#x7edf;&#x914d;&#x7f6e;';
    $block_title = '&#x7cfb;&#x7edf;&#x914d;&#x7f6e;';
    $block_css = '';
}elseif($a == 'banner'){

    if(IS_AJAX){
        
        $xrzw_banners     = junhua_I('xrzw_banners', '');

        $data = array(
            'xrzw_banners'     => $xrzw_banners,
        );

        $data = array_merge($dataOrg, $data);

        savecache('junhua_xrzw_setting', serialize($data));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x914d;&#x7f6e;&#x6210;&#x529f;'));
    }

    $block_head_title = '&#x8f6e;&#x64ad;&#x8bbe;&#x7f6e;';
    $block_title = '&#x8f6e;&#x64ad;&#x8bbe;&#x7f6e;';
    $block_css = '';
}elseif($a == 'nav'){

    if(IS_AJAX){
        
        $xrzw_footer_nav     = junhua_I('xrzw_footer_nav', '');
        $xrzw_nav_show_open     = junhua_I('xrzw_nav_show_open/a', array());

        $data = array(
            'xrzw_footer_nav'     => $xrzw_footer_nav,
            'xrzw_nav_show_open'  => serialize($xrzw_nav_show_open),
        );

        $data = array_merge($dataOrg, $data);

        savecache('junhua_xrzw_setting', serialize($data));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x914d;&#x7f6e;&#x6210;&#x529f;'));
    }

    $junhua_xrzw_setting['xrzw_nav_show_open'] = dunserialize($junhua_xrzw_setting['xrzw_nav_show_open']);

    $block_head_title = '&#x83dc;&#x5355;&#x8bbe;&#x7f6e;';
    $block_title = '&#x83dc;&#x5355;&#x8bbe;&#x7f6e;';
    $block_css = '';
}elseif($a == 'about'){

    if(IS_AJAX){
        
        $xrzw_about     = junhua_I('xrzw_about', '');
        $xrzw_about = htmlspecialchars_decode($xrzw_about);
        $xrzw_about = preg_replace('/<img src="(.*)source\/plugin\/junhua_xrzw\/upload\/image/U', '<img src="source/plugin/junhua_xrzw/upload/image', $xrzw_about);
        $xrzw_about = dhtmlspecialchars($xrzw_about);

        $data = array(
            'xrzw_about'     => $xrzw_about,
        );

        $data = array_merge($dataOrg, $data);

        savecache('junhua_xrzw_setting', serialize($data));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x914d;&#x7f6e;&#x6210;&#x529f;'));
    }

    $block_head_title = '&#x5173;&#x4e8e;&#x6211;&#x4eec;&#x8bbe;&#x7f6e;';
    $block_title = '&#x5173;&#x4e8e;&#x6211;&#x4eec;&#x8bbe;&#x7f6e;';
    $block_css = '<link rel="stylesheet" href="source/plugin/junhua_editor/themes/default/default.css" />';
}elseif($a == 'notice'){

    if(IS_AJAX){
        
        $xrzw_notice     = junhua_I('xrzw_notice', '');
        $xrzw_notice = htmlspecialchars_decode($xrzw_notice);
        $xrzw_notice = preg_replace('/<img src="(.*)source\/plugin\/junhua_xrzw\/upload\/image/U', '<img src="source/plugin/junhua_xrzw/upload/image', $xrzw_notice);
        $xrzw_notice = dhtmlspecialchars($xrzw_notice);

        $data = array(
            'xrzw_notice'     => $xrzw_notice,
        );

        $data = array_merge($dataOrg, $data);

        savecache('junhua_xrzw_setting', serialize($data));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x914d;&#x7f6e;&#x6210;&#x529f;'));
    }

    $block_head_title = '&#x53d1;&#x5e03;&#x987b;&#x77e5;&#x8bbe;&#x7f6e;';
    $block_title = '&#x53d1;&#x5e03;&#x987b;&#x77e5;&#x8bbe;&#x7f6e;';
    $block_css = '<link rel="stylesheet" href="source/plugin/junhua_editor/themes/default/default.css" />';
}elseif($a == 'top'){

    if(IS_AJAX){
        
        $top_setting     = junhua_I('top_setting', '');

        //&#x8fc7;&#x6ee4;&#x56de;&#x8f66;&#x7a7a;&#x683c;
        $top_setting = str_replace("\r", "", $top_setting);
        $top_setting = explode("\n", $top_setting);
        $top_setting = array_filter($top_setting);
        if($top_setting){
            $top_setting = array_map("trim", $top_setting);
            $top_setting = implode("\n", $top_setting);
        }else{
            $top_setting = '';
        }

        $data = array(
            'top_setting'     => $top_setting,
        );

        $data = array_merge($dataOrg, $data);

        savecache('junhua_xrzw_setting', serialize($data));

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x914d;&#x7f6e;&#x6210;&#x529f;'));
    }

    $block_head_title = '&#x7f6e;&#x9876;&#x8bbe;&#x7f6e;';
    $block_title = '&#x7f6e;&#x9876;&#x8bbe;&#x7f6e;';
}elseif($a == 'uploadfile'){
    include_once('source/plugin/junhua_base/libs/filemanger.class.php');

    if (!IS_POST && isset($_FILES) ? $_FILES : array()) {
        exit;
    }

    $filemanger = new junhua_filemanger('source/plugin/junhua_xrzw', 'source/plugin/junhua_xrzw');
    $img_path = $filemanger->uploadJson('Filedata', false);

    junhua_ajaxReturn(array('status' => 1, 'file_path' => $img_path));
}elseif($a == 'uploadfile_editor'){
    include_once('source/plugin/junhua_base/libs/filemanger.class.php');

    if (!IS_POST && isset($_FILES) ? $_FILES : array()) {
        exit;
    }

    $filemanger = new junhua_filemanger('source/plugin/junhua_xrzw', 'source/plugin/junhua_xrzw');
    $img_path = $filemanger->uploadJson('imgFile');
    exit;
}
else{
	exit;
}

$block_content = 'junhua_xrzw:mp/'.$c.'/'.$a;
include template('junhua_xrzw:mp/layout');