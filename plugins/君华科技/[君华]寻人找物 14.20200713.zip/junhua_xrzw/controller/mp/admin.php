<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once('common.php');

$AdminModel = new junhua_model('xrzwAdmin');

$groupList = $GroupModel->select(array(
), 'group_id,group_name', 'group_id desc', 0, 0, 1);

if($a == 'index'){
    $page    = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $where = array();

    $param['perpage'] = $perpage;


    $theurl = junhua_url('mp/admin/index', http_build_query($param), true);
    $totalNum = $AdminModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $AdminModel->select($where, '*', 'admin_id desc', $start, $perpage);

    $block_head_title = '&#x5458;&#x5de5;&#x7ba1;&#x7406;';
    $block_title = '&#x5458;&#x5de5;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'add') {

    
	if(IS_AJAX){
        
        $user_id  = junhua_I('user_id/d', 0);
        $group_id = junhua_I('group_id/d', 0);
        $beizhu   = junhua_I('beizhu', '');

        $data = array(
            'user_id'     => $user_id,
            'beizhu'      => $beizhu,
            'group_id'    => $group_id,
            'is_enable'   => 1,
            'add_time'    => $_G['timestamp'],
            'update_time' => $_G['timestamp'],
        );

        $AdminModel->add($data);

	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/admin/index', '', true)));
	}

    $block_head_title = '&#x5458;&#x5de5;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x5458;&#x5de5;';
    $block_css = '';
    $a = 'update';
}elseif ($a == 'edit') {

	$admin_id = junhua_I('admin_id/d', 0);

	$where = array('admin_id' => $admin_id);
	$adminInfo = $AdminModel->find($where);

	if(!$adminInfo){
        dheader('location:' . junhua_url('mp/admin/index', '', 1));
        exit;
	}

	if(IS_AJAX){

        $user_id  = junhua_I('user_id/d', 0);
        $group_id = junhua_I('group_id/d', 0);
        $beizhu   = junhua_I('beizhu', '');

        $data = array(
            'user_id'     => $user_id,
            'beizhu'      => $beizhu,
            'group_id'    => $group_id,
            'update_time' => $_G['timestamp'],
        );

		$AdminModel->save($where, $data);

	    junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/admin/index', '', 1)));
	}


    $block_head_title = '&#x5458;&#x5de5;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x5458;&#x5de5;';
    $block_css = '';
    $a = 'update';
}elseif($a == 'del'){
    if(IS_AJAX){
        $admin_id = junhua_I('admin_id/d', 0);

        $where = array(
            'admin_id'      => $admin_id
        );

        $adminInfo = $AdminModel->find($where);
        if(!$adminInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $AdminModel->delete($where);

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'set'){
    if(IS_AJAX){
        $admin_id = junhua_I('admin_id/d', 0);

        $where = array(
            'admin_id'      => $admin_id
        );

        $adminInfo = $AdminModel->find($where);
        if(!$adminInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($adminInfo['is_enable'] == 1){
            $is_enable = 0;
        }else{
            $is_enable = 1;
        }

        $AdminModel->save($where, array('is_enable' => $is_enable));

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'setqiantai'){
    if(IS_AJAX){
        $admin_id = junhua_I('admin_id/d', 0);

        $where = array(
            'admin_id'      => $admin_id
        );

        $adminInfo = $AdminModel->find($where);
        if(!$adminInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($adminInfo['is_qiantai'] == 1){
            $is_qiantai = 0;
        }else{
            $is_qiantai = 1;
        }

        $AdminModel->save($where, array('is_qiantai' => $is_qiantai));

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'gindex'){
    $page    = junhua_I('page/d', 1);
    $perpage = junhua_I('perpage/d', 10);

    if($page < 1) $page = 1;
    $start = ($page-1)*$perpage;

    $param = array();
    $where = array();

    $param['perpage'] = $perpage;

    $theurl = junhua_url('mp/admin/gindex', http_build_query($param), true);
    $totalNum = $GroupModel->count($where);

    if($totalNum) {
        $multi = multi($totalNum, $perpage, $page, $theurl);
    }

    $lists = $GroupModel->select($where, '*', 'group_id desc', $start, $perpage);

    $block_head_title = '&#x7528;&#x6237;&#x7ec4;&#x7ba1;&#x7406;';
    $block_title = '&#x7528;&#x6237;&#x7ec4;&#x5217;&#x8868;';
    $block_css = '';
}elseif ($a == 'gadd') {
   
    if(IS_AJAX){
        
        $group_name = junhua_I('group_name/s', '');
        $group_ids  = junhua_I('group_ids/a', array());

        $data = array(
            'group_name' => $group_name,
            'group_ids'  => serialize($group_ids),
            'add_time'    => $_G['timestamp'],
            'update_time' => $_G['timestamp'],
        );


        $GroupModel->add($data);

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x6dfb;&#x52a0;&#x6210;&#x529f;', 'url' => junhua_url('mp/admin/gindex', '', true)));
    }

    $block_head_title = '&#x7528;&#x6237;&#x7ec4;&#x7ba1;&#x7406;';
    $block_title = '&#x6dfb;&#x52a0;&#x7528;&#x6237;&#x7ec4;';
    $block_css = '';
    $a = 'gupdate';
}elseif ($a == 'gedit') {

    $group_id = junhua_I('group_id/d', 0);

    $where = array('group_id' => $group_id);
    $groupInfo = $GroupModel->find($where);

    if(!$groupInfo){
        dheader('location:' . junhua_url('mp/admin/gindex', '', 1));
        exit;
    }

    if(IS_AJAX){

        $group_name = junhua_I('group_name/s', '');
        $group_ids  = junhua_I('group_ids/a', array());

        $data = array(
            'group_name' => $group_name,
            'group_ids'  => serialize($group_ids),
            'update_time' => $_G['timestamp'],
        );

        $GroupModel->save($where, $data);

        junhua_ajaxReturn(array('status' => 1, 'msg' => '&#x7f16;&#x8f91;&#x6210;&#x529f;', 'url' => junhua_url('mp/admin/gindex', '', 1)));
    }

    $groupInfo['group_ids'] = dunserialize($groupInfo['group_ids']);

    $block_head_title = '&#x7528;&#x6237;&#x7ec4;&#x7ba1;&#x7406;';
    $block_title = '&#x4fee;&#x6539;&#x7528;&#x6237;&#x7ec4;';
    $block_css = '';
    $a = 'gupdate';
}elseif($a == 'gdel'){
    if(IS_AJAX){
        $group_id = junhua_I('group_id/d', 0);

        $where = array(
            'group_id'      => $group_id
        );

        $groupInfo = $GroupModel->find($where);
        if(!$groupInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x5220;&#x9664;&#x5931;&#x8d25;'));
        }

        $GroupModel->delete($where);

        junhua_ajaxReturn(array('status' => 1));
    }
}elseif($a == 'gset'){
    if(IS_AJAX){
        $group_id = junhua_I('group_id/d', 0);

        $where = array(
            'group_id'      => $group_id
        );

        $groupInfo = $GroupModel->find($where);
        if(!$groupInfo){
            junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x8bbe;&#x7f6e;&#x5931;&#x8d25;'));
        }

        if($groupInfo['is_enable'] == 1){
            $is_enable = 0;
        }else{
            $is_enable = 1;
        }

        $GroupModel->save($where, array('is_enable' => $is_enable));

        junhua_ajaxReturn(array('status' => 1));
    }
}
else{
	exit;
}

$block_content = 'junhua_xrzw:mp/'.$c.'/'.$a;

include template('junhua_xrzw:mp/layout');