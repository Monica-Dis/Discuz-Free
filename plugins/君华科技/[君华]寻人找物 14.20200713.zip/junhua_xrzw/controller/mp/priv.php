<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$privs = array();
$privs['01'] = array('id' => '01', 'name' => '&#x7528;&#x6237;', 'url' => junhua_url('mp/users/index', '', 1), 'in_menu' => '');
$privs['01']['menu_list'] = array(
        array('id'=> '0101', 'name' => '&#x7528;&#x6237;&#x5217;&#x8868;', 'url' => junhua_url('mp/users/index', '', 1), 'in_menu' => ''),
        array('id'=> '0102', 'name' => '&#x5220;&#x9664;&#x7528;&#x6237;', 'url' => junhua_url('mp/users/del', '', 1), 'in_menu' => '0101'),
        array('id'=> '0103', 'name' => '&#x7981;&#x7528;/&#x542f;&#x7528;&#x7528;&#x6237;', 'url' => junhua_url('mp/users/set', '', 1), 'in_menu' => '0101'),
);
$privs['02'] = array('id' => '02', 'name' => '&#x5185;&#x5bb9;', 'url' => junhua_url('mp/xrzw/index', '', 1), 'in_menu' => '');
$privs['02']['menu_list'] = array(
        array('id'=> '0201', 'name' => '&#x6dfb;&#x52a0;&#x5185;&#x5bb9;', 'url' => junhua_url('mp/xrzw/add', '', 1), 'in_menu' => '0202'),
        array('id'=> '0202', 'name' => '&#x5185;&#x5bb9;&#x5217;&#x8868;', 'url' => junhua_url('mp/xrzw/index', '', 1), 'in_menu' => ''),
        array('id'=> '0203', 'name' => '&#x7f16;&#x8f91;&#x5185;&#x5bb9;', 'url' => junhua_url('mp/xrzw/edit', '', 1), 'in_menu' => '0202'),
        array('id'=> '0204', 'name' => '&#x5220;&#x9664;&#x5185;&#x5bb9;', 'url' => junhua_url('mp/xrzw/del', '', 1), 'in_menu' => '0202'),
        array('id'=> '0205', 'name' => '&#x8bbe;&#x7f6e;&#x72b6;&#x6001;', 'url' => junhua_url('mp/xrzw/set', '', 1), 'in_menu' => '0202'),
        array('id'=> '0206', 'name' => '&#x8bbe;&#x7f6e;&#x5b8c;&#x6210;', 'url' => junhua_url('mp/xrzw/ren', '', 1), 'in_menu' => '0202'),

        array('id'=> '0207', 'name' => '&#x6dfb;&#x52a0;&#x5206;&#x7c7b;', 'url' => junhua_url('mp/xrzw/classify_add', '', 1), 'in_menu' => '0208'),
        array('id'=> '0208', 'name' => '&#x5206;&#x7c7b;&#x5217;&#x8868;', 'url' => junhua_url('mp/xrzw/classify_list', '', 1), 'in_menu' => ''),
        array('id'=> '0209', 'name' => '&#x7f16;&#x8f91;&#x5206;&#x7c7b;', 'url' => junhua_url('mp/xrzw/classify_edit', '', 1), 'in_menu' => '0208'),
        array('id'=> '0210', 'name' => '&#x5220;&#x9664;&#x5206;&#x7c7b;', 'url' => junhua_url('mp/xrzw/classify_del', '', 1), 'in_menu' => '0208'),
        array('id'=> '0211', 'name' => '&#x8bbe;&#x7f6e;&#x72b6;&#x6001;', 'url' => junhua_url('mp/xrzw/classify_set', '', 1), 'in_menu' => '0208'),
);

$privs['03'] = array('id' => '03', 'name' => '&#x8ba2;&#x5355;', 'url' => junhua_url('mp/order/index', '', 1), 'in_menu' => '');
$privs['03']['menu_list'] = array(
        array('id'=> '0301', 'name' => '&#x8ba2;&#x5355;&#x5217;&#x8868;', 'url' => junhua_url('mp/order/index', '', 1), 'in_menu' => ''),
);

$privs['04'] = array('id' => '04', 'name' => '&#x5458;&#x5de5;', 'url' => junhua_url('mp/admin/index', '', 1), 'in_menu' => '');
$privs['04']['menu_list'] = array(
        array('id'=> '0401', 'name' => '&#x6dfb;&#x52a0;&#x5458;&#x5de5;', 'url' => junhua_url('mp/admin/add', '', 1), 'in_menu' => '0402'),
        array('id'=> '0402', 'name' => '&#x5458;&#x5de5;&#x5217;&#x8868;', 'url' => junhua_url('mp/admin/index', '', 1), 'in_menu' => ''),
        array('id'=> '0403', 'name' => '&#x7f16;&#x8f91;&#x5458;&#x5de5;', 'url' => junhua_url('mp/admin/edit', '', 1), 'in_menu' => '0402'),
        array('id'=> '0404', 'name' => '&#x5220;&#x9664;&#x5458;&#x5de5;', 'url' => junhua_url('mp/admin/del', '', 1), 'in_menu' => '0402'),
        array('id'=> '0405', 'name' => '&#x7981;&#x7528;/&#x542f;&#x7528;&#x5458;&#x5de5;', 'url' => junhua_url('mp/admin/set', '', 1), 'in_menu' => '0402'),
        array('id'=> '0406', 'name' => '&#x8bbe;&#x7f6e;&#x524d;&#x7aef;&#x53ef;&#x7ba1;&#x7406;', 'url' => junhua_url('mp/admin/setqiantai', '', 1), 'in_menu' => '0402'),

        array('id'=> '0407', 'name' => '&#x6dfb;&#x52a0;&#x7528;&#x6237;&#x7ec4;', 'url' => junhua_url('mp/admin/gadd', '', 1), 'in_menu' => '0408'),
        array('id'=> '0408', 'name' => '&#x7528;&#x6237;&#x7ec4;&#x5217;&#x8868;', 'url' => junhua_url('mp/admin/gindex', '', 1), 'in_menu' => ''),
        array('id'=> '0409', 'name' => '&#x7f16;&#x8f91;&#x7528;&#x6237;&#x7ec4;', 'url' => junhua_url('mp/admin/gedit', '', 1), 'in_menu' => '0408'),
        array('id'=> '0410', 'name' => '&#x5220;&#x9664;&#x7528;&#x6237;&#x7ec4;', 'url' => junhua_url('mp/admin/gdel', '', 1), 'in_menu' => '0408'),
        array('id'=> '0411', 'name' => '&#x7981;&#x7528;/&#x542f;&#x7528;&#x7528;&#x6237;&#x7ec4;', 'url' => junhua_url('mp/admin/gset', '', 1), 'in_menu' => '0408'),
);


$privs['20'] = array('id' => '20', 'name' => '&#x914d;&#x7f6e;', 'url' => junhua_url('mp/setting/index', '', 1), 'in_menu' => '');
$privs['20']['menu_list'] = array(
        array('id'=> '2001', 'name' => '&#x7cfb;&#x7edf;&#x8bbe;&#x7f6e;', 'url' => junhua_url('mp/setting/index', '', 1), 'in_menu' => ''),
        array('id'=> '2002', 'name' => '&#x9996;&#x9875;&#x8f6e;&#x64ad;', 'url' => junhua_url('mp/setting/banner', '', 1), 'in_menu' => ''),
        array('id'=> '2003', 'name' => '&#x5e95;&#x90e8;&#x5bfc;&#x822a;', 'url' => junhua_url('mp/setting/nav', '', 1), 'in_menu' => ''),
        array('id'=> '2004', 'name' => '&#x5173;&#x4e8e;&#x6211;&#x4eec;', 'url' => junhua_url('mp/setting/about', '', 1), 'in_menu' => ''),
        array('id'=> '2005', 'name' => '&#x901a;&#x77e5;&#x8bbe;&#x7f6e;', 'url' => junhua_url('mp/setting/notice', '', 1), 'in_menu' => ''),
        array('id'=> '2006', 'name' => '&#x7f6e;&#x9876;&#x8bbe;&#x7f6e;', 'url' => junhua_url('mp/setting/top', '', 1), 'in_menu' => ''),

        array('id'=> '2007', 'name' => '&#x6a21;&#x7248;&#x6d88;&#x606f;&#x914d;&#x7f6e;', 'url' => junhua_url('mp/tpmsg/index', '', 1), 'in_menu' => ''),
        array('id'=> '2008', 'name' => '&#x6dfb;&#x52a0;&#x6a21;&#x7248;', 'url' => junhua_url('mp/tpmsg/add', '', 1), 'in_menu' => '2006'),
        array('id'=> '2009', 'name' => '&#x7f16;&#x8f91;&#x6a21;&#x7248;', 'url' => junhua_url('mp/tpmsg/edit', '', 1), 'in_menu' => '2006'),
        array('id'=> '2010', 'name' => '&#x8bbe;&#x7f6e;&#x6a21;&#x7248;&#x6d88;&#x606f;', 'url' => junhua_url('mp/tpmsg/set', '', 1), 'in_menu' => '2006'),
        array('id'=> '2011', 'name' => '&#x5220;&#x9664;&#x6a21;&#x7248;&#x6d88;&#x606f;', 'url' => junhua_url('mp/tpmsg/del', '', 1), 'in_menu' => '2006'),
);