<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//&#x4e3a;&#x4e86;&#x7ffb;&#x9875;
if(!defined('IN_ADMINCP')) {
    define('IN_ADMINCP', true);
}

include_once('priv.php');

if(!$uid){
    showmessage('&#x60a8;&#x8fd8;&#x672a;&#x767b;&#x5f55;&#xff0c;&#x8bf7;&#x5148;&#x767b;&#x5f55;', $_G['siteurl'] . '/member.php?mod=logging&action=login&referer=' . urlencode($refererurl), array(), array('refreshtime' => 5));
}

$AdminModel = new junhua_model('xrzwAdmin');
$GroupModel = new junhua_model('xrzwAdminGroup');

if(!in_array($uid, $admin_lists)){
    $adminInfo = $AdminModel->find(array(
        'user_id'  => $uid,
        'is_enable'  => 1,
    ));

    if(!$adminInfo){
        showmessage('&#x60a8;&#x65e0;&#x6743;&#x9650;&#x64cd;&#x4f5c;&#xff01;', $_G['siteurl'], array(), array('refreshtime' => 5));
    }

    $group_ids = $GroupModel->getField(array('group_id' => $adminInfo['group_id']), 'group_ids');
    $group_ids = dunserialize($group_ids);

    $tempPriv = array();
    foreach ($privs as $key => $value) {
        $tempPriv[$key] = $value;
        if(isset($value['menu_list'])){
            foreach ($value['menu_list'] as $k => $v) {
                if(!in_array($v['id'], $group_ids)){
                    unset($tempPriv[$key]['menu_list'][$k]);
                    continue;
                }
            }

            if(!sizeof($tempPriv[$key]['menu_list'])){
                unset($tempPriv[$key]);
            }
        }
    }
    $privs = $tempPriv;
}

//&#x666e;&#x901a;&#x5458;&#x5de5;&#x5fc5;&#x987b;&#x5f97;&#x6709;$ownAreaIds
//&#x8d85;&#x7ea7;&#x7ba1;&#x7406;&#x5458; $ownAreaIds &#x4e3a;&#x7a7a;

//&#x6743;&#x9650;&#x5224;&#x65ad;
$quanxian_url = junhua_url('mp/'.$c.'/'.$a, '', 1);

$prev_url_id = 0;
$prev_url_cid = 0;
$in_menu = 0;
$quanxian_pass = false;

foreach ($privs as $key => $value) {
    if($value['url'] == $quanxian_url){
        $prev_url_id = $value['id'];
    }

    if(isset($value['menu_list']) && is_array($value['menu_list'])){
        foreach ($value['menu_list'] as $key1 => $value1) {
            if($value1['url'] == $quanxian_url){
                $in_menu      = $value1['in_menu'];
                $prev_url_id  = substr($value1['id'], 0, 2);
                $prev_url_cid = $value1['id'];
                $quanxian_pass = true;
                break;
            }
        }
    }
}


$except_url = array(
    junhua_url('mp/setting/uploadfile', '', 1),
    junhua_url('mp/setting/uploadfile_editor', '', 1),
    junhua_url('mp/tpmsg/gettpmsg', '', 1),
    junhua_url('mp/tpmsg/gettpmsginfo', '', 1)
);

if(in_array($quanxian_url, $except_url)){
    $quanxian_pass = true;
}

if(!$quanxian_pass){
    if(IS_AJAX){
        junhua_ajaxReturn(array('status' => 0, 'msg' => '&#x60a8;&#x65e0;&#x6743;&#x9650;&#x64cd;&#x4f5c;&#xff01;&#x8bf7;&#x8054;&#x7cfb;&#x7ba1;&#x7406;&#x5458;&#xff01;'));
    }

    showmessage('&#x60a8;&#x65e0;&#x6743;&#x9650;&#x64cd;&#x4f5c;&#xff01;', $_G['siteurl'], array(), array('refreshtime' => 5));
}
