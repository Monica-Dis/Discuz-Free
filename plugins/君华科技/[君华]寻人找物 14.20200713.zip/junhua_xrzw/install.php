<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$ADMINSCRIPT = ADMINSCRIPT;
$siteurl = $_G['siteurl'];

$createtablesql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_junhua_xrzw` (
  `xrzw_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT '0',
  `classify_id` int(10) DEFAULT '0',
  `title` varchar(125) DEFAULT '',
  `faxian_time` int(10) unsigned DEFAULT '0',
  `province_id` varchar(16) DEFAULT '',
  `city_id` varchar(16) DEFAULT '',
  `area_id` varchar(16) DEFAULT '',
  `faxian_address` varchar(255) DEFAULT '',
  `address` varchar(255) DEFAULT '',
  `lat` varchar(32) DEFAULT '',
  `lng` varchar(32) DEFAULT '',
  `mobile` varchar(16) DEFAULT NULL,
  `lianxiren` varchar(64) DEFAULT '',
  `cover_img` varchar(256) DEFAULT '',
  `imgs` varchar(1000) DEFAULT '[]',
  `imgs_zl` varchar(1000) DEFAULT '[]',
  `miaoshu` varchar(1000) DEFAULT '',
  `names` varchar(100) DEFAULT '',
  `sex` tinyint(1) DEFAULT '0',
  `age` int(10) DEFAULT '0',
  `height` int(10) DEFAULT '0',
  `weight` int(10) DEFAULT '0',
  `jiguanids` varchar(256) DEFAULT '',
  `jiguan` varchar(255) DEFAULT '',
  `clicknum` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  `top_time` int(10) unsigned DEFAULT '0',
  `refresh_time` int(10) unsigned DEFAULT '0',
  `is_xunren` tinyint(1) DEFAULT '0',
  `share_num` int(10) DEFAULT '0',
  `is_ren` tinyint(1) unsigned DEFAULT '0',
  `is_enable` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`xrzw_id`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`classify_id`),
  KEY `is_enable` (`is_enable`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_xrzw_classify` (
  `classify_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classify_title` varchar(255) DEFAULT NULL,
  `pid` int(10) DEFAULT NULL,
  `classify_icon` varchar(200) DEFAULT NULL,
  `ordernum` int(10) DEFAULT '0',
  `fields` text,
  `is_xunren` tinyint(1) DEFAULT '0',
  `is_check` tinyint(1) unsigned DEFAULT '0',
  `check_uids` varchar(256) DEFAULT '',
  `check_text` varchar(256) DEFAULT '',
  `check_ts_type` tinyint(1) DEFAULT '0',
  `tpmsg_id` int(10) DEFAULT '0',
  `classify_nopic` varchar(256) DEFAULT '',
  `threshold_num` int(10) DEFAULT '0',
  `is_enable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`classify_id`),
  KEY `orderby` (`ordernum`)
) ENGINE=MyISAM AUTO_INCREMENT=1;


CREATE TABLE IF NOT EXISTS `pre_junhua_xrzw_users` (
  `xuser_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT '0',
  `mobile` varchar(16) DEFAULT '',
  `openid` varchar(64) DEFAULT '',
  `unionid` varchar(64) DEFAULT '',
  `nickname` varchar(64) DEFAULT '',
  `sex` tinyint(1) DEFAULT '0',
  `language` varchar(32) DEFAULT '',
  `country` varchar(32) DEFAULT '',
  `province` varchar(32) DEFAULT '',
  `city` varchar(32) DEFAULT '',
  `headimgurl` varchar(256) DEFAULT '',
  `subscribe_time` int(11) unsigned DEFAULT '0',
  `unsubscribe_time` int(11) unsigned DEFAULT '0',
  `privilege` varchar(256) DEFAULT '',
  `subscribe` tinyint(1) DEFAULT '0',
  `add_time` int(11) unsigned DEFAULT '0',
  `last_time` int(11) unsigned DEFAULT '0',
  `is_enable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`xuser_id`),
  KEY `openid` (`openid`),
  KEY `unionid` (`unionid`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_junhua_xrzw_verify` (
  `verify_id` int(10) NOT NULL AUTO_INCREMENT,
  `verify_from` varchar(32) DEFAULT '',
  `verify_st` varchar(16) DEFAULT '',
  `is_verify` tinyint(1) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`verify_id`),
  KEY `verify_from` (`verify_from`) USING BTREE,
  KEY `verify_st` (`verify_st`) USING BTREE,
  KEY `user_id` (`user_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_junhua_xrzw_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `xrzw_id` int(10) unsigned DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `total_amount` decimal(14,2) DEFAULT '0.00',
  `trade_no` varchar(64) DEFAULT '',
  `out_trade_no` varchar(64) DEFAULT '',
  `type` tinyint(1) DEFAULT '0',
  `top_num` int(10) unsigned DEFAULT '0',
  `paytype` tinyint(1) DEFAULT '0',
  `remark` varchar(256) DEFAULT '',
  `is_pay` tinyint(1) unsigned DEFAULT '0',
  `pay_time` int(10) unsigned DEFAULT '0',
  `add_time` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`order_id`),
  KEY `out_trade_no` (`out_trade_no`),
  KEY `user_id` (`user_id`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;


//&#x5165;&#x5e93;&#x7f13;&#x5b58;&#x8868;

$setting = array(
  'xrzw_appsharehide_open' => 0,
  'xrzw_mustlogin_open' => 0,
  'weixin_appid' => '',
  'weixin_appsecret' => '',
  'weixin_paohui_url' => '',
  'xrzw_weixin_share_open' => 1,
  'xrzw_weixin_gz_open' => 1,
  'xrzw_gzh_ewm' => 'source/plugin/junhua_xrzw/static/m/img/guanzhu.png',
  'xrzw_gzh_winpinlv' => 86400,
  'xrzw_gzh_win_title' => '&#x5173;&#x6ce8;&#x672c;&#x516c;&#x4f17;&#x53f7;',
  'xrzw_gzh_win_subtitle' => '&#x8ba9;&#x7231;&#x4f20;&#x9012;',
  'xrzw_share_title' => '&#x5bfb;&#x4eba;&#x627e;&#x7269;',
  'xrzw_share_desc' => '&#x8fd9;&#x662f;&#x6700;&#x597d;&#x7684;&#x5bfb;&#x4eba;&#x627e;&#x7269;&#x5e73;&#x53f0;',
  'xrzw_share_img' => 'source/plugin/junhua_xrzw/static/m/img/group.png',
  'maga_zhushou_text' => '',
  'xrzw_banners' => 'source/plugin/junhua_xrzw/static/m/img/banner.jpg|http://www.baidu.com|&#x8fd9;&#x4e2a;&#x662f;&#x6807;&#x9898;&#x6587;&#x5b57;
source/plugin/junhua_xrzw/static/m/img/banner.jpg|http://www.baidu.com|&#x8fd9;&#x4e2a;&#x662f;&#x6807;&#x9898;&#x6587;&#x5b57;',
  'xrzw_footer_nav' => 'source/plugin/junhua_xrzw/static/m/img/ic_home.png|plugin.php?id=junhua_xrzw&amp;m=m&amp;c=index&amp;a=index|&#x9996;&#x9875;
source/plugin/junhua_xrzw/static/m/img/ic_fabu.png|plugin.php?id=junhua_xrzw&amp;m=m&amp;c=fabu&amp;a=index|&#x53d1;&#x5e03;
source/plugin/junhua_xrzw/static/m/img/ic_user.png|plugin.php?id=junhua_xrzw&amp;m=m&amp;c=user&amp;a=index|&#x6211;&#x7684;
',
  'xrzw_nav_show_open' => 'a:3:{i:0;s:5:"index";i:1;s:4:"fabu";i:2;s:4:"user";}',
  'xrzw_detail_ads' => '',
  'xrzw_system_title' => '&#x5bfb;&#x4eba;&#x627e;&#x7269;',
  'xrzw_about' => '&lt;span style=&quot;font-size:14px;&quot;&gt;&amp;emsp;&amp;emsp;&#x201c;&lt;span style=&quot;color:#006600;&quot;&gt;XXX&#x5bfb;&#x4eba;&#x627e;&#x7269;&#x516c;&#x76ca;&#x5e73;&#x53f0;&lt;/span&gt;&#x201d;&lt;span style=&quot;color:#333333;&quot;&gt;&#x5e73;&#x53f0;&#x662f;&#x4e3a;&#x5e7f;&#x5927;&#x5bfb;&#x4eb2;&#x6c42;&#x52a9;&#x8005;&#x642d;&#x5efa;&#x7684;&#x5bfb;&#x4eba;&#x542f;&#x4e8b;&#x4fe1;&#x606f;&#x53d1;&#x5e03;&#x516c;&#x76ca;&#x5e73;&#x53f0;&#xff0c;&#x6211;&#x4eec;&#x5c06;&#x957f;&#x671f;&#x81f4;&#x529b;&#x4e8e;&#x4e3a;&#x5bfb;&#x4eb2;&#x5bb6;&#x5ead;&#x4ee5;&#x53ca;&#x6d41;&#x79bb;&#x5931;&#x8e2a;&#x8005;&#x63d0;&#x4f9b;&#x5bfb;&#x4eba;&#x5bfb;&#x5bb6;&#x652f;&#x63f4;&#xff0c;&#x65e8;&#x5728;&#x4fc3;&#x8fdb;&#x66f4;&#x591a;&#x7684;&#x5931;&#x6563;&#x5bb6;&#x5ead;&#x4eb2;&#x4eba;&#x56e2;&#x805a;&#x3001;&#x7834;&#x955c;&#x91cd;&#x5706;&#x3002;&lt;/span&gt;&lt;/span&gt;',
  'xrzw_notice' => '&lt;span style=&quot;color:#009900;&quot;&gt;&amp;emsp;&amp;emsp;&#x4e00;&#x3001;&#x5bfb;&#x4eba;&#x627e;&#x7269;&#x53d1;&#x5e03;&#x767b;&#x8bb0;&#x8981;&#x6c42;&#xff1a;&lt;br /&gt;
&lt;span style=&quot;font-size:14px;&quot;&gt;&amp;emsp;&lt;/span&gt;&lt;span style=&quot;color:#000000;font-size:14px;&quot;&gt;&amp;emsp;1&#x3001;&#x5fc5;&#x987b;&#x4fdd;&#x8bc1;&#x6240;&#x63d0;&#x4f9b;&#x4fe1;&#x606f;&#x7684;&#x771f;&#x5b9e;&#x6027;&#xff0c;&#x540c;&#x65f6;&#x5185;&#x5bb9;&#x8981;&#x7cbe;&#x51c6;&#x3001;&#x5b8c;&#x6574;&#xff0c;&#x4e0d;&#x8981;&#x5f15;&#x51fa;&#x6b67;&#x4e49;&#x9020;&#x6210;&#x9648;&#x8ff0;&#x5931;&#x8bef;&#x3002;&#x5e76;&#x4e14;&#x6ca1;&#x6709;&#x4efb;&#x4f55;&#x5f15;&#x4eba;&#x8bef;&#x89e3;&#x6216;&#x8005;&#x865a;&#x5047;&#x7684;&#x9648;&#x8ff0;&#x3002;&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;color:#000000;font-size:14px;&quot;&gt;&amp;emsp;&amp;emsp;2&#x3001;&#x767b;&#x8bb0;&#x8005;&#x6240;&#x767b;&#x8bb0;&#x7684;&#x5185;&#x5bb9;&#x5177;&#x6709;&#x6cd5;&#x5f8b;&#x7ea6;&#x675f;&#x529b;&#xff0c;&#x5bf9;&#x5176;&#x5e26;&#x6765;&#x7684;&#x540e;&#x679c;&#x627f;&#x62c5;&#x6cd5;&#x5f8b;&#x8d23;&#x4efb;&#x3002;&lt;/span&gt;&lt;br /&gt;
&lt;/span&gt; 
&lt;p&gt;
  &lt;span style=&quot;color:#009900;&quot;&gt;&lt;span style=&quot;color:#000000;font-size:14px;&quot;&gt;&amp;emsp;&amp;emsp;3&#x3001;&#x4fdd;&#x8bc1;&#x6240;&#x767b;&#x8bb0;&#x7684;&#x4fe1;&#x606f;&#x8d44;&#x6599;&#x4e0d;&#x8fdd;&#x53cd;&#x4e2d;&#x534e;&#x4eba;&#x6c11;&#x5171;&#x548c;&#x56fd;&#x6cd5;&#x5f8b;&#x6cd5;&#x89c4;&#xff0c;&#x4e5f;&#x4e0d;&#x6784;&#x6210;&#x5bf9;&#x4efb;&#x4f55;&#x7b2c;&#x4e09;&#x8005;&#x4efb;&#x4f55;&#x5f62;&#x5f0f;&#x7684;&#x4fb5;&#x6743;&#x3002;&lt;/span&gt;&lt;/span&gt; 
&lt;/p&gt;
&lt;p&gt;
  &lt;span style=&quot;color:#009900;&quot;&gt;&lt;span style=&quot;color:#000000;font-size:14px;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;/span&gt; 
&lt;/p&gt;
&lt;span style=&quot;color:#009900;&quot;&gt; &amp;emsp;&amp;emsp;&#x4e8c;&#x3001;&#x8c28;&#x9632;&#x53d7;&#x9a97;&lt;br /&gt;
&lt;span style=&quot;color:#000000;&quot;&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;&amp;emsp;&amp;emsp;&#x51e1;&#x662f;&#x4ee5;&#x4efb;&#x4f55;&#x5bfb;&#x4eba;&#x4e3a;&#x7531;&#x9700;&#x8981;&#x8f6c;&#x94b1;&#x7684;&#x90fd;&#x662f;&#x8bc8;&#x9a97;&#x884c;&#x4e3a;&#xff0c;&#x8bf7;&#x7528;&#x6237;&#x63d0;&#x9ad8;&#x8b66;&#x60d5;&#xff0c;&#x8c28;&#x9632;&#x53d7;&#x9a97;!!!&#x5982;&#x6709;&#x7591;&#x95ee;&#x8bf7;&#x8054;&#x7cfb;&#x5e73;&#x53f0;&#x5ba2;&#x670d;&#x5fae;&#x4fe1;&#xff1a;&lt;/span&gt;&lt;span style=&quot;color:#E53333;font-size:14px;&quot;&gt;XXXX&lt;/span&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;&#x6216;&#x8005;&lt;/span&gt;&lt;span style=&quot;color:#E53333;font-size:14px;&quot;&gt;XXXX&lt;/span&gt;&lt;span style=&quot;font-size:14px;&quot;&gt;&#xff0c;&#x5176;&#x4ed6;&#x5747;&#x4e3a;&#x5047;&#x5192;&#x8d26;&#x53f7;!!!&lt;/span&gt;&lt;/span&gt;&lt;br /&gt;
&lt;/span&gt; 
&lt;p&gt;
  &lt;span style=&quot;color:#E56600;&quot;&gt;&lt;/span&gt;&lt;span style=&quot;color:#E56600;&quot;&gt;&lt;/span&gt; 
&lt;/p&gt;',
  'xrzw_m_adminuids' => '1',
  'xrzw_isren_show' => 1,
  'xrzw_user_kfimg' => 'source/plugin/junhua_xrzw/static/m/img/guanzhu.png',
  'xrzw_user_kfimg_title' => '&#x5ba2;&#x670d;&#x5fae;&#x4fe1;',
  'xrzw_user_kfimg_subtitle' => '&#x53d1;&#x5e03;&#x4e2d;&#x9047;&#x5230;&#x95ee;&#x9898;&#x8054;&#x7cfb;&#x6211;&#x4eec;',
  'xrzw_user_jzimg' => 'source/plugin/junhua_xrzw/static/m/img/guanzhu.png',
  'xrzw_user_jzimg_title' => '&#x611f;&#x8c22;&#x60a8;&#x7684;&#x6350;&#x8d60;',
  'xrzw_finish_icon' => 'source/plugin/junhua_xrzw/static/m/img/finish.png',
  'xrzw_user_jzimg_subtitle' => '&#x8ba9;&#x7231;&#x4f20;&#x9012;',
  'xrzw_detail_groupimg' => 'source/plugin/junhua_xrzw/static/m/img/guanzhu.png',
  'xrzw_detail_groupimg_text1' => '&#x5168;&#x56fd;&#x5bfb;&#x4eba;&#x5fd7;&#x613f;&#x8005;&#x5b98;&#x65b9;&#x7fa4;',
  'xrzw_detail_groupimg_text2' => '&#x732e;&#x51fa;&#x4e00;&#x4efd;&#x7231;&#x5fc3;, &#x6258;&#x8d77;&#x4e00;&#x4efd;&#x5e0c;&#x671b;',
  'xrzw_detail_groupimg_title' => '&#x8ba9;&#x7231;&#x805a;&#x9f50;',
  'xrzw_detail_groupimg_subtitle' => '&#x8ba9;&#x7231;&#x4f20;&#x9012;',
  'xrzw_address_diy' => '',
  'xrzw_address_default' => '33,3306,330603',
  'xrzw_jiguan_diy' => '',
  'xrzw_jiguan_default' => '33,3306',
  'xrzw_fabu_need_mobile' => 0,
  'dayu_FreeSignName' => '',
  'dayu_TemplateCode' => '',
  'xrzw_water_open' => 0,
  'xrzw_water_weizhi' => 9,
  'xrzw_water_img' => '',
);

savecache('junhua_xrzw_setting', serialize($setting));
runquery($createtablesql);

$initVal = array (
  array (
    'classify_title' => '&#x5bfb;&#x4eba;',
    'pid'            => '0',
    'classify_icon'  => 'source/plugin/junhua_xrzw/static/m/img/xunren.png',
    'ordernum'       => '2',
    'fields'         => serialize(array (
        'title'                  => '&#x5bfb;&#x4eba;&#x767b;&#x8bb0;',
        'title_show'             => '1',
        'title_need'             => '1',
        'title_list'             => '1',
        'imgs_show'              => '1',
        'imgs_need'              => '1',
        'imgs_list'              => '1',
        'imgs_zl'                => '',
        'faxian_time'            => '&#x5931;&#x8e2a;&#x65f6;&#x95f4;',
        'faxian_time_show'       => '1',
        'faxian_time_need'       => '1',
        'faxian_time_list'       => '1',
        'faxian_address'         => '&#x5931;&#x8e2a;&#x5730;&#x70b9;',
        'faxian_address_show'    => '1',
        'faxian_address_need'    => '1',
        'faxian_address_list'    => '1',
        'address'                => '',
        'mobile'                 => '&#x5bb6;&#x5c5e;&#x7535;&#x8bdd;',
        'mobile_show'            => '1',
        'mobile_need'            => '1',
        'mobile_list'            => '1',
        'lianxiren'              => '&#x5bb6;&#x5c5e;&#x59d3;&#x540d;',
        'lianxiren_show'         => '1',
        'lianxiren_need'         => '1',
        'lianxiren_list'         => '1',
        'miaoshu'                => '&#x8d70;&#x5931;&#x8be6;&#x60c5;',
        'miaoshu_show'           => '1',
        'miaoshu_need'           => '1',
        'miaoshu_list'           => '1',
        'miaoshu_placeholder'    => '&#x8bf7;&#x4e00;&#x5b9a;&#x8981;&#x8be6;&#x7ec6;&#x8bf4;&#x660e;&#x8d70;&#x5931;&#x8005;&#x4fe1;&#x606f;&#xff01;',
        'names'                  => '&#x5931;&#x8e2a;&#x8005;&#x59d3;&#x540d;',
        'names_show'             => '1',
        'names_need'             => '1',
        'names_list'             => '1',
        'sex'                    => '&#x5931;&#x8e2a;&#x8005;&#x6027;&#x522b;',
        'sex_show'               => '1',
        'sex_need'               => '1',
        'sex_list'               => '1',
        'age'                    => '&#x5931;&#x8e2a;&#x8005;&#x5e74;&#x9f84;',
        'age_show'               => '1',
        'age_need'               => '1',
        'age_list'               => '1',
        'height'                 => '&#x5931;&#x8e2a;&#x8005;&#x8eab;&#x9ad8;',
        'height_show'            => '1',
        'height_need'            => '1',
        'height_list'            => '1',
        'weight'                 => '&#x5931;&#x8e2a;&#x8005;&#x4f53;&#x91cd;',
        'weight_show'            => '1',
        'weight_need'            => '1',
        'weight_list'            => '1',
        'jiguan'                 => '',
        'index_btn'              => '&#x5e2e;&#x6211;&#x56de;&#x5bb6;',
        'detail_title'           => '[names],[sex],&lt;span&gt;[age]&#x5c81;&lt;/span&gt;, &#x8eab;&#x9ad8;&lt;span&gt;[height]&#x5398;&#x7c73;&lt;/span&gt;&lt;span&gt;[weight]&#x516c;&#x65a4;&lt;/span&gt;, [jiguan]&#x4eba;, &#x4e8e;&lt;span&gt;[faxian_time]&lt;/span&gt;&#x5728;&lt;span&gt;[faxian_address]&lt;/span&gt;&#x5931;&#x8e2a;&#x3002;',
        'detail_share'           => '[names],[sex],[age]&#x5c81;, &#x8eab;&#x9ad8;[height]&#x5398;&#x7c73;[weight]&#x516c;&#x65a4;, [jiguan]&#x4eba;, &#x4e8e;[faxian_time]&#x5728;[faxian_address]&#x5931;&#x8e2a;&#x3002;',
        'detail_share_win_pic'   => '',
        'detail_share_win_text1' => '&#x964c;&#x751f;&#x4eba;',
        'detail_share_win_text2' => '&#x611f;&#x8c22;&#x4f60;&#x7684;&#x968f;&#x624b;&#x8f6c;&#x53d1;',
        'detail_ganxie_content'  => '&#x8c22;&#x8c22;&#x60a8;&#xff0c;&#x964c;&#x751f;&#x4eba;&#xff01;',
    )),
    'is_xunren'      => '0',
    'is_check'       => '0',
    'check_uids'     => '1',
    'check_text'     => '&#x60a8;&#x6709;&#x4e00;&#x6761;&#x65b0;&#x6d88;&#x606f;&#x9700;&#x8981;&#x5ba1;&#x6838;&#xff0c;[link]',
    'check_ts_type'  => '0',
    'classify_nopic' => '',
    'is_enable'      => '1',
  ),
  array (
    'classify_title' => '&#x627e;&#x7269;',
    'pid'            => '0',
    'classify_icon'  => 'source/plugin/junhua_xrzw/static/m/img/zhaowu.png',
    'ordernum'       => '1',
    'fields'         => serialize(array (
        'title'                  => '&#x627e;&#x7269;&#x767b;&#x8bb0;',
        'title_show'             => '1',
        'title_need'             => '1',
        'title_list'             => '1',
        'imgs_show'              => '1',
        'imgs_need'              => '1',
        'imgs_list'              => '1',
        'imgs_zl'                => '',
        'faxian_time'            => '&#x4e22;&#x5931;&#x65f6;&#x95f4;',
        'faxian_time_show'       => '1',
        'faxian_time_need'       => '1',
        'faxian_time_list'       => '1',
        'faxian_time_ms'         => '1',
        'faxian_address'         => '&#x4e22;&#x5931;&#x5730;&#x70b9;',
        'faxian_address_show'    => '1',
        'faxian_address_need'    => '1',
        'faxian_address_list'    => '1',
        'address'                => '',
        'mobile'                 => '&#x5931;&#x4e3b;&#x7535;&#x8bdd;',
        'mobile_show'            => '1',
        'mobile_need'            => '1',
        'lianxiren'              => '&#x5931;&#x4e3b;&#x79f0;&#x547c;',
        'lianxiren_show'         => '1',
        'lianxiren_need'         => '1',
        'miaoshu'                => '&#x7269;&#x54c1;&#x8bf4;&#x660e;',
        'miaoshu_show'           => '1',
        'miaoshu_need'           => '1',
        'miaoshu_placeholder'    => '&#x4e22;&#x5931;&#x4e1c;&#x897f;&#x7684;&#x7279;&#x5f81;&#x6837;&#x5f0f;&#x8be6;&#x7ec6;&#x8bf4;&#x660e;&#x6e05;&#x695a;&#xff01;',
        'names'                  => '',
        'sex'                    => '',
        'age'                    => '',
        'height'                 => '',
        'weight'                 => '',
        'jiguan'                 => '',
        'index_btn'              => '&#x5e2e;&#x627e;&#x4e3b;&#x4eba;',
        'detail_title'           => '&#x4e8e;&lt;span&gt;[faxian_time]&lt;/span&gt;&#x5728;&lt;span&gt;[faxian_address]&lt;/span&gt;&#x4e22;&#x5931;&#x3002;',
        'detail_share'           => '[miaoshu]',
        'detail_share_win_pic'   => '',
        'detail_share_win_text1' => '&#x964c;&#x751f;&#x4eba;',
        'detail_share_win_text2' => '&#x611f;&#x8c22;&#x4f60;&#x7684;&#x968f;&#x624b;&#x8f6c;&#x53d1;&#xff01;',
        'detail_ganxie_content'  => '&#x8c22;&#x8c22;&#x60a8;&#xff0c;&#x964c;&#x751f;&#x4eba;&#xff01;',
    )),
    'is_xunren'      => '0',
    'is_check'       => '1',
    'check_uids'     => '',
    'check_text'     => '&#x60a8;&#x6709;&#x4e00;&#x6761;&#x65b0;&#x7684;&#x627e;&#x7269;&#x4fe1;&#x606f;&#x9700;&#x8981;&#x5ba1;&#x6838;[&#xff0c;link]',
    'check_ts_type'  => '0',
    'classify_nopic' => '',
    'is_enable'      => '1',
  ),
  array (
    'classify_title' => '&#x5931;&#x7269;&#x62db;&#x9886;',
    'pid'            => '0',
    'classify_icon'  => 'source/plugin/junhua_xrzw/static/m/img/shiwu.png',
    'ordernum'       => '0',
    'fields'         => serialize(array (
        'title'                  => '&#x5931;&#x7269;&#x62db;&#x9886;&#x767b;&#x8bb0;',
        'title_show'             => '1',
        'title_need'             => '1',
        'title_list'             => '1',
        'imgs_show'              => '1',
        'imgs_list'              => '1',
        'imgs_zl'                => '',
        'faxian_time'            => '&#x6361;&#x5230;&#x65f6;&#x95f4;',
        'faxian_address'         => '&#x6361;&#x5230;&#x5730;&#x70b9;',
        'address'                => '',
        'mobile'                 => '&#x8054;&#x7cfb;&#x7535;&#x8bdd;',
        'mobile_show'            => '1',
        'mobile_need'            => '1',
        'lianxiren'              => '',
        'miaoshu'                => '&#x7269;&#x54c1;&#x8bf4;&#x660e;',
        'miaoshu_show'           => '1',
        'miaoshu_list'           => '1',
        'miaoshu_placeholder'    => '&#x7269;&#x54c1;&#x5176;&#x4ed6;&#x4fe1;&#x606f;&#x7279;&#x5f81;&#x8be6;&#x7ec6;&#x8bf4;&#x660e;',
        'names'                  => '',
        'sex'                    => '',
        'age'                    => '',
        'height'                 => '',
        'weight'                 => '',
        'jiguan'                 => '',
        'index_btn'              => '&#x5e2e;&#x627e;&#x4e3b;&#x4eba;',
        'detail_title'           => '',
        'detail_share'           => '[miaoshu]',
        'detail_share_win_pic'   => '',
        'detail_share_win_text1' => '&#x611f;&#x8c22;&#x4f60;&#x7684;&#x5e2e;&#x52a9;&#x8f6c;&#x53d1;',
        'detail_share_win_text2' => '&#x6211;&#x4eec;&#x4e5f;&#x60f3;&#x56de;&#x5230;&#x4e3b;&#x4eba;&#x8eab;&#x8fb9;&#xff01;',
        'detail_ganxie_content'  => '&#x8c22;&#x8c22;&#x60a8;&#xff0c;&#x964c;&#x751f;&#x4eba;&#xff01;',
    )),
    'is_xunren'      => '0',
    'is_check'       => '1',
    'check_uids'     => '1',
    'check_text'     => '&#x60a8;&#x6709;&#x4e00;&#x6761;&#x65b0;&#x7684;&#x5931;&#x7269;&#x62db;&#x9886;&#x9700;&#x8981;&#x5ba1;&#x6838;&#xff0c;[link]',
    'check_ts_type'  => '0',
    'classify_nopic' => '',
    'is_enable'      => '1',
  ),
);


foreach ($initVal as $key => $value) {

    $mk = array_keys($value);
    $mv = array_values($value);

    $sql = 'INSERT INTO `pre_junhua_xrzw_classify` ('.'`'.implode('`,`', $mk).'`'.') VALUE ('.'\''.implode('\',\'', $mv).'\''.')';
    runquery($sql);
}


$finish = TRUE;
?>