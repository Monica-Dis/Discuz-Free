<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$execsql = <<<EOF
DROP TABLE IF EXISTS cdb_dev8133_class;
CREATE TABLE `cdb_dev8133_class` (
	    `id` int(11) NOT NULL AUTO_INCREMENT,
    	`name` VARCHAR(200) NOT NULL DEFAULT '',
        `pic` VARCHAR(200) NOT NULL DEFAULT '',
    	`dateline` INT(10) NULL DEFAULT NULL,
        `sortid` INT(10) NULL DEFAULT NULL,
	     PRIMARY KEY (`id`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS cdb_dev8133_sub_class;
CREATE TABLE `cdb_dev8133_sub_class` (
	   `id` int(11) NOT NULL AUTO_INCREMENT,
       `classid` int(11) NOT NULL ,
       `icon` VARCHAR(200) NOT NULL DEFAULT '',
	   `cname` VARCHAR(50) NOT NULL DEFAULT '',
	   `curl` VARCHAR(130) NOT NULL DEFAULT '',
       `dateline` INT(10) NULL DEFAULT NULL,
        `sortid` INT(10) NULL DEFAULT NULL,
	    PRIMARY KEY (`id`),
        index classid(`classid`)
) ENGINE=MyISAM;

EOF;
runquery($execsql);
$finish = TRUE;


@unlink(DISCUZ_ROOT . './source/plugin/dev8133_class/discuz_plugin_dev8133_class.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_class/discuz_plugin_dev8133_class_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_class/discuz_plugin_dev8133_class_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_class/discuz_plugin_dev8133_class_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_class/discuz_plugin_dev8133_class_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_class/install.php');
 

?>