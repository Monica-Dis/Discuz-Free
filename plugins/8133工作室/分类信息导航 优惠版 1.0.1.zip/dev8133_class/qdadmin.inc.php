<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$config  =  $_G['cache']['plugin']['dev8133_class'];

$adminuids = explode(',',$config['adminuids']);
if(!in_array($_G['uid'],$adminuids)){
    showmessage(lang('plugin/dev8133_class', 'qd001'));
}


$op  = daddslashes($_GET['operl']);

if($op == "addsubmit"){
    
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('error');
    }
    
    if(!$_GET['name']){
        showmessage(lang('plugin/dev8133_class', 'qd002'));
    }
    
   
    $activity['name']=daddslashes($_GET['name']);
    
  
  	$activity['sortid'] = intval($_GET['sortid']);
  	
  	
  
  	if($_FILES["picupload"]['name']){
  	    
  	    $upload = new discuz_upload();
  	    $upload->init($_FILES['picupload'], 'forum', random(3, 1), random(8));
  	    if(!in_array($upload->attach['ext'], array('jpg','png','gif','jpeg')))
  	    {
  	        showmessage(lang('plugin/dev8133_class', 'qd0066'));
  	    }
  	    //图片文件不能超过2M
  	    if($upload->attach['size']>2097152){
  	        showmessage(lang('plugin/dev8133_class', 'qd0067'));
  	    }
  	    $upload->save();
  	    $picurl = $_G['setting']['attachurl'].'forum/'.$upload->attach['attachment'];
  	    $activity['pic']= $picurl;
  	    
  	}else{
  	    $activity['pic'] = daddslashes($_GET['pic']);
  	}
  
    
    $activity['dateline'] = $_G['timestamp'];
    C::t('#dev8133_class#dev8133_class')->insert($activity);
    showmessage(lang('plugin/dev8133_class', 'common_01'), 'plugin.php?id=dev8133_class:qdadmin','',array('alert=>right'));
    
}elseif( $op=="edit"){
    
    $aid = intval($_GET['aid']);
    
    $activitydata  = C::t('#dev8133_class#dev8133_class')->fetch_by_id($aid);
    
    if(!$activitydata){
        showmessage('data error');
    }
     
    include template('dev8133_class:qdadmin');
}elseif($op == "editsubmit"){
    
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('error');
    }
    
    $aid = intval($_GET['aid']);
    
    if(!$_GET['name']){
        showmessage(lang('plugin/dev8133_class', 'qd002'));
    }
        
    $activity['name']=($_GET['name']);
    
    $activity['sortid'] = intval($_GET['sortid']);
  
    
    $activitydata  = C::t('#dev8133_class#dev8133_class')->fetch_by_id($aid);
    
    if(!$activitydata){
        showmessage('data error');
    }
    
  	if($_FILES['picupload']['name']){
  	    
  	    $upload = new discuz_upload();
  	    $upload->init($_FILES['picupload'], 'forum', random(3, 1), random(8));
  	    if(!in_array($upload->attach['ext'], array('jpg','png','gif','jpeg')))
  	    {
  	        showmessage(lang('plugin/dev8133_class', 'qd0066'));
  	    }
  	    //图片文件不能超过2M
  	    if($upload->attach['size']>2097152){
  	        showmessage(lang('plugin/dev8133_class', 'qd0067'));
  	    }
  	    $upload->save();
  	    $picurl = $_G['setting']['attachurl'].'forum/'.$upload->attach['attachment'];
  	    
  	     $activity['pic'] = $picurl;
         @unlink(DISCUZ_ROOT . $activitydata['pic']);
         
    }else{
      $activity['pic'] = daddslashes($_GET['pic']);
    }
    
    
    
    C::t('#dev8133_class#dev8133_class')->update(array('id'=>$aid),$activity);
    
    showmessage(lang('plugin/dev8133_class', 'common_01'), 'plugin.php?id=dev8133_class:qdadmin','',array('alert=>right'));
    
}elseif($op == "delete"){
    
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('error');
    }
    
    $aid = intval($_GET['aid']);
  
   	$activitydata  = C::t('#dev8133_class#dev8133_class')->fetch_by_id($aid);
   	
   	if(!$activitydata){
   	    showmessage('data error');
   	}
  	
  	@unlink(DISCUZ_ROOT . $activitydata['pic']);
  
    C::t('#dev8133_class#dev8133_class')->delete_by_id($aid);
    showmessage(lang('plugin/dev8133_class', 'common_01'), 'plugin.php?id=dev8133_class:qdadmin','',array('alert=>right'));
    
}else{
    
    $ppp = 30;
    $tmpurl = 'plugin.php?id=dev8133_class:qdadmin';
    $page = max ( 1, intval ( $_GET ['page'] ) );
    $startlimit = ($page - 1) * $ppp;
    $allcount = C::t('#dev8133_class#dev8133_class')->count_all($wheres);
    if ($allcount) {
        $uidccfadata = C::t ( '#dev8133_class#dev8133_class' )->fetch_all_by_limit ( $startlimit, $ppp, $wheres );
    }
    $multipage = '';
    $multipage = multi ( $allcount, $ppp, $page, $_G ['siteurl'] . $tmpurl );

    include template('dev8133_class:qdadmin');
}
//From: Dism_taobao-com
?>