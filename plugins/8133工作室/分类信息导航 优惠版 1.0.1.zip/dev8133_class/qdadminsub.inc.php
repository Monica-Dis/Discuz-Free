<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$config  =  $_G['cache']['plugin']['dev8133_class'];
$adminuids = explode(',',$config['adminuids']);
if(!in_array($_G['uid'],$adminuids)){
    showmessage(lang('plugin/dev8133_class', 'qd001'));
}

$op  = daddslashes($_GET['operl']);


if($op == "addsubmit"){
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('error');
    }
    $aid = intval($_GET['aid']);
    if(!$_GET['cname'] || !$aid || (!$_GET['icon'] && !$_FILES['iconupload']['name']) || !$_GET['curl']){
        showmessage(lang('plugin/dev8133_class', 'qd003'));
    }
    $activity['cname']=daddslashes($_GET['cname']);
    $activity['sortid'] = intval($_GET['sortid']);
  
    
    
    if($_FILES["iconupload"]['name']){
        
        
        $upload = new discuz_upload();
        $upload->init($_FILES['iconupload'], 'forum', random(3, 1), random(8));
        if(!in_array($upload->attach['ext'], array('jpg','png','gif','jpeg')))
        {
            showmessage(lang('plugin/dev8133_class', 'qd0066'));
        }
        //图片文件不能超过2M
        if($upload->attach['size']>2097152){
            showmessage(lang('plugin/dev8133_class', 'qd0067'));
        }
        $upload->save();
        $picurl = $_G['setting']['attachurl'].'forum/'.$upload->attach['attachment'];
        
        $activity['icon']=$picurl;
        
        
    }else{
        $activity['icon'] = daddslashes($_GET['pic']);
    }

    $activity['classid'] = $aid;
    $activity['curl'] = daddslashes($_GET['curl']);
    $activity['dateline'] = $_G['timestamp'];
    C::t('#dev8133_class#dev8133_sub_class')->insert($activity);
    showmessage(lang('plugin/dev8133_class', 'common_01'), 'plugin.php?id=dev8133_class:qdadminsub&aid='.$aid,'',array('alert=>right'));
    
}elseif( $op=="edit"){
    
    $aid = intval($_GET['aid']);
    
    $operid = intval($_GET['operid']);
    
    $activitydata  = C::t('#dev8133_class#dev8133_sub_class')->fetch_by_id($operid);
     
    
    if(!$activitydata){
        showmessage('data error');
    }
    
    include template('dev8133_class:qdadminsub');
    
}elseif($op == "editsubmit"){
    
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('error');
    }
    
    $operid = intval($_GET['operid']);
    $aid = intval($_GET['aid']);
    
    if(!$_GET['cname'] || !$aid || (!$_GET['icon'] && !$_FILES['iconupload']['name']) || !$_GET['curl']){
        showmessage(lang('plugin/dev8133_class', 'qd003'));
    }
    
 
  
  	$activitydata  = C::t('#dev8133_class#dev8133_sub_class')->fetch_by_id($operid);
  	
  	
  	if(!$activitydata){
  	    showmessage('data error');
  	}
  	
  	if($_FILES['iconupload']['name']){
  	    
  	    $upload = new discuz_upload();
  	    $upload->init($_FILES['iconupload'], 'forum', random(3, 1), random(8));
  	    if(!in_array($upload->attach['ext'], array('jpg','png','gif','jpeg')))
  	    {
  	        showmessage(lang('plugin/dev8133_class', 'qd0066'));
  	    }
  	    //图片文件不能超过2M
  	    if($upload->attach['size']>2097152){
  	        showmessage(lang('plugin/dev8133_class', 'qd0067'));
  	    }
  	    $upload->save();
  	    $picurl = $_G['setting']['attachurl'].'forum/'.$upload->attach['attachment'];
  	   
  	    $activity['icon'] = $picurl;
        @unlink(DISCUZ_ROOT . $activitydata['icon']);
        
    }else{
        $activity['icon'] = ($_GET['icon']);
    }
  
    $activity['cname']=($_GET['cname']);
    
    $activity['sortid'] = intval($_GET['sortid']);
    
   
    $activity['curl'] = ($_GET['curl']);
    
    C::t('#dev8133_class#dev8133_sub_class')->update(array('id'=>$operid),$activity);
    
    showmessage(lang('plugin/dev8133_class', 'common_01'), 'plugin.php?id=dev8133_class:qdadminsub&aid='.$aid,'',array('alert=>right'));
    
}elseif($op == "delete"){
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('error');
    }
    
    $aid = intval($_GET['aid']);
  
    $operid = intval($_GET['operid']);
  
  	$activitydata  = C::t('#dev8133_class#dev8133_sub_class')->fetch_by_id($operid);
  	
  	if(!$activitydata){
  	    showmessage('data error');
  	}
  	
  	
  	@unlink(DISCUZ_ROOT . $activitydata['icon']);
    
 
    C::t('#dev8133_class#dev8133_sub_class')->delete_by_id($operid);
    showmessage(lang('plugin/dev8133_class', 'common_01'), 'plugin.php?id=dev8133_class:qdadminsub&aid='.$aid,'',array('alert=>right'));
    
}else{
    
    
    $aid = intval($_GET['aid']);
    $ppp = 30;
    $tmpurl = 'plugin.php?id=dev8133_class:qdadminsub';
    $page = max ( 1, intval ( $_GET ['page'] ) );
    $startlimit = ($page - 1) * $ppp;
    
    $wheres = " where classid=".$aid;
    
    $allcount = C::t('#dev8133_class#dev8133_sub_class')->count_all($wheres);
    if ($allcount) {
        $uidccfadata = C::t ( '#dev8133_class#dev8133_sub_class' )->fetch_all_by_limit ( $startlimit, $ppp, $wheres );
    }
    $multipage = '';
    $multipage = multi ( $allcount, $ppp, $page, $_G ['siteurl'] . $tmpurl );

    include template('dev8133_class:qdadminsub');
}
//From: Dism·taobao·com
?>