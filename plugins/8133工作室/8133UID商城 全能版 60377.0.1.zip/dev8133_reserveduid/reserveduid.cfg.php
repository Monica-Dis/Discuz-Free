<?php
	if (!defined('IN_DISCUZ')) {
		exit ('Access Denied');
	}
	$trstatus =  array(
		1=>lang('plugin/dev8133_reserveduid', 'orderstatus1'),
		2=>lang('plugin/dev8133_reserveduid', 'orderstatus2'),
		3=>lang('plugin/dev8133_reserveduid', 'orderstatus3'),
		
	);
?>