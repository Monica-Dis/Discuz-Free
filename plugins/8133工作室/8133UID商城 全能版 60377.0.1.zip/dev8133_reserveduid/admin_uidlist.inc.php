<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'/source/plugin/dev8133_reserveduid/reserveduid.cfg.php';

loadcache('plugin');

$reserveduidplg =  $_G['cache']['plugin']['dev8133_reserveduid'];

foreach($trstatus as $sk=>$sv){
	$options .= "<option value='$sk'>$sv</option>";
}
$operation= daddslashes($_GET['cp']);

if($operation == "delete"){
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		cpmsg('error');
	}
	$orderid = daddslashes($_GET['orderid']);
	C::t('#dev8133_reserveduid#dev8133_reserveduid')->deteletbyorder($orderid);
	cpmsg(lang('plugin/dev8133_reserveduid', 'admin_cgtc'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=admin_uidlist&identifier=dev8133_reserveduid', 'succeed');
	
}elseif($operation == "sale"){
		if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
			cpmsg('error');
		}
		$orderid = daddslashes($_GET['orderid']);
		$offline=intval($_GET['offline']);
		if($offline == 1){
			$updatedata['status']=2;
		}elseif($offline == 2){
			$updatedata['status']=1;
		}else{
			cpmsg("error");
		}
		$updatedata['dateline']  = time();
		
		C::t('#dev8133_reserveduid#dev8133_reserveduid')->update(array('id'=>$orderid),$updatedata);
		cpmsg(lang('plugin/dev8133_reserveduid', 'admin_cgtc'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=admin_uidlist&identifier=dev8133_reserveduid', 'succeed');

}elseif($operation == "setprice"){
	
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		cpmsg('error');
	}
	
	$orderid = intval($_GET['orderid']);
	showtableheader(lang('plugin/dev8133_reserveduid', 'admin_ss1'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=admin_uidlist&identifier=dev8133_reserveduid');   
	showtablerow('','', array(
				lang('plugin/dev8133_reserveduid', 'admin_tsinfo6').$orderid."</strong><br/><br/><strong>".lang('plugin/dev8133_reserveduid', 'admin_tsinfo7')."</strong><input value=$orderid name=\"orderid\" type=\"hidden\"/><input name=\"price\" type=\"text\"/>",
				"",
	));
	showsubmit('setpricesubmit');
	showformfooter(); /*Dism_taobao_com*/
	showtablefooter(); /*Dism·taobao·com*/
	exit;
}
if(submitcheck('setpricesubmit')) {
	
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
			cpmsg('error');
	}
	
	$setprice = intval($_GET['price']);
	$orderid = intval($_GET['orderid']);
	
	if($setprice <=0){
		cpmsg(lang('plugin/dev8133_reserveduid', 'admin_tsinfo8'));
	}
	
	$updatedata['price']=$setprice;
	$updatedata['dateline']  = time();
	
	C::t('#dev8133_reserveduid#dev8133_reserveduid')->update(array('id'=>$orderid),$updatedata);
	
	cpmsg(lang('plugin/dev8133_reserveduid', 'admin_cgtc'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=admin_uidlist&identifier=dev8133_reserveduid', 'succeed');
}

if(submitcheck('appdatasearch')) {
	showtableheader(lang('plugin/dev8133_reserveduid', 'admin_ss'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=admin_uidlist&identifier=dev8133_reserveduid');   
	showtablerow('','', array(
				"UID:<input  name=\"searchuid\" type=\"text\"/>&nbsp;&nbsp;&nbsp;&nbsp;".lang('plugin/dev8133_reserveduid', 'admin_tsinfo10')."<select name='uidstatus'><option value=0>".lang('plugin/dev8133_reserveduid', 'admin_tsinfo9')."</option>".$options."</select>",
				"",
	));
	showsubmit('appdatasearch');
	showformfooter(); /*Dism_taobao_com*/
	showtablefooter(); /*Dism·taobao·com*/
	
	showtableheader(lang('plugin/dev8133_reserveduid', 'admin_dqgy'));
	
	showtablerow("",'',array(
				lang('plugin/dev8133_reserveduid', 'admin_l01'),
				lang('plugin/dev8133_reserveduid', 'admin_l02'),
				lang('plugin/dev8133_reserveduid', 'admin_l03'),
				lang('plugin/dev8133_reserveduid', 'admin_l07'),
				lang('plugin/dev8133_reserveduid', 'admin_l04'),
				lang('plugin/dev8133_reserveduid', 'admin_l05'),
				lang('plugin/dev8133_reserveduid', 'admin_l06')
	));
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
			cpmsg('error');
	}
	
	$searchuid = intval($_GET['searchuid']);
	$uidstatus = intval($_GET['uidstatus']);
	
	if(!$searchuid && !$uidstatus){
		$url = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&pmod=admin_uidlist&identifier=dev8133_reserveduid';
		Header("Location: $url");
	}
	
	$appdata = C::t('#dev8133_reserveduid#dev8133_reserveduid')->fetch_orderCondition($searchuid,$uidstatus);
	
	foreach($appdata as $appvalue){
			$appvalue['dateline']  = dgmdate($appvalue['dateline'],'Y/m/d H:i');
			
			$str = "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=admin_uidlist&identifier=dev8133_reserveduid&cp=setprice&formhash=".formhash()."&orderid=".$appvalue['id']."'>".lang('plugin/dev8133_reserveduid', 'admin_l08')."</a>";
			if($appvalue['status'] == 1){
				$str .= " | <a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=admin_uidlist&identifier=dev8133_reserveduid&cp=sale&offline=1&formhash=".formhash()."&orderid=".$appvalue['id']."'>".lang('plugin/dev8133_reserveduid', 'admin_l09')."</a>";
				$str .= " | <a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=admin_uidlist&identifier=dev8133_reserveduid&cp=delete&formhash=".formhash()."&orderid=".$appvalue['id']."'>".lang('plugin/dev8133_reserveduid', 'admin_l10')."</a>";
			}elseif($appvalue['status'] == 2){
				$str .= " | <a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=admin_uidlist&identifier=dev8133_reserveduid&cp=sale&offline=2&formhash=".formhash()."&orderid=".$appvalue['id']."'>".lang('plugin/dev8133_reserveduid', 'admin_l11')."</a>";
			}
			
			showtablerow("",'',array(
				$appvalue['uid'],
				$trstatus[$appvalue['status']],
				$appvalue['price']." " .$_G['setting']['extcredits'][$reserveduidplg['reserveduid_jftype']]['title'],
				$appvalue['buyusername'],
				$appvalue['buyip'],
				$appvalue['dateline'],
				$str
			));
	}
	showtablefooter(); /*Dism·taobao·com*/
	exit;
}

if(!submitcheck('appdatasearch')) {
	showtableheader(lang('plugin/dev8133_reserveduid', 'admin_ss'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=admin_uidlist&identifier=dev8133_reserveduid');   
	showtablerow('','', array(
				"UID：<input  name=\"searchuid\" type=\"text\"/>&nbsp;&nbsp;&nbsp;&nbsp;UID状态：<select name='uidstatus'><option value=0>--请选择--</option>".$options."</select>",
				"",
			));
	showsubmit('appdatasearch');
	showformfooter(); /*Dism_taobao_com*/
	showtablefooter(); /*Dism·taobao·com*/
}

	$curpage=intval(getgpc('page'));
	if($curpage<1){
		$curpage=1;
	}
	
	$pageUrl=ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=admin_uidlist&identifier=dev8133_reserveduid";

	showtableheader(lang('plugin/dev8133_reserveduid', 'admin_dqgy'));
	
	showtablerow("",'',array(
				lang('plugin/dev8133_reserveduid', 'admin_l01'),
				lang('plugin/dev8133_reserveduid', 'admin_l02'),
				lang('plugin/dev8133_reserveduid', 'admin_l03'),
				lang('plugin/dev8133_reserveduid', 'admin_l07'),
				lang('plugin/dev8133_reserveduid', 'admin_l04'),
				lang('plugin/dev8133_reserveduid', 'admin_l05'),
				lang('plugin/dev8133_reserveduid', 'admin_l06')
	));
	
	$pagesize=20;
	
	$appdata = C::t('#dev8133_reserveduid#dev8133_reserveduid')->fetchappdataall(($curpage-1)*$pagesize,$pagesize);
	
	$sumcount = C::t('#dev8133_reserveduid#dev8133_reserveduid')->count();
	
	foreach($appdata as $appvalue){
			$appvalue['dateline']  = dgmdate($appvalue['dateline'],'Y/m/d H:i');
			
			$str = "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=admin_uidlist&identifier=dev8133_reserveduid&cp=setprice&formhash=".formhash()."&orderid=".$appvalue['id']."'>".lang('plugin/dev8133_reserveduid', 'admin_l08')."</a>";
			if($appvalue['status'] == 1){
				$str .= " | <a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=admin_uidlist&identifier=dev8133_reserveduid&cp=sale&offline=1&formhash=".formhash()."&orderid=".$appvalue['id']."'>".lang('plugin/dev8133_reserveduid', 'admin_l09')."</a>";
				$str .= " | <a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=admin_uidlist&identifier=dev8133_reserveduid&cp=delete&formhash=".formhash()."&orderid=".$appvalue['id']."'>".lang('plugin/dev8133_reserveduid', 'admin_l10')."</a>";
			}elseif($appvalue['status'] == 2){
				$str .= " | <a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=admin_uidlist&identifier=dev8133_reserveduid&cp=sale&offline=2&formhash=".formhash()."&orderid=".$appvalue['id']."'>".lang('plugin/dev8133_reserveduid', 'admin_l11')."</a>";
			}
			showtablerow("",'',array(
				$appvalue['uid'],
				$trstatus[$appvalue['status']],
				
				$appvalue['price']." " .$_G['setting']['extcredits'][$reserveduidplg['reserveduid_jftype']]['title'],
				
				$appvalue['buyusername'],
				$appvalue['buyip'],
				$appvalue['dateline'],
				$str
			));
	}
	$pagenav=multi($sumcount, $pagesize, $curpage, $pageUrl);
	echo "<tr><td align=left colspan=5>".$pagenav."</td><tr>";
	showtablefooter(); /*Dism·taobao·com*/
?>