<?php 
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$devop  = dhtmlspecialchars($_GET['devop']);

$curjf = getuserprofile("extcredits".$reserveduidplg['reserveduid_jftype']);

if($devop == "buyuid"){
	
	if(!$_G['uid']) {
		showmessage('not_loggedin', NULL, array(), array('login' => 1));
	}
	
	$resid =  intval($_GET['resid']);
	include template('common/header_ajax');
	include template('dev8133_reserveduid:main_buyuid');
	include template('common/footer_ajax');
	
}elseif($devop =="buysubmit"){
	
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		showmessage('error');
	}
	
	if(!$_G['uid']) {
		showmessage('not_loggedin', NULL, array(), array('login' => 1));
	}
	
	$resid =  intval($_GET['resid']);

	$singledata = C::t('#dev8133_reserveduid#dev8133_reserveduid')->fetchbyid($resid);
	
	if(!$singledata){
		showmessage("error");
	}
	
	if($singledata['status'] != 2){
		
		showmessage("status error");
	}
	
	$username = dhtmlspecialchars(trim($_GET['username']));
	
	$usernamelen = dstrlen($username);
	
	$password1 = dhtmlspecialchars($_GET['password1']);
	
	$password1len = dstrlen($password1);
	
	$password2 = dhtmlspecialchars($_GET['password2']);
	
	
	if($usernamelen < 3) {
		showmessage('profile_username_tooshort');
	} elseif($usernamelen > 15) {
		showmessage('profile_username_toolong');
	}
	
	if($password1len <6){
		showmessage(lang('plugin/dev8133_reserveduid', 'add1'));
	}
	
	if($password1 != $password2){
		showmessage('profile_passwd_notmatch');
	}
	
	//�����Ƿ�

	if($curjf < $singledata['price']){
		showmessage(lang('plugin/dev8133_reserveduid', 'add2'));
	}
	loaducenter();
	
	$user = uc_user_register($username,"","");
	
	if($user <= 0) {
		if($user == -1) {
			showmessage('profile_username_illegal');
		} elseif($user == -2) {
			showmessage('profile_username_protect');
		} elseif($user == -3) {
			showmessage('profile_username_duplicate');
		} 
	}
	
	$md5pass = preg_match('/^\w{32}$/',$password1) ? $password2 : md5($password1);
	
	$saltkey = substr(uniqid(rand()), 0, 6);
	
	$password = md5($md5pass.$saltkey);
	
	$userdata['uid'] =  $singledata['uid'];
	$userdata['username'] = $username;
	$userdata['password'] = $password;
	$userdata['salt'] = $saltkey;
	
	//��������
	$updatedata = array(
		'saltkey'=>$saltkey,
		'buyusername'=>$username,
		'buyip'=>$_G['clientip'],
		'status'=>3,
		'dateline'=>time(),
	);
	
	
	C::t('#dev8133_reserveduid#dev8133_reserveduid')->update(array('id'=>$singledata[id]),$updatedata);
	
	//�����û�
	C::t('#dev8133_reserveduid#dev8133_reserveduid_member')->insert($userdata);
	
	//�ۻ���
	updatemembercount($_G['uid'], array('extcredits'.$reserveduidplg['reserveduid_jftype']=>-$singledata['price']),true,'',0,'',lang('plugin/dev8133_reserveduid', 'add4'),lang('plugin/dev8133_reserveduid', 'add5'));
	
	showmessage(lang('plugin/dev8133_reserveduid', 'add3'),"plugin.php?id=dev8133_reserveduid:reserveduid",array(),array('alert'=>'right'));
	
		
}else{
	
	$curpage=intval(getgpc('page'));
	if($curpage<1){
		$curpage=1;
	}
	
	$pageUrl="plugin.php?id=dev8133_reserveduid:reserveduid";
	
	$pagesize=20;
	
	$selluid = C::t('#dev8133_reserveduid#dev8133_reserveduid')->fetchbystatus(2,($curpage-1)*$pagesize,$pagesize);
	
	$sumcount =C::t('#dev8133_reserveduid#dev8133_reserveduid')->fetchbystatusc(2);
	
	$pagenav=multi($sumcount['statuscount'], $pagesize, $curpage, $pageUrl);
	
	//��ȡ�����¼
	$buysucess = C::t('#dev8133_reserveduid#dev8133_reserveduid')->fetchbystatus(3,0,10);
	
}
include template('dev8133_reserveduid:main');

?>