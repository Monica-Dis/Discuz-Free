<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')||!defined('IN_ADMINCP')){
    exit('AccessDenied');
}

$createtablesql = <<<EOF
DROP TABLE IF EXISTS cdb_dev8133_jfwallet_jf;
CREATE TABLE `cdb_dev8133_jfwallet_jf` (
	`orderid` VARCHAR(100) NOT NULL,
	`uid` MEDIUMINT(8) UNSIGNED NOT NULL,
	`username` VARCHAR(30) NOT NULL DEFAULT '',
	`trade_no` VARCHAR(100) NOT NULL DEFAULT '',
	`price` FLOAT(5,2) NULL DEFAULT NULL,
	`paystatus` CHAR(2) NOT NULL DEFAULT '1',
	`integralc` INT(10) NULL DEFAULT NULL,
	`integraltype` CHAR(2) NULL DEFAULT NULL,
	`paytype` VARCHAR(30) NOT NULL DEFAULT '',
	`dateline` INT(10) NULL DEFAULT NULL,
	`paydateline` INT(10) NULL DEFAULT NULL,
	PRIMARY KEY (`orderid`),
	INDEX `weixc_uid` (`uid`)
)

DROP TABLE IF EXISTS cdb_dev8133_jfwallet_zz;
CREATE TABLE `cdb_dev8133_jfwallet_zz` (
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`uid` MEDIUMINT(8) UNSIGNED NOT NULL,
	`username` VARCHAR(30) NOT NULL DEFAULT '',
	`touser` VARCHAR(100) NOT NULL DEFAULT '',
	`integral` INT(10) NULL DEFAULT NULL,
	`integraltype` CHAR(2) NULL DEFAULT NULL,
    `integralfree` INT(10) NULL DEFAULT NULL,
	`dateline` INT(10) NULL DEFAULT NULL,
	PRIMARY KEY (`id`)
)

EOF;
runquery($createtablesql);
$finish = TRUE;


@unlink(DISCUZ_ROOT . './source/plugin/dev8133_jfwallet/discuz_plugin_dev8133_jfwallet.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_jfwallet/discuz_plugin_dev8133_jfwallet_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_jfwallet/discuz_plugin_dev8133_jfwallet_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_jfwallet/discuz_plugin_dev8133_jfwallet_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_jfwallet/discuz_plugin_dev8133_jfwallet_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_jfwallet/install.php');
?>