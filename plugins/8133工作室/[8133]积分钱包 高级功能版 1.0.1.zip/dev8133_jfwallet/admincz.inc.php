<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')||!defined('IN_ADMINCP')){
	exit('AccessDenied');
}

if(!$_G['cache']['plugin']){
    loadcache('plugin');
}

if(submitcheck("delall")){
	if(is_array($_GET['delete'])){
		C::t('#dev8133_jfwallet#dev8133_jfwallet_jf')->delete($_GET['delete']);
	}
	cpmsg(lang('plugin/dev8133_jfwallet', 'common_01'),ADMINSCRIPT.'?frames=yes&action=plugins&operation=config&identifier=dev8133_jfwallet&pmod=admincz','succeed');
}

$username = daddslashes(dhtmlspecialchars($_GET['username']));

showtableheader(lang('plugin/dev8133_jfwallet', 'common_05'));
showformheader('plugins&operation=config&do='.$pluginid.'&pmod=dev8133_jfwallet&pmod=admincz','testhd');
showsetting(lang('plugin/dev8133_jfwallet', 'common_02'),'username',$username,'text');
showsubmit('searchsubmit');
showformfooter(); /*dism��taobao��com*/
showtablefooter(); /*dism _ taobao _ com*/

$wheres='where 1 ';

if($_GET['username']){
	$wheres.=" AND username like'%".daddslashes($_GET['username'])."%'";
}


showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=".$plugin["identifier"]."&pmod=admincz");
showtableheader(lang('plugin/dev8133_jfwallet', 'common_04'));
showsubtitle(array(
    lang('plugin/dev8133_jfwallet', 'common_03'),
    lang('plugin/dev8133_jfwallet', 'acz_01'),
    lang('plugin/dev8133_jfwallet', 'acz_02'),
    lang('plugin/dev8133_jfwallet', 'acz_03'),
    lang('plugin/dev8133_jfwallet', 'acz_04'),
    lang('plugin/dev8133_jfwallet', 'acz_05'),
    lang('plugin/dev8133_jfwallet', 'acz_06'),
    lang('plugin/dev8133_jfwallet', 'acz_07'),
    lang('plugin/dev8133_jfwallet', 'acz_08'),
    lang('plugin/dev8133_jfwallet', 'acz_09'),
));

$pagesize=30;
$pageUrl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=dev8133_jfwallet&pmod=admincz';
$curpage=max(1,intval($_GET['page']));
$startlimit=($curpage-1)*$pagesize;
$allcount=C::t('#dev8133_jfwallet#dev8133_jfwallet_jf')->count_all($wheres);
if($allcount){
	$query=C::t('#dev8133_jfwallet#dev8133_jfwallet_jf')->fetch_all_by_limit($startlimit,$pagesize,$wheres);
	foreach($query as $val){
		$table=array();
		$table[0]='<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['orderid'].'"/>';
		$table[1]=$val['orderid'];
		$table[2]=$val['username'];
		$table[3]=$val['integralc'].$_G['setting']['extcredits'][$val['integraltype']]['title'];
		$table[4]=$val['price'];
		$table[5]=$val['paytype'];
		$table[7]=$val['paystatus']==1?lang('plugin/dev8133_jfwallet', 'acz_010'):lang('plugin/dev8133_jfwallet', 'acz_011');
		$table[9]=$val['trade_no'];
		$table[20]=$val['paydateline']?dgmdate($val['paydateline'],'Y/m/dH:i'):'-';
		$table[30]=$val['dateline']?dgmdate($val['dateline'],'Y/m/dH:i'):'-';
		showtablerow('',array(
				''
		),$table);
	}
}
$multipage='';
$multipage=multi($allcount,$pagesize,$curpage,$_G['siteurl'].$pageUrl);
if($multipage)
	echo'<trclass="hover"><tdcolspan="9">'.$multipage.'</td></tr>';
showsubmit('delall','submit','del');
showtablefooter(); /*dism _ taobao _ com*/
showformfooter(); /*dism��taobao��com*/