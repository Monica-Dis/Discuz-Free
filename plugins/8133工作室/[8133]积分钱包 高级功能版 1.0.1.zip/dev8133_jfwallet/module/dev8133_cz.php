<?php 

if(!defined('IN_DISCUZ')) {

	exit('Access Denied');

}


$title = lang('plugin/dev8133_jfwallet', 'cz_title');

$jftypecount = getuserprofile('extcredits'.$plugincfg['czjf']);

$czbl =$plugincfg['czbl'];

$subdmod = daddslashes($_GET['subdmod']);

if($subdmod == "paysubmit"){
    
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('formhash error');
    }
    
    $buyinte = intval($_GET['buyinte']);
    
    if($buyinte<$plugincfg['czmin']){
        showmessage(lang('plugin/dev8133_jfwallet', 'cz_alert_01'));
    }
    $price = $buyinte * $plugincfg['czbl'];
    $price =round($price,2);
    require_once("source/plugin/dev8133_jfwallet/lib/alipay/alipay.config.php");
    require_once("source/plugin/dev8133_jfwallet/lib/alipay/alipay_submit.class.php");
    
    $orderdata = array(
        'orderid'=>dgmdate(TIMESTAMP, 'YmdHis').random(10),
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'integralc'=>$buyinte,
        'integraltype'=>$plugincfg['czjf'],
        'price'=>$price,
        'paytype'=>'alipay',
        'dateline'=>TIMESTAMP,
    );
    DB::insert("dev8133_jfwallet_jf", $orderdata);
    
    $title = "Integral recharge";
    //�̻������ţ��̻���վ����ϵͳ��Ψһ�����ţ�����
    $out_trade_no = $orderdata['orderid'];
    //�������ƣ�����
    $subject = $title;
    //���������
    $total_fee = $price;
    //����̨ҳ���ϣ���Ʒչʾ�ĳ����ӣ�����
    $show_url = "plugin.php?id=dev8133_jfwallet:jfwallet";
    //����Ҫ����Ĳ������飬����Ķ�
    $parameter = array(
        "service"       => $alipay_config['service'],
        "partner"       => $alipay_config['partner'],
        "seller_id"  => $alipay_config['seller_id'],
        "payment_type"	=> $alipay_config['payment_type'],
        "notify_url"	=> $alipay_config['notify_url'],
        "return_url"	=> $alipay_config['return_url'],
        "_input_charset"	=> trim(strtolower($alipay_config['input_charset'])),
        "out_trade_no"	=> $out_trade_no,
        "subject"	=> $subject,
        "total_fee"	=> $total_fee,
        "show_url"	=> $show_url,
    );
    //��������
    $alipaySubmit = new AlipaySubmit($alipay_config);
    $html_text = $alipaySubmit->buildRequestForm($parameter,"get", "alipay go");
    echo $html_text;
}elseif($subdmod == "paylog"){
    
    if($_G['uid']){
        $wheres='where 1 AND uid='.$_G['uid'];
        
        $maxc=30;
        
        $pagenumurl='plugin.php?id=dev8133_jfwallet:jfwallet&subdmod=paylog';
        
        $pagenum=max(1,intval($_GET['page']));
        
        $start=($pagenum-1)*$maxc;
        
        $datacount = C::t('#dev8133_jfwallet#dev8133_jfwallet_jf')->count_all($wheres);
        
        if($datacount){
            $data = C::t('#dev8133_jfwallet#dev8133_jfwallet_jf')->fetch_all_by_limit($start,$maxc,$wheres);
        }
        
        $pagenav=multi($datacount,$maxc,$pagenum,$pagenumurl);
    }
    include template('dev8133_jfwallet:cz_log');
}else{
    include template('dev8133_jfwallet:cz');
}
//From: Dism_taobao-com
?>