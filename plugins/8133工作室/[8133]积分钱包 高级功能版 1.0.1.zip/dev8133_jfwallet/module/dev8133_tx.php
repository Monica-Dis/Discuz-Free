<?php 

if(!defined('IN_DISCUZ')) {

	exit('Access Denied');

}

$title = lang('plugin/dev8133_jfwallet', 'tx_title');
$cfgcontent =  $_G['cache']['plugin']['dev8133_integrallift'];

if(!$cfgcontent){
    showmessage(lang('plugin/dev8133_jfwallet', 'tx_alert_01'));
}

require_once DISCUZ_ROOT.'/source/plugin/dev8133_integrallift/cfg/config.cfg.php';
$subdmod = daddslashes($_GET['subdmod']);
$countat = unserialize($cfgcontent['account_type']);
$jftype = $cfgcontent['jftype'];
$jfbl = $cfgcontent['jfbl'];
$jftypecount = getuserprofile('extcredits'.$jftype);
$zdtxjf = $cfgcontent['zdtxjf'];

$msxfzd = $cfgcontent['msxfzd'];
$sxfbl = $cfgcontent['sxfbl'];
$sxfbljs = ($cfgcontent['sxfbl']*100);
$showaat= array();
for ($i=0;$i<count($countat);$i++){
    $showaat += array($countat[$i]=>$account_types[$countat[$i]]);
    
}
$isuser = C::t('#dev8133_integrallift#dev8133_integralliftaccount')->fetchbyuiddata($_G['uid']);

if($isuser){
    $isuser['account_type'] = $account_types[$isuser['account_type']];
}

if($subdmod  == 'txaddsubmit'){
    
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('formhash error');
    }
    if($_G['uid']){
        $status1 = C::t('#dev8133_integrallift#dev8133_integrallift')->fetchbystatus01($_G['uid']);
    }
    if($status1){
        showmessage(lang('plugin/dev8133_integrallift', 'cashsq_status1'), 'plugin.php?id=dev8133_jfwallet:jfwallet&dmod=tx',"",array('alert'=>"error"));
    }
    
    $tjcount = daddslashes($_GET['tjcount']);
    $password = trim(daddslashes($_GET['password']));
    
    // �ж������Ƿ���ȷ
    if($password !=  $isuser['passwrod']){
        showmessage(lang('plugin/dev8133_integrallift', 'cashsq_txmmcw'), 'plugin.php?id=dev8133_jfwallet:jfwallet&dmod=tx',"",array('alert'=>"error"));
    }
    
    if($txje > $jftypecount){
        showmessage(lang('plugin/dev8133_integrallift', 'cashsq_txjfbz'), 'plugin.php?id=dev8133_jfwallet:jfwallet&dmod=tx',"",array('alert'=>"error"));
    }
    
    $txje  = $tjcount / $jfbl;
    
    if($txje < $cfgcontent['zdtxjf']){
        showmessage(lang('plugin/dev8133_integrallift', 'cashsq_txjfzx'), 'plugin.php?id=dev8133_jfwallet:jfwallet&dmod=tx',"",array('alert'=>"error"));
    }
    
    if($txje > $jftypecount){
        showmessage(lang('plugin/dev8133_integrallift', 'cashsq_txjfed'), 'plugin.php?id=dev8133_jfwallet:jfwallet&dmod=tx',"",array('alert'=>"error"));
    }
    
    //�۳�������
     if($tjcount < $msxfzd){
        $sxfsumje = round ($tjcount*$sxfbl,2);
         $tjcount = $tjcount-$sxfsumje;
     } 
    
    $sxfsumje = round ($tjcount*$sxfbl,2);
    $tjcount = $tjcount-$sxfsumje;
    
    $insertdata  = array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'orderid'=>dgmdate(TIMESTAMP, 'YmdHis'),
        'jfcount'=>$txje,
        'txje'=>$tjcount,
        'jftype'=>$jftype,
        'tktype'=>$isuser['account_type'],
        'tkaccount'=>$isuser['skaccount'],
        'skname'=>$isuser['skname'],
        'status'=>1,
        'dateline'=>time(),
    );
    C::t('#dev8133_integrallift#dev8133_integrallift')->insert($insertdata);
    
    updatemembercount($_G['uid'], array('extcredits'.$jftype =>-$txje));
    
    showmessage(lang('plugin/dev8133_integrallift', 'cashsq_txcg'), 'plugin.php?id=dev8133_jfwallet:jfwallet&dmod=tx');
}elseif($subdmod == "txlog"){
    
    $curpage=intval($_GET['page']);
    if($curpage<1){
        $curpage=1;
    }
    $pageUrl="plugin.php?id=dev8133_jfwallet:jfwallet&dmod=tx&subdmod=txlog";
    
    $pagesize=30;
    
    $data = C::t('#dev8133_integrallift#dev8133_integrallift')->fetchappdata(($curpage-1)*$pagesize,$pagesize,$_G['uid']);
    
    $sumcount = C::t('#dev8133_integrallift#dev8133_integrallift')->count();
    
    $pagenav=multi($sumcount, $pagesize, $curpage, $pageUrl);
    
    include template('dev8133_jfwallet:tx_log');
}else{
    include template('dev8133_jfwallet:tx');
}
//From: Dism��taobao��com
?>