<?php 
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$title = lang('plugin/dev8133_jfwallet', 'zz_title');

$jftypecount = getuserprofile('extcredits'.$plugincfg['zzjf']);

$zzflstr = $plugincfg['zzfl']*100;

$jftype  = $plugincfg['zzjf'];

$subdmod = daddslashes($_GET['subdmod']);

if($subdmod  == 'zzsubmit'){
    
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('formhash error');
    }
    
    $zzje = intval($_GET['zzje']);
    
    $touser = daddslashes($_GET['touser']);
    
    if($touser == $_G['username']){
        showmessage(lang('plugin/dev8133_jfwallet', 'zz_alert_01'));
    }
    
    if($zzje < $plugincfg['zzmin']){
        showmessage(lang('plugin/dev8133_jfwallet', 'zz_alert_02'));
    }
    
    if($zzje>$jftypecount){
        showmessage(lang('plugin/dev8133_jfwallet', 'zz_alert_03'));
    }
    
    $to = DB::fetch_first("select uid from ".DB::table("common_member")." where username='".$touser."'");
    
    if(!$to){
        showmessage(lang('plugin/dev8133_jfwallet', 'zz_alert_04'));
    }
    
    $addjffree = intval($plugincfg['zzfl']*$zzje);
    $addjf  = $zzje-$addjffree;
    
    $orderdata = array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'integral'=>$zzje,
        'touser'=>$touser,
        'integralfree'=>$addjffree,
        'integraltype'=>$jftype,
        'dateline'=>TIMESTAMP,
    );
    DB::insert("dev8133_jfwallet_zz", $orderdata);
   
    updatemembercount($_G['uid'], array("extcredits".$jftype=>-$zzje), 1, 'TFR', $to['uid']);
    updatemembercount($to['uid'], array("extcredits".$jftype=>$addjf), 1, 'RCV', $_G['uid']);
    showmessage(lang('plugin/dev8133_jfwallet', 'common_01'), 'plugin.php?id=dev8133_jfwallet:jfwallet&dmod=zz');

}elseif($subdmod == "zzlog"){
    
    if($_G['uid']){
        $wheres='where 1 AND uid='.$_G['uid'];
        
        $maxc=30;
        
        $pagenumurl='plugin.php?id=dev8133_jfwallet:jfwallet&dmod=zz&subdmod=zzlog';
        
        $pagenum=max(1,intval($_GET['page']));
        
        $start=($pagenum-1)*$maxc;
        
        $datacount = C::t('#dev8133_jfwallet#dev8133_jfwallet_zz')->count_all($wheres);
        
        if($datacount){
            $data = C::t('#dev8133_jfwallet#dev8133_jfwallet_zz')->fetch_all_by_limit($start,$maxc,$wheres);
        }
        
        $pagenav=multi($datacount,$maxc,$pagenum,$pagenumurl);
    }
    include template('dev8133_jfwallet:zz_log');
}else{
    include template('dev8133_jfwallet:zz');
}
//From: Dism_taobao-com
?>