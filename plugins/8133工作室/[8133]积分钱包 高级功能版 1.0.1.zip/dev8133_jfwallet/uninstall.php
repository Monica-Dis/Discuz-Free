<?php
if(!defined('IN_DISCUZ')||!defined('IN_ADMINCP')){    exit('AccessDenied');}$deletetablesql = <<<EOFDROP TABLE IF EXISTS cdb_dev8133_jfwallet_jf;DROP TABLE IF EXISTS cdb_dev8133_jfwallet_zz;EOF;
runquery($deletetablesql);
$finish = TRUE;