<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

loadcache('plugin');

require_once("source/plugin/dev8133_jfwallet/lib/alipay/alipay.config.php");
require_once("source/plugin/dev8133_jfwallet/lib/alipay/alipay_notify.class.php");


//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyNotify();

if($verify_result) {
	$out_trade_no = $_POST['out_trade_no'];
	$trade_no = $_POST['trade_no'];
	$trade_status = $_POST['trade_status'];
    if($_POST['trade_status'] == 'TRADE_FINISHED' || $_POST['trade_status'] == 'TRADE_SUCCESS') {
        $orderdata= C::t('#dev8133_jfwallet#dev8133_jfwallet_jf')->fetch_by_id($out_trade_no);
		$orderarr=array(
		    'trade_no'=>$trade_no,
		    'paystatus'=>2,
		    'paydateline'=>$_G['timestamp'],
		);
		C::t('#dev8133_jfwallet#dev8133_jfwallet_jf')->update($orderdata, $orderarr);
		updatemembercount($orderdata['uid'], array('extcredits'.$orderdata['integraltype']=>$orderdata['integralc']), true, '', 0, '',lang('plugin/dev8133_jfwallet', 'cz_alert_02'),lang('plugin/dev8133_jfwallet', 'cz_alert_02'));	
    }
	echo "success";		
}
else {
    //验证失败
    echo "fail";
}
?>