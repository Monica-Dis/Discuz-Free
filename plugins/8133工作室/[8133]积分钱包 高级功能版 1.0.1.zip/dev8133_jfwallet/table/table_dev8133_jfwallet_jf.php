<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dev8133_jfwallet_jf extends discuz_table
{
	public function __construct() {

		$this->_table = 'dev8133_jfwallet_jf';
		$this->_pk    = 'orderid';
		parent::__construct(); /*dism - taobao - com*/
	}
	
	public function count_all($where='') {
	    return DB::result_first("SELECT count(*) FROM %t %i", array($this->_table,$where));
	}
	
	public function fetch_all_by_limit($startlimit,$ppp,$where='') {
	    return DB::fetch_all("SELECT * FROM %t %i order by dateline desc LIMIT %d,%d", array($this->_table,$where,$startlimit,$ppp));
	}
	
	public function fetch_page_dataall($uid,$start=0,$limit=10)
	{
	    return DB::fetch_all('SELECT * FROM  %t  where uid=%d ORDER BY dateline desc limit '. $start.",".$limit, array($this->_table,$uid));
	}
	
	public function fetch_page_dataallc($uid)
	{
	    return DB::fetch_first('SELECT count(*) as countnum FROM  %t  where uid=%d', array($this->_table,$uid));
	}
	
	
	public function fetch_by_id($orderid) {
	    return DB::fetch_first("SELECT * FROM %t where orderid=%s", array($this->_table,$orderid));
	}
	
	
	public function fetch_allstartaddress() {
	    return DB::fetch_all("SELECT distinct startaddress FROM %t ", array($this->_table));
	}
	
	public function fetch_get_endaddress($sstr) {
	    return DB::fetch_all("SELECT * FROM %t ", array($this->_table));
	}
	
}
//From: Dism_taobao-com
?>