<?php 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$curpage=intval(getgpc('page'));

if($curpage<1){
	$curpage=1;
}
$pageUrl="plugin.php?id=dev8133_extend:extend&modac=myextend";
$pagesize=10;			
$fromuidinfo = C::t("#dev8133_extend#dev8133_extend_log")->fetch_by_frominfopage($_G['uid'],($curpage-1)*$pagesize,$pagesize);
$sumcount = C::t("#dev8133_extend#dev8133_extend_log")->fetch_by_frominfopagec($_G['uid']);
$count = count($fromuidinfo);
for($i=0;$i<$count;$i++){
	$userinfo =  C::t("#dev8133_extend#dev8133_extend_member")->fetch_by_uidgroupid($fromuidinfo[$i]['reguid']);
	$fromuidinfo[$i]['userinfo'] = $userinfo;
}
$pagenav = multi($sumcount['sumcount'], $pagesize, $curpage, $pageUrl);
include template('dev8133_extend:extend_main');
?>