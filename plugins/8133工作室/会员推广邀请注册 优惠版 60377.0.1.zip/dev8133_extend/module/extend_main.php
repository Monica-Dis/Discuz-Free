<?php 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include template('dev8133_extend:extend_main');
?>