<?php

if (!defined('IN_DISCUZ')) {
	exit ('Access Denied');
}
$modarray = array (	
	'myextend',
);

if(!$_G['uid']) {
		showmessage('not_loggedin', NULL, array(), array('login' => 1));
}

$modac = !in_array(dhtmlspecialchars($_GET['modac']), $modarray) ? 'main' : $_GET['modac'];
$xmlcfg = $_G['cache']['plugin']['dev8133_extend'];
$levelcfg = explode("\r\n",$xmlcfg['setconfigs']);
$levelcfginfo = array();
foreach($levelcfg as $gbv){
	$akey = explode("=",$gbv);
	$avalue = explode("||",$akey[1]);
	$levelcfginfo += array($akey[0]=>$avalue);
}
foreach($levelcfginfo as $k=>$v){
	$levelinfo =  C::t("#dev8133_extend#dev8133_extend_log")->fetch_by_uidlevel($_G['uid'],$k);
	$levelinfouid[$k] = $levelinfo['levelcount'];
}
//��ȡע������
$extendurl = $_G['siteurl'].'member.php?mod='.$_G['setting']['regname'];
$extendurl = $extendurl.'&fromuid='.$_G['uid'];
//��ȡ�ܷ��ֽ��
 $awawrdcount = C::t("#dev8133_extend#dev8133_extend_log")->fetch_by_sumawardcount($_G['uid']);

loadcache("usergroups");

require DISCUZ_ROOT . './source/plugin/dev8133_extend/module/extend_' . $modac . '.php';

?>