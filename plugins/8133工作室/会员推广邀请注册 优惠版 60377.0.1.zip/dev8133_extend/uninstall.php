<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {

	exit('Access Denied');

}

$deletetablesql = <<<EOF

DROP TABLE IF EXISTS cdb_dev8133_extend;

DROP TABLE IF EXISTS cdb_dev8133_extend_log;

EOF;

runquery($deletetablesql);

$finish = TRUE;