<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {

	exit('Access Denied');

}



class table_dev8133_extend_member extends discuz_table

{

	public function __construct() {



		$this->_table = 'common_member';

		$this->_pk    = 'uid';

		parent::__construct();

	}

	

	public function fetch_by_uidgroupid($uid){

		return DB::fetch_first("SELECT * FROM  %t where uid=%d", array($this->_table,$uid));

	}



	public function fetch_by_uidgroupidall($uids){

		return DB::fetch_all("SELECT uid,groupid FROM  %t where uid in(".$uids.")", array($this->_table,$uids));

	}

}

//From: Dism_taobao��com

?>