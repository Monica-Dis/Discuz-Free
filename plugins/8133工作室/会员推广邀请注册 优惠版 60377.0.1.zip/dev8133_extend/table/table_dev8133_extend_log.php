<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {

	exit('Access Denied');

}



class table_dev8133_extend_log extends discuz_table

{

	public function __construct() {



		$this->_table = 'dev8133_extend_log';

		$this->_pk    = 'id';



		parent::__construct();

	}

	

	public function fetch_by_award($uid) {

		return DB::fetch_all("SELECT * FROM %t where fromuid = %d and isaward=0",array($this->_table,$uid));

	}

	

	public function fetch_by_baward($uid) {

		return DB::fetch_all("SELECT * FROM %t where reguid = %d and isaward = 0",array($this->_table,$uid));

	}

	

	public function fetch_by_frominfo($fromuid){

		return DB::fetch_all("SELECT * FROM %t where fromuid = %d",array($this->_table,$fromuid));

	}



	public function fetch_by_uidlevel($fromuid,$level){

		return DB::fetch_first("SELECT count(*) as levelcount FROM %t where fromuid = %d and level=%d",array($this->_table,$fromuid,$level));

	}

	

	public function fetch_by_sumawardcount($fromuid){

		return DB::fetch_first("SELECT SUM(awardcount) AS sumawardcount FROM %t where fromuid = %d",array($this->_table,$fromuid));

	}



	

	public function fetch_by_frominfopage($fromuid,$b,$e){

		return DB::fetch_all("SELECT * FROM %t where fromuid = %d limit %d,%d",array($this->_table,$fromuid,$b,$e));

	}

	

	public function fetch_by_frominfopagec($fromuid){

		return DB::fetch_first("SELECT count(*) as sumcount FROM %t where fromuid = %d",array($this->_table,$fromuid));

	}

	

	

	public function fetchappdataall($b,$e){

		

		return DB::fetch_all("SELECT fromuid,SUM(awardcount) AS sumawardcount,COUNT(fromuid) AS tgcount FROM  %t  GROUP BY fromuid limit %d,%d",array($this->_table,$b,$e));

	

	}

		public function fetchappdataallc(){

		

		return DB::fetch_first("SELECT COUNT(fromuid) AS tgcount FROM  %t  GROUP BY fromuid",array($this->_table));

	

	}

	

}

//From: Dism_taobao��com

?>