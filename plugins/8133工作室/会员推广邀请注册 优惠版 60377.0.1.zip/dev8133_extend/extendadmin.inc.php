<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {

	exit('Access Denied');

}

loadcache('plugin');

$xmlcfg = $_G['cache']['plugin']['dev8133_extend'];

$operation= daddslashes($_GET['cp']);

if($operation =="showdetail"){

		if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){

			cpmsg('error');

		}

		$fromuid = intval($_GET['fromuid']);

		

		showtableheader("UID=".$fromuid.lang('plugin/dev8133_extend', 'admin_dqgy01'));

		

		showtablerow("",'',array(

					lang('plugin/dev8133_extend', 'admin_l01'),

					lang('plugin/dev8133_extend', 'admin_l04'),

					lang('plugin/dev8133_extend', 'admin_l05'),

					lang('plugin/dev8133_extend', 'admin_l07'),

		));

		

		$fromuidinfo = C::t('#dev8133_extend#dev8133_extend_log')->fetch_by_frominfo($fromuid);

		foreach($fromuidinfo as $appvalue){

			if($appvalue['isaward']== 1){

				$appvalue['isaward'] = lang('plugin/dev8133_extend', 'admin_201');

			}else{

				$appvalue['isaward'] = lang('plugin/dev8133_extend', 'admin_202');

			}

			showtablerow("",'',array(

				$appvalue['reguid'],

				$appvalue['level'],

				$appvalue['awardcount'].$_G['setting']['extcredits'][$xmlcfg['setintegraltype']]['title'],

				$appvalue['isaward'] ,

			));

		}

		showformfooter();

		showtablefooter();/*Dism-taobao_com*/

		exit;

}



	$curpage=intval(getgpc('page'));

	if($curpage<1){

		$curpage=1;

	}

	

	$pageUrl=ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=extendadmin&identifier=dev8133_extend";



	showtableheader(lang('plugin/dev8133_extend', 'admin_dqgy'));

	

	showtablerow("",'',array(

				lang('plugin/dev8133_extend', 'admin_l01'),

				lang('plugin/dev8133_extend', 'admin_l02'),

				lang('plugin/dev8133_extend', 'admin_210'),

				lang('plugin/dev8133_extend', 'admin_l03'),

	));

	

	$pagesize=15;

	$appdata = C::t('#dev8133_extend#dev8133_extend_log')->fetchappdataall(($curpage-1)*$pagesize,$pagesize);

	$sumcount = C::t('#dev8133_extend#dev8133_extend_log')->fetchappdataallc();

	

	foreach($appdata as $appvalue){

			$str .= "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=extendadmin&identifier=dev8133_extend&cp=showdetail&formhash=".formhash()."&fromuid=".$appvalue['fromuid']."'>".lang('plugin/dev8133_extend', 'adh3')."</a>";

			showtablerow("",'',array(

				$appvalue['fromuid'],

				$appvalue['tgcount'],

				$appvalue['sumawardcount'].$_G['setting']['extcredits'][$xmlcfg['setintegraltype']]['title'],

				$str,

			));

			$str="";

	}

	$pagenav=multi($sumcount['tgcount'], $pagesize, $curpage, $pageUrl);

	echo "<tr><td align=left colspan=4>".$pagenav."</td><tr>";

	showtablefooter();/*Dism-taobao_com*/

?>