<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {

    exit('Access Denied');

}

class plugin_dev8133_extend {

	public $config = array();

	//��common�д����������֣����Ը����������

	protected function get_award() {

		global $_G;	

		//�鿴��Ҫ����������
		$getaward  = C::t("#dev8133_extend#dev8133_extend_log")->fetch_by_award($_G['uid']);
		if(!$getaward){
			return $return;
		}
		foreach ($getaward as  $reguid){
			array_push($reguids, $reguid['reguid']);
			$reguids .=$reguid['reguid'].",";
		}

		$reguids = trim($reguids,",");

		$reguidinfo = C::t("#dev8133_extend#dev8133_extend_member")->fetch_by_uidgroupidall($reguids);

		foreach($reguidinfo as $rd){

			$usergroup[$rd['uid']] = $rd['groupid'];

		}

	

		//exit;


		foreach($getaward as $gwv){

			//$group =  C::t("#dev8133_extend#dev8133_extend_member")->fetch_by_uidgroupid($gwv['reguid']);


			if($usergroup[$gwv['reguid']] == intval($this->config['levelinfo'][$gwv['level']][0])){

				$updatedata = array(

					'isaward' => '1',

					'awarddateline'=>$_G['timestamp'],

					'awardcount'=>intval($this->config['levelinfo'][$gwv['level']][1]),

				);

				C::t("#dev8133_extend#dev8133_extend_log")->update(array('id'=>$gwv['id']),$updatedata);

				updatemembercount($_G['uid'], array("extcredits".$this->config['setintegraltype']=>$this->config['levelinfo'][$gwv['level']][1]),true,'',0,'',lang('plugin/dev8133_extend', 'tgjl'),lang('plugin/dev8133_extend', 'tgjfjf'));	

			}

		}

		


		$bgetaward = C::t("#dev8133_extend#dev8133_extend_log")->fetch_by_baward($_G['uid']);

		foreach($bgetaward as $bgwv){

			if($_G['groupid'] ==  intval($this->config['levelinfo'][$bgwv['level']][0])){

				$updatedata = array(

					'isaward' => '1',

					'awarddateline'=>$_G['timestamp'],

					'awardcount'=>intval($this->config['levelinfo'][$bgwv['level']][1]),

				);

				C::t("#dev8133_extend#dev8133_extend_log")->update(array('id'=>$bgwv['id']),$updatedata);

				updatemembercount($bgwv['fromuid'], array("extcredits".$this->config['setintegraltype']=>$this->config['levelinfo'][$bgwv['level']][1]),true,'',0,'',lang('plugin/dev8133_extend', 'tgjl'),lang('plugin/dev8133_extend', 'tgjfjf'));	

			}

		}

	}

	

	

	function plugin_dev8133_extend() {

		global $_G;

		$this->config = $_G['cache']['plugin']['dev8133_extend'];

		$levelcfg = explode("\r\n",$this->config['setconfigs']);

		$levelcfginfo = array();

		foreach($levelcfg as $gbv){

			$akey = explode("=",$gbv);

			$avalue = explode("||",$akey[1]);

			$levelcfginfo += array($akey[0]=>$avalue);

		

		}

		$this->config['levelinfo'] = $levelcfginfo;

		

	}

	

	/**

	 * ע��ɹ������Ƿ�������ע�Ტ����ش���

	 */
}





class plugin_dev8133_extend_member extends plugin_dev8133_extend {

	/**

	 * ע�����������  

	 */

	public function register_input() {

		global $_G;

		$fromuid = intval($_G['cookie']['promotion']);

		if($fromuid);{

			$html = '<input type="hidden" name="fuid" value="'.$fromuid.'" />';

			return $html;

		}

	}
	
	function register_message(){

		global $_G;
		if($_G['uid']){
			//ע��ɹ������
			$uid = $_G['uid'];
			$fromuid = intval($_GET['fuid']);
			$user = C::t('common_member')->fetch_all_username_by_uid(array($fromuid));
			if($user){
				$regdata = array(
						'reguid'=>$uid,

						'fromuid'=>$fromuid,

						'dateline'=>$_G['timestamp']

				);

				C::t('#dev8133_extend#dev8133_extend')->insert($regdata);

				//1��

				$logdata = array(

					'fromuid'=>$fromuid,

					'reguid'=>$uid,

					'level'=>1,

					'dateline'=>$_G['timestamp']

				);

				C::t('#dev8133_extend#dev8133_extend_log')->insert($logdata);

				//2����ʼѭ��,��������ѭ��

				$levelfromuid = $fromuid;

				for($i=2;$i<=3;$i++){

					$islevel = C::t("#dev8133_extend#dev8133_extend")->fetch_by_fromuid($levelfromuid);

					if($islevel){

						$logdata = array(

								'fromuid'=>$islevel['fromuid'],

								'reguid'=>$uid,

								'level'=>$i,

								'dateline'=>$_G['timestamp']

						);

						C::t('#dev8133_extend#dev8133_extend_log')->insert($logdata);

						$levelfromuid = $islevel['fromuid'];

					}

				}

			}
		}else{
			
		}

	}

	//ֻ�е�¼�ɹ�ʱ �Ž��з��������������������
	public function logging_dev8133_extend_message($p) {

		if($p['param'][0] == 'login_succeed' || $p['param'][0] == 'location_login_succeed') {

			$this->get_award();

		}

	}

}

