<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */

if(!defined('IN_DISCUZ')) {

	exit('Access Denied');

}

$createtablesql = <<<EOF

DROP TABLE IF EXISTS cdb_dev8133_extend;

CREATE TABLE IF NOT EXISTS `cdb_dev8133_extend` (

  `id` int(11) unsigned NOT NULL auto_increment,

  `reguid`  	mediumint(8) unsigned NOT NULL,

  `fromuid`     mediumint(8) unsigned  NOT NULL,

  `dateline`    int(10) DEFAULT NULL,

  PRIMARY KEY  (`id`),

  INDEX `dev8133_extend` (`reguid`,`fromuid`)

) ENGINE=MyISAM;



DROP TABLE IF EXISTS cdb_dev8133_extend_log;

CREATE TABLE cdb_dev8133_extend_log (

  `id` int(10) NOT NULL AUTO_INCREMENT,

  `fromuid` mediumint(8) unsigned NOT NULL,

  `reguid` mediumint(8) unsigned NOT NULL,

  `level` int(10) NOT NULL ,

  `awardcount` int(10) NOT NULL DEFAULT '0' ,

  `isaward` int(10) NOT NULL DEFAULT '0',

  `dateline` int(10) NOT NULL DEFAULT '0',

  `awarddateline` int(10) NOT NULL DEFAULT '0',

  PRIMARY KEY (`id`),

  INDEX `dev8133_extend_log` (`fromuid`,`reguid`)

) ENGINE=MyISAM;



EOF;

runquery($createtablesql);

$finish = TRUE;


@unlink(DISCUZ_ROOT . './source/plugin/dev8133_extend/discuz_plugin_dev8133_extend.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_extend/discuz_plugin_dev8133_extend_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_extend/discuz_plugin_dev8133_extend_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_extend/discuz_plugin_dev8133_extend_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_extend/discuz_plugin_dev8133_extend_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_extend/install.php');


?>