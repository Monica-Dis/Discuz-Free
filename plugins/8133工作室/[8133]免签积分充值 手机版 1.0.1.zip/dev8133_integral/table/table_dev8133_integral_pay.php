<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dev8133_integral_pay extends discuz_table
{
	public function __construct() {

		$this->_table = 'dev8133_integral_pay';
		$this->_pk    = 'id';
		parent::__construct();
	}
	
	public function count_all($where='') {
	    return DB::result_first("SELECT count(*) FROM %t %i", array($this->_table,$where));
	}
	
	public function fetch_all_by_limit($startlimit,$ppp,$where='') {
	    return DB::fetch_all("SELECT * FROM %t %i LIMIT %d,%d", array($this->_table,$where,$startlimit,$ppp));
	}
	
	public function fetch_first_field_data($field,$where='') {
	    return DB::fetch_first("SELECT %i FROM %t %i", array($field,$this->_table,$where));
	}
	
	
	public function fetch_all_byall() {
	    return DB::fetch_all("SELECT * FROM %t order BY paysort desc ", array($this->_table));
	}
	

	
	public function delete_by_id($id) {
	    return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
	public function update_status($id) {
	    return DB::query("update %t set kstatus=2 WHERE id=%d", array($this->_table, $id));
	}
	
	public function fetch_mybuycard($where,$ppp) {
	    return DB::fetch_all("SELECT * FROM %t %i LIMIT 0,%d", array($this->_table,$where,$ppp));
    }
    
    public function fetch_by_deleteall() {
        $data = DB::fetch_all("SELECT payicon,payqrimg FROM %t",array($this->_table));
        return $data;
    }
}
//From: Dism_taobao_com
?>