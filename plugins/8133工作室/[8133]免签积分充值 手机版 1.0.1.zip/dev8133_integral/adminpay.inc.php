<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	
	if($_GET['ac']){
	    
		if($_GET['formhash'] != $_G['formhash']) {
			exit('Access Denied');
		}
		
		if($_GET['ac']=='edit'){
		    
		    $jfid= intval($_GET['jfid']);
		    if($jfid){
		        $ws = " where id=".$jfid;
    		    $editdata = C::t('#dev8133_integral#dev8133_integral_pay')->fetch_first_field_data("*",$ws);
		    }
		    
			if (submitcheck("editsubmit")) {
				
				if(!$_GET['payname']){
				    cpmsg(lang('plugin/dev8133_integral', 'adminpaystr_1'), '', 'error');
				}
				if(!$_FILES['payicon']['name'] && !$_GET['payicon']){
				    cpmsg(lang('plugin/dev8133_integral', 'adminpaystr_2'), '', 'error');
				}
				if(!$_FILES['payqrimg']['name'] && !$_GET['payqrimg']){
				    cpmsg(lang('plugin/dev8133_integral', 'adminpaystr_3'), '', 'error');
				}
				
				if($_FILES['payicon']){
				    $upload = new discuz_upload();
				    $upload->init($_FILES['payicon'], 'common', random(3, 1), random(8));
				    if(!in_array($upload->attach['ext'], array('jpg','png','gif','jpeg')))
				    {
				        cpmsg(lang('plugin/dev8133_integral', 'qd0066'));
				    }
				    if($upload->attach['size']>2097152){
				        cpmsg(lang('plugin/dev8133_integral', 'qd0067'));
				    }
				    $upload->save();
				    $payicon = $_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
				    if($jfid){
				        @unlink(DISCUZ_ROOT . $editdata['payicon']);
				    }
				}else{
				    $payicon = daddslashes($_GET['payicon']);
				}
				
				if($_FILES['payqrimg']){
				    
				    $upload = new discuz_upload();
				    $upload->init($_FILES['payqrimg'], 'common', random(3, 1), random(8));
				    if(!in_array($upload->attach['ext'], array('jpg','png','gif','jpeg')))
				    {
				        @unlink(DISCUZ_ROOT . $payicon);
				        cpmsg(lang('plugin/dev8133_integral', 'qd0066'));
				    }
				    if($upload->attach['size']>2097152){
				        @unlink(DISCUZ_ROOT . $payicon);
				        cpmsg(lang('plugin/dev8133_integral', 'qd0067'));
				    }
				    $upload->save();
				    $payqrimg = $_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
				    
				    if($jfid){
				        @unlink(DISCUZ_ROOT . $editdata['payqrimg']);
				    }
				}else{
				    $payqrimg = daddslashes($_GET['payqrimg']);
				}
				
				$arr=array(
				    'payicon'=> $payicon,
				    'payname'=> daddslashes($_GET['payname']),
				    'paysort'=> intval($_GET['paysort']),
				    'payqrimg'=> $payqrimg,
				    'dateline'=>TIMESTAMP,
				);
				if($editdata['id']){
				   
				    C::t('#dev8133_integral#dev8133_integral_pay')->update($editdata['id'],$arr);
				}else{
					C::t('#dev8133_integral#dev8133_integral_pay')->insert($arr);
				}
				cpmsg(lang('plugin/dev8133_integral', 'common_06'), 'action=plugins&operation=config&identifier=dev8133_integral&pmod=adminpay&formhash='.FORMHASH, 'succeed');
			}
			showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=adminpay&ac=edit", 'enctype');
			showtableheader(lang('plugin/dev8133_integral', 'adminpaystr_4'));
			showsetting(lang('plugin/dev8133_integral', 'adminpay01'),'payname',$editdata['payname'],'text');
			showsetting(lang('plugin/dev8133_integral', 'adminpay02'),'payicon',$editdata['payicon'],'filetext','','',lang('plugin/dev8133_integral', 'adminpaystr_5'));
			showsetting(lang('plugin/dev8133_integral', 'adminpay03'),'payqrimg',$editdata['payqrimg'],'filetext','','',lang('plugin/dev8133_integral', 'adminpaystr_6'));
			showsetting(lang('plugin/dev8133_integral', 'adminjf05'),'paysort',$editdata['paysort'],'text',"","",lang('plugin/dev8133_integral', 'adminjf11'));
			
			echo '<input name="jfid" type="hidden" value="'.$editdata['id'].'" />';
			showsubmit('editsubmit', 'submit', '');
			showtablefooter();/*dis'.'m.tao'.'bao.com*/
   			showformfooter();/*Dism��taobao��com*/
			exit();
		}elseif($_GET['ac']=='del'){
		    $jfid= intval($_GET['jfid']);
		    if($jfid){
		        $ws = " where id=".$jfid;
		        $editdata = C::t('#dev8133_integral#dev8133_integral_pay')->fetch_first_field_data("*",$ws);
		    }
		    
		    @unlink(DISCUZ_ROOT . $editdata['payicon']);
		    @unlink(DISCUZ_ROOT . $editdata['payqrimg']);
		    
		    C::t('#dev8133_integral#dev8133_integral_pay')->delete_by_id($jfid);
		    
		}
		cpmsg(lang('plugin/dev8133_integral', 'common_06'), 'action=plugins&operation=config&identifier=dev8133_integral&pmod=adminpay', 'succeed');
	}
	
	
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=adminpay");
    showtableheader(lang('plugin/dev8133_integral', 'lang466').'&nbsp;&nbsp;&nbsp;<a href='.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dev8133_integral&pmod=adminpay&ac=edit&formhash='.FORMHASH.' class="addtr">'.lang('plugin/dev8133_integral', 'common_011').'</a>');
    showsubtitle(array(
        "ID",
        lang('plugin/dev8133_integral', 'adminpay01'),
        lang('plugin/dev8133_integral', 'adminpay02'),
        lang('plugin/dev8133_integral', 'adminpay03'),
        lang('plugin/dev8133_integral', 'adminjf05'),
        lang('plugin/dev8133_integral', 'common_03'),
    ));
    
    $ppp = 25;
    $where =  " order by paysort desc";
    $tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=dev8133_integral&pmod=adminpay';
    $page = max (1,intval($_GET['page']));
    $startlimit = ($page - 1) * $ppp;
    $allcount = C::t('#dev8133_integral#dev8133_integral_pay')->count_all($where);
    if ($allcount) {
        $query = C::t ( '#dev8133_integral#dev8133_integral_pay' )->fetch_all_by_limit ( $startlimit, $ppp, $where);
    	foreach($query as $k=>$v){
    		$table = array();
    		$table[0] = $v['id'];
            $table[1] = $v['payname'];
            $table[2] =  "<img width='32' height='32' src='".$v['payicon']."'>";
            $table[3] = "<img width='100' height='100' src='".$v['payqrimg']."'>";
    		$table[5] = $v['paysort'];
    		$table[6] = '<a href='.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dev8133_integral&pmod=adminpay&ac=edit&jfid='.$v['id'].'&formhash='.FORMHASH.'>'.lang('plugin/dev8133_integral', 'common_02').'</a>&nbsp;&nbsp;&nbsp;/&nbsp;&nbsp;&nbsp;'.$table[6] = '<a href='.ADMINSCRIPT.'?action=plugins&operation=config&identifier=dev8133_integral&pmod=adminpay&ac=del&jfid='.$v['id'].'&formhash='.FORMHASH.'>'.lang('plugin/dev8133_integral', 'common_07').'</a>';;
            showtablerow('',array(), $table);
    	}
    }
    $multipage = '';
    $multipage = multi ( $allcount, $ppp, $page, $_G ['siteurl'] . $tmpurl );
    if ($multipage)
        echo '<tr class="hover"><td colspan="9">' . $multipage . '</td></tr>';
    showtablefooter();/*dis'.'m.tao'.'bao.com*/
    showformfooter();/*Dism��taobao��com*/
