<?php 
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($submodac == "submityes"){
    
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('Access Denied');
    }
    
    if(!$uid) {
        showmessage('not_loggedin', NULL, array(), array('login' => 1));
    }
    
    $jfid = daddslashes($_GET['jfid']);
    $payid = intval($_GET['payid']);
    
    $ws1 = " where id=".$payid;
    $pdata = C::t('#dev8133_integral#dev8133_integral_pay')->fetch_first_field_data("*",$ws1);
    
    if(!$pdata){
        showmessage('data error');
    }
    
    if($jfid != "zdy"){
        $jfid = intval($jfid);
        if($jfid && $payid){
            $ws = " where id=".$jfid;
            $jdata = C::t('#dev8133_integral#dev8133_integral')->fetch_first_field_data("*",$ws);
            
      }
        if(!$jdata){
            showmessage('data error');
        }
        
        $intetype =  $jdata['intetype'];
        $intcount =  $jdata['intcount'];
        $price =  $jdata['price'];
        
    }else{
        $zdynums = intval($_GET['zdynums']);
        if($zdynums< $config['minje']){
            showmessage(lang('plugin/dev8133_integral', 'adminpaystr_8').$config['minje']);
        }
        $sumje = $zdynums*$config['zdybl'];
        $intetype =  $config['zdyjf'];
        $intcount =  $zdynums;
        $price = $sumje;
    }
    
    
    
    $payno = daddslashes($_GET['payno']);
    $paycontact = daddslashes($_GET['paycontact']);
    
    $orderdata = array(
        'uid'=>    $uid,
        'username'=> $username,
        'intetype'  =>  $intetype,
        'intcount'  =>   $intcount,
        'price'  =>   $price,
        'zsintetype'  =>   $jdata['zsintetype'],
        'zsintcount'  =>   $jdata['zsintcount'],
        'payname'=>$pdata['payname'],
        'ostatus'=>1,
        'payno'=>$payno,
        'paycontact'=>$paycontact,
        'dateline'=> TIMESTAMP,
    );
    DB::insert('dev8133_integral_order', $orderdata);
    //������Ϣ���û�
    $msg = lang('plugin/dev8133_integral', 'mainstr3').$jdata['intcount'].$_G['setting']['extcredits'][$jdata['intetype']]['title'].lang('plugin/dev8133_integral', 'mainstr4');
    notification_add($uid, 'system', $msg);
    
    $msg = $username.lang('plugin/dev8133_integral', 'mainstr5');
    notification_add(1, 'system', $msg);
    
    //���ʼ�������Ա   
    if($config['email']){
        require_once libfile('function/mail');
        $msubject =lang('plugin/dev8133_integral', 'mainstr1');
        $mmessage=$username.lang('plugin/dev8133_integral', 'mainstr2');
        sendmail($config['email'],$msubject,$mmessage);
    }
    
    showmessage(lang('plugin/dev8133_integral', 'mainstr6'),"plugin.php?id=dev8133_integral",array(),array('alert'=>'right'));
    
}else{
    
    //��ȡ��ֵ����
    $czjfdata = C::t('#dev8133_integral#dev8133_integral')->fetch_all_byall();
    $deaultjf = $czjfdata[0];
    $paydata = C::t('#dev8133_integral#dev8133_integral_pay')->fetch_all_byall();
    $deaultpay = $paydata[0];
    
    $myext = intval(getuserprofile('extcredits'.$deaultjf['intetype']));
    include template('dev8133_integral:main');
}
//From: Dism_taobao_com
?>