<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (! defined ( 'IN_DISCUZ' )) {
	exit ( 'Access Denied' );
}


	class plugin_dev8133_repeatthread{
			
				function common(){
					global $_G;
						
					loadcache('plugin');
					
					$plugincfg = $_G['cache']['plugin']['dev8133_repeatthread'];
					
					$setforum = (array) unserialize($plugincfg['setforum']);
					
					$notestr = $plugincfg['setnotestr'];
					
					
					if((in_array($_G['fid'],$setforum)) && CURSCRIPT == 'forum' && CURMODULE == 'post' && $_GET['subject'] && $_GET['action'] == 'newthread'){
						
							
						
							$subject = trim(daddslashes($_GET['subject']));
							
							$subject  = mb_substr($subject,0,$plugincfg['setthreadlength'],CHARSET); 
							
							if(repeatthreadtitle($subject)){
							 		showmessage($notestr, NULL);
							}
					}
				}
		}

		class mobileplugin_dev8133_repeatthread{
			
				function common(){
					
					global $_G;
						
					loadcache('plugin');
					
					$plugincfg = $_G['cache']['plugin']['dev8133_repeatthread'];
					
					$setforum = (array) unserialize($plugincfg['setforum']);
					
					$notestr = $plugincfg['setnotestr'];
					
					if((in_array($_G['fid'],$setforum)) && CURSCRIPT == 'forum' && CURMODULE == 'post' && $_GET['subject'] && $_GET['action'] == 'newthread'){
						
							$subject = trim(daddslashes($_GET['subject']));
							
							$subject  = mb_substr($subject,0,$plugincfg['setthreadlength'],CHARSET); 
							
							if(repeatthreadtitle($subject)){
							 		showmessage($notestr, NULL);
							}
					}
				}
		}

		function repeatthreadtitle($subject){
			
				//like �����ַ�
				$subject = addcslashes($subject, '%_');
				
				$table = DB::table('forum_thread');
				$sql = "SELECT `tid` FROM  `$table` where subject like '%$subject%'";
				$tid = DB::fetch_first($sql);
				if($tid){
					return true;
				}else{
					return false;
				}
		}
//From: Dism_taobao_com
?>