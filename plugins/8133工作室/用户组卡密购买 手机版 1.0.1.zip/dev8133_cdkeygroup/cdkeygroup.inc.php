<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
	if(!defined('IN_DISCUZ')) {

		exit('Access Denied');

	}

	

	

	$plugincfg = $_G['cache']['plugin']['dev8133_cdkeygroup'];

	



	$rulecfg = getRule(explode("\r\n",$plugincfg['setbuyrule']));

	

	$operation = daddslashes($_GET['operation']);

	

	$extcrtitle = $_G['setting']['extcredits'][$plugincfg['setgivejf']]['title'];

	$userjf = getuserprofile("extcredits".$plugincfg['setgivejf']);

	

	$orderinfo = C::t('#dev8133_cdkeygroup#dev8133_cdkeygroup_order')->fetch_data(0,10);

	

	for($i=0;$i<count($orderinfo);$i++){

			$orderinfo[$i]['dateline']  =  dgmdate($orderinfo[$i]['dateline'],'u');

	}

	

	

	if($operation == "openpage"){

		

		if(!$_G['uid']) {

			showmessage('not_loggedin', NULL, array(), array('login' => 1));

		}

		

		$buyid = intval($_GET['buyid']);

		include template('dev8133_cdkeygroup:cdkeygroupbuypage');

	}

	

	if($operation == "submitbuy"){

		

		if(!$_G['uid']) {

			showmessage('not_loggedin', NULL, array(), array('login' => 1));

		}

		

		if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){

			system_error('request_tainting');

		}

		

		$protectuid = explode(",",$plugincfg['setprotectuid']);

		

		if(in_array($_G['uid'],$protectuid)){

			showmessage(lang('plugin/dev8133_cdkeygroup', 'cdkey_str01'),"plugin.php?id=dev8133_cdkeygroup:cdkeygroup",array(),array('alert'=>'error'));	

		}

		

		$buyid = intval($_GET['buyid']);

		

		$cdkey = daddslashes(trim($_GET['cdkey']));



		if(!isset($rulecfg[$buyid])){

			showmessage(lang('plugin/dev8133_cdkeygroup', 'cdkey_str02'),"plugin.php?id=dev8133_cdkeygroup:cdkeygroup",array(),array('alert'=>'error'));	

		}

		

		$buyinfo  = $rulecfg[$buyid];

		

		$cdkeyexist = C::t('#dev8133_cdkeygroup#dev8133_cdkeygroup_cdkey')->fetch_by_cdkeygroup($cdkey,$buyinfo[1]);

		

		

		if(!$cdkeyexist){

			showmessage(lang('plugin/dev8133_cdkeygroup', 'cdkey_str03'),"plugin.php?id=dev8133_cdkeygroup:cdkeygroup",array(),array('alert'=>'error'));	

		}

		$cdkeyorder = array(

				'id' => dgmdate(TIMESTAMP, 'YmdHis').random(15),

				'uid' =>$_G['uid'],

				'username'=>$_G['username'],

				'cdkey'=>$cdkey,

				'integralcount'=>$buyinfo[4],

				'price'=>$buyinfo[2],

				'day'=>$buyinfo[3],

				'groupid'=>$buyinfo[1],

				'ip'=>$_G['clientip'],

				'groupname'=>$buyinfo[0],

				'dateline'=>time(),

		);

		$updatejddata = array(

			'status'=>2,

			'updateline'=>time(),

		);

		C::t('#dev8133_cdkeygroup#dev8133_cdkeygroup_cdkey')->update(array('cdkey'=>$cdkey),$updatejddata);

		C::t('#dev8133_cdkeygroup#dev8133_cdkeygroup_order')->insert($cdkeyorder);

		

		$member=C::t('common_member')->fetch($_G['uid'], false, 1);

		if(count($member)==0){

				$inarchive = '_inarchive';

		}else{

				$isinarchive = '';

		}

		

		$myname = $_G['username'];

		$cusername =  C::t('common_member')->fetch_all_by_username($myname);

		$validity = $cdkeyorder['day'];
		
		//�ӻ���
		updatemembercount($_G['uid'], array("extcredits".$plugincfg['setgivejf'] =>$cdkeyorder["integralcount"]));

		//���û���
		if($cdkeyorder['day'] == 0){
					C::t('common_member'.$isinarchive)->update($_G['uid'], array('groupid'=>$cdkeyorder['groupid'],'groupexpiry'=>''));
					C::t('common_member_field_forum'.$isinarchive)->update($_G['uid'],array('groupterms' => ""));
		}elseif (is_numeric($cdkeyorder['day']) && $cdkeyorder['day']>0) {
			
				$groupexpiryTime = strtotime(date('Y-m-d H:i:s',strtotime("+$validity day")));;
				if($buyinfo[1] == $cusername[$myname]['groupid']){
					$groupexpiryTime = $cusername[$myname]['groupexpiry'] + ($validity*24*60*60);
				}

				C::t('common_member'.$isinarchive)->update($_G['uid'], array('groupid'=>$cdkeyorder['groupid'],'groupexpiry'=>$groupexpiryTime));

				$groupterms['main'] = array('time' => $groupexpiryTime);

				$groupterms['ext'][$cdkeyorder['groupid']] = $groupexpiryTime;

				C::t('common_member_field_forum'.$isinarchive)->update($_G['uid'],array('groupterms' => serialize($groupterms)));

		}

		


		showmessage(lang('plugin/dev8133_cdkeygroup', 'cdkey_str04'),"plugin.php?id=dev8133_cdkeygroup:cdkeygroup",array(),array('alert'=>'right'));	

			

		

	}



	include template('dev8133_cdkeygroup:cdkeygroup');

	

	

	function getRule($rulecfg){

		

		$returnvalue = array();

		foreach($rulecfg as $value){

			$tmpArray = explode("|",$value);

			array_push($returnvalue,$tmpArray);

		}

		return $returnvalue;

	}
//From: Dism_taobao��com
?>