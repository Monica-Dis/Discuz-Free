<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit ('Access Denied');
}
$optioner = daddslashes($_GET['optioner']);
if ($optioner == 'delete') {	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		system_error('request_tainting');
	}
	$orederid = daddslashes($_GET['orederid']);
	C::t('#dev8133_cdkeygroup#dev8133_cdkeygroup_cdkey')->detele_by_cdkey($orederid);
	cpmsg(lang('plugin/dev8133_cdkeygroup', 'admin_str01'), "action=plugins&operation=config&do=" . $pluginid . "&identifier=dev8133_cdkeygroup&pmod=admin_cdkeylist", 'right');}
if (!submitcheck('searchsubmit')) {
	showtableheader(lang('plugin/dev8133_cdkeygroup', 'admin_str02'));
	showformheader('plugins&operation=config&do=' . $pluginid . '&pmod=admin_cdkeylist&identifier=dev8133_cdkeygroup');
	showtablerow('', '', array (
		lang('plugin/dev8133_cdkeygroup', 'admin_str03'),
		"<input size=\"40\" name=\"cdkeystr\" type=\"text\" />",
	));
	showsubmit('searchsubmit');
	showformfooter(); /*DISM-TAOBAO-COM*/
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
}
if (submitcheck('searchsubmit', 1)) {
	
	showtableheader(lang('plugin/dev8133_cdkeygroup', 'admin_str02'));
	showformheader('plugins&operation=config&do=' . $pluginid . '&pmod=admin_cdkeylist&identifier=dev8133_cdkeygroup');
	showtablerow('', '', array (
		lang('plugin/dev8133_cdkeygroup', 'admin_str03'),
		"<input size=\"40\" name=\"cdkeystr\" type=\"text\" />",
	));
	showsubmit('searchsubmit');
	showformfooter(); /*DISM-TAOBAO-COM*/
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/

	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		system_error('request_tainting');
	}	
	
	$cdkeystr = daddslashes(trim($_GET['cdkeystr']));
	
	$export = "<a href=plugin.php?id=dev8133_cdkeygroup:admin_exportfile>".lang('plugin/dev8133_cdkeygroup', 'admin_str05')."</a>";
	showtableheader(lang('plugin/dev8133_cdkeygroup', 'admin_str04').$export);
	$cdkeyata = C::t('#dev8133_cdkeygroup#dev8133_cdkeygroup_cdkey')->fetch_by_cdkey($cdkeystr);
	
	if($cdkeyata){
		
		showtablerow("", '', array (
			lang('plugin/dev8133_cdkeygroup', 'admin_str09'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str10'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str11'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str12'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str13'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str34'),
		));
	
		foreach ($cdkeyata as $value) {
		
			if ($value['status'] == 1) {
				$value['status'] = lang('plugin/dev8133_cdkeygroup', 'admin_str06');
			} else {
				$value['status'] = lang('plugin/dev8133_cdkeygroup', 'admin_str07');
			}
			$value['dateline'] = dgmdate($value['dateline'],'Y/m/d H:i');
			$value['updateline'] = dgmdate($value['updateline'],'Y/m/d H:i');
			showtablerow("", '', array (
				$value['cdkey'],
				$value['groupid'],
				$value['status'],
				$value['dateline'],
				$value['updateline'],
				"<a href=".ADMINSCRIPT."?action=plugins&operation=config&do=". $pluginid . "&identifier=dev8133_cdkeygroup&pmod=admin_cdkeylist&optioner=delete&formhash=".formhash()."&orederid=$value[cdkey]>".lang('plugin/dev8133_cdkeygroup', 'admin_str08')."</a>"
			));
		}
		exit;
	}
}

	$cur_page = intval(getgpc('page'));
	if ($cur_page < 1) {
		$cur_page = 1;
	}
	$curUrl = ADMINSCRIPT."?action=plugins&operation=config&do=" . $pluginid . "&identifier=dev8133_cdkeygroup&pmod=admin_cdkeylist";
	
	
	$export = "<a href=plugin.php?id=dev8133_cdkeygroup:admin_exportfile>".lang('plugin/dev8133_cdkeygroup', 'admin_str05')."</a>";
	showtableheader(lang('plugin/dev8133_cdkeygroup', 'admin_str04').$export);
	showtablerow("", '', array (
		lang('plugin/dev8133_cdkeygroup', 'admin_str09'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str10'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str11'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str12'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str13'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str34'),
	));
	$showNum = 35;
	
	$cdkeyata = C::t('#dev8133_cdkeygroup#dev8133_cdkeygroup_cdkey')->fetch_data(($cur_page -1) * $showNum, $showNum);
	
	$count = C::t('#dev8133_cdkeygroup#dev8133_cdkeygroup_cdkey')->count();
	
	foreach ($cdkeyata as $value) {
	
		if ($value['status'] == 1) {
				$value['status'] = lang('plugin/dev8133_cdkeygroup', 'admin_str06');
			} else {
				$value['status'] = lang('plugin/dev8133_cdkeygroup', 'admin_str07');
			}
		$value['dateline'] = dgmdate($value['dateline'],'Y/m/d H:i');
		$value['updateline'] = dgmdate($value['updateline'],'Y/m/d H:i');
		showtablerow("", '', array (
			$value['cdkey'],
			$value['groupid'],
			$value['status'],
			$value['dateline'],
			$value['updateline'],
			"<a href=".ADMINSCRIPT."?action=plugins&operation=config&do=". $pluginid . "&identifier=dev8133_cdkeygroup&pmod=admin_cdkeylist&optioner=delete&formhash=".formhash()."&orederid=$value[cdkey]>".lang('plugin/dev8133_cdkeygroup', 'admin_str08')."</a>"					
		));
	}
	$pagenav = multi($count, $showNum, $cur_page, $curUrl);
	echo $pagenav;
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
?>