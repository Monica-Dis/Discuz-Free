<?php

	if (!defined('IN_DISCUZ')) {
		exit ('Access Denied');
	}
	
	$plugincfg = $_G['cache']['plugin']['dev8133_cdkeygroup'];
	$protectuid = explode(",",$plugincfg['setprotectuid']);
	
	//ͨ����̨���õ���UID	
	if(!in_array($_G['uid'],$protectuid)){
		exit ('Access Denied');
	}
	$filename = "cdkey.csv";
	header("Content-type:text/csv");
	header("Content-Disposition:attachment;filename=cdkey.csv");
	header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
	header('Expires:0');
	header('Pragma:public');
	echo lang('plugin/dev8133_cdkeygroup', 'admin_str23');  
	$cdkeydata = C::t('#dev8133_cdkeygroup#dev8133_cdkeygroup_cdkey')->fetch_all($_GET['cond']);
    foreach($cdkeydata as $value){
    	 echo $value['cdkey']. ",".$value['groupid'].",".$value['status'].",".dgmdate($value['dateline'],'Y/m/d H:i').",".dgmdate($value['dateline'],'Y/m/d H:i')."\n"; 
    }
	exit ();


?>