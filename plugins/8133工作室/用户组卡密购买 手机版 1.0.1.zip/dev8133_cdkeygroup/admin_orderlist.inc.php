<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit ('Access Denied');
}


if (daddslashes($_GET['optioner']) == 'delete') {
	
		if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		system_error('request_tainting');
	}
	$orederid = daddslashes($_GET['orederid']);
	C :: t('#dev8133_cdkeygroup#dev8133_cdkeygroup_order')->detele_by_id($orederid);
	cpmsg(lang('plugin/dev8133_cdkeygroup', 'admin_str01'), "action=plugins&operation=config&do=" . $pluginid . "&identifier=dev8133_cdkeygroup&pmod=admin_orderlist", 'right');
}

if (!submitcheck('searchsubmit')) {
	showtableheader(lang('plugin/dev8133_cdkeygroup', 'admin_str02'));
	showformheader('plugins&operation=config&do=' . $pluginid . '&pmod=admin_orderlist&identifier=dev8133_cdkeygroup');
	showtablerow('', '', array (
		lang('plugin/dev8133_cdkeygroup', 'admin_str24'),
		"<input size=\"40\" name=\"orderid\" type=\"text\" />",
		
	));
	showsubmit('searchsubmit');
	showformfooter(); /*DISM-TAOBAO-COM*/
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
}
if (submitcheck('searchsubmit', 1)) {

	showtableheader(lang('plugin/dev8133_cdkeygroup', 'admin_str02'));
	showformheader('plugins&operation=config&do=' . $pluginid . '&pmod=admin_orderlist&identifier=dev8133_cdkeygroup');
	showtablerow('', '', array (
			lang('plugin/dev8133_cdkeygroup', 'admin_str24'),
		"<input size=\"40\" name=\"orderid\" type=\"text\" />",
		
	));
	showsubmit('searchsubmit');
	showformfooter(); /*DISM-TAOBAO-COM*/
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/

	if (empty ($_GET['formhash']) || $_GET['formhash'] != formhash()) {
		system_error('request_tainting');
	}

	$orderid = daddslashes(trim($_GET['orderid']));

	showtableheader(lang('plugin/dev8133_cdkeygroup', 'admin_str25'));

	$cdkeyata = C :: t('#dev8133_cdkeygroup#dev8133_cdkeygroup_order')->fetch_orderid($orderid);

	if ($cdkeyata) {

		showtablerow("", '', array (
			lang('plugin/dev8133_cdkeygroup', 'admin_str26'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str27'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str28'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str29'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str30'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str31'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str32'),
			
		));

		foreach ($cdkeyata as $value) {

			
			$value['dateline'] = dgmdate($value['dateline'], 'Y/m/d H:i');
			if (!$value['day']) {
				$value['day'] = lang('plugin/dev8133_cdkeygroup', 'admin_str33');
			}
			showtablerow("", '', array (
				$value['id'],
				$value['username'],
				$value['cdkey'],
				$value['price'],
				$value['day'],
				$value['dateline'],
				"<a href=".ADMINSCRIPT."?action=plugins&operation=config&do=". $pluginid . "&identifier=dev8133_cdkeygroup&pmod=admin_orderlist&optioner=delete&orederid=$value[id]>".lang('plugin/dev8133_cdkeygroup', 'admin_str08')."</a>"

			));
		}
		exit;
	}
}

$cur_page = intval(getgpc('page'));
if ($cur_page < 1) {
	$cur_page = 1;
}
$curUrl = ADMINSCRIPT . "?action=plugins&operation=config&do=" . $pluginid . "&identifier=dev8133_cdkeygroup&pmod=admin_orderlist";
showtableheader(lang('plugin/dev8133_cdkeygroup', 'admin_str25'));
showtablerow("", '', array (
	lang('plugin/dev8133_cdkeygroup', 'admin_str26'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str27'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str28'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str29'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str30'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str31'),
			lang('plugin/dev8133_cdkeygroup', 'admin_str32'),
	
));
$showNum = 35;

$cdkeyata = C :: t('#dev8133_cdkeygroup#dev8133_cdkeygroup_order')->fetch_data(($cur_page -1) * $showNum, $showNum);

$count = C :: t('#dev8133_cdkeygroup#dev8133_cdkeygroup_order')->count();

foreach ($cdkeyata as $value) {

	
	$value['dateline'] = dgmdate($value['dateline'], 'Y/m/d H:i');
	if (!$value['day']) {
		$value['day'] = lang('plugin/dev8133_cdkeygroup', 'admin_str33');
	}
	showtablerow("", '', array (
		$value['id'],
		$value['username'],
		$value['cdkey'],
		$value['price'],
		$value['day'],
		$value['dateline'],
		"<a href=".ADMINSCRIPT."?action=plugins&operation=config&do=". $pluginid . "&identifier=dev8133_cdkeygroup&pmod=admin_orderlist&optioner=delete&formhash=".formhash()."&orederid=$value[id]>".lang('plugin/dev8133_cdkeygroup', 'admin_str08')."</a>"));
}
$pagenav = multi($count, $showNum, $cur_page, $curUrl);
echo $pagenav;
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
?>