<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$uninstallsql = <<<EOF
DROP TABLE IF EXISTS cdb_dev8133_cdkeygroup_cdkey;
DROP TABLE IF EXISTS cdb_dev8133_cdkeygroup_order;
EOF;
runquery($uninstallsql);
$finish = TRUE;