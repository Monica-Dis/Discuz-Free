<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {

	exit('Access Denied');

}





if(!submitcheck('cdkeycreate')) {

	

	showtips(lang('plugin/dev8133_cdkeygroup', 'admin_str14'));

	

	showtableheader(lang('plugin/dev8133_cdkeygroup', 'admin_str15'));

	

	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=admin_createcdkey&identifier=dev8133_cdkeygroup', 'testhd');  

	

	showsetting(lang('plugin/dev8133_cdkeygroup', 'admin_str16'),'pre_str','','text',"","",lang('plugin/dev8133_cdkeygroup', 'admin_str17'));  

	

	showsetting(lang('plugin/dev8133_cdkeygroup', 'admin_str18'),'cdkeycount','','text');  

	

	showsetting(lang('plugin/dev8133_cdkeygroup', 'admin_str19'),'groupid','','text',"","",lang('plugin/dev8133_cdkeygroup', 'admin_str20'));  

	

	showsubmit('cdkeycreate');

	showformfooter(); /*DISM-TAOBAO-COM*/

	showtablefooter(); /*dis'.'m.tao'.'bao.com*/

}



if(submitcheck('cdkeycreate', 1)) {

	

	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){

		system_error('request_tainting');

	}

	$cdkeycount  = intval($_GET['cdkeycount']);

	$pre_str = daddslashes($_GET['pre_str']);

	if(strlen($pre_str)>6){

		cpmsg(lang('plugin/dev8133_cdkeygroup', 'admin_str21'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=admin_createcdkey&identifier=dev8133_cdkeygroup', 'error');

	}

	$groupid =  intval($_GET['groupid']);

	

	for($i=0;$i<$cdkeycount;$i++){

		$cdkeydata = array(

			'cdkey'=>strtoupper(($pre_str.cdkeycreate(20))),

			'groupid'=>$groupid,

			'status'=>1,

			'dateline'=>time(),

			'updateline'=>time(),

		);

		C::t('#dev8133_cdkeygroup#dev8133_cdkeygroup_cdkey')->insert($cdkeydata);

	}

	cpmsg(lang('plugin/dev8133_cdkeygroup', 'admin_str22'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=admin_createcdkey&identifier=dev8133_cdkeygroup', 'succeed');

}



function cdkeycreate($length)

{

		$chars='0123456789abcdefghigklmnopqrstuvwxwz'; 

		$string='';

		for(;$length>=1;$length--){

				$position=rand()%strlen($chars);

				$string.=substr($chars,$position,1);

		}

		return $string;

}
//From: Dism_taobao��com
?>