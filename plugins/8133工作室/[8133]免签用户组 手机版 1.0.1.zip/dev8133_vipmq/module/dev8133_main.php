<?php 
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($submodac == "submityes"){
    
    
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('Access Denied');
    }
    
    if(!$uid) {
        showmessage('not_loggedin', NULL, array(), array('login' => 1));
    }
    
    if($_G['groupid'] == 1) {
        showmessage(lang('plugin/dev8133_vipmq', 'mainstr7'));
    }
     
    
    $jfid = intval($_GET['jfid']);
    $payid = intval($_GET['payid']);
    
    if($jfid && $payid){
        
        $ws = " where id=".$jfid;
        $jdata = C::t('#dev8133_vipmq#dev8133_vipmq')->fetch_first_field_data("*",$ws);
        
        $ws1 = " where id=".$payid;
        $pdata = C::t('#dev8133_vipmq#dev8133_vipmq_pay')->fetch_first_field_data("*",$ws1);
    }
    
    if(!$jdata && !$pdata){
        showmessage('data error');
    }
    
    $payno = daddslashes($_GET['payno']);
    $paycontact = daddslashes($_GET['paycontact']);
    
    $orderdata = array(
        'uid'=>    $uid,
        'username'=> $username,
        'groupid'  =>   $jdata['groupid'],
        'gcount'  =>   $jdata['gcount'],
        'zsintetype'  =>   $jdata['zsintetype'],
        'zsintcount'  =>   $jdata['zsintcount'],
        'price'  =>   $jdata['price'],
        'payname'=>$pdata['payname'],
        'ostatus'=>1,
        'payno'=>$payno,
        'paycontact'=>$paycontact,
        'dateline'=> TIMESTAMP,
    );
    C::t('#dev8133_vipmq#dev8133_vipmq_order')->insert($orderdata);
    //������Ϣ���û�
    $msg = lang('plugin/dev8133_vipmq', 'mainstr3').$_G['cache']['usergroups'][$jdata['groupid']]['grouptitle'].lang('plugin/dev8133_vipmq', 'mainstr4');
    notification_add($uid, 'system', $msg);
    
    $msg = $username.lang('plugin/dev8133_vipmq', 'mainstr5');
    notification_add(1, 'system', $msg);
    
    //���ʼ�������Ա   
    if($config['email']){
        require_once libfile('function/mail');
        $msubject =lang('plugin/dev8133_vipmq', 'mainstr1');
        $mmessage=$username.lang('plugin/dev8133_vipmq', 'mainstr2');
        sendmail($config['email'],$msubject,$mmessage);
    }
    
    showmessage(lang('plugin/dev8133_vipmq', 'mainstr6'),"plugin.php?id=dev8133_vipmq",array(),array('alert'=>'right'));
    
}else{
    loadcache('usergroups');
    //��ȡ��ֵ����
    $czjfdata = C::t('#dev8133_vipmq#dev8133_vipmq')->fetch_all_byall();
    $deaultjf = $czjfdata[0];
    $paydata = C::t('#dev8133_vipmq#dev8133_vipmq_pay')->fetch_all_byall();
    $deaultpay = $paydata[0];
    
    $myext = intval(getuserprofile('extcredits'.$deaultjf['intetype']));
    include template('dev8133_vipmq:main');
}
//From: Dism_taobao_com
?>