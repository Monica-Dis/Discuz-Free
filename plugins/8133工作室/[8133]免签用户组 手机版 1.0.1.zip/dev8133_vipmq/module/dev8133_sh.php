<?php 
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$admingroup = dunserialize($config['admingroup']);
if(!in_array($_G['groupid'],$admingroup)){
    showmessage(lang('plugin/dev8133_vipmq', 'qd001'));
}


if($submodac == "shsubmit"){
    
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('error');
    }
    
    $aid = intval($_GET['aid']);
    $wheres = " where id=".$aid;
    $query = C::t('#dev8133_vipmq#dev8133_vipmq_order')->fetch_first_field_data('*', $wheres);
    if(!$query){
        showmessage("data error");
    }
    
    if($query['ostatus'] == 2){
        showmessage(lang('plugin/dev8133_vipmq', 'mainstr_14'));
    }
    
    $updata = array(
        'ostatus'=>2,
        'shdateline'=>TIMESTAMP,
    );
    
    C::t('#dev8133_vipmq#dev8133_vipmq_order')->update($aid,$updata);
    
    if($query['gcount']){
        $gcount = $query['gcount'];
    }else{
        $gcount = 0;
    }
    
    $opuid = $query['uid'];
    $groupid = $query['groupid'];
    
    $member=C::t('common_member')->fetch($opuid, false, 1);
    if(count($member)==0){
        $inarchive = '_inarchive';
    }else{
        $inarchive = '';
    }
    if($gcount == 0){
        C::t('common_member'.$inarchive)->update($opuid, array('groupid'=>$groupid));
    }elseif ($gcount>0) {
        $sumtime = $gcount*86400;
        $groupexpiryTime = TIMESTAMP +	$sumtime;
        if($groupid == $member['groupid']){
            $groupexpiryTime = $member['groupexpiry'] + $sumtime;
        }
        C::t('common_member'.$inarchive)->update($opuid, array('groupid'=>$groupid ,'groupexpiry'=>$groupexpiryTime));
        $groupterms['main'] = array('time' => $groupexpiryTime,'groupid'=>10);
        $groupterms['ext'][$groupid] = $groupexpiryTime;
        C::t('common_member_field_forum'.$inarchive)->update($opuid,array('groupterms' => serialize($groupterms)));
    }
    
    //�ӻ���
    updatemembercount($query['uid'], array('extcredits'.$query['zsintetype']=>$query['zsintcount']),true,'',0,'',lang('plugin/dev8133_vipmq', 'shstr03'),lang('plugin/dev8133_vipmq', 'shstr04'));
   
    //����Ϣ
    $msg = lang('plugin/dev8133_vipmq', 'shstr05').$_G['cache']['usergroups'][$query['groupid']]['grouptitle'].lang('plugin/dev8133_vipmq', 'shstr06');
    notification_add($query['uid'], 'system', $msg);
    showmessage(lang('plugin/dev8133_vipmq', 'common_06'), 'plugin.php?id=dev8133_vipmq&modac=sh&page='.intval($_GET['page']),'',array('alert=>right'));
    
}elseif($submodac == "delete"){
    
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('error');
    }
    
    $aid = intval($_GET['aid']);
    $wheres = " where id=".$aid;
    $query = C::t('#dev8133_vipmq#dev8133_vipmq_order')->fetch_first_field_data('*', $wheres);
    if(!$query){
        showmessage("data error");
    }
    C::t('#dev8133_vipmq#dev8133_vipmq_order')->delete_by_id($aid);
    
    showmessage(lang('plugin/dev8133_vipmq', 'common_06'), 'plugin.php?id=dev8133_vipmq&modac=sh&page='.intval($_GET['page']),'',array('alert=>right'));
    
}else{
    
    
    $wheres .= " order by dateline desc";
    $ppp = 25;
    $tmpurl = 'plugin.php?id=dev8133_vipmq&modac=sh';
    
    
    $page = max ( 1, intval($_GET ['page']));
    $startlimit = ($page - 1) * $ppp;
    $allcount = C::t('#dev8133_vipmq#dev8133_vipmq_order')->count_all($wheres);
    if ($allcount) {
        $uidccfadata = C::t ( '#dev8133_vipmq#dev8133_vipmq_order' )->fetch_all_by_limit( $startlimit, $ppp, $wheres );
    }
    $multipage = '';
    $multipage = multi ( $allcount, $ppp, $page, $_G ['siteurl'] . $tmpurl );
    
    include template('dev8133_vipmq:admin');
}
//From: Dism_taobao_com
?>