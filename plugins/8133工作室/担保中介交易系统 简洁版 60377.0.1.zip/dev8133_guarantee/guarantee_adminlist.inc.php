<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo '<script type="text/javascript"  src="source/plugin/dev8133_guarantee/js/dev8133.js"></script>';
echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
require_once DISCUZ_ROOT.'/source/plugin/dev8133_guarantee/guarantee.cfg.php';

loadcache('plugin');

$guaranteeplg =  $_G['cache']['plugin']['dev8133_guarantee'];

$operation= daddslashes($_GET['cp']);


if($operation == "delete"){
	
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		cpmsg('error');
	}
	
	$orderid = daddslashes($_GET['orderid']);
	C::t('#dev8133_guarantee#dev8133_guarantee')->deteletbyorder($orderid);
	cpmsg(lang('plugin/dev8133_guarantee', 'admin_cgtc'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=guarantee_adminlist&identifier=dev8133_guarantee', 'succeed');
	
}

if($operation =="qrsk"){
	$orderid = daddslashes($_GET['orderid']);
	$updatedata  =  array(
			'updateline'=>time(),
			'trstatus'=>30,
	);
	C::t('#dev8133_guarantee#dev8133_guarantee')->update(array('orderid'=>$orderid),$updatedata);
	cpmsg(lang('plugin/dev8133_guarantee', 'admin_cgtc'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=guarantee_adminlist&identifier=dev8133_guarantee', 'succeed');
}

if($operation =="dkbuyer"){
	
		if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
			cpmsg('error');
		}
		
		$orderid = daddslashes($_GET['orderid']);
		$updatedata  =  array(
				'updateline'=>time(),
				'trstatus'=>6,
		);
		C::t('#dev8133_guarantee#dev8133_guarantee')->update(array('orderid'=>$orderid),$updatedata);
		cpmsg(lang('plugin/dev8133_guarantee', 'admin_cgtc'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=guarantee_adminlist&identifier=dev8133_guarantee', 'succeed');
}

if(submitcheck('appdatasearch')) {
	showtableheader(lang('plugin/dev8133_guarantee', 'admin_ss'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=guarantee_adminlist&identifier=dev8133_guarantee');   
	showtablerow('','', array(
				lang('plugin/dev8133_guarantee', 'admin_hym'),
	            "<input  name=\"username\" type=\"text\"/>", 
	            lang('plugin/dev8133_guarantee', 'admin_lsh'),
	            "<input  name=\"orderid\" type=\"text\"/>", 
	         	 lang('plugin/dev8133_guarantee', 'admin_sqsjd'),
	             "<input style=\"width:120px;\" name=\"searchbegin\" type=\"text\" onclick=\"showcalendar(event, this)\" />&nbsp;---&nbsp;<input style=\"width:120px;\" name=\"searchend\" type=\"text\" onclick=\"showcalendar(event, this)\" />",  
			));
	showsubmit('appdatasearch');
	showformfooter(); /*Dism_taobao-com*/
	showtablefooter(); /*Dism_taobao_com*/
	
	showtableheader(lang('plugin/dev8133_guarantee', 'admin_dqgy'));
	
	showtablerow("",'',array(
				lang('plugin/dev8133_guarantee', 'admin_l01'),
				lang('plugin/dev8133_guarantee', 'admin_l02'),
				lang('plugin/dev8133_guarantee', 'admin_l03'),
				lang('plugin/dev8133_guarantee', 'admin_l04'),
				lang('plugin/dev8133_guarantee', 'admin_l05'),
				lang('plugin/dev8133_guarantee', 'admin_l08'),
				lang('plugin/dev8133_guarantee', 'admin_201'),
				lang('plugin/dev8133_guarantee', 'admin_l09'),
				lang('plugin/dev8133_guarantee', 'admin_l11'),
				lang('plugin/dev8133_guarantee', 'admin_l07'),
	));
	
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
			cpmsg('error');
	}
	
	$username = daddslashes($_GET['username']);
	$orderid = daddslashes($_GET['orderid']);
	$searchbegin = daddslashes($_GET['searchbegin']);
	$searchend = daddslashes($_GET['searchend']);
	
	if(!$username && !$orderid && !$searchbegin && !$searchend){
		
		$url = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&pmod=guarantee_adminlist&identifier=dev8133_guarantee';
		Header("Location: $url");
	}
	
	$appdata = C::t('#dev8133_guarantee#dev8133_guarantee')->fetch_orderCondition($username,$orderid,$searchbegin,$searchend);
	
	foreach($appdata as $appvalue){
		
			$appvalue['updateline']  = dgmdate($appvalue['updateline'],'Y/m/d H:i');
			
			if($appvalue['trstatus'] == 3){
				$str = "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=guarantee_adminlist&identifier=dev8133_guarantee&cp=qrsk&orderid=".$appvalue['orderid']."'>确认收到买家付款</a>";
			}else if($appvalue['trstatus'] == 5){
				$str = "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=guarantee_adminlist&identifier=dev8133_guarantee&cp=dkbuyer&formhash=".formhash()."&orderid=".$appvalue['orderid']."'>打款到买家</a>|"."<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=guarantee_adminlist&identifier=dev8133_guarantee&cp=delete&orderid=".$appvalue['orderid']."'>删除</a>";
			}else{
				$str = "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=guarantee_adminlist&identifier=dev8133_guarantee&cp=delete&formhash=".formhash()."&orderid=".$appvalue['orderid']."'>删除</a>";
			}
			$str .= "| <a target='_blank' href='plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&type=detail&orderid=".$appvalue['orderid']."'>详情</a>";
				
			showtablerow("",'',array(
				$appvalue['orderid'],
				$appvalue['buyerusername'],
				$appvalue['buysermobile'],
				
				$appvalue['sellerusername'],
				$appvalue['sellermobile'],
				$appvalue['tramount'],
				$appvalue['tramount']+($appvalue['tramount']*($guaranteeplg['guarantee_afee']/100)),
				$trstatus[$appvalue['trstatus']],
				$appvalue['updateline'],
				$str
			));
	}
	showtablefooter(); /*Dism_taobao_com*/
	exit;
}

if(!submitcheck('appdatasearch')) {
	showtableheader(lang('plugin/dev8133_guarantee', 'admin_ss'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=guarantee_adminlist&identifier=dev8133_guarantee');   
	showtablerow('','', array(
				lang('plugin/dev8133_guarantee', 'admin_hym'),
	            "<input  name=\"username\" type=\"text\"/>", 
	            lang('plugin/dev8133_guarantee', 'admin_lsh'),
	            "<input  name=\"orderid\" type=\"text\"/>", 
	         	 lang('plugin/dev8133_guarantee', 'admin_sqsjd'),
	             "<input style=\"width:120px;\" name=\"searchbegin\" type=\"text\" onclick=\"showcalendar(event, this)\" />&nbsp;---&nbsp;<input style=\"width:120px;\" name=\"searchend\" type=\"text\" onclick=\"showcalendar(event, this)\" />",  
			));
	showsubmit('appdatasearch');
	showformfooter(); /*Dism_taobao-com*/
	showtablefooter(); /*Dism_taobao_com*/
}

	$curpage=intval(getgpc('page'));
	if($curpage<1){
		$curpage=1;
	}
	
	$pageUrl=ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=guarantee_adminlist&identifier=dev8133_guarantee";

	$sumje = C::t('#dev8133_guarantee#dev8133_guarantee')->getsum();
	$zbs = C::t('#dev8133_guarantee#dev8133_guarantee')->getsumr();
	showtableheader(lang('plugin/dev8133_guarantee', 'admin_dqgy')."<font color='red'>&nbsp;&nbsp;总金额:".$sumje['sumtramount']."&nbsp;&nbsp;交易总笔数:".$zbs['sumr']."</font>");
	
	showtablerow("",'',array(
				lang('plugin/dev8133_guarantee', 'admin_l01'),
				lang('plugin/dev8133_guarantee', 'admin_l02'),
				lang('plugin/dev8133_guarantee', 'admin_l03'),
				lang('plugin/dev8133_guarantee', 'admin_l04'),
				lang('plugin/dev8133_guarantee', 'admin_l05'),
				lang('plugin/dev8133_guarantee', 'admin_l08'),
				lang('plugin/dev8133_guarantee', 'admin_201'),
				lang('plugin/dev8133_guarantee', 'admin_l09'),
				lang('plugin/dev8133_guarantee', 'admin_l11'),
				lang('plugin/dev8133_guarantee', 'admin_l07'),
	));
	
	$pagesize=15;
	
	$appdata = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchappdataall(($curpage-1)*$pagesize,$pagesize);
	
	$sumcount = C::t('#dev8133_guarantee#dev8133_guarantee')->count();
	
	$zjf = 0;
	$sum=0;
	
	foreach($appdata as $appvalue){
		
			$appvalue['updateline']  = dgmdate($appvalue['updateline'],'Y/m/d H:i');
			if($appvalue['trstatus'] == 3){
				$str = "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=guarantee_adminlist&identifier=dev8133_guarantee&cp=qrsk&orderid=".$appvalue['orderid']."'>确认收到买家付款</a>";
			}else if($appvalue['trstatus'] == 5){
				$str = "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=guarantee_adminlist&identifier=dev8133_guarantee&cp=dkbuyer&formhash=".formhash()."&orderid=".$appvalue['orderid']."'>打款到买家</a>|"."<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=guarantee_adminlist&identifier=dev8133_guarantee&cp=delete&orderid=".$appvalue['orderid']."'>删除</a>";
			}else{
				$str = "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=guarantee_adminlist&identifier=dev8133_guarantee&cp=delete&formhash=".formhash()."&orderid=".$appvalue['orderid']."'>&nbsp;&nbsp;&nbsp;删除&nbsp;&nbsp;&nbsp;  </a>";
			}
			$str .= "| <a target='_blank' href='plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&type=detail&orderid=".$appvalue['orderid']."'> &nbsp;&nbsp;&nbsp;详情&nbsp;&nbsp;&nbsp; </a>";
			
			$zje +=($appvalue['tramount']*($guaranteeplg['guarantee_afee']/100));
			$sum += $appvalue['tramount'];
			showtablerow("",'',array(
				$appvalue['orderid'],
				$appvalue['buyerusername'],
				$appvalue['buysermobile'],
				$appvalue['sellerusername'],
				$appvalue['sellermobile'],
				$appvalue['tramount'],
				//$appvalue['tramount']+($appvalue['tramount']*($guaranteeplg['guarantee_afee']/100)),
				$appvalue['tramount']*($guaranteeplg['guarantee_afee']/100),
				$trstatus[$appvalue['trstatus']],
				$appvalue['updateline'],
				$str,
			));
	}
	$str = "<strong style='color:green'>中介金额:$zje &nbsp;&nbsp;交易金额：$sum</strong>";
	$pagenav=multi($sumcount, $pagesize, $curpage, $pageUrl);
	echo "<tr><td colspan=2>".$str."</td><td align=right colspan=10>".$pagenav."</td><tr>";
	showtablefooter(); /*Dism_taobao_com*/
	
	
?>