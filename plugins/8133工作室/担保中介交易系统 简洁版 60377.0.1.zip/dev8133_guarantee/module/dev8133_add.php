<?php 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$submit  = dhtmlspecialchars($_GET['submit']);

$app_type = dhtmlspecialchars($_GET['app_type']);

if($submit == 'yes'){
	
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash()){
		showmessage('error');
	}
	
		$dev8133_group = dunserialize($guaranteeplg['guarantee_groups']);
		if(!in_array($_G['groupid'],$dev8133_group)){
			
			showmessage(lang('plugin/dev8133_guarantee','add6'));
		}
	
	$sbrelation = dhtmlspecialchars($_GET['sbrelation']);
	//������� ����
	if($sbrelation == 1){
		$buyerusername = $_G['username'];
		$buyeruid = $_G['uid'];
		$sellerusername = dhtmlspecialchars($_GET['sellerusername']);
		//����username ��ȡuid
		$userinfo  = C::t('common_member')->fetch_by_username($sellerusername);
		if(!$userinfo['uid']){
			showmessage(lang('plugin/dev8133_guarantee', 'add1'));
		}
		if($userinfo['uid'] == $_G['uid']){
			showmessage(lang('plugin/dev8133_guarantee', 'add2'));
		}
		$selleruid = $userinfo['uid'];	
		
	}else if($sbrelation == 2){
		$sellerusername = $_G['username'];
		$selleruid = $_G['uid'];	
		$buyerusername = dhtmlspecialchars($_GET['buyerusername']);;
		//����username ��ȡuid
		$userinfo  = C::t('common_member')->fetch_by_username($buyerusername);
		if(!$userinfo['uid']){
			showmessage(lang('plugin/dev8133_guarantee', 'add3'));
		}
		if($userinfo['uid'] == $_G['uid']){
			showmessage(lang('plugin/dev8133_guarantee', 'add4'));
		}
		$buyeruid = $userinfo['uid'];
	}else{
		showmessage("error");
	}
	
	
	$gdata = array(
		'orderid'=>dgmdate(TIMESTAMP, 'YmdHis').random(3),
		'buyerusername'=> $buyerusername,
		'buyeruid'=> $buyeruid,
		'buysermobile' => dhtmlspecialchars($_GET['buysermobile']),
		'buyserqq' => dhtmlspecialchars($_GET['buyserqq']),
		'sellerusername'=> $sellerusername,
		'selleruid'=> $selleruid,
	    'sellermobile'=> dhtmlspecialchars($_GET['sellermobile']),
	    'sellerqq' => dhtmlspecialchars($_GET['sellerqq']),
		'tramount'=> intval($_GET['tramount']),
		'message'=>dhtmlspecialchars($_GET['message']),
		'trstatus'=>1,
		'dateline'=>time(),
		'updateline'=>time(),
		'createuid'=> $_G['uid'],
	);
	
	if($_FILES['imgsrc1']){
		$gdata['imgsrc1'] =  uploadimg($_FILES['imgsrc1'],date('YmdHis').rand(100,999));
	}
	if($_FILES['imgsrc2']){
		$gdata['imgsrc2'] =  uploadimg($_FILES['imgsrc2'],date('YmdHis').rand(1000,9999));
	}
	
	if($_FILES['imgsrc3']){
		$gdata['imgsrc3'] =  uploadimg($_FILES['imgsrc3'],date('YmdHis').rand(10000,99999));
	
	}
	C::t('#dev8133_guarantee#dev8133_guarantee')->insert($gdata);
	showmessage(lang('plugin/dev8133_guarantee', 'add5'),"plugin.php?id=dev8133_guarantee:guarantee",array(),array('alert'=>'right'));
	
}else if($app_type=="buyer"){
		$dev8133_group = dunserialize($guaranteeplg['guarantee_groups']);
		if(!in_array($_G['groupid'],$dev8133_group)){
			
			showmessage(lang('plugin/dev8133_guarantee','add6'));
		}
	
	$sbrelation=1;
	include template('dev8133_guarantee:main_add');
}else if($app_type=="seller"){
		$dev8133_group = dunserialize($guaranteeplg['guarantee_groups']);
		if(!in_array($_G['groupid'],$dev8133_group)){
			
			showmessage(lang('plugin/dev8133_guarantee','add6'));
		}
	
	$sbrelation=2;
	include template('dev8133_guarantee:main_add');
}else {
	include template('dev8133_guarantee:main_qdsf');
}


function uploadimg($filesobj,$picname){
	
	$path = 'source/plugin/dev8133_guarantee/uploadimg';
	
	
	if(!is_dir($path)) mkdir($path);
	
	$fmpath = "";
	
	if ($filesobj['size'] < 2097152){
		$filetype = pathinfo($filesobj['name'], PATHINFO_EXTENSION);
		if( in_array($filetype, array('jpg','png','gif','jpeg')))
		{
			$fmpath = $path.'/'.$picname.'.'.$filetype;
			 move_uploaded_file($filesobj['tmp_name'], $fmpath);
		}
	}
	
	return  $fmpath;
	
}
//From: Dism��taobao��com
?>