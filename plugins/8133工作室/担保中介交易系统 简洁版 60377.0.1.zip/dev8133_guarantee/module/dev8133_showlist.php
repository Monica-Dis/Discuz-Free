<?php 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



$type  = dhtmlspecialchars($_GET['type']);

$tab = intval($_GET['tab']);

$pagesize=15;

$curpage=intval(getgpc('page'));
if($curpage<1){
	$curpage=1;
}

if($type == 'seller'){
	
	if($tab == 1 || !$tab){

		$pageUrl="plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&tab=1&type=seller";
		
		$buyerdata = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyuidsb($_G['uid'],2,0,($curpage-1)*$pagesize,$pagesize);
		
		$sumcount = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyuidcount($_G['uid'],2);
		
	}elseif($tab == 2){
		
		$pageUrl="plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&tab=2&type=seller";
		
		$buyerdata = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyuidsb($_G['uid'],2,3,($curpage-1)*$pagesize,$pagesize);
		
		$sumcount = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyuidcount($_G['uid'],2,3);
		
		
	}elseif($tab == 3){
		
		$pageUrl="plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&tab=3&type=seller";
		
		$buyerdata = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyuidsb($_G['uid'],2,5,($curpage-1)*$pagesize,$pagesize);
		
		$sumcount = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyuidcount($_G['uid'],2,5);
		
	}
	
	$pagenav=multi($sumcount['pcount'], $pagesize, $curpage, $pageUrl);
	
	include template('dev8133_guarantee:main_orderlist');

}else if($type == 'buyer') {
	
	
	if($tab == 1  || !$tab){
		
		
		$pageUrl="plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&tab=1&type=buyer";
		
		
		$buyerdata = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyuidsb($_G['uid'],1,0,($curpage-1)*$pagesize,$pagesize);
		
		$sumcount = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyuidcount($_G['uid'],1);
		
	}elseif($tab == 2){
		
		
		$pageUrl="plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&tab=2&type=buyer";
		
		$buyerdata = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyuidsb($_G['uid'],1,2,($curpage-1)*$pagesize,$pagesize);
		
		$sumcount = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyuidcount($_G['uid'],1,2);
		
	}elseif($tab == 3){
		

		$pageUrl="plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&tab=3&type=buyer";
		
		$buyerdata = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyuidsb($_G['uid'],1,4,($curpage-1)*$pagesize,$pagesize);
		
		$sumcount = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyuidcount($_G['uid'],1,4);
		
	}
	$pagenav=multi($sumcount['pcount'], $pagesize, $curpage, $pageUrl);
	
	include template('dev8133_guarantee:main_orderlist');

}else if($type == 'detail'){
	

	require_once libfile('function/discuzcode');
	
	$orderid=  dhtmlspecialchars($_GET['orderid']);
	
	$oper  = dhtmlspecialchars($_GET['oper']);
	
	$orderdata  = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyorderid($orderid);
	if(!$orderdata){
		showmessage("error");
	}
	//�ж�������һ�����Ҷ����ǵ�ǰ�û�����
	if($_G['uid'] !=1){
		if(($orderdata['buyeruid'] != $_G['uid']) && ($orderdata['selleruid'] != $_G['uid'])){
			showmessage("error");
		}
	}
	$orderdata['message'] = discuzcode($orderdata['message']);
	
	include template('dev8133_guarantee:main_detail');
}
//From: Dism��taobao��com
?>