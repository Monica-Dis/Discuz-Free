<?php 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
	showmessage('error');
}

$orederid = dhtmlspecialchars($_GET['orderid']);

$orderiddata = C::t('#dev8133_guarantee#dev8133_guarantee')->fetchbyorderid($orederid);

if(!$orderiddata){
	showmessage("error");
}

//�ж�������һ�����Ҷ����ǵ�ǰ�û�����
if(($orderiddata['buyeruid'] != $_G['uid']) && ($orderiddata['selleruid'] != $_G['uid'])){
	showmessage("error");
}

$op = intval($_GET['op']);

if($op == 1){
	//�����жϵ�ǰ������������Ƿ�Ϸ�
	if(($orderiddata['trstatus'] == 1)){
		$updatedata  =  array(
			'updateline'=>time(),
			'trstatus'=>2,
		);
		
		C::t('#dev8133_guarantee#dev8133_guarantee')->update(array('orderid'=>$orederid),$updatedata);
		showmessage(lang('plugin/dev8133_guarantee', 'handlerstatus1'),"plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&type=detail&orderid=".$orederid."&oper=".$_GET['oper']."&formhash=".formhash(),array(),array('alert'=>'right'));
	}else{
		showmessage("order error");
	}
	
}elseif($op == 2){
	if(($orderiddata['trstatus'] == 1)){
		$updatedata  =  array(
				'updateline'=>time(),
				'trstatus'=>23,
		);
		C::t('#dev8133_guarantee#dev8133_guarantee')->update(array('orderid'=>$orederid),$updatedata);
		showmessage(lang('plugin/dev8133_guarantee', 'handlerstatus2'),"plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&type=detail&orderid=".$orederid."&oper=".$_GET['oper']."&formhash=".formhash(),array(),array('alert'=>'right'));
	}else{
		showmessage("order error");
	}
}elseif($op == 3){
	if(($orderiddata['trstatus'] == 2)){
		$zjpay = intval($_GET['zjpay']);
		$updatedata  =  array(
			'updateline'=>time(),
			'trstatus'=>3,
			'hrzh'=>$zjpay
		);
		C::t('#dev8133_guarantee#dev8133_guarantee')->update(array('orderid'=>$orederid),$updatedata);
		showmessage(lang('plugin/dev8133_guarantee', 'handlerstatus3'),"plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&type=detail&orderid=".$orederid."&oper=".$_GET['oper']."&formhash=".formhash(),array(),array('alert'=>'right'));
	}else{
		showmessage("error");
	}
	
}elseif($op == 4){
	if(($orderiddata['trstatus'] == 30)){
		$updatedata  =  array(
			'updateline'=>time(),
			'trstatus'=>4,
		);
		if($_GET['express']){
			$updatedata['express'] = intval($_GET['express']);
			$updatedata['expressno'] = dhtmlspecialchars($_GET['expressno']);
		}
		C::t('#dev8133_guarantee#dev8133_guarantee')->update(array('orderid'=>$orederid),$updatedata);
		showmessage(lang('plugin/dev8133_guarantee', 'handlerstatus4'),"plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&type=detail&orderid=".$orederid."&oper=".$_GET['oper']."&formhash=".formhash(),array(),array('alert'=>'right'));
		
	}else{
		showmessage("error");
	}
	
}elseif($op == 5){
	if(($orderiddata['trstatus'] == 4)){
		$updatedata  =  array(
			'updateline'=>time(),
			'trstatus'=>5,
		);
		C::t('#dev8133_guarantee#dev8133_guarantee')->update(array('orderid'=>$orederid),$updatedata);
		showmessage(lang('plugin/dev8133_guarantee', 'handlerstatus5'),"plugin.php?id=dev8133_guarantee:guarantee&modac=showlist&type=detail&orderid=".$orederid."&oper=".$_GET['oper']."&formhash=".formhash(),array(),array('alert'=>'right'));
	}else{
		showmessage("error");
	}
}

//From: dis'.'m.tao'.'bao.com
?>