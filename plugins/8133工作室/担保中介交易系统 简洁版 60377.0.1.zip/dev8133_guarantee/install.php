<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$installsql = <<<EOF
DROP TABLE IF EXISTS cdb_dev8133_guarantee;
CREATE TABLE IF NOT EXISTS `cdb_dev8133_guarantee` (
  `orderid` varchar(33) NOT NULL ,
  `sbrelation` 	tinyint(1)  NOT NULL,
  `buyerusername` char(15) NOT NULL,
  `buyeruid`	 mediumint(8) unsigned NOT NULL,
  `buysermobile`  varchar(13) NOT NULL,
  `buyserqq`  	varchar(255)  NOT NULL,
  `sellerusername` char(15) NOT NULL,
  `selleruid`	 mediumint(8) unsigned NOT NULL,
  `sellermobile`  varchar(13) NOT NULL,
  `sellerqq`  varchar(255) NOT NULL,
  `express`  int(10) unsigned NOT NULL,
  `expressno`  varchar(50)  NOT NULL,
  `hrzh`  int(10) unsigned NOT NULL,
  `tramount`  int(10) unsigned NOT NULL,
  `coststype` 	tinyint(1)  NOT NULL,
  `imgsrc1`   varchar(255) NOT NULL,
  `imgsrc2`   varchar(255) NOT NULL,
  `imgsrc3`   varchar(255) NOT NULL,
  `message`	  text NOT NULL,
  `trstatus` 	tinyint(1)  NOT NULL,
  `dateline` int(10) NOT NULL,
  `updateline` int(10) NOT NULL,
  `createuid`	 mediumint(8) unsigned NOT NULL,
  PRIMARY KEY  (`orderid`)
)ENGINE=MyISAM;

EOF;

runquery($installsql);
$finish = TRUE;



@unlink(DISCUZ_ROOT . './source/plugin/dev8133_guarantee/discuz_plugin_dev8133_guarantee.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_guarantee/discuz_plugin_dev8133_guarantee_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_guarantee/discuz_plugin_dev8133_guarantee_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_guarantee/discuz_plugin_dev8133_guarantee_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_guarantee/discuz_plugin_dev8133_guarantee_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/dev8133_guarantee/install.php');


?>