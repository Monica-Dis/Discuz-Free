<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
	if (!defined('IN_DISCUZ')) {
		exit ('Access Denied');
	}

	
	$trstatus =  array(

		1=>lang('plugin/dev8133_guarantee', 'orderstatus1'),
		2=>lang('plugin/dev8133_guarantee', 'orderstatus2'),
		3=>'<font color="red"><b>买家已打款到中介，等待中介已确认</b></font>',
		30=>'<font color="red"><b>中介已确认,等待卖家发货</b></font>',
		4=>lang('plugin/dev8133_guarantee', 'orderstatus4'),
		5=>lang('plugin/dev8133_guarantee', 'orderstatus5'),
		6=>lang('plugin/dev8133_guarantee', 'orderstatus6'),
		23=>lang('plugin/dev8133_guarantee', 'orderstatus23'),
	);





?>