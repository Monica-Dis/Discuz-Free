<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_dev8133_guarantee extends discuz_table
{
	public function __construct() {

		$this->_table = 'dev8133_guarantee';
		$this->_pk    = 'orderid';
		parent::__construct(); /*dism��taobao��com*/
	}
	
	public function fetchbyuid($uid=0,$dfuid=0)
	{
		
		if($uid && $dfuid){
			return DB::fetch_all('SELECT * FROM  %t   where uid=%d or dfuid=%d', array($this->_table,$uid,$dfuid));
		}else if($uid && !$dfuid){
			return DB::fetch_all('SELECT * FROM  %t   where uid=%d', array($this->_table,$uid));
		}else if($dfuid  && !$uid){
			return DB::fetch_all('SELECT * FROM  %t   where dfuid=%d', array($this->_table,$dfuid));
		}
	}
	
	//���
	public function fetchbyuidsb($uid=0,$apptype=1,$trstatus=0,$begin=0,$showcount=10)
	{
		
		if($apptype == 1){
			if(!$trstatus){
				return DB::fetch_all('SELECT * FROM  %t  where buyeruid=%d order by updateline desc limit %d,%d', array($this->_table,$uid,$begin,$showcount));
			}else{
				return DB::fetch_all('SELECT * FROM  %t  where buyeruid=%d and trstatus=%d order by updateline desc limit %d,%d', array($this->_table,$uid,$trstatus,$begin,$showcount));
			}
		}else{
			if(!$trstatus){
				return DB::fetch_all('SELECT * FROM  %t  where selleruid=%d order by updateline desc limit %d,%d', array($this->_table,$uid,$begin,$showcount));
			}else{
				return DB::fetch_all('SELECT * FROM  %t  where selleruid=%d and trstatus=%d order by updateline desc limit %d,%d', array($this->_table,$uid,$trstatus,$begin,$showcount));
			}
		}
		
	}
	
	//���count
	public function fetchbyuidcount($uid=0,$apptype=1,$trstatus=0)
	{
		if($apptype == 1){
			if(!$trstatus){
				return DB::fetch_first('SELECT count(*) as pcount FROM  %t  where buyeruid=%d', array($this->_table,$uid));
			}else{
				return DB::fetch_first('SELECT count(*) as pcount FROM  %t  where buyeruid=%d and trstatus=%d', array($this->_table,$uid,$trstatus));
			}
		}else{
			if(!$trstatus){
				return DB::fetch_first('SELECT count(*) as pcount FROM  %t  where selleruid=%d', array($this->_table,$uid));
			}else{
				return DB::fetch_first('SELECT count(*) as pcount FROM  %t  where selleruid=%d and trstatus=%d', array($this->_table,$uid,$trstatus));
			}
		}
	
	}
	
	
	public function fetchbyorderid($orderid)
	{
		return DB::fetch_first('SELECT * FROM  %t   where orderid=%s', array($this->_table,$orderid));
		
	}
	
	public function fetchbycount($uid,$trstatus)
	{
		return DB::fetch_first('SELECT * FROM  %t   where trstatus=%d and (buyeruid=%d or selleruid=%d)', array($this->_table,$trstatus,$uid,$uid));
		
	}
	
	
	public function fetchappdataall($begin=0,$showcount=10)
	{
		return DB::fetch_all('SELECT * FROM  %t ORDER BY updateline desc limit %d,%d', array($this->_table,$begin,$showcount));
	}
	
	public function fetch_orderCondition($username=null,$orderid=null,$submitdatebegin=null,$submitdateend=null)
	{
		$condition = '';
		$condition .= $orderid ? " AND orderid='". $orderid."'":'';
		$condition .= $username ? " AND buyerusername=". "'".$username."'":'';

		if($submitdatebegin and $submitdateend){
			$condition .=' AND (updateline>='.strtotime($submitdatebegin.' 00:00:00').' AND updateline<='.strtotime($submitdateend.' 23:59:59').')';
		}
		if($submitdatebegin and !$submitdateend){
				$condition .=$submitdatebegin? ' AND updateline>='.strtotime($submitdatebegin.' 00:00:00'):'';
		}
		$condition = substr($condition,4);
		return  DB::fetch_all('SELECT * FROM  %t   where ' .$condition .' ORDER BY updateline desc', array($this->_table));
		
	}
	
	public function fetchjyje($uid)
	{
		return DB::fetch_first('SELECT sum(tramount)  as  sumtramount FROM  %t   where trstatus=6 and (buyeruid=%d or selleruid=%d)', array($this->_table,$uid,$uid));
	
	}
	
	public function deteletbyorder($orderid)
	{
		return DB::query('delete  FROM  %t   where orderid=%s', array($this->_table,$orderid));
	
	}
	
		public function getsum()
	{
		return DB::fetch_first('SELECT sum(tramount)  as  sumtramount FROM  %t', array($this->_table));
	
	}
	
			public function getsumr()
	{
		return DB::fetch_first('SELECT count(*)  as  sumr FROM  %t', array($this->_table));
	
	}
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>