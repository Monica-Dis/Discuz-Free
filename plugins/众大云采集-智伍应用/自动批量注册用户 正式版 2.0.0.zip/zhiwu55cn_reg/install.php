<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_zhiwu55cn_reg` (
  `uid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(200) DEFAULT NULL,
  `username_pwd` varchar(50) DEFAULT NULL,
  `username_mail` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;