<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
runquery('DROP TABLE IF EXISTS `pre_zhiwu55cn_reg`');
$finish = true;