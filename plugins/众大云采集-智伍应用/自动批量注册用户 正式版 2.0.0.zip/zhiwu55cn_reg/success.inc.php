<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
function insertUserAli($uid) {
	
	if (is_numeric($uid) == false || $uid==1) {
		return false;
	}
	$chkUid2 = DB::fetch_first('SELECT * FROM %t WHERE uid=%d',array('zhiwu55cn_reg',$uid));
	if (count($chkUid2) == 0) {
		$chkUid = getuserbyuid($uid, 1);
		if (count($chkUid) > 1) {
			$userArr = array();
			$userArr['uid'] = $uid;
			$userArr['username'] = $chkUid['username'];
			$userArr['username_pwd'] = 'XXXXXXXXXX';
			$userArr['username_mail'] = 'XXXXXX@XXX';
			DB::insert('zhiwu55cn_reg', $userArr);
		}
	}
	
}
if (empty($_GET['page']) || is_numeric($_GET['page']) === false) {
	$page = 1;
} else {
	$page = intval($_GET['page']);
	$page = max(1, $page);
}
$server_url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zhiwu55cn_reg&pmod=success';
if ($_GET['formhash'] == FORMHASH && empty($_GET['deluser']) == false && $_GET['deluser'] == 'yes') {
	
	if(empty($_GET['clears_all'])==false)
	{
		DB::delete('zhiwu55cn_reg', 'uid>0');
		cpmsg('zhiwu55cn_reg:succeed', $server_url , 'succeed');
	}
	if(empty($_GET['uidarray']))
	{
		cpmsg('zhiwu55cn_reg:select_empty', '' , 'error');
	}
	$uidarray = $_GET['uidarray'];
	foreach ($uidarray as $uid) {
		DB::delete('zhiwu55cn_reg', 'uid=' . intval($uid));
	}
	include template('zhiwu55cn_reg:delete_vest_list');
	
} elseif ($_GET['formhash'] == FORMHASH && empty($_GET['modifypic']) == false && is_numeric($_GET['modifypic']) == true) {
	
	loaducenter();
	$avatarhtml = uc_avatar($_GET['modifypic']);
	include template('zhiwu55cn_reg:uc_avatar');

} elseif($_GET['formhash'] == FORMHASH && !empty($_GET['subpmod']) && $_GET['subpmod']=='importVest') {
	
	$server_url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zhiwu55cn_reg&pmod=success&subpmod=importVest&formhash=' . FORMHASH;
	if ($_GET['formhash'] == FORMHASH && empty($_GET['inputuser']) == false && $_GET['inputuser'] == 'yes') {
		if (empty($_GET['add_uids']) == false) {
			$add_uids = $_GET['add_uids'];
			if (strpos($add_uids, ',') == false) {
				insertUserAli($add_uids);
			} else {
				$uid_arr = explode(',', $add_uids);
				foreach ($uid_arr as $uidValue) {
					insertUserAli($uidValue);
				}
			}
		}
		$back_server_url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zhiwu55cn_reg&pmod=success';
		cpmsg("zhiwu55cn_reg:import_vest_success", $back_server_url, "succeed");
	}
	include template('zhiwu55cn_reg:importVest');
	
} elseif($_GET['formhash'] == FORMHASH && !empty($_GET['subpmod']) && $_GET['subpmod']=='exportVest') {
	
	$user_list = DB::fetch_all('SELECT * FROM %t ORDER BY uid DESC',array('zhiwu55cn_reg'));
	foreach ($user_list as $uidvalue) {
		$uidstr = $uidvalue['uid'] . ',' . $uidstr;
	}
	$uidstr = substr($uidstr, 0, -1);
	include template('zhiwu55cn_reg:exportVest');
	
} elseif ($_GET['formhash'] == FORMHASH && empty($_GET['output']) == false && $_GET['output'] == 'yes') {
	
	
	$uidarray = DB::fetch_all('select uid from %t order by uid desc',array('zhiwu55cn_reg'));
	foreach ($uidarray as $uidvalue) {
		$uidstr = $uidvalue['uid'] . ',' . $uidstr;
	}
	$uidstr = substr($uidstr, 0, -1);
	include template('zhiwu55cn_reg:output_user_list');
	
	
} else {
	
	
	$VestCount = DB::result_first('SELECT count(*) FROM %t',array('zhiwu55cn_reg'));
	if($VestCount>0)
	{
		$TotalNumber = lang('plugin/zhiwu55cn_reg', 'total_number');
		$TotalPageNumber = $VestCount/20;
		$TotalPageNumber = @ceil($TotalPageNumber);
		$TotalNumber = str_replace('x',$TotalPageNumber,$TotalNumber);
		$TotalNumber = str_replace('y',$VestCount,$TotalNumber);
		$TotalNumber = str_replace('z',$page,$TotalNumber);
		$page = min($TotalPageNumber,$page);
		$startNum = ($page - 1) * 20;
		$homePage = $server_url . '&page=1';
		$nextPage = $server_url . '&page=' . ($page + 1);
		$prePage = $server_url . '&page=' . ($page - 1);
		$endPage = $server_url . '&page=' . $TotalPageNumber;	
		$user_list = DB::fetch_all('SELECT * FROM %t ORDER BY uid DESC LIMIT %d,20',array('zhiwu55cn_reg',$startNum));
		$start = $page - 4;		
		$start = min($TotalPageNumber - 8,$start);
		$start = max($start,1);
		$end = $start + 8;
		$end = min($end,$TotalPageNumber);
		$showPage="";
		for($i=$start;$i<=$end;$i++)
		{
			if($i==$page)
			{
				$showPage=$showPage . '<strong>' . $i . '</strong>';
			} else {
				$showPage=$showPage . '<a href="?' . $server_url . '&page=' . $i . '&formhash=' . FORMHASH . '">' . $i . '</a>';
			}
		}
	}
	include template('zhiwu55cn_reg:adminVest');
	
}