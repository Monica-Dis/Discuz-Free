<?php
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if (!isset($_G['cache']['plugin'])) {
	loadcache('plugin');
}
$version=$_G['setting']['plugins']['version']['zhiwu55cn_reg'];
include template('zhiwu55cn_reg:help');