<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
function zhiwu55_avatar_by_uid($uid, $img) {

	global $_G;
	C::t('common_member')->update($uid, array('avatarstatus' => 1));
	$uc_server = basename($_G['setting']['ucenterurl']);
	$dir = DISCUZ_ROOT . './' . $uc_server . '/data/avatar';
	$uid = sprintf("%09d", $uid);
	$dir1 = substr($uid, 0, 3);
	$dir2 = substr($uid, 3, 2);
	$dir3 = substr($uid, 5, 2);
	!is_dir($dir . '/' . $dir1) && mkdir($dir . '/' . $dir1, 0777);
	!is_dir($dir . '/' . $dir1 . '/' . $dir2) && mkdir($dir . '/' . $dir1 . '/' . $dir2, 0777);
	!is_dir($dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3) && mkdir($dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3, 0777);
	$avatar_small = $dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3 . '/' . substr($uid, -2) . "_avatar_small.jpg";
	$avatar_middle = $dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3 . '/' . substr($uid, -2) . "_avatar_middle.jpg";
	$avatar_big = $dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3 . '/' . substr($uid, -2) . "_avatar_big.jpg";
	$imgData = dfsockopen($img);
	file_put_contents($avatar_small, $imgData);
	file_put_contents($avatar_middle, $imgData);
	file_put_contents($avatar_big, $imgData);

}
function ip_random()
{

	$ip_long = array(
	array('607649792', '608174079'),
	array('1038614528', '1039007743'),
	array('1783627776', '1784676351'),
	array('2035023872', '2035154943'),
	array('2078801920', '2079064063'),
	array('-1950089216', '-1948778497'),
	array('-1425539072', '-1425014785'),
	array('-1236271104', '-1235419137'),
	array('-770113536', '-768606209'),
	array('-569376768', '-564133889'),
	 );
	$rand_key = mt_rand(0, 9);
	$ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
	return  $ip;

}
function reg_dateline()
{
	$startTime=time()-500000;
	$endTime=time();
	$regdate=rand($startTime,$endTime);
	return $regdate;

}
function zhiwu55com_appid()
{
	global $_G;
	$appid = '';
	$randNum=rand(1,50);
	$hzw_appid=getcookie('zhiwu55com_appid');
	if(!empty($hzw_appid) && strlen($hzw_appid)==32 && $randNum!=32)
	{
		return $hzw_appid;
	}
	$siteurl = parse_url($_G['siteurl'],PHP_URL_HOST);
	$siteurlArr=explode('.',$siteurl);
	array_splice($siteurlArr,0,-2);
	$siteurl=implode('.',$siteurlArr);
	$appid = $siteurl.dirname(__DIR__).php_uname('s').php_uname('n');
	$appid = md5($appid);
	$appid = strtoupper($appid);
	dsetcookie('zhiwu55com_appid',$appid,86400);
	$dataArr = array();
	$dataArr['siteurl'] = $_G['siteurl'];
	$dataArr['savepath'] = __DIR__;
	$dataArr['system_info'] = php_uname();
	$dataArr['http_server'] = $_SERVER['SERVER_SOFTWARE'];
	$returnStr = serialize($dataArr);
	$returnStr=base64_encode($returnStr);
	$remoteUrl = array();
	$remoteUrl['zhiwu55com_appid_data'] = $returnStr;
	$remoteUrl['zhiwu55com_appid'] = $appid;
	$fetchUrl = "http://www.zhiwu55.com/authorization/wwwzhiwu55com_empowerment_202005.php";
	dfsockopen($fetchUrl, 0, $remoteUrl);
	return $appid;
}
if ($_GET['formhash'] == FORMHASH && empty($_GET['zhiwu55_agrs']) == false && $_GET['zhiwu55_agrs'] == 'yes') {

	$appid=zhiwu55com_appid();
	$regData = dfsockopen('http://discuz.csdn123.net/avatar/zhiwu55_com.php?appid='.$appid);
	$regData = dunserialize($regData);
	if(is_array($regData)==false)
	{
		cpmsg("zhiwu55cn_reg:zhiwu55_com_01", '', "error");
	}
	$newgroupid = $_GET['newgroupid'];
	$newgroupid = intval($newgroupid);
	$credits=$_GET['credits'];
	$credits=intval($credits);
	$pws=$_GET['pws'];
	$spec_username=$_GET['spec_username'];
	$spec_avatar=$_GET['spec_avatar'];
	$spec_mail=$_GET['spec_mail'];
	$postsnew=$_GET['postsnew'];
	$digestpostsnew=$_GET['digestpostsnew'];
	$regdatenew=$_GET['regdatenew'];
	$lastvisitnew=$_GET['lastvisitnew'];
	$num=intval($_GET['num']);
	$num=min($num,5000);
	$sliceNum=0;
	if(!empty($spec_username))
	{
		$spec_usernameArr=preg_split('/[\r\n]+/',$spec_username);
		foreach($spec_usernameArr as $k=>$v)
		{
			if(!empty($v) && strlen($v)>1)
			{
				$v=diconv($v,CHARSET,'UTF-8');
				$regData[$k]['u']=trim($v);
			}
		}
		$sliceNum=max($sliceNum,$k);
	}
	if(!empty($spec_avatar))
	{
		$spec_avatarArr=preg_split('/[\r\n]+/',$spec_avatar);
		foreach($spec_avatarArr as $k=>$v)
		{
			if(!empty($v) && strlen($v)>1)
			{
				$regData[$k]['p']=trim($v);
			}
		}
		$sliceNum=max($sliceNum,$k);
	}
	if(!empty($spec_mail))
	{
		$spec_mailArr=preg_split('/[\r\n]+/',$spec_mail);
		foreach($spec_mailArr as $k=>$v)
		{
			if(!empty($v) && strlen($v)>1)
			{
				$regData[$k]['m']=trim($v);
			}
		}
		$sliceNum=max($sliceNum,$k);
	}
	if($sliceNum>0)
	{
		$sliceNum++;
		$num=$sliceNum;
		$regData=array_slice($regData,0,$sliceNum);
	}
	foreach ($regData as $regValue) {

		if($num==0)
		{
			$server_url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=zhiwu55cn_reg&pmod=success';
			cpmsg("zhiwu55cn_reg:zhiwu55_com_02", $server_url, "succeed");
		}		
		$zhiwu55_username = diconv($regValue['u'], 'UTF-8');
		$zhiwu55_username = addslashes($zhiwu55_username);
		$zhiwu55_img = $regValue['p'];
		if (empty($pws) || $pws == '') {
			$zhiwu55_password = random(10);
		} else {
			$zhiwu55_password = daddslashes($pws);
		}
		$zhiwu55_email = addslashes($regValue['m']);
		$zhiwu55_ip = ip_random();
		if (C::t('common_member')->fetch_uid_by_username($zhiwu55_username) || C::t('common_member_archive')->fetch_uid_by_username($zhiwu55_username)) {
			continue;
		}
		loaducenter();
		$uid = uc_user_register($zhiwu55_username, $zhiwu55_password, $zhiwu55_email,'','',$zhiwu55_ip);
		// var_dump($uid);exit;
		if ($uid <= 0) {
			continue;
		}
		loadcache('fields_register');
		if($credits==1)
		{
			$credits2=rand(1,20);
			$credits2=$credits2 * 2;
			$init_arr=array();
			$init_arr['credits'][0]=$credits2;
			$init_arr['credits'][1]=0;
			$init_arr['credits'][2]=$credits2;
			$init_arr['credits'][3]=0;
			$init_arr['credits'][4]=0;
			$init_arr['credits'][5]=0;
			$init_arr['credits'][6]=0;
			$init_arr['credits'][7]=0;
			$init_arr['credits'][8]=0;

		} else {

			$init_arr = explode(',', $_G['setting']['initcredits']);

		}
		$common_member_password = md5(random(10));
		C::t('common_member')->insert($uid, $zhiwu55_username, $common_member_password, $zhiwu55_email, $zhiwu55_ip, $newgroupid, $init_arr, 0);
		$update_member=array();
		$regdate=strtotime($regdatenew);
		$regdate=$regdate-rand(1,3600);
		$update_member['regdate']=$regdate;
		$update_member['emailstatus']=1;
		DB::update('common_member',$update_member,array('uid'=>$uid));
		$update_common_member_status=array();
		$update_common_member_status['lastip']=ip_random();
		$lastvisit=strtotime($lastvisitnew);
		$lastvisit=$lastvisit + rand(1800,3600);
		if($lastvisit>time())
		{
			$lastvisit=time();
		}
		$lastactivity = $lastvisit - rand(1800,3600);
		$update_common_member_status['lastvisit']=$lastvisit;
		$update_common_member_status['lastactivity']=$lastactivity;
		DB::update('common_member_status',$update_common_member_status,array('uid'=>$uid));
		$avatar = zhiwu55_avatar_by_uid($uid, $zhiwu55_img);
		$addUser = array();
		$addUser['uid'] = $uid;
		$addUser['username'] = $zhiwu55_username;
		$addUser['username_pwd'] = $zhiwu55_password;
		$addUser['username_mail'] = $zhiwu55_email;
		DB::insert('zhiwu55cn_reg', $addUser);
		if(stripos($postsnew,'-')!==false)
		{
			$postsnewArr=explode('-',$postsnew);
			$postsnew=rand($postsnewArr[0],$postsnewArr[1]);
		}
		if(stripos($digestpostsnew,'-')!==false)
		{
			$digestpostsnewArr=explode('-',$digestpostsnew);
			$digestpostsnew=rand($digestpostsnewArr[0],$digestpostsnewArr[1]);
		}
		DB::update('common_member_count',array('posts'=>$postsnew,'digestposts'=>$digestpostsnew),array('uid'=>$uid));
		$num--;

	}
	$user_list = DB::fetch_all('select * from %t order by uid desc',array('zhiwu55cn_reg'));
	$totalmembers = C::t('common_member')->count();
	$data = array('totalmembers' => $totalmembers, 'newsetuser' => $zhiwu55_username);
	savecache('userstats', $data);
	$next_reg_url='action=plugins&operation=config&do=' . $pluginid . '&identifier=zhiwu55cn_reg&pmod=bat_reg';
	$next_reg_url=$next_reg_url.'&zhiwu55_agrs=yes&formhash='.FORMHASH.'&newgroupid='.$newgroupid.'&credits='.$credits.'&pws='.$pws.'&postsnew='.$postsnew.'&digestpostsnew='.$digestpostsnew.'&regdatenew='.$regdatenew.'&lastvisitnew='.$lastvisitnew.'&num='.$num;
	$zhiwu55_com_03 = lang('plugin/zhiwu55cn_reg', 'zhiwu55_com_03');
	$zhiwu55_com_03 = str_replace('num',$num,$zhiwu55_com_03);
	cpmsg($zhiwu55_com_03, $next_reg_url, 'loading', '', FALSE);

} else {

	$groupselect = array();
	$query = C::t('common_usergroup')->fetch_all_by_not_groupid(array(5, 6, 7));
	foreach ($query as $group) {
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		if ($group['type'] == 'member' && $group['creditshigher'] == 0) {
			$groupselect[$group['type']].= "<option value=\"$group[groupid]\" selected>$group[grouptitle]</option>\n";
		} else {
			$groupselect[$group['type']].= "<option value=\"$group[groupid]\">$group[grouptitle]</option>\n";
		}
	}
	$groupselect = '<optgroup label="' . $lang['usergroups_member'] . '">' . $groupselect['member'] . '</optgroup>' . ($groupselect['special'] ? '<optgroup label="' . $lang['usergroups_special'] . '">' . $groupselect['special'] . '</optgroup>' : '') . ($groupselect['specialadmin'] ? '<optgroup label="' . $lang['usergroups_specialadmin'] . '">' . $groupselect['specialadmin'] . '</optgroup>' : '') . '<optgroup label="' . $lang['usergroups_system'] . '">' . $groupselect['system'] . '</optgroup>';
	include template('zhiwu55cn_reg:bat_reg');

}