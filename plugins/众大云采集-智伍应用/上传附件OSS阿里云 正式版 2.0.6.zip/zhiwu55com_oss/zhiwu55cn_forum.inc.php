<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$server_url='action=plugins&operation=config&do=' . $pluginid . '&identifier=zhiwu55com_oss&pmod=zhiwu55cn_forum';
if($_GET['formhash'] == FORMHASH && !empty($_GET['zhiwu55_agrs']) && $_GET['zhiwu55_agrs']=='yes')
{
	$del=$_GET['del'];
	if(empty($_GET['aid']) || !is_numeric($_GET['aid']))
	{
		$aid=DB::result_first('SELECT max(aid) FROM %t',array('forum_attachment'));
		$aid++;
		
	} else {
		$aid=$_GET['aid'];
	}
	$imgArr=DB::fetch_all('SELECT * FROM %t WHERE aid<%d AND tableid <> 127 ORDER BY aid DESC LIMIT 10',array('forum_attachment',$aid));
	if(empty($imgArr) || !is_array($imgArr) || $aid<=1)
	{
		cpmsg('zhiwu55com_oss:zhiwu55com_01','',"succeed");

	} else {

		if (!isset($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_oss'];
		if(empty($zhiwu55comConfig['OSS_ACCESS_ID']) || empty($zhiwu55comConfig['OSS_ACCESS_KEY']) || empty($zhiwu55comConfig['OSS_ENDPOINT']) || empty($zhiwu55comConfig['OSS_BUCKET']) || empty($zhiwu55comConfig['attachurl']))
		{
			cpmsg('zhiwu55com_oss:zhiwu55com_02','',"error");
		}
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/MimeTypes.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssException.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssUtil.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore_Exception.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/ResponseCore.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/Result.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/PutSetDeleteResult.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/OssClient.php';
		try {
			$ossClient = new OssClient($zhiwu55comConfig['OSS_ACCESS_ID'],$zhiwu55comConfig['OSS_ACCESS_KEY'],$zhiwu55comConfig['OSS_ENDPOINT']);
		} catch (OssException $e) {
			// echo $e->getMessage();exit;
		}
		$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
		$dir = $dir . 'forum/';
		foreach($imgArr as $imgInfo)
		{
			$img=DB::fetch_first('SELECT * FROM %t WHERE remote=0 AND aid=%d',array('forum_attachment_'.$imgInfo['tableid'],$imgInfo['aid']));
			$threadimage_attachment=DB::result_first('SELECT attachment FROM %t WHERE remote=0 AND tid=%d',array('forum_threadimage',$img['tid']));
			if(is_file($dir.$img['attachment']))
			{
				$fp = @fopen($dir.$img['attachment'],'r');
				$objectContent = @fread($fp,$img['filesize']);
				fclose($fp);
				$objectName = 'forum/'.$img['attachment'];
				$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$objectContent);
				$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
				$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
				$checkPic=dfsockopen($checkPicUrl);
				if(!empty($checkPic) && strlen($checkPic)>50)
				{
					if($del=='yes')
					{	
						unlink($dir.$img['attachment']);
					}
					DB::update('forum_attachment_'.$imgInfo['tableid'],array('remote'=>1),array('aid'=>$img['aid']));
					if($img['attachment']==$threadimage_attachment)
					{
						DB::update('forum_threadimage',array('remote'=>1),array('tid'=>$img['tid']));
					}
					if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>5)
					{
						$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$checkPic);
					}
				}				
			}			
			$threadcover=$dir.'threadcover/'.substr(md5($img['tid']), 0, 2).'/'.substr(md5($img['tid']), 2, 2).'/'.$img['tid'].'.jpg';
			if(is_file($threadcover))
			{
				$fp = @fopen($threadcover,'r');
				$objectContent = @fread($fp,filesize($threadcover));
				fclose($fp);
				$objectName = 'forum/threadcover/'.substr(md5($img['tid']), 0, 2).'/'.substr(md5($img['tid']), 2, 2).'/'.$img['tid'].'.jpg';
				$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$objectContent);
				$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
				$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
				$checkPic=dfsockopen($checkPicUrl);
				if(!empty($checkPic) && strlen($checkPic)>50)
				{
					unlink($threadcover);
					DB::update('forum_thread',array('cover'=>-1),array('tid'=>$img['tid']));
					if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>5)
					{
						$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$checkPic);
					}
				}				
			}			
			
		}
		$next_url=$server_url.'&formhash='.FORMHASH.'&zhiwu55_agrs=yes&aid='.$imgInfo['aid'].'&del='.$del;
		$zhiwu55com_03=lang('plugin/zhiwu55com_oss','zhiwu55com_03');
		$zhiwu55com_03=str_replace('aid',$aid,$zhiwu55com_03);
		cpmsg($zhiwu55com_03, $next_url, 'loading', '', FALSE);

	}

} else {

	$dir = !getglobal('setting/attachurl') ? 'data/attachment/' : getglobal('setting/attachurl');
	$dir = $dir.'forum';
	include template('zhiwu55com_oss:zhiwu55cn_forum');

}