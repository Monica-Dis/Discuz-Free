<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_zhiwu55com_oss {

	public function common()
	{

		global $_G;
		if (!isset($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_oss'];
		if($_GET['mod']!='swfupload' && !empty($zhiwu55comConfig['OSS_ACCESS_ID']) && !empty($zhiwu55comConfig['OSS_ACCESS_KEY']) && !empty($zhiwu55comConfig['OSS_ENDPOINT']) && !empty($zhiwu55comConfig['OSS_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
		{
			$_G['setting']['ftp']['on'] = 1;
			$_G['setting']['ftp']['attachurl'] = $zhiwu55comConfig['attachurl'];
		}

	}
	public function global_footer()
	{
		global $_G,$threadsortshow;
		if (!isset($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_oss'];
		if(!empty($zhiwu55comConfig['OSS_ACCESS_ID']) && !empty($zhiwu55comConfig['OSS_ACCESS_KEY']) && !empty($zhiwu55comConfig['OSS_ENDPOINT']) && !empty($zhiwu55comConfig['OSS_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
		{
			if(!empty($threadsortshow['optionlist']) && is_array($threadsortshow['optionlist']))
			{
				foreach($threadsortshow['optionlist'] as $kk=>$vv)
				{
					if(strtolower($vv['type'])=='image' && strlen($vv['value'])>10 && stripos($vv['value'],'http')===false)
					{
						preg_match('/data\/attachment\/[^"\']+/',$threadsortshow['optionlist'][$kk]['value'],$imgArr);
						if(!file_exists(DISCUZ_ROOT.$imgArr[0]))
						{						
							$threadsortshow['optionlist'][$kk]['value']=preg_replace('/data\/attachment\/([^"]+)/',$zhiwu55comConfig['attachurl'].'$1',$vv['value']);
						}	
					}
				}
			}
			if($zhiwu55comConfig['auto_cut']==1 && !empty($_GET['aid']) && is_numeric($_GET['aid']))
			{

				$uploadOssUrl = $_G['siteurl'] . 'plugin.php?id=zhiwu55com_oss&aid='.$_GET['aid'];
				return '<script src="'.$uploadOssUrl.'" defer="defer"></script>';

			} elseif($zhiwu55comConfig['auto_cut']==1 && !empty($_GET['tid']) && is_numeric($_GET['tid'])) {

				$uploadOssUrl = $_G['siteurl'] . 'plugin.php?id=zhiwu55com_oss&tid='.$_GET['tid'];
				return '<script src="'.$uploadOssUrl.'" defer="defer"></script>';

			} elseif($_GET['do']=='album' && is_numeric($_GET['id'])) {
				
				$uploadOssUrl = $_G['siteurl'] . 'plugin.php?id=zhiwu55com_oss&albumid='.$_GET['id'];
				return '<script src="'.$uploadOssUrl.'" defer="defer"></script>';
				
			} elseif($_GET['do']=='album' && is_numeric($_GET['picid'])) {
				
				$uploadOssUrl = $_G['siteurl'] . 'plugin.php?id=zhiwu55com_oss&picid='.$_GET['picid'];
				return '<script src="'.$uploadOssUrl.'" defer="defer"></script>';
				
			}
		}
	}

}
class plugin_zhiwu55com_oss_forum extends plugin_zhiwu55com_oss {

	public function post_zhiwu55()
	{
		global $_G;
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_oss'];
		if($zhiwu55comConfig['auto_cut']==0 && ((!empty($_GET['attachnew']) && is_array($_GET['attachnew'])) || (!empty($_GET['typeoption']) && is_array($_GET['typeoption']))))
		{
			if (!isset($_G['cache']['plugin'])) {
				loadcache('plugin');
			}			
			if(!empty($zhiwu55comConfig['OSS_ACCESS_ID']) && !empty($zhiwu55comConfig['OSS_ACCESS_KEY']) && !empty($zhiwu55comConfig['OSS_ENDPOINT']) && !empty($zhiwu55comConfig['OSS_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
			{
				$zhiwu55Attach=array();
				$zhiwu55Attach=array_keys($_GET['attachnew']);
				foreach($_GET['typeoption'] as $imgKey=>$imgItem)
				{
					if(is_numeric($imgItem['aid']))
					{
						$zhiwu55Attach[]=$imgItem['aid'];
						$_GET['typeoption'][$imgKey]['url']=str_ireplace('data/attachment/',$zhiwu55comConfig['attachurl'],$_GET['typeoption'][$imgKey]['url']);
					}
				}
				$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
				$dir = $dir . 'forum/';
				$unusedattachs = C::t('forum_attachment_unused')->fetch_all($zhiwu55Attach);
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/MimeTypes.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssException.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssUtil.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore_Exception.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/ResponseCore.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/Result.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/PutSetDeleteResult.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/OssClient.php';
				try {
					$ossClient = new OssClient($zhiwu55comConfig['OSS_ACCESS_ID'],$zhiwu55comConfig['OSS_ACCESS_KEY'],$zhiwu55comConfig['OSS_ENDPOINT']);
				} catch (OssException $e) {
					// echo $e->getMessage();exit;
				}
				foreach($unusedattachs as $attachs)
				{
					try {

						if(is_file($dir.$attachs['attachment']))
						{
							$fp = @fopen($dir.$attachs['attachment'],'r');
							$objectContent = @fread($fp,$attachs['filesize']);
							fclose($fp);
							$objectName = 'forum/'.$attachs['attachment'];
							$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$objectContent);
							$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
							$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
							$checkPic=dfsockopen($checkPicUrl);
							if(!empty($checkPic) && strlen($checkPic)>50)
							{
								unlink($dir.$attachs['attachment']);
								DB::update('forum_attachment_unused',array('remote'=>1),array('aid'=>$attachs['aid']));
								if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>5)
								{
									$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$checkPic);
								}
							}

						}

					} catch (OssException $e) {

						// echo $e->getMessage();exit;

					}
				}
				$_G['setting']['ftp']['on'] = 1;
				$_G['setting']['ftp']['attachurl'] = $zhiwu55comConfig['attachurl'];

			}
			
		} else {
			
			$_G['setting']['ftp']['on'] = 0;
			$_G['setting']['ftp']['attachurl'] = '';
			
		}

	}
	public function ajax_zhiwu55_output()
	{
		global $_G;
		if($_GET['action']!='setthreadcover')
		{
			return '';
		}
		$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
		$dir = $dir . 'forum/';
		$aid = intval($_GET['aid']);
		$threadimage = C::t('forum_attachment_n')->fetch('aid:'.$aid, $aid);
		$tid = $threadimage['tid'];
		$threadcover=$dir.'threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/'.$tid.'.jpg';
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_oss'];
		if(!empty($zhiwu55comConfig['OSS_ACCESS_ID']) && !empty($zhiwu55comConfig['OSS_ACCESS_KEY']) && !empty($zhiwu55comConfig['OSS_ENDPOINT']) && !empty($zhiwu55comConfig['OSS_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
		{

			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/MimeTypes.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssException.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssUtil.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore_Exception.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/ResponseCore.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/Result.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/PutSetDeleteResult.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/OssClient.php';
			try {
				$ossClient = new OssClient($zhiwu55comConfig['OSS_ACCESS_ID'],$zhiwu55comConfig['OSS_ACCESS_KEY'],$zhiwu55comConfig['OSS_ENDPOINT']);
			} catch (OssException $e) {
				// echo $e->getMessage();exit;
			}
			$objectName = 'forum/threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/'.$tid.'.jpg';
			if(!is_file($threadcover))
			{
				sleep(2);
			}
			if(!is_file($threadcover))
			{
				sleep(2);
			}
			if(!is_file($threadcover))
			{
				sleep(2);
			}
			if(is_file($threadcover))
			{
				$fp = @fopen($threadcover,'r');
				$objectContent = @fread($fp,filesize($threadcover));
				fclose($fp);
			}
			$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$objectContent);
			$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
			$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
			$checkPic=dfsockopen($checkPicUrl);
			if(!empty($checkPic) && strlen($checkPic)>50)
			{
				unlink($threadcover);
				DB::update('forum_thread',array('cover'=>-1),array('tid'=>$tid));
			}

		}

	}

}
class plugin_zhiwu55com_oss_group extends plugin_zhiwu55com_oss {

	public function post_zhiwu55()
	{
		global $_G;
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_oss'];
		if($zhiwu55comConfig['auto_cut']==0 && ((!empty($_GET['attachnew']) && is_array($_GET['attachnew'])) || (!empty($_GET['typeoption']) && is_array($_GET['typeoption']))))
		{
			if (!isset($_G['cache']['plugin'])) {
				loadcache('plugin');
			}			
			if(!empty($zhiwu55comConfig['OSS_ACCESS_ID']) && !empty($zhiwu55comConfig['OSS_ACCESS_KEY']) && !empty($zhiwu55comConfig['OSS_ENDPOINT']) && !empty($zhiwu55comConfig['OSS_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
			{
				$zhiwu55Attach=array();
				$zhiwu55Attach=array_keys($_GET['attachnew']);
				foreach($_GET['typeoption'] as $imgKey=>$imgItem)
				{
					if(is_numeric($imgItem['aid']))
					{
						$zhiwu55Attach[]=$imgItem['aid'];
						$_GET['typeoption'][$imgKey]['url']=str_ireplace('data/attachment/',$zhiwu55comConfig['attachurl'],$_GET['typeoption'][$imgKey]['url']);
					}
				}
				$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
				$dir = $dir . 'forum/';
				$unusedattachs = C::t('forum_attachment_unused')->fetch_all($zhiwu55Attach);
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/MimeTypes.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssException.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssUtil.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore_Exception.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/ResponseCore.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/Result.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/PutSetDeleteResult.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/OssClient.php';
				try {
					$ossClient = new OssClient($zhiwu55comConfig['OSS_ACCESS_ID'],$zhiwu55comConfig['OSS_ACCESS_KEY'],$zhiwu55comConfig['OSS_ENDPOINT']);
				} catch (OssException $e) {
					// echo $e->getMessage();exit;
				}
				foreach($unusedattachs as $attachs)
				{
					try {

						if(is_file($dir.$attachs['attachment']))
						{
							$fp = @fopen($dir.$attachs['attachment'],'r');
							$objectContent = @fread($fp,$attachs['filesize']);
							fclose($fp);
							$objectName = 'forum/'.$attachs['attachment'];
							$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$objectContent);
							$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
							$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
							$checkPic=dfsockopen($checkPicUrl);
							if(!empty($checkPic) && strlen($checkPic)>50)
							{
								unlink($dir.$attachs['attachment']);
								DB::update('forum_attachment_unused',array('remote'=>1),array('aid'=>$attachs['aid']));
								if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>5)
								{
									$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$checkPic);
								}
							}

						}

					} catch (OssException $e) {

						// echo $e->getMessage();exit;

					}
				}
				$_G['setting']['ftp']['on'] = 1;
				$_G['setting']['ftp']['attachurl'] = $zhiwu55comConfig['attachurl'];

			}
			
		} else {
			
			$_G['setting']['ftp']['on'] = 0;
			$_G['setting']['ftp']['attachurl'] = '';
			
		}

	}

}
class plugin_zhiwu55com_oss_portal extends plugin_zhiwu55com_oss {

	public function portalcp_zhiwu55()
	{
		global $_G;
		if(!empty($_GET['content']) && strlen($_GET['content'])>5 && !empty($_GET['title']))
		{
			if(!empty($_GET['attach_ids']))
			{
				if(!empty($_GET['conver']))
				{
					$converArr=array();
					$converArr=dunserialize($_GET['conver']);
					$converArr['remote']=1;
					$_GET['conver']=$_POST['conver']=serialize($converArr);
				}
				if (!isset($_G['cache']['plugin'])) {
					loadcache('plugin');
				}
				$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_oss'];
				if(!empty($zhiwu55comConfig['OSS_ACCESS_ID']) && !empty($zhiwu55comConfig['OSS_ACCESS_KEY']) && !empty($zhiwu55comConfig['OSS_ENDPOINT']) && !empty($zhiwu55comConfig['OSS_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
				{
					$zhiwu55Attach=array();
					$zhiwu55Attach=array_keys($_GET['attachnew']);
					$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
					$dir = $dir . 'portal/';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/MimeTypes.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssException.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssUtil.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore_Exception.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/ResponseCore.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/Result.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/PutSetDeleteResult.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/OssClient.php';
					try {
						$ossClient = new OssClient($zhiwu55comConfig['OSS_ACCESS_ID'],$zhiwu55comConfig['OSS_ACCESS_KEY'],$zhiwu55comConfig['OSS_ENDPOINT']);
					} catch (OssException $e) {
						// echo $e->getMessage();exit;
					}
					if(strpos($_GET['attach_ids'],',')===false)
					{
						$unusedattachs = array($_GET['attach_ids']);
					} else {
						$unusedattachs = explode(',',$_GET['attach_ids']);
					}
					foreach($unusedattachs as $attachid)
					{
						$attachid=trim($attachid);
						$attachs = C::t('portal_attachment')->fetch($attachid);
						if(!empty($attachs) && is_array($attachs))
						{
							try {

								if(is_file($dir.$attachs['attachment']))
								{

									$fp = @fopen($dir.$attachs['attachment'],'r');
									$objectContent = @fread($fp,$attachs['filesize']);
									fclose($fp);
									$objectName = 'portal/'.$attachs['attachment'];
									$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$objectContent);
									$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName.'.thumb.jpg',$objectContent);
									$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
									$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
									$checkPic=dfsockopen($checkPicUrl);
									if(!empty($checkPic) && strlen($checkPic)>50)
									{
										unlink($dir.$attachs['attachment']);
										unlink($dir.$attachs['attachment'].'.thumb.jpg');
										C::t('portal_attachment')->update($attachid,array('remote'=>1));
										if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>5)
										{
											$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$checkPic);
										}
									}

								}

							} catch (OssException $e) {

								// echo $e->getMessage();exit;

							}
						}
					}
					$imgDir = !getglobal('setting/attachurl') ? 'data/attachment/' : getglobal('setting/attachurl');
					$_GET['content']=$_POST['content']=str_replace($imgDir,$zhiwu55comConfig['attachurl'],$_GET['content']);
					$_G['setting']['ftp']['on'] = 1;
					$_G['setting']['ftp']['attachurl'] = $zhiwu55comConfig['attachurl'];

				}

			}
		}

	}

}
//From: Dism��taobao-com
?>