<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$server_url='action=plugins&operation=config&do=' . $pluginid . '&identifier=zhiwu55com_oss&pmod=zhiwu55cn_portal';
if($_GET['formhash'] == FORMHASH && !empty($_GET['zhiwu55_agrs']) && $_GET['zhiwu55_agrs']=='yes')
{
	$del=$_GET['del'];
	if(empty($_GET['attachid']) || !is_numeric($_GET['attachid']))
	{
		$attachid=DB::result_first('SELECT max(attachid) FROM %t',array('portal_attachment'));
	} else {
		$attachid=$_GET['attachid'];
	}
	$imgArr=DB::fetch_all('SELECT * FROM %t WHERE attachid<=%d AND remote=0 ORDER BY attachid DESC LIMIT 10',array('portal_attachment',$attachid));
	if(empty($imgArr) || !is_array($imgArr) || $attachid<=1)
	{
		cpmsg('zhiwu55com_oss:zhiwu55com_01','',"succeed");

	} else {

		if (!isset($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_oss'];
		if(empty($zhiwu55comConfig['OSS_ACCESS_ID']) || empty($zhiwu55comConfig['OSS_ACCESS_KEY']) || empty($zhiwu55comConfig['OSS_ENDPOINT']) || empty($zhiwu55comConfig['OSS_BUCKET']) || empty($zhiwu55comConfig['attachurl']))
		{
			cpmsg('zhiwu55com_oss:zhiwu55com_02','',"error");
		}
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/MimeTypes.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssException.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssUtil.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore_Exception.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/ResponseCore.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/Result.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/PutSetDeleteResult.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/OssClient.php';
		try {
			$ossClient = new OssClient($zhiwu55comConfig['OSS_ACCESS_ID'],$zhiwu55comConfig['OSS_ACCESS_KEY'],$zhiwu55comConfig['OSS_ENDPOINT']);
		} catch (OssException $e) {
			// echo $e->getMessage();exit;
		}
		$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
		$dir = $dir . 'portal/';
		foreach($imgArr as $img)
		{
			if(is_file($dir.$img['attachment']))
			{
				$fp = @fopen($dir.$img['attachment'],'r');
				$objectContent = @fread($fp,$img['filesize']);
				fclose($fp);
				$objectName = 'portal/'.$img['attachment'];
				$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$objectContent);
				$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName.'.thumb.jpg',$objectContent);
				$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
				$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
				$checkPic=dfsockopen($checkPicUrl);
				if(!empty($checkPic) && strlen($checkPic)>50)
				{
					if($del=='yes')
					{
						unlink($dir.$img['attachment']);
						unlink($dir.$img['attachment'].'.thumb.jpg');
					}
					DB::update('portal_attachment',array('remote'=>1),array('attachid'=>$img['attachid']));
					$aid=$img['aid'];
					DB::update('portal_article_title',array('remote'=>1),array('aid'=>$aid));
					$imgDir = !getglobal('setting/attachurl') ? 'data/attachment/' : getglobal('setting/attachurl');
					$zhiwu55cn_content=DB::result_first('SELECT content FROM %t WHERE aid=%d',array('portal_article_content',$aid));
					if(stripos($zhiwu55cn_content,$zhiwu55comConfig['attachurl'])===false)
					{
						$zhiwu55cn_content=str_replace($imgDir,$zhiwu55comConfig['attachurl'],$zhiwu55cn_content);
						DB::update('portal_article_content',array('content'=>$zhiwu55cn_content),array('aid'=>$aid));
					}
					if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>5)
					{
						$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$checkPic);
					}
				}				
			}
		}
		$next_url=$server_url.'&formhash='.FORMHASH.'&zhiwu55_agrs=yes&attachid='.$img['attachid'].'&del='.$del;
		$zhiwu55com_04=lang('plugin/zhiwu55com_oss','zhiwu55com_04');
		$zhiwu55com_04=str_replace('attachid',$aid,$zhiwu55com_04);
		cpmsg($zhiwu55com_04, $next_url, 'loading', '', FALSE);

	}

} else {

	$dir = !getglobal('setting/attachurl') ? 'data/attachment/' : getglobal('setting/attachurl');
	$dir = $dir.'portal';
	include template('zhiwu55com_oss:zhiwu55cn_portal');

}