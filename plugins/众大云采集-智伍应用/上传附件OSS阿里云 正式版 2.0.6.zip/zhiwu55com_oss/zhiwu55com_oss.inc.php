<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!isset($_G['cache']['plugin'])) {
	loadcache('plugin');
}
$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_oss'];
if($zhiwu55comConfig['auto_cut']==1 && !empty($zhiwu55comConfig['OSS_ACCESS_ID']) && !empty($zhiwu55comConfig['OSS_ACCESS_KEY']) && !empty($zhiwu55comConfig['OSS_ENDPOINT']) && !empty($zhiwu55comConfig['OSS_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
{

	if(!empty($_GET['tid']) && is_numeric($_GET['tid']))
	{
		$tid=$_GET['tid'];
		$tableid=DB::result_first('SELECT tableid FROM %t WHERE tid=%d',array('forum_attachment',$tid));
		if(is_numeric($tableid))
		{
			$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
			$dir = $dir . 'forum/';
			$tableid='forum_attachment_'.$tableid;
			$imgArr=DB::fetch_all('SELECT * FROM %t WHERE remote=0 AND tid=%d',array($tableid,$tid));
			if(!empty($imgArr) && is_array($imgArr))
			{
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/MimeTypes.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssException.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssUtil.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore_Exception.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/ResponseCore.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/Result.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/PutSetDeleteResult.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/OssClient.php';
				try {
					$ossClient = new OssClient($zhiwu55comConfig['OSS_ACCESS_ID'],$zhiwu55comConfig['OSS_ACCESS_KEY'],$zhiwu55comConfig['OSS_ENDPOINT']);
				} catch (OssException $e) {
					// echo $e->getMessage();exit;
				}
				$threadimage_attachment=DB::result_first('SELECT attachment FROM %t WHERE tid=%d',array('forum_threadimage',$tid));
				foreach($imgArr as $img)
				{
					if(is_file($dir.$img['attachment']))
					{
						$fp = @fopen($dir.$img['attachment'],'r');
						$objectContent = @fread($fp,$img['filesize']);
						fclose($fp);
						$objectName = 'forum/'.$img['attachment'];
						$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$objectContent);
						$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
						$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
						$checkPic=dfsockopen($checkPicUrl);
						if(!empty($checkPic) && strlen($checkPic)>50)
						{
							unlink($dir.$img['attachment']);
							DB::update($tableid,array('remote'=>1),array('aid'=>$img['aid']));
							if($threadimage_attachment==$img['attachment'])
							{
								DB::update('forum_threadimage',array('remote'=>1),array('tid'=>$tid));
							}
							if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>5)
							{
								$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$checkPic);
							}
						}
					}

				}				

			}
			$threadcover=$dir.'threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/'.$tid.'.jpg';
			if(is_file($threadcover))
			{
				$fp = @fopen($threadcover,'r');
				$objectContent = @fread($fp,filesize($threadcover));
				fclose($fp);
				$objectName = 'forum/threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/'.$tid.'.jpg';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/MimeTypes.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssException.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssUtil.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore_Exception.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/ResponseCore.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/Result.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/PutSetDeleteResult.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/OssClient.php';
				try {
					$ossClient = new OssClient($zhiwu55comConfig['OSS_ACCESS_ID'],$zhiwu55comConfig['OSS_ACCESS_KEY'],$zhiwu55comConfig['OSS_ENDPOINT']);
				} catch (OssException $e) {
					// echo $e->getMessage();exit;
				}
				$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$objectContent);
				$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
				$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
				$checkPic=dfsockopen($checkPicUrl);
				if(!empty($checkPic) && strlen($checkPic)>50)
				{
					unlink($threadcover);
					DB::update('forum_thread',array('cover'=>-1),array('tid'=>$tid));
				}
			}

		}

	} elseif(!empty($_GET['aid']) && is_numeric($_GET['aid'])) {

		$aid=$_GET['aid'];
		$imgArr=DB::fetch_all('SELECT * FROM %t WHERE remote=0 AND aid=%d',array('portal_attachment',$aid));
		if(!empty($imgArr) && is_array($imgArr))
		{
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/MimeTypes.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssException.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssUtil.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore_Exception.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/ResponseCore.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/Result.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/PutSetDeleteResult.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/OssClient.php';
			try {
				$ossClient = new OssClient($zhiwu55comConfig['OSS_ACCESS_ID'],$zhiwu55comConfig['OSS_ACCESS_KEY'],$zhiwu55comConfig['OSS_ENDPOINT']);
			} catch (OssException $e) {
				// echo $e->getMessage();exit;
			}
			$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
			$dir = $dir . 'portal/';
			foreach($imgArr as $img)
			{
				if(is_file($dir.$img['attachment']))
				{
					$fp = @fopen($dir.$img['attachment'],'r');
					$objectContent = @fread($fp,$img['filesize']);
					fclose($fp);
					$objectName = 'portal/'.$img['attachment'];
					$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$objectContent);
					$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName.'.thumb.jpg',$objectContent);
					$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
					$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
					$checkPic=dfsockopen($checkPicUrl);
					if(!empty($checkPic) && strlen($checkPic)>50)
					{
						unlink($dir.$img['attachment']);
						unlink($dir.$img['attachment'].'.thumb.jpg');
						DB::update('portal_attachment',array('remote'=>1),array('attachid'=>$img['attachid']));
						if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>5)
						{
							$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$checkPic);
						}
					}
				}

			}
			DB::update('portal_article_title',array('remote'=>1),array('aid'=>$aid));
			$imgDir = !getglobal('setting/attachurl') ? 'data/attachment/' : getglobal('setting/attachurl');
			$zhiwu55cn_content=DB::result_first('SELECT content FROM %t WHERE aid=%d',array('portal_article_content',$aid));
			$zhiwu55cn_content=str_replace($imgDir,$zhiwu55comConfig['attachurl'],$zhiwu55cn_content);
			DB::update('portal_article_content',array('content'=>$zhiwu55cn_content),array('aid'=>$aid));

		}

	} elseif(is_numeric($_GET['albumid']) || is_numeric($_GET['picid'])) {

		if(is_numeric($_GET['picid']))
		{
			$albumid=DB::result_first('SELECT albumid FROM %t WHERE remote=0 AND picid=%d',array('home_pic',$_GET['picid']));
			
		} else {
			
			$albumid=$_GET['albumid'];
			
		}
		if(is_numeric($albumid))
		{
			$imgArr=DB::fetch_all('SELECT * FROM %t WHERE remote=0 AND albumid=%d',array('home_pic',$albumid));
			if(!empty($imgArr) && is_array($imgArr))
			{
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/MimeTypes.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssException.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssUtil.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore_Exception.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/ResponseCore.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/Result.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/PutSetDeleteResult.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/OssClient.php';
				try {
					$ossClient = new OssClient($zhiwu55comConfig['OSS_ACCESS_ID'],$zhiwu55comConfig['OSS_ACCESS_KEY'],$zhiwu55comConfig['OSS_ENDPOINT']);
				} catch (OssException $e) {
					// echo $e->getMessage();exit;
				}
				$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
				$dir = $dir . 'album/';
				foreach($imgArr as $img)
				{
					if(is_file($dir.$img['filepath']))
					{
						$fp = @fopen($dir.$img['filepath'],'r');
						$objectContent = @fread($fp,$img['size']);
						fclose($fp);
						$objectName = 'album/'.$img['filepath'];
						$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$objectContent);
						$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName.'.thumb.jpg',$objectContent);
						$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
						$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
						$checkPic=dfsockopen($checkPicUrl);
						if(!empty($checkPic) && strlen($checkPic)>50)
						{
							unlink($dir.$img['filepath']);
							unlink($dir.$img['filepath'].'.thumb.jpg');
							DB::update('home_pic',array('remote'=>1),array('picid'=>$img['picid']));
							if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>5)
							{
								$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$checkPic);
							}
						}
					}

				}

			}
		}

	}

}
echo 'try { if (window.console && window.console.log) { console.log("%c\u6b64\u6a21\u5757\u5e94\u7528\u7684\u5f00\u53d1\u8005\u662f\u667a\u4f0d\u5e94\u7528\uff1a\x77\x77\x77.\x7a\x68\x69\x77\x75\x35\x35.\x63\x6f\x6d", "line-height:160px;font-size:24px;color:red"); } } catch (e) {}';