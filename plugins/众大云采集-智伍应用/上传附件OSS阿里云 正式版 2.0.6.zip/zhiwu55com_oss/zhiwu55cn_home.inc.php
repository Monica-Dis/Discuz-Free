<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$server_url='action=plugins&operation=config&do=' . $pluginid . '&identifier=zhiwu55com_oss&pmod=zhiwu55cn_home';
if($_GET['formhash'] == FORMHASH && !empty($_GET['zhiwu55_agrs']) && $_GET['zhiwu55_agrs']=='yes')
{
	$del=$_GET['del'];
	if(empty($_GET['picid']) || !is_numeric($_GET['picid']))
	{
		$picid=DB::result_first('SELECT max(picid) FROM %t',array('home_pic'));
		$picid++;
	} else {
		$picid=$_GET['picid'];
	}
	$imgArr=DB::fetch_all('SELECT * FROM %t WHERE picid<%d AND remote=0 ORDER BY picid DESC LIMIT 10',array('home_pic',$picid));
	if(empty($imgArr) || !is_array($imgArr) || $picid<=1)
	{
		cpmsg('zhiwu55com_oss:zhiwu55com_01','',"succeed");

	} else {

		if (!isset($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_oss'];
		if(empty($zhiwu55comConfig['OSS_ACCESS_ID']) || empty($zhiwu55comConfig['OSS_ACCESS_KEY']) || empty($zhiwu55comConfig['OSS_ENDPOINT']) || empty($zhiwu55comConfig['OSS_BUCKET']) || empty($zhiwu55comConfig['attachurl']))
		{
			cpmsg('zhiwu55com_oss:zhiwu55com_02','',"error");
		}
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/MimeTypes.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssException.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Core/OssUtil.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/RequestCore_Exception.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Http/ResponseCore.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/Result.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/Result/PutSetDeleteResult.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_oss/OSS/OssClient.php';
		try {
			$ossClient = new OssClient($zhiwu55comConfig['OSS_ACCESS_ID'],$zhiwu55comConfig['OSS_ACCESS_KEY'],$zhiwu55comConfig['OSS_ENDPOINT']);
		} catch (OssException $e) {
			// echo $e->getMessage();exit;
		}
		$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
		$dir = $dir . 'album/';
		foreach($imgArr as $img)
		{
			if(is_file($dir.$img['filepath']))
			{
				$fp = @fopen($dir.$img['filepath'],'r');
				$objectContent = @fread($fp,$img['size']);
				fclose($fp);
				$objectName = 'album/'.$img['filepath'];
				$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$objectContent);
				$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName.'.thumb.jpg',$objectContent);
				$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
				$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
				$checkPic=dfsockopen($checkPicUrl);
				if(!empty($checkPic) && strlen($checkPic)>50)
				{
					if($del=='yes')
					{
						unlink($dir.$img['filepath']);
						unlink($dir.$img['filepath'].'.thumb.jpg');
					}
					DB::update('home_pic',array('remote'=>1),array('picid'=>$img['picid']));					
					if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>5)
					{
						$ossClient->putObject($zhiwu55comConfig['OSS_BUCKET'],$objectName,$checkPic);
					}
				}				
			}
		}
		$next_url=$server_url.'&formhash='.FORMHASH.'&zhiwu55_agrs=yes&picid='.$img['picid'].'&del='.$del;
		$zhiwu55com_05=lang('plugin/zhiwu55com_oss','zhiwu55com_05');
		$zhiwu55com_05=str_replace('picid',$picid,$zhiwu55com_05);
		cpmsg($zhiwu55com_05, $next_url, 'loading', '', FALSE);

	}

} else {

	$dir = !getglobal('setting/attachurl') ? 'data/attachment/' : getglobal('setting/attachurl');
	$dir = $dir.'album';
	include template('zhiwu55com_oss:zhiwu55cn_home');

}