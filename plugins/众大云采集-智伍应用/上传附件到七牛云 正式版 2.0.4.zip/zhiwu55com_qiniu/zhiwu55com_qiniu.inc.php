<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!isset($_G['cache']['plugin'])) {
	loadcache('plugin');
}
$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_qiniu'];
if($zhiwu55comConfig['auto_cut']==1 && !empty($zhiwu55comConfig['qiniu_ACCESS_ID']) && !empty($zhiwu55comConfig['qiniu_ACCESS_KEY']) && !empty($zhiwu55comConfig['qiniu_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
{

	if(!empty($_GET['tid']) && is_numeric($_GET['tid']))
	{
		$tid=$_GET['tid'];
		$tableid=DB::result_first('SELECT tableid FROM %t WHERE tid=%d',array('forum_attachment',$tid));
		if(is_numeric($tableid))
		{
			$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
			$dir = $dir . 'forum/';
			$tableid='forum_attachment_'.$tableid;
			$imgArr=DB::fetch_all('SELECT * FROM %t WHERE remote=0 AND tid=%d',array($tableid,$tid));
			if(!empty($imgArr) && is_array($imgArr))
			{
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Response.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Request.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Client.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Region.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Zone.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/FormUploader.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/UploadManager.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/ResumeUploader.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Auth.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Config.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/functions.php';
				$accessKey = $zhiwu55comConfig['qiniu_ACCESS_ID'];
				$secretKey = $zhiwu55comConfig['qiniu_ACCESS_KEY'];
				$bucket = $zhiwu55comConfig['qiniu_BUCKET'];
				$auth = new \Qiniu\Auth($accessKey, $secretKey);
				$uploadMgr = new \Qiniu\Storage\UploadManager();
				foreach($imgArr as $img)
				{
					if(is_file($dir.$img['attachment']))
					{
						$objectName = 'forum/'.$img['attachment'];
						$token = $auth->uploadToken($bucket,$objectName);
						$aa=$uploadMgr->putFile($token, $objectName, $dir.$img['attachment']);
						$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
						$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
						$checkPic=dfsockopen($checkPicUrl);
						if(!empty($checkPic) && strlen($checkPic)>50)
						{
							unlink($dir.$img['attachment']);
							DB::update($tableid,array('remote'=>1),array('aid'=>$img['aid']));
							if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>1)
							{
								$uploadMgr->put($token, $objectName, $checkPic);
							}
						}
					}

				}
				$threadimage_attachment=DB::result_first('SELECT attachment FROM %t WHERE tid=%d',array('forum_threadimage',$tid));
				if(is_file($dir.$threadimage_attachment))
				{
					$objectName = 'forum/'.$threadimage_attachment;
					$token2 = $auth->uploadToken($bucket,$objectName);
					$uploadMgr->putFile($token2, $objectName, $dir.$threadimage_attachment);
					$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
					$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
					$checkPic=dfsockopen($checkPicUrl);
					if(!empty($checkPic) && strlen($checkPic)>50)
					{
						unlink($dir.$threadimage_attachment);
						DB::update('forum_threadimage',array('remote'=>1),array('tid'=>$tid));
						if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>1)
						{
							$uploadMgr->put($token2, $objectName, $checkPic);
						}
					}
				}

			}
			$threadcover=$dir.'threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/'.$tid.'.jpg';
			if(is_file($threadcover))
			{
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Response.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Request.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Client.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Region.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Zone.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/FormUploader.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/UploadManager.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/ResumeUploader.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Auth.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Config.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/functions.php';
				$accessKey = $zhiwu55comConfig['qiniu_ACCESS_ID'];
				$secretKey = $zhiwu55comConfig['qiniu_ACCESS_KEY'];
				$bucket = $zhiwu55comConfig['qiniu_BUCKET'];
				$auth = new \Qiniu\Auth($accessKey, $secretKey);
				$uploadMgr = new \Qiniu\Storage\UploadManager();				
				$objectName = 'forum/threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/'.$tid.'.jpg';
				$token3 = $auth->uploadToken($bucket,$objectName);
				$uploadMgr->putFile($token3, $objectName, $threadcover);
				$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName;
				$checkPic=dfsockopen($checkPicUrl);
				if(!empty($checkPic) && strlen($checkPic)>50)
				{
					unlink($threadcover);
					DB::update('forum_thread',array('cover'=>-1),array('tid'=>$tid));
				}
			}

		}

	} elseif(!empty($_GET['aid']) && is_numeric($_GET['aid'])) {

		$aid=$_GET['aid'];
		$imgArr=DB::fetch_all('SELECT * FROM %t WHERE remote=0 AND aid=%d',array('portal_attachment',$aid));
		if(!empty($imgArr) && is_array($imgArr))
		{
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Response.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Request.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Client.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Region.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Zone.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/FormUploader.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/UploadManager.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/ResumeUploader.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Auth.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Config.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/functions.php';
			$accessKey = $zhiwu55comConfig['qiniu_ACCESS_ID'];
			$secretKey = $zhiwu55comConfig['qiniu_ACCESS_KEY'];
			$bucket = $zhiwu55comConfig['qiniu_BUCKET'];
			$auth = new \Qiniu\Auth($accessKey, $secretKey);				
			$uploadMgr = new \Qiniu\Storage\UploadManager();				
			$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
			$dir = $dir . 'portal/';
			foreach($imgArr as $img)
			{
				if(is_file($dir.$img['attachment']))
				{
					$objectName = 'portal/'.$img['attachment'];
					$token4 = $auth->uploadToken($bucket,$objectName);
					$uploadMgr->putFile($token4, $objectName, $dir.$img['attachment']);
					$token5 = $auth->uploadToken($bucket,$objectName.'.thumb.jpg');
					$uploadMgr->putFile($token5, $objectName.'.thumb.jpg', $dir.$img['attachment']);						
					$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
					$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
					$checkPic=dfsockopen($checkPicUrl);
					if(!empty($checkPic) && strlen($checkPic)>50)
					{
						unlink($dir.$img['attachment']);
						unlink($dir.$img['attachment'].'.thumb.jpg');
						DB::update('portal_attachment',array('remote'=>1),array('attachid'=>$img['attachid']));
						if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>1)
						{
							$uploadMgr->put($token4, $objectName, $checkPic);
						}
					}
				}

			}
			DB::update('portal_article_title',array('remote'=>1),array('aid'=>$aid));
			$imgDir = !getglobal('setting/attachurl') ? 'data/attachment/' : getglobal('setting/attachurl');
			$zhiwu55cn_content=DB::result_first('SELECT content FROM %t WHERE aid=%d',array('portal_article_content',$aid));
			$zhiwu55cn_content=str_replace($imgDir,$zhiwu55comConfig['attachurl'],$zhiwu55cn_content);
			DB::update('portal_article_content',array('content'=>$zhiwu55cn_content),array('aid'=>$aid));

		}


	}

}
echo 'try { if (window.console && window.console.log) { console.log("%c\u6b64\u6a21\u5757\u5e94\u7528\u7684\u5f00\u53d1\u8005\u662f\u667a\u4f0d\u5e94\u7528\uff1a\x77\x77\x77.\x7a\x68\x69\x77\x75\x35\x35.\x63\x6f\x6d", "line-height:160px;font-size:24px;color:red"); } } catch (e) {}';