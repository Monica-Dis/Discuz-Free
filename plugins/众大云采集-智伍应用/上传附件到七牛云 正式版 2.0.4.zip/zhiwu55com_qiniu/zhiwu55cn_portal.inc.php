<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$server_url='action=plugins&operation=config&do=' . $pluginid . '&identifier=zhiwu55com_qiniu&pmod=zhiwu55cn_portal';
if($_GET['formhash'] == FORMHASH && !empty($_GET['zhiwu55_agrs']) && $_GET['zhiwu55_agrs']=='yes')
{
	$del=$_GET['del'];
	if(empty($_GET['attachid']) || !is_numeric($_GET['attachid']))
	{
		$attachid=DB::result_first('SELECT max(attachid) FROM %t',array('portal_attachment'));
		$attachid++;
	} else {
		$attachid=$_GET['attachid'];
	}
	$imgArr=DB::fetch_all('SELECT * FROM %t WHERE attachid<%d AND remote=0 ORDER BY attachid DESC LIMIT 10',array('portal_attachment',$attachid));
	if(empty($imgArr) || !is_array($imgArr) || $attachid<=1)
	{
		cpmsg('zhiwu55com_qiniu:zhiwu55com_01','',"succeed");

	} else {

		if (!isset($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_qiniu'];
		if(empty($zhiwu55comConfig['qiniu_ACCESS_ID']) || empty($zhiwu55comConfig['qiniu_ACCESS_KEY']) || empty($zhiwu55comConfig['qiniu_BUCKET']) || empty($zhiwu55comConfig['attachurl']))
		{
			cpmsg('zhiwu55com_qiniu:zhiwu55com_02','',"error");
		}
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Response.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Request.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Client.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Region.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Zone.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/FormUploader.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/UploadManager.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/ResumeUploader.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Auth.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Config.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/functions.php';
		$accessKey = $zhiwu55comConfig['qiniu_ACCESS_ID'];
		$secretKey = $zhiwu55comConfig['qiniu_ACCESS_KEY'];
		$bucket = $zhiwu55comConfig['qiniu_BUCKET'];
		$auth = new \Qiniu\Auth($accessKey, $secretKey);
		$uploadMgr = new \Qiniu\Storage\UploadManager();
		$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
		$dir = $dir . 'portal/';
		foreach($imgArr as $img)
		{
			if(is_file($dir.$img['attachment']))
			{
				$objectName = 'portal/'.$img['attachment'];
				$token = $auth->uploadToken($bucket,$objectName);
				$uploadMgr->putFile($token, $objectName, $dir.$img['attachment']);
				$token2 = $auth->uploadToken($bucket,$objectName.'.thumb.jpg');
				$uploadMgr->putFile($token2, $objectName.'.thumb.jpg', $dir.$img['attachment']);
				$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
				$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
				$checkPic=dfsockopen($checkPicUrl);
				if(!empty($checkPic) && strlen($checkPic)>50)
				{
					if($del=='yes')
					{
						unlink($dir.$img['attachment']);
						unlink($dir.$img['attachment'].'.thumb.jpg');
					}
					DB::update('portal_attachment',array('remote'=>1),array('attachid'=>$img['attachid']));
					$aid=$img['aid'];
					DB::update('portal_article_title',array('remote'=>1),array('aid'=>$aid));
					$imgDir = !getglobal('setting/attachurl') ? 'data/attachment/' : getglobal('setting/attachurl');
					$zhiwu55cn_content=DB::result_first('SELECT content FROM %t WHERE aid=%d',array('portal_article_content',$aid));
					if(stripos($zhiwu55cn_content,$zhiwu55comConfig['attachurl'])===false)
					{
						$zhiwu55cn_content=str_replace($imgDir,$zhiwu55comConfig['attachurl'],$zhiwu55cn_content);
						DB::update('portal_article_content',array('content'=>$zhiwu55cn_content),array('aid'=>$aid));
					}
					if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>1)
					{
						$uploadMgr->put($token, $objectName, $checkPic);
					}
				}
			}
		}
		$next_url=$server_url.'&formhash='.FORMHASH.'&zhiwu55_agrs=yes&attachid='.$img['attachid'].'&del='.$del;
		$zhiwu55com_04=lang('plugin/zhiwu55com_qiniu','zhiwu55com_04');
		$zhiwu55com_04=str_replace('attachid',$aid,$zhiwu55com_04);
		cpmsg($zhiwu55com_04, $next_url, 'loading', '', FALSE);

	}

} else {

	$dir = !getglobal('setting/attachurl') ? 'data/attachment/' : getglobal('setting/attachurl');
	$dir = $dir.'portal';
	include template('zhiwu55com_qiniu:zhiwu55cn_portal');

}