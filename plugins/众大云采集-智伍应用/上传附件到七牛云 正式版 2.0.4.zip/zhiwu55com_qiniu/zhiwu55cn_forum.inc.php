<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$server_url='action=plugins&operation=config&do=' . $pluginid . '&identifier=zhiwu55com_qiniu&pmod=zhiwu55cn_forum';
if($_GET['formhash'] == FORMHASH && !empty($_GET['zhiwu55_agrs']) && $_GET['zhiwu55_agrs']=='yes')
{
	$del=$_GET['del'];
	if(empty($_GET['aid']) || !is_numeric($_GET['aid']))
	{
		$aid=DB::result_first('SELECT max(aid) FROM %t',array('forum_attachment'));
		$aid++;
	} else {
		$aid=$_GET['aid'];
	}
	$imgArr=DB::fetch_all('SELECT * FROM %t WHERE aid<%d AND tableid <> 127 ORDER BY aid DESC LIMIT 1',array('forum_attachment',$aid));
	if(empty($imgArr) || !is_array($imgArr) || $aid<=1)
	{
		cpmsg('zhiwu55com_qiniu:zhiwu55com_01','',"succeed");

	} else {

		if (!isset($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_qiniu'];
		if(empty($zhiwu55comConfig['qiniu_ACCESS_ID']) || empty($zhiwu55comConfig['qiniu_ACCESS_KEY']) || empty($zhiwu55comConfig['qiniu_BUCKET']) || empty($zhiwu55comConfig['attachurl']))
		{
			cpmsg('zhiwu55com_qiniu:zhiwu55com_02','',"error");
		}
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Response.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Request.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Client.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Region.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Zone.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/FormUploader.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/UploadManager.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/ResumeUploader.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Auth.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Config.php';
		require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/functions.php';
		$accessKey = $zhiwu55comConfig['qiniu_ACCESS_ID'];
		$secretKey = $zhiwu55comConfig['qiniu_ACCESS_KEY'];
		$bucket = $zhiwu55comConfig['qiniu_BUCKET'];
		$auth = new \Qiniu\Auth($accessKey, $secretKey);
		$uploadMgr = new \Qiniu\Storage\UploadManager();
		$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
		$dir = $dir . 'forum/';
		foreach($imgArr as $imgInfo)
		{
			$img=DB::fetch_first('SELECT * FROM %t WHERE remote=0 AND aid=%d',array('forum_attachment_'.$imgInfo['tableid'],$imgInfo['aid']));
			if(is_file($dir.$img['attachment']))
			{
				$objectName = 'forum/'.$img['attachment'];
				$token = $auth->uploadToken($bucket,$objectName);
				$uploadMgr->putFile($token, $objectName, $dir.$img['attachment']);
				$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
				$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
				$checkPic=dfsockopen($checkPicUrl);
				if(!empty($checkPic) && strlen($checkPic)>50)
				{
					if($del=='yes')
					{
						unlink($dir.$img['attachment']);
					}
					DB::update('forum_attachment_'.$imgInfo['tableid'],array('remote'=>1),array('aid'=>$img['aid']));
					if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>1)
					{
						$uploadMgr->put($token, $objectName, $checkPic);
					}
				}
			}
			$threadimage_attachment=DB::result_first('SELECT attachment FROM %t WHERE remote=0 AND tid=%d',array('forum_threadimage',$img['tid']));
			if(is_file($dir.$threadimage_attachment))
			{
				$objectName = 'forum/'.$threadimage_attachment;
				$token = $auth->uploadToken($bucket,$objectName);
				$uploadMgr->putFile($token, $objectName, $dir.$threadimage_attachment);
				$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
				$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
				$checkPic=dfsockopen($checkPicUrl);
				if(!empty($checkPic) && strlen($checkPic)>50)
				{
					if($del=='yes')
					{
						unlink($dir.$threadimage_attachment);
					}
					DB::update('forum_threadimage',array('remote'=>1),array('tid'=>$img['tid']));
					if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>1)
					{
						$uploadMgr->put($token, $objectName, $checkPic);
					}
				}
			}
			$threadcover=$dir.'threadcover/'.substr(md5($img['tid']), 0, 2).'/'.substr(md5($img['tid']), 2, 2).'/'.$img['tid'].'.jpg';
			if(is_file($threadcover))
			{
				$objectName = 'forum/threadcover/'.substr(md5($img['tid']), 0, 2).'/'.substr(md5($img['tid']), 2, 2).'/'.$img['tid'].'.jpg';
				$token = $auth->uploadToken($bucket,$objectName);
				$uploadMgr->putFile($token, $objectName, $threadcover);
				$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
				$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
				$checkPic=dfsockopen($checkPicUrl);
				if(!empty($checkPic) && strlen($checkPic)>50)
				{
					unlink($threadcover);
					DB::update('forum_thread',array('cover'=>-1),array('tid'=>$img['tid']));
				}
			}

		}
		$next_url=$server_url.'&formhash='.FORMHASH.'&zhiwu55_agrs=yes&aid='.$imgInfo['aid'].'&del='.$del;
		$zhiwu55com_03=lang('plugin/zhiwu55com_qiniu','zhiwu55com_03');
		$zhiwu55com_03=str_replace('aid',$aid,$zhiwu55com_03);
		cpmsg($zhiwu55com_03, $next_url, 'loading', '', FALSE);

	}

} else {

	$dir = !getglobal('setting/attachurl') ? 'data/attachment/' : getglobal('setting/attachurl');
	$dir = $dir.'forum';
	include template('zhiwu55com_qiniu:zhiwu55cn_forum');

}