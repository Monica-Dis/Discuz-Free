<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_zhiwu55com_qiniu {

	public function common()
	{

		global $_G;
		if (!isset($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_qiniu'];
		if($_GET['mod']!='swfupload' && $_GET['ac']!='upload' && $_GET['ac']!='article' && $_GET['op']!='downremotefile' && $_GET['id']!='csdn123_news:front_control' && !empty($zhiwu55comConfig['qiniu_ACCESS_ID']) && !empty($zhiwu55comConfig['qiniu_ACCESS_KEY']) && !empty($zhiwu55comConfig['qiniu_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
		{
			$_G['setting']['ftp']['on'] = 1;
			$_G['setting']['ftp']['attachurl'] = $zhiwu55comConfig['attachurl'];
		}

	}
	public function global_footer()
	{
		global $_G;
		if (!isset($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_qiniu'];
		if($zhiwu55comConfig['auto_cut']==1 && !empty($_GET['aid']) && is_numeric($_GET['aid']))
		{

			$uploadqiniuUrl = $_G['siteurl'] . 'plugin.php?id=zhiwu55com_qiniu&aid='.$_GET['aid'];
			return '<script src="'.$uploadqiniuUrl.'" defer="defer"></script>';

		} elseif($zhiwu55comConfig['auto_cut']==1 && !empty($_GET['tid']) && is_numeric($_GET['tid'])) {

			$uploadqiniuUrl = $_G['siteurl'] . 'plugin.php?id=zhiwu55com_qiniu&tid='.$_GET['tid'];
			return '<script src="'.$uploadqiniuUrl.'" defer="defer"></script>';

		}
	}

}
class plugin_zhiwu55com_qiniu_forum extends plugin_zhiwu55com_qiniu {

	public function post_zhiwu55()
	{
		global $_G;
		if(!empty($_GET['attachnew']) && is_array($_GET['attachnew']))
		{
			if (!isset($_G['cache']['plugin'])) {
				loadcache('plugin');
			}
			$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_qiniu'];
			if(!empty($zhiwu55comConfig['qiniu_ACCESS_ID']) && !empty($zhiwu55comConfig['qiniu_ACCESS_KEY']) && !empty($zhiwu55comConfig['qiniu_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
			{
				$zhiwu55Attach=array();
				$zhiwu55Attach=array_keys($_GET['attachnew']);
				$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
				$dir = $dir . 'forum/';
				$unusedattachs = C::t('forum_attachment_unused')->fetch_all($zhiwu55Attach);
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Response.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Request.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Client.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Region.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Zone.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/FormUploader.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/UploadManager.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/ResumeUploader.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Auth.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Config.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/functions.php';
				$accessKey = $zhiwu55comConfig['qiniu_ACCESS_ID'];
				$secretKey = $zhiwu55comConfig['qiniu_ACCESS_KEY'];
				$bucket = $zhiwu55comConfig['qiniu_BUCKET'];
				$auth = new \Qiniu\Auth($accessKey, $secretKey);
				$uploadMgr = new \Qiniu\Storage\UploadManager();
				foreach($unusedattachs as $attachs)
				{
					if(is_file($dir.$attachs['attachment']))
					{
						$objectName = 'forum/'.$attachs['attachment'];
						$token = $auth->uploadToken($bucket,$objectName);
						$uploadMgr->putFile($token, $objectName, $dir.$attachs['attachment']);
						$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
						$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
						$checkPic=dfsockopen($checkPicUrl);
						if(!empty($checkPic) && strlen($checkPic)>50)
						{
							unlink($dir.$attachs['attachment']);
							DB::update('forum_attachment_unused',array('remote'=>1),array('aid'=>$attachs['aid']));
							if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>1)
							{
								$uploadMgr->put($token, $objectName, $checkPic);
							}
						}

					}
				}
				$_G['setting']['ftp']['on'] = 1;
				$_G['setting']['ftp']['attachurl'] = $zhiwu55comConfig['attachurl'];

			}
		}

	}
	public function ajax_zhiwu55_output()
	{
		global $_G;
		if($_GET['action']!='setthreadcover')
		{
			return '';
		}
		$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
		$dir = $dir . 'forum/';
		$aid = intval($_GET['aid']);
		$threadimage = C::t('forum_attachment_n')->fetch('aid:'.$aid, $aid);
		$tid = $threadimage['tid'];
		$threadcover=$dir.'threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/'.$tid.'.jpg';
		$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_qiniu'];
		if(!empty($zhiwu55comConfig['qiniu_ACCESS_ID']) && !empty($zhiwu55comConfig['qiniu_ACCESS_KEY']) && !empty($zhiwu55comConfig['qiniu_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
		{
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Response.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Request.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Client.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Error.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Region.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Zone.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/FormUploader.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/UploadManager.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/ResumeUploader.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Auth.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Config.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/functions.php';
			require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Cdn/CdnManager.php';
			$accessKey = $zhiwu55comConfig['qiniu_ACCESS_ID'];
			$secretKey = $zhiwu55comConfig['qiniu_ACCESS_KEY'];
			$bucket = $zhiwu55comConfig['qiniu_BUCKET'];
			$auth = new \Qiniu\Auth($accessKey, $secretKey);
			$cdnManager = new \Qiniu\Cdn\CdnManager($auth);
			$uploadMgr = new \Qiniu\Storage\UploadManager();
			$objectName = 'forum/threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/'.$tid.'.jpg';
			if(!is_file($threadcover))
			{
				sleep(2);
			}
			if(!is_file($threadcover))
			{
				sleep(2);
			}
			if(!is_file($threadcover))
			{
				sleep(2);
			}
			if(is_file($threadcover))
			{
				$token = $auth->uploadToken($bucket,$objectName,3600,null,true);
				$uploadMgr->putFile($token, $objectName, $threadcover);
				$cdnManager->refreshUrls(array($zhiwu55comConfig['attachurl'].$objectName));
				$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName;
				$checkPic=dfsockopen($checkPicUrl);
				if(!empty($checkPic) && strlen($checkPic)>50)
				{
					unlink($threadcover);
					DB::update('forum_thread',array('cover'=>-1),array('tid'=>$tid));
				}
			}

		}

	}

}
class plugin_zhiwu55com_qiniu_group extends plugin_zhiwu55com_qiniu {

	public function post_zhiwu55()
	{
		global $_G;
		if(!empty($_GET['attachnew']) && is_array($_GET['attachnew']))
		{

			if (!isset($_G['cache']['plugin'])) {
				loadcache('plugin');
			}
			$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_qiniu'];
			if(!empty($zhiwu55comConfig['qiniu_ACCESS_ID']) && !empty($zhiwu55comConfig['qiniu_ACCESS_KEY']) && !empty($zhiwu55comConfig['qiniu_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
			{
				$zhiwu55Attach=array();
				$zhiwu55Attach=array_keys($_GET['attachnew']);
				$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
				$dir = $dir . 'forum/';
				$unusedattachs = C::t('forum_attachment_unused')->fetch_all($zhiwu55Attach);
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Response.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Request.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Client.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Region.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Zone.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/FormUploader.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/UploadManager.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/ResumeUploader.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Auth.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Config.php';
				require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/functions.php';
				$accessKey = $zhiwu55comConfig['qiniu_ACCESS_ID'];
				$secretKey = $zhiwu55comConfig['qiniu_ACCESS_KEY'];
				$bucket = $zhiwu55comConfig['qiniu_BUCKET'];
				$auth = new \Qiniu\Auth($accessKey, $secretKey);
				$uploadMgr = new \Qiniu\Storage\UploadManager();
				foreach($unusedattachs as $attachs)
				{

					if(is_file($dir.$attachs['attachment']))
					{
						$objectName = 'forum/'.$attachs['attachment'];
						$token = $auth->uploadToken($bucket,$objectName);
						$uploadMgr->putFile($token, $objectName, $dir.$attachs['attachment']);
						$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
						$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
						$checkPic=dfsockopen($checkPicUrl);
						if(!empty($checkPic) && strlen($checkPic)>50)
						{
							unlink($dir.$attachs['attachment']);
							DB::update('forum_attachment_unused',array('remote'=>1),array('aid'=>$attachs['aid']));
							if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>1)
							{
								$uploadMgr->put($token, $objectName, $checkPic);
							}
						}
					}

				}
				$_G['setting']['ftp']['on'] = 1;
				$_G['setting']['ftp']['attachurl'] = $zhiwu55comConfig['attachurl'];

			}

		}

	}

}
class plugin_zhiwu55com_qiniu_portal extends plugin_zhiwu55com_qiniu {

	public function portalcp_zhiwu55()
	{
		global $_G;
		if(!empty($_GET['content']) && strlen($_GET['content'])>5 && !empty($_GET['title']))
		{
			if(!empty($_GET['attach_ids']))
			{
				if(!empty($_GET['conver']))
				{
					$converArr=array();
					$converArr=dunserialize($_GET['conver']);
					$converArr['remote']=1;
					$_GET['conver']=$_POST['conver']=serialize($converArr);
				}
				if (!isset($_G['cache']['plugin'])) {
					loadcache('plugin');
				}
				$zhiwu55comConfig=$_G['cache']['plugin']['zhiwu55com_qiniu'];
				if(!empty($zhiwu55comConfig['qiniu_ACCESS_ID']) && !empty($zhiwu55comConfig['qiniu_ACCESS_KEY']) && !empty($zhiwu55comConfig['qiniu_BUCKET']) && !empty($zhiwu55comConfig['attachurl']))
				{
					$zhiwu55Attach=array();
					$zhiwu55Attach=array_keys($_GET['attachnew']);
					$dir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT . './data/attachment/') : getglobal('setting/attachdir');
					$dir = $dir . 'portal/';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Response.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Request.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Http/Client.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Region.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Zone.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/FormUploader.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/UploadManager.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Storage/ResumeUploader.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Auth.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/Config.php';
					require_once DISCUZ_ROOT.'source/plugin/zhiwu55com_qiniu/src/functions.php';
					$accessKey = $zhiwu55comConfig['qiniu_ACCESS_ID'];
					$secretKey = $zhiwu55comConfig['qiniu_ACCESS_KEY'];
					$bucket = $zhiwu55comConfig['qiniu_BUCKET'];
					$auth = new \Qiniu\Auth($accessKey, $secretKey);
					$uploadMgr = new \Qiniu\Storage\UploadManager();
					if(strpos($_GET['attach_ids'],',')===false)
					{
						$unusedattachs = array($_GET['attach_ids']);
					} else {
						$unusedattachs = explode(',',$_GET['attach_ids']);
					}
					foreach($unusedattachs as $attachid)
					{
						$attachid=trim($attachid);
						$attachs = C::t('portal_attachment')->fetch($attachid);
						if(!empty($attachs) && is_array($attachs))
						{

							if(is_file($dir.$attachs['attachment']))
							{

								$objectName = 'portal/'.$attachs['attachment'];
								$token = $auth->uploadToken($bucket,$objectName);
								$token2 = $auth->uploadToken($bucket);
								$uploadMgr->putFile($token, $objectName, $dir.$attachs['attachment']);
								$uploadMgr->putFile($token2, $objectName.'.thumb.jpg', $dir.$attachs['attachment']);
								$zhiwu55comConfig['stylename']=trim($zhiwu55comConfig['stylename']);
								$checkPicUrl=$zhiwu55comConfig['attachurl'].$objectName.$zhiwu55comConfig['stylename'];
								$checkPic=dfsockopen($checkPicUrl);
								if(!empty($checkPic) && strlen($checkPic)>50)
								{
									unlink($dir.$attachs['attachment']);
									unlink($dir.$attachs['attachment'].'.thumb.jpg');
									C::t('portal_attachment')->update($attachid,array('remote'=>1));
									if(stripos($objectName,'gif')===false && !empty($zhiwu55comConfig['stylename']) && strlen($zhiwu55comConfig['stylename'])>1)
									{
										$uploadMgr->put($token, $objectName, $checkPic);
									}
								}

							}

						}
					}
					$imgDir = !getglobal('setting/attachurl') ? 'data/attachment/' : getglobal('setting/attachurl');
					$_GET['content']=$_POST['content']=str_replace($imgDir,$zhiwu55comConfig['attachurl'],$_GET['content']);
					$_G['setting']['ftp']['on'] = 1;
					$_G['setting']['ftp']['attachurl'] = $zhiwu55comConfig['attachurl'];

				}

			}
		}

	}

}
?>