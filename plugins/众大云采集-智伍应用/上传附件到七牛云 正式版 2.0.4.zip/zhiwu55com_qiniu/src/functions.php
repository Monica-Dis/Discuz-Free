<?php

namespace Qiniu;

use Qiniu\Config;

if (!defined('QINIU_FUNCTIONS_VERSION')) {
    define('QINIU_FUNCTIONS_VERSION', Config::SDK_VER);

    /**
     * zhiwu55.comcrc32zhiwu55.com:
     *
     * @param $file string  zhiwu55.com
     *
     * @return string zhiwu55.comcrc32zhiwu55.com
     */
    function crc32_file($file)
    {
        $hash = hash_file('crc32b', $file);
        $array = unpack('N', pack('H*', $hash));
        return sprintf('%u', $array[1]);
    }

    /**
     * zhiwu55.comcrc32zhiwu55.com
     *
     * @param $data zhiwu55.com
     *
     * @return string zhiwu55.comcrc32zhiwu55.com
     */
    function crc32_data($data)
    {
        $hash = hash('crc32b', $data);
        $array = unpack('N', pack('H*', $hash));
        return sprintf('%u', $array[1]);
    }

    /**
     * zhiwu55.comurlsafezhiwu55.combase64zhiwu55.com
     *
     * @param string $data zhiwu55.com
     *
     * @return string zhiwu55.com
     * @link http://developer.qiniu.com/docs/v6/api/overview/appendix.html#urlsafe-base64
     */
    function base64_urlSafeEncode($data)
    {
        $find = array('+', '/');
        $replace = array('-', '_');
        return str_replace($find, $replace, base64_encode($data));
    }

    /**
     * zhiwu55.comurlsafezhiwu55.combase64zhiwu55.com
     *
     * @param string $str zhiwu55.com
     *
     * @return string zhiwu55.com
     */
    function base64_urlSafeDecode($str)
    {
        $find = array('-', '_');
        $replace = array('+', '/');
        return base64_decode(str_replace($find, $replace, $str));
    }

    /**
     * Wrapper for JSON decode that implements error detection with helpful
     * error messages.
     *
     * @param string $json JSON data to parse
     * @param bool $assoc When true, returned objects will be converted
     *                        into associative arrays.
     * @param int $depth User specified recursion depth.
     *
     * @return mixed
     * @throws \InvalidArgumentException if the JSON cannot be parsed.
     * @link http://www.php.net/manual/en/function.json-decode.php
     */
    function json_decode($json, $assoc = false, $depth = 512)
    {
        static $jsonErrors = array(
            JSON_ERROR_DEPTH => 'JSON_ERROR_DEPTH - Maximum stack depth exceeded',
            JSON_ERROR_STATE_MISMATCH => 'JSON_ERROR_STATE_MISMATCH - Underflow or the modes mismatch',
            JSON_ERROR_CTRL_CHAR => 'JSON_ERROR_CTRL_CHAR - Unexpected control character found',
            JSON_ERROR_SYNTAX => 'JSON_ERROR_SYNTAX - Syntax error, malformed JSON',
            JSON_ERROR_UTF8 => 'JSON_ERROR_UTF8 - Malformed UTF-8 characters, possibly incorrectly encoded'
        );

        if (empty($json)) {
            return null;
        }
        $data = \json_decode($json, $assoc, $depth);

        if (JSON_ERROR_NONE !== json_last_error()) {
            $last = json_last_error();
            throw new \InvalidArgumentException(
                'Unable to parse JSON data: '
                . (isset($jsonErrors[$last])
                    ? $jsonErrors[$last]
                    : 'Unknown error')
            );
        }

        return $data;
    }

    /**
     * zhiwu55.comAPIzhiwu55.com
     *
     * @param $bucket zhiwu55.com
     * @param $key zhiwu55.com
     *
     * @return string  zhiwu55.comAPIzhiwu55.com
     * @link http://developer.qiniu.com/docs/v6/api/reference/data-formats.html
     */
    function entry($bucket, $key)
    {
        $en = $bucket;
        if (!empty($key)) {
            $en = $bucket . ':' . $key;
        }
        return base64_urlSafeEncode($en);
    }

    /**
     * array zhiwu55.comset
     *
     * @param $array zhiwu55.comarray
     * @param $key key
     * @param $value value zhiwu55.comnullzhiwu55.com zhiwu55.com
     *
     * @return array zhiwu55.comarrayzhiwu55.com
     */
    function setWithoutEmpty(&$array, $key, $value)
    {
        if (!empty($value)) {
            $array[$key] = $value;
        }
        return $array;
    }

    /**
     * zhiwu55.com
     *
     * @param  string $url zhiwu55.com
     * @param  int $mode zhiwu55.com
     * @param  int $width zhiwu55.com
     * @param  int $height zhiwu55.com
     * @param  string $format zhiwu55.com
     * @param  int $quality zhiwu55.com
     * @param  int $interlace zhiwu55.com
     * @param  int $ignoreError zhiwu55.com
     * @return string
     * @link http://developer.qiniu.com/code/v6/api/kodo-api/image/imageview2.html
     * @author Sherlock Ren <sherlock_ren@icloud.com>
     */
    function thumbnail(
        $url,
        $mode,
        $width,
        $height,
        $format = null,
        $quality = null,
        $interlace = null,
        $ignoreError = 1
    ) {

        static $imageUrlBuilder = null;
        if (is_null($imageUrlBuilder)) {
            $imageUrlBuilder = new \Qiniu\Processing\ImageUrlBuilder;
        }

        return call_user_func_array(array($imageUrlBuilder, 'thumbnail'), func_get_args());
    }

    /**
     * zhiwu55.com
     *
     * @param  string $url zhiwu55.com
     * @param  string $image zhiwu55.com
     * @param  numeric $dissolve zhiwu55.com
     * @param  string $gravity zhiwu55.com
     * @param  numeric $dx zhiwu55.com
     * @param  numeric $dy zhiwu55.com
     * @param  numeric $watermarkScale zhiwu55.com
     * @link   http://developer.qiniu.com/code/v6/api/kodo-api/image/watermark.html
     * @return string
     * @author Sherlock Ren <sherlock_ren@icloud.com>
     */
    function waterImg(
        $url,
        $image,
        $dissolve = 100,
        $gravity = 'SouthEast',
        $dx = null,
        $dy = null,
        $watermarkScale = null
    ) {

        static $imageUrlBuilder = null;
        if (is_null($imageUrlBuilder)) {
            $imageUrlBuilder = new \Qiniu\Processing\ImageUrlBuilder;
        }

        return call_user_func_array(array($imageUrlBuilder, 'waterImg'), func_get_args());
    }

    /**
     * zhiwu55.com
     *
     * @param  string $url zhiwu55.com
     * @param  string $text zhiwu55.com
     * @param  string $font zhiwu55.com
     * @param  string $fontSize zhiwu55.com
     * @param  string $fontColor zhiwu55.com
     * @param  numeric $dissolve zhiwu55.com
     * @param  string $gravity zhiwu55.com
     * @param  numeric $dx zhiwu55.com
     * @param  numeric $dy zhiwu55.com
     * @link   http://developer.qiniu.com/code/v6/api/kodo-api/image/watermark.html#text-watermark
     * @return string
     * @author Sherlock Ren <sherlock_ren@icloud.com>
     */
    function waterText(
        $url,
        $text,
        $font = 'zhiwu55.com',
        $fontSize = 0,
        $fontColor = null,
        $dissolve = 100,
        $gravity = 'SouthEast',
        $dx = null,
        $dy = null
    ) {

        static $imageUrlBuilder = null;
        if (is_null($imageUrlBuilder)) {
            $imageUrlBuilder = new \Qiniu\Processing\ImageUrlBuilder;
        }

        return call_user_func_array(array($imageUrlBuilder, 'waterText'), func_get_args());
    }

    /**
     *  zhiwu55.comuptokenzhiwu55.comaccessKeyzhiwu55.combucket
     *
     * @param $upToken
     * @return array(ak,bucket,err=null)
     */
    function explodeUpToken($upToken)
    {
        $items = explode(':', $upToken);
        if (count($items) != 3) {
            return array(null, null, "invalid uptoken");
        }
        $accessKey = $items[0];
        $putPolicy = json_decode(base64_urlSafeDecode($items[2]));
        $scope = $putPolicy->scope;
        $scopeItems = explode(':', $scope);
        $bucket = $scopeItems[0];
        return array($accessKey, $bucket, null);
    }
}
