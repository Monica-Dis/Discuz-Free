<?php
/*
 *	Author: IAN - zhouxingming
 *	Last modified: 2014-11-15 
 *	Filename: block_xml.inc.php
 *	Description: 
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$clientid = intval($_G['gp_clientid']);//ͨѶid
$sign = daddslashes(trim($_G['gp_sign']));//ͨѶ��Կ
$clientcharset = strtolower(trim($_G['gp_charset']));
$clientcharset = str_replace('-', '', $clientcharset);
$servercharset = CHARSET;
$clientcharset = in_array($clientcharset, array('gbk', 'utf8')) ? $clientcharset : $servercharset;
$auc = $auclists = array();

if(empty($clientid) || empty($sign)) {
	exit('CLIENT_SIGN_ERROR');
}

$client_check = 0;
$client_check = DB::result_first("SELECT COUNT(*) FROM ".DB::table('bingofans_video_xml')." WHERE clientid='$clientid' AND sign='$sign'");
$servercharset = CHARSET;//��֤��·�Ϸ���
if($client_check) {//$client_check
	if($_G['gp_op'] == 'getconfig') {
		$xml = file_get_contents(DISCUZ_ROOT.'./source/plugin/bingofans_video/xml/block_xml.setting.'.$clientcharset.'.xml');
	} elseif($_G['gp_op'] == 'getdata') {
		$sqladd 	= array();
		$uids 		= get_int_from_string($_G['gp_uids']);
		$tids 		= get_int_from_string($_G['gp_tids']);
                $bannedids 	= get_int_from_string($_G['gp_bannedids']);
		$start 		= max(0, intval($_G['gp_start']));
		$order 		= intval($_G['gp_order']);
		$num 		= max(1, intval($_G['gp_items']));
		$num 		= $num > 10 ? 10 : $num;
		$width 		= intval($_G['gp_width']);
		$height 	= intval($_G['gp_height']);

		if(!empty($uids)) {
			$sqladd[] = 'authorid IN ('.dimplode($uids).')';
		}
		if(!empty($tids)) {
			$sqladd[] = 'tid IN ('.dimplode($tids).')';
		}
		if(!empty($bannedids)) {
			$sqladd[] = 'tid NOT IN ('.dimplode($bannedids).')';
		}
		$orderby = 'dateline desc';
                if($order ==1){
                    $orderby = 'play desc,dateline desc';
                }elseif($order ==2){
                    $orderby = 'reply desc,dateline desc';   
                }
		$query = DB::query("SELECT * FROM ".DB::table('bingofans_video_thread')." ".($sqladd ? 'WHERE ' : '').implode(' AND ', $sqladd).' ORDER BY '.$orderby." LIMIT $start,$num");
 require_once libfile("function/video","plugin/bingofans_video");
		while($video = DB::fetch($query)) {
			$auc['id'] = $video['tid'];
                        $video['width']=$width;
                        $video['height']=$height;
			$auc['url'] = get_turl($video['tid']);
			$auc['title'] = $video['subject'];
			$auc['pic'] = $video['coverimg'];
			$auc['fields'] = $video;
			$auclists[] = $auc;
		}

		require_once libfile('class/xml');
		$xmlarray = array('html' => '', 'data' => $auclists);
		$xml = array2xml($xmlarray);

	} else {
		exit('OPERATION_ERROR');
	}
	@header("Expires: -1");
	@header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
	@header("Pragma: no-cache");
	header("Content-type: text/xml;charset=".$clientcharset.';');
	echo $xml;
	exit();
} else {
    echo $client_check;
	exit('CLIENT_SIGN_ERROR');
}


function get_int_from_string($str, $array = null) {
	$str = trim($str);
	$ids_tmp = explode(',', $str);
	$ids = array();
	foreach($ids_tmp as $key => $id) {
		$id = intval($id);
		if($array) {
			in_array($id, $array) && $ids[] = $id;//ǰ��Ϊ�ٺ��治��ִ��
		} elseif(!empty($id)){
			$ids[] = $id;
		}
	}
	return $ids;
}
//From: Dism��taobao��com
?>