  <?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
   $fcid=intval($_GET['fcid']);$scid=intval($_GET['scid']);
   $tcid=intval($_GET['tcid']);
   $fclass= C::t("#bingofans_video#video")->fetch_all("type=1");
   if($fcid)$sclass= C::t("#bingofans_video#video")->fetch_all("type=2 and cup=$fcid");
   if($scid)$tclass= C::t("#bingofans_video#video")->fetch_all("type=3 and cup=$scid");
   if(submitcheck('search_submit',1)){
		if($_GET['urlkey']){
			$key=trim(urldecode($_GET['urlkey']));
		}else{
			$key=trim($_GET['key']);
		}
			if($key){
			$key=stripsearchkey($key);
			$where="subject LIKE '%".$key."%' and ";}
			}
			$c_array=array('fcid','scid','tcid');
			foreach($c_array as$ck=>$cv){
			$tmp=$$cv;
			if($tmp){
			$where.="$cv=$tmp and ";
			}else{
			$where.="1=1 and ";
			}
	   		
		}
	$where.="visiable=1";	
	$where=str_replace("1=1 and 1=1","1=1",$where);
	$where=str_replace("1=1 and 1=1","1=1",$where);
	if(!$where){$where="visiable=1";}
   $urlkey=urlencode($key);
   $perpage=max(1,$bingofans['perpage']);$page=max(1,intval($_GET['page']));
   $start=$perpage*$page-$perpage;
   if($_GET['order']=='play'){$order='play desc,dateline desc';}elseif($_GET['order']=='grade'){$order='grade desc,dateline desc';}else{$order='dateline desc,play desc';}
   $postsz=C::t("#bingofans_video#video")->fetch_all_by_where('bingofans_video_thread',$where,$order,$start,$perpage);
   $maxnum=C::t("#bingofans_video#video")->count_by_where('bingofans_video_thread',$where); 
   define("bingofans_SEARCH_URL","$bingofans[ruphp]mod=s&search_submit=1&urlkey=$urlkey&formhash=".FORMHASH);
   $url="$bingofans[ruphp]mod=s&fcid=$fcid&scid=$scid&tcid=$tcid&urlkey=$urlkey&search_submit=1&formhash=".FORMHASH;
      if(!defined('IN_MOBILE')){
		  $multi=multi($maxnum,$perpage,$page,$url,0,10,true,FALSE);
	   }else{$multi=get_bootstrap_page($maxnum,$perpage,$page,$url,10,0);}
   
   $audionum=count($postsz);
   $navtitle.="-$key";
   $metakeywords=$navtitle.',$key';
   if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
		include template('bingofans_video:s');
	} else {
		include template('diy:s', null, 'source/plugin/bingofans_video/template');
	}
 ?>