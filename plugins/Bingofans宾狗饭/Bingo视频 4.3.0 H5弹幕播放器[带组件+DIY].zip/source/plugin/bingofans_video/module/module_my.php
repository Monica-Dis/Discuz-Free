<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_G[groupid]!=1&&!in_array($_G[groupid],unserialize($bingofans['allow_r']))||!$_G[uid]){
	$forbide_reply=1;
	}
$authorid=intval($_GET['authorid']);
$authorid=max(1,$authorid);
C::t("#bingofans_video#video")->increase_by_where("bingofans_video_thread",'play',"authorid=$authorid");
$thread=C::t("#bingofans_video#video")->fetch_first("bingofans_video_thread","authorid=$authorid");
if(empty($thread))showmessage('&#23545;&#19981;&#36215;&#44;&#20182;&#36824;&#27809;&#26377;&#24050;&#32463;&#21457;&#24067;&#30340;&#35270;&#39057;&#65281;',dreferer());
require_once libfile("function/reply","plugin/bingofans_video");
$perpage=max(1,$bingofans['mydan']);$page=max(1,intval($_GET['page']));
$start=$perpage*$page-$perpage;
if($_GET['order']=='play'){$order='play desc,dateline desc';}elseif($_GET['order']=='grade'){$order='grade desc,dateline desc';}else{$order='dateline desc,play desc';}
$post=C::t("#bingofans_video#video")->fetch_first("bingofans_video_post","authorid=$authorid and first=1");
$my_video=C::t("#bingofans_video#video")->fetch_all_by_where('bingofans_video_thread','authorid='.$thread['authorid']." and num=1",$order,$start,$perpage);
$my_album=C::t("#bingofans_video#video")->fetch_all_by_where('bingofans_video_thread','authorid='.$thread['authorid']." and num>1",$order,$start,$perpage);
$navtitle=$thread['author'];
$svalue=intval(getcookie("ping_video_".$thread[authorid]));
$ext=bingofans_get_ext($video[0]['link']);
$maxnum=C::t("#bingofans_video#video")->count_by_where('bingofans_video_thread','authorid='.$thread['authorid']." and num=1"); 
   define("$bingofans[ruphp]mod=my&authorid=$authorid&formhash=".FORMHASH);
   $url="$bingofans[ruphp]mod=my&authorid=$authorid&formhash=".FORMHASH;
      if(!defined('IN_MOBILE')){
		  $multi=multi($maxnum,$perpage,$page,$url,0,10,true,FALSE);
	   }else{$multi=get_bootstrap_page($maxnum,$perpage,$page,$url,10,0);}
   if($_G['mobile'] && $_G['setting']['mobile']['allowmobile']) {
		include template('bingofans_video:my');
	} else {
		include template('diy:my', null, 'source/plugin/bingofans_video/template');
	}
 ?>