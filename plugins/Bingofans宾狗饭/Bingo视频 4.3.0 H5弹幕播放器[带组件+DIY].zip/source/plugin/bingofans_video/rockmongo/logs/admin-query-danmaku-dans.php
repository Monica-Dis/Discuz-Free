<?php exit("Permission Denied"); ?>
2019-12-22 06:08:44
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
tid=260
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-22 06:08:49
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => 'tid=260',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-22 06:08:52
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => 'tid=260',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-22 06:09:37
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
260
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => 'referer',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-22 06:09:50
array (
  'action' => 'collection.index',
  'db' => 'danmaku',
  'collection' => 'dans',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2019-12-22 06:09:58
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array (260
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-22 06:41:26
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	5dfe8c8fce4db20011f8d938
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-22 06:41:36
array (
  'action' => 'collection.index',
  'db' => 'danmaku',
  'collection' => 'dans',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
)
================
2019-12-22 06:41:41
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
	5dfe8c8fce4db20011f8d938
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-22 06:42:26
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
	11
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'text',
  ),
)
================
2019-12-22 07:21:55
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"player": "c35d395bcdfd047c7df3a9a13c49d166",
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-22 07:22:24
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"player":"c35d395bcdfd047c7df3a9a13c49d166"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => 'player',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
  ),
)
================
2019-12-22 07:22:31
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"player":"c35d395bcdfd047c7df3a9a13c49d166"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'asc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
  ),
)
================
2019-12-22 07:22:32
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"player":"c35d395bcdfd047c7df3a9a13c49d166"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'asc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
  ),
)
================
2019-12-22 07:22:53
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"referer": "https://www.bingoufan.com/plugin.php?id=bingofans_video&mod=v&tid=260",
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
  ),
)
================
2019-12-22 07:22:57
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"referer": "https://www.bingoufan.com/plugin.php?id=bingofans_video&mod=v&tid=260"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
  ),
)
================
2019-12-22 07:23:44
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"referer": "https://www.bingoufan.com/plugin.php?id=bingofans_video&mod=v&tid=260"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => 'text',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
  ),
)
================
2019-12-22 07:24:07
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"author": "DIYgod"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
    1 => 'text',
  ),
)
================
2019-12-22 07:24:36
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"author": "DIYgod"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
    1 => 'text',
  ),
  'page' => '2',
)
================
2019-12-22 07:50:31
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"text": "222222222222222"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
    1 => 'text',
  ),
)
================
2019-12-22 07:52:11
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"text": "222222222222222"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'remove',
  'query_fields' => 
  array (
    0 => 'player',
    1 => 'text',
  ),
)
================
2019-12-22 07:52:19
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"text": "222222222222222"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
    1 => 'text',
  ),
)
================
2019-12-22 07:52:20
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"text": "222222222222222"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
    1 => 'text',
  ),
)
================
2019-12-22 07:52:21
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"text": "222222222222222"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
    1 => 'text',
  ),
)
================
2019-12-22 07:59:51
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"text": "我来刷一波弹幕"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-22 07:59:59
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{"text": "我来刷一波弹幕"

}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-22 08:00:12
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{"text": "我来刷一波"

}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-22 08:00:19
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{"text": "我来刷一波"

}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
  'query_fields' => 
  array (
    0 => 'player',
  ),
)
================
2019-12-25 11:30:21
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"player": "c35d395bcdfd047c7df3a9a13c49d166"
}',
  'newobj' => '{
	\'$set\': {
		"player": "260"
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'modify',
)
================
2019-12-25 11:31:10
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"player": "c35d395bcdfd047c7df3a9a13c49d166"
}',
  'newobj' => '{
"player": "260"
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'modify',
)
================
2019-12-25 11:31:41
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"player": "c35d395bcdfd047c7df3a9a13c49d166"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-25 11:35:40
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"player": "c35d395bcdfd047c7df3a9a13c49d166"
}',
  'newobj' => '{
	\'$set\': {
		260
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'modify',
)
================
2019-12-25 11:38:29
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"player": "c35d395bcdfd047c7df3a9a13c49d166"
}',
  'newobj' => '{
	\'$set\': "player": "260"
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'modify',
)
================
2019-12-25 11:41:16
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{"player": "c35d395bcdfd047c7df3a9a13c49d166"

}',
  'newobj' => '{
	\'$set\': "player": "260"
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'modify',
)
================
2019-12-25 11:44:39
array (
  'action' => 'collection.index',
  'db' => 'danmaku',
  'collection' => 'dans',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2019-12-25 11:50:38
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	\'player\' => \'c35d395bcdfd047c7df3a9a13c49d166\'
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2019-12-25 11:51:04
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	\'player\' => \'c35d395bcdfd047c7df3a9a13c49d166\'
)',
  'newobj' => 'array(
	\'$set\' => array (
		\'player\' => \'260\'
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'modify',
)
================
2019-12-25 11:51:12
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	\'player\' => \'c35d395bcdfd047c7df3a9a13c49d166\'
)',
  'newobj' => 'array(
	\'$set\' => array (
		\'player\' => \'260\'
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'modify',
)
================
2019-12-25 11:52:07
array (
  'action' => 'collection.index',
  'db' => 'danmaku',
  'collection' => 'dans',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '11',
)
================
2019-12-25 11:52:23
array (
  'db' => 'danmaku',
  'collection' => 'dans',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	\'player\' => \'9afbb11205758932db0dddd304074b1c\'
)',
  'newobj' => 'array(
	\'$set\' => array (
		\'player\' => \'161\'
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'modify',
)
================
2019-12-25 11:52:28
array (
  'action' => 'collection.index',
  'db' => 'danmaku',
  'collection' => 'dans',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '11',
)
================
2019-12-25 11:52:46
array (
  'action' => 'collection.index',
  'db' => 'danmaku',
  'collection' => 'dans',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '5',
)
================
2019-12-25 11:52:47
array (
  'action' => 'collection.index',
  'db' => 'danmaku',
  'collection' => 'dans',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '1',
)
================
