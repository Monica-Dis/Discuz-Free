<?php

/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile("function/video", "plugin/bingofans_video");
require_once libfile("function/reply", "plugin/bingofans_video");
$bingofans = $_G['cache']['plugin']['bingofans_video'];
include template('common/header_ajax');
if (submitcheck('rsubmit')) {
    if (!$_G['uid']) {
        showmessage("<font color='red'>error:not uid</font>");
    }
    $tid = $_GET['tid'];
    if (getcookie("reply_" . $tid)) {
        showmessage("<font color='red'>&#x5BF9;&#x4E0D;&#x8D77;&#x4F60;&#x56DE;&#x590D;&#x7684;&#x8FC7;&#x4E8E;&#x9891;&#x7E41;&#xFF01;</font>");
        exit;
    } else {
        if (!$_GET['tid'])
            showmessage("&#x5BF9;&#x4E0D;&#x8D77; tid&#x4E0D;&#x80FD;&#x4E3A;&#x7A7A;");
        if (!$_GET['content'])
            showmessage("&#x8BF7;&#x586B;&#x5199;&#x5185;&#x5BB9;");
        $pid = insert_new_reply();
        $touid = $_GET['authorid'];
        if (preg_match('/^@/', $_GET['content'])) {
            $touid = $_GET['touid'];
        }
        if ($touid != $_G['uid']) {
            $note = $_G['username'] . '&#x8BC4;&#x8BBA;&#x4E86;&#x4F60;&#x7684;&#x4E00;&#x6761;&#x5185;&#x5BB9;<a href="' . bingofans_video_URL . '&mod=v&tid=' . $tid . '#reply_list">&#x70B9;&#x6B64;&#x770B;&#x4E00;&#x770B;</a>';
            notification_add($touid, 'post', $note);
        }
        updatemembercount($_G['uid'], array($bingofans['rjftype'] => $bingofans['rjfvalue']));
        dsetcookie('reply_' . $tid, 1, max(30, $bingofans['dtime']));
        $replys[0]['message'] = $_GET['content'];
        $replys[0]['author'] = $_G['username'];
        $replys[0]['authorid'] = $_G['uid'];
        $replys[0]['pid'] = $pid;
        $replys[0]['dateline'] = time();
        include template('bingofans_video:ajax_reply');
    }
} elseif ($_GET['type'] == 'reply') {
    $perpage = max(1, $bingofans['per_reply']);
    $page = max(1, $_GET['page']);
    $tid = intval($_GET['tid']);
    $start = $perpage * $page - $perpage;
    $where = "tid=$tid and first<>1";
    $replys = C::t("#bingofans_video#video")->fetch_all_by_where('bingofans_video_post', $where, 'dateline desc', $start, $perpage);
    $maxnum = C::t("#bingofans_video#video")->count_by_where('bingofans_video_post', $where);
    $url = bingofans_video_URL . ":ajax&type=reply&tid=$tid";
    $multi = get_bingofans_page($maxnum, $perpage, $page, $url, 10, 1, "reply_reajax");
    include template('bingofans_video:ajax_reply');
} elseif ($_GET['type'] == 'delete') {
	if (submitcheck('dsubmit', 1)) {
        C::t("#bingofans_video#video")->delete_by_where('pid=' . intval($_GET[pid]), 'bingofans_video_post');
    }
} elseif ($_GET['type'] == 'grade') {
    @list($tid, $value) = array(intval($_GET['tid']), intval($_GET['value']));
    if (!$tid)
        showmessage("&#x5BF9;&#x4E0D;&#x8D77;&#x7CFB;&#x7EDF;&#x51FA;&#x9519;&#xFF01;");
    $thread = C::t("#bingofans_video#video")->fetch_first('bingofans_video_thread', "tid=$tid");
    $grade = $thread['grade'];
    $gnum = $thread['gnum'];
    $ngnum = $gnum + 1;
    $ngrade = (($grade * $gnum) + $value) / $ngnum;
    $uparr = array('grade' => $ngrade, 'gnum' => $ngnum);
    C::t("#bingofans_video#video")->update_by_where('bingofans_video_thread', $uparr, "tid=$tid");
    dsetcookie('ping_video_' . $tid, $value, 2592000);
    for ($i = 1; $i < 6; $i++) {
        if ($i <= $ngrade)
            echo '<li class="bingofans_x hover"></li>';
        else
            echo '<li class="bingofans_x"></li>';
    }
    echo '<div class="bingofans_grade"><font  color="#FF0000">' . number_format($ngrade, 1) . '</font>&#x5206;</div>';
}elseif ($_GET['list']) {
    @list($fcid, $scid) = array(intval($_GET[fcid]), intval($_GET[scid]));
    $key = array('fcid', 'scid');
    $where = '';
    foreach ($key as $k => $v) {
        if ($$v != 0) {
            $where.="$v=" . $$v . " and ";
        }
    }
    $where.="1=1";
    $bingofans = $_G['cache']['plugin']['bingofans_video'];
    $perpage = max(4, $bingofans['perpage']);
    $page = max(1, intval($_GET['page']));
    $start = $perpage * $page - $perpage;
    $posts = C::t("#bingofans_video#video")->fetch_all_by_where('bingofans_video_thread', $where, 'displayorder desc,dateline desc', $start, $perpage);
    $maxnum = C::t("#bingofans_video#video")->count_by_where('bingofans_video_thread', $where);
    $url = "plugin.php?id=bingofans_video:ajax&list=1&fcid=$fcid&scid=$scid";
    $multi = get_bingofans_page($maxnum, $perpage, $page, $url);
    include template('bingofans_video:ajax_post');
} else {
    @list($type, $cup) = array(intval($_GET[type]), intval($_GET[cup]));
    $class = C::t("#bingofans_video#video")->fetch_all("type=$type and cup=$cup");
    include template('bingofans_video:ajax');
}
include template('common/footer_ajax');
?>