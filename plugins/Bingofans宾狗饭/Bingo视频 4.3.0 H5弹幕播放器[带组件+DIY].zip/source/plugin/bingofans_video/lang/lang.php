<?php
/*请注意，带超链接的文字，将链接填入href=""引号中，一定要是引号中*/
/*PC电脑端*/
/*首页 首页 首页 首页 m.htm*/
/*上中下切换*/
$index_a1 = '<li class="new cur">新番</li><li class="rec">推荐</li><li class="hot">热门</li>';
/*1*/
$index_a2 = '今日推荐';
$index_a3 = '<a href="">最新资讯</a><a href="">最热资源</a><a href="">精彩推荐</a>';
/*2左*/
$index_a4 = '动漫番剧';
$index_a5 = '<a href="">海贼王</a><a href="">火影忍者</a><a href="">妖精的尾巴</a><a href="">亚人</a><a href="">龙珠Z</a><a href="">夏目友人帐</a>';
$index_a6 = '<a class="more" href="">更多 >></a>';
/*2右*/
$index_a7 = '排行';
$index_a8 = '<li class="first cur">24小时</li><li class="last">一周</li>';
/*3最新星期切换*/
$index_a9 = '<li class="cur"><i class="new icur"></i>最新</li><li><i class="mon"></i>周一</li><li><i class="tues"></i>周二</li><li><i class="wed"></i>周三</li><li><i class="thur"></i>周四</li><li><i class="fri"></i>周五</li><li><i class="sat"></i>周六</li><li><i class="sun"></i>周日</li>';
/*3右*/
$index_a10 = '排行';
$index_a11 = '<li class="first cur">推荐</li><li class="last">一周</li>';
/*4左*/
$index_a12 = '音　悦';
$index_a13 = '<a href="">动漫原声</a><a href="">纯音乐</a><a href="">激燃BGM</a><a href="">畅听心灵</a><a href="">冬季</a><a href="">歌单推荐</a>';
$index_a14 = '<a class="more" href="">更多 >></a>';
/*4右*/
$index_a15 = '排行';
$index_a16 = '<li class="first cur">24小时</li><li class="last">一周</li>';
/*5左*/
$index_a17 = '萌图 / 壁纸';
$index_a18 = '<a href="">动漫萌妹</a><a href="">典藏包</a><a href="">壁纸</a><a href="">COSER</a><a href="">同人图</a><a href="">游戏</a>';
$index_a19 = '<a class="more" href="">更多 >></a>';
/*5右*/
$index_a20 = '排行';
$index_a21 = '<li class="first cur">推荐</li><li class="last">一周</li>';
/*6左*/
$index_a22 = '绘　画';
$index_a23 = '<a href="">板绘</a><a href="">手绘</a><a href="">工具资源</a><a href="">CG人设</a><a href="">厚涂作品</a><a href="">线稿</a>';
$index_a24 = '<a class="more" href="">更多 >></a>';
/*6右*/
$index_a25 = '排行';
$index_a26 = '<li class="first cur">24小时</li><li class="last">一周</li>';
/*7左*/
$index_a27 = 'SEVEN';
$index_a28 = '<a href="">Else-one</a><a href="">Else-two</a><a href="">Else-three</a><a href="">Else-four</a><a href="">Else-five</a><a href="">Else-six</a>';
$index_a29 = '<a class="more" href="">更多 >></a>';
/*7右*/
$index_a30 = '排行';
$index_a31 = '<li class="first cur">24小时</li><li class="last">一周</li>';
/*8左*/
$index_a32 = 'EIGHT';
$index_a33 = '<a href="">Else-one</a><a href="">Else-two</a><a href="">Else-three</a><a href="">Else-four</a><a href="">Else-five</a><a href="">Else-six</a>';
$index_a34 = '<a class="more" href="">更多 >></a>';
/*8右*/
$index_a35 = '排行';
$index_a36 = '<li class="first cur">24小时</li><li class="last">一周</li>';

/*插件风格下底部文字 footer.htm*/
$index_b1 = '<a href="#" target="_blank">关于我们</a><a href="#" target="_blank">商务合作</a><a href="#" target="_blank">免责声明</a>';
$index_b2 = '2001-2013';
$index_b3 = '官方';
$index_b4 = '<a href="#" target="_blank">新浪微博</a><a href="#" target="_blank">腾讯微博</a><a href="#" target="_blank">微信公众号</a><a href="#" target="_blank">投稿规则</a><a href="#" target="_blank">版权声明</a><a href="#" target="_blank">捐助我们</a><p class="dz_a">官方Q群: <a>133722836</a><a>133722836</a></p>';
$index_b5 = '反馈';
$index_b6 = '<a href="#" target="_blank">投诉举报</a><a href="#" target="_blank">意见反馈</a><a href="#" target="_blank">用户协议</a><a href="#" target="_blank">论坛规则</a><p class="dz_a">须知： 切勿滥用举报，任何与举报相关的信息必须属实！</p>';
$index_b7 = '/source/plugin/bingofans_video/template/new/erweima.gif';/*底部二维码*/
$index_b8 = '<a href=""><span class="to_down">点击下载</span></a>';

/*插件风格下头部文字 header_m_top.htm*/
$index_c1 = '打开 DIY 面板';
$index_c2 = 'DIY设置';
$index_c3 = '修改资料';
$index_c4 = '上传头像';
$index_c5 = '我的帖子';
$index_c6 = '我的收藏';
$index_c7 = '我的好友';
$index_c8 = '退出登陆';
$index_c9 = '消息';
$index_c10 = '投稿';
$index_c11 = '登陆';
$index_c12 = '注册';
$index_c13 = 'QQ登陆';

/*小导航文字 xiaonav.htm*/
$index_c14 = '首页';
$index_c15 = '自频道';
$index_c16 = '我的投稿';
$index_c17 = '活动';
$index_c18 = '话题列表';

/*搜索页 s.htm*/
$index_d1 = '综合排序';
$index_d2 = '最多点击';
$index_d3 = '最新发布';
$index_d4 = '最高评分';
$index_d5 = '共找到';
$index_d6 = '个相关视频';
$index_d7 = '观看';
$index_d8 = '上传时间';
$index_d9 = 'up主';

/*模板风格下搜索框 search.htm*/
$index_d10 = '发布视频';

/*插件风格下搜索框提示语 pubsearchform.htm*/
$index_d11 = '搜索视频';

/*发布页 后台 p.htm*/
$index_dd1 = '选择';
$index_dd2 = '待审核';
$index_dd3 = '通过审核';
$index_dd4 = '批量删除';
$index_dd5 = '请将优酷视频网址复制到此(目前一键采集暂时只支持优酷，请不要在下方输入优酷以外的链接。)';
$index_dd6 = '快捷发布';
$index_dd7 = '添加其他平台视频';
$index_dd8 = '点此去手动添加';
$index_dd9 = '优酷快捷发布';
$index_dd10 = '不需要输入复杂信息，一个网址就够了';
$index_dd11 = '视频标题:';
$index_dd12 = '点击查看腾讯视频、哔哩哔哩、爱奇艺、芒果TV等发布教程';
$index_dd13 = '视频地址:';
$index_dd14 = '封面地址:';
$index_dd15 = '删除';
$index_dd16 = '视频地址:';
$index_dd17 = '视频标题:';
$index_dd18 = '封面地址:';
$index_dd19 = '增加一个视频信息，制作播单';
$index_dd20 = '发布视频';
$index_dd21 = '上传文件大小限制为';
$index_dd22 = '编辑视频';
$index_dd23 = '频道：';
$index_dd24 = '简介：';
$index_dd25 = '对不起你暂时没有回复的权限！';
$index_dd26 = '看点槽点，不吐不快！别憋着，马上大声说出来吧！';
$index_dd27 = '提交(最多可输入140个字)';
$index_dd28 = '提交';
$index_dd29 = '表情';
$index_dd30 = '你需要';
$index_dd31 = '登录';
$index_dd32 = '才能回复';
$index_dd33 = '超清';
$index_dd34 = '频道：';
$index_dd35 = '次播放';
$yuan_p0 = '发布信息';
$yuan_p1 = '名称';
$yuan_p2 = '封面';
$yuan_p3 = '类别';
$yuan_p4 = '所在地区';
$yuan_p5 = '详细地址';
$yuan_p6 = '简介';
$yuan_p7 = '详细介绍';
$yuan_p8 = '不限';
$yuan_p9 = '建议大小640*350或448*252';
$yuan_p10 = '确认提交';
$yuan_p11 = '视频信息';
$yuan_p12 = '音频链接';
$yuan_p13 = '链接地址';
$yuan_p14 = '含有http://';
$yuan_p15 = '抱歉，您无法使用该功能';

/*优酷发布 youku.htm youku2.htm*/
$index_zz0 = '视频上传完成前，请不要关闭此窗口！';
$index_zz1 = '选择文件：';
$index_zz2 = '简介：';
$index_zz3 = '标签：';
$index_zz4 = '类别：';
$index_zz5 = '版权所有';
$index_zz6 = '原创';
$index_zz7 = '转载';
$index_zz8 = '视频权限';
$index_zz9 = '公开';
$index_zz10 = '仅优酷好友';
$index_zz11 = '输入密码观看';
$index_zz12 = '开始上传';
$index_zz13 = '需要登录后才能使用本功能;请';
$index_zz14 = '登录';
$index_zz15 = '视频上传成功，已自动获取视频地址，地址为';
$index_zz16 = '（请将地址复制到视频发布页，建议您先将地址复制到浏览器查看，待视频转码审核完成再发布，否则可能出现无法自动获取封面），视频名称为：';
$index_zz17 = '标题：';
$index_zz18 = '前往视频发布页';
$index_zz19 = '一键上传到优酷';
$index_zz20 = '你的浏览器不支持flash,Silverlight或者HTML5！';

/*播放页 v.htm vl.htm v_reply v_side*/
$index_e1 = '稿件投诉';
$index_e2 = '[编辑该视频信息]';
$index_e3 = '播放';
$index_e4 = '评论';
$index_e5 = '发消息';
$index_e6 = '这家伙很懒，什么也没写...';
$index_e7 = '稍后观看';
$index_e8 = '频道：';
$index_e9 = '次播放';
$index_e10 = '分享';
$index_e11 = '将视频贴到博客或论坛';
$index_e12 = '视频地址';
$index_e13 = '复制';
$index_e14 = '微信扫一扫分享';
$index_e15 = '用手机看';
$index_e16 = '转移阵地~';
$index_e17 = '用<a href="#" target="_blank" id="toolbar-mobile-app">宾狗视频APP客户端</a>或其他应用扫描二维码';
$index_e18 = '下载APP';
$index_e19 = '扫描二维码下载APP';
$index_e20 = '看过该视频的还喜欢';
$index_e21 = '热门播单';
$index_e22 = '评论';
$index_e23 = '全部评论';
$index_e24 = '按热度排序';
$index_e25 = '请自觉遵守互联网相关的政策法规，严禁发布色情、暴力、反动的言论。';
$index_e26 = '评论';
$index_e27 = '表情';
$index_e28 = '字数：';
$index_e29 = '评分：';
$index_e30 = '你的评分：';
$index_e31 = '分';

/*自频道内页 my.htm*/
$index_my1 = '这个人很懒，什么也没留下......';
$index_my2 = '发消息';
$index_my3 = '举报该用户';
$index_my4 = '主页';
$index_my5 = '主题';
$index_my6 = '视频';
$index_my7 = '频道';
$index_my8 = '视频';
$index_my9 = '播单';
$index_my10 = '专栏';
$index_my11 = 'TA的视频';
$index_my12 = '我的视频';
$index_my13 = '介绍';
$index_my14 = '播放数';
$index_my15 = '弹幕数';
$index_my16 = '创建时间';
$index_my17 = '关注数';
$index_my18 = '粉丝数';


/*手机版*/
/*手机底部文字 footer.htm*/
$index_mfooter1 = '<a href="/"><i class="iconfont icon-shouye"></i><font>首页</font></a>';
$index_mfooter2 = '视频搜索';
$index_mfooter3 = '发布';
$index_mfooter4 = '论坛';
$index_mfooter5 = '我的';
?>