<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
   $la=lang("plugin/bingofans_video");
   if(submitcheck('submit')){
		  $order=$_GET['order'];
		  $name=$_GET['name'];
		  $neworder=$_GET['newcatorder'];
		  $newname=$_GET['newcat'];
		  $newsuborder=$_GET['newsuborder'];
		  $newsubcat=$_GET['newsubcat'];
		  $newtirorder=$_GET['newtirorder'];
		  $newtircat=$_GET['newtircat'];
		  {if($_G[groupid]!=1){showmessage('&#x5BF9;&#x4E0D;&#x8D77;,&#x4F60;&#x6CA1;&#x6709;&#x6743;&#x9650;&#x6267;&#x884C;&#x6B64;&#x64CD;&#x4F5C;!',dreferer());}
			foreach($neworder as$k=>$v){//first
			if(empty($newname[$k]))$newname[$k]=$la['no_name'];
				C::t("#bingofans_video#video")->insert_new("bingofans_video",array('cup'=>0,'type'=>1,'name'=>daddslashes($newname[$k]),'displayorder'=>$v));
				}	 
			foreach($newsuborder as$k=>$v){//second
				 foreach($v as$kin=>$vin){
					 if(empty($newsubcat[$k][$kin]))$newsubcat[$k][$kin]=$la['no_name'];
					 C::t("#bingofans_video#video")->insert_new("bingofans_video",array('cup'=>$k,'type'=>2,'name'=>daddslashes($newsubcat[$k][$kin]),'displayorder'=>$vin));
				}
			 }
			foreach($newtirorder as$k=>$v){//third
					 foreach($v as$kin=>$vin){
						  if(empty($newtircat[$k][$kin]))$newtircat[$k][$kin]=$la['no_name'];
						 C::t("#bingofans_video#video")->insert_new("bingofans_video",array('cup'=>$k,'type'=>3,'name'=>daddslashes($newtircat[$k][$kin]),'displayorder'=>$vin));
					}	 
			}
			foreach($order as$k=>$v){
				if(empty($name[$k]))$name[$k]=$la['no_name'];
				C::t("#bingofans_video#video")->update_by_where("bingofans_video",array('name'=>daddslashes($name[$k]),'displayorder'=>intval($v)),"cid=$k");
				}
		
		cpmsg($la['success'],'action=plugins&identifier=bingofans_video&pmod=class','succeed');			 
	}}elseif($_GET['dele']&&FORMHASH == $_GET['formhash']){
		{if($_G[groupid]!=1){showmessage('&#x5BF9;&#x4E0D;&#x8D77;,&#x4F60;&#x6CA1;&#x6709;&#x6743;&#x9650;&#x6267;&#x884C;&#x6B64;&#x64CD;&#x4F5C;!',dreferer());}
		$cid=intval($_GET['cid']);$type=intval($_GET['type']);
		if($type<3){
			$is_sub=C::t("#bingofans_video#video")->result_first("count(cid)","bingofans_video","cup=$cid");
			if($is_sub)
			cpmsg($la['s6'],'action=plugins&identifier=bingofans_video&pmod=class','error');
			}
		C::t("#bingofans_video#video")->delete_by_where("cid=$cid");

	 	cpmsg($la['s5'],'action=plugins&identifier=bingofans_video&pmod=class','succeed');
	}}else{
		 $fclass= C::t("#bingofans_video#video")->fetch_all("type=1");
		 $sclass= C::t("#bingofans_video#video")->fetch_all("type=2");
		 $tclass= C::t("#bingofans_video#video")->fetch_all("type=3");
		showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier=bingofans_video&pmod=class');
		showtableheader('');
		showsubtitle(array('',lang('plugin/bingofans_video','s1'),'',lang('plugin/bingofans_video','s2'),'','',lang('plugin/bingofans_video','s3')));
		include template("bingofans_video:class");
		showsubmit('submit');
		showtablefooter();
		showformfooter();/*Dism_taobao_com*/
	}
//From: Dism��taobao��com
?>