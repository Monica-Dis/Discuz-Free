<?php
/*
 *	Author: IAN - zhouxingming
 *	Last modified: 2011-09-09 11:25
 *	Filename: xml.inc.php
 *	Description: 
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(submitcheck('addsubmit')) {
	$sign = daddslashes(trim($_G['gp_signnew']));
	if(!empty($sign)) {
		DB::query("INSERT INTO ".DB::table('bingofans_video_xml')." (clientid,sign) VALUES (null,'{$sign}')");
		cpmsg('&#25968;&#25454;&#35843;&#29992;&#28155;&#21152;&#25104;&#21151;', 'action=plugins&operation=config&identifier=bingofans_video&pmod=diy', 'succeed');
	} else {
		cpmsg('&#39564;&#35777;&#23494;&#38053;&#19981;&#33021;&#20026;&#31354;', '', 'error');
	}
} elseif(submitcheck('delsubmit')) {
	$delclientid = $_G['gp_delclientid'];
	foreach($delclientid as $key => $clientid) {
		$clientid = intval($clientid);
		if($clientid) {
			$delclientid[$key] = $clientid;
		} else {
			unset($delclientid[$key]);
		}
	}
	if($delclientid) {
		DB::query("DELETE FROM ".DB::table('bingofans_video_xml')." WHERE clientid IN(".dimplode($delclientid).")");
	}
	cpmsg('&#25968;&#25454;&#35843;&#29992;&#21024;&#38500;&#25104;&#21151;', 'action=plugins&operation=config&identifier=auction&pmod=xml', 'succeed');
} else {
	showtips(str_replace(array('{adminscript}', '{url}'), array(ADMINSCRIPT, $_G['siteurl'].'plugin.php?id=bingofans_video:block_xml'), '<li>&#28155;&#21152;&#25968;&#25454;&#35843;&#29992;&#30340;&#26102;&#20505;&#20250;&#33258;&#21160;&#20998;&#37197;&#23458;&#25143;&#31471;ID</li><li>&#28155;&#21152;&#21518;&#65292;&#21040;&#38376;&#25143;&#20013;&#28155;&#21152;&#31532;&#19977;&#26041;&#27169;&#22359;&#21518;&#21363;&#21487;&#20351;&#29992;DIY&#35843;&#29992;&#32;<a href="{adminscript}?action=blockxml&operation=add" target="_blank">&#28857;&#27492;&#21069;&#24448;</a></li><li>&#31532;&#19977;&#26041;&#22320;&#22336;&#20026;&#58;&#32;{url}</li><li>&#23458;&#25143;&#31471;&#73;&#68;&#21644;&#36890;&#20449;&#23494;&#38053;&#20998;&#21035;&#20026;&#19979;&#38754;&#22635;&#20889;&#30340;&#20869;&#23481;</li>'));
	showtableheader('&#25968;&#25454;&#35843;&#29992;');
	showformheader('plugins&operation=config&identifier=bingofans_video&pmod=diy');
	showtablerow('', array('width="5%"', 'width="10%"', 'width="85%"'), array(
		'&nbsp;',
		'&#23458;&#25143;&#31471;ID',
		'&#36890;&#20449;&#23494;&#38053;',
	));
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('bingofans_video_xml'));
	if($count) {
		$page = intval($_G['gp_page']);
		$page = max(1, $page);
		$each = 15;
		$start = ($page - 1) * $each;
	
		$xml_query = DB::query("SELECT * FROM ".DB::table('bingofans_video_xml')." LIMIT $start,$each");
		while($xml = DB::fetch($xml_query)) {
			showtablerow('', array('width="5%"', 'width="10%"', 'width="85%"'), array(
				'<input type="checkbox" name="delclientid[]" value="'.$xml['clientid'].'" />',
				$xml['clientid'],
				$xml['sign']
				));
		}
		$multi = multi($count, $each, $page, ADMINSCRIPT.'?action=plugins&operation=config&identifier=bingofans_video&pmod=diy');
		showsubmit('delsubmit', 'delete', '', '', $multi);
	} else {
		showtablerow('', array('width="5%"', 'colspan="2"'), array('&nbsp;', '&#27809;&#26377;&#25968;&#25454;&#35843;&#29992;'));
	}

	showformfooter();/*Dism_taobao_com*/
	showtablefooter();

	showtableheader('&#28155;&#21152;&#25968;&#25454;&#35843;&#29992;');
	showformheader('plugins&operation=config&identifier=bingofans_video&pmod=diy');
	showtablerow('', array('width="10%"', 'width="85%"'), array(
		'&#36890;&#20449;&#23494;&#38053;',
		'<input type="text" class="txt" name="signnew" style="width:200px;"/>',
	));
	showsubmit('addsubmit', 'add');
	showformfooter();/*Dism_taobao_com*/
	showtablefooter();
}
//From: Dism��taobao��com
?>