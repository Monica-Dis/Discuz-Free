<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-CN">
<head>
<title>音悦台解析</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style>
html,body,div {
	margin:0;
	padding:0;
	border:0;
	font-size:100%;
	font:inherit;
	vertical-align:baseline;
}body {
	margin:0;
	padding:0;	background:linear-gradient(90deg,#ffb821 0,#ff5c38 45%,#ff1459);
	font-family: 'Tahoma', sans-serif;
	background-size:100% 100%;
	background-attachment: fixed;
    background-position: center;
    
}

.icon {
	padding:15px;
	margin:2% auto;
}
.icon img{
	display:block;
	margin:auto;
}

.shuru {
	text-align:center;
	margin:2% auto;
}
.shuru p {
	color:#048698;
	font-size:20px;
	font-weight:600;
	
}
.shuchu {
	width: 75%;
	padding: 15px;
	color: #999;
	font-size: 17px;
	outline: none;
	background: #E5FFFF; 
	border: none;
	margin:3% auto;
	border-radius:4px;
}
.shuchu p {
	color:#048698;
	font-size:20px;
	font-weight:600;
	
}
input.url {
	width: 65%;
	padding: 15px;
	color: #999;
	font-size: 17px;
	outline: none;
	background: #E5FFFF;
	border: none;
	margin:3% auto;
	border-radius:4px;
}
input[type="submit"] {
	width: 10%;
	border: none;
	outline: none;
	padding: 16px 0px;
	cursor: pointer;
	color:#fff;
	background: #27b1ed; 
	font-size:16px;
	margin-left:1%;
    border-radius: 4px;
}
input[type="submit"]:hover {
	background:#09204E;  
	transition:all 0.5s ease-in-out;
} </style>
<script>
function Jump(){
    var link = document.getElementById('link').value; 
    location.href = '.?url=' + link;}
</script>

</head>
<body>	
		<div class="shuru">
	
						<input type="text" id="link"class="url" placeholder="输入音悦台视频网址"  value="<?php echo $_GET['url']?>">
						<input type="submit"   value="        确定        " onClick="Jump()">
				
		</div>
		<div  class="shuchu">
		  (长时间没有反应，请刷新页面或重新输入地址)<br>
		  解析结果:<br>
		    <HR>
	   <?php
        $urlcut=$_GET['url'];
        if (strrpos($urlcut,'?') == TRUE) 
           {
            $urlcut=substr($urlcut,0,strrpos($urlcut,'?'));
           }
        
        $urlcut=substr($urlcut,strrpos($urlcut,'video/')+6);
        
    
        
    $url = file_get_contents('http://ext.yinyuetai.com/main/get-h-mv-info?json=true&videoId=' . $urlcut);
    $link = json_decode(($url) , true);
    echo $link['videoInfo']['coreVideoInfo']['videoName'].'<HR>';
    $videoUrlModels = $link['videoInfo']['coreVideoInfo']['videoUrlModels'];
    foreach ($videoUrlModels as $kvi) {
        $qualityLevelName = $kvi['qualityLevelName'];
        $videoUrl = $kvi['videoUrl'];
        $end=strrpos($videoUrl,'?');
        $urlend=substr($videoUrl,0,$end);
        
        echo  "".$qualityLevelName. "  ". $urlend. '<a href="http://cytron.cdn.videojj.com/latest/player.iframe.html?appkey=B1zZvOSGl&video='.$urlend.'"target="_blank">播放</a><br>';
       
    }
//From: Dism_taobao-com
?><HR>

	    </div>
	

</body>
</html>