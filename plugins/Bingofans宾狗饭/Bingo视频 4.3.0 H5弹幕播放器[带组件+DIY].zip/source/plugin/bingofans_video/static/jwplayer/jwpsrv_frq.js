jwplayer.jwpsrv.setSampleFrequency(0.001);








