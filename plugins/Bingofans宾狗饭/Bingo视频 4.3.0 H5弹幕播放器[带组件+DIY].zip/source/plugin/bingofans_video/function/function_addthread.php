<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
function add_thread($author,$authorid,$subject,$message,$fid,$typeid){
	$dateline=time();
	$lastpost=$dateline;
	$lastposter=$author;
	$status=32;	
$newthread=array(
'fid'=>$fid,
'typeid'=>$typeid,
'author'=>$author,
'authorid'=>$authorid,
'subject'=>$subject,
'dateline'=>$dateline,
'lastpost'=>$lastpost,
'lastposter'=>$lastposter,
'status'=>$status
);
$tid=DB::insert('forum_thread',daddslashes($newthread),true);	
$newpost=array(
'tid'=>$tid,
'fid'=>$fid,
'first'=>1,
'author'=>$author,
'authorid'=>$authorid,
'subject'=>$subject,
'dateline'=>$dateline,
'message'=>$message,
'useip'=>$_SERVER["REMOTE_ADDR"],
'usesig'=>1,
'smileyoff'=>-1,
'position'=>1
);
$pid=dxksst_insertpost(daddslashes($newpost));
$lastpost = "$tid\t$subject\t".time()."\t$author";
C::t("#bingofans_video#video")->after_success_insert(array('authorid'=>$authorid,"author"=>$author),$tid,$fid,daddslashes($lastpost));
return $tid;	
	}
function dxksst_insertpost($data) {
	if(isset($data['tid'])) {
		$thread = C::t('forum_thread')->fetch($data['tid']);
		$tableid = $thread['posttableid'];
	} else {
		$tableid = $data['tid'] = 0;
	}
	$pid = C::t('forum_post_tableid')->insert(array('pid' => null), true);


	$data = array_merge($data, array('pid' => $pid));

	C::t('forum_post')->insert($tableid, $data);
	if ($_G[groupid]!=1) {
	if($pid % 1024 == 0) {
		C::t('forum_post_tableid')->delete_by_lesspid($pid);
	}
	}
	savecache('max_post_id', $pid);
	return $pid;
}
//From: Dism��taobao��com
?>