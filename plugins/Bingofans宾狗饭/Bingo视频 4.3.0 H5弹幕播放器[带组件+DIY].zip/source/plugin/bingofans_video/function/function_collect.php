<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function bingofans_collect($url){
	if(preg_match('/56\.com/',$url)){//56
	  require_once libfile("function/56","plugin/bingofans_video");
		if(preg_match('/album\-aid\-([0-9]{1,20})/',$url,$match)){
		   $post=get_album_by_aid($match[1]);
		   $_GET['subject']=diconv($post['title'],"utf-8");
		   $_GET['videoname']=$post['videoname'];
		   $_GET['videolink']=$post['videolink'];
		   $_GET['videoimg']=$post['videoimg'];
		   $_GET['videotime']=$post['videotime'];
		   $_GET['coverimg']=$post['cover'];
		   $_GET['editorValue']=diconv($post['info'],"utf-8");
		   }elseif(preg_match('/v_([0-9a-zA-Z]{6,20}|[0-9]{1,20})/',$url,$match)){
			 $post=get_video_by_vid($match[1]);
			 $_GET['videoname']=$_GET['subject']=diconv($post['title'],"utf-8");
			 $_GET['coverimg']=$post['bimg'];
			 $_GET['videolink']=$post['swf'];
			 $_GET['videoimg']=$post['bimg'];
			 $_GET['videotime']=time();
			 $_GET['editorValue']=diconv($post['desc'],"utf-8");
		   }	
	}elseif(preg_match('/youku\.com/',$url)){//youku
	 if(!fopen(libfile("function/youku","plugin/bingofans_video"),'r'))showmessage('&#23545;&#19981;&#36215;&#44;&#27492;&#32593;&#31449;&#23578;&#26410;&#36141;&#20080;&#20248;&#37239;&#37319;&#38598;&#27169;&#22359;&#65281;');
		 require_once libfile("function/youku","plugin/bingofans_video");
		 if(preg_match('/v_show\/id_([0-9a-zA-Z]{6,20})/',$url,$match)){//video
			$post=get_youkuvideo_by_vid($match[1]);
				$_GET['videoname']=$_GET['subject']=diconv($post['title'],"utf-8");
				$_GET['coverimg']=$post['bigThumbnail'];
				$_GET['videolink']=$post['player'];
				$_GET['videoimg']=$post['bigThumbnail'];
				$_GET['videotime']=time();
				$_GET['editorValue']=diconv($post['description'],"utf-8");
			 }elseif(preg_match('/show\/id_([0-9a-zA-Z]{6,20})/',$url,$match)){
				 $post=get_playlist_byid($match[1]);
					$_GET['subject']=$post['videoname'][0];
					$_GET['videoname']=$post['videoname'];
					$_GET['videolink']=$post['videolink'];
					$_GET['videoimg']=$post['videoimg'];
					$_GET['videotime']=$post['videotime'];
					$_GET['coverimg']=$post['videoimg'][0];
			 }
		 
	}elseif(preg_match('/tudou\.com/',$url)){
	if(!fopen(libfile("function/tudou","plugin/bingofans_video"),'r'))showmessage('&#23545;&#19981;&#36215;&#44;&#27492;&#32593;&#31449;&#23578;&#26410;&#36141;&#20080;&#22303;&#35910;&#37319;&#38598;&#27169;&#22359;&#65281;');
	  require_once libfile("function/tudou","plugin/bingofans_video");
		 if(preg_match('/v\/([0-9a-zA-Z\-_]{6,20})/',$url,$match)){//video//http://new-play.tudou.com/v/681458358.html
			$post=get_tudouv_by_id($match[1]);
				$_GET['videoname']=$_GET['subject']=diconv($post['title'],"utf-8");
				$_GET['coverimg']=$post['bigPicUrl'];
				$_GET['videolink']=$post['outerPlayerUrl'];
				$_GET['videoimg']=$post['bigPicUrl'];
				$_GET['videotime']=time();
				$_GET['editorValue']=diconv($post['description'],"utf-8");
			 }elseif(preg_match('/listplay\/([0-9a-zA-Z\-_]{6,20})/',$url,$match)){//http://www.tudou.com/listplay/31kTSBmnsKk/JUFDsHRypSo.html
				 $post=get_tplaylist_byid($match[1]);
					$_GET['subject']=$post['videoname'][0];
					$_GET['videoname']=$post['videoname'];
					$_GET['videolink']=$post['videolink'];
					$_GET['videoimg']=$post['videoimg'];
					$_GET['videotime']=$post['videotime'];
					$_GET['coverimg']=$post['videoimg'][0];
				 }
	}elseif(preg_match('/youtube\.com\/watch\?v\=(.*)/',$url,$match)){//https://www.youtube.com/watch?v=q0BG5bppVUQ
	if(!fopen(libfile("function/youtube","plugin/bingofans_video"),'r'))showmessage('&#35831;&#36141;&#20080;&#121;&#111;&#117;&#116;&#117;&#98;&#101;&#37319;&#38598;&#27169;&#22359;');
					  require_once libfile("function/youtube","plugin/bingofans_video");
					$post = getYouTubeInfo($match[1]);
					$_GET['videoname'] = $_GET['subject']=diconv($post['title'],"utf-8");
					$_GET['videolink'] = $post['url'];
					$_GET['coverimg'] = $_GET['videoimg']=$post['img'];
					$_GET['videotime'] = $post['time'];
					$_GET['editorValue']=diconv($post['description'],"utf-8");
					 
					 }
if(empty($_GET['subject'])){
	showmessage("&#23545;&#19981;&#36215;&#65292;&#19981;&#25903;&#25345;&#27492;&#85;&#82;&#76;&#35268;&#21017;&#30340;&#37319;&#38598;&#32;&#65281;");
	}	
}
//From: Dism��taobao��com
?>