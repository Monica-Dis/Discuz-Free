<?php
/**
 * 		Copyright��bingoufan
 * 		  WebSite��www.bingoufan.com
 *             QQ: 250070723
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
define("bingofans_SMILEY_DIR","source/plugin/bingofans_video/static/images/0/");
function insert_new_reply(){
	    global $_G;
		$tid=intval($_GET['tid']);
		$post=array(
		'tid'=>$tid,
		'author'=>$_G['username'],
		'authorid'=>$_G['uid'],
		'audio'=>'',
		'message'=>$_GET['content'],
		'fname'=>'',
		'first'=>0,
		'dateline'=>time()
		);
		C::t("#bingofans_video#video")->increase_by_where('bingofans_video_thread','reply',"tid=$tid");
		bingofans_record(1);
		return C::t("#bingofans_video#video")->insert_new("bingofans_video_post",daddslashes($post),true);		
 	}						
function get_smiley(){
return array(
":ali01:"=>"ali01.gif",
":ali02:"=>"ali02.gif",
":ali03:"=>"ali03.gif",
":ali04:"=>"ali04.gif",
":ali05:"=>"ali05.gif",
":ali06:"=>"ali06.gif",
":ali07:"=>"ali07.gif",
":ali08:"=>"ali08.gif",
":ali09:"=>"ali09.gif",
":ali10:"=>"ali10.gif",
":ali11:"=>"ali11.gif",
":ali12:"=>"ali12.gif",
":ali13:"=>"ali13.gif",
":ali14:"=>"ali14.gif",
":ali15:"=>"ali15.gif",
":ali16:"=>"ali16.gif",
":ali17:"=>"ali17.gif",
":ali18:"=>"ali18.gif",
":ali19:"=>"ali19.gif",
":ali20:"=>"ali20.gif",
":ali21:"=>"ali21.gif",
":ali22:"=>"ali22.gif",
":ali23:"=>"ali23.gif",
":ali24:"=>"ali24.gif",
":ali25:"=>"ali25.gif");}
function deal_smile($str){
	 $smiley=get_smiley();
	foreach($smiley as$k=>$v){
		$str=str_replace($k,'<img  style=" height:60px;width:60px;"src="'.bingofans_SMILEY_DIR.$v.'"/>',$str);
		}
	return $str;	
	}
//From: Dism��taobao��com
?>