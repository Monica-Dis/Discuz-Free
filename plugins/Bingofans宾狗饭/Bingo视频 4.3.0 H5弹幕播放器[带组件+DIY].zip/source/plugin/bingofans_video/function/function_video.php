<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
define("bingofans_video_URL","plugin.php?id=bingofans_video");
define("bingofans_video_DIR","source/plugin/bingofans_video/");
function get_turl($tid){
	global $_G;
	$bingofans=$_G['cache']['plugin']['bingofans_video'];
	if($bingofans['seo'] == 1){
	return "$bingofans[ruphp]mod=v&tid=$tid";			
	}
	if($bingofans['seo'] == 2){
	return "vid-$tid.html";
	}
	if($bingofans['seo'] == 3){
		if($_G['uid']){	
	return "$bingofans[ruphp]mod=v&tid=$tid";
        }else{
	return "vid-$tid.html";
		}	
	}	
}
function get_furl($fcid=0,$scid=0,$tcid=0){
	global $_G;
	$bingofans=$_G['cache']['plugin']['bingofans_video'];
	if($bingofans['seo'] == 1){
	return "$bingofans[ruphp]mod=s&fcid=$fcid&scid=$scid&tcid=$tcid";			
	}
	if($bingofans['seo'] == 2){
	return "so-$fcid-$scid-$tcid.html";
	}
	if($bingofans['seo'] == 3){
		if($_G['uid']){	
	return "$bingofans[ruphp]mod=s&fcid=$fcid&scid=$scid&tcid=$tcid";
        }else{
	return "so-$fcid-$scid-$tcid.html";
		}	
	}	
}	
function check_uploaddir(){
	$ym=date("Ym");$d=date("d");
	$main_dir=DISCUZ_ROOT."source/plugin/bingofans_video/upload/";
	if(!is_dir($main_dir))mkdir($main_dir);
	if(!is_dir($main_dir.$ym."/")) mkdir($main_dir.$ym."/");
	if(!is_dir($main_dir.$ym."/".$d."/")) mkdir($main_dir.$ym."/".$d."/");
	return "source/plugin/bingofans_video/upload/".$ym."/".$d."/";
}
function get_all_class(){
		 $class= C::t("#bingofans_video#video")->fetch_all("1=1");
	     $cache=array();
		 foreach($class as$ck=>$cv){
			 $cache[$cv[cid]]=$cv;
			 }
		return $cache;	  
	}
function myhtmlspe($str){
   if(is_array($str)){
	   foreach($str as$sk=>$sv){
		   $str[$sk]=myhtmlspe($sv);
		   } 
	}else{
	$str=str_replace("<","&lt;",$str);
	$str=str_replace(">","&gt;",$str);
	}
	return $str;
	}	
function is_have_empty($ar){
	foreach($ar as$k=>$v){
		if(!is_array($v)){
			if(empty($v))return true;
			}else{
			is_have_empty($v);
			}	
		}
	return false;
	}
function get_bootstrap_page($num,$perpage=12,$page,$url,$around=10){
	if(!$num)return ;
	$perpage=max(1,$perpage);
	$upage=max(1,$page-1);
	$tpage=$num%$perpage?intval($num/$perpage)+1:intval($num/$perpage);
	if($tpage==1)return;
	$page=min($page,$tpage);
	$nextpage=min(($page+1),$tpage);
		$html='<ul class="pagination">';
	$html.='<li><a href="'.$url."&page=$upage".'">&laquo;</a></li>';
	for($i=0;$i<=2*$around;$i++){
	$thispage=$page-$around+$i;
	if(($thispage>=1)&&($thispage<=$tpage)){
		if($thispage==$page){
			$html.='<li class="active"><a>'.$thispage.'</a></li>';
			}else{
				$html.='<li><a href="'.$url."&page=$thispage".'">'.$thispage.'</a></li>';
				
				}
			
		}
	
		
	}
		$html.='<li><a href="'.$url."&page=$upage".'">&raquo;</a></li></ul>';
return $html;	
}	
function get_bingofans_page($num,$perpage=12,$page,$url,$around=10,$ajax=1,$id="main"){
	if(!$num)return ;
	$perpage=max(1,$perpage);
	$html='<div class="pg"><a class="prev" ';
	$upage=max(1,$page-1);
	$html.=$ajax?'href="javascript:;" onclick="ajaxget(\''.$url.'&page='.$upage.'\',\''.$id.'\',null,null,null,null)">':'href="'.$url.'&page='.$upage.'">';
	$html.='</a>';
	$tpage=$num%$perpage?intval($num/$perpage)+1:intval($num/$perpage);
	if($tpage==1)return;
	$page=min($page,$tpage);
	for($i=0;$i<=2*$around;$i++){
	$thispage=$page-$around+$i;
	if(($thispage>=1)&&($thispage<=$tpage))
	if($thispage==$page){
	    $html.="<strong>$thispage</strong>";
	}else{
		$html.=$ajax?'<a href="javascript:;" onclick="ajaxget(\''.$url.'&page='.$thispage.'\',\''.$id.'\',null,null,null,null)">'.$thispage.'</a>':'<a href="'.$url.'&page='.$thispage.'">'.$thispage.'</a>';
		}
	
	}
	$js=$ajax?"ajaxget('{$url}&page='+this.value,'$id',null,null,null,null)":"window.location='{url}&page='+this.value";
	$html.='<label><input type="text" name="custompage" class="px" size="2" title="&#x8F93;&#x5165;&#x9875;&#x7801;&#xFF0C;&#x6309;&#x56DE;&#x8F66;&#x5FEB;&#x901F;&#x8DF3;&#x8F6C;" value="'.$page.'" onkeydown="if(event.keyCode==13) {'.$js.'; doane(event);}"><span title="&#x5171; '.$tpage.' &#x9875;"> / '.$tpage.' &#x9875;</span></label>';
	$html.='<a class="nxt" ';
	$nextpage=min(($page+1),$tpage);
	$html.=$ajax?'<a href="javascript:;" onclick="ajaxget(\''.$url.'&page='.$nextpage.'\',\''.$id.'\',null,null,null,null)">':'<a href="'.$url.'&page='.$nextpage.'">';
	$html.='&#x4E0B;&#x4E00;&#x9875;</a>';
	$html.='</div>';
	return $html;
	}
function insert_new_thread($lan,$collect=0){
	if(!$_GET['subject'])showmessage("&#19981;&#25903;&#25345;&#27492;&#117;&#114;&#108;&#38142;&#25509;&#26679;&#24335;&#30340;&#37319;&#38598;&#44;&#25110;&#32773;&#26631;&#39064;&#20026;&#31354;&#65281;");
	    global $_G;
		$bingofans=$_G['cache']['plugin']['bingofans_video'];
		$shen=unserialize($bingofans['shen']);
		$visiable=in_array($_G[groupid],$shen)?0:1;
		if(!$collect){
		$dir=check_uploaddir();
		$filename=time().rand(1, 10000).".png";
		move_uploaded_file($_FILES['coverimg']['tmp_name'],DISCUZ_ROOT.$dir.$filename);
		$imgsrc=$dir.$filename;
		}else{
		$imgsrc=$_GET['coverimg'];	
			}
		$thread=array(
		'author'=>$_G['username'],
		'authorid'=>$_G['uid'],
		'subject'=>$_GET['subject'],
		'coverimg'=>$imgsrc,
		'grade'=>0,
		'gnum'=>0,
		'fcid'=>intval($_GET['fcid']),
		'scid'=>intval($_GET['scid']),
		'tcid'=>intval($_GET['tcid']),
		'visiable'=>$visiable,
		'num'=>count($_GET['videoname']),
		'dateline'=>time()
		);
		$check_t=$thread;
		$tid=C::t("#bingofans_video#video")->insert_new("bingofans_video_thread",daddslashes($thread),true);
		$fcid=intval($_GET['fcid']);
		$fname=C::t("#bingofans_video#video")->result_first('name',"bingofans_video","cid=$fcid");
		$mes=$_GET['editorValue'];
		$videoname=$_GET['videoname'];$audio=array();$videolink=$_GET['videolink'];$videotime=$_GET['videotime'];
		$videoimg=$_GET['videoimg'];
		if(is_array($videoname)){
		foreach($videoname as$kvideo=>$vvideo){
			$tmp['name']=$vvideo;$tmp['link']=$videolink[$kvideo];
			$tmp['img']=$videoimg[$kvideo];$tmp['time']=$videotime[$kvideo]?$videotime[$kvideo]:time();
			$audio[]=$tmp;
			}
		}else{
			$audio[0]['name']=$videoname;
			$audio[0]['link']=$videolink;
			$audio[0]['img']=$videoimg;
			$audio[0]['time']=$videotime;
			}
		$video = $audio;			
		$audio=serialize($audio);	
		$post=array(
		'tid'=>$tid,
		'author'=>$_G['username'],
		'authorid'=>$_G['uid'],
		'audio'=>$audio,
		'message'=>$mes,
		'fname'=>$fname,
		'first'=>1,
		'dateline'=>time()
		);
		$pid=C::t("#bingofans_video#video")->insert_new("bingofans_video_post",daddslashes($post),true);
		bingofans_record(0,$tid,$_GET['subject']);
		tongbu($tid,$bingofans['tongbu'],$thread,$mes,$video);//
		showmessage($lan['p1'],"$bingofans[ruphp]mod=v&tid=$tid",'succeed');
	}
function bingofans_record($reply=0,$tid,$subject){
	global $_G;$uid=$_G['uid'];
	if(!$uid)return ;
	$have=C::t("#bingofans_video#video")->result_first('uid','bingofans_video_user',"uid=$uid");
	if(!$have)$id=C::t("#bingofans_video#video")->insert_new('bingofans_video_user',array("uid"=>$uid,"username"=>$_G['username'],"dateline"=>time()),true);
    if(!$reply){
		C::t("#bingofans_video#video")->increase_by_where('bingofans_video_user','threads',"uid=$uid");
	    C::t("#bingofans_video#video")->update_by_where('bingofans_video_user',array('tid'=>intval($tid),'subject'=>daddslashes($subject)),"uid=$uid");
	}
	C::t("#bingofans_video#video")->increase_by_where('bingofans_video_user','posts',"uid=$uid");
	}	
function bingofans_cache(){
	    global $_G;
		$bingofans=$_G['cache']['plugin']['bingofans_video'];
                $recom_num = $bingofans['is_wide']?8:6;
                $left_row = $bingofans['left_rows']?$bingofans['left_rows']:1;
                $left_num = $left_row*($bingofans['is_wide']?6:4);
        $hot=C::t("#bingofans_video#video")->fetch_all_by_where('bingofans_video_thread','visiable=1','play desc,dateline desc',0,10);
		$boke=C::t("#bingofans_video#video")->fetch_all_by_where('bingofans_video_user','threads<>0','threads desc',0,8);
		if(empty($bingofans['recom'])){
		$new=C::t("#bingofans_video#video")->fetch_all_by_where('bingofans_video_thread','visiable=1','dateline desc',0,$recom_num);
		}else{
		$n_tids=explode("|",$bingofans['recom']);
		$new=C::t("#bingofans_video#video")->fetch_all_by_array('bingofans_video_thread','tid',$n_tids);
			}
		$fclass= C::t("#bingofans_video#video")->fetch_all("type=1");
		$enew=array();
		foreach($fclass as $k=>$v){
		$enew[]=C::t("#bingofans_video#video")->fetch_all_by_where('bingofans_video_thread','fcid='.intval($fclass[$k]['cid'])." and visiable=1",'dateline desc',0,$left_num);
		}
		$bingofans_video=array('new'=>$new,'hot'=>$hot,'fclass'=>$fclass,'enew'=>$enew,'boke'=>$boke,'time'=>time());
		require_once libfile("function/cache");
		writetocache('bingofans_video', getcachevars(array('bingofans_video' =>$bingofans_video)));
	return $bingofans_video;
	}
function bingofans_get_ext($name){
	$na_ar=explode('.',$name);
	$max=count($na_ar)-1;
	$ext=$na_ar[$max];
	$ext=$ext?$ext:'png';
	return $ext;
	}
function get_bingofans_url($str,$tid,$order,$img=0){
	global $_G;$bingofans=$_G['cache']['plugin']['bingofans_video'];
	if(preg_match('/^source/',$str)){
		return $_G['siteurl'].$str;
		//if($img){return $_G['siteurl'].$str;}
		$tid=intval($tid);$order=intval($order);
		return $_G['siteurl']."plugin.php?id=bingofans_video&mod=url&tid=$tid&order=$order&urlsubmit=1&formhash=".FORMHASH;
		}elseif(preg_match('/^qn/',$str)){	
		$bingofans_qn=init_qn();
		$object=str_replace($bingofans['qnossurl'],'',$str);
		$return=$bingofans_qn?$bingofans_qn->get_sign_url($object):'not set oss';
		return $return;
		}else{
		return $str;	
			}
	}
function init_qn(){
		global $_G;
		$bingofans=$_G['cache']['plugin']['bingofans_video'];
		require_once 'source/plugin/bingofans_video/qn.class.php';
		$ak=trim($bingofans["ak"]);
		$sk=trim($bingofans["sk"]);
		$bucket=trim($bingofans["bucket"]);
		if($ak&&$sk&&$bucket){
		$bingofans_qn=new bingofans_qn($ak,$sk,$bucket);
		return $bingofans_qn;
		}else{
		return NULL;	
			}
	}
function get_bingofans_player($url){
if(preg_match('/56\.com/',$url)){
	if(preg_match('/_([0-9a-zA-Z]{1,20})\.swf/',$url,$match)){
	$player='<iframe height="100%" width="100%" src="http://www.56.com/iframe/'.$match[1].'" frameborder=0 allowfullscreen></iframe>';
	}
	}elseif(preg_match('/youku\.com/',$url)){
	if(preg_match('/\/sid\/([0-9a-zA-Z=]{6,50})\//',$url,$match)){
	$player=''.$match[1].'';
	}
	}elseif(preg_match('/youtube.com/',$url)){
		$player='<iframe width="100%" height="100%" src="'.str_replace('.swf','',$url).'" frameborder="0" allowfullscreen></iframe>';
	}
	if(!$player){
	$player='<embed  width="100%" height="100%" src="'.$url.'" allowFullScreen="true" quality="high"align="middle" allowScriptAccess="always" type="application/x-shockwave-flash"></embed>';
	}
	return $player;
}
function get_bingofans1_player($url){
if(preg_match('/56\.com/',$url)){
	if(preg_match('/_([0-9a-zA-Z]{1,20})\.swf/',$url,$match)){
	$player='<iframe height="100%" width="100%" src="http://www.56.com/iframe/'.$match[1].'" frameborder=0 allowfullscreen></iframe>';
	}
	}elseif(preg_match('/youku\.com/',$url)){
	if(preg_match('/\/sid\/([0-9a-zA-Z=]{6,50})\//',$url,$match)){
	$player='<iframe width="100%" height="100%" src="//player.youku.com/embed/'.$match[1].'?client_id=fa263b22a8f7c671&password=&autoplay=false#www.bingoufan.com" id="iframeId" frameborder="0" allowfullscreen="true" scrolling="no"></iframe>';
	}
	}elseif(preg_match('/youtube.com/',$url)){
		$player='<iframe width="100%" height="100%" src="'.str_replace('.swf','',$url).'" frameborder="0" allowfullscreen></iframe>';
	}elseif(preg_match('/player.bilibili.com/',$url)){
		$player='<iframe width="100%" height="100%" src="'.str_replace('.swf','',$url).'" frameborder="0" allowfullscreen></iframe>';
	}elseif(preg_match('/player.yinyuetai.com/',$url)){
		$player='<iframe width="100%" height="100%" src="'.str_replace('.swf','',$url).'" frameborder="0" allowfullscreen></iframe>';
	}elseif(preg_match('/.+\//',$url)){
	if(preg_match('/([0-9a-zA-Z]{1,50}).mp4|.MP4|.avi|.AVI|.wma|.WMA|.rmvb|.RMVB|.rm|.RM|.flash|.FLASH|.mid|.MID|.3gp|.3GP|.flv|.FLV|.mkv|.mov|.MOV|.M3U8|.m3u8|.MKV/',$url,$match)){
	$player='<link rel="stylesheet" type="text/css" href="source/plugin/bingofans_video/template/new/play/css/reset.css"><link rel="stylesheet" href="source/plugin/bingofans_video/template/new/play/bootstrap/css/bootstrap.css"><link rel="stylesheet" type="text/css" href="source/plugin/bingofans_video/template/new/play/css/willesPlay.css"><script src="source/plugin/bingofans_video/template/new/play/js/jquery-1.11.3.min.js" type="text/javascript" charset=gbk></script><script src="source/plugin/bingofans_video/template/new/play/js/willesPlay.js" type="text/javascript" charset=gbk></script><div class="container"><div class="row"><div class="col-md-12"><div id="willesPlay"><div class="playContent"><div class="turnoff"><ul><li><a href="javascript:;" title="&#x559C;&#x6B22;" class="glyphicon glyphicon-heart-empty"></a></li><li><a href="javascript:;" title="&#x5173;&#x706F;" class="btnLight on glyphicon glyphicon-sunglasses"></a></li><li><a href="javascript:;" title="&#x5206;&#x4EAB;" class="glyphicon glyphicon-share"></a></li></ul></div><video width="100%" height="100%" id="playVideo"><source src="'.$url.'" type="video/mp4"></source>&#x5F53;&#x524D;&#x6D4F;&#x89C8;&#x5668;&#x4E0D;&#x652F;&#x6301;video&#x76F4;&#x63A5;&#x64AD;&#x653E;&#xFF0C;&#x70B9;&#x51FB;&#x8FD9;&#x91CC;&#x4E0B;&#x8F7D;&#x89C6;&#x9891;&#xFF1A; <a href="/">&#x4E0B;&#x8F7D;&#x89C6;&#x9891;</a></video><div class="playTip glyphicon glyphicon-play"></div></div><div class="playControll fullControll" style="left: 0px; bottom: 0px;"><div class="playPause playIcon"></div><div class="timebar"><span class="currentTime">0:00:00</span><div class="progress"><div class="progress-bar progress-bar-danger progress-bar-striped" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:0"></div></div><span class="duration">0:00:00</span></div><div class="otherControl"><span class="volume glyphicon glyphicon-volume-down"></span> <span class="fullScreen glyphicon glyphicon-fullscreen"></span><div class="volumeBar"><div class="volumewrap"><div class="progress"><div class="progress-bar progress-bar-danger" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width:8px;height:40%"></div></div></div></div></div></div></div></div></div></div>';
	}}
	if(!$player){
	$player='<embed  width="100%" height="100%" src="'.$url.'" allowFullScreen="true" quality="high"align="middle" allowScriptAccess="always" type="application/x-shockwave-flash"></embed>';
	}
	return $player;
}
function get_bingofans2_player($url){
if(preg_match('/56\.com/',$url)){
	if(preg_match('/_([0-9a-zA-Z]{1,20})\.swf/',$url,$match)){
	$player='<iframe height="100%" width="100%" src="http://www.56.com/iframe/'.$match[1].'" frameborder=0 allowfullscreen></iframe>';
	}
	}elseif(preg_match('/youku\.com/',$url)){
	if(preg_match('/\/sid\/([0-9a-zA-Z=]{6,50})\//',$url,$match)){
	$player='<iframe width="100%" height="100%" src="//player.youku.com/embed/'.$match[1].'?client_id=fa263b22a8f7c671&password=&autoplay=false#www.bingoufan.com" id="iframeId" frameborder="0" allowfullscreen="true" scrolling="no"></iframe>';
	}
	}elseif(preg_match('/youtube.com/',$url)){
		$player='<iframe width="100%" height="100%" src="'.str_replace('.swf','',$url).'" frameborder="0" allowfullscreen></iframe>';
	}elseif(preg_match('/player.bilibili.com/',$url)){
		$player='<iframe width="100%" height="100%" src="'.str_replace('.swf','',$url).'" frameborder="0" allowfullscreen></iframe>';
	}elseif(preg_match('/player.yinyuetai.com/',$url)){
		$player='<iframe width="100%" height="100%" src="'.str_replace('.swf','',$url).'" frameborder="0" allowfullscreen></iframe>';
	}elseif(preg_match('/v.qq.com/',$url)){
		$player='<iframe frameborder="0" width="100%" height="100%" src="'.str_replace('.swf','',$url).'" allowfullscreen></iframe>';
	}elseif(preg_match('/.+\//',$url)){
	if(preg_match('/([0-9a-zA-Z]{1,50}).mp4|.MP4|.avi|.AVI|.wma|.WMA|.rmvb|.RMVB|.rm|.RM|.flash|.FLASH|.mid|.MID|.3gp|.3GP|.flv|.FLV|.mkv|.mov|.MOV|.M3U8|.m3u8|.MKV/',$url,$match)){
	$player='<div id="a1"></div><script type="text/javascript" src="source/plugin/bingofans_video/template/ckplayer/ckplayer.js" charset=gbk></script><script type="text/javascript">function closelights(){alert(" ����ʾ��֧�ֿ��ص�")}function openlights(){alert(" ����ʾ��֧�ֿ��ص�")}var flashvars={f:"'.$url.'",a:"",s:0,c:0,h:3,l:"source/plugin/bingofans_video/template/play/videoad.jpg",r:"/",t:5,d:"source/plugin/bingofans_video/template/play/videoad.jpg",u:"/",z:"source/plugin/bingofans_video/template/play/logo.png",my_url:encodeURIComponent(window.location.href),my_title:encodeURIComponent(document.title),p:1,loaded:"loadedHandler",b:0},params={bgcolor:"#FFF",allowFullScreen:!0,allowScriptAccess:"always",wmode:"transparent"};CKobject.embedSWF("source/plugin/bingofans_video/template/ckplayer/ckplayer.swf","a1","ckplayer_a1","100%","474",flashvars,params);var video=["'.$url.'"],support=["iPad","iPhone","ios","android+false","msie10+false"];CKobject.embedHTML5("a1","ckplayer_a1",600,400,video,flashvars,support);</script>';
	}}
	if(!$player){
	$player='<embed  width="100%" height="100%" src="'.$url.'" allowFullScreen="true" quality="high"align="middle" allowScriptAccess="always" type="application/x-shockwave-flash"></embed>';
	}
	return $player;
}
function get_bingofans_ali_player($url){
if(preg_match('/56\.com/',$url)){
	if(preg_match('/_([0-9a-zA-Z]{1,20})\.swf/',$url,$match)){
	$player='<iframe height="100%" width="100%" src="http://www.56.com/iframe/'.$match[1].'" frameborder=0 allowfullscreen></iframe>';
	}
	}elseif(preg_match('/youku\.com/',$url)){
	if(preg_match('/\/sid\/([0-9a-zA-Z=]{6,50})\//',$url,$match)){
	$player='<iframe width="100%" height="100%" src="//player.youku.com/embed/'.$match[1].'?client_id=fa263b22a8f7c671&password=&autoplay=false#www.bingoufan.com" id="iframeId" frameborder="0" allowfullscreen="true" scrolling="no"></iframe>';
	}
	}elseif(preg_match('/youtube.com/',$url)){
		$player='<iframe width="100%" height="100%" src="'.str_replace('.swf','',$url).'" frameborder="0" allowfullscreen></iframe>';
	}elseif(preg_match('/player.bilibili.com/',$url)){
		$player='<iframe width="100%" height="100%" src="'.str_replace('.swf','',$url).'" frameborder="0" allowfullscreen></iframe>';
	}elseif(preg_match('/player.yinyuetai.com/',$url)){
		$player='<iframe width="100%" height="100%" src="'.str_replace('.swf','',$url).'" frameborder="0" allowfullscreen></iframe>';
	}elseif(preg_match('/v.qq.com/',$url)){
		$player='<iframe frameborder="0" width="100%" height="100%" src="'.str_replace('.swf','',$url).'" allowfullscreen></iframe>';
	}elseif(preg_match('/.+\//',$url)){
	if(preg_match('/([0-9a-zA-Z]{1,50}).mp4|.MP4|.avi|.AVI|.wma|.WMA|.rmvb|.RMVB|.rm|.RM|.flash|.FLASH|.mid|.MID|.3gp|.3GP|.flv|.FLV|.mkv|.mov|.MOV|.M3U8|.m3u8|.MKV/',$url,$match)){
	$player=''.$url.'';
	}}
	if(!$player){
	$player=''.$url.'';
	}
	return $player;
}
function tongbu($tid,$fid,$thread,$mes,$video){
	if($fid){
	  require libfile("function/addthread","plugin/bingofans_video");
	  $url = get_turl($tid);
	  foreach($video as $v=>$vv){
		  $str .= "[free][img=300,0]".get_bingofans_url($vv[img],$tid,$v,1)."[/img][/p]&#28857;&#20987;&#35266;&#30475;:".$vv[name].'[/p]'; 
		  }
		$mes = "[url=$url]{$str}[/url][/free]".$mes;
		add_thread($thread['author'],$thread['authorid'],$thread['subject'],$mes,$fid,0);
		}
	return $tid;
	}													
?>