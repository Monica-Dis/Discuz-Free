<?php
/**
 * 		Copyright：bingoufan
 * 		  WebSite：www.bingoufan.com
 *             QQ:250070723
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$blockclass = array(
	'name' => '宾狗视频',
);

?>