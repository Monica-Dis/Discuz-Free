<?php

/**
 *      [BingoFans!] (C)2001-2099 bingoufan.com.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: block_video.php
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class block_bingovideo extends discuz_block {

    function name() {
        return '高级自定义';
    }

    function blockclass() {
        return array('video', '视频模块');
    }

    function fields() {
        return array(
            'url' => array('name' => '视频URL', 'formtype' => 'text', 'datatype' => 'string'),
            'title' => array('name' => '视频名称', 'formtype' => 'title', 'datatype' => 'title'),
            'summary' => array('name' => '视频简介', 'formtype' => 'summary', 'datatype' => 'summary'),
            'pic' => array('name' => '视频图片', 'formtype' => 'pic', 'datatype' => 'pic'),
            'imgsrc' => array('name' => '视频图片备用', 'formtype' => 'pic', 'datatype' => 'pic'),
			'author' => array('name' => '发布者', 'formtype' => 'text', 'datatype' => 'text'),
            'authorid' => array('name' => '发布者ID', 'formtype' => 'text', 'datatype' => 'int'),
			'dateline' => array('name' => '发布时间', 'formtype' => 'date', 'datatype' => 'date'),
            'play' => array('name' => '查看数', 'formtype' => 'text', 'datatype' => 'int'),
            'reply' => array('name' => '回复数', 'formtype' => 'text', 'datatype' => 'int'),
            'width' => array('name' => '宽度', 'formtype' => 'text', 'datatype' => 'int'),
            'height' => array('name' => '高度', 'formtype' => 'text', 'datatype' => 'int'),
        );
    }

    function getsetting() {
        global $_G;
        $cate = $this->get_format_class(0);
        $cate = array_merge(array(0=>array(0, '全部分类')), $cate);
        return array(
            'video_id' => array(
                'title' => '指定视频',
                'type' => 'text'
            ),
            'cate_id' => array(
                'title' => '类别',
                'type' => 'mselect',
                'value' => $cate
            ),
            'orderby' => array(
                'title' => '排序方式',
                'type' => 'mradio',
                'value' => array(
                    array('time', '按时间倒序排序'),
                    array('play', '按查看数倒序排序'),
                    array('replay', '按回复多少倒序排序'),
                    array('rand', '随机数据排序(新增测试版)'),
                ),
                'default' => 'time'
            ),
            'titlelength' => array(
                'title' => '标题长度',
                'type' => 'text',
                'default' => 40
            ),
            'summarylength' => array(
                'title' => '简介长度',
                'type' => 'text',
                'default' => 80
            ),
            'width' => array(
                'title' => '图片宽度',
                'type' => 'text',
                'default' => 100
            ),
            'height' => array(
                'title' => '图片高度',
                'type' => 'text',
                'default' => 100
            )
        );
    }

    function getdata($style, $parameter) {
        global $_G;
        writelog('bingofans_log', var_export($parameter, true));
        require_once libfile("function/video", "plugin/bingofans_video");
        $param['video_id'] = !empty($parameter['video_id']) ? explode(',', $parameter['video_id']) : array();
        $param['cate_id'] = !empty($parameter['cate_id']) && $parameter['cate_id'] != array('0') ? $parameter['cate_id'] : array();
        $param['orderby'] = !empty($parameter['orderby']) ? $parameter['orderby'] : 'time';
        $titlelength = !empty($parameter['titlelength']) ? intval($parameter['titlelength']) : 40;
        $summarylength = !empty($parameter['summarylength']) ? intval($parameter['summarylength']) : 80;
        $param['items'] = !empty($parameter['items']) ? intval($parameter['items']) : 10;
        $height = !empty($parameter['height']) ? intval($parameter['height']) : 100;
        $width = !empty($parameter['width']) ? intval($parameter['width']) : 100;
        $list = array();
        $query = $this->fetch_all_for_diy($param);
        foreach ($query as $video) {
            $list[] = array(
                'id' => $video['tid'],
                'idtype' => 'video_id',
                'title' => cutstr($video['subject'], $titlelength, ''),
                'url' => get_turl($video['tid']),
                'pic' => (preg_match('/http/',$video['coverimg'])?$video['coverimg']:$_G['siteurl'] . '/' . $video['coverimg']),
                'picflag' => $video['coverimg'] ? '3' : '0',
                'summary' => $video['message'],
                'fields' => array(
                    'height' => $height,
                    'width' => $width,
                    'play' => $video['play'],
                    'reply' => $video['reply'],
                    'imgsrc' => $video['coverimg'],
					'author' => $video['author'],
					'authorid' => $video['authorid'],
					'dateline' => $video['dateline'],
                )
            );
        }
        return array('html' => '', 'data' => $list);
    }

    private function fetch_all_for_diy($warray) {
        $items = (intval($warray['items']) == 0? 10 : intval($warray['items']));
        $sqladd = array();
        if (!empty($warray['video_id'])) {
            $sqladd[] = 'tid IN (' . dimplode($warray['video_id']) . ')';
        }
        if (!empty($warray['cate_id'])) {
            $cid_in = '(' . dimplode($warray['cate_id']) . ')';
            $sqladd[] = "(fcid IN {$cid_in} or scid in {$cid_in} or tcid in {$cid_in})";
        }
        if (!empty($warray['bannedids'])) {
            $sqladd[] = 'tid NOT IN (' . dimplode($warray['bannedids']) . ')';
        }
        $orderby = 'dateline desc';
        if ($warray['orderby'] == 'reply') {
            $orderby = 'play desc,dateline desc';
        } elseif ($warray['orderby'] == 'reply') {
            $orderby = 'reply desc,dateline desc';
        }elseif ($warray['orderby'] == 'rand') {
            $orderby = 'rand()';
        }
        return DB::fetch_all("SELECT * FROM " . DB::table('bingofans_video_thread') . " " . (!empty($sqladd) ? 'WHERE ' : '') . implode(' AND ', $sqladd) . ' ORDER BY ' . $orderby . " LIMIT 0,$items");
    }

    
    /*
     * 递归方式获取格式化分类 
     * @return array 格式化后的分类
     */
    private function get_format_class($cid) {
        $r = array();
        $fclass = C::t("#bingofans_video#video")->fetch_all("cup={$cid}");
        foreach ($fclass as $fk => $fv) {
            for ($i = 0; $i < $fv['type']; $i++) {
                $fv['name'] = '&nbsp;&nbsp;' . $fv['name'];
            }
            $r[] = array($fv['cid'], $fv['name']);
            $r = array_merge($r, $this->get_format_class($fv['cid']));
        }
        return $r;
    }

}		
?>