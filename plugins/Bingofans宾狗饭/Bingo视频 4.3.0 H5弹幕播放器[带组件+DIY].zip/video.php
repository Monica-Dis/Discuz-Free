<?php
/**
 * This is NOT a freeware, use is subject to license terms
 * From www.bingoufan.com
 */
 
$_GET['id'] = "bingofans_video:bingofans_video";
require "plugin.php";

?>