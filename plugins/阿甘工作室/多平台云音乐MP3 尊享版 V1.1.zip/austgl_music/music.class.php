<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * [Meting多平台云音乐(austgl_music.pc)] (C)2019-2099 Powered by austgl.com 阿甘工作室.
 * DisM!应用中心 dism.taobao.com
 * Date: 2019/1/22
 * Time: 00:32
 */
if ( ! defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class plugin_austgl_music
{

    /**
     * @param $url
     *
     * @param string $site
     *
     * @return string
     */
    protected function player_html($server, $id, $type)
    {
        global $post, $_G;
        $randomid    = 'player_' . random(6);
        $player_html = '<div id="%s"></div>'
                       . '<script type="application/javascript">'
                       . 'var ap = new APlayer({'
                       . 'container: document.getElementById("%s"),'
                       . 'preload: "auto",'
                       . 'audio: %s,'
                       . 'lrcType: 3'
                       . '});'
                       . '</script>';
        if ($type == 'net') {
            $audio = '[{'
                      .'url: "'.$id.'",'
                      .'}]';
            return sprintf($player_html, $randomid, $randomid, $audio);
        }
        require_once libfile('Meting', 'plugin/austgl_music/lib');
        $api = new \Metowolf\Meting($server);
        $api->format(true);
//        var_dump($server, $id, $type);
        $music = array();
        if (in_array($type, array('song', 'album', 'search', 'artist', 'playlist'))) {
            $data = $api->$type($id);
            $data = json_decode($data, 1);
            $url   = $_G['siteurl'] . 'plugin.php?id=austgl_music';
            $music = array();
            foreach ($data as $v) {
                $music[] = array(
                    'name'   => $v['name'],
                    'artist' => implode(' / ', $v['artist']),
                    'url'    => $url . '&site=' . $v['source'] . '&type=url&music_rid=' . $v['url_id'],
                    'cover'  => $url . '&site=' . $v['source'] . '&type=pic&music_rid=' . $v['pic_id'],
                    'lrc'    => $url . '&site=' . $v['source'] . '&type=lrc&music_rid=' . $v['lyric_id'],
                );
            }
        }

        return sprintf($player_html, $randomid, $randomid, json_encode($music));
    }

    protected function loadPlayer($matches)
    {
        if (count($matches) < 2) {
            return $matches[0];
        } else {
            $url  = $matches[1];
            $id   = '';
            $type = '';
            switch (1) {
                case (strpos($url, '163.com') !== false):
                    $server = 'netease';
                    if (preg_match('/playlist\?id=(\d+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'playlist');
                    } elseif (preg_match('/toplist\?id=(\d+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'playlist');
                    } elseif (preg_match('/album\?id=(\d+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'album');
                    } elseif (preg_match('/song\?id=(\d+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'song');
                    } elseif (preg_match('/artist\?id=(\d+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'artist');
                    }
                    break;
                case (strpos($url, 'qq.com') !== false):
                    $server = 'tencent';
                    if (preg_match('/playsquare\/([^\.]*)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'playlist');
                    } elseif (preg_match('/playlist\/([^\.]*)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'playlist');
                    } elseif (preg_match('/album\/([^\.]*)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'album');
                    } elseif (preg_match('/song\/([^\.]*)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'song');
                    } elseif (preg_match('/singer\/([^\.]*)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'artist');
                    }
                    break;
                case (strpos($url, 'xiami.com') !== false):
                    $server = 'xiami';
                    if (preg_match('/collect\/(\w+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'playlist');
                    } elseif (preg_match('/album\/(\w+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'album');
                    } elseif (preg_match('/[\/.]\w+\/[songdem]+\/(\w+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'song');
                    } elseif (preg_match('/artist\/(\w+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'artist');
                    }
                    if ( ! preg_match('/^\d*$/i', $id, $t)) {
                        $data = self::curl($url);
                        preg_match('/' . $type . '\/(\d+)/i', $data, $id);
                        $id = $id[1];
                    }
                    break;
                case (strpos($url, 'kugou.com') !== false):
                    $server = 'kugou';
                    if (preg_match('/special\/single\/(\d+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'playlist');
                    } elseif (preg_match('/#hash\=(\w+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'song');
                    } elseif (preg_match('/album\/[single\/]*(\d+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'album');
                    } elseif (preg_match('/singer\/[home\/]*(\d+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'artist');
                    } elseif (preg_match('/kgsong\/(\w+)\.html/i', $url, $id)) {
                        $content = $this->curl($url);
                        if ($content) {
                            preg_match('/"hash":"([A-F0-9]{32})"/', $content, $hash);
                            list($id, $type) = array($hash[1], 'song');
                        }
                    }
                    break;
                case (strpos($url, 'baidu.com') !== false):
                    $server = 'baidu';
                    if (preg_match('/songlist\/(\d+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'playlist');
                    } elseif (preg_match('/album\/(\d+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'album');
                    } elseif (preg_match('/song\/(\d+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'song');
                    } elseif (preg_match('/artist\/(\d+)/i', $url, $id)) {
                        list($id, $type) = array($id[1], 'artist');
                    }
                    break;
                case (preg_match("/\.mp3/i", $url, $matches)):
                    $server = 'net';
                    list($id, $type) = array($url, 'net');
                    break;
                default:
                    $server = 'netease';
                    break;
            }
            if (is_array($id)) {
                $id = '';
            }

            return $this->player_html($server, $id, $type);
        }
    }

    private function curl($url)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($curl, CURLOPT_TIMEOUT, 10);
        curl_setopt($curl, CURLOPT_REFERER, $url);
        $result = curl_exec($curl);
        curl_close($curl);

        return $result;
    }

    protected function parseMetingMusic($message)
    {
        if (strpos($message, '[/audio]') !== false) {
            $message = preg_replace_callback("/\[audio\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/is",
                array($this, 'loadPlayer'), $message);
        }

        return $message;
    }

    public function global_header()
    {
        global $_G;
        $assets_html = '<link type="text/css" rel="stylesheet" href="' . $_G['siteurl'] . 'source/plugin/austgl_music/player/APlayer.min.css"/>'
                       . '<script type="text/javascript" src="' . $_G['siteurl'] . 'source/plugin/austgl_music/player/APlayer.min.js"></script>';

        return $assets_html;
    }

    public function discuzcode($value)
    {
        global $_G;
        switch ($value['caller']) {
            case 'discuzcode':
//                var_dump($_G['discuzcodemessage']);
//                break;
            case 'messagecutstr':
                $_G['discuzcodemessage'] = $this->parseMetingMusic($_G['discuzcodemessage']);
                break;
        }
    }
}


class plugin_austgl_music_forum extends plugin_austgl_music
{

}

class plugin_austgl_music_group extends plugin_austgl_music
{

}

class plugin_austgl_music_portal extends plugin_austgl_music
{

}

class mobileplugin_austgl_music extends plugin_austgl_music
{
    function global_header_mobile()
    {
        return $this->global_header();
    }
}

class mobileplugin_austgl_music_forum extends mobileplugin_austgl_music
{

}

class mobileplugin_austgl_music_group extends mobileplugin_austgl_music
{

}

class mobileplugin_austgl_music_portal extends mobileplugin_austgl_music
{

}
