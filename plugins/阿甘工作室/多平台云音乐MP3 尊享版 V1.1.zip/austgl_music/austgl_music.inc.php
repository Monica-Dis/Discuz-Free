<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * DisM!应用中心 dism.taobao.com
 * Date: 2019/1/24
 * Time: 00:03
 */


$server = $_GET['site'];
$type = $_GET['type'];
$id = $_GET['music_rid'];

require_once libfile('Meting','plugin/austgl_music/lib');
$api = new \Metowolf\Meting($server);
$api->format(true);

if ($type == 'lrc') {
    $data = $api->lyric($id);
    $data = json_decode($data, true);
    header("Content-Type: application/javascript");
    if (!empty($data['tlyric'])) {
        echo lrctran($data['lyric'], $data['tlyric']);
    } else {
        echo $data['lyric'];
    }
}

// 专辑图片解析
if ($type == 'pic') {
    $data = $api->pic($id, 90);
    $data = json_decode($data, true);
    header("Location: ${data['url']}");
}

// 歌曲链接解析
if ($type == 'url') {
    $data = $api->url($id);
    $data = json_decode($data, true);
    var_dump($data);
    $url = $data['url'];
    if ($server == 'netease') {
        $url = str_replace('://m7c.', '://m7.', $url);
        $url = str_replace('://m8c.', '://m8.', $url);
        $url = str_replace('http://m8.', 'https://m9.', $url);
        $url = str_replace('http://m7.', 'https://m9.', $url);
        $url = str_replace('http://m10.', 'https://m10.', $url);
    }
    if ($server == 'xiami') {
        $url = str_replace('http://', 'https://', $url);
    }
    if ($server == 'baidu') {
        $url = str_replace('http://zhangmenshiting.qianqian.com', 'https://gss3.baidu.com/y0s1hSulBw92lNKgpU_Z2jR7b2w6buu', $url);
    }
    if (empty($url)) {
        if ($server == 'netease') {
            $url = 'https://music.163.com/song/media/outer/url?id='.$id.'.mp3';
        }
    }
    header("Location: " . $url);
}

function lrctrim($lyrics)
{
    $result = "";
    $lyrics = explode("\n", $lyrics);
    $data = array();
    foreach ($lyrics as $key => $lyric) {
        preg_match('/\[(\d{2}):(\d{2}[\.:]?\d*)]/', $lyric, $lrcTimes);
        $lrcText = preg_replace('/\[(\d{2}):(\d{2}[\.:]?\d*)]/', '', $lyric);
        if (empty($lrcTimes)) {
            continue;
        }
        $lrcTimes = intval($lrcTimes[1]) * 60000 + intval(floatval($lrcTimes[2]) * 1000);
        $lrcText = preg_replace('/\s\s+/', ' ', $lrcText);
        $lrcText = trim($lrcText);
        $data[] = array($lrcTimes, $key, $lrcText);
    }
    sort($data);
    return $data;
}
function lrctran($lyric, $tlyric)
{
    $lyric = $this->lrctrim($lyric);
    $tlyric = $this->lrctrim($tlyric);
    $len1 = count($lyric);
    $len2 = count($tlyric);
    $result = "";
    for ($i=0,$j=0; $i<$len1&&$j<$len2; $i++) {
        while ($lyric[$i][0]>$tlyric[$j][0]&&$j+1<$len2) {
            $j++;
        }
        if ($lyric[$i][0] == $tlyric[$j][0]) {
            $tlyric[$j][2] = str_replace('/', '', $tlyric[$j][2]);
            if (!empty($tlyric[$j][2])) {
                $lyric[$i][2] .= " ({$tlyric[$j][2]})";
            }
            $j++;
        }
    }
    for ($i=0; $i<$len1; $i++) {
        $t = $lyric[$i][0];
        $result .= sprintf("[%02d:%02d.%03d]%s\n", $t/60000, $t%60000/1000, $t%1000, $lyric[$i][2]);
    }
    return $result;
}
