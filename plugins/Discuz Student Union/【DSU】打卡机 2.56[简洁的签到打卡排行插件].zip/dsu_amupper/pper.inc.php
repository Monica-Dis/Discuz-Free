<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$file = './data/plugindata/dsu_amupper.data.php';$return = '';
if(file_exists($file)){
	require_once DISCUZ_ROOT.'./data/plugindata/dsu_amupper.data.php';
	$data_f2a =dstripslashes($data_f2a);
}

if(!empty($_G['uid'])){
	$processname = 'dsu_amupper';
	if(discuz_process::islocked($processname, 3)) {
		showmessage('dsu_amupper:wrong', '', array(), array('showdialog' => true, 'alert' => 'error', 'closetime' => true));
	}else{
		dsetcookie('dsu_amupper_footer'.$_G['uid'],'',0);
		$ppereturn = dsu_amupper();
		discuz_process::unlock($processname);
		if($ppereturn){
			$ppereturn['message'];
			if($ppereturn['tid'] && $ppereturn['pid']){
				$url = "forum.php?mod=redirect&goto=findpost&ptid={$ppereturn['tid']}&pid={$ppereturn['pid']}";
				showmessage($ppereturn['message']."<br><b><a href='".$url."'>".lang('plugin/dsu_amupper','goto')."</a></b>", $url, array(), array('showmsg' => true,'alert' => 'right', 'closetime' =>10));
			}else{
				showmessage($ppereturn['message'], $url, array(), array('showmsg' => true,'alert' => 'right', 'closetime' =>10));
			}
		}else{
			showmessage('dsu_amupper:wrong', '', array(), array('showdialog' => true, 'alert' => 'error', 'closetime' => true));
		}
	}
}




function dsu_amupper(){
	global $_G;
	$thisvars['offset'] = $_G['setting']['timeoffset'];
	$thisvars['today'] = dgmdate($_G['timestamp'],'Ymd',$thisvars['offset']);
	$thisvars['yesterday'] = dgmdate($_G['timestamp']-86400,'Ymd',$thisvars['offset']);
	$thisvars['tomorrow'] = dgmdate($_G['timestamp']+86400,'Ymd',$thisvars['offset']);
	$time = dgmdate($_G['timestamp'],'Y-m-d',$thisvars['offset']);
	$times = dgmdate($_G['timestamp'],'Y-m-d H:i:s',$thisvars['offset']);

	
	$cdb_pper = array();
	$cdb_pper['uid'] = intval($_G['uid']);
	$cdb_pper['lasttime'] = intval($_G['timestamp']);
	$cdb_pper['continuous'] = intval(1);
	$cdb_pper['addup'] = intval(1);
	$query = array();
	$reward_if = 0;

	$query = DB::fetch_first("SELECT * FROM ".DB::table("plugin_dsuampper")." WHERE uid = '{$cdb_pper['uid']}'");
	if($query){
		$lasttime =  dgmdate($query['lasttime'],'Ymd',$thisvars['offset']);
		if($lasttime == $thisvars['yesterday'] || ($lasttime <= $thisvars['yesterday'] && $_G['cache']['plugin']['dsu_amupper']['liwai'])){
			$show['continuous'] = $cdb_pper['continuous'] = 1 + $query['continuous'];
			$show['addup'] = $cdb_pper['addup'] = 1 + $query['addup'];
			$reward_if = 1;//�Ƿ�����ǩ������
		}elseif($lasttime < $thisvars['yesterday'] && !$_G['cache']['plugin']['dsu_amupper']['liwai']){
			$show['continuous'] = $cdb_pper['continuous'] = 1;
			$show['addup'] = $cdb_pper['addup'] = 1 + $query['addup'];
			$reward_if = 1;
		}else{
			$show['continuous'] = $cdb_pper['continuous'] = $query['addup'];
			$show['addup'] = $cdb_pper['addup'] = $query['addup'];
		}
	}else{
		$show['continuous'] = $cdb_pper['continuous'] = 1;
		$show['addup'] = $cdb_pper['addup'] = 1;
		$reward_if = 2;//�Ƿ����״�ǩ��
	}
	$spre_msg = special_rewardts($cdb_pper['continuous']);

	if($reward_if){
		$extcredit = $_G['cache']['plugin']['dsu_amupper']['extcredit'];
		$base = $_G['cache']['plugin']['dsu_amupper']['base'];
		$supreme = $_G['cache']['plugin']['dsu_amupper']['supreme'];
		$continuous = $cdb_pper['continuous'];
		if($reward_if == 1){
			DB::query("UPDATE ".DB::table('plugin_dsuampper')." SET lasttime = '{$cdb_pper['lasttime']}' , continuous = '{$cdb_pper['continuous']}' , addup = '{$cdb_pper['addup']}' WHERE uid = '{$cdb_pper['uid']}'");
		}elseif($reward_if == 2){
			DB::insert('plugin_dsuampper',$cdb_pper);
		}
		
		$reward_fun = reward($continuous,$base,$supreme,$spre_msg,$_G['cache']['plugin']['dsu_amupper']['mod']);
		
		$log_subject = lang('plugin/dsu_amupper','logsj',array('day' => $time));
		$log_message = $reward_fun['log'];
		$show_out['message'] = $reward_fun['show'];
		$logid = $_G['cache']['plugin']['dsu_amupper']['logid'];
		if($logid){
			$querylog = DB::fetch_first("SELECT * FROM ".DB::table("forum_thread")." WHERE subject = '{$log_subject}' AND fid = '{$logid}'");
			if(!$querylog['tid'] || $querylog['fid'] <> $logid){
				$show_out['tid'] = addnewtid($logid,$log_subject,$log_message);
				$log_data['day'] = $thisvars['today'];$log_data['tid'] = $show_out['tid'];
			}else{
				$show_out['tid'] = $querylog['tid'];
				$show_out['pid'] = addnewpid($logid,$querylog['tid'],$log_subject,$log_message);	
			}
			
		}

		return $show_out;
	}else{
		return false;
	}
}
function reward($continuous,$base,$supreme,$spre_msg,$mod){
	global $_G;
	$extcredit = $_G['cache']['plugin']['dsu_amupper']['extcredit'];
	switch ($mod){
	case 1:
		$reward['now'] = intval($continuous * $continuous * 0.09 + $base);
		$continuous_next = $continuous + 1;
		if($supreme < $reward['now']){$reward['now'] = $supreme;}//�ж��Ƿ񳬹����ֵ
		updatemembercount($_G['uid'], array("extcredits{$extcredit}" => $reward['now']), true,'',0);
		$reward['next'] = intval($continuous_next * $continuous_next * 0.09 + $base);
		if($supreme < $reward['next']){$reward['next'] = $supreme;}
		$rewards = $_G['setting']['extcredits'][$extcredit]['title'].$reward['now'];
		$reward_next = $_G['setting']['extcredits'][$extcredit]['title'].$reward['next'];
		$spre = special_reward($continuous);
		$message['log'] = lang('plugin/dsu_amupper','notice',array('rewards' => $rewards,'reward_next' => $reward_next,'continuous' => $continuous,'special_reward' => $spre))."\n".$spre_msg;
		$message['show'] = lang('plugin/dsu_amupper','notice',array('rewards' => $rewards,'reward_next' => $reward_next,'continuous' => $continuous,'special_reward' => $spre)).$spre_msg;
		return $message;
	break;

	case 2:
		$reward['now'] = $reward['next'] = intval($base);
		$continuous_next = $continuous + 1;
		updatemembercount($_G['uid'], array("extcredits{$extcredit}" => $reward['now']), true,'',0);
		$rewards = $_G['setting']['extcredits'][$extcredit]['title'].$reward['now'];
		$reward_next = $_G['setting']['extcredits'][$extcredit]['title'].$reward['next'];
		$spre = special_reward($continuous);
		$message['log'] = lang('plugin/dsu_amupper','notice',array('rewards' => $rewards,'reward_next' => $reward_next,'continuous' => $continuous,'special_reward' => $spre))."\n".$spre_msg;
		$message['show'] = lang('plugin/dsu_amupper','notice',array('rewards' => $rewards,'reward_next' => $reward_next,'continuous' => $continuous,'special_reward' => $spre)).$spre_msg;
		return $message;
	break;

	case 3:
		$reward['now'] = intval(rand($base,$supreme));
		$reward['next'] = 'X';
		$continuous_next = $continuous + 1;
		updatemembercount($_G['uid'], array("extcredits{$extcredit}" => $reward['now']), true,'',0);
		$rewards = $_G['setting']['extcredits'][$extcredit]['title'].$reward['now'];
		$reward_next = $_G['setting']['extcredits'][$extcredit]['title'].$reward['next'];
		$spre = special_reward($continuous);
		$message['log'] = lang('plugin/dsu_amupper','notice',array('rewards' => $rewards,'reward_next' => $reward_next,'continuous' => $continuous,'special_reward' => $spre))."\n".$spre_msg;
		$message['show'] = lang('plugin/dsu_amupper','notice',array('rewards' => $rewards,'reward_next' => $reward_next,'continuous' => $continuous,'special_reward' => $spre)).$spre_msg;
		return $message;
	break;
	}
	
}



function special_reward($i){
	global $_G,$data_f2a;
	$file = './data/plugindata/dsu_amupper.data.php';$return = '';
	if(file_exists($file)){
		$minday = -1;
		if($_G['cache']['plugin']['dsu_amupper']['periodicity']){
			foreach ($data_f2a as $id => $result){
				if($i % $result['days'] == 0 && ($_G['groupid']==$result['usergid'] || $result['usergid'] == '-1')){
					$return = $result;					
				}
			}
		}else{
			foreach ($data_f2a as $id => $result){
				if($i == $result['days'] && ($_G['groupid']==$result['usergid'] || $result['usergid'] == '-1')){
					$return = $result;
				}
			}
		}
		if($return){
			updatemembercount($_G['uid'], array("extcredits{$return['extcredits']}" => $return['reward']), true,'',0);
			$return['extcredits'] = $_G['setting']['extcredits'][$return['extcredits']]['title'];
			$return = lang('plugin/dsu_amupper','special_reward',array('rewards' => $return['reward'],'extcredits' => $return['extcredits']));
		}
	}

	return $return;
}

function special_rewardts($i){
	global $_G,$data_f2a;
	$file = './data/plugindata/dsu_amupper.data.php';$return = '';
	if(file_exists($file)){
		$minday = -1;
		if($_G['cache']['plugin']['dsu_amupper']['periodicity']){
			foreach ($data_f2a as $id => $result){
				if($_G['groupid']==$result['usergid'] || $result['usergid'] == '-1'){
					$day = $result['days'] - $i % $result['days'];
					
					if($minday <0 || $minday > $day){
						$minday = $day;
						$return = $result;	
					}
				}
			}
		}else{
			foreach ($data_f2a as $id => $result){
				if($i == $result['days'] && ($_G['groupid']==$result['usergid'] || $result['usergid'] == '-1')){
					$day = $result['days'] - $i;
					if($minday <0 || $minday > $day){
						$minday = $day;
						$return = $result;	
					}
				}
			}
		}
		if($return && $minday > 0){
			$return['extcredits'] = $_G['setting']['extcredits'][$return['extcredits']]['title'];
			$return = lang('plugin/dsu_amupper','specialreward_ts',array('minday' => $minday,'reward' => $return['reward'],'extcredits' => $return['extcredits']));
		}
	}
	return $return;
}

function addnewtid($fid,$subject,$message){
	global $_G;
	if($_G['uid'] && $fid && $subject && $message){
		require_once libfile('function/forum');

		DB::insert('forum_thread', array(
			'fid'=>$fid,
			'author'=>$_G['username'],
			'authorid'=>$_G['uid'],
			'subject' =>$subject,
			'dateline' => $_G['timestamp'],
			'lastpost' => $_G['timestamp'],
			'lastposter'=>$_G['username'],
			'closed'=>1));

		$tid = DB::insert_id();

		if($tid){
			$pid=insertpost(array(
				'fid'=>$fid,
				'tid' => $tid,
				'first'=>'1',
				'author'=>$_G['username'],
				'authorid'=>$_G['uid'],
				'subject'=>$subject,
				'dateline'=>$_G['timestamp'],
				'message'=>$message,
				'useip'=>$_G['clientip']));
			$lastpost = "$tid\t".addslashes($subject)."\t$_G[timestamp]\t$_G[username]";
			DB::query('UPDATE '.DB::table('forum_forum')." SET threads=threads+'1', todayposts=todayposts+1, lastpost='{$lastpost}' WHERE fid=".$fid);
		}
	}
	
	return $tid;
}

function addnewpid($fid,$tid,$subject='',$message){
	global $_G;
	if($_G['uid'] && $fid && $tid && $message){
		require_once libfile('function/forum');
		$pid=insertpost(array(
			'fid'=>$fid,
			'tid'=>$tid,
			'first'=>'0',
			'author'=>$_G['username'],
			'authorid'=>$_G['uid'],
			'subject'=>$subject,
			'dateline'=>$_G['timestamp'],
			'message'=>$message,
			'useip'=>$_G['clientip']));
		if($pid){
			DB::query("UPDATE ".DB::table('forum_thread')." SET lastposter='$_G[username]', lastpost='$_G[timestamp]', replies=replies+1 WHERE tid='$tid' AND fid='$fid'", 'UNBUFFERED');
			$lastpost = "$tid\t".addslashes($subject)."\t$_G[timestamp]\t$_G[username]";
			DB::query("UPDATE ".DB::table('forum_forum')." SET lastpost='$lastpost', posts=posts+1, todayposts=todayposts+1 WHERE fid='$fid'", 'UNBUFFERED');
			return $pid;
		}
	}
	
}

?>


