<?php
/*
	Copyright 2001-2099 DisM!Ӧ������.
*/
!defined('IN_DISCUZ') && exit('Access Denied');
!defined('IN_ADMINCP') && exit('Access Denied');


if(file_exists(DISCUZ_ROOT.'./data/dsu_amupper.lock')) {
	cpmsg('dsu_amupper:admin_ed', 'action=plugins&operation=config&identifier=dsu_amupper','succeed');
	exit;
} 

if(!$_G['gp_submit']){
	showtableheader(lang("plugin/dsu_amupper","admin_h1"));
	showformheader("plugins&operation=config&identifier=dsu_amupper&pmod=admin&submit=1", "");
	showsetting(lang('plugin/dsu_amupper','admin_f2'), 'reserve', '1', 'radio');
	echo '<input type="hidden" name="formhash" value="'.FORMHASH.'">';
	showsubmit('submit', "OK!");
	showformfooter(); /*dis'.'m.tao'.'bao.com*/
	showtablefooter(); /*dism��taobao��com*/
}elseif($_G['gp_submit'] && $_G['adminid']=='1' && $_G['gp_formhash']==FORMHASH){
	$formhash = FORMHASH;
	$limit = 400;
	$tablename = DB::table('dsu_paulsign');
	$amuppertable = DB::table('plugin_dsuampper');
	$query = DB::query("SHOW TABLES LIKE '$tablename'");
	$sql = '';
	$paulsign_exist = 0;
	if(DB::num_rows($query) > 0){
		$paulsign_exist = 1;
	}
	if(!$_G['gp_reserve']){
		DB::query("DROP TABLE IF EXISTS ".$amuppertable."");
		$sql ='CREATE TABLE '.$amuppertable.' (
		`uid` MEDIUMINT( 8 ) UNSIGNED NOT NULL ,
		`lasttime` INT( 10 ) UNSIGNED NOT NULL ,
		`continuous` MEDIUMINT( 8 ) NOT NULL ,
		`addup` MEDIUMINT( 10 ) NOT NULL
		) ENGINE = MYISAM ;
		';

		DB::query($sql);
	}
	if($paulsign_exist){
		$num = DB::result_first("SELECT COUNT(*) FROM ".DB::table('dsu_paulsign'));
		$page = max(1, intval($_G['gp_page']));
		$start_limit = ($page - 1) * $limit;
	    $maxpage = ceil($num/$limit);
		$nextpage = $page + 1;

		$query = DB::query("SELECT * FROM ".DB::table('dsu_paulsign')." LIMIT ".$start_limit." ,".$limit);
		$mrcs = array();
		while($mrc = DB::fetch($query)) {
			$mrc['ifcz'] = DB::fetch_first("SELECT * FROM ".$amuppertable." WHERE uid='$mrc[uid]'");
			if(!$mrc['ifcz']['uid']) {
				$mrc['mdays'] = $mrc['mdays'] + 1;
				DB::query("INSERT INTO ".$amuppertable." (uid,lasttime,continuous,addup) VALUES ('$mrc[uid]','$mrc[time]','$mrc[mdays]','$mrc[days]')");
			}else{
				$mrc['im_continuous']= $mrc['ifcz']['continuous'] + $mrc['mdays'];
				$mrc['im_addup']= $mrc['ifcz']['addup'] + $mrc['days'];
				if($mrc['ifcz']['lasttime']>$mrc['time']){$mrc['im_lasttime']=$mrc['ifcz']['lasttime'];}else{$mrc['im_lasttime']=$mrc['time'];}
				DB::query("UPDATE ".$amuppertable." SET continuous='$mrc[im_continuous]',addup='$mrc[im_addup]',lasttime='$mrc[im_lasttime]' WHERE uid='$mrc[uid]'");
			}
			$mrcs[] = $mrc;
		}
	}
	if($page<$maxpage){
		cpmsg(lang('plugin/dsu_amupper','admin_ing',array('jindu'=>$page.'/'.$maxpage)), 'action=plugins&operation=config&identifier=dsu_amupper&pmod=admin&reserve=reserve&submit=submit&formhash='.$formhash.'&page='.$nextpage,'loading');
	}else{
		touch(DISCUZ_ROOT.'./data/dsu_amupper.lock');
		cpmsg('dsu_amupper:admin_i', 'action=plugins&operation=config&identifier=dsu_amupper&anchor=vars','succeed');
	}
}
//From: Dism��taobao��com
?>