<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//start to put your own code

$sql = <<<EOF

CREATE TABLE  pre_plugin_dsuampper (
`uid` MEDIUMINT( 8 ) UNSIGNED NOT NULL ,
`lasttime` INT( 10 ) UNSIGNED NOT NULL ,
`continuous` MEDIUMINT( 8 ) NOT NULL ,
`addup` MEDIUMINT( 10 ) NOT NULL ,
UNIQUE (
`uid`
)
) ENGINE = MYISAM ;

EOF;

runquery($sql);
//finish to put your own code
$finish = TRUE;
?>