<?php
/*
	Install Uninstall Upgrade AutoStat System Code
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//start to put your own code

$sql = "ALTER TABLE `pre_plugin_dsuampper` ADD UNIQUE(`uid`)";
runquery($sql);

//finish to put your own code
$finish = TRUE;
?>