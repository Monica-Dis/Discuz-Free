<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) exit('Access Denied');
class mobileplugin_dsu_paulsign {
        function global_header_mobile(){
			global $_G,$show_message;
			function dsu_signtz() {
				dheader('Location: plugin.php?id=dsu_paulsign:sign&mobile=yes');
			}
			$var = $_G['cache']['plugin']['dsu_paulsign'];
			if(defined('IN_dsu_paulsign') || $show_message || defined('IN_dsu_paulsc') || !$_G['uid'] || !$var['ifopen'] || !$var['wap_sign']) return '';
			$tdtime = gmmktime(0,0,0,dgmdate($_G['timestamp'], 'n',$var['tos']),dgmdate($_G['timestamp'], 'j',$var['tos']),dgmdate($_G['timestamp'], 'Y',$var['tos'])) - $var['tos']*3600;
			$allowmem = memory('check');
			if($var['ftopen']  && in_array($_G['groupid'], unserialize($var['tzgroupid'])) && !in_array($_G['uid'],explode(",",$var['ban'])) && in_array($_G['groupid'], unserialize($var['groups']))) {
				if($allowmem && $var['mcacheopen']) $signtime = memory('get', 'dsu_pualsign_'.$_G['uid']);
				if(!$signtime){
					$qiandaodb = C::t('#dsu_paulsign#dsu_paulsign')->fetch($_G['uid']);
					$signtime = $qiandaodb['time'];
					$htime = dgmdate($_G['timestamp'], 'H',$var['tos']);
					if($qiandaodb){
						if($allowmem && $var['mcacheopen']) memory('set', 'dsu_pualsign_'.$_G['uid'], $qiandaodb['time'], 86400);
						if($qiandaodb['time'] < $tdtime){
							if($var['timeopen']) {
								if(!($htime < $var['stime']) && !($htime > $var['ftime'])) return dsu_signtz();
							}else{
								return dsu_signtz();
							}
						}
					}else{
						if($var['mintdpost'] <= C::t('#dsu_paulsign#dsu_paulsign')->getuserpost($_G['uid'])){
							if($var['timeopen']) {
								if(!($htime < $var['stime']) && !($htime > $var['ftime'])) return dsu_signtz();
							}else{
								return dsu_signtz();
							}
						}
					}
				}else{
					if($signtime < $tdtime){
						if($var['timeopen']) {
							if(!($htime < $var['stime']) && !($htime > $var['ftime']))return dsu_signtz();
						}else{
							return dsu_signtz();
						}
					}
				}
			}
			return '<a href="plugin.php?id=dsu_paulsign:sign">'.lang('plugin/dsu_paulsign', 'name').'</a>';
        }
}
//From: Dism��taobao��com
?>