<?php
/*
	(c) 2020 by dism.taobao.com[DISM.TAOBAO.COM Team] 2020-11-19
*/
!defined('IN_DISCUZ') && exit('Access Denied');
!defined('IN_ADMINCP') && exit('Access Denied');
include template('dsu_paulsign:sign_helper');
?>