<?php
/*
 data : 2019.1.20
 最新插件：http://t.cn/Aiux1Jx1
 
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_yibai_app_follow {
	function global_header_mobile() {
			global $_G;
			$yibai = $_G['cache']['plugin']['yibai_app_follow'];
			$yb_wx_off = $yibai['yb_wx_off'];
			//判断是否开启
			if($yb_wx_off == 0){
				return;
			}			
			$yb_wx_picadd = dhtmlspecialchars($yibai['yb_wx_picadd']);
			$yb_ad_url = dhtmlspecialchars($yibai['yb_ad_url']);
			$yb_wx_time = intval($yibai['yb_wx_time']);
			$yb_wx_interval = intval($yibai['yb_wx_interval']);//时间间隔
			$yb_wx_weixin = $yibai['yb_wx_weixin'];
			$yb_user_show = unserialize($yibai['yb_user_show']);
			//开启用户组功能
			if(!in_array($_G['group']['groupid'],$yb_user_show)){
				return;
			}
			//仅在微信浏览器打开
			if($yb_wx_weixin == 0){
				if($_G['cookie']['ybfollow'] == ''){
					dsetcookie("ybfollow","yibai",$yb_wx_interval);
					include template('yibai_app_follow:ad');
					return $return;
				}
			}else{
				//判断是为微信浏览器
				if ( strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false ) {
					if($_G['cookie']['ybfollow'] == ''){
						dsetcookie("ybfollow","yibai",$yb_wx_interval);
						include template('yibai_app_follow:ad');
						return $return;
					}
				}else{
					return;
				}  
			
			}
	}
}
//From: Dism_taobao-com
?>