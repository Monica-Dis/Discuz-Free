<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_yibai_app_follow {
	function global_footer(){
		global $_G;
		$yibaiWebF=$_G['cache']['plugin']['yibai_app_follow'];
		$yb_web_off = $yibaiWebF['yb_web_off'];
		if(!$yb_web_off){
			return;
		}
		$yb_web_colse = $yibaiWebF['yb_web_colse'];
		$yb_web_title=dhtmlspecialchars($yibaiWebF['yb_web_title']);
		$yb_web_picadd=dhtmlspecialchars($yibaiWebF['yb_web_picadd']);
		$yb_webad_url=dhtmlspecialchars($yibaiWebF['yb_webad_url']);
		$yb_web_time = intval($yibaiWebF['yb_web_time']);
		$yb_web_interval = intval($yibaiWebF['yb_web_interval']);//间隔
		$yb_web_weizhi=unserialize($yibaiWebF['yb_web_weizhi']);
		$yb_user_show = unserialize($yibaiWebF['yb_user_show']);
		//开启用户组功能
		if(!in_array($_G['group']['groupid'],$yb_user_show)){
			return;
		}
		//投放位置
		if(!$yb_web_weizhi[1]){
			$wz=CURSCRIPT;
			if(!is_array($yb_web_weizhi)) $yb_web_weizhi = array();
			if(!(empty($yb_web_weizhi[0]) || in_array($wz,$yb_web_weizhi))){
				return;
			}
			
		}
		//投放间隔
		if($_G['cookie']['yb_web_follow'] == ''){
			dsetcookie("yb_web_follow","yibai",$yb_web_interval);
			include template('yibai_app_follow:webad');
			return $return;
		}
	}
}
//From: Dism_taobao-com
?>