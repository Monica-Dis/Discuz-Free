<?php

/*
DisM!�û�����Ⱥ: ��Ⱥ778390776

DZģ�����ṩ��
רҵ�Ŷӣ�Ϊ���ṩרҵ����

From: DisM.taobao.Com   
date:20150107
QQ:318650791

*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_yibai_qrcode {
	     function yibai_qrcode(){
			   global $_G;
				$cache = $_G['cache']['plugin']['yibai_qrcode'];
				 $this->urlqrcode = str_replace('&','%26','http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']);  
				 $this->titleqconde = $_G[thread][subject];
				 $this->yibai_title = $cache['yibai_title'];
				 $this->yibai_n = $cache['yibai_n'];
				 $this->yibai_jiesi = $cache['yibai_jiesi'];
				 $this->yibai_qr = intval($cache['yibai_qr']);
				 
				
			 //qrcode
			 
			 if($this->yibai_qr = 1){
			 	$this->urlzong = "http://qr.liantu.com/api.php?w=150&amp;m=0&amp;el=l&amp;text=$this->urlqrcode";
			 }else{
				$this->urlzong = "http://chart.apis.google.com/chart?chs=150x150&cht=qr&chld=H|0&chl=$this->urlqrcode";
			 
			 }
		 }

}

class plugin_yibai_qrcode_forum extends plugin_yibai_qrcode{
				function viewthread_title_extra_output(){
					  global $_G;
				$this->yibai_qrcode();;
				$cache = $_G['cache']['plugin']['yibai_qrcode'];
				
				include template('yibai_qrcode:code');
				return $return;
				
				}
	}
//From: Dism_taobao_com
?>