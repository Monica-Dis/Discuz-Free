<?php
//aphly 2018/5/18

if(!defined('IN_DISCUZ')) {exit('Access Denied');}

$link = base64_decode($_G['currenturl_encode']);
$seach= '/plugin.php?id=aphly_qr&make=';
$pos = strpos($link,$seach);
$url = substr($link,$pos+strlen($seach));

if($url){
	require_once DISCUZ_ROOT.'source/plugin/aphly_qr/aphly_qrapi.php';
	$obj = new aphly_qrapi;
	echo $obj->make($url);
	exit;
}
//From: Dism_taobao-com
?>