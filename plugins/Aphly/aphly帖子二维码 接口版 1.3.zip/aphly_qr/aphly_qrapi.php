<?php
//aphly 2018/5/18

if(!defined('IN_DISCUZ')) {exit('Access Denied');}

class aphly_qrapi { 

	function make($url){
		$qrsize = !empty($_GET['qrsize']) ? $_GET['qrsize'] : 4;
		require_once DISCUZ_ROOT.'source/plugin/aphly_qr/qrcode.class.php';
		QRcode::png($url, false, QR_ECLEVEL_Q, $qrsize);
	}

	function cmake($url){
		$dir = DISCUZ_ROOT.'./data/cache/aphly_qr/';
		$qrsize = !empty($_GET['qrsize']) ? $_GET['qrsize'] : 4;
		$file = $dir.'qr_index.jpg';
		if(!file_exists($file) || !filesize($file)) {
			dmkdir($dir);
		}
		require_once DISCUZ_ROOT.'source/plugin/aphly_qr/qrcode.class.php';
		QRcode::png($url, $file, QR_ECLEVEL_Q, $qrsize);
		dheader('Content-Disposition: inline; filename=qrcode_index.jpg');
		dheader('Content-Type: image/pjpeg');
		@readfile($file);
	}

	

}
//From: Dism_taobao-com
?>