<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class user{
	function change_dx($oldun, $newun){
		$member = DB::fetch_first("SELECT * FROM " . DB::table('common_member') . " WHERE username='$oldun'");
		if($member){
			DB::query("UPDATE " . DB::table('common_adminnote') . " SET admin='$newun' WHERE admin='$oldun'");
			DB::query("UPDATE " . DB::table('common_block') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('common_block_item') . " SET title='$newun' WHERE title='$oldun'");
			DB::query("UPDATE " . DB::table('common_block_item_data') . " SET title='$newun' WHERE title='$oldun'");
			DB::query("UPDATE " . DB::table('common_card_log') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('common_failedlogin') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('common_grouppm') . " SET author='$newun' WHERE author='$oldun'");
			DB::query("UPDATE " . DB::table('common_invite') . " SET fusername='$newun' WHERE fusername='$oldun'");
			DB::query("UPDATE " . DB::table('common_member') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('common_member_security') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('common_member_validate') . " SET admin='$newun' WHERE admin='$oldun'");
			DB::query("UPDATE " . DB::table('common_member_verify_info') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('common_member_security') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('common_mytask') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('common_report') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('common_session') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('common_word') . " SET admin='$newun' WHERE admin='$oldun'");
			DB::query("UPDATE " . DB::table('forum_activityapply') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_announcement') . " SET author='$newun' WHERE author='$oldun'");
			DB::query("UPDATE " . DB::table('forum_collection') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_collectioncomment') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_collectionfollow') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_collectionteamworker') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_forumrecommend') . " SET author='$newun' WHERE author='$oldun'");
			DB::query("UPDATE " . DB::table('forum_groupuser') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_imagetype') . " SET name='$newun' WHERE name='$oldun'");
			DB::query("UPDATE " . DB::table('forum_order') . " SET buyer='$newun' WHERE buyer='$oldun'");
			DB::query("UPDATE " . DB::table('forum_order') . " SET admin='$newun' WHERE admin='$oldun'");
			DB::query("UPDATE " . DB::table('forum_pollvoter') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_post') . " SET author='$newun' WHERE author='$oldun'");
			DB::query("UPDATE " . DB::table('forum_postcomment') . " SET author='$newun' WHERE author='$oldun'");
			DB::query("UPDATE " . DB::table('forum_promotion') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_ratelog') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_rsscache') . " SET author='$newun' WHERE author='$oldun'");
			DB::query("UPDATE " . DB::table('forum_thread') . " SET author='$newun' WHERE author='$oldun'");
			DB::query("UPDATE " . DB::table('forum_threadmod') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_trade') . " SET seller='$newun' WHERE seller='$oldun'");
			DB::query("UPDATE " . DB::table('forum_tradelog') . " SET seller='$newun' WHERE seller='$oldun'");
			DB::query("UPDATE " . DB::table('forum_tradelog') . " SET buyer='$newun' WHERE buyer='$oldun'");
			DB::query("UPDATE " . DB::table('forum_warning') . " SET author='$newun' WHERE author='$oldun'");
			DB::query("UPDATE " . DB::table('home_album') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_blog') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_clickuser') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_comment') . " SET author='$newun' WHERE author='$oldun'");
			DB::query("UPDATE " . DB::table('home_docomment') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_doing') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_feed') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_feed_app') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_follow') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_follow') . " SET fusername='$newun' WHERE fusername='$oldun'");
			DB::query("UPDATE " . DB::table('home_follow_feed') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_follow_feed_archiver') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_friend') . " SET fusername='$newun' WHERE fusername='$oldun'");
			DB::query("UPDATE " . DB::table('home_friend_request') . " SET fusername='$newun' WHERE fusername='$oldun'");
			DB::query("UPDATE " . DB::table('home_notification') . " SET author='$newun' WHERE author='$oldun'");
			DB::query("UPDATE " . DB::table('home_pic') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_poke') . " SET fromusername='$newun' WHERE fromusername='$oldun'");
			DB::query("UPDATE " . DB::table('home_share') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_show') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_specialuser') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_visitor') . " SET vusername='$newun' WHERE vusername='$oldun'");
			DB::query("UPDATE " . DB::table('home_specialuser') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('portal_article_title') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('portal_comment') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('portal_rsscache') . " SET author='$newun' WHERE author='$oldun'");
			DB::query("UPDATE " . DB::table('portal_topic') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('portal_topic_pic') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_collection') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_collectioncomment') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_collectionfollow') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('forum_collectionteamworker') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_follow') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_follow') . " SET username='$fusername' WHERE username='$fusername'");
			DB::query("UPDATE " . DB::table('home_follow_feed') . " SET username='$newun' WHERE username='$oldun'");
			DB::query("UPDATE " . DB::table('home_follow_feed_archiver') . " SET username='$newun' WHERE username='$oldun'");
		}
	}

	function change_uc($oldun, $newun){
		DB::query("UPDATE " . UC_DBTABLEPRE . "admins SET username='$newun' WHERE username='$oldun'");
		DB::query("UPDATE " . UC_DBTABLEPRE . "badwords SET admin='$newun' WHERE admin='$oldun'");
		DB::query("UPDATE " . UC_DBTABLEPRE . "feeds SET username='$newun' WHERE username='$oldun'");
		DB::query("UPDATE " . UC_DBTABLEPRE . "members SET username='$newun' WHERE username='$oldun'");
		DB::query("UPDATE " . UC_DBTABLEPRE . "mergemembers SET username='$newun' WHERE username='$oldun'");
		DB::query("UPDATE " . UC_DBTABLEPRE . "protectedmembers SET username='$newun' WHERE username='$oldun'");
	}
}
//From: Dism��taobao��com
?>