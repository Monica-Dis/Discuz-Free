<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$_G['uid']){
	showmessage(lang('plugin/aphly_avatar', 'qlogin'), '', array(), array('showmsg' => true,'login' => 1));
}

$open=$_G['cache']['plugin']['aphly_avatar']['open'];
$ctype=$_G['cache']['plugin']['aphly_avatar']['ctype'];
$jf=intval($_G['cache']['plugin']['aphly_avatar']['jf']);
$userg=unserialize($_G['cache']['plugin']['aphly_avatar']['cg']);

if(!$open){
	showmessage(lang('plugin/aphly_avatar', 'qopen'));
}
if(!in_array($_G['groupid'], $userg)){
	showmessage(lang('plugin/aphly_avatar', 'userg'));
}
$extcredit='extcredits'.$ctype;

if(getuserprofile($extcredit)<$jf){
	showmessage(lang('plugin/aphly_avatar', 'jfbz'));
}

$nun=lang('plugin/aphly_avatar', 'nun');
$zs=lang('plugin/aphly_avatar', 'zs');

if(submitcheck('changesubmit')){
	$oldun = $_G['username'];
	$newun=isset($_GET['newun'])?daddslashes(trim($_GET['newun'])):0;
	if ($newun == '' && $newun) {
		showmessage(lang('plugin/aphly_avatar', 'noun'));
	} else {
		loaducenter();
		$check = uc_user_checkname($newun);
		if($check==1){
			require_once dirname(__FILE__)."/user.class.php";
			$user = new user();
			$user->change_dx($oldun, $newun);
			$user->change_uc($oldun, $newun);

			updatemembercount($_G['uid'], array($extcredit => -$jf), true, '', 0, '', lang('plugin/aphly_avatar', 'change_log'), '');
			showmessage(lang('plugin/aphly_avatar', 'success'),'','',array('alert' => 'right'));
		}else if($check==-1){
			showmessage(lang('plugin/aphly_avatar', 'error_1'));
		}else if($check==-2){
			showmessage(lang('plugin/aphly_avatar', 'error_2'));
		}else if($check==-3){
			showmessage(lang('plugin/aphly_avatar', 'error_3'));
		}
	}
}else{
	$aphly_avatar= $_G['cache']['plugin']['aphly_avatar'];
	if($aphly_avatar['header']){
			if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ') !== false) {
				$header=1;
			}else{
				$header=0;
			}
	}else{
			$header=0;
	}
	$aphly =  isset($_GET['aphly'])? daddslashes($_GET['aphly']):0;
	$sid =  isset($_GET['sid'])? daddslashes($_GET['sid']):0;
	include template('aphly_avatar:change');
}