<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$aphlysysoffset = getglobal('setting/timeoffset');
$aphlyScriptLang = $scriptlang['aphly_dzp'];
$aphlydzpBaseUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=aphly_dzp&pmod=admincp'; 
$aphlydzpListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=aphly_dzp&pmod=admincp';
$extcredits = $_G['setting']['extcredits'];
echo '<link href="source/plugin/aphly_dzp/imgs/admincpstyle.css" rel="stylesheet" type="text/css">';
echo '<script type="text/javascript" src="static/js/common.js"></script>';
echo '<script type="text/JavaScript">var disallowfloat = \'\';</script>';
$dzp = C::t('#aphly_dzp#aphly_dzp');
if($_GET['act'] == 'edit'){
    $hdInfo = $dzp->fetch_by_id(intval($_GET['id']));
    if(submitcheck('submit')){
        $title          = isset($_GET['title'])? addslashes($_GET['title']):'';
        $start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
        $start_time     = strtotime($start_time);
        $end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
        $end_time       = strtotime($end_time);
        $content        = isset($_GET['content'])? addslashes($_GET['content']):'';
        $cyfs           = isset($_GET['cyfs'])? addslashes($_GET['cyfs']):'';
        $if_gz          = isset($_GET['if_gz'])? intval($_GET['if_gz']):1;
		$mtzj           = isset($_GET['mtzj'])? intval($_GET['mtzj']):2;
		$if_share       = isset($_GET['if_share'])? intval($_GET['if_share']):2;
        $mr_cj_num      = isset($_GET['mr_cj_num'])? intval($_GET['mr_cj_num']):'';
        $mr_share_num   = isset($_GET['mr_share_num'])? intval($_GET['mr_share_num']):'';
		$share_desc       = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
        $duijm       = isset($_GET['duijm'])? addslashes($_GET['duijm']):'';
        $gz_url         = isset($_GET['gz_url'])? addslashes($_GET['gz_url']):'';
		$wxgzh_disc          = isset($_GET['wxgzh_disc'])? addslashes($_GET['wxgzh_disc']):'';

		$cy_num          = isset($_GET['cy_num'])? intval($_GET['cy_num']):'';
		$zj_num          = isset($_GET['zj_num'])? intval($_GET['zj_num']):'';
		$show_zjmd          = isset($_GET['show_zjmd'])? intval($_GET['show_zjmd']):0;
		$show_cy          = isset($_GET['show_cy'])? intval($_GET['show_cy']):0;
		$views          = isset($_GET['views'])? intval($_GET['views']):0;
		$show_prize_num   = isset($_GET['show_prize_num'])? intval($_GET['show_prize_num']):0;
		$join          = isset($_GET['join'])? intval($_GET['join']):0;
		$jif          = isset($_GET['jif'])? intval($_GET['jif']):0;

		if($_FILES['wxgzh_pic']['tmp_name']) {
			$wxgzh_pic = $dzp->picupload('wxgzh_pic');
		}else{
			$wxgzh_pic = addslashes($hdInfo['wxgzh_pic']);
		}

		if($_FILES['share_pic']['tmp_name']) {
			$share_pic = $dzp->picupload('share_pic');
		}else{
			$share_pic = addslashes($hdInfo['share_pic']);
		}

		if($_FILES['dingbu_pic']['tmp_name']) {
			$dingbu_pic = $dzp->picupload('dingbu_pic');
		}else{
			$dingbu_pic = addslashes($hdInfo['dingbu_pic']);
		}
		
        $updateData = array();
		$updateData['dingbu_pic']   = $dingbu_pic;
        $updateData['title']        = $title;
        $updateData['start_time']   = $start_time;
        $updateData['end_time']     = $end_time;
        $updateData['content']      = $content;
        $updateData['cyfs']         = $cyfs;
        $updateData['mr_cj_num']    = $mr_cj_num;
        $updateData['mr_share_num'] = $mr_share_num;
        $updateData['if_gz']        = $if_gz;
		$updateData['mtzj']         = $mtzj;
		$updateData['if_share']     = $if_share;
		$updateData['share_pic']    = $share_pic;
        $updateData['duijm']     = $duijm;
        $updateData['gz_url']		= $gz_url;
		$updateData['share_desc']		= $share_desc;
		$updateData['wxgzh_pic']   = $wxgzh_pic;
		$updateData['wxgzh_disc']   = $wxgzh_disc;
		$updateData['cy_num']    = $cy_num;
		$updateData['zj_num']    = $zj_num;
		$updateData['show_zjmd']    = $show_zjmd;
		$updateData['show_cy']    = $show_cy;
		$updateData['views']    = $views;
		$updateData['show_prize_num']    = $show_prize_num;
		$updateData['join']    = $join;
		$updateData['jif']    = $jif;
        $dzp->update($hdInfo['id'],$updateData);
        cpmsg($aphlyScriptLang['act_success'], $aphlydzpListUrl, 'succeed');
    }else{
        echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=aphly_dzp&pmod=admincp&act=edit&id='.$_GET['id'],'enctype');
        showtableheader();
        
        echo '<tr><th colspan="15" class="partition">' . $aphlyScriptLang['dzp_edit'] . '</th></tr>';
		
		$if_checked1 = ($hdInfo['join'] == 1)?"checked":"";
        $if_checked2 = ($hdInfo['join'] == 0)?"checked":"";

		echo '<tr class="header"><th>'.$aphlyScriptLang['join'].':</th><td><input name="join" type="radio" value="1" '.$if_checked1.'/>'.$aphlyScriptLang['dzp_if_gz_1'].'<input name="join" type="radio" value="0" '.$if_checked2.' />'.$aphlyScriptLang['dzp_if_gz_2'].'</td><td>'.$aphlyScriptLang['join_desc'].'</td></tr>';


		if($hdInfo['dingbu_pic']){
			$dingbu_pic = $_G['setting']['attachurl'].$hdInfo['dingbu_pic'];
			$dingbu_pic='<img src="'.dhtmlspecialchars($dingbu_pic).'" width="40" />';
		}else{
			$dingbu_pic='';
		}
        $aphlyScriptLang['dingbu_pic_msg'] = $aphlyScriptLang['dingbu_pic_msg'].'<br/>'.$dingbu_pic;
		
		echo '<tr class="header"><th>'.$aphlyScriptLang['dingbu_pic'].':</th><td><input class="text" name="dingbu_pic" value="'.dhtmlspecialchars($hdInfo['dingbu_pic']).'" size="35" type="file"></td><td>'.$aphlyScriptLang['dingbu_pic_msg'].'</td></tr>';

		

        echo '<tr class="header"><th width="7%">'.$aphlyScriptLang['dzp_title'].'</th><td width="30%"><input name="title" type="text" value="'.dhtmlspecialchars($hdInfo['title']).'" size="40" /></td><td>'.$aphlyScriptLang['dzp_title_msg'].'</td></tr>';

		/*
        if($hdInfo['mode'] == 1){
            $modev = $aphlyScriptLang['admin_mode_1'];
        }else if($hdInfo['mode'] == 2){
            $modev = $aphlyScriptLang['admin_mode_2'];
		}else if($hdInfo['mode'] == 3){
            $modev = $aphlyScriptLang['admin_mode_3'];
        }

		echo '<tr class="header"><th>'.$aphlyScriptLang['admin_mode'].':</th><td>'.$modev.'</td><td>'.$aphlyScriptLang['admin_mode_msg'].'</td></tr>';
		*/
        $start_time = dgmdate($hdInfo['start_time'],"Y-m-d H:i:s",$aphlysysoffset);
		$end_time = dgmdate($hdInfo['end_time'],"Y-m-d H:i:s",$aphlysysoffset);
        echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_time'].'</th><td><input name="start_time" style="width: 180px;" type="text" value="'.dhtmlspecialchars($start_time).'" size="40" onclick="showcalendar(event, this, 1)" />-<input name="end_time" style="width: 180px;" type="text" value="'.dhtmlspecialchars($end_time).'" size="40" onclick="showcalendar(event, this, 1)" /></td><td>'.$aphlyScriptLang['dzp_time_msg'].'</td></tr>';

        echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_content'].'</th><td><textarea rows="6" name="content" style="margin:2px;resize:both;width:400px" class="tarea">'.dhtmlspecialchars($hdInfo['content']).'</textarea></td><td>'.$aphlyScriptLang['dzp_content_msg'].'</td></tr>';
        
        //echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_cyfs'].'</th><td><textarea rows="6" name="cyfs" style="margin:2px;resize:both;width:400px" class="tarea">'.dhtmlspecialchars($hdInfo['cyfs']).'</textarea></td><td>'.$aphlyScriptLang['dzp_cyfs_msg'].'</td></tr>';
        
		$if_mtzj_1_checked = ($hdInfo['mtzj'] == 1)?"checked":"";
        $if_mtzj_2_checked = ($hdInfo['mtzj'] == 2)?"checked":"";

		echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_mtzj'].':</th><td><input name="mtzj" type="radio" value="1" '.$if_mtzj_1_checked.' />'.$aphlyScriptLang['dzp_if_gz_1'].'<input name="mtzj" type="radio" value="2" '.$if_mtzj_2_checked.' />'.$aphlyScriptLang['dzp_if_gz_2'].'</td><td>'.$aphlyScriptLang['dzp_mtzj_msg'].'</td></tr>';

        echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_mr_cj_num'].'</th><td><input name="mr_cj_num" type="text" value="'.dhtmlspecialchars($hdInfo['mr_cj_num']).'" size="40" /></td><td>'.$aphlyScriptLang['dzp_mr_cj_num_msg'].'</td></tr>';
        

        $if_if_share_1_checked = $hdInfo['if_share'] == 1?"checked":'';
		$if_if_share_2_checked = $hdInfo['if_share'] == 2?"checked":'';


		echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_if_share'].':</th><td><input name="if_share" type="radio" value="1" '.$if_if_share_1_checked.' />'.$aphlyScriptLang['dzp_if_gz_1'].'<input name="if_share" type="radio" value="2" '.$if_if_share_2_checked.' />'.$aphlyScriptLang['dzp_if_gz_2'].'</td><td>'.$aphlyScriptLang['dzp_if_share_msg'].'</td></tr>';

        echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_mr_share_num'].'</th><td><input name="mr_share_num" type="text" value="'.dhtmlspecialchars($hdInfo['mr_share_num']).'" size="40" /></td><td>'.$aphlyScriptLang['dzp_mr_share_num_msg'].'</td></tr>';
		
		echo '<tr class="header"><th>'.$aphlyScriptLang['jif'].':</th><td><input name="jif" type="text" value="'.dhtmlspecialchars($hdInfo['jif']).'" size="40" /></td><td>'.$aphlyScriptLang['jif_desc'].'</td></tr>';

		echo '<tr class="header"><th>'.$aphlyScriptLang['zj_num'].':</th><td><input name="zj_num" type="text" value="'.dhtmlspecialchars($hdInfo['zj_num']).'" size="40" /></td><td>'.$aphlyScriptLang['zj_num_msg'].'</td></tr>';

		echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_duijm'].'</th><td><input name="duijm" type="text" value="'.dhtmlspecialchars($hdInfo['duijm']).'" size="40" /></td><td>'.$aphlyScriptLang['dzp_duijm_msg'].'</td></tr>';
		
		if($hdInfo['share_pic']){
			$share_pic = $_G['setting']['attachurl'].$hdInfo['share_pic'];
			$share_pic='<img src="'.dhtmlspecialchars($share_pic).'" width="40" />';
		}else{
			$share_pic='';
		}
        $aphlyScriptLang['share_pic_msg'] = $aphlyScriptLang['share_pic_msg'].'<br/>'.$share_pic;

		echo '<tr class="header"><th>'.$aphlyScriptLang['share_pic'].':</th><td><input class="text" name="share_pic" value="'.dhtmlspecialchars($hdInfo['share_pic']).'" size="35" type="file"></td><td>'.$aphlyScriptLang['share_pic_msg'].'</td></tr>';

		echo '<tr class="header"><th>'.$aphlyScriptLang['share_desc'].':</th><td><input class="text" name="share_desc" value="'.dhtmlspecialchars($hdInfo['share_desc']).'" size="35" type="text"></td><td>'.$aphlyScriptLang['share_desc_msg'].'</td></tr>';
   
		$if_gz_1_checked = $hdInfo['if_gz'] == 1?"checked":"";
		$if_gz_2_checked = $hdInfo['if_gz'] == 2?"checked":"";

        //echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_if_gz'].'</th><td><input name="if_gz" type="radio" value="1" '.$if_gz_1_checked.' />'.$aphlyScriptLang['dzp_if_gz_1'].'<input name="if_gz" type="radio" value="2" '.$if_gz_2_checked.' />'.$aphlyScriptLang['dzp_if_gz_2'].'</td><td>'.$aphlyScriptLang['dzp_if_gz_msg'].'</td></tr>';
        if($hdInfo['wxgzh_pic']){
			$wxgzh_pic = $_G['setting']['attachurl'].$hdInfo['wxgzh_pic'];
			$wxgzh_pic='<img src="'.dhtmlspecialchars($wxgzh_pic).'" width="40" />';
		}else{
			$wxgzh_pic='';
		}
		$aphlyScriptLang['admin_hd_gzpic_msg'] = $aphlyScriptLang['admin_hd_gzpic_msg'].'<br/>'.$wxgzh_pic;

		echo '<tr class="header"><th width="10%">'.$aphlyScriptLang['admin_hd_gzpic'].'</th><td width="25%"><input class="text" name="wxgzh_pic" value="" size="35" type="file"></td><td>'.$aphlyScriptLang['admin_hd_gzpic_msg'].'</td></tr>';

		echo '<tr class="header"><th>'.$aphlyScriptLang['admin_hd_gzms'].':</th><td><input name="wxgzh_disc" type="text" value="'.dhtmlspecialchars($hdInfo['wxgzh_disc']).'" size="40" /></td><td>'.$aphlyScriptLang['admin_hd_gzms_msg'].'</td></tr>';

		

		echo '<tr class="header"><th>'.$aphlyScriptLang['show_cy'].':</th><td><input name="show_cy" type="radio" value="1" '.($hdInfo['show_cy'] == 1?"checked":"").' />'.$aphlyScriptLang['show_cy1'].'<input name="show_cy" type="radio" value="0" '.($hdInfo['show_cy'] == 0?"checked":"").' size="40" />'.$aphlyScriptLang['show_cy0'].'</td><td>'.$aphlyScriptLang['show_cy_msg'].'</td></tr>';
		echo '<tr class="header"><th>'.$aphlyScriptLang['cy_num'].':</th><td><input name="cy_num" type="text" value="'.dhtmlspecialchars($hdInfo['cy_num']).'" size="40" /></td><td>'.$aphlyScriptLang['cy_num_msg'].'</td></tr>';
		
		echo '<tr class="header"><th>'.$aphlyScriptLang['show_zjmd'].':</th><td><input name="show_zjmd" type="radio" value="1" '.($hdInfo['show_zjmd'] == 1?"checked":"").' />'.$aphlyScriptLang['show_zjmd1'].'<input name="show_zjmd" type="radio" value="0" '.($hdInfo['show_zjmd'] == 0?"checked":"").' size="40" />'.$aphlyScriptLang['show_zjmd0'].'</td><td>'.$aphlyScriptLang['show_zjmd_msg'].'</td></tr>';

		echo '<tr class="header"><th>'.$aphlyScriptLang['show_prize_num'].':</th><td><input name="show_prize_num" type="radio" value="1" '.($hdInfo['show_prize_num'] == 1?"checked":"").' />'.$aphlyScriptLang['show_prize_num1'].'<input name="show_prize_num" type="radio" value="0" size="40" '.($hdInfo['show_prize_num'] == 0?"checked":"").'/>'.$aphlyScriptLang['show_prize_num0'].'</td><td>'.$aphlyScriptLang['show_prize_num_msg'].'</td></tr>';
		
		echo '<tr class="header"><th>'.$aphlyScriptLang['views'].':</th><td><input name="views" type="text" value="'.dhtmlspecialchars($hdInfo['views']).'" size="40" /></td><td>'.$aphlyScriptLang['views_msg'].'</td></tr>';
        
		echo '<tr class="header"><th></th><td><input type="submit" class="btn" name="submit" title="" value="'.$aphlyScriptLang['discuz_tj_bt'].'"></td><td></td></tr>';

        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
    }
}else if($_GET['act'] == 'listuser'){
    $hd_id     = isset($_GET['hd_id'])? intval($_GET['hd_id']):0;
	$hdInfo = $dzp->fetch_by_id($hd_id);
    $pagesize = 15;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    
    $order_str = " ORDER BY id DESC ";
    
    $count = C::t('#aphly_dzp#aphly_dzp_user')->fetch_all_count(" AND hd_id = {$hd_id} ");
    $userList = C::t('#aphly_dzp#aphly_dzp_user')->fetch_all_list(" AND hd_id = {$hd_id} ",$order_str,$start,$pagesize);
	$uids=array();
	foreach ($userList as $key => $value) {
		$uids[]=$value['uid'];
	}
	$memberdatas = C::t('common_member')->fetch_all($uids);
    showtableheader('','aphlybk');
    echo '<tr><th colspan="15" class="partition">' .dhtmlspecialchars($hdInfo['title']).' > '.$aphlyScriptLang['user_list'].'</th></tr>';
    echo '<tr class="header">';
    echo '<tr><th colspan="5">';
    echo '&nbsp;&nbsp;<a class="aphly_dc" target="_blank" href="'.$_G['siteurl'].'plugin.php?id=aphly_dzp:dc&hd_id='.$hd_id.'&ms=1">' . $aphlyScriptLang['user_export'] . '</a>';
	echo '</th></tr>';
    echo '</th></tr>';
    echo '<tr class="header">';
    echo '<th width="10%">UID</th>';
    echo '<th>' . $aphlyScriptLang['user_xm'] . '</th>';
    echo '<th>' . $aphlyScriptLang['user_tel'] . '</th>';
    echo '<th>' . $aphlyScriptLang['sy_cj_times'] . '</th>';
    echo '<th>' . $aphlyScriptLang['user_cj_znum'] . '</th>';
	echo '<th>' . $aphlyScriptLang['user_share_num'] . '</th>';
	echo '<th>' . $aphlyScriptLang['duij'] . '</th>';
    echo '<th>' . $aphlyScriptLang['user_add_time'] . '</th>';
    echo '<th>' . $aphlyScriptLang['dzp_cz'] . '</th>';
    echo '</tr>';
    
    $i = ($page-1)*$pagesize + 1;
    foreach ($userList as $key => $value) {
        echo '<tr class="ap_li">';
        echo '<td>' . $value['uid'] . '</td>';
        echo '<td><a href="home.php?mod=space&uid='.$value['uid'].'&do=profile">' . dhtmlspecialchars($memberdatas[$value['uid']]['username']) . '</a></td>';
        echo '<td>' . (!empty($value['tel'])?dhtmlspecialchars($value['tel']):$aphlyScriptLang['no_tel']) . '</td>';
        echo '<td>' . dhtmlspecialchars($value['chance_num']+$value['set_cj_num']-$value['cj_num']) . '</td>';
		echo '<td>' . dhtmlspecialchars($value['cj_num']) . '</td>';
		echo '<td>' . dhtmlspecialchars($value['share_num']) . '</td>';
		$duij = $value['duij']?$aphlyScriptLang['mb_dj_ydj']:$aphlyScriptLang['mb_dj_wdj'];
		echo '<td>' . $duij . '</td>';
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i",$aphlysysoffset) . '</td>';
        echo '<td>';
        //echo '<a href="'.$aphlydzpBaseUrl.'&act=edituser&hd_id='.$hd_id.'&id='.$value['id'].'&formhash='.FORMHASH.'">' . $aphlyScriptLang['user_edit']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$aphlydzpBaseUrl.'&act=deluser&hd_id='.$hd_id.'&id='.$value['id'].'&formhash='.FORMHASH.'">' . $aphlyScriptLang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=aphly_dzp&pmod=admincp&act=listuser&hd_id=".$hd_id);	
    showsubmit('', '', '', '', $multi, false);
}else if($_GET['act'] == 'adduser'){
    $hdInfo = $dzp->fetch_by_id(intval($_GET['hd_id']));
    if(submitcheck('submit')){
		$hd_id        = isset($_GET['hd_id'])? intval($_GET['hd_id']):'';
		$tel		  = isset($_GET['tel'])? addslashes($_GET['tel']):'';
		$randzj=array();
		$prizeLists = C::t('#aphly_dzp#aphly_dzp_prize')->fetch_by_hd_id($hd_id);
		foreach($prizeLists as $value){
			if(($value['prize_znum']-$value['prize_num'])<=0){
				$randzj[$value['if_jx']]=0;
			}else{
				$randzj[$value['if_jx']]=$value['prize_glv'];
			}
		}

        $insertData = array();
		$today = mktime(0, 0, 0, date('m', time()), date('d', time()), date('Y', time()));
        $insertData['hd_id']			= $hd_id;
        $insertData['xm']               = '';
        $insertData['tel']              = $tel;
		$insertData['if_time']          = $today;
        $insertData['add_time']         = TIMESTAMP;
        C::t('#aphly_dzp#aphly_dzp_user')->insert($insertData);
		
        cpmsg($aphlyScriptLang['act_success'], $aphlydzpListUrl.'&act=listuser&hd_id='.$_GET['hd_id'], 'succeed');
    }else{
        echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=aphly_dzp&pmod=admincp&act=adduser&hd_id='.$_GET['hd_id'],'enctype');
        showtableheader();
        
        echo '<tr><th colspan="15" class="partition">' .dhtmlspecialchars($hdInfo['title']).' > '. $aphlyScriptLang['user_list'] .' > '.$aphlyScriptLang['user_add'].'</th></tr>';

        echo '<tr class="header"><th>'.$aphlyScriptLang['user_tel'].'</th><td><input name="tel" type="text" value="" size="40" /></td><td></td></tr>';
        
        echo '<tr class="header"><th></th><td><input type="submit" class="btn" name="submit" title="" value="'.$aphlyScriptLang['discuz_tj_bt'].'"></td><td></td></tr>';

        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
    }
}else if($_GET['act'] == 'listuserzj'){
    $hdInfo = $dzp->fetch_by_id(intval($_GET['hd_id']));
    $hd_id     = isset($_GET['hd_id'])? intval($_GET['hd_id']):0;
    $pagesize = 15;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    
    $order_str = " ORDER BY id DESC ";
    
    $count = C::t('#aphly_dzp#aphly_dzp_user_zj')->fetch_all_count(" AND hd_id = {$hd_id} ");
    $userList = C::t('#aphly_dzp#aphly_dzp_user_zj')->fetch_all_list(" AND hd_id = {$hd_id} AND prize_id!=0",$order_str,$start,$pagesize);
	$uids=array();
	foreach ($userList as $key => $value) {
		$uids[]=$value['uid'];
	}
	$userdatas = C::t('#aphly_dzp#aphly_dzp_user')->fetch_all_hd_id_uids($hd_id,$uids);
    showtableheader('','aphlybk');
    echo '<tr><th colspan="15" class="partition">' .dhtmlspecialchars($hdInfo['title']).' > ' . $aphlyScriptLang['user_list_zj'] . '</th></tr>';
    echo '<tr class="header">';
    echo '<tr><th colspan="5">';
    echo '&nbsp;&nbsp;<a class="aphly_dc" target="_blank" href="'.$_G['siteurl'].'plugin.php?id=aphly_dzp:dc&hd_id='.$hd_id.'&ms=2">' . $aphlyScriptLang['user_export_zj'] . '</a>';
    echo '</th><th><a class="addtr" href="'.$aphlydzpBaseUrl.'&act=adduserzj&hd_id='.$hd_id.'&formhash='.FORMHASH.'">' . $aphlyScriptLang['user_zj_add']. '</a></th></tr>';
    echo '<tr class="header">';
    echo '<th width="10%">ID</th>';
    echo '<th>' . $aphlyScriptLang['user_xm'] . '</th>';
    echo '<th>' . $aphlyScriptLang['user_tel'] . '</th>';
	echo '<th>' . $aphlyScriptLang['user_list_zjjx'] . '</th>';
    echo '<th>' . $aphlyScriptLang['user_add_time'] . '</th>';
    echo '<th>' . $aphlyScriptLang['dzp_cz'] . '</th>';
    echo '</tr>';
    
    $i = ($page-1)*$pagesize + 1;
    foreach ($userList as $key => $value) {
        echo '<tr class="ap_li">';
        echo '<td>' . $i . '</td>';
        echo '<td><a href="home.php?mod=space&uid='.$value['uid'].'&do=profile">' . dhtmlspecialchars($value['username']) . '</a></td>';
        echo '<td>' . (!empty($userdatas[$value['uid']]['tel'])?dhtmlspecialchars($userdatas[$value['uid']]['tel']):$aphlyScriptLang['no_tel']) . '</td>';
		if($value['prize_id']==1){
			$zjmc = $aphlyScriptLang['user_list_ydj'];
		}else if($value['prize_id']==2){
			$zjmc = $aphlyScriptLang['user_list_edj'];
		}else if($value['prize_id']==3){
			$zjmc = $aphlyScriptLang['user_list_sdj'];
		}else if($value['prize_id']==4){
			$zjmc = $aphlyScriptLang['user_list_sidj'];
		}else if($value['prize_id']==5){
			$zjmc = $aphlyScriptLang['user_list_wdj'];
		}else if($value['prize_id']==0){
			$zjmc = $aphlyScriptLang['user_list_xxcy'];
		}else{
			$zjmc = $aphlyScriptLang['user_list_xxcy'];
		}
		echo '<td>' . $zjmc . '</td>';
        echo '<td>' . dgmdate($value['add_time'],"Y-m-d H:i",$aphlysysoffset) . '</td>';
        echo '<td>';
		if($value['type']==2){
        echo '<a href="'.$aphlydzpBaseUrl.'&act=deluserzj&hd_id='.$hd_id.'&id='.$value['id'].'&formhash='.FORMHASH.'">' . $aphlyScriptLang['delete'] . '</a>';
		}else{
		echo '<a href="'.$aphlydzpBaseUrl.'&act=deluserzj&hd_id='.$hd_id.'&id='.$value['id'].'&formhash='.FORMHASH.'">' . $aphlyScriptLang['delete'] . '</a>';
		}
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=aphly_dzp&pmod=admincp&act=listuserzj&hd_id=".$hd_id);	
    showsubmit('', '', '', '', $multi, false);
}else if($_GET['act'] == 'edituser'){
    $userInfo = C::t('#aphly_dzp#aphly_dzp_user')->fetch_by_id(intval($_GET['id']));
    $hdInfo = $dzp->fetch_by_id(intval($_GET['hd_id']));
    if(submitcheck('submit')){
        $set_cj_num     = isset($_GET['set_cj_num'])? intval($_GET['set_cj_num']):'';
        
        $updateData = array();
        $updateData['set_cj_num'] = $userInfo['set_cj_num']+$set_cj_num;

        C::t('#aphly_dzp#aphly_dzp_user')->update($userInfo['id'],$updateData);
        cpmsg($aphlyScriptLang['act_success'], $aphlydzpListUrl.'&act=listuser&hd_id='.$_GET['hd_id'], 'succeed');
    }else{
        echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=aphly_dzp&pmod=admincp&act=edituser&id='.$_GET['id'].'&hd_id='.$_GET['hd_id'],'enctype');
        showtableheader();
        
        echo '<tr><th colspan="15" class="partition">' .dhtmlspecialchars($hdInfo['title']).' > '. $aphlyScriptLang['user_edit'] . '</th></tr>';
        
        echo '<tr class="header"><th width="10%">'.$aphlyScriptLang['user_xm'].'</th><td width="30%">'.dhtmlspecialchars($userInfo['xm']).'</td><td></td></tr>';
        
        echo '<tr class="header"><th>'.$aphlyScriptLang['user_tel'].'</th><td>'.dhtmlspecialchars($userInfo['tel']).'</td><td></td></tr>';
        
        echo '<tr class="header"><th>'.$aphlyScriptLang['set_cj_num'].'</th><td><input name="set_cj_num" type="text" value="'.dhtmlspecialchars($userInfo['set_cj_num']).'" size="40" /></td><td></td></tr>';

        echo '<tr class="header"><th></th><td><input type="submit" class="btn" name="submit" title="" value="'.$aphlyScriptLang['discuz_tj_bt'].'"></td><td></td></tr>';

        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
    }
}else if($_GET['act'] == 'adduserzj'){
	$hd_id        = isset($_GET['hd_id'])? intval($_GET['hd_id']):0;
    $hdInfo = $dzp->fetch_by_id($hd_id);
    if(submitcheck('submit')){
		$uid     = isset($_GET['uid'])? intval($_GET['uid']):'';
		$userInfo = C::t('#aphly_dzp#aphly_dzp_user')->fetch_by_hd_id_uid($hd_id,$uid);
		$member = getuserbyuid($uid);
		if($userInfo && $member){
			$prize_id     = isset($_GET['prize_id'])? intval($_GET['prize_id']):'';
			$userzj_time     = isset($_GET['userzj_time'])? strtotime(addslashes($_GET['userzj_time'])):'';

			$updateDataid = array();
			$updateDataid['cj_num']         = $userInfo['cj_num']+1;
			C::t('#aphly_dzp#aphly_dzp_user')->update($userInfo['id'],$updateDataid);

			$insertDatazj = array();
			$insertDatazj['uid']		      = $member['uid'];
			$insertDatazj['prize_id']		  = $prize_id;
			$insertDatazj['hd_id']			  = $hd_id;
			$insertDatazj['username']         = $member['username'];
			$insertDatazj['type']             = 2;
			$insertDatazj['add_time']         = $userzj_time;
			C::t('#aphly_dzp#aphly_dzp_user_zj')->insert($insertDatazj);
			
			$prizeInfo = C::t('#aphly_dzp#aphly_dzp_prize')->fetch_by_hd_id_if_jx($hd_id,$prize_id);
			if($prizeInfo['prize_znum']>$prizeInfo['prize_num']){
				$updateDataprize = array();
				$updateDataprize['prize_num']	= $prizeInfo['prize_num']+1;
				C::t('#aphly_dzp#aphly_dzp_prize')->update($prizeInfo['id'],$updateDataprize);
			}
			cpmsg($aphlyScriptLang['act_success'], $aphlydzpListUrl.'&act=listuserzj&hd_id='.$_GET['hd_id'], 'succeed');
		}else{
			cpmsg($aphlyScriptLang['act_fail'], $aphlydzpListUrl.'&act=listuserzj&hd_id='.$_GET['hd_id'], 'error');
		}
    }else{
        echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=aphly_dzp&pmod=admincp&act=adduserzj&hd_id='.$_GET['hd_id'],'enctype');
        showtableheader();
        
        echo '<tr><th colspan="15" class="partition">' .dhtmlspecialchars($hdInfo['title']).' > '. $aphlyScriptLang['user_list_zj'] .' > '.$aphlyScriptLang['user_zj_add'].'</th></tr>';
        
        echo '<tr class="header"><th width="10%">'.$aphlyScriptLang['uid'].'</th><td width="30%"><input name="uid" type="text" value="" size="40" /></td><td></td></tr>';

        echo '<tr class="header"><th>'.$aphlyScriptLang['user_prize_id'].'</th><td><input name="prize_id" type="radio" value="1" />'.$aphlyScriptLang['user_list_ydj'].'<input name="prize_id" type="radio" value="2" />'.$aphlyScriptLang['user_list_edj'].'<input name="prize_id" type="radio" value="3" />'.$aphlyScriptLang['user_list_sdj'].'<input name="prize_id" type="radio" value="4" />'.$aphlyScriptLang['user_list_sidj'].'<input name="prize_id" type="radio" value="5" />'.$aphlyScriptLang['user_list_wdj'].'</td><td></td></tr>';
		
		echo '<tr class="header"><th>'.$aphlyScriptLang['user_add_time_zj'].':</th><td><input name="userzj_time" type="text" value="" size="25" onclick="showcalendar(event, this, 1)" /></td><td></td></tr>';

        echo '<tr class="header"><th></th><td><input type="submit" class="btn" name="submit" title="" value="'.$aphlyScriptLang['discuz_tj_bt'].'"></td><td></td></tr>';

        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
    }

}else if($_GET['act'] == 'listprize'){
    $hdInfo = $dzp->fetch_by_id(intval($_GET['hd_id']));
    $hd_id     = isset($_GET['hd_id'])? intval($_GET['hd_id']):0;
    $prizeList = C::t('#aphly_dzp#aphly_dzp_prize')->fetch_all_list(" AND hd_id = {$hd_id} ","ORDER BY px ASC",0,50);
    showtableheader('','aphlybk');
    echo '<tr><th colspan="15" class="partition">' .dhtmlspecialchars($hdInfo['title']).' > ' . $aphlyScriptLang['prize_list'] . '</th></tr>';
    echo '<tr><th colspan="15">';
    echo '&nbsp;&nbsp;<a class="addtr" href="'.$aphlydzpBaseUrl.'&act=addprize&hd_id='.$hd_id.'">' . $aphlyScriptLang['prize_add'] . '</a>';
    echo '</th></tr>';
    echo '<tr class="header">';
    echo '<th width="10%">'.$aphlyScriptLang['user_list_zjjx'].' </th>';
    echo '<th>' . $aphlyScriptLang['prize_title'] . '</th>';
    echo '<th>' . $aphlyScriptLang['prize_pic'] . '</th>';
	echo '<th>' . $aphlyScriptLang['prize_znum'] . '</th>';
    echo '<th>' . $aphlyScriptLang['prize_num'] . '</th>';
	echo '<th>' . $aphlyScriptLang['prize_glv'] . ' ( % ) </th>';
    echo '<th>' . $aphlyScriptLang['dzp_cz'] . '</th>';
    echo '</tr>';
    
    foreach ($prizeList as $key => $value) {
		if($value['prize_pic']){
			$prize_pic = $_G['setting']['attachurl'].$value['prize_pic'];
			$prize_pic ='<img src="'.dhtmlspecialchars($prize_pic).'" width="40" />';
		}else{
			$prize_pic ='';
		}
        echo '<tr class="ap_li">';

		if($value['if_jx']==1){
			$jpmc = $aphlyScriptLang['user_list_ydj'];
		}else if($value['if_jx']==2){
			$jpmc = $aphlyScriptLang['user_list_edj'];
		}else if($value['if_jx']==3){
			$jpmc = $aphlyScriptLang['user_list_sdj'];
		}else if($value['if_jx']==4){
			$jpmc = $aphlyScriptLang['user_list_sidj'];
		}else if($value['if_jx']==5){
			$jpmc = $aphlyScriptLang['user_list_wdj'];
		}else if($value['if_jx']==0){
			$jpmc = $aphlyScriptLang['user_list_xxcy'];
		}

        echo '<td>' . $jpmc . '</td>';
        echo '<td>' . dhtmlspecialchars($value['prize_title']) . '</td>';
        echo '<td>'.$prize_pic.'</td>';
        echo '<td>' . dhtmlspecialchars($value['prize_znum']) . '</td>';
		echo '<td>' . dhtmlspecialchars($value['prize_znum']-$value['prize_num']) . '</td>';
		echo '<td>' . dhtmlspecialchars($value['prize_glv']) . '</td>';
        echo '<td>';
        echo '<a href="'.$aphlydzpBaseUrl.'&act=editprize&hd_id='.$hd_id.'&id='.$value['id'].'&formhash='.FORMHASH.'">' . $aphlyScriptLang['prize_edit']. '</a>&nbsp;&nbsp;';
        echo '<a href="'.$aphlydzpBaseUrl.'&act=delprize&hd_id='.$hd_id.'&id='.$value['id'].'&formhash='.FORMHASH.'">' . $aphlyScriptLang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
    }
    showtablefooter(); /*Dism��taobao��com*/
}else if($_GET['act'] == 'addprize'){
    $hdInfo = $dzp->fetch_by_id(intval($_GET['hd_id']));
    if(submitcheck('submit')){
        $hd_id			= isset($_GET['hd_id'])? intval($_GET['hd_id']):0;
        $prize_title    = isset($_GET['prize_title'])? addslashes($_GET['prize_title']):'';
		$prize_if_jx      = isset($_GET['if_jx'])? intval($_GET['if_jx']):'';
        $prize_num      = isset($_GET['prize_num'])? intval($_GET['prize_num']):'';
		$prize_glv      = isset($_GET['prize_glv'])? floatval($_GET['prize_glv']):'';
        $px			    = isset($_GET['px'])? intval($_GET['px']):'';
		 $type			    = isset($_GET['type'])? intval($_GET['type']):1;
		 $jf_type			= isset($_GET['jf_type'])? intval($_GET['jf_type']):'';
		 $jf			    = isset($_GET['jf'])? intval($_GET['jf']):'';
        if($_FILES['prize_pic']['tmp_name']) {
			$prize_pic = $dzp->picupload('prize_pic');
		}else{
			$prize_pic = addslashes($_GET['prize_pic']);
		}
        $insertData = array();
        $insertData['hd_id']			  = $hd_id;
		$insertData['if_jx']			  = $prize_if_jx;
        $insertData['prize_title']        = $prize_title;
        $insertData['prize_num']          = 0;
		$insertData['prize_znum']         = $prize_num;
		$insertData['prize_glv']          = $prize_glv;
        $insertData['prize_pic']		  = $prize_pic;
        $insertData['px']				  = $px;
		$insertData['type']				  = $type;
		$insertData['jf_type']			  = $jf_type;
		$insertData['jf']				  = $jf;
        C::t('#aphly_dzp#aphly_dzp_prize')->insert($insertData);
        cpmsg($aphlyScriptLang['act_success'], $aphlydzpListUrl.'&act=listprize&hd_id='.$hd_id, 'succeed');
    }else{
		

        echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=aphly_dzp&pmod=admincp&act=addprize&hd_id='.$_GET['hd_id'],'enctype');
        showtableheader();
        echo '<tr><th colspan="15" class="partition">' .dhtmlspecialchars($hdInfo['title']).' > ' . $aphlyScriptLang['prize_list'] . ' > '. $aphlyScriptLang['prize_add'] . '</th></tr>';
        
		echo '<tr class="header"><th>'.$aphlyScriptLang['user_list_zjjx'].'</th><td><input name="if_jx" type="radio" value="1" />'.$aphlyScriptLang['user_list_ydj'].'<input name="if_jx" type="radio" value="2" />'.$aphlyScriptLang['user_list_edj'].'<input name="if_jx" type="radio" value="3" />'.$aphlyScriptLang['user_list_sdj'].'<input name="if_jx" type="radio" value="4" />'.$aphlyScriptLang['user_list_sidj'].'<input name="if_jx" type="radio" value="5" />'.$aphlyScriptLang['user_list_wdj'].'</td><td></td></tr>';

        echo '<tr class="header"><th>'.$aphlyScriptLang['prize_title'].'</th><td><input name="prize_title" type="text" value="" size="40" /></td><td>'.$aphlyScriptLang['prize_title_msg'].'</td></tr>';
        
        echo '<tr class="header"><th>'.$aphlyScriptLang['prize_znum'].'</th><td><input name="prize_num" type="text" value="" size="40" /></td><td>'.$aphlyScriptLang['prize_num_msg'].'</td></tr>';

		echo '<tr class="header"><th>'.$aphlyScriptLang['prize_glv'].'</th><td><input name="prize_glv" type="text" value="" size="40" /></td><td>'.$aphlyScriptLang['prize_glv_msg'].'</td></tr>';
        
		echo '<tr class="header"><th width="10%">'.$aphlyScriptLang['prize_pic'].'</th><td width="25%"><input class="text" name="prize_pic" value="" size="35" type="file"></td><td>'.$aphlyScriptLang['prize_pic_msg'].'</td></tr>';
        
        echo '<tr class="header"><th>'.$aphlyScriptLang['px'].'</th><td><input name="px" type="text" value="0" size="40" /></td><td></td></tr>';

		echo '<tr class="header"><th>'.$aphlyScriptLang['type'].'</th><td><input name="type" type="radio" value="1" checked />'.$aphlyScriptLang['type1'].'<input name="type" type="radio" value="2" />'.$aphlyScriptLang['type2'].'</td><td></td></tr>';
		
		$html = '';
		foreach($extcredits as $k=>$v){
			$html .= '<input name="jf_type" type="radio" value="'.$k.'" />'.$v['title'];
		}
		echo '<tr class="header"><th>'.$aphlyScriptLang['jf_type'].'</th><td>'.$html.'</td><td>'.$aphlyScriptLang['jf_msg'].'</td></tr>';
		echo '<tr class="header"><th>'.$aphlyScriptLang['jf'].'</th><td><input name="jf" type="text" value="0" size="40" /></td><td>'.$aphlyScriptLang['jf_msg'].'</td></tr>';
        
		echo '<tr class="header"><th></th><td><input type="submit" class="btn" name="submit" title="" value="'.$aphlyScriptLang['discuz_tj_bt'].'"></td><td></td></tr>';

        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
    }
}else if($_GET['act'] == 'editprize'){
    $prizeInfo = C::t('#aphly_dzp#aphly_dzp_prize')->fetch_by_id(intval($_GET['id']));
    $hdInfo = $dzp->fetch_by_id(intval($_GET['hd_id']));
    if(submitcheck('submit')){
        $hd_id     = isset($_GET['hd_id'])? intval($_GET['hd_id']):0;
		$if_jx     = isset($_GET['if_jx'])? intval($_GET['if_jx']):0;
        $prize_title    = isset($_GET['prize_title'])? addslashes($_GET['prize_title']):'';
        $prize_znum		= isset($_GET['prize_znum'])? intval($_GET['prize_znum']):'';
		$prize_glv		= isset($_GET['prize_glv'])? floatval($_GET['prize_glv']):'';
        $px			    = isset($_GET['px'])? intval($_GET['px']):'';
		$type			    = isset($_GET['type'])? intval($_GET['type']):1;
		$jf_type			= isset($_GET['jf_type'])? intval($_GET['jf_type']):'';
		$jf			    = isset($_GET['jf'])? intval($_GET['jf']):'';
        if($_FILES['prize_pic']['tmp_name']) {
			$prize_pic = $dzp->picupload('prize_pic');
		}else{
			$prize_pic = addslashes($prizeInfo['prize_pic']);
		}

        $updateData = array();
        $updateData['hd_id']			= $hd_id;
		$updateData['if_jx']			= $if_jx;
        $updateData['prize_title']      = $prize_title;
		$updateData['prize_znum']       = $prize_znum;
		$updateData['prize_glv']        = $prize_glv;
        $updateData['prize_pic']		= $prize_pic;
        $updateData['px']				= $px;
		$updateData['type']				  = $type;
		$updateData['jf_type']			  = $jf_type;
		$updateData['jf']				  = $jf;
        
        C::t('#aphly_dzp#aphly_dzp_prize')->update($prizeInfo['id'],$updateData);
        cpmsg($aphlyScriptLang['act_success'], $aphlydzpListUrl.'&act=listprize&hd_id='.$hd_id, 'succeed');
    }else{
        echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=aphly_dzp&pmod=admincp&act=editprize&id='.$_GET['id'].'&hd_id='.$_GET['hd_id'],'enctype');
        showtableheader();
        
        echo '<tr><th colspan="15" class="partition">' .dhtmlspecialchars($hdInfo['title']).' > ' . $aphlyScriptLang['prize_list'] . ' > '. $aphlyScriptLang['prize_edit'] . '</th></tr>';

		$if_jx_1_checked = ($prizeInfo['if_jx'] == 1)? "checked":'';
		$if_jx_2_checked = ($prizeInfo['if_jx'] == 2)?"checked":'';
		$if_jx_3_checked = ($prizeInfo['if_jx'] == 3)? "checked":'';
		$if_jx_4_checked = ($prizeInfo['if_jx'] == 4)?"checked":'';
		$if_jx_5_checked = ($prizeInfo['if_jx'] == 5)? "checked":'';
		$if_jx_0_checked = ($prizeInfo['if_jx'] == 0)?"checked":'';

		echo '<tr class="header"><th width="10%">'.$aphlyScriptLang['user_list_zjjx'].'</th><td width="25%"><input name="if_jx" type="radio" value="1" '.$if_jx_1_checked.' />'.$aphlyScriptLang['user_list_ydj'].'<input name="if_jx" type="radio" value="2" '.$if_jx_2_checked.' />'.$aphlyScriptLang['user_list_edj'].'<input name="if_jx" type="radio" value="3" '.$if_jx_3_checked.' />'.$aphlyScriptLang['user_list_sdj'].'<input name="if_jx" type="radio" value="4" '.$if_jx_4_checked.' />'.$aphlyScriptLang['user_list_sidj'].'<input name="if_jx" type="radio" value="5" '.$if_jx_5_checked.' />'.$aphlyScriptLang['user_list_wdj'].'</td><td>'.$aphlyScriptLang['user_list_zjjx_ts'].'</td></tr>';

        echo '<tr class="header"><th>'.$aphlyScriptLang['prize_title'].'</th><td><input name="prize_title" type="text" value="'.dhtmlspecialchars($prizeInfo['prize_title']).'" size="40" /></td><td>'.$aphlyScriptLang['prize_title_msg'].'</td></tr>';
        
        echo '<tr class="header"><th>'.$aphlyScriptLang['prize_znum'].'</th><td><input name="prize_znum" type="text" value="'.dhtmlspecialchars($prizeInfo['prize_znum']).'" size="40" /></td><td>'.$aphlyScriptLang['prize_znum_msg'].'</td></tr>';

		echo '<tr class="header"><th>'.$aphlyScriptLang['prize_glv'].'</th><td><input name="prize_glv" type="text" value="'.dhtmlspecialchars($prizeInfo['prize_glv']).'" size="40" /></td><td>'.$aphlyScriptLang['prize_glv_msg'].'</td></tr>';
        if($prizeInfo['prize_pic']){
			$prize_pic = $_G['setting']['attachurl'].$prizeInfo['prize_pic'];
			$prize_pic='<img src="'.dhtmlspecialchars($prize_pic).'" width="40" />';
		}else{
			$prize_pic='';
		}

        $aphlyScriptLang['prize_pic_msg'] = $aphlyScriptLang['prize_pic_msg'].'<br/>'.$prize_pic;

		echo '<tr class="header"><th>'.$aphlyScriptLang['prize_pic'].':</th><td><input class="text" name="prize_pic" value="'.dhtmlspecialchars($prizeInfo['prize_pic']).'" size="35" type="file"></td><td>'.$aphlyScriptLang['prize_pic_msg'].'</td></tr>';
        
        echo '<tr class="header"><th>'.$aphlyScriptLang['px'].'</th><td><input name="px" type="text" value="'.dhtmlspecialchars($prizeInfo['px']).'" size="40" /></td><td></td></tr>';

		echo '<tr class="header"><th>'.$aphlyScriptLang['type'].'</th><td><input name="type" type="radio" value="1" '.(($prizeInfo['type'] == 1)? "checked":'').' />'.$aphlyScriptLang['type1'].'<input name="type" type="radio" value="2" '.(($prizeInfo['type'] == 2)? "checked":'').' />'.$aphlyScriptLang['type2'].'</td><td></td></tr>';
		
		$html = '';
		foreach($extcredits as $k=>$v){
			if($prizeInfo['jf_type'] == $k){
				$html .= '<input name="jf_type" type="radio" value="'.$k.'" checked />'.$v['title'];
			}else{
				$html .= '<input name="jf_type" type="radio" value="'.$k.'" />'.$v['title'];
			}
		}
		echo '<tr class="header"><th>'.$aphlyScriptLang['jf_type'].'</th><td>'.$html.'</td><td>'.$aphlyScriptLang['jf_msg'].'</td></tr>';
		echo '<tr class="header"><th>'.$aphlyScriptLang['jf'].'</th><td><input name="jf" type="text" value="'.dhtmlspecialchars($prizeInfo['jf']).'" size="40" /></td><td>'.$aphlyScriptLang['jf_msg'].'</td></tr>';
        
        echo '<tr class="header"><th></th><td><input type="submit" class="btn" name="submit" title="" value="'.$aphlyScriptLang['discuz_tj_bt'].'"></td><td></td></tr>';

        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
    }

}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'del'){
    $dzp->delete_by_id(intval($_GET['id']));
    cpmsg($aphlyScriptLang['act_success'], $aphlydzpListUrl, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'delprize'){
    $hd_id     = isset($_GET['hd_id'])? intval($_GET['hd_id']):0;
    C::t('#aphly_dzp#aphly_dzp_prize')->delete_by_id(intval($_GET['id']));
    cpmsg($aphlyScriptLang['act_success'], $aphlydzpListUrl.'&act=listprize&hd_id='.$hd_id, 'succeed');
    
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'deluser'){
    $hd_id     = isset($_GET['hd_id'])? intval($_GET['hd_id']):0;
    C::t('#aphly_dzp#aphly_dzp_user')->delete_by_id(intval($_GET['id']));
    cpmsg($aphlyScriptLang['act_success'], $aphlydzpListUrl.'&act=listuser&hd_id='.$hd_id, 'succeed');
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'deluserzj'){
    $hd_id     = isset($_GET['hd_id'])? intval($_GET['hd_id']):0;
	$userInfo = C::t('#aphly_dzp#aphly_dzp_user_zj')->fetch_by_id(intval($_GET['id']));
	if($userInfo){
		$prizeInfo = C::t('#aphly_dzp#aphly_dzp_prize')->fetch_by_id($userInfo['prize_id']);
		$updateDataprize = array();
		$updateDataprize['prize_num']	= $prizeInfo['prize_num']-1;
		$updateDataprize['prize_num'] = $updateDataprize['prize_num']>=0?$updateDataprize['prize_num']:0;
		C::t('#aphly_dzp#aphly_dzp_prize')->update($prizeInfo['id'],$updateDataprize);
		C::t('#aphly_dzp#aphly_dzp_user_zj')->delete_by_id(intval($_GET['id']));
		cpmsg($aphlyScriptLang['act_success'], $aphlydzpListUrl.'&act=listuserzj&hd_id='.$hd_id, 'succeed');
	}else{
		cpmsg($aphlyScriptLang['act_fail'], $aphlydzpListUrl.'&act=listuserzj&hd_id='.$hd_id, 'error');
	}
}else if($_GET['formhash'] == FORMHASH && $_GET['act'] == 'status'){
	if(intval($_GET['statusv'])==1){
		$dzp->status_by_id_0(intval($_GET['id']));
	}else{
		$dzp->status_by_id_1(intval($_GET['id']));
	}
    cpmsg($aphlyScriptLang['act_success'], $aphlydzpListUrl, 'succeed');
}else{

    $pagesize = 15;
    $page = intval($_GET['page'])>0? intval($_GET['page']):1;
    $start = ($page-1)*$pagesize;	
    $count = $dzp->fetch_all_count("");
    $hdList = $dzp->fetch_all_list("","ORDER BY id DESC",$start,$pagesize);
    showtableheader('','aphlybk');
    echo '<tr class="header">';
    echo '<th width="5%">' . $aphlyScriptLang['dzp_id'] . '</th>';
    echo '<th width="18%">' . $aphlyScriptLang['dzp_title'] . '</th>';
    echo '<th width="6%">' . $aphlyScriptLang['dzp_hdzt'] . '</th>';
    echo '<th width="18%">' . $aphlyScriptLang['dzp_time'] . '</th>';
    echo '<th width="15%">' . $aphlyScriptLang['dzp_ewm'] . '</th>';
    echo '<th>' . $aphlyScriptLang['dzp_cz'] . '</th>';
    echo '</tr>';
    
    $i = 1;
    foreach ($hdList as $key => $value) {        
		
		if(TIMESTAMP < $value['start_time']){
			$dzp_hdzt = $aphlyScriptLang['dzp_hd_wks'];
		}else if(TIMESTAMP>=$value['start_time'] && TIMESTAMP <= $value['end_time']){
			if($value['status']==1){
				$dzp_hdzt = '<a href="'.$aphlydzpBaseUrl.'&act=status&id='.$value['id'].'&formhash='.FORMHASH.'&statusv='.$value['status'].'">'.$aphlyScriptLang['dzp_hd_jxz'].'</a>';
			}else{
				$dzp_hdzt = '<a href="'.$aphlydzpBaseUrl.'&act=status&id='.$value['id'].'&formhash='.FORMHASH.'&statusv='.$value['status'].'">'.$aphlyScriptLang['dzp_hd_ztz'].'</a>';
			}
		}else if(TIMESTAMP > $value['end_time']){
			$dzp_hdzt = $aphlyScriptLang['dzp_hd_yjs'];
		}

        echo '<tr class="ap_li">';
        echo '<td>' . $value['id'] . '</td>';
        echo '<td><a href='.$_G['siteurl'].'plugin.php?id=aphly_dzp&hd_id='.$value['id'].'&mobile=no target="_blank">' . dhtmlspecialchars($value['title']) . '</a></td>';
        echo '<td>' . $dzp_hdzt . '</td>';
        echo '<td><span class="aphly_qs">' . dhtmlspecialchars(dgmdate($value['start_time'],"Y-m-d H:i",$aphlysysoffset)) .'</span>-<span class="aphly_zd">'. dhtmlspecialchars(dgmdate($value['end_time'],"Y-m-d H:i",$aphlysysoffset)).'</span></td>';
		echo '<td><a href="javascript:showWindow(\'aphlydzp\', \'plugin.php?id=aphly_dzp:qr&hd_id='.$value['id'].'\', \'get\' ,0);"><img src="source/plugin/aphly_dzp/imgs/ewm.png" /></a></td>';
        echo '<td>';
		echo '<a href="'.$aphlydzpBaseUrl.'&act=edit&id='.$value['id'].'&formhash='.FORMHASH.'">' . $aphlyScriptLang['dzp_edit']. '</a>&nbsp;|&nbsp;';
		echo '<a href="'.$aphlydzpBaseUrl.'&act=listprize&hd_id='.$value['id'].'&formhash='.FORMHASH.'">' . $aphlyScriptLang['prize_list']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$aphlydzpBaseUrl.'&act=listuser&hd_id='.$value['id'].'&formhash='.FORMHASH.'">' . $aphlyScriptLang['user_list']. '</a>&nbsp;|&nbsp;';
		echo '<a href="'.$aphlydzpBaseUrl.'&act=listuserzj&hd_id='.$value['id'].'&formhash='.FORMHASH.'">' . $aphlyScriptLang['user_list_zj']. '</a>&nbsp;|&nbsp;';
		echo '<a href="'.$_G['siteurl'].'plugin.php?id=aphly_dzp:duij&hd_id='.$value['id'].'&mobile=no" target="_blank">' . $aphlyScriptLang['admin_hd_dj']. '</a>&nbsp;|&nbsp;';
        echo '<a href="'.$aphlydzpBaseUrl.'&act=del&id='.$value['id'].'&formhash='.FORMHASH.'">' . $aphlyScriptLang['delete'] . '</a>';
        echo '</td>';
        echo '</tr>';
        $i++;
    }
    showtablefooter(); /*Dism��taobao��com*/
    $multi = multi($count, $pagesize, $page, ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=aphly_dzp&pmod=admincp");	
    showsubmit('', '', '', '', $multi, false);
}