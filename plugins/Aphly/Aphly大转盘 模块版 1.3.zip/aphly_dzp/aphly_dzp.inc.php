<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$dzp=C::t('#aphly_dzp#aphly_dzp');
$dzp_prize=C::t('#aphly_dzp#aphly_dzp_prize');
$dzp_user=C::t('#aphly_dzp#aphly_dzp_user');
$dzp_user_zj=C::t('#aphly_dzp#aphly_dzp_user_zj');

$hd_id = isset($_GET['hd_id'])? intval($_GET['hd_id']):0;

$jp=0;
$chance=0;
$hdstatus = 1;
$hdInfo = $dzp->fetch_by_id($hd_id);
if(!$hdInfo){
	showmessage(lang('plugin/aphly_dzp','no_hd'));
}

$prizeList = $dzp_prize->fetch_all_list_p(" AND hd_id = {$hd_id} ","ORDER BY px ASC");

require_once libfile('function/discuzcode');
$hdInfo['content'] = discuzcode($hdInfo['content'], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0);

if(!empty($hdInfo['wxgzh_pic'])){
	$hdInfo['wxgzh_pic'] = $_G['setting']['attachurl'].$hdInfo['wxgzh_pic'];
}else{
	$hdInfo['wxgzh_pic']='';
}
if(!empty($hdInfo['dingbu_pic'])){
	$hdInfo['dingbu_pic'] = $_G['setting']['attachurl'].$hdInfo['dingbu_pic'];
}else{
	$hdInfo['dingbu_pic']='';
}
$aphly_dzp_fx_ctrl = getcookie('aphly_dzp_fx_ctrl'.$hd_id);
$fuid = isset($_GET['fuid'])? intval($_GET['fuid']):0;
if($fuid && $_G['mobile'] && !$aphly_dzp_fx_ctrl){
	$fuser = getuserbyuid($fuid, 1);
	if($fuser){
		$fuserInfo = $dzp_user->fetch_by_hd_uid($hd_id,$fuser['uid']);
		if($fuserInfo){
			if($hdInfo['if_share']==1 && $fuid!=$_G['uid']){
				if($dzp->is_today($fuserInfo['if_s_time'])){
					if($fuserInfo['share_num']<$hdInfo['mr_share_num']){
						$dzp_user->update($fuserInfo['id'],array(
							'chance_num'=>$fuserInfo['chance_num']+1,
							'share_num'=>$fuserInfo['share_num']+1,
							'share_znum'=>$fuserInfo['share_znum']+1,
							'if_s_time'=>TIMESTAMP,
						));
						dsetcookie('aphly_dzp_fx_ctrl'.$hd_id,1,12*3600);
					}
				}else{
					$dzp_user->update($fuserInfo['id'],array(
						'chance_num'=>$fuserInfo['chance_num']+1,
						'share_num'=>1,
						'share_znum'=>$fuserInfo['share_znum']+1,
						'if_s_time'=>TIMESTAMP,
					));
					dsetcookie('aphly_dzp_fx_ctrl'.$hd_id,1,12*3600);
				}
				
			}
		}
	}
}

if($_G['uid']){
	$currurl=$_G['siteurl']."plugin.php?id=aphly_dzp&hd_id={$hd_id}&fuid={$_G['uid']}";
}else{
	$currurl=$_G['siteurl']."plugin.php?id=aphly_dzp&hd_id={$hd_id}";
}

if($_G['uid'] && $fuid!=$_G['uid']){
	dheader('location:'.$currurl);
	exit;
}


if($_G['uid']){
	if($hdInfo['join']){
		$wechatinfo = C::t('#aphly_wechat#common_member_aphly_wechat')->fetch_by_uid_a($_G['uid']);
	}
	$userInfo = $dzp_user->fetch_by_hd_uid($hd_id,$_G['uid']);
	if($userInfo){
		if($hdInfo['mtzj']==1 && !$dzp->is_today($userInfo['if_time'])){
			$updateData = array();	
			$updateData['if_time'] = TIMESTAMP;
			$userInfo['chance_num'] = $updateData['chance_num']  = $userInfo['chance_num']+$hdInfo['mr_cj_num'];
			$dzp_user->update($userInfo['id'],$updateData);
		}

		$chance = $userInfo['chance_num']+$userInfo['set_cj_num']-$userInfo['cj_num'];
		$chance = $chance>0?$chance:0;
	}
}

if($hdInfo['show_zjmd']){
	$pagesize = 10;
	$page = isset($_GET['page'])?intval($_GET['page']):1;
	if($page){
		$start = ($page-1)*$pagesize;
		$mdcount = $dzp_user_zj->fetch_all_count(" AND hd_id = {$hd_id}");
		$pagecount = ceil($mdcount/$pagesize);
		if($mdcount){
			$order_str = " ORDER BY id DESC ";
			$zjmdList = $dzp_user_zj->fetch_all_list(" AND hd_id = {$hd_id}",$order_str,$start,$pagesize);
		}
	}
}

$djs=$hdInfo['end_time']-TIMESTAMP;
$djs=$djs>0?$djs:0;
$wks=TIMESTAMP-$hdInfo['start_time'];
$wks=$wks>0?$wks:0;

$dzp->views($hd_id);
if(in_array('aphly_wxfx', $_G["setting"]["plugins"]["available"])){
	if(!empty($hdInfo['share_pic'])){
		$hdInfo['share_pic'] = $_G['setting']['attachurl'].$hdInfo['share_pic'];
	}else{
		$hdInfo['share_pic']=$_G['siteurl'].'source/plugin/aphly_dzp/imgs/share_pic.png';
	}
	require_once DISCUZ_ROOT.'./source/plugin/aphly_wxfx/aphly_fxapi.php';
	$fxapi = new aphly_fxapi;
	$wxfx = $fxapi->aphly_share($hdInfo['title'],$hdInfo['share_desc'],$hdInfo['share_pic']);
}
if($_G['mobile']){
	include template("aphly_dzp:index"); 
}else{
	include template("aphly_dzp:ts"); 
}