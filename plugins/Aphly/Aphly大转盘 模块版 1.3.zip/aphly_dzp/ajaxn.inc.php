<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if($_GET['formhash'] != FORMHASH){
	exit('error_formhash');
}
$hd_id = isset($_GET['hd_id'])? intval($_GET['hd_id']):0;
if(!$hd_id){
	exit('no_hd_id');
}
$dzp_user=C::t('#aphly_dzp#aphly_dzp_user');
$dzp_prize=C::t('#aphly_dzp#aphly_dzp_prize');
$dzp=C::t('#aphly_dzp#aphly_dzp');
$dzp_user_zj=C::t('#aphly_dzp#aphly_dzp_user_zj');
$aphly_dzp = $_G['cache']['plugin']['aphly_dzp'];
$res = array();
$res['jp'] = 0;
$res['chance'] = 0;
$res['status'] = 1;
$hdInfo = $dzp->fetch_by_id($hd_id);
if(!$hdInfo){
	$res['code'] = 1000;
	echo json_encode($res);exit();
}else{
	if(!$hdInfo['status']){
		$res['code'] = 1001;
		$res['status'] = 0;
		echo json_encode($res);exit();
	}
	if(TIMESTAMP<$hdInfo['start_time']){
		$res['code'] = 1002;
		$res['status'] = 0;
		echo json_encode($res);exit();
	}else if(TIMESTAMP>$hdInfo['end_time']){
		$res['code'] = 1003;
		$res['status'] = 0;
		echo json_encode($res);exit();
	}
}
if(!$_G['uid']){
	$res['code'] = 1010;
	echo json_encode($res);exit();
}

if($_GET['act'] == 'getjp'){
	$userInfo = $dzp_user->fetch_by_hd_uid($hd_id,$_G['uid']);
	if($userInfo){
		$updateData = array();	
		if($hdInfo['mtzj']==1 && !$dzp->is_today($userInfo['if_time'])){
			$updateData['if_time'] = TIMESTAMP;
			$userInfo['chance_num'] = $updateData['chance_num'] = $userInfo['chance_num']+$hdInfo['mr_cj_num'];
			$dzp_user->update($userInfo['id'],$updateData);
		}
		$res['chance'] = $userInfo['chance_num']+$userInfo['set_cj_num']-$userInfo['cj_num'];
		if($res['chance']>0){
			$updateData = array();	
			$res['chance']=$res['chance']-1;
			$updateData['cj_num']	= $userInfo['cj_num'] + 1;
			$dzp_user->update($userInfo['id'],$updateData);

			if($hdInfo['zj_num']){
				$zj_num = $dzp_user_zj->findzjCount($hd_id,$_G['uid']);
				if($zj_num>=$hdInfo['zj_num'] && $hdInfo['zj_num']){
					$res['code'] = 2002;
					$res['jp'] = 0;
					exit(json_encode($res));
				}
			}

			$randzj = $dzp_prize->fetch_all_list_glv(' AND hd_id ='.$hd_id);
			$res['jp']=$dzp_prize->get_rand($randzj);
			$res['jp']=intval($res['jp']);
			if($res['jp']>=1 && $res['jp']<=5){
				$prizeInfo = $dzp_prize->fetch_by_hd_id_if_jx($hd_id,$res['jp']);
				$res['jpnum'] = $prizeInfo['prize_znum']-$prizeInfo['prize_num'];
				if($res['jpnum']>0){
					$dzp_prize->update($prizeInfo['id'],array('prize_num'=>($prizeInfo['prize_num']+1)));
				}else{
					$res['jp']=0;
					$res['code'] = 2009;
					exit(json_encode($res));
				}

				$currprizeInfo = $dzp_prize->fetch_by_hd_id_if_jx($hd_id,$res['jp']);
				if($currprizeInfo['type']==2){
					updatemembercount($userInfo['uid'], array('extcredits'.$currprizeInfo['jf_type'] => +$currprizeInfo['jf']), true, '', 0, '', lang('plugin/aphly_dzp','jfnotigy'), '');
				}
				$dzp_user_zj->insert(array(
					'uid'=>$userInfo['uid'],
					'prize_id'=>$res['jp'],
					'hd_id'=>$userInfo['hd_id'],
					'username'=>$_G['username'],
					'add_time'=>TIMESTAMP
				));
				$res['code'] = 2000;
				exit(json_encode($res));
			}else{
				$res['code'] = 2008;
				exit(json_encode($res));
			}
		}

		$res['code'] = 2003;
		$res['chance'] = 0;
		exit(json_encode($res));
		
	}else{
		$res['code'] = 2001;
		exit(json_encode($res));
	}
}else if($_GET['act'] == 'join'){
	if($hdInfo['join']){
		$wechatinfo = C::t('#aphly_wechat#common_member_aphly_wechat')->fetch_by_uid_a($_G['uid']);
		if($wechatinfo){
			$userInfo = $dzp_user->fetch_by_hd_uid($hd_id,$_G['uid']);
			if(!$userInfo){
				$data = C::t('common_member_profile')->fetch($_G['uid']);
				$insertData = array();
				$insertData['uid']			= $_G['uid'];
				$insertData['hd_id']		= $hd_id;
				$insertData['chance_num']	= $hdInfo['mr_cj_num'];
				$insertData['if_time']      = TIMESTAMP;
				$insertData['add_time']     = TIMESTAMP;
				$insertData['tel']          = $data['mobile'];
				if($dzp_user->insert($insertData)){
					$dzp->cy1($hd_id);
					$res['code'] = 3000;
					$res['msg'] = 'join_ok';
					exit(json_encode($res));
				}
			}else{
				$res['code'] = 3001;
				$res['msg'] = 'joined';
				exit(json_encode($res));
			}
		}else{
			$res['code'] = 4001;
			$res['msg'] = 'joinwechat';
			exit(json_encode($res));
		}
	}else{
		$userInfo = $dzp_user->fetch_by_hd_uid($hd_id,$_G['uid']);
		if(!$userInfo){
			$data = C::t('common_member_profile')->fetch($_G['uid']);
			$insertData = array();
			$insertData['uid']			= $_G['uid'];
			$insertData['hd_id']		= $hd_id;
			$insertData['if_time']      = TIMESTAMP;
			$insertData['chance_num']	= $hdInfo['mr_cj_num'];
			$insertData['add_time']     = TIMESTAMP;
			$insertData['tel']          = $data['mobile'];
			if($dzp_user->insert($insertData)){
				$dzp->cy1($hd_id);
				$res['code'] = 3000;
				$res['msg'] = 'join_ok';
				exit(json_encode($res));
			}
		}else{
			$res['code'] = 3001;
			$res['msg'] = 'joined';
			exit(json_encode($res));
		}
	}
}else if($_GET['act'] == 'adduij'){
	if($_G['groupid']==1){
		$tel = isset($_GET['tel'])? daddslashes($_GET['tel']):'';
		$uid = isset($_GET['uid'])? intval($_GET['uid']):0;
		if($tel){
			$userInfo = $dzp_user->fetch_by_hd_id_tel_ad($hd_id,$tel);
		}else if($uid){
			$userInfo = $dzp_user->fetch_by_hd_id_uid_ad($hd_id,$uid);
		}
		if($userInfo){
			if($userInfo['duij']==0){
				$dzp_user->duij($hd_id,$userInfo['uid']);
				$res['code'] = 5001;
				$res['msg'] = 'success';
				exit(json_encode($res));
			}else{
				$res['code'] = 5002;
				$res['msg'] = 'yduij';
				exit(json_encode($res));
			}
		}else{
			$res['code'] = 5003;
			$res['msg'] = 'notel';
			exit(json_encode($res));
		}
	}else{
		$res['code'] = 5004;
		$res['msg'] = 'noadmin';
		exit(json_encode($res));
	}
}else if($_GET['act'] == 'duij'){
	$duijm = isset($_GET['duijm'])? daddslashes($_GET['duijm']):'';
	$userInfo = $dzp_user->fetch_by_hd_id_uid($hd_id,$_G['uid']);
	if($userInfo){
		if($duijm && $hdInfo['duijm']==$duijm){
			$dzp_user->duij($hd_id,$userInfo['uid']);
			$res['code'] = 6001;
			$res['msg'] = 'success';
			exit(json_encode($res));
		}else{
			$res['code'] = 6002;
			$res['msg'] = 'duijfail';
			exit(json_encode($res));
		}
	}else{
		$res['code'] = 6003;
		$res['msg'] = 'nozjinfo';
		exit(json_encode($res));
	}
}else if($_GET['act'] == 'useredit'){
	$tel = isset($_GET['tel'])? daddslashes($_GET['tel']):0;
	$userInfo = $dzp_user->fetch_by_hd_id_uid($hd_id,$_G['uid']);
	if($userInfo && $tel){
		$updateDatatel = array();
		$updateDatatel['tel']              = $tel;
		$dzp_user->update($userInfo['id'],$updateDatatel);
		$res['code'] = 7001;
		$res['msg'] = 'success';
		exit(json_encode($res));
	}else{
		$res['code'] = 7002;
		$res['msg'] = 'fail';
		exit(json_encode($res));
	}
}else if($_GET['act'] == 'dhcredit'){
	$dhnum = isset($_GET['dhnum'])? intval($_GET['dhnum']):0;
	if($dhnum){
		$mycredit = $dzp->jif();
		$needcredit = $dhnum*intval($hdInfo['jif']);
		if($mycredit['val']>=$needcredit){
			$dzp->setuserprize($hd_id,$_G['uid'],$dhnum);
			updatemembercount($_G['uid'], array('extcredits'.$aphly_dzp['jf_type'] => -$needcredit), true, '', 0, '', lang('plugin/aphly_dzp','dzp'), lang('plugin/aphly_dzp','dhnum').$dhnum.lang('plugin/aphly_dzp','dhnum_desc'));
			$res['code'] = 8000;
			$res['msg'] = 'dh_ok';
			exit(json_encode($res));
		}else{
			$res['code'] = 8001;
			$res['msg'] = 'error_1';
			exit(json_encode($res));
		}
	}else{
		$res['code'] = 8002;
		$res['msg'] = 'error_2';
		exit(json_encode($res));
	}
}else{
	$res['code'] = 4000;
	$res['msg'] = 'error_all';
	exit(json_encode($res));	
}