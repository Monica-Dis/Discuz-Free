function reset(){
	var ys = jduv%360;
	$("#cj-bg").css({
		'transition':'',
		'-webkit-transition':'',
		'transform':'rotate('+ys+'deg)',
		'-ms-transform':'rotate('+ys+'deg)',
		'-moz-transform':'rotate('+ys+'deg)',
		'-webkit-transform':'rotate('+ys+'deg)',
		'-o-transform':'rotate('+ys+'deg)',
	});
}

function openzjl(jp){
	if(jp){
		$('#zjl').show();
		$('#promptbox').show();
		$('.zjlmain').hide();
		$('#zjjp'+jp).show();
	}else{
		$('#zjl').show();
		$('#gxyn').show();
	}
	flag=true;
}



function closezjl(){
	reset();
	$('#zjl').hide();
	$('#gxyn').hide();
	$('#promptbox').hide();
}

function arand(m,n){
	return Math.floor(Math.random()*(m - n) + n);
}
function getjdu(jx){
	jx = parseInt(jx);
	var jdu=0;
	switch(jx){
		 case 5:jdu = arand(250,290);break;
		 case 4:jdu = arand(10,50);break;
		 case 0:jdu = arand(130,170);break;
		 case 2:jdu = arand(310,350);break;
		 case 1:jdu = arand(70,110);break;
		 case 3:jdu = arand(190,230);break;
		 default:jdu = arand(130,170);
	}
	jdu= jdu+360*arand(10,20);
	return jdu;
}
	
function setDegree(deg){
	$("#cj-bg").css({
		'transition':'transform 3s Ease',
		'-webkit-transition':'transform 3s Ease',
		'transform':'rotate('+deg+'deg)',
		'-ms-transform':'rotate('+deg+'deg)',
		'-moz-transform':'rotate('+deg+'deg)',
		'-webkit-transform':'rotate('+deg+'deg)',
		'-o-transform':'rotate('+deg+'deg)',
	});
	return true;
}

function showmsg(){
	var msg = arguments[0]?arguments[0]:false;
	var btn = arguments[1]?arguments[1]:false;
	var tz = arguments[2]?arguments[2]:false;
	var url = arguments[3]?arguments[3]:false;
	$('#message').show();
	$('#message_txt').html(msg);
	if(btn){
		$('#message_ok').html(btn);
	}else{
		$('#axs').hide();
	}
	if(tz){
		if(url){
			$('#message_ok').attr('onclick',"$('#message').hide();location.href='"+url+"';");
		}else{
			$('#message_ok').attr('onclick',"$('#message').hide();location.reload();");
		}
	}
	$('#message_ok').show();
}

function aajax_next(urlv){
	if(isclick){
        isclick = false;
		if(page>=pages){
			$('.anext').addClass('none');
			return;
		}
		$(".anext").disabled = true;
		$(".anext").html('<i class="aphly_hd icon-jiazai jjloading"></i>');
		page++;
		$.ajax({
			url:urlv,
			async:true,
			data:{'page':page},
			dataType:'text',
			success: function(res){
				var Obj = $("<code></code>").append($(res));
				var str = $(".hdzjmd", Obj);
				var addhtml ='';
					$(str).find('.findli').each(function() {
					addhtml += $(this).prop("outerHTML");
				});
				$(".hdzjmd").append(addhtml);
				$(".anext").disabled = false;
				$(".anext").html('<i class="aphly_hd icon-shuangxiajiantou"></i>');
				if(page>=pages){
					$('.anext').addClass('none');
				}
				isclick = true;
			}
		});
	}
}