<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$aphlysysoffset = getglobal('setting/timeoffset');
$aphlyScriptLang = $scriptlang['aphly_dzp'];
$aphlydzpListUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier=aphly_dzp&pmod=admincp';
echo '<link href="source/plugin/aphly_dzp/imgs/admincpstyle.css" rel="stylesheet" type="text/css">';
$dzp = C::t('#aphly_dzp#aphly_dzp');
if(submitcheck('submit')){
	$title          = isset($_GET['title'])? addslashes($_GET['title']):'';
	$mode          = isset($_GET['mode'])? intval($_GET['mode']):1;
	$start_time     = isset($_GET['start_time'])? addslashes($_GET['start_time']):'';
	$start_time     = strtotime($start_time);
	$end_time       = isset($_GET['end_time'])? addslashes($_GET['end_time']):'';
	$end_time       = strtotime($end_time);
	$content        = isset($_GET['content'])? addslashes($_GET['content']):'';
	$cyfs           = isset($_GET['cyfs'])? addslashes($_GET['cyfs']):'';
	$mr_cj_num		= isset($_GET['mr_cj_num'])? intval($_GET['mr_cj_num']):'';
	$mr_share_num   = isset($_GET['mr_share_num'])? intval($_GET['mr_share_num']):'';
	$if_gz          = isset($_GET['if_gz'])? intval($_GET['if_gz']):1;
	$mtzj           = isset($_GET['mtzj'])? intval($_GET['mtzj']):2;
	$if_share       = isset($_GET['if_share'])? intval($_GET['if_share']):2;
	$duijm       = isset($_GET['duijm'])? intval($_GET['duijm']):'';
	$gz_url         = isset($_GET['gz_url'])? addslashes($_GET['gz_url']):'';
	$share_desc         = isset($_GET['share_desc'])? addslashes($_GET['share_desc']):'';
	$wxgzh_disc          = isset($_GET['wxgzh_disc'])? addslashes($_GET['wxgzh_disc']):'';
	$cy_num          = isset($_GET['cy_num'])? intval($_GET['cy_num']):'';
	$zj_num          = isset($_GET['zj_num'])? intval($_GET['zj_num']):'';
	$show_zjmd          = isset($_GET['show_zjmd'])? intval($_GET['show_zjmd']):'';
	$show_cy          = isset($_GET['show_cy'])? intval($_GET['show_cy']):'';
	$views          = isset($_GET['views'])? intval($_GET['views']):'';
	$show_prize_num   = isset($_GET['show_prize_num'])? intval($_GET['show_prize_num']):0;
	$join          = isset($_GET['join'])? intval($_GET['join']):0;
	$jif          = isset($_GET['jif'])? intval($_GET['jif']):0;

	if($_FILES['wxgzh_pic']['tmp_name']) {
		$wxgzh_pic = $dzp->picupload('wxgzh_pic');
	}else{
		$wxgzh_pic = addslashes($_GET['wxgzh_pic']);
	}

	if($_FILES['share_pic']['tmp_name']) {
		$share_pic = $dzp->picupload('share_pic');
	}else{
		$share_pic = addslashes($_GET['share_pic']);
	}

	if($_FILES['dingbu_pic']['tmp_name']) {
		$dingbu_pic = $dzp->picupload('dingbu_pic');
	}else{
		$dingbu_pic = addslashes($_GET['dingbu_pic']);
	}

	$insertData = array();
	$insertData['dingbu_pic']   = $dingbu_pic;
	$insertData['title']        = $title;
	$insertData['mode']         = $mode;
	$insertData['start_time']   = $start_time;
	$insertData['end_time']     = $end_time;
	$insertData['content']      = $content;
	$insertData['if_share']		= $if_share;
	$insertData['share_pic']	= $share_pic;
	$insertData['mtzj']			= $mtzj;
	$insertData['cyfs']         = $cyfs;
	$insertData['mr_cj_num']    = $mr_cj_num;
	$insertData['mr_share_num'] = $mr_share_num;
	$insertData['if_gz']		= $if_gz;
	$insertData['duijm']		= $duijm;
	$insertData['gz_url']		= $gz_url;
	$insertData['share_desc']		= $share_desc;
	$insertData['add_time']     = TIMESTAMP;
	$insertData['wxgzh_disc']   = $wxgzh_disc;
	$insertData['wxgzh_pic']    = $wxgzh_pic;

	$insertData['cy_num']    = $cy_num;
	$insertData['zj_num']    = $zj_num;
	$insertData['show_zjmd']    = $show_zjmd;
	$insertData['show_cy']    = $show_cy;
	$insertData['views']    = $views;
	$insertData['show_prize_num']    = $show_prize_num;
	$insertData['join']    = $join;
	$insertData['jif']    = $jif;

	$dzp->insert($insertData);
	cpmsg($aphlyScriptLang['act_success'], $aphlydzpListUrl, 'succeed');
}else{
	echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
	showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=aphly_dzp&pmod=adminadd','enctype');
	showtableheader();
	echo '<tr><th colspan="15" class="partition">' . $aphlyScriptLang['dzp_add'] . '</th></tr>';
	
	echo '<tr class="header"><th>'.$aphlyScriptLang['join'].':</th><td><input name="join" type="radio" value="1" />'.$aphlyScriptLang['dzp_if_gz_1'].'<input name="join" type="radio" value="0" checked />'.$aphlyScriptLang['dzp_if_gz_2'].'</td><td>'.$aphlyScriptLang['join_desc'].'</td></tr>';

	echo '<tr class="header"><th width="10%">'.$aphlyScriptLang['dingbu_pic'].'</th><td width="25%"><input class="text" name="dingbu_pic" value="" size="35" type="file"></td><td>'.$aphlyScriptLang['dingbu_pic_msg'].'</td></tr>';

	echo '<tr class="header"><th class="bj" width="10%">'.$aphlyScriptLang['dzp_title'].':</th><td width="20%"><input name="title" type="text" value="" size="40" /></td><td></td></tr>';

	//echo '<tr class="header"><th>'.$aphlyScriptLang['admin_mode'].':</th><td><input name="mode" type="radio" value="1" checked />'.$aphlyScriptLang['admin_mode_1'].'<input name="mode" type="radio" value="2" />'.$aphlyScriptLang['admin_mode_2'].'<input name="mode" type="radio" value="3" />'.$aphlyScriptLang['admin_mode_3'].'</td><td>'.$aphlyScriptLang['admin_mode_msg'].'</td></tr>';
	
	echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_time'].':</th><td><input name="start_time" type="text" value="" size="25" onclick="showcalendar(event, this, 1)" /> - <input name="end_time" type="text" value="" size="25" onclick="showcalendar(event, this, 1)" /></td><td>'.$aphlyScriptLang['dzp_time'].'</td></tr>';   
	
	echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_content'].':</th><td><textarea rows="6" name="content" style="margin:2px;resize:both;width:400px" class="tarea"></textarea></td><td>'.$aphlyScriptLang['dzp_content_msg'].'</td></tr>';

	//echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_cyfs'].':</th><td><textarea rows="6" name="cyfs" style="margin:2px;resize:both;width:400px" class="tarea"></textarea></td><td>'.$aphlyScriptLang['dzp_cyfs_msg'].'</td></tr>';

	echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_mtzj'].':</th><td><input name="mtzj" type="radio" value="1" />'.$aphlyScriptLang['dzp_if_gz_1'].'<input name="mtzj" type="radio" value="2" checked />'.$aphlyScriptLang['dzp_if_gz_2'].'</td><td>'.$aphlyScriptLang['dzp_mtzj_msg'].'</td></tr>';

	echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_mr_cj_num'].':</th><td><input name="mr_cj_num" type="text" value="" size="40" /></td><td>'.$aphlyScriptLang['dzp_mr_cj_num_msg'].'</td></tr>';

	echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_if_share'].':</th><td><input name="if_share" type="radio" value="1" checked />'.$aphlyScriptLang['dzp_if_gz_1'].'<input name="if_share" type="radio" value="2" />'.$aphlyScriptLang['dzp_if_gz_2'].'</td><td>'.$aphlyScriptLang['dzp_if_share_msg'].'</td></tr>';

	echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_mr_share_num'].':</th><td><input name="mr_share_num" type="text" value="" size="40" /></td><td>'.$aphlyScriptLang['dzp_mr_share_num_msg'].'</td></tr>';

	echo '<tr class="header"><th>'.$aphlyScriptLang['jif'].':</th><td><input name="jif" type="text" value="" size="40" /></td><td>'.$aphlyScriptLang['jif_desc'].'</td></tr>';

	echo '<tr class="header"><th>'.$aphlyScriptLang['zj_num'].':</th><td><input name="zj_num" type="text" value="" size="40" /></td><td>'.$aphlyScriptLang['zj_num_msg'].'</td></tr>';

	echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_duijm'].':</th><td><input name="duijm" type="text" value="" size="40" /></td><td>'.$aphlyScriptLang['dzp_duijm_msg'].'</th></tr>';
	

	echo '<tr class="header"><th width="10%">'.$aphlyScriptLang['share_pic'].'</th><td width="25%"><input class="text" name="share_pic" value="" size="35" type="file"></td><td>'.$aphlyScriptLang['share_pic_msg'].'</td></tr>';

	echo '<tr class="header"><th width="10%">'.$aphlyScriptLang['share_desc'].'</th><td width="25%"><input class="text" name="share_desc" value="" size="35" type="text"></td><td>'.$aphlyScriptLang['share_desc_msg'].'</td></tr>';

	
	//echo '<tr class="header"><th>'.$aphlyScriptLang['dzp_if_gz'].':</th><td><input name="if_gz" type="radio" value="1" />'.$aphlyScriptLang['dzp_if_gz_1'].'<input name="if_gz" type="radio" value="2" checked />'.$aphlyScriptLang['dzp_if_gz_2'].'</td><td>'.$aphlyScriptLang['dzp_if_gz_msg'].'</td></tr>';

	echo '<tr class="header"><th width="10%">'.$aphlyScriptLang['admin_hd_gzpic'].'</th><td width="25%"><input class="text" name="wxgzh_pic" value="" size="35" type="file"></td><td>'.$aphlyScriptLang['admin_hd_gzpic_msg'].'</td></tr>';

	echo '<tr class="header"><th>'.$aphlyScriptLang['admin_hd_gzms'].':</th><td><input name="wxgzh_disc" type="text" value="" size="40" /></td><td>'.$aphlyScriptLang['admin_hd_gzms_msg'].'</td></tr>';
	
	
	echo '<tr class="header"><th>'.$aphlyScriptLang['show_cy'].':</th><td><input name="show_cy" type="radio" value="1" checked />'.$aphlyScriptLang['show_cy1'].'<input name="show_cy" type="radio" value="0" size="40" />'.$aphlyScriptLang['show_cy0'].'</td><td>'.$aphlyScriptLang['show_cy_msg'].'</td></tr>';
	echo '<tr class="header"><th>'.$aphlyScriptLang['cy_num'].':</th><td><input name="cy_num" type="text" value="" size="40" /></td><td>'.$aphlyScriptLang['cy_num_msg'].'</td></tr>';
	
	echo '<tr class="header"><th>'.$aphlyScriptLang['show_zjmd'].':</th><td><input name="show_zjmd" type="radio" value="1" checked />'.$aphlyScriptLang['show_zjmd1'].'<input name="show_zjmd" type="radio" value="0" size="40" />'.$aphlyScriptLang['show_zjmd0'].'</td><td>'.$aphlyScriptLang['show_zjmd_msg'].'</td></tr>';

	echo '<tr class="header"><th>'.$aphlyScriptLang['show_prize_num'].':</th><td><input name="show_prize_num" type="radio" value="1" checked />'.$aphlyScriptLang['show_prize_num1'].'<input name="show_prize_num" type="radio" value="0" size="40" />'.$aphlyScriptLang['show_prize_num0'].'</td><td>'.$aphlyScriptLang['show_prize_num_msg'].'</td></tr>';

	echo '<tr class="header"><th>'.$aphlyScriptLang['views'].':</th><td><input name="views" type="text" value="" size="40" /></td><td>'.$aphlyScriptLang['views_msg'].'</td></tr>';

	

	echo '<tr class="header"><th></th><td><input type="submit" class="btn" name="submit" title="" value="'.$aphlyScriptLang['discuz_tj_bt'].'"></td><td></td></tr>';

	showtablefooter(); /*Dism��taobao��com*/
	showformfooter(); /*Dism_taobao_com*/
}
