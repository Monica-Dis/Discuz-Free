<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$aphlysysoffset = getglobal('setting/timeoffset');
$hd_id = isset($_GET['hd_id'])? intval($_GET['hd_id']):0;
$hd_ms = isset($_GET['ms'])? intval($_GET['ms']):0;
$dzpInfo = C::t('#aphly_dzp#aphly_dzp')->fetch_by_id($hd_id);

if($dzpInfo && $_G['uid'] && $_G['groupid'] == 1){
	if($hd_ms==1){
		$order_str = " ORDER BY id DESC ";
		$userListTmp = C::t('#aphly_dzp#aphly_dzp_user')->fetch_all_list(" AND hd_id = {$hd_id} ",$order_str,0,10000);
		$userList = array();
		$uids=array();
		foreach ($userListTmp as $key => $value) {
			$userList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i",$aphlysysoffset);
			$userList[$key]['uid'] = $value['uid'];
			$userList[$key]['cj_znum'] = $value['cj_znum'];
			if($value['duij']){
				$userList[$key]['duij'] = lang('plugin/aphly_dzp','mb_dj_ydj');
			}else{
				$userList[$key]['duij'] = lang('plugin/aphly_dzp','mb_dj_wdj');
			}
			$uids[]=$value['uid'];
		}
		
		$memberdatas = C::t('common_member')->fetch_all($uids);
		$userdatas = C::t('#aphly_dzp#aphly_dzp_user')->fetch_all_hd_id_uids($hd_id,$uids);

		ob_end_clean();
		$listData[] = array(lang('plugin/aphly_dzp','px'),'UID',lang('plugin/aphly_dzp','user_xm'),lang('plugin/aphly_dzp','user_tel'),lang('plugin/aphly_dzp','user_cj_znum'),lang('plugin/aphly_dzp','duij'),lang('plugin/aphly_dzp','user_add_time')); 
		$i = 1;
		foreach ($userList as $v){
			$lineData = array();
			$lineData[] = $i;
			$lineData[] = $v['uid'];
			$lineData[] = $memberdatas[$v['uid']]['username'];
			$lineData[] = !empty($userdatas[$v['uid']]['tel'])?$userdatas[$v['uid']]['tel']:lang('plugin/aphly_dzp','no_tel');
			$lineData[] = $v['cj_znum'];
			$lineData[] = $v['duij'];
			$lineData[] = $v['add_time'];
			$listData[] = $lineData;
			$i++;
		}
		header("Content-Type: application/vnd.ms-excel");
		header("Content-Disposition:filename=rymd.xls");
		foreach ($listData as $fields){
			foreach ($fields as $k=> $v){
				$str = @diconv("$v",CHARSET,"GB2312");
				echo $str ."\t";
			}
			echo "\n";
		}
		exit;
	}else if($hd_ms==2){
		$order_str = " ORDER BY id DESC ";
		$userListTmp = C::t('#aphly_dzp#aphly_dzp_user_zj')->fetch_all_list(" AND hd_id = {$hd_id} AND prize_id!=0",$order_str,0,10000);
		$userList = array();
		$uids=array();
		foreach ($userListTmp as $key => $value) {
			$userList[$key]['username'] = $value['username'];
			if($value['prize_id']==1){
				$userList[$key]['prize_id'] = lang('plugin/aphly_dzp','user_list_ydj');
			}else if($value['prize_id']==2){
				$userList[$key]['prize_id'] = lang('plugin/aphly_dzp','user_list_edj');
			}else if($value['prize_id']==3){
				$userList[$key]['prize_id'] = lang('plugin/aphly_dzp','user_list_sdj');
			}else if($value['prize_id']==4){
				$userList[$key]['prize_id'] = lang('plugin/aphly_dzp','user_list_sidj');
			}else if($value['prize_id']==5){
				$userList[$key]['prize_id'] = lang('plugin/aphly_dzp','user_list_wdj');
			}else{
				$userList[$key]['prize_id'] = lang('plugin/aphly_dzp','user_list_wzjjl');
			}
			$userList[$key]['add_time'] = dgmdate($value['add_time'],"Y-m-d H:i",$aphlysysoffset);
			$userList[$key]['uid'] = $value['uid'];
			$uids[]=$value['uid'];
		}
		$userdatas = C::t('#aphly_dzp#aphly_dzp_user')->fetch_all_hd_id_uids($hd_id,$uids);

		ob_end_clean();
		$listData[] = array(lang('plugin/aphly_dzp','px'),'UID',lang('plugin/aphly_dzp','user_xm'),lang('plugin/aphly_dzp','user_tel'),lang('plugin/aphly_dzp','user_list_zjjx'),lang('plugin/aphly_dzp','user_add_time_zj')); 
		$i = 1;
		foreach ($userList as $v){
			$lineData = array();
			$lineData[] = $i;
			$lineData[] = $v['uid'];
			$lineData[] = $v['username'];
			$lineData[] = !empty($userdatas[$v['uid']]['tel'])?$userdatas[$v['uid']]['tel']:lang('plugin/aphly_dzp','no_tel');
			$lineData[] = $v['prize_id'];
			$lineData[] = $v['add_time'];
			$listData[] = $lineData;
			$i++;
		}
		header("Content-Type: application/vnd.ms-excel");
		header("Content-Disposition:filename=rymdzj.xls");

		foreach ($listData as $fields){
			foreach ($fields as $k=> $v){
				$str = @diconv("$v",CHARSET,"GB2312");
				echo $str ."\t";
			}
			echo "\n";
		}
		exit;
	}
}else{
    exit('Access Denied');
}