<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_aphly_dzp_prize extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dism _ taobao _ com*/
		$this->_table = 'aphly_dzp_prize';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
    public function fetch_all_list($condition,$orders = '',$start = 0,$limit = 10) {
		return DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
	}
    
    public function fetch_all_count($condition) {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		if($return){
			return $return['num'];
		}
		return 0;
	}
	
	public function fetch_by_hd_id_if_jx($hd_id,$if_jx) {
		return DB::fetch_first("SELECT * FROM %t WHERE hd_id=%d AND if_jx=%s ", array($this->_table, $hd_id,$if_jx));
	}
	
	public function fetch_by_hd_id($hd_id) {
		return DB::fetch_all("SELECT * FROM %t WHERE hd_id=%d ", array($this->_table, $hd_id));
	}

    public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

	public function fetch_all_list_p($condition,$orders = '',$start = 0,$limit = 10) {
		global $_G;
		$data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i group by if_jx $orders  LIMIT $start,$limit",array($this->_table,$condition));
		$res =array();
		if($data){
			foreach($data as $v){
				$res[$v['if_jx']] = $v;
				if($v['prize_pic']){
					$res[$v['if_jx']]['prize_pic'] = $_G['setting']['attachurl'].$v['prize_pic'];
				}
			}
		}
		return $res;
	}

	public function fetch_all_list_glv($condition,$orders = '',$start = 0,$limit = 10) {
		$data = DB::fetch_all("SELECT * FROM %t WHERE 1 %i group by if_jx $orders  LIMIT $start,$limit",array($this->_table,$condition));
		$randzj =array();
		if($data){
			foreach($data as $value){
				if(($value['prize_znum']-$value['prize_num'])<=0){
					$randzj[$value['if_jx']]=0;
				}else{
					$randzj[$value['if_jx']]=$value['prize_glv'];
				}
			}
		}
		return $randzj;
	}

	public function get_rand($proArr) { 
		if(!empty($proArr)){
			$result = 0; 
			$proArr = $this->resetgl($proArr);
			if(!$proArr){return $result; }
			$proSum = array_sum($proArr); 
			foreach ($proArr as $key => $proCur) { 
				$randNum = mt_rand(1, $proSum); 
				if ($randNum <= $proCur) { 
					$result = $key; 
					break; 
				} else { 
					$proSum -= $proCur;                     
				} 
			} 
			unset ($proArr); 
			return $result; 
		}
		return 0; 
	}
	
	public function get_rand_f($hd_id) { 
		$randzj = $this->fetch_all_list_glv(' AND hd_id ='.$hd_id);
		$jp = $this->get_rand($randzj);
		if($jp){
			$prizeInfo = $this->fetch_by_hd_id_if_jx($hd_id,$jp);
			if($prizeInfo){
				if(($prizeInfo['prize_znum']-$prizeInfo['prize_num'])>0){
					return $jp; 
				}
			}
		}
		return 0; 
	}


	public function resetgl($proArr,$maxgl=1000000) { 
		if(!empty($proArr)){
			$proSum = array_sum($proArr);
			if(!$proSum || $proSum>100 || $proSum<0){
				return 0; 
			}
			$result = array(); 
			foreach($proArr as $k => $v){
				$result[$k]=intval($v*$maxgl/100);
			}
			$result[0]= intval($maxgl - array_sum($result));
			$result[0]= $result[0]>0?$result[0]:0;
			return $result; 
		}
		return 0; 
	}

	

}
