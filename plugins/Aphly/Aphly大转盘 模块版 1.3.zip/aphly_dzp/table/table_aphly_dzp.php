<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

//login_method 0 default 1 wechat
class table_aphly_dzp extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dism _ taobao _ com*/
		$this->_table = 'aphly_dzp';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
	
    public function fetch_all_list($condition,$orders = '',$start = 0,$limit = 10) {
		return DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
	}
    
    public function fetch_all_count($condition) {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		if($return){
			return $return['num'];
		}
		return 0;
	}
	
    public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

	public function status_by_id_1($id) {
		return DB::query("UPDATE %t SET status=1 WHERE id=%d", array($this->_table, $id));
	}

	public function status_by_id_0($id) {
		return DB::query("UPDATE %t SET status=0 WHERE id=%d", array($this->_table, $id));
	}

	public function checkstatus($id) {
		if(is_array($id)){
			$data = $id;
		}else{
			$data = $this->fetch_by_id($id);
		}
		return $data['status'];
	}

	function is_today($time){
	  if(date('Y-m-d') == date('Y-m-d',$time)){
			return true;
	  }else{
			return false;
	  }
	}

	public function cy1($id) {
		return DB::query("UPDATE %t SET cy_num=cy_num+1 WHERE id=%d", array($this->_table, $id));
	}

	public function views($id) {
		return DB::query("UPDATE %t SET views=views+1 WHERE id=%d", array($this->_table, $id));
	}

	public function picupload($picn,$dir='aphly_dzp'){
		$basedir = !getglobal('setting/attachdir') ? (DISCUZ_ROOT.'./data/attachment') : getglobal('setting/attachdir');
		$typedir = $basedir.'/'.$dir;
		$subdir1 = $typedir.'/'.date('Ym');
		$subdir2  = $subdir1.'/'.date('d');
		$res = $subdir2 ? is_dir($subdir2) : ($subdir1 ? is_dir($subdir1) : is_dir($typedir));
		if(!$res) {
			$res = $typedir && discuz_upload::make_dir($typedir);
			$res && $subdir1 && ($res = discuz_upload::make_dir($subdir1));
			$res && $subdir1 && $subdir2 && ($res = discuz_upload::make_dir($subdir2));
		}
		$filedir = $dir.'/'.date('Ym').'/'.date('d').'/'.date('His').strtolower(random(16));
		$upload = new discuz_upload();
		$upload->init($_FILES["$picn"], 'portal');
		if($upload->error()) {
			$pic = '';
		}else{
			$upload->attach['target'] = getglobal('setting/attachdir').$filedir.'.'.$upload->attach['extension'];	
			$upload->save();
			if($upload->error()) {
				$pic = '';
			}else{
				$pic = $filedir.'.'.$upload->attach['extension'];
			}
		}
		return $pic;
	}

	function jif(){
		global $_G;
		$aphly_dzp = $_G['cache']['plugin']['aphly_dzp'];
		$aphly_dzp['jf_type']=intval($aphly_dzp['jf_type']);
		if($aphly_dzp['jf_type']){
			$creditname = $_G['setting']['extcredits'][$aphly_dzp['jf_type']]['title'];
			$nowcredit = getuserprofile('extcredits'.$aphly_dzp['jf_type']);
			return array('name'=>$creditname,'val'=>$nowcredit);
		}else{
			return array();
		}
	}

	public function setuserprize($hd_id,$uid,$num=0) {
		$userdata = getuserbyuid($uid);
		$hddata = $this->fetch_by_id($hd_id);
		if($userdata && $hddata){
			$dzp_user=C::t('#aphly_dzp#aphly_dzp_user');
			$userInfo = $dzp_user->fetch_by_hd_uid($hd_id,$uid);
			$num = $num?$num:1;
			if($userInfo){
				$updateData = array();
				$updateData['set_cj_num']    = $userInfo['set_cj_num']+$num;
				return $dzp_user->update($userInfo['id'],$updateData);
			}else{
				$insertData = array();
				$insertData['uid']			= $uid;
				$insertData['hd_id']		= $hd_id;
				$insertData['if_time']      = TIMESTAMP;
				$insertData['add_time']     = TIMESTAMP;
				$insertData['set_cj_num']   = $num;
				return $dzp_user->insert($insertData);
			}
		}
	}
	
	


}
