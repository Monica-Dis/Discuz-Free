<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_aphly_dzp_user extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dism _ taobao _ com*/
		$this->_table = 'aphly_dzp_user';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
    
    public function fetch_by_hd_id_tel($hd_id,$tel) {
		return DB::fetch_first("SELECT * FROM %t WHERE hd_id=%d AND tel=%s ", array($this->_table, $hd_id,$tel));
	}
	
	public function fetch_by_hd_id_uid($hd_id,$uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE hd_id=%d AND uid=%s ", array($this->_table, $hd_id,$uid));
	}

	public function fetch_by_hd_id_wgateid($hd_id,$wgateid) {
		return DB::fetch_first("SELECT * FROM %t WHERE hd_id=%d and wgateid=%s", array($this->_table,$hd_id,$wgateid));
	}

    public function fetch_all_list($condition,$orders = '',$start = 0,$limit = 10) {
		return DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
	}
    
    public function fetch_all_count($condition) {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		if($return){
			return $return['num'];
		}
		return 0;
	}
	
    public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

	public function fetch_by_hd_uid($hd_id,$uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE hd_id=%d AND uid=%d ", array($this->_table, $hd_id,$uid));
	}
	
	public function getchance($hd_id,$uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE hd_id=%d AND uid=%d ", array($this->_table, $hd_id,$uid));
	}

	public function fetch_all_hd_ids($hd_ids,$uid){
		return DB::fetch_all("SELECT * FROM %t WHERE ".DB::field('hd_id', $hd_ids)." and uid=%d",array($this->_table,$uid),'hd_id');
	}

	public function duij($hd_id,$uid){
		return DB::query("UPDATE %t SET duij=1 WHERE hd_id=%d and uid=%d", array($this->_table,$hd_id,$uid));
	}

	public function fetch_all_hd_id_uids($hd_id,$uids){
		return DB::fetch_all("SELECT * FROM %t WHERE ".DB::field('uid', $uids)." and hd_id=%d",array($this->_table,$hd_id),'uid');
	}
	
	public function fetch_by_hd_id_tel_ad($hd_id,$tel){
		return DB::fetch_first("SELECT * FROM %t WHERE tel=%s and hd_id=%d",array($this->_table,$tel,$hd_id));
	}

	public function fetch_by_hd_id_uid_ad($hd_id,$uid){
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d and hd_id=%d",array($this->_table,$uid,$hd_id));
	}

	public function chance($userInfo){
		return $userInfo['chance_num']+$userInfo['set_cj_num']-$userInfo['cj_num'];
	}

}
