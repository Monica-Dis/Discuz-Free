<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
} 

class table_aphly_dzp_user_zj extends discuz_table{
	public function __construct() {
        parent::__construct(); /*dism _ taobao _ com*/
		$this->_table = 'aphly_dzp_user_zj';
		$this->_pk    = 'id';
	}

    public function fetch_by_id($id,$field='*') {
		return DB::fetch_first("SELECT $field FROM %t WHERE id=%d", array($this->_table, $id));
	}
    
    public function fetch_by_hd_id_tel($hd_id,$tel) {
		return DB::fetch_first("SELECT * FROM %t WHERE hd_id=%d AND tel=%s ", array($this->_table, $hd_id,$tel));
	}
	
	public function fetch_by_hd_id_uid($hd_id,$uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE hd_id=%d AND uid=%s ", array($this->_table, $hd_id,$uid));
	}

    public function fetch_all_list($condition,$orders = '',$start = 0,$limit = 10) {
		return DB::fetch_all("SELECT * FROM %t WHERE 1 %i $orders LIMIT $start,$limit",array($this->_table,$condition));
	}

	public function findzjCount($hd_id,$uid) {
        return DB::result_first("SELECT count(*) FROM %t WHERE hd_id=%d AND uid=%s ", array($this->_table,$hd_id,$uid));
	}
    
    public function fetch_all_count($condition) {
        $return = DB::fetch_first("SELECT count(*) AS num FROM ".DB::table($this->_table)." WHERE 1 $condition ");
		if($return){
			return $return['num'];
		}
		return 0;
	}
	
    public function delete_by_id($id) {
		return DB::query("DELETE FROM %t WHERE id=%d", array($this->_table, $id));
	}

	public function fetch_by_hd_id_tel_duij($hd_id,$tel,$duijm) {
		return DB::fetch_first("SELECT * FROM %t WHERE hd_id=%d AND tel=%s and duijm=%d", array($this->_table, $hd_id,$tel,$duijm));
	}
	
	public function fetch_by_hd_id_tel_uid($hd_id,$uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE hd_id=%d AND uid=%d ", array($this->_table, $hd_id,$uid));
	}

	public function fetch_by_hd_id_tel_ad($hd_id,$tel) {
		return DB::fetch_first("SELECT * FROM %t WHERE hd_id=%d AND tel=%s", array($this->_table, $hd_id,$tel));
	}

	public function duij_by_hd_id_tel($hd_id,$tel,$duijm) {
		return DB::query("UPDATE %t SET duij=1 WHERE hd_id=%d AND tel=%s and duijm=%d ", array($this->_table,$hd_id,$tel,$duijm));
	}

	public function duij_by_hd_id_uid($hd_id,$uid) {
		return DB::query("UPDATE %t SET duij=1 WHERE hd_id=%d AND uid=%d ", array($this->_table,$hd_id,$uid));
	}

	public function duij_by_hd_id_uid_f($hd_id,$uid) {
		return C::t('#aphly_dzp#aphly_dzp_user')->duij($hd_id,$uid);
	}

	public function duij_by_hd_id_tel_ad($hd_id,$tel) {
		return DB::query("UPDATE %t SET duij=1 WHERE hd_id=%d AND tel=%s", array($this->_table,$hd_id,$tel));
	}

}