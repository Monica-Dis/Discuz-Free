<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_aphly_dzp` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `dingbu_pic` varchar(255) DEFAULT NULL,
  `start_time` int(10) DEFAULT 0,
  `end_time` int(10) DEFAULT 0,
  `content` text DEFAULT NULL,
  `cyfs` text DEFAULT NULL,
  `mtzj` tinyint(1) DEFAULT 1,
  `if_share` tinyint(1) DEFAULT 1,
  `share_pic` varchar(255) DEFAULT NULL,
  `mr_cj_num` smallint(5) DEFAULT 1,
  `mr_share_num` smallint(5) DEFAULT 1,
  `if_gz` tinyint(4) DEFAULT 1,
  `duijm` varchar(32) DEFAULT '100',
  `share_desc` varchar(255) DEFAULT NULL,
  `gz_url` varchar(255) DEFAULT NULL,
  `add_time` int(10) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `mode` tinyint(1) DEFAULT 0,
  `wxgzh_pic` varchar(255) DEFAULT NULL,
  `wxgzh_disc` varchar(255) DEFAULT NULL,
  `cy_num` int(10) unsigned DEFAULT 0,
  `zj_num` int(10) unsigned DEFAULT 0,
  `show_zjmd` tinyint(1) unsigned DEFAULT 0,
  `show_cy` tinyint(1) unsigned DEFAULT 0,
  `show_prize_num` tinyint(1) unsigned DEFAULT 0,
  `views` int(10) unsigned DEFAULT 0,
  `join` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `jif` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_aphly_dzp_prize` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `hd_id` int(10) DEFAULT 0,
  `if_jx` tinyint(1) DEFAULT 1,
  `prize_title` varchar(255) DEFAULT NULL,
  `prize_num` int(10) DEFAULT 0,
  `prize_znum` int(10) DEFAULT 0,
  `prize_pic` varchar(255) DEFAULT NULL,
  `prize_glv` float(7,4) DEFAULT NULL,
  `px` int(10) DEFAULT 0,
  `type` tinyint(1) unsigned DEFAULT 0,
  `jf_type` tinyint(1) unsigned DEFAULT 0,
  `jf` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_aphly_dzp_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT 0,
  `hd_id` int(10) DEFAULT NULL,
  `tel` varchar(32) DEFAULT NULL,
  `cj_num` int(10) DEFAULT 0,
  `chance_num` int(10) unsigned NOT NULL DEFAULT 0,
  `if_time` int(10) DEFAULT 0,
  `if_s_time` int(10) DEFAULT 0,
  `share_num` int(10) DEFAULT 0,
  `share_znum` int(10) DEFAULT 0,
  `cj_znum` int(10) NOT NULL DEFAULT 0,
  `add_time` int(10) DEFAULT 0,
  `set_cj_num` int(10) DEFAULT 0,
  `duij` tinyint(1) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `cj_num` (`cj_num`),
  KEY `share_num` (`share_num`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_aphly_dzp_user_zj` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned DEFAULT NULL,
  `hd_id` int(10) DEFAULT NULL,
  `username` varchar(32) DEFAULT NULL,
  `prize_id` tinyint(3) DEFAULT 0,
  `type` tinyint(3) DEFAULT 1,
  `duij` tinyint(3) DEFAULT 0,
  `duijm` int(10) unsigned DEFAULT 0,
  `add_time` int(10) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;


EOF;

runquery($sql);

$finish = TRUE; /*dism��taobao��com*/
