<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT.'./source/plugin/aphly_dzp/class.php';

$dzp=C::t('#aphly_dzp#aphly_dzp');
$dzp_prize=C::t('#aphly_dzp#aphly_dzp_prize');
$dzp_user=C::t('#aphly_dzp#aphly_dzp_user');
$dzp_user_zj=C::t('#aphly_dzp#aphly_dzp_user_zj');
$aphly_dzp = $_G['cache']['plugin']['aphly_dzp'];
$mycredit = $dzp->jif();
if(!$_G['uid']){
	showmessage(lang('plugin/aphly_dzp','login'),$_G['siteurl'].'member.php?mod=logging&action=login');
}
$hd_id = isset($_GET['hd_id'])? intval($_GET['hd_id']):0;
if($hd_id){
	$hdInfo = $dzp->fetch_by_id($hd_id);
	if(!$hdInfo){
		showmessage(lang('plugin/aphly_dzp','no_hd'));
	}
	$hdInfo['jif'] = intval($hdInfo['jif']);
	$userInfo = $dzp_user->fetch_by_hd_uid($hd_id,$_G['uid']);
	$chance =  $userInfo['chance_num']+$userInfo['set_cj_num']-$userInfo['cj_num'];
	$chance = $chance>0?$chance:0;
	$dzp->views($hd_id);
	$wheresql= " AND hd_id = {$hd_id} and uid=".$_G['uid'];
	$currurl=$_G['siteurl']."plugin.php?id=aphly_dzp:me&hd_id={$hd_id}";
}else{
	//$wheresql=" AND uid=".$_G['uid'];
	//$currurl=$_G['siteurl']."plugin.php?id=aphly_dzp:me";
	showmessage(lang('plugin/aphly_dzp','no_hd'));
}

$pagesize = 10;
$page = isset($_GET['page'])?intval($_GET['page']):1;
$hd_ids=$newdata=array();
if($page){
	$start = ($page-1)*$pagesize;
	$mdcount = $dzp_user_zj->fetch_all_count($wheresql);
	$pagecount = ceil($mdcount/$pagesize);
	if($mdcount){
		$order_str = " ORDER BY id DESC ";
		$zjmdList = $dzp_user_zj->fetch_all_list($wheresql,$order_str,$start,$pagesize);
		foreach($zjmdList as $k=>$v){
			$hd_ids[$v['hd_id']]=$v['hd_id'];
			$newdata[$v['hd_id']][]=$v;
		}
	}
}

$hdatas = $dzp->fetch_all($hd_ids);
$userdatas = $dzp_user->fetch_all_hd_ids($hd_ids,$_G['uid']);
if(in_array('aphly_wxfx', $_G["setting"]["plugins"]["available"])){
	if(!empty($hdInfo['share_pic'])){
		$hdInfo['share_pic'] = $_G['setting']['attachurl'].$hdInfo['share_pic'];
	}else{
		$hdInfo['share_pic']=$_G['siteurl'].'source/plugin/aphly_dzp/imgs/share_pic.png';
	}
	require_once DISCUZ_ROOT.'./source/plugin/aphly_wxfx/aphly_fxapi.php';
	$fxapi = new aphly_fxapi;
	$wxfx = $fxapi->aphly_share($hdInfo['title'],$hdInfo['share_desc'],$hdInfo['share_pic']);
}
include template("aphly_dzp:me"); 
