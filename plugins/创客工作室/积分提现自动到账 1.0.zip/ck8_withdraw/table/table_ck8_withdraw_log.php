<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_ck8_withdraw_log extends discuz_table{
    public function __construct() {
        $this->_table = 'ck8_withdraw_log';
        $this->_pk = 's_id';
        parent::__construct();
    }

    public function get_ck8_withdraw_log_count($where=array()){
        $sql = "SELECT count(*) as count FROM %t WHERE 1";
        $condition[] = $this->_table;
        if($where['s_apply_uid']){     
            $sql .=" AND s_apply_uid=%d ";
            $condition[] = $where['s_apply_uid'];
        }
        if($where['s_account_type']){     
            $sql .=" AND s_account_type=%d ";
            $condition[] = $where['s_account_type'];
        }
        if($where['s_transfer_state']){     
            $sql .=" AND s_transfer_state=%d ";
            $condition[] = $where['s_transfer_state'];
        }
        if($where['s_transfer_line']){     
            $sql .=" AND s_transfer_line=%d ";
            $condition[] = $where['s_transfer_line'];
        }
        if($where['s_apply_dateline']){     
            $sql .=" AND s_apply_dateline>%d ";
            $condition[] = $where['s_apply_dateline'];
        }
        if($where['s_apply_dateline2']){     
            $sql .=" AND s_apply_dateline<%d ";
            $condition[] = $where['s_apply_dateline2'];
        }
        $count = DB::fetch_first($sql,$condition);
        return $count['count'];
    }

	public function get_ck8_withdraw_log_list($start,$size,$where=array()){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
        if($where['s_apply_uid']){     
            $sql .=" AND s_apply_uid=%d ";
            $condition[] = $where['s_apply_uid'];
        }
        if($where['s_account_type']){     
            $sql .=" AND s_account_type=%d ";
            $condition[] = $where['s_account_type'];
        }
        if($where['s_transfer_state']){     
            $sql .=" AND s_transfer_state=%d ";
            $condition[] = $where['s_transfer_state'];
        }
        if($where['s_transfer_line']){     
            $sql .=" AND s_transfer_line=%d ";
            $condition[] = $where['s_transfer_line'];
        }
        if($where['s_apply_dateline']){     
            $sql .=" AND s_apply_dateline>%d ";
            $condition[] = $where['s_apply_dateline'];
        }
        if($where['s_apply_dateline2']){     
            $sql .=" AND s_apply_dateline<%d ";
            $condition[] = $where['s_apply_dateline2'];
        }
		$sql .= " ORDER BY s_apply_dateline DESC LIMIT %d,%d ";
		$condition[] = $start;
		$condition[] = $size;
		return DB::fetch_all($sql,$condition);
	}
	
	public function get_ck8_withdraw_log_first($where,$ORDER ='ORDER BY s_apply_dateline DESC'){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
        if($where['s_id']){     
            $sql .=" AND s_id=%d ";
            $condition[] = $where['s_id'];
        }
        if($where['s_apply_uid']){     
            $sql .=" AND s_apply_uid=%d ";
            $condition[] = $where['s_apply_uid'];
        }
        if($where['s_account_type']){     
            $sql .=" AND s_account_type=%d ";
            $condition[] = $where['s_account_type'];
        }
        if($where['s_transfer_state']){     
            $sql .=" AND s_transfer_state=%d ";
            $condition[] = $where['s_transfer_state'];
        }
        if($where['s_transfer_line']){     
            $sql .=" AND s_transfer_line=%d ";
            $condition[] = $where['s_transfer_line'];
        }
        if($where['s_apply_dateline']){     
            $sql .=" AND s_apply_dateline=%d ";
            $condition[] = $where['s_apply_dateline'];
        }
		$sql .= " $ORDER ";
		return DB::fetch_first($sql,$condition);
	}
	
    public function insert($data){
        return DB::insert($this->_table,$data,true);
    }
	
    public function update($data,$condition){
        return DB::update($this->_table,$data,$condition,true);
    }
	
    public function delete($condition){
        return DB::delete($this->_table, $condition);
    }
}
//From: Dism_taobao_com
?>