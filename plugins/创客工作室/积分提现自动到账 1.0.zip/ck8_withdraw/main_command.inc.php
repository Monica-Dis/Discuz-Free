<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once libfile('class/Withdraw','plugin/ck8_withdraw');
$config = Withdraw::config();
$msgarr = array();
if(!function_exists('curl_version')){
	exit('Please open curl extension');
}
if (!$_G['uid']){
    $msgarr['error'] = lang('plugin/ck8_withdraw', 'langs069');
	Withdraw::RetMsgJson($msgarr);
}

if($_GET['formhash'] != FORMHASH){
    $msgarr['error'] = lang('plugin/ck8_withdraw', 'langs070');
	Withdraw::RetMsgJson($msgarr);
}

if($_GET['action'] == 'apply_account'){

    $u_account_type = intval($_GET['u_account_type']);
	$u_name =  daddslashes($_GET['u_name']);
	$u_card =  daddslashes($_GET['u_card']);
	$u_bank = daddslashes($_GET['u_bank']);
	$u_bank_address =  daddslashes($_GET['u_bank_address']);

	if(empty($u_account_type) || empty($u_name)){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs071');
		Withdraw::RetMsgJson($msgarr);
	}
	if(empty($u_card)){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs072');
		Withdraw::RetMsgJson($msgarr);
	}
	if(empty($u_bank) && $u_account_type == 3){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs073');
		Withdraw::RetMsgJson($msgarr);
	}

	$data = array(
		'u_uid' => $_G['uid'],
		'u_account_type' => $u_account_type,
		'u_name' => $u_name,
		'u_card' => $u_card,
		'u_bank' => $u_bank,
		'u_bank_address' => $u_bank_address,
		'u_dateline'  => TIMESTAMP
	);
    $u_id = DB::result_first('select u_id from %t where u_uid=%d and u_card=%s', array('ck8_withdraw_account',$_G['uid'], $u_card));
	if($u_id){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs074');
		Withdraw::RetMsgJson($msgarr);
	}
	$isok = DB::insert('ck8_withdraw_account',$data,true);
	if($isok){
		$msgarr['succeed'] = 'ok';
		$msgarr['msg'] = lang('plugin/ck8_withdraw', 'langs075');
		Withdraw::RetMsgJson($msgarr);
	}else{
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs076');
		Withdraw::RetMsgJson($msgarr);
	}

}else if($_GET['action'] == 'edit_account'){

    $u_id = intval($_GET['u_id']);
    $u_account_type = intval($_GET['u_account_type']);
	$u_name = daddslashes($_GET['u_name']);
	$u_card = daddslashes($_GET['u_card']);
	$u_bank = daddslashes($_GET['u_bank']);
	$u_bank_address =  daddslashes($_GET['u_bank_address']);

	if(empty($u_id)){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs077');
		Withdraw::RetMsgJson($msgarr);
	}
	if(empty($u_account_type) || empty($u_name)){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs071');
		Withdraw::RetMsgJson($msgarr);
	}
	if(empty($u_card)){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs072');
		Withdraw::RetMsgJson($msgarr);
	}
	if(empty($u_bank) && $u_account_type == 3){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs073');
		Withdraw::RetMsgJson($msgarr);
	}
    $result = DB::fetch_first('SELECT wa.*,wl.* FROM %t wa, %t wl WHERE wa.u_id=%d AND wl.s_transfer_state=1 AND wa.u_id=wl.s_account_type', array('ck8_withdraw_account', 'ck8_withdraw_log', $u_id));
	if($result['s_apply_uid'] == $_G['uid']){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs078');
		Withdraw::RetMsgJson($msgarr);
	}

	$data = array();
	$data['u_account_type'] = $u_account_type;
	$data['u_bank'] = $u_bank;
	$data['u_bank_address'] = $u_bank_address;
	if (strpos($u_card,'***') === FALSE){
		$data['u_card'] = $u_card;
	}
	if (strpos($u_name,'***') === FALSE){
		$data['u_name'] = $u_name;
	}
	$isok = DB::update('ck8_withdraw_account',$data,array('u_id' => $u_id),true);
	if($isok){
		$msgarr['succeed'] = 'ok';
		$msgarr['msg'] = lang('plugin/ck8_withdraw', 'langs079');
		Withdraw::RetMsgJson($msgarr);
	}else{
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs080');
		Withdraw::RetMsgJson($msgarr);
	}

}else if($_GET['action'] == 'del_account'){//ɾ���˻�

    $u_id = intval($_GET['u_id']);
	if(empty($u_id)){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs077');
		Withdraw::RetMsgJson($msgarr);
	}
    $result = DB::fetch_first('SELECT wa.*,wl.* FROM %t wa, %t wl WHERE wa.u_id=%d AND wl.s_transfer_state=1 AND wa.u_id=wl.s_account_type', array('ck8_withdraw_account', 'ck8_withdraw_log', $u_id));
	if($result['s_apply_uid'] == $_G['uid']){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs081');
		Withdraw::RetMsgJson($msgarr);
	}
	$isok = DB::delete('ck8_withdraw_account', array('u_id' => $u_id));
	if($isok){
		$msgarr['succeed'] = 'ok';
		$msgarr['msg'] = lang('plugin/ck8_withdraw', 'langs082');
		Withdraw::RetMsgJson($msgarr);
	}else{
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs083');
		Withdraw::RetMsgJson($msgarr);
	}

}else if($_GET['action'] == 'apply_withdraw'){//��������

    $s_account_type = intval($_GET['s_account_type']);
    $s_apply_number = intval($_GET['s_apply_number']);
	if(empty($s_account_type)){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs077');
		Withdraw::RetMsgJson($msgarr);
	}
    $extcredits = getuserprofile('extcredits'.$config['credit_type']);
	//�ж��û���Ȩ��
	$credit_accoun_groupid = dunserialize($config['credit_accoun_groupid']);
	if(is_array($credit_accoun_groupid) && !in_array($_G['groupid'], $credit_accoun_groupid)){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs084');
		Withdraw::RetMsgJson($msgarr);
	}

    //�ж������
	if(empty($s_apply_number) || $s_apply_number > $config['credit_account_max']){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs085').$config['credit_account_max'];
		Withdraw::RetMsgJson($msgarr);
	}
    //�ж���С���
	if(empty($s_apply_number) || $s_apply_number < $config['credit_account_min']){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs086').$config['credit_account_min'];
		Withdraw::RetMsgJson($msgarr);
	}
	//�жϻ����Ƿ��㹻
	if($s_apply_number > $extcredits){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs087');
		Withdraw::RetMsgJson($msgarr);
	}

	//����ת�������
	$s_apply_number = round($s_apply_number * $config['credit_moey'],2); 
	
	//�۳�������
	if($config['credit_proportion']){
	    $credit_proportion = round($s_apply_number * $config['credit_proportion'],2);
		$s_apply_number = round($s_apply_number - $credit_proportion,2);//�õ�Ӧת�˽��
	}

	//�۳�����
	updatemembercount($_G['uid'], array('extcredits'.$config['credit_type'] => -intval($_GET['s_apply_number'])), true, '',1,1,lang('plugin/ck8_withdraw', 'langs088'),lang('plugin/ck8_withdraw', 'langs089'));
	$data = array(
		's_apply_uid' => $_G['uid'],
		's_account_type' => $s_account_type,
		's_apply_number' => intval($_GET['s_apply_number']),
		's_apply_moey' => $s_apply_number,
		's_service' => $credit_proportion,
		's_transfer_state' => 2,  //ת�˴���״̬  1.ת�˳ɹ�  2.����˴�����  3.ȡ������  4.����ʧ��
		's_transfer_line' => '',
		's_apply_dateline' => TIMESTAMP
	);
	$s_id = C::t('#ck8_withdraw#ck8_withdraw_log')->insert($data);

	$u_list = DB::fetch_first('SELECT u_name,u_card,u_account_type FROM %t WHERE u_id=%d',array('ck8_withdraw_account',$s_account_type));
	if($u_list['u_account_type'] == 1 && $config['auto_zfbaccount']){//֧����
		
		//������Ƿ���� ����֧����ת��
		if($s_id && in_array('ck8_pay',$_G['setting']['plugins']['available'])){
			include_once DISCUZ_ROOT.'./source/plugin/ck8_pay/function.php';
			include_once DISCUZ_ROOT.'./source/plugin/ck8_pay/lib/AlipayService.class.php';
			if(empty($_G['cache']['plugin'])){
				loadcache('plugin');
			}
			$pay_config = $_G['cache']['plugin']['ck8_pay'];
			
			$orderno = dgmdate(TIMESTAMP,'Ymd').random(8);
			$source = GetPluginList('ck8_withdraw');
			$remark = $remark2 = lang('plugin/ck8_withdraw', 'langs090');
			$account = $u_list['u_card'];
			$realName = $u_list['u_name'];
			if($_G['charset'] == 'gbk'){
				$remark =  iconv('gbk','utf-8',$remark);
			}
			if($_G['charset'] == 'gbk'){
				$realName =  iconv('gbk','utf-8',$realName);
			}			
			$aliPay = new AlipayService();
			$aliPay->setAppid(trim($pay_config['zfb_appid']));
			$aliPay->setRsaPrivateKey(trim($pay_config['zfb_rsaPrivateKey']));
			$aliPay->signType(trim($pay_config['zfb_rsatype']));
			$result = $aliPay->doPayTransfer($s_apply_number,$orderno,$account,$realName,$remark);
			$result = $result['alipay_fund_trans_toaccount_transfer_response'];
			if($result['code'] && $result['code']=='10000'){

                creation_Pay($orderno,$source['name'], $remark2, 7, $s_apply_number, '', '', '',$result['order_id']);
	            C::t('#ck8_withdraw#ck8_withdraw_log')->update(array('s_transfer_state' => 1,'s_transfer_line' => TIMESTAMP),array('s_id' => $s_id));
				$msgarr['succeed'] = 'ok';
				$msgarr['msg'] = lang('plugin/ck8_withdraw', 'langs091');
				Withdraw::RetMsgJson($msgarr);
			}else{
				$msg = Withdraw::diconv_gbk_to_utf8($result['msg']);
				$sub_code = Withdraw::diconv_gbk_to_utf8($result['sub_code']);
				$sub_msg = Withdraw::diconv_gbk_to_utf8($result['sub_msg']);
				$addLogStr = "doPayTransfer==>>>$sub_code=====>>>$msg=======>>>$sub_msg\r\n";
				$aliPay->logResult($addLogStr);
                $msgarr['succeed'] = 'ok';
				$msgarr['msg'] = lang('plugin/ck8_withdraw', 'langs092');
				Withdraw::RetMsgJson($msgarr);
			}
		}else{
			$msgarr['succeed'] = 'ok';
			$msgarr['msg'] = lang('plugin/ck8_withdraw', 'langs093');
			Withdraw::RetMsgJson($msgarr);
		}
	}else if($u_list['u_account_type'] == 2 && $config['auto_wxaccount']){//΢��

		if($s_id && in_array('ck8_pay',$_G['setting']['plugins']['available'])){
			include_once DISCUZ_ROOT.'./source/plugin/ck8_pay/function.php';
	        include_once DISCUZ_ROOT.'./source/plugin/ck8_pay/lib/WxpayService.class.php';

			if(empty($_G['cache']['plugin'])){
				loadcache('plugin');
			}
			$pay_config = $_G['cache']['plugin']['ck8_pay'];
			//��ȡopenid
			$openid = '';
			$table = DB::table('common_member_wechat');
			$counttable = DB::fetch_first('show tables like \''.$table.'\'');
			if(!empty($counttable)){
				$openid = DB::result_first('select openid from %t where uid=%d', array('common_member_wechat', $_G['uid']));
			}
			if(empty($openid) && $config['wxuser_tabe']){
			    $openid = DB::result_first('select openid from %t where uid=%d', array($config['wxuser_tabe'], $_G['uid']));
			}
			if(empty($openid)){
				$msgarr['succeed'] = 'ok';
				$msgarr['msg'] = lang('plugin/ck8_withdraw', 'langs094');
				Withdraw::RetMsgJson($msgarr);
			}

			$orderno = dgmdate(TIMESTAMP,'Ymd').random(8);
			$source = GetPluginList('ck8_withdraw');
			$remark = $remark2 = lang('plugin/ck8_withdraw', 'langs090');
			$trueName = $u_list['u_name'];
			if($_G['charset'] == 'gbk'){
				$remark =  iconv('gbk','utf-8',$remark);
			}
			if($_G['charset'] == 'gbk'){
				$trueName =  iconv('gbk','utf-8',$trueName);
			}
			$wxPay = new WxpayService(trim($pay_config['wxzf_mchid']),trim($pay_config['wxzf_appid']),trim($pay_config['wxzf_apiKey']),trim($pay_config['wxzf_appKey']));
			$result = $wxPay->createJsBizPackageTransfer($openid, $s_apply_number,$orderno,$trueName,$remark,$pay_config['apiclient_cert'],$pay_config['apiclient_key']);
			if($result !== false){

				$result = (array)$result;
                creation_Pay($orderno,$source['name'], $remark2, 7, $s_apply_number, '', '', '',$result['payment_no']);
	            C::t('#ck8_withdraw#ck8_withdraw_log')->update(array('s_transfer_state' => 1,'s_transfer_line' => TIMESTAMP),array('s_id' => $s_id));
				$msgarr['succeed'] = 'ok';
				$msgarr['msg'] = lang('plugin/ck8_withdraw', 'langs095');
				Withdraw::RetMsgJson($msgarr);
			}else{
				$msgarr['succeed'] = 'ok';
				$msgarr['msg'] = lang('plugin/ck8_withdraw', 'langs096');
				Withdraw::RetMsgJson($msgarr);
			}
		}else{
			$msgarr['succeed'] = 'ok';
			$msgarr['msg'] = lang('plugin/ck8_withdraw', 'langs093');
			Withdraw::RetMsgJson($msgarr);
		}
	}else {//�˹�ת��
		$msgarr['succeed'] = 'ok';
		$msgarr['msg'] = lang('plugin/ck8_withdraw', 'langs097');
		Withdraw::RetMsgJson($msgarr);
	}

}else if($_GET['action'] == 'apply_cancel'){//ȡ������

    $s_id = intval($_GET['s_id']);
	if(empty($s_id)){
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs077');
		Withdraw::RetMsgJson($msgarr);
	}
	$s_list = C::t('#ck8_withdraw#ck8_withdraw_log')->get_ck8_withdraw_log_first(array('s_id' => $s_id));
	if($s_list['s_transfer_state'] == 2){

		C::t('#ck8_withdraw#ck8_withdraw_log')->update(array('s_transfer_state' => 3),array('s_id' => $s_id));
		//�˻ػ���
		updatemembercount($_G['uid'], array('extcredits'.$config['credit_type'] => $s_list['s_apply_number']), true, '',1,1,lang('plugin/ck8_withdraw', 'langs098'),lang('plugin/ck8_withdraw', 'langs099'));
		$msgarr['succeed'] = 'ok';
		$msgarr['msg'] = lang('plugin/ck8_withdraw', 'langs0100');
		Withdraw::RetMsgJson($msgarr);
	}else{
		$msgarr['error'] = lang('plugin/ck8_withdraw', 'langs0101');//0101
		Withdraw::RetMsgJson($msgarr);
	}
}
//From: Dism_taobao_com
?>