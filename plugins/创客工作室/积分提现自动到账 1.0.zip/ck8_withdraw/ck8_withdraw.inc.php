<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('class/Withdraw','plugin/ck8_withdraw');
$config = Withdraw::config();

if (!$_G['uid']){
	$url = $siteurl.'member.php?mod=logging&action=login&referer='.urlencode($_G['siteurl'].'plugin.php?id=ck8_withdraw');
	dheader('location: '.$url);exit;
}

$act = daddslashes($_GET['act']);
$credit_name = $_G['setting']['extcredits'][$config['credit_type']]['title'];
$extcredits = getuserprofile('extcredits'.$config['credit_type']);
if(!$act && !checkmobile()){
	$act = 'apply';
}

if($act == 'apply_account' || $act == 'apply'){//�ҵ��˻�  //�������� 

	$u_list = DB::fetch_all('SELECT * FROM %t WHERE u_uid=%d', array('ck8_withdraw_account', $_G['uid']));
    $sel_list = array();
	foreach($u_list as $key => $val){
		if($val['u_account_type'] == 1){
			$icon = lang('plugin/ck8_withdraw', 'langs021');
		}else if($val['u_account_type'] == 2){
			$icon = lang('plugin/ck8_withdraw', 'langs022');
		}else if($val['u_account_type'] == 3){
			$icon = lang('plugin/ck8_withdraw', 'langs023');
		}
		$u_bank = $val['u_bank'] ? '-'.$val['u_bank']: '';
		$sel_list[$key]['selid'] = $val['u_id'];
		$sel_list[$key]['sel'] = $icon.'-'.$val['u_name'].'-'.$val['u_card'].$u_bank;
	}

}else if($act == 'apply_state'){//����״̬

    $where = array();
	if($_GET['s_id']){
		$where['s_id'] = intval($_GET['s_id']);
	}else{
		$where['s_apply_uid'] = $_G['uid'];
	}
	$s_list = C::t('#ck8_withdraw#ck8_withdraw_log')->get_ck8_withdraw_log_first($where);
    $u_list = DB::fetch_first('SELECT * FROM %t WHERE u_id=%d',array('ck8_withdraw_account',$s_list['s_account_type']));
	$u_account_type_name = '';
	if($u_list['u_account_type'] == 1){
		$u_account_type_name = lang('plugin/ck8_withdraw', 'langs021').lang('plugin/ck8_withdraw', 'langs039');
	}else if($u_list['u_account_type'] == 2){
		$u_account_type_name = lang('plugin/ck8_withdraw', 'langs022').lang('plugin/ck8_withdraw', 'langs039');
	}else if($u_list['u_account_type'] == 3){
		$u_account_type_name = lang('plugin/ck8_withdraw', 'langs023').lang('plugin/ck8_withdraw', 'langs039');
	}
	$u_name = mb_substr($u_list['u_name'], 0,1,CHARSET).'*******'.mb_substr($u_list['u_name'],-1,1,CHARSET);
	$u_card = substr($u_list['u_card'], 0, 3).'************'.substr($u_list['u_card'], -2);

}else if($act == 'apply_log'){//���ּ�¼

    $perpage = 10;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage-1)*$perpage;
	$s_list = C::t('#ck8_withdraw#ck8_withdraw_log')->get_ck8_withdraw_log_list($start,$perpage,array('s_apply_uid' => $_G['uid']));
	if($_GET['inajax'] == 1){
		$html = '';
		if($s_list){
			foreach($s_list as $val){
				if($val['s_transfer_state'] == 1){
					$txt = lang('plugin/ck8_withdraw', 'langs060');
				}else if($val['s_transfer_state'] == 2){
					$txt = lang('plugin/ck8_withdraw', 'langs061');
				}else if($val['s_transfer_state'] == 3){
					$txt = lang('plugin/ck8_withdraw', 'langs062');
				}else if($val['s_transfer_state'] == 4){
					$txt = lang('plugin/ck8_withdraw', 'langs063');
				}
			    $html .='<div class="ck8-list" style="margin-bottom:5px;">
							<div class="ck8-list-text ck8-list-text-c">
								'.lang('plugin/ck8_withdraw', 'langs064').$txt.'<div class="ck8-list-info">'.dgmdate($val['s_apply_dateline']).'</div>
							</div>
							<div class="list-content-c">
								'.lang('plugin/ck8_withdraw', 'langs065').' <i style="font-size:15px;color:#FF9800;">'.$val['s_apply_number'].'</i>'.$credit_name.'
							</div>
							<div class="ck8-list-text ck8-list-text-c">
								<div class="ck8-list-info" style="color:#999;font-size:14px;width:100%;position:relative;">'.lang('plugin/ck8_withdraw', 'langs066').$val['s_apply_moey'].lang('plugin/ck8_withdraw', 'langs033').' <a href="plugin.php?id=ck8_withdraw&act=apply_state&s_id='.$val['s_id'].'" class="ck8-app-stylexq stylexq-pcs">'.lang('plugin/ck8_withdraw', 'langs067').'</a></div>
							</div>
						</div>';
			}
		}else{
			    $html .='<div class="ck8-center">
							<i class="ck8-icons ck8-icons-wushuju1"></i>
							<p>'.lang('plugin/ck8_withdraw', 'langs068').'</p>
						</div>';
		}
	    echo $html;exit;
	}
}
include template('ck8_withdraw:withdraw');
?>