<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
cpheader();
include_once libfile('class/Withdraw','plugin/ck8_withdraw');
$config = Withdraw::config();

if(!$_GET['act']){
	$perpage = 20;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage-1)*$perpage;
	$s_transfer_state = intval($_GET['s_transfer_state']);
	$s_apply_dateline = dmktime($_GET['s_apply_dateline']);
	$s_apply_dateline2 = dmktime($_GET['s_apply_dateline2']);
	$where = array();
	if($_GET['s_apply_uid']){
		$uid = ($uids = C::t('common_member')->fetch_uid_by_username($_GET['s_apply_uid'])) ? $uids : $_GET['s_apply_uid'];
		$uid = is_numeric($uid) ? $uid : -1;
		$where['s_apply_uid'] = intval($uid);
	}
	if($s_transfer_state){
		$where['s_transfer_state'] = $s_transfer_state;
	}
	if($s_apply_dateline){
		$s_apply_dateline = strtotime(date('Y-m-d',$s_apply_dateline));
		$where['s_apply_dateline'] = $s_apply_dateline;
	}
	if($s_apply_dateline2){
		$s_apply_dateline2 = strtotime(date('Y-m-d',strtotime( "+1 day",$s_apply_dateline2)));
		$where['s_apply_dateline2'] = $s_apply_dateline2;
	}

	$count = C::t('#ck8_withdraw#ck8_withdraw_log')->get_ck8_withdraw_log_count($where);
	$mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=ck8_withdraw&pmod=AdminWithdrawLog&s_transfer_state=".$s_transfer_state."&s_apply_uid=".$s_apply_uid."&s_apply_dateline=".$s_apply_dateline."&s_apply_dateline2=".$s_apply_dateline2;
	$multipage = multi($count, $perpage,$curpage,$mpurl, 0, 5);
	$list = C::t('#ck8_withdraw#ck8_withdraw_log')->get_ck8_withdraw_log_list($start,$perpage,$where);

	$bnt = lang('plugin/ck8_withdraw', 'langs001'); 
	$apply_uid_txt = lang('plugin/ck8_withdraw', 'langs002');
	$apply_dateline_txt = lang('plugin/ck8_withdraw', 'langs003');
    $transfer_state_txt = lang('plugin/ck8_withdraw', 'langs004');
	$transfer_state = array();
	$transfer_state[] = array(1,lang('plugin/ck8_withdraw', 'langs005'));
	$transfer_state[] = array(2,lang('plugin/ck8_withdraw', 'langs006'));
	$transfer_state[] = array(3,lang('plugin/ck8_withdraw', 'langs007'));
	$transfer_state[] = array(4,lang('plugin/ck8_withdraw', 'langs008'));
	$sel_transfer_state = Withdraw::get_select('s_transfer_state', $transfer_state, $s_transfer_state, array(0, lang('plugin/ck8_withdraw', 'langs009')));
echo <<<SEARCH
		<script src="static/js/calendar.js" type="text/javascript"></script>
		<form method="post" autocomplete="off" id="tb_search" action="$mpurl">
		<table style="padding:10px 0;">
			<tbody>
			<tr>
			<th>
				<td>&nbsp;$transfer_state_txt&nbsp;</td><td>$sel_transfer_state</td>
				<td>&nbsp;&nbsp;&nbsp;$apply_uid_txt</td><td>&nbsp;<td><input type="text" name="s_apply_uid" value="" style="width:180px;"></td>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$apply_dateline_txt</td><td>&nbsp;<td>
				  <input type="text" class="txt" name="s_apply_dateline" value="{$_GET['s_apply_dateline']}" onclick="showcalendar(event, this)">~
				  <input type="text" class="txt" name="s_apply_dateline2" value="{$_GET['s_apply_dateline2']}" onclick="showcalendar(event, this)">
				</td>
				<td>&nbsp;&nbsp;&nbsp;<input type="submit" class="btn" value="$bnt"></td>
			</th>
			</tr>
			</tbody>
		</table>
		</form>
SEARCH;

	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=ck8_withdraw&pmod=AdminWithdrawLog&act=del','enctype');
	showtableheader(lang('plugin/ck8_withdraw', 'langs010'));
		showtablerow('class="header"',array('class="td25"'),array(
			lang('plugin/ck8_withdraw', 'langs011'),
			lang('plugin/ck8_withdraw', 'langs012'),
			lang('plugin/ck8_withdraw', 'langs013'),
			lang('plugin/ck8_withdraw', 'langs014'),
			lang('plugin/ck8_withdraw', 'langs015'),
			lang('plugin/ck8_withdraw', 'langs016'),
			lang('plugin/ck8_withdraw', 'langs017'),
			lang('plugin/ck8_withdraw', 'langs018'),
			lang('plugin/ck8_withdraw', 'langs019'),
			lang('plugin/ck8_withdraw', 'langs020')
		));
		foreach ($list as $v) {
		    $accountlist = DB::fetch_first('SELECT u_account_type,u_card FROM %t WHERE u_id=%d',array('ck8_withdraw_account',$v['s_account_type']));
			$u_account_type_name = '';
			if($accountlist['u_account_type'] == 1){
				$u_account_type_name = lang('plugin/ck8_withdraw', 'langs021');
			}else if($accountlist['u_account_type'] == 2){
				$u_account_type_name = lang('plugin/ck8_withdraw', 'langs022');
			}else if($accountlist['u_account_type'] == 3){
				$u_account_type_name = lang('plugin/ck8_withdraw', 'langs023');
			}
			$payment = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do=$pluginid&identifier=ck8_withdraw&pmod=AdminWithdrawLog&act=payment&s_id='.$v['s_id'].'">'.lang('plugin/ck8_withdraw', 'langs024').'</a>';
			if($v['s_transfer_state'] == 1){
				$s_transfer_state = '<em style="color:#4CAF50;">'.lang('plugin/ck8_withdraw', 'langs025').'</em>';
				$payment = lang('plugin/ck8_withdraw', 'langs026');
			}else if($v['s_transfer_state'] == 2){
				$s_transfer_state = '<em style="color:#03A9F4;">'.lang('plugin/ck8_withdraw', 'langs027').'</em>';
			}else if($v['s_transfer_state'] == 3){
				$s_transfer_state = '<em style="color:#F44336;">'.lang('plugin/ck8_withdraw', 'langs028').'</em>';
				$payment = lang('plugin/ck8_withdraw', 'langs029');
			}else if($v['s_transfer_state'] == 4){	
			    $s_transfer_state = '<em style="color:#673AB7;">'.lang('plugin/ck8_withdraw', 'langs030').'</em>';
				$payment = lang('plugin/ck8_withdraw', 'langs031');
			}
			$get_name = getuserbyuid($v['s_apply_uid']);
			showtablerow('', array('class="td25"'), array(
				'<input class="checkbox" type="checkbox" name="delete['.$v['s_id'].']" value="' .$v['s_id'].'">',
				$get_name['username'],
				$accountlist['u_card'] ? $u_account_type_name.'>>'.$accountlist['u_card'] : lang('plugin/ck8_withdraw', 'langs032'),
				$v['s_apply_number'].$_G['setting']['extcredits'][$config['credit_type']]['title'],
				$v['s_apply_moey'].lang('plugin/ck8_withdraw', 'langs033'),
				$v['s_service'].lang('plugin/ck8_withdraw', 'langs033'),
				$s_transfer_state,
				$v['s_transfer_line'] ? dgmdate($v['s_transfer_line']) : '--',
				dgmdate($v['s_apply_dateline']),
				$payment
			));
		}
		showsubmit('delsubmit', lang('plugin/ck8_withdraw', 'langs034'), '<label><input type="checkbox" name="chkall" class="checkbox" onclick="checkall(this.form,\'delete\')" />'.lang('plugin/ck8_withdraw', 'langs035').'</label>','', $multipage,'');
	showtablefooter();/*Dism��taobao��com*/
	/*Dism_taobao��com*/showformfooter();
	
}else if($_GET['act'] == 'del'){
	if (submitcheck('delsubmit')){
		if (empty($_POST['delete'])){
			cpmsg(lang('plugin/ck8_withdraw', 'langs036'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=ck8_withdraw&pmod=AdminWithdrawLog', 'error');
		}else{
			foreach ($_POST['delete'] as $del){
				C::t('#ck8_withdraw#ck8_withdraw_log')->delete(array('s_id' => $del));
			}
			cpmsg(lang('plugin/ck8_withdraw', 'langs037'),'action=plugins&operation=config&do='.$pluginid.'&identifier=ck8_withdraw&pmod=AdminWithdrawLog', 'succeed');
		}
	}
}else if($_GET['act'] == 'payment'){
	$cs_id = intval($_GET['s_id']) ? intval($_GET['s_id']): intval($_POST['s_id']);
    $s_list = C::t('#ck8_withdraw#ck8_withdraw_log')->get_ck8_withdraw_log_first(array('s_id' => $cs_id));
	if($s_list['s_transfer_state'] != 2){
		cpmsg(lang('plugin/ck8_withdraw', 'langs038'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=ck8_withdraw&pmod=AdminWithdrawLog', 'succeed');
	}
	$get_name = getuserbyuid($s_list['s_apply_uid']);
    if (!submitcheck('paymentsubmit')){
		$u_list = DB::fetch_first('SELECT * FROM %t WHERE u_id=%d',array('ck8_withdraw_account',$s_list['s_account_type']));
		$u_account_type_name = '';
		if($u_list['u_account_type'] == 1){
			$u_account_type_name = lang('plugin/ck8_withdraw', 'langs021').lang('plugin/ck8_withdraw', 'langs039');
		}else if($u_list['u_account_type'] == 2){
			$u_account_type_name = lang('plugin/ck8_withdraw', 'langs022').lang('plugin/ck8_withdraw', 'langs039');
		}else if($u_list['u_account_type'] == 3){
			$u_account_type_name = lang('plugin/ck8_withdraw', 'langs023').lang('plugin/ck8_withdraw', 'langs039');
		}
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=ck8_withdraw&pmod=AdminWithdrawLog&act=payment', 'enctype');
            showtableheader(lang('plugin/ck8_withdraw', 'langs040'));
			echo '<input type="hidden" name="s_id" value="'.$s_list['s_id'].'"/>';
			showsetting(lang('plugin/ck8_withdraw', 'langs041'), 'user_id',$s_list['s_apply_uid'], 'text', 1, '','');
			showsetting(lang('plugin/ck8_withdraw', 'langs042'), 'user_name',$get_name['username'], 'text', 1, '','');
			showsetting(lang('plugin/ck8_withdraw', 'langs043').'('.$_G['setting']['extcredits'][$config['credit_type']]['title'].')', 's_apply_number',$s_list['s_apply_number'], 'text', 1, '','');
			showsetting(lang('plugin/ck8_withdraw', 'langs044'), 's_apply_moey',$s_list['s_apply_moey'].lang('plugin/ck8_withdraw', 'langs033'), 'text', 1, '','');
			showsetting(lang('plugin/ck8_withdraw', 'langs045'), 's_service',$s_list['s_service'].lang('plugin/ck8_withdraw', 'langs033'), 'text', 1, '','');
			showsetting(lang('plugin/ck8_withdraw', 'langs046'), 's_apply_dateline',dgmdate($s_list['s_apply_dateline']), 'text', 1, '','');
			showsetting(lang('plugin/ck8_withdraw', 'langs047'), 'u_account_type',$u_account_type_name, 'text', 1, '','');
			showsetting(lang('plugin/ck8_withdraw', 'langs048'), 'u_name',$u_list['u_name'], 'text', 1, '','');
			showsetting(lang('plugin/ck8_withdraw', 'langs049'), 'u_card',$u_list['u_card'], 'text', 1, '','');
			if($u_list['u_account_type'] == 3){
				showsetting(lang('plugin/ck8_withdraw', 'langs050'), 'u_bank',$u_list['u_bank'], 'text', 1, '','');
				showsetting(lang('plugin/ck8_withdraw', 'langs021'), 'u_bank_address',$u_list['u_bank_address'], 'text', 1, '','');
			}
			showsetting(lang('plugin/ck8_withdraw', 'langs052'), 's_transfer_state',1, 'radio', '', '',lang('plugin/ck8_withdraw', 'langs053'));
	    showsubmit('paymentsubmit',lang('plugin/ck8_withdraw', 'langs054'),'',lang('plugin/ck8_withdraw', 'langs055'),'','');
        showtablefooter();/*Dism��taobao��com*/
        /*Dism_taobao��com*/showformfooter();
	}else{
		if($_POST['s_transfer_state']){
			C::t('#ck8_withdraw#ck8_withdraw_log')->update(array('s_transfer_state' => 1,'s_transfer_line' => TIMESTAMP),array('s_id' => intval($_POST['s_id'])));
			cpmsg(lang('plugin/ck8_withdraw', 'langs056'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=ck8_withdraw&pmod=AdminWithdrawLog', 'succeed');
		}else{
			updatemembercount($s_list['s_apply_uid'], array('extcredits'.$config['credit_type'] => $s_list['s_apply_number']), true, '',1,1,lang('plugin/ck8_withdraw', 'langs057'),lang('plugin/ck8_withdraw', 'langs058'));
			C::t('#ck8_withdraw#ck8_withdraw_log')->update( array('s_transfer_state' => 4), array('s_id' => intval($_POST['s_id'])));
			cpmsg(lang('plugin/ck8_withdraw', 'langs059'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=ck8_withdraw&pmod=AdminWithdrawLog', 'succeed');
		}
	}
}
//From: Dism_taobao_com
?>