<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class Withdraw {

	public static function config(){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		return $_G['cache']['plugin']['ck8_withdraw'];
	}

	public static function get_select($name, $data, $selected='', $initial='',$style='') {
		$select = '<select name="'.$name.'" id="'.$name.'" '.$style.'>';
		if ($initial) {
			$select.= '<option value="'.$initial[0].'">'.$initial[1].'</option>';
		}
		foreach ($data as $v) {
			$sed = $selected == $v[0] ? 'selected' : '';
			$select.= '<option value="'.$v[0].'" '.$sed.'>'.$v[1].'</option>';
		}
		$select.= '</select>';
		return $select;
	}

	public static function RetMsgJson($arr,$isexit=false){
		if (is_array($arr)) {
			foreach($arr as $k => $v){
				if(strtolower(CHARSET) == 'gbk'){
					if(is_array($v)) {
						foreach($v as $key => $val){
							$ret[$k][$key] = iconv('gbk', 'utf-8',$val);
						}
					}else{
						$ret[$k] = iconv('gbk', 'utf-8',$v);
					}
				}else{
					if(is_array($v)) {
						foreach($v as $key => $val){
							$ret[$k][$key] = $val;
						}
					}else{
						$ret[$k] = $v;
					}
				}
			}
			if($isexit){
				return json_encode($ret);
			}else{
				echo json_encode($ret);exit;
			}
		}else{
			if(strtolower(CHARSET) == 'gbk'){
				$arr = iconv('gbk', 'utf-8',$arr);
			}
			if($isexit){
				return json_encode($arr);
			}else{
				echo json_encode($arr);exit;
			}
		}
	}

	public static function diconv_gbk_to_utf8($str){
		if(strtolower(CHARSET) == 'gbk'){
			$str = iconv('utf-8', 'gbk',$str);
		}
		return $str;
	}

}
//From: Dism_taobao_com
?>