<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$act = daddslashes($_GET['act']);
$uid = dintval($_GET['uid']);

if(!empty($uid) && $uid != $_G['uid']){
	echo 'error';exit;
}

if($act == 'add' && $_GET['formhash'] == FORMHASH){
	$data = array();
	$data['faid'] = dintval($_GET['aid']);
	$data['furl'] = daddslashes($_GET['url']);
	if($data['faid']){
		$flist = DB::result_first("SELECT * FROM %t WHERE faid=%d",array('ck8_vdocover',$data['faid']));
		if($flist['id']){
			DB::update('ck8_vdocover',$data,array('id' => $flist['id']),true);
		}else{
			DB::insert('ck8_vdocover',$data,true);;
		}
		echo 'succeed';exit;
	}
}else if($act == 'del' && $_GET['formhash'] == FORMHASH){
	$aid = dintval($_GET['aid']);
	if($aid){
		DB::delete('ck8_vdocover',array('faid' => $aid));
		echo 'succeed';exit;
	}
}
//From: Dism_taobao_com
?>