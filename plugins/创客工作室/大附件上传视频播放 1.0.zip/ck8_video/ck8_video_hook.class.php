<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_ck8_video {

    public static $config;
    public static $upfhash;
    public static $attachurl;

	public function __construct(){
        global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		self::$config = $_G['cache']['plugin']['ck8_video'];
        self::$upfhash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
        self::$attachurl = $_G['siteurl'].$_G['setting']['attachurl'].'forum/';
	}

	function global_header(){
        global $_G;
		$style ='';
		$config = self::$config;
		$height = explode('|',$config['height']);
		$width = explode('|',$config['width']);
		$height = $height[0] ? $height[0] : '430px';
		$width = $width[0] ? $width[0] : '100%';
		$style ='<link rel="stylesheet" href="source/plugin/ck8_video/static/audio/APlayer.min.css">
				<script src="source/plugin/ck8_video/static/audio/APlayer.min.js"></script>
				<script type="text/javascript" src="source/plugin/ck8_video/ckplayer/ckplayer_'.CHARSET.'.js" charset="'.CHARSET.'"></script>';
		if($_G['basescript'] == 'forum' && $_G['gp_mod'] == 'forumdisplay'){
			if($config['current_show'] > 1){
				$style .='<style type="text/css">
						   .ck8-player{position:relative;width:47%;display:inline-block;}
						   .ck8-player iframe.iframevideo{width:95%;height:200px;margin:10px 5px;}
						   .ck8-player iframe.iframe{width:90%;height:80px;margin:10px 5px;}
						   .ck8-player .aplayers{width:90%;background:#494A5F;margin:10px 5px;padding:2px 0px;color:#cfcfcf;border-radius:3px;}
						   .ck8-player .video{width:95%;height:200px;margin:10px 5px;}
						</style>';
			}else{
				$style .='<style type="text/css">
						   .ck8-player{position:relative;width:100%;display:inline-flex;}
						   .ck8-player iframe.iframevideo{width:60%;height:220px;margin:10px 5px;}
						   .ck8-player iframe.iframe{width:99%;height:80px;margin:10px 5px;}
						   .ck8-player .aplayers{width:100%;background:#494A5F;margin:10px 5px;padding:2px 0px;color:#cfcfcf;border-radius:3px;}
						   .ck8-player .video{width:60%;height:220px;margin:10px 5px;}
						</style>';
			}
		}else if($_G['basescript'] == 'forum' && $_G['gp_mod'] == 'viewthread'){
			$style .='<style type="text/css">
					   .ck8-player{position:relative;width:100%;display:inline-flex;}
					   .ck8-player iframe.iframevideo{width:'.$width.';height:'.$height.';margin:10px 5px;}
					   .ck8-player iframe.iframe{width:'.$width.';height:80px;margin:10px 5px;}
					   .ck8-player .aplayers{width:'.$width.';background:#494A5F;margin:10px 5px;padding:2px 0px;color:#cfcfcf;border-radius:3px;}
					   .ck8-player .video{width:'.$width.';height:'.$height.';margin:10px 5px;}
					</style>';
		}
		return $style;
    }

	function discuzcode($param){
		global $_G;
        $config = self::$config;
		if(!in_array($_G['fid'],dunserialize($config['forum_media']))) return;
		if($param['caller'] == 'discuzcode' && CURMODULE == 'viewthread'){
			if(strexists($_G['discuzcodemessage'],'[/media]') !== FALSE){
				$_G['discuzcodemessage'] = preg_replace_callback("/\[media(.*?)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is","self::concentrate_replace",$_G['discuzcodemessage']);
			}
			if(strexists($_G['discuzcodemessage'],'[/audio]') !== FALSE){
				$_G['discuzcodemessage'] = preg_replace_callback("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/is","self::audio_replace",$_G['discuzcodemessage']);
			}
			if(strexists($_G['discuzcodemessage'],'[/attach]') !== FALSE){
				$_G['discuzcodemessage'] = preg_replace_callback("/\[attach(.*?)\](\d+)\[\/attach\]/i","self::attach_replace",$_G['discuzcodemessage']);
			}
		}else if($param['caller'] == 'messagecutstr'){
			if($config['subject_show']){
				$_G['discuzcodemessage'] = '';
			}
		}
	}

	public static function attach_replace($matches,$is_match=FALSE){
		global $_G;
		$config = self::$config;
		$aid = $is_match ? $matches : $matches[2];
		$video = explode('|',$config['video_bmp']);
		$voice = explode('|',$config['voice_bmp']);
		if(empty($aid)){return $is_match ? '' : $matches[0];}
		$aidtb = getattachtablebyaid($aid);
		$attachlist = DB::fetch_all("SELECT readperm,price,attachment,filename,remote,dateline,filesize FROM %t WHERE aid=%d",array($aidtb,$aid));
		$furl = DB::result_first("SELECT furl FROM %t WHERE faid=%d",array('ck8_vdocover',$aid));
		require_once libfile('function/attachment'); 
		foreach($attachlist as $k => $attach){
			$attachurl = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/';
			$attachext = strtolower(fileext($attach['filename']));
			$attachicon = attachtype($attachext."\t");
			$attachdate = dgmdate($attach['dateline'], 'u');
			$attachsize = sizecount($attach['filesize']);
			$readperm = $attach['readperm'] ? lang('plugin/ck8_video', 'lang_vdo002').'<strong>'.$attach['readperm'].'</strong>' : '';
			$price = $attach['price'] ? lang('plugin/ck8_video', 'lang_vdo003').'<strong>'.$attach['price'].'&nbsp;'.$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['unit'].$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['title'].'</strong>' : '';
			if(!$config['media_analysis'] && ($attach['readperm'] || $attach['price'])){
				if(checkmobile() && CURMODULE == 'viewthread'){
                    $attachhtml ='<div style="margin:10px 0px;"><dd><p class="attnm"> '.$attachicon.'<a href="javascript:;" id="">'.$attach['filename'].'</a></p><p class="xglc">('.$attachdate.lang('plugin/ck8_video', 'lang_vdo004').')&nbsp;'.$attachsize.'&nbsp;'.$readperm.',&nbsp; '.$price.'&nbsp;&nbsp;'.lang('plugin/ck8_video', 'lang_vdo005').'</p></dd></div>';
					return $attachhtml;
				}else{
					return $is_match ? '' : $matches[0];
				}
			}
			if(in_array($attachext,$voice)){
				return self::player($attachurl.$attach['attachment'], 'voice', $aid, $attach['filename']);
			}else if(in_array($attachext,$video)){
				$furl = $furl ? $furl : $config['cover_init'];
				return self::player($attachurl.$attach['attachment'], 'video', $aid, '', $furl);
			}else if($attach['readperm'] || $attach['price']){
				if(checkmobile() && CURMODULE == 'viewthread'){
                    $attachhtml ='<div style="margin:10px 0px;"><dd><p class="attnm"> '.$attachicon.'<a href="javascript:;" id="">'.$attach['filename'].'</a></p><p class="xglc">('.$attachdate.lang('plugin/ck8_video', 'lang_vdo004').')&nbsp;'.$attachsize.'&nbsp;'.$readperm.',&nbsp; '.$price.'&nbsp;&nbsp;'.lang('plugin/ck8_video', 'lang_vdo005').'</p></dd></div>';
					return $attachhtml;
				}else{
					return $is_match ? '' : $matches[0];
				}
			} else {
				return $is_match ? '' : $matches[0];
			}
		}
    }

	public static function noattach_replace($postlist, $isforumdisplay=FALSE){
		global $_G;
		$config = self::$config;
		$message = $postlist['message'];
		$attachmsg = array();
		$tid = $postlist['tid'];
		$pid = $postlist['pid'];
		$fid = $postlist['fid'];
		$video = explode('|',$config['video_bmp']);
		$voice = explode('|',$config['voice_bmp']);
		$post = DB::fetch_first("SELECT message FROM %t WHERE tid=%d and pid=%d and fid=%d ",array('forum_post', $tid, $pid, $fid));
		preg_match_all("/\[attach(.*?)\](\d+)\[\/attach\]/i", $post['message'], $mat);
		$aidtb = getattachtablebytid($tid);
		$attachlist = DB::fetch_all("SELECT aid,readperm,price,attachment,filename,remote,dateline,filesize FROM %t WHERE tid=%d and pid=%d",array($aidtb,$tid,$pid));
		$aids = array();
		foreach($attachlist as $v){
		    $aids[] = $v['aid'];
		}
		$aidsstr = implode(",", $aids);
		unset($aids);
        $aidlist = DB::fetch_all("SELECT faid,furl FROM %t WHERE faid IN (%n)", array('ck8_vdocover', $aidsstr));
		$furlarr = array();
		foreach($aidlist as $key => $val){
		    $furlarr[$val['faid']] = $val['furl'];
		}
		unset($aidlist);
		require_once libfile('function/attachment');
		foreach($attachlist as $k => $attach){
			$attachurl = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/';
			$attachext = strtolower(fileext($attach['filename']));
			if(!in_array($attach['aid'], $mat[2])){	
				$attachicon = attachtype($attachext."\t");
				$attachdate = dgmdate($attach['dateline'], 'u');
				$attachsize = sizecount($attach['filesize']);
				$readperm = $attach['readperm'] ? lang('plugin/ck8_video', 'lang_vdo002').' <strong>'.$attach['readperm'].'</strong>' : '';
				$price = $attach['price'] ? lang('plugin/ck8_video', 'lang_vdo003').'<strong>'.$attach['price'].'&nbsp;'.$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['unit'].$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['title'].'</strong>' : '';
				if(!$config['media_analysis'] && ($attach['readperm'] || $attach['price'])){
					if(checkmobile() && CURMODULE == 'viewthread'){
						$message .='<div style="margin:10px 0px;"><dd><p class="attnm"> '.$attachicon.'<a href="javascript:;" id="">'.$attach['filename'].'</a></p><p class="xglc">('.$attachdate.lang('plugin/ck8_video', 'lang_vdo004').')&nbsp;'.$attachsize.'&nbsp;'.$readperm.',&nbsp; '.$price.'&nbsp;&nbsp;'.lang('plugin/ck8_video', 'lang_vdo005').'</p></dd></div>';
					}else if(CURMODULE == 'viewthread'){
						return $postlist;
					}
				}else{
					if(in_array($attachext,$voice)){
						if($isforumdisplay){
							$attachmsg[] = self::player($attachurl.$attach['attachment'], 'voice', $attach['aid'], $attach['filename']);
						}else{
							$message .= self::player($attachurl.$attach['attachment'], 'voice', $attach['aid'], $attach['filename']);
						}
					}else if(in_array($attachext,$video)){
						$furl = $furlarr[$attach['aid']] ? $furlarr[$attach['aid']] : $config['cover_init'];
						if($isforumdisplay){
							$attachmsg[] = self::player($attachurl.$attach['attachment'], 'video', $attach['aid'], '', $furl);
						}else{
							$message .= self::player($attachurl.$attach['attachment'], 'video', $attach['aid'], '', $furl);
						}
					}else if($attach['readperm'] || $attach['price']){
						if(checkmobile() && CURMODULE == 'viewthread'){
							$message .='<div style="margin:10px 0px;"><dd><p class="attnm"> '.$attachicon.'<a href="javascript:;" id="">'.$attach['filename'].'</a></p><p class="xglc">('.$attachdate.lang('plugin/ck8_video', 'lang_vdo004').')&nbsp;'.$attachsize.'&nbsp;'.$readperm.',&nbsp; '.$price.'&nbsp;&nbsp;'.lang('plugin/ck8_video', 'lang_vdo005').'</p></dd></div>';
						}
					}
				}
            }
		}
		if($isforumdisplay){
			return $attachmsg;
		}else{
			$postlist['message'] = $message;
			return $postlist;
		}
    }

    //����audioý��
	public static function audio_replace($matches,$is_match=FALSE){
		$url = $is_match ? $matches : $matches[2];
		if(empty($url))return;
		$key = random(5);
		$arr = explode("/",$url);
		if(strexists($arr[count($arr)-1],'.mp3')){
			return self::player($url,'voice',$key,$arr[count($arr)-1]);
		}else if(strexists($url,'music.163.com')){
			return self::player($url,'iframeaudio');
		}
	}
	//����mediaý��������Ƶ
	public static function concentrate_replace($matches,$is_match=FALSE){
		$key = random(5);
		$url = $is_match ? $matches : $matches[2];
		if(empty($url))return;
		$arr = explode("/",$url);
		if(strexists($url, "youku.com") !== FALSE){//youku
			if(strexists($arr[count($arr)-1],"==.html")){
				$player = $arr[0]."//player.youku.com/embed/".str_replace(array("id_",".html"),array("",""),$arr[count($arr)-1]);
			}else if(strexists($arr[count($arr)-1],"v.swf")){
				$player = $arr[0]."//player.youku.com/embed/".$arr[count($arr)-2];
			}else if(strexists($url,"player.youku.com")){
				$player = $url;
			}
			return self::player($player,'iframevideo');
		}else if(strexists($url, "qq.com") !== FALSE){//v.qq.com
            if(strexists($arr[count($arr)-1],"player.html?vid=")){
		        $vid = stristr(str_replace("player.html?vid=","",$arr[count($arr)-1]),'&',TRUE);
		        $player = $arr[0]."//v.qq.com/iframe/player.html?vid=".$vid."&auto=0";
			}else if(strexists($arr[count($arr)-1],".swf?")){
				$vid = str_replace("vid=","",stristr(stristr($arr[count($arr)-1],"vid="),'&',TRUE));
			    $player = $arr[0]."//v.qq.com/iframe/player.html?vid=".$vid."&auto=0";
			}else if(strexists($arr[count($arr)-1],".html")){//��ַ��ʽ
				$vid = str_replace(".html","",$arr[count($arr)-1]);
				$player = $arr[0]."//v.qq.com/iframe/player.html?vid=".$vid."&auto=0";
			}
			return self::player($player,'iframevideo');
		}else if(strexists($url,"player.video.qiyi.com") !== FALSE){//qiyi
			if(preg_match("/http:\/\/player.video.qiyi.com\/([^\/]+).*?tvId=([^-]+).*?/i", $url, $matchesp)) {
				$player = $arr[0].'//open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid='.$matchesp[1].'&tvId='.$matchesp[2].'';
			}
			return self::player($player,'iframevideo');
		}else if(strexists($arr[count($arr)-1],'.mp3')){
			return self::player($url,'voice',$key,$arr[count($arr)-1]);
		}else if(strexists($arr[count($arr)-1],'.mp4')){
			return self::player($url,'video',$key);
		}
	}

    public static function player($playurl, $type, $id=null, $title=null, $furl=null){
		if($type == 'voice'){
			include template('ck8_video:audio');
			return $audio;
		}else if($type == 'video'){
			include template('ck8_video:player');
			return $player;
		}else if($type == 'iframeaudio'){
			$player = '<div class="ck8-player cl"><iframe class="iframe" src="'.$playurl.'" frameborder=0 allowfullscreen scrolling="no" ></iframe></div>';
		}else if($type == 'iframevideo'){
            $player = '<div class="ck8-player cl"><iframe class="iframevideo" src="'.$playurl.'" allowtransparency="true" allowfullscreen="true" allowfullscreenInteractive="true" scrolling="no" border="0" frameborder="0"></iframe></div>';
		}
		return $player;
    }

	public static function sortbytids($result,$tids){
		$resultlist = array();
		foreach ($tids as $v) {
			foreach ($result as $val) {
				if ($v == $val['tid']) {
					$resultlist[$v] = array(
						'message' => $val['message'],
						'tid' => $val['tid'],
						'pid' => $val['pid'],
						'fid' => $val['fid']
					);
				}
			}
		}
		return $resultlist;
	}

	public static function forumdisplay_replace($message, $tid=null, $pid=null, $fid=null){
		$config = self::$config;
		$player = '';
		$playerarr = array();
		if(strexists($message,'[/media]') !== FALSE){
			if(preg_match_all("/\[media(.*?)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is", $message, $match)){
				foreach($match[2] as $val){
					$playerarr[] = self::concentrate_replace($val, true);
				}
		    }
		}
		if(strexists($message,'[/attach]') !== FALSE){
			if(preg_match_all("/\[attach\](\d+)\[\/attach\]/is", $message, $matc)){
				foreach(array_unique($matc[1]) as $val){
					if(empty($val)){continue;}
					$playerarr[] = self::attach_replace($val, true);
				}
			}
		}else{
			$arr = array();
			$arr[] = array('message' => $message, 'tid' => $tid, 'pid' => $pid, 'fid' => $fid);
			foreach($arr as $val){
				if(empty($val['pid'])){continue;}
				$list = self::noattach_replace($val, true);
			}
			foreach($list as $v){
				$playerarr[] = $v;
			}
		}
		if(strexists($message,'[/audio]') !== FALSE){
			if(preg_match_all("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/is", $message, $mat)){
				foreach($mat[2] as $val){
					$playerarr[] = self::audio_replace($val, true);
				}
			}
		}
		foreach ($playerarr as $k => $v){
            if(!empty($config['current_show']) && $k < $config['current_show']){
				$player .= $v;
			}else{
				break;
			}
		}
		return $player;
	}
}

class plugin_ck8_video_forum extends plugin_ck8_video{
	
    function post_attach_btn_extra(){
		global $_G;
		$config = self::$config;
		if(!in_array($_G['groupid'],dunserialize($config['forum_upus'])) || !in_array($_G['fid'],dunserialize($config['forum_open']))) return;
        return "<li id=\"e_btn_attachlists\"><a href=\"javascript:;\" onclick=\"switchAttachbutton('attachlists');\">".lang('plugin/ck8_video', 'lang_vdo001')."</a></li>";
    }

    function post_attach_tab_extra(){
        global $_G;
		$config = self::$config;
		if(!in_array($_G['groupid'],dunserialize($config['forum_upus'])) || !in_array($_G['fid'],dunserialize($config['forum_open']))) return;
		loadcache('groupreadaccess');
        $upfhash = self::$upfhash;
        $attachurl = self::$attachurl;
		$video = json_encode(explode('|',$config['video_bmp']));
		$voice = json_encode(explode('|',$config['voice_bmp']));
		include template('ck8_video:up_file');
	    return $file;
    }

	function forumdisplay_output(){
        global $_G;
		$config = self::$config;
		if(!in_array($_G['fid'],dunserialize($config['forum_media']))) return;
        if(!$_G['forum_threadlist'] || !$config['media_open']){return;}
		$tids = array();
		foreach($_G['forum_threadlist'] as $k => $v){
			$tids[] = $v['tid'];
		}
		require_once libfile('function/post');
		if(empty($tids))return '';
		$result = DB::fetch_all('SELECT fid,pid,tid,message FROM '.DB::table('forum_post').' WHERE first=1 and tid in('.dimplode($tids).')');
		$resultlist = self::sortbytids($result, $tids);
		unset($tids);
		unset($result);
		foreach($_G['forum_threadlist'] as $k => $v){
			$_G['setting']['pluginhooks']['forumdisplay_thread'][$k] = self::forumdisplay_replace(
			    $resultlist[$v['tid']]['message'],
				$resultlist[$v['tid']]['tid'],
				$resultlist[$v['tid']]['pid'],
				$resultlist[$v['tid']]['fid']
			);
		}
    }

	function viewthread_postbottom_output(){
		global $_G,$postlist;
		$config = self::$config;
		if(empty($postlist) || !in_array($_G['fid'],dunserialize($config['forum_media']))) return;
		foreach($postlist as $key =>$val){
            $postlist[$key] = self::noattach_replace($val);
		}
    }
}

class mobileplugin_ck8_video extends plugin_ck8_video{
	function global_header_mobile(){
        global $_G;
		$style ='';
		$config = self::$config;
		$height = explode('|',$config['height']);
		$width = explode('|',$config['width']);
		$height = $height[1] ? $height[1] : '200px';
		$width = $width[1] ? $width[1] : '100%';
		$style ='<link rel="stylesheet" href="source/plugin/ck8_video/static/audio/APlayer.min.css">
				<script src="source/plugin/ck8_video/static/audio/APlayer.min.js"></script>
				<script type="text/javascript" src="source/plugin/ck8_video/ckplayer/ckplayer_'.CHARSET.'.js" charset="'.CHARSET.'"></script>';
		if($_G['basescript'] == 'forum' && $_G['gp_mod'] == 'forumdisplay'){
			$style .='<style type="text/css">
					   .ck8-player{position:relative;width:100%;}
					   .ck8-player iframe.iframevideo{width:100%;height:235px;margin:10px 0px;}
					   .ck8-player iframe.iframe{width:100%;height:80px;margin:10px 0px;}
					   .ck8-player .aplayers{width:100%;background:#494A5F;margin:10px 0px;padding:2px 0px;color:#cfcfcf;border-radius:3px;}
					   .ck8-player .video{width:100%;height:235px;margin:10px 0px;}
					</style>';
		}else if($_G['basescript'] == 'forum' && $_G['gp_mod'] == 'viewthread'){
			$style .='<style type="text/css">
					   .ck8-player{position:relative;width:100%;}
					   .ck8-player iframe.iframevideo{width:'.$width.';height:'.$height.';margin:10px 0px;}
					   .ck8-player iframe.iframe{width:'.$width.';height:80px;margin:10px 0px;}
					   .ck8-player .aplayers{width:'.$width.';background:#494A5F;margin:10px 0px;padding:2px 0px;color:#cfcfcf;border-radius:3px;}
					   .ck8-player .video{width:'.$width.';height:'.$height.';margin:10px 0px;}
					   .attnm{margin-bottom:3px;overflow:hidden;white-space:nowrap;}
					   .attnm a{color:#2684ce;text-decoration:underline;}
					   .xglc{display:block;font-size: 13px;color:#999;}
					   .xglc strong{color:#F26C4F;font-weight:400;}
					</style>';
		}
		return $style;
    }
}

class mobileplugin_ck8_video_forum extends mobileplugin_ck8_video {

	function post_bottom_mobile(){
		global $_G;
		$config = self::$config;
		if(!in_array($_G['groupid'],dunserialize($config['forum_upus'])) || !in_array($_G['fid'],dunserialize($config['forum_open']))) return;
		loadcache('groupreadaccess');
        $upfhash = self::$upfhash;
        $attachurl = self::$attachurl;
		$video = json_encode(explode('|',$config['video_bmp']));
		$voice = json_encode(explode('|',$config['voice_bmp']));
		include template('ck8_video:up_file');
	    return $file;
	}

	function forumdisplay_mobile_output(){
        global $_G;
		$config = self::$config;
		if(!in_array($_G['fid'],dunserialize($config['forum_media']))) return;
        if(!$_G['forum_threadlist'] || !$config['media_open']){return;}
		$tids = array();
		foreach($_G['forum_threadlist'] as $k => $v){
			$tids[] = $v['tid'];
		}
		require_once libfile('function/post');
		if(empty($tids))return '';
		$result = DB::fetch_all('SELECT fid,pid,tid,message FROM '.DB::table('forum_post').' WHERE first=1 and tid in('.dimplode($tids).')');
		$resultlist = self::sortbytids($result, $tids);
		unset($tids);
		unset($result);
		foreach($_G['forum_threadlist'] as $k => $v){
			$_G['setting']['pluginhooks']['forumdisplay_thread_mobile'][$k] = self::forumdisplay_replace(
				$resultlist[$v['tid']]['message'],
				$resultlist[$v['tid']]['tid'],
				$resultlist[$v['tid']]['pid'],
				$resultlist[$v['tid']]['fid']
			);
		}
    }
	
	function viewthread_postbottom_mobile_output(){
		global $_G,$postlist;
		$config = self::$config;
		if(empty($postlist) || !in_array($_G['fid'],dunserialize($config['forum_media']))) return;
		foreach($postlist as $key =>$val){
            $postlist[$key] = self::noattach_replace($val);
		}
    }

}
//From: Dism_taobao_com
?>