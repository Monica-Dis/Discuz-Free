<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/ck8_video/ck8_upload.class.php';
    global $_G;
	$fid = intval($_GET['fid']);
	$uid = intval($_GET['uid']);
	if(empty($fid) && empty($uid)) { return;}
	$upfhash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
	$aid = 0;
	$file = isset($_FILES['file_data']) ? $_FILES['file_data'] : null;
	$total = isset($_POST['file_total']) ? $_POST['file_total'] : 0;
	$index = isset($_POST['file_index']) ? $_POST['file_index'] : 0;
	$upsize = isset($_POST['file_size']) ? $_POST['file_size'] : 0;
	$file_name = isset($_POST['file_name']) ? $_POST['file_name'] : null;
	$file_id = isset($_POST['file_id']) ? $_POST['file_id'] : 0;
	if(strtoupper(CHARSET) == 'GBK' && !checkmobile()){
		$file_name = diconv($file_name, 'UTF-8');
	}
	if($_GET['hash'] != $upfhash ){ ck8_upmsg(10);}
		$ck8_upload = new ck8_upload($total,$index,$upsize,$file_name,$file_id);
		$ck8_upload->init($file, 'forum');
		$ck8_upload->save();
        $attach = &$ck8_upload->attach;

		if ($index >= $total){
			if($ck8_upload->error()) {
				ck8_upmsg(2);
			}

			$allowupload = !$_G['group']['maxattachnum'] || $_G['group']['maxattachnum'] && $_G['group']['maxattachnum'] > getuserprofile('todayattachs');;
			if(!$allowupload) {
				ck8_upmsg(6);
			}

			if($_G['group']['attachextensions'] && (!preg_match("/(^|\s|,)".preg_quote($ck8_upload->attach['ext'], '/')."($|\s|,)/i", $_G['group']['attachextensions']) || !$ck8_upload->attach['ext'])) {
				ck8_upmsg(1);
			}

			if(empty($ck8_upload->attach['size'])) {
				ck8_upmsg(2);
			}

			if($_G['group']['maxattachsize'] && $ck8_upload->attach['size'] > $_G['group']['maxattachsize']){
				$error_sizelimit = $_G['group']['maxattachsize'];
				ck8_upmsg(3);
			}

			loadcache('attachtype');
			if($_G['fid'] && isset($_G['cache']['attachtype'][$_G['fid']][$ck8_upload->attach['ext']])){
				$maxsize = $_G['cache']['attachtype'][$_G['fid']][$ck8_upload->attach['ext']];
			} else if(isset($_G['cache']['attachtype'][0][$ck8_upload->attach['ext']])) {
				$maxsize = $_G['cache']['attachtype'][0][$ck8_upload->attach['ext']];
			}
			if(isset($maxsize)){
				if(!$maxsize) {
					$error_sizelimit = 'ban';
					ck8_upmsg(4);
				} elseif($ck8_upload->attach['size'] > $maxsize) {
					$error_sizelimit = $maxsize;
					ck8_upmsg(5);
				}
			}

			if($ck8_upload->attach['size'] && $_G['group']['maxsizeperday']) {
				$todaysize = getuserprofile('todayattachsize') + $ck8_upload->attach['size'];
				if($todaysize >= $_G['group']['maxsizeperday']) {
					$error_sizelimit = 'perday|'.$_G['group']['maxsizeperday'];
					ck8_upmsg(11);
				}
			}
			    if($ck8_upload->error() == -103) {
					ck8_upmsg(8);
				} elseif($ck8_upload->error()) {
					ck8_upmsg(9);
				}
				$thumb = $remote = $width = 0;
				if($_GET['type'] == 'image' && !$ck8_upload->attach['isimage']) {
					ck8_upmsg(7);
				}
				if($ck8_upload->attach['isimage']) {
					if(!in_array($ck8_upload->attach['imageinfo']['2'], array(1,2,3,6))) {
						ck8_upmsg(7);
					}
					if($_G['setting']['showexif']) {
						require_once libfile('function/attachment');
						$exif = getattachexif(0, $ck8_upload->attach['target']);
					}
					if($_G['setting']['thumbsource'] || $_G['setting']['thumbstatus']) {
						require_once libfile('class/image');
						$image = new image;
					}
					if($_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight']) {
						$thumb = $image->Thumb($ck8_upload->attach['target'], '', $_G['setting']['sourcewidth'], $_G['setting']['sourceheight'], 1, 1) ? 1 : 0;
						$width = $image->imginfo['width'];
						$ck8_upload->attach['size'] = $image->imginfo['size'];
					}
					if($_G['setting']['thumbstatus']) {
						$thumb = $image->Thumb($ck8_upload->attach['target'], '', $_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
						$width = $image->imginfo['width'];
					}
					if($_G['setting']['thumbsource'] || !$_G['setting']['thumbstatus']) {
						list($width) = @getimagesize($ck8_upload->attach['target']);
					}
				}

			if ($attach['accomplish'] && $attach['accomplish'] == 1 ){
				updatemembercount($_G['uid'], array('todayattachs' => 1, 'todayattachsize' => $ck8_upload->attach['size']));
				if($_GET['type'] != 'image' && $attach['isimage']){
					$ck8_upload->attach['isimage'] = -1;
				}
				$aid = getattachnewaid($_G['uid']);
				$insert = array(
					'aid' => $aid,
					'dateline' => $_G['timestamp'],
					'filename' => dhtmlspecialchars(censor($ck8_upload->attach['name'])),
					'filesize' => $ck8_upload->attach['size'],
					'attachment' => $ck8_upload->attach['attachment'],
					'isimage' => $ck8_upload->attach['isimage'],
					'uid' => $_G['uid'],
					'thumb' => $thumb,
					'remote' => $remote,
					'width' => $width,
				);
				C::t('forum_attachment_unused')->insert($insert);
				if($ck8_upload->attach['isimage'] && $_G['setting']['showexif']) {
					C::t('forum_attachment_exif')->insert($aid, $exif);
				}
				if ($ck8_upload->attach['isimage'] && $ck8_upload->attach['isimage'] == 1){$simple = $ck8_upload->attach['isimage'];}
				ck8_upmsg(0);
			}else{
				$attachurl = $_G['siteurl'].$_G['setting']['attachurl'].'forum/';
				@unlink($attachurl.$attach['attachment']);
				ck8_upmsg($attach['accomplish']);
			}
		}

	function ck8_upmsg($statusid) {
		global $_G,$error_sizelimit,$aid,$simple,$attach;
		$error_sizelimit = !empty($error_sizelimit) ? $error_sizelimit : 0;
		if($simple == 1){
			echo 'DISCUZUPLOAD|'.$statusid.'|'.$aid.'|'.$attach['isimage'].'|'.($attach['isimage'] ? $attach['attachment'] : '').'|'.$attach['name'].'|'.$attach['size'].'|'.$attach['ext'].'|'.$error_sizelimit;
		}else{
			echo $statusid ? $statusid : 'DISCUZUPLOAD|'.$statusid.'|'.$aid.'|'.$attach['isimage'].'|'.$attach['attachment'].'|'.$attach['name'].'|'.$attach['size'].'|'.$attach['ext'].'|'.$error_sizelimit;
		}
		exit;
	}
//From: Dism_taobao_com
?>