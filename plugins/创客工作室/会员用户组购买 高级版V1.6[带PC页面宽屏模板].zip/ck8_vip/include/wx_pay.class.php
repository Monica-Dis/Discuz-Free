<?php
function std_class_object_to_array($stdclassobject)
{
    $_array = is_object($stdclassobject) ? get_object_vars($stdclassobject) : $stdclassobject;
    foreach ($_array as $key => $value) {
        $value = (is_array($value) || is_object($value)) ? std_class_object_to_array($value) : $value;
        $array[$key] = $value;
    }
    return $array;
}
function postxml($url,$data)
{
	$ch = curl_init($url); 
	curl_setopt($ch, CURLOPT_MUTE, 1); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); 
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
	curl_setopt($ch, CURLOPT_POST, 1); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml')); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, "$data"); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	$output = curl_exec($ch); 
	curl_close($ch); 
	return $output;
}

function postXmlCurl($xml,$url,$second=30)
{	 
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_TIMEOUT,$second);
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	curl_setopt($ch,CURLOPT_HEADER,FALSE);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,TRUE);
	curl_setopt($ch,CURLOPT_POST,TRUE);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$xml);
	$data = curl_exec($ch);
	curl_close($ch);
	if($data){
		curl_close($ch);
		return $data;
	}
}
function get($url)
{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

	if (!curl_exec($ch)) {
		error_log(curl_error($ch));
		$data = '';
	} else {
		$data = curl_multi_getcontent($ch);
	}
	curl_close($ch);
	return $data;
}

function getRandChar($length)
{
   $str = null;
   $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";
   $max = strlen($strPol)-1;
   for($i=0;$i<$length;$i++){
    $str.=$strPol[rand(0,$max)];
   }
  return $str;
}

function createNoncestr( $length = 32 )
{
	$chars = "abcdefghijklmnopqrstuvwxyz0123456789";  
	$str ="";
	for ( $i = 0; $i < $length; $i++ )  {  
		$str.= substr($chars, mt_rand(0, strlen($chars)-1), 1);  
	}  
	return $str;
}

function ck8_getwxsign($arrtmp,$wxkey)
{
	foreach ($arrtmp as $key => $value){
		$parameters[$key] = $value;
	}
	ksort($parameters);
	$string = formatBizQueryParaMap($parameters,false);
	$string = $string."&key=$wxkey";
	$string = md5($string);
	$resultstr = strtoupper($string);
	return $resultstr;
}

function formatBizQueryParaMap($querystr,$isurlencode)
{
	$tmpstr = '';
	ksort($querystr);
	foreach($querystr as $key => $value){
		if($isurlencode){
		   $value = urlencode($value);
		}
		$tmpstr .= $key.'='.$value.'&';
	}
	$returnstr='';
	if(strlen($tmpstr) > 0){
		$returnstr = substr($tmpstr,0,strlen($tmpstr)-1);
	}
	return $returnstr;
}


function arrayToXml($arr){
	$xmlstr='';
	foreach($arr as $key=>$val){
		 if(is_numeric($val)){
			$xmlstr.='<'.$key.'>'.$val.'</'.$key.'>'; 
		 }else{
			$xmlstr.='<'.$key.'><![CDATA['.$val.']]></'.$key.'>';  
		 }
	}
	$xmlstr='<xml>'.$xmlstr.'</xml>';
	return $xmlstr; 
}


function xmlToArray($xml){
    libxml_disable_entity_loader(true);
	$xmltmp=simplexml_load_string($xml,'SimpleXMLElement',LIBXML_NOCDATA);
	$arraytmp = json_decode(json_encode($xmltmp),true);
	return $arraytmp;
}


function createOauthUrlForCode($redirectUrl)
{
	global $appid;
	$urlObj["appid"] = $appid;
	$urlObj["redirect_uri"] = urlencode($redirectUrl);
	$urlObj["response_type"] = "code";
	$urlObj["scope"] = "snsapi_base";
	$urlObj["state"] = "STATE"."#wechat_redirect";
	$bizString = formatBizQueryParaMap($urlObj, false);
	return "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
}

function createOauthUrlForOpenid()
{
	global $appid,$appsecret,$code;
	$urlObj["appid"] = $appid;
	$urlObj["secret"] = $appsecret;
	$urlObj["code"] = $code;
	$urlObj["grant_type"] = "authorization_code";
	$bizString = formatBizQueryParaMap($urlObj, false);
	return "https://api.weixin.qq.com/sns/oauth2/access_token?".$bizString;
}

function getOpenid()
{
	$url = createOauthUrlForOpenid();
	$ch = curl_init();
	curl_setopt($ch, CURLOP_TIMEOUT, 30);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
	curl_setopt($ch, CURLOPT_HEADER, FALSE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	$res = curl_exec($ch);
	curl_close($ch);
	$data = json_decode($res,true);
	$return = $data['openid'];
	return $return;
}
//From: Dism_taobao-com
?>