<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(file_exists($ck8_pay_list = DISCUZ_ROOT.'./data/sysdata/cache_ck8_pay_list.php')){
	@include $ck8_pay_list;
}

if($_GET['act'] == 'adds'){
	if(submitcheck('submit')){
		$pay_list = array();
		$pay_list['zfb_id'] = addslashes($_GET['zfb_id']);
		$pay_list['zfb_zh'] = addslashes($_GET['zfb_zh']);
		$pay_list['zfb_key'] = addslashes($_GET['zfb_key']);

		$pay_list['wx_appid'] = addslashes($_GET['wx_appid']);
		$pay_list['wx_appsecret'] = addslashes($_GET['wx_appsecret']);
		$pay_list['wx_mchid'] = addslashes($_GET['wx_mchid']);
		$pay_list['wx_apikey'] = addslashes($_GET['wx_apikey']);

		$pay_list['wxapp_appid'] = addslashes($_GET['wxapp_appid']);
		$pay_list['wxapp_mch_id'] = addslashes($_GET['wxapp_mch_id']);
		$pay_list['wxapp_key'] = addslashes($_GET['wxapp_key']);
		
		$pay_list['magappxsecret'] = addslashes($_GET['magappxsecret']);
		$pay_list['magappdomain'] = addslashes($_GET['magappdomain']);

		writetocache('ck8_pay_list',getcachevars(array('pay_list'=>$pay_list)));
		cpmsg(lang('plugin/ck8_vip', 'bcok'),'action=plugins&operation=config&do='.$pluginid.'&identifier=ck8_vip&pmod=admin_paylist','succeed');
	}
}

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=ck8_vip&pmod=admin_paylist&act=adds');
showtableheader(lang('plugin/ck8_vip', 'zfb_sz'));
showsetting(lang('plugin/ck8_vip', 'zfb_id'), 'zfb_id', $pay_list['zfb_id'], 'text');
showsetting(lang('plugin/ck8_vip', 'zfb_zh'), 'zfb_zh', $pay_list['zfb_zh'], 'text');
showsetting(lang('plugin/ck8_vip', 'zfb_key'), 'zfb_key',  $pay_list['zfb_key'], 'text');

showtableheader(lang('plugin/ck8_vip', 'wx_sz'));
showsetting(lang('plugin/ck8_vip', 'wx_appid'), 'wx_appid', $pay_list['wx_appid'], 'text');
showsetting(lang('plugin/ck8_vip', 'wx_appsecret'), 'wx_appsecret',$pay_list['wx_appsecret'], 'text');
showsetting(lang('plugin/ck8_vip', 'wx_mchid'), 'wx_mchid', $pay_list['wx_mchid'], 'text');
showsetting(lang('plugin/ck8_vip', 'wx_apikey'), 'wx_apikey', $pay_list['wx_apikey'], 'text');

showtableheader(lang('plugin/ck8_vip', 'wxapptitle'));
showsetting(lang('plugin/ck8_vip', 'wxapp_appid'), 'wxapp_appid', $pay_list['wxapp_appid'], 'text');
showsetting(lang('plugin/ck8_vip', 'wxapp_mch_id'), 'wxapp_mch_id',$pay_list['wxapp_mch_id'], 'text');
showsetting(lang('plugin/ck8_vip', 'wxapp_key'), 'wxapp_key', $pay_list['wxapp_key'], 'text');

showtableheader(lang('plugin/ck8_vip', 'magappxtitle'));
showsetting(lang('plugin/ck8_vip', 'magappxsecret'), 'magappxsecret', $pay_list['magappxsecret'], 'text');
showsetting(lang('plugin/ck8_vip', 'magappdomain'), 'magappdomain',$pay_list['magappdomain'], 'text');

showsubmit('submit',lang('plugin/ck8_vip', 'adds'));
showtablefooter();/*dis'.'m.tao'.'bao.com*/
showformfooter();/*Dism��taobao��com*/
?>