<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/ck8_vip/function.php')) {
	@include_once DISCUZ_ROOT.'./source/plugin/ck8_vip/function.php';
}
VerifyState('ck8_vip.plugin');
$act = daddslashes($_GET['act']);
$group = DB::fetch_all("SELECT groupid,grouptitle FROM ".DB::table('common_usergroup')." WHERE type='special'");
if (!$act) {
	$perpage = 20;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage-1)*$perpage;
	$count = C::t('#ck8_vip#ck8_product_list')->get_viplist_count();
	$mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=ck8_vip&pmod=admin_product";
	$multipage = multi($count, $perpage,$curpage,$mpurl, 0, 5);
	$vip_list = C::t('#ck8_vip#ck8_product_list')->get_viplist($start,$perpage);
	if (!$count){
		cpmsg(lang('plugin/ck8_vip', 'error_lists'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=ck8_vip&pmod=admin_product&act=add', 'succeed');
	}
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=ck8_vip&pmod=admin_product&act=del','enctype');
	showtableheader(lang('plugin/ck8_vip', 'vip_compile_list'));
		showtablerow('',array(),array(
			'<input type="checkbox" name="chkall" class="checkbox" onclick="checkall(this.form,\'delete\')" />'.lang('plugin/ck8_vip', 'full'),
			'ID',
			lang('plugin/ck8_vip', 'vip_name'),
			lang('plugin/ck8_vip', 'vip_group'),
			lang('plugin/ck8_vip', 'vip_timep'),
			lang('plugin/ck8_vip', 'vip_prime').'/'.lang('plugin/ck8_vip', 'vip_price'),
			lang('plugin/ck8_vip', 'vip_credits_price').'/'.lang('plugin/ck8_vip', 'credits_type'),
			lang('plugin/ck8_vip', 'vip_credits_presentp').'/'.lang('plugin/ck8_vip', 'credits_type'),
			lang('plugin/ck8_vip', 'vip_present_datep'),
			lang('plugin/ck8_vip', 'vip_restrict_amount'),
			lang('plugin/ck8_vip', 'vip_discount_valuep'),
			lang('plugin/ck8_vip', 'vip_recommendp'),
			lang('plugin/ck8_vip', 'operate')
		));
		foreach ($vip_list as $v) {
			$grouplist = C::t('common_usergroup')->fetch($v['vip_group']);
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				'<input class="checkbox" type="checkbox" name="delete['.$v['vip_id'].']" value="' .$v['vip_id'].'">',
				$v['vip_id'],
				$v['vip_name'],
				$grouplist['grouptitle'],
				$v['vip_time'],
				$v['vip_prime'].'/'.$v['vip_price'],
				$v['vip_credits_price'].'/'.$_G['setting']['extcredits'][$v['vip_credits_type']]['title'],
				$v['vip_credits_present'].'/'.$_G['setting']['extcredits'][$v['vip_credits_present_type']]['title'],
				$v['vip_present_date'],
				$v['vip_restrict_amount'],
				$v['vip_discount_value'],
				$vip_recommend = $v['vip_recommend'] ? lang('plugin/ck8_vip', 'vip_yes') : lang('plugin/ck8_vip', 'vip_no'),
				'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do=$pluginid&identifier=ck8_vip&pmod=admin_product&act=edit&vip_id='.$v['vip_id'].'">'.lang('plugin/ck8_vip', 'alter').'</a>'
			));
		}
		$addt = '<input type="button" class="btn" onclick="location.href=\'' . ADMINSCRIPT . '?action=plugins&operation=config&do='.$pluginid. '&identifier=ck8_vip&pmod=admin_product&act=add\'" value="'.lang('plugin/ck8_vip', 'addt').'" />';
		showsubmit('submit', lang('plugin/ck8_vip', 'dels'), '',$addt, $multipage);//ɾ�� ->���� ->��ҳ
	showtablefooter();/*dis'.'m.tao'.'bao.com*/
	showformfooter();/*Dism��taobao��com*/
}else if($act == 'add'){//����
    if (submitcheck('submit')){
        $vip_data = array();
        $vip_data['vip_name'] = daddslashes($_POST['vip_name']);
        $vip_data['vip_group'] = intval($_POST['vip_group']);
		$vip_data['vip_time'] = intval($_POST['vip_time']);
		$vip_data['vip_prime'] = floatval($_POST['vip_prime']);
		$vip_data['vip_price'] = floatval($_POST['vip_price']);
		$vip_data['vip_credits_price'] = intval($_POST['vip_credits_price']);
		$vip_data['vip_credits_type'] = intval($_POST['vip_credits_type']);
		$vip_data['vip_present_open'] = intval($_POST['vip_present_open']);
		$vip_data['vip_credits_present'] = intval($_POST['vip_credits_present']);
		$vip_data['vip_credits_present_type'] = intval($_POST['vip_credits_present_type']);
		$vip_data['vip_present_date'] = intval($_POST['vip_present_date']);
		$vip_data['vip_restrict_group'] = serialize(daddslashes($_POST['vip_restrict_group']));
		$vip_data['vip_restrict_amount'] = intval($_POST['vip_restrict_amount']);
		$vip_data['vip_discount'] = intval($_POST['vip_discount']);
		$vip_data['vip_discount_value'] = floatval($_POST['vip_discount_value']);
		$vip_data['vip_discount_group'] = serialize(daddslashes($_POST['vip_discount_group']));
		$vip_data['vip_html'] = $_POST['vip_html'];
		$vip_data['vip_recommend'] = intval($_POST['vip_recommend']);
		$vip_data['vip_dateline'] = time();
        C::t('#ck8_vip#ck8_product_list')->insert($vip_data);
        cpmsg(lang('plugin/ck8_vip', 'bcok'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=ck8_vip&pmod=admin_product', 'succeed');
	}else{
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=ck8_vip&pmod=admin_product&act=add', 'enctype');
        showtableheader(lang('plugin/ck8_vip', 'vip_compile_add'));
			showsetting(lang('plugin/ck8_vip', 'vip_name'), 'vip_name','', 'text', '', '',lang('plugin/ck8_vip', 'vip_names'));
		    showsetting(lang('plugin/ck8_vip', 'vip_group'), array('vip_group',$group), '', 'select','','',lang('plugin/ck8_vip', 'vip_groups'));
			showsetting(lang('plugin/ck8_vip', 'vip_time'), 'vip_time','', 'text', '', '',lang('plugin/ck8_vip', 'vip_times'));
			showsetting(lang('plugin/ck8_vip', 'vip_prime'), 'vip_prime','', 'text', '', '',lang('plugin/ck8_vip', 'vip_primes'));
			showsetting(lang('plugin/ck8_vip', 'vip_price'), 'vip_price','', 'text', '', '',lang('plugin/ck8_vip', 'vip_prices'));
			showsetting(lang('plugin/ck8_vip', 'vip_credits_price'), 'vip_credits_price','', 'text', '', '',lang('plugin/ck8_vip', 'vip_credits_prices'));
			showsetting(lang('plugin/ck8_vip', 'vip_credits_type'), 'vip_credits_type','', '<select name="vip_credits_type" style="width:80px">'.get_extcredits_selected().'</select>', '', '',lang('plugin/ck8_vip', 'vip_credits_types'));
			showsetting(lang('plugin/ck8_vip', 'vip_present_open'), 'vip_present_open','', 'radio', '', '',lang('plugin/ck8_vip', 'vip_present_opens'));
			showsetting(lang('plugin/ck8_vip', 'vip_credits_present'), 'vip_credits_present','', 'text', '', '',lang('plugin/ck8_vip', 'vip_credits_presents'));
			showsetting(lang('plugin/ck8_vip', 'vip_credits_present_type'), 'vip_credits_present_type','', '<select name="vip_credits_present_type" style="width:80px">'.get_extcredits_selected().'</select>', '', '',lang('plugin/ck8_vip', 'vip_credits_present_types'));
			showsetting(lang('plugin/ck8_vip', 'vip_present_date'), 'vip_present_date','', 'text', '', '',lang('plugin/ck8_vip', 'vip_present_dates'));
			showsetting(lang('plugin/ck8_vip', 'vip_restrict_group'), 'vip_restrict_group', '', '<select name="vip_restrict_group[]"  multiple="multiple" size="10">'.get_group_selected().'</select><td class="vtop tips2" s="1">'.lang('plugin/ck8_vip','vip_restrict_groups').'</td>');
			showsetting(lang('plugin/ck8_vip', 'vip_restrict_amount'), 'vip_restrict_amount','', 'text', '', '',lang('plugin/ck8_vip', 'vip_restrict_amounts'));
			showsetting(lang('plugin/ck8_vip', 'vip_discount'), 'vip_discount','', 'radio', '', '',lang('plugin/ck8_vip', 'vip_discounts'));
			showsetting(lang('plugin/ck8_vip', 'vip_discount_value'), 'vip_discount_value','', 'text', '', '',lang('plugin/ck8_vip', 'vip_discount_values'));
			showsetting(lang('plugin/ck8_vip', 'vip_discount_group'), 'vip_discount_group', '', '<select name="vip_discount_group[]"  multiple="multiple" size="10">'.get_group_selected().'</select><td class="vtop tips2" s="1">'.lang('plugin/ck8_vip','vip_discount_groups').'</td>');
			showsetting(lang('plugin/ck8_vip', 'vip_html'), 'vip_html','', 'textarea', '', '',lang('plugin/ck8_vip', 'vip_htmls'));
			showsetting(lang('plugin/ck8_vip', 'vip_recommend'), 'vip_recommend','', 'radio', '', '');
        showsubmit('submit');
        showtablefooter();/*dis'.'m.tao'.'bao.com*/
        showformfooter();/*Dism��taobao��com*/
	}
}else if ($act == 'edit'){//�༭
    if (submitcheck('submit')){
        $vip_data = array();
        $vip_data['vip_name'] = daddslashes($_POST['vip_name']);
        $vip_data['vip_group'] = intval($_POST['vip_group']);
		$vip_data['vip_time'] = intval($_POST['vip_time']);
		$vip_data['vip_prime'] = floatval($_POST['vip_prime']);
		$vip_data['vip_price'] = floatval($_POST['vip_price']);
		$vip_data['vip_credits_price'] = intval($_POST['vip_credits_price']);
		$vip_data['vip_credits_type'] = intval($_POST['vip_credits_type']);
		$vip_data['vip_present_open'] = intval($_POST['vip_present_open']);
		$vip_data['vip_credits_present'] = intval($_POST['vip_credits_present']);
		$vip_data['vip_credits_present_type'] = intval($_POST['vip_credits_present_type']);
		$vip_data['vip_present_date'] = intval($_POST['vip_present_date']);
		$vip_data['vip_restrict_group'] = serialize(daddslashes($_POST['vip_restrict_group']));
		$vip_data['vip_restrict_amount'] = intval($_POST['vip_restrict_amount']);
		$vip_data['vip_discount'] = intval($_POST['vip_discount']);
		$vip_data['vip_discount_value'] = floatval($_POST['vip_discount_value']);
		$vip_data['vip_discount_group'] = serialize(daddslashes($_POST['vip_discount_group']));
		$vip_data['vip_html'] = $_POST['vip_html'];
		$vip_data['vip_recommend'] = intval($_POST['vip_recommend']);
		$vip_data['vip_dateline'] = time();
		C::t('#ck8_vip#ck8_product_list')->update($vip_data, array('vip_id' => intval($_POST['vip_id'])));
        cpmsg(lang('plugin/ck8_vip', 'editok'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=ck8_vip&pmod=admin_product', 'succeed');
	}else{
		$vip_id = intval($_GET['vip_id']);
        $vip_list = C::t('#ck8_vip#ck8_product_list')->get_viplist_first($vip_id);
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=ck8_vip&pmod=admin_product&act=edit', 'enctype');
		echo '<input type="hidden" name="vip_id" value="'.$vip_list['vip_id'].'"/>';
        showtableheader(lang('plugin/ck8_vip', 'vip_compile'));
			showsetting(lang('plugin/ck8_vip', 'vip_name'), 'vip_name',$vip_list['vip_name'], 'text', '', '',lang('plugin/ck8_vip', 'vip_names'));
		    showsetting(lang('plugin/ck8_vip', 'vip_group'), array('vip_group',$group), $vip_list['vip_group'], 'select','','',lang('plugin/ck8_vip', 'vip_groups'));
			showsetting(lang('plugin/ck8_vip', 'vip_time'), 'vip_time',$vip_list['vip_time'], 'text', '', '',lang('plugin/ck8_vip', 'vip_times'));
			showsetting(lang('plugin/ck8_vip', 'vip_prime'), 'vip_prime',$vip_list['vip_prime'], 'text', '', '',lang('plugin/ck8_vip', 'vip_primes'));
			showsetting(lang('plugin/ck8_vip', 'vip_price'), 'vip_price',$vip_list['vip_price'], 'text', '', '',lang('plugin/ck8_vip', 'vip_prices'));
			showsetting(lang('plugin/ck8_vip', 'vip_credits_price'), 'vip_credits_price',$vip_list['vip_credits_price'], 'text', '', '',lang('plugin/ck8_vip', 'vip_credits_prices'));
			showsetting(lang('plugin/ck8_vip', 'vip_credits_type'), 'vip_credits_type','', '<select name="vip_credits_type" style="width:80px">'.get_extcredits_selected($vip_list['vip_credits_type']).'</select>', '', '',lang('plugin/ck8_vip', 'vip_credits_types'));
			showsetting(lang('plugin/ck8_vip', 'vip_present_open'), 'vip_present_open',$vip_list['vip_present_open'], 'radio', '', '',lang('plugin/ck8_vip', 'vip_present_opens'));
			showsetting(lang('plugin/ck8_vip', 'vip_credits_present'), 'vip_credits_present',$vip_list['vip_credits_present'], 'text', '', '',lang('plugin/ck8_vip', 'vip_credits_presents'));
			showsetting(lang('plugin/ck8_vip', 'vip_credits_present_type'), 'vip_credits_present_type','', '<select name="vip_credits_present_type" style="width:80px">'.get_extcredits_selected($vip_list['vip_credits_present_type']).'</select>', '', '',lang('plugin/ck8_vip', 'vip_credits_present_types'));
			showsetting(lang('plugin/ck8_vip', 'vip_present_date'), 'vip_present_date',$vip_list['vip_present_date'], 'text', '', '',lang('plugin/ck8_vip', 'vip_present_dates'));
			showsetting(lang('plugin/ck8_vip', 'vip_restrict_group'), 'vip_restrict_group', '', '<select name="vip_restrict_group[]"  multiple="multiple" size="10">'.get_group_selected($vip_list['vip_restrict_group']).'</select><td class="vtop tips2" s="1">'.lang('plugin/ck8_vip','vip_restrict_groups').'</td>');
			showsetting(lang('plugin/ck8_vip', 'vip_restrict_amount'),'vip_restrict_amount',$vip_list['vip_restrict_amount'], 'text', '', '',lang('plugin/ck8_vip', 'vip_restrict_amounts'));
			showsetting(lang('plugin/ck8_vip', 'vip_discount'), 'vip_discount',$vip_list['vip_discount'], 'radio', '', '',lang('plugin/ck8_vip', 'vip_discounts'));
			showsetting(lang('plugin/ck8_vip', 'vip_discount_value'),'vip_discount_value',$vip_list['vip_discount_value'], 'text', '', '',lang('plugin/ck8_vip', 'vip_discount_values'));
			showsetting(lang('plugin/ck8_vip', 'vip_discount_group'), 'vip_discount_group','','<select name="vip_discount_group[]"  multiple="multiple" size="10">'.get_group_selected($vip_list['vip_discount_group']).'</select><td class="vtop tips2" s="1">'.lang('plugin/ck8_vip','vip_discount_groups').'</td>');
			showsetting(lang('plugin/ck8_vip', 'vip_html'), 'vip_html',$vip_list['vip_html'], 'textarea', '', '',lang('plugin/ck8_vip', 'vip_htmls'));
			showsetting(lang('plugin/ck8_vip', 'vip_recommend'), 'vip_recommend',$vip_list['vip_recommend'], 'radio', '', '');
        showsubmit('submit');
        showtablefooter();/*dis'.'m.tao'.'bao.com*/
        showformfooter();/*Dism��taobao��com*/
	}
}else if ($act == 'del'){//ɾ��
    if (submitcheck('submit')){
		if (empty($_POST['delete'])){
			cpmsg(lang('plugin/ck8_vip', 'error_list'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=ck8_vip&pmod=admin_product', 'succeed');
		}else{
			foreach ($_POST['delete'] as $del){
				C::t('#ck8_vip#ck8_product_list')->delete(array('vip_id' => $del));
			}
			cpmsg(lang('plugin/ck8_vip','delok'),'action=plugins&operation=config&do='.$pluginid.'&identifier=ck8_vip&pmod=admin_product', 'succeed');
		}
    }
}
//From: Dism_taobao-com
?>