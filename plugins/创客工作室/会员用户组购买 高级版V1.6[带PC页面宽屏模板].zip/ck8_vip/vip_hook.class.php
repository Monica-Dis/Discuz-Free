<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(file_exists(DISCUZ_ROOT.'./source/plugin/ck8_vip/function.php')){
    @include_once DISCUZ_ROOT.'./source/plugin/ck8_vip/function.php';
}

class plugin_ck8_vip {

	function common(){
		global $_G;
		if($_G['uid'] && CURSCRIPT == 'home' && CURMODULE =='spacecp' && $_GET['ac'] =='usergroup' && $_GET['do'] == 'expiry'){
			$config = vip_config();
			$groupidlists = CeckUserGorup($_G['uid']);
			$new_groupid = '';
			foreach($groupidlists['group_list'] as $grouplist){
				if($grouplist['groupid_time'] && $grouplist['groupid_time'] > TIMESTAMP){
					$new_groupid = $grouplist['groupid'];
					break;
				}
			}
			if($new_groupid == ''){
				if($groupidlists['groupid_main']['groupid']){
					$new_groupid = $groupidlists['groupid_main']['groupid'];
				}else{
					foreach($groupidlists['group_list'] as $grouplist){
						if(!in_array($grouplist['groupid'], $groupidlists['groupidarr'])){
							$new_groupid = $grouplist['groupid'];
							break;
						}
					}
				}
			}

			if($new_groupid != $_G['groupid']){
				$result = GroupSwitch($new_groupid,$_G['uid']);
				if($result['code'] == 1) {
					showmessage(lang('plugin/ck8_vip', 'operation3'), $_G['siteurl']);
				}
			}
		}
	}

	function global_footer(){
		global $_G;
        $config = vip_config();
		if($_G['uid'] && $config['ck8_vipRemind']){
			$remind_expired = getcookie('remind_expired');
			$groupidlist = CeckUserGorup($_G['uid']);
			if(!$remind_expired && $groupidlist['effectiveMsg'] && $groupidlist['effectiveMsg']['effective_days'] < $config['ck8_vipRemind'] && $_GET['do'] != 'expiry'){
				dsetcookie('remind_expired', '1', $config['ck8_vipRemind_time']);
				if(in_array('ck8_notice', $_G['setting']['plugins']['available'])){
					$newnote = lang('plugin/ck8_vip', 'vip_past');
					$url = $_G['siteurl'].'plugin.php?id=ck8_vip';
					vip_MsgWxSend($_G['uid'], 'vip_past', $newnote,$url,false);
				}
				return '<script type="text/javascript">showWindow(\'ck8_expired\',\'plugin.php?id=ck8_vip:expired\');</script>';
			}
		}
	}
}

class mobileplugin_ck8_vip extends plugin_ck8_vip {

	function global_footer_mobile(){
		global $_G;
        $config = vip_config();
		if($_G['uid'] && $config['ck8_vipRemind']){
			$remind_expired = getcookie('remind_expired');
			$groupidlist = CeckUserGorup($_G['uid']);
			if(!$remind_expired && $groupidlist['effectiveMsg'] && $groupidlist['effectiveMsg']['effective_days'] < $config['ck8_vipRemind'] && $_GET['do'] != 'expiry'){
				dsetcookie('remind_expired', '1', $config['ck8_vipRemind_time']);
				if(in_array('ck8_notice', $_G['setting']['plugins']['available'])){
					$newnote = lang('plugin/ck8_vip', 'vip_past');
					$url = $_G['siteurl'].'plugin.php?id=ck8_vip';
					vip_MsgWxSend($_G['uid'], 'vip_past', $newnote,$url,false);
				}
				include template('ck8_vip:return');
				return $return;
			}
		}
	}
}