<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_ck8_payrecord_log extends discuz_table{
    public function __construct() {
        $this->_table = 'ck8_payrecord_log';
        $this->_pk = 'log_id';
        parent::__construct();
    }

    public function get_payrecord_log_count($where = null){
        $sql = "SELECT count(*) as count FROM %t WHERE 1";
        $condition[] = $this->_table;
        if($where['pay_status']){     
            $sql .=" AND pay_status=%d ";
            $condition[] = $where['pay_status'];
        }
		if($where['vip_id']){
            $sql .=" AND vip_id=%d ";
            $condition[] = $where['vip_id'];
        }
		if($where['pay_pyte']){
            $sql .=" AND pay_pyte=%s ";
            $condition[] = $where['pay_pyte'];
        }
		if($where['deal_pyte']){
            $sql .=" AND deal_pyte=%s ";
            $condition[] = $where['deal_pyte'];
        }
		if($where['deal_pyte_no']){
            $sql .=" AND deal_pyte!=%s ";
            $condition[] = $where['deal_pyte_no'];
        }
		if($where['out_trade_no']){
            $sql .=" AND out_trade_no=%s ";
            $condition[] = $where['out_trade_no'];
        }
		if($where['uid']){
            $sql .=" AND uid=%d ";
            $condition[] = $where['uid'];
        }
		if($where['groupid_new']){
            $sql .=" AND groupid_new=%d ";
            $condition[] = $where['groupid_new'];
        }
		if($where['dateline']){
            $sql .=" AND dateline>%d ";
            $condition[] = $where['dateline'];
        }
		if($where['dateline2']){
            $sql .=" AND dateline<%d ";
            $condition[] = $where['dateline2'];
        }
        $count = DB::fetch_first($sql,$condition);
        return $count['count'];
    }

	public function get_payrecord_log_list($start,$size,$where=null,$ORDER='ORDER BY dateline DESC LIMIT %d,%d'){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if($where['pay_status']){
			$sql .=" AND pay_status=%d ";
			$condition[] = $where['pay_status'];
		}
		if($where['vip_id']){
            $sql .=" AND vip_id=%d ";
            $condition[] = $where['vip_id'];
        }
		if($where['pay_pyte']){
            $sql .=" AND pay_pyte=%s ";
            $condition[] = $where['pay_pyte'];
        }
		if($where['deal_pyte']){
            $sql .=" AND deal_pyte=%s ";
            $condition[] = $where['deal_pyte'];
        }
		if($where['deal_pyte_no']){
            $sql .=" AND deal_pyte!=%s ";
            $condition[] = $where['deal_pyte_no'];
        }
		if($where['out_trade_no']){
            $sql .=" AND out_trade_no=%s ";
            $condition[] = $where['out_trade_no'];
        }
		if($where['uid']){
            $sql .=" AND uid=%d ";
            $condition[] = $where['uid'];
        }
		if($where['groupid_new']){
            $sql .=" AND groupid_new=%d ";
            $condition[] = $where['groupid_new'];
        }
		if($where['dateline']){
            $sql .=" AND dateline>%d ";
            $condition[] = $where['dateline'];
        }
		if($where['dateline2']){
            $sql .=" AND dateline<%d ";
            $condition[] = $where['dateline2'];
        }
		$sql .= " $ORDER ";
		$condition[] = $start;
		$condition[] = $size;
		return DB::fetch_all($sql,$condition);
	}

    public function insert($data){
        return DB::insert($this->_table,$data,true);
    }
	
    public function update($data,$condition){
        return DB::update($this->_table,$data,$condition,true);
    }
	
    public function delete($condition){
        return DB::delete($this->_table, $condition);
    }
	
	public function get_payrecord_log_first($where){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if($where['pay_status']){
			$sql .=" AND pay_status=%d ";
			$condition[] = $where['pay_status'];
		}
		if($where['vip_id']){
            $sql .=" AND vip_id=%d ";
            $condition[] = $where['vip_id'];
        }
		if($where['pay_pyte']){
            $sql .=" AND pay_pyte=%s ";
            $condition[] = $where['pay_pyte'];
        }
		if($where['deal_pyte']){
            $sql .=" AND deal_pyte=%s ";
            $condition[] = $where['deal_pyte'];
        }
		if($where['out_trade_no']){
            $sql .=" AND out_trade_no=%s ";
            $condition[] = $where['out_trade_no'];
        }
		if($where['uid']){
            $sql .=" AND uid=%d ";
            $condition[] = $where['uid'];
        }
		if($where['deal_pyte_no']){
            $sql .=" AND deal_pyte!=%s ";
            $condition[] = $where['deal_pyte_no'];
        }
		if($where['groupid_new']){
            $sql .=" AND groupid_new=%d ";
            $condition[] = $where['groupid_new'];
        }
		return DB::fetch_first($sql,$condition);
	}
}
//From: Dism_taobao-com
?>