<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function GetPluginList($identifier){
	if(!$identifier){return false;}
	$pluginarr = DB::fetch_first('SELECT * FROM %t WHERE identifier=%s',array('common_plugin',$identifier));
	return $pluginarr;
}

function creation_Pay($orderno,$source, $describe, $p_type, $money, $notify_url='', $jmurl='', $return_url='',$p_numbered=''){
	global $_G;
	$data = array();
	$data['p_number'] = $orderno;
	$data['p_source'] = $source;
	$data['p_describe'] = $describe;
	$data['p_type'] = dintval($p_type);
	$data['p_uid'] = $_G['uid'];
	$data['p_money'] = $money;
	$data['p_notify_url'] = $notify_url;
	$data['p_return_url'] = $return_url;
	$data['p_jmurl'] = $jmurl;
    $data['p_state'] = 1;
	$data['p_dateline'] = TIMESTAMP;
	if(!empty($p_numbered)){
		$data['p_state'] = 2;
		$data['p_date'] = TIMESTAMP;
		$data['p_numbered'] = $p_numbered;
	}
	$p_list = C::t('#ck8_pay#ck8_pay_log')->get_pay_log_first(array('p_uid' => $_G['uid'],'p_state' => 1));
	if($p_list){
		C::t('#ck8_pay#ck8_pay_log')->update($data,array('p_id'=> $p_list['p_id']));
		return $p_list['p_id'];
	}else{
		$p_id = C::t('#ck8_pay#ck8_pay_log')->insert($data);
		return $p_id;
	}
}

function upPayState($number,$numbered=''){
	if(!empty($number)){
        C::t('#ck8_pay#ck8_pay_log')->update(array('p_state'=> 2, 'p_date' => TIMESTAMP, 'p_numbered' => $numbered),array('p_number'=> $number));
		return true;
    }else{
		return false;
	}
}

function pay_type($type){
	$isFromWeixin = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;
	$isMobile = checkmobile();
	if($type =='wxzf'){
		if($isFromWeixin && $isMobile){
			$type = 4;
		}else if(!$isFromWeixin && $isMobile){
			$type = 5;
		}else{
			$type = 3;
		}
	}else if($type =='zfbzf'){
		if(!$isFromWeixin && $isMobile){
			$type = 2;
		}else{
			$type = 1;
		}
    }
	return $type;
}

function PaymentType($type){
	$type_name ='';
	switch($type){
		case 1:
			$type_name = lang('plugin/ck8_pay','langs022');
			break;
		case 2:
			$type_name = lang('plugin/ck8_pay','langs023');
			break;
		case 3:
			$type_name = lang('plugin/ck8_pay','langs029');
			break;
		case 4:
			$type_name = lang('plugin/ck8_pay','langs024');
			break;
		case 5:
			$type_name = lang('plugin/ck8_pay','langs025');
			break;
		case 6:
			$type_name = lang('plugin/ck8_pay','langs033');
			break;
		case 7:
			$type_name = lang('plugin/ck8_pay','langs034');
			break;
		default:
            $type_name = lang('plugin/ck8_pay','langs035');
	}
	return $type_name;
}

function ck8_pay_select($name, $data, $selected, $initial) {
    $select = "<select name='$name' id='$name'>";
    if ($initial) {
        $select.= "<option value='".$initial[0]."'>".$initial[1]."</option>";
    }
    foreach ($data as $v) {
        $sed = $selected == $v[0] ? 'selected' : '';
        $select.= "<option value='".$v[0]."' $sed>".$v[1]."</option>";
    }
    $select.= "</select>";
    return $select;
}

function pay_https(){
    if(!isset($_SERVER['HTTPS'])) return false;
		if($_SERVER['HTTPS'] === 1){
			return true;
		}else if($_SERVER['HTTPS'] === 'on'){
			return true;
		}else if($_SERVER['SERVER_PORT'] == 443){
			return true;
		}
    return false;
}
//From: Dism_taobao_com
?>