<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/ck8_pay/function.php';

if(!function_exists('curl_version')){
	exit('Please open curl extension');
}

if(empty($_G['cache']['plugin'])){
	loadcache('plugin');
}
$config = $_G['cache']['plugin']['ck8_pay'];

if(!$_G['uid']){
	showmessage(lang('plugin/ck8_pay','langs032'),'member.php?mod=logging&action=login', array(), array('login' => 1));
}

$p_id = dintval($_GET['p_id']);
if(empty($p_id)){
  $urls = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
  $p_id = stristr($urls,'p_id');
  $p_id = str_replace("&mobile=2","",$p_id);
  $p_id = str_replace("p_id","",$p_id);
  $p_id = str_replace("=","",$p_id);
}

if(empty($p_id)){
	showmessage(lang('plugin/ck8_pay','langs031'));
}

$p_list = C::t('#ck8_pay#ck8_pay_log')->get_pay_log_first(array('p_id' => $p_id));
$subject = cutstr($p_list['p_describe'],25);
$subjects = $subject;
if($_G['charset'] == 'gbk'){
	$subject = iconv('gbk','utf-8',$subject);
}

if ($p_list['p_type'] == 1 || $p_list['p_type'] == 2){
    include_once DISCUZ_ROOT.'./source/plugin/ck8_pay/lib/AlipayService.class.php';
	$aliPay = new AlipayService();
	$aliPay->setAppid(trim($config['zfb_appid']));
	$aliPay->setReturnUrl($p_list['p_return_url']);
	$aliPay->setNotifyUrl($p_list['p_notify_url']);
	$aliPay->setRsaPrivateKey(trim($config['zfb_rsaPrivateKey']));
	$aliPay->setTotalFee($p_list['p_money']);
	$aliPay->setOutTradeNo($p_list['p_number']);
	$aliPay->setOrderName($subject);
	$aliPay->signType(trim($config['zfb_rsatype']));
	if($p_list['p_type'] == 2){
		$sHtml = $aliPay->doPayWap();
	}else if($p_list['p_type'] == 1){
		$sHtml = $aliPay->doPayPc();
	}
	echo $sHtml;
	exit;
}

if ($p_list['p_type'] == 3){
	include_once DISCUZ_ROOT.'./source/plugin/ck8_pay/lib/WxpayService.class.php';
	$wxPay = new WxpayService(trim($config['wxzf_mchid']),trim($config['wxzf_appid']),trim($config['wxzf_apiKey']));
	$wxPay->setTotalFee($p_list['p_money']);
	$wxPay->setOutTradeNo($p_list['p_number']);
	$wxPay->setOrderName($subject);
	$wxPay->setNotifyUrl($p_list['p_notify_url']);
	$arr = $wxPay->createJsBizPackagePC(TIMESTAMP);
	if($arr === false){
        showmessage(lang('plugin/ck8_pay','langs031'));
	}
	$hash = random(10);
	$qrsize = 5;
	$dir = 'source/plugin/ck8_pay/cache/';
	$file = $dir.'ck8_pay_'.$hash.'.jpg';
	if(!file_exists($file) || !filesize($file)) {
		dmkdir($dir);
		include_once libfile('class/qrcode','plugin/ck8_pay');
		QRcode::png($arr['code_url'], $file, QR_ECLEVEL_L, $qrsize);
	}
	$url = base64_encode(file_get_contents($file));
	@unlink($file);
	$url = '<img src="data:image/png;base64,'.$url.'" style="width:238px;" class="vm"/>';
	include template('ck8_pay:wxpay');
	exit;
}

if ($p_list['p_type'] == 4){
	$appid = trim($config['wx_appid']);
	include_once DISCUZ_ROOT.'./source/plugin/ck8_pay/lib/WxpayService.class.php';
	$authority='';
	if(!empty($config['wx_authority'])){
		$authority = $config['wx_authority'];
	}
	$codeurl = $_G['siteurl'].'plugin.php?id=ck8_pay:pay_dispose&p_id='.$p_id;
	$wxPay = new WxpayService(trim($config['wxzf_mchid']),trim($config['wxzf_appid']),trim($config['wxzf_apiKey']),trim($config['wxzf_appKey']));
	$openId = $wxPay->GetOpenid($codeurl,$authority);
	if(!$openId){
		showmessage(lang('plugin/ck8_pay','langs036'));
	}

	$wxPay->setTotalFee($p_list['p_money']);
	$wxPay->setOutTradeNo($p_list['p_number']);
	$wxPay->setOrderName($subject);
	$wxPay->setNotifyUrl($p_list['p_notify_url']);
	$jsApiParameters = $wxPay->createJsBizPackageJSAPI($openId,TIMESTAMP);
	if($jsApiParameters === false){
        showmessage(lang('plugin/ck8_pay','langs031'));
	}
	$jsApiParameters = json_encode($jsApiParameters);
	$wxpay=
	'<html>
	<head>
		<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
		<title>'.$subjects.'</title>
		<script type="text/javascript">
			function jsApiCall(){
				WeixinJSBridge.invoke(
					\'getBrandWCPayRequest\',
					'.$jsApiParameters.',
					function(res){
						if(res.err_msg == "get_brand_wcpay_request:ok" ){
	                        location.href="'.$p_list['p_jmurl'].'";
						}else{
							history.back();
						}
					}
				);
			}
			function callpay(){
				if (typeof WeixinJSBridge == "undefined"){
					if( document.addEventListener ){
						document.addEventListener(\'WeixinJSBridgeReady\', jsApiCall, false);
					}else if (document.attachEvent){
						document.attachEvent(\'WeixinJSBridgeReady\', jsApiCall);
						document.attachEvent(\'onWeixinJSBridgeReady\', jsApiCall);
					}
				}else{
					jsApiCall();
				}
			}
			window.onload=function(){callpay();}
		</script>
	</head>
	</html>';
	echo $wxpay;exit;
}

if ($p_list['p_type'] == 5){
	include_once DISCUZ_ROOT.'./source/plugin/ck8_pay/lib/WxpayService.class.php';
	$wxPay = new WxpayService(trim($config['wxzf_mchid']),trim($config['wxzf_appid']),trim($config['wxzf_apiKey']));
	$wxPay->setTotalFee($p_list['p_money']);
	$wxPay->setOutTradeNo($p_list['p_number']);
	$wxPay->setOrderName($subject);
	$wxPay->setNotifyUrl($p_list['p_notify_url']);
	$wxPay->setWapUrl($_G['siteurl']);
	$wxPay->setWapName($_G['setting']['bbname']);
	$mwebUrl = $wxPay->createJsBizPackageH5();
	if($mwebUrl === false){
        showmessage(lang('plugin/ck8_pay','langs031'));
	}
	dheader("location:$mwebUrl&redirect_url=".urlencode($p_list["p_jmurl"]));
	exit;
}
//From: Dism_taobao_com
?>