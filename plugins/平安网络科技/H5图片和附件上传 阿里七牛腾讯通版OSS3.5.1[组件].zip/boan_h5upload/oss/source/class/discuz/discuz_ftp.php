<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!defined('FTP_ERR_SERVER_DISABLED')) {
    define('FTP_ERR_SERVER_DISABLED', -100);
    define('FTP_ERR_CONFIG_OFF', -101);
    define('FTP_ERR_CONNECT_TO_SERVER', -102);
    define('FTP_ERR_USER_NO_LOGGIN', -103);
    define('FTP_ERR_CHDIR', -104);
    define('FTP_ERR_MKDIR', -105);
    define('FTP_ERR_SOURCE_READ', -106);
    define('FTP_ERR_TARGET_WRITE', -107);
}

class discuz_ftp
{
    
    var $enabled = false;
    var $config = array();
    
    var $func;
    var $connectid;
    var $_error;
    
    function &instance($config = array()) {
        static $object;
        if(empty($object)) {
            $object = new discuz_ftp($config);
        }
        return $object;
    }
    function __construct($config = array()) {
        $this->set_error(0);
        $this->enabled = true;
        
    }
    
    function connect(){
        $this->connectid = 1;
        return $this->connectid;
    }
    
    function __call($name,$arguments){
        return '';
    }
    function set_error($code = 0) {
        $this->_error = $code;
    }
    
    function error() {
        return $this->_error;
    }
    
    function clear($str) {
        return str_replace(array( "\n", "\r", '..'), '', $str);
    }
    function upload($source, $target) {
        global $_G;
        static $attachs;
        $exclude = dunserialize($_G['BOAN_OSSCONFIG']['oss_exclude_forums']);
        if(in_array($_G['fid'], $exclude)){
            $_G['BOAN_OSSCONFIG']['oss_img'] = $_G['BOAN_OSSCONFIG']['oss_att'] = 0;
        }
        if(!$_G['BOAN_OSSCONFIG']['oss_img'] || !$_G['BOAN_OSSCONFIG']['oss_att']){
            $v = debug_backtrace()[2];
            $isimg = false;
            if(!is_array($attachs) && ($v['function'] == 'ftpupload') && !empty($v['args'][0])) {
                foreach(C::t('forum_attachment')->fetch_all($v['args'][0]) as $attach) {
                    $temp  = C::t('forum_attachment_n')->fetch_all($attach['tableid'], $attach['aid'], 0);
                    $attachs[] = $temp[0];
                }
            }
         
            $pos = strpos($source, 'forum');
            if($pos !== FALSE){
                $filename = substr($source, $pos+6);
               foreach ($attachs as $attach){
                   if($filename == $attach['attachment']){
                       $isimg = $attach['isimage'];
                       break;
                   }
               }
               if((!$_G['BOAN_OSSCONFIG']['oss_img'] &&  $isimg > 0) || (!$_G['BOAN_OSSCONFIG']['oss_att'] &&  $isimg <= 0)){
                   return 0;
               }
                
            }
          
        }
    
        if(file_exists($source) && filesize($source) < 20000000){
            $public_arr = array('png','jpg','jpeg','bmp','gif');
            $arr = explode(',', $_G['BOAN_OSSCONFIG']['oss_ext']);
            $public_arr = array_merge($public_arr,$arr);
            $ext = fileext($source);
            return  $_G['BOAN_OSS']->uploadFile($source, OSS_BASEDIR.$target,in_array($ext, $public_arr) ? 'public' : 'private');
        }elseif(file_exists($source)){
            return 0;
        }else{
            
            return 1;
        }
    }
    function ftp_delete($path){
        global $_G;
        $path = discuz_ftp::clear($path);
        $path = OSS_BASEDIR.$path;
        return  $_G['BOAN_OSS']->deleteFile($path);
    }
    function ftp_size($path){
        global $_G;
        if(!$_G['BOAN_OSSCONFIG']['oss_referer']){
            return 0;
        }
        $v = debug_backtrace()[1];
        if($_G['BOAN_OSS']->isObject(OSS_BASEDIR.$path)){
            return 1;
        }elseif(($v['function'] == 'block_updateitem') &&  ($bid = $v['args'][0]) && ($block = $_G['block'][$bid])){
          
            $pic = '';
            foreach(C::t('common_block_item')->fetch_all_by_bid($bid, true) as $value) {
                $item1 =  array('pic' => $value['pic'],'picflag' => 1);
                $item2 = array('pic' => $value['pic'],'picflag' => 2);
                if((block_thumbpath($block,$item1) == $path) || (block_thumbpath($block, $item2) == $path)){
                    $pic = $value['pic'];
                    break;
                }
            }
            $basedir = !$_G['setting']['attachdir'] ? (DISCUZ_ROOT.'./data/attachment/') : $_G['setting']['attachdir'];
            
            if(!empty($pic) && $_G['BOAN_OSS']->isObject(OSS_BASEDIR.$pic)){
                $tmpfilename =$_G['setting']['attachdir'].'temp/'.random(16).substr(strrchr($path, '.'), 0);
                require_once libfile('class/image');
                $image = new image();
                if($_G['BOAN_OSS']->downFile($tmpfilename, OSS_BASEDIR.$pic) && ($image->Thumb($tmpfilename, $path, $block['picwidth'], $block['picheight'], 2)
                    && $this->upload($basedir.$path, $path))){
                        @unlink($tmpfilename);
                        @unlink($basedir.$path);
                        return 1;
                }
                @unlink($tmpfilename);
            }
        }
        return 0;
    }
    function ftp_get($local_file, $remote_file, $mode = 0, $resumepos = 0) {
        global $_G;
        $remote_file = discuz_ftp::clear($remote_file);
        $remote_file = OSS_BASEDIR.$remote_file;
        $local_file = discuz_ftp::clear($local_file);
        return  $_G['BOAN_OSS']->downFile($local_file, $remote_file);
    }
    
    
    
    
    
    
    
}