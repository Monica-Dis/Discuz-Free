<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: extend_thread_image.php 32709 2013-03-04 03:28:55Z zhangjie $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class extend_thread_image extends extend_thread_base {
    
    public function after_newthread() {
        $threadimageaid = 0;
        $threadimage = array();
        $tid = $this->tid;
        $pid = $this->pid;
        $fid = $this->forum['fid'];
        if($this->param['special'] == 4 && $_GET['activityaid']) {
            $threadimageaid = $_GET['activityaid'];
            convertunusedattach($_GET['activityaid'], $tid, $pid);
        }
        $this->mobile_upload();
        if(($this->group['allowpostattach'] || $this->group['allowpostimage']) && ($_GET['attachnew'] || $this->param['sortid'] || !empty($_GET['activityaid']))) {
            updateattach($this->param['displayorder'] == -4 || $this->param['modnewthreads'], $tid, $pid, $_GET['attachnew']);
            if(!$threadimageaid) {
                $threadimage = C::t('forum_attachment_n')->fetch_max_image('tid:'.$tid, 'tid', $tid);
                $threadimageaid = $threadimage['aid'];
            }
        }
        
        $values = array('fid' => $fid, 'tid' => $tid, 'pid' => $pid, 'coverimg' => '');
        $param = array();
        if($this->forum['picstyle']) {
            $this->setthreadcover($pid, 0, $threadimageaid);
        }
        if($threadimageaid) {
            if(!$threadimage) {
                $threadimage = C::t('forum_attachment_n')->fetch('tid:'.$tid, $threadimageaid);
            }
            $threadimage = daddslashes($threadimage);
            C::t('forum_threadimage')->insert(array(
                'tid' => $tid,
                'attachment' => $threadimage['attachment'],
                'remote' => $threadimage['remote'],
            ));
        }
        
        $this->param['values'] = array_merge((array)$this->param['values'], $values);
        $this->param['param'] = array_merge((array)$this->param['param'], $param);
    }
    
    private function setthreadcover($pid, $tid = 0, $aid = 0, $countimg = 0, $imgurl = '') {
        global $_G;
        $cover = 0;
        if(empty($_G['uid']) || !intval($_G['setting']['forumpicstyle']['thumbheight']) || !intval($_G['setting']['forumpicstyle']['thumbwidth'])) {
            return false;
        }
        
        if(($pid || $aid) && empty($countimg)) {
           
            if(empty($imgurl)) {
                if($aid) {
                    $attachtable = 'aid:'.$aid;
                    $attach = C::t('forum_attachment_n')->fetch('aid:'.$aid, $aid, array(1, -1));
                } else {
                    $attachtable = 'pid:'.$pid;
                    $attach = C::t('forum_attachment_n')->fetch_max_image('pid:'.$pid, 'pid', $pid);
                }
                if(!$attach) {
                    return false;
                }
                if(empty($_G['forum']['ismoderator']) && $_G['uid'] != $attach['uid']) {
                    return false;
                }
                $pid = empty($pid) ? $attach['pid'] : $pid;
                $tid = empty($tid) ? $attach['tid'] : $tid;
                $picsource = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachdir']).'forum/'.$attach['attachment'];
            } else {
                return true;
            }
            
            $basedir = !$_G['setting']['attachdir'] ? (DISCUZ_ROOT.'./data/attachment/') : $_G['setting']['attachdir'];
            $coverdir = 'threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/';
            dmkdir($basedir.'./forum/'.$coverdir);
            
            require_once libfile('class/image');
            $image = new image();
            $tmpfilename = '';
            $parse = parse_url($picsource);
            if($parse['path']){
                $parse['path'][0] == '/' && ($parse['path'] = substr($parse['path'], 1));
               
                if($_G['BOAN_OSS']->isObject($parse['path'])){
                    $tmpfilename =$_G['setting']['attachdir'].'temp/'.random(16).substr(strrchr($parse['path'], '.'), 0);
                    if($_G['BOAN_OSS']->downFile($tmpfilename, $parse['path'])){
                        $picsource = $tmpfilename;
                    }
                    
                }
            }
            if($image->Thumb($picsource, 'forum/'.$coverdir.$tid.'.jpg', $_G['setting']['forumpicstyle']['thumbwidth'], $_G['setting']['forumpicstyle']['thumbheight'], 2)) {
                $remote = '';
                if(getglobal('setting/ftp/on')) {
                    if(ftpcmd('upload', 'forum/'.$coverdir.$tid.'.jpg')) {
                        $remote = '-';
                    }
                }
                $cover = C::t('forum_attachment_n')->count_image_by_id($attachtable, 'pid', $pid);
                if($imgurl && empty($cover)) {
                    $cover = 1;
                }
                $cover = $remote.$cover;
            } else {
                !empty($tmpfilename) &&  @unlink($tmpfilename);
                return false;
            }
        }
        !empty($tmpfilename) &&  @unlink($tmpfilename);
        if($countimg) {
            if(empty($cover)) {
                $thread = C::t('forum_thread')->fetch($tid);
                $oldcover = $thread['cover'];
                
                $cover = C::t('forum_attachment_n')->count_image_by_id('tid:'.$tid, 'pid', $pid);
                if($cover) {
                    $cover = $oldcover < 0 ? '-'.$cover : $cover;
                }
            }
        }
        if($cover) {
            C::t('forum_thread')->update($tid, array('cover' => $cover));
            return true;
        }
    }
    
    
    private function mobile_upload() {
        if($_GET['mobile'] == 'yes' && !empty($_FILES['Filedata'])) {
            $forumattachextensions = '';
            if($_G['forum']) {
                $forum = $_G['forum'];
                if($forum['status'] == 3 && $forum['level']) {
                    $levelinfo = C::t('forum_grouplevel')->fetch($forum['level']);
                    if($postpolicy = $levelinfo['postpolicy']) {
                        $postpolicy = dunserialize($postpolicy);
                        $forumattachextensions = $postpolicy['attachextensions'];
                    }
                } else {
                    $forumattachextensions = $forum['attachextensions'];
                }
                if($forumattachextensions) {
                    $_G['group']['attachextensions'] = $forumattachextensions;
                }
            }
            $upload = new forum_upload(1);
            if($upload) {
                $_GET['attachnew'][$upload->getaid] = array('description' => '');
            }
        }
    }
    public function after_newreply() {
        $this->mobile_upload();
        ($this->group['allowpostattach'] || $this->group['allowpostimage']) && ($_GET['attachnew'] || $this->param['special'] == 2 && $_GET['tradeaid']) && updateattach($this->thread['displayorder'] == -4 || $this->param['modnewreplies'], $this->thread['tid'], $this->pid, $_GET['attachnew']);
    }
    
    public function before_editpost($parameters) {
        global $_G;
        $isfirstpost = $this->post['first'] ? 1 : 0;
        $attachupdate = !empty($_GET['delattachop']) || ($this->group['allowpostattach'] || $this->group['allowpostimage']) && ($_GET['attachnew'] || $parameters['special'] == 2 && $_GET['tradeaid'] || $parameters['special'] == 4 && $_GET['activityaid'] || $isfirstpost && $parameters['sortid']);
        
        if($attachupdate) {
            updateattach($this->thread['displayorder'] == -4 || $_G['forum_auditstatuson'], $this->thread['tid'], $this->post['pid'], $_GET['attachnew'], $_GET['attachupdate'], $this->post['authorid']);
        }
        
        
        if($isfirstpost && $attachupdate) {
            if(!$this->param['threadimageaid']) {
                $this->param['threadimage'] = C::t('forum_attachment_n')->fetch_max_image('tid:'.$this->thread['tid'], 'pid', $this->post['pid']);
                $this->param['threadimageaid'] = $this->param['threadimage']['aid'];
            }
            
            if($this->forum['picstyle']) {
                if(empty($this->thread['cover'])) {
                    $this->setthreadcover($this->post['pid'], 0, $this->param['threadimageaid']);
                } else {
                    $this->setthreadcover($this->post['pid'], $this->thread['tid'], 0, 1);
                }
            }
            
            if($this->param['threadimageaid']) {
                if(!$this->param['threadimage']) {
                    $this->param['threadimage'] = C::t('forum_attachment_n')->fetch_max_image('tid:'.$this->thread['tid'], 'tid', $this->thread['tid']);
                }
                C::t('forum_threadimage')->delete_by_tid($this->thread['tid']);
                C::t('forum_threadimage')->insert(array(
                    'tid' => $this->thread['tid'],
                    'attachment' => $this->param['threadimage']['attachment'],
                    'remote' => $this->param['threadimage']['remote'],
                ));
            }
        }
    }
    
    public function before_deletepost($parameters) {
        $thread_attachment = $post_attachment = 0;
        foreach(C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$this->thread['tid'], 'tid', $this->thread['tid']) as $attach) {
            if($attach['pid'] == $this->post['pid']) {
                if($this->thread['displayorder'] >= 0) {
                    $post_attachment++;
                }
                dunlink($attach);
            } else {
                $thread_attachment = 1;
            }
        }
        
        $this->param['updatefieldarr']['attachment'] = array($thread_attachment);
        
        if($post_attachment) {
            C::t('forum_attachment')->delete_by_id('pid', $this->post['pid']);
            DB::query("DELETE FROM ".DB::table(getattachtablebytid($this->thread['tid']))." WHERE pid='".$this->post['pid']."'", 'UNBUFFEREED');
            updatecreditbyaction('postattach', $this->post['authorid'], array(),  '', -$post_attachment);
        }
    }
}
//From: Dism��taobao��com
?>