<?php

namespace Qcloud\Cos\Exception;

// The specified key does not exist.
class NoSuchKeyException extends CosException {}
