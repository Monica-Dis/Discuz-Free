<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class qiniu_oss extends base_oss{
    
    function __construct($oss_id,$oss_key,$oss_bucket,$oss_endpoint,$oss_url){
        self::$oss_server_name = 'qiniu'; 
        $this->oss_client = new Qiniu\Auth($oss_id,$oss_key);
             
        $this->oss_info = array(
            'oss_id' => $oss_id,
            'oss_key' => $oss_key,
            'oss_bucket' => $oss_bucket,
            'oss_endpoint' => $oss_endpoint,
            'oss_url' => $oss_url,
        );
    }
    
    public function  setCors(){
        $bucket = $this->oss_info['oss_bucket'];
        $config = new \Qiniu\Config();
        $bucketManager = new \Qiniu\Storage\BucketManager($this->oss_client, $config);
        $bucketManager->putBucketAccessMode($bucket, 0);
    }
    
    public function  testOSS(){
        $bucket = $this->oss_info['oss_bucket'];
        $token = $this->oss_client->uploadToken($bucket);
        $uploadMgr = new  Qiniu\Storage\UploadManager();
        $status = 2;
        try{
           
            list($ret, $err) = $uploadMgr->put($token, 'test.txt', 'A test of qiniu oss');
            if ($err !== null) {
                throw new Exception($err);
            }
            $status--;
           
            $url =  $this->oss_client->privateDownloadurl($this->oss_info['oss_url'].'test.txt');
            
            $content = $this->check_file($url);
            if($content){
                $status--;
            }
            
        }catch(Exception $e){
           return $status;
        }
        
        return $status;
    }
    
    public function getFilesList($prefix = '',$marker = '',$limit = 100, $delimiter = ''){
        $config = new \Qiniu\Config();
        $bucketManager = new \Qiniu\Storage\BucketManager($this->oss_client, $config);
        $bucket = $this->oss_info['oss_bucket'];
        list($ret, $err) = $bucketManager->listFiles($bucket, $prefix, $marker, $limit, $delimiter);
        if ($err !== null) {
           return 0;
        } else {
            return $ret;
        }
        
    }
    
    public function avthumb($object,$data){
        $bucket = $this->oss_info['oss_bucket'];
        $arr_pos = array(
            'NorthWest',
            'North',
            'NorthEast',
            'West',
            'Center',
            'East',
            'SouthWest',
            'South',
            'SouthEast',
        );
        $arr_fontname = array(
          '黑体',
          '仿宋',
          '楷体',
          '宋体',
          '微软雅黑',
        );
        //$notifyUrl = 'http://218.92.246.146:86/callback.php';
        $notifyUrl = '';
        $force = true;
        $flag = false;
        $config =  new \Qiniu\Config();
        $config->useHTTPS = true;
        $p = new Qiniu\Processing\PersistentFop($this->oss_client, $config);
        $saveasKey = $object;
        $pfop = 'avthumb/mp4/vcodec/libx264/avsmart/1';
        if($data['avthumb_width'] || $data['avthumb_height']){
            $pfop .= "/s/".($data['avthumb_width'] ? $data['avthumb_width'] : '').'x'.($data['avthumb_height'] ? $data['avthumb_height'] : '');
        }
        if(substr($data['avthumb_pic'], 0,4) == 'http'){
            $pfop .= '/wmImage/'.\Qiniu\base64_urlSafeEncode($data['avthumb_pic']).'/wmGravity/'.$arr_pos[$data['avthumb_pic_pos']];
            $flag = true;
        }
        if(!empty($data['avthumb_text'])){
            $pfop .= '/wmText/'.\Qiniu\base64_urlSafeEncode($data['avthumb_text']);
            $pfop .= '/Font/'.\Qiniu\base64_urlSafeEncode($arr_fontname[$data['avthumb_text_fontname']-1]);
            $pfop .= '/wmGravityText/'.$arr_pos[$data['avthumb_text_pos']];
            $pfop .= '/wmFontColor/'.\Qiniu\base64_urlSafeEncode($data['avthumb_text_color']);
            $pfop .= '/wmFontSize/'.$data['avthumb_text_fontsize'];
            $flag = true;
        }
       
        if($flag){
            $pfop .= '/wmOffsetX/'.$data['avthumb_HOffset'];
            $pfop .= '/wmOffsetY/'.$data['avthumb_VOffset'];
        }
        $pfop .= "|saveas/".\Qiniu\base64_urlSafeEncode("$bucket:$saveasKey");
        $url =  $this->oss_info['oss_url'].$object;
        $url .= '?avinfo';
       
        $content = $this->check_file($url);
        $rtn = 0;
        if($data && $content && ($content = json_decode($content)) && $content->streams[0]->codec_name != 'h264'){
            list($id, $err) = $p->execute($bucket, $object, $pfop, '', $notifyUrl, $force);
            if ($err != null) {
                $rtn = 0;
            } else {
                $rtn = $id;
            }
        }
        return $rtn;
    }
    
    public function  RefererConfig(){
      
        return '';
    }
    
    public function getImgStyle($style){
           return $style;
    }
    public function getRemote($url,$object){
        try{
            $bucket = $this->oss_info['oss_bucket'];
            $config = new \Qiniu\Config();
            $bucketManager = new \Qiniu\Storage\BucketManager($this->oss_client, $config);
            list($fileInfo, $err) = $bucketManager->fetch($url,$bucket, $object);
            if ($err) {
                throw new Exception($err->code().'|'.$err->message());
            }
            $err = $bucketManager->changeMime($bucket, $object, 'image/jpeg');
            if ($err) {
                throw new Exception($err->code().'|'.$err->message());
            }
        }catch(Exception $e){
            return 0;
        }
        return 1;
    }
    public function  isObject($object){
       try{
           $bucket = $this->oss_info['oss_bucket'];
           $config = new \Qiniu\Config();
           $bucketManager = new \Qiniu\Storage\BucketManager($this->oss_client, $config);
           list($fileInfo, $err) = $bucketManager->stat($bucket, $object);
           if ($err) {
                 throw new Exception($err->code().'|'.$err->message());
           }
        }catch(Exception $e){
              return 0;
        }
        return 1;
    }
   
    
    public function  renameObject($oldObject,$newObject,$MimeType = null){
        try{
            $bucket = $this->oss_info['oss_bucket'];
            $config = new \Qiniu\Config();
            $bucketManager = new \Qiniu\Storage\BucketManager($this->oss_client, $config);
            $err = $bucketManager->move($bucket,$oldObject,$bucket,$newObject);
            if ($err) {
                throw new Exception($err->code().'|'.$err->message());
            }
            
            $MimeType && $bucketManager->changeMime($bucket,$newObject,$MimeType);
            
        }catch(Exception $e){
            return 0;
        }
        return 1;
    }
    
    public function  uploadData($data, $object,$Acl = null){
        try{
            if(empty($data)){
                return 0;
            }
            $bucket = $this->oss_info['oss_bucket'];
            $token = $this->oss_client->uploadToken($bucket);
            $uploadMgr = new  Qiniu\Storage\UploadManager();
            
            list($ret, $err) = $uploadMgr->put($token, $object,$data);
            if ($err !== null) {
                throw new Exception($err);
            }
            
            empty($Acl) && $Acl = 'private';
            $config = new \Qiniu\Config();
            $bucketManager = new \Qiniu\Storage\BucketManager($this->oss_client, $config);
            
            $arr = array('private' => 1,'public' => 0);
            $bucketManager->changeStatus($bucket, $object,  $arr[$Acl]);
        }catch(Exception $e){
            if(OSS_DEBUG){
                throw(new Exception($e->getMessage()));
            }
            return 0;
        }
        return 1;
    }
    
    
   public function uploadFile($file, $object,$Acl = null){
      try{
          if(!file_exists($file)){
             return 0;
          }
          $bucket = $this->oss_info['oss_bucket'];
          $keyToOverwrite = $object;
          $token = $this->oss_client->uploadToken($bucket,$keyToOverwrite);
          $uploadMgr = new Qiniu\Storage\UploadManager();
          list($ret, $err) = $uploadMgr->putFile($token, $object, $file);
          if ($err) {
              throw new Exception($err->code().'|'.$err->message());
          }
          empty($Acl) && $Acl = 'private';
          $config = new \Qiniu\Config();
          $bucketManager = new \Qiniu\Storage\BucketManager($this->oss_client, $config);
         
          $arr = array('private' => 1,'public' => 0);
          $bucketManager->changeStatus($bucket, $object,  $arr[$Acl]);
         
          
      }catch (Exception $e) {
          if(OSS_DEBUG){
            throw(new Exception($e->getMessage()));
          }
         return 0;
      }
      return 1;
     
   }
   
   public function setAcl($object,$Acl = null){
           
       $config = new \Qiniu\Config();
       $bucketManager = new \Qiniu\Storage\BucketManager($this->oss_client, $config);
       $bucket = $this->oss_info['oss_bucket'];
       empty($Acl) && $Acl = 'private';
       $arr = array('private' => 1,'public' => 0);
       $bucketManager->changeStatus($bucket, $object,  $arr[$Acl]);
       
       return 1;
       
   }
   public function getList($prefix = '', $marker = '', $limit = 1000, $delimiter = ''){
       $bucket = $this->oss_info['oss_bucket'];
       $config = new \Qiniu\Config();
       $bucketManager = new \Qiniu\Storage\BucketManager($this->oss_client);
       list($ret,$err) = $bucketManager->listFiles($bucket,$prefix,$marker,$limit,$delimiter);
       if($err != null){
          var_dump($err); 
       }else{
           
           return $ret;
       }
       
   }
   public function  getPolicy($dir,$object,$length = 1048576000){
       $id= $this->oss_info['oss_id'];         
       $key= $this->oss_info['oss_key'];     
       $host = $this->oss_info['oss_url'];
       $bucket = $this->oss_info['oss_bucket'];
       $expires = 3600;
       $policy = array();
       $keyToOverwrite = $dir.$object;
       $upToken = $this->oss_client->uploadToken($bucket, $keyToOverwrite, $expires, $policy, true);
       $arr = array('token'=>$upToken,'filename'=>$keyToOverwrite);
       return json_encode($arr);
   }
   public function signUrl($object,$filename = '',$e = 3600){
       empty($e) && ($e = 3600);
       $url = '';
       
       $bucket = $this->oss_info['oss_bucket'];
       try{
           $url =  $this->oss_client->privateDownloadurl($this->oss_info['oss_url'].$object,$e);
              if($filename){
                  $filename = rawurldecode(diconv($filename, CHARSET,'utf8'));
                  $url .= '&attname='.$filename;
              }
       }catch (Exception $e) {
           if(OSS_DEBUG){
               throw(new Exception($e->getMessage()));
           }
           return 0;
       }
       return $url;
   }
   
   public function downFile($file,$object){
       try{
           $url =  $this->oss_client->privateDownloadurl($this->oss_info['oss_url'].$object);
           
           $content = $this->check_file($url);
           if(!$content ||  !@file_put_contents($file, $content)){
                   throw new Exception('downfile error!');
           }
       }catch (Exception $e) {
           if(OSS_DEBUG){
               throw(new Exception($e->getMessage()));
           }
           return 0;
       }
       return 1;
   }
   
   
   public function deleteFile($objects){
      try{
          $bucket = $this->oss_info['oss_bucket'];
          $config = new \Qiniu\Config();
          $bucketManager = new \Qiniu\Storage\BucketManager($this->oss_client, $config);
          if(is_array($objects)){
              $ops = $bucketManager->buildBatchDelete($bucket, $objects);
              list($ret, $err) = $bucketManager->batch($ops);
           }else{
               $err = $bucketManager->delete($bucket, $objects);
           }
           if ($err) {
               throw new Exception($err->code().'|'.$err->message());
           }
      }catch (Exception $e) {
         
          return 0;
      }
      return 1;
   }
   
   
   public function  getCallback($object){
       $bucket = $this->oss_info['oss_bucket'];
       $config = new \Qiniu\Config();
       $bucketManager = new \Qiniu\Storage\BucketManager($this->oss_client, $config);
       list($fileInfo, $err) = $bucketManager->stat($bucket, $object);
       $data = array();
       if($err){
           return null;
       }
       $data['object'] = $object;
       $data['size'] = $fileInfo['fsize'];
       $data['height'] = 0;
       $data['width'] = 0;
       if(strpos($fileInfo['mimeType'],'image') !== FALSE){
           $url =  $this->oss_info['oss_url'].$object;
           $url .= '?imageInfo';
           $content = $this->check_file($url);
           if(!$content){
               return $data;
           }
           $content = json_decode($content,true);
           $data['height'] = $content['height'];
           $data['width'] = $content['width'];
       }
      
       return $data;
   }
  
}