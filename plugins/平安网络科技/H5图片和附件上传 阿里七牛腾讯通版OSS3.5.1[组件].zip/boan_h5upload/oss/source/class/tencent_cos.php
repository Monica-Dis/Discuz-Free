<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class tencent_cos extends base_oss{
    
    function __construct($oss_id,$oss_key,$oss_bucket,$oss_endpoint,$oss_url,$bucket_url){
        self::$oss_server_name = 'tencent'; 
       
        $this->oss_client = new Qcloud\Cos\Client(
            array(
                'region' => $oss_endpoint,
                'schema' => 'https', //协议头部，默认为http
                'credentials'=> array(
                    'secretId'  => $oss_id ,
                    'secretKey' => $oss_key)));
  
        $this->oss_info = array(
            'oss_id' => $oss_id,
            'oss_key' => $oss_key,
            'oss_bucket' => $oss_bucket,
            'oss_endpoint' => $oss_endpoint,
            'oss_url' => $oss_url,
            'bucket_url' => $bucket_url,
        );
    }
    
    public function  setCors(){
        try {
            $result = $this->oss_client->putBucketCors(array(
                'Bucket' => $this->oss_info['oss_bucket'], //格式：BucketName-APPID
                'CORSRules' => array(
                    array(
                        'AllowedHeaders' => array('*',),
                        'AllowedMethods' => array('POST', ),
                        'AllowedOrigins' => array('*', ),
                        'ExposeHeaders' => array('*', ),
                    ),
                )
            ));
            
        } catch (Exception $e) {
            if(OSS_DEBUG){
                throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
            }
            return 0;
        }
        return 1;
    }
    
    
    public function  testOSS(){
        $status = 3;
        try{
             $this->oss_client->putObject(array(
                'Bucket' => $this->oss_info['oss_bucket'], 
                'Key' => 'test.txt',
                'Body' => 'A test of Tencent_cos',
                'ACL' => 'public-read',
            )); 
            
            $status--;
            $this->oss_client->getObject(array(
                'Bucket' => $this->oss_info['oss_bucket'], 
                'Key' => 'test.txt',
             )); 
            
            $status--;
            $this->RefererConfig();
            $content = $this->check_file($this->oss_info['oss_url'].'test.txt');
            if($content){
                $status--;
            }
            
        }catch (Exception $e) {
            if(OSS_DEBUG){
                throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
            }
        }
        return $status;
    }
    
    public function  RefererConfig(){
      return '';
    }
    
    public function getImgStyle($style){
        return $style;
    }
    public function  isObject($object){
        try{
            return $this->oss_client->doesObjectExist($this->oss_info['oss_bucket'], $object);
        }catch (Exception $e) {
            if(OSS_DEBUG){
                throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
            }
            return 0;
        }
    }
    
    public function getFilesList($prefix = '',$marker = '',$limit = 100, $delimiter = ''){
        try {
            $result = $this->oss_client->listObjects(array(
                'Bucket' => $this->oss_info['oss_bucket'], 
                'Delimiter' => $delimiter,
                'EncodingType' => 'url',
                'Marker' => $marker,
                'Prefix' => $prefix,
                'MaxKeys' => $limit,
            ));
            $r['marker'] = $result['Marker'];
            $r['items'] = $result['Contents'];
            unset($result);
            foreach ($r['items'] as $k => $r1){
                $r['items'][$k]['key'] = $r1['Key'];
                unset($r['items'][$k]['Key']);
            }
            return $r;
        } catch (\Exception $e) {
            return  0;
        }
    }
    
    
    
    public function  uploadData($data, $object,$Acl = null){
        try{
            $ret = 0;
            if(empty($data)){
                return 0;
            }
            $arr = array('private' => 'private','public' => 'public-read');
            empty($Acl) && $Acl = 'private';
            
            
            $this->oss_client->putObject(array(
                'Bucket' => $this->oss_info['oss_bucket'],
                'Key' => $object,
                'Body' => $data,
                'ACL' => $arr[$Acl],
            )); 
            
            
        }catch(Exception $e){
            if(OSS_DEBUG){
                throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
            }
            return 0;
        }
        return $ret;
    }
    
    
   public function uploadFile($file, $object,$Acl = null){
     try{
          $arr = array('private' => 'private','public' => 'public-read');
          $file = fopen($file, 'rb');
          if ($file) {
              $result = $this->oss_client->Upload(
                  $bucket = $this->oss_info['oss_bucket'],
                  $key = $object,
                  $body = $file);
          }else{
              return 0;
          }
          
          $Acl && ($this->oss_client->putObjectAcl(array(
              'Bucket' => $this->oss_info['oss_bucket'], 
              'Key' => $object, 
              'ACL' => $arr[$Acl])));
     }catch (Exception $e) {
         if(OSS_DEBUG){
             throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
         }
         return 0;
     }
      return 1;
     
   }
   
   public function setAcl($object,$Acl = null){
       try{
           $arr = array('private' => 'private','public' => 'public-read');
           $Acl && ($this->oss_client->putObjectAcl(array(
               'Bucket' => $this->oss_info['oss_bucket'],
               'Key' => $object,
               'ACL' => $arr[$Acl])));
       }catch (Exception $e) {
           if(OSS_DEBUG){
               throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
           }
           return 0;
       }
       return 1;
       
   }
   
   public function  getPolicy($dir,$object,$length = 1048576000){
       require_once  OSS_ROOT.'source/class/tencent/server/qcloud-sts-sdk.php';
       $sts = new STS();
     
       $config = array(
           'url' => 'https://sts.tencentcloudapi.com/',
           'domain' => 'sts.tencentcloudapi.com',
           'proxy' => '',
           'secretId' => $this->oss_info['oss_id'], 
           'secretKey' => $this->oss_info['oss_key'],
           'bucket' =>  $this->oss_info['oss_bucket'], 
           'region' => $this->oss_info['oss_endpoint'], 
           'durationSeconds' => 1800,
           'allowPrefix' => '*',
           'allowActions' => array (
              
               'name/cos:PutObject',
               'name/cos:PostObject',
              
               'name/cos:InitiateMultipartUpload',
               'name/cos:ListMultipartUploads',
               'name/cos:ListParts',
               'name/cos:UploadPart',
               'name/cos:CompleteMultipartUpload'
           )
       );
      
    
       $tempKeys = $sts->getTempKeys($config);
       $tempKeys['dir'] = $dir;
       $tempKeys['object'] = $object;
       header('Content-Type: application/json');
       header('Access-Control-Allow-Origin: http://127.0.0.1'); 
       header('Access-Control-Allow-Headers: origin,accept,content-type');
       return   json_encode($tempKeys);
   }
   
   public function signUrl($object,$filename = '',$e = 3600){
       empty($e) && ($e = 3600);
       $url = '';
       $bucket = $this->oss_info['oss_bucket'];
       $burl = $sourceurl = str_replace('https://', '', $this->oss_info['bucket_url']);
       $burl = $sourceurl = str_replace('http://','', $sourceurl);
       
       $ourl = str_replace('https://', '', $this->oss_info['oss_url']);
       $ourl =  str_replace('http://','', $ourl);
       try{
          if(!empty($filename)){
              $filename = rawurldecode(diconv($filename, CHARSET,'utf8'));
              $meta = $this->oss_client->headObject(array(
                  'Bucket' => $this->oss_info['oss_bucket'], 
                  'Key' => $object,
              )); 
              if(!isset($meta['Metadata']) || !isset($meta['Metadata']['filename']) || $meta['Metadata']['filename']!=$filename){
                  $para = array(
                      'Bucket' => $this->oss_info['oss_bucket'],
                      'Key' => $object,
                      'CopySource' => $sourceurl.$object,
                      'MetadataDirective' => 'Replaced',
                      'Metadata' => array(
                          'filename' => $filename,
                      ),
                      'ContentDisposition' => "attachment; filename=\"$filename\";filename*=utf-8''$filename",);
                  if(fileext($filename) == 'mp4'){
                     $para['ContentType'] = 'video/mp4';
                  }
                  $this->oss_client->copyObject(
                      $para
                  ); 
              }
          }
          $e = intval($e/60);
          $e <=0 && ($e = 1);
          $url =  $this->oss_client->getObjectUrl($this->oss_info['oss_bucket'], $object, "+$e minutes");
          $url = str_replace($burl,$ourl, $url);
       }catch (Exception $e) {
           if(OSS_DEBUG){
               throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
           }
           return 0;
       }
       return $url;
   }
   
   public function  renameObject($oldObject,$newObject,$MimeType = null){
       //Content-type
       $bucket = $this->oss_info['oss_bucket'];
       $sourceurl = str_replace('https://', '', $this->oss_info['bucket_url']);
       $sourceurl = str_replace('http://','', $sourceurl);
       try{
           $rtn = $this->oss_client->copyObject(array(
               'Bucket' => $this->oss_info['oss_bucket'],
               'Key' =>$newObject ,
               'CopySource' => $sourceurl.$oldObject,
           )); 
           
           if($rtn){
               
               $this->oss_client->deleteObject(array(
                   'Bucket' =>$this->oss_info['oss_bucket'],
                   'Key' => $oldObject,
               ));
               
               if(fileext($newObject) == 'mp3' || fileext($newObject) == 'mp4'){
                   $this->setAcl($newObject,'public');
               }
           }
           
       }catch (Exception $e) {
           if(OSS_DEBUG){
               throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
           }
           return 0;
       }
       return 1;
   }
   
   
   public function downFile($file,$object){
       try{
            $this->oss_client->getObject(array(
               'Bucket' => $this->oss_info['oss_bucket'],
               'Key' => $object,
               'SaveAs' => $file));
       }catch (Exception $e) {
           if(OSS_DEBUG){
               throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
           }
           return 0;
       }
       return 1;
   }
   
   
   public function deleteFile($objects){
       try{
           
           if(is_array($objects)){
               $this->oss_client->deleteObjects(array(
                   'Bucket' => $this->oss_info['oss_bucket'],
                   'Objects' =>$objects));
           }else{
              
                $this->oss_client->deleteObject(array(
                   'Bucket' =>$this->oss_info['oss_bucket'],
                   'Key' => $objects,
               ));
           }
       }catch (Exception $e) {
           if(OSS_DEBUG){
               throw(new Qcloud\Cos\Exception\ServiceResponseException($e->getMessage()));
           }
           return 0;
       }
       return 1;
   }
   
   
   public function  getCallback($object){
       if(!$this->oss_client->doesObjectExist($this->oss_info['oss_bucket'], $object)){
           return null;
       }
       $data = array();
       $data['object'] = $object;
       $data1 = $this->oss_client->headObject(array('Bucket' => $this->oss_info['oss_bucket'], 
                                                'Key' => $object));
     
       $data['size'] = $data1['ContentLength'];
      
       $data['height'] = 0;
       $data['width'] = 0;
       if(strpos($data1['ContentType'],'image') !== FALSE){
          
           $url = $this->oss_client->getObjectUrl($this->oss_info['oss_bucket'], $object, '+10 minutes');
           $url .= '&imageInfo';
           $content = $this->check_file($url);
           if(!$content){
               return null;
           }
           $content = json_decode($content,true);
           $data['height'] = $content['height'];
           $data['width'] = $content['width'];
       }
     
       return $data;
   }
  
}