<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function move_forum_attach(&$ossdataconfig){
    global $_G;
    static $step = 0;
    $img_arr = array('png','jpg','jpeg','bmp','gif','PNG','JPG','JPEG','BMP','GIF');
    $arr = explode(',', $_G['BOAN_OSSCONFIG']['oss_ext']);
    $public_arr = array_merge($img_arr,$arr);
    
    if(!$ossdataconfig['status']){
        return 0;
    }
    
    if($ossdataconfig['direction'] == 1){
        $result = C::t('#boan_h5upload#boanh5_attachment')->fetch_by_limit(10,0,$ossdataconfig['date'],$ossdataconfig['ext'],$ossdataconfig['size'],$step);
        $step = 0;
        foreach ($result as $r){
            $filename = $_G['setting']['attachdir'].'forum/'.$r['attachment'];
            $object = OSS_BASEDIR.'forum/'.$r['attachment'];
            if(file_exists($filename) && filesize($filename)){
                $ext = fileext($r['filename']);
                $ext = !empty($ext) ? fileext($r['filename']) : fileext($r['attachment']);
                
                if($_G['BOAN_OSS']->isObject($object) || $_G['BOAN_OSS']->uploadFile($filename, $object,in_array($ext, $public_arr) ? 'public' : 'private')){
                    $r['remote'] = 1;
                    C::t('forum_attachment_n')->update('tid:'. $r['tid'], $r['aid'],$r);
                    $ossdataconfig['isdel'] && @unlink($filename);
                    if($r['isimage']){
                        $picid = C::t('#boan_h5upload#boanh5_home_pic')->fetch_by_filename($r['uid'],2,$r['attachment']);
                        $picid && C::t('#boan_h5upload#boanh5_home_pic')->update_by_remote($picid,3);
                        DB::update('forum_threadimage',array('remote'=>1),DB::field('tid', $r['tid']).' AND '.DB::field('attachment',$r['attachment']));
                        $filename = $_G['setting']['attachdir'].'forum/'.$r['attachment'].'.thumb.jpg';
                        $object = OSS_BASEDIR.'forum/'.$r['attachment'].'.thumb.jpg';
                        $r['thumb'] && file_exists($filename) && filesize($filename) && $_G['BOAN_OSS']->uploadFile($filename, $object,'public');
                        $ossdataconfig['isdel'] && @unlink($filename);
                    }
                    $ossdataconfig['ok_count']++;
                }else{
                    $step ++;
                    $ossdataconfig['error_count']++;
                }
            }else{
                $step++;
                $ossdataconfig['error_count']++;
            }
            $ossdataconfig['current_file'] = $filename;
            $ossdataconfig['last_date'] = time();
            $ossdataconfig['completed_count']++;
        }
        if(!count($result)){
            $result  = C::t('#boan_h5upload#boanh5_thread')->fetch_by_cover(10,0,0);
            foreach ($result as $r){
                $basedir = !$_G['setting']['attachdir'] ? (DISCUZ_ROOT.'./data/attachment/') : $_G['setting']['attachdir'];
                $coverdir = 'threadcover/'.substr(md5($r['tid']), 0, 2).'/'.substr(md5($r['tid']), 2, 2).'/';
                $filename = $basedir.'forum/'.$coverdir.$r['tid'].'.jpg';
                $object = OSS_BASEDIR.'forum/'.$coverdir.$r['tid'].'.jpg';
                if(file_exists($filename) && filesize($filename)){
                    if($_G['BOAN_OSS']->uploadFile($filename, $object,'public')){
                        $ossdataconfig['isdel'] &&  @unlink($filename);
                        $ossdataconfig['ok_count']++;
                    }else{
                        $step ++;
                        $ossdataconfig['error_count']++;
                    }
                }else{
                    $step ++;
                    $ossdataconfig['error_count']++;
                }
                C::t('forum_thread')->update($r['tid'], array('cover' => '-'.$r['cover']));
                
                $ossdataconfig['current_file'] = $filename;
                $ossdataconfig['last_date'] = time();
                $ossdataconfig['completed_count']++;
            }
        }
        
    }else{
        $result = C::t('#boan_h5upload#boanh5_attachment')->fetch_by_limit(10,1,$ossdataconfig['date'],$ossdataconfig['ext'],$ossdataconfig['size'],$step);
        $step = 0;
        
        foreach ($result as $r){
            $filename = $_G['setting']['attachdir'].'forum/'.$r['attachment'];
            $object = OSS_BASEDIR.'forum/'.$r['attachment'];
            if($_G['BOAN_OSS']->isObject($object)){
                dmkdir(dirname($filename));
                if(file_exists($filename) || $_G['BOAN_OSS']->downFile($filename, $object)){
                    $r['remote'] = 0;
                    C::t('forum_attachment_n')->update('tid:'. $r['tid'], $r['aid'],$r);
                    $ossdataconfig['isdel'] && $_G['BOAN_OSS']->deleteFile($object);
                    if($r['isimage']){
                        $filename = $_G['setting']['attachdir'].'forum/'.$r['attachment'].'.thumb.jpg';
                        $object = OSS_BASEDIR.'forum/'.$r['attachment'].'.thumb.jpg';
                        $r['thumb'] && $_G['BOAN_OSS']->isObject($object) && $_G['BOAN_OSS']->downFile($filename, $object);
                        $picid = C::t('#boan_h5upload#boanh5_home_pic')->fetch_by_filename($r['uid'],3,$r['attachment']);
                        $picid && C::t('#boan_h5upload#boanh5_home_pic')->update_by_remote($picid,2);
                        DB::update('forum_threadimage',array('remote'=>0),DB::field('tid', $r['tid']).' AND '.DB::field('attachment',$r['attachment']));
                    }
                    $ossdataconfig['ok_count']++;
                    
                }else{
                    $step++;
                    $ossdataconfig['error_count']++;
                }
                
            }else{
                $step++;
                $ossdataconfig['error_count']++;
            }
            $ossdataconfig['current_file'] = $filename;
            $ossdataconfig['last_date'] = time();
            $ossdataconfig['completed_count']++;
        }
        if(!count($result)){
            $result  = C::t('#boan_h5upload#boanh5_thread')->fetch_by_cover(10,1,0);
            foreach ($result as $r){
                $basedir = !$_G['setting']['attachdir'] ? (DISCUZ_ROOT.'./data/attachment/') : $_G['setting']['attachdir'];
                $coverdir = 'threadcover/'.substr(md5($r['tid']), 0, 2).'/'.substr(md5($r['tid']), 2, 2).'/';
                $filename = $basedir.'forum/'.$coverdir.$r['tid'].'.jpg';
                $object = OSS_BASEDIR.'forum/'.$coverdir.$r['tid'].'.jpg';
                dmkdir(dirname($filename));
                if($_G['BOAN_OSS']->isObject($object)){
                    if($_G['BOAN_OSS']->downFile($filename, $object)){
                        $ossdataconfig['isdel'] && $_G['BOAN_OSS']->deleteFile($object);
                        $ossdataconfig['ok_count']++;
                    }else{
                        $step ++;
                        $ossdataconfig['error_count']++;
                    }
                }else{
                    $step ++;
                    $ossdataconfig['error_count']++;
                }
                C::t('forum_thread')->update($r['tid'], array('cover' => abs($r['cover'])));
                
                $ossdataconfig['current_file'] = $filename;
                $ossdataconfig['last_date'] = time();
                $ossdataconfig['completed_count']++;
            }
        }
    }
    return count($result);
}


function move_portal_attach(&$ossdataconfig){
    global $_G;
    static $step = 0;
    $img_arr = array('png','jpg','jpeg','bmp','gif','PNG','JPG','JPEG','BMP','GIF');
    $arr = explode(',', $_G['BOAN_OSSCONFIG']['oss_ext']);
    $public_arr = array_merge($img_arr,$arr);
    
    if(!$ossdataconfig['status']){
        return 0;
    }
    
    if($ossdataconfig['direction'] == 1){
        $result = C::t('#boan_h5upload#boanh5_portal_attachment')->fetch_by_limit(10,0,$step);
        $step = 0;
        foreach ($result as $r){
            $filename = $_G['setting']['attachdir'].'portal/'.$r['attachment'];
            $object = OSS_BASEDIR.'portal/'.$r['attachment'];
            if(file_exists($filename) &&  filesize($filename)){
                $ext = fileext($r['filename']);
                $ext = !empty($ext) ? fileext($r['filename']) : fileext($r['attachment']);
                
                if($_G['BOAN_OSS']->isObject($object) || $_G['BOAN_OSS']->uploadFile($filename, $object,in_array($ext, $public_arr) ? 'public' : 'private')){
                    C::t('#boan_h5upload#boanh5_portal_attachment')->update_by_attachid($r['attachid'],1);
                    $ossdataconfig['isdel'] &&  @unlink($filename);
                    $ossdataconfig['ok_count']++;
                    $filename = $_G['setting']['attachdir'].'portal/'.$r['attachment'].'.thumb.jpg';
                    $object = OSS_BASEDIR.'portal/'.$r['attachment'].'.thumb.jpg';
                    if($r['thumb'] && file_exists($filename) && filesize($filename)){
                        if($_G['BOAN_OSS']->uploadFile($filename, $object,'public')){
                            $ossdataconfig['isdel'] &&  @unlink($filename);
                        }
                    }
                    
                }else{
                    $step ++;
                    $ossdataconfig['error_count']++;
                }
            }else{
                $step++;
                $ossdataconfig['error_count']++;
            }
            $ossdataconfig['current_file'] = $filename;
            $ossdataconfig['last_date'] = time();
            $ossdataconfig['completed_count']++;
        }
              
    }else{
        $result = C::t('#boan_h5upload#boanh5_portal_attachment')->fetch_by_limit(10,1,$step);
        $step = 0;
        
        foreach ($result as $r){
            $filename = $_G['setting']['attachdir'].'portal/'.$r['attachment'];
            $object = OSS_BASEDIR.'portal/'.$r['attachment'];
            if($_G['BOAN_OSS']->isObject($object)){
                dmkdir(dirname($filename));
                if(file_exists($filename) || $_G['BOAN_OSS']->downFile($filename, $object)){
                    C::t('#boan_h5upload#boanh5_portal_attachment')->update_by_attachid($r['attachid'],0);
                    $ossdataconfig['isdel'] && $_G['BOAN_OSS']->deleteFile($object);
                    $ossdataconfig['ok_count']++;
                    
                    $filename = $_G['setting']['attachdir'].'portal/'.$r['attachment'].'.thumb.jpg';
                    $object = OSS_BASEDIR.'portal/'.$r['attachment'].'.thumb.jpg';
                    if($r['thumb'] && $_G['BOAN_OSS']->isObject($object)){
                        if($_G['BOAN_OSS']->downFile($filename, $object)){
                            $ossdataconfig['isdel'] && $_G['BOAN_OSS']->deleteFile($object);
                        }
                    }
                }else{
                    $step++;
                    $ossdataconfig['error_count']++;
                }
                
            }else{
                $step++;
                $ossdataconfig['error_count']++;
            }
            $ossdataconfig['current_file'] = $filename;
            $ossdataconfig['last_date'] = time();
            $ossdataconfig['completed_count']++;
        }
       
    }
    return count($result);
}
function restore_article_image_link(&$ossdataconfig){
    global $_G;
    static $step = 0;
    if(!$ossdataconfig['status']){
        return 0;
    }
    foreach (($result = C::t('#boan_h5upload#boanh5_portal_attachment')->fetch_by_article_limit(3,$step)) as $artice){
        $flag = false;
        foreach (DB::fetch_all("SELECT * FROM %t WHERE aid = %d AND isimage = 1",array('portal_attachment',$artice['aid']), 'attachid') as $att){
            $matches = array();
            $filepath = $att['remote'] ? $_G['BOAN_OSSCONFIG']['oss_url'].OSS_BASEDIR.'portal/'.$att['attachment'] : 'data/attachment/'.'portal/'.$att['attachment'];
            $pattern = '/src="(.*)"|href="(.*)"/iU';
            preg_match_all($pattern,$artice['content'],$matches);
            foreach (array_merge($matches[1],$matches[2]) as $m){
                if(strpos($m,$att['attachment']) !== FALSE){
                    if($m != $filepath){
                        $artice['content'] = str_replace($m, $filepath, $artice['content']);
                        $flag = true;
                    }
                }
            }
            $at = DB::fetch_first('SELECT aid FROM %t WHERE aid = %d AND pic = %s',array('portal_article_title',$att['aid'],'portal/'.$att['attachment']));
            
            if(count($at) > 0){
                DB::update('portal_article_title', array('remote' => $att['remote']), DB::field('aid',$at['aid']));
            }
        }
        if($flag){
            C::t('portal_article_content')->update_by_aid($artice['aid'],array('content'=>$artice['content']));
        }
        $step ++;
        $ossdataconfig['ok_count']++;
        $ossdataconfig['current_file'] = 'aid:'.$artice['aid'];
        $ossdataconfig['last_date'] = time();
        $ossdataconfig['completed_count']++;
    }
   
    return count($result);
    
}

function move_home_pic(&$ossdataconfig){
    global $_G;
    static $step = 0;
    
    if(!$ossdataconfig['status']){
        return 0;
    }
    if($ossdataconfig['direction'] == 1){
        $result = C::t('#boan_h5upload#boanh5_home_pic')->fetch_by_limit(10,0,$step);
        $step = 0;
        foreach ($result as $r){
            $filename = $_G['setting']['attachdir'].'album/'.$r['filepath'];
            $object = OSS_BASEDIR.'album/'.$r['filepath'];
            if(file_exists($filename) &&  filesize($filename)){
                if($_G['BOAN_OSS']->uploadFile($filename, $object,'public')){
                    
                    C::t('#boan_h5upload#boanh5_home_pic')->update_by_picid($r['picid'],1);
                    $ossdataconfig['isdel'] &&  @unlink($filename);
                    $ossdataconfig['ok_count']++;
                    $filename = $_G['setting']['attachdir'].'album/'.$r['filepath'].'.thumb.jpg';
                    $object = OSS_BASEDIR.'album/'.$r['filepath'].'.thumb.jpg';
                    if($r['thumb'] && file_exists($filename) && filesize($filename)){
                        if($_G['BOAN_OSS']->uploadFile($filename, $object,'public')){
                            $ossdataconfig['isdel'] &&  @unlink($filename);
                        }
                    }
                }else{
                    $step ++;
                    $ossdataconfig['error_count']++;
                }
            }else{
                $step++;
                $ossdataconfig['error_count']++;
            }
            $ossdataconfig['current_file'] = $filename;
            $ossdataconfig['last_date'] = time();
            $ossdataconfig['completed_count']++;
        }
        
        if(!count($result)){
            $result  = C::t('#boan_h5upload#boanh5_home_pic')->fetch_by_cover_limit(10,0);
            foreach ($result as $r){
                $filename = $_G['setting']['attachdir'].'album/'.$r['pic'];
                $object = OSS_BASEDIR.'album/'.$r['pic'];
                if(file_exists($filename) && filesize($filename)){
                    if($_G['BOAN_OSS']->uploadFile($filename, $object,'public')){
                        $ossdataconfig['isdel'] &&  @unlink($filename);
                        $ossdataconfig['ok_count']++;
                    }else{
                        $ossdataconfig['error_count']++;
                    }
                }else{
                    $ossdataconfig['error_count']++;
                }
                C::t('#boan_h5upload#boanh5_home_pic')->update_by_albumid($r['albumid'],2);
                $ossdataconfig['current_file'] = $filename;
                $ossdataconfig['last_date'] = time();
                $ossdataconfig['completed_count']++;
            }
        }
        
    }else{
        $result = C::t('#boan_h5upload#boanh5_home_pic')->fetch_by_limit(10,1,$step);
        $step = 0;
        foreach ($result as $r){
            $filename = $_G['setting']['attachdir'].'album/'.$r['filepath'];
            $object = OSS_BASEDIR.'album/'.$r['filepath'];
            if($_G['BOAN_OSS']->isObject($object)){
                dmkdir(dirname($filename));
                if($_G['BOAN_OSS']->downFile($filename, $object)){
                    C::t('#boan_h5upload#boanh5_home_pic')->update_by_picid($r['picid'],0);
                    $ossdataconfig['isdel'] && $_G['BOAN_OSS']->deleteFile($object);
                    $ossdataconfig['ok_count']++;
                    
                    $filename = $_G['setting']['attachdir'].'album/'.$r['filepath'].'.thumb.jpg';
                    $object = OSS_BASEDIR.'album/'.$r['filepath'].'.thumb.jpg';
                    if($r['thumb'] && $_G['BOAN_OSS']->isObject($object)){
                        if($_G['BOAN_OSS']->downFile($filename, $object)){
                            $ossdataconfig['isdel'] && $_G['BOAN_OSS']->deleteFile($object);
                        }
                    }
                }else{
                    $step++;
                    $ossdataconfig['error_count']++;
                }
                
            }else{
                $step++;
                $ossdataconfig['error_count']++;
            }
            $ossdataconfig['current_file'] = $filename;
            $ossdataconfig['last_date'] = time();
            $ossdataconfig['completed_count']++;
        }
        if(!count($result)){
            $result  = C::t('#boan_h5upload#boanh5_home_pic')->fetch_by_cover_limit(10,1);
            foreach ($result as $r){
                $filename = $_G['setting']['attachdir'].'album/'.$r['pic'];
                $object = OSS_BASEDIR.'album/'.$r['pic'];
                if($_G['BOAN_OSS']->isObject($object)){
                    dmkdir(dirname($filename));
                    if($_G['BOAN_OSS']->downFile($filename, $object)){
                        $ossdataconfig['isdel'] && $_G['BOAN_OSS']->deleteFile($object);
                        $ossdataconfig['ok_count']++;
                      
                    }else{
                        $ossdataconfig['error_count']++;
                    }
                    
                }else{
                    $ossdataconfig['error_count']++;
                }
                C::t('#boan_h5upload#boanh5_home_pic')->update_by_albumid($r['albumid'],1);
                $ossdataconfig['current_file'] = $filename;
                $ossdataconfig['last_date'] = time();
                $ossdataconfig['completed_count']++;
            }
        }
        
    }
    return count($result);
}

function get_avatar_pic($dir,&$filesList,&$limit){
    $file_arr = scandir($dir);
    $del_flag = true;
    foreach($file_arr as $item){
        if($item != ".." && $item != "." && $item != 'index.html'  && $item != 'index.htm'){
            $del_flag = false;
            if(is_dir($dir."/".$item)){
                get_avatar_pic($dir."/".$item,$filesList,$limit);
            }else{
                if($limit <= 0 ){
                    break;
                }
                $filesList[] = $dir."/".$item;
                $limit-- ;
            }
        }
    }
  
}


function move_avatar(&$ossdataconfig){
    global $_G;
    if(!$ossdataconfig['status']){
        return 0;
    }
    if($ossdataconfig['direction'] == 1){
        $result = array();
        $step = 10;
        get_avatar_pic('uc_server/data/avatar', $result, $step);
        foreach ($result as $r){
            $filename = $r;
            $object = substr($filename,strpos($filename,'uc_server'));
            if(file_exists($filename) &&  filesize($filename)){
                if($_G['BOAN_OSS']->uploadFile($filename, $object,'public')){
                    @unlink($filename);
                    $ossdataconfig['ok_count']++;
                    
                }else{
                    $ossdataconfig['error_count']++;
                }
            }else{
                $ossdataconfig['error_count']++;
            }
            $ossdataconfig['current_file'] = $filename;
            $ossdataconfig['last_date'] = time();
            $ossdataconfig['completed_count']++;
        }
       
    }else{
        $result = $_G['BOAN_OSS']->getFilesList('uc_server/data/avatar', '',10);
        $result = (!empty($result) ? $result['items'] : array());
        foreach ($result as $r){
            $filename = DISCUZ_ROOT.$r['key'];
            $object = $r['key'];
            if($_G['BOAN_OSS']->isObject($object)){
                dmkdir(dirname($filename));
                if($_G['BOAN_OSS']->downFile($filename, $object)){
                    $_G['BOAN_OSS']->deleteFile($object);
                    $ossdataconfig['ok_count']++;
                   
                }else{
                    $ossdataconfig['error_count']++;
                }
                
            }else{
                $ossdataconfig['error_count']++;
            }
            $ossdataconfig['current_file'] = $filename;
            $ossdataconfig['last_date'] = time();
            $ossdataconfig['completed_count']++;
        }
        
    }
    return count($result);
}




function move_type_image(&$ossdataconfig){
    global $_G;
    static $step = 0;
    $result = null;
    if(!$ossdataconfig['status']){
        return 0;
    }
    
    if($ossdataconfig['direction'] == 1){
        $result = C::t('#boan_h5upload#boanh5_forum_typeoptionvar')->fetch_all_by_value(0,10,$step);
        $step = 0;
        foreach ($result as $v){
            $v1 = dunserialize($v['value']);
            $object = substr($v1['url'], strpos($v1['url'],'forum'));
            $filename1 = $_G['BOAN_OSSCONFIG']['oss_url'].OSS_BASEDIR.$object;
            $filename = $_G['setting']['attachdir'].$object;
            if(file_exists($filename) && filesize($filename) && $_G['BOAN_OSS']->uploadFile($filename, OSS_BASEDIR.$object,'public')){
                $v1['url'] = $filename1;
                C::t('forum_attachment_n')->update('tid:'.$v['tid'],$v1['aid'],array('remote'=>1));
                
                DB::update('forum_threadimage',array('remote'=>1),DB::field('tid', $v['tid']).' AND '.DB::field('attachment',str_replace(OSS_BASEDIR.'forum/', '', $object)));
                $v1 = addslashes(serialize($v1));
                $sql = $v['identifier']."='$v1'";
                C::t('forum_typeoptionvar')->update_by_tid($v['tid'], array('value' => $v1, 'sortid' => $v['sortid']), false, false, $v['optionid']);
                C::t('forum_optionvalue')->update($v['sortid'], $v['tid'], $v['fid'], $sql);
              
                $ossdataconfig['isdel'] &&  @unlink($filename);
                $ossdataconfig['ok_count']++;
            }else{
                $step ++;
                $ossdataconfig['error_count']++;
            }
            
            $ossdataconfig['current_file'] = $filename;
            $ossdataconfig['last_date'] = time();
            $ossdataconfig['completed_count']++;
        }
    }else{
        $result = C::t('#boan_h5upload#boanh5_forum_typeoptionvar')->fetch_all_by_value(1,10,$step);
        $step = 0;
        foreach ($result as $v){
            $v1 = dunserialize($v['value']);
            $object = substr($v1['url'], strpos($v1['url'],'forum'));
            $filename1 ='data/attachment/'.$object;
            $filename = $_G['setting']['attachdir'].$object;
            dmkdir(dirname($filename));
            if($_G['BOAN_OSS']->isObject(OSS_BASEDIR.$object) && $_G['BOAN_OSS']->downFile($filename, OSS_BASEDIR.$object)){
                $v1['url'] = $filename1;
                C::t('forum_attachment_n')->update('tid:'.$v['tid'],$v1['aid'],array('remote'=>0));
                DB::update('forum_threadimage',array('remote'=>0),DB::field('tid', $v['tid']).' AND '.DB::field('attachment',str_replace(OSS_BASEDIR.'forum/', '', $object)));
                $v1 = addslashes(serialize($v1));
                $sql = $v['identifier']."='$v1'";
                C::t('forum_typeoptionvar')->update_by_tid($v['tid'], array('value' => $v1, 'sortid' => $v['sortid']), false, false, $v['optionid']);
                C::t('forum_optionvalue')->update($v['sortid'], $v['tid'], $v['fid'], $sql);
                
                $ossdataconfig['isdel'] && $_G['BOAN_OSS']->deleteFile(OSS_BASEDIR.$object);
                $ossdataconfig['ok_count']++;
            }else{
                $step ++;
                $ossdataconfig['error_count']++;
            }
            
            $ossdataconfig['current_file'] = $filename;
            $ossdataconfig['last_date'] = time();
            $ossdataconfig['completed_count']++;
        }
    }
    
    return count($result);
}

function restore_type_image(&$ossdataconfig){
    global $_G;
    static $step = 0;
    $result = null;
    if(!$ossdataconfig['status']){
        return 0;
    }
    foreach (($result = C::t('#boan_h5upload#boanh5_forum_typeoptionvar')->fetch_all_by_value(2,10,$step)) as $v){
        $v1 = dunserialize($v['value']);
        $object = substr($v1['url'], strpos($v1['url'],'forum'));
        $filename1 ='data/attachment/'.$object;
        $filename2 = $_G['BOAN_OSSCONFIG']['oss_url'].OSS_BASEDIR.$object;
        $filename = $_G['setting']['attachdir'].$object;
        $isremote = (strpos($v1['url'], 'http') !== FALSE);
        if(!$isremote && !file_exists($filename) && $_G['BOAN_OSS']->isObject(OSS_BASEDIR.$object)){
            $v1['url'] = $filename2;
            C::t('forum_attachment_n')->update('tid:'.$v['tid'],$v1['aid'],array('remote'=>1));
            $v1 = addslashes(serialize($v1));
            $sql = $v['identifier']."='$v1'";
            C::t('forum_typeoptionvar')->update_by_tid($v['tid'], array('value' => $v1, 'sortid' => $v['sortid']), false, false, $v['optionid']);
            C::t('forum_optionvalue')->update($v['sortid'], $v['tid'], $v['fid'], $sql);
           
        }elseif($isremote && !$_G['BOAN_OSS']->isObject(OSS_BASEDIR.$object) && file_exists($filename) && filesize($filename)){
            $v1['url'] = $filename1;
            C::t('forum_attachment_n')->update('tid:'.$v['tid'],$v1['aid'],array('remote'=>0));
            $v1 = addslashes(serialize($v1));
            $sql = $v['identifier']."='$v1'";
            C::t('forum_typeoptionvar')->update_by_tid($v['tid'], array('value' => $v1, 'sortid' => $v['sortid']), false, false, $v['optionid']);
            C::t('forum_optionvalue')->update($v['sortid'], $v['tid'], $v['fid'], $sql);
          
        }elseif($isremote && $v1['url'] != $filename2){
            $v1['url'] = $filename2;
            $v1 = addslashes(serialize($v1));
            $sql = $v['identifier']."='$v1'";
            C::t('forum_typeoptionvar')->update_by_tid($v['tid'], array('value' => $v1, 'sortid' => $v['sortid']), false, false, $v['optionid']);
            C::t('forum_optionvalue')->update($v['sortid'], $v['tid'], $v['fid'], $sql);
        }
        $step ++;
        $ossdataconfig['ok_count']++;
        $ossdataconfig['current_file'] = $filename;
        $ossdataconfig['last_date'] = time();
        $ossdataconfig['completed_count']++;
    }
    return count($result);
}


function run_oss_data(){
    global $_G;
    static $step = 0;
    loadcache('boan_oss_dataconfig_cache',true);
    $ossdataconfig = $_G['cache']['boan_oss_dataconfig_cache'];
    if($ossdataconfig['target'] == 1){
        $result = move_forum_attach($ossdataconfig);
    }elseif($ossdataconfig['target'] == 2){
        $result = move_type_image($ossdataconfig);
    }elseif($ossdataconfig['target'] == 3){
        $result = move_portal_attach($ossdataconfig);
    }elseif($ossdataconfig['target'] == 4){
        $result = move_home_pic($ossdataconfig);
    }elseif ($ossdataconfig['target'] == 5){
        $result = restore_type_image($ossdataconfig);
    }elseif ($ossdataconfig['target'] == 6){
        $result = restore_article_image_link($ossdataconfig);
    }elseif ($ossdataconfig['target'] == 7){
        $result = move_avatar($ossdataconfig);
    }
  
    
    savecache('boan_oss_dataconfig_cache',$ossdataconfig);
    return $ossdataconfig['status'] && $result;
}

function end_oss_data(){
    global $_G;
    loadcache('boan_oss_dataconfig_cache',true);
    $ossdataconfig = $_G['cache']['boan_oss_dataconfig_cache'];
    $ossdataconfig['status'] = 2;
    savecache('boan_oss_dataconfig_cache',$ossdataconfig);
}

function stop_oss_data(){
    global $_G;
    loadcache('boan_oss_dataconfig_cache',true);
    $ossdataconfig = $_G['cache']['boan_oss_dataconfig_cache'];
    $ossdataconfig['status'] = 3;
    savecache('boan_oss_dataconfig_cache',$ossdataconfig);
    
}

function ignore_abort($runfunction, $endfunction, $stopfunction,$sleep = 10,$outtime = 0){
    ignore_user_abort(TRUE);
    set_time_limit($outtime);
    
    static $id;
    if(in_array($runfunction, $id)){
        return;
    }else{
        $id[] = $runfunction;
    }
    try{
        while (1) {
            if(!call_user_func($runfunction)){
                call_user_func($endfunction);
                break;
            }
            sleep($sleep);
        }
    }catch (Exception $e){
       writelog('hh',print_r($e,true));
        call_user_func($stopfunction);
    }
}