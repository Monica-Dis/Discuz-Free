<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: forum_image.php 32531 2013-02-06 10:15:19Z zhangguosheng $
 */
global $_G;
if(!defined('IN_DISCUZ') || empty($_GET['aid']) || empty($_GET['size']) || empty($_GET['key'])) {
    header('location: '.$_G['siteurl'].'static/image/common/none.gif');
    exit;
}
$nocache = !empty($_GET['nocache']) ? 1 : 0;
$daid = intval($_GET['aid']);
$type = !empty($_GET['type']) ? $_GET['type'] : 'fixwr';
list($w, $h) = explode('x', $_GET['size']);
$dw = intval($w);
$dh = intval($h);

$thumbfile = 'image/'.helper_attach::makethumbpath($daid, $dw, $dh);$attachurl = helper_attach::attachpreurl();
if(!$nocache) {
    if($_G['BOAN_OSS']->isObject(OSS_BASEDIR.$thumbfile)) {
         dheader('location: '.$_G['setting']['ftp']['attachurl'].$thumbfile);
    }
}

define('NOROBOT', TRUE);

$id = !empty($_GET['atid']) ? $_GET['atid'] : $daid;
if(dsign($id.'|'.$dw.'|'.$dh) != $_GET['key']) {
    dheader('location: '.$_G['siteurl'].'static/image/common/none.gif');
}

if($attach = C::t('forum_attachment_n')->fetch('aid:'.$daid, $daid, array(1, -1))) {
    if(!$dw && !$dh && $attach['tid'] != $id) {
        dheader('location: '.$_G['siteurl'].'static/image/common/none.gif');
    }
    dheader('Expires: '.gmdate('D, d M Y H:i:s', TIMESTAMP + 3600).' GMT');
    if($attach['remote']) {
        $filename = $_G['setting']['ftp']['attachurl'].'forum/'.$attach['attachment'];
        
    } else {
        $filename = $_G['setting']['attachdir'].'forum/'.$attach['attachment'];
        
    }
    require_once libfile('class/image');
    $img = new image;
    
    if($img->Thumb($filename, $thumbfile, $w, $h, $type)) {
        if($nocache) {
            dheader('Content-Type: image');
            @readfile($_G['setting']['attachdir'].$thumbfile);
            @unlink($_G['setting']['attachdir'].$thumbfile);
        } else {
            $_G['BOAN_OSS']->uploadFile($_G['setting']['attachdir'].$thumbfile, OSS_BASEDIR.$thumbfile,'public');
            @unlink($_G['setting']['attachdir'].$thumbfile);
            dheader('location: '.$_G['setting']['ftp']['attachurl'].$thumbfile);
        }
    } else {
        if($attach['remote']){
            if($_G['BOAN_OSS']->isObject(OSS_BASEDIR.'forum/'.$attach['attachment']) && !$nocache){
                $tmpfilename =$_G['setting']['attachdir'].'temp/'.random(16).substr(strrchr($attach['attachment'], '.'), 0);
                $_G['BOAN_OSS']->downFile($tmpfilename, OSS_BASEDIR.'forum/'.$attach['attachment']);
                
                if($img->Thumb($tmpfilename, $thumbfile, $w, $h, $type)){
                    $_G['BOAN_OSS']->uploadFile($_G['setting']['attachdir'].$thumbfile, OSS_BASEDIR.$thumbfile,'public');
                    @unlink($_G['setting']['attachdir'].$thumbfile);
                    @unlink($tmpfilename);
                    dheader('location: '.$_G['setting']['ftp']['attachurl'].$thumbfile);
                }
                @unlink($tmpfilename);
            }
            
            dheader('location: '.$filename);
        }else{
            dheader('Content-Type: image');
            @readfile($filename);
        }
        
    }
}
//From: Dism��taobao��com
?>