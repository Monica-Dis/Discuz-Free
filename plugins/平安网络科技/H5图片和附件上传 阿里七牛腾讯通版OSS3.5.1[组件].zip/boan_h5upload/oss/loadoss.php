<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
define('OSS_CLIENT_VERSION', '1.6.4');
define('OSS_CLIENT_RELEASE', '20210625');
define('OSS_ROOT', substr(__FILE__, 0, -11));
function boan_h5upload_autoloadcalss($class){    $dzlist = array('discuz_ftp','forum_upload','extend_thread_image','extend_thread_sort','extend_thread_trade');    $path =$class;    if(in_array($class,$dzlist)){
        $path = OSS_ROOT."source/class/discuz/$class.php";
        $path = str_replace('\\', DIRECTORY_SEPARATOR, $path);
        require_once $path;    }else{
        $path = OSS_ROOT."source/class/$class.php";
        $path = str_replace('\\', DIRECTORY_SEPARATOR, $path);
        if(file_exists($path)){            require_once $path;        }
    }
}

function boan_h5upload_formaturl($url){    $url = $url.(substr($url, -1) == '/' ? '' : '/');    preg_match('/^https?/i',$url) || ($url = 'https://'.$url);    return $url;}

function boan_h5upload_auto(){    global $_G;    $disable = array('zimu','xigua','ror_grab_csdn','bingofans_video','one_market','fn_','qqy_imageseg');    foreach ($disable as $v){        if(strpos($_GET['id'], $v) !== FALSE){            return ;        }    }        loadcache('boan_oss_cache');    $vars = $_G['cache']['boan_oss_cache'];      if(defined('IN_ADMINCP') && !empty($_GET['ossserver'])){        $vars = array( 'oss_server' => $_GET['ossserver'],            'oss_id' => trim($_GET['ossid']),            'oss_key' => trim($_GET['osskey']),            'oss_endpoint' => trim($_GET['ossendpoint']),            'oss_bucket' => trim($_GET['ossbucket']),            'oss_url' => trim($_GET['ossurl']),           );
    }
    if(!empty($vars) && $vars['oss_server']>1 && empty($_G['BOAN_OSS']) && function_exists('spl_autoload_register')){        spl_autoload_register('boan_h5upload_autoloadcalss',false,true);        define('OSS_DEBUG',$vars['oss_debug'] ? $_G['adminid'] : 0);        define('OSS_BASEDIR',$vars['oss_basedir']);        if(strpos($_SERVER['HTTP_USER_AGENT'],'MAGAPPX') !== FALSE){            define('IN_MAGAPP',1);        }               $oss_id = $vars['oss_id'];        $oss_key = $vars['oss_key'];        $oss_bucket = $vars['oss_bucket'];        $oss_endpoint = $vars['oss_endpoint'];        $oss_url = $vars['oss_url'];        $oss_url = boan_h5upload_formaturl($oss_url);        $_G['BOAN_OSSCONFIG'] = $vars;        $_G['BOAN_OSSCONFIG']['oss_url'] = $oss_url;        $_G['BOAN_OSSCONFIG']['oss_bucket_url'] = boan_h5upload_formaturl($_G['BOAN_OSSCONFIG']['oss_bucket_url']);        if($vars['oss_server'] == 2){            require_once OSS_ROOT.'source/class/aliyun/autoload.php';            $_G['BOAN_OSS'] = new aliyun_oss($oss_id, $oss_key, $oss_bucket, $oss_endpoint, $oss_url);        }else if($vars['oss_server'] == 3){            require_once OSS_ROOT.'source/class/qiniu/autoload.php';            $_G['BOAN_OSS'] = new qiniu_oss($oss_id, $oss_key, $oss_bucket, $oss_endpoint, $oss_url);        }else if($vars['oss_server'] == 4){            (!class_exists('Qcloud\Cos\Client')) && require_once OSS_ROOT.'source/class/tencent/vendor/autoload.php';            $_G['BOAN_OSS'] = new tencent_cos($oss_id, $oss_key, $oss_bucket, $oss_endpoint, $oss_url,$_G['BOAN_OSSCONFIG']['oss_bucket_url']);        }        $_G['BOAN_OSSCONFIG']['img_hlong'] && $_G['forum']['disablewatermark'] = 1;        $_G['setting']['ftp']['on'] = 1;        $_G['setting']['ftp']['host'] = 1;        $_G['setting']['ftp']['attachurl'] =  $oss_url.OSS_BASEDIR;    }}
boan_h5upload_auto();







