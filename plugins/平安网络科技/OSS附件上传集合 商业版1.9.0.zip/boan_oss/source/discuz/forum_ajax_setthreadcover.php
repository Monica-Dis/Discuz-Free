<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
define('NOROBOT', TRUE);
global $_G;
if($_GET['action'] == 'setthreadcover') {
    $aid = intval($_GET['aid']);
    $imgurl = $_GET['imgurl'];
    require_once libfile('function/post');
    if($_G['forum'] && ($aid || $imgurl)) {
        if($imgurl) {
            $tid = intval($_GET['tid']);
            $pid = intval($_GET['pid']);
        } else {
            $threadimage = C::t('forum_attachment_n')->fetch('aid:'.$aid, $aid);
            $tid = $threadimage['tid'];
            $pid = $threadimage['pid'];
        }
        
        if($tid && $pid) {
            $thread =get_thread_by_tid($tid);
        } else {
            $thread = array();
        }
        if(empty($thread) || (!$_G['forum']['ismoderator'] && $_G['uid'] != $thread['authorid'])) {
            if($_GET['newthread']) {
                showmessage('set_cover_faild', '', array(), array('msgtype' => 3));
            } else {
                showmessage('set_cover_faild', '', array(), array('closetime' => 3));
            }
        }
        if(boanh5_setthreadcover($pid, $tid, $aid, 0, $imgurl)) {
            if(empty($imgurl)) {
                C::t('forum_threadimage')->delete_by_tid($threadimage['tid']);
                C::t('forum_threadimage')->insert(array(
                    'tid' => $threadimage['tid'],
                    'attachment' => $threadimage['attachment'],
                    'remote' => $threadimage['remote'],
                ));
            }
            if($_GET['newthread']) {
                showmessage('set_cover_succeed', '', array(), array('msgtype' => 3));
            } else {
                showmessage('set_cover_succeed', '', array(), array('alert' => 'right', 'closetime' => 1));
            }
        }
    }
    if($_GET['newthread']) {
        showmessage('set_cover_faild', '', array(), array('msgtype' => 3));
    } else {
        showmessage('set_cover_faild', '', array(), array('closetime' => 3));
    }
    
} 

function boanh5_setthreadcover($pid, $tid = 0, $aid = 0, $countimg = 0, $imgurl = '') {
    global $_G;
    $cover = 0;
    if(empty($_G['uid']) || !intval($_G['setting']['forumpicstyle']['thumbheight']) || !intval($_G['setting']['forumpicstyle']['thumbwidth'])) {
        return false;
    }
   
    if(($pid || $aid) && empty($countimg)) {
        if(empty($imgurl)) {
            if($aid) {
                $attachtable = 'aid:'.$aid;
                $attach = C::t('forum_attachment_n')->fetch('aid:'.$aid, $aid, array(1, -1));
            } else {
                $attachtable = 'pid:'.$pid;
                $attach = C::t('forum_attachment_n')->fetch_max_image('pid:'.$pid, 'pid', $pid);
            }
            if(!$attach) {
                return false;
            }
            if(empty($_G['forum']['ismoderator']) && $_G['uid'] != $attach['uid']) {
                return false;
            }
            $pid = empty($pid) ? $attach['pid'] : $pid;
            $tid = empty($tid) ? $attach['tid'] : $tid;
            $picsource = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachdir']).'forum/'.$attach['attachment'];
        } else {
            return true;
        }
        
        $basedir = !$_G['setting']['attachdir'] ? (DISCUZ_ROOT.'./data/attachment/') : $_G['setting']['attachdir'];
        $coverdir = 'threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/';
        dmkdir($basedir.'./forum/'.$coverdir);
        
        require_once libfile('class/image');
        $image = new image();
        $tmpfilename = '';
        $parse = parse_url($picsource);
        if($parse['path']){
            $parse['path'][0] == '/' && ($parse['path'] = substr($parse['path'], 1));
           if($_G['BOAN_OSS']->isObject($parse['path'])){
                $tmpfilename =$_G['setting']['attachdir'].'temp/'.random(16).substr(strrchr($parse['path'], '.'), 0);
                if($_G['BOAN_OSS']->downFile($tmpfilename, $parse['path'])){
                    $picsource = $tmpfilename;
                }
               
            }
        }
        if($image->Thumb($picsource, 'forum/'.$coverdir.$tid.'.jpg', $_G['setting']['forumpicstyle']['thumbwidth'], $_G['setting']['forumpicstyle']['thumbheight'], 2)) {
            $remote = '';
            if(getglobal('setting/ftp/on')) {
                if(ftpcmd('upload', 'forum/'.$coverdir.$tid.'.jpg')) {
                    $remote = '-';
                }
            }
            $cover = C::t('forum_attachment_n')->count_image_by_id($attachtable, 'pid', $pid);
            if($imgurl && empty($cover)) {
                $cover = 1;
            }
            $cover = $remote.$cover;
        } else {
            !empty($tmpfilename) &&  @unlink($tmpfilename);
            return false;
        }
    }
    !empty($tmpfilename) &&  @unlink($tmpfilename);
    if($countimg) {
        if(empty($cover)) {
            $thread = C::t('forum_thread')->fetch($tid);
            $oldcover = $thread['cover'];
            
            $cover = C::t('forum_attachment_n')->count_image_by_id('tid:'.$tid, 'pid', $pid);
            if($cover) {
                $cover = $oldcover < 0 ? '-'.$cover : $cover;
            }
        }
    }
    if($cover) {
        C::t('forum_thread')->update($tid, array('cover' => $cover));
        return true;
    }
}
