<?php
use Obs\ObsClient;
use Obs\ObsException;

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class huawei_obs extends base_oss{
    
    function __construct($oss_id,$oss_key,$oss_bucket,$oss_endpoint,$oss_url){
        self::$oss_server_name = 'huawei';
        $this->oss_client = new ObsClient([
            'key' => $oss_id,
            'secret' => $oss_key,
            'endpoint' => $oss_endpoint,
            'signature' => 'obs'
        ]);
        $this->oss_info = array(
            'oss_id' => $oss_id,
            'oss_key' => $oss_key,
            'oss_bucket' => $oss_bucket,
            'oss_endpoint' => $oss_endpoint,
            'oss_url' => $oss_url
        );
    }
    
    function __destruct(){
        $this->oss_client->close ();
    }
    
    public function  setCors(){
        try {
            $bucket = $this->oss_info['oss_bucket'];
            $resp = $this->oss_client->setBucketCors ( [
                'Bucket' => $bucket,
                'CorsRules' => [
                    [
                        'ID' => 'rule1',
                        'AllowedMethod' => [ 'GET','HEAD','PUT','POST'],
                        'AllowedOrigin' => ['*'],
                        'AllowedHeader' => ['*'],
                        'MaxAgeSeconds' => 60
                    ]
                ]
            ] );
        }catch (Exception $e){
            return 0;
        }
        return 1;
    }
    
    
    public function  testOSS(){
        $status = 3;
        $bucket = $this->oss_info['oss_bucket'];
        try{
            $this->oss_client->putObject([
                'Bucket' => $bucket,
                'Key' => 'test.txt',
                'Body' => 'Hello OBS',
                'ACL' => ObsClient::AclPublicRead
            ]);
            $status--;
            $resp = $this->oss_client->getObject([
                'Bucket' => $bucket,
                'Key' => 'test.txt',
            ]);
            $content = $resp ['Body'];
            $status--;
            $content = $this->check_file($this->oss_info['oss_url'].'test.txt');
            if($content){
                $status--;
            }
            
        }catch(Exception $e){
            return $status;
        }
        return $status;
    }
    
    public function  RefererConfig(){
     
    }
    
    public function getImgStyle($style){
        if(empty($style)){
            return '';
        }
        return 'x-image-process=style/'.$style;
    }
    
    public function  isObject($object){
        try{
            $bucket = $this->oss_info['oss_bucket'];
            $this->oss_client->getObjectAcl ( [
                'Bucket' => $bucket,
                'Key' => $object
            ] );
            
            return 1;
        }catch(Exception $e){
          
            return 0;
        }
    }
    
    public function getFilesList($prefix = '',$marker = '',$limit = 100, $delimiter = ''){
        $bucket = $this->oss_info['oss_bucket'];
        $options = array(
            'Bucket' => $bucket,
            'Prefix' => $prefix,
            'MaxKeys' => $limit,
            'Marker' => $marker,
        );
        try {
            $resp = $this->oss_client->listObjects($options);
        } catch (Exception $e) {
            return 0;
        }
        
        $r['marker'] = $resp['NextMarker'];
        $r['items'] = array();
        foreach ( $resp ['Contents'] as $index => $content ) {
            $r['items'][] = array('key' => $content ['Key']);
        }
        
        return $r;
    }
    
    public function uploadFile($file, $object,$Acl = null){
        try{
            
            $arr = array('private' => 'private','public' => 'public-read');
            
            $bucket = $this->oss_info['oss_bucket'];
            
            if(!file_exists($file)){
                return 0;
            }
            $options = [
                'Bucket' => $bucket,
                'Key' => $object,
                'SourceFile' => $file
            ];
            $Acl && ($options['ACL'] = $arr[$Acl]);
            $resp =  $this->oss_client->putObject($options);
        }catch (Exception $e) {
            if(OSS_DEBUG){
                throw(new ObsException($e));
            }
            return 0;
        }
        return 1;
        
    }
    
    public function  uploadData($data, $object,$Acl = null){
        return 0;
    }
    
    public function setAcl($object,$Acl = null){
        try{
            $bucket = $this->oss_info['oss_bucket'];
            if(!$Acl){
                return 0;
            }
            $arr = array('private' => 'private','public' => 'public-read');
            $resp = $this->oss_client -> setObjectAcl([
                'Bucket' => $bucket,
                'Key' => $object,
                'ACL' => $arr[$Acl]
            ]);
            
        }catch (Exception $e) {
            if(OSS_DEBUG){
                throw(new ObsException($e));
            }
            return 0;
        }
        return 1;
        
    }
    
    public function  getPolicy($dir,$object,$length = 3048576000){
        global $_G;
        $id = $this->oss_info['oss_id'];      
        $public_arr = array('png','jpg','jpeg','bmp','gif');
        $arr = explode(',', $_G['BOAN_OSSCONFIG']['oss_ext']);
        $public_arr = array_merge($public_arr,$arr);
        $ext = strtolower($_GET['ext']);
        
        $acl = in_array($ext, $public_arr) ? 'public-read' : 'private';
        
        $EXT_MIME_MAP = [
            '3gp'=> 'video/3gpp',
            '7z'=> 'application/x-7z-compressed',
            'aac'=> 'audio/aac',
            'abw'=> 'application/x-abiword',
            'arc'=> 'application/x-freearc',
            'avi'=> 'video/x-msvideo',
            'apk'=> 'application/vnd.android.package-archive',
            'azw'=> 'application/vnd.amazon.ebook',
            'bin'=> 'application/octet-stream',
            'bmp'=> 'image/bmp',
            'bz'=> 'application/x-bzip',
            'bz2'=> 'application/x-bzip2',
            'bzip2'=> 'application/x-bzip2',
            'chm'=> 'application/vnd.ms-htmlhelp',
            'csh'=> 'application/x-csh',
            'css'=> 'text/css',
            'csv'=> 'text/csv',
            'doc'=> 'application/msword',
            'docx'=> 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'eot'=> 'application/vnd.ms-fontobject',
            'epub'=> 'application/epub+zip',
            'flv'=> 'video/x-flv',
            'gif'=> 'image/gif',
            'gz'=> 'application/gzip',
            'htm'=> 'text/html',
            'html'=> 'text/html',
            'ico'=> 'image/vnd.microsoft.icon',
            'ics'=> 'text/calendar',
            'jar'=> 'application/java-archive',
            'jpeg'=> 'image/jpeg',
            'jpg'=> 'image/jpeg',
            'js'=> 'text/javascript',
            'json'=> 'application/json',
            'jsonld'=> 'application/ld+json',
            'm4a'=> 'audio/mp4',
            'mid'=> 'audio/midi',
            'midi'=> 'audio/midi',
            'mjs'=> 'text/javascript',
            'mov'=> 'video/quicktime',
            'mkv'=> 'video/x-matroska',
            'mp3'=> 'audio/mpeg',
            'mp4'=> 'video/mp4',
            'mp4a'=> 'audio/mp4',
            'mp4v'=> 'video/mp4',
            'mpeg'=> 'video/mpeg',
            'mpkg'=> 'application/vnd.apple.installer+xml',
            'odp'=> 'application/vnd.oasis.opendocument.presentation',
            'ods'=> 'application/vnd.oasis.opendocument.spreadsheet',
            'odt'=> 'application/vnd.oasis.opendocument.text',
            'oga'=> 'audio/ogg',
            'ogv'=> 'video/ogg',
            'ogx'=> 'application/ogg',
            'opus'=> 'audio/opus',
            'otf'=> 'font/otf',
            'pdf'=> 'application/pdf',
            'php'=> 'application/php',
            'png'=> 'image/png',
            'ppt'=> 'application/vnd.ms-powerpoint',
            'pptx'=> 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'rar'=> 'application/x-rar-compressed',
            'rtf'=> 'application/rtf',
            'sh'=> 'application/x-sh',
            'svg'=> 'image/svg+xml',
            'swf'=> 'application/x-shockwave-flash',
            'tar'=> 'application/x-tar',
            'tif'=> 'image/tiff',
            'tiff'=> 'image/tiff',
            'ts'=> 'video/mp2t',
            'ttf'=> 'font/ttf',
            'txt'=> 'text/plain',
            'vsd'=> 'application/vnd.visio',
            'wav'=> 'audio/wav',
            'wma'=> 'audio/x-ms-wma',
            'wmv'=> 'video/x-ms-asf',
            'weba'=> 'audio/webm',
            'webm'=> 'video/webm',
            'webp'=> 'image/webp',
            'woff'=> 'font/woff',
            'woff2'=> 'font/woff2',
            'xhtml'=> 'application/xhtml+xml',
            'xls'=> 'application/vnd.ms-excel',
            'xlsx'=> 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'xml'=> 'application/xml',
            'xul'=> 'application/vnd.mozilla.xul+xml',
            'zip'=> 'application/zip'
        ];
        
        $MIME = array_key_exists($ext,$EXT_MIME_MAP) ? $EXT_MIME_MAP[$ext] : 'binary/octet-stream';
        
        $bucket = $this->oss_info['oss_bucket'];
        $resp = $this->oss_client->createPostSignature( [
            'Bucket' => $bucket,
            'Key' => "{$dir}{$object}",
            'Expires' => 3600,
            'FormParams' => [
                'acl' => $acl,
                'content-type' => $MIME,
            ]
        ] );
      
        $response = array();
        $response['accessid'] = $id;
        $response['policy'] = $resp['Policy'];
        $response['signature'] = $resp['Signature'];
        $response['dir'] = $dir;
        $response['acl'] = $acl;
        $response['contenttype'] = $MIME;
        $response['object'] = $object;
        return json_encode($response);
    }
    
    public function signUrl($object,$filename = '',$e = 3600){
        empty($e) && ($e = 3600);
        $url = '';
        $bucket = $this->oss_info['oss_bucket'];
        try{
            if(!empty($filename)){
                $resp = $this->oss_client->getObjectMetadata([
                    'Bucket' => $bucket,
                    'Key' => $object
                ]);
                
                $filename = rawurldecode(diconv($filename, CHARSET,'utf8'));
                
                $meta = $resp['Metadata'];
                if(!isset($meta['x-obs-meta-filename']) || $meta['x-obs-meta-filename'] != $filename  || (fileext($filename) == 'mp4' && $resp['ContentType'] != 'video/mp4')){
                    $options = [
                        'Bucket' => $bucket,
                        'Key' => $object,
                        'CopySource' => "$bucket/$object",
                        'ContentDisposition' => "attachment; filename=\"$filename\";filename*=utf-8''$filename",
                        'Metadata' => ['x-obs-meta-filename' => $filename],
                        'MetadataDirective' => ObsClient::ReplaceMetadata
                    ];
                    if(fileext($filename) == 'mp4'){
                        $options['ContentType'] = 'video/mp4';
                    }
                    $resp = $this->oss_client->copyObject($options);
                }
            }
            
            $resp = $this->oss_client->getObjectAcl ( [
                'Bucket' => $bucket,
                'Key' => $object
            ] );
            $Permission = '';
            foreach ($resp ['Grants'] as $v){
                if(empty($v['Grantee']['ID']) && strpos($v['Grantee']['URI'],'AllUsers') !== FALSE && $v['Permission'] == 'READ'){
                    $Permission = 'public-read';
                    break;
               }
            }
            
            if($Permission == 'public-read'){
                $url =  $this->oss_info['oss_url'].$object;
            }else{
                $resp = $this->oss_client->createSignedUrl( [
                    'Method' => 'GET',
                    'Bucket' => $bucket,
                    'Key' => $object,
                    'Expires' => $e
                ] );
                $url = $resp['SignedUrl'];
                
                $url = explode('?', $url);
                $url =  $this->oss_info['oss_url'].$object.($url[1] ? '?'.$url[1] : '');
            }
            $url = str_replace('-internal', '', $url);
        }catch (Exception $e) {
            if(OSS_DEBUG){
                throw(new ObsException($e));
            }
            return 0;
        }
        return $url;
    }
    
    public function  renameObject($oldObject,$newObject,$MimeType = null){
        $bucket = $this->oss_info['oss_bucket'];
        try{
            
            $resp = $this->oss_client->copyObject ( [
                'Bucket' => $bucket,
                'Key' => $newObject,
                'CopySource' => "$bucket/$oldObject"
            ] );
            
            if(!empty($resp ['RequestId'])){
                $resp = $this->oss_client->deleteObject ( [
                    'Bucket' => $bucket,
                    'Key' => $oldObject
                ] );
            }
            
        }catch (Exception $e) {
            if(OSS_DEBUG){
                throw(new ObsException($e));
            }
            return 0;
        }
        return 1;
        
    }
    
    
    public function downFile($file,$object){
        try{
            $bucket = $this->oss_info['oss_bucket'];
            $resp =  $this->oss_client -> getObject([
                'Bucket' => $bucket,
                'Key' => $object,
                'SaveAsFile' => $file,
            ]);
           
        }catch (Exception $e) {
            if(OSS_DEBUG){
                throw(new ObsException($e));
            }
            return 0;
        }
        return 1;
    }
    
    
    public function deleteFile($objects){
        try{
            $bucket = $this->oss_info['oss_bucket'];
            if(is_array($objects)){
                return 0;
            }else{
                $resp = $this->oss_client->deleteObject ( [
                    'Bucket' => $bucket,
                    'Key' => $objects
                ] );
            }
        }catch (Exception $e) {
            if(OSS_DEBUG){
                throw(new ObsException($e));
            }
            return 0;
        }
        return 1;
    }
    
    
    public function  getCallback($object){
        global $_G;
        $bucket = $this->oss_info['oss_bucket'];
        if(!$this->isObject($object)){
            return null;
        }
        $data = array();
        $data['object'] = $object;
      
        $data1 = $this->oss_client->getObjectMetadata([
            'Bucket' => $bucket,
            'Key' => $object
        ]);
        $data['size'] = $data1['ContentLength'];
        $data['height'] = 0;
        $data['width'] = 0;
        if(strpos($data1['ContentType'],'image') !== FALSE){
            $url = $this->signUrl($object);
            $ch = curl_init();
            
            $httpheader[] = "User-Agent: ".$_SERVER['HTTP_USER_AGENT'];
            $httpheader[] = "Referer: ".$_G['siteurl'];
            
            if($httpheader) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
            }
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, 1);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RANGE, '0-32767');
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            $dataBlock = curl_exec($ch);
            $status = curl_getinfo($ch);
            $errno = curl_errno($ch);
            curl_close($ch);
           
            if($errno) {
                return $data;
            } else {
                $GLOBALS['filesockheader'] = substr($dataBlock, 0, $status['header_size']);
                $dataBlock = substr($dataBlock, $status['header_size']);
            }
            
            if (!$dataBlock) return $data;
            $size = getimagesize('data://image/jpeg;base64,'. base64_encode($dataBlock));
            
            if (empty($size)) {
                $img = $this->check_file($url);
                $size = getimagesize('data://image/jpeg;base64,'. base64_encode($img));
                if(empty($size)){
                    return $data;
                }
            }
            
            $data['width'] = $size[0];
            $data['height'] = $size[1];
        }
        
        return $data;
    }
    
}