<?php
use OSS\OssClient;

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class aliyun_oss extends base_oss{
    
    function __construct($oss_id,$oss_key,$oss_bucket,$oss_endpoint,$oss_url){
        self::$oss_server_name = 'aliyun'; 
        $this->oss_client = new OSS\OssClient($oss_id,$oss_key,$oss_endpoint);
        
        $this->oss_info = array(
            'oss_id' => $oss_id,
            'oss_key' => $oss_key,
            'oss_bucket' => $oss_bucket,
            'oss_endpoint' => $oss_endpoint,
            'oss_url' => $oss_url
        );
    }
    
    public function  setCors(){
        $corsConfig = new OSS\Model\CorsConfig();
        $rule = new OSS\Model\CorsRule();
        $rule->addAllowedOrigin("*");
        $rule->addAllowedMethod("POST");
        $rule->addAllowedMethod("GET");
        $rule->setMaxAgeSeconds(0);
        $corsConfig->addRule($rule);
        try {
            $this->oss_client->putBucketCors($this->oss_info['oss_bucket'], $corsConfig);
            
        }catch (Exception $e){
            return 0;
        }
        return 1;
    }
    
    
    public function  testOSS(){
        $status = 3;
        try{
            $options = array(
                OssClient::OSS_HEADERS => array(
                    'x-oss-object-acl' => 'public-read',
                ),
            );
            $this->oss_client->putObject($this->oss_info['oss_bucket'], 'test.txt', 'A test of aliyun oss',$options);
            $status--;
            $content = $this->oss_client->getObject($this->oss_info['oss_bucket'], 'test.txt');
            $status--;
            //$this->RefererConfig();
            $content = $this->check_file($this->oss_info['oss_url'].'test.txt');
            if($content){
                $status--;
            }
            
        }catch(Exception $e){
           return $status;
        }
        return $status;
    }
    
    public function  RefererConfig(){
        $refererConfig = new OSS\Model\RefererConfig();
        $refererConfig->setAllowEmptyReferer(false);
        $refererConfig->addReferer('*.aliyun.com');
        $refererConfig->addReferer('*'.$_SERVER[HTTP_HOST].'*');
        $refererConfig->addReferer($this->oss_info['oss_url']);
        
        $this->oss_client->putBucketReferer($this->oss_info['oss_bucket'], $refererConfig);
    }
    
    public function getImgStyle($style){
        if(empty($style)){
            return '';
        }
        
        return 'x-oss-process='.$style;
    }
    
    public function  isObject($object){
        try{
            return $this->oss_client->doesObjectExist($this->oss_info['oss_bucket'], $object);
        }catch(Exception $e){
            if(OSS_DEBUG){
                throw(new OSS\Core\OssException($e->getMessage()));
            }
            return 0;
        }
    }
    
    public function getFilesList($prefix = '',$marker = '',$limit = 100, $delimiter = ''){
        $bucket = $this->oss_info['oss_bucket'];
        $options = array(
            'delimiter' => $delimiter,
            'prefix' => $prefix,
            'max-keys' => $limit,
            'marker' => $marker,
        );
        try {
            $listObjectInfo = $this->oss_client->listObjects($bucket, $options);
        } catch (Exception $e) {
            return 0;
        }
        $r = array();
        $objectList = $listObjectInfo->getObjectList(); // object list
        $r['marker'] = $listObjectInfo->getNextMarker();
        $r['items'] = array();
        if (!empty($objectList)) {
           foreach ($objectList as $objectInfo) {
               $r['items'][] = array('key' => $objectInfo->getKey());
            }
        }
        return $r;
    }
    
   public function uploadFile($file, $object,$Acl = null){
      try{
          if(!file_exists($file)){
             return 0;
          }
          $arr = array('private' => 'private','public' => 'public-read');
          $this->oss_client->multiuploadFile($this->oss_info['oss_bucket'], $object, $file);
          $Acl && ($this->oss_client->putObjectAcl($this->oss_info['oss_bucket'], $object, $arr[$Acl]));
      }catch (Exception $e) {
          if(OSS_DEBUG){
              throw(new OSS\Core\OssException($e->getMessage()));
          }
         return 0;
      }
      return 1;
     
   }
   
   public function  uploadData($data, $object,$Acl = null){
       try{
         $ret = 0;
         if(empty($data)){
             return 0;
         }
         $arr = array('private' => 'private','public' => 'public-read');
         empty($Acl) && $Acl = 'private';
      
         $options =  array(
             OssClient::OSS_HEADERS => array(
                 'x-oss-object-acl' =>  $arr[$Acl],
             ),
         );
         $ret = $this->oss_client->putObject($this->oss_info['oss_bucket'], $object, $data,$options);
         
       }catch(Exception $e){
           if(OSS_DEBUG){
               throw(new OSS\Core\OssException($e->getMessage()));
           }
           return 0;
       }
       return $ret;
   }
   
   public function setAcl($object,$Acl = null){
       try{
           $arr = array('private' => 'private','public' => 'public-read');
           $Acl && ($this->oss_client->putObjectAcl($this->oss_info['oss_bucket'], $object, $arr[$Acl]));
       }catch (Exception $e) {
           if(OSS_DEBUG){
               throw(new OSS\Core\OssException($e->getMessage()));
           }
           return 0;
       }
       return 1;
       
   }
   
   public function  getPolicy($dir,$object,$length = 3048576000){
       $id= $this->oss_info['oss_id'];         
       $key= $this->oss_info['oss_key'];     
       $host = $this->oss_info['oss_url'];
       
       $now = time();
       $expire = 30;  
       $end = $now + $expire;
       $expiration = $this->gmt_iso8601($end);
      
       $condition = array(0=>'content-length-range', 1=>0, 2=>$length);
       $conditions[] = $condition;
     
       $start = array(0=>'starts-with', 1=>'$key', 2=>$dir);
       $conditions[] = $start;
       
       $arr = array('expiration'=>$expiration,'conditions'=>$conditions);
       $policy = json_encode($arr);
       $base64_policy = base64_encode($policy);
       $string_to_sign = $base64_policy;
       $signature = base64_encode(hash_hmac('sha1', $string_to_sign, $key, true));
       
       $response = array();
       $response['accessid'] = $id;
       $response['host'] = $host;
       $response['policy'] = $base64_policy;
       $response['signature'] = $signature;
       $response['expire'] = $end;
       $response['dir'] = $dir;  
       $response['object'] = $object;
       return json_encode($response);
   }
   
   public function signUrl($object,$filename = '',$e = 3600){
       empty($e) && ($e = 3600);
       $url = '';
       $bucket = $this->oss_info['oss_bucket'];
       try{
           if(!empty($filename)){
               $meta = $this->oss_client->getObjectMeta($bucket,$object);
               if(!isset($meta['x-oss-meta-filename']) || $meta['x-oss-meta-filename'] != $filename  || (fileext($filename) == 'mp4' && $meta['content-type'] != 'video/mp4')){
                   $filename = rawurldecode(diconv($filename, CHARSET,'utf8'));
                   $headers = array(
                       'Content-Disposition' => "attachment; filename=\"$filename\";filename*=utf-8''$filename",
                       'x-oss-meta-filename' => $filename,
                       'x-oss-metadata-directive' => 'REPLACE',
                   );
                   if(fileext($filename) == 'mp4'){
                       $headers['Content-Type'] = 'video/mp4';
                   }
                   $copyOptions = array(
                       'headers' =>  $headers,
                   );
                   $this->oss_client->copyObject($bucket, $object, $bucket, $object,$copyOptions);
               }
               
           }
           
           if($this->oss_client->getObjectAcl($bucket, $object) == 'public-read'){
               $url =  $this->oss_info['oss_url'].$object;
           }else{
               $url = $this->oss_client->signUrl($bucket, $object,$e);
               $url = explode('?', $url);
               $url =  $this->oss_info['oss_url'].$object.($url[1] ? '?'.$url[1] : '');
           }
           
           $url = str_replace('-internal', '', $url);
           
       }catch (Exception $e) {
           if(OSS_DEBUG){
               throw(new OSS\Core\OssException($e->getMessage()));
           }
           return 0;
       }
       return $url;
   }
   
   public function  renameObject($oldObject,$newObject,$MimeType = null){
       $bucket = $this->oss_info['oss_bucket'];
       try{
           
           
           if($this->oss_client->copyObject($bucket, $oldObject, $bucket, $newObject)){
               $this->oss_client->deleteObject($bucket, $oldObject);
           }
       }catch (Exception $e) {
           if(OSS_DEBUG){
               throw(new OSS\Core\OssException($e->getMessage()));
           }
           return 0;
       }
       return 1;
       
   }
   
   
   public function downFile($file,$object){
       try{
          
           $options = array(
               'fileDownload' => $file,
           );
           $this->oss_client->getObject($this->oss_info['oss_bucket'],$object,$options);
       }catch (Exception $e) {
           if(OSS_DEBUG){
               throw(new OSS\Core\OssException($e->getMessage()));
           }
           return 0;
       }
       return 1;
   }
   
   
   public function deleteFile($objects){
       try{
           if(is_array($objects)){
               $this->oss_client->deleteObjects($this->oss_info['oss_bucket'], $objects);
           }else{
               $this->oss_client->deleteObject($this->oss_info['oss_bucket'], $objects);
           }
       }catch (Exception $e) {
           if(OSS_DEBUG){
               throw(new OSS\Core\OssException($e->getMessage()));
               
           }
           return 0;
       }
       return 1;
   }
   
   
   public function  getCallback($object){
       if(!$this->oss_client->doesObjectExist($this->oss_info['oss_bucket'], $object)){
         return null;
       }
       $data = array();
       $data['object'] = $object;
       $data1 = $this->oss_client->getObjectMeta($this->oss_info['oss_bucket'], $object);
       $data['size'] = $data1['content-length'];
       $data['height'] = 0;
       $data['width'] = 0;
       if(strpos($data1['content-type'],'image') !== FALSE){
           $options = array(
               OssClient::OSS_PROCESS => "image/info" );
           $data1 = $this->oss_client->getObject($this->oss_info['oss_bucket'], $object,$options);
           $data1 = json_decode($data1,true);
           $data['height'] = $data1['ImageHeight']['value'];
           $data['width'] = $data1['ImageWidth']['value'];
       }
    
       return $data;
   }
  
}