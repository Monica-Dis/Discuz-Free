<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    
    exit('Access Denied');
    
}

define('OSS_CLIENTLIB_VERSION', '1.0.1');

define('OSS_CLIENTLIB_RELEASE', '20210823');

define('OSS_LIB_ROOT', substr(__FILE__, 0, -15));

function boan_oss_formaturl($url){
    $url = $url.(substr($url, -1) == '/' ? '' : '/');
    preg_match('/^https?/i',$url) || ($url = 'https://'.$url);
    return $url;
}

function boan_oss_autoloadcalss($class){
    $path = OSS_LIB_ROOT."source/class/$class.php";
    $path = str_replace('\\', DIRECTORY_SEPARATOR, $path);
    if(file_exists($path)){
        require_once $path;
    }
}

/**
 * OSS
 * @param unknown $type :=1,t=2,=3
 * @param unknown $para
 * @return aliyun_oss|qiniu_oss|tencent_cos|boolean
 */
function  boan_loadoss($type,$para){
    $oss_id = trim($para['oss_id']);                //Access Key ID
    $oss_key = trim($para['oss_key']);              //Access Key Secret
    $oss_bucket = $para['oss_bucket'];        //OSSBucket
    //OSS^j   дOSS /EndPointoss-cn-beijing.aliyuncs.com:д:ap-nanjingt:,:s3-cn-south-1.qiniucs.com
    $oss_endpoint = $para['oss_endpoint'];   
    //OSSBucket ,
    //Bucketpingankj.oss-cn-beijing.aliyuncs.com:еk, : https://xsyt-1255568104.cos.ap-nanjing.myqcloud.com;tOSSBucket,:https://upload.qiniup.com;:https://upload-z1.qiniup.com;:https://upload-z2.qiniup.com;: https://upload-na0.qiniup.com;:https://upload-as0.qiniup.com
    $oss_bucket_url =  boan_oss_formaturl($para['oss_bucket_url']);
    //OSS дOSSbucket.
    $oss_url = boan_oss_formaturl($para['oss_url']);      
    spl_autoload_register('boan_oss_autoloadcalss',false,true);
    if($type == 1){//
        require_once OSS_LIB_ROOT.'source/class/aliyun/autoload.php';
        return new aliyun_oss($oss_id, $oss_key, $oss_bucket, $oss_endpoint, $oss_url);
    }else if($type == 2){//t
        require_once OSS_LIB_ROOT.'source/class/qiniu/autoload.php';
        return new qiniu_oss($oss_id, $oss_key, $oss_bucket, $oss_endpoint, $oss_url);
    }else if($type == 3){//
        require_once OSS_LIB_ROOT.'source/class/tencent/vendor/autoload.php';
        return  new tencent_cos($oss_id, $oss_key, $oss_bucket, $oss_endpoint, $oss_url,$oss_bucket_url);
    }
    return false;
}


