if(typeof boan_h5upload_qrcodelife === 'undefined' ){
	var boan_h5upload_qrcodelife = 0;
}
var boanh5_remain = boan_h5upload_qrcodelife ? parseInt(boan_h5upload_qrcodelife) : 0;
var boanh5_qrcode = null;
setInterval(function(){
	boanh5_posttime = parseInt(boanh5_posttime) + 1;
	if(boan_h5upload_qrcodelife && boanh5_remain>0){
		 boanh5_remain -= 1;
		//console.log(boanh5_remain);
	}
	if(boan_h5upload_qrcodelife>0 &&  boanh5_remain <= 0  && $('boanh5_qrccde') && $('boanh5_info_holt').style.display != ''){
		$('boanh5_info_holt').style.display = '';
		$('boanh5_info_title').style.display = '';
		boan_jq('#boanh5_qrccde img').css('opacity',0.1);
	}
	//console.log(boanh5_posttime);
},1000);

function boan_h5upload_reflash_qrcode(){
	boan_jq.ajax({
		type:"GET",
		url:'plugin.php?id=boan_h5upload:ajax&qrcode=yes',
		success:function(data){
			if(data){
				boanh5_qrcode.makeCode(data);
				boanh5_remain = boan_h5upload_qrcodelife;
				$('boanh5_info_holt').style.display = 'none';
				$('boanh5_info_title').style.display = 'none';
				boan_jq('#boanh5_qrccde img').css('opacity',1);
			}
		},
		error:function(xhr,status,error){
			alert(error);
		},
	});
}
function boan_bulid_qrcode(){
boan_jq('[id=e_image],.edui-for-dz_image').on('click',function(){
   if(boan_h5upload_ispic_qrcode && !$('boanh5_qrccde')){
	notice = boan_jq('#e_imgattachlist .notice');
	notice.css('width','444px');
	notice.css('float','left');
	notice.css('margin-top','0px');
	notice.before('<div class="notice upnf" style="float:left; margin:14px 0px 14px 0px;">' + boan_h5upload_lang['qrcode_4'] + '</div>');
	var s1 = '<div id="boanh5_qrccde" style="">';
	s1 += '<div id="boanh5_info_holt" style="display:none;position: absolute;left: 50%; background-color: red; z-index: 1; width: 40px; margin-left: -20px; text-align: center; border-radius: 30px; height: 40px;  top: 10px;"><span style="color: white; font-size: 30px; font-weight: bold;line-height:40px">!</span></div>';
    s1 += '<div id="boanh5_info_title" style="display:none; position: absolute; top: 60px; left: 14px; z-index: 1; text-align: center;"><span style="color: gray;">' + boan_h5upload_lang['qrcode_5'] + '</span><br><a style="cursor: pointer;" onclick="boan_h5upload_reflash_qrcode()">' + boan_h5upload_lang['qrcode_6'] +'</a></div>';
	s1 += '</div>';
	notice.after(s1);
		boanh5_qrcode = new QRCode("boanh5_qrccde",{
		text:boan_h5upload_qrcodeurl,
		width:100,
		height:100,
	
	});
	var boanh5_obj = document.createElement('div');
	boanh5_obj.id = 'boanh5_qrcode_rtn';
	boanh5_obj.style.display = 'none';
	document.body.appendChild(boanh5_obj);
	
	var boanh5_ajaxflag = true;
		
	setInterval(function(){
		if(!($(editorid+'_image_menu').style.display == 'none' || $(editorid+'_image_menu').style.visibility == 'hidden')){
			if(boanh5_qrcode_img.timeflag && boanh5_ajaxflag){
				boanh5_ajaxflag = false;
				ajaxget('forum.php?mod=ajax&action=imagelist&type=single&pid=0&posttime='+boanh5_qrcode_img.posttime ,'boanh5_qrcode_rtn',null,null,'none',function(){
						var L = boan_jq('#boanh5_qrcode_rtn').children('a').length;
						console.log(L);
						for(var i = 0; i<L; i++){
							boanh5_qrcode_img.posttime = boanh5_posttime-5;
							var obj = boan_jq('#boanh5_qrcode_rtn').children(':eq(0)');
							if($('image_td_'+obj[0].id.substr(11)) || in_array(obj[0].id.substr(11),boanh5_updateimg)) {
								continue;
							}
							var tdObj = getInsertTdId(imgUpload.customSettings.imgBoxObj, 'image_td_'+obj[0].id.substr(11));
							boan_jq(tdObj).append(boan_jq('#boanh5_qrcode_rtn').children(':eq(0)'));
							boan_jq(tdObj).append(boan_jq('#boanh5_qrcode_rtn').children(':eq(0)'));
							boan_jq(tdObj).append(boan_jq('#boanh5_qrcode_rtn').children(':eq(0)'));
							obj = boan_jq('#boanh5_qrcode_rtn').children(':eq(0)');
							obj[0].id == ''  && boan_jq(tdObj).append(boan_jq('#boanh5_qrcode_rtn').children(':eq(0)'));
						}
						boanh5_ajaxflag = true;
				});
				//console.log(boanh5_qrcode_img);
			}	
		}
		
	},5000); 
	
}

});}

setTimeout('boan_bulid_qrcode()',600);

