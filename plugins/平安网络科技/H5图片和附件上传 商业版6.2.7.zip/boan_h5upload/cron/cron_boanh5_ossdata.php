<?php

//cronname:OSS_MOVE_DATA
//minute:0,5,10,15,20,15,30,35,40,45,50,55,59


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


global $_G;
$oss1 = DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/';
$oss2 = DISCUZ_ROOT.'./source/plugin/boan_oss/';

(file_exists($oss1.'loadoss.php') &&  require_once($oss1.'loadoss.php')) || (file_exists($oss2.'loadoss.php') &&  require_once($oss2.'loadoss.php'));
(file_exists($oss1.'source/admin/cron_ossdata.inc.php') &&  require_once($oss1.'source/admin/cron_ossdata.inc.php')) || file_exists($oss2.'source/admin/cron_ossdata.inc.php') &&  require_once($oss2.'source/admin/cron_ossdata.inc.php');
if($_G['BOAN_OSS']){
    loadcache('boan_oss_dataconfig_cache',true);
    $ossdataconfig = $_G['cache']['boan_oss_dataconfig_cache'];

    try{
        if($ossdataconfig['ossmethod'] == 2 && $ossdataconfig['status'] == 1){
            if(!run_oss_data()){
                end_oss_data();
            }
        }
    }catch (Exception $e){
        writelog('boan_oss',print_r($e,true));
        stop_oss_data();
    }
   
}



