<?php
//cronname:CLEANATT
//minute:0,59

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
loadcache('boan_oss_cleanatt_cache',true);
$cache = $_G['cache']['boan_oss_cleanatt_cache'];

empty($cache['lasttime']) && $cache['lasttime'] = time();

if(strtotime("-{$cache['interval']} hours") > $cache['lasttime']){
    $cache['lasttime'] = time();
    if(empty($cache['lastweektime']) || strtotime("-1 week") > $cache['lastweektime']){
        $cache['lastweektime'] = time();
        $cache['weekdayatt'] = 0;
        $cache['weekdayatt_ct'] = 0;
        $cache['weekdaytemp'] = 0;
        $cache['weekdaytemp_ct'] = 0;
    }
    
    $expire = time()-$cache['limitatt']*60;
    $temp_att = DB::fetch_all('SELECT * FROM %t WHERE dateline<%i',array('forum_attachment_unused',$expire));
    foreach ($temp_att as $attach){
        $cache['weekdayatt_ct']++;
        $cache['weekdayatt'] += $attach['filesize'];
        DB::delete('forum_attachment_unused', 'aid='.$attach['aid']);
        DB::delete('forum_attachment', 'aid='.$attach['aid']);
        dunlink($attach);
    }
    
    $tempdir = scandir($_G['setting']['attachdir'].'/temp/');
    foreach ($tempdir as $t){
        if($t != '.' && $t != '..' && !is_dir($_G['setting']['attachdir'].'/temp/'.$t) && (time()-$cache['limittemp']*60) > filemtime($_G['setting']['attachdir'].'/temp/'.$t)){
            $cache['weekdaytemp_ct']++;
            $cache['weekdaytemp'] += filesize($_G['setting']['attachdir'].'/temp/'.$t);
            @unlink($_G['setting']['attachdir'].'/temp/'.$t);
        }
    }
}

savecache('boan_oss_cleanatt_cache',$cache);