<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
define('P_NAME', 'plugin/boan_h5upload');
(file_exists(DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/loadoss.php') &&  require_once(DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/loadoss.php'))
|| (file_exists(DISCUZ_ROOT.'./source/plugin/boan_oss/loadoss.php') &&  require_once(DISCUZ_ROOT.'./source/plugin/boan_oss/loadoss.php'));
global $_G;
if($_GET['pmod'] == 'avthumb'){
    if(!submitcheck('set_submit')){
        cpheader();
        loadcache('boan_oss_avthumb_cache');
        $avthumb_cache = $_G['cache']['boan_oss_avthumb_cache'];
        if(!$_G['cache']['boan_oss_avthumb_cache']){
            $avthumb_cache = array(
                'avthumb_allow' => '0',
                'avthumb_ext' => 'flv,mepg,avi,rm,rmvb,mp4,mpg',
                'avthumb_width' => '0',
                'avthumb_height' => '0',
                'avthumb_pic' => '',
                'avthumb_pic_pos' => 0,
                'avthumb_text' => '',
                'avthumb_text_pos' => 0,
                'avthumb_text_fontname' => 0,
                'avthumb_text_fontsize' => 20,
                'avthumb_text_color' => '#000000',
                'avthumb_HOffset' => 0,
                'avthumb_VOffset' => 0,
                'avthumb_groups' => null,
                'avthumb_forums' => null,
            );
        }
        
        showtips(lang(P_NAME, 'oss_avthumb_explain'));
        showformheader('plugins&operation=config&do='.$pluginid.'&pmod=avthumb');
        showtableheader('','','',9);
        showtagheader('tbody', '',true);
        showsetting(lang(P_NAME, 'oss_avthumb_allow'), 'avthumballow', $avthumb_cache['avthumb_allow'],'radio',0,0,lang(P_NAME, 'oss_avthumb_allow_comment'));
        showsetting(lang(P_NAME, 'oss_avthumb_ext'), 'avthumbext', $avthumb_cache['avthumb_ext'],'text',0,0,lang(P_NAME, 'oss_avthumb_ext_comment'));
        showsetting(lang(P_NAME, 'oss_avthumb_width'), 'avthumbwidth',$avthumb_cache['avthumb_width'],'number',0,0,lang(P_NAME, 'oss_avthumb_width_comment'));
        showsetting(lang(P_NAME, 'oss_avthumb_height'), 'avthumbheight', $avthumb_cache['avthumb_height'],'number',0,0,lang(P_NAME, 'oss_avthumb_height_comment'));
        showsetting(lang(P_NAME, 'oss_avthumb_pic'), 'avthumbpic', $avthumb_cache['avthumb_pic'],'text',0,0,lang(P_NAME, 'oss_avthumb_pic_comment'));
        
        $checkwm['pic'] = array('','','','','','','','','');
        $checkwm['pic'][$avthumb_cache['avthumb_pic_pos']] = 'checked';
        
        showsetting(lang(P_NAME, 'oss_avthumb_picpos'), '', '', '<table style="margin-bottom: 3px; margin-top:3px;"><tr><td><input class="radio" type="radio" name="avthumbpicpos" value="0" '.$checkwm['pic'][0].'> #1</td><td><input class="radio" type="radio" name="avthumbpicpos" value="1" '.$checkwm['pic'][1].'> #2</td><td><input class="radio" type="radio" name="avthumbpicpos" value="2" '.$checkwm['pic'][2].'> #3</td></tr><tr><td><input class="radio" type="radio" name="avthumbpicpos" value="3" '.$checkwm['pic'][3].'> #4</td><td><input class="radio" type="radio" name="avthumbpicpos" value="4" '.$checkwm['pic'][4].'> #5</td><td><input class="radio" type="radio" name="avthumbpicpos" value="5" '.$checkwm['pic'][5].'> #6</td></tr><tr><td><input class="radio" type="radio" name="avthumbpicpos" value="6" '.$checkwm['pic'][6].'> #7</td><td><input class="radio" type="radio" name="avthumbpicpos" value="7" '.$checkwm['pic'][7].'> #8</td><td><input class="radio" type="radio" name="avthumbpicpos" value="8" '.$checkwm['pic'][8].'> #9</td></tr></table>');
        
        showsetting(lang(P_NAME, 'oss_avthumb_text'), 'avthumbtext', $avthumb_cache['avthumb_text'],'text',0,0,lang(P_NAME, 'oss_avthumb_text_comment'));
        $checkwm['text'] = array('','','','','','','','','');
        $checkwm['text'][$avthumb_cache['avthumb_text_pos']] = 'checked';
        
        showsetting(lang(P_NAME, 'oss_avthumb_textpos'), '', '', '<table style="margin-bottom: 3px; margin-top:3px;"><tr><td><input class="radio" type="radio" name="avthumbtextpos" value="0" '.$checkwm['text'][0].'> #1</td><td><input class="radio" type="radio" name="avthumbtextpos" value="1" '.$checkwm['text'][1].'> #2</td><td><input class="radio" type="radio" name="avthumbtextpos" value="2" '.$checkwm['text'][2].'> #3</td></tr><tr><td><input class="radio" type="radio" name="avthumbtextpos" value="3" '.$checkwm['text'][3].'> #4</td><td><input class="radio" type="radio" name="avthumbtextpos" value="4" '.$checkwm['text'][4].'> #5</td><td><input class="radio" type="radio" name="avthumbtextpos" value="5" '.$checkwm['text'][5].'> #6</td></tr><tr><td><input class="radio" type="radio" name="avthumbtextpos" value="6" '.$checkwm['text'][6].'> #7</td><td><input class="radio" type="radio" name="avthumbtextpos" value="7" '.$checkwm['text'][7].'> #8</td><td><input class="radio" type="radio" name="avthumbtextpos" value="8" '.$checkwm['text'][8].'> #9</td></tr></table>');
        $L_fonts = lang(P_NAME,'oss_avthumb_fonts');
        showsetting(lang(P_NAME, 'oss_avthumb_fontname'),
            array('avthumbtextfontname',
                array(
                    array('1',$L_fonts[1]),
                    array('2',$L_fonts[2]),
                    array('3',$L_fonts[3]),
                    array('4',$L_fonts[4]),
                    array('5',$L_fonts[5]),
                    
                )),
            $avthumb_cache['avthumb_text_fontname'],'select','',0,lang(P_NAME, 'oss_avthumb_fontname_comment')
            );
        showsetting(lang(P_NAME, 'oss_avthumb_fontsize'), 'avthumbtextfontsize',$avthumb_cache['avthumb_text_fontsize'],'number',0,0,lang(P_NAME, 'oss_avthumb_fontsize_comment'));
        showsetting(lang(P_NAME, 'oss_avthumb_color'), 'avthumbtextcolor',$avthumb_cache['avthumb_text_color'],'color',0,0,lang(P_NAME, 'oss_avthumb_color_comment'));
        
        showsetting(lang(P_NAME, 'oss_avthumb_HOffset'), 'avthumbHOffset', $avthumb_cache['avthumb_HOffset'],'number',0,0,lang(P_NAME, 'oss_avthumb_HOffset_comment'));
        showsetting(lang(P_NAME, 'oss_avthumb_VOffset'), 'avthumbVOffset', $avthumb_cache['avthumb_VOffset'],'number',0,0,lang(P_NAME, 'oss_avthumb_VOffset_comment'));
        
        $var =  array('title'=>lang(P_NAME,'oss_avthumb_groups'),
                      'type' => 'groups',
            'description' => lang(P_NAME,'oss_avthumb_groups_comment'),
                      'variable' => 'avthumbgroups',
                      'value' =>  $avthumb_cache['avthumb_groups'],
        );
        show_groups($var);
       
        showtagfooter('tbody');
        showtablefooter(); /*dism��taobao��com*/
        showsubmit('set_submit');
        showformfooter();
    }else{
       
        $avthumb_cache = array(
            'avthumb_allow'         => $_GET['avthumballow'],
            'avthumb_ext'           => $_GET['avthumbext'],
            'avthumb_width'         => $_GET['avthumbwidth'],
            'avthumb_height'        => $_GET['avthumbheight'],
            'avthumb_pic'           => $_GET['avthumbpic'],
            'avthumb_pic_pos'       => $_GET['avthumbpicpos'],
            'avthumb_text'          => $_GET['avthumbtext'],
            'avthumb_text_pos'      => $_GET['avthumbtextpos'],
            'avthumb_text_fontname' => $_GET['avthumbtextfontname'],
            'avthumb_text_fontsize' => $_GET['avthumbtextfontsize'],
            'avthumb_text_color'    => $_GET['avthumbtextcolor'],
            'avthumb_HOffset'       => $_GET['avthumbHOffset'],
            'avthumb_VOffset'       => $_GET['avthumbVOffset'],
            'avthumb_groups'        => serialize($_GET['avthumbgroups']),
        );
        
        savecache('boan_oss_avthumb_cache',$avthumb_cache);
        cpmsg('plugins_edit_succeed', 'action=plugins&operation=config&do='.$pluginid.'&pmod=avthumb', 'succeed');
    }
}


function show_forums($var){
    $var['description'] = ($var['description'] ? (isset($lang[$var['description']]) ? $lang[$var['description']] : $var['description'])."\n" : '').$lang['plugins_edit_vars_multiselect_comment']."\n".$var['comment'];
    $var['value'] = dunserialize($var['value']);
    $var['value'] = is_array($var['value']) ? $var['value'] : array();
    require_once libfile('function/forumlist');
    $var['type'] = '<select name="'.$var['variable'].'[]" size="10" multiple="multiple"><option value="">'.cplang('plugins_empty').'</option>'.forumselect(FALSE, 0, 0, TRUE).'</select>';
    foreach($var['value'] as $v) {
        $var['type'] = str_replace('<option value="'.$v.'">', '<option value="'.$v.'" selected>', $var['type']);
    }
    $var['variable'] = $var['value'] = '';
    showsetting(isset($lang[$var['title']]) ? $lang[$var['title']] : dhtmlspecialchars($var['title']), $var['variable'], $var['value'], $var['type'], '', 0, isset($lang[$var['description']]) ? $lang[$var['description']] : nl2br(dhtmlspecialchars($var['description'])), dhtmlspecialchars($var['extra']), '', true);
}


function show_groups($var){
    if($var['type'] == 'groups') {
        $var['description'] = ($var['description'] ? (isset($lang[$var['description']]) ? $lang[$var['description']] : $var['description'])."\n" : '').$lang['plugins_edit_vars_multiselect_comment']."\n".$var['comment'];
        $var['value'] = dunserialize($var['value']);
        $var['type'] = '<select name="'.$var['variable'].'[]" size="10" multiple="multiple"><option value=""'.(@in_array('', $var['value']) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>';
    } else {
        $var['type'] = '<select name="'.$var['variable'].'"><option value="">'.cplang('plugins_empty').'</option>';
    }
    $var['value'] = is_array($var['value']) ? $var['value'] : array($var['value']);
    
    $query = C::t('common_usergroup')->range_orderby_credit();
    $groupselect = array();
    foreach($query as $group) {
        $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
        $groupselect[$group['type']] .= '<option value="'.$group['groupid'].'"'.(@in_array($group['groupid'], $var['value']) ? ' selected' : '').'>'.$group['grouptitle'].'</option>';
    }
    $var['type'] .= '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
        ($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
        ($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
        '<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup></select>';
        $var['variable'] = $var['value'] = '';
        
  showsetting(isset($lang[$var['title']]) ? $lang[$var['title']] : dhtmlspecialchars($var['title']), $var['variable'], $var['value'], $var['type'], '', 0, isset($lang[$var['description']]) ? $lang[$var['description']] : nl2br(dhtmlspecialchars($var['description'])), dhtmlspecialchars($var['extra']), '', true);
}


