
function BoanH5upload(){
	try{
		
	}catch(e){
	}
}




boanH5upload = new BoanH5upload();
var boan_img = null;


for(i=0;i<$("img").length;i++){
	if($("img")[i].src.indexOf('boan_h5avatar')>-1){
		boan_img = $('img')[i];
		if($('body').hasClass('comiis_bodybg')){
			$(boan_img).parent().is('a') && set_avatar(boan_img);
		}else {
			set_avatar(boan_img);
		}
		
	}
}

if(window.location.href.indexOf('t=')>-1){
	//如果是修改头像后返回，则向服务器发送请缓存请求
	$.ajax({url:"plugin.php?id=boan_h5upload:ajax&avatar=yes"});
}

function set_avatar(boan_img){
	var border_radius = $(boan_img).css('border-radius');
	var width = $(boan_img).css('width');
	var height = $(boan_img).css('height');
	var box_shadow = $(boan_img).css('box-shadow');
	var boan_str = '<div style="' ;
	width && width !='0px' && (boan_str += 'width:'  + width  +';');
	height && height !='0px' && (boan_str += 'height:'  + height +';');
	border_radius && (boan_str += 'border-radius:'  + border_radius +';');
	box_shadow  && (boan_str += 'box-shadow:'  + box_shadow +';');
	boan_str += 'display:block;overflow:hidden;position: relative;left: 50%;transform: translateX(-50%);';
	boan_str += '"></div>';
	$(boan_img).wrap(boan_str);
	
	
	$("<style type='text/css'> .boan_water{position: absolute;bottom:0px;left:0;width:100%;height:25px;line-height:24px;background: rgba(0,0,50,0.40);text-shadow: 3px 2px 3px #000;font-size: 12px;color: #FFF;text-align: center;} </style>").appendTo("head");
	
	$(boan_img).parent().append('<div class="boan_water">修改</div>');
	
	$(boan_img).parent().on('click',function(event){
		event.stopPropagation();
		event.preventDefault(); 
		//$(this).parent().attr('href','javascript:;');
		window.location.href = 'plugin.php?id=boan_h5upload:mavatar&mobile=2';
	});
}





