
var boanh5_qrcode_img = {timeflag : true,posttime : $('posttime').value};
var boanh5_posttime = $('posttime').value;
var remotestatus = false;
boanh5_updateimg = new Array();
function boan_addpost(file,key,val){
		file.post || (file.post = new Array());
		
		file.post.push(key + '|' + val);
}


function addUploadEvent(imgid, proid){
	 
	upload_url = imgUpload.settings['upload_url'];
	upload_url = upload_url.replace('operation=upload','operation=poll');
	 
	 temp = WebUploader.create({
		server:upload_url,
		formData:imgUpload.settings['post_params'],
		swf:'source/plugin/boan_h5upload/image/Uploader.swf',
		pick:{id:'#' + imgid},
		fileVal:'Filedata',
		accept:{
			title:imgUpload.settings['file_types_description'],
			extensions:imgUpload.settings['file_types'].replace(/\*\./g,'').replace(/;/g,','),
			mimeTypes: 'image/*',
		},
		fileSingleSizeLimit:imgUpload.settings['file_size_limit']*1024,
		resize:true,
		});
	temp.progressTarget = proid;
	temp.uploadType = 'poll';
	temp.on('beforeFileQueued',function(file){
			return boanH5upload.beforeFileQueued('poll',file,this);
	});
	temp.on('error', function(err_num){
		var MSG = {
			F_EXCEED_SIZE : boan_h5upload_lang['Q_EXCEED_SIZE_LIMIT'],
			Q_TYPE_DENIED : boan_h5upload_lang['Q_TYPE_DENIED'],
			
		};
		alert(MSG[err_num] ? MSG[err_num] : err_num);
	});	
	temp.on('fileQueued',function(file){
		boanH5upload.fileQueued('poll',file,this);
		this.upload();
	});	
	temp.on( 'uploadBeforeSend', function( object, data,header ) {
       // 修改data可以控制发送哪些携带数据。
      if(object.file.post){
		   for(var i = 0 ; i < object.file.post.length;i++){
			 var v = object.file.post[i].split('|');
			 eval('data.' + v[0] + '="' + v[1] + '"');
		   }
	  }
	  delete data.lastModifiedDate;
	  delete data.name;
    });
	temp.on('uploadStart',function(file){
		try {
			boan_addpost(file,'filetype','.'+file.ext);	
		} catch (ex) {
		}
	});
	
	temp.on( 'uploadSuccess', function( file,response) {
		boanH5upload.uploadSuccess('img',file,response,this);
	});
	
	temp.on( 'uploadError', function( file ) {
		alert(boan_h5upload_lang['up_error']);
	});
}

function BoanH5upload(){
	try{
		var objA = $('attach_confirms').parentNode.parentNode;
		var statusObj = document.createElement('div');
		var copyrightObj = document.createElement('div');
		
		statusObj.style.display = '';
		statusObj.id = 'boan_h5upload_status';
	
		statusObj.style.textAlign="center";
		statusObj.style.height='28px';
		statusObj.style.fontSize='14px';
		$('attach_confirms').style.float="right";
		
		$('attach_confirms').parentNode.appendChild(statusObj);
		
		objA = $(editorid + '_imgattachlist');
		imgstatusObj = $('boan_h5upload_status').cloneNode(true);
		imgstatusObj.id = 'boan_h5upload_imgstatus';
		objA.firstElementChild.nextElementSibling.firstElementChild.style.float = 'right';
		objA.firstElementChild.nextElementSibling.appendChild(imgstatusObj);
	}catch(e){
	}
}


BoanH5upload.prototype.fileQueueError = function(errorCode,obj) {
	try {
		var err = '';
		switch (errorCode) {
		case 'F_EXCEED_SIZE':
			err = boan_h5upload_lang['F_EXCEED_SIZE'] + WebUploader.Base.formatSize(obj.options['fileSingleSizeLimit']) + '！';
			break;
		case 'Q_EXCEED_NUM_LIMIT':
			err = boan_h5upload_lang['Q_EXCEED_NUM_LIMIT'] + obj.options['fileNumLimit'] + boan_h5upload_lang['one'] + '！';
			break;
		case 'Q_EXCEED_SIZE_LIMIT':
			err = boan_h5upload_lang['Q_EXCEED_SIZE_LIMIT'] + WebUploader.Base.formatSize(obj.options['fileSizeLimit']) + '！';
			break;
		case 'Q_TYPE_DENIED':
			err = boan_h5upload_lang['Q_TYPE_DENIED'];
			break;
		case 'F_DUPLICATE':
			err = boan_h5upload_lang['F_DUPLICATE'];
			break;
		default:
			err = boan_h5upload_lang['up_error'] + code;
			break;
		}
		showDialog(err, 'notice', null, null, 0, null, null, null, null, sdCloseTime);
	} catch (ex) {
        console.log(ex);
    }
}

BoanH5upload.prototype.getMimes = function(file_types){
	EXT_MIME_MAP = {
	'3gp': 'video/3gpp',
	'7z': 'application/x-7z-compressed',
	'aac': 'audio/aac',
	'abw': 'application/x-abiword',
	'arc': 'application/x-freearc',
	'avi': 'video/x-msvideo',
	'apk': 'application/vnd.android.package-archive',
	'azw': 'application/vnd.amazon.ebook',
	'bin': 'application/octet-stream',
	'bmp': 'image/bmp',
	'bz': 'application/x-bzip',
	'bz2': 'application/x-bzip2',
	'bzip2': 'application/x-bzip2',
	'chm': 'application/vnd.ms-htmlhelp',
	'csh': 'application/x-csh',
	'css': 'text/css',
	'csv': 'text/csv',
	'doc': 'application/msword',
	'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
	'eot': 'application/vnd.ms-fontobject',
	'epub': 'application/epub+zip',
	'flv': 'video/x-flv',
	'gif': 'image/gif',
	'gz': 'application/gzip',
	'htm': 'text/html',
	'html': 'text/html',
	'ico': 'image/vnd.microsoft.icon',
	'ics': 'text/calendar',
	'jar': 'application/java-archive',
	'jpeg': 'image/jpeg',
	'jpg': 'image/jpeg',
	'js': 'text/javascript',
	'json': 'application/json',
	'jsonld': 'application/ld+json',
	'm4a': 'audio/mp4',
	'mid': 'audio/midi',
	'midi': 'audio/midi',
	'mjs': 'text/javascript',
	'mov': 'video/quicktime',
	'mkv': 'video/x-matroska',
	'mp3': 'audio/mpeg',
	'mp4': 'video/mp4',
	'mp4a': 'audio/mp4',
	'mp4v': 'video/mp4',
	'mpeg': 'video/mpeg',
	'mpkg': 'application/vnd.apple.installer+xml',
	'odp': 'application/vnd.oasis.opendocument.presentation',
	'ods': 'application/vnd.oasis.opendocument.spreadsheet',
	'odt': 'application/vnd.oasis.opendocument.text',
	'oga': 'audio/ogg',
	'ogv': 'video/ogg',
	'ogx': 'application/ogg',
	'opus': 'audio/opus',
	'otf': 'font/otf',
	'pdf': 'application/pdf',
	'php': 'application/php',
	'png': 'image/png',
	'ppt': 'application/vnd.ms-powerpoint',
	'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
	'rar': 'application/x-rar-compressed',
	'rtf': 'application/rtf',
	'sh': 'application/x-sh',
	'svg': 'image/svg+xml',
	'swf': 'application/x-shockwave-flash',
	'tar': 'application/x-tar',
	'tif': 'image/tiff',
	'tiff': 'image/tiff',
	'ts': 'video/mp2t',
	'ttf': 'font/ttf',
	'txt': 'text/plain',
	'vsd': 'application/vnd.visio',
	'wav': 'audio/wav',
	'wma': 'audio/x-ms-wma',
	'wmv': 'video/x-ms-asf',
	'weba': 'audio/webm',
	'webm': 'video/webm',
	'webp': 'image/webp',
	'woff': 'font/woff',
	'woff2': 'font/woff2',
	'xhtml': 'application/xhtml+xml',
	'xls': 'application/vnd.ms-excel',
	'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
	'xml': 'application/xml',
	'xul': 'application/vnd.mozilla.xul+xml',
	'zip': 'application/zip'
	};
	
	var exts = "",
		mimes = "";
	if(file_types.indexOf('*.*') < 0) {
		exts = file_types.replace(/\*\./g, '').replace(/;/g, ',');
		var extsArray = jQuery.grep(exts.split(','), function (s) {
			return s.length > 0
		});
		
		exts = jQuery.grep(
			extsArray, 
			function (s) {
				return s.length > 0
			}
		).join(",");
		
		
		mimes = jQuery.grep(
			jQuery.merge(
				jQuery.map(extsArray, function (ext) {
					return "." + ext;
				}),
				jQuery.map(extsArray, function (ext) {
					return EXT_MIME_MAP[ext];
				})
			),
			function (s) {
				return s.length > 0
			}
		);
		
		mimes = jQuery.grep(mimes, function (m, i) {
			return i === jQuery.inArray(m, mimes)
		}).join(",")
			
   }
	return {'mimes':mimes,'exts':exts};
}

BoanH5upload.prototype.beforeFileQueued = function(prefix,file,otherObj){
	var upObj = prefix ? imgUpload : upload;
	if(upObj.customSettings.uploadSource == 'forum') {
		upObj.customSettings.alertType = 0;
		if(upObj.customSettings.uploadFrom == 'fastpost') {
			if(typeof forum_post_inited == 'undefined') {
				appendscript(JSPATH + 'forum_post.js?' + VERHASH);
			}
		}
	}
	createQueue = true;
	
	if(upObj.customSettings.uploadSource == 'forum' && prefix == 'poll') {
			var inputObj = $(otherObj.progressTarget+'_aid');
			if(inputObj && parseInt(inputObj.value)) {
				boan_addpost(file,'aid',inputObj.value);
			}
	} 
	
	if(upObj.customSettings.uploadSource == 'forum') {
		if(upObj.customSettings.maxAttachNum != undefined) {
			if(upObj.customSettings.maxAttachNum > 0) {
				upObj.customSettings.maxAttachNum--;
			} else {
				upObj.customSettings.alertType = 6;
				createQueue = false;
				alert(STATUSMSG[6]);
			}
		}

		if(createQueue && upObj.customSettings.maxSizePerDay != undefined) {
			if(upObj.customSettings.maxSizePerDay - file.size > 0) {
				upObj.customSettings.maxSizePerDay = upObj.customSettings.maxSizePerDay - file.size;
			} else {
				upObj.customSettings.alertType = 11;
				createQueue = false;
				alert(STATUSMSG[11]);
			}
		}
		if(createQueue && upObj.customSettings.filterType != undefined) {
			var fileSize = upObj.customSettings.filterType[file.ext.substr(1).toLowerCase()];
			if(fileSize != undefined && fileSize && file.size > fileSize) {
				upObj.customSettings.alertType = 5;
				createQueue = false;
				alert(STATUSMSG[5]);
			}
		}
	}
	if(file.ext=='png' && boan_h5upload_ispng){
		file.type='image/jpeg'
		file.source.type='image/jpeg'
	}
	
	return createQueue;
	
}


BoanH5upload.prototype.filenamecheck = function(filename){
 var patt =/[><"()']/i;
 return  patt.test(filename);
}

BoanH5upload.prototype.fileQueued = function(prefix,file,Obj){
	var upObj = prefix ? imgUpload : upload;
	
	if(upObj.customSettings.uploadSource == 'forum' && prefix == 'poll') {
		var preObj = $(Obj.progressTarget);
		preObj.style.display = 'none';
		preObj.innerHTML = '';
		return;
	}
		
	var progress = new FileProgress(file, upObj.customSettings.progressTarget);
	progress.setStatus(boan_h5upload_lang['wait_up']);
	
	progress.toggleCancel = function (show, swfUploadInstance) {
		this.fileProgressElement.childNodes[0].style.visibility = show ? "visible" : "hidden"; //设置是否显示取消按钮
		if (swfUploadInstance) {
			var fileID = this.fileProgressID;
			that = this;
			this.fileProgressElement.childNodes[0].onclick = function () {
				swfUploadInstance.removeFile(fileID);
				that.setCancelled();
				return false;
			};
		}
	};
	progress.toggleCancel(true,Obj);
	
	if(upObj.customSettings.uploadType == 'attach') {
		try {
			    $('attach_tblheader').style.display = '';
				$('attach_notice').style.display = '';
		} catch (ex) {}
	} else if(upObj.customSettings.uploadType == 'image') {
		try {
			$('imgattach_notice').style.display = '';
		} catch (ex) {}
	}
	var objId = upObj.customSettings.uploadType == 'attach' ? 'attachlist' : 'imgattachlist';
	var listObj = $(objId);
	var tableObj = listObj.getElementsByTagName("table");
	if(!tableObj.length) {
		listObj.innerHTML = "";
	}
	
	var rFilter = /^(image\/jpeg|image\/png|image\/jpg|image\/gif|image\/jpe)$/i; // 检查图片格式
	if ((rFilter.test(file.type) && file.source.source !== undefined) && !(($(editorid+'_image_menu').style.display == 'none' || $(editorid+'_image_menu').style.visibility == 'hidden')) && file.name != 'image.png') {
		new Boan_EXIF(Obj,file);
		
	}else{
		Obj.upload(file);
	}
	
}

BoanH5upload.prototype.uploadSuccess = function(prefix,file,response,Obj){
	
	try {
		var upObj = prefix ? imgUpload : upload;
		upload_url = window.location.protocol+'//'+window.location.host+'/';
		if(Obj.uploadType != 'poll'){
			var progress = new FileProgress(file, upObj.customSettings.progressTarget);
		}
	
		if(upObj.customSettings.uploadSource == 'forum') {
			if(Obj.uploadType == 'poll') {
				var data = response;
				if(parseInt(data.aid)) {
					var preObj = $(Obj.progressTarget);
					preObj.innerHTML = "";
					preObj.style.display = '';
					var img = new Image();
					img.src = IMGDIR + '/attachimg_2.png';//data.smallimg;
					var imgObj = document.createElement("img");
					imgObj.src = img.src;
					imgObj.className = "cur1";
					imgObj.onmouseout = function(){hideMenu('poll_img_preview_'+data.aid+'_menu');};//"hideMenu('poll_img_preview_"+data.aid+"_menu');";
					imgObj.onmouseover = function(){showMenu({'menuid':'poll_img_preview_'+data.aid+'_menu','ctrlclass':'a','duration':2,'timeout':0,'pos':'34'});};//"showMenu({'menuid':'poll_img_preview_"+data.aid+"_menu','ctrlclass':'a','duration':2,'timeout':0,'pos':'34'});";
					preObj.appendChild(imgObj);
					var inputObj = document.createElement("input");
					inputObj.type = 'hidden';
					inputObj.name = 'pollimage[]';
					inputObj.id = Obj.progressTarget+'_aid';
					inputObj.value= data.aid;
					preObj.appendChild(inputObj);
					var preImgObj = document.createElement("span");
					preImgObj.style.display = 'none';
					preImgObj.id = 'poll_img_preview_'+data.aid+'_menu';
					img = new Image();
					img.src = data.smallimg;
					imgObj = document.createElement("img");
					imgObj.src = img.src;
					preImgObj.appendChild(imgObj);
					preObj.appendChild(preImgObj);
				}
			}else{	
				aid = parseInt(response);
				if(aid > 0) {
					if(upObj.customSettings.uploadType == 'attach') {
						ajaxget('forum.php?mod=ajax&action=attachlist&aids=' + aid + (!fid ? '' : '&fid=' + fid)+(typeof resulttype == 'undefined' ? '' : '&result=simple'), file.id);
					} else if(upObj.customSettings.uploadType == 'image') {
						var tdObj = getInsertTdId(upObj.customSettings.imgBoxObj, 'image_td_'+aid);
						ajaxget('forum.php?mod=ajax&action=imagelist&type=single&pid=' + pid + '&aids=' + aid + (!fid ? '' : '&fid=' + fid),tdObj.id);
						$(file.id).style.display = 'none';
					}
				} else {
					aid = aid < -1 ? Math.abs(aid) : aid;
					if(typeof STATUSMSG[aid] == "string") {
						progress.setStatus(STATUSMSG[aid]);
						showDialog(STATUSMSG[aid], 'notice', null, null, 0, null, null, null, null, sdCloseTime);
					} else {
						progress.setStatus(boan_h5upload_lang['cancel_up']);
					}
					
					progress.setCancelled();
					Obj.removeFile(file.id);
					progress.toggleCancel(false);		
				}
		  }
		} else {
			progress.setComplete();
			progress.setStatus(boan_h5upload_lang['ok_up']);
			progress.toggleCancel(false);
		}
	} catch (ex) {
		alert(ex.message);
	}
}

BoanH5upload.prototype.m = new Map();

BoanH5upload.prototype.get_signature =function(file,type){
	var obj = null;
	var url = 'plugin.php?id=boan_h5upload:ajax&oss=yes&type=forum&filename=';
	url += file.name.replace(/[\(\)'"<>]/g,'');
	var hash = '';
	if(typeof imgUpload !== 'undefined'){
		hash = imgUpload.settings['post_params']['hash'];
	}else{
		hash = upload.settings['post_params']['hash'];
	}
	url += '&hash='+ hash + '&atttype=' + type + '&ext=' + file.ext;
	boan_jq.ajax({
				type:"GET",
				url:url,
				async:false,
				success:function(data){
					if(data == -10 || data == 0){
						alert('up error');
					}else{ 
						 if(boan_h5upload_ossserver == 'tencent'){
						     obj = data;
						 }else{
						 	 data = data.substr(0,data.indexOf('}')+1);
							 obj = eval ("(" + data + ")");
						 }
					}
				},
				error:function(xhr,status,error){
					alert(error);
				},
	});
	return obj;
}


BoanH5upload.prototype.setH5 = function(){
	//设置附件上传
	var domin_pre = window.location.protocol+'//'+window.location.host+'/';
	var that = this;
	//var nodes = $(editorid+'_upload').childNodes;
	typeof(curoptions) == "undefined" && (curoptions = 0);
	 if(($('imgSpanButtonPlaceholder') || $('SWFUpload_0'))){
		//图片上传
		var nodes = $(editorid+'_imgattachlist').childNodes;
		newnode = $(editorid + '_btn_imgattachlist').firstElementChild;
		
		$(editorid+'_imgattachlist').style.padding = '3px 10px';
		
		$(editorid + '_imgattachlist').style.display = '';

		newnode = document.createElement('div');
		newnode.id = 'imguploader';
		newnode.className = 'boanh5-example';
		newnode.innerHTML = '<div id="thelist" class="uploader-list" style="clear: both; display:block;"><div class="btns" style="float:left;"><div id="imgPicker" >'
		+ boan_h5upload_lang['sel_file'] + '</div></div><div class="placeholder">'
		+ boan_h5upload_lang['explain_img'] + '</div><div style="float: right; position: relative;">'
		+ (boan_h5upload_isbasepic ? '<input type="checkbox" id="boanh5_baseimg" style="position: absolute; margin-top: 9px;" onclick="boanh5_baseimg(this);" ><label for="boanh5_baseimg" class="insertimg" style="margin-left: 20px; color:purple">' + boan_h5upload_lang['base_img'] + '</label>' : '')
		+ ' <span  class="insertimg"  onclick="boanh5_insertAll(0);">'
		+ boan_h5upload_lang['insert_left'] + '</span><span class="insertimg" onclick="boanh5_insertAll(1);">'
		+ boan_h5upload_lang['insert_center'] + '</span><span class="insertimg"   onclick="boanh5_insertAll(2);">'
		+ boan_h5upload_lang['insert_right'] + '</span><span class="insertimg"  style="margin-right:30px;" onclick="boanh5_insertAll(3);">'
		+ boan_h5upload_lang['insert_tile'] + '</span><span id="boanh5_limit"  class="insertimg" style="color:green" flag="0" onclick="boanh5_insertSort(1);">'
		+ boan_h5upload_lang['insert_old'] + '</span><span id="boanh5_insertSort" class="insertimg" title="'
		+ boan_h5upload_lang['set_img_order'] + '" style="color:green;cursor: pointer;" flag="0" onclick="boanh5_insertSort(0);">'
		+ boan_h5upload_lang['backward'] +  '</span><span id="boanh5_DelImgAll"  class="insertimg" title="'
		+ boan_h5upload_lang['del_img_all'] + '" style="color:red;" onclick="boanh5_DelImgAll()") >' + boan_h5upload_lang['del_img_all'] + '</span></div></div>';
	    
		rnode = $('imgSpanButtonPlaceholder');
		rnode || (rnode = $('SWFUpload_' +  parseInt(curoptions)));
		rnode.parentNode.replaceChild(newnode,rnode);
		
		boan_jq('#imgattachlist').attr('title',boan_h5upload_lang['drop_order']);
		//upload_url= domin_pre + imgUpload.settings['upload_url'].substr(imgUpload.settings['upload_url'].indexOf('misc.php'));
		if(boan_h5upload_ossserver && boan_h5upload_img_hlongup){
			upload_url = boan_h5upload_hlongurl;
			var fileVal = 'file'; //'Filedata'
			
		}else{
			upload_url = imgUpload.settings['upload_url'];
			var fileVal = 'Filedata'; 
		}
		
		
		var exts = this.getMimes(imgUpload.settings['file_types']).exts;
		var mimes = this.getMimes(imgUpload.settings['file_types']).mimes;
		try{
			var paste = $(editorid+'_iframe').contentDocument.body;
		}catch(e){
			var paste = $(editorid+'_textarea');
		}
		
		var imgUploader = WebUploader.create({
			server:upload_url,
			formData:imgUpload.settings['post_params'],
			swf:'source/plugin/boan_h5upload/image/Uploader.swf',
			pick:{id:'#imgPicker'},
			fileVal:fileVal,
			dnd: '#thelist .placeholder',
			paste: paste,
			disableGlobalDnd: true,
			compress:boan_h5upload_dispose,
			threads:1,
			accept:{
				title:imgUpload.settings['file_types_description'],
				extensions:exts,
				mimeTypes:mimes,
			},
			fileNumLimit:imgUpload.settings['file_upload_limit'],
			resize:boan_h5upload_dispose ? true : false,
		});
		
		
		boanh5_imguploader = imgUploader;
		//	fileSingleSizeLimit:imgUpload.settings['file_size_limit']*1024*5,
		//图片上传
		imgUploader.on('beforeFileQueued',function(file){
			return boanH5upload.beforeFileQueued('img',file,this);
		});
		imgUploader.on('error', function(err_num){
			that.fileQueueError(err_num,this);
		});
		
		imgUploader.on('fileQueued',function(file){
			boanH5upload.fileQueued('img',file,this);
		});
		
		imgUploader.on( 'uploadBeforeSend', function( object, data,headers ) {
		   // 修改data可以控制发送哪些携带数据。
		   data.type = 'image';
		   delete data.lastModifiedDate;
		   delete data.name;
		   if(object.file.post){
			 for(var i = 0 ; i < object.file.post.length;i++){
				 var v = object.file.post[i].split('|');
				 eval('data.' + v[0] + '="' + v[1] + '"');
			 }
		   }
		   
		   if(boan_h5upload_img_hlongup && boan_h5upload_ossserver == 'aliyun'){
				var data1 = that.get_signature(object.file,'image');		
				data = boan_jq.extend(data,{
					'key':data1.dir+data1.object,
					'policy' : data1.policy,
					'OSSAccessKeyId':data1.accessid, 
					'success_action_status':'200',
					'signature': data1.signature,
				});	
				object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
				object.file.objectname  =  data1.dir+data1.object;
		   }else if( boan_h5upload_img_hlongup && boan_h5upload_ossserver == 'qiniu'){
		   		var data1 = that.get_signature(object.file,'image');	 
				data = boan_jq.extend(data,{
					'key':data1.filename,
					'token' : data1.token,
				});	
				object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			    object.file.objectname  =  data1.filename;
		   }else if(boan_h5upload_img_hlongup && boan_h5upload_ossserver == 'tencent'){
			   var data1 = that.get_signature(object.file,'image');
			   var credentials = data1.credentials;
			   var Authorization = CosAuth({
							SecretId: credentials.tmpSecretId,
							SecretKey: credentials.tmpSecretKey,
							Method: 'POST',
							Pathname: '/',
						});
						
				
				data = boan_jq.extend(data,{
					'key' : data1.dir+data1.object,
					'x-cos-security-token' : credentials.sessionToken || '',
					'Signature' : Authorization,
					
				});	
			 
			   object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			   object.file.objectname  =  data1.dir+data1.object;   
		   }else if(boan_h5upload_img_hlongup && boan_h5upload_ossserver == 'huawei'){
		   	   var data1 = that.get_signature(object.file,'image');
			   data = boan_jq.extend(data,{
					'policy' : data1.policy,
					'AccessKeyId' : data1.accessid,
					'signature' : data1.signature,
					'Key': data1.dir+data1.object,
					'acl': data1.acl,
					'content-type':data1.contenttype,
					});
			   delete object.transport.options.formData.uid;
			   delete object.transport.options.formData.type;
			   delete object.transport.options.formData.hash;
			   delete data.uid;
			   delete data.size;
			   delete data.id;
			   delete data.type;
			   delete data.hash;
			   delete data.filetype;
			   object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			   object.file.objectname  =  data1.dir+data1.object; 
		   }
		});
		
		imgUploader.on('uploadProgress',function(file,percentage){
			try {
				if($(editorid+'_image_menu').style.display == 'none' || $(editorid+'_image_menu').style.visibility == 'hidden'){
					return ;
				}
				var progress = new FileProgress(file, imgUpload.customSettings.progressTarget);
				progress.setStatus(boan_h5upload_lang['uppercent'] + parseInt(percentage*100)+"%)...");
	
			} catch (ex) {
				
			}
		});
		
		imgUploader.on('uploadStart',function(file){
			try {
			
				if($(editorid+'_image_menu').style.display == 'none' || $(editorid+'_image_menu').style.visibility == 'hidden'){
					showDialog('<div id="screenpicinfo" style="padding:10px 10px;"><p class="mbn">' + boan_h5upload_lang['upwaiting'] + '</p><p><img src="' + STATICURL + 'image/common/uploading.gif" alt="" /></p></div>', 'info', '', null, 1);
				}else{
					
					var progress = new FileProgress(file,imgUpload.customSettings.progressTarget);
					progress.setStatus(boan_h5upload_lang['uping']);
				}
				boan_addpost(file,'filetype','.'+file.ext);
				if(imgUpload.customSettings.uploadSource == 'forum') {
					var objId = imgUpload.customSettings.uploadType == 'attach' ? 'attachlist' : 'imgattachlist';
					var attachlistObj = $(objId).parentNode;
					attachlistObj.scrollTop = $(file.id).offsetTop - attachlistObj.clientHeight;
				}
				   boanh5_qrcode_img.timeflag = false; 
			} catch (ex) {
			}
		
		});
		
		imgUploader.on( 'uploadSuccess', function( file,response) {
			
			if(boan_h5upload_img_hlongup ){
				var url = 'plugin.php?id=boan_h5upload:callback&type=forum&atttype=image&filename=' + encodeURI(file.name) + '&object=' + file.objectname +'&hash=' + imgUpload.settings['post_params']['hash'] + '&fid=' + fid;
				boan_jq.ajax({
						type:"GET",
						url:url,
						async:false,
						success:function(data){
							response = data;
						},
						error:function(xhr,status,error){
							alert(error);
							response = -10;
						},
				});
			}
			
			boanH5upload.uploadSuccess('img',file,response,this);
			boanh5_DropOrder()
			
			aid = response;
			if($(editorid+'_image_menu').style.display == 'none' || $(editorid+'_image_menu').style.visibility == 'hidden'){
				if(aid > 0){
					insertImg = function(aid){
						if($('image_' + aid)){
							insertAttachimgTag(aid);
							hideMenu('fwin_dialog','dialog');
							
						}else{
							setTimeout(function(){
							  insertImg(aid);
							},250);
						}
					}
					insertImg(aid);
				}
			}
			
		});
		
		imgUploader.on( 'uploadError', function( file ) {
			alert(boan_h5upload_lang['up_error']);
		});
		
		imgUploader.on( 'uploadComplete', function( file ) {
			//alert('上传完结');
		});
		
		imgUploader.on( 'uploadFinished', function( ) {
			boanh5_qrcode_img.posttime = boanh5_posttime+3;
			boanh5_qrcode_img.timeflag = true;
			
		});
		
		
	}
	 
	if(($('spanButtonPlaceholder') || $('SWFUpload_1'))){
		//附件上传
		$(editorid + '_attachlist').style.display = '';
		newnode = document.createElement('div');
		newnode.id = 'uploader';
		newnode.className = 'boanh5-example';
		newnode.innerHTML = '<div id="boanh5list" class="uploader-list"></div><div class="btns" style="float:left;"><div id="boanh5_picker">' 
		+ boan_h5upload_lang['sel_file'] + '</div></div><div id="boanh5_filedrag" class="placeholder">'
		+ boan_h5upload_lang['explain_file'] + '</div></div>';
		
		
		rnode = $('spanButtonPlaceholder');
		rnode || (rnode = $('SWFUpload_' +  parseInt(curoptions+1)));
		rnode.parentNode.replaceChild(newnode,rnode);	
		boan_jq('#uploader').parent().css('border-bottom','none');
		if(boan_h5upload_ossserver && boan_h5upload_att_hlongup){
			upload_url = boan_h5upload_hlongurl;
			var fileVal = 'file'; //'Filedata'
			var fileLimit = 3*1024*1024*1024;
		}else{
			upload_url = upload.settings['upload_url'];
			var fileVal = 'Filedata'; 
			var fileLimit = upload.settings['file_size_limit']*1024;
		}
			
	
		
		var exts = this.getMimes(upload.settings['file_types']).exts;
		var mimes = this.getMimes(upload.settings['file_types']).mimes;
		var uploader = WebUploader.create({
			server:upload_url,
			formData:upload.settings['post_params'],
			swf:'source/plugin/boan_h5upload/image/Uploader.swf',
			pick:{id:'#boanh5_picker'},
			fileVal: fileVal,
			dnd:'#boanh5_filedrag',
			accept:{
				title:upload.settings['file_types_description'],
				extensions:exts,
				mimeTypes:mimes,
			},
			compress:boan_h5upload_dispose,
			fileSingleSizeLimit:fileLimit,
			fileNumLimit:upload.settings['file_upload_limit'],
			resize:boan_h5upload_dispose ? true : false,
		});
		
		//附件上传
		uploader.on('beforeFileQueued',function(file){
			return boanH5upload.beforeFileQueued('',file);
		});
		
		
		uploader.on('error', function(err_num){
			that.fileQueueError(err_num,this);
		});
		
		uploader.on('fileQueued',function(file){
			boanH5upload.fileQueued('',file,this);
		});
		
		uploader.on( 'uploadBeforeSend', function( object, data,header ) {
		   // 修改data可以控制发送哪些携带数据。
		  if(object.file.post){
			   for(var i = 0 ; i < object.file.post.length;i++){
				 var v = object.file.post[i].split('|');
				 eval('data.' + v[0] + '="' + v[1] + '"');
			   }
		  }
		  delete data.lastModifiedDate;
		  delete data.name;
		   if(boan_h5upload_att_hlongup && boan_h5upload_ossserver == 'aliyun'){
				var data1 = that.get_signature(object.file,'attach');		
				data = boan_jq.extend(data,{
					'key':data1.dir+data1.object,
					'policy' : data1.policy,
					'OSSAccessKeyId':data1.accessid, 
					'success_action_status':'200',
					'signature': data1.signature,
				});	
				object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
				object.file.objectname  = data1.dir+data1.object;
		   }else if( boan_h5upload_att_hlongup && boan_h5upload_ossserver == 'qiniu'){
		   		var data1 = that.get_signature(object.file,'attach');	 
				data = boan_jq.extend(data,{
					'key':data1.filename,
					'token' : data1.token,
				});	
				
				object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			    object.file.objectname  =  data1.filename;
		   }else if(boan_h5upload_att_hlongup && boan_h5upload_ossserver == 'tencent'){
			   var data1 = that.get_signature(object.file,'attach');
			   var credentials = data1.credentials;
			   var Authorization = CosAuth({
							SecretId: credentials.tmpSecretId,
							SecretKey: credentials.tmpSecretKey,
							Method: 'POST',
							Pathname: '/',
						});
						
				
				data = boan_jq.extend(data,{
					'key' : data1.dir+data1.object,
					'x-cos-security-token' : credentials.sessionToken || '',
					'Signature' : Authorization,
					
				});	
			 
			   object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			   object.file.objectname  =  data1.dir+data1.object;   
		   }else if(boan_h5upload_att_hlongup && boan_h5upload_ossserver == 'huawei'){
		   	   var data1 = that.get_signature(object.file,'image');
			   data = boan_jq.extend(data,{
					'policy' : data1.policy,
					'AccessKeyId' : data1.accessid,
					'signature' : data1.signature,
					'Key': data1.dir+data1.object,
					'acl': data1.acl,
					'content-type':data1.contenttype,
					});
			   delete object.transport.options.formData.uid;
			   delete object.transport.options.formData.type;
			   delete object.transport.options.formData.hash;
			   delete data.uid;
			   delete data.size;
			   delete data.id;
			   delete data.type;
			   delete data.hash;
			   delete data.filetype;
			   object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			   object.file.objectname  =  data1.dir+data1.object; 
		   }
		   
		});
	
		uploader.on('uploadProgress',function(file,percentage){
			try {
				var progress = new FileProgress(file, upload.customSettings.progressTarget);
				progress.setStatus(boan_h5upload_lang['uppercent'] + parseInt(percentage*100)+"%)...");
	
			} catch (ex) {
				
			}
		});
		
		uploader.on('uploadStart',function(file){
			try {
				var progress = new FileProgress(file,upload.customSettings.progressTarget);
				boan_addpost(file,'filetype',file.ext);
				progress.setStatus(boan_h5upload_lang['uping']);
				if(upload.customSettings.uploadSource == 'forum') {
					var objId = upload.customSettings.uploadType == 'attach' ? 'attachlist' : 'imgattachlist';
					var attachlistObj = $(objId).parentNode;
					attachlistObj.scrollTop = $(file.id).offsetTop - attachlistObj.clientHeight;
				}
			} catch (ex) {
			}
		});
		
		uploader.on( 'uploadSuccess', function( file,response) {
			if(boan_h5upload_att_hlongup ){
				
				var url = 'plugin.php?id=boan_h5upload:callback&type=forum&atttype=attach&filename=' + encodeURI(file.name) + '&object=' + file.objectname +'&hash=' + upload.settings['post_params']['hash'];
				boan_jq.ajax({
						type:"GET",
						url:url,
						async:false,
						success:function(data){
							response = data;
						},
						error:function(xhr,status,error){
							alert(error);
							response = -10;
						},
				});
			}
			
			boanH5upload.uploadSuccess('',file,response,this);
			if(typeof boan_attachview_upload === 'function' && response > 0 &&  (boan_h5upload_ossserver != 'tencent')){
				boan_attachview_upload(file,response);
			}
		});
		
		uploader.on( 'uploadError', function( file ) {
			alert(boan_h5upload_lang['up_error']);
		});
		
		uploader.on( 'uploadComplete', function( file ) {
			//alert('上传完结');
		});
		
		if(boan_h5upload_isbig){
			//大附件上传功能
			var tempstr = '<li  id="e_btn_bigattachlist" ><a href="javascript:;" hidefocus="true" onclick="';
			tempstr += 'switchAttachbutton(' + "'bigattachlist')";
			tempstr += '">' + boan_h5upload_lang['upbig'] + '</a></li>';
			boan_jq('#e_attach_ctrl').append(tempstr);
			tempstr = '<div class="p_opt" unselectable="on" id="e_bigattachlist" style="display: none;">';
			tempstr += '<div class="pbm bbda"><div class="boanh5-example"><div class="btns"><div id="boanh5big_picker">' + boan_h5upload_lang['sel_bigfile'] + '</div></div></div></div>';
			tempstr += '</div>'
			boan_jq('#e_attach_ctrl').parent().append(tempstr);
			
			boan_jq('#e_btn_bigattachlist a,#e_btn_attachlist a').on("click",function(){
				var current_btn = boan_jq(this).parent().attr('id');
				var table = boan_jq('#attach_tblheader');
				var uplist = current_btn == 'e_btn_bigattachlist' ? boan_jq('#e_attachlist .upfl') : boan_jq('#e_bigattachlist .upfl');
				var notice = current_btn == 'e_btn_bigattachlist' ? boan_jq('#e_attachlist .notice') : boan_jq('#e_bigattachlist .notice');
				if(current_btn == 'e_btn_bigattachlist' && boan_jq('#e_bigattachlist .upfl').length == 0){
					boan_jq('#e_bigattachlist').append(table);
					boan_jq('#e_bigattachlist').append(uplist);
					boan_jq('#e_bigattachlist').append(notice);
					
				}else if(current_btn == 'e_btn_attachlist' && boan_jq('#e_attachlist .upfl').length == 0){
					boan_jq('#e_attachlist').append(table);
					boan_jq('#e_attachlist').append(uplist);
					boan_jq('#e_attachlist').append(notice);
				}
				
			});
			//校正
			boan_jq('#postsubmit').on('click',function(){
					if(boan_jq('#e_attachlist .upfl').length == 0){
						var table = boan_jq('#attach_tblheader');
						var uplist = boan_jq('#e_bigattachlist .upfl');
						var notice = boan_jq('#e_bigattachlist .notice');
						boan_jq('#e_attachlist').append(table);
						boan_jq('#e_attachlist').append(uplist);
						boan_jq('#e_attachlist').append(notice);
					}
			});
			
			
			var exts = this.getMimes(upload.settings['file_types']).exts;
			var mimes = this.getMimes(upload.settings['file_types']).mimes;
			var big_uploader = WebUploader.create({
				server:'plugin.php?id=boan_h5upload:bigfileuploader&boanh5op=upload',
				formData:upload.settings['post_params'],
				swf:'source/plugin/boan_h5upload/image/Uploader.swf',
				pick:{id:'#boanh5big_picker'},
				auto:true,
				chunked:true,
				chunkSize:2000*1024,
				accept:{
					title:upload.settings['file_types_description'],
					extensions:exts,
					mimeTypes:mimes,
				},
				duplicate :false,
				compress:boan_h5upload_dispose,
				fileSingleSizeLimit:3*1024*1024*1024,
				resize:boan_h5upload_dispose ? true : false,
			});
			
			big_uploader.on('uploadStart',function(file){
				try {
					var progress = new FileProgress(file,upload.customSettings.progressTarget);
					boan_addpost(file,'filetype',file.ext); 
					boan_addpost(file,'guid',WebUploader.guid());
					progress.setStatus(boan_h5upload_lang['uping']);
					if(upload.customSettings.uploadSource == 'forum') {
						var objId = upload.customSettings.uploadType == 'attach' ? 'attachlist' : 'imgattachlist';
						var attachlistObj = $(objId).parentNode;
						attachlistObj.scrollTop = $(file.id).offsetTop - attachlistObj.clientHeight;
					}
				} catch (ex) {
					console.log(ex);
				}
			});
				
			
			big_uploader.on('fileQueued',function(file){
				boanH5upload.fileQueued('',file,this);
			});
			
			big_uploader.on( 'uploadBeforeSend', function( object, data,header ) {
			   // 修改data可以控制发送哪些携带数据。
			  if(object.file.post){
				   for(var i = 0 ; i < object.file.post.length;i++){
					 var v = object.file.post[i].split('|');
					 eval('data.' + v[0] + '="' + v[1] + '"');
				   }
			  }
			  delete data.lastModifiedDate;
			  delete data.id;
			  delete data.name;
			 
			})
			
			big_uploader.on('error', function(err_num){
				that.fileQueueError(err_num,this);
			});
		
			big_uploader.on('uploadProgress',function(file,percentage){
				try {
					var progress = new FileProgress(file, upload.customSettings.progressTarget);
					progress.setStatus(boan_h5upload_lang['uppercent']+ parseInt(percentage*100)+"%)...");
		
				} catch (ex) {
					
				}
			});
			
			big_uploader.on('fileDequeued',function(file){
				//当强制取消时清除已经上传的切片
				try {
					var guid = '';
					for(i=0;i<file.post.length;i++){
					   var v = file.post[i].split('|');
					   if(v[0] == 'guid'){
						 guid = v[1];
						 break;
					   }
					}
					if(guid.length>0){
						ajaxget('plugin.php?id=boan_h5upload:bigfileuploader&boanh5op=delete&guid='+guid );
					}
		
				} catch (ex) {
					
				}
			});
			
			big_uploader.on( 'uploadSuccess', function( file,response) {
				boanH5upload.uploadSuccess('',file,response,this);
			});
			
			big_uploader.on( 'uploadError', function( file ) {
				alert(boan_h5upload_lang['up_error']);
			});
			
			big_uploader.on( 'uploadComplete', function( file ) {
				//alert('上传完结');
			});
		}		
	}
	
	var t = $('pollUploadProgress_0') ? 0 : 1;
	var sid = $('SWFUpload_0') ? 0 : 1;
	while($('pollUploadProgress_'+ t)){
	 $('SWFUpload_'+sid) &&  boan_jq('#SWFUpload_'+sid).replaceWith('<span id="newpoll_' + t + '" class="vm"></span>');	 
	 addUploadEvent('newpoll_' + t,'pollUploadProgress_' + t);
	 t++;
	 sid++;
	}	
}


BoanH5upload.prototype.getOs = function()  
{  
  try{
	   var browser = {
        versions: function () {
            var u = navigator.userAgent, app = navigator.appVersion;
            return {
                trident: u.indexOf('Trident') > -1, //IE内核
                presto: u.indexOf('Presto') > -1 || u.indexOf('OPR') > -1, //opera内核
                webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
                gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,//火狐内核
                mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
                ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
                android: u.indexOf('Android') > -1 || u.indexOf('Adr') > -1, //android终端
                iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器
                iPad: u.indexOf('iPad') > -1, //是否iPad
                webApp: u.indexOf('Safari') == -1, //是否web应该程序，没有头部与底部
                weixin: u.indexOf('MicroMessenger') > -1, //是否微信 （2015-01-22新增）
                qq: u.match(/\sQQ/i) == " qq" //是否QQ
            };
        }(),
        language: (navigator.browserLanguage || navigator.language).toLowerCase()
    };
	
    return browser;
  }catch(e){
	  alert(e.message);
  }
    
} 
BoanH5upload.prototype.check = function(){
	var img_flag = true;
	var attach_flag = true;
	//检测原图片附件按钮是否存在
	if(!($('imgSpanButtonPlaceholder') || $('SWFUpload_0'))){
		img_flag = false;
	}
	if(!($('spanButtonPlaceholder') || $('SWFUpload_1'))){
		attach_flag = false;
	}
	return img_flag || attach_flag;
	
}


boanH5upload = new BoanH5upload();
//为markd提供H5支持
if($('zxsq_editor_btn')){
	_attachEvent($('zxsq_editor_btn'), 'click', function(e){
		
		newnode = document.createElement('div');
		newnode.id = 'zxsquploader';
		newnode.className = 'boanh5-example';
		newnode.innerHTML = '<div id="zxsqlist" class="uploader-list" style="clear: both;"><div class="btns" style="float:left;margin-top:1px;height:16px;"><div id="zxsqPicker" >选择文件</div></div><div class="placeholder" style="font-size:16px;line-height:24px; float:none;">　文件拖拽到此处可上传。</div></div>'
	
		rnode = $('zxsqimgattachnew');
		
		rnode.parentNode.replaceChild(newnode,rnode);
		
		zxsqUploader = WebUploader.create({
			server:$('zxsqimgattachform').action.replace(/\&inajax\=1/g, "") + "&inajax=1",
			formData:imgUpload.settings['post_params'],
			pick:{id:'#zxsqPicker'},
			fileVal:'Filedata',
			dnd: '#zxsqlist .placeholder',
			paste:$('e_zxsq_editor_menu'),
			disableGlobalDnd: true,
			compress:boan_h5upload_dispose,
			accept:{
				title:imgUpload.settings['file_types_description'],
				extensions:imgUpload.settings['file_types'].replace(/\*\./g,'').replace(/;/g,','),
				mimeTypes: 'image/*',
			},
			fileSingleSizeLimit:imgUpload.settings['file_size_limit']*1024,
			resize:true,
		});
		
		zxsqUploader.on('error', function(err_num){
			var MSG = {
				F_EXCEED_SIZE : '文件太大',
				Q_TYPE_DENIED : '禁止上传此类型的文件',
				F_DUPLICATE	  : '此文件已经上传'
				
			};
			alert(MSG[err_num] ? MSG[err_num] : err_num);
		});
		
		zxsqUploader.on('beforeFileQueued',function(file){
			
			return true;
		});
		
		zxsqUploader.on( 'uploadBeforeSend', function( object, data,header ) {
		   // 修改data可以控制发送哪些携带数据。
		   data.type = 'image';
		   delete data.lastModifiedDate;
		   delete data.name;
		   if(object.file.post){
			 for(var i = 0 ; i < object.file.post.length;i++){
				 var v = object.file.post[i].split('|');
				 eval('data.' + v[0] + '="' + v[1] + '"');
			 }
		   }
		
		});
		
	   zxsqUploader.on('uploadStart',function(file){
			try {
				
			} catch (ex) {
			}
		
		});
		zxsqUploader.on('fileQueued',function(file){
			this.upload();
		});
		zxsqUploader.on( 'uploadSuccess', function( file,response) {
			
			try{
			ret = response;
			statusid = ret.picid;
			url = "![](" + ret.bigimg + ")";
			type = $("zxsq_editor_select").value;
			//alert(url);
			if (statusid > 0) {
				if (type == "md") {
					var a = simplemde.codemirror.getCursor();
					simplemde.codemirror.setSelection(a, a);
					simplemde.codemirror.replaceSelection(url)
				} else {
					var a = aceEditor.getCursorPosition();
					aceEditor.session.insert(a, url)
				}
			} else {
				$("zxsqimg_error").innerHTML = '<span style="color:red">' + zxsqEditorLang.uploaderror + maximagesize + 'KB</span>&nbsp;&nbsp;		<span id="zxsqimgtryagain"><a href="javascript:void(0)">' + zxsqEditorLang.tryagain + "</a></span>";
				$("zxsqimg_error").style.display = "block";
				$("zxsqimgattachform").style.display = "none";
				$("zxsqimgtryagain").onclick = function() {
					$("zxsqimgattachform").style.display = "block";
					$("zxsqimg_error").style.display = "none"
				}
			}}		
			catch(e){
				alert(e.message);
			}
		});
		
	});
}

//改进系统的远程图片本地化
boan_h5downremoteimg = function(event){

		showDialog('<div id="remotedowninfo"><p class="mbn">' + boan_h5upload_lang['downfile']  + '</p><p><img src="' + STATICURL + 'image/common/uploading.gif" alt="" /></p></div>', 'notice', '', null, 1);
		var message = wysiwyg ? html2bbcode(getEditorContents()) : (!editorform.parseurloff.checked ? parseurl(editorform.message.value) : editorform.message.value);
		var oldValidate = editorform.onsubmit;
		var oldAction = editorform.action;
	
		
		editorform.onsubmit = '';
		editorform.action = 'plugin.php?id=boan_h5upload:downremoteimg&fid='+fid+'&wysiwyg='+(wysiwyg ? 1 : 0);
		editorform.target = "ajaxpostframe";
		editorform.message.value = message;
		
		boanh5_qrcode_img.timeflag = false;
		editorform.submit();
		editorform.onsubmit = oldValidate;
		editorform.action = oldAction;
		editorform.target = "";
};
if($(editorid+'_downremoteimg')){
	$(editorid+'_downremoteimg').onclick  = boan_h5downremoteimg;
	$('ajaxpostframe').onload=function(){
		setTimeout(function(){
			parent.e_downremoteimg.onclick = parent.boan_h5downremoteimg
		},2000);
	}
}

//批量插图
function boanh5_insertAll(justify){
	var flag = $('boanh5_insertSort').getAttribute('flag');
	var limit = $('boanh5_limit').getAttribute('flag');
	var s = '';
	var jq_arr;
	var tile = (justify == 3) ? 1 : 0 ;
	var justify = (justify == 1 ||  justify == 3) ? 'justifycenter' : (justify == 2 ? 'justifyright' : 'justifyleft');
	if(boanH5upload.getOs().versions.trident){
		alert(boan_h5upload_lang['noie']);
		return ;
	}
	if(!wysiwyg) {
		alert(boan_h5upload_lang['notext']);
		return;
	}
	
	limit == 0 ? (jq_arr = boan_jq('.upfilelist .imgl:eq(1) td')) : (jq_arr = boan_jq('.upfilelist .imgl:eq(0) td'));
	jq_arr.length == 0 && (jq_arr = boan_jq('.upfilelist .imgl:eq(0) td'));
	flag == '0' || (jq_arr = boan_jq(jq_arr.toArray().reverse())); 
	jq_arr.each(function(index,td){   
		s = boan_jq(td).find('img:first').attr('id');
		if(s){
			s = s.substring(s.indexOf('_')+1);
			s = '<img src="' + $('image_' + s).src + '" border="0" aid="attachimg_' + s + '" alt="" />' + (tile == 0 ? '<br/><br/><br/>' : '');
			
			editdoc.execCommand(justify, false);
			insertText(s,false);
		}
	});

}
//设置插图顺序
function boanh5_insertSort(para){
	if(para == 0){
		var flag = $('boanh5_insertSort').getAttribute('flag');
		flag = flag == '0' ? '1' : '0';
		if(flag == '1'){
			$('boanh5_insertSort').innerText = boan_h5upload_lang['order'];
		}else{
			$('boanh5_insertSort').innerText =  boan_h5upload_lang['backward'];
		}
		 $('boanh5_insertSort').setAttribute('flag',flag);
	}else{
		var flag = $('boanh5_limit').getAttribute('flag');
		flag = flag == '0' ? '1' : '0';
		if(flag == '1'){
			$('boanh5_limit').innerText = boan_h5upload_lang['insert_new'];
		}else{
			$('boanh5_limit').innerText = boan_h5upload_lang['insert_old'];
		}
		 $('boanh5_limit').setAttribute('flag',flag);
	}
	
}

//原图上传控制

function boanh5_baseimg(obj){
	if(obj.checked){
		(typeof this.compress == 'undefined')  &&  (this.compress = boanh5_imguploader.options.compress);
		 boanh5_imguploader.option('compress',false);
		 boanh5_imguploader.option('resize',false);
	
	}else{
		 boanh5_imguploader.option('compress',this.compress);
		 boanh5_imguploader.option('resize',true);
	}
}

//一键删图
boan_indelimgall = 0;  
function boanh5_DelImgAll(){
	if(boanH5upload.getOs().versions.trident){
		alert(boan_h5upload_lang['noie']);
		return ;
	}
	if(!wysiwyg) {
		alert(boan_h5upload_lang['notext']);
		return;
	}
	if (confirm(boan_h5upload_lang['confirm_del_all'])==true){
		jq_arr = boan_jq('.upfilelist .imgl:eq(1) td');
		jq_arr.length == 0 && (jq_arr = boan_jq('.upfilelist .imgl:eq(0) td'));
		
		jq_arr.each(function(index,td){ 
		boan_indelimgall = 1;  
			boan_jq(td).find('.mtn a').trigger('click').end().remove();
		});
	}

}


// JavaScript Document
if(boan_h5upload_ispic_type){
	old_uploadWindowload = uploadWindowload ;
	uploadWindow = function (recall, type) {
		var type = isUndefined(type) ? 'image' : type;
		BOANH5_TYPE = type;
		UPLOADWINRECALL = recall;
		showWindow('upload', 'forum.php?mod=misc&action=upload&fid=' + fid + '&type=' + type, 'get', 0, {'zindex':601});
	}
	uploadWindowload = function(){
		if(boan_indelimgall){
			boan_indelimgall = 0;
			return ;
		}
		if (BOANH5_TYPE == 'file'){
			old_uploadWindowload();
			return ;
		}
		var str = $('uploadattachframe').contentWindow.document.body.innerHTML;
		if(str == '') {
			boan_jq('.filebtn').replaceWith('<div class="boanh5-example"><div  class="uploader-list"></div><div class="btns"><div id="boanh5_forum_picker" style="width:75px; margin-left:45px;">' +
			boan_h5upload_lang['sel_file'] +'</div></div></div>');
			var forumUploader = WebUploader.create({
				server:$('uploadform').action,
				formData:imgUpload.settings['post_params'],
				swf:'source/plugin/boan_h5upload/image/Uploader.swf',
				pick:{id:'#boanh5_forum_picker'},
				fileVal:'Filedata',
				compress:boan_h5upload_dispose,
				threads:1,
				accept:{
					title:imgUpload.settings['file_types_description'],
					extensions:'jpg,jpeg,gif,png,bmp',
					mimeTypes: 'image/*'
				},
				
				resize:boan_h5upload_dispose ? true : false
			});
			
			forumUploader.on('beforeFileQueued',function(file){
				if(file.ext=='png' && boan_h5upload_ispng){
					file.type='image/jpeg'
					file.source.type='image/jpeg'
				}
				return true;
			});
			
			forumUploader.on('uploadBeforeSend', function(block, data) {
				delete data.id;
				delete data.name;
				delete data.lastModifiedDate;
				data.type = 'image';
				uploadWindowstart();
			});
			
			forumUploader.on('uploadSuccess', function(file, response) {
				$('uploadattachframe').contentWindow.document.body.innerHTML = response._raw;
				response = response._raw.split('|');
				boanh5_updateimg.push(response[3]);
				uploadWindowload();
			});
			forumUploader.on('fileQueued',function(file){
				this.upload();
			});
			
			forumUploader.on('error', function(err_num){
				var MSG = {
					F_EXCEED_SIZE : boan_h5upload_lang['Q_EXCEED_SIZE_LIMIT'],
					Q_TYPE_DENIED : boan_h5upload_lang['Q_TYPE_DENIED'],
					F_DUPLICATE	  : boan_h5upload_lang['F_DUPLICATE']
					
				};
				alert(MSG[err_num] ? MSG[err_num] : err_num);
			});
		}
		old_uploadWindowload();
	}
}




function boanh5_DropOrder(){
	try{
		for (var i = 0; i < boan_jq('#imgattachlist .imgl tr').length; i++) {
			new Sortable( boan_jq('#imgattachlist .imgl tr')[i], {
				group: 'nested',
				animation: 150,
				fallbackOnBody: true,
				swapThreshold: 0.65
			});
		}
	}catch(e){
	}
	
}

if(boanH5upload.check()){
	boanH5upload.setH5();
	
	//纠正文件选择框移位
	function boan_bindimg(){
		boan_jq('[id=e_image],.edui-for-dz_image').on('click',function(){
			if(boan_jq('#boanh5_filedrag div').length>0){
				var filedrag = boan_jq('#boanh5_filedrag div');
				filedrag.css('left','0px');
				filedrag.css('top','0px');
				boan_jq('#imgPicker').css('position','relative');
				boan_jq('#imgPicker').append(filedrag);
			}	
				//添加拖动排序功能 
				boanh5_DropOrder();
				
			});
	}
	
	setTimeout('boan_bindimg()',600);
	
	
	//判断用户插图发贴
	
	if(boan_h5upload_force || boan_h5upload_havepic || boan_h5upload_remote){
		$('postform').onsubmit = function(){
			var flag = true;
			var haveflag = false;
			boan_jq('.upfilelist .imgl tr td').each(function(index,el){
				var id = boan_jq(el).attr('id');
				var classname = boan_jq(el).attr('class');
				if(id && id.substr(0,5) == 'image' && classname != 'imgdeleted'){
					var aid = id.substr(id.lastIndexOf('_')+1);
					if(wysiwyg){
						var e_body = $(editorid+'_iframe').contentDocument.body;
						if(boan_jq(e_body).find('[aid=attachimg_' + aid + ']').length == 0){
							flag = false;
						}else{
							haveflag = true;
						}
					}else{
						var text = $('e_textarea').value;
						if(text.indexOf('[attachimg]' + aid + '[/attachimg]') == -1){
							flag =false;
						}else{
							haveflag = true;
						}
					}	
				}
			});
			if(!flag && boan_h5upload_force && $('postsubmit').name != 'replysubmit'){
				showDialog(boan_h5upload_lang['explain_insert'], 'notice', null, null, 0, null, null, null, null, sdCloseTime);
				return false;
			}else if(!haveflag && boan_h5upload_havepic && $('postsubmit').name != 'replysubmit'){
				showDialog(boan_h5upload_lang['explain_must_insert'], 'notice', null, null, 0, null, null, null, null, sdCloseTime);
				return false;
			}else{	
				return  validate(this);
			}
		};
	}
	/*
	if(boan_h5upload_isbasepic){
		$('boanh5_baseimg').click();
	}*/
		
} 

