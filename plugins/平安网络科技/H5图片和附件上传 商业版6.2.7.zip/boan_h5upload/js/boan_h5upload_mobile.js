﻿var  boanh5_duplicate = [];

function boanh5_insertImgTag(aid,type,center){
	var txt = type ? '[attach]' + aid + '[/attach]' : '[attachimg]' + aid + '[/attachimg]';
	if(center){
		txt = '[align=center]' + txt + '[/align]';
	}
	txt += '\r\n';
	var messageobj = jQuery("#needmessage").get(0);
	if (document.selection) {  
		messageobj.focus();  
		sel = document.selection.createRange();  
		sel.text = txt;  
		messageobj.focus();
	} else if (messageobj.selectionStart || messageobj.selectionStart == "0") {
		var startPos = messageobj.selectionStart;
		var endPos = messageobj.selectionEnd;
		var scrollTop = messageobj.scrollTop;
		messageobj.value = messageobj.value.substring(0, startPos) + txt + messageobj.value.substring(endPos, messageobj.value.length);
		messageobj.focus();
		messageobj.selectionStart = startPos + txt.length;
		messageobj.selectionEnd = startPos + txt.length;
		messageobj.scrollTop = scrollTop;
	} else {
		messageobj.value += txt;
		messageobj.focus();
	}
	$('.btn_pn').removeClass('btn_pn_grey').addClass('btn_pn_blue');
	$('.btn_pn').attr('disable', 'false');
}


function boanh5_set_imglist(objstr,dataarr){
    var pid = 0;
	var romote = 0;
	if(typeof dataarr[8] != 'undefined'){
		pid = dataarr[8];
	}
	if(typeof dataarr[9] != 'undefined'){
		romote  = dataarr[9];
	}
	
	var dir = romote ? boan_h5upload_ftpurl : 'data/attachment/forum/' ;
	
	jQuery(objstr).append('<li><span aid="'+dataarr[3]+'" class="del" pid='+pid+' style="z-index:10;position: absolute;left: -5px;top: -10px;}"><a href="javascript:;"><img src="static/image/mobile/images/icon_del.png"></a></span><span class="p_img"><a href="javascript:;" onclick="boanh5_insertImgTag('+dataarr[3]+');" ><p style="position:absolute;left:6px;bottom:10px;color:#fff;font-size:12px;">插入图片</p><img style="height:54px;width:54px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="' + dir + dataarr[5]+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
}


function BoanH5upload(){
	if(this.getOs().versions.android && this.getOs().versions.weixin){
		this.setWeiXin();
	}else{
		this.setH5();
	}
	
}

BoanH5upload.prototype.getOs = function()  
{    
  try{
	   var browser = {
        versions: function () {
            var u = navigator.userAgent, app = navigator.appVersion;
            return {
                trident: u.indexOf('Trident') > -1, //IE内核
                presto: u.indexOf('Presto') > -1 || u.indexOf('OPR') > -1, //opera内核
                webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
                gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,//火狐内核
                mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
                ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
                android: u.indexOf('Android') > -1 || u.indexOf('Adr') > -1, //android终端
                iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器
                iPad: u.indexOf('iPad') > -1, //是否iPad
                webApp: u.indexOf('Safari') == -1, //是否web应该程序，没有头部与底部
                weixin: u.indexOf('MicroMessenger') > -1 || u.indexOf('micromessenger') >-1, //是否微信 （2015-01-22新增）
                qq: u.match(/\sQQ/i) == " qq" //是否QQ
            };
        }(),
        language: (navigator.browserLanguage || navigator.language).toLowerCase()
    };
	
    return browser;
  }catch(e){
	  alert(e.message);
  }
} 


BoanH5upload.prototype.getMimes = function(file_types){
	EXT_MIME_MAP = {
	'3gp': 'video/3gpp',
	'7z': 'application/x-7z-compressed',
	'aac': 'audio/aac',
	'abw': 'application/x-abiword',
	'arc': 'application/x-freearc',
	'avi': 'video/x-msvideo',
	'apk': 'application/vnd.android.package-archive',
	'azw': 'application/vnd.amazon.ebook',
	'bin': 'application/octet-stream',
	'bmp': 'image/bmp',
	'bz': 'application/x-bzip',
	'bz2': 'application/x-bzip2',
	'bzip2': 'application/x-bzip2',
	'chm': 'application/vnd.ms-htmlhelp',
	'csh': 'application/x-csh',
	'css': 'text/css',
	'csv': 'text/csv',
	'doc': 'application/msword',
	'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
	'eot': 'application/vnd.ms-fontobject',
	'epub': 'application/epub+zip',
	'flv': 'video/x-flv',
	'gif': 'image/gif',
	'gz': 'application/gzip',
	'htm': 'text/html',
	'html': 'text/html',
	'ico': 'image/vnd.microsoft.icon',
	'ics': 'text/calendar',
	'jar': 'application/java-archive',
	'jpeg': 'image/jpeg',
	'jpg': 'image/jpeg',
	'js': 'text/javascript',
	'json': 'application/json',
	'jsonld': 'application/ld+json',
	'm4a': 'audio/mp4',
	'mid': 'audio/midi',
	'midi': 'audio/midi',
	'mjs': 'text/javascript',
	'mov': 'video/quicktime',
	'mkv': 'video/x-matroska',
	'mp3': 'audio/mpeg',
	'mp4': 'video/mp4',
	'mp4a': 'audio/mp4',
	'mp4v': 'video/mp4',
	'mpeg': 'video/mpeg',
	'mpkg': 'application/vnd.apple.installer+xml',
	'odp': 'application/vnd.oasis.opendocument.presentation',
	'ods': 'application/vnd.oasis.opendocument.spreadsheet',
	'odt': 'application/vnd.oasis.opendocument.text',
	'oga': 'audio/ogg',
	'ogv': 'video/ogg',
	'ogx': 'application/ogg',
	'opus': 'audio/opus',
	'otf': 'font/otf',
	'pdf': 'application/pdf',
	'php': 'application/php',
	'png': 'image/png',
	'ppt': 'application/vnd.ms-powerpoint',
	'pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
	'rar': 'application/x-rar-compressed',
	'rtf': 'application/rtf',
	'sh': 'application/x-sh',
	'svg': 'image/svg+xml',
	'swf': 'application/x-shockwave-flash',
	'tar': 'application/x-tar',
	'tif': 'image/tiff',
	'tiff': 'image/tiff',
	'ts': 'video/mp2t',
	'ttf': 'font/ttf',
	'txt': 'text/plain',
	'vsd': 'application/vnd.visio',
	'wav': 'audio/wav',
	'wma': 'audio/x-ms-wma',
	'wmv': 'video/x-ms-asf',
	'weba': 'audio/webm',
	'webm': 'video/webm',
	'webp': 'image/webp',
	'woff': 'font/woff',
	'woff2': 'font/woff2',
	'xhtml': 'application/xhtml+xml',
	'xls': 'application/vnd.ms-excel',
	'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
	'xml': 'application/xml',
	'xul': 'application/vnd.mozilla.xul+xml',
	'zip': 'application/zip'
	};
	
	var exts = "",
		mimes = "";
	if(file_types.indexOf('*.*') < 0) {
		exts = file_types.replace(/\*\./g, '').replace(/;/g, ',');
		var extsArray = jQuery.grep(exts.split(','), function (s) {
			return s.length > 0
		});
		
		exts = jQuery.grep(
			extsArray, 
			function (s) {
				return s.length > 0
			}
		).join(",");
		
		mimes = jQuery.grep(
			jQuery.map(extsArray, function (ext) {
				return EXT_MIME_MAP[ext];
			}),
			function (s) {
				return s.length > 0
			}
		).join(",");
			
   }
	return {'mimes':mimes,'exts':exts};
}

BoanH5upload.prototype.get_signature =function(file,type,simple){
	var obj = null;
	var url = 'plugin.php?id=boan_h5upload:ajax&oss=yes&type=forum&filename=';
	url += file.name;
	url += '&hash='+boan_h5upload_dispose.uploadformdata['hash'] + '&atttype=' + type + '&ext=' + file.ext;;
	simple && (url += '&simple=' + parseInt(simple))
	$.ajax({
			type:"GET",
			url:url,
			async:false,
			success:function(data){
				if(data == -10 || data == 0){
					alert('up error');
				}else{
				  data = data.replace(/\<\?xml.*\>/,'');
		          obj = eval ("(" + data + ")");
				 
				}
			},
			error:function(xhr,status,error){
				alert(error);
			},
	});
	return obj;
}


BoanH5upload.prototype.defaultH5 = function(){
	try{
		//FILEID
		var that = this;
		$(FILEID).parent().addClass('boan_h5upload_m1');
		$(FILEID).parent().append('<div class="boan_h5upload_m2" ><div id="fileList" class="uploader-list"></div><div id="filePicker">　</div></div>');
		$(FILEID).remove();
		boanh5_editfun();
		if(boan_h5upload_ossserver && boan_h5upload_img_hlongup){
			upload_url = boan_h5upload_hlongurl;
			var fileVal = 'file'; //'Filedata'
			
		}else{
			upload_url = boan_h5upload_dispose.uploadurl;
			var fileVal = 'Filedata'; 
		}
		
		var uploader = WebUploader.create({
			server: upload_url,
		    fileVal:fileVal,
			fileSingleSizeLimit:boan_h5upload_dispose.maxfilesize*10,
			pick: '#filePicker',
			formData:boan_h5upload_dispose.uploadformdata,
			//压缩配置
			compress:boan_h5upload_dispose.compress,
			// 只允许选择图片文件。
			accept: {
				title: 'Images',
				extensions: 'gif,jpg,jpeg,bmp,png',
				mimeTypes: 'image/*'
			}
		});
		
		
		uploader.on( 'fileQueued', function( file ) {	
			var rFilter = /^(image\/jpeg|image\/png|image\/jpg|image\/gif|image\/jpe)$/i; // 检查图片格式
			if (rFilter.test(file.type) && file.source.source !== undefined) {
				popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
				new Boan_EXIF(this,file);
				//this.upload(file);
			}else{
				popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
				this.upload(file);
			}

		});
		
		uploader.on('beforeFileQueued',function(file){
			if(file.ext == 'png'){
				file.type='image/jpeg'
				file.source.type='image/jpeg'
			}
			var str = file.name + file.size;
			if($.inArray(str,boanh5_duplicate)>-1){
				popup.open('禁止重复选择', 'alert');
				return false;
			}else{
				boanh5_duplicate.push(str);
			}
			
			
			return true;
		});
		
		
		uploader.on('error', function(err_num){
			var MSG = {
				F_EXCEED_SIZE : '文件太大(必须小于' + boan_h5upload_dispose.maxfilesize*5/1024 + 'KB',
				Q_TYPE_DENIED : '禁止上传此类型的文件',
				F_DUPLICATE	  : '禁止重复选择'
			
			};
			 popup.open(MSG[err_num] ? MSG[err_num] : err_num,'alert');
		});
		
		uploader.on( 'uploadBeforeSend', function( object, data,header ) {
		   // 修改data可以控制发送哪些携带数据。
		   delete data.lastModifiedDate;
           delete data.name;
		   data.type = 'image';
		   data.filetype = '.'+object.file.ext;
		   
		  if(boan_h5upload_img_hlongup && boan_h5upload_ossserver == 'aliyun'){
				var data1 = that.get_signature(object.file,'image',2);		
				data = $.extend(data,{
					'key':data1.dir+data1.object,
					'policy' : data1.policy,
					'OSSAccessKeyId':data1.accessid, 
					'success_action_status':'200',
					'signature': data1.signature,
				});	
				object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			    object.file.objectname  =  data1.dir+data1.object;
		   }else if( boan_h5upload_img_hlongup && boan_h5upload_ossserver == 'qiniu'){
		   		var data1 = that.get_signature(object.file,'image',2);	 
				data = $.extend(data,{
					'key':data1.filename,
					'token' : data1.token,
				});	
				object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			    object.file.objectname  =  data1.filename;
		   }else if(boan_h5upload_img_hlongup && boan_h5upload_ossserver == 'tencent'){
			   var data1 = that.get_signature(object.file,'image');
			   var credentials = data1.credentials;
			   var Authorization = CosAuth({
							SecretId: credentials.tmpSecretId,
							SecretKey: credentials.tmpSecretKey,
							Method: 'POST',
							Pathname: '/',
						});
						
				
				data = $.extend(data,{
					'key' : data1.dir+data1.object,
					'x-cos-security-token' : credentials.sessionToken || '',
					'Signature' : Authorization,
					
				});	
			 
			   object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			   object.file.objectname  =  data1.dir+data1.object;   
		   } else if(boan_h5upload_img_hlongup && boan_h5upload_ossserver == 'huawei'){
		   	   var data1 = that.get_signature(object.file,'image');
			   data = $.extend(data,{
					'policy' : data1.policy,
					'AccessKeyId' : data1.accessid,
					'signature' : data1.signature,
					'Key': data1.dir+data1.object,
					'acl': data1.acl,
					'content-type':data1.contenttype,
					});
			   delete object.transport.options.formData.uid;
			   delete object.transport.options.formData.type;
			   delete object.transport.options.formData.hash;
			   delete data.uid;
			   delete data.size;
			   delete data.id;
			   delete data.type;
			   delete data.hash;
			   delete data.filetype;
			   object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			   object.file.objectname  =  data1.dir+data1.object; 
		   }
		   
		});
		
		uploader.on('uploadStart',function(file){
			
		});
		
		uploader.on( 'uploadSuccess', function( file,response) {
			if(response == '') {
				popup.open('上传失败，请稍后再试', 'alert');
			}
			
		   if(boan_h5upload_img_hlongup ){
				var url = 'plugin.php?id=boan_h5upload:callback&type=forum&atttype=image&filename=' + file.name + '&object=' + file.objectname +'&hash=' + boan_h5upload_dispose.uploadformdata['hash']+'&simple=2';
				$.ajax({
						type:"GET",
						url:url,
						async:false,
						success:function(data){
							response._raw = data;
						},
						error:function(xhr,status,error){
							alert(error);
						},
				});
			}
			
		    dataarr = response._raw.split('|');
			if(dataarr[0].indexOf('DISCUZUPLOAD') >-1 && parseInt(dataarr[2]) == 0) {
				popup.close();
				boanh5_set_imglist(IMGLIST,dataarr);
				if(boan_h5upload_picauto){
					boanh5_insertImgTag(dataarr[3],0);
				}
			} else {
				var sizelimit = '';
				if(dataarr[7] == 'ban') {
					sizelimit = '(附件类型被禁止)';
				} else if(dataarr[7] == 'perday') {
					sizelimit = '(不能超过'+Math.ceil(dataarr[8]/1024)+'K)';
				} else if(dataarr[7] > 0) {
					sizelimit = '(不能超过'+Math.ceil(dataarr[7]/1024)+'K)';
				}
				popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
			}
		});
		
		uploader.on( 'uploadError', function( file ) {
			alert('上传出错');
		});
		
		uploader.on( 'uploadComplete', function( file ) {
			//alert('上传完结');
		});	
	}catch(e){
		//alert(e.message);
	};
}


BoanH5upload.prototype.defaultWeixin = function(){
	var that =  this;
	$.ajax({
            type:"GET",
            url:"plugin.php?id=boan_h5upload:h5upload&operation=getticket&url="+escape(window.location.href),
            dataType:"json",
			async: false,
            success:function(data){
				if(!data.ticket){
					if(!$('div').is('.comiis_body')){
						that.defaultH5();
					 }
					return ;
				}
				wx.config({
					debug: false,
					appId:data.appid, 
					timestamp:data.timestamp ,
					nonceStr: data.noncestr,
					signature: data.signature,
					jsApiList: ["chooseImage","previewImage","uploadImage","downloadImage"] 
				});
				wx.ready(function(){
				
					var localIdsArr = [];var serverIdsArr = [];
					
					$(FILEID).parent().addClass('boan_h5upload_m1');
										
					$(FILEID).replaceWith('<div id="filedata"  class="boan_h5upload_m2"></div>');
					$(FILEID).replaceWith('<div id="filedata"  style="position:absolute;left:0px;top:0px;width:60px;	height:60px;z-index:10;	opacity:0;"></div>');
					boanh5_editfun();
					$(FILEID).on('click', function () {
						wx.chooseImage({
							success: function (res) {
								var localIds = res.localIds;
								 //console.log(localIds);
								syncUpload(localIds);
							}
						});
					});

					var syncUpload = function(localIds){
						var localId = localIds.pop();
						wx.uploadImage({
							localId: localId,
							isShowProgressTips: 1,
							success: function (res) {
								var serverId = res.serverId; // 返回图片的服务器端ID
								//其他对serverId做处理的代码
								$.ajax({
									type:"GET",
									url:"plugin.php?id=boan_h5upload:h5upload&operation=upload&serverid="+serverId+'&type=image&inajax=yes&infloat=yes&simple=2&uid='+boan_h5upload_dispose.uploadformdata.uid+'&hash='+boan_h5upload_dispose.uploadformdata.hash,
									success:function(data){
										//alert(data);
										var dataarr = data.split('|');
										if(dataarr[0].indexOf('DISCUZUPLOAD')>-1 && parseInt(dataarr[2]) == 0) {
										   boanh5_set_imglist(IMGLIST,dataarr);
										   if(boan_h5upload_picauto){
											  boanh5_insertImgTag(dataarr[3],0);
										   }
										} else {
											var sizelimit = '';
											if(dataarr[7] == 'ban') {
												sizelimit = '(附件类型被禁止)';
											} else if(dataarr[7] == 'perday') {
												sizelimit = '(不能超过'+Math.ceil(dataarr[8]/1024)+'K)';
											} else if(dataarr[7] > 0) {
												sizelimit = '(不能超过'+Math.ceil(dataarr[7]/1024)+'K)';
											}
											popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
										}
									},
									
									error:function(xhr,status,error){
										alert(error);
									},
								
								});
								
								if(localIds.length > 0){
									syncUpload(localIds);
								}
							}
						});
					};
		  			
	     		});
	  			
				wx.error(function(res) {
					console.log(res);
				});
            },
            error:function(jqXHR){
                console.log("Error: "+jqXHR.status);
            }
        });
}


BoanH5upload.prototype.setWeiXin = function(){

	this.defaultWeixin();
	 
}

BoanH5upload.prototype.setH5 = function(){
	
	 this.defaultH5();
}



function boanh5_editfun(){
	if(typeof boan_ATTACHSIMG != 'undefined'){
		$(IMGLIST + " li:not('.boan_h5upload_m1')").each(function(){
			if($(this).html().indexOf('boan_h5upload_m1') < 0){
			  $(this).remove();
			}
			});
		for(var i=0; i<boan_ATTACHSIMG.length; i++){
			var dataarr = new Array(0,0,0,boan_ATTACHSIMG[i].aid,0,boan_ATTACHSIMG[i].attachment,boan_ATTACHSIMG[i].filenametitle,0,boan_ATTACHSIMG[i].pid,boan_ATTACHSIMG[i].romote);
			boanh5_set_imglist(IMGLIST,dataarr);		
		}
		$('#mumucms_imglist').length && (window.onload=function(){$('#mumucms_imglist li .p_img a img').css('height','54px');$('#mumucms_imglist li .p_img a img').css('width','54px');});
	}
}



//插图判断
if(boan_h5upload_force || boan_h5upload_havepic){
	try {
		var boanh5_oldfun = $._data($('#postsubmit')[0],'events').click[0].handler;
	}catch(e){
		var boanh5_oldfun = null;
	}
		
	$('#postsubmit').off('click');
	$('#postsubmit').on('click',function(){
		var flag = true;
		var haveflag = false;
		$(IMGLIST+' li').each(function(index,el){
			var aid = $(el).find('input').attr('name');
			aid = aid.replace(/[^0-9]/ig,"");
			if(aid == ''){
				return true;
			}
			aid = '[attachimg]' + aid + '[/attachimg]';
			//console.log(aid);
			text = $('#needmessage').val();
			if(text.indexOf(aid) == -1){
				flag = false;
			}else{
				haveflag = true;
			}
		});
		var isreply = window.location.href.indexOf('action=reply')>-1 ? 1 : 0;
		if(!flag && boan_h5upload_force && !isreply){
			 popup.open(boan_h5upload_lang['explain_insert'],'alert');
			 return false;
		}else if(!haveflag && boan_h5upload_havepic && !isreply){
			 popup.open(boan_h5upload_lang['explain_must_insert'],'alert');
			 return false;
		}
		return boanh5_oldfun ? boanh5_oldfun.call(this) : true;
	});
}

//插入附件

if(boan_h5upload_attach){
	$('#needmessage').after('<div><span id="attachPicker">上传附件</span></div>');
	var exts = BoanH5upload.prototype.getMimes(boan_h5upload_dispose.attach_ext).exts;
	var mimes = BoanH5upload.prototype.getMimes(boan_h5upload_dispose.attach_ext).mimes;
	if(boan_h5upload_ossserver && boan_h5upload_att_hlongup){
		upload_url = boan_h5upload_hlongurl;
		var fileVal = 'file'; //'Filedata'
		var fileSingleSizeLimit = 1024*1024*1024;
		
	}else{
		upload_url = boan_h5upload_dispose.attachurl;
		var fileVal = 'Filedata'; 
		var fileSingleSizeLimit = boan_h5upload_dispose.maxfilesize;
	}
	
	var attach_uploader = WebUploader.create({
		server: upload_url,
		fileVal:fileVal,
		fileSingleSizeLimit:fileSingleSizeLimit,
		pick: '#attachPicker',
		formData:boan_h5upload_dispose.uploadformdata,
	
		accept: {
			title: 'attaches',

		}
	});
	
	attach_uploader.on( 'fileQueued', function( file ) {	
		var rFilter = /^(image\/jpeg|image\/png|image\/jpg|image\/gif|image\/jpe)$/i; // 检查图片格式
		if (rFilter.test(file.type) && file.source.source !== undefined) {
			popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
			new Boan_EXIF(this,file);
			//this.upload(file);
		}else{
			popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
			this.upload(file);
		}
	
	});
	
	attach_uploader.on('beforeFileQueued',function(file){
		if(file.ext == 'png'){
			file.type='image/jpeg'
			file.source.type='image/jpeg'
		}
		var str = file.name + file.size;
		if($.inArray(str,boanh5_duplicate)>-1){
			popup.open('禁止重复选择', 'alert');
			return false;
		}else{
			boanh5_duplicate.push(str);
		}
		return true;
	});
	
	
	attach_uploader.on('error', function(err_num){
		var MSG = {
			F_EXCEED_SIZE : '文件太大',
			Q_TYPE_DENIED : '禁止上传此类型的文件',
			F_DUPLICATE	  : '禁止重复选择'
		
		};
		 popup.open(MSG[err_num] ? MSG[err_num] : err_num,'alert');
	});
	
	attach_uploader.on( 'uploadBeforeSend', function( object, data,header ) {
	   // 修改data可以控制发送哪些携带数据。
	   delete data.lastModifiedDate;
	   delete data.name;
	   data.filetype = '.'+object.file.ext;
	   
	   if(boan_h5upload_att_hlongup && boan_h5upload_ossserver == 'aliyun'){
			var data1 = BoanH5upload.prototype.get_signature(object.file,'attach',2);		
			data = $.extend(data,{
				'key':data1.dir+data1.object,
				'policy' : data1.policy,
				'OSSAccessKeyId':data1.accessid, 
				'success_action_status':'200',
				'signature': data1.signature,
			});	
			object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			object.file.objectname  =  data1.dir+data1.object;
	   }else if( boan_h5upload_att_hlongup && boan_h5upload_ossserver == 'qiniu'){
			var data1 = BoanH5upload.prototype.get_signature(object.file,'attach',2);	 
			data = $.extend(data,{
				'key':data1.filename,
				'token' : data1.token,
			});	
			object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			object.file.objectname  =  data1.filename;
	   }else if(boan_h5upload_att_hlongup && boan_h5upload_ossserver == 'tencent'){
			   var data1 = BoanH5upload.prototype.get_signature(object.file,'attach',2);
			   var credentials = data1.credentials;
			   var Authorization = CosAuth({
							SecretId: credentials.tmpSecretId,
							SecretKey: credentials.tmpSecretKey,
							Method: 'POST',
							Pathname: '/',
						});
						
				
				data = $.extend(data,{
					'key' : data1.dir+data1.object,
					'x-cos-security-token' : credentials.sessionToken || '',
					'Signature' : Authorization,
					
				});	
			 
			   object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
			   object.file.objectname  =  data1.dir+data1.object;   
	   }else if(boan_h5upload_att_hlongup && boan_h5upload_ossserver == 'huawei'){
		   var data1 = BoanH5upload.prototype.get_signature(object.file,'attach',2);
		   data = $.extend(data,{
				'policy' : data1.policy,
				'AccessKeyId' : data1.accessid,
				'signature' : data1.signature,
				'Key': data1.dir+data1.object,
				'acl': data1.acl,
				'content-type':data1.contenttype,
				});
		   delete object.transport.options.formData.uid;
		   delete object.transport.options.formData.type;
		   delete object.transport.options.formData.hash;
		   delete data.uid;
		   delete data.size;
		   delete data.id;
		   delete data.type;
		   delete data.hash;
		   delete data.filetype;
		   object.file.name = object.file.name.replace(/[\(\)'"<>]/g,'');
		   object.file.objectname  =  data1.dir+data1.object; 
	   }

	});
	
	attach_uploader.on('uploadStart',function(file){
		
	});
	
	attach_uploader.on( 'uploadSuccess', function( file,response) {
		if(response == '') {
			popup.open('上传失败，请稍后再试', 'alert');
		}
       if(boan_h5upload_att_hlongup ){
			var url = 'plugin.php?id=boan_h5upload:callback&type=forum&atttype=attach&filename=' + file.name + '&object=' + file.objectname +'&hash=' + boan_h5upload_dispose.uploadformdata['hash']+'&simple=2';
			$.ajax({
					type:"GET",
					url:url,
					async:false,
					success:function(data){
						response._raw = data;
					},
					error:function(xhr,status,error){
						alert(error);
					},
			});
	   }
		
		dataarr = response._raw.split('|');
		
			
		if(dataarr[0].indexOf('DISCUZUPLOAD') >-1 && parseInt(dataarr[2]) == 0) {
			popup.close();
			boanh5_insertImgTag(dataarr[3],1);
			$('#needmessage').parent().after('<input type="hidden" name="attachnew[' + dataarr[3] + '][description]" value="由手机上传">');	
		} else {
			var sizelimit = '';
			if(dataarr[7] == 'ban') {
				sizelimit = '(附件类型被禁止)';
			} else if(dataarr[7] == 'perday') {
				sizelimit = '(不能超过'+Math.ceil(dataarr[8]/1024)+'K)';
			} else if(dataarr[7] > 0) {
				sizelimit = '(不能超过'+Math.ceil(dataarr[7]/1024)+'K)';
			}
			popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
		}
	});
	
	attach_uploader.on( 'uploadError', function( file ) {
		alert('上传出错');
	});
	
	attach_uploader.on( 'uploadComplete', function( file ) {
		//alert('上传完结');
	});
}


var IMGLIST = boan_h5upload_imagelistid;
$('#mumucms_imglist').length && (IMGLIST = '#mumucms_imglist');
$('#imglist2').length && (IMGLIST = '#imglist2');


var FILEID = boan_h5upload_fileid;


if($(IMGLIST).hasClass('wqpost_imglist')){
	//兼容wq
	$('#imglist .wqadd_photo').append($('#filedata'));
	$('#imglist .wqadd_photo').removeAttr('onclick');
	$('#file_button').off('click');
	$('#file_button').on('click',{},function(e){
		if($('#imglist').is(':hidden')){
			$('#imglist').show();
		}else{
			$('#imglist').hide();	
		}
		e.stopPropagation();
	});
	$(IMGLIST).off('click', 'img');

}

							  
boanH5upload = new BoanH5upload();
$('.boan_h5upload_m1 .comiis_font').css('top','7px');

$(document).off('click','.del');
$(document).on('click', '.del', function(e) {
	var obj = $(this);
	if($('input[name="pid"]').length>0){
		obj.attr('pid',$('input[name="pid"]').val());
		obj.attr('fid',$('input[name="fid"]').val());
	}
	var s = $('#needmessage').val();
	var s1 = '\\[attachimg]' + obj.attr('aid') + '\\[/attachimg]';
	$('#needmessage').val(s.replace(new RegExp(s1,'g'),''));
	s1 = '\\[align=center]\\[/align]';
	s = $('#needmessage').val();
	$('#needmessage').val(s.replace(new RegExp(s1,'g'),''));
	$.ajax({
		type:'GET',
		url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid') + (obj.attr('pid') ? '&pid=' + obj.attr('pid') :'') + (obj.attr('fid') ? '&fid=' + obj.attr('fid') :''),
	})
	.success(function(s) {
		obj.parent().remove();
		
	})
	.error(function() {
		popup.open('网络出现问题，请稍后再试', 'alert');
	});
	return false;
});

//$(IMGLIST).find('i').css('top','7px');

