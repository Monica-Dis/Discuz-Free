
function boan_addpost(file,key,val){
		file.post || (file.post = new Array());
		
		file.post.push(key + '|' + val);
}
function BoanH5upload(){
	try{
		var objA = $('icoAttach_attach_ctrl').parentNode;
		var statusObj = document.createElement('div');
		statusObj.style.display = '';
		statusObj.id = 'boan_h5upload_status';
	
		statusObj.style.textAlign="center";
		statusObj.style.height='28px';
		statusObj.style.fontSize='14px';
		
		
		objA.appendChild(statusObj);
		var objA = $('icoImg_image_ctrl').parentNode;
	
		imgstatusObj = $('boan_h5upload_status').cloneNode(true);
		imgstatusObj.id = 'boan_h5upload_imgstatus';
	
		objA.appendChild(imgstatusObj);
	}catch(e){
	}
}

BoanH5upload.prototype.beforeFileQueued = function(prefix,file){
	var upObj = prefix ? upload : attachUpload ;
	if(upObj.customSettings.uploadSource == 'portal') {
		var inputObj = $('catid');
		if(inputObj && parseInt(inputObj.value)) {
			boan_addpost(file,'catid', inputObj.value);
		}
	}
	
	if(file.ext=='png' && boan_h5upload_ispng){
		file.type='image/jpeg'
		file.source.type='image/jpeg'
	}
	
	createQueue = true;
	
	return createQueue;
	
}

BoanH5upload.prototype.fileQueued = function(prefix,file,Obj){
	var upObj = prefix ?  upload : attachUpload;
	var progress = new FileProgress(file, upObj.customSettings.progressTarget);
	progress.setStatus(boan_h5upload_lang['wait_up']);
	
	progress.toggleCancel = function (show, swfUploadInstance) {
		this.fileProgressElement.childNodes[0].style.visibility = show ? "visible" : "hidden"; //设置是否显示取消按钮
		if (swfUploadInstance) {
			var fileID = this.fileProgressID;
			that = this;
			this.fileProgressElement.childNodes[0].onclick = function () {
				swfUploadInstance.removeFile(fileID);
				that.setCancelled();
				return false;
			};
		}
	};
	progress.toggleCancel(true,Obj);
	
	if(upObj.customSettings.uploadType == 'attach') {
		try {
			    $('attach_tblheader').style.display = '';
				$('attach_notice').style.display = '';
		} catch (ex) {}
	} else if(upObj.customSettings.uploadType == 'image') {
		try {
			$('imgattach_notice').style.display = '';
		} catch (ex) {}
	}
	var objId = upObj.customSettings.uploadType == 'attach' ? 'attachlist' : 'imgattachlist';
	var listObj = $(objId);
	var tableObj = listObj.getElementsByTagName("table");
	if(!tableObj.length) {
		listObj.innerHTML = "";
	}
}

BoanH5upload.prototype.uploadSuccess = function(prefix,file,response,Obj){
	
	try {
		var upObj = prefix ? upload : attachUpload;;
		var progress = new FileProgress(file, upObj.customSettings.progressTarget);
		upload_url = window.location.protocol+'//'+window.location.host+'/';
		
		if(upObj.customSettings.uploadSource == 'portal') {
			var data = response;
			if(data.aid) {
				if(upObj.customSettings.uploadType == 'attach') {
					ajaxget(upload_url + 'portal.php?mod=attachment&op=getattach&type=attach&id=' + data.aid, file.id);
					if($('attach_tblheader')) {
						$('attach_tblheader').style.display = '';
					}
				} else {
					var tdObj = getInsertTdId(upObj.customSettings.imgBoxObj, 'attach_list_'+data.aid);
					ajaxget(upload_url + 'portal.php?mod=attachment&op=getattach&id=' + data.aid, tdObj.id);
					$(file.id).style.display = 'none';
				}
			} else {
				showDialog(boan_h5upload_lang['up_error'], 'notice', null, null, 0, null, null, null, null, sdCloseTime);
				progress.setCancelled();
				Obj.removeFile(file.id);
				progress.toggleCancel(false);
			}
		} else {
			progress.setComplete();
			progress.setStatus(boan_h5upload_lang['ok_up']);
			progress.toggleCancel(false);
		}
	} catch (ex) {
		alert(ex.message);
	}
}


BoanH5upload.prototype.setH5 = function(){
	//设置附件上传
	
    var domin_pre = window.location.protocol+'//'+window.location.host+'/';
	var newnode = $('icoAttach_btn_attachlist').firstElementChild;
	//newnode.innerText = 'H5附件上传';
	
	newnode = document.createElement('div');
	newnode.id = 'uploader';
    newnode.className = 'boanh5-example';
	newnode.innerHTML = '<div id="attachuploadlist" class="uploader-list"></div><div class="btns"><div id="picker">' 
	+ boan_h5upload_lang['sel_file'] + '</div></div>';
	
	rnode = $('spanButtonPlaceholder');
	rnode || (rnode = $('SWFUpload_0'));
	rnode.parentElement.style.float='none';
	rnode.parentNode.replaceChild(newnode,rnode);
	
	
	//图片上传
	
	newnode = $('icoImg_btn_imgattachlist').firstElementChild;
	
	//newnode.innerText = '图片H5上传';

	newnode = document.createElement('div');
	newnode.id = 'imguploader';
    newnode.className = 'boanh5-example';
	newnode.innerHTML = '<div id="thelist" class="uploader-list" style="clear: both;"><div class="btns" style="float:left;"><div id="imgPicker" >' 
	+boan_h5upload_lang['sel_file'] + '</div></div><div class="placeholder">' 
	+ boan_h5upload_lang['explain_portal'] + '</div></div>';
	
	rnode = $('imgSpanButtonPlaceholder');
	rnode || (rnode = $('SWFUpload_1'));
	rnode.parentElement.style.float='none';
	rnode.parentNode.replaceChild(newnode,rnode);
	upload_url= domin_pre + upload.settings['upload_url'].substr(upload.settings['upload_url'].indexOf('misc.php'));
	var imgUploader = WebUploader.create({
		server:upload_url,
		formData:upload.settings['post_params'],
		swf:'source/plugin/boan_h5upload/image/Uploader.swf',
		pick:{id:'#imgPicker'},
		fileVal:'Filedata',
		dnd: '#thelist .placeholder',
		paste: Document.body,
		disableGlobalDnd: true,
		accept:{
			title:upload.settings['file_types_description'],
			extensions:upload.settings['file_types'].replace(/\*\./g,'').replace(/;/g,','),
			mimeTypes: 'image/*',
		},
		dnd: '#thelist .placeholder',
		paste: document.body,
		disableGlobalDnd: true,
		threads:1,
		compress:boan_h5upload_dispose,
		fileSingleSizeLimit:upload.settings['file_size_limit']*1024*5,
		resize:boan_h5upload_dispose ? true : false,
	});
		upload_url= domin_pre + attachUpload.settings['upload_url'].substr(attachUpload.settings['upload_url'].indexOf('misc.php'));
		var uploader = WebUploader.create({
		server:upload_url,
		swf:'source/plugin/boan_h5upload/image/Uploader.swf',
		formData:attachUpload.settings['post_params'],
		pick:{id:'#picker'},
		fileVal:'Filedata',
		accept:{
			title:attachUpload.settings['file_types_description'],
			extensions:attachUpload.settings['file_types'].replace(/\*\./g,'').replace(/;/g,','),
		},
		compress:boan_h5upload_dispose,
		fileSingleSizeLimit:attachUpload.settings['file_size_limit']*1024,
		resize:boan_h5upload_dispose ? true : false,
	});
	
	function boan_addpost(file,key,val){
		    file.post || (file.post = new Array());
			file.post.push(key + '|' + val);
	}
	
	//附件上传
	uploader.on('beforeFileQueued',function(file){
		return boanH5upload.beforeFileQueued('',file);
	});
	
	
	uploader.on('error', function(err_num){
		var MSG = {
			F_EXCEED_SIZE : boan_h5upload_lang['Q_EXCEED_SIZE_LIMIT'],
			Q_TYPE_DENIED : boan_h5upload_lang['Q_TYPE_DENIED'],
			F_DUPLICATE	  : boan_h5upload_lang['F_DUPLICATE']
			
		};
		alert(MSG[err_num] ? MSG[err_num] : err_num);
	});
	
	uploader.on('fileQueued',function(file){
		boanH5upload.fileQueued('',file,this);
		this.upload();
	});
	
	uploader.on( 'uploadBeforeSend', function( object, data,header ) {
       // 修改data可以控制发送哪些携带数据。
      if(object.file.post){
		   for(var i = 0 ; i < object.file.post.length;i++){
			 var v = object.file.post[i].split('|');
			 eval('data.' + v[0] + '="' + v[1] + '"');
		   }
	  }
	  delete data.lastModifiedDate;
	  delete data.name;
    });

	uploader.on('uploadProgress',function(file,percentage){
		try {
			var progress = new FileProgress(file, upload.customSettings.progressTarget);
			progress.setStatus(boan_h5upload_lang['uppercent']+ parseInt(percentage*100)+"%)...");

		} catch (ex) {
			
		}
	});
	
	uploader.on('uploadStart',function(file){
		try {
			var progress = new FileProgress(file,upload.customSettings.progressTarget);
			boan_addpost(file,'filetype',file.ext);
			progress.setStatus(boan_h5upload_lang['uping']);
			
		} catch (ex) {
		}
	});
	
	uploader.on( 'uploadSuccess', function( file,response) {
		boanH5upload.uploadSuccess('',file,response,this);
	});
	
	uploader.on( 'uploadError', function( file ) {
		alert(boan_h5upload_lang['up_error']);
	});
	
	uploader.on( 'uploadComplete', function( file ) {
		//alert('上传完结');
	});
	
	
	//图片上传
	imgUploader.on('beforeFileQueued',function(file){
		return boanH5upload.beforeFileQueued('img',file);
	});
	imgUploader.on('error', function(err_num){
		var MSG = {
			F_EXCEED_SIZE : boan_h5upload_lang['Q_EXCEED_SIZE_LIMIT'],
			Q_TYPE_DENIED : boan_h5upload_lang['Q_TYPE_DENIED'],
			F_DUPLICATE	  : boan_h5upload_lang['F_DUPLICATE']
			
		};
		alert(MSG[err_num] ? MSG[err_num] : err_num);
	});
	
	imgUploader.on('fileQueued',function(file){
		boanH5upload.fileQueued('img',file,this);
		this.upload();
	});
	
	imgUploader.on( 'uploadBeforeSend', function( object, data,header ) {
       // 修改data可以控制发送哪些携带数据。
	   data.type = 'image';
       delete data.lastModifiedDate;
	   delete data.name;
	   if(object.file.post){
	   	 for(var i = 0 ; i < object.file.post.length;i++){
			 var v = object.file.post[i].split('|');
			 eval('data.' + v[0] + '="' + v[1] + '"');
		 }
	   }
	  
    });
	
	imgUploader.on('uploadProgress',function(file,percentage){
		try {
			var progress = new FileProgress(file, upload.customSettings.progressTarget);
			progress.setStatus(boan_h5upload_lang['uppercent']+ parseInt(percentage*100)+"%)...");

		} catch (ex) {
			
		}
	});
	
	imgUploader.on('uploadStart',function(file){
		try {
			//this.addPostParam('filetype', file.type);
		   
			var progress = new FileProgress(file,upload.customSettings.progressTarget);
			boan_addpost(file,'filetype','.'+file.ext);
			progress.setStatus(boan_h5upload_lang['uping']);
			
		} catch (ex) {
		}
	
	});
	
	imgUploader.on( 'uploadSuccess', function( file,response) {
		boanH5upload.uploadSuccess('img',file,response,this);
		
	});
	
	imgUploader.on( 'uploadError', function( file ) {
		alert(boan_h5upload_lang['up_error']);
	});
	
	imgUploader.on( 'uploadComplete', function( file ) {
		//alert('上传完结');
	});
	
}

BoanH5upload.prototype.checkhHtml5 = function(){
    if (typeof(Worker) !== "undefined") {  
		return true;	
	} 
	else {
		return false;  
	}
}

BoanH5upload.prototype.getOs = function()  
{  
  try{
	   var browser = {
        versions: function () {
            var u = navigator.userAgent, app = navigator.appVersion;
            return {
                trident: u.indexOf('Trident') > -1, //IE内核
                presto: u.indexOf('Presto') > -1 || u.indexOf('OPR') > -1, //opera内核
                webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
                gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,//火狐内核
                mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
                ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
                android: u.indexOf('Android') > -1 || u.indexOf('Adr') > -1, //android终端
                iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器
                iPad: u.indexOf('iPad') > -1, //是否iPad
                webApp: u.indexOf('Safari') == -1, //是否web应该程序，没有头部与底部
                weixin: u.indexOf('MicroMessenger') > -1, //是否微信 （2015-01-22新增）
                qq: u.match(/\sQQ/i) == " qq" //是否QQ
            };
        }(),
        language: (navigator.browserLanguage || navigator.language).toLowerCase()
    };
	
    return browser;
  }catch(e){
	  alert(e.message);
  }
    
} 

BoanH5upload.prototype.isFlash = function(){
  var flag = false;
  if(window.ActiveXObject){
	try{
	  var swf = new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
	  if(swf){
		flag = true;
	  }
	}catch(e){
	}
  }else{
	try{
	  var swf = navigator.plugins['Shockwave Flash'];
	  if(swf){
		flag = true;
	  }
	}catch(e){
	}
  }
  (this.getOs().versions.gecko || this.getOs().versions.presto) && (flag = 0);
  return flag ;	  
}

BoanH5upload.prototype.showStatus = function(prefix,message){
	if(!prefix){
		$('boan_h5upload_status').innerHTML = '<span style="color:#39F;line-height:28px;">' + message + '</span>';
	}else{
		$('boan_h5upload_imgstatus').innerHTML = '<span style="color:#39F;line-height:28px;">' + message + '</span>';
	}
	
}

BoanH5upload.prototype.check = function(){
	var flag = true;
	//检测原图片附件按钮是否存在
	if(!($('imgSpanButtonPlaceholder') || $('SWFUpload_0'))){
		flag = false;
	}
	if(!($('spanButtonPlaceholder') || $('SWFUpload_1'))){
		flag = false;
	}
	return flag;
	
}

function downRemoteFile() {
	showDialog('<div id="remotedowninfo"><p class="mbn">' + 
	boan_h5upload_lang['downfile'] + '</p><p><img src="' + STATICURL + 'image/common/uploading.gif" alt="" /></p></div>', 'notice', '', null, 1);
	edit_save();
	var formObj = $("articleform");
	var oldAction = formObj.action;
	var oldid = boan_jq('input[name="id"]').attr('value');
	formObj.action = "plugin.php?id=boan_h5upload:downremotefile&ac=upload&op=downremotefile";
	formObj.onSubmit = "";
	formObj.target = "uploadframe";
	
	boan_jq('input[name="id"]').attr('value', 'boan_h5upload:downremotefile');
	
	formObj.submit();
	formObj.action = oldAction;
	formObj.target = "";
	boan_jq('input[name="id"]').attr('value', oldid); 
}

boanH5upload = new BoanH5upload();

if(boanH5upload.check()){
	 boanH5upload.setH5();
	// boanH5upload.showStatus('','已经载入H5上传支持!');
	// boanH5upload.showStatus('img','已经载入H5图片上传支持!');
}else {
	// boanH5upload.showStatus('','发生异常，无法提供H5支持！');
	 //boanH5upload.showStatus('img','发生异常，无法提供H5支持！');
}
	 

