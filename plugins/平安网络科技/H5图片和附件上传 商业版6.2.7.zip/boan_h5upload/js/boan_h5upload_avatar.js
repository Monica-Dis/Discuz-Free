
function BoanH5upload(){
	try{
		
	}catch(e){
	}
}

BoanH5upload.prototype.getOs = function()  
{  
  try{
	   var browser = {
        versions: function () {
            var u = navigator.userAgent, app = navigator.appVersion;
            return {
                trident: u.indexOf('Trident') > -1, //IE内核
                presto: u.indexOf('Presto') > -1 || u.indexOf('OPR') > -1, //opera内核
                webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
                gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1,//火狐内核
                mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
                ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
                android: u.indexOf('Android') > -1 || u.indexOf('Adr') > -1, //android终端
                iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器
                iPad: u.indexOf('iPad') > -1, //是否iPad
                webApp: u.indexOf('Safari') == -1, //是否web应该程序，没有头部与底部
                weixin: u.indexOf('MicroMessenger') > -1, //是否微信 （2015-01-22新增）
                qq: u.match(/\sQQ/i) == " qq" //是否QQ
            };
        }(),
        language: (navigator.browserLanguage || navigator.language).toLowerCase()
    };
	
    return browser;
  }catch(e){
	  alert(e.message);
  }
    
} 

BoanH5upload.prototype.isFlash = function(){
  var flag = false;
  if(window.ActiveXObject){
	try{
	  var swf = new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
	  if(swf){
		flag = true;
	  }
	}catch(e){
	}
  }else{
	try{
	  var swf = navigator.plugins['Shockwave Flash'];
	  if(swf){
		flag = true;
	  }
	}catch(e){
	}
  }
  (this.getOs().versions.gecko || this.getOs().versions.presto) && (flag = 0);
  return flag ;	  
}

boanH5upload = new BoanH5upload();
if(window.location.href.indexOf('t=')>-1){
	//如果是修改头像后返回，则向服务器发送请缓存请求
	boan_jq.ajax({url:"plugin.php?id=boan_h5upload:ajax&avatar=yes"});
}

var obj = boan_jq('.tfm:eq(1) tbody');
obj.html('<iframe  width="100%" height="560" src="source/plugin/boan_h5upload/cropper/demo/index.html"  frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>');
for(i=0;i<boan_jq("img").length;i++){
	if(boan_jq("img")[i].src.indexOf('size')>-1){
		boan_jq("img")[i].src = boan_jq("img")[i].src + '&random=1'; 
	}
}


