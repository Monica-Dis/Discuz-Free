$(function () {

  'use strict';

  var console = window.console || { log: function () {} },
      $alert = $('.docs-alert'),
      $message = $alert.find('.message'),
      showMessage = function (message, type) {
        $message.text(message);

        if (type) {
          $message.addClass(type);
        }

        $alert.fadeIn();

        setTimeout(function () {
          $alert.fadeOut();
        }, 3000);
      };

  // Demo
  // -------------------------------------------------------------------------

  (function () {
    var $image = $('.img-container > img'),
        $dataX = $('#dataX'),
        $dataY = $('#dataY'),
        $dataHeight = $('#dataHeight'),
        $dataWidth = $('#dataWidth'),
        $dataRotate = $('#dataRotate'),
        options = {
          // strict: false,
          // responsive: false,
          // checkImageOrigin: false

          // modal: false,
          // guides: false,
          // highlight: false,
          // background: false,

          // autoCrop: false,
          // autoCropArea: 0.5,
          // dragCrop: false,
          // movable: false,
          // resizable: false,
          // rotatable: false,
          // zoomable: false,
          // touchDragZoom: false,
          // mouseWheelZoom: false,

          // minCanvasWidth: 320,
          // minCanvasHeight: 180,
           minCropBoxWidth: 48,
           minCropBoxHeight: 48,
          // minContainerWidth: 320,
          // minContainerHeight: 180,

          // build: null,
          // built: null,
          // dragstart: null,
          // dragmove: null,
          // dragend: null,
          // zoomin: null,
          // zoomout: null,

          aspectRatio: 1 / 1,
          preview: '.img-preview',
          crop: function (data) {
            $dataX.val(Math.round(data.x));
            $dataY.val(Math.round(data.y));
            $dataHeight.val(Math.round(data.height));
            $dataWidth.val(Math.round(data.width));
            $dataRotate.val(Math.round(data.rotate));
          }
		 
        };
	
	$('#info').text(window.parent.boan_h5upload_lang['explain_gif'] + window.parent.gif_size + 'KB');
	$(window).on('message',function(e){
		if(window.location.href.indexOf('mobile') < 0 ){
			//top.location.reload();
			//top.window.location = '/home.php?mod=spacecp&ac=avatar' + '&t=3333';
			top.window.location = window.parent.SITEURL+'home.php?mod=spacecp&ac=avatar' + '&t=3333';
		} else {
			popup.close();
			window.location = 'home.php?mod=space&uid=' + $('#uid').val() + '&do=profile&mycenter=1&mobile=2&t=' + parseInt(Math.random()*1000);
		}
		if(is_saya){
			if(typeof boan_h5upload_lang == 'undefined'){
				var boan_h5upload_lang = new Array();
				boan_h5upload_lang['examine'] = window.parent.boan_h5upload_lang['examine']
			}
			
			alert(boan_h5upload_lang['examine']);
		}
	});
	
	var is_saya = window.parent.is_saya;
	
    $image.on({
      'build.cropper': function (e) {
        //console.log(e.type);
      },
      'built.cropper': function (e) {
        //console.log(e.type);
      },
      'dragstart.cropper': function (e) {
        //console.log(e.type, e.dragType);
      },
      'dragmove.cropper': function (e) {
       // console.log(e.type, e.dragType);
      },
      'dragend.cropper': function (e) {
        //console.log(e.type, e.dragType);
      },
      'zoomin.cropper': function (e) {
       // console.log(e.type);
      },
      'zoomout.cropper': function (e) {
       // console.log(e.type);
      }
    }).cropper(options);

	
    // Methods
    $(document.body).on('click', '[data-method]', function () {
      var data = $(this).data(),
          $target,
          result;

      if (data.method) {
        data = $.extend({}, data); // Clone a new one

        if (typeof data.target !== 'undefined') {
          $target = $(data.target);

          if (typeof data.option === 'undefined') {
            try {
              data.option = JSON.parse($target.val());
            } catch (e) {
              console.log(e.message);
            }
          }
        }
		
        if (data.method === 'saveimg') {
			if(window.location.href.indexOf('mobile') < 0 ){	
				$("input[name='formhash']").val($("input[name='formhash']", window.parent.document).val());
				var data = window.parent.uc_avatarflash;
			}else{
				var data = $("#uc_avatarflash").val();
				data = data.split(',');
				popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
			}
			
			if( $('#inputImage')[0].files[0] && /\w+?\.gif$/.test($('#inputImage')[0].files[0].name)){
			  // var upload_url = window.location.protocol+'//'+window.location.host+'/';
			   var upload_url  = window.parent.SITEURL;
			   $("#avatarform").attr('action',upload_url+'plugin.php?id=boan_h5upload:fileupload');
			}else{
				var cav = $image.cropper('getCropBoxData');
				var sw = cav.width;
				var sh = cav.height;
				var tw = sw;
				var th = sh;
				if (sw>200 || sh>250) {
					var r = Math.max(sw/200, sh/250);
					tw = Math.floor(sw/r);
					th = Math.floor(sh/r);
				}
				var cnvimg = $image.cropper('getCroppedCanvas', {
				  width: tw,
				  height: th
				});
				var dataURL = cnvimg.toDataURL("image/jpeg");
				$('#avatar1').val(dataURL.substr(dataURL.indexOf(",") + 1));
							
				if (sw>120 || sh>120) {
					var r = Math.max(sw/120, sh/120);
					tw = Math.floor(sw/r);
					th = Math.floor(sh/r);
				}
				var cnvimg = $image.cropper('getCroppedCanvas', {
				  width: tw,
				  height: th
				});
				var dataURL = cnvimg.toDataURL("image/jpeg");
				$('#avatar2').val(dataURL.substr(dataURL.indexOf(",") + 1));
				
				
				if (sw>48 || sh>48) {
					var r = Math.max(sw/48, sh/48);
					tw = Math.floor(sw/r);
					th = Math.floor(sh/r);
				}
				var cnvimg = $image.cropper('getCroppedCanvas', {
				  width: tw,
				  height: th
				});
				var dataURL = cnvimg.toDataURL("image/jpeg");
				$('#avatar3').val(dataURL.substr(dataURL.indexOf(",") + 1));
				var s_p = window.location.protocol.replace(':','');
				var l=data[data.indexOf('src')+1].indexOf('://');
				data[data.indexOf('src')+1] = s_p + data[data.indexOf('src')+1].substr(l);
				$("#avatarform").attr('action',data[data.indexOf('src')+1].replace('images/camera.swf?inajax=1', 'index.php?m=user&a=rectavatar&base64=yes'));
				
				//var domin = window.location.protocol+'//'+ window.location.host;
				var domin = window.parent.SITEURL;
				var ss=$("#avatarform").attr('action');
				ss = ss.substr(0,ss.indexOf('/uc_server'));
				if(ss != domin && ss != ''){
					$("#avatarform").attr('action',$("#avatarform").attr('action').replace(ss,domin));
				}
				
				if(is_saya){
					var temp=$("#avatarform").attr('action').replace('uc_server/index.php?','plugin.php?id=saya_avatarverify:index&');
					$("#avatarform").attr('action',temp);
				}
			}	
        }
		
		result = $image.cropper(data.method, data.option);
		
        if (data.method === 'getCroppedCanvas') {
          $('#getCroppedCanvasModal').modal().find('.modal-body').html(result);
        }

        if ($.isPlainObject(result) && $target) {
          try {
            $target.val(JSON.stringify(result));
          } catch (e) {
            console.log(e.message);
          }
        }

      }
    }).on('keydown', function (e) {

      switch (e.which) {
        case 37:
          e.preventDefault();
          $image.cropper('move', -1, 0);
          break;

        case 38:
          e.preventDefault();
          $image.cropper('move', 0, -1);
          break;

        case 39:
          e.preventDefault();
          $image.cropper('move', 1, 0);
          break;

        case 40:
          e.preventDefault();
          $image.cropper('move', 0, 1);
          break;
      }

    });


    // Import image
    var $inputImage = $('#inputImage'),
        URL = window.URL || window.webkitURL,
        blobURL;

    if (URL) {
      $inputImage.change(function () {
        var files = this.files,
            file;

        if (files && files.length) {
          file = files[0];
		  if(/\w+?\.gif$/.test(file.name)){
			
		  }
		  
          if (/^image\/\w+$/.test(file.type)) {
            blobURL = URL.createObjectURL(file);
			
            $image.one('built.cropper', function () {
              URL.revokeObjectURL(blobURL); // Revoke when load complete
            }).cropper('reset', true).cropper('replace', blobURL);
           
          } else {
            showMessage('Please choose an image file.');
          }
        }
      });
    } else {
      $inputImage.parent().remove();
    }


    // Options
    $('.docs-options :checkbox').on('change', function () {
      var $this = $(this);

      options[$this.val()] = $this.prop('checked');
      $image.cropper('destroy').cropper(options);
    });


    // Tooltips
    $('[data-toggle="tooltip"]').tooltip();

  }());

});
