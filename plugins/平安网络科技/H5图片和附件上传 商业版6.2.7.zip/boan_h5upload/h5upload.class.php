<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}
require_once   DISCUZ_ROOT.'./source/plugin/boan_h5upload/common.func.php';
define('P_NAME', 'plugin/boan_h5upload');

class  plugin_boan_h5upload{
    var $vars;
    function __construct(){
        global $_G;
        if(empty($_G['cache']['plugin'])){
            loadcache('plugin');
        }
        $this->vars = $_G['cache']['plugin']['boan_h5upload'];
        
    
        $this->vars['img_hlongup'] = 0;
        $this->vars['att_hlongup'] = 0;
        $this->vars['hlongurl'] = '';
        $this->vars['ossserver'] = '' ;
        if((file_exists(DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/loadoss.php') &&  require_once(DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/loadoss.php'))
            || (file_exists(DISCUZ_ROOT.'./source/plugin/boan_oss/loadoss.php') &&  require_once(DISCUZ_ROOT.'./source/plugin/boan_oss/loadoss.php'))){
            if($_G['BOAN_OSS']){
                $this->vars['oss_exclude_forums'] = dunserialize($_G['BOAN_OSSCONFIG']['oss_exclude_forums']);
                $this->vars['img_hlongup'] = (dintval($_G['BOAN_OSSCONFIG']['img_hlong']) & dintval($_G['BOAN_OSSCONFIG']['oss_img']) );
                $this->vars['att_hlongup'] = (dintval($_G['BOAN_OSSCONFIG']['att_hlong']) & dintval($_G['BOAN_OSSCONFIG']['oss_att']) );
                if(in_array($_G['fid'], $this->vars['oss_exclude_forums'])){
                    $this->vars['img_hlongup'] = $this->vars['att_hlongup'] = 0;
                }
                $this->vars['hlongurl'] = $_G['BOAN_OSSCONFIG']['oss_bucket_url'];
                $this->vars['ossserver'] = $_G['BOAN_OSS']::$oss_server_name;
                $this->vars['ossstyleforums'] = dunserialize($_G['BOAN_OSSCONFIG']['oss_style_forums']);
            }
            
            /////////////////////////////////兼容boan_watermask/////////////////////////////////////////////////
           
            if(in_array('boan_watermask',$_G['setting']['plugins']['available']) !== FALSE){
                $boan_watermask =  $_G['cache']['plugin']['boan_watermask'];
                $boan_watermask['allow_forums'] = unserialize($boan_watermask['allow_forums']);
                $boan_watermask['allow_groups'] = unserialize($boan_watermask['allow_groups']);
                if(CURMODULE == 'post' && $boan_watermask ['is_forum'] &&
                    in_array($_G['fid'], $boan_watermask['allow_forums']) && in_array($_G['groupid'], $boan_watermask['allow_groups'])){
                        $this->vars['img_hlongup'] = 0;
                }
            }
           
            //////////////////////////////////////////////////////////////////////////////////////////////////
            
        }
        
    }
    
    function common() {
    }
    function deletethread(){
    }
    function deletepost(){
    }
    
    private function closeNewH5(){
        return <<<EOF
        <script>
            var SWFUpload;
        	SWFUpload = function(settings) {
        		this.initUpload(settings);
       	    };
           
            SWFUpload.prototype.initUpload = function(userSettings) {
            	try {
            		this.customSettings = {};	
            		this.settings = {};
            		this.eventQueue = [];
            		this.initSettings1(userSettings);
            	} catch (ex) {
            		throw ex;
            	}
            };
            SWFUpload.prototype.initSettings1 = function (userSettings) {
            	this.ensureDefault = function(settingName, defaultValue) {
            		var setting = userSettings[settingName];
            		if (setting != undefined) {
            			this.settings[settingName] = setting;
            		} else {
            			this.settings[settingName] = defaultValue;
            		}
            	};
            
            	this.ensureDefault("upload_url", "");
            	this.ensureDefault("file_post_name", "Filedata");
            	this.ensureDefault("post_params", {});
            
            	this.ensureDefault("file_types", "*.*");
            	this.ensureDefault("file_types_description", "All Files");
            	this.ensureDefault("file_size_limit", 0);	
            	this.ensureDefault("file_upload_limit", 0);
            	this.ensureDefault("file_queue_limit", 0); 
                this.ensureDefault("custom_settings", {});
	            this.customSettings = this.settings.custom_settings;
            }
        </script>
EOF;
    }
    private function getSwitchCode(){
        global $_G;
        $vars = $this->vars;
        $switch = dintval($vars['switch']);
        $rtn = '';
        $pic_width = dintval($vars['pic_width']);
        $pic_height = dintval($vars['pic_height']);
        $pic_quality = $vars['pic_quality'] ? $vars['pic_quality'] : 100;
        
        $compress = '{';
        $pic_width ? $compress .= "width:$pic_width," :  $compress .= "width:8000,";
        $pic_height ? $compress .= "height:$pic_height," : $compress .= "height:8000,";
        $pic_quality && $compress .= "quality:$pic_quality,";
        $compress .= 'noCompressIfLarger:false,crop:false,}';
        
        $group_ids = unserialize(stripslashes($this->vars['os_group']));
        $forum_ids = unserialize(stripslashes($this->vars['os_forum']));
        $is_base = 0;
        if(in_array($_G['groupid'],$group_ids) || in_array($_G['fid'],$forum_ids)){
            //$compress = 'false';
            $is_base = '1';
        }
        
        $group_ids = unserialize(stripslashes($this->vars['big_group']));
        $is_big = 'false';
        if(in_array($_G['groupid'],$group_ids)){
            $is_big = 'true';
        }
        
        $ispng = $vars['ispng'] ? '1' : '0' ;
        
        $forums = $vars['is_have_forums'];
        $forums = unserialize($forums);
        $is_have_pic = $vars['is_have_pic'] && in_array($_G['fid'], $forums) ? '1' : '0';
        
        $isforce = $vars['is_force'] ? '1' : '0';
        $is_remotetolocal = $vars['is_remotetolocal'] && $_G['group']['allowdownremoteimg'] ? '1' : '0';
        
        $qrcodeurl = '';
        $k = $this->vars['pic_qrcode_outtime'] ? $this->vars['pic_qrcode_outtime'] * 60 : 1;
        $life = $k == 1 ? 0 : $k;
        $k = authcode($_G['member']['uid'],'ENCODE',$_G['config']['security']['authkey'],$k);
        $qrcodeurl = $_G['siteurl'].'plugin.php?id=boan_h5upload:qrcode&uid='.rawurlencode($k);
        
        $pic_type = $vars['pic_type'] ? '1' : '0';
        $pic_qrcode = $vars['pic_qrcode'] ? '1' : '0';
        
        $rtn .= "<script> var boan_h5upload_dispose= $compress,boan_h5upload_ispng = $ispng, boan_h5upload_isbig = $is_big,boan_h5upload_force = $isforce,
        boan_h5upload_havepic = $is_have_pic,
        boan_h5upload_isbasepic = $is_base,
        boan_h5upload_ispic_type = $pic_type,
        boan_h5upload_remote = $is_remotetolocal,
        boan_h5upload_ispic_qrcode = $pic_qrcode,
        boan_h5upload_qrcodeurl = '$qrcodeurl';  
        boan_h5upload_qrcodelife = '$life';
        boan_h5upload_img_hlongup = {$this->vars['img_hlongup']};
        boan_h5upload_att_hlongup = {$this->vars['att_hlongup']} ;
        boan_h5upload_hlongurl = '{$this->vars['hlongurl']}';
        boan_h5upload_ossserver = '{$this->vars['ossserver']}'; 
        </script>";
        return $rtn;
    }
 
    function global_header(){
        $rtn = '';
        $rtn .= boan_load_jq('jquery-1.11.0.min.js','boan_h5upload');
        
        if($_GET['mod'] == 'post' || ($_GET['mod'] == 'spacecp' && $_GET['ac'] == 'upload') || ($_GET['mod'] == 'spacecp' && $_GET['ac'] == 'blog')){
            $rtn .= '<link href="./source/plugin/boan_h5upload/css/webuploader.css" rel="stylesheet" type="text/css" />';
            $rtn .= $this->closeNewH5();
        }elseif(($_GET['mod'] == 'viewthread' || $_GET['mod'] == 'forumdisplay' || $_GET['mod'] == 'follow') ){
            $rtn .= '<link href="./source/plugin/boan_h5upload/css/webuploader_fast.css" rel="stylesheet" type="text/css" />';
            $rtn .= $this->closeNewH5();
        }elseif(($_GET['mod'] == 'portalcp' && $_GET['ac'] == 'article') || ($_GET['mod'] == 'portalcp' && $_GET['op'] == 'edit')){
            $rtn .= '<link href="./source/plugin/boan_h5upload/css/webuploader.css" rel="stylesheet" type="text/css" />';
            $rtn .= $this->closeNewH5();
        
        } elseif($_GET['mod'] == 'spacecp' && $_GET['ac'] == 'avatar' && !$_GET['old']){
            $rtn .= boan_load_jq('jquery-1.11.0.min.js','boan_h5upload');
        } 
        return $rtn;
    }
   
    function  global_footer() {
        global  $_G;
        $rtn = '';
        $return = '';
        if($_GET['mod'] == 'post'){
            $rtn .= $this->getSwitchCode();
            $rtn .= boan_set_jq();
            include template('boan_h5upload:lang');
            $rtn .= $return;
            
            if($_G['BOAN_OSS'] && $_G['BOAN_OSS']::$oss_server_name == 'tencent'){
                $rtn .= "<script src=\"source/plugin/boan_h5upload/js/cos-auth.min.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
            }
            
            $rtn .= "<script src=\"source/plugin/boan_h5upload/js/webuploader.min.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
            $rtn .= "<script src=\"source/plugin/boan_h5upload/js/exif.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
           
            $rtn .= "<script src=\"source/plugin/boan_h5upload/js/boan_h5upload.js?{$_G['formhash']} \" charset=\"utf-8\" type=\"text/javascript\"></script>";
            $rtn .= "<script src=\"source/plugin/boan_h5upload/js/Sortable.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
           
            if(file_exists(DISCUZ_ROOT.'./source/plugin/boan_h5upload/qrcode.inc.php')){
                $rtn .= "<script src=\"source/plugin/boan_h5upload/qrcodetoimg/js/qrcode.min.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
                $rtn .= "<script src=\"source/plugin/boan_h5upload/qrcodetoimg/js/qrcodetoimg.js?{$_G['formhash']}\" charset=\"utf-8\" type=\"text/javascript\"></script>";
            }
            $rtn .= boan_reset_jq();
        }else if($_GET['mod'] == 'viewthread' || $_GET['mod'] == 'forumdisplay'  || $_GET['mod'] == 'follow'){
            if(!$this->vars['is_fast']){
                $rtn .= $this->getSwitchCode();
                $rtn .= boan_set_jq();
                include template('boan_h5upload:lang');
                $rtn .= $return;
                $rtn .= "<script src=\"source/plugin/boan_h5upload/js/webuploader.min.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
                $rtn .= "<script src=\"source/plugin/boan_h5upload/js/boan_h5upload_fast.js?{$_G['formhash']} \" charset=\"utf-8\" type=\"text/javascript\"></script>";
                if($_G['BOAN_OSS'] && $_G['BOAN_OSS']::$oss_server_name == 'tencent'){
                    $rtn .= "<script src=\"source/plugin/boan_h5upload/js/cos-auth.min.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
                }
                $rtn .= boan_reset_jq();
            }else{
                $rtn .= "<script>boan_jq('#SWFUpload_0').hide();boan_jq('#spanButtonPlaceholder').hide()</script>";               
            }
        }
        elseif(($_GET['mod'] == 'portalcp' && $_GET['ac'] == 'article') || ($_GET['mod'] == 'portalcp' && $_GET['op'] == 'edit')){
            $rtn .= $this->getSwitchCode();
            $rtn .= boan_set_jq();
            include template('boan_h5upload:lang');
            $rtn .= $return;
            $rtn .= "<script src=\"source/plugin/boan_h5upload/js/webuploader.min.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
            $rtn .= "<script src=\"source/plugin/boan_h5upload/js/boan_h5upload_portal.js?{$_G['formhash']} \" charset=\"utf-8\" type=\"text/javascript\"></script>";
            $rtn .= boan_reset_jq();
        }elseif($_GET['mod'] == 'spacecp' && $_GET['ac'] == 'upload'){
            $rtn .= $this->getSwitchCode();
            $rtn .= boan_set_jq();
            include template('boan_h5upload:lang');
            $rtn .= $return;
            $rtn .= "<script src=\"source/plugin/boan_h5upload/js/webuploader.min.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
            $rtn .= "<script src=\"source/plugin/boan_h5upload/js/boan_h5upload_album.js?{$_G['formhash']} \" charset=\"utf-8\" type=\"text/javascript\"></script>";
            $rtn .= boan_reset_jq();
        } elseif($_GET['mod'] == 'spacecp' && $_GET['ac'] == 'blog'){
            $rtn .= $this->getSwitchCode();
            $rtn .= boan_set_jq();
            include template('boan_h5upload:lang');
            $rtn .= $return;
            $rtn .= "<script src=\"source/plugin/boan_h5upload/js/webuploader.min.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
            $rtn .= "<script src=\"source/plugin/boan_h5upload/js/boan_h5upload_blog.js?{$_G['formhash']} \" charset=\"utf-8\" type=\"text/javascript\"></script>";
            $rtn .= boan_reset_jq();
        } elseif($_GET['mod'] == 'spacecp' && $_GET['ac'] == 'avatar' && !$_GET['old']){
            $rtn = '';
            if( $this->vars['isavatar']){
                global $_G,$uc_avatarflash;
                $aratarflash = implode(",", $uc_avatarflash);
                $gif_size = $this->vars['gif_size'];
                $is_saya = dintval($this->vars['is_saya']);
                if($is_saya){
                    $saya_vals = $_G['cache']['plugin']['saya_avatarverify'];
                    $group_ids = unserialize(stripslashes($saya_vals['verifygroup']));
                    if(!in_array($_G['groupid'],$group_ids) || empty($saya_vals)){
                        $is_saya = 0;
                    }
                }
                include template('boan_h5upload:lang');
                $rtn .= $return;
                $rtn .="<script> var uc_avatarflash=\"$aratarflash\".split(',');var gif_size=$gif_size; var is_saya=$is_saya; </script>";
                $rtn .= "<script src=\"source/plugin/boan_h5upload/js/boan_h5upload_avatar.js?{$_G['formhash']} \" charset=\"utf-8\" type=\"text/javascript\"></script>";
            }
        } 
        return $rtn;
    }

    function avatar($value){
        global $_G;
        $_G['hookavatar'] = boan_set_avatar($value);
    }
}
class plugin_boan_h5upload_forum extends plugin_boan_h5upload{
    private function get_limit_str($files_limit){
        global $_G;
        require_once libfile('function/post');
        $str = '';
        $pid = dintval($_GET['pid']);
        $attList = getattach($pid);
        $att_ct = @count($attList['attachs']['used']) + @count($attList['attachs']['unused']);
        $img_ct = @count($attList['imgattachs']['used']) + @count($attList['imgattachs']['unused']);;
        $limit_ct =  $files_limit - $att_ct -$img_ct;
        if($limit_ct > 0){
            $str = lang(P_NAME, 'limit_1').$files_limit.lang(P_NAME, 'limit_3').','.lang(P_NAME, 'limit_2').$limit_ct.lang(P_NAME, 'limit_3').'.';
        }else{
            $str =  lang(P_NAME, 'limit_4');
        }
        $str = '<span style = "color:red">'.$str.'</span>';
        return $str;
    }
    
    function post_btn_extra(){
        global $_G;
        if($this->vars['is_remotetolocal'] && $_G['group']['allowdownremoteimg']){
            return '<label><input type="checkbox" name="boanh5_remote" id="boanh5_remote" value="true" class="pc" checked="checked">'.lang(P_NAME, 'auto_remote').'</label>';
        }
        return '';
       
    }
    
    function post_image_btn_extra(){
        global  $_G;
        $str = '';
        $groups = $this->vars['exclude_limit'];
        $groups = unserialize($groups);

        $forums = $this->vars['forums_limit'];
        $forums = unserialize($forums);
        
        $files_limit = $this->vars['files_limit'];
        if($this->vars['is_att_limit'] &&  $files_limit && !in_array($_G['groupid'], $groups) && in_array($_G['fid'], $forums)){
            $str = $this->get_limit_str($files_limit);
        }
        return $str;
    }
    
    function  post_attach_btn_extra(){
        global  $_G;
        $str = '';
        $groups = $this->vars['exclude_limit'];
        $groups = unserialize($groups);
        
        $forums = $this->vars['forums_limit'];
        $forums = unserialize($forums);
        
        $files_limit = $this->vars['files_limit'];
        if($this->vars['is_att_limit'] &&  $files_limit && !in_array($_G['groupid'], $groups) && in_array($_G['fid'], $forums)){
            $str = $this->get_limit_str($files_limit);
        }
        return $str;
    }
    
    function post_bottom_output() {
        global $_G, $swfconfig,$allowuploadtoday;
        $groups = $this->vars['exclude_limit'];
        $groups = unserialize($groups);
        
        $forums = $this->vars['forums_limit'];
        $forums = unserialize($forums);
        
        $files_limit = $this->vars['files_limit'];
        if($this->vars['is_att_limit'] &&  $files_limit && !in_array($_G['groupid'], $groups) && in_array($_G['fid'], $forums)){
            $pid = dintval($_GET['pid']);
            $attList = getattach($pid);
            $att_ct = @count($attList['attachs']['used']) + @count($attList['attachs']['unused']);
            $img_ct = @count($attList['imgattachs']['used']) + @count($attList['imgattachs']['unused']);;
            $limit_ct =  $files_limit - $att_ct -$img_ct;
            if($limit_ct > 0){
                $allowuploadtoday = true;
            }else{
                $allowuploadtoday = false;
            }
            
            $swfconfig['limit'] = $limit_ct; 
        }
        return '';
        
    }
    
    function attachment_boanoss(){
        global $_G;
       
        if($_G['BOAN_OSS']){
            $flag = 1;
            @list($aid) = daddslashes(explode('|', base64_decode($_GET['aid'])));
            $aid = intval($aid);
            $attach = C::t('forum_attachment_n')->fetch('aid:'.$aid, $aid);
            if($attach && !preg_match('/^\d{6}\/\d{2}/is', $attach['attachment']) ){
                $flag = 0;
            }
            if($flag){
                require_once OSS_ROOT.'./source/discuz/forum_attachment.php';
                dexit();
            }
        }
    }
 
    function image_boanoss(){
        global $_G;
        if($_G['BOAN_OSS']){
            require_once OSS_ROOT.'./source/discuz/forum_image.php';
            dexit();
        }
        
    }
    function ajax_boanoss(){
        global $_G;
        if($_GET['action'] == 'setthreadcover' && $_G['BOAN_OSS'] &&  $_G['BOAN_OSSCONFIG']['oss_referer']){
            require_once OSS_ROOT.'./source/discuz/forum_ajax_setthreadcover.php';
            dexit();
        }
    }
    function viewthread_bottom(){
       global  $_G;
       $subject = $_G['forum_thread']['subject'];
       $title = $_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']];
       $rtn = '';
       
       if($this->vars['isseo']){
           $rtn .= "<script>
                   /*boan_jq(\"img[id^='aimg']\").attr('alt','$subject');boan_jq(\"img[id^='aimg']\").attr('title','$title');
                  boan_jq(\"img[id^='aimg']\").each(function(index,el){
                   if(boan_jq(el).width()>=300){
                   var W = boan_jq(el).parent().parent().parent().parent().width();
                   boan_jq(el).attr('width','100%');
               }
               });*/
           </script>";
       }
       
       return $rtn;
    }
    function viewthread_bottom_output(){
        global $_G;
        global $postlist;
        
       
        if($_G['BOAN_OSS'] && !empty($_G['BOAN_OSSCONFIG']['oss_style']) && !in_array($_G['fid'], $this->vars['ossstyleforums'])){
            $p = '/https?:\/\/(?!(\\.jpg|\\.png)).+?(\\.jpg\\.thumb\\.jpg|\\.png\\.thumb\\.jpg|\\.jpg|\\.png)/is';
             foreach ($postlist as $k => $v){
                 $postlist[$k]['message'] = preg_replace_callback($p, function($m){
                    global $_G;
                    if(strpos($m[0],$_G['BOAN_OSSCONFIG']['oss_url']) === FALSE){
                         return $m[0];
                    }
                    if(strpos($m[0],'?') !== FALSE){
                        return $m[0].'&'.$_G['BOAN_OSS']->getImgStyle($_G['BOAN_OSSCONFIG']['oss_style']);
                    }else{
                        return $m[0].'?'.$_G['BOAN_OSS']->getImgStyle($_G['BOAN_OSSCONFIG']['oss_style']);
                    }
                
               }, $v['message']);
               
               foreach ($postlist[$k]['attachments'] as $k1 => $v1){
                   if($v1['isimage'] && empty($v1['thumb']) && strpos($v1['url'],$_G['BOAN_OSSCONFIG']['oss_url']) !== FALSE){
                       $v1['attachment'] = $v1['attachment'].'?'.$_G['BOAN_OSS']->getImgStyle($_G['BOAN_OSSCONFIG']['oss_style']);
                       $postlist[$k]['attachments'][$k1] = $v1; 
                   }
                  
               }
             }
        }
     
    }
    
    function post_boan_getromote(){
        global $_G;
        if($_GET['boanh5_remote']){
            define('BOANH5_ROMOTEPIC','1');
            require_once(DISCUZ_ROOT.'./source/plugin/boan_h5upload/downremoteimg.inc.php');
        }
        
    }
    
}

class plugin_boan_h5upload_portal extends plugin_boan_h5upload{
     function view_article_content_output(){
        global  $_G,$article;
        $title = $article['title'];
        if($this->vars['isseo']){
            $rtn .= "<script>boan_jq(\"#article_content img\").attr('alt','$title');boan_jq(\"#article_content img\").attr('title','$title');</script>";
        }
        
        return $rtn;
    }
}

class plugin_boan_h5upload_misc extends plugin_boan_h5upload{
    function imgcropper(){
        global  $_G;
        if($_G['BOAN_OSS'] && $_G['BOAN_OSSCONFIG']['oss_referer']){
            require_once OSS_ROOT.'./source/discuz/misc_imgcropper.php';
            dexit();
        }
    }
}

