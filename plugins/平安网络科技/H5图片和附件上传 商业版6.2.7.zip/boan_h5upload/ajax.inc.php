<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
if(empty($_G['cache']['plugin'])){
    loadcache('plugin');
}
$vars = $_G['cache']['plugin']['boan_h5upload'];
if($_G['uid']>0){
    if($_GET['avatar']){
        savecache('boan_avatar_'.$_G['uid'], array(
            'timeout'=>strtotime('1 day'),
        ));
        echo '1';
        dexit();
    }
    
    if($_GET['qrcode']){
        $qrcodeurl = '';
        $k = $vars['pic_qrcode_outtime'] ? $vars['pic_qrcode_outtime'] * 60 : 1;
        $k = authcode($_G['member']['uid'],'ENCODE',$_G['config']['security']['authkey'],$k);
        $qrcodeurl = $_G[siteurl].'plugin.php?id=boan_h5upload:qrcode&uid='.rawurlencode($k);
        echo $qrcodeurl;
    }
    
    if($_GET['cleanatt']){
        require_once libfile('function/forum');
        echo "<?xml version=\"1.0\" encoding=\"".CHARSET."\"?>\n<root><![CDATA[";
        if(!$_G['adminid']){
            echo '<em class="edited">没有权限</em>';
            echo ']]></root>';
            dexit();
        }
        
        loadcache('boan_oss_cleanatt_cache',true);
        $cache = $_G['cache']['boan_oss_cleanatt_cache'];
        
        if(empty($cache['lastweektime']) || strtotime("-1 week") > $cache['lastweektime']){
            $cache['lastweektime'] = time();
            $cache['weekdayatt'] = 0;
            $cache['weekdayatt_ct'] = 0;
            $cache['weekdaytemp'] = 0;
            $cache['weekdaytemp_ct'] = 0;
        }
        
        $expire = time()-$cache['limitatt']*60;
        $temp_att = DB::fetch_all('SELECT * FROM %t WHERE dateline<%i',array('forum_attachment_unused',$expire));
        foreach ($temp_att as $attach){
            $cache['weekdayatt_ct']++;
            $cache['weekdayatt'] += $attach['filesize'];
            DB::delete('forum_attachment_unused', 'aid='.$attach['aid']);
            DB::delete('forum_attachment', 'aid='.$attach['aid']);
            dunlink($attach);
        }
        
        
        $tempdir = scandir($_G['setting']['attachdir'].'/temp/');
        foreach ($tempdir as $t){
            if($t != '.' && $t != '..' && !is_dir($_G['setting']['attachdir'].'/temp/'.$t) && (time()-$cache['limittemp']*60) > filemtime($_G['setting']['attachdir'].'/temp/'.$t)){
                $cache['weekdaytemp_ct']++;
                $cache['weekdaytemp'] += filesize($_G['setting']['attachdir'].'/temp/'.$t);
                @unlink($_G['setting']['attachdir'].'/temp/'.$t);
            }
        }
        
        savecache('boan_oss_cleanatt_cache',$cache);
        
        echo '<script>location.reload();</script>';
        echo ']]></root>';
        dexit();
        
    }
    
    
    if($_GET['oss'] && isset($_G['BOAN_OSS'])){
        $swfhash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
        $type = $_GET['type'];
        $att_type = $_GET['atttype'];
        if( $_GET['hash'] != $swfhash || empty($_GET['filename']) || !in_array($type, array('forum')) || !in_array($att_type,array('image','attach'))) {
            echo -10;
            dexit();
        }
        
        $upload = new discuz_upload();
        $filename = $_GET['filename'];
        $type = $upload->check_dir_type($type);
        $filename =  trim($filename);
        $ext = $upload->fileext($filename);
        
        $filename =  dhtmlspecialchars($filename, ENT_QUOTES);
        if(strlen($filename) > 90) {
            $filename = cutstr($filename, 80, '').'.'.$ext;
        }
        
        $extension = $upload->get_target_extension($ext);
        $dir = $type.'/'.$upload->get_target_dir($type, 0);
        $object = $upload->get_target_filename($upload->type,0, '').'.'.$extension;
        
        $_G['member'] = getuserbyuid($_G['uid']);
        $_G['groupid'] = $_G['member']['groupid'];
        loadcache('usergroup_'.$_G['member']['groupid']);
        $_G['group'] = $_G['cache']['usergroup_'.$_G['member']['groupid']];
        $allowupload = !$_G['group']['maxattachnum'] || $_G['group']['maxattachnum'] && $_G['group']['maxattachnum'] > getuserprofile('todayattachs');
        if(!$allowupload) {
            echo -6;
            dexit();
        }
        
        if($_G['group']['attachextensions'] && (!preg_match("/(^|\s|,)".preg_quote($ext, '/')."($|\s|,)/i", $_G['group']['attachextensions']) || !$ext)) {
            echo -1;
            dexit();
        }
        
        echo $_G['BOAN_OSS']->getPolicy(OSS_BASEDIR.$dir, $object);
        dexit();
        
    }
    
}
echo '0';