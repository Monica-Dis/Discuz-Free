<?php 
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
define('P_NAME', 'plugin/boan_h5upload');

$guid = $_GET['guid'];

if(empty($_GET['simple'])) {
    $_FILES['file']['name'] = diconv(urldecode($_FILES['file']['name']), 'UTF-8');
    $_FILES['file']['type'] = $_GET['filetype'];
}
$upload = new discuz_upload();
$upload->init($_FILES['file'], 'forum');
$attach = $upload->attach;

$uploadDir = getglobal('setting/attachdir').'./'.'forum'.'/'.$attach['attachdir'];
$targetDir = getglobal('setting/attachdir').'./temp/';
$cleanupTargetDir = true; // Remove old files
$maxFileAge = 5 * 3600; // Temp file age in seconds


$chunk = isset($_GET["chunk"]) ? intval($_GET["chunk"]) : 0;
$chunks = isset($_GET["chunks"]) ? intval($_GET["chunks"]) : 1;



global $_G;
if(empty($_G['cache']['plugin'])){
    loadcache('plugin');
}
$vars = $_G['cache']['plugin']['boan_h5upload'];

$group_ids = unserialize(stripslashes($vars['big_group']));

if(!in_array($_G['groupid'],$group_ids)){
    errormsg(10);
}

if($_GET['boanh5op'] == 'upload'){
    if (!file_exists($targetDir)) {
        @mkdir($targetDir);
    }
    if (!file_exists($uploadDir)) {
        @mkdir($uploadDir);
    }
    
    $filePath = "{$targetDir}{$guid}";
    if ($cleanupTargetDir) {
        if (!is_dir($targetDir) || !$dir = opendir($targetDir)) {
            errormsg(8);
        }
        while (($file = readdir($dir)) !== false) {
            $tmpfilePath = $targetDir  . $file;
            if ($tmpfilePath == "{$filePath}_{$chunk}.part" || $tmpfilePath == "{$filePath}_{$chunk}.parttmp") {
                continue;
            }
            if (preg_match('/\.(part|parttmp)$/', $file) && (@filemtime($tmpfilePath) < time() - $maxFileAge)) {
                @unlink($tmpfilePath);
            }
        }
        closedir($dir);
    }
    
    if (!$out = @fopen("{$filePath}_{$chunk}.parttmp", "wb")) {
        errormsg(8);
    }
    if (!empty($_FILES)) {
        if ($_FILES["file"]["error"] || !is_uploaded_file($_FILES["file"]["tmp_name"])) {
            errormsg(9);
        }
        if (!$in = @fopen($_FILES["file"]["tmp_name"], "rb")) {
            errormsg(9);
        }
    } else {
        if (!$in = @fopen("php://input", "rb")) {
            errormsg(9);
        }
    }
    while ($buff = fread($in, 4096)) {
        fwrite($out, $buff);
    }
    @fclose($out);
    @fclose($in);
    
    rename("{$filePath}_{$chunk}.parttmp", "{$filePath}_{$chunk}.part");
    
    $index = 0;
    $done = true;
    for( $index = 0; $index < $chunks; $index++ ) {
        if ( !file_exists("{$filePath}_{$index}.part") ) {
            $done = false;
            break;
        }
    }
    if ( $done ) {
        $uploadPath = $attach['target'];
        
        if (!$out = @fopen($uploadPath, "wb")) {
            errormsg(8);
        }
        if ( flock($out, LOCK_EX) ) {
            for( $index = 0; $index < $chunks; $index++ ) {
                if (!$in = @fopen("{$filePath}_{$index}.part", "rb")) {
                    break;
                }
                while ($buff = fread($in, 4096)) {
                    fwrite($out, $buff);
                }
                @fclose($in);
                @unlink("{$filePath}_{$index}.part");
            }
            flock($out, LOCK_UN);
        }
        @fclose($out);
        
        require_once   DISCUZ_ROOT.'./source/plugin/boan_h5upload/filetoattach.class.php';
       
        $forumattachextensions = '';
        $fid = intval($_GET['fid']);
        if($fid) {
            $forum = $fid != $_G['fid'] ? C::t('forum_forum')->fetch_info_by_fid($fid) : $_G['forum'];
            if($forum['status'] == 3 && $forum['level']) {
                $levelinfo = C::t('forum_grouplevel')->fetch($forum['level']);
                if($postpolicy = $levelinfo['postpolicy']) {
                    $postpolicy = dunserialize($postpolicy);
                    $forumattachextensions = $postpolicy['attachextensions'];
                }
            } else {
                $forumattachextensions = $forum['attachextensions'];
            }
            if($forumattachextensions) {
                $_G['group']['attachextensions'] = $forumattachextensions;
            }
        }
        
        new filetoattach($attach,'forum');
  }
}else if($_GET['boanh5op'] == 'delete'){
    $targetDir = getglobal('setting/attachdir').'./temp/';
    del_chunks($targetDir, $_GET['guid']);
}

function del_chunks($targetDir,$guid){
    if(empty($guid)){
        return ;
    }
    if (!is_dir($targetDir) || !$dir = opendir($targetDir) ) {
       return ;
    }
    
    while (($file = readdir($dir)) !== false) {
        $tmpfilePath = $targetDir.$file;
        if(strpos($file,$guid) !== false) {
            @unlink($tmpfilePath);
        }
    }
    closedir($dir);
}

function errormsg($statusid) {
    echo  -$statusid;
    exit;
}






