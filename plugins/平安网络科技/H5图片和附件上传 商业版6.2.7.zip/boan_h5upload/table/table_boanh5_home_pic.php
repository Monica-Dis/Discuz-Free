<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class table_boanh5_home_pic extends discuz_table
{
    public function __construct() {
        
        $this->_table = 'home_pic';
        $this->_pk    = 'picid';
        
        parent::__construct(); /*dism �� taobao �� com*/
    }
    public function fetch_by_filename($uid,$remote,$filepath){
        
        return DB::result_first("SELECT picid FROM %t WHERE uid = $uid AND remote = $remote AND filepath = '$filepath'", array($this->_table));
    }
    public function update_by_remote($picid,$remote){
        return DB::update($this->_table, array('remote'=>$remote), DB::field('picid', $picid));
    }
    
    public function total_by_remote($remote = 0){
        return DB::result_first("SELECT count(*) FROM %t " .($remote != 4 ? "WHERE  remote = $remote " : ''), array($this->_table));
    }
    
    public function total_by_alubm_remote($remote = 0){
        return DB::result_first("SELECT count(*) FROM %t " .($remote != 0 ? "WHERE  picflag = $remote " : ''), array('home_album'));
    }
    
    
    public function update_by_picid($picid,$remote) {
        return ($picid) ? DB::update($this->_table, array('remote'=>$remote), DB::field('picid', $picid)) : false;
    }
    public function update_by_albumid($albumid,$remote) {
        return ($albumid) ? DB::update('home_album', array('picflag'=>$remote), DB::field('albumid', $albumid)) : false;
    }
    
    
    
    public function fetch_by_limit($limit = 10,$isremote = 0, $step = 0,&$start = 0) {
        static $pos = 0;
        $start  && $pos = &$start;
        
        $pos += $step;
        $start = $pos;
        if($limit) {
            $parameter = array($this->_table);
            if($isremote == 0 ){
                return DB::fetch_all("SELECT * FROM %t WHERE remote = 0  ".DB::limit($pos, $limit), $parameter, $this->_pk);
            }else{
                return DB::fetch_all("SELECT * FROM %t WHERE remote = 1  ".DB::limit($pos, $limit), $parameter, $this->_pk);
            }
        }
        return array();
    }
    
    
    public function fetch_by_cover_limit($limit = 10,$isremote = 0) {
      
        if($limit) {
            $parameter = array('home_album');
            if($isremote == 0 ){
                return DB::fetch_all("SELECT * FROM %t WHERE picflag = 1  ".DB::limit(0, $limit), $parameter, 'albumid');
            }else{
                return DB::fetch_all("SELECT * FROM %t WHERE picflag = 2  ".DB::limit(0, $limit), $parameter, 'albumid');
            }
        }
        return array();
    }
    
    
    
    
    
    
    
}