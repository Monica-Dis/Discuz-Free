<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_boanh5_attachment extends discuz_table {
    function __construct(){
        $this->_table = '';
        $this->_pk    = 'aid';
        parent::__construct(); /*dism �� taobao �� com*/
    }

    private function _get_table($tableid) {
        if(!is_numeric($tableid)) {
            list($idtype, $id) = explode(':', $tableid);
            if($idtype == 'aid') {
                $aid = dintval($id);
                $tableid = DB::result_first("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE aid='$aid'");
            } elseif($idtype == 'tid') {
                $tid = (string)$id;
                $tableid = dintval($tid{strlen($tid)-1});
            } elseif($idtype == 'pid') {
                $pid = dintval($id);
                $tableid = DB::result_first("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE pid='$pid' LIMIT 1");
                $tableid = $tableid >= 0 && $tableid < 10 ? intval($tableid) : 127;
            }
        }
        if($tableid >= 0 && $tableid < 10) {
            return 'forum_attachment_'.intval($tableid);
        } elseif($tableid == 127) {
            return 'forum_attachment_unused';
        } else {
            throw new DbException('Table forum_attachment_'.$this->_table.' has not exists');
        }
    }
    
    private function _check_id($idtype, $ids) {
        if($idtype == 'pid' && $this->_table == 'forum_attachment_unused') {
            return false;
        }
        if(in_array($idtype, array('aid', 'tid', 'pid', 'uid')) && !empty($ids)) {
            return true;
        } else {
            return false;
        }
    }
    
    public function get_toatl_count_by_forum(){
        $count = 0;
        for($i = 0;$i < 10; $i++){
            $sql = 'SELECT COUNT(*) FROM '. DB::table($this->_get_table($i));
            $count += DB::result_first($sql);
        }
        
        return $count;
    }
    
    public function get_total_filecount($isremote = 0,$date = '',$ext = '',$size = 20000) {
        $size *= 1000;
        $attachsize = 0;
        $sql = 'SELECT COUNT(aid) FROM '. DB::table($this->_get_table(0)) .' WHERE remote = '.$isremote;
        !empty($size) && $sql .= ' AND filesize <= '.$size;
        !empty($date) && $sql .= ' AND dateline >= '.strtotime($date);
        if(!empty($ext)){
            $ext = explode(',', $ext);
            $sql .= ' AND (';
            $arr = array();
            foreach ($ext as $v){
                $arr[] = " filename like '%.$v' ";
            }
            $sql .= implode(' OR ', $arr);
            $sql .= ')';
        }
     
        for($i = 0;$i < 10;$i++) {
            $attachsize += DB::result_first($sql);
            ($i+1) <10 && $sql = str_replace(DB::table($this->_get_table($i)), DB::table($this->_get_table($i+1)), $sql);
        }
        return $attachsize;
    }
    
    public function fetch_by_limit($limit,$isremote = 0,$date = '',$ext = '',$size = 20000,&$step = 0,&$t_id = 0,&$p = 0){
        static $table_id =0;
        static $pos = 0;
        static $ct = 1;
        $size *= 1000;
        
        $t_id && $table_id = $t_id;
        $p && $pos = $p;
        
        $ct++;
        $reulst = null;
        
        if($table_id >= 10){
            return $reulst;
        }
        
        $sql = 'SELECT * FROM '. DB::table($this->_get_table($table_id)) .' WHERE remote = '.$isremote;
        !empty($size) && $sql .= ' AND filesize <= '.$size;
        
        !empty($date) && $sql .= ' AND dateline >= '.strtotime($date); 
        
       
        if(!empty($ext)){
            $ext = explode(',', $ext);
            $sql .= ' AND (';
            $arr = array();
            foreach ($ext as $v){
                $arr[] = " filename like '%.$v' ";
            }
            $sql .= implode(' OR ', $arr);
            $sql .= ')';
        }
        $pos += $step;
        $p = $pos;
        $sql .= ' LIMIT '.$pos.','.dintval($limit);
        
        
        for($i = $table_id;$i <10; $i++){
            $reulst = DB::fetch_all($sql);
            if(count($reulst)){
                return $reulst;
            }
            $table_id = $t_id = $i+1;
          
            if(($i+1) <10){
                $sql = str_replace(DB::table($this->_get_table($i)), DB::table($this->_get_table($i+1)), $sql);
                $sql = str_replace('LIMIT '.$pos, 'LIMIT 0', $sql);
            }
            $pos = $p = $step = 0;
        }
        return $reulst;
    }
    
}