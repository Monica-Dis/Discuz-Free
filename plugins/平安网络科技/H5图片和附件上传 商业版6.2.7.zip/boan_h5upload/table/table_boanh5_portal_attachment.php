<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_boanh5_portal_attachment extends discuz_table
{
    public function __construct() {
        
        $this->_table = 'portal_attachment';
        $this->_pk    = 'attachid';
        
        parent::__construct(); /*dism �� taobao �� com*/
    }
    public function get_count_attachment($isremote = 0){
        $parameter = array($this->_table);
        if($isremote == 0){
            return DB::result_first("SELECT count(*) FROM %t WHERE remote = 0 ",$parameter);
        }elseif($isremote == 1){
            return DB::result_first("SELECT count(*) FROM %t WHERE remote = 1  ",$parameter);
        }else{
            return DB::result_first("SELECT count(*) FROM %t ",$parameter);
        }
    }
    
    public function get_count_article(){
        return DB::result_first("SELECT count(*) FROM %t",array('portal_article_content'));
    }
    
    public function update_by_attachid($attachid,$remote) {
        $aid = dintval($attachid);
        return ($attachid) ? DB::update($this->_table, array('remote'=>$remote), DB::field('attachid', $attachid)) : false;
    }
    
    
    public function fetch_by_article_limit($limit = 2,$step = 0){
        if($limit) {
            $parameter = array('portal_article_content');
            return DB::fetch_all("SELECT * FROM %t".DB::limit($step, $limit), $parameter, 'cid');
        }
        return array();
    }
    
    public function fetch_by_limit($limit = 10,$isremote = 0, $step = 0,&$start = 0) {
        static $pos = 0;
        $start  && $pos = &$start;
        
        $pos += $step;
        $start = $pos;
        if($limit) {
            $parameter = array($this->_table);
            if($isremote == 0 ){
                return DB::fetch_all("SELECT * FROM %t WHERE remote = 0  ".DB::limit($pos, $limit), $parameter, $this->_pk);
            }else{
                return DB::fetch_all("SELECT * FROM %t WHERE remote = 1  ".DB::limit($pos, $limit), $parameter, $this->_pk);
            }
        }
        return array();
    }
    
    
    
}