<?php 
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_boanh5_forum_typeoptionvar extends discuz_table
{
    public function __construct() {
        
        $this->_table = 'forum_typeoptionvar';
        $this->_pk    = '';
        
        parent::__construct(); /*dism �� taobao �� com*/
    }
    public function fetch_all_by_value($remote = 0,$limit = 2,&$setp = 0) {
       
        if($remote == 0){
            $sql = 'SELECT p.*,s.identifier FROM '. DB::table($this->_table).' AS p JOIN '.DB::table('forum_typeoption')." AS s ON p.optionid = s.optionid WHERE s.type = 'image'  AND p.value like  '%data/attachment/%' AND p.value not like '%http%'";
            $sql .= "LIMIT $setp , $limit";
        }elseif($remote == 1){
            $sql = 'SELECT p.*,s.identifier FROM '. DB::table($this->_table).' AS p JOIN '.DB::table('forum_typeoption')." AS s ON p.optionid = s.optionid WHERE s.type = 'image'  AND p.value like '%http%'";
            $sql .= "LIMIT $setp , $limit";
        }else{
            $sql = 'SELECT p.*,s.identifier FROM '. DB::table($this->_table).' AS p JOIN '.DB::table('forum_typeoption')." AS s ON p.optionid = s.optionid WHERE s.type = 'image'";
            $sql .= "LIMIT $setp , $limit";
        }
        return DB::fetch_all($sql);
    }
    
    public function count_by_value($remote = 0){
        
        if($remote == 0){
            $sql = 'SELECT count(*) FROM '. DB::table($this->_table)." WHERE value like '%url%' AND value like '%data/attachment/%' AND value not like '%http%'";
        }elseif($remote == 1){
            $sql = 'SELECT count(*) FROM '. DB::table($this->_table)." WHERE value like '%url%' AND value like '%http%'";
        }else{
            $sql = 'SELECT count(*) FROM '. DB::table($this->_table)." WHERE value like '%url%'";
        }
        return  DB::result_first($sql);
    }
}