<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class table_boanh5_thread extends discuz_table
{
    private $_posttableid = array();
    private $_urlparam = array();
    public function __construct() {
        
        $this->_table = 'forum_thread';
        $this->_pk    = 'tid';
        $this->_pre_cache_key = 'forum_thread_';
        parent::__construct(); /*dism �� taobao �� com*/
    }
    public function get_table_name($tableid = 0){
        $tableid = intval($tableid);
        return $tableid ? "forum_thread_$tableid" : 'forum_thread';
    }
    public function get_count_cover($isremote = 0){
        $parameter = array($this->get_table_name());
        if($isremote == 0){
           return DB::result_first("SELECT count(*) FROM %t WHERE cover > 0  AND displayorder>'-1' ",$parameter);
        }else{
           return DB::result_first("SELECT count(*) FROM %t WHERE cover < 0  AND displayorder>'-1' ",$parameter);
        }
     
    }
    public function fetch_by_cover($limit = 10,$isremote = 0, $step = 0,&$start = 0) {
        static $pos = 0;
        $start  && $pos = &$start;
        
        $pos += $step;
        $start = $pos;
        if($limit) {
            $parameter = array($this->get_table_name());
            if($isremote == 0 ){
                return DB::fetch_all("SELECT * FROM %t WHERE cover > 0  AND displayorder>'-1' ".DB::limit($pos, $limit), $parameter, $this->_pk);
            }else{
                return DB::fetch_all("SELECT * FROM %t WHERE cover < 0  AND displayorder>'-1' ".DB::limit($pos, $limit), $parameter, $this->_pk);
            }
        }
        return array();
    }
    
}