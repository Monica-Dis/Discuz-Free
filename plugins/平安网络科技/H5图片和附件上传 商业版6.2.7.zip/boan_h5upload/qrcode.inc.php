<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

global $_G;
define('P_NAME', 'plugin/boan_h5upload');

require_once  libfile('function/member');
$uid = authcode($_GET['uid'],'DECODE',$_G['config']['security']['authkey']);
$uid = intval($uid);
$user = getuserbyuid($uid);
if($user['uid'] && empty($user['self'])){
    setloginstatus($user, 3600);
    dheader('location: plugin.php?id=boan_h5upload:qrcode');
}elseif(empty($_G['uid'])){
    $url = 'plugin.php?id=boan_h5upload:qrcode';
    dheader('location:member.php?mod=logging&action=login&mobile=2&referer='.rawurlencode($url));
}


if(empty($_G['cache']['plugin'])){
    loadcache('plugin');
}
$vars = $_G['cache']['plugin']['boan_h5upload'];
$uid = $_G['uid'];
$user = getuserbyuid($uid);
setloginstatus($user, 1);

$hash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
$formhash = formhash();
$maxfilesize = $_G['group']['maxattachsize'];
$maxfilesize = $maxfilesize ? "$maxfilesize*10" : '0';
$pic_width = dintval($vars['pic_width']);
$pic_height = dintval($vars['pic_height']);
$pic_quality = $vars['pic_quality'] ? $vars['pic_quality'] : 100;
$compress = '{';
$pic_width ? $compress .= "width:$pic_width," :  $compress .= "width:8000,";
$pic_height ? $compress .= "height:$pic_height," : $compress .= "height:8000,";
$pic_quality && $compress .= "quality:$pic_quality,";
$compress .= 'noCompressIfLarger:true,crop:false,}';

require_once libfile('function/upload');
$swfconfig = getuploadconfig($_G['uid'], $_G['fid']);
include template('boan_h5upload:qrcode');
