<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class oss_upload{
    var $aid;
    var $uid;
    var $error_sizelimit;
    var $object = '';
    var $data = null;
    function __construct($data){
        global $_G;
        $this->aid = 0;
        $this->error_sizelimit = 0;
        $this->data = &$data;
        $this->fid = intval($_GET['fid']);
        
        $uid = $this->uid = $_G['uid'];
        $swfhash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
        $filename = daddslashes($_GET['filename']);
        $this->object = $object = daddslashes($_GET['object']);
        $att_type = $data['type'] = $_GET['atttype'];
        $data['simple'] = dintval($_GET['simple']);
        $data['simple'] && $filename = diconv(urldecode($filename), 'UTF-8');
        if(!count($data) || empty($uid) || $_GET['hash'] != $swfhash || empty($filename) || empty($object) || !in_array($att_type, array('image','attach'))){
            return $this->uploadmsg(10);
        }
        
        $data['filename'] = diconv(urldecode($filename), 'UTF-8');
        $this->object = $data['object'];
       
       
        $_G['member'] = getuserbyuid($uid);
        $_G['groupid'] = $_G['member']['groupid'];
        loadcache('usergroup_'.$_G['member']['groupid']);
        $_G['group'] = $_G['cache']['usergroup_'.$_G['member']['groupid']];
        
        if(empty($data['size'])) {
           return  $this->uploadmsg(2);
        }
        
        if($_G['group']['maxattachsize'] && $data['size'] > $_G['group']['maxattachsize']) {
            $this->error_sizelimit = $_G['group']['maxattachsize'];
            return  $this->uploadmsg(3);
        }
        
        if($data['size'] && $_G['group']['maxsizeperday']) {
            $todaysize = getuserprofile('todayattachsize') + $data['size'];
            if($todaysize >= $_G['group']['maxsizeperday']) {
                $this->error_sizelimit = 'perday|'.$_G['group']['maxsizeperday'];
                return $this->uploadmsg(11);
            }
        }
        updatemembercount($uid, array('todayattachs' => 1, 'todayattachsize' => $data['size']));
        
        if(!empty($data['width'])){
           $_G['BOAN_OSS']->setAcl($this->object,'public');
        }
        
        !empty($data['width']) && $data['isimage'] = 1;
        if($data['type'] != 'image' && $data['width']>0) {
            $data['isimage'] = -1;
        }
        $thumb = 0;
        $remote = 1;
        $width = $data['width'];
        $tmpfilename  = '';
        $havewater = false;
        if($width && $data['isimage'] == 1 && ($_G['BOAN_OSSCONFIG']['oss_water'] || $_G['BOAN_OSSCONFIG']['oss_thumb'])){
            $watermark = dunserialize($_G['setting']['watermarkstatus']);
            if($_G['setting']['thumbsource'] || $_G['setting']['thumbstatus'] || $watermark) {
                require_once libfile('class/image');
                $image = new image;
                $tmpfilename =$_G['setting']['attachdir'].'temp/'.random(16).substr(strrchr(str_replace(OSS_BASEDIR.'forum/', '', $data['object']), '.'), 0);
                $_G['BOAN_OSS']->downFile($tmpfilename, $data['object']);
            }
           
            if($_G['BOAN_OSSCONFIG']['oss_water'] && $watermark){
                $havewater =$image->Watermark($tmpfilename, '', 'forum');
            }
            
            if($_G['BOAN_OSSCONFIG']['oss_thumb'] && $_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight'] && file_exists($tmpfilename)) {
                $thumb = $image->Thumb($tmpfilename, '', $_G['setting']['sourcewidth'], $_G['setting']['sourceheight'], 1, 1) ? 1 : 0;
                if ($_G['BOAN_OSS']->uploadFile($tmpfilename, $data['object'],'public')){
                    $data['width'] = $width = $image->imginfo['width'];
                    $data['size'] = $image->imginfo['size'];
                }
            }elseif($havewater){
                if($_G['BOAN_OSS']->uploadFile($tmpfilename, $data['object'],'public')){
                    $data['width'] = $width = $image->imginfo['width'];
                    $data['size'] = $image->imginfo['size'];
                }
                
            }
            
            if($_G['BOAN_OSSCONFIG']['oss_thumb'] && $_G['setting']['thumbstatus']) {
                $thumb = $image->Thumb($tmpfilename, '', $_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
                if ($_G['BOAN_OSS']->uploadFile($tmpfilename.'.thumb.jpg', $data['object'].'.thumb.jpg','public')){
                    $data['width'] = $width = $image->imginfo['width'];
                }
            }
        }
        
       
        loadcache('boan_oss_avthumb_cache');
        $avthumb_cache = $_G['cache']['boan_oss_avthumb_cache'];
        $avthumb_cache['avthumb_ext'] = explode(',', $avthumb_cache['avthumb_ext']);
        $avthumb_cache['avthumb_groups'] = unserialize($avthumb_cache['avthumb_groups']);
        if($avthumb_cache['avthumb_allow'] && in_array(fileext($filename), $avthumb_cache['avthumb_ext']) && method_exists($_G['BOAN_OSS'],'avthumb')
            && in_array($_G['groupid'],$avthumb_cache['avthumb_groups']) ){
            $pfosid = $_G['BOAN_OSS']->avthumb($object,$avthumb_cache);
            if($pfosid){
                $data['filename'] = $filename = str_replace('.'.fileext($filename), '.mp4', $filename);
            }
          
        }
        
        $this->aid = $aid = getattachnewaid($this->uid);
        $insert = array(
            'aid' => $aid,
            'dateline' => $_G['timestamp'],
            'filename' => dhtmlspecialchars(censor($data['filename'])),
            'filesize' => $data['size'],
            'attachment' => str_replace(OSS_BASEDIR.'forum/', '', $data['object']),
            'isimage' => $data['isimage'],
            'uid' => $this->uid,
            'thumb' => $thumb,
            'remote' => $remote,
            'width' => $width,
        );
        C::t('forum_attachment_unused')->insert($insert);
        $public_arr = array('png','jpg','jpeg','bmp','gif');
        $arr = explode(',', $_G['BOAN_OSSCONFIG']['oss_ext']);
        $public_arr = array_merge($public_arr,$arr);
        $ext = strtolower(substr(strrchr($data['filename'], '.'), 1));
        in_array($ext,$public_arr) ? $_G['BOAN_OSS']->setAcl($data['object'],'public') : $_G['BOAN_OSS']->setAcl($data['object'],'private');
        
        if(file_exists($tmpfilename)){
           @unlink($tmpfilename);
           @unlink($tmpfilename.'.thumb.jpg');
        }
        
                
        return $this->uploadmsg(0,$data['simple']);
    }
    
    
    
    function uploadmsg($statusid,$simple = 0) {
        global $_G;
        $this->error_sizelimit = !empty($this->error_sizelimit) ? $this->error_sizelimit : 0;
        
        if(!$this->aid && !empty($this->object)){
            $_G['BOAN_OSS']->deleteFile($this->object);
        }
       
        if(in_array("saya_imgverify",$_G['setting']['plugins']['available'])!==false && file_exists(DISCUZ_ROOT.'source/plugin/saya_imgverify/function/function_main.php') && $this->data['isimage'] == 1){
            require_once DISCUZ_ROOT.'source/plugin/saya_imgverify/function/function_main.php';
            $saya_imgverify=new saya_imgverify();
            $saya_imgverify->boan_verify($this->data['object'],$this->aid,$this->fid);
        }
        
        if($simple == 1) {
            echo 'DISCUZUPLOAD|'.$statusid.'|'.$this->aid.'|'.$this->data['isimage'].'|'.$this->error_sizelimit;
        } elseif($simple == 2) {
            echo 'DISCUZUPLOAD|'.( $this->data['type'] == 'image' ? '1' : '0').'|'.$statusid.'|'.$this->aid.'|'.$this->data['isimage'].'|'.
                ($this->data['isimage'] ? str_replace(OSS_BASEDIR.'forum/', '', $this->data['object']) : '').'|'
                .dhtmlspecialchars(censor($this->data['filename'])).'|'.$this->error_sizelimit.'|0|1';
            
        } else {
            echo  $statusid ? -$statusid : $this->aid;
        }
       
        exit;
    }
    
}
global $_G;
$data = $_G['BOAN_OSS']->getCallback($_GET['object']);
new oss_upload($data);



