<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}
require_once './source/plugin/wechat/wechat.lib.class.php';
global $_G;

if(empty($_G['cache']['plugin'])){
    loadcache('plugin');
}

$vars = $_G['cache']['plugin']['boan_h5upload'];

if($_GET['operation'] == 'getticket'){
    $data['appid'] = $vars['appID'];
    $nonceStr = random(16);
    $timestamp = time();
    $ticket = check();
    $weixin = new WeChatClient($vars['appID'],$vars['appsecret']);
    $url = $_GET['url'];
    if(is_string($ticket)){
        $data['err'] = 0 ; 
    }else{
        $data['err'] = $ticket;
        $ticket = 0;
    }
    if($ticket && $url){
        $string = "jsapi_ticket=$ticket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";
        $signature = sha1($string);
    }
    $data['noncestr'] = $nonceStr;
    $data['timestamp'] = $timestamp;
    $data['signature'] = $signature;
    $data['ticket'] = $ticket;
    echo json_encode($data);
} elseif($_GET['operation'] == 'upload'){
    require_once   DISCUZ_ROOT.'./source/plugin/boan_h5upload/imgtoattach.class.php';
   
    $_G['uid'] = dintval($_G['uid']);
    $serverid =daddslashes($_GET['serverid']);
    if(!$_G['uid'] || !$serverid){
        return ;
    }
    if(empty($_G['cache']['boan_weixin_token'])){
        loadcache('boan_weixin_token');
    }
    $weixin = new WeChatClient($vars['appID'],$vars['appsecret']);
    
    $token = $weixin->getAccessToken();
    $str = "https://file.api.weixin.qq.com/cgi-bin/media/get?access_token=$token&media_id=$serverid";
    $img = new imgtoattach($str);
}

function check(){
    global $_G;
    if(empty($_G['cache']['plugin'])){
        loadcache('plugin');
    }
    if(empty($_G['cache']['boan_weixin_token'])){
        loadcache('boan_weixin_token');
    }
    $vars = $_G['cache']['plugin']['boan_h5upload'];
    
    if($vars['appID'] && $vars['appsecret']){
        if(!$_G['cache']['boan_weixin_token'] || $_G['cache']['boan_weixin_token']['timeout'] < time()){
            $weixin = new WeChatClient($vars['appID'],$vars['appsecret']);
            $access_token = $weixin->getAccessToken();
            if($access_token){
                $str = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token='.$access_token.'&type=jsapi';
                
                $data = json_decode(@file_get_contents($str,FALSE));
                if($data->ticket){
                    savecache('boan_weixin_token', array(
                        'ticket'=>$data->ticket,
                        'access_token'=>$access_token,
                        'expires_in'=>$data->expires_in,
                        'timeout'=>time()+$data->expires_in,
                   ));
                    return $data->ticket;
                }else{
                    //
                    return -2;
                }
                
            }else{
              // echo 'sID'; 
              return -1;  
            }
        }else{
            return $_G['cache']['boan_weixin_token']['ticket'];
        }
    }else{
      //  return false;
     // echo '^usID';
    }
   return 0;
}
