<?php

/*
 PingAn at 2020-4-27
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


global $_G;

define('UC_API',  $_G['siteurl']);

define('UC_OSS_API', $_G['BOAN_OSSCONFIG']['oss_url']);

if(!($_G['BOAN_OSSCONFIG'] && $_G['BOAN_OSSCONFIG']['oss_avatar'])){
    exit(0);
}

$uid = isset($_GET['uid']) ? $_GET['uid'] : 0;
$size = isset($_GET['size']) ? $_GET['size'] : '';
list($size) = explode('?', $size);
$random = isset($_GET['random']) ? $_GET['random'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : '';
$check = isset($_GET['check_file_exists']) ? $_GET['check_file_exists'] : '';

$avatar = 'data/avatar/'.get_avatar($uid, $size, $type);
$s_avatar = 'data/avatar/'.get_avatar($uid, 'small', $type);
$m_avatar = 'data/avatar/'.get_avatar($uid, 'middle', $type);
$b_avatar = 'data/avatar/'.get_avatar($uid, 'big', $type);

$random = !empty($random) ? rand(1000, 9999) : '';

$exist = true;
if(file_exists(DISCUZ_ROOT.'uc_server/'.$avatar)) {
    if($check) {
        echo 1;
        exit;
    }
    $_G['BOAN_OSS']->uploadFile(DISCUZ_ROOT.'uc_server/'.$s_avatar, 'uc_server/'.$s_avatar,'public') && @unlink(DISCUZ_ROOT.'uc_server/'.$s_avatar);
    $_G['BOAN_OSS']->uploadFile(DISCUZ_ROOT.'uc_server/'.$m_avatar, 'uc_server/'.$m_avatar,'public') &&  @unlink(DISCUZ_ROOT.'uc_server/'.$m_avatar);
    $_G['BOAN_OSS']->uploadFile(DISCUZ_ROOT.'uc_server/'.$b_avatar, 'uc_server/'.$b_avatar,'public') && @unlink(DISCUZ_ROOT.'uc_server/'.$b_avatar);
}

$avatar_url = empty($random) ? 'uc_server/'.$avatar : 'uc_server/'.$avatar.'?random='.$random;

if($_G['BOAN_OSS']->isObject('uc_server/'.$avatar)){
    header('Location: '.UC_OSS_API.$avatar_url);
}else{
    $avatar_url = 'uc_server/images/noavatar_'.$size.'.gif';
    header('Location: '.UC_API.'/'.$avatar_url); 
    
}
exit;

function get_avatar($uid, $size = 'middle', $type = '') {
    $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
    $uid = abs(intval($uid));
    $uid = sprintf("%09d", $uid);
    $dir1 = substr($uid, 0, 3);
    $dir2 = substr($uid, 3, 2);
    $dir3 = substr($uid, 5, 2);
    $typeadd = $type == 'real' ? '_real' : '';
    return $dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).$typeadd."_avatar_$size.jpg";
}

?>