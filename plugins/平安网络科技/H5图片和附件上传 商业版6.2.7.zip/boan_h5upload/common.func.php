<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!function_exists('boan_get_cache')){
    function boan_get_cache($plugin_name,$force = false){
        global $_G;
        loadcache($plugin_name,$force);
        return $_G['cache'][$plugin_name];
    }
    
}


if(!function_exists('boan_set_cache')){
    function boan_set_cache($plugin_name,$data){
        global $_G;
        savecache($plugin_name, $data);
    }
}


if(!function_exists('boan_load_script')){
    function boan_load_script($js_file,$plugin_name) {
        $js_pre='<script type="text/javascript" src="source/plugin/'.$plugin_name.'/js/';
        $js_code='';
    
        $var=getglobal('boan/js_file/'.$js_file);
        if(!isset($var)){
            $js_code=$js_pre.$js_file.'?'.VERHASH.'" charset="utf-8"></script>';
            setglobal('boan/js_file/'.$js_file, 1); //
        }
        return $js_code;
    }
}



if(!function_exists('boan_load_jq')){
    function boan_load_jq($js_file,$plugin_name){
        $js_code='
         <script type="text/javascript">
           if (typeof jQuery != \'undefined\'){
              var boan_old_jq = jQuery;
           } 
         </script>';
        $js_pre='<script type="text/javascript" src="source/plugin/'.$plugin_name.'/js/';
        $var=getglobal('boan/jq_redim_var');
        if(!isset($var)){
            $js_code.=$js_pre.$js_file.'?'.VERHASH.'" charset="utf-8"></script>';
          $js_code.= '
          <script type="text/javascript">
             var boan_jq=$.noConflict();
             if (typeof  boan_old_jq != \'undefined\'){
               jQuery = boan_old_jq;
              }
         </script>';
            setglobal('boan/jq_redim_var',1);
        }
        return $js_code;
    }
}



if(!function_exists('boan_set_jq')){
    function boan_set_jq(){
        $js_code = '';
        $js_code .= '
         <script type="text/javascript">
           if (typeof boan_jq != \'undefined\'){
             boan_old_jq = jQuery; 
             jQuery = boan_jq;
           } 
         </script>';
        return $js_code;
    }
   
}


if(!function_exists('boan_reset_jq')){
    function boan_reset_jq(){
        $js_code = '';
        $js_code .= '
         <script type="text/javascript">
           if (typeof  boan_old_jq != \'undefined\'){
               jQuery = boan_old_jq;
           }
         </script>';
        return $js_code;
    }
}


if(!function_exists('boan_set_avatar')){
    function boan_set_avatar($value){
        global $_G;
        if(empty($_G['cache']['boan_avatar'])){
            loadcache('boan_avatar');
        }
        $uid = $value['param'][0];
        $size = isset($value['param'][1]) ? $value['param'][1] : '';
        $returnsrc = isset($value['param'][2]) ? $value['param'][2] : FALSE;
        $real = isset($value['param'][3]) ? $value['param'][3] : FALSE;
        $static = isset($value['param'][4]) ? $value['param'][4] : FALSE;
        $ucenterurl = isset($value['param'][5]) ? $value['param'][5] : FALSE;
        
        $avatar_url = '';
        $random = 0;
        $flag = $_GET['mod'] == 'space' && $_G['uid'] == $uid;
        if(empty($_G['cache']['boan_avatar_'.$uid])){
            loadcache('boan_avatar_'.$uid);
        }
        if($_G['cache']['boan_avatar_'.$uid] && time()< $_G['cache']['boan_avatar_'.$uid]['timeout'] && $_G['uid'] == $uid){
            $random = 1;
        }
        
        static $staticavatar;
        if($staticavatar === null) {
            $staticavatar = $_G['setting']['avatarmethod'];
        }
       
        $ucenterurl = empty($ucenterurl) ? $_G['setting']['ucenterurl'] : $ucenterurl;
        $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
        $uid = abs(intval($uid));
        
        if(!$staticavatar && !$static) {
            $arr = parse_url($_G['siteurl']);
            $siteurl = $arr['scheme'].'://'.$arr['host'].'/';  
            $avatar_url = $returnsrc ? $ucenterurl.'/avatar.php?uid='.$uid.'&size='.$size.($real ? '&type=real' : '').($random ? '&random=1' : '' ).($flag ? '&boan_h5avatar=yes' : '') : '<img src="'.$ucenterurl.'/avatar.php?uid='.$uid.'&size='.$size.($real ? '&type=real' : '').($random ? '&random=1' : '' ).($flag ? '&boan_h5avatar=yes' : '').'" />';
            if($_G['BOAN_OSSCONFIG'] && $_G['BOAN_OSSCONFIG']['oss_avatar']){
                $avatar_url = $returnsrc ? $_G['siteurl'].'plugin.php?id=boan_h5upload:avatar&uid='.$uid.'&size='.$size.($real ? '&type=real' : '').($random ? '&random=1' : '' ).($flag ? '&boan_h5avatar=yes' : '') : 
                '<img src="'.$_G['siteurl'].'plugin.php?id=boan_h5upload:avatar&uid='.$uid.'&size='.$size.($real ? '&type=real' : '').($random ? '&random=1' : '' ).($flag ? '&boan_h5avatar=yes' : '').'" onerror="this.onerror=null;this.src=\''.$ucenterurl.'/images/noavatar_'.$size.'.gif\'"/>';
            }
        } else {
            $uid = sprintf("%09d", $uid);
            $dir1 = substr($uid, 0, 3);
            $dir2 = substr($uid, 3, 2);
            $dir3 = substr($uid, 5, 2);
            $rand = rand(1,10000);
            $avatar = 'data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).($real ? '_real' : '').'_avatar_'.$size.'.jpg';
            if($_G['BOAN_OSSCONFIG'] && $_G['BOAN_OSSCONFIG']['oss_avatar'] && file_exists(DISCUZ_ROOT.'uc_server/'.$avatar)) {
                $s_avatar = 'data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).($real ? '_real' : '').'_avatar_'.'small'.'.jpg';
                $m_avatar = 'data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).($real ? '_real' : '').'_avatar_'.'middle'.'.jpg';
                $b_avatar = 'data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).($real ? '_real' : '').'_avatar_'.'big'.'.jpg';
                
                $_G['BOAN_OSS']->uploadFile(DISCUZ_ROOT.'uc_server/'.$s_avatar, 'uc_server/'.$s_avatar,'public') && @unlink(DISCUZ_ROOT.'uc_server/'.$s_avatar);
                $_G['BOAN_OSS']->uploadFile(DISCUZ_ROOT.'uc_server/'.$m_avatar, 'uc_server/'.$m_avatar,'public') && @unlink(DISCUZ_ROOT.'uc_server/'.$m_avatar);
                $_G['BOAN_OSS']->uploadFile(DISCUZ_ROOT.'uc_server/'.$b_avatar, 'uc_server/'.$b_avatar,'public') && @unlink(DISCUZ_ROOT.'uc_server/'.$b_avatar);
               
                $file = $_G['BOAN_OSSCONFIG']['oss_url'].'uc_server/'.$avatar .($random ? "?random=$rand" : '' );
            }else if($_G['BOAN_OSS'] && $_G['BOAN_OSSCONFIG']['oss_avatar']){
                $file = $_G['BOAN_OSSCONFIG']['oss_url'].'uc_server/'.$avatar .($random ? "?random=$rand" : '' );
            }else{
                $file = $ucenterurl.'/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).($real ? '_real' : '').'_avatar_'.$size.'.jpg'.($random ? "?random=$rand" : '' );
            }
            
            $avatar_url = $returnsrc ? $file : '<img src="'.$file.'" onerror="this.onerror=null;this.src=\''.$ucenterurl.'/images/noavatar_'.$size.'.gif\'" />';
        }
        return $avatar_url;
    }
}

