<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
define('P_NAME', 'plugin/boan_h5upload');

(file_exists(DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/loadoss.php') &&  require_once(DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/loadoss.php'))
|| (file_exists(DISCUZ_ROOT.'./source/plugin/boan_oss/loadoss.php') &&  require_once(DISCUZ_ROOT.'./source/plugin/boan_oss/loadoss.php'));

global $_G;
if($_GET['pmod'] == 'oss_data'){
    loadcache('boan_oss_dataconfig_cache',true);
    $ossdataconfig = $_G['cache']['boan_oss_dataconfig_cache'];
    if(empty($ossdataconfig)){
        $ossdataconfig['status'] = 0;
        $ossdataconfig['direction'] = 1;
    }
    if(!submitcheck('data_submit') &&  $ossdataconfig['status'] == 0){
        
        cpheader();
        $havetable = file_exists(DISCUZ_ROOT.'./source/plugin/boan_h5upload/table/table_boanh5_attachment.php');
        echo '<script type="text/javascript" src="'.STATICURL.'js/calendar.js"></script>';
        loadcache('boan_oss_data_cache');
        showtips(lang(P_NAME, 'oss_data_explain'),'tips',true,lang(P_NAME, 'oss_data_explain_title'));
      
        showformheader('plugins&operation=config&do='.$pluginid.'&pmod=oss_data');
        showtableheader('','','',9);
        showtagheader('tbody', '',true);
        
                    
        showsetting(lang(P_NAME, 'oss_data_authorize'), 'ossauthorize','','text',0,0,lang(P_NAME, 'oss_data_authorize_comment'));
        showsetting(lang(P_NAME, 'oss_data_osscalendar'), 'osscalendar','','calendar',0,0,lang(P_NAME, 'oss_data_osscalendar_comment'));
        
        showsetting(lang(P_NAME, 'oss_data_ext'), 'ossext','','text',0,0,lang(P_NAME, 'oss_data_ext_comment'));
        
        showsetting(lang(P_NAME, 'oss_data_del'), 'ossdel','','radio',0,0,lang(P_NAME, 'oss_data_del_comment'));
        showsetting(lang(P_NAME, 'oss_data_size'), 'osssize','10000','text',0,0,lang(P_NAME, 'oss_data_size_comment'));
        $forum_ct = '';
        $type_ct ='';
        $portal_ct = '';
        if($havetable){
            $forum_ct = '('.lang(P_NAME, 'oss_data_local_text').C::t('#boan_h5upload#boanh5_attachment')->get_total_filecount(0,'','',0);
            $forum_ct .= ','.lang(P_NAME, 'oss_data_remote_text').C::t('#boan_h5upload#boanh5_attachment')->get_total_filecount(1,'','',0).')';
            
            $type_ct = '('.lang(P_NAME, 'oss_data_local_text').C::t('#boan_h5upload#boanh5_forum_typeoptionvar')->count_by_value(0);
            $type_ct .= ','.lang(P_NAME, 'oss_data_remote_text').C::t('#boan_h5upload#boanh5_forum_typeoptionvar')->count_by_value(1).')';
            
            $portal_ct = '('.lang(P_NAME, 'oss_data_local_text').C::t('#boan_h5upload#boanh5_portal_attachment')->get_count_attachment(0);
            $portal_ct .= ','.lang(P_NAME, 'oss_data_remote_text').C::t('#boan_h5upload#boanh5_portal_attachment')->get_count_attachment(1).')';
            
            $album_ct = '('.lang(P_NAME, 'oss_data_local_text').C::t('#boan_h5upload#boanh5_home_pic')->total_by_remote(0);
            $album_ct .=  lang(P_NAME, 'oss_data_remote_text').C::t('#boan_h5upload#boanh5_home_pic')->total_by_remote(1).')';
            
        }
        
        showsetting(lang(P_NAME, 'oss_data_target_title'),
            array('osstarget',
                array(
                    array('1',lang(P_NAME, 'oss_data_target_forum').$forum_ct),
                    array('2',lang(P_NAME, 'oss_data_target_type').$type_ct),
                    array('3',lang(P_NAME, 'oss_data_target_portal').$portal_ct),
                    array('4',lang(P_NAME, 'oss_data_target_home').$album_ct),
                    array('7',lang(P_NAME, 'oss_data_target_avatar')),
                    array('5',lang(P_NAME, 'oss_data_target_type_restore')),
                    array('6',lang(P_NAME, 'oss_data_target_portal_restore')),
                 
                )),
            '1','select',0,0,lang(P_NAME, 'oss_data_target_comment')
            );
        
        showsetting(lang(P_NAME, 'oss_data_direction_title'),
            array('ossdirection',
                array(
                    array('1',lang(P_NAME, 'oss_data_direction_tooss')),
                    array('2',lang(P_NAME, 'oss_data_direction_tolocal')),
                )),
            '1','select',0,0,lang(P_NAME, 'oss_data_direction_comment')
            );
        
        showsetting(lang(P_NAME, 'oss_data_method_title'),
            array('ossmethod',
                array(
                    array('1',lang(P_NAME, 'oss_data_method_immediately')),
                    array('2',lang(P_NAME, 'oss_data_method_quiet')),
                )),
            '1','select',0,0,lang(P_NAME, 'oss_data_method_comment')
            );
        showtablefooter(); /*dism��taobao��com*/
     
        showsubmit('data_submit',lang(P_NAME,'oss_data_del_submit'));
        
        showformfooter();
    }elseif(submitcheck('data_submit')){
        if(!$_GET['ossauthorize']) {
            cpmsg(lang(P_NAME,'oss_data_msg1'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=oss_data', 'error');
        }elseif(empty($_G['BOAN_OSS'])){
            cpmsg(lang(P_NAME,'oss_data_msg2'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=oss_data', 'error');
        }else{
            if(empty($_G['BOAN_OSS']) || $_G['BOAN_OSS']->testOSS()){
                cpmsg(lang(P_NAME,'oss_data_msg3'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=oss_data', 'error');
            }else{
                //cpmsg(lang(P_NAME,'oss_data_msg6'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=oss_data', 'succeed');
                $ossdataconfig['status'] = 1;
                $ossdataconfig['startdate'] = time();
                $ossdataconfig['date'] = trim($_GET['osscalendar']);
                $ossdataconfig['ext'] = trim($_GET['ossext']);
                $ossdataconfig['isdel'] = $_GET['ossdel'];
                $ossdataconfig['size'] = trim($_GET['osssize']);
                $ossdataconfig['direction'] = $_GET['ossdirection'];
                $ossdataconfig['ossmethod'] = $_GET['ossmethod'];
                
                $ossdataconfig['target'] = $_GET['osstarget'];
                switch ($ossdataconfig['target']){
                    case 1:
                        $ossdataconfig['total'] = C::t('#boan_h5upload#boanh5_attachment')->get_total_filecount($ossdataconfig['direction']-1,$ossdataconfig['date'],$ossdataconfig['ext'],$ossdataconfig['size']);
                        $ossdataconfig['total'] += C::t('#boan_h5upload#boanh5_thread')->get_count_cover($ossdataconfig['direction']-1);
                        break;
                    case 2:
                        $ossdataconfig['total'] = C::t('#boan_h5upload#boanh5_forum_typeoptionvar')->count_by_value($ossdataconfig['direction']-1);
                        break;
                    case 3:
                        $ossdataconfig['total'] = C::t('#boan_h5upload#boanh5_portal_attachment')->get_count_attachment($ossdataconfig['direction']-1);
                        break;
                    case 4:
                        $ossdataconfig['total'] = C::t('#boan_h5upload#boanh5_home_pic')->total_by_remote($ossdataconfig['direction']-1);
                        $ossdataconfig['total'] += C::t('#boan_h5upload#boanh5_home_pic')->total_by_alubm_remote($ossdataconfig['direction']);
                        break;
                    case 5:
                        $ossdataconfig['total'] =  C::t('#boan_h5upload#boanh5_forum_typeoptionvar')->count_by_value(2);
                        break;
                    case 6:
                        $ossdataconfig['total'] =  C::t('#boan_h5upload#boanh5_portal_attachment')->get_count_article();
                        break;
                    case 7: 
                        $ossdataconfig['total'] =  -1;
                        break;
                }
              
                $ossdataconfig['completed_count'] = 0;
                $ossdataconfig['error_count'] = 0;
                $ossdataconfig['ok_count'] = 0;
                $ossdataconfig['current_file'] = 0;
                $ossdataconfig['last_date'] = time();
              
                
                $ossdataconfig['t_id'] = 0;
                $ossdataconfig['p'] = 0;
                $ossdataconfig['step'] = 0;
                
                savecache('boan_oss_dataconfig_cache',$ossdataconfig);
               
                header('X-Accel-Buffering: no');
                header('Content-type: text/html;charset='.CHARSET);
                echo str_repeat(' ',1024*4);
                cpmsg(lang(P_NAME,'oss_data_msg4'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=oss_data', 'succeed','','',FALSE);
                
                echo ob_get_clean();
                flush();
                
                if($ossdataconfig['ossmethod'] == '1'){
                    require_once   OSS_ROOT.'./source/admin/ossdata.inc.php';
                    ignore_abort('run_oss_data','end_oss_data','stop_oss_data',2,0);
                }else{
                    $cron_id = C::t('common_cron')->get_cronid_by_filename('boan_h5upload:cron_boanh5_ossdata.php');
                    $data = DB:: fetch_first('SELECT * FROM %t WHERE cronid=%s', array('common_cron',$cron_id));
                    $data['available'] = 1;
                    DB::update('common_cron', $data, $condition = "cronid=$cron_id"); 
                    discuz_cron::run($cron_id);
                }
            }
        }
    }elseif(submitcheck('data_end_submit')){
        $ossdataconfig['status'] = 0;
        savecache('boan_oss_dataconfig_cache',$ossdataconfig);
        $cron_id = C::t('common_cron')->get_cronid_by_filename('boan_h5upload:cron_boanh5_ossdata.php');
        $data = DB:: fetch_first('SELECT * FROM %t WHERE cronid=%s', array('common_cron',$cron_id));
        $data['available'] = 0;
        DB::update('common_cron', $data, $condition = "cronid=$cron_id"); 
        cpmsg(lang(P_NAME,'oss_data_msg5'), 'action=plugins&operation=config&do='.$pluginid.'&pmod=oss_data', 'error');
        
    }elseif($ossdataconfig['status'] >0){
        cpheader();
        showtips(lang(P_NAME, 'oss_move_explain'));
        showformheader('plugins&operation=config&do='.$pluginid.'&pmod=oss_data');
      
        $status = $ossdataconfig['status'];
        $direction = $ossdataconfig['direction'];
        $directiontxt = array(1=>lang(P_NAME, 'oss_data_direction_tooss'),2=>lang(P_NAME, 'oss_data_direction_tolocal'));
        $startdate = date('Y-m-d H:m:s',$ossdataconfig['startdate']);
        $date = !empty($ossdataconfig['date']) ? $ossdataconfig['date'] : lang(P_NAME, 'oss_move_nolimit');
        $arr_status = array('1' => lang(P_NAME, 'oss_move_moving'),'2' => lang(P_NAME, 'oss_move_moved'),'3' => lang(P_NAME, 'oss_move_err'),);
        $size = $ossdataconfig['size'] ? $ossdataconfig['size'].'KB' : lang(P_NAME, 'oss_move_nolimit');
        
        $total = $ossdataconfig['total'];
        $completed_count = $ossdataconfig['completed_count'];
        $error_count = $ossdataconfig['error_count'];
        $ok_count = $ossdataconfig['ok_count'];
        $current_file = $ossdataconfig['current_file']; 
        $last_data = date('Y-m-d H:m:s',$ossdataconfig['last_date']);
        $isdel = $ossdataconfig['isdel'] ? 'Yes' : 'No';
        $ossmethod = $ossdataconfig['ossmethod'] == '1' ?  lang(P_NAME, 'oss_data_method_immediately') : lang(P_NAME, 'oss_data_method_quiet');
        $percentage = 0;
        if($total >= 0 ){
            $percentage = (int)(($completed_count / $total)*100);
            $percentbar = $percentage > 15 ? $percentage : 15;
        }
       
        
        $oss_move_item =  lang(P_NAME,'oss_data_object_item');
        $oss_move_item = $oss_move_item[$ossdataconfig['target']];
        
        $htmltxt = lang(P_NAME,'oss_move_htmltext');
        echo <<<SCRIPT
              <style>
        		.infobox {
        			width: 50%;
        			border: 4px solid #8540e0;
        			line-height: 28px;
        			overflow: hidden;
                    padding: 0px;      
                    text-align: left;        
        		}
        
        		.infobox div {
        			padding: 0 10px
        		}
        
        		.fixsel .btn {
        			background: #8540e0;
        			color: #fff;
        			font-size: 16px;
        			padding: 10px 0;
        			border: 0;
        			width: 50.6%;
        			border-radius: 0;
        		}
        	</style>  
        <div class="infobox">
			<div id="precentbar" style="background: #886ce1;
			width: 15%;
			color: #fff;
			padding: 5px 0;
			margin: 0;"><span>{$htmltxt['11']}>>>$percentage%</span></div>
			<div style="margin:10px 0px;"><span>{$htmltxt['15']}{$oss_move_item}</span></div>
            <div style="margin:10px 0px;"><span>{$htmltxt['1']}{$directiontxt[$direction]}</span></div>
			<div style="margin:10px 0px;"><span>{$htmltxt['2']}$startdate</span></div>
            <div style="margin:10px 0px;"><span>{$htmltxt['3']}$date</span></div>
            <div style="margin:10px 0px;"><span>{$htmltxt['4']}$size</span></div>
            <div style="margin:10px 0px;"><span>{$htmltxt['5']}{$arr_status[$status]}</span></div>
			<div style="margin:10px 0px;"><span>{$htmltxt['6']}$ok_count</span></div>
			<div style="margin:10px 0px;"><span>{$htmltxt['7']}$error_count</span></div>
			<div style="margin:10px 0px;"><span>{$htmltxt['12']}$total</span></div>
            <div style="margin:10px 0px;"><span>{$htmltxt['13']}$isdel</span></div>
            <div style="margin:10px 0px;"><span>{$htmltxt['14']}$ossmethod</span></div>
			<div style="margin:10px 0px;"><span>{$htmltxt['8']}$current_file</span></div>
			<div style="margin:10px 0px;"><span>{$htmltxt['9']}$last_data</span></div>
		</div>
		<tr>
			<td colspan="15">
				<div class="fixsel"><input type="submit" class="btn" id="submit_data_end_submit" name="data_end_submit"
						title="" value="{$htmltxt['10']}" /></div>
			</td>
		</tr>
	<script
			type="text/JavaScript">_attachEvent(document.documentElement, 'keydown', function (e) { entersubmit(e, 'data_end_submit'); });
            var total = $total;
            if(total >= 0){
                $('precentbar').style.width = '$percentbar%';
            }else{
                $('precentbar').style.display = 'none';
            }          
            setInterval('location.reload();',5000); 
</script>
	</div>
SCRIPT;
        showformfooter();
    }
}




