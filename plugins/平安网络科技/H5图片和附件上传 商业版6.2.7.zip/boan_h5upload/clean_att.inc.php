<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
define('P_NAME', 'plugin/boan_h5upload');

(file_exists(DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/loadoss.php') &&  require_once(DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/loadoss.php'))
|| (file_exists(DISCUZ_ROOT.'./source/plugin/boan_oss/loadoss.php') &&  require_once(DISCUZ_ROOT.'./source/plugin/boan_oss/loadoss.php'));
global $_G;


if($_GET['pmod'] == 'clean_att'){
    
    loadcache('boan_oss_cleanatt_cache',true);
    $cache = $_G['cache']['boan_oss_cleanatt_cache'];
    if(!$_G['cache']['boan_oss_cleanatt_cache']){
        $cache = array(
            'allow' => '0',
            'interval' => '8',
            'limitatt' => '600',
            'limittemp' => '600',
            'lasttime' => '',
            'lastweektime' => '',
            'weekdayatt' => '0',
            'weekdaytemp' => '0',
            'weekdayatt_ct' => '',
            'weekdaytemp_ct' => '',
        );
    }
    
    if(!submitcheck('set_submit') && empty($_GET['filelist'])){
        cpheader();
        
        showtableheader(lang(P_NAME, 'cleanatt_week'), 'fixpadding');
        $cache['weekdayatt_ct'] = intval($cache['weekdayatt_ct']);
        $cache['weekdaytemp_ct'] = intval($cache['weekdaytemp_ct']);
        $cache['weekdayatt'] = sizecount($cache['weekdayatt']);
        $cache['weekdaytemp'] = sizecount($cache['weekdaytemp']);
        
        showtablerow('', array('', 'class="td21" style="text-align:right;"'),
            "<em class=\"fixed\">{$cache['weekdayatt_ct']}".lang(P_NAME, 'cleanatt_weekdayatt')."{$cache['weekdayatt']}</em> &nbsp <em class=\"fixed\">{$cache['weekdaytemp_ct']}".lang(P_NAME, 'cleanatt_weekdaytemp')."{$cache['weekdaytemp']}</em>"
            );
        
        
        $temp_att = DB::fetch_first('SELECT count(*) as ct,sum(filesize) as filesize FROM %t WHERE dateline<%i',array('forum_attachment_unused',time()-$cache['limitatt']*60));
        $temp_att['filesize'] = sizecount($temp_att['filesize']);
        showtablefooter(); /*dism��taobao��com*/
        
        $tempdir = scandir($_G['setting']['attachdir'].'/temp/');
        $temp_file['ct'] = 0;
        $temp_file['filesize'] = 0;
        foreach ($tempdir as $t){
            if($t != '.' && $t != '..' && !is_dir($_G['setting']['attachdir'].'/temp/'.$t) && (time()-$cache['limittemp']*60) > filemtime($_G['setting']['attachdir'].'/temp/'.$t)){
                $temp_file['ct']++;
                $temp_file['filesize'] += filesize($_G['setting']['attachdir'].'/temp/'.$t);
            }
        }
        $temp_file['filesize'] = sizecount($temp_file['filesize']);
        showtableheader(lang(P_NAME, 'cleanatt_no')."<a href=\"javascript:;\" onclick=\"ajaxget('plugin.php?id=boan_h5upload:ajax&cleanatt=yes', 'filecheck_div')\">".lang(P_NAME, 'cleanatt_run')."</a>", 'fixpadding');
        
        $url = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=boan_h5upload&pmod=clean_att&filelist=yes";
        showtablerow('', array('', 'class="td21" style="text-align:right;"'),
            "<div  id=\"filecheck_div\"><em class=\"edited\">{$temp_att['ct']}".lang(P_NAME, 'cleanatt_weekdayatt')."{$temp_att['filesize']}<a href=\"$url\">".lang(P_NAME, 'cleanatt_filelist')."</a></em> &nbsp <em class=\"edited\">{$temp_file['ct']}".lang(P_NAME, 'cleanatt_weekdaytemp')."{$temp_file['filesize']}</em></div>"
            );
        
        showtablefooter(); /*dism��taobao��com*/
        
        showformheader('plugins&operation=config&do='.$pluginid.'&pmod=clean_att');
        
        showtableheader(lang(P_NAME, 'cleanatt_set'),'','',9);
        
        showtagheader('tbody', '',true);
        showsetting(lang(P_NAME, 'cleanatt_allow'), 'allow', $cache['allow'],'radio',0,0,'');
        
        showsetting(lang(P_NAME, 'cleanatt_interval'), 'interval', $cache['interval'],'text',0,0,lang(P_NAME, 'cleanatt_interval_comment'));
        
        showsetting(lang(P_NAME, 'cleanatt_limitatt'), 'limitatt', $cache['limitatt'],'text',0,0,lang(P_NAME, 'cleanatt_limitatt_comment'));
        
        showsetting(lang(P_NAME, 'cleanatt_limittemp'), 'limittemp', $cache['limittemp'],'text',0,0,lang(P_NAME, 'cleanatt_limittemp_comment'));
        
        showtagfooter('tbody');
        
        showtablefooter(); /*dism��taobao��com*/
        
        showsubmit('set_submit');
        
        showformfooter();
    }elseif($_GET['filelist']){
        cpheader();
        
        $pagesize = 20 ;  
        $query = DB::query('SELECT count(*) FROM %t WHERE dateline<%i',array('forum_attachment_unused',time()-$cache['limitatt']*60));
        $amount = DB::result($query, 0); 
        $pagecount = $amount ? (($amount < $pagesize) ? 1 : (($amount % $pagesize) ? ((int)($amount / $pagesize) + 1) : ($amount / $pagesize))) : 0; 
        $page = !empty($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $page = $page > $pagecount ? 1 : $page;  
        $startlimit = ($page - 1) * $pagesize;
        
        
        showtableheader(lang(P_NAME,'cleanatt_nouse').'<a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=boan_h5upload&pmod=clean_att\">".lang(P_NAME,'cleanatt_back').'</a>','','',9);
        
        $status = array(lang(P_NAME,'cleanatt_local'),lang(P_NAME,'cleanatt_remote'));
        
        $subtitle=array(lang(P_NAME,'cleanatt_item0'),
            lang(P_NAME,'cleanatt_item1'),
            lang(P_NAME,'cleanatt_item2'),
            lang(P_NAME,'cleanatt_item3'),
            lang(P_NAME,'cleanatt_item4'),
            lang(P_NAME,'cleanatt_item5'),);
        showsubtitle($subtitle);
        
        $query = DB::query('SELECT * FROM %t WHERE dateline<%i ORDER BY dateline DESC LIMIT %i,%i',array('forum_attachment_unused',time()-$cache['limitatt']*60,$startlimit,$pagesize));  
        $multipage = multi($amount, $pagesize, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=boan_h5upload&pmod=clean_att&filelist=yes&get=string", $pagecount,20); 
        
        while($arr = DB::fetch($query)){
            $userinfo = getuserbyuid($arr['uid']);
            $row=array("<span style=\"color:green;\">".$userinfo['username']."</span>",
                "<span style=\"color:green;\">".$arr['filename']."</span>",
                "<span style=\"color:green;\">".$arr['attachment']."</span>",
                "<span style=\"color:green;\">".sizecount($arr['filesize'])."</span>",
                "<span style=\"color:green;\">".$status[$arr['remote']]."</span>",
                "<span style=\"color:green;\">".date("Y-m-d H:m:s",$arr['dateline'])."</span>",
            );
            showtablerow('','',$row);
        }
        $row = array("$multipage");
        showtablerow('','',$row);
        showtablefooter(); /*dism��taobao��com*/
        
    }else{
  
        $cache['allow'] = intval($_GET['allow']);
        $cache['interval'] = intval($_GET['interval']);
        $cache['limitatt'] = intval($_GET['limitatt']);
        $cache['limittemp'] = intval($_GET['limittemp']);
        savecache('boan_oss_cleanatt_cache',$cache);
        $cron_id = C::t('common_cron')->get_cronid_by_filename('boan_h5upload:cron_boanh5_cleanatt.php');
        if(empty($cron_id)){
            register_cron('boan_h5upload','cron_boanh5_cleanatt.php');
            $cron_id = C::t('common_cron')->get_cronid_by_filename('boan_h5upload:cron_boanh5_cleanatt.php');
        }
        
        $data = DB:: fetch_first('SELECT * FROM %t WHERE cronid=%s', array('common_cron',$cron_id));
        if($cache['allow']){
             $data['available'] = 1;
             DB::update('common_cron', $data, $condition = "cronid=$cron_id");
             discuz_cron::run($cron_id);
        }else{
            $data['available'] = 0;
            DB::update('common_cron', $data, $condition = "cronid=$cron_id");
        }
        
        cpmsg('plugins_edit_succeed', 'action=plugins&operation=config&do='.$pluginid.'&pmod=clean_att', 'succeed');
    }
}

function register_cron($pluginid,$filename){
    if(!ispluginkey($pluginid)) {
        return false;
    }
    
    $dir = DISCUZ_ROOT.'./source/plugin/'.$pluginid.'/cron';
    if(!file_exists($dir)) {
        return false;
    }
    
    $path = $dir.'/'.$filename;
    if(!file_exists($path)){
        return false;
    }
    
    $content = file_get_contents($path);
    preg_match("/cronname\:(.+?)\n/", $content, $r);$name = lang('plugin/'.$pluginid, trim($r[1]));
    preg_match("/week\:(.+?)\n/", $content, $r);$weekday = trim($r[1]) ? intval($r[1]) : -1;
    preg_match("/day\:(.+?)\n/", $content, $r);$day = trim($r[1]) ? intval($r[1]) : -1;
    preg_match("/hour\:(.+?)\n/", $content, $r);$hour = trim($r[1]) ? intval($r[1]) : -1;
    preg_match("/minute\:(.+?)\n/", $content, $r);$minute = trim($r[1]) ? trim($r[1]) : 0;
    $minutenew = explode(',', $minute);
    foreach($minutenew as $key => $val) {
        $minutenew[$key] = $val = intval($val);
        if($val < 0 || $var > 59) {
            unset($minutenew[$key]);
        }
    }
    $minutenew = array_slice(array_unique($minutenew), 0, 12);
    $minutenew = implode("\t", $minutenew);
    $filename = $pluginid.':'.$filename;
    
    $cronid = C::t('common_cron')->get_cronid_by_filename($filename);
    
    if($cronid){
        return false;
    }
    
    
    return C::t('common_cron')->insert(array(
        'available' => 0,
        'type' => 'plugin',
        'name' => $name,
        'filename' => $filename,
        'weekday' => $weekday,
        'day' => $day,
        'hour' => $hour,
        'minute' => $minutenew,
    ), true);
    
}


