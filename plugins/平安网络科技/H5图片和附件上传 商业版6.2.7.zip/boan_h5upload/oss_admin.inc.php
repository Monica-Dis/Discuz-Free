<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
define('P_NAME', 'plugin/boan_h5upload');
(file_exists(DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/loadoss.php') &&  require_once(DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/loadoss.php'))
|| (file_exists(DISCUZ_ROOT.'./source/plugin/boan_oss/loadoss.php') &&  require_once(DISCUZ_ROOT.'./source/plugin/boan_oss/loadoss.php'));
global $_G;
if($_GET['pmod'] == 'oss_admin'){
    if(!submitcheck('set_submit')){
        cpheader();
        loadcache('boan_oss_cache');
        $osscache = $_G['cache']['boan_oss_cache'];
        
        if(!$_G['cache']['boan_oss_cache']){
            $osscache = array(
              'oss_server' => '1',
              'oss_id' => '',
              'oss_key' => '',
              'oss_endpoint' => '',
              'oss_bucket' => '',
              'oss_bucket_url' => '',
              'oss_url' => '',
              'oss_basedir' => '',
              'oss_img' => 1,
              'oss_att' => 1,
              'img_hlong' => 1,
              'att_hlong' => 1,
              'oss_type' => 0,
              'oss_trade' => 0,
              'oss_avatar' => 0,
              'oss_thumb' => 0,
              'oss_water' => 0,
              'oss_ext' => 'mp3,mp4',
              'oss_style' => '',
              'oss_dubug' => 1,
              'oss_style_forums' => null,
              'oss_exclude_forums' => null,
              'oss_expires' =>3600,
              'oss_auto' => 0, 
              'oss_referer' => 1,
              'oss_suffix' => '',
            );
        }
        if(submitcheck('test_submit')){
            $osscache['oss_server'] = $_GET['ossserver'];
            $osscache['oss_id'] = trim($_GET['ossid']);
            $osscache['oss_key'] = trim($_GET['osskey']);
            $osscache['oss_endpoint'] = trim($_GET['ossendpoint']);
            $osscache['oss_bucket'] = trim($_GET['ossbucket']);
            $osscache['oss_bucket_url'] = trim($_GET['ossbucketurl']);
            $osscache['oss_url'] = trim($_GET['ossurl']);
                                
            if($_GET['ossserver'] == '1'){
                echo "<script>alert('".lang(P_NAME, 'oss_test_local')."');</script>";
            }elseif(!($_GET['ossid'] && $_GET['osskey'] && $_GET['ossendpoint'] && $_GET['ossbucket'] && $_GET['ossurl'] && $_GET['ossbucketurl'])){
                echo "<script>alert('".lang(P_NAME, 'oss_test_info')."');</script>";
            }else if(empty($_G['BOAN_OSS'])){
                echo "<script>alert('".lang(P_NAME, 'oss_test_notpay')."');</script>";
            }else{
            
                switch ($_G['BOAN_OSS']->testOSS()){
                    case 3:
                        echo "<script>alert('".lang(P_NAME, 'oss_test_notup')."');</script>";
                        break;
                    case 2:
                        echo "<script>alert('".lang(P_NAME, 'oss_test_notdown')."');</script>";
                        break;
                    case 1:
                        echo "<script>alert('".lang(P_NAME, 'oss_test_notaccess')."');</script>";
                        break;
                    default:
                        echo "<script>alert('".lang(P_NAME, 'oss_test_ok')."');</script>";
                }
                
            }
            
        }
        
        showtips(lang(P_NAME, 'oss_set_explain'));
        showformheader('plugins&operation=config&do='.$pluginid.'&pmod=oss_admin');
        showtableheader('','','',9);
        showtagheader('tbody', '',true);
        showsetting(lang(P_NAME, 'oss_server_name'),
            array('ossserver',
                array(
                    array('1',lang(P_NAME, 'oss_server_local')),
                    array('2',lang(P_NAME, 'oss_server_aliyun')),
                    array('3',lang(P_NAME, 'oss_server_qiniu')),
                    array('4',lang(P_NAME, 'oss_server_tencent')),
                    array('5',lang(P_NAME, 'oss_server_huawei')),
                )),
            $osscache['oss_server'],'select',0,0,lang(P_NAME, 'oss_server_comment')
            );
        showsetting('Access Key ID:', 'ossid',  $osscache['oss_id'],'text',0,0,lang(P_NAME, 'oss_ossid_comment'));
        showsetting('Access Key Secret:', 'osskey', $osscache['oss_key'],'text',0,0,lang(P_NAME, 'oss_osskey_comment'));
        showsetting('OSS Bucket:', 'ossbucket', $osscache['oss_bucket'],'text',0,0,lang(P_NAME, 'oss_bucket_comment'));
        showsetting('OSS EndPoint:', 'ossendpoint', $osscache['oss_endpoint'],'text',0,0,lang(P_NAME, 'oss_ossendpoint_comment'));
        showsetting(lang(P_NAME, 'oss_bucket_url_name'), 'ossbucketurl', $osscache['oss_bucket_url'],'text',0,0,lang(P_NAME, 'oss_bucket_url_comment'));
        showsetting(lang(P_NAME, 'oss_url_name'), 'ossurl', $osscache['oss_url'],'text',0,0,lang(P_NAME, 'oss_url_comment'));
        showsubmit('test_submit',lang(P_NAME, 'oss_test_btn'));
        
        showsetting(lang(P_NAME, 'oss_basedir_name'), 'ossbasedir', $osscache['oss_basedir'],'text',0,0,lang(P_NAME, 'oss_basedir_comment'));
        showsetting(lang(P_NAME, 'oss_suffix_name'), 'osssuffix', $osscache['oss_suffix'],'text',0,0,lang(P_NAME, 'oss_suffix_comment'));
        showsetting(lang(P_NAME, 'oss_debug_name'), 'ossdebug', $osscache['oss_debug'],'radio',0,0,lang(P_NAME, 'oss_debug_comment'));
        showsetting(lang(P_NAME, 'oss_auto_name'), 'ossauto', $osscache['oss_auto'],'radio',0,0,lang(P_NAME, 'oss_auto_comment'));
        showsetting(lang(P_NAME, 'oss_referer_name'), 'ossreferer', $osscache['oss_referer'],'radio',0,0,lang(P_NAME, 'oss_referer_comment'));
        
        
        showsetting(lang(P_NAME, 'oss_img_name'), 'ossimg', $osscache['oss_img'],'radio',0,0,lang(P_NAME, 'oss_img_comment'));
        showsetting(lang(P_NAME, 'oss_att_name'), 'ossatt', $osscache['oss_att'],'radio',0,0,lang(P_NAME, 'oss_att_comment'));
        showsetting(lang(P_NAME, 'oss_type_name'), 'osstype', $osscache['oss_type'],'radio',0,0,lang(P_NAME,'oss_type_comment'));
        showsetting(lang(P_NAME, 'oss_trade_name'), 'osstrade', $osscache['oss_trade'],'radio',0,0,lang(P_NAME,'oss_trade_comment'));
        showsetting(lang(P_NAME, 'oss_avatar_name'), 'ossavatar', $osscache['oss_avatar'],'radio',0,0,lang(P_NAME, 'oss_avatar_comment'));
        showsetting(lang(P_NAME, 'oss_imghlong_name'), 'imghlong', $osscache['img_hlong'],'radio',0,0,lang(P_NAME, 'oss_imghlong_comment'));
        showsetting(lang(P_NAME, 'oss_atthlong_name'), 'atthlong', $osscache['att_hlong'],'radio',0,0,lang(P_NAME, 'oss_imghlong_comment'));
        showsetting(lang(P_NAME, 'oss_thumb_name'), 'ossthumb', $osscache['oss_thumb'],'radio',0,0,lang(P_NAME, 'oss_thumb_comment'));
        showsetting(lang(P_NAME, 'oss_water_name'), 'osswater', $osscache['oss_water'],'radio',0,0,lang(P_NAME, 'oss_water_comment'));
        showsetting(lang(P_NAME, 'oss_ext_name'), 'ossext', $osscache['oss_ext'],'text',0,0,lang(P_NAME, 'oss_ext_comment'));
        showsetting(lang(P_NAME, 'oss_expires_name'), 'ossexpires', $osscache['oss_expires'],'text',0,0,lang(P_NAME, 'oss_expires_comment'));
        
        $var =  array('title'=>lang(P_NAME,'oss_exclude_forums'),
            'type' => 'forums',
            'description' => lang(P_NAME,'oss_exclude_forums_comment'),
            'variable' => 'ossexcludeforums',
            'value' => $osscache['oss_exclude_forums'],
            
        );
        show_forums($var);
        
        showsetting(lang(P_NAME, 'oss_style_name'), 'ossstyle', $osscache['oss_style'],'textarea',0,0,lang(P_NAME, 'oss_style_comment'));
        $var =  array('title'=>lang(P_NAME,'oss_style_forums'),
            'type' => 'forums',
            'description' => lang(P_NAME,'oss_style_forums_comment'),
            'variable' => 'ossstyleforums',
            'value' => $osscache['oss_style_forums'],
            
        );
        show_forums($var);
               
        showtagfooter('tbody');
        showtablefooter(); /*dism��taobao��com*/
        showsubmit('set_submit');
        showformfooter();
    }else{
        
        $osscache = array(
            'oss_server' => $_GET['ossserver'],
            'oss_id' => trim($_GET['ossid']),
            'oss_key' => trim($_GET['osskey']),
            'oss_endpoint' => trim($_GET['ossendpoint']),
            'oss_bucket' => trim($_GET['ossbucket']),
            'oss_url' => trim($_GET['ossurl']),
            'oss_bucket_url' => trim($_GET['ossbucketurl']),
            'oss_img' => $_GET['ossimg'],
            'oss_att' => $_GET['ossatt'],
            'img_hlong' => $_GET['imghlong'],
            'att_hlong' => $_GET['atthlong'],
            'oss_type' => $_GET['osstype'],
            'oss_trade' => $_GET['osstrade'],
            'oss_avatar' => $_GET['ossavatar'],
            'oss_ext' => $_GET['ossext'],
            'oss_style' => $_GET['ossstyle'],
            'oss_basedir' => $_GET['ossbasedir'],
            'oss_thumb' => $_GET['ossthumb'],
            'oss_water' => $_GET['osswater'],
            'oss_debug' =>  $_GET['ossdebug'],
            'oss_style_forums' => serialize($_GET['ossstyleforums']),
            'oss_exclude_forums' => serialize($_GET['ossexcludeforums']),
            'oss_expires' => $_GET['ossexpires'],
            'oss_auto' => $_GET['ossauto'],
            'oss_referer' => $_GET['ossreferer'],
            'oss_suffix' => $_GET['osssuffix'],
        );
        savecache('boan_oss_cache',$osscache);
        setting_auto(dintval($_GET['ossauto']));
      
        if($_G['BOAN_OSS'] && !$_G['BOAN_OSS']->testOSS()){
                $_G['BOAN_OSS']->setCors();
         }
       
        cpmsg('plugins_edit_succeed', 'action=plugins&operation=config&do='.$pluginid.'&pmod=oss_admin', 'succeed');
    }
}


function setting_auto($status){
    global $_G;
    loadcache('boan_oss_dataconfig_cache',true);
    $ossdataconfig = $_G['cache']['boan_oss_dataconfig_cache'];
    $ossdataconfig['status'] = $status;
    $ossdataconfig['direction'] = 1;
    $ossdataconfig['startdate'] = time();
    $ossdataconfig['date'] ='';
    $ossdataconfig['ext'] = 'png,jpg,jpeg,bmp,gif,PNG,JPG,JPEG,BMP,GIF';
    $ossdataconfig['isdel'] = 1;
    $ossdataconfig['size'] = 15000;
    $ossdataconfig['ossmethod'] = 2;
    $ossdataconfig['target'] = 8;
    
    $ossdataconfig['total'] =  -1;
    $ossdataconfig['completed_count'] = 0;
    $ossdataconfig['error_count'] = 0;
    $ossdataconfig['ok_count'] = 0;
    $ossdataconfig['current_file'] = 0;
    $ossdataconfig['last_date'] = time();
    
    $ossdataconfig['t_id'] = 0;
    $ossdataconfig['p'] = 0;
    $ossdataconfig['step'] = 0;
    savecache('boan_oss_dataconfig_cache',$ossdataconfig);
    if($status){
        $cron_id = C::t('common_cron')->get_cronid_by_filename('boan_h5upload:cron_boanh5_ossdata.php');
        $data = DB:: fetch_first('SELECT * FROM %t WHERE cronid=%s', array('common_cron',$cron_id));
        $data['available'] = 1;
        DB::update('common_cron', $data, $condition = "cronid=$cron_id");
    }
   
}

function show_forums($var){
    $var['description'] = ($var['description'] ? (isset($lang[$var['description']]) ? $lang[$var['description']] : $var['description'])."\n" : '').$lang['plugins_edit_vars_multiselect_comment']."\n".$var['comment'];
    $var['value'] = dunserialize($var['value']);
    $var['value'] = is_array($var['value']) ? $var['value'] : array();
    require_once libfile('function/forumlist');
    $var['type'] = '<select name="'.$var['variable'].'[]" size="10" multiple="multiple"><option value="">'.cplang('plugins_empty').'</option>'.forumselect(FALSE, 0, 0, TRUE).'</select>';
    foreach($var['value'] as $v) {
        $var['type'] = str_replace('<option value="'.$v.'">', '<option value="'.$v.'" selected>', $var['type']);
    }
    $var['variable'] = $var['value'] = '';
    showsetting(isset($lang[$var['title']]) ? $lang[$var['title']] : dhtmlspecialchars($var['title']), $var['variable'], $var['value'], $var['type'], '', 0, isset($lang[$var['description']]) ? $lang[$var['description']] : nl2br(dhtmlspecialchars($var['description'])), dhtmlspecialchars($var['extra']), '', true);
}



