<?php
define('UC_ROOT',DISCUZ_ROOT.'uc_server');
define('UC_DATADIR', UC_ROOT.'/data/');
define('UC_DATAURL', UC_API.'/data');
define('P_NAME', 'plugin/boan_h5upload');
class boan_avater{
    var $uid;
    var $vars;
    function __construct(){
        global $_G;
        $this->uid = intval($_G['uid']);
        if(empty($_G['cache']['plugin'])){
            loadcache('plugin');
        }
        $this->vars = $_G['cache']['plugin']['boan_h5upload'];
        if(!$this->uid){ //�ж��û��Ƿ��¼
            $this->output_err(-1);
        }
    }
    function get_home($uid) {
        $uid = sprintf("%09d", $uid);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        return $dir1.'/'.$dir2.'/'.$dir3;
    }
    function set_home($uid, $dir = '.') {
        $uid = sprintf("%09d", $uid);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        !is_dir($dir.'/'.$dir1) && mkdir($dir.'/'.$dir1, 0777);
        !is_dir($dir.'/'.$dir1.'/'.$dir2) && mkdir($dir.'/'.$dir1.'/'.$dir2, 0777);
        !is_dir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3) && mkdir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3, 0777);
    }
    
    function output_err($errnum){
        $err_info = lang(P_NAME, 'err_info');
        //err_info�����±�Ϊ���֣����������Ʋ��
        echo "<script>alert('$err_info[$errnum]');</script>";
        dexit();
    }
    function get_avatar($uid, $size = 'big', $type = '') {
        $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'big';
        $uid = abs(intval($uid));
        $uid = sprintf("%09d", $uid);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        $typeadd = $type == 'real' ? '_real' : '';
        return  $dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).$typeadd."_avatar_$size.jpg";
    }
    
    function onrectavatar() {
        $uid = $this->uid;
        $msg = '';
        if(!is_dir(UC_DATADIR)){
            $this->output_err(-2);
            return ;
        }
        $home = $this->get_home($uid);
        if(!is_dir(UC_DATADIR.'./avatar/'.$home)) {
            $this->set_home($uid, UC_DATADIR.'./avatar/');
        }
        $avatartype = $_GET['avatartype'] == 'real' ? 'real' : 'virtual';
        $bigavatarfile = UC_DATADIR.'./avatar/'.$this->get_avatar($uid, 'big', $avatartype);
        $middleavatarfile = UC_DATADIR.'./avatar/'.$this->get_avatar($uid, 'middle', $avatartype);
        $smallavatarfile = UC_DATADIR.'./avatar/'.$this->get_avatar($uid, 'small', $avatartype);
        $upload = new discuz_upload();
        if($upload->init($_FILES["file"]) &&  $upload->save() && $upload->get_image_info($upload->attach['target'])){
            if($upload->attach['size'] <= $this->vars['gif_size'] * 1024){
                @copy($upload->attach['target'],$bigavatarfile);
                @copy($upload->attach['target'],$middleavatarfile);
                @copy($upload->attach['target'],$smallavatarfile);
                @unlink($upload->attach['target']);
                
                $biginfo = @getimagesize($bigavatarfile);
                $middleinfo = @getimagesize($middleavatarfile);
                $smallinfo = @getimagesize($smallavatarfile);
                
                if(!$biginfo || !$middleinfo || !$smallinfo){
                    file_exists($bigavatarfile) && unlink($bigavatarfile);
                    file_exists($middleavatarfile) && unlink($middleavatarfile);
                    file_exists($smallavatarfile) && unlink($smallavatarfile);
                    $this->output_err(-3);
                }else{
                    echo "<script>window.parent.postMessage('success','*');</script>";
                }
                
            }else{
                $this->output_err(-4);
            }
           
        }else{
            $this->output_err(-5);
        }
      
    }
}
$avatar = new boan_avater();
$avatar->onrectavatar();


    
