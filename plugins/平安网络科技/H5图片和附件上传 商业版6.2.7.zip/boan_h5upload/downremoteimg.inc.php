<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global  $_G;
if(!$_G['group']['allowdownremoteimg']) {
    dexit();
}
if(empty($_G['cache']['plugin'])){
    loadcache('plugin');
}
$h5vars = $_G['cache']['plugin']['boan_h5upload'];
if(!defined('BOANH5_ROMOTEPIC')){
    $_GET['message'] = str_replace(array("\r", "\n"), array($_GET['wysiwyg'] ? '<br />' : '', "\\n"), $_GET['message']);
    $_GET['message'] = str_replace('\u','\\\\u',$_GET['message']);
}

preg_match_all("/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]|\[img=\d{1,4}[x|\,]\d{1,4}\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/is", $_GET['message'], $image1, PREG_SET_ORDER);
preg_match_all("/\<img.+src=('|\"|)?(.*)(\\1)([\s].*)?\>/ismUe", $_GET['message'], $image2, PREG_SET_ORDER);
$temp = $aids = $existentimg = array();
if(is_array($image1) && !empty($image1)) {
    foreach($image1 as $value) {
        $tempstr = trim(!empty($value[1]) ? $value[1] : $value[2]);
        $temp[] = array(
            '0' => $value[0],
            '1' => $tempstr
        );
        //writelog('h77', 'image1:'.$tempstr);
    }
}
if(is_array($image2) && !empty($image2)) {
    foreach($image2 as $value) {
        $tempstr = trim($value[2]);
        $temp[] = array(
            '0' => $value[0],
            '1' => $tempstr
        );
       //writelog('h77', 'image2:'.$value[0].'|'.trim($value[2]));
    }
}
require_once libfile('class/image');
if(is_array($temp) && !empty($temp)) {
    $upload = new discuz_upload();
    $attachaids = array();

    foreach($temp as $value) {
        $imageurl = $value[1];
        $hash = md5($imageurl);
        if(strlen($imageurl)) {
            $imagereplace['oldimageurl'][] = $value[0];
            if(!isset($existentimg[$hash])) {
                $existentimg[$hash] = $imageurl;
                $attach['ext'] = 'jpg';
                if(!$upload->is_image_ext($attach['ext'])) {
                    continue;
                }
                
                $patharr = explode('/', $imageurl);
                $path = trim($patharr[count($patharr)-1]);
                $path = explode('?', $path);
                $attach['name'] =  $path[0];
                $attach['thumb'] = '';
                $attach['isimage'] = $upload -> is_image_ext($attach['ext']);
                $attach['extension'] = $upload -> get_target_extension($attach['ext']);
                $attach['attachdir'] = $upload -> get_target_dir('forum');
                $attach['attachment'] = $attach['attachdir'] . $upload->get_target_filename('forum').'.'.$attach['extension'];
                $attach['target'] = getglobal('setting/attachdir').'./forum/'.$attach['attachment'];
                
                $content = '';
                $remote = 0;
                if(preg_match('/^(https?:\/\/|\.)/i', $imageurl) || preg_match('/\\.jpg|\\.png/i', $imageurl)) {
                    $object = OSS_BASEDIR.'forum/'.$attach['attachment'];
                    if($_G['BOAN_OSS'] && method_exists($_G['BOAN_OSS'],'getRemote') && $_G['BOAN_OSS']->getRemote($imageurl,$object)){
                        $data = $_G['BOAN_OSS']->getCallback($object);
                        if($data && $data['width']){
                            $width = $data['width'];
                            $upload->attach = $attach;
                            $upload->attach['size'] = $data['size'];
                            $remote = 1;
                            $content = 1;
                        }else{
                            $_G['BOAN_OSS']->deleteFile($object);
                        }
                    }else{
                        $content = dfsockopen($imageurl);
                        
                        $content || $content = file_get_contents($imageurl);
                        
                    }
                  
                } elseif(preg_match('/^('.preg_quote(getglobal('setting/attachurl'), '/').')/i', $imageurl)) {
                    $imagereplace['newimageurl'][] = $value[0];
                }
                if(empty($content)) {
                    $attachaids[$hash] = $imagereplace['newimageurl'][] = '';
                    continue;
                }
              
                if($content != 1){
                    if(!@$fp = fopen($attach['target'], 'wb')) {
                        $attachaids[$hash] = $imagereplace['newimageurl'][] = '';
                        continue;
                    } else {
                        flock($fp, 2);
                        fwrite($fp, $content);
                        fclose($fp);
                    }
                    if(!$upload->get_image_info($attach['target']) && $h5vars['check_pic_style']) {
                        $attachaids[$hash] = $imagereplace['newimageurl'][] = '';
                        @unlink($attach['target']);
                        continue;
                    }
                    $attach['size'] = filesize($attach['target']);
                    $upload->attach = $attach;
                    $thumb = $width = 0;
                    if($upload->attach['isimage']) {
                        if($_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight']) {
                            $image = new image();
                            $thumb = $image->Thumb($upload->attach['target'], '', $_G['setting']['sourcewidth'], $_G['setting']['sourceheight'], 1, 1) ? 1 : 0;
                            $width = $image->imginfo['width'];
                            $upload->attach['size'] = $image->imginfo['size'];
                        }
                        if($_G['setting']['thumbstatus']) {
                            $image = new image();
                            $thumb = $image->Thumb($upload->attach['target'], '', $_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
                            $width = $image->imginfo['width'];
                        }
                        if($_G['setting']['thumbsource'] || !$_G['setting']['thumbstatus']) {
                            list($width) = @getimagesize($upload->attach['target']);
                        }
                        if($_G['setting']['watermarkstatus'] && empty($_G['forum']['disablewatermark'])) {
                            $image = new image();
                            $image->Watermark($attach['target'], '', 'forum');
                            $upload->attach['size'] = $image->imginfo['size'];
                        }
                        $pic_width = dintval($h5vars['pic_width']);
                        $pic_height = dintval($h5vars['pic_height']);
                        $pic_quality = $h5vars['pic_quality'] ? $h5vars['pic_quality'] : 100;
                        
                        if($pic_height || $pic_width){
                            $image = new image();
                            $thumb = $image->Thumb($upload->attach['target'], '', 1024, 0, 1, 1) ? 1 : 0;
                            $width = $image->imginfo['width'];
                            $upload->attach['size'] = $image->imginfo['size'];
                            
                        }
                    }
                }
                if(defined('BOANH5_ROMOTEPIC')){
                    $aids[] = $aid = C::t('forum_attachment')->insert(
                        array(
                        'tableid'=>127,
                        'aid'=>0,
                        'tid'=>0,
                        'pid'=>0,
                        'uid'=>$_G['uid'],
                        'downloads'=>0),
                        true);
                    $_GET['attachnew'][$aid]=array();
                }else{
                    $aids[] = $aid = getattachnewaid();
                }
                
                $setarr = array(
                    'aid' => $aid,
                    'dateline' => $_G['timestamp'],
                    'filename' => $upload->attach['name'],
                    'filesize' => $upload->attach['size'],
                    'attachment' => $upload->attach['attachment'],
                    'isimage' => $upload->attach['isimage'],
                    'uid' => $_G['uid'],
                    'thumb' => $thumb,
                    'remote' => $remote,
                    'width' => $width
                );
                C::t("forum_attachment_unused")->insert($setarr);
                $attachaids[$hash] = $imagereplace['newimageurl'][] = '[attachimg]'.$aid.'[/attachimg]';

            } else {
                $imagereplace['newimageurl'][] = $attachaids[$hash];
            }
        }
    }
    if(!empty($aids)) {
        require_once libfile('function/post');
    }
    $_GET['message'] = str_replace($imagereplace['oldimageurl'], $imagereplace['newimageurl'], $_GET['message']);
    
}

if(!defined('BOANH5_ROMOTEPIC')){
    $_GET['message'] = addcslashes($_GET['message'], '/"\'');
    print <<<EOF
	<script type="text/javascript">
		parent.ATTACHORIMAGE = 1;
        parent.boanh5_qrcode_img.posttime = parent.boanh5_posttime+3;
        parent.boanh5_qrcode_img.timeflag = true;
        parent.updateDownImageList('$_GET[message]');  
	</script>
EOF;
    dexit();
  
}
