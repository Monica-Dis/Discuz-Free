<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
require_once(DISCUZ_ROOT.'./source/plugin/boan_attachview/oss/loadoss.lib.php');
define('P_ATTACHVIEW_NAME', 'plugin/boan_attachview');
global $_G;
if($_GET['pmod'] == 'oss_admin'){
    if(!submitcheck('set_submit')){
        cpheader();
        loadcache('boan_attachview_admin_cache');
        $osscache = $_G['cache']['boan_attachview_admin_cache'];
        
        if(!$_G['cache']['boan_attachview_admin_cache']){
            $osscache = array(
                'oss_server' => '1',
                'oss_id' => '',
                'oss_key' => '',
                'oss_endpoint' => '',
                'oss_bucket' => '',
                'oss_bucket_url' => '',
                'oss_url' => '',
                'oss_basedir' => '',
            );
        }
        if(submitcheck('test_submit')){
            $osscache['oss_server'] = $_GET['ossserver'];
            $osscache['oss_id'] = trim($_GET['ossid']);
            $osscache['oss_key'] = trim($_GET['osskey']);
            $osscache['oss_endpoint'] = trim($_GET['ossendpoint']);
            $osscache['oss_bucket'] = trim($_GET['ossbucket']);
            $osscache['oss_bucket_url'] = trim($_GET['ossbucketurl']);
            $osscache['oss_url'] = trim($_GET['ossurl']);
            
           if(!($_GET['ossid'] && $_GET['osskey'] && $_GET['ossendpoint'] && $_GET['ossbucket'] && $_GET['ossurl'] && $_GET['ossbucketurl'])){
                echo "<script>alert('".lang(P_ATTACHVIEW_NAME, 'oss_test_info')."');</script>";
            }else{
                $oss = boan_attachview_loadoss($osscache['oss_server'], $osscache);
                switch ( $oss->testOSS()){
                    case 4:
                        echo "<script>alert('".lang(P_ATTACHVIEW_NAME, 'oss_test_notup')."');</script>";
                        break;
                    case 3:
                        echo "<script>alert('".lang(P_ATTACHVIEW_NAME, 'oss_test_notdown')."');</script>";
                        break;
                    case 2:
                        echo "<script>alert('".lang(P_ATTACHVIEW_NAME, 'oss_test_notaccess')."');</script>";
                        break;
                    case 1:
                        echo "<script>alert('".lang(P_ATTACHVIEW_NAME, 'oss_test_notpreview')."');</script>";
                        break;
                    default:
                        echo "<script>alert('".lang(P_ATTACHVIEW_NAME, 'oss_test_ok')."');</script>";
                }
                
            }
            
        }
        
        showtips(lang(P_ATTACHVIEW_NAME, 'oss_set_explain'));
        showformheader('plugins&operation=config&do='.$pluginid.'&pmod=oss_admin');
        showtableheader('','','',9);
        showtagheader('tbody', '',true);
        showsetting(lang(P_ATTACHVIEW_NAME, 'oss_server_name'),
            array('ossserver',
                array(
                    //array('1',lang(P_ATTACHVIEW_NAME, 'oss_server_aliyun')),
                   // array('2',lang(P_ATTACHVIEW_NAME, 'oss_server_qiniu')),
                    array('3',lang(P_ATTACHVIEW_NAME, 'oss_server_tencent')),
                )),
            $osscache['oss_server'],'select',0,0,lang(P_ATTACHVIEW_NAME, 'oss_server_comment')
            );
        showsetting('Access Key ID:', 'ossid',  $osscache['oss_id'],'text',0,0,lang(P_ATTACHVIEW_NAME, 'oss_ossid_comment'));
        showsetting('Access Key Secret:', 'osskey', $osscache['oss_key'],'text',0,0,lang(P_ATTACHVIEW_NAME, 'oss_osskey_comment'));
        showsetting('OSS Bucket:', 'ossbucket', $osscache['oss_bucket'],'text',0,0,lang(P_ATTACHVIEW_NAME, 'oss_bucket_comment'));
        showsetting('OSS EndPoint:', 'ossendpoint', $osscache['oss_endpoint'],'text',0,0,lang(P_ATTACHVIEW_NAME, 'oss_ossendpoint_comment'));
        showsetting(lang(P_ATTACHVIEW_NAME, 'oss_bucket_url_name'), 'ossbucketurl', $osscache['oss_bucket_url'],'text',0,0,lang(P_ATTACHVIEW_NAME, 'oss_bucket_url_comment'));
        showsetting(lang(P_ATTACHVIEW_NAME, 'oss_url_name'), 'ossurl', $osscache['oss_url'],'text',0,0,lang(P_ATTACHVIEW_NAME, 'oss_url_comment'));
        showsubmit('test_submit',lang(P_ATTACHVIEW_NAME, 'oss_test_btn'));
        
        showsetting(lang(P_ATTACHVIEW_NAME, 'oss_basedir_name'), 'ossbasedir', $osscache['oss_basedir'],'text',0,0,lang(P_ATTACHVIEW_NAME, 'oss_basedir_comment'));
       
        
        showtagfooter('tbody');
        showtablefooter(); /*dism��taobao��com*/
        showsubmit('set_submit');
        showformfooter(); /*Dism_taobao-com*/
    }else{
        
        $osscache = array(
            'oss_server' => $_GET['ossserver'],
            'oss_id' => trim($_GET['ossid']),
            'oss_key' => trim($_GET['osskey']),
            'oss_endpoint' => trim($_GET['ossendpoint']),
            'oss_bucket' => trim($_GET['ossbucket']),
            'oss_url' => trim($_GET['ossurl']),
            'oss_bucket_url' => trim($_GET['ossbucketurl']),
            
        );
        savecache('boan_attachview_admin_cache',$osscache);
        $oss = boan_attachview_loadoss($osscache['oss_server'], $osscache);
        if($oss && !$oss->testOSS()){
            $oss->setCors();
        }
        
        cpmsg('plugins_edit_succeed', 'action=plugins&operation=config&do='.$pluginid.'&pmod=oss_admin', 'succeed');
    }
}