<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!class_exists('payment_plugin')) {
    include_once DISCUZ_ROOT . './source/plugin/payment/payment_plugin.class.php';
}

class boan_attachview_pay extends payment_plugin{
    public function __construct($order_id = '') {
        parent::__construct($order_id);
    }
    
    public function success() {
 
        $content = [
            $this->order['subject'],
            lang('plugin/payment', 'order_id') . ':' . $this->order['order_id'],
            lang('plugin/payment', 'amount') . ':' . payment::amount($this->order['amount']),
            lang('plugin/payment', 'method_id') . ':' . payment::method_title($this->order['method_id']),
            lang('plugin/payment', 'status') . ':' . payment::status_color($this->order['status']),
        ];
        csubase::system_notice($this->order['uid'], lang('plugin/payment', 'pay_success'), implode('<br>', $content));
        $params = $this->order['params'];
        
        $lockid = 'docpay_'.$params['uid'];
        
        if(!discuz_process::islocked($lockid)){
            updatemembercount($params['authorid'], array($params['extcredittype'] => $params['netprice']), 1, 'SAC', $params['aid']);
            updatemembercount($params['uid'], array($params['extcredittype'] => 1), 1, 'RCV', $params['aid']);
            updatemembercount($params['uid'], array($params['extcredittype'] => -1), 1, 'BAC', $params['aid']);
        }
        discuz_process::unlock($lockid);
        return true;
    }
    public function refund() {
        $content = [
            $this->order['subject'],
            lang('plugin/payment', 'out_refund_id') . ':' . $this->order['order_id'],
            lang('plugin/payment', 'refund_amount') . ':' . payment::amount($this->order['amount']),
            lang('plugin/payment', 'status') . ':' . payment::status_color($this->order['status']),
            lang('plugin/payment', 'plugin_status') . ':' . lang('plugin/payment', 'plugin_status_' . $this->order['plugin_status']),
        ];
        csubase::system_notice($this->order['uid'], lang('plugin/payment', 'refund_success'), implode('<br>', $content));
        return true;
    }
    
    public function expire() {
        C::t('#payment#payment_order')->delete($this->order['order_id']);
        return true;
    }
    
}