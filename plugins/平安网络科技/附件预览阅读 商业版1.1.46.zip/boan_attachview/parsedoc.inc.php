<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {

    exit('Access Denied');

}
class parseDoc{
    var $oss;
    var $vars;
    
    function __construct(){
        global $_G;
        if(empty($_G['cache']['plugin'])){
            loadcache('plugin');
        }
        
        $this->vars = $_G['cache']['plugin']['boan_attachview'];
        $this->vars['allow_ext'] = explode(',', $this->vars['previewext']);
        $temp = $this->vars['previewfourms'];
        $this->vars['forums'] = unserialize($temp);
        $temp =  $this->vars['previewgroups'];
        $this->vars['groups'] = unserialize($temp);
        
        require_once(DISCUZ_ROOT.'./source/plugin/boan_attachview/oss/loadoss.lib.php');
        
        loadcache('boan_attachview_admin_cache');
        $osscache = $_G['cache']['boan_attachview_admin_cache'];
        $this->oss =boan_attachview_loadoss($osscache['oss_server'], $osscache);
    }
    
    function getCache($name,$key = ''){
        global $_G;
        loadcache('boan_attview_'.$name);
        $viewcache = $_G['cache']['boan_attview_'.$name];
        if(count($viewcache) > 15000){
            $viewcache = '';
        }
        
        return !empty($viewcache) && !empty($key) ? $viewcache[$key] : $viewcache;
    }
    
    function setCache($name,$data,$key = ''){
        global $_G;
        loadcache('boan_attview_'.$name);
        $viewcache = $_G['cache']['boan_attview_'.$name];
        if(!empty($key)){
            $viewcache[$key] = $data;
        } else {
            $viewcache = $data;                
        }
        savecache('boan_attview_'.$name, $viewcache);
    }
    
    
   function countPages($object,$ext){
        global $_G;
        $viewcache = $this->getCache('obj',$object);
        
        if($viewcache['pages_count']){
            return dintval($viewcache['pages_count']);
        }
        
        $sign = $this->oss->signUrl($object);
        $rtn = 0;
        $img = $this->oss->check_file($sign."&ci-process=doc-preview&page=1&srcType=$ext");
        if($sign && $img){
            $arr = explode(PHP_EOL, $GLOBALS['filesockheader']);
            foreach ($arr as $v){
                if(strpos($v,'X-Total-Page') !== FALSE){
                    list(,$val) = explode(':', $v);
                    $val = dintval($val);
                    $viewcache['pages_count'] = $val;
                    $this->setCache('obj', $viewcache,$object);
                    return $val;
                }
            }
        }
        return $rtn;
    }
    
  function setthreadthumb($attach){
        
        global $_G;
        if(empty($_G['uid'])) {
            return false;
        }
        
        $tid = $attach['tid'];
        $ext = $attach['ext'];
        
        $object = 'forum/'.$attach['attachment'];
        $viewcache = $this->getCache('tid',$tid);
        if($viewcache['thumb']){
            
            return true;
        }
        $viewcache['thumb'] = 0;
        for($i = 1; $i <= 3;$i++){
            $pic = 'boanattpic/forum/'.$tid."/$i.jpg";
            
            if(!$this->oss->isObject($pic)){
                $sign = $this->oss->signUrl($object);
                $img = $this->oss->check_file($sign."&ci-process=doc-preview&page=$i&srcType=$ext");
                if(!$sign || !$img){
                    $this->setCache('tid', $viewcache,$tid);
                    return false;
                }
                $this->oss->uploadData($img, $pic,'public');
            }
            $viewcache['thumb']++;
        }
        $this->setCache('tid', $viewcache,$tid);
        
        return true;
        
    }
    
    function setthreadcover($attach) {
        
        global $_G;
        
        $cover = 0;
        $coverw = dintval($_G['setting']['forumpicstyle']['thumbwidth']);
        $coverh = dintval($_G['setting']['forumpicstyle']['thumbheight']);
        if(empty($_G['uid']) || !$coverw || !$coverh) {
            return false;
        }
        $tid = $attach['tid'];
        $ext = $attach['ext'];
        
        $object = 'forum/'.$attach['attachment'];
        $coverdir = 'threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/';
        
        $temp = basename($attach['attachment'],'.'.fileext($attach['attachment']));
        $coverpic = 'boanattpic/forum/'.$temp.'/cover.jpg';
        $viewcache = $this->getCache('tid',$tid);
        if($viewcache['cover']){
            return true;
        }
        if(!$this->oss->isObject($coverpic)){
            $sign = $this->oss->signUrl($object);
            $img = $this->oss->check_file($sign."&ci-process=doc-preview&page=1&srcType=$ext");
            if(!$sign || !$img){
                return false;
            }
            
            $basedir = !$_G['setting']['attachdir'] ? (DISCUZ_ROOT.'./data/attachment/') : $_G['setting']['attachdir'];
            dmkdir($basedir.'./forum/'.$coverdir);
            $coverfilename = $basedir.'forum/'.$coverdir.$tid.'.jpg';
            if(!file_put_contents($coverfilename ,$img)){
                return false;
            }
            
            $t1 = '.'.fileext($attach['attachment']);
            $imgattachment = str_replace($t1, '.jpg', $attach['attachment']);
            dmkdir(dirname($basedir.'./forum/'.$imgattachment));
            file_put_contents($basedir.'./forum/'.$imgattachment ,$img);
            $cover = 1;
            $remote = '';
            
            if(getglobal('setting/ftp/on')) {
                if(ftpcmd('upload', 'forum/'.$coverdir.$tid.'.jpg')) {
                    $remote = '-';
                }
                
                if(ftpcmd('upload', 'forum/'.$imgattachment)) {
                    @unlink($basedir.'./forum/'.$imgattachment);
                }
            }
            
            $cover = $remote.$cover;
            $this->oss->uploadFile($coverfilename,$coverpic,'public');
            $remote == '-' &&  @unlink($coverfilename);
            if($cover) {
                C::t('forum_thread')->update($tid, array('cover' => $cover));
                C::t('forum_threadimage')->delete_by_tid($tid);
                C::t('forum_threadimage')->insert(array(
                    'tid' => $tid,
                    'attachment' => $imgattachment,
                    'remote' => $attach['remote'],
                    
                ));
                
                $viewcache['cover'] = 1;
                $this->setCache('tid', $viewcache,$tid);
                return true;
            }
            
        }else{
            $viewcache['cover'] = 1;
            $this->setCache('tid', $viewcache,$tid);
        }
        return true;
    }
    
    function get_portal_attach($attachid){
        $attach = array();
        $attachid = dintval($attachid, true);
        if(!empty($attachid)){
            $attach =  DB::fetch_first('SELECT * FROM %t WHERE '.DB::field('attachid', $attachid), array('portal_attachment'));
            if(!empty($attach)){
                $attach['ext'] = fileext($attach['filename']);
                $attach['url'] = 'portal.php?mod=attachment&id='.$attachid;
            }
        }
        return $attach;
    }
    
    function parse_portal_att($attach){
        global $_G;
        $ext = $attach['ext'];
        if(!in_array($ext, $this->vars['allow_ext'])){
            return false;
        }
        $islimit =  $this->vars['previewsize'] * 1000000 < $attach['filesize'] ? 1 : 0;
        
        $object = 'portal/'.$attach['attachment'];
        if(!$this->oss->isObject($object) && file_exists($_G['setting']['attachdir'].'portal/'.$attach['attachment']) && !$islimit){
            
            if(!$this->oss->uploadFile($_G['setting']['attachdir'].'portal/'.$attach['attachment'],$object)){
                return false;
            }
            
        }elseif(!$this->oss->isObject($object) && $attach['remote'] && !$islimit){
            $ftp = new discuz_ftp();
            $tmpfilename =$_G['setting']['attachdir'].'temp/'.random(16).'.'.$ext;
            $ftp->ftp_get($tmpfilename,$object,FILE_BINARY);
            if(!$this->oss->uploadFile($tmpfilename,$object)){
                @unlink($tmpfilename);
                return false;
            }
            @unlink($tmpfilename);
        }
        if($this->oss->isObject('portal/'.$attach['attachment']) && ($attach['count_pages'] = $this->countPages($object,$ext))){
            
            $sign = $this->oss->signUrl($object);
            $id = random(6);
            if($_G['uid']){
                $count_view = $attach['count_pages'];
            }else{
                $count_view = $this->vars['previewcount'] > $attach['count_pages'] ? $attach['count_pages'] : $this->vars['previewcount'];
            }
            
            $pages = array();
            for($i = 0; $i < $count_view; $i++){
                $pages[$i] = ($i+1);
            }
            
            $arr_ext = array('doc'  => 'word',
                'docx' => 'word',
                'ppt'  => 'ppt',
                'pptx' => 'ppt',
                'txt'  => 'txt',
                'pdf'  => 'pdf',
                
            );
            
            $sext = array_key_exists($ext, $arr_ext) ? $arr_ext[$ext] : 'why';
            
            $aid = $attach['attachid'];
            
            $picwidth = $this->vars['portal_readerW'];
            $hidetitle = $this->vars['hidetitle'];
            $readtype = $this->vars['portal_readtype'];
            $copyright = $this->vars['copyright'];
         
            $replacedown = $this->vars['replacedown'];
            $alt = !empty($attach['description']) ? $attach['description'] : $attach['filename'];
            $return = '';
            include template('boan_attachview:portal_reader');
            $return = str_replace(array(PHP_EOL,"\r","\t","  "), array("","","",""), $return);
            return $return;
        }
        return false;
    }
    
    
    function parse_forum_att($attach,$template = 'reader'){ 
        global $_G;
        $ext = $attach['ext'];
        
        if(!in_array($ext, $this->vars['allow_ext'])){
            return false;
        }
      
        $islimit =  $this->vars['previewsize'] * 1000000 < $attach['filesize'] ? 1 : 0;
        $object = 'forum/'.$attach['attachment'];
     
        if(!$this->oss->isObject($object) && file_exists($_G['setting']['attachdir'].'forum/'.$attach['attachment']) && !$islimit){
            if(!$this->oss->uploadFile($_G['setting']['attachdir'].'forum/'.$attach['attachment'],$object)){
                return false;
            }
            
        }elseif(!$this->oss->isObject($object) && $attach['remote'] && !$islimit){
            $ftp = new discuz_ftp();
            $tmpfilename =$_G['setting']['attachdir'].'temp/'.random(16).'.'.$ext;
            $ftp->ftp_get($tmpfilename,$object,FILE_BINARY);
            if(!$this->oss->uploadFile($tmpfilename,$object)){
                @unlink($tmpfilename);
                return false;
            }
            
            @unlink($tmpfilename);
        }
       
       
            
        if($this->oss->isObject('forum/'.$attach['attachment']) && ($attach['count_pages'] = $this->countPages($object,$ext))){
            
            $this->setthreadcover($attach);
            $this->setthreadthumb($attach);
            $sign = $this->oss->signUrl($object);
            $id = random(6);
            if($this->vars['previewcount'] == 0 || ($_G['uid'] == $_G['adminid'] && $_G['uid'] > 0) || $_G['uid'] == $attach['uid'] || $attach['payed']){
                $count_view = $attach['count_pages'];
            }else{
                $count_view = $this->vars['previewcount'] > $attach['count_pages'] ? $attach['count_pages'] : $this->vars['previewcount'];
            }
            
            loadcache('boan_attachview_realization',true);
            $rcache = $_G['cache']['boan_attachview_realization'];
            
            $pages = array();
            
            for($i = 0; $i < $count_view; $i++){
                $pages[$i] = ($i+1);
            }
            
            $arr_ext = array('doc'  => 'word',
                'docx' => 'word',
                'ppt'  => 'ppt',
                'pptx' => 'ppt',
                'txt'  => 'txt',
                'pdf'  => 'pdf',
            );
            
            $sext = array_key_exists($ext, $arr_ext) ? $arr_ext[$ext] : 'why';
            $pid = $attach['pid'];
            $aid = $attach['aid'];
            $tid = $attach['tid'];
            $copyright = $this->vars['copyright'];
            $ad =  $this->vars['ad'];

            loadcache('boan_attachview_realization',true);
            $rcache = $_G['cache']['boan_attachview_realization'];
            
            $alipay = $rcache['alipay'];
            $wechat = $rcache['wechat'];
           
            
            $credits = $_G['setting']['extcredits'][$rcache['extcredittype']];
            $feedpay = $rcache['ok'] && ($attach['count_pages'] > $count_view && $attach['price']);
            $rcache['rate'] <= 0 && $rcache['rate'] = 10; 
            $amount = 0;
            $feedpay && $amount = $attach['price'] / $rcache['rate']; 
            $_G['feedpay'] = $feedpay;
            $picwidth = $this->vars['readerW'];
            $hidetitle = $this->vars['hidetitle'];
            $readtype = $this->vars['readtype'];
            $replacedown = $this->vars['replacedown'];
            $alt = !empty($attach['description']) ? $attach['description'] : $attach['filename'];
            $return = '';
            include template("boan_attachview:$template");
            $return = str_replace(array(PHP_EOL,"\r","\t","  "), array("","","",""), $return);
            return $return;
        }
            
        return false;
    }
    
    
    function getthreadcover($tid){
        $url = array();
        $viewcache = $this->getCache('tid',$tid);
        $l = empty($viewcache['thumb']) ? 3 : $viewcache['thumb'];
        for($i = 1; $i <= $l; $i++){
            $pic = 'boanattpic/forum/'.$tid."/$i.jpg";
            if(!empty($viewcache['thumb']) || $this->oss->isObject($pic)){
                $url[] = $this->oss->oss_info['oss_url'].$pic;
            }
        }
        return $url;
        
    }
    
    function getBucketUrl(){
        return $this->oss->oss_info['bucket_url'];
    }
    
    function deleteDoc($attach){
        $object = 'forum/'.$attach['attachment'];
        $this->oss->deleteFile($object);
        
    }
    
}