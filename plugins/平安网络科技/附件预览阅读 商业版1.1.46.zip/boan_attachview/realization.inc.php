<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

define('BOAN_ATTACHVIEW_NAME', 'plugin/boan_attachview');

global $_G;

if(empty($_G['cache']['plugin'])){
    loadcache('plugin');
}
$vars = $_G['cache']['plugin']['boan_attachview'];
if(!submitcheck('realization_submit')){
    
    loadcache('boan_attachview_realization',true);
    $rcache = $_G['cache']['boan_attachview_realization'];
    
    if(!$_G['cache']['boan_attachview_realization']){
        $rcache = array(
            'ok' => 0,
            'extcredittype' => 1,
            'inpoururl' => '',
            'rate' => 10,
            'alipay' => 0,
            'wechat' => 0,
            'preferential' => '',
        );
    }
    
    cpheader();
    if (DB::fetch_first('SELECT * FROM information_schema.tables WHERE table_name=%s', [DB::table('payment_api')])) {
        if(empty(C::t('#payment#payment_api')->fetch('boan_attachview_pay'))) {
            C::t('#payment#payment_api')->insert([
                'api_id' => 'boan_attachview_pay',
                'identifier' => 'boan_attachview',
                'filename' => 'source/plugin/boan_attachview/payment.class.php',
                'description' => lang(BOAN_ATTACHVIEW_NAME, 'install_payment'),
                'method_list' => '',
                'method_rule' => '0',
            ]);
        }
    }
    showtips(lang(BOAN_ATTACHVIEW_NAME, 'realization_explain'));
    $paytips = '';
    if (DB::fetch_first('SELECT * FROM information_schema.tables WHERE table_name=%s', [DB::table('payment_method')])) {
        if(!empty($temp = C::t('#payment#payment_method')->fetch('alipay')) && $temp['available']){ 
            $rcache['alipay'] = 1;
            $paytips .= lang(BOAN_ATTACHVIEW_NAME,'realization_alipay_ok');
        }else{
            $rcache['alipay'] = 0;
            $paytips .= lang(BOAN_ATTACHVIEW_NAME,'realization_alipay_no');
        }
        
        if(!empty($temp = C::t('#payment#payment_method')->fetch('wpay')) && $temp['available']){
            $rcache['wechat'] = 1;
            $paytips .= lang(BOAN_ATTACHVIEW_NAME,'realization_wechat_ok');
        }else{
            $rcache['wechat'] = 0;
            $paytips .= lang(BOAN_ATTACHVIEW_NAME,'realization_wechat_no');
        }
    }else{
        $paytips .= lang(BOAN_ATTACHVIEW_NAME,'realization_payment_no');
    }
    
    savecache('boan_attachview_realization',$rcache);
    showtips($paytips, 'paytips',  TRUE, $title =  lang(BOAN_ATTACHVIEW_NAME,'realization_paytips_title'));
    
    showformheader('plugins&operation=config&do='.$pluginid.'&pmod=realization');
    
    showtableheader('','','',9);
    showtagheader('tbody', '',true);

    showsetting(lang(BOAN_ATTACHVIEW_NAME,'realization_ok'), 'ok',$rcache['ok'],'radio',0,0,lang(BOAN_ATTACHVIEW_NAME, 'realization_ok_comment'));
    showsetting(lang(BOAN_ATTACHVIEW_NAME, 'realization_rate'), 'rate',  $rcache['rate'],'number',0,0,lang(BOAN_ATTACHVIEW_NAME, 'realization_rate_comment'));
    $arr = array();
    
    foreach($_G['setting']['extcredits'] as $id => $credit) {
        $arr[]=array($id,$credit['title']);
    }
    
    showsetting(lang(BOAN_ATTACHVIEW_NAME, 'realization_extcredittype'),
        array('extcredittype',
            $arr),
        $rcache['extcredittype'],'select',0,0,lang(BOAN_ATTACHVIEW_NAME, 'realization_extcredittype_comment')
        );
    showsetting(lang(BOAN_ATTACHVIEW_NAME, 'realization_inpoururl'), 'inpoururl',  $rcache['inpoururl'],'text',0,0,lang(BOAN_ATTACHVIEW_NAME, 'realization_inpoururl_comment'));
    showsetting(lang(BOAN_ATTACHVIEW_NAME, 'realization_preferential'), 'preferential',  $rcache['preferential'],'textarea',0,0,lang(BOAN_ATTACHVIEW_NAME, 'realization_preferential_comment'));
    showtagfooter('tbody');
    showtablefooter(); /*dism��taobao��com*/
    
    showsubmit('realization_submit');
    showformfooter(); /*Dism_taobao-com*/
}else{
    loadcache('boan_attachview_realization',true);
    $rcache = $_G['cache']['boan_attachview_realization'];
  
    $rcache = array(
        'ok' => intval($_GET['ok']),
        'extcredittype' => intval($_GET['extcredittype']),
        'inpoururl' => $_GET['inpoururl'],
        'rate' => intval($_GET['rate']),
        'preferential' => $_GET['preferential'],
    );
    $rcache['rate'] <= 0 && $rcache['rate'] = 10;
    savecache('boan_attachview_realization',$rcache);
    
    cpmsg('plugins_edit_succeed', 'action=plugins&operation=config&do='.$pluginid.'&pmod=realization', 'succeed');
   
   
}

