<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
define('P_ATTACHVIEW_NAME', 'plugin/boan_attachview');
require_once   DISCUZ_ROOT.'./source/plugin/boan_attachview/common.func.php';


global $_G;
if(empty($_G['cache']['plugin'])){
    loadcache('plugin');
}
$vars = $_G['cache']['plugin']['boan_attachview'];
$info = array(
    'code' => '201',
    'msg' => lang(P_ATTACHVIEW_NAME, '201'),
);
require_once(DISCUZ_ROOT.'./source/plugin/boan_attachview/oss/loadoss.lib.php');
loadcache('boan_attachview_admin_cache');
$osscache = $_G['cache']['boan_attachview_admin_cache'];
$oss =boan_attachview_loadoss($osscache['oss_server'], $osscache);

if($_GET['op'] == 'getpageurl'){
    require_once libfile('function/post');
    $uid  = $_G['uid'];
    $_G['tid']  = dintval($_GET['tid']);
    $pid  = dintval($_GET['pid']);
    $aid  = dintval($_GET['aid']);
    $page = dintval($_GET['page']);
   
    if($aid && $page && $pid){
        $attachs = getattach($pid,0,$aid);
        $attachs = $attachs['attachs']['used'];
        
        foreach ($attachs as $v){
            if($v['aid'] == $aid){
                $attach = $v;
                break;
            }
        }
        unset($attachs);
        $info = array(
            'code' => '202',
            'msg' => lang(P_ATTACHVIEW_NAME, '202'),
        );
        if(isset($attach)){
            $key = 'forum/'.$attach['attachment'];
            $ext = $attach['ext'];
            $sign = $oss->signUrl($key,'',5);
            $watermask = $vars['watermask'];
            $url = $sign.'&ci-process=doc-preview&page='.$page.'&srcType='.$ext;
            !empty($watermask) && ($url .= '&ImageParams='.$watermask);
            $info = array(
                'code' => '203',
                'msg' => lang(P_ATTACHVIEW_NAME, '203'),
            );
            if(!empty($sign)){
                $info = array(
                    'code' => '204',
                    'msg' => lang(P_ATTACHVIEW_NAME, '204'),
                );
                if(($page <= $vars['previewcount'] || empty($vars['previewcount'])) || (($uid == $_G['adminid'] && $_G['uid'] > 0) || $uid == $attach['uid'])){
                    $info = array(
                        'code' => '200',
                        'msg' => $url,
                    );
                }else{
                    $temp = C::t('common_credit_log')->fetch_all_by_uid_operation_relatedid($uid, 'BAC', array($aid));
                    if(count($temp) > 0 && $uid){
                        $info = array(
                            'code' => '200',
                            'msg' => $url,
                        );
                    }
                }
            }
        }
    }
}elseif($_GET['op'] == 'getpolicy'){
    require_once libfile('function/post');
    $aid = dintval($_GET['aid']);
    $swfhash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
    if($_GET['hash'] == $swfhash && !empty($aid)){
        $attachs = getattach(0,0,$aid);
        $attachs = $attachs['attachs']['unused'];
        $attach = array();
        foreach ($attachs as $v){
            if($v['aid'] == $aid){
                $attach = $v;
                break;
            }
        }
        unset($attachs);
        $info = array(
            'code' => '202',
            'msg' => lang(P_ATTACHVIEW_NAME, '202'),
        );
       
        if(!empty($attach)){
            $dir = 'forum/'.dirname($attach['attachment']).'/';
           
            $object = basename($attach['attachment']);
            echo $oss->getPolicy($dir, $object);
            dexit();
        }
    }
}elseif($_GET['op'] == 'getportalpageurl'){
    $uid  = $_G['uid'];
    $aid  = dintval($_GET['aid']);
    $page = dintval($_GET['page']);
    if($aid){
        $attach =  DB::fetch_first('SELECT * FROM %t WHERE '.DB::field('attachid', $aid), array('portal_attachment'));
        $info = array(
            'code' => '202',
            'msg' => lang(P_ATTACHVIEW_NAME, '202'),
        );
        
       if(!empty($attach)){
           $key = 'portal/'.$attach['attachment'];
           $ext = fileext($attach['filename']);
           $sign = $oss->signUrl($key,'',5);
           
           $url = $sign.'&ci-process=doc-preview&page='.$page.'&srcType='.$ext;
           $info = array(
               'code' => '203',
               'msg' => lang(P_ATTACHVIEW_NAME, '203'),
           );
           if(!empty($sign)){
               $info = array(
                   'code' => '204',
                   'msg' => lang(P_ATTACHVIEW_NAME, '204'),
               );
               
               if(($page <= $vars['previewcount'] || empty($vars['previewcount'])) ||  $_G['uid'] > 0){
                   $info = array(
                       'code' => '200',
                       'msg' => $url,
                   );
               }
           }
       }
    }
}elseif($_GET['op'] == 'onekey'){
    
    $aid = dintval($_GET['aid']);
    $uid = $_G['uid'];
    if($aid && $uid){
        $member = getuserbyuid($uid);
        
        require_once(DISCUZ_ROOT.'./source/plugin/boan_attachview/parsedoc.inc.php');
        require_once(DISCUZ_ROOT.'./source/plugin/boan_attachview/boan_post.inc.php');
        
        require_once libfile('function/post');
        require_once libfile('function/forum');
        loadcache('boan_attachview_onkey',true);
        
        $parse = new parseDoc();
        
        $attcache = $_G['cache']['boan_attachview_onkey'];
        $fid = dunserialize($attcache['att_forum']);
        $fid = $fid[0];
        $info = array(
            'code' => '301',
            'msg' => lang(P_ATTACHVIEW_NAME, '301'),
        );
        
        if($member['adminid']){
            $info = array(
                'code' => '302',
                'msg' => lang(P_ATTACHVIEW_NAME, '302'),
            );
            $_G['fid'] = $fid;
            $attachs = getattach(0,0,$aid);
            $attachs = $attachs['attachs']['unused'];
            $attach = $attachs[0];
            if(count($attach) > 0 ){
                $p = new boan_post();
                $info = array(
                    'code' => '303',
                    'msg' => lang(P_ATTACHVIEW_NAME, '303'),
                );
                if($attcache['att_repeat']){
                    $arr = array();
                    for($i = 0;$i < 10;$i++) {
                        $arr =  DB::fetch_first("SELECT * FROM %t WHERE filename=%s AND filesize=%d ",array('forum_attachment_'.$i,$attach['filenametitle'],$attach['filesize']));
                        
                        if(isset($arr['aid'])){
                            break;
                        }
                    }
                   
                    if(isset($arr['aid'])){
                        C::t('forum_attachment_unused')->delete($aid);
                        C::t('forum_attachment')->delete_by_id('aid',$attach['aid']);
                        dunlink($attach);
                        $parse->deleteDoc($attach);
                      
                        echo json_encode(array('code'=>304,'msg' => lang(P_ATTACHVIEW_NAME, '304')));
                        dexit();
                        
                    }
                }
             
            
                $tags = $attcache['att_tags'];
                $typeid = $attcache['att_typeid'];
                $sortid = $attcache['att_sortid'];
                $optiondata = $attcache['att_typeoption'];
                
                $message = $attcache['att_top'].PHP_EOL.
                '[attach]'.$attach['aid'].'[/attach]'
                .PHP_EOL.$attcache['att_bottom'];
                
                $ext = fileext($attach['filenametitle']);
                $subject = str_replace('.'.$ext, '', $attach['filenametitle']);
                
                $uids = explode(',', $attcache['userlist']);
                if(isset($uids[0]) && $uids[0]){
                    $t1 = rand(0,count($uids)-1);
                    $uid = $uids[$t1];
                }
                $params = array(
                    'fid' => $fid,
                    'uid' => $uid,
                    'subject' => $subject,
                    'message' => censor($message),
                    'tags' => $tags,
                    'typeid' => $typeid,
                    'sortid' => $sortid,
                    
                );
                $aids = $aid ? explode('|', $aid) : array();
               
                $p->newthread($params,$aids,$optiondata);
                
                if($p->tid && $p->pid){
                    $attach['tid'] = $p->tid;
                    $attach['pid'] = $p->pid;
                    $parse->setthreadcover($attach);
                    $parse->setthreadthumb($attach);
                    $url = $parse->getthreadcover($p->tid);
                    $price = dintval($attcache['att_price']);
                    
                    loadcache('groupreadaccess');
                    $readperm = 0;                    
                    foreach ($_G['cache']['groupreadaccess'] as $v){
                        if($v['groupid'] == $attcache['att_readaccess']){
                            $readperm = $v['readaccess'];
                            break;
                        }
                    }
                    $attach['readperm'] = $readperm;
                    C::t('forum_attachment_n')->update('tid:'.$p->tid,$attach['aid'],array('price'=>$price,'readperm'=>$readperm));
                    $info = array(
                        'code' => '200',
                        'msg' => $url[0],
                    );
                }
            }
        }
    }
}elseif($_GET['op'] == 'getattread'){
    require_once libfile('function/post');
    $uid  = $_G['uid'];
    $aid  = dintval($_GET['aid']);
    
    $attach = C::t('forum_attachment_n')->fetch('aid:'.$aid,$aid);
    $attach['ext'] = fileext($attach['filename']);
    $attach['filenametitle'] = $attach['filename'];
    if(empty($attach)){
        showmessage(lang(BOAN_ATTACHVIEW_NAME, 'ajax_nothing'));
    }
    
  
    require_once(DISCUZ_ROOT.'./source/plugin/boan_attachview/parsedoc.inc.php');
    
    $parse = new parseDoc();
    
    if($_GET['ajax']){
        include template('common/header_ajax');
        $result = "<link href=\"./source/plugin/boan_attachview/reader/css/reader.css?{$_G['formhash']}\" rel=\"stylesheet\" type=\"text/css\" />";
        $result .= "<script src=\"source/plugin/boan_attachview/reader/js/ajax_reader.js?{$_G['formhash']}\" charset=\"utf-8\" type=\"text/javascript\"></script>";
        $str = $parse->parse_forum_att($attach,'ajax_reader');
        if(empty($str)){
            showmessage(lang(BOAN_ATTACHVIEW_NAME, 'ajax_parseerr'));
        }
        $result .= $str;
        echo $result;
        include template('common/footer_ajax');
    }elseif(defined('IN_MOBILE')){
        include template('common/header');
         $str = $parse->parse_forum_att($attach,'reader');
         if(empty($str)){
             showmessage(lang(BOAN_ATTACHVIEW_NAME, 'ajax_parseerr'));
         }
        $result = "<link href=\"./source/plugin/boan_attachview/reader/touch/css/reader.css?{$_G['formhash']}\" rel=\"stylesheet\" type=\"text/css\" />";
        $result .= "<script src=\"source/plugin/boan_attachview/reader/touch/js/reader.js?{$_G['formhash']}\" charset=\"utf-8\" type=\"text/javascript\"></script>";
        $result = $str.$result;
        echo $result;
        
        include template('common/footer');
    }else{
        include template('common/header_common');
        $result = "<link href=\"./source/plugin/boan_attachview/reader/css/reader.css?{$_G['formhash']}\" rel=\"stylesheet\" type=\"text/css\" />";
        $result .= "<script src=\"source/plugin/boan_attachview/reader/js/reader.js?{$_G['formhash']}\" charset=\"utf-8\" type=\"text/javascript\"></script>";
        $result .= boan_load_jq('jquery-1.11.0.min.js','boan_attachview');
        $str = $parse->parse_forum_att($attach,'reader');
        if(empty($str)){
            showmessage(lang(BOAN_ATTACHVIEW_NAME, 'ajax_parseerr'));
        }
        $result .= $str;
        echo $result;
    }
   
   
    dexit();
    
}

echo json_encode($info);



