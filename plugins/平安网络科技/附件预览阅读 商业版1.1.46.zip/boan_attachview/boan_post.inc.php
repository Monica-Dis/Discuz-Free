<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class boan_post{
    var $forum = null;
    var $param = [];
    var $tid;
    var $pid;
    
    public function __construct($fid = null){
        require_once libfile('class/credit');
        
        require_once libfile('function/post');
        
        include_once libfile('function/forum');
        
        if($fid) {
            loadforum($fid);
            $this->forum = C::app()->var['forum'];
        }
    }
    
    private function call_func($func){
        
        $class = $func['class'];
        $method = $func['method'];
        $param_arr = $func['para'];
        if(!empty($class) && !empty($method)){
            call_user_func_array(array($class,$method),$param_arr);
        }elseif(!empty($method)){
            call_user_func_array($method, $param_arr);
        }
    }
    
    
    
    
    public function newthread($para,$aids = array(),$optiondata = array(),$before = array(),$after = array()){
        global $_G;
        $this->tid = $this->pid = 0;
        $this->_init_parameters($para);
        $member = getuserbyuid($this->param['uid']);
        $author = !$this->param['isanonymous'] ? $member['username'] : '';
        
        if(trim($this->param['subject']) == '') {
            return false;
        }
        
        if(!$this->param['sortid'] && !$this->param['special'] && trim($this->param['message']) == '') {
            return false;
        }
        
        
        if(!empty($this->forum) || $this->forum['fid'] != $this->param['fid']){
            loadforum($this->param['fid']);
            $this->forum = C::app()->var['forum'];
        }
        
        $this->call_func($before);
        
        $newthread = array(
            'fid' => $this->param['fid'],
            'posttableid' => 0,
            'readperm' => $this->param['readperm'],
            'price' => $this->param['price'],
            'typeid' => $this->param['typeid'],
            'sortid' => $this->param['sortid'],
            'author' => $author,
            'authorid' => $member['uid'],
            'subject' => $this->param['subject'],
            'dateline' => $this->param['dateline'],
            'lastpost' => $this->param['lastpost'],
            'lastposter' => $author,
            'displayorder' => $this->param['displayorder'],
            'digest' => $this->param['digest'],
            'special' => $this->param['special'],
            'attachment' => $this->param['attachment'],
            'moderated' => $this->param['moderated'],
            'status' => $this->param['status'],
            'isgroup' => $this->param['isgroup'],
            'replycredit' => $this->param['replycredit'],
            'closed' => $this->param['closed'] ? 1 : 0
        );
        $this->tid = C::t('forum_thread')->insert($newthread, true);
        
        if(!$this->tid){
            return false;
        }
        
        $class_tag = new tag();
        
        $this->param['tagstr'] = $class_tag->add_tag($this->param['tags'], $this->tid, 'tid');
        
        $this->pid = insertpost(array(
            'fid' => $this->param['fid'],
            'tid' => $this->tid,
            'first' => '1',
            'author' => $member['username'],
            'authorid' => $member['uid'],
            'subject' => $this->param['subject'],
            'dateline' => $this->param['dateline'],
            'message' => $this->param['message'],
            'useip' => $this->param['useip'] ? $this->param['useip'] : getglobal('clientip'),
            'port' => $this->param['port'] ? $this->param['port'] : getglobal('remoteport'),
            'invisible' => $this->param['pinvisible'],
            'anonymous' => $this->param['isanonymous'],
            'usesig' => $this->param['usesig'],
            'htmlon' => $this->param['htmlon'],
            'bbcodeoff' => $this->param['bbcodeoff'],
            'smileyoff' => $this->param['smileyoff'],
            'parseurloff' => $this->param['parseurloff'],
            'attachment' => '0',
            'tags' => $this->param['tagstr'],
            'replycredit' => 0,
            'status' => $this->param['pstatus']
        ));
        
        if(!$this->pid){
            return false;
        }
        $attachment = 0;
        foreach ($aids as $aid){
            $attach = C::t('forum_attachment_n')->fetch(127,$aid);
            if(count($attach) > 0 ){
                $attach['tid'] = $this->tid;
                $attach['pid'] = $this->pid;
                $tableid = substr($this->tid, -1,1);
                C::t('forum_attachment_n')->insert($tableid,$attach,false, true);
                C::t('forum_attachment_unused')->delete($aid);
                C::t('forum_attachment')->update($aid, array('tid' => $this->tid, 'pid' => $this->pid, 'tableid' =>$tableid));
                
                $attach['isimsage'] && $attachment = 2;
                $attachment == 0 && $attachment = 1;
            }
        }
        if($attachment){
            C::t('forum_thread')->update($this->tid,array('attachment' => $attachment));
            C::t('forum_post')->update(0,$this->pid,array('attachment' => $attachment));
        }
        
        $sortid = array_key_exists($this->param['sortid'],$_G['forum']['threadsorts']['types']) ? $this->param['sortid'] : 0;
        
        if($sortid > 0 && count($optiondata)){
            require_once libfile('post/threadsorts', 'include');
            $tid = $this->tid;
            $fid = $this->param['fid'];
            $field = '';
            $value = '';
            foreach ($_G['forum_optionlist'] as $optionid => $option){
                $v = isset($optiondata[$option['identifier']]) ? $optiondata[$option['identifier']] : '';
                $field .= empty($field) ? $option['identifier'] : ','.$option['identifier'];
                if(is_array($v)){
                    $v = implode("\t", $v);
                }
                $v = DB::quote($v);
                $value .= empty($value) ? $v : ','.$v;
                DB::query("INSERT INTO %t (sortid,tid,fid,optionid,expiration,value)VALUES($sortid,$tid,$fid,$optionid,0,$v)",array('forum_typeoptionvar'));
            }
            if($field){
                DB::query("INSERT INTO %t{$sortid} ($field,tid,fid,dateline,expiration)VALUES($value,'$tid','$fid',0,0)",array('forum_optionvalue'));;
            }
        }
        
        
        $subject = str_replace("\t", ' ', $this->param['subject']);
        $lastpost = "$this->tid\t".$subject."\t".TIMESTAMP."\t$author";
        C::t('forum_forum')->update($this->forum['fid'], array('lastpost' => $lastpost));
        C::t('forum_forum')->update_forum_counter($this->forum['fid'], 1, 1, 1);
        if($this->forum['type'] == 'sub') {
            C::t('forum_forum')->update($this->forum['fup'], array('lastpost' => $lastpost));
        }
        
        
        $this->call_func($after);
        
        return true;
    }
    
    protected function _init_parameters($param){
        $varname = array(
            'fid' => 0,
            'uid' => 0,
            'posttableid' => 0,
            'readperm' => 0,
            'price' => 0,
            'typeid' => 0,
            'sortid' => 0,
            'subject' => '',
            'dateline' => time(),
            'lastpost' => time(),
            'lastposter' => '',
            'displayorder' => 0,
            'digest' => 0,
            'special' => 0,
            'attachment' => 0,
            'moderated' => 0,
            'status' => 32,
            'isgroup' =>0,
            'replycredit' => 0,
            'closed' => 0,
            //post
            'message' => '',
            'useip' => '',
            'port' => '',
            'invisible' => 0,
            'anonymous' => 0,
            'usesig' => 0,
            'htmlon' => 0,
            'bbcodeoff' => 0,
            'smileyoff' => -1,
            'parseurloff' => 0,
            'attachment' => '0',
            'tags' => '',
            'replycredit' => 0,
            'pstatus' => 0,
        );
        $this->param = $varname;
        
        foreach($varname as $key => $val) {
            if(isset($param[$key])){
                $this->param[$key] = $param[$key];
            }
        }
    }
}