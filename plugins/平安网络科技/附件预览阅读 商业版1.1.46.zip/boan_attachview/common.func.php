<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!function_exists('boan_get_cache')){
    function boan_get_cache($plugin_name,$force = false){
        global $_G;
        loadcache($plugin_name,$force);
        return $_G['cache'][$plugin_name];
    }
    
}


if(!function_exists('boan_set_cache')){
    function boan_set_cache($plugin_name,$data){
        global $_G;
        savecache($plugin_name, $data);
    }
}


if(!function_exists('boan_load_script')){
    function boan_load_script($js_file,$plugin_name) {
        $js_pre='<script type="text/javascript" src="source/plugin/'.$plugin_name.'/js/';
        $js_code='';
    
        $var=getglobal('boan/js_file/'.$js_file);
        if(!isset($var)){
            $js_code=$js_pre.$js_file.'?'.VERHASH.'" charset="utf-8"></script>';
            setglobal('boan/js_file/'.$js_file, 1); //
        }
        return $js_code;
    }
}



if(!function_exists('boan_load_jq')){
    function boan_load_jq($js_file,$plugin_name){
        $js_code='
         <script type="text/javascript">
           if (typeof jQuery != \'undefined\'){
              var boan_old_jq = jQuery;
           } 
         </script>';
        $js_pre='<script type="text/javascript" src="source/plugin/'.$plugin_name.'/js/';
        $var=getglobal('boan/jq_redim_var');
        if(!isset($var)){
            $js_code.=$js_pre.$js_file.'?'.VERHASH.'" charset="utf-8"></script>';
          $js_code.= '
          <script type="text/javascript">
            try{
             var boan_jq=$.noConflict();
             if (typeof  boan_old_jq != \'undefined\'){
               jQuery = boan_old_jq;
              }
            }catch(e){} 
            
         </script>';
            setglobal('boan/jq_redim_var',1);
        }
        return $js_code;
    }
}



if(!function_exists('boan_set_jq')){
    function boan_set_jq(){
        $js_code = '';
        $js_code .= '
         <script type="text/javascript">
           if (typeof boan_jq != \'undefined\'){
             boan_old_jq = jQuery; 
             jQuery = boan_jq;
           } 
         </script>';
        return $js_code;
    }
   
}


if(!function_exists('boan_reset_jq')){
    function boan_reset_jq(){
        $js_code = '';
        $js_code .= '
         <script type="text/javascript">
           if (typeof  boan_old_jq != \'undefined\'){
               jQuery = boan_old_jq;
           }
         </script>';
        return $js_code;
    }
}




