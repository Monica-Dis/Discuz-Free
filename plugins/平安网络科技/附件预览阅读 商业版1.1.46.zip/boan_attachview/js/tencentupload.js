

function boan_attachview_admin_upload(File,aid){
	var upload_url = boan_jq('#hlongurl').val();
	
	this.getsignature = function(){
			var obj = null;
			var url = 'plugin.php?id=boan_attachview:ajax&op=getpolicy&aid=' + aid;
			
			var hash = boan_jq('#hash').val();
			
			
		
			url += '&hash='+ hash ;
			boan_jq.ajax({
						type:"GET",
						url:url,
						async:false,
						success:function(data){
							if(isUndefined(data.code)){
						 	  obj = data;
						    }
						},
						error:function(xhr,status,error){
							alert(error);
						},
			});
			return obj;
		}
	

	var obj = this.getsignature();
    if(obj){
		var uploader = WebUploader.create({
				server:upload_url,
				fileVal:'file',
			});
		
		uploader.on('fileQueued',function(file){
			
			this.upload(file);
			
		});
		
		uploader.on('error', function(err_num){
			alert(err_num);
		});
		uploader.on( 'uploadBeforeSend', function( object, data,headers ) {
		   // 修改data可以控制发送哪些携带数据。
		   delete data.lastModifiedDate;
		   delete data.name;
  
		   var credentials = obj.credentials;
		   var Authorization = CosAuth({
						SecretId: credentials.tmpSecretId,
						SecretKey: credentials.tmpSecretKey,
						Method: 'POST',
						Pathname: '/',
					});
					
			data = boan_jq.extend(data,{
				'key' : obj.dir+obj.object,
				'x-cos-security-token' : credentials.sessionToken || '',
				'Signature' : Authorization,
			});	
			
		});
		
		uploader.on('uploadProgress',function(file,percentage){
			try {
				var boan_li = boan_jq('#'+file.id);
				boan_percent = boan_li.find('.progress span');
				boan_percent.css( 'width', percentage * 100 + '%' );
				
			} catch (ex) {
				
			}
		});
		
		uploader.on( 'uploadSuccess', function( file,response) {
			var boan_li = boan_jq('#'+file.id);
			
			boan_li.find('.imgWrap').text('正在发贴...');
			
			var url = 'plugin.php?id=boan_attachview:ajax&op=onekey&aid=' + aid;
				boan_jq.ajax({
						type:"GET",
						url:url,
						
						success:function(data){
							data = eval ("(" + data + ")");
							if(data.code == 200){
								boan_li.find('.imgWrap').text('');
								boan_li.find('.imgWrap').append('<img src="' + data.msg + '"/>');
								boan_li.append( '<span class="success"></span>' );
							}else{
								boan_li.find('.imgWrap').text(data.msg);
							}
						},
						error:function(xhr,status,error){
							alert(error);
							
						},
				});
			
			
			
		});
		
		uploader.on( 'uploadError', function( file,reason ) {
			var boan_li = boan_jq('#'+file.id);
			boan_li.find('.imgWrap').text('直传腾讯云失败,出错原因:' + reason);
		});
		
		uploader.on( 'uploadComplete', function( file ) {
			var boan_li = boan_jq('#'+file.id);
			
			boan_percent = boan_li.find('.progress span');
			boan_percent.css( 'display','none' )
		});
		
		
		uploader.on('uploadStart',function(file){
		
			var boan_li = boan_jq('#'+file.id);
			boan_li.find('.imgWrap').text('正在直传腾讯云...');
			boan_percent = boan_li.find('.progress span');
			boan_percent.css( 'display','block' );
	    });
		
        uploader.addFiles(File);
	}
	
	
}



function boan_attachview_upload(File,aid){
	var upload_url = boan_attachview_hlongurl;
	
	this.get_signature = function(){
			var obj = null;
			var url = 'plugin.php?id=boan_attachview:ajax&op=getpolicy&aid=' + aid;
			
			var hash = '';
			if(typeof imgUpload !== 'undefined'){
				hash = imgUpload.settings['post_params']['hash'];
			}else{
				hash = upload.settings['post_params']['hash'];
			}
			url += '&hash='+ hash ;
			boan_jq.ajax({
						type:"GET",
						url:url,
						async:false,
						success:function(data){
							if(isUndefined(data.code)){
						 	  obj = data;
						    }
						},
						error:function(xhr,status,error){
							alert(error);
						},
			});
			return obj;
		}
	if(!in_array(File.ext,boan_attachview_allow)){
		return 0;
	}

	var obj = this.get_signature();
    if(obj){
		var Uploader = WebUploader.create({
				server:upload_url,
				fileVal:'file',
			});
		
		Uploader.on('fileQueued',function(file){
			
			this.upload(file);
			
		});
		
		Uploader.on('error', function(err_num){
			alert(err_num);
		});
		Uploader.on( 'uploadBeforeSend', function( object, data,headers ) {
		   // 修改data可以控制发送哪些携带数据。
		   delete data.lastModifiedDate;
		   delete data.name;
  
		   var credentials = obj.credentials;
		   var Authorization = CosAuth({
						SecretId: credentials.tmpSecretId,
						SecretKey: credentials.tmpSecretKey,
						Method: 'POST',
						Pathname: '/',
					});
					
			data = boan_jq.extend(data,{
				'key' : obj.dir+obj.object,
				'x-cos-security-token' : credentials.sessionToken || '',
				'Signature' : Authorization,
			});	
			
		});
		
		Uploader.on('uploadProgress',function(file,percentage){
			try {
				var p = parseInt(percentage * 100);
				
					
				var boan_li = boan_jq('#'+file.id);
				if(boan_li.length > 0){
					boan_percent = boan_li.find('.progress span');
					if(boan_percent.length>0){
						boan_percent.css( 'width', percentage * 100 + '%' );
						return ;
					}
				}
				
				
				if(!$('boan_attachview_' + aid)){
					boan_jq('#attach_' + aid + ' tr').append('<td title="正在直传至腾讯云以便预览" id=boan_attachview_' + aid + ' style="text-align: center;background-color: lightblue;color: green;font-weight: bold;cursor: pointer;}">0%</td>');
				}
				boan_jq('#boan_attachview_' + aid).text(p + '%');
				
			} catch (ex) {
				
			}
		});
		
		Uploader.on( 'uploadSuccess', function( file,response) {
			
			
		});
		
		Uploader.on( 'uploadComplete', function( file ) {
			boan_jq('#boan_attachview_' + aid).remove();
		});
		
	    
        Uploader.addFiles(File);
	}
	
}





