<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once   DISCUZ_ROOT.'./source/plugin/boan_attachview/common.func.php';
define('BOAN_ATTACHVIEW_NAME', 'plugin/boan_attachview');

class plugin_boan_attachview {
    var $vars;
    var $attachs;         
    var $parse;
    var $pid;
    function __construct(){
        global $_G;
        if(empty($_G['cache']['plugin'])){
            loadcache('plugin');
        }
        $this->vars = $_G['cache']['plugin']['boan_attachview'];
        $this->vars['allow_ext'] = explode(',', $this->vars['previewext']);
        
        $temp = $this->vars['previewfourms'];
        $this->vars['forums'] = unserialize($temp);
        $temp =  $this->vars['previewgroups'];
        $this->vars['groups'] = unserialize($temp);
        $this->vars['thumbcount'] =  $this->vars['thumbcount'] > 3 ? 3 : $this->vars['thumbcount'];
        
        require_once(DISCUZ_ROOT.'./source/plugin/boan_attachview/parsedoc.inc.php');
       $this->parse = new parseDoc();
    }
    
    private function load_attach(){
        global $_G,$post;
        if(empty($post)){
            return false;
        }
        preg_match_all(preg_match_all('/\[attach\](\d+)\[\/attach\]/is',$post['message'],$matches));
        $matches[1] = array_unique($matches[1]);         
        $aids = implode('|',$matches[1]);       
        $attachs = getattach($post['pid'],0,$aids);   
        $attachs = $attachs['attachs']['used'];     
        foreach ($attachs as $key => $attach){
            $attach['url'] = 'forum.php?mod=attachment&aid='.aidencode($attach['aid'],0,$attach['tid'].(defined('IN_MOBILE') ? '&mobile=2' : ''));
            $attach['readperm'] = $_G['group']['readaccess'] >= $attach['readperm'];
            if($attach['price']) {
                if($_G['setting']['maxchargespan'] && TIMESTAMP - $attach['dateline'] >= $_G['setting']['maxchargespan'] * 3600) {
                    C::t('forum_attachment_n')->update('tid:'.$_G['tid'], $attach['aid'], array('price' => 0));
                    $attach['price'] = 0;
                } elseif(!$_G['forum_attachmentdown'] && $_G['uid'] != $attach['uid']) {
                    $payaids[$attach['aid']] = $attach['pid'];
                }
            }
            $attach['payed'] = $_G['forum_attachmentdown'] || $_G['uid'] == $attach['uid'] ? 1 : 0;
            $attach['author'] = $post['author'];
            $attach['authorid'] = $post['authorid'];
            $this->attachs[$attach['aid']] = $attach;
        }
        if($payaids && $_G['uid']) {
            foreach(C::t('common_credit_log')->fetch_all_by_uid_operation_relatedid($_G['uid'], 'BAC', array_keys($payaids)) as $creditlog) {
                $this->attachs[$creditlog['relatedid']]['payed'] = 1;
            }
        }                
        foreach ($this->attachs as $k => $v){            
            if(in_array($v['aid'],$matches[1])){                
                $this->attachs[$k]['used'] = 1;            
            }        
        }

    }
    protected function check_allow(){
        global $_G;
        $rtn = 1;
       
        if(!in_array($_G['groupid'],$this->vars['groups']) || !in_array($_G['fid'],$this->vars['forums']) && $_G['basescript'] != 'group' || $_G['basescript'] == 'search' || defined('IN_ADMINCP')){
            $rtn = 0;
        }
        return $rtn;
    }
    
 
    function parse_attach($m){
        global $_G;
       
        if(empty($m[1]) || !($attach = $this->attachs[$m[1]])){
            return $m[0];
        }
        $ext = $attach['ext'];
        if(!in_array($ext, $this->vars['allow_ext'])){
            return $m[0];
        }
     
        $return = $this->parse->parse_forum_att($attach);
        if($attach['readperm'] && $return){
            $replacedown = $this->vars['replacedown'];
            (!$replacedown && $_G['uid'] &&  !$_G['feedpay']) && ($return .= $m[0]);
            return $return;        
        }
        return $m[0];    
    }
        
    
    function global_header(){
        global $_G;
        $rtn = '';
        if($_GET['mod'] == 'viewthread' || $_GET['mod'] == 'forumdisplay' ){
            $rtn = "<link href=\"./source/plugin/boan_attachview/reader/css/reader.css?{$_G['formhash']}\" rel=\"stylesheet\" type=\"text/css\" />";
            $rtn .= boan_load_jq('jquery-1.11.0.min.js','boan_attachview');
            $rtn .= "<script src=\"source/plugin/boan_attachview/reader/js/reader.js?{$_G['formhash']}\" charset=\"utf-8\" type=\"text/javascript\"></script>";
        }else if($_GET['mod'] == 'post'){
            $rtn .= boan_load_jq('jquery-1.11.0.min.js','boan_attachview');
            
            $rtn .= "<script src=\"source/plugin/boan_attachview/js/cos-auth.min.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
            
            $rtn .= "<script src=\"source/plugin/boan_attachview/js/webuploader.min.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
            
            $rtn .= "<script src=\"source/plugin/boan_attachview/js/tencentupload.js\" charset=\"utf-8\" type=\"text/javascript\"></script>";
            $bucket_url = $this->parse->getBucketUrl();
            $allow_ext = implode('|',$this->vars['allow_ext']);
            $rtn .= "<script> boan_attachview_hlongurl = '$bucket_url'; boan_attachview_allow = '$allow_ext'.split('|'); </script>";
            
            $rtn .= boan_reset_jq();
        }
        return $rtn;
    }
    
    function discuzcode($value){
        global $_G,$post;
        $this->pid = $post['pid'];
        if($this->check_allow()){
        
            $this->load_attach();
            $_G['discuzcodemessage'] = preg_replace_callback('/\[attach\](\d+)\[\/attach\]/is',array($this,'parse_attach'), $_G['discuzcodemessage']);      
            $_G['discuzcodemessage'] = preg_replace_callback('/\[oneattachatt\](\d+)\[\/oneattachatt\]/is',array($this,'parse_attach'), $_G['discuzcodemessage']);
            if($this->vars['parseout']){
                $str = '';
                foreach ($this->attachs as $k => $v){
                    if(empty($v['used']) && $v['pid'] == $post['pid']){
                        $str .= '[attach]'.$v['aid'].'[/attach]';
                    }
                }
                if(!empty($str)){
                    $str = preg_replace_callback('/\[attach\](\d+)\[\/attach\]/is',array($this,'parse_attach'), $str);
                    $str = preg_replace('/\[attach\](\d+)\[\/attach\]/is','',$str);
                    $_G['discuzcodemessage'] .= $str;
                }        
            }
           
        }
    }
}

class plugin_boan_attachview_forum extends plugin_boan_attachview{    
    function viewthread_bottom_output(){                
        global $_G;                
        global $postlist;   
        if(!$_G['uid']  && !is_dir(DISCUZ_ROOT.'./source/plugin/threed_dazhe')){
            foreach ($postlist as $k => $v){
                foreach ($postlist[$k]['attachments'] as $k1 => $v1){
                    if(in_array($v1['ext'],$this->vars['allow_ext'])){
                        unset($postlist[$k]['attachments'][$k1]);
                    }
                }
            }      
        }
        return '';
                 
    }        
    public function forumdisplay_thread_subject_output() {
        global $_G,$threadlist;
        $arr = array();
        if($this->vars['pcthumb'] && $this->check_allow()){
           $thumbw = dintval($this->vars['thumbw']);
           $thumbh = dintval($this->vars['thumbh']);
           $thumbw = $thumbw > 0 ? $thumbw.'px' : 'auto';
           $thumbh = $thumbh > 0 ? $thumbh.'px' : 'auto';
            foreach ($threadlist as $key => $thread){
                $urls = $this->parse->getthreadcover($thread['tid']);
                $ct = 0;
                foreach ($urls as $url){
                    if($ct++ >=  $this->vars['thumbcount']){
                        break;
                    }
                    $href = "forum.php?mod=viewthread&tid={$thread['tid']}";
                    $arr[$key] .= "<div><a href=$href><img src=\"$url\" style=\"width:$thumbw;height:$thumbh;float:left;margin-left:10px;\"></a></div>";
                }
            }        
        }
        return $arr;
    }
}


class plugin_boan_attachview_portal extends plugin_boan_attachview{    
    
    function view_article_top_output(){
        global  $_G;
        
        $rtn = "<link href=\"./source/plugin/boan_attachview/reader/css/reader.css?{$_G['formhash']}\" rel=\"stylesheet\" type=\"text/css\" />";
        $rtn .= boan_load_jq('jquery-1.11.0.min.js','boan_attachview');
        $rtn .= "<script src=\"source/plugin/boan_attachview/reader/js/portal_reader.js?{$_G['formhash']}\" charset=\"utf-8\" type=\"text/javascript\"></script>";
        return $rtn;
    }
    
    function view_article_content_output(){
        global  $_G,$content ;
        if(!$this->vars['isportal']){
            return '';
        }
        $content['content'] = preg_replace_callback('/<a\s*?href="portal.*?mod=attachment.*?id=(\d+)".*?>(.*?)<\/a>/is',function($m){
            global  $_G;
            $attach = $this->parse->get_portal_attach($m[1]);
            if(!empty($attach) && in_array($attach['ext'],  $this->vars['allow_ext'])){
                $s1 = ($_G['uid']>0 ? $m[0] : '');
                return  $this->parse->parse_portal_att($attach).$s1;
               
            }
            
            return $m[0];
            
        }, $content['content']);
        
    }
}



class mobileplugin_boan_attachview extends plugin_boan_attachview{

    function global_footer_mobile(){
        global $_G;
        $rtn = '';
        if($_GET['mod'] == 'viewthread' || $_GET['mod'] == 'forumdisplay' ){
            $rtn = "<link href=\"./source/plugin/boan_attachview/reader/touch/css/reader.css?{$_G['formhash']}\" rel=\"stylesheet\" type=\"text/css\" />";
            $rtn .= "<script src=\"source/plugin/boan_attachview/reader/touch/js/reader.js?{$_G['formhash']}\" charset=\"utf-8\" type=\"text/javascript\"></script>";
        }
        return $rtn;
    }
   
}

class mobileplugin_boan_attachview_forum extends mobileplugin_boan_attachview{
    function forumdisplay_thread_mobile_output(){
        global $_G,$threadlist;
        $arr = array();
        if($this->vars['mobilethumb'] && $this->check_allow()){
            $thumbw = dintval($this->vars['mthumbw']);
            $thumbh = dintval($this->vars['mthumbh']);
            $thumbw = $thumbw > 0 ? $thumbw.'px' : 'auto';
            $thumbh = $thumbh > 0 ? $thumbh.'px' : 'auto';
            foreach ($threadlist as $key => $thread){
                $urls = $this->parse->getthreadcover($thread['tid']);
                $str  = '';
                $ct = 0;
                foreach ($urls as $url){
                    if($ct++ >=  $this->vars['thumbcount']){
                        break;
                    }
                    $href = "forum.php?mod=viewthread&tid={$thread['tid']}";
                    $str.= "<a href=\"$href\" style=\"float:left;\"><img src=\"$url\" style=\"width:$thumbw;height:$thumbh;\"></a>";
                }
                if(!empty($str)){
                   $arr[$key] = "<div id=\"boan_attachview_$key\">$str</div><div id=\"boan_attachview_{$key}_after\" style=\"clear:both;\"></div><script>setTimeout(\"$('#boan_attachview_$key').parent().append($('#boan_attachview_$key'));$('#boan_attachview_$key').parent().append($('#boan_attachview_{$key}_after'));\",200);</script>";
                }
                
            }
        }
        return $arr;
    }
    
}

