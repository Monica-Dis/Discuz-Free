


function Boan_attachview(id,pages_count,view_count,tid,pid,aid,picwidth,uid,feedpay){
	var $that = this;
	
	this.id = id;
	var JQID = '#' + id;
	var pages_count = parseInt(pages_count);
	var view_count = parseInt(view_count);
	var picwidth = parseInt(picwidth);
	var maxpicw = parseInt(picwidth);
	var fill = 0;
	this.posobj = null;
	this.posmodel = 0;
	var cur = 0;
	var bodyShow = null;
	var viewport = '';
	
	this.setPageBottom = function(){
		var info = '';
		if(uid){
			if(!feedpay){
				info = '预览结束,请下载阅读全文。';
			}else{
				info = '预览结束,购买后可下载阅读全文。';
			}
		}else{
			info = '预览结束,请登录阅读全文。';
		}
		if(cur < view_count){
			$(JQID + ' .pagerwg-button .info').text('点击加载更多');
			
		}else if(view_count < pages_count){
				$(JQID + ' .pagerwg-button .info').text(info);
		}else{
			$(JQID + ' .pagerwg-root').hide();
		}
		$(JQID + ' .pagerwg-schedule .info').text('已阅读' + cur + '页,还有' + (pages_count - cur) + '页未读.');
	}
	
	this.pageDown = function(){
		var t = cur;
		var s = '';
		var t1 = (cur == 0 ? 3 : 30);
		if(cur >= view_count){
			$that.setPageBottom();
			return ;
		}
	    $(JQID + ' .pagerwg-button .info').text('请稍候...');
		setTimeout(function(){
			while((cur - t) < t1 && cur < view_count){
				cur++;
				var url = $that.getPageUrl(cur);
				url = url ? url.msg : '';
				
				s = '<div class="gap"></div>';
				s += '<div class="retype-page" id="' + $that.id + '_page' + cur + (cur == 1 ? '" data-page="1">' : '">');
				s += '<div><p class="pic"><img src="' + url + '" width="100%"  style="max-width: inherit; max-height: inherit;">  </p></div></div>';
				$(JQID+' .reader-container').append(s);
				
			}
			$(JQID + ' .retype-page').off('click');
			$(JQID + ' .retype-page').on('click',{},function(e){
				if(!$that.fill){
					$that.setFillScreen();
				}else{
					$that.closeFillScreen();
				}
			});
			$that.setPageBottom();
			},200);
	
	}
	
	this.getPageUrl = function(page){
		var url = 'plugin.php?id=boan_attachview:ajax&op=getpageurl&tid=' + tid +'&pid=' + pid + '&page=' + page + '&aid=' + aid;
		obj = null;
		$.ajax({
				type:"GET",
				url:url,
				async:false,
				success:function(data){
					 obj = eval ("(" + data + ")");
				},
				error:function(xhr,status,error){
					console.log(error);
				},
		});
		return obj;
	}
	

	
	this.setFillScreen = function(){
		$that.fill = 1;
		$that.posobj = $(JQID).next();
		$that.posmodel = 1;
		viewport = $("meta[name='viewport']").attr('content');
		$("meta[name='viewport']").attr('content','width=device-width, initial-scale=1.0, user-scalable=yes, minimum-scale=1.0, maximum-scale=10.0');
		if($that.posobj.length == 0){
			$that.posobj = $(JQID).prev();
			$that.posmodel = 2;
		}
		if($that.posobj.length == 0){
			$that.posobj = $(JQID).parent();
			$that.posmodel = 0;
		}
		
		var t = $(JQID + ' :visible');
		bodyShow = $("body  :visible");
		bodyShow.hide();
		
		$(JQID).show();
		t.show();
		
		$('body').prepend($(JQID));
	}
	
	this.closeFillScreen = function(){
		$that.fill = 0;
		$("meta[name='viewport']").attr('content',viewport);
		if(	$that.posmodel == 0){
			$that.posobj.prepend($(JQID));
		}else if($that.posmodel == 1){
			$that.posobj.before($(JQID));
		}else{
			$that.posobj.after($(JQID));
		}
		bodyShow.show();
		
	}
	
	this.init = function(){
		$that.pageDown();
		
		$(JQID + ' .pagerwg-button').on('click',{},function(e){
			if(!uid && cur >= view_count){
				window.location = 'member.php?mod=logging&action=login&mobile=2';
			}else{
				$that.pageDown();
			}
		});
	
	}
	this.init();
	
}


$('.content-wrapper').each(function(index,el){
	var id = $(el).attr('id'),
	    ctpages = $(el).data('ctpages'),
		ctview =  $(el).data('ctview'),
		tid =  $(el).data('tid'),
		pid =  $(el).data('pid'),
		aid =  $(el).data('aid'),
		picwidth =  $(el).data('picwidth'),
		uid =  $(el).data('uid'),
		feedpay = $(el).data('feedpay');
		
	   new Boan_attachview(id,ctpages,ctview,tid,pid,aid,picwidth,uid,feedpay);
});

