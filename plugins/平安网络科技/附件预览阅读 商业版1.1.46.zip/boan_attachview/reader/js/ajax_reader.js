


function Boan_ajax_attachview(id,pages_count,view_count,tid,pid,aid,picwidth){
	var $that = this;
	var JQID = '#' + id;
	var $$ =  boan_jq;
	
	var cur = 1;
	this.id = id;
	this.pages_count = parseInt(pages_count);
	this.view_count = parseInt(view_count);
	this.picwidth = parseInt(picwidth);
	this.maxpicw =  parseInt(pages_count);
	
	this.tid = tid;
	this.pid = pid;
	this.aid = aid;
	this.loaddom = null;
	this.fill = false;
	this.posobj = null;
	this.posmodel = 0;
	this.scrolltop = 0;
	
	this.getPageUrl = function(page){
		var url = 'plugin.php?id=boan_attachview:ajax&op=getpageurl&tid=' + $that.tid +'&pid=' + $that.pid + '&page=' + page + '&aid=' + $that.aid;
		obj = null;
		$$.ajax({
				type:"GET",
				url:url,
				async:false,
				success:function(data){
					 obj = eval ("(" + data + ")");
				},
				error:function(xhr,status,error){
					console.log(error);
				},
		});
		return obj;
	}
	
	
	this.getPageWid = function (){
		var cur = parseInt($$(JQID).find('.cur-page').val());
		var picw = $$(JQID+'_page' + cur + ' img').eq(0).width();
		
		if(picw > $that.maxpicw){
			$that.maxpicw = picw;
		}else{
			picw = $that.maxpicw;
		}
		if($that.fill){
			(picw > $$(window).width() -100 ) && (picw = $$(window).width() - 100);
		}else if(!$that.get_widthauto()){
			(picw > $$(JQID).width()) && (picw = $$(JQID).width());
		}
		return picw;
	}

	this.setPagePos = function(){
		var pwid;
		if($that.get_widthauto()){
			pwid = $that.picwidth - 48;
		}else{
			pwid = $that.getPageWid() - 48;
		}
		
		$$(JQID).find('.reader-page-btn').eq(1).css('left',pwid + 'px');
	}

	this.showpage = function(page_no,force){
		var cur = parseInt($$(JQID).find('.cur-page').val());
		var gopage = page_no;
		if(page_no == cur && !force){
			return ;
		}
		if(page_no < 1){
			gopage = 1;
		}else if(page_no > $that.view_count){
			gopage = $that.view_count;
		}
		$$(JQID).find('.cur-page').val(gopage);
		
		var img = $$(JQID+'_page' + gopage + ' img')[0];
		
		img.onload = function () {
			var picwidth = $$(this).width();
			var widthauto = $that.get_widthauto();
			$that.hideloading();
			$that.getPageWid();
			if((picwidth > $that.picwidth) && widthauto && !$that.fill){
				$$(this).css('width',$that.picwidth + 'px');
			}else if(picwidth > $$(JQID).width()){
				$$(this).css('width',$$(JQID).width() + 'px')
			}
			var picheight = $$(this).height();
			
			!$that.fill && $$(this).parent().parent().css('height',picheight+'px');
			if(!$that.fill){
				$$(JQID).find('.reader-container')[0].scrollTop = $$(JQID+'_page' + gopage)[0].offsetTop-38;
				$that.setPagePos();
			}else{
				var pos = $$(JQID+'_page' + gopage).offset();
				$$(document).scrollTop(pos.top - 38);
			}
			$$(this).addClass('zoom');
			$$(this).attr('alt',$$(this).parent().attr('alt'));
				
		};
		if(!img.getAttribute('src')){
			var obj = $that.getPageUrl(gopage);
			if(obj && obj.code == 200){
				$that.showloading($$(JQID+'_page' + cur));
				img.setAttribute('src', obj.msg);
			}else{
				alert(obj.msg);
			}
			
		}else{
			if(!$that.fill){
				$$(JQID).find('.reader-container')[0].scrollTop = $$(JQID+'_page' + gopage)[0].offsetTop-38;
				$that.setPagePos();
				
			}else{
				var pos = $$(JQID+'_page' + gopage).offset();
				$$(document).scrollTop(pos.top - 38);
			}
		}
		$that.set_end_fold_page();
	}
	

	this.set_height = function(){
		if(!$that.fill){
			var H = $$(JQID).find('.reader-container').height();
			if(H > 800){
				$$(JQID + ' .reader-container-wrap').css('height','800px');
			}else{
			    $$(JQID + ' .reader-container-wrap').css('height','auto');
			}
		}
	}
	
	this.get_widthauto = function(){
		return  true;
	}
	
	this.set_widthauto = function(){
		var cur = parseInt($$(JQID).find('.cur-page').val());
		$$(JQID).css('width','auto');
		setTimeout(function(){
			var widthauto = $that.get_widthauto();
			var picw = 'auto';
			
			if(widthauto && !$that.fill){
				picw = $that.getPageWid();
				if((picw >= $that.picwidth)){
					 picw = $that.picwidth + 'px';
				}else{
					 picw = 'auto';
				}
			}else if(!widthauto || $that.fill){
				picw = $that.getPageWid() + 'px';
				
			}
	       
			$$(JQID).css('width',picw > $that.picwidth ? picw : $that.picwidth);
			
			
			$$(JQID+' .reader-page img').css('width',picw);
		
			var pich = $$(JQID+'_page1 img').eq(0).height()+'px';
			$that.fill && (pich = 'auto');
			$$(JQID+' .reader-container').css('height',pich);
			$that.showpage(cur,true);
			
			$that.set_height();
		},200);
	}
	
	this.showloading = function(el){
		if(!$that.loaddom){
			$that.loaddom = document.createElement('div');
			$that.loaddom.id="loaddom";
		}
		var width = el.parent().css('width') ? el.parent().css('width') : '100px';
		var height = el.parent().css('height') ? el.parent().css('height') : '100px';
		$that.loaddom.innerHTML = '<div style="width: '+width+'; height: '+height+';background: url('+IMGDIR + '/loading.gif) no-repeat center center;"></div>';
		$that.loaddom.style.display = '';
		el.before($that.loaddom);		
	}
	
	this.isloading = function(){
		return ($that.loaddom) ? true : false;
	}
	
	this.hideloading = function(){
		$$(JQID).find("[id='loaddom']").remove();
		$that.loaddom = null;
	}
	
	this.set_end_fold_page = function(){
		
		var curpage = parseInt($$(JQID).find('.cur-page').val());
		if(curpage  == $that.view_count && $that.pages_count > $that.view_count){
			$$(JQID).find('.try-end-fold-page').show();
		}else{
			$$(JQID).find('.try-end-fold-page').hide();
		}
		
	}
	this.scroll_change = function(){
		$$('[id^=' + $that.id + '_page]').each(function(index,el){
		   var pos = $$(this).offset();
		   var scrtop = $$(document).scrollTop();
		   var winh = $$(window).height();
		   var nextobj = '';
		   var rtn = true;
		   if($$(this).children('img:first').attr('src')){
				if((pos.top - scrtop)>=0 && (pos.top - scrtop) <= winh){
					$$(JQID).find('.cur-page').val(index+1);
					$that.set_end_fold_page();
					rtn = false;
				}
				nextobj = $$(this).next('.reader-page');
				var nextpage = index+2;
				if(!nextobj.length){
					nextobj = $$(this).prev('.reader-page');
					nextpage = index-2;
				}
				if(!$that.isloading() &&  nextobj.length && !nextobj.children('img:first').attr('src')){
					pos = nextobj.offset();
					if((pos.top - scrtop)>=0 && (pos.top - scrtop) <= winh){
						var img = nextobj.children('img:first')[0];
						var obj = $that.getPageUrl(nextpage);
						if(obj && obj.code == 200){
							$that.showloading(nextobj);
							img.setAttribute('src', obj.msg);
						}else{
							alert(obj.msg);
						}

						img.onload = function () {
							$that.hideloading();
							if(!isUndefined($$('body').css('zoom'))){
								var zoom = parseFloat($$(JQID + ' .reader-container').css('zoom'));
								var imgwidth = ($that.getPageWid() * zoom) + 'px';
								$$(JQID).css('width',imgwidth);
								$$(JQID+' .topbar-container').css('width',imgwidth);
							}
							
						}
					}
				}
    			return rtn;
		   }
		});
	
	}
	
	
	this.set_screen_fill = function(){
		$that.scrolltop = $$(document).scrollTop();
		boan_attachview_screen_objs  = $$("body :visible");
		var x_reader = $$(JQID+' :visible');
		$that.fill = true;
		boan_attachview_screen_objs.hide();
		
		
		$that.posobj = $$(JQID).next();
		$that.posmodel = 1;
		if($that.posobj.length == 0){
			$that.posobj = $$(JQID).prev();
			$that.posmodel = 2;
		}
		if($that.posobj.length == 0){
			$that.posobj = $$(JQID).parent();
			$that.posmodel = 0;
		}
		
		
		$$('body').prepend($$(JQID));
				
		x_reader.show();
		$$(JQID).show();		
		$$(JQID + ' .doc-btns-wrap').css('display','none');
		$$(JQID + ' .doc-info-wrapper').css('display','none');
		$$(JQID + ' .reader-topbar').css('cursor','auto');
		
		$$(JQID + ' .reader-container-wrap').css('height','auto');
		$$(JQID + ' .reader-container-wrap').css('overflow','hidden');
		
		$that.set_widthauto();
		var imgwidth = $that.getPageWid() + 'px';
		$$(JQID).css('width',imgwidth);
		$$(JQID+' .topbar-container').css('width',imgwidth);
					
		$$(JQID+' .reader-topbar').css('position','fixed');
		$$(JQID+' .flbc').css('display','none');
		$$('body').addClass('full-screen');
		if(isUndefined($$('body').css('zoom'))){
			$$(JQID).find('.scale-big').hide();
			$$(JQID).find('.scale-small').hide();
		}
		
		$that.scroll_change();
		_attachEvent(window,'scroll',$that.scroll_change);
		
	}

	this.init = function(){
		
		this.showpage(1,true);
		setTimeout(function(){$that.set_widthauto();},200);
	
		
		$('fwin_attachview').style.height = '1200px';
		
		$$(JQID).find('.change-page').on("click",{},function (e) {
           var cur = parseInt($$(JQID).find('.cur-page').val());
		   if($$(this).attr('data-btn') == 0){
		   		cur = cur - 1;
		   }else{
		   		cur = cur + 1;
		   }
		   $that.showpage(cur);
        });
		
		
		
		$$(JQID).find('.read-all').on("click",{},function (e) {
			$that.pageDown();
		});
		
		$$(JQID).find('.btn-full').on("click",{},function (e) {
			$that.set_screen_fill();
		});
		
				
	    $$(JQID).find('.reader-page-btn').on("mouseover",{},function(e){
			$$(this).css('opacity',1);
		});
		
		$$(JQID).find('.reader-page-btn').on("mouseout",{},function(e){
			$$(this).css('opacity',0.5);
		});
		
		$$(JQID).find('.reader-page-btn').on("click",{},function(e){
		   var cur = parseInt($$(JQID).find('.cur-page').val());
		   if($$(this).attr('data-btn') == 0){
		   		cur = cur - 1;
		   }else{
		   		cur = cur + 1;
		   }
		   $that.showpage(cur);
		});
		
		$$(JQID).find('.reader-container').on("mouseover",{},function(e){
			if($that.fill ){
				return ;
			}
			$$(JQID).find('.reader-page-btn').css('display','block');
		});
		$$(JQID).find('.reader-page img').on("mouseover",{},function(e){
			if($that.fill){
				return ;
			}
			$$(JQID).find('.reader-page-btn').css('display','block');
		});
		
		$$(JQID).find('.reader-page').on("mouseout",{},function(e){
			$$(JQID).find('.reader-page-btn').css('display','none');
		});
		
		$$(JQID).find('.reader-container').on("mouseout",{},function(e){
			$$(JQID).find('.reader-page-btn').css('display','none');
		});
		
		$$(JQID).find('.scale-big').on("click",{},function(e){
			var zoom = parseFloat($$(JQID + ' .reader-container').css('zoom'));
			zoom += 0.1;
			$$(JQID).width($that.getPageWid() * zoom + 'px');
			$$(JQID + ' .reader-container').css('zoom',zoom);
			$$(JQID + ' .try-end-fold-page').css('zoom',zoom);
		});
		
		$$(JQID).find('.scale-small').on("click",{},function(e){
			var zoom = parseFloat($$(JQID + ' .reader-container').css('zoom'));
			zoom -= 0.1;
			if(zoom < 1){
				return ;
			}
			$$(JQID).width($that.getPageWid() * zoom + 'px');
			$$(JQID + ' .reader-container').css('zoom',zoom);
			$$(JQID + ' .try-end-fold-page').css('zoom',zoom);
			
		});
		
		$$(JQID).find('.reader-page-btn').on("click",{},function(e){
			$$(this).css('opacity',1);
		});
		
		$$(JQID).find('.reader-page').on("click",{},function(e){
			/*var img = $$(this).children('img:first');
			if(!$that.fill && img.attr('src')){
				var url = $that.getPageUrl($$(this).index()-1);
				zoom(img[0], url.msg, 0, 0, 0);
			}*/
		});
		
		if(this.get_widthauto()){
			$$(JQID).css('width',$that.picwidth + 'px');
		}
		
		$$(JQID).find('.cur-page').on('change',{},function(e){
			var cur = parseInt($$(this).val());
			$that.showpage(cur,true);
		});
		
		$$(JQID).find('.exit-full-screen').on("click",{},function(e){
			$that.fill = false;
			if(	$that.posmodel == 0){
				$that.posobj.prepend($$(JQID));
			}else if($that.posmodel == 1){
				$that.posobj.before($$(JQID));
			}else{
				$that.posobj.after($$(JQID));
			}
			
			$$(JQID + ' .reader-topbar').css('cursor','move');
			
			$$(JQID + ' .reader-container').css('zoom',1);
			$$(JQID + ' .try-end-fold-page').css('zoom',1);
			$$(JQID+' .flbc').css('display','');
			$$('body').removeClass('full-screen');
			$$(JQID+' .reader-topbar').css('position','relative');
			$$(JQID+' .topbar-container').css('width','auto');
			
			$$(JQID + ' .reader-container-wrap').css('height','474px');
		    $$(JQID + ' .reader-container-wrap').css('overflow','auto');
			boan_attachview_screen_objs.show();
			$that.set_widthauto();
			$$(document).scrollTop($that.scrolltop);
			_detachEvent(window,'scroll',$that.scroll_change);
				
		});
		if($('switchwidth')){
			_attachEvent($('switchwidth'),'click',function(e){ setTimeout($that.set_widthauto,200);});
		}
	
		
		$$(JQID).bind("contextmenu",function(e){
			return false;
		});
		
		$$(JQID).find('img').on('dragstart',function(e){
			
			return false;	
		});
		
	}
	this.init();
	
}

