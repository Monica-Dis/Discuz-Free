<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
define('BOAN_ATTACHVIEW_NAME', 'plugin/boan_attachview');
global $_G;
$uid = $_G['uid'];
if(!$uid){
    showmessage('group_nopermission', NULL, array('grouptitle' => $_G['group']['grouptitle']), array('login' => 1));
}
$aid = intval($_GET['aid']);

if(!$aid){
    showmessage(lang(BOAN_ATTACHVIEW_NAME, 'ajax_nothing'));
}

$attach = C::t('forum_attachment_n')->fetch('aid:'.$aid,$aid);
if(empty($attach)){
    showmessage(lang(BOAN_ATTACHVIEW_NAME, 'ajax_nothing'));
}

$temp = C::t('common_credit_log')->fetch_all_by_uid_operation_relatedid($uid, 'BAC', array($aid));
if(count($temp) > 0 || $uid == $_G['adminid']  || $uid == $attach['uid'] || !$attach['price']){
    showmessage(lang(BOAN_ATTACHVIEW_NAME, 'pay_unfeedpay'));
}

if(empty($_G['cache']['plugin'])){
    loadcache('plugin');
}
$vars = $_G['cache']['plugin']['boan_attachview'];

loadcache('boan_attachview_realization',true);
$rcache = $_G['cache']['boan_attachview_realization'];

$credits = $_G['setting']['extcredits'][$rcache['extcredittype']];
$balance = getuserprofile('extcredits'.$rcache['extcredittype']);

$rcache['preferential'] = explode(PHP_EOL, $rcache['preferential']);
$preferential = array();
foreach ($rcache['preferential'] as $v){
    $t = explode('|', $v);
    $preferential[$t[0]] = $t[1];
}
$attach['netprice'] =  round($attach['price'] * (1 - $_G['setting']['creditstax']));
if($preferential[$_G['groupid']]){
    $attach['netprice'] = $attach['netprice'] * (intval($preferential[$_G['groupid']])/100);
    $attach['netprice'] = intval($attach['netprice']);
}
$lockid = 'docpay_'.$_G['uid'];
if(!submitcheck('payok')){
    require_once(DISCUZ_ROOT.'./source/plugin/boan_attachview/parsedoc.inc.php');
    loadcache('boan_attachview_realization',true);
    $rcache = $_G['cache']['boan_attachview_realization'];
    
    $payurl = '';
    $alipay = intval($rcache['alipay']);
    $wechat = intval($rcache['wechat']);
    $rcache['rate'] <= 0 && $rcache['rate'] = 10;
    $amount = 0;
    $amount = $attach['price'] / $rcache['rate'];
    if($alipay || $wechat){
        C::m('#payment#payment');
        try{
            $order_id = C::m('#payment#payment')->build($attach['filename'], $_G['uid'], $amount * 100, 'boan_attachview_pay', 
                ['aid' => $aid,
                 'uid' => $_G['uid'],
                 'authorid' => $attach['uid'],
                 'netprice' => $attach['netprice'],
                 'extcredittype' => $rcache['extcredittype'], 
                ], 600,'','','forum.php?mod=redirect&goto=findpost&ptid='.$attach['tid'].'&pid='.$attach['pid']);
            $payurl = payment::makeurl($order_id);
            
        }catch (PaymentExeption $e){
            
        }
    }
    
    $parse = new parseDoc();
    $ext = fileext($attach['filename']);
    $arr_ext = array('doc'  => 'word',
        'docx' => 'word',
        'ppt'  => 'ppt',
        'pptx' => 'ppt',
        'txt'  => 'txt',
        'pdf'  => 'pdf',
    );
    
    $sext = array_key_exists($ext, $arr_ext) ? $arr_ext[$ext] : 'why';
    
    $docsize = sizecount($attach['filesize']);
    $picurl = $parse->getthreadcover($attach['tid']);
    $picurl = $picurl[0];
    $inpoururl = $rcache['inpoururl'];
    include template('common/header');
    include  template('boan_attachview:pay');
    if(!defined('IN_MOBILE')){
        include template('common/footer');
    }
}else{
    if($_GET['formhash'] != $_G['formhash']){
        showmessage(lang(BOAN_ATTACHVIEW_NAME, 'pay_unlawful'));
    }
    
    if($balance < $attach['price']){
        showmessage(lang(BOAN_ATTACHVIEW_NAME, 'pay_dontpay'));
    }
    
    if(!discuz_process::islocked($lockid)){
        $updateauthor = 1;
        $authorEarn = $attach['netprice'];
        if($_G['setting']['maxincperthread'] > 0) {
            $extcredit = 'extcredits'.$rcache['extcredittype'];
            $alog = C::t('common_credit_log')->count_credit_by_uid_operation_relatedid($attach['uid'], 'SAC', $aid, $_G['setting']['creditstransextra'][$rcache['extcredittype']]);
            if($alog >= $_G['setting']['maxincperthread']) {
                $updateauthor = 0;
            } else {
                $authorEarn = min($_G['setting']['maxincperthread'] - $alog['credit'], $attach['netprice']);
            }
        }
        if($updateauthor) {
            updatemembercount($attach['uid'], array($rcache['extcredittype'] => $authorEarn), 1, 'SAC', $aid);
        }
        updatemembercount($_G['uid'], array($rcache['extcredittype'] => -$authorEarn), 1, 'BAC', $aid);
        
        discuz_process::unlock($lockid);
    }
    showmessage(lang(BOAN_ATTACHVIEW_NAME, 'pay_ok'), 'forum.php?mod=redirect&goto=findpost&ptid='.$attach['tid'].'&pid='.$attach['pid']);
   
}



