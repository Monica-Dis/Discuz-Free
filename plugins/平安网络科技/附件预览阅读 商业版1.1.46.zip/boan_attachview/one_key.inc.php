<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
define('BOAN_ATTACHVIEW_NAME', 'plugin/boan_attachview');
global $_G;
if(empty($_G['cache']['plugin'])){
    loadcache('plugin');
}
$vars = $_G['cache']['plugin']['boan_attachview'];
if($_GET['pmod'] == 'one_key'){
    if(!submitcheck('one_submit') && !$_GET['step']){
       
        loadcache('boan_attachview_onkey',true);
        $attcache = $_G['cache']['boan_attachview_onkey'];
        
        if(!$_G['cache']['boan_attachview_onkey']){
            $attcache = array(
                'userlist' => '',
                'process' => 1,
                'att_price' => '0',
                'att_tags' => '',
                'att_readaccess' => '0',
                'att_forum' => null,
                'att_typeid' => 0,
                'att_sortid' => 0,
                'att_typeoption' => array(),
                'att_top' => '',
                'att_bottom' => '',
                'att_repeat' => 0,
                
            );
        }
        
        cpheader();
        showtips(lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_explain'));
        showformheader('plugins&operation=config&do='.$pluginid.'&pmod=one_key');
        echo '<input type="hidden" name="reload" id="reload" value="" />';
        showtableheader('','','',9);
        showtagheader('tbody', '',true);
        
        showsetting(lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_userlist'), 'userlist',  $attcache['userlist'],'text',0,0,lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_userlist_comment'));
        
        showsetting(lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_attprice'), 'attprice',  $attcache['att_price'],'text',0,0,lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_attprice_comment'));
        showsetting(lang(BOAN_ATTACHVIEW_NAME,'onekey_one_atttags'), 'atttags', $attcache['att_tags'],'text',0,0,lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_atttags_comment'));
        show_groupreadaccess($attcache['att_readaccess']);
   
        $var =  array('title'=>lang(BOAN_ATTACHVIEW_NAME,'onekey_one_forum'),
            'type' => 'forum',
            'description' => lang(BOAN_ATTACHVIEW_NAME,'onekey_one_forum_comment'),
            'variable' => 'attforum',
            'value' => $attcache['att_forum'],
            
        );
        
        show_forum($var);
        
        $fid = dunserialize($attcache['att_forum']);
        $fid = $fid[0];
        loadforum($fid);
        
        echo <<<EOF
<script>
               $('forum').onchange=function(){
                   $('reload').value = 1;
                   $('submit_one_submit').click();
                }
                
          </script>
EOF;
        if(isset($_G['forum']['threadtypes']['types']) && count($_G['forum']['threadtypes']['types']) > 0){
           
            $arr = array(array('0',lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_none')));
            foreach ($_G['forum']['threadtypes']['types'] as $key => $val){
                $arr[] = array($key,$val);
            }
            
            showsetting(lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_atttypeid'),
                array('atttypeid',
                   $arr),
                $attcache['att_typeid'],'select',0,0,lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_atttypeid_comment'),'id=typeid'
                );
        }
        
        if(isset($_G['forum']['threadsorts']['types']) && count($_G['forum']['threadsorts']['types']) > 0){
            
            $arr = array(array('0',lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_none')));
            foreach ($_G['forum']['threadsorts']['types'] as $key => $val){
                $arr[] = array($key,$val);
            }
            
            $sortid = array_key_exists($attcache['att_sortid'],$_G['forum']['threadsorts']['types']) ? $attcache['att_sortid'] : 0;
            showsetting(lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_attsortid'),
                array('attsortid',
                    $arr),
                $sortid,'select',0,0,lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_attsortid_comment'),'id=sortid'
                );
            
            
            echo <<<EOF
<script>
               $('sortid').onchange=function(){
                   $('reload').value = 1;
                   $('submit_one_submit').click();
                }
                
          </script>
EOF;
            if($sortid){
                require_once libfile('post/threadsorts', 'include');
                foreach ($_G['forum_optionlist'] as $optionid => $option){
                    $val = $attcache['att_typeoption'][$option['identifier']];
                    if($option['type'] == 'image'){
                        unset($_G['forum_optionlist'][$optionid]);
                        continue;
                    }
                    if(!empty($val)){
                        if($option['type'] == 'radio') {
                            $_G['forum_optionlist'][$optionid]['value'] = array($val => 'checked="checked"');
                        }elseif($option['type'] == 'select') {
                            $_G['forum_optionlist'][$optionid]['value'] = array($val => 'selected="selected"');
                        } else {
                            $_G['forum_optionlist'][$optionid]['value'] = $val;
                        }
                    }
                }
                
                include template('boan_attachview:post_sortoption');
            }
            
        }
        showtagfooter('tbody');
        showtablefooter(); /*dism��taobao��com*/
        
        
        showtableheader('','','',9);
        showtagheader('tbody', '',true);
        
        showsetting(lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_atttop'), 'atttop',   $attcache['att_top'],'textarea',0,0,lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_atttop_comment'));
        showsetting(lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_attbottom'), 'attbottom',   $attcache['att_bottom'],'textarea',0,0,lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_attbottom_comment'));
        showsetting(lang(BOAN_ATTACHVIEW_NAME,'onekey_one_process'), 'process', (empty($attcache['process']) ? 1 : $attcache['process']),'text',0,0,lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_process_comment'));
        showsetting(lang(BOAN_ATTACHVIEW_NAME,'onekey_one_repeat'), 'repeat', $attcache['att_repeat'],'radio',0,0,lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_repeat_comment'));
        
        showtagfooter('tbody');
        showtablefooter(); /*dism��taobao��com*/
        showsubmit('one_submit');
        showformfooter(); /*Dism_taobao-com*/
    }else if(!$_GET['step']){
        loadcache('boan_attachview_onkey',true);
        $attcache = $_G['cache']['boan_attachview_onkey'];
        $attcache = array(
            'userlist' => dhtmlspecialchars($_GET['userlist']),
            'process' => intval($_GET['process']),
            'att_price' => intval($_GET['attprice']),
            'att_tags' => dhtmlspecialchars($_GET['atttags']),
            'att_readaccess' => intval($_GET['attreadaccess']),
            'att_forum' => serialize($_GET['attforum']),
            'att_typeid' => intval($_GET['atttypeid']),
            'att_sortid' => intval($_GET['attsortid']),
            'att_top'    =>  dhtmlspecialchars($_GET['atttop']),
            'att_bottom'  =>  dhtmlspecialchars($_GET['attbottom']),
            'att_typeoption' => $_GET['typeoption'],
            'att_repeat' => intval($_GET['repeat']),
        );
        savecache('boan_attachview_onkey',$attcache);
        if($_GET['reload']){
            $url = 'action=plugins&operation=config&do='.$pluginid.'&pmod=one_key';
            $url = preg_match('/^https?:\/\//is', $url) ? $url : ADMINSCRIPT.'?'.$url;
            dheader('location:'.$url);
        }
      
        $url = 'action=plugins&operation=config&do='.$pluginid.'&pmod=one_key&step=2';
        $url = preg_match('/^https?:\/\//is', $url) ? $url : ADMINSCRIPT.'?'.$url;
        dheader('location:'.$url);
    }else{
        (file_exists(DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/loadoss.php') &&  require_once(DISCUZ_ROOT.'./source/plugin/boan_h5upload/oss/loadoss.php'))
        || (file_exists(DISCUZ_ROOT.'./source/plugin/boan_oss/loadoss.php') &&  require_once(DISCUZ_ROOT.'./source/plugin/boan_oss/loadoss.php'));
        
        loadcache('boan_attachview_onkey');
        $attcache = $_G['cache']['boan_attachview_onkey'];
        cpheader();
        $url = 'action=plugins&operation=config&do='.$pluginid.'&pmod=one_key';
        $url = preg_match('/^https?:\/\//is', $url) ? $url : ADMINSCRIPT.'?'.$url;
      
        if(!isset($_G['cache']['forums'])) {
            loadcache('forums');
        }
        $forumcache = &$_G['cache']['forums'];
        $forum = unserialize($attcache['att_forum']);
        $forum = $forumcache[$forum[0]];
        
        loadcache('groupreadaccess');
        $ratitle = lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_nolimit');
        foreach ($_G['cache']['groupreadaccess'] as $v){
            if($attcache['att_readaccess'] == $v['groupid']){
                $ratitle = $v['grouptitle'];
                break;
            }
        }
        $typeids = DB::fetch_all('SELECT typeid,fid,name FROM %t',array('forum_threadclass'));
        $typetitle = lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_none');
        foreach ($typeids as $v){
            if($attcache['att_typeid'] == $v['typeid']){
                $typetitle = $v['name'];
                break;
            }
        }
        
        
        $postmaxsize = return_bytes(ini_get('post_max_size'));
        $hash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
        $ossserver = '';
        $post_params = "{uid:{$_G['uid']},hash:'$hash',type:'attach'}";
       
        if(empty($_G['BOAN_OSSCONFIG'])){
            $upload_url = 'misc.php?mod=swfupload&action=swfupload&operation=upload';
            $fileVal = 'Filedata';
            $postmaxsize = return_bytes(ini_get('post_max_size'));
        }else{
            $ossserver = $_G['BOAN_OSS']::$oss_server_name;
            $upload_url =  $_G['BOAN_OSSCONFIG']['oss_bucket_url'];
            $fileVal = 'file';
            $postmaxsize = 200000000;
         
        }
        
        require_once(DISCUZ_ROOT.'./source/plugin/boan_attachview/parsedoc.inc.php');
        $parse = new parseDoc();
        $hlongurl = $parse->getBucketUrl();
        $attcache['process'] = empty($attcache['process']) ? 1 : $attcache['process'];
        
        include template('boan_attachview:onekey');
    }
}



function show_forum($var){
   require_once libfile('function/forumlist');
    $var['description'] = ($var['description'] ? (isset($lang[$var['description']]) ? $lang[$var['description']] : $var['description'])."\n" : '').$lang['plugins_edit_vars_multiselect_comment']."\n".$var['comment'];
    $var['value'] = dunserialize($var['value']);
    $var['value'] = is_array($var['value']) ? $var['value'] : array();
    $var['type'] = '<select id="forum" name="'.$var['variable'].'[]"><option value="">'.cplang('plugins_empty').'</option>'.forumselect(FALSE, 0, 0, TRUE).'</select>';
    foreach($var['value'] as $v) {
        $var['type'] = str_replace('<option value="'.$v.'">', '<option value="'.$v.'" selected>', $var['type']);
    }
    $var['variable'] = $var['value'] = '';
    showsetting(isset($lang[$var['title']]) ? $lang[$var['title']] : dhtmlspecialchars($var['title']), $var['variable'], $var['value'], $var['type'], '', 0, isset($lang[$var['description']]) ? $lang[$var['description']] : nl2br(dhtmlspecialchars($var['description'])), dhtmlspecialchars($var['extra']), '', true);
}


function show_groupreadaccess($var){
    global $_G;
    loadcache('groupreadaccess');
    $arr = [];
    $arr[] = array('0',lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_nolimit'));
    foreach ($_G['cache']['groupreadaccess'] as $v){
        array_push($arr, array($v['groupid'],$v['grouptitle']));
    }
    showsetting(lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_attreadaccess'),
        array('attreadaccess',$arr),
        $var,'select',0,0,lang(BOAN_ATTACHVIEW_NAME, 'onekey_one_attreadaccess_comment')
        );
}