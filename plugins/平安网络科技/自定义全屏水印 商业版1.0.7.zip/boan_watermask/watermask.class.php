<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
define('BOAN_WATERMASK_NAME', 'plugin/boan_watermask');
class plugin_boan_watermask{
    var $vars;
    function __construct(){
        global $_G;
        if(empty($_G['cache']['plugin'])){
            loadcache('plugin');
        }
        $this->vars = $_G['cache']['plugin']['boan_watermask'];
        $this->vars['allow_forums'] = unserialize($this->vars['allow_forums']);
        $this->vars['allow_groups'] = unserialize($this->vars['allow_groups']);
        $this->vars['set_forums'] = unserialize($this->vars['set_forums']);
        $this->vars['set_groups'] = unserialize($this->vars['set_groups']);
        $this->vars['is_first_user'] = intval($this->vars['is_first_user']);
    }
    
    function common() {
        global $_G;
        if(CURMODULE == 'post' && $this->vars['is_reply'] && $_GET['action'] == 'reply'){
            return ;
        }
        
        
        if(in_array($_G['fid'], $this->vars['set_forums']) || in_array($_G['groupid'], $this->vars['set_groups'])){
            if(empty($_GET['boanwatermask_tile']) && empty($_GET['boanwatermask_text']) && empty($_GET['boanwatermask_logo'])){
                return ;
            }
        }
        
        if(CURMODULE == 'post' && $this->vars['is_forum'] && is_array($_GET['attachnew'])
            && in_array($_G['fid'], $this->vars['allow_forums']) && in_array($_G['groupid'], $this->vars['allow_groups'])){
            $uid = $_G['uid'];
            $newaids = array_keys($_GET['attachnew']);
           $drawattachs = array();
           foreach(C::t('forum_attachment_unused')->fetch_all($newaids) as $attach) {
                if($attach['uid'] != $uid) {
                    continue;
                }
                if($attach['isimage'] && fileext($attach['filename']) != 'gif') {
                    $filename = $_G['setting']['attachdir'].'/forum/'.$attach['attachment'];
                    if($this->vars['pic_width'] || $this->vars['pic_height']){
                        $img = getimagesize($filename);
                        if($this->vars['pic_width'] && $img[0] < $this->vars['pic_width'] || $this->vars['pic_height'] && $img[1] < $this->vars['pic_height'] ){
                            continue;
                        }
                    }
                    $_G['forum']['disablewatermark'] = true;
                    $_G['boan_watermask']['drawattachs'][$attach['aid']] = $attach;
                 
                }
            }
        }
    }
    
    
    function check_allow(){
        global $_G;
     
        $_G['uid'] = intval($_POST['uid']);
        
        if($_G['uid']) {
            $_G['member'] = getuserbyuid($_G['uid']);
        }
        
        $_G['groupid'] = $_G['member']['groupid'];
        if((empty($_G['uid']) && $_GET['operation'] != 'upload') || $_POST['hash'] != md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid'])) {
            return 0;
        }
        if(strpos($_GET['type'], 'image') === FALSE){
            return 0;
        }
        if($this->vars['pic_width'] || $this->vars['pic_height']){
            $img = getimagesize($_FILES['Filedata']['tmp_name']);
            if($this->vars['pic_width'] && $img[0] < $this->vars['pic_width'] || $this->vars['pic_height'] && $img[1] < $this->vars['pic_height'] ){
                return 0;
            }
        }
        if($_GET['operation'] == 'portal' && $this->vars['is_portal'] || $_GET['operation'] == 'album' && $this->vars['is_album']){
           return 1;
        }
        
        return 0;
    }
}

class plugin_boan_watermask_forum extends plugin_boan_watermask{
    
    function post_boan_watermask(){
        global $_G;
        
        if(!empty($_G['boan_watermask']['drawattachs'])){
            $flag = 1;
            if(!empty($_G['BOAN_OSSCONFIG'])){
                $exclude = dunserialize($_G['BOAN_OSSCONFIG']['oss_exclude_forums']);
                if(in_array($_G['fid'], $exclude)){
                    $flag = 0;
                }
                if(!$_G['BOAN_OSSCONFIG']['oss_img']){
                    $flag = 0;
                }
            }
            $flag && spl_autoload_register('boan_watermask_autoload',false,true);
        }
    }
    
    function post_btn_extra(){
        global $_G;
        
        if(in_array($_G['fid'], $this->vars['allow_forums']) && in_array($_G['groupid'], $this->vars['allow_groups'])
            && (in_array($_G['fid'], $this->vars['set_forums']) || in_array($_G['groupid'], $this->vars['set_groups']))
            ){
                return '<label><input type="checkbox" name="boanwatermask_tile" style="margin:0px 5px;" id="boanwatermask_tile" value="true" class="pc" checked="checked">'.lang(BOAN_WATERMASK_NAME, '平铺水印').'</label>'
                    .'<label><input type="checkbox" name="boanwatermask_text" style="margin:0px 5px;" id="boanwatermask_text" value="true" class="pc" checked="checked">'.lang(BOAN_WATERMASK_NAME, '文字水印').'</label>'
                    .'<label><input type="checkbox" name="boanwatermask_logo" style="margin:0px 5px;" id="boanwatermask_logo" value="true" class="pc" checked="checked">'.lang(BOAN_WATERMASK_NAME, 'LOGO水印').'</label>';
                ;
        }
        return '';
        
    }
    
    function post_boan_watermask_message($params){
        global $_G,$post;
        if(!empty($_G['boan_watermask']['drawattachs']) || !empty($_G['boan_watermask']['noattach'])){
            $uid = $_G['uid'];
      
            $paratext = array(
                'username' => $_G['thread']['author'] && $this->vars['is_first_user'] ? $_G['thread']['author'] : $_G['username'],
                'threadid' => $params['param'][2]['tid'],
                'threadtitle' => $_G['thread']['subject'] ? $_G['thread']['subject'] : $_GET['subject'],
                'dateline' => $_G['timenow']['time'], 
            );
            foreach ($_G['boan_watermask']['drawattachs'] as $attach){
                 $filename = $_G['setting']['attachdir'].'/forum/'.$attach['attachment'];
                 $filesize = 0;
                 $filesize = drawWater($filename,$paratext);
                 if($filesize){
                     C::t('forum_attachment_n')->update('aid:'.$attach['aid'],$attach['aid'],array('filesize' => $filesize));
                 }
            }
            
            if(!empty($_G['boan_watermask']['noattach'])){
                $attach = $_G['boan_watermask']['noattach'];
                $filename = $_G['setting']['attachdir'].'/forum/'.$attach['attachment'];
                @rename($attach['tempfile'], $filename);
                
                ftpcmd('upload','forum/'.$attach['attachment']);
                @unlink($filename);
            }
        }
    }
}

class plugin_boan_watermask_misc extends plugin_boan_watermask{
    function swfupload_boan_watermask(){
        global $_G;
        if($this->check_allow()){
            if($_GET['operation'] == 'portal'){
                $_G['setting']['portalarticleimgthumbclosed'] = 1;
                drawWater($_FILES['Filedata']['tmp_name'],array(),'portal');
            }else{
                drawWater($_FILES['Filedata']['tmp_name'],array(),'album');
            }
        }
    }
}

function boan_watermask_autoload($class){
    global $_G;
    if($class == 'discuz_ftp'){
        $attach  = current($_G['boan_watermask']['drawattachs']);
        if(!empty($attach)){
            $attach = C::t('forum_attachment_n')->fetch('aid:'.$attach['aid'],$attach['aid']);
            
            $uid = $_G['uid'];
            if(empty($_G['cache']['plugin'])){
                loadcache('plugin');
            }
            $vars = $_G['cache']['plugin']['boan_watermask'];
            $vars['is_first_user'] = intval($vars['is_first_user']);
            
            $vars['allow_forums'] = unserialize($vars['allow_forums']);
            $vars['allow_groups'] = unserialize($vars['allow_groups']);
            $vars['set_forums'] = unserialize($vars['set_forums']);
            $vars['set_groups'] = unserialize($vars['set_groups']);
            
            
            $drawtext = $drawtile = $drawlogo = true;   
            if(in_array($_G['fid'], $vars['set_forums']) || in_array($_G['groupid'], $vars['set_groups'])){
                empty($_GET['boanwatermask_tile']) && ($drawtile = false);
                empty($_GET['boanwatermask_text']) && ($drawtext = false);
                empty($_GET['boanwatermask_logo']) && ($drawlogo = false);
            }
            
            $paratext = array(
                'username' => $_G['thread']['author'] && $vars['is_first_user'] ? $_G['thread']['author'] : $_G['username'],
                'threadid' => $attach['tid'],
                'threadtitle' => $_G['thread']['subject'] ? $_G['thread']['subject'] : $_GET['subject'],
                'dateline' => $_G['timenow']['time'], 
            );
            $noaid = 0;
            if(($_GET['action'] == 'newthread') && $_G['forum']['picstyle'] && empty($thumb) && (intval($_G['setting']['forumpicstyle']['thumbheight']) || intval($_G['setting']['forumpicstyle']['thumbwidth']))){
                $attach = C::t('forum_attachment_n')->fetch_max_image('pid:'.$attach['pid'], 'pid', $attach['pid']);
                $_G['boan_watermask']['noattach'] = $attach;
                $noaid = $attach['aid'];
            }
            
            foreach ($_G['boan_watermask']['drawattachs'] as $attach){
               
                $filename = $_G['setting']['attachdir'].'/forum/'.$attach['attachment'];
                
                if($attach['aid'] == $noaid){
                    $tempfile = tempnam($_G['setting']['attachdir'].'./temp/', 'tmpimg_');
                    $_G['boan_watermask']['noattach']['tempfile'] = $tempfile;
                    @copy($filename, $tempfile);
                    $filename = $tempfile;
                }
             
                $filesize = 0;
                $filesize = drawWater($filename,$paratext,'forum',$drawtile,$drawtext,$drawlogo);
                if($filesize){
                    C::t('forum_attachment_n')->update('aid:'.$attach['aid'],$attach['aid'],array('filesize' => $filesize));
                }
            }
            $_G['boan_watermask']['drawattachs'] = NULL;
        }
    }
}

class mobileplugin_boan_watermask extends plugin_boan_watermask{
    function common() {
        if($this->vars['is_mobile']){
            parent::common();
        }
       
    }
}


class mobileplugin_boan_watermask_forum extends mobileplugin_boan_watermask{
    function post_boan_watermask(){
        global $_G;
        
        if(!empty($_G['boan_watermask']['drawattachs']) && $this->vars['is_mobile']){
            $flag = 1;
            if(!empty($_G['BOAN_OSSCONFIG'])){
                $exclude = dunserialize($_G['BOAN_OSSCONFIG']['oss_exclude_forums']);
                if(in_array($_G['fid'], $exclude)){
                    $flag = 0;
                }
                if(!$_G['BOAN_OSSCONFIG']['oss_img']){
                    $flag = 0;
                }
            }
            $flag && spl_autoload_register('boan_watermask_autoload',false,true);
        }
    }
    
    
    function post_boan_watermask_message($params){
        global $_G;
        
        if((!empty($_G['boan_watermask']['drawattachs']) || !empty($_G['boan_watermask']['noattach'])) && ($this->vars['is_mobile'])){
            $uid = $_G['uid'];

            $drawtext = $drawtile = $drawlogo = true;            
            if(in_array($_G['fid'], $this->vars['set_forums']) || in_array($_G['groupid'], $this->vars['set_groups'])){
                empty($_GET['boanwatermask_tile']) && ($drawtile = false);
                empty($_GET['boanwatermask_text']) && ($drawtext = false);
                empty($_GET['boanwatermask_logo']) && ($drawlogo = false);
            }
            $paratext = array(
                'username' => $_G['thread']['author'] && $this->vars['is_first_user'] ? $_G['thread']['author'] : $_G['username'],
                'threadid' => $params['param'][2]['tid'],
                'threadtitle' => $_G['thread']['subject'] ? $_G['thread']['subject'] : $_GET['subject'],
                'dateline' => $_G['timenow']['time'], 
            );
            foreach ($_G['boan_watermask']['drawattachs'] as $attach){
                $filename = $_G['setting']['attachdir'].'/forum/'.$attach['attachment'];
                $filesize = 0;
                $filesize = drawWater($filename,$paratext,'forum',$drawtile,$drawtext,$drawlogo);
                if($filesize){
                    C::t('forum_attachment_n')->update('aid:'.$attach['aid'],$attach['aid'],array('filesize' => $filesize));
                }
            }
            
            if(!empty($_G['boan_watermask']['noattach'])){
                $attach = $_G['boan_watermask']['noattach'];
                $filename = $_G['setting']['attachdir'].'/forum/'.$attach['attachment'];
                @rename($attach['tempfile'], $filename);
                
                ftpcmd('upload','forum/'.$attach['attachment']);
                @unlink($filename);
            }
        }
    }
}




function drawWater($filename,$textpara = array(),$target = 'forum',$drawtile = true,$drawtext = true,$drawlogo = true){
    global $_G;
    require_once DISCUZ_ROOT.'./source/plugin/boan_watermask/watermask.inc.php';
   
    
    if(empty($_G['cache']['plugin'])){
        loadcache('plugin');
    }
    $vars = $_G['cache']['plugin']['boan_watermask'];
    
    if($target == 'forum'){
        loadcache('boan_watermask',true);
        $cache = $_G['cache']['boan_watermask'];
        
        
        
    }elseif($target == 'portal'){
        loadcache('boan_portal_watermask',true);
        $cache = $_G['cache']['boan_portal_watermask'];
    }else{
        loadcache('boan_album_watermask',true);
        $cache = $_G['cache']['boan_album_watermask'];
    }
 
    
    $options = array('width' => intval($cache['waterW']),
        'height' => intval($cache['waterH']),
        'angle' => intval($cache['waterA']),
        'opacity' => intval($cache['waterO']),
        
    );
    $water = DISCUZ_ROOT.'./source/plugin/boan_watermask/images/t_water.png';
    if(file_exists(DISCUZ_ROOT.'./source/plugin/boan_watermask/images/water.png')){
        $water = DISCUZ_ROOT.'./source/plugin/boan_watermask/images/water.png';
    }
    
    $textoptions = array('text'=>trim($cache['watertextstyle']),
        'file'=>DISCUZ_ROOT.'./source/plugin/boan_watermask/font/'.$cache['watertextfile'],
        'color'=>trim($cache['watertextcolor']),
        'size'=>$cache['watertextsize'],
        'opacity'=>$cache['watertextO'],
        'pos' => $cache['watertextpos'],
        'angle' => $cache['watertextA'],
        'x_pos' => $cache['watertextHO'],
        'y_pos' =>  $cache['watertextVO'],
        'shadowx' => $cache['watertextHS'],
        'shadowy' =>$cache['watertextVS'],
        'shadowcolor' => trim($cache['watertextSC']),
        'para' => $textpara,
    );
   
    
    if($vars['text_pos']){
        $text_pos = explode(',',$vars['text_pos']);
        $r = rand(0,count($text_pos));
        $textoptions['pos'] = $text_pos[$r] ;
    }
    
    $logooptions = array('file' => DISCUZ_ROOT.'./source/plugin/boan_watermask/images/logo.png',
        'opacity' => intval($cache['waterlogoO']),
        'pos' => intval($cache['waterlogopos']),
        'x_pos' => intval($cache['waterlogoHO']),
        'y_pos' => intval($cache['waterlogoHO']),
    );
    if(!$cache['waterlogoallow'] || !$drawlogo){
        $logooptions = array();
    }
    
    if(!$cache['waterscreenallow'] || !$drawtile){
        $water = '';
    }
    
    if(!$drawtext){
        $textoptions['text'] = '';
    }
    
    return full_screen($water,
        $filename,'',
        $options,$textoptions,$logooptions);
}




