<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/boan_watermask/watermask.inc.php';

$options = array('width' => intval($_GET['width']),
                 'height' => intval($_GET['height']),
                 'angle' => intval($_GET['angle']),
                 'opacity' => intval($_GET['opacity']),
                 
);
$water = DISCUZ_ROOT.'./source/plugin/boan_watermask/images/t_water.png';
if(file_exists(DISCUZ_ROOT.'./source/plugin/boan_watermask/images/water.png')){
    $water = DISCUZ_ROOT.'./source/plugin/boan_watermask/images/water.png';
}

$textoptions = array('text'=>trim($_GET['watertextstyle']),
    'file'=>DISCUZ_ROOT.'./source/plugin/boan_watermask/font/'.$_GET['watertextfile'],
    'color'=>trim($_GET['watertextcolor']),
    'size'=>$_GET['watertextsize'],
    'opacity'=>$_GET['watertextO'], 
    'pos' => $_GET['watertextpos'],
    'angle' => $_GET['watertextA'],
    'x_pos' => $_GET['watertextHO'],
    'y_pos' =>  $_GET['watertextVO'],
    'shadowx' => $_GET['watertextHS'],
    'shadowy' => $_GET['watertextVS'],
    'shadowcolor' => trim($_GET['watertextSC']),
    'para' => array('username'=>'admin',
                    'threadtitle' => 'subject',
                    'threadid' => '666666',
        'dateline' => date("Y-m-d H:i",time())),
);

$url .= "&waterlogoO={$_GET['waterlogoO']}&waterlogopos={$_GET['waterlogopos']}&waterlogoHO={$_GET['waterlogoHO']}&waterlogoVO={$_GET['waterlogoVO']}";
$logooptions = array('file' => DISCUZ_ROOT.'./source/plugin/boan_watermask/images/logo.png',
    'opacity' => intval($_GET['waterlogoO']),
    'pos' => intval($_GET['waterlogopos']),
    'x_pos' => intval($_GET['waterlogoHO']),
    'y_pos' => intval($_GET['waterlogoVO']),
);
if(!$_GET['waterlogoallow']){
    $logooptions = array();
}
if(!$_GET['waterscreenallow']){
    $water = '';
}
full_screen($water,
            DISCUZ_ROOT.'./source/plugin/boan_watermask/images/test.jpg','',
    $options,$textoptions,$logooptions,true);
