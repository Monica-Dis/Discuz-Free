<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
define('BOAN_WATERMASK_NAME', 'plugin/boan_watermask');
global $_G;
if(empty($_G['cache']['plugin'])){
    loadcache('plugin');
}
$vars = $_G['cache']['plugin']['boan_album_watermask'];

if($_GET['pmod'] == 'album_watermask'){
    if(!submitcheck('water_submit')){
        loadcache('boan_album_watermask',true);
        $cache = $_G['cache']['boan_album_watermask'];
        if(!$_G['cache']['boan_album_watermask']){
            $cache = array(
                'waterscreenallow' => 1,
                'waterW' => 0,
                'waterH' => 0,
                'waterA' => 0,
                'waterO' => 0,
                'watertextstyle' => 'sitename:{sitename}{n}sitedomin:{sitedomin}',
                'watertextfile' => 0,
                'watertextsize' => '24',
                'watertextcolor' => '#FFFFFF',
                'watertextO' => 10,
                'watertextA' => 0,
                'watertextpos' => '0',
                'watertextHO' => 50,
                'watertextVO' => 50,
                'watertextHS' => 0,
                'watertextVS' => 0,
                'watertextSC' => '',
                'waterlogoallow' => 0,
                'waterlogoO' => 0,
                'waterlogopos' => 0,
                'waterlogoHO' => 0,
                'waterlogoVO' => 0,
            );
        }
        cpheader();
        showtips(lang(BOAN_WATERMASK_NAME, 'onekey_watermask_explain'));
        showformheader('plugins&operation=config&do='.$pluginid.'&pmod=album_watermask','enctype');
        showtableheader('','','',9);
        showtagheader('tbody', '',true);
        
        if(!file_exists(DISCUZ_ROOT.'./source/plugin/boan_watermask/images/water.png')){
            $waterF_comment =lang(BOAN_WATERMASK_NAME, 'set_watermask_waterF_comment2');
        }else{
            $waterF_comment =lang(BOAN_WATERMASK_NAME, 'set_watermask_waterF_comment1');
        }
        
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_waterscreenallow'), 'waterscreenallow',$cache['waterscreenallow'],'radio',0,0,'');
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_waterF'), 'waterF','','file',0,0,$waterF_comment);
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_waterW'), 'waterW',  $cache['waterW'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_waterW_comment'));
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_waterH'), 'waterH',  $cache['waterH'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_waterH_comment'));
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_waterA'), 'waterA',  $cache['waterA'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_waterA_comment'));
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_waterO'), 'waterO',  $cache['waterO'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_waterO_comment'));
        
        $checkwm['text'] = array('','','','','','','','','');
        $checkwm['text'][$cache['watertextpos']] = 'checked';
        
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextpos'), '', '', '<table style="margin-bottom: 3px; margin-top:3px;"><tr><td><input class="radio" type="radio" name="watertextpos" value="0" '.$checkwm['text'][0].'> #1</td><td><input class="radio" type="radio" name="watertextpos" value="1" '.$checkwm['text'][1].'> #2</td><td><input class="radio" type="radio" name="watertextpos" value="2" '.$checkwm['text'][2].'> #3</td></tr><tr><td><input class="radio" type="radio" name="watertextpos" value="3" '.$checkwm['text'][3].'> #4</td><td><input class="radio" type="radio" name="watertextpos" value="4" '.$checkwm['text'][4].'> #5</td><td><input class="radio" type="radio" name="watertextpos" value="5" '.$checkwm['text'][5].'> #6</td></tr><tr><td><input class="radio" type="radio" name="watertextpos" value="6" '.$checkwm['text'][6].'> #7</td><td><input class="radio" type="radio" name="watertextpos" value="7" '.$checkwm['text'][7].'> #8</td><td><input class="radio" type="radio" name="watertextpos" value="8" '.$checkwm['text'][8].'> #9</td></tr></table>');
        
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextstyle'), 'watertextstyle',  $cache['watertextstyle'],'textarea',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextstyle_comment'));
        
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_waterFontFile'), 'waterFontFile','','file',0,0,lang(BOAN_WATERMASK_NAME,'set_watermask_waterFontFile_comment'));
        
        
        $arr = array();
        $dir = opendir(DISCUZ_ROOT.'./source/plugin/boan_watermask/font');
        while(false !== ($file = readdir($dir))){
            if($file == '.' || $file == '..'){
                continue;
            }
            if(!is_dir($file)){
                $arr[] = array($file,$file);
            }
        }
        closedir($dir);
        
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextfile'),
            array('watertextfile',
                $arr),
            $cache['watertextfile'],'select',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextfile_comment')
            );
        
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextsize'), 'watertextsize',  $cache['watertextsize'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextsize_comment'));
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextcolor'), 'watertextcolor',  $cache['watertextcolor'],'color',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextcolor_comment'));
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextO'), 'watertextO',  $cache['watertextO'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextO_comment'));
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextA'), 'watertextA',  $cache['watertextA'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextA_comment'));
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextHO'), 'watertextHO',  $cache['watertextHO'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextHO_comment'));
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextVO'), 'watertextVO',  $cache['watertextVO'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextVO_comment'));
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextHS'), 'watertextHS',  $cache['watertextHS'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextHS_comment'));
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextVS'), 'watertextVS',  $cache['watertextVS'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextVS_comment'));
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextSC_comment'), 'watertextSC',  $cache['watertextSC'],'color',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_watertextSC_comment'));
        
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_waterlogoallow'), 'waterlogoallow',$cache['waterlogoallow'],'radio',0,0,'');
        
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_waterLogoFile'), 'waterLogoFile','','file',0,0,'');
        
        $checkwm['logo'] = array('','','','','','','','','');
        $checkwm['logo'][$cache['waterlogopos']] = 'checked';
        
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_waterlogopos'), '', '', '<table style="margin-bottom: 3px; margin-top:3px;"><tr><td><input class="radio" type="radio" name="waterlogopos" value="0" '.$checkwm['logo'][0].'> #1</td><td><input class="radio" type="radio" name="waterlogopos" value="1" '.$checkwm['logo'][1].'> #2</td><td><input class="radio" type="radio" name="waterlogopos" value="2" '.$checkwm['logo'][2].'> #3</td></tr><tr><td><input class="radio" type="radio" name="waterlogopos" value="3" '.$checkwm['logo'][3].'> #4</td><td><input class="radio" type="radio" name="waterlogopos" value="4" '.$checkwm['logo'][4].'> #5</td><td><input class="radio" type="radio" name="waterlogopos" value="5" '.$checkwm['logo'][5].'> #6</td></tr><tr><td><input class="radio" type="radio" name="waterlogopos" value="6" '.$checkwm['logo'][6].'> #7</td><td><input class="radio" type="radio" name="waterlogopos" value="7" '.$checkwm['logo'][7].'> #8</td><td><input class="radio" type="radio" name="waterlogopos" value="8" '.$checkwm['logo'][8].'> #9</td></tr></table>');
        
        
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_waterlogoHO'), 'waterlogoHO',  $cache['waterlogoHO'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_waterlogoHO_comment'));
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_waterlogoVO'), 'waterlogoVO',  $cache['waterlogoVO'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_waterlogoVO_comment'));
        
        showsetting(lang(BOAN_WATERMASK_NAME, 'set_watermask_waterlogoO'), 'waterlogoO',$cache['waterlogoO'],'number',0,0,lang(BOAN_WATERMASK_NAME, 'set_watermask_waterlogoO_comment'));
        
        showtagfooter('tbody');
        showtablefooter(); /*dism��taobao��com*/
        showsubmit('water_submit');
        showformfooter(); /*Dism_taobao-com*/
    }else{
        saveconfig();
        
        $backurl = 'action=plugins&operation=config&do='.$pluginid.'&pmod=album_watermask';
        $backurl = preg_match('/^https?:\/\//is', $backurl) ? $backurl : ADMINSCRIPT.'?'.$backurl;
        
        $_GET['watertextstyle'] = urlencode($_GET['watertextstyle']);
        $_GET['watertextfile'] = urlencode($_GET['watertextfile']);
        $_GET['watertextcolor'] = urlencode($_GET['watertextcolor']);
        $_GET['watertextSC'] = urlencode($_GET['watertextSC']);
        
        $url = "plugin.php?id=boan_watermask:preview&width={$_GET['waterW']}&height={$_GET['waterH']}&angle={$_GET['waterA']}&opacity={$_GET['waterO']}&watertextstyle={$_GET['watertextstyle']}
        &watertextfile={$_GET['watertextfile']}&watertextcolor={$_GET['watertextcolor']}&watertextsize={$_GET['watertextsize']}&watertextO={$_GET['watertextO']}&watertextpos={$_GET['watertextpos']}
        &watertextHO={$_GET['watertextHO']}&watertextVO={$_GET['watertextVO']}&watertextA={$_GET['watertextA']}&watertextHS={$_GET['watertextHS']}&watertextVS={$_GET['watertextVS']}&watertextSC= {$_GET['watertextSC']}
        &waterscreenallow={$_GET['waterscreenallow']}";
        
        
        if(intval($_GET['waterlogoallow'])){
            $url .= "&waterlogoallow={$_GET['waterlogoallow']}&waterlogoO={$_GET['waterlogoO']}&waterlogopos={$_GET['waterlogopos']}&waterlogoHO={$_GET['waterlogoHO']}&waterlogoVO={$_GET['waterlogoVO']}";
        }
        
        echo <<<EOF
            <style>
                .y {float: right;}
                .zoominner { padding: 5px 10px 10px; background:#FFF; text-align: left; }
		.zoominner p { padding: 8px 0; }
			.zoominner p a { float: left; margin-left: 10px; width: 17px; height: 17px; background: url(source/plugin/boan_watermask/images/imgzoom_tb.gif) no-repeat 0 0; line-height: 100px; overflow: hidden; }
				.zoominner p a:hover { background-position: 0 -39px; }
			.zoominner p a.imgadjust { background-position: -40px 0; }
				.zoominner p a.imgadjust:hover { background-position: -40px -39px; }
			.zoominner p a.imgclose { background-position: -80px 0; }
				.zoominner p a.imgclose:hover { background-position: -80px -39px; }
            
.zimg_c { position: relative; }
.zimg_prev, .zimg_next { display: block; position: absolute; width: 80px; height: 100%; background: url({IMGDIR}/pic-prev.png) no-repeat 0 -100px; cursor: pointer; }
.zimg_next { right: 10px; background-image: url({IMGDIR}/pic-next.png); background-position: 100% -100px; }
.zimg_c img { margin: 0 auto; }
.zimg_p strong { display: none; }
            </style>
EOF;
        echo "<img id=\"imgtest\" src=\"$url\" zoomfile=\"$url\" file=\"$url\" class=\"zoom\" style=\"display:none;\"><script>zoom($('imgtest'),$('imgtest').src,0,0,0); setTimeout(function(e){
        _attachEvent(document.getElementsByClassName('imgclose')[0],'click',function(e){window.location.href='$backurl';});
    },200);</script>";
        
    }
}



function saveconfig(){
    global $_G;
    
    if(isset($_FILES['waterF']) && $_FILES['waterF']['error'] == UPLOAD_ERR_OK  && file_exists($_FILES['waterF']['tmp_name']) && $_FILES['waterF']['size'] >0 ){
        $imageinfo = @getimagesize($_FILES['waterF']['tmp_name']);
        if($imageinfo){
            @move_uploaded_file($_FILES['waterF']['tmp_name'], DISCUZ_ROOT.'./source/plugin/boan_watermask/images/water.png');
        }else{
            @unlink($_FILES['waterF']['tmp_name']);
        }
        
    }
    
    if(isset($_FILES['waterLogoFile']) && $_FILES['waterLogoFile']['error'] == UPLOAD_ERR_OK  && file_exists($_FILES['waterLogoFile']['tmp_name']) && $_FILES['waterLogoFile']['size'] >0 ){
        $imageinfo = @getimagesize($_FILES['waterLogoFile']['tmp_name']);
        if($imageinfo){
            @move_uploaded_file($_FILES['waterLogoFile']['tmp_name'], DISCUZ_ROOT.'./source/plugin/boan_watermask/images/logo.png');
        }else{
            @unlink($_FILES['waterLogoFile']['tmp_name']);
        }
        
    }
    
    if(isset($_FILES['waterFontFile']) && $_FILES['waterFontFile']['error'] == UPLOAD_ERR_OK  && file_exists($_FILES['waterFontFile']['tmp_name']) && $_FILES['waterFontFile']['size'] >0 ){
        @move_uploaded_file($_FILES['waterFontFile']['tmp_name'], DISCUZ_ROOT.'./source/plugin/boan_watermask/font/'.$_FILES['waterFontFile']['name']);
        @unlink($_FILES['waterFontFile']['tmp_name']);
    }
    
    loadcache('boan_album_watermask',true);
    $cache = $_G['cache']['boan_album_watermask'];
    if(!isset($cache) || !is_array($cache)){
        $cache = array();
    }
    
    $cache1 = array(
        'waterscreenallow' => $_GET['waterscreenallow'],
        'waterW' => $_GET['waterW'],
        'waterH' => $_GET['waterH'],
        'waterA' => $_GET['waterA'],
        'waterO' => $_GET['waterO'],
        'watertextstyle' => $_GET['watertextstyle'],
        'watertextfile' => $_GET['watertextfile'],
        'watertextsize' => $_GET['watertextsize'],
        'watertextcolor' => $_GET['watertextcolor'],
        'watertextpos' => intval($_GET['watertextpos']),
        'watertextA' => intval($_GET['watertextA']),
        'watertextHS' => intval($_GET['watertextHS']),
        'watertextVS' => intval($_GET['watertextVS']),
        'watertextSC' => $_GET['watertextSC'],
        'watertextO' => intval($_GET['watertextO']),
        'watertextHO' => intval($_GET['watertextHO']),
        'watertextVO' => intval($_GET['watertextVO']),
        
        'waterlogoallow' => intval($_GET['waterlogoallow']),
        'waterlogoO' => intval($_GET['waterlogoO']),
        'waterlogopos' => intval($_GET['waterlogopos']),
        'waterlogoHO' => intval($_GET['waterlogoHO']),
        'waterlogoVO' => intval($_GET['waterlogoVO']),
        
    );
    $cache = array_merge($cache,$cache1);
    savecache('boan_album_watermask',$cache);
}

