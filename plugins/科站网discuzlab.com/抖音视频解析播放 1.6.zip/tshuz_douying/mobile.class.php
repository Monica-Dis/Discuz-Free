<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: mobile.class.php 2018-06-08 10:54:24Z Dism·taobao·com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */
class mobileplugin_tshuz_douying{
	function discuzcode($value){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_douying'];
		$forums = dunserialize($pvars['forums']);
		if(!in_array($_G['fid'],$forums) && $_G['tid']) return '';
		if($value['caller'] == 'discuzcode'){
			if(strpos($_G['discuzcodemessage'],"[/douyin]") !== false){
				$_G['discuzcodemessage'] = preg_replace(
					'/\[douyin\](.*?)\[\/douyin\]/',
					'<video class="tshuz_douying" data-src="\1" style="width:100%;height:'.$pvars['mobile'].'px;" controls="controls" ></video>',
					$_G['discuzcodemessage']
				);
				$_G['discuzcodemessage'] .= '<script>$("head").append(\'<meta name="referrer" content="no-referrer">\');$(function(){$(".tshuz_douying").each(function(){var w =$(this);$.get("plugin.php?id=tshuz_douying&url="+encodeURIComponent($(this).attr("data-src")),function(data,status){w.attr("src",data);});})})</script>';
			}
		}
	}
}
class mobileplugin_tshuz_douying_forum {
	function post_bottom_mobile(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_douying'];
		if(!in_array($_G['fid'],unserialize($pvars['forums'])) || !in_array($_G['groupid'],unserialize($pvars['groups']))) return '';
		return '<a href="plugin.php?id=tshuz_douying&mod=show" class="dialog" style="background:#000;color:#fff; width:90%; display:block; margin:10px auto; text-align:center; padding:10px 0; font-size:14px; border-radius:3px;">'.lang('plugin/tshuz_douying','W1RdaZ').'</a>';
	}
}
