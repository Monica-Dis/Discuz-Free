<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$pvars = $_G['cache']['plugin']['tshuz_douying'];
if($_GET['mod'] == 'show' && defined('IN_MOBILE')){
	include template('tshuz_douying:show');
	exit;
}
if(!$_GET['url']) showmsg($pvars['error']);
$url = addslashes($_GET['url']);

if($pvars['type'] == 2 && $apiFile = libfile('function/core','plugin/dzlab_api')){
	include $apiFile;
	$result = sendData(array('aid'=>7,'url'=>$url));
	showmsg($result['result']?$result['result']:$pvars['error']);exit;
}
if(strpos($url,'share/video') === false){
	$data = httpGet($url);
	preg_match('/href=\"(.*?)\"/',$data,$m);
	if(!$m[1]) showmsg($pvars['error']);
	$url = $m[1];
}
$data = httpGet($url);;
if(strtolower($_G['charset']) != 'utf-8'){
	$data = mb_convert_encoding($data,$_G['charset'],'utf-8');
}
preg_match('/playAddr: \"(.*?)\"/',$data,$m);
if(!$m[1]) showmsg($pvars['error']);
showmsg($m[1]);exit;
function httpGet($url)
{
	$user_agent = 'Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0';
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
	curl_setopt($ch, CURLOPT_URL, $url);
	$output = curl_exec($ch);
	curl_close($ch);
	return $output;
}

function showmsg($msg){
	echo $msg;exit;
}