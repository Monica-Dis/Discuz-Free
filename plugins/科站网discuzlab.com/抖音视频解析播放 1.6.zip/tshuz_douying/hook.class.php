<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: hook.class.php 2018-06-08 10:54:18Z Dism·taobao·com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */
class plugin_tshuz_douying{
	function discuzcode($value){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_douying'];
		$forums = dunserialize($pvars['forums']);
		if(!in_array($_G['fid'],$forums) && $_G['tid']) return '';
		list($width,$height) = explode('|',$pvars['pc']);
		if($value['caller'] == 'discuzcode'){
			if(strpos($_G['discuzcodemessage'],"[/douyin]") !== false){
				$_G['discuzcodemessage'] = preg_replace(
					'/\[douyin\](.*?)\[\/douyin\]/',
					'<video class="tshuz_douying" data-src="\1" style="width:'.$width.'px;height:'.$height.'px; background:#000;" controls="controls" ></video>',
					$_G['discuzcodemessage']
				);
				$_G['discuzcodemessage'] .= '<script src="source/plugin/tshuz_douying/jquery.min.js" type="text/javascript"></script><script>var jq=$.noConflict();jq("head").append(\'<meta name="referrer" content="no-referrer">\');jq(function(){jq(".tshuz_douying").each(function(){var w =jq(this);jq.get("plugin.php?id=tshuz_douying&url="+encodeURIComponent(jq(this).attr("data-src")),function(data,status){w.attr("src",data);});})})</script>';
			}
		}
	}
}
class plugin_tshuz_douying_forum {
	function post_editorctrl_left(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_douying'];
		$forums = dunserialize($pvars['forums']);
		$groups = dunserialize($pvars['groups']);
		if(!in_array($_G['fid'],$forums) || !in_array($_G['groupid'],$groups) ) return '';
		include template('tshuz_douying:post_editorctrl_left');
		return $return;
	}
}
