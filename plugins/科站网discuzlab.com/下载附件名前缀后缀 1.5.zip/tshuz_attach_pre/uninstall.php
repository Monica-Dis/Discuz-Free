<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!function_exists('cloudaddons_deltree')) require libfile('function/cloudaddons');
cloudaddons_deltree(DISCUZ_ROOT .'./source/plugin/tshuz_attach_pre/');
$finish = true;