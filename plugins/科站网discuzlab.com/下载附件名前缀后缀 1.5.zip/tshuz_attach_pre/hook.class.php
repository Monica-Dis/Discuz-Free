<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class plugin_tshuz_attach_pre_forum {
	function attachment(){
		global $_G;
		//插件设置
		$config = $_G['cache']['plugin']['tshuz_attach_pre'];
		$forums = unserialize($config['forums']);//启用版块
		$groups = unserialize($config['groups']);//启用用户组
		$pres 	= explode("\r\n",$config['pre']);//前缀
		$sufs	= explode("\r\n",$config['suf']);//后缀
		
		//引用文件
		if(in_array($_G['groupid'],$groups)){
			include_once DISCUZ_ROOT.'/source/plugin/tshuz_attach_pre/module/forum_attachment.php';
		}
		return '';
	}
	private function ruler($domain , $position , $pres , $sufs , $rand) {
		//随机显示前缀后缀
		$random1 = mt_rand(0,count($pres)-1);
		$random2 = mt_rand(0,count($sufs)-1);
		//前缀后缀
		$pre = $pres[$random1];
		$suf = $sufs[$random2];
		//位置判断显示
		if($position){//显示域名
			if($rand){//随机大小写
				$domain = $this->domain($domain);
			}
			switch($position){
				case 1: return $domain.$pre.'{attachname}'.$suf;break;
				case 2: return $pre.$domain.'{attachname}'.$suf;break;
				case 3: return $pre.'{attachname}'.$domain.$suf;break;
				case 4: return $pre.'{attachname}'.$suf.$domain;break;
			}
		}else{//不显示域名
			return $pre.'{attachname}'.$suf;
		}
	}
	private function domain($domain){
		$domainArray = str_split($domain, 1);
		foreach ($domainArray as $str) {
			$rand = mt_rand(0, 1);
			if ($rand) {
				$new[] = strtoupper($str);
			} else {
				$new[] = strtolower($str);
			}
		}
		$newDomain = implode("", $new);
		return $newDomain;
	}
}

class mobileplugin_tshuz_attach_pre_forum extends plugin_tshuz_attach_pre_forum {}