<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$groupid =  $_G{'groupid'};//当前用户组ID
$files = dintval($_GET['file'],1);
$tid = intval(addslashes($_GET['tid']));
$tableid = substr($tid,-1);
$splugin_setting = $_G['cache']['plugin']['tshuz_batchdownload'];
$forums_setting=$splugin_setting['group'];
$setting = unserialize($forums_setting);

$attachs = C::t('forum_attachment_n')->fetch_all($tableid,$files);
foreach($files as $aid){
	$attach = $attachs[$aid];
	if($attach['price']>0 && !(in_array($groupid,$setting))){
		
	}else{
		$attachment[] = $attach;
	}
}

foreach($attachment as $file){
	$fileNameArr[] = $_G['setting']['attachdir']."forum/".$file['attachment'];
}
$filename = "./source/plugin/tshuz_batchdownload/".date('YmdH')."_uid_".$_G['uid'].".zip"; 
$zip = new ZipArchive (); // 使用本类，linux需开启zlib，windows需取消php_zip.dll前的注释
if ($zip->open ($filename, ZIPARCHIVE::CREATE ) !== TRUE) {
    exit;
}

foreach ($attachment as $val ) {
    $zip->addFile ($_G['setting']['attachdir']."forum/".$val['attachment'], $val['filename']);
}
$zip->close (); 
header ( "Cache-Control: max-age=0" );
header ( "Content-Description: File Transfer" );
header ( 'Content-disposition: attachment; filename=' . basename ( $filename ) ); 
header ( "Content-Type: application/zip" ); 
header ( "Content-Transfer-Encoding: binary" ); 
header ( 'Content-Length: ' . filesize ( $filename ) ); 
@readfile ( $filename );
unlink($filename);