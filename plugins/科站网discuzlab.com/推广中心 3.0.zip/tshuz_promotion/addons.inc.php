<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: addons.inc.php 2019-11-01 14:01:45Z Todd $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* RKaKzG */

?><script type="text/javascript">location.href="https://addon.dismall.com/?@838.developer";</script>