<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_tshuz_famous {
	public $return=array();
	public $cacheFile = '';
	function global_tshuz_famous() {
		global $_G;
		require_once libfile('function/cache');
		$vars = $_G['cache']['plugin']['tshuz_famous'];
		$this->cacheFile = DISCUZ_ROOT.'./data/sysdata/cache_tshuz_famous.php';
		if (!file_exists($this->cacheFile)) {
			$this->get_top_rank();
		}
		if(($_G['timestamp']-@filemtime($this->cacheFile)) > ($vars['rate']*86400)){
			$this->get_top_rank();
		}
	}
	function get_top_rank(){
		global $_G;
		$vars = $_G['cache']['plugin']['tshuz_famous'];
		$terms = explode("\r\n",$vars['term']);
		$array = array('extcredits1','extcredits2','extcredits3','extcredits4','extcredits5','extcredits6','extcredits7','extcredits8','friends','posts','threads','digestposts','doings','blogs','albums','sharings','views','oltime','feeds','follower');
		$brray = array('>','<','=','>=','<=');
		foreach($terms as $term){
			$tmp = explode("|",$term);
			if(in_array($tmp[0],$array) && in_array($tmp[1],$brray)){
				$whereList[] = "c.".$tmp[0].$tmp[1].intval($tmp[2]);	
			}
		}
		$where = implode(" and ",$whereList);
		$groups = unserialize($vars['groups']);
		$groups = implode(",",array_filter($groups));
		if($groups != ''){
			$where .= " and m.groupid in (".$groups.")";
		}
		$this->return = array();
		$tablename1 = "common_member_count";
		$tablename2 = "common_member";
		$tablename3 = "plugin_tshuz_famous";
		foreach($array as $val){
			$crray[] = "c.".$val." as ".$val;	
		}
		$sql = "select m.uid as uid,m.groupid as groupid,m.username as username,m.credits as credits,".implode(",",$crray)." from ".DB::table($tablename1)." as c left join ".DB::table($tablename2)." as m on m.uid=c.uid left join ".DB::table($tablename3)." as p on m.uid=p.uid where ".$where." order by p.num desc, m.credits desc limit 0,10";
		$list = DB::fetch_all($sql);
		$this->return = $list;
		$this->tshuz_write_cache();
		return $this->return;
	}
	function tshuz_write_cache(){
		global $_G;
		$cacheArray .= "\$list=".arrayeval($this->return).";\n";
		writetocache('tshuz_famous', $cacheArray) ;
	}
	function tshuz_get_cache(){
		if(!file_exists($this->cacheFile))	return false;
		require $this->cacheFile;
		return $list;
	}
	public function get_uid_array(){
		$list = $this->tshuz_get_cache();
		foreach($list as $key=>$val){
			$uids[] = $val['uid'];	
		}
		return $uids;
	}
	
	function global_usernav_extra1(){
		global $_G;
		$vars = $_G['cache']['plugin']['tshuz_famous'];
		$list = $this->tshuz_get_cache();
		if(in_array($_G['uid'],$this->get_uid_array())){
			$key = array_keys($list,$_G['uid']);
			return '<span style="'.$vars['style'].'">No.'.$vars['pre'].($key[0]+1)."</span>";	
		}
	}
	
	
}
class plugin_tshuz_famous_forum extends plugin_tshuz_famous {
	function viewthread_sidetop_output(){
		global $_G,$postlist;
		$vars = $_G['cache']['plugin']['tshuz_famous'];
		include DISCUZ_ROOT.'./data/sysdata/cache_tshuz_famous.php';
		foreach($list as $key=>$val){
			$uids[] = $val['uid'];	
		}
		foreach($postlist as $key=>$val){
			if(in_array($val['authorid'],$uids)){
				$key = array_keys($uids,$val['authorid']);
				$return[] =  '<dl class="pil cl">
	<dt>'.lang('plugin/tshuz_famous','lang05').'</dt><dd><span style="'.$vars['style'].'">No.'.$vars['pre'].($key[0]+1)."</span></dd>
</dl>";	
			}else{
				$return[] = '';	
			}
		}
		return $return;
	}
	
	function viewthread_useraction(){
		global $_G;
		$vars = $_G['cache']['plugin']['tshuz_famous'];
		$return = '<script type="text/javascript">
		function firm(uid) {  
		var name = "'.$_G['setting']['extcredits'][$vars['ext']]['title'].'";
        if (confirm("'.lang('plugin/tshuz_famous','lang10').$vars['money'].lang('plugin/tshuz_famous','lang11').'"+name+"'.lang('plugin/tshuz_famous','lang12').'\r\n'.lang('plugin/tshuz_famous','lang13').'")) {  
            showWindow(\'tshuz_famous\', \'plugin.php?id=tshuz_famous:famous&uid=\'+uid+\'&hash='.FORMHASH.'\');
			return false;
        } 
    }  
</script><a href="javascript:;" onclick="firm('.$_G['thread']['authorid'].');"  title="'.lang('plugin/tshuz_famous','lang14').'" ><i><img src="source/plugin/tshuz_famous/vip.jpg" alt="'.lang('plugin/tshuz_famous','lang14').'">'.lang('plugin/tshuz_famous','lang15').'</i></a>';
		return $return;
	}
	
	function viewthread_postfooter_output(){
		global $_G,$postlist;
		foreach($postlist as $key=>$val){
			$return[] = '<a href="javascript:;" onclick="firm('.$val['authorid'].');" style="background:url(source/plugin/tshuz_famous/vip.jpg) no-repeat left 5px center !important;"  title="'.lang('plugin/tshuz_famous','lang14').'" >'.lang('plugin/tshuz_famous','lang15').'</a>';
		}
		return $return;
	}
	
	function forumdisplay_author_output(){
		global $_G;
		include DISCUZ_ROOT.'./data/sysdata/cache_tshuz_famous.php';
		foreach($list as $key=>$val){
			$uids[] = $val['uid'];	
		}
		foreach($_G['forum_threadlist'] as $key=>$thread){
			if(in_array($thread['authorid'],$uids)){
				$key = array_keys($uids,$val['authorid']);
				$return[] = '<cite class="z" style="margin-right:5px;"><img title="'.lang('plugin/tshuz_famous','lang16').'No.'.($key[0]+1).'" src="source/plugin/tshuz_famous/template/vip.jpg"></cite>';	
			}else{
				$return[] = '';
			}
		}
		return $return;
	}
	
}
class plugin_tshuz_famous_home extends plugin_tshuz_famous{
	function space_profile_baseinfo_top(){
		global $_G,$space;
		$uid = $_G['gp_uid'];
		$vars = $_G['cache']['plugin']['tshuz_famous'];
		include DISCUZ_ROOT.'./data/sysdata/cache_tshuz_famous.php';
		foreach($list as $key=>$val){
			$uids[] = $val['uid'];	
		}
		if(in_array($uid,$uids)){
			$key = array_keys($list,$uid);
			return lang('plugin/tshuz_famous','lang05').'No.'.$vars['pre'].($key[0]+1);	
		}
	}
}
//From: Dism_taobao_com
?>