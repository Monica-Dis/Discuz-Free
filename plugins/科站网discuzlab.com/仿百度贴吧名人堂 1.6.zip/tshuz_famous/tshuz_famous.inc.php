<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$vars = $_G['cache']['plugin']['tshuz_famous'];
$cacheFile = DISCUZ_ROOT.'./data/sysdata/cache_tshuz_famous.php';
if (!file_exists($cacheFile)) {
	showmessage(lang('plugin/tshuz_famous','lang36'),'',array(),array("alert"=>"error","msgtype"=>2,"closetime"=>3));	
}
include $cacheFile;
$navtitle = lang('plugin/tshuz_famous','lang37');
include template('tshuz_famous:tshuz_famous');

function getGroupInfo($groupId){
	$info = DB::fetch_first("select * from ".DB::table("common_usergroup")." where groupid=".intval($groupId));
	return $info;
}
//From: Dism_taobao_com
?>