<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$vars = $_G['cache']['plugin']['tshuz_famous'];
include DISCUZ_ROOT.'./data/sysdata/cache_tshuz_famous.php';
$hash = $_GET['hash'];
$uid = intval($_GET['uid']);
if($hash != FORMHASH || !$uid){
	showmessage(lang('plugin/tshuz_famous','lang01'),'',array(),array("alert"=>"error","msgtype"=>2,"closetime"=>3));			
}
if($uid == $_G['uid']){
	showmessage(lang('plugin/tshuz_famous','lang02'),'',array(),array("alert"=>"error","msgtype"=>2,"closetime"=>3));	
}
//检查积分是否足够
$hasMoney = getuserprofile("extcredits".$vars['ext']);
if($hasMoney < $vars['money']){
	showmessage(lang('plugin/tshuz_famous','lang38'),'',array(),array("alert"=>"error","msgtype"=>2,"closetime"=>3));	exit;
}
//开始处理数据
$voteInfo = DB::fetch_first("select * from ".DB::table("plugin_tshuz_famous")." where uid=".$uid);
if($voteInfo){
	$voteUids = json_decode($voteInfo['uids'],true);
	if(in_array($_G['uid'],$voteUids)){
		showmessage(lang('plugin/tshuz_famous','lang03'),'',array(),array("alert"=>"error","msgtype"=>2,"closetime"=>3));	
	}
	$voteUids[] = $_G['uid'];
	$data= array(
		"num"=>($voteInfo['num']+1),
		"uids"=>json_encode($voteUids)
	);
	DB::update("plugin_tshuz_famous",$data,"uid=".$uid);
}else{
	$voteUids[] = $_G['uid'];
	$data= array(
		'uid'=>$uid,
		"num"=>1,
		"uids"=>json_encode($voteUids)
	);
	DB::insert("plugin_tshuz_famous",$data);
}
updatemembercount($uid, array("extcredits".$vars['ext'] => $vars['money']), true, 'RCV', $_G['uid']);
updatemembercount($_G['uid'], array("extcredits".$vars['ext'] => "-".$vars['money']), true, 'TFR', $uid);
showmessage(lang('plugin/tshuz_famous','lang04'),'',array(),array("alert"=>"right","msgtype"=>2,"closetime"=>3));	
?>