<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_tshuz_posthighlightlimit {}
class mobileplugin_tshuz_posthighlightlimit_forum extends mobileplugin_tshuz_posthighlightlimit{
	public function post_message($param) {
		global $_G;
		$param = $param['param'];
		//判断是否是新帖
		if(strpos($param[0],'newthread') === false || strpos($param[0],'succeed') == false) return '';
		$tid = intval($param[2]['tid']);
		$fid = intval($param[2]['fid']);
		$pid = intval($param[2]['pid']);
		if (!$tid || !$pid) {
			return '';
		}
		$pvars = $_G['cache']['plugin']['tshuz_posthighlightlimit'];
		$forums = (array)unserialize($pvars['forums']);
		$groups = (array)unserialize($pvars['groups']);
		if(in_array($fid,$forums) && in_array($_G['groupid'],$groups)){//查看是否是启用版块和用户组
			//设置高亮
			$data['highlight'] 	= $pvars['color1']?(intval($pvars['color1'])-1):mt_rand(0,8);
			$data['underline'] 	= $pvars['underline1']?(intval($pvars['underline1'])-1):mt_rand(0,1);
			$data['blod'] 		= $pvars['blod1']?(intval($pvars['blod1'])-4):(mt_rand(0,1)?4:0);
			$data['italic']		= $pvars['italic1']?(intval($pvars['italic1'])-2):(mt_rand(0,1)?2:0);
			//更改帖子状态
			$thread['highlight'] = intval(($data['underline']+$data['blod']+$data['italic']).$data['highlight']);
			$thread['moderated'] = 1;
			C::t("forum_thread")->update($tid,$thread);
			//更新限时高亮
			C::t("forum_threadmod")->update_by_tid_action($tid, 'EHL',array("status"=>0));
			//设置到期时间
			$threadmod['tid'] = $tid;
			$adminUid = $pvars['admin'];
			$threadmod['uid'] = $adminUid;
			$adminInfo = getuserbyuid($adminUid);
			$threadmod['username'] = $adminInfo['username'];
			$threadmod['dateline'] = time();
			$pdays = $pvars['days']?$pvars['days']:mt_rand(1,365);
			$threadmod['expiration'] = $threadmod['dateline']+$pdays*86400;
			$threadmod['action'] = "EHL";
			$threadmod['status'] = 1;
			C::t("forum_threadmod")->insert($threadmod);
		}
		return '';
	}
}
//From: Dism_taobao_com
?>