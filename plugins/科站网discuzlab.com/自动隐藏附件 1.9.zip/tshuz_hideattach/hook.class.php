<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class tshuz_hideattach {
	function discuzcode($value){
		global $_G;
		if($value['caller'] == 'discuzcode' && $value['param'][15]){
			$pVars = $_G['cache']['plugin']['tshuz_hideattach'];
			$forums = dunserialize($pVars['forums']);
			if(in_array($_G['fid'], $forums)){
				$hides = dunserialize($pVars['hide']);
				if(!$hides) return;
				$find = $replace = array();
				$message = $_G['discuzcodemessage'];
				$pid = intval($value['param'][12]);
				$attachlist = getattach($pid);
				foreach ($attachlist['imgattachs']['used'] as $imgattach) {
					$find[] = '[attach]'.$imgattach['aid'].'[/attach]';
					$replace[] = '[attachimg]'.$imgattach['aid'].'[/attachimg]';
				}
				$message = str_replace($find, $replace, $message);
				$find = $replace = array();
				if($pVars['auto']){//默认隐藏
					$find = array('[attach]','[/attach]','[attachimg]','[/attachimg]');
					$replace = array('[hide][attach]','[/attach][/hide]','[hide][attachimg]','[/attachimg][/hide]');
				}else{
					$log = C::t("#tshuz_hideattach#log")->fetch($_G['tid']);
					switch ($log['hide']) {
						case '12':
							$find = array('[attach]','[/attach]','[attachimg]','[/attachimg]');
							$replace = array('[hide][attach]','[/attach][/hide]','[hide][attachimg]','[/attachimg][/hide]');
							break;
						case '1':
							$find = array('[attachimg]','[/attachimg]');
							$replace = array('[hide][attachimg]','[/attachimg][/hide]');
							break;
						case '2':
							$find = array('[attach]','[/attach]');
							$replace = array('[hide][attach]','[/attach][/hide]');
							break;
					}
				}
				if(count($find)>1){
					$find[] = '[hide][hide]'; $replace[] = '[hide]';
					$find[] = '[/hide][/hide]'; $replace[] = '[/hide]';
					$message = str_replace($find, $replace, $message);
					//解析hide
					if(!$_G['forum']['ismoderator']) {
						if($_G['uid']) {
							$_post = C::t('forum_post')->fetch('tid:'.$_G['tid'], $pid);
							$authorreplyexist = $_post['tid'] == $_G['tid'] ? C::t('forum_post')->fetch_pid_by_tid_authorid($_G['tid'], $_G['uid']) : FALSE;
						}
					} else {
						$authorreplyexist = TRUE;
					}

					if($authorreplyexist) {
						$message = preg_replace("/\[hide\]\s*(.*?)\s*\[\/hide\]/is", tpl_hide_reply(), $message);
					} else {
						$message = preg_replace("/\[hide\](.*?)\[\/hide\]/is", tpl_hide_reply_hidden(), $message);
						$message = '<script type="text/javascript">replyreload += \',\' + '.$pid.';</script>'.$message;
					}
					$message = str_replace(array('[attachimg]','[/attachimg]'), array('[attach]','[/attach]'), $message);
					$_G['discuzcodemessage'] = $message;
				}
			}
		}
		return '';
	}
	function post_message($param){
		global $_G;
		$param = $param['param'];
		$tid = intval($param[2]['tid']);//帖子ID
		$post_type = $param[0];
		if(isset($_GET['autohide'])){
			$data['hide'] = intval(implode('',$_GET['autohide']));
			if($post_type == 'post_newthread_succeed'){//发帖成功
				$data['tid'] = $tid;
				C::t("#tshuz_hideattach#log")->insert($data);
			}elseif($post_type == 'post_edit_succeed'){//编辑成功
				$pid = intval($param[2]['pid']);//帖子PID
				require_once libfile('function/magic');
				$post = getpostinfo($_GET['pid'], 'pid', array());
				if($post['first']){
					$log = C::t("#tshuz_hideattach#log")->fetch($tid);
					if(!$log){
						$data['tid'] = $tid;
						C::t("#tshuz_hideattach#log")->insert($data);
					}else{
						C::t("#tshuz_hideattach#log")->update($tid,$data);
					}
				}
			}
		}elseif($post_type == 'post_edit_succeed'){
			$pid = intval($param[2]['pid']);//帖子PID
			require_once libfile('function/magic');
			$post = getpostinfo($_GET['pid'], 'pid', array());
			if($post['first']){
				$log = C::t("#tshuz_hideattach#log")->fetch($tid);
				if($log){
					$data['hide'] = 0;
					C::t("#tshuz_hideattach#log")->update($tid,$data);
				}
			}
		}
	}

	function _post_tshuz_hideattach(){
		global $_G,$isfirstpost;
		if(!in_array($_GET['action'], array("edit","newthread")) || !$isfirstpost) return;
		$pVars = $_G['cache']['plugin']['tshuz_hideattach'];
		$forums = dunserialize($pVars['forums']);
		if(in_array($_G['fid'], $forums)){
			$hides = dunserialize($pVars['hide']);
			if(!$hides) return;
			$extra['auto'] = $extra['attach'] =	$extra['img'] = false;
			$log = C::t("#tshuz_hideattach#log")->fetch($_G['tid']);
					switch ($log['hide']) {
						case '12':
							$extra['attach'] =	$extra['img'] = true;
							break;
						case '1':
							$extra['img'] = true;
							break;
						case '2':
							$extra['attach'] = true;
							break;
						default:
							$extra['attach'] =	$extra['img'] = false;
							break;
					}

			if($pVars['auto']){//默认隐藏
				$extra['auto'] = $extra['attach'] =	$extra['img'] = true;
			}else{
				$groups = dunserialize($pVars['groups']);
				if(!in_array($_G['groupid'], $groups)){
					return ;
				}
			}
			include template("tshuz_hideattach:post");
			return $return;
		}
		return ;
	}
}
class plugin_tshuz_hideattach extends tshuz_hideattach{}
class mobileplugin_tshuz_hideattach extends tshuz_hideattach{}
class mobileplugin_tshuz_hideattach_forum extends plugin_tshuz_hideattach{
	function post_bottom_mobile_output(){
		global $_G,$isfirstpost;
		return $this->_post_tshuz_hideattach();
	}
}
class plugin_tshuz_hideattach_forum extends plugin_tshuz_hideattach{
	function post_attribute_extra_body_output(){
		global $_G,$isfirstpost;
		return $this->_post_tshuz_hideattach();
	}
}
//From: Dism_taobao_com
?>