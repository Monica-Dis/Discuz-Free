<?php

/**
 *      Copyright 2001-2099 DisM!应用中心.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: extends.inc.php 2018-06-21 16:54:27Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* 插件代码开始 */
showtableheader(lang('plugin/tshuz_urlattach','RB4cc2'));
showsubtitle(array(lang('plugin/tshuz_urlattach','tzc7Z7'),lang('plugin/tshuz_urlattach','KTkKUV'),''));
$files = array(
	'vip'=>array(lang('plugin/tshuz_urlattach','Rr4z1L'),80234),
	'high'=>array(lang('plugin/tshuz_urlattach','NzIrCb'), 81988),
	'toauthor' => array(lang('plugin/tshuz_urlattach', 'mHwz53'), 80889),
	'baidupan'=>array(lang('plugin/tshuz_urlattach', 'Y6dBis'),80888)
);
foreach($files as $k=>$v){
	showtablerow(
		'',array('width="200","width="100"',''),
		array(
			$v[0],
			file_exists(DISCUZ_ROOT.'./source/plugin/tshuz_urlattach/extend/'.$k.'.php')?'<font color=green>'.lang('plugin/tshuz_urlattach','DBww5W').'</font>':'<a href="http://dism.taobao.com?/?@tshuz_urlattach.plugin.'.$v[1].'" target="_blank"><font color=red>'.lang('plugin/tshuz_urlattach','Gc7B5g').'</font></a>'
		)
	);
}
showtablefooter(); /*dism · taobao · com*/