<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_tshuz_urlattach
{
	public function getTemplate($content, $pid, $authorid)
	{
		global $_G;
		preg_match_all("/\[urlattach=(.*?)\](.*?)\[\/urlattach\]/", $content, $matchs);
		if (!$matchs[1]) {
			return $content;
		}
		require DISCUZ_ROOT . './source/plugin/tshuz_urlattach/function/lang.php';
		$pvars = $_G['cache']['plugin']['tshuz_urlattach'];
		$credits['id'] = $_G['setting']['creditstransextra']['1'];
		$credits['title'] = $_G['setting']['extcredits'][$credits['id']]['title'];
		foreach ($matchs[0] as $pkey => $pvalue) {
			$plist = array();
			$tmp = explode(",", $matchs[1][$pkey]);
			if (count($tmp) != 4) continue;
			$return = '';
			$plist = array(
				"title"	=> $matchs[2][$pkey],
				"url"	=> $tmp[0],
				"desc"	=> $tmp[1],
				"readrm" => $tmp[2] ? intval($tmp[2]) : 0,
				"price"	=> $tmp[3] ? intval($tmp[3]) : 0
			);
			$plist['price'] = abs($plist['price']);
			if (file_exists(DISCUZ_ROOT . './source/plugin/tshuz_urlattach/extend/vip.php')) {
				include DISCUZ_ROOT . './source/plugin/tshuz_urlattach/extend/vip.php';
			}
			if ($plist['price'] || $plist['readrm'] > $_G['group']['readaccess']) {
				$plist['url'] = "plugin.php?id=tshuz_urlattach&tid={$_G['tid']}&pid={$pid}&item=" . ($pkey + 1) . "&hash=" . FORMHASH;
			}
			if ((($plist['readrm'] <= $_G['group']['readaccess'] || $pvars['ignore']) || $_G['uid'] == $authorid || $_G['forum']['ismoderator'])  && $plist['title'] && $plist['url']) {
				if ($pvars['template']) {
					include template('tshuz_urlattach:show' . $pvars['template']);
				} else {
					$find = array('{title}', '{url}', '{desc}', '{readrm}', '{price}');
					$replace = array($plist['title'], $plist['url'], $plist['desc'], $plist['readrm'], $plist['price']);
					$return = str_replace($find, $replace, $pvars['defined']);
				}
				$return = str_replace(array("\r", "\n", "\t"), '', $return);
			}
			$content = str_replace($pvalue, $return, $content);
		}
		return $content;
	}
	public function _post_message($param, $fkey = 'forums')
	{
		global $_G;
		$tid = $param['param'][2]['tid'];
		$fid = $param['param'][2]['fid'];
		$pid = $param['param'][2]['pid'];
		$pvars = $_G['cache']['plugin']['tshuz_urlattach'];
		$forums = $fkey == 'forums' ? dunserialize($pvars[$fkey]) : explode(',', $pvars[$fkey]);
		$groups = dunserialize($pvars['groups']);
		if (!in_array($fid, $forums) || !in_array($_G['groupid'], $groups)) return;
		if (!in_array($param['param'][0], array('post_newthread_succeed', 'audit_edit_succeed', 'post_edit_succeed'))) return '';
		$post = C::t('forum_post')->fetch('tid:' . $tid, $pid);
		if ($post['first'] && strpos($_GET['message'], '[urlattach') !== false && strpos($_GET['message'], '[/urlattach]') !== false) {
			C::t('forum_thread')->update($tid, array('attachment' => 1));
		}
		return '';
	}
	public function _viewthread_posttop_output()
	{
		global $_G, $postlist;
		foreach ($postlist as $k => $v) {
			$postlist[$k]['message'] = $this->getTemplate($v['message'], $v['pid'], $v['authorid']);
		}
	}
	public function _post_attach_btn_extra($fkey = 'forums')
	{
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_urlattach'];
		$forums = $fkey == 'forums' ? dunserialize($pvars[$fkey]) : explode(',', $pvars[$fkey]);
		$groups = dunserialize($pvars['groups']);
		if (!in_array($_G['fid'], $forums) || !in_array($_G['groupid'], $groups))
			return;
		require DISCUZ_ROOT . './source/plugin/tshuz_urlattach/function/lang.php';
		$return = '<li id="e_btn_urllist"><a href="javascript:;" onclick="switchAttachbutton(\'urllist\');">' . $dlang['lang001'] . '</a></li>';
		return $return;
	}
	public function _post_attach_tab_extra($fkey = 'forums')
	{
		global $_G, $editor, $postinfo;
		$pvars = $_G['cache']['plugin']['tshuz_urlattach'];
		$forums = $fkey == 'forums' ? dunserialize($pvars[$fkey]) : explode(',', $pvars[$fkey]);
		$groups = dunserialize($pvars['groups']);
		if (!in_array($_G['fid'], $forums) || !in_array($_G['groupid'], $groups))
			return;
		$credits['id'] = $_G['setting']['creditstransextra']['1'];
		$credits['title'] = $_G['setting']['extcredits'][$credits['id']]['title'];
		loadcache("groupreadaccess");
		if ($pid = intval($_GET['pid'])) {
			/*获取帖子内容*/
			$message = $postinfo['message'];
			preg_match_all("/\[urlattach=(.*?)\](.*?)\[\/urlattach\]/", $message, $matchs);
			$plists = array();
			foreach ($matchs[1] as $pkey => $pvalue) {
				$tmp = explode(",", $matchs[1][$pkey]);
				$plists[] = array(
					"title"	=> $matchs[2][$pkey],
					"url"	=> $tmp[0],
					"desc"	=> $tmp[1],
					"readrm" => $tmp[2] ? $tmp[2] : 0,
					"price"	=> $tmp[3] ? $tmp[3] : 0
				);
				$plist['price'] = abs($plist['price']);
			}
		}
		require DISCUZ_ROOT . './source/plugin/tshuz_urlattach/function/lang.php';
		include template("tshuz_urlattach:post");
		return $return;
	}

	public function replaceAttach($message){
        return str_replace('[/urlattach]','',$message);
    }

	function discuzcode($value)
	{
		global $_G;
		if ($value['caller'] == 'discuzcode'){
            $_G['discuzcodemessage'] = $this->getTemplate($_G['discuzcodemessage'], $value['param'][12], $value['param'][10]);
        }else{
            $_G['discuzcodemessage'] = $this->replaceAttach($_G['discuzcodemessage']);
        }
		return '';
	}
}
class plugin_tshuz_urlattach_forum extends plugin_tshuz_urlattach
{

	function post_message($param)
	{
		global $_G;
		return $this->_post_message($param);
	}
	function viewthread_posttop_output()
	{
		global $_G, $postlist;
		return $this->_viewthread_posttop_output();
	}
	function post_attach_btn_extra()
	{
		global $_G;
		return $this->_post_attach_btn_extra();
	}
	function post_attach_tab_extra_output()
	{
		global $_G, $editor, $postinfo;
		return $this->_post_attach_tab_extra();
	}
}
class plugin_tshuz_urlattach_group extends plugin_tshuz_urlattach
{

	function post_message($param)
	{
		global $_G;
		return $this->_post_message($param, 'gforums');
	}
	function viewthread_posttop_output()
	{
		global $_G, $postlist;
		return $this->_viewthread_posttop_output('gforums');
	}
	function post_attach_btn_extra()
	{
		global $_G;
		return $this->_post_attach_btn_extra('gforums');
	}
	function post_attach_tab_extra_output()
	{
		global $_G, $editor, $postinfo;
		return $this->_post_attach_tab_extra('gforums');
	}
}
