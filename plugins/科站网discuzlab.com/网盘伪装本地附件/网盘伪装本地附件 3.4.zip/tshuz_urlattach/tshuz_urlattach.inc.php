<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_GET['hash'] != FORMHASH) showmessage('submit_invalid');
$pid = intval($_GET['pid']);
$tid = intval($_GET['tid']);
$item = intval($_GET['item']);
if(!$pid || !$tid || !$item) showmessage('submit_invalid');
$item = $item-1;
require DISCUZ_ROOT . './source/plugin/tshuz_urlattach/function/lang.php';
/*获取帖子内容*/
require_once libfile('function/magic');
$post = getpostinfo($pid, 'pid');
$message = $post['message'];
if($_G['cache']['plugin']['tshuz_link2attach']){
	include_once libfile('function/core', 'plugin/tshuz_link2attach');
	$message = replaceMessage($message);
}


preg_match_all("/\[urlattach=(.*?)\](.*?)\[\/urlattach\]/", $message,$matchs);
if(!count($matchs)) showmessage($dlang['lang002']);
/*附件信息*/
$tmp = explode(",", $matchs[1][$item]);
$plist = array(
	"title"	=> $matchs[2][$item],
	"url"	=> $tmp[0],
	"desc"	=> $tmp[1],
	"readrm"=> $tmp[2]?$tmp[2]:0,
	"price"	=> $tmp[3]?$tmp[3]:0
);

/*是否为作者或管理员*/
if($post['authorid'] == $_G['uid'] || $_G['forum']['ismoderator']){
	showmessage($dlang['lang003'].$plist['title'],$plist['url']);
}
/*判断阅读权限*/
if($plist['readrm']>$_G['group']['readaccess']){
	showmessage($dlang['lang004'],'','',array('login'=>1));
}
/*检查可用性*/
$file = DISCUZ_ROOT.'./source/plugin/tshuz_urlattach/extend/baidupan.php';
if(file_exists($file)){
	include $file;
}
/*判断无售价*/
if(!$plist['price']){
	showmessage($dlang['lang003'].$plist['title'],$plist['url']);
}
if(!$_G['uid']) showmessage('to_login', '', array(), array('login' => 1));
/*判断购买*/
$log = C::t("#tshuz_urlattach#tshuz_urlattach")->fetch($tid,$pid,$_G['uid'],$plist['url']);
if($log) showmessage($dlang['lang003'].$plist['title'],$plist['url']);
/*检查积分*/
$credits = $_G['setting']['creditstransextra']['1'];
$title = $_G['setting']['extcredits'][$credits]['title'];
$extNow = getuserprofile("extcredits".$credits);
$plist['price'] = abs($plist['price']);
if($extNow<$plist['price']) 
	showmessage($dlang['lang005'].$title.$dlang['lang006'].$plist['price']);
/*购买操作*/
$data = array();
$data['tid'] 		= $tid;
$data['pid'] 		= $pid;
$data['uid'] 		= $_G['uid'];
$data['attachurl'] 	= $plist['url'];
$data['price'] 		= $plist['price'];
$data['dateline'] 	= TIMESTAMP;
C::t("#tshuz_urlattach#tshuz_urlattach")->insert($data);
updatemembercount($_G['uid'], array("extcredits".$credits => "-".$plist['price']), 1, '');
$hasSum = false;
$file = DISCUZ_ROOT.'./source/plugin/tshuz_urlattach/extend/high.php';
if(file_exists($file) && $_G['cache']['plugin']['tshuz_urlattach']['high']){
	include $file;
}
$file = DISCUZ_ROOT.'./source/plugin/tshuz_urlattach/extend/toauthor.php';
if(file_exists($file)){
	include $file;
}
showmessage($dlang['lang003'].$plist['title'],$plist['url']);
?>