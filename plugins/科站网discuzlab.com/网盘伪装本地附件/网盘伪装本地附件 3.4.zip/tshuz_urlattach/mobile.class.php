<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class mobileplugin_tshuz_urlattach {
	
	public function getTemplate($content,$pid,$authorid){
		global $_G;
		preg_match_all("/\[urlattach=(.*?)\](.*?)\[\/urlattach\]/", $content,$matchs);
		if(!$matchs[1]){
			return $content;
		}
		$pvars = $_G['cache']['plugin']['tshuz_urlattach'];
		foreach ($matchs[0] as $pkey => $pvalue) {
			$plist = array();
			$tmp = explode(",", $matchs[1][$pkey]);
			if(count($tmp) != 4) continue;
			$return = '';
			$plist = array(
				"title"	=> $matchs[2][$pkey],
				"url"	=> $tmp[0],
				"desc"	=> $tmp[1],
				"readrm"=> $tmp[2]?intval($tmp[2]):0,
				"price"	=> $tmp[3]?intval($tmp[3]):0
			);
			$plist['price'] = abs($plist['price']);
			if(file_exists(DISCUZ_ROOT.'./source/plugin/tshuz_urlattach/extend/vip.php')){
				include DISCUZ_ROOT.'./source/plugin/tshuz_urlattach/extend/vip.php';
			}
			if($plist['price'] || $plist['readrm']>$_G['group']['readaccess']){
				$plist['url'] = "plugin.php?id=tshuz_urlattach&tid={$_G['tid']}&pid={$pid}&item=".($pkey+1)."&hash=".FORMHASH;
			}
			if( (($plist['readrm']<=$_G['group']['readaccess'] || $pvars['ignore']) || $_G['uid'] == $authorid || $_G['forum']['ismoderator'])  && $plist['title'] && $plist['url']){
				$find = array('{title}','{url}','{desc}','{readrm}','{price}');
				$replace = array($plist['title'],$plist['url'],$plist['desc'],$plist['readrm'],$plist['price']);
				$return = str_replace($find, $replace,$pvars['defined']);
				$return = str_replace(array("\r","\n","\t"), '', $return);
			}
			$content = str_replace($pvalue,$return, $content);	
		}
		return $content;
	}
	
	public function _viewthread_posttop_mobile_output(){
		global $_G,$postlist;
		foreach($postlist as $k=>$v){
			$postlist[$k]['message'] = $this->getTemplate($v['message'],$v['pid'],$v['authorid']);
		}
		return '';
	}
	
	
	public function _post_message($param,$fkey ='forums'){
		global $_G;
		$tid = $param['param'][2]['tid'];
		$fid = $param['param'][2]['fid'];
		$pid = $param['param'][2]['pid'];
		$pvars = $_G['cache']['plugin']['tshuz_urlattach'];
		$forums = $fkey =='forums'?dunserialize($pvars['forums']):explode(',',$pvars['gforums']);
		$groups = dunserialize($pvars['groups']);
		if(!in_array($fid, $forums) || !in_array($_G['groupid'], $groups)) return;
		if(!in_array($param['param'][0],array('post_newthread_succeed','audit_edit_succeed','post_edit_succeed'))) return '';
		$post = C::t('forum_post')->fetch('tid:'.$tid,$pid);
		if($post['first'] && strpos($_GET['message'],'[urlattach') !== false && strpos($_GET['message'],'[/urlattach]') !== false){
			C::t('forum_thread')->update($tid,array('attachment'=>1));
		}
		return '';
	}


    public function replaceAttach($message){
        return str_replace('[/urlattach]','',$message);
    }

    function discuzcode($value)
    {
        global $_G;
        if ($value['caller'] == 'discuzcode'){
            $_G['discuzcodemessage'] = $this->getTemplate($_G['discuzcodemessage'], $value['param'][12], $value['param'][10]);
        }else{
            $_G['discuzcodemessage'] = $this->replaceAttach($_G['discuzcodemessage']);
        }
        return '';
    }
}

class mobileplugin_tshuz_urlattach_forum extends mobileplugin_tshuz_urlattach {
	function viewthread_posttop_mobile_output(){
		global $_G,$postlist;
		return $this->_viewthread_posttop_mobile_output();
	}
	
	
	function post_message($param){
		global $_G;
		return $this->_post_message($param);
	}
}


class mobileplugin_tshuz_urlattach_group extends mobileplugin_tshuz_urlattach {
	function viewthread_posttop_mobile_output(){
		global $_G,$postlist;
		return $this->_viewthread_posttop_mobile_output();
	}
	
	
	function post_message($param){
		global $_G;
		return $this->_post_message($param,'gforums');
	}
}