<?php

/**
 *      (C)2001-2099 DiscuzLab.com.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: tshuz_qqfastlogin.inc.php 2018-09-29 14:12:36Z Todd $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* 插件代码开始 */

?><script type="text/javascript">location.href="https://addon.dismall.com/?@tshuz_qqfastlogin.plugin";</script>