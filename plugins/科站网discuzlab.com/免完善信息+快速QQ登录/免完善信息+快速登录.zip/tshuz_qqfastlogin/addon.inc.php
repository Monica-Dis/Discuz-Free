<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
?>
<script type="text/javascript">location.href="https://addon.dismall.com/?@838.developer";</script>