<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_tshuz_qqfastlogin {
	function global_header(){
		global $_G;
		if(CURSCRIPT == 'member' && $_GET['mod'] == 'connect'){
			$openid = addslashes(getcookie("client_token"));
			if($_G['connectguest'] && $openid && !$_G['uid']){
				$username 	= $_G['member']['username']; //当前用户名
				$censorexp = '/^(' . str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
				if ($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
					return '';
				}
				$avatars 	= array();
				$avatars[] 	= "http://q.qlogo.cn/qqapp";;
				$avatars[] 	= $_G['setting']['connectappid'];
				$avatars[] 	= strtoupper($openid);
				$avatars[]	= "40";
				$avatar 	= implode("/", $avatars);//	qq头像
				$res = C::t("#qqconnect#common_connect_guest")->fetch_all($openid);

				if(!$res || $res[$openid]['conqqnick'] != $username){
					return '';
				}
				//新建用户
				$user['name'] 	= $this->checkUsername($username);
				$user['pwd'] 	= md5(random(10));
				$user['email'] 	= 'qqconect_'.strtolower(random(10)).'@null.null';
				loaducenter();
				$uid = uc_user_register($user['name'], $user['pwd'], $user['email'],'', '', $_G['clientip']);//添加uc用户
				if($uid>1){//uid正常
					C::t('common_member')->insert($uid, $user['name'], md5(random(10)), $user['email'], $_G['clientip'], $_G['setting']['newusergroupid'], null);//添加discuz用户
					
					$imageContent = dfsockopen($avatar);
					if(strlen($imageContent) > 100){//有头像内容
						$dir = './data/cache/';//存储路径
						$file = $dir.'dzlab_avatar_'.$uid.'.png';
						$image = DISCUZ_ROOT.$file;	
						file_put_contents($file, dfsockopen($avatar));//保存临时图片
						$this->createavatarimg($uid,$image);//创建头像文件
						unlink($image);//删除临时图片
						C::t('common_member')->update($uid,array('avatarstatus'=>1,"conisbind"=>1));
					}
					//关联用户
					$connect['uid'] = $uid;
					$connect['conopenid'] = $openid;
					$connect['conisfeed'] = 1;
					$connect['conisregister'] = 1;
					$connect['conuintoken'] = addslashes($res[$openid]['conuintoken']);
					C::t("#qqconnect#common_member_connect")->insert($connect);
					//增加积分
					$defaultext = array();
					$initcredits = explode(",",$_G['setting']['initcredits']);
					foreach($initcredits as $keyNum => $initcredit){
						if($keyNum>0 && $initcredit){
							$defaultext['extcredits'.$keyNum] = $initcredit;
						}
					}
					updatemembercount($uid, $defaultext, 1);

					//登陆
					require_once libfile('function/member');
					$member = getuserbyuid($uid, 1);
					if(isset($member['_inarchive'])) {
						C::t('common_member_archive')->move_to_master($uid);
					}
					$cookietime = 1296000;
					setloginstatus($member, $cookietime);
					C::t("#qqconnect#common_connect_guest")->delete($openid);
					$bindlog['uid'] = $uid;
					$bindlog['uin'] = $openid;
					$bindlog['type']= 1;
					$bindlog['dateline'] = $_G['timestamp'];
					C::t("#qqconnect#connect_memberbindlog")->insert($bindlog);
					dsetcookie("client_token",null);
					dheader("location: ".$_G['siteurl']);
				}
			}
		}
	}



	public function checkUsername($username){
		$username = str_replace(" ", '', trim($username));
		$username = str_ireplace("\xe3\x80\x80","",$username);
		if(C::t('common_member')->fetch_uid_by_username($username) || C::t('common_member_archive')->fetch_uid_by_username($username)) {
			$username = "qq_".$username."_".random(3);
			if(strlen($username)>15){
				$username = mb_substr($username,0,15);
			}
			return $this->checkUsername($username);
		}else{
			return addslashes($username);
		}
	}

	public function createavatarimg($uid,$image) {
		$uid = abs(intval($uid)); //UID取整数绝对值
		$uid = sprintf("%09d", $uid); //前边加0补齐9位，例如UID为31的用户变成 000000031
		$dir1 = substr($uid, 0, 3);  //取左边3位，即 000
		$dir2 = substr($uid, 3, 2);  //取4-5位，即00
		$dir3 = substr($uid, 5, 2);  //取6-7位，即00
		$avatar_save_path = DISCUZ_ROOT.'uc_server/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3;	
		if(!file_exists($avatar_save_path)) {
			mkdir($avatar_save_path,0755,true);
		}
		$avatar_save_name_id = substr($uid, -2);
		
		$pic_info = array();
		$pic_size = getimagesize($image,$pic_info);
		if ($pic_size['mime'] == 'image/png') {
			$pic_img = imagecreatefrompng($image);
		}else{
			$pic_img = imagecreatefromjpeg($image);
		}
		$bg_color_white = imagecolorallocate($bg_img_big,255, 255, 255);//底色
		
		$avas = array('big'=>145,'middle'=>120,'small'=>48);
		foreach($avas as $n=>$s) {
			$s = ($s>=$pic_size[0]?$pic_size[0]:$s);
			$bg_img = imagecreatetruecolor($s,$s);
			imagefill($bg_img,$bg_color_white);
			imagecopyresampled($bg_img , $pic_img , 0 , 0 , 0 , 0 , $pic_size[0],$pic_size[1] , $pic_size[0] , $pic_size[1]);

			imagejpeg($bg_img, $avatar_save_path.'/'.$avatar_save_name_id.'_avatar_'.$n.'.jpg');
			
		}
	}
}
?>