<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: tshuz_copyupload.inc.php 2017-07-03 11:07:54Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */
$pvars = $_G['cache']['plugin']['tshuz_copyupload'];
if(!in_array($_G['groupid'],dunserialize($pvars['groups'])) ) showmsg(lang('plugin/tshuz_copyupload','TDWQWj'));

$picData = $_FILES['Filedata'];
if(!$picData || $picData['size'] < 0) 
	showmsg(lang('plugin/tshuz_copyupload','RQ8C3g'));
if($_GET['formhash'] != FORMHASH) 
	showmsg(lang('plugin/tshuz_copyupload','Eg7Y03'));
$types = array(
	"image/jpeg"=>'jpg',
	"image/png"=>'png',
	"image/gif"=>'gif',
	"image/jpg"=>'jpg'
);
if(!$types[$picData['type']]) 
	showmsg(lang('plugin/tshuz_copyupload','wfJrCw'));

$_FILES['Filedata']['name'] = date($pvars['name'],TIMESTAMP).mt_rand(1000,9999).".".$types[$picData['type']];
$mod = $_GET['mod'];
if($mod == 'portal'){
	include libfile('extend/portal','plugin/tshuz_copyupload');
}else{//论坛
	$fid = dintval($_GET['fid']);
	if($fid) {
		$forum = $fid != $_G['fid'] ? C::t('forum_forum')->fetch_info_by_fid($fid) : $_G['forum'];
		if($forum['status'] == 3 && $forum['level']) {
			$levelinfo = C::t('forum_grouplevel')->fetch($forum['level']);
			if($postpolicy = $levelinfo['postpolicy']) {
				$postpolicy = dunserialize($postpolicy);
				$forumattachextensions = $postpolicy['attachextensions'];
			}
		} else {
			$forumattachextensions = $forum['attachextensions'];
		}
		if($forumattachextensions) {
			$_G['group']['attachextensions'] = $forumattachextensions;
		}
	}
	include libfile('class/upload','plugin/tshuz_copyupload');
	$upload = new class_upload();
}


function showmsg($msg,$error = 'error'){
	$return = array(
		'ercode'=>$error,
		'msg'  =>$msg
	);
	echo json_encode($return);
	exit();
}
//From: d'.'is'.'m.ta'.'obao.com
?>