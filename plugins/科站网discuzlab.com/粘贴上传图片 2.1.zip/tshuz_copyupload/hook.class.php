<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: hook.class.php 2017-06-30 15:38:27Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */

class plugin_tshuz_copyupload_forum {
	function post_middle(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_copyupload'];
		if(!in_array($_G['groupid'],dunserialize($pvars['groups'])) ) return '';
		$swfhash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
		include template("tshuz_copyupload:post_middle");
		return $return;
	}

	function viewthread_fastpost_btn_extra(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_copyupload'];
		if(!in_array($_G['groupid'],dunserialize($pvars['groups'])) ) return '';
		$swfhash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
		include template("tshuz_copyupload:viewthread_fastpost");
		return $return;
	}

	function forumdisplay_fastpost_btn_extra(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_copyupload'];
		if(!in_array($_G['groupid'],dunserialize($pvars['groups'])) ) return '';
		$swfhash = md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid']);
		include template("tshuz_copyupload:viewthread_fastpost");
		return $return;
	}
}
class plugin_tshuz_copyupload_portal{
    function portalcp_middle_output(){
		global $_G,$article,$catid;
		if(!libfile('extend/portal','plugin/tshuz_copyupload')) return '';
		$pvars = $_G['cache']['plugin']['tshuz_copyupload'];
		if(!in_array($_G['groupid'],dunserialize($pvars['groups'])) ) return '';
		include template("tshuz_copyupload:portalcp_middle");
		return $return;
	}
}