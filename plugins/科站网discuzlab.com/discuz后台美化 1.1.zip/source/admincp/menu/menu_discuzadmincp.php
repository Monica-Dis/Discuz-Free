<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
if($_G['cache']['plugin']['discuzadmincp']['onoff'])
$menu['index'][] = array(lang('plugin/discuzadmincp','BaS8Xz').'<link rel="stylesheet" href="source/plugin/discuzadmincp/static/admincp.css" type="text/css" media="all" />','plugins&operation=config&identifier=discuzadmincp');