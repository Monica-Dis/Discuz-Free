<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache("plugin");
$pvars = $_G['cache']['plugin'][$_GET['identifier']];
$op = $_GET['op']?$_GET['op']:"list";
$opArray = array("list","import","add","edit","del","status","cache");
$defaultMenu = "list";
$menuList = array(
	"list"=>dzlang(1),
	"import"=>dzlang(2),
	"add"=>dzlang(3),
);
if(in_array($op,$opArray)){
	$hrefUrl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod'];
	$cpmsgUrl = 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod'];
	$formUrl = 'plugins&operation=config&do=' . $_GET['do'] . '&identifier=' . $_GET['identifier'] . '&pmod='.$_GET['pmod'];
	echo <<<EOF
	<style>
		.dzlab_admincp {width: 100%; margin: 0 auto; border-bottom: 3px solid #0099cc; background: #f2f6fd; height: 36px; margin-bottom: 10px;}
			.dzlab_admincp ul {margin: 0 10px;}
				.dzlab_admincp ul li{ display: inline-block; height: 26px;line-height: 26px; margin-top: 9px; padding: 0 11px; margin-right:5px;}
				.dzlab_admincp ul li.on,.dzlab_admincp ul li:hover {border: 1px solid #0099cc;padding: 0 10px; border-bottom: 0; background: #fff;}
					.dzlab_admincp ul li a {color: #0099cc; text-decoration: none;}
					.dzlab_admincp ul li.on a {font-weight: bold;}
	</style>
	<div class="dzlab_admincp">
		<ul>
EOF;
		foreach($menuList as $menuKey=>$menuVal){
			if($menuKey == $defaultMenu){
				echo "<li".(($menuKey==$op || !isset($menuList[$op]))?' class="on"':"")."><a href=\"".$hrefUrl."&op=".$menuKey."\">".$menuVal."</a></li>";
			}else{
				echo "<li".($menuKey==$op?' class="on"':"")."><a href=\"".$hrefUrl."&op=".$menuKey."\">".$menuVal."</a></li>";
			}
		}
	echo <<<EOF
		</ul>
	</div>
EOF;
	require DISCUZ_ROOT . './source/plugin/tshuz_buyname/admincp/' . $op . '.php';
}else{
	cpmsg("undefined_action","","error");
}

function dzlang($id){
	$langId = sprintf("%02d", $id);
	return lang('plugin/tshuz_buyname', 'slang'.$langId);
}
//From: Dism_taobao-com
?>