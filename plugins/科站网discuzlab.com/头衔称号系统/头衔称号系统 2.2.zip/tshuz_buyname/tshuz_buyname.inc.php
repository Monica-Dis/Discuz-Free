<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//禁止游客操作
if(!$_G['uid'])
	showmessage('to_login', null, array(), array('showmsg' => true, 'login' => 1));
$mod = $_GET['mod']?$_GET['mod']:"list";
$modArray = array("list","manage","buy","show");
$pvars = $_G['cache']['plugin']['tshuz_buyname'];
$ext = $_G['setting']['extcredits'][$pvars['ext']];
if(!in_array($mod,$modArray)){
	$mod = 'list';
}
require DISCUZ_ROOT . './source/plugin/tshuz_buyname/module/' . $mod . '.php';
function dzlang($id){
	$langId = sprintf("%02d", $id);
	return lang('plugin/tshuz_buyname', 'slang'.$langId);
}
//From: Dism_taobao-com
?>