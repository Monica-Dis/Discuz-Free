
<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_manage extends discuz_table{
	public function __construct() {
		$this->_table = 'tshuz_buyname_manage';
		$this->_pk    = '';
		parent::__construct(); //d'.'is'.'m.ta'.'obao.com
	}

	public function update_status_by_uid_timestamp($uid,$timestamp) {
		return DB::query("UPDATE %t SET status = -1 WHERE status!=-1 and uid = %d and dateline<%d",array($this->_table, $uid,$timestamp));
	}

	public function update_status_by_timestamp($timestamp){
		return DB::query("UPDATE %t SET status = -1 WHERE status!=-1 and dateline<%d",array($this->_table,$timestamp));
	}
	
	public function fetach_all_by_uid_limit($uid,$start,$perpage) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d ORDER BY dateline DESC LIMIT %d , %d " ,array($this->_table,$uid,$start,$perpage));
	}

	public function count_by_uid($uid){
		return DB::result_first("SELECT count(*) FROM %t WHERE uid=%d", array($this->_table,$uid));
	}

	public function delete_by_pid($pid){
		return DB::query("DELETE FROM %t WHERE pid=%d",array($this->_table,$pid));
	}

	public function fetch_by_pid_uid($pid,$uid){
		return DB::fetch_first("SELECT * FROM %t WHERE pid=%d and uid=%d", array($this->_table,$pid,$uid));
	}

	public function fetch_by_uid($uid){
		return DB::fetch_first("SELECT * FROM %t WHERE status=1 and uid=%d", array($this->_table,$uid));
	}

	public function update_by_uid_pid($data,$pid,$uid){
		return DB::update($this->_table,$data,array("pid"=>$pid,"uid"=>$uid));
	}

	public function update_status_by_uid_pid($uid,$pid){
		return DB::query("UPDATE %t SET status = 1 WHERE uid = %d and pid=%d and status=0",array($this->_table, $uid,$pid));
	}

	public function update_status_by_uid($uid){
		return DB::query("UPDATE %t SET status = 0 WHERE uid = %d and status=1",array($this->_table, $uid));
	}

	public function fetch_all_by_uids($uids){
		return DB::fetch_all("SELECT * FROM %t WHERE status=1 and uid in (%n)", array($this->_table,$uids));
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>