<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_title extends discuz_table{
	public function __construct() {
		$this->_table = 'tshuz_buyname_title';
		$this->_pk    = '';
		parent::__construct(); //d'.'is'.'m.ta'.'obao.com
	}

	public function count() {
		return DB::result_first("SELECT count(*) FROM %t", array($this->_table));
	}
	
	public function fetch_all_limit($start,$perpage) {
		return DB::fetch_all("SELECT * FROM %t ORDER BY id DESC LIMIT %d , %d " ,array($this->_table,$start,$perpage));
	}

	public function count_status($status) {
		return DB::result_first("SELECT count(*) FROM %t WHERE status=%d", array($this->_table,$status));
	}
	
	public function fetch_all_limit_by_status($status,$start,$perpage) {
		return DB::fetch_all("SELECT * FROM %t WHERE status=%d ORDER BY id DESC LIMIT %d , %d " ,array($this->_table,$status,$start,$perpage));
	}

	public function update_status_by_id($status,$id) {
		return DB::query("UPDATE %t SET status=%d WHERE id = %d",array($this->_table,$status, $id));
	}

	public function update_by_id($data,$id) {
		return DB::query("UPDATE %t SET title=%s,price=%d,days=%d,src=%s WHERE id = %d",array($this->_table,$data['title'],$data['price'],$data['days'],$data['src'], $id));
	}

	public function fetch_by_id($id){
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$id));
	}

	public function delete_by_id($id){
		return DB::query("DELETE FROM %t WHERE id=%d ",array($this->_table,$id));
	}

	public function fetch_all(){
		return DB::fetch_all("SELECT * FROM %t" ,array($this->_table));
	}

}
//dis'.'m.t'.'ao'.'bao.com
?>