<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_tshuz_buyname {
	function global_header(){
		global $_G;
		require_once libfile('function/cache');
		$cacheTimeFile = DISCUZ_ROOT.'./data/sysdata/cache_tshuz_buyname_cache.php';//缓存文件
		if(!file_exists($cacheFile)) return '';
		require($cacheTimeFile);
		$todaytime = strtotime(date("Y-m-d"));
		if( $cacheTime != $todaytime || !file_exists($cacheFile) ){//缓存到期
			$cacheArray .= "\$cacheTime=".$todaytime.";\n";
			writetocache('tshuz_buyname_cache', $cacheArray) ;
			//更新过期的状态
			C::t("#tshuz_buyname#manage")->update_status_by_timestamp($_G['timestamp']);
		}
	}
}
class plugin_tshuz_buyname_forum extends plugin_tshuz_buyname{
	function viewthread_avatar_output(){
		global $_G,$postlist;
		$return = array();
		$cacheFile = DISCUZ_ROOT.'./data/sysdata/cache_tshuz_buyname.php';//缓存文件
		if(!file_exists($cacheFile)) return '';
		require $cacheFile;
		$pvars = $_G['cache']['plugin']['tshuz_buyname'];
		$groups = dunserialize($pvars['groups']);
		$uids = array();
		foreach ($postlist as $pkey => $pvalue) {
			$uids[] = $pvalue['authorid'];
		}
		$nameAll = C::t("#tshuz_buyname#manage")->fetch_all_by_uids($uids);
		foreach($nameAll as $name){
			$tempName[$name['uid']] = $name;
		}
		foreach ($postlist as $pkey => $pvalue) {
			$uids = array();
			if(in_array($pvalue['groupid'], $groups)){
				$nameInfo = $tempName[$pvalue['authorid']];
				if($nameInfo){
					$tempInfo = $tshuz_buyname[$nameInfo['pid']];
					$return[] = $tempInfo['status']?"<div style='width:90%; margin:0 auto;'><img title='".$tempInfo['title']."' style='max-width:100%; display:block;margin:10px auto;' title='".$tempInfo['title']."' src=".$tempInfo['src']." /></div>":"";
				}else{
					$return[] = '';
				}
			}else{
				$return[] = '';
			}
		}
		return $return;

	}
}

class plugin_tshuz_buyname_home extends plugin_tshuz_buyname{
	function space_profile_baseinfo_top(){
		global $_G,$space;
		$uid = $_GET['uid'];
		$cacheFile = DISCUZ_ROOT.'./data/sysdata/cache_tshuz_buyname.php';//缓存文件
		if(!file_exists($cacheFile)) return '';
		require $cacheFile;
		$pvars = $_G['cache']['plugin']['tshuz_buyname'];
		$groups = dunserialize($pvars['groups']);
		$return = '';
		$groupid = C::t("#tshuz_buyname#member")->fetch_by_uid($uid);
		if(in_array($groupid, $groups)){
			$nameInfo = C::t("#tshuz_buyname#manage")->fetch_by_uid($uid);
			if($nameInfo){
				$tempInfo = $tshuz_buyname[$nameInfo['pid']];
				$return= $tempInfo['status']?"<img title='".$tempInfo['title']."' src=".$tempInfo['src']." />":"";
			}
		}
		return $return;

	}
}

class mobileplugin_tshuz_buyname_forum {
	function viewthread_posttop_mobile_output(){
		global $_G,$postlist;
		$return = array();
		$cacheFile = DISCUZ_ROOT.'./data/sysdata/cache_tshuz_buyname.php';//缓存文件
		if(!file_exists($cacheFile)) return '';
		require $cacheFile;
		$pvars = $_G['cache']['plugin']['tshuz_buyname'];
		$groups = dunserialize($pvars['groups']);
		$uids = array();
		foreach ($postlist as $pkey => $pvalue) {
			$uids[] = $pvalue['authorid'];
		}
		$nameAll = C::t("#tshuz_buyname#manage")->fetch_all_by_uids($uids);
		foreach($nameAll as $name){
			$tempName[$name['uid']] = $name;
		}
		foreach ($postlist as $pkey => $pvalue) {
			$uids = array();
			if(in_array($pvalue['groupid'], $groups)){
				$nameInfo = $tempName[$pvalue['authorid']];
				if($nameInfo){
					$tempInfo = $tshuz_buyname[$nameInfo['pid']];
					$postlist[$pkey]['author'] .= $tempInfo['status']?"<br><img title='".$tempInfo['title']."' style='height:".$pvars['height']."' title='".$tempInfo['title']."' src=".$tempInfo['src']." />":"";
				}else{
					$return[] = '';
				}
			}else{
				$return[] = '';
			}
		}
		return $return;

	}
}