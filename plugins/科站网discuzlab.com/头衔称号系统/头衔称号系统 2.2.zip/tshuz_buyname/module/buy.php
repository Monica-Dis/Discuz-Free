<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_GET['hash'] != FORMHASH)
	showmessage('submit_invalid', '', array(), array('closetime' => true, 'showdialog' => 3, 'alert' => 'error'));
$id = intval($_GET['item']);
if(!$id)
	showmessage(dzlang(16), '', array(), array('closetime' => true, 'showdialog' => 3, 'alert' => 'error'));
$titleInfo = C::t("#tshuz_buyname#title")->fetch_by_id($id);
if(!$titleInfo)
	showmessage(dzlang(17), '', array(), array('closetime' => true, 'showdialog' => 3, 'alert' => 'error'));
if(!in_array($_G['groupid'], dunserialize($pvars['groups'])))
	showmessage(dzlang(36), '', array(), array('closetime' => true, 'showdialog' => 3, 'alert' => 'error'));
//检查积分
$credit = getuserprofile("extcredits".$pvars['ext']);
if($credit-$titleInfo['price']<0){
	$extTitle = $_G['setting']['extcredits'][$pvars['ext']]['title'];
	$extUnit = $_G['setting']['extcredits'][$pvars['ext']]['unit'];
	$message = dzlang(37).$extTitle.dzlang(38).$titleInfo['price'].$extUnit;
	showmessage($message, '', array(), array('closetime' => true, 'showdialog' => 3, 'alert' => 'error'));
}
//设置时间
$titleInfo['dbdays'] = $titleInfo['days'];
$titleInfo['days'] = $titleInfo['days']?$titleInfo['days']:36500;//100年
//检查是否购买过
$buyInfo = C::t("#tshuz_buyname#manage")->fetch_by_pid_uid($id,$_G['uid']);
if($buyInfo){
	//检查是否为永久
	if(!$titleInfo['dbdays']){
		showmessage(lang('plugin/tshuz_buyname', 'd5Gko6'), '', array(), array('closetime' => true, 'showdialog' => 3, 'alert' => 'error'));
	}
	//购买过
	$data['status'] = $buyInfo['status']<0?0:$buyInfo['status'];//状态
	if($buyInfo['status']<0){//过期了
		$data['buytime'] = $_G['timestamp'];//新购买时间
		$temptime = strtotime(date("Y-m-d"));
	}else{//未过期
		$temptime = $buyInfo['dateline'];
	}
	$data['dateline'] = $temptime+$titleInfo['days']*86400;//到期时间
	C::t("#tshuz_buyname#manage")->update_by_uid_pid($data,$id,$_G['uid']);
}else{
	$temptime = strtotime(date("Y-m-d"));
	$dateline = $temptime+$titleInfo['days']*86400;
	//未购买过
	C::t("#tshuz_buyname#manage")->insert( array("uid"=>$_G['uid'],"pid"=>$id,"buytime"=>$_G['timestamp'],"dateline"=>$dateline) );
}
//扣分
updatemembercount($_G['uid'], array('extcredits'.$pvars['ext'] => "-".$titleInfo['price']), true, '', 0, '');
showmessage(dzlang(39), 'plugin.php?id=tshuz_buyname&mod=manage', array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => true));
?>