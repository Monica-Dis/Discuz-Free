<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//更新过期的状态
C::t("#tshuz_buyname#manage")->update_status_by_uid_timestamp($_G['uid'],$_G['timestamp']);

if($_GET['hash'] != FORMHASH)
	showmessage('submit_invalid', '', array(), array('closetime' => true, 'showdialog' => 3, 'alert' => 'error'));
$id = intval($_GET['item']);
if(!$id)
	showmessage(dzlang(16), '', array(), array('closetime' => true, 'showdialog' => 3, 'alert' => 'error'));
if(!in_array($_G['groupid'], dunserialize($pvars['groups'])))
	showmessage(dzlang(36), '', array(), array('closetime' => true, 'showdialog' => 3, 'alert' => 'error'));
//检查是否购买过
$buyInfo = C::t("#tshuz_buyname#manage")->fetch_by_pid_uid($id,$_G['uid']);
if(!$buyInfo)
	showmessage(dzlang(40), '', array(), array('closetime' => true, 'showdialog' => 3, 'alert' => 'error'));
if($buyInfo['status']<0){
	showmessage(dzlang(41), '', array(), array('closetime' => true, 'showdialog' => 3, 'alert' => 'error'));
}
C::t("#tshuz_buyname#manage")->update_status_by_uid($_G['uid']);//解除佩戴
if($buyInfo['status']>0) {
	showmessage(dzlang(44), 'plugin.php?id=tshuz_buyname&mod=manage', array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => true));
}
C::t("#tshuz_buyname#manage")->update_status_by_uid_pid($_G['uid'],$id);//佩戴

showmessage(dzlang(43), 'plugin.php?id=tshuz_buyname&mod=manage', array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => true));

?>