<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//更新过期的状态
C::t("#tshuz_buyname#manage")->update_status_by_uid_timestamp($_G['uid'],$_G['timestamp']);

$perpage = 10;
$page = intval ( $_GET ['page'] ) ? intval ( $_GET ['page'] ) : 1;
$start = ($page - 1) * $perpage;
if ($start < 0)
$start = 0;
$count = C::t("#tshuz_buyname#title")->count_status(1);
$multi=	multi($count, $perpage, $page, "plugin.php?id=tshuz_buyname&mod=".$mod );
$list = C::t("#tshuz_buyname#title")->fetch_all_limit_by_status(1,$start,$perpage);
include template('tshuz_buyname:main');
?>