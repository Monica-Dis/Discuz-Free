<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//更新过期的状态
C::t("#tshuz_buyname#manage")->update_status_by_uid_timestamp($_G['uid'],$_G['timestamp']);

$cacheFile = DISCUZ_ROOT.'./data/sysdata/cache_tshuz_buyname.php';//缓存文件
require $cacheFile;

$perpage = 10;
$page = intval ( $_GET ['page'] ) ? intval ( $_GET ['page'] ) : 1;
$start = ($page - 1) * $perpage;
if ($start < 0)
$start = 0;
$count = C::t("#tshuz_buyname#manage")->count_by_uid($_G['uid']);
$multi=	multi($count, $perpage, $page, "plugin.php?id=tshuz_buyname&mod=".$mod );
$list = C::t("#tshuz_buyname#manage")->fetach_all_by_uid_limit($_G['uid'],$start,$perpage);
foreach ($list as $key => $value) {
	$list[$key]['info'] = $tshuz_buyname[$value['pid']];
}

include template('tshuz_buyname:main');
?>