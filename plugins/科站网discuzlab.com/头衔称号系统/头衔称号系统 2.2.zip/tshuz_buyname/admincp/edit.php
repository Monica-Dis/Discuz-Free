<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(submitcheck('submit')){//提交操作
	$id = intval($_GET['item']);
	if(!$id)
		cpmsg(dzlang(16), '', 'error');
	if(!$_GET['info']['title'])
		cpmsg(dzlang(4), '', 'error');
	if(!$_GET['info']['src'])
		cpmsg(dzlang(5), '', 'error');
	$data['title'] = addslashes($_GET['info']['title']);
	$data['src'] = addslashes($_GET['info']['src']);
	$data['price'] = intval($_GET['info']['price']);
	$data['days'] = intval($_GET['info']['days']);
	C::t("#tshuz_buyname#title")->update_by_id($data,$id);
	cpmsg(dzlang(6), $cpmsgUrl."&op=cache&hash=".FORMHASH, 'loading');
}else{
	$id = intval($_GET['item']);
	if(!$id)
		cpmsg(dzlang(16), '', 'error');
	$titleInfo = C::t("#tshuz_buyname#title")->fetch_by_id($id);
	if(!$titleInfo)
		cpmsg(dzlang(17), '', 'error');
	
    showformheader($formUrl.'&op=edit&item='.$id);
    showtableheader(dzlang(18), 'nobottom'); 
    showsetting(dzlang(7), 'info[title]', $titleInfo['title'], 'text');
    showsetting(dzlang(8), 'info[price]', $titleInfo['price'], 'text',false,false,dzlang(11));
    showsetting(dzlang(9), 'info[days]', $titleInfo['days'], 'text',false,false,dzlang(12));
    showsetting(dzlang(10), 'info[src]', $titleInfo['src'], 'text',false,false,dzlang(13));
    showsubmit('submit', 'submit');
    showtablefooter(); //Dism·taobao·com
}
//From: Dism_taobao-com
?>