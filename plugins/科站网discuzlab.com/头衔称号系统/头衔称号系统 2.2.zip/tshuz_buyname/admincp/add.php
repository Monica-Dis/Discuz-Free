<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(submitcheck('submit')){//提交操作
	if(!$_GET['info']['title'])
		cpmsg(dzlang(4), '', 'error');
	if(!$_GET['info']['src'])
		cpmsg(dzlang(5), '', 'error');
	$data['title'] = addslashes($_GET['info']['title']);
	$data['src'] = addslashes($_GET['info']['src']);
	$data['price'] = intval($_GET['info']['price']);
	$data['days'] = intval($_GET['info']['days']);
	C::t("#tshuz_buyname#title")->insert($data);
	cpmsg(dzlang(6), $cpmsgUrl."&op=cache&hash=".FORMHASH, 'loading');
}else{
    showformheader($formUrl.'&op=add');
    showtableheader(dzlang(3), 'nobottom'); 
    showsetting(dzlang(7), 'info[title]', '', 'text');
    showsetting(dzlang(8), 'info[price]', '1', 'text',false,false,dzlang(11));
    showsetting(dzlang(9), 'info[days]', '0', 'text',false,false,dzlang(12));
    showsetting(dzlang(10), 'info[src]', '', 'text',false,false,dzlang(13));
    showsubmit('submit', 'submit');
    showtablefooter(); //Dism·taobao·com
}
//From: Dism_taobao-com
?>