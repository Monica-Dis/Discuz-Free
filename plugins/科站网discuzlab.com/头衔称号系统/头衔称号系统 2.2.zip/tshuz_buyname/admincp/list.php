<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(submitcheck('submit')){//提交操作
	foreach($_GET['delete'] as $id){
		C::t("#tshuz_buyname#title")->delete_by_id($id);
		C::t("#tshuz_buyname#manage")->delete_by_pid($id);
	}
	cpmsg(dzlang(6), $cpmsgUrl."&op=cache&hash=".FORMHASH, 'loading');
}else{
	$perpage = 10;
	$page = intval ( $_GET ['page'] ) ? intval ( $_GET ['page'] ) : 1;
	$start = ($page - 1) * $perpage;
	if ($start < 0)
	$start = 0;
	$count = C::t("#tshuz_buyname#title")->count();
	$multi=	multi($count, $perpage, $page, $hrefUrl."&op=".$op );
	$list = C::t("#tshuz_buyname#title")->fetch_all_limit($start,$perpage);
	$ext = $_G['setting']['extcredits'][$pvars['ext']];
	showformheader($formUrl);
	if(count($list)){
		showtableheader("", 'nobottom',"id='cpform'");
		showsubtitle(array("","ID",dzlang(24),dzlang(24),dzlang(25),dzlang(26),dzlang(27)));
		foreach($list as $key=>$title){
			showtablerow('', array(
				'class="td25"',
				'class="td25"',
				'',
				'class="td24"',
				'class="td24"',
				'class="td24"',
				'width="100"'
			) , array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$title[id]\">",
				stripslashes($title['id']),
				'<a href="'.$title['src'].'" target="_blank">'.stripslashes($title['title']).'</a>',
				"<font style=\"color:#f60;font-weight:bold\">".$title['price'].$ext['unit'].$ext['title']."</font>",
				$title['days']?$title['days'].dzlang(29):dzlang(30),
				'<a title="'.dzlang(31).'" href="'.$hrefUrl."&op=status&item=".$title['id'].'&hash='.FORMHASH.'">'.($title['status']?dzlang(34):dzlang(35)).'</a>',
				'
				<a href="'.$hrefUrl."&op=edit&item=".$title['id'].'">'.dzlang(32).'</a>&nbsp;|&nbsp;
				<a href="'.$hrefUrl."&op=del&item=".$title['id'].'&hash='.FORMHASH.'">'.dzlang(33).'</a>
				'
			));
		}
		if($multi)
			showtablerow('',array('colspan=7 style="text-align: right;"'), array($multi));
		showsubmit('submit', 'submit','del');
	}else{
		echo "<tr><td>".dzlang(23)."</td></tr>";
	}
	showtablefooter(); //Dism·taobao·com
	showformfooter(); //Dism_taobao_com
}
//dis'.'m.t'.'ao'.'bao.com
?>