<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(submitcheck('submit')){//提交操作
	if(!$_GET['file'])
		cpmsg(dzlang(21), '', 'error');
	$json = @base64_decode($_GET['file']);
	$array = @json_decode($json,true);
	if(!is_array($array) || !count($array))
		cpmsg(dzlang(22), '', 'error');
	foreach ($array as $value) {
		$data = array();
		$data['title'] = addslashes(urldecode($value['title']));
		if(strtolower($_G['charset']) != 'gbk'){
			$data['title'] = mb_convert_encoding($data['title'], $_G['charset'],"gbk");
		}
		$data['src'] = addslashes($value['src']);
		$data['price'] = intval($value['price']);
		$data['days'] = intval($value['days']);
		if($data['title'] && $data['src']){
			C::t("#tshuz_buyname#title")->insert($data);
		}
	}
	cpmsg(dzlang(6), $cpmsgUrl."&op=cache&hash=".FORMHASH, 'loading');
}else{
    showformheader($formUrl.'&op=import');
    showtableheader('', 'nobottom'); 
    showsetting(dzlang(19), 'file', '', 'textarea',false,false,dzlang(20));
    showsubmit('submit', 'submit');
    showtablefooter(); //Dism·taobao·com
}
//From: Dism_taobao-com
?>