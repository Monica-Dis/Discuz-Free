<?php

/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: mobile.class.php 2017-05-22 16:26:36Z Todd $
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */

class mobileplugin_tshuz_wxreg
{
	function global_footer_mobile()
	{
		global $_G;
		$return = '';
		if (!defined('DISCUZ_VERSION')) include DISCUZ_ROOT . './source/discuz_version.php';
		if (strtolower(DISCUZ_VERSION) == 'x3.5') return '';
		if (CURSCRIPT == 'member' && 'register' == CURMODULE) {
			$pvars = $_G['cache']['plugin']['tshuz_wxreg'];
			$tip = strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') === false ? $pvars['tip3'] : $pvars['tip4'];
			include template("tshuz_wxreg:register");
		}
		return $return;
	}
}
class mobileplugin_tshuz_wxreg_member extends mobileplugin_tshuz_wxreg
{
	function register_limit()
	{
		global $_G;
		if (submitcheck("regsubmit")) {
			$pvars = $_G['cache']['plugin']['tshuz_wxreg'];
			if ($_GET['regwxcode'] != $pvars['code']) {
				showmessage($pvars['tip2']);
			}
		}
		return '';
	}

	function register_input_mobile()
	{
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_wxreg'];
		$tip = strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') === false ? $pvars['tip3'] : $pvars['tip4'];
		include template("tshuz_wxreg:register_input");
		return $return;
	}
}
