<?php

/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: qrcode.inc.php 2017-05-23 09:16:54Z Todd $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */
$pvars = $_G['cache']['plugin']['tshuz_wxreg'];
include template("tshuz_wxreg:qrcode");
?>