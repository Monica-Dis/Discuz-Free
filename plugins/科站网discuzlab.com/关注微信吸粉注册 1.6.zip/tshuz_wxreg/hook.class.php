<?php

/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: hook.class.php 2017-05-22 16:26:09Z Todd $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */
class plugin_tshuz_wxreg {}
class plugin_tshuz_wxreg_member extends plugin_tshuz_wxreg {
	function register_input(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_wxreg'];
		include template("tshuz_wxreg:register");
		return $return;
	}

	function register_limit(){
		global $_G;
		if(submitcheck("regsubmit")){
			$pvars = $_G['cache']['plugin']['tshuz_wxreg'];
			if($_GET['regwxcode'] != $pvars['code']){
				showmessage($pvars['tip2']);
			}
		}
		return '';
	}
}