<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//插件重复计费模式

if(in_array($thread['fid'],$forums)){
	$pluginpayed = $lastPayLog = DB::fetch_first('SELECT * FROM %t WHERE uid=%d AND operation=%s AND relatedid=%d ORDER BY dateline DESC LIMIT 0,1 ', array('common_credit_log', $_G['uid'], "BAC", $aid));
	if($pluginpayed ){
		//已经购买过
		$lastPayLog = end($pluginpayed); //最后一次购买记录
		if (TIMESTAMP - $config['validity'] * 86400 > $lastPayLog['dateline']) {
			//超过时限
			$newPrice = floor($attach['price'] * $config['discount'] / 100);
			$newPrice = $newPrice ? $newPrice : 1;
			$extCredit = $_G['setting']['creditstrans'];
			if (($balance = (getuserprofile('extcredits' . $extCredit) - $newPrice)) < 0) {
				showmessage($config['tip'], 'home.php?mod=spacecp&ac=credit');
			}
			//写入再次购买记录
			$data1['uid'] = $thread['authorid'];
			$data2['uid'] = $_G['uid'];
			$data1['operation'] = 'SAC';
			$data2['operation'] = 'BAC';
			$data1['relatedid'] = $data2['relatedid'] = $aid;
			$data1['dateline'] = $data2['dateline'] = TIMESTAMP;
			$data1['extcredits' . $extCredit] = $newPrice;
			$data2['extcredits' . $extCredit] = "-" . $newPrice;
			DB::insert("common_credit_log", $data1);
			DB::insert("common_credit_log", $data2);
		}
	}

}
//插件修改结束