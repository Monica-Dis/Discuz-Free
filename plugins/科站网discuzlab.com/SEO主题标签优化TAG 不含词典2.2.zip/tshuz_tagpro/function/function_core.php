<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
define('PLUGIN_CLASS',DISCUZ_ROOT.'./source/plugin/tshuz_tagpro/class/');
function getByPullwordGet($text){
	global $_G;
	$getway = 'http://api.pullword.com/get.php?source='.$text.'&param1=0&param2=1';
	$content = dfsockopen($getway);
	return pullword($content);
}

function pullword($content){
	global $_G;
	$data = explode("\n",$content);
	$keywords = array();
	foreach($data as $keyword){
		list($kwd,$floatnum) = explode(':',$keyword);
		$kwd = trim($kwd);
		$kwd = diconv($kwd,'utf-8');
		$floatnum = floatval($floatnum);
		if($kwd && $floatnum){
			$keywords[$kwd] = ($keywords[$kwd] ? $keywords[$kwd] : 0)+$floatnum;
		}
	}
	arsort($keywords);
	$keywords = array_slice($keywords,0,5,true);
	return array_keys($keywords);
}

function getByPhpanalysis($text){
	global $_G;
    include PLUGIN_CLASS.'./phpanalysis/phpanalysis.php';
    $pa = new PhpAnalysis( 'utf-8', $_G['charset'],false,$text);
    $pa::$loadInit = false;
    $pa->LoadDict();
    $pa->StartAnalysis( false );
	$tags = $pa->GetFinallyResult();
	$tags = explode(",",$tags);
    return $tags;
}

function getByScws($text,$num=5){
    global $_G;
    include PLUGIN_CLASS.'./scws/pscws4.class.php';
    $pscws = new PSCWS4('utf8');
    $pscws->set_dict( PLUGIN_CLASS.'./scws/dict.utf8.xdb');
    $pscws->set_rule( PLUGIN_CLASS.'./scws/dict/rules.utf8.ini');
    $pscws->set_ignore(true);
    $pscws->send_text($text);
    $words = $pscws->get_tops($num, 'zh');
    $pscws->close();
    $tags = array();
    foreach ($words as $val) {
        $tags[] =  (strtolower($_G['charset']) != 'gbk' ? $val['word'] : mb_convert_encoding($val['word'],$_G['charset'],'utf-8'));
    }
	$pscws->close();
    return $tags;
}
/*
function getByBaiduKeywords($text){
	global $_G;
	$getway = 'http://zhannei.baidu.com/api/customsearch/keywords?title=';
	$getway .= urlencode($text);
	$json = dfsockopen($getway);
	$data = json_decode($json,true);
	$keyword_list = $data['result']['res']['keyword_list'];
	$keywords = array_slice($keyword_list,0,5,true);
	return $keywords;
}

function getByBaiduWordrank($text){
	global $_G;
	$getway = 'http://zhannei.baidu.com/api/customsearch/keywords?title=';
	$getway .= urlencode($text);
	$json = dfsockopen($getway);
	$data = json_decode($json,true);
	$keyword_list = $data['result']['res']['wordrank'];
	$keywords = array();
	foreach($keyword_list as $wordrank){
		list($kwd,,$rank) = explode(":",$wordrank,3);
		$kwd = trim($kwd);
		$rank = floatval($rank);
		if($kwd && $rank && mb_strlen($kwd,$_G['charset'])>=2){
			$keywords[$kwd] = ($keywords[$kwd] ? $keywords[$kwd] : 0)+$rank;
		}
	}
	arsort($keywords);
	$keywords = array_slice($keywords,0,5,true);
	return array_keys($keywords);
}
*/