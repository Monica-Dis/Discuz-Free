<?php

/**
 *      Copyright (c) 2020 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: forum_relatekw.php 29236 2012-03-30 05:34:47Z chenmengshu $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($tid = @intval($_GET['tid'])) {
	$data = C::t('forum_post')->fetch_threadpost_by_tid_invisible($tid);
	$subject = $data['subject'];
	$message = cutstr($data['message'], 500, '');
	$pid = $data['pid'];
} else {
	$subject = daddslashes( $_GET['subjectenc'] );
	$message = daddslashes( $_GET['messageenc']);
}
include_once libfile('function/core','plugin/tshuz_tagpro');
$text = str_replace(array("\r","\t","\n"," "),'',$text);
$text = strip_tags($subject).",".strip_tags(preg_replace("/\[.+?\]/U", '', $message));
if(strtolower($_G['charset']) != 'utf-8' && !defined('IN_MOBILE')){
	$text = mb_convert_encoding($text,'utf-8',$_G['charset']);
}
switch ($getType) {
	/*
	case '2':
		$kws = getByPullwordPost($text);
		break;*/
	case '3':
		$kws = getByScws($text);
		break;
	case '4':
		$kws = getByPhpanalysis($text);
		break;
	/*
	case '5':
		$kws = getByBaiduKeywords($text);
		break;
	case '6':
		$kws = getByBaiduWordrank($text);
		break;*/
	default:
		$kws = getByPullwordGet($text);
		break;
}
$return = '';
if($kws) {
	foreach($kws as $kw) {
		$kw = dhtmlspecialchars($kw);
		$return .= $kw.',';
	}
	$return = dhtmlspecialchars($return);
}

$return = substr($return, 0, strlen($return)-1);
if(defined('IN_MOBILE')){
	foreach($kws as $k=>$v){
		$kws[$k] = diconv($v,$_G['charset'], 'UTF-8');
	}
	echo json_encode($kws);exit;
}
if(!$tid) {
	$_G['inajax'] = 1;
	include template('forum/relatekw');
} elseif($kws) {
	loadcache('censor');
	C::t('forum_post')->update('tid:'.$_G['tid'], $pid, array(
		'tags' => implode(',', $kws),
	));
}
//From: Dism_taobao-com
?>