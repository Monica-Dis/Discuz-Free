<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: hook.class.php 2017-09-19 10:27:06Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */

class plugin_tshuz_tagpro_forum {
	function relatekw_limit(){
		global $_G;
		$getType = $_G['cache']['plugin']['tshuz_tagpro']['type'];
		require DISCUZ_ROOT . './source/plugin/tshuz_tagpro/module/forum_' . CURMODULE . '.php';exit;
		return '';
	}

	function post_attribute_extra_body(){
		global $_G;
		if(!$_G['cache']['plugin']['tshuz_tagpro']['show']) return '';
		$auto_keyword = lang('forum/template','auto_keyword');
		$choosetag = lang('forum/template','choosetag');
		include template('tshuz_tagpro:show');
		return $return;
	}
}
