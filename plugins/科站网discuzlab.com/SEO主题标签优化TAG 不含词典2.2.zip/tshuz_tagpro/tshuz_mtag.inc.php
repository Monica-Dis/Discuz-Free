<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: tshuz_mtag.inc.php 2018-09-25 17:13:16Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* 插件代码开始 */

?><script type="text/javascript">location.href="https://dism.taobao.com/?@tshuz_mtag.plugin";</script>