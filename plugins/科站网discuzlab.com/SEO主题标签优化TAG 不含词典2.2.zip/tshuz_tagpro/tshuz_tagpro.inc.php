<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: tshuz_tagpro.inc.php 2018-09-25 17:11:55Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$getType = $_G['cache']['plugin']['tshuz_tagpro']['type'];

require DISCUZ_ROOT.'./source/plugin/tshuz_tagpro/module/forum_relatekw.php';