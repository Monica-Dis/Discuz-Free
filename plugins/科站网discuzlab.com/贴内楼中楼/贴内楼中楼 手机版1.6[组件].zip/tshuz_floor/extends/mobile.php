<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
foreach($postlist as $post){
	$pids[] = $post['pid'];
}
$floors = C::t("#tshuz_floor#floor")->fetch_all_by_pids($pids,$pvars['default']);
$counts = C::t("#tshuz_floor#floor")->count_by_pids($pids);
foreach($postlist as $k=>$post){
	if(!$post['first'] || ($post['first'] && $pvars['first'])){
		include template("tshuz_floor:floor");
		$postlist[$k]['message'] .= $return;
	}
}
//From: Dism_taobao-com
?>