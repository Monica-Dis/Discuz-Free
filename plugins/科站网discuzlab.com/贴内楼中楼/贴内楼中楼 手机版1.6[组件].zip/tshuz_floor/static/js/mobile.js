$(function(){
	$(".icon-reply").click(function(){
		$(this).parent().find(".reply_area").show()
	})
	$(".tshuz_title").click(function(){
		var replyObject = $(this).parent().find(".tshuz_reply");
		if(replyObject.is(":visible")){
			replyObject.hide();
			$(this).html(langs[1]).removeClass("nobottom");
		}else{
			replyObject.show()
			$(this).html(langs[0]).addClass("nobottom");;
		}
	})
})

function dshowmore(PID){
	var lilength = $("#floor_"+PID).find("li").length;
	var showurl = 'plugin.php?id=tshuz_floor&mod=show&pid='+PID+'&s='+lilength+'&formhash='+dformhash;
	$.ajax({
		type : 'GET',
		data:'',
		url : showurl,
		dataType : 'text'
	})
	.success(function(res) {
		if(res == 'formhasherror'){
			showDialog(langs[3]);
		}else if(res == 'paramerror'){
			showDialog(langs[4]);
		}else if(res == 'replynone'){
			showDialog(langs[5]);
		}else if(res == ''){
			showDialog(langs[2]);
		}else{
			var strs= new Array(); //定义一数组
			strs = res.split("####");
			$("#floor_"+PID+" .tshuz_reply .nobottom").before(strs[1]);
			if(strs[0] != "0"){
				$("#floor_"+PID+" #reply_more i").html(strs[0]);
			}else{
				$("#floor_"+PID+" #reply_more").hide();
			}
		}
	})
	.error(function() {
		popup.open(langs[2]);
	});
	return false;

}

function showDialog(msg){
	popup.open(msg,'alert');
}

function dreply(pid,uid,username){
	var replyObject = $("#floor_"+pid+" .reply_area").show();
	$("#floor_"+pid+" input[name='duid']").val(uid);
	$("#floor_"+pid+" input[name='dusername']").val(username);
}

function dreplysubmit(pid){
	if(nowuid == '0'){
		window.location.href="member.php?mod=logging&action=login";return false;
	}
	var cnt = $("#floor_"+pid+" .reply_cnt").val();
	if(cnt.length<1){
		showDialog(langs[6]);return false;
	}
	var submitUrl = 'plugin.php?id=tshuz_floor&mod=submit&pid='+pid+'&formhash='+dformhash+'&cnt='+cnt;
	var uid = $("#floor_"+pid+" input[name='duid']").val();
	var username = $("#floor_"+pid+" input[name='dusername']").val();
	if(uid && username) submitUrl += '&duid='+uid+ '&uname='+username;
	$.ajax({
		type : 'post',
		data:'',
		url : submitUrl,
		dataType : 'json'
	})
	.success(function(res) {
		res = res.msg;
		if(res == 'formhasherror'){
			showDialog(langs[3]);
		}else if(res == 'paramerror'){
			showDialog(langs[4]);
		}else if(res == 'contenterror'){
			showDialog(langs[6]);
		}else if(res == 'contentcherror'){
			showDialog(langs[8]);
		}else if(res == 'contentlengerror'){
			showDialog(langs[9]);
		}else if(res == 'tologin'){
			window.location.href="member.php?mod=logging&action=login";return false;
		}else if(res.substr(0,7) == 'success'){
			content = res.substr(7,res.length);
			var str = '';
			if(uid && username && uid != nowuid){
				str += '&nbsp;'+langs[7]+'&nbsp;<a class="tshuz_at" href="home.php?mod=space&uid='+uid+'" target="_blank" >'+username+'</a>';
			}
			var html = '<li><a class="tshuz_at" href="home.php?mod=space&uid='+nowuid+'" target="_blank" >'+nowusername+'</a>'+str+'&nbsp;:&nbsp;<span class="tshuz_cnt_main">'+cnt+'</span>&nbsp;<span class="tshuz_time grey rela">'+langs[7]+'</span></li>';
			$("#floor_"+pid+" .tshuz_reply .nobottom").before(html);
			$("#floor_"+pid+" .reply_cnt").val('');
			$("#floor_"+pid+" input[name='duid']").val('');
			$("#floor_"+pid+" input[name='dusername']").val('');
		}else{
			showDialog(langs[2]);
		}
	})
}
