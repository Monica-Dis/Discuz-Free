<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require DISCUZ_ROOT . './source/plugin/tshuz_floor/function/lang.php';
if(dintval($_GET['lid']) && $_GET['formhash'] == FORMHASH){
	$lid = dintval($_GET['lid']);
	$floor = C::t("#tshuz_floor#floor")->fetch($lid);
	$pid = $floor['pid'];
	C::t("#tshuz_floor#floor")->delete($lid);
	C::t("#tshuz_floor#floor")->update_floor_by_lid_pid($lid,$pid);
	cpmsg($dlang['lang012'],'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod'],"succeed");
}else{
	showtips($dlang['lang013']);
	/*数据读取*/
	$perpage = 15;
	$page = intval ( $_GET['page'] ) ? intval ( $_GET['page'] ) : 1;
	$start = ($page - 1) * $perpage;
	if ($start < 0) $start = 0;
	$count = C::t("#tshuz_floor#floor")->count();
	$multi=	multi($count, $perpage, $page, ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod']);
	$list = C::t("#tshuz_floor#floor")->range($start,$perpage,'dateline desc');
	/*数据展示*/
	showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod']);
	showtableheader();
	$href = ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod']."&formhash=".FORMHASH;
	showsubtitle(array($dlang['lang014'],$dlang['lang015'],$dlang['lang016'],$dlang['lang019'],$dlang['lang017']));
	if(!function_exists("parsesmiles"))
		include libfile("function/discuzcode");
	foreach($list as $reply){
		showtablerow('',
			array('','class="td24"','class="td31"','class="td25"'), 
			array(
				parsesmiles(dhtmlspecialchars($reply['content'])),
				'<a href="home.php?mod=space&uid='.$reply['uid'].'" target="_blank">'.$reply['username'].'</a>',
				date("Y-m-d H:i:s",$reply['dateline']),
				"<a href='forum.php?mod=redirect&goto=findpost&pid={$reply['pid']}' target='_blank'>{$dlang['lang019']}</a>",
				"<a href='{$href}&lid={$reply['lid']}' style='color:red'>{$dlang['lang018']}</a>"
			)
		);
	}
	if($multi) showtablerow('',array('colspan=8 style="text-align: right;"'), array($multi));
	showtablefooter();/*dis'.'m.tao'.'bao.com*/
	showformfooter();/*Dism_taobao_com*/
	echo <<<EOF
	<style> td img {max-height:2em;}
EOF;
}
//From: Dism.taobao-com
?>