<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_floor extends discuz_table{
	public function __construct() {
		$this->_table = 'tshuz_floor';
		$this->_pk    = 'lid';
		parent::__construct();/*dism��taobao��com*/
	}

	public function count_by_pids($pids){
		$where = DB::field("pid",$pids);
		$result = DB::fetch_all("SELECT count(*) AS count,pid FROM %t where %i GROUP BY pid",array($this->_table,$where));
		$return = array();
		foreach($result as $floor){
			$return[$floor['pid']] = $floor['count'];
		}
		return $return;
	}

	public function dfetch_all_by_pids($pids,$limit,$start = 0){
		global $_G;
		$where = DB::field("pid",$pids);
		$result = DB::fetch_all("SELECT * FROM %t WHERE %i ORDER BY dateline ASC LIMIT %d,%d",array($this->_table,$where,$start,$limit));
		$return = array();
		if(!function_exists("parsesmiles"))
			include libfile("function/discuzcode");
		foreach($result as $floor){
			$floor['content'] = dhtmlspecialchars($floor['content']);
			$floor['content'] = parsesmiles($floor['content']);
			$floor['dateline'] = dgmdate($floor['dateline'],'u');
			$return[$floor['pid']][] = $floor;
		}
		return $return;
	}

	public function fetch_all_by_pids($pids,$limit,$start = 0){
		global $_G;
		$return = array();
		if(!function_exists("parsesmiles"))
			include libfile("function/discuzcode");
		foreach($pids as $pid){
			$where = DB::field("pid",$pid);
			$result = DB::fetch_all("SELECT * FROM %t WHERE %i ORDER BY dateline ASC LIMIT 0,%d",array($this->_table,$where,$limit));
			foreach($result as $floor){
				$floor['content'] = dhtmlspecialchars($floor['content']);
				$floor['content'] = parsesmiles($floor['content']);
				$floor['dateline'] = dgmdate($floor['dateline'],'u');
				$return[$floor['pid']][] = $floor;
			}
		}
		return $return;
	}

	public function update_floor_by_lid_pid($lid,$pid){
		DB::query("UPDATE %t SET floor=floor-1 WHERE pid = %d AND lid>%d", array($this->table,$pid,$lid));
	}

}
//From: Dism_taobao-com
?>