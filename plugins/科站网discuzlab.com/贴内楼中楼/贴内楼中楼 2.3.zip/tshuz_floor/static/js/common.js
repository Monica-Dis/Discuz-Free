var jq= jQuery.noConflict();
jq(function(){
	jq(".icon-reply").click(function(){
		jq(this).parent().find(".reply_area").show()
	})
	jq(".tshuz_title").click(function(){
		var replyObject = jq(this).parent().find(".tshuz_reply");
		if(replyObject.is(":visible")){
			replyObject.hide();
			jq(this).html(langs[1]).removeClass("nobottom");
		}else{
			replyObject.show()
			jq(this).html(langs[0]).addClass("nobottom");;
		}
	})
	
})

function dshowmore(PID){
	var lilength = jq("#floor_"+PID).find("li").length;
	var x = new Ajax();
	var showurl = 'plugin.php?id=tshuz_floor&mod=show&pid='+PID+'&s='+lilength+'&formhash='+dformhash;
	x.get(showurl , function(res,tshuz_floor) {
		if(res == 'formhasherror'){
			showDialog(langs[3],'alert');
		}else if(res == 'paramerror'){
			showDialog(langs[4],'alert');
		}else if(res == 'replynone'){
			showDialog(langs[5],'alert');
		}else if(res == ''){
			showDialog(langs[2],'alert');
		}else{
			var strs= new Array(); //定义一数组
			strs = res.split("####");
			console.log(strs)
			jq("#floor_"+PID+" .tshuz_reply .nobottom").before(strs[1]);
			if(strs[0] != "0"){
				jq("#floor_"+PID+" #reply_more i").html(strs[0]);
			}else{
				jq("#floor_"+PID+" #reply_more").hide();
			}
		}
	});
}

function dreply(pid,uid,username){
	var replyObject = jq("#floor_"+pid+" .reply_area").show();
	jq("#floor_"+pid+" input[name='duid']").val(uid);
	jq("#floor_"+pid+" input[name='dusername']").val(username);
}

function dreplysubmit(pid){
	if(nowuid == '0'){
		showWindow('login', 'member.php?mod=logging&action=login');return false;
	}
	
	var cnt = jq("#floor_"+pid+" .reply_cnt").val();
	var uid = jq("#floor_"+pid+" input[name='duid']").val();
	if(cnt.length<1){
		showDialog(langs[6],'alert');return false;
	}
	var username = jq("#floor_"+pid+" input[name='dusername']").val();

	jq.ajax({
		url:'plugin.php',
		type:'POST', //GET
		async:true,    //或false,是否异步
		data:{
			id:'tshuz_floor',mod:'submit',pid:pid,formhash:dformhash,cnt:cnt,duid:uid,uname:username
		},
		dataType:'json',    //返回的数据格式：json/xml/html/script/jsonp/text
		success:function(data){
			res = data.msg;
			if(res == 'formhasherror'){
				showDialog(langs[3],'alert');
			}else if(res == 'paramerror'){
				showDialog(langs[4],'alert');
			}else if(res == 'contenterror'){
				showDialog(langs[6],'alert');
			}else if(res == 'contentcherror'){
				showDialog(langs[8],'alert');
			}else if(res == 'contentlengerror'){
				showDialog(langs[9],'alert');
			}else if(res == 'no_access'){
				showDialog(langs[10],'alert');
			}else if(res == 'tologin'){
				showWindow('login', 'member.php?mod=logging&action=login');return false;
			}else if(res.substr(0,7) == 'success'){
				content = cnt;
				var str = '';
				if(uid && username && uid != nowuid){
					str += '&nbsp;'+langs[7]+'&nbsp;<a class="tshuz_at" href="home.php?mod=space&uid='+uid+'" target="_blank" >'+username+'</a>';
				}
				var html = '<li><a href="home.php?mod=space&uid='+nowuid+'" target="_blank" class="avatar">'+nowavatar+'</a><div class="tshuz_cnt"><a class="tshuz_at" href="home.php?mod=space&uid='+nowuid+'" target="_blank" >'+nowusername+'</a>'+str+'&nbsp;:&nbsp;<span class="tshuz_cnt_main">'+content+'</span><div class="tshuz_time">'+langs[7]+'</div></div></li>';
				jq("#floor_"+pid+" .tshuz_reply .nobottom").before(html);
				jq("#floor_"+pid+" .reply_cnt").val('');
				jq("#floor_"+pid+" input[name='duid']").val('');
				jq("#floor_"+pid+" input[name='dusername']").val('');
			}else{
				showDialog(langs[2],'alert');
			}
		},
		error:function(xhr,textStatus){
			showDialog(langs[2],'alert');
		}
	})	
	return false;
}


	jq(".smiley").click(function(){
		var faceId = jq(this).attr("id");
		dsmiley(faceId);
	})
function dsmiley(pid,v){
	smilies_show('fastpostsmiliesdiv_'+pid, 8, 'fastpost_'+pid);
	showMenu({'ctrlid':'fastpost_'+pid+'sml','evt':'click','layer':2});
}