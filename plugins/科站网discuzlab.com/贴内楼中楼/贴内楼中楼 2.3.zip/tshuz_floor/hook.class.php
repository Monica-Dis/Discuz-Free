<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_tshuz_floor_forum {
	function viewthread_postbottom_output(){
		global $_G,$postlist;
		$pvars = $_G['cache']['plugin']['tshuz_floor'];
		$returns = $pids = array();
		foreach($postlist as $post){
			if(!$post['first']){
				$pids[] = $post['pid'];
			}elseif($pvars['first']){
				$pids[] = $post['pid'];
			}
		}
		require DISCUZ_ROOT . './source/plugin/tshuz_floor/function/lang.php';
		$floors = C::t("#tshuz_floor#floor")->fetch_all_by_pids($pids,$pvars['default']);
		$counts = C::t("#tshuz_floor#floor")->count_by_pids($pids);
		$allowed = in_array($_G['groupid'],unserialize($pvars['groups']));
		foreach($postlist as $k=>$post){
			if(!$post['first']){
				include template("tshuz_floor:floor");
				$returns[] = $return;
			}elseif($pvars['first']){
				include template("tshuz_floor:floor");
				$returns[] = $return;
			}else{
				$returns[] = '';
			}
		}
		return $returns;
	}

	function viewthread_top(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_floor'];
		require DISCUZ_ROOT . './source/plugin/tshuz_floor/function/lang.php';
		$return = '
		<link rel="stylesheet" href="source/plugin/tshuz_floor/static/css/common.css" type="text/css"/>
		<script src="source/plugin/tshuz_floor/static/js/jquery.min.js" type="text/javascript"></script>
		<script type="text/javascript">
		var dformhash = \''.FORMHASH.'\';
		var nowuid= \''.$_G['uid'].'\';
		var nowusername = \''.$_G['username'].'\';
		var nowavatar = \'<img src="'.avatar($_G['uid'],'small',1).'" />\';
		var langs = [\''.$dlang['lang001'].$pvars['min'].$dlang['lang002'].'\',\''.lang('plugin/tshuz_floor','SfTNOj').'\'];
		</script>
		<script src="source/plugin/tshuz_floor/static/js/common.js" type="text/javascript"></script>';
		
		return $return;
	}

}
//From: Dism_taobao-com
?>