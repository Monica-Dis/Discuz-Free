<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require DISCUZ_ROOT . './source/plugin/tshuz_floor/function/lang.php';
$pvars = $_G['cache']['plugin']['tshuz_floor'];
if($_GET['formhash'] != FORMHASH) dshow('formhasherror');
$pid = dintval($_GET['pid']);
$mod = $_GET['mod'];
if($mod == 'show'){
	$start = dintval($_GET['s']);
	if(!$pid || !$start) dshow('paramerror');
	$start -= 1;
	$floors = C::t("#tshuz_floor#floor")->dfetch_all_by_pids($pid,$pvars['default'],$start);
	$counts = C::t("#tshuz_floor#floor")->count_by_pids($pid);
	$surplus = $counts[$pid]-($start-1+$pvars['default'])-1;
	$surplus = $surplus>0?$surplus:0;
	$floors = $floors[$pid];
	if(!$floors) dshow("replynone");
	$msg = $surplus.'####';
	if(!function_exists("parsesmiles"))
		include libfile("function/discuzcode");

	foreach($floors as $floor){
		$avatar = avatar($floor['uid'],'small');
		$extends = dunserialize($floor['extends']);
		$floor['content'] = parsesmiles(stripslashes($floor['content']."") );
		$str = '';
		if($extends){
			$str = "&nbsp;".$dlang['lang003']."&nbsp;<a class=\"tshuz_at\" href='home.php?mod=space&uid={$extends['duid']}' target=\"_blank\" title=\"{$extends['dusername']}".$dlang['lang004']."\">{$extends['dusername']}</a>";
		}
		if(!defined("IN_MOBILE")){
		$msg .= <<<EOF
	<li><a href='home.php?mod=space&uid={$floor['uid']}' target="_blank" title="{$floor['username']}{$dlang['lang004']}" class="avatar">{$avatar}</a><div class="tshuz_cnt"><a class="tshuz_at" href='home.php?mod=space&uid={$floor['uid']}' target="_blank" title="{$floor['username']}{$dlang['lang004']}">{$floor['username']}</a>{$str}&nbsp;:&nbsp;<span class="tshuz_cnt_main">{$floor['content']}</span><div class="tshuz_time">{$floor['dateline']}<span class="pipe">|</span><a href="javascript:;" onclick="dreply('{$floor['pid']}','{$floor['uid']}','{$floor['username']}');" class="tshuz_at">{$dlang['lang003']}</a></div></div></li>
EOF;
		}else{
			$msg .= <<<EOF
	<li><a class="tshuz_at" href='home.php?mod=space&uid={$floor['uid']}' target="_blank" title="{$floor['username']}{$dlang['lang004']}">{$floor['username']}</a>{$str}&nbsp;:&nbsp;<span class="tshuz_cnt_main">{$floor['content']}</span>&nbsp;<span class="tshuz_time grey rela">{$floor['dateline']}</span></li>
EOF;
		}
	}
}elseif($mod == 'submit'){
	if(!$_G['uid']) dshow('tologin');
	if(!$pid) dshow('paramerror');
	if(!in_array($_G['groupid'],unserialize($pvars['groups']))) dshow('no_access');
	$data = array();
	$data['pid'] = $pid;
	$data['content'] = daddslashes($_GET['cnt']);
	if(strtolower($_G['charset']) != 'utf-8'){
		$data['content'] = mb_convert_encoding($data['content'],$_G['charset'],'utf-8');
	}
	if(strtolower($_G['charset']) != 'utf-8' && $_GET['uname']){
		$_GET['uname'] = mb_convert_encoding($_GET['uname'],$_G['charset'],'utf-8');
	}
	if(!$data['content']) dshow('contenterror');
	$filter = dunserialize($pvars['filter']);
	if(in_array(2,$filter) && strlen($data['content'])<$pvars['min'] ){
		 dshow('contentlengerror');
	}
	if(in_array(1,$filter) && !preg_match("/[\x7f-\xff]/",$data['content']) ){
		 dshow('contentcherror');
	}
	$data['uid'] = $_G['uid'];
	$data['username'] = $_G['username'];
	$duid = dintval($_GET['duid']);
	$dusername = daddslashes($_GET['uname']);
	$extends = array();
	if($duid && $dusername && $duid != $_G['uid']){
		$extends = array(
			"duid"=>$duid,
			'dusername'=>$dusername
		);
	}
	$counts = C::t("#tshuz_floor#floor")->count_by_pids($pid);
	if($counts){
		$data['floor'] = $counts[$pid]['count']+1;
	}
	$data['dateline'] = TIMESTAMP;
	$data['extends'] = serialize($extends);
	$floorid = C::t("#tshuz_floor#floor")->insert($data,true);
	$tmp = explode(PHP_EOL,$pvars['ruler']);
	$ruler = array();
	foreach($tmp as $t){
		list($ext,$num) = explode("|",$t,2);
		$ext = dintval($ext);
		$num = dintval($num);
		if($ext && $num){
			$ruler['extcredits'.$ext] = $num;
		}
	}
	if($ruler)
		updatemembercount($_G['uid'], $ruler);
	include_once libfile('function/magic');
	$post = getpostinfo($pid, 'pid', array('p.first', 'p.tid', 'p.fid', 'p.authorid', 'p.rate', 't.status as thread_status'));
	$senduid = $extends?$extends['duid']:$post['authorid'];
	if($senduid != $_G['uid']){
		$thread = getpostinfo($post['tid'], 'tid', array('fid', 'authorid', 'subject'));
		$reppost_noticeauthor = $dlang['lang005'];
		notification_add($senduid, 'post', $reppost_noticeauthor, array(
			'tid' => $post['pid'],
			'subject' => $thread['subject'],
			'fid' => $thread['fid'],
			'pid' => $pid,
			'from_id' => $thread['tid'],
			'from_idtype' => 'post',
		));
	}
	if(!function_exists("parsesmiles"))
		include libfile("function/discuzcode");
	
	$content = parsesmiles(dhtmlspecialchars(stripslashes($data['content'])) );
	dshow('success'.str_replace('"','\'',$content));
}
dshow($msg);
function dshow($msg){
	global $mod;
	if($mod == 'show'){
		if(!defined("IN_MOBILE")){
			include template('common/header_ajax');
			echo $msg;
			include template('common/footer_ajax');
			dexit();
		}else{
			echo $msg;exit;
		}
		exit;
	}
	$data = array('msg'=>urlencode($msg));
	$json = json_encode( $data);
	$echo = urldecode($json);
	echo $echo;exit;
	
}
//From: Dism.taobao-com
?>