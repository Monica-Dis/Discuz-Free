<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_tshuz_floor_forum {
	function viewthread_postbottom_mobile_output(){
		global $_G,$postlist;
		$pvars = $_G['cache']['plugin']['tshuz_floor'];
		$returns = $pids = array();
		require DISCUZ_ROOT . './source/plugin/tshuz_floor/function/lang.php';
		$extends = DISCUZ_ROOT.'./source/plugin/tshuz_floor/extends/mobile.php';
		if(file_exists($extends)) include $extends;
		return $returns;
	}

	function viewthread_top_mobile(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_floor'];
		$extends = DISCUZ_ROOT.'./source/plugin/tshuz_floor/extends/mobile.php';
		require DISCUZ_ROOT . './source/plugin/tshuz_floor/function/lang.php';
		$return = '';
		if(file_exists($extends)){
			$return = '
		<link rel="stylesheet" href="source/plugin/tshuz_floor/static/css/mobile.css" type="text/css"/>
		<script type="text/javascript">
		var dformhash = \''.FORMHASH.'\';
		var nowuid= \''.$_G['uid'].'\';
		var nowusername = \''.$_G['username'].'\';
		var nowavatar = \''.avatar($_G['uid'],'small').'\';
		var langs = [\''.$dlang['lang001'].$pvars['min'].$dlang['lang002'].'\'];
		</script>
		<script src="source/plugin/tshuz_floor/static/js/mobile.js" type="text/javascript"></script>';
		}
		return $return;
	}
}
//From: Dism_taobao-com
?>