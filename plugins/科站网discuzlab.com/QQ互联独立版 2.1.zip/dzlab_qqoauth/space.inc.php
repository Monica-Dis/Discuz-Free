<?php

/**
 *      Copyright 2001-2099 DisM!应用中心.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: space.inc.php 2017-11-13 16:58:27Z DisM.taobao.Com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */
if(!$_G['uid']) showmessage('to_login', null, array(), array('showmsg' => true, 'login' => 1));
$bindinfo = C::t("#dzlab_qqoauth#user")->fetch($_G['uid']);
if(submitcheck('unbind') && $bindinfo){
	C::t("#dzlab_qqoauth#user")->delete($_G['uid']);
	C::t('common_member')->update($_G['uid'], array('conisbind' => 0));
	showmessage(lang('plugin/dzlab_qqoauth','AD4CKk'),dreferer());
}
if(defined('IN_MOBILE') == 2){
	include template('dzlab_qqoauth:space');exit;
}