<?php

/**
 *      Copyright 2001-2099 DisM!应用中心.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: mobile.class.php 2017-11-10 14:22:28Z DisM.taobao.Com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */

class mobileplugin_dzlab_qqoauth_member {
	function logging_bottom_mobile(){
		global $_G;
		return '<a href="plugin.php?id=dzlab_qqoauth" style="display:block;background:'.$_G['cache']['plugin']['dzlab_qqoauth']['color'].';width: 289px; color:#fff;margin: 10px auto;border-radius: 3px;font-size: 16px;padding: 10px 0;text-align: center;" rel="nofollow">'.lang('plugin/dzlab_qqoauth','U26J0p').'</a>';
	}
}
class mobileplugin_dzlab_qqoauth {
	function global_footer_mobile(){
		global $_G;
		$return = CURSCRIPT =='member' && CURMODULE =='register' && $_G['cache']['plugin']['dzlab_qqoauth']['only']?'<script>window.location.href="plugin.php?id=dzlab_qqoauth"</script>':'';
		return $return ;
	}
}