<?php

/**
 *      Copyright 2001-2099 DisM!应用中心.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: hook.class.php 2017-11-10 14:22:15Z DisM.taobao.Com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */

class plugin_dzlab_qqoauth {
	function global_login_extra(){
		global $_G;
		return $this->dzlab_qqoauth_show(2);
	}

	function global_login_text(){
		global $_G;
		return $this->dzlab_qqoauth_show(3);
	}

	function global_usernav_extra4(){
		global $_G;
		if($_G['member']['conisbind']) return '';
		return $this->dzlab_qqoauth_show(4);
	}

	public function dzlab_qqoauth_show($type = 1){
		global $_G;
		if($_G['uid'] && $type != 4) return '';
		include template("dzlab_qqoauth:login".$type);
		return $return;
	}
}

class plugin_dzlab_qqoauth_member extends plugin_dzlab_qqoauth{
	function register_logging_method(){
		global $_G;
		return $this->dzlab_qqoauth_show();
	}

	function logging_method(){
		global $_G;
		return $this->dzlab_qqoauth_show();
	}

	function register_side_top(){
		global $_G;
		$return = $_G['cache']['plugin']['dzlab_qqoauth']['only']?'<script>window.location.href="plugin.php?id=dzlab_qqoauth"</script>':'';
		return $return ;

	}
}
//From: dis'.'m.tao'.'bao.com
?>