<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
require_once '../../class/class_core.php';
$discuz = C::app();
$discuz->init();
$param = array();
loadcache("plugin");
$config = $_G['cache']['plugin']['dzlab_qqoauth'];
$appid = 1;
if(!$_GET['code']){//获取Authorization Code
	$getWay = 'https://graph.qq.com/oauth2.0/authorize';
	$param['response_type'] 	= 'code';
	$param['client_id'] 		= $config['appid'];
	$param['redirect_uri']		= urlencode($_G['siteurl'].'connect.php');
	$param['state']				= $appid;
	dheader("location:".$getWay.'?'.makeUrl($param));exit;
}else{
	/* 获取access_token */
	$getWay = 'https://graph.qq.com/oauth2.0/token';
	$param['grant_type'] 		= 'authorization_code';
	$param['client_id'] 		= $config['appid'];
	$param['client_secret'] 	= $config['appkey'];
	$param['code'] 				= $_GET['code'];
	$param['redirect_uri']		= urlencode($_G['siteurl'].'connect.php');
	$url = $getWay.'?'.makeUrl($param);
	$response = dfsockopen($url);
	if(strpos($response, "callback") === false) {
		parse_str($response,$data);
		$access_token = $data['access_token'];
		/* 获取openid */
		$getWay = 'https://graph.qq.com/oauth2.0/me';//WAP网站：https://graph.z.qq.com/moc2/me
		$getWay .= '?access_token='.$access_token;
		$response = dfsockopen($getWay);
		$data = callback($response);
		if($data['error']){
			showmsg($data['error_description'],$data['error']);
		}else{
			$openid = $data['openid'];//终于拿到openid了
			/* 获取用户信息 */
			$getWay = 'https://graph.qq.com/user/get_user_info';
			$param = array();
			$param['access_token'] 			= $access_token;
			$param['oauth_consumer_key'] 	= $config['appid'];
			$param['openid'] 				= $openid;
			$url = $getWay.'?'.http_build_query($param);
			$response = dfsockopen($url);
			$data = json_decode($response,true);
			if($data['nickname']){
				$return = array();
				$return['openid'] = $openid;
				$return['nickname'] = $data['nickname'];
				showmsg($return,'success');//成功
			}else{
				showmsg($data['msg'],$data['ret']);
			}
		}
	}else{
		$data = callback($response);
		showmsg($data['error_description'],$data['error']);
	}
}

function callback($response) {
	$lpos = strpos($response, "(");
	$rpos = strrpos($response, ")");
	$response = substr($response, $lpos + 1, $rpos - $lpos - 1);
	return json_decode($response,true);
}

function makeUrl($param = array()){
	$return = array();
	foreach($param as $k=>$v){
		$return[] = $k.'='.$v;
	}
	return implode('&',$return);
}

function showmsg($msg,$code){
	global $_G,$config;
	$data = array("error"=>$code,"msg"=>$msg);
	$data = authcode(json_encode($data),"ENCODE",$config['appkey']);
	$_G['siteurl'] = str_replace('source/plugin/dzlab_qqoauth/','',$_G['siteurl']);
	dheader ("location:".$_G['siteurl'].'plugin.php?id=dzlab_qqoauth&mod=callback&data='.urlencode($data));exit;
}
//From: d'.'is'.'m.ta'.'obao.com
?>