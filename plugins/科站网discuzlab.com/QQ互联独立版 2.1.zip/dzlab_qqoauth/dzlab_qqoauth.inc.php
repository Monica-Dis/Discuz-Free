<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$mod = $_GET['mod'];
$pvars = $_G['cache']['plugin']['dzlab_qqoauth'];
if($mod == 'callback'){
	$data = authcode($_GET['data'],"DECODE",$pvars['appkey']);
	$data = json_decode($data,true);
	if($data['error'] != 'success' || !$data['msg']['openid']){
		showmessage(lang('plugin/dzlab_qqoauth','XE3YAi').$data['error']);
	}else{//具体逻辑
		$openid = addslashes($data['msg']['openid']);
		if($_G['uid']){//绑定
			$binduid = C::t("#dzlab_qqoauth#user")->fetch_by_openid($openid);
			if($binduid != $_G['uid'] && $binduid)  showmessage(lang('plugin/dzlab_qqoauth','Lk0Ys8'));
			$user = C::t("#dzlab_qqoauth#user")->fetch($_G['uid']);
			if($user && $user['openid']){
				showmessage(lang('plugin/dzlab_qqoauth','Lk0Ys8'));
			}
			if(!$user){
				C::t("#dzlab_qqoauth#user")->insert(array("uid"=>$_G['uid'],"openid"=>$openid));
			}else{
				C::t("#dzlab_qqoauth#user")->update($_G['uid'],array("openid"=>$openid));
			}
			C::t('common_member')->update($_G['uid'], array('conisbind' => 1));
			showmessage(lang('plugin/dzlab_qqoauth','D3iAEt'),'home.php?mod=spacecp&ac=plugin&id=dzlab_qqoauth:space');	
		}else{
			$user = C::t("#dzlab_qqoauth#user")->fetch_by_openid($openid);
			if($user){
				duserlogin($user,lang('plugin/dzlab_qqoauth','LEmEM3'),$_G['siteurl']);
			}
			$nickname = addslashes($data['msg']['nickname']);
			if($_G['charset'] != 'utf-8'){
				$nickname = mb_convert_encoding($nickname,$_G['charset'],'utf-8');
			}
			include template("dzlab_qqoauth:reg");
		}
	}
}elseif($mod == 'reg'){
	$openid = urldecode($_GET['openid']);
	$user = C::t("#dzlab_qqoauth#user")->fetch_by_openid($openid);
	if($user['uid']){
		duserlogin($user['uid'],lang('plugin/dzlab_qqoauth','LEmEM3'),$referer);
	}
	$referer = $_G['siteurl'];
	if(submitcheck('regsubmit')){
		if($_GET['pwd1'] != $_GET['pwd2'] ) showmessage(lang('plugin/dzlab_qqoauth','bclU84'));
		if(strlen($_GET['pwd1']) < 6) showmessage(lang('plugin/dzlab_qqoauth','S54L8e'));
		if(!isemail($_GET['email'])) showmessage(lang('plugin/dzlab_qqoauth','Q4GCl8'));
		$password = addslashes($_GET['pwd1']);
		/* 检查用户名 */
		$username = trim(addslashes($_GET['username']));
		$usernamelen = dstrlen($username);
		if($usernamelen < 3) {
			showmessage('profile_username_tooshort', '', array(), array('handle' => false));
		} elseif($usernamelen > 15) {
			showmessage('profile_username_toolong', '', array(), array('handle' => false));
		}

		loaducenter();
		$ucresult = uc_user_checkname($username);

		if($ucresult == -1) {
			showmessage('profile_username_illegal', '', array(), array('handle' => false));
		} elseif($ucresult == -2) {
			showmessage('profile_username_protect', '', array(), array('handle' => false));
		} elseif($ucresult == -3) {
			if(C::t('common_member')->fetch_by_username($username) || C::t('common_member_archive')->fetch_by_username($username)) {
				showmessage('register_check_found', '', array(), array('handle' => false));
			} else {
				showmessage('register_activation', '', array(), array('handle' => false));
			}
		}

		$censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';
		if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
			showmessage('profile_username_protect', '', array(), array('handle' => false));
		}
		//添加用户
		$ip = $_G['clientip'];
		$user = array();
		$user['name'] = $username;	
		$user['pwd'] = $password;
		$user['email'] = daddslashes($_GET['email']);
		$uid = uc_user_register($user['name'], $user['pwd'], $user['email']);
		$errors = array(
			'-1'=>lang('plugin/dzlab_qqoauth','fZGc7a'),
			'-2'=>lang('plugin/dzlab_qqoauth','K7Ulk4'),
			'-3'=>lang('plugin/dzlab_qqoauth','w7Gg8E'),
			'-4'=>lang('plugin/dzlab_qqoauth','g44CsC'),
			'-5'=>lang('plugin/dzlab_qqoauth','Pmzl4u'),
			'-6'=>lang('plugin/dzlab_qqoauth','DZ7vva')
		);
		if($uid<=0){
			showmessage($errors[$uid]);
		}  
		C::t('common_member')->insert($uid, $user['name'], md5(random(10)), $user['email'], $ip, $_G['setting']['newusergroupid'], null);
		//推广注册
		if($_G['cookie']['promotion']){
			$fromuid = $_G['cookie']['promotion'];
			if($fromuid) {
				updatecreditbyaction('promotion_register', $fromuid);
				dsetcookie('promotion', '');
			}
		}
		//初始化积分
		$defaultext = array();
		$initcredits = explode(",",$_G['setting']['initcredits']);
		foreach($initcredits as $keyNum => $initcredit){
			if($keyNum>0 && $initcredit){
				$defaultext['extcredits'.$keyNum] = $initcredit;
			}
		}
		updatemembercount($uid, $defaultext, 1);
		$user = array();
		$user['uid'] = $uid;
		$user['openid'] = $openid;
		C::t("#dzlab_qqoauth#user")->insert($user);
		//更新
		require_once libfile('cache/userstats', 'function');
		build_cache_userstats();
		//仿造QQ互联
		//C::t("#qqconnect#common_member_connect")->insert(array('uid'=>$uid,'conopenid'=>$openid,'conisfeed'=>1));
		C::t('common_member')->update($user['uid'], array('conisbind' => 1));
		//登陆
		duserlogin($uid,lang('plugin/dzlab_qqoauth','LEmEM3'),$referer);
	}elseif(submitcheck('loginsubmit')){//绑定
		loaducenter();
		list($uid, $username, $password, $email) = uc_user_login(daddslashes($_GET['username']), daddslashes($_GET['password']),0,1,intval($_GET['questionid']),daddslashes($_GET['answer']));
		if($uid > 0) {
			$user = array();
			$user['uid'] = $uid;
			$user['openid'] = $openid;
			C::t("#dzlab_qqoauth#user")->insert($user);
			C::t('common_member')->update($user['uid'], array('conisbind' => 1));
			duserlogin($uid,lang('plugin/dzlab_qqoauth','W1WBs2'),$referer);
		} elseif($uid == -1) {
			showmessage(lang('plugin/dzlab_qqoauth','s26lW6'));
		} elseif($uid == -2) {
			showmessage(lang('plugin/dzlab_qqoauth','Wwmj8l'));
		} else {
		}
	}
}else{
	$refer = dreferer();
	if(!$pvars['appid'] || !$pvars['appkey']) showmessage(lang('plugin/dzlab_qqoauth','Nnlcm0'));
	dheader("location:source/plugin/dzlab_qqoauth/connect.php?appid={$pvars['appid']}");exit;
}

function duserlogin($uid,$msg,$referer){
	$user = getuserbyuid($uid);
	require_once libfile('function/member');
	setloginstatus($user, 2592000);
	dsetcookie('dzlab_qqoauth',2);
	showmessage($msg,$referer);
}

//From: di'.'sm.t'.'aoba'.'o.com
?>