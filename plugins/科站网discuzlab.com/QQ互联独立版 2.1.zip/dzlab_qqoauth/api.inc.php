<?php

/**
 *      Copyright 2001-2099 DisM!应用中心.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: api.inc.php 2017-11-13 17:28:55Z DisM.taobao.Com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* 插件代码开始 */
showtips(lang('plugin/dzlab_qqoauth','XjJnCS',array("siteurl"=>$_G['siteurl'])));
?>