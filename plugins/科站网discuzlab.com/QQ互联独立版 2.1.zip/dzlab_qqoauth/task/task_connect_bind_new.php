<?php

/**
 *      [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: task_connect_bind.php 22196 2011-04-26 02:02:52Z dis'.'m.t'.'ao'.'bao.com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include libfile('extend/task','plugin/dzlab_qqoauth');