<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_clean extends discuz_table {

	public function __construct() {
		$this->_table = 'forum_attachment_unused';
		$this->_pk = 'aid';
		parent::__construct();
	}

	public function count_by_dateline($start,$end){
		$where = array();
		if($start){
			$where[] = DB::field("dateline", $start,">=");
		}
		if($end){
			$where[] = DB::field("dateline", $end,"<");
		}
		$where = implode(" AND ", $where);
		return DB::result_first("SELECT count(*) FROM %t WHERE %i",array($this->_table,$where));
	}

	public function fetch_by_dateline($start,$end,$perpage){
		$where = array();
		if($start){
			$where[] = DB::field("dateline", $start,">=");
		}
		if($end){
			$where[] = DB::field("dateline", $end,"<");
		}
		$where = implode(" AND ", $where);
		return DB::fetch_all("SELECT * FROM %t WHERE %i limit 0,%d",array($this->_table,$where,$perpage));
	}
}