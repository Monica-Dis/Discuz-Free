<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require DISCUZ_ROOT . './source/plugin/tshuz_cleanunused/function/lang.php';
if($_GET['formhash'] == FORMHASH){
	$file = DISCUZ_ROOT . './source/plugin/tshuz_cleanunused/extend/clean.php';
	$baseDir = DISCUZ_ROOT ;
	$perpage = 100;
	$extend = '';
	if(($_GET['start'] || $_GET['end']) && file_exists($file)){
		require $file;
	}else{
		$count = C::t("#tshuz_cleanunused#log")->count();//总数
		$list = C::t("#tshuz_cleanunused#log")->range(0, $perpage);
	}
	$cpmsg = 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod'];

	$aids = array();
	foreach ($list as $val) {
		$aids[] = $val['aid'];
		$file = $_G['setting']['attachdir'].'forum/'.$val['attachment'];
		@unlink($file);//删除文件
		if($val['thumb'])
			@unlink($file.".thumb.jpg");//删除缩略图文件

	}
	C::t("#tshuz_cleanunused#log")->delete($aids);//清除数据
	$surplus = $count-count($list);
	if(!$surplus) cpmsg($dlang['lang001'],$cpmsg,'succeed');
	$cpmsg .= "&formhash=".FORMHASH.$extend;
	//echo $cpmsg;exit;
	$tip = $dlang['lang002'].count($list).$dlang['lang003'].$surplus.$dlang['lang004'];

	cpmsg($tip,$cpmsg,'loadingform');
}else{
	showtips($dlang['lang007']);
	$file = DISCUZ_ROOT . './source/plugin/tshuz_cleanunused/extend/setting.php';
	showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod']);
	showtableheader($dlang['lang005']);
	if(	file_exists($file)){
		require $file;
	}
	showsubmit("submit",$dlang['lang006']);
	showtablefooter();/*dism-Taobao-com*/
	/*di'.'sm.t'.'aoba'.'o.com*/showformfooter();
}
//From: Dism·taobao·com
?>