<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
showsetting($dlang['lang008'], 'start', "", 'calendar');
showsetting($dlang['lang009'], 'end', date("Y-m-d",TIMESTAMP), 'calendar');
?>