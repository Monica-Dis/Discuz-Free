<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$start = strtotime($_GET['start']);
$end = strtotime($_GET['end']);
$count = $count = C::t("#tshuz_cleanunused#clean")->count_by_dateline($start,$end);
$list = C::t("#tshuz_cleanunused#clean")->fetch_by_dateline($start,$end, $perpage);
$extend .= $_GET['start']?"&start=".$_GET['start']:'';
$extend .= $_GET['end']?"&end=".$_GET['end']:'';
?>