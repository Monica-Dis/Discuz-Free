<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$dlang = array();
for($i=1;$i<=9;$i++){
	$key = 'lang'.sprintf("%03d", $i);
	$dlang[$key] = lang('plugin/tshuz_cleanunused', $key);
}
//From: Dism��taobao��com
?>