<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_tshuz_ad2thread_advers`;
CREATE TABLE `cdb_tshuz_ad2thread_advers` (
  `aid` int(8) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `forums` text,
  `startline` int(10) DEFAULT NULL,
  `endline` int(10) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(80) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `href` varchar(255) DEFAULT NULL,
  `cover` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM;
DROP TABLE IF EXISTS `cdb_tshuz_ad2thread_forums`;
CREATE TABLE `cdb_tshuz_ad2thread_forums` (
  `fid` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  KEY `aid` (`aid`),
  KEY `fid` (`fid`)
) ENGINE=MyISAM;
EOF;
runquery($sql);

$identifier = 'tshuz_ad2thread';
/* 删除文件 */
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/upgrade.php');
@unlink($entrydir.'/install.php');
$finish = TRUE; /*dism·taobao·com*/