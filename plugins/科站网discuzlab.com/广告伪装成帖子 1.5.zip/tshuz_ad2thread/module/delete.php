<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$aid = dintval($_GET['aid']);
if(!$aid || $_GET['hash'] != FORMHASH) cpmsg($lang['lang019'],"","error");
/* 删广告设置 */
C::t("#tshuz_ad2thread#advers")->delete($aid);
/* 删版块设置 */
C::t("#tshuz_ad2thread#forums")->delete_by_aid($aid);
$hrefUrl = 'action=plugins&operation=config&do=';
$hrefUrl .= $_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod'];
cpmsg($lang['lang009'],$hrefUrl,"succeed");
?>