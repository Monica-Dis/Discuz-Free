<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(submitcheck('submit')){
	$get = $_GET['set'];
	$data = $forums = array();
	$data['title'] = daddslashes($get['title']);
	if(!$data['title']) cpmsg($langdlang['lang002'].$lang['lang003'],"","error");
	foreach($get['forums'] as $fid){
		if(dintval($fid)) $forums[] = $fid;
	}
	if(!$forums)  cpmsg($lang['lang004'].$lang['lang005'],"","error");
	$data['forums'] = serialize($forums);
	$data['startline'] = $get['start']?strtotime($get['start']):0;
	$data['endline'] = $get['end']?strtotime($get['end']):0;
	if($data['endline'] && $data['startline'] && $data['endline'] <= $data['startline']) 
		cpmsg($lang['lang006'],"","error");
	$data['subject'] = daddslashes($get['subject']);
	if(!$data['subject']) cpmsg($lang['lang002'].$lang['lang007'],"","error");
	$data['href'] = daddslashes($get['href']);
	if(!$data['href']) cpmsg($lang['lang002'].$lang['lang008'],"","error");
	$data['uid'] = dintval($get['uid'])?dintval($get['uid']):getRandUid();
	require_once libfile('function/member');
	$member = getuserbyuid($data['uid'], 1);
	$data['username'] = $member['username'];
	$data['cover'] = daddslashes($get['cover']);
	$aid = C::t("#tshuz_ad2thread#advers")->insert($data,true);
	$forumData = array("aid"=>$aid);
	foreach($forums as $fid){
		$forumData['fid'] = $fid;
		C::t("#tshuz_ad2thread#forums")->insert($forumData);
	}
	$hrefUrl = 'action=plugins&operation=config&do=';
	$hrefUrl .= $_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod'];
	cpmsg($lang['lang009'],$hrefUrl,"succeed");
}else{
	echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
	showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod'].'&op=add');
	showtableheader();
	showsetting($lang['lang003'], 'set[title]', '', 'text');
	$forums = getForums();
	showsetting($lang['lang005'], 'set[forums]', '', $forums, '', 0, $lang['lang010']."Shift".$lang['lang011']);
	showsetting($lang['lang012'], 'set[start]', '', 'calendar',0,0,$lang['lang013']);
	showsetting($lang['lang014'], 'set[end]', '', 'calendar',0,0,$lang['lang013']);
	showsetting($lang['lang007'], 'set[subject]', '', 'text');
	showsetting($lang['lang008'], 'set[href]', '', 'text');
	showsetting($lang['lang015'].'UID', 'set[uid]', '', 'number',0,0,$lang['lang016']);
	showsetting($lang['lang017'], 'set[cover]', '', 'text',0,0,$lang['lang018']);
	showsubmit("submit","submit");
	showtablefooter(); /*Dism��taobao��com*/
	showformfooter(); /*Dism_taobao_com*/
}
//From: dis'.'m.tao'.'bao.com
?>