<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$hrefUrl = ADMINSCRIPT.'?action=plugins&operation=config&do=';
$hrefUrl .= $_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod'];
$perpage = 10;
$page = dintval ( $_GET ['page'] ) ? dintval ( $_GET ['page'] ) : 1;
$start = ($page - 1) * $perpage;
if ($start < 0) $start = 0;
$count = C::t("#tshuz_ad2thread#advers")->count();
$multi=	multi($count, $perpage, $page, $hrefUrl);
$list = C::t("#tshuz_ad2thread#advers")->fetch_all_limit($start,$perpage);
$list = dhtmlspecialchars($list);
showtips("<li>{$lang['lang020']}</li><li><a href='".$hrefUrl."&op=add' style='color:red'>{$lang['lang021']}</a></li>");
showtableheader("", 'nobottom',"id='cpform'");
showsubtitle(array($lang['lang022'],$lang['lang023'],$lang['lang024']));
if(count($list)){
	foreach($list as $adver){
		showtablerow('', array(
			'',
			'width="200"',
			'width="70"'
		) , array(
			$adver['title'].($adver['cover']?'<img style="vertical-align: middle;" src="static/image/filetype/image_s.gif" />':""),
			dshowdate($adver['startline'],$adver['endline']),
			'<a style="color:green" href="'.$hrefUrl.'&op=edit&aid='.$adver['aid'].'">'.$lang['lang025'].'</a>&nbsp;|&nbsp;<a style="color:red" href="'.$hrefUrl.'&op=delete&hash='.FORMHASH.'&aid='.$adver['aid'].'">'.$lang['lang026'].'</a>'
		));
	}
	if($multi)
		showtablerow('',array('colspan=3 style="text-align: right;"'), array($multi));
}else{
	echo "<tr><td>{$lang['lang027']}</td><td width='200'></td><td width='70'></td></tr>";
}
showtablefooter(); /*Dism��taobao��com*/
?>