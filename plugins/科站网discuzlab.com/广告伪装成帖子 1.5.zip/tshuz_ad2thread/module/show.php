<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
		/* 取出所有版块广告aid */
		$aids = C::t("#tshuz_ad2thread#forums")->fetch_all($_G['fid']);
		/* 取出所有广告 */
		$advers = C::t("#tshuz_ad2thread#advers")->fetch_all_by_aids($aids);
		/* 过滤不符合时间限制的广告 */
		$dayLine = strtotime(date("Y-m-d",TIMESTAMP));
		foreach($advers as $k=>$adver){
			if( 
				($adver['startline'] && $dayLine<$adver['startline']) || 
				($adver['endline'] && $dayLine>$adver['endline'])
			 ){
				 unset($advers[$k]);
			}
		}
		$total = count($advers);//总广告数
		/* 插件设置的数目 */
		$pvars =  $_G['cache']['plugin']['tshuz_ad2thread'];
		$num = $pvars['nums'];
		$listcount = count($_G['forum_threadlist']);//当前帖子数
		$fa = 5;//阀值
		if($num*$fa>$listcount) return '';
		shuffle($advers);
		if($total > $num){//减少到目标数
			$advers = array_slice($advers, 0, $num);   
		}
		include DISCUZ_ROOT.'./source/plugin/tshuz_ad2thread/function/common.php';
		/* 插入广告 */
		foreach($advers as $adver){
			$random = mt_rand(0,count($_G['forum_threadlist']));
			$tmp = $_G['forum_threadlist'][$random]?$_G['forum_threadlist'][$random]:$_G['forum_threadlist'][--$random];
			$tmp['tid'] = 'adver&aid='.$adver['aid'];
			$tmp['author'] = $tmp['lastposter'] = $adver['username'];
			$tmp['authorid'] = $adver['uid'];
			$tmp['dbdateline'] = $tmp['dbdateline']+mt_rand(10,100);
			$tmp['dateline'] = dgmdate($tmp['dbdateline'], 'u', '9999', getglobal('setting/dateformat'));
			$tmp['dblastpost'] = $tmp['dblastpost']+mt_rand(10,100);
			$tmp['lastpost'] = dgmdate($tmp['dbdateline'], 'u');
			$tmp['replies'] = $tmp['allreplies'] = mt_rand(1,$pvars['range']);
			$tmp['views'] = $tmp['replies']+mt_rand(1,$pvars['range']);
			$tmp['attachment'] = 0;
			$tmp['folder'] = mt_rand(0,1)?"new":"common";
			$tmp['coverpath'] = $tmp['cover'] = $adver['cover'];
			$tmp['subject'] = $adver["subject"];
			$tmp['icon'] = '';
			$_G['forum_threadlist'] = addvtorandp($_G['forum_threadlist'],$random,$tmp);
		}
//From: Dism_taobao-com
?>