<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function dshowdate($startline,$endline){
	global $lang;
	$return = '';
	if(!$startline && !$endline) return $lang['lang001'];
	$return .= ($startline?date("Y-m-d",$startline):$lang['lang001']);
	$return .= '&nbsp;~&nbsp;';
	$return .= ($endline?date("Y-m-d",$endline):$lang['lang001']);
	return $return;	
}

function dzlang(){
	$dlang = array();
	for($i=1;$i<100;$i++){
		$key = 'lang'.sprintf("%03d", $i);
		$dlang[$key] = lang('plugin/tshuz_ad2thread', $key);
	}
	return $dlang;
}

function getForums($fids = array()){
	global $_G;
	require_once libfile('function/forumlist');
	$forums = '<select name="set[forums][]" size="10" multiple="multiple">'.forumselect(FALSE, 0, 0, TRUE).'</select>';
	foreach($fids as $v) {
			$forums = str_replace('<option value="'.$v.'">', '<option value="'.$v.'" selected>', $forums);
	}
	return $forums;
}

function getRandUid(){
	global $_G,$pvars;
	$uids = explode(",",$pvars['uids']);
	$count = count($uids)-1;
	$random = mt_rand(0,$count);
	$uid = dintval($uids[$random]);
	if(!$uid){
		$uid = getRandUid();
	}
	return $uid;
}

function addvtorandp($array,$position,$value){
    $tmp=array();
    for($i=0;$i<=count($array);$i++){
        if($i==$position){
            $tmp[$position]=$value;
        }elseif($i<$position){
            $tmp[$i]=$array[$i];
        }else{
            $tmp[$i]=$array[$i-1];
        }

    }
    return $tmp;
}

$lang = array_merge($lang, dzlang() );
loadcache("plugin");
$pvars = $_G['cache']['plugin']['tshuz_ad2thread'];
?>