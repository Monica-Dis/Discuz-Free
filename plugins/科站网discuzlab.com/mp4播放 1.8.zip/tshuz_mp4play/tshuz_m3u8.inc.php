<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *      $Id: tshuz_m3u8.inc.php 2018-09-07 13:16:43Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* 插件代码开始 */

?><script type="text/javascript">location.href="https://dism.taobao.com/?@tshuz_m3u8.plugin";</script>