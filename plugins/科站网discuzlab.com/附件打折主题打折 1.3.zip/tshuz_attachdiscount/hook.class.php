<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: hook.class.php 2020-04-29 03:10:38Z Todd $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* ������뿪ʼ */
class tshuz_attachdiscount{

    protected function sumPrice($price){
        $price = intval($price);
        return $price?$price:1;
    }

	function getDisCount(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_attachdiscount'];
		if (!$_G['uid'] || !$pvars['onoff']) return '';
		$discounts = unserialize($pvars['discount']);
		$discount = $discounts[$_G['groupid']];
		$discount = $discount >= 100 || $discount <= 0 ? 0 : $discount;
		return $discount;
	}
	function _viewthread()
	{
		global $_G, $postlist;
		$discount = $this->getDisCount();
		if(!$discount) return '';
		foreach ($postlist as $pid => $post) {
			if (!$post['attachments']) continue;
			foreach ($post['attachments'] as $aid => $attach) {
				if ($attach['price']) {
					$postlist[$pid]['attachments'][$aid]['price'] = $this->sumPrice(round($attach['price'] * $discount / 100) );
				}
			}
		}
		return '';
	}

	function viewthread_limit()
	{
		global $_G,$discount;
		$discount = $this->getDisCount();
		if (!$discount) return '';
		if($_G['thread']['price']){
			$_G['thread']['price'] = $this->sumPrice(round($_G['thread']['price'] * $discount / 100));
		}
		include libfile('forum/viewthread', 'plugin/tshuz_attachdiscount');
		return '';
	}

	function misc_limit(){
		global $_G;
		if($_GET['action'] != 'attachpay' && $_GET['action'] != 'pay') return '';
		$discount = $this->getDisCount();
		if (!$discount) return '';
		include libfile('forum/misc','plugin/tshuz_attachdiscount');
		return '';
	}
}
class plugin_tshuz_attachdiscount extends tshuz_attachdiscount
{
}
class mobileplugin_tshuz_attachdiscount extends tshuz_attachdiscount
{
}
class plugin_tshuz_attachdiscount_forum extends tshuz_attachdiscount
{
	function viewthread_posttop_output()
	{
		global $_G, $postlist;
		$this->_viewthread();
		return '';
	}
}
class mobileplugin_tshuz_attachdiscount_forum extends tshuz_attachdiscount
{
	function viewthread_posttop_mobile_output()
	{
		global $_G, $postlist;
		$this->_viewthread();
		return '';
	}

}

