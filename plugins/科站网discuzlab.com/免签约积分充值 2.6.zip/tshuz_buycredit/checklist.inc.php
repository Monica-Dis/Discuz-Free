<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require DISCUZ_ROOT . './source/plugin/tshuz_buycredit/function/lang.php';
loadcache('plugin');
$pvars = $_G['cache']['plugin']['tshuz_buycredit'];
if(in_array($_GET['status'],array(-1,1)) && $_GET['formhash'] == FORMHASH && dintval($_GET['payid'])){
	$data = array();
	$payid = dintval($_GET['payid']);
	$order = C::t("#tshuz_buycredit#log")->fetch($payid);
	if($order['status'] != 0)
		cpmsg($dlang['lang013'],"","error");

	$data['status'] = $_GET['status'];

	if($_GET['status'] == -1){
		notification_add($order['uid'], 'system', $dlang['lang024'].$order['amount'].$_G['setting']['extcredits'][$pvars['ext']]['title'].$dlang['lang048'],  $notevars = array(), $system = 1);
	}else{
		updatemembercount($order['uid'], array($pvars['ext'] => $order['amount']), 1, 'AFD', $order['uid']);
		notification_add($order['uid'], 'system', $dlang['lang049'].$order['amount'].$_G['setting']['extcredits'][$pvars['ext']]['title'],  $notevars = array(), $system = 1);
	}
	C::t("#tshuz_buycredit#log")->update($payid,$data);
	cpmsg($dlang['lang014'],'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod'],"succeed");

}else{
/*数据读取*/
$perpage = 15;
$page = intval ( $_GET['page'] ) ? intval ( $_GET['page'] ) : 1;
$start = ($page - 1) * $perpage;
if ($start < 0) $start = 0;
$count = C::t("#tshuz_buycredit#log")->count_by_status(0);
$multi=	multi($count, $perpage, $page, ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod']);
$list = C::t("#tshuz_buycredit#log")->fetch_all_by_status(0,$start,$perpage);
/*数据展示*/
showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod']);
showtableheader($dlang['lang001']);
$href = ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod']."&formhash=".FORMHASH;
showsubtitle(array($dlang['lang002'],$dlang['lang003'],$dlang['lang004'],$dlang['lang005'],$dlang['lang006'],$dlang['lang007'],$dlang['lang008']));
if(!count($list)){
	showtablerow('',array('colspan=8 '), array($dlang['lang009']));
}else{
	$typename = array("alipay"=>$dlang['lang015'],"qq"=>$dlang['lang016'],"wechat"=>$dlang['lang017']);
	$status = array(-1=>$dlang['lang018'],0=>$dlang['lang019'],1=>$dlang['lang020']);
	$color = array(-1=>"red",0=>"blue",1=>"green");
	foreach($list as $pay){
		showtablerow('',
			array('','','class="td24"','class="td31"','class="td31"','class="td31"','class="td24"'), 
			array(
				'<a href="home.php?mod=space&uid='.$pay['uid'].'" target="_blank">'.$pay['username'].'</a>',
				$dlang['lang024'].$pay['amount'].$_G['setting']['extcredits'][$pvars['ext']]['title'],
				$typename[$pay['paytype']],
				dhtmlspecialchars($pay['pay']),
				$pay['trade']?dhtmlspecialchars($pay['trade']):$dlang['lang010'],
				date("Y-m-d H:i:s",$pay['dateline']),
				"<a href='{$href}&status=-1&payid={$pay['id']}' style='color:red'>[{$dlang['lang011']}]</a> &nbsp; | &nbsp;".
				"<a href='{$href}&status=1&payid={$pay['id']}' style='color:green'>[{$dlang['lang012']}]</a>"
			)
		);
	}
	if($multi) showtablerow('',array('colspan=8 style="text-align: right;"'), array($multi));
}
showtablefooter(); //From: Dism·taobao·com
showformfooter(); //From: Dism_taobao-com
}
//From: dis'.'m.tao'.'bao.com
?>