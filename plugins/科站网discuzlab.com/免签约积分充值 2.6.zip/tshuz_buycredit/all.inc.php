<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require DISCUZ_ROOT . './source/plugin/tshuz_buycredit/function/lang.php';
loadcache('plugin');
$pvars = $_G['cache']['plugin']['tshuz_buycredit'];
/*数据读取*/
$perpage = 15;
$page = intval ( $_GET['page'] ) ? intval ( $_GET['page'] ) : 1;
$start = ($page - 1) * $perpage;
if ($start < 0) $start = 0;
$count = C::t("#tshuz_buycredit#log")->count_by_status(array(0,-1,1));
$multi=	multi($count, $perpage, $page, ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod']);
$list = C::t("#tshuz_buycredit#log")->fetch_all_by_status(array(0,-1,1),$start,$perpage);
/*数据展示*/
showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod']);
showtableheader($dlang['lang021']);
$href = ADMINSCRIPT.'?action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod']."&formhash=".FORMHASH;
showsubtitle(array($dlang['lang002'],$dlang['lang003'],$dlang['lang004'],$dlang['lang005'],$dlang['lang006'],$dlang['lang022'],$dlang['lang007']));
if(!count($list)){
	showtablerow('',array('colspan=7 '), array($dlang['lang025']) );
}else{
	$typename = array("alipay"=>$dlang['lang015'],"qq"=>$dlang['lang016'],"wechat"=>$dlang['lang017']);
	$status = array(-1=>$dlang['lang018'],0=>$dlang['lang019'],1=>$dlang['lang020']);
	$color = array(-1=>"red",0=>"blue",1=>"green");
	foreach($list as $pay){
		showtablerow('',
			array('','','class="td24"','class="td31"','class="td31"','width="80"','class="td31"'), 
			array(
				'<a href="home.php?mod=space&uid='.$pay['uid'].'" target="_blank">'.$pay['username'].'</a>',
				$dlang['lang024'].$pay['amount'].$_G['setting']['extcredits'][$pvars['ext']]['title'],
				$typename[$pay['paytype']],
				dhtmlspecialchars($pay['pay']),
				$pay['trade']?dhtmlspecialchars($pay['trade']):$dlang['lang010'],
				"<font color={$color[$pay['status']]}><b>{$status[$pay['status']]}</b></font>",
				date("Y-m-d H:i:s",$pay['dateline'])
			)
		);
	}
	if($multi) showtablerow('',array('colspan=7 style="text-align: right;"'), array($multi));
}
showtablefooter(); //From: Dism·taobao·com
showformfooter(); //From: Dism_taobao-com

?>