<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: charts.inc.php 2020-03-02 08:41:25Z DisM.taobao.Com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$file = libfile('extend/charts','plugin/tshuz_buycredit');
if(!$file) cpmsg(lang('plugin/tshuz_buycredit','LKaFbF'),'','error');
include $file;