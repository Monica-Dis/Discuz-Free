<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$_G['uid']) showmessage('to_login', '', array(), array('login' => 1));
require DISCUZ_ROOT . './source/plugin/tshuz_buycredit/function/lang.php';
$navtitle = $dlang['lang024'];
//读取插件配置信息
$pvars = $_G['cache']['plugin']['tshuz_buycredit'];

$typename = array("alipay"=>$dlang['lang015'],"qq"=>$dlang['lang016'],"wechat"=>$dlang['lang017']);
$tmp = explode(PHP_EOL,$pvars['pay']);
$pays = array();
foreach($tmp as $k=>$v){
	$tmp2 = explode("|",$v);
	$pay = array();
	$tmp2[0] = strtolower($tmp2[0]);
	if(!in_array($tmp2[0],array("alipay","qq","wechat") ) ) continue;
	$pays[$tmp2[0]] = array(
		'pay'	=> $tmp2[1],
		'pic'	=> $tmp2[2]
	);
	switch ($tmp2[0]) {
		case 'alipay':
			$pays[$tmp2[0]]['tip'] = $dlang['lang025'].$pays[$tmp2[0]]['pay'].$dlang['lang026'];
			break;
		case 'qq':
			$pays[$tmp2[0]]['tip'] = $dlang['lang025'].$pays[$tmp2[0]]['pay'].$dlang['lang027'];
			break;
		default:
			$pays[$tmp2[0]]['tip'] = $dlang['lang028'];
			break;
	}
}	
if(submitcheck("buysubmit")){
	$addfundamount = intval($_GET['addfundamount']);
	if($addfundamount < $pvars['min']) 
		showmessage($dlang['lang029']." ".$pvars['min']." ".$_G['setting']['extcredits'][$pvars['extcredit']]['unit']." ".$_G['setting']['extcredits'][$pvars['extcredit']]['title']);
	$mod = 'check';
	$paytype = $_GET['bank_type'];
	if(!in_array($paytype,array("alipay","qq","wechat") ) ) showmessage($dlang['lang030']);
	$money = ceil($addfundamount*100/$pvars['per'])/100;
}elseif(submitcheck("checksubmit")){
	$addfundamount = intval($_GET['info']['addfundamount']);
	if($addfundamount < $pvars['min']) 
		showmessage($dlang['lang029']." ".$pvars['min']." ".$_G['setting']['extcredits'][$pvars['extcredit']]['unit']." ".$_G['setting']['extcredits'][$pvars['extcredit']]['title']);
	$paytype = $_GET['info']['bank_type'];
	if(!in_array($paytype,array("alipay","qq","wechat") ) ) showmessage($dlang['lang030']);
	$data = array();
	$data['uid'] 		= $_G['uid'];
	$data['username'] 	= $_G['username'];
	$data['amount'] 	= $addfundamount;
	$data['price'] 		= ceil($addfundamount*100/$pvars['per'])/100;
	$data['paytype'] 	= $paytype;
	$data['pay'] 		= addslashes($_GET['info']['pay']);
	if(!$data['pay']) showmessage($dlang['lang031']);
	$data['trade'] 		= addslashes($_GET['info']['trade']);
	$data['dateline'] 	= TIMESTAMP; 
	C::t("#tshuz_buycredit#log")->insert($data);
	$content = '<br>' . $dlang['lang032'] . ':' . $typename[$paytype];
	$content .= '<br>' . $dlang['lang033'] . ':' . $addfundamount . $_G['setting']['extcredits'][$pvars['ext']]['title'];
	$content .= '<br>' . $dlang['lang034'] . ':' . $data['price'];
	$content .= '<br>' . $dlang['lang035'] . ':' . $_G['username'] . "(uid:{$_G['uid']})";
	$content .= '<br>' . $dlang['lang036'] . ':' . $data['pay'];
	if ($data['trade'])
		$content .= '<br>' . $dlang['lang037'] . ':' . $data['trade'];
	if($pvars['email']){
		include_once libfile('function/mail');
		sendmail(
			$pvars['email'],
			$dlang['lang038'],
			$content
		);
	}
	foreach(explode(',',$pvars['uid']) as $uid){
		notification_add($uid, 'system', $dlang['lang038']);
	}
	showmessage($pvars['tip'],"index.php");
}else{
	$mod = 'base';
}
if(defined('IN_MOBILE')){
	include template("tshuz_buycredit:tshuz_buycredit");exit;
}