<?php

/**
 *      DisM!应用中心：dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: tshuz_tagpro.inc.php 2018-05-14 10:17:05Z Todd $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* 插件代码开始 */

?><script type="text/javascript">location.href="https://dism.taobao.com/?@tshuz_tagpro.plugin";</script>