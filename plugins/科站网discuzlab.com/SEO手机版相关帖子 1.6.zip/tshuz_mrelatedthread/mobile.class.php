<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_tshuz_mrelatedthread_forum {
	function viewthread_postbottom_mobile_output(){
		global $_G,$postlist;
		$return = array();
		$pvars = $_G['cache']['plugin']['tshuz_mrelatedthread'];
		$forums = dunserialize($pvars['forums']);
		if(!in_array($_G['fid'],$forums)) return $return;
		foreach($postlist as $post){
			if(!$post['first']) $return[] = '';
			$return[] = $post['relateitem']?$this->parsetemplate($post['relateitem']):"";
		}
		return $return;
	}

	public function parsetemplate($threads){
		global $_G;
		$return = '';
		$template = $_G['cache']['plugin']['tshuz_mrelatedthread']['template'];
		$maxnum = $_G['cache']['plugin']['tshuz_mrelatedthread']['maxnum'];
		if(strexists($template, '[loop]') && strexists($template, '[/loop]')) {
			preg_match('/^(.+?)\[loop\](.+?)\[\/loop\](.+?)$/s', $template, $r);
			$return .= stripslashes($r[1]);
			$loop = stripslashes($r[2]);
			$find = array('{currentid}','{subject}','{author}','{authorid}','{tid}','{dateline}','{lastpost}','{lastposter}','{views}','{replies}');
			foreach($threads as $currentid=>$thread){
				if($currentid>=$maxnum) break;
				$thread['dateline'] = dgmdate($thread['dateline'], 'u', '9999', getglobal('setting/dateformat'));
				$thread['lastpost'] = dgmdate($thread['lastpost'], 'u', '9999', getglobal('setting/dateformat'));
				$replace = array(sprintf("%02d", $currentid+1),$thread['subject'],$thread['author'],$thread['authorid'],$thread['tid'],$thread['dateline'],$thread['lastpost'],$thread['lastposter'],$thread['views'],$thread['replies']);
				$return .= str_replace($find,$replace,$loop);
			}
			$return .= stripslashes($r[3]);
		}
		return $return;
	}
}
//From: Dism��taobao��com
?>