<?php

/**
 *      DisM!应用中心：dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: mobile.class.php 2018-07-31 15:10:00Z Todd $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */

class mobileplugin_tshuz_draft_forum {
	function post_bottom_mobile_output(){
		global $_G,$savecount;
		$pvars = $_G['cache']['plugin']['tshuz_draft'];
		if(!$_G['uid'] || !$_G['group']['allowsave']) return '';
		if(!in_array($_G['fid'],unserialize($pvars['forums'])) || !in_array($_G['groupid'],unserialize($pvars['groups']))) return '';
		include template('tshuz_draft:tshuz_draft');
		return $return;
	}
}
//From: Dism_taobao-com
?>