<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: hook.class.php 2020-09-22 05:34:58Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */
class tshuz_removeemail
{

	function register_limit()
	{
		global $_G;
		$_G['setting']['forgeemail'] = 1;
		if (submitcheck('regsubmit', 1) && $_GET['formhash'] == FORMHASH) { //提交
			$key = $_G['setting']['reginput']['email'];
			if (!$_GET[$key]) {
				$_GET[$key] = $_G['cache']['plugin']['tshuz_removeemail']['relateqq'] && ctype_digit($_GET['qq']) && strlen($_GET['qq']) > 5 ? $_GET['qq'] . '@qq.com' : strtolower(random(10)) . '@null.null';
			}
		}
	}
}

class plugin_tshuz_removeemail_member extends tshuz_removeemail
{
	function register_input()
	{
		global $_G;
		if(!$_G['cache']['plugin']['tshuz_removeemail']['hideemail']) return '';
		return '<script>$("emailmore").parentNode.parentNode.parentNode.parentNode.parentNode.style.display = "none"</script>';
	}

}

class mobileplugin_tshuz_removeemail_member extends tshuz_removeemail
{
}

class mobileplugin_tshuz_removeemail
{
	function global_footer_mobile(){
		global $_G;
		if (!$_G['cache']['plugin']['tshuz_removeemail']['hideemail']) return '';
		if(CURSCRIPT != 'member' || CURMODULE != 'register') return '';
		return '<script>$("input[name=\''. $_G['setting']['reginput']['email'].'\']").parent().hide()</script>';
	}
}