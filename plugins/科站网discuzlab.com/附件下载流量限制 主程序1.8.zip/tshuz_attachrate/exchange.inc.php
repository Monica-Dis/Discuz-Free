<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$dlang = array();
for($i=1;$i<=15;$i++){
	$key = 'lang'.sprintf("%03d", $i);
	$dlang[$key] = lang('plugin/tshuz_attachrate', $key);
}
$pvars = $_G['cache']['plugin']['tshuz_attachrate'];
$groups = unserialize($pvars['groups']);
if (in_array($_G['groupid'], $groups)) showmessage($dlang['lang001'], dreferer());
if(submitcheck("exchange")){
	$addfundamount = dintval($_GET['addfundamount']);
	if(!$addfundamount) showmessage($dlang['lang002']);
	$extcredits  = getuserprofile("extcredits".$pvars['ext']);
	$title = $_G['setting']['extcredits'][$pvars['ext']]['title'];
	if($extcredits < $addfundamount)  showmessage($dlang['lang003'].$title.$dlang['lang004'].$addfundamount);
	$size = $addfundamount*$pvars['rate']*1024;
	updatemembercount($_G['uid'], array($pvars['ext'] => -$addfundamount), 1, '', $_G['uid'],$dlang['lang015'],$dlang['lang015'],$dlang['lang015'].sizecount($size));
	C::t("#tshuz_attachrate#user")->plus_size($size,$_G['uid']);
	dsetcookie("tshuz_attachrate",null);
	showmessage($dlang['lang005'],'home.php?mod=spacecp&ac=plugin&op=credit&id=tshuz_attachrate:exchange');
}else{
	$perpage = 15;
	$page = intval ( $_GET ['page'] ) ? intval ( $_GET ['page'] ) : 1;
	$start = ($page - 1) * $perpage;
	if ($start < 0) $start = 0;
	$count = C::t("#tshuz_attachrate#log")->count_by_uid($_G['uid']);
	$multi=	multi($count, $perpage, $page, "home.php?mod=spacecp&ac=plugin&op=credit&id=tshuz_attachrate:exchange" );	
	$list = C::t("#tshuz_attachrate#log")->fetch_all_limit_by_uid($_G['uid'],$start,$perpage);
	$tids = array();
	foreach($list as $order){
		$tids[] = $order['tid'];
	}
	$usersize = C::t("#tshuz_attachrate#user")->fetch($_G['uid']);
	if(!$usersize){
		C::t("#tshuz_attachrate#user")->insert(array("uid"=>$_G['uid'],"size"=>$pvars['free']*1024));
		$usersize = sizecount($pvars['free']*1024);
	}else{
		$usersize = sizecount($usersize['size']);
	}
	$threads = C::t("forum_thread")->fetch_all_by_tid($tids);
	foreach($list as $k=>$order){
		$list[$k]['subject'] = $threads[$order['tid']]['subject'];
		$list[$k]['size'] = sizecount($order['size']);
	}
	if(defined('IN_MOBILE')){
		include template("tshuz_attachrate:exchange");exit;
	}
}
//From: Dism_taobao-com
?>