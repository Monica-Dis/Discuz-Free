<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_tshuz_attachrate_forum {
	function attachment_limit(){
		global $_G;
		if(!$_G['uid']) return '';//未登录
		$file = DISCUZ_ROOT.'./source/plugin/tshuz_attachrate/module/mobile.php';
		if(file_exists($file) ){
			include $file;exit;
		}
		return '';
	}
}
//From: Dism_taobao-com
?>