<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_log extends discuz_table{
	public function __construct() {
		$this->_table = 'tshuz_attachrate_log';
		$this->_pk    = 'id';
		parent::__construct();
	}

	public function fetch_by_aid_uid($aid,$uid){
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND aid=%d",array($this->_table,$uid,$aid));
	}

	public function count_by_uid($uid){
		return DB::result_first("SELECT count(*) FROM %t WHERE uid=%d",array($this->_table,$uid));
	}

	public function fetch_all_limit_by_uid($uid,$start,$perpage){
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d ORDER BY dateline DESC limit %d,%d",array($this->_table,$uid,$start,$perpage));
	}

}

?>