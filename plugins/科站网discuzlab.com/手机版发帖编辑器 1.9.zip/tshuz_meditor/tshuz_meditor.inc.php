<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$editors = dunserialize($_G['cache']['plugin']['tshuz_meditor']['editors']);
$editor = addslashes($_GET['editor']);
if(!in_array($editor,$editors)) showmessage("undefined_action");
include DISCUZ_ROOT.'./source/language/home/lang_editor.php';
$dlang = array();
for($i=1;$i<=5;$i++){
	$key = 'lang'.sprintf("%03d", $i);
	$dlang[$key] = lang('plugin/tshuz_meditor', $key);
}
$colors = array('Black', 'Sienna', 'DarkOliveGreen', 'DarkGreen', 'DarkSlateBlue', 'Navy', 'Indigo', 'DarkSlateGray', 'DarkRed', 'DarkOrange', 'Olive', 'Green', 'Teal', 'Blue', 'SlateGray', 'DimGray', 'Red', 'SandyBrown', 'YellowGreen', 'SeaGreen', 'MediumTurquoise', 'RoyalBlue', 'Purple', 'Gray', 'Magenta', 'Orange', 'Yellow', 'Lime', 'Cyan', 'DeepSkyBlue', 'DarkOrchid', 'Silver', 'Pink', 'Wheat', 'LemonChiffon', 'PaleGreen', 'PaleTurquoise', 'LightBlue', 'Plum', 'White');
$colornames = explode(",",$dlang['lang005']);
include template("tshuz_meditor:editor");
?>
