<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      应用更新支持：https://dism.taobao.com
 *      $Id: tshuz_mavatar.inc.php 2018-10-31 09:16:51Z Todd $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* 插件代码开始 */

?><script type="text/javascript">location.href="https://dism.taobao.com/?@tshuz_mavatar.plugin";</script>