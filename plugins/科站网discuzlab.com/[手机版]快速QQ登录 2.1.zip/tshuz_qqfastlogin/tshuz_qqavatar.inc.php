<?php

/**
 *      Copyright (c) 2020 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: tshuz_qqavatar.inc.php 2018-09-29 14:36:43Z Dism_taobao_com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* 插件代码开始 */

?><script type="text/javascript">location.href="https://dism.taobao.com/?@tshuz_qqavatar.plugin";</script>