<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$mod = $_GET['mod'];
$modArray = array(
    "forum",
    "viewthread",
	'agree'
);
if (!in_array($mod, $modArray)) showmessage('undefined_action');
$fid = dintval($_GET['fid']);
if(!$fid){
	$tid = dintval($_GET['tid']);
	$thread = C::t("forum_thread")->fetch($tid);
	$fid = $thread['fid'];
}
if(!$fid)  showmessage('undefined_action');

$pvars = $_G['cache']['plugin']['tshuz_forumrulers'];
$rulers = dunserialize($pvars['rulers']);
$groups = dunserialize($pvars['groups']);
$types = dunserialize($pvars['type']);
if (!getcookie("tshuz_forumrulers")) {
	$userlog = array();
    if($_G['uid'])  $userlog = C::t("#tshuz_forumrulers#log")->fetch($_G['uid']);
    if (!$userlog) {
        $userforums = array();
         if($_G['uid'])  C::t("#tshuz_forumrulers#log")->insert(array(
            "uid" => $_G['uid'],
            "fids" => serialize($userforums)
        ));
    } else {
        $userforums = unserialize($userlog['fids']);
    }
    dsetcookie("tshuz_forumrulers", dauthcode($userforums, "ENCODE"));
} else {
    $userforums = getcookie("tshuz_forumrulers");
    $userforums = dauthcode($userforums, "DECODE");
    $userforums = unserialize($userforums);
}
loadcache("forums");

$dlang = array();
for($i=1;$i<=4;$i++){
	$key = 'lang'.sprintf("%03d", $i);
	$dlang[$key] = lang('plugin/tshuz_forumrulers', $key);
}

$url = $tid?"forum.php?mod=viewthread&tid=".$tid:"forum.php?mod=forumdisplay&fid=".$fid;
if(in_array($fid,$userforums) || !in_array($_G['groupid'],$groups)) 
	showmessage($dlang['lang001'],$url);
if(!trim($rulers[$fid])){
	$rulers[$fid] = $pvars['ruler'];
}


if($_GET['mod'] == 'agree' && $_GET['formhash'] == FORMHASH){
	$userforums[] = $fid;
	if($_G['uid']) C::t("#tshuz_forumrulers#log")->update($_G['uid'],array("fids" => serialize($userforums)));
	dsetcookie("tshuz_forumrulers", dauthcode($userforums, "ENCODE"));
	showmessage($dlang['lang001'],$url);
}else{
	include template("tshuz_forumrulers:show");
}

	function dauthcode($string,$operation = 'DECODE'){
		global $_G;
		$string = is_array($string)?serialize($string):$string;
		$key = $_G['uid']?$_G['member']['password']:$_G['clientip'];
		return authcode($string,$operation,$key);
	}
//From: dis'.'m.tao'.'bao.com
?>
