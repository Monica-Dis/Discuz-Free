<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_tshuz_forumrulers_forum {
	public $_rulers;
	public $_groups;
	public $_types;
	public $_userforums;
	public function __construct(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_forumrulers'];
		$this->_rulers = dunserialize($pvars['rulers']);
		$this->_groups = dunserialize($pvars['groups']);
		$this->_types = $pvars['type'];
		if(!getcookie("tshuz_forumrulers")){
			$userlog = array();
			 if($_G['uid']) $userlog = C::t("#tshuz_forumrulers#log")->fetch($_G['uid']);
			if(!$userlog){
				$this->_userforums = array();
				 if($_G['uid']) C::t("#tshuz_forumrulers#log")->insert(array("uid"=>$_G['uid'],"fids"=>serialize($this->_userforums)));
			}else{
				$this->_userforums = unserialize($userlog['fids']);
			}
			dsetcookie("tshuz_forumrulers",$this->dauthcode($this->_userforums,"ENCODE"));
		}else{
			$this->_userforums = getcookie("tshuz_forumrulers");
			$this->_userforums = $this->dauthcode($this->_userforums,"DECODE");
			$this->_userforums = unserialize($this->_userforums);
		}
	}

	public function dauthcode($string,$operation = 'DECODE'){
		global $_G;
		$string = is_array($string)?serialize($string):$string;
		$key = $_G['uid']?$_G['member']['password']:$_G['clientip'];
		return authcode($string,$operation,$key);
	}

	function forumdisplay_top(){
		global $_G;
		if(trim($this->_rulers[$_G['fid']]) && in_array($_G['groupid'],$this->_groups) ){//有版块规则，并且受控
			if(in_array($this->_types,array(1,3)) && !in_array($_G['fid'],$this->_userforums)){//禁止帖子列表
				dheader("location:plugin.php?id=tshuz_forumrulers&mod=forum&fid=".$_G['fid']);
			}
		}
	}

	function viewthread_top(){
		global $_G;
		if(trim($this->_rulers[$_G['fid']]) && in_array($_G['groupid'],$this->_groups) ){//有版块规则，并且受控
			if(in_array($this->_types,array(2,3)) && !in_array($_G['fid'],$this->_userforums)){//禁止帖子内容
				dheader("location:plugin.php?id=tshuz_forumrulers&mod=viewthread&tid=".$_G['tid']);
			}
		}
	}
}


class mobileplugin_tshuz_forumrulers_forum extends plugin_tshuz_forumrulers_forum
{
	function forumdisplay_top_mobile()
	{
		global $_G;
		if (trim($this->_rulers[$_G['fid']]) && in_array($_G['groupid'], $this->_groups)) { //有版块规则，并且受控
			if (in_array($this->_types, array(1, 3)) && !in_array($_G['fid'], $this->_userforums)) { //禁止帖子列表
				dheader("location:plugin.php?id=tshuz_forumrulers&mod=forum&fid=" . $_G['fid']);
			}
		}
	}

	function viewthread_top_mobile()
	{
		global $_G;
		if (trim($this->_rulers[$_G['fid']]) && in_array($_G['groupid'], $this->_groups)) { //有版块规则，并且受控
			if (in_array($this->_types, array(2, 3)) && !in_array($_G['fid'], $this->_userforums)) { //禁止帖子内容
				dheader("location:plugin.php?id=tshuz_forumrulers&mod=viewthread&tid=" . $_G['tid']);
			}
		}
	}
}