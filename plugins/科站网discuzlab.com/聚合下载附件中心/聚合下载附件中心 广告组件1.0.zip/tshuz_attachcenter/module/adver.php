<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(submitcheck('submit')){
	if(!function_exists('writetocache')) include libfile("function/cache");
	$data = $_GET['adver'];
	$adver = array();
	foreach($data as $k=>$v){
		$adver[$k] = daddslashes($v);
	}
	writetocache('tshuz_attachcenter_adver',getcachevars(array('adver' => $adver)));
	$cpmsg = 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod'];
	cpmsg($dlang['lang001'], $cpmsg, 'succeed');
}else{
	$adverCache = DISCUZ_ROOT.'./data/sysdata/cache_tshuz_attachcenter_adver.php';
	if(file_exists($adverCache)){
		include $adverCache;
		$adver = dstripslashes($adver);
	}
	showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod']);
	showtableheader();
	showsetting($dlang['lang002'], 'adver[ad1]',$adver['ad1'], 'textarea',0,0,$dlang['lang010']);
	showsetting($dlang['lang003'], 'adver[ad2]',$adver['ad2'], 'textarea',0,0,$dlang['lang010']);
	showsetting($dlang['lang004'], 'adver[ad3]',$adver['ad3'], 'textarea',0,0,$dlang['lang010']);
	showsetting($dlang['lang005'], 'adver[ad4]',$adver['ad4'], 'textarea',0,0,$dlang['lang010']);
	showsetting($dlang['lang006'], 'adver[ad5]',$adver['ad5'], 'textarea',0,0,$dlang['lang010']);
	showsetting($dlang['lang007'], 'adver[ad6]',$adver['ad6'], 'textarea',0,0,$dlang['lang010']);
	showsetting($dlang['lang008'], 'adver[ad7]',$adver['ad7'], 'textarea',0,0,$dlang['lang010']);
	showsetting($dlang['lang009'], 'adver[ad8]',$adver['ad8'], 'textarea',0,0,$dlang['lang011']);
	showsubmit("submit","submit");
	showtablefooter();/*dis'.'m.tao'.'bao.com*/
	/*Dism_taobao-com*/showformfooter();
}
//From: Dism_taobao_com
?>