<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function loadcacheforums(){
	global $_G;
	$pvars = $_G['cache']['plugin']['tshuz_attachcenter'];
	$formsCache = DISCUZ_ROOT.'./data/sysdata/cache_tshuz_attachcenter_forums.php';
	if(!file_exists($formsCache) || TIMESTAMP-filemtime($formsCache) > $pvars['cachetime']*60 ){
		/* 载入缓存 */
		loadcache('forums');
		/* 图标 */
		$tmps = explode(PHP_EOL,$pvars['icons']);
		$icons = $newforums = array();
		foreach($tmps as $tmp){
			list($fid,$icon) = explode("|",$tmp);
			$icons[dintval($fid)] = addslashes($icon);
		}
		/* 启用的版块 */
		$forums = dunserialize($pvars['forums']);
		foreach($forums as $k=>$fid){
			$newforums[$fid] = array(
				'fid'	=> $fid,
				'name'	=> $_G['cache']['forums'][$fid]['name'],
				'icon'	=> $icons[$fid]
			);
		}
		if(!function_exists('writetocache')) include libfile("function/cache");
		writetocache('tshuz_attachcenter_forums',getcachevars(array('forums' => $newforums)));
		$forums = $newforums;
	}else{
		include $formsCache;
	}
	return $forums;
}

function loadindexpic(){
	global $_G;
	$pvars = $_G['cache']['plugin']['tshuz_attachcenter'];
	$indexpicCache = DISCUZ_ROOT.'./data/sysdata/cache_tshuz_attachcenter_indexpic.php';
	if($pvars['promote']){
		$return = array();
		$tmps = explode(PHP_EOL,$pvars['promote']);
		foreach($tmps as $tmp){
			list($link,$pic) = explode("|",$tmp,2);
			$return[] = array(
				'link' 	=> $link,
				'pic'	=> $pic
			);
		}
		return $return;
	}
	if(!file_exists($indexpicCache) || TIMESTAMP-filemtime($indexpicCache) > $pvars['cachetime']*60 ){
		$picfids = dunserialize($pvars['picfids']);
		list($picnum,$attnum) = explode("|",$pvars['nums'],2);
		$picnum = dintval($picnum);
		$picnum = $picnum>5?5:$picnum;
		$pics = C::t("#tshuz_attachcenter#attachcenter")->fetch_all_image_by_fids($picfids,0,$picnum);
		$tableids = array();
		foreach($pics as $att){
			$tableids[$att['tableid']][] = $att['aid'];
		}
		$return = array();
		foreach($tableids as $tableid=>$aids){
			$attachs = C::t("forum_attachment_n")->fetch_all($tableid, $aids);
			foreach($attachs as $attach){
				$return[$attach['aid']] = $_G['setting']['attachurl'].'forum/'.$attach['attachment'];
			}
		}
		if(!function_exists('writetocache')) include libfile("function/cache");
		writetocache('tshuz_attachcenter_indexpic',getcachevars(array('indexpics' => $return)));
	}else{
		include $indexpicCache;
		$return = $indexpics;
	}
	return $return;
}

function loadindexattach(){
	global $_G;
	$pvars = $_G['cache']['plugin']['tshuz_attachcenter'];
	$indexattachCache = DISCUZ_ROOT.'./data/sysdata/cache_tshuz_attachcenter_indexattach.php';
	if(!file_exists($indexattachCache) || TIMESTAMP-filemtime($indexattachCache) > $pvars['cachetime']*60 ){
		$attachfids = dunserialize($pvars['attachfids']);
		list($picnum,$attnum) = explode("|",$pvars['nums'],2);
		$attachments = array();
		$attnum = dintval($attnum);
		$attnum = $attnum>15?15:$attnum;
		foreach($attachfids as $fid){
			$attachments[$fid] = getNewByFid($fid,$attnum);//C::t("#tshuz_attachcenter#attachcenter")->fetch_all_not_image_by_fids($fid,0,$attnum);
		}
		if(!function_exists('writetocache')) include libfile("function/cache");
		writetocache('tshuz_attachcenter_indexattach',getcachevars(array('attachments' => $attachments)));
	}else{
		include $indexattachCache;
	}
	return $attachments;
}

function getNewByFid($fid,$attachmun){
	$postTable = DB::table('forum_post');
	$where = ' AND a.isimage=0' ;
	$sql = <<<EOF
( SELECT * FROM {$postTable} as p LEFT JOIN %t as a on p.pid=a.pid WHERE fid={$fid} AND aid>0 {$where})
EOF;
	$sqls = array();
	for ($i = 0; $i <= 9; $i++) {
		$sqls[] = str_replace(array('%t', '%d'), array(DB::table('forum_attachment_' . $i), $i), $sql);
	}
	$sql = implode(' union all ', $sqls);

	return DB::fetch_all($sql . ' ORDER BY aid DESC LIMIT 0,' . $attachmun);
}

function sprintfid($id,$idoffset = 0){
	$id = $id+$idoffset;
	return sprintf("%02d",$id);
}

function thunder($url){
	return "thunder://".base64_encode("AA".$url."ZZ");
}

function getAid($aid,$tableid){
	global $_G;
	$getAid = $aid."|";
	$t = TIMESTAMP;
	$k = substr(md5($aid.md5($_G['config']['security']['authkey']).$t.$_G['uid']), 0, 8);
	$getAid .= $k."|";
	$getAid .= $t."|";
	$getAid .= $_G['uid']."|";
	$getAid .= $tableid."|";
	$getAid = base64_encode($getAid);
	$getAid = urlencode($getAid);
	return $getAid;
}

function typeclass($filename){
	$types = array("exe","msi","dmg","pkg","psd","apk","key","ai","ipa","pages","numbers","eot","ttf","woff","eps","lnk","link","swf","php","c","js","css","html","htm","xhtml","java","cc","python","json","sh","bat","ejs","xml","bt","torrent","dws","dwt","dxf","dwg","cad","as","cpp","h","cs","asp","pas","diff","patch","erl","groovy","jsp","pl","py","rb","sass","scss","scala","sql","vb","md","less","lua","go","wml","txt","rtf","pdf","doc","docx","ppt","pptx","xls","xlsx","vsd","jpg","jpeg","gif","bmp","png","jpe","cur","svgz","tif","tiff","ico","mmap","xmind","mm","wma","wav","mp3","aac","ra","ram","mp2","ogg","aif","mpega","amr","mid","midi","m4a","wmv","rmvb","mpeg4","mpeg2","flv","avi","3gp","mpga","qt","rm","wmz","wmd","wvx","wmx","wm","mpg","mp4","mkv","mpeg","mov","asf","m4v","m3u8","rar","zip");
	$tmp = explode(".",$filename);
	$type = strtolower(end($tmp));
	if(!in_array($type,$types)) return 'filedefualt';
	return 'file_'.$type;
}

function dzlab_output(){
	global $_G;
	$module = DISCUZ_ROOT.'./source/plugin/tshuz_attachcenter/module/rewrite.php';
	if(!file_exists($module)) return '';
	$rewrite = $_G['cache']['plugin']['tshuz_attachcenter']['rewrite'];
	if($rewrite == 1 || (!$rewrite && !$_G['uid'])){
		$content = ob_get_contents();
		ob_end_clean();
		ob_start();
		$find = $replace = array();
		$find[] = '/window\.location=\'plugin\.php\?id=tshuz_attachcenter(&|&amp;)mod=list(&|&amp;)fid=(\d+)(&|&amp;)page=\'\+this.value/';
		$replace[] = "window.location='download/list-\$3-'+this.value+'.html'";
		$find[] = '/plugin\.php\?id=tshuz_attachcenter(:tshuz_attachcenter|)(\'|\")/';
		$replace[] = "download/\$2";
		$find[] = '/plugin\.php\?id=tshuz_attachcenter(:tshuz_attachcenter|)(&|&amp;)mod=view(&|&amp;)aid=(\d+)/';
		$replace[] = "download/view-\$4.html";
		$find[] = '/plugin\.php\?id=tshuz_attachcenter(:tshuz_attachcenter|)(&|&amp;)mod=list(&|&amp;)fid=(\d+)(&|&amp;)page=(\d+)/';
		$replace[] = "download/list-\$4-\$6.html";
		$find[] = '/plugin\.php\?id=tshuz_attachcenter(:tshuz_attachcenter|)(&|&amp;)mod=list(&|&amp;)fid=(\d+)/';
		$replace[] = "download/list-\$4-1.html";
		$content = preg_replace($find,$replace,$content);
		echo $content;
	}
}
//From: Dism_taobao-com
?>