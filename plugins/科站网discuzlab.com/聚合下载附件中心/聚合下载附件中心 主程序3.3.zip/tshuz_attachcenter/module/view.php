<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$aid = dintval($_GET['aid']);
if(!$aid) showmessage($dlang['lang013']);

$attach = C::t("forum_attachment")->fetch($aid);
$downloads = $attach['downloads'];
$tableid = $attach['tableid'];
$attach = C::t("forum_attachment_n")->fetch($tableid,$aid);
if(!$attach) showmessage($dlang['lang013']);
$pid = $attach['pid'];
include libfile("function/magic");
$post = getpostinfo($pid,'pid');
if($post['status']) showmessage($dlang['lang051']);
$fid = $post['fid'];
if($attach['isimage']){
	$attach['cover'] = defined("IN_MOBILE")?getforumimg($attach['aid'], 0, 155,155):getforumimg($attach['aid'], 0, 260,183);
}
$attach['filesize'] = sizecount($attach['filesize']);
$attach['dateline'] = dgmdate($attach['dateline'],'u');
$ext = $_G['setting']['creditstrans'];
$unittitle = $_G['setting']['extcredits'][$ext]['unit'].$_G['setting']['extcredits'][$ext]['title'];
require_once libfile('function/post');
$postsummary = str_replace(array("\r", "\n"), '', messagecutstr(strip_tags($post['message']), 430));
$find =array(" ","　","\t","\n","\r");
$replace =array("","","","","");
$postsummary = str_replace($find,$replace,$postsummary).'...';
$download = array();
$getAid = getAid($aid,$tableid);
$download['normal'] = 'forum.php?mod=attachment&aid='.$getAid;
$download['fast'] = thunder($_G['siteurl'].$_G['setting']['attachurl'].'forum/'.$attach['attachment']);
$fast = explode("|",$pvars['fast']);
$normal = explode("|",$pvars['normal']);
$hasbuy = true;
if($attach['price'] && $_G['uid'] != $post['authorid']){//检查是否购买过
	$result = C::t("common_credit_log")->fetch_all_by_uid_operation_relatedid($_G['uid'],'BAC',$aid);
	$hasbuy = count($result)?true:false;
}
$navtitle = $dlang['lang032'].$attach['filename']." - ".$_G['cache']['forums'][$fid]['name']." - ".$dlang['lang033'];
include template("tshuz_attachcenter:view");
?>