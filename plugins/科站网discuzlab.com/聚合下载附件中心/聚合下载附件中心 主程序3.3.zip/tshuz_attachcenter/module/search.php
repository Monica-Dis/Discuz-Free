<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$keyword = daddslashes($_GET['kw']);
if(!$keyword){
	$navtitle = $dlang['lang049'];
	include template("tshuz_attachcenter:search_index");
}else{
	if($_GET['formhash'] != FORMHASH) showmessage($dlang['lang014']);
	$fids = array();
	foreach($forums as $fid=>$forum){
		$fids[] = $fid;
	}
	$perpage = 10;
	$page = intval ( $_GET ['page'] ) ? intval ( $_GET ['page'] ) : 1;
	$start = ($page - 1) * $perpage;
	if ($start < 0) $start = 0;

	$attachments = getNewByFids($keyword, $fids, $start, $perpage, $pvars['isimage']);
	$count = $attachments['count'];
	$attachments = $attachments['list'];
	foreach ($attachments as $k => $attach) {
		$attachments[$k]['filesize'] = sizecount($attach['filesize']);
		$attachments[$k]['dateline'] = dgmdate($attach['dateline'], 'u');
		$attachments[$k]['class'] = typeclass($attach['filename']);
	}
	$multi=	multi($count, $perpage, $page, 'plugin.php?id=tshuz_attachcenter&mod=search&kw='.$keyword."&formhash=".FORMHASH );
	$navtitle = $dlang['lang046'].$keyword;
	include template("tshuz_attachcenter:search_list");
}


function getNewByFids($keyword,$fids ,$start,$perpage,$isimage)
{
	$postTable = DB::table('forum_post');
	$keyword = str_replace(array('%','_'),'', $keyword);
	$where = ($isimage?' AND a.isimage=0':'').' AND '.DB::field('fid',$fids)." AND filename LIKE '%".$keyword."%' ";
	$sql = <<<EOF
( SELECT * FROM {$postTable} as p LEFT JOIN forum_attachment_n as a on p.pid=a.pid WHERE aid>0 {$where})
EOF;
	$sqls = array();
	for ($i = 0; $i <= 9; $i++) {
		$sqls[] = str_replace(array('forum_attachment_n', '%d'), array(DB::table('forum_attachment_' . $i), $i), $sql);
	}
	$sql = implode(' union all ', $sqls);
	$count = 0;
	foreach (DB::fetch_all(str_replace('*', 'count(aid) as n,p.fid', $sql)) as $v) {
		$count += $v['n'];
	}
	
	return array(
		'list'=> DB::fetch_all($sql . ' ORDER BY aid DESC LIMIT ' . $start . ',' . $perpage),
		'count'=>$count
	);
}