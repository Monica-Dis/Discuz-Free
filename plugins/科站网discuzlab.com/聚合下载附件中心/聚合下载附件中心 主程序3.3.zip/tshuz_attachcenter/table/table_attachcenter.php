<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_attachcenter extends discuz_table{
	public function __construct() {
		$this->_table = 'tshuz_attachcenter';
		$this->_pk    = 'aid';
		parent::__construct(); /*d'.'i'.'sm.ta'.'o'.'bao.com*/
	}

	public function insert($data){
		DB::insert($this->_table, $data, true, true); //插入数据
	}

	public function delete_all(){
		return DB::query("DELETE FROM %t WHERE aid >0",array($this->_table));
	}

	public function fetch_all_image_by_fids($fids,$start,$perpage){
		$where = DB::field('fid', $fids);
		return DB::fetch_all("SELECT * FROM %t WHERE %i AND isimage != 0 ORDER BY aid DESC limit %d,%d",array($this->_table,$where,$start,$perpage));
	}

	public function fetch_all_not_image_by_fids($fids,$start,$perpage){
		$where = DB::field('fid', $fids);
		return DB::fetch_all("SELECT * FROM %t WHERE %i AND isimage = 0 ORDER BY aid DESC limit %d,%d",array($this->_table,$where,$start,$perpage));
	}

	public function count_by_fid($fid,$isimage = 0){
		$where = $isimage?" AND isimage=0 ":"";
		return DB::result_first("SELECT count(*) FROM %t WHERE fid=%d %i",array($this->_table,$fid,$where));
	}

	public function fetch_all_by_fid($fid,$start,$perpage,$isimage = 0){
		$where = $isimage?" AND isimage=0 ":"";
		return DB::fetch_all("SELECT * FROM %t WHERE fid=%d %i ORDER BY aid DESC limit %d,%d",array($this->_table,$fid,$where,$start,$perpage));
	}
	

}

?>