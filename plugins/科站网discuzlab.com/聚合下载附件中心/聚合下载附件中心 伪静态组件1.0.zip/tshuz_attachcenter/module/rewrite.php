<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$onoff = $_G['cache']['plugin']['tshuz_attachcenter']['guest'];
if($onoff < 0) cpmsg($dlang['lang015'],"","error");
$rule = array();
$rule['{apache1}'] = $rule['{apache2}'] = $rule['{iis}'] = $rule['{iis7}'] = $rule['{zeus}'] = $rule['{nginx}'] = '';
$rulerdata = array();
$rule['{apache1}'] .= "\tRewriteCond %{QUERY_STRING} ^(.*)$".PHP_EOL;
$rule['{apache1}'] .= "\tRewriteRule ^(.*)/download/$ $1/plugin.php?id=tshuz_attachcenter&%1".PHP_EOL;
$rule['{apache1}'] .= "\tRewriteCond %{QUERY_STRING} ^(.*)$".PHP_EOL;
$rule['{apache1}'] .= "\tRewriteRule ^(.*)/download/list-([0-9]+)-([0-9]+).html$ $1/plugin.php?id=tshuz_attachcenter&mod=list&fid=$2&page=$3&%1".PHP_EOL;
$rule['{apache1}'] .= "\tRewriteCond %{QUERY_STRING} ^(.*)$".PHP_EOL;
$rule['{apache1}'] .= "\tRewriteRule ^(.*)/download/view-([0-9]+).html$ $1/plugin.php?id=tshuz_attachcenter&mod=view&aid=$2&%1".PHP_EOL;

$rule['{apache2}'] .= "RewriteCond %{QUERY_STRING} ^(.*)$".PHP_EOL;
$rule['{apache2}'] .= "RewriteRule ^download/$ plugin.php?id=tshuz_attachcenter&%1".PHP_EOL;
$rule['{apache2}'] .= "RewriteCond %{QUERY_STRING} ^(.*)$".PHP_EOL;
$rule['{apache2}'] .= "RewriteRule ^download/list-([0-9]+)-([0-9]+).html$ plugin.php?id=tshuz_attachcenter&mod=list&fid=$1&page=$2&%1".PHP_EOL;
$rule['{apache2}'] .= "RewriteCond %{QUERY_STRING} ^(.*)$".PHP_EOL;
$rule['{apache2}'] .= "RewriteRule ^download/view-([0-9]+).html$ plugin.php?id=tshuz_attachcenter&mod=view&aid=$1&%1".PHP_EOL;

$rule['{iis}'] .= "RewriteRule ^download/(\?(.*))*$ $1/plugin\.php\?id=tshuz_attachcenter&%1".PHP_EOL;
$rule['{iis}'] .= "RewriteRule ^download/list-([0-9]+)-([0-9]+).html(\?(.*))*$ $1/plugin\.php\?id=tshuz_attachcenter&mod=list&fid=$2&page=$3&%1".PHP_EOL;
$rule['{iis}'] .= "RewriteRule ^download/view-([0-9]+).html(\?(.*))*$ $1/plugin\.php\?id=tshuz_attachcenter&mod=view&aid=$2&%1".PHP_EOL;

$rule['{iis7}'] .= "\t\t<rule name=\"tshuz_attachcenter\">".PHP_EOL;
$rule['{iis7}'] .= "\t\t\t".'<match url="^(.*/)*download/\?*(.*)$" />'.PHP_EOL;
$rule['{iis7}'] .= "\t\t\t".'<action type="Rewrite" url="{R:1}/plugin.php\?id=tshuz_attachcenter&amp;{R:2}" />'.PHP_EOL;
$rule['{iis7}'] .= "\t\t</rule>".PHP_EOL;
$rule['{iis7}'] .= "\t\t<rule name=\"tshuz_attachcenter_list\">".PHP_EOL;
$rule['{iis7}'] .= "\t\t\t".'<match url="^(.*/)*download/list-([0-9]+)-([0-9]+).html\?*(.*)$" />'.PHP_EOL;
$rule['{iis7}'] .= "\t\t\t".'<action type="Rewrite" url="{R:1}/plugin.php\?id=tshuz_attachcenter&amp;mod=list&amp;fid={R:2}&amp;page={R:3}&amp;{R:4}" />'.PHP_EOL;
$rule['{iis7}'] .= "\t\t</rule>".PHP_EOL;
$rule['{iis7}'] .= "\t\t<rule name=\"tshuz_attachcenter_view\">".PHP_EOL;
$rule['{iis7}'] .= "\t\t\t".'<match url="^(.*/)*download/view-([0-9]+).html\?*(.*)$" />'.PHP_EOL;
$rule['{iis7}'] .= "\t\t\t".'<action type="Rewrite" url="{R:1}/plugin.php\?id=tshuz_attachcenter&amp;mod=view&amp;aid={R:2}&amp;{R:3}" />'.PHP_EOL;
$rule['{iis7}'] .= "\t\t</rule>".PHP_EOL;
$rule['{iis7}'] = htmlentities($rule['{iis7}']);

$rule['{zeus}'] .= 'match URL into $ with ^(.*)/download/\?*(.*)$'.PHP_EOL.'if matched then'.PHP_EOL."\t";
$rule['{zeus}'] .= 'set URL = $1/plugin.php?id=tshuz_attachcenter&$2'.PHP_EOL.'endif';
$rule['{zeus}'] .= 'match URL into $ with ^(.*)/download/list-([0-9]+)-([0-9]+)\.html\?*(.*)$'.PHP_EOL.'if matched then'.PHP_EOL."\t";
$rule['{zeus}'] .= 'set URL = $1/plugin.php?id=tshuz_attachcenter&mod=list&fid=$2&page=$3&$4'.PHP_EOL.'endif';
$rule['{zeus}'] .= 'match URL into $ with ^(.*)/download/view-([0-9]+)\.html\?*(.*)$'.PHP_EOL.'if matched then'.PHP_EOL."\t";
$rule['{zeus}'] .= 'set URL = $1/plugin.php?id=tshuz_attachcenter&mod=view&aid=$2&$3'.PHP_EOL.'endif';

$rule['{nginx}'] .= 'rewrite ^([^\.]*)/download/$ $1/plugin.php?id=tshuz_attachcenter last;'.PHP_EOL;
$rule['{nginx}'] .= 'rewrite ^([^\.]*)/download/list-([0-9]+)-([0-9]+)\.html$ $1/plugin.php?id=tshuz_attachcenter&mod=list&fid=$2&page=$3 last;'.PHP_EOL;
$rule['{nginx}'] .= 'rewrite ^([^\.]*)/download/view-([0-9]+)\.html$ $1/plugin.php?id=tshuz_attachcenter&mod=view&aid=$2 last;'.PHP_EOL;
$rule['{nginx}'] .= 'if (!-e $request_filename) {'.PHP_EOL."\treturn 404;".PHP_EOL.'}';

echo str_replace(array_keys($rule), $rule, cplang('rewrite_message'));
?>