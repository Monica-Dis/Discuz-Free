<?php

/**
 *      Copyright (c) 2020 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: addons.inc.php 2017-08-18 14:10:38Z Todd $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* 插件代码开始 */

?>
<script type="text/javascript">location.href="https://dism.taobao.com/?@838.developer";</script>