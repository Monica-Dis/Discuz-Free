<?php

/**
 *      Copyright (c) 2020 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: mobile.class.php 2017-08-18 13:32:51Z Todd $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */

class mobileplugin_tshuz_mkefu {
	function global_footer_mobile(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_mkefu'];
		$set = array();
		foreach(explode(PHP_EOL,$pvars['set']) as $v){
			list($type,$val) = explode("=",$v,2);
			if(in_array($type,array("qq","tel",'sms','wechat')) && $val){
				$set[] = array("type"=>$type,'val'=>$val);
			}
		}
		include template("tshuz_mkefu:tshuz_mkefu");
		return $return;
	}
}
//From: Dism·taobao·com
?>