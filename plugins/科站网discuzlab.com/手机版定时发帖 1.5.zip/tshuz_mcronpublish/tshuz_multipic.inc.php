<?php

/**
 *      应用更新支持：https://dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: tshuz_multipic.inc.php 2018-10-31 09:44:01Z Dism·taobao·com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* 插件代码开始 */

?><script type="text/javascript">location.href="https://dism.taobao.com/?@tshuz_multipic.plugin";</script>