<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_tshuz_mcronpublish_forum {
	function post_bottom_mobile_output(){
		global $_G,$isfirstpost,$thread,$cronpublish,$cronpublishdate;
		if($_G['group']['allowsetpublishdate'] && ($_GET['action'] == 'newthread' || ($_GET['action'] == 'edit' && $isfirstpost && $thread['displayorder'] == -4))){
			if($cronpublishdate){
				$cronpublishdate = strtotime($cronpublishdate);
				$cronpublishdate = date('Y-m-d',$cronpublishdate).'T'.date('H:i',$cronpublishdate);
			}
			$post_timer = lang("forum/template",'post_timer');
			include template("tshuz_mcronpublish:tshuz_mcronpublish");
			return $return;
		}
	}
}
//From: Dism��taobao��com
?>