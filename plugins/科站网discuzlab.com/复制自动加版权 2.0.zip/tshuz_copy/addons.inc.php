<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: addons.inc.php 2019-11-29 16:50:28Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* ������뿪ʼ */

?><script type="text/javascript">location.href="https://dism.taobao.com/?@838.developer";</script>