<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: hook.class.php 2019-11-29 16:50:13Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


class plugin_tshuz_copy {
	
	function global_footer() {
	    global $_G;
		if(!in_array($_G['groupid'],unserialize($_G['cache']['plugin']['tshuz_copy']['groups']))) return '';
		$text = str_replace("\r",'',$_G['cache']['plugin']['tshuz_copy']['text']);
		$text1 = str_replace("\n",'<br>',$text);
		$text2 = str_replace('<br>',"\\n",$text1);
		include template('tshuz_copy:tshuz_copy');
		return $return;
	}
}