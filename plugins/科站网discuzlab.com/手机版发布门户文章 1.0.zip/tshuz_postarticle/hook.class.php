<?php

/**
 *      (C)2001-2099 DiscuzLab.com.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: hook.class.php 2020-07-27 00:55:51Z Todd $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* ������뿪ʼ */

class mobileplugin_tshuz_postarticle_portal {
	function portalcp_limit(){
		global $_G;
		if($_GET['ac'] != 'article') return '';
		$pvars = $_G['cache']['plugin']['tshuz_postarticle'];
		$formValues = unserialize($pvars['values']);
		include DISCUZ_ROOT.'./source/language/portal/lang_template.php';
		include libfile('portal/portalcp', 'plugin/tshuz_postarticle/module');
		return '';
	}

	function attachment_limit(){
		global $_G;
		if($_GET['op'] != 'getattach') return '';
		include libfile('portal/attachment', 'plugin/tshuz_postarticle/module');
		return '';
	}

}
class mobileplugin_tshuz_postarticle_home
{
	function editor_limit()
	{
		global $_G;
		//include DISCUZ_ROOT . './source/language/portal/lang_template.php';
		include libfile('home/editor', 'plugin/tshuz_postarticle/module');
		return '';
	}
}


