<?php

/**
 *      (C)2001-2099 DiscuzLab.com.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: admincp.inc.php 2018-08-13 15:58:46Z Todd $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* 插件代码开始 */
if($_GET['op'] ){
	include libfile('admincp/plugins','plugin/plugintools');
	exit;
}
$isLayuimini = file_exists(DISCUZ_ROOT . './source/plugin/admincenter/layuimini/css/public.css');
loadcache('plugin');
shownav('plugin');
$plugins = C::t('common_plugin')->fetch_all_data();
$enable = $disable = $installed = array();
foreach($plugins as $plugin){
	$identifier = $plugin['identifier'];
	$installed[] = $identifier;
	if($plugin['available']){
		$enable[$identifier] = $plugin;
	}else{
		$disable[$identifier] = $plugin;
	}
}
if(empty($_G['cookie']['addoncheck_plugin'])) {
	foreach($plugins as $plugin) {
		$addonids[$plugin['pluginid']] = $plugin['identifier'].'.plugin';
	}
	$checkresult = dunserialize(cloudaddons_upgradecheck($addonids));
	savecache('addoncheck_plugin', $checkresult);
	dsetcookie('addoncheck_plugin', 1, 43200);
} else {
	loadcache('addoncheck_plugin');
	$checkresult = $_G['cache']['addoncheck_plugin'];
}
if($enable){
	showList($enable,'plugins_list_available');
}
if($disable){
	showList($disable,'plugins_list_unavailable');
}

$plugindir = DISCUZ_ROOT.'./source/plugin';
$pluginsdir = dir($plugindir);
$newplugins = array();
showtableheader('', 'psetting');
$newlist = array();
while($entry = $pluginsdir->read()) {
	
	if(!in_array($entry, array('.', '..')) && is_dir($plugindir.'/'.$entry) && !in_array($entry,array_keys($enable)) && !in_array($entry,array_keys($disable)) ) {
		$entrydir = DISCUZ_ROOT.'./source/plugin/'.$entry;
		$d = dir($entrydir);
		$filemtime = filemtime($entrydir);
		$entrytitle = $entry;
		$entryversion = $entrycopyright = $importtxt = '';
		$extra = currentlang();
		$extra = $extra ? '_'.$extra : '';
		if(file_exists($entrydir.'/discuz_plugin_'.$entry.$extra.'.xml')) {
			$importtxt = @implode('', file($entrydir.'/discuz_plugin_'.$entry.$extra.'.xml'));
		} elseif(file_exists($entrydir.'/discuz_plugin_'.$entry.'.xml')) {
			$importtxt = @implode('', file($entrydir.'/discuz_plugin_'.$entry.'.xml'));
		}
		if($importtxt) {
			$pluginarray = getimportdata('Discuz! Plugin', 0, 1);
			if(!empty($pluginarray['plugin']['name'])) {
				$entrytitle = dhtmlspecialchars($pluginarray['plugin']['name']);
				$entryversion = dhtmlspecialchars($pluginarray['plugin']['version']);
				$entrycopyright = dhtmlspecialchars($pluginarray['plugin']['copyright']);
			}
			$file = $entrydir.'/'.$f;
			$newlist[$entry] = array(
				'name'=>$entrytitle,
				'copyright'=>($entrycopyright ? cplang('author').': '.$entrycopyright : '')

			);
		}
	}
}
if($newlist) {
	showtableheader('plugins_list_new',$tableclass.' dzlab" border="1" bordercolor="#efefef');
	$href = ADMINSCRIPT.'?action=plugins&operation=config&identifier=plugintools&pmod=admincp';
	echo '<tr><td>';
	foreach($newlist as $identifier=>$plugin){
		$href .= '&didentifier='.$identifier;
		echo '<div class="div '.$identifier.'"><div class="td"><div class="addon_info"><div class="addon_icon"><img src="http://addon.dismall.com/?_'.$identifier.'" width="40" onerror="javascript:this.src=\'static/image/admincp/plugin_logo.png\';"></div><div class="plugin"><span class="bold">'.$plugin['name'].'</span><span class="sml">('.$identifier.')</span><br>'.$plugin['copyright'].'</div></div>';
		echo '<div class="ctrol"><input type="checkbox"'.$checked.' id="'.$identifier.'" class="cbox"><label for="'.$identifier.'" class="green" title="'.$lang['plugins_config_install'].'" onclick="install(\''.$identifier.'\')"></label></div>';
		echo '</div>'.'<p class="menulist">'.implode('<br>', $submenuitem).'</p></div>';
	}
	echo '</td></tr>';
	showtablefooter();
}

function showList($list,$title){
	global $lang,$checkresult,$_G;
	loadcache('plugin');
	$ignores = explode("\n",str_replace("\r",'',$_G['cache']['plugin']['plugintools']['ignore']));
	$tableclass = $title == 'plugins_list_available' ? 'available' : 'unavailable';
	showtableheader($title,$tableclass.' dzlab" border="1" bordercolor="#efefef');
	echo '<tr><td>';
	foreach($list as $identifier=>$plugin){
		$checked = $plugin['available'] ? ' checked="checked"':'';
		$plugin['modules'] = unserialize($plugin['modules']);
		$submenuitem = submenu($plugin);

		$addonid = $plugin['identifier'].'.plugin';
		$updateinfo = '';
		list(, $newver, $sysver) = explode(':', $checkresult[$addonid]);
		if(!in_array($plugin['identifier'], $ignores)){
			if ($sysver && $sysver > $plugin['version']) {
				$updateinfo = '<a href="' . ADMINSCRIPT . '?action=cloudaddons&id=' . $addonid . '" title="' . $lang['plugins_online_update'] . '"><font color="red">' . $lang['plugins_find_newversion'] . ' ' . $sysver . '</font></a>';
			} elseif ($newver) {
				$updateinfo = '<a href="' . ADMINSCRIPT . '?action=cloudaddons&id=' . $addonid . '" title="' . $lang['plugins_online_update'] . '"><font color="red">' . $lang['plugins_find_newversion'] . ' ' . $newver . '</font></a>';
			}
		}


		$href = ADMINSCRIPT.'?action=plugins&operation=config&identifier=plugintools&pmod=admincp';
		$href .= '&didentifier='.$identifier;
		echo '<div class="div '.$identifier.'"><div class="td"><div class="addon_info"><div class="addon_icon"><img src="http://addon.dismall.com/?_'.$identifier.'" width="40" onerror="javascript:this.src=\'static/image/admincp/plugin_logo.png\';"></div><div class="plugin"><span class="bold">'.$plugin['name'].' '.$plugin['version'].'</span><span class="sml">('.$identifier.')</span><br>'.($submenuitem ?'<span onmouseover="showmenu(\''.$identifier.'\')" class="dmenu">'.$lang['config'].'&nbsp;&nbsp;</span>':'').( "<a href=\"".$href."&op=enable&pluginid=$plugin[pluginid]&formhash=".FORMHASH.(!empty($_GET['system']) ? '&system=1' : '')."\" class=\"bold enable\">$lang[enable]</a>" . "<a href=\"".$href."&op=disable&pluginid=$plugin[pluginid]&formhash=".FORMHASH.(!empty($_GET['system']) ? '&system=1' : '')."\"  class=\"closed\">$lang[closed]</a>").
		"&nbsp;&nbsp;<a href=\"".$href."&op=upgrade&pluginid=$plugin[pluginid]\">$lang[plugins_config_upgrade]</a>&nbsp;&nbsp;".
		(!$plugin['modules']['system'] ? "<a href=\"javascript:;\" onclick=\"uninstall({$plugin['pluginid']},'{$plugin['name']}','{$plugin['version']}')\">$lang[plugins_config_uninstall]</a>&nbsp;&nbsp;" : '').$updateinfo.'</div></div>';
		echo '<div class="ctrol"><input type="checkbox"'.$checked.' id="'.$identifier.'" class="cbox"><label for="'.$identifier.'" class="green" data-pluginid="'.$plugin['pluginid'].'" onclick="onoff(this)"></label></div>';
		echo '</div>'.'<p class="menulist" onMouseLeave="hidemenu(\''.$identifier.'\')">'.implode('<br>', $submenuitem).'</p></div>';
	}
	echo '</td></tr>';
	showtablefooter();
}
if($isLayuimini)
echo <<<EOF
<script>
var layui = window.parent.layui;
var miniTab = null;
layui.use(['form','miniTab'], function () {
            miniTab = layui.miniTab;

});
function newTab(url,title){
    miniTab.openNewTabByIframe({
        href:url,
        title:title,
    });
}


</script>
EOF;

function submenu($plugin)
{
	global $_G, $lang, $isLayuimini;
	$submenuitem = array();
	if (isset($_G['cache']['plugin'][$plugin['identifier']])) {
		$href = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin['pluginid'];
		$submenuitem[] = submenuhref($href, $lang['config'], $plugin, false);
	}
	if (is_array($plugin['modules'])) {
		foreach ($plugin['modules'] as $module) {
			if ($module['type'] == 3) {
				$href = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin['pluginid'] . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module['name'] . ($module['param'] ? '&' . $module['param'] : '');
				$submenuitem[] = submenuhref($href, $module['menu'], $plugin, false);
			}
			if ($module['type'] == 29) {
				$submenuitem[] = submenuhref($module['url'], $module['menu'], $plugin, true);
			}
		}
	}
	return $submenuitem;
}

function submenuhref($href,$title,$plugin,$target = false){
	global $isLayuimini;
	if($isLayuimini) {
		return '<a href="javascript:;" onclick="newTab(\'' . $href . '\',\''.$plugin['name'].'\')" >' . $title . '</a>';
	}else{
		return '<a href="'.$href.'" '.($target? 'target="_blank"':'').'>'.$title.'</a>';
	}

}


function dcpmsg($message, $url = '', $type = '', $values = array(), $extra = '', $halt = TRUE, $cancelurl = '') {
	global $lang;
	if($_GET['in_ajax']){
		ob_end_clean();
		$message = lang('admincp_msg',$message);
		$message = explode('<br',$message);
		$message = strip_tags($message[0]);
		$data = array('type'=>$type,'msg'=>urlencode($message));
		define('FOOTERDISABLED' , 1);
		echo urldecode(json_encode($data));exit;
	}else{
		if($message != 'plugins_config_upgrade_confirm')
		$url = 'action=plugins&operation=config&identifier=plugintools&pmod=admincp';
		cpmsg($message, $url, $type , $values , $extra, $halt, $cancelurl ) ;
	}
}
$uninstalltip = lang('plugin/plugintools','I9kQ8k');
$href = ADMINSCRIPT.'?action=plugins&operation=config&identifier=plugintools&pmod=admincp&formhash='.FORMHASH;
$str = <<<EOF
<link href="source/plugin/plugintools/static/common.css?{$_G['style']['verhash']}" rel="stylesheet" type="text/css" />
<script src="source/plugin/plugintools/static/jquery.min.js?{$_G['style']['verhash']}" type="text/javascript"></script>
<script src="source/plugin/plugintools/static/layer.js?{$_G['style']['verhash']}" type="text/javascript"></script>
<script>
var jq=$.noConflict();
function onoff(which){
	var ajaxUrl = '{$href}&in_ajax=1&op=';
	var identifier = jq(which).attr('for');
	var key = jq('#'+identifier).is(':checked')?'unavailable':'available';
	var op = jq('#'+identifier).is(':checked')?'disable':'enable';
	ajaxUrl += op+'&pluginid='+jq(which).attr('data-pluginid');
	var obj = jq(which);
	jq.ajax({
		type: "GET",
		url: ajaxUrl,
		dataType: 'json',
		success: function(data){
			if(data.type == 'succeed'){
				var html = obj.parents('.div');
				obj.parents('.div').remove();
				if(op == 'disable'){
					jq('#'+identifier).attr("chacked",false).removeAttr("checked");
				}
				jq('.'+key+' td:eq(0)').append(html);
			}
			layer.msg(data.msg);
		}
	 });
}
function uninstall(pluginid,pluginname,pluginversion){
	layer.confirm('{$uninstalltip} '+pluginname+' '+pluginversion+'?', {
		btn: ['{$lang[plugins_config_uninstall]}','{$lang[no]}']
	}, function(){
		var url = '{$href}&op=delete&pluginid='+pluginid;
		window.location.href=url
	});
}
function install(identifier){
	var url = '{$href}&op=import&dir='+identifier;
	window.location.href=url
}
function showmenu(identifier){
	jq('.'+identifier).find('.menulist').css('display','inline-block');	
}
function hidemenu(identifier){
	jq('.'+identifier).find('.menulist').hide();	
}

</script>
EOF;
echo $str;