<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: admincp_main.php 36284 2016-12-12 00:47:50Z nemohou $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

lang('admincp_menu');

$extra = cpurl('url');
$extra = $extra && getgpc('action') ? $extra : 'action=index';
$charset = CHARSET;
$title = cplang('admincp_title');
$header_welcome = cplang('header_welcome');
$header_logout = cplang('header_logout');
$header_bbs = cplang('header_bbs');
if(isfounder()) {
	cplang('founder_admin');
} else {
	if($GLOBALS['admincp']->adminsession['cpgroupid']) {
		$cpgroup = C::t('common_admincp_group')->fetch($GLOBALS['admincp']->adminsession['cpgroupid']);
		$cpadmingroup = $cpgroup['cpgroupname'];
	} else {
		cplang('founder_master');
	}
}

require DISCUZ_ROOT.'./source/admincp/admincp_menu.php';

$basescript = ADMINSCRIPT;
if($_GET['init']){
	$data = array('logoInfo'=>array('title'=>'Discuz!','image'=>'source/plugin/admincenter/layuimini/images/logo.png','href'=>''));
	$data['homeInfo'] = array(
		'title'=>cplang('menu_home'),
		'href'=>$basescript .'?action=index'
	);
	$data['menuInfo'] = array();
	$headerMenus = $menus = array();
	foreach($menu as $k=>$vals){
		$title = strpos(cplang('header_'.$k),'header_') === false ? cplang('header_'.$k) : $k;
		if(in_array($title,$headerMenus)) continue;
		if($vals){
			$menus[$k] = array('titles'=>$title);
			foreach($vals as $_k=>$_v){
				if(strpos($_v[1], 'plugins&operation=config') === false){
					list($action, $operation, $do) = explode('_', $_v[1]);
					$_v[1] = $action.($operation ? '&operation='.$operation.($do ? '&do='.$do : '') : '');
                }
				$menus[$k]['subs'][$_k] = array(cplang($_v[0]),substr($_v[1], 0, 4) == 'http' ? $_v[1] : ADMINSCRIPT.'?action='.$_v[1]);
			}
		}
		$headerMenus[] = $title;
	}
	foreach($menus as $k=>$vals){
		$child = array();
		foreach($vals['subs'] as $_k=>$_vals){
			$child[$_k] = array(
				'title'=>$_vals[0],
				'href'=>$_vals[1],
				'target'=>'_self',
				'icon'=>'fa fa-navicon'
			);
		}
		$data['menuInfo'][] = array(
			'title'=>$vals['titles'],
			'href'=>'',
			'target'=>'_self',
			'icon'=>'',
			'child'=>$child
		);
	}
    loaducenter();
    $uc_api_url = '';
    if ($isfounder) {
        $data['menuInfo'][] = array(
            'title' => cplang('header_uc'),
            'href' => '',
            'target' => '_self',
            'icon' => '',
            'child'=> array(
                array(
                    'title' => cplang('header_uc'),
                    'href' => UC_API . '/admin.php?m=frame',
                    'target' => '_self',
                    'icon' => 'fa fa-navicon'
                )
            )
        );
    }


	$data = charsetToUtf8($data);
	echo json_encode($data);exit;
}
function charsetToUtf8($data){
    if(is_array($data)){
        return array_map('charsetToUtf8', $data);    
	}
	return diconv($data,CHARSET,'utf-8');
}

$inmobile = checkmobile();
$inmobile = $inmobile?'?mobile='. $inmobile :'';
$miniTab = '';
if($_GET['action']){
    unset($_GET['frames']);
    
    $url = ADMINSCRIPT.'?'. http_build_query($_GET);
    $miniTab = <<<EOT
        miniTab.openNewTabByIframe({
            href:"{$url}",
            title:"&#20020;&#26102;&#31383;&#21475;",
        });
EOT;
}
$formhash = FORMHASH;
echo <<<EOT
<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=$charset">
<title>$title</title>
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<meta http-equiv="Cache-Control" content="no-siteapp" />
<meta content="Comsenz Inc." name="Copyright" />
	<link rel="icon" href="source/plugin/admincenter/layuimini/images/favicon.ico">
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta http-equiv="Access-Control-Allow-Origin" content="*">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="stylesheet" href="source/plugin/admincenter/layuimini/lib/layui-v2.5.5/css/layui.css" media="all">
    <link rel="stylesheet" href="source/plugin/admincenter/layuimini/css/layuimini.css?v=2.0.4" media="all">
    <link rel="stylesheet" href="source/plugin/admincenter/layuimini/css/themes/default.css" media="all">
    <link rel="stylesheet" href="source/plugin/admincenter/layuimini/lib/font-awesome-4.7.0/css/font-awesome.min.css" media="all">

</head>

<body class="layui-layout-body layuimini-all">
<div class="layui-layout layui-layout-admin">

    <div class="layui-header header">
        <div class="layui-logo layuimini-logo"></div>

        <div class="layuimini-header-content">
            <a>
                <div class="layuimini-tool"><i class="fa fa-outdent" data-side-fold="1"></i></div>
            </a>

            <ul class="layui-nav layui-layout-left layuimini-header-menu layuimini-menu-header-pc layuimini-pc-show">
            </ul>

            <ul class="layui-nav layui-layout-left layuimini-header-menu layuimini-mobile-show">
                <li class="layui-nav-item">
                    <a href="javascript:;"><i class="fa fa-list-ul"></i> &#36873;&#25321;&#27169;&#22359;</a>
                    <dl class="layui-nav-child layuimini-menu-header-mobile">
                    </dl>
                </li>
            </ul>

            <ul class="layui-nav layui-layout-right">

                <li class="layui-nav-item" lay-unselect>
                    <a href="index.php{$inmobile}" target="_blank"><i class="fa fa-home"></i></a>
                </li>
                <li class="layui-nav-item layuimini-setting">
                    <a href="javascript:;">{$_G['username']}</a>
                    <dl class="layui-nav-child">
                        <dd>
                            <a href="$basescript?action=logout&formhash={$formhash}" target="_top" class="login-out">$header_logout</a>
                        </dd>
                    </dl>
                </li>
                <li class="layui-nav-item mobile layui-hide-xs" lay-unselect>
                    <a href="javascript:;" data-check-screen="full"><i class="fa fa-arrows-alt"></i></a>
                </li>
            </ul>
        </div>
    </div>
    <div class="layui-side layui-bg-black layuimini-menu-left" id="leftmenu">
    </div>
    <div class="layuimini-loader">
        <div class="layuimini-loader-inner"></div>
    </div>
    <div class="layuimini-make"></div>
    <div class="layuimini-site-mobile"><i class="fa fa-navicon"></i></div>

    <div class="layui-body">

        <div class="layuimini-tab layui-tab-rollTool layui-tab" lay-filter="layuiminiTab" lay-allowclose="true">
            <ul class="layui-tab-title">
                <li class="layui-this" id="layuiminiHomeTabId" lay-id=""></li>
            </ul>
            <div class="layui-tab-control">
                <li class="layuimini-tab-roll-left layui-icon layui-icon-left"></li>
                <li class="layuimini-tab-roll-right layui-icon layui-icon-right"></li>
                <li class="layui-tab-tool layui-icon layui-icon-down">
                    <ul class="layui-nav close-box">
                        <li class="layui-nav-item">
                            <a href="javascript:;"><span class="layui-nav-more"></span></a>
                            <dl class="layui-nav-child">
                                <dd><a href="javascript:;" layuimini-tab-refresh="now">&#21047;&#32;&#26032;&#32;&#24403;&#32;&#21069;</a></dd>
                                <dd><a href="javascript:;" layuimini-tab-close="current">&#20851;&#32;&#38381;&#32;&#24403;&#32;&#21069;</a></dd>
                                <dd><a href="javascript:;" layuimini-tab-close="other">&#20851;&#32;&#38381;&#32;&#20854;&#32;&#20182;</a></dd>
                                <dd><a href="javascript:;" layuimini-tab-close="all">&#20851;&#32;&#38381;&#32;&#20840;&#32;&#37096;</a></dd>
                            </dl>
                        </li>
                    </ul>
                </li>
            </div>
            <div class="layui-tab-content"><div id="layuiminiHomeTabIframe" class="layui-tab-item layui-show"></div>
            </div>
        </div>

    </div>
</div>
<script src="source/plugin/admincenter/layuimini/lib/layui-v2.5.5/layui.js" charset="utf-8"></script>
<script src="source/plugin/admincenter/layuimini/js/lay-config.js?v=2.0.0" charset="utf-8"></script>
<script>
	var $ = function(){
		
	};
    layui.use([ 'layer', 'miniAdmin','miniTab'], function () {
        var layer = layui.layer,
            miniAdmin = layui.miniAdmin,
            miniTab = layui.miniTab;

        var options = {
            iniUrl: "{$basescript}?init=1",
            urlHashLocation: false, 
            bgColorDefault: false, 
            multiModule: true,
            menuChildOpen: false,
            loadingTime: 0,
            pageAnim: true,
            maxTabNum: 99,
        };
        miniAdmin.render(options);
        {$miniTab}
    });
</script>

</body>
</html>

EOT;

?>