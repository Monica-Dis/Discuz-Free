<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: admincp_login.php 36284 2016-12-12 00:47:50Z nemohou $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if($this->core->var['inajax']) {
	ajaxshowheader();
	ajaxshowfooter();
}

if($this->cpaccess == -3) {
	html_login_header(false);
} else {
	html_login_header();
}


if($this->cpaccess == -3) {
	echo  '<p class="logintips">'.lang('admincp_login', 'login_cp_noaccess').'</p>';


}elseif($this->cpaccess == -1) {
	$ltime = $this->sessionlife - (TIMESTAMP - $this->adminsession['dateline']);
	echo  '<p class="logintips">'.lang('admincp_login', 'login_cplock', array('ltime' => $ltime)).'</p>';

}elseif($this->cpaccess == -4) {
	$ltime = $this->sessionlife - (TIMESTAMP - $this->adminsession['dateline']);
	echo  '<p class="logintips">'.lang('admincp_login', 'login_user_lock').'</p>';

} else {
	html_login_form();
}

html_login_footer();

function html_login_header($form = true) {
	$charset = CHARSET;
	$title = lang('admincp_login', 'login_title');
	$tips = lang('admincp_login', 'login_tips');
	echo <<<EOT
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=$charset" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0,  user-scalable=0;">

<title>$title</title>

	<link rel="stylesheet" type="text/css" href="source/plugin/admincenter/static/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="source/plugin/admincenter/static/main.css">
</head>
<body>
EOT;

	if($form) {
		echo <<<EOT
<script language="JavaScript">
	if(self.parent.frames.length != 0) {
		self.parent.location=document.location;
	}
</script>
<div class="login">
	<div class="container-login100">
		<div class="wrap-login100">
			<div class="login100-pic js-tilt" data-tilt>
				<img src="source/plugin/admincenter/static/img-01.png" alt="IMG">
			</div>
EOT;
	}
}

function html_login_footer($halt = true) {
	$version = getglobal('setting/version');
	echo <<<EOT
		</div>
	</div>
</div>

</body>
</html>

EOT;

	$halt && exit();
}

function html_login_form() {
	global $_G;
	$isguest = !getglobal('uid');
	$lang = lang('admincp_login');
	$loginuser = $isguest ? '<input name="admin_username" type="text" class="txt" autocomplete="off" />' : getglobal('member/username');
	$sid = getglobal('sid');
	$_SERVER['QUERY_STRING'] = str_replace('&amp;', '&', dhtmlspecialchars($_SERVER['QUERY_STRING']));
	$extra = ADMINSCRIPT.'?'.(getgpc('action') && getgpc('frames') ? 'frames=yes&' : '').$_SERVER['QUERY_STRING'];
	$forcesecques = '<option value="0">'.($_G['config']['admincp']['forcesecques'] || $_G['group']['forcesecques'] ? $lang['forcesecques'] : $lang['security_question_0']).'</option>';
	$disabled = $_G['usernmae']?' disabled readonly':'';
	echo <<<EOT
		<form method="post" autocomplete="off" name="login" id="loginform" class="login100-form validate-form" action="$extra">
		<input type="hidden" name="sid" value="$sid">
		<input type="hidden" name="frames" value="yes">
				<span class="login100-form-title"><font color="#f60">Discuz!</font> &#31649;&#29702;&#20013;&#24515;
				</span>
				<div class="wrap-input100 validate-input">
					<input class="input100" type="text" name="admin_username"{$disabled} value="{$_G['username']}" placeholder="$lang[login_username]">
					<span class="focus-input100"></span>
					<span class="symbol-input100">
						<i class="fa fa-user" aria-hidden="true"></i>
					</span>
				</div>
				<div class="wrap-input100 validate-input">
					<input class="input100" type="password" name="admin_password" placeholder="{$lang[login_password]}">
					<span class="focus-input100"></span>
					<span class="symbol-input100">
						<i class="fa fa-lock" aria-hidden="true"></i>
					</span>
				</div>
				<div class="wrap-input100 validate-input">
					<select id="questionid" class="input100" name="admin_questionid">
						$forcesecques
						<option value="1">$lang[security_question_1]</option>
						<option value="2">$lang[security_question_2]</option>
						<option value="3">$lang[security_question_3]</option>
						<option value="4">$lang[security_question_4]</option>
						<option value="5">$lang[security_question_5]</option>
						<option value="6">$lang[security_question_6]</option>
						<option value="7">$lang[security_question_7]</option>
					</select>
					<span class="focus-input100"></span>
					<span class="symbol-input100">
						<i class="fa fa-question-circle" aria-hidden="true"></i>
					</span>
				</div>
				<div class="wrap-input100 validate-input">
					<input class="input100" type="password" name="admin_answer" placeholder="{$lang[security_answer]}">
					<span class="focus-input100"></span>
					<span class="symbol-input100">
						<i class="fa fa-unlock" aria-hidden="true"></i>
					</span>
				</div>
				<div class="container-login100-form-btn">
					<button type="submit" class="login100-form-btn">
						{$lang[submit]}
					</button>
				</div>
		</form>
EOT;
		echo '<script type="text/JavaScript">document.getElementById(\'loginform\').admin_'.($isguest ? 'username' : 'password').'.focus();</script>';
}
//From: Dism_taobao_com
?>