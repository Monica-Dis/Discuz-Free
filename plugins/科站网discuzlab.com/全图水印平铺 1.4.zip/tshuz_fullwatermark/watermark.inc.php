<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: watermark.inc.php 2020-01-20 05:20:44Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* ������뿪ʼ */
$source = DISCUZ_ROOT.'./source/plugin/tshuz_fullwatermark/watermarkpreview.jpg';
$sizesource = filesize($source);
$target = $_G['setting']['attachdir'].'./temp/watermark_temp3.jpg';
@unlink($target);
include libfile('function/core','plugin/tshuz_fullwatermark');
fullwatermark($source,$target);
$sizetarget1 = filesize($target);
showtips(lang('plugin/tshuz_fullwatermark','Yas991'));
echo $lang['imagepreview_imagesize_source'].' '.number_format($sizesource).' Bytes &nbsp;&nbsp;'.
$lang['imagepreview_imagesize_target'].' '.number_format($sizetarget1).' Bytes ('.
		(sprintf("%2.1f", $sizetarget1 / $sizesource * 100)).'%)<br /><br /><img src="data/attachment/temp/watermark_temp3.jpg?'.random(5).'">';