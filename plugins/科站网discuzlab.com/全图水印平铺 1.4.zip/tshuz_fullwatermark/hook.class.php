<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: hook.class.php 2020-01-19 06:42:05Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */

class tshuz_fullwatermark {
	function swfupload_fullwatermar(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_fullwatermark'];
		if(!in_array($_G['groupid'],dunserialize($pvars['groups']))) return '';
		$attachext = $this->fileext($_FILES['Filedata']['name']);
		if(!$this->is_image_ext($attachext)) return '';
		if(!$_GET['fid']){
			$urlDatas = parse_url(dreferer());
			if(!$urlDatas['query']) return '';
			parse_str($urlDatas['query'],$querys);
			$_GET['fid'] = $querys['fid'];
			if(!$_GET['fid']) return '';
		}
		if($_GET['fid'] && !in_array($_GET['fid'],unserialize($pvars['forums']))) return '';


		include libfile('function/core','plugin/tshuz_fullwatermark');
		fullwatermark($_FILES['Filedata']['tmp_name']);
		return '';
	}

	
	private function is_image_ext($ext) {
		static $imgext  = array('jpg', 'jpeg', 'png', 'bmp');
		return in_array($ext, $imgext) ? 1 : 0;
	}

	private function fileext($filename) {
		return addslashes(strtolower(substr(strrchr($filename, '.'), 1, 10)));
	}

	function common(){
		global $_G;
		$pvars = $_G['cache']['plugin']['tshuz_fullwatermark'];
		if(in_array($_G['groupid'],dunserialize($pvars['groups'])) && (!$_G['fid'] || in_array($_G['fid'], unserialize($pvars['forums'])))	){
			$_G['setting']['watermarkstatus'] = '';
		}
		return '';
	}
}

class plugin_tshuz_fullwatermark extends tshuz_fullwatermark{}
class mobileplugin_tshuz_fullwatermark extends tshuz_fullwatermark{}
class plugin_tshuz_fullwatermark_misc extends tshuz_fullwatermark{}
class mobileplugin_tshuz_fullwatermark_misc extends tshuz_fullwatermark{}