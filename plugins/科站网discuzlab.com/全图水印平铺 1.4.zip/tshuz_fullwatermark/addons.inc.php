<?php

/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: addons.inc.php 2020-01-19 06:43:03Z DisM.Taobao.Com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* ������뿪ʼ */

?><script type="text/javascript">location.href="https://dism.taobao.com/?@838.developer";</script>