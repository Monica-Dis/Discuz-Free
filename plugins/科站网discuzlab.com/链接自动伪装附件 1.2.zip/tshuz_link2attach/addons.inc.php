<?php

/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: addons.inc.php 2020-07-15 01:26:56Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* ������뿪ʼ */

?><script type="text/javascript">location.href="https://dism.taobao.com/?@838.developer";</script>