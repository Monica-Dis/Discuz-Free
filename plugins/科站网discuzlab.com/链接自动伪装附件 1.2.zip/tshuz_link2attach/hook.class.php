<?php

/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: hook.class.php 2020-07-15 01:26:35Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('function/core','plugin/tshuz_link2attach');
/* ������뿪ʼ */
class tshuz_link2attach
{
	function discuzcode(){
		global $_G, $hosts;
		$pvars = $_G['cache']['plugin']['tshuz_link2attach'];
		if(!in_array($_G['fid'],unserialize($pvars['forums']))) return '';
		$_G['discuzcodemessage'] = replaceMessage($_G['discuzcodemessage']);
		return '';
	}
}
class plugin_tshuz_link2attach extends tshuz_link2attach {}
class mobileplugin_tshuz_link2attach extends tshuz_link2attach {}