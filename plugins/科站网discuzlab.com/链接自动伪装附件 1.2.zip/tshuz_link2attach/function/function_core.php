<?php

/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: hook.class.php 2020-07-15 01:26:35Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function link2attach($matches)
{
	global $_G, $hosts;
	$url = $matches[2] ? $matches[2] : $matches[3];
	$res = parse_url($url);
	if (!in_array($res['host'], $hosts)) return $matches[0];
	if ($_G['cache']['plugin']['tshuz_link2attach']['price']) { //ת��Ϊ����
		return '[urlattach=' . $url . ',' . $_G['cache']['plugin']['tshuz_link2attach']['desc'] . ',0,' . $_G['cache']['plugin']['tshuz_link2attach']['price'] . ']' . $_G['cache']['plugin']['tshuz_link2attach']['title'] . '[/urlattach]';
	} else {
		return str_replace(array('{url}', '{title}', '{desc}'), array($url, $_G['cache']['plugin']['tshuz_link2attach']['title'], $_G['cache']['plugin']['tshuz_link2attach']['desc']), $_G['cache']['plugin']['tshuz_link2attach']['tpl']);
	}
	return '';
}

function replaceMessage($msg)
{
	global $_G, $hosts;
	$pvars = $_G['cache']['plugin']['tshuz_link2attach'];
	$hosts = array_filter(explode("\n", str_replace("\r", '', $pvars['domains'])));
	return preg_replace_callback('/\[url(=(.*?))?\](.*?)\[\/url\]/', 'link2attach', $msg);
}