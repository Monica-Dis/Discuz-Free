<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: admincp.inc.php 2018-05-10 15:11:16Z Dism_taobao-com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/* 插件代码开始 */
loadcache('plugin');
$getType = $_G['cache']['plugin']['tshuz_tagpro']['type'];
if(!$getType) cpmsg(lang('plugin/tshuz_batchtags','n9TfFt'),'http://dism.taobao.com/?@tshuz_tagpro.plugin','loadingform');

$tables = $set = array();
foreach(C::t('forum_post')->show_table() as $table) {
	list($tempkey, $tablename) = each($table);
	$tableid = gettableid($tablename);
	if(!preg_match('/^\d+$/', $tableid)) {
		continue;
	}
	$tables[$tableid] = $tablename;
}
$forums = unserialize($_G['cache']['plugin']['tshuz_batchtags']['forums']);
if(!$forums || (!$forums[0] && count($forums)==1)) cpmsg(lang('plugin/tshuz_batchtags','B97FiK'),'','error');
if(isset($_GET['submit']) && $_GET['formhash'] == FORMHASH ){
	$page = max(1,$_GET['page']);
	$perpage = $_G['cache']['plugin']['tshuz_batchtags']['perpage'];
	$start = ($page - 1) * $perpage;
	if ($start < 0) $start = 0;

	$tableid = dintval($_GET['tableid']);
	$table = 'forum_post'.($tableid?'_'.$tableid:'');
	$whereTags = !$_GET['type']?" AND tags = ''":'';
	$whereFid = DB::field('fid',$forums);

	$count = DB::result_first("SELECT count(*) FROM %t WHERE first=1 AND %i %i",array($table,$whereFid,$whereTags),'tid');

	$posts = DB::fetch_all("SELECT * FROM %t WHERE first=1 AND %i %i ORDER BY dateline ASC LIMIT %d,%d",array($table,$whereFid,$whereTags,$start,$perpage),'tid');
	include_once libfile('function/core','plugin/tshuz_tagpro');
	include_once libfile('function/discuzcode');
	C::t('common_tagitem')->delete(0,array_keys($posts),'tid');//删除旧数据
	foreach($posts as $tid=>$post){
		/* 获取TAG */
		$text = strip_tags($post['subject']).",".strip_tags(discuzcode($post['message']));
		$text = str_replace(array("\r","\t","\n"," "),'',$text);
		if(strtolower($_G['charset']) != 'utf-8'){
			$text = mb_convert_encoding($text,'utf-8',$_G['charset']);
		}
		switch ($getType) {
			case '3':
				$kws = getByScws($text);
				break;
			case '4':
				$kws = getByPhpanalysis($text);
				break;
			default:
				$kws = getByPullwordGet($text);
				foreach($kws as $k=>$v){
					$kws[$k] = diconv($v,'UTF-8');
				}
				break;
		}
		/* 插入新TAG数据 */
		if(!$kws) continue;
		$kws = daddslashes($kws);
		$tagids = array();
		foreach($kws as $kwd){
			$tagid = C::t('common_tag')->insert($kwd);
			$tagids[$tagid] = $kwd;
			C::t('common_tagitem')->insert(array('tagid'=>$tagid,'itemid'=>$tid,'idtype'=>'tid'));
		}
		/* 更新帖子 */
		$tags = array();
		foreach($tagids as $tagid=>$tag){
			$tags[] = $tagid.','.$tag;
		}
		$posttag = implode("\t",$tags);
		DB::update($table,array('tags'=>$posttag),array('tid'=>$tid));
	}
	$href = 'action=plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod'];
	$need = $count-$start-$perpage;
	if($need>0){
		$page++;
		$href .= '&submit=true&formhash='.FORMHASH.'&page='.$page;
		$href .= '&tableid='.$tableid.'&type='.$_GET['type'];
		cpmsg(lang('plugin/tshuz_batchtags','Lv847e'),$href,'loadingform');
	}else{
		cpmsg(lang('plugin/tshuz_batchtags','Pn77V4'),$href,'succeed');
	}
}else{
	$set[] = array(0,lang('plugin/tshuz_batchtags','G96UTE'));
	foreach($tables as $tableid=>$tablename){
		$set[] = array($tableid,lang('plugin/tshuz_batchtags','IZt17Z').$tableid);
	}
	showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier='.$_GET['identifier'].'&pmod='.$_GET['pmod']);
	showtableheader();
	showsetting(lang('plugin/tshuz_batchtags','pjkjCC'), 'type',0, 'radio',0,0,lang('plugin/tshuz_batchtags','IR3uZc'));
	showsetting(lang('plugin/tshuz_batchtags','ivJK3m'), array('tableid',$set), 0, 'select');
	showsubmit('submit','submit');
	showtablefooter();/*Dism·taobao·com*/
	showformfooter();
}
function gettableid($tablename) {
	$tableid = substr($tablename, strrpos($tablename, '_') + 1);
	return $tableid;
}