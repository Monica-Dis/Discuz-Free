<?php

/**
 *      DisM!应用中心：dism.taobao.com
 *      nayuan_request_logs.
 *      core.func.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-06-06 12:03:49.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function nayuan_get($name, $type = 0, $default = '') {
    $value = $_GET[$name];
    if(!isset($value) || $value === '') return $default;
    if($type === 0) { //数字
        return intval(trim($value));
    } else if($type === 1) { //字符串
        return trim(addslashes($value));
    } else {
        return daddslashes($value);
    }
}

function nayuan_post($name, $type = 0, $default = '') {
    $value = $_POST[$name];
    if(!isset($value) || $value === '') return $default;
    if($type === 0) { //数字
        return intval(trim($value));
    } else if($type === 1) { //字符串
        return trim(addslashes($value));
    } else {
        return daddslashes($value);
    }
}

function nayuan_strreplace($str, $vars) {
    if($vars && is_array($vars)) {
        foreach($vars as $k => $v) {
            $searchs[] = '{'.$k.'}';
            $replaces[] = $v;
        }
    }
    if(is_string($str) && strpos($str, '{_G/') !== false) {
        preg_match_all('/\{_G\/(.+?)\}/', $str, $gvar);
        foreach($gvar[0] as $k => $v) {
            $searchs[] = $v;
            $replaces[] = getglobal($gvar[1][$k]);
        }
    }
    return str_replace($searchs, $replaces, $str);
}

function nayuan_options($name) {
    parse_str(lang($name), $_list);
    return $_list;
}

function nayuan_show_options($value, $select, $exclude = array()) {
    $_options = array();
    parse_str($value, $_list);
    foreach($_list as $_value => $_title) {
        if($exclude && in_array($_value, $exclude)) continue;
        $_options[] = "<option value=\"$_value\" " . ($select === $_value ? "selected=\"selected\"" : "") . ">$_title</option>";
    }
    return implode("", $_options);
}

function nayuan_format_filesize($size, $prec = 3) {
    if($size < 1024) {
        return $size . 'B';
    }
    $size /= 1024;
    if($size < 1024) {
        return round($size, $prec) . 'K';
    }
    $size /= 1024;
    if($size < 1024) {
        return round($size, $prec) . 'M';
    }
    $size /= 1024;
    return round($size, $prec) . 'G';
}
//From: Dism_taobao-com
?>