<?php

/**
 *      DisM!应用中心：dism.taobao.com
 *      nayuan_request_logs.
 *      table_nayuan_requestlogs.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-06-06 12:03:49.
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_nayuan_requestlogs extends discuz_table {

    public function __construct() {
        $this->_table = 'nayuan_request_logs';
        $this->_pk    = 'id';
        parent::__construct();
    }

    public function delete_by_time($time) {
        DB::query("DELETE FROM %t WHERE `time` < %d", array($this -> _table, $time));
    }

    public function delete_by_id($ids) {
        DB::query("DELETE FROM %t WHERE `id` in (%n)", array($this -> _table, $ids));
    }

    public function fetch_list($action, $username, $ip, $target, $page = 1, $pagesize = 15, $orderby) {
        $wherestr = $params = array();
        $wherestr[] = 'a.uid = b.uid';
        $params[] = $this -> _table;
        $params[] = 'common_member';

        if($username) {
            $wherestr[]= 'b.`username` = %s';
            $params[] = $username;
        }
        if($ip) {
            $wherestr[]= 'a.`clientip` = %s';
            $params[] = $ip;
        }
        if($action){
            if(is_array($action)) {
                $wherestr[]= 'a.`action` in (%n)';
                $params[] = $action;
            }else{
                $wherestr[]= 'a.`action` = %s';
                $params[] = $action;
            }
        }
        if($target) {
            $wherestr[]= 'a.`target` = %d';
            $params[] = $target;
        }
        if($wherestr) {
            $wherestr = ' WHERE ' . implode(' AND ', $wherestr);
        }

        $_result = array();
        $_total = DB::result_first("SELECT count(*) FROM %t a, %t b $wherestr", $params);
        if(!$_total) {
            $_result['total'] = 0;
            $_result['list'] = array();
        }else{
            $_list = DB::fetch_all("SELECT a.`id`,a.`action`,a.`uid`,b.username,a.`clientip`,a.`clientport`,a.`request_url`,a.`http_user_agent`, a.`mobile`,a.`time`,a.`target` FROM %t a, %t b $wherestr ORDER BY $orderby" . DB::limit(($page-1) * $pagesize, $pagesize), $params);
            $_result['total'] = $_total;
            $_result['list'] = $_list;
        }
        return $_result;
    }

    public function fetch_list_for_export($action, $username, $ip, $target, $page = 1, $pagesize = 10000) {
        $wherestr = $params = array();
        $wherestr[] = 'a.uid = b.uid';
        $params[] = $this -> _table;
        $params[] = 'common_member';

        if($username) {
            $wherestr[]= 'b.`username` = %s';
            $params[] = $username;
        }
        if($ip) {
            $wherestr[]= 'a.`clientip` = %s';
            $params[] = $ip;
        }
        if($action){
            if(is_array($action)) {
                $wherestr[]= 'a.`action` in (%n)';
                $params[] = $action;
            }else{
                $wherestr[]= 'a.`action` = %s';
                $params[] = $action;
            }
        }
        if($target) {
            $wherestr[]= 'a.`target` = %d';
            $params[] = $target;
        }
        if($wherestr) {
            $wherestr = ' WHERE ' . implode(' AND ', $wherestr);
        }

        return DB::fetch_all("SELECT a.`action`,a.`uid`,b.username,a.`clientip`,a.`clientport`,a.`request_url`,a.`http_user_agent`, a.`mobile`,a.`time`,a.`target` FROM %t a, %t b $wherestr" . DB::limit(($page-1) * $pagesize, $pagesize), $params);
    }

    public function fetch_post_subject($tids) {
        return DB::fetch_all("SELECT `tid`, `subject` FROM %t WHERE `tid` in (%n)", array('forum_thread', $tids));
    }

}
//From: Dism_taobao-com
?>