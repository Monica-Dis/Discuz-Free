<?php

/**
 *      DisM!应用中心：dism.taobao.com
 *      nayuan_request_logs.
 *      service.inc.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-06-06 12:03:49.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

showtableheader(lang('plugin/nayuan_request_logs', 'service_title'));
showtablerow('', array(),
    array(
        lang('plugin/nayuan_request_logs', 'service_help_doc'),
        '<a href="'.lang('plugin/nayuan_request_logs', 'service_help_doc_url').'" target="_blank">'.lang('plugin/nayuan_request_logs', 'service_help_doc_url').'</a>'
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_request_logs', 'service_qq'),
        '<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=276440802&site=qq&menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=2:276440802:51" alt="'.lang('plugin/nayuan_request_logs', 'service_qq_tips').'" title="'.lang('plugin/nayuan_request_logs', 'service_qq_tips').'"/></a>'
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_request_logs', 'service_email'), 'nayuan@vip.qq.com',
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_request_logs', 'service_site'), '<a href="https://www.dplugin.com" target="_blank">https://www.dplugin.com</a>',
    )
);
showtablerow('', array(),
    array(
        lang('plugin/nayuan_request_logs', 'service_addon'), '<a href="https://dism.taobao.com/?@12008.developer" target="_blank">https://dism.taobao.com/?@12008.developer</a>',
    )
);
showtablefooter();/*Dism·taobao·com*/


?>