<?php

/**
 *      DisM!应用中心：dism.taobao.com
 *      nayuan_request_logs.
 *      register.inc.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-06-06 12:03:49.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require DISCUZ_ROOT . 'source/plugin/nayuan_request_logs/source/function/core.func.php';

$adminurl = 'plugins&operation=config&do=' .$do . '&pmod=register';

//// 搜索
$q_page = nayuan_get('page', 0, 1);
$q_page = $q_page < 1 ? 1 : $q_page;
$q_pagesize = nayuan_get('pagesize', 0, 20);
$q_orderby = nayuan_get('orderby', 0, 1);
$q_username = nayuan_get('q_username', 1, '');
$q_ip = nayuan_get('q_ip', 1, '');

parse_str(lang('plugin/nayuan_request_logs', 'client_options'), $_client_options);

$export = nayuan_get('export');
if(submitcheck('deletesubmit')) {
    $_ids = nayuan_get('delete', 3);
    if($_ids) {
        C::t('#nayuan_request_logs#nayuan_requestlogs') -> delete_by_id($_ids);
    }
    cpmsg('nayuan_request_logs:delete_success', 'action=' . $adminurl, 'succeed');
} else if($export) {
    define('FOOTERDISABLED',1);
    @set_time_limit(0);
    ob_end_clean();

    $filename = 'register-logs-' . time().'.csv';
    header('Content-Encoding: none');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename='.$filename);
    header('Pragma: no-cache');
    header('Expires: 0');

    ob_start();

    $titles = array(
        'UID',
        lang('plugin/nayuan_request_logs', 'list_header_user'),
        lang('plugin/nayuan_request_logs', 'list_header_register_time'),
        lang('plugin/nayuan_request_logs', 'list_header_register_ip'),
        lang('plugin/nayuan_request_logs', 'list_header_register_port'),
        lang('plugin/nayuan_request_logs', 'list_header_ipaddress'),
        lang('plugin/nayuan_request_logs', 'list_header_client')
    );
    if($_G['charset'] != 'gbk') {
        echo diconv(implode(',', $titles) . "\n", $_G['charset'], 'GBK');
    }else{
        echo implode(',', $titles) . "\n";
    }

    require_once libfile('function/misc');
    $q_page = 1;
    while(($list = C::t('#nayuan_request_logs#nayuan_requestlogs') -> fetch_list_for_export('register_user', $q_username, $q_ip, 0, $q_page))) {
        $pagedata = '';
        foreach ($list as $_item) {
            $pagedata .= $_item['uid'] . ',[' . $_item['username'] . '],' . dgmdate($_item['time'], 'Y-m-d H:m:s') . ',' . $_item['clientip'] . ',' . $_item['clientport'] . ',' . convertip($_item['clientip']) . ',' . $_client_options[$_item['mobile']] . "\n";
        }
        if($_G['charset'] != 'gbk') {
            echo diconv($pagedata, $_G['charset'], 'GBK');
        }else{
            echo $pagedata;
        }
        ob_flush();
        flush();
        $q_page++;
    }
    exit();
}else{
    showtips(lang('plugin/nayuan_request_logs', 'register_tips'));
    showformheader("$adminurl", '', 'search_form');
    echo '<input type="hidden" name="page" id="page" value="1">';
    echo <<<SCRIPT
<script type="text/javascript">
    function nayuan_next_page(page) {
        $("page").value=page;
        $("search_form").submit();
    }
</script>
SCRIPT;
    showtableheader('search');
    $_orderby = array();
    $_orderby[] = '<option value="1" '.($q_orderby == 1 ? 'selected="selected"' : '').'>'.lang('plugin/nayuan_request_logs', 'search_order_register_desc').'</option>';
    $_orderby[] = '<option value="2" '.($q_orderby == 2 ? 'selected="selected"' : '').'>'.lang('plugin/nayuan_request_logs', 'search_order_register_asc').'</option>';
    $_pagesizeoptions = array();
    $_pagesizeoptions[] = '<option value="20" '.($q_pagesize == 20 ? 'selected="selected"' : '').'>'.lang('plugin/nayuan_request_logs', 'search_pagesize', array('num' => 20)).'</option>';
    $_pagesizeoptions[] = '<option value="50" '.($q_pagesize == 50 ? 'selected="selected"' : '').'>'.lang('plugin/nayuan_request_logs', 'search_pagesize', array('num' => 50)).'</option>';
    $_pagesizeoptions[] = '<option value="100" '.($q_pagesize == 100 ? 'selected="selected"' : '').'>'.lang('plugin/nayuan_request_logs', 'search_pagesize', array('num' => 100)).'</option>';
    $_pagesizeoptions[] = '<option value="500" '.($q_pagesize == 500 ? 'selected="selected"' : '').'>'.lang('plugin/nayuan_request_logs', 'search_pagesize', array('num' => 500)).'</option>';
    showtablerow('', array(
        'width="40"', 'width="150"','width="40"', 'width="200"','width="50"', 'width="70"','width="70"', ''),
        array(
            lang('plugin/nayuan_request_logs', 'search_user'), '<input type="text" class="txt" name="q_username" value="'.$q_username.'" />',
            lang('plugin/nayuan_request_logs', 'search_register_ip'), '<input type="text" class="txt" name="q_ip" style="width: 180px;" value="'.$q_ip.'" />',
            lang('plugin/nayuan_request_logs', 'search_order'), '<select name="orderby">'.implode('', $_orderby).'</select>',
            '<select name="pagesize">'.implode('', $_pagesizeoptions).'</select>',
            "<input class=\"btn\" type=\"submit\" id=\"searchformsubmit\" name=\"searchformsubmit\" value=\"$lang[search]\" />",
        )
    );
    showtablefooter();/*Dism·taobao·com*/
    showformfooter();/*Dism_taobao_com*/

    if($q_orderby == 2) {
        $q_orderby = 'a.`time`';
    }else{
        $q_orderby = 'a.`time` desc';
    }

    $_result = C::t('#nayuan_request_logs#nayuan_requestlogs') -> fetch_list('register_user', $q_username, $q_ip, 0, $q_page, $q_pagesize, $q_orderby);
    $_title = lang('plugin/nayuan_request_logs', 'list_title').'&nbsp;('.$_result['total'].')&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.ADMINSCRIPT . '?action=' .$adminurl.'&export=1">'.lang('plugin/nayuan_request_logs', 'search_export').'</a>';
    showformheader("$adminurl", '', 'delete_form');
    showtableheader($_title);
    showsubtitle(array(
        '',
        lang('plugin/nayuan_request_logs', 'list_header_user'),
        lang('plugin/nayuan_request_logs', 'list_header_register_time'),
        lang('plugin/nayuan_request_logs', 'list_header_register_ip'),
        lang('plugin/nayuan_request_logs', 'list_header_register_port'),
        lang('plugin/nayuan_request_logs', 'list_header_ipaddress'),
        lang('plugin/nayuan_request_logs', 'list_header_client')
    ), 'header', array(
        'class="td25"',
        'class="td23 center"',
        'class="center" style="width: 150px"',
        'class="td25" style="text-align:right"',
        'class="td25" style="text-align:left"',
        '',
        'class="td25 center"'
    ));

    if($_result['total']) {
        require_once libfile('function/misc');
        foreach ($_result['list'] as $_item) {
            showtablerow(
                '',
                array(
                    'class="td25"',
                    'class="td23 center"',
                    'class="center" style="width: 150px"',
                    'class="td23" style="text-align:right"',
                    'class="td23" style="text-align:left"',
                    '',
                    'class="td25 center"'
                ),
                array(
                    '<input type="checkbox" class="checkbox" name="delete[]" value="'.$_item['id'].'" />',
                    "<a href=\"$_G[siteurl]home.php?mod=space&uid=$_item[uid]&do=profile\" target=\"_blank\">$_item[username]</a>",
                    dgmdate($_item['time'], 'Y-m-d H:m:s'),
                    $_item['clientip'],
                    $_item['clientport'],
                    convertip($_item['clientip']),
                    $_client_options[$_item['mobile']]
                )
            );
        }
        $v_page_html = multi($_result['total'], $q_pagesize, $q_page, 'nayuan_next_page({page})', 0, $q_pagesize, false, false, ';');
        showsubmit('deletesubmit', 'del', 'select_all', '', $v_page_html);
    }else{
        showtablerow('', array('colspan="15"'), array(lang('plugin/nayuan_request_logs', 'not_data')));
    }

    showtablefooter();/*Dism·taobao·com*/
    showformfooter();/*Dism_taobao_com*/
}
//From: Dism_taobao-com
?>