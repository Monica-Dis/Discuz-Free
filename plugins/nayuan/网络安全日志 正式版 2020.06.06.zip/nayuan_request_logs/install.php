<?php

/**
 *      DisM!应用中心：dism.taobao.com
 *      nayuan_request_logs.
 *      install.php.
 *      最新插件：http://t.cn/Aiux1Jx1
 *      Time 2020-06-06 12:03:48.
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


$sql = <<<EOF

    CREATE TABLE IF NOT EXISTS `pre_nayuan_request_logs` (
        `id`                    char(32) NOT NULL,
        `action`                varchar(30) NOT NULL,
        `sid`                   char(12),
        `clientip`              varchar(15),
        `clientport`            mediumint(5),
        `uid`                   bigint(20) NOT NULL,
        `mobile`                tinyint(1),
        `request_method`        varchar(10),
        `request_url`           text,
        `http_referer`          varchar(255),
        `http_user_agent`       text,
        `http_x_forwarded_for`  varchar(15),
        `target`                bigint(20),
        `data`                  varchar(255),
        `time`                  int(10) NOT NULL,
        PRIMARY KEY  (`id`),
        INDEX `idx_uid`(`uid`),
        INDEX `idx_action`(`action`),
        INDEX `idx_ip`(`clientip`),
        INDEX `idx_target`(`target`),
        INDEX `idx_time`(`time`)
    ) ENGINE=MyISAM;

EOF;

runquery($sql);

$wechat = DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
if(file_exists($wechat)) {
    require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
    WeChatHook::updateAPIHook(array(
        array('login_variables' => array(
            'plugin' => 'nayuan_request_logs',
            'include' => 'requestlogs.class.php',
            'class' => 'mobileapiplugin_nayuan_request_logs_member',
            'method' => 'login_variables',
        )),
        array('register_variables' => array(
            'plugin' => 'nayuan_request_logs',
            'include' => 'requestlogs.class.php',
            'class' => 'mobileapiplugin_nayuan_request_logs_member',
            'method' => 'register_variables',
        )),
        array('newthread_variables' => array(
            'plugin' => 'nayuan_request_logs',
            'include' => 'requestlogs.class.php',
            'class' => 'mobileapiplugin_nayuan_request_logs_member',
            'method' => 'newthread_variables',
        )),
        array('sendreply_variables' => array(
            'plugin' => 'nayuan_request_logs',
            'include' => 'requestlogs.class.php',
            'class' => 'mobileapiplugin_nayuan_request_logs_member',
            'method' => 'sendreply_variables',
        ))
    ));
}

$finish = true;

?>