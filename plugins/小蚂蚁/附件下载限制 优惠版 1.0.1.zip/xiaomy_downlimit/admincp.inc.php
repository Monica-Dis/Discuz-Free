<?php
if (! defined ( 'IN_DISCUZ' ) || ! defined ( 'IN_ADMINCP' )) {
	exit ( 'Access Denied' );
}


if (submitcheck ( "forumset" )) {
	if (is_array ( $_GET ['delete'] )) {
		C::t ( '#xiaomy_downlimit#xiaomy_downlimit' )->delete ( $_GET ['delete'] );
	}
	cpmsg (lang('plugin/xiaomy_downlimit', 'common_01'), 'admin.php?frames=yes&action=plugins&operation=config&identifier=xiaomy_downlimit&pmod=admincp', 'succeed' );
}

showformheader ( "plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp" );
showtableheader ( lang('plugin/xiaomy_downlimit', 'common_06') );
showsubtitle ( array (
    lang('plugin/xiaomy_downlimit', 'common_02'),
    lang('plugin/xiaomy_downlimit', 'common_03'),
    lang('plugin/xiaomy_downlimit', 'common_04'),
    lang('plugin/xiaomy_downlimit', 'common_05'),
) );

$ppp = 30;
$tmpurl = 'admin.php?action=plugins&operation=config&identifier=xiaomy_downlimit&pmod=admincp';
$page = max ( 1, intval ( $_GET ['page'] ) );
$startlimit = ($page - 1) * $ppp;
 $allcount = C::t('#xiaomy_downlimit#xiaomy_downlimit')->count_all($wheres);
if ($allcount) {
	$query = C::t ( '#xiaomy_downlimit#xiaomy_downlimit' )->fetch_all_by_limit ( $startlimit, $ppp, $wheres );
	foreach ( $query as $val ) {
		$table = array ();
		$table [0] = '<input type="checkbox" class="checkbox" name="delete[]" value="' . $val ['id'] . '" />';
		$table [1] = $val ['useusername'];
		$table [2] = "<a target='_blank' href='forum.php?mod=viewthread&tid=".$val['tid']."&extra=&page=1'>".$val['attname']."</a>";
		$table [5] = $val ['dateline'] ? dgmdate ( $val ['dateline'], 'Y/m/d H:i' ) : '-';
		showtablerow ( '', array (
				'' 
		), $table );
	}
}
$multipage = '';
$multipage = multi ( $allcount, $ppp, $page, $_G ['siteurl'] . $tmpurl );
if ($multipage)
	echo '<tr class="hover"><td colspan="9">' . $multipage . '</td></tr>';
showsubmit ( 'forumset', 'submit', 'del' );
showtablefooter ();
showformfooter ();