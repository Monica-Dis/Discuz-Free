<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (! defined ( 'IN_DISCUZ' )) {
	exit ( 'Access Denied' );
}


class plugin_xiaomy_downlimit{
    
    public $downloadnum,$isopen,$forums,$tips,$vipurl,$counttips;
    
    function __construct(){
        
        global $_G;
        loadcache('plugin');
        $configarr = $_G['cache']['plugin']['xiaomy_downlimit'];
        $downloadtmp = explode("\r\n", $configarr['downloadnum']);
        foreach ($downloadtmp as $cv){
            $tmpcv = explode("=",$cv);
            $downloadnumarrs[$tmpcv[0]] = $tmpcv[1];
        }
        $this->downloadnum = $downloadnumarrs;
        $this->forums =  (array)dunserialize($configarr['forums']);
        $this->isopen =$configarr['isopen'];
        $this->tips = $configarr['tips'];
        $this->vipurl = $configarr['vipurl'];
        $this->counttips = $configarr['counttips'];
        
       
    }
    
    function global_usernav_extra3(){
        
        global $_G;
        $uid =  intval($_G['uid']);
        $groupid = intval($_G['groupid']);
        
        $return = "";
      
        if(!$uid || !$this->isopen || !$this->downloadnum[$groupid]){
            return $return;
        }
        $curcountl = getcookie('curcountl');
        $day = date('Y-m-d',$_G['timestamp']);
        if($curcountl){
            $countl = $curcountl;
        }else{
       
            $countl = C::t('#xiaomy_downlimit#xiaomy_downlimit')-> fetch_by_uid($uid,$day);
            $countl = $countl['datecount'];
            dsetcookie('curcountl',$countl); 
        }
        
        $showtips = str_replace(array('{s}','{z}'),array($countl,$this->downloadnum[$groupid]),$this->counttips);
        return $showtips;
        
    }
}
		
class plugin_xiaomy_downlimit_forum extends plugin_xiaomy_downlimit {
    
    
    
    function attachment_down(){
		        global $_G;
		        
		        $return = "";
		        
		        $attachment = explode('|', base64_decode($_GET['aid']));
		        $tid = intval($attachment[4]);
		        $aid = intval($attachment[0]);
		        $groupid = intval($_G['groupid']);
		        $uid =  intval($_G['uid']);
		        
		        $thread = C::t('#xiaomy_downlimit#xiaomy_downlimit_thread')->fetch_by_tid($tid);
		        $fid = $thread['fid'];
		        
		        $attinfo = DB::fetch_first("select tableid from ".DB::table("forum_attachment ")." where aid=".$aid);
		        $attach = C::t('forum_attachment_n')->fetch($attinfo['tableid'],$aid);
		        
		      
		        //�����Լ��ĸ�����ͼƬ����
		        if(!$uid || !$this->isopen || !in_array($fid,$this->forums) || !$this->downloadnum[$groupid] || ($attach['isimage']==1)){
		            return $return;
		        }
		        
		        $day = date('Y-m-d',$_G['timestamp']);
		        
		        $countl = C::t('#xiaomy_downlimit#xiaomy_downlimit')-> fetch_by_uid($uid,$day);
		        $countl = $countl['datecount'];
		        
		        if($countl>=$this->downloadnum[$groupid]){
		            
		            showmessage($this->tips,NULL, array('vipurl' =>$this->vipurl));
		            
		        }else{
		            $download  = array(
		                'uid'=>$uid,
		                'datestr'=>$day,
		                'useusername'=>$_G['username'],
		                'tid'=>$tid,
		                'aid'=>$aid,
		                'pid'=>$attach['pid'],
		                'attname'=>$attach['filename'],
		                'dateline'=>$_G['timestamp'],
		            );
		           
		            DB::insert('xiaomy_downlimit', $download);
		            dsetcookie('curcountl',$countl+1); 
		        }
		    }
		}
		
		
		class mobileplugin_xiaomy_downlimit_forum extends plugin_xiaomy_downlimit {
		    
		    function attachment_down(){
		        global $_G;
		        
		        $return = "";
		        
		        $attachment = explode('|', base64_decode($_GET['aid']));
		        $tid = intval($attachment[4]);
		        $aid = intval($attachment[0]);
		        $groupid = intval($_G['groupid']);
		        $uid =  intval($_G['uid']);
		        
		        $thread = C::t('#xiaomy_downlimit#xiaomy_downlimit_thread')->fetch_by_tid($tid);
		        $fid = $thread['fid'];
		        
		        $attinfo = DB::fetch_first("select tableid from ".DB::table("forum_attachment ")." where aid=".$aid);
		        $attach = C::t('forum_attachment_n')->fetch($attinfo['tableid'],$aid);
		        
		        
		        //�����Լ��ĸ�����ͼƬ����
		        if(!$uid || !$this->isopen || !in_array($fid,$this->forums) || !$this->downloadnum[$groupid] || ($attach['isimage']==1)){
		            return $return;
		        }
		        
		        $day = date('Y-m-d',$_G['timestamp']);
		        
		        $countl = C::t('#xiaomy_downlimit#xiaomy_downlimit')-> fetch_by_uid($uid,$day);
		        $countl = $countl['datecount'];
		       
		        if($countl>=$this->downloadnum[$groupid]){
		            
		            showmessage($this->tips,NULL, array('vipurl' =>$this->vipurl));
		            
		        }else{
		            
		            $download  = array(
		                'uid'=>$uid,
		                'datestr'=>$day,
		                'useusername'=>$_G['username'],
		                'tid'=>$tid,
		                'aid'=>$aid,
		                'pid'=>$attach['pid'],
		                'attname'=>$attach['filename'],
		                'dateline'=>$_G['timestamp'],
		            );
		            DB::insert('xiaomy_downlimit', $download);
		            dsetcookie('curcountl',$countl+1); 
		        }
		    }
		}


?>