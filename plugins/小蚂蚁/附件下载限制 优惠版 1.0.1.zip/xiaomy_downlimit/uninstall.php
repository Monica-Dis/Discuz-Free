<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$uninstallsql = <<<EOF
DROP TABLE IF EXISTS cdb_xiaomy_downlimit;
EOF;
runquery($uninstallsql);
$finish = TRUE;