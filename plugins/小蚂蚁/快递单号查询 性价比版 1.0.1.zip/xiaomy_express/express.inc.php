<?php

/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$ac  = daddslashes($_GET['ac']);
$xmlcfg = $_G['cache']['plugin']['xiaomy_express'];
   
$appkey = $xmlcfg['apikey'];


require_once libfile('function/cache');

if($ac == "submit"){
    
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        showmessage('error');
    }
    
    if(!$_G['uid']) {
        showmessage('not_loggedin', NULL, array(), array('login' => 1));
    }
    
	$myinte = getuserprofile('extcredits'.$xmlcfg['intetype']);
	
	if($xmlcfg['intecount'] > $myinte){
	    showmessage(lang('plugin/xiaomy_express', 'express1'));
	}
	$expressno = daddslashes($_GET['expressno']);
	
	if(!$expressno){
	    showmessage(lang('plugin/xiaomy_express', 'express2'));
	}
	//���appkey
	$url = "http://api.jisuapi.com/express/query?appkey=$appkey";
	$post = array(
	        'type'=>"auto",
	        'number'=>trim($expressno),
	  );
	
	$result = dfsockopen($url,0,$post);
	$jsonarr = json_decode($result, true);
	
	if($jsonarr['status'] != 0 ){
	    $str = $jsonarr['msg'];
	    if(CHARSET == 'gbk' || CHARSET == 'GBK'){
	        $str = diconv($str,"UTF-8", "GBK");
	    }
	    showmessage($str);
	}else{
	    $expresscontext = $jsonarr['result']['list'];
	    
	    if(CHARSET == 'gbk' || CHARSET == 'GBK'){
	        for($i=0;$i<count($expresscontext);$i++){
	            $expresscontext[$i]['status'] = diconv($expresscontext[$i]['status'],"UTF-8", "GBK");
	        }
	    }
	    $expresscontext =  serialize($expresscontext);
	    $cxrecode = array(
	        'uid'=>$_G['uid'],
	        'username'=>$_G['username'],
	        'expressno'=>$expressno,
	        'expresscontext'=>$expresscontext,
	        'intetype'=>$xmlcfg['intetype'],
	        'intecount'=>$xmlcfg['intecount'],
	        'dateline'=>$_G['timestamp']
	    );
	    $expressid = DB::insert('xiaomy_express', $cxrecode,true);
	    updatemembercount($_G['uid'], array("extcredits".$xmlcfg['intetype']=>-$xmlcfg['intecount']),true,'',0,'',lang('plugin/xiaomy_express', 'express5'),lang('plugin/xiaomy_express', 'express6'));
	    dheader('Location:plugin.php?id=xiaomy_express:expressorder&xac=detail&expressid='.$expressid);
		exit;
	}
}else{
    
    //��ȡ���ð����������
    $tgforum = $xmlcfg['tgforum'];
    $tgforum = explode("||", $tgforum);
    $threaddata = DB::fetch_all("select author,authorid,tid,subject,dateline from  ".DB::table("forum_thread") ." where fid=".$tgforum[0]." and displayorder>=0 order by  dateline desc limit ".$tgforum[1]);
	include template('xiaomy_express:express');
}
	
?>