<?php
/**
 * 
 * author:xiaomy
 * QQ:3396710833
 * 
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$installsql = <<<EOF
DROP TABLE IF EXISTS cdb_xiaomy_express;
CREATE TABLE IF NOT EXISTS `cdb_xiaomy_express` (
 	`id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`uid` MEDIUMINT(8) UNSIGNED NOT NULL,
	`username` VARCHAR(30) NOT NULL DEFAULT '',
    `intetype` INT(10) NULL DEFAULT NULL,
	`intecount` INT(10) NULL DEFAULT NULL,
	`expressno` VARCHAR(130) NOT NULL DEFAULT '',
	`expresscontext` text DEFAULT NULL,
	`dateline` INT(10) NULL DEFAULT NULL,
	PRIMARY KEY (`id`),
    KEY `express_uid` (`uid`)
) ENGINE=MyISAM;
EOF;
runquery($installsql);
$finish = TRUE; /*dism��taobao��com*/

@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_carrule/discuz_plugin_xiaomy_carrule.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_carrule/discuz_plugin_xiaomy_carrule_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_carrule/discuz_plugin_xiaomy_carrule_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_carrule/discuz_plugin_xiaomy_carrule_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_carrule/discuz_plugin_xiaomy_carrule_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_carrule/install.php'); 

?>