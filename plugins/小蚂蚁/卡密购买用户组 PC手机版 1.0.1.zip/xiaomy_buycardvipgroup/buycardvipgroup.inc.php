<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit ('Access Denied');
}

if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}

$step = dhtmlspecialchars($_GET['step']);
$xmlcfg = $_G['cache']['plugin']['xiaomy_buycardvipgroup'];
loadcache("usergroups");
$groupconfigs = explode("\r\n",$xmlcfg['groupconfigs']);
$groupinfo = array();
foreach($groupconfigs as $gbv){
	$akey = explode("=",$gbv);
	$avalue = explode("||",$akey[1]);
	$groupinfo += array($akey[0]=>$avalue);
}
if($step =="submityes"){
	
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
			showmessage('error');
	}
	
	if($_G['uid'] == 1){
		showmessage(lang('plugin/xiaomy_buycardvipgroup', 'bvip01'));
	}
	
	$groupskey = intval($_GET['groupskey']);
	
	if(!$groupinfo[$groupskey]){
		showmessage('invalid data');
	}
	
	$cardno = trim(dhtmlspecialchars($_GET['cardno']));

	if(!$cardno){
		showmessage('invalid data');
	}
	//�鿴�����Ƿ���Ч
	$cardcode = C::t('#xiaomy_buycardvipgroup#xiaomy_buycardvipgroup')->fetch_by_cardno($cardno);
	if(!$cardcode){
		showmessage(lang('plugin/xiaomy_buycardvipgroup', 'xiaomycarderror01'));
	}else if($cardcode['kmtype'] != $groupskey){
		showmessage(lang('plugin/xiaomy_buycardvipgroup', 'xiaomycarderror02'));
	}else if($_G['timestamp']>$cardcode['endtime']){
		showmessage(lang('plugin/xiaomy_buycardvipgroup', 'xiaomycarderror03'));
	}
	//�����û���
	$member=C::t('common_member')->fetch($_G['uid'], false, 1);
	if(count($member)==0){
		$isinarchive = '_inarchive';
	}else{
		$isinarchive = '';
	}
	
	if($groupinfo[$groupskey][3] == 0){
		C::t('common_member'.$isinarchive)->update($_G['uid'], array('groupid'=>$groupinfo[$groupskey][0]));
	}elseif (is_numeric($groupinfo[$groupskey][3]) && $groupinfo[$groupskey][3]>0) {
		//$validity = $groupinfo[$groupskey][3]*30;
	    $validity = $groupinfo[$groupskey][3];
		$groupexpiryTime = TIMESTAMP +	$validity*86400;
		if($groupinfo[$groupskey][0] == $member['groupid']){
			$groupexpiryTime = $member['groupexpiry'] + $validity*86400;
		}
		C::t('common_member'.$isinarchive)->update($_G['uid'], array('groupid'=>$groupinfo[$groupskey][0] ,'groupexpiry'=>$groupexpiryTime));
		$groupterms['main'] = array('time' => $groupexpiryTime,'groupid' => $xmlcfg['expiredgroup']);
		$groupterms['ext'][$groupinfo[$groupskey][0] ] = $groupexpiryTime;
		C::t('common_member_field_forum'.$isinarchive)->update($_G['uid'],array('groupterms' => serialize($groupterms)));
	}
	$cardarray = array(
		'useuid'=>$_G['uid'],
		'useusername' =>$_G['username'],
		'usedateline'=>$_G['timestamp'],
		'useip'=>$_G['clientip'],
	);
	C::t('#xiaomy_buycardvipgroup#xiaomy_buycardvipgroup')->update(array('id'=>$cardcode['id']),$cardarray);
	
	showmessage(lang('plugin/xiaomy_buycardvipgroup', 'postrtc04'),"plugin.php?id=xiaomy_buycardvipgroup:buycardvipgroup",array(),array('alert'=>'right'));
}elseif($step =="ljbuy"){
	$buyid = intval($_GET['buyid']);
	include template('xiaomy_buycardvipgroup:cdkeygroupbuypage');
}
$record = C::t('#xiaomy_buycardvipgroup#xiaomy_buycardvipgroup')->fetch_pay_record(7);
include template('xiaomy_buycardvipgroup:buycardvipgroup');
?>