<?php

/**
 * 
 * author:xiaomy
 * QQ:3396710833
 * 
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$installsql = <<<EOF
DROP TABLE IF EXISTS cdb_xiaomy_buycardvipgroup;
CREATE TABLE IF NOT EXISTS `cdb_xiaomy_buycardvipgroup` (
  `id`    int(11) unsigned NOT NULL auto_increment,
  `useuid`     mediumint(8) unsigned  NOT NULL,
  `useusername` VARCHAR(30) NOT NULL DEFAULT '',
  `cardcode` VARCHAR(35) NOT NULL DEFAULT '',
  `kmtype` int(10) NOT NULL,
  `endtime` int(10) DEFAULT NULL,
  `dateline` int(10) DEFAULT NULL,
  `usedateline` int(10) DEFAULT NULL,
  `useip` char(15) NOT NULL,
  PRIMARY KEY  (`id`),
  index in_uid(`cardcode`)
) ENGINE=MyISAM;
EOF;
runquery($installsql);
$finish = TRUE;



 @unlink(DISCUZ_ROOT . './source/plugin/xiaomy_buycardvipgroup/discuz_plugin_xiaomy_buycardvipgroup.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_buycardvipgroup/discuz_plugin_xiaomy_buycardvipgroup_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_buycardvipgroup/discuz_plugin_xiaomy_buycardvipgroup_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_buycardvipgroup/discuz_plugin_xiaomy_buycardvipgroup_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_buycardvipgroup/discuz_plugin_xiaomy_buycardvipgroup_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_buycardvipgroup/install.php'); 


?>