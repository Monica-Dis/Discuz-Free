<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_xiaomy_buycardvipgroup extends discuz_table
{
	public function __construct() {

		$this->_table = 'xiaomy_buycardvipgroup';
		$this->_pk    = 'id';
		parent::__construct(); /*dism �� taoabo �� com*/
	}
	public function fetch_bysearch($kmtype=0,$useusername=''){
		if($kmtype && !$useusername){
			return DB::fetch_all('SELECT * FROM  %t  where kmtype=%d order by useusername desc', array($this->_table,$kmtype));
		}else if(!$kmtype && $useusername){
			return DB::fetch_all('SELECT * FROM  %t  where useusername=%s order by useusername desc', array($this->_table,$useusername));
		}else if($kmtype && $useusername){
			return DB::fetch_all('SELECT * FROM  %t  where kmtype=%d and useusername=%s order by useusername desc', array($this->_table,$kmtype,$useusername));
		}else{
			return DB::fetch_all('SELECT * FROM  %t  order by useusername desc', array($this->_table));
		}
	}
	
	public function fetch_by_cardno($cardcode){
		return DB::fetch_first('SELECT * FROM  %t  where cardcode=%s and useuid =0 ', array($this->_table,$cardcode));
	}
	
	
	public function fetch_by_uid($uid,$b,$e){
		return DB::fetch_all('SELECT * FROM  %t  where uid=%d order by dateline desc limit %d,%d', array($this->_table,$uid,$b,$e));
	}
	
	public function fetch_by_uidrcount($uid){
		return DB::fetch_first('SELECT count(*) as rcount FROM  %t  where uid=%d', array($this->_table,$uid));
	}
	
	
	public function fetch_page_data($start=0,$limit=10)
	{
		return DB::fetch_all('SELECT * FROM  %t  ORDER BY usedateline desc limit %d,%d', array($this->_table,$start,$limit));
	}
	
	
	public function fetch_by_id($did){
			return DB::fetch_first('SELECT * FROM  %t  where id=%d', array($this->_table,$did));
	}
	
	public function delete_by_id($did){
		
		return DB::query('delete  FROM  %t  where id=%s', array($this->_table,$did));
	}
	
	
		public function fetch_pay_record($limit)
	{
		return DB::fetch_all('SELECT * FROM  %t   where useuid>0 ORDER BY usedateline desc limit 0,%d', array($this->_table,$limit));
	}
}
//From: Dism��taobao��com
?>