<?php
/**
 * 
 * author:xiaomy
 * QQ:3396710833
 * 
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$uninstallsql = <<<EOF
DROP TABLE IF EXISTS cdb_xiaomy_buycardvipgroup;
EOF;
runquery($uninstallsql);
$finish = TRUE;