<?php

if (!defined('IN_DISCUZ')) {
	exit ('Access Denied');
}

dheader("Location: http://dism.taobao.com/?@72247.developer");

?>