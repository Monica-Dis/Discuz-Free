<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo '<script type="text/javascript">
		function exportcsv(kmtype,useusername,formhash){
			 window.location.href= "plugin.php?id=xiaomy_buycardvipgroup:export&kmtype="+kmtype+"&useusername="+useusername;
		}
</script>';

loadcache("usergroups");

loadcache("plugin");


$xmlcfg = $_G['cache']['plugin']['xiaomy_buycardvipgroup'];

$cp= dhtmlspecialchars($_GET['cp']);

$groupconfigs = explode("\r\n",$xmlcfg['groupconfigs']);
$groupinfo = array();
foreach($groupconfigs as $gbv){
	$akey = explode("=",$gbv);
	$avalue = explode("||",$akey[1]);
	$groupinfo += array($akey[0]=>$avalue);
}

if($cp=='delete'){
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		cpmsg('error');
	}
	$xiaomyid = intval($_GET['xiaomyid']);
	C::t('#xiaomy_buycardvipgroup#xiaomy_buycardvipgroup')->delete_by_id($xiaomyid);
	cpmsg("<strong>".lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr0019')."</strong>", 'action=plugins&operation=config&do='.$pluginid.'&pmod=admincp&identifier=xiaomy_buycardvipgroup', 'succeed');
	
}else if($cp =="createcc"){

	showtableheader(lang('plugin/xiaomy_buycardvipgroup', 'moni_data'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=admincp&identifier=xiaomy_buycardvipgroup');
	showsetting(lang('plugin/xiaomy_buycardvipgroup', 'prestr'),'cardrule','','text',"","",lang('plugin/xiaomy_buycardvipgroup', 'prestr01'));
	showsetting(lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr11'),'num','1','text',"","",lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr011'));
	$option = array();
	array_push($option,array(0,lang('plugin/xiaomy_buycardvipgroup', 'xiaomyflstr01')));
	foreach($groupinfo as $gbk=>$gbv){
		array_push($option,array($gbk,$_G['cache']['usergroups'][$gbv[0]]['grouptitle'].'-'.$gbv[3].lang('plugin/xiaomy_buycardvipgroup', 'htmlstr02')));
	}
	showsetting(lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr12'),array('kmtype',$option),'0','select',"","",lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr012'));
	showsetting(lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr13'),'yxday','10','text',"","",lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr013'));
	showsubmit('createcc');
	showformfooter();/*dism��taobao��com*/
	showtablefooter();/*dis'.'m.tao'.'bao.com*/
	exit;
}

if(submitcheck('createcc')) {
	
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		cpmsg('error');
	}
	
	
	$cardrule = trim(dhtmlspecialchars($_GET['cardrule']));
	$num = intval($_GET['num']);
	$kmtype = intval($_GET['kmtype']);
	$yxday = intval($_GET['yxday']);
	if(strlen($cardrule)>12){
		cpmsg(lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr15'),'','error');
	}
		
	if(!$kmtype || !$cardrule || !$yxday  || !$num){
		cpmsg(lang('plugin/xiaomy_buycardvipgroup', 'xiaomyargs01'),'','error');
	}
	
	$invite_endtime = TIMESTAMP + $yxday*86400;

	for($i=0;$i<$num;$i++){
		$orderid  = random(30);
		//���뿨��
		$carddata = array(
				'cardcode'=>$cardrule.random(18),
				'dateline'=>TIMESTAMP,
				'endtime'=>$invite_endtime,
				'kmtype'=>$kmtype,
		);
		DB::insert('xiaomy_buycardvipgroup',$carddata);
	}
	cpmsg("<strong>".lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr19').$num."</strong>", 'action=plugins&operation=config&do='.$pluginid.'&pmod=admincp&identifier=xiaomy_buycardvipgroup', 'succeed');
}
if(!submitcheck('searchsubmit')) {
	showtableheader(lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr01'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=admincp&identifier=xiaomy_buycardvipgroup', '');  
	$option="<option value=0>".lang('plugin/xiaomy_buycardvipgroup', 'htmlstr08882')."</option>";
	foreach($groupinfo as $gbk=>$gbv){
		$option .="<option value=".$gbk.">".$_G['cache']['usergroups'][$gbv[0]]['grouptitle'].'-'.$gbv[3].lang('plugin/xiaomy_buycardvipgroup', 'htmlstr02')."</option>";
	}
	showtablerow('','', array(
				lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr02').
	            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select name=\"kmtype\">".$option."</select>",  
	            lang('plugin/xiaomy_buycardvipgroup', 'xiaomynew01').
	            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input size=\"25\" name=\"useusername\" type=\"text\" />",    
			));
	showsubmit('searchsubmit');
	showformfooter();/*dism��taobao��com*/
	showtablefooter();/*dis'.'m.tao'.'bao.com*/

}
if(submitcheck('searchsubmit', 1)) {
	showtableheader(lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr01'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=admincp&identifier=xiaomy_buycardvipgroup', '');  
	$option="<option value=0>".lang('plugin/xiaomy_buycardvipgroup', 'htmlstr08882')."</option>";
	foreach($groupinfo as $gbk=>$gbv){
		$option .="<option value=".$gbk.">".$_G['cache']['usergroups'][$gbv[0]]['grouptitle'].'-'.$gbv[3].lang('plugin/xiaomy_buycardvipgroup', 'htmlstr02')."</option>";
	}
	showtablerow('','', array(
				lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr02').
	            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<select name=\"kmtype\">".$option."</select>",  
	            lang('plugin/xiaomy_buycardvipgroup', 'xiaomynew01').
	            "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input size=\"25\" name=\"useusername\" type=\"text\" />",    
			));
	showsubmit('searchsubmit');
	showformfooter();/*dism��taobao��com*/
	showtablefooter();/*dis'.'m.tao'.'bao.com*/
	
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		cpmsg('error','','error');
	}
	
	$kmtype = intval($_GET['kmtype']);
	$useusername = trim(dhtmlspecialchars($_GET['useusername']));
	
	$createcc = "&nbsp;&nbsp;&nbsp;<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=admincp&identifier=xiaomy_buycardvipgroup&cp=createcc&formhash=".formhash()."'><strong style='color:red;'>[".lang('plugin/xiaomy_buycardvipgroup', 'info09')."]</strong></a>";
	showtableheader(lang('plugin/xiaomy_buycardvipgroup', 'kminfo').$createcc.
	"&nbsp;&nbsp;&nbsp;<a style='color:red;' href='#' onclick='exportcsv(".( ($kmtype) ? $kmtype : "0") .",".( ($useusername) ? '"'.$useusername.'"' : "0") .")'>[".lang('plugin/xiaomy_buycardvipgroup', 'info009')."]"
	);
	
	
	if(!$kmtype && !$useusername){
		$url = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&pmod=admincp&identifier=xiaomy_buycardvipgroup';
		Header("Location: $url");
		exit;
	}
	$alldata = array();
	$alldata=C::t('#xiaomy_buycardvipgroup#xiaomy_buycardvipgroup')->fetch_bysearch($kmtype,$useusername);
		
	showtablerow("",'',array(
		lang('plugin/xiaomy_buycardvipgroup', 'astr02'),
		lang('plugin/xiaomy_buycardvipgroup', 'astrnew03'),
		lang('plugin/xiaomy_buycardvipgroup', 'astrnew10'),
		lang('plugin/xiaomy_buycardvipgroup', 'astrnew02'),
		lang('plugin/xiaomy_buycardvipgroup', 'astr001'),
		lang('plugin/xiaomy_buycardvipgroup', 'astr08'),
		lang('plugin/xiaomy_buycardvipgroup', 'astr0008'),
		lang('plugin/xiaomy_buycardvipgroup', 'astr09'),
	));

	foreach($alldata as $value){
			$value['dateline']  = date('Y-m-d H:i:s',$value['dateline']);
			if($value['usedateline']){
				$value['usedateline']  = date('Y-m-d H:i:s',$value['usedateline'] );
			}else{
				$value['usedateline']  = "--";
			}
			$value['endtime']  = date('Y-m-d H:i:s',$value['endtime'] );
			$sxstr  = "&nbsp;&nbsp;&nbsp;<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&xiaomyid=".$value['id']."&pmod=admincp&identifier=xiaomy_buycardvipgroup&cp=delete&formhash=".formhash()."'><strong style='color:red;'>[".lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr18')."]</strong></a>";
			
			showtablerow("",'',array(
				$value['cardcode'],
				$_G['cache']['usergroups'][$groupinfo[$value['kmtype']][0]]['grouptitle'].'-'.$groupinfo[$value['kmtype']][3].lang('plugin/xiaomy_buycardvipgroup', 'htmlstr02'),
				$value['endtime'],
				$value['dateline'],
				$value['useusername'],
				$value['usedateline'],
				$value['useip'],
				$sxstr
				)
			);
	}
	exit;
	
}
	$cur_page=intval(getgpc('page'));
	if($cur_page<1){
		$cur_page=1;
	}

	$curUrl=ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=xiaomy_buycardvipgroup&pmod=admincp";
	
	$createcc = "&nbsp;&nbsp;&nbsp;<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=admincp&identifier=xiaomy_buycardvipgroup&cp=createcc&formhash=".formhash()."'><strong style='color:red;'>[".lang('plugin/xiaomy_buycardvipgroup', 'info09')."]</strong></a>";

	showtableheader(lang('plugin/xiaomy_buycardvipgroup', 'kminfo').$createcc.
	"&nbsp;&nbsp;&nbsp;<a style='color:red;' href='#' onclick='exportcsv(".( ($kmtype) ? $kmtype : "0") .",".( ($useusername) ? '"'.$useusername.'"' : "0") .")'>[".lang('plugin/xiaomy_buycardvipgroup', 'info009')."]"
	);
	

	showtablerow("",'',array(
		lang('plugin/xiaomy_buycardvipgroup', 'astr02'),
		lang('plugin/xiaomy_buycardvipgroup', 'astrnew03'),
		lang('plugin/xiaomy_buycardvipgroup', 'astrnew10'),
		lang('plugin/xiaomy_buycardvipgroup', 'astrnew02'),
		lang('plugin/xiaomy_buycardvipgroup', 'astr001'),
		lang('plugin/xiaomy_buycardvipgroup', 'astr08'),
		lang('plugin/xiaomy_buycardvipgroup', 'astr0008'),
		lang('plugin/xiaomy_buycardvipgroup', 'astr09'),
		
			
));

	$showNum=15;
	$alldata = 	C::t('#xiaomy_buycardvipgroup#xiaomy_buycardvipgroup')->fetch_page_data(($cur_page-1)*$showNum,$showNum);
	$count=C::t('#xiaomy_buycardvipgroup#xiaomy_buycardvipgroup')->count();
	 
	foreach($alldata as $value){
			$value['dateline']  = dgmdate($value['dateline']);
			if($value['usedateline']){
				$value['usedateline']  = dgmdate($value['usedateline'] );
			}else{
				$value['usedateline']  = "--";
			}
			$value['endtime']  = dgmdate($value['endtime'] );
			$sxstr  = "&nbsp;&nbsp;&nbsp;<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&xiaomyid=".$value['id']."&pmod=admincp&identifier=xiaomy_buycardvipgroup&cp=delete&formhash=".formhash()."'><strong style='color:red;'>[".lang('plugin/xiaomy_buycardvipgroup', 'xiaomystr18')."]</strong></a>";
			
			showtablerow("",'',array(
				$value['cardcode'],
				$_G['cache']['usergroups'][$groupinfo[$value['kmtype']][0]]['grouptitle'].'-'.$groupinfo[$value['kmtype']][3].lang('plugin/xiaomy_buycardvipgroup', 'htmlstr02'),
				$value['endtime'],
				$value['dateline'],
				$value['useusername'],
				$value['usedateline'],
				$value['useip'],
				$sxstr
				)
			);
	}
	$pagenav=multi($count, $showNum, $cur_page, $curUrl);
	echo $pagenav;
	showtablefooter();/*dis'.'m.tao'.'bao.com*/
?>