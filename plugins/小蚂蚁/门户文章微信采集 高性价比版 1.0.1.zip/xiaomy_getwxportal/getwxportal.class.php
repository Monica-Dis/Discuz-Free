<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_xiaomy_getwxportal {
}

class plugin_xiaomy_getwxportal_portal extends plugin_xiaomy_getwxportal {
	function portalcp_top() {
		global $_G;
		$xmlcfg = $_G['cache']['plugin']['xiaomy_getwxportal'];
	   	$groups = dunserialize($xmlcfg['xiaomy_groups']);
	   	if(!in_array($_G['groupid'],$groups)){
	   	   	return $return;
	   	}
		return "<div><a onclick=showWindow('xiaomy_getwxportal','plugin.php?id=xiaomy_getwxportal:getwxarticleportal') href=javascript:; class='y viewpay' ><span id='loading' style='display:none;padding-right:5px;'><img src='source/plugin/xiaomy_getwxportal/css/loading.gif'></span><span style='color:red;font-weight:700'>".lang('plugin/xiaomy_getwxportal','loadtitle')."</span></a></div>";
	}
}
//From: Dism_taobao_com
?>