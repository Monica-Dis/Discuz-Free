var xmlHttp

function showHint(formhash)
{
		xmlHttp=GetXmlHttpObject();
		if (xmlHttp==null){
				alert ("Browser does not support HTTP Request");
				return;
		 } 
		var url="plugin.php?id=xiaomy_getwxportal:getwxarticleportal&op=loaddata";
		url=url+"&wechaturl="+escape(document.getElementById("wxurl").value);
		url=url+"&formhash="+formhash;
		url=url+"&sid="+Math.random();
		xmlHttp.onreadystatechange=stateChanged 
		xmlHttp.open("POST",url,true);
		xmlHttp.send(null);
} 



function stateChanged() 
{ 
if(xmlHttp.readyState==4 || xmlHttp.readyState=="complete")
 { 
	  var text = xmlHttp.responseText;
      var json=JSON.parse(text);
      if(json.message == ''  ||  json.message==null) {
    		showError(laodfailwx);
      } 
      document.getElementById("title").value=json.subject;
      var iframetexea = document.getElementById('uchome-ifrHtmlEditor').contentWindow;
      var htmleditor = iframetexea.document.getElementById('HtmlEditor').contentWindow;
      htmleditor.document.write(json.message);
      document.getElementById("loading").style.display = "none";   
 } else{
	 document.getElementById("loading").style.display = "";   
	 hideWindow('xiaomy_getwxportal');
 }
}


function GetXmlHttpObject()
{
var xmlHttp=null;
try
 {
 // Firefox, Opera 8.0+, Safari
 xmlHttp=new XMLHttpRequest();
 }
catch (e)
 {
 // Internet Explorer
 try
  {
  xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");
  }
 catch (e)
  {
  xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
 }
return xmlHttp;
}