<?php 
	if(!defined('IN_DISCUZ')) {
		exit('Access Denied');
	}
   $xmlcfg = $_G['cache']['plugin']['xiaomy_getwxportal'];
   $groups = dunserialize($xmlcfg['xiaomy_groups']);
   if(!in_array($_G['groupid'],$groups)){
   		showmessage(lang('plugin/xiaomy_getwxportal','grouptips'));
   }
   $op= $_GET['op'];
   if($op == "loaddata"){
   		if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
				$contents['subject'] = "";
				$contents['message'] = "";
				echo json_encode($contents);
				exit;
		}
   		$wxurl = trim($_GET['wechaturl']);
   		$istieba = strstr($wxurl, 'mp.weixin.qq.com');
   		if(!check_url($wxurl) ||  !$istieba){
			$contents['subject'] = "";
			$contents['message'] = "";
			echo json_encode($contents);
			exit;
		}
   		//ʹ��dz�Դ�����dfsockopen��ȡ����
   		$urlcontent = dfsockopen($wxurl);
   		//��ȡ��������ֱ�ӷ��ؿ�
   		if(!$urlcontent){
   			$contents['subject'] = "";
   			$contents['message'] = "";
   			echo json_encode($contents);
   			exit;
   		}
   		$title = get_title($urlcontent);
   		
   		$pattstr = '/<div class="rich_media_content " id="js_content">(.*)<\/div>/iUs';
   		preg_match($pattstr, $urlcontent,$bodycontent);
   		$bodycontent=$bodycontent[1];
   		
   		$attachcontent = get_contents($bodycontent);
   		
   		$contents['subject'] = $title;
   		
   		$contents['message'] = $attachcontent;
   		
   		//��װ��json��ʽ
   		echo json_encode($contents);
   		
   }else{
	   include template('xiaomy_getwxportal:getwxportal');
   }
   
   
   function get_title($content){
       $patternstr = '/<h2 class="rich_media_title" id="activity-name">(.*)<\/h2>/iUs';
   	preg_match($patternstr, $content,$title);
   	$title =  trim(daddslashes($title[1]));
   	return $title;
   }
   
   function get_contents($content){
   	global $_G;
   	$imgurl=array();
   	$upload = new discuz_upload();
   	$pimg="/<[img|IMG].*?src=[\'|\"](.*?)[\'|\"].*?[\/]?>/";
   	preg_match_all($pimg,$content,$imgurl);
   	foreach ($imgurl[1] as  $ik=>$iv){
   
   		$im ="";
   		$minfo = $attach= array();
   		$im = dfsockopen($iv);
   
   		if(empty($im)){
   			continue;
   		}
   		$minfo =getimagesize("data://text/plain;base64," . base64_encode($im));
   		if($minfo['mime']=='image/jpeg'){
   			$attach['ext']='jpg';
   		}elseif($minfo['mime']=='image/gif'){
   			$attach['ext']='gif';
   		}elseif($minfo['mime']=='image/png'){
   			$attach['ext']='png';
   		}elseif($minfo['mime']=='image/bmp'){
   			$attach['ext']='bmp';
   		}
   
   		if(empty($attach['ext'])) continue;
   
   		//�ο�form.ajax д��
   		$attach['name'] =  md5($iv).'.'.$attach['ext'];
   		$attach['thumb'] = '';
   		$attach['isimage'] = $upload -> is_image_ext($attach['ext']);
   		$attach['extension'] = $upload -> get_target_extension($attach['ext']);
   
   		$attach['attachdir'] = $upload -> get_target_dir('portal');
   		$attach['attachment'] = $attach['attachdir'] . $upload->get_target_filename('portal').'.'.$attach['extension'];
   		$attach['target'] = getglobal('setting/attachdir').'./portal/'.$attach['attachment'];
   
   
   		if (!@$fp = fopen($attach['target'], 'wb'))
   		{
   			continue;
   		} else{
   			flock($fp, 2);
   			fwrite($fp, $im);
   			fclose($fp);
   		}
   
   		if(!$upload->get_image_info($attach['target'])) {
   			@unlink($attach['target']);
   			continue;
   		}
   		$attach['size'] = filesize($attach['target']);
   		
   		$upload->attach = $attach;
   		
   		$loadimgsrc= 'data/attachment/portal/'.$upload->attach['attachment'];
   		$attachimgstr = '<p><a href="'.$loadimgsrc.'" target="_blank"><img src="'.$loadimgsrc.'" _moz_resizing="true"></a></p>';
   		$content = str_replace($imgurl[0][$ik], $attachimgstr, $content);
   	}
   	return $content;
   
   }
   
   
function check_url($url){
	if(!preg_match('/http|https:\/\/[\w.]+[\w\/]*[\w.]*\??[\w=&\+\%]*/is',$url)){
		return false;
	}
	return true;

}
//From: Dism_taobao_com
?>