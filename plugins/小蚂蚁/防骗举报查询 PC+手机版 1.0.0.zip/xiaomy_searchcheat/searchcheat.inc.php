<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$type = daddslashes($_GET['type']);
$configs = $_G['cache']['plugin']['xiaomy_searchcheat'];
$jbtype = explode("\r\n",$configs['jbtype']);
$jbtypes = array();
foreach($jbtype as $gbv){
	$akey = explode("=",$gbv);
	$jbtypes += array($akey[0]=>$akey[1]);
}
$adminuids = explode(",", $configs['adminuids']);
$groups = dunserialize($configs['groupids']);

if($type == "addbg"){
	
	if(!$_G['uid']) {
		showmessage('not_loggedin', NULL, array(), array('login' => 1));
	}
	
	
	if(!in_array($_G['groupid'],$groups)){
		showmessage(lang('plugin/xiaomy_searchcheat', 'tishistr06'));
	}
	
	$isamdin = false;
	if(in_array($_G['uid'], $adminuids)){
		$isamdin = true;
	}
		include template('xiaomy_searchcheat:addbg');
	
}elseif($type == "addbgsubmit"){

	
	if(!$_G['uid']) {
		showmessage('not_loggedin', NULL, array(), array('login' => 1));
	}
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		showmessage('error');
	}
	if(!in_array($_G['groupid'],$groups)){
		showmessage(lang('plugin/xiaomy_searchcheat', 'tishistr06'));
	}
	
	
	$jbtype = daddslashes($_GET['jbtype']);
	$jbcontent = daddslashes($_GET['jbcontent']);
	$jbremark = daddslashes($_GET['jbremark']);
	
	if(!$jbcontent || !$jbcontent || !$jbremark){
		showmessage(lang('plugin/xiaomy_searchcheat', 'tishistr01'));
	}
	
	$data  = array(
			'uid'=>$_G['uid'],
			'username'=>$_G['username'],
			'jbtype'=>$jbtype,
			'jbcontent'=>$jbcontent,
			'jbremark'=>$jbremark,
			'status'=>1,
			'dateline'=>$_G['timestamp'],
	);
	C::t('#xiaomy_searchcheat#xiaomy_searchcheat')->insert($data);
	showmessage(lang('plugin/xiaomy_searchcheat', 'tishistr02'),"plugin.php?id=xiaomy_searchcheat:searchcheat",array(),array('alert'=>'right'));

}elseif($type=="search"){
	
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		showmessage('error');
	}
	$searchcontent = daddslashes($_GET['searchcontent']);
	
	
	$alldata = 	C::t('#xiaomy_searchcheat#xiaomy_searchcheat')->fetch_search($searchcontent);
	$count=C::t('#xiaomy_searchcheat#xiaomy_searchcheat')->fetch_page_datastatuscount();
	$count = $count['scount'];
	include template('xiaomy_searchcheat:main');
}else{
	
	$cur_page=intval(getgpc('page'));
	if($cur_page<1){
		$cur_page=1;
	}
	
	$curUrl="plugin.php?id=xiaomy_searchcheat:searchcheat";
	$showNum=25;
	$alldata = 	C::t('#xiaomy_searchcheat#xiaomy_searchcheat')->fetch_page_datastatus(($cur_page-1)*$showNum,$showNum);
	$count=C::t('#xiaomy_searchcheat#xiaomy_searchcheat')->fetch_page_datastatuscount();
	$count = $count['scount'];
	
	$pagenav=multi($count, $showNum, $cur_page, $curUrl);
	

	include template('xiaomy_searchcheat:main');
}
//From: Dism_taobao-com
?>