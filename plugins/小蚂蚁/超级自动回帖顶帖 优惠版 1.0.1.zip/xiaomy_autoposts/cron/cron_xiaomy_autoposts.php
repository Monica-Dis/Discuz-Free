<?php
//cronname:cron_xiaomy_autoposts
//week:
//day:
//hour:
//minute:30

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$xiaomycfg =  $_G['cache']['plugin']['xiaomy_autoposts'];
if(!$xiaomycfg){
	loadcache("plugin");
	$xiaomycfg =  $_G['cache']['plugin']['xiaomy_autoposts'];
}

//ɸѡ����
$postforum = dunserialize($xiaomycfg['postforum']);
foreach($postforum as $pf){
	$fids .= $pf.",";	
}
$fids = trim($fids,",");
$fids ="(".$fids.")";
$fids = dhtmlspecialchars($fids);

$poststarttime = strtotime($xiaomycfg['poststarttime']);
$postendtime = strtotime($xiaomycfg['postendtime']);
$thread = C::t("#xiaomy_autoposts#xiaomy_autoposts")->fetch_bycondition($fids,$poststarttime,$postendtime,$xiaomycfg['postrange']);

$replyuids = explode(",",$xiaomycfg['postuid']);
$replycontents=  explode("\r\n",$xiaomycfg['postcontent']);
shuffle($replyuids);
shuffle($replycontents);
shuffle($thread);

$index = rand(0,count($replyuids)-1);
$authorid = $replyuids[$index];
$author = C::t('common_member')->fetch_all_username_by_uid(array($authorid));
$tindex = rand(0,count($thread)-1);
$sthread = $thread[$tindex];
$rindex = rand(0,count($replycontents)-1);
$sreplycontents = $replycontents[$rindex];


$postdata = array(
	'dateline'=>$_G['timestamp'],
	'fid'=>$sthread['fid'],
	'tid'=>$sthread['tid'],
	'uid'=>$authorid,
	'username'=>$author[$authorid],
	'content' =>$sreplycontents,
	'ip'=>get_rand_ip(),
);
if($postdata['username']){
	$test = replypost($postdata);
}
	function replypost($postdata){
	global $_G;
	require_once libfile('function/post');
	require_once libfile('function/forum');
	$dateline=$postdata['dateline'];
	$invisible=0;
	$pid = insertpost(array(
			'fid' => $postdata['fid'],
			'tid' => $postdata['tid'],
			'first' => '0',
			'author' => $postdata['username'],
			'authorid' => $postdata['uid'],
			'subject' => '',
			'dateline' =>$dateline,
			'message' => htmlspecialchars_decode($postdata['content'],ENT_QUOTES),
			'useip' => $postdata['ip'],//,
			'invisible' => $invisible,
			'anonymous' => 0,
			'usesig' => 0,
			'htmlon' => 0,
			'bbcodeoff' => 0,
			'smileyoff' => 0,
			'parseurloff' => 0,
			'attachment' => 0,
			'tags' => '',
			'replycredit' => 0,
			'status' => 0
	));
	C::t('common_member_count')->increase(array($postdata['uid']),array('posts'=>1));
	C::t('forum_thread')->update($postdata['tid'],array('`replies`=`replies`+1','`lastpost`='.$dateline,'lastposter=\''.$postdata['username'].'\''),false,false,0,true);
	C::t('forum_forum')->update_forum_counter($postdata['fid'],0,1,1);
	$subject=htmlspecialchars_decode($postdata['tid']['subject']);
	$lastpost = "$tid\t$subject\t".$dateline."\t".$postdata['username'];
	C::t('forum_forum')->update(array('fid'=>$postdata['fid']),array('lastpost'=>$lastpost));
	return $postdata['tid'];
}

function get_rand_ip(){
	$arr_1 = array("218","218","66","66","218","218","60","60","202","204","66","66","66","59","61","60","222","221","66","59","60","60","66","218","218","62","63","64","66","66","122","211");
	$randarr= mt_rand(0,count($arr_1));
	$ip1id = $arr_1[$randarr];
	$ip2id=  round(rand(600000,  2550000)  /  10000);
	$ip3id=  round(rand(600000,  2550000)  /  10000);
	$ip4id=  round(rand(600000,  2550000)  /  10000);
	return  $ip1id . "." . $ip2id . "." . $ip3id . "." . $ip4id;
}
//dis'.'m.t'.'ao'.'bao.com
?>
