var content="<li class='comiis_flex qqli styli_zico b_b f16' style='background: #fff;'>" +
"<div class='styli_tit'><i class='comiis_font f_d'></i>注册码<span class='f_g'>*</span></div>" +
"<div class='flex'><input type='text'  class='px p_fre'  id='weixincode'   name='weixincode' placeholder='注册码' style='border:none;'>&nbsp;&nbsp;&nbsp;" +
"<input type='button' onClick='showweixinqr();' class='px p_fre'  value='获取注册码' style='background: #a5a5a5;border: none;padding: 3px 7px;color: #fff;'></div></li>";

var showqr="<div id='shownotes' style='display:none;text-align:center;line-height:45px;'>"+xmypcalertinfo+"</div>" +
"<div id='showqr'  style='display:none;text-align:center;line-height:45px;'><img  width=200 height=200 src='"+xmyweixgzhurl+"'></div>"; 
$("#registerform").append(content+showqr); 

function showweixinqr(){
	 document.getElementById("shownotes").style.display="";
	 document.getElementById("showqr").style.display="";
}

