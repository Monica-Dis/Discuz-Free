<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_xiaomy_fansweixin {
	
	public $config = array();
	function plugin_xiaomy_fansweixin(){
		global $_G;
		$this->config = $_G['cache']['plugin']['xiaomy_fansweixin'];
	}
	
	function getmobilehtml(){
		
		if(strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger') == false){
			$pcalertinfo = dhtmlspecialchars($this->config['pcalertinfo']);
		}else{
			$pcalertinfo = dhtmlspecialchars($this->config['wxalertinfo']);
		}
		return '<script type="text/javascript">' .
				'var xmyfieldname ="'.dhtmlspecialchars($this->config['fieldname']).'";' .
				'var xmyfieldnamebtn ="'.dhtmlspecialchars(lang('plugin/xiaomy_fansweixin', 'fw01').$this->config['fieldname']).'";' .
				'var xmypcalertinfo ="'.$pcalertinfo.'";' .
				'var xmyweixgzhurl ="'.dhtmlspecialchars($this->config['weixgzhurl']).'";' .
				'</script><SCRIPT src="source/plugin/xiaomy_fansweixin/static/fansweixin.js" type=text/javascript></SCRIPT>';
	}
	
}

class plugin_xiaomy_fansweixin_member extends plugin_xiaomy_fansweixin {
	
	//ע��
	function register_input(){
			$return ="";
			$fieldname = dhtmlspecialchars($this->config['fieldname']);
			include template('xiaomy_fansweixin:fansweixin');
			return $return;	
	}

	//ע����
	function register_fansweixin($param){
		global $_G;
		if(submitcheck('regsubmit')){
			$weixincode = daddslashes($_GET['weixincode']);
			if($weixincode != $this->config['regcode']){
				showmessage(dhtmlspecialchars($this->config['alertinfo']));
			}
		}
	}
}

class mobileplugin_xiaomy_fansweixin extends plugin_xiaomy_fansweixin {
	
	//ע��
	function global_footer_mobile(){
		if($_GET['mod']=="register"){
			return $this->getmobilehtml();
		}
	}
}

class mobileplugin_xiaomy_fansweixin_member extends plugin_xiaomy_fansweixin {
	
	//ע����
	function register_fansweixin($param){
		global $_G;
		if(submitcheck('regsubmit')){
			$weixincode = daddslashes($_GET['weixincode']);
			if($weixincode != $this->config['regcode']){
				showmessage(dhtmlspecialchars($this->config['alertinfo']));
			}
		}
	}
}


//dis'.'m.t'.'ao'.'bao.com
?>