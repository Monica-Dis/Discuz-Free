<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$type = daddslashes($_GET['type']);
$configs = $_G['cache']['plugin']['xiaomy_fraud'];
$jbtype = explode("\r\n",$configs['jbtype']);
$jbtypes = array();
foreach($jbtype as $gbv){
	$akey = explode("=",$gbv);
	$jbtypes += array($akey[0]=>$akey[1]);
}
$adminuids = explode(",", $configs['adminuids']);
$groups = dunserialize($configs['groupids']);
$isquanx = array("my","mysc",'editbg','editpic','editsubmit','addbgsubmit','delete');
if(in_array($type, $isquanx)){
    if(!$_G['uid']) {
        showmessage('not_loggedin', NULL, array(), array('login' => 1));
    }
}
$lookgroup = dunserialize($configs['lookgroup']);
$islook = "1";
if(in_array($_G['groupid'], $lookgroup)){
    $islook = "2";
}
$keyword = explode("||", $configs['keyword']);




$title=lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_1');

if($type == "editbg"){

    $bgid = intval($_GET['bgid']);
    $where .= "where id=".$bgid." AND uid=".$_G['uid'];
    $editdata = C::t('#xiaomy_fraud#xiaomy_fraud')->fetch_first_field_data("*",$where);
    if (!$editdata){
        showmessage(lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_2'));
    }
    $jbpic = dunserialize($editdata['jbpic']);
    include template('xiaomy_fraud:editbg');
    
}elseif($type == "editpic"){

    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        echojson(2,"data error");
    }
    $pindx =  intval($_GET['pindx']);
    $bgid =  intval($_GET['bgid']);
    $where .= "where id=".$bgid." AND uid=".$_G['uid'];
    $editdata = C::t('#xiaomy_fraud#xiaomy_fraud')->fetch_first_field_data("*",$where);
    $jbpic = dunserialize($editdata['jbpic']);
    unset($jbpic[$pindx]);
    $jbpic = array_values($jbpic);
    $arrupdate['jbpic'] = serialize($jbpic);
    C::t('#xiaomy_fraud#xiaomy_fraud')->update(array('id'=>$bgid),$arrupdate);

}elseif($type == "editsubmit"){
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        echojson(2,"data error");
    }
    $bgid = daddslashes($_GET['bgid']);
    $where .= "where id=".$bgid." AND uid=".$_G['uid'];
    $editdata = C::t('#xiaomy_fraud#xiaomy_fraud')->fetch_first_field_data("*",$where);
    if(!$editdata){
        echojson(2,"data error");
    }
    $jbname = daddslashes($_GET['jbname']);
    $jbwx = daddslashes($_GET['jbwx']);
    $jbphone = daddslashes($_GET['jbphone']);
    $jbqq = daddslashes($_GET['jbqq']);
    $jbremark = daddslashes($_GET['jbremark']);
    $isnm = intval($_GET['isnm']);
    $jbprice = intval($_GET['jbprice']);
    $data  = array(
        'uid'=>$_G['uid'],
        'username'=>$_G['username'],
        'jbname'=>$jbname,
        'jbwx'=>$jbwx,
        'jbphone'=>$jbphone,
        'jbqq'=>$jbqq,
        'isnm'=>$isnm,
        'jbremark'=>$jbremark,
        'status'=>1,
        'jbprice'=>$jbprice,
        'dateline'=>$_G['timestamp'],
    );
    $fileobjs = format_files($_FILES);
    foreach ($fileobjs as $value) {
        $upload = new discuz_upload();
        $upload->init($value, 'forum', random(3, 1), random(8));
        if(!in_array($upload->attach['ext'], array('jpg','png','gif','jpeg')))
        {
            echojson(2,lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_3'));
        }
        if($upload->attach['size']>5097152){
            echojson(2,lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_4'));
        }
        $upload->save();
        $picpath = $_G['setting']['attachurl'].'forum/'.$upload->attach['attachment'];
        $tempfilename = explode("/", $upload->attach['attachment']);
        $smallpic = explode(".", $tempfilename[2]);
        mkThumbnail($picpath, 80, 80,$_G['setting']['attachurl'].'forum/'.$upload->attachdir.$smallpic[0]."_small".".".$smallpic[1]);
        $picurl1[] = array(
            'pic'=>$picpath,
            'pic_small'=>$_G['setting']['attachurl'].'forum/'.$upload->attachdir.$smallpic[0]."_small".".".$smallpic[1]);
        $jbpic = dunserialize($editdata['jbpic']);
        if($jbpic){
            $picurl1update =  array_merge($picurl1,$jbpic);
        }else{
            $picurl1update = $picurl1;
        }
        $picurlserstr1 = serialize($picurl1update);
        $data['jbpic'] = $picurlserstr1;
    }
    C::t('#xiaomy_fraud#xiaomy_fraud')->update(array('id'=>$bgid),$data);
    echojson(8,"");

}elseif($type == "addbg"){
	if(!$_G['uid']) {
		showmessage('not_loggedin', NULL, array(), array('login' => 1));
	}
	if(!in_array($_G['groupid'],$groups)){
		showmessage(lang('plugin/xiaomy_fraud', 'tishistr06'));
	}
	$isamdin = false;
	if(in_array($_G['uid'], $adminuids)){
		$isamdin = true;
	}
	include template('xiaomy_fraud:addbg');
	
}elseif($type == "addbgsubmit"){

    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        echojson(2,"data erro");
    }
	if(!in_array($_G['groupid'],$groups)){
        echojson(2,lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_5'));
	}
	$jbname = daddslashes($_GET['jbname']);
	$jbwx = daddslashes($_GET['jbwx']);
	$jbphone = daddslashes($_GET['jbphone']);
	$jbqq = daddslashes($_GET['jbqq']);
	$jbremark = daddslashes($_GET['jbremark']);
	$isnm = intval($_GET['isnm']);
	
	$jbprice = intval($_GET['jbprice']);
	//�����ļ��ϴ�
	$fileobjs = format_files($_FILES);
	foreach ($fileobjs as $value) {
	    $upload = new discuz_upload();
	    $upload->init($value, 'forum', random(3, 1), random(8));
	    if(!in_array($upload->attach['ext'], array('jpg','png','gif','jpeg')))
	    {
            echojson(2,lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_3'));
	    }
	    if($upload->attach['size']>5097152){
            echojson(2,lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_4'));
	    }
	    $upload->save();
	    
	    $picpath = $_G['setting']['attachurl'].'forum/'.$upload->attach['attachment'];
	    $tempfilename = explode("/", $upload->attach['attachment']);
	    $smallpic = explode(".", $tempfilename[2]);
	    mkThumbnail($picpath, 80, 80,$_G['setting']['attachurl'].'forum/'.$upload->attachdir.$smallpic[0]."_small".".".$smallpic[1]);
	    $picurl1[] = array(
	         'pic'=>$picpath,
	         'pic_small'=>$_G['setting']['attachurl'].'forum/'.$upload->attachdir.$smallpic[0]."_small".".".$smallpic[1]);
	}
	$picurlserstr1 = serialize($picurl1)	;
	$data  = array(
			'uid'=>$_G['uid'],
			'username'=>$_G['username'],
    	    'jbname'=>$jbname,
    	    'jbwx'=>$jbwx,
    	    'jbphone'=>$jbphone,
    	    'jbqq'=>$jbqq,
    	    'isnm'=>$isnm,
			'jbremark'=>$jbremark,
			'status'=>1,
	        'jbprice'=>$jbprice,
	       'jbpic'=>$picurlserstr1,
            'dateline'=>$_G['timestamp'],
	);
	C::t('#xiaomy_fraud#xiaomy_fraud')->insert($data);
    echojson(8,"");

}elseif($type=="delete"){

    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        echojson(2,"data erro");
    }
    $bgid = intval($_GET['bgid']);
    $where .= "where id=".$bgid." AND uid=".$_G['uid'];
    $editdata = C::t('#xiaomy_fraud#xiaomy_fraud')->fetch_first_field_data("*",$where);
    if(!$editdata){
        echojson(2,"data error");
    }
    C::t('#xiaomy_fraud#xiaomy_fraud')->delete_by_id($bgid);
    echojson(8,"");
    
}elseif($type=="search"){
	$searchcontent = daddslashes($_GET['searchcontent']);
	$alldata = 	C::t('#xiaomy_fraud#xiaomy_fraud')->fetch_search($searchcontent);
	$count=C::t('#xiaomy_fraud#xiaomy_fraud')->fetch_page_datastatuscount();
	$count = $count['scount'];
	include template('xiaomy_fraud:main');
	
}elseif($type=="my"){

    include template('xiaomy_fraud:my');

}elseif($type=="mysc"){

    include template('xiaomy_fraud:mysc');
}elseif($type=="myscpage"){
    $ppp = 10;
    $page = max (1, intval($_GET ['page'] ) );
    $startlimit = ($page - 1) * $ppp;
    $query = C::t('#xiaomy_fraud#xiaomy_fraud_collect')->fetch_mycollect( $startlimit, $ppp, $_G['uid']);
    for($i=0;$i<count($query);$i++){
            $jbremarkstr = cutstr($query[$i]['jbremark'],100,'...');
            $jbremarkstr= diconv($jbremarkstr,CHARSET,"UTF-8");
            $query[$i]['jbremark'] =$jbremarkstr;
    }
    $res = array('res'=>2,'List'=>$query);
    $res = json_encode($res);
    echo $res;
    exit;

}elseif($type=="mypage"){

    $wheres = 'where uid='.$_G['uid'];
    $ppp = 10;
    $page = max (1, intval( $_GET ['page'] ) );
    $startlimit = ($page - 1) * $ppp;
    $query = C::t('#xiaomy_fraud#xiaomy_fraud')->fetch_all_by_limit ( "id,status,jbremark",$startlimit, $ppp, $wheres );
    for($i=0;$i<count($query);$i++){
        $jbremarkstr = cutstr($query[$i]['jbremark'],100,'...');
        $jbremarkstr= diconv($jbremarkstr,CHARSET,"UTF-8");
        $query[$i]['jbremark'] =$jbremarkstr;
    }
    $res = array('res'=>2,'List'=>$query);
    $res = json_encode($res);
    echo $res;
    exit;

}elseif($type=="mymianpage"){
    
    $wheres = 'where 1=1 and status=2';
    $searchstr = daddslashes($_GET['searchcontent']);
    
    if ($searchstr) {
		$searchstr = str_replace('*', '%', addcslashes($searchstr, '%_'));
        $wheres .= " AND (jbremark like '%" .$searchstr. "%'  or jbqq like '%".$searchstr."%' or jbname like '%".$searchstr."%' or jbwx like '%".$searchstr."%' or jbphone like '%".$searchstr."%')";
    }
    $ppp = 10;
    $page = max (1, intval( $_GET ['page'] ) );
    $startlimit = ($page - 1) * $ppp;
    $query = C::t('#xiaomy_fraud#xiaomy_fraud')->fetch_all_by_limit ( "id,jbphone,jbremark,jbpic,username,isnm",$startlimit, $ppp, $wheres );
    for($i=0;$i<count($query);$i++){
        $jbremark = cutstr($query[$i]['jbremark'],200,"...");
        $query[$i]['jbremark'] = diconv($jbremark,CHARSET,"UTF-8");;
        $jbpic = dunserialize( $query[$i]['jbpic']);
        foreach ($jbpic as $value) {
            $query[$i]['showpics'] .= "<img onclick='showmxpic(this)'  width='80' height='80' src='".$value['pic_small']."'>&nbsp;";
        }
        
        if(!$query[$i]['showpics']){
            $query[$i]['showpics'] = "&nbsp;";
        }
        if($query[$i]['jbphone']){
            $isstr =  diconv(lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_6').cutstr($query[$i]['jbphone'],3,"********"),CHARSET,"UTF-8");;
        }else{
            $isstr ="&nbsp;";
        }
        $query[$i]['isnmstr'] = $isstr ;
        $query[$i]['username'] = diconv($query[$i]['username'],CHARSET,"UTF-8");
    }
    $res = array('res'=>2,'List'=>$query);
    $res = json_encode($res);
    echo $res;
    exit;

}elseif($type=="detail"){
    if($islook == 1){
        showmessage(lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_7'));
    }
    $pzid = intval($_GET['pzid']);
    $wheres = 'where id='.$pzid;
    $detailinfo = C::t('#xiaomy_fraud#xiaomy_fraud')->fetch_first_field_data("*",$wheres);
    if(!$detailinfo){
        showmessage(lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_2'));
    }
    $jbpic = dunserialize($detailinfo['jbpic']);
    include template('xiaomy_fraud:detail');

}elseif($type=="collect"){

    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        echojson(2,"data erro");
    }
    $tsstr  = lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_8');
    $tsstr2 =  lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_9');
    $bgid = intval($_GET['bgid']);
    $wherestr = " where uid=".$_G['uid']." AND bgid=".$bgid;
    $issc = C::t('#xiaomy_fraud#xiaomy_fraud_collect')->fetch_first_field_data('id',$wherestr);
    if($issc){
        echojson(2,$tsstr);
    }
    $data  = array(
        'uid'=>$_G['uid'],
        'bgid'=>$bgid,
        'dateline'=>$_G['timestamp'],
    );
    C::t('#xiaomy_fraud#xiaomy_fraud_collect')->insert($data);
    echojson(8,$tsstr2);

}elseif($type=="canelcollect"){
    if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
        echojson(2,"data erro");
    }
    $bgid = intval($_GET['bgid']);
    $wherestr = " where uid=".$_G['uid']." AND bgid=".$bgid;
    $issc = C::t('#xiaomy_fraud#xiaomy_fraud_collect')->fetch_first_field_data('id',$wherestr);
    if(!$issc){
        echojson(2,"data error");
    }
    C::t('#xiaomy_fraud#xiaomy_fraud_collect')->delete_by_id($issc['id']);
    echojson(8,lang('plugin/xiaomy_fraud', 'xiaomy_fraud_lang_10'));

}else{
	
	$cur_page=intval(getgpc('page'));
	if($cur_page<1){
		$cur_page=1;
	}
	$curUrl="plugin.php?id=xiaomy_fraud";
	$showNum=25;
	$alldata = 	C::t('#xiaomy_fraud#xiaomy_fraud')->fetch_page_datastatus(($cur_page-1)*$showNum,$showNum);
	$count=C::t('#xiaomy_fraud#xiaomy_fraud')->fetch_page_datastatuscount();
	$count = $count['scount'];
	$pagenav=multi($count, $showNum, $cur_page, $curUrl);

	include template('xiaomy_fraud:main');
}



function format_files($files)
{
    $fileArray = array();
    $n = 0;
    foreach ($files as $key => $file)
    {
        if (is_array($file['name']))
        {
            $keys = array_keys($file);
            $count = count($file['name']);
            for ($i = 0; $i < $count; $i++)
            {
                $fileArray[$n]['key'] = $key;
                foreach ($keys as $_key)
                {
                    $fileArray[$n][$_key] = $file[$_key][$i];
                }
                $n++;
            }
        }
        else
        {
            $fileArray[$n] = $file;
            $fileArray[$n]['key'] = $key;
            $n++;
        }
    }
    
    return $fileArray;
}

function echojson($res,$msg=""){
    $msg =  diconv($msg,CHARSET,'utf-8');
    $res = array('res'=>$res,'msg'=>$msg);
    echo json_encode($res);
    exit;
}

function mkThumbnail($src, $width = null, $height = null, $filename = null) {
    if (!isset($width) && !isset($height))
        return false;
        if (isset($width) && $width <= 0)
            return false;
            if (isset($height) && $height <= 0)
                return false;
                
                $size = getimagesize($src);
                if (!$size)
                    return false;
                    
                    list($src_w, $src_h, $src_type) = $size;
                    $src_mime = $size['mime'];
                    switch($src_type) {
                        case 1 :
                            $img_type = 'gif';
                            break;
                        case 2 :
                            $img_type = 'jpeg';
                            break;
                        case 3 :
                            $img_type = 'png';
                            break;
                        case 15 :
                            $img_type = 'wbmp';
                            break;
                        default :
                            return false;
                    }
                    
                    if (!isset($width))
                        $width = $src_w * ($height / $src_h);
                        if (!isset($height))
                            $height = $src_h * ($width / $src_w);
                            
                            $imagecreatefunc = 'imagecreatefrom' . $img_type;
                            $src_img = $imagecreatefunc($src);
                            $dest_img = imagecreatetruecolor($width, $height);
                            imagecopyresampled($dest_img, $src_img, 0, 0, 0, 0, $width, $height, $src_w, $src_h);
                            
                            $imagefunc = 'image' . $img_type;
                            if ($filename) {
                                $imagefunc($dest_img, $filename);
                            } else {
                                header('Content-Type: ' . $src_mime);
                                $imagefunc($dest_img);
                            }
                            imagedestroy($src_img);
                            imagedestroy($dest_img);
                            return true;
}

//From: Dism_taobao-com
?>