var toast = $('#js_toast');

function sc(){
	var formData = new FormData();
	formData.append('bgid',bgtid);
	formData.append('formhash',formhash);
	//删除图片
    $.ajax({
        url: "plugin.php?id=xiaomy_fraud"+"&type=collect",
        type: 'POST',
        cache: false,
        data: formData,
        processData: false,
        contentType: false,
        dataType: "json",
        success: function(data){
        	toast.find(".weui-toast__content").html(data.msg);
        	toast.fadeIn(100);
            setTimeout(function () {
            	toast.fadeOut(100);
            }, 2000);  
        }
    });
}

function canelcollect(bgtid){
	var formData = new FormData();
	formData.append('bgid',bgtid);
	formData.append('formhash',formhash);
    $.ajax({
        url: "plugin.php?id=xiaomy_fraud"+"&type=canelcollect",
        type: 'POST',
        cache: false,
        data: formData,
        processData: false,
        contentType: false,
        dataType: "json",
        success: function(data){
        	toast.find(".weui-toast__content").html(data.msg);
        	toast.fadeIn(100);
            setTimeout(function () {
            	$("#cl_"+bgtid).remove();
            	toast.fadeOut(100);
            }, 2000);    
        }
    });
}