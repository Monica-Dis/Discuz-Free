<?php
/**
 *
 * author:xiaomy
 * QQ:3396710833
 *
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$installsql = <<<EOF
DROP TABLE IF EXISTS cdb_xiaomy_fraud;
CREATE TABLE IF NOT EXISTS `cdb_xiaomy_fraud` (
  `id`    int(11) unsigned NOT NULL auto_increment,
  `uid` MEDIUMINT(8) UNSIGNED NOT NULL,
   `username` VARCHAR(30) NOT NULL DEFAULT '',
   `jbname` VARCHAR(30) NOT NULL DEFAULT '',
   `jbwx` VARCHAR(30) NOT NULL DEFAULT '',
   `jbphone` VARCHAR(30) NOT NULL DEFAULT '',
   `jbqq` VARCHAR(30) NOT NULL DEFAULT '',
   `isnm` CHAR(2) NOT NULL DEFAULT '',
  `jbremark` VARCHAR(300) NOT NULL DEFAULT '',
  `status` CHAR(2) NOT NULL DEFAULT '',
  `jbprice` varchar(300) DEFAULT NULL,
  `pic` varchar(300) DEFAULT NULL,
  `pic_small` varchar(300) DEFAULT NULL,
  `jbpic` text DEFAULT NULL,
  `dateline` INT(10) NULL DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `xiaomy_fraud` (`uid`)
) ENGINE=MyISAM;



DROP TABLE IF EXISTS cdb_xiaomy_fraud_collect;
CREATE TABLE IF NOT EXISTS `cdb_xiaomy_fraud_collect` (
  `id`    int(11) unsigned NOT NULL auto_increment,
  `uid` MEDIUMINT(8) UNSIGNED NOT NULL,
  `bgid` MEDIUMINT(8) UNSIGNED NOT NULL,
  `dateline` INT(10) NULL DEFAULT NULL,
  PRIMARY KEY  (`id`),
  KEY `xiaomy_fraud_collect` (`uid`)
) ENGINE=MyISAM;

EOF;
runquery($installsql);
$finish = TRUE;


@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_fraud/discuz_plugin_xiaomy_fraud.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_fraud/discuz_plugin_xiaomy_fraud_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_fraud/discuz_plugin_xiaomy_fraud_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_fraud/discuz_plugin_xiaomy_fraud_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_fraud/discuz_plugin_xiaomy_fraud_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaomy_fraud/install.php');

?>