<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_xiaomy_fraud_collect extends discuz_table
{
	public function __construct() {

		$this->_table = 'xiaomy_fraud_collect';
		$this->_pk    = 'id';
		parent::__construct(); /*dism - taobao - com*/
	}

	
	public function fetchbyuid($uid)
	{
		return DB::fetch_first('SELECT * FROM  %t where uid=%d', array($this->_table,$uid));
	}
	
		public function fetch_page_data($start=0,$limit=10)
	{
		return DB::fetch_all('SELECT * FROM  %t   order by dateline desc limit %d,%d', array($this->_table,$start,$limit));
	}
	
	
	public function fetch_page_datastatus($start=0,$limit=10)
	{
		return DB::fetch_all('SELECT * FROM  %t where status=2 order by dateline desc  limit %d,%d', array($this->_table,$start,$limit));
	}
	
	public function fetch_page_datastatuscount($start=0,$limit=10)
	{
		return DB::fetch_first('SELECT count(*) as scount FROM  %t where status=2', array($this->_table,$start,$limit));
	}
	
	
	public function fetch_search($searchstr)
	{
		return DB::fetch_all('SELECT * FROM  %t where jbcontent like %s or jbremark like %s', array($this->_table,'%'.$searchstr."%",'%'.$searchstr."%"));
	}
	
	
		public function delete_by_id($did){
		
		return DB::query('delete  FROM  %t  where id=%s', array($this->_table,$did));
	}
	
	
	public function count_all($where='') {
	    return DB::result_first("SELECT count(*) FROM %t %i", array($this->_table,$where));
	}
	
	public function fetch_all_by_limit($f,$startlimit,$ppp,$where='') {
	    return DB::fetch_all("SELECT %i FROM %t %i order by dateline desc LIMIT %d,%d", array($f,$this->_table,$where,$startlimit,$ppp));
	}
	
	public function fetch_first_field_data($field,$where='') {
	    return DB::fetch_first("SELECT %i FROM %t %i", array($field,$this->_table,$where));
	}
	
	public function fetch_mycollect($startlimit,$ppp,$uid='') {
	    return DB::fetch_all("SELECT tc.id as id,tc.jbremark as jbremark FROM  ".DB::table('xiaomy_fraud')." tc left join %t  tcgz ON tcgz.bgid=tc.id WHERE tcgz.uid=%d LIMIT %d,%d", array($this->_table,$uid,$startlimit,$ppp));
	}
	

	

}
//From: Dism��taobao��com
?>