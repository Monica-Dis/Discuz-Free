<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//�Ƿ��ǹ���Ա
$configs = $_G['cache']['plugin']['xiaomy_searchcheat'];

$adminuids = explode(",", $configs['adminuids']);


if(!in_array($_G['uid'], $adminuids)){
	showmessage(lang('plugin/xiaomy_searchcheat', 'tishistr05'));
}

$aop = daddslashes($_GET['aop']);

if($aop == "sh"){
	
	$jbid  =  intval($_GET['jbid']);
	$status = array(
			'status'=>2,
	);
	C::t('#xiaomy_searchcheat#xiaomy_searchcheat')->update(array('id'=>$jbid),$status);
	
	showmessage(lang('plugin/xiaomy_searchcheat', 'tishistr03'),"plugin.php?id=xiaomy_searchcheat:adminop",array(),array('alert'=>'right'));
	
}elseif($aop == "delete"){
	
	$jbid  =  intval($_GET['jbid']);
	
	C::t('#xiaomy_searchcheat#xiaomy_searchcheat')->delete_by_id($jbid);
	
	showmessage(lang('plugin/xiaomy_searchcheat', 'tishistr04'),"plugin.php?id=xiaomy_searchcheat:adminop",array(),array('alert'=>'right'));
	
}else{

	$cur_page=intval(getgpc('page'));
	if($cur_page<1){
		$cur_page=1;
	}
	
	$curUrl="plugin.php?id=xiaomy_searchcheat:adminop";
	$showNum=25;
	$alldata = 	C::t('#xiaomy_searchcheat#xiaomy_searchcheat')->fetch_page_data(($cur_page-1)*$showNum,$showNum);
	$count=C::t('#xiaomy_searchcheat#xiaomy_searchcheat')->count();
	
	$pagenav=multi($count, $showNum, $cur_page, $curUrl);
	
	include template('xiaomy_searchcheat:adminop');

}
//From: Dism_taobao_com
?>