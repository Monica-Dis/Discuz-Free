<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$installsql = <<<EOF
DROP TABLE IF EXISTS cdb_xiaomy_searchcheat;
CREATE TABLE IF NOT EXISTS `cdb_xiaomy_searchcheat` (
  `id`    int(11) unsigned NOT NULL auto_increment,
  `uid`     mediumint(8) unsigned  NOT NULL,
  `username` VARCHAR(30) NOT NULL DEFAULT '',
  `jbtype` char(2) NOT NULL,
  `jbcontent` VARCHAR(300) NOT NULL DEFAULT '',
  `jbremark` VARCHAR(300) NOT NULL DEFAULT '',
  `status` char(2)  NOT NULL,
  `dateline` int(10) DEFAULT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
EOF;
runquery($installsql);
$finish = TRUE;
?>