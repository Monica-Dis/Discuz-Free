<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_xiaomy_searchcheat extends discuz_table
{
	public function __construct() {

		$this->_table = 'xiaomy_searchcheat';
		$this->_pk    = 'id';
		parent::__construct();
	}

	
	public function fetchbyuid($uid)
	{
		return DB::fetch_first('SELECT * FROM  %t where uid=%d', array($this->_table,$uid));
	}
	
		public function fetch_page_data($start=0,$limit=10)
	{
		return DB::fetch_all('SELECT * FROM  %t   order by dateline desc limit %d,%d', array($this->_table,$start,$limit));
	}
	
	
	public function fetch_page_datastatus($start=0,$limit=10)
	{
		return DB::fetch_all('SELECT * FROM  %t where status=2 order by dateline desc  limit %d,%d', array($this->_table,$start,$limit));
	}
	
	public function fetch_page_datastatuscount($start=0,$limit=10)
	{
		return DB::fetch_first('SELECT count(*) as scount FROM  %t where status=2', array($this->_table,$start,$limit));
	}
	
	
	public function fetch_search($searchstr)
	{
		return DB::fetch_all('SELECT * FROM  %t where jbcontent like %s or jbremark like %s', array($this->_table,'%'.$searchstr."%",'%'.$searchstr."%"));
	}
	
	
		public function delete_by_id($did){
		
		return DB::query('delete  FROM  %t  where id=%s', array($this->_table,$did));
	}
	

}
//From: Dism��taobao��com
?>