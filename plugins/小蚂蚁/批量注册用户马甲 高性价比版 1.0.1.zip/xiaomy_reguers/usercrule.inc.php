<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$cp= dhtmlspecialchars($_GET['cp']);

if($cp =="createcc"){
	showtableheader(lang('plugin/xiaomy_reguers', 'usercrulelbms'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=usercrule&identifier=xiaomy_reguers');
	showsetting(lang('plugin/xiaomy_reguers', 'usercrulec07'),'isauto','0','radio',"","",lang('plugin/xiaomy_reguers', 'usercrulec007'));
	showsetting(lang('plugin/xiaomy_reguers', 'usercrulec19'),'isavatar','1','radio',"","",lang('plugin/xiaomy_reguers', 'usercrulec019'));
	
	showsetting(lang('plugin/xiaomy_reguers', 'usercrulec01'),'usernamerule','','textarea',"","",lang('plugin/xiaomy_reguers', 'usercrulec001'));
	showsetting(lang('plugin/xiaomy_reguers', 'usercrulec06'),'createcount','1','text',"","",lang('plugin/xiaomy_reguers', 'usercrulec006'));
	showsetting(lang('plugin/xiaomy_reguers', 'usercrulec02'),'userpassword','123456','text',"","",lang('plugin/xiaomy_reguers', 'usercrulec002'));
	showsetting(lang('plugin/xiaomy_reguers', 'usercrulec13'),'regmail','@163.com','text',"","",lang('plugin/xiaomy_reguers', 'usercrulec013'));
	
	showsubmit('createcc');
	showformfooter();
	showtablefooter();/*Dism��taobao��com*/
	exit;
}
if(submitcheck('createcc')) {
	
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		cpmsg('error');
	}
	
	loaducenter();
	$isauto = intval($_GET['isauto']);
	$isavatar = intval($_GET['isavatar']);
	if(!$isauto){
		$usernamerule = trim(dhtmlspecialchars($_GET['usernamerule']));
		$usernames = explode(",",$usernamerule);
	}else{
		$createcount = intval($_GET['createcount']);
		$usernames  = random_str($createcount);
	}
	if(!$usernames[0]){
		cpmsg(lang('plugin/xiaomy_reguers', 'usercrulec12'),'',"error");
	}
	$userpassword =  trim(dhtmlspecialchars($_GET['userpassword']));
	$regmail = trim(dhtmlspecialchars($_GET['regmail']));
	
	foreach($usernames as $userv){
		//�ж��û����Ƿ���Ч
		$regemail = uniqid() . $regmail;
		$username = addslashes($userv);
		$uid = uc_user_register($username, $userpassword, $regemail);
		if ($uid <= 0) {
			continue;
		}
		$mpassword = md5(random(10));
		$num++;
		$ip = get_rand_ip();
		C::t('common_member')->insert($uid,$username, $mpassword, $regemail,$ip, 10, '', 0);
		//дͷ��
		//���һ��ͷ��
		
		if($isavatar){
			$imgsrc = C::t('#xiaomy_reguers#xiaomy_reguers_avatar')->fetch_roundavater();
			if(!$imgsrc['avatarpath']){
				$avatar = 'default';
			}else{
				$avatarimg = $_G['siteurl'].$imgsrc['avatarpath'];
				$avatar = avatar_by_uid($uid,$avatarimg);
			}
		}else{
			$avatar = 'default';
		}
		$regUser = array();
		$regUser['reguid'] = $uid;
		$regUser['regusername'] = $username;
		$regUser['regip'] = $ip;
		$regUser['reg_avater_pic'] = $avatar;
		$regUser['regpassword'] = $userpassword;
		$regUser['dateline'] = time();
		
		DB::insert('xiaomy_reguers', $regUser);
	}
	cpmsg("<strong>".lang('plugin/xiaomy_reguers', 'xiaomystr19').$num."</strong>", 'action=plugins&operation=config&do='.$pluginid.'&pmod=usercrule&identifier=xiaomy_reguers', 'succeed');
}
	$cur_page=intval(getgpc('page'));
	if($cur_page<1){
		$cur_page=1;
	}
	$curUrl="admin.php?action=plugins&operation=config&do=".$pluginid."&identifier=xiaomy_reguers&pmod=usercrule";
	$createcc = "&nbsp;&nbsp;&nbsp;<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=usercrule&identifier=xiaomy_reguers&cp=createcc&formhash=".formhash()."'><strong style='color:red;'>[".lang('plugin/xiaomy_reguers', 'usercrulepl')."]</strong></a>";
	showtableheader(lang('plugin/xiaomy_reguers', 'usercrulelbmc').$createcc);

	showtablerow("",'',array(
		lang('plugin/xiaomy_reguers', 'usercrulestr3'),
		lang('plugin/xiaomy_reguers', 'usercrulestr4'),
		"<strong>".lang('plugin/xiaomy_reguers', 'usercrulec17')."</strong>",
		lang('plugin/xiaomy_reguers', 'usercrulestr7'),
		lang('plugin/xiaomy_reguers', 'usercrulestr5'),
		lang('plugin/xiaomy_reguers', 'usercrulestr6'),
		lang('plugin/xiaomy_reguers', 'astr09'),
	));

	$showNum=15;
	$alldata = 	C::t('#xiaomy_reguers#xiaomy_reguers')->fetch_page_data(($cur_page-1)*$showNum,$showNum);
	$count=C::t('#xiaomy_reguers#xiaomy_reguers')->count();
	 
	foreach($alldata as $value){
			$value['dateline']  = dgmdate($value['dateline']);
			$sxstr  = "<a target=blank href='".ADMINSCRIPT."?action=members&operation=edit&uid=".$value['reguid']."'>".lang('plugin/xiaomy_reguers', 'usercrulec11')."</a>";
			
			if($value['reg_avater_pic'] == 'default'){
				$value['reg_avater_pic']  = lang('plugin/xiaomy_reguers', 'usercrulec18');
			}else{
				$value['reg_avater_pic']  = "<img width=50 height=50 src=".$value['reg_avater_pic']."></img>";
			}
			
			showtablerow("",'',array(
				$value['reguid'],
				"<a target=blank href='home.php?mod=space&uid=".$value['reguid']."'>".$value['regusername']."</a>",
				$value['regpassword'],
				$value['reg_avater_pic'],
				$value['regip'],
				$value['dateline'],
				$sxstr
				)
			);
	}
	$pagenav=multi($count, $showNum, $cur_page, $curUrl);
	echo $pagenav;
	showtablefooter();/*Dism��taobao��com*/
	
	
function random_str($length){
    //����һ������ ��дӢ����ĸ, СдӢ����ĸ, ���� ������
    $arr = array_merge(range(0, 9), range('a', 'z'), range('A', 'Z'));
    $str = '';
    $arr_len = count($arr);
    $usernames = array();
    for ($ii = 0; $ii < $length; $ii++){
	    for ($i = 0; $i < rand(3,15); $i++)
	    {
	        $rand = mt_rand(0, $arr_len-1);
	        $str.=$arr[$rand];
	    }
	    array_push($usernames,$str);
	    $str = "";
    }
    return $usernames;
}
//ip�����
function get_rand_ip(){
  $arr_1 = array("218","218","66","66","218","218","60","60","202","204","66","66","66","59","61","60","222","221","66","59","60","60","66","218","218","62","63","64","66","66","122","211");
  $randarr= mt_rand(0,count($arr_1));
  $ip1id = $arr_1[$randarr];
  $ip2id=  round(rand(600000,  2550000)  /  10000);
  $ip3id=  round(rand(600000,  2550000)  /  10000);
  $ip4id=  round(rand(600000,  2550000)  /  10000);
  return  $ip1id . "." . $ip2id . "." . $ip3id . "." . $ip4id;
}

//ͷ��洢
function avatar_by_uid($uid, $img) {
	global $_G;
	C::t('common_member')->update($uid, array('avatarstatus' => 1)); 
	
	$uc_server = basename($_G['setting']['ucenterurl']); 
	
	$dir = DISCUZ_ROOT . './' . $uc_server . '/data/avatar'; 
	
	$uid = sprintf("%09d", $uid);
	
	$dir1 = substr($uid, 0, 3);
	
	$dir2 = substr($uid, 3, 2);
	
	$dir3 = substr($uid, 5, 2);
	
	!is_dir($dir . '/' . $dir1) && mkdir($dir . '/' . $dir1, 0777);
	
	!is_dir($dir . '/' . $dir1 . '/' . $dir2) && mkdir($dir . '/' . $dir1 . '/' . $dir2, 0777);
	
	!is_dir($dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3) && mkdir($dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3, 0777);
	
	$avatar_small = $dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3 . '/' . substr($uid, -2) . "_avatar_small.jpg";
	
	$avatar_middle = $dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3 . '/' . substr($uid, -2) . "_avatar_middle.jpg";
	
	$avatar_big = $dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3 . '/' . substr($uid, -2) . "_avatar_big.jpg";
	
	$imgData = dfsockopen($img);
	
	file_put_contents($avatar_small, $imgData);
	
	file_put_contents($avatar_middle, $imgData);
	
	file_put_contents($avatar_big, $imgData);
	
	$avatar_img = $_G['siteurl'] . $uc_server . '/data/avatar' . '/' . $dir1 . '/' . $dir2 . '/' . $dir3 . '/' . substr($uid, -2) . "_avatar_middle.jpg";
	
	return $avatar_img;
}
?>