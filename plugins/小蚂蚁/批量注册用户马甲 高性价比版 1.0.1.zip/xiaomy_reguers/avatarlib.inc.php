<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$cp= dhtmlspecialchars($_GET['cp']);

if($cp=='delete'){
	if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
		cpmsg('error');
	}
	$xiaomyid = intval($_GET['xiaomyid']);
	$avatar = C::t('#xiaomy_reguers#xiaomy_reguers_avatar')->fetch_by_cardno($xiaomyid);
	C::t('#xiaomy_reguers#xiaomy_reguers_avatar')->delete_by_id($xiaomyid);
	//ɾ��ͼƬ
	$filename = DISCUZ_ROOT.$avatar['avatarpath'];
	if(file_exists($filename)){  
         unlink($filename);  
    }
	cpmsg("<strong>".lang('plugin/xiaomy_reguers', 'xiaomystr0019')."</strong>", 'action=plugins&operation=config&do='.$pluginid.'&pmod=avatarlib&identifier=xiaomy_reguers', 'succeed');
	
}else if($cp =="createcc"){
	showtableheader(lang('plugin/xiaomy_reguers', 'moni_data'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=avatarlib&identifier=xiaomy_reguers',"enctype=multipart/form-data");
	showsetting(lang('plugin/xiaomy_reguers', 'xiaomystr13'),'avatarpic','','file',"","",lang('plugin/xiaomy_reguers', 'xiaomystr013'));
	showsubmit('createcc');
	showformfooter();
	showtablefooter();/*Dism��taobao��com*/
	exit;
}

if(submitcheck('createcc')) {
		if(empty($_GET['formhash']) || $_GET['formhash'] != formhash() ){
			cpmsg('error');
		}
		if(!$_FILES['avatarpic']['name']){
			cpmsg(lang('plugin/xiaomy_reguers', 'avatarstr01'),'','error');
		}
		$uploadavatar = uploadavatar($_FILES['avatarpic'],date('YmdHis').rand(100,9999));		
		if($uploadavatar == 1){
			cpmsg(lang('plugin/xiaomy_reguers', 'avatarstr02'),'','error');
		}elseif($uploadavatar == 2){
			cpmsg(lang('plugin/xiaomy_reguers', 'avatarstr03'),'','error');
		}
		$avatardata = array(
			'avatarpath'=>$uploadavatar,
		);
		DB::insert('xiaomy_reguers_avatar',$avatardata);
		cpmsg("<strong>".lang('plugin/xiaomy_reguers', 'xiaomystr199').$num."</strong>", 'action=plugins&operation=config&do='.$pluginid.'&pmod=avatarlib&identifier=xiaomy_reguers', 'succeed');
}

	$cur_page=intval(getgpc('page'));
	if($cur_page<1){
		$cur_page=1;
	}

	$curUrl="admin.php?action=plugins&operation=config&do=".$pluginid."&identifier=xiaomy_reguers&pmod=avatarlib";
	
	$createcc = "&nbsp;&nbsp;&nbsp;<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&pmod=avatarlib&identifier=xiaomy_reguers&cp=createcc&formhash=".formhash()."'><strong style='color:red;'>[".lang('plugin/xiaomy_reguers', 'info09')."]</strong></a>";

	showtableheader(lang('plugin/xiaomy_reguers', 'kminfo').$createcc
	);
	

	showtablerow("",'',array(
		lang('plugin/xiaomy_reguers', 'astr02'),
		lang('plugin/xiaomy_reguers', 'astrnew03'),
		lang('plugin/xiaomy_reguers', 'astrnew10'),
		lang('plugin/xiaomy_reguers', 'astr09'),
		
			
));

	$showNum=15;
	$alldata = 	C::t('#xiaomy_reguers#xiaomy_reguers_avatar')->fetch_page_data(($cur_page-1)*$showNum,$showNum);
	$count=C::t('#xiaomy_reguers#xiaomy_reguers_avatar')->count();
	 
	foreach($alldata as $value){
			$sxstr  = "&nbsp;&nbsp;&nbsp;<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&xiaomyid=".$value['id']."&pmod=avatarlib&identifier=xiaomy_reguers&cp=delete&formhash=".formhash()."'><strong style='color:red;'>[".lang('plugin/xiaomy_reguers', 'xiaomystr18')."]</strong></a>";
			showtablerow("",'',array(
				$value['id'],
				"<img width=50 height=50 src=".$value['avatarpath']."></img>",
				$value['avatarpath'],
				$sxstr
				)
			);
	}
	$pagenav=multi($count, $showNum, $cur_page, $curUrl);
	echo $pagenav;
	showtablefooter();/*Dism��taobao��com*/
	
	
function uploadavatar($filesobj,$picname){
	$path = 'source/plugin/xiaomy_reguers/avatarpic';
	if(!is_dir($path)) mkdir($path);
	$fmpath = "";
	if ($filesobj['size'] < (2*1024*1024)){
		$filetype = pathinfo($filesobj['name'], PATHINFO_EXTENSION);
		if( in_array($filetype, array('jpg','png','gif','jpeg')))
		{
			$fmpath = $path.'/'.$picname.'.'.$filetype;
			 move_uploaded_file($filesobj['tmp_name'], $fmpath);
		}else{
			return 1;
		}
	}else{
		return 2;
	}
	return  $fmpath;
}
?>