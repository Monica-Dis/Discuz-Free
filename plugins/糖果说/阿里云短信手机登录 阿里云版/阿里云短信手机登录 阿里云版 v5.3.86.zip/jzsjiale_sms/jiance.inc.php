<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function unicodeDecode($unicode_str)
{
    $json = '{"str":"' . $unicode_str . '"}';
    $arr = json_decode($json, true);
    if (empty($arr)) return '';
    global $_G;
    if($_G['charset'] == "gbk"){
        $arr['str'] = diconv($arr['str'],'UTF-8','GBK');
    }

    return $arr['str'];

}


$lang1 = unicodeDecode("\u201c\u963f\u91cc\u4e91\u77ed\u4fe1\u624b\u673a\u767b\u5f55\u201d\u63d2\u4ef6\u8fd0\u884c\u73af\u5883\u68c0\u6d4b");
$lang2 = unicodeDecode('\u73af\u5883\u540d\u79f0');
$lang3 = unicodeDecode('\u914d\u7f6e\u8981\u6c42');
$lang4 = unicodeDecode('\u5f53\u524d\u914d\u7f6e');
$lang5 = unicodeDecode('\u68c0\u6d4b\u7ed3\u679c');
$lang6 = unicodeDecode('\u0064\u0069\u0073\u0063\u0075\u007a\u7248\u672c');
$lang7 = unicodeDecode('\u0050\u0048\u0050\u7248\u672c');
$lang8 = unicodeDecode('\u5927\u4e8e\u7b49\u4e8e\u0035\u002e\u0033\uff0c\u5efa\u8bae\u0035\u002e\u0035\u4ee5\u4e0a');
$lang9 = unicodeDecode('\u0063\u0075\u0072\u006c\u6269\u5c55');
$lang10 = unicodeDecode('\u0070\u0068\u0070\u002e\u0069\u006e\u0069\u914d\u7f6e\u6587\u4ef6\u4e2d\u5fc5\u987b\u542f\u7528\u0063\u0075\u0072\u006c\u6269\u5c55');
$lang11 = unicodeDecode('\u006f\u0070\u0065\u006e\u0073\u0073\u006c\u6269\u5c55');
$lang12 = unicodeDecode('\u0070\u0068\u0070\u002e\u0069\u006e\u0069\u914d\u7f6e\u6587\u4ef6\u4e2d\u5fc5\u987b\u542f\u7528\u006f\u0070\u0065\u006e\u0073\u0073\u006c\u6269\u5c55');
$lang13 = unicodeDecode('\u0070\u0068\u0070\u5f00\u542f\u0063\u0075\u0072\u006c\u548c\u006f\u0070\u0065\u006e\u0073\u0073\u006c\u65b9\u6cd5\uff1a');
$lang14 = unicodeDecode('\u4ee5\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u7cfb\u7edf\u73af\u5883\u4e3a\u4f8b');
$lang15 = unicodeDecode('\u2460\u0020\u6253\u5f00\u0070\u0068\u0070\u002e\u0069\u006e\u0069\uff0c\u627e\u5230\u5982\u4e0b\u4ee3\u7801\uff1a\u003b\u0065\u0078\u0074\u0065\u006e\u0073\u0069\u006f\u006e\u003d\u0070\u0068\u0070\u005f\u0063\u0075\u0072\u006c\u002e\u0064\u006c\u006c\u0020\u548c\u0020\u003b\u0065\u0078\u0074\u0065\u006e\u0073\u0069\u006f\u006e\u003d\u0070\u0068\u0070\u005f\u006f\u0070\u0065\u006e\u0073\u0073\u006c\u002e\u0064\u006c\u006c\u0020\uff0c\u53bb\u6389\u524d\u9762\u7684\u5206\u53f7\u201c\u003b\u201d\u3002');
$lang16 = unicodeDecode('\u2461\u0020\u68c0\u67e5\u0070\u0068\u0070\u002e\u0069\u006e\u0069\u7684\u0065\u0078\u0074\u0065\u006e\u0073\u0069\u006f\u006e\u005f\u0064\u0069\u0072\u503c\u662f\u54ea\u4e2a\u76ee\u5f55\uff0c\u68c0\u67e5\u8be5\u76ee\u5f55\u6709\u65e0\u0070\u0068\u0070\u005f\u0063\u0075\u0072\u006c\u002e\u0064\u006c\u006c\u3001\u0070\u0068\u0070\u005f\u006f\u0070\u0065\u006e\u0073\u0073\u006c\u002e\u0064\u006c\u006c\uff0c\u5982\u679c\u6ca1\u6709\u7684\u8bf7\u4e0b\u8f7d\u0070\u0068\u0070\u005f\u0063\u0075\u0072\u006c\u002e\u0064\u006c\u006c\u3001\u0070\u0068\u0070\u005f\u006f\u0070\u0065\u006e\u0073\u0073\u006c\u002e\u0064\u006c\u006c\u3002');
$lang17 = unicodeDecode('\u2462\u0020\u91cd\u542f\u4e0b\u0061\u0070\u0061\u0063\u0068\u0065\u6216\u8005\u0069\u0069\u0073\u670d\u52a1\u5668\u3002');
$lang18 = unicodeDecode('\u2463\u0020\u53ef\u4ee5\u4f7f\u7528\u0070\u0068\u0070\u0069\u006e\u0066\u006f\u0028\u0029\u51fd\u6570\u67e5\u770b\u8be6\u7ec6\u914d\u7f6e\u4fe1\u606f\uff0c\u786e\u8ba4\u0063\u0075\u0072\u006c\u3001\u006f\u0070\u0065\u006e\u0073\u0073\u006c\u5df2\u7ecf\u5f00\u542f\u3002');
$lang19 = unicodeDecode('\u66f4\u8be6\u7ec6\u7684\u6559\u7a0b\uff0c\u8bf7\u81ea\u884c\u767e\u5ea6\u67e5\u627e\uff0c\u6216\u8054\u7cfb\u670d\u52a1\u5668\u7a7a\u95f4\u5546\u534f\u52a9\u89e3\u51b3\u3002');
$langzhu = unicodeDecode('\u6ce8\uff1a\u68c0\u6d4b\u7ed3\u679c\u4e3a\u201c\u006f\u006b\u201d\u65f6\u8868\u793a\u5f53\u524d\u68c0\u6d4b\u9879\u76ee\u7b26\u5408\u8981\u6c42\uff0c\u4e3a\u201c\u0065\u0072\u0072\u006f\u0072\u201d\u65f6\u8868\u793a\u5f53\u524d\u68c0\u6d4b\u9879\u76ee\u4e0d\u7b26\u5408\u8981\u6c42\u3002');


@include_once DISCUZ_ROOT.'./source/discuz_version.php';
$discuzversion = DISCUZ_VERSION;
$discuzversion_result = in_array($discuzversion,array('X2.5','X3','X3.1','X3.2','X3.3','X3.4','F1.0'))?"<span style='color:green'>ok</span>":"<span style='color:red'>error</span>";

$phpversion = phpversion();
$version = explode('.', $phpversion);
$phpversiontmp = $version[0].'.'.$version[1];
$phpversion_result = ($phpversiontmp>5.3)?"<span style='color:green'>ok</span>":"<span style='color:red'>error</span>";


if(function_exists('curl_init') && function_exists('curl_version')){
    $v = curl_version();
    $curlversion = unicodeDecode('\u5df2\u542f\u7528').' curl_version:'.$v['version'];
    $curlversion_result = "<span style='color:green'>ok</span>";
}else{
    $curlversion = unicodeDecode('\u672a\u542f\u7528');
    $curlversion_result = "<span style='color:red'>error</span>";
}

if(function_exists('openssl_random_pseudo_bytes')){
    $opensslversion = unicodeDecode('\u5df2\u542f\u7528');
    $opensslversion_result = "<span style='color:green'>ok</span>";
}else{
    $opensslversion = unicodeDecode('\u672a\u542f\u7528');
    $opensslversion_result = "<span style='color:red'>error</span>";
}

echo <<<EOF
<style>
.table3_3 table {
	width:100%;
	margin:15px 0
}
.table3_3 th {
	background-color:#87CEFA;
	color:#000000
}
.table3_3,.table3_3 th,.table3_3 td
{
	font-size:0.95em;
	text-align:center;
	padding:4px;
	border:1px solid #5fbdf8;
	border-collapse:collapse
}
.table3_3 tr:nth-child(odd){
	background-color:#d7eefd;
}
.table3_3 tr:nth-child(even){
	background-color:#fdfdfd;
}
</style>
<table class=table3_3>
<tr>
	<th colspan="4">{$lang1}</th>
</tr>
<tr>
	<th>{$lang2}</th><th>{$lang3}</th><th>{$lang4}</th><th>{$lang5}</th>
</tr>
<tr>
	<td>{$lang6}</td><td>X2.5,X3,X3.1,X3.2,X3.3,X3.4,X3.5,F1.0</td><td>{$discuzversion}</td><td>{$discuzversion_result}</td>
</tr>
<tr>
	<td>{$lang7}</td><td>{$lang8}</td><td>{$phpversion}</td><td>{$phpversion_result}</td>
</tr>
	<tr>
	<td>{$lang9}</td><td>{$lang10}</td><td>{$curlversion}</td><td>{$curlversion_result}</td>
</tr>
<tr>
	<td>{$lang11}</td><td>{$lang12}</td><td>{$opensslversion}</td><td>{$opensslversion_result}</td>
</tr>
</table>
<br/>
<strong style="color:red;">{$langzhu}</strong>
<br/>
<br/>
<strong>{$lang13}</strong>
<br/>
<br/>
{$lang14}
<br/>
{$lang15}
<br/>
{$lang16}
<br/>
{$lang17}
<br/>
{$lang18}
<br/>
<br/>
{$lang19}
EOF;

?>