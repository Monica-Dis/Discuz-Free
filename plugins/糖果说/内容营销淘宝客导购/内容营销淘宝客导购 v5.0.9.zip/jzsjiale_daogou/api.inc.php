<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';
$utils = new Utils();

global $_G;

$act = daddslashes(trim($_GET['a']));

if(!in_array($act, array('delunusedimg', 'category', 'shangpin', 'forum', 'webshangpin','webshangpinv2', 'webspcategory','searchshangpin','searchtiezi','webshangpinbycatelevel1','getcomments','addcomment','relationrec','publisharticle','getDraft','gettidaodehaowu','getxiangguanhaowu','saveDraft','sendseccode','phoneregister','phonelogin','phonelogout','jsapi', 'souquan', 'souquanci', 'gettkl'))) {
        showmessage(array('code' => 100));
        dexit();
}

if($act == 'category'){
    $all = daddslashes(trim($_GET['all']));
    $pid = daddslashes(trim($_GET['pid']));
    $status = daddslashes(trim($_GET['status']));
    
    if(empty($pid)){
        $pid = 0;
    }
    if(empty($status)){
        $status = 1;
    }
    
    if($all){
        $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
    }else{
        $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($pid,$status);
    }
  
    $category = dhtmlspecialchars($category);
    if(!empty($category)){
        showmessage(array('code' => 200,'data' => $category));
        dexit();
    }else{
        showmessage(array('code' => 110));
        dexit();
    }
    
}elseif($act == 'shangpin'){
    $status = daddslashes(trim($_GET['status']));
    $all = daddslashes(trim($_GET['all']));
    $categoryid = daddslashes(trim($_GET['categoryid']));
    $title = daddslashes(trim($_GET['title']));
    
    if(empty($status)){
        $status = 1;
    }
    
    $page = intval($_GET['page']);
    $page = $page > 0 ? $page : 1;
    $pagesize = 20;
    $start = ($page - 1) * $pagesize;
    
    $shangpin = array();
    $count = 0;
    $currurl = "";
    
    
    if($all){
        $shangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->range_by_title("",$start,$pagesize,'DESC',$status);
        $count = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->count_by_title("",$status);
        $currurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:api&a=shangpin&all=1&status='.$status;
    }else{
        if(!empty($categoryid)){
            $shangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->range_by_categoryid($categoryid,$start,$pagesize,'DESC',$status);
            $count = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->count_by_categoryid($categoryid,$status);
            $currurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:api&a=shangpin&categoryid='.$categoryid.'&status='.$status;
            
        }elseif(!empty($title)){
            
            if($_G['charset'] == 'gbk') {
                $title = diconv($title,'UTF-8','GB2312');
            }
            
            $shangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->range_by_title($title,$start,$pagesize,'DESC',$status);
            $count = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->count_by_title($title,$status);
            $currurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:api&a=shangpin&title='.$title.'&status='.$status;
        }
        
    }

    
    $countpage = ($count%$pagesize > 0)?ceil($count/$pagesize):$count/$pagesize;
    
    $fanyehtml = $utils->show_array($countpage, $currurl);
    
    $shangpin = dhtmlspecialchars($shangpin);
    $count = dhtmlspecialchars($count);
    $fanyehtml = dhtmlspecialchars($fanyehtml);
    $fanyehtml = htmlspecialchars_decode($fanyehtml);
    if(!empty($shangpin)){
        showmessage(array('code' => 200,'data' => $shangpin,'count' => $count,'fanye' => $fanyehtml));
        dexit();
    }else{
        showmessage(array('code' => 110));
        dexit();
    }
    
}elseif($act == 'forum'){
    
    $extend = intval($_GET['extend']);
    $quanbu = intval($_GET['quanbu']);
    $page = intval($_GET['page']);
    $pagesize = intval($_GET['pagesize']);
    $extend = $extend > 0 ? $extend : 0;
    $quanbu = $quanbu > 0 ? $quanbu : 0;
    $page = $page > 0 ? $page : 1;
    $pagesize = $pagesize > 0 ? $pagesize : 10;
    
  
    $tiezicategory = "";
    
    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezicategory.php')){
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezicategory.php';
    
        $tiezicategory = $tbktiezicategory;
    
    }else{
        $tbktiezicategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->getall();
    
        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_tiezicategory', getcachevars(array('tbktiezicategory' => $tbktiezicategory)));
    
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezicategory.php';
        $tiezicategory = $tbktiezicategory;
    
    }
    
    if($extend<=0){
        foreach($tiezicategory as $tzkey => $tzvalue){
            if($tzvalue['status'] == 1 && $tzvalue['pid'] == 0){
                $extend = $tzvalue['id'];
                break;
            }
        }
    }
    
    
    
    $tiezi = "";
    
    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezi.php')){
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezi.php';
    
        $tiezi = $daogoutiezi;
    
    }else{
        $daogoutiezi = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->getall();
    
        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_tiezi', getcachevars(array('daogoutiezi' => $daogoutiezi)));
    
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezi.php';
        $tiezi = $daogoutiezi;
    
    }
    
    
    $homefisrtlist = array();
    if($quanbu>0){
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $g_dulixiewenzhangfid = $_config['g_dulixiewenzhang'];
       
        $allposts = array();
        $allposts = C::t('forum_thread')->fetch_all_by_fid_displayorder($g_dulixiewenzhangfid, 0);
   
        $homefisrttids = $utils->searchReturnAllByRet('tid',$allposts);
  
    }else{
        $homefisrttids = $utils->searchReturnStrByCatePid($extend,'tiezicategoryid','tid',$tiezi,$tiezicategory);
    }
   
    $homefisrtlist = $utils->get_forumdata($homefisrttids,$page,$pagesize,0);
   
   
    require_once(DISCUZ_ROOT."./source/function/function_post.php");
    foreach($homefisrtlist as $k=>$v){
        
        //20170616start
        if(preg_match('/\s?\[jzsjiale_daogou_post\](.*?)\[\/jzsjiale_daogou_post\]\s?/is', $homefisrtlist[$k]['message'], $matches)) {
            $m1 = $matches[1];
            if ($_G['charset'] == "gbk") {
                $m1 = diconv($m1,'GBK', 'UTF-8');
            }
            $content1 = html_entity_decode($m1);
            $content = json_decode($content1,TRUE);
            $content_list = $content['content_list'];
             
            $postmessage = "";
            foreach ($content_list as $key => $value){
                if($content_list[$key]['type'] == 2){
                    $text_content = diconv($content_list[$key]['text_content'], 'UTF-8','GBK');
                    $postmessage .= '<p class="desc">'.$text_content.'</p>';
                }
            }
            if ($_G['charset'] == "gbk") {
            
            }else{
                $postmessage = diconv($postmessage,'GBK', 'UTF-8');
            }
            $homefisrtlist[$k]['message'] = $postmessage;
        }
        //20170616end
        
        if ($_G['charset'] == "gbk") {
            $homefisrtlist[$k]['subject'] = diconv(cutstr($homefisrtlist[$k]['subject'],190),'GBK','UTF-8');
            $homefisrtlist[$k]['author']=diconv(messagecutstr($homefisrtlist[$k]['author'],190),'GBK','UTF-8');
            $homefisrtlist[$k]['message']=diconv(messagecutstr($homefisrtlist[$k]['message'],190),'GBK','UTF-8');
        }else{
            $homefisrtlist[$k]['subject']=cutstr($homefisrtlist[$k]['subject'],190);
            $homefisrtlist[$k]['author']=messagecutstr($homefisrtlist[$k]['author'],190);
            $homefisrtlist[$k]['message']=messagecutstr($homefisrtlist[$k]['message'],190);
        }
        
        $homefisrtlist[$k]['dateline']=date('Y-m-d H:i:s',$homefisrtlist[$k]['dateline']);
        
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $g_isopenyuancheng = $_config['g_isopenyuancheng'];
        $g_yuanchengurl = $_config['g_yuanchengurl'];
        
        $tid = $v['tid'];
        $cover_tmp=getCover($tid);
        $pic=$cover_tmp['attachment'];
        $isremote=$cover_tmp['remote'];
        if(!empty($pic)){
            if($g_isopenyuancheng && !empty($g_yuanchengurl) && $isremote){
                $homefisrtlist[$k]['cover']=$g_yuanchengurl.'/forum/'.$pic;
            }else{
                $homefisrtlist[$k]['cover']='data/attachment/forum/'.$pic;
            }
            
        }else{
            $homefisrtlist[$k]['cover']= $_G['jzsjiale_tpl_daogou']['defaultimg'];//$utils->searchArrayByField('defaultimg',$daogouoptions);
        }
        
        if(empty($homefisrtlist[$k]['cover'])){
            $homefisrtlist[$k]['cover']='source/plugin/jzsjiale_daogou/static/images/daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/nopic.jpg';
        }
    }
    //var_dump($homefisrtlist);exit;
    
    $homefisrtlist = dhtmlspecialchars($homefisrtlist);
    header("Content-Type: text/html; charset=".$_G['charset']);
    if(!empty($homefisrtlist)){
        echo json_encode(array('code' => 200,'data' => $homefisrtlist));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'webshangpin'){
    
    $level = intval($_GET['level']);
    $cateid = intval($_GET['cateid']);
    $page = intval($_GET['page']);
    $pagesize = intval($_GET['pagesize']);
    
    $page = $page > 0 ? $page : 1;
    $pagesize = $pagesize > 0 ? $pagesize : 21;

    $shangpin = "";

    
    if(!empty($cateid)){
        if(!empty($level) && $level == 2){
            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }else{
                $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $cateid);

                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_shangpin_'.$cateid, getcachevars(array('tbkshangpin_'.$cateid => $shangpin_cache_tmp)));

                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }
            //$shangpin1 = $utils->search($cateid,'categoryid',$tbkshangpin);
            $shangpin1 = $tbkshangpin;
            $shangpin2 = array();
            $spcategory = "";
    
            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
    
                $spcategory = $tbkcategory;
    
            }else{
                $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
    
                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));
    
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                $spcategory = $tbkcategory;
    
            }
    
            $childcateid = $utils->searchArrayByPid($cateid,$spcategory);
            foreach ($childcateid as $childcateiddata){
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcateiddata['id'].'.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcateiddata['id'].'.php';
                    $shangpintmp = ${'tbkshangpin_'.$childcateiddata['id']};

                }else{
                    $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $childcateiddata['id']);

                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_shangpin_'.$childcateiddata['id'], getcachevars(array('tbkshangpin_'.$childcateiddata['id'] => $shangpin_cache_tmp)));

                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcateiddata['id'].'.php';
                    $shangpintmp = ${'tbkshangpin_'.$childcateiddata['id']};

                }
                //$shangpintmp = $utils->search($childcateiddata['id'],'categoryid',$tbkshangpin);
                if(!empty($shangpintmp)){
                    $shangpin2 = array_merge($shangpin2, $shangpintmp);
                }
    
            }
    
    
            if(empty($shangpin1)){
                $shangpin = $shangpin2;
            }else{
                $shangpin = array_merge($shangpin1, $shangpin2);
            }
    
    
    
        }else{
            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }else{
                $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $cateid);

                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_shangpin_'.$cateid, getcachevars(array('tbkshangpin_'.$cateid => $shangpin_cache_tmp)));

                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }
            //$shangpin = $utils->search($cateid,'categoryid',$tbkshangpin);
            $shangpin = $tbkshangpin;
        }
    }else{

        $alltbkshangpin = array();
        $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

        foreach ($category as $key => $value){

            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php';
                $tbkshangpin = ${'tbkshangpin_'.$value["id"]};

            }else{
                $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $value["id"]);

                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));

                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php';
                $tbkshangpin = ${'tbkshangpin_'.$value["id"]};

            }

            if(!empty($tbkshangpin) && $tbkshangpin != null){
                $alltbkshangpin = array_merge($alltbkshangpin, $tbkshangpin);
            }


        }

        $shangpin = $alltbkshangpin;
    }
    
    
    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    
    $shangpin = $utils->page_array($pagesize,$page,$shangpin,0);
    require_once(DISCUZ_ROOT."./source/function/function_post.php");
    foreach($shangpin as $k=>$v){
        if ($_G['charset'] == "gbk") {
            $shangpin[$k]['title'] = diconv(cutstr($shangpin[$k]['title'],190),'GBK', 'UTF-8' );
            $shangpin[$k]['tkl'] = diconv($shangpin[$k]['tkl'],'GBK', 'UTF-8');
            $shangpin[$k]['tklsimple'] = diconv($shangpin[$k]['tklsimple'],'GBK', 'UTF-8');
            $shangpin[$k]['couponinfo'] = diconv($shangpin[$k]['couponinfo'],'GBK', 'UTF-8');
        }else{
            $shangpin[$k]['title']=cutstr($shangpin[$k]['title'],190);
            $shangpin[$k]['tkl']=$shangpin[$k]['tkl'];
            $shangpin[$k]['tklsimple']=$shangpin[$k]['tklsimple'];
            $shangpin[$k]['couponinfo']=$shangpin[$k]['couponinfo'];
        }
    
        if($_config['g_spneilian']){
            $shangpin[$k]['url'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$shangpin[$k]['id'];
            $shangpin[$k]['youhuiquan'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$shangpin[$k]['id'];
        }
        
        if(empty($shangpin[$k]['img'])){
            $shangpin[$k]['img']='source/plugin/jzsjiale_daogou/static/images/daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/spnopic.jpg';
        }
    }
    
    //var_dump($shangpin);exit;
    $shangpin = dhtmlspecialchars($shangpin);
    header("Content-Type: text/html; charset=".$_G['charset']);
    if(!empty($shangpin)){
        echo json_encode(array('code' => 200,'data' => $shangpin));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'webshangpinv2'){
    
    $level = intval($_GET['level']);
    $cateid = intval($_GET['cateid']);
    $sort = intval($_GET['sort']);
    $page = intval($_GET['page']);
    $pagesize = intval($_GET['pagesize']);
    
    $page = $page > 0 ? $page : 1;
    $pagesize = $pagesize > 0 ? $pagesize : 20;

    $shangpin = "";

    
    
    if(!empty($cateid)){
        if(!empty($level) && $level == 1){
            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }else{
                $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $cateid);

                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_shangpin_'.$cateid, getcachevars(array('tbkshangpin_'.$cateid => $shangpin_cache_tmp)));

                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }
            //$shangpin1 = $utils->search($cateid,'categoryid',$tbkshangpin);
            $shangpin1 = $tbkshangpin;
            $shangpin2 = array();
            $shangpin3 = array();
            $spcategory = "";
    
            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
    
                $spcategory = $tbkcategory;
    
            }else{
                $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
    
                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));
    
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                $spcategory = $tbkcategory;
    
            }
    
            $childcateid = $utils->searchArrayByPid($cateid,$spcategory);
            foreach ($childcateid as $childcateiddata){
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcateiddata['id'].'.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcateiddata['id'].'.php';
                    $shangpintmp = ${'tbkshangpin_'.$childcateiddata['id']};

                }else{
                    $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $childcateiddata['id']);

                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_shangpin_'.$childcateiddata['id'], getcachevars(array('tbkshangpin_'.$childcateiddata['id'] => $shangpin_cache_tmp)));

                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcateiddata['id'].'.php';
                    $shangpintmp = ${'tbkshangpin_'.$childcateiddata['id']};

                }
                //$shangpintmp = $utils->search($childcateiddata['id'],'categoryid',$tbkshangpin);
                //$shangpintmp = $tbkshangpin;
                if(!empty($shangpintmp)){
                    $shangpin2 = array_merge($shangpin2, $shangpintmp);
                }
    
                //shangpin3 start
                $child3cateid = $utils->searchArrayByPid($childcateiddata['id'],$spcategory);
                foreach ($child3cateid as $child3cateiddata){
                    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$child3cateiddata['id'].'.php')){
                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$child3cateiddata['id'].'.php';
                        $shangpintmp3 = ${'tbkshangpin_'.$child3cateiddata['id']};

                    }else{
                        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $child3cateiddata['id']);

                        require_once libfile('function/cache');
                        writetocache('jzsjiale_daogou_shangpin_'.$child3cateiddata['id'], getcachevars(array('tbkshangpin_'.$child3cateiddata['id'] => $shangpin_cache_tmp)));

                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$child3cateiddata['id'].'.php';
                        $shangpintmp3 = ${'tbkshangpin_'.$child3cateiddata['id']};

                    }
                    //$shangpintmp3 = $utils->search($child3cateiddata['id'],'categoryid',$tbkshangpin);
                    if(!empty($shangpintmp3)){
                        $shangpin3 = array_merge($shangpin3, $shangpintmp3);
                    }
                
                }
                //shangpin3 end
            }
    
    
            if(empty($shangpin1) && empty($shangpin2) && empty($shangpin3)){
                $shangpin = array();
            }elseif(empty($shangpin1) && empty($shangpin2) && !empty($shangpin3)){
                $shangpin = $shangpin3;
            }elseif(empty($shangpin1) && !empty($shangpin2) && !empty($shangpin3)){
                $shangpin = array_merge($shangpin2, $shangpin3);
            }elseif(!empty($shangpin1) && !empty($shangpin2) && !empty($shangpin3)){
                $shangpin = array_merge($shangpin1,$shangpin2, $shangpin3);
            }elseif(empty($shangpin1) && !empty($shangpin2) && empty($shangpin3)){
                $shangpin = $shangpin2;
            }elseif(!empty($shangpin1) && !empty($shangpin2) && empty($shangpin3)){
                $shangpin = array_merge($shangpin1, $shangpin2);
            }elseif(!empty($shangpin1) && empty($shangpin2) && empty($shangpin3)){
                $shangpin = $shangpin1;
            }elseif(!empty($shangpin1) && empty($shangpin2) && !empty($shangpin3)){
                $shangpin = array_merge($shangpin1, $shangpin3);
            }else{
                $shangpin = array();
            }
    
    
    
        }elseif(!empty($level) && $level == 2){
            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }else{
                $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $cateid);

                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_shangpin_'.$cateid, getcachevars(array('tbkshangpin_'.$cateid => $shangpin_cache_tmp)));

                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }
            //$shangpin1 = $utils->search($cateid,'categoryid',$tbkshangpin);
            $shangpin1 = $tbkshangpin;
            $shangpin2 = array();
            $spcategory = "";
    
            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
    
                $spcategory = $tbkcategory;
    
            }else{
                $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
    
                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));
    
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                $spcategory = $tbkcategory;
    
            }
    
            $childcateid = $utils->searchArrayByPid($cateid,$spcategory);
            foreach ($childcateid as $childcateiddata){
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcateiddata['id'].'.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcateiddata['id'].'.php';
                    $shangpintmp = ${'tbkshangpin_'.$childcateiddata['id']};

                }else{
                    $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $childcateiddata['id']);

                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_shangpin_'.$childcateiddata['id'], getcachevars(array('tbkshangpin_'.$childcateiddata['id'] => $shangpin_cache_tmp)));

                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcateiddata['id'].'.php';
                    $shangpintmp = ${'tbkshangpin_'.$childcateiddata['id']};

                }
                //$shangpintmp = $utils->search($childcateiddata['id'],'categoryid',$tbkshangpin);
                if(!empty($shangpintmp)){
                    $shangpin2 = array_merge($shangpin2, $shangpintmp);
                }
    
            }
    
    
            if(empty($shangpin1)){
                $shangpin = $shangpin2;
            }else{
                $shangpin = array_merge($shangpin1, $shangpin2);
            }
    
    
    
        }else{
            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }else{
                $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $cateid);

                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_shangpin_'.$cateid, getcachevars(array('tbkshangpin_'.$cateid => $shangpin_cache_tmp)));

                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }
            //$shangpin = $utils->search($cateid,'categoryid',$tbkshangpin);
            $shangpin = $tbkshangpin;
        }
    }else{

        $alltbkshangpin = array();
        $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

        foreach ($category as $key => $value){

            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php';
                $tbkshangpin = ${'tbkshangpin_'.$value["id"]};

            }else{
                $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $value["id"]);

                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));

                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php';
                $tbkshangpin = ${'tbkshangpin_'.$value["id"]};

            }

            if(!empty($tbkshangpin) && $tbkshangpin != null){
                $alltbkshangpin = array_merge($alltbkshangpin, $tbkshangpin);
            }


        }

        $shangpin = $alltbkshangpin;
    }
    
    
    if($sort == 3){
        //jiagedidaogao
        $shangpin = $utils->my_sort($shangpin,'xianjia',SORT_ASC,SORT_NUMERIC);
    }elseif($sort == 4){
       //jiagegaodaodi
        $shangpin = $utils->my_sort($shangpin,'xianjia',SORT_DESC,SORT_NUMERIC);
    }else{
        
    }

    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    
    $shangpin = $utils->page_array($pagesize,$page,$shangpin,0);
    require_once(DISCUZ_ROOT."./source/function/function_post.php");
    foreach($shangpin as $k=>$v){
        if ($_G['charset'] == "gbk") {
            $shangpin[$k]['title'] = diconv(cutstr($shangpin[$k]['title'],190),'GBK', 'UTF-8' );
            $shangpin[$k]['tkl'] = diconv($shangpin[$k]['tkl'],'GBK', 'UTF-8');
            $shangpin[$k]['tklsimple'] = diconv($shangpin[$k]['tklsimple'],'GBK', 'UTF-8');
            $shangpin[$k]['couponinfo'] = diconv($shangpin[$k]['couponinfo'],'GBK', 'UTF-8');
        }else{
            $shangpin[$k]['title']=cutstr($shangpin[$k]['title'],190);
            $shangpin[$k]['tkl']=$shangpin[$k]['tkl'];
            $shangpin[$k]['tklsimple']=$shangpin[$k]['tklsimple'];
            $shangpin[$k]['couponinfo'] = $shangpin[$k]['couponinfo'];
        }
    
        if($_config['g_spneilian']){
            $shangpin[$k]['url'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$shangpin[$k]['id'];
            $shangpin[$k]['youhuiquan'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$shangpin[$k]['id'];
        }
        
        if(empty($shangpin[$k]['img'])){
            $shangpin[$k]['img']='source/plugin/jzsjiale_daogou/static/images/daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/spnopic.jpg';
        }
    }
    
    //var_dump($shangpin);exit;
    $shangpin = dhtmlspecialchars($shangpin);
    header("Content-Type: text/html; charset=".$_G['charset']);
    if(!empty($shangpin)){
        echo json_encode(array('code' => 200,'data' => $shangpin));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'webspcategory'){
    
    $spcategory = "";
    
    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
    
        $spcategory = $tbkcategory;
    
    }else{
        $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
        
        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));
    
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
        $spcategory = $tbkcategory;
    
    }
    

    require_once(DISCUZ_ROOT."./source/function/function_post.php");
    foreach($spcategory as $k=>$v){
        if ($_G['charset'] == "gbk") {
            $spcategory[$k]['title'] = diconv(cutstr($spcategory[$k]['title'],190),'GBK', 'UTF-8');
        }else{
            $spcategory[$k]['title']=cutstr($spcategory[$k]['title'],190);
        }
    
        if(empty($spcategory[$k]['img'])){
            $spcategory[$k]['img']='source/plugin/jzsjiale_daogou/static/images/daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/spcatenopic.png';
        }
    }
    
    $spcategory = $utils->treeCate($spcategory);
    
    $spcategory = dhtmlspecialchars($spcategory);
    header("Content-Type: text/html; charset=".$_G['charset']);
    if(!empty($spcategory)){
        echo json_encode(array('code' => 200,'data' => $spcategory));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'searchshangpin'){
    
    $query = daddslashes(trim($_GET['q']));
    $type = daddslashes(trim($_GET['t']));
    $sort = intval(daddslashes($_GET['sort']));
    $page = intval(daddslashes(trim($_GET['page'])));
    $pagesize = intval(daddslashes(trim($_GET['pagesize'])));
   
    $page = $page > 0 ? $page : 1;
    $pagesize = $pagesize > 0 ? $pagesize : 21;

    if(!empty($query) && $_G['charset'] == 'gbk') {
        $query = diconv($query,'UTF-8','GBK');
    }
    
    $searchdata = "";


    //20190329 add
    $alltbkshangpin = array();
    $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

    foreach ($category as $key => $value){

        if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php')){
            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php';
            $tbkshangpin = ${'tbkshangpin_'.$value["id"]};

        }else{
            $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $value["id"]);

            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));

            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php';
            $tbkshangpin = ${'tbkshangpin_'.$value["id"]};

        }

        if(!empty($tbkshangpin) && $tbkshangpin != null){
            $alltbkshangpin = array_merge($alltbkshangpin, $tbkshangpin);
        }


    }


    if(!empty($query)){
        $searchdata =  $utils->searchlike($query,'title',$alltbkshangpin);
    }

    //20170620start
    if($sort == 3){
        //jiagedidaogao
        $searchdata = $utils->my_sort($searchdata,'xianjia',SORT_ASC,SORT_NUMERIC);
    }elseif($sort == 4){
        //jiagegaodaodi
        $searchdata = $utils->my_sort($searchdata,'xianjia',SORT_DESC,SORT_NUMERIC);
    }else{

    }
    //20170620end

    $searchdata = $utils->page_array($pagesize,$page,$searchdata,0);

    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];

    require_once(DISCUZ_ROOT."./source/function/function_post.php");
    foreach($searchdata as $k=>$v){
        if ($_G['charset'] == "gbk") {
            $searchdata[$k]['title'] = diconv(cutstr($searchdata[$k]['title'],190),'GBK', 'UTF-8');
            $searchdata[$k]['tkl'] = diconv($searchdata[$k]['tkl'],'GBK', 'UTF-8');
            $searchdata[$k]['tklsimple'] = diconv($searchdata[$k]['tklsimple'],'GBK', 'UTF-8');
            $searchdata[$k]['couponinfo'] = diconv($searchdata[$k]['couponinfo'],'GBK', 'UTF-8');
        }else{
            $searchdata[$k]['title']=cutstr($searchdata[$k]['title'],190);
            $searchdata[$k]['tkl']=$searchdata[$k]['tkl'];
            $searchdata[$k]['tklsimple']=$searchdata[$k]['tklsimple'];
            $searchdata[$k]['couponinfo']=$searchdata[$k]['couponinfo'];
        }

        if($_config['g_spneilian']){
            $searchdata[$k]['url'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$searchdata[$k]['id'];
            $searchdata[$k]['youhuiquan'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$searchdata[$k]['id'];
        }

        if(empty($searchdata[$k]['img'])){
            $searchdata[$k]['img']='source/plugin/jzsjiale_daogou/static/images/daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/spnopic.jpg';
        }
    }

    //var_dump($searchdata);exit;
    $searchdata = dhtmlspecialchars($searchdata);
    header("Content-Type: text/html; charset=".$_G['charset']);
    if(!empty($searchdata)){
        echo json_encode(array('code' => 200,'data' => $searchdata));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'searchtiezi'){
    
    $query = daddslashes(trim($_GET['q']));
    $type = daddslashes(trim($_GET['t']));
    $page = intval(daddslashes(trim($_GET['page'])));
    $pagesize = intval(daddslashes(trim($_GET['pagesize'])));
   
    $page = $page > 0 ? $page : 1;
    $pagesize = $pagesize > 0 ? $pagesize : 21;

    $searchdata = "";
    
    if(!empty($query) && $_G['charset'] == 'gbk') {
        $query = diconv($query,'UTF-8','GBK');
    }
    
    //20170620start
    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    $g_dulixiewenzhangfid = $_config['g_dulixiewenzhang'];
     
    $allposts = array();
    $allposts = C::t('forum_thread')->fetch_all_by_fid_displayorder($g_dulixiewenzhangfid, 0);
     
   
    $searchdatatids = "";
    if(!empty($query)){
        $searchdatatids =  $utils->searchlikeReturnStr2($query,'subject','tid',$allposts);
    }
    //20170620end
    
  
    $searchdata = $utils->get_forumdata($searchdatatids,$page,$pagesize,0);
    
    require_once(DISCUZ_ROOT."./source/function/function_post.php");
    foreach($searchdata as $k=>$v){
        
        //20170616start
        if(preg_match('/\s?\[jzsjiale_daogou_post\](.*?)\[\/jzsjiale_daogou_post\]\s?/is', $searchdata[$k]['message'], $matches)) {
            $m1 = $matches[1];
            if ($_G['charset'] == "gbk") {
                $m1 = diconv($m1,'GBK', 'UTF-8');
            }
            $content1 = html_entity_decode($m1);
            $content = json_decode($content1,TRUE);
            $content_list = $content['content_list'];
             
            $postmessage = "";
            foreach ($content_list as $key => $value){
                if($content_list[$key]['type'] == 2){
                    $text_content = diconv($content_list[$key]['text_content'], 'UTF-8','GBK');
                    $postmessage .= '<p class="desc">'.$text_content.'</p>';
                }
            }
            if ($_G['charset'] == "gbk") {
        
            }else{
                $postmessage = diconv($postmessage,'GBK', 'UTF-8');
            }
            $searchdata[$k]['message'] = $postmessage;
        }
        //20170616end
        
        if ($_G['charset'] == "gbk") {
            $searchdata[$k]['subject'] = diconv(cutstr($searchdata[$k]['subject'],190),'GBK', 'UTF-8');
            $searchdata[$k]['author']=diconv(messagecutstr($searchdata[$k]['author'],190),'GBK', 'UTF-8');
            $searchdata[$k]['message']=diconv(messagecutstr($searchdata[$k]['message'],190),'GBK', 'UTF-8');
        }else{
            $searchdata[$k]['subject']=cutstr($searchdata[$k]['subject'],190);
            $searchdata[$k]['author']=messagecutstr($searchdata[$k]['author'],190);
            $searchdata[$k]['message']=messagecutstr($searchdata[$k]['message'],190);
        }
    
        $searchdata[$k]['dateline']=date('Y-m-d H:i:s',$searchdata[$k]['dateline']);
        
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $g_isopenyuancheng = $_config['g_isopenyuancheng'];
        $g_yuanchengurl = $_config['g_yuanchengurl'];
        
        $tid = $v['tid'];
        $cover_tmp=getCover($tid);
        $pic=$cover_tmp['attachment'];
        $isremote=$cover_tmp['remote'];
        if(!empty($pic)){
            if($g_isopenyuancheng && !empty($g_yuanchengurl) && $isremote){
                $searchdata[$k]['cover']=$g_yuanchengurl.'/forum/'.$pic;
            }else{
                $searchdata[$k]['cover']='data/attachment/forum/'.$pic;
            }
        }else{
            $searchdata[$k]['cover']= $_G['jzsjiale_tpl_daogou']['defaultimg'];//$utils->searchArrayByField('defaultimg',$daogouoptions);
        }
    
        if(empty($searchdata[$k]['cover'])){
            $searchdata[$k]['cover']='source/plugin/jzsjiale_daogou/static/images/daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/nopic.jpg';
        }
    }
    
    
    //var_dump($homefisrtlist);exit;
    $searchdata = dhtmlspecialchars($searchdata);
    header("Content-Type: text/html; charset=".$_G['charset']);
    if(!empty($searchdata)){
        echo json_encode(array('code' => 200,'data' => $searchdata));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'webshangpinbycatelevel1'){
    
    $level = intval($_GET['level']);
    $cateid = intval($_GET['cateid']);
    $page = intval($_GET['page']);
    $pagesize = intval($_GET['pagesize']);
    $startfirstcate = intval($_GET['startfirstcate']);
    
    $page = $page > 0 ? $page : 1;
    $pagesize = $pagesize > 0 ? $pagesize : 21;

    $shangpin = "";


    $spcategory = "";
    
    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
    
        $spcategory = $tbkcategory;
    
    }else{
        $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
    
        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));
    
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
        $spcategory = $tbkcategory;
    
    }
    
    
    if($startfirstcate && empty($cateid)){
        foreach($spcategory as $spkey => $spvalue){
            if($spvalue['status'] == 1 && $spvalue['pid'] == 0){
                $cateid = $spvalue['id'];
                break;
            }
        }
    }
   
    if(!empty($cateid)){
        if(!empty($level) && $level == 1){
            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }else{
                $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $cateid);

                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_shangpin_'.$cateid, getcachevars(array('tbkshangpin_'.$cateid => $shangpin_cache_tmp)));

                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }
            //$shangpin1 = $utils->search($cateid,'categoryid',$tbkshangpin);
            $shangpin1 = $tbkshangpin;
            $shangpin2 = array();
            $shangpin3 = array();
    
            $childcateid = $utils->searchArrayByPid($cateid,$spcategory);
            foreach ($childcateid as $childcateiddata){
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcateiddata['id'].'.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcateiddata['id'].'.php';
                    $shangpintmp = ${'tbkshangpin_'.$childcateiddata['id']};

                }else{
                    $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $childcateiddata['id']);

                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_shangpin_'.$childcateiddata['id'], getcachevars(array('tbkshangpin_'.$childcateiddata['id'] => $shangpin_cache_tmp)));

                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcateiddata['id'].'.php';
                    $shangpintmp = ${'tbkshangpin_'.$childcateiddata['id']};

                }
                //$shangpintmp = $utils->search($childcateiddata['id'],'categoryid',$tbkshangpin);
                if(!empty($shangpintmp)){
                    $shangpin2 = array_merge($shangpin2, $shangpintmp);
                }
    
                $childcate3id = $utils->searchArrayByPid($childcateiddata['id'],$spcategory);
                foreach ($childcate3id as $childcate3iddata){
                    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcate3iddata['id'].'.php')){
                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcate3iddata['id'].'.php';
                        $shangpintmp = ${'tbkshangpin_'.$childcate3iddata['id']};

                    }else{
                        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $childcate3iddata['id']);

                        require_once libfile('function/cache');
                        writetocache('jzsjiale_daogou_shangpin_'.$childcate3iddata['id'], getcachevars(array('tbkshangpin_'.$childcate3iddata['id'] => $shangpin_cache_tmp)));

                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$childcate3iddata['id'].'.php';
                        $shangpintmp = ${'tbkshangpin_'.$childcate3iddata['id']};

                    }
                    //$shangpintmp = $utils->search($childcate3iddata['id'],'categoryid',$tbkshangpin);
                    if(!empty($shangpintmp)){
                        $shangpin3 = array_merge($shangpin3, $shangpintmp);
                    }
                
                }
            }
    
            if(empty($shangpin1)){
                $shangpin1 = array();
            }
            if(empty($shangpin2)){
                $shangpin2 = array();
            }
            if(empty($shangpin3)){
                $shangpin3 = array();
            }
            
            
            $shangpin = array_merge($shangpin1, $shangpin2, $shangpin3);
            
    
            $shangpin = $utils->my_sort($shangpin,'id',SORT_DESC);
    
        }else{
            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }else{
                $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $cateid);

                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_shangpin_'.$cateid, getcachevars(array('tbkshangpin_'.$cateid => $shangpin_cache_tmp)));

                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$cateid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$cateid};

            }
            //$shangpin = $utils->search($cateid,'categoryid',$tbkshangpin);
            $shangpin = $tbkshangpin;
        }
    }else{
        //20190329 add
        $alltbkshangpin = array();
        $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

        foreach ($category as $key => $value){

            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php';
                $tbkshangpin = ${'tbkshangpin_'.$value["id"]};

            }else{
                $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $value["id"]);

                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));

                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php';
                $tbkshangpin = ${'tbkshangpin_'.$value["id"]};

            }

            if(!empty($tbkshangpin) && $tbkshangpin != null){
                $alltbkshangpin = array_merge($alltbkshangpin, $tbkshangpin);
            }


        }

        $shangpin = $alltbkshangpin;
    }
    
    
    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    
    $shangpin = $utils->page_array($pagesize,$page,$shangpin,0);
    require_once(DISCUZ_ROOT."./source/function/function_post.php");
    foreach($shangpin as $k=>$v){
        if ($_G['charset'] == "gbk") {
            $shangpin[$k]['title'] = diconv(cutstr($shangpin[$k]['title'],190),'GBK', 'UTF-8' );
            $shangpin[$k]['tkl'] = diconv($shangpin[$k]['tkl'],'GBK', 'UTF-8');
            $shangpin[$k]['tklsimple'] = diconv($shangpin[$k]['tklsimple'],'GBK', 'UTF-8');
            $shangpin[$k]['couponinfo'] = diconv($shangpin[$k]['couponinfo'],'GBK', 'UTF-8');
        }else{
            $shangpin[$k]['title']=cutstr($shangpin[$k]['title'],190);
            $shangpin[$k]['tkl']=$shangpin[$k]['tkl'];
            $shangpin[$k]['tklsimple']=$shangpin[$k]['tklsimple'];
            $shangpin[$k]['couponinfo'] = $shangpin[$k]['couponinfo'];
        }
    
        if($_config['g_spneilian']){
            $shangpin[$k]['url'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$shangpin[$k]['id'];
            $shangpin[$k]['youhuiquan'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$shangpin[$k]['id'];
        }
        
        if(empty($shangpin[$k]['img'])){
            $shangpin[$k]['img']='source/plugin/jzsjiale_daogou/static/images/daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/spnopic.jpg';
        }
    }
    
    $shangpin = dhtmlspecialchars($shangpin);
    header("Content-Type: text/html; charset=".$_G['charset']);
    if(!empty($shangpin)){
        echo json_encode(array('code' => 200,'data' => $shangpin));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'getcomments'){
    $tid = $_GET['tid'];
    $page = intval($_GET['page']);
    $pagesize = intval($_GET['pagesize']);
    
    $page = $page > 0 ? $page : 0;
    $pagesize = $pagesize > 0 ? $pagesize : 20;
    
    $posts = C::t('forum_post')->fetch_all_by_tid('tid:'.$tid, $tid, true, 'DESC', $page*$pagesize, $pagesize, 0, 0);
 
    require_once(DISCUZ_ROOT."./source/function/function_post.php");
    $comments = array();
    $index = 0;
    foreach ($posts as $post) {
        $comments[$index] = $post;
        
        $comments[$index]['avatar'] = $_G[setting][ucenterurl].'/avatar.php?uid='.$post['authorid'].'&size=small';
        $comments[$index]['userhome'] = ($_G[jzsjiale_tpl_daogou][weijingtaimokuai] == 1)?$_G[siteurl].'user.html?uid='.$post['authorid']:$_G[siteurl].'plugin.php?id=jzsjiale_daogou:user&uid='.$post['authorid'];
        $comments[$index]['dateline'] = date("Y-m-d H:i:s",$post['dateline']);
        $comments[$index]['messagequote'] = "";
        $comments[$index]['quotepid'] = '';
        $comments[$index]['quoteauthor'] = '';
 
        
        $message = $post['message'];
        $_G['setting']['plugins']['func'][HOOKTYPE]['discuzcode'] = false;
        if (strpos($message, '[/attach]') !== FALSE || strpos($message, '[/attachimg]') !== FALSE || strpos($message, '[/url]') !== FALSE || strpos($message, '[/img]') !== FALSE || strpos($message, '[/media]') !== FALSE || strpos($message, '[/audio]') !== FALSE || strpos($message, '[/flash]') !== FALSE) {
            
            if (strpos($message, '[/img]') !== FALSE) {
                $pattern = "/\[img.*?\](.*?)\[\/img\]/i";
                preg_match_all($pattern, $message, $matchsimg);
                $comments[$index]['img_piclist'] = $matchsimg[1];
            }
        }
       
        if(strexists($message, '[quote]')){
            $pattern = "/\s?\[quote.*?\](.*?)\[url=(.*?)\](.*?)\[\/quote\]\s?/is";
            preg_match_all($pattern, $message, $matchsquote);
 
            $quote = $utils->getparam($matchsquote[2][0]);
    
            if(!empty($quote)){
                $messagequote = C::t('forum_post')->fetch('tid:'.$quote['ptid'], $quote['pid']);
                
                $comments[$index]['messagequote'] = messagecutstr($messagequote['message'], 300);
                $comments[$index]['quotepid'] = $messagequote['pid'];
                $comments[$index]['quoteauthor'] = $messagequote['author'];
            }
            
        }
        
        
        $comments[$index]['message'] = messagecutstr($post['message'], 300);
        /*
        foreach ($comments[$index]['img_piclist'] as $img){
            $comments[$index]['messageimg'].='<a href="'.$img.'" target="_blank"><img src="'.$img.'" style="width:50px;height:70px;"/></a>';
        }
        */
        if ($_G['charset'] == "gbk") {
            $comments[$index]['author'] = diconv(cutstr($comments[$index]['author'],190),'GBK', 'UTF-8' );
            $comments[$index]['message'] = diconv($comments[$index]['message'],'GBK', 'UTF-8');
            $comments[$index]['messagequote'] = diconv($comments[$index]['messagequote'],'GBK', 'UTF-8');
            $comments[$index]['quoteauthor'] = diconv($comments[$index]['quoteauthor'],'GBK', 'UTF-8');
            //$comments[$index]['messageimg'] = diconv($comments[$index]['messageimg'],'GBK', 'UTF-8');
        }else{
            $comments[$index]['author']=cutstr($comments[$index]['author'],190);
            $comments[$index]['message']=$comments[$index]['message'];
            $comments[$index]['messagequote']=$comments[$index]['messagequote'];
            $comments[$index]['quoteauthor']=$comments[$index]['quoteauthor'];
            //$comments[$index]['messageimg']=$comments[$index]['messageimg'];
        }
        
        $index++;
    }

    $comments = dhtmlspecialchars($comments);
    header("Content-Type: text/html; charset=".$_G['charset']);
    if(!empty($comments)){
        echo json_encode(array('code' => 200,'data' => $comments));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'addcomment'){
    header("Content-Type: text/html; charset=".$_G['charset']);
    
    $tid = $_GET['tid'];
    $fid = $_GET['fid'];
    $pid = $_GET['pid'];
    $formhash = $_GET['formhash'];
    $content = daddslashes($_GET['content']);
    $mobileflag = $_GET['mobileflag'];
    
    if(empty($formhash) || $formhash != FORMHASH){
        echo json_encode(array('code' => -2));
        exit();
    }
    if(empty($_G['uid']) || empty($_G['username'])){
        echo json_encode(array('code' => -2));
        exit();
    }
    
    if ($_G['charset'] == "gbk" && ($mobileflag != 1 && !$utils->is_mobile())) {
        $content = diconv($content, 'UTF-8','GB2312');
    }
    
    require_once(DISCUZ_ROOT."./source/function/function_post.php");
    include_once libfile('function/forum');
    $postid = "";
    if(empty($pid) || $pid == "" || $pid == null){
        $subject = '';
        $postid = insertpost(array(
            'fid'         => $fid,
            'tid'         => $tid,
            'first'       => 0,
            'author'      => $_G['username'],
            'authorid'    => $_G['uid'],
            'subject'     => '',
            'dateline'    => $_G['timestamp'],
            'message'     => $content,
            'useip'       => $_G['clientip'],
            'invisible'   => 0,
            'anonymous'   => 0,
            'usesig'      => 1,
            'htmlon'      => 0,
            'bbcodeoff'   => 0,
            'smileyoff'   => -1,
            'parseurloff' => 0,
            'attachment'  => 0,
        ));
        
        
    }else{
        
        $pidmessage = C::t('forum_post')->fetch('tid:'.$tid, $pid);
        if($pidmessage == null || empty($pidmessage)){
            $postid = '';
        }else{
            $post_reply_quote = lang('forum/misc', 'post_reply_quote', array('author' => $pidmessage['author'], 'time' => date("Y-m-d H:i",$pidmessage['dateline'])));
            $message = messagecutstr($pidmessage['message'], 100);
            $message = implode("\n", array_slice(explode("\n", $message), 0, 3));
            
            $message = "[quote][size=2][url=forum.php?mod=redirect&goto=findpost&pid=".$pid."&ptid=".$tid."][color=#999999]".$post_reply_quote."[/color][/url][/size]\n".$message."[/quote]";
            
            $content = $message.$content;
            
            $subject = '';
            $postid = insertpost(array(
                'fid'         => $fid,
                'tid'         => $tid,
                'first'       => 0,
                'author'      => $_G['username'],
                'authorid'    => $_G['uid'],
                'subject'     => '',
                'dateline'    => $_G['timestamp'],
                'message'     => $content,
                'useip'       => $_G['clientip'],
                'invisible'   => 0,
                'anonymous'   => 0,
                'usesig'      => 1,
                'htmlon'      => 0,
                'bbcodeoff'   => 0,
                'smileyoff'   => -1,
                'parseurloff' => 0,
                'attachment'  => 0,
            ));
        }
        
       
    }
    
    if($postid) {
        DB::query("UPDATE ".DB::table('forum_thread')." SET replies=replies+1,lastpost='$_G[timestamp]',lastposter='$_G[username]' WHERE tid='$tid'");
        DB::query("UPDATE ".DB::table('common_member_count')." SET posts=posts+1 WHERE uid='$_G[uid]'");
        DB::query("UPDATE ".DB::table('forum_forum')." SET lastpost='$tid\t$subject\t$_G[timestamp]\t$_G[username]',posts=posts+1,todayposts=todayposts+1 WHERE fid='$fid'");
    }
    
    if(!empty($postid)){
        echo json_encode(array('code' => 200));
        exit();
    }else{
        echo json_encode(array('code' => 200));
        exit();
    }
}elseif($act == 'relationrec'){
    
    $tid = $_GET['tid'];
    $num = dintval($_GET['num']);
    
    $num = $num > 0 ? $num : 0;
    
    $tiezi = "";
    
    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezi.php')){
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezi.php';
    
        $tiezi = $daogoutiezi;
    
    }else{
        $daogoutiezi = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->getall();
    
        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_tiezi', getcachevars(array('daogoutiezi' => $daogoutiezi)));
    
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezi.php';
        $tiezi = $daogoutiezi;
    
    }
    
    $relationrectids = array();
    
    $tiezicategoryidlists = array();
    $tiezicategoryidlists = $utils->searchReturnStr($tid,'tid','tiezicategoryid',$tiezi);

    $random_tiezicategoryid = array_rand($tiezicategoryidlists,1);

    if(!empty($tiezicategoryidlists[$random_tiezicategoryid]) && $tiezicategoryidlists[$random_tiezicategoryid] != "" && $tiezicategoryidlists[$random_tiezicategoryid] != null){
        $tmp = $utils->searchReturnStr($tiezicategoryidlists[$random_tiezicategoryid],'tiezicategoryid','tid',$tiezi);
        $count_tmp = count($tmp);
        $num = $num > $count_tmp ? $count_tmp : $num;
        $tmprandom = $utils->searchByRandom($tmp,$num);
        foreach ($tmprandom as $tmpkey=>$tmpvalue){
            $relationrectids[] = $tmpvalue;
        }
    }else{
        $count_tmp = count($tiezi);
        $num = $num > $count_tmp ? $count_tmp : $num;
        $tmprandom = $utils->searchByRandom($tiezi,$num);
        foreach ($tmprandom as $tmpkey=>$tmpvalue){
            $relationrectids[] = $tmpvalue;
        }
    }

    $relationreclist = $utils->get_forumdata($relationrectids,1,$num,0);

    require_once(DISCUZ_ROOT."./source/function/function_post.php");
    foreach($relationreclist as $k=>$v){
        if ($_G['charset'] == "gbk") {
            $relationreclist[$k]['subject'] = diconv(cutstr($relationreclist[$k]['subject'],190),'GBK','UTF-8');
            $relationreclist[$k]['author']=diconv(messagecutstr($relationreclist[$k]['author'],190),'GBK','UTF-8');
            $relationreclist[$k]['message']=diconv(messagecutstr($relationreclist[$k]['message'],190),'GBK','UTF-8');
        }else{
            $relationreclist[$k]['subject']=cutstr($relationreclist[$k]['subject'],190);
            $relationreclist[$k]['author']=messagecutstr($relationreclist[$k]['author'],190);
            $relationreclist[$k]['message']=messagecutstr($relationreclist[$k]['message'],190);
        }
    
        $relationreclist[$k]['dateline']=date('Y-m-d H:i:s',$relationreclist[$k]['dateline']);
    
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $g_isopenyuancheng = $_config['g_isopenyuancheng'];
        $g_yuanchengurl = $_config['g_yuanchengurl'];
    
        $tid = $v['tid'];
        $cover_tmp=getCover($tid);
        $pic=$cover_tmp['attachment'];
        $isremote=$cover_tmp['remote'];
        if(!empty($pic)){
            if($g_isopenyuancheng && !empty($g_yuanchengurl) && $isremote){
                $relationreclist[$k]['cover']=$g_yuanchengurl.'/forum/'.$pic;
            }else{
                $relationreclist[$k]['cover']='data/attachment/forum/'.$pic;
            }
    
        }else{
            $relationreclist[$k]['cover']= $_G['jzsjiale_tpl_daogou']['defaultimg'];//$utils->searchArrayByField('defaultimg',$daogouoptions);
        }
    
        if(empty($relationreclist[$k]['cover'])){
            $relationreclist[$k]['cover']='source/plugin/jzsjiale_daogou/static/images/daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/nopic.jpg';
        }
    }
    //var_dump($homefisrtlist);exit;
    
    $relationreclist = dhtmlspecialchars($relationreclist);
    header("Content-Type: text/html; charset=".$_G['charset']);
    if(!empty($relationreclist)){
        echo json_encode(array('code' => 200,'data' => $relationreclist));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'publisharticle'){
    header("Content-Type: text/html; charset=".$_G['charset']);
    
    $tid = $_GET['tid'];
    $pid = $_GET['pid'];
    $fid = $_GET['fid'];
    
    $formhash = $_GET['formhash'];
    $content = daddslashes($_GET['articleContent']);
    $mobileflag = $_GET['mobileflag'];
    
    if(empty($mobileflag)){
        $mobileflag = 0;
    }
    
    if(empty($fid)){
        echo json_encode(array('code' => -2));
        exit();
    }
     
    if(empty($formhash) || $formhash != FORMHASH){
        echo json_encode(array('code' => -2));
        exit();
    }
     
    if(empty($_G['uid']) || empty($_G['username'])){
        echo json_encode(array('code' => -2));
        exit();
    }
    
    
    $content1 = stripslashes(html_entity_decode($content));
    //20170615start
    if ($_G['charset'] == "gbk" && ($mobileflag == 1 || $utils->is_mobile())) {
        $content1 = diconv($content1,'GBK', 'UTF-8');
    }
    //20170615end
    $content2 = json_decode($content1,TRUE);
    
    $subject = $content2['title'];
    $message = '';
    $cover_url = $content2['cover_url'];
    $cover_aid = $content2['cover_aid'];
    
      
    $content_list = $content2['content_list'];
    
    //20170615start
    if ($_G['charset'] == "gbk") {
        $subject = diconv($subject, 'UTF-8','GBK');
        $content1 = diconv($content1, 'UTF-8','GBK');
        $message = '[jzsjiale_daogou_post]'.$content1.'[/jzsjiale_daogou_post]';
    }else{
        $message = '[jzsjiale_daogou_post]'.$content1.'[/jzsjiale_daogou_post]';
    }
    //20170615end
    
  
    if (empty($subject) || empty($message)){
        echo json_encode(array('code' => -100,'msg' => 'The title and content cannot be empty!'));
        exit();
    }
    
    $modthread = C::m('forum_thread', $fid);
    $modthread->param = array();
    
    $_G['group']['disablepostctrl'] = 1;
    
    $bfmethods = $afmethods = array();
     
    $params = array(
        'subject' => $subject,
        'message' => $message,
        'typeid' => 0,
        'sortid' => 0,
        'special' => 0,
        'closed' => 0,
        'bbcodeoff' => 0,
        //'htmlon' => 1,
        'save' => 0,
        'publishdate' => $_G['timestamp'],
        //'displayorder' => -4,
    );
    
    
    $params['allownoticeauthor'] = 0;
    //$params['tags'] = $_GET['tags'];
    //$params['bbcodeoff'] = $_GET['bbcodeoff'];
    //$params['smileyoff'] = $_GET['smileyoff'];
    //$params['parseurloff'] = $_GET['parseurloff'];
    $params['usesig'] = 0;
    //$params['htmlon'] = $_GET['htmlon'];
    $params['geoloc'] = diconv($_GET['geoloc'], 'UTF-8');
    
    $acriclevalue = array();
    $articletid = "";
    $articlepid = "";
    if(empty($tid)){
        $savereturn = $modthread->newthread($params);
        $acriclevalue['id'] = $modthread->tid;
        $acriclevalue['pid'] = $modthread->pid;
        
        $articletid = $modthread->tid;
        $articlepid = $modthread->pid;
        
        if(!empty($cover_url)){
            $threadimage = array('tid'=>$modthread->tid,'attachment'=>$cover_url,'remote'=>0);
            C::t('forum_threadimage')->insert($threadimage,true);
        }
        
    }else{
        $posttmp = C::t('forum_post')->fetch('tid:'.$tid, $pid);
        $acriclevalue['id'] = $posttmp['tid'];
        $acriclevalue['pid'] = $posttmp['pid'];
    
        $articletid = $posttmp['tid'];
        $articlepid = $posttmp['pid'];
        
        C::t('forum_thread')->update($posttmp['tid'], array('subject' => $subject,'displayorder' => 0));
        C::t('forum_post')->update('tid:'.$posttmp['tid'], $posttmp['pid'], array('subject' => $subject,'message' => $message,'invisible' => 0));
    
        C::t('forum_threadimage')->delete($tid);
        if(!empty($cover_url)){
            $threadimage = array('tid'=>$posttmp['tid'],'attachment'=>$cover_url,'remote'=>0);
            C::t('forum_threadimage')->insert($threadimage,true);
        }
    }
    
    //shanchu fujian  unused
    if (!empty($articletid) && !empty($cover_aid) && is_numeric($cover_aid) && !empty($cover_url)){
        /*
        $attachmentn = array();
        $attachmentn['aid'] = $cover_aid;
        $attachmentn['tid'] = $articletid;
        $attachmentn['pid'] = $articlepid;
        $attachmentn['uid'] = $_G['uid'];
        $attachmentn['dateline'] = TIMESTAMP;
        $arr=explode("/", $cover_url);
 
        $last=$arr[count($arr)-1];
        $attachmentn['filename'] = $last;
        $attachmentn['filesize'] = 1111;
        $attachmentn['attachment'] = $cover_url;
        $attachmentn['description'] = "cover_desc";
        $attachmentn['remote'] = 0;
        $attachmentn['readperm'] = 0;
        $attachmentn['price'] = 0;
        $attachmentn['isimage'] = 1;
        $attachmentn['width'] = 100;
        $attachmentn['thumb'] = 0;
        $attachmentn['picid'] = 0;
        C::t('forum_attachment_n')->insert('tid:'.$articletid, $attachmentn, false, true);
        */
        C::t('forum_attachment_unused')->delete($cover_aid);
    }
    
    foreach ($content_list as $key => $value){
        if($content_list[$key]['type'] == 1){
          
            if (!empty($content_list[$key]['image_aid']) && is_numeric($content_list[$key]['image_aid'])){
                C::t('forum_attachment_unused')->delete($content_list[$key]['image_aid']);
            }
        }
    }
    
    if(!empty($acriclevalue)){
        echo json_encode(array('code' => 200,'data' => $acriclevalue));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'getDraft'){
    header("Content-Type: text/html; charset=".$_G['charset']);
    
    if(empty($_G['uid']) || empty($_G['username'])){
        echo json_encode(array('code' => -2));
        exit();
    }
    
    $invisible = -3;
    $start = 0;
    $limit = 1;
    
  
    require_once libfile('function/post');
    $posts = C::t('forum_post')->fetch_all_by_authorid(0, $_G['uid'], true, 'DESC', $start, $limit, null, $invisible, null, null);
    
    if(empty($posts)) return "";

    $message = array();
    
    $listcount = count($posts);
    foreach($posts as $pid => $post) {
        $tids[$post['tid']][] = $pid;
        
        if($post['authorid'] == $_G['uid']){
            $message['post'] = $posts[$pid]['message'];
            $message['tid'] = $posts[$pid]['tid'];
            $message['pid'] = $posts[$pid]['pid'];
        }
        
    }
    if (strpos($message['post'], '[/jzsjiale_daogou_post]') === false) {
        return "";
    }
    
    if(preg_match('/\s?\[jzsjiale_daogou_post\](.*?)\[\/jzsjiale_daogou_post\]\s?/is', $message['post'], $matches)) {
        $m1 = $matches[1];
        if ($_G['charset'] == "gbk") {
            $message['post'] = diconv($m1,'GBK', 'UTF-8');
        }else{
            $message['post'] = $m1;
        }
    }else{
        return "";
    }
    
    /*
    $m1 = substr($message['post'], strlen('[jzsjiale_daogou_post]'), strlen($message['post']) - strlen('[jzsjiale_daogou_post]') - strlen('[/jzsjiale_daogou_post]'));
    if ($_G['charset'] == "gbk") {
        $message['post'] = diconv($m1,'GB2312', 'UTF-8');
    }else{
        $message['post'] = $m1;
    }
    */
    
    if(!empty($message)){
        echo json_encode(array('code' => 200,'data' =>  $message));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'saveDraft'){
    header("Content-Type: text/html; charset=".$_G['charset']);

    $tid = $_GET['tid'];
    $pid = $_GET['pid'];
    $fid = $_GET['fid'];
    
    $formhash = $_GET['formhash'];
    $content = daddslashes($_GET['articleContent']);
    $mobileflag = $_GET['mobileflag'];
    
    if(empty($mobileflag)){
        $mobileflag = 0;
    }

    if(empty($fid)){
        echo json_encode(array('code' => -2));
        exit();
    }
   
    if(empty($formhash) || $formhash != FORMHASH){
        echo json_encode(array('code' => -2));
        exit();
    }
   
    if(empty($_G['uid']) || empty($_G['username'])){
        echo json_encode(array('code' => -2));
        exit();
    }
    
    
    $content1 = stripslashes(html_entity_decode($content)); 
    //20170615start
    if ($_G['charset'] == "gbk" && ($mobileflag == 1 || $utils->is_mobile())) {
        $content1 = diconv($content1,'GBK', 'UTF-8');
    }
    //20170615end
    $content2 = json_decode($content1,TRUE);

    $subject = $content2['title'];
    $message = '';
    $cover_url = $content2['cover_url'];
    
    $content_list = $content2['content_list'];
    
    //20170615start
    if ($_G['charset'] == "gbk") {
        $subject = diconv($subject, 'UTF-8','GBK');
        $content1 = diconv($content1, 'UTF-8','GBK');
        $message = '[jzsjiale_daogou_post]'.$content1.'[/jzsjiale_daogou_post]';
    }else{
        $message = '[jzsjiale_daogou_post]'.$content1.'[/jzsjiale_daogou_post]';
    }
    //20170615end
    
    if (empty($subject) || empty($message)){
        echo json_encode(array('code' => -100,'msg' => 'The title and content cannot be empty.'));
        exit();
    }
    
    $modthread = C::m('forum_thread', $fid);
    $modthread->param = array();
    
    $_G['group']['disablepostctrl'] = 1;
    
    $bfmethods = $afmethods = array();
   
    $params = array(
        'subject' => $subject,
        'message' => $message,
        'typeid' => 0,
        'sortid' => 0,
        'special' => 0,
        'closed' => 0,
        'bbcodeoff' => 0,
        //'htmlon' => 1,
        'save' => -3,
        'publishdate' => $_G['timestamp'],
        //'displayorder' => -4,
    );
    

    $params['allownoticeauthor'] = 0;
    //$params['tags'] = $_GET['tags'];
    //$params['bbcodeoff'] = $_GET['bbcodeoff'];
    //$params['smileyoff'] = $_GET['smileyoff'];
    //$params['parseurloff'] = $_GET['parseurloff'];
    $params['usesig'] = 0;
    //$params['htmlon'] = $_GET['htmlon'];
    $params['geoloc'] = diconv($_GET['geoloc'], 'UTF-8'); 
    
    $acriclevalue = array();
    if(empty($tid)){
        $savereturn = $modthread->newthread($params);
        $acriclevalue['id'] = $modthread->tid;
        $acriclevalue['pid'] = $modthread->pid;
        
        if(!empty($cover_url)){
            $threadimage = array('tid'=>$modthread->tid,'attachment'=>$cover_url,'remote'=>0);
            C::t('forum_threadimage')->insert($threadimage,true);
        }
    }else{
        $posttmp = C::t('forum_post')->fetch('tid:'.$tid, $pid);
        $acriclevalue['id'] = $posttmp['tid'];
        $acriclevalue['pid'] = $posttmp['pid'];
        
        C::t('forum_thread')->update($posttmp['tid'], array('subject' => $subject));
        C::t('forum_post')->update('tid:'.$posttmp['tid'], $posttmp['pid'], array('subject' => $subject,'message' => $message));
  
        C::t('forum_threadimage')->delete($tid);
        if(!empty($cover_url)){
            $threadimage = array('tid'=>$posttmp['tid'],'attachment'=>$cover_url,'remote'=>0);
            C::t('forum_threadimage')->insert($threadimage,true);
        }
    }

  
    if(!empty($acriclevalue)){
        echo json_encode(array('code' => 200,'data' => $acriclevalue));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'gettidaodehaowu'){
    header("Content-Type: text/html; charset=".$_G['charset']);
    
    $gettid = $_GET['tid'];
    $getpid = $_GET['pid'];
    $getfid = $_GET['fid'];
   
    require_once libfile('function/post');
    $post = C::t('forum_post')->fetch_by_pid_condition('tid:'.$gettid, $getpid);
  
    $message = "";
    
    if(!empty($post)){
        $message = $post['message'];
        $articleId = $post['tid'];
        $pid = $post['pid'];
    }else{
        return "";
    }
   
    if (strpos($message, '[/jzsjiale_daogou_post]') === false) {
            return "";
    }
       
    if(preg_match('/\s?\[jzsjiale_daogou_post\](.*?)\[\/jzsjiale_daogou_post\]\s?/is', $message, $matches)) {
        $m1 = $matches[1];
        if ($_G['charset'] == "gbk") {
            $message = diconv($m1,'GBK', 'UTF-8');
        }else{
            $message = $m1;
        }
    }else{
        return "";
    }
    
    
    $content1 = html_entity_decode($message);
    $content = json_decode($content1,TRUE);
    $content_list = $content['content_list'];
     
    $productids = array();
    foreach ($content_list as $key => $value){
        if($content_list[$key]['type'] == 5){
            $product_id = $content_list[$key]['product_id'];
            $productids[] = $product_id;
        }
    }
   
    $allokshangpin = array();
    //cache start
    /*
    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php')){
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php';
    
        
        foreach ($productids as $pdata){
            $okshangpin = $utils->search($pdata,'id',$tbkshangpin);
            if(!empty($okshangpin) && $okshangpin != null){
                $allokshangpin = array_merge($allokshangpin, $okshangpin);
            }
    
        }
    
    
    }else{
        $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();
    
        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
    
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php';
    
        foreach ($productids as $pdata){
            $okshangpin = $utils->search($pdata,'id',$tbkshangpin);
            if(!empty($okshangpin) && $okshangpin != null){
                $allokshangpin = array_merge($allokshangpin, $okshangpin);
            }
    
        }
    }
    */
    //20190329 add
    $alltbkshangpin = array();
    $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

    foreach ($category as $key => $value){

        if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php')){
            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php';
            $tbkshangpin = ${'tbkshangpin_'.$value["id"]};

        }else{
            $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $value["id"]);

            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));

            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php';
            $tbkshangpin = ${'tbkshangpin_'.$value["id"]};

        }

        if(!empty($tbkshangpin) && $tbkshangpin != null){
            $alltbkshangpin = array_merge($alltbkshangpin, $tbkshangpin);
        }


    }

    foreach ($productids as $pdata){
        $okshangpin = $utils->search($pdata,'id',$alltbkshangpin);
        if(!empty($okshangpin) && $okshangpin != null){
            $allokshangpin = array_merge($allokshangpin, $okshangpin);
        }

    }
    //cache end
    
    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    
    require_once(DISCUZ_ROOT."./source/function/function_post.php");
    foreach($allokshangpin as $k=>$v){
        if ($_G['charset'] == "gbk") {
            $allokshangpin[$k]['title'] = diconv(cutstr($allokshangpin[$k]['title'],190),'GBK', 'UTF-8');
            $allokshangpin[$k]['tkl'] = diconv($allokshangpin[$k]['tkl'],'GBK', 'UTF-8');
            $allokshangpin[$k]['tklsimple'] = diconv($allokshangpin[$k]['tklsimple'],'GBK', 'UTF-8');
            $allokshangpin[$k]['couponinfo'] = diconv($allokshangpin[$k]['couponinfo'],'GBK', 'UTF-8');
        }else{
            $allokshangpin[$k]['title']=cutstr($allokshangpin[$k]['title'],190);
            $allokshangpin[$k]['tkl']=$allokshangpin[$k]['tkl'];
            $allokshangpin[$k]['tklsimple']=$allokshangpin[$k]['tklsimple'];
            $allokshangpin[$k]['couponinfo']=$allokshangpin[$k]['couponinfo'];
        }
    
        if($_config['g_spneilian']){
            $allokshangpin[$k]['url'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$allokshangpin[$k]['id'];
            $allokshangpin[$k]['youhuiquan'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$allokshangpin[$k]['id'];
        }
    
        if(empty($allokshangpin[$k]['img'])){
            $allokshangpin[$k]['img']='source/plugin/jzsjiale_daogou/static/images/daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/spnopic.jpg';
        }
    }
    
    $allokshangpin = dhtmlspecialchars($allokshangpin);
    if(!empty($allokshangpin)){
        echo json_encode(array('code' => 200,'data' =>  $allokshangpin));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'getxiangguanhaowu'){
    header("Content-Type: text/html; charset=".$_G['charset']);
    
    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    
    $allxiangguanshangpin = array();
    $cacheshangpin = "";

    $gettid = $_GET['tid'];
    $getpid = $_GET['pid'];
    $getfid = $_GET['fid'];
    
    if (! $_config['g_isopen']) {
        return;
    }
    if (! $_config['g_issuiji']) {
         
        return;
    }
    
    if (! $_config['g_yxgroups']) {
        return;
    }


    $pid = $getpid;
    if (empty($pid)) {
        return;
    }
    
    $tid = $gettid;
    if (empty($tid)) {
        return;
    }
    
    $fid = $getfid;
    if (empty($fid)) {
        return;
    }


    $groupid = $_G['groupid'];
    if (empty($groupid)) {
        return;
    }
    
    
    
    $uid = $_G['uid'];
     
     
    $suijigeshu = 1;
    if (! $_config['g_suijigeshu']) {
        $suijigeshu = 1;
    }else{
        $suijigeshu = $_config['g_suijigeshu'];
    }


    
            if (!empty($_config['g_yunxuuid'])) {
                $yunxuuids = array();
                $yunxuuids = explode(',',trim($_config['g_yunxuuid']));
            
                if(!in_array($uid,$yunxuuids)){
                    return;
                }
            }else{
                $mianuids = array();
                
                if (!empty($_config['g_mianuid'])) {
                    $mianuids = explode(',',trim($_config['g_mianuid']));
                
                    if(in_array($uid,$mianuids)){
                        return;
                    }
                }
            }
            
            
            if (!empty($_config['g_yunxutid'])) {
                $yunxutids = array();
                $yunxutids = explode(',',trim($_config['g_yunxutid']));
            
                if(!in_array($tid,$yunxutids)){
                    return;
                }
            }else{
                $miantids = array();
                
                if (!empty($_config['g_miantid'])) {
                    $miantids = explode(',',trim($_config['g_miantid']));
                
                    if(in_array($tid,$miantids)){
                        return;
                    }
                }
            }

            $tuijianfenleiid = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->get_by_tid($tid);
            
            if (empty($tuijianfenleiid) && $_config['g_yxfids'] && in_array($fid,(array)unserialize($_config['g_yxfids'])) && in_array ( $groupid, (array)unserialize($_config['g_yxgroups']) )){
         
                
                //20161222 start
                $ok_suijicategory = "";
                //cache start
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                
                    $ok_suijicategory = $tbkcategory;
                
                }else{
                    $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
                
                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));
                
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                    $ok_suijicategory = $tbkcategory;
                
                }
                //cache end
                $suijicategorylist = array();
                foreach ($ok_suijicategory as $suijidata){
                    if(in_array($fid,json_decode($suijidata['fids']))){
                        $suijicategorylist[] = $suijidata['id'];
                    }
                }


                $allokshangpin = array();
                foreach ($suijicategorylist as $sjdata){
                    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php')){
                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                        $tbkshangpin = ${'tbkshangpin_'.$sjdata};

                    }else{
                        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $sjdata);

                        require_once libfile('function/cache');
                        writetocache('jzsjiale_daogou_shangpin_'.$sjdata, getcachevars(array('tbkshangpin_'.$sjdata => $shangpin_cache_tmp)));

                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                        $tbkshangpin = ${'tbkshangpin_'.$sjdata};

                    }

                    if(!empty($tbkshangpin) && $tbkshangpin != null){
                        $allokshangpin = array_merge($allokshangpin, $tbkshangpin);
                    }
                    $cacheshangpin = $allokshangpin;
                }

                //cache end
                //20161222 over
                
                $spcount = count($cacheshangpin);
       
                if(empty($cacheshangpin) || $spcount <= 0){
                    return;
                }
                
                if($spcount <= $suijigeshu){
                    $suijigeshu = $spcount;
                }
                

                
                
                    $spweiid = array_rand($cacheshangpin,$suijigeshu);
              
                   
                    if($suijigeshu == 1){
                        $okshangpin = $cacheshangpin[$spweiid];
                        $allxiangguanshangpin[] = $okshangpin;
                    }else{
                        for($i=0;$i<$suijigeshu;$i++){
                            $okshangpin = $cacheshangpin[$spweiid[$i]];
                            $allxiangguanshangpin[] = $okshangpin;
                        } 
                    }
                    
                
            }elseif (!empty($tuijianfenleiid) && in_array ( $groupid, (array)unserialize($_config['g_yxgroups']) )){

                $ok_suijicategory = "";
                //cache start
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                
                    $ok_suijicategory = $tbkcategory;
                
                }else{
                    $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
                
                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));
                
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                    $ok_suijicategory = $tbkcategory;
                
                }
                //cache end

                $suijicategorylist = array();
                foreach ($ok_suijicategory as $suijidata){

                    if(!empty($suijidata['daogou']) && $suijidata['daogou'] != 'null'){
                        if(in_array($tuijianfenleiid['tiezicategoryid'],json_decode($suijidata['daogou']))){
                            $suijicategorylist[] = $suijidata['id'];
                        }
                    }

                }
        


                $allokshangpin = array();
                foreach ($suijicategorylist as $sjdata){
                    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php')){
                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                        $tbkshangpin = ${'tbkshangpin_'.$sjdata};

                    }else{
                        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $sjdata);

                        require_once libfile('function/cache');
                        writetocache('jzsjiale_daogou_shangpin_'.$sjdata, getcachevars(array('tbkshangpin_'.$sjdata => $shangpin_cache_tmp)));

                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                        $tbkshangpin = ${'tbkshangpin_'.$sjdata};

                    }

                    if(!empty($tbkshangpin) && $tbkshangpin != null){
                        $allokshangpin = array_merge($allokshangpin, $tbkshangpin);
                    }
                    $cacheshangpin = $allokshangpin;
                }
                //cache end
                //20161222 over
                
                $spcount = count($cacheshangpin);
                 
                if(empty($cacheshangpin) || $spcount <= 0){
                    return;
                }
                
                if($spcount <= $suijigeshu){
                    $suijigeshu = $spcount;
                }
                
                
                
                
                $spweiid = array_rand($cacheshangpin,$suijigeshu);
                
                 
                if($suijigeshu == 1){
                    $okshangpin = $cacheshangpin[$spweiid];
                    $allxiangguanshangpin[] = $okshangpin;
                }else{
                    for($i=0;$i<$suijigeshu;$i++){
                        $okshangpin = $cacheshangpin[$spweiid[$i]];
                        $allxiangguanshangpin[] = $okshangpin;
                    }
                }
            }else{
                return;
            }
    
     

    require_once(DISCUZ_ROOT."./source/function/function_post.php");
    foreach($allxiangguanshangpin as $k=>$v){
        if ($_G['charset'] == "gbk") {
            $allxiangguanshangpin[$k]['title'] = diconv(cutstr($allxiangguanshangpin[$k]['title'],190),'GBK', 'UTF-8');
            $allxiangguanshangpin[$k]['tkl'] = diconv($allxiangguanshangpin[$k]['tkl'],'GBK', 'UTF-8');
            $allxiangguanshangpin[$k]['tklsimple'] = diconv($allxiangguanshangpin[$k]['tklsimple'],'GBK', 'UTF-8');
            $allxiangguanshangpin[$k]['couponinfo'] = diconv($allxiangguanshangpin[$k]['couponinfo'],'GBK', 'UTF-8');
        }else{
            $allxiangguanshangpin[$k]['title']=cutstr($allxiangguanshangpin[$k]['title'],190);
            $allxiangguanshangpin[$k]['tkl']=$allxiangguanshangpin[$k]['tkl'];
            $allxiangguanshangpin[$k]['tklsimple']=$allxiangguanshangpin[$k]['tklsimple'];
            $allxiangguanshangpin[$k]['couponinfo']=$allxiangguanshangpin[$k]['couponinfo'];
        }
    
        if($_config['g_spneilian']){
            $allxiangguanshangpin[$k]['url'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$allxiangguanshangpin[$k]['id'];
            $allxiangguanshangpin[$k]['youhuiquan'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$allxiangguanshangpin[$k]['id'];
        }
    
        if(empty($allxiangguanshangpin[$k]['img'])){
            $allxiangguanshangpin[$k]['img']='source/plugin/jzsjiale_daogou/static/images/daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/spnopic.jpg';
        }
    }
    
    $allxiangguanshangpin = dhtmlspecialchars($allxiangguanshangpin);
    if(!empty($allxiangguanshangpin)){
        echo json_encode(array('code' => 200,'data' =>  $allxiangguanshangpin));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'sendseccode'){
    header("Content-Type: text/html; charset=".$_G['charset']);
    
    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    if(empty($_config['g_issms']) || $_config['g_issms'] == "0"){
        echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
        exit();
    }

    if($_config['g_issms'] == "1" || $_config['g_issms'] == "2"){
        try {
            $_configsms = $_G['cache']['plugin']['jzsjiale_sms'];
            if(empty($_configsms)){
                echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
                exit();
            }

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_sms/smstools.inc.php')){
                require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_sms/smstools.inc.php';

                $g_accesskeyid = $_configsms['g_accesskeyid'];
                $g_accesskeysecret = $_configsms['g_accesskeysecret'];
                $webbianma = $_G['charset'];
                //$g_xiane = $_config['g_xiane'];
                $g_xiane = !empty($_configsms['g_xiane'])?$_configsms['g_xiane']:10;
                $g_isopenhtmlspecialchars = !empty($_configsms['g_isopenhtmlspecialchars'])?true:false;

                $g_templateid = "";
                $g_sign = "";
                $type = intval($_GET[type]);
                //type 0ceshi 1zhuce 2shenfenyanzheng 3denglu 4xiugaimima


                if(empty($g_accesskeyid)){
                    echo json_encode(array('code' => -1,'data' => 'peizhierror'));
                    exit;
                }
                if(empty($g_accesskeysecret)){
                    echo json_encode(array('code' => -1,'data' => 'peizhierror'));
                    exit;
                }


                if($type == 1){
                    $g_openregister = $_configsms['g_openregister'];

                    if(!$g_openregister){
                        echo json_encode(array('code' => -1,'data' => 'notopenregister'));
                        exit;
                    }else{
                        $g_templateid = $_configsms['g_registerid'];
                        $g_sign = $_configsms['g_registersign'];
                    }
                }elseif($type == 2){
                    $g_openyanzheng = $_configsms['g_openyanzheng'];

                    if(!$g_openyanzheng){
                        echo json_encode(array('code' => -1,'data' => 'notopenyanzheng'));
                        exit;
                    }else{
                        $g_templateid = $_configsms['g_yanzhengid'];
                        $g_sign = $_configsms['g_yanzhengsign'];
                    }
                }elseif($type == 3){
                    $g_openlogin = $_configsms['g_openlogin'];

                    if(!$g_openlogin){
                        echo json_encode(array('code' => -1,'data' => 'notopenlogin'));
                        exit;
                    }else{
                        $g_templateid = $_configsms['g_loginid'];
                        $g_sign = $_configsms['g_loginsign'];
                    }
                }elseif($type == 4){
                    $g_openmima = $_configsms['g_openmima'];

                    if(!$g_openmima){
                        echo json_encode(array('code' => -1,'data' => 'notopenmima'));
                        exit;
                    }else{
                        $g_templateid = $_configsms['g_mimaid'];
                        $g_sign = $_configsms['g_mimasign'];
                    }
                }else{
                    $g_openyanzheng = $_configsms['g_openyanzheng'];

                    if(!$g_openyanzheng){
                        echo json_encode(array('code' => -1,'data' => 'notopenyanzheng'));
                        exit;
                    }else{
                        $g_templateid = $_configsms['g_yanzhengid'];
                        $g_sign = $_configsms['g_yanzhengsign'];
                    }
                }



                $phone = addslashes($_GET['phone']);
                if(empty($phone)){
                    echo json_encode(array('code' => -1,'data' => 'paramerror'));
                    exit;
                }


                if (!preg_match("/^1[0123456789]{1}\d{9}$/", $phone)) {
                    echo json_encode(array('code' => -1,'data' => 'bind_phone_error'));
                    exit;
                }

                if($_configsms['g_tongyiuser']){
                    //20170805 add start
                    $user =  C::t('#jzsjiale_sms#jzsjiale_sms_member')->fetch_by_mobile($phone);
                    //20170805 add end
                }else{
                    $user = C::t('#jzsjiale_sms#jzsjiale_sms_user')->fetch_by_phone($phone);
                }

                if ($user && ($type == 1 || $type == 2)) {
                    echo json_encode(array('code' => -1,'data' => 'err_phonebind'));
                    exit;
                }
                if (!$user && ($type == 3 || $type == 4)) {
                    echo json_encode(array('code' => -1,'data' => 'err_nouser'));
                    exit;
                }



                $phonesendcount = C::t('#jzsjiale_sms#jzsjiale_sms_smslist')->count_by_phone_day($phone);

                if($phonesendcount >= $g_xiane){
                    echo json_encode(array('code' => -1,'data' => 'err_seccodexiane'));
                    exit;
                }



                if(empty($g_templateid)){
                    echo json_encode(array('code' => -1,'data' => 'peizhierror'));
                    exit;
                }
                if(empty($g_sign)){
                    echo json_encode(array('code' => -1,'data' => 'peizhierror'));
                    exit;
                }

                $code = generate_code();

                if(empty($code) || $code == null){
                    echo json_encode(array('code' => -1,'data' => 'generatecodeerror'));
                    exit;
                }

                $g_product = $_configsms['g_product'];
                $sms_param_array = array();
                $sms_param_array['code']=(string)$code;
                $sms_param_array['product']=!empty($g_product)?$g_product:'';

                $sms_param_array['product'] = getbianma($sms_param_array['product'],$webbianma);

                $sms_param = json_encode($sms_param_array);


                $g_sign=getbianma($g_sign,$webbianma,$g_isopenhtmlspecialchars);
                if($_config['g_issms'] == "2"){
                    $g_templateid = str_replace('{code}',$code,$g_templateid);
                    $g_templateid = getbianma($g_templateid,$webbianma,$g_isopenhtmlspecialchars);
                }


                //quoqishijian
                $g_youxiaoqi = $_configsms['g_youxiaoqi'];
                if(empty($g_youxiaoqi)){
                    $g_youxiaoqi = 600;
                }
                //echo "====".date('Y-m-d H:i:s',strtotime("+".$g_youxiaoqi." second"));exit;
                $expire = strtotime("+".$g_youxiaoqi." second");

                $uid = $_G['uid'];


                $retdata = "";
                $phonecode = C::t('#jzsjiale_sms#jzsjiale_sms_code')->fetchfirst_by_phone($phone);
                if($_config['g_issms'] == "2"){
                    if ($phonecode) {
                        if (($phonecode['dateline'] + 60) > TIMESTAMP) {
                            echo json_encode(array('code' => -1,'data' => 'err_seccodefasong'));
                            exit;
                        } else {
                            $smstools = new SMSTools();
                            $smstools->__construct($g_accesskeyid, $g_accesskeysecret);
                            $retdata = $smstools->smssend($code,$expire,$type,$uid,$phone,$g_sign,$g_templateid);
                        }
                    } else {
                        $smstools = new SMSTools();
                        $smstools->__construct($g_accesskeyid, $g_accesskeysecret);
                        $retdata = $smstools->smssend($code,$expire,$type,$uid,$phone,$g_sign,$g_templateid);
                    }
                }else{
                    if ($phonecode) {
                        if (($phonecode['dateline'] + 60) > TIMESTAMP) {
                            echo json_encode(array('code' => -1,'data' => 'err_seccodefasong'));
                            exit;
                        } else {
                            $smstools = new SMSTools();
                            $smstools->__construct($g_accesskeyid, $g_accesskeysecret);
                            $retdata = $smstools->smssend($code,$expire,$type,$uid,$phone,$g_sign,$g_templateid,$sms_param);
                        }
                    } else {
                        $smstools = new SMSTools();
                        $smstools->__construct($g_accesskeyid, $g_accesskeysecret);
                        $retdata = $smstools->smssend($code,$expire,$type,$uid,$phone,$g_sign,$g_templateid,$sms_param);
                    }
                }



                switch ($retdata){
                    case 'success':
                        echo json_encode(array('code' => 200,'data' => 'smssuccess'));
                        break;
                    case 'error':
                        echo json_encode(array('code' => -1,'data' => 'smserror'));
                        break;
                    default:
                        echo json_encode(array('code' => -1,'data' => 'smserror'));
                        break;
                }
            }else{
                echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
                exit();
            }
        }catch (Exception $e) {
            echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
            exit();
        }
    }elseif($_config['g_issms'] == "3"){
        try {
            $_configisms = $_G['cache']['plugin']['jzsjiale_isms'];
            if(empty($_configisms)){
                echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
                exit();
            }

            $phone = addslashes($_GET['phone']);
            if(empty($phone)){
                echo json_encode(array('code' => -1,'data' => 'paramerror'));
                exit;
            }


            if (!preg_match("/^1[0123456789]{1}\d{9}$/", $phone)) {
                echo json_encode(array('code' => -1,'data' => 'bind_phone_error'));
                exit;
            }

            $type = intval($_GET[type]);

            $user =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_mobile($phone);
            if ($user && ($type == 1 || $type == 2)) {
                echo json_encode(array('code' => -1,'data' => 'err_phonebind'));
                exit;
            }
            if (!$user && ($type == 3 || $type == 4)) {
                echo json_encode(array('code' => -1,'data' => 'err_nouser'));
                exit;
            }

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/ismsapi.inc.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/ismsapi.inc.php';
                $ismsapi = new ISMSApi();

                $codelength = 6;
                if(!empty($_configisms['g_seccodebits']) && $_configisms['g_seccodebits'] != 6){
                    $codelength = $_configisms['g_seccodebits'];
                }
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
                $ismsutils = new ISMSUtils();
                $code = $ismsutils->generate_code($codelength);

                if(empty($code) || $code == null){
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_generatecode_error');
                    api_core::result($result);
                }

                $uid = $_G['uid']?$_G['uid']:($user['uid']?$user['uid']:0);
                $areacode = "86";
                $sendsmsresult = $ismsapi->smssend($areacode,$phone,$code,$type,$uid);

                switch ($sendsmsresult){
                    case 1:
                        echo json_encode(array('code' => 200,'data' => 'smssuccess'));
                        break;
                    case 0:
                        echo json_encode(array('code' => -1,'data' => 'smserror'));
                        break;
                    default:
                        echo json_encode(array('code' => -1,'data' => 'smserror'));
                        break;
                }

            }else{
                echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
                exit();
            }


        }catch (Exception $e) {
            echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
            exit();
        }
    }

    
    
}elseif($act == 'phoneregister'){
    header("Content-Type: text/html; charset=".$_G['charset']);
    
    global $_G;

    $formhash = $_GET['formhash'];
    
    if(empty($formhash) || $formhash != FORMHASH){
        echo json_encode(array('code' => -1,'data' => 'paramerror'));
        exit();
    }

    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    if(empty($_config['g_issms']) || $_config['g_issms'] == "0"){
        echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
        exit();
    }

    $phone = addslashes($_GET['phone']);
    $seccode = addslashes($_GET['seccode']);
    $username = addslashes($_GET['username']);
    $password = addslashes($_GET['password']);



    if(empty($phone)){
        echo json_encode(array('code' => -1,'data' => 'phonenull'));
        exit;
    }

    if (!preg_match("/^1[0123456789]{1}\d{9}$/", $phone)) {
        echo json_encode(array('code' => -1,'data' => 'bind_phone_error'));
        exit;
    }

    if(empty($seccode)){
        echo json_encode(array('code' => -1,'data' => 'seccodenull'));
        exit;
    }

    if(empty($username)){
        echo json_encode(array('code' => -1,'data' => 'usernamenull'));
        exit;
    }

    if(empty($password)){
        echo json_encode(array('code' => -1,'data' => 'passwordnull'));
        exit;
    }

    if(strlen($password)<6){
        echo json_encode(array('code' => -1,'data' => 'password6'));
        exit;
    }

    if($_config['g_issms'] == "1" || $_config['g_issms'] == "2"){
        try {
            $_configsms = $_G['cache']['plugin']['jzsjiale_sms'];
            if(empty($_configsms)){
                echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
                exit();
            }


            $codeinfo = C::t('#jzsjiale_sms#jzsjiale_sms_code')->fetchfirst_by_phone_and_seccode($phone,$seccode);
            if ($codeinfo) {
                if ((TIMESTAMP - $codeinfo[dateline]) > $_configsms['g_youxiaoqi']) {
                    C::t('#jzsjiale_sms#jzsjiale_sms_code')->deleteby_seccode_and_phone($phone,$seccode);
                    //C::t('#jzsjiale_sms#jzsjiale_sms_smslist')->deleteby_seccode_and_phone($phone,$seccode);
                    echo json_encode(array('code' => -1,'data' => 'err_seccodeguoqi'));
                    exit;
                }
            } else {
                echo json_encode(array('code' => -1,'data' => 'err_seccodeerror'));
                exit;
            }

            if($_configsms['g_tongyiuser']){
                //20170805 add start
                $phoneuser =  C::t('#jzsjiale_sms#jzsjiale_sms_member')->fetch_by_mobile($phone);
                //20170805 add end
            }else{
                $phoneuser = C::t('#jzsjiale_sms#jzsjiale_sms_user')->fetch_by_phone($phone);
            }


            if(!empty($phoneuser)){
                echo json_encode(array('code' => -1,'data' => 'phonecunzai'));
                exit;
            }

            $username = iconv('UTF-8', CHARSET.'//ignore', urldecode($username));
            $email = "reg_".substr($phone,0,3).time().substr($phone,7,4)."@null.null";

            $user = C::t('common_member')->fetch_by_username($username);
            if($user){
                echo json_encode(array('code' => -1,'data' => 'usernamecunzai'));
                exit;
            }

            $profile = array (
                "mobile" => $phone,
            );

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_sms/uc.inc.php')){
                require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_sms/uc.inc.php';
            }else{
                echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
                exit();
            }

            $uid = UC::regist($username,$password,$email,$profile);
            if (!is_numeric($uid)) {
                echo json_encode(array('code' => -1,'data' => 'registererror'));
                exit;
            }


            $isregok = false;
            if($_configsms['g_tongyiuser']){
                //20170805 add start
                $userinfo =  C::t('#jzsjiale_sms#jzsjiale_sms_member')->fetch_by_uid($uid);

                if ($uid && $phone && $seccode && empty($userinfo['mobile'])) {

                    $isregok = true;
                }
                //20170805 add end
            }else{
                $userinfo = C::t('#jzsjiale_sms#jzsjiale_sms_user')->fetch_by_uid($uid);

                if ($uid && $phone && $seccode && !$userinfo) {

                    $isregok = true;
                }
            }



            if ($isregok) {

                $data = array(
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'phone' => $codeinfo['phone'],
                    'dateline' => TIMESTAMP
                );

                C::t('#jzsjiale_sms#jzsjiale_sms_user')->insert($data, true);

                C::t('common_member_profile')->update($_G['uid'], array('mobile'=> $phone));

                C::t('#jzsjiale_sms#jzsjiale_sms_code')->deleteby_seccode_and_phone($phone,$seccode);
                echo json_encode(array(
                    'code' => 200,
                    'data' => 'registersuccess'
                ));
                exit();

            }else{
                C::t('#jzsjiale_sms#jzsjiale_sms_code')->deleteby_seccode_and_phone($phone,$seccode);
                echo json_encode(array(
                    'code' => 200,
                    'data' => 'registersuccess_phoneerror'
                ));
                exit();
            }

        }catch (Exception $e) {
            echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
            exit();
        }
    }elseif($_config['g_issms'] == "3"){
        try {
            $_configisms = $_G['cache']['plugin']['jzsjiale_isms'];
            if(empty($_configisms)){
                echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
                exit();
            }
            $areacode = "86";
            $codeinfo = C::t('#jzsjiale_isms#jzsjiale_isms_code')->fetchfirst_by_areacode_phone_seccode($areacode,$phone,$seccode);
            if ($codeinfo) {
                if ((TIMESTAMP - $codeinfo[dateline]) > $_configisms['g_youxiaoqi']) {
                    C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);
                    echo json_encode(array('code' => -1,'data' => 'err_seccodeguoqi'));
                    exit;
                }
            } else {
                echo json_encode(array('code' => -1,'data' => 'err_seccodeerror'));
                exit;
            }

            $field = (!empty($_configisms['g_areacodefield']) && in_array($_configisms['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_configisms['g_areacodefield']:'field8';
            $mobileuser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($areacode, $phone, $field);

            if(!empty($mobileuser)){
                echo json_encode(array('code' => -1,'data' => 'phonecunzai'));
                exit;
            }
            $username = iconv('UTF-8', CHARSET.'//ignore', urldecode($username));
            $g_emailprefix = !empty($_configisms['g_emailprefix'])?$_configisms['g_emailprefix']:"isms.com";
            $email = time().substr($phone,-3)."@".$g_emailprefix;

            $profile = array (
                "mobile" => $phone,
            );
            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/uc.inc.php')){
                require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/uc.inc.php';
            }else{
                echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
                exit();
            }
            $uid = UC::regist($username,$password,$email,$profile);
            if (!is_numeric($uid)) {
                echo json_encode(array('code' => -1,'data' => 'registererror'));
                exit;
            }

            $isregok = false;
            $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_member_by_uid($uid);
            if ($uid && $phone && $seccode && empty($userinfo['mobile'])) {

                $isregok = true;
            }

            if ($isregok) {


                C::t('common_member_profile')->update($_G['uid'], array('mobile' => $phone,$field => $areacode));

                C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);
                echo json_encode(array(
                    'code' => 200,
                    'data' => 'registersuccess'
                ));
                exit();

            }else{
                C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);
                echo json_encode(array(
                    'code' => 200,
                    'data' => 'registersuccess_phoneerror'
                ));
                exit();
            }

        }catch (Exception $e) {
            echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
            exit();
        }

    }

}elseif($act == 'phonelogin'){
    header("Content-Type: text/html; charset=".$_G['charset']);
    
    global $_G;
    $_configsms = $_G['cache']['plugin']['jzsjiale_sms'];
    
    $formhash = $_GET['formhash'];
    
    if(empty($formhash) || $formhash != FORMHASH){
        echo json_encode(array('code' => -1,'data' => 'paramerror'));
        exit();
    }
    
    try {
    
        $phone = addslashes($_GET['phone']);
        $password = addslashes($_GET['password']);
    
         
    
        if(empty($phone)){
            echo json_encode(array('code' => -1,'data' => 'phonenull'));
            exit;
        }
    
        if (!preg_match("/^1[34578]{1}\d{9}$/", $phone)) {
            echo json_encode(array('code' => -1,'data' => 'bind_phone_error'));
            exit;
        }
    
        if(empty($password)){
            echo json_encode(array('code' => -1,'data' => 'passwordnull'));
            exit;
        }
    
        if(strlen($password)<6){
            echo json_encode(array('code' => -1,'data' => 'password6'));
            exit;
        }
        
        require_once libfile('function/misc');
        loaducenter();
         
        require_once libfile('function/member');
        
        
        $_G['uid'] = $_G['member']['uid'] = 0;
        $_G['username'] = $_G['member']['username'] = $_G['member']['password'] = '';
        
        
        if($_configsms['g_tongyiuser']){
            //20170805 add start
            $userinfo =  C::t('#jzsjiale_sms#jzsjiale_sms_member')->fetch_by_mobile($phone);
            //20170805 add end
        }else{
            $userinfo = C::t('#jzsjiale_sms#jzsjiale_sms_user')->fetch_by_phone($phone);
            if(!empty($userinfo)){
                if(empty($userinfo['username'])){
                    C::t('#jzsjiale_sms#jzsjiale_sms_user')->deletebyid($userinfo['id']);
                    $userinfo = array();
                    echo json_encode(array('code' => -1,'data' => 'err_weibangding'));
                    exit;
                }
            }
        }
        
        
        
        if(empty($userinfo)){
            echo json_encode(array('code' => -1,'data' => 'err_weibangding'));
            exit;
        }
        
        $member = getuserbyuid($userinfo['uid'], 1);
        if (!$member || empty($member['uid'])) {
            C::t('#jzsjiale_sms#jzsjiale_sms_user')->deletebyphone($phone);
            echo json_encode(array('code' => -1,'data' => 'err_weibangding'));
            exit;
        }
        
        if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_sms/uc.inc.php')){
            require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_sms/uc.inc.php';
        }else{
            echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
            exit();
        }
        
        $uid = UC::logincheck($member['username'],$password);
        if (!is_numeric($uid)) {
            echo json_encode(array('code' => -1,'data' => 'mimaerror'));
            exit;
        }
      
        if($member['uid'] != $uid){
            echo json_encode(array('code' => -1,'data' => 'loginerror'));
            exit;
        }
        
        if ($member['_inarchive']) {
            C::t('common_member_archive')->move_to_master($member['uid']);
        }
        
        setloginstatus($member, $_GET['cookietime'] ? 2592000 : 0);
        checkfollowfeed();
        if ($_G['group']['forcelogin']) {
            if ($_G['group']['forcelogin'] == 1) {
                clearcookies();
                echo json_encode(array('code' => -1,'data' => 'err_location_login_force_qq'));
                exit;
            } elseif ($_G['group']['forcelogin'] == 2 && $_GET['loginfield'] != 'email') {
                clearcookies();
                echo json_encode(array('code' => -1,'data' => 'err_location_login_force_mail'));
                exit;
            }
        }
        if ($_G['member']['lastip'] && $_G['member']['lastvisit']) {
            dsetcookie('lip', $_G['member']['lastip'] . ',' . $_G['member']['lastvisit']);
        }
        C::t('common_member_status')->update($_G['uid'], array('lastip' => $_G['clientip'], 'port' => $_G['remoteport'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));
        $ucsynlogin = $_G['setting']['allowsynlogin'] ? uc_user_synlogin($_G['uid']) : '';
        
        
        
        if ($_G['member']['adminid'] != 1) {
            if ($_G['setting']['accountguard']['loginoutofdate'] && $_G['member']['lastvisit'] && TIMESTAMP - $_G['member']['lastvisit'] > 90 * 86400) {
                C::t('common_member')->update($_G['uid'], array('freeze' => 2));
                C::t('common_member_validate')->insert(array(
                'uid' => $_G['uid'],
                'submitdate' => TIMESTAMP,
                'moddate' => 0,
                'admin' => '',
                'submittimes' => 1,
                'status' => 0,
                'message' => '',
                'remark' => '',
                ), false, true);
                manage_addnotify('verifyuser');
                echo json_encode(array('code' => -1,'data' => 'err_location_login_outofdate'));
                exit;
                //showmessage('location_login_outofdate', 'home.php?mod=spacecp&ac=profile&op=password&resend=1', array('type' => 1), array('showdialog' => true, 'striptags' => false, 'locationtime' => true));
            }
        }
        
        $param = array(
            'username' => $_G['member']['username'],
            'usergroup' => $_G['group']['grouptitle'],
            'uid' => $_G['member']['uid'],
            'groupid' => $_G['groupid'],
            'syn' => $ucsynlogin ? 1 : 0
        );
        $extra = array(
            'showdialog' => true,
            'locationtime' => true,
            'extrajs' => $ucsynlogin
        );
      
        
        echo json_encode(array('code' => 200,'data' => 'loginsuccess'));
        exit;
        
    }catch (Exception $e) {
        echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
        exit();
    }  
}elseif($act == 'phonelogout'){
    header("Content-Type: text/html; charset=".$_G['charset']);
    
    global $_G;
    
    $formhash = $_GET['formhash'];
    
    if(empty($formhash) || $formhash != FORMHASH){
        echo json_encode(array('code' => -1,'data' => 'paramerror'));
        exit();
    }
    
    try {
        if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_sms/uc.inc.php')){
            require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_sms/uc.inc.php';
        }else{
            echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
            exit();
        }
        
        UC::dologout();
        echo json_encode(array('code' => 200,'data' => 'logoutsuccess'));
        exit;
    }catch (Exception $e) {
            echo json_encode(array('code' => -1,'data' => 'smsconfigerror'));
            exit();
    }
}elseif($act == 'jsapi'){
    $callback = $_GET['callback'];
    $url = $_GET['url'];
    $url = urldecode($url);
    if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/jssdk.php')){
        require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/jssdk.php';
        
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
      
        $appId=$_config['g_wxappid'];
        $appSecret=$_config['g_wxappsecret'];
        
        if(empty($appId) || empty($appSecret)){
            $tmp = json_encode(array('code' => -1,'data' => array()));
            echo $callback.'('.$tmp.')';
            exit();
        }
        
        $jssdk = new JSSDK($appId, $appSecret,$url);
        $signpackage = $jssdk->getSignPackage();
      
        if(!empty($signpackage)){
            $tmp = json_encode(array('code' => 200,'data' =>  $signpackage));
            echo $callback.'('.$tmp.')';
            exit();
        }else{
            $tmp = json_encode(array('code' => -1,'data' => array()));
            echo $callback.'('.$tmp.')';
            exit();
        }
    }else{
        $tmp = json_encode(array('code' => -1,'data' => array()));
        echo $callback.'('.$tmp.')';
        exit();
    }
}elseif($act == 'delunusedimg'){
    
    $aid = intval($_GET['aid']);
    if(!empty($aid)){
        C::t('forum_attachment_unused')->delete($aid);
    }
    echo json_encode(array('code' => 200,'data' => 'delsucess'));
    exit;
}elseif($act == 'souquan'){

    $keyword = addslashes($_GET['keyword']);
    $page = intval($_GET['page']);
    $pagesize = intval($_GET['pagesize']);
    $formhash = addslashes($_GET['formhash']);

    if($formhash != FORMHASH){
        echo json_encode(array('code' => 400,'data' => array()));
        exit();
    }
    $page = $page > 0 ? $page : 1;
    $pagesize = $pagesize > 0 ? $pagesize : 20;

    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    $tbappkey = $_config['g_appkey'];
    $tbsecretKey = $_config['g_appsecret'];
    $pid = $_config['g_pid'];
    $webbianma = $_G['charset'];

    if(empty($pid)){
        cpmsg('jzsjiale_daogou:pidnull', '', 'error');
        dexit();
    }

    $adzoneId = explode("_",$pid);
    $adzoneId = $adzoneId[3];

    if(empty($adzoneId)){
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }

    if(!empty($keyword) && $webbianma == 'gbk') {
        $keyword = diconv($keyword,'UTF-8','GBK');
    }
    if(empty($keyword)){
        $g_souquantjc = $_config['g_souquantjc'];
        $rand_souquantjc = explode(',',$g_souquantjc);
        $rand_souquantjc_index = array_rand($rand_souquantjc,1);
        $keyword = $rand_souquantjc[$rand_souquantjc_index];
    }

    $shangpin = array();

    //fliggy start
    if(strpos($keyword,'traveldetail.fliggy.com') !==false){
        $fliggydata = getparam($keyword);
        $fliggyid = $fliggydata['id'];

        if(!empty($fliggyid) && $fliggyid != null){
            $keyword = "https://item.taobao.com/item.htm?id=".$fliggyid;
        }
    }
    //fliggy end

    $dsp = array();
    $dsp['q'] = $keyword;
    $dsp['sort'] = "total_sales_des";
    $dsp['has_coupon'] = true;
    $dsp['currpage'] = $page;
    $dsp['page_size'] = $pagesize;

    require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';
    $gtkl = new GetTbAPI;
    $gtkl->__construct($tbappkey, $tbsecretKey);
    $tbinfo =  $gtkl->getdgmaterialoptional($dsp,$adzoneId,$webbianma);

    $tbinfo = json_decode($tbinfo);

    $splistinfo = $tbinfo->result_list->map_data;

    foreach($splistinfo as $spi){

        $coupon_start_time = $spi->coupon_start_time;
        $coupon_end_time = $spi->coupon_end_time;
        //$info_dxjh = $spi->info_dxjh;
        $tk_total_sales = $spi->tk_total_sales;
        //$tk_total_commi = $spi->tk_total_commi;
        //$coupon_id = $spi->coupon_id;
        //$num_iid = $spi->num_iid;
        $title = $spi->title;
        $pict_url = $spi->pict_url;
        //$small_images = $spi->small_images;
        $reserve_price = $spi->reserve_price;
        $zk_final_price = $spi->zk_final_price;
        $user_type = $spi->user_type;
        $provcity = $spi->provcity;
        $item_url = $spi->item_url;
        //$include_mkt = $spi->include_mkt;
        //$include_dxjh = $spi->include_dxjh;
        $commission_rate = $spi->commission_rate;
        $volume = $spi->volume;
        //$seller_id = $spi->seller_id;
        $coupon_total_count = $spi->coupon_total_count;
        $coupon_remain_count = $spi->coupon_remain_count;
        $coupon_info = $spi->coupon_info;
        //$commission_type = $spi->commission_type;
        $shop_title = $spi->shop_title;
        $shop_dsr = $spi->shop_dsr;
        $coupon_share_url = $spi->coupon_share_url;
        $url = $spi->url;
        /*
        $level_one_category_name = $spi->level_one_category_name;
        $level_one_category_id = $spi->level_one_category_id;
        $category_name = $spi->category_name;
        $category_id = $spi->category_id;
        $short_title = $spi->short_title;
        $white_image = $spi->white_image;
        $oetime = $spi->oetime;
        $ostime = $spi->ostime;
        $jdd_num = $spi->jdd_num;
        $jdd_price = $spi->jdd_price;
        $uv_sum_pre_sale = $spi->uv_sum_pre_sale;
        $x_id = $spi->x_id);
        */
        $coupon_start_fee = $spi->coupon_start_fee;
        $coupon_amount = $spi->coupon_amount;
        //$item_description = $spi->item_description;
        $nick = $spi->nick;
        /*
        $orig_price = $spi->orig_price;
        $total_stock = $spi->total_stock;
        $sell_num = $spi->sell_num;
        $stock = $spi->stock;
        $tmall_play_activity_info = $spi->tmall_play_activity_info;
        */
        $item_id = $spi->item_id;
        $real_post_fee = $spi->real_post_fee;



        $sp_url = "";
        if(!empty($url)){
            $sp_url = $url;
        }else{
            $sp_url = $item_url;
        }

        $sptmp = array();
        $sptmp['numiid'] = $item_id;
        $sptmp['title'] = $title;
        $sptmp['xianjia'] = $zk_final_price - $coupon_amount;
        $sptmp['user_type'] = $user_type;
        $sptmp['img'] = ((strpos($pict_url,'http') ===false)?'https:':'').$pict_url;
        $sptmp['youhuiquan'] = (!empty($coupon_share_url)?((strpos($coupon_share_url,'http') ===false)?'https:':'').$coupon_share_url:'');
        $sptmp['url'] = ((strpos($sp_url,'http') ===false)?'https:':'').$sp_url;
        $sptmp['couponamount'] = $coupon_amount;
        $sptmp['coupontotalcount'] = $coupon_total_count;
        $sptmp['couponremaincount'] = $coupon_remain_count;
        $sptmp['couponstarttime'] = $coupon_start_time;
        $sptmp['couponendtime'] = $coupon_end_time;

        if($_config['g_sqneilian']){
            if(!empty($sptmp['url'])){
                $tbk_url_data = base64_encode($sptmp['url']);
                $tbk_url_data = str_replace(array('+','/','='),array('-','_',''),$tbk_url_data);

                $sptmp['url'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=zjzr&spurl='.$tbk_url_data;
            }
            if(!empty($sptmp['youhuiquan'])){
                $tbk_youhuiquanurl_data = base64_encode($sptmp['youhuiquan']);
                $tbk_youhuiquanurl_data = str_replace(array('+','/','='),array('-','_',''),$tbk_youhuiquanurl_data);

                $sptmp['youhuiquan'] = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=zjzr&spurl='.$tbk_youhuiquanurl_data;
            }

        }
        if(!empty($sptmp)){
            $shangpin[] = $sptmp;
        }
    }

    //var_dump($shangpin);exit;
    $shangpin = dhtmlspecialchars($shangpin);
    header("Content-Type: text/html; charset=".$_G['charset']);
    if(!empty($shangpin)){
        echo json_encode(array('code' => 200,'data' => $shangpin));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}elseif($act == 'souquanci'){
    $formhash = addslashes($_GET['formhash']);

    if($formhash != FORMHASH){
        echo json_encode(array('code' => 400,'data' => array()));
        exit();
    }

    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    $g_souquantjc = $_config['g_souquantjc'];
    $webbianma = $_G['charset'];
    $rand_souquantjc = explode(',',$g_souquantjc);
    $rand_size = count($rand_souquantjc) < 10 ? count($rand_souquantjc) : 10;
    $rand_souquantjc_index = array_rand($rand_souquantjc,$rand_size);
    $souquanci = array();
    foreach ($rand_souquantjc_index as $sqci){
        if($webbianma == 'gbk') {
            $souquanci[] = diconv($rand_souquantjc[$sqci],'GBK','UTF-8');
        }else{
            $souquanci[] = $rand_souquantjc[$sqci];
        }
    }

    $souquanci = dhtmlspecialchars($souquanci);
    header("Content-Type: text/html; charset=".$_G['charset']);
    if(!empty($souquanci)){
        echo json_encode(array('code' => 200,'data' => $souquanci));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
} elseif($act == 'gettkl'){
    $formhash = addslashes($_GET['formhash']);

    if($formhash != FORMHASH){
        echo json_encode(array('code' => 400,'data' => array()));
        exit();
    }

    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    $tbappkey = $_config['g_appkey'];
    $tbsecretKey = $_config['g_appsecret'];
    $webbianma = $_G['charset'];

    $title = addslashes($_GET['title']);
    $url = addslashes($_GET['url']);
    $img = addslashes($_GET['img']);

    $title = urldecode($title);
    $url = urldecode($url);
    $img = urldecode($img);


    require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';
    $gtkl = new GetTbAPI;
    $gtkl->__construct($tbappkey, $tbsecretKey);
    $tbktkl_get =  $gtkl->gettkl($title,$url,$img,$webbianma);

    $tbktkl_get = json_decode($tbktkl_get,true);
    $tbktkl = $tbktkl_get['model'];
    $tbktklsimple = $tbktkl_get['password_simple'];

    $tbktkl = dhtmlspecialchars($tbktkl);
    $tbktklsimple = dhtmlspecialchars($tbktklsimple);
    header("Content-Type: text/html; charset=".$_G['charset']);
    if(!empty($tbktkl)){
        echo json_encode(array('code' => 200,'data' => array('tkl' => $tbktkl, 'tklsimple' => $tbktklsimple)));
        exit();
    }else{
        echo json_encode(array('code' => 200,'data' => array()));
        exit();
    }
}

function getparam($str){
    $data = array();
    $parameter = explode('&',end(explode('?',$str)));
    foreach($parameter as $val){
        $tmp = explode('=',$val);
        $data[$tmp[0]] = $tmp[1];
    }
    return $data;
}

function getCover($tid){
    $pic=DB::fetch_first("SELECT attachment,remote FROM ".DB::table('forum_threadimage')." where tid='$tid'");
    if(empty($pic) || $pic == null){
        $pic=DB::fetch_first("SELECT attachment,remote FROM ".DB::table('forum_attachment_'.($tid%10))." where tid='$tid' and isimage=1");
    }
    return $pic;
}
function getbianma($data, $webbianma = "gbk",$openhtmlspecialchars = true)
{
    if ($webbianma == "gbk") {
        $data = diconv($data, 'GBK', 'UTF-8');
    }
    $data = isset($data) ? trim(htmlspecialchars($data, ENT_QUOTES)) : '';
    return $data;
}
function generate_code($length = 6)
{
    return rand(pow(10, ($length - 1)), pow(10, $length) - 1);
}