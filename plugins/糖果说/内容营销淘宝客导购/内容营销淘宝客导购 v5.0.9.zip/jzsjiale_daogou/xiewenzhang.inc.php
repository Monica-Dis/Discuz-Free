<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$gettid = $_GET['tid'];
$getpid = $_GET['pid'];
$getfid = $_GET['fid'];

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_daogou'];
$g_dulixiewenzhang = $_config['g_dulixiewenzhang'];

if($_G[jzsjiale_tpl_daogou][isopenpost] && $g_dulixiewenzhang)
{
    if(!in_array ( "xiewenzhang", (array)unserialize($_config['g_alone']) )){
        showmessage(lang('plugin/jzsjiale_daogou','function_closed'), $_G['siteurl']);
    }

    $articleId = "";
    $pid = "";
    if(!empty($gettid) && !empty($getpid) && !empty($getfid)){
        
        if(empty($_G['uid']) || empty($_G['username'])){
            dheader("Location: member.php?mod=logging&action=login");
            dexit();
        }
        
        require_once libfile('function/post');
        $post = C::t('forum_post')->fetch_by_pid_condition('tid:'.$gettid, $getpid);
     
        if(!empty($post)){
            if($post['authorid'] == $_G['uid'] || in_array($_G['uid'], array(1))){
                $message = $post['message'];
                $articleId = $post['tid'];
                $pid = $post['pid'];
            }
        }
    
        if (strpos($message, '[/jzsjiale_daogou_post]') === false) {
            dheader("Location: forum.php?mod=post&action=edit&fid=".$getfid."&tid=".$gettid."&pid=".$getpid."&page=1");
            dexit();
        }
       
        if(preg_match('/\s?\[jzsjiale_daogou_post\](.*?)\[\/jzsjiale_daogou_post\]\s?/is', $message, $matches)) {
            $message = $matches[1];
            $message = str_replace("\\","\\\\",$message);
            $message = str_replace("'","\'",$message);
        }else{
            dheader("Location: forum.php?mod=post&action=edit&fid=".$getfid."&tid=".$gettid."&pid=".$getpid."&page=1");
            dexit();
        }
        //$message = substr($message, strlen('[jzsjiale_daogou_post]'), strlen($message) - strlen('[jzsjiale_daogou_post]') - strlen('[/jzsjiale_daogou_post]'));
        
        
    }
    include template('jzsjiale_daogou:daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/post');
}else{
    if($_config['g_feidulixiewenzhang']){
        dheader("Location: forum.php?mod=post&action=newthread&fid=".$_config['g_feidulixiewenzhang']);
    }else{
        dheader("Location: forum.php?mod=misc&action=nav");
    }
    dexit();
}
//From: dis'.'m.tao'.'bao.com
?>