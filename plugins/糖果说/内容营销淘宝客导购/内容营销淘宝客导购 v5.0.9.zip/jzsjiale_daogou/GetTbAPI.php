<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/TopClient.php';
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/ResultSet.php';
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/TopLogger.php';
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/RequestCheckUtil.php';
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/request/WirelessShareTpwdQueryRequest.php';
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/request/TbkItemInfoGetRequest.php';
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/domain/TbkFavorites.php';
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/request/TbkDgMaterialOptionalRequest.php';
//require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/request/TbkItemGetRequest.php';
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/request/TbkJuTqgGetRequest.php';
//require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/request/TbkDgItemCouponGetRequest.php';
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/request/TbkTpwdCreateRequest.php';
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/sdk/top/request/TbkDgOptimusMaterialRequest.php';

class GetTbAPI
{

    public $appkey;
    
    public $secretKey;
    
    public function __construct($appkey = "",$secretKey = ""){
        $this->appkey = $appkey;
        $this->secretKey = $secretKey ;
    }
    
    public function gettkl($title = "", $url = "", $logo = "",$webbianma = "gbk")
    {

        if ($webbianma == "gbk") {
            $title = diconv($title,'GBK', 'UTF-8');
            $url = diconv($url,'GBK', 'UTF-8');
            $logo = diconv($logo,'GBK', 'UTF-8');
        }
        $text = isset($title) ? trim(htmlspecialchars($title, ENT_QUOTES)) : lang('plugin/jzsjiale_daogou', 'tkltitle');
        $url = isset($url) ? trim(htmlspecialchars($url, ENT_QUOTES)) : '';
        $logo = isset($logo) ? trim(htmlspecialchars($logo, ENT_QUOTES)) : '';
       
        if(strpos($url, "uland.taobao.com") && strpos($url, "activityId")){
            $url= htmlspecialchars_decode($url, ENT_QUOTES);
        }
        
        
        date_default_timezone_set('Asia/Shanghai');
        
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $g_tklapi = $_config['g_tklapi'];
        if(empty($g_tklapi)){
            $g_tklapi = "mianfei";
        }
        
        if($g_tklapi == "mianfei"){
            $c = new TopClient;
            $c->format = 'json';
            $c->appkey = $this->appkey;
            $c->secretKey = $this->secretKey;
            $req = new TbkTpwdCreateRequest;
            $req->setUserId("0");
            $req->setText($text);
            $req->setUrl($url);
            $req->setLogo($logo);
            $req->setExt("{}");
            $resp = $c->execute($req);
           
            $resp = $resp->data;
        }
        
        //2018.9.30 change
        /*
        if($g_tklapi == "zhineng"){
            
            //youxian mianfei
            $c = new TopClient;
            $c->format = 'json';
            $c->appkey = $this->appkey;
            $c->secretKey = $this->secretKey;
            $req = new TbkTpwdCreateRequest;
            $req->setUserId("0");
            $req->setText($text);
            $req->setUrl($url);
            $req->setLogo($logo);
            $req->setExt("{}");
            $resp = $c->execute($req);
       
            $resp = $resp->data;
            
            if($resp == null || empty($resp) || empty($resp->model)){
                $c = new TopClient();
                $c->format = 'json';
                $c->appkey = $this->appkey;
                $c->secretKey = $this->secretKey;
                $req = new WirelessShareTpwdCreateRequest();
                $tpwd_param = new GenPwdIsvParamDto();
                $tpwd_param->text = $text;
                $tpwd_param->url = $url;
                $tpwd_param->logo = $logo;
                $tpwd_param->user_id = "0";
                $req->setTpwdParam(json_encode($tpwd_param));
                $resp = $c->execute($req);
            }
            
            
        }elseif($g_tklapi == "mianfei"){
            $c = new TopClient;
            $c->format = 'json';
            $c->appkey = $this->appkey;
            $c->secretKey = $this->secretKey;
            $req = new TbkTpwdCreateRequest;
            $req->setUserId("0");
            $req->setText($text);
            $req->setUrl($url);
            $req->setLogo($logo);
            $req->setExt("{}");
            $resp = $c->execute($req);
       
            $resp = $resp->data;
        }else{
            $c = new TopClient();
            $c->format = 'json';
            $c->appkey = $this->appkey;
            $c->secretKey = $this->secretKey;
            $req = new WirelessShareTpwdCreateRequest();
            $tpwd_param = new GenPwdIsvParamDto();
            $tpwd_param->text = $text;
            $tpwd_param->url = $url;
            $tpwd_param->logo = $logo;
            $tpwd_param->user_id = "0";
            $req->setTpwdParam(json_encode($tpwd_param));
            $resp = $c->execute($req);
            
        }
        */
        //return $resp->model;
        return json_encode($resp);
    }
    
    

    
    public function gettbinfo($id = "")
    {
        date_default_timezone_set('Asia/Shanghai');

        $c = new TopClient;
        $c->format = 'json';
        $c->appkey = $this->appkey;
        $c->secretKey = $this->secretKey;
        $req = new TbkItemInfoGetRequest;
        //$req->setFields("num_iid,title,pict_url,small_images,reserve_price,zk_final_price,user_type,provcity,item_url");
        $req->setPlatform("1");
        $req->setNumIids($id);
        $resp = $c->execute($req);
        
        //return $resp->model;
        return json_encode($resp);
    }
    
    public function getxuanpinkulist($pageNo ="1",$dzoneId = "")
    {
        date_default_timezone_set('Asia/Shanghai');

        /*
        $c = new TopClient;
        $c->format = 'json';
        $c->appkey = $this->appkey;
        $c->secretKey = $this->secretKey;
        $req = new TbkUatmFavoritesGetRequest;
        $req->setPageNo($pageNo);
        $req->setPageSize("200");
        $req->setFields("favorites_title,favorites_id,type");
        $req->setType("-1");
        $resp = $c->execute($req);
        */

        $c = new TopClient;
        $c->appkey = $this->appkey;
        $c->secretKey = $this->secretKey;
        $req = new TbkDgOptimusMaterialRequest;
        $req->setPageSize("100");
        $req->setAdzoneId($dzoneId);
        $req->setPageNo($pageNo);
        $req->setMaterialId("31519");
        $resp = $c->execute($req);
    
        //return $resp->model;
        return json_encode($resp);
    }
    
    public function getxuanpinkushangpin($favoritesId = "",$dzoneId = "",$pageNo ="1")
    {
        date_default_timezone_set('Asia/Shanghai');

        $c = new TopClient;
        $c->appkey = $this->appkey;
        $c->secretKey = $this->secretKey;
        $req = new TbkDgOptimusMaterialRequest;
        $req->setPageSize("100");
        $req->setAdzoneId($dzoneId);
        $req->setPageNo($pageNo);
        $req->setMaterialId("31539");
        $req->setFavoritesId($favoritesId);
        $resp = $c->execute($req);
    
        //return $resp->model;
        return json_encode($resp);
    }

    //chaojisousuo
    public function getdgmaterialoptional($dsp, $adzoneId = "", $webbianma = "gbk")
    {
        $q = $this->getbianma($dsp['q'],$webbianma);
        $itemloc = $this->getbianma($dsp['itemloc'],$webbianma);
        $sort = $this->getbianma($dsp['sort'],$webbianma);
        $has_coupon = $this->getbianma($dsp['has_coupon'],$webbianma);
        $is_tmall = $this->getbianma($dsp['is_tmall'],$webbianma);
        $is_overseas = $this->getbianma($dsp['is_overseas'],$webbianma);
        $need_free_shipment = $this->getbianma($dsp['need_free_shipment'],$webbianma);
        $need_prepay = $this->getbianma($dsp['need_prepay'],$webbianma);
        $start_price = $this->getbianma($dsp['start_price'],$webbianma);
        $end_price = $this->getbianma($dsp['end_price'],$webbianma);
        $start_tk_rate = $this->getbianma($dsp['start_tk_rate'],$webbianma);
        $end_tk_rate = $this->getbianma($dsp['end_tk_rate'],$webbianma);
        $page_no = $this->getbianma($dsp['page_no'],$webbianma);
        $currpage = $this->getbianma($dsp['currpage'],$webbianma);
        $page_size = $this->getbianma($dsp['page_size'],$webbianma);
        $start_dsr = $this->getbianma($dsp['start_dsr'],$webbianma);
        $include_pay_rate_30 = $this->getbianma($dsp['include_pay_rate_30'],$webbianma);
        $include_good_rate = $this->getbianma($dsp['include_good_rate'],$webbianma);
        $include_rfd_rate = $this->getbianma($dsp['include_rfd_rate'],$webbianma);

        if($has_coupon){
            $has_coupon = 'true';
        }else{
            $has_coupon = 'false';
        }

        if($is_tmall){
            $is_tmall = 'true';
        }else{
            $is_tmall = 'false';
        }

        if($is_overseas){
            $is_overseas = 'true';
        }else{
            $is_overseas = 'false';
        }

        if($need_free_shipment){
            $need_free_shipment = 'true';
        }else{
            $need_free_shipment = 'false';
        }

        if($need_prepay){
            $need_prepay = 'true';
        }else{
            $need_prepay = 'false';
        }

        if($include_pay_rate_30){
            $include_pay_rate_30 = 'true';
        }else{
            $include_pay_rate_30 = 'false';
        }

        if($include_good_rate){
            $include_good_rate = 'true';
        }else{
            $include_good_rate = 'false';
        }

        if($include_rfd_rate){
            $include_rfd_rate = 'true';
        }else{
            $include_rfd_rate = 'false';
        }

        if(empty($currpage)){
            $currpage = '1';
        }
        if(empty($page_size)){
            $page_size = '20';
        }

        date_default_timezone_set('Asia/Shanghai');

        $c = new TopClient;
        $c->format = 'json';
        $c->appkey = $this->appkey;
        $c->secretKey = $this->secretKey;
        $req = new TbkDgMaterialOptionalRequest;

        if(!empty($q)){
            $req->setQ($q);
        }
        if(!empty($itemloc)){
            $req->setItemloc($itemloc);
        }
        $req->setSort($sort);
        $req->setHasCoupon($has_coupon);
        $req->setIsTmall($is_tmall);
        $req->setIsOverseas($is_overseas);
        $req->setNeedFreeShipment($need_free_shipment);
        $req->setNeedPrepay($need_prepay);
        if(!empty($start_price)){
            $req->setStartPrice($start_price);
        }
        if(!empty($end_price)){
            $req->setEndPrice($end_price);
        }
        if(!empty($start_tk_rate)){
            $req->setStartTkRate($start_tk_rate);
        }
        if(!empty($end_tk_rate)){
            $req->setEndTkRate($end_tk_rate);
        }
        $req->setPlatform("1");
        $req->setPageNo($currpage);
        $req->setPageSize($page_size);
        if(!empty($start_dsr)){
            $req->setStartDsr($start_dsr);
        }
        if(!empty($adzoneId)){
            $req->setAdzoneId($adzoneId);
        }

        $req->setIncludePayRate30($include_pay_rate_30);
        $req->setIncludeGoodRate($include_good_rate);
        $req->setIncludeRfdRate($include_rfd_rate);
        $resp = $c->execute($req);

        //return $resp->model;
        return json_encode($resp);
    }
    /*
    public function gettbkitem($dsp,$webbianma = "gbk")
    {

        $q = $this->getbianma($dsp['q'],$webbianma);
        $itemloc = $this->getbianma($dsp['itemloc'],$webbianma);
        $sort = $this->getbianma($dsp['sort'],$webbianma);
        $is_tmall = $this->getbianma($dsp['is_tmall'],$webbianma);
        $is_overseas = $this->getbianma($dsp['is_overseas'],$webbianma);
        $start_price = $this->getbianma($dsp['start_price'],$webbianma);
        $end_price = $this->getbianma($dsp['end_price'],$webbianma);
        $start_tk_rate = $this->getbianma($dsp['start_tk_rate'],$webbianma);
        $end_tk_rate = $this->getbianma($dsp['end_tk_rate'],$webbianma);
        $page_no = $this->getbianma($dsp['page_no'],$webbianma);
        $currpage = $this->getbianma($dsp['currpage'],$webbianma);
        $page_size = $this->getbianma($dsp['page_size'],$webbianma);
    
        if($is_tmall){
            $is_tmall = 'true';
        }else{
            $is_tmall = 'false';
        }
        
        if($is_overseas){
            $is_overseas = 'true';
        }else{
            $is_overseas = 'false';
        }
        if(empty($currpage)){
            $currpage = '1';
        }
        if(empty($page_size)){
            $page_size = '20';
        }
        
        date_default_timezone_set('Asia/Shanghai');

        $c = new TopClient;
        $c->format = 'json';
        $c->appkey = $this->appkey;
        $c->secretKey = $this->secretKey;
        $req = new TbkItemGetRequest;
        $req->setFields("num_iid,title,pict_url,small_images,reserve_price,zk_final_price,user_type,provcity,item_url,seller_id,volume,nick");
        $req->setQ($q);
        //$req->setCat("16,18");
        if(!empty($itemloc)){
            $req->setItemloc($itemloc);
        }
        $req->setSort($sort);
        $req->setIsTmall($is_tmall);
        $req->setIsOverseas($is_overseas);
        if(!empty($start_price)){
            $req->setStartPrice($start_price);
        }
        if(!empty($end_price)){
            $req->setEndPrice($end_price);
        }
        if(!empty($start_tk_rate)){
            $req->setStartTkRate($start_tk_rate);
        }
        if(!empty($end_tk_rate)){
            $req->setEndTkRate($end_tk_rate);
        }
        $req->setPlatform("1");
        $req->setPageNo($currpage);
        $req->setPageSize($page_size);
        $resp = $c->execute($req);
    
        //return $resp->model;
        return json_encode($resp);
    }
    */
    
    public function gettaoqianggouitem($dsp,$dzoneId = "",$webbianma = "gbk")
    {
        $starttime = $this->getbianma($dsp['starttime'],$webbianma);
        $endtime = $this->getbianma($dsp['endtime'],$webbianma);
        $page_no = $this->getbianma($dsp['page_no'],$webbianma);
        $currpage = $this->getbianma($dsp['currpage'],$webbianma);
        $page_size = $this->getbianma($dsp['page_size'],$webbianma);
        
        if(empty($currpage)){
            $currpage = '1';
        }
        if(empty($page_size)){
            $page_size = '40';
        }
        
        date_default_timezone_set('Asia/Shanghai');

        $c = new TopClient;
        $c->format = 'json';
        $c->appkey = $this->appkey;
        $c->secretKey = $this->secretKey;
        $req = new TbkJuTqgGetRequest;
        $req->setAdzoneId($dzoneId);
        $req->setFields("click_url,pic_url,reserve_price,zk_final_price,total_amount,sold_num,title,category_name,start_time,end_time");
        $req->setStartTime($starttime);
        $req->setEndTime($endtime);
        $req->setPageNo($currpage);
        $req->setPageSize($page_size);
        $resp = $c->execute($req);
        
        return json_encode($resp);
    }
    
    
    /*
    public function getyouhuiquanitem($dsp,$dzoneId = "",$webbianma = "gbk")
    {
        $q = $this->getbianma($dsp['q'],$webbianma);
        $page_no = $this->getbianma($dsp['page_no'],$webbianma);
        $currpage = $this->getbianma($dsp['currpage'],$webbianma);
        $page_size = $this->getbianma($dsp['page_size'],$webbianma);
    
        if(empty($currpage)){
            $currpage = '1';
        }
        if(empty($page_size)){
            $page_size = '40';
        }
    
        date_default_timezone_set('Asia/Shanghai');
    
        $c = new TopClient;
        $c->format = 'json';
        $c->appkey = $this->appkey;
        $c->secretKey = $this->secretKey;
        $req = new TbkDgItemCouponGetRequest;
        $req->setAdzoneId($dzoneId);
        //$req->setPlatform("1");
        //$req->setCat("16,18");
        $req->setPageSize($page_size);
        $req->setQ($q);
        $req->setPageNo($currpage);
        $resp = $c->execute($req);
    
        return json_encode($resp);
    }
    */
    
    public function get_tkl_query($password_content,$webbianma = "gbk")
    {
        $password_content = $this->getbianma($password_content,$webbianma);
    
        date_default_timezone_set('Asia/Shanghai');
        
        $c = new TopClient;
        $c->format = 'json';
        $c->appkey = $this->appkey;
        $c->secretKey = $this->secretKey;
        $req = new WirelessShareTpwdQueryRequest;
        $req->setPasswordContent($password_content);
        $resp = $c->execute($req);

        return json_encode($resp);
    }
    
    
    public function getbianma($data,$webbianma = "gbk"){
        if ($webbianma == "gbk") {
            $data = diconv($data,'GBK', 'UTF-8');
           
        }
        //$data = isset($data) ? trim(htmlspecialchars($data, ENT_QUOTES)) : '';
        return $data;
    }
  
}