<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';

$qr_url = daddslashes(trim($_GET['url']));

$qrsize = !empty($_GET['qrsize']) ? $_GET['qrsize'] : 4;
QRcode::png($qr_url, $file, QR_ECLEVEL_Q, $qrsize);
dheader('Content-Disposition: inline; filename=dg_qrcode.jpg');
dheader('Content-Type: image/pjpeg');