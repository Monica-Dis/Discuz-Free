<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
loadcache('plugin');
global $_G, $lang;

require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';
require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';

if($act=='add'){
	if(submitcheck('submit')){
	
		$sp = $_GET['sp'];
		$dsp = array('dateline'=>TIMESTAMP);
		$dsp['categoryid'] = daddslashes(trim($sp['categoryid']));
		$dsp['title'] = daddslashes(trim($sp['title']));
		$dsp['url'] = daddslashes(trim($sp['url']));
		$dsp['youhuiquan'] = daddslashes(trim($sp['youhuiquan']));
		$dsp['yuanjia'] = daddslashes(trim($sp['yuanjia']));
		$dsp['xianjia'] = daddslashes(trim($sp['xianjia']));
		$dsp['tkl'] = daddslashes(trim($sp['tkl']));
        $dsp['tklsimple'] = daddslashes(trim($sp['tklsimple']));
		$dsp['status'] = daddslashes(trim($sp['status']));
		$dsp['numiid'] = daddslashes(trim($sp['numiid']));
        $dsp['couponinfo'] = daddslashes(trim($sp['couponinfo']));
        $dsp['couponstartfee'] = daddslashes(trim($sp['couponstartfee']));
        $dsp['couponamount'] = daddslashes(trim($sp['couponamount']));
        $dsp['couponstarttime'] = daddslashes(trim($sp['couponstarttime']));
        $dsp['couponendtime'] = daddslashes(trim($sp['couponendtime']));
        $dsp['couponactivityid'] = daddslashes(trim($sp['couponactivityid']));
        $dsp['coupontotalcount'] = daddslashes(trim($sp['coupontotalcount']));
        $dsp['couponremaincount'] = daddslashes(trim($sp['couponremaincount']));
        $dsp['platform'] = daddslashes(trim($sp['platform']));
        $dsp['freeshipment'] = daddslashes(trim($sp['freeshipment']));
		
		if(!empty($dsp['tkl'])){
		   $dsp['tkldateline'] = TIMESTAMP;
		}
		
		//20180710 add
		if($_G['charset'] == 'gbk'){
		    $tklouyuantmp = urlencode($dsp['tkl']);
		    if(strpos($tklouyuantmp,'%80') !== false){
		        $dsp['tkl'] = $tklouyuantmp;
		    }
		}
		//20180710 end
		
	    if(empty($dsp['numiid']) || $dsp['numiid'] == "" || $dsp['numiid'] == null || $dsp['numiid'] == "#"){
		    $data = getparam($dsp['url']);
		    $dsp['numiid'] = $data['id'];
		}
		
		if($_FILES['img']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['img'], 'common') && $upload->save(1)) {
		        $dsp['img'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		        $dsp['attach'] = $upload->attach['attachment'];
		    }
		} else {
		    $dsp['img'] = !empty($_GET['img'])?trim($_GET['img']):"";
		}
		
		if(empty($dsp['img'])){
		    cpmsg('jzsjiale_daogou:dspnoimg', '', 'error');
		}
		
		$pattern = "/^[a-zA-z]+:\/\/[^\s]*[.]{1}(gif|jpg|png|bmp|jpeg|SS2)$/is";
		if ( !preg_match( $pattern, $dsp['img'] ) )
		{
		    cpmsg('jzsjiale_daogou:dspimgfeifa', '', 'error');
		}
		
		
		if(empty($dsp['title'])){
		    cpmsg('jzsjiale_daogou:dspnotitle', '', 'error');
		}elseif(strlen($dsp['title']) > 100) {
		    cpmsg('jzsjiale_daogou:dsptitle_more', '', 'error');
		}
		
		if(empty($dsp['url'])){
		    cpmsg('jzsjiale_daogou:dspnourl', '', 'error');
		}
		
		global $_G;
		$_config = $_G['cache']['plugin']['jzsjiale_daogou'];
		
		$pattern = "/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/is";
	    if(!empty($_config['g_urlxieyi'])){
		    $pattern = "/^((".$_config['g_urlxieyi'].")?:\/\/)[^\s]+$/is";
		}
		if ( !preg_match( $pattern, $dsp['url'] ) )
		{
		    cpmsg('jzsjiale_daogou:dspurlfeifa', '', 'error');
		}
		
		$pattern = "/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/is";
	    if(!empty($_config['g_urlxieyi'])){
		    $pattern = "/^((".$_config['g_urlxieyi'].")?:\/\/)[^\s]+$/is";
		}
		if ( !preg_match( $pattern, $dsp['youhuiquan'] ) && !empty($dsp['youhuiquan']))
		{
		    cpmsg('jzsjiale_daogou:dspyouhuiquanfeifa', '', 'error');
		}
		
		/*
	    if(empty($dsp['yuanjia'])){
		    cpmsg('jzsjiale_daogou:dspyuanjianull', '', 'error');
		}elseif(!is_numeric($dsp['yuanjia'])){
		    cpmsg('jzsjiale_daogou:dspyuanjianotnum', '', 'error');
		}
		*/
		
		if(!empty($dsp['yuanjia']) && !is_numeric($dsp['yuanjia'])){
		    cpmsg('jzsjiale_daogou:dspyuanjianotnum', '', 'error');
		}
		
		//20180912 del start
		/*
		if(empty($dsp['xianjia'])){
		    cpmsg('jzsjiale_daogou:dspxianjianull', '', 'error');
		}elseif(!is_numeric($dsp['xianjia'])){
		    cpmsg('jzsjiale_daogou:dspxianjianotnum', '', 'error');
		}
		*/
		//20180912 del end
		
		//20180912 add start
		if(!empty($dsp['xianjia']) && !is_numeric($dsp['xianjia'])){
		    cpmsg('jzsjiale_daogou:dspxianjianotnum', '', 'error');
		}
		//20180912 add end
		
		if(C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->insert($dsp,true)){
		    recache(false,$dsp['categoryid']);
			cpmsg('jzsjiale_daogou:addok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'succeed');
		}else{
			cpmsg('jzsjiale_daogou:error', '', 'error');
		}
	
	}
	
	echo '<div class="colorbox"><h4>'.plang('aboutsp').'</h4>'.
		 '<table cellspacing="0" cellpadding="3"><tr>'.
	     '<td valign="top">'.plang('spdescription').'</td></tr></table>'.
		 '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

    echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=add', 'enctype');
	
	showsubmit('submit', 'submit');
	
	showtableheader(plang('addsp'), '');
	
	$categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid(0,1);
	$categoryidselect = '<option value="0">'.plang('qingxuanze').'</option>';
	foreach($categoryids as $k =>$v){
	    $categoryidselect .= '<option value="'.$v['id'].'">'.$v['title'].'</option>';
	    
	    $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($v['id'],1);
	    
	    foreach($subcategoryids as $subk =>$subv){
	        $categoryidselect .= '<option value="'.$subv['id'].'" >&nbsp;&nbsp;&nbsp;&nbsp;'.$subv['title'].'</option>';
	         
	        $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($subv['id'],1);
	        foreach($sub3categoryids as $sub3k =>$sub3v){
	            $categoryidselect .= '<option value="'.$sub3v['id'].'" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sub3v['title'].'</option>';
	        }
	    }
	}
	showsetting(plang('dspcategoryid'),'sp[categoryid]','','<select name="sp[categoryid]">'.$categoryidselect.'</select>','',0,plang('dspcategoryid_msg'),1,'dspcategoryid');
	showsetting(plang('dsptitle'),'sp[title]','','text','','',plang('dsptitle_msg'));
	showsetting(plang('dspimg'), 'img', '', 'filetext','','',plang('dspimg_msg'),'','dspimg');
	showsetting(plang('dspurl'),'sp[url]','','text','','',plang('dspurl_msg'),'','dspurl');
	showsetting(plang('dspyouhuiquan'),'sp[youhuiquan]','','text','','',plang('dspyouhuiquan_msg'),'','dspyouhuiquan');
	showsetting(plang('dspyuanjia'),'sp[yuanjia]','','text','','',plang('dspyuanjia_msg'),'','dspyuanjia');
	showsetting(plang('dspxianjia'),'sp[xianjia]','','text','','',plang('dspxianjia_msg'),'','dspxianjia');
	showsetting(plang('dsptkl'),'sp[tkl]','','text','','',plang('dsptkl_msg'),'','dsptkl');
    showsetting(plang('dsptklsimple'),'sp[tklsimple]','','text','','',plang('dsptklsimple_msg'),'','dsptklsimple');
    showsetting(plang('dspstatus'),'sp[status]','1','radio','','',plang('dspstatus_msg'));
    showsetting(plang('dspcouponinfo'),'sp[couponinfo]','','text','','',plang('dspcouponinfo_msg'),'','dspcouponinfo');
    showsetting(plang('dspcouponstartfee'),'sp[couponstartfee]','','text','','',plang('dspcouponstartfee_msg'),'','dspcouponstartfee');
    showsetting(plang('dspcouponamount'),'sp[couponamount]','','text','','',plang('dspcouponamount_msg'),'','dspcouponamount');
    showsetting(plang('dspcouponstarttime'),'sp[couponstarttime]','','calendar','',0,plang('dspcouponstarttime_msg'),1,'dspcouponstarttime');
    showsetting(plang('dspcouponendtime'),'sp[couponendtime]','','calendar','',0,plang('dspcouponendtime_msg'),1,'dspcouponendtime');
    showsetting(plang('dspcouponactivityid'),'sp[couponactivityid]','','text','','',plang('dspcouponactivityid_msg'),'','dspcouponactivityid');
    showsetting(plang('dspcoupontotalcount'),'sp[coupontotalcount]','','text','','',plang('dspcoupontotalcount_msg'),'','dspcoupontotalcount');
    showsetting(plang('dspcouponremaincount'),'sp[couponremaincount]','','text','','',plang('dspcouponremaincount_msg'),'','dspcouponremaincount');

    $platformselect ='';
    $platformselect .= '<option value="none" selected>'.plang('platform')['none'].'</option>';
    $platformselect .= '<option value="taobao">'.plang('platform')['taobao'].'</option>';
    $platformselect .= '<option value="tmall">'.plang('platform')['tmall'].'</option>';
    $platformselect .= '<option value="jd">'.plang('platform')['jd'].'</option>';
    $platformselect .= '<option value="vip">'.plang('platform')['vip'].'</option>';
    $platformselect .= '<option value="pinduoduo">'.plang('platform')['pinduoduo'].'</option>';
    showsetting(plang('dspplatform'),'sp[platform]','','<select name="sp[platform]">'.$platformselect.'</select>','',0,plang('dspplatform_msg'),1,'dspplatform');
    showsetting(plang('dspfreeshipment'),'sp[freeshipment]','0','radio','','',plang('dspfreeshipment_msg'));

    showsubmit('submit', 'submit');
	showtablefooter(); /*Dism��taobao��com*/
	showformfooter(); /*Dism_taobao_com*/
	
	
	dexit();
}elseif($act=='delete'){
	$id = dintval($_GET['id']);
	$page = dintval($_GET['page']);
	$title = dintval($_GET['title']);
	$categoryid = dintval($_GET['categoryid']);
	$flag = dintval($_GET['flag']);
	$sp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->fetch($id);
	if(empty($sp))
		cpmsg('jzsjiale_daogou:empty', '', 'error');
	if(submitcheck('submit')){
	    if(!empty($sp['attach'])){
	        @unlink($_G['setting']['attachdir'].'common/'.$sp['attach']);
	    }
		C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->delete($id);
		recache(false,$categoryid);
		cpmsg('jzsjiale_daogou:delok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&page='.$page.'&title='.$title.'&categoryid='.$categoryid.'&flag='.$flag, 'succeed');
	
	}
	cpmsg('jzsjiale_daogou:spdel','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=delete&id='.$id.'&submit=yes&page='.$page.'&title='.$title.'&categoryid='.$categoryid.'&flag='.$flag,'form',array('title' => $sp['title']));
}elseif($act=='details'){
	$id = dintval($_GET['id']);
	$page = dintval($_GET['page']);
	
	$sp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->fetch($id);
	if(empty($sp))
		cpmsg('jzsjiale_daogou:empty', '', 'error');
	$category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->fetch($sp['categoryid']);
	//20180710 add
	if($_G['charset'] == 'gbk'){
	    if(strpos($sp['tkl'],'%80') !== false){
	        $sp['tkl'] = urldecode($sp['tkl']);
	    }
	}
	//20180710 end
	echo "<strong>".plang("dsptitle").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['title'])."<br/>"
	     ."<strong>".plang("dspimg").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".'<a href="'.dhtmlspecialchars($sp['img']).'" target="_blank"><img src="' . dhtmlspecialchars($sp['img']) . '" width="200px" /></a>'."<br/>"
		 ."<strong>".plang("dspurl").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".'<a href="'.dhtmlspecialchars($sp['url']).'" target="_blank">'.dhtmlspecialchars($sp['url']).'</a>'."<br/>"
		 ."<strong>".plang("dspyouhuiquan").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".'<a href="'.dhtmlspecialchars($sp['youhuiquan']).'" target="_blank">'.dhtmlspecialchars($sp['youhuiquan']).'</a>'."<br/>"
		 ."<strong>".plang("dspyuanjia").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['yuanjia']).plang("yuan")."<br/>"
		 ."<strong>".plang("dspxianjia").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['xianjia']).plang("yuan")."<br/>"
		 ."<strong>".plang("dsptkl").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['tkl'])."<br/>"
         ."<strong>".plang("dsptklsimple").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['tklsimple'])."<br/>"
         ."<strong>".plang("dsptkldateline").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dgmdate(dhtmlspecialchars($sp['tkldateline']))."<br/>"
		 ."<strong>".plang("dspcategoryid").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($category['title'])."<br/>"
		 ."<strong>".plang("dspstatus").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".(dhtmlspecialchars($sp['status'])?plang('yes'):plang('no'))."<br/>"
         ."<strong>".plang("dspcouponinfo").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['couponinfo'])."<br/>"
         ."<strong>".plang("dspcouponstartfee").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['couponstartfee'])."<br/>"
         ."<strong>".plang("dspcouponamount").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['couponamount'])."<br/>"
         ."<strong>".plang("dspcouponstarttime").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['couponstarttime'])."<br/>"
         ."<strong>".plang("dspcouponendtime").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['couponendtime'])."<br/>"
         ."<strong>".plang("dspcouponactivityid").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['couponactivityid'])."<br/>"
         ."<strong>".plang("dspcoupontotalcount").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['coupontotalcount'])."<br/>"
         ."<strong>".plang("dspcouponremaincount").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dhtmlspecialchars($sp['couponremaincount'])."<br/>"
         ."<strong>".plang("dspplatform").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".(dhtmlspecialchars($sp['platform'])?plang('platform')[$sp['platform']]:plang('platform')['none'])."<br/>"
         ."<strong>".plang("dspfreeshipment").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".(dhtmlspecialchars($sp['freeshipment'])?plang('yes'):plang('no'))."<br/>"
         ."<strong>".plang("dsdateline").":&nbsp;&nbsp;&nbsp;&nbsp;</strong>".dgmdate(dhtmlspecialchars($sp['dateline']))."<br/>";
	
	
	dexit();
}elseif($act=='edit'){
	$id = dintval($_GET['id']);
	$page = dintval($_GET['page']);
	$title = dintval($_GET['title']);
	$categoryid = dintval($_GET['categoryid']);
	$flag = dintval($_GET['flag']);
	$sp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->fetch($id);
	if(empty($sp))
		cpmsg('jzsjiale_daogou:empty', '', 'error');
	
	$tkldateline = $sp['tkldateline'];
	if(submitcheck('submit')){
	    $sp = $_GET['sp'];
		$dsp = array('dateline'=>TIMESTAMP);
        $prevcategoryid = daddslashes(trim($sp['prevcategoryid']));
		$dsp['categoryid'] = daddslashes(trim($sp['categoryid']));
		$dsp['title'] = daddslashes(trim($sp['title']));
		$dsp['url'] = daddslashes(trim($sp['url']));
		$dsp['youhuiquan'] = daddslashes(trim($sp['youhuiquan']));
		$dsp['yuanjia'] = daddslashes(trim($sp['yuanjia']));
		$dsp['xianjia'] = daddslashes(trim($sp['xianjia']));
		$dsp['tkl'] = daddslashes(trim($sp['tkl']));
        $dsp['tklsimple'] = daddslashes(trim($sp['tklsimple']));
		$dsp['status'] = daddslashes(trim($sp['status']));
		$dsp['numiid'] = daddslashes(trim($sp['numiid']));
        $dsp['couponinfo'] = daddslashes(trim($sp['couponinfo']));
        $dsp['couponstartfee'] = daddslashes(trim($sp['couponstartfee']));
        $dsp['couponamount'] = daddslashes(trim($sp['couponamount']));
        $dsp['couponstarttime'] = daddslashes(trim($sp['couponstarttime']));
        $dsp['couponendtime'] = daddslashes(trim($sp['couponendtime']));
        $dsp['couponactivityid'] = daddslashes(trim($sp['couponactivityid']));
        $dsp['coupontotalcount'] = daddslashes(trim($sp['coupontotalcount']));
        $dsp['couponremaincount'] = daddslashes(trim($sp['couponremaincount']));
        $dsp['platform'] = daddslashes(trim($sp['platform']));
        $dsp['freeshipment'] = daddslashes(trim($sp['freeshipment']));
		
		if(!empty($dsp['tkl']) && empty($tkldateline)){
		    $dsp['tkldateline'] = TIMESTAMP;
		}
		
		//20180710 add
		if($_G['charset'] == 'gbk'){
		    $tklouyuantmp = urlencode($dsp['tkl']);
		    if(strpos($tklouyuantmp,'%80') !== false){
		        $dsp['tkl'] = $tklouyuantmp;
		    }
		}
		//20180710 end
		
		if(empty($dsp['numiid']) || $dsp['numiid'] == "" || $dsp['numiid'] == null || $dsp['numiid'] == "#"){
		    $data = getparam($dsp['url']);
		    $dsp['numiid'] = $data['id'];
		}
		
		if($_FILES['img']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['img'], 'common') && $upload->save(1)) {
		        $dsp['img'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		        $dsp['attach'] = $upload->attach['attachment'];
		    }
		} else {
		    $dsp['img'] = !empty($_GET['img'])?trim($_GET['img']):"";
		}
		
		if(empty($dsp['img'])){
		    cpmsg('jzsjiale_daogou:dspnoimg', '', 'error');
		}
		
		$pattern = "/^[a-zA-z]+:\/\/[^\s]*[.]{1}(gif|jpg|png|bmp|jpeg|SS2)$/is";
		if ( !preg_match( $pattern, $dsp['img'] ) )
		{
		    cpmsg('jzsjiale_daogou:dspimgfeifa', '', 'error');
		}
		
		
		if(empty($dsp['title'])){
		    cpmsg('jzsjiale_daogou:dspnotitle', '', 'error');
		}elseif(strlen($dsp['title']) > 100) {
		    cpmsg('jzsjiale_daogou:dsptitle_more', '', 'error');
		}
		
		if(empty($dsp['url'])){
		    cpmsg('jzsjiale_daogou:dspnourl', '', 'error');
		}
		
		global $_G;
		$_config = $_G['cache']['plugin']['jzsjiale_daogou'];
		
		$pattern = "/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/is";
		if(!empty($_config['g_urlxieyi'])){
		    $pattern = "/^((".$_config['g_urlxieyi'].")?:\/\/)[^\s]+$/is";
		}
		if ( !preg_match( $pattern, $dsp['url'] ) )
		{
		    cpmsg('jzsjiale_daogou:dspurlfeifa', '', 'error');
		}
		
		$pattern = "/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/is";
	    if(!empty($_config['g_urlxieyi'])){
		    $pattern = "/^((".$_config['g_urlxieyi'].")?:\/\/)[^\s]+$/is";
		}
		if ( !preg_match( $pattern, $dsp['youhuiquan'] ) && !empty($dsp['youhuiquan']))
		{
		    cpmsg('jzsjiale_daogou:dspyouhuiquanfeifa', '', 'error');
		}
		
	   /*
	    if(empty($dsp['yuanjia'])){
		    cpmsg('jzsjiale_daogou:dspyuanjianull', '', 'error');
		}elseif(!is_numeric($dsp['yuanjia'])){
		    cpmsg('jzsjiale_daogou:dspyuanjianotnum', '', 'error');
		}
		*/
		
		if(!empty($dsp['yuanjia']) && !is_numeric($dsp['yuanjia'])){
		    cpmsg('jzsjiale_daogou:dspyuanjianotnum', '', 'error');
		}
		
		//20180912 del start
		/*
		if(empty($dsp['xianjia'])){
		    cpmsg('jzsjiale_daogou:dspxianjianull', '', 'error');
		}elseif(!is_numeric($dsp['xianjia'])){
		    cpmsg('jzsjiale_daogou:dspxianjianotnum', '', 'error');
		}
		*/
		//20180912 del end
		
		//20180912 add start
		if(!empty($dsp['xianjia']) && !is_numeric($dsp['xianjia'])){
		    cpmsg('jzsjiale_daogou:dspxianjianotnum', '', 'error');
		}
		//20180912 add end
		
		if(C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->update($id,$dsp)){
		    if($prevcategoryid != $dsp['categoryid']){
                recache(false,$prevcategoryid);
                recache(false,$dsp['categoryid']);
            }else{
                recache(false,$dsp['categoryid']);
            }

			cpmsg('jzsjiale_daogou:editok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&page='.$page.'&title='.$title.'&categoryid='.$categoryid.'&flag='.$flag, 'succeed');
		}else{
			cpmsg('jzsjiale_daogou:error', '', 'error');
		}
		
	
	
	}
	echo '<div class="colorbox"><h4>'.plang('aboutsp').'</h4>'.
		 '<table cellspacing="0" cellpadding="3"><tr>'.
	     '<td valign="top">'.plang('spdescription').'</td></tr></table>'.
		 '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

    echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=edit&page='.$page.'&title='.$title.'&categoryid='.$categoryid.'&flag='.$flag, 'enctype');
	
	showsubmit('submit', 'submit');
	
	echo'<input type="hidden" value="'.dhtmlspecialchars($sp['id']).'" name="id"/>';
	echo'<input type="hidden" value="'.dhtmlspecialchars($sp['numiid']).'" name="sp[numiid]"/>';
    echo'<input type="hidden" value="'.dhtmlspecialchars($sp['categoryid']).'" name="sp[prevcategoryid]"/>';
	showtableheader(plang('editsp'), '');
	
	$categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid(0,1);
	$categoryidselect = '<option value="0">'.plang('qingxuanze').'</option>';
	foreach($categoryids as $k =>$v){
	    $categoryidselect .= '<option value="'.$v['id'].'" '.($v['id']==$sp['categoryid']?'selected':'').'>'.$v['title'].'</option>';
	    
	    $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($v['id'],1);
	    
	    foreach($subcategoryids as $subk =>$subv){
	        $categoryidselect .= '<option value="'.$subv['id'].'" '.($subv['id']==$sp['categoryid']?'selected':'').'>&nbsp;&nbsp;&nbsp;&nbsp;'.$subv['title'].'</option>';
	         
	        $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($subv['id'],1);
	        foreach($sub3categoryids as $sub3k =>$sub3v){
	            $categoryidselect .= '<option value="'.$sub3v['id'].'" '.($sub3v['id']==$sp['categoryid']?'selected':'').'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sub3v['title'].'</option>';
	        }
	    }
	}
	showsetting(plang('dspcategoryid'),'sp[categoryid]','','<select name="sp[categoryid]">'.$categoryidselect.'</select>','',0,plang('dspcategoryid_msg'),1,'dspcategoryid');
	showsetting(plang('dsptitle'),'sp[title]',dhtmlspecialchars($sp['title']),'text','','',plang('dsptitle_msg'));
	showsetting(plang('dspimg'), 'img', dhtmlspecialchars($sp['img']), 'filetext','','',plang('dspimg_msg'),'','dspimg');
	showsetting(plang('dspurl'),'sp[url]',dhtmlspecialchars($sp['url']),'text','','',plang('dspurl_msg'),'','dspurl');
	showsetting(plang('dspyouhuiquan'),'sp[youhuiquan]',dhtmlspecialchars($sp['youhuiquan']),'text','','',plang('dspyouhuiquan_msg'),'','dspyouhuiquan');
	showsetting(plang('dspyuanjia'),'sp[yuanjia]',dhtmlspecialchars($sp['yuanjia']),'text','','',plang('dspyuanjia_msg'),'','dspyuanjia');
	showsetting(plang('dspxianjia'),'sp[xianjia]',dhtmlspecialchars($sp['xianjia']),'text','','',plang('dspxianjia_msg'),'','dspxianjia');
	
	//20180710 add
	if($_G['charset'] == 'gbk'){
	    if(strpos($sp['tkl'],'%80') !== false){
	        $sp['tkl'] = urldecode($sp['tkl']);
	    }
	}
	//20180710 end
	
	showsetting(plang('dsptkl'),'sp[tkl]',dhtmlspecialchars($sp['tkl']),'text','','',plang('dsptkl_msg'),'','dsptkl');
    showsetting(plang('dsptklsimple'),'sp[tklsimple]',dhtmlspecialchars($sp['tklsimple']),'text','','',plang('dsptklsimple_msg'),'','dsptklsimple');
    showsetting(plang('dspstatus'),'sp[status]',dhtmlspecialchars($sp['status']),'radio','','',plang('dspstatus_msg'));
    showsetting(plang('dspcouponinfo'),'sp[couponinfo]',dhtmlspecialchars($sp['couponinfo']),'text','','',plang('dspcouponinfo_msg'),'','dspcouponinfo');
    showsetting(plang('dspcouponstartfee'),'sp[couponstartfee]',dhtmlspecialchars($sp['couponstartfee']),'text','','',plang('dspcouponstartfee_msg'),'','dspcouponstartfee');
    showsetting(plang('dspcouponamount'),'sp[couponamount]',dhtmlspecialchars($sp['couponamount']),'text','','',plang('dspcouponamount_msg'),'','dspcouponamount');
    showsetting(plang('dspcouponstarttime'),'sp[couponstarttime]',dhtmlspecialchars($sp['couponstarttime']),'calendar','',0,plang('dspcouponstarttime_msg'),1,'dspcouponstarttime');
    showsetting(plang('dspcouponendtime'),'sp[couponendtime]',dhtmlspecialchars($sp['couponendtime']),'calendar','',0,plang('dspcouponendtime_msg'),1,'dspcouponendtime');
    showsetting(plang('dspcouponactivityid'),'sp[couponactivityid]',dhtmlspecialchars($sp['couponactivityid']),'text','','',plang('dspcouponactivityid_msg'),'','dspcouponactivityid');
    showsetting(plang('dspcoupontotalcount'),'sp[coupontotalcount]',dhtmlspecialchars($sp['coupontotalcount']),'text','','',plang('dspcoupontotalcount_msg'),'','dspcoupontotalcount');
    showsetting(plang('dspcouponremaincount'),'sp[couponremaincount]',dhtmlspecialchars($sp['couponremaincount']),'text','','',plang('dspcouponremaincount_msg'),'','dspcouponremaincount');
    $platformselect ='';
    $platformselect .= '<option value="none" '.($sp['platform'] == 'none' || empty($sp['platform'])?"selected":"").'>'.plang('platform')['none'].'</option>';
    $platformselect .= '<option value="taobao" '.($sp['platform'] == 'taobao'?"selected":"").'>'.plang('platform')['taobao'].'</option>';
    $platformselect .= '<option value="tmall" '.($sp['platform'] == 'tmall'?"selected":"").'>'.plang('platform')['tmall'].'</option>';
    $platformselect .= '<option value="jd" '.($sp['platform'] == 'jd'?"selected":"").'>'.plang('platform')['jd'].'</option>';
    $platformselect .= '<option value="vip" '.($sp['platform'] == 'vip'?"selected":"").'>'.plang('platform')['vip'].'</option>';
    $platformselect .= '<option value="pinduoduo" '.($sp['platform'] == 'pinduoduo'?"selected":"").'>'.plang('platform')['pinduoduo'].'</option>';
    showsetting(plang('dspplatform'),'sp[platform]',dhtmlspecialchars($sp['platform']),'<select name="sp[platform]">'.$platformselect.'</select>','',0,plang('dspplatform_msg'),1,'dspplatform');
    showsetting(plang('dspfreeshipment'),'sp[freeshipment]',dhtmlspecialchars($sp['freeshipment']),'radio','','',plang('dspfreeshipment_msg'));


    showsubmit('submit', 'submit');
	showtablefooter(); /*Dism��taobao��com*/
	showformfooter(); /*Dism_taobao_com*/
	dexit();
}elseif($formhash == FORMHASH && $act=='allyessuiji'){
    
            $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->setallsuiji(1);

            if(count($allshangpin) > 0){
                recache();
                cpmsg('jzsjiale_daogou:editok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'succeed');
            }else{
                cpmsg('jzsjiale_daogou:cache_error', '', 'error');
            }
            
        
        dexit();
 
}elseif($formhash == FORMHASH && $act=='allnosuiji'){
    
            $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->setallsuiji(0);

            if(count($allshangpin) > 0){
                recache();
                cpmsg('jzsjiale_daogou:editok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'succeed');
            }else{
                cpmsg('jzsjiale_daogou:cache_error', '', 'error');
            }
            
        
        dexit();
 
}elseif($formhash == FORMHASH && $act=='delallsp'){
    
            
            if(submitcheck('submit')){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->delallsp();
                recache();
                cpmsg('jzsjiale_daogou:delok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'succeed');
            }
            cpmsg('jzsjiale_daogou:delallsptip','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=delallsp&submit=yes','form',array());
        dexit();
 
}elseif($act=='cache'){

    /*
            $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();
      
            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));

    if(count($allshangpin) > 0){
                cpmsg('jzsjiale_daogou:cache_success', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'succeed');
            }else{
                cpmsg('jzsjiale_daogou:cache_error', '', 'error');
            }


        */
    //20190329 add
    $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

    foreach ($category as $key => $value){

        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1,$value["id"]);

        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));
    }

    cpmsg('jzsjiale_daogou:cache_success', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'succeed');



    dexit();
 
}elseif($act=='caiji'){
       $formhash = $_POST['formhash'];
       if($formhash == FORMHASH){
           $caijiurl = daddslashes(trim($_POST['caijiurl']));
		  if(empty($caijiurl) || $caijiurl == null){
		      cpmsg('jzsjiale_daogou:caijiurlnull', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'error');
		  }else{

              $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
              $tbappkey = $_config['g_appkey'];
              $tbsecretKey = $_config['g_appsecret'];
              //$webbianma = $_config['g_bianma'];
              $webbianma = $_G['charset'];
              $pid = $_config['g_pid'];

              //youxian youhuiquan
              $dsp_cjss = array();
              $dsp_cjss['q'] = $caijiurl;
              $dsp_cjss['currpage'] = '1';
              $dsp_cjss['page_size'] = '1';


              if(empty($pid)){
                  cpmsg('jzsjiale_daogou:pidnull', '', 'error');
                  dexit();
              }

              $adzoneId = explode("_",$pid);
              $adzoneId = $adzoneId[3];

              if(empty($adzoneId)){
                  cpmsg('jzsjiale_daogou:pidnull', '', 'error');
                  dexit();
              }

              //fliggy start
              if(strpos($caijiurl,'traveldetail.fliggy.com') !==false){
                  $fliggydata = getparam($caijiurl);
                  $fliggyid = $fliggydata['id'];

                  if(!empty($fliggyid) && $fliggyid != null){
                      $dsp_cjss['q'] = "https://item.taobao.com/item.htm?id=".$fliggyid;
                  }
              }
              //fliggy end

              $gtkl = new GetTbAPI;
              $gtkl->__construct($tbappkey, $tbsecretKey);
              $tbinfo =  $gtkl->getdgmaterialoptional($dsp_cjss,$adzoneId,$webbianma);

              $tbinfo = json_decode($tbinfo);

              $tbinfo = $tbinfo->result_list->map_data;
              $tbinfo = $tbinfo[0];

              if(!empty($tbinfo)){

                  if($webbianma == 'gbk') {
                      $coupon_start_time = diconv($tbinfo->coupon_start_time,'UTF-8','GBK');
                      $coupon_end_time = diconv($tbinfo->coupon_end_time,'UTF-8','GBK');
                      //$info_dxjh = diconv($tbinfo->info_dxjh,'UTF-8','GBK');
                      $tk_total_sales = diconv($tbinfo->tk_total_sales,'UTF-8','GBK');
                      //$tk_total_commi = diconv($tbinfo->tk_total_commi,'UTF-8','GBK');
                      $coupon_id = diconv($tbinfo->coupon_id,'UTF-8','GBK');
                      //$num_iid = diconv($tbinfo->num_iid,'UTF-8','GBK');
                      $title = diconv($tbinfo->title,'UTF-8','GBK');
                      $pict_url = diconv($tbinfo->pict_url,'UTF-8','GBK');
                      //$small_images = diconv($tbinfo->small_images,'UTF-8','GBK');
                      $reserve_price = diconv($tbinfo->reserve_price,'UTF-8','GBK');
                      $zk_final_price = diconv($tbinfo->zk_final_price,'UTF-8','GBK');
                      $user_type = diconv($tbinfo->user_type,'UTF-8','GBK');
                      $provcity = diconv($tbinfo->provcity,'UTF-8','GBK');
                      $item_url = diconv($tbinfo->item_url,'UTF-8','GBK');
                      //$include_mkt = diconv($tbinfo->include_mkt,'UTF-8','GBK');
                      //$include_dxjh = diconv($tbinfo->include_dxjh,'UTF-8','GBK');
                      $commission_rate = diconv($tbinfo->commission_rate,'UTF-8','GBK');
                      $volume = diconv($tbinfo->volume,'UTF-8','GBK');
                      //$seller_id = diconv($tbinfo->seller_id,'UTF-8','GBK');
                      $coupon_total_count = diconv($tbinfo->coupon_total_count,'UTF-8','GBK');
                      $coupon_remain_count = diconv($tbinfo->coupon_remain_count,'UTF-8','GBK');
                      $coupon_info = diconv($tbinfo->coupon_info,'UTF-8','GBK');
                      //$commission_type = diconv($tbinfo->commission_type,'UTF-8','GBK');
                      $shop_title = diconv($tbinfo->shop_title,'UTF-8','GBK');
                      $shop_dsr = diconv($tbinfo->shop_dsr,'UTF-8','GBK');
                      $coupon_share_url = diconv($tbinfo->coupon_share_url,'UTF-8','GBK');
                      $url = diconv($tbinfo->url,'UTF-8','GBK');
                      /*
                      $level_one_category_name = diconv($tbinfo->level_one_category_name,'UTF-8','GBK');
                      $level_one_category_id = diconv($tbinfo->level_one_category_id,'UTF-8','GBK');
                      $category_name = diconv($tbinfo->category_name,'UTF-8','GBK');
                      $category_id = diconv($tbinfo->category_id,'UTF-8','GBK');
                      $short_title = diconv($tbinfo->short_title,'UTF-8','GBK');
                      $white_image = diconv($tbinfo->white_image,'UTF-8','GBK');
                      $oetime = diconv($tbinfo->oetime,'UTF-8','GBK');
                      $ostime = diconv($tbinfo->ostime,'UTF-8','GBK');
                      $jdd_num = diconv($tbinfo->jdd_num,'UTF-8','GBK');
                      $jdd_price = diconv($tbinfo->jdd_price,'UTF-8','GBK');
                      $uv_sum_pre_sale = diconv($tbinfo->uv_sum_pre_sale,'UTF-8','GBK');
                      $x_id = diconv($tbinfo->x_id,'UTF-8','GBK');
                      */
                      $coupon_start_fee = diconv($tbinfo->coupon_start_fee,'UTF-8','GBK');
                      $coupon_amount = diconv($tbinfo->coupon_amount,'UTF-8','GBK');
                      //$item_description = diconv($tbinfo->item_description,'UTF-8','GBK');
                      $nick = diconv($tbinfo->nick,'UTF-8','GBK');
                      /*
                      $orig_price = diconv($tbinfo->orig_price,'UTF-8','GBK');
                      $total_stock = diconv($tbinfo->total_stock,'UTF-8','GBK');
                      $sell_num = diconv($tbinfo->sell_num,'UTF-8','GBK');
                      $stock = diconv($tbinfo->stock,'UTF-8','GBK');
                      $tmall_play_activity_info = diconv($tbinfo->tmall_play_activity_info,'UTF-8','GBK');
                      */
                      $item_id = diconv($tbinfo->item_id,'UTF-8','GBK');
                      $real_post_fee = diconv($tbinfo->real_post_fee,'UTF-8','GBK');

                  }else{
                      $coupon_start_time = $tbinfo->coupon_start_time;
                      $coupon_end_time = $tbinfo->coupon_end_time;
                      //$info_dxjh = $tbinfo->info_dxjh;
                      $tk_total_sales = $tbinfo->tk_total_sales;
                      //$tk_total_commi = $tbinfo->tk_total_commi;
                      $coupon_id = $tbinfo->coupon_id;
                      //$num_iid = $tbinfo->num_iid;
                      $title = $tbinfo->title;
                      $pict_url = $tbinfo->pict_url;
                      //$small_images = $tbinfo->small_images;
                      $reserve_price = $tbinfo->reserve_price;
                      $zk_final_price = $tbinfo->zk_final_price;
                      $user_type = $tbinfo->user_type;
                      $provcity = $tbinfo->provcity;
                      $item_url = $tbinfo->item_url;
                      //$include_mkt = $tbinfo->include_mkt;
                      //$include_dxjh = $tbinfo->include_dxjh;
                      $commission_rate = $tbinfo->commission_rate;
                      $volume = $tbinfo->volume;
                      //$seller_id = $tbinfo->seller_id;
                      $coupon_total_count = $tbinfo->coupon_total_count;
                      $coupon_remain_count = $tbinfo->coupon_remain_count;
                      $coupon_info = $tbinfo->coupon_info;
                      //$commission_type = $tbinfo->commission_type;
                      $shop_title = $tbinfo->shop_title;
                      $shop_dsr = $tbinfo->shop_dsr;
                      $coupon_share_url = $tbinfo->coupon_share_url;
                      $url = $tbinfo->url;
                      /*
                      $level_one_category_name = $tbinfo->level_one_category_name;
                      $level_one_category_id = $tbinfo->level_one_category_id;
                      $category_name = $tbinfo->category_name;
                      $category_id = $tbinfo->category_id;
                      $short_title = $tbinfo->short_title;
                      $white_image = $tbinfo->white_image;
                      $oetime = $tbinfo->oetime;
                      $ostime = $tbinfo->ostime;
                      $jdd_num = $tbinfo->jdd_num;
                      $jdd_price = $tbinfo->jdd_price;
                      $uv_sum_pre_sale = $tbinfo->uv_sum_pre_sale;
                      $x_id = $tbinfo->x_id);
                      */
                      $coupon_start_fee = $tbinfo->coupon_start_fee;
                      $coupon_amount = $tbinfo->coupon_amount;
                      //$item_description = $tbinfo->item_description;
                      $nick = $tbinfo->nick;
                      /*
                      $orig_price = $tbinfo->orig_price;
                      $total_stock = $tbinfo->total_stock;
                      $sell_num = $tbinfo->sell_num;
                      $stock = $tbinfo->stock;
                      $tmall_play_activity_info = $tbinfo->tmall_play_activity_info;
                      */
                      $item_id = $tbinfo->item_id;
                      $real_post_fee = $tbinfo->real_post_fee;
                  }

                  if(empty($url)){
                      $url = $item_url;
                  }
                  $url = ((!empty($url) && strpos($url,'http') === false)?'https:':'').$url;
                  $quanurl = ((!empty($coupon_share_url) && strpos($coupon_share_url,'http') ===false)?'https:':'').$coupon_share_url;
                  $user_type = $user_type?'tmall':'taobao';
                  $freeshipment = (int)$real_post_fee > 0 ?0:1;
              }else{
                  $data = getparam($caijiurl);
                  $tbid = $data['id'];

                  if(empty($tbid) || $tbid == null){
                      cpmsg('jzsjiale_daogou:caijiurlerror', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'error');
                      dexit();
                  }


                  $tbinfo =  $gtkl->gettbinfo($tbid);

                  $tbinfo = json_decode($tbinfo);
                  $tbinfo = $tbinfo->results->n_tbk_item[0];

                  if($webbianma == 'gbk') {
                      $item_id = diconv($tbinfo->num_iid,'UTF-8','GBK');
                      $title = diconv($tbinfo->title,'UTF-8','GBK');
                      $pict_url = diconv($tbinfo->pict_url,'UTF-8','GBK');
                      $url = diconv($tbinfo->item_url,'UTF-8','GBK');
                      $reserve_price = diconv($tbinfo->reserve_price,'UTF-8','GBK');
                      $zk_final_price = diconv($tbinfo->zk_final_price,'UTF-8','GBK');
                      $user_type = diconv($tbinfo->user_type,'UTF-8','GBK');
                      $free_shipment = diconv($tbinfo->free_shipment,'UTF-8','GBK');
                  }else{
                      $item_id = $tbinfo->num_iid;
                      $title = $tbinfo->title;
                      $pict_url = $tbinfo->pict_url;
                      $url = $tbinfo->item_url;
                      $reserve_price = $tbinfo->reserve_price;
                      $zk_final_price = $tbinfo->zk_final_price;
                      $user_type = $tbinfo->user_type;
                      $free_shipment = $tbinfo->free_shipment;
                  }

                  $url = ((!empty($url) && strpos($url,'http') === false)?'https:':'').$url;
                  $quanurl = "";
                  $user_type = $user_type?'tmall':'taobao';
                  $freeshipment = $free_shipment ?1:0;
                  $coupon_info = "";
                  $coupon_start_fee = "";
                  $coupon_amount = "";
                  $coupon_start_time = "";
                  $coupon_end_time = "";
                  $coupon_id = "";
                  $coupon_total_count = "";
                  $coupon_remain_count = "";
              }



              echo '<div class="colorbox"><h4>'.plang('aboutsp').'</h4>'.
                  '<table cellspacing="0" cellpadding="3"><tr>'.
                  '<td valign="top">'.plang('spdescription').'</td></tr></table>'.
                  '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

              echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
              showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=add', 'enctype');

              showsubmit('submit', 'submit');

              showtableheader(plang('editsp'), '');

              $categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid(0,1);
              $categoryidselect = '<option value="0">'.plang('qingxuanze').'</option>';
              foreach($categoryids as $k =>$v){
                  $categoryidselect .= '<option value="'.$v['id'].'">'.$v['title'].'</option>';

                  $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($v['id'],1);

                  foreach($subcategoryids as $subk =>$subv){
                      $categoryidselect .= '<option value="'.$subv['id'].'" >&nbsp;&nbsp;&nbsp;&nbsp;'.$subv['title'].'</option>';

                      $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($subv['id'],1);
                      foreach($sub3categoryids as $sub3k =>$sub3v){
                          $categoryidselect .= '<option value="'.$sub3v['id'].'" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sub3v['title'].'</option>';
                      }
                  }
              }
              showsetting(plang('dspcategoryid'),'sp[categoryid]','','<select name="sp[categoryid]">'.$categoryidselect.'</select>','',0,plang('dspcategoryid_msg'),1,'dspcategoryid');
              showsetting(plang('dsptbnumiid'),'sp[numiid]',$item_id,'text','','',plang('dsptbnumiid_msg'));
              showsetting(plang('dsptitle'),'sp[title]',$title,'text','','',plang('dsptitle_msg'));
              showsetting(plang('dspimg'), 'img', $pict_url, 'filetext','','',plang('dspimg_msg'),'','dspimg');
              showsetting(plang('dspurl'),'sp[url]',$url,'text','','',plang('dspurl_msg'),'','dspurl');
              showsetting(plang('dspyouhuiquan'),'sp[youhuiquan]',$quanurl,'text','','',plang('dspyouhuiquan_msg'),'','dspyouhuiquan');
              showsetting(plang('dspyuanjia'),'sp[yuanjia]',$reserve_price,'text','','',plang('dspyuanjia_msg'),'','dspyuanjia');
              showsetting(plang('dspxianjia'),'sp[xianjia]',$zk_final_price,'text','','',plang('dspxianjia_msg'),'','dspxianjia');
              showsetting(plang('dsptkl'),'sp[tkl]','','text','','',plang('dsptkl_msg'),'','dsptkl');
              showsetting(plang('dsptklsimple'),'sp[tklsimple]','','text','','',plang('dsptklsimple_msg'),'','dsptklsimple');
              showsetting(plang('dspstatus'),'sp[status]','1','radio','','',plang('dspstatus_msg'));
              showsetting(plang('dspcouponinfo'),'sp[couponinfo]',$coupon_info,'text','','',plang('dspcouponinfo_msg'),'','dspcouponinfo');
              showsetting(plang('dspcouponstartfee'),'sp[couponstartfee]',$coupon_start_fee,'text','','',plang('dspcouponstartfee_msg'),'','dspcouponstartfee');
              showsetting(plang('dspcouponamount'),'sp[couponamount]',$coupon_amount,'text','','',plang('dspcouponamount_msg'),'','dspcouponamount');
              showsetting(plang('dspcouponstarttime'),'sp[couponstarttime]',$coupon_start_time,'calendar','',0,plang('dspcouponstarttime_msg'),1,'dspcouponstarttime');
              showsetting(plang('dspcouponendtime'),'sp[couponendtime]',$coupon_end_time,'calendar','',0,plang('dspcouponendtime_msg'),1,'dspcouponendtime');
              showsetting(plang('dspcouponactivityid'),'sp[couponactivityid]',$coupon_id,'text','','',plang('dspcouponactivityid_msg'),'','dspcouponactivityid');
              showsetting(plang('dspcoupontotalcount'),'sp[coupontotalcount]',$coupon_total_count,'text','','',plang('dspcoupontotalcount_msg'),'','dspcoupontotalcount');
              showsetting(plang('dspcouponremaincount'),'sp[couponremaincount]',$coupon_remain_count,'text','','',plang('dspcouponremaincount_msg'),'','dspcouponremaincount');
              $platformselect ='';
              $platformselect .= '<option value="none">'.plang('platform')['none'].'</option>';
              $platformselect .= '<option value="taobao" '.($user_type == 'taobao'?"selected":"").'>'.plang('platform')['taobao'].'</option>';
              $platformselect .= '<option value="tmall" '.($user_type == 'tmall'?"selected":"").'>'.plang('platform')['tmall'].'</option>';
              $platformselect .= '<option value="jd">'.plang('platform')['jd'].'</option>';
              $platformselect .= '<option value="vip">'.plang('platform')['vip'].'</option>';
              $platformselect .= '<option value="pinduoduo">'.plang('platform')['pinduoduo'].'</option>';
              showsetting(plang('dspplatform'),'sp[platform]','','<select name="sp[platform]">'.$platformselect.'</select>','',0,plang('dspplatform_msg'),1,'dspplatform');
              showsetting(plang('dspfreeshipment'),'sp[freeshipment]',$freeshipment,'radio','','',plang('dspfreeshipment_msg'));

              showsubmit('submit', 'submit');
              showtablefooter(); /*Dism��taobao��com*/
              showformfooter(); /*Dism_taobao_com*/
              dexit();



		  }
       }
       dexit();
 
}elseif($formhash == FORMHASH && $act=='createtkl'){
    
    loadcache('plugin');
    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    
    $tbappkey = $_config['g_appkey'];
    $tbsecretKey = $_config['g_appsecret'];
    $webbianma = $_G['charset'];
    $g_tklguoqishijian = $_config['g_tklguoqishijian'];

    
    $gtkl = new GetTbAPI();
    $gtkl->__construct($tbappkey, $tbsecretKey);
    
    
    $pertask = dintval(daddslashes(trim($_GET['pertask'])))?dintval(daddslashes(trim($_GET['pertask']))):10;
    $next = dintval(daddslashes(trim($_GET['next'])));
    if($next){
        $current = $next;
    }else{
        $current = 0;
    }
    $nextcurrent = $current + ($pertask-1);
    $next = $nextcurrent+1;
    $nextlink = "action=plugins&operation=config&do=$pluginid&identifier=jzsjiale_daogou&pmod=shangpin&act=createtkl&next=$next&pertask=$pertask&formhash=".FORMHASH;

    $count = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->count();
    $qdsp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->range($current,$pertask,'DESC');

    foreach ($qdsp as $spdata){
        
        date_default_timezone_set('Asia/Shanghai');
        	
        $hourtime = strtotime("-".($g_tklguoqishijian*24)." hour");
        
        $iscreateok = false;
        if($spdata['tkldateline'] <= $hourtime || empty($spdata['tkl']) || $spdata['tkl'] == "" || $spdata['tkl'] == null){
            $iscreateok = true;
        }else{
            $iscreateok = false;
        }
        
        if($iscreateok){
            $sp_url = dhtmlspecialchars($spdata["url"]);
            if($_config['g_yhqtotkl'] && !empty($spdata["youhuiquan"])){
                $sp_url = dhtmlspecialchars($spdata["youhuiquan"]);
            }
            $tbktkl_get = $gtkl->gettkl(dhtmlspecialchars($spdata['title']), $sp_url, dhtmlspecialchars($spdata["img"]), $webbianma);

            $tbktkl_get = json_decode($tbktkl_get);
            
            if ($webbianma == "gbk") {
                $tbktkl = diconv(dhtmlspecialchars($tbktkl_get->model),'UTF-8', 'GBK');
                $tbktklsimple = diconv(dhtmlspecialchars($tbktkl_get->password_simple),'UTF-8', 'GBK');
            } else {
                $tbktkl = dhtmlspecialchars($tbktkl_get->model);
                $tbktklsimple = dhtmlspecialchars($tbktkl_get->password_simple);
            }
            
            
            
            if(empty($tbktkl)){
                $tbktkl_get = $gtkl->gettkl(mb_convert_encoding(dhtmlspecialchars($spdata['title']),'gbk','UTF-8'), $sp_url, dhtmlspecialchars($spdata["img"]), $webbianma);

                $tbktkl_get = json_decode($tbktkl_get);
                if ($webbianma == "gbk") {
                    $tbktkl = diconv(dhtmlspecialchars($tbktkl_get->model),'UTF-8', 'GBK');
                    $tbktklsimple = diconv(dhtmlspecialchars($tbktkl_get->password_simple),'UTF-8', 'GBK');
                } else {
                    $tbktkl = dhtmlspecialchars($tbktkl_get->model);
                    $tbktklsimple = dhtmlspecialchars($tbktkl_get->password_simple);
                }
            }
      
            
            $dsp = array('tkldateline'=>TIMESTAMP);
            $dsp['tkl'] = $tbktkl;
            $dsp['tklsimple'] = $tbktklsimple;
            
            
            //20180710 add
            if($_G['charset'] == 'gbk'){
                $pattern = "/^[a-zA-z0-9]$/is";
                /*
                if (preg_match( $pattern, substr( $dsp['tkl'], 0, 1 ) ) )
                {
                    $dsp['tkl'] = '%80'.$dsp['tkl'].'%80';
                }
                */
                if (preg_match( $pattern, substr( $dsp['tklsimple'], 0, 1 ) ) )
                {
                    $dsp['tklsimple'] = '%80'.$dsp['tklsimple'].'%80';
                }
            }
            //20180710 end
            
            C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->update($spdata['id'],$dsp);
        }
    }
  
    if($current < $count-1){
        recache();
        cpmsg(plang('curr_createtkl').cplang('counter_processing', array('current' => ($current+1), 'next' => ($nextcurrent+1))), $nextlink, 'loading',array('count' => $count));
    }else{
        recache();
        cpmsg('jzsjiale_daogou:createtklok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'succeed');
    }
    

	
}elseif($formhash == FORMHASH && $act=='createtklbycategory'){
    
    loadcache('plugin');
    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    
    $categoryid = dintval(daddslashes(trim($_GET['categoryid'])));
    if(empty($categoryid)){
        cpmsg('jzsjiale_daogou:gettklerror', '', 'error');
    }
    
    $tbappkey = $_config['g_appkey'];
    $tbsecretKey = $_config['g_appsecret'];
    $webbianma = $_G['charset'];
    $g_tklguoqishijian = $_config['g_tklguoqishijian'];

    
    $gtkl = new GetTbAPI();
    $gtkl->__construct($tbappkey, $tbsecretKey);
    
    
    
    $pertask = dintval(daddslashes(trim($_GET['pertask'])))?dintval(daddslashes(trim($_GET['pertask']))):10;
    $next = dintval(daddslashes(trim($_GET['next'])));
    if($next){
        $current = $next;
    }else{
        $current = 0;
    }
    $nextcurrent = $current + ($pertask-1);
    $next = $nextcurrent+1;
    $nextlink = "action=plugins&operation=config&do=$pluginid&identifier=jzsjiale_daogou&pmod=shangpin&act=createtklbycategory&next=$next&pertask=$pertask&formhash=".FORMHASH."&categoryid=".$categoryid;

    $count = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->count_by_categoryid($categoryid);
    $qdsp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->range_by_categoryid($categoryid,$current,$pertask,'DESC');

    foreach ($qdsp as $spdata){
        
        date_default_timezone_set('Asia/Shanghai');
        	
        $hourtime = strtotime("-".($g_tklguoqishijian*24)." hour");
        
        $iscreateok = false;
        if($spdata['tkldateline'] <= $hourtime || empty($spdata['tkl']) || $spdata['tkl'] == "" || $spdata['tkl'] == null){
            $iscreateok = true;
        }else{
            $iscreateok = false;
        }
        
        if($iscreateok){
            $sp_url = dhtmlspecialchars($spdata["url"]);
            if($_config['g_yhqtotkl'] && !empty($spdata["youhuiquan"])){
                $sp_url = dhtmlspecialchars($spdata["youhuiquan"]);
            }
            $tbktkl_get = $gtkl->gettkl(dhtmlspecialchars($spdata['title']), $sp_url, dhtmlspecialchars($spdata["img"]), $webbianma);

            $tbktkl_get = json_decode($tbktkl_get);
            if ($webbianma == "gbk") {
                $tbktkl = diconv(dhtmlspecialchars($tbktkl_get->model),'UTF-8', 'GBK');
                $tbktklsimple = diconv(dhtmlspecialchars($tbktkl_get->password_simple),'UTF-8', 'GBK');
            } else {
                $tbktkl = dhtmlspecialchars($tbktkl_get->model);
                $tbktklsimple = dhtmlspecialchars($tbktkl_get->password_simple);
            }
             
            if(empty($tbktkl)){
                $tbktkl_get = $gtkl->gettkl(mb_convert_encoding(dhtmlspecialchars($spdata['title']),'gbk','UTF-8'), $sp_url, dhtmlspecialchars($spdata["img"]), $webbianma);

                $tbktkl_get = json_decode($tbktkl_get);
                if ($webbianma == "gbk") {
                    $tbktkl = diconv(dhtmlspecialchars($tbktkl_get->model),'UTF-8', 'GBK');
                    $tbktklsimple = diconv(dhtmlspecialchars($tbktkl_get->password_simple),'UTF-8', 'GBK');
                } else {
                    $tbktkl = dhtmlspecialchars($tbktkl_get->model);
                    $tbktklsimple = dhtmlspecialchars($tbktkl_get->password_simple);
                }
            }
      
            
            $dsp = array('tkldateline'=>TIMESTAMP);
            $dsp['tkl'] = $tbktkl;
            $dsp['tklsimple'] = $tbktklsimple;

            //20180710 add
            if($_G['charset'] == 'gbk'){
                $pattern = "/^[a-zA-z0-9]$/is";
                /*
                if (preg_match( $pattern, substr( $dsp['tkl'], 0, 1 ) ) )
                {
                    $dsp['tkl'] = '%80'.$dsp['tkl'].'%80';
                }
                 */
                if (preg_match( $pattern, substr( $dsp['tklsimple'], 0, 1 ) ) )
                {
                    $dsp['tklsimple'] = '%80'.$dsp['tklsimple'].'%80';
                }
            }
            //20180710 end
            
            
            C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->update($spdata['id'],$dsp);
            
        }
    }
  
    if($current < $count-1){
        recache();
        cpmsg(plang('curr_createtkl').cplang('counter_processing', array('current' => ($current+1), 'next' => ($nextcurrent+1))), $nextlink, 'loading',array('count' => $count));
    }else{
        recache();
        cpmsg('jzsjiale_daogou:createtklok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'succeed');
    }
    

	
}elseif($formhash == FORMHASH && $act=='gettkl'){
    $id = dintval($_GET['id']);
    $page = dintval($_GET['page']);
    $title = dintval($_GET['title']);
    $categoryid = dintval($_GET['categoryid']);
    $flag = dintval($_GET['flag']);
    $spdata = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->fetch($id);
    if(empty($spdata)){
        cpmsg('jzsjiale_daogou:empty', '', 'error');
    }else{
        loadcache('plugin');
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        
        $tbappkey = $_config['g_appkey'];
        $tbsecretKey = $_config['g_appsecret'];
        $webbianma = $_G['charset'];
        
        
        $gtkl = new GetTbAPI();
        $gtkl->__construct($tbappkey, $tbsecretKey);
        
        
        $sp_url = dhtmlspecialchars($spdata["url"]);
        if($_GET['getyhqtotkl'] && !empty($spdata["youhuiquan"])){
            $sp_url = dhtmlspecialchars($spdata["youhuiquan"]);
        }
        $tbktkl_get = $gtkl->gettkl(dhtmlspecialchars($spdata['title']),$sp_url , dhtmlspecialchars($spdata["img"]), $webbianma);

        $tbktkl_get = json_decode($tbktkl_get);
        if ($webbianma == "gbk") {
            $tbktkl = diconv(dhtmlspecialchars($tbktkl_get->model),'UTF-8', 'GBK');
            $tbktklsimple = diconv(dhtmlspecialchars($tbktkl_get->password_simple),'UTF-8', 'GBK');
        } else {
            $tbktkl = dhtmlspecialchars($tbktkl_get->model);
            $tbktklsimple = dhtmlspecialchars($tbktkl_get->password_simple);
        }
         
        if(empty($tbktkl)){
            $tbktkl_get = $gtkl->gettkl(mb_convert_encoding(dhtmlspecialchars($spdata['title']),'gbk','UTF-8'), $sp_url, dhtmlspecialchars($spdata["img"]), $webbianma);

            $tbktkl_get = json_decode($tbktkl_get);
            if ($webbianma == "gbk") {
                $tbktkl = diconv(dhtmlspecialchars($tbktkl_get->model),'UTF-8', 'GBK');
                $tbktklsimple = diconv(dhtmlspecialchars($tbktkl_get->password_simple),'UTF-8', 'GBK');
            } else {
                $tbktkl = dhtmlspecialchars($tbktkl_get->model);
                $tbktklsimple = dhtmlspecialchars($tbktkl_get->password_simple);
            }
        }
        
        
        
        $dsp = array('tkldateline'=>TIMESTAMP);
        $dsp['tkl'] = $tbktkl;
        $dsp['tklsimple'] = $tbktklsimple;

        //20180710 add
        if($_G['charset'] == 'gbk'){
            $pattern = "/^[a-zA-z0-9]$/is";
            /*
            if (preg_match( $pattern, substr( $dsp['tkl'], 0, 1 ) ) )
            {
                $dsp['tkl'] = '%80'.$dsp['tkl'].'%80';
            }
             */
            if (preg_match( $pattern, substr( $dsp['tklsimple'], 0, 1 ) ) )
            {
                $dsp['tklsimple'] = '%80'.$dsp['tklsimple'].'%80';
            }
        }
        //20180710 end 
        
        if(C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->update($spdata['id'],$dsp)){
            recache();
            cpmsg('jzsjiale_daogou:gettklok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&page='.$page.'&title='.$title.'&categoryid='.$categoryid.'&flag='.$flag, 'succeed');
        }else{
            cpmsg('jzsjiale_daogou:gettklerror', '', 'error');
        }
    }


	
}elseif($formhash == FORMHASH && $act=='delallgqsp'){
    
            
            if(submitcheck('submit')){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->deletebyflag(1);
                recache();
                cpmsg('jzsjiale_daogou:delok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'succeed');
            }
            cpmsg('jzsjiale_daogou:delallgqsptip','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=delallgqsp&submit=yes','form',array());
        dexit();
 
}elseif($formhash == FORMHASH && $act=='qingkongtkl'){
    
            
            if(submitcheck('submit')){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->settklnull();
                recache();
                cpmsg('jzsjiale_daogou:qingkongtklok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'succeed');
            }
            cpmsg('jzsjiale_daogou:qingkongtkltip','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=qingkongtkl&submit=yes','form',array());
        dexit();
 
}elseif($formhash == FORMHASH && $act=='qingchutklcategory'){
    
    $categoryid = dintval(daddslashes(trim($_GET['categoryid'])));
    
            if(submitcheck('submit')){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->settklnull_by_categoryid($categoryid);
                recache();
                cpmsg('jzsjiale_daogou:qingchutklcategoryok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'succeed');
            }
            cpmsg('jzsjiale_daogou:qingchutklcategorytip','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=qingchutklcategory&categoryid='.$categoryid.'&submit=yes','form',array());
        dexit();
 
}



function recache($isallcategory = true,$categoryid = 0){
    /*
    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();
    
    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
    */
    //20190329 add
    if($isallcategory){
        $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

        foreach ($category as $key => $value){

            $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1,$value["id"]);

            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));
        }
    }else{
        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $categoryid);

        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_shangpin_'.$categoryid, getcachevars(array('tbkshangpin_'.$categoryid => $shangpin_cache_tmp)));
    }

}

loadcache('plugin');

/////////caiji start

echo '<div class="colorbox"><h4>'.plang('taobaocaijititle').'</h4>'.
         '<table cellspacing="0" cellpadding="3"><tr>'.
		 '<form action="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=caiji" method="post">'.
	     '<td valign="top">'.plang('taobaocaijitip').'<input type="hidden" name="formhash" value="'.FORMHASH.'" /><input type="text" name="caijiurl" value=""/>&nbsp;&nbsp;<input type="submit" value="&nbsp;'.plang('caiji').'&nbsp;" />&nbsp;&nbsp;'.plang('caijitip1').'</td></form>'.
	     '</tr></table>'.
	     //'<table cellspacing="0" cellpadding="3"><tr>'.
	     //'<form action="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=caijitbk" method="post">'.
	     //'<td valign="top">'.plang('taobaocaijitip').'<input type="hidden" name="formhash" value="'.FORMHASH.'" /><input type="text" name="caijiurl" value=""/>&nbsp;&nbsp;<input type="submit" value="&nbsp;'.plang('caijitbk').'&nbsp;" />&nbsp;&nbsp;'.plang('caijitip2').'</td></form>'.
	     //'</tr></table>'.
	     '</div>';


/////////caiji end

if(!submitcheck('spsubmit')) {

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'enctype');


$title = daddslashes(trim($_GET['title']));
$categoryid = daddslashes(trim($_GET['categoryid']));
$flag = daddslashes(trim($_GET['flag']));

$page = intval($_GET['page']);
$page = $page > 0 ? $page : 1;
$pagesize = 10;
$start = ($page - 1) * $pagesize;

//20170703start
$map = array();
if(!empty($title)){
    $map['title'] = '%'.$title.'%';
}
if(!empty($categoryid)){
    $map['categoryid'] = $categoryid;
}
if(!empty($flag)){
    $map['flag'] = $flag;
}

$allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->range_by_map($map,$start,$pagesize,'DESC');
$count = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->count_by_map($map);

//20170703end
/*
if(empty($categoryid)){
    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->range_by_title($title,$start,$pagesize,'DESC');
    $count = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->count_by_title($title);
}else{
    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->range_by_categoryid($categoryid,$start,$pagesize,'DESC');
    $count = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->count_by_categoryid($categoryid);
}
*/


$category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
$utils = new Utils();
showtableheader(plang('splist').'(  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=add" style="color:red;">'.plang('addsp').'</a>   |   <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=createtkl&formhash='.FORMHASH.'" style="color:red;">'.plang('createtkl').'</a>   |   <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=cache" style="color:red;">'.plang('cacheshangpin').'</a>  |  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=allyessuiji&formhash='.FORMHASH.'" style="color:red;">'.plang('allyessuiji').'</a>  |  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=allnosuiji&formhash='.FORMHASH.'" style="color:red;">'.plang('allnosuiji').'</a>  |  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=delallsp&formhash='.FORMHASH.'" style="color:red;">'.plang('delallsp').'</a>  |  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&flag=1&formhash='.FORMHASH.'" style="color:red;">'.plang('showallgqsp').'</a>  |  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=delallgqsp&formhash='.FORMHASH.'" style="color:red;">'.plang('delallgqsp').'</a>  |  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category" style="color:blue;">'.plang('shezhibankuaishangpin').'</a>  |  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=qingkongtkl&formhash='.FORMHASH.'" style="color:red;">'.plang('qingkongtkl').'</a>)', '');
showsubtitle(plang('sptitle'));
foreach($allshangpin as $d){
	showtablerow('', array('width="50"'), array(
	'<input class="checkbox" type="checkbox" name="delete[]" value="'.$d['id'].'">'.$d['id'],
	'<a href="'.$d['url'].'" target="_blank"><span title="'.$d['title'].'">'.mb_substr($d['title'],0,40).'</span></a>',
	'<a href="'.$d['img'].'" target="_blank"><img src="' . $d['img'] . '" width="80px" /></a>',
	'<a href="'.$d['url'].'" target="_blank">'.(!empty($d['url'])?mb_substr($d['url'],0,20).'...':'').'</a>',
    '<a href="'.$d['youhuiquan'].'" target="_blank">'.(!empty($d['youhuiquan'])?mb_substr($d['youhuiquan'],0,20).'...':'').'</a>',
	'<span title="'.$d['xianjia'].'">'.mb_substr($d['xianjia'],0,40).'</span>',
	'<span title="'.$d['yuanjia'].'">'.mb_substr($d['yuanjia'],0,40).'</span>',
    '<span>'.$utils->searchArray($category,'id',$d['categoryid'],'title').'</span>',
	'<span title="'.($d['status']?plang('yes'):plang('no')).'">'.($d['status']?plang('yes'):plang('no')).'</span>',
	'<span title="'.($d['tkl']?plang('yes'):plang('no')).'">'.($d['tkl']?'<span style="color:green;">'.plang('yes').'</span>':'<span style="color:red;">'.plang('no')).'</span>'.'</span>',
	dgmdate($d['dateline']),
    '<span title="'.($d['flag']==1?plang('shangpinguoqi'):'').'">'.($d['flag']==1?'<span style="color:red;">'.plang('shangpinguoqi').'</span>':'').'</span>',
	'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=details&id='.$d['id'].'&page='.$page.'">'.plang('details').'</a>&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=edit&id='.$d['id'].'&page='.$page.'&title='.$title.'&categoryid='.$categoryid.'&flag='.$flag.'">'.plang('edit').'</a>&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=delete&id='.$d['id'].'&page='.$page.'&title='.$title.'&categoryid='.$d['categoryid'].'&flag='.$flag.'">'.plang('delete').'</a>&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=gettkl&id='.$d['id'].'&formhash='.FORMHASH.'&page='.$page.'&title='.$title.'&categoryid='.$categoryid.'&flag='.$flag.'">'.plang('gettkl').'</a>'.($d['youhuiquan']?'&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=gettkl&id='.$d['id'].'&formhash='.FORMHASH.'&page='.$page.'&title='.$title.'&categoryid='.$categoryid.'&flag='.$flag.'&getyhqtotkl=1">'.plang('getyhqtkl').'</a>':''))
	);
}

$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&title='.$title.'&categoryid='.$categoryid.'&flag='.$flag;
$multipage = multi($count, $pagesize, $page, $mpurl);
//showsubmit('', '', '', '', $multipage);


//search start
showsubmit('spsubmit', 'submit', 'del', plang('allcount').$count, $multipage.'
<input type="text" class="txt" name="title" value="'.(dhtmlspecialchars($title)?dhtmlspecialchars($title):plang('defaulttitle')).'" size="15" onkeyup="if(event.keyCode == 13) this.form.searchsubmit.click()" onclick="this.value=\'\'">&nbsp;&nbsp;
<input type="button" class="btn" name="searchsubmit" value="'.plang('searchtitle').'" onclick="if(this.form.title.value==\''.plang('defaulttitle').'\'){this.form.title.value=\'\'}location.href=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&categoryid='.$categoryid.'&flag='.$flag.'&title=\'+this.form.title.value;"> &nbsp;
		');

//search end

if(!empty($flag)){
    echo '<br/>'.plang("showallgqsptip");
}

showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/


}else {

    
    
		    if($_GET['delete']) {
		        
		        $delresult = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallByIds(dimplode(dhtmlspecialchars($_GET['delete'])));
		        foreach($delresult as $dr){
		            if(!empty($dr['attach'])){
		                @unlink($_G['setting']['attachdir'].'common/'.$dr['attach']);
		            }
		        }
		        
		        
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->delete(dhtmlspecialchars($_GET['delete']));
		    }
		    recache();
		    cpmsg('jzsjiale_daogou:delok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin', 'succeed');
	
		
}



function plang($str) {
	return lang('plugin/jzsjiale_daogou', $str);
}

function getparam($str){
    $data = array();
    $parameter = explode('&',end(explode('?',$str)));
    foreach($parameter as $val){
        $tmp = explode('=',$val);
        $data[$tmp[0]] = $tmp[1];
    }
    return $data;
}
//From: Dism��taobao��com
?>