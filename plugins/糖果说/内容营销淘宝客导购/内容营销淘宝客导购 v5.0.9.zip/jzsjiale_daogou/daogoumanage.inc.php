<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
global $_G, $lang;

require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';
$utils = new Utils();

if($act=='save'){
	if(submitcheck('submit')){
	
	    $setting = C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->getall();
	    
		$dg = $_GET['dg'];
		$isopendg = daddslashes(trim($dg['isopendg']));
		$isopenarticle = daddslashes(trim($dg['isopenarticle']));
		$isopenxiangguanhaowu = daddslashes(trim($dg['isopenxiangguanhaowu']));
		$isopenpost = daddslashes(trim($dg['isopenpost']));
		$xinchuangkou = daddslashes(trim($dg['xinchuangkou']));
		$onlymynav = daddslashes(trim($dg['onlymynav']));
		$qiangzhinavindex = daddslashes(trim($dg['qiangzhinavindex']));
		$qiangzhinavfaxian = daddslashes(trim($dg['qiangzhinavfaxian']));
		$qiangzhinavhaowu = daddslashes(trim($dg['qiangzhinavhaowu']));
        $qiangzhinavsouquan = daddslashes(trim($dg['qiangzhinavsouquan']));
		$qiangzhinavxiewenzhang = daddslashes(trim($dg['qiangzhinavxiewenzhang']));
		$daogoustyle = daddslashes(trim($dg['daogoustyle']));
		$weijingtai = daddslashes(trim($dg['weijingtai']));
		$weijingtaimokuai = daddslashes(trim($dg['weijingtaimokuai']));
		$isopenpchdp = daddslashes(trim($dg['isopenpchdp']));
		$pchdpmaxwidth = daddslashes(trim($dg['pchdpmaxwidth']));
		$isopenmobilehdp = daddslashes(trim($dg['isopenmobilehdp']));
		$diynav = daddslashes(trim($dg['diynav']));
		$title = daddslashes(trim($dg['title']));
		$keywords = daddslashes(trim($dg['keywords']));
		$description = daddslashes(trim($dg['description']));
		$headercode = stripslashes($dg['headercode']);
		$footercode = stripslashes($dg['footercode']);
		$homeadurl = daddslashes(trim($dg['homeadurl']));
		$text1 = daddslashes(trim($dg['text1']));
		$text2 = daddslashes(trim($dg['text2']));
		$text3 = stripslashes($dg['text3']);
		$footermenu1 = daddslashes(trim($dg['footermenu1']));
		$footermenu2 = daddslashes(trim($dg['footermenu2']));
		$isopenmobilebar = daddslashes(trim($dg['isopenmobilebar']));
		$mobilebarcode = stripslashes($dg['mobilebarcode']);
		$logoimgurl = daddslashes(trim($dg['logoimgurl']));
		$footerlogoimgurl = daddslashes(trim($dg['footerlogoimgurl']));
		$sharehouzhui = daddslashes(trim($dg['sharehouzhui']));
		$isopencnxh = daddslashes(trim($dg['isopencnxh']));
		$cnxhnum = daddslashes(trim($dg['cnxhnum']));
		$isopenfaxiangundong = daddslashes(trim($dg['isopenfaxiangundong']));
		$isopenpinglun = daddslashes(trim($dg['isopenpinglun']));
        $haowuheader = daddslashes(trim($dg['haowuheader']));
        $haowuheaderbtn = daddslashes(trim($dg['haowuheaderbtn']));
        $autotuijian = daddslashes(trim($dg['autotuijian']));
        $autotuijianlll = daddslashes(trim($dg['autotuijianlll']));
        $souquantklbtn = daddslashes(trim($dg['souquantklbtn']));
        $titlefaxian = daddslashes(trim($dg['titlefaxian']));
        $keywordsfaxian = daddslashes(trim($dg['keywordsfaxian']));
        $descriptionfaxian = daddslashes(trim($dg['descriptionfaxian']));
        $titlehaowu = daddslashes(trim($dg['titlehaowu']));
        $keywordshaowu = daddslashes(trim($dg['keywordshaowu']));
        $descriptionhaowu = daddslashes(trim($dg['descriptionhaowu']));
        $titlesouquan = daddslashes(trim($dg['titlesouquan']));
        $keywordssouquan = daddslashes(trim($dg['keywordssouquan']));
        $descriptionsouquan = daddslashes(trim($dg['descriptionsouquan']));
		
		if($_FILES['defaultimg']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['defaultimg'], 'common') && $upload->save(1)) {
		        $defaultimg = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		    }
		} else {
		    $defaultimg = !empty($_GET['defaultimg'])?trim($_GET['defaultimg']):"";
		}
		
		if($_FILES['homeadimg']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['homeadimg'], 'common') && $upload->save(1)) {
		        $homeadimg = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		    }
		} else {
		    $homeadimg = !empty($_GET['homeadimg'])?trim($_GET['homeadimg']):"";
		}
		
		if($_FILES['logoimg']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['logoimg'], 'common') && $upload->save(1)) {
		        $logoimg = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		    }
		} else {
		    $logoimg = !empty($_GET['logoimg'])?trim($_GET['logoimg']):"";
		}

        if($_FILES['sharelogo300']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['sharelogo300'], 'common') && $upload->save(1)) {
                $sharelogo300 = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $sharelogo300 = !empty($_GET['sharelogo300'])?trim($_GET['sharelogo300']):"";
        }
		
		if($_FILES['footerlogoimg']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['footerlogoimg'], 'common') && $upload->save(1)) {
		        $footerlogoimg = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		    }
		} else {
		    $footerlogoimg = !empty($_GET['footerlogoimg'])?trim($_GET['footerlogoimg']):"";
		}
		
		if($_FILES['erweimaimg']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['erweimaimg'], 'common') && $upload->save(1)) {
		        $erweimaimg = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		    }
		} else {
		    $erweimaimg = !empty($_GET['erweimaimg'])?trim($_GET['erweimaimg']):"";
		}
		
		if($_FILES['homelogo121']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['homelogo121'], 'common') && $upload->save(1)) {
		        $homelogo121 = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		    }
		} else {
		    $homelogo121 = !empty($_GET['homelogo121'])?trim($_GET['homelogo121']):"";
		}
		
		if($_FILES['homelogo600']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['homelogo600'], 'common') && $upload->save(1)) {
		        $homelogo600 = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		    }
		} else {
		    $homelogo600 = !empty($_GET['homelogo600'])?trim($_GET['homelogo600']):"";
		}
		
		if($_FILES['faviconico']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['faviconico'], 'common') && $upload->save(1)) {
		        $faviconico = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		    }
		} else {
		    $faviconico = !empty($_GET['faviconico'])?trim($_GET['faviconico']):"";
		}
		
		if($_FILES['sharepopupleftimg']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['sharepopupleftimg'], 'common') && $upload->save(1)) {
		        $sharepopupleftimg = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		    }
		} else {
		    $sharepopupleftimg = !empty($_GET['sharepopupleftimg'])?trim($_GET['sharepopupleftimg']):"";
		}
		
		if($_FILES['sharepopuprightlogo']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['sharepopuprightlogo'], 'common') && $upload->save(1)) {
		        $sharepopuprightlogo = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		    }
		} else {
		    $sharepopuprightlogo = !empty($_GET['sharepopuprightlogo'])?trim($_GET['sharepopuprightlogo']):"";
		}
		
		
		if($_FILES['loginlogoimg']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['loginlogoimg'], 'common') && $upload->save(1)) {
		        $loginlogoimg = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		    }
		} else {
		    $loginlogoimg = !empty($_GET['loginlogoimg'])?trim($_GET['loginlogoimg']):"";
		}
		
		
		if($_FILES['mobilebarimg']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['mobilebarimg'], 'common') && $upload->save(1)) {
		        $mobilebarimg = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		    }
		} else {
		    $mobilebarimg = !empty($_GET['mobilebarimg'])?trim($_GET['mobilebarimg']):"";
		}
		
		
		foreach($setting as $sdata){
		    if($sdata['key'] == 'isopendg'){
		        if($sdata['value'] == '1' && $sdata['value'] == $isopendg){
		            
		        }
		        if($sdata['value'] == '0' && $sdata['value'] == $isopendg){
		        
		        }
		        if($sdata['value'] == '1' && $isopendg == '0'){
		            $sql = <<<EOF
UPDATE `pre_common_nav` SET available = '0' WHERE url like '%plugin.php?id=jzsjiale_daogou:daogou%' ;
DELETE FROM `pre_common_nav` WHERE url like '%plugin.php?id=jzsjiale_daogou:faxian%' ;
DELETE FROM `pre_common_nav` WHERE url like '%plugin.php?id=jzsjiale_daogou:haowu%' ;
DELETE FROM `pre_common_nav` WHERE url like '%plugin.php?id=jzsjiale_daogou:xiewenzhang%' ;
DELETE FROM `pre_common_nav` WHERE url like '%plugin.php?id=jzsjiale_daogou:souquan%' ;
DELETE FROM `pre_common_nav` WHERE url like '%forum.php?daogou%' ;
EOF;
		            
		            runquery($sql);
		        }
		        if($sdata['value'] == '0' && $isopendg == '1'){
		            $installmenu1 = plang('installmenu1');
		            $installmenu2 = plang('installmenu2');
		            $installmenu3 = plang('installmenu3');
		            $installmenu4 = plang('installmenu4');
		            $installmenu5 = plang('installmenu5');
		            $sql = <<<EOF
INSERT INTO `pre_common_nav` (`parentid`,`name`,`title`,`url`,`identifier`,`target`,`type`,`available`,`displayorder`,`highlight`,`level`,`subtype`,`subcols`,`icon`,`subname`,`suburl`,`navtype`,`logo`) VALUES 
(0,'$installmenu1','','plugin.php?id=jzsjiale_daogou:faxian','',0,1,1,2,0,0,0,0,'','','',0,''),
(0,'$installmenu2','','plugin.php?id=jzsjiale_daogou:haowu','',0,1,1,3,0,0,0,0,'','','',0,''),
(0,'$installmenu5','','plugin.php?id=jzsjiale_daogou:souquan','',0,1,1,4,0,0,0,0,'','','',0,''),
(0,'$installmenu3','','plugin.php?id=jzsjiale_daogou:xiewenzhang','',0,1,1,5,0,0,0,0,'','','',0,''),
(0,'$installmenu4','','forum.php?daogou','',0,1,0,6,0,0,0,0,'','','',0,'');
    
UPDATE `pre_common_nav` SET available = '1' WHERE url like '%plugin.php?id=jzsjiale_daogou:daogou%' ;
EOF;
		        
		            runquery($sql);
		        }
		        $_G[jzsjiale_tpl_daogou][isopendg]=$isopendg;
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$isopendg);
		        updatecache('setting');
		    }
		    if($sdata['key'] == 'weijingtaimokuai'){
		        if($sdata['value'] == '1' && $sdata['value'] == $weijingtaimokuai){
		        
		        }
		        if($sdata['value'] == '0' && $sdata['value'] == $weijingtaimokuai){
		        
		        }
		        if($sdata['value'] == '1' && $weijingtaimokuai == '0'){
		            $sql = <<<EOF
UPDATE `pre_common_nav` SET url = 'plugin.php?id=jzsjiale_daogou:daogou' WHERE url like '%index.html%';
UPDATE `pre_common_nav` SET url = 'plugin.php?id=jzsjiale_daogou:faxian' WHERE url like '%faxian.html%';
UPDATE `pre_common_nav` SET url = 'plugin.php?id=jzsjiale_daogou:haowu' WHERE url like '%haowu.html%';
UPDATE `pre_common_nav` SET url = 'plugin.php?id=jzsjiale_daogou:souquan' WHERE url like '%souquan.html%';
UPDATE `pre_common_nav` SET url = 'plugin.php?id=jzsjiale_daogou:xiewenzhang' WHERE url like '%xiewenzhang.html%';
EOF;
		        
		            runquery($sql);
		        }
		        if($sdata['value'] == '0' && $weijingtaimokuai == '1'){
		            $sql = <<<EOF
UPDATE `pre_common_nav` SET url = 'index.html' WHERE url like '%plugin.php?id=jzsjiale_daogou:daogou%';
UPDATE `pre_common_nav` SET url = 'faxian.html' WHERE url like '%plugin.php?id=jzsjiale_daogou:faxian%';
UPDATE `pre_common_nav` SET url = 'haowu.html' WHERE url like '%plugin.php?id=jzsjiale_daogou:haowu%';
UPDATE `pre_common_nav` SET url = 'souquan.html' WHERE url like '%plugin.php?id=jzsjiale_daogou:souquan%';
UPDATE `pre_common_nav` SET url = 'xiewenzhang.html' WHERE url like '%plugin.php?id=jzsjiale_daogou:xiewenzhang%';
EOF;
		            
		            runquery($sql);
		        }
		        
		        $_G[jzsjiale_tpl_daogou][weijingtaimokuai]=$weijingtaimokuai;
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$weijingtaimokuai);
		        updatecache('setting');
		    }
		    if($sdata['key'] == 'xinchuangkou'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$xinchuangkou);
		    }
		    if($sdata['key'] == 'onlymynav'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$onlymynav);
		    }
		    if($sdata['key'] == 'qiangzhinavindex'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$qiangzhinavindex);
		    }
		    if($sdata['key'] == 'qiangzhinavfaxian'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$qiangzhinavfaxian);
		    }
		    if($sdata['key'] == 'qiangzhinavhaowu'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$qiangzhinavhaowu);
		    }
            if($sdata['key'] == 'qiangzhinavsouquan'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$qiangzhinavsouquan);
            }
		    if($sdata['key'] == 'qiangzhinavxiewenzhang'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$qiangzhinavxiewenzhang);
		    }
		    if($sdata['key'] == 'daogoustyle'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$daogoustyle);
		    }
		    if($sdata['key'] == 'weijingtai'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$weijingtai);
		    }
		    if($sdata['key'] == 'diynav'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$diynav);
		    }
		    if($sdata['key'] == 'title'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$title);
		    }
		    if($sdata['key'] == 'keywords'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$keywords);
		    }
		    if($sdata['key'] == 'description'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$description);
		    }
            if($sdata['key'] == 'sharelogo300'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$sharelogo300);
            }
		    if($sdata['key'] == 'isopenpchdp'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$isopenpchdp);
		    }
		    if($sdata['key'] == 'pchdpmaxwidth'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$pchdpmaxwidth);
		    }
		    if($sdata['key'] == 'isopenmobilehdp'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$isopenmobilehdp);
		    }
		    if($sdata['key'] == 'defaultimg'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$defaultimg);
		    }
		    if($sdata['key'] == 'headercode'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$headercode);
		    }
		    if($sdata['key'] == 'footercode'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$footercode);
		    }
		    if($sdata['key'] == 'homeadurl'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$homeadurl);
		    }
		    if($sdata['key'] == 'homeadimg'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$homeadimg);
		    }
		    if($sdata['key'] == 'text1'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$text1);
		    }
		    if($sdata['key'] == 'text2'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$text2);
		    }
		    if($sdata['key'] == 'text3'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$text3);
		    }
		    if($sdata['key'] == 'logoimg'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$logoimg);
		    }
		    if($sdata['key'] == 'footerlogoimg'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$footerlogoimg);
		    }
		    if($sdata['key'] == 'erweimaimg'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$erweimaimg);
		    }
		    if($sdata['key'] == 'footermenu1'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$footermenu1);
		    }
		    if($sdata['key'] == 'footermenu2'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$footermenu2);
		    }
		    if($sdata['key'] == 'sharepopupleftimg'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$sharepopupleftimg);
		    }
		    if($sdata['key'] == 'sharepopuprightlogo'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$sharepopuprightlogo);
		    }
		    if($sdata['key'] == 'isopenmobilebar'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$isopenmobilebar);
		    }
		    if($sdata['key'] == 'mobilebarcode'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$mobilebarcode);
		    }
		    if($sdata['key'] == 'mobilebarimg'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$mobilebarimg);
		    }
		    if($sdata['key'] == 'logoimgurl'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$logoimgurl);
		    }
		    if($sdata['key'] == 'footerlogoimgurl'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$footerlogoimgurl);
		    }
		    if($sdata['key'] == 'homelogo121'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$homelogo121);
		    }
		    if($sdata['key'] == 'homelogo600'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$homelogo600);
		    }
		    if($sdata['key'] == 'faviconico'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$faviconico);
		    }
		    if($sdata['key'] == 'sharehouzhui'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$sharehouzhui);
		    }
		    if($sdata['key'] == 'isopencnxh'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$isopencnxh);
		    }
		    if($sdata['key'] == 'cnxhnum'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$cnxhnum);
		    }
		    if($sdata['key'] == 'isopenarticle'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$isopenarticle);
		    }
		    if($sdata['key'] == 'isopenpost'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$isopenpost);
		    }
		    
		    if($sdata['key'] == 'loginlogoimg'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$loginlogoimg);
		    }
		    if($sdata['key'] == 'isopenxiangguanhaowu'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$isopenxiangguanhaowu);
		    }
		    if($sdata['key'] == 'isopenfaxiangundong'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$isopenfaxiangundong);
		    }
		    if($sdata['key'] == 'isopenpinglun'){
		        C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$isopenpinglun);
		    }
            if($sdata['key'] == 'haowuheader'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$haowuheader);
            }
            if($sdata['key'] == 'haowuheaderbtn'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$haowuheaderbtn);
            }
            if($sdata['key'] == 'autotuijian'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$autotuijian);
            }
            if($sdata['key'] == 'autotuijianlll'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$autotuijianlll);
            }
            if($sdata['key'] == 'souquantklbtn'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$souquantklbtn);
            }
            if($sdata['key'] == 'titlefaxian'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$titlefaxian);
            }
            if($sdata['key'] == 'keywordsfaxian'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$keywordsfaxian);
            }
            if($sdata['key'] == 'descriptionfaxian'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$descriptionfaxian);
            }
            if($sdata['key'] == 'titlehaowu'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$titlehaowu);
            }
            if($sdata['key'] == 'keywordshaowu'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$keywordshaowu);
            }
            if($sdata['key'] == 'descriptionhaowu'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$descriptionhaowu);
            }
            if($sdata['key'] == 'titlesouquan'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$titlesouquan);
            }
            if($sdata['key'] == 'keywordssouquan'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$keywordssouquan);
            }
            if($sdata['key'] == 'descriptionsouquan'){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->updateOption($sdata['id'],$descriptionsouquan);
            }
		}
		
		recache();
		cpmsg('jzsjiale_daogou:addok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=daogoumanage', 'succeed');
		
	
	}
	
	
}



function recache(){
    $daogouoption = C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->getall();
    
    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_daogou', getcachevars(array('daogouoption' => $daogouoption)));
}

loadcache('plugin');




/////////erjidaohang end

echo '<div class="colorbox"><h4>'.plang('aboutdaogou').'</h4>'.
    '<table cellspacing="0" cellpadding="3"><tr>'.
    '<td valign="top">'.plang('daogoudescription').'</td></tr></table>'.
    '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

/////////erjidaohang start
echo '<br/><div style="border-bottom:2px solid #6AC3F6;padding-bottom:5px;">'
    .'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=daogoumanage" style="color:red;"><strong>'.plang('menu2jichushezhi').'</strong></a>'
    .'&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?frames=yes&action=misc&operation=link" target="_blank"><strong>'.plang('menu2forumlinks').'</strong></a>'
    .'&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian" ><strong>'.plang('menu2hdpmanage').'</strong></a>'
    .'&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory" ><strong>'.plang('menu2tiezifenleimanage').'</strong></a>'
    .'</div><br/>';



$setting = C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->getall();

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=daogoumanage&act=save', 'enctype');
showsubmit('submit', 'submit');
showtableheader(plang('dgjichushezhi'), '');


$searchArrayField = $utils->searchArrayGetField('isopendg',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'isopendg','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgisopendg'),'dg[isopendg]','1','radio','','',plang('dgisopendg_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('isopendg',$setting);
    showsetting(plang('dgisopendg'),'dg[isopendg]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgisopendg_msg'));
}

$searchArrayField = $utils->searchArrayGetField('isopenarticle',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'isopenarticle','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgisopenarticle'),'dg[isopenarticle]','1','radio','','',plang('dgisopenarticle_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('isopenarticle',$setting);
    showsetting(plang('dgisopenarticle'),'dg[isopenarticle]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgisopenarticle_msg'));
}

$searchArrayField = $utils->searchArrayGetField('isopenpost',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'isopenpost','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgisopenpost'),'dg[isopenpost]','1','radio','','',plang('dgisopenpost_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('isopenpost',$setting);
    showsetting(plang('dgisopenpost'),'dg[isopenpost]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgisopenpost_msg'));
}

$searchArrayField = $utils->searchArrayGetField('weijingtaimokuai',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'weijingtaimokuai','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgweijingtaimokuai'),'dg[weijingtaimokuai]','0','radio','','',plang('dgweijingtaimokuai_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('weijingtaimokuai',$setting);
    showsetting(plang('dgweijingtaimokuai'),'dg[weijingtaimokuai]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgweijingtaimokuai_msg'));
}


$searchArrayField = $utils->searchArrayGetField('weijingtai',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'weijingtai','value'=>'0');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    $_G[jzsjiale_tpl_daogou][weijingtai]='0';
    $weijingtaiselect ='';
    $weijingtaiselect .= '<option value="0" selected>'.plang('dgweijingtaibuqiyong').'</option>';
    $weijingtaiselect .= '<option value="1">'.plang('dgweijingtai1').'</option>';
    $weijingtaiselect .= '<option value="2">'.plang('dgweijingtai2').'</option>';
    $weijingtaiselect .= '<option value="3">'.plang('dgweijingtai3').'</option>';
    $weijingtaiselect .= '<option value="4">'.plang('dgweijingtai4').'</option>';
    $weijingtaiselect .= '<option value="5">'.plang('dgweijingtai5').'</option>';
    showsetting(plang('dgweijingtai'),'dg[weijingtai]','','<select name="dg[weijingtai]">'.$weijingtaiselect.'</select>','',0,plang('dgweijingtai_msg'));

}else{
    $searchArrayValue = $utils->searchArrayByField('weijingtai',$setting);
    $_G[jzsjiale_tpl_daogou][weijingtai]=$searchArrayValue;
    $weijingtaiselect ='';
    $weijingtaiselect .= '<option value="0" '.($searchArrayValue == 0?"selected":"").'>'.plang('dgweijingtaibuqiyong').'</option>';
    $weijingtaiselect .= '<option value="1" '.($searchArrayValue == 1?"selected":"").'>'.plang('dgweijingtai1').'</option>';
    $weijingtaiselect .= '<option value="2" '.($searchArrayValue == 2?"selected":"").'>'.plang('dgweijingtai2').'</option>';
    $weijingtaiselect .= '<option value="3" '.($searchArrayValue == 3?"selected":"").'>'.plang('dgweijingtai3').'</option>';
    $weijingtaiselect .= '<option value="4" '.($searchArrayValue == 4?"selected":"").'>'.plang('dgweijingtai4').'</option>';
    $weijingtaiselect .= '<option value="5" '.($searchArrayValue == 5?"selected":"").'>'.plang('dgweijingtai5').'</option>';
    showsetting(plang('dgweijingtai'),'dg[weijingtai]','','<select name="dg[weijingtai]">'.$weijingtaiselect.'</select>','',0,plang('dgweijingtai_msg'));
}


$searchArrayField = $utils->searchArrayGetField('daogoustyle',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'daogoustyle','value'=>'2');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    $_G[jzsjiale_tpl_daogou][daogoustyle]='2';
    $daotoustyleselect ='';
    $daotoustyleselect .= '<option value="1">'.plang('dgdaogoustyleselect').'1</option>';
    $daotoustyleselect .= '<option value="2" selected>'.plang('dgdaogoustyleselect').'2</option>';
    showsetting(plang('dgdaogoustyle'),'dg[daogoustyle]','','<select name="dg[daogoustyle]">'.$daotoustyleselect.'</select>','',0,plang('dgdaogoustyle_msg'));

}else{
    $searchArrayValue = $utils->searchArrayByField('daogoustyle',$setting);
    $_G[jzsjiale_tpl_daogou][daogoustyle]=$searchArrayValue;
    $daotoustyleselect ='';
    $daotoustyleselect .= '<option value="1" '.($searchArrayValue == 1?"selected":"").'>'.plang('dgdaogoustyleselect').'1</option>';
    $daotoustyleselect .= '<option value="2" '.($searchArrayValue == 2?"selected":"").'>'.plang('dgdaogoustyleselect').'2</option>';
    showsetting(plang('dgdaogoustyle'),'dg[daogoustyle]','','<select name="dg[daogoustyle]">'.$daotoustyleselect.'</select>','',0,plang('dgdaogoustyle_msg'));
}

$searchArrayField = $utils->searchArrayGetField('xinchuangkou',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'xinchuangkou','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgxinchuangkou'),'dg[xinchuangkou]','1','radio','','',plang('dgxinchuangkou_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('xinchuangkou',$setting);
    showsetting(plang('dgxinchuangkou'),'dg[xinchuangkou]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgxinchuangkou_msg'));
}


$searchArrayField = $utils->searchArrayGetField('onlymynav',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'onlymynav','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgonlymynav'),'dg[onlymynav]','1','radio','','',plang('dgonlymynav_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('onlymynav',$setting);
    showsetting(plang('dgonlymynav'),'dg[onlymynav]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgonlymynav_msg'));
}

$searchArrayField = $utils->searchArrayGetField('qiangzhinavindex',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'qiangzhinavindex','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgqiangzhinavindex'),'dg[qiangzhinavindex]','1','radio','','',plang('dgqiangzhinavindex_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('qiangzhinavindex',$setting);
    showsetting(plang('dgqiangzhinavindex'),'dg[qiangzhinavindex]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgqiangzhinavindex_msg'));
}

$searchArrayField = $utils->searchArrayGetField('qiangzhinavfaxian',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'qiangzhinavfaxian','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgqiangzhinavfaxian'),'dg[qiangzhinavfaxian]','1','radio','','',plang('dgqiangzhinavfaxian_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('qiangzhinavfaxian',$setting);
    showsetting(plang('dgqiangzhinavfaxian'),'dg[qiangzhinavfaxian]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgqiangzhinavfaxian_msg'));
}

$searchArrayField = $utils->searchArrayGetField('qiangzhinavhaowu',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'qiangzhinavhaowu','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgqiangzhinavhaowu'),'dg[qiangzhinavhaowu]','1','radio','','',plang('dgqiangzhinavhaowu_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('qiangzhinavhaowu',$setting);
    showsetting(plang('dgqiangzhinavhaowu'),'dg[qiangzhinavhaowu]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgqiangzhinavhaowu_msg'));
}

$searchArrayField = $utils->searchArrayGetField('qiangzhinavsouquan',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'qiangzhinavsouquan','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgqiangzhinavsouquan'),'dg[qiangzhinavsouquan]','1','radio','','',plang('dgqiangzhinavsouquan_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('qiangzhinavsouquan',$setting);
    showsetting(plang('dgqiangzhinavsouquan'),'dg[qiangzhinavsouquan]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgqiangzhinavsouquan_msg'));
}

$searchArrayField = $utils->searchArrayGetField('qiangzhinavxiewenzhang',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'qiangzhinavxiewenzhang','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgqiangzhinavxiewenzhang'),'dg[qiangzhinavxiewenzhang]','1','radio','','',plang('dgqiangzhinavxiewenzhang_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('qiangzhinavxiewenzhang',$setting);
    showsetting(plang('dgqiangzhinavxiewenzhang'),'dg[qiangzhinavxiewenzhang]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgqiangzhinavxiewenzhang_msg'));
}

$searchArrayField = $utils->searchArrayGetField('diynav',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'diynav','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgdiynav'),'dg[diynav]','','textarea','','',plang('dgdiynav_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('diynav',$setting);
    showsetting(plang('dgdiynav'),'dg[diynav]',dhtmlspecialchars($searchArrayValue),'textarea','','',plang('dgdiynav_msg'));
}

$searchArrayField = $utils->searchArrayGetField('title',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'title','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgtitle'),'dg[title]','','text','','',plang('dgtitle_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('title',$setting);
    showsetting(plang('dgtitle'),'dg[title]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dgtitle_msg'));
}

$searchArrayField = $utils->searchArrayGetField('logoimg',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'logoimg','value'=>'source/plugin/jzsjiale_daogou/static/images/daogou/v1/headerlogo.png');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dglogoimg'),'logoimg','source/plugin/jzsjiale_daogou/static/images/daogou/v1/headerlogo.png','filetext','','',plang('dglogoimg_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('logoimg',$setting);
    showsetting(plang('dglogoimg'),'logoimg',dhtmlspecialchars($searchArrayValue),'filetext','','',plang('dglogoimg_msg'));
}

$searchArrayField = $utils->searchArrayGetField('logoimgurl',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'logoimgurl','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dglogoimgurl'),'dg[logoimgurl]','','text','','',plang('dglogoimgurl_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('logoimgurl',$setting);
    showsetting(plang('dglogoimgurl'),'dg[logoimgurl]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dglogoimgurl_msg'));
}

$searchArrayField = $utils->searchArrayGetField('footerlogoimg',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'footerlogoimg','value'=>'source/plugin/jzsjiale_daogou/static/images/daogou/v1/footerlogo.png');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgfooterlogoimg'),'footerlogoimg','source/plugin/jzsjiale_daogou/static/images/daogou/v1/footerlogo.png','filetext','','',plang('dgfooterlogoimg_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('footerlogoimg',$setting);
    showsetting(plang('dgfooterlogoimg'),'footerlogoimg',dhtmlspecialchars($searchArrayValue),'filetext','','',plang('dgfooterlogoimg_msg'));
}

$searchArrayField = $utils->searchArrayGetField('footerlogoimgurl',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'footerlogoimgurl','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgfooterlogoimgurl'),'dg[footerlogoimgurl]','','text','','',plang('dgfooterlogoimgurl_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('footerlogoimgurl',$setting);
    showsetting(plang('dgfooterlogoimgurl'),'dg[footerlogoimgurl]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dgfooterlogoimgurl_msg'));
}

$searchArrayField = $utils->searchArrayGetField('homelogo121',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'homelogo121','value'=>'source/plugin/jzsjiale_daogou/static/images/daogou/v1/homelogo121.png');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dghomelogo121'),'homelogo121','source/plugin/jzsjiale_daogou/static/images/daogou/v1/homelogo121.png','filetext','','',plang('dghomelogo121_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('homelogo121',$setting);
    showsetting(plang('dghomelogo121'),'homelogo121',dhtmlspecialchars($searchArrayValue),'filetext','','',plang('dghomelogo121_msg'));
}

$searchArrayField = $utils->searchArrayGetField('homelogo600',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'homelogo600','value'=>'source/plugin/jzsjiale_daogou/static/images/daogou/v1/homelogo600.png');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dghomelogo600'),'homelogo600','source/plugin/jzsjiale_daogou/static/images/daogou/v1/homelogo600.png','filetext','','',plang('dghomelogo600_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('homelogo600',$setting);
    showsetting(plang('dghomelogo600'),'homelogo600',dhtmlspecialchars($searchArrayValue),'filetext','','',plang('dghomelogo600_msg'));
}

$searchArrayField = $utils->searchArrayGetField('faviconico',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'faviconico','value'=>'source/plugin/jzsjiale_daogou/static/images/daogou/v1/favicon.ico');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgfaviconico'),'faviconico','source/plugin/jzsjiale_daogou/static/images/daogou/v1/favicon.ico','filetext','','',plang('dgfaviconico_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('faviconico',$setting);
    showsetting(plang('dgfaviconico'),'faviconico',dhtmlspecialchars($searchArrayValue),'filetext','','',plang('dgfaviconico_msg'));
}

$searchArrayField = $utils->searchArrayGetField('keywords',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'keywords','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgkeywords'),'dg[keywords]','','textarea','','',plang('dgkeywords_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('keywords',$setting);
    showsetting(plang('dgkeywords'),'dg[keywords]',dhtmlspecialchars($searchArrayValue),'textarea','','',plang('dgkeywords_msg'));
}

$searchArrayField = $utils->searchArrayGetField('description',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'description','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgdescription'),'dg[description]','','textarea','','',plang('dgdescription_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('description',$setting);
    showsetting(plang('dgdescription'),'dg[description]',dhtmlspecialchars($searchArrayValue),'textarea','','',plang('dgdescription_msg'));
}

$searchArrayField = $utils->searchArrayGetField('sharelogo300',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'sharelogo300','value'=>'source/plugin/jzsjiale_daogou/static/images/daogou/v2/sharelogo300.png');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgsharelogo300'),'sharelogo300','source/plugin/jzsjiale_daogou/static/images/daogou/v2/sharelogo300.png','filetext','','',plang('dgsharelogo300_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('sharelogo300',$setting);
    showsetting(plang('dgsharelogo300'),'sharelogo300',dhtmlspecialchars($searchArrayValue),'filetext','','',plang('dgsharelogo300_msg'));
}

$searchArrayField = $utils->searchArrayGetField('isopenpchdp',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'isopenpchdp','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgisopenpchdp'),'dg[isopenpchdp]','1','radio','','',plang('dgisopenpchdp_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('isopenpchdp',$setting);
    showsetting(plang('dgisopenpchdp'),'dg[isopenpchdp]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgisopenpchdp_msg'));
}


$searchArrayField = $utils->searchArrayGetField('pchdpmaxwidth',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'pchdpmaxwidth','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgpchdpmaxwidth'),'dg[pchdpmaxwidth]','','text','','',plang('dgpchdpmaxwidth_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('pchdpmaxwidth',$setting);
    showsetting(plang('dgpchdpmaxwidth'),'dg[pchdpmaxwidth]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dgpchdpmaxwidth_msg'));
}

$searchArrayField = $utils->searchArrayGetField('isopenmobilehdp',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'isopenmobilehdp','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgisopenmobilehdp'),'dg[isopenmobilehdp]','1','radio','','',plang('dgisopenmobilehdp_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('isopenmobilehdp',$setting);
    showsetting(plang('dgisopenmobilehdp'),'dg[isopenmobilehdp]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgisopenmobilehdp_msg'));
}


$searchArrayField = $utils->searchArrayGetField('defaultimg',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'defaultimg','value'=>'source/plugin/jzsjiale_daogou/static/images/daogou/v1/nopic.jpg');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgdefaultimg'),'defaultimg','source/plugin/jzsjiale_daogou/static/images/daogou/v1/nopic.jpg','filetext','','',plang('dgdefaultimg_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('defaultimg',$setting);
    showsetting(plang('dgdefaultimg'),'defaultimg',dhtmlspecialchars($searchArrayValue),'filetext','','',plang('dgdefaultimg_msg'));
}


$searchArrayField = $utils->searchArrayGetField('headercode',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'headercode','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgheadercode'),'dg[headercode]','','textarea','','',plang('dgheadercode_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('headercode',$setting);
    showsetting(plang('dgheadercode'),'dg[headercode]',htmlspecialchars_decode($searchArrayValue),'textarea','','',plang('dgheadercode_msg'));
}


$searchArrayField = $utils->searchArrayGetField('footercode',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'footercode','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgfootercode'),'dg[footercode]','','textarea','','',plang('dgfootercode_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('footercode',$setting);
    showsetting(plang('dgfootercode'),'dg[footercode]',htmlspecialchars_decode($searchArrayValue),'textarea','','',plang('dgfootercode_msg'));
}


$searchArrayField = $utils->searchArrayGetField('homeadurl',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'homeadurl','value'=>'http://dism.taobao.com/?@32563.developer');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dghomeadurl'),'dg[homeadurl]','','text','','',plang('dghomeadurl_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('homeadurl',$setting);
    showsetting(plang('dghomeadurl'),'dg[homeadurl]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dghomeadurl_msg'));
}


$searchArrayField = $utils->searchArrayGetField('homeadimg',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'homeadimg','value'=>'source/plugin/jzsjiale_daogou/static/images/daogou/v1/ad1.png');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dghomeadimg'),'homeadimg','source/plugin/jzsjiale_daogou/static/images/daogou/v1/ad1.png','filetext','','',plang('dghomeadimg_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('homeadimg',$setting);
    showsetting(plang('dghomeadimg'),'homeadimg',dhtmlspecialchars($searchArrayValue),'filetext','','',plang('dghomeadimg_msg'));
}

$searchArrayField = $utils->searchArrayGetField('erweimaimg',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'erweimaimg','value'=>'source/plugin/jzsjiale_daogou/static/images/daogou/v1/erweima.png');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgerweimaimg'),'erweimaimg','source/plugin/jzsjiale_daogou/static/images/daogou/v1/erweima.png','filetext','','',plang('dgerweimaimg_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('erweimaimg',$setting);
    showsetting(plang('dgerweimaimg'),'erweimaimg',dhtmlspecialchars($searchArrayValue),'filetext','','',plang('dgerweimaimg_msg'));
}


$searchArrayField = $utils->searchArrayGetField('loginlogoimg',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'loginlogoimg','value'=>'source/plugin/jzsjiale_daogou/static/images/daogou/v2/login-top-bg.png');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgloginlogoimg'),'loginlogoimg','source/plugin/jzsjiale_daogou/static/images/daogou/v2/login-top-bg.png','filetext','','',plang('dgloginlogoimg_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('loginlogoimg',$setting);
    showsetting(plang('dgloginlogoimg'),'loginlogoimg',$searchArrayValue,'filetext','','',plang('dgloginlogoimg_msg'));
}


$searchArrayField = $utils->searchArrayGetField('text1',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'text1','value'=>plang('text1'));
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgtext1'),'dg[text1]','','text','','',plang('dgtext1_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('text1',$setting);
    showsetting(plang('dgtext1'),'dg[text1]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dgtext1_msg'));
}

$searchArrayField = $utils->searchArrayGetField('text2',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'text2','value'=>plang('text2'));
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgtext2'),'dg[text2]','','text','','',plang('dgtext2_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('text2',$setting);
    showsetting(plang('dgtext2'),'dg[text2]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dgtext2_msg'));
}

$searchArrayField = $utils->searchArrayGetField('text3',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'text3','value'=>plang('text3'));
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgtext3'),'dg[text3]','','textarea','','',plang('dgtext3_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('text3',$setting);
    showsetting(plang('dgtext3'),'dg[text3]',htmlspecialchars_decode($searchArrayValue),'textarea','','',plang('dgtext3_msg'));
}


$searchArrayField = $utils->searchArrayGetField('footermenu1',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'footermenu1','value'=>plang('footermenu1'));
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgfootermenu1'),'dg[footermenu1]','','textarea','','',plang('dgfootermenu1_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('footermenu1',$setting);
    showsetting(plang('dgfootermenu1'),'dg[footermenu1]',dhtmlspecialchars($searchArrayValue),'textarea','','',plang('dgfootermenu1_msg'));
}


$searchArrayField = $utils->searchArrayGetField('footermenu2',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'footermenu2','value'=>plang('footermenu2'));
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgfootermenu2'),'dg[footermenu2]','','textarea','','',plang('dgfootermenu2_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('footermenu2',$setting);
    showsetting(plang('dgfootermenu2'),'dg[footermenu2]',dhtmlspecialchars($searchArrayValue),'textarea','','',plang('dgfootermenu2_msg'));
}

$searchArrayField = $utils->searchArrayGetField('isopenmobilebar',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'isopenmobilebar','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgisopenmobilebar'),'dg[isopenmobilebar]','1','radio','','',plang('dgisopenmobilebar_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('isopenmobilebar',$setting);
    showsetting(plang('dgisopenmobilebar'),'dg[isopenmobilebar]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgisopenmobilebar_msg'));
}

$searchArrayField = $utils->searchArrayGetField('mobilebarimg',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'mobilebarimg','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgmobilebarimg'),'mobilebarimg','','filetext','','',plang('dgmobilebarimg_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('mobilebarimg',$setting);
    showsetting(plang('dgmobilebarimg'),'mobilebarimg',$searchArrayValue,'filetext','','',plang('dgmobilebarimg_msg'));
}

$searchArrayField = $utils->searchArrayGetField('mobilebarcode',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'mobilebarcode','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgmobilebarcode'),'dg[mobilebarcode]','','textarea','','',plang('dgmobilebarcode_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('mobilebarcode',$setting);
    showsetting(plang('dgmobilebarcode'),'dg[mobilebarcode]',htmlspecialchars_decode($searchArrayValue),'textarea','','',plang('dgmobilebarcode_msg'));
}

$searchArrayField = $utils->searchArrayGetField('sharehouzhui',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'sharehouzhui','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgsharehouzhui'),'dg[sharehouzhui]','','text','','',plang('dgsharehouzhui_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('sharehouzhui',$setting);
    showsetting(plang('dgsharehouzhui'),'dg[sharehouzhui]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dgsharehouzhui_msg'));
}


$searchArrayField = $utils->searchArrayGetField('sharepopupleftimg',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'sharepopupleftimg','value'=>'source/plugin/jzsjiale_daogou/static/images/daogou/v2/download-model-left.jpg');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgsharepopupleftimg'),'sharepopupleftimg','source/plugin/jzsjiale_daogou/static/images/daogou/v2/download-model-left.jpg','filetext','','',plang('dgsharepopupleftimg_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('sharepopupleftimg',$setting);
    showsetting(plang('dgsharepopupleftimg'),'sharepopupleftimg',dhtmlspecialchars($searchArrayValue),'filetext','','',plang('dgsharepopupleftimg_msg'));
}

$searchArrayField = $utils->searchArrayGetField('sharepopuprightlogo',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'sharepopuprightlogo','value'=>'source/plugin/jzsjiale_daogou/static/images/daogou/v2/download-model-code-bg.jpg');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgsharepopuprightlogo'),'sharepopuprightlogo','source/plugin/jzsjiale_daogou/static/images/daogou/v2/download-model-code-bg.jpg','filetext','','',plang('dgsharepopuprightlogo_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('sharepopuprightlogo',$setting);
    showsetting(plang('dgsharepopuprightlogo'),'sharepopuprightlogo',dhtmlspecialchars($searchArrayValue),'filetext','','',plang('dgsharepopuprightlogo_msg'));
}

$searchArrayField = $utils->searchArrayGetField('isopencnxh',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'isopencnxh','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgisopencnxh'),'dg[isopencnxh]','1','radio','','',plang('dgisopencnxh_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('isopencnxh',$setting);
    showsetting(plang('dgisopencnxh'),'dg[isopencnxh]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgisopencnxh_msg'));
}

$searchArrayField = $utils->searchArrayGetField('cnxhnum',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'cnxhnum','value'=>'4');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgcnxhnum'),'dg[cnxhnum]','4','text','','',plang('dgcnxhnum_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('cnxhnum',$setting);
    showsetting(plang('dgcnxhnum'),'dg[cnxhnum]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dgcnxhnum_msg'));
}


$searchArrayField = $utils->searchArrayGetField('isopenxiangguanhaowu',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'isopenxiangguanhaowu','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgisopenxiangguanhaowu'),'dg[isopenxiangguanhaowu]','1','radio','','',plang('dgisopenxiangguanhaowu_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('isopenxiangguanhaowu',$setting);
    showsetting(plang('dgisopenxiangguanhaowu'),'dg[isopenxiangguanhaowu]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgisopenxiangguanhaowu_msg'));
}


$searchArrayField = $utils->searchArrayGetField('isopenfaxiangundong',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'isopenfaxiangundong','value'=>'0');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgisopenfaxiangundong'),'dg[isopenfaxiangundong]','0','radio','','',plang('dgisopenfaxiangundong_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('isopenfaxiangundong',$setting);
    showsetting(plang('dgisopenfaxiangundong'),'dg[isopenfaxiangundong]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgisopenfaxiangundong_msg'));
}

$searchArrayField = $utils->searchArrayGetField('isopenpinglun',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'isopenpinglun','value'=>'1');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgisopenpinglun'),'dg[isopenpinglun]','1','radio','','',plang('dgisopenpinglun_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('isopenpinglun',$setting);
    showsetting(plang('dgisopenpinglun'),'dg[isopenpinglun]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgisopenpinglun_msg'));
}


$searchArrayField = $utils->searchArrayGetField('haowuheader',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'haowuheader','value'=>'0');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dghaowuheader'),'dg[haowuheader]','0','radio','','',plang('dghaowuheader_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('haowuheader',$setting);
    showsetting(plang('dghaowuheader'),'dg[haowuheader]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dghaowuheader_msg'));
}


$searchArrayField = $utils->searchArrayGetField('haowuheaderbtn',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'haowuheaderbtn','value'=>'0');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dghaowuheaderbtn'),'dg[haowuheaderbtn]','0','radio','','',plang('dghaowuheaderbtn_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('haowuheaderbtn',$setting);
    showsetting(plang('dghaowuheaderbtn'),'dg[haowuheaderbtn]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dghaowuheaderbtn_msg'));
}



$searchArrayField = $utils->searchArrayGetField('autotuijian',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'autotuijian','value'=>'0');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    $_G[jzsjiale_tpl_daogou][autotuijian]='0';
    $dgcategory = $utils->getdaogousetting();
    $autotuijianselect ='';
    $autotuijianselect .= '<option value="0" selected>'.plang('dgautotuijianbuqiyong').'</option>';
    foreach($dgcategory as $dgkey => $dgvalue) {
        $autotuijianselect .= '<option value="'.$dgvalue[0].'">'.$dgvalue[1].'</option>';
    }
    showsetting(plang('dgautotuijian'),'dg[autotuijian]','','<select name="dg[autotuijian]">'.$autotuijianselect.'</select>','',0,plang('dgautotuijian_msg'));

}else{
    $searchArrayValue = $utils->searchArrayByField('autotuijian',$setting);
    $_G[jzsjiale_tpl_daogou][autotuijian]=$searchArrayValue;
    $dgcategory = $utils->getdaogousetting();
    $autotuijianselect ='';
    $autotuijianselect .= '<option value="0" '.($searchArrayValue == 0?"selected":"").'>'.plang('dgautotuijianbuqiyong').'</option>';
    foreach($dgcategory as $dgkey => $dgvalue) {
        $autotuijianselect .= '<option value="'.$dgvalue[0].'" '.($searchArrayValue == $dgvalue[0]?"selected":"").'>'.$dgvalue[1].'</option>';
    }
    showsetting(plang('dgautotuijian'),'dg[autotuijian]','','<select name="dg[autotuijian]">'.$autotuijianselect.'</select>','',0,plang('dgautotuijian_msg'));
}

$searchArrayField = $utils->searchArrayGetField('autotuijianlll',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'autotuijianlll','value'=>'100');
    $_G[jzsjiale_tpl_daogou][autotuijianlll]='100';
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgautotuijianlll'),'dg[autotuijianlll]','100','text','','',plang('dgautotuijianlll_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('autotuijianlll',$setting);
    $_G[jzsjiale_tpl_daogou][autotuijianlll]=$searchArrayValue;
    showsetting(plang('dgautotuijianlll'),'dg[autotuijianlll]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dgautotuijianlll_msg'));
}


$searchArrayField = $utils->searchArrayGetField('souquantklbtn',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'souquantklbtn','value'=>'0');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgsouquantklbtn'),'dg[souquantklbtn]','0','radio','','',plang('dgsouquantklbtn_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('souquantklbtn',$setting);
    showsetting(plang('dgsouquantklbtn'),'dg[souquantklbtn]',dhtmlspecialchars($searchArrayValue),'radio','','',plang('dgsouquantklbtn_msg'));
}


showtablefooter(); /*Dism��taobao��com*/

showtableheader(plang('dgjichushezhi2'), '');

$searchArrayField = $utils->searchArrayGetField('titlefaxian',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'titlefaxian','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgtitle_faxian'),'dg[titlefaxian]','','text','','',plang('dgtitle_faxian_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('titlefaxian',$setting);
    showsetting(plang('dgtitle_faxian'),'dg[titlefaxian]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dgtitle_faxian_msg'));
}
$searchArrayField = $utils->searchArrayGetField('keywordsfaxian',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'keywordsfaxian','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgkeywords_faxian'),'dg[keywordsfaxian]','','textarea','','',plang('dgkeywords_faxian_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('keywordsfaxian',$setting);
    showsetting(plang('dgkeywords_faxian'),'dg[keywordsfaxian]',dhtmlspecialchars($searchArrayValue),'textarea','','',plang('dgkeywords_faxian_msg'));
}
$searchArrayField = $utils->searchArrayGetField('descriptionfaxian',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'descriptionfaxian','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgdescription_faxian'),'dg[descriptionfaxian]','','textarea','','',plang('dgdescription_faxian_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('descriptionfaxian',$setting);
    showsetting(plang('dgdescription_faxian'),'dg[descriptionfaxian]',dhtmlspecialchars($searchArrayValue),'textarea','','',plang('dgdescription_faxian_msg'));
}


$searchArrayField = $utils->searchArrayGetField('titlehaowu',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'titlehaowu','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgtitle_haowu'),'dg[titlehaowu]','','text','','',plang('dgtitle_haowu_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('titlehaowu',$setting);
    showsetting(plang('dgtitle_haowu'),'dg[titlehaowu]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dgtitle_haowu_msg'));
}
$searchArrayField = $utils->searchArrayGetField('keywordshaowu',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'keywordshaowu','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgkeywords_haowu'),'dg[keywordshaowu]','','textarea','','',plang('dgkeywords_haowu_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('keywordshaowu',$setting);
    showsetting(plang('dgkeywords_haowu'),'dg[keywordshaowu]',dhtmlspecialchars($searchArrayValue),'textarea','','',plang('dgkeywords_haowu_msg'));
}
$searchArrayField = $utils->searchArrayGetField('descriptionhaowu',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'descriptionhaowu','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgdescription_haowu'),'dg[descriptionhaowu]','','textarea','','',plang('dgdescription_haowu_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('descriptionhaowu',$setting);
    showsetting(plang('dgdescription_haowu'),'dg[descriptionhaowu]',dhtmlspecialchars($searchArrayValue),'textarea','','',plang('dgdescription_haowu_msg'));
}


$searchArrayField = $utils->searchArrayGetField('titlesouquan',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'titlesouquan','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgtitle_souquan'),'dg[titlesouquan]','','text','','',plang('dgtitle_souquan_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('titlesouquan',$setting);
    showsetting(plang('dgtitle_souquan'),'dg[titlesouquan]',dhtmlspecialchars($searchArrayValue),'text','','',plang('dgtitle_souquan_msg'));
}
$searchArrayField = $utils->searchArrayGetField('keywordssouquan',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'keywordssouquan','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgkeywords_souquan'),'dg[keywordssouquan]','','textarea','','',plang('dgkeywords_souquan_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('keywordssouquan',$setting);
    showsetting(plang('dgkeywords_souquan'),'dg[keywordssouquan]',dhtmlspecialchars($searchArrayValue),'textarea','','',plang('dgkeywords_souquan_msg'));
}
$searchArrayField = $utils->searchArrayGetField('descriptionsouquan',$setting);
if(!$searchArrayField){
    $dsp = array('key'=>'descriptionsouquan','value'=>'');
    C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->insert($dsp,true);
    showsetting(plang('dgdescription_souquan'),'dg[descriptionsouquan]','','textarea','','',plang('dgdescription_souquan_msg'));
}else{
    $searchArrayValue = $utils->searchArrayByField('descriptionsouquan',$setting);
    showsetting(plang('dgdescription_souquan'),'dg[descriptionsouquan]',dhtmlspecialchars($searchArrayValue),'textarea','','',plang('dgdescription_souquan_msg'));
}

showtablefooter(); /*Dism��taobao��com*/

showsubmit('submit', 'submit');
showformfooter(); /*Dism_taobao_com*/



function plang($str) {
	return lang('plugin/jzsjiale_daogou', $str);
}

function getparam($str){
    $data = array();
    $parameter = explode('&',end(explode('?',$str)));
    foreach($parameter as $val){
        $tmp = explode('=',$val);
        $data[$tmp[0]] = $tmp[1];
    }
    return $data;
}
//From: Dism��taobao��com
?>