<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
global $_G, $lang;

loadcache('plugin');



require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';
require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';

$utils = new Utils();

if($act=='sousuo'){
	
    if(submitcheck('submit')){
    
        $setting = $_GET['setting'];
        $dsp = array();
        $dsp['starttime'] = addslashes(trim($setting['starttime']));
		$dsp['endtime'] = addslashes(trim($setting['endtime']));	
        $dsp['page_no'] = daddslashes(trim($setting['page_no']));
        $dsp['page_size'] = daddslashes(trim($setting['page_size']));
        $dsp['currpage'] = '1';
        
        if(empty($dsp['starttime'])){
            cpmsg('jzsjiale_daogou:tqgstarttime_notnull', '', 'error');
        }
        if(empty($dsp['endtime'])){
            cpmsg('jzsjiale_daogou:tqgendtime_notnull', '', 'error');
        }
        if(!empty($dsp['starttime']) && !empty($dsp['endtime'])) {
			if(strtotime($dsp['endtime']) <= TIMESTAMP || strtotime($dsp['endtime']) <= strtotime($dsp['starttime'])) {
				cpmsg('jzsjiale_daogou:tqgtime_error', '', 'error');
			}
		}
        if(!empty($dsp['page_no']) && !is_numeric($dsp['page_no'])){
            cpmsg('jzsjiale_daogou:tqgpage_no_notnumeric', '', 'error');
        }
        if(!empty($dsp['page_size']) && !is_numeric($dsp['page_size'])){
            cpmsg('jzsjiale_daogou:tqgpage_size_notnumeric', '', 'error');
        }
    
        $dsp['starttime'] = $dsp['starttime'].":00";
        $dsp['endtime'] = $dsp['endtime'].":00";
        
        setSpList($dsp);
        
        
        dexit();
    }
    
}elseif($act=='spfanye'){
    
    $page = intval($_GET['page']);
    $page = $page > 0 ? $page : 1;
    
    $dsp = array();
    $dsp['starttime'] = addslashes(trim($_GET['starttime']));
	$dsp['endtime'] = addslashes(trim($_GET['endtime']));	
    $dsp['page_no'] = daddslashes(trim($_GET['page_no']));
    $dsp['page_size'] = daddslashes(trim($_GET['page_size']));
    $dsp['currpage'] = $page;
    

    $dsp['starttime'] = date('Y-m-d H:i:s', $dsp['starttime']);
    $dsp['endtime'] = date('Y-m-d H:i:s', $dsp['endtime']);
    
    if (empty($dsp['starttime'])) {
        cpmsg('jzsjiale_daogou:tqgstarttime_notnull', '', 'error');
    }
    if (empty($dsp['endtime'])) {
        cpmsg('jzsjiale_daogou:tqgendtime_notnull', '', 'error');
    }
    if (! empty($dsp['starttime']) && ! empty($dsp['endtime'])) {
        if (strtotime($dsp['endtime']) <= TIMESTAMP || strtotime($dsp['endtime']) <= strtotime($dsp['starttime'])) {
            cpmsg('jzsjiale_daogou:tqgtime_error', '', 'error');
        }
    }
    if (! empty($dsp['page_no']) && ! is_numeric($dsp['page_no'])) {
        cpmsg('jzsjiale_daogou:tqgpage_no_notnumeric', '', 'error');
    }
    if (! empty($dsp['page_size']) && ! is_numeric($dsp['page_size'])) {
        cpmsg('jzsjiale_daogou:tqgpage_size_notnumeric', '', 'error');
    }
    
    
    setSpList($dsp);
    
    dexit();
}elseif($act=='caiji'){
	
    $currpage = intval($_GET['currpage']);
    $currpage = $currpage > 0 ? $currpage : 1;
    
    $dsp = array();
    $dsp['starttime'] = addslashes(trim($_GET['starttime']));
    $dsp['endtime'] = addslashes(trim($_GET['endtime']));
    $dsp['page_no'] = daddslashes(trim($_GET['page_no']));
    $dsp['page_size'] = daddslashes(trim($_GET['page_size']));
    $dsp['currpage'] = $currpage;
    
    $dsp['starttime'] = date('Y-m-d H:i:s', $dsp['starttime']);
    $dsp['endtime'] = date('Y-m-d H:i:s', $dsp['endtime']);
    
    $spcategoryid = $_POST['spcategoryid'];
    $numiids = $_POST['numiids'];
    $numiidsstr = "";
    
    
    if (empty($dsp['starttime'])) {
        cpmsg('jzsjiale_daogou:tqg_shuju_error', '', 'error');
    }
    if (empty($dsp['endtime'])) {
        cpmsg('jzsjiale_daogou:tqg_shuju_error', '', 'error');
    }
    if (! empty($dsp['starttime']) && ! empty($dsp['endtime'])) {
        if (strtotime($dsp['endtime']) <= TIMESTAMP || strtotime($dsp['endtime']) <= strtotime($dsp['starttime'])) {
            cpmsg('jzsjiale_daogou:tqg_shuju_error', '', 'error');
        }
    }
    if (! empty($dsp['page_no']) && ! is_numeric($dsp['page_no'])) {
        cpmsg('jzsjiale_daogou:tqg_shuju_error', '', 'error');
    }
    if (! empty($dsp['page_size']) && ! is_numeric($dsp['page_size'])) {
        cpmsg('jzsjiale_daogou:tqg_shuju_error', '', 'error');
    }
    
    
    if(empty($spcategoryid)){
        $spcategoryid=0;
    }
    if(empty($numiids)){
        cpmsg('jzsjiale_daogou:tqgcxcaiji_notxuanze', '', 'error');
    }
  
    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    $tbappkey = $_config['g_appkey'];
    $tbsecretKey = $_config['g_appsecret'];
    $webbianma = $_G['charset'];
    $pid = $_config['g_pid'];
    
    if (empty($pid)) {
        cpmsg('jzsjiale_daogou:pidnull', '', 'error');
        dexit();
    }
    
    $dzoneId = explode("_", $pid);
    $dzoneId = $dzoneId[3];
    
    if (empty($dzoneId)) {
        cpmsg('jzsjiale_daogou:pidnull', '', 'error');
        dexit();
    }
    
    $gtkl = new GetTbAPI();
    $gtkl->__construct($tbappkey, $tbsecretKey);
    $tbinfo = $gtkl->gettaoqianggouitem($dsp, $dzoneId, $webbianma);
    
    $tbinfo = json_decode($tbinfo);
    
    $splistinfo = $tbinfo->results->results;
        
  
    
    $isok = false;
    
    foreach($splistinfo as $tbi){
        
        if($webbianma == "gbk"){
            $numiid = diconv(dhtmlspecialchars($tbi->num_iid),'UTF-8','GB2312');
            $title = diconv(dhtmlspecialchars($tbi->title),'UTF-8','GB2312');
            $pic_url = diconv(dhtmlspecialchars($tbi->pic_url),'UTF-8','GB2312');
            $click_url = diconv(dhtmlspecialchars($tbi->click_url),'UTF-8','GB2312');
            $reserve_price = diconv(dhtmlspecialchars($tbi->reserve_price),'UTF-8','GB2312');
            $zk_final_price = diconv(dhtmlspecialchars($tbi->zk_final_price),'UTF-8','GB2312');
        }else{
            $numiid = dhtmlspecialchars($tbi->num_iid);
            $title = dhtmlspecialchars($tbi->title);
            $pic_url = dhtmlspecialchars($tbi->pic_url);
            $click_url = dhtmlspecialchars($tbi->click_url);
            $reserve_price = dhtmlspecialchars($tbi->reserve_price);
            $zk_final_price = dhtmlspecialchars($tbi->zk_final_price);
        }
        
        if(!in_array($numiid,$numiids)){
            continue;
        }else{
            $spsetting = array('dateline'=>TIMESTAMP);
            $spsetting['numiid'] = $numiid;
            $spsetting['title'] = $title;
            $spsetting['url'] = $click_url;
            $spsetting['img'] = $pic_url;
            $spsetting['youhuiquan'] = '';//$click_url;
            $spsetting['yuanjia'] = $reserve_price;
            $spsetting['xianjia'] = $zk_final_price;
            $spsetting['tkl'] = "";
            $spsetting['categoryid'] = $spcategoryid;
            $spsetting['status'] = 1;
             
            if(C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->insert($spsetting,true)){
                $isok = true;
            }else{
                $isok = false;
            }
        }
                
    }
    
    if($isok){
        recache(false,$spcategoryid);
        cpmsg('jzsjiale_daogou:cxcaiji_success', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=taoqianggou&act=spfanye&starttime='.strtotime($dsp['starttime']).'&endtime='.strtotime($dsp['endtime']).'&page_no='.$dsp['page_no'].'&page_size='.$dsp['page_size'].'&page='.$currpage, 'succeed');
    }else{
        cpmsg('jzsjiale_daogou:cxcaiji_error', '', 'error');
    }
    
	dexit();
}






/////////caiji start

echo '<div class="colorbox"><h4>'.plang('abouttqg').'</h4>'.
                      '<table cellspacing="0" cellpadding="3"><tr>'.
                      '<td valign="top">'.plang('tqgdescription').'</td></tr></table>'.
                      '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
/////////caiji end
date_default_timezone_set('Asia/Shanghai');

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=taoqianggou&act=sousuo', 'enctype');
showtableheader(plang('tqgtitle'), '');

showsetting(plang('tqgstarttime'),'setting[starttime]',date("Y-m-d H:i",time()),'calendar','',0,plang('tqgstarttime_msg'),1,'tqgstarttime');
showsetting(plang('tqgendtime'),'setting[endtime]',date("Y-m-d H:i",strtotime("+1 day")),'calendar','',0,plang('tqgendtime_msg'),1,'tqgendtime');

$page_noselect ='';
$page_noselect .= '<option value="1" selected>'.plang('tqgpage_no_gong').'1'.plang('tqgpage_no_ye').'</option>';
for($ino = 2;$ino<=100;$ino++){
    $page_noselect .= '<option value="'.$ino.'">'.plang('tqgpage_no_gong').$ino.plang('tqgpage_no_ye').'</option>';
}
showsetting(plang('tqgpage_no'),'setting[page_no]','','<select name="setting[page_no]">'.$page_noselect.'</select>','',0,plang('tqgpage_no_msg'),1,'tqgpage_no');


showsetting(plang('tqgpage_size'),'setting[page_size]','40','text','','',plang('tqgpage_size_msg'));

showsubmit('submit', plang('tqgsousuosubmit'));
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/



function setSpList($dsp) {
   
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $tbappkey = $_config['g_appkey'];
        $tbsecretKey = $_config['g_appsecret'];
        $webbianma = $_G['charset'];
        $pid = $_config['g_pid'];
        
        if(empty($pid)){
            cpmsg('jzsjiale_daogou:pidnull', '', 'error');
            dexit();
        }
       
        $dzoneId = explode("_",$pid);
        $dzoneId = $dzoneId[3];
         
        if(empty($dzoneId)){
            cpmsg('jzsjiale_daogou:pidnull', '', 'error');
            dexit();
        }
        
        
        $gtkl = new GetTbAPI;
        $gtkl->__construct($tbappkey, $tbsecretKey);
        $tbinfo =  $gtkl->gettaoqianggouitem($dsp,$dzoneId,$webbianma);
      
        $tbinfo = json_decode($tbinfo);

        $splistinfo = $tbinfo->results->results;
        
        
        //----sp list
        echo '<div class="colorbox"><h4>'.plang('abouttqg').'</h4>'.
                      '<table cellspacing="0" cellpadding="3"><tr>'.
                      '<td valign="top">'.plang('tqgdescription').'</td></tr></table>'.
                      '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';
        
        showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=taoqianggou&act=caiji&starttime='.strtotime($dsp['starttime']).'&endtime='.strtotime($dsp['endtime']).'&page_no='.$dsp['page_no'].'&page_size='.$dsp['page_size'].'&currpage='.$dsp['currpage'], 'enctype');
        
        showtableheader(plang('tqgcxsplist'), '');
        showsubtitle(plang('tqgcxsptitle'));
        
        foreach($splistinfo as $spi){
       
	        if($webbianma == 'gbk') {
	            $cx_num_iid = diconv($spi->num_iid,'UTF-8','GB2312');
	            $cx_title = diconv($spi->title,'UTF-8','GB2312');
	            $cx_pic_url = diconv($spi->pic_url,'UTF-8','GB2312');
	            $cx_reserve_price = diconv($spi->reserve_price,'UTF-8','GB2312');
	            $cx_zk_final_price = diconv($spi->zk_final_price,'UTF-8','GB2312');
	            $cx_start_time = diconv($spi->start_time,'UTF-8','GB2312');
	            $cx_end_time = diconv($spi->end_time,'UTF-8','GB2312');
	            $cx_click_url = diconv($spi->click_url,'UTF-8','GB2312');
	            $cx_category_name = diconv($spi->category_name,'UTF-8','GB2312');
	            $cx_total_amount = diconv($spi->total_amount,'UTF-8','GB2312');
	            $cx_sold_num = diconv($spi->sold_num,'UTF-8','GB2312');
	        }else{
	            $cx_num_iid = $spi->num_iid;
	            $cx_title = $spi->title;
	            $cx_pic_url = $spi->pic_url;
	            $cx_reserve_price = $spi->reserve_price;
	            $cx_zk_final_price = $spi->zk_final_price;
	            $cx_start_time = $spi->start_time;
	            $cx_end_time = $spi->end_time;
	            $cx_click_url = $spi->click_url;
	            $cx_category_name = $spi->category_name;
	            $cx_total_amount = $spi->total_amount;
	            $cx_sold_num = $spi->sold_num;
	        }
	        
	        
	        showtablerow('', array('width="50"'), array(
	        '<input class="checkbox" type="checkbox" name="numiids[]" value="'.$cx_num_iid.'" title="'.$cx_num_iid.'" width="80">'.$cx_num_iid,
	        '<a href="'.$cx_click_url.'" target="_blank"><span title="'.$cx_title.'">'.mb_substr($cx_title,0,40).'</span></a>',
	        '<a href="'.$cx_click_url.'" target="_blank"><img src="' . $cx_pic_url . '" width="80px" /></a>',
	        '<span title="'.$cx_reserve_price.'">'.mb_substr($cx_reserve_price,0,40).'</span>',
	        '<span title="'.$cx_zk_final_price.'">'.mb_substr($cx_zk_final_price,0,40).'</span>',
	        '<span title="'.$cx_start_time.'">'.getSpanColor($cx_start_time,'red').'</span>',
	        '<span title="'.$cx_end_time.'">'.getSpanColor($cx_end_time,'green').'</span>',
	        '<a href="'.$cx_click_url.'" target="_blank">' . mb_substr($cx_click_url,0,40) .'...</a>',
	        '<span title="'.$cx_category_name.'">'.mb_substr($cx_category_name,0,40).'</span>',
	        '<span title="'.$cx_total_amount.'">'.$cx_total_amount.'</span>',
	        '<span title="'.$cx_sold_num.'">'.$cx_sold_num.'</span>')
	        );
	        
	    }

	    
	    $count = $dsp['page_size'] * $dsp['page_no'];
	    $mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=taoqianggou&act=spfanye&starttime='.strtotime($dsp['starttime']).'&endtime='.strtotime($dsp['endtime']).'&page_no='.$dsp['page_no'].'&page_size='.$dsp['page_size'];
	    $multipage = multi($count, $dsp['page_size'], $pageno, $mpurl);
	    //showsubmit('', '', '', '', $multipage);
	    
	    
	    showsubmit('', '', '','<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'numiids\')" /><label for="chkall">'.cplang('select_all').'</label>&nbsp;&nbsp<span style="color:red;">'.plang('cxfenleitip').'</span>&nbsp;&nbsp'.getcategoryselect().'&nbsp;&nbsp<input type="submit" class="btn" name="batchbutton" value="'.cplang('submit').'" />', plang('allcount').(!empty($multipage)?$multipage:$count));
	    
	    
	    showtablefooter(); /*Dism��taobao��com*/
	    showformfooter(); /*Dism_taobao_com*/
	 
	    dexit();
}



function recache($isallcategory = true,$categoryid = 0){
    /*
    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();

    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
    */
    //20190329 add
    if($isallcategory){
        $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

        foreach ($category as $key => $value){

            $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1,$value["id"]);

            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));
        }
    }else{
        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $categoryid);

        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_shangpin_'.$categoryid, getcachevars(array('tbkshangpin_'.$categoryid => $shangpin_cache_tmp)));
    }

}

function getcategoryselect() {
         $categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid(0,1);
         $categoryidselect = '<option value="0">------'.plang('qingxuanze').'------</option>';
         $categoryidselect .= '<option value="0">------'.plang('bufenlei').'------</option>';
         foreach($categoryids as $k =>$v){
               $categoryidselect .= '<option value="'.$v['id'].'" >'.$v['title'].'</option>';
               $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($v['id'],1);
                 foreach($subcategoryids as $subk =>$subv){
                      $categoryidselect .= '<option value="'.$subv['id'].'" >&nbsp;&nbsp;&nbsp;&nbsp;'.$subv['title'].'</option>';
                      
                      $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($subv['id'],1);
                      foreach($sub3categoryids as $sub3k =>$sub3v){
                          $categoryidselect .= '<option value="'.$sub3v['id'].'" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sub3v['title'].'</option>';
                      }
                 }
         }
         $categoryselect = '<select name="spcategoryid" id="spcategoryid">'.$categoryidselect.'</select>';

         return $categoryselect;
}

function getSpanColor($str,$color) {
    return "<span style='color:".$color.";'>".$str."</span>";
}

function plang($str) {
	return lang('plugin/jzsjiale_daogou', $str);
}
//From: Dism��taobao��com
?>