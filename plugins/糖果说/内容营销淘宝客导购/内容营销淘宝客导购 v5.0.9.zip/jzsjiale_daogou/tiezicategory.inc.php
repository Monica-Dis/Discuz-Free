<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
global $_G, $lang;

if(!in_array($act, array('list', 'cache', 'qingchu'))) {
    $act = 'list';
}

if($act=='qingchu'){
	$tiezicategoryid = dintval($_GET['tiezicategoryid']);
	$setting = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->fetch($tiezicategoryid);
	if(empty($setting))
		cpmsg('jzsjiale_daogou:empty', '', 'error');
	if(submitcheck('submit')){
		C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->deletebytiezicategoryid($tiezicategoryid);
		recache();
		recachetiezi();
		cpmsg('jzsjiale_daogou:delok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory', 'succeed');
	}
	cpmsg('jzsjiale_daogou:deltiezicategorydata','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory&act=qingchu&tiezicategoryid='.$tiezicategoryid.'&submit=yes','form',array('title' => $setting['title']));
}elseif($act=='cache'){
    
            $tbktiezicategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->getall();
    
            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_tiezicategory', getcachevars(array('tbktiezicategory' => $tbktiezicategory)));
            
            if(count($tbktiezicategory) > 0){
                cpmsg('jzsjiale_daogou:cache_success', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory', 'succeed');
            }else{
                cpmsg('jzsjiale_daogou:cache_error', '', 'error');
            }
            
        
        dexit();
}elseif($act=='list'){
	if(submitcheck('submit')){
	    
	    $newforum = $_GET['newforum'];
	    $neworder = $_GET['neworder'];
	    $neworderlevel = $_GET['neworderlevel'];
	    if(is_array($newforum)) {
	        foreach($newforum as $fup => $forums) {
	            	
	            $forum = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->fetch($fup);
	            foreach($forums as $key => $forumname) {
	    
	                if(empty($forumname)) {
	                    continue;
	                }
	                $forumfields = array();
	                $forumfields['title'] = $forumname;
	                $forumfields['pid'] = $forum['id'];
	                $forumfields['keywords'] = '';
	                $forumfields['description'] = '';
	                $forumfields['status'] = 1;
	                $forumfields['sort'] = $neworder[$fup][$key];
	                $forumfields['level'] = $neworderlevel[$fup][$key];
	                $forumfields['dateline'] = TIMESTAMP;
	                C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->insert($forumfields);
	                	
	            }
	        }
	    }
	    
	   if(is_array($_GET['groupnamenewadd'])) {
			foreach($_GET['groupnamenewadd'] as $k => $v) {
				if($v) {
					$setarr = array(
						'title' => $v,
						'sort' => $_GET['groupordernewadd'][$k],
					    'level' => $_GET['groupordernewaddlevel'][$k],
					    'status' => '1',
						'dateline' => TIMESTAMP
					);
					C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->insert($setarr);
				}
			}
		}
		
		
		if(is_array($_GET['group_title'])) {
		    foreach($_GET['group_title'] as $id => $title) {
		        if(!$_GET['delete'][$id]) {
		            $setarr = array(
		                'title' => $_GET['group_title'][$id],
		                'sort' => $_GET['group_order'][$id],
		                'img' => $_GET['group_img'][$id],
		                'color' => $_GET['group_color'][$id],
		                'status' => intval($_GET['group_status'][$id]),
		                'level' => $_GET['group_level'][$id],
		                'dateline' => TIMESTAMP
		            );
		            C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->update($id,$setarr);
		        }
		    }
		    	
		}
		
		if($_GET['delete']) {
		    C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->delete($_GET['delete']);
		    C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->delete3bytiezicategoryid(dimplode($_GET['delete']));
		    C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->deletebytiezicategoryid(dimplode($_GET['delete']));
		}
		
		    recache();
		    cpmsg('jzsjiale_daogou:ok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory&act=list', 'succeed');
		
	}else{
	    echo '<div class="colorbox"><h4>'.plang('abouttiezicategory').'</h4>'.
	        '<table cellspacing="0" cellpadding="3"><tr>'.
	        '<td valign="top">'.plang('tiezicategorydescription').'</td></tr></table>'.
	        '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';
	    
	    $wutuimg = "source/plugin/jzsjiale_daogou/static/images/tp.png";

	    ?>
	    <script type="text/JavaScript">
	    var rowtypedata = [
	                       [
	                           [1,''],
	                           [1,'<input type="text" class="txt" name="groupordernewadd[]" value="0"><input type="hidden" class="txt" name="groupordernewaddlevel[]" value="1">', 'td25'],
	                           [1,'<div><input type="text" class="txt" name="groupnamenewadd[]"><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php cplang('delete', null, true);?></a></div>', '']
	                       ],
	                       [
	                            [1,''],
	                            [1,'<input type="text" class="txt" name="neworder[{1}][]" value="0" /><input type="hidden" class="txt" name="neworderlevel[{1}][]" value="2">', 'td25'],
	                            [1, '<div class="board" ><input name="newforum[{1}][]" value="<?php echo plang("newsubcate");?>" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php cplang('delete', null, true);?></a></div>', '']
	                       ],
	                       [
	                            [1, ''],
	                            [1,'<input type="text" class="txt" name="neworder[{1}][]" value="0" /><input type="hidden" class="txt" name="neworderlevel[{1}][]" value="3">', 'td25'], 
	                            [5, '<div class="childboard"><input name="newforum[{1}][]" value="<?php cplang('forums_admin_add_forum_name', null, true);?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php cplang('delete', null, true);?></a></div>']
	                       ],
	                 ];
	    </script>
	    <?php
	    
	    
		//showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory&act=list', 'enctype');



		showtableheader(plang('letiezicategory').'(  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory&act=cache" style="color:red;">'.plang('cachetiezicategory').'</a>  )', 'nobottom');
		showsubtitle(plang('letiezicategorytitle'));
		showtablefooter(); /*Dism��taobao��com*/
		
		//----xinzeng dingji  start
		
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory&act=list', 'enctype');
		showtableheader('<span style="color:red;">'.plang('tiezizengjiadingjifenlei').'</span>', 'nobottom');
		
		echo '<tr><td>&nbsp;</td><td colspan="5"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.plang('addcate').'</a></div></td></tr>';
		showsubmit('submit', 'submit', 'td', '<span style="color:red;">('.plang('tiezizengjiadingjifenlei').')</span>');
		showtablefooter(); /*Dism��taobao��com*/
		showformfooter(); /*Dism_taobao_com*/
		
		//----xinzeng dingji  end
		
		
		echo '
<script type="text/javascript">
	function categoryagrouphide(categroupid) {
         document.getElementById("categorya_group_show_"+categroupid).style.display="";
         document.getElementById("categorya_group_hide_"+categroupid).style.display="none";
         var controls = document.getElementsByName("category_"+categroupid+"_group");
		
         for(var i=0;i<controls.length;i++)
         {
            controls[i].style.display="none";
         }
	}
    function categoryagroupshow(categroupid) {
         document.getElementById("categorya_group_show_"+categroupid).style.display="none";
         document.getElementById("categorya_group_hide_"+categroupid).style.display="";
         var controls = document.getElementsByName("category_"+categroupid+"_group");
		
         for(var i=0;i<controls.length;i++)
         {
            controls[i].style.display="";
         }
	}
</script>';
		
		
		$tiezicategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid(0);
		foreach($tiezicategory as $group) {
		    //NEW
		    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory&act=list', 'enctype');
		    showtableheader('<a href="javascript:;" id="categorya_group_show_'.$group['id'].'" onclick="categoryagroupshow('.$group['id'].')">'.plang('zhankai').'</a><a href="javascript:;" id="categorya_group_hide_'.$group['id'].'" style="display:none;" onclick="categoryagrouphide('.$group['id'].')">'.plang('shouqi').'</a>&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:red;">'.$group[title].'</span>&nbsp;--&nbsp;'.plang('letiezicategoryzi'), 'nobottom');
		    
		    $tiezicount = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->count_by_tiezicategoryid($group['id']);
			$statusstr = $group[status]==1 ? ' checked="checked"':'';
			showtablerow('name="category_'.$group['id'].'_group" style="display:none;"', array('', 'class="td25"', '', 'class="td25" style="width:150px;"'), array(
						"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[$group[id]]\" value=\"$group[id]\">$group[id]<input type=\"hidden\"  name=\"group_level[$group[id]]\" value=\"$group[level]\">",
						"<input type=\"text\" class=\"txt\" name=\"group_order[$group[id]]\" value=\"$group[sort]\">",					
						"<input type=\"text\" class=\"txt\" name=\"group_title[$group[id]]\" value=\"$group[title]\">",
						"<img src=\"".($group[img]?$group[img]:$wutuimg)."\" id=\"img".$group[id]."\" width=\"40px\" height=\"40px\" align=\"absmiddle\" style=\"margin-right:3px;float:left\"/><input class=\"txt\" type=\"text\" id=\"url".$group['id']."\" name=\"group_img[".$group['id']."]\" readonly=\"readonly\" value=\"".$group[img]."\"  style=\"margin-right:3px;float:left;vertical-align:middle;\"/> <input type=\"button\" id=\"image".$group['id']."\" value=\"".plang('uploadimage')."\" style=\"margin-right:3px;float:left;vertical-align:middle;\"/>",
			            "<input id=\"c2".$group['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"group_color[$group[id]]\" value=\"$group[color]\" onchange=\"updatecolorpreview('c2".$group['id']."')\"/><input id=\"c2".$group['id']."\" onclick=\"c2".$group['id']."_frame.location='static/image/admincp/getcolor.htm?c2".$group['id']."|c2".$group['id']."_v';showMenu({'ctrlid':'c2".$group['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:$group[color]\"><span id=\"c2".$group['id']."_menu\" style=\"display: none\"><iframe name=\"c2".$group['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
						"<input type=\"checkbox\"  size=\"12\" name=\"group_status[$group[id]]\" value=\"1\" $statusstr>",
						$tiezicount,
						dgmdate($group['dateline']),
						'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&tiezicategoryid='.$group['id'].'">'.plang('viewtiezi').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory&act=qingchu&tiezicategoryid='.$group['id'].'">'.plang('qingchutiezi').'</a>'
					));
			
			$editorjs ='K(\'#image'.$group['id'].'\').click(function() {
					editor'.$group['id'].'.loadPlugin(\'image\', function() {
						editor'.$group['id'].'.plugin.imageDialog({
							imageUrl : K(\'#url'.$group['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$group['id'].'\').val(url);
								K(\'#img'.$group['id'].'\').attr(\'src\',url);
								editor'.$group['id'].'.hideDialog();
							}
						});
					});
				});';
			
			echo '
<link rel="stylesheet" href="source/plugin/jzsjiale_daogou/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/jzsjiale_daogou/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/jzsjiale_daogou/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor'.$group['id'].' = K.editor({
					uploadJson : \'source/plugin/jzsjiale_daogou/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/jzsjiale_daogou/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';
		   $subtiezicategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($group[id]);
		   foreach($subtiezicategory as $subgroup) {
		   
		       $subtiezicount = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->count_by_tiezicategoryid($subgroup['id']);
			   $substatusstr = $subgroup[status]==1 ? ' checked="checked"':'';		   
			   showtablerow('name="category_'.$group['id'].'_group" style="display:none;"', array('', 'class="td25"', '', 'class="td25"'), array(
							"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[$subgroup[id]]\" value=\"$subgroup[id]\">$subgroup[id]<input type=\"hidden\" name=\"group_level[$subgroup[id]]\" value=\"$subgroup[level]\">",
							"<input type=\"text\" class=\"txt\" name=\"group_order[$subgroup[id]]\" value=\"$subgroup[sort]\">",					
							"<div class=\"board\"><input type=\"text\" class=\"txt\"  name=\"group_title[$subgroup[id]]\" value=\"$subgroup[title]\"><a href=\"###\" onclick=\"addrowdirect = 1;addrow(this, 2, '$subgroup[id]')\" class=\"addchildboard\">".plang('addsubcate')."</a></div>",
							"<img src=\"".($subgroup[img]?$subgroup[img]:$wutuimg)."\" id=\"img".$subgroup[id]."\" width=\"40px\" height=\"40px\" align=\"absmiddle\" style=\"margin-right:3px;float:left\"/><input class=\"txt\" type=\"text\" id=\"url".$subgroup['id']."\" name=\"group_img[".$subgroup['id']."]\" readonly=\"readonly\" value=\"".$subgroup[img]."\"  style=\"margin-right:3px;float:left;vertical-align:middle;\"/> <input type=\"button\" id=\"image".$subgroup['id']."\" value=\"".plang('uploadimage')."\" style=\"margin-right:3px;float:left;vertical-align:middle;\"/>",
			               "<input id=\"c2".$subgroup['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"group_color[$subgroup[id]]\" value=\"$subgroup[color]\" onchange=\"updatecolorpreview('c2".$subgroup['id']."')\"/><input id=\"c2".$subgroup['id']."\" onclick=\"c2".$subgroup['id']."_frame.location='static/image/admincp/getcolor.htm?c2".$subgroup['id']."|c2".$subgroup['id']."_v';showMenu({'ctrlid':'c2".$subgroup['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:$subgroup[color]\"><span id=\"c2".$subgroup['id']."_menu\" style=\"display: none\"><iframe name=\"c2".$subgroup['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
						   "<input type=\"checkbox\"  size=\"12\" name=\"group_status[$subgroup[id]]\" value=\"1\" $substatusstr>",
						    $subtiezicount,
			                dgmdate($subgroup['dateline']),
							'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&tiezicategoryid='.$subgroup['id'].'">'.plang('viewtiezi').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory&act=qingchu&tiezicategoryid='.$subgroup['id'].'">'.plang('qingchutiezi').'</a>'
						));  
						 
			   $subeditorjs ='K(\'#image'.$subgroup['id'].'\').click(function() {
					subeditor'.$subgroup['id'].'.loadPlugin(\'image\', function() {
						subeditor'.$subgroup['id'].'.plugin.imageDialog({
							imageUrl : K(\'#url'.$subgroup['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$subgroup['id'].'\').val(url);
								K(\'#img'.$subgroup['id'].'\').attr(\'src\',url);
								subeditor'.$subgroup['id'].'.hideDialog();
							}
						});
					});
				});';
			   	
			   echo '
<link rel="stylesheet" href="source/plugin/jzsjiale_daogou/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/jzsjiale_daogou/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/jzsjiale_daogou/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var subeditor'.$subgroup['id'].' = K.editor({
					uploadJson : \'source/plugin/jzsjiale_daogou/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/jzsjiale_daogou/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$subeditorjs.'
			});
</script>';
			   
			   
			   
			   $sub3tiezicategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($subgroup[id]);
			   foreach($sub3tiezicategory as $sub3group) {
			        
			       $sub3tiezicount = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->count_by_tiezicategoryid($sub3group['id']);
			       $sub3statusstr = $sub3group[status]==1 ? ' checked="checked"':'';
			       showtablerow('name="category_'.$group['id'].'_group" style="display:none;"', array('', 'class="td25"', '', 'class="td25"'), array(
			           "<input class=\"checkbox\" type=\"checkbox\" name=\"delete[$sub3group[id]]\" value=\"$sub3group[id]\">$sub3group[id]<input type=\"hidden\" name=\"group_level[$sub3group[id]]\" value=\"$sub3group[level]\">",
			           "<input type=\"text\" class=\"txt\" name=\"group_order[$sub3group[id]]\" value=\"$sub3group[sort]\">",
			           "<div class=\"childboard\"><input type=\"text\" class=\"txt\"  name=\"group_title[$sub3group[id]]\" value=\"$sub3group[title]\"></div>",
			           "<img src=\"".($sub3group[img]?$sub3group[img]:$wutuimg)."\" id=\"img".$sub3group[id]."\" width=\"40px\" height=\"40px\" align=\"absmiddle\" style=\"margin-right:3px;float:left\"/><input class=\"txt\" type=\"text\" id=\"url".$sub3group['id']."\" name=\"group_img[".$sub3group['id']."]\" readonly=\"readonly\" value=\"".$sub3group[img]."\"  style=\"margin-right:3px;float:left;vertical-align:middle;\"/> <input type=\"button\" id=\"image".$sub3group['id']."\" value=\"".plang('uploadimage')."\" style=\"margin-right:3px;float:left;vertical-align:middle;\"/>",
			           "<input id=\"c2".$sub3group['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"group_color[$sub3group[id]]\" value=\"$sub3group[color]\" onchange=\"updatecolorpreview('c2".$sub3group['id']."')\"/><input id=\"c2".$sub3group['id']."\" onclick=\"c2".$sub3group['id']."_frame.location='static/image/admincp/getcolor.htm?c2".$sub3group['id']."|c2".$sub3group['id']."_v';showMenu({'ctrlid':'c2".$sub3group['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:$sub3group[color]\"><span id=\"c2".$sub3group['id']."_menu\" style=\"display: none\"><iframe name=\"c2".$sub3group['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			           "<input type=\"checkbox\"  size=\"12\" name=\"group_status[$sub3group[id]]\" value=\"1\" $sub3statusstr>",
			           $sub3tiezicount,
			           dgmdate($sub3group['dateline']),
			           '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&tiezicategoryid='.$sub3group['id'].'">'.plang('viewtiezi').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory&act=qingchu&tiezicategoryid='.$sub3group['id'].'">'.plang('qingchutiezi').'</a>'
				   )); 
			   
			       $sub3editorjs ='K(\'#image'.$sub3group['id'].'\').click(function() {
					sub3editor'.$sub3group['id'].'.loadPlugin(\'image\', function() {
						sub3editor'.$sub3group['id'].'.plugin.imageDialog({
							imageUrl : K(\'#url'.$sub3group['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$sub3group['id'].'\').val(url);
								K(\'#img'.$sub3group['id'].'\').attr(\'src\',url);
								sub3editor'.$sub3group['id'].'.hideDialog();
							}
						});
					});
				});';
			        
			       echo '
<link rel="stylesheet" href="source/plugin/jzsjiale_daogou/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/jzsjiale_daogou/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/jzsjiale_daogou/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var sub3editor'.$sub3group['id'].' = K.editor({
					uploadJson : \'source/plugin/jzsjiale_daogou/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/jzsjiale_daogou/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$sub3editorjs.'
			});
</script>';
			   
			   
			   }
		   }
		   echo '<tr><td>&nbsp;</td><td>&nbsp;</td><td><div><a href="###" onclick="addrow(this, 1, '.$group['id'].')" class="addtr">'.plang('addsubcate').'</a></div></td></tr>';
		
		
		   echo '<tr><td>&nbsp;</td><td colspan="5"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.plang('addcate').'</a></div></td></tr>';		
		   showsubmit('submit', 'submit', 'del', '<span style="color:red;">'.plang('tiezijinbaocunquyu1').'</span>&nbsp;&nbsp;<span style="color:blue;">'.$group[title].'</span>&nbsp;&nbsp;<span style="color:red;">'.plang('tiezijinbaocunquyu2').'</span>');
		   showtablefooter(); /*Dism��taobao��com*/
		   showformfooter(); /*Dism_taobao_com*/
		}
		/*
		echo '<tr><td>&nbsp;</td><td colspan="5"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.plang('addcate').'</a></div></td></tr>';		
		showsubmit('submit', 'submit', 'del', '');
		showtablefooter(); /*Dism��taobao��com*/
		showformfooter(); /*Dism_taobao_com*/	
		*/

		//----xinzeng dingji  start
		
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezicategory&act=list', 'enctype');
		showtableheader('<span style="color:red;">'.plang('tiezizengjiadingjifenlei').'</span>', 'nobottom');
		
		echo '<tr><td>&nbsp;</td><td colspan="5"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.plang('addcate').'</a></div></td></tr>';		
		showsubmit('submit', 'submit', 'td', '<span style="color:red;">('.plang('tiezizengjiadingjifenlei').')</span>');
		showtablefooter(); /*Dism��taobao��com*/
		showformfooter(); /*Dism_taobao_com*/
		
		//----xinzeng dingji  end
	}
	

}


function plang($str) {
	return lang('plugin/jzsjiale_daogou', $str);
}

function recache() {
    $tbktiezicategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->getall();
    
    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_tiezicategory', getcachevars(array('tbktiezicategory' => $tbktiezicategory)));

}

function recachetiezi() {
    $daogoutiezi = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->getall();

    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_tiezi', getcachevars(array('daogoutiezi' => $daogoutiezi)));

}
//From: Dism��taobao��com
?>