<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
global $_G, $lang;

loadcache('plugin');



require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';
require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';

$utils = new Utils();

if($act=='sousuo'){
	
    if(submitcheck('submit')){
    
        $setting = $_GET['setting'];
        $dsp = array();
        $dsp['q'] = daddslashes(trim($setting['q']));
        $dsp['itemloc'] = daddslashes(trim($setting['itemloc']));
        $dsp['sort'] = daddslashes(trim($setting['sort']));
        $dsp['has_coupon'] = daddslashes(trim($setting['has_coupon']));
        $dsp['is_tmall'] = daddslashes(trim($setting['is_tmall']));
        $dsp['is_overseas'] = daddslashes(trim($setting['is_overseas']));
        $dsp['need_free_shipment'] = daddslashes(trim($setting['need_free_shipment']));
        $dsp['need_prepay'] = daddslashes(trim($setting['need_prepay']));
        $dsp['start_price'] = daddslashes(trim($setting['start_price']));
        $dsp['end_price'] = daddslashes(trim($setting['end_price']));
        $dsp['start_tk_rate'] = daddslashes(trim($setting['start_tk_rate']));
        $dsp['end_tk_rate'] = daddslashes(trim($setting['end_tk_rate']));
        $dsp['page_no'] = daddslashes(trim($setting['page_no']));
        $dsp['page_size'] = daddslashes(trim($setting['page_size']));
        $dsp['start_dsr'] = daddslashes(trim($setting['start_dsr']));
        $dsp['include_pay_rate_30'] = daddslashes(trim($setting['include_pay_rate_30']));
        $dsp['include_good_rate'] = daddslashes(trim($setting['include_good_rate']));
        $dsp['include_rfd_rate'] = daddslashes(trim($setting['include_rfd_rate']));
        $dsp['currpage'] = '1';


        if(empty($dsp['q'])){
            cpmsg('jzsjiale_daogou:cjssq_null', '', 'error');
        }

        if(!empty($dsp['start_price']) && !is_numeric($dsp['start_price'])){
            cpmsg('jzsjiale_daogou:cjssstart_price_notnumeric', '', 'error');
        }
        if(!empty($dsp['end_price']) && !is_numeric($dsp['end_price'])){
            cpmsg('jzsjiale_daogou:cjssend_price_notnumeric', '', 'error');
        }
        if(!empty($dsp['start_tk_rate']) && !is_numeric($dsp['start_tk_rate'])){
            cpmsg('jzsjiale_daogou:cjssstart_tk_rate_notnumeric', '', 'error');
        }
        if(!empty($dsp['end_tk_rate']) && !is_numeric($dsp['end_tk_rate'])){
            cpmsg('jzsjiale_daogou:cjssend_tk_rate_notnumeric', '', 'error');
        }
        if(!empty($dsp['page_no']) && !is_numeric($dsp['page_no'])){
            cpmsg('jzsjiale_daogou:cjsspage_no_notnumeric', '', 'error');
        }
        if(!empty($dsp['page_size']) && !is_numeric($dsp['page_size'])){
            cpmsg('jzsjiale_daogou:cjsspage_size_notnumeric', '', 'error');
        }
    
        setSpList($dsp);
        dexit();
    }
  
}elseif($act=='spfanye'){
    
    $page = intval($_GET['page']);
    $page = $page > 0 ? $page : 1;
    
    $dsp = array();
    $dsp['q'] = daddslashes(trim($_GET['q']));
    $dsp['itemloc'] = daddslashes(trim($_GET['itemloc']));
    $dsp['sort'] = daddslashes(trim($_GET['sort']));
    $dsp['has_coupon'] = daddslashes(trim($_GET['has_coupon']));
    $dsp['is_tmall'] = daddslashes(trim($_GET['is_tmall']));
    $dsp['is_overseas'] = daddslashes(trim($_GET['is_overseas']));
    $dsp['need_free_shipment'] = daddslashes(trim($_GET['need_free_shipment']));
    $dsp['need_prepay'] = daddslashes(trim($_GET['need_prepay']));
    $dsp['start_price'] = daddslashes(trim($_GET['start_price']));
    $dsp['end_price'] = daddslashes(trim($_GET['end_price']));
    $dsp['start_tk_rate'] = daddslashes(trim($_GET['start_tk_rate']));
    $dsp['end_tk_rate'] = daddslashes(trim($_GET['end_tk_rate']));
    $dsp['page_no'] = daddslashes(trim($_GET['page_no']));
    $dsp['page_size'] = daddslashes(trim($_GET['page_size']));
    $dsp['start_dsr'] = daddslashes(trim($_GET['start_dsr']));
    $dsp['include_pay_rate_30'] = daddslashes(trim($_GET['include_pay_rate_30']));
    $dsp['include_good_rate'] = daddslashes(trim($_GET['include_good_rate']));
    $dsp['include_rfd_rate'] = daddslashes(trim($_GET['include_rfd_rate']));
    $dsp['currpage'] = $page;


    if(empty($dsp['q'])){
        cpmsg('jzsjiale_daogou:cjssq_null', '', 'error');
    }

    if(!empty($dsp['start_price']) && !is_numeric($dsp['start_price'])){
        cpmsg('jzsjiale_daogou:cjssstart_price_notnumeric', '', 'error');
    }
    if(!empty($dsp['end_price']) && !is_numeric($dsp['end_price'])){
        cpmsg('jzsjiale_daogou:cjssend_price_notnumeric', '', 'error');
    }
    if(!empty($dsp['start_tk_rate']) && !is_numeric($dsp['start_tk_rate'])){
        cpmsg('jzsjiale_daogou:cjssstart_tk_rate_notnumeric', '', 'error');
    }
    if(!empty($dsp['end_tk_rate']) && !is_numeric($dsp['end_tk_rate'])){
        cpmsg('jzsjiale_daogou:cjssend_tk_rate_notnumeric', '', 'error');
    }
    if(!empty($dsp['page_no']) && !is_numeric($dsp['page_no'])){
        cpmsg('jzsjiale_daogou:cjsspage_no_notnumeric', '', 'error');
    }
    if(!empty($dsp['page_size']) && !is_numeric($dsp['page_size'])){
        cpmsg('jzsjiale_daogou:cjsspage_size_notnumeric', '', 'error');
    }
    
    setSpList($dsp);
    
    dexit();
}elseif($act=='caiji'){

    $currpage = intval($_GET['currpage']);
    $currpage = $currpage > 0 ? $currpage : 1;

    $dsp = array();
    $dsp['q'] = daddslashes(trim($_GET['q']));
    $dsp['itemloc'] = daddslashes(trim($_GET['itemloc']));
    $dsp['sort'] = daddslashes(trim($_GET['sort']));
    $dsp['has_coupon'] = daddslashes(trim($_GET['has_coupon']));
    $dsp['is_tmall'] = daddslashes(trim($_GET['is_tmall']));
    $dsp['is_overseas'] = daddslashes(trim($_GET['is_overseas']));
    $dsp['need_free_shipment'] = daddslashes(trim($_GET['need_free_shipment']));
    $dsp['need_prepay'] = daddslashes(trim($_GET['need_prepay']));
    $dsp['start_price'] = daddslashes(trim($_GET['start_price']));
    $dsp['end_price'] = daddslashes(trim($_GET['end_price']));
    $dsp['start_tk_rate'] = daddslashes(trim($_GET['start_tk_rate']));
    $dsp['end_tk_rate'] = daddslashes(trim($_GET['end_tk_rate']));
    $dsp['page_no'] = daddslashes(trim($_GET['page_no']));
    $dsp['page_size'] = daddslashes(trim($_GET['page_size']));
    $dsp['start_dsr'] = daddslashes(trim($_GET['start_dsr']));
    $dsp['include_pay_rate_30'] = daddslashes(trim($_GET['include_pay_rate_30']));
    $dsp['include_good_rate'] = daddslashes(trim($_GET['include_good_rate']));
    $dsp['include_rfd_rate'] = daddslashes(trim($_GET['include_rfd_rate']));
    $dsp['currpage'] = $currpage;

    $spcategoryid = $_POST['spcategoryid'];
    $numiids = $_POST['numiids'];
    $numiidsstr = "";

    if (! empty($dsp['page_no']) && ! is_numeric($dsp['page_no'])) {
        cpmsg('jzsjiale_daogou:youhuiquan_shuju_error', '', 'error');
    }
    if (! empty($dsp['page_size']) && ! is_numeric($dsp['page_size'])) {
        cpmsg('jzsjiale_daogou:youhuiquan_shuju_error', '', 'error');
    }

    if(empty($spcategoryid)){
        $spcategoryid=0;
    }
    if(empty($numiids)){
        cpmsg('jzsjiale_daogou:cxcaiji_notxuanze', '', 'error');
    }

    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    $tbappkey = $_config['g_appkey'];
    $tbsecretKey = $_config['g_appsecret'];
    $webbianma = $_G['charset'];
    $pid = $_config['g_pid'];

    $tbinfo = "";
    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_cjssshangpin.php')){
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_cjssshangpin.php';

        $tbinfo = $cjssshangpin;

    }else{
        cpmsg('jzsjiale_daogou:cxcaiji_error', '', 'error');
        dexit();
    }

    $tbinfo = json_decode($tbinfo);

    $splistinfo = $tbinfo->result_list->map_data;
    
    $isok = false;
    
    foreach($splistinfo as $tbi){

        $sp_url = "";
        if(!empty($tbi->url)){
            $sp_url = $tbi->url;
        }else{
            $sp_url = $tbi->item_url;
        }

        if($webbianma == "gbk"){
            $item_id = diconv(dhtmlspecialchars($tbi->item_id),'UTF-8','GBK');
            $title = diconv(dhtmlspecialchars($tbi->title),'UTF-8','GBK');
            $pict_url = diconv(dhtmlspecialchars($tbi->pict_url),'UTF-8','GBK');
            $coupon_share_url = diconv(dhtmlspecialchars($tbi->coupon_share_url),'UTF-8','GBK');
            $url = diconv(dhtmlspecialchars($sp_url),'UTF-8','GBK');
            $reserve_price = diconv(dhtmlspecialchars($tbi->reserve_price),'UTF-8','GBK');
            $zk_final_price = diconv(dhtmlspecialchars($tbi->zk_final_price),'UTF-8','GBK');
            $coupon_start_fee = diconv(dhtmlspecialchars($tbi->coupon_start_fee),'UTF-8','GBK');
            $coupon_amount = diconv(dhtmlspecialchars($tbi->coupon_amount),'UTF-8','GBK');
            $coupon_info = diconv(dhtmlspecialchars($tbi->coupon_info),'UTF-8','GBK');
            $coupon_start_time = diconv(dhtmlspecialchars($tbi->coupon_start_time),'UTF-8','GBK');
            $coupon_end_time = diconv(dhtmlspecialchars($tbi->coupon_end_time),'UTF-8','GBK');
            $coupon_total_count = diconv(dhtmlspecialchars($tbi->coupon_total_count),'UTF-8','GBK');
            $coupon_remain_count = diconv(dhtmlspecialchars($tbi->coupon_remain_count),'UTF-8','GBK');
            $coupon_id = diconv(dhtmlspecialchars($tbi->coupon_id),'UTF-8','GBK');
            $user_type = diconv(dhtmlspecialchars($tbi->user_type),'UTF-8','GBK');
            $real_post_fee = diconv(dhtmlspecialchars($tbi->real_post_fee),'UTF-8','GBK');
        }else{
            $item_id = dhtmlspecialchars($tbi->item_id);
            $title = dhtmlspecialchars($tbi->title);
            $pict_url = dhtmlspecialchars($tbi->pict_url);
            $coupon_share_url = dhtmlspecialchars($tbi->coupon_share_url);
            $url = dhtmlspecialchars($sp_url);
            $reserve_price = dhtmlspecialchars($tbi->reserve_price);
            $zk_final_price = dhtmlspecialchars($tbi->zk_final_price);
            $coupon_start_fee = dhtmlspecialchars($tbi->coupon_start_fee);
            $coupon_amount = dhtmlspecialchars($tbi->coupon_amount);
            $coupon_info = dhtmlspecialchars($tbi->coupon_info);
            $coupon_start_time = dhtmlspecialchars($tbi->coupon_start_time);
            $coupon_end_time = dhtmlspecialchars($tbi->coupon_end_time);
            $coupon_total_count = dhtmlspecialchars($tbi->coupon_total_count);
            $coupon_remain_count = dhtmlspecialchars($tbi->coupon_remain_count);
            $coupon_id = dhtmlspecialchars($tbi->coupon_id);
            $user_type = dhtmlspecialchars($tbi->user_type);
            $real_post_fee = dhtmlspecialchars($tbi->real_post_fee);
        }

        if(!in_array($item_id,$numiids)){
            continue;
        }else{
            $spsetting = array('dateline'=>TIMESTAMP);
            $spsetting['numiid'] = $item_id;
            $spsetting['title'] = $title;
            $spsetting['url'] = ((strpos($url,'http') ===false)?'https:':'').$url;
            $spsetting['img'] = $pict_url;
            $spsetting['youhuiquan'] = ((!empty($coupon_share_url) && strpos($coupon_share_url,'http') ===false)?'https:':'').$coupon_share_url;
            $spsetting['yuanjia'] = $reserve_price;
            $spsetting['xianjia'] = $zk_final_price;
            $spsetting['tkl'] = "";
            $spsetting['categoryid'] = $spcategoryid;
            $spsetting['couponinfo'] = $coupon_info;
            $spsetting['couponstartfee'] = $coupon_start_fee;
            $spsetting['couponamount'] = $coupon_amount;
            $spsetting['couponstarttime'] = $coupon_start_time;
            $spsetting['couponendtime'] = $coupon_end_time;
            $spsetting['couponactivityid'] = $coupon_id;
            $spsetting['coupontotalcount'] = $coupon_total_count;
            $spsetting['couponremaincount'] = $coupon_remain_count;
            $spsetting['status'] = 1;
            $spsetting['platform'] = $user_type?'tmall':'taobao';
            $spsetting['freeshipment'] = (int)$real_post_fee > 0 ?0:1;

            //tiqu  youhuijiage
            /*
            if(!empty($coupon_info)){

                if($coupon_amount > 0 &&  !empty($coupon_amount)){
                    if($coupon_start_fee > $zk_final_price){
                        $spsetting['xianjia'] = $zk_final_price;
                    }
                    if($coupon_start_fee <= $zk_final_price){
                        $spsetting['xianjia'] = intval($zk_final_price) - intval($coupon_amount);
                    }
                }elseif($coupon_amount <= 0 ||  empty($coupon_amount)){
                    if($coupon_start_fee > $zk_final_price){
                        $spsetting['xianjia'] = $zk_final_price;
                    }
                    if($coupon_start_fee <= $zk_final_price){
                        $spsetting['xianjia'] = intval($zk_final_price) - intval($coupon_start_fee);
                    }
                }
            }
            */
            if(C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->insert($spsetting,true)){
                $isok = true;
            }else{
                $isok = false;
            }
        }

    }
    
    if($isok){
        recache(false,$spcategoryid);
        cpmsg('jzsjiale_daogou:cxcaiji_success', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=chaojisousuo&act=spfanye&q='.$dsp['q'].'&itemloc='.$dsp['itemloc'].'&sort='.$dsp['sort'].'&has_coupon='.$dsp['has_coupon'].'&is_tmall='.$dsp['is_tmall'].'&is_overseas='.$dsp['is_overseas'].'&need_free_shipment='.$dsp['need_free_shipment'].'&need_prepay='.$dsp['need_prepay'].'&start_price='.$dsp['start_price'].'&end_price='.$dsp['end_price'].'&start_tk_rate='.$dsp['start_tk_rate'].'&end_tk_rate='.$dsp['end_tk_rate'].'&page_no='.$dsp['page_no'].'&page_size='.$dsp['page_size'].'&start_dsr='.$dsp['start_dsr'].'&include_pay_rate_30='.$dsp['include_pay_rate_30'].'&include_good_rate='.$dsp['include_good_rate'].'&include_rfd_rate='.$dsp['include_rfd_rate'].'&page='.$dsp['currpage'], 'succeed');
    }else{
        cpmsg('jzsjiale_daogou:cxcaiji_error', '', 'error');
    }
    
	dexit();
}






/////////caiji start

echo '<div class="colorbox"><h4>'.plang('aboutcjss').'</h4>'.
                      '<table cellspacing="0" cellpadding="3"><tr>'.
                      '<td valign="top">'.plang('cjssdescription').'</td></tr></table>'.
                      '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

/////////caiji end

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=chaojisousuo&act=sousuo', 'enctype');
showsubmit('submit', plang('sousuosubmit'));
showtableheader(plang('cjsstitle'), '');
showsetting(plang('cjssq'),'setting[q]','','text','','',plang('cjssq_msg'));
showsetting(plang('cjssitemloc'),'setting[itemloc]','','text','','',plang('cjssitemloc_msg'));

$sortselect ='';
$sortselect .= '<option value="total_sales_des" selected>'.plang('total_sales_des').'</option>';
$sortselect .= '<option value="total_sales_asc">'.plang('total_sales_asc').'</option>';
$sortselect .= '<option value="tk_rate_des">'.plang('tk_rate_des').'</option>';
$sortselect .= '<option value="tk_rate_asc">'.plang('tk_rate_asc').'</option>';
$sortselect .= '<option value="tk_total_sales_des">'.plang('tk_total_sales_des').'</option>';
$sortselect .= '<option value="tk_total_sales_asc">'.plang('tk_total_sales_asc').'</option>';
$sortselect .= '<option value="tk_total_commi_des">'.plang('tk_total_commi_des').'</option>';
$sortselect .= '<option value="tk_total_commi_asc">'.plang('tk_total_commi_asc').'</option>';
$sortselect .= '<option value="price_des">'.plang('price_des').'</option>';
$sortselect .= '<option value="price_asc">'.plang('price_asc').'</option>';
showsetting(plang('cjsssort'),'setting[sort]','','<select name="setting[sort]">'.$sortselect.'</select>','',0,plang('cjsssort_msg'),1,'cjsssort');

showsetting(plang('cjssis_has_coupon'),'setting[has_coupon]','0','radio','','',plang('cjssis_has_coupon_msg'));
showsetting(plang('cjssis_tmall'),'setting[is_tmall]','0','radio','','',plang('cjssis_tmall_msg'));
showsetting(plang('cjssis_overseas'),'setting[is_overseas]','0','radio','','',plang('cjssis_overseas_msg'));
showsetting(plang('cjssneed_free_shipment'),'setting[need_free_shipment]','0','radio','','',plang('cjssneed_free_shipment_msg'));
showsetting(plang('cjssneed_prepay'),'setting[need_prepay]','0','radio','','',plang('cjssneed_prepay_msg'));

showsetting(plang('cjssstart_price'),'setting[start_price]','','text','','',plang('cjssstart_price_msg'));
showsetting(plang('cjssend_price'),'setting[end_price]','','text','','',plang('cjssend_price_msg'));
showsetting(plang('cjssstart_tk_rate'),'setting[start_tk_rate]','','text','','',plang('cjssstart_tk_rate_msg'));
showsetting(plang('cjssend_tk_rate'),'setting[end_tk_rate]','','text','','',plang('cjssend_tk_rate_msg'));

showsetting(plang('cjssstart_dsr'),'setting[start_dsr]','','text','','',plang('cjssstart_dsr_msg'));
showsetting(plang('cjssinclude_pay_rate_30'),'setting[include_pay_rate_30]','0','radio','','',plang('cjssinclude_pay_rate_30_msg'));
showsetting(plang('cjssinclude_good_rate'),'setting[include_good_rate]','0','radio','','',plang('cjssinclude_good_rate_msg'));
showsetting(plang('cjssinclude_rfd_rate'),'setting[include_rfd_rate]','0','radio','','',plang('cjssinclude_rfd_rate_msg'));

$page_noselect ='';
$page_noselect .= '<option value="1" selected>'.plang('cjsspage_no_gong').'1'.plang('cjsspage_no_ye').'</option>';
for($ino = 2;$ino<=200;$ino++){
    $page_noselect .= '<option value="'.$ino.'">'.plang('cjsspage_no_gong').$ino.plang('cjsspage_no_ye').'</option>';
}
showsetting(plang('cjsspage_no'),'setting[page_no]','','<select name="setting[page_no]">'.$page_noselect.'</select>','',0,plang('cjsspage_no_msg'),1,'cjsspage_no');


showsetting(plang('cjsspage_size'),'setting[page_size]','20','text','','',plang('cjsspage_size_msg'));

showsubmit('submit', plang('sousuosubmit'));
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/



function setSpList($dsp) {
   
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $tbappkey = $_config['g_appkey'];
        $tbsecretKey = $_config['g_appsecret'];
        $pid = $_config['g_pid'];
        $webbianma = $_G['charset'];

        if(empty($pid)){
            cpmsg('jzsjiale_daogou:pidnull', '', 'error');
            dexit();
        }

        $adzoneId = explode("_",$pid);
        $adzoneId = $adzoneId[3];

        if(empty($adzoneId)){
            cpmsg('jzsjiale_daogou:pidnull', '', 'error');
            dexit();
        }

        //fliggy start
        $caijiurl = $dsp['q'];
        if(strpos($caijiurl,'traveldetail.fliggy.com') !==false){
            $fliggydata = getparam($caijiurl);
            $fliggyid = $fliggydata['id'];

            if(!empty($fliggyid) && $fliggyid != null){
                $dsp['q'] = "https://item.taobao.com/item.htm?id=".$fliggyid;
            }
        }
        //fliggy end

        $gtkl = new GetTbAPI;
        $gtkl->__construct($tbappkey, $tbsecretKey);
        $tbinfo =  $gtkl->getdgmaterialoptional($dsp,$adzoneId,$webbianma);

        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_cjssshangpin', getcachevars(array('cjssshangpin' => $tbinfo)));

        $tbinfo = json_decode($tbinfo);

        $splistinfo = $tbinfo->result_list->map_data;
        
        //----sp list
        echo '<div class="colorbox"><h4>'.plang('aboutcjsscx').'</h4>'.
            '<table cellspacing="0" cellpadding="3"><tr>'.
            '<td valign="top">'.plang('cjsscxdescription').'</td></tr></table>'.
            '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

        showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=chaojisousuo&act=caiji&q='.$dsp['q'].'&itemloc='.$dsp['itemloc'].'&sort='.$dsp['sort'].'&has_coupon='.$dsp['has_coupon'].'&is_tmall='.$dsp['is_tmall'].'&is_overseas='.$dsp['is_overseas'].'&need_free_shipment='.$dsp['need_free_shipment'].'&need_prepay='.$dsp['need_prepay'].'&start_price='.$dsp['start_price'].'&end_price='.$dsp['end_price'].'&start_tk_rate='.$dsp['start_tk_rate'].'&end_tk_rate='.$dsp['end_tk_rate'].'&page_no='.$dsp['page_no'].'&page_size='.$dsp['page_size'].'&start_dsr='.$dsp['start_dsr'].'&include_pay_rate_30='.$dsp['include_pay_rate_30'].'&include_good_rate='.$dsp['include_good_rate'].'&include_rfd_rate='.$dsp['include_rfd_rate'].'&currpage='.$dsp['currpage'], 'enctype');
        
        showtableheader(plang('cxsplist'), '');
        showsubtitle(plang('cxsptitle'));
        
        foreach($splistinfo as $spi){
       
	        if($webbianma == 'gbk') {
                $coupon_start_time = diconv($spi->coupon_start_time,'UTF-8','GBK');
                $coupon_end_time = diconv($spi->coupon_end_time,'UTF-8','GBK');
                //$info_dxjh = diconv($spi->info_dxjh,'UTF-8','GBK');
                $tk_total_sales = diconv($spi->tk_total_sales,'UTF-8','GBK');
                //$tk_total_commi = diconv($spi->tk_total_commi,'UTF-8','GBK');
                //$coupon_id = diconv($spi->coupon_id,'UTF-8','GBK');
                //$num_iid = diconv($spi->num_iid,'UTF-8','GBK');
                $title = diconv($spi->title,'UTF-8','GBK');
                $pict_url = diconv($spi->pict_url,'UTF-8','GBK');
                //$small_images = diconv($spi->small_images,'UTF-8','GBK');
                $reserve_price = diconv($spi->reserve_price,'UTF-8','GBK');
                $zk_final_price = diconv($spi->zk_final_price,'UTF-8','GBK');
                $user_type = diconv($spi->user_type,'UTF-8','GBK');
                $provcity = diconv($spi->provcity,'UTF-8','GBK');
                $item_url = diconv($spi->item_url,'UTF-8','GBK');
                //$include_mkt = diconv($spi->include_mkt,'UTF-8','GBK');
                //$include_dxjh = diconv($spi->include_dxjh,'UTF-8','GBK');
                $commission_rate = diconv($spi->commission_rate,'UTF-8','GBK');
                $volume = diconv($spi->volume,'UTF-8','GBK');
                //$seller_id = diconv($spi->seller_id,'UTF-8','GBK');
                $coupon_total_count = diconv($spi->coupon_total_count,'UTF-8','GBK');
                $coupon_remain_count = diconv($spi->coupon_remain_count,'UTF-8','GBK');
                $coupon_info = diconv($spi->coupon_info,'UTF-8','GBK');
                //$commission_type = diconv($spi->commission_type,'UTF-8','GBK');
                $shop_title = diconv($spi->shop_title,'UTF-8','GBK');
                $shop_dsr = diconv($spi->shop_dsr,'UTF-8','GBK');
                $coupon_share_url = diconv($spi->coupon_share_url,'UTF-8','GBK');
                $url = diconv($spi->url,'UTF-8','GBK');
                /*
                $level_one_category_name = diconv($spi->level_one_category_name,'UTF-8','GBK');
                $level_one_category_id = diconv($spi->level_one_category_id,'UTF-8','GBK');
                $category_name = diconv($spi->category_name,'UTF-8','GBK');
                $category_id = diconv($spi->category_id,'UTF-8','GBK');
                $short_title = diconv($spi->short_title,'UTF-8','GBK');
                $white_image = diconv($spi->white_image,'UTF-8','GBK');
                $oetime = diconv($spi->oetime,'UTF-8','GBK');
                $ostime = diconv($spi->ostime,'UTF-8','GBK');
                $jdd_num = diconv($spi->jdd_num,'UTF-8','GBK');
                $jdd_price = diconv($spi->jdd_price,'UTF-8','GBK');
                $uv_sum_pre_sale = diconv($spi->uv_sum_pre_sale,'UTF-8','GBK');
                $x_id = diconv($spi->x_id,'UTF-8','GBK');
                */
                $coupon_start_fee = diconv($spi->coupon_start_fee,'UTF-8','GBK');
                $coupon_amount = diconv($spi->coupon_amount,'UTF-8','GBK');
                //$item_description = diconv($spi->item_description,'UTF-8','GBK');
                $nick = diconv($spi->nick,'UTF-8','GBK');
                /*
                $orig_price = diconv($spi->orig_price,'UTF-8','GBK');
                $total_stock = diconv($spi->total_stock,'UTF-8','GBK');
                $sell_num = diconv($spi->sell_num,'UTF-8','GBK');
                $stock = diconv($spi->stock,'UTF-8','GBK');
                $tmall_play_activity_info = diconv($spi->tmall_play_activity_info,'UTF-8','GBK');
                */
                $item_id = diconv($spi->item_id,'UTF-8','GBK');
                $real_post_fee = diconv($spi->real_post_fee,'UTF-8','GBK');

	        }else{
                $coupon_start_time = $spi->coupon_start_time;
                $coupon_end_time = $spi->coupon_end_time;
                //$info_dxjh = $spi->info_dxjh;
                $tk_total_sales = $spi->tk_total_sales;
                //$tk_total_commi = $spi->tk_total_commi;
                //$coupon_id = $spi->coupon_id;
                //$num_iid = $spi->num_iid;
                $title = $spi->title;
                $pict_url = $spi->pict_url;
                //$small_images = $spi->small_images;
                $reserve_price = $spi->reserve_price;
                $zk_final_price = $spi->zk_final_price;
                $user_type = $spi->user_type;
                $provcity = $spi->provcity;
                $item_url = $spi->item_url;
                //$include_mkt = $spi->include_mkt;
                //$include_dxjh = $spi->include_dxjh;
                $commission_rate = $spi->commission_rate;
                $volume = $spi->volume;
                //$seller_id = $spi->seller_id;
                $coupon_total_count = $spi->coupon_total_count;
                $coupon_remain_count = $spi->coupon_remain_count;
                $coupon_info = $spi->coupon_info;
                //$commission_type = $spi->commission_type;
                $shop_title = $spi->shop_title;
                $shop_dsr = $spi->shop_dsr;
                $coupon_share_url = $spi->coupon_share_url;
                $url = $spi->url;
                /*
                $level_one_category_name = $spi->level_one_category_name;
                $level_one_category_id = $spi->level_one_category_id;
                $category_name = $spi->category_name;
                $category_id = $spi->category_id;
                $short_title = $spi->short_title;
                $white_image = $spi->white_image;
                $oetime = $spi->oetime;
                $ostime = $spi->ostime;
                $jdd_num = $spi->jdd_num;
                $jdd_price = $spi->jdd_price;
                $uv_sum_pre_sale = $spi->uv_sum_pre_sale;
                $x_id = $spi->x_id);
                */
                $coupon_start_fee = $spi->coupon_start_fee;
                $coupon_amount = $spi->coupon_amount;
                //$item_description = $spi->item_description;
                $nick = $spi->nick;
                /*
                $orig_price = $spi->orig_price;
                $total_stock = $spi->total_stock;
                $sell_num = $spi->sell_num;
                $stock = $spi->stock;
                $tmall_play_activity_info = $spi->tmall_play_activity_info;
                */
                $item_id = $spi->item_id;
                $real_post_fee = $spi->real_post_fee;
	        }
	        
	        $sp_url = "";
	        if(!empty($url)){
                $sp_url = $url;
            }else{
                $sp_url = $item_url;
            }
	        showtablerow('', array('width="50"'), array(
	        '<input class="checkbox" type="checkbox" name="numiids[]" value="'.$item_id.'" title="'.$item_id.'" width="80">'.$item_id,
	        '<a href="'.$sp_url.'" target="_blank"><span title="'.$title.'">'.mb_substr($title,0,40).'</span></a>',
	        '<a href="'.$sp_url.'" target="_blank"><img src="' . $pict_url . '" width="80px" /></a>',
	        '<span title="'.$reserve_price.'">'.mb_substr($reserve_price,0,40).'</span>',
	        '<span title="'.$zk_final_price.'">'.mb_substr($zk_final_price,0,40).'</span>',
	        '<span title="'.($user_type?getSpanColor(plang('cxuser_type_shangcheng'),'red'):getSpanColor(plang('cxuser_type_jishi'),'green')).'">'.($user_type?getSpanColor(plang('cxuser_type_shangcheng'),'red'):getSpanColor(plang('cxuser_type_jishi'),'green')).'</span>',
	        '<span title="'.$provcity.'">'.mb_substr($provcity,0,40).'</span>',
	        '<a href="'.(!empty($coupon_share_url)?((strpos($coupon_share_url,'http') ===false)?'https:':'').$coupon_share_url:'').'" target="_blank">' . (!empty($coupon_share_url)?((strpos($coupon_share_url,'http') ===false)?'https:':'').mb_substr($coupon_share_url,0,40).'...':'') .'</a>',
            '<a href="'.((strpos($sp_url,'http') ===false)?'https:':'').$sp_url.'" target="_blank">' . ((strpos($sp_url,'http') ===false)?'https:':'').mb_substr($sp_url,0,40) .'...</a>',
	        '<span title="'.$shop_title.'">'.mb_substr($shop_title,0,40).'</span>',
            '<span title="'.($commission_rate/100).'%">'.($commission_rate/100).'%</span>',
	        '<span title="'.$volume.'">'.mb_substr($volume,0,40).'</span>',
            '<span title="'.$coupon_info.'">'.mb_substr($coupon_info,0,40).'</span>',
            '<span title="'.$coupon_remain_count.'">'.mb_substr($coupon_remain_count,0,40).'</span>',
            '<span title="'.$coupon_start_time.'">'.mb_substr($coupon_start_time,0,40).'</span>',
            '<span title="'.$coupon_end_time.'">'.mb_substr($coupon_end_time,0,40).'</span>')
	        );
	        
	    }

	    
	    $count = $dsp['page_size'] * $dsp['page_no'];
	    $mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=chaojisousuo&act=spfanye&q='.$dsp['q'].'&itemloc='.$dsp['itemloc'].'&sort='.$dsp['sort'].'&has_coupon='.$dsp['has_coupon'].'&is_tmall='.$dsp['is_tmall'].'&is_overseas='.$dsp['is_overseas'].'&need_free_shipment='.$dsp['need_free_shipment'].'&need_prepay='.$dsp['need_prepay'].'&start_price='.$dsp['start_price'].'&end_price='.$dsp['end_price'].'&start_tk_rate='.$dsp['start_tk_rate'].'&end_tk_rate='.$dsp['end_tk_rate'].'&page_no='.$dsp['page_no'].'&page_size='.$dsp['page_size'].'&start_dsr='.$dsp['start_dsr'].'&include_pay_rate_30='.$dsp['include_pay_rate_30'].'&include_good_rate='.$dsp['include_good_rate'].'&include_rfd_rate='.$dsp['include_rfd_rate'];
	    $multipage = multi($count, $dsp['page_size'],  $dsp['currpage'], $mpurl);
	    //showsubmit('', '', '', '', $multipage);


	    showsubmit('', '', '','<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'numiids\')" /><label for="chkall">'.cplang('select_all').'</label>&nbsp;&nbsp<span style="color:red;">'.plang('cxfenleitip').'</span>&nbsp;&nbsp'.getcategoryselect().'&nbsp;&nbsp<input type="submit" class="btn" name="batchbutton" value="'.cplang('submit').'" />', plang('allcount').(!empty($multipage)?$multipage:$count));
	    
	    
	    showtablefooter(); /*Dism��taobao��com*/
	    showformfooter(); /*Dism_taobao_com*/
	 
}



function recache($isallcategory = true,$categoryid = 0){
    /*
    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();

    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
    */
    //20190329 add
    if($isallcategory){
        $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

        foreach ($category as $key => $value){

            $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1,$value["id"]);

            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));
        }
    }else{
        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $categoryid);

        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_shangpin_'.$categoryid, getcachevars(array('tbkshangpin_'.$categoryid => $shangpin_cache_tmp)));
    }

}

function getcategoryselect() {
         $categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid(0,1);
         $categoryidselect = '<option value="0">------'.plang('qingxuanze').'------</option>';
         $categoryidselect .= '<option value="0">------'.plang('bufenlei').'------</option>';
         foreach($categoryids as $k =>$v){
               $categoryidselect .= '<option value="'.$v['id'].'" >'.$v['title'].'</option>';
               $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($v['id'],1);
                 foreach($subcategoryids as $subk =>$subv){
                      $categoryidselect .= '<option value="'.$subv['id'].'" >&nbsp;&nbsp;&nbsp;&nbsp;'.$subv['title'].'</option>';
                      
                      $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($subv['id'],1);
                      foreach($sub3categoryids as $sub3k =>$sub3v){
                          $categoryidselect .= '<option value="'.$sub3v['id'].'" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sub3v['title'].'</option>';
                      }
                 }
         }
         $categoryselect = '<select name="spcategoryid" id="spcategoryid">'.$categoryidselect.'</select>';

         return $categoryselect;
}

function getSpanColor($str,$color) {
    return "<span style='color:".$color.";'>".$str."</span>";
}

function getparam($str){
    $data = array();
    $parameter = explode('&',end(explode('?',$str)));
    foreach($parameter as $val){
        $tmp = explode('=',$val);
        $data[$tmp[0]] = $tmp[1];
    }
    return $data;
}

function plang($str) {
	return lang('plugin/jzsjiale_daogou', $str);
}
//From: Dism��taobao��com
?>