<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$caijitkl = daddslashes(trim($_GET['caijitkl']));
if(empty($caijitkl) || $caijitkl == null){
    showmessage(array('dataexist' => 0));
    dexit();
}else{
    //$caijitkl = diconv($caijitkl,'UTF-8','GB2312');
    
    require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';

    global $_G;
    loadcache('plugin');
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    $tbappkey = $_config['g_appkey'];
    $tbsecretKey = $_config['g_appsecret'];
    //$webbianma = $_config['g_bianma'];
    $webbianma = $_G['charset'];
     
    $gtkl = new GetTbAPI;
    $gtkl->__construct($tbappkey, $tbsecretKey);
    $tbinfo =  $gtkl->get_tkl_query($caijitkl,$webbianma);
    
    $tbinfo = json_decode($tbinfo);
    //var_dump($tbinfo);exit;

    if(!$tbinfo->suc){
        showmessage(array('dataexist' => 0));
        dexit();
    }

    if(empty($tbinfo->content) && empty($tbinfo->url) && empty($tbinfo->pic_url)){
        showmessage(array('dataexist' => 0));
        dexit();
    }
    
    if($webbianma == "gbk"){

        $arr = array();
        $arr['dataexist'] = 1;
        $arr['numiid'] = "";
        $arr['title'] = diconv($tbinfo->content,'UTF-8','GB2312');
        $arr['imgurl'] = diconv($tbinfo->pic_url,'UTF-8','GB2312');
        $arr['url'] = diconv($tbinfo->url,'UTF-8','GB2312');
        $arr['yuanjia'] = "";
        if(!empty($tbinfo->price)){
            $arr['xianjia'] = diconv($tbinfo->price,'UTF-8','GB2312');
        }else{
            $contenttmp = diconv($tbinfo->content,'UTF-8','GB2312');
    
            preg_match_all('/'.diconv(unicode_decode('\u3010'),'UTF-8','GB2312').'(.*?)'.diconv(unicode_decode('\u5143'),'UTF-8','GB2312').diconv(unicode_decode('\u3011'),'UTF-8','GB2312').'/', $contenttmp, $matches);
            if(end($matches[1])){
                $arr['xianjia'] = end($matches[1]);
            }else{
                $arr['xianjia'] = "";
            }
            
        }
        
        showmessage($arr);
        dexit();

    }else{
        $arr = array();
        $arr['dataexist'] = 1;
        $arr['numiid'] = "";
        $arr['title'] = $tbinfo->content;
        $arr['imgurl'] = $tbinfo->pic_url;
        $arr['url'] = $tbinfo->url;
        $arr['yuanjia'] = "";
        
        if(!empty($tbinfo->price)){
            $arr['xianjia'] = $tbinfo->price;
        }else{
            $contenttmp = $tbinfo->content;
        
            preg_match_all('/'.unicode_decode('\u3010').'(.*?)'.unicode_decode('\u5143').unicode_decode('\u3011').'/', $contenttmp, $matches);
            if(end($matches[1])){
                $arr['xianjia'] = end($matches[1]);
            }else{
                $arr['xianjia'] = "";
            }
        
        }
        
        showmessage($arr);
        dexit();
    }
}
function unicode_decode($name){
 
  $json = '{"str":"'.$name.'"}';
  $arr = json_decode($json,true);
  if(empty($arr)) return '';
  return $arr['str'];
}