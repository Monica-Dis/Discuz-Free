<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
global $_G, $lang;


if($act=='add'){
	if(submitcheck('submit')){
	
		$setting = $_GET['setting'];
		$dsp = array('dateline'=>TIMESTAMP);
		$dsp['title'] = daddslashes(trim($setting['title']));
		$dsp['url'] = daddslashes(trim($setting['url']));
		$dsp['targets'] = daddslashes(trim($setting['targets']));
		$dsp['sort'] = daddslashes(trim($setting['sort']));
		$dsp['status'] = daddslashes(trim($setting['status']));
		
		if($_FILES['img']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['img'], 'common') && $upload->save(1)) {
		        $dsp['imgurl'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		        $dsp['attach'] = $upload->attach['attachment'];
		    }
		} else {
		    $dsp['imgurl'] = !empty($_GET['img'])?trim($_GET['img']):"";
		}
		
		
		if(empty($dsp['title'])){
			cpmsg('jzsjiale_daogou:dhdptitle_msgnull', '', 'error');
		}
		if(empty($dsp['url'])){
		    cpmsg('jzsjiale_daogou:dhdpurl_msgnull', '', 'error');
		}
		if(empty($dsp['targets'])){
		    cpmsg('jzsjiale_daogou:dhdptargets_msgnull', '', 'error');
		}
		if(empty($dsp['imgurl'])){
		    cpmsg('jzsjiale_daogou:dhdpimg_msgnull', '', 'error');
		}
		if(empty($dsp['sort']) && $dsp['sort'] != '0'){
		    cpmsg('jzsjiale_daogou:dhdpsort_msgnull', '', 'error');
		}
		
		if(C::t('#jzsjiale_daogou#jzsjiale_daogou_huandengpian')->insert($dsp,true)){
		    recache();
			cpmsg('jzsjiale_daogou:addok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian', 'succeed');
		}else{
			cpmsg('jzsjiale_daogou:error', '', 'error');
		}
	}
	
	
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian&act=add', 'enctype');
	showtableheader(plang('addhuandengpiantitle'), '');
	showsetting(plang('dhdptitle'),'setting[title]','','text','','',plang('dhdptitle_msg'));
	showsetting(plang('dhdpurl'),'setting[url]','#','text','','',plang('dhdpurl_msg'));
	showsetting(plang('dhdpimg'), 'img', '', 'filetext','','',plang('dhdpimg_msg'),'','dhdpimg');
	
	$targetsselect ='';
	$targetsselect .= '<option value="1" selected>'.plang('hdppc').'</option>';
	$targetsselect .= '<option value="2">'.plang('hdpmobile').'</option>';
	showsetting(plang('dhdptargets'),'setting[targets]','','<select name="setting[targets]">'.$targetsselect.'</select>','',0,plang('dhdptargets_msg'),1,'dhdptargets');
	
	showsetting(plang('dhdpsort'),'setting[sort]','0','text','','',plang('dhdpsort_msg'));
	showsetting(plang('dhdpstatus'),'setting[status]','1','radio','','',plang('dhdpstatus_msg'));

	showsubmit('submit', 'submit');
	showtablefooter(); /*Dism��taobao��com*/
	showformfooter(); /*Dism_taobao_com*/
	
	
	dexit();
}elseif($act=='delete'){
	$id = dintval($_GET['id']);
	$setting = C::t('#jzsjiale_daogou#jzsjiale_daogou_huandengpian')->fetch($id);
	if(empty($setting))
		cpmsg('jzsjiale_daogou:empty', '', 'error');
	if(submitcheck('submit')){
	    if(!empty($setting['attach'])){
	        @unlink($_G['setting']['attachdir'].'common/'.$setting['attach']);
	    }
		C::t('#jzsjiale_daogou#jzsjiale_daogou_huandengpian')->delete($id);
		recache();
		cpmsg('jzsjiale_daogou:delok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian', 'succeed');
	}
	cpmsg('jzsjiale_daogou:delhuandengpian','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian&act=delete&id='.$id.'&submit=yes','form',array('title' => $setting['title']));
}elseif($act=='edit'){
	$id = dintval($_GET['id']);
	$setting = C::t('#jzsjiale_daogou#jzsjiale_daogou_huandengpian')->fetch($id);
	if(empty($setting))
		cpmsg('jzsjiale_daogou:empty', '', 'error');
	if(submitcheck('submit')){
	    $setting = $_GET['setting'];
	    $dsp = array('dateline'=>TIMESTAMP);
		$dsp['title'] = daddslashes(trim($setting['title']));
		$dsp['url'] = daddslashes(trim($setting['url']));
		$dsp['targets'] = daddslashes(trim($setting['targets']));
		$dsp['sort'] = daddslashes(trim($setting['sort']));
		$dsp['status'] = daddslashes(trim($setting['status']));
		
		if($_FILES['img']) {
		    if(file_exists(libfile('class/upload'))){
		        require_once libfile('class/upload');
		    }else{
		        require_once libfile('discuz/upload', 'class');
		    }
		    $upload = new discuz_upload();
		    if($upload->init($_FILES['img'], 'common') && $upload->save(1)) {
		        $dsp['imgurl'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		        $dsp['attach'] = $upload->attach['attachment'];
		    }
		} else {
		    $dsp['imgurl'] = !empty($_GET['img'])?trim($_GET['img']):"";
		}
		
		
		if(empty($dsp['title'])){
			cpmsg('jzsjiale_daogou:dhdptitle_msgnull', '', 'error');
		}
		if(empty($dsp['url'])){
		    cpmsg('jzsjiale_daogou:dhdpurl_msgnull', '', 'error');
		}
		if(empty($dsp['targets'])){
		    cpmsg('jzsjiale_daogou:dhdptargets_msgnull', '', 'error');
		}
		if(empty($dsp['imgurl'])){
		    cpmsg('jzsjiale_daogou:dhdpimg_msgnull', '', 'error');
		}
		if(empty($dsp['sort']) && $dsp['sort'] != '0'){
		    cpmsg('jzsjiale_daogou:dhdpsort_msgnull', '', 'error');
		}
		
		if(C::t('#jzsjiale_daogou#jzsjiale_daogou_huandengpian')->update($id,$dsp)){
		    recache();
			cpmsg('jzsjiale_daogou:editok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian', 'succeed');
		}else{
			cpmsg('jzsjiale_daogou:error', '', 'error');
		}
		
	
	}
	
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian&act=edit', 'enctype');
	echo'<input type="hidden" value="'.dhtmlspecialchars($setting['id']).'" name="id"/>';
	showtableheader(plang('edithuandengpiantitle'), '');
	
	
	showsetting(plang('dhdptitle'),'setting[title]',dhtmlspecialchars($setting['title']),'text','','',plang('dhdptitle_msg'));
	showsetting(plang('dhdpurl'),'setting[url]',dhtmlspecialchars($setting['url']),'text','','',plang('dhdpurl_msg'));
	showsetting(plang('dhdpimg'), 'img', dhtmlspecialchars($setting['imgurl']), 'filetext','','',plang('dhdpimg_msg'),'','dhdpimg');
	
	$targetsselect ='';
	$targetsselect .= '<option value="1" '.(dhtmlspecialchars($setting['targets'])==1?'selected':'').'>'.plang('hdppc').'</option>';
	$targetsselect .= '<option value="2" '.(dhtmlspecialchars($setting['targets'])==2?'selected':'').'>'.plang('hdpmobile').'</option>';
	showsetting(plang('dhdptargets'),'setting[targets]','','<select name="setting[targets]">'.$targetsselect.'</select>','',0,plang('dhdptargets_msg'),1,'dhdptargets');
	
	showsetting(plang('dhdpsort'),'setting[sort]',dhtmlspecialchars($setting['sort']),'text','','',plang('dhdpsort_msg'));
	showsetting(plang('dhdpstatus'),'setting[status]',dhtmlspecialchars($setting['status']),'radio','','',plang('dhdpstatus_msg'));

	showsubmit('submit', 'submit');
	showtablefooter(); /*Dism��taobao��com*/
	showformfooter(); /*Dism_taobao_com*/
	dexit();
}elseif($act=='cache'){
    
            $daogouhuandengpian = C::t('#jzsjiale_daogou#jzsjiale_daogou_huandengpian')->getall();
      
            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_huandengpian', getcachevars(array('daogouhuandengpian' => $daogouhuandengpian)));
        
            if(count($daogouhuandengpian) > 0){
                cpmsg('jzsjiale_daogou:cache_success', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian', 'succeed');
            }else{
                cpmsg('jzsjiale_daogou:cache_error', '', 'error');
            }
            
        
        dexit();
}


loadcache('plugin');

echo '<div class="colorbox"><h4>'.plang('abouthuandengpian').'</h4>'.
    '<table cellspacing="0" cellpadding="3"><tr>'.
    '<td valign="top">'.plang('huandengpiandescription').'</td></tr></table>'.
    '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

$page = intval($_GET['page']);
$page = $page > 0 ? $page : 1;
$pagesize = 150;
$start = ($page - 1) * $pagesize;

$allhuandengpian = C::t('#jzsjiale_daogou#jzsjiale_daogou_huandengpian')->range($start,$pagesize,'DESC');
$count = C::t('#jzsjiale_daogou#jzsjiale_daogou_huandengpian')->count();
showtableheader(plang('hdplist').'(  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian&act=add" style="color:red;">'.plang('addhuandengpian').'</a>  |  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian&act=cache" style="color:red;">'.plang('cachehuandengpian').'</a>)', '');
showsubtitle(plang('hdptitle'));

foreach($allhuandengpian as $d){
	showtablerow('', array('width="150"'), array(
	$d['id'],
	'<span title="'.dhtmlspecialchars($d['title']).'">'.mb_substr(dhtmlspecialchars($d['title']),0,20).'</span>',
	'<a href="'.dhtmlspecialchars($d['imgurl']).'" target="_blank"><img src="' . dhtmlspecialchars($d['imgurl']) . '" width="80px" /></a>',
	'<span title="'.(dhtmlspecialchars($d['targets'])==1?plang('hdppc'):'').'" '.(dhtmlspecialchars($d['targets'])==1?' style="color:red;display:block;"':' style="display:none;"').'>'.(dhtmlspecialchars($d['targets'])==1?plang('hdppc'):'').'</span><span title="'.(dhtmlspecialchars($d['targets'])==2?plang('hdpmobile'):'').'" '.(dhtmlspecialchars($d['targets'])==2?' style="color:blue;display:block;"':' style="display:none;"').'>'.(dhtmlspecialchars($d['targets'])==2?plang('hdpmobile'):'').'</span>',
	'<a href="'.dhtmlspecialchars($d['url']).'" target="_blank"><span title="'.dhtmlspecialchars($d['url']).'">'.mb_substr(dhtmlspecialchars($d['url']),0,20).'...</span></a>',
	'<span title="'.(dhtmlspecialchars($d['status'])?plang('yes'):plang('no')).'">'.(dhtmlspecialchars($d['status'])?'<span style="color:green;">'.plang('yes').'</span>':'<span style="color:red;">'.plang('no').'</span>').'</span>',
	'<span title="'.dhtmlspecialchars($d['sort']).'">'.mb_substr(dhtmlspecialchars($d['sort']),0,20).'</span>',
	dgmdate(dhtmlspecialchars($d['dateline'])),
	'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian&act=edit&id='.dhtmlspecialchars($d['id']).'">'.plang('edit').'</a>&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian&act=delete&id='.dhtmlspecialchars($d['id']).'">'.plang('delete').'</a>')
	);
}

$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=huandengpian';
$multipage = multi($count, $pagesize, $page, $mpurl);
showsubmit('', '', '', '', $multipage);
showtablefooter(); /*Dism��taobao��com*/

function plang($str) {
	return lang('plugin/jzsjiale_daogou', $str);
}

function recache() {
    $daogouhuandengpian = C::t('#jzsjiale_daogou#jzsjiale_daogou_huandengpian')->getall();
    
    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_huandengpian', getcachevars(array('daogouhuandengpian' => $daogouhuandengpian)));

}
//From: Dism��taobao��com
?>