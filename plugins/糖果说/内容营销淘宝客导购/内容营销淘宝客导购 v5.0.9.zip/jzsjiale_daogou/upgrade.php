<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT."/source/function/function_plugin.php";

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_daogou_shangpin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numiid` varchar(1024) NOT NULL DEFAULT '',
  `title` varchar(1024) NOT NULL DEFAULT '',
  `url` varchar(1024) NOT NULL DEFAULT '',
  `youhuiquan` varchar(1024) NOT NULL DEFAULT '',
  `img` varchar(1024) NOT NULL DEFAULT '',  
  `attach` varchar(1024) NOT NULL DEFAULT '',
  `yuanjia` decimal(10,2) NOT NULL DEFAULT 0,
  `xianjia` decimal(10,2) NOT NULL DEFAULT 0,
  `tkl` varchar(1024) NOT NULL DEFAULT '',
  `tklsimple` varchar(1024) NOT NULL DEFAULT '',
  `tkldateline` int(11) unsigned NOT NULL,
  `flag` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `categoryid` int(11) NOT NULL DEFAULT 0,
  `favoritesid` int(11) NOT NULL DEFAULT 0,
  `couponinfo` varchar(255) NOT NULL DEFAULT '',
  `couponstartfee` varchar(255) NOT NULL DEFAULT '',
  `couponamount` varchar(255) NOT NULL DEFAULT '',
  `couponstarttime` varchar(255) NOT NULL DEFAULT '',
  `couponendtime` varchar(255) NOT NULL DEFAULT '',
  `couponactivityid` varchar(255) NOT NULL DEFAULT '',
  `coupontotalcount` int(11) NOT NULL DEFAULT 0,
  `couponremaincount` int(11) NOT NULL DEFAULT 0,
  `platform` varchar(255) NOT NULL DEFAULT '',
  `freeshipment` int(11) NOT NULL DEFAULT 0,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX shangpin_name (`title`)
);

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_daogou_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(1024) NOT NULL DEFAULT '',
  `attach` varchar(1024) NOT NULL DEFAULT '',
  `title` varchar(1024) NOT NULL DEFAULT '',
  `color` varchar(1024) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `keywords` varchar(1024) NOT NULL DEFAULT '',
  `description` varchar(1024) NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `sort` int(11) NOT NULL DEFAULT 0,
  `fids` text NOT NULL DEFAULT '',
  `catids` text NOT NULL DEFAULT '',
  `groups` text NOT NULL DEFAULT '',
  `daogou` text NOT NULL DEFAULT '',
  `level` int(11) NOT NULL DEFAULT 1,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX category_name (`title`)
);

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_daogou_tiezicategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(1024) NOT NULL DEFAULT '',
  `attach` varchar(1024) NOT NULL DEFAULT '',
  `title` varchar(1024) NOT NULL DEFAULT '',
  `color` varchar(1024) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `keywords` varchar(1024) NOT NULL DEFAULT '',
  `description` varchar(1024) NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `sort` int(11) NOT NULL DEFAULT 0,
  `level` int(11) NOT NULL DEFAULT 1,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX tiezicategory_name (`title`)
);

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_daogou_huandengpian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1024) NOT NULL DEFAULT '',
  `imgurl` text NOT NULL DEFAULT '',
  `attach` varchar(1024) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `targets` int(11) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX huandengpian_name (`title`)
);


CREATE TABLE IF NOT EXISTS `pre_jzsjiale_daogou_tiezi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1024) NOT NULL DEFAULT '',
  `tid` int(11) NOT NULL DEFAULT 0,
  `tiezicategoryid` int(11) NOT NULL DEFAULT 0,
  `uid` int(11) NOT NULL DEFAULT 1,
  `sort` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX tiezi_name (`title`)
);

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_daogou_daogou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(1024) NOT NULL DEFAULT '',
  `value` text NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
   INDEX daogou_name (`key`)
);

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_daogou_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1024) NOT NULL DEFAULT '',
  `contentid` int(11) NOT NULL DEFAULT 0,
  `tid` int(11) NOT NULL DEFAULT 0,
  `source` varchar(1024) NOT NULL DEFAULT '',
  `remark` text NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL default 1,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  INDEX content_name (`title`)
);

EOF;

runquery($sql);

$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_daogou_shangpin'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('numiid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `numiid` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('title', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `title` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('url', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `url` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('youhuiquan', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `youhuiquan` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('img', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `img` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('attach', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `attach` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('yuanjia', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `yuanjia` decimal(10,2) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('xianjia', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `xianjia` decimal(10,2) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('tkl', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `tkl` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('tklsimple', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `tklsimple` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('tkldateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `tkldateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}
if(!in_array('flag', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `flag` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('status', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `status` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('categoryid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `categoryid` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('favoritesid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `favoritesid` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('couponinfo', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `couponinfo` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('couponstartfee', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `couponstartfee` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('couponamount', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `couponamount` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('couponstarttime', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `couponstarttime` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('couponendtime', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `couponendtime` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('couponactivityid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `couponactivityid` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('coupontotalcount', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `coupontotalcount` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('couponremaincount', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `couponremaincount` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('platform', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `platform` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('freeshipment', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `freeshipment` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_shangpin')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}
unset($col_field);


$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_daogou_category'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('img', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `img` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('attach', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `attach` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('title', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `title` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('color', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `color` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('pid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `pid` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('keywords', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `keywords` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('description', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `description` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('status', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `status` tinyint(4) NOT NULL DEFAULT 1;";
    DB::query($sql);
}
if(!in_array('sort', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `sort` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('fids', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `fids` text NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('catids', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `catids` text NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('groups', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `groups` text NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('daogou', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `daogou` text NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('level', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `level` int(11) NOT NULL DEFAULT 1;";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_category')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}
unset($col_field);



$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_daogou_tiezicategory'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezicategory')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('img', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezicategory')." add `img` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('attach', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezicategory')." add `attach` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('title', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezicategory')." add `title` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('color', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezicategory')." add `color` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('pid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezicategory')." add `pid` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('keywords', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezicategory')." add `keywords` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('description', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezicategory')." add `description` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('status', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezicategory')." add `status` tinyint(4) NOT NULL DEFAULT 1;";
    DB::query($sql);
}
if(!in_array('sort', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezicategory')." add `sort` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('level', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezicategory')." add `level` int(11) NOT NULL DEFAULT 1;";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezicategory')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}
unset($col_field);



$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_daogou_huandengpian'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_huandengpian')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('title', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_huandengpian')." add `title` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('imgurl', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_huandengpian')." add `imgurl` text NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('attach', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_huandengpian')." add `attach` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('url', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_huandengpian')." add `url` text NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('targets', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_huandengpian')." add `targets` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('sort', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_huandengpian')." add `sort` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('status', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_huandengpian')." add `status` tinyint(4) NOT NULL DEFAULT 1;";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_huandengpian')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}

unset($col_field);



$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_daogou_tiezi'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezi')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('title', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezi')." add `title` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('tid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezi')." add `tid` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('tiezicategoryid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezi')." add `tiezicategoryid` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('uid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezi')." add `uid` int(11) NOT NULL DEFAULT 1;";
    DB::query($sql);
}
if(!in_array('sort', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezi')." add `sort` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('status', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezi')." add `status` tinyint(4) NOT NULL DEFAULT 1;";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_tiezi')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}

unset($col_field);


$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_daogou_daogou'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_daogou')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('key', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_daogou')." add `key` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('value', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_daogou')." add `value` text NOT NULL DEFAULT '';";
    DB::query($sql);
}
unset($col_field);


$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_daogou_content'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_content')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('title', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_content')." add `title` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('contentid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_content')." add `contentid` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('tid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_content')." add `tid` int(11) NOT NULL DEFAULT 0;";
    DB::query($sql);
}
if(!in_array('source', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_content')." add `source` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('remark', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_content')." add `remark` text NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('status', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_content')." add `status` tinyint(4) NOT NULL default 1;";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_daogou_content')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}
unset($col_field);


//---UPDATE START
$sql = "UPDATE ".DB::table('jzsjiale_daogou_daogou')." SET `value` = 'source/plugin/jzsjiale_daogou/static/images/v1/daogou/nopic.jpg' WHERE `value` like '%source/plugin/jzsjiale_daogou/static/images/daogou/nopic.jpg%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_daogou')." SET `value` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/ad1.png' WHERE `value` like '%source/plugin/jzsjiale_daogou/static/images/daogou/ad1.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_daogou')." SET `value` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/headerlogo.png' WHERE `value` like '%source/plugin/jzsjiale_daogou/static/images/daogou/headerlogo.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_daogou')." SET `value` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/erweima.png' WHERE `value` like '%source/plugin/jzsjiale_daogou/static/images/daogou/erweima.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_daogou')." SET `value` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/footerlogo.png' WHERE `value` like '%source/plugin/jzsjiale_daogou/static/images/daogou/footerlogo.png%';";
DB::query($sql);
$tmpret = DB::fetch_first("SELECT * FROM ".DB::table('jzsjiale_daogou_daogou')."  WHERE `key` = 'daogoustyle' ORDER BY id DESC limit 0,1");
if(empty($tmpret) || $tmpret == null){
    $sql = "INSERT INTO ".DB::table('jzsjiale_daogou_daogou')." (`key`,`value`) VALUES ('daogoustyle', '1') ;";
    DB::query($sql);
}
$sql = "UPDATE ".DB::table('jzsjiale_daogou_huandengpian')." SET `imgurl` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/banner1.png' WHERE `imgurl` like '%source/plugin/jzsjiale_daogou/static/images/daogou/banner1.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_huandengpian')." SET `imgurl` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/banner1.png' WHERE `imgurl` like '%source/plugin/jzsjiale_daogou/static/images/daogou/banner1.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_huandengpian')." SET `imgurl` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/banner4.png' WHERE `imgurl` like '%source/plugin/jzsjiale_daogou/static/images/daogou/banner4.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_huandengpian')." SET `imgurl` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/banner4.png' WHERE `imgurl` like '%source/plugin/jzsjiale_daogou/static/images/daogou/banner4.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_category')." SET `img` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/110.png' WHERE `img` like '%source/plugin/jzsjiale_daogou/static/images/daogou/icon/110.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_category')." SET `img` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/120.png' WHERE `img` like '%source/plugin/jzsjiale_daogou/static/images/daogou/icon/120.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_category')." SET `img` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/130.png' WHERE `img` like '%source/plugin/jzsjiale_daogou/static/images/daogou/icon/130.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_category')." SET `img` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/140.png' WHERE `img` like '%source/plugin/jzsjiale_daogou/static/images/daogou/icon/140.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_category')." SET `img` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/210.png' WHERE `img` like '%source/plugin/jzsjiale_daogou/static/images/daogou/icon/210.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_category')." SET `img` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/220.png' WHERE `img` like '%source/plugin/jzsjiale_daogou/static/images/daogou/icon/220.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_category')." SET `img` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/310.png' WHERE `img` like '%source/plugin/jzsjiale_daogou/static/images/daogou/icon/310.png%';";
DB::query($sql);
$sql = "UPDATE ".DB::table('jzsjiale_daogou_category')." SET `img` = 'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/320.png' WHERE `img` like '%source/plugin/jzsjiale_daogou/static/images/daogou/icon/320.png%';";
DB::query($sql);

/*
$tmpret = DB::fetch_first("SELECT * FROM ".DB::table('common_nav')."  WHERE `url` like '%plugin.php?id=jzsjiale_daogou:souquan%' OR `url` like '%souquan.html%'");
if(empty($tmpret) || $tmpret == null){
    $sql = "INSERT INTO ".DB::table('common_nav')." (`parentid`,`name`,`title`,`url`,`identifier`,`target`,`type`,`available`,`displayorder`,`highlight`,`level`,`subtype`,`subcols`,`icon`,`subname`,`suburl`,`navtype`,`logo`) VALUES (0,'$installlang[installmenu5]','','plugin.php?id=jzsjiale_daogou:souquan','',0,1,1,4,0,0,0,0,'','','',0,'') ;";
    DB::query($sql);
}
*/

$daogouoption = C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->getall();
require_once libfile('function/cache');
writetocache('jzsjiale_daogou_daogou', getcachevars(array('daogouoption' => $daogouoption)));

$daogouhuandengpian = C::t('#jzsjiale_daogou#jzsjiale_daogou_huandengpian')->getall();
require_once libfile('function/cache');
writetocache('jzsjiale_daogou_huandengpian', getcachevars(array('daogouhuandengpian' => $daogouhuandengpian)));

$tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
require_once libfile('function/cache');
writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));
//--UPDATE END

$pluginid = 'jzsjiale_daogou';

$Hooks = array (
    'viewthread_variables'
);

$data = array ();
foreach ( $Hooks as $Hook ) {
    $data [] = array (
        $Hook => array (
            'plugin' => $pluginid,
            'include' => 'api.class.php',
            'class' => $pluginid . '_api',
            'method' => $Hook
        )
    );
}

require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
WeChatHook::updateAPIHook($data);


@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/discuz_plugin_jzsjiale_daogou.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/discuz_plugin_jzsjiale_daogou_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/discuz_plugin_jzsjiale_daogou_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/discuz_plugin_jzsjiale_daogou_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/discuz_plugin_jzsjiale_daogou_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/install.php');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/upgrade.php');

$finish = TRUE;
?>