<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';
$utils = new Utils();

global $_G;

$act = daddslashes(trim($_GET['a']));

if($act == 'sp'){
    $t = daddslashes(trim($_GET['t']));
    $spid = intval(daddslashes(trim($_GET['spid'])));

    /*
    $shangpin = "";


    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php')){
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php';
    
        $shangpin = $tbkshangpin;
    }else{
        $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();
    
        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
    
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php';
        $shangpin = $tbkshangpin;
    }
*/

    $shangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->fetch($spid);

    if(!empty($t) && $t == 'url'){
        //$res = $utils->searchGetOne($spid,'id','url',$shangpin);
        $res = $shangpin['url'];
        if(!empty($res)){
            dheader("Location: ".$res);
            dexit();
        }else{
            dheader("Location: plugin.php?id=jzsjiale_daogou:daogou");
            dexit();
        }
        
    }elseif(!empty($t) && $t == 'youhuiquanurl'){
        //$res = $utils->searchGetOne($spid,'id','youhuiquan',$shangpin);
        $res = $shangpin['youhuiquan'];
        if(!empty($res)){
            dheader("Location: ".$res);
            dexit();
        }else{
            dheader("Location: plugin.php?id=jzsjiale_daogou:daogou");
            dexit();
        }
        
    }else{
        dheader("Location: plugin.php?id=jzsjiale_daogou:daogou");
        dexit();
    }
    
}else if($act == 'zjzr') {
    $spurl = daddslashes(trim($_GET['spurl']));

    $spurl_data = str_replace(array('-','_'),array('+','/'),$spurl);
    $mod4 = strlen($spurl_data) % 4;
    if ($mod4) {
        $spurl_data .= substr('====', $mod4);
    }
    $spurl_data = base64_decode($spurl_data);

    if(!empty($spurl_data)){
        dheader("Location: ".$spurl_data);
        dexit();
    }else{
        dheader("Location: plugin.php?id=jzsjiale_daogou:daogou");
        dexit();
    }

}else{
    dheader("Location: plugin.php?id=jzsjiale_daogou:daogou");
    dexit();
}
//From: dis'.'m.t'.'ao'.'bao.com
?>