<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (! defined ( 'IN_DISCUZ' )) {
	exit ( 'Access Denied' );
}

require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';
require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';

class jzsjiale_daogou_api {
    
    var $count = 0;


    function gettaobaoke($message)
    {
    	$message = $message[0];
        $this->count ++;
        $id = 'tbk' . $this->count;
        
        $message = trim($message);
        $message = str_ireplace('&amp;', '&', $message);
        
        $message = substr($message, strlen('[jzsjiale_daogou]'), strlen($message) - strlen('[jzsjiale_daogou]') - strlen('[/jzsjiale_daogou]'));
        $tbkarray = explode(',=', $message);
        
        $tbk_title = $tbkarray[0];
        $tbk_imgurl = $tbkarray[1];
        
        $pattern = "/^[a-zA-z]+:\/\/[^\s]*[.]{1}(gif|jpg|png|bmp|jpeg)$/is";
        if ( !preg_match( $pattern, $tbk_imgurl ) )
        {
            $tbk_imgurl = "#";
        }
        
        $tbk_url = $tbkarray[2];
        
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        
        $pattern = "/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/is";
        if(!empty($_config['g_urlxieyi'])){
		    $pattern = "/^((".$_config['g_urlxieyi'].")?:\/\/)[^\s]+$/is";
		}
        if ( !preg_match( $pattern, $tbk_url ) )
        {
            $tbk_url = "#";
        }
        $tbk_yuanjia = $tbkarray[3];
        
        $isyuanjia = true;
        if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == ""){
            $isyuanjia = false;
        }
        
        
        $tbk_xianjia = $tbkarray[4];
        
        
        $tbk_youhuiquanurl = $tbkarray[5];
        $pattern = "/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/is";
        if(!empty($_config['g_urlxieyi'])){
		    $pattern = "/^((".$_config['g_urlxieyi'].")?:\/\/)[^\s]+$/is";
		}
        if ( !preg_match( $pattern, $tbk_youhuiquanurl ) )
        {
            $tbk_youhuiquanurl = "#";
        }
        
        $tbk_fengge = $tbkarray[6];
        
        
        $tbk_myouhuitips = $_config['g_myouhuitips'];
        
        $isshowyhk = false;
        if(!empty($tbk_youhuiquanurl) && $tbk_youhuiquanurl != "#"){
            $isshowyhk = true;
        }
        
       
        
        $tbkstyle = $_config['g_wsqstyle'];
        if(empty($tbkstyle)){
            $tbkstyle = "wsq1";
        }
        
        
        
        
        $tbk_tkl = $tbkarray[7];
        if ( $tbk_tkl == "" || $tbk_tkl == null )
        {
            $tbk_tkl = "#";
        }
        
        
        if($_config['g_iswsqtkl']){

            $tbappkey = $_config['g_appkey'];
            $tbsecretKey = $_config['g_appsecret'];
            //$webbianma = $_config['g_bianma'];
            $webbianma = $_G['charset'];
            
            
            if($tbk_tkl == "" || $tbk_tkl == null || $tbk_tkl == '#'){
                
                $gtkl = new GetTbAPI;
                $gtkl->__construct($tbappkey, $tbsecretKey);
                $tbktkl =  $gtkl->gettkl($tbk_title,$tbk_url,$tbk_imgurl,$webbianma);
                
                $tbktkl = json_decode($tbktkl);
                if($webbianma == "gbk"){
                    $tbktkl = diconv($tbktkl->model,'UTF-8','GB2312');
                }else{
                    $tbktkl = $tbktkl->model;
                }
            }else{
                $tbktkl = $tbk_tkl;
            }
            
            
            
            $tkltips = $_config['g_tkltips'];
            
            if(!empty($tbktkl)){
                $tbkstyle = $_config['g_wsqtklstyle'];
                if(empty($tbkstyle)){
                    $tbkstyle = "taokouling";
                }
            }
            
        }else{
            if(!empty($tbk_tkl)){
                $tbktkl = $tbk_tkl;
                
                $tkltips = $_config['g_tkltips'];
                
                if(!empty($tbktkl)){
                    $tbkstyle = $_config['g_wsqtklstyle'];
                    if(empty($tbkstyle)){
                        $tbkstyle = "taokouling";
                    }
                }
            }
                
        }
        
        $g_isopenzhtglj = $_config['g_isopenzhtglj'];
        $numiid = $tbkarray[8];
        if($numiid == "#"){
            $numiid = '';
        }
        
        $tbk_goumai = $_config['g_goumai'];
        $tbk_youhuiquan = $_config['g_youhuiquan'];
        
        $isnofollow = true;
        $isnofollow = $_config['g_isnofollow'];
        
        include template('jzsjiale_daogou:'.$tbkstyle);
        return trim($return);
    }
    
    
    function gettaobaokejianrong($message)
    {
        $message = $message[0];
        $this->count ++;
        $id = 'tbk' . $this->count;
    
        $message = trim($message);
        $message = str_ireplace('&amp;', '&', $message);
    
        $message = substr($message, strlen('[jzsjiale_taobaoke]'), strlen($message) - strlen('[jzsjiale_taobaoke]') - strlen('[/jzsjiale_taobaoke]'));
        $tbkarray = explode(',=', $message);
    
        $tbk_title = $tbkarray[0];
        $tbk_imgurl = $tbkarray[1];
    
        $pattern = "/^[a-zA-z]+:\/\/[^\s]*[.]{1}(gif|jpg|png|bmp|jpeg)$/is";
        if ( !preg_match( $pattern, $tbk_imgurl ) )
        {
            $tbk_imgurl = "#";
        }
    
        $tbk_url = $tbkarray[2];
    
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        
        $pattern = "/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/is";
        if(!empty($_config['g_urlxieyi'])){
		    $pattern = "/^((".$_config['g_urlxieyi'].")?:\/\/)[^\s]+$/is";
		}
        if ( !preg_match( $pattern, $tbk_url ) )
        {
            $tbk_url = "#";
        }
        $tbk_yuanjia = $tbkarray[3];
    
        $isyuanjia = true;
        if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == ""){
            $isyuanjia = false;
        }
    
    
        $tbk_xianjia = $tbkarray[4];
    
    
        $tbk_youhuiquanurl = $tbkarray[5];
        $pattern = "/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/is";
        if(!empty($_config['g_urlxieyi'])){
		    $pattern = "/^((".$_config['g_urlxieyi'].")?:\/\/)[^\s]+$/is";
		}
        if ( !preg_match( $pattern, $tbk_youhuiquanurl ) )
        {
            $tbk_youhuiquanurl = "#";
        }
    
        $tbk_fengge = $tbkarray[6];
    
        
        $tbk_myouhuitips = $_config['g_myouhuitips'];
    
        $isshowyhk = false;
        if(!empty($tbk_youhuiquanurl) && $tbk_youhuiquanurl != "#"){
            $isshowyhk = true;
        }
    
         
    
        $tbkstyle = $_config['g_wsqstyle'];
        if(empty($tbkstyle)){
            $tbkstyle = "wsq1";
        }
    
    
    
    
        $tbk_tkl = $tbkarray[7];
        if ( $tbk_tkl == "" || $tbk_tkl == null )
        {
            $tbk_tkl = "#";
        }
    
    
        if($_config['g_iswsqtkl']){
    
            $tbappkey = $_config['g_appkey'];
            $tbsecretKey = $_config['g_appsecret'];
            //$webbianma = $_config['g_bianma'];
            $webbianma = $_G['charset'];
    
    
            if($tbk_tkl == "" || $tbk_tkl == null || $tbk_tkl == '#'){
    
                $gtkl = new GetTbAPI;
                $gtkl->__construct($tbappkey, $tbsecretKey);
                $tbktkl =  $gtkl->gettkl($tbk_title,$tbk_url,$tbk_imgurl,$webbianma);
    
                $tbktkl = json_decode($tbktkl);
                if($webbianma == "gbk"){
                    $tbktkl = diconv($tbktkl->model,'UTF-8','GB2312');
                }else{
                    $tbktkl = $tbktkl->model;
                }
            }else{
                $tbktkl = $tbk_tkl;
            }
    
    
    
            $tkltips = $_config['g_tkltips'];
    
            if(!empty($tbktkl)){
                $tbkstyle = $_config['g_wsqtklstyle'];
                if(empty($tbkstyle)){
                    $tbkstyle = "taokouling";
                }
            }
    
        }else{
            if(!empty($tbk_tkl)){
                $tbktkl = $tbk_tkl;
                
                $tkltips = $_config['g_tkltips'];
                
                if(!empty($tbktkl)){
                    $tbkstyle = $_config['g_wsqtklstyle'];
                    if(empty($tbkstyle)){
                        $tbkstyle = "taokouling";
                    }
                }
            }
                
        }
    
    
        $tbk_goumai = $_config['g_goumai'];
        $tbk_youhuiquan = $_config['g_youhuiquan'];
    
        $isnofollow = true;
        $isnofollow = $_config['g_isnofollow'];
    
        include template('jzsjiale_daogou:'.$tbkstyle);
        return trim($return);
    }
    
    function getspkshangpin($message)
    {
        
        $message = $message[0];
        $this->count ++;
        $id = 'tbk' . $this->count;
        
        $message = trim($message);
        $message = str_ireplace('&amp;', '&', $message);
        
        $message = substr($message, strlen('[jzsjiale_daogou_spk]'), strlen($message) - strlen('[jzsjiale_daogou_spk]') - strlen('[/jzsjiale_daogou_spk]'));
        $sbkarray = explode(',=', $message);
        
        $shangpinid = $sbkarray[0];
        
        $shangpinid = is_numeric($shangpinid)?$shangpinid:0;
        
        $shangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->get_by_id($shangpinid);
        
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    
        $tbk_title = $shangpin['title'];
        $tbk_imgurl = $shangpin['img'];
        $tbk_url = $shangpin['url'];
        $tbk_yuanjia = $shangpin['yuanjia'];
    
        $isyuanjia = true;
        if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == ""){
            $isyuanjia = false;
        }
    
        $tbk_xianjia = $shangpin['xianjia'];
    
        $tbk_youhuiquanurl = $shangpin['youhuiquan'];
        $tbk_myouhuitips = $_config['g_myouhuitips'];
    
        $isshowyhk = false;
        if(!empty($shangpin['youhuiquan'])){
            $isshowyhk = true;
        }
    
        $tbkstyle = $_config['g_wsqstyle'];
        if(empty($tbkstyle)){
            $tbkstyle = "wsq1";
        }
    
    
        $tbk_tkl = $shangpin['tkl'];
    
    
        if($_config['g_iswsqtkl']){
    
            $tbappkey = $_config['g_appkey'];
            $tbsecretKey = $_config['g_appsecret'];
            //$webbianma = $_config['g_bianma'];
            $webbianma = $_G['charset'];
    
    
            $g_tklguoqishijian = $_config['g_tklguoqishijian'];
            $hourtime = strtotime("-".($g_tklguoqishijian*24)." hour");
        
            if(empty($tbk_tkl) || $shangpin['tkldateline'] <= $hourtime){
                $gtkl = new GetTbAPI;
                $gtkl->__construct($tbappkey, $tbsecretKey);
                $tbktkl =  $gtkl->gettkl($tbk_title,$tbk_url,$tbk_imgurl,$webbianma);
    
                $tbktkl = json_decode($tbktkl);
                if($webbianma == "gbk"){
                    $tbktkl = diconv($tbktkl->model,'UTF-8','GB2312');
                }else{
                    $tbktkl = $tbktkl->model;
                }
                
                if($g_tklguoqishijian>0){
                    $dsp = array('tkldateline'=>TIMESTAMP);
                    $dsp['tkl'] = $tbktkl;
                
                    C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->update($shangpin['id'],$dsp);
                }
            }else{
                $tbktkl = $tbk_tkl;
            }
    
    
    
            $tkltips = $_config['g_tkltips'];
    
            if(!empty($tbktkl)){
                $tbkstyle = $_config['g_wsqtklstyle'];
                if(empty($tbkstyle)){
                    $tbkstyle = "taokouling";
                }
            }
    
        }else{
            if(!empty($tbk_tkl)){
                $tbktkl = $tbk_tkl;
                
                $tkltips = $_config['g_tkltips'];
                
                if(!empty($tbktkl)){
                    $tbkstyle = $_config['g_wsqtklstyle'];
                    if(empty($tbkstyle)){
                        $tbkstyle = "taokouling";
                    }
                }
            }
                
        }
        
        $g_isopenzhtglj = $_config['g_isopenzhtglj'];
        $numiid = $shangpin['numiid'];
    
        $tbk_goumai = $_config['g_goumai'];
        $tbk_youhuiquan = $_config['g_youhuiquan'];
    
        $isnofollow = true;
        $isnofollow = $_config['g_isnofollow'];
    
        if($_config['g_spneilian']){
            $tbk_url = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$shangpin['id'];
            $tbk_youhuiquanurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$shangpin['id'];
        }
        
        include template('jzsjiale_daogou:'.$tbkstyle);
        return trim($return);
    }
    
	function viewthread_variables(&$variables) {
	  
	    global $_G;
	    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
	     
	    if (! $_config['g_isopen']) {
	        return;
	    }
	    
	    $pid = $_G['forum_firstpid'];
	    
	    
	    /*
	    if (strpos($variables['postlist'][0]['message'], '[/jzsjiale_daogou]') == true || strpos($variables['postlist'][0]['message'], '[/jzsjiale_daogou_spk]') == true || strpos($variables['postlist'][0]['message'], '[/jzsjiale_taobaoke]') == true) {
	        
	        $variables['postlist'][0]['message'] = preg_replace_callback('/\s?\[jzsjiale_daogou\](.*?)\[\/jzsjiale_daogou\]\s?/is', array(
    	       $this,
    	       'gettaobaoke'
    	    ), $variables['postlist'][0]['message']);
    	  
    	    //$variables['postlist'][0]['message'] .= "<link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/mobiletbkitem.css\" type=\"text/css\" />";
    
    	    $variables['postlist'][0]['message'] .=$ret;
    	    
    	    
    	    $variables['postlist'][0]['message'] = preg_replace_callback('/\s?\[jzsjiale_daogou_spk\](.*?)\[\/jzsjiale_daogou_spk\]\s?/is', array(
    	        $this,
    	        'getspkshangpin'
    	    ), $variables['postlist'][0]['message']);
    	     
    	    $variables['postlist'][0]['message'] .=$ret;
    	    
    	    
    	    
    	    $variables['postlist'][0]['message'] = preg_replace_callback('/\s?\[jzsjiale_taobaoke\](.*?)\[\/jzsjiale_taobaoke\]\s?/is', array(
    	        $this,
    	        'gettaobaokejianrong'
    	    ), $variables['postlist'][0]['message']);
    	     
    	    //$variables['postlist'][0]['message'] .= "<link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/mobiletbkitem.css\" type=\"text/css\" />";
    	    
    	    $variables['postlist'][0]['message'] .=$ret;
	    
	    }
	    */
	    
	    foreach ($variables['postlist'] as $key=>$value) {
	        if (strpos($variables['postlist'][$key]['message'], '[/jzsjiale_daogou]') == true || strpos($variables['postlist'][$key]['message'], '[/jzsjiale_daogou_spk]') == true || strpos($variables['postlist'][$key]['message'], '[/jzsjiale_taobaoke]') == true) {
	             
	            $variables['postlist'][$key]['message'] = preg_replace_callback('/\s?\[jzsjiale_daogou\](.*?)\[\/jzsjiale_daogou\]\s?/is', array(
	                $this,
	                'gettaobaoke'
	            ), $variables['postlist'][$key]['message']);
	            
	            $variables['postlist'][$key]['message'] .=$ret;
	            	
	            	
	            $variables['postlist'][$key]['message'] = preg_replace_callback('/\s?\[jzsjiale_daogou_spk\](.*?)\[\/jzsjiale_daogou_spk\]\s?/is', array(
	                $this,
	                'getspkshangpin'
	            ), $variables['postlist'][$key]['message']);
	        
	            $variables['postlist'][$key]['message'] .=$ret;
	            	
	            	
	            	
	            $variables['postlist'][$key]['message'] = preg_replace_callback('/\s?\[jzsjiale_taobaoke\](.*?)\[\/jzsjiale_taobaoke\]\s?/is', array(
	                $this,
	                'gettaobaokejianrong'
	            ), $variables['postlist'][$key]['message']);

	            $variables['postlist'][$key]['message'] .=$ret;
	             
	        }
	    }
	    /////////////////////////////////////////////
	   
	    
	    if (! $_config['g_issuiji']) {
	        return;
	    }
	    
	    if (! $_config['g_yxfids']) {
	        return;
	    }
	    if (! $_config['g_yxgroups']) {
	        return;
	    }
	     
	    $pid = $_G['forum_firstpid'];
	    if (empty($pid)) {
	        return;
	    }
	     
	    $tid = $_GET['tid'];
	    if (empty($tid)) {
	        return;
	    }
	     
	    $fid = $_G['fid'];
	    if (empty($fid)) {
	        return;
	    }
	     
	    $groupid = $_G['groupid'];
	    if (empty($groupid)) {
	        return;
	    }
	     
	    $uid = $_G['uid'];
	    
	    
	    
	    $basescript = $_G['basescript'];
	    $curm = CURMODULE;
	    
	    $suijigeshu = 1;
	    if (! $_config['g_suijigeshu']) {
	        $suijigeshu = 1;
	    }else{
	        $suijigeshu = $_config['g_suijigeshu'];
	    }
	    
	    
	    if ($basescript == "forum" ) {
	      
	        if ($curm == "viewthread") {
	    


	            $mianuids = array();
	            
	            if (!empty($_config['g_mianuid'])) {
	                $mianuids = explode(',',trim($_config['g_mianuid']));
	            
	                if(in_array($uid,$mianuids)){
	                    return;
	                }
	            }
	            
	            $miantids = array();
	            
	            if (!empty($_config['g_miantid'])) {
	                $miantids = explode(',',trim($_config['g_miantid']));
	            
	                if(in_array($tid,$miantids)){
	                    return;
	                }
	            }
	            
	            if (in_array($fid,(array)unserialize($_config['g_yxfids'])) && in_array ( $groupid, (array)unserialize($_config['g_yxgroups']) )){
	                 
	                //20161222 start
                $ok_suijicategory = "";
                //cache start
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                
                    $ok_suijicategory = $tbkcategory;
                
                }else{
                    $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
                
                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));
                
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                    $ok_suijicategory = $tbkcategory;
                
                }
                //cache end
                $suijicategorylist = array();
                foreach ($ok_suijicategory as $suijidata){
                    if(in_array($fid,json_decode($suijidata['fids']))){
                        $suijicategorylist[] = $suijidata['id'];
                    }
                }
                
                 
                $utils = new Utils();
                //cache start
                    /*
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php';
                    
                    $allokshangpin = array();
                    foreach ($suijicategorylist as $sjdata){
                        $okshangpin = $utils->search($sjdata,'categoryid',$tbkshangpin);
                        if(!empty($okshangpin) && $okshangpin != null){
                            $allokshangpin = array_merge($allokshangpin, $okshangpin);
                        }
                        
                    }
                    
                    $this->cacheshangpin = $allokshangpin;
                
                }else{
                    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();
    
                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
                
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php';
                    
                    $allokshangpin = array();
                    foreach ($suijicategorylist as $sjdata){
                        $okshangpin = $utils->search($sjdata,'categoryid',$tbkshangpin);
                        if(!empty($okshangpin) && $okshangpin != null){
                            $allokshangpin = array_merge($allokshangpin, $okshangpin);
                        }
                        
                    }
                    
                    $this->cacheshangpin = $allokshangpin;
                }
                    */
                    //20190329 add

                    $allokshangpin = array();
                    foreach ($suijicategorylist as $sjdata){
                        if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php')){
                            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                            $tbkshangpin = ${'tbkshangpin_'.$sjdata};

                        }else{
                            $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $sjdata);

                            require_once libfile('function/cache');
                            writetocache('jzsjiale_daogou_shangpin_'.$sjdata, getcachevars(array('tbkshangpin_'.$sjdata => $shangpin_cache_tmp)));

                            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                            $tbkshangpin = ${'tbkshangpin_'.$sjdata};

                        }

                        if(!empty($tbkshangpin) && $tbkshangpin != null){
                            $allokshangpin = array_merge($allokshangpin, $tbkshangpin);
                        }
                        $this->cacheshangpin = $allokshangpin;
                    }
                //cache end
                //20161222 over
	            
	                $spcount = count($this->cacheshangpin);
	            
	                if($spcount <= 0){
	                    return;
	                }
	          
	            
	                if($spcount <= $suijigeshu){
	                    $suijigeshu = $spcount;
	                }
	                
	            
	                if ($_config['g_wsqwei']) {
	            
    	                $spweiid = array_rand($this->cacheshangpin,$suijigeshu);
                  
                        $spweiformat = "";
                        
                        if($suijigeshu == 1){
                            $spwei = $this->cacheshangpin[$spweiid];
                            $spweiformat .= $this->getshangpin($spwei);
                        }else{
                            for($i=0;$i<$suijigeshu;$i++){
                                $spwei = $this->cacheshangpin[$spweiid[$i]];
                                $spweiformat .= $this->getshangpin($spwei);
                            } 
                        }
	            
	            
	                    $variables['postlist'][0]['message'] .= '<br/>'. $spweiformat ;
	                }
	            
	            }else{
	                return;
	            }
	            
	            
	            
	        }
	    }
	    
	    
	    
	    
	    return;
	}
	
	
	
	function getshangpin($shangpin)
	{
	    global $_G;
	    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
	
	    $tbk_title = $shangpin['title'];
	    $tbk_imgurl = $shangpin['img'];
	    $tbk_url = $shangpin['url'];
	    $tbk_yuanjia = $shangpin['yuanjia'];
	
	    $isyuanjia = true;
	    if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == ""){
	        $isyuanjia = false;
	    }
	
	    $tbk_xianjia = $shangpin['xianjia'];
	
	    $tbk_youhuiquanurl = $shangpin['youhuiquan'];
	    $tbk_myouhuitips = $_config['g_myouhuitips'];
	
	    $isshowyhk = false;
	    if(!empty($shangpin['youhuiquan'])){
	        $isshowyhk = true;
	    }
	
	    $tbkstyle = $_config['g_wsqstyle'];
        if(empty($tbkstyle)){
            $tbkstyle = "wsq1";
        }
        
        
        $tbk_tkl = $shangpin['tkl'];
        
        
        if($_config['g_iswsqtkl']){

            $tbappkey = $_config['g_appkey'];
            $tbsecretKey = $_config['g_appsecret'];
            //$webbianma = $_config['g_bianma'];
            $webbianma = $_G['charset'];
            
            
            $g_tklguoqishijian = $_config['g_tklguoqishijian'];
            $hourtime = strtotime("-".($g_tklguoqishijian*24)." hour");
        
            if(empty($tbk_tkl) || $shangpin['tkldateline'] <= $hourtime){
                $gtkl = new GetTbAPI;
                $gtkl->__construct($tbappkey, $tbsecretKey);
                $tbktkl =  $gtkl->gettkl($tbk_title,$tbk_url,$tbk_imgurl,$webbianma);
                
                $tbktkl = json_decode($tbktkl);
                if($webbianma == "gbk"){
                    $tbktkl = diconv($tbktkl->model,'UTF-8','GB2312');
                }else{
                    $tbktkl = $tbktkl->model;
                }
                
                if($g_tklguoqishijian>0){
                    $dsp = array('tkldateline'=>TIMESTAMP);
                    $dsp['tkl'] = $tbktkl;
                
                    C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->update($shangpin['id'],$dsp);

                    /*
                    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();
                
                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
                    */
                    $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $shangpin['categoryid']);

                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_shangpin_'.$shangpin['categoryid'], getcachevars(array('tbkshangpin_'.$shangpin['categoryid'] => $shangpin_cache_tmp)));

                }
            }else{
                $tbktkl = $tbk_tkl;
            }
            
            
            
            $tkltips = $_config['g_tkltips'];
            
            if(!empty($tbktkl)){
                $tbkstyle = $_config['g_wsqtklstyle'];
                if(empty($tbkstyle)){
                    $tbkstyle = "taokouling";
                }
            }
            
        }else{
            if(!empty($tbk_tkl)){
                $tbktkl = $tbk_tkl;
                
                $tkltips = $_config['g_tkltips'];
                
                if(!empty($tbktkl)){
                    $tbkstyle = $_config['g_wsqtklstyle'];
                    if(empty($tbkstyle)){
                        $tbkstyle = "taokouling";
                    }
                }
            }
                
        }
	
        $g_isopenzhtglj = $_config['g_isopenzhtglj'];
        $numiid = $shangpin['numiid'];
        
	    $tbk_goumai = $_config['g_goumai'];
	    $tbk_youhuiquan = $_config['g_youhuiquan'];
	
	    $isnofollow = true;
	    $isnofollow = $_config['g_isnofollow'];
	
	    if($_config['g_spneilian']){
	        $tbk_url = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$shangpin['id'];
	        $tbk_youhuiquanurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$shangpin['id'];
	    }
	    
	    include template('jzsjiale_daogou:'.$tbkstyle);
	    return trim($return);
	}


}