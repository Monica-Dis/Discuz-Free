<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
global $_G, $lang;

require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';

if(!in_array($act, array('list', 'cache', 'qingchu','shezhibankuai'))) {
    $act = 'list';
}

if($act=='qingchu'){
	$categoryid = dintval($_GET['categoryid']);
	$setting = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->fetch($categoryid);
	if(empty($setting))
		cpmsg('jzsjiale_daogou:empty', '', 'error');
	if(submitcheck('submit')){
		C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->deletebycategoryid($categoryid);
		recache();
		recacheshangpin(false,$categoryid);
		cpmsg('jzsjiale_daogou:delok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category', 'succeed');
	}
	cpmsg('jzsjiale_daogou:delcategorydata','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=qingchu&categoryid='.$categoryid.'&submit=yes','form',array('title' => $setting['title']));
}elseif($act=='cache'){
    
            $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
    
            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));
            
            if(count($tbkcategory) > 0){
                cpmsg('jzsjiale_daogou:cache_success', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category', 'succeed');
            }else{
                cpmsg('jzsjiale_daogou:cache_error', '', 'error');
            }
            
        
        dexit();
}elseif($act=='shezhibankuai'){
	$categoryid = dintval($_GET['categoryid']);
	$category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->fetch($categoryid);
	if(empty($category))
		cpmsg('jzsjiale_daogou:emptyspcategory', '', 'error');
	if(submitcheck('submit')){
	    $categoryop = $_GET['categoryop'];
		$dsp = array('dateline'=>TIMESTAMP);
		$dsp['fids'] =  json_encode($categoryop['fids']);
		$dsp['catids'] =  json_encode($categoryop['catids']);
		$dsp['groups'] =  json_encode($categoryop['groups']);
		$dsp['daogou'] =  json_encode($categoryop['daogou']);
		
		if(C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->update($categoryid,$dsp)){
		    recache();
			cpmsg('jzsjiale_daogou:editok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category', 'succeed');
		}else{
			cpmsg('jzsjiale_daogou:error', '', 'error');
		}
		
	
	
	}
	echo '<div class="colorbox"><h4>'.plang('aboutshezhibankuai').'</h4>'.
		 '<table cellspacing="0" cellpadding="3"><tr>'.
	     '<td valign="top">'.plang('shezhibankuaidescription').'</td></tr></table>'.
		 '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

	
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=shezhibankuai', 'enctype');
	
	showsubmit('submit', 'submit');
	
	echo'<input type="hidden" value="'.$category['id'].'" name="categoryid"/>';
	showtableheader(plang('wei').'<span style="color:red;">['.$category['title'].']</span> '.plang('shezhiyunxusuijibankuai'), '');
	
    $utils = new Utils();
		$forumsetting = $utils->getsetting();
		if(is_array($forumsetting)) {
			foreach($forumsetting as $settingvar => $setting) {
				if(!empty($setting['value']) && is_array($setting['value'])) {
					foreach($setting['value'] as $k => $v) {
						$setting['value'][$k][1] = plang($setting['value'][$k][1]);
					}
				}
				$varname = in_array($setting['type'], array('mradio', 'mcheckbox', 'select', 'mselect')) ?
				($setting['type'] == 'mselect' ? array('categoryop['.$settingvar.'][]', $setting['value']) : array('categoryop['.$settingvar.']', $setting['value']))
				: 'categoryop['.$settingvar.']';
				$value = json_decode($category[$settingvar]) != '' ? json_decode($category[$settingvar]) : $setting['default'];
				$comment = plang($setting['comment']);
				showsetting(plang($setting['title']).':', $varname, $value, $setting['type'], '', 0, $comment);
			}
		}
	
	showsubmit('submit', 'submit');
	showtablefooter(); /*Dism��taobao��com*/
	showformfooter(); /*Dism_taobao_com*/
	dexit();
}elseif($act=='list'){
	if(submitcheck('submit')){
	    
	    $newforum = $_GET['newforum'];
	    $neworder = $_GET['neworder'];
	    $neworderlevel = $_GET['neworderlevel'];
	    if(is_array($newforum)) {
	        foreach($newforum as $fup => $forums) {
	            	
	            $forum = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->fetch($fup);
	            foreach($forums as $key => $forumname) {
	    
	                if(empty($forumname)) {
	                    continue;
	                }
	                $forumfields = array();
	                $forumfields['title'] = $forumname;
	                $forumfields['pid'] = $forum['id'];
	                $forumfields['keywords'] = '';
	                $forumfields['description'] = '';
	                $forumfields['status'] = 1;
	                $forumfields['sort'] = $neworder[$fup][$key];
	                $forumfields['level'] = $neworderlevel[$fup][$key];
	                $forumfields['dateline'] = TIMESTAMP;
	                C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->insert($forumfields);
	                	
	            }
	        }
	    }
	    
	   if(is_array($_GET['groupnamenewadd'])) {
			foreach($_GET['groupnamenewadd'] as $k => $v) {
				if($v) {
					$setarr = array(
						'title' => $v,
						'sort' => $_GET['groupordernewadd'][$k],
					    'status' => '1',
					    'level' => $_GET['groupordernewaddlevel'][$k],
						'dateline' => TIMESTAMP
					);
					C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->insert($setarr);
				}
			}
		}
		
	
		if(is_array($_GET['group_title'])) {
		    foreach($_GET['group_title'] as $id => $title) {
		        if(!$_GET['delete'][$id]) {
		            $setarr = array(
		                'title' => $_GET['group_title'][$id],
		                'sort' => $_GET['group_order'][$id],
		                'img' => $_GET['group_img'][$id],
		                'color' => $_GET['group_color'][$id],
		                'level' => $_GET['group_level'][$id],
		                'status' => intval($_GET['group_status'][$id]),
		                'dateline' => TIMESTAMP
		            );
		            C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->update($id,$setarr);
		        }
		    }
		    	
		}
		
		if($_GET['delete']) {
		    C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->delete($_GET['delete']);
		    C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->delete3bycategoryid(dimplode($_GET['delete']));
		    C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->deletebycategoryid(dimplode($_GET['delete']));
		}
	
		    recache();
		    cpmsg('jzsjiale_daogou:ok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=list', 'succeed');
		
	}else{
	    echo '<div class="colorbox"><h4>'.plang('aboutcategory').'</h4>'.
	        '<table cellspacing="0" cellpadding="3"><tr>'.
	        '<td valign="top">'.plang('categorydescription').'</td></tr></table>'.
	        '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';
	    
        $wutuimg = "source/plugin/jzsjiale_daogou/static/images/tp.png";
	    ?>
<script type="text/JavaScript">
	    		    var rowtypedata = [
	    		          [
	    		              [1,''],
	    		              [1,'<input type="text" class="txt" name="groupordernewadd[]" value="0"><input type="hidden" class="txt" name="groupordernewaddlevel[]" value="1">', 'td25'],
	    		              [1,'<div><input type="text" class="txt" name="groupnamenewadd[]"><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php cplang('delete', null, true);?></a></div>', '']
	    		          ],
	    		          [
	    		               [1,''],
	    		               [1,'<input type="text" class="txt" name="neworder[{1}][]" value="0" /><input type="hidden" class="txt" name="neworderlevel[{1}][]" value="2">', 'td25'],
	    		               [1, '<div class="board" ><input name="newforum[{1}][]" value="<?php echo plang("newsubcate");?>" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php cplang('delete', null, true);?></a></div>', '']
	    		          ],
	    		          [
	    		               [1, ''],
	    		               [1,'<input type="text" class="txt" name="neworder[{1}][]" value="0" /><input type="hidden" class="txt" name="neworderlevel[{1}][]" value="3">', 'td25'], 
	    		               [5, '<div class="childboard"><input name="newforum[{1}][]" value="<?php cplang('forums_admin_add_forum_name', null, true);?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php cplang('delete', null, true);?></a></div>']
	    		          ],
	    		    ];
	    		    </script>
<?php
	    		    
	    		    
		//showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=list', 'enctype');

        
        
        showtableheader(plang('lecategory').'(  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=cache" style="color:red;">'.plang('cachecategory').'</a>  )', 'nobottom');
		showsubtitle(plang('lecategorytitle'));
		showtablefooter(); /*Dism��taobao��com*/
		
		//----xinzeng dingji  start
		showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=jzsjiale_daogou&pmod=category&act=list', 'enctype');
		
		showtableheader('<span style="color:red;">' . plang('zengjiadingjifenlei') . '</span>', 'nobottom');
		
		echo '<tr><td>&nbsp;</td><td colspan="5"><div><a href="###" onclick="addrow(this, 0)" class="addtr">' . plang('addcate') . '</a></div></td></tr>';
		showsubmit('submit', 'submit', 'td', '<span style="color:red;">(' . plang('zengjiadingjifenlei') . ')</span>');
		showtablefooter(); /*Dism��taobao��com*/
		showformfooter(); /*Dism_taobao_com*/
		//----xinzeng dingji  end
		
		echo '
<script type="text/javascript">
	function categoryagrouphide(categroupid) {
         document.getElementById("categorya_group_show_"+categroupid).style.display="";
         document.getElementById("categorya_group_hide_"+categroupid).style.display="none";
         var controls = document.getElementsByName("category_"+categroupid+"_group");

         for(var i=0;i<controls.length;i++)
         {
            controls[i].style.display="none";
         }
	}
    function categoryagroupshow(categroupid) {
         document.getElementById("categorya_group_show_"+categroupid).style.display="none";
         document.getElementById("categorya_group_hide_"+categroupid).style.display="";
         var controls = document.getElementsByName("category_"+categroupid+"_group");

         for(var i=0;i<controls.length;i++)
         {
            controls[i].style.display="";
         }
	}
</script>';
		
		$category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid(0);
		foreach($category as $group) {
		    //NEW
		    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=list', 'enctype');
		    
		    showtableheader('<a href="javascript:;" id="categorya_group_show_'.$group['id'].'" onclick="categoryagroupshow('.$group['id'].')">'.plang('zhankai').'</a><a href="javascript:;" id="categorya_group_hide_'.$group['id'].'" style="display:none;" onclick="categoryagrouphide('.$group['id'].')">'.plang('shouqi').'</a>&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:red;">'.$group[title].'</span>&nbsp;--&nbsp;'.plang('lecategoryzi'), 'nobottom');
		    
		    
			$count =  C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->count_by_categoryid($group['id']);
			$statusstr = $group[status]==1 ? ' checked="checked"':'';
			showtablerow('name="category_'.$group['id'].'_group" style="display:none;"', array('', 'class="td25"', '', 'class="td25" style="width:150px;"'), array(
						"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[$group[id]]\" value=\"$group[id]\">$group[id]<input type=\"hidden\"  name=\"group_level[$group[id]]\" value=\"$group[level]\">",
						"<input type=\"text\" class=\"txt\" name=\"group_order[$group[id]]\" value=\"$group[sort]\">",					
						"<input type=\"text\" class=\"txt\" name=\"group_title[$group[id]]\" value=\"$group[title]\">",
						"<img src=\"".($group[img]?$group[img]:$wutuimg)."\" id=\"img".$group[id]."\" width=\"40px\" height=\"40px\" align=\"absmiddle\" style=\"margin-right:3px;float:left\"/><input class=\"txt\" type=\"text\" id=\"url".$group['id']."\" name=\"group_img[".$group['id']."]\" readonly=\"readonly\" value=\"".$group[img]."\"  style=\"margin-right:3px;float:left;vertical-align:middle;\"/> <input type=\"button\" id=\"image".$group['id']."\" value=\"".plang('uploadimage')."\" style=\"margin-right:3px;float:left;vertical-align:middle;\"/>",
			            "<input id=\"c2".$group['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"group_color[$group[id]]\" value=\"$group[color]\" onchange=\"updatecolorpreview('c2".$group['id']."')\"/><input id=\"c2".$group['id']."\" onclick=\"c2".$group['id']."_frame.location='static/image/admincp/getcolor.htm?c2".$group['id']."|c2".$group['id']."_v';showMenu({'ctrlid':'c2".$group['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:$group[color]\"><span id=\"c2".$group['id']."_menu\" style=\"display: none\"><iframe name=\"c2".$group['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
						"<input type=\"checkbox\"  size=\"12\" name=\"group_status[$group[id]]\" value=\"1\" $statusstr>",
						$count,
						dgmdate($group['dateline']),
						'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=shezhibankuai&categoryid='.$group['id'].'" style="'.(($group['fids'] && $group['fids'] != 'null') || ($group['catids'] && $group['catids'] != 'null') || ($group['groups'] && $group['groups'] != 'null') || ($group['daogou'] && $group['daogou'] != 'null')?"color:green;":"color:red;").'">'.plang('shezhibankuai').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&categoryid='.$group['id'].'">'.plang('viewshangpin').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=qingchu&categoryid='.$group['id'].'">'.plang('qingchushangpin').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=createtklbycategory&formhash='.FORMHASH.'&categoryid='.$group['id'].'">'.plang('tklcategory').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=qingchutklcategory&formhash='.FORMHASH.'&categoryid='.$group['id'].'">'.plang('qingchutklcategory').'</a>'
					));
			
			$editorjs ='K(\'#image'.$group['id'].'\').click(function() {
					editor'.$group['id'].'.loadPlugin(\'image\', function() {
						editor'.$group['id'].'.plugin.imageDialog({
							imageUrl : K(\'#url'.$group['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$group['id'].'\').val(url);
								K(\'#img'.$group['id'].'\').attr(\'src\',url);
								editor'.$group['id'].'.hideDialog();
							}
						});
					});
				});';
			
			echo '
<link rel="stylesheet" href="source/plugin/jzsjiale_daogou/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/jzsjiale_daogou/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/jzsjiale_daogou/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var editor'.$group['id'].' = K.editor({
					uploadJson : \'source/plugin/jzsjiale_daogou/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/jzsjiale_daogou/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$editorjs.'
			});
</script>';
		   $subcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($group[id]);
		   foreach($subcategory as $subgroup) {
		   
			   $subcount = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->count_by_categoryid($subgroup['id']);
			   $substatusstr = $subgroup[status]==1 ? ' checked="checked"':'';		   
			   showtablerow('name="category_'.$group['id'].'_group" style="display:none;"', array('', 'class="td25"', '', 'class="td25"'), array(
							"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[$subgroup[id]]\" value=\"$subgroup[id]\">$subgroup[id]<input type=\"hidden\" name=\"group_level[$subgroup[id]]\" value=\"$subgroup[level]\">",
							"<input type=\"text\" class=\"txt\" name=\"group_order[$subgroup[id]]\" value=\"$subgroup[sort]\">",					
							"<div class=\"board\"><input type=\"text\" class=\"txt\"  name=\"group_title[$subgroup[id]]\" value=\"$subgroup[title]\"><a href=\"###\" onclick=\"addrowdirect = 1;addrow(this, 2, '$subgroup[id]')\" class=\"addchildboard\">".plang('addsubcate')."</a></div>",
							"<img src=\"".($subgroup[img]?$subgroup[img]:$wutuimg)."\" id=\"img".$subgroup[id]."\" width=\"40px\" height=\"40px\" align=\"absmiddle\" style=\"margin-right:3px;float:left\"/><input class=\"txt\" type=\"text\" id=\"url".$subgroup['id']."\" name=\"group_img[".$subgroup['id']."]\" readonly=\"readonly\" value=\"".$subgroup[img]."\"  style=\"margin-right:3px;float:left;vertical-align:middle;\"/> <input type=\"button\" id=\"image".$subgroup['id']."\" value=\"".plang('uploadimage')."\" style=\"margin-right:3px;float:left;vertical-align:middle;\"/>",
			               "<input id=\"c2".$subgroup['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"group_color[$subgroup[id]]\" value=\"$subgroup[color]\" onchange=\"updatecolorpreview('c2".$subgroup['id']."')\"/><input id=\"c2".$subgroup['id']."\" onclick=\"c2".$subgroup['id']."_frame.location='static/image/admincp/getcolor.htm?c2".$subgroup['id']."|c2".$subgroup['id']."_v';showMenu({'ctrlid':'c2".$subgroup['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:$subgroup[color]\"><span id=\"c2".$subgroup['id']."_menu\" style=\"display: none\"><iframe name=\"c2".$subgroup['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
						   "<input type=\"checkbox\"  size=\"12\" name=\"group_status[$subgroup[id]]\" value=\"1\" $substatusstr>",
						    $subcount,
			                dgmdate($subgroup['dateline']),
							'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=shezhibankuai&categoryid='.$subgroup['id'].'" style="'.(($subgroup['fids'] && $subgroup['fids'] != 'null') || ($subgroup['catids'] && $subgroup['catids'] != 'null') || ($subgroup['groups'] && $subgroup['groups'] != 'null') || ($subgroup['daogou'] && $subgroup['daogou'] != 'null')?"color:green;":"color:red;").'">'.plang('shezhibankuai').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&categoryid='.$subgroup['id'].'">'.plang('viewshangpin').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=qingchu&categoryid='.$subgroup['id'].'">'.plang('qingchushangpin').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=createtklbycategory&formhash='.FORMHASH.'&categoryid='.$subgroup['id'].'">'.plang('tklcategory').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=qingchutklcategory&formhash='.FORMHASH.'&categoryid='.$subgroup['id'].'">'.plang('qingchutklcategory').'</a>'
						));  
						 
			   $subeditorjs ='K(\'#image'.$subgroup['id'].'\').click(function() {
					subeditor'.$subgroup['id'].'.loadPlugin(\'image\', function() {
						subeditor'.$subgroup['id'].'.plugin.imageDialog({
							imageUrl : K(\'#url'.$subgroup['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$subgroup['id'].'\').val(url);
								K(\'#img'.$subgroup['id'].'\').attr(\'src\',url);
								subeditor'.$subgroup['id'].'.hideDialog();
							}
						});
					});
				});';
			   	
			   echo '
<link rel="stylesheet" href="source/plugin/jzsjiale_daogou/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/jzsjiale_daogou/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/jzsjiale_daogou/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var subeditor'.$subgroup['id'].' = K.editor({
					uploadJson : \'source/plugin/jzsjiale_daogou/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/jzsjiale_daogou/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$subeditorjs.'
			});
</script>';
			   
			   //=====start sub3
			  
			   $sub3category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($subgroup[id]);
			   foreach($sub3category as $sub3group) {
			      
			        $sub3count = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->count_by_categoryid($sub3group['id']);
			      $sub3statusstr = $sub3group[status]==1 ? ' checked="checked"':'';
			       showtablerow('name="category_'.$group['id'].'_group" style="display:none;"', array('', 'class="td25"', '', 'class="td25"'), array(
			           "<input class=\"checkbox\" type=\"checkbox\" name=\"delete[$sub3group[id]]\" value=\"$sub3group[id]\">$sub3group[id]<input type=\"hidden\" name=\"group_level[$sub3group[id]]\" value=\"$sub3group[level]\">",
			           "<input type=\"text\" class=\"txt\" name=\"group_order[$sub3group[id]]\" value=\"$sub3group[sort]\">",
			           "<div class=\"childboard\"><input type=\"text\" class=\"txt\"  name=\"group_title[$sub3group[id]]\" value=\"$sub3group[title]\"></div>",
			           "<img src=\"".($sub3group[img]?$sub3group[img]:$wutuimg)."\" id=\"img".$sub3group[id]."\" width=\"40px\" height=\"40px\" align=\"absmiddle\" style=\"margin-right:3px;float:left\"/><input class=\"txt\" type=\"text\" id=\"url".$sub3group['id']."\" name=\"group_img[".$sub3group['id']."]\" readonly=\"readonly\" value=\"".$sub3group[img]."\"  style=\"margin-right:3px;float:left;vertical-align:middle;\"/> <input type=\"button\" id=\"image".$sub3group['id']."\" value=\"".plang('uploadimage')."\" style=\"margin-right:3px;float:left;vertical-align:middle;\"/>",
			           "<input id=\"c2".$sub3group['id']."_v\" type=\"text\" class=\"txt\" style=\"width:80px;float:left\" name=\"group_color[$sub3group[id]]\" value=\"$sub3group[color]\" onchange=\"updatecolorpreview('c2".$sub3group['id']."')\"/><input id=\"c2".$sub3group['id']."\" onclick=\"c2".$sub3group['id']."_frame.location='static/image/admincp/getcolor.htm?c2".$sub3group['id']."|c2".$sub3group['id']."_v';showMenu({'ctrlid':'c2".$sub3group['id']."'})\" type=\"button\" class=\"colorwd\" value=\"\" style=\"background:$sub3group[color]\"><span id=\"c2".$sub3group['id']."_menu\" style=\"display: none\"><iframe name=\"c2".$sub3group['id']."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			           "<input type=\"checkbox\"  size=\"12\" name=\"group_status[$sub3group[id]]\" value=\"1\" $sub3statusstr>",
			           $sub3count,
			           dgmdate($sub3group['dateline']),
			           '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=shezhibankuai&categoryid='.$sub3group['id'].'" style="'.(($sub3group['fids'] && $sub3group['fids'] != 'null') || ($sub3group['catids'] && $sub3group['catids'] != 'null') || ($sub3group['groups'] && $sub3group['groups'] != 'null') || ($sub3group['daogou'] && $sub3group['daogou'] != 'null')?"color:green;":"color:red;").'">'.plang('shezhibankuai').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&categoryid='.$sub3group['id'].'">'.plang('viewshangpin').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=qingchu&categoryid='.$sub3group['id'].'">'.plang('qingchushangpin').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=createtklbycategory&formhash='.FORMHASH.'&categoryid='.$sub3group['id'].'">'.plang('tklcategory').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=shangpin&act=qingchutklcategory&formhash='.FORMHASH.'&categoryid='.$sub3group['id'].'">'.plang('qingchutklcategory').'</a>'
			       ));
			       
			       $sub3editorjs ='K(\'#image'.$sub3group['id'].'\').click(function() {
					sub3editor'.$sub3group['id'].'.loadPlugin(\'image\', function() {
						sub3editor'.$sub3group['id'].'.plugin.imageDialog({
							imageUrl : K(\'#url'.$sub3group['id'].'\').val(),
							clickFn : function(url, title, width, height, border, align) {
								K(\'#url'.$sub3group['id'].'\').val(url);
								K(\'#img'.$sub3group['id'].'\').attr(\'src\',url);
								sub3editor'.$sub3group['id'].'.hideDialog();
							}
						});
					});
				});';
			        
			       echo '
<link rel="stylesheet" href="source/plugin/jzsjiale_daogou/kindeditor/themes/default/default.css" />
<script charset="utf-8" src="source/plugin/jzsjiale_daogou/kindeditor/kindeditor-min.js"></script>
<script charset="utf-8" src="source/plugin/jzsjiale_daogou/kindeditor/lang/zh_CN.js"></script>
<script>
	KindEditor.ready(function(K) {
				var sub3editor'.$sub3group['id'].' = K.editor({
					uploadJson : \'source/plugin/jzsjiale_daogou/kindeditor/php/upload_json.php\',
					fileManagerJson : \'source/plugin/jzsjiale_daogou/kindeditor/php/file_manager_json.php\',
					allowFileManager : true
				});
				'.$sub3editorjs.'
			});
</script>';
			       
			       
			   }    
			   
			   
			   //=====end sub3
			   
		   }    
		   echo '<tr><td>&nbsp;</td><td>&nbsp;</td><td><div><a href="###" onclick="addrow(this, 1, '.$group['id'].')" class="addtr">'.plang('addsubcate').'</a></div></td></tr>';
		
		
		   
		   echo '<tr><td>&nbsp;</td><td colspan="5"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.plang('addcate').'</a></div></td></tr>';		
    		showsubmit('submit', 'submit', 'del', '<span style="color:red;">'.plang('jinbaocunquyu1').'</span>&nbsp;&nbsp;<span style="color:blue;">'.$group[title].'</span>&nbsp;&nbsp;<span style="color:red;">'.plang('jinbaocunquyu2').'</span>');
    		showtablefooter(); /*Dism��taobao��com*/
    		showformfooter(); /*Dism_taobao_com*/
		}
		/*
		echo '<tr><td>&nbsp;</td><td colspan="5"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.plang('addcate').'</a></div></td></tr>';		
		showsubmit('submit', 'submit', 'del', '');
		showtablefooter(); /*Dism��taobao��com*/
		showformfooter(); /*Dism_taobao_com*/	
		*/	
		
		//----xinzeng dingji  start
		
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=category&act=list', 'enctype');
		
		showtableheader('<span style="color:red;">'.plang('zengjiadingjifenlei').'</span>', 'nobottom');
		
		echo '<tr><td>&nbsp;</td><td colspan="5"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.plang('addcate').'</a></div></td></tr>';
		showsubmit('submit', 'submit', 'td', '<span style="color:red;">('.plang('zengjiadingjifenlei').')</span>');
		showtablefooter(); /*Dism��taobao��com*/
		showformfooter(); /*Dism_taobao_com*/
		
		//----xinzeng dingji  end
	}
	

}


function plang($str) {
	return lang('plugin/jzsjiale_daogou', $str);
}

function recache() {
    $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
    
    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));

}

function recacheshangpin($isallcategory = true,$categoryid = 0){
    /*
    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();

    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
    */
    //20190329 add
    if($isallcategory){
        $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

        foreach ($category as $key => $value){

            $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1,$value["id"]);

            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));
        }
    }else{
        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $categoryid);

        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_shangpin_'.$categoryid, getcachevars(array('tbkshangpin_'.$categoryid => $shangpin_cache_tmp)));
    }
}
//From: Dism��taobao��com
?>