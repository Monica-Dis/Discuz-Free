function shangpinku(cmd) {
	checkFocus();
	showEditorMenuShangpinku(cmd);
	return;
}

function Trim(str)
{ 
    return str.replace(/(^\s*)|(\s*$)/g, ""); 
}


var global_ctrlid,global_sel;
function showEditorMenuShangpinku(tag, params) {
	var sel, selection;
	var str = '', strdialog = 0, stitle = '',categorystr = ''; 
	var ctrlid = editorid + (params ? '_cst' + params + '_' : '_') + tag;
	
	global_ctrlid = ctrlid;
	
	var menu = $(ctrlid + '_menu');
	var pos = [0, 0];
	var menuwidth = 270;
	var menupos = '43!';
	var menutype = 'menu';

	
	
	if(BROWSER.ie) {
		sel = wysiwyg ? editdoc.selection.createRange() : document.selection.createRange();
		pos = getCaret();
	}

	global_sel = sel;
	
	selection = sel ? (wysiwyg ? sel.htmlText : sel.text) : getSel();


	stitle = '\u4ece\u5546\u54c1\u5e93\u63d2\u5165\u5546\u54c1';
	

	str = '';
	str += '<p class="pbn"><span style="color:red;">\u5546\u54c1\u5e93\u5546\u54c1\u67e5\u8be2\u003a</span>\u0028\u4ece\u5546\u54c1\u5e93\u63d2\u5165\u7684\u5546\u54c1\u53ef\u968f\u540e\u53f0\u5546\u54c1\u4fe1\u606f\u7684\u4fee\u6539\u800c\u6539\u53d8\u0029</p>';
	str += '<p class="pbn">\u9009\u62e9\u5206\u7c7b\u7b5b\u9009:<select name="' + ctrlid + '_param_category"  id="' + ctrlid + '_param_category" class="px" style="width:180px;" onChange="spfanye(\'plugin.php?id=jzsjiale_daogou:api&a=shangpin&categoryid=\'+this.value)"></select><img id="' + ctrlid + '_param_category_loading" src="source/plugin/jzsjiale_daogou/static/images/loading.gif" style="width:20px !important;height:20px !important;padding: 0px!important;line-height: 20px;" />&nbsp;&nbsp;&nbsp;&nbsp;\u6216\u0020\u0020\u0020\u6309\u6807\u9898\u641c\u7d22\u003a<input type="text" id="' + ctrlid + '_param_search" class="px" value="" style="width: 220px;" />&nbsp;&nbsp;&nbsp;&nbsp;<button type="button" id="btnspsearch">\u641c\u0020\u0020\u7d22</button><img id="' + ctrlid + '_param_shangpin_loading" src="source/plugin/jzsjiale_daogou/static/images/loading.gif" style="width:20px !important;height:20px !important;padding: 0px!important;line-height: 20px;display:none;" /></p>';
	str += '<p class="pbn"><span style="color:red;">-----------------------------------------------------------------\u5546\u54c1\u5e93\u5546\u54c1\u533a----------------------------------------------------------------</span></p>';
	str += '<div style="overflow:auto; height:400px; width:664px">';
	str += '<ul id="' + ctrlid + '_param_shangpin_list">';
	str += '</ul>';
	str += '</div>';
	str += '<p ><span id="' + ctrlid + '_param_fanye" style=""></span></p>';
	
	
	
	s = '<style type="text/css">'
	+'.jzsjialespkcss input,.pbn {font:12px/1.5 Tahoma,Helvetica,"SimSun",sans-serif !important;}'
	+'.jzsjialespkcss input {line-height:17px !important;height:17px !important;padding:4px !important;}'
	+'.jzsjialespkcss p{max-width:664px !important;}'
	+'.jzsjialespkcss div.c{max-width:684px !important;padding:0 10px !important;}'
	+'.jzsjialespkcss h3.flb{max-width:664px !important;padding:10px 10px 8px !important;}'
	+'.jzsjialespkcss td.m_c{max-width:664px !important;padding:0px!important;}'
	+'.jzsjialespkcss .pbn select{height:30px !important;padding:0px!important;}'
	+'.jzsjialespkcss ul{margin: 0;padding: 0;list-style: none;}'
	+'.jzsjialespkcss li{margin: 0;padding: 10px;height:120px;display: list-item;text-align: -webkit-match-parent;border-bottom:1px dashed #666666;}'
	+'.jzsjialespkcss a{margin: 0;padding: 0;text-decoration: none;}'
	+'.jzsjialespkcss img{margin: 0;padding: 0;text-decoration: none;border: 0;vertical-align: middle;}'
	+'.jzsjialespkcss .shangpinku_list_content_img {width: 120px;height: 120px;float: left;background-color: #fff;}'
	+'.jzsjialespkcss .shangpinku_list_content_img img{width: 100%;height: 100%;-webkit-transition: all .3s;transition: all .3s;}'
	+'.jzsjialespkcss .shangpinku_list_content_detail {padding-left: 20px;padding-right: 20px;width: 400px;position: relative;float: left;height: 120px;}'
	+'.jzsjialespkcss .shangpinku_list_content_detail h3{font-size:18px;}'
	+'.jzsjialespkcss .shangpinku_list_jiage{padding-top:5px;}'
	+'.jzsjialespkcss .shangpinku_list_charu_img {width: 40px;height: 100px;float: left;}'
	+'.jzsjialespkcss .shangpinku_list_charu_img img{width: 100%;height: 100%;-webkit-transition: all .3s;transition: all .3s;}'
	+'.jzsjialespkcss .sptitle {font-size: 18px;line-height: 30px;max-height: 60px;color: #444;font-weight: 400;overflow: hidden;}'
	+'.jzsjialespkcss .elli{white-space: unset;text-overflow: ellipsis;}'
	+'.jzsjialespkcss .sptitle span {position: relative;top: -2px;display: inline-block;width: 36px;height: 18px;font-size: 12px;color: #fff;text-align: center;line-height: 18px;background-color: #FFA248;margin-right: 5px;}'
	+'.jzsjialespkcss .sptitle i {display: inline-block;width: 18px;height: 18px;line-height: 18px;background: center no-repeat;background-size: 18px 18px;margin-right: 5px;top: 2px;position: relative;}'
	+'.jzsjialespkcss .shangpinku_list_yhq{padding-top:5px;}'
	+'</style>';



	menuwidth = 700;
	menupos = '00';
	menutype = 'win';

	var menu = document.createElement('div');
	menu.id = ctrlid + '_menu';
	menu.style.display = 'none';
	menu.className = 'p_pof upf';
	menu.style.width = menuwidth + 'px';
	if(menupos == '00') {
			menu.className = 'fwinmask jzsjialespkcss';
			s += '<table width="100%" cellpadding="0" cellspacing="0" class="fwin"><tr><td class="t_l"></td><td class="t_c"></td><td class="t_r"></td></tr><tr><td class="m_l">&nbsp;&nbsp;</td><td class="m_c">'
				+ '<h3 class="flb"><em>' + stitle + '</em><span><a onclick="hideMenu(\''+ctrlid + '_menu\', \'win\');return false;" class="flbc" href="javascript:;">\u5173\u95ed</a></span></h3><div class="c">' + str + '</div>'
				+ '<p class="o pns"><button type="button" onclick="spfanye(\'plugin.php?id=jzsjiale_daogou:api&a=shangpin&all=1\');return false;" class="pn pnc"><strong>\u663e\u793a\u5168\u90e8\u5546\u54c1</strong></button>&nbsp;&nbsp;&nbsp;&nbsp;<button type="button" onclick="hideMenu(\''+ctrlid + '_menu\', \'win\');return false;" class="pn pnc"><strong>\u5173\u95ed</strong></button></p>'
				+ '</td><td class="m_r"></td></tr><tr><td class="b_l"></td><td class="b_c"></td><td class="b_r"></td></tr></table>';
		} else {
			s += '<div class="p_opt cl"><span class="y" style="margin:-10px -10px 0 0"><a onclick="hideMenu();return false;" class="flbc" href="javascript:;">\u5173\u95ed</a></span><div>' + str + '</div><div class="pns mtn"><button type="submit" id="' + ctrlid + '_submit" class="pn pnc"><strong>\u63d0\u4ea4</strong></button></div></div>';
		}
	menu.innerHTML = s;
	$(editorid + '_editortoolbar').appendChild(menu);
	showMenu({'ctrlid':ctrlid,'mtype':menutype,'evt':'click','duration':3,'cache':0,'drag':1,'pos':menupos});

	try {
		if($(ctrlid + '_param_1')) {
			$(ctrlid + '_param_1').focus();
		}
	} catch(e) {}
	var objs = menu.getElementsByTagName('*');
	for(var i = 0; i < objs.length; i++) {
		_attachEvent(objs[i], 'keydown', function(e) {
			e = e ? e : event;
			obj = BROWSER.ie ? event.srcElement : e.target;
			if((obj.type == 'text' && e.keyCode == 13) || (obj.type == 'textarea' && e.ctrlKey && e.keyCode == 13)) {
				if($(ctrlid + '_submit') && tag != 'image') $(ctrlid + '_submit').click();
				doane(e);
			} else if(e.keyCode == 27) {
				hideMenu();
				doane(e);
			}
		});
	}
	
	
	
	if($('btnspsearch')) $('btnspsearch').onclick = function() {
		checkFocus();
		
		var searchtitle = Trim($(ctrlid + '_param_search').value);

		if(searchtitle == ""){
			alert("\u8bf7\u8f93\u5165\u5546\u54c1\u5173\u952e\u8bcd!");
			return;
		}
		
		$(ctrlid + '_param_shangpin_loading').style.display = 'block';
		
		searchtitle = encodeURIComponent(searchtitle);
	
		
		var xsearch = new Ajax('JSON');
		xsearch.getJSON('plugin.php?id=jzsjiale_daogou:api&a=shangpin&status=1&title='+searchtitle, function(ssearch){
	
			if(ssearch && ssearch.message) {
				if(ssearch.message.code == 200) {
					var ssearchdata = ssearch.message.data;
					var spkli = "";
					
					var countsp = 0;
					for (var keysearch in ssearchdata) {
						spkli += '<li>';
						spkli += '<div class="shangpinku_list_content_img">';
						spkli += '<a href="'+ssearchdata[keysearch].url+'" target="_blank" title="'+ssearchdata[keysearch].title+'" >';
						spkli += '<img src="'+ssearchdata[keysearch].img+'" alt="'+ssearchdata[keysearch].title+'"> ';
						spkli += '</a>';
						spkli += '</div>';
						spkli += '<div class="shangpinku_list_content_detail">';
						spkli += '<h1 class="sptitle elli">';
						if(ssearchdata[keysearch].freeshipment){
							spkli += '<span>\u5305\u90ae</span>';
						}
						if(ssearchdata[keysearch].platform && ssearchdata[keysearch].platform != 'none'){
							let platformimg = "/source/plugin/jzsjiale_daogou/static/images/platform/"+ssearchdata[keysearch].platform+".png";
							spkli += '<i style="background-image: url('+platformimg+');"></i>';
						}
						spkli += '<a href="'+ssearchdata[keysearch].url+'" target="_blank" title="'+ssearchdata[keysearch].title+'" >';
						spkli += ssearchdata[keysearch].title;
						spkli += '</a>';
						spkli += '</h1>';
						if(ssearchdata[keysearch].xianjia && ssearchdata[keysearch].youhuiquan && ssearchdata[keysearch].couponstartfee && ssearchdata[keysearch].couponamount){
							let tbk_youxiaoqi = ssearchdata[keysearch].couponendtime?(ssearchdata[keysearch].couponstarttime?ssearchdata[keysearch].couponstarttime+'&nbsp;-&nbsp;'+ssearchdata[keysearch].couponendtime:ssearchdata[keysearch].couponendtime):"";
							spkli += '<div class="shangpinku_list_yhq"><span style="color:red;">\u5238\u9762\u989d\u003a</span><span style="color:red;font-size:18px;">'+ssearchdata[keysearch].couponamount+'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#787878;">\u6709\u6548\u671f\u003a&nbsp;</span><span style="color:#787878;font-size:13px;">'+tbk_youxiaoqi+'</span></div>';
						}
						spkli += '<div class="shangpinku_list_jiage">';
						if(ssearchdata[keysearch].xianjia && ssearchdata[keysearch].youhuiquan && ssearchdata[keysearch].couponstartfee && ssearchdata[keysearch].couponamount){
							let tbk_couponamount = ssearchdata[keysearch].couponamount;
							let tbk_quanhoujia = 0;
							if(tbk_couponamount > 0){
								if(parseFloat(ssearchdata[keysearch].couponstartfee) <= parseFloat(ssearchdata[keysearch].xianjia)){
									tbk_quanhoujia = parseFloat(ssearchdata[keysearch].xianjia - tbk_couponamount).toFixed(2);
								}
							}
							spkli += '<span style="color:blue;">\u5238\u540e\u4ef7\u003a</span><span style="color:blue;font-size:18px;">'+tbk_quanhoujia+'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
						}
						spkli += '<span style="color:red;">\u73b0\u4ef7\u003a</span><span style="color:red;font-size:18px;">'+ssearchdata[keysearch].xianjia+'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:red;">\u539f\u4ef7\u003a</span><del><span style="color:red;font-size:18px;">'+ssearchdata[keysearch].yuanjia+'</span></del>';
						spkli += '</div>';
						spkli += '</div>';
						spkli += '<div class="shangpinku_list_charu_img">';
						spkli += '<a href="javascript:void(0);" onclick="spkcharu('+ssearchdata[keysearch].id+')" title="\u63d2\u5165\u5546\u54c1\u5230\u6b63\u6587\u003a'+ssearchdata[keysearch].title+'" >';
						spkli += '<img src="source/plugin/jzsjiale_daogou/static/images/charu.png" alt="\u63d2\u5165\u5546\u54c1\u5230\u6b63\u6587\u003a'+ssearchdata[keysearch].title+'"> ';
						spkli += '</a>';
						spkli += '</div>';
						spkli += '</li>';

						countsp++;
					}
					
					
					
					if(countsp <= 0){
						alert("\u672a\u627e\u5230\u76f8\u5173\u5546\u54c1\u0021");
					}else{
						$(ctrlid + '_param_shangpin_list').innerHTML=spkli;
						$(ctrlid + '_param_fanye').innerHTML=ssearch.message.fanye;
					}
					
				} else {
					alert("\u672a\u627e\u5230\u76f8\u5173\u5546\u54c1!");
				}
				$(ctrlid + '_param_shangpin_loading').style.display = 'none';
			}
			
			
		});
		
		
	};	
	
	
	
	
	
	//----
	
	
	
	//-----
	var x = new Ajax('JSON');
	x.getJSON('plugin.php?id=jzsjiale_daogou:api&a=category&all=1', function(s){

		if(s && s.message) {
			var categoryoption = "";
			
			if(s.message.code == 200) {
				categoryoption += '<option value="0">--------------\u8bf7\u9009\u62e9--------------</option>';
				
				var s2 = s;
				var s3 = s;
				var sdata = s.message.data;
				
				for (var key in sdata) {
				
				    if(sdata[key].pid == 0){
				    	categoryoption += '<option value="'+sdata[key].id+'">'+sdata[key].title+'</option>';
						
						var sdata2 = s2.message.data;
						for (var key2 in sdata2) {
						    if(sdata2[key2].pid == sdata[key].id){
						    	categoryoption += '<option value="'+sdata2[key2].id+'">&nbsp;&nbsp;&nbsp;&nbsp;'+sdata2[key2].title+'</option>';
								
						    	var sdata3 = s3.message.data;
								for (var key3 in sdata3) {
								    if(sdata3[key3].pid == sdata2[key2].id){
								    	categoryoption += '<option value="'+sdata3[key3].id+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+sdata3[key3].title+'</option>';
										
								    }
								}
						    }
						}
				    }
				}
			} else {
				categoryoption += '<option value="0">--------------\u8bf7\u9009\u62e9--------------</option>';
			
			}
			$(ctrlid + '_param_category').innerHTML=categoryoption;
			$(ctrlid + '_param_category_loading').style.display = 'none';
		}
		
		
	});
	
	//-----
	var xspk = new Ajax('JSON');
	$(ctrlid + '_param_shangpin_loading').style.display = 'block';
	xspk.getJSON('plugin.php?id=jzsjiale_daogou:api&a=shangpin&status=1&all=1', function(sspk){
		
		if(sspk && sspk.message) {
			if(sspk.message.code == 200) {
				var sspkdata = sspk.message.data;
				var spkli = "";
			
				var countsp = 0;
				for (var keyspk in sspkdata) {
					spkli += '<li>';
					spkli += '<div class="shangpinku_list_content_img">';
					spkli += '<a href="'+sspkdata[keyspk].url+'" target="_blank" title="'+sspkdata[keyspk].title+'" >';
					spkli += '<img src="'+sspkdata[keyspk].img+'" alt="'+sspkdata[keyspk].title+'"> ';
					spkli += '</a>';
					spkli += '</div>';
					spkli += '<div class="shangpinku_list_content_detail">';
					spkli += '<h1 class="sptitle elli">';
					if(sspkdata[keyspk].freeshipment){
						spkli += '<span>\u5305\u90ae</span>';
					}
					if(sspkdata[keyspk].platform && sspkdata[keyspk].platform != 'none'){
						let platformimg = "/source/plugin/jzsjiale_daogou/static/images/platform/"+sspkdata[keyspk].platform+".png";
						spkli += '<i style="background-image: url('+platformimg+');"></i>';
					}
					spkli += '<a href="'+sspkdata[keyspk].url+'" target="_blank" title="'+sspkdata[keyspk].title+'" >';
					spkli += sspkdata[keyspk].title;
					spkli += '</a>';
					spkli += '</h1>';
					if(sspkdata[keyspk].xianjia && sspkdata[keyspk].youhuiquan && sspkdata[keyspk].couponstartfee && sspkdata[keyspk].couponamount){
						let tbk_youxiaoqi = sspkdata[keyspk].couponendtime?(sspkdata[keyspk].couponstarttime?sspkdata[keyspk].couponstarttime+'&nbsp;-&nbsp;'+sspkdata[keyspk].couponendtime:sspkdata[keyspk].couponendtime):"";
						spkli += '<div class="shangpinku_list_yhq"><span style="color:red;">\u5238\u9762\u989d\u003a</span><span style="color:red;font-size:18px;">'+sspkdata[keyspk].couponamount+'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#787878;">\u6709\u6548\u671f\u003a&nbsp;</span><span style="color:#787878;font-size:13px;">'+tbk_youxiaoqi+'</span></div>';
					}
					spkli += '<div class="shangpinku_list_jiage">';
					if(sspkdata[keyspk].xianjia && sspkdata[keyspk].youhuiquan && sspkdata[keyspk].couponstartfee && sspkdata[keyspk].couponamount){
						let tbk_couponamount = sspkdata[keyspk].couponamount;
						let tbk_quanhoujia = 0;
						if(tbk_couponamount > 0){
							if(parseFloat(sspkdata[keyspk].couponstartfee) <= parseFloat(sspkdata[keyspk].xianjia)){
								tbk_quanhoujia = parseFloat(sspkdata[keyspk].xianjia - tbk_couponamount).toFixed(2);
							}
						}
						spkli += '<span style="color:blue;">\u5238\u540e\u4ef7\u003a</span><span style="color:blue;font-size:18px;">'+tbk_quanhoujia+'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
					}
					spkli += '<span style="color:red;">\u73b0\u4ef7\u003a</span><span style="color:red;font-size:18px;">'+sspkdata[keyspk].xianjia+'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:red;">\u539f\u4ef7\u003a</span><del><span style="color:red;font-size:18px;">'+sspkdata[keyspk].yuanjia+'</span></del>';
					spkli += '</div>';
					spkli += '</div>';
					spkli += '<div class="shangpinku_list_charu_img">';
					spkli += '<a href="javascript:void(0);" onclick="spkcharu('+sspkdata[keyspk].id+')" title="\u63d2\u5165\u5546\u54c1\u5230\u6b63\u6587\u003a'+sspkdata[keyspk].title+'" >';
					spkli += '<img src="source/plugin/jzsjiale_daogou/static/images/charu.png" alt="\u63d2\u5165\u5546\u54c1\u5230\u6b63\u6587\u003a'+sspkdata[keyspk].title+'"> ';
					spkli += '</a>';
					spkli += '</div>';
					spkli += '</li>';

					countsp++;
				}
				
				
				
				if(countsp <= 0){
					alert("\u672a\u627e\u5230\u76f8\u5173\u5546\u54c1\u0021");
					
				}else{
					$(ctrlid + '_param_shangpin_list').innerHTML=spkli;
					$(ctrlid + '_param_fanye').innerHTML=sspk.message.fanye;
				}
				
			} else {
				alert("\u672a\u627e\u5230\u76f8\u5173\u5546\u54c1!");
			}
			$(ctrlid + '_param_shangpin_loading').style.display = 'none';
		}
		
		
	});
	//--
	
	
	
	
	
		
}

function spfanye(currurl) {
	let xspk = new Ajax('JSON');
	$(global_ctrlid + '_param_shangpin_loading').style.display = 'block';
	xspk.getJSON(currurl, function(sspk){
		
		if(sspk && sspk.message) {
			if(sspk.message.code == 200) {
				let sspkdata = sspk.message.data;
				let spkli = "";

				let countspfy = 0;
				for (let keyspk in sspkdata) {
					spkli += '<li>';
					spkli += '<div class="shangpinku_list_content_img">';
					spkli += '<a href="'+sspkdata[keyspk].url+'" target="_blank" title="'+sspkdata[keyspk].title+'" >';
					spkli += '<img src="'+sspkdata[keyspk].img+'" alt="'+sspkdata[keyspk].title+'"> ';
					spkli += '</a>';
					spkli += '</div>';
					spkli += '<div class="shangpinku_list_content_detail">';
					spkli += '<h1 class="sptitle elli">';
					if(sspkdata[keyspk].freeshipment){
						spkli += '<span>\u5305\u90ae</span>';
					}
					if(sspkdata[keyspk].platform && sspkdata[keyspk].platform != 'none'){
						let platformimg = "/source/plugin/jzsjiale_daogou/static/images/platform/"+sspkdata[keyspk].platform+".png";
						spkli += '<i style="background-image: url('+platformimg+');"></i>';
					}
					spkli += '<a href="'+sspkdata[keyspk].url+'" target="_blank" title="'+sspkdata[keyspk].title+'" >';
					spkli += sspkdata[keyspk].title;
					spkli += '</a>';
					spkli += '</h1>';
					if(sspkdata[keyspk].xianjia && sspkdata[keyspk].youhuiquan && sspkdata[keyspk].couponstartfee && sspkdata[keyspk].couponamount){
						let tbk_youxiaoqi = sspkdata[keyspk].couponendtime?(sspkdata[keyspk].couponstarttime?sspkdata[keyspk].couponstarttime+'&nbsp;-&nbsp;'+sspkdata[keyspk].couponendtime:sspkdata[keyspk].couponendtime):"";
						spkli += '<div class="shangpinku_list_yhq"><span style="color:red;">\u5238\u9762\u989d\u003a</span><span style="color:red;font-size:18px;">'+sspkdata[keyspk].couponamount+'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#787878;">\u6709\u6548\u671f\u003a&nbsp;</span><span style="color:#787878;font-size:13px;">'+tbk_youxiaoqi+'</span></div>';
					}
					spkli += '<div class="shangpinku_list_jiage">';
					if(sspkdata[keyspk].xianjia && sspkdata[keyspk].youhuiquan && sspkdata[keyspk].couponstartfee && sspkdata[keyspk].couponamount){
						let tbk_couponamount = sspkdata[keyspk].couponamount;
						let tbk_quanhoujia = 0;
						if(tbk_couponamount > 0){
							if(parseFloat(sspkdata[keyspk].couponstartfee) <= parseFloat(sspkdata[keyspk].xianjia)){
								tbk_quanhoujia = parseFloat(sspkdata[keyspk].xianjia - tbk_couponamount).toFixed(2);
							}
						}
						spkli += '<span style="color:blue;">\u5238\u540e\u4ef7\u003a</span><span style="color:blue;font-size:18px;">'+tbk_quanhoujia+'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
					}
					spkli += '<span style="color:red;">\u73b0\u4ef7\u003a</span><span style="color:red;font-size:18px;">'+sspkdata[keyspk].xianjia+'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:red;">\u539f\u4ef7\u003a</span><del><span style="color:red;font-size:18px;">'+sspkdata[keyspk].yuanjia+'</span></del>';
					spkli += '</div>';
					spkli += '</div>';
					spkli += '<div class="shangpinku_list_charu_img">';
					spkli += '<a href="javascript:void(0);" onclick="spkcharu('+sspkdata[keyspk].id+')" title="\u63d2\u5165\u5546\u54c1\u5230\u6b63\u6587\u003a'+sspkdata[keyspk].title+'" >';
					spkli += '<img src="source/plugin/jzsjiale_daogou/static/images/charu.png" alt="\u63d2\u5165\u5546\u54c1\u5230\u6b63\u6587\u003a'+sspkdata[keyspk].title+'"> ';
					spkli += '</a>';
					spkli += '</div>';
					spkli += '</li>';

					countspfy++;
				}
			
				if(countspfy <= 0){
					alert("\u672a\u627e\u5230\u76f8\u5173\u5546\u54c1\u0021");
				}else{
					$(global_ctrlid + '_param_shangpin_list').innerHTML=spkli;
					$(global_ctrlid + '_param_fanye').innerHTML=sspk.message.fanye;
				}
				
			} else {
				alert("\u672a\u627e\u5230\u76f8\u5173\u5546\u54c1!");
			}
			$(global_ctrlid + '_param_shangpin_loading').style.display = 'none';
		}
		
		
	});
}

function spkcharu(spid) {
	var opentag = '[jzsjiale_daogou_spk]';
	var closetag = '[/jzsjiale_daogou_spk]';
	
	str = opentag + spid + closetag;
	insertText(str, strlen(opentag), strlen(closetag), false, global_sel);
}