var ArticleUtil = ArticleUtil || {};
ArticleUtil.checkBrowser = function() {
    return "undefined" != typeof JSON && 0 == jq("<textarea></textarea>")[0].selectionStart ? 1 : 0
},
ArticleUtil.config = {
    qiniuHost: "http://localhost",
    defaultProductPic: "source/plugin/jzsjiale_daogou/static/images/daogou/v2/product-default-pic.png",
    scrollToCurrentPosLazy: null,
    canpublish: 1,
    uploadFileCount: 0,
    currentUploadFile: 0
},
ArticleUtil.qiniuUploadInit = function(t, e, i) {
    Qiniu.uploader({
        runtimes: "html5,flash,html4",
        browse_button: t,
        uptoken_url: "/qiniu/uploadToken",
        unique_names: !1,
        save_key: !1,
        domain: "http://pic1.bantangapp.com/",
        max_file_size: e,
        flash_swf_url: "/js/plupload/Moxie.swf",
        filters: {
            mime_types: [{
                title: "\u56fe\u7247\u6587\u4ef6",
                extensions: "jpg,jpeg,png"
            }]
        },
        max_retries: 3,
        dragdrop: !0,
        drop_element: "editor-container",
        chunk_size: "4mb",
        auto_start: !0,
        init: {
            FilesAdded: function(t, e) {
                var i = ArticleUtil.checkImgCount();
                return i >= 30 ? (alert("\u6700\u591a\u6dfb\u52a0\u0033\u0030\u5f20\u56fe\u7247\u002c\u5f53\u524d" + i + "\u5f20"), void t.stop()) : (ArticleUtil.config.uploadFileCount = 1 * e.length, void ArticleUtil.showProgress())
            },
            BeforeUpload: function(t, e) {},
            UploadProgress: function(t, e) {
                ArticleUtil.progresAnimate(e.percent)
            },
            FileUploaded: function(t, e, a) {
                ArticleUtil.config.currentUploadFile++,
                ArticleUtil.config.currentUploadFile == ArticleUtil.config.uploadFileCount && ArticleUtil.closeProgress();
                var r = t.getOption("domain"),
                n = jq.parseJSON(a),
                l = r + n.key;
                jq.ajax({
                    url: "/qiniu/getImageInfo",
                    type: "GET",
                    dataType: "json",
                    data: {
                        imageUrl: l
                    },
                    success: function(t) {
                        1 == t.code && i({
                            url: l + "!w900",
                            width: t.data.width,
                            height: t.data.height
                        })
                    }
                })
            },
            Error: function(t, e, i) {
                switch (e.code) {
                case - 600 : alert("\u56fe\u7247\u4e0a\u4f20\u5927\u5c0f\u9650\u5236\u4e3a\u0031\u0030\u004d");
                    break;
                case - 601 : alert("\u56fe\u7247\u4e0a\u4f20\u4ec5\u652f\u6301\u006a\u0070\u0067\u002c\u006a\u0070\u0065\u0067\u002c\u0070\u006e\u0067\u7c7b\u578b");
                    break;
                default:
                    alert(i)
                }
            },
            UploadComplete: function() {},
            Key: function(t, e) {
                var i = new Date,
                a = i.getFullYear(),
                r = i.getMonth() + 1,
                n = i.getDate();
                r = r >= 10 ? r: "0" + r,
                n = n >= 10 ? n: "0" + n;
                var l = "topic/" + a + r + "/" + n + "/web_" + (new Date).getTime() + "_" + Math.floor(1e5 * Math.random()) + "_" + Math.floor(1e5 * Math.random());
                return l
            }
        }
    })
},
ArticleUtil.progresAnimate = function(t) {
    if (ArticleUtil.config.currentUploadFile != ArticleUtil.config.uploadFileCount) {
        var e = (100 / ArticleUtil.config.uploadFileCount).toFixed(2),
        i = ArticleUtil.config.currentUploadFile * e + e * t / 100;
        jq(".progress-inner").css("width", i + "%"),
        jq(".progress-no span").html(Math.floor(i))
    }
},
ArticleUtil.showProgress = function() {
    jq(".upload-progress-mask").show()
},
ArticleUtil.closeProgress = function() {
    jq(".upload-progress-mask").hide(),
    jq(".progress-inner").css("width", "0%"),
    jq(".progress-no span").html(0),
    ArticleUtil.config.uploadFileCount = 0,
    ArticleUtil.config.currentUploadFile = 0
},
ArticleUtil.getSelectionPos = function(t) {
    var e = 0;
    if (t.selectionStart) e = t.selectionStart;
    else if (event && event.srcElement && event.srcElement.createTextRange) {
        var i;
        "textarea" == t.tagName ? (i = event.srcElement.createTextRange(), i.moveToPoint(event.x, event.y)) : i = document.selection.createRange(),
        i.moveStart("character", -event.srcElement.value.length),
        e = i.text.length
    }
    return e
},
ArticleUtil.setSelectionPos = function(t, e) {
    t.selectionStart && (t.selectionStart = e, t.selectionEnd = e)
},
ArticleUtil.scrollToCurrentPos = function() {
    clearTimeout(ArticleUtil.config.scrollToCurrentPosLazy),
    ArticleUtil.config.scrollToCurrentPosLazy = null,
    ArticleUtil.config.scrollToCurrentPosLazy = setTimeout(function() {
        var t = jq(".current-pos").offset().top + jq(".current-pos").height();
        t < 3 * jq(window).height() / 4 + jq(window).scrollTop() || jq("body").animate({
            scrollTop: t - jq(window).height() / 2
        },
        400)
    },
    500)
},
ArticleUtil.addTxtUnit = function(t, e) {
    var i = '<div class="edit-unit" data-type="2"></div>',
    a = '<textarea class="txt"></textarea>',
    r = jq(a);
    e && r.val(e);
    var n = jq(i).append(r),
    l = n.find(".txt");
    t.hasClass("first-hidden-unit") && l.addClass("cannot-delete"),
    l.on("keydown",
    function(t) {
        var e = jq(this);
        e.css("height", this.scrollHeight + "px");
        var e = jq(this);
        e.css("height", this.scrollHeight + "px");
        var i = t.keyCode;
        if (8 == i) {
            if (e.css("height", e.height() - 24 + "px"), e.trigger("keydown"), !e.val() && !e.hasClass("cannot-delete")) {
                var a = e.parent().prev().find(".txt");
                a.length > 0 && (a.val(a.val() + " "), a.focus(), e.parent().remove())
            }
            if (ArticleUtil.getSelectionPos(e[0]) <= 0 && e.val() && e.parent().prev().find(".txt").length > 0) {
                var r = e.parent().prev().find(".txt"),
                n = r.val().length;
                r.val(r.val() + e.val()).trigger("keydown").focus(),
                ArticleUtil.setSelectionPos(r[0], n),
                e.parent().remove()
            }
        }
    }).on("keyup",
    function(t) {
        var e = jq(this);
        e.css("height", this.scrollHeight + "px");
        var i = t.keyCode;
        if (38 == i) {
            var a = e.parent().prev().find(".txt");
            a.length > 0 && ArticleUtil.getSelectionPos(e[0]) <= 0 && a.focus()
        }
        if (40 == i) {
            var r = e.parent().next().find(".txt");
            r.length > 0 && ArticleUtil.getSelectionPos(e[0]) >= e.val().length && r.focus()
        }
    }).on("keypress",
    function(t) {
        var e = jq(this),
        i = t.keyCode;
        if (13 == i) {
            t.preventDefault();
            var a = ArticleUtil.getSelectionPos(e[0]),
            r = e.val().length;
            if (a >= r) ArticleUtil.addTxtUnit(e.parent());
            else if (a > 0 && r > a) {
                var n = e.val();
                e.val("").css("height", "0"),
                ArticleUtil.addTxtUnit(e.parent(), n.substring(0, a)),
                ArticleUtil.addTxtUnit(e.parent().next(), n.substring(a, r));
                var l = e.parent().next().next().find(".txt");
                l.focus(),
                ArticleUtil.setSelectionPos(l[0], 0),
                e.parent().remove()
            } else ArticleUtil.addTxtUnit(e.parent().prev()),
            e.focus(),
            ArticleUtil.setSelectionPos(e[0], p)
        }
    }).on("focus",
    function() {
        var t = jq(this);
        jq(".current-pos").removeClass("current-pos"),
        t.parent().addClass("current-pos"),
        t.data("interval", setInterval(function() {
            t.trigger("keydown")
        },
        50))
    }).on("blur",
    function() {
        var t = jq(this);
        t.data("interval", null)
    }),
    n.on("click",
    function() {
        l.focus()
    }),
    jq(t).after(n),
    n.find(".txt").focus(),
    jq(".current-pos").removeClass("current-pos"),
    n.addClass("current-pos"),
    ArticleUtil.scrollToCurrentPos()
},
ArticleUtil.addTitle = function(r1,e) {
	var t = jq(".current-pos");
	var a = '<div class="edit-unit" data-type="3"></div>',
    r = jq('<div class="close-btn"><i class="article-icons article-icons-close"></i></div>');
    r.on("click",
    function() {
        confirm("\u786e\u5b9a\u8981\u5220\u9664\u8fd9\u4e2a\u6807\u9898\u5417\u003f") && jq(this).parent().hide(200,
        function() {
            jq(this).remove()
        })
    });
    s = jq('<p class="h1title"><input maxlength="50" type="text" placeholder="\u8bf7\u8f93\u5165\u6807\u9898" value=""/></p>'),
    o = s.find("input");
    e && o.val(e);
    //r1.hasClass("first-hidden-unit") && o.addClass("cannot-delete"),
    o.on("keypress",
    function(t) {
        var e = jq(this),
        i = t.keyCode;
        13 == i && (t.preventDefault(), ArticleUtil.addTxtUnit(e.parent().parent()))
    }).on("focus",
    function() {
        jq(".current-pos").removeClass("current-pos"),
        jq(this).parent().parent().addClass("current-pos")
    }),
    t.after(jq(a).append(r).append(s)),
    jq(".current-pos").removeClass("current-pos"),
    s.parent().addClass("current-pos"),
    ArticleUtil.scrollToCurrentPos()
},
ArticleUtil.addVideo = function(r1,e) {
	var t = jq(".current-pos");
	var a = '<div class="edit-unit" data-type="6"></div>',
    r = jq('<div class="close-btn"><i class="article-icons article-icons-close"></i></div>');
    r.on("click",
    function() {
        confirm("\u786e\u5b9a\u8981\u5220\u9664\u8fd9\u4e2a\u89c6\u9891\u5417\u003f") && jq(this).parent().hide(200,
        function() {
            jq(this).remove()
        })
    });
    s = jq('<p class="videotitle"><input maxlength="1000" type="text" placeholder="\u8bf7\u8f93\u5165\u89c6\u9891\u7f51\u5740\u0075\u0072\u006c\uff08\u4ec5\u652f\u6301\u006d\u0070\u0034\u683c\u5f0f\uff09" value=""/></p>'),
    o = s.find("input");
    e && o.val(e);
    //r1.hasClass("first-hidden-unit") && o.addClass("cannot-delete"),
    o.on("keypress",
    function(t) {
        var e = jq(this),
        i = t.keyCode;
        13 == i && (t.preventDefault(), ArticleUtil.addTxtUnit(e.parent().parent()))
    }).on("focus",
    function() {
        jq(".current-pos").removeClass("current-pos"),
        jq(this).parent().parent().addClass("current-pos")
    }),
    t.after(jq(a).append(r).append(s)),
    jq(".current-pos").removeClass("current-pos"),
    s.parent().addClass("current-pos"),
    ArticleUtil.scrollToCurrentPos()
},
ArticleUtil.imgUploadEvent = function(t) {
    ArticleUtil.qiniuUploadInit(t, "10mb",
    function(t) {
        var e = jq(".current-pos");
        e = e.length <= 0 ? jq(".edit-unit:last-child") : jq(e[0]),
        ArticleUtil.addImgUnit(e, t, "")
    })
},
ArticleUtil.addImgUnit = function(t, e, i,ds,aid) {
    if (! (ArticleUtil.checkImgCount() >= 30)) {
        var a = '<div class="edit-unit" data-type="1"></div>',
        r = jq('<div class="close-btn"><i class="article-icons article-icons-close"></i></div>');
        r.on("click",
        function() {
            confirm("\u786e\u5b9a\u8981\u5220\u9664\u8fd9\u5f20\u56fe\u7247\u5417\u003f") && jq(this).parent().hide(200,
            function() {
                jq(this).remove()
            })
        });
        var n = "" + Math.floor(1e4 * Math.random()) + "_" + Math.floor(1e4 * Math.random()),
        //l = 580 * e.height / e.width,
        //c = jq('<div style="height:' + l + 'px;" class="pic" id="pic' + n + '"><img data-width="' + e.width + '" data-height="' + e.height + '" src="' + e.url + '"/></div>'),
        c = jq('<div style="height:auto;" class="pic" id="pic' + n + '"><img data-width="" data-height="" data-src="'+ds+'" data-aid="'+aid+'" src="' + e + '"/></div>'),
        s = jq('<div class="pic-desc"><i class="article-icons article-icons-desc"></i><input maxlength="50" type="text" placeholder="\u56fe\u7247\u63cf\u8ff0" value="' + (i && "undefined" != i ? i: "") + '"/></div>'),
        o = s.find("input");
        o.on("keypress",
        function(t) {
            var e = jq(this),
            i = t.keyCode;
            13 == i && (t.preventDefault(), ArticleUtil.addTxtUnit(e.parent().parent()))
        }).on("focus",
        function() {
            jq(".current-pos").removeClass("current-pos"),
            jq(this).parent().parent().addClass("current-pos")
        }),
        t.after(jq(a).append(r).append(c).append(s)),
        jq(".current-pos").removeClass("current-pos"),
        c.parent().addClass("current-pos"),
        ArticleUtil.scrollToCurrentPos()
    }
},
ArticleUtil.addFengmianImgUnit = function(t, e, i,ds,aid) {
	    t.find('div').remove();
	    jq('#fengmianurl').val('');
	    jq('#fengmianaid').val('');
        t.hide();
        
        var r = jq('<div class="close-btn"><i class="article-icons article-icons-close"></i></div>');
        r.on("click",
                function() {
                    confirm("\u786e\u5b9a\u8981\u5220\u9664\u8fd9\u5f20\u56fe\u7247\u5417\u003f") && jq(this).parent().find('div').hide(200,
                    function() {
                        jq(this).remove();
                        jq('#fengmianurl').val('');
                        jq('#fengmianaid').val('');
                        t.hide();
                    })
         });
        //t.find('div').remove();
        var n = "" + Math.floor(1e4 * Math.random()) + "_" + Math.floor(1e4 * Math.random()),
        c = jq('<div style="width:200px;height:110px;" class="pic" id="pic' + n + '"><img style="width:200px;height:110px;" data-width="" data-height="" data-src="'+ds+'" src="' + e + '"/></div>');
                
        jq('#fengmianurl').val(ds);
        jq('#fengmianaid').val(aid);
        
        t.append(r).append(c);
        t.show();
    
},
ArticleUtil.addBrandProductEvent = function(t, e, i, a,numiid,yuanjia,xianjia) {
    var r = jq(".current-pos");
    r = r.length <= 0 ? jq(".edit-unit:last-child") : jq(r[0]),
    ArticleUtil.addBrandProductUnit(r, t, e, i, a,null,numiid,yuanjia,xianjia)
},
ArticleUtil.addBrandProductUnit = function(t, e, i, a, r, n,numiid,yuanjia,xianjia) {
    r = r || ArticleUtil.config.defaultProductPic,
    n = n || 0;
    var l = '<div class="edit-unit" data-type="5"></div>',
    c = '<div class="brand-product" data-product-id="' + e + '" data-product-pic="' + r + '" data-product-numiid="' + numiid + '" data-product-yuanjia="' + yuanjia + '" data-product-xianjia="' + xianjia + '"><i class="article-icons article-icons-bp-close"></i><div class="pic" style="background-image: url(' + r + ');"></div><div class="info"><p class="name">' + a + '</p><!--<p class="brand">' + i + '</p>--><p class="xianjia">' + xianjia + '</p></div><div class="score-area"><p class="head">\u4f60\u7684\u8bc4\u5206</p><ul class="stars"><li><i class="article-icons star-0" data-index="1"></i></li><li><i class="article-icons star-0" data-index="2"></i></li><li><i class="article-icons star-0" data-index="3"></i></li><li><i class="article-icons star-0" data-index="4"></i></li><li><i class="article-icons star-0" data-index="5"></i></li></ul><p class="score"><span>' + n + "</span>\u5206</p></div></div>",
    s = jq('<div class="hot-zone"></div>');
    s.on("click",
    function() {
        s.parent().next() && 2 == s.parent().next().attr("data-type") && !s.parent().next().find(".txt").val() ? s.parent().next().find(".txt").focus() : ArticleUtil.addTxtUnit(jq(this).parent())
    });
    var o = jq(c);
    o.find(".article-icons-bp-close").on("click",
    function() {
        confirm("\u786e\u5b9a\u8981\u5220\u9664\u8fd9\u4e2a\u5546\u54c1\u5417\u003f") && o.parent().hide(100,
        function() {
            jq(this).remove()
        })
    });
    for (var d = o.find(".stars"), u = o.find(".stars li"), p = o.find(".stars li i"), f = o.find(".score span"), v = Math.floor(n / 2), h = 0; v > h; h++) jq(p[h]).addClass("star-2");
    var g = 0;
    u.on("mouseenter",
    function(t) {
        t.stopPropagation();
        var e = jq(this).find("i");
        d.removeClass("scored");
        for (var i = e.attr("data-index"), a = 0; 5 > a; a++) i > a ? jq(p[a]).addClass("star-2") : jq(p[a]).removeClass("star-2");
        f.html(2 * i)
    }).on("mouseleave",
    function(t) {
        if (t.stopPropagation(), d.hasClass("scored") || (p.removeClass("star-2"), f.html(0)), g) {
            for (var e = Math.floor(g / 2), i = 0; e > i; i++) jq(p[i]).addClass("star-2");
            f.html(g)
        }
    }).on("click",
    function(t) {
        t.stopPropagation();
        for (var e = jq(this).find("i"), i = e.attr("data-index"), a = 0; i > a; a++) jq(p[a]).addClass("star-2");
        f.html(2 * a),
        g = 2 * a,
        d.addClass("scored")
    }),
    t.after(jq(l).append(o).append(s)),
    jq(".current-pos").removeClass("current-pos"),
    o.parent().addClass("current-pos"),
    ArticleUtil.scrollToCurrentPos()
},
ArticleUtil.searchBrand = function(t, e, i, a) {
    function r(t) {
        jq.ajax({
            url: "/article/searchBrand",
            type: "GET",
            dataType: "json",
            data: {
                q: t,
                page: 0,
                pagesize: 100
            },
            beforeSend: function() {},
            success: function(t) {
                1 == t.code && n(t.data, e)
            }
        })
    }
    function n(e, a) {
        for (var r = "",
        n = 0,
        l = e.length; l > n; n++) r += '<div class="elli brand-result-item' + (0 == n ? " selected": "") + '" data-name="' + e[n].name + '" data-alias="' + e[n].alias + '" data-id="' + e[n].id + '"><div class="brand-logo" style="background-image: url(' + e[n].pic + ')"></div><p class="brand-name elli">' + e[n].name + (e[n].alias ? "_" + e[n].alias: "") + "</p></div>";
        jq(a).html(r).show(),
        jq(a).find(".brand-result-item").on("click",
        function() {
            var e = jq(this);
            jq(".brand-result-item.selected").removeClass("selected"),
            e.addClass("selected"),
            jq(t).val(e.attr("data-name")).attr("data-id", e.attr("data-id")),
            jq(a).hide(),
            jq(i).focus(),
            jq(i).trigger("keyup")
        })
    }
    t && jq(t).on("keyup",
    function() {
        var t = jq(this).val();
        return t ? void r(t) : void jq(this).removeAttr("data-id")
    }).on("focus",
    function() {
        jq(a).hide(),
        jq(e).show()
    })
},
ArticleUtil.searchBrandProduct = function(t, e, i, a) {
    function r(t, i) {
        jq.ajax({
            url: "plugin.php?id=jzsjiale_daogou:api&a=searchshangpin",
            type: "GET",
            dataType: "json",
            data: {
                q: t,
                brandId: i,
                page: 0,
                pagesize: 100
            },
            beforeSend: function() {},
            success: function(t) {
                jq(a).hide(),
                200 == t.code && n(t.data, e)
            }
        })
    }
    function n(e, i) {
        for (var a = "",
        r = 0,
        n = e.length; n > r; r++) a += '<p class="elli product-result-item' + (0 == r ? " selected": "") + '" data-name="' + e[r].title + '" data-id="' + e[r].id + '" data-pic="' + e[r].img + '" data-numiid="' + e[r].numiid + '" data-xianjia="' + e[r].xianjia + '" data-yuanjia="' + e[r].yuanjia + '">',
        a += '<i class="pic" style="background-image: url(' + e[r].img + ');"></i>',
        //e[r].brand && e[r].brand.id && (a += "<span>" + e[r].brand.name + "</span>"),
        a += e[r].title + "</p>";
        jq(i).html(a).show(),
        jq(i).find(".product-result-item").on("click",
        function() {
            var e = jq(this);
            jq(".product-result-item.selected").removeClass("selected"),
            e.addClass("selected"),
            jq(t).val(e.attr("data-name")).attr("data-id", e.attr("data-id")).attr("data-pic", e.attr("data-pic")).attr("data-numiid", e.attr("data-numiid")).attr("data-yuanjia", e.attr("data-yuanjia")).attr("data-xianjia", e.attr("data-xianjia")),
            jq(t).prev().val(e.find("span").html()),
            jq(i).hide()
        })
    }
    t && jq(t).on("keyup focus",
    function() {
        var t = jq(this).val(),
        e = jq(i).attr("data-id");
        t || (t = jq(i).val()),
        r(t, e)
    })
},
ArticleUtil.editBrandProduct = function() {
    jq(".edit-mask").fadeIn(100),
    jq(".edit-brand-product-area").fadeIn(100),
    jq(".edit-brand-product-btn").fadeIn(100)
},
ArticleUtil.closeEditBrandProduct = function() {
    jq(".edit-brand-product-area").fadeOut(100),
    jq(".edit-brand-product-btn").fadeOut(100),
    jq(".edit-mask").fadeOut(100),
    jq(".search-brand").val("").removeAttr("data-id"),
    jq(".search-product").val("").removeAttr("data-id").removeAttr("data-pic")
},
ArticleUtil.transToJSON = function(t, e) {
    for (var i = jq(t).find("." + e), a = [], r = 0, n = i.length; n > r; r++) {
        var l = jq(i[r]),
        c = {},
        s = l.attr("data-type");
        switch (s) {
        case "1":
            c.type = 1;
            var o = l.find(".pic img"),
            //d = o.attr("src");
            d = o.attr("data-src");
            if (!d) break;
            c.image_url = d,
            c.image_desc = l.find(".pic-desc input").val(),
            c.image_width = o.attr("data-width"),
            c.image_height = o.attr("data-height"),
            c.image_aid = o.attr("data-aid"),
            a.push(c);
            break;
        case "2":
            var u = l.find(".txt").val();
            if (!jq.trim(u)) break;
            c.type = 2,
            c.text_type = 2,
            c.text_content = jq.trim(u),
            a.push(c);
            break;
        case "3":
            var u = l.find(".h1title input").val();
            if (!jq.trim(u)) break;
            c.type = 3,
            c.text_type = 3,
            c.text_content = jq.trim(u),
            a.push(c);
            break;
        case "5":
            c.type = 5;
            var p = l.find(".brand-product");
            c.product_id = p.attr("data-product-id"),
            c.product_id = "undefinded" == c.product_id || isNaN(c.product_id) ? "": c.product_id,
            c.product_score = p.find(".score span").html(),
            c.item_name = p.find(".name").html(),
            c.item_subtitle = p.find(".brand").html(),
            c.pic = p.attr("data-product-pic"),
            c.numiid = p.attr("data-product-numiid"),
            c.xianjia = p.attr("data-product-xianjia"),
            c.yuanjia = p.attr("data-product-yuanjia"),
            a.push(c);
            break;
        case "6":
            var u = l.find(".videotitle input").val();
            if (!jq.trim(u)) break;
            c.type = 6,
            c.text_type = 6,
            c.text_content = jq.trim(u),
            a.push(c);
            break;
        }
    }
    var f = {};
    return f.title = jq("#titleInput").val(),
    f.cover_url = jq("#fengmianurl").val(),
    f.cover_aid = jq('#fengmianaid').val(),
    f.desc = "",
    f.content_list = a,
    f
},
ArticleUtil.saveJSON = function(t, e, i) {
    var a = ArticleUtil.transToJSON(t, e);
    ArticleUtil.setDraft(JSON.stringify(a), i)
},
ArticleUtil.deleteJSON = function() {
    ArticleUtil.setDraft("", 1)
},
ArticleUtil.setDraft = function(t, e) {
	var formhash = jq("#formhash").val();
	var fid = jq("#fid").val();
	var articleid = jq("#articleId").val();
	var mobileflag = jq("#mobileflag").val();
	var pid = jq("#pid").val();
	//jq("#articleId").val() || 
    jq.ajax({
        url: "plugin.php?id=jzsjiale_daogou:api&a=saveDraft",
        type: "POST",
        dataType: "json",
        data: {
        	tid:articleid,
        	pid:pid,
        	fid:fid,
            articleContent: t,
            mobileflag:mobileflag,
            formhash:formhash
        },
        success: function(t) {
            200 == t.code ? (jq("#articleId").val(t.data.id),jq("#pid").val(t.data.pid),(e == "" || typeof(e) == "undefined")? alert("\u4fdd\u5b58\u6210\u529f"):jq("#pagemsg").html("\u81ea\u52a8\u4fdd\u5b58\u6210\u529f").show(300).delay(3000).hide(300)) : -2 == t.code ? Util.loginModel(1) : alert(t.msg)
        }
    })
},
ArticleUtil.getDraft = function(t) {
    jq.ajax({
        url: "plugin.php?id=jzsjiale_daogou:api&a=getDraft",
        type: "GET",
        dataType: "json",
        data: {},
        success: function(e) {
            200 == e.code ? t(e.data) : (alert('\u8bf7\u5148\u767b\u5f55'),Util.loginModel(1))
        }
    })
},
ArticleUtil.recoverEditContent = function(t) {
    if (t && (t.title && jq("#titleInput").val(t.title), t.content_list)){
    	var realimg = jq("#realimg").val();
    	if(t.cover_url != null && t.cover_url != ""){
    		ArticleUtil.addFengmianImgUnit(jq(".fengmian"), realimg+t.cover_url,"",t.cover_url,t.cover_aid);
    	}
    	
	   for (var e = 0,i = t.content_list.length; i > e; e++) {
	        var a = t.content_list[e],
	        r = jq(".edit-unit").last();
	        
	        switch (a.type) {
	        case 1:
	        	ArticleUtil.addImgUnit(r, realimg+a.image_url,a.image_desc,a.image_url,a.image_aid);
	        	/*
	            ArticleUtil.addImgUnit(r, {
	                url: a.image_url,
	                width: a.image_width,
	                height: a.image_height
	            },
	            a.image_desc);
	            */
	            break;
	        case 2:
	            ArticleUtil.addTxtUnit(r, a.text_content);
	            break;
	        case 3:
	            ArticleUtil.addTitle(r, a.text_content);
	            break;
	        case 5:
	            ArticleUtil.addBrandProductUnit(r, a.product_id, a.item_subtitle, a.item_name, a.pic, a.product_score,a.numiid,a.yuanjia,a.xianjia);
	            break;
	        case 6:
	            ArticleUtil.addVideo(r, a.text_content);
	            break;    
	        }
	    }
    } 
},
ArticleUtil.dealImageUrl = function(t) {
    jq.each(t,
    function(t, e) {
        1 == e.type && (e.image_url = ArticleUtil.config.qiniuHost + "/" + e.image_url, e.image_url.match(/\.jpg/g) || (e.image_url += "!w900"))
    })
},
ArticleUtil.buildArticle = function(t, e, i) {
    if (t) {
        var a = '<h1 class="title">' + t.title + "</h1>",
        r = "";
        if (t.content_list) for (var n = 0,
        l = t.content_list.length; l > n; n++) {
            var c = t.content_list[n];
            switch (c.type) {
            case 1:
                var s = 580 * c.image_height / c.image_width;
                r += '<div class="img-area">',
                r += '<img src="' + c.image_url + '" style="height:' + s + 'px;"/>',
                c.image_desc && (r += '<p class="img-desc"><i></i>' + c.image_desc + "</p>"),
                r += "</div>";
                break;
            case 2:
                r += '<p class="txt">' + c.text_content + "</p>";
                break;
            case 5:
                c.pic = c.pic || ArticleUtil.config.defaultProductPic;
                var o = "javascript:;";
                c.product_id && !isNaN(c.product_id) && (o = "/product/" + c.product_id),
                i && (o = "javascript:;"),
                r += '<div class="product-v3" data-product-id="' + c.product_id + '">',
                r += '<a title="' + c.item_name + '" href="' + o + '">',
                r += '<div class="info-area">',
                r += '<div class="cover" style="background-image:url(' + c.pic + ');"></div>',
                r += '<div class="arr-area"><i class="arr-right"></i></div>',
                r += '<div class="info">',
                r += '<p class="pro-title"><span>' + c.item_subtitle + "</span>" + c.item_name + "</p>",
                c.price && (r += '<p class="price">¥&nbsp;<span class="number-font">' + c.price + "</span></p>"),
                r += "</div>",
                r += "</div>",
                r += "</a>",
                r += '<div class="option-area">',
                r += '<div class="like-area' + (c.islike ? " liked": "") + '" data-likes="' + (c.likes || 0) + '">',
                r += '<div class="right-line"></div>',
                r += '<i class="pro-like"><i class="ani"></i></i>',
                r += '<span class="like-count">' + (c.islike ? "\u5df2\u559c\u6b22": c.likes || "\u559c\u6b22") + "</span>",
                r += "</div>",
                r += '<a target="_blank" rel="nofollow" isconvert="1" href="' + (c.url || "javascript:;") + '">',
                r += '<div class="buy-area"><i class="buy"></i>\u8d2d\u4e70</div>',
                r += "</a>",
                r += "</div>",
                r += "</div>"
            }
        }
        e.html(a).append(r)
    }
},
ArticleUtil.preview = function(t, e, i) {
    ArticleUtil.buildArticle(t, e, 1),
    i.fadeIn(),
    jq("body").css("overflow", "hidden")
},
ArticleUtil.closePreview = function(t) {
    t.fadeOut(),
    jq("body").css("overflow", "auto")
},
ArticleUtil.checkImgCount = function() {
    var t = ArticleUtil.transToJSON(jq(".edit-content"), "edit-unit"),
    e = 0;
    return jq.each(t.content_list,
    function(t, i) {
        1 == i.type && e++
    }),
    e
},
ArticleUtil.publish = function(w, ar) {
    if (ArticleUtil.config.canpublish) {
    	
    	var uri = "forum.php?mod=viewthread&tid=";
		var uri2 = "";
		
		if(ar == 1){
			if(w == 2){
				uri = "topic-";
				uri2 = ".html";
			}else if(w == 3){
				uri = "topic_";
				uri2 = ".html";
			}else if(w == 4){
				uri = "post-";
				uri2 = ".html";
			}else if(w == 5){
				uri = "post_";
				uri2 = ".html";
			}else{
				uri = "plugin.php?id=jzsjiale_daogou:article&tid=";
				uri2 = "";
			}
		}

		if(ar == 0){
			if(w == 1){
				uri = "thread-";
				uri2 = "-1-1.html";
			}else{
				uri = "forum.php?mod=viewthread&tid=";
				uri2 = "";
			}
		}
		
		
    	var formhash = jq("#formhash").val();
    	var fid = jq("#fid").val();
    	var pid = jq("#pid").val();
    	
    	    
        var articleid = jq("#articleId").val(),
        e = ArticleUtil.transToJSON(jq(".edit-content"), "edit-unit"),
        i = 0,
        a = 0;
        if (jq.each(e.content_list,
        function(t, e) {
            //5 == e.type && e.pic && delete e.pic,
            1 == e.type && (i++, e.image_url = e.image_url.replace("!w900", "")),
            2 == e.type && (a += e.text_content.length),
            3 == e.type && (a += e.text_content.length)
        }), !jq.trim(e.title) || "\u6807\u9898" == jq.trim(e.title)) return void alert("\u8bf7\u8f93\u5165\u6807\u9898");
 
        if (jq.trim(e.title).length > 40) return void alert("\u6807\u9898\u6700\u591a\u4e0d\u80fd\u8d85\u8fc7\u0034\u0030\u4e2a\u5b57");
        if (0 >= i) return void alert("\u8bf7\u81f3\u5c11\u6dfb\u52a0\u4e00\u5f20\u56fe\u7247\u0021");
        if (i > 30) return void alert("\u6700\u591a\u6dfb\u52a0\u0033\u0030\u5f20\u56fe\u7247\u002c\u5f53\u524d" + i + "\u5f20");
        if (a > 1e4) return void alert("\u6587\u7ae0\u5b57\u6570\u6700\u5927\u4e3a\u0031\u4e07\u5b57\u002c\u5f53\u524d\u5b57\u6570" + a);
        e = JSON.stringify(e),
        jq.ajax({
            url: "plugin.php?id=jzsjiale_daogou:api&a=publisharticle",
            type: "POST",
            dataType: "json",
            data: {
            	tid:articleid,
            	pid:pid,
            	fid:fid,
                articleContent: e,
                formhash:formhash
            },
            beforeSend: function() {
                ArticleUtil.config.canpublish = 0
            },
            success: function(t) {
                200 == t.code && t.data.id ? (window.location.href = uri + t.data.id + uri2) : -2 == t.code ? (Util.loginModel(1), ArticleUtil.config.canpublish = 1) : (alert("\u53d1\u5e03\u6210\u529f"), ArticleUtil.config.canpublish = 1)
            }
        })
        
    
    
    }
};