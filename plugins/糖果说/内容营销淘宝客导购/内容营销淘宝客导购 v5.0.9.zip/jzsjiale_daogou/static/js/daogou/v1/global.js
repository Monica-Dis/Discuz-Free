var Util = Util || {};
Util.flag = {
    productLikeFlag: 1,
    topicCollectFlag: 1
},
Util.pageSize = function() {
    var i = document.documentElement,
    e = ["clientWidth", "clientHeight", "scrollWidth", "scrollHeight"],
    t = {};
    for (var a in e) t[e[a]] = i[e[a]];
    return t.scrollLeft = document.body.scrollLeft || document.documentElement.scrollLeft,
    t.scrollTop = document.body.scrollTop || document.documentElement.scrollTop,
    t
},

Util.modelClose = function(i, e) {
    i.css("opacity", "0"),
    e.css({
        opacity: "0",
        transform: "translate(0,-20px)"
    }),
    setTimeout(function() {
        i.remove(),
        e.remove()
    },
    300)
},
Util.scrollHeader = function() {
    $(window).on("scroll",
    function() {
        $(document).scrollTop() >= 200 ? $("body").removeClass("home-header") : $("body").addClass("home-header")
    })
},

Util.scrollToTop = function(i) {
    var e = $("body,html");
    20 > i ? e.scrollTop(0) : e.stop(!0, !0).animate({
        scrollTop: 0
    },
    i)
},
Util.sideFixedMenu = function(i, e, t, a) {
    if (i && e && !(e.length <= 0)) {
        t || (t = 2e3);
        var s = $(document),
        l = ($("body"), i.width()),
        c = Math.floor(l / 2) + 40,
        n = "";
        n += '<div class="side-fixed-menu" style="margin-left: ' + c + 'px;">';
        for (var o = 0,
        r = e.length; r > o; o++) switch (e[o]) {
        case "back-to-top":
            n += '<div class="menu-item" id="backToTop">',
            n += '<i class="bt-iconfont if-back-to-top"></i>',
            n += "<p>\u8fd4\u56de\u9876\u90e8</p>",
            n += "</div>";
            break;
        
        }
        n += "</div>";
        var d = $(n);
        d.find("#backToTop").on("click",
        function() {
            Util.scrollToTop(300)
        }),
        d.find("#productLike").on("click",
        function() {
            var i = $(this),
            e = 1;
            i.hasClass("liked") && (e = 2);
            var t = $("#productId").val();
            Util.productLike(t, e, i)
        }),
        d.find("#topicLike").on("click",
        function() {
            var i = $(this),
            e = 1;
            i.hasClass("liked") && (e = 2);
            var t = $("#topicId").val();
            Util.topicCollect(t, e, i)
        }),
        d.appendTo($("body")),
        $(window).on("scroll",
        function() {
            var i = s.scrollTop();
            i > t ? d.fadeIn(100) : d.fadeOut(100)
        })
    }
},
Util.allCateStruct = function(i, e, t, a) {
    function s(s) {
        var l = 50,
        c = "",
        n = "";
        n += '<div class="cate-content-area" style="left:' + e + 'px;">',
        c += '<div class="cate-struct-area" style="width:' + e + 'px;">',
        c += '<p class="title">\u5168\u90e8\u5206\u7c7b</p><div class="h-dashed-3"></div>',
        c += '<ul class="cate-1-list">';
        for (var o = 0,
        r = s.length; r > o; o++) {
            l += t + 1,
            c += '<li data-id="' + s[o].id + '" data-level="1" d-i="' + o + '" data-index="' + o + '" style="height:' + t + "px;line-height:" + t + 'px;"><i class="before-arr"></i><p>' + s[o].title + '</p><div class="h-dashed-3"></div><i class="after-arr"></i></li>';
            var d = s[o].child;
            n += '<div data-index="' + o + '" class="cate-2-list">',
            n += '<div class="inner">';
            if (typeof(d)!="undefined"){ 
	            for (var p = 0,
	            v = d.length; v > p; p++) {
	                n += '<div class="cate-2-list-item">',
	                n += '<div class="pic"><img src="' + d[p].img + '"/></div>',
	                n += '<div class="info">',
	                n += '<p data-id="' + d[p].id + '" data-level="2" d-i="' + o + '" d-j="' + p + '" class="title cate-unit">' + d[p].title + "</p>",
	                n += '<ul class="cate-3-list clearfix">';
	                if (typeof(d[p].child)!="undefined"){ 
	                   for (var h = d[p].child, f = 0, m = h.length; m > f; f++) n += '<li class="cate-unit" data-id="' + h[f].id + '" data-level="3" d-i="' + o + '" d-j="' + p + '" d-k="' + f + '">' + h[f].title + "</li>";
	                }
	                n += "</ul>",
	                n += "</div>",
	                n += "</div>",
	                p % 3 == 2 && (n += '<div class="clear"></div>')
	            }
            }
            n += '<div class="clear"></div>',
            n += "</div>",
            n += "</div>"
        }
        c += "</ul>",
        c += "</div>",
        n += "</div>";
        var g = $(n),
        k = $(c);
        k.append(g),
        k.find(".cate-unit").click(function() {
            var i = $(this);
            $(".cate-1-list li.selected").removeClass("selected"),
            $($(".cate-1-list li")[i.attr("d-i")]).addClass("selected"),
            a(s, i.attr("data-level"), i.attr("data-id"), i.attr("d-i"), i.attr("d-j"), i.attr("d-k")),
            $(".cate-2-list").css("z-index", "1").hide()
        });
        var b = k.find(".cate-1-list li");
        b.each(function() {
            var i = $(this).attr("data-index"),
            e = k.find(".cate-2-list[data-index=" + i + "]");
            e.find(".inner").css("min-height", 50 * (1 * i + 2) - 70 + "px");
            var a = 0,
            s = Math.floor(50 + i * (t + 1) + t / 2),
            l = s - a;
            e.css("top", a + "px"),
            e.find(".inner .before-arr").css("top", l + "px"),
            e.find(".inner .after-arr").css("top", l + "px")
        }),
        b.on("mouseenter",
        function() {
            var i = $(this);
            i.find("i").css("display", "block");
            var e = $(this).attr("data-index"),
            t = k.find(".cate-2-list[data-index=" + e + "]"),
            a = $(document).scrollTop();
            if (a > 30) {
                var s = a - 30;
                t.css("top", s + "px"),
                t.find(".inner").css("min-height", 50 * (1 * e + 2) - 70 - s + "px")
            } else t.css("top", "0px"),
            t.find(".inner").css("min-height", 50 * (1 * e + 2) - 70 + "px");
            t.css("z-index", "10").show()
        }).on("mouseleave",
        function() {
            var i = $(this);
            i.find("i").css("display", "none");
            var e = $(this).attr("data-index");
            k.find(".cate-2-list[data-index=" + e + "]").css("z-index", "1").hide()
        }),
        g.find(".cate-2-list").on("mouseenter",
        function() {
            var i = $(this),
            e = i.attr("data-index");
            k.find(".cate-1-list li[data-index=" + e + "]").find("i").css("display", "block"),
            $(this).css("z-index", "10").show()
        }).on("mouseleave",
        function() {
            var i = $(this),
            e = i.attr("data-index");
            k.find(".cate-1-list li[data-index=" + e + "]").find("i").css("display", "none"),
            $(this).css("z-index", "1").hide()
        }),
        i.html("").append(k)
    }
    $.ajax({
        url: "plugin.php?id=jzsjiale_daogou:api&a=webspcategory",
        type: "GET",
        dataType: "json",
        data: {},
        success: function(i) {
            s(i.data)
        },
        error: function(i) {
        
        }
    })
},
Util.scrollEvent = function(i, e) {
    $(document).on("scroll",
    function() {
        var t = $(document).scrollTop(),
        a = Util.pageSize().scrollHeight,
        s = Util.pageSize().clientHeight;
        t + s >= a - e && i()
    })
},
Util.createTopicList = function(i, e, t, a) {
    for (var s = "",
    l = 0,
    c = t.length; c > l; l++) {
        var n = t[l];
        if ((2 != n.type || 0 != n.type_id) && 6 != n.type) {
            var o = n.cover || n.pic || n.pics && n.pics.length > 0 && n.pics[0].url || "";
            a && "recommend" == a && n.pics && n.pics.length > 0 && (o = n.pics[0].url),
            o = o.replace("!300x300", "!w600");
            var r = n.description ? n.description: n.desc;
            s += '<div class="topic-item">',
            s += '<a target="_blank" title="' + n.title + '" href="/topic/' + n.id + '/">',
            s += '<div class="cover-area"><div class="cover"><img src="' + o + '" alt="' + n.title + '"/></div></div>',
            s += '<div class="detail">',
            s += '<p class="title">' + n.title + "</p>",
            s += '<p class="desc">' + r || "</p>",
            s += '<div class="info">',
            s += '<div class="stat">',
            s += '<i class="bt-iconfont if-view"></i>' + (n.views || "0"),
            s += '<i class="bt-iconfont if-like pl"></i>' + (n.likes || "0"),
            s += "</div>",
            s += "</div>",
            s += "</div>",
            s += "</a>",
            s += "</div>"
        }
    }
    1 == e ? i.html(s) : i.append(s)
},
Util.createTopicListV2 = function(i, e, t, w) {
	var uri = "forum.php?mod=viewthread&tid=";
	var uri2 = "";
	if(w == 1){
		uri = "thread-";
		uri2 = "-1-1.html";
	}else if(w == 2){
		uri = "topic-";
		uri2 = ".html";
	}else{
		uri = "forum.php?mod=viewthread&tid=";
		uri2 = "";
	}
	
    for (var a = "",
    s = 0,
    l = t.length; l > s; s++) {
        var c = t[s];
        if (1 != c.status) {
            a += '<div class="topic-item">',
            a += '<a target="_blank" title="' + c.subject + '" href="' + uri + c.tid + uri2 +'">',
            a += '<div class="cover-area"><div class="cover"><img src="' + c.cover + '" alt="' + c.subject + '"/></div></div>',
            a += '<div class="detail">',
            a += '<p class="title elli">' + c.subject + "</p>",
            a += '<p class="desc">' + c.message + "</p>",
            a += '<div class="info">',
            a += '<div class="user">',
            a += '<div class="avatar" style="background-image: url(uc_server/avatar.php?uid=' + c.authorid + '&size=small);"></div>',
            a += '<p class="nickname">' + c.author + "</p>",
            a += "</div>",
            a += '<div class="stat">',
            a += '<i class="bt-iconfont if-view"></i>' + (c.views || "0"),
            a += '<i class="bt-iconfont if-comment pl"></i>' + (c.replies || "0"),
            a += "</div>",
            a += "</div>",
            a += "</div>",
            a += "</a>",
            a += "</div>"
        }
    }
    1 == e ? i.html(a) : i.append(a)
},
Util.createProductList = function(i, e, t,j) {
    for (var a = "",
    s = 0,
    l = t.length; l > s; s++) {
    	var tdj = '';
    	if(j > 0 && t[s].numiid != '' &&  t[s].url.indexOf("uland.taobao.com/coupon") < 0){
    		tdj = 'data-type="0" isconvert="1" biz-itemid="'+t[s].numiid+'"';
    	}
        a += '<div class="goods-item"><a target="_blank" title="' + t[s].title + '" '+tdj+'href="' + t[s].url + '"><div class="cover"><img src="' + t[s].img + '" alt="' + t[s].title + '"/></div><p class="title elli">' + t[s].title + '</p><p class="stat"><span class="price">&yen;' + t[s].xianjia + '</span>&nbsp;&nbsp;&nbsp;<del class="oldprice">&yen;' + t[s].yuanjia + '</del><strong class="chakanbtn"><a '+tdj+'href="' + t[s].url + '" target="_blank">\u67e5\u0020\u770b</a></strong></p></a></div>'
    }
    1 == e ? i.html(a) : i.append(a)
},
Util.createSinglePicProductList = function(i, e, t) {
    for (var a = "",
    s = 0,
    l = t.length; l > s; s++) {
        var c = t[s].pic;
        c || (c = t[s].picUrl),
        a += '<div class="goods-item"><a title="' + t[s].title + '" href="/product/' + t[s].id + '/"><div class="cover"><img src="' + c + '" alt="' + t[s].title + '"/></div></a></div>'
    }
    1 == e ? i.html(a) : i.append(a)
},

Util.likeOptTips = function(i) {
    var e = '<div class="like-opt-tips">';
    e += '<i class="icons like-tips"></i>',
    e += "<p>" + i + "</p>",
    e += "</div>";
    var t = $(".suser-area");
    t.prepend(e),
    setTimeout(function() {
        t.find(".like-opt-tips").css("opacity", "0")
    },
    2e3)
},

Util.rightSideFix = function(i) {
    i = i || 30;
    var e = $(".wrapper-950-r .inner");
    $(window).on("scroll",
    function() {
        $(document).scrollTop() >= i ? e.addClass("fixed") : e.removeClass("fixed")
    })
},
$(function() {
    function i(i) {
        window.location.href = "plugin.php?id=jzsjiale_daogou:search&q=" + i
    }
    var limg = $("#loginlogo").val();
    var e = $("#searchForm"),
    t = e.find("input"),
    a = e.find("a");
    t.on("focus",
    function() {
        "\u641c\u7d22\u4f60\u60f3\u8981\u7684" == $(this).val() && $(this).val("")
    }).on("blur",
    function() {
        "" == $(this).val() && $(this).val("\u641c\u7d22\u4f60\u60f3\u8981\u7684")
    }).on("keyup",
    function(e) {
        var t = e.keyCode,
        a = $(this).val();
        13 == t && a && i(a)
    }),
    a.bind("click",
    function() {
        var e = t.val();
        "\u641c\u7d22\u4f60\u60f3\u8981\u7684" != e.trim() && i(e)
    }),

    $("[data-ga-event]").click(function() {
        var i = $(this),
        e = i.attr("data-ga-event"),
        t = e.split(":");
        "undefined" != typeof ga && t.length >= 3 && ga("send", "event", t[0], t[1], t[2])
    })
});