if('undefined' != typeof Zepto) {
    (function ($) {
        $.extend($.fn, {
            cookie: function (key, value, options) {
                var days, time, result, decode

                // A key and value were given. Set cookie.
                if (arguments.length > 1 && String(value) !== "[object Object]") {
                    // Enforce object
                    options = $.extend({}, options)

                    if (value === null || value === undefined) options.expires = -1

                    if (typeof options.expires === 'number') {
                        days = (options.expires * 24 * 60 * 60 * 1000)
                        time = options.expires = new Date()

                        time.setTime(time.getTime() + days)
                    }

                    value = String(value)

                    return (document.cookie = [
                        encodeURIComponent(key), '=',
                        options.raw ? value : encodeURIComponent(value),
                        options.expires ? '; expires=' + options.expires.toUTCString() : '',
                        options.path ? '; path=' + options.path : '',
                        options.domain ? '; domain=' + options.domain : '',
                        options.secure ? '; secure' : ''
                    ].join(''))
                }

                // Key and possibly options given, get cookie
                options = value || {}

                decode = options.raw ? function (s) {
                    return s
                } : decodeURIComponent

                return (result = new RegExp('(?:^|; )' + encodeURIComponent(key) + '=([^;]*)').exec(document.cookie)) ? decode(result[1]) : null
            }

        })
    })(Zepto);
}

var Util = Util || {};

Util.DownloadShow = function(inparams) {
    var params = {
        maskerID: 'modelOverlay',
        contentID: 'modelContent',
        alpha: 0.7,
        bgColor: '#000',
        dbclick: true,
        keydown: true,
        mZindex: 9997,
        cZindex: 9999,
        url:'http://m.bantangapp.com/appview/downapp.html',
        content: '使用本功能<br>需用<span style="color: #ec5252;padding: 0 3px;">半糖App</span>打开'
    };

    if (inparams && typeof(inparams) == 'object') {
        for (var key in inparams) {
            if (key.match(/^_/)) {
                continue
            }
            params[key] = inparams[key]
        }
    };
    var de = document.documentElement;
    var _height = de.clientHeight;
    var top = Math.floor(_height/2-100);
    var html = '<div id="'+ params.maskerID +'" style="position:fixed;left:0;top:0;right:0;bottom:0;z-index:' + params.mZindex + ';background-color:rgba(0,0,0,.7);"></div>';
    html += '<div id="' + params.contentID + '" class="model-dialog" style="z-index:' + params.cZindex + ';position:fixed;left:50%;width:280px;padding:0 10px;margin-left:-140px;top:'+top+'px;background-color:#fff;border-radius:4px;">';
    html += '<div style="width: 37px;height: 37px;margin: 25px auto 0;background: url(http://7xlxny.com1.z0.glb.clouddn.com/h5/v2/home/logo.png) center no-repeat;background-size: cover;"></div>';
    html += '<p style="line-height: 21px;font-size: 13px;color:#666;text-align: center;padding: 10px 15px 17px;">'+params.content+'</p>';
    html += '<div style="border-top:1px solid #d8d8d8;height: 20px;padding: 10px 0;line-height: 20px;font-size: 13px;">' +
    '<a class="icon-close" style="display:block;float:left;width: 139px;height:20px;border-right:1px solid #d8d8d8;color:#999;text-align: center;" href="javascript:;">不了</a>' +
    '<a class="confirm-btn" style="display:block;float:left;width: 140px;height:20px;color:#ec5252;text-align: center;" href="'+params.url+'">用App打开</a>' +
    '<div>';
    html += '</div>';
    $('body').css("overflow","hidden");
    $(html).appendTo('body').fadeIn(200);

    $('.confirm-btn').on('click',function(){
        if($(this).attr('href').indexOf('/dp/') >= 0){
            Util.gaEventMethod('global:click:deep_share');
        }
    });

    var modelBox = $('#' + params.maskerID);
    var modelBody = $('#' + params.contentID);
    var iconClose = $('.icon-close');
    if(iconClose){
        iconClose.click(function(){
            Util.modelClose(modelBox, modelBody);
        });
    }
    if (params.dbclick) {
        modelBox.click(function(e) {
            e = e || window.event;
            var ele = e.srcElement ? e.srcElement : e.target;
            Util.modelClose(modelBox, modelBody);
        })
    }
    if (params.keydown) {
        document.onkeydown = function(event) {
            event = window.event || event;
            var keyCode = event.keyCode || event.which || event.charCode;
            if (event.keyCode == 27) {
                Util.modelClose(modelBox, modelBody);
            }
        }
    }
}
Util.loginModel = function(i) {
    var mobileflag = $('#mobileflag').val();
    if(mobileflag == 1){
		window.location.href="member.php?mod=logging&action=login&mobile=2";
	}else{
		window.location.href="member.php?mod=logging&action=login";
	}
	
	//window.open("member.php?mod=logging&action=login");
	return;
}
Util.modelClose = function(o, m) {
    o.fadeOut(function() {
        o.remove();
    });
    m.fadeOut(function() {
        m.remove();
        $('body').css("overflow","auto");
    })
};

Util.WXShareShow = function(inparams) {
    var params = {
        maskerID: 'modelOverlay',
        contentID: 'modelContent',
        alpha: 0.7,
        bgColor: '#000',
        dbclick: true,
        keydown: true,
        mZindex: 9997,
        cZindex: 9999
    };

    if (inparams && typeof(inparams) == 'object') {
        for (var key in inparams) {
            if (key.match(/^_/)) {
                continue
            }
            params[key] = inparams[key]
        }
    };
    var html = '<div id="'+ params.maskerID +'" style="position:fixed;left:0;top:0;right:0;bottom:0;z-index:' + params.mZindex + ';background-color:rgba(0,0,0,.7);">' +
        '<img style="width: 100%;" src="http://7xlxny.com1.z0.glb.clouddn.com/h5/v2/home/share-guide.png"/></div>';
    $('body').css("overflow","hidden");
    $(html).appendTo('body').fadeIn(200);

    var modelBox = $('#' + params.maskerID);
    var modelBody = $('#' + params.contentID);
    if (params.dbclick) {
        modelBox.click(function(e) {
            e = e || window.event;
            var ele = e.srcElement ? e.srcElement : e.target;
            Util.modelClose(modelBox, modelBody);
        })
    }
    if (params.keydown) {
        document.onkeydown = function(event) {
            event = window.event || event;
            var keyCode = event.keyCode || event.which || event.charCode;
            if (event.keyCode == 27) {
                Util.modelClose(modelBox, modelBody);
            }
        }
    }
}

Util.getQueryString = function(url){
    if(url.split('?').length <= 1){
        return {};
    }
    var queryString = url.split('?')[1];
    if(!queryString) return;
    queryString = queryString.split('&');
    var queries = {};
    for(var i= 0,len=queryString.length;i<len;i++){
        var tmp = queryString[i].split('=');
        queries[''+tmp[0]] = tmp[1];
    }
    return queries;
}

Util.loadTopicComment = function(){
	function i(i, t, p) {
        var a = "";
        "topic" == s ? a = "plugin.php?id=jzsjiale_daogou:api&a=addcomment": "post" == s && (a = "plugin.php?id=jzsjiale_daogou:api&a=addcomment"),
        $.ajax({
            url: a,
            type: "POST",
            dataType: "json",
            data: {
                tid: l,
                content: i,
                fid: fid,
                atUserId: t,
                pid: p,
                mobileflag:1,
                formhash:formhash
            },
            beforeSend: function() {},
            success: function(i) {
                200 == i.code ? (alert("\u8bc4\u8bba\u53d1\u5e03\u6210\u529f"), window.location.reload()) : -2 == i.code && (alert('\u8bf7\u5148\u767b\u5f55'),Util.loginModel())
            },
            error: function() {
            	alert("\u53d1\u8868\u8bc4\u8bba\u5931\u8d25\u002c\u8bf7\u91cd\u8bd5\u0021");
            }
        })
    }
	function t() {
        0 != f && $.ajax({
            url: h,
            type: "GET",
            dataType: "json",
            data: {
                tid: l,
                page: v,
                pagesize: u
            },
            beforeSend: function() {
                f = 0
            },
            success: function(i) {
                200 == i.code && (e(i.data, r), i.data.length >= u ? (v++, f = 1, p.css("display", "block")) : (p.css("display", "none"), $(".comment-item:last-child").css("border-bottom", "none")))
            },
            error: function(i) {
                
            }
        })
    }
	function e(t, e) {
        for (var a = "",
        s = 0,
        l = t.length; l > s; s++) {
            var c = t[s];
            a += '<li class="comment-item">',
            a += '<a target="_blank" title="' + c.author + '\u7684\u9996\u9875" href="' + c.userhome + '">',
            a += '<div class="avatar" style="background-image: url(' + c.avatar + ');"></div>',
            a += "</a>",
            a += '<div class="info">',
            a += '<p class="nickname">',
            a += '<a href="javascript:;">' + c.author + "</a>",
            a += "</p>",
            a += '<p class="content">' + c.message + "</p>",
            c.messagequote && c.quotepid && (a += '<p class="at-comment"><span class="at-user">' + c.quoteauthor + ":</span>" + c.messagequote + "</p>"),
            a += '<p class="stats">' + c.dateline + '<span class="reply-btn">\u56de\u590d</span></p>',
            a += '<div class="reply-area"><div class="reply-con-area"><textarea class="reply-con" placeholder="\u56de\u590d @' + c.author + '"></textarea></div><div class="reply-btn-area"><a href="javascript:;" class="reply-commit" data-uid="' + c.authorid + '" data-pid="' + c.pid + '" data-tid="' + c.tid + '" data-fid="' + c.fid + '">\u53d1\u5e03</a><a href="javascript:;" class="reply-cancel">\u53d6\u6d88</a></div></div>',
            a += "</div>",
            a += "</li>"
        }
        a = $(a),
        a.find(".reply-btn").on("click",
        function() {
            var i = $(this).parent().parent().parent();
            i.find(".reply-area").css("height", "auto")
        }),
        a.find(".reply-cancel").on("click",
        function() {
            $(this).parent().parent().css("height", "0")
        }),
        a.find(".reply-commit").on("click",
        function() {
            var t = $(this),
            e = t.parent().parent(),
            a = e.find(".reply-con").val();
            i(a, t.data("uid"), t.data("pid"))
        }),
        $(e).append(a)
    }
	var a = $(".comment-area-v2");
    if (a && !(a.length <= 0)) {
        var s = a.data("type"),
        l = a.data("id"),
        fid = a.data("fid"),
        formhash = a.data("formhash");
        c = '<div class="add-comment">';
        c += '<p class="head">\u8bc4\u8bba</p>',
        c += '<div class="text-area">',
        c += '<textarea class="add-con" placeholder="\u6211\u4e5f\u6765\u8bf4\u4e24\u53e5"></textarea>',
        c += '<a href="javascript:;" class="btn">\u53d1\u8868\u8bc4\u8bba</a>',
        c += "</div>",
        c += "</div>";
        var n = $(c);
        n.find(".text-area .btn").on("click",
        function() {
            var t = n.find(".add-con").val();
            if (t !== null && t !== undefined && t !== '') { 
            	i(t, null, null)
            }else{
            	alert('\u8bc4\u8bba\u5185\u5bb9\u4e0d\u80fd\u4e3a\u7a7a\u0021');
            	return;
            }
        });
        var o = '<ul class="comment-list"></ul>',
        r = $(o),
        d = '<a href="javascript:;" class="more-comment">\u67e5\u770b\u66f4\u591a\u8bc4\u8bba</a>',
        p = $(d);
        p.on("click",
        function() {
            t()
        }),
        a.append(n).append(r).append(p);
        var v = 0,
        u = 3,
        f = 1,
        h = "";
        if ("topic" == s) h = "plugin.php?id=jzsjiale_daogou:api&a=getcomments";
        else {
            if ("post" != s) return;
            h = "plugin.php?id=jzsjiale_daogou:api&a=getcomments"
        }
        t()
    }
    
   
}


Util.loadTopicRelationRec = function(topicId,obj,num, w, ar){
    var createTopicRelationRecHTML = function(topic,num, w, ar){
    	
    	var uri = "forum.php?mod=viewthread&tid=";
		var uri2 = "";
		
		if(ar == 1){
			if(w == 2){
				uri = "topic-";
				uri2 = ".html";
			}else if(w == 3){
				uri = "topic_";
				uri2 = ".html";
			}else if(w == 4){
				uri = "post-";
				uri2 = ".html";
			}else if(w == 5){
				uri = "post_";
				uri2 = ".html";
			}else{
				uri = "plugin.php?id=jzsjiale_daogou:article&tid=";
				uri2 = "";
			}
		}

		if(ar == 0){
			if(w == 1){
				uri = "thread-";
				uri2 = "-1-1.html";
			}else{
				uri = "forum.php?mod=viewthread&tid=";
				uri2 = "";
			}
		}
		
        if(topic.length <= 0){
            return;
        }
        var len = num;
        if(topic.length < num){
            len = topic.length;
        }
        var htmlStr = '<div class="relation-rec">' +
            '<h4 class="head">\u731c\u4f60\u559c\u6b22</h4>';
        for(var i=0;i<len;i++){
            var t = topic[i];
            htmlStr += '<a href="' + uri + t.tid + uri2 +'">';
            htmlStr += '<div class="relation-rec-item">' +
            '<div class="rr-cover" style="background-image: url(' + t.cover + ');"></div>' +
            '<div class="rr-info">' +
            '<p class="rr-title elli">'+ t.subject +'</p>' +
            '<div class="rr-stat">' +
            '<div class="rr-user"><div class="rr-avatar" style="background-image: url(uc_server/avatar.php?uid=' + t.authorid + '&size=small);"></div><p class="rr-nickname">'+ t.author +'</p></div>' +
            '<div class="rr-count"><i class="views"></i>'+ t.views +'<i class="comment"></i>'+ t.replies +'</div>' +
            '</div>' +
            '</div>' +
            '</div>';
            htmlStr += '</a>';
        }
         htmlStr += '</div>';

        obj.html(htmlStr);
        //Util.deepShareLinks('deep-share-link');
        $('.relation-rec-item').on('click',function(){
            Util.gaEventMethod('global:click:recommend_topic_item');
        });
        $('.more-rr-btn').on('click',function(){
            Util.gaEventMethod('global:click:more_recommend_topic');
        });
    }

    $.ajax({
        url:'plugin.php?id=jzsjiale_daogou:api&a=relationrec',
        type:'GET',
        dataType:'json',
        data:{
        	tid: topicId,
            num:num
        },
        success:function(data){
            if(data.code == 200){
                createTopicRelationRecHTML(data.data,num, w, ar);
            }
        }
    });
}


Util.lazyLoad = function(cn){
    var lazyImg = $('.'+cn);

    lazyImg.each(function(){
        var _this = $(this);
        var url = _this.attr('data-original');

        $('<img />').one('load',function(){
            if(_this.is('img')){
                _this.attr('src',url);
            }else{
                _this.css('background-image','url('+url+')');
            }
            setTimeout(function(){
                _this.css('opacity','1');
            },15);
        }).one('error',function(){
            _this.css('opacity','1');
        }).attr('src',url);
    });
}

Util.bantangVersion = function(){
    var ua = window.navigator.userAgent+' ';
    var version = ua.match(/bantang\/.+? /);
    if(!version){
        return;
    }
    version = version[0];
    version = version.substring(8);
    version = version.split('.');

    var newVersion = '';
    for(var i=0;i<4;i++){
        if(version[i]){
            newVersion += (version[i]*1 + 1000).toString().substring(1);
        }else{
            newVersion += '000';
        }
    }

    return newVersion*1;
}

Util.isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i) ? true : false;
    },
    BlackBerry: function() {
        return navigator.userAgent.match(/BlackBerry/i) ? true : false;
    },
    iOS: function() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i) ? true : false;
    },
    Windows: function() {
        return navigator.userAgent.match(/IEMobile/i) ? true : false;
    },
    Weixin: function(){
        return navigator.userAgent.match(/MicroMessenger/i) ? true : false;
    },
    Bantang: function(){
        return navigator.userAgent.match(/bantang/i) ? true : false;
    },
    any: function() {
        return (Util.isMobile.Android() || Util.isMobile.BlackBerry()
        || Util.isMobile.iOS() || Util.isMobile.Windows() || Util.isMobile.Weixin());
    }
};

Util.dockBar = function(){
    if($('#noDock').val() == 1){
        return;
    }
    var topicId = $('#topicId').val();
    var fid = $('#fid').val();
    var pid = $('#pid').val();
    var tuijianmobile = $('#tuijianmobile').val();
    var medit = $('#medit').val();
    
    var tuijiadiv = "";
    if(tuijianmobile && topicId && fid){
    	tuijiadiv = '<a href="plugin.php?id=jzsjiale_daogou:tuijian&dulixiangqing=1&tid='+topicId+'&fid='+fid+'"  class="btn deep-share-link" >\u63a8\u0020\u0020\u0020\u0020\u8350</a>';
    }
    
    var meditdiv = "";
    if(medit == '1'){
    	meditdiv = '<a href="xiewenzhang.html?fid='+fid+'&tid='+topicId+'&pid='+pid+'"  class="btn deep-share-link" >\u7f16\u0020\u0020\u0020\u0020\u8f91</a>';
    }else if(medit == '2'){
    	meditdiv = '<a href="plugin.php?id=jzsjiale_daogou:xiewenzhang&fid='+fid+'&tid='+topicId+'&pid='+pid+'"  class="btn deep-share-link" >\u7f16\u0020\u0020\u0020\u0020\u8f91</a>';
    }else if(medit == '3'){
    	meditdiv = '<a href="forum.php?mod=post&action=edit&fid='+fid+'&tid='+topicId+'&pid='+pid+'"  class="btn deep-share-link" >\u7f16\u0020\u0020\u0020\u0020\u8f91</a>';
    }else{
    	meditdiv = '';
    }
    
    var currUrl = window.location.href;

        var dock = '<div id="topBar" class="top-bar" style="z-index:99;">' +
            '<a href="javascript:window.history.back();location.reload(); "><div class="logo"></div></a>' +
            '<a href="#topic-comment-area"  class="btn deep-share-link" >\u8bc4\u0020\u0020\u0020\u0020\u8bba</a>' +
            tuijiadiv+
            meditdiv+
            '</div>';



        var wrap = $('.wrapper');
        if(window.location.pathname != '/'){
            wrap.append(dock).css('padding-top','60px')
        }

        //$('.bottom-container').html(bottomDock);
        Util.gaEvent();
    /*
      }
      */
}

Util.scrollTo = function(scrollTo, time) {
    var scrollFrom = parseInt(document.body.scrollTop),
        i = 0,
        runEvery = 5;

    scrollTo = parseInt(scrollTo);
    time /= runEvery;

    var interval = setInterval(function () {
        i++;

        document.body.scrollTop = (scrollTo - scrollFrom) / time * i + scrollFrom;

        if (i >= time) {
            clearInterval(interval);
        }
    }, runEvery);
}

Util.scrollEvent = function(handler,h){
    $(document).on('scroll',function(){
        var _top = $('body').scrollTop(),
            scroll_height = document.documentElement.scrollHeight,
            client_height = document.documentElement.clientHeight;
        if(_top + client_height >= (scroll_height-h)){
            handler();
        }
    });
}

Util.linkedmeInit = function(cb){
    if('undefined' == typeof linkedme){
        return;
    }
    var lkm_data = {};
    lkm_data.type = "test";
    linkedme.init("e35767f329c6f554e7fc01ab809e8017", lkm_data, function(err, data){
        if(err){
            // 初始化失败
        } else {
            // 初始化成功
        }
        cb();
    });
}
/*
Util.deepShareLinks = function(cn){
    var dsl = $('.'+cn);
    dsl.each(function(i){
        var _this = $(this);
        var os = 'other';
        if(Util.isMobile.iOS()){
            os = 'iOS';
        }else if(Util.isMobile.Android()){
            os = 'Android';
        }
        var paramsJson = {
            inapp_data:{
                url:_this.data('dp-link'),
                ref:window.location.href,
                os:os,
                browser:window.navigator.userAgent
            }
        };

        var lkm_data = {};
        lkm_data.type = "test";
        lkm_data.params = JSON.stringify(paramsJson);
        lkm_data.req_version = encodeURIComponent(_this.data('dp-link'));

        linkedme.link(lkm_data, function (err, data) {
            if (err) {
                _this.attr('href', _this.data('dp-link'));
            } else {
                _this.attr('data-ds-link',data.url);
            }
        }, false);

        // $.ajax({
        //     url:'https://fds.so/v2/url/21e0c7d8bf287288',
        //     type:'POST',
        //     dataType:'string',
        //     data:JSON.stringify(paramsJson),
        //     success:function(result){
        //         result = JSON.parse(result);
        //         _this.data('ds-link',result.url);
        //     },
        //     error:function(){
        //         _this.attr('href',_this.data('dp-link'));
        //     }
        // });
    });

    dsl.unbind('click').on('click',function() {
        var _this = $(this);
        if(_this.hasClass('opt-download-show')){
            var toUrl = 'http://m.ibantang.com/dp/';
            if(_this.data('ds-link')){
                toUrl = _this.data('ds-link');
            }
            Util.DownloadShow({
                url:toUrl,
                content:'用<span style="color:#333;padding: 0 2px;">半糖App</span>打开<br><span style="color:#fd6363;">收藏、购买</span>心仪好物更方便！'
            });
        }else if(_this.hasClass('comment-download-show')){
            var toUrl = 'http://m.ibantang.com/dp/';
            if(_this.data('ds-link')){
                toUrl = _this.data('ds-link');
            }
            Util.DownloadShow({
                url:toUrl,
                content:'用<span style="color:#333;padding: 0 2px;">半糖App</span>打开<br>参与更多<span style="color:#fd6363;">互动、评论</span>'
            });
        }else if(_this.hasClass('normal-download-show')){
            var toUrl = 'http://m.ibantang.com/dp/';
            if(_this.data('ds-link')){
                toUrl = _this.data('ds-link');
            }
            Util.DownloadShow({
                url:toUrl
            });
        }else{
            if(_this.data('ds-link')){
                Util.gaEventMethod('global:click:deep_share');
                location.href = _this.data('ds-link');
            }else{
                location.href = 'http://m.bantangapp.com/appview/downapp.html';
            }
        }
    });
}
*/
Util.cutMainContent = function(cn,h){
    var obj = $('.'+cn);
    if(obj && obj.height() > h){
        obj.css({
            'overflow':'hidden',
            'position':'relative'
        });
        obj.css('height',h+'px');
        obj.append('<p class="read-complete"><span class="read-complete-btn">\u9605\u8bfb\u5168\u6587<i class="arr-down-blue"></i></span></p>');
        $('.read-complete').on('click',function(){
            obj.css('height','auto');
            $(this).remove();
            Util.gaEventMethod('global:click:read_the_full_article');
        });
    }
}

Util.gaEvent = function(){
    if(window.location.href.indexOf('m.ibantang.com') < 0){
        return;
    }
    $('[data-ga-event]').on('click',function(){
        var _this = $(this);
        var gaEventStr = _this.attr('data-ga-event');
        Util.gaEventMethod(gaEventStr);
    });
}

Util.gaEventMethod = function(gaEventStr){
    var gaParmas = gaEventStr.split(':');
    if(typeof ga != 'undefined' && gaParmas.length >= 3){
        ga('send','event',gaParmas[0],gaParmas[1],gaParmas[2]);
    }
}

Util.urlDir = function(url,type){
    if(Util.bantangVersion() >= 5008003000){
        url = 'bantang://com.jzyd.BanTang/openWebview?url='+encodeURIComponent(url);
        if(type){
            url += '&type=1';
        }
    }
    window.location.href = url;
}

function commonInit($){
    Util.dockBar();

    Util.linkedmeInit(function(){
        Util.deepShareLinks('deep-share-link');
    })

    Util.loadTopicComment();

    Util.cutMainContent('article-wrapper', 1000);

    Util.gaEvent();

    var seoDesc = $('.seo-desc'),
        seoDescHead = seoDesc.find('.head');
    seoDescHead.on('click',function(){
        if(seoDesc.hasClass('active')){
            seoDesc.removeClass('active').css('height','44px');
        }else{
            seoDesc.addClass('active').css('height','auto');
        }
    });
}

if('undefined' != typeof Zepto) {
    Zepto(function ($) {
        commonInit($);
    });
}else if('undefined' != typeof jQuery){
    $(function(){
        commonInit($);
    });
}