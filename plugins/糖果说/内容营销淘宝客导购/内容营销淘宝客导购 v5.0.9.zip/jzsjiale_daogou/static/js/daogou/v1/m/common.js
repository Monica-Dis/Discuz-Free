var Util = Util || {};

Util.pageSize = function() {
    var i = document.documentElement,
    e = ["clientWidth", "clientHeight", "scrollWidth", "scrollHeight"],
    t = {};
    for (var a in e) t[e[a]] = i[e[a]];
    return t.scrollLeft = document.body.scrollLeft || document.documentElement.scrollLeft,
    t.scrollTop = document.body.scrollTop || document.documentElement.scrollTop,
    t
}

Util.modelClose = function(o, m) {
    o.fadeOut(function() {
        o.remove();
    });
    m.fadeOut(function() {
        m.remove();
        $('body').css("overflow","auto");
    })
};



Util.getQueryString = function(url){
    var queryString = url.split('?')[1];
    if(!queryString) return;
    queryString = queryString.split('&');
    var queries = {};
    for(var i= 0,len=queryString.length;i<len;i++){
        var tmp = queryString[i].split('=');
        queries[''+tmp[0]] = tmp[1];
    }
    return queries;
}


Util.scrollEvent = function(i, e) {
    $(document).on("scroll",
    function() {
        var t = $(document).scrollTop(),
        a = Util.pageSize().scrollHeight,
        s = Util.pageSize().clientHeight;
        t + s >= a - e && i()
    })
}

Util.lazyLoad = function(cn){
    var lazyImg = $('.'+cn);

    lazyImg.each(function(){
        var _this = $(this);
        var url = _this.attr('data-original');

        $('<img />').one('load',function(){
            if(_this.is('img')){
                _this.attr('src',url);
            }else{
                _this.css('background-image','url('+url+')');
            }
            setTimeout(function(){
                _this.css('opacity','1');
            },15);
        }).one('error',function(){
            _this.css('opacity','1');
        }).attr('src',url);
    });
}


Util.isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i) ? true : false;
    },
    BlackBerry: function() {
        return navigator.userAgent.match(/BlackBerry/i) ? true : false;
    },
    iOS: function() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i) ? true : false;
    },
    Windows: function() {
        return navigator.userAgent.match(/IEMobile/i) ? true : false;
    },
    Weixin: function(){
        return navigator.userAgent.match(/MicroMessenger/i) ? true : false;
    },
    Bantang: function(){
        return navigator.userAgent.match(/bantang/i) ? true : false;
    },
    any: function() {
        return (Util.isMobile.Android() || Util.isMobile.BlackBerry()
        || Util.isMobile.iOS() || Util.isMobile.Windows() || Util.isMobile.Weixin());
    }
};


Util.scrollTo = function(scrollTo, time) {
    var scrollFrom = parseInt(document.body.scrollTop),
        i = 0,
        runEvery = 5;

    scrollTo = parseInt(scrollTo);
    time /= runEvery;

    var interval = setInterval(function () {
        i++;

        document.body.scrollTop = (scrollTo - scrollFrom) / time * i + scrollFrom;

        if (i >= time) {
            clearInterval(interval);
        }
    }, runEvery);
}