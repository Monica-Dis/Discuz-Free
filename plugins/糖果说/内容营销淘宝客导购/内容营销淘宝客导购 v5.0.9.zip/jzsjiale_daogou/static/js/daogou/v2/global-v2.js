var Util = Util || {};
Util.flag = {
    productLikeFlag: 1,
    topicCollectFlag: 1
},
Util.pageSize = function() {
    var i = document.documentElement,
    t = ["clientWidth", "clientHeight", "scrollWidth", "scrollHeight"],
    e = {};
    for (var a in t) e[t[a]] = i[t[a]];
    return e.scrollLeft = document.body.scrollLeft || document.documentElement.scrollLeft,
    e.scrollTop = document.body.scrollTop || document.documentElement.scrollTop,
    e
},
Util.DownloadShow = function(i) {
    var t = '<div class="left-bg"><img src="/img/download-model-left.jpg"/></div><div class="code"><img src="http://7xo1vw.com1.z0.glb.clouddn.com/qrcode/qrcode.png" alt=""/></div><p class="desc">\u626b\u63cf\u4e8c\u7ef4\u7801\uff0c\u4e0b\u8f7d\u0041\u0050\u0050</p>',
    e = {
        maskerID: "downloadModelOverlay",
        contentID: "downloadModelContent",
        alpha: .6,
        bgColor: "#000",
        dbclick: !0,
        keydown: !0,
        mZindex: 9997,
        cZindex: 9999,
        height: 410,
        contentHTML: t
    };
    if (i && "object" == typeof i) for (var a in i) a.match(/^_/) || (e[a] = i[a]);
    var s = Util.pageSize().scrollWidth,
    l = Util.pageSize().scrollHeight;
    $(window).size(function() {
        s = Util.pageSize().scrollWidth,
        l = Util.pageSize().scrollHeight
    });
    var c = Math.floor((Util.pageSize().clientHeight - e.height) / 2),
    n = '<div id="' + e.maskerID + '" style="position:fixed;left:0;top:0;right:0;bottom:0;z-index:' + e.mZindex + ';background-color:rgba(0,0,0,.7);opacity:0;"><div class="model-close-area"><i class="icons model-close"></i></div></div>',
    o = '<div id="' + e.contentID + '" class="model-dialog" style="z-index:' + e.cZindex + ";top:" + c + 'px;opacity:0;transition: all .3s ease-out;transform:translate(0,-20px)">';
    o += e.contentHTML,
    o += "</div>",
    $(n).appendTo("body"),
    $(o).appendTo("body");
    var r = $("#" + e.maskerID),
    d = $("#" + e.contentID);
    setTimeout(function() {
        r.css("opacity", "1"),
        d.css({
            opacity: "1",
            transform: "translate(0,0)"
        })
    },
    20);
    var p = $(".icon-close");
    p && p.click(function() {
        Util.modelClose(r, d)
    }),
    e.dbclick && r.click(function(i) {
        i = i || window.event;
        i.srcElement ? i.srcElement: i.target;
        Util.modelClose(r, d)
    }),
    e.keydown && (document.onkeydown = function(i) {
        i = window.event || i;
        i.keyCode || i.which || i.charCode;
        27 == i.keyCode && Util.modelClose(r, d)
    })
},
Util.modelClose = function(i, t) {
    i.css("opacity", "0"),
    t.css({
        opacity: "0",
        transform: "translate(0,-20px)"
    }),
    setTimeout(function() {
        i.remove(),
        t.remove()
    },
    300)
},
Util.scrollHeader = function() {
    $(window).on("scroll",
    function() {
        $(document).scrollTop() >= 200 ? $("body").removeClass("home-header") : $("body").addClass("home-header")
    })
},
Util.logoutModel = function() {
	$.ajax({
        url: "plugin.php?id=jzsjiale_daogou:api&a=phonelogout",
        type: "POST",
        dataType: "json",
        data: {
        	formhash: $("#phoneformhash").val()
        },
        success: function(i) {
            200 == i.code ? window.location.reload() : window.location.href="member.php?mod=logging&action=logout&formhash="+$("#phoneformhash").val()
        }
    })
},
Util.loginModel = function(i) {
	
    function t() {
        v.hide(),
        p.show()
    }
    function e() {
        p.hide(),
        v.show()
    }
    function a() {
        var pf = $("#phoneformhash").val(),
        t = $("#loginMobile").val(),
        e = $("#loginPwd").val(),
        loginErr = $("#loginErr");
        return t ? e ? void $.ajax({
            url: "plugin.php?id=jzsjiale_daogou:api&a=phonelogin",
            type: "POST",
            dataType: "json",
            data: {
                phone: t,
                password: e,
                formhash:pf
            },
            beforeSend: function() {},
            success: function(t) {
                200 == t.code ? i ? (loginErr.html(""),Util.modelClose($("#downloadModelOverlay"), $("#loginModelContent")), window.location.href.indexOf("xiewenzhang") > 0 && setInterval(function() {
                    ArticleUtil.saveJSON($(".edit-content"), "edit-unit", 1)
                },
                3e4)) : window.location.reload() : msg(loginErr,t.data)
            }
        }) : void loginErr.html("\u8bf7\u8f93\u5165\u5bc6\u7801") : void loginErr.html("\u8bf7\u8f93\u5165\u624b\u673a\u53f7")
    }
    function s() {
        var i = $("#regMobile").val(),
        regErr = $("#regErr");
        return i ? void $.ajax({
            url: "plugin.php?id=jzsjiale_daogou:api&a=sendseccode",
            type: "POST",
            dataType: "json",
            data: {
                phone: i,
                type:1
            },
            beforeSend: function() {},
            success: function(i) {
                200 == i.code ? l() : msg(regErr,i.data)
            },
            error: function(i) {
            	regErr.html("\u53d1\u9001\u5931\u8d25\uff01")
            }
        }) : void regErr.html("\u8bf7\u8f93\u5165\u624b\u673a\u53f7")
    }
    function l() {
    	var regErr = $("#regErr");
    	regErr.html("");
        k.hasClass("disabled") || (k.unbind("click").addClass("disabled"), w = setInterval(function() {
            0 >= b ? (clearInterval(w), w = null, k.html("\u83b7\u53d6\u9a8c\u8bc1\u7801").bind("click",
            function() {
                s()
            }).removeClass("disabled"), b = 59) : (k.html(b + "\u79d2\u540e\u91cd\u65b0\u83b7\u53d6"), b--)
        },
        1e3))
    }
    function c() {
        var pf = $("#phoneformhash").val(),
        u = $("#regUsername").val(),
        i = $("#regMobile").val(),
        t = $("#regAuthCode").val(),
        e = $("#regPwd").val(),
        regErr = $("#regErr");
        return u ? i ? t ? e ?  void $.ajax({
            url: "plugin.php?id=jzsjiale_daogou:api&a=phoneregister",
            type: "POST",
            dataType: "json",
            data: {
            	username: u,
                phone: i,
                password: e,
                seccode: t,
                formhash:pf
            },
            beforeSend: function() {},
            success: function(i) {
                200 == i.code ? window.location.reload() : msg(regErr,i.data)
            }
        }) : void regErr.html("\u8bf7\u8f93\u5165\u5bc6\u7801") : void regErr.html("\u8bf7\u8f93\u5165\u9a8c\u8bc1\u7801") : void regErr.html("\u8bf7\u8f93\u5165\u624b\u673a\u53f7") : void regErr.html("\u8bf7\u8f93\u5165\u7528\u6237\u540d")
    }
    function msg(err,msgdata) {
    	
    	switch (msgdata) {
        case "smsconfigerror":
        	err.html("\u670d\u52a1\u5668\u77ed\u4fe1\u914d\u7f6e\u9519\u8bef");
            break;
        case "peizhierror":
        	err.html("\u670d\u52a1\u5668\u77ed\u4fe1\u914d\u7f6e\u9519\u8bef");
            break;
        case "notopenregister":
        	err.html("\u672a\u5f00\u542f\u6ce8\u518c\u9a8c\u8bc1\u77ed\u4fe1\u53d1\u9001\u529f\u80fd");
            break;
        case "notopenyanzheng":
        	err.html("\u672a\u5f00\u542f\u8eab\u4efd\u9a8c\u8bc1\u77ed\u4fe1\u53d1\u9001\u529f\u80fd");
            break;
        case "notopenlogin":
        	err.html("\u672a\u5f00\u542f\u767b\u5f55\u9a8c\u8bc1\u77ed\u4fe1\u53d1\u9001\u529f\u80fd");
            break;
        case "notopenmima":
        	err.html("\u672a\u5f00\u542f\u4fee\u6539\u5bc6\u7801\u9a8c\u8bc1\u77ed\u4fe1\u53d1\u9001\u529f\u80fd");
            break;
        case "paramerror":
        	err.html("\u624b\u673a\u9a8c\u8bc1\uff1a\u7f3a\u5c11\u53c2\u6570\u6216\u53c2\u6570\u9519\u8bef\u0021");
            break;
        case "bind_phone_error":
        	err.html("\u624b\u673a\u53f7\u683c\u5f0f\u4e0d\u6b63\u786e");
            break;
        case "err_phonebind":
        	err.html("\u8be5\u624b\u673a\u53f7\u7801\u5df2\u88ab\u5176\u4ed6\u7528\u6237\u7ed1\u5b9a\u4f7f\u7528\uff0c\u8bf7\u66f4\u6362\u5176\u4ed6\u624b\u673a\u53f7\u7801");
            break;
        case "err_nouser":
        	err.html("\u62b1\u6b49\uff0c\u8be5\u624b\u673a\u6682\u672a\u7ed1\u5b9a\u7528\u6237\u540d");
            break;
        case "err_seccodexiane":
        	err.html("\u62b1\u6b49\uff0c\u60a8\u7684\u624b\u673a\u4f7f\u7528\u77ed\u4fe1\u9a8c\u8bc1\u7801\u8d85\u8fc7\u6bcf\u65e5\u9650\u989d");
            break;
        case "generatecodeerror":
        	err.html("\u751f\u6210\u9a8c\u8bc1\u7801\u5931\u8d25");
            break;
        case "err_seccodefasong":
        	err.html("\u540c\u4e00\u624b\u673a\u53f7\u7801\u0031\u5206\u949f\u5185\u53ea\u5141\u8bb8\u53d1\u9001\u4e00\u6b21\u9a8c\u8bc1\u7801\uff0c\u0031\u5c0f\u65f6\u5185\u53ea\u5141\u8bb8\u53d1\u9001\u0035\u6761");
            break;
        case "smssuccess":
        	err.html("\u53d1\u9001\u6210\u529f");
            break;
        case "smserror":
        	err.html("\u53d1\u9001\u5931\u8d25");
            break;
        case "phonenull":
        	err.html("\u624b\u673a\u53f7\u4e0d\u80fd\u4e3a\u7a7a");
            break;
        case "seccodenull":
        	err.html("\u9a8c\u8bc1\u7801\u4e0d\u80fd\u4e3a\u7a7a");
            break;
        case "usernamenull":
        	err.html("\u7528\u6237\u540d\u4e0d\u80fd\u4e3a\u7a7a");
            break;
        case "passwordnull":
        	err.html("\u5bc6\u7801\u4e0d\u80fd\u4e3a\u7a7a");
            break;
        case "err_seccodeguoqi":
        	err.html("\u77ed\u4fe1\u9a8c\u8bc1\u7801\u5df2\u8fc7\u671f");
            break;
        case "err_seccodeerror":
        	err.html("\u77ed\u4fe1\u9a8c\u8bc1\u7801\u586b\u5199\u9519\u8bef");
            break;
        case "phonecunzai":
        	err.html("\u8be5\u624b\u673a\u53f7\u5df2\u88ab\u522b\u4eba\u7ed1\u5b9a");
            break;
        case "usernamecunzai":
        	err.html("\u8be5\u7528\u6237\u540d\u5df2\u5b58\u5728");
            break;
        case "registererror":
        	err.html("\u6ce8\u518c\u5931\u8d25");
            break;
        case "registersuccess":
        	err.html("\u6ce8\u518c\u6210\u529f");
            break;
        case "registersuccess_phoneerror":
        	err.html("\u6ce8\u518c\u6210\u529f\u002c\u4f46\u624b\u673a\u7ed1\u5b9a\u5931\u8d25");
            break;
        case "password6":
        	err.html("\u5bc6\u7801\u4e0d\u5f97\u5c0f\u4e8e\u0036\u4f4d");
            break;
        case "err_weibangding":
        	err.html("\u8be5\u624b\u673a\u53f7\u5e76\u672a\u6ce8\u518c\u6216\u672a\u7ed1\u5b9a\u7f51\u7ad9\u8d26\u53f7");
            break;
        case "mimaerror":
        	err.html("\u5bc6\u7801\u9519\u8bef");
            break;
        case "loginerror":
        	err.html("\u7528\u6237\u4fe1\u606f\u6821\u9a8c\u9519\u8bef\uff0c\u767b\u5f55\u5931\u8d25\uff01");
            break;
        case "err_location_login_force_qq":
        	err.html("\u60a8\u6240\u5728\u7684\u7528\u6237\u7ec4\u5fc5\u987b\u4f7f\u7528\u0051\u0051\u5e10\u53f7\u767b\u5f55");
            break;
        case "err_location_login_force_mail":
        	err.html("\u60a8\u6240\u5728\u7684\u7528\u6237\u7ec4\u5fc5\u987b\u4f7f\u7528\u90ae\u7bb1\u767b\u5f55");
            break;
        case "err_location_login_outofdate":
        	err.html("\u60a8\u5f53\u524d\u7684\u5e10\u53f7\u5df2\u7ecf\u592a\u957f\u65f6\u95f4\u672a\u767b\u5f55\u7f51\u7ad9\u5df2\u7ecf\u88ab\u51bb\u7ed3\uff0c\u5fc5\u987b\u9a8c\u8bc1\u90ae\u7bb1\u540e\u624d\u80fd\u89e3\u9664\u51bb\u7ed3\u72b6\u6001");
            break;
        case "loginsuccess":
        	err.html("\u767b\u5f55\u6210\u529f");
            break;
        default:
        	err.html("\u64cd\u4f5c\u5931\u8d25\uff01");
            break;
        }
    	
    	
    }
    
    var issms = $('#issms').val();
    var mobileflag = $('#mobileflag').val();
    if(issms==0){
    	if(mobileflag == 1){
    		window.location.href="member.php?mod=logging&action=login&mobile=2";
    	}else{
    		window.location.href="member.php?mod=logging&action=login";
    	}
    	
    	//window.open("member.php?mod=logging&action=login");
    	return;
    }
    
    var limg = $("#loginlogo").val();
    //var n = '<div class="model-inner"><div class="code-area" style="background:url('+limg+') center no-repeat #f5f5f5;width:420px;height:160px;background-size:cover;"></div><div class="log-reg-area"><div class="inner"><div class="login-area"><input type="text" id="loginMobile" placeholder="\u624b\u673a\u53f7"/><input type="password" id="loginPwd" placeholder="\u5bc6\u7801"/><p class="err-msg" id="loginErr"></p><a href="javascript:;" class="btn" id="loginBtn">\u767b\u5f55</a><p class="toggle" id="showReg">\u6ce8\u518c</p></div><div class="reg-area"><input type="text" id="regMobile" placeholder="\u624b\u673a\u53f7"/><input class="auth-code" type="text" id="regAuthCode" placeholder="\u9a8c\u8bc1\u7801"/><a class="btn auth-code-btn" id="getAuthCodeBtn">\u83b7\u53d6\u9a8c\u8bc1\u7801</a><div class="clear"></div><input type="password" id="regPwd" placeholder="\u5bc6\u7801"/><p class="err-msg" id="regErr"></p><a href="javascript:;" class="btn reg-btn" id="regBtn">\u6ce8\u518c</a><p class="toggle" id="showLogin">\u767b\u5f55</p></div><p class="third-title">\u793e\u4ea4\u8d26\u53f7\u5feb\u901f\u767b\u5f55</p><div class="third"><a target="_blank" title="\u5fae\u535a\u767b\u5f55" href="/account/oauth2/weibo/" class="item weibo"><i class="icons weibo-login"></i><p>\u5fae\u535a</p></a><a target="_blank" title="\u0051\u0051\u767b\u5f55" href="/account/oauth2/qq/" class="item qq"><i class="icons qq-login"></i><p>QQ</p></a></div></div></div></div>',
    var n = '<div class="model-inner"><div class="code-area" style="background:url('+limg+') center no-repeat #f5f5f5;width:420px;height:160px;background-size:cover;"></div><div class="log-reg-area"><div class="inner"><div class="login-area"><input type="text" id="loginMobile" placeholder="\u624b\u673a\u53f7"/><input type="password" id="loginPwd" placeholder="\u5bc6\u7801"/><p class="err-msg" id="loginErr"></p><a href="javascript:;" class="btn" id="loginBtn">\u767b\u5f55</a><p class="toggle" id="showReg">\u6ce8\u518c</p></div><div class="reg-area"><input type="text" id="regUsername" placeholder="\u7528\u6237\u540d"/><input type="text" id="regMobile" placeholder="\u624b\u673a\u53f7"/><input class="auth-code" type="text" id="regAuthCode" placeholder="\u9a8c\u8bc1\u7801"/><a class="btn auth-code-btn" id="getAuthCodeBtn">\u83b7\u53d6\u9a8c\u8bc1\u7801</a><div class="clear"></div><input type="password" id="regPwd" placeholder="\u5bc6\u7801"/><p class="err-msg" id="regErr"></p><a href="javascript:;" class="btn reg-btn" id="regBtn">\u6ce8\u518c</a><p class="toggle" id="showLogin">\u767b\u5f55</p></div></div></div></div>',
    o = {
        contentID: "loginModelContent",
        height: 580,
        contentHTML: n
    };
    Util.DownloadShow(o);
    var r = $("#showLogin"),
    d = $("#showReg"),
    p = $(".login-area"),
    v = $(".reg-area"),
    u = $(".third .item");
    u.click(function() {
        Util.modelClose($("#downloadModelOverlay"), $("#loginModelContent"))
    }),
    r.click(function() {
        t()
    }),
    d.click(function() {
        e()
    });
    var f = $("#loginBtn"),
    h = $("#loginPwd"),
    m = $("#regPwd"),
    g = $("#regBtn"),
    k = $("#getAuthCodeBtn");
    f.click(function() {
        a()
    }),
    h.on("keyup",
    function(i) {
        var t = i.keyCode;
        13 == t && a()
    }),
    k.click(function() {
        s()
    }),
    g.click(function() {
        c()
    }),
    m.on("keyup",
    function(i) {
        var t = i.keyCode;
        13 == t && c()
    });
    var b = 59,
    w = null
   
},
Util.shareOption = function(i, t) {
    switch (i) {
    case "weixin":
        var e = window.location.href;
        var sharepopupimgs = $('#articlehidden');
        var siteurl = sharepopupimgs.data("siteurl");
        var sharepopupimg = sharepopupimgs.data("sharepopupimg");
        var sharepopuplogo = sharepopupimgs.data("sharepopuplogo");
        var n = "plugin.php?id=jzsjiale_daogou:qrcode&url=" + encodeURIComponent(e),
        o = '<div class="left-bg"><img src="' + sharepopupimg + '"/></div><div class="code" style="background:url('+sharepopuplogo+') center no-repeat;background-size: 160px 215px;"><img src="' + n + '"/></div><p class="desc">\u6253\u5f00\u5fae\u4fe1\u626b\u4e00\u626b\uff0c\u5373\u53ef\u5206\u4eab\u7ed9\u597d\u53cb</p>';
        Util.DownloadShow({
            contentHTML: o
        });
        break;
    case "weibo":
        var r = "http://service.weibo.com/share/share.php?";
        r += "url=" + encodeURIComponent(location.href + "?ref=webshare&cate=weibo"),
        r += "&appkey=2463269013",
        r += "&pic=" + $("#sharePic").val(),
        r += "&title=" + $("#shareTitle").val(),
        r += "&ralateUid=",
        r += "&searchPic=false",
        t.attr("href", r);
        break;
    case "qq-space":
        var r = "http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?";
        r += "url=" + encodeURIComponent(location.href + "?ref=webshare&cate=qq_space"),
        r += "&pics=" + $("#sharePic").val().replace(/\|\|/g, "|"),
        r += "&title=" + $("#shareTitle").val(),
        t.attr("href", r);
        break;
    case "qq":
        var r = "http://connect.qq.com/widget/shareqq/index.html?";
        r += "url=" + encodeURIComponent(location.href + "?ref=webshare&cate=qq_friends"),
        r += "&site=" + encodeURIComponent("\u534a\u7cd6"),
        r += "&desc=" + $("#shareTitle").val(),
        t.attr("href", r)
    }
},
Util.scrollToTop = function(i) {
    var t = $("body,html");
    20 > i ? t.scrollTop(0) : t.stop(!0, !0).animate({
        scrollTop: 0
    },
    i)
},
Util.sideFixedMenu = function(i, t, e, a) {
    if (i && t && !(t.length <= 0)) {
        e || (e = 2e3);
        var s = $(document),
        l = ($("body"), i.width()),
        c = Math.floor(l / 2) + 40,
        n = "";
        for (var o = 0,
        r = t.length; r > o; o++) switch (t[o]) {
        case "back-to-top":
            n += '<div class="side-fixed-menu" style="margin-left: ' + c + 'px;">';
            n += '<div class="menu-item" id="backToTop">',
            n += '<i class="bt-iconfont if-back-to-top"></i>',
            n += "<p>\u8fd4\u56de\u9876\u90e8</p>",
            n += "</div>";
            n += "</div>";
            break;
        case "m-back-to-top":
            n += '<div class="side-fixed-menu" style="right: 5%;">';
            n += '<div class="menu-item" id="backToTop">',
            n += '<i class="bt-iconfont if-back-to-top"></i>',
            n += "</div>";
            n += "</div>";
            break;
        case "topic-like":
            n += '<div class="side-fixed-menu" style="margin-left: ' + c + 'px;">';
            n += '<div class="menu-item' + (a ? " liked": "") + '" id="topicLike">',
            n += '<i class="bt-iconfont if-like"></i>',
            n += "<p>" + (a ? "\u53d6\u6d88\u6536\u85cf": "\u6536\u85cf\u6e05\u5355") + "</p>",
            n += "</div>";
            n += "</div>";
            break;
        case "product-like":
            n += '<div class="side-fixed-menu" style="margin-left: ' + c + 'px;">';
            n += '<div class="menu-item' + (a ? " liked": "") + '" id="productLike">',
            n += '<i class="bt-iconfont if-like"></i>',
            n += "<p>" + (a ? "\u53d6\u6d88\u6536\u85cf": "\u6536\u85cf\u5355\u54c1") + "</p>",
            n += "</div>"
            n += "</div>";
        }
        var d = $(n);
        d.find("#backToTop").on("click",
        function() {
            Util.scrollToTop(300)
        }),
        d.find("#productLike").on("click",
        function() {
            var i = $(this),
            t = 1;
            i.hasClass("liked") && (t = 2);
            var e = $("#productId").val();
            Util.productLike(e, t, i)
        }),
        d.find("#topicLike").on("click",
        function() {
            var i = $(this),
            t = 1;
            i.hasClass("liked") && (t = 2);
            var e = $("#topicId").val();
            Util.topicCollect(e, t, i)
        }),
        d.appendTo($("body")),
        $(window).on("scroll",
        function() {
            var i = s.scrollTop();
            i > e ? d.fadeIn(100) : d.fadeOut(100)
        })
    }
},
Util.allCateStruct = function(i, t, e, a) {
    function s(s) {
        var l = 50,
        c = "",
        n = "";
        n += '<div class="cate-content-area" style="left:' + t + 'px;">',
        c += '<div class="cate-struct-area" style="width:' + t + 'px;">',
        c += '<p class="title">\u5168\u90e8\u5206\u7c7b</p><div class="h-dashed-3"></div>',
        c += '<ul class="cate-1-list">';
        for (var o = 0,
        r = s.length; r > o; o++) {
            l += e + 1,
            c += '<li data-id="' + s[o].id + '" data-level="1" d-i="' + o + '" data-index="' + o + '" style="height:' + e + "px;line-height:" + e + 'px;"><i class="before-arr"></i><p>' + s[o].name + '</p><div class="h-dashed-3"></div><i class="after-arr"></i></li>';
            var d = s[o].subCate;
            n += '<div data-index="' + o + '" class="cate-2-list">',
            n += '<div class="inner">';
            for (var p = 0,
            v = d.length; v > p; p++) {
                var u = "http://7viiaj.com2.z0.glb.qiniucdn.com/newcategory/";
                u += (1 * d[p].pid + 1e3).toString().substring(1),
                u += "/" + (1 * d[p].id + 1e3).toString().substring(1) + ".png",
                n += '<div class="cate-2-list-item">',
                n += '<div class="pic"><img src="' + u + '"/></div>',
                n += '<div class="info">',
                n += '<p data-id="' + d[p].id + '" data-level="2" d-i="' + o + '" d-j="' + p + '" class="title cate-unit">' + d[p].name + "</p>",
                n += '<ul class="cate-3-list clearfix">';
                for (var f = d[p].subCate, h = 0, m = f.length; m > h; h++) n += '<li class="cate-unit" data-id="' + f[h].id + '" data-level="3" d-i="' + o + '" d-j="' + p + '" d-k="' + h + '">' + f[h].name + "</li>";
                n += "</ul>",
                n += "</div>",
                n += "</div>",
                p % 3 == 2 && (n += '<div class="clear"></div>')
            }
            n += '<div class="clear"></div>',
            n += "</div>",
            n += "</div>"
        }
        c += "</ul>",
        c += "</div>",
        n += "</div>";
        var g = $(n),
        k = $(c);
        k.append(g),
        k.find(".cate-unit").click(function() {
            var i = $(this);
            $(".cate-1-list li.selected").removeClass("selected"),
            $($(".cate-1-list li")[i.attr("d-i")]).addClass("selected"),
            a(s, i.attr("data-level"), i.attr("data-id"), i.attr("d-i"), i.attr("d-j"), i.attr("d-k")),
            $(".cate-2-list").css("z-index", "1").hide()
        });
        var b = k.find(".cate-1-list li");
        b.each(function() {
            var i = $(this).attr("data-index"),
            t = k.find(".cate-2-list[data-index=" + i + "]");
            t.find(".inner").css("min-height", 50 * (1 * i + 2) - 70 + "px");
            var a = 0,
            s = Math.floor(50 + i * (e + 1) + e / 2),
            l = s - a;
            t.css("top", a + "px"),
            t.find(".inner .before-arr").css("top", l + "px"),
            t.find(".inner .after-arr").css("top", l + "px")
        }),
        b.on("mouseenter",
        function() {
            var i = $(this);
            i.find("i").css("display", "block");
            var t = $(this).attr("data-index"),
            e = k.find(".cate-2-list[data-index=" + t + "]"),
            a = $(document).scrollTop();
            if (a > 30) {
                var s = a - 30;
                e.css("top", s + "px"),
                e.find(".inner").css("min-height", 50 * (1 * t + 2) - 70 - s + "px")
            } else e.css("top", "0px"),
            e.find(".inner").css("min-height", 50 * (1 * t + 2) - 70 + "px");
            e.css("z-index", "10").show()
        }).on("mouseleave",
        function() {
            var i = $(this);
            i.find("i").css("display", "none");
            var t = $(this).attr("data-index");
            k.find(".cate-2-list[data-index=" + t + "]").css("z-index", "1").hide()
        }),
        g.find(".cate-2-list").on("mouseenter",
        function() {
            var i = $(this),
            t = i.attr("data-index");
            k.find(".cate-1-list li[data-index=" + t + "]").find("i").css("display", "block"),
            $(this).css("z-index", "10").show()
        }).on("mouseleave",
        function() {
            var i = $(this),
            t = i.attr("data-index");
            k.find(".cate-1-list li[data-index=" + t + "]").find("i").css("display", "none"),
            $(this).css("z-index", "1").hide()
        }),
        i.html("").append(k)
    }
    $.ajax({
        url: "",
        type: "GET",
        dataType: "json",
        data: {},
        success: function(i) {
            s(i)
        }
    })
},
Util.scrollEvent = function(i, t) {
    $(document).on("scroll",
    function() {
        var e = $(document).scrollTop(),
        a = Util.pageSize().scrollHeight,
        s = Util.pageSize().clientHeight;
        e + s >= a - t && i()
    })
},
Util.createTopicList = function(i, t, e, a) {
    for (var s = "",
    l = 0,
    c = e.length; c > l; l++) {
        var n = e[l];
        if ((2 != n.type || 0 != n.type_id) && 6 != n.type) {
            var o = n.cover || n.pic || n.pics && n.pics.length > 0 && n.pics[0].url || "";
            a && "recommend" == a && n.pics && n.pics.length > 0 && (o = n.pics[0].url),
            o = o.replace("!300x300", "!w600");
            var r = n.description ? n.description: n.desc;
            s += '<div class="topic-item">',
            s += '<a target="_blank" title="' + n.title + '" href="/topic/' + n.id + '/">',
            s += '<div class="cover-area"><div class="cover"><img src="' + o + '" alt="' + n.title + '"/></div></div>',
            s += '<div class="detail">',
            s += '<p class="title">' + n.title + "</p>",
            s += '<p class="desc">' + r || "</p>",
            s += '<div class="info">',
            s += '<div class="stat">',
            s += '<i class="bt-iconfont if-view"></i>' + (n.views || "0"),
            s += '<i class="bt-iconfont if-like pl"></i>' + (n.likes || "0"),
            s += "</div>",
            s += "</div>",
            s += "</div>",
            s += "</a>",
            s += "</div>"
        }
    }
    1 == t ? i.html(s) : i.append(s)
},
Util.createTopicListV2 = function(i, e, t, w, ar) {
	var uri = "forum.php?mod=viewthread&tid=";
	var uri2 = "";
	
	if(ar == 1){
		if(w == 2){
			uri = "topic-";
			uri2 = ".html";
		}else if(w == 3){
			uri = "topic_";
			uri2 = ".html";
		}else if(w == 4){
			uri = "post-";
			uri2 = ".html";
		}else if(w == 5){
			uri = "post_";
			uri2 = ".html";
		}else{
			uri = "plugin.php?id=jzsjiale_daogou:article&tid=";
			uri2 = "";
		}
	}

	if(ar == 0){
		if(w == 1){
			uri = "thread-";
			uri2 = "-1-1.html";
		}else{
			uri = "forum.php?mod=viewthread&tid=";
			uri2 = "";
		}
	}
	
    for (var a = "",
    s = 0,
    l = t.length; l > s; s++) {
        var c = t[s];
        if (1 != c.status) {
            a += '<div class="topic-item">',
            a += '<a target="_blank" title="' + c.subject + '" href="' + uri + c.tid + uri2 +'">',
            a += '<div class="cover-area"><div class="cover"><img src="' + c.cover + '" alt="' + c.subject + '"/></div></div>',
            a += '<div class="detail">',
            a += '<p class="title elli">' + c.subject + "</p>",
            a += '<p class="desc">' + c.message + "</p>",
            a += '<div class="info">',
            a += '<div class="user">',
            a += '<div class="avatar" style="background-image: url(uc_server/avatar.php?uid=' + c.authorid + '&size=small);"></div>',
            a += '<p class="nickname">' + c.author + "</p>",
            a += "</div>",
            a += '<div class="stat">',
            a += '<i class="bt-iconfont if-view"></i>' + (c.views || "0"),
            a += '<i class="bt-iconfont if-comment pl"></i>' + (c.replies || "0"),
            a += "</div>",
            a += "</div>",
            a += "</div>",
            a += "</a>",
            a += "</div>"
        }
    }
    1 == e ? i.html(a) : i.append(a)
},
Util.createTopicListV3 = function(i, t, e, w, ar) {
	var uri = "forum.php?mod=viewthread&tid=";
	var uri2 = "";
	
	if(ar == 1){
		if(w == 2){
			uri = "topic-";
			uri2 = ".html";
		}else if(w == 3){
			uri = "topic_";
			uri2 = ".html";
		}else if(w == 4){
			uri = "post-";
			uri2 = ".html";
		}else if(w == 5){
			uri = "post_";
			uri2 = ".html";
		}else{
			uri = "plugin.php?id=jzsjiale_daogou:article&tid=";
			uri2 = "";
		}
	}

	if(ar == 0){
		if(w == 1){
			uri = "thread-";
			uri2 = "-1-1.html";
		}else{
			uri = "forum.php?mod=viewthread&tid=";
			uri2 = "";
		}
	}

	
    for (var a = "",
    s = 0,
    l = e.length; l > s; s++) {
        var c = e[s];
        if (1 != c.status) {
            a += '<div class="topic-item-v3">',
            a += '<a target="_blank" title="' + c.subject + '" href="' + uri + c.tid + uri2 +'">',
            a += '<div class="cover-area"><img class="lazy new" data-original="' + c.cover + '" alt="' + c.subject + '"/></div>',
            a += '<p class="title elli">' + c.subject + "</p>",
            a += '<div class="info">',
            a += '<div class="user">',
            a += '<div class="avatar" style="background-image: url(uc_server/avatar.php?uid=' + c.authorid + '&size=small);"></div>',
            a += '<p class="nickname elli">' + c.author + "</p>",
            a += "</div>",
            a += '<div class="stat">',
            a += '<i class="bt-iconfont if-view"></i>' + (c.views || "0"),
            a += '<i class="bt-iconfont if-comment pl"></i>' + (c.replies || "0"),
            //a += '<i class="bt-iconfont if-like pl"></i>' + (c.replies || "0"),
            a += "</div>",
            a += "</div>",
            a += "</a>",
            a += "</div>"
        }
    }
    1 == t ? i.html(a) : i.append(a),
    Util.lazyLoad("lazy.new"),
    $(".lazy.new").removeClass(".new")
},
Util.createProductList = function(i, t, e) {
    for (var a = "",
    s = 0,
    l = e.length; l > s; s++) {
        var c = e[s].pic;
        c || (c = e[s].picUrl),
        a += '<div class="goods-item"><a target="_blank" title="' + e[s].title + '" href="/product/' + e[s].id + '/"><div class="cover"><img src="' + c + '" alt="' + e[s].title + '"/></div><p class="title elli">' + e[s].title + '</p><p class="stat"><span class="price">&yen;' + e[s].price + '</span><span class="like"><i class="icons topic-item-like"></i>' + e[s].likes + "</span></p></a></div>"
    }
    1 == t ? i.html(a) : i.append(a)
},
Util.createProductListV2 = function(i, t, j) {
    for (var e = "",
    a = 0,
    s = t.length; s > a; a++) {
        var l = t[a];
        var tdj = '';
    	if(j > 0 && l.numiid != '' &&  l.url.indexOf("uland.taobao.com/coupon") < 0){
    		tdj = 'data-type="0" isconvert="1" biz-itemid="'+l.numiid+'"';
    	}
    	if(l.youhuiquan != ""){
            e += '<a target="_blank"  '+tdj+'title="' + l.title + '" href="' + l.youhuiquan + '">';
        }else{
            e += '<a target="_blank"  '+tdj+'title="' + l.title + '" href="' + l.url + '">';
        }
        e += '<div class="product-item-v2">';
        e += '<div class="pic"><img class="lazy new" data-original="' + l.img + '" alt="' + l.title + '"></div>';
        e += '<p class="title elli">' + l.title + "</p>";
        e += '<p class="info">';
        if(l.usertype == 1){
            e += '<span class="user_type_tmall">\u5929\u732b</span>';
        }else{
            e += '<span class="user_type_taobao">\u6dd8\u5b9d</span>';
        }
        e += '<span class="price number-font">&yen;' + l.xianjia + "</span>";
        //e += '<span class="like"><i class="bt-iconfont if-like"></i>' + (l.likes || "\u559c\u6b22") + "</span>";
        if(l.couponamount != "" && l.couponamount > 0){
            e += '<span class="like"><i class="bt-iconfont if-like"></i>' + l.couponamount + "\u5143\u4f18\u60e0\u5238</span>";
        }
        e += "</p>";
        e += "</div>";
        e += "</a>";
    }
    i.append(e),
    Util.lazyLoad("lazy.new"),
    $(".lazy.new").removeClass(".new")
},
Util.createSouQuanProductList = function(i, t, j) {
        for (var e = "",
                 a = 0,
                 s = t.length; s > a; a++) {
            var l = t[a];
            var tdj = '';
            if(j > 0 && l.numiid != '' &&  l.url.indexOf("uland.taobao.com/coupon") < 0){
                tdj = 'data-type="0" isconvert="1" biz-itemid="'+l.numiid+'"';
            }
            if(l.youhuiquan != ""){
                e += '<a target="_blank"  '+tdj+'title="' + l.title + '" href="' + l.youhuiquan + '">';
            }else{
                e += '<a target="_blank"  '+tdj+'title="' + l.title + '" href="' + l.url + '">';
            }
            e += '<div class="product-item-v2">';
            e += '<div class="pic"><img class="lazy new" data-original="' + l.img + '" alt="' + l.title + '"></div>';
            e += '<p class="title elli">' + l.title + "</p>";
            e += '<p class="info">';
            if(l.user_type == 1){
                e += '<span class="user_type_tmall">\u5929\u732b</span>';
            }else{
                e += '<span class="user_type_taobao">\u6dd8\u5b9d</span>';
            }
            e += '<span class="price number-font">&yen;' + l.xianjia + "</span>";
            //e += '<span class="like"><i class="bt-iconfont if-like"></i>' + (l.likes || "\u559c\u6b22") + "</span>";
            if(l.couponamount != "" && l.couponamount > 0){
                e += '<span class="like"><i class="bt-iconfont if-like"></i>' + l.couponamount + '\u5143\u4f18\u60e0\u5238</span>';
            }
            e += "</p>";
            e += "</div>";
            e += "</a>";
        }
        i.append(e),
            Util.lazyLoad("lazy.new"),
            $(".lazy.new").removeClass(".new")
},
Util.createSinglePicProductList = function(i, t, e) {
    for (var a = "",
    s = 0,
    l = e.length; l > s; s++) {
        var c = e[s].pic;
        c || (c = e[s].picUrl),
        a += '<div class="goods-item"><a title="' + e[s].title + '" href="/product/' + e[s].id + '/"><div class="cover"><img src="' + c + '" alt="' + e[s].title + '"/></div></a></div>'
    }
    1 == t ? i.html(a) : i.append(a)
},
Util.createPostList = function(i, t, e) {
    for (var a = "",
    s = 0,
    l = e.length; l > s; s++) {
        var c = e[s],
        n = c.id,
        o = c.middle_pic_url;
        o || (o = c.PostPics[0].url),
        o = o.replace("!w300", "/300x300");
        var r = "",
        d = "",
        p = "";
        c.user ? (r = c.user.avatar, d = c.user.nickname, p = c.user.user_id) : (r = c.UserProfile.avatar, d = c.UserProfile.nickname, p = c.UserProfile.user_id);
        var v = 0;
        v = c.dynamic ? c.dynamic.likes: c.likes;
        var u = c.content;
        a += '<div class="post-item"><a target="_blank" title="' + d + '\u7684\u5206\u4eab" href="/post/' + n + '/"><div class="cover"><img src="' + o + '" alt="' + d + '\u7684\u5206\u4eab"/></div></a><div class="info"><div class="user"><a target="_blank" title="' + d + '\u7684\u9996\u9875" href="/u/' + p + '/"><div class="avatar" style="background-image: url(' + r + ');filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src="' + r + '", sizingMethod=scale);"></div></a><p class="nickname elli">' + d + '</p></div><span class="like"><i class="icons topic-item-like"></i>' + v + '</span></div><p class="content">' + (u.length > 44 ? u.substring(0, 44) + "...": u) + "</p></div>"
    }
    1 == t ? i.html(a) : i.append(a)
},
Util.createPostListV3 = function(i, t) {
    for (var e = "",
    a = 0,
    s = t.length; s > a; a++) {
        var l = t[a];
        e += '<a target="_blank" href="/post/' + l.id + '/">',
        e += '<div class="post-item-v3">',
        e += '<div class="pic"><img class="lazy new" data-original="' + (l.pics && l.pics.length > 0 ? l.pics[0].url: l.middle_pic_url) + '"></div>',
        e += '<div class="info">',
        e += '<div class="user">',
        e += '<div class="avatar" style="background-image: url(' + l.user.avatar + ');"></div>',
        e += '<p class="nickname elli">' + l.user.nickname + "</p>",
        e += "</div>",
        e += '<span class="like"><i class="bt-iconfont if-like"></i>' + (l.dynamic.likes || "\u559c\u6b22") + "</span>",
        e += "</div>",
        e += '<p class="content">' + l.content + "</p>",
        e += "</div>",
        e += "</a>"
    }
    i.append(e),
    Util.lazyLoad("lazy.new"),
    $(".lazy.new").removeClass(".new")
},
Util.createLikeBoxList = function(i, t, e) {
    for (var a = "",
    s = 0,
    l = e.length; l > s; s++) a += '<div data-id="' + e[s].id + '" data-title="' + e[s].title + '" data-count="' + e[s].count + '" class="like-box-item"><div class="cover" style="background-image: url(' + e[s].cover + ');filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src="' + e[s].cover + '", sizingMethod=scale);"></div><p class="title">' + e[s].title + '</p><p class="stat">' + e[s].count + "&nbsp;\u5355\u54c1</p></div>";
    1 == t ? i.html(a) : i.append(a)
},
Util.productLike = function(i, t, e) {
    Util.flag.productLikeFlag && $.ajax({
        url: "/product/like",
        type: "GET",
        dataType: "json",
        data: {
            productId: i,
            type: t
        },
        beforeSend: function() {
            Util.flag.productLikeFlag = 0
        },
        success: function(i) {
            1 == i.code ? 1 == t ? (e.addClass("liked"), e.hasClass("menu-item") && e.find("p").css("top", "40px").html("\u53d6\u6d88\u6536\u85cf"), e.find(".like-count").length > 0 && e.find(".like-count").html("\u5df2\u559c\u6b22"), Util.likeOptTips("\u6210\u529f\u6dfb\u52a0\u81f3\u300c\u6211\u7684\u559c\u6b22\u300d")) : (e.removeClass("liked"), e.hasClass("menu-item") && e.find("p").css("top", "40px").html("\u6536\u85cf\u5355\u54c1"), e.find(".like-count").length > 0 && e.find(".like-count").html(e.attr("data-likes"))) : -2 == i.code ? Util.loginModel() : console.log(i.msg),
            Util.flag.productLikeFlag = 1
        }
    })
},
Util.productLikeEvent = function() {
    var i = $(".product-card .pc-like-area");
    i.click(function() {
        var i = $(this),
        t = i.data("product-id");
        if (t && "undefined" != t) {
            var e = 1;
            i.hasClass("liked") && (e = 2),
            Util.productLike(t, e, i)
        }
    })
},
Util.topicCollect = function(i, t, e) {
    Util.flag.topicCollectFlag && $.ajax({
        url: "/topic/collect",
        type: "GET",
        dataType: "json",
        data: {
            topicId: i,
            type: t
        },
        beforeSend: function() {
            Util.flag.topicCollectFlag = 0
        },
        success: function(i) {
            1 == i.code ? 1 == t ? (e.addClass("liked"), e.hasClass("menu-item") && e.find("p").css("top", "40px").html("\u53d6\u6d88\u6536\u85cf"), Util.likeOptTips("\u6210\u529f\u6536\u85cf\u81f3\u6211\u7684\u300c\u6e05\u5355\u300d")) : (e.removeClass("liked"), e.hasClass("menu-item") && e.find("p").css("top", "40px").html("\u6536\u85cf\u6e05\u5355")) : -2 == i.code ? Util.loginModel() : console.log(i.msg),
            Util.flag.topicCollectFlag = 1
        }
    })
},
Util.likeOptTips = function(i) {
    var t = '<div class="like-opt-tips">';
    t += '<i class="icons like-tips"></i>',
    t += "<p>" + i + "</p>",
    t += "</div>";
    var e = $(".suser-area");
    e.prepend(t),
    setTimeout(function() {
        e.find(".like-opt-tips").css("opacity", "0")
    },
    2e3)
},
Util.loadTopicComment = function(i, t, e, a) {
    $.ajax({
        url: "/topic/getComments",
        type: "GET",
        dataType: "json",
        data: {
            id: i,
            page: t,
            pagesize: e
        },
        success: function(i) {
            1 == i.code && a(i.data)
        }
    })
},
Util.createTopicCommentsHTML = function(i, t) {
    for (var e = "",
    a = 0,
    s = i.length; s > a; a++) {
        var l = i[a];
        e += '<li class="comment-item" data-comment-id="' + l.id + '">',
        e += '<a target="_blank" title="' + l.user.nickname + '\u7684\u9996\u9875" href="/u/' + l.user.user_id + '">',
        e += '<div class="avatar" style="background-image: url(' + l.user.avatar + ');"></div>',
        e += "</a>",
        e += '<div class="info">',
        e += '<p class="nickname">',
        e += '<a href="javascript:;">' + l.user.nickname + "</a>",
        e += "</p>",
        e += '<p class="content">' + (l.at_user.nickname ? "\u56de\u590d<span>@" + l.at_user.nickname + "：</span>": "") + l.conent + "</p>",
        e += '<p class="stats">' + l.datestr + "</p>",
        e += "</div>",
        e += "</li>"
    }
    $(t).append(e)
},
Util.loadCommentV2 = function() {
    function i(i, t, p) {
        var a = "";
        "topic" == s ? a = "plugin.php?id=jzsjiale_daogou:api&a=addcomment": "post" == s && (a = "plugin.php?id=jzsjiale_daogou:api&a=addcomment"),
        $.ajax({
            url: a,
            type: "POST",
            dataType: "json",
            data: {
                tid: l,
                content: i,
                fid: fid,
                atUserId: t,
                pid: p,
                formhash:formhash
            },
            beforeSend: function() {},
            success: function(i) {
                200 == i.code ? (alert("\u8bc4\u8bba\u53d1\u5e03\u6210\u529f"), window.location.reload()) : -2 == i.code && (alert('\u8bf7\u5148\u767b\u5f55'),Util.loginModel())
            },
            error: function() {
            	alert("\u53d1\u8868\u8bc4\u8bba\u5931\u8d25\u002c\u8bf7\u91cd\u8bd5\u0021");
            }
        })
    }
    function t() {
        0 != f && $.ajax({
            url: h,
            type: "GET",
            dataType: "json",
            data: {
                tid: l,
                page: v,
                pagesize: u
            },
            beforeSend: function() {
                f = 0
            },
            success: function(i) {
                200 == i.code && (e(i.data, r), i.data.length >= u ? (v++, f = 1, p.css("display", "block")) : (p.css("display", "none"), $(".comment-item:last-child").css("border-bottom", "none")))
            },
            error: function(i) {
                
            }
        })
    }
    function e(t, e) {
        for (var a = "",
        s = 0,
        l = t.length; l > s; s++) {
            var c = t[s];
            a += '<li class="comment-item">',
            a += '<a target="_blank" title="' + c.author + '\u7684\u9996\u9875" href="' + c.userhome + '">',
            a += '<div class="avatar" style="background-image: url(' + c.avatar + ');"></div>',
            a += "</a>",
            a += '<div class="info">',
            a += '<p class="nickname">',
            a += '<a href="javascript:;">' + c.author + "</a>",
            a += "</p>",
            a += '<p class="content">' + c.message + "</p>"
            //c.img_piclist && (a += c.messageimg),
            var aimg = "";
            if(typeof(c.img_piclist) != "undefined"){
            	for(var j in c.img_piclist){
                    if(c.img_piclist[j].length != undefined){
                    	aimg+='<a href="'+c.img_piclist[j]+'" target="_blank"><img src="'+c.img_piclist[j]+'" style="width:60px;height:auto;"/></a>'
                        
                    }
                }
            
            }
            a+=aimg,
            c.messagequote && c.quotepid && (a += '<p class="at-comment"><span class="at-user">' + c.quoteauthor + ":</span>" + c.messagequote + "</p>"),
            a += '<p class="stats">' + c.dateline + '<span class="reply-btn">\u56de\u590d</span></p>',
            a += '<div class="reply-area"><div class="reply-con-area"><textarea class="reply-con" placeholder="\u56de\u590d @' + c.author + '"></textarea></div><div class="reply-btn-area"><a href="javascript:;" class="reply-commit" data-uid="' + c.authorid + '" data-pid="' + c.pid + '" data-tid="' + c.tid + '" data-fid="' + c.fid + '">\u53d1\u5e03</a><a href="javascript:;" class="reply-cancel">\u53d6\u6d88</a></div></div>',
            a += "</div>",
            a += "</li>"
        }
        a = $(a),
        a.find(".reply-btn").on("click",
        function() {
            var i = $(this).parent().parent().parent();
            i.find(".reply-area").css("height", "auto")
        }),
        a.find(".reply-cancel").on("click",
        function() {
            $(this).parent().parent().css("height", "0")
        }),
        a.find(".reply-commit").on("click",
        function() {
            var t = $(this),
            e = t.parent().parent(),
            a = e.find(".reply-con").val();
            i(a, t.data("uid"), t.data("pid"))
        }),
        $(e).append(a)
    }
    var a = $(".comment-area-v2");
    if (a && !(a.length <= 0)) {
        var s = a.data("type"),
        l = a.data("id"),
        fid = a.data("fid"),
        formhash = a.data("formhash");
        c = '<div class="add-comment">';
        c += '<p class="head">\u8bc4\u8bba</p>',
        c += '<div class="text-area">',
        c += '<textarea class="add-con" placeholder="\u6211\u4e5f\u6765\u8bf4\u4e24\u53e5"></textarea>',
        c += '<a href="javascript:;" class="btn">\u53d1\u8868\u8bc4\u8bba</a>',
        c += "</div>",
        c += "</div>";
        var n = $(c);
        n.find(".text-area .btn").on("click",
        function() {
            var t = n.find(".add-con").val();
            if (t !== null && t !== undefined && t !== '') { 
            	i(t, null, null)
            }else{
            	alert('\u8bc4\u8bba\u5185\u5bb9\u4e0d\u80fd\u4e3a\u7a7a\u0021');
            	return;
            }
            
        });
        var o = '<ul class="comment-list"></ul>',
        r = $(o),
        d = '<a href="javascript:;" class="more-comment">\u67e5\u770b\u66f4\u591a\u8bc4\u8bba</a>',
        p = $(d);
        p.on("click",
        function() {
            t()
        }),
        a.append(n).append(r).append(p);
        var v = 0,
        u = 20,
        f = 1,
        h = "";
        if ("topic" == s) h = "plugin.php?id=jzsjiale_daogou:api&a=getcomments";
        else {
            if ("post" != s) return;
            h = "plugin.php?id=jzsjiale_daogou:api&a=getcomments"
        }
        t()
    }
},
Util.loadTopicRelationRec = function(i,num, t, w, ar) {
    var e = function(i,num,w,ar) {
    	
    		var uri = "forum.php?mod=viewthread&tid=";
    		var uri2 = "";
    		
    		if(ar == 1){
    			if(w == 2){
    				uri = "topic-";
    				uri2 = ".html";
    			}else if(w == 3){
    				uri = "topic_";
    				uri2 = ".html";
    			}else if(w == 4){
    				uri = "post-";
    				uri2 = ".html";
    			}else if(w == 5){
    				uri = "post_";
    				uri2 = ".html";
    			}else{
    				uri = "plugin.php?id=jzsjiale_daogou:article&tid=";
    				uri2 = "";
    			}
    		}

    		if(ar == 0){
    			if(w == 1){
    				uri = "thread-";
    				uri2 = "-1-1.html";
    			}else{
    				uri = "forum.php?mod=viewthread&tid=";
    				uri2 = "";
    			}
    		}
    	
        if (! (i.length <= 0)) {
            var e = num;
            i.length < num && (e = i.length);
            for (var a = '<div class="relation-rec"><h4 class="head">\u731c\u4f60\u559c\u6b22</h4>',
            s = 0; e > s; s++) {
                var l = i[s];
                a += '<a href="' + uri + l.tid + uri2 +'">',
                a += '<div class="relation-rec-item"><div class="rr-cover" style="background-image: url(' + l.cover + ');"></div><div class="rr-info"><p class="rr-title elli">' + l.subject + '</p><div class="rr-stat"><div class="rr-user"><div class="rr-avatar" style="background-image: url(uc_server/avatar.php?uid=' + l.authorid + '&size=small);"></div><p class="rr-nickname">' + l.author + '</p></div><div class="rr-count"><i class="bt-iconfont if-view"></i>' + l.views + "</div></div></div></div>",
                a += "</a>"
            }
            a += "</div>",
            t.html(a)
        }
    };
    $.ajax({
        url: "plugin.php?id=jzsjiale_daogou:api&a=relationrec",
        type: "GET",
        dataType: "json",
        data: {
            tid: i,
            num:num
        },
        success: function(i) {
            200 == i.code && e(i.data,num,w,ar)
        }
    })
},
Util.loadTopicHotList = function(i, t, e) {
    var a = function(i) {
        if (! (i.length <= 0)) {
            var a = e || 2;
            i.length < a && (a = i.length);
            for (var s = '<div class="relation-rec">',
            l = 0; a > l; l++) {
                var c = i[l];
                s += '<a href="/topic/' + c.id + '/">',
                s += '<div class="relation-rec-item"><div class="rr-cover" style="background-image: url(' + (c.pic || c.pics[0].url) + ');"></div><div class="rr-info"><p class="rr-title">' + c.title + '</p><div class="rr-stat"><div class="rr-user"><div class="rr-avatar" style="background-image: url(' + c.user.avatar + ');"></div><p class="rr-nickname">' + c.user.nickname + '</p></div><div class="rr-count"><i class="bt-iconfont if-view"></i>' + c.views + "</div></div></div></div>",
                s += "</a>"
            }
            s += "</div>",
            t.html(s)
        }
    };
    $.ajax({
        url: "/topic/hotList",
        type: "GET",
        dataType: "json",
        data: {
            typeId: 0
        },
        success: function(i) {
            1 == i.code && a(i.data.topic)
        }
    })
},
Util.shareAreaInit = function() {
    var i = $(".share-area-v2"),
    t = '<p class="share-title">\u5206\u4eab\u7ed9\u670b\u53cb</p>';
    t += '<div class="share-list">',
    t += '<a href="javascript:;" class="share-item wx-share-show"><i class="share-icon share-icon-weixin-friend"></i></a>',
    t += '<a href="javascript:;" class="share-item wx-share-show"><i class="share-icon share-icon-weixin-timeline"></i></a>',
    t += '<a href="javascript:;" target="_blank" class="share-item wb-share-show"><i class="share-icon share-icon-weibo"></i></a>',
    t += '<a href="javascript:;" target="_blank" class="share-item qq-share-show"><i class="share-icon share-icon-qzone"></i></a>',
    t += '<a href="javascript:;" target="_blank" class="share-item qq-share-show"><i class="share-icon share-icon-qq"></i></a>',
    t += "</div>",
    i.html(t)
},
Util.getXiangguanhaowu = function() {
	var fid = $("#xiangguanhaowufid").val();
	var articleid = $("#topicId").val();
	var pid = $("#pid").val();
	var isopenzhtglj = $("#isopenzhtglj").val();
	
	var a = function(i) {
        if (! (i.length <= 0)) {
        	var t = $(".xiangguan-products");
        	t.show();
            var a = i.length;
            for (var s = '<p class="head">\u76f8\u5173\u597d\u7269</p>',
            l = 0; a > l; l++) {
                var c = i[l];
                
                var tdj = '';
            	if(isopenzhtglj > 0 && c.numiid != '' &&  c.url.indexOf("uland.taobao.com/coupon") < 0){
            		tdj = 'data-type="0" isconvert="1" biz-itemid="'+c.numiid+'"';
            	}
                s += '<a class="rp-item" '+tdj+' href="'+c.url+'" style="padding:7px 18px 0 0;" target="_blank">',
                s += '<div class="inner">',
                s += '<div class="rp-cover" style="background-image:url(\''+c.img+'\');"></div>',
                s += '<p class="rp-title elli">'+c.title+'</p>',
                s += '<p class="rp-stat elli" style="border-bottom: 0;">',
                s += '<span class="price-number number-font">&yen;' + c.xianjia + '</span>',
                s += '</p>',
                s += '</div>',
                s += "</a>"
            }
            s += '<div class="clear"></div>',
            s += '<b class="h5line"></b>',
            t.html(s)
        }
    };
    $.ajax({
        url: "plugin.php?id=jzsjiale_daogou:api&a=getxiangguanhaowu",
        type: "GET",
        dataType: "json",
        data: {
        	tid:articleid,
        	pid:pid,
        	fid:fid
        },
        success: function(e) {
            200 == e.code && a(e.data)
        }
    })
},
Util.getTidaodehaowu = function() {
	var fid = $("#fid").val();
	var articleid = $("#topicId").val();
	var pid = $("#pid").val();
	var isopenzhtglj = $("#isopenzhtglj").val();
	
	var a = function(i) {
        if (! (i.length <= 0)) {
        	var t = $(".reference-products");
        	t.show();
            var a = i.length;
            for (var s = '<p class="head">\u63d0\u5230\u7684\u597d\u7269</p>',
            l = 0; a > l; l++) {
                var c = i[l];
                
                var tdj = '';
            	if(isopenzhtglj > 0 && c.numiid != '' &&  c.url.indexOf("uland.taobao.com/coupon") < 0){
            		tdj = 'data-type="0" isconvert="1" biz-itemid="'+c.numiid+'"';
            	}
                s += '<a class="rp-item" '+tdj+' href="'+c.url+'" style="padding:7px 18px 0 0;" target="_blank">',
                s += '<div class="inner">',
                s += '<div class="rp-cover" style="background-image:url(\''+c.img+'\');"></div>',
                s += '<p class="rp-title elli">'+c.title+'</p>',
                s += '<p class="rp-stat elli" style="border-bottom: 0;">',
                s += '<span class="price-number number-font">&yen;' + c.xianjia + '</span>',
                s += '</p>',
                s += '</div>',
                s += "</a>"
            }
            s += '<div class="clear"></div>',
            s += '<b class="h5line"></b>',
            t.html(s)
        }
    };
    $.ajax({
        url: "plugin.php?id=jzsjiale_daogou:api&a=gettidaodehaowu",
        type: "GET",
        dataType: "json",
        data: {
        	tid:articleid,
        	pid:pid,
        	fid:fid
        },
        success: function(e) {
            200 == e.code && a(e.data)
        }
    })
},
Util.rightSideFix = function(i) {
    i = i || 30;
    var t = $(".wrapper-950-r .inner");
    $(window).on("scroll",
    function() {
        $(document).scrollTop() >= i ? t.addClass("fixed") : t.removeClass("fixed")
    })
},
Util.lazyLoad = function(i) {
    var t = $("." + i);
    t.each(function() {
        var i = $(this),
        t = i.attr("data-original");
        $("<img />").one("load",
        function() {
            i.is("img") ? i.attr("src", t) : i.css("background-image", "url(" + t + ")"),
            setTimeout(function() {
                i.css("opacity", "1")
            },
            15)
        }).one("error",
        function() {
            i.css("opacity", "1")
        }).attr("src", t)
    })
},
$(function() {
    function i(i) {
        window.location.href = "plugin.php?id=jzsjiale_daogou:search&q=" + i
    }
    var t = $("#searchForm"),
    e = t.find("input"),
    a = t.find("a");
    e.on("focus",
    function() {
        "\u641c\u7d22\u4f60\u60f3\u8981\u7684" == $(this).val() && $(this).val("")
    }).on("blur",
    function() {
        "" == $(this).val() && $(this).val("\u641c\u7d22\u4f60\u60f3\u8981\u7684")
    }).on("keyup",
    function(t) {
        var e = t.keyCode,
        a = $(this).val();
        13 == e && a && i(a)
    }),
    a.bind("click",
    function() {
        var t = e.val();
        "\u641c\u7d22\u4f60\u60f3\u8981\u7684" != t.trim() && i(t)
    }),
    Util.productLikeEvent(),
    Util.loadCommentV2();
    var s = $(".collect-btn");
    s.on("click",
    function() {
        var i = $(this),
        t = i.data("tid");
        i.hasClass("liked") ? Util.topicCollect(t, 2, i) : Util.topicCollect(t, 1, i)
    }),
    Util.shareAreaInit(),

  
    $(".login-btn").click(function() {
    	var issms = $('#issms').val();
    	if(issms == 1){
    		Util.loginModel();
    	}else{
    		//window.open("member.php?mod=logging&action=login");
        	return;
    	}
        
    }),
    $(".phonelogout-btn").click(function() {
    	Util.logoutModel();
        
    }),
    $(".download-show").on("click focus",
    function() {
        Util.DownloadShow()
    }),
    $(".wx-share-show").click(function() {
        Util.shareOption("weixin")
    }),
    $(".wb-share-show").click(function() {
        Util.shareOption("weibo", $(this))
    }),
    $(".qs-share-show").click(function() {
        Util.shareOption("qq-space", $(this))
    }),
    $(".qq-share-show").click(function() {
        Util.shareOption("qq", $(this))
    }),
    $("[data-ga-event]").click(function() {
        var i = $(this),
        t = i.attr("data-ga-event"),
        e = t.split(":");
        "undefined" != typeof ga && e.length >= 3 && ga("send", "event", e[0], e[1], e[2])
    });
    var l = $(".seo-desc"),
    c = l.find(".head");
    c.on("click",
    function() {
        l.hasClass("active") ? l.removeClass("active").css("height", "46px") : l.addClass("active").css("height", "auto")
    })
    //$("body").append('<a href="http://www.51sqkb.com/" target="_blank" title="\u7701\u94b1\u5feb\u62a5" class="sqkb"></a>')
});