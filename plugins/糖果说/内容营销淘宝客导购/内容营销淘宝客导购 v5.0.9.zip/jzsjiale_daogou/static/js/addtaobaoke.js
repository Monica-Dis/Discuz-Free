function addtaobaoke(cmd,onlymoren,rukuok,tklcaijiok,regexpstr,siteurl,isopenmiaoshu) {
	checkFocus();
	showEditorMenuTaobaoke(cmd,'',onlymoren,rukuok,tklcaijiok,regexpstr,siteurl,isopenmiaoshu);
	return;
}

function Trim(str)
{ 
    return str.replace(/(^\s*)|(\s*$)/g, ""); 
}

function IsURL(str,regexpstr) {
	if (str.length != 0) {
		var reg = /^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/;		
		
		if (typeof(regexpstr) != "undefined" && regexpstr != "") { 
			reg = "^(("+regexpstr+")?:\/\/)[^\\s]+$";	
			reg = new RegExp(reg);
		}  
		
		if (!reg.test(str)) {
			return false;
		} else {
			return true;
		}
	}
}

function IsImgUrl(str) {
	if (str.length != 0) {
		var reg = /^[a-zA-z]+:\/\/[^\s]*[.]{1}(gif|jpg|png|bmp|jpeg|SS2)$/;
		//var reg = new RegExp(strRegex);
		if (!reg.test(str)) {
			return false;
		}else{
			return true;
		}
	}
}  


function IsDouble(str) {
	if (str.length != 0) {
		reg = /^[-\+]?\d+(\.\d+)?$/;
		if (!reg.test(str)) {
			return false;
		}else{
			return true;
		}
	}
}     

function IsTkl(str) {
	if (str.length != 0) {
		return true;
		/*
		reg = /^\uffe5\w*\uffe5$/;
		if (!reg.test(str)) {
			return false;
		}else{
			return true;
		}
		*/
	}
} 


function GetQueryString(url,name)
{
	var queryString = url.split('?')[1];
    if(!queryString) return;
    queryString = queryString.split('&');
    var queries = {};
    for(var i= 0,len=queryString.length;i<len;i++){
        var tmp = queryString[i].split('=');
        queries[''+tmp[0]] = tmp[1];
    }
    return queries[name];
}

function showhidexiangguanshuoming() {
	var xiangguanshuoming = document.getElementById("xiangguanshuoming");
	if (xiangguanshuoming) {
		if (xiangguanshuoming.style.display == "block") {
			xiangguanshuoming.style.display = "none";
		} else {
			xiangguanshuoming.style.display = "block";
		}
	}
}

function showhideinfomore() {
	var infomore = document.getElementById("infomore");
	if (infomore) {
		if (infomore.style.display == "block") {
			infomore.style.display = "none";
		} else {
			infomore.style.display = "block";
		}
	}
}


function jzsjiale_daogou_img_upload(imginput,aid, url,siteurl) {
	var x = new Ajax('JSON');
	x.getJSON('plugin.php?id=jzsjiale_daogou:api&a=delunusedimg&aid='+aid, function(s){});
    $(imginput).value = siteurl+'data/attachment/forum/'+url;
}



function showEditorMenuTaobaoke(tag, params,onlymoren,rukuok,tklcaijiok,regexpstr,siteurl,isopenmiaoshu) {
	var sel, selection;
	var str = '', strdialog = 0, stitle = '';
	var ctrlid = editorid + (params ? '_cst' + params + '_' : '_') + tag;
	
	var menu = $(ctrlid + '_menu');
	var pos = [0, 0];
	var menuwidth = 270;
	var menupos = '43!';
	var menutype = 'menu';

	if(BROWSER.ie) {
		sel = wysiwyg ? editdoc.selection.createRange() : document.selection.createRange();
		pos = getCaret();
	}

	selection = sel ? (wysiwyg ? sel.htmlText : sel.text) : getSel();


	stitle = '\u63d2\u5165\u5546\u54c1';
	
	str = '';
	str += '<p class="pbn"><span style="color:red;">\u5546\u54c1\u91c7\u96c6</span>\u0028\u652f\u6301\u003a\u6dd8\u5b9d\u3001\u5929\u732b\u0029</p>';
	str += '<p class="pbn">\u5546\u54c1\u7f51\u5740:<input type="text" id="' + ctrlid + '_param_caiji" class="px" value="" placeholder="\u8bf7\u8f93\u5165\u5546\u54c1\u666e\u901a\u94fe\u63a5" style="width: 220px;" />&nbsp;&nbsp;&nbsp;&nbsp;<button type="button" id="btnspcaiji">\u91c7\u0020\u0020\u96c6</button></p>';
	if(tklcaijiok>0){
	    str += '<p class="pbn">\u5546\u54c1\u6dd8\u53e3\u4ee4\u6587\u6848:<input type="text" id="' + ctrlid + '_param_tklcaiji" class="px" value="" style="width: 185px;" />&nbsp;&nbsp;&nbsp;&nbsp;<button type="button" id="btntklcaiji">\u91c7\u0020\u0020\u96c6</button></p>';
	}
	str += '<p class="pbn"><span style="color:red;">----------------------\u4e0d\u91c7\u96c6\u53ef\u5728\u4e0b\u9762\u624b\u5de5\u586b\u5199\u4fe1\u606f---------------------</span></p>';
	str += '<p class="pbn">\u5546\u54c1\u6807\u9898:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="' + ctrlid + '_param_1" class="px" value="" placeholder="\u5fc5\u586b" style="width: 220px;" /></p>';
	str += '<p class="pbn">\u5546\u54c1\u0020\u56fe\u7247\u0020\u5730\u5740:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="' + ctrlid + '_param_2" class="px" value="" placeholder="\u5fc5\u586b" style="width: 180px;" /><button type="button" class="pn" onclick="uploadWindow(function (aid, url){jzsjiale_daogou_img_upload(\''+ctrlid+'_param_2\',aid, url,\''+siteurl+'\');})"><em>\u4e0a\u4f20</em></button></p>';
	str += '<p class="pbn">\u70b9\u51fb\u5546\u54c1\u94fe\u63a5\u5730\u5740:&nbsp;&nbsp;<input type="text" id="' + ctrlid + '_param_3" class="px" value="" placeholder="\u5fc5\u586b" style="width: 220px;" /></p>';
	str += '<p class="pbn">\u4f18\u60e0\u5238\u94fe\u63a5\u5730\u5740:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="' + ctrlid + '_param_4" class="px" value="" style="width: 220px;" /></p>';
	str += '<p class="pbn">\u624b\u5de5\u6307\u5b9a\u6dd8\u53e3\u4ee4:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="' + ctrlid + '_param_8" class="px" value="" style="width: 170px;" /><span style="color:red;">\u4f18\u5148\u4f7f\u7528</span></p>';
	str += '<p class="pbn">\u4ef7\u683c\u0028\u539f\u4ef7\u0029:<input id="' + ctrlid + '_param_5" style="width: 80px;" value="" class="px" />&nbsp;&nbsp;\u5143&nbsp;&nbsp;&nbsp;&nbsp;';
	str += '\u4ef7\u683c\u0028\u73b0\u4ef7\u0029:<input id="' + ctrlid + '_param_6" style="width: 80px;" value="" class="px" />&nbsp;&nbsp;\u5143</p>';
	str += '<p class="pbn" style="display:none;">\u6dd8\u5b9d\u5546\u54c1\u0069\u0064:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="' + ctrlid + '_param_9" class="px" value="" style="width: 220px;" /></p>';
	str += '<p class="pbn"><button type="button" id="showhideinfomorebutton" onClick="javascript:showhideinfomore();">\u70b9\u51fb\u8fd9\u91cc\u9690\u85cf\u002f\u663e\u793a\u66f4\u591a\u5546\u54c1\u4fe1\u606f</button></p>';
	str += '<div id="infomore" style="display:none;">';
	str += '<p class="pbn" style="display:none;">\u4f18\u60e0\u5238\u0069\u0064:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="' + ctrlid + '_param_coupon_id" class="px" value="" style="width: 220px;" /></p>';
	str += '<p class="pbn">\u5238\u4fe1\u606f:<input id="' + ctrlid + '_param_coupon_info" style="width: 70px;" value="" class="px" />&nbsp;&nbsp;';
	str += '\u5238\u603b\u91cf:<input id="' + ctrlid + '_param_coupon_total_count" style="width: 40px;" value="" class="px" />&nbsp;&nbsp;';
	str += '\u5238\u5269\u4f59\u91cf:<input id="' + ctrlid + '_param_coupon_remain_count" style="width: 40px;" value="" class="px" />&nbsp;&nbsp;</p>';
	str += '<p class="pbn">\u5238\u8d77\u7528\u95e8\u69db:<input id="' + ctrlid + '_param_coupon_start_fee" style="width: 80px;" value="" class="px" />&nbsp;&nbsp;';
	str += '\u5238\u9762\u989d:<input id="' + ctrlid + '_param_coupon_amount" style="width: 80px;" value="" class="px" />&nbsp;&nbsp;</p>';
	str += '<p class="pbn">\u5238\u5f00\u59cb\u65f6\u95f4:<input id="' + ctrlid + '_param_coupon_start_time" placeholder="2019-09-20" style="width: 80px;" value="" class="px" />&nbsp;&nbsp;';
	str += '\u5238\u7ed3\u675f\u65f6\u95f4:<input id="' + ctrlid + '_param_coupon_end_time" placeholder="2019-09-21" style="width: 80px;" value="" class="px" />&nbsp;&nbsp;</p>';
	str += '<p class="pbn">\u5546\u54c1\u662f\u5426\u5305\u90ae:<label><input name="' + ctrlid + '_param_freeshipment" id="' + ctrlid + '_param_freeshipment1" type="radio" value="1" />\u662f</label><label><input name="' + ctrlid + '_param_freeshipment" id="' + ctrlid + '_param_freeshipment0" type="radio" value="0" checked="checked" />\u5426</label>&nbsp;&nbsp;';
	str += '\u5e73\u53f0\u7c7b\u578b:<select name="' + ctrlid + '_param_platform" id="' + ctrlid + '_param_platform" class="px" /><option value="none" selected="selected">\u4e0d\u8bbe\u7f6e</option><option value="taobao">\u6dd8\u5b9d</option><option value="tmall">\u5929\u732b</option><option value="jd">\u4eac\u4e1c</option><option value="vip">\u552f\u54c1\u4f1a</option><option value="pinduoduo">\u62fc\u591a\u591a</option></select>&nbsp;&nbsp;</p>';
	str += '</div>';

	if(onlymoren>0){
		str += '<p class="pbn" style="color:red;">\u98ce\u683c\u6a21\u677f:<select name="' + ctrlid + '_param_7" id="' + ctrlid + '_param_7" class="px" /><option value="#" selected="selected">\u7cfb\u7edf\u9ed8\u8ba4</option></select></p>';
	}else{
		str += '<p class="pbn" style="color:red;">\u98ce\u683c\u6a21\u677f:<select name="' + ctrlid + '_param_7" id="' + ctrlid + '_param_7" class="px" /><option value="#" selected="selected">\u7cfb\u7edf\u9ed8\u8ba4</option><option value="discuzcode">\u56fe\u6587\u98ce\u683c\u5c45\u5de6\u6a21\u677f</option><option value="discuzcodecenter">\u56fe\u6587\u98ce\u683c\u5c45\u4e2d\u6a21\u677f</option><option value="liwushuo">\u4eff\u793c\u7269\u8bf4\u5c45\u4e2d\u6a21\u677f\u000d\u000a</option><option value="liwushuoleft">\u4eff\u793c\u7269\u8bf4\u5c45\u5de6\u6a21\u677f\u000d\u000a</option><option value="wutu">\u65e0\u56fe\u5c45\u4e2d\u6a21\u677f</option><option value="wutuleft">\u65e0\u56fe\u5c45\u5de6\u6a21\u677f</option><option value="pctuwencenter">\u56fe\u6587\u7535\u8111\u624b\u673a\u4e00\u81f4\u5c45\u4e2d\u6a21\u677f</option><option value="pctuwen750center">\u56fe\u6587\u0037\u0035\u0030\u0070\u0078\u5bbd\u9002\u5e94\u624b\u673a\u5c45\u4e2d\u6a21\u677f</option><option value="baisetuwenhong">\u767d\u8272\u8272\u8c03\u7b80\u5355\u56fe\u6587\u7ea2\u8272\u6309\u94ae</option><option value="baisetuwen">\u767d\u8272\u8272\u8c03\u7b80\u5355\u56fe\u6587\u6309\u94ae\u7ea2\u8272\u8fb9\u6846</option></select></p>';
	}
	if(rukuok>0){
		str += '<p class="pbn"><span style="color:red;">--------------------------------\u5546\u54c1\u540c\u6b65\u5165\u5e93-------------------------------</span></p>';
		str += '<p class="pbn" style="color:red;">\u8bf7\u9009\u62e9\u5546\u54c1\u5206\u7c7b:<select name="' + ctrlid + '_param_rukufenlei" id="' + ctrlid + '_param_rukufenlei" class="px" /></select><img id="' + ctrlid + '_param_rukufenlei_loading" src="source/plugin/jzsjiale_daogou/static/images/loading.gif" style="width:20px !important;height:20px !important;padding: 0px!important;line-height: 20px;" /></p>';
		str += '<p class="pbn" style="color:red;">\u662f\u5426\u52a0\u5165\u5546\u54c1\u5e93:<label><input name="' + ctrlid + '_param_isruku" id="' + ctrlid + '_param_isruku1" type="radio" value="1" />\u662f</label><label><input name="' + ctrlid + '_param_isruku" id="' + ctrlid + '_param_isruku0" type="radio" value="0" checked="checked" />\u5426</label></p>';
		//-----
		var x = new Ajax('JSON');
		x.getJSON('plugin.php?id=jzsjiale_daogou:api&a=category&all=1', function(s){

			if(s && s.message) {
				var categoryoption = "";
				
				if(s.message.code == 200) {
					categoryoption += '<option value="0">--------------\u8bf7\u9009\u62e9--------------</option>';
					
					var s2 = s;
					var s3 = s;
					var sdata = s.message.data;
					
					for (var key in sdata) {
					
					    if(sdata[key].pid == 0){
					    	categoryoption += '<option value="'+sdata[key].id+'">'+sdata[key].title+'</option>';
							
							var sdata2 = s2.message.data;
							for (var key2 in sdata2) {
							    if(sdata2[key2].pid == sdata[key].id){
							    	categoryoption += '<option value="'+sdata2[key2].id+'">&nbsp;&nbsp;&nbsp;&nbsp;'+sdata2[key2].title+'</option>';
									
							    	var sdata3 = s3.message.data;
									for (var key3 in sdata3) {
									    if(sdata3[key3].pid == sdata2[key2].id){
									    	categoryoption += '<option value="'+sdata3[key3].id+'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+sdata3[key3].title+'</option>';
											
									    }
									}
							    }
							}
					    }
					}
				} else {
					categoryoption += '<option value="0">--------------\u8bf7\u9009\u62e9--------------</option>';
				
				}
				$(ctrlid + '_param_rukufenlei').innerHTML=categoryoption;
				$(ctrlid + '_param_rukufenlei_loading').style.display = 'none';
			}
			
			
		});
	
	}
	if(isopenmiaoshu>0){
	  str += '<p class="pbn">\u76f8\u5173\u8bf4\u660e:<button type="button" id="showhidebutton" onClick="javascript:showhidexiangguanshuoming();">\u70b9\u51fb\u8fd9\u91cc\u9690\u85cf\u002f\u663e\u793a\u76f8\u5173\u8bf4\u660e</button></p>';
	  str += '<p class="xg2 pbn" id="xiangguanshuoming" style="display:none;">\u6dd8\u5b9d\u7f51\u963f\u91cc\u5988\u5988\u5730\u5740--><a href="http://www.alimama.com/" target="_blank" style="color:red;">\u70b9\u6b64\u94fe\u63a5</a><br />\u5efa\u8bae\u4f7f\u7528\u6dd8\u5b9d\u5ba2\u77ed\u94fe\u63a5.&nbsp;&nbsp;&nbsp;&nbsp;\u793a\u4f8b:http://s.click.taobao.com/ainbyXx <br />\u5546\u54c1\u56fe\u7247\u5efa\u8bae\u4e0a\u4e3a\u6b63\u65b9\u5f62\u56fe\u7247.<br />\u4f18\u60e0\u5238\u94fe\u63a5\u6ca1\u6709\u53ef\u4e0d\u586b\u5199,\u6a21\u677f\u5219\u4e0d\u663e\u793a\u4f18\u60e0\u5238\u6309\u94ae.<br/>\u6b64\u5904\u98ce\u683c\u6a21\u677f\u9009\u0026\u0071\u0075\u006f\u0074\u003b\u7cfb\u7edf\u9ed8\u8ba4\u0026\u0071\u0075\u006f\u0074\u003b\u5219\u4ee5\u540e\u53f0\u9009\u62e9\u7684\u6a21\u677f\u4e3a\u51c6.<br/>\u91c7\u96c6\u529f\u80fd\u53ea\u80fd\u91c7\u96c6\u5230\u963f\u91cc\u5988\u5988\u91cc\u9762\u80fd\u641c\u7d22\u5230\u7684\u5546\u54c1.<br/>\u4e8c\u5408\u4e00\u94fe\u63a5\u53e3\u4ee4\u53ef\u624b\u5de5\u6307\u5b9a\uff0c\u4f18\u5148\u7ea7\u9ad8\u4e8e\u81ea\u52a8\u8f6c\u6362\u7684\u6dd8\u53e3\u4ee4.</p>';
	}
	
	
	s = '<style type="text/css">'
	+'.jzsjialetbkcss input,.pbn {font:12px/1.5 Tahoma,Helvetica,"SimSun",sans-serif !important;}'
	+'.jzsjialetbkcss input {line-height:17px !important;height:17px !important;padding:4px !important;}'
	+'.jzsjialetbkcss p{max-width:364px !important;}'
	+'.jzsjialetbkcss div.c{max-width:384px !important;padding:0 10px !important;}'
	+'.jzsjialetbkcss h3.flb{max-width:364px !important;padding:10px 10px 8px !important;}'
	+'.jzsjialetbkcss td.m_c{max-width:364px !important;padding:0px!important;}'
	+'.jzsjialetbkcss .pbn select{height:30px !important;padding:0px!important;}'
	+'</style>';



	menuwidth = 400;//600
	menupos = '00';
	menutype = 'win';

	var menu = document.createElement('div');
	menu.id = ctrlid + '_menu';
	menu.style.display = 'none';
	menu.className = 'p_pof upf';
	menu.style.width = menuwidth + 'px';
	if(menupos == '00') {
			menu.className = 'fwinmask jzsjialetbkcss';
			s += '<table width="100%" cellpadding="0" cellspacing="0" class="fwin"><tr><td class="t_l"></td><td class="t_c"></td><td class="t_r"></td></tr><tr><td class="m_l">&nbsp;&nbsp;</td><td class="m_c">'
				+ '<h3 class="flb"><em>' + stitle + '</em><span><a onclick="hideMenu(\''+ctrlid + '_menu\', \'win\');return false;" class="flbc" href="javascript:;">\u5173\u95ed</a></span></h3><div class="c">' + str + '</div>'
				+ '<p class="o pns"><button type="submit" id="' + ctrlid + '_submit" class="pn pnc"><strong>\u63d0\u4ea4</strong></button></p>'
				+ '</td><td class="m_r"></td></tr><tr><td class="b_l"></td><td class="b_c"></td><td class="b_r"></td></tr></table>';
		} else {
			s += '<div class="p_opt cl"><span class="y" style="margin:-10px -10px 0 0"><a onclick="hideMenu();return false;" class="flbc" href="javascript:;">\u5173\u95ed</a></span><div>' + str + '</div><div class="pns mtn"><button type="submit" id="' + ctrlid + '_submit" class="pn pnc"><strong>\u63d0\u4ea4</strong></button></div></div>';
		}
	menu.innerHTML = s;
	$(editorid + '_editortoolbar').appendChild(menu);
	showMenu({'ctrlid':ctrlid,'mtype':menutype,'evt':'click','duration':3,'cache':0,'drag':1,'pos':menupos});

	try {
		if($(ctrlid + '_param_1')) {
			$(ctrlid + '_param_1').focus();
		}
	} catch(e) {}
	var objs = menu.getElementsByTagName('*');
	for(var i = 0; i < objs.length; i++) {
		_attachEvent(objs[i], 'keydown', function(e) {
			e = e ? e : event;
			obj = BROWSER.ie ? event.srcElement : e.target;
			if((obj.type == 'text' && e.keyCode == 13) || (obj.type == 'textarea' && e.ctrlKey && e.keyCode == 13)) {
				if($(ctrlid + '_submit') && tag != 'image') $(ctrlid + '_submit').click();
				doane(e);
			} else if(e.keyCode == 27) {
				hideMenu();
				doane(e);
			}
		});
	}
	if($(ctrlid + '_submit')) $(ctrlid + '_submit').onclick = function() {
		checkFocus();
		switch(tag) {
			case 'jzsjiale_daogou':
				var title = Trim($(ctrlid + '_param_1').value);
				var imgurl = Trim($(ctrlid + '_param_2').value);
				var url = Trim($(ctrlid + '_param_3').value);
				var yhqurl = Trim($(ctrlid + '_param_4').value);
				var yuanjia = Trim($(ctrlid + '_param_5').value);
				var xianjia = Trim($(ctrlid + '_param_6').value);
				var fengge = Trim($(ctrlid + '_param_7').value);
				var tkl = Trim($(ctrlid + '_param_8').value);
				var numiid = Trim($(ctrlid + '_param_9').value);
				var couponinfo = Trim($(ctrlid + '_param_coupon_info').value);
				var couponstartfee = Trim($(ctrlid + '_param_coupon_start_fee').value);
				var couponamount = Trim($(ctrlid + '_param_coupon_amount').value);
				var couponstarttime = Trim($(ctrlid + '_param_coupon_start_time').value);
				var couponendtime = Trim($(ctrlid + '_param_coupon_end_time').value);
				var couponactivityid = Trim($(ctrlid + '_param_coupon_id').value);
				var coupontotalcount = Trim($(ctrlid + '_param_coupon_total_count').value);
				var couponremaincount = Trim($(ctrlid + '_param_coupon_remain_count').value);
				var platform = Trim($(ctrlid + '_param_platform').value);
				var freeshipment = $(ctrlid + '_param_freeshipment1').checked?1:0;

				if(title == ""){
					alert("\u5546\u54c1\u6807\u9898\u4e0d\u80fd\u4e3a\u7a7a!");
					break;
				}
				if(imgurl == ""){
					alert("\u5546\u54c1\u56fe\u7247\u94fe\u63a5\u4e0d\u80fd\u4e3a\u7a7a!");
					return;
				}
				if(!IsImgUrl(imgurl)){
					alert("\u56fe\u7247\u94fe\u63a5\u5730\u5740\u683c\u5f0f\u4e0d\u6b63\u786e!");
					return;
				}
				if(url == ""){
					alert("\u5546\u54c1\u94fe\u63a5\u4e0d\u80fd\u4e3a\u7a7a!");
					return;
				}
				if(!IsURL(url,regexpstr)){
					alert("\u94fe\u63a5\u5730\u5740\u683c\u5f0f\u4e0d\u6b63\u786e!");
					return;
				}
				
				if(yhqurl != "" && !IsURL(yhqurl,regexpstr)){
					alert("\u4f18\u60e0\u5238\u94fe\u63a5\u683c\u5f0f\u4e0d\u6b63\u786e!");
					return;
				}
				
				if(yhqurl == ""){
					yhqurl = "#";
				}
				
				
				if(yuanjia != "" && !IsDouble(yuanjia)){
					alert("\u5546\u54c1\u539f\u4ef7\u5fc5\u987b\u662f\u6570\u5b57\u683c\u5f0f!");
					return;
				}
				
				if(yuanjia == ""){
					yuanjia = "0";
				}
				
				//20180912 del start
				/*
				if(xianjia == ""){
					alert("\u5546\u54c1\u73b0\u4ef7\u4e0d\u80fd\u4e3a\u7a7a!");
					return;
				}
				if(!IsDouble(xianjia)){
					alert("\u5546\u54c1\u73b0\u4ef7\u5fc5\u987b\u662f\u6570\u5b57\u683c\u5f0f!");
					return;
				}
				*/
				//20180912 del end
				
				//20180912 add start
				if(xianjia != "" && !IsDouble(xianjia)){
					alert("\u5546\u54c1\u73b0\u4ef7\u5fc5\u987b\u662f\u6570\u5b57\u683c\u5f0f!");
					return;
				}
				if(xianjia == ""){
					xianjia = "0";
				}
				//20180912 add end
				
				if(fengge == ""){
					fengge = "#";
				}
				
				if(tkl != "" && !IsTkl(tkl)){
					alert("\u6dd8\u53e3\u4ee4\u683c\u5f0f\u9519\u8bef\uff0c\u6b63\u786e\u683c\u5f0f\uffe5\u0041\u0041\u0054\u0045\u0078\u0064\u0045\u0072\uffe5!");
					return;
				}
				
				if(tkl == ""){
					tkl = "#";
				}
                
				if(document.charset == 'gbk' || document.charset == 'GBK'){
					var tklotmp = encodeURI(tkl);
	                if(tklotmp.indexOf("%E2%82%AC") != -1 ){
	                	tkl = tklotmp;
	                }
				}
                
				
				if(numiid == ""){
					numiid = GetQueryString(url,'id');
				}

				if(numiid == "" || numiid == null){
					numiid = "#";
				}


				if(couponinfo == ""){
					couponinfo = "#";
				}
				if(couponstartfee == ""){
					couponstartfee = "#";
				}
				if(couponamount == ""){
					couponamount = "#";
				}
				if(couponstarttime == ""){
					couponstarttime = "#";
				}
				if(couponendtime == ""){
					couponendtime = "#";
				}
				if(couponactivityid == ""){
					couponactivityid = "#";
				}
				if(coupontotalcount == ""){
					coupontotalcount = "#";
				}
				if(couponremaincount == ""){
					couponremaincount = "#";
				}
				if(platform == ""){
					platform = "#";
				}
				if(freeshipment == ""){
					freeshipment = "0";
				}



				if(rukuok>0 && $(ctrlid + '_param_isruku1').checked){
					
					var categoryid = $(ctrlid + '_param_rukufenlei').value;
					
					if(categoryid <= 0){
						alert("\u8bf7\u9009\u62e9\u5546\u54c1\u5206\u7c7b!");
						return;
					}
					var x = new Ajax('JSON');
					x.getJSON('plugin.php?id=jzsjiale_daogou:ruku&categoryid='+categoryid+'&title='+encodeURIComponent(title)+'&imgurl='+encodeURIComponent(squarestrip(imgurl))+'&url='+encodeURIComponent(squarestrip(url))+'&yuanjia='+yuanjia+'&xianjia='+xianjia+'&yhqurl='+encodeURIComponent(squarestrip(yhqurl))+'&tkl='+encodeURIComponent(squarestrip(tkl))+'&numiid='+encodeURIComponent(squarestrip(numiid))+'&couponinfo='+encodeURIComponent(squarestrip(couponinfo))+'&couponstartfee='+encodeURIComponent(couponstartfee)+'&couponamount='+encodeURIComponent(couponamount)+'&couponstarttime='+encodeURIComponent(couponstarttime)+'&couponendtime='+encodeURIComponent(couponendtime)+'&couponactivityid='+encodeURIComponent(couponactivityid)+'&coupontotalcount='+encodeURIComponent(coupontotalcount)+'&couponremaincount='+encodeURIComponent(couponremaincount)+'&platform='+encodeURIComponent(platform)+'&freeshipment='+encodeURIComponent(freeshipment)+'&inajax=1', function(s){
				
						if(s && s.message) {
							if(s.message.code == 1) {
							
								var opentag = '[jzsjiale_daogou_spk]';
								var closetag = '[/jzsjiale_daogou_spk]';
								
								str = opentag + s.message.spid + closetag;
								insertText(str, strlen(opentag), strlen(closetag), false, sel);
								hideMenu('', 'win');
								hideMenu();
								
								alert("\u52a0\u5165\u5546\u54c1\u5e93\u6210\u529f");
							} else {
								
								str = title+",="+squarestrip(imgurl)+",="+squarestrip(url)+",="+yuanjia+",="+xianjia+",="+squarestrip(yhqurl)+",="+fengge+",="+squarestrip(tkl)+",="+squarestrip(numiid)+",="+squarestrip(couponinfo)+",="+couponstartfee+",="+couponamount+",="+couponstarttime+",="+couponendtime+",="+couponactivityid+",="+coupontotalcount+",="+couponremaincount+",="+platform+",="+freeshipment;

								var opentag = '[' + tag + ']';
								var closetag = '[/' + tag + ']';
								
								str = opentag + str + closetag;
								insertText(str, strlen(opentag), strlen(closetag), false, sel);
								
								hideMenu('', 'win');
								hideMenu();
								
								alert("\u5165\u5e93\u5931\u8d25\u6216\u65e0\u6743\u9650\u52a0\u5165\u5546\u54c1\u5e93\u002c\u4ee5\u666e\u901a\u65b9\u5f0f\u63d2\u5165");
							}
						}
						
						
					});
				}else{
					str = title+",="+squarestrip(imgurl)+",="+squarestrip(url)+",="+yuanjia+",="+xianjia+",="+squarestrip(yhqurl)+",="+fengge+",="+squarestrip(tkl)+",="+squarestrip(numiid)+",="+squarestrip(couponinfo)+",="+couponstartfee+",="+couponamount+",="+couponstarttime+",="+couponendtime+",="+couponactivityid+",="+coupontotalcount+",="+couponremaincount+",="+platform+",="+freeshipment;

					var opentag = '[' + tag + ']';
					var closetag = '[/' + tag + ']';
					
					str = opentag + str + closetag;
					insertText(str, strlen(opentag), strlen(closetag), false, sel);
					
					hideMenu('', 'win');
					hideMenu();
					
				}
				break;
			
			default:
				
				break;
		}
		
	};
	
	
	
	
	
	if($('btnspcaiji')) $('btnspcaiji').onclick = function() {
		checkFocus();
		
		var caijiurl = Trim($(ctrlid + '_param_caiji').value);

		if(caijiurl == ""){
			alert("\u91c7\u96c6\u5730\u5740\u4e0d\u80fd\u4e3a\u7a7a!");
			return;
		}
		
		var caijiurl = encodeURIComponent(caijiurl);
		
		
		var x = new Ajax('JSON');
		x.getJSON('plugin.php?id=jzsjiale_daogou:caiji&caijiurl='+caijiurl, function(s){
	
			if(s && s.message) {
				if(s.message.dataexist == 1) {
					$(ctrlid + '_param_1').value = s.message.title;
					$(ctrlid + '_param_2').value = s.message.img;
					$(ctrlid + '_param_3').value = s.message.url;
					$(ctrlid + '_param_4').value = s.message.youhuiquan;
					$(ctrlid + '_param_5').value = s.message.yuanjia;
					$(ctrlid + '_param_6').value = s.message.xianjia;
					$(ctrlid + '_param_9').value = s.message.numiid;
					$(ctrlid + '_param_coupon_info').value = s.message.couponinfo;
					$(ctrlid + '_param_coupon_start_fee').value = s.message.couponstartfee;
					$(ctrlid + '_param_coupon_amount').value = s.message.couponamount;
					$(ctrlid + '_param_coupon_start_time').value = s.message.couponstarttime;
					$(ctrlid + '_param_coupon_end_time').value = s.message.couponendtime;
					$(ctrlid + '_param_coupon_id').value = s.message.couponactivityid;
					$(ctrlid + '_param_coupon_total_count').value = s.message.coupontotalcount;
					$(ctrlid + '_param_coupon_remain_count').value = s.message.couponremaincount;
					$(ctrlid + '_param_platform').value = s.message.platform;
					if(s.message.freeshipment == '1'){
						$(ctrlid + '_param_freeshipment1').checked = true;
					}else{
						$(ctrlid + '_param_freeshipment0').checked = true;
					}

				} else {
					alert("\u6ca1\u6709\u91c7\u96c6\u5230\u6570\u636e\u002c\u8bf7\u91cd\u8bd5\u0020\u6216\u0020\u8be5\u5546\u54c1\u65e0\u6cd5\u91c7\u96c6\u0021\u0020\u8bf7\u624b\u5de5\u5f55\u5165\u5546\u54c1\u6570\u636e\u0021");
				}
			}
			
			
		});
		
		
	};	
	
	
	
	if($('btntklcaiji')) $('btntklcaiji').onclick = function() {
		checkFocus();
		
		var caijitkl = Trim($(ctrlid + '_param_tklcaiji').value);

		if(caijitkl == ""){
			alert("\u8bf7\u586b\u5199\u5546\u54c1\u6dd8\u53e3\u4ee4\u6587\u6848!");
			return;
		}
		
		//var caijitkl = encodeURIComponent(caijitkl);
		
		var x = new Ajax('JSON');
		x.getJSON('plugin.php?id=jzsjiale_daogou:caijitkl&caijitkl='+caijitkl, function(s){
	
			if(s && s.message) {
				if(s.message.dataexist == 1) {
					var imgurltmp = s.message.imgurl;
					imgurltmp = imgurltmp.substr(0,2).toLowerCase() == "//" ? "http:" + imgurltmp : imgurltmp;
					
					$(ctrlid + '_param_1').value = s.message.title;
					$(ctrlid + '_param_2').value = imgurltmp;
					$(ctrlid + '_param_3').value = s.message.url;
					//$(ctrlid + '_param_4').value = s.message.url;
					$(ctrlid + '_param_5').value = s.message.yuanjia;
					$(ctrlid + '_param_6').value = s.message.xianjia != "" ? s.message.xianjia : 0;
					$(ctrlid + '_param_9').value = s.message.numiid;
				} else {
					alert("\u6ca1\u6709\u91c7\u96c6\u5230\u6570\u636e\u002c\u8bf7\u91cd\u8bd5\u0020\u6216\u0020\u8be5\u5546\u54c1\u65e0\u6cd5\u91c7\u96c6\u0021\u0020\u8bf7\u624b\u5de5\u5f55\u5165\u5546\u54c1\u6570\u636e\u0021");
				}
			}
			
			
		});
		
		
	};
		
}