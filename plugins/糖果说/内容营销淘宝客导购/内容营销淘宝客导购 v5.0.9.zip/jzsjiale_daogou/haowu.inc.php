<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';
$utils = new Utils();

global $_G, $lang;
$_config = $_G['cache']['plugin']['jzsjiale_daogou'];
if(!in_array ( "haowu", (array)unserialize($_config['g_alone']) )){
    showmessage(lang('plugin/jzsjiale_daogou','function_closed'), $_G['siteurl']);
}

$cateid = daddslashes(trim($_GET['cateid']));

$spcategory = "";

if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';

    $spcategory = $tbkcategory;

}else{
    $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();

    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));

    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
    $spcategory = $tbkcategory;

}

$currcateid = 0;
$level = 0;
$currcate = array();
$currcate2 = array();
$havecate2 = array();
$currcate3 = array();
$havecate3 = array();
$currtitle = "";
foreach($spcategory as $spkey => $spvalue){
    if(empty($cateid)){
        if($spvalue['status'] == 1 && $spvalue['pid'] == 0){
            $currcate = $spvalue;
            $currtitle = $currcate['title'];
            $currcateid = $spvalue['id'];
            $level = $spvalue['level'];
            foreach($spcategory as $spkey2 => $spvalue2){
                if($spvalue2['status'] == 1 && $spvalue2['pid'] == $currcate['id'] && $spvalue2['level'] == 2){
                    $havecate2 = $spvalue2;
                    break;
                }
            }
            break;
        }
    }else{
        if($spvalue['status'] == 1 && $spvalue['id'] == $cateid && $spvalue['pid'] == 0 && $spvalue['level'] == 1){
            $currcate = $spvalue;
            $currtitle = $currcate['title'];
            $currcateid = $spvalue['id'];
            $level = $spvalue['level'];
            foreach($spcategory as $spkey2 => $spvalue2){
                if($spvalue2['status'] == 1 && $spvalue2['pid'] == $currcate['id'] && $spvalue2['level'] == 2){
                    $havecate2 = $spvalue2;
                    break;
                }
            }
            break;
        }
        if($spvalue['status'] == 1 && $spvalue['id'] == $cateid && $spvalue['pid'] > 0  && $spvalue['level'] == 2){
            $currcate2 = $spvalue;
            $currtitle = $currcate2['title'];
            $havecate2 = $spvalue;
            $currcateid = $spvalue['id'];
            $level = $spvalue['level'];
            foreach($spcategory as $spkey1 => $spvalue1){
                if($spvalue1['status'] == 1 && $spvalue1['id'] == $currcate2['pid'] && $spvalue1['pid'] == 0 && $spvalue1['level'] == 1){
                    $currcate = $spvalue1;
                    break;
                }
            }
            foreach($spcategory as $spkey3 => $spvalue3){
                if($spvalue3['status'] == 1 && $spvalue3['pid'] == $currcate2['id'] && $spvalue3['level'] == 3){
                    $havecate3 = $spvalue3;
                    break;
                }
            }
            break;
        }
        if($spvalue['status'] == 1 && $spvalue['id'] == $cateid && $spvalue['pid'] > 0  && $spvalue['level'] == 3){
            $currcate3 = $spvalue;
            $currtitle = $currcate3['title'];
            $havecate3 = $spvalue;
            $currcateid = $spvalue['id'];
            $level = $spvalue['level'];
            foreach($spcategory as $spkey2 => $spvalue2){
                if($spvalue2['status'] == 1 && $spvalue2['id'] == $currcate3['pid'] && $spvalue2['level'] == 2){
                    $currcate2 = $spvalue2;
                    $havecate2 = $spvalue2;
                    break;
                }
            }
            foreach($spcategory as $spkey1 => $spvalue1){
                if($spvalue1['status'] == 1 && $spvalue1['id'] == $currcate2['pid'] && $spvalue1['pid'] == 0 && $spvalue1['level'] == 1){
                    $currcate = $spvalue1;
                    break;
                }
            }
            
            break;
        }
        
    }
    
}



$hdp = "";

if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_huandengpian.php')){
    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_huandengpian.php';

    $hdp = $daogouhuandengpian;

}else{
    $daogouhuandengpian = C::t('#jzsjiale_daogou#jzsjiale_daogou_huandengpian')->getall();

    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_huandengpian', getcachevars(array('daogouhuandengpian' => $daogouhuandengpian)));

    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_huandengpian.php';
    $hdp = $daogouhuandengpian;

}

$hdp = dhtmlspecialchars($hdp);


$_config = $_G['cache']['plugin']['jzsjiale_daogou'];
$g_isopenzhtglj = $_config['g_isopenzhtglj'];
$g_taodianjincode = $_config['g_taodianjincode'];


include template('jzsjiale_daogou:daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/haowu');  
?>