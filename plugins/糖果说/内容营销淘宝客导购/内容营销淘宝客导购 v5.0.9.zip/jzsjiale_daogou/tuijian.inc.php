<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;

if (!empty($_GET['formhash']) && FORMHASH == $_GET['formhash']) {
    $tid = $_GET['tid'];
    $tiezicategoryid = $_GET['tiezicategoryid'];
    $groupflag = $_GET['groupflag'];
    $dulixiangqing = $_GET['dulixiangqing'];
    $uid = $_G['uid'];
    $pid = $_G['forum_firstpid'];
    
    if (empty($tid)) {
        $uid = 1;
    }
    if (empty($tiezicategoryid)) {
        $tiezicategoryid = 0;
    }
    
    
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    
    if (! $_config['g_isopen']) {
        showmessage(lang('plugin/jzsjiale_daogou', 'lailufeifa'));
    }
    
    if (! $_config['g_tuijianpc']) {
        showmessage(lang('plugin/jzsjiale_daogou', 'lailufeifa'));
    }
    
    $uid = $_G['uid'];
    
    if (empty($uid)) {
        showmessage(lang('plugin/jzsjiale_daogou', 'lailufeifa'));
    }
    
    $fid = $_GET['fid'];
    if (empty($fid)) {
        showmessage(lang('plugin/jzsjiale_daogou', 'lailufeifa'));
    }
    
    $groupid = $_G['groupid'];
    if (empty($groupid)) {
        showmessage(lang('plugin/jzsjiale_daogou', 'lailufeifa'));
    }
    
    if ((! in_array($fid, (array) unserialize($_config['g_tuijianpcforum'])) && !$groupflag) || ! in_array($groupid, (array) unserialize($_config['g_tuijianpcgroup']))) {
        showmessage(lang('plugin/jzsjiale_daogou', 'lailufeifa'));
    } elseif (empty($tid)) {
        showmessage(lang('plugin/jzsjiale_daogou', 'notid'));
    } else {
        $yanzhengtuijian = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->get_by_tidandcategoryid($tid,$tiezicategoryid);
        if (! empty($yanzhengtuijian)) {
            showmessage(lang('plugin/jzsjiale_daogou', 'yijingtuijian'));
        } else {
            $postresult = C::t('forum_thread')->fetch($tid);
            $title = $postresult['subject'];
            
            DB::insert('jzsjiale_daogou_tiezi', array(
                'dateline' => TIMESTAMP,
                'title' => $title,
                'tid' => $tid,
                'tiezicategoryid' => $tiezicategoryid,
                'uid' => $uid,
                'status' => 1,
                'sort' => 1
            ));
            
            $daogoutiezi = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->getall();
            
            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_tiezi', getcachevars(array('daogoutiezi' => $daogoutiezi)));
            
            if($dulixiangqing){
                if($_G[jzsjiale_tpl_daogou][weijingtaimokuai] && $_G[jzsjiale_tpl_daogou][weijingtai] == 2){
                    showmessage(lang('plugin/jzsjiale_daogou', 'tuijianok'), 'topic-' . $tid.'.html', '', array(
                        'alert' => 'right'
                    ));
                }else{
                    showmessage(lang('plugin/jzsjiale_daogou', 'tuijianok'), 'plugin.php?id=jzsjiale_daogou:article&tid=' . $tid, '', array(
                        'alert' => 'right'
                    ));
                }
            }else{
                showmessage(lang('plugin/jzsjiale_daogou', 'tuijianok'), 'forum.php?mod=viewthread&tid=' . $tid, '', array(
                    'alert' => 'right'
                ));
            }
            
        }
    }
} else {
    
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    $groupflag = $_GET['groupflag'];
    $dulixiangqing = $_GET['dulixiangqing'];
    
    $isok = true;
    
    if (! $_config['g_isopen']) {
        $isok = false;
    }
    
    if (! $_config['g_tuijianpc']) {
        $isok = false;
    }
    
    $fid = $_GET['fid'];
    if (empty($fid)) {
        $isok = false;
    }
    
    $groupid = $_G['groupid'];
    if (empty($groupid)) {
        $isok = false;
    }
    
    if ($isok == true && (in_array($fid, (array) unserialize($_config['g_tuijianpcforum'])) || $groupflag) && in_array($groupid, (array) unserialize($_config['g_tuijianpcgroup']))) {
        $isok = true;
    } else {
        $isok = false;
    }
   
    if ($isok) {
        
        $categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid(0, 1);
        $categoryidselect = '<option value="0">' . lang('plugin/jzsjiale_daogou', 'qingxuanze') . '</option>';
        foreach ($categoryids as $k => $v) {
            $categoryidselect .= '<option value="' . $v['id'] . '">' . $v['title'] . '</option>';
            
            $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($v['id'], 1);
            
            foreach ($subcategoryids as $subk => $subv) {
                $categoryidselect .= '<option value="' . $subv['id'] . '">&nbsp;&nbsp;&nbsp;&nbsp;' . $subv['title'] . '</option>';
                
                $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($subv['id'], 1);
                
                foreach ($sub3categoryids as $sub3k => $sub3v) {
                    $categoryidselect .= '<option value="' . $sub3v['id'] . '">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $sub3v['title'] . '</option>';
                }
            }
        }
        
        $tid = $_GET['tid'];
        include template('jzsjiale_daogou:other/tuijianwindow');
    } elseif (! $_G['uid']) {
        showmessage(lang('plugin/jzsjiale_daogou', 'nologin'), '', '', array(
            'login' => '1'
        ));
    } else {
        showmessage(lang('plugin/jzsjiale_daogou', 'lailufeifa'));
    }
}
//From: dis'.'m.t'.'ao'.'bao.com
?>