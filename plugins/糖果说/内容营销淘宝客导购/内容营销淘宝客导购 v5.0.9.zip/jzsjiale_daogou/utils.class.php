<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class Utils
{
    // TODO - Insert your code here
    function page_array($count, $page, $array, $order)
    {
        global $countpage; 
        $page = (empty($page)) ? '1' : $page; 
        $start = ($page - 1) * $count; 
        if ($order == 1) {
            $array = array_reverse($array);
        }
        $totals = count($array);
        $countpage = ceil($totals / $count); 
        $pagedata = array();
        $pagedata = array_slice($array, $start, $count);
        return $pagedata;
    }


    function show_array($countpage, $url)
    {
        $page = empty($_GET['page']) ? 1 : $_GET['page'];
    
        global $_G;
 
        if ($page > 1) {
            $uppage = $page - 1;
        } else {
            $uppage = 1;
        }
        
        if ($page < $countpage) {
            $nextpage = $page + 1;
        } else {
            $nextpage = $countpage;
        }
        
            $str = "<div style='border:1px; height:30px; color:#9999CC;font-size:16px;text-align:center;'>";
            $str .= "<span style='color:blue;' id='qdfanye1'>".lang('plugin/jzsjiale_daogou','fanyegong')."  {$countpage}  ".lang('plugin/jzsjiale_daogou','fanye2')." {$page} ".lang('plugin/jzsjiale_daogou','fanye3')."</span>";
            $str .= "<span  id='qdfanye2'>&nbsp;&nbsp;&nbsp;&nbsp;".$this->pageList($page,$countpage,$url)."&nbsp;&nbsp;&nbsp;&nbsp;</span>";
            
            $str .= "<span id='qdfanye3'>";
            $str .= "<span><a href='javascript:void(0);' onclick='spfanye(\"$url&page=1\")'>   ".lang('plugin/jzsjiale_daogou','fanye4')."  </a></span>";
            $str .= "<span><a href='javascript:void(0);' onclick='spfanye(\"$url&page={$uppage}\")'> ".lang('plugin/jzsjiale_daogou','fanye5')."  </a></span>";
            $str .= "<span><a href='javascript:void(0);' onclick='spfanye(\"$url&page={$nextpage}\")'>".lang('plugin/jzsjiale_daogou','fanye6')."  </a></span>";
            $str .= "<span><a href='javascript:void(0);' onclick='spfanye(\"$url&page={$countpage}\")'>".lang('plugin/jzsjiale_daogou','fanye7')."  </a></span>";
            $str .= "</span>";
            $str .= "</div>";
        return $str;
    }
    
    
    function pageList($currpage,$countpage,$url) {
      for($i=5;$i>=1;$i--) {
         $_page = $currpage-$i;
         if ($_page < 1) continue;
         $_pagelist .= ' <a href="javascript:void(0);" onclick="spfanye(\''.$url.'&page='.$_page.'\')" class="fanyenoactive">'.$_page.'</a> ';
      }
      $_pagelist .= ' <span class="fanyeactive">'.$currpage.'</span> ';
      for ($i=1;$i<=5;$i++) {
         $_page = $currpage+$i;
         if ($_page > $countpage) break;
         $_pagelist .= ' <a href="javascript:void(0);" onclick="spfanye(\''.$url.'&page='.$_page.'\')" class="fanyenoactive">'.$_page.'</a> ';
      }
      return $_pagelist;
    }
    
   
    
    function searchlike($keywords,$field,$data)
    {
        if(!$keywords||!$data||!$field)return false;
        $this->keywords=$keywords;
        $this->field=$field;
        $this->data=$data;
        for($i=0;$i<count($data);$i++){
            if(strpos($data[$i][$field],$keywords)>-1){
                $res[]=$data[$i];
            }
        }
            
        return $res;
    }
    
    function searchlikegetfirst($keywords,$field,$data)
    {
        if(!$keywords||!$data||!$field)return false;
        $this->keywords=$keywords;
        $this->field=$field;
        $this->data=$data;
        foreach ($data as $d){
            if(strpos($d[$field],$keywords)>-1){
                $res=$d;
                break;
            }
        }
    
        return $res;
    }
    
    function search($keywords,$field,$data)
    {
        if(!isset($keywords) || !isset($data) || !isset($field)){
            return false;
        }
        $this->keywords=$keywords;
        $this->field=$field;
        $this->data=$data;
        for($i=0;$i<count($data);$i++){
            if($data[$i][$field] == $keywords){
                $res[]=$data[$i];
            }
        }
    
        return $res;
    }
    
    function searchByRandom($data,$count = 0)
    {
        if(!isset($data)){
            return false;
        }
        $this->data=$data;
        
        $randomdata = array_rand($data,$count);
        for($i=0;$i<$count;$i++){
            $res[]=$data[$randomdata[$i]];
        }
    
        return $res;
    }
    
    function searchGetOne($keywords,$field,$returnfield,$data)
    {
        if(!isset($keywords) || !isset($data) || !isset($field) || !isset($returnfield)){
            return false;
        }
        $this->keywords=$keywords;
        $this->field=$field;
        $this->data=$data;
        for($i=0;$i<count($data);$i++){
            if($data[$i][$field] == $keywords){
                $res=$data[$i][$returnfield];
                break;
            }
        }
    
        return $res;
    }
    
    function search2($keywords1,$field1,$keywords2,$field2,$data)
    {
        if(!isset($keywords1) || !isset($field1) || !isset($keywords2) || !isset($field2) ||!isset($data)){
            return false;
        }
        $this->keywords1=$keywords1;
        $this->field1=$field1;
        $this->keywords2=$keywords2;
        $this->field2=$field2;
        $this->data=$data;
     
        for($i=0;$i<count($data);$i++){
            if($data[$i][$field1] == $keywords1 && $data[$i][$field2] == $keywords2){
                $res[]=$data[$i];
            }
        }
    
        return $res;
    }
    
 
    function searchArrayByPid($pid,$data)
    {
        if(!isset($pid) || !isset($data)){
            return false;
        }
        $this->pid=$pid;
        $this->data=$data;
        for($i=0;$i<count($data);$i++){
            if($data[$i]['pid'] == $pid){
                $res[]=$data[$i];
            }
        }
    
        return $res;
    }
    

    function searchArrayGetField($field,$data)
    {
        if(!$data || !$field) return false;
        foreach ($data as $d){
            if($d['key'] === $field){
                return true;
            }
        }
        return false;
    }
    
 
    function searchArrayByField($field,$data)
    {
        if(!$data||!$field)return false;
        $this->field=$field;
        $this->data=$data;
        for($i=0;$i<count($data);$i++){
            if($data[$i]['key'] == $field){
                $res=$data[$i]['value'];
                break;
            }
        }
    
        return $res;
    }
    

    function searchlikeReturnStr($keywords,$field,$returnfield,$data)
    {
        if(!isset($keywords) || !isset($field) || !isset($returnfield) || !isset($data)){
            return false;
        }
        $this->keywords=$keywords;
        $this->field=$field;
        $this->data=$data;
        for($i=0;$i<count($data);$i++){
            if(strpos($data[$i][$field],$keywords)>-1){
                $res[]=$data[$i][$returnfield];
            }
        }
    
        return $res;
    }
    
    function searchlikeReturnStr2($keywords,$field,$returnfield,$data)
    {
        if(!isset($keywords) || !isset($field) || !isset($returnfield) || !isset($data)){
            return false;
        }
        $this->keywords=$keywords;
        $this->field=$field;
        $this->data=$data;
        foreach ($data as $d){
            if(strpos($d[$field],$keywords)>-1){
                $res[]=$d[$returnfield];
            }
        }
    
        return $res;
    }
    
    

    function searchReturnStr($keywords,$field,$returnfield,$data)
    {
        if(!isset($keywords) || !isset($field) || !isset($returnfield) || !isset($data)){
            return false;
        }
        $this->keywords=$keywords;
        $this->field=$field;
        $this->data=$data;
        for($i=0;$i<count($data);$i++){
            if($data[$i][$field] == $keywords){
                $res[]=$data[$i][$returnfield];
            }
        }
    
        return $res;
    }
    
    

    function searchReturnStrByCatePid($keywords,$field,$returnfield,$data,$catedata)
    {
        if(!isset($keywords) || !isset($field) || !isset($returnfield) || !isset($data) ||!isset($catedata)){
            return false;
        }
        $this->keywords=$keywords;
        $this->field=$field;
        $this->data=$data;
        
        $cateids = array($keywords);
        
        for($i=0;$i<count($catedata);$i++){
            if($catedata[$i]['pid'] == $keywords){
                $cateids[]=$catedata[$i]['id'];
                
                for($j=0;$j<count($catedata);$j++){
                    if($catedata[$j]['pid'] == $catedata[$i]['id']){
                        $cateids[]=$catedata[$j]['id'];
                    }
                }
            }
        }
        
        for($i=0;$i<count($data);$i++){
            if(in_array($data[$i][$field],$cateids)){
                $res[]=$data[$i][$returnfield];
            }
        }
    
        return $res;
    }
    
    
    function searchReturnAllByRet($returnfield,$data)
    {
        if(!isset($returnfield) || !isset($data)){
            return false;
        }
        $this->data=$data;
        
        foreach ($data as $d){
            $res[]=$d[$returnfield];
        }
    
        return $res;
    }
    
    
    function is_mobile() {
        if ( empty($_SERVER['HTTP_USER_AGENT']) ) {
            $is_mobile = false;
        } elseif ( strpos($_SERVER['HTTP_USER_AGENT'], 'Mobile') !== false // many mobile devices (all iPhone, iPad, etc.)
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Silk/') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Kindle') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'BlackBerry') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mini') !== false
            || strpos($_SERVER['HTTP_USER_AGENT'], 'Opera Mobi') !== false ) {
            $is_mobile = true;
        } else {
            $is_mobile = false;
        }
    
        return $is_mobile;
    }
    
    
    
  
    function msubstr($str, $start, $length, $charset="utf-8", $suffix=true)
    {
        if(function_exists("mb_substr")){
            $slice = mb_substr($str, $start, $length, $charset);
        }elseif(function_exists('iconv_substr')) {
            $slice = iconv_substr($str,$start,$length,$charset);
            if(false === $slice) {
                $slice = '';
            }
        }else{
            $re['utf-8']   = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|[\xe0-\xef][\x80-\xbf]{2}|[\xf0-\xff][\x80-\xbf]{3}/";
            $re['gb2312'] = "/[\x01-\x7f]|[\xb0-\xf7][\xa0-\xfe]/";
            $re['gbk']    = "/[\x01-\x7f]|[\x81-\xfe][\x40-\xfe]/";
            $re['big5']   = "/[\x01-\x7f]|[\x81-\xfe]([\x40-\x7e]|\xa1-\xfe])/";
            preg_match_all($re[$charset], $str, $match);
            $slice = join("",array_slice($match[0], $start, $length));
        }
        return $suffix ? $slice.'...' : $slice;
    }
    
    
    public function searchArray($array,$key,$value,$returnkey){
        foreach($array as $keyp=>$valuep){
            if($valuep[$key]==$value){
                if($returnkey){
                    return $array[$keyp][$returnkey];
                }else{
                    return $array[$keyp];
                }
            }
        }
        return null;
    }
    
    
    function getsetting() {
        global $_G;
        $settings = array(
            'fids' => array(
                'title' => 'fidstitle',
                'type' => 'mselect',
                'comment' => 'fidscomment',
                'value' => array(),
            ),
            'catids' => array(
                'title' => 'catidstitle',
                'type' => 'mselect',
                'comment' => 'catidscomment',
                'value' => array(),
            ),
            'groups' => array(
                'title' => 'qunzutitle',
                'type' => 'mselect',
                'comment' => 'qunzucomment',
                'value' => array(),
            ),
            'daogou' => array(
                'title' => 'daogoutitle',
                'type' => 'mselect',
                'comment' => 'daogoucomment',
                'value' => array(),
            ),
        );
        loadcache(array('forums', 'grouptype'));
        if(empty($_G['cache']['forums'])) $_G['cache']['forums'] = array();
        foreach($_G['cache']['forums'] as $fid => $forum) {
            $settings['fids']['value'][] = array($fid, ($forum['type'] == 'forum' ? str_repeat('&nbsp;', 4) : ($forum['type'] == 'sub' ? str_repeat('&nbsp;', 8) : '')).$forum['name']);
        }
    
        foreach($_G['cache']['grouptype']['first'] as $gid => $group) {
            $settings['groups']['value'][] = array($gid, $group['name']);
            if($group['secondlist']) {
                foreach($group['secondlist'] as $sgid) {
                    $settings['groups']['value'][] = array($sgid, str_repeat('&nbsp;', 4).$_G['cache']['grouptype']['second'][$sgid]['name']);
                    if(!empty($sgid)){
                        $sgidresult = C::t('forum_forum')->fetch_all_sub_group_by_fup($sgid);
                        if(!empty($sgidresult)){
                            foreach($sgidresult as $subgid) {
                                $settings['groups']['value'][] = array($subgid['fid'], str_repeat('&nbsp;', 8).$subgid['name']);
                            }
                        }
        
                    }
        
                }
            }
        }
        
        loadcache('portalcategory');
        
        $this->getcategory(0);
        
        $settings['catids']['value'] = $this->categoryvalue;
        
        
        //daogoutuijian start
        $tbktiezicategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid(0,1);
        $categoryidselect = '<option value="0">'.plang('qingxuanze').'</option>';
        foreach($tbktiezicategory as $k =>$v){
            
            $settings['daogou']['value'][] = array($v['id'], str_repeat('&nbsp;', 4).$v['title']);
            
            $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($v['id'],1);
             
            foreach($subcategoryids as $subk =>$subv){
                
                $settings['daogou']['value'][] = array($subv['id'], str_repeat('&nbsp;', 8).$subv['title']);
                
                $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($subv['id'],1);
                foreach($sub3categoryids as $sub3k =>$sub3v){
                    $settings['daogou']['value'][] = array($sub3v['id'], str_repeat('&nbsp;', 12).$sub3v['title']);
                }
            }
        }
        //daogoutuijian end
        
        return $settings;
    }
    function getdaogousetting() {
        global $_G;
        $dgcategory = array();
        //daogoutuijian start
        $tbktiezicategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid(0,1);

        foreach($tbktiezicategory as $k =>$v){

            $dgcategory[] = array($v['id'], $v['title']);

            $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($v['id'],1);

            foreach($subcategoryids as $subk =>$subv){

                $dgcategory[] = array($subv['id'], str_repeat('&nbsp;', 4).$subv['title']);

                $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($subv['id'],1);
                foreach($sub3categoryids as $sub3k =>$sub3v){
                    $dgcategory[] = array($sub3v['id'], str_repeat('&nbsp;', 8).$sub3v['title']);
                }
            }
        }
        //daogoutuijian end

        return $dgcategory;
    }

    function getcategory($upid) {
        global $_G;
        foreach($_G['cache']['portalcategory'] as $category) {
            $ishome = false;
            if($category['upid'] == $upid) {
                $this->categoryvalue[] = array($category['catid'], str_repeat('&nbsp;', $category['level'] * 4).$category['catname']);
                $this->getcategory($category['catid'],false);
            }
        }
    }
    
    //$tids:1,2,3
    function get_forumdata($tids,$page=1,$pagesize=10,$filter=0){
        if(empty($tids)){
            return null;
        }
        $page = $page > 0 ? $page : 1;
        $start = ($page - 1) * $pagesize;
        
        $data=array();
        if($filter){
            $where="a.attachment!=0 and a.displayorder>=0 and a.tid in (".dimplode($tids).") and ";
        }else{
            $where="a.displayorder>=0 and a.tid in (".dimplode($tids).") and ";
        }
        //$count=DB::result_first("select count(*) from ".DB::table("forum_thread")." a join ".DB::table("forum_post")." b on a.tid=b.tid where $where b.first=1");
        $data=DB::fetch_all("select a.tid,a.subject,a.dateline,a.views,a.replies,a.author,a.authorid,b.message from ".DB::table("forum_thread")." a join ".DB::table("forum_post")." b on a.tid=b.tid where $where b.first=1 order by FIND_IN_SET(a.tid,'".implode(",",$tids)."') limit ".$start.",$pagesize");
     
        return $data;
        //return array('count'=>$count,'data'=>$data);
    }
    

    function treeCate($catedata){
        require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/tree.class.php';
        $tree= new Tree($catedata);
        $arr=$tree->leaf(0);
      
        return $arr;
    }
    

    
    
    /*
     * $sort_order:SORT_ASC/SORT_DESC
     * $sort_type:SORT_REGULAR/SORT_NUMERIC/SORT_STRING
     */
    function my_sort($arrays,$sort_key,$sort_order=SORT_ASC,$sort_type=SORT_NUMERIC ){
        if(is_array($arrays)){
            foreach ($arrays as $array){
                if(is_array($array)){
                    $key_arrays[] = $array[$sort_key];
                }else{
                    return false;
                }
            }
        }else{
            return false;
        }
        array_multisort($key_arrays,$sort_order,$sort_type,$arrays);
        return $arrays;
    }

    function getcontentname($type) {
        $contentname = "";
        $contenttype = plang('contenttype');
        switch ($type) {
            case "wz" :
                $contentname = $contenttype["wz"];
                break;
            case "hdkdrs" :
                $contentname = $contenttype["hdkdrs"];
                break;
            default :
                $contentname = $contenttype["wz"];
                break;
        }
        return $contentname;
    }

    function getparam($str){
        $data = array();
        $parameter = explode('&',end(explode('?',$str)));
        foreach($parameter as $val){
            $tmp = explode('=',$val);
            $data[$tmp[0]] = $tmp[1];
        }
        return $data;
    }
}
//From: dis'.'m.t'.'ao'.'bao.com
?>