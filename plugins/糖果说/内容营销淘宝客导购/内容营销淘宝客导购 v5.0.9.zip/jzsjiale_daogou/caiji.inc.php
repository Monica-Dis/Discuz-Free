<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$caijiurl = daddslashes(trim($_GET['caijiurl']));
if(empty($caijiurl) || $caijiurl == null){
    showmessage(array('dataexist' => 0));
    dexit();
}else{
    global $_G;
    loadcache('plugin');
    require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';

    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    $tbappkey = $_config['g_appkey'];
    $tbsecretKey = $_config['g_appsecret'];
    //$webbianma = $_config['g_bianma'];
    $webbianma = $_G['charset'];
    $pid = $_config['g_pid'];

    //youxian youhuiquan
    $dsp_cjss = array();
    $dsp_cjss['q'] = $caijiurl;
    $dsp_cjss['currpage'] = '1';
    $dsp_cjss['page_size'] = '1';


    if(empty($pid)){
        showmessage(array('dataexist' => 0));
        dexit();
    }

    $adzoneId = explode("_",$pid);
    $adzoneId = $adzoneId[3];

    if(empty($adzoneId)){
        showmessage(array('dataexist' => 0));
        dexit();
    }

    //fliggy start
    if(strpos($caijiurl,'traveldetail.fliggy.com') !==false){
        $fliggydata = getparam($caijiurl);
        $fliggyid = $fliggydata['id'];

        if(!empty($fliggyid) && $fliggyid != null){
            $dsp_cjss['q'] = "https://item.taobao.com/item.htm?id=".$fliggyid;
        }
    }
    //fliggy end

    $gtkl = new GetTbAPI;
    $gtkl->__construct($tbappkey, $tbsecretKey);
    $tbinfo =  $gtkl->getdgmaterialoptional($dsp_cjss,$adzoneId,$webbianma);

    $tbinfo = json_decode($tbinfo);

    $tbinfo = $tbinfo->result_list->map_data;
    $tbinfo = $tbinfo[0];

    if(!empty($tbinfo)){

        if($webbianma == 'gbk') {
            $coupon_start_time = diconv($tbinfo->coupon_start_time,'UTF-8','GBK');
            $coupon_end_time = diconv($tbinfo->coupon_end_time,'UTF-8','GBK');
            //$info_dxjh = diconv($tbinfo->info_dxjh,'UTF-8','GBK');
            $tk_total_sales = diconv($tbinfo->tk_total_sales,'UTF-8','GBK');
            //$tk_total_commi = diconv($tbinfo->tk_total_commi,'UTF-8','GBK');
            $coupon_id = diconv($tbinfo->coupon_id,'UTF-8','GBK');
            //$num_iid = diconv($tbinfo->num_iid,'UTF-8','GBK');
            $title = diconv($tbinfo->title,'UTF-8','GBK');
            $pict_url = diconv($tbinfo->pict_url,'UTF-8','GBK');
            //$small_images = diconv($tbinfo->small_images,'UTF-8','GBK');
            $reserve_price = diconv($tbinfo->reserve_price,'UTF-8','GBK');
            $zk_final_price = diconv($tbinfo->zk_final_price,'UTF-8','GBK');
            $user_type = diconv($tbinfo->user_type,'UTF-8','GBK');
            $provcity = diconv($tbinfo->provcity,'UTF-8','GBK');
            $item_url = diconv($tbinfo->item_url,'UTF-8','GBK');
            //$include_mkt = diconv($tbinfo->include_mkt,'UTF-8','GBK');
            //$include_dxjh = diconv($tbinfo->include_dxjh,'UTF-8','GBK');
            $commission_rate = diconv($tbinfo->commission_rate,'UTF-8','GBK');
            $volume = diconv($tbinfo->volume,'UTF-8','GBK');
            //$seller_id = diconv($tbinfo->seller_id,'UTF-8','GBK');
            $coupon_total_count = diconv($tbinfo->coupon_total_count,'UTF-8','GBK');
            $coupon_remain_count = diconv($tbinfo->coupon_remain_count,'UTF-8','GBK');
            $coupon_info = diconv($tbinfo->coupon_info,'UTF-8','GBK');
            //$commission_type = diconv($tbinfo->commission_type,'UTF-8','GBK');
            $shop_title = diconv($tbinfo->shop_title,'UTF-8','GBK');
            $shop_dsr = diconv($tbinfo->shop_dsr,'UTF-8','GBK');
            $coupon_share_url = diconv($tbinfo->coupon_share_url,'UTF-8','GBK');
            $url = diconv($tbinfo->url,'UTF-8','GBK');
            /*
            $level_one_category_name = diconv($tbinfo->level_one_category_name,'UTF-8','GBK');
            $level_one_category_id = diconv($tbinfo->level_one_category_id,'UTF-8','GBK');
            $category_name = diconv($tbinfo->category_name,'UTF-8','GBK');
            $category_id = diconv($tbinfo->category_id,'UTF-8','GBK');
            $short_title = diconv($tbinfo->short_title,'UTF-8','GBK');
            $white_image = diconv($tbinfo->white_image,'UTF-8','GBK');
            $oetime = diconv($tbinfo->oetime,'UTF-8','GBK');
            $ostime = diconv($tbinfo->ostime,'UTF-8','GBK');
            $jdd_num = diconv($tbinfo->jdd_num,'UTF-8','GBK');
            $jdd_price = diconv($tbinfo->jdd_price,'UTF-8','GBK');
            $uv_sum_pre_sale = diconv($tbinfo->uv_sum_pre_sale,'UTF-8','GBK');
            $x_id = diconv($tbinfo->x_id,'UTF-8','GBK');
            */
            $coupon_start_fee = diconv($tbinfo->coupon_start_fee,'UTF-8','GBK');
            $coupon_amount = diconv($tbinfo->coupon_amount,'UTF-8','GBK');
            //$item_description = diconv($tbinfo->item_description,'UTF-8','GBK');
            $nick = diconv($tbinfo->nick,'UTF-8','GBK');
            /*
            $orig_price = diconv($tbinfo->orig_price,'UTF-8','GBK');
            $total_stock = diconv($tbinfo->total_stock,'UTF-8','GBK');
            $sell_num = diconv($tbinfo->sell_num,'UTF-8','GBK');
            $stock = diconv($tbinfo->stock,'UTF-8','GBK');
            $tmall_play_activity_info = diconv($tbinfo->tmall_play_activity_info,'UTF-8','GBK');
            */
            $item_id = diconv($tbinfo->item_id,'UTF-8','GBK');
            $real_post_fee = diconv($tbinfo->real_post_fee,'UTF-8','GBK');

        }else{
            $coupon_start_time = $tbinfo->coupon_start_time;
            $coupon_end_time = $tbinfo->coupon_end_time;
            //$info_dxjh = $tbinfo->info_dxjh;
            $tk_total_sales = $tbinfo->tk_total_sales;
            //$tk_total_commi = $tbinfo->tk_total_commi;
            $coupon_id = $tbinfo->coupon_id;
            //$num_iid = $tbinfo->num_iid;
            $title = $tbinfo->title;
            $pict_url = $tbinfo->pict_url;
            //$small_images = $tbinfo->small_images;
            $reserve_price = $tbinfo->reserve_price;
            $zk_final_price = $tbinfo->zk_final_price;
            $user_type = $tbinfo->user_type;
            $provcity = $tbinfo->provcity;
            $item_url = $tbinfo->item_url;
            //$include_mkt = $tbinfo->include_mkt;
            //$include_dxjh = $tbinfo->include_dxjh;
            $commission_rate = $tbinfo->commission_rate;
            $volume = $tbinfo->volume;
            //$seller_id = $tbinfo->seller_id;
            $coupon_total_count = $tbinfo->coupon_total_count;
            $coupon_remain_count = $tbinfo->coupon_remain_count;
            $coupon_info = $tbinfo->coupon_info;
            //$commission_type = $tbinfo->commission_type;
            $shop_title = $tbinfo->shop_title;
            $shop_dsr = $tbinfo->shop_dsr;
            $coupon_share_url = $tbinfo->coupon_share_url;
            $url = $tbinfo->url;
            /*
            $level_one_category_name = $tbinfo->level_one_category_name;
            $level_one_category_id = $tbinfo->level_one_category_id;
            $category_name = $tbinfo->category_name;
            $category_id = $tbinfo->category_id;
            $short_title = $tbinfo->short_title;
            $white_image = $tbinfo->white_image;
            $oetime = $tbinfo->oetime;
            $ostime = $tbinfo->ostime;
            $jdd_num = $tbinfo->jdd_num;
            $jdd_price = $tbinfo->jdd_price;
            $uv_sum_pre_sale = $tbinfo->uv_sum_pre_sale;
            $x_id = $tbinfo->x_id);
            */
            $coupon_start_fee = $tbinfo->coupon_start_fee;
            $coupon_amount = $tbinfo->coupon_amount;
            //$item_description = $tbinfo->item_description;
            $nick = $tbinfo->nick;
            /*
            $orig_price = $tbinfo->orig_price;
            $total_stock = $tbinfo->total_stock;
            $sell_num = $tbinfo->sell_num;
            $stock = $tbinfo->stock;
            $tmall_play_activity_info = $tbinfo->tmall_play_activity_info;
            */
            $item_id = $tbinfo->item_id;
            $real_post_fee = $tbinfo->real_post_fee;
        }

        if(empty($url)){
            $url = $item_url;
        }
        $url = ((!empty($url) && strpos($url,'http') === false)?'https:':'').$url;
        $quanurl = ((!empty($coupon_share_url) && strpos($coupon_share_url,'http') ===false)?'https:':'').$coupon_share_url;
        $user_type = $user_type?'tmall':'taobao';
        $freeshipment = (int)$real_post_fee > 0 ?0:1;
    }else{
        $data = getparam($caijiurl);
        $tbid = $data['id'];

        if(empty($tbid) || $tbid == null){
            showmessage(array('dataexist' => 0));
            dexit();
        }


        $tbinfo =  $gtkl->gettbinfo($tbid);

        $tbinfo = json_decode($tbinfo);
        $tbinfo = $tbinfo->results->n_tbk_item[0];

        if($webbianma == 'gbk') {
            $item_id = diconv($tbinfo->num_iid,'UTF-8','GBK');
            $title = diconv($tbinfo->title,'UTF-8','GBK');
            $pict_url = diconv($tbinfo->pict_url,'UTF-8','GBK');
            $url = diconv($tbinfo->item_url,'UTF-8','GBK');
            $reserve_price = diconv($tbinfo->reserve_price,'UTF-8','GBK');
            $zk_final_price = diconv($tbinfo->zk_final_price,'UTF-8','GBK');
            $user_type = diconv($tbinfo->user_type,'UTF-8','GBK');
            $free_shipment = diconv($tbinfo->free_shipment,'UTF-8','GBK');
        }else{
            $item_id = $tbinfo->num_iid;
            $title = $tbinfo->title;
            $pict_url = $tbinfo->pict_url;
            $url = $tbinfo->item_url;
            $reserve_price = $tbinfo->reserve_price;
            $zk_final_price = $tbinfo->zk_final_price;
            $user_type = $tbinfo->user_type;
            $free_shipment = $tbinfo->free_shipment;
        }

        $url = ((!empty($url) && strpos($url,'http') === false)?'https:':'').$url;
        $quanurl = "";
        $user_type = $user_type?'tmall':'taobao';
        $freeshipment = $free_shipment ?1:0;
        $coupon_info = "";
        $coupon_start_fee = "";
        $coupon_amount = "";
        $coupon_start_time = "";
        $coupon_end_time = "";
        $coupon_id = "";
        $coupon_total_count = "";
        $coupon_remain_count = "";
    }


    $arr = array();
    $arr['dataexist'] = 1;
    $arr['numiid'] = $item_id;
    $arr['title'] = $title;
    $arr['url'] = $url;
    $arr['img'] = $pict_url;
    $arr['youhuiquan'] = $quanurl;
    $arr['yuanjia'] = $reserve_price;
    $arr['xianjia'] = $zk_final_price;
    $arr['tkl'] = "";
    $arr['tklsimple'] = "";
    $arr['couponinfo'] = $coupon_info;
    $arr['couponstartfee'] = $coupon_start_fee;
    $arr['couponamount'] = $coupon_amount;
    $arr['couponstarttime'] = $coupon_start_time;
    $arr['couponendtime'] = $coupon_end_time;
    $arr['couponactivityid'] = $coupon_id;
    $arr['coupontotalcount'] = $coupon_total_count;
    $arr['couponremaincount'] = $coupon_remain_count;
    $arr['status'] = 1;
    $arr['platform'] = $user_type;
    $arr['freeshipment'] = $freeshipment;

    showmessage($arr);
    dexit();
}

function getparam($str){
    $data = array();
    $parameter = explode('&',end(explode('?',$str)));
    foreach($parameter as $val){
        $tmp = explode('=',$val);
        $data[$tmp[0]] = $tmp[1];
    }
    return $data;
}