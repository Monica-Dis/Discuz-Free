<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `pre_jzsjiale_daogou_shangpin`;
CREATE TABLE `pre_jzsjiale_daogou_shangpin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numiid` varchar(1024) NOT NULL DEFAULT '',
  `title` varchar(1024) NOT NULL DEFAULT '',
  `url` varchar(1024) NOT NULL DEFAULT '',
  `youhuiquan` varchar(1024) NOT NULL DEFAULT '',
  `img` varchar(1024) NOT NULL DEFAULT '',  
  `attach` varchar(1024) NOT NULL DEFAULT '',
  `yuanjia` decimal(10,2) NOT NULL DEFAULT 0,
  `xianjia` decimal(10,2) NOT NULL DEFAULT 0,
  `tkl` varchar(1024) NOT NULL DEFAULT '',
  `tklsimple` varchar(1024) NOT NULL DEFAULT '',
  `tkldateline` int(11) unsigned NOT NULL,
  `flag` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `categoryid` int(11) NOT NULL DEFAULT 0,
  `favoritesid` int(11) NOT NULL DEFAULT 0,
  `couponinfo` varchar(255) NOT NULL DEFAULT '',
  `couponstartfee` varchar(255) NOT NULL DEFAULT '',
  `couponamount` varchar(255) NOT NULL DEFAULT '',
  `couponstarttime` varchar(255) NOT NULL DEFAULT '',
  `couponendtime` varchar(255) NOT NULL DEFAULT '',
  `couponactivityid` varchar(255) NOT NULL DEFAULT '',
  `coupontotalcount` int(11) NOT NULL DEFAULT 0,
  `couponremaincount` int(11) NOT NULL DEFAULT 0,
  `platform` varchar(255) NOT NULL DEFAULT '',
  `freeshipment` int(11) NOT NULL DEFAULT 0,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX shangpin_name (`title`)
);

DROP TABLE IF EXISTS `pre_jzsjiale_daogou_category`;
CREATE TABLE `pre_jzsjiale_daogou_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(1024) NOT NULL DEFAULT '',
  `attach` varchar(1024) NOT NULL DEFAULT '',
  `title` varchar(1024) NOT NULL DEFAULT '',
  `color` varchar(1024) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `keywords` varchar(1024) NOT NULL DEFAULT '',
  `description` varchar(1024) NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `sort` int(11) NOT NULL DEFAULT 0,
  `fids` text NOT NULL DEFAULT '',
  `catids` text NOT NULL DEFAULT '',
  `groups` text NOT NULL DEFAULT '',
  `daogou` text NOT NULL DEFAULT '',
  `level` int(11) NOT NULL DEFAULT 1,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX category_name (`title`)
);
    
INSERT INTO `pre_jzsjiale_daogou_category` (`id`,`img`,`title`,`color`,`pid`,`keywords`,`description`,`status`,`sort`,`level`,`dateline`) VALUES 
(1,'','$installlang[install100]','',0,NULL,NULL,1,1,1,1482285431),
(2,'','$installlang[install200]','',0,NULL,NULL,1,2,1,1482285431),
(3,'','$installlang[install300]','',0,NULL,NULL,1,3,1,1482285431),
(4,'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/110.png','$installlang[install110]','',1,NULL,NULL,1,1,2,1482285431),
(5,'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/120.png','$installlang[install120]','',1,NULL,NULL,1,2,2,1482285431),
(6,'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/130.png','$installlang[install130]','',1,NULL,NULL,1,3,2,1482285431),
(7,'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/140.png','$installlang[install140]','',1,NULL,NULL,1,4,2,1482285431),
(8,'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/210.png','$installlang[install210]','',2,NULL,NULL,1,1,2,1482285431),
(9,'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/220.png','$installlang[install220]','',2,NULL,NULL,1,2,2,1482285431),
(10,'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/310.png','$installlang[install310]','',3,NULL,NULL,1,1,2,1482285431),
(11,'source/plugin/jzsjiale_daogou/static/images/daogou/v1/icon/320.png','$installlang[install320]','',3,NULL,NULL,1,2,2,1482285431),
(12,'','$installlang[install111]','',4,NULL,NULL,1,1,3,1482285431),
(13,'','$installlang[install112]','',4,NULL,NULL,1,2,3,1482285431),
(14,'','$installlang[install113]','',4,NULL,NULL,1,3,3,1482285431),
(15,'','$installlang[install114]','',4,NULL,NULL,1,4,3,1482285431),
(16,'','$installlang[install115]','',4,NULL,NULL,1,5,3,1482285431),
(17,'','$installlang[install116]','',4,NULL,NULL,1,6,3,1482285431),
(18,'','$installlang[install117]','',4,NULL,NULL,1,7,3,1482285431),
(19,'','$installlang[install118]','',4,NULL,NULL,1,8,3,1482285431),
(20,'','$installlang[install119]','',4,NULL,NULL,1,9,3,1482285431),
(21,'','$installlang[install121]','',5,NULL,NULL,1,1,3,1482285431),
(22,'','$installlang[install122]','',5,NULL,NULL,1,2,3,1482285431),
(23,'','$installlang[install123]','',5,NULL,NULL,1,3,3,1482285431),
(24,'','$installlang[install124]','',5,NULL,NULL,1,4,3,1482285431),
(25,'','$installlang[install131]','',6,NULL,NULL,1,1,3,1482285431),
(26,'','$installlang[install132]','',6,NULL,NULL,1,2,3,1482285431),
(27,'','$installlang[install133]','',6,NULL,NULL,1,3,3,1482285431),
(28,'','$installlang[install141]','',7,NULL,NULL,1,1,3,1482285431),
(29,'','$installlang[install142]','',7,NULL,NULL,1,2,3,1482285431),
(30,'','$installlang[install143]','',7,NULL,NULL,1,3,3,1482285431),
(31,'','$installlang[install211]','',8,NULL,NULL,1,1,3,1482285431),
(32,'','$installlang[install212]','',8,NULL,NULL,1,2,3,1482285431),
(33,'','$installlang[install221]','',9,NULL,NULL,1,1,3,1482285431),
(34,'','$installlang[install222]','',9,NULL,NULL,1,2,3,1482285431),
(35,'','$installlang[install311]','',10,NULL,NULL,1,1,3,1482285431),
(36,'','$installlang[install312]','',10,NULL,NULL,1,2,3,1482285431),
(37,'','$installlang[install313]','',10,NULL,NULL,1,3,3,1482285431),
(38,'','$installlang[install321]','',11,NULL,NULL,1,1,3,1482285431),
(39,'','$installlang[install322]','',11,NULL,NULL,1,2,3,1482285431);
    
    
DROP TABLE IF EXISTS `pre_jzsjiale_daogou_tiezicategory`;
CREATE TABLE `pre_jzsjiale_daogou_tiezicategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(1024) NOT NULL DEFAULT '',
  `attach` varchar(1024) NOT NULL DEFAULT '',
  `title` varchar(1024) NOT NULL DEFAULT '',
  `color` varchar(1024) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `keywords` varchar(1024) NOT NULL DEFAULT '',
  `description` varchar(1024) NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `sort` int(11) NOT NULL DEFAULT 0,
  `level` int(11) NOT NULL DEFAULT 1,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX tiezicategory_name (`title`)
);

INSERT INTO `pre_jzsjiale_daogou_tiezicategory` (`id`,`img`,`title`,`color`,`pid`,`keywords`,`description`,`status`,`sort`,`level`,`dateline`) VALUES 
(1,'','$installlang[install1]','',0,NULL,NULL,1,1,1,1482285431),
(2,'','$installlang[install2]','',0,NULL,NULL,1,2,1,1482285431),
(3,'','$installlang[install3]','',0,NULL,NULL,1,3,1,1482285431),
(4,'','$installlang[install4]','',0,NULL,NULL,1,4,1,1482285431),
(5,'','$installlang[install5]','',0,NULL,NULL,1,5,1,1482285431),
(6,'','$installlang[install6]','',0,NULL,NULL,1,6,1,1482285431),
(7,'','$installlang[install7]','',0,NULL,NULL,1,7,1,1482285431),
(8,'','$installlang[install8]','',0,NULL,NULL,1,8,1,1482285431);
    
DROP TABLE IF EXISTS `pre_jzsjiale_daogou_huandengpian`;
CREATE TABLE `pre_jzsjiale_daogou_huandengpian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1024) NOT NULL DEFAULT '',
  `imgurl` text NOT NULL DEFAULT '',
  `attach` varchar(1024) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `targets` int(11) NOT NULL DEFAULT 0,
  `sort` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX huandengpian_name (`title`)
);

INSERT INTO `pre_jzsjiale_daogou_huandengpian` (`id`,`title`,`imgurl`,`url`,`targets`,`sort`,`status`,`dateline`) VALUES 
(1,'banner1','source/plugin/jzsjiale_daogou/static/images/daogou/v1/banner1.png','plugin.php?id=jzsjiale_daogou:daogou',1,1,1,1482285431),
(2,'banner2','source/plugin/jzsjiale_daogou/static/images/daogou/v1/banner1.png','plugin.php?id=jzsjiale_daogou:daogou',1,1,1,1482285431),
(3,'banner3','source/plugin/jzsjiale_daogou/static/images/daogou/v1/banner4.png','plugin.php?id=jzsjiale_daogou:daogou',2,1,1,1482285431),
(4,'banner4','source/plugin/jzsjiale_daogou/static/images/daogou/v1/banner4.png','plugin.php?id=jzsjiale_daogou:daogou',2,1,1,1482285431);

DROP TABLE IF EXISTS `pre_jzsjiale_daogou_tiezi`;
CREATE TABLE `pre_jzsjiale_daogou_tiezi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1024) NOT NULL DEFAULT '',
  `tid` int(11) NOT NULL DEFAULT 0,
  `tiezicategoryid` int(11) NOT NULL DEFAULT 0,
  `uid` int(11) NOT NULL DEFAULT 1,
  `sort` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX tiezi_name (`title`)
);

DROP TABLE IF EXISTS `pre_jzsjiale_daogou_daogou`;
CREATE TABLE `pre_jzsjiale_daogou_daogou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(1024) NOT NULL DEFAULT '',
  `value` text NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
   INDEX daogou_name (`key`)
);

INSERT INTO `pre_jzsjiale_daogou_daogou` (`id`,`key`,`value`) VALUES
(1,'title',''),
(2,'keywords',''),
(3,'description',''),
(4,'isopenpchdp','1'),
(5,'isopenmobilehdp','1'),
(6,'defaultimg','source/plugin/jzsjiale_daogou/static/images/daogou/v1/nopic.jpg'),
(7,'headercode',''),
(8,'footercode',''),
(9,'homeadurl','plugin.php?id=jzsjiale_daogou:daogou'),
(10,'homeadimg','source/plugin/jzsjiale_daogou/static/images/daogou/v1/ad1.png'),
(11,'logoimg','source/plugin/jzsjiale_daogou/static/images/daogou/v1/headerlogo.png'),
(12,'erweimaimg','source/plugin/jzsjiale_daogou/static/images/daogou/v1/erweima.png'),
(13,'text1','$installlang[installtext1]'),
(14,'text2','$installlang[installtext2]'),
(15,'text3','$installlang[installtext3]'),
(16,'footermenu1','$installlang[installfootermenu1]'),
(17,'footermenu2','$installlang[installfootermenu2]'),
(18,'isopenmobilebar','1'),
(19,'footerlogoimg','source/plugin/jzsjiale_daogou/static/images/daogou/v1/footerlogo.png'),
(20,'logoimgurl',''),
(21,'footerlogoimgurl',''),
(22,'isopendg','1'),
(23,'daogoustyle','2'),
(24,'weijingtai','0'),
(25,'weijingtaimokuai','0'),
(26,'homelogo121','source/plugin/jzsjiale_daogou/static/images/daogou/v1/homelogo121.png'),
(27,'homelogo600','source/plugin/jzsjiale_daogou/static/images/daogou/v1/homelogo600.png'),
(28,'xinchuangkou','1'),
(29,'faviconico','source/plugin/jzsjiale_daogou/static/images/daogou/v1/favicon.ico'),
(30,'sharehouzhui',''),
(31,'sharepopupleftimg','source/plugin/jzsjiale_daogou/static/images/daogou/v2/download-model-left.jpg'),
(32,'sharepopuprightlogo','source/plugin/jzsjiale_daogou/static/images/daogou/v2/download-model-code-bg.jpg'),
(33,'isopencnxh','1'),
(34,'cnxhnum','4'),
(35,'isopenarticle','1'),
(36,'isopenpost','1'),
(37,'autotuijian','0'),
(38,'autotuijianlll','100'),
(39,'souquantklbtn','0');
    
INSERT INTO `pre_common_nav` (`parentid`,`name`,`title`,`url`,`identifier`,`target`,`type`,`available`,`displayorder`,`highlight`,`level`,`subtype`,`subcols`,`icon`,`subname`,`suburl`,`navtype`,`logo`) VALUES 
(0,'$installlang[installmenu1]','','plugin.php?id=jzsjiale_daogou:faxian','',0,1,1,2,0,0,0,0,'','','',0,''),
(0,'$installlang[installmenu2]','','plugin.php?id=jzsjiale_daogou:haowu','',0,1,1,3,0,0,0,0,'','','',0,''),
(0,'$installlang[installmenu5]','','plugin.php?id=jzsjiale_daogou:souquan','',0,1,1,4,0,0,0,0,'','','',0,''),
(0,'$installlang[installmenu3]','','plugin.php?id=jzsjiale_daogou:xiewenzhang','',0,1,1,5,0,0,0,0,'','','',0,''),
(0,'$installlang[installmenu4]','','forum.php?daogou','',0,1,0,6,0,0,0,0,'','','',0,'');


DROP TABLE IF EXISTS `pre_jzsjiale_daogou_content`;
CREATE TABLE `pre_jzsjiale_daogou_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1024) NOT NULL DEFAULT '',
  `contentid` int(11) NOT NULL DEFAULT 0,
  `tid` int(11) NOT NULL DEFAULT 0,
  `source` varchar(1024) NOT NULL DEFAULT '',
  `remark` text NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL default 1,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  INDEX content_name (`title`)
);
EOF;
runquery ( $sql );


//--CACHE START
$_G[jzsjiale_tpl_daogou][daogoustyle] = '2';
$_G[jzsjiale_tpl_daogou][weijingtai] = '0';
$_G[jzsjiale_tpl_daogou][xinchuangkou] = '0';
//--CACHE END

$pluginid = 'jzsjiale_daogou';


$Hooks = array (
    'viewthread_variables'
);

$data = array ();
foreach ( $Hooks as $Hook ) {
    $data [] = array (
        $Hook => array (
            'plugin' => $pluginid,
            'include' => 'api.class.php',
            'class' => $pluginid . '_api',
            'method' => $Hook
        )
    );
}

require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
WeChatHook::updateAPIHook($data);

//option cache
$daogouoption = C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->getall();

require_once libfile('function/cache');
writetocache('jzsjiale_daogou_daogou', getcachevars(array('daogouoption' => $daogouoption)));
//option cache end


@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/discuz_plugin_jzsjiale_daogou.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/discuz_plugin_jzsjiale_daogou_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/discuz_plugin_jzsjiale_daogou_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/discuz_plugin_jzsjiale_daogou_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/discuz_plugin_jzsjiale_daogou_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/install.php');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_daogou/upgrade.php');
$finish = TRUE;
?>