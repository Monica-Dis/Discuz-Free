<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$categoryid = daddslashes(trim($_GET['categoryid']));
$title = daddslashes(trim($_GET['title']));
$imgurl = daddslashes(trim($_GET['imgurl']));
$url = daddslashes(trim($_GET['url']));
$yuanjia = daddslashes(trim($_GET['yuanjia']));
$xianjia = daddslashes(trim($_GET['xianjia']));
$yhqurl = daddslashes(trim($_GET['yhqurl']));
$tkl = daddslashes(trim($_GET['tkl']));
$numiid = daddslashes(trim($_GET['numiid']));
$couponinfo = daddslashes(trim($_GET['couponinfo']));
$couponstartfee = daddslashes(trim($_GET['couponstartfee']));
$couponamount = daddslashes(trim($_GET['couponamount']));
$couponstarttime = daddslashes(trim($_GET['couponstarttime']));
$couponendtime = daddslashes(trim($_GET['couponendtime']));
$couponactivityid = daddslashes(trim($_GET['couponactivityid']));
$coupontotalcount = daddslashes(trim($_GET['coupontotalcount']));
$couponremaincount = daddslashes(trim($_GET['couponremaincount']));
$platform = daddslashes(trim($_GET['platform']));
$freeshipment = daddslashes(trim($_GET['freeshipment']));
$inajax = daddslashes(trim($_GET['inajax']));

if($inajax){
    
    global $_G;
    
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    $groupid = $_G['groupid'];
    
    if(!$_config['g_isruku'] || !in_array($groupid, (array) unserialize($_config['g_rukugroup']))){
        showmessage(array('code' => 0));
        dexit();
    }
    
    if($_G['charset'] == 'gbk') {
        $title = diconv($title,'UTF-8','GBK');
        $tkl = diconv($tkl,'UTF-8','GBK');
        $couponinfo = diconv($couponinfo,'UTF-8','GBK');
        
        if(strpos($tkl,'%E2%82%AC') !== false){
            $tkl = str_replace("%E2%82%AC","%80",$tkl);
        }
    }
    if(strstr($yhqurl, "#") !== false){
        $yhqurl = "";
    }
    
    if(strstr($tkl, "#") !== false){
        $tkl = "";
    }

    if(strstr($couponinfo, "#") !== false){
        $couponinfo = "";
    }
    if(strstr($couponstartfee, "#") !== false){
        $couponstartfee = "";
    }
    if(strstr($couponamount, "#") !== false){
        $couponamount = "";
    }
    if(strstr($couponstarttime, "#") !== false){
        $couponstarttime = "";
    }
    if(strstr($couponendtime, "#") !== false){
        $couponendtime = "";
    }
    if(strstr($couponactivityid, "#") !== false){
        $couponactivityid = "";
    }
    if(strstr($coupontotalcount, "#") !== false){
        $coupontotalcount = "";
    }
    if(strstr($couponremaincount, "#") !== false){
        $couponremaincount = "";
    }
    if(strstr($platform, "#") !== false || !in_array($platform,array('taobao','tmall','jd','vip','pinduoduo'))){
        $platform = "none";
    }
    if($freeshipment == 1 || $freeshipment == '1'){
        $freeshipment = 1;
    }else{
        $freeshipment = 0;
    }
    $dsp = array('dateline'=>TIMESTAMP);
    $dsp['categoryid'] = $categoryid;
    $dsp['title'] = $title;
    $dsp['img'] = $imgurl;
    $dsp['url'] = $url;
    $dsp['youhuiquan'] = $yhqurl;
    $dsp['yuanjia'] = $yuanjia;
    $dsp['xianjia'] = $xianjia;
    $dsp['tkl'] = $tkl;
    $dsp['numiid'] = $numiid;
    $dsp['status'] = 1;
    $dsp['couponinfo'] = $couponinfo;
    $dsp['couponstartfee'] = $couponstartfee;
    $dsp['couponamount'] = $couponamount;
    $dsp['couponstarttime'] = $couponstarttime;
    $dsp['couponendtime'] = $couponendtime;
    $dsp['couponactivityid'] = $couponactivityid;
    $dsp['coupontotalcount'] = $coupontotalcount;
    $dsp['couponremaincount'] = $couponremaincount;
    $dsp['platform'] = $platform;
    $dsp['freeshipment'] = $freeshipment;
    
    if($spid = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->insert($dsp,true)){
        
		    recache(false,$categoryid);
			showmessage(array('code' => 1,'spid'=>$spid));
            dexit();
	}else{
			showmessage(array('code' => 0));
            dexit();
	}
    
}else{
    showmessage(array('code' => 0));
    dexit();
}


function recache($isallcategory = true,$categoryid = 0){
    /*
    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();

    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
    */
    //20190329 add
    if($isallcategory){
        $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

        foreach ($category as $key => $value){

            $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1,$value["id"]);

            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));
        }
    }else{
        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $categoryid);

        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_shangpin_'.$categoryid, getcachevars(array('tbkshangpin_'.$categoryid => $shangpin_cache_tmp)));
    }

}