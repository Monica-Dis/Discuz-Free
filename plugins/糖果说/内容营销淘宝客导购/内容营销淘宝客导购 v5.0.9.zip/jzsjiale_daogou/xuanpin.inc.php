<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
global $_G, $lang;

loadcache('plugin');

$_config = $_G['cache']['plugin']['jzsjiale_daogou'];


require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';
require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';

$utils = new Utils();

if($act=='updatexpklist'){
	
    cpmsg('jzsjiale_daogou:xpklist_update_ok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=xuanpin', 'succeed');
    dexit();
}elseif($formhash == FORMHASH && $act=='caiji'){
	$favorites_id = dintval(daddslashes(trim($_GET['favorites_id'])));
	$categoryid = dintval(daddslashes(trim($_GET['categoryid'])));
	$favorites_id = daddslashes(trim($favorites_id));
	$categoryid = daddslashes(trim($categoryid));
	
	if(empty($categoryid)){
	    $categoryid = 0;
	}
	if(empty($favorites_id) || $favorites_id == null){
	    cpmsg('jzsjiale_daogou:favorites_id_null', '', 'error');
	    dexit();
	}else{

	    $tbappkey = $_config['g_appkey'];
	    $tbsecretKey = $_config['g_appsecret'];
	    //$webbianma = $_config['g_bianma'];
        $webbianma = $_G['charset'];
	    $pid = $_config['g_pid'];
	    $g_xpkguize = $_config['g_xpkguize'];

	    if(empty($pid)){
	        cpmsg('jzsjiale_daogou:pidnull', '', 'error');
	        dexit();
	    }

	    if(empty($g_xpkguize)){
	        $g_xpkguize = 'xpkgz2';
	    }
	    $dzoneId = explode("_",$pid);
	    $dzoneId = $dzoneId[3];

	    if(empty($dzoneId)){
	        cpmsg('jzsjiale_daogou:pidnull', '', 'error');
	        dexit();
	    }

	    $gtkl = new GetTbAPI;
	    $gtkl->__construct($tbappkey, $tbsecretKey);
	    $tbinfo1 =  $gtkl->getxuanpinkushangpin($favorites_id,$dzoneId,"1");

	    $tbinfo1 = json_decode($tbinfo1);

	    $splistinfo1 = $tbinfo1->result_list->map_data;


	    $tbinfo2 =  $gtkl->getxuanpinkushangpin($favorites_id,$dzoneId,"2");

	    $tbinfo2 = json_decode($tbinfo2);

	    $splistinfo2 = $tbinfo2->result_list->map_data;


	    $splistinfo = array();
	    if(!empty($splistinfo1) && $splistinfo1 != null && !empty($splistinfo2) && $splistinfo2 != null){
	        $splistinfo = array_merge($splistinfo1, $splistinfo2);
	    }

	    if((!empty($splistinfo1) && $splistinfo1 != null) && (empty($splistinfo2) || $splistinfo2 == null)){
	        $splistinfo = $splistinfo1;
	    }

	    if((!empty($splistinfo2) && $splistinfo2 != null) && (empty($splistinfo1) || $splistinfo1 == null)){
	        $splistinfo = $splistinfo2;
	    }

	    //$total_results = $tbinfo->total_results;


	    $isok = false;
	    $isruku = false;
	    $isbidui = false;
	    $isupdate = false;

	    $cacheshangpin = array();

	    if($g_xpkguize == 'xpkgz1'){
	        $isruku = true;
	        $isbidui = false;
	        $isupdate = false;
	    }elseif($g_xpkguize == 'xpkgz2'){

	        //cache start

	        if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$categoryid.'.php')){
	            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$categoryid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$categoryid};

	            if(!empty($tbkshangpin)){
	                $cacheshangpin = $utils->search2($categoryid,'categoryid',$favorites_id,'favoritesid',$tbkshangpin);
	            }

	        }else{
	            /*
	            $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();

	            require_once libfile('function/cache');
	            writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
	            */
                recache(false,$categoryid);

	            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$categoryid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$categoryid};
	            if(!empty($tbkshangpin)){
	                $cacheshangpin = $utils->search2($categoryid,'categoryid',$favorites_id,'favoritesid',$tbkshangpin);
	            }
	        }

	        //cache end

	        $isruku = false;
	        $isbidui = true;
	        $isupdate = false;
	    }elseif($g_xpkguize == 'xpkgz3'){
	        /*
	        C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->deletebycategoryidandfavoritesid($categoryid,$favorites_id);

	        $isruku = true;
	        $isbidui = false;
	        */

	        //20171026
	        //cache start

	        if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$categoryid.'.php')){
	            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$categoryid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$categoryid};

	            if(!empty($tbkshangpin)){
	                $cacheshangpin = $utils->search2($categoryid,'categoryid',$favorites_id,'favoritesid',$tbkshangpin);
	            }

	        }else{
                recache(false,$categoryid);

                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$categoryid.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$categoryid};

	            if(!empty($tbkshangpin)){
	                $cacheshangpin = $utils->search2($categoryid,'categoryid',$favorites_id,'favoritesid',$tbkshangpin);
	            }
	        }

	        //cache end

	        $isruku = false;
	        $isbidui = true;
	        $isupdate = true;
	    }

	    foreach($splistinfo as $spi){
	        $isupdate2 = false;
	        if($webbianma == 'gbk') {
	            $numiid = diconv(dhtmlspecialchars($spi->item_id),'UTF-8','GBK');
	            $title = diconv(dhtmlspecialchars($spi->title),'UTF-8','GBK');
	            $click_url = diconv(dhtmlspecialchars($spi->click_url),'UTF-8','GBK');
                $click_url = ((strpos($click_url,'http') ===false)?'https:':'').$click_url;
	            $pict_url = diconv(dhtmlspecialchars($spi->pict_url),'UTF-8','GBK');
                $pict_url = ((strpos($pict_url,'http') ===false)?'https:':'').$pict_url;
	            $reserve_price = diconv(dhtmlspecialchars($spi->reserve_price),'UTF-8','GBK');
	            $zk_final_price = diconv(dhtmlspecialchars($spi->zk_final_price),'UTF-8','GBK');
	            if(!empty($spi->coupon_click_url)){
                    $coupon_click_url = diconv(dhtmlspecialchars($spi->coupon_click_url),'UTF-8','GBK');
                    $coupon_click_url = ((strpos($coupon_click_url,'http') ===false)?'https:':'').$coupon_click_url;
                    $coupon_info = diconv(dhtmlspecialchars($spi->coupon_info),'UTF-8','GBK');
                    $coupon_start_time = diconv(dhtmlspecialchars($spi->coupon_start_time),'UTF-8','GBK');
                    $coupon_start_time = date('Y-m-d',$coupon_start_time/1000);
                    $coupon_end_time = diconv(dhtmlspecialchars($spi->coupon_end_time),'UTF-8','GBK');
                    $coupon_end_time = date('Y-m-d',$coupon_end_time/1000);
                    $coupon_total_count = diconv(dhtmlspecialchars($spi->coupon_total_count),'UTF-8','GBK');
                    $coupon_remain_count = diconv(dhtmlspecialchars($spi->coupon_remain_count),'UTF-8','GBK');
                }else{
                    $coupon_click_url = "";
                    $coupon_info = "";
                    $coupon_start_time = "";
                    $coupon_end_time = "";
                    $coupon_total_count = "";
                    $coupon_remain_count = "";
                }
                $user_type = diconv(dhtmlspecialchars($spi->user_type),'UTF-8','GBK');
	        }else{
	            $numiid = dhtmlspecialchars($spi->item_id);
	            $title = dhtmlspecialchars($spi->title);
	            $click_url = dhtmlspecialchars($spi->click_url);
                $click_url = ((strpos($click_url,'http') ===false)?'https:':'').$click_url;
	            $pict_url = dhtmlspecialchars($spi->pict_url);
                $pict_url = ((strpos($pict_url,'http') ===false)?'https:':'').$pict_url;
	            $reserve_price = dhtmlspecialchars($spi->reserve_price);
	            $zk_final_price = dhtmlspecialchars($spi->zk_final_price);
                if(!empty($spi->coupon_click_url)){
                    $coupon_click_url = dhtmlspecialchars($spi->coupon_click_url);
                    $coupon_click_url = ((strpos($coupon_click_url,'http') ===false)?'https:':'').$coupon_click_url;
                    $coupon_info = dhtmlspecialchars($spi->coupon_info);
                    $coupon_start_time = dhtmlspecialchars($spi->coupon_start_time);
                    $coupon_start_time = date('Y-m-d',$coupon_start_time/1000);
                    $coupon_end_time = dhtmlspecialchars($spi->coupon_end_time);
                    $coupon_end_time = date('Y-m-d',$coupon_end_time/1000);
                    $coupon_total_count = dhtmlspecialchars($spi->coupon_total_count);
                    $coupon_remain_count = dhtmlspecialchars($spi->coupon_remain_count);
                }else{
                    $coupon_click_url = "";
                    $coupon_info = "";
                    $coupon_start_time = "";
                    $coupon_end_time = "";
                    $coupon_total_count = "";
                    $coupon_remain_count = "";
                }
                $user_type = dhtmlspecialchars($spi->user_type);
            }

	        if($isbidui){

	            $iscunzaiid = $utils->searchGetOne($numiid,'numiid','id',$cacheshangpin);
	            if(!empty($iscunzaiid) && $iscunzaiid != null && $iscunzaiid > 0 && $iscunzaiid != ""){
	                if($isupdate){
	                    $isruku = true;
	                    $isupdate2 = true;
	                }else{
	                    $isruku = false;
	                    $isupdate2 = false;
	                }
	            }else{
	                $isruku = true;
	                $isupdate2 = false;
	            }

	        }

	        if(empty($click_url) || empty($numiid) || empty($title)){
	            $isruku = false;
	        }
	        if($isruku && !$isupdate2){
	            $spsetting = array('dateline'=>TIMESTAMP);
	            $spsetting['numiid'] = $numiid;
	            $spsetting['title'] = $title;
	            $spsetting['url'] = $click_url;
	            $spsetting['img'] = $pict_url;
	            $spsetting['youhuiquan'] = $coupon_click_url;//$click_url;
	            $spsetting['yuanjia'] = $reserve_price;
	            $spsetting['xianjia'] = $zk_final_price;
	            $spsetting['tkl'] = "";
	            $spsetting['categoryid'] = $categoryid;
	            $spsetting['favoritesid'] = $favorites_id;
                $spsetting['status'] = 1;
                $spsetting['couponinfo'] = $coupon_info;
                $spsetting['couponstarttime'] = $coupon_start_time;
                $spsetting['couponendtime'] = $coupon_end_time;
                $spsetting['couponactivityid'] = '';
                $spsetting['coupontotalcount'] = $coupon_total_count;
                $spsetting['couponremaincount'] = $coupon_remain_count;
                $spsetting['platform'] = $user_type?'tmall':'taobao';

                if(!empty($coupon_info)){
                    $patterns = "/\d+/";
                    $yhqarrtmp = array();
                    preg_match_all($patterns,$coupon_info,$yhqarrtmp);

                    $yhqarr=$yhqarrtmp[0];

                    if($yhqarr[1] > 0 && !empty($yhqarr[1])){
                        if($yhqarr[0] > 0 && !empty($yhqarr[0])){
                            $spsetting['couponstartfee'] = $yhqarr[0];
                        }
                        $spsetting['couponamount'] = $yhqarr[1];
                    }elseif($yhqarr[1] <= 0 || empty($yhqarr[1])){
                        $spsetting['couponamount'] = $yhqarr[0];
                    }
                }

	            if(C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->insert($spsetting,true)){
	                $isok = true;
	            }else{
	                $isok = false;
	            }
	        }elseif($isruku && $isupdate2){
	            $spsetting = array('dateline'=>TIMESTAMP);
	            $spsetting['numiid'] = $numiid;
	            $spsetting['title'] = $title;
	            $spsetting['url'] = $click_url;
	            $spsetting['img'] = $pict_url;
	            $spsetting['youhuiquan'] = $coupon_click_url;//$click_url;
	            $spsetting['yuanjia'] = $reserve_price;
	            $spsetting['xianjia'] = $zk_final_price;
	            $spsetting['tkl'] = "";
	            $spsetting['categoryid'] = $categoryid;
	            $spsetting['favoritesid'] = $favorites_id;
	            $spsetting['status'] = 1;
                $spsetting['couponinfo'] = $coupon_info;
                $spsetting['couponstarttime'] = $coupon_start_time;
                $spsetting['couponendtime'] = $coupon_end_time;
                $spsetting['couponactivityid'] = '';
                $spsetting['coupontotalcount'] = $coupon_total_count;
                $spsetting['couponremaincount'] = $coupon_remain_count;
                $spsetting['platform'] = $user_type?'tmall':'taobao';

                if(!empty($coupon_info)){
                    $patterns = "/\d+/";
                    $yhqarrtmp = array();
                    preg_match_all($patterns,$coupon_info,$yhqarrtmp);

                    $yhqarr=$yhqarrtmp[0];

                    if($yhqarr[1] > 0 && !empty($yhqarr[1])){
                        if($yhqarr[0] > 0 && !empty($yhqarr[0])){
                            $spsetting['couponstartfee'] = $yhqarr[0];
                        }
                        $spsetting['couponamount'] = $yhqarr[1];
                    }elseif($yhqarr[1] <= 0 || empty($yhqarr[1])){
                        $spsetting['couponamount'] = $yhqarr[0];
                    }
                }

	            if(C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->update($iscunzaiid,$spsetting)){
	                $isok = true;
	            }else{
	                $isok = false;
	            }
	        }

	    }

	    if($g_xpkguize == 'xpkgz3'){
	        $xpnumiids = array();
	        foreach($splistinfo as $spi){
	            if($webbianma == 'gbk') {
	                $numiid = diconv($spi->item_id,'UTF-8','GBK');
	            }else{
	                $numiid = $spi->item_id;
	            }
	            $xpnumiids[]=$numiid;
	        }

	        foreach($cacheshangpin as $cs){
	            if(!in_array($cs['numiid'],$xpnumiids)){
	                C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->deletebycategoryidandfavoritesidandnumiid($categoryid,$favorites_id,$cs['numiid']);
	            }
	        }
	    }

	    if($isok){
	        recache(false,$categoryid);
	        cpmsg('jzsjiale_daogou:xpkcaijiok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=xuanpin', 'succeed');
	    }else{
	        cpmsg('jzsjiale_daogou:xpkcaijierror', '', 'error');
	    }

	}
	
	dexit();
}elseif($formhash == FORMHASH && $act=='bind') {
    $favorites_id = dintval(daddslashes(trim($_GET['favorites_id'])));
    $categoryid = dintval(daddslashes(trim($_GET['categoryid'])));
    $favorites_id = daddslashes(trim($favorites_id));
    $categoryid = daddslashes(trim($categoryid));

    if (empty($categoryid)) {
        $categoryid = 0;
    }
    if (empty($favorites_id) || $favorites_id == null) {
        cpmsg('jzsjiale_daogou:favorites_id_null', '', 'error');
        dexit();
    } else {
        $setting = C::t('common_setting')->fetch_all(array('jdaogou_xuanpin_bind'));
        $setting = (array)unserialize($setting['jdaogou_xuanpin_bind']);

        $setting[$favorites_id] = $categoryid;

        unset($setting['0']);
        $settings = array('jdaogou_xuanpin_bind' => serialize($setting));
        C::t('common_setting')->update_batch($settings);
        updatecache('setting');
        cpmsg('jzsjiale_daogou:bindok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=xuanpin', 'succeed');

        dexit();
    }
}elseif($formhash == FORMHASH && $act=='yijiancaiji') {
    $setting = C::t('common_setting')->fetch_all(array('jdaogou_xuanpin_bind'));
    $setting = (array)unserialize($setting['jdaogou_xuanpin_bind']);

    if(empty($setting)){
        cpmsg('jzsjiale_daogou:favorites_notbind', '', 'error');
        dexit();
    }

    $next_favorites_id = daddslashes(trim($_GET['next']));
    if($next_favorites_id){
        $current = $next_favorites_id;
    }else{
        reset($setting);
        $current = key($setting);
    }

    $nowkey = false;
    $next = "";
    foreach ($setting as $key => $val) {
        if($key == $current) {
            $nowkey = true;
            if(end(array_keys($setting)) != $current){
                continue;
            }else{
                $next = "end";
                break;
            }
        }
        if($nowkey){
            $next = $key;
            break;
        }
    }

    $nextlink = "action=plugins&operation=config&do=$pluginid&identifier=jzsjiale_daogou&pmod=xuanpin&act=yijiancaiji&next=$next&formhash=".FORMHASH;


    if($current != "end"){
        if(!empty($setting[$current]) && $setting[$current] != 0 && $setting[$current] != "0"){
            //caiji start
            $favorites_id = $current;
            $categoryid = $setting[$current];

            $tbappkey = $_config['g_appkey'];
            $tbsecretKey = $_config['g_appsecret'];
            //$webbianma = $_config['g_bianma'];
            $webbianma = $_G['charset'];
            $pid = $_config['g_pid'];
            $g_xpkguize = $_config['g_xpkguize'];

            if(empty($pid)){
                cpmsg('jzsjiale_daogou:pidnull', '', 'error');
                dexit();
            }

            if(empty($g_xpkguize)){
                $g_xpkguize = 'xpkgz2';
            }
            $dzoneId = explode("_",$pid);
            $dzoneId = $dzoneId[3];

            if(empty($dzoneId)){
                cpmsg('jzsjiale_daogou:pidnull', '', 'error');
                dexit();
            }

            $gtkl = new GetTbAPI;
            $gtkl->__construct($tbappkey, $tbsecretKey);
            $tbinfo1 =  $gtkl->getxuanpinkushangpin($favorites_id,$dzoneId,"1");

            $tbinfo1 = json_decode($tbinfo1);

            $splistinfo1 = $tbinfo1->result_list->map_data;


            $tbinfo2 =  $gtkl->getxuanpinkushangpin($favorites_id,$dzoneId,"2");

            $tbinfo2 = json_decode($tbinfo2);

            $splistinfo2 = $tbinfo2->result_list->map_data;


            $splistinfo = array();
            if(!empty($splistinfo1) && $splistinfo1 != null && !empty($splistinfo2) && $splistinfo2 != null){
                $splistinfo = array_merge($splistinfo1, $splistinfo2);
            }

            if((!empty($splistinfo1) && $splistinfo1 != null) && (empty($splistinfo2) || $splistinfo2 == null)){
                $splistinfo = $splistinfo1;
            }

            if((!empty($splistinfo2) && $splistinfo2 != null) && (empty($splistinfo1) || $splistinfo1 == null)){
                $splistinfo = $splistinfo2;
            }

            //$total_results = $tbinfo->total_results;


            $isok = false;
            $isruku = false;
            $isbidui = false;
            $isupdate = false;

            $cacheshangpin = array();

            if($g_xpkguize == 'xpkgz1'){
                $isruku = true;
                $isbidui = false;
                $isupdate = false;
            }elseif($g_xpkguize == 'xpkgz2'){

                //cache start

                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$categoryid.'.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$categoryid.'.php';
                    $tbkshangpin = ${'tbkshangpin_'.$categoryid};

                    if(!empty($tbkshangpin)){
                        $cacheshangpin = $utils->search2($categoryid,'categoryid',$favorites_id,'favoritesid',$tbkshangpin);
                    }

                }else{
                    /*
                    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();

                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
                    */
                    recache(false,$categoryid);

                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$categoryid.'.php';
                    $tbkshangpin = ${'tbkshangpin_'.$categoryid};
                    if(!empty($tbkshangpin)){
                        $cacheshangpin = $utils->search2($categoryid,'categoryid',$favorites_id,'favoritesid',$tbkshangpin);
                    }
                }

                //cache end

                $isruku = false;
                $isbidui = true;
                $isupdate = false;
            }elseif($g_xpkguize == 'xpkgz3'){
                /*
                C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->deletebycategoryidandfavoritesid($categoryid,$favorites_id);

                $isruku = true;
                $isbidui = false;
                */

                //20171026
                //cache start

                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$categoryid.'.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$categoryid.'.php';
                    $tbkshangpin = ${'tbkshangpin_'.$categoryid};

                    if(!empty($tbkshangpin)){
                        $cacheshangpin = $utils->search2($categoryid,'categoryid',$favorites_id,'favoritesid',$tbkshangpin);
                    }

                }else{
                    recache(false,$categoryid);

                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$categoryid.'.php';
                    $tbkshangpin = ${'tbkshangpin_'.$categoryid};

                    if(!empty($tbkshangpin)){
                        $cacheshangpin = $utils->search2($categoryid,'categoryid',$favorites_id,'favoritesid',$tbkshangpin);
                    }
                }

                //cache end

                $isruku = false;
                $isbidui = true;
                $isupdate = true;
            }

            foreach($splistinfo as $spi){
                $isupdate2 = false;
                if($webbianma == 'gbk') {
                    $numiid = diconv(dhtmlspecialchars($spi->item_id),'UTF-8','GBK');
                    $title = diconv(dhtmlspecialchars($spi->title),'UTF-8','GBK');
                    $click_url = diconv(dhtmlspecialchars($spi->click_url),'UTF-8','GBK');
                    $click_url = ((strpos($click_url,'http') ===false)?'https:':'').$click_url;
                    $pict_url = diconv(dhtmlspecialchars($spi->pict_url),'UTF-8','GBK');
                    $pict_url = ((strpos($pict_url,'http') ===false)?'https:':'').$pict_url;
                    $reserve_price = diconv(dhtmlspecialchars($spi->reserve_price),'UTF-8','GBK');
                    $zk_final_price = diconv(dhtmlspecialchars($spi->zk_final_price),'UTF-8','GBK');
                    if(!empty($spi->coupon_click_url)){
                        $coupon_click_url = diconv(dhtmlspecialchars($spi->coupon_click_url),'UTF-8','GBK');
                        $coupon_click_url = ((strpos($coupon_click_url,'http') ===false)?'https:':'').$coupon_click_url;
                        $coupon_info = diconv(dhtmlspecialchars($spi->coupon_info),'UTF-8','GBK');
                        $coupon_start_time = diconv(dhtmlspecialchars($spi->coupon_start_time),'UTF-8','GBK');
                        $coupon_start_time = date('Y-m-d',$coupon_start_time/1000);
                        $coupon_end_time = diconv(dhtmlspecialchars($spi->coupon_end_time),'UTF-8','GBK');
                        $coupon_end_time = date('Y-m-d',$coupon_end_time/1000);
                        $coupon_total_count = diconv(dhtmlspecialchars($spi->coupon_total_count),'UTF-8','GBK');
                        $coupon_remain_count = diconv(dhtmlspecialchars($spi->coupon_remain_count),'UTF-8','GBK');
                    }else{
                        $coupon_click_url = "";
                        $coupon_info = "";
                        $coupon_start_time = "";
                        $coupon_end_time = "";
                        $coupon_total_count = "";
                        $coupon_remain_count = "";
                    }
                    $user_type = diconv(dhtmlspecialchars($spi->user_type),'UTF-8','GBK');
                }else{
                    $numiid = dhtmlspecialchars($spi->item_id);
                    $title = dhtmlspecialchars($spi->title);
                    $click_url = dhtmlspecialchars($spi->click_url);
                    $click_url = ((strpos($click_url,'http') ===false)?'https:':'').$click_url;
                    $pict_url = dhtmlspecialchars($spi->pict_url);
                    $pict_url = ((strpos($pict_url,'http') ===false)?'https:':'').$pict_url;
                    $reserve_price = dhtmlspecialchars($spi->reserve_price);
                    $zk_final_price = dhtmlspecialchars($spi->zk_final_price);
                    if(!empty($spi->coupon_click_url)){
                        $coupon_click_url = dhtmlspecialchars($spi->coupon_click_url);
                        $coupon_click_url = ((strpos($coupon_click_url,'http') ===false)?'https:':'').$coupon_click_url;
                        $coupon_info = dhtmlspecialchars($spi->coupon_info);
                        $coupon_start_time = dhtmlspecialchars($spi->coupon_start_time);
                        $coupon_start_time = date('Y-m-d',$coupon_start_time/1000);
                        $coupon_end_time = dhtmlspecialchars($spi->coupon_end_time);
                        $coupon_end_time = date('Y-m-d',$coupon_end_time/1000);
                        $coupon_total_count = dhtmlspecialchars($spi->coupon_total_count);
                        $coupon_remain_count = dhtmlspecialchars($spi->coupon_remain_count);
                    }else{
                        $coupon_click_url = "";
                        $coupon_info = "";
                        $coupon_start_time = "";
                        $coupon_end_time = "";
                        $coupon_total_count = "";
                        $coupon_remain_count = "";
                    }
                    $user_type = dhtmlspecialchars($spi->user_type);
                }

                if($isbidui){

                    $iscunzaiid = $utils->searchGetOne($numiid,'numiid','id',$cacheshangpin);
                    if(!empty($iscunzaiid) && $iscunzaiid != null && $iscunzaiid > 0 && $iscunzaiid != ""){
                        if($isupdate){
                            $isruku = true;
                            $isupdate2 = true;
                        }else{
                            $isruku = false;
                            $isupdate2 = false;
                        }
                    }else{
                        $isruku = true;
                        $isupdate2 = false;
                    }

                }

                if(empty($click_url) || empty($numiid) || empty($title)){
                    $isruku = false;
                }
                if($isruku && !$isupdate2){
                    $spsetting = array('dateline'=>TIMESTAMP);
                    $spsetting['numiid'] = $numiid;
                    $spsetting['title'] = $title;
                    $spsetting['url'] = $click_url;
                    $spsetting['img'] = $pict_url;
                    $spsetting['youhuiquan'] = $coupon_click_url;//$click_url;
                    $spsetting['yuanjia'] = $reserve_price;
                    $spsetting['xianjia'] = $zk_final_price;
                    $spsetting['tkl'] = "";
                    $spsetting['categoryid'] = $categoryid;
                    $spsetting['favoritesid'] = $favorites_id;
                    $spsetting['status'] = 1;
                    $spsetting['couponinfo'] = $coupon_info;
                    $spsetting['couponstarttime'] = $coupon_start_time;
                    $spsetting['couponendtime'] = $coupon_end_time;
                    $spsetting['couponactivityid'] = '';
                    $spsetting['coupontotalcount'] = $coupon_total_count;
                    $spsetting['couponremaincount'] = $coupon_remain_count;
                    $spsetting['platform'] = $user_type?'tmall':'taobao';

                    if(!empty($coupon_info)){
                        $patterns = "/\d+/";
                        $yhqarrtmp = array();
                        preg_match_all($patterns,$coupon_info,$yhqarrtmp);

                        $yhqarr=$yhqarrtmp[0];

                        if($yhqarr[1] > 0 && !empty($yhqarr[1])){
                            if($yhqarr[0] > 0 && !empty($yhqarr[0])){
                                $spsetting['couponstartfee'] = $yhqarr[0];
                            }
                            $spsetting['couponamount'] = $yhqarr[1];
                        }elseif($yhqarr[1] <= 0 || empty($yhqarr[1])){
                            $spsetting['couponamount'] = $yhqarr[0];
                        }
                    }

                    if(C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->insert($spsetting,true)){
                        $isok = true;
                    }else{
                        $isok = false;
                    }
                }elseif($isruku && $isupdate2){
                    $spsetting = array('dateline'=>TIMESTAMP);
                    $spsetting['numiid'] = $numiid;
                    $spsetting['title'] = $title;
                    $spsetting['url'] = $click_url;
                    $spsetting['img'] = $pict_url;
                    $spsetting['youhuiquan'] = $coupon_click_url;//$click_url;
                    $spsetting['yuanjia'] = $reserve_price;
                    $spsetting['xianjia'] = $zk_final_price;
                    $spsetting['tkl'] = "";
                    $spsetting['categoryid'] = $categoryid;
                    $spsetting['favoritesid'] = $favorites_id;
                    $spsetting['status'] = 1;
                    $spsetting['couponinfo'] = $coupon_info;
                    $spsetting['couponstarttime'] = $coupon_start_time;
                    $spsetting['couponendtime'] = $coupon_end_time;
                    $spsetting['couponactivityid'] = '';
                    $spsetting['coupontotalcount'] = $coupon_total_count;
                    $spsetting['couponremaincount'] = $coupon_remain_count;
                    $spsetting['platform'] = $user_type?'tmall':'taobao';

                    if(!empty($coupon_info)){
                        $patterns = "/\d+/";
                        $yhqarrtmp = array();
                        preg_match_all($patterns,$coupon_info,$yhqarrtmp);

                        $yhqarr=$yhqarrtmp[0];

                        if($yhqarr[1] > 0 && !empty($yhqarr[1])){
                            if($yhqarr[0] > 0 && !empty($yhqarr[0])){
                                $spsetting['couponstartfee'] = $yhqarr[0];
                            }
                            $spsetting['couponamount'] = $yhqarr[1];
                        }elseif($yhqarr[1] <= 0 || empty($yhqarr[1])){
                            $spsetting['couponamount'] = $yhqarr[0];
                        }
                    }

                    if(C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->update($iscunzaiid,$spsetting)){
                        $isok = true;
                    }else{
                        $isok = false;
                    }
                }

            }

            if($g_xpkguize == 'xpkgz3'){
                $xpnumiids = array();
                foreach($splistinfo as $spi){
                    if($webbianma == 'gbk') {
                        $numiid = diconv($spi->item_id,'UTF-8','GBK');
                    }else{
                        $numiid = $spi->item_id;
                    }
                    $xpnumiids[]=$numiid;
                }

                foreach($cacheshangpin as $cs){
                    if(!in_array($cs['numiid'],$xpnumiids)){
                        C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->deletebycategoryidandfavoritesidandnumiid($categoryid,$favorites_id,$cs['numiid']);
                    }
                }
            }

            if($isok){
                recache(false,$categoryid);
            }
            //caiji end
        }

        cpmsg(plang('curr_yijiantongbu'), $nextlink, 'loading',array('favorites_id' => $current));
    }else{
        cpmsg('jzsjiale_daogou:xpkcaijiok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=xuanpin', 'succeed');
    }
    dexit();
}






/////////caiji start

echo '<div class="colorbox"><h4>'.plang('aboutxp').'</h4>'.
                      '<table cellspacing="0" cellpadding="3"><tr>'.
                      '<td valign="top">'.plang('xpdescription').'</td></tr></table>'.
                      '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

/////////caiji end

$tbappkey = $_config['g_appkey'];
$tbsecretKey = $_config['g_appsecret'];
//$webbianma = $_config['g_bianma'];
$pid = $_config['g_pid'];
$webbianma = $_G['charset'];

$dzoneId = explode("_",$pid);
$dzoneId = $dzoneId[3];

if(empty($dzoneId)){
    cpmsg('jzsjiale_daogou:pidnull', '', 'error');
    dexit();
}

$gtkl = new GetTbAPI;
$gtkl->__construct($tbappkey, $tbsecretKey);
$tbxuanpinkulist = $gtkl->getxuanpinkulist("1",$dzoneId);
$tbxuanpinkulist = json_decode($tbxuanpinkulist,true);
$tbxuanpinkulist_count = $tbxuanpinkulist['result_list']['map_data']['favorites_info']['total_count'];
$tbxuanpinkulist = $tbxuanpinkulist['result_list']['map_data']['favorites_info']['favorites_list']['favorites_detail'];
if($tbxuanpinkulist_count == "1"){
    $tbxuanpinkulist = array($tbxuanpinkulist);
}


$tbxuanpinkulist2 = $gtkl->getxuanpinkulist("2",$dzoneId);
$tbxuanpinkulist2 = json_decode($tbxuanpinkulist2,true);
$tbxuanpinkulist2_count = $tbxuanpinkulist2['result_list']['map_data']['favorites_info']['total_count'];
$tbxuanpinkulist2 = $tbxuanpinkulist2['result_list']['map_data']['favorites_info']['favorites_list']['favorites_detail'];
if($tbxuanpinkulist2_count == "1"){
    $tbxuanpinkulist2 = array($tbxuanpinkulist2);
}

$xpklist = array();
if(!empty($tbxuanpinkulist) && $tbxuanpinkulist != null && !empty($tbxuanpinkulist[0]) && !empty($tbxuanpinkulist2) && $tbxuanpinkulist2 != null && !empty($tbxuanpinkulist2[0])){
    $xpklist = array_merge($tbxuanpinkulist, $tbxuanpinkulist2);
}

if((!empty($tbxuanpinkulist) && $tbxuanpinkulist != null && !empty($tbxuanpinkulist[0])) && (empty($tbxuanpinkulist2) || $tbxuanpinkulist2 == null || empty($tbxuanpinkulist2[0]))){
    $xpklist = $tbxuanpinkulist;
}

if((!empty($tbxuanpinkulist2) && $tbxuanpinkulist2 != null && !empty($tbxuanpinkulist2[0])) && (empty($tbxuanpinkulist) || $tbxuanpinkulist == null || empty($tbxuanpinkulist[0]))){
    $xpklist = $tbxuanpinkulist2;
}

showtableheader(plang('xuanpinkulist').'(&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=xuanpin&act=updatexpklist" style="color:red;">'.plang('updatexpklist').'</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=xuanpin&act=yijiancaiji&formhash='.FORMHASH.'" style="color:red;">'.plang('yijiancaiji').'</a>)', '');
showsubtitle(plang('xpktitle'));
$index = 1;
foreach($xpklist as $d){
	showtablerow('', array('width="50"'), array(
	$index,
	diconv($d['favorites_id'],'UTF-8','GBK'),
	($webbianma == "gbk")?'<span title="'.diconv($d['favorites_title'],'UTF-8','GBK').'">'.mb_substr(diconv($d['favorites_title'],'UTF-8','GBK'),0,80).'</span>':'<span title="'.$d['favorites_title'].'">'.mb_substr($d['favorites_title'],0,80).'</span>',
	'<span style=\'float:left;\'>'.plang('favorites_caiji').'</span>'.getcategoryselect($d['favorites_id']),
    bindcategoryselect($d['favorites_id']))
	);
	$index++;
}

showtablefooter(); /*Dism��taobao��com*/


function recache($isallcategory = true,$categoryid = 0){
    /*
    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();

    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
    */
    //20190329 add
    if($isallcategory){
        $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

        foreach ($category as $key => $value){

            $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1,$value["id"]);

            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));
        }
    }else{
        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $categoryid);

        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_shangpin_'.$categoryid, getcachevars(array('tbkshangpin_'.$categoryid => $shangpin_cache_tmp)));
    }

}

function getcategoryselect($favorites_id) {
         $categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid(0,1);
         $categoryidselect = '<option value="0">------'.plang('qingxuanze').'------</option>';
         $categoryidselect .= '<option value="0">------'.plang('bufenlei').'------</option>';
         foreach($categoryids as $k =>$v){
               $categoryidselect .= '<option value="'.$v['id'].'" >'.$v['title'].'</option>';
               $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($v['id'],1);
                 foreach($subcategoryids as $subk =>$subv){
                      $categoryidselect .= '<option value="'.$subv['id'].'" >&nbsp;&nbsp;&nbsp;&nbsp;'.$subv['title'].'</option>';
                      
                      $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($subv['id'],1);
                      foreach($sub3categoryids as $sub3k =>$sub3v){
                          $categoryidselect .= '<option value="'.$sub3v['id'].'" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sub3v['title'].'</option>';
                      }
                 }
         }
         $categoryselect = '<select style=\'float:left;\' onChange="javascript:document.getElementById(\'loading'.$favorites_id.'\').style.display=\'block\';self.location.href=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=xuanpin&act=caiji&favorites_id='.$favorites_id.'&formhash='.FORMHASH.'&categoryid=\'+this.value">'.$categoryidselect.'</select><span id=\'loading'.$favorites_id.'\' style=\'color:red;display:none;float:left;\'>&nbsp;&nbsp;&nbsp;&nbsp;<strong>'.plang('loading').'</strong></span>';

         return $categoryselect;
}

function bindcategoryselect($favorites_id) {
    $setting = C::t('common_setting')->fetch_all(array('jdaogou_xuanpin_bind'));
    $setting = (array)unserialize($setting['jdaogou_xuanpin_bind']);

    $categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid(0,1);
    $categoryidselect = '<option value="0">------'.plang('qingxuanze').'------</option>';
    $categoryidselect .= '<option value="0" '.(empty($setting[$favorites_id]) || $setting[$favorites_id]=='0'?'selected':'').'>------'.plang('bubangding').'------</option>';
    foreach($categoryids as $k =>$v){
        $categoryidselect .= '<option value="'.$v['id'].'" '.($setting[$favorites_id]==$v['id']?'selected':'').'>'.$v['title'].'</option>';
        $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($v['id'],1);
        foreach($subcategoryids as $subk =>$subv){
            $categoryidselect .= '<option value="'.$subv['id'].'" '.($setting[$favorites_id]==$subv['id']?'selected':'').'>&nbsp;&nbsp;&nbsp;&nbsp;'.$subv['title'].'</option>';

            $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($subv['id'],1);
            foreach($sub3categoryids as $sub3k =>$sub3v){
                $categoryidselect .= '<option value="'.$sub3v['id'].'" '.($setting[$favorites_id]==$sub3v['id']?'selected':'').'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sub3v['title'].'</option>';
            }
        }
    }
    $categoryselect = '<select style=\'float:left;\' onChange="javascript:document.getElementById(\'bindloading'.$favorites_id.'\').style.display=\'block\';self.location.href=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=xuanpin&act=bind&favorites_id='.$favorites_id.'&formhash='.FORMHASH.'&categoryid=\'+this.value">'.$categoryidselect.'</select><span id=\'bindloading'.$favorites_id.'\' style=\'color:red;display:none;float:left;\'>&nbsp;&nbsp;&nbsp;&nbsp;<strong>'.plang('bind_loading').'</strong></span>';

    return $categoryselect;
}

function plang($str) {
	return lang('plugin/jzsjiale_daogou', $str);
}
//From: Dism��taobao��com
?>