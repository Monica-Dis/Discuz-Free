<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jzsjiale_daogou_shangpin extends discuz_table
{
	public function __construct() {
		$this->_table = 'jzsjiale_daogou_shangpin';
		$this->_pk    = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}
	public function getone(){
		return DB::fetch_first('SELECT * FROM %t ORDER BY id DESC limit 0,1',array($this->_table));
		
	}
	
	public function get_by_id($id){
	    return DB::fetch_first('SELECT * FROM %t WHERE id = '.$id,array($this->_table));
	
	}
	
	public function getall(){
		return DB::fetch_all('SELECT * FROM %t ORDER BY id DESC',array($this->_table));
	
	}
	
	public function getallByIds($ids){
	    return DB::fetch_all('SELECT * FROM %t WHERE id in ('.$ids.')',array($this->_table));
	
	}
	
	public function getallsuiji($status = 1){
	    return DB::fetch_all('SELECT * FROM %t WHERE status = %d ORDER BY id DESC',array($this->_table,$status));
	
	}

    public function getallsuijibycategoryid($status = 1,$categoryid = 0){
        return DB::fetch_all('SELECT * FROM %t WHERE status = %d and categoryid = %d ORDER BY id DESC',array($this->_table,$status,$categoryid));

    }
	
	public function setallsuiji($status = 1){
	    return DB::update($this->_table,array('status' => $status));
	}
	
	public function settklnull(){
	    return DB::update($this->_table,array('tkl' => ''));
	}
	
	public function settklnull_by_categoryid($categoryid){
	    return DB::update($this->_table,array('tkl' => ''),'categoryid = '.$categoryid);
	
	}
	
	public function count_by_title($title,$status="") {
	    $where = " 1=1 ";
	    if(!empty($title)){
	        $where .=' and '.DB::field('title', '%'.$title.'%', 'like').' ';
	    }
	    if(!empty($status)){
	        $where .= " and status = ".$status.' ';
	    }
	    $count = (int) DB::result_first("SELECT count(*) FROM ".DB::table($this->_table).' WHERE '.$where);
		return $count;
	}
	
	public function count_by_categoryid($categoryid,$status="") {
	    $wherestatus = "";
	    if(!empty($status)){
	        $wherestatus = " and status = ".$status.' ';
	    }
	    $count = (int) DB::result_first("SELECT count(*) FROM ".DB::table($this->_table).' WHERE categoryid ='.$categoryid.$wherestatus);
	    return $count;
	}
	
	public function range_by_title($title = "",$start = 0, $limit = 0, $sort = '',$status="") {
	    $where = " 1=1 ";
	    if(!empty($title)){
	        
	        $where .=' and '.DB::field('title', '%'.$title.'%', 'like').' ';
	    }
	    if(!empty($status)){
	        $where .= " and status = ".$status.' ';
	    }
	    if($sort) {
	        $this->checkpk();
	    }
	    return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' WHERE '.$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
	
	public function delallsp(){
	    return DB::delete($this->_table,'id>0');
	
	}
	
	public function deletebycategoryid($categoryid){
	    return DB::delete($this->_table,'categoryid = '.$categoryid);
	
	}
	
	
	public function deletebycategoryidandfavoritesid($categoryid,$favoritesid){
	    return DB::delete($this->_table,'categoryid = '.$categoryid.' and favoritesid = '.$favoritesid);
	
	}
	public function deletebycategoryidandfavoritesidandnumiid($categoryid,$favoritesid,$numiid){
	    return DB::delete($this->_table,'categoryid = '.$categoryid.' and favoritesid = '.$favoritesid.' and numiid = '.$numiid);
	
	}
	
	public function deletebyflag($flagid){
	    return DB::delete($this->_table,'flag = '.$flagid);
	
	}
	
	public function range_by_categoryid($categoryid = "",$start = 0, $limit = 0, $sort = '',$status="") {
	    $wherestatus = "";
	    if(!empty($status)){
	        $wherestatus = " and status = ".$status.' ';
	    }
	    if($sort) {
	        $this->checkpk();
	    }
	    return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' WHERE categoryid = '.$categoryid.$wherestatus.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
	
	
	public function count_by_map($map,$status="") {
	    $where = " 1=1 ";
	    
    	foreach ($map as $mapkey => $mapvalue){
            if($mapkey == "title"){
                $where .=  ' and '.DB::field('title', '%'.$mapvalue.'%', 'like').' ';
            }else{
                $where .=  ' and '.$mapkey.' = '.$mapvalue.' ';
            }
            
        }
	    if(!empty($status)){
	        $where = ' and status = '.$status.' ';
	    }
	    $count = (int) DB::result_first("SELECT count(*) FROM ".DB::table($this->_table).' WHERE '.$where);
	    return $count;
	}
	
	//$map title,categoryid,flag
	public function range_by_map($map = array(),$start = 0, $limit = 0, $sort = '',$status="") {
	    $where = " 1=1 ";
	    
    	foreach ($map as $mapkey => $mapvalue){
            if($mapkey == "title"){
                $where .=  ' and '.DB::field('title', '%'.$mapvalue.'%', 'like').' ';
            }else{
                $where .=  ' and '.$mapkey.' = '.$mapvalue.' ';
            }
            
        }
	    if(!empty($status)){
	        $where = ' and status = '.$status.' ';
	    }
	    if($sort) {
	        $this->checkpk();
	    }
	    return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' WHERE '.$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
}
//From: dis'.'m.tao'.'bao.com
?>