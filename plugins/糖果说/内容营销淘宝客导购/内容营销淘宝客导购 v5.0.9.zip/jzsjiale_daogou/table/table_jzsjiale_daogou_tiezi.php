<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jzsjiale_daogou_tiezi extends discuz_table
{
	public function __construct() {
		$this->_table = 'jzsjiale_daogou_tiezi';
		$this->_pk    = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}
	public function getone(){
		return DB::fetch_first('SELECT * FROM %t ORDER BY id DESC limit 0,1',array($this->_table));
		
	}
	
	public function get_by_id($id){
	    return DB::fetch_first('SELECT * FROM %t WHERE id = '.$id,array($this->_table));
	
	}
	
	public function get_by_tid($tid){
	    return DB::fetch_first('SELECT * FROM %t WHERE tid = '.$tid.' ORDER BY id DESC',array($this->_table));
	
	}
	
	public function get_by_tidandcategoryid($tid,$tiezicategoryid){
	    return DB::fetch_first('SELECT * FROM %t WHERE tid = '.$tid.' and tiezicategoryid = '.$tiezicategoryid,array($this->_table));
	
	}
	
	public function getall($status="") {
	    $wherestatus = "";
	    if(!empty($status)){
	        $wherestatus = " WHERE status = ".$status.' ';
	    }
		return DB::fetch_all('SELECT * FROM %t '.$wherestatus.' ORDER BY sort ASC,dateline DESC,id DESC',array($this->_table));
	
	}
	
	
	public function count_by_title($title) {
	    $count = (int) DB::result_first("SELECT count(*) FROM ".DB::table($this->_table).' WHERE title LIKE \'%'.$title.'%\' ');
		return $count;
	}
	
	public function count_by_tiezicategoryid($tiezicategoryid) {
	    $count = (int) DB::result_first("SELECT count(*) FROM ".DB::table($this->_table).' WHERE tiezicategoryid ='.$tiezicategoryid);
	    return $count;
	}
	
	public function range_by_title($title = "",$start = 0, $limit = 0, $sort = '') {
	    if($sort) {
	        $this->checkpk();
	    }
	    return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' WHERE '.DB::field('title', '%'.$title.'%', 'like').($sort ? ' ORDER BY '.$sort : ' ORDER BY id DESC ').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
	
	public function delalltiezi(){
	    return DB::delete($this->_table,'id > 0');
	
	}
	
	public function deletebytiezicategoryid($tiezicategoryid){
	    return DB::delete($this->_table,'tiezicategoryid = '.$tiezicategoryid);
	
	}
	
	public function range_by_tiezicategoryid($tiezicategoryid = "",$start = 0, $limit = 0, $sort = '') {
	    if($sort) {
	        $this->checkpk();
	    }
	    return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' WHERE tiezicategoryid = '.$tiezicategoryid.' '.($sort ? ' ORDER BY '.$sort : ' ORDER BY id DESC ').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
	
	public function zhiding($id,$updatetime){
	    return DB::update($this->_table,array('sort' => 0,'dateline'=>$updatetime),'id = '.$id);
	
	}
	
	public function quxiaozhiding($id){
	    return DB::update($this->_table,array('sort' => 99999999),'id = '.$id);
	
	}
}
//From: dis'.'m.tao'.'bao.com
?>