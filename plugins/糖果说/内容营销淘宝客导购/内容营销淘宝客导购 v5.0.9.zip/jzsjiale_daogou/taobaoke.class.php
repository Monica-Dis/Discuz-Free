<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';

class plugin_jzsjiale_daogou
{
    var $count = 0;

    function gettaobaoke($message)
    {
    	$message = $message[0];
        $this->count ++;
        $id = 'tbk' . $this->count;
        
        $message = trim($message);
        $message = str_ireplace('&amp;', '&', $message);
        
        $message = substr($message, strlen('[jzsjiale_daogou]'), strlen($message) - strlen('[jzsjiale_daogou]') - strlen('[/jzsjiale_daogou]'));
        
        $tbkarray = explode(',=', $message);
        
        $tbk_title = $tbkarray[0];
        $tbk_imgurl = $tbkarray[1];
        
        $pattern = "/^[a-zA-z]+:\/\/[^\s]*[.]{1}(gif|jpg|png|bmp|jpeg)$/is";
        if ( !preg_match( $pattern, $tbk_imgurl ) )
        {
            $tbk_imgurl = "#";
        }
        
        $tbk_url = $tbkarray[2];
        
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        
        $pattern = "/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/is";
        if(!empty($_config['g_urlxieyi'])){
		    $pattern = "/^((".$_config['g_urlxieyi'].")?:\/\/)[^\s]+$/is";
		}
        if ( !preg_match( $pattern, $tbk_url ) )
        {
            $tbk_url = "#";
        }
        $tbk_yuanjia = $tbkarray[3];
        
        $isyuanjia = true;
        if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == ""){
            $isyuanjia = false;
        }
        
        $tbk_xianjia = $tbkarray[4];
        
        //20180912 add start
        $isxianjia = true;
        if($tbk_xianjia == "#" || $tbk_xianjia == 0 || $tbk_xianjia == ""){
            $isxianjia = false;
        }
        //20180912 add end
        
        $tbk_youhuiquanurl = $tbkarray[5];
        $pattern = "/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/is";
        if(!empty($_config['g_urlxieyi'])){
		    $pattern = "/^((".$_config['g_urlxieyi'].")?:\/\/)[^\s]+$/is";
		}
        if ( !preg_match( $pattern, $tbk_youhuiquanurl ) )
        {
            $tbk_youhuiquanurl = "#";
        }
        
        $tbk_fengge = $tbkarray[6];
        
        
        $tbk_youhuitips = $_config['g_youhuitips'];
    
        $isshowyhk = false;
        if(!empty($tbk_youhuiquanurl) && $tbk_youhuiquanurl != "#"){
            $isshowyhk = true;
        }
        
        $tbkstyle = $_config['g_style'];
        if(empty($tbkstyle)){
            $tbkstyle = "discuzcode";
        }
        
        if(!empty($tbk_fengge) && $tbk_fengge !="" && $tbk_fengge != "#"){  
            $tbkstyle = $tbk_fengge;
        }
        
        $g_isopenzhtglj = $_config['g_isopenzhtglj'];
        $numiid = $tbkarray[8];
        if($numiid == "#"){
            $numiid = '';
        }
        
        $tbk_goumai = $_config['g_goumai'];
        $tbk_youhuiquan = $_config['g_youhuiquan'];
        
        $isnofollow = true;
        $isnofollow = $_config['g_isnofollow'];

        if($_config['g_zjzrspneilian']){
            if(!empty($tbk_url) && $tbk_url != "#"){
                $tbk_url_data = base64_encode($tbk_url);
                $tbk_url_data = str_replace(array('+','/','='),array('-','_',''),$tbk_url_data);

                $tbk_url = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=zjzr&spurl='.$tbk_url_data;
            }
            if(!empty($tbk_youhuiquanurl) && $tbk_youhuiquanurl != "#"){
                $tbk_youhuiquanurl_data = base64_encode($tbk_youhuiquanurl);
                $tbk_youhuiquanurl_data = str_replace(array('+','/','='),array('-','_',''),$tbk_youhuiquanurl_data);

                $tbk_youhuiquanurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=zjzr&spurl='.$tbk_youhuiquanurl_data;
            }

        }


        //newyhq start

        $tbk_couponstartfee = $tbkarray[10];
        if($tbk_couponstartfee == "#"){
            $tbk_couponstartfee = '';
        }
        $tbk_couponamount = $tbkarray[11];
        if($tbk_couponamount == "#"){
            $tbk_couponamount = '';
        }
        $tbk_couponstarttime = $tbkarray[12];
        if($tbk_couponstarttime == "#"){
            $tbk_couponstarttime = '';
        }
        $tbk_couponendtime = $tbkarray[13];
        if($tbk_couponendtime == "#"){
            $tbk_couponendtime = '';
        }
        $tbk_platform = $tbkarray[17];
        if($tbk_platform == "#"){
            $tbk_platform = '';
        }
        $tbk_platform = (!empty($tbk_platform) && $tbk_platform != 'none')?$tbk_platform:'';
        $tbk_platform_img = !empty($tbk_platform)?'/source/plugin/jzsjiale_daogou/static/images/platform/'.$tbk_platform.'.png':'';

        $tbk_freeshipment = $tbkarray[18];
        if($tbk_freeshipment == "1"){
            $tbk_freeshipment = 1;
        }else{
            $tbk_freeshipment = 0;
        }

        $is_time_ok = false;
        if(!empty($tbk_couponstarttime) && !empty($tbk_couponendtime)){
            $time_now = time();
            $time_start = strtotime(date($tbk_couponstarttime));
            $time_end = strtotime(date($tbk_couponendtime)) + 86400 - 1;

            if($time_now >= $time_start && $time_now <= $time_end){
                $is_time_ok = true;
            }else{
                $is_time_ok = false;
                $isshowyhk = false;
            }
        }

        if($_config['g_pcyhqstyle'] != 'none' && $tbk_fengge == "#" && !empty($tbk_xianjia) && !empty($tbk_youhuiquanurl) && $tbk_youhuiquanurl != "#"
            && !empty($tbk_couponstartfee) && !empty($tbk_couponamount) && $is_time_ok){

            if($tbk_couponamount > 0){
                if($tbk_couponstartfee <= $tbk_xianjia){
                    $tbk_quanhoujia = (double)$tbk_xianjia - (double)$tbk_couponamount;
                }
            }

            $tbk_youxiaoqi = !empty($tbk_couponendtime)?(!empty($tbk_couponstarttime)?$tbk_couponstarttime.'&nbsp;&nbsp;-&nbsp;&nbsp;'.$tbk_couponendtime:$tbk_couponendtime):"";


            $tbkstyle = $_config['g_pcyhqstyle'];
            include template('jzsjiale_daogou:'.$tbkstyle);
            $return = str_replace(array("\r\n", "\r", "\n"), "", $return);
            return trim($return);
        }else{
            include template('jzsjiale_daogou:'.$tbkstyle);
            $return = str_replace(array("\r\n", "\r", "\n"), "", $return);
            return trim($return);
        }

    }
    
    function gettaobaokejianrong($message)
    {
        $message = $message[0];
        $this->count ++;
        $id = 'tbk' . $this->count;
    
        $message = trim($message);
        $message = str_ireplace('&amp;', '&', $message);
    
        $message = substr($message, strlen('[jzsjiale_taobaoke]'), strlen($message) - strlen('[jzsjiale_taobaoke]') - strlen('[/jzsjiale_taobaoke]'));
    
        $tbkarray = explode(',=', $message);
    
        $tbk_title = $tbkarray[0];
        $tbk_imgurl = $tbkarray[1];
    
        $pattern = "/^[a-zA-z]+:\/\/[^\s]*[.]{1}(gif|jpg|png|bmp|jpeg)$/is";
        if ( !preg_match( $pattern, $tbk_imgurl ) )
        {
            $tbk_imgurl = "#";
        }
    
        $tbk_url = $tbkarray[2];
    
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        
        $pattern = "/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/is";
        if(!empty($_config['g_urlxieyi'])){
		    $pattern = "/^((".$_config['g_urlxieyi'].")?:\/\/)[^\s]+$/is";
		}
        if ( !preg_match( $pattern, $tbk_url ) )
        {
            $tbk_url = "#";
        }
        $tbk_yuanjia = $tbkarray[3];
    
        $isyuanjia = true;
        if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == ""){
            $isyuanjia = false;
        }
    
        $tbk_xianjia = $tbkarray[4];
        
        //20180912 add start
        $isxianjia = true;
        if($tbk_xianjia == "#" || $tbk_xianjia == 0 || $tbk_xianjia == ""){
            $isxianjia = false;
        }
        //20180912 add end
    
        $tbk_youhuiquanurl = $tbkarray[5];
        $pattern = "/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+$/is";
        if(!empty($_config['g_urlxieyi'])){
		    $pattern = "/^((".$_config['g_urlxieyi'].")?:\/\/)[^\s]+$/is";
		}
        if ( !preg_match( $pattern, $tbk_youhuiquanurl ) )
        {
            $tbk_youhuiquanurl = "#";
        }
    
        $tbk_fengge = $tbkarray[6];
    
        
        $tbk_youhuitips = $_config['g_youhuitips'];
    
        $isshowyhk = false;
        if(!empty($tbk_youhuiquanurl) && $tbk_youhuiquanurl != "#"){
            $isshowyhk = true;
        }
    
        $tbkstyle = $_config['g_style'];
        if(empty($tbkstyle)){
            $tbkstyle = "discuzcode";
        }
    
        if(!empty($tbk_fengge) && $tbk_fengge !="" && $tbk_fengge != "#"){
            $tbkstyle = $tbk_fengge;
        }
    
    
         
    
        $tbk_goumai = $_config['g_goumai'];
        $tbk_youhuiquan = $_config['g_youhuiquan'];
    
        $isnofollow = true;
        $isnofollow = $_config['g_isnofollow'];
    
        include template('jzsjiale_daogou:'.$tbkstyle);
        $return = str_replace(array("\r\n", "\r", "\n"), "", $return);
        return trim($return);
    }
    
    function getspkshangpin($message)
    {
        $message = $message[0];
        $this->count ++;
        $id = 'tbk' . $this->count;
        
        $message = trim($message);
        $message = str_ireplace('&amp;', '&', $message);
        
        $message = substr($message, strlen('[jzsjiale_daogou_spk]'), strlen($message) - strlen('[jzsjiale_daogou_spk]') - strlen('[/jzsjiale_daogou_spk]'));
        $sbkarray = explode(',=', $message);
        
        $shangpinid = $sbkarray[0];
        
        $shangpinid = is_numeric($shangpinid)?$shangpinid:0;
        
        $shangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->get_by_id($shangpinid);
        
        if(empty($shangpin)){
            return;
        }
        
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    
    
        $tbk_title = $shangpin['title'];
        $tbk_imgurl = $shangpin['img'];
        $tbk_url = $shangpin['url'];
        $tbk_yuanjia = $shangpin['yuanjia'];
    
        $isyuanjia = true;
        if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == ""){
            $isyuanjia = false;
        }
    
    
        $tbk_xianjia = $shangpin['xianjia'];
        
        //20180912 add start
        $isxianjia = true;
        if($tbk_xianjia == "#" || $tbk_xianjia == 0 || $tbk_xianjia == ""){
            $isxianjia = false;
        }
        //20180912 add end
    
        $tbk_youhuiquanurl = $shangpin['youhuiquan'];
        $tbk_youhuitips = $_config['g_youhuitips'];
    
        $isshowyhk = false;
        if(!empty($shangpin['youhuiquan'])){
            $isshowyhk = true;
        }
    
        $tbkstyle = $_config['g_style'];
        if(empty($tbkstyle)){
            $tbkstyle = "discuzcode";
        }
    
        $g_isopenzhtglj = $_config['g_isopenzhtglj'];
        $numiid = $shangpin['numiid'];
        
        $tbk_goumai = $_config['g_goumai'];
        $tbk_youhuiquan = $_config['g_youhuiquan'];


        $isnofollow = true;
        $isnofollow = $_config['g_isnofollow'];
    
        
        if($_config['g_spneilian']){
            $tbk_url = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$shangpin['id'];
            $tbk_youhuiquanurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$shangpin['id'];
        }


        $tbk_platform = (!empty($shangpin['platform']) && $shangpin['platform'] != 'none')?$shangpin['platform']:'';
        $tbk_platform_img = !empty($tbk_platform)?'/source/plugin/jzsjiale_daogou/static/images/platform/'.$tbk_platform.'.png':'';

        $tbk_freeshipment = $shangpin['freeshipment'];
        if($tbk_freeshipment == "1"){
            $tbk_freeshipment = 1;
        }else{
            $tbk_freeshipment = 0;
        }

        //newyhq start

        $is_time_ok = false;
        if(!empty($shangpin['couponstarttime']) && !empty($shangpin['couponendtime'])){
            $time_now = time();
            $time_start = strtotime(date($shangpin['couponstarttime']));
            $time_end = strtotime(date($shangpin['couponendtime'])) + 86400 - 1;

            if($time_now >= $time_start && $time_now <= $time_end){
                $is_time_ok = true;
            }else{
                $is_time_ok = false;
                $isshowyhk = false;
            }
        }
        if($_config['g_pcyhqstyle'] != 'none' && !empty($tbk_xianjia) && !empty($shangpin['youhuiquan'])
            && !empty($shangpin['couponstartfee']) && !empty($shangpin['couponamount']) && $is_time_ok){

            $tbk_couponamount = $shangpin['couponamount'];
            if($tbk_couponamount > 0){
                if($shangpin['couponstartfee'] <= $shangpin['xianjia']){
                    $tbk_quanhoujia = (double)$shangpin['xianjia'] - (double)$shangpin['couponamount'];
                }
            }


            $tbk_youxiaoqi = !empty($shangpin['couponendtime'])?(!empty($shangpin['couponstarttime'])?$shangpin['couponstarttime'].'&nbsp;&nbsp;-&nbsp;&nbsp;'.$shangpin['couponendtime']:$shangpin['couponendtime']):"";



            $tbkstyle = $_config['g_pcyhqstyle'];
            include template('jzsjiale_daogou:'.$tbkstyle);
            $return = str_replace(array("\r\n", "\r", "\n"), "", $return);
            return trim($return);
        }else{
            include template('jzsjiale_daogou:'.$tbkstyle);
            $return = str_replace(array("\r\n", "\r", "\n"), "", $return);
            return trim($return);
        }

    }
    function getpost($message)
    {
        global $_G;
        $message = $message[0];
        $this->count ++;
        $id = 'tbk' . $this->count;
    
        $message = trim($message);
        $message = str_ireplace('&amp;', '&', $message);
    
        $message = substr($message, strlen('[jzsjiale_daogou_post]'), strlen($message) - strlen('[jzsjiale_daogou_post]') - strlen('[/jzsjiale_daogou_post]'));
        if ($_G['charset'] == "gbk") {
            $message = diconv($message,'GBK', 'UTF-8');
        }
        
        $content1 = html_entity_decode($message);
        $content = json_decode($content1,TRUE);
        $content_list = $content['content_list'];
     
        $postmessage = "";
        foreach ($content_list as $key => $value){
            if($content_list[$key]['type'] == 1){
                $postmessage .= '<img class="pic" src="'.$_G['siteurl'].'data/attachment/forum/'.$content_list[$key]['image_url'].'" style="height:auto;" title="'.$image_desc.'" alt="'.$image_desc.'"/>';
                if(!empty($content_list[$key]['image_desc'])){
                    $image_desc = diconv($content_list[$key]['image_desc'], 'UTF-8','GBK');
                    $postmessage .= '<p class="txt"><i class="article-icons article-icons-desc"></i><span>'.$image_desc.'</span></p>';
                }
            }elseif($content_list[$key]['type'] == 2){
                $text_content = diconv($content_list[$key]['text_content'], 'UTF-8','GBK');
                $postmessage .= '<p class="desc">'.$text_content.'</p>';
            }elseif($content_list[$key]['type'] == 3){
                $text_content = diconv($content_list[$key]['text_content'], 'UTF-8','GBK');
                $postmessage .= '<p class="h1title">'.$text_content.'</p>';
            }elseif($content_list[$key]['type'] == 5){
                $product_id = $content_list[$key]['product_id'];
                $postmessage .= '[jzsjiale_daogou_spk]'.$product_id.'[/jzsjiale_daogou_spk]';
            }elseif($content_list[$key]['type'] == 6){
                $text_content = diconv($content_list[$key]['text_content'], 'UTF-8','GBK');
                
                $houzhuiinfo=pathinfo($text_content);
                if(strpos($houzhuiinfo['extension'], 'mp4') !== false){
                    $postmessage .= '<video controls="controls" autoplay="autoplay" width="100%"><source src="'.$text_content.'" type="video/mp4"></video>';
                }elseif(strpos($houzhuiinfo['extension'], 'm3u8') !== false){
                    $postmessage .= '<video controls="controls" autoplay="autoplay" width="100%"><source src="'.$text_content.'" type="application/vnd.apple.mpegurl"></video>';
                    $postmessage .= '<span style="color:red;">'.plang('pcm3u8').'</span>';
                }                
                
            }
            
            
        }
        
        if ($_G['charset'] == "gbk") {
            
        }else{
            $postmessage = diconv($postmessage,'GBK', 'UTF-8');
        }
        
        return trim($postmessage);
    }
    
    function discuzcode($param)
    {
        global $_G;
 
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        
        if (! $_config['g_isopen']) {
            return;
        }
        
        if (strpos($_G['discuzcodemessage'], '[/jzsjiale_daogou]') === false && strpos($_G['discuzcodemessage'], '[/jzsjiale_daogou_spk]') === false && strpos($_G['discuzcodemessage'], '[/jzsjiale_daogou_post]') === false && strpos($_G['discuzcodemessage'], '[/jzsjiale_taobaoke]') === false) {
            return false;
        }

        //gaidong chaojihuodong start
        if($_G["thread"]["special"] != '127'){
            $_G['discuzcodemessage'] .= "<link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/tbkitem.css\" type=\"text/css\" />";

        }
        //gaidong chaojihuodong end

        if ($param['caller'] == 'discuzcode') {
            
            $_G['discuzcodemessage'] = preg_replace_callback('/\s?\[jzsjiale_daogou_post\](.*?)\[\/jzsjiale_daogou_post\]\s?/is', array(
                $this,
                'getpost'
            ), $_G['discuzcodemessage']);
            
            $_G['discuzcodemessage'] = preg_replace_callback('/\s?\[jzsjiale_daogou\](.*?)\[\/jzsjiale_daogou\]\s?/is', array(
		            $this,
		            'gettaobaoke'
		        ), $_G['discuzcodemessage']);
            
            $_G['discuzcodemessage'] = preg_replace_callback('/\s?\[jzsjiale_daogou_spk\](.*?)\[\/jzsjiale_daogou_spk\]\s?/is', array(
                $this,
                'getspkshangpin'
            ), $_G['discuzcodemessage']);
            
            
            $_G['discuzcodemessage'] = preg_replace_callback('/\s?\[jzsjiale_taobaoke\](.*?)\[\/jzsjiale_taobaoke\]\s?/is', array(
                $this,
                'gettaobaokejianrong'
            ), $_G['discuzcodemessage']);
        } else {
            $_G['discuzcodemessage'] = preg_replace_callback('/\s?\[jzsjiale_daogou_post\](.*?)\[\/jzsjiale_daogou_post\]\s?/is', '', $_G['discuzcodemessage']);
            $_G['discuzcodemessage'] = preg_replace_callback('/\s?\[jzsjiale_daogou\](.*?)\[\/jzsjiale_daogou\]\s?/is', '', $_G['discuzcodemessage']);
            $_G['discuzcodemessage'] = preg_replace_callback('/\s?\[jzsjiale_daogou_spk\](.*?)\[\/jzsjiale_daogou_spk\]\s?/is', '', $_G['discuzcodemessage']);
            $_G['discuzcodemessage'] = preg_replace_callback('/\s?\[jzsjiale_taobaoke\](.*?)\[\/jzsjiale_taobaoke\]\s?/is', '', $_G['discuzcodemessage']);
        }
    }

    public function global_header() {
        global $_G;
    
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $current_url = str_replace(array('index.php','&simpletype=yes','&simpletype=no','&mobile=yes','&mobile=no','&mobile=1','&mobile=2'),'',$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);

        /*
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_domain.php';
        if(empty($domain)){
            include DISCUZ_ROOT.'./data/sysdata/cache_domain.php';
        }

        if($_config['g_ishome'] && strpos($domain['defaultindex'],'forum.php?daogou')>-1 && strpos($current_url,'forum.php?daogou')!=false){
        */

        if($_config['g_ishome'] && ('http://'.$current_url == $_G['siteurl'] || 'https://'.$current_url == $_G['siteurl']) ){
            if($_G[jzsjiale_tpl_daogou][isopendg] && $_G[jzsjiale_tpl_daogou][weijingtaimokuai]){
                return dheader('Location: index.html');
            }elseif($_G[jzsjiale_tpl_daogou][isopendg] && !$_G[jzsjiale_tpl_daogou][weijingtaimokuai]){
                return dheader('Location: plugin.php?id=jzsjiale_daogou:daogou');
            }else{
                return dheader('Location: plugin.php?id=jzsjiale_daogou:daogou');
            }
            
        }
    
        if($_config['g_isopenzhtglj']){
            return $_config['g_taodianjincode'];
        }
        
    }
    
    
    public function common() {
        global $_G;
    
        $daogouoptions = "";
        
        if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_daogou.php')){
            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_daogou.php';
        
            $daogouoptions = $daogouoption;
        
        }else{
            $daogouoption = C::t('#jzsjiale_daogou#jzsjiale_daogou_daogou')->getall();
        
            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_daogou', getcachevars(array('daogouoption' => $daogouoption)));
        
            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_daogou.php';
            $daogouoptions = $daogouoption;
        
        }
        
        
        $dgoptions = array();
        foreach($daogouoptions as $dgdata){
            
            if($dgdata['key'] == 'headercode' || $dgdata['key'] == 'footercode' || $dgdata['key'] == 'text3'){
                $dgoptions[$dgdata['key']] = htmlspecialchars_decode($dgdata['value']);
            }else{
                $dgoptions[$dgdata['key']]=dhtmlspecialchars($dgdata['value']);
            }
            
        }
        
        if(empty($dgoptions['logoimgurl'])){
            $dgoptions['logoimgurl'] = $_G['siteurl'];
        }
        if(empty($dgoptions['footerlogoimgurl'])){
            $dgoptions['footerlogoimgurl'] = $_G['siteurl'];
        }
        if(!empty($dgoptions['diynav'])){
            $tmpdiynav = $dgoptions['diynav'];
            $tmpdiynavexp = explode(',',$tmpdiynav);
            $tmpdiynavarr = array();
            foreach($tmpdiynavexp as $tdne)
            {
                $tmpdiynavexp2 = explode('|',$tdne);
                $tmpdiynavarr[]=$tmpdiynavexp2;
            }
            $dgoptions['diynav'] = $tmpdiynavarr;
        }
        
        
        $_G[jzsjiale_tpl_daogou]=$dgoptions;
        
        $forumlinks = C::t('common_friendlink')->fetch_all_by_displayorder();
        $forumlinks = dhtmlspecialchars($forumlinks);
        
        $_G[jzsjiale_tpl_daogou][forumlinks]=$forumlinks;
        
        
        
        if($_G[jzsjiale_tpl_daogou][qiangzhinavindex] || $_G[jzsjiale_tpl_daogou][qiangzhinavfaxian] || $_G[jzsjiale_tpl_daogou][qiangzhinavhaowu] || $_G[jzsjiale_tpl_daogou][qiangzhinavsouquan] || $_G[jzsjiale_tpl_daogou][qiangzhinavxiewenzhang]){
            $mynav = array();
            $navtype0 = C::t('common_nav')->fetch_all_by_navtype(0);
            $navids = array();
            foreach ($navtype0 as $nav){
                $isok = false;
                if(!$nav['available'] && (strpos($nav['url'], 'plugin.php?id=jzsjiale_daogou:daogou') !== false 
                    || strpos($nav['url'], 'index.html') !== false) && $_G[jzsjiale_tpl_daogou][qiangzhinavindex]){
                    $isok = true;
                }   
                
                if(!$nav['available'] && (strpos($nav['url'], 'plugin.php?id=jzsjiale_daogou:faxian') !== false
                    || strpos($nav['url'], 'faxian.html') !== false) && $_G[jzsjiale_tpl_daogou][qiangzhinavfaxian]){
                    $isok = true;
                }
                
                if(!$nav['available'] && (strpos($nav['url'], 'plugin.php?id=jzsjiale_daogou:haowu') !== false
                    || strpos($nav['url'], 'haowu.html') !== false) && $_G[jzsjiale_tpl_daogou][qiangzhinavhaowu]){
                    $isok = true;
                }

                if(!$nav['available'] && (strpos($nav['url'], 'plugin.php?id=jzsjiale_daogou:souquan') !== false
                        || strpos($nav['url'], 'souquan.html') !== false) && $_G[jzsjiale_tpl_daogou][qiangzhinavsouquan]){
                    $isok = true;
                }
                
                if(!$nav['available'] && (strpos($nav['url'], 'plugin.php?id=jzsjiale_daogou:xiewenzhang') !== false
                    || strpos($nav['url'], 'xiewenzhang.html') !== false) && $_G[jzsjiale_tpl_daogou][qiangzhinavxiewenzhang]){
                    $isok = true;
                }
                
                    if($isok){
                        
                        
                        list($navid) = explode('.', basename($nav['url']));
                        if($nav['type'] || $navid == 'misc' || $nav['identifier'] == 6) {
                            if($nav['type'] == 4) {
                                $navid = 'P'.$nav['identifier'];
                            } elseif($nav['type'] == 5) {
                                $navid = 'F'.$nav['identifier'];
                            } else {
                                $navid = 'N'.substr(md5(($nav['url'] != '#' ? $nav['url'] : $nav['name'])), 0, 4);
                            }
                        }
                        $navid = 'mn_'.$navid;
                        if(in_array($navid, $navids)) {
                            $navid .= '_'.$nav['identifier'];
                        }
                        $navids[] = $navid;
                        $nav['navid'] = $navid;
                        
                        $nav['navname'] = $nav['name'];
                        $nav['filename'] = $nav['url'];
                        
                        $nav['displayorder'] = intval($nav['displayorder']);
                        $nav['available'] = 1;
                        
                        unset($nav['name']);
                        unset($nav['url']);
                       
                        $mynav[] = $nav;
                    }else{
                        continue;
                    }
                
            }
               
            foreach ($_G['setting']['navs'] as $nav){
          
                $navtmp['navname'] = $nav['navname'];
                $navtmp['filename'] = $nav['filename'];
                $navtmp['available'] = $nav['available'];
                
                $utils = new Utils();
                $thenavalldata = $utils->searchlikegetfirst($navtmp['filename'],'url',$navtype0);

                $navtmp['displayorder'] = intval($thenavalldata['displayorder']);
                $navtmp['navid'] = $nav['navid'];
                
                $mynav[] = $navtmp;
            }
       
            $utils = new Utils();
            $mynav = $utils->my_sort($mynav,'displayorder',SORT_ASC,SORT_NUMERIC);
       
            $_G[jzsjiale_tpl_daogou][settings][navs]=$mynav;
            
        }else{
            $_G[jzsjiale_tpl_daogou][settings][navs]=$_G['setting']['navs'];
        }
        
        
    }
}

class plugin_jzsjiale_daogou_forum extends plugin_jzsjiale_daogou
{
    var $cacheshangpin = "";

    //gaidong chaojihuodong start
    function viewthread_modaction(){
        global $_G;

        if($_G["thread"]["special"] == '127'){
            return "<link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/tbkitem.css\" type=\"text/css\" />";
        }
    }
    //gaidong chaojihuodong end

    function post_editorctrl_left()
    { 
        global $_G;
      
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $groupid = $_G['groupid'];
        $fid = $_G['fid'];
        
        if (! $_config['g_isopen']) {
            return;
        }
        
        $rukuok = 0;
        if($_config['g_isruku'] && in_array($groupid, (array) unserialize($_config['g_rukugroup']))){
            $rukuok = 1;
        }
        
        $tklcaijiok = 0;
        if($_config['g_isopentklcaiji'] && in_array($groupid, (array) unserialize($_config['g_tklcaijigroup']))){
            $tklcaijiok = 1;
        }
        
        $regexpstr = "https|http|ftp|rtsp|mms";
        if($_config['g_urlxieyi']){
            $regexpstr = $_config['g_urlxieyi'];
        }
        
        $taobtn = "";
        if (in_array($fid, (array) unserialize($_config['g_fids'])) && in_array($groupid, (array) unserialize($_config['g_groups']))) {
            $taobtn = "<script src=\"source/plugin/jzsjiale_daogou/static/js/addtaobaoke.js\" type=\"text/javascript\"></script><link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/btn_tao.css\" type=\"text/css\" /><a id=\"btn_taobaoke\" title=\"" . $_config['g_btntip'] . "\" onClick=\"addtaobaoke('jzsjiale_daogou','" . $_config['g_onlymoren'] . "','".$rukuok."','".$tklcaijiok."','".$regexpstr."','".$_G['siteurl']."','".$_config['g_isopenmiaoshu']."')\" href='javascript:void(0);' >" . $_config['g_btnname'] . "</a>";     
        }
        
        $shangbtn = "";
        if (in_array($fid, (array) unserialize($_config['g_spkfids'])) && in_array($groupid, (array) unserialize($_config['g_spkgroups']))) {
            $shangbtn = "<script src=\"source/plugin/jzsjiale_daogou/static/js/shangpinku.js\" type=\"text/javascript\"></script><link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/btn_shang.css\" type=\"text/css\" /><a id=\"btn_taobaokeshang\" title=\"" . $_config['g_btnshangtip'] . "\" onClick=\"shangpinku('jzsjiale_daogou_shang')\" href='javascript:void(0);' >" . $_config['g_btnshangname'] . "</a>";     
        }
        
        return $taobtn.$shangbtn;
    }
    
    function viewthread_replacex_output()
    {
        global $_G, $postlist,$thread;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        
        if (! $_config['g_isopen']) {
            return;
        }

        if ($_config['g_autotuijian']) {
            if ($_G[jzsjiale_tpl_daogou][autotuijian]) {
                $autotuijianlll = intval($_G[jzsjiale_tpl_daogou][autotuijianlll]);
                if($thread['views'] >= $autotuijianlll){
                    $yanzhengtuijian = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->get_by_tidandcategoryid($thread['tid'],$_G[jzsjiale_tpl_daogou][autotuijian]);
                    if(empty($yanzhengtuijian)){
                        DB::insert('jzsjiale_daogou_tiezi', array(
                            'dateline' => TIMESTAMP,
                            'title' => $thread['subject'],
                            'tid' => $thread['tid'],
                            'tiezicategoryid' => $_G[jzsjiale_tpl_daogou][autotuijian],
                            'uid' => 1,
                            'status' => 1,
                            'sort' => 1
                        ));
                        $daogoutiezi = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->getall();

                        require_once libfile('function/cache');
                        writetocache('jzsjiale_daogou_tiezi', getcachevars(array('daogoutiezi' => $daogoutiezi)));
                    }
                }
            }
        }



        if (! $_config['g_issuiji']) {
        	
            return;
        }
        
        if (! $_config['g_yxfids']) {
            return;
        }
        if (! $_config['g_yxgroups']) {
            return;
        }
        

        $pid = $_G['forum_firstpid'];
        if (empty($pid)) {
            return;
        }
        
        $tid = $_GET['tid'];
        if (empty($tid)) {
            return;
        }
        
        $fid = $_G['fid'];
        if (empty($fid)) {
            return;
        }
        
        $groupid = $_G['groupid'];
        if (empty($groupid)) {
            return;
        }
        
        
        
        $uid = $_G['uid'];
     
        $basescript = $_G['basescript'];
        $curm = CURMODULE;
             
        $suijigeshu = 1;
        if (! $_config['g_suijigeshu']) {
            $suijigeshu = 1;
        }else{
            $suijigeshu = $_config['g_suijigeshu'];
        }
        
        //start
        if ($basescript == "forum") {
            
            
            if (!empty($_config['g_yunxuuid'])) {
                $yunxuuids = array();
                $yunxuuids = explode(',',trim($_config['g_yunxuuid']));
            
                if(!in_array($uid,$yunxuuids)){
                    return;
                }
            }else{
                $mianuids = array();
                
                if (!empty($_config['g_mianuid'])) {
                    $mianuids = explode(',',trim($_config['g_mianuid']));
                
                    if(in_array($uid,$mianuids)){
                        return;
                    }
                }
            }
            
            
            if (!empty($_config['g_yunxutid'])) {
                $yunxutids = array();
                $yunxutids = explode(',',trim($_config['g_yunxutid']));
            
                if(!in_array($tid,$yunxutids)){
                    return;
                }
            }else{
                $miantids = array();
                
                if (!empty($_config['g_miantid'])) {
                    $miantids = explode(',',trim($_config['g_miantid']));
                
                    if(in_array($tid,$miantids)){
                        return;
                    }
                }
            }
            
          
            if (in_array($fid,(array)unserialize($_config['g_yxfids'])) && in_array ( $groupid, (array)unserialize($_config['g_yxgroups']) )){
         
                
                //20161222 start
                $ok_suijicategory = "";
                //cache start
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                
                    $ok_suijicategory = $tbkcategory;
                
                }else{
                    $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
                
                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));
                
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                    $ok_suijicategory = $tbkcategory;
                
                }
                //cache end
                $suijicategorylist = array();
                foreach ($ok_suijicategory as $suijidata){
                    if(in_array($fid,json_decode($suijidata['fids']))){
                        $suijicategorylist[] = $suijidata['id'];
                    }
                }
                
                 
                $utils = new Utils();
                //cache start
                /*
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php';
                    
                    $allokshangpin = array();
                    foreach ($suijicategorylist as $sjdata){
                        $okshangpin = $utils->search($sjdata,'categoryid',$tbkshangpin);
                        if(!empty($okshangpin) && $okshangpin != null){
                            $allokshangpin = array_merge($allokshangpin, $okshangpin);
                        }
                        
                    }
                    
                    $this->cacheshangpin = $allokshangpin;
                
                }else{
                    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();
    
                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
                
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php';
                    
                    $allokshangpin = array();
                    foreach ($suijicategorylist as $sjdata){
                        $okshangpin = $utils->search($sjdata,'categoryid',$tbkshangpin);
                        if(!empty($okshangpin) && $okshangpin != null){
                            $allokshangpin = array_merge($allokshangpin, $okshangpin);
                        }
                        
                    }
                    
                    $this->cacheshangpin = $allokshangpin;
                }
                */
                //20190329 add

                $allokshangpin = array();
                foreach ($suijicategorylist as $sjdata){
                    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php')){
                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                        $tbkshangpin = ${'tbkshangpin_'.$sjdata};

                    }else{
                        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $sjdata);

                        require_once libfile('function/cache');
                        writetocache('jzsjiale_daogou_shangpin_'.$sjdata, getcachevars(array('tbkshangpin_'.$sjdata => $shangpin_cache_tmp)));

                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                        $tbkshangpin = ${'tbkshangpin_'.$sjdata};

                    }

                    if(!empty($tbkshangpin) && $tbkshangpin != null){
                        $allokshangpin = array_merge($allokshangpin, $tbkshangpin);
                    }
                    $this->cacheshangpin = $allokshangpin;
                }


                //cache end
                //20161222 over
                
                $spcount = count($this->cacheshangpin);

                if(empty($this->cacheshangpin) || $spcount <= 0){
                    return;
                }
                
                if($spcount <= $suijigeshu){
                    $suijigeshu = $spcount;
                }
                
                
                //css start
                
                $cssstr = "<link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/e.css\" type=\"text/css\" /><link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/tbkitem.css\" type=\"text/css\" />";
                $pos = strpos($postlist[$pid]['message'], $cssstr);
                
                if($pos === false){
                    $postlist[$pid]['message'] = $cssstr.'<br/>'.$postlist[$pid]['message']  ;
                    
                    if($_G["thread"]["freemessage"]){
                        $_G["thread"]["freemessage"] = $cssstr.'<br/>'.$_G["thread"]["freemessage"];
                    }
                }
                //css end
              
                if ($_config['g_ding']) {
                   
                    $spdingid = array_rand($this->cacheshangpin,$suijigeshu);
                    
                    
                    $spdingformat = "";
                    
                    if($suijigeshu == 1){
                        $spding = $this->cacheshangpin[$spdingid];
                        $spdingformat .= $this->getshangpin($spding);
                    }else{
                        $yhqnullclass = "bingpaisuijiding";
                        $haveyhq = false;
                        for($i=0;$i<$suijigeshu;$i++){
                            $spding = $this->cacheshangpin[$spdingid[$i]];
                            if(!empty($spding['youhuiquan'])){
                                $haveyhq = true;
                            }
                            $spdingformat .= $this->getshangpin($spding,$yhqnullclass);
                        }
                    }
                    if(!$haveyhq){
                        $spdingformat .= '<style type="text/css">.bingpaisuijiding{height:0px!important;line-height:0px!important;}</style>';
                    }
                    
                    
                    $postlist[$pid]['message'] = '<div class="e-row">'.$spdingformat.'</div><br/>'.$postlist[$pid]['message']  ;
                    
                    if($_G["thread"]["freemessage"]){
                        $_G["thread"]["freemessage"] = '<div class="e-row">'.$spdingformat.'</div><br/>'.$_G["thread"]["freemessage"];
                    }
                }
                
                
                if ($_config['g_wei']) {
                    
                    $spweiid = array_rand($this->cacheshangpin,$suijigeshu);
              
                    $spweiformat = "";
                    
                    if($suijigeshu == 1){
                        $spwei = $this->cacheshangpin[$spweiid];
                        $spweiformat .= $this->getshangpin($spwei);
                    }else{
                        $yhqnullclass = "bingpaisuijiwei";
                        $haveyhq = false;
                        for($i=0;$i<$suijigeshu;$i++){
                            $spwei = $this->cacheshangpin[$spweiid[$i]];
                            if(!empty($spwei['youhuiquan'])){
                                $haveyhq = true;
                            }
                            $spweiformat .= $this->getshangpin($spwei,$yhqnullclass);
                        } 
                    }
                    if(!$haveyhq){
                        $spweiformat .= '<style type="text/css">.bingpaisuijiwei{height:0px!important;line-height:0px!important;}</style>';
                    }
                    
                
                
                    $postlist[$pid]['message'] = $postlist[$pid]['message'] . '<br/><div class="e-row">'. $spweiformat .'</div>';
                    
                    if($_G["thread"]["freemessage"]){
                        $_G["thread"]["freemessage"] = $_G["thread"]["freemessage"] . '<br/><div class="e-row">'. $spweiformat .'</div>';
                    }
                }
                
            }else{
                return;
            }
            
        }
        //end
    }

    function getshangpin($shangpin,$yhqnullclass="")
    {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];

        $id = $shangpin['id'];
        $tbk_title = $shangpin['title'];
        $tbk_imgurl = $shangpin['img'];
        $tbk_url = $shangpin['url'];
        $tbk_yuanjia = $shangpin['yuanjia'];
        
        $isyuanjia = true;
        if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == ""){
            $isyuanjia = false;
        }
        
        
        $tbk_xianjia = $shangpin['xianjia'];
        
        //20180912 add start
        $isxianjia = true;
        if($tbk_xianjia == "#" || $tbk_xianjia == 0 || $tbk_xianjia == ""){
            $isxianjia = false;
        }
        //20180912 add end
        
        $tbk_youhuiquanurl = $shangpin['youhuiquan'];
        $tbk_youhuitips = $_config['g_youhuitips'];
    
        $isshowyhk = false;
        if(!empty($shangpin['youhuiquan'])){
            $isshowyhk = true;
        }
        
        $tbkstyle = $_config['g_pcsuijistyle'];
        if(empty($tbkstyle)){
            $tbkstyle = "discuzcode";
        }
        
        $g_isopenzhtglj = $_config['g_isopenzhtglj'];
        $numiid = $shangpin['numiid'];
        
        $tbk_goumai = $_config['g_goumai'];
        $tbk_youhuiquan = $_config['g_youhuiquan'];
        
        $isnofollow = true;
        $isnofollow = $_config['g_isnofollow'];
        
        if($_config['g_spneilian']){
            $tbk_url = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$shangpin['id'];
            $tbk_youhuiquanurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$shangpin['id'];
        }


        if($tbkstyle == "fangyhq"){
            $tbk_platform = (!empty($shangpin['platform']) && $shangpin['platform'] != 'none')?$shangpin['platform']:'';
            $tbk_platform_img = !empty($tbk_platform)?'/source/plugin/jzsjiale_daogou/static/images/platform/'.$tbk_platform.'.png':'';

            $tbk_freeshipment = $shangpin['freeshipment'];
            if($tbk_freeshipment == "1"){
                $tbk_freeshipment = 1;
            }else{
                $tbk_freeshipment = 0;
            }

            //newyhq start

            $is_time_ok = false;
            if(!empty($shangpin['couponstarttime']) && !empty($shangpin['couponendtime'])){
                $time_now = time();
                $time_start = strtotime(date($shangpin['couponstarttime']));
                $time_end = strtotime(date($shangpin['couponendtime'])) + 86400 - 1;

                if($time_now >= $time_start && $time_now <= $time_end){
                    $is_time_ok = true;
                }else{
                    $is_time_ok = false;
                    $isshowyhk = false;
                }
            }
            if($_config['g_pcyhqstyle'] != 'none' && !empty($tbk_xianjia) && !empty($shangpin['youhuiquan'])
                && !empty($shangpin['couponstartfee']) && !empty($shangpin['couponamount']) && $is_time_ok){

                $tbk_couponamount = $shangpin['couponamount'];
                if($tbk_couponamount > 0){
                    if($shangpin['couponstartfee'] <= $shangpin['xianjia']){
                        $tbk_quanhoujia = (double)$shangpin['xianjia'] - (double)$shangpin['couponamount'];
                    }
                }


                $tbk_youxiaoqi = !empty($shangpin['couponendtime'])?(!empty($shangpin['couponstarttime'])?$shangpin['couponstarttime'].'&nbsp;&nbsp;-&nbsp;&nbsp;'.$shangpin['couponendtime']:$shangpin['couponendtime']):"";



                $tbkstyle = $_config['g_pcyhqstyle'];
                include template('jzsjiale_daogou:'.$tbkstyle);
                return trim($return);
            }else{
                include template('jzsjiale_daogou:'.$tbkstyle);
                return trim($return);
            }
        }else{
            include template('jzsjiale_daogou:'.$tbkstyle);
            return trim($return);
        }

    }
    
    
    function viewthread_postheader(){
    
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
 
        if (! $_config['g_isopen']) {
            return;
        }
        
        if (! $_config['g_tuijianpc']) {
            return;
        }
        
        $uid = $_G['uid'];
        
        if (empty($uid)) {
            return;
        }

        $fid = $_G['fid'];
        if (empty($fid)) {
            return;
        }
        
        $groupid = $_G['groupid'];
        if (empty($groupid)) {
            return;
        }
        
        if (in_array($fid,(array)unserialize($_config['g_tuijianpcforum'])) && in_array ( $groupid, (array)unserialize($_config['g_tuijianpcgroup']) ))
        {
            $posttextbtn['0']='&nbsp;&nbsp;<a href="#" onclick="showWindow(\'jzsjiale_daogou_mods\', \'plugin.php?id=jzsjiale_daogou:tuijian&tid='.$_G['tid'].'&fid='.$_G['fid'].'\', \'get\', -1);return false;" style="color:red;"><b>'.$_config['g_tuijianbtntitle'].'</b></a>&nbsp;&nbsp;&nbsp;';
            
            return $posttextbtn;
        }else{
            return "";
        }
    }
    
    function viewthread_postfooter(){
    
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    
        if (! $_config['g_isopen']) {
            return;
        }
        
        if (! $_config['g_tuijianpc']) {
            return;
        }
        
        $uid = $_G['uid'];
        
        if (empty($uid)) {
            return;
        }

        $fid = $_G['fid'];
        if (empty($fid)) {
            return;
        }
        
        $groupid = $_G['groupid'];
        if (empty($groupid)) {
            return;
        }
        
        if (in_array($fid,(array)unserialize($_config['g_tuijianpcforum'])) && in_array ( $groupid, (array)unserialize($_config['g_tuijianpcgroup']) ))
        {
            $posttextbtn['0']='&nbsp;&nbsp;<a href="#" onclick="showWindow(\'jzsjiale_daogou_mods\', \'plugin.php?id=jzsjiale_daogou:tuijian&tid='.$_G['tid'].'&fid='.$_G['fid'].'\', \'get\', -1);return false;" style="color:red;"><b>'.$_config['g_tuijianbtntitle'].'</b></a>&nbsp;&nbsp;&nbsp;';
           
            return $posttextbtn;
        }else{
            return "";
        }
        
    }
    
    function plang($str)
    {
        return lang('plugin/jzsjiale_daogou', $str);
    }
}



class plugin_jzsjiale_daogou_portal extends plugin_jzsjiale_daogou
{
    var $cacheshangpin = "";


    function view_article_content()
    {
        global $_G, $postlist;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];

        $contentstr = "";
        
        if (! $_config['g_isopen']) {
            return;
        }
        if (! $_config['g_issuiji']) {
             
            return;
        }
      
        if (! $_config['g_wenzhangwei']) {
            return;
        }
       
        

        $aid = $_GET['aid'];
        if (empty($aid)) {
            return;
        }
        
        $catid = $_GET['catid'];
        if (empty($catid)) {
            $portalresult = C::t('portal_article_title')->fetch($aid);
            $catid = $portalresult['catid'];
            if(empty($catid)) {
                return;
            }
        }
        
        
        $uid = $_G['uid'];
         
        $basescript = $_G['basescript'];
        $curm = CURMODULE;
        
        $suijigeshu = 1;
        if (! $_config['g_suijigeshu']) {
            $suijigeshu = 1;
        }else{
            $suijigeshu = $_config['g_suijigeshu'];
        }
       
        //start
        if ($basescript == "portal") {

            if (!empty($_config['g_yunxuuid'])) {
                $yunxuuids = array();
                $yunxuuids = explode(',',trim($_config['g_yunxuuid']));
            
                if(!in_array($uid,$yunxuuids)){
                    return;
                }
            }else{
                $mianuids = array();
            
                if (!empty($_config['g_mianuid'])) {
                    $mianuids = explode(',',trim($_config['g_mianuid']));
            
                    if(in_array($uid,$mianuids)){
                        return;
                    }
                }
            }
            
            
            if (!empty($_config['g_yunxuaid'])) {
                $yunxuaids = array();
                $yunxuaids = explode(',',trim($_config['g_yunxuaid']));
            
                if(!in_array($aid,$yunxuaids)){
                    return;
                }
            }else{
                $mianaids = array();
    
                if (!empty($_config['g_mianaid'])) {
                    $mianaids = explode(',',trim($_config['g_mianaid']));
    
                    if(in_array($aid,$mianaids)){
                        return;
                    }
                }
            }

            

            if ($_config['g_wenzhangwei']){
                 
                //20161222 start
                $ok_suijicategory = "";
                //cache start
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                
                    $ok_suijicategory = $tbkcategory;
                
                }else{
                    $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();
                
                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));
                
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                    $ok_suijicategory = $tbkcategory;
                
                }
                //cache end
                $suijicategorylist = array();
                foreach ($ok_suijicategory as $suijidata){
                    if(in_array($catid,json_decode($suijidata['catids']))){
                        $suijicategorylist[] = $suijidata['id'];
                    }
                }
                
                 
                $utils = new Utils();
                //cache start
                /*
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php';
                
                    $allokshangpin = array();
                    foreach ($suijicategorylist as $sjdata){
                        $okshangpin = $utils->search($sjdata,'categoryid',$tbkshangpin);
                        if(!empty($okshangpin) && $okshangpin != null){
                            $allokshangpin = array_merge($allokshangpin, $okshangpin);
                        }
                
                    }
                
                    $this->cacheshangpin = $allokshangpin;
                
                }else{
                    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();
                
                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
                
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php';
                
                    $allokshangpin = array();
                    foreach ($suijicategorylist as $sjdata){
                        $okshangpin = $utils->search($sjdata,'categoryid',$tbkshangpin);
                        if(!empty($okshangpin) && $okshangpin != null){
                            $allokshangpin = array_merge($allokshangpin, $okshangpin);
                        }
                
                    }
                
                    $this->cacheshangpin = $allokshangpin;
                }
                 */
                //20190329 add

                $allokshangpin = array();
                foreach ($suijicategorylist as $sjdata){
                    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php')){
                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                        $tbkshangpin = ${'tbkshangpin_'.$sjdata};

                    }else{
                        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $sjdata);

                        require_once libfile('function/cache');
                        writetocache('jzsjiale_daogou_shangpin_'.$sjdata, getcachevars(array('tbkshangpin_'.$sjdata => $shangpin_cache_tmp)));

                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                        $tbkshangpin = ${'tbkshangpin_'.$sjdata};

                    }

                    if(!empty($tbkshangpin) && $tbkshangpin != null){
                        $allokshangpin = array_merge($allokshangpin, $tbkshangpin);
                    }
                    $this->cacheshangpin = $allokshangpin;
                }
                //cache end
                //20161222 over

                $spcount = count($this->cacheshangpin);

                if(empty($this->cacheshangpin) || $spcount <= 0){
                    return;
                }
                
                if($spcount <= $suijigeshu){
                    $suijigeshu = $spcount;
                }

                //css start

                $cssstr = "<link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/e.css\" type=\"text/css\" /><link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/tbkitem.css\" type=\"text/css\" />";
                
                $contentstr .= $cssstr.'<br/>';
              
                //css end

                if ($_config['g_wenzhangwei']) {

                    $spweiid = array_rand($this->cacheshangpin,$suijigeshu);
       
                    $spweiformat = "";
                    
                    if($suijigeshu == 1){
                        $spwei = $this->cacheshangpin[$spweiid];
                        $spweiformat .= $this->getshangpin($spwei);
                    }else{
                        $yhqnullclass = "bingpaisuijiwei";
                        $haveyhq = false;
                        for($i=0;$i<$suijigeshu;$i++){
                            $spwei = $this->cacheshangpin[$spweiid[$i]];
                            if(!empty($spwei['youhuiquan'])){
                                $haveyhq = true;
                            }
                            $spweiformat .= $this->getshangpin($spwei,$yhqnullclass);
                        }
                    }
                    if(!$haveyhq){
                        $spweiformat .= '<style type="text/css">.bingpaisuijiwei{height:0px!important;line-height:0px!important;}</style>';
                    }
                    
                    
                    $contentstr.= '<div class="e-row">'. $spweiformat .'</div>';
                }

                return "<br/>".$contentstr."<br/>";
            }else{
                return;
            }

        }
        //end
    }

    function getshangpin($shangpin,$yhqnullclass="")
    {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];

        $id = $shangpin['id'];
        $tbk_title = $shangpin['title'];
        $tbk_imgurl = $shangpin['img'];
        $tbk_url = $shangpin['url'];
        $tbk_yuanjia = $shangpin['yuanjia'];

        $isyuanjia = true;
        if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == ""){
            $isyuanjia = false;
        }


        $tbk_xianjia = $shangpin['xianjia'];
        
        //20180912 add start
        $isxianjia = true;
        if($tbk_xianjia == "#" || $tbk_xianjia == 0 || $tbk_xianjia == ""){
            $isxianjia = false;
        }
        //20180912 add end

        $tbk_youhuiquanurl = $shangpin['youhuiquan'];
        $tbk_youhuitips = $_config['g_youhuitips'];

        $isshowyhk = false;
        if(!empty($shangpin['youhuiquan'])){
            $isshowyhk = true;
        }

        $tbkstyle = $_config['g_pcsuijistyle'];
        if(empty($tbkstyle)){
            $tbkstyle = "discuzcode";
        }
        
        $g_isopenzhtglj = $_config['g_isopenzhtglj'];
        $numiid = $shangpin['numiid'];
        
        $tbk_goumai = $_config['g_goumai'];
        $tbk_youhuiquan = $_config['g_youhuiquan'];
        
        $isnofollow = true;
        $isnofollow = $_config['g_isnofollow'];
        
        if($_config['g_spneilian']){
            $tbk_url = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$shangpin['id'];
            $tbk_youhuiquanurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$shangpin['id'];
        }

        if($tbkstyle == "fangyhq"){
            $tbk_platform = (!empty($shangpin['platform']) && $shangpin['platform'] != 'none')?$shangpin['platform']:'';
            $tbk_platform_img = !empty($tbk_platform)?'/source/plugin/jzsjiale_daogou/static/images/platform/'.$tbk_platform.'.png':'';

            $tbk_freeshipment = $shangpin['freeshipment'];
            if($tbk_freeshipment == "1"){
                $tbk_freeshipment = 1;
            }else{
                $tbk_freeshipment = 0;
            }

            //newyhq start

            $is_time_ok = false;
            if(!empty($shangpin['couponstarttime']) && !empty($shangpin['couponendtime'])){
                $time_now = time();
                $time_start = strtotime(date($shangpin['couponstarttime']));
                $time_end = strtotime(date($shangpin['couponendtime'])) + 86400 - 1;

                if($time_now >= $time_start && $time_now <= $time_end){
                    $is_time_ok = true;
                }else{
                    $is_time_ok = false;
                    $isshowyhk = false;
                }
            }
            if($_config['g_pcyhqstyle'] != 'none' && !empty($tbk_xianjia) && !empty($shangpin['youhuiquan'])
                && !empty($shangpin['couponstartfee']) && !empty($shangpin['couponamount']) && $is_time_ok){

                $tbk_couponamount = $shangpin['couponamount'];
                if($tbk_couponamount > 0){
                    if($shangpin['couponstartfee'] <= $shangpin['xianjia']){
                        $tbk_quanhoujia = (double)$shangpin['xianjia'] - (double)$shangpin['couponamount'];
                    }
                }


                $tbk_youxiaoqi = !empty($shangpin['couponendtime'])?(!empty($shangpin['couponstarttime'])?$shangpin['couponstarttime'].'&nbsp;&nbsp;-&nbsp;&nbsp;'.$shangpin['couponendtime']:$shangpin['couponendtime']):"";



                $tbkstyle = $_config['g_pcyhqstyle'];
                include template('jzsjiale_daogou:'.$tbkstyle);
                return trim($return);
            }else{
                include template('jzsjiale_daogou:'.$tbkstyle);
                return trim($return);
            }
        }else{
            include template('jzsjiale_daogou:'.$tbkstyle);
            return trim($return);
        }
    }

    function plang($str)
    {
        return lang('plugin/jzsjiale_daogou', $str);
    }
}





class plugin_jzsjiale_daogou_group extends plugin_jzsjiale_daogou
{
    var $cacheshangpin = "";

    function post_editorctrl_left()
    {
        global $_G;

        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $groupid = $_G['groupid'];
       
        if (! $_config['g_isopen']) {
            return;
        }

        $rukuok = 0;
        if($_config['g_isruku'] && in_array($groupid, (array) unserialize($_config['g_rukugroup']))){
            $rukuok = 1;
        }

        $taobtn = "";
        if ($_config['g_isopenqunzushougong'] && in_array($groupid, (array) unserialize($_config['g_groups']))) {
            $taobtn = "<script src=\"source/plugin/jzsjiale_daogou/static/js/addtaobaoke.js\" type=\"text/javascript\"></script><link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/btn_tao.css\" type=\"text/css\" /><a id=\"btn_taobaoke\" title=\"" . $_config['g_btntip'] . "\" onClick=\"addtaobaoke('jzsjiale_daogou','" . $_config['g_onlymoren'] . "','".$rukuok."')\" href='javascript:void(0);' >" . $_config['g_btnname'] . "</a>";
        }

        $shangbtn = "";
        if ($_config['g_isopenspk'] && in_array($groupid, (array) unserialize($_config['g_spkgroups']))) {
            $shangbtn = "<script src=\"source/plugin/jzsjiale_daogou/static/js/shangpinku.js\" type=\"text/javascript\"></script><link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/btn_shang.css\" type=\"text/css\" /><a id=\"btn_taobaokeshang\" title=\"" . $_config['g_btnshangtip'] . "\" onClick=\"shangpinku('jzsjiale_daogou_shang')\" href='javascript:void(0);' >" . $_config['g_btnshangname'] . "</a>";
        }

        return $taobtn.$shangbtn;
    }

    function viewthread_replacex_output()
    {
        global $_G, $postlist,$thread;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];

        if (! $_config['g_isopen']) {
            return;
        }

        if ($_config['g_autotuijian']) {
            if ($_G[jzsjiale_tpl_daogou][autotuijian]) {
                $autotuijianlll = intval($_G[jzsjiale_tpl_daogou][autotuijianlll]);
                if($thread['views'] >= $autotuijianlll){
                    $yanzhengtuijian = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->get_by_tidandcategoryid($thread['tid'],$_G[jzsjiale_tpl_daogou][autotuijian]);
                    if(empty($yanzhengtuijian)){
                        DB::insert('jzsjiale_daogou_tiezi', array(
                            'dateline' => TIMESTAMP,
                            'title' => $thread['subject'],
                            'tid' => $thread['tid'],
                            'tiezicategoryid' => $_G[jzsjiale_tpl_daogou][autotuijian],
                            'uid' => 1,
                            'status' => 1,
                            'sort' => 1
                        ));
                        $daogoutiezi = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->getall();

                        require_once libfile('function/cache');
                        writetocache('jzsjiale_daogou_tiezi', getcachevars(array('daogoutiezi' => $daogoutiezi)));
                    }
                }
            }
        }

        if (! $_config['g_issuiji']) {
             
            return;
        }


        if (! $_config['g_yxgroups']) {
            return;
        }


        $pid = $_G['forum_firstpid'];
        if (empty($pid)) {
            return;
        }

        $tid = $_GET['tid'];
        if (empty($tid)) {
            return;
        }

        $fid = $_G['fid'];
        if (empty($fid)) {
            return;
        }

        $groupid = $_G['groupid'];
        if (empty($groupid)) {
            return;
        }



        $uid = $_G['uid'];
         
        $basescript = $_G['basescript'];
        $curm = CURMODULE;
         
        $suijigeshu = 1;
        if (! $_config['g_suijigeshu']) {
            $suijigeshu = 1;
        }else{
            $suijigeshu = $_config['g_suijigeshu'];
        }

        //start
        if ($basescript == "group") {


            if (!empty($_config['g_yunxuuid'])) {
                $yunxuuids = array();
                $yunxuuids = explode(',',trim($_config['g_yunxuuid']));

                if(!in_array($uid,$yunxuuids)){
                    return;
                }
            }else{
                $mianuids = array();

                if (!empty($_config['g_mianuid'])) {
                    $mianuids = explode(',',trim($_config['g_mianuid']));

                    if(in_array($uid,$mianuids)){
                        return;
                    }
                }
            }


            if (!empty($_config['g_yunxutid'])) {
                $yunxutids = array();
                $yunxutids = explode(',',trim($_config['g_yunxutid']));

                if(!in_array($tid,$yunxutids)){
                    return;
                }
            }else{
                $miantids = array();

                if (!empty($_config['g_miantid'])) {
                    $miantids = explode(',',trim($_config['g_miantid']));

                    if(in_array($tid,$miantids)){
                        return;
                    }
                }
            }


            if ( $_config['g_isopenqunzusjsp'] && in_array ( $groupid, (array)unserialize($_config['g_yxgroups']) )){
                 

                //20161222 start
                $ok_suijicategory = "";
                //cache start
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';

                    $ok_suijicategory = $tbkcategory;

                }else{
                    $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();

                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));

                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';
                    $ok_suijicategory = $tbkcategory;

                }
                //cache end
                $suijicategorylist = array();
                foreach ($ok_suijicategory as $suijidata){
                    if(in_array($fid,json_decode($suijidata['groups']))){
                        $suijicategorylist[] = $suijidata['id'];
                    }
                }

                 
                $utils = new Utils();
                //cache start
                /*
                if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php')){
                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php';

                    $allokshangpin = array();
                    foreach ($suijicategorylist as $sjdata){
                        $okshangpin = $utils->search($sjdata,'categoryid',$tbkshangpin);
                        if(!empty($okshangpin) && $okshangpin != null){
                            $allokshangpin = array_merge($allokshangpin, $okshangpin);
                        }

                    }

                    $this->cacheshangpin = $allokshangpin;

                }else{
                    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();

                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));

                    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php';

                    $allokshangpin = array();
                    foreach ($suijicategorylist as $sjdata){
                        $okshangpin = $utils->search($sjdata,'categoryid',$tbkshangpin);
                        if(!empty($okshangpin) && $okshangpin != null){
                            $allokshangpin = array_merge($allokshangpin, $okshangpin);
                        }

                    }

                    $this->cacheshangpin = $allokshangpin;
                }
                */
                //20190329 add

                $allokshangpin = array();
                foreach ($suijicategorylist as $sjdata){
                    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php')){
                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                        $tbkshangpin = ${'tbkshangpin_'.$sjdata};

                    }else{
                        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $sjdata);

                        require_once libfile('function/cache');
                        writetocache('jzsjiale_daogou_shangpin_'.$sjdata, getcachevars(array('tbkshangpin_'.$sjdata => $shangpin_cache_tmp)));

                        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                        $tbkshangpin = ${'tbkshangpin_'.$sjdata};

                    }

                    if(!empty($tbkshangpin) && $tbkshangpin != null){
                        $allokshangpin = array_merge($allokshangpin, $tbkshangpin);
                    }
                    $this->cacheshangpin = $allokshangpin;
                }
                //cache end
                //20161222 over

                $spcount = count($this->cacheshangpin);

                if(empty($this->cacheshangpin) || $spcount <= 0){
                    return;
                }

                if($spcount <= $suijigeshu){
                    $suijigeshu = $spcount;
                }


                //css start

                $cssstr = "<link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/e.css\" type=\"text/css\" /><link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/tbkitem.css\" type=\"text/css\" />";
                $pos = strpos($postlist[$pid]['message'], $cssstr);

                if($pos === false){
                    $postlist[$pid]['message'] = $cssstr.'<br/>'.$postlist[$pid]['message']  ;

                    if($_G["thread"]["freemessage"]){
                        $_G["thread"]["freemessage"] = $cssstr.'<br/>'.$_G["thread"]["freemessage"];
                    }
                }
                //css end

                if ($_config['g_ding']) {
                     
                    $spdingid = array_rand($this->cacheshangpin,$suijigeshu);


                    $spdingformat = "";

                    if($suijigeshu == 1){
                        $spding = $this->cacheshangpin[$spdingid];
                        $spdingformat .= $this->getshangpin($spding);
                    }else{
                        $yhqnullclass = "bingpaisuijiding";
                        $haveyhq = false;
                        for($i=0;$i<$suijigeshu;$i++){
                            $spding = $this->cacheshangpin[$spdingid[$i]];
                            if(!empty($spding['youhuiquan'])){
                                $haveyhq = true;
                            }
                            $spdingformat .= $this->getshangpin($spding,$yhqnullclass);
                        }
                    }
                    if(!$haveyhq){
                        $spdingformat .= '<style type="text/css">.bingpaisuijiding{height:0px!important;line-height:0px!important;}</style>';
                    }


                    $postlist[$pid]['message'] = '<div class="e-row">'.$spdingformat.'</div><br/>'.$postlist[$pid]['message']  ;

                    if($_G["thread"]["freemessage"]){
                        $_G["thread"]["freemessage"] = '<div class="e-row">'.$spdingformat.'</div><br/>'.$_G["thread"]["freemessage"];
                    }
                }


                if ($_config['g_wei']) {

                    $spweiid = array_rand($this->cacheshangpin,$suijigeshu);

                    $spweiformat = "";

                    if($suijigeshu == 1){
                        $spwei = $this->cacheshangpin[$spweiid];
                        $spweiformat .= $this->getshangpin($spwei);
                    }else{
                        $yhqnullclass = "bingpaisuijiwei";
                        $haveyhq = false;
                        for($i=0;$i<$suijigeshu;$i++){
                            $spwei = $this->cacheshangpin[$spweiid[$i]];
                            if(!empty($spwei['youhuiquan'])){
                                $haveyhq = true;
                            }
                            $spweiformat .= $this->getshangpin($spwei,$yhqnullclass);
                        }
                    }
                    if(!$haveyhq){
                        $spweiformat .= '<style type="text/css">.bingpaisuijiwei{height:0px!important;line-height:0px!important;}</style>';
                    }



                    $postlist[$pid]['message'] = $postlist[$pid]['message'] . '<br/><div class="e-row">'. $spweiformat .'</div>';

                    if($_G["thread"]["freemessage"]){
                        $_G["thread"]["freemessage"] = $_G["thread"]["freemessage"] . '<br/><div class="e-row">'. $spweiformat .'</div>';
                    }
                }

            }else{
                return;
            }

        }
        //end
    }

    function getshangpin($shangpin,$yhqnullclass="")
    {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];

        $id = $shangpin['id'];
        $tbk_title = $shangpin['title'];
        $tbk_imgurl = $shangpin['img'];
        $tbk_url = $shangpin['url'];
        $tbk_yuanjia = $shangpin['yuanjia'];

        $isyuanjia = true;
        if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == ""){
            $isyuanjia = false;
        }


        $tbk_xianjia = $shangpin['xianjia'];
        
        //20180912 add start
        $isxianjia = true;
        if($tbk_xianjia == "#" || $tbk_xianjia == 0 || $tbk_xianjia == ""){
            $isxianjia = false;
        }
        //20180912 add end

        $tbk_youhuiquanurl = $shangpin['youhuiquan'];
        $tbk_youhuitips = $_config['g_youhuitips'];

        $isshowyhk = false;
        if(!empty($shangpin['youhuiquan'])){
            $isshowyhk = true;
        }

        $tbkstyle = $_config['g_pcsuijistyle'];
        if(empty($tbkstyle)){
            $tbkstyle = "discuzcode";
        }

        $g_isopenzhtglj = $_config['g_isopenzhtglj'];
        $numiid = $shangpin['numiid'];
        
        $tbk_goumai = $_config['g_goumai'];
        $tbk_youhuiquan = $_config['g_youhuiquan'];

        $isnofollow = true;
        $isnofollow = $_config['g_isnofollow'];

        if($_config['g_spneilian']){
            $tbk_url = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$shangpin['id'];
            $tbk_youhuiquanurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$shangpin['id'];
        }

        if($tbkstyle == "fangyhq"){
            $tbk_platform = (!empty($shangpin['platform']) && $shangpin['platform'] != 'none')?$shangpin['platform']:'';
            $tbk_platform_img = !empty($tbk_platform)?'/source/plugin/jzsjiale_daogou/static/images/platform/'.$tbk_platform.'.png':'';

            $tbk_freeshipment = $shangpin['freeshipment'];
            if($tbk_freeshipment == "1"){
                $tbk_freeshipment = 1;
            }else{
                $tbk_freeshipment = 0;
            }

            //newyhq start

            $is_time_ok = false;
            if(!empty($shangpin['couponstarttime']) && !empty($shangpin['couponendtime'])){
                $time_now = time();
                $time_start = strtotime(date($shangpin['couponstarttime']));
                $time_end = strtotime(date($shangpin['couponendtime'])) + 86400 - 1;

                if($time_now >= $time_start && $time_now <= $time_end){
                    $is_time_ok = true;
                }else{
                    $is_time_ok = false;
                    $isshowyhk = false;
                }
            }
            if($_config['g_pcyhqstyle'] != 'none' && !empty($tbk_xianjia) && !empty($shangpin['youhuiquan'])
                && !empty($shangpin['couponstartfee']) && !empty($shangpin['couponamount']) && $is_time_ok){

                $tbk_couponamount = $shangpin['couponamount'];
                if($tbk_couponamount > 0){
                    if($shangpin['couponstartfee'] <= $shangpin['xianjia']){
                        $tbk_quanhoujia = (double)$shangpin['xianjia'] - (double)$shangpin['couponamount'];
                    }
                }


                $tbk_youxiaoqi = !empty($shangpin['couponendtime'])?(!empty($shangpin['couponstarttime'])?$shangpin['couponstarttime'].'&nbsp;&nbsp;-&nbsp;&nbsp;'.$shangpin['couponendtime']:$shangpin['couponendtime']):"";



                $tbkstyle = $_config['g_pcyhqstyle'];
                include template('jzsjiale_daogou:'.$tbkstyle);
                return trim($return);
            }else{
                include template('jzsjiale_daogou:'.$tbkstyle);
                return trim($return);
            }
        }else{
            include template('jzsjiale_daogou:'.$tbkstyle);
            return trim($return);
        }
    }


    function viewthread_postheader(){

        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];

        if (! $_config['g_isopen']) {
            return;
        }

        if (! $_config['g_qunzupctuijian']) {
            return;
        }

        $uid = $_G['uid'];

        if (empty($uid)) {
            return;
        }

        $fid = $_G['fid'];
        if (empty($fid)) {
            return;
        }

        $groupid = $_G['groupid'];
        if (empty($groupid)) {
            return;
        }

        if (in_array ( $groupid, (array)unserialize($_config['g_tuijianpcgroup']) ))
        {
            $posttextbtn['0']='&nbsp;&nbsp;<a href="#" onclick="showWindow(\'jzsjiale_daogou_mods\', \'plugin.php?id=jzsjiale_daogou:tuijian&tid='.$_G['tid'].'&fid='.$_G['fid'].'&groupflag=1\', \'get\', -1);return false;" style="color:red;"><b>'.$_config['g_tuijianbtntitle'].'</b></a>&nbsp;&nbsp;&nbsp;';

            return $posttextbtn;
        }else{
            return "";
        }
    }

    function viewthread_postfooter(){

        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];

        if (! $_config['g_isopen']) {
            return;
        }

        if (! $_config['g_qunzupctuijian']) {
            return;
        }

        $uid = $_G['uid'];

        if (empty($uid)) {
            return;
        }

        $fid = $_G['fid'];
        if (empty($fid)) {
            return;
        }

        $groupid = $_G['groupid'];
        if (empty($groupid)) {
            return;
        }

        if (in_array ( $groupid, (array)unserialize($_config['g_tuijianpcgroup']) ))
        {
            $posttextbtn['0']='&nbsp;&nbsp;<a href="#" onclick="showWindow(\'jzsjiale_daogou_mods\', \'plugin.php?id=jzsjiale_daogou:tuijian&tid='.$_G['tid'].'&fid='.$_G['fid'].'&groupflag=1\', \'get\', -1);return false;" style="color:red;"><b>'.$_config['g_tuijianbtntitle'].'</b></a>&nbsp;&nbsp;&nbsp;';
             
            return $posttextbtn;
        }else{
            return "";
        }

    }

    function plang($str)
    {
        return lang('plugin/jzsjiale_daogou', $str);
    }
}
//From: Dism��taobao��com
?>