<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
global $_G, $lang;

loadcache('plugin');


require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';
require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';

$utils = new Utils();

if($act=='sousuo'){
    if(submitcheck('submit')){
    
        $setting = $_GET['setting'];
        $dsp = array();
        $dsp['q'] = daddslashes(trim($setting['q']));
        $dsp['page_no'] = daddslashes(trim($setting['page_no']));
        $dsp['page_size'] = daddslashes(trim($setting['page_size']));
        $dsp['currpage'] = '1';
         
        /*
        if(empty($dsp['q'])){
            cpmsg('jzsjiale_daogou:youhuiquanq_null', '', 'error');
        }
        */
        
        if(!empty($dsp['page_no']) && !is_numeric($dsp['page_no'])){
            cpmsg('jzsjiale_daogou:youhuiquanpage_no_notnumeric', '', 'error');
        }
        if(!empty($dsp['page_size']) && !is_numeric($dsp['page_size'])){
            cpmsg('jzsjiale_daogou:youhuiquanpage_size_notnumeric', '', 'error');
        }
      
        setSpList($dsp);
        dexit();
    }
    
}elseif($act=='spfanye'){
    
    $page = intval($_GET['page']);
    $page = $page > 0 ? $page : 1;

    $dsp = array();
    $dsp['q'] = daddslashes(trim($_GET['q']));
    $dsp['page_no'] = daddslashes(trim($_GET['page_no']));
    $dsp['page_size'] = daddslashes(trim($_GET['page_size']));
    $dsp['currpage'] = $page;
    
    /*
    if(empty($dsp['q'])){
        cpmsg('jzsjiale_daogou:youhuiquanq_null', '', 'error');
    }
    */
    if(!empty($dsp['page_no']) && !is_numeric($dsp['page_no'])){
        cpmsg('jzsjiale_daogou:youhuiquanpage_no_notnumeric', '', 'error');
    }
    if(!empty($dsp['page_size']) && !is_numeric($dsp['page_size'])){
        cpmsg('jzsjiale_daogou:youhuiquanpage_size_notnumeric', '', 'error');
    }
    
    setSpList($dsp);
    
    dexit();
}elseif($act=='caiji'){
	
    $currpage = intval($_GET['currpage']);
    $currpage = $currpage > 0 ? $currpage : 1;
    
    $dsp = array();
    $dsp['q'] = daddslashes(trim($_GET['q']));
    $dsp['page_no'] = daddslashes(trim($_GET['page_no']));
    $dsp['page_size'] = daddslashes(trim($_GET['page_size']));
    $dsp['currpage'] = $currpage;
    
  
    
    $spcategoryid = $_POST['spcategoryid'];
    $numiids = $_POST['numiids'];
    $numiidsstr = "";
    
    /*
    if(empty($dsp['q'])){
        cpmsg('jzsjiale_daogou:youhuiquanq_null', '', 'error');
    }
    */
    if (! empty($dsp['page_no']) && ! is_numeric($dsp['page_no'])) {
        cpmsg('jzsjiale_daogou:youhuiquan_shuju_error', '', 'error');
    }
    if (! empty($dsp['page_size']) && ! is_numeric($dsp['page_size'])) {
        cpmsg('jzsjiale_daogou:youhuiquan_shuju_error', '', 'error');
    }
    
    
    if(empty($spcategoryid)){
        $spcategoryid=0;
    }
    if(empty($numiids)){
        cpmsg('jzsjiale_daogou:youhuiquancxcaiji_notxuanze', '', 'error');
    }
  
    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
    $tbappkey = $_config['g_appkey'];
    $tbsecretKey = $_config['g_appsecret'];
    $webbianma = $_G['charset'];
    $pid = $_config['g_pid'];
    
    /*
    if (empty($pid)) {
        cpmsg('jzsjiale_daogou:pidnull', '', 'error');
        dexit();
    }
    
    $dzoneId = explode("_", $pid);
    $dzoneId = $dzoneId[3];
    
    if (empty($dzoneId)) {
        cpmsg('jzsjiale_daogou:pidnull', '', 'error');
        dexit();
    }
    
    $gtkl = new GetTbAPI();
    $gtkl->__construct($tbappkey, $tbsecretKey);
    $tbinfo = $gtkl->getyouhuiquanitem($dsp, $dzoneId, $webbianma);
    
    $tbinfo = json_decode($tbinfo);
    
    $splistinfo = $tbinfo->results->tbk_coupon;
    
    */

    $tbinfo = "";
    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_yhqshangpin.php')){
        @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_yhqshangpin.php';
    
        $tbinfo = $yhqshangpin;
    
    }else{
        cpmsg('jzsjiale_daogou:cxcaiji_error', '', 'error');
        dexit();
    }
    
    $tbinfo = json_decode($tbinfo);
    
    $splistinfo = $tbinfo->results->tbk_coupon;
    
    
    
    $isok = false;
    
    foreach($splistinfo as $tbi){

        if($webbianma == "gbk"){
            $numiid = diconv(dhtmlspecialchars($tbi->num_iid),'UTF-8','GB2312');
            $title = diconv(dhtmlspecialchars($tbi->title),'UTF-8','GB2312');
            $pic_url = diconv(dhtmlspecialchars($tbi->pict_url),'UTF-8','GB2312');
            $click_url = diconv(dhtmlspecialchars($tbi->coupon_click_url),'UTF-8','GB2312');
            $zk_final_price = diconv(dhtmlspecialchars($tbi->zk_final_price),'UTF-8','GB2312');
            $cx_coupon_info = diconv(dhtmlspecialchars($tbi->coupon_info),'UTF-8','GB2312');
        }else{
            $numiid = dhtmlspecialchars($tbi->num_iid);
            $title = dhtmlspecialchars($tbi->title);
            $pic_url = dhtmlspecialchars($tbi->pict_url);
            $click_url = dhtmlspecialchars($tbi->coupon_click_url);
            $zk_final_price = dhtmlspecialchars($tbi->zk_final_price);
            $cx_coupon_info = dhtmlspecialchars($tbi->coupon_info);
        }
        
        if(!in_array($numiid,$numiids)){
            continue;
        }else{
            $spsetting = array('dateline'=>TIMESTAMP);
            $spsetting['numiid'] = $numiid;
            $spsetting['title'] = $title;
            $spsetting['url'] = $click_url;
            $spsetting['img'] = $pic_url;
            $spsetting['youhuiquan'] = $click_url;//$click_url;
            $spsetting['yuanjia'] = $zk_final_price;// $reserve_price;
            $spsetting['xianjia'] = $zk_final_price;
            $spsetting['tkl'] = "";
            $spsetting['categoryid'] = $spcategoryid;
            $spsetting['status'] = 1;
            
            //tiqu  youhuijiage
            if(!empty($cx_coupon_info)){
                $patterns = "/\d+/";
                $yhqarrtmp = array();
                preg_match_all($patterns,$cx_coupon_info,$yhqarrtmp);
                
                $yhqarr=$yhqarrtmp[0];
                
                if($yhqarr[1] > 0 &&  $yhqarr[1] != ""){
                    if($yhqarr[0] > $zk_final_price){
                        $spsetting['xianjia'] = $zk_final_price;
                    }
                    if($yhqarr[0] <= $zk_final_price){
                        $spsetting['xianjia'] = intval($zk_final_price) - intval($yhqarr[1]);
                    }
                }elseif($yhqarr[1] <= 0 ||  $yhqarr[1] == ""){
                    if($yhqarr[0] > $zk_final_price){
                        $spsetting['xianjia'] = $zk_final_price;
                    }
                    if($yhqarr[0] <= $zk_final_price){
                        $spsetting['xianjia'] = intval($zk_final_price) - intval($yhqarr[0]);
                    }
                }
            }
            
          
            if(C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->insert($spsetting,true)){
                $isok = true;
            }else{
                $isok = false;
            }
        }
                
    }
    
    if($isok){
        recache(false,$spcategoryid);
        cpmsg('jzsjiale_daogou:cxcaiji_success', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=youhuiquan&act=spfanye&q='.$_GET['q'].'&page_no='.$dsp['page_no'].'&page_size='.$dsp['page_size'].'&page='.$currpage, 'succeed');
    }else{
        cpmsg('jzsjiale_daogou:cxcaiji_error', '', 'error');
    }
    
	dexit();
}






/////////caiji start

echo '<div class="colorbox"><h4>'.plang('aboutyouhuiquan').'</h4>'.
                      '<table cellspacing="0" cellpadding="3"><tr>'.
                      '<td valign="top">'.plang('youhuiquandescription').'</td></tr></table>'.
                      '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

/////////caiji end

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=youhuiquan&act=sousuo', 'enctype');
showtableheader(plang('youhuiquantitle'), '');
showsetting(plang('youhuiquanq'),'setting[q]','','text','','',plang('youhuiquanq_msg'));

$page_noselect ='';
$page_noselect .= '<option value="1" selected>'.plang('youhuiquanpage_no_gong').'1'.plang('youhuiquanpage_no_ye').'</option>';
for($ino = 2;$ino<=200;$ino++){
    $page_noselect .= '<option value="'.$ino.'">'.plang('youhuiquanpage_no_gong').$ino.plang('youhuiquanpage_no_ye').'</option>';
}
showsetting(plang('youhuiquanpage_no'),'setting[page_no]','','<select name="setting[page_no]">'.$page_noselect.'</select>','',0,plang('youhuiquanpage_no_msg'),1,'youhuiquanpage_no');


showsetting(plang('youhuiquanpage_size'),'setting[page_size]','20','text','','',plang('youhuiquanpage_size_msg'));

showsubmit('submit', plang('youhuiquansousuosubmit'));
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/



function setSpList($dsp) {

        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $tbappkey = $_config['g_appkey'];
        $tbsecretKey = $_config['g_appsecret'];
        $pid = $_config['g_pid'];
        $webbianma = $_G['charset'];
  
        if(empty($pid)){
            cpmsg('jzsjiale_daogou:pidnull', '', 'error');
            dexit();
        }
        
        $dzoneId = explode("_",$pid);
        $dzoneId = $dzoneId[3];
         
        if(empty($dzoneId)){
            cpmsg('jzsjiale_daogou:pidnull', '', 'error');
            dexit();
        }
        
        
        $gtkl = new GetTbAPI;
        $gtkl->__construct($tbappkey, $tbsecretKey);
        $tbinfo =  $gtkl->getyouhuiquanitem($dsp,$dzoneId,$webbianma);

        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_yhqshangpin', getcachevars(array('yhqshangpin' => $tbinfo)));
        
        $tbinfo = json_decode($tbinfo);
        
        $splistinfo = $tbinfo->results->tbk_coupon;
        
        
        
        
        
        //----sp list
        echo '<div class="colorbox"><h4>'.plang('aboutyouhuiquancx').'</h4>'.
            '<table cellspacing="0" cellpadding="3"><tr>'.
            '<td valign="top">'.plang('youhuiquancxdescription').'</td></tr></table>'.
            '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';
        
        showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=youhuiquan&act=caiji&q='.$dsp['q'].'&page_no='.$dsp['page_no'].'&page_size='.$dsp['page_size'].'&currpage='.$dsp['currpage'], 'enctype');
        
        showtableheader(plang('cxyouhuiquansplist'), '');
        showsubtitle(plang('cxyouhuiquansptitle'));
        
        foreach($splistinfo as $spi){
       
	        if($webbianma == 'gbk') {
	            $cx_num_iid = diconv($spi->num_iid,'UTF-8','GB2312');
	            $cx_title = diconv($spi->title,'UTF-8','GB2312');
	            $cx_pict_url = diconv($spi->pict_url,'UTF-8','GB2312');
	            //$cx_small_images = diconv($spi->small_images,'UTF-8','GB2312');
	            $cx_zk_final_price = diconv($spi->zk_final_price,'UTF-8','GB2312');
	            $cx_user_type = diconv($spi->user_type,'UTF-8','GB2312');
	            $cx_item_url = diconv($spi->item_url,'UTF-8','GB2312');
	            $cx_coupon_click_url = diconv($spi->coupon_click_url,'UTF-8','GB2312');
	            $cx_coupon_info = diconv($spi->coupon_info,'UTF-8','GB2312');
	            $cx_coupon_remain_count = diconv($spi->coupon_remain_count,'UTF-8','GB2312');
	            $cx_coupon_start_time = diconv($spi->coupon_start_time,'UTF-8','GB2312');
	            $cx_coupon_end_time = diconv($spi->coupon_end_time,'UTF-8','GB2312');
	            $cx_seller_id = diconv($spi->seller_id,'UTF-8','GB2312');
	            $cx_volume = diconv($spi->volume,'UTF-8','GB2312');
	            $cx_nick = diconv($spi->nick,'UTF-8','GB2312');
	        }else{
	            $cx_num_iid = $spi->num_iid;
	            $cx_title = $spi->title;
	            $cx_pict_url = $spi->pict_url;
	            //$cx_small_images = $spi->small_images;
	            $cx_zk_final_price = $spi->zk_final_price;
	            $cx_user_type = $spi->user_type;
	            $cx_item_url = $spi->item_url;
	            $cx_coupon_click_url = $spi->coupon_click_url;
	            $cx_coupon_info = $spi->coupon_info;
	            $cx_coupon_remain_count = $spi->coupon_remain_count;
	            $cx_coupon_start_time = $spi->coupon_start_time;
	            $cx_coupon_end_time = $spi->coupon_end_time;
	            $cx_seller_id = $spi->seller_id;
	            $cx_volume = $spi->volume;
	            $cx_nick = $spi->nick;
	        }
	        
	        
	        showtablerow('', array('width="50"'), array(
	        '<input class="checkbox" type="checkbox" name="numiids[]" value="'.$cx_num_iid.'" title="'.$cx_num_iid.'" width="80">'.$cx_num_iid,
	        '<a href="'.$cx_item_url.'" target="_blank"><span title="'.$cx_title.'">'.mb_substr($cx_title,0,40).'</span></a>',
	        '<a href="'.$cx_item_url.'" target="_blank"><img src="' . $cx_pict_url . '" width="80px" /></a>',
	        '<span title="'.$cx_zk_final_price.'">'.mb_substr($cx_zk_final_price,0,40).'</span>',
	        '<span title="'.($cx_user_type?getSpanColor(plang('cxyouhuiquanuser_type_shangcheng'),'red'):getSpanColor(plang('cxyouhuiquanuser_type_jishi'),'green')).'">'.($cx_user_type?getSpanColor(plang('cxyouhuiquanuser_type_shangcheng'),'red'):getSpanColor(plang('cxyouhuiquanuser_type_jishi'),'green')).'</span>',
	        '<a href="'.$cx_coupon_click_url.'" target="_blank">' . mb_substr($cx_coupon_click_url,0,40) .'...</a>',
	        '<span title="'.$cx_nick.'">'.mb_substr($cx_nick,0,40).'</span>',
	        '<span title="'.$cx_volume.'">'.mb_substr($cx_volume,0,40).'</span>',
	        '<span title="'.$cx_coupon_info.'">'.mb_substr($cx_coupon_info,0,40).'</span>',
	        '<span title="'.$cx_coupon_remain_count.'">'.mb_substr($cx_coupon_remain_count,0,40).'</span>',
	        '<span title="'.$cx_coupon_start_time.'">'.mb_substr($cx_coupon_start_time,0,40).'</span>',
	        '<span title="'.$cx_coupon_end_time.'">'.mb_substr($cx_coupon_end_time,0,40).'</span>')
	        );
	        
	    }

	    
	    $count = $dsp['page_size'] * $dsp['page_no'];
	    $mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=youhuiquan&act=spfanye&q='.$dsp['q'].'&page_no='.$dsp['page_no'].'&page_size='.$dsp['page_size'];
	    $multipage = multi($count, $dsp['page_size'], $dsp['currpage'], $mpurl);
	    //showsubmit('', '', '', '', $multipage);
	    
	    
	    showsubmit('', '', '','<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'numiids\')" /><label for="chkall">'.cplang('select_all').'</label>&nbsp;&nbsp<span style="color:red;">'.plang('cxfenleitip').'</span>&nbsp;&nbsp'.getcategoryselect().'&nbsp;&nbsp<input type="submit" class="btn" name="batchbutton" value="'.cplang('submit').'" />', plang('allcount').(!empty($multipage)?$multipage:$count));
	    
	    
	    showtablefooter(); /*Dism��taobao��com*/
	    showformfooter(); /*Dism_taobao_com*/
	  
}



function recache($isallcategory = true,$categoryid = 0){
    /*
    $allshangpin = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuiji();

    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_shangpin', getcachevars(array('tbkshangpin' => $allshangpin)));
    */
    //20190329 add
    if($isallcategory){
        $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

        foreach ($category as $key => $value){

            $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1,$value["id"]);

            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));
        }
    }else{
        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $categoryid);

        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_shangpin_'.$categoryid, getcachevars(array('tbkshangpin_'.$categoryid => $shangpin_cache_tmp)));
    }

}

function getcategoryselect() {
         $categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid(0,1);
         $categoryidselect = '<option value="0">------'.plang('qingxuanze').'------</option>';
         $categoryidselect .= '<option value="0">------'.plang('bufenlei').'------</option>';
         foreach($categoryids as $k =>$v){
               $categoryidselect .= '<option value="'.$v['id'].'" >'.$v['title'].'</option>';
               $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($v['id'],1);
                 foreach($subcategoryids as $subk =>$subv){
                      $categoryidselect .= '<option value="'.$subv['id'].'" >&nbsp;&nbsp;&nbsp;&nbsp;'.$subv['title'].'</option>';
                      
                      $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getcategory_by_pid($subv['id'],1);
                      foreach($sub3categoryids as $sub3k =>$sub3v){
                          $categoryidselect .= '<option value="'.$sub3v['id'].'" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sub3v['title'].'</option>';
                      }
                 }
         }
         $categoryselect = '<select name="spcategoryid" id="spcategoryid">'.$categoryidselect.'</select>';

         return $categoryselect;
}

function getSpanColor($str,$color) {
    return "<span style='color:".$color.";'>".$str."</span>";
}

function plang($str) {
	return lang('plugin/jzsjiale_daogou', $str);
}
//From: Dism��taobao��com
?>