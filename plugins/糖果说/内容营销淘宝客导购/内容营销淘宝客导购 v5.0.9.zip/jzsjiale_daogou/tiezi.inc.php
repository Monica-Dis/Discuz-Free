<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
global $_G, $lang;

require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';

if($act=='add'){
	if(submitcheck('submit')){
	
		$setting = $_GET['setting'];
		$dsp = array('dateline'=>TIMESTAMP);
		$dsp['tid'] = dintval(daddslashes(trim($setting['tid'])));
		$dsp['tiezicategoryid'] = daddslashes(trim($setting['tiezicategoryid']));
		$dsp['sort'] = daddslashes(trim($setting['sort']));
		$dsp['status'] = daddslashes(trim($setting['status']));
		
		if(empty($dsp['tid'])){
		    cpmsg('jzsjiale_daogou:dtiezitid_msgnull', '', 'error');
		}
		if(empty($dsp['sort']) && $dsp['sort'] != '0'){
		    cpmsg('jzsjiale_daogou:dtiezisort_msgnull', '', 'error');
		}
		
		if(empty($dsp['tiezicategoryid']) || $dsp['tiezicategoryid'] == 0){
		    cpmsg('jzsjiale_daogou:dtiezicategory_msgnull', '', 'error');
		}
		
		$yanzhengtuijian = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->get_by_tidandcategoryid($dsp['tid'],$dsp['tiezicategoryid']);
		if(!empty($yanzhengtuijian)){
		    cpmsg('jzsjiale_daogou:yijingtuijian', '', 'error');
		}
		
		$postresult = C::t('forum_thread')->fetch($dsp['tid']);
		$dsp['title'] = $postresult['subject'];
		
		if(empty($dsp['title'])){
			cpmsg('jzsjiale_daogou:dtiezititle_msgnull', '', 'error');
		}
		
		
		if(C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->insert($dsp,true)){
		    recache();
			cpmsg('jzsjiale_daogou:addok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi', 'succeed');
		}else{
			cpmsg('jzsjiale_daogou:error', '', 'error');
		}
	}
	
	
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&act=add', 'enctype');
	showtableheader(plang('addtiezititle'), '');
	showsetting(plang('dtiezitid'),'setting[tid]','','text','','',plang('dtiezitid_msg'));
	
	
	$categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid(0,1);
	$categoryidselect = '<option value="0">'.plang('qingxuanze').'</option>';
	foreach($categoryids as $k =>$v){
	    $categoryidselect .= '<option value="'.$v['id'].'">'.$v['title'].'</option>';
	     
	    $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($v['id'],1);
	     
	    foreach($subcategoryids as $subk =>$subv){
	        $categoryidselect .= '<option value="'.$subv['id'].'">&nbsp;&nbsp;&nbsp;&nbsp;'.$subv['title'].'</option>';
	
	        $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($subv['id'],1);
	        
	        foreach($sub3categoryids as $sub3k =>$sub3v){
	            $categoryidselect .= '<option value="'.$sub3v['id'].'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sub3v['title'].'</option>';
	        
	        }
	    }
	}
	showsetting(plang('dtiezicategory'),'setting[tiezicategoryid]','','<select name="setting[tiezicategoryid]">'.$categoryidselect.'</select>','',0,plang('dtiezicategory_msg'),1,'dtiezicategory');
	
	
	
	showsetting(plang('dtiezisort'),'setting[sort]','1','text','','',plang('dtiezisort_msg'));
	showsetting(plang('dtiezistatus'),'setting[status]','1','radio','','',plang('dtiezistatus_msg'));

	showsubmit('submit', 'submit');
	showtablefooter(); /*Dism��taobao��com*/
	showformfooter(); /*Dism_taobao_com*/
	
	
	dexit();
}elseif($formhash == FORMHASH && $act=='addpiliangsubmit'){

        if($_GET['fids']){
            $fids = $_GET['fids'];
        }else{
            $fids = implode(',',$_GET['inforum']);
        }
        $fids = daddslashes(trim($fids));
        $tiezicategoryid = daddslashes(trim($_GET['tiezicategoryid']));
        $sort = daddslashes(trim($_GET['sort']));
        $status = daddslashes(trim($_GET['status']));
        $tiezistarttime = daddslashes(trim($_GET['tiezistarttime']));
        $tieziendtime = daddslashes(trim($_GET['tieziendtime']));
        
        $tiezistarttime = strtotime($tiezistarttime);
        $tieziendtime = strtotime($tieziendtime);

		if(empty($fids)){
		    cpmsg('jzsjiale_daogou:dtiezifids_msgnull', '', 'error');
		}
		
		if(empty($tiezistarttime)){
		    cpmsg('jzsjiale_daogou:dtiezistarttime_msgnull', '', 'error');
		}
		if(empty($tieziendtime)){
		    cpmsg('jzsjiale_daogou:dtieziendtime_msgnull', '', 'error');
		}
		
		if(!empty($tiezistarttime) && !empty($tieziendtime)) {
		    if($tieziendtime <= $tiezistarttime) {
		        cpmsg('jzsjiale_daogou:d_endtime_invalid', '', 'error');
		    }
		}
		
		if(empty($sort) && $sort != '0'){
		    $sort = '0';
		}
		
		if(empty($tiezicategoryid) || $tiezicategoryid == 0){
		    cpmsg('jzsjiale_daogou:dtiezicategory_msgnull', '', 'error');
		}
		
		
		$pertask = dintval(daddslashes(trim($_GET['pertask'])))?dintval(daddslashes(trim($_GET['pertask']))):10;
		$next = dintval(daddslashes(trim($_GET['next'])));
		if($next){
		    $current = $next;
		}else{
		    $current = 0;
		}
		$nextcurrent = $current + ($pertask-1);
		$next = $nextcurrent+1;
		$nextlink = "action=plugins&operation=config&do=$pluginid&identifier=jzsjiale_daogou&pmod=tiezi&act=addpiliangsubmit&next=$next&pertask=$pertask&formhash=".FORMHASH."&tiezicategoryid=$tiezicategoryid&sort=$sort&fids=$fids&status=$status&tiezistarttime=".$_GET['tiezistarttime']."&tieziendtime=".$_GET['tieziendtime'];
		
		
		$fids = $fids?$fids:0;
		$count = DB::result_first("SELECT count(*) FROM ".DB::table('forum_post')." WHERE invisible>=0 and first=1 and dateline>=$tiezistarttime and dateline<=$tieziendtime and fid in($fids)");
		$query = DB::query("SELECT * FROM ".DB::table('forum_post')." WHERE invisible>=0 and first=1 and dateline>=$tiezistarttime and dateline<=$tieziendtime and fid in($fids) LIMIT $current,$pertask");
	
		require_once libfile('function/post');
		while($value = DB::fetch($query)){
		    $tid = $value['tid'];
		    
		    $yanzhengtuijian = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->get_by_tidandcategoryid($tid,$tiezicategoryid);
		    if(!empty($yanzhengtuijian)){
		        continue;
		    }
		    
		    $dsp = array('dateline'=>TIMESTAMP);
		    $postresult = C::t('forum_thread')->fetch($tid);
		    $dsp['title'] = $postresult['subject'];
		    if(empty($dsp['title'])){
		        $dsp['title'] = plang('wubiaoti');
		    }

		    $dsp['tid'] = $tid;
		    $dsp['tiezicategoryid'] = $tiezicategoryid;
		    $dsp['sort'] = $sort;
		    $dsp['status'] = $status;
		    C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->insert($dsp,true);
		}
		
		
		if($current < $count-1){
		    recache();
		    cpmsg(plang('curr_caijifids').cplang('counter_processing', array('current' => ($current+1), 'next' => ($nextcurrent+1))), $nextlink, 'loading',array('count' => $count));
		}else{
		    recache();
		    cpmsg('jzsjiale_daogou:caijifidsok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi', 'succeed');
		}
}elseif($act=='addpiliang'){
    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&act=addpiliangsubmit', 'enctype');
	showtableheader(plang('addtiezipiliangtitle'), '');
	echo'<input type="hidden" value="'.FORMHASH.'" name="formhash"/>';
	
	require_once libfile('function/forumlist');
	showsetting(plang('dtiezifids'), '', '', '<select name="inforum[]" multiple="multiple" size="10">'.forumselect(FALSE, 0, 0, TRUE).'</select>','',0,plang('dtiezifids_msg'),1,'dtiezifids');
	
	
	$categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid(0,1);
	$categoryidselect = '<option value="0">'.plang('qingxuanze').'</option>';
	foreach($categoryids as $k =>$v){
	    $categoryidselect .= '<option value="'.$v['id'].'">'.$v['title'].'</option>';
	     
	    $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($v['id'],1);
	     
	    foreach($subcategoryids as $subk =>$subv){
	        $categoryidselect .= '<option value="'.$subv['id'].'">&nbsp;&nbsp;&nbsp;&nbsp;'.$subv['title'].'</option>';
	
	        $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($subv['id'],1);
	        
	        foreach($sub3categoryids as $sub3k =>$sub3v){
	            $categoryidselect .= '<option value="'.$sub3v['id'].'">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sub3v['title'].'</option>';
	        
	        }
	    }
	}
	
	echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
	showsetting(plang('dtiezistarttime'),'tiezistarttime','','calendar','',0,plang('dtiezistarttime_msg'),1,'dtiezistarttime');
	showsetting(plang('dtieziendtime'),'tieziendtime','','calendar','',0,plang('dtieziendtime_msg'),1,'dtieziendtime');
	showsetting(plang('dtiezicategory'),'tiezicategoryid','','<select name="tiezicategoryid">'.$categoryidselect.'</select>','',0,plang('dtiezicategory_msg'),1,'dtiezicategory');
	
	
	
	showsetting(plang('dtiezisort'),'sort','1','text','','',plang('dtiezisort_msg'));
	showsetting(plang('dtiezistatus'),'status','1','radio','','',plang('dtiezistatus_msg'));

	showsubmit('submit', 'submit');
	showtablefooter(); /*Dism��taobao��com*/
	showformfooter(); /*Dism_taobao_com*/
	
	
	dexit();
}elseif($act=='delete'){
	$id = dintval($_GET['id']);
	$setting = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->fetch($id);
	if(empty($setting))
		cpmsg('jzsjiale_daogou:empty', '', 'error');
	if(submitcheck('submit')){
		C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->delete($id);
		recache();
		cpmsg('jzsjiale_daogou:delok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi', 'succeed');
	}
	cpmsg('jzsjiale_daogou:deltiezi','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&act=delete&id='.$id.'&submit=yes','form',array('title' => $setting['title']));
}elseif($act=='edit'){
	$id = dintval($_GET['id']);
	$setting = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->fetch($id);
	if(empty($setting))
		cpmsg('jzsjiale_daogou:empty', '', 'error');
	if(submitcheck('submit')){
	    
	    $tz = $_GET['tz'];
	    $dsp = array('dateline'=>TIMESTAMP);
	    $dsp['tiezicategoryid'] = daddslashes(trim($tz['tiezicategoryid']));
	    $dsp['sort'] = daddslashes(trim($tz['sort']));
	    $dsp['status'] = daddslashes(trim($tz['status']));
	    
	    if(empty($dsp['sort']) && $dsp['sort'] != '0'){
	        cpmsg('jzsjiale_daogou:dtiezisort_msgnull', '', 'error');
	    }
	    
	    if(empty($dsp['tiezicategoryid']) || $dsp['tiezicategoryid'] == 0){
	        cpmsg('jzsjiale_daogou:dtiezicategory_msgnull', '', 'error');
	    }
	    
	    if(C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->update($id,$dsp)){
	        recache();
	        cpmsg('jzsjiale_daogou:editok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi', 'succeed');
	    }else{
	        cpmsg('jzsjiale_daogou:error', '', 'error');
	    }
	}
	
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&act=edit', 'enctype');
	showsubmit('submit', 'submit');
	
	echo'<input type="hidden" value="'.dhtmlspecialchars($setting['id']).'" name="id"/>';
	showtableheader(plang('edittiezi').':<span style="color:red;">'.dhtmlspecialchars($setting['title']).'&nbsp;&nbsp;&nbsp;&nbsp;tid:'.dhtmlspecialchars($setting['tid']).'</span>', '');
	
	
	$categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid(0,1);
	$categoryidselect = '<option value="0">'.plang('qingxuanze').'</option>';
	foreach($categoryids as $k =>$v){
	    $categoryidselect .= '<option value="'.$v['id'].'" '.($setting['tiezicategoryid'] == $v['id']?'selected':'').'>'.$v['title'].'</option>';
	
	    $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($v['id'],1);
	
	    foreach($subcategoryids as $subk =>$subv){
	        $categoryidselect .= '<option value="'.$subv['id'].'" '.($setting['tiezicategoryid'] == $subv['id']?'selected':'').'>&nbsp;&nbsp;&nbsp;&nbsp;'.$subv['title'].'</option>';
	
	        $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($subv['id'],1);
	         
	        foreach($sub3categoryids as $sub3k =>$sub3v){
	            $categoryidselect .= '<option value="'.$sub3v['id'].'" '.($setting['tiezicategoryid'] == $sub3v['id']?'selected':'').'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sub3v['title'].'</option>';
	             
	        }
	    }
	}
	showsetting(plang('dtiezicategory'),'tz[tiezicategoryid]','','<select name="tz[tiezicategoryid]">'.$categoryidselect.'</select>','',0,plang('dtiezicategory_msg'),1,'dtiezicategory');
	
	
	
	showsetting(plang('dtiezisort'),'tz[sort]',dhtmlspecialchars($setting['sort']),'text','','',plang('dtiezisort_msg'));
	showsetting(plang('dtiezistatus'),'tz[status]',dhtmlspecialchars($setting['status']),'radio','','',plang('dtiezistatus_msg'));
	
	showsubmit('submit', 'submit');
	showtablefooter(); /*Dism��taobao��com*/
	showformfooter(); /*Dism_taobao_com*/
	
	
	dexit();
}elseif($formhash == FORMHASH && $act=='zhiding'){
	$id = dintval($_GET['id']);
	$setting = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->fetch($id);
	if(empty($setting)){
	    cpmsg('jzsjiale_daogou:empty', '', 'error');
	}else{
	    C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->zhiding($id,TIMESTAMP);
	    recache();
	    cpmsg('jzsjiale_daogou:editok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi', 'succeed');
	    
	}
	
}elseif($formhash == FORMHASH && $act=='quxiaozhiding'){
	$id = dintval($_GET['id']);
	$setting = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->fetch($id);
	if(empty($setting)){
	    cpmsg('jzsjiale_daogou:empty', '', 'error');
	}else{
	    C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->quxiaozhiding($id);
	    recache();
	    cpmsg('jzsjiale_daogou:editok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi', 'succeed');
	   
	}
	
}elseif($act=='cache'){
    
            $daogoutiezi = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->getall();
      
            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_tiezi', getcachevars(array('daogoutiezi' => $daogoutiezi)));
        
            if(count($daogoutiezi) > 0){
                cpmsg('jzsjiale_daogou:cache_success', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi', 'succeed');
            }else{
                cpmsg('jzsjiale_daogou:cache_error', '', 'error');
            }
            
        
        dexit();
}


loadcache('plugin');

echo '<div class="colorbox"><h4>'.plang('abouttiezi').'</h4>'.
    '<table cellspacing="0" cellpadding="3"><tr>'.
    '<td valign="top">'.plang('tiezidescription').'</td></tr></table>'.
    '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';


if(!submitcheck('tzsubmit')) {

    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi', 'enctype');
    
    $title = daddslashes(trim($_GET['title']));
    $tiezicategoryid = daddslashes(trim($_GET['tiezicategoryid']));
    
$page = intval($_GET['page']);
$page = $page > 0 ? $page : 1;
$pagesize = 20;
$start = ($page - 1) * $pagesize;


if(empty($tiezicategoryid)){
    $alltiezi = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->range_by_title($title,$start,$pagesize,'sort ASC,dateline DESC,id DESC');
    $count = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->count_by_title($title);
}else{
    $alltiezi = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->range_by_tiezicategoryid($tiezicategoryid,$start,$pagesize,'sort ASC,dateline DESC,id DESC');
    $count = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->count_by_tiezicategoryid($tiezicategoryid);
}

$category = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->getall();
$utils = new Utils();
showtableheader(plang('tiezilist').'(  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&act=add" style="color:red;">'.plang('addtiezi').'</a>  |  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&act=addpiliang" style="color:red;">'.plang('addtiezipiliang').'</a>  |  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&act=cache" style="color:red;">'.plang('cachetiezi').'</a>)', '');
showsubtitle(plang('tiezititle'));

foreach($alltiezi as $d){
	showtablerow('', array('width="50"'), array(
	'<input class="checkbox" type="checkbox" name="delete[]" value="'.$d['id'].'">'.$d['id'],
	'<span title="'.$d['title'].'"><a href="forum.php?mod=viewthread&tid='.$d['tid'].'" target="_blank">'.mb_substr($d['title'],0,20).'</a></span>',
	'<span title="'.$d['tid'].'"><a href="forum.php?mod=viewthread&tid='.$d['tid'].'" target="_blank">'.$d['tid'].'</a></span>',
	'<span>'.$utils->searchArray($category,'id',$d['tiezicategoryid'],'title').'</span>',
	'<span title="'.$d['uid'].'"><a href="home.php?mod=space&uid='.$d['uid'].'&do=profile" target="_blank">'.$d['uid'].'</a></span>',
	'<span title="'.($d['status']?plang('yes'):plang('no')).'">'.($d['status']?'<span style="color:green;">'.plang('yes').'</span>':'<span style="color:red;">'.plang('no').'</span>').'</span>',
	'<span title="'.($d['sort']==0?plang('yes'):plang('no')).'">'.($d['sort']==0?'<span style="color:green;">'.plang('yes').'</span>':'').'</span>',
	'<span title="'.$d['sort'].'">'.mb_substr($d['sort'],0,20).'</span>',
	dgmdate($d['dateline']),
	'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&act=zhiding&id='.$d['id'].'&formhash='.FORMHASH.'" style="color:red;">'.plang('zhiding').'</a>&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&act=quxiaozhiding&id='.$d['id'].'&formhash='.FORMHASH.'" style="color:red;">'.plang('quxiaozhiding').'</a>&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&act=edit&id='.$d['id'].'" >'.plang('edit').'</a>&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&act=delete&id='.$d['id'].'">'.plang('delete').'</a>')
	);
}


$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&title='.$title.'&tiezicategoryid='.$tiezicategoryid;
$multipage = multi($count, $pagesize, $page, $mpurl);
//showsubmit('', '', '', '', $multipage);


//search start
showsubmit('tzsubmit', 'submit', 'del', plang('allcount').$count, $multipage.'
<input type="text" class="txt" name="title" value="'.(dhtmlspecialchars($title)?dhtmlspecialchars($title):plang('defaulttitle')).'" size="15" onkeyup="if(event.keyCode == 13) this.form.searchsubmit.click()" onclick="this.value=\'\'">&nbsp;&nbsp;
<input type="button" class="btn" name="searchsubmit" value="'.plang('searchtitle').'" onclick="if(this.form.title.value==\''.plang('defaulttitle').'\'){this.form.title.value=\'\'}location.href=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&title=\'+this.form.title.value;"> &nbsp;
		');

//search end

showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/

}else {

    if($_GET['delete']) {
        C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->delete(dhtmlspecialchars($_GET['delete']));
    }
    recache();
    cpmsg('jzsjiale_daogou:delok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi', 'succeed');


}

function plang($str) {
	return lang('plugin/jzsjiale_daogou', $str);
}

function recache() {
    $daogoutiezi = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->getall();
    
    require_once libfile('function/cache');
    writetocache('jzsjiale_daogou_tiezi', getcachevars(array('daogoutiezi' => $daogoutiezi)));

}
//From: Dism��taobao��com
?>