<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = daddslashes(trim($_GET['act']));
$act = !empty($act)?$act:'caiji';

$formhash =  $_GET['formhash']? $_GET['formhash']:'';
global $_G, $lang;
$_config = $_G['cache']['plugin']['jzsjiale_daogou'];
require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';
$utils = new Utils();

loadcache('plugin');

echo '<div class="colorbox"><h4>'.plang('aboutcontent').'</h4>'.
    '<table cellspacing="0" cellpadding="3"><tr>'.
    '<td valign="top">'.plang('contentdescription').'</td></tr></table>'.
    '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';


/////////erjidaohang start
echo '<br/><div style="border-bottom:2px solid #6AC3F6;padding-bottom:5px;">'
    .'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=base" target="_self" style="color:red;"><strong>'.plang('contentmenu1').'</strong></a>'
    .'&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=caiji" target="_self"><strong>'.plang('contentmenu2').'</strong></a>'
    .'&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=log" target="_self"><strong>'.plang('contentmenu3').'</strong></a>'
    .'</div><br/>';

if($act == 'base'){
    if(!submitcheck('settingsubmit')) {
        $setting = C::t('common_setting')->fetch_all(array('jdg_content_base'));
        $setting = (array)unserialize($setting['jdg_content_base']);


        showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=base', 'enctype');

        showtableheader(plang('content_base_settings_title'), '', 'id="base_settings"');

        //showsetting(plang('content_base_isopendarenshuo'),'setting[isopendarenshuo]',$setting["isopendarenshuo"],'radio','','',plang('content_base_isopendarenshuo_msg'));
        showsetting(plang('content_base_hdk_appkey'),'setting[hdk_appkey]',$setting["hdk_appkey"],'text','','',plang('content_base_hdk_appkey_msg'));

        $autosaveselect = '<option value="0" '.((empty($setting['autosave']) || $setting['autosave']=='0')?'selected':'').'>'.plang('qingxuanze').'</option>';
        loadcache(array('forums'));
        if(empty($_G['cache']['forums'])) $_G['cache']['forums'] = array();
        foreach($_G['cache']['forums'] as $fid => $forum) {
            $autosaveselect .= '<option value="'.$fid.'" '.($setting['autosave']==$fid?'selected':'').'>'.($forum['type'] == 'forum' ? str_repeat('&nbsp;', 4) : ($forum['type'] == 'sub' ? str_repeat('&nbsp;', 8) : '')).$forum['name'].'</option>';
        }
        showsetting(plang('content_base_autosave'),'setting[autosave]','','<select name="setting[autosave]">'.$autosaveselect.'</select>','','',plang('content_base_autosave_msg'));

        $categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid(0,1);
        $autorecommendselect = '<option value="0" '.((empty($setting['autorecommend']) || $setting['autorecommend']=='0')?'selected':'').'>'.plang('content_caiji_autorecommend_no').'</option>';
        foreach($categoryids as $k =>$v){
            $autorecommendselect .= '<option value="'.$v['id'].'" '.($setting['autorecommend']==$v['id']?'selected':'').'>'.$v['title'].'</option>';

            $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($v['id'],1);

            foreach($subcategoryids as $subk =>$subv){
                $autorecommendselect .= '<option value="'.$subv['id'].'" '.($setting['autorecommend']==$subv['id']?'selected':'').'>&nbsp;&nbsp;&nbsp;&nbsp;'.$subv['title'].'</option>';

                $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($subv['id'],1);

                foreach($sub3categoryids as $sub3k =>$sub3v){
                    $autorecommendselect .= '<option value="'.$sub3v['id'].'" '.($setting['autorecommend']==$sub3v['id']?'selected':'').'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$sub3v['title'].'</option>';

                }
            }
        }
        showsetting(plang('content_base_autorecommend'),'setting[autorecommend]','','<select name="setting[autorecommend]">'.$autorecommendselect.'</select>','','',plang('content_base_autorecommend_msg'));


        showtablefooter(); /*Dism��taobao��com*/

        showsubmit('settingsubmit', 'submit');

        showformfooter(); /*Dism_taobao_com*/
    }else{
        $setting = $_GET['setting'];
        $settings = array('jdg_content_base' => serialize($setting));
        C::t('common_setting')->update_batch($settings);

        updatecache('setting');

        cpmsg(plang('setting_update_succeed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=base', 'succeed');

    }
}elseif($act == 'caiji'){

    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=caijiprocess', 'enctype');

    showtableheader(plang('content_caiji_settings_title'), '', 'id="caiji_settings"');

    $contenttypeselect = '<option value="hdkdrs" '.((empty($contenttype) || $contenttype=='hdkdrs')?'selected':'').'>'.plang('contenttype')['hdkdrs'].'</option>';
    //$contenttypeselect .= '<option value="1">'.plang('menu_cdn_1').'</option>';
    showsetting(plang('content_caiji_contenttype'),'contenttype','','<select name="contenttype">'.$contenttypeselect.'</select>','','',plang('content_caiji_contenttype_msg'));
    showsetting(plang('content_caiji_contentid'),'id',$id,'text','','',plang('content_caiji_contentid_msg'));


    showtablefooter(); /*Dism��taobao��com*/

    showsubmit('caijiprocesssubmit', 'submit');

    showformfooter(); /*Dism_taobao_com*/
}elseif($act == 'caijiprocess'){

    if(submitcheck('caijiprocesssubmit')){
        $contenttype = daddslashes(trim($_GET['contenttype']));
        $id = daddslashes(trim($_GET['id']));
        $contenttype = !empty($contenttype)?$contenttype:'wz';

        $jdg_content_base = (array)unserialize($_G['setting']['jdg_content_base']);
        if(empty($jdg_content_base)){
            cpmsg(plang('setting_base_null'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=base', 'error');
        }

        if(empty($jdg_content_base['autosave']) || $jdg_content_base['autosave'] == '0'){
            cpmsg(plang('content_caiji_autosave_null'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=base', 'error');
        }


        $caijiurl = "";
        switch ($contenttype){
            case "hdkdrs":
                if(empty($jdg_content_base['hdk_appkey'])){
                    cpmsg(plang('setting_base_null'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=base', 'error');
                }else{
                    $caijiurl = "http://v2.api.haodanku.com/talent_article/apikey/".$jdg_content_base['hdk_appkey']."/id/";
                }
                break;
            default:
                cpmsg(plang('setting_select_contenttype'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=caiji', 'error');
                break;
        }

        if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/httpcurl.php')){
            @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/httpcurl.php';
        }else{
            cpmsg(plang('wuxiaoqingqiu'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=caiji', 'error');
        }

        $url = $caijiurl . $id;

        $httpcurl = new HttpCurl();
        $closessl = $_config['g_closessl'] ? 1 : 0;

        $content = $httpcurl->hcurl($url,null, '',0,$closessl);
        $result = json_decode($content,true);

        if(!empty($result) && $result['code'] == '1' && !empty($result['data']) && !empty($result['data']['name']) && !empty($result['data']['article'])){
            if ($_G['charset'] == "gbk") {
                $contentid = diconv($result['data']['id'], 'UTF-8','GBK');
                $subject = diconv($result['data']['name'], 'UTF-8','GBK');
                $message = diconv($result['data']['article'], 'UTF-8','GBK');
                if(!empty($result['data']['app_image'])){
                    $cover_url = diconv($result['data']['app_image'], 'UTF-8','GBK');
                }elseif(!empty($result['data']['article_banner'])){
                    $cover_url = diconv($result['data']['article_banner'], 'UTF-8','GBK');
                }elseif(!empty($result['data']['compose_image'])){
                    $cover_url = diconv($result['data']['compose_image'], 'UTF-8','GBK');
                }else{
                    $cover_url = "";
                }

            }else{
                $contentid = $result['data']['id'];
                $subject = $result['data']['name'];
                $message = $result['data']['article'];
                if(!empty($result['data']['app_image'])){
                    $cover_url = $result['data']['app_image'];
                }elseif(!empty($result['data']['article_banner'])){
                    $cover_url = $result['data']['article_banner'];
                }elseif(!empty($result['data']['compose_image'])){
                    $cover_url = $result['data']['compose_image'];
                }else{
                    $cover_url = "";
                }
            }
            $fid = $jdg_content_base['autosave'];
            $modthread = C::m('forum_thread', $fid);
            $modthread->param = array();

            $_G['group']['disablepostctrl'] = 1;

            $bfmethods = $afmethods = array();
            $message = html_entity_decode($message, ENT_COMPAT, $_G['charset']);

            $doc = new DOMDocument();
            $doc->formatOutput = true;
            $doc->loadHTML('<meta http-equiv=Content-Type content="text/html;charset='.$_G['charset'].'">'.$message);//mb_convert_encoding($message, 'HTML-ENTITIES', $_G['charset']));
            $finder = new DomXPath($doc);
            $nodes = $finder->query("//*[contains(@class, 'js_tobuy')]");

            foreach ($nodes as $node)
            {
                while($node->hasChildNodes())
                {
                    $node->removeChild($node->lastChild);
                }

            }
            $message = $doc->saveHTML();

            $rulespan = '/\s?<span(\s*)style="([^"]*)"(\s*)>\s?/is';
            $message = preg_replace($rulespan, '<span>', $message);

            $rule = '/\s?<div(\s*)class="([^"\']*)js_tobuy([^"\']*)"(\s*)id="itemid([0-9]\d*)">(.*?)<\/div>\s?/is';

            $message = preg_replace_callback(
                $rule,
                function($ms){
                    return "[jzsjiale_guanjianci]https://item.taobao.com/item.htm?id=".$ms[5].",=1[/jzsjiale_guanjianci]";
                },
                $message
            );

            $params = array(
                'subject' => $subject,
                'message' => $message,
                'typeid' => 0,
                'sortid' => 0,
                'special' => 0,
                'closed' => 0,
                'bbcodeoff' => 0,
                'htmlon' => 1,
                'save' => 0,
                'usesig' => 0,
                'allownoticeauthor' => 0,
                'cover' => 1,
                'publishdate' => $_G['timestamp'],
                //'displayorder' => -4,
            );

            $acriclevalue = array();
            $articletid = "";
            $articlepid = "";

            $savereturn = $modthread->newthread($params);
            $acriclevalue['id'] = $modthread->tid;
            $acriclevalue['pid'] = $modthread->pid;

            $articletid = $modthread->tid;
            $articlepid = $modthread->pid;


            if(!empty($cover_url)){
                $imgtmp=@file_get_contents($cover_url);
                if(!$imgtmp){
                    return;
                }else{
                    $imgtype="jpg";
                    $threadcoverdir = DISCUZ_ROOT.'./data/attachment/forum/threadcover/'.substr(md5($articletid),0,2).'/'.substr(md5($articletid),2,2).'/';
                    @mkdir($threadcoverdir,0777,true);
                    $filename = $articletid.'.'.$imgtype;
                    $threadcover = $threadcoverdir.$filename;
                    @unlink($threadcover);
                    $ret=file_put_contents($threadcover,$imgtmp);

                    if(!$ret || !file_exists($threadcover)){
                        return;
                    }
                    $remote = 0;
                    DB::insert('forum_threadimage',array('tid'=>$articletid,'attachment'=>'threadcover/'.substr(md5($articletid),0,2).'/'.substr(md5($articletid),2,2).'/'.$articletid.'.'.$imgtype,'remote' => $remote));

                    $thumbpath = "";
                    $thumbpath=DB::result_first("select thumbpath from ".DB::table('common_block_item')." where id='".$articletid."' and makethumb=1 order by itemid desc");
                    if($thumbpath){
                        @unlink(DISCUZ_ROOT.'./data/attachment/'.$thumbpath);
                        DB::update('common_block_item',array('makethumb'=>0,'thumbpath'=>'','pic'=>'forum/threadcover/'.substr(md5($articletid),0,2).'/'.substr(md5($articletid),2,2).'/'.$articletid.'.'.$imgtype),array('id'=>$articletid));
                    }
                }
            }

            $logdata = array(
                'title' => $subject,
                'contentid' => $contentid,
                'source' => $contenttype,
                'tid' => $articletid,
                'remark' => "",
                'status' => 1,
                'dateline' => TIMESTAMP
            );

            C::t('#jzsjiale_daogou#jzsjiale_daogou_content')->insert($logdata, true);


            if(!empty($jdg_content_base['autorecommend']) && $jdg_content_base['autorecommend'] != "0"){

                $tiezidata = array(
                    'title' => $subject,
                    'tid' => $articletid,
                    'tiezicategoryid' => $jdg_content_base['autorecommend'],
                    'sort' => 1,
                    'status' => 1,
                    'dateline' => TIMESTAMP
                );

                C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->insert($tiezidata, true);
            }


            header("Content-Type: text/html; charset=".$_G['charset']);
            if(!empty($jdg_content_base['autorecommend']) && $jdg_content_base['autorecommend'] != "0"){
                cpmsg(plang('content_caiji_success_cache'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=tiezi&act=cache', 'succeed');
            }else{
                cpmsg(plang('content_caiji_success'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=caiji', 'succeed');
            }

        }else{
            header("Content-Type: text/html; charset=".$_G['charset']);
            cpmsg(plang('content_caiji_error'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=caiji', 'error');
        }
    }else{
        cpmsg(plang('wuxiaoqingqiu'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=caiji', 'error');
    }

}elseif($act == 'log'){
    if(!submitcheck('contentsubmit')) {

        showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=log', 'enctype');

        $title = daddslashes(trim($_GET['title']));

        $page = intval($_GET['page']);
        $page = $page > 0 ? $page : 1;
        $pagesize = 20;
        $start = ($page - 1) * $pagesize;


        $allcontent = C::t('#jzsjiale_daogou#jzsjiale_daogou_content')->range_by_title($title,$start,$pagesize,'dateline DESC,id DESC');
        $count = C::t('#jzsjiale_daogou#jzsjiale_daogou_content')->count_by_title($title);


        showtableheader(plang('content_log_list').'(  <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=clearlog" style="color:red;">'.plang('clearlog').'</a> )', '');
        showsubtitle(plang('content_log_title'));

        foreach($allcontent as $d){
            showtablerow('', array('width="50"'), array(
                    '<input class="checkbox" type="checkbox" name="delete[]" value="'.$d['id'].'">'.$d['id'],
                    '<span title="'.$d['title'].'">'.mb_substr($d['title'],0,60).'</span>',
                    '<span title="'.$d['contentid'].'">'.$d['contentid'].'</span>',
                    '<span title="'.$d['tid'].'"><a href="forum.php?mod=viewthread&tid='.$d['tid'].'" target="_blank">'.$d['tid'].'</a></span>',
                    '<span>'.$utils->getcontentname($d['source']).'</span>',
                    '<span title="'.($d['status']?plang('yes'):plang('no')).'">'.($d['status']?'<span style="color:green;">'.plang('yes').'</span>':'<span style="color:red;">'.plang('no').'</span>').'</span>',
                    '<span title="'.$d['remark'].'">'.mb_substr($d['remark'],0,60).'</span>',
                    dgmdate($d['dateline']))
            );
        }


        $mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=log&title='.$title;
        $multipage = multi($count, $pagesize, $page, $mpurl);
//showsubmit('', '', '', '', $multipage);


//search start
        showsubmit('contentsubmit', 'submit', 'del', plang('allcount').$count, $multipage.'
<input type="text" class="txt" name="title" value="'.(dhtmlspecialchars($title)?dhtmlspecialchars($title):plang('defaulttitle')).'" size="15" onkeyup="if(event.keyCode == 13) this.form.searchsubmit.click()" onclick="this.value=\'\'">&nbsp;&nbsp;
<input type="button" class="btn" name="searchsubmit" value="'.plang('searchtitle').'" onclick="if(this.form.title.value==\''.plang('defaulttitle').'\'){this.form.title.value=\'\'}location.href=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=log&title=\'+this.form.title.value;"> &nbsp;
		');

//search end

        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/

    }else {

        if($_GET['delete']) {
            C::t('#jzsjiale_daogou#jzsjiale_daogou_content')->delete(dhtmlspecialchars($_GET['delete']));
        }
        recache();
        cpmsg('jzsjiale_daogou:delok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=log', 'succeed');


    }
}elseif($act == 'clearlog'){
    if(submitcheck('submit')){
        C::t('#jzsjiale_daogou#jzsjiale_daogou_content')->delallcontent();
        cpmsg('jzsjiale_daogou:clearlogok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=log', 'succeed');
    }
    cpmsg('jzsjiale_daogou:isclearlog','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_daogou&pmod=content&act=clearlog&submit=yes','form');

}


function plang($str) {
	return lang('plugin/jzsjiale_daogou', $str);
}
//From: dis'.'m.tao'.'bao.com
?>