<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';
$utils = new Utils();

global $_G, $postlist, $lang;
$_config = $_G['cache']['plugin']['jzsjiale_daogou'];
if(!in_array ( "article", (array)unserialize($_config['g_alone']) )){
    showmessage(lang('plugin/jzsjiale_daogou','function_closed'), $_G['siteurl']);
}

$tid = $_GET['tid'];
if (empty($tid)) {
    if ($_G[jzsjiale_tpl_daogou][isopendg] && $_G[jzsjiale_tpl_daogou][weijingtaimokuai]) {
        return dheader('Location: index.html');
    } elseif ($_G[jzsjiale_tpl_daogou][isopendg] && ! $_G[jzsjiale_tpl_daogou][weijingtaimokuai]) {
        return dheader('Location: plugin.php?id=jzsjiale_daogou:daogou');
    } else {
        return dheader('Location: plugin.php?id=jzsjiale_daogou:daogou');
    }
}


$g_isopenzhtglj = $_config['g_isopenzhtglj'];
$g_taodianjincode = "";
if($_config['g_isopenzhtglj']){
    $g_taodianjincode = $_config['g_taodianjincode'];
}
$g_dulixiewenzhang = $_config['g_dulixiewenzhang'];

$g_isopenyuancheng = $_config['g_isopenyuancheng'];
$g_yuanchengurl = $_config['g_yuanchengurl'];

/*
$topic = get_thread_by_tid($tid);

$topicarticle = C::t('forum_post')->fetch_threadpost_by_tid_invisible($tid);
*/

$posttable = getposttablebytid($tid);
$thread = C::t('forum_thread')->fetch($tid);
if(empty($thread)){
    header('HTTP/1.1 404 Not Found');
    header('status: 404 Not Found');
    header('Location: '.$_G['siteurl']);
    dexit(); 
}
//view +1
viewthread_updateviews($_G['forum_thread']['threadtableid'],$tid);

$thread = array_merge($thread, C::t('forum_post')->fetch_threadpost_by_tid_invisible($tid));
if ($thread && ($thread['invisible'] != -3 || $_G['uid'] == $thread['authorid'] || in_array($_G['uid'],array(1)))) {
    $article['title'] = $thread['subject'];
    $thread['message'] = portalcp_get_postmessage($thread, 0);
    $article['summary'] = portalcp_get_summary_my($thread['message']);
    $article['fromurl'] = 'forum.php?mod=viewthread&tid=' . $thread['tid'];
    $article['author'] = $thread['author'];
    $article['authorid'] = $thread['authorid'];
    $article['views'] = $thread['views'];
    $article['replies'] = $thread['replies'];
    //$article['message'] = dhtmlspecialchars($thread['message']);
    $article['message'] = $thread['message'];
    $article['fid'] = $thread['fid'];
    $article['pid'] = $thread['pid'];
    $article['invisible'] = $thread['invisible'];
    
    $article['attach_image'] = $article['attach_file'] = '';
    foreach (C::t('forum_attachment_n')->fetch_all_by_id('tid:' . $thread['tid'], 'pid', $thread['pid'], 'aid DESC') as $attach) {
        $attachcode = '[attach]' . $attach['aid'] . '[/attach]';
        if (! strexists($article['message'], $attachcode)) {
            $article['message'] .= '<br /><br />' . $attachcode;
        }
        if ($attach['isimage']) {
            if ($article['pic']) {
                $attach['pic'] = $article['pic'];
            }
        } else {}
        $attach['from'] = 'forum';
        $attachs[] = $attach;
    }
    
    if(!empty($article['dateline'])) {
        $article['dateline'] = dgmdate($article['dateline']);
    }
    
    if(!empty($attachs)) {
        $article['attachs'] = get_upload_content($attachs);
    }
    
    $aids = array();
    $article['tid'] = $tid;
    if($thread['attachment']) {
        $_G['group']['allowgetimage'] = 1;
        if(preg_match_all("/\[attach\](\d+)\[\/attach\]/i", $article['message'], $matchaids)) {
            $aids = $matchaids[1];
        }
    }
    
    if($aids) {
        parseforumattach($article, $aids);
    }
   
    $article['message'] = replacemessage($article['message']);
    
    
    $article['message'] = htmlspecialchars_decode($article['message'] , ENT_QUOTES);
    
    //--tuijian start

    $tuijianpc = false;
    $tuijianmobile = false;
    $categoryidselect = "";
    if ($_config['g_tuijianpc'] && !empty($_G['uid']) && in_array ( $_G['groupid'], (array)unserialize($_config['g_tuijianpcgroup']) )) {
         $tuijianpc = true;
    }
    if ($_config['g_tuijianmobile'] && !empty($_G['uid']) && in_array ( $_G['groupid'], (array)unserialize($_config['g_tuijianmobilegroup']) )) {
        $tuijianmobile = true;
    }
    if($tuijianpc || $tuijianmobile){
        $categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid(0, 1);
        $categoryidselect = '<option value="0">' . lang('plugin/jzsjiale_daogou', 'qingxuanze') . '</option>';
        foreach ($categoryids as $k => $v) {
            $categoryidselect .= '<option value="' . $v['id'] . '">' . $v['title'] . '</option>';
        
            $subcategoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($v['id'], 1);
        
            foreach ($subcategoryids as $subk => $subv) {
                $categoryidselect .= '<option value="' . $subv['id'] . '">&nbsp;&nbsp;&nbsp;&nbsp;' . $subv['title'] . '</option>';
        
                $sub3categoryids = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezicategory')->gettiezicategory_by_pid($subv['id'], 1);
        
                foreach ($sub3categoryids as $sub3k => $sub3v) {
                    $categoryidselect .= '<option value="' . $sub3v['id'] . '">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $sub3v['title'] . '</option>';
                }
            }
        }
    }
    //--tuijian end


    $cover_tmp=getCover($tid);
    $pic=$cover_tmp['attachment'];
    $isremote=$cover_tmp['remote'];
    if(!empty($pic)){
        if($g_isopenyuancheng && !empty($g_yuanchengurl) && $isremote){
            $article['articlecover'] =$g_yuanchengurl.'/forum/'.$pic;
        }else{
            $article['articlecover'] = $_G['siteurl'].'data/attachment/forum/'.$pic;
        }
    
    }


    if ($_config['g_autotuijian']) {
        if ($_G[jzsjiale_tpl_daogou][autotuijian]) {
            $autotuijianlll = intval($_G[jzsjiale_tpl_daogou][autotuijianlll]);
            if($thread['views'] >= $autotuijianlll){
                $yanzhengtuijian = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->get_by_tidandcategoryid($thread['tid'],$_G[jzsjiale_tpl_daogou][autotuijian]);
                if(empty($yanzhengtuijian)){
                    DB::insert('jzsjiale_daogou_tiezi', array(
                        'dateline' => TIMESTAMP,
                        'title' => $thread['subject'],
                        'tid' => $thread['tid'],
                        'tiezicategoryid' => $_G[jzsjiale_tpl_daogou][autotuijian],
                        'uid' => 1,
                        'status' => 1,
                        'sort' => 1
                    ));
                    $daogoutiezi = C::t('#jzsjiale_daogou#jzsjiale_daogou_tiezi')->getall();

                    require_once libfile('function/cache');
                    writetocache('jzsjiale_daogou_tiezi', getcachevars(array('daogoutiezi' => $daogoutiezi)));
                }
            }
        }
    }
   
    
}else{
    $article['message'] = plang('weifabu');
}


include template('jzsjiale_daogou:daogou/v'.$_G[jzsjiale_tpl_daogou][daogoustyle].'/article');
//----end---

//----function start-----
function portalcp_get_postmessage($post, $getauthorall = '') {
    global $_G;
    $post['message'] = my_parsesmiles($post['message']);
    
    $forum = C::t('forum_forum')->fetch($post['fid']);
    require_once libfile('function/discuzcode');
    $language = lang('forum/misc');
    if($forum['type'] == 'sub' && $forum['status'] == 3) {
        loadcache('grouplevels');
        $grouplevel = $_G['grouplevels'][$forum['level']];
        $group_postpolicy = $grouplevel['postpolicy'];
        if(is_array($group_postpolicy)) {
            $forum = array_merge($forum, $group_postpolicy);
        }
    }
    $post['message'] = preg_replace($language['post_edit_regexp'], '', $post['message']);
    
    $_message = '';
    if($getauthorall) {
        foreach(C::t('forum_post')->fetch_all_by_tid('tid:'.$post['tid'], $post['tid'], true, '', 0, 0, null, null, $post['authorid']) as $value){
            if(!$value['first']) {
                $value['message'] = preg_replace("/\s?\[quote\][\n\r]*(.+?)[\n\r]*\[\/quote\]\s?/is", '', $value['message']);
                $value['message'] = discuzcode($value['message'], $value['smileyoff'], $value['bbcodeoff'], $value['htmlon'] & 1, $forum['allowsmilies'], $forum['allowbbcode'], ($forum['allowimgcode'] && $_G['setting']['showimages'] ? 1 : 0), $forum['allowhtml'], 0, 0, $value['authorid'], $forum['allowmediacode'], $value['pid']);
                portalcp_parse_postattch($value);
                $_message .= '<br /><br />'.$value['message'];
            }
        }
    }
    
    $msglower = strtolower($post['message']);

    if(!$_G['cache']['plugin']['jzsjiale_video']){
        if(strpos($msglower, '[/media]') !== FALSE) {
            $post['message'] = preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is", "", $post['message']);
        }
    }


    if(strpos($msglower, '[/audio]') !== FALSE) {
        $post['message'] = preg_replace("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/is", "", $post['message']);
    }
    
    if(strpos($msglower, '[/flash]') !== FALSE) {
        $post['message'] = preg_replace("/\[flash(=(\d+),(\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/is", "", $post['message']);
    }
    /*
    if(strpos($msglower, '[/media]') !== FALSE) {
        $post['message'] = preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/ies", "parsearticlemedia('\\1', '\\2')", $post['message']);
    }
    if(strpos($msglower, '[/audio]') !== FALSE) {
        $post['message'] = preg_replace("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/ies", "parsearticlemedia('mid,0,0', '\\2')", $post['message']);
    }
    
    if(strpos($msglower, '[/flash]') !== FALSE) {
        $post['message'] = preg_replace("/\[flash(=(\d+),(\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/ies", "parsearticlemedia('swf,0,0', '\\4');", $post['message']);
    }
    */
    $post['message'] = discuzcode($post['message'], $post['smileyoff'], $post['bbcodeoff'], $post['htmlon'] & 1, $forum['allowsmilies'], $forum['allowbbcode'], ($forum['allowimgcode'] && $_G['setting']['showimages'] ? 1 : 0), $forum['allowhtml'], 0, 0, $post['authorid'], $forum['allowmediacode'], $post['pid']);
    portalcp_parse_postattch($post);
    
    if(strpos($post['message'], '[/flash1]') !== FALSE) {
        $post['message'] = str_replace('[/flash1]', '[/flash]', $post['message']);
    }
    
    $message = $post['message'].$_message;
    
    $message = replacemessage($message);
    return $message;
}
function portalcp_parse_postattch(&$post) {
    static $allpostattchs = null;
    if($allpostattchs === null) {
        foreach(C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$post['tid'], 'tid', $post['tid']) as $attch) {
            $allpostattchs[$attch['pid']][$attch['aid']] = $attch['aid'];
        }
    }
    $attachs = $allpostattchs[$post['pid']];
    if(preg_match_all("/\[attach\](\d+)\[\/attach\]/i", $post['message'], $matchaids)) {
        $attachs = array_diff($allpostattchs[$post['pid']], $matchaids[1]);
    }
    if($attachs) {
        $add = '';
        foreach($attachs as $attachid) {
            $add .= '<br/>'.'[attach]'.$attachid.'[/attach]';
        }
        $post['message'] .= $add;
    }
}
function get_upload_content($attachs, $dotype='') {
    $html = '';
    $dotype = $dotype ? 'checked' : '';
    $i = 0;
    foreach($attachs as $key => $attach) {
        $type = $attach['from'] == 'forum' ? 'forum' : 'portal';
        $html .= '<td id="attach_list_'.$attach['attachid'].'">';
        if($attach['isimage']) {
            $pic = pic_get($attach['attachment'], $type, $attach['thumb'], $attach['remote'], 0);
            $small_pic = $attach['thumb'] ? getimgthumbname($pic) : '';
            $check = $attach['pic'] == $type.'/'.$attach['attachment'] ? 'checked' : $dotype;
            $aid = $check ? $attach['aid'] : '';

            $html .= '<a href="javascript:;" class="opattach">';
            $html .= '<span class="opattach_ctrl">';
            $html .= '<span onclick="insertImage(\''.$pic.'\');" class="cur1">'.lang('portalcp', 'insert_large_image').'</span><span class="pipe">|</span>';
            if($small_pic) $html .= '<span onclick="insertImage(\''.$small_pic.'\', \''.$pic.'\');" class="cur1">'.lang('portalcp', 'small_image').'</span>';
            $html .= '</span><img src="'.($small_pic ? $small_pic : $pic).'" onclick="insertImage(\''.$pic.'\');" class="cur1" /></a>';
            $html .= '<label for="setconver'.$attach['attachid'].'" class="cur1 xi2"><input type="radio" name="setconver" id="setconver'.$attach['attachid'].'" class="pr" value="1" onclick=setConver(\''.addslashes(serialize(array('pic'=>$type.'/'.$attach['attachment'], 'thumb'=>$attach['thumb'], 'remote'=>$attach['remote']))).'\') '.$check.'>'.lang('portalcp', 'set_to_conver').'</label>';
            if($type == 'portal') {
                $html .= '<span class="pipe">|</span><span class="cur1 xi2" onclick="deleteAttach(\''.$attach['attachid'].'\', \'portal.php?mod=attachment&id='.$attach['attachid'].'&aid='.$aid.'&op=delete\');">'.lang('portalcp', 'delete').'</span>';
            }
        } else {
            $html .= '<img src="static/image/editor/editor_file_thumb.png" class="cur1" onclick="insertFile(\''.$attach['filename'].'\', \'portal.php?mod=attachment&id='.$attach['attachid'].'\');" tip="'.$attach['filename'].'" onmouseover="showTip(this);" /><br/>';
            $html .= '<span onclick="deleteAttach(\''.$attach['attachid'].'\', \'portal.php?mod=attachment&id='.$attach['attachid'].'&op=delete\');" class="cur1 xi2">'.lang('portalcp', 'delete').'</span>';
        }
        $html .= '</td>';
        $i++;

        if($i % 4 == 0 && isset($attachs[$i])) {
            $html .= '</tr><tr>';
        }
    }
    if(!empty($html)) {
        if(($imgpad = $i % 4) > 0) {
            $html .= str_repeat('<td width="25%"></td>', 4 - $imgpad);
        }

        $html = '<table class="imgl"><tr>'.$html.'</tr></table>';
    }
    return $html;
}

function pic_get($filepath, $type, $thumb, $remote, $return_thumb=1, $hastype = '') {
    global $_G;

    $url = $filepath;
    if($return_thumb && $thumb) $url = getimgthumbname($url);
    if($remote > 1 && $type == 'album') {
        $remote -= 2;
        $type = 'forum';
    }
    $type = $hastype ? '' : $type.'/';
    return ($remote?$_G['setting']['ftp']['attachurl']:$_G['setting']['attachurl']).$type.$url;
}
function parseforumattach(&$post, $aids) {
    global $_G;
    if(($aids = array_unique($aids))) {
        require_once libfile('function/attachment');
        $finds = $replaces = array();
        foreach(C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$post['tid'], 'aid', $aids) as $attach) {

            $attach['url'] = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/';
            $attach['dateline'] = dgmdate($attach['dateline'], 'u');
            $extension = strtolower(fileext($attach['filename']));
            $attach['ext'] = $extension;
            $attach['imgalt'] = $attach['isimage'] ? strip_tags(str_replace('"', '\"', $attach['description'] ? $attach['description'] : $attach['filename'])) : '';
            $attach['attachicon'] = attachtype($extension."\t".$attach['filetype']);
            $attach['attachsize'] = sizecount($attach['filesize']);

            $attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
            $aidencode = packaids($attach);
            $widthcode = attachwidth($attach['width']);
            $is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G['forum_thread']['archiveid'] : '';
            if($attach['isimage']) {
                $attachthumb = getimgthumbname($attach['attachment']);
                if($_G['setting']['thumbstatus'] && $attach['thumb']) {
                    $replaces[$attach['aid']] = "<a href=\"javascript:;\"><img id=\"_aimg_$attach[aid]\" aid=\"$attach[aid]\" 
                        src=\"".($attach['refcheck'] ? "forum.php?mod=attachment{$is_archive}&aid=$aidencode" : $attach['url'].$attachthumb)."\" alt=\"$attach[imgalt]\" title=\"$attach[imgalt]\" w=\"$attach[width]\" /></a>";
                    } else {
                    $replaces[$attach['aid']] = "<img id=\"_aimg_$attach[aid]\" aid=\"$attach[aid]\"
                    src=\"".($attach['refcheck'] ? "forum.php?mod=attachment{$is_archive}&aid=$aidencode&noupdate=yes " : $attach['url'].$attach['attachment'])."\" $widthcode alt=\"$attach[imgalt]\" title=\"$attach[imgalt]\" w=\"$attach[width]\" />";
                    }
                    } else {
                    $replaces[$attach['aid']] = "$attach[attachicon]<a href=\"forum.php?mod=attachment{$is_archive}&aid=$aidencode\" onmouseover=\"showMenu({'ctrlid':this.id,'pos':'12'})\" id=\"aid$attach[aid]\" target=\"_blank\">$attach[filename]</a>";
                    }
			$finds[$attach['aid']] = '[attach]'.$attach['aid'].'[/attach]';
		}
		if($finds && $replaces) {
			$post['message'] = str_ireplace($finds, $replaces, $post['message']);
		}
	}
}
//viewthread_updateviews($_G['forum_thread']['threadtableid']);
function viewthread_updateviews($tableid,$tid) {
    global $_G;

    if(!$_G['setting']['preventrefresh'] || $_G['cookie']['viewid'] != 'tid_'.$tid) {
        if(!$tableid && $_G['setting']['optimizeviews']) {
            if($_G['forum_thread']['addviews']) {
                if($_G['forum_thread']['addviews'] < 100) {
                    C::t('forum_threadaddviews')->update_by_tid($tid);
                } else {
                    if(!discuz_process::islocked('update_thread_view')) {
                        $row = C::t('forum_threadaddviews')->fetch($tid);
                        C::t('forum_threadaddviews')->update($tid, array('addviews' => 0));
                        C::t('forum_thread')->increase($tid, array('views' => $row['addviews']+1), true);
                        discuz_process::unlock('update_thread_view');
                    }
                }
            } else {
                C::t('forum_threadaddviews')->insert(array('tid' => $tid, 'addviews' => 1), false, true);
            }
        } else {
            C::t('forum_thread')->increase($tid, array('views' => 1), true, $tableid);
        }
    }
    dsetcookie('viewid', 'tid_'.$tid);
}

function replacemessage($message){
    
    if(strpos($message, 'onmouseover="img_onmouseoverfunc(this)"') !== FALSE) {
        $message = str_replace('onmouseover="img_onmouseoverfunc(this)"', '', $message);
    }
    if(strpos($message, 'onload="thumbImg(this)"') !== FALSE) {
        $message = str_replace('onload="thumbImg(this)"', '',$message);
    }
    
    if(strpos($message, 'onclick="zoom(') !== FALSE) {
        $message = preg_replace('/onclick="zoom\(this,(.*?)this.src,(.*?)(-?[0-9]\d*),(.*?)(-?[0-9]\d*),(.*?)(-?[0-9]\d*)\)"/is', "",$message);
    }
    if(strpos($message, '[free]') !== FALSE) {
        $message = preg_replace('/\[free\](.*?)\[\/free\]/i', "",$message);
    }
    return $message;
}
function getCover($tid){
    $pic=DB::fetch_first("SELECT attachment,remote FROM ".DB::table('forum_threadimage')." where tid='$tid'");
    if(empty($pic) || $pic == null){
        $pic=DB::fetch_first("SELECT attachment,remote FROM ".DB::table('forum_attachment_'.($tid%10))." where tid='$tid' and isimage=1");
    }
    return $pic;
}
function my_parsesmiles(&$message) {
    global $_G;
    loadcache(array('bbcodes', 'smilies', 'smileytypes'));
    static $enablesmiles;
    if($enablesmiles === null) {
        $enablesmiles = false;
        if(!empty($_G['cache']['smilies']) && is_array($_G['cache']['smilies'])) {
            foreach($_G['cache']['smilies']['replacearray'] AS $key => $smiley) {
                $_G['cache']['smilies']['replacearray'][$key] = '<img src="'.STATICURL.'image/smiley/'.$_G['cache']['smileytypes'][$_G['cache']['smilies']['typearray'][$key]]['directory'].'/'.$smiley.'" smilieid="'.$key.'" style="width:auto;display:inline;" border="0" alt="" />';
            }
            $enablesmiles = true;
        }
    }
    $enablesmiles && $message = preg_replace($_G['cache']['smilies']['searcharray'], $_G['cache']['smilies']['replacearray'], $message, $_G['setting']['maxsmilies']);
    return $message;
}
function portalcp_get_summary_my($message) {
    $message = preg_replace(array("/\[attach\].*?\[\/attach\]/", "/\&[a-z]+\;/i", "/\<script.*?\<\/script\>/"), '', $message);
    $message = preg_replace("/\[.*?\]/", '', $message);
    $message = strip_tags($message);
    $message = mb_substr($message,0,200);
    return $message;
}
function plang($str)
{
    return lang('plugin/jzsjiale_daogou', $str);
}
//From: Dism��taobao��com
?>