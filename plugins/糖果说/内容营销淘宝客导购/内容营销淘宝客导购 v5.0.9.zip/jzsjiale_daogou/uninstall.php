<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;
$result = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getall();
foreach($result as $dr){
    if(!empty($dr['attach'])){
        @unlink($_G['setting']['attachdir'].'common/'.$dr['attach']);
    }
}
$result = C::t('#jzsjiale_daogou#jzsjiale_daogou_huandengpian')->getall();
foreach($result as $dr){
    if(!empty($dr['attach'])){
        @unlink($_G['setting']['attachdir'].'common/'.$dr['attach']);
    }
}
$category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();
$sql = <<<EOF
DROP TABLE IF EXISTS `pre_jzsjiale_daogou_shangpin`;
DROP TABLE IF EXISTS `pre_jzsjiale_daogou_category`;
DROP TABLE IF EXISTS `pre_jzsjiale_daogou_tiezicategory`;
DROP TABLE IF EXISTS `pre_jzsjiale_daogou_huandengpian`;
DROP TABLE IF EXISTS `pre_jzsjiale_daogou_tiezi`;
DROP TABLE IF EXISTS `pre_jzsjiale_daogou_daogou`;
DROP TABLE IF EXISTS `pre_jzsjiale_daogou_content`;

DELETE FROM `pre_common_nav` WHERE url like '%plugin.php?id=jzsjiale_daogou:faxian%' ;
DELETE FROM `pre_common_nav` WHERE url like '%plugin.php?id=jzsjiale_daogou:haowu%' ;
DELETE FROM `pre_common_nav` WHERE url like '%plugin.php?id=jzsjiale_daogou:xiewenzhang%' ;
DELETE FROM `pre_common_nav` WHERE url like '%plugin.php?id=jzsjiale_daogou:souquan%' ;
DELETE FROM `pre_common_nav` WHERE url like '%forum.php?daogou%' ;
EOF;

runquery($sql);

require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::delAPIHook('jzsjiale_daogou');

C::t('common_setting')->delete('jdaogou_xuanpin_bind');
C::t('common_setting')->delete('jdg_content_base');
updatecache('setting');

foreach ($category as $key => $value){
    if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php')){
        @unlink(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$value["id"].'.php');
    }
}
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php')){
    @unlink(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin.php');
}
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
    @unlink(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php');
}
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezicategory.php')){
    @unlink(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezicategory.php');
}
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_huandengpian.php')){
    @unlink(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_huandengpian.php');
}
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezi.php')){
    @unlink(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_tiezi.php');
}
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_daogou.php')){
    @unlink(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_daogou.php');
}
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_yhqshangpin.php')){
    @unlink(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_yhqshangpin.php');
}
if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_cjssshangpin.php')){
    @unlink(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_cjssshangpin.php');
}
$finish = TRUE;