<?php

/**
 * model
 * @author auto create
 */
class ContentEffectPageDto
{
	
	/** 
	 * contentEffectList
	 **/
	public $content_effect_list;	
}
//From: dis'.'m.t'.'ao'.'bao.com
?>