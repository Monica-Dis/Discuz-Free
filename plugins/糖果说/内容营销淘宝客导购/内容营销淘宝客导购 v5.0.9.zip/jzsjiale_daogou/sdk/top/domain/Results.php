<?php

/**
 * data
 * @author auto create
 */
class Results
{
	
	/** 
	 * data
	 **/
	public $data;	
}
//From: dis'.'m.t'.'ao'.'bao.com
?>