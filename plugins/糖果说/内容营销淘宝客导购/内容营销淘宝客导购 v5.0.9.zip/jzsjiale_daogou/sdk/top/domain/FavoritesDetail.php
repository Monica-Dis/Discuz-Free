<?php

/**
 * 选品库详细信息
 * @author auto create
 */
class FavoritesDetail
{
	
	/** 
	 * 选品库id
	 **/
	public $favorites_id;
	
	/** 
	 * 选品库标题
	 **/
	public $favorites_title;	
}
//From: dis'.'m.t'.'ao'.'bao.com
?>