<?php

/**
 * 清单列表
 * @author auto create
 */
class WishInfo
{
	
	/** 
	 * 清单商品
	 **/
	public $item_id_list;
	
	/** 
	 * 清单id
	 **/
	public $wish_list_id;
	
	/** 
	 * 清单链接
	 **/
	public $wish_list_url;	
}
//From: dis'.'m.t'.'ao'.'bao.com
?>