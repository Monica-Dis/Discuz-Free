<?php

/**
 * model
 * @author auto create
 */
class RightsInstanceCreateResult
{
	
	/** 
	 * 淘礼金Id
	 **/
	public $rights_id;
	
	/** 
	 * 淘礼金领取Url
	 **/
	public $send_url;
	
	/** 
	 * 投放code
	 **/
	public $vegas_code;	
}
//From: dis'.'m.t'.'ao'.'bao.com
?>