<?php

/**
 * 接口返回model
 * @author auto create
 */
class Result
{
	
	/** 
	 * model
	 **/
	public $model;
	
	/** 
	 * msgCode
	 **/
	public $msg_code;
	
	/** 
	 * msgInfo
	 **/
	public $msg_info;
	
	/** 
	 * 是否成功
	 **/
	public $success;	
}
//From: dis'.'m.t'.'ao'.'bao.com
?>