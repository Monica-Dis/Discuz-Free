<?php

/**
 * 埋点信息
 * @author auto create
 */
class Trackparams
{
	
	/** 
	 * empty
	 **/
	public $empty;	
}
//From: dis'.'m.t'.'ao'.'bao.com
?>