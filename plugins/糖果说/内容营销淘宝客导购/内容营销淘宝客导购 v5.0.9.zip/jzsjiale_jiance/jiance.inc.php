<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';

loadcache('plugin');
global $_G, $lang;


$step = max(1, intval($_GET['step']));
showsubmenusteps(plang('jiancetitle'), array(
    array(plang('step1title'), $step == 1),
    array(plang('step2title'), $step == 2),
    array(plang('step3title'), $step == 3)
));

if($step == 1) {
    cpmsg(plang('jiance_tips_step1'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_jiance&pmod=jiance&step=2', 'button', '', FALSE);
} elseif($step == 2) {
    
    $_configdaogou = $_G['cache']['plugin']['jzsjiale_daogou'];
    $tbappkey = $_configdaogou['g_appkey'];
    $tbsecretKey = $_configdaogou['g_appsecret'];
    $webbianma = $_G['charset'];
    
    $_config = $_G['cache']['plugin']['jzsjiale_jiance'];
    $g_chulifangshi = $_config['g_chulifangshi'];
    
    if(empty($tbappkey) || empty($tbsecretKey)){
        cpmsg('jzsjiale_jiance:jiancenoappkey', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_jiance&pmod=jiance&step=1', 'error'); 
    }
    
    $gtkl = new GetTbAPI();
    $gtkl->__construct($tbappkey, $tbsecretKey);
    
    
    $pertask = dintval(daddslashes(trim($_GET['pertask'])))?dintval(daddslashes(trim($_GET['pertask']))):40;
    $next = dintval(daddslashes(trim($_GET['next'])));
    if($next){
        $current = $next;
    }else{
        $current = 0;
    }
    $nextcurrent = $current + ($pertask-1);
    $next = $nextcurrent+1;
    $nextlink = 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_jiance&pmod=jiance&next='.$next.'&pertask='.$pertask.'&step=2';
    
    $count = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->count();
    $qdsp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->range($current,$pertask,'DESC');
    
    $chaxunnumiids = array();
    foreach ($qdsp as $spdata){
        if(!empty($spdata['numiid']) && (strpos($spdata['url'], "taobao.com") !== false || strpos($spdata['url'], "tmall.com") !== false)){
            $chaxunnumiids[] = $spdata['numiid'];
        }
        
    }
    $numiids = implode(',',$chaxunnumiids);
    
    $tbinfo = $gtkl->gettbinfo($numiids);
    
    $tbinfo = json_decode($tbinfo);
    $tbinfo = $tbinfo->results->n_tbk_item;
    
    $jieguonumiids = array();
    foreach ($tbinfo as $tbinfodata){
            //echo diconv(dhtmlspecialchars($tbinfodata->num_iid),'UTF-8','GB2312').'---'.diconv(dhtmlspecialchars($tbinfodata->title),'UTF-8','GB2312').'---'.diconv(dhtmlspecialchars($tbinfodata->item_url),'UTF-8','GB2312').'=============================';
        $jieguonumiids[] = $tbinfodata->num_iid;
    }
    //bijiao
    foreach ($qdsp as $spdata){
        if(!in_array($spdata['numiid'], $jieguonumiids) && !empty($spdata['numiid']) && (strpos($spdata['url'], "taobao.com") !== false || strpos($spdata['url'], "tmall.com") !== false)){
            //$g_chulifangshi 1/shanchu,2/biaoji
            if($g_chulifangshi == 1){
                C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->delete($spdata['id']);
            }elseif($g_chulifangshi == 2){
                $dsp = array();
                $dsp['flag'] = 1;
                C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->update($spdata['id'],$dsp);
            }
        }
    }
 
    if($current < $count-1){
        recache();
        cpmsg(plang('curr_jiance').cplang('counter_processing', array('current' => ($current+1), 'next' => ($nextcurrent+1))), $nextlink, 'loading',array('count' => $count));
    }else{
        recache();
        cpmsg('jzsjiale_jiance:jianceok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_jiance&pmod=jiance&step=3', 'succeed');
    }
    
} elseif($step == 3) {
    cpmsg('jzsjiale_jiance:jianceok', '', '', '', FALSE);
}



function recache(){

    $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

    foreach ($category as $key => $value){

        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1,$value["id"]);

        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));
    }

}
function plang($str)
{
    return lang('plugin/jzsjiale_jiance', $str);
}
//From: Dism��taobao��com
?>