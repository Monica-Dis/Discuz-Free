<?php
/**
 *	[淘宝客商品过期检测(jzsjiale_jiance.cron_jzsjiale_jiance)] (C)2017-2099 Powered by jzsjiale.
 *	Version: 1.0.0
 *	Date: 2017-7-1 14:46
 *	Warning: Don't delete this comment
 *
 *	cronname:jzsjiale_jiance
 *	week:
 *	day:
 *	hour:1
 *	minute:
 *	desc:
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';

loadcache('plugin');
global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_jiance'];
$g_openauto = $_config['g_openauto'];
$g_chulifangshi = $_config['g_chulifangshi'];

if(!$g_openauto){
    return;
}

$_configdaogou = $_G['cache']['plugin']['jzsjiale_daogou'];
$tbappkey = $_configdaogou['g_appkey'];
$tbsecretKey = $_configdaogou['g_appsecret'];
$webbianma = $_G['charset'];

if(empty($tbappkey) || empty($tbsecretKey)){
   return;
}

$gtkl = new GetTbAPI();
$gtkl->__construct($tbappkey, $tbsecretKey);

$qdsp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getall();

$chaxunnumiids = array();
$jieguonumiids = array();
foreach ($qdsp as $spdata){
    
    if(!empty($spdata['numiid']) && (strpos($spdata['url'], "taobao.com") !== false || strpos($spdata['url'], "tmall.com") !== false)){
        $chaxunnumiids[] = $spdata['numiid'];
    }
    
    if(count($chaxunnumiids) == 40){
        
        $numiids = implode(',',$chaxunnumiids);
        
        $tbinfo = $gtkl->gettbinfo($numiids);
        
        $tbinfo = json_decode($tbinfo);
        $tbinfo = $tbinfo->results->n_tbk_item;
        
        
        foreach ($tbinfo as $tbinfodata){
            //echo diconv(dhtmlspecialchars($tbinfodata->num_iid),'UTF-8','GB2312').'---'.diconv(dhtmlspecialchars($tbinfodata->title),'UTF-8','GB2312').'---'.diconv(dhtmlspecialchars($tbinfodata->item_url),'UTF-8','GB2312').'=============================';
            $jieguonumiids[] = $tbinfodata->num_iid;
        }
        //bijiao
        
        
        $chaxunnumiids = array();
    }
}


foreach ($qdsp as $spdata){
    if(!in_array($spdata['numiid'], $jieguonumiids) && !empty($spdata['numiid']) && (strpos($spdata['url'], "taobao.com") !== false || strpos($spdata['url'], "tmall.com") !== false)){
        //$g_chulifangshi 1/shanchu,2/biaoji
        if($g_chulifangshi == 1){
            C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->delete($spdata['id']);
        }elseif($g_chulifangshi == 2){
            $dsp = array();
            $dsp['flag'] = 1;
            C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->update($spdata['id'],$dsp);
        }
    }
}

recache();
function recache(){
    $category = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getallidusedcache();

    foreach ($category as $key => $value){

        $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1,$value["id"]);

        require_once libfile('function/cache');
        writetocache('jzsjiale_daogou_shangpin_'.$value["id"], getcachevars(array('tbkshangpin_'.$value["id"] => $shangpin_cache_tmp)));
    }
}
//TODO - Insert your code here
?>
