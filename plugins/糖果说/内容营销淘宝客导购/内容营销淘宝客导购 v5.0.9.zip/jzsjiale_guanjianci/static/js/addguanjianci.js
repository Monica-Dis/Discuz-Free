function addguanjianci(cmd) {
	checkFocus();
	showEditorMenuGuanjianci(cmd,'');
	return;
}

function Trim(str)
{ 
    return str.replace(/(^\s*)|(\s*$)/g, ""); 
}


function IsNum(str) {
	if (str.length != 0) {
		reg = /^[1-9]\d*$/;
		if (!reg.test(str)) {
			return false;
		}else{
			return true;
		}
	}
}     


function showhidexiangguanshuomingguanjianci() {
	var xiangguanshuomingguanjianci = document.getElementById("xiangguanshuomingguanjianci");
	if (xiangguanshuomingguanjianci) {
		if (xiangguanshuomingguanjianci.style.display == "block") {
			xiangguanshuomingguanjianci.style.display = "none";
		} else {
			xiangguanshuomingguanjianci.style.display = "block";
		}
	}
}



function showEditorMenuGuanjianci(tag, params) {
	var sel, selection;
	var str = '', strdialog = 0, stitle = '';
	var ctrlid = editorid + (params ? '_cst' + params + '_' : '_') + tag;
	
	var menu = $(ctrlid + '_menu');
	var pos = [0, 0];
	var menuwidth = 270;
	var menupos = '43!';
	var menutype = 'menu';

	if(BROWSER.ie) {
		sel = wysiwyg ? editdoc.selection.createRange() : document.selection.createRange();
		pos = getCaret();
	}

	selection = sel ? (wysiwyg ? sel.htmlText : sel.text) : getSel();


	stitle = '\u4f7f\u7528\u5173\u952e\u8bcd\u5339\u914d\u690d\u5165\u5546\u54c1';
	
	str = '';
	str += '<p class="pbn"><span style="color:red;">------------------------------------------------------------</span></p>';
	str += '<p class="pbn">\u5173\u952e\u8bcd:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" id="' + ctrlid + '_param_1" class="px" value="" style="width: 220px;" /></p>';
	str += '<p class="pbn">\u690d\u5165\u5546\u54c1\u4e2a\u6570:&nbsp;&nbsp;&nbsp;<input type="text" id="' + ctrlid + '_param_2" class="px" value="1" style="width: 220px;" /></p>';
	str += '<p class="pbn">\u76f8\u5173\u8bf4\u660e:<button type="button" id="showhidebuttonguanjianci" onClick="javascript:showhidexiangguanshuomingguanjianci();">\u70b9\u51fb\u8fd9\u91cc\u9690\u85cf\u002f\u663e\u793a\u76f8\u5173\u8bf4\u660e</button></p>';
	str += '<p class="xg2 pbn" id="xiangguanshuomingguanjianci" style="display:block;">1:\u4f7f\u7528\u672c\u529f\u80fd\u521b\u5efa\u5173\u952e\u8bcd\u8282\u70b9\u002c\u5bf9\u5e94\u8282\u70b9\u4f1a\u6839\u636e\u8bbe\u7f6e\u7684\u5173\u952e\u8bcd\u81ea\u52a8\u968f\u673a\u83b7\u53d6\u76f8\u5173\u5546\u54c1;<br/><span style="color:red;">2:\u53ef\u8bbe\u7f6e\u591a\u4e2a\u5173\u952e\u8bcd\u002c\u591a\u4e2a\u5173\u952e\u8bcd\u7528\u82f1\u6587\u9017\u53f7\u5206\u9694;</span><br/>3:\u5982\u679c\u8bbe\u7f6e\u591a\u4e2a\u5173\u952e\u8bcd\u002c\u4e5f\u4f1a\u6839\u636e\u8bbe\u7f6e\u7684\u663e\u793a\u5546\u54c1\u4e2a\u6570\u002c\u968f\u673a\u4f7f\u7528\u5173\u952e\u8bcd;<br/>4:\u5173\u952e\u8bcd\u8d8a\u591a\u002c\u538b\u529b\u8d8a\u5927\u002c\u8bf7\u77e5\u6653\u0021</p>';
	
	
	
	s = '<style type="text/css">'
	+'.jzsjialegjccss input,.pbn {font:12px/1.5 Tahoma,Helvetica,"SimSun",sans-serif !important;}'
	+'.jzsjialegjccss input {line-height:17px !important;height:17px !important;padding:4px !important;}'
	+'.jzsjialegjccss p{max-width:364px !important;}'
	+'.jzsjialegjccss div.c{max-width:384px !important;padding:0 10px !important;}'
	+'.jzsjialegjccss h3.flb{max-width:364px !important;padding:10px 10px 8px !important;}'
	+'.jzsjialegjccss td.m_c{max-width:364px !important;padding:0px!important;}'
	+'.jzsjialegjccss .pbn select{height:30px !important;padding:0px!important;}'
	+'</style>';



	menuwidth = 400;//600
	menupos = '00';
	menutype = 'win';

	var menu = document.createElement('div');
	menu.id = ctrlid + '_menu';
	menu.style.display = 'none';
	menu.className = 'p_pof upf';
	menu.style.width = menuwidth + 'px';
	if(menupos == '00') {
			menu.className = 'fwinmask jzsjialegjccss';
			s += '<table width="100%" cellpadding="0" cellspacing="0" class="fwin"><tr><td class="t_l"></td><td class="t_c"></td><td class="t_r"></td></tr><tr><td class="m_l">&nbsp;&nbsp;</td><td class="m_c">'
				+ '<h3 class="flb"><em>' + stitle + '</em><span><a onclick="hideMenu(\''+ctrlid + '_menu\', \'win\');return false;" class="flbc" href="javascript:;">\u5173\u95ed</a></span></h3><div class="c">' + str + '</div>'
				+ '<p class="o pns"><button type="submit" id="' + ctrlid + '_submit" class="pn pnc"><strong>\u63d0\u4ea4</strong></button></p>'
				+ '</td><td class="m_r"></td></tr><tr><td class="b_l"></td><td class="b_c"></td><td class="b_r"></td></tr></table>';
		} else {
			s += '<div class="p_opt cl"><span class="y" style="margin:-10px -10px 0 0"><a onclick="hideMenu();return false;" class="flbc" href="javascript:;">\u5173\u95ed</a></span><div>' + str + '</div><div class="pns mtn"><button type="submit" id="' + ctrlid + '_submit" class="pn pnc"><strong>\u63d0\u4ea4</strong></button></div></div>';
		}
	menu.innerHTML = s;
	$(editorid + '_editortoolbar').appendChild(menu);
	showMenu({'ctrlid':ctrlid,'mtype':menutype,'evt':'click','duration':3,'cache':0,'drag':1,'pos':menupos});

	try {
		if($(ctrlid + '_param_1')) {
			$(ctrlid + '_param_1').focus();
		}
	} catch(e) {}
	var objs = menu.getElementsByTagName('*');
	for(var i = 0; i < objs.length; i++) {
		_attachEvent(objs[i], 'keydown', function(e) {
			e = e ? e : event;
			obj = BROWSER.ie ? event.srcElement : e.target;
			if((obj.type == 'text' && e.keyCode == 13) || (obj.type == 'textarea' && e.ctrlKey && e.keyCode == 13)) {
				if($(ctrlid + '_submit') && tag != 'image') $(ctrlid + '_submit').click();
				doane(e);
			} else if(e.keyCode == 27) {
				hideMenu();
				doane(e);
			}
		});
	}
	if($(ctrlid + '_submit')) $(ctrlid + '_submit').onclick = function() {
		checkFocus();
		switch(tag) {
			case 'jzsjiale_guanjianci':
				var gjctitle = Trim($(ctrlid + '_param_1').value);
				var gjcnum = Trim($(ctrlid + '_param_2').value);

				if(gjctitle == ""){
					alert("\u8bf7\u8f93\u5165\u5173\u952e\u8bcd\u0021");
					break;
				}
				
				if(!IsNum(gjcnum)){
					alert("\u5546\u54c1\u690d\u5165\u4e2a\u6570\u5fc5\u987b\u662f\u5927\u4e8e\u96f6\u4e14\u4e0d\u5927\u4e8e\u0031\u0030\u0030\u7684\u6b63\u6574\u6570\u0021");
					return;
				}
				if(gjcnum <= 0 || gjcnum > 100){
					alert("\u5546\u54c1\u690d\u5165\u4e2a\u6570\u5fc5\u987b\u662f\u5927\u4e8e\u96f6\u4e14\u4e0d\u5927\u4e8e\u0031\u0030\u0030\u7684\u6b63\u6574\u6570\u0021");
					return;
				}
				if(gjcnum == ""){
					gjcnum = 1;
				}
				
				str = squarestrip(gjctitle)+",="+squarestrip(gjcnum);

				var opentag = '[' + tag + ']';
				var closetag = '[/' + tag + ']';
				
				str = opentag + str + closetag;
				insertText(str, strlen(opentag), strlen(closetag), false, sel);
				
				hideMenu('', 'win');
				hideMenu();
				
				break;
			
			default:
				
				break;
		}
		
	};
	
		
}