<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/utils.class.php';

class mobileplugin_jzsjiale_guanjianci {
    var $count = 0;

    function getshangpin($gjc_gjctitle,$gjc_gjcnum)
    {
        global $_G;
        $_config_gjc = $_G['cache']['plugin']['jzsjiale_guanjianci'];

        $dsp = array();
        $dsp['q'] = daddslashes(trim($gjc_gjctitle));
        $dsp['sort'] = $_config_gjc['sort']?$_config_gjc['sort']:"total_sales_des";
        $dsp['has_coupon'] = $_config_gjc['has_coupon'];
        $dsp['is_tmall'] = $_config_gjc['is_tmall'];
        $dsp['is_overseas'] = $_config_gjc['is_overseas'];
        $dsp['need_free_shipment'] = $_config_gjc['need_free_shipment'];
        $dsp['need_prepay'] = $_config_gjc['need_prepay'];
        /*
        $dsp['include_pay_rate_30'] = 1;
        $dsp['include_good_rate'] = 1;
        $dsp['include_rfd_rate'] = 1;
        */
        $dsp['page_size'] = ($gjc_gjcnum*10<100)?($gjc_gjcnum*10):100;
        $dsp['currpage'] = '1';

        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $tbappkey = $_config['g_appkey'];
        $tbsecretKey = $_config['g_appsecret'];
        $pid = $_config['g_pid'];
        $webbianma = $_G['charset'];

        if(empty($pid)){
            return array();
        }

        $dzoneId = explode("_",$pid);
        $dzoneId = $dzoneId[3];

        if(empty($dzoneId)){
            return array();
        }

        require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';
        $gtkl = new GetTbAPI;
        $gtkl->__construct($tbappkey, $tbsecretKey);
        $tbinfo =  $gtkl->getdgmaterialoptional($dsp,$dzoneId,$webbianma);

        $tbinfo = json_decode($tbinfo);

        $splistinfo = $tbinfo->result_list->map_data;

        return $splistinfo;
    }

    function gettemplate($spi)
    {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $_config_gjc = $_G['cache']['plugin']['jzsjiale_guanjianci'];

        $webbianma = $_G['charset'];

        if($webbianma == 'gbk') {
            $coupon_start_time = diconv($spi->coupon_start_time,'UTF-8','GBK');
            $coupon_end_time = diconv($spi->coupon_end_time,'UTF-8','GBK');
            //$info_dxjh = diconv($spi->info_dxjh,'UTF-8','GBK');
            $tk_total_sales = diconv($spi->tk_total_sales,'UTF-8','GBK');
            //$tk_total_commi = diconv($spi->tk_total_commi,'UTF-8','GBK');
            //$coupon_id = diconv($spi->coupon_id,'UTF-8','GBK');
            //$num_iid = diconv($spi->num_iid,'UTF-8','GBK');
            $title = diconv($spi->title,'UTF-8','GBK');
            $pict_url = diconv($spi->pict_url,'UTF-8','GBK');
            //$small_images = diconv($spi->small_images,'UTF-8','GBK');
            $reserve_price = diconv($spi->reserve_price,'UTF-8','GBK');
            $zk_final_price = diconv($spi->zk_final_price,'UTF-8','GBK');
            $user_type = diconv($spi->user_type,'UTF-8','GBK');
            $provcity = diconv($spi->provcity,'UTF-8','GBK');
            $item_url = diconv($spi->item_url,'UTF-8','GBK');
            //$include_mkt = diconv($spi->include_mkt,'UTF-8','GBK');
            //$include_dxjh = diconv($spi->include_dxjh,'UTF-8','GBK');
            $commission_rate = diconv($spi->commission_rate,'UTF-8','GBK');
            $volume = diconv($spi->volume,'UTF-8','GBK');
            //$seller_id = diconv($spi->seller_id,'UTF-8','GBK');
            $coupon_total_count = diconv($spi->coupon_total_count,'UTF-8','GBK');
            $coupon_remain_count = diconv($spi->coupon_remain_count,'UTF-8','GBK');
            $coupon_info = diconv($spi->coupon_info,'UTF-8','GBK');
            //$commission_type = diconv($spi->commission_type,'UTF-8','GBK');
            $shop_title = diconv($spi->shop_title,'UTF-8','GBK');
            $shop_dsr = diconv($spi->shop_dsr,'UTF-8','GBK');
            $coupon_share_url = diconv($spi->coupon_share_url,'UTF-8','GBK');
            $url = diconv($spi->url,'UTF-8','GBK');
            /*
            $level_one_category_name = diconv($spi->level_one_category_name,'UTF-8','GBK');
            $level_one_category_id = diconv($spi->level_one_category_id,'UTF-8','GBK');
            $category_name = diconv($spi->category_name,'UTF-8','GBK');
            $category_id = diconv($spi->category_id,'UTF-8','GBK');
            $short_title = diconv($spi->short_title,'UTF-8','GBK');
            $white_image = diconv($spi->white_image,'UTF-8','GBK');
            $oetime = diconv($spi->oetime,'UTF-8','GBK');
            $ostime = diconv($spi->ostime,'UTF-8','GBK');
            $jdd_num = diconv($spi->jdd_num,'UTF-8','GBK');
            $jdd_price = diconv($spi->jdd_price,'UTF-8','GBK');
            $uv_sum_pre_sale = diconv($spi->uv_sum_pre_sale,'UTF-8','GBK');
            $x_id = diconv($spi->x_id,'UTF-8','GBK');
            */
            $coupon_start_fee = diconv($spi->coupon_start_fee,'UTF-8','GBK');
            $coupon_amount = diconv($spi->coupon_amount,'UTF-8','GBK');
            //$item_description = diconv($spi->item_description,'UTF-8','GBK');
            $nick = diconv($spi->nick,'UTF-8','GBK');
            /*
            $orig_price = diconv($spi->orig_price,'UTF-8','GBK');
            $total_stock = diconv($spi->total_stock,'UTF-8','GBK');
            $sell_num = diconv($spi->sell_num,'UTF-8','GBK');
            $stock = diconv($spi->stock,'UTF-8','GBK');
            $tmall_play_activity_info = diconv($spi->tmall_play_activity_info,'UTF-8','GBK');
            */
            $item_id = diconv($spi->item_id,'UTF-8','GBK');
            $real_post_fee = diconv($spi->real_post_fee,'UTF-8','GBK');
        }else{
            $coupon_start_time = $spi->coupon_start_time;
            $coupon_end_time = $spi->coupon_end_time;
            //$info_dxjh = $spi->info_dxjh;
            $tk_total_sales = $spi->tk_total_sales;
            //$tk_total_commi = $spi->tk_total_commi;
            //$coupon_id = $spi->coupon_id;
            //$num_iid = $spi->num_iid;
            $title = $spi->title;
            $pict_url = $spi->pict_url;
            //$small_images = $spi->small_images;
            $reserve_price = $spi->reserve_price;
            $zk_final_price = $spi->zk_final_price;
            $user_type = $spi->user_type;
            $provcity = $spi->provcity;
            $item_url = $spi->item_url;
            //$include_mkt = $spi->include_mkt;
            //$include_dxjh = $spi->include_dxjh;
            $commission_rate = $spi->commission_rate;
            $volume = $spi->volume;
            //$seller_id = $spi->seller_id;
            $coupon_total_count = $spi->coupon_total_count;
            $coupon_remain_count = $spi->coupon_remain_count;
            $coupon_info = $spi->coupon_info;
            //$commission_type = $spi->commission_type;
            $shop_title = $spi->shop_title;
            $shop_dsr = $spi->shop_dsr;
            $coupon_share_url = $spi->coupon_share_url;
            $url = $spi->url;
            /*
            $level_one_category_name = $spi->level_one_category_name;
            $level_one_category_id = $spi->level_one_category_id;
            $category_name = $spi->category_name;
            $category_id = $spi->category_id;
            $short_title = $spi->short_title;
            $white_image = $spi->white_image;
            $oetime = $spi->oetime;
            $ostime = $spi->ostime;
            $jdd_num = $spi->jdd_num;
            $jdd_price = $spi->jdd_price;
            $uv_sum_pre_sale = $spi->uv_sum_pre_sale;
            $x_id = $spi->x_id);
            */
            $coupon_start_fee = $spi->coupon_start_fee;
            $coupon_amount = $spi->coupon_amount;
            //$item_description = $spi->item_description;
            $nick = $spi->nick;
            /*
            $orig_price = $spi->orig_price;
            $total_stock = $spi->total_stock;
            $sell_num = $spi->sell_num;
            $stock = $spi->stock;
            $tmall_play_activity_info = $spi->tmall_play_activity_info;
            */
            $item_id = $spi->item_id;
            $real_post_fee = $spi->real_post_fee;
        }


        $tbk_title = $title;
        $tbk_imgurl = $pict_url;
        $tbk_url = !empty($url)?$url:(!empty($coupon_share_url)?$coupon_share_url:$item_url);
        $tbk_url = ((!empty($tbk_url) && strpos($tbk_url,'http') ===false)?'https:':'').$tbk_url;
        $tbk_yuanjia = $reserve_price;
        $tbk_xianjia = $zk_final_price;

        //tiqu  youhuijiage
        if(!empty($coupon_info)){

            if($coupon_amount > 0 &&  !empty($coupon_amount)){
                if($coupon_start_fee > $zk_final_price){
                    $tbk_xianjia = $zk_final_price;
                }
                if($coupon_start_fee <= $zk_final_price){
                    $tbk_xianjia = intval($zk_final_price) - intval($coupon_amount);
                }
            }elseif($coupon_amount <= 0 ||  empty($coupon_amount)){
                if($coupon_start_fee > $zk_final_price){
                    $tbk_xianjia = $zk_final_price;
                }
                if($coupon_start_fee <= $zk_final_price){
                    $tbk_xianjia = intval($zk_final_price) - intval($coupon_start_fee);
                }
            }
        }


        $isyuanjia = true;
        if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == "" || $tbk_xianjia >= $tbk_yuanjia){
            $isyuanjia = false;
        }

        //20180912 add start
        $isxianjia = true;
        if($tbk_xianjia == "#" || $tbk_xianjia == 0 || $tbk_xianjia == ""){
            $isxianjia = false;
        }
        //20180912 add end

        $tbk_youhuiquanurl = "";
        $tbk_youhuitips = $_config['g_youhuitips'];

        $isshowyhk = false;
        if(!empty($tbk_youhuiquanurl)){
            $isshowyhk = true;
        }

        $tbkstyle = $_config['g_mstyle'];
        if(empty($tbkstyle)){
            $tbkstyle = "discuzcode";
        }


        $tbk_tkl = '';

        if($_config_gjc['g_ismtkl']){

            $tbappkey = $_config['g_appkey'];
            $tbsecretKey = $_config['g_appsecret'];
            //$webbianma = $_config['g_bianma'];
            $webbianma = $_G['charset'];

            require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';
            $gtkl = new GetTbAPI();
            $gtkl->__construct($tbappkey, $tbsecretKey);
            $tbktkl_get = $gtkl->gettkl($tbk_title, $tbk_url, $tbk_imgurl, $webbianma);

            $tbktkl_get = json_decode($tbktkl_get);
            if ($webbianma == "gbk") {
                $tbktkl = diconv($tbktkl_get->model, 'UTF-8', 'GBK');
                $tbktklsimple = diconv($tbktkl_get->password_simple, 'UTF-8', 'GBK');
            } else {
                $tbktkl = $tbktkl_get->model;
                $tbktklsimple = $tbktkl_get->password_simple;
            }



            $tkltips = $_config['g_tkltips'];

            if(!empty($tbktkl)){
                $tbkstyle = $_config['g_tklstyle'];
                if(empty($tbkstyle)){
                    $tbkstyle = "taokouling";
                }
            }

        }


        $g_isopenzhtglj = $_config['g_isopenzhtglj'];
        $numiid = $item_id;

        $tbk_goumai = $_config['g_goumai'];
        $tbk_youhuiquan = $_config['g_youhuiquan'];

        $tbk_platform = $user_type?'tmall':'taobao';
        $tbk_platform_img = !empty($tbk_platform)?'/source/plugin/jzsjiale_daogou/static/images/platform/'.$tbk_platform.'.png':'';

        $tbk_freeshipment = (int)$real_post_fee > 0 ?0:1;

        $isnofollow = true;
        $isnofollow = $_config['g_isnofollow'];


        if($_config['g_zjzrspneilian']){
            if(!empty($tbk_url) && $tbk_url != "#"){
                $tbk_url_data = base64_encode($tbk_url);
                $tbk_url_data = str_replace(array('+','/','='),array('-','_',''),$tbk_url_data);

                $tbk_url = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=zjzr&spurl='.$tbk_url_data;
            }
            if(!empty($tbk_youhuiquanurl) && $tbk_youhuiquanurl != "#"){
                $tbk_youhuiquanurl_data = base64_encode($tbk_youhuiquanurl);
                $tbk_youhuiquanurl_data = str_replace(array('+','/','='),array('-','_',''),$tbk_youhuiquanurl_data);

                $tbk_youhuiquanurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=zjzr&spurl='.$tbk_youhuiquanurl_data;
            }

        }

        $suijishu = random(10, '123456789abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ');
        include template('jzsjiale_daogou:'.$tbkstyle);
        $return = str_replace(array("\r\n", "\r", "\n"), "", $return);
        return trim($return);
    }


    function getyhqshangpin($gjc_gjctitle,$gjc_gjcnum)
    {
        global $_G;
        $_config_gjc = $_G['cache']['plugin']['jzsjiale_guanjianci'];

        $dsp = array();
        $dsp['q'] = daddslashes(trim($gjc_gjctitle));
        $dsp['sort'] = $_config_gjc['sort']?$_config_gjc['sort']:"total_sales_des";
        $dsp['has_coupon'] = $_config_gjc['has_coupon'];
        $dsp['is_tmall'] = $_config_gjc['is_tmall'];
        $dsp['is_overseas'] = $_config_gjc['is_overseas'];
        $dsp['need_free_shipment'] = $_config_gjc['need_free_shipment'];
        $dsp['need_prepay'] = $_config_gjc['need_prepay'];
        /*
        $dsp['include_pay_rate_30'] = 1;
        $dsp['include_good_rate'] = 1;
        $dsp['include_rfd_rate'] = 1;
        */
        $dsp['page_size'] = ($gjc_gjcnum*10<100)?($gjc_gjcnum*10):100;
        $dsp['currpage'] = '1';

        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $tbappkey = $_config['g_appkey'];
        $tbsecretKey = $_config['g_appsecret'];
        $pid = $_config['g_pid'];
        $webbianma = $_G['charset'];

        if(empty($pid)){
            return array();
        }

        $dzoneId = explode("_",$pid);
        $dzoneId = $dzoneId[3];

        if(empty($dzoneId)){
            return array();
        }

        require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';
        $gtkl = new GetTbAPI;
        $gtkl->__construct($tbappkey, $tbsecretKey);
        $tbinfo =  $gtkl->getdgmaterialoptional($dsp,$dzoneId,$webbianma);

        $tbinfo = json_decode($tbinfo);

        $splistinfo = $tbinfo->result_list->map_data;

        return $splistinfo;
    }

    function getyhqtemplate($spi)
    {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $_config_gjc = $_G['cache']['plugin']['jzsjiale_guanjianci'];

        $webbianma = $_G['charset'];

        if($webbianma == 'gbk') {
            $coupon_start_time = diconv($spi->coupon_start_time,'UTF-8','GBK');
            $coupon_end_time = diconv($spi->coupon_end_time,'UTF-8','GBK');
            //$info_dxjh = diconv($spi->info_dxjh,'UTF-8','GBK');
            $tk_total_sales = diconv($spi->tk_total_sales,'UTF-8','GBK');
            //$tk_total_commi = diconv($spi->tk_total_commi,'UTF-8','GBK');
            //$coupon_id = diconv($spi->coupon_id,'UTF-8','GBK');
            //$num_iid = diconv($spi->num_iid,'UTF-8','GBK');
            $title = diconv($spi->title,'UTF-8','GBK');
            $pict_url = diconv($spi->pict_url,'UTF-8','GBK');
            //$small_images = diconv($spi->small_images,'UTF-8','GBK');
            $reserve_price = diconv($spi->reserve_price,'UTF-8','GBK');
            $zk_final_price = diconv($spi->zk_final_price,'UTF-8','GBK');
            $user_type = diconv($spi->user_type,'UTF-8','GBK');
            $provcity = diconv($spi->provcity,'UTF-8','GBK');
            $item_url = diconv($spi->item_url,'UTF-8','GBK');
            //$include_mkt = diconv($spi->include_mkt,'UTF-8','GBK');
            //$include_dxjh = diconv($spi->include_dxjh,'UTF-8','GBK');
            $commission_rate = diconv($spi->commission_rate,'UTF-8','GBK');
            $volume = diconv($spi->volume,'UTF-8','GBK');
            //$seller_id = diconv($spi->seller_id,'UTF-8','GBK');
            $coupon_total_count = diconv($spi->coupon_total_count,'UTF-8','GBK');
            $coupon_remain_count = diconv($spi->coupon_remain_count,'UTF-8','GBK');
            $coupon_info = diconv($spi->coupon_info,'UTF-8','GBK');
            //$commission_type = diconv($spi->commission_type,'UTF-8','GBK');
            $shop_title = diconv($spi->shop_title,'UTF-8','GBK');
            $shop_dsr = diconv($spi->shop_dsr,'UTF-8','GBK');
            $coupon_share_url = diconv($spi->coupon_share_url,'UTF-8','GBK');
            $url = diconv($spi->url,'UTF-8','GBK');
            /*
            $level_one_category_name = diconv($spi->level_one_category_name,'UTF-8','GBK');
            $level_one_category_id = diconv($spi->level_one_category_id,'UTF-8','GBK');
            $category_name = diconv($spi->category_name,'UTF-8','GBK');
            $category_id = diconv($spi->category_id,'UTF-8','GBK');
            $short_title = diconv($spi->short_title,'UTF-8','GBK');
            $white_image = diconv($spi->white_image,'UTF-8','GBK');
            $oetime = diconv($spi->oetime,'UTF-8','GBK');
            $ostime = diconv($spi->ostime,'UTF-8','GBK');
            $jdd_num = diconv($spi->jdd_num,'UTF-8','GBK');
            $jdd_price = diconv($spi->jdd_price,'UTF-8','GBK');
            $uv_sum_pre_sale = diconv($spi->uv_sum_pre_sale,'UTF-8','GBK');
            $x_id = diconv($spi->x_id,'UTF-8','GBK');
            */
            $coupon_start_fee = diconv($spi->coupon_start_fee,'UTF-8','GBK');
            $coupon_amount = diconv($spi->coupon_amount,'UTF-8','GBK');
            //$item_description = diconv($spi->item_description,'UTF-8','GBK');
            $nick = diconv($spi->nick,'UTF-8','GBK');
            /*
            $orig_price = diconv($spi->orig_price,'UTF-8','GBK');
            $total_stock = diconv($spi->total_stock,'UTF-8','GBK');
            $sell_num = diconv($spi->sell_num,'UTF-8','GBK');
            $stock = diconv($spi->stock,'UTF-8','GBK');
            $tmall_play_activity_info = diconv($spi->tmall_play_activity_info,'UTF-8','GBK');
            */
            $item_id = diconv($spi->item_id,'UTF-8','GBK');
            $real_post_fee = diconv($spi->real_post_fee,'UTF-8','GBK');
        }else{
            $coupon_start_time = $spi->coupon_start_time;
            $coupon_end_time = $spi->coupon_end_time;
            //$info_dxjh = $spi->info_dxjh;
            $tk_total_sales = $spi->tk_total_sales;
            //$tk_total_commi = $spi->tk_total_commi;
            //$coupon_id = $spi->coupon_id;
            //$num_iid = $spi->num_iid;
            $title = $spi->title;
            $pict_url = $spi->pict_url;
            //$small_images = $spi->small_images;
            $reserve_price = $spi->reserve_price;
            $zk_final_price = $spi->zk_final_price;
            $user_type = $spi->user_type;
            $provcity = $spi->provcity;
            $item_url = $spi->item_url;
            //$include_mkt = $spi->include_mkt;
            //$include_dxjh = $spi->include_dxjh;
            $commission_rate = $spi->commission_rate;
            $volume = $spi->volume;
            //$seller_id = $spi->seller_id;
            $coupon_total_count = $spi->coupon_total_count;
            $coupon_remain_count = $spi->coupon_remain_count;
            $coupon_info = $spi->coupon_info;
            //$commission_type = $spi->commission_type;
            $shop_title = $spi->shop_title;
            $shop_dsr = $spi->shop_dsr;
            $coupon_share_url = $spi->coupon_share_url;
            $url = $spi->url;
            /*
            $level_one_category_name = $spi->level_one_category_name;
            $level_one_category_id = $spi->level_one_category_id;
            $category_name = $spi->category_name;
            $category_id = $spi->category_id;
            $short_title = $spi->short_title;
            $white_image = $spi->white_image;
            $oetime = $spi->oetime;
            $ostime = $spi->ostime;
            $jdd_num = $spi->jdd_num;
            $jdd_price = $spi->jdd_price;
            $uv_sum_pre_sale = $spi->uv_sum_pre_sale;
            $x_id = $spi->x_id);
            */
            $coupon_start_fee = $spi->coupon_start_fee;
            $coupon_amount = $spi->coupon_amount;
            //$item_description = $spi->item_description;
            $nick = $spi->nick;
            /*
            $orig_price = $spi->orig_price;
            $total_stock = $spi->total_stock;
            $sell_num = $spi->sell_num;
            $stock = $spi->stock;
            $tmall_play_activity_info = $spi->tmall_play_activity_info;
            */
            $item_id = $spi->item_id;
            $real_post_fee = $spi->real_post_fee;
        }


        $tbk_title = $title;
        $tbk_imgurl = $pict_url;
        $tbk_url = !empty($coupon_share_url)?$coupon_share_url:(!empty($url)?$url:$item_url);
        $tbk_url = ((!empty($tbk_url) && strpos($tbk_url,'http') ===false)?'https:':'').$tbk_url;
        $tbk_yuanjia = $reserve_price;
        $tbk_xianjia = $zk_final_price;

        //tiqu  youhuijiage
        /*
        if(!empty($coupon_info)){

            if($coupon_amount > 0 &&  !empty($coupon_amount)){
                if($coupon_start_fee > $zk_final_price){
                    $tbk_xianjia = $zk_final_price;
                }
                if($coupon_start_fee <= $zk_final_price){
                    $tbk_xianjia = intval($zk_final_price) - intval($coupon_amount);
                }
            }elseif($coupon_amount <= 0 ||  empty($coupon_amount)){
                if($coupon_start_fee > $zk_final_price){
                    $tbk_xianjia = $zk_final_price;
                }
                if($coupon_start_fee <= $zk_final_price){
                    $tbk_xianjia = intval($zk_final_price) - intval($coupon_start_fee);
                }
            }
        }
        */

        $isyuanjia = true;
        if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == "" || $tbk_xianjia >= $tbk_yuanjia){
            $isyuanjia = false;
        }

        //20180912 add start
        $isxianjia = true;
        if($tbk_xianjia == "#" || $tbk_xianjia == 0 || $tbk_xianjia == ""){
            $isxianjia = false;
        }
        //20180912 add end

        $tbk_youhuiquanurl = "";
        $tbk_youhuitips = $_config['g_youhuitips'];

        $isshowyhk = false;
        if(!empty($tbk_youhuiquanurl)){
            $isshowyhk = true;
        }

        $tbkstyle = $_config['g_mstyle'];
        if(empty($tbkstyle)){
            $tbkstyle = "discuzcode";
        }


        $tbk_tkl = '';


        if($_config_gjc['g_ismtkl']){

            $tbappkey = $_config['g_appkey'];
            $tbsecretKey = $_config['g_appsecret'];
            //$webbianma = $_config['g_bianma'];
            $webbianma = $_G['charset'];

            require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';
            $gtkl = new GetTbAPI();
            $gtkl->__construct($tbappkey, $tbsecretKey);
            $tbktkl_get = $gtkl->gettkl($tbk_title, $tbk_url, $tbk_imgurl, $webbianma);

            $tbktkl_get = json_decode($tbktkl_get);
            if ($webbianma == "gbk") {
                $tbktkl = diconv($tbktkl_get->model, 'UTF-8', 'GBK');
                $tbktklsimple = diconv($tbktkl_get->password_simple, 'UTF-8', 'GBK');
            } else {
                $tbktkl = $tbktkl_get->model;
                $tbktklsimple = $tbktkl_get->password_simple;
            }



            $tkltips = $_config['g_tkltips'];

            if(!empty($tbktkl)){
                $tbkstyle = $_config['g_tklstyle'];
                if(empty($tbkstyle)){
                    $tbkstyle = "taokouling";
                }
            }

        }


        $g_isopenzhtglj = $_config['g_isopenzhtglj'];
        $numiid = $item_id;

        $tbk_goumai = $_config['g_goumai'];
        $tbk_youhuiquan = $_config['g_youhuiquan'];

        $isnofollow = true;
        $isnofollow = $_config['g_isnofollow'];


        if($_config['g_zjzrspneilian']){
            if(!empty($tbk_url) && $tbk_url != "#"){
                $tbk_url_data = base64_encode($tbk_url);
                $tbk_url_data = str_replace(array('+','/','='),array('-','_',''),$tbk_url_data);

                $tbk_url = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=zjzr&spurl='.$tbk_url_data;
            }
            if(!empty($tbk_youhuiquanurl) && $tbk_youhuiquanurl != "#"){
                $tbk_youhuiquanurl_data = base64_encode($tbk_youhuiquanurl);
                $tbk_youhuiquanurl_data = str_replace(array('+','/','='),array('-','_',''),$tbk_youhuiquanurl_data);

                $tbk_youhuiquanurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=zjzr&spurl='.$tbk_youhuiquanurl_data;
            }

        }

        $suijishu = random(10, '123456789abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ');

        $tbk_platform = $user_type?'tmall':'taobao';
        $tbk_platform_img = !empty($tbk_platform)?'/source/plugin/jzsjiale_daogou/static/images/platform/'.$tbk_platform.'.png':'';

        $tbk_freeshipment = (int)$real_post_fee > 0 ?0:1;

        //newyhq start

        if($_config['g_myhqstyle'] != 'none' && !empty($tbk_xianjia) && !empty($tbk_url)
            && !empty($coupon_start_fee) && !empty($coupon_amount)){

            $tbk_youhuiquanurl = $tbk_url;

            $tbk_couponamount = $coupon_amount;
            if($tbk_couponamount > 0){
                if($coupon_start_fee <= $tbk_xianjia){
                    $tbk_quanhoujia = (double)$tbk_xianjia - (double)$coupon_amount;
                }
            }
            $tbk_youxiaoqi = !empty($coupon_end_time)?(!empty($coupon_start_time)?$coupon_start_time.'&nbsp;&nbsp;-&nbsp;&nbsp;'.$coupon_end_time:$coupon_end_time):"";

            $tbk_xianjia = (double)$tbk_xianjia;

            $tbkstyle = $_config['g_myhqstyle'];
            include template('jzsjiale_daogou:'.$tbkstyle);
            $return = str_replace(array("\r\n", "\r", "\n"), "", $return);
            return trim($return);
        }else{
            include template('jzsjiale_daogou:'.$tbkstyle);
            $return = str_replace(array("\r\n", "\r", "\n"), "", $return);
            return trim($return);
        }
    }


    function getspkshangpin($gjc_gjctitle,$gjc_gjcnum)
    {
        $q = daddslashes(trim($gjc_gjctitle));


        //cache start
        if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php')){
            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';


        }else{
            $tbkcategory = C::t('#jzsjiale_daogou#jzsjiale_daogou_category')->getall();

            require_once libfile('function/cache');
            writetocache('jzsjiale_daogou_category', getcachevars(array('tbkcategory' => $tbkcategory)));

            @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_category.php';

        }

        $categorylist = array();
        foreach ($tbkcategory as $suijidata){
            $categorylist[] = $suijidata['id'];
        }

        $allokshangpin = array();
        foreach ($categorylist as $sjdata){
            if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php')){
                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$sjdata};

            }else{
                $shangpin_cache_tmp = C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->getallsuijibycategoryid(1, $sjdata);

                require_once libfile('function/cache');
                writetocache('jzsjiale_daogou_shangpin_'.$sjdata, getcachevars(array('tbkshangpin_'.$sjdata => $shangpin_cache_tmp)));

                @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_daogou_shangpin_'.$sjdata.'.php';
                $tbkshangpin = ${'tbkshangpin_'.$sjdata};

            }

            if(!empty($tbkshangpin) && $tbkshangpin != null){
                $allokshangpin = array_merge($allokshangpin, $tbkshangpin);
            }
        }

        //cache end

        $utils = new Utils();
        $splistinfo = $utils->searchlike($q,'title',$allokshangpin);
        //var_dump($splistinfo);
        return $splistinfo;
    }
    
    
    function getspktemplate($spi)
    {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_daogou'];
        $_config_gjc = $_G['cache']['plugin']['jzsjiale_guanjianci'];
        
        
        $tbk_title = $spi['title'];
        $tbk_imgurl = $spi['img'];
        $tbk_url = $spi['url'];
        $tbk_yuanjia = $spi['yuanjia'];
        
        $isyuanjia = true;
        if($tbk_yuanjia == "#" || $tbk_yuanjia == 0 || $tbk_yuanjia == ""){
            $isyuanjia = false;
        }
        
        
        $tbk_xianjia = $spi['xianjia'];
        
        //20180912 add start
        $isxianjia = true;
        if($tbk_xianjia == "#" || $tbk_xianjia == 0 || $tbk_xianjia == ""){
            $isxianjia = false;
        }
        //20180912 add end
        
        $tbk_youhuiquanurl = $spi['youhuiquan'];
        $tbk_youhuitips = $_config['g_youhuitips'];
        
        $isshowyhk = false;
        if(!empty($tbk_youhuiquanurl)){
            $isshowyhk = true;
        }
        
        $tbkstyle = $_config['g_mstyle'];
        if(empty($tbkstyle)){
            $tbkstyle = "discuzcode";
        }
        
        
        $tbk_tkl = $spi['tkl'];
        $tbk_tkl_simple = $spi['tklsimple'];

        if($_config['g_yhqtotkl'] && $_config['g_myhqstyle'] != 'none' && !empty($tbk_xianjia)
            && !empty($spi['youhuiquan']) && !empty($spi['couponstartfee'])
            && !empty($spi['couponamount'])){

            $tbk_url = $spi['youhuiquan'];
        }
        
        if($_config_gjc['g_ismtkl']){
            
            $tbappkey = $_config['g_appkey'];
            $tbsecretKey = $_config['g_appsecret'];
            //$webbianma = $_config['g_bianma'];
            $webbianma = $_G['charset'];
            
            $g_tklguoqishijian = $_config['g_tklguoqishijian'];
            $hourtime = strtotime("-".($g_tklguoqishijian*24)." hour");
            
            if(empty($tbk_tkl) || $spi['tkldateline'] <= $hourtime){
                require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_daogou/GetTbAPI.php';
                $gtkl = new GetTbAPI;
                $gtkl->__construct($tbappkey, $tbsecretKey);
                $tbktkl_get =  $gtkl->gettkl($tbk_title,$tbk_url,$tbk_imgurl,$webbianma);

                $tbktkl_get = json_decode($tbktkl_get);
                if($webbianma == "gbk"){
                    $tbktkl = diconv($tbktkl_get->model,'UTF-8','GBK');
                    $tbktklsimple = diconv($tbktkl_get->password_simple,'UTF-8','GBK');
                }else{
                    $tbktkl = $tbktkl_get->model;
                    $tbktklsimple = $tbktkl_get->password_simple;
                }
                
                if($g_tklguoqishijian>0){
                    $dsp = array('tkldateline'=>TIMESTAMP);
                    $dsp['tkl'] = $tbktkl;
                    $dsp['tklsimple'] = $tbktklsimple;
                    
                    //20180710 add
                    if($_G['charset'] == 'gbk'){
                        $pattern = "/^[a-zA-z0-9]$/is";
                        /*
                        if (preg_match( $pattern, substr( $dsp['tkl'], 0, 1 ) ) )
                        {
                            $dsp['tkl'] = '%80'.$dsp['tkl'].'%80';
                            $tbktkl = $dsp['tkl'];
                        }
                         */
                        if (preg_match( $pattern, substr( $dsp['tklsimple'], 0, 1 ) ) )
                        {
                            $dsp['tklsimple'] = '%80'.$dsp['tklsimple'].'%80';
                            $tbktklsimple = $dsp['tklsimple'];
                        }
                    }
                    //20180710 end
                    
                    C::t('#jzsjiale_daogou#jzsjiale_daogou_shangpin')->update($spi['id'],$dsp);
                }
                
            }else{
                if($_config['g_showdiytkl']){
                    $tbktkl = $tbk_tkl;
                    $tbktklsimple = $tbk_tkl_simple;
                }
            }
            
            
            
            $tkltips = $_config['g_tkltips'];
            
            if(!empty($tbktkl) && $tbktkl != '#'){
                $tbkstyle = $_config['g_tklstyle'];
                if(empty($tbkstyle)){
                    $tbkstyle = "taokouling";
                }
            }
            
        }else{
            if(!empty($tbk_tkl) && $tbk_tkl != '#' && $_config['g_showdiytkl']){
                $tbktkl = $tbk_tkl;
                $tbktklsimple = $tbk_tkl_simple;
                
                $tkltips = $_config['g_tkltips'];
                
                if(!empty($tbktkl)){
                    $tbkstyle = $_config['g_tklstyle'];
                    if(empty($tbkstyle)){
                        $tbkstyle = "taokouling";
                    }
                }
            }
            
        }
        
        
        $g_isopenzhtglj = $_config['g_isopenzhtglj'];
        $numiid = $spi['numiid'];
        
        $tbk_goumai = $_config['g_goumai'];
        $tbk_youhuiquan = $_config['g_youhuiquan'];
        
        $isnofollow = true;
        $isnofollow = $_config['g_isnofollow'];


        if($_config['g_spneilian']){
            $tbk_url = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=url&spid='.$spi['id'];
            $tbk_youhuiquanurl = $_G['siteurl'].'plugin.php?id=jzsjiale_daogou:turnto&a=sp&t=youhuiquanurl&spid='.$spi['id'];
        }

        $suijishu = random(10, '123456789abcdefghijklmnpqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ');

        $tbk_platform = (!empty($spi['platform']) && $spi['platform'] != 'none')?$spi['platform']:'';
        $tbk_platform_img = !empty($tbk_platform)?'/source/plugin/jzsjiale_daogou/static/images/platform/'.$tbk_platform.'.png':'';

        $tbk_freeshipment = $spi['freeshipment'];

        //newyhq start

        if($_config['g_myhqstyle'] != 'none' && !empty($tbk_xianjia) && !empty($spi['youhuiquan'])
            && !empty($spi['couponstartfee']) && !empty($spi['couponamount'])){

            $tbk_couponamount = $spi['couponamount'];
            if($tbk_couponamount > 0){
                if($spi['couponstartfee'] <= $spi['xianjia']){
                    $tbk_quanhoujia = (double)$spi['xianjia'] - (double)$spi['couponamount'];
                }
            }
            $tbk_youxiaoqi = !empty($spi['couponendtime'])?(!empty($spi['couponstarttime'])?$spi['couponstarttime'].'&nbsp;&nbsp;-&nbsp;&nbsp;'.$spi['couponendtime']:$spi['couponendtime']):"";


            $tbk_xianjia = (double)$spi['xianjia'];

            $tbkstyle = $_config['g_myhqstyle'];
            include template('jzsjiale_daogou:'.$tbkstyle);
            $return = str_replace(array("\r\n", "\r", "\n"), "", $return);
            return trim($return);
        }else{
            include template('jzsjiale_daogou:'.$tbkstyle);
            $return = str_replace(array("\r\n", "\r", "\n"), "", $return);
            return trim($return);
        }
    }
    
    
    function getguanjianci($message)
    {
        $message = $message[0];
        $this->count ++;
        $id = 'gjc' . $this->count;
    
        $message = trim($message);
        $message = str_ireplace('&amp;', '&', $message);
    
        $message = substr($message, strlen('[jzsjiale_guanjianci]'), strlen($message) - strlen('[jzsjiale_guanjianci]') - strlen('[/jzsjiale_guanjianci]'));
    
        $gjcarray = explode(',=', $message);
    
        $gjc_gjctitle = $gjcarray[0];
        $gjc_gjcnum = $gjcarray[1];
    
        if(empty($gjc_gjctitle)){
            $gjc_gjctitle = '1';
        }
    
        $pattern = "/^[1-9]\d*$/is";
        if ( !preg_match( $pattern, $gjc_gjcnum ) )
        {
            $gjc_gjcnum = 1;
        }
    
        $allsp = array();
    
        $gjcstrarray = explode(',', $gjc_gjctitle);
    
        
        global $_G;
        
        $_config_gjc = $_G['cache']['plugin']['jzsjiale_guanjianci'];
        
        $g_source = !empty($_config_gjc['g_source'])?$_config_gjc['g_source']:'tbk';
        
      
        if ($g_source == 'tbk') {
            
            foreach ($gjcstrarray as $gjc){
                
                $retsplist = $this->getshangpin($gjc,$gjc_gjcnum);
                if(!empty($retsplist)){
                    $allsp = array_merge($allsp, $retsplist);
                }
            }
        }else if($g_source == 'yhq'){
            foreach ($gjcstrarray as $gjc){

                $retsplist = $this->getyhqshangpin($gjc,$gjc_gjcnum);//var_dump($retsplist);
                if(!empty($retsplist)){
                    $allsp = array_merge($allsp, $retsplist);
                }
            }
        }else if($g_source == 'spk'){
            foreach ($gjcstrarray as $gjc){

                $retsplist = $this->getspkshangpin($gjc,$gjc_gjcnum);//var_dump($retsplist);
                if(!empty($retsplist)){
                    $allsp = array_merge($allsp, $retsplist);
                }
            }
        }
        
        
         
    
        $allokspformat = "";
    
        $spid = array_rand($allsp,$gjc_gjcnum);
    
        if($gjc_gjcnum == 1){
            $sptmp = $allsp[$spid];
            if(!empty($sptmp)){
                if ($g_source == 'tbk') {
                    $allokspformat = $this->gettemplate($sptmp);
                }else if($g_source == 'yhq'){
                    $allokspformat = $this->getyhqtemplate($sptmp);
                }else if($g_source == 'spk'){
                    $allokspformat = $this->getspktemplate($sptmp);
                }
            }
        }else{
            for($i=0;$i<$gjc_gjcnum;$i++){
                $sptmp = $allsp[$spid[$i]];
                if(!empty($sptmp)){
                    if ($g_source == 'tbk') {
                        $allokspformat .= $this->gettemplate($sptmp);
                    }else if($g_source == 'yhq'){
                        $allokspformat .= $this->getyhqtemplate($sptmp);
                    }else if($g_source == 'spk'){
                        $allokspformat .= $this->getspktemplate($sptmp);
                    }
                    
                }
            }
        }
    
        return $allokspformat;
    }
    
    
    
    function discuzcode($param)
    {
        global $_G;
    
        $_config_gjc = $_G['cache']['plugin']['jzsjiale_guanjianci'];
    
        if (! $_config_gjc['g_isopen']) {
            return;
        }
    
        if (strpos($_G['discuzcodemessage'], '[/jzsjiale_guanjianci]') === false) {
            return false;
        }

        //gaidong chaojihuodong start
        if($_G["thread"]["special"] != '127') {
            $_G['discuzcodemessage'] .= "<link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/mobiletbkitem.css\" type=\"text/css\" />";

        }
        //gaidong chaojihuodong end
        if ($param['caller'] == 'discuzcode') {
            $_G['discuzcodemessage'] = preg_replace_callback('/\s?\[jzsjiale_guanjianci\](.*?)\[\/jzsjiale_guanjianci\]\s?/is', array(
                $this,
                'getguanjianci'
            ), $_G['discuzcodemessage']);
    
             
        } else {
            $_G['discuzcodemessage'] = preg_replace_callback('/\s?\[jzsjiale_guanjianci\](.*?)\[\/jzsjiale_guanjianci\]\s?/is', '', $_G['discuzcodemessage']);
        }
    }
}

class mobileplugin_jzsjiale_guanjianci_forum extends mobileplugin_jzsjiale_guanjianci
{
    var $cacheshangpin = "";

    //gaidong chaojihuodong start
    function viewthread_top_mobile()
    {
        global $_G;

        if ($_G["thread"]["special"] == '127') {
            return "<link rel=\"stylesheet\" href=\"source/plugin/jzsjiale_daogou/static/css/mobiletbkitem.css\" type=\"text/css\" />";
        }

    }
    //gaidong chaojihuodong end
}
//From: Dism��taobao��com
?>