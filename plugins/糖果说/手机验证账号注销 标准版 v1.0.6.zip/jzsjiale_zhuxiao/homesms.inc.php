<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$act = addslashes($_GET['act']);
$formhash =  addslashes($_GET['formhash'])? addslashes($_GET['formhash']):'';
loadcache('plugin');
global $_G, $lang;

require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_zhuxiao/smstools.inc.php';


if ($act == 'sendseccode') {
    
    if ($formhash == FORMHASH) {
  
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_zhuxiao'];
        $g_accesskeyid = $_config['g_accesskeyid'];
        $g_accesskeysecret = $_config['g_accesskeysecret'];
        $webbianma = $_G['charset'];
        //$g_xiane = $_config['g_xiane'];
        $g_xiane = !empty($_config['g_xiane'])?$_config['g_xiane']:10;
        $g_zongxiane = ($_config['g_zongxiane']>0)?$_config['g_zongxiane']:0;
        $g_zhanghaoxiane = ($_config['g_zhanghaoxiane']>0)?$_config['g_zhanghaoxiane']:0;
        $g_isopenhtmlspecialchars = !empty($_config['g_isopenhtmlspecialchars'])?true:false;
        
        $g_templateid = "";
        $g_sign = "";
        $type = intval($_GET[type]);
        //type 0ceshi 1zhuxiao
        
        
        if($g_zongxiane){
            $phonesendallcount = C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_smslist')->count_all_by_day();
            
            if($phonesendallcount >= $g_zongxiane){
                echo json_encode(array('code' => -1,'data' => 'err_seccodezongxiane'));
                exit;
            }
        }
        
        if($_G['uid'] && $g_zhanghaoxiane && $type == 1){
            $uidphonesendcount = C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_smslist')->count_by_uid_day($_G['uid']);
   
            if($uidphonesendcount >= $g_zhanghaoxiane){
                echo json_encode(array('code' => -1,'data' => 'err_zhanghaoseccodexiane'));
                exit;
            }
        }
        
        
        if(empty($g_accesskeyid)){
            echo json_encode(array('code' => -1,'data' => 'peizhierror'));
            exit;
        }
        if(empty($g_accesskeysecret)){
            echo json_encode(array('code' => -1,'data' => 'peizhierror'));
            exit;
        }
        
        
       $g_openzhuxiaosms = $_config['g_openzhuxiaosms'];
            
       if(!$g_openzhuxiaosms){
            echo json_encode(array('code' => -1,'data' => 'notopenzhuxiao'));
            exit;
       }else{
            $g_templateid = $_config['g_zhuxiaoid'];
            $g_sign = $_config['g_zhuxiaosign'];
       }
        
        
        $phone = addslashes($_GET['phone']);
        if(empty($phone)){
            echo json_encode(array('code' => -1,'data' => 'paramerror'));
            exit;
        }
        if (!preg_match("/^1[34578]{1}\d{9}$/", $phone)) {
            echo json_encode(array('code' => -1,'data' => 'bind_phone_error'));
            exit;
        }
        
        if($_config['g_isopenimgcode']){
            if(empty($_GET['seccodeverify']) || empty($_GET['seccodehash'])){
                echo json_encode(array('code' => -1,'data' => 'paramerror'));
                exit;
            }
            if (!check_seccode($_GET['seccodeverify'], $_GET['seccodehash'])) {
                echo json_encode(array('code' => -1,'data' => 'seccode_invalid'));
                exit;
            }
        }
        
        $user =  C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_member')->fetch_by_mobile_and_uid($phone,$_G['uid']);

        if (!$user && $type == 1) {
            echo json_encode(array('code' => -1,'data' => 'err_oldphonebind'));
            exit;
        }
        
        
        $phonesendcount = C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_smslist')->count_by_phone_day($phone);
        
        if($phonesendcount >= $g_xiane){
            echo json_encode(array('code' => -1,'data' => 'err_seccodexiane'));
            exit;
        }
        
        
        
        if(empty($g_templateid)){
            echo json_encode(array('code' => -1,'data' => 'peizhierror'));
            exit;
        }
        if(empty($g_sign)){
            echo json_encode(array('code' => -1,'data' => 'peizhierror'));
            exit;
        }
        
        $code = generate_code();
        
        if(empty($code) || $code == null){
            echo json_encode(array('code' => -1,'data' => 'generatecodeerror'));
            exit;
        }
        
        
        $sms_param_array = array();
        $sms_param_array['code']=(string)$code;
        
        $sms_param = json_encode($sms_param_array);
   
        
        $g_sign=getbianma($g_sign,$webbianma,$g_isopenhtmlspecialchars);
        
        //quoqishijian
        $g_youxiaoqi = $_config['g_youxiaoqi'];
        if(empty($g_youxiaoqi)){
            $g_youxiaoqi = 600;
        }
        //echo "====".date('Y-m-d H:i:s',strtotime("+".$g_youxiaoqi." second"));exit;
        $expire = strtotime("+".$g_youxiaoqi." second");
        
        $uid = $_G['uid'];
        
       
        $retdata = "";
        $phonecode = C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_code')->fetchfirst_by_phone($phone);
        if ($phonecode) {
            if (($phonecode['dateline'] + 60) > TIMESTAMP) {
                echo json_encode(array('code' => -1,'data' => 'err_seccodefasong'));
                exit;
            } else {
                $smstools = new SMSTools();
                $smstools->__construct($g_accesskeyid, $g_accesskeysecret);
                $retdata = $smstools->smssend($code,$expire,$type,$uid,$phone,$g_sign,$g_templateid,$sms_param);
            }
        } else {
                $smstools = new SMSTools();
                $smstools->__construct($g_accesskeyid, $g_accesskeysecret);
                $retdata = $smstools->smssend($code,$expire,$type,$uid,$phone,$g_sign,$g_templateid,$sms_param);
        }
      

        switch ($retdata){
            case 'success':
                echo json_encode(array('code' => 200,'data' => 'smssuccess'));
                break;
            case 'isv.MOBILE_NUMBER_ILLEGAL':
                echo json_encode(array('code' => -1,'data' => 'isvMOBILE_NUMBER_ILLEGAL'));
                break;
            case 'isv.BUSINESS_LIMIT_CONTROL':
                echo json_encode(array('code' => -1,'data' => 'isvBUSINESS_LIMIT_CONTROL'));
                break;
            case 'error':
                echo json_encode(array('code' => -1,'data' => 'smserror'));
                break;
            default:
                echo json_encode(array('code' => -1,'data' => 'smserror'));
                break;
        }
        
    } else {
        include template('jzsjiale_zhuxiao:sendseccode');
    }
}elseif ($act == 'aloneregister') {
    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_zhuxiao'];
 
    if (!$_config['g_openpcregister']) {
        showmessage(lang('plugin/jzsjiale_zhuxiao', 'err_gongnengweikaiqi'));
    }
    if (!$_config['g_pcregphonetab']) {
        showmessage(lang('plugin/jzsjiale_zhuxiao', 'err_pcregphonetabweikaiqi'));
    }
    if ($formhash == FORMHASH && $_GET['jzsjiale_zhuxiao_alone_submit']) {
        
        if(isset($_GET["inajax"]) && $_GET["inajax"]==1){
            $phone = addslashes($_GET['alone_phone_reg']);
            $seccode = addslashes($_GET['alone_seccode']);
            $username = addslashes($_GET['alone_username']);
            $password = addslashes($_GET['alone_password1']);
            $password2 = addslashes($_GET['alone_password2']);
            $referer = addslashes($_GET['referer']);
            
            if(empty($phone)){
                showmessage(lang('plugin/jzsjiale_zhuxiao', 'phonenull'));
            }
            
            if (!preg_match("/^1[34578]{1}\d{9}$/", $phone)) {
                showmessage(lang('plugin/jzsjiale_zhuxiao', 'bind_phone_error'));
            }
            
            if(empty($seccode)){
                showmessage(lang('plugin/jzsjiale_zhuxiao', 'seccodenull'));
            }
            
            if(empty($password)){
                showmessage(lang('plugin/jzsjiale_zhuxiao', 'passwordnull'));
            }
            
            if (strlen($password)<6) {
                showmessage(lang('plugin/jzsjiale_zhuxiao', 'password6'));
            }
            
            if(empty($password2)){
                showmessage(lang('plugin/jzsjiale_zhuxiao', 'password2null'));
            }
            
            if (strlen($password2)<6) {
                showmessage(lang('plugin/jzsjiale_zhuxiao', 'password6'));
            }
            
            if($password != $password2){
                showmessage(lang('plugin/jzsjiale_zhuxiao', 'passworderr'));
            }
            
            if(!$_config['g_pcregphoneusername']){
                $username = $_config['g_pcregphoneqianzhui'].get_rand_username(8);
            }else{
                if(empty($username)){
                    showmessage(lang('plugin/jzsjiale_zhuxiao', 'usernamenull'));
                }
            }
            
            $codeinfo = C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_code')->fetchfirst_by_phone_and_seccode($phone,$seccode);
            if ($codeinfo) {
                if ((TIMESTAMP - $codeinfo[dateline]) > $_config['g_youxiaoqi']) {
                    C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_code')->deleteby_seccode_and_phone($phone,$seccode);
                    //C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_smslist')->deleteby_seccode_and_phone($phone,$seccode);
                    showmessage(lang('plugin/jzsjiale_zhuxiao', 'err_seccodeguoqi'));
                }
            } else {
                showmessage(lang('plugin/jzsjiale_zhuxiao', 'err_seccodeerror'));
            }
            
            
            if($_config['g_tongyiuser']){
                //20170805 add start
                $phoneuser =  C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_member')->fetch_by_mobile($phone);
                //20170805 add end
            }else{
                $phoneuser = C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_user')->fetch_by_phone($phone);
            }
            
            
            if(!empty($phoneuser)){
                showmessage(lang('plugin/jzsjiale_zhuxiao', 'phonecunzai'));
            }
            
            
            //$username = iconv('UTF-8', CHARSET.'//ignore', urldecode($username));
            
            $email = "reg_".substr($phone,0,3).time().substr($phone,7,4)."@null.null";
            
            
            $user = C::t('common_member')->fetch_by_username($username);
            if($user){
                showmessage(lang('plugin/jzsjiale_zhuxiao', 'usernamecunzai'));
                exit;
            }
            
            $profile = array (
                "mobile" => $phone,
            );
            require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_zhuxiao/uc.inc.php';
            
            $isreturnuid = 0;
            $isopenmemail = 0;
            $uid = UC::regist($username,$password,$email,$profile,$isreturnuid,$isopenmemail);
         
            if (!is_numeric($uid)) {
                if($uid == "username_len_invalid"){
                    showmessage(lang('plugin/jzsjiale_zhuxiao', 'username_len_invalid_error'));
                    exit;
                }elseif($uid == "password_len_invalid"){
                    showmessage(lang('plugin/jzsjiale_zhuxiao', 'password_len_invalid_error'));
                    exit;
                }else{
                    showmessage(lang('plugin/jzsjiale_zhuxiao', 'registererror'));
                    exit;
                }
                
            }else{
                if ($uid<=0) {
                    switch ($uid) {
                        case -4:showmessage(lang('plugin/jzsjiale_zhuxiao', 'registeremailillegal')); exit(); break;
                        case -5:showmessage(lang('plugin/jzsjiale_zhuxiao', 'registeremailillegal')); exit(); break;
                        case -6:showmessage(lang('plugin/jzsjiale_zhuxiao', 'registeremailduplicate')); exit(); break;
                        default: showmessage(lang('plugin/jzsjiale_zhuxiao', 'registererror')); exit(); break;
                    };
                }
            }
            
            
            $userinfo = C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_user')->fetch_by_uid($uid);
             
            if ($uid && $phone && $seccode && !$userinfo) {
            
                //weibaochitongbuxianshanchu
                C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_user')->deletebyuid($_G['uid']);
            
                $data = array(
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'phone' => $codeinfo['phone'],
                    'dateline' => TIMESTAMP
                );
            
                C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_user')->insert($data, true);
            
                C::t('common_member_profile')->update($_G['uid'], array('mobile'=> $phone));
            
                C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_code')->deleteby_seccode_and_phone($phone,$seccode);
            
            
            
                //verify start
                if($_config['g_isopenautoverify'] && $_config['g_mobileverify']){
                    $verifyuid = $_G['uid'];
                    $memberautoverify = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$verifyuid);
                    if(empty($memberautoverify)){
                        C::t('common_member_verify')->insert(array('uid' => $verifyuid,'verify'.$_config['g_mobileverify'] => 1));
                    }else{
                        C::t('common_member_verify')->update($verifyuid, array('verify'.$_config['g_mobileverify'] => 1));
                    }
            
                }
            
            
                //verify end
                
                $url_forward = !empty($referer)?$referer:$_G['siteurl'];
                $param = array('bbname' => $_G['setting']['bbname'], 'username' => $_G['username'], 'usergroup' => $_G['group']['grouptitle'], 'uid' => $_G['uid']);
    			if(strpos($url_forward, $_G['setting']['regname']) !== false || strpos($url_forward, 'buyinvitecode') !== false) {
    				$url_forward = 'forum.php';
    			}
    			$refreshtime = 10000;
    			$message = 'register_succeed';
    			$locationmessage = 'register_succeed_location';
    			$href = str_replace("'", "\'", $url_forward);
    			$extra = array(
    				'showid' => 'succeedmessage',
    				'extrajs' => '<script type="text/javascript">'.
    					'setTimeout("window.location.href =\''.$href.'\';", '.$refreshtime.');'.
    					'$(\'succeedmessage_href\').href = \''.$href.'\';'.
    					'$(\'main_message\').style.display = \'none\';'.
    					'$(\'main_succeed\').style.display = \'\';'.
    					'$(\'succeedlocation\').innerHTML = \''.lang('message', $locationmessage).'\';'.
    				'</script>',
    				'striptags' => false,
    			);
                
                showmessage($message, $url_forward,$param,$extra);
                exit();
            
            }else{
                C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_code')->deleteby_seccode_and_phone($phone,$seccode);
                showmessage(lang('plugin/jzsjiale_zhuxiao', 'registersuccess_phoneerror'));
                exit();
            }
            
        }else{
            showmessage(lang('plugin/jzsjiale_zhuxiao', 'paramerror'));
        }
        
    }else{
        $url ="member.php?mod=register";
        header("Location: $url");
        die(0);
    }
}

function getbianma($data, $webbianma = "gbk",$openhtmlspecialchars = true)
{
    if ($webbianma == "gbk") {
        $data = diconv($data, 'GB2312', 'UTF-8');
    }
    if($openhtmlspecialchars){
        $data = isset($data) ? trim(htmlspecialchars($data, ENT_QUOTES)) : '';
    }
    return $data;
}

function generate_code($length = 6)
{
    return rand(pow(10, ($length - 1)), pow(10, $length) - 1);
}

function crypto_rand_secure($min, $max)
{
    $range = $max - $min;
    if ($range < 1) return $min; // not so random...
    $log = ceil(log($range, 2));
    $bytes = (int) ($log / 8) + 1; // length in bytes
    $bits = (int) $log + 1; // length in bits
    $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
    do {
        $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
        $rnd = $rnd & $filter; // discard irrelevant bits
    } while ($rnd >= $range);
    return $min + $rnd;
}

function get_rand_username($length = 8)
{
    $username = "";
    $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $codeAlphabet.= "abcdefghijklmnopqrstuvwxyz";
    $codeAlphabet.= "0123456789";
    $max = strlen($codeAlphabet); // edited

    for ($i=0; $i < $length; $i++) {
        $username .= $codeAlphabet[crypto_rand_secure(0, $max)];
    }

    return $username;
}
//From: Dism_taobao_com
?>