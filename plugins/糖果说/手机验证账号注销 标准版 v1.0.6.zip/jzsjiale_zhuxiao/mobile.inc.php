<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$act = addslashes($_GET['act']);
$formhash =  addslashes($_GET['formhash'])? addslashes($_GET['formhash']):'';
loadcache('plugin');
global $_G, $lang;

if ($act == 'zhuxiao') {
    
    if ($formhash == FORMHASH && $_GET['zhuxiaosubmit']) {
        
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_zhuxiao'];
        
        $groupid = $_G['groupid'];
        if($_G['uid'] == 1 || $groupid == 1){
            echo json_encode(array('code' => -1,'data' => 'err_account_invalid'));
            exit;
        }
        
        if (!$_config['g_openmobilezhuxiao'] || !$_G['uid'] || !in_array($groupid, (array) unserialize($_config['g_groups']))){
            echo json_encode(array('code' => -1,'data' => 'err_group_invalid'));
            exit;
        }
        
        
        $seccode = addslashes($_GET['seccode']);
        $password = addslashes($_GET['password']);
        
        
        if(empty($seccode)){
            echo json_encode(array('code' => -1,'data' => 'seccodenull'));
            exit;
        }
        
        $olduser =  C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_member')->fetch_by_uid($_G['uid']);
        $oldmobile = $olduser['mobile'];

        $phone = $oldmobile;
        
        if(empty($phone)){
            echo json_encode(array('code' => -1,'data' => 'getoldmobilenull'));
            exit;
        }
        
        if (!preg_match("/^1[34578]{1}\d{9}$/", $phone)) {
            echo json_encode(array('code' => -1,'data' => 'bind_phone_error'));
            exit;
        }
        
        
        loaducenter();
        list($result) = uc_user_login($_G['uid'], $password, 1, 0);
        if ($result < 0){
            echo json_encode(array('code' => -1,'data' => 'err_mima'));
            exit;
        }
        
     
        
        $codeinfo = C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_code')->fetchfirst_by_phone_and_seccode($phone,$seccode);
        if ($codeinfo) {
            if ((TIMESTAMP - $codeinfo[dateline]) > $_config['g_youxiaoqi']) {
                C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_code')->deleteby_seccode_and_phone($phone,$seccode);
                
                echo json_encode(array('code' => -1,'data' => 'err_seccodeguoqi'));
                exit;
            }
        } else {
            echo json_encode(array('code' => -1,'data' => 'err_seccodeerror'));
            exit;
        }
        
        C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_code')->deleteby_seccode_and_phone($phone,$seccode);
        
        $data = array(
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'phone' => $phone,
            'dateline' => TIMESTAMP
        );
        
        C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_log')->insert($data,true);
        
        $uids = array();
        $uids[] = $_G['uid'];
        
        require_once libfile('function/delete');
        $numdeleted = deletemember($uids, 0);
        loaducenter();
        uc_user_delete($uids);
        
        
        echo json_encode(array('code' => 200,'data' => 'zhuxiaook'));
        exit;
        
    }else{
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_zhuxiao'];
        
        $mobilecolor = !empty($_config['g_mobilecolor'])?$_config['g_mobilecolor']:"#4eabe8";
        
        $groupid = $_G['groupid'];
        $isok = false;
        
        $bindmobileurl = "home.php?mod=spacecp&ac=profile&op=contact";
        
        if ($_config['g_openmobilezhuxiao'] && $_G['uid'] && in_array($groupid, (array) unserialize($_config['g_groups']))){
        
            $userinfo =  C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_member')->fetch_by_uid($_G['uid']);
            $bindmobile = $userinfo['mobile'];
      
            if(!empty($_config['g_mbindphone'])){
                $bindmobileurl = $_config['g_mbindphone'];
            }elseif($_G['cache']['plugin']['jzsjiale_sms']){
                $bindmobileurl = "plugin.php?id=jzsjiale_sms:mobile&act=bangding&mobile=2";
            }else{
                $bindmobileurl = "home.php?mod=spacecp&ac=profile&op=contact";
            }
            $isok = true;
        }
        
        include template('jzsjiale_zhuxiao:zhuxiao');
    }
    
}
//From: Dism_taobao_com
?>