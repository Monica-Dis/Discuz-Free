<?php


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$act = $_GET['act'];
loadcache('plugin');
global $_G, $lang;


require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_zhuxiao/smstools.inc.php';
require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_zhuxiao/utils.class.php';
$utils = new Utils();

if($act=='sendtest'){
    if(submitcheck('submit')){

        $setting = $_GET['setting'];
        $dsp = array();
        $dsp['phone'] = daddslashes(trim($setting['phone']));
         
        if(empty($dsp['phone'])){
            cpmsg('jzsjiale_zhuxiao:smssendphone_null', '', 'error');
        }

        if(!$utils->isMobile($dsp['phone'])){
            cpmsg('jzsjiale_zhuxiao:smssendphoneerror_null', '', 'error');
        }
        
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_zhuxiao'];
        $g_accesskeyid = $_config['g_accesskeyid'];
        $g_accesskeysecret = $_config['g_accesskeysecret'];
        $webbianma = $_G['charset'];
        $g_xiane = $_config['g_xiane'];
        $g_isopenhtmlspecialchars = !empty($_config['g_isopenhtmlspecialchars'])?true:false;
        
        if(empty($g_accesskeyid) || empty($g_accesskeysecret)){
            cpmsg('jzsjiale_zhuxiao:noappkey', '', 'error');
        }
        
        $phonesendcount = C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_smslist')->count_by_phone_day($dsp['phone']);
 
        if($phonesendcount >= $g_xiane){
            cpmsg('jzsjiale_zhuxiao:smsxiane', '', 'error');
        }
        
        $code = $utils->generate_code();
        
        if(empty($code) || $code == null){
            cpmsg('jzsjiale_zhuxiao:generatecodeerror', '', 'error');
        }
        
        $g_zhuxiaoid = $_config['g_zhuxiaoid'];
        $g_zhuxiaosign = $_config['g_zhuxiaosign'];
        
        if(empty($g_zhuxiaoid)){
            cpmsg('jzsjiale_zhuxiao:nozhuxiaoid', '', 'error');
        }
        if(empty($g_zhuxiaosign)){
            cpmsg('jzsjiale_zhuxiao:nozhuxiaosign', '', 'error');
        }
        
        
        $sms_param_array = array();
        $sms_param_array['code']=(string)$code;
   
        $sms_param = json_encode($sms_param_array);
      
        
        $g_zhuxiaosign=$utils->getbianma($g_zhuxiaosign,$webbianma,$g_isopenhtmlspecialchars);
        
        //quoqishijian
        $g_youxiaoqi = $_config['g_youxiaoqi'];
        if(empty($g_youxiaoqi)){
            $g_youxiaoqi = 600;
        }
        //echo "====".date('Y-m-d H:i:s',strtotime("+".$g_youxiaoqi." second"));exit;
        $expire = strtotime("+".$g_youxiaoqi." second");
       
        $uid = $_G['uid'];
        $smstools = new SMSTools();
        $smstools->__construct($g_accesskeyid, $g_accesskeysecret);
        $retdata = $smstools->smssend($code,$expire,0,$uid,$dsp['phone'],$g_zhuxiaosign,$g_zhuxiaoid,$sms_param);
        
        switch ($retdata){
            case 'success':
                cpmsg('jzsjiale_zhuxiao:smssuccess', '', 'success');
                break;
            case 'error':
                cpmsg('jzsjiale_zhuxiao:smserror', '', 'error');
                break;
            case 'isv.BUSINESS_LIMIT_CONTROL':
                cpmsg('jzsjiale_zhuxiao:smsBUSINESS_LIMIT_CONTROL', '', 'error');
                break;
            default:
                cpmsg('jzsjiale_zhuxiao:smserror', '', 'error');
                break;
        }
        exit();
    }

}

/////////tip start

echo '<div class="colorbox"><h4>'.plang('aboutsmssend').'</h4>'.
'<table cellspacing="0" cellpadding="3"><tr>'.
'<td valign="top">'.plang('smssenddescription').'</td></tr></table>'.
'<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

/////////tip end

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_zhuxiao&pmod=smssend&act=sendtest', 'enctype');
showtableheader(plang('smssendtitle'), '');
showsetting(plang('smssendphone'),'setting[phone]','','text','','',plang('smssendphone_msg'));

showsubmit('submit',plang('fasong'));
showtablefooter();
showformfooter();



function plang($str) {
    return lang('plugin/jzsjiale_zhuxiao', $str);
}
//From: Dism_taobao_com
?>