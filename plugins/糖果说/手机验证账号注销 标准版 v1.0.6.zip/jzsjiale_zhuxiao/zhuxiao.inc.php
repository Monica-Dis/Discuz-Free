<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


loadcache('plugin');
global $_G, $lang;

$formhash =  addslashes($_GET['formhash'])? addslashes($_GET['formhash']):'';

if ($formhash == FORMHASH) {

    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_zhuxiao'];
    
    $groupid = $_G['groupid'];
    if($_G['uid'] == 1 || $groupid == 1){
        showmessage(plang('err_account_invalid'));
    }
    
    if (!$_config['g_openpczhuxiao'] || !$_G['uid'] || !in_array($groupid, (array) unserialize($_config['g_groups']))){
        showmessage(plang('err_group_invalid'));
    }
    $seccode = daddslashes($_GET['seccode']);
    if (!$seccode){
        showmessage(plang('seccodenull'));
    }
    
    $olduser =  C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_member')->fetch_by_uid($_G['uid']);
    $oldmobile = $olduser['mobile'];
    
    if(empty($oldmobile)){
        showmessage(plang('getoldmobilenull'));
    }
    
    $phone = $oldmobile;
    
    if (!preg_match("/^1[34578]{1}\d{9}$/", $phone)) {
        showmessage(plang('bind_phone_error'));
    }
    
    loaducenter();
    list($result) = uc_user_login($_G['uid'], $_GET['password'], 1, 0);
    if ($result < 0){
        showmessage(plang('mimaerror'));
    }
    
    $codeinfo = C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_code')->fetchfirst_by_phone_and_seccode($phone,$seccode);
    if ($codeinfo) {
        if ((TIMESTAMP - $codeinfo[dateline]) > $_config['g_youxiaoqi']) {
            C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_code')->deleteby_seccode_and_phone($phone,$seccode);
            
            showmessage(plang('err_seccodeguoqi'));
        }
    } else {
        showmessage(plang('err_seccodeerror'));
    }

    C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_code')->deleteby_seccode_and_phone($phone,$seccode);
    
    
    $data = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'phone' => $phone,
        'dateline' => TIMESTAMP
    );
    
    C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_log')->insert($data,true);
    
    $uids = array();
    $uids[] = $_G['uid'];
    
    require_once libfile('function/delete');
    $numdeleted = deletemember($uids, 0);
    loaducenter();
    uc_user_delete($uids);
    
    showmessage(plang('zhuxiaook'), $_G['siteurl'], array(), array('alert' => 'right', 'locationtime' => true, 'msgtype' => 2, 'showdialog' => true, 'showmsg' => true));
    
}else{
    global $_G;
    $_config = $_G['cache']['plugin']['jzsjiale_zhuxiao'];
    
    $groupid = $_G['groupid'];
    $isok = false;
    
    $bindmobileurl = "home.php?mod=spacecp&ac=profile&op=contact";
    
    if ($_config['g_openpczhuxiao'] && $_G['uid'] && in_array($groupid, (array) unserialize($_config['g_groups']))){
        
        $userinfo =  C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_member')->fetch_by_uid($_G['uid']);
        $bindmobile = $userinfo['mobile'];
        
        if(!empty($_config['g_bindphone'])){
            $bindmobileurl = $_config['g_bindphone'];
        }elseif($_G['cache']['plugin']['jzsjiale_sms']){
            $bindmobileurl = "home.php?mod=spacecp&ac=plugin&id=jzsjiale_sms:home";
        }else{
            $bindmobileurl = "home.php?mod=spacecp&ac=profile&op=contact";
        }
        $isok = true;
    }
    
}


function plang($str) {
    return lang('plugin/jzsjiale_zhuxiao', $str);
}
//From: Dism_taobao_com
?>