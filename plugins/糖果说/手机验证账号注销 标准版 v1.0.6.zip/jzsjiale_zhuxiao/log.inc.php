<?php


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
loadcache('plugin');
global $_G, $lang;


require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_zhuxiao/utils.class.php';
$utils = new Utils();


/////////tip start

echo '<div class="colorbox"><h4>'.plang('aboutlog').'</h4>'.
    '<table cellspacing="0" cellpadding="3"><tr>'.
    '<td valign="top">'.plang('logdescription').'</td></tr></table>'.
    '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

/////////tip end

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_zhuxiao&pmod=log', 'enctype');


$keyword = daddslashes(trim($_GET['keyword']));

$page = intval($_GET['page']);
$page = $page > 0 ? $page : 1;
$pagesize = 20;
$start = ($page - 1) * $pagesize;

//20170703start
$map = array();
if(!empty($keyword)){
    $map['keyword'] = $keyword;
}


$alllog = C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_log')->range_by_map($map,$start,$pagesize,'DESC');
$count = C::t('#jzsjiale_zhuxiao#jzsjiale_zhuxiao_log')->count_by_map($map);


showtablerow('', array('width="150"', 'width="150"', 'width="150"', ''), array(
plang('userphone'),
"<input size=\"20\" name=\"keyword\" type=\"text\" value=\"$keyword\" />
<input class=\"btn\" type=\"submit\" value=\"" . cplang('search') . "\" />"
    )
);

showtableheader(plang('loglist').'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(<span style="color:red;">'.plang('yiyou').$count.plang('yonghuzhuxiao').'</span>)');
showsubtitle(plang('loglisttitle'));
foreach($alllog as $d){
    showtablerow('', array('width="50"'), array(
    $d['id'],
    $d['uid'],
    $d['username'],
    $d['phone'],
    dgmdate($d['dateline']))
    );
}

$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_zhuxiao&pmod=log&keyword='.$keyword;
$multipage = multi($count, $pagesize, $page, $mpurl);
//showsubmit('', '', '', '', $multipage);


//search start
showsubmit('', '', '', '', $multipage);

//search end


showtablefooter();
showformfooter();

function plang($str) {
    return lang('plugin/jzsjiale_zhuxiao', $str);
}
//From: Dism_taobao_com
?>