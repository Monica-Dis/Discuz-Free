<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `pre_jzsjiale_zhuxiao_log`;
CREATE TABLE `pre_jzsjiale_zhuxiao_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11)  NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `phone` bigint(20) unsigned NOT NULL,
  `dateline` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
   INDEX phone_name (`phone`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_jzsjiale_zhuxiao_code`;
CREATE TABLE `pre_jzsjiale_zhuxiao_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11)  NULL DEFAULT '0',
  `phone` bigint(20) unsigned NOT NULL,
  `seccode` varchar(50) NOT NULL DEFAULT '000000',
  `expire` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
   INDEX phone_name (`phone`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_jzsjiale_zhuxiao_smslist`;
CREATE TABLE `pre_jzsjiale_zhuxiao_smslist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11)  NULL DEFAULT '0',
  `phone` bigint(20) unsigned NOT NULL,
  `seccode` varchar(50) NOT NULL DEFAULT '000000',
  `msg` varchar(999) NOT NULL DEFAULT '',
  `type` int(10) unsigned NOT NULL DEFAULT '0',
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
   INDEX phone_name (`phone`)
) ENGINE=MyISAM;
EOF;
runquery ( $sql );


@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_zhuxiao/discuz_plugin_jzsjiale_zhuxiao.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_zhuxiao/discuz_plugin_jzsjiale_zhuxiao_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_zhuxiao/discuz_plugin_jzsjiale_zhuxiao_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_zhuxiao/discuz_plugin_jzsjiale_zhuxiao_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_zhuxiao/discuz_plugin_jzsjiale_zhuxiao_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_zhuxiao/install.php');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_zhuxiao/upgrade.php');

$finish = TRUE;
?>