<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_jzsjiale_zhuxiao {
   
    function global_footer_mobile() {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_zhuxiao'];
    
        if (!$_G['uid']){
            return;
        }
        
        $basescript = $_G['basescript'];
        $curm = CURMODULE;
        
        if($basescript != "home" || $curm != "space" || empty($_GET[mycenter])){
            return;
        }
    
        if (!$_config['g_openmobilezhuxiaobtn']){
            return;
        }
        
        
        if($_config['g_openmobilezhuxiaobtn']) {
            include_once template('jzsjiale_zhuxiao:zhuxiaobtn');
            return $bangdingbtn;
        }
    
    }
}
//From: Dism_taobao_com
?>