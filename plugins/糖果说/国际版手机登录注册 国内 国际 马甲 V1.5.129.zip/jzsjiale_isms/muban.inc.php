<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;
require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/setting.class.php';
JzsjialeIsmsSetting::menu();

$type = daddslashes($_GET['type']);
$type = !empty($type)?$type:'pc';

if($type == 'pc'){
    if(!submitcheck('settingsubmit')) {

        $setting = C::t('common_setting')->fetch_all(array('jsms_muban_pc'));
        $setting = (array)unserialize($setting['jsms_muban_pc']);

        showtips(lang('plugin/jzsjiale_isms', 'muban_pc_tips'));

        showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=pc', 'enctype');

        showsubmit('settingsubmit', 'submit');

        showtableheader(plang('menu_pc_settings_title'), '', 'id="pc_settings"');

        $pctemplateselectvalue = 'default';
        if(!empty($setting["pctemplate"])){
            $pctemplateselectvalue = $setting["pctemplate"];
        }
        $templates = getDir('pc');

        $pctemplateselect ='';
        foreach ($templates as $key => $value){
            $pctemplateselect .= '<option value="'.$value['dir'].'" '.($setting["pctemplate"]==$value['dir']?'selected':'').'>'.unicodeDecode($value['title']).'</option>';
        }
        if(empty($pctemplateselect)){
            $pctemplateselect .= '<option value="default" selected>'.unicodeDecode('\u9ed8\u8ba4\u6a21\u677f').'</option>';
        }
        showsetting(plang('menu_pc_template'),'setting[pctemplate]','','<select name="setting[pctemplate]">'.$pctemplateselect.'</select>','',0,plang('menu_pc_template_msg'),1,'menu_pc_template');
        $securitycdnselect = '<option value="0" '.((empty($setting["cdn"]) || $setting["cdn"]=='0')?'selected':'').'>'.plang('menu_cdn_0').'</option>';
        $securitycdnselect .= '<option value="1" '.($setting["cdn"]=='1'?'selected':'').'>'.plang('menu_cdn_1').'</option>';
        $securitycdnselect .= '<option value="2" '.($setting["cdn"]=='2'?'selected':'').'>'.plang('menu_cdn_2').'</option>';
        $securitycdnselect .= '<option value="3" '.($setting["cdn"]=='3'?'selected':'').'>'.plang('menu_cdn_3').'</option>';
        $securitycdnselect .= '<option value="4" '.($setting["cdn"]=='4'?'selected':'').'>'.plang('menu_cdn_4').'</option>';
        showsetting(plang('menu_pc_cdn'),'setting[cdn]','','<select name="setting[cdn]">'.$securitycdnselect.'</select>','','',plang('menu_pc_cdn_msg'));
        showsetting(plang('menu_pc_vuedebug'),'setting[vuedebug]',$setting["vuedebug"],'radio','','',plang('menu_pc_vuedebug_msg'));
        showsetting(plang('menu_pc_title'),'setting[title]',$setting["title"],'text','','',plang('menu_pc_title_msg'));
        showsetting(plang('menu_pc_logo'), 'logo', $setting["logo"], 'filetext','','',plang('menu_pc_logo_msg'),'','menu_pc_logo_msg');
        showsetting(plang('menu_pc_title_color'),'setting[titlecolor]',(!empty($setting["titlecolor"])?$setting["titlecolor"]:"#46a3fd"),'color','','',plang('menu_pc_title_color_msg'));
        showsetting(plang('menu_pc_registerdesc'),'setting[registerdesc]',$setting["registerdesc"],'text','','',plang('menu_pc_registerdesc_msg'));
        showsetting(plang('menu_pc_logindesc'),'setting[logindesc]',$setting["logindesc"],'text','','',plang('menu_pc_logindesc_msg'));
        showsetting(plang('menu_pc_lostpasswddesc'),'setting[lostpasswddesc]',$setting["lostpasswddesc"],'text','','',plang('menu_pc_lostpasswddesc_msg'));
        showsetting(plang('menu_pc_getpasswddesc'),'setting[getpasswddesc]',$setting["getpasswddesc"],'text','','',plang('menu_pc_getpasswddesc_msg'));
        showsetting(plang('menu_pc_desc_color'),'setting[desccolor]',(!empty($setting["desccolor"])?$setting["desccolor"]:"#46a3fd"),'color','','',plang('menu_pc_desc_color_msg'));
        showsetting(plang('menu_pc_bg_color'),'setting[bgcolor]',$setting["bgcolor"],'color','','',plang('menu_pc_bg_color_msg'));
        showsetting(plang('menu_pc_bg_img'), 'bgimg', $setting["bgimg"], 'filetext','','',plang('menu_pc_bg_img_msg'),'','menu_pc_bg_img_msg');
        showsetting(plang('menu_pc_bg_video'), 'setting[bgvideo]', $setting["bgvideo"], 'text','','',plang('menu_pc_bg_video_msg'));
        showsetting(plang('menu_pc_bg_video_ismuted'),'setting[ismuted]',(!is_null($setting["ismuted"])?$setting["ismuted"]:"1"),'radio','','',plang('menu_pc_bg_video_ismuted_msg'));
        showsetting(plang('menu_pc_bg_video_usermuted'),'setting[usermuted]',(!is_null($setting["usermuted"])?$setting["usermuted"]:"0"),'radio','','',plang('menu_pc_bg_video_usermuted_msg'));
        showsetting(plang('menu_pc_bg_720yun'), 'setting[bg720yun]', $setting["bg720yun"], 'text','','',plang('menu_pc_bg_720yun_msg'));
        showsetting(plang('menu_pc_favicon'), 'favicon', $setting["favicon"], 'filetext','','',plang('menu_pc_favicon_msg'),'','menu_pc_favicon_msg');
        showsetting(plang('menu_pc_headertitle'),'setting[headertitle]',$setting["headertitle"],'text','','',plang('menu_pc_headertitle_msg'));
        showsetting(plang('menu_pc_headerdescription'),'setting[headerdescription]',$setting["headerdescription"],'textarea','','',plang('menu_pc_headerdescription_msg'));
        showsetting(plang('menu_pc_headerkeywords'),'setting[headerkeywords]',$setting["headerkeywords"],'textarea','','',plang('menu_pc_headerkeywords_msg'));
        showsetting(plang('menu_pc_xieyi_tip'),'setting[xieyitip]',$setting["xieyitip"],'text','','',plang('menu_pc_xieyi_tip_msg'));
        showsetting(plang('menu_pc_xieyi_title'),'setting[xieyititle]',$setting["xieyititle"],'text','','',plang('menu_pc_xieyi_title_msg'));
        showsetting(plang('menu_pc_xieyidefault'),'setting[xieyidefault]',$setting["xieyidefault"],'radio','','',plang('menu_pc_xieyidefault_msg'));
        showsetting(plang('menu_pc_xieyi_content'),'setting[xieyicontent]',$setting["xieyicontent"],'textarea','','',plang('menu_pc_xieyi_content_msg'));
        showsetting(plang('menu_pc_yinsi_title'),'setting[yinsititle]',$setting["yinsititle"],'text','','',plang('menu_pc_yinsi_title_msg'));
        showsetting(plang('menu_pc_yinsi_content'),'setting[yinsicontent]',$setting["yinsicontent"],'textarea','','',plang('menu_pc_yinsi_content_msg'));
        showsetting(plang('menu_pc_readagreement'),'setting[readagreement]',$setting["readagreement"],'radio','','',plang('menu_pc_readagreement_msg'));
        showsetting(plang('menu_pc_defaultreadagreement'),'setting[defaultreadagreement]',$setting["defaultreadagreement"],'radio','','',plang('menu_pc_defaultreadagreement_msg'));
        showsetting(plang('menu_pc_readagreementtip'),'setting[readagreementtip]',$setting["readagreementtip"],'text','','',plang('menu_pc_readagreementtip_msg'));
        showsetting(plang('menu_pc_btntext_color'),'setting[btntextcolor]',(!empty($setting["btntextcolor"])?$setting["btntextcolor"]:"#ffffff"),'color','','',plang('menu_pc_btntext_color_msg'));
        showsetting(plang('menu_pc_btnbackground_color'),'setting[btnbackgroundcolor]',(!empty($setting["btnbackgroundcolor"])?$setting["btnbackgroundcolor"]:"#0084ff"),'color','','',plang('menu_pc_btnbackground_color_msg'));
        showsetting(plang('menu_pc_btnbackgroundhover_color'),'setting[btnbackgroundhovercolor]',(!empty($setting["btnbackgroundhovercolor"])?$setting["btnbackgroundhovercolor"]:""),'color','','',plang('menu_pc_btnbackgroundhover_color_msg'));
        showsetting(plang('menu_pc_btna_color'),'setting[btnacolor]',(!empty($setting["btnacolor"])?$setting["btnacolor"]:""),'color','','',plang('menu_pc_btna_color_msg'));
        showsetting(plang('menu_pc_pianyi'),'setting[pianyi]',$setting["pianyi"],'text','','',plang('menu_pc_pianyi_msg'));
        showsetting(plang('menu_pc_isshowappdownloadbtn'),'setting[isshowappdownloadbtn]',$setting["isshowappdownloadbtn"],'radio','','',plang('menu_pc_isshowappdownloadbtn_msg'));
        showsetting(plang('menu_pc_appdownloadtitle'),'setting[appdownloadtitle]',$setting["appdownloadtitle"],'text','','',plang('menu_pc_appdownloadtitle_msg'));
        showsetting(plang('menu_pc_appdownloadclosetitle'),'setting[appdownloadclosetitle]',$setting["appdownloadclosetitle"],'text','','',plang('menu_pc_appdownloadclosetitle_msg'));
        showsetting(plang('menu_pc_appdownload_color'),'setting[appdownloadcolor]',(!empty($setting["appdownloadcolor"])?$setting["appdownloadcolor"]:"#8590a6"),'color','','',plang('menu_pc_appdownload_color_msg'));
        //app qr image start
        showsetting(plang('menu_pc_appqrtitleandroid_title'),'setting[appqrtitleandroid]',$setting["appqrtitleandroid"],'text','','',plang('menu_pc_appqrtitleandroid_title_msg'));
        showsetting(plang('menu_pc_appqrimageandroid'), 'appqrimageandroid', $setting["appqrimageandroid"], 'filetext','','',plang('menu_pc_appqrimageandroid_msg'),'','menu_pc_appqrimageandroid_msg');
        showsetting(plang('menu_pc_appqrtitleios_title'),'setting[appqrtitleios]',$setting["appqrtitleios"],'text','','',plang('menu_pc_appqrtitleios_title_msg'));
        showsetting(plang('menu_pc_appqrimageios'), 'appqrimageios', $setting["appqrimageios"], 'filetext','','',plang('menu_pc_appqrimageios_msg'),'','menu_pc_appqrimageios_msg');
        showsetting(plang('menu_pc_appqrtitlewxminapp_title'),'setting[appqrtitlewxminapp]',$setting["appqrtitlewxminapp"],'text','','',plang('menu_pc_appqrtitlewxminapp_title_msg'));
        showsetting(plang('menu_pc_appqrimagewxminapp'), 'appqrimagewxminapp', $setting["appqrimagewxminapp"], 'filetext','','',plang('menu_pc_appqrimagewxminapp_msg'),'','menu_pc_appqrimagewxminapp_msg');
        showsetting(plang('menu_pc_appqrtitlebaiduminapp_title'),'setting[appqrtitlebaiduminapp]',$setting["appqrtitlebaiduminapp"],'text','','',plang('menu_pc_appqrtitlebaiduminapp_title_msg'));
        showsetting(plang('menu_pc_appqrimagebaiduminapp'), 'appqrimagebaiduminapp', $setting["appqrimagebaiduminapp"], 'filetext','','',plang('menu_pc_appqrimagebaiduminapp_msg'),'','menu_pc_appqrimagebaiduminapp_msg');
        showsetting(plang('menu_pc_appqrtitletoutiaominapp_title'),'setting[appqrtitletoutiaominapp]',$setting["appqrtitletoutiaominapp"],'text','','',plang('menu_pc_appqrtitletoutiaominapp_title_msg'));
        showsetting(plang('menu_pc_appqrimagetoutiaominapp'), 'appqrimagetoutiaominapp', $setting["appqrimagetoutiaominapp"], 'filetext','','',plang('menu_pc_appqrimagetoutiaominapp_msg'),'','menu_pc_appqrimagetoutiaominapp_msg');
        showsetting(plang('menu_pc_appqrtitlealipayminapp_title'),'setting[appqrtitlealipayminapp]',$setting["appqrtitlealipayminapp"],'text','','',plang('menu_pc_appqrtitlealipayminapp_title_msg'));
        showsetting(plang('menu_pc_appqrimagealipayminapp'), 'appqrimagealipayminapp', $setting["appqrimagealipayminapp"], 'filetext','','',plang('menu_pc_appqrimagealipayminapp_msg'),'','menu_pc_appqrimagealipayminapp_msg');
        showsetting(plang('menu_pc_appqrtitleqqminapp_title'),'setting[appqrtitleqqminapp]',$setting["appqrtitleqqminapp"],'text','','',plang('menu_pc_appqrtitleqqminapp_title_msg'));
        showsetting(plang('menu_pc_appqrimageqqminapp'), 'appqrimageqqminapp', $setting["appqrimageqqminapp"], 'filetext','','',plang('menu_pc_appqrimageqqminapp_msg'),'','menu_pc_appqrimageqqminapp_msg');
        showsetting(plang('menu_pc_appqrtitlekuaiminapp_title'),'setting[appqrtitlekuaiminapp]',$setting["appqrtitlekuaiminapp"],'text','','',plang('menu_pc_appqrtitlekuaiminapp_title_msg'));
        showsetting(plang('menu_pc_appqrimagekuaiminapp'), 'appqrimagekuaiminapp', $setting["appqrimagekuaiminapp"], 'filetext','','',plang('menu_pc_appqrimagekuaiminapp_msg'),'','menu_pc_appqrimagekuaiminapp_msg');
        //app qr image end
        //app footer start
        showsetting(plang('menu_pc_footer_color'),'setting[footercolor]',$setting["footercolor"],'color','','',plang('menu_pc_footer_color_msg'));
        showsetting(plang('menu_pc_footershadow_color'),'setting[footershadowcolor]',$setting["footershadowcolor"],'color','','',plang('menu_pc_footershadow_color_msg'));
        showsetting(plang('menu_pc_footerlinks'),'setting[footerlinks]',$setting["footerlinks"],'textarea','','',plang('menu_pc_footerlinks_msg'));
        showsetting(plang('menu_pc_footercopyright'),'setting[footercopyright]',$setting["footercopyright"],'textarea','','',plang('menu_pc_footercopyright_msg'));
        showsetting(plang('menu_pc_footerother'),'setting[footerother]',$setting["footerother"],'textarea','','',plang('menu_pc_footerother_msg'));
        //app footer end
        //social footer start
        showsetting(plang('menu_pc_isshowsocial'),'setting[isshowsocial]',$setting["isshowsocial"],'radio','','',plang('menu_pc_isshowsocial_msg'));
        showsetting(plang('menu_pc_social_tip'),'setting[socialtip]',$setting["socialtip"],'text','','',plang('menu_pc_social_tip_msg'));
        $apptypeselect = '<option value="none" '.((empty($setting["apptype"]) || $setting["apptype"]=='none')?'selected':'').'>'.plang('menu_apptype_none').'</option>';
        $apptypeselect .= '<option value="zimu" '.($setting["apptype"]=='zimu'?'selected':'').'>'.plang('menu_apptype_zimu').'</option>';
        $apptypeselect .= '<option value="duceapp" '.($setting["apptype"]=='duceapp'?'selected':'').'>'.plang('menu_apptype_duceapp').'</option>';
        showsetting(plang('menu_pc_apptype'),'setting[apptype]','','<select name="setting[apptype]">'.$apptypeselect.'</select>','','',plang('menu_pc_apptype_msg'));
        showsetting(plang('menu_pc_apptitle'),'setting[apptitle]',$setting["apptitle"],'text','','',plang('menu_pc_apptitle_msg'));
        $defaultweixinselect = '<option value="0" '.((empty($setting["defaultweixin"]) || $setting["defaultweixin"]=='0')?'selected':'').'>'.plang('menu_defaultweixin_none').'</option>';
        $defaultweixinselect .= '<option value="1" '.($setting["defaultweixin"]=='1'?'selected':'').'>'.plang('menu_defaultweixin_weixin').'</option>';
        $defaultweixinselect .= '<option value="2" '.($setting["defaultweixin"]=='2'?'selected':'').'>'.plang('menu_defaultweixin_app').'</option>';
        showsetting(plang('menu_pc_defaultweixin'),'setting[defaultweixin]','','<select name="setting[defaultweixin]">'.$defaultweixinselect.'</select>','','',plang('menu_pc_defaultweixin_msg'));
        $weixintypeselect = '<option value="diy" '.((empty($setting["weixintype"]) || $setting["weixintype"]=='diy')?'selected':'').'>'.plang('menu_weixintype_diy').'</option>';
        $weixintypeselect .= '<option value="xigua" '.($setting["weixintype"]=='xigua'?'selected':'').'>'.plang('menu_weixintype_xigua').'</option>';
        $weixintypeselect .= '<option value="comiis" '.($setting["weixintype"]=='comiis'?'selected':'').'>'.plang('menu_weixintype_comiis').'</option>';
        $weixintypeselect .= '<option value="strong" '.($setting["weixintype"]=='strong'?'selected':'').'>'.plang('menu_weixintype_strong').'</option>';
        $weixintypeselect .= '<option value="weiqing" '.($setting["weixintype"]=='weiqing'?'selected':'').'>'.plang('menu_weixintype_weiqing').'</option>';
        $weixintypeselect .= '<option value="zimucms" '.($setting["weixintype"]=='zimucms'?'selected':'').'>'.plang('menu_weixintype_zimucms').'</option>';
        $weixintypeselect .= '<option value="feiniao" '.($setting["weixintype"]=='feiniao'?'selected':'').'>'.plang('menu_weixintype_feiniao').'</option>';
        $weixintypeselect .= '<option value="pn" '.($setting["weixintype"]=='pn'?'selected':'').'>'.plang('menu_weixintype_pn').'</option>';
        $weixintypeselect .= '<option value="duceapp" '.($setting["weixintype"]=='duceapp'?'selected':'').'>'.plang('menu_weixintype_duceapp').'</option>';
        $weixintypeselect .= '<option value="kekewxlogin" '.($setting["weixintype"]=='kekewxlogin'?'selected':'').'>'.plang('menu_weixintype_kekewxlogin').'</option>';
        $weixintypeselect .= '<option value="1314wxlogin" '.($setting["weixintype"]=='1314wxlogin'?'selected':'').'>'.plang('menu_weixintype_1314wxlogin').'</option>';
        showsetting(plang('menu_pc_weixintype'),'setting[weixintype]','','<select name="setting[weixintype]">'.$weixintypeselect.'</select>','','',plang('menu_pc_weixintype_msg'));
        showsetting(plang('menu_pc_weixinbtn'),'setting[weixinbtn]',$setting["weixinbtn"],'radio','','',plang('menu_pc_weixinbtn_msg'));
        $weixintypetipselect = '<option value="0" '.((empty($setting["weixintypetip"]) || $setting["weixintypetip"]=='0')?'selected':'').'>'.plang('menu_weixintypetip_0').'</option>';
        $weixintypetipselect .= '<option value="1" '.($setting["weixintypetip"]=='1'?'selected':'').'>'.plang('menu_weixintypetip_1').'</option>';
        $weixintypetipselect .= '<option value="2" '.($setting["weixintypetip"]=='2'?'selected':'').'>'.plang('menu_weixintypetip_2').'</option>';
        showsetting(plang('menu_pc_weixintypetip'),'setting[weixintypetip]','','<select name="setting[weixintypetip]">'.$weixintypetipselect.'</select>','','',plang('menu_pc_weixintypetip_msg'));
        showsetting(plang('menu_pc_weixinurl'),'setting[weixinurl]',$setting["weixinurl"],'text','','',plang('menu_pc_weixinurl_msg'));
        showsetting(plang('menu_pc_qqurl'),'setting[qqurl]',$setting["qqurl"],'text','','',plang('menu_pc_qqurl_msg'));
        showsetting(plang('menu_pc_weibourl'),'setting[weibourl]',$setting["weibourl"],'text','','',plang('menu_pc_weibourl_msg'));
        showsetting(plang('menu_pc_googleurl'),'setting[googleurl]',$setting["googleurl"],'text','','',plang('menu_pc_googleurl_msg'));
        showsetting(plang('menu_pc_facebookurl'),'setting[facebookurl]',$setting["facebookurl"],'text','','',plang('menu_pc_facebookurl_msg'));
        showsetting(plang('menu_pc_twitterurl'),'setting[twitterurl]',$setting["twitterurl"],'text','','',plang('menu_pc_twitterurl_msg'));
        showsetting(plang('menu_pc_weiruanurl'),'setting[weiruanurl]',$setting["weiruanurl"],'text','','',plang('menu_pc_weiruanurl_msg'));
        showsetting(plang('menu_pc_socialcolor'),'setting[socialcolor]',$setting["socialcolor"],'color','','',plang('menu_pc_socialcolor_msg'));
        showsetting(plang('menu_pc_sociatitle'),'setting[sociatitle]',$setting["sociatitle"],'radio','','',plang('menu_pc_sociatitle_msg'));
        //social footer end
        showsetting(plang('menu_pc_extendcss'),'setting[extendcss]',$setting["extendcss"],'textarea','','',plang('menu_pc_extendcss_msg'));

        showtablefooter(); /*Dism��taobao��com*/
        showtableheader(plang('menu_pc_security_settings_title'), '', 'id="pc_security_settings"');
        showsetting(plang('menu_pc_security_title'),'setting[securitytitle]',$setting["securitytitle"],'text','','',plang('menu_pc_security_title_msg'));
        showsetting(plang('menu_pc_security_title_color'),'setting[securitytitlecolor]',(!empty($setting["securitytitlecolor"])?$setting["securitytitlecolor"]:"#46a3fd"),'color','','',plang('menu_pc_security_title_color_msg'));
        showsetting(plang('menu_pc_security_favicon'), 'securityfavicon', $setting["securityfavicon"], 'filetext','','',plang('menu_pc_security_favicon_msg'),'','menu_pc_security_favicon_msg');
        showsetting(plang('menu_pc_security_headertitle'),'setting[securityheadertitle]',$setting["securityheadertitle"],'text','','',plang('menu_pc_security_headertitle_msg'));
        showsetting(plang('menu_pc_security_headerdescription'),'setting[securityheaderdescription]',$setting["securityheaderdescription"],'textarea','','',plang('menu_pc_security_headerdescription_msg'));
        showsetting(plang('menu_pc_security_headerkeywords'),'setting[securityheaderkeywords]',$setting["securityheaderkeywords"],'textarea','','',plang('menu_pc_security_headerkeywords_msg'));
        showsetting(plang('menu_pc_security_btntext_color'),'setting[securitybtntextcolor]',(!empty($setting["securitybtntextcolor"])?$setting["securitybtntextcolor"]:"#ffffff"),'color','','',plang('menu_pc_security_btntext_color_msg'));
        showsetting(plang('menu_pc_security_btnbackground_color'),'setting[securitybtnbackgroundcolor]',(!empty($setting["securitybtnbackgroundcolor"])?$setting["securitybtnbackgroundcolor"]:"#0084ff"),'color','','',plang('menu_pc_security_btnbackground_color_msg'));

        $securitynavnumselect = '<option value="999" '.((empty($setting["securitynavnum"]) || $setting["securitynavnum"]=='999')?'selected':'').'>'.plang('norestriction').'</option>';
        for ($n=0; $n<=30; $n++){
            $securitynavnumselect .= '<option value="'.$n.'" '.((strlen($setting["securitynavnum"]) > 0 && $setting["securitynavnum"]==$n)?'selected':'').'>'.$n.'</option>';
        }
        showsetting(plang('menu_pc_security_securitynavnum'),'setting[securitynavnum]','','<select name="setting[securitynavnum]">'.$securitynavnumselect.'</select>','',0,plang('menu_pc_security_securitynavnum_msg'),1,'menu_pc_security_securitynavnum');
        showsetting(plang('menu_pc_security_extendcss'),'setting[securityextendcss]',$setting["securityextendcss"],'textarea','','',plang('menu_pc_security_extendcss_msg'));

        showtablefooter(); /*Dism��taobao��com*/

        showsubmit('settingsubmit', 'submit');

        showformfooter(); /*Dism_taobao_com*/

    }else{


        $setting = $_GET['setting'];

        if($_FILES['logo']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['logo'], 'common') && $upload->save(1)) {
                $setting['logo'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['logo'] = !empty($_GET['logo'])?trim($_GET['logo']):"";
        }

        if($_FILES['favicon']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['favicon'], 'common') && $upload->save(1)) {
                $setting['favicon'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['favicon'] = !empty($_GET['favicon'])?trim($_GET['favicon']):"";
        }

        if($_FILES['bgimg']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['bgimg'], 'common') && $upload->save(1)) {
                $setting['bgimg'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['bgimg'] = !empty($_GET['bgimg'])?trim($_GET['bgimg']):"";
        }

        //app qr image start

        if($_FILES['appqrimageandroid']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['appqrimageandroid'], 'common') && $upload->save(1)) {
                $setting['appqrimageandroid'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['appqrimageandroid'] = !empty($_GET['appqrimageandroid'])?trim($_GET['appqrimageandroid']):"";
        }

        if($_FILES['appqrimageios']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['appqrimageios'], 'common') && $upload->save(1)) {
                $setting['appqrimageios'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['appqrimageios'] = !empty($_GET['appqrimageios'])?trim($_GET['appqrimageios']):"";
        }

        if($_FILES['appqrimagewxminapp']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['appqrimagewxminapp'], 'common') && $upload->save(1)) {
                $setting['appqrimagewxminapp'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['appqrimagewxminapp'] = !empty($_GET['appqrimagewxminapp'])?trim($_GET['appqrimagewxminapp']):"";
        }

        if($_FILES['appqrimagebaiduminapp']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['appqrimagebaiduminapp'], 'common') && $upload->save(1)) {
                $setting['appqrimagebaiduminapp'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['appqrimagebaiduminapp'] = !empty($_GET['appqrimagebaiduminapp'])?trim($_GET['appqrimagebaiduminapp']):"";
        }

        if($_FILES['appqrimagetoutiaominapp']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['appqrimagetoutiaominapp'], 'common') && $upload->save(1)) {
                $setting['appqrimagetoutiaominapp'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['appqrimagetoutiaominapp'] = !empty($_GET['appqrimagetoutiaominapp'])?trim($_GET['appqrimagetoutiaominapp']):"";
        }

        if($_FILES['appqrimagealipayminapp']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['appqrimagealipayminapp'], 'common') && $upload->save(1)) {
                $setting['appqrimagealipayminapp'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['appqrimagealipayminapp'] = !empty($_GET['appqrimagealipayminapp'])?trim($_GET['appqrimagealipayminapp']):"";
        }

        if($_FILES['appqrimageqqminapp']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['appqrimageqqminapp'], 'common') && $upload->save(1)) {
                $setting['appqrimageqqminapp'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['appqrimageqqminapp'] = !empty($_GET['appqrimageqqminapp'])?trim($_GET['appqrimageqqminapp']):"";
        }

        if($_FILES['appqrimagekuaiminapp']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['appqrimagekuaiminapp'], 'common') && $upload->save(1)) {
                $setting['appqrimagekuaiminapp'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['appqrimagekuaiminapp'] = !empty($_GET['appqrimagekuaiminapp'])?trim($_GET['appqrimagekuaiminapp']):"";
        }
        //app qr image end

        if($_FILES['securityfavicon']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['securityfavicon'], 'common') && $upload->save(1)) {
                $setting['securityfavicon'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['securityfavicon'] = !empty($_GET['securityfavicon'])?trim($_GET['securityfavicon']):"";
        }

        $settings = array('jsms_muban_pc' => serialize($setting));
        C::t('common_setting')->update_batch($settings);

        updatecache('setting');

        cpmsg('setting_update_succeed', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=pc', 'succeed');
    }

}elseif ($type == 'mobile'){
    if(!submitcheck('settingsubmit')) {


        $setting = C::t('common_setting')->fetch_all(array('jsms_muban_mobile'));
        $setting = (array)unserialize($setting['jsms_muban_mobile']);

        showtips(lang('plugin/jzsjiale_isms', 'muban_mobile_tips'));

        showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=mobile', 'enctype');

        showsubmit('settingsubmit', 'submit');

        showtableheader(plang('menu_mobile_settings_title'), '', 'id="mobile_settings"');


        $mobiletemplateselectvalue = 'default';
        if(!empty($setting["mobiletemplate"])){
            $mobiletemplateselectvalue = $setting["mobiletemplate"];
        }

        $templates = getDir('touch/frontend');

        $mobiletemplateselect ='';
        foreach ($templates as $key => $value){
            $mobiletemplateselect .= '<option value="'.$value['dir'].'" '.($setting["mobiletemplate"]==$value['dir']?'selected':'').'>'.unicodeDecode($value['title']).'</option>';
        }
        if(empty($mobiletemplateselect)){
            $mobiletemplateselect .= '<option value="default" selected>'.unicodeDecode('\u9ed8\u8ba4\u6a21\u677f').'</option>';
        }


        showsetting(plang('menu_mobile_template'),'setting[mobiletemplate]','','<select name="setting[mobiletemplate]">'.$mobiletemplateselect.'</select>','',0,plang('menu_mobile_template_msg'),1,'menu_mobile_template');
        $securitycdnselect = '<option value="0" '.((empty($setting["cdn"]) || $setting["cdn"]=='0')?'selected':'').'>'.plang('menu_cdn_0').'</option>';
        $securitycdnselect .= '<option value="1" '.($setting["cdn"]=='1'?'selected':'').'>'.plang('menu_cdn_1').'</option>';
        $securitycdnselect .= '<option value="2" '.($setting["cdn"]=='2'?'selected':'').'>'.plang('menu_cdn_2').'</option>';
        $securitycdnselect .= '<option value="3" '.($setting["cdn"]=='3'?'selected':'').'>'.plang('menu_cdn_3').'</option>';
        $securitycdnselect .= '<option value="4" '.($setting["cdn"]=='4'?'selected':'').'>'.plang('menu_cdn_4').'</option>';
        showsetting(plang('menu_mobile_cdn'),'setting[cdn]','','<select name="setting[cdn]">'.$securitycdnselect.'</select>','','',plang('menu_mobile_cdn_msg'));
        showsetting(plang('menu_mobile_vuedebug'),'setting[vuedebug]',$setting["vuedebug"],'radio','','',plang('menu_mobile_vuedebug_msg'));
        showsetting(plang('menu_mobile_title'),'setting[title]',$setting["title"],'text','','',plang('menu_mobile_title_msg'));
        showsetting(plang('menu_mobile_logo'), 'logo', $setting["logo"], 'filetext','','',plang('menu_mobile_logo_msg'),'','menu_mobile_logo_msg');
        showsetting(plang('menu_mobile_title_color'),'setting[titlecolor]',(!empty($setting["titlecolor"])?$setting["titlecolor"]:"#ffffff"),'color','','',plang('menu_mobile_title_color_msg'));
        showsetting(plang('menu_mobile_registerdesc'),'setting[registerdesc]',$setting["registerdesc"],'text','','',plang('menu_mobile_registerdesc_msg'));
        showsetting(plang('menu_mobile_logindesc'),'setting[logindesc]',$setting["logindesc"],'text','','',plang('menu_mobile_logindesc_msg'));
        showsetting(plang('menu_mobile_lostpasswddesc'),'setting[lostpasswddesc]',$setting["lostpasswddesc"],'text','','',plang('menu_mobile_lostpasswddesc_msg'));
        showsetting(plang('menu_mobile_getpasswddesc'),'setting[getpasswddesc]',$setting["getpasswddesc"],'text','','',plang('menu_mobile_getpasswddesc_msg'));
        showsetting(plang('menu_mobile_desc_color'),'setting[desccolor]',(!empty($setting["desccolor"])?$setting["desccolor"]:"#ffffff"),'color','','',plang('menu_mobile_desc_color_msg'));
        showsetting(plang('menu_mobile_bg_color'),'setting[bgcolor]',$setting["bgcolor"],'color','','',plang('menu_mobile_bg_color_msg'));
        showsetting(plang('menu_mobile_favicon'), 'favicon', $setting["favicon"], 'filetext','','',plang('menu_mobile_favicon_msg'),'','menu_mobile_favicon_msg');
        showsetting(plang('menu_mobile_headertitle'),'setting[headertitle]',$setting["headertitle"],'text','','',plang('menu_mobile_headertitle_msg'));
        showsetting(plang('menu_mobile_headerdescription'),'setting[headerdescription]',$setting["headerdescription"],'textarea','','',plang('menu_mobile_headerdescription_msg'));
        showsetting(plang('menu_mobile_headerkeywords'),'setting[headerkeywords]',$setting["headerkeywords"],'textarea','','',plang('menu_mobile_headerkeywords_msg'));

        showsetting(plang('menu_mobile_xieyi_tip'),'setting[xieyitip]',$setting["xieyitip"],'text','','',plang('menu_mobile_xieyi_tip_msg'));
        showsetting(plang('menu_mobile_xieyi_title'),'setting[xieyititle]',$setting["xieyititle"],'text','','',plang('menu_mobile_xieyi_title_msg'));
        showsetting(plang('menu_mobile_xieyidefault'),'setting[xieyidefault]',$setting["xieyidefault"],'radio','','',plang('menu_mobile_xieyidefault_msg'));
        showsetting(plang('menu_mobile_xieyi_content'),'setting[xieyicontent]',$setting["xieyicontent"],'textarea','','',plang('menu_mobile_xieyi_content_msg'));
        showsetting(plang('menu_mobile_yinsi_title'),'setting[yinsititle]',$setting["yinsititle"],'text','','',plang('menu_mobile_yinsi_title_msg'));
        showsetting(plang('menu_mobile_yinsi_content'),'setting[yinsicontent]',$setting["yinsicontent"],'textarea','','',plang('menu_mobile_yinsi_content_msg'));
        showsetting(plang('menu_mobile_readagreement'),'setting[readagreement]',$setting["readagreement"],'radio','','',plang('menu_mobile_readagreement_msg'));
        showsetting(plang('menu_mobile_defaultreadagreement'),'setting[defaultreadagreement]',$setting["defaultreadagreement"],'radio','','',plang('menu_mobile_defaultreadagreement_msg'));
        showsetting(plang('menu_mobile_readagreementtip'),'setting[readagreementtip]',$setting["readagreementtip"],'text','','',plang('menu_mobile_readagreementtip_msg'));
        showsetting(plang('menu_mobile_btntext_color'),'setting[btntextcolor]',(!empty($setting["btntextcolor"])?$setting["btntextcolor"]:"#ffffff"),'color','','',plang('menu_mobile_btntext_color_msg'));
        showsetting(plang('menu_mobile_btnbackground_color'),'setting[btnbackgroundcolor]',(!empty($setting["btnbackgroundcolor"])?$setting["btnbackgroundcolor"]:"#0084ff"),'color','','',plang('menu_mobile_btnbackground_color_msg'));
        showsetting(plang('menu_mobile_btna_color'),'setting[btnacolor]',(!empty($setting["btnacolor"])?$setting["btnacolor"]:"#0084ff"),'color','','',plang('menu_mobile_btna_color_msg'));

        //social footer start
        showsetting(plang('menu_mobile_isshowsocial'),'setting[isshowsocial]',$setting["isshowsocial"],'radio','','',plang('menu_mobile_isshowsocial_msg'));
        showsetting(plang('menu_mobile_social_tip'),'setting[socialtip]',$setting["socialtip"],'text','','',plang('menu_mobile_social_tip_msg'));
        showsetting(plang('menu_mobile_weixinurl'),'setting[weixinurl]',$setting["weixinurl"],'text','','',plang('menu_mobile_weixinurl_msg'));
        showsetting(plang('menu_mobile_onlyweixin'),'setting[onlyweixin]',$setting["onlyweixin"],'radio','','',plang('menu_mobile_onlyweixin_msg'));
        showsetting(plang('menu_mobile_qqurl'),'setting[qqurl]',$setting["qqurl"],'text','','',plang('menu_mobile_qqurl_msg'));
        showsetting(plang('menu_mobile_weibourl'),'setting[weibourl]',$setting["weibourl"],'text','','',plang('menu_mobile_weibourl_msg'));
        showsetting(plang('menu_mobile_googleurl'),'setting[googleurl]',$setting["googleurl"],'text','','',plang('menu_mobile_googleurl_msg'));
        showsetting(plang('menu_mobile_facebookurl'),'setting[facebookurl]',$setting["facebookurl"],'text','','',plang('menu_mobile_facebookurl_msg'));
        showsetting(plang('menu_mobile_twitterurl'),'setting[twitterurl]',$setting["twitterurl"],'text','','',plang('menu_mobile_twitterurl_msg'));
        showsetting(plang('menu_mobile_weiruanurl'),'setting[weiruanurl]',$setting["weiruanurl"],'text','','',plang('menu_mobile_weiruanurl_msg'));
        showsetting(plang('menu_mobile_social_color'),'setting[socialcolor]',$setting["socialcolor"],'color','','',plang('menu_mobile_social_color_msg'));
        //social footer end
        //app footer start
        showsetting(plang('menu_mobile_footer_color'),'setting[footercolor]',$setting["footercolor"],'color','','',plang('menu_mobile_footer_color_msg'));
        showsetting(plang('menu_mobile_footercopyright'),'setting[footercopyright]',$setting["footercopyright"],'textarea','','',plang('menu_mobile_footercopyright_msg'));
        //app footer end
        showsetting(plang('menu_mobile_close_color'),'setting[closecolor]',$setting["closecolor"],'color','','',plang('menu_mobile_close_color_msg'));

        showsetting(plang('menu_mobile_extendcss'),'setting[extendcss]',$setting["extendcss"],'textarea','','',plang('menu_mobile_extendcss_msg'));

        showtablefooter(); /*Dism��taobao��com*/

        showtableheader(plang('menu_mobile_security_settings_title'), '', 'id="mobile_security_settings"');
        showsetting(plang('menu_mobile_security_title'),'setting[securitytitle]',$setting["securitytitle"],'text','','',plang('menu_mobile_security_title_msg'));
        showsetting(plang('menu_mobile_security_title_color'),'setting[securitytitlecolor]',(!empty($setting["securitytitlecolor"])?$setting["securitytitlecolor"]:"#46a3fd"),'color','','',plang('menu_mobile_security_title_color_msg'));
        showsetting(plang('menu_mobile_security_favicon'), 'securityfavicon', $setting["securityfavicon"], 'filetext','','',plang('menu_mobile_security_favicon_msg'),'','menu_mobile_security_favicon_msg');
        showsetting(plang('menu_mobile_security_headertitle'),'setting[securityheadertitle]',$setting["securityheadertitle"],'text','','',plang('menu_mobile_security_headertitle_msg'));
        showsetting(plang('menu_mobile_security_headerdescription'),'setting[securityheaderdescription]',$setting["securityheaderdescription"],'textarea','','',plang('menu_mobile_security_headerdescription_msg'));
        showsetting(plang('menu_mobile_security_headerkeywords'),'setting[securityheaderkeywords]',$setting["securityheaderkeywords"],'textarea','','',plang('menu_mobile_security_headerkeywords_msg'));
        showsetting(plang('menu_mobile_security_btntext_color'),'setting[securitybtntextcolor]',(!empty($setting["securitybtntextcolor"])?$setting["securitybtntextcolor"]:"#ffffff"),'color','','',plang('menu_mobile_security_btntext_color_msg'));
        showsetting(plang('menu_mobile_security_btnbackground_color'),'setting[securitybtnbackgroundcolor]',(!empty($setting["securitybtnbackgroundcolor"])?$setting["securitybtnbackgroundcolor"]:"#0084ff"),'color','','',plang('menu_mobile_security_btnbackground_color_msg'));
        showsetting(plang('menu_mobile_security_circle_menu'),'setting[securitycirclemenu]',(!empty($setting["securitycirclemenu"])?$setting["securitycirclemenu"]:0),'radio','','',plang('menu_mobile_security_circle_menu_msg'));
        /*
        $securitynavnumselect = '<option value="999" '.((empty($setting["securitynavnum"]) || $setting["securitynavnum"]=='999')?'selected':'').'>'.plang('norestriction').'</option>';
        for ($n=0; $n<=30; $n++){
            $securitynavnumselect .= '<option value="'.$n.'" '.((strlen($setting["securitynavnum"]) > 0 && $setting["securitynavnum"]==$n)?'selected':'').'>'.$n.'</option>';
        }
        showsetting(plang('menu_mobile_security_securitynavnum'),'setting[securitynavnum]','','<select name="setting[securitynavnum]">'.$securitynavnumselect.'</select>','',0,plang('menu_mobile_security_securitynavnum_msg'),1,'menu_mobile_security_securitynavnum');
        */
        showsetting(plang('menu_mobile_security_extendcss'),'setting[securityextendcss]',$setting["securityextendcss"],'textarea','','',plang('menu_mobile_security_extendcss_msg'));

        showtablefooter(); /*Dism��taobao��com*/

        showsubmit('settingsubmit', 'submit');
        showformfooter(); /*Dism_taobao_com*/
    }else{

        $setting = $_GET['setting'];

        if($_FILES['logo']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['logo'], 'common') && $upload->save(1)) {
                $setting['logo'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['logo'] = !empty($_GET['logo'])?trim($_GET['logo']):"";
        }

        if($_FILES['favicon']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['favicon'], 'common') && $upload->save(1)) {
                $setting['favicon'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['favicon'] = !empty($_GET['favicon'])?trim($_GET['favicon']):"";
        }


        if($_FILES['securityfavicon']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['securityfavicon'], 'common') && $upload->save(1)) {
                $setting['securityfavicon'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $setting['securityfavicon'] = !empty($_GET['securityfavicon'])?trim($_GET['securityfavicon']):"";
        }

        $settings = array('jsms_muban_mobile' => serialize($setting));
        C::t('common_setting')->update_batch($settings);

        updatecache('setting');

        cpmsg('setting_update_succeed', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=mobile', 'succeed');

    }
}elseif($type == 'wenti'){

    $act = $_GET['act'];

    if($act == 'add'){

        if(submitcheck('submit')){

            $setting = $_GET['setting'];
            $dsp = array('dateline'=>TIMESTAMP);
            $dsp['type'] = daddslashes(trim($setting['type']));
            $dsp['question'] = daddslashes(trim($setting['question']));
            $dsp['answer'] = daddslashes(trim($setting['answer']));
            $dsp['sort'] = daddslashes(trim($setting['sort']));
            $dsp['status'] = daddslashes(trim($setting['status']));

            if(empty($dsp['type']) || !in_array($dsp['type'],array('bindmobile','changepassword','changeusername','logonlog','logoff','logoffapply','needverify','ask','email','checkphone'))){
                cpmsg('jzsjiale_isms:wttype_null', '', 'error');
            }
            if(empty($dsp['question'])){
                cpmsg('jzsjiale_isms:wtquestion_null', '', 'error');
            }
            if(empty($dsp['answer'])){
                cpmsg('jzsjiale_isms:wtanswer_null', '', 'error');
            }
            if(empty($dsp['sort']) || !preg_match("/^[0-9]\d*$/",$dsp['sort'])){
                $dsp['sort'] = 0;
            }

            if(C::t('#jzsjiale_isms#jzsjiale_isms_wenti')->insert($dsp,true)){
                recache();
                cpmsg('jzsjiale_isms:addok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti', 'succeed');
            }else{
                cpmsg('jzsjiale_isms:error', '', 'error');
            }
        }else{

            showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti&act=add', 'enctype');
            showtableheader(plang('addwentititle'), '');
            $wentitypeselect = "";
            $wentitypeselect .= '<option value="bindmobile">'.plang('wentitype')['bindmobile'].'</option>';
            $wentitypeselect .= '<option value="changepassword">'.plang('wentitype')['changepassword'].'</option>';
            $wentitypeselect .= '<option value="changeusername">'.plang('wentitype')['changeusername'].'</option>';
            $wentitypeselect .= '<option value="logonlog">'.plang('wentitype')['logonlog'].'</option>';
            $wentitypeselect .= '<option value="logoff">'.plang('wentitype')['logoff'].'</option>';
            $wentitypeselect .= '<option value="logoffapply">'.plang('wentitype')['logoffapply'].'</option>';
            $wentitypeselect .= '<option value="ask">'.plang('wentitype')['ask'].'</option>';
            $wentitypeselect .= '<option value="email">'.plang('wentitype')['email'].'</option>';
            $wentitypeselect .= '<option value="needverify">'.plang('wentitype')['needverify'].'</option>';
            $wentitypeselect .= '<option value="checkphone">'.plang('wentitype')['checkphone'].'</option>';

            showsetting(plang('wttype'),'setting[type]','','<select name="setting[type]">'.$wentitypeselect.'</select>','',0,plang('wttype_msg'),1,'wttype');
            showsetting(plang('wtquestion'),'setting[question]','','text','','',plang('wtquestion_msg'));
            showsetting(plang('wtanswer'),'setting[answer]','','textarea','','',plang('wtanswer_msg'));
            showsetting(plang('wtsort'),'setting[sort]','0','text','','',plang('wtsort_msg'));
            showsetting(plang('wtstatus'),'setting[status]','1','radio','','',plang('wtstatus_msg'));

            showsubmit('submit', 'submit');
            showtablefooter(); /*Dism��taobao��com*/
            showformfooter(); /*Dism_taobao_com*/

            exit();
        }
    }elseif($act == 'edit'){
        $id = dintval($_GET['id']);

        $wenti = C::t('#jzsjiale_isms#jzsjiale_isms_wenti')->fetch($id);
        if(empty($wenti))
            cpmsg('jzsjiale_isms:empty', '', 'error');

        if(submitcheck('submit')){

            $setting = $_GET['setting'];
            $dsp = array('dateline'=>TIMESTAMP);
            $dsp['type'] = daddslashes(trim($setting['type']));
            $dsp['question'] = daddslashes(trim($setting['question']));
            $dsp['answer'] = daddslashes(trim($setting['answer']));
            $dsp['sort'] = daddslashes(trim($setting['sort']));
            $dsp['status'] = daddslashes(trim($setting['status']));

            if(empty($dsp['type']) || !in_array($dsp['type'],array('bindmobile','changepassword','changeusername','logonlog','logoff','logoffapply','needverify','ask','email','checkphone'))){
                cpmsg('jzsjiale_isms:wttype_null', '', 'error');
            }
            if(empty($dsp['question'])){
                cpmsg('jzsjiale_isms:wtquestion_null', '', 'error');
            }
            if(empty($dsp['answer'])){
                cpmsg('jzsjiale_isms:wtanswer_null', '', 'error');
            }
            if(empty($dsp['sort']) || !preg_match("/^[0-9]\d*$/",$dsp['sort'])){
                $dsp['sort'] = 0;
            }

            if(C::t('#jzsjiale_isms#jzsjiale_isms_wenti')->update($id,$dsp)){
                recache();
                cpmsg('jzsjiale_isms:editok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti', 'succeed');
            }else{
                cpmsg('jzsjiale_isms:error', '', 'error');
            }
        }else{

            showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti&act=edit', 'enctype');
            echo'<input type="hidden" value="'.dhtmlspecialchars($wenti['id']).'" name="id"/>';
            showtableheader(plang('addwentititle'), '');
            $wentitypeselect = "";
            $wentitypeselect .= '<option value="bindmobile" '.($wenti['type'] == 'bindmobile'?"selected":"").'>'.plang('wentitype')['bindmobile'].'</option>';
            $wentitypeselect .= '<option value="changepassword" '.($wenti['type'] == 'changepassword'?"selected":"").'>'.plang('wentitype')['changepassword'].'</option>';
            $wentitypeselect .= '<option value="changeusername" '.($wenti['type'] == 'changeusername'?"selected":"").'>'.plang('wentitype')['changeusername'].'</option>';
            $wentitypeselect .= '<option value="logonlog" '.($wenti['type'] == 'logonlog'?"selected":"").'>'.plang('wentitype')['logonlog'].'</option>';
            $wentitypeselect .= '<option value="logoff" '.($wenti['type'] == 'logoff'?"selected":"").'>'.plang('wentitype')['logoff'].'</option>';
            $wentitypeselect .= '<option value="logoffapply" '.($wenti['type'] == 'logoffapply'?"selected":"").'>'.plang('wentitype')['logoffapply'].'</option>';
            $wentitypeselect .= '<option value="ask" '.($wenti['type'] == 'ask'?"selected":"").'>'.plang('wentitype')['ask'].'</option>';
            $wentitypeselect .= '<option value="email" '.($wenti['type'] == 'email'?"selected":"").'>'.plang('wentitype')['email'].'</option>';
            $wentitypeselect .= '<option value="needverify" '.($wenti['type'] == 'needverify'?"selected":"").'>'.plang('wentitype')['needverify'].'</option>';
            $wentitypeselect .= '<option value="checkphone" '.($wenti['type'] == 'checkphone'?"selected":"").'>'.plang('wentitype')['checkphone'].'</option>';

            showsetting(plang('wttype'),'setting[type]','','<select name="setting[type]">'.$wentitypeselect.'</select>','',0,plang('wttype_msg'),1,'wttype');
            showsetting(plang('wtquestion'),'setting[question]',$wenti['question'],'text','','',plang('wtquestion_msg'));
            showsetting(plang('wtanswer'),'setting[answer]',$wenti['answer'],'textarea','','',plang('wtanswer_msg'));
            showsetting(plang('wtsort'),'setting[sort]',$wenti['sort'],'text','','',plang('wtsort_msg'));
            showsetting(plang('wtstatus'),'setting[status]',$wenti['status'],'radio','','',plang('wtstatus_msg'));

            showsubmit('submit', 'submit');
            showtablefooter(); /*Dism��taobao��com*/
            showformfooter(); /*Dism_taobao_com*/

            exit();
        }

    }elseif($act == 'del'){
        $formhash =  $_GET['formhash']? $_GET['formhash']:'';
        if($formhash != FORMHASH){
            cpmsg('jzsjiale_isms:formhash_error', '', 'error');
        }
        $id = dintval($_GET['id']);

        $wenti = C::t('#jzsjiale_isms#jzsjiale_isms_wenti')->fetch($id);
        if(empty($wenti))
            cpmsg('jzsjiale_isms:empty', '', 'error');
        if(submitcheck('submit')){
            C::t('#jzsjiale_isms#jzsjiale_isms_wenti')->deletebyid($id);
            recache();
            cpmsg('jzsjiale_isms:delok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti', 'succeed');

        }
        cpmsg('jzsjiale_isms:deltitle','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti&act=del&submit=yes&id='.$id,'form',array('title' => $wenti['question']));

    }elseif($act == 'recache'){
        recache();
        cpmsg('jzsjiale_isms:cache_success', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti', 'succeed');
    }
    //tip start

    echo '<div class="colorbox"><h4>'.plang('aboutwenti').'</h4>'.
        '<table cellspacing="0" cellpadding="3"><tr>'.
        '<td valign="top">'.plang('wentidescription').'</td></tr></table>'.
        '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

    //tip end
    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti', 'enctype');

    $keyword = daddslashes(trim($_GET['keyword']));

    $page = intval($_GET['page']);
    $page = $page > 0 ? $page : 1;
    $pagesize = 20;
    $start = ($page - 1) * $pagesize;


    $wenti = C::t('#jzsjiale_isms#jzsjiale_isms_wenti')->range_by_map($keyword,$start,$pagesize,'DESC');
    $count = C::t('#jzsjiale_isms#jzsjiale_isms_wenti')->count_by_map($keyword);

    $type_options = "<option value=\"all\"  " . (($keyword == 'all') ? "selected='selected'" : '') . ">" . plang('typeall') . "</option>"
        . "<option value='bindmobile' " . (($keyword == 'bindmobile') ? "selected='selected'" : '') . ">" . plang('wentitype')['bindmobile'] . "</option>"
        . "<option value='changepassword' " . (($keyword == 'changepassword') ? "selected='selected'" : '') . ">" . plang('wentitype')['changepassword'] . "</option>"
        . "<option value='changeusername' " . (($keyword == 'changeusername') ? "selected='selected'" : '') . ">" . plang('wentitype')['changeusername'] . "</option>"
        . "<option value='logonlog' " . (($keyword == 'logonlog') ? "selected='selected'" : '') . ">" . plang('wentitype')['logonlog'] . "</option>"
        . "<option value='logoff' " . (($keyword == 'logoff') ? "selected='selected'" : '') . ">" . plang('wentitype')['logoff'] . "</option>"
        . "<option value='logoffapply' " . (($keyword == 'logoffapply') ? "selected='selected'" : '') . ">" . plang('wentitype')['logoffapply'] . "</option>"
        . "<option value='ask' " . (($keyword == 'ask') ? "selected='selected'" : '') . ">" . plang('wentitype')['ask'] . "</option>"
        . "<option value='email' " . (($keyword == 'email') ? "selected='selected'" : '') . ">" . plang('wentitype')['email'] . "</option>"
        . "<option value='needverify' " . (($keyword == 'needverify') ? "selected='selected'" : '') . ">" . plang('wentitype')['needverify'] . "</option>"
        . "<option value='checkphone' " . (($keyword == 'checkphone') ? "selected='selected'" : '') . ">" . plang('wentitype')['checkphone'] . "</option>";


    showtablerow('', array('width="150"', 'width="150"', 'width="150"', ''), array(
            plang('tip_wentitype'),
            "<select name=\"keyword\">$type_options</select>
                <input class=\"btn\" type=\"submit\" value=\"" . cplang('search') . "\" />"
        )
    );

    showtableheader(plang('wentilist').'(&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti&act=add" style="color:red;">'.plang('addwenti').'</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti&act=recache" style="color:red;">'.plang('recache').'</a>&nbsp;&nbsp;)');
    showsubtitle(plang('wentilisttitle'));
    foreach($wenti as $d){
        showtablerow('', array('width="5%"','width="15%"','width="40%"','width="10%"','width="5%"','width="5%"','width="10%"','width="10%"'), array(
                $d['id'],
                $d['question'],
                $d['answer'],
                plang("wentitype")[$d['type']].'('.$d['type'].')',
                $d['sort'],
                '<span title="'.($d['status']?plang('yes'):plang('no')).'">'.($d['status']?'<span style="color:green;">'.plang('yes').'</span>':'<span style="color:red;">'.plang('no').'</span>').'</span>',
                dgmdate($d['dateline']),
                '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti&act=edit&id='.$d['id'].'" style="color:red;">'.plang('edit').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti&act=del&id='.$d['id'].'&formhash='.FORMHASH.'" style="color:red;">'.plang('del').'</a>')
        );
    }

    $mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=wenti&keyword='.$keyword;
    $multipage = multi($count, $pagesize, $page, $mpurl);
    //showsubmit('', '', '', '', $multipage);


    //search start
    showsubmit('', '', '', '', $multipage);

    //search end


    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/


}elseif ($type == 'xieyi'){
    if(!submitcheck('settingsubmit')) {


        $setting = C::t('common_setting')->fetch_all(array('jsms_muban_xieyi'));
        $setting = (array)unserialize($setting['jsms_muban_xieyi']);

        showtips(lang('plugin/jzsjiale_isms', 'muban_xieyi_tips'));

        showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=xieyi', 'enctype');

        showtableheader(plang('menu_xieyi'), '', 'id="xieyi_settings"');

        echo '<script type="text/javascript" src="https://cdn.bootcdn.net/ajax/libs/tinymce/5.4.2/tinymce.min.js"></script>';
        echo '<script type="text/javascript">tinymce.init({selector: "#xieyi",branding: false,menubar: false,toolbar: ["undo redo | fontsizeselect bold italic h1 h2 h3 | forecolor backcolor | superscript subscript charmap insertdatetime emoticons| lists image media | numlist | preview code removeformat | alignleft aligncenter alignright alignjustify | bullist outdent indent"]});</script>';
        echo '<style>.tox-tinymce{height: 500px!important;width: 900px!important;}</style>';
        showsetting(plang('menu_xieyi_content'),'xieyi',$setting['xieyi'],'textarea','','',plang('menu_xieyi_content_msg'));

        showtablefooter(); /*Dism��taobao��com*/

        showsubmit('settingsubmit', 'submit');
        showformfooter(); /*Dism_taobao_com*/
    }else{

        $xieyi = $_GET['xieyi'];
        $setting['xieyi'] = $xieyi;

        $settings = array('jsms_muban_xieyi' => serialize($setting));
        C::t('common_setting')->update_batch($settings);

        updatecache('setting');

        cpmsg('setting_update_succeed', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=xieyi', 'succeed');

    }
}elseif ($type == 'yinsi'){
    if(!submitcheck('settingsubmit')) {


        $setting = C::t('common_setting')->fetch_all(array('jsms_muban_yinsi'));
        $setting = (array)unserialize($setting['jsms_muban_yinsi']);

        showtips(lang('plugin/jzsjiale_isms', 'muban_yinsi_tips'));

        showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=yinsi', 'enctype');

        showtableheader(plang('menu_yinsi'), '', 'id="yinsi_settings"');

        echo '<script type="text/javascript" src="https://cdn.bootcdn.net/ajax/libs/tinymce/5.4.2/tinymce.min.js"></script>';
        echo '<script type="text/javascript">tinymce.init({selector: "#yinsi",branding: false,menubar: false,toolbar: ["undo redo | fontsizeselect bold italic h1 h2 h3 | forecolor backcolor | superscript subscript charmap insertdatetime emoticons| lists image media | numlist | preview code removeformat | alignleft aligncenter alignright alignjustify | bullist outdent indent"]});</script>';
        echo '<style>.tox-tinymce{height: 500px!important;width: 900px!important;}</style>';
        showsetting(plang('menu_yinsi_content'),'yinsi',$setting['yinsi'],'textarea','','',plang('menu_yinsi_content_msg'));

        showtablefooter(); /*Dism��taobao��com*/

        showsubmit('settingsubmit', 'submit');
        showformfooter(); /*Dism_taobao_com*/
    }else{

        $yinsi = $_GET['yinsi'];
        $setting['yinsi'] = $yinsi;

        $settings = array('jsms_muban_yinsi' => serialize($setting));
        C::t('common_setting')->update_batch($settings);

        updatecache('setting');

        cpmsg('setting_update_succeed', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=muban&type=yinsi', 'succeed');

    }
}

function recache() {
    $wenti = C::t('#jzsjiale_isms#jzsjiale_isms_wenti')->getall();

    require_once libfile('function/cache');
    writetocache('jzsjiale_isms_wenti', getcachevars(array('wenti' => $wenti)));

}

function unicodeDecode($unicode_str)
{
    $json = '{"str":"' . $unicode_str . '"}';
    $arr = json_decode($json, true);
    if (empty($arr)) return '';
    global $_G;
    if($_G['charset'] == "gbk"){
        $arr['str'] = diconv($arr['str'],'UTF-8','GBK');
    }

    return $arr['str'];

}

function getDir($dir){
    $templatedir = DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/template/'.$dir;
    $templatesdir = dir($templatedir);
    $templates = array();

    while($entry = $templatesdir->read()) {
        if(!in_array($entry, array('.', '..')) && is_dir($templatedir.'/'.$entry)) {

            $entrydir = $templatedir.'/'.$entry;
            if(file_exists($entrydir.'/config.php')) {
                @include_once $entrydir.'/config.php';

                if(!empty($config) && $config != null){
                    $templates[] = $config;
                }
            }

        }
    }
    return $templates;
}

function plang($str) {
    return lang('plugin/jzsjiale_isms', $str);
}
//From: d'.'is'.'m.ta'.'obao.com
?>