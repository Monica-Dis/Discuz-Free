<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jzsjiale_isms_freeze extends discuz_table
{
	public function __construct() {
		$this->_table = 'jzsjiale_isms_freeze';
		$this->_pk    = 'id';
		parent::__construct(); //Dism_taobao-com
	}

    public function fetch_by_id($id){
        return DB::fetch_first('SELECT * FROM %t WHERE id = '.$id,array($this->_table));
    }

    public function fetch_by_uid($uid){
        return DB::fetch_first('SELECT * FROM %t WHERE uid = '.$uid,array($this->_table));
    }

    public function fetch_one_by_uid_and_freeze($uid,$freeze = "") {
        $info = array();
        $where = '';
        if(!empty($freeze)){
            $where = ' and freeze = \''.$freeze.'\'';
        }
        if($uid) {
            $info = DB::fetch_first('SELECT * FROM %t WHERE uid=%d '.$where.' ORDER BY id DESC limit 0,1', array($this->_table, $uid));
        }
        return $info;
    }

    public function getall(){
        return DB::fetch_all('SELECT * FROM %t ORDER BY sort DESC,id DESC',array($this->_table));
    }

    public function delall(){
        return DB::delete($this->_table,'id>0');
    }

    public function deletebyid($id){
        return DB::delete($this->_table,'id = '.$id);
    }

    public function deletebyuid($uid){
        return DB::delete($this->_table,'uid = '.$uid);
    }

    public function update_freeze_by_id($id,$freeze){
        return DB::update($this->_table,array('freeze'=>$freeze),'id='.$id);
    }

    public function update_freeze_by_uid($uid,$freeze){
        return DB::update($this->_table,array('freeze'=>$freeze),'uid='.$uid);
    }

    public function count_by_map($keyword = '') {
        $where = ' 1=1 ';

        if(!empty($keyword) && $keyword != 'all'){
            $where .=  ' and type = \''.$keyword.'\' ';
        }
        $count = (int) DB::result_first("SELECT count(*) FROM ".DB::table($this->_table).' WHERE '.$where);
        return $count;
    }

    public function range_by_map($keyword = '',$start = 0, $limit = 0, $sort = '') {
        $where = ' 1=1 ';

        if(!empty($keyword) && $keyword != 'all'){
            $where .=  ' and type = \''.$keyword.'\' ';
        }
        if($sort) {
            $this->checkpk();
        }
        return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' WHERE '.$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
    }

    public function count_logoffapply() {
        $where = ' freeze = -1 ';

        $count = (int) DB::result_first("SELECT count(*) FROM ".DB::table($this->_table).' WHERE '.$where);
        return $count;
    }

    public function range_logoffapply($start = 0, $limit = 0, $sort = '') {
        $where = ' freeze = -1 ';
        if($sort) {
            $this->checkpk();
        }
        return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' WHERE '.$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
    }
}
//From: d'.'is'.'m.ta'.'obao.com
?>