<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jzsjiale_isms_log extends discuz_table
{
	public function __construct() {
		$this->_table = 'jzsjiale_isms_log';
		$this->_pk    = 'id';
		parent::__construct(); //Dism_taobao-com
	}
	public function getone(){
		return DB::fetch_first('SELECT * FROM %t ORDER BY id DESC limit 0,1',array($this->_table));
		
	}
	
	public function get_by_id($id){
	    return DB::fetch_first('SELECT * FROM %t WHERE id = '.$id,array($this->_table));
	
	}
	
	public function getall(){
		return DB::fetch_all('SELECT * FROM %t ORDER BY id DESC',array($this->_table));
	
	}
	
	public function getallByIds($ids){
	    return DB::fetch_all('SELECT * FROM %t WHERE id in ('.$ids.')',array($this->_table));
	
	}
	
	public function getallByPhone($phone){
	    return DB::fetch_all('SELECT * FROM %t WHERE phone = '.$phone,array($this->_table));
	
	}
	
	public function fetch_by_phone($phone) {
        $log = array();
	    if($phone) {
            $log = DB::fetch_all('SELECT * FROM %t WHERE phone=%s', array($this->_table, $phone));
	    }
	    return $log;
	}
    public function fetch_by_areacode_and_phone($areacode, $phone) {
        $log = array();
        if($phone) {
            $log = DB::fetch_all('SELECT * FROM %t WHERE areacode=%s and phone=%s', array($this->_table, $areacode, $phone));
        }
        return $log;
    }
    public function fetch_by_username($username) {
        $log = array();
		if($username) {
            $log = DB::fetch_all('SELECT * FROM %t WHERE username=%s', array($this->_table, $username));
		}
		return $log;
	}
	
	public function fetch_by_uid($uid) {
        $log = array();
	    if($uid) {
            $log = DB::fetch_all('SELECT * FROM %t WHERE uid=%d', array($this->_table, $uid));
	    }
	    return $log;
	}

    public function fetch_by_uid_and_type($uid,$type = "") {
        $log = array();
        $where = '';
        if(!empty($type)){
            $where = ' and type = \''.$type.'\'';
        }
        if($uid) {
            $log = DB::fetch_all('SELECT id,record,ip,browser,os,device,from_unixtime(dateline) as dateline FROM %t WHERE uid=%d '.$where.' ORDER BY id DESC', array($this->_table, $uid));
        }
        return $log;
    }

    public function fetch_one_by_uid_and_type($uid,$type = "") {
        $log = array();
        $where = '';
        if(!empty($type)){
            $where = ' and type = \''.$type.'\'';
        }
        if($uid) {
            $log = DB::fetch_first('SELECT id,record,ip,browser,os,device,dateline FROM %t WHERE uid=%d '.$where.' ORDER BY id DESC limit 0,1', array($this->_table, $uid));
        }
        return $log;
    }
	
	public function delalllog(){
	    return DB::delete($this->_table,'id>0');
	
	}
	
	public function deletebyid($id){
	    return DB::delete($this->_table,'id = '.$id);
	
	}
	
	public function deletebyphone($phone){
	    return DB::delete($this->_table,'phone = '.$phone);
	
	}
	
	public function deletebyuid($uid){
	    return DB::delete($this->_table,'uid = '.$uid);
	
	}
    
	public function count_by_map($map = array(),$status="") {
	    $where = " 1=1 ";
	
	    foreach ($map as $mapkey => $mapvalue){
	        if($mapkey == "keyword"){
	            $where .=  ' and ('.DB::field('phone', '%'.$mapvalue.'%', 'like').' or '.DB::field('username', '%'.$mapvalue.'%', 'like').') ';
	        }elseif($mapkey == "ip"){
                $where .=  ' and '.DB::field('ip', '%'.$mapvalue.'%', 'like').' ';
            }else{
	            $where .=  ' and '.$mapkey.' = \''.$mapvalue.'\' ';
	        }
	
	    }
	    $count = (int) DB::result_first("SELECT count(*) FROM ".DB::table($this->_table).' WHERE '.$where);
	    return $count;
	}
	
	//$map title,categoryid,flag
	public function range_by_map($map = array(),$start = 0, $limit = 0, $sort = '',$status="") {
	    $where = " 1=1 ";
	
	    foreach ($map as $mapkey => $mapvalue){
	        if($mapkey == "keyword"){
	            $where .=  ' and ('.DB::field('phone', '%'.$mapvalue.'%', 'like').' or '.DB::field('username', '%'.$mapvalue.'%', 'like').') ';
	        }elseif($mapkey == "ip"){
                $where .=  ' and '.DB::field('ip', '%'.$mapvalue.'%', 'like').' ';
            }else{
	            $where .=  ' and '.$mapkey.' = \''.$mapvalue.'\' ';
	        }
	
	    }
	    if($sort) {
	        $this->checkpk();
	    }
	    return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' WHERE '.$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>