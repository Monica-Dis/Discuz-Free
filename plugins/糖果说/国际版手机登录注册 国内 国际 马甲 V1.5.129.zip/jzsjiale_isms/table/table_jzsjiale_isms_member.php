<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jzsjiale_isms_member extends discuz_table
{
	public function __construct() {
		$this->_table = 'common_member_profile';
		$this->_pk    = 'uid';
		parent::__construct(); //Dism_taobao-com
	}

	
	public function fetch_by_mobile($phone) {
	    $user = array();
	    if($phone) {
	        $user = DB::fetch_first('SELECT * FROM %t WHERE mobile=%s', array($this->_table, $phone));
	    }
	    return $user;
	}

    public function fetch_archive_by_mobile($phone) {
        $user = array();
        if($phone) {
            $user = DB::fetch_first('SELECT * FROM '.DB::table("common_member_profile_archive").'  WHERE mobile=%s', array($phone));
        }
        return $user;
    }

    public function fetch_by_mobile_magapp($areacode = '86', $phone) {
        $user = array();
        $areacode_phone = '';
        if($areacode != '99999'){
            $areacode_phone = $areacode.$phone;
        }else{
            $areacode_phone = $phone;
        }
        if($phone) {
            $user = DB::fetch_first('SELECT * FROM %t WHERE mobile=%s or mobile=%s', array($this->_table, $phone, $areacode_phone));
        }
        return $user;
    }
	
	public function fetch_by_areacode_and_mobile($areacode = '86', $phone, $field = 'field8') {
	    $user = array();
	    if(empty($field) || !in_array($field, array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8'))){
            $field = 'field8';
        }
	    if($areacode && $phone) {
	        $user = DB::fetch_first('SELECT * FROM %t WHERE '.$field.' = %s and mobile = %s', array($this->_table, $areacode, $phone));

            if(empty($user)){
                $user = DB::fetch_first('SELECT * FROM %t WHERE mobile = %s', array($this->_table, $phone));
            }
	    }
	    return $user;
	}

    public function fetch_archive_by_areacode_and_mobile($areacode = '86', $phone, $field = 'field8') {
        $user = array();
        if(empty($field) || !in_array($field, array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8'))){
            $field = 'field8';
        }
        if($areacode && $phone) {
            $user = DB::fetch_first('SELECT * FROM '.DB::table("common_member_profile_archive").' WHERE '.$field.' = %s and mobile = %s', array($areacode, $phone));

            if(empty($user)){
                $user = DB::fetch_first('SELECT * FROM '.DB::table("common_member_profile_archive").' WHERE mobile = %s', array($phone));
            }
        }
        return $user;
    }

    public function fetch_by_areacode_and_mobile_relation($areacode = '86', $phone, $field = 'field8') {
        $user = array();
        if(empty($field) || !in_array($field, array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8'))){
            $field = 'field8';
        }
        if($areacode && $phone) {
            $user = DB::fetch_first('SELECT * FROM %t WHERE '.$field.' = %s and mobile = %s', array($this->_table, $areacode, $phone));
            if(empty($user) && $areacode == '86'){
                $user = DB::fetch_first('SELECT * FROM %t WHERE '.$field.' = %s and mobile = %s', array($this->_table, '', $phone));
            }
        }
        return $user;
    }

    public function fetch_archive_by_areacode_and_mobile_relation($areacode = '86', $phone, $field = 'field8') {
        $user = array();
        if(empty($field) || !in_array($field, array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8'))){
            $field = 'field8';
        }
        if($areacode && $phone) {
            $user = DB::fetch_first('SELECT * FROM '.DB::table("common_member_profile_archive").' WHERE '.$field.' = %s and mobile = %s', array($areacode, $phone));
            if(empty($user) && $areacode == '86'){
                $user = DB::fetch_first('SELECT * FROM '.DB::table("common_member_profile_archive").' WHERE '.$field.' = %s and mobile = %s', array('', $phone));
            }
        }
        return $user;
    }

    public function fetch_by_areacode_and_mobile_relation_magapp($areacode = '86', $phone, $field = 'field8') {
        $user = array();
        if(empty($field) || !in_array($field, array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8'))){
            $field = 'field8';
        }
        $areacode_phone = '';
        if($areacode != '99999'){
            $areacode_phone = $areacode.$phone;

            $user = DB::fetch_first('SELECT * FROM %t WHERE '.$field.' = %s and (mobile = %s or mobile = %s)', array($this->_table, $areacode, $phone, $areacode_phone));
            if(empty($user) && $areacode == '86'){
                $user = DB::fetch_first('SELECT * FROM %t WHERE mobile = %s or mobile = %s', array($this->_table, $phone, $areacode_phone));
                if($user){
                    DB::update($this->_table,array($field=>'86'),'uid='.$user['uid']);
                }
            }elseif(empty($user) && $areacode != '86'){
                $user = DB::fetch_first('SELECT * FROM %t WHERE mobile = %s', array($this->_table, $areacode_phone));
                if($user){
                    DB::update($this->_table,array($field=>$areacode),'uid='.$user['uid']);
                }
            }
        }else{
            $areacode_phone = $phone;

            $user = DB::fetch_first('SELECT * FROM %t WHERE mobile = %s', array($this->_table, $areacode_phone));
        }


        return $user;
    }
   
	public function fetch_by_uid($uid) {
	    $user = array();
	    if($uid) {
	        $user = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array($this->_table, $uid));
	    }
	    return $user;
	}

    public function fetch_archive_by_uid($uid) {
        $user = array();
        if($uid) {
            $user = DB::fetch_first('SELECT * FROM '.DB::table("common_member_profile_archive").'  WHERE uid=%d', array($uid));
        }
        return $user;
    }
	
	public function fetch_member_by_uid($uid) {
	    $user = array();
	    if($uid) {
	        $user = DB::fetch_first('SELECT * FROM '.DB::table('common_member').' WHERE uid='.$uid);
	    }
	    return $user;
	}

    public function fetch_member_profile_by_uid($uid) {
        $user = array();
        if($uid) {
            $user = DB::fetch_first('SELECT * FROM '.DB::table('common_member_profile').' sf RIGHT JOIN '.DB::table('common_member').' s USING(uid) WHERE uid='.$uid);
        }
        return $user;
    }
	
	public function fetch_all_with_username_and_mobile($map = array(),$start = 0, $limit = 0, $sort = '',$field = 'field8') {
	    $dzuserlist = array();
        $where = " 1=1 ";

        foreach ($map as $mapkey => $mapvalue){
            if($mapkey == "keyword"){
                $where .=  " and (sf.mobile like '%".$mapvalue."%' or s.username like '%".$mapvalue."%') ";
            }elseif($mapkey == "status"){
                if($mapvalue == '1'){
                    $where .=  ' and sf.mobile != \'\' ';
                }elseif($mapvalue == '0'){
                    $where .=  ' and sf.mobile = \'\' ';
                }
            }else{
                $where .=  " and ".$mapkey." = '".$mapvalue."' ";
            }

        }

	    $dzuserlist = DB::fetch_all("SELECT sf.uid as uid,sf.mobile as phone,sf.".$field." as areacode,s.username as username,s.email as email,sf.qq as qq,s.groupid as groupid,s.regdate as dateline,ss.lastvisit as lastvisit,ss.lastip as lastip,jf.freeze as freeze
				FROM (".DB::table('common_member')." s
				LEFT JOIN ".DB::table('common_member_profile')." sf USING(uid)
				LEFT JOIN ".DB::table('common_member_status')." ss USING(uid))
				LEFT JOIN ".DB::table('jzsjiale_isms_freeze')." jf USING(uid)
	            WHERE ".$where.($sort ? ' ORDER BY s.uid '. $sort : ', sf.mobile desc ').DB::limit($start, $limit));
	   
	    return $dzuserlist;
	}

	public function count_all_with_username_and_mobile($map = array()) {

        $where = " 1=1 ";

        foreach ($map as $mapkey => $mapvalue){
            if($mapkey == "keyword"){
                $where .=  " and (sf.mobile like '%".$mapvalue."%' or s.username like '%".$mapvalue."%') ";
            }elseif($mapkey == "status"){
                if($mapvalue == '1'){
                    $where .=  ' and sf.mobile != \'\' ';
                }elseif($mapvalue == '0'){
                    $where .=  ' and sf.mobile = \'\' ';
                }
            }else{
                $where .=  " and ".$mapkey." = '".$mapvalue."' ";
            }

        }


	     $count = (int) DB::result_first("SELECT count(*)
				FROM (".DB::table('common_member')." s
				LEFT JOIN ".DB::table('common_member_profile')." sf USING(uid)
				LEFT JOIN ".DB::table('common_member_status')." ss USING(uid))
				LEFT JOIN ".DB::table('jzsjiale_isms_freeze')." jf USING(uid)
	            WHERE ".$where);
	
	    return $count;
	}
	
	
	public function fetch_all_with_username_and_mobile_chachong($start = 0, $limit = 0, $sort = '',$field = 'field8') {
	    $dzuserlist = array();
	 
	    $dzuserchongfulist = DB::fetch_all("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE mobile <> '' GROUP BY mobile having count(1)>1");
	
	    $mobiles = array();
    	foreach ($dzuserchongfulist as $dzuserdata){
    	    if(!empty($dzuserdata['mobile'])){
    	        $mobiles[]=$dzuserdata['mobile'];
    	    }
    	}
    	
    	if (!empty($mobiles)){
    	    $dzuserlist = DB::fetch_all("SELECT sf.uid as uid,sf.mobile as phone,sf.".$field." as areacode,s.username as username,s.email as email,sf.qq as qq,s.groupid as groupid,s.regdate as dateline,ss.lastvisit as lastvisit,ss.lastip as lastip,jf.freeze as freeze
				FROM (".DB::table('common_member')." s
				LEFT JOIN ".DB::table('common_member_profile')." sf USING(uid)
				LEFT JOIN ".DB::table('common_member_status')." ss USING(uid))
				LEFT JOIN ".DB::table('jzsjiale_isms_freeze')." jf USING(uid)
	            WHERE sf.mobile in (".dimplode($mobiles).") ".($sort ? ' ORDER BY sf.mobile ASC,s.uid '. $sort : ', sf.mobile desc').DB::limit($start, $limit));
    	     
    	}
    	
	    return $dzuserlist;
	}
	
	public function count_all_with_username_and_mobile_chachong() {
	
	    $count = 0;
	    $dzuserchongfulist = DB::fetch_all("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE mobile <> '' GROUP BY mobile having count(1)>1");
	
	    $mobiles = array();
    	foreach ($dzuserchongfulist as $dzuserdata){
    	    if(!empty($dzuserdata['mobile'])){
    	        $mobiles[]=$dzuserdata['mobile'];
    	    }
    	}
    	
    	if (!empty($mobiles)){
    	    $count = (int) DB::result_first("SELECT count(*)
    				FROM (".DB::table('common_member')." s
				    LEFT JOIN ".DB::table('common_member_profile')." sf USING(uid)
				    LEFT JOIN ".DB::table('common_member_status')." ss USING(uid))
                    LEFT JOIN ".DB::table('jzsjiale_isms_freeze')." jf USING(uid)
    	            WHERE sf.mobile in (".dimplode($mobiles).") ");
    	}
	    return $count;
	}
	
	
	
	public function fetch_all_with_username_and_mobile_verify($map = array(),$start = 0, $limit = 0, $sort = '',$verify = 1, $field = 'field8') {
	    $dzuserlist = array();
        $where = " 1=1 ";

        foreach ($map as $mapkey => $mapvalue){
            if($mapkey == "keyword"){
                $where .=  " and (sf.mobile like '%".$mapvalue."%' or s.username like '%".$mapvalue."%') ";
            }elseif($mapkey == "status"){
                if($mapvalue == '1'){
                    $where .=  ' and sv.verify'.$verify.' = 1 ';
                }elseif($mapvalue == '0'){
                    $where .=  ' and (sv.verify'.$verify.' != 1 or sv.uid is null) ';
                }
            }else{
                $where .=  " and ".$mapkey." = '".$mapvalue."' ";
            }

        }
	    $dzuserlist = DB::fetch_all("SELECT sf.uid as uid,sf.mobile as phone,s.username as username,s.email as email,sf.qq as qq,s.groupid as groupid,sf.".$field." as areacode, s.regdate as dateline,sv.verify".$verify." as verify
				FROM (".DB::table('common_member')." s
				LEFT JOIN ".DB::table('common_member_profile')." sf USING(uid))
	            LEFT JOIN ".DB::table('common_member_verify')." sv USING(uid)
	            WHERE ".$where.($sort ? ' ORDER BY s.uid '. $sort : ', sf.mobile desc').DB::limit($start, $limit));
	
	    return $dzuserlist;
	}
	
	public function count_all_with_username_and_mobile_verify($map = array(),$verify = 1) {

        $where = " 1=1 ";

        foreach ($map as $mapkey => $mapvalue){
            if($mapkey == "keyword"){
                $where .=  " and (sf.mobile like '%".$mapvalue."%' or s.username like '%".$mapvalue."%') ";
            }elseif($mapkey == "status"){
                if($mapvalue == '1'){
                    $where .=  ' and sv.verify'.$verify.' = 1 ';
                }elseif($mapvalue == '0'){
                    $where .=  ' and (sv.verify'.$verify.' != 1 or sv.uid is null) ';
                }
            }else{
                $where .=  " and ".$mapkey." = '".$mapvalue."' ";
            }

        }
	    $count = (int) DB::result_first("SELECT count(*)
				FROM (".DB::table('common_member')." s
				LEFT JOIN ".DB::table('common_member_profile')." sf USING(uid))
	            LEFT JOIN ".DB::table('common_member_verify')." sv USING(uid)
	            WHERE ".$where);
	
	    return $count;
	}
	
	public function count_by_isexists_mobile($isexistsmobile=true) {
	    $where = " ";
	    if($isexistsmobile){
	        $where .= " mobile is not null and mobile <> '' ";
	    }else{
	        $where .= " mobile is null or mobile = '' ";
	    }
	    $count = (int) DB::result_first("SELECT count(*) FROM ".DB::table($this->_table).' WHERE '.$where);
	    return $count;
	}
	
	public function range_by_isexists_mobile($isexistsmobile=true,$start = 0, $limit = 0, $sort = '') {
	    $where = " ";
	    if($isexistsmobile){
	        $where .= " mobile is not null and mobile <> '' ";
	    }else{
	        $where .= " mobile is null or mobile = '' ";
	    }
	    if($sort) {
	        $this->checkpk();
	    }
	    return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' WHERE '.$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
	
	
	public function count_common_member_verify() {
	    $count = (int) DB::result_first("SELECT count(*) FROM ".DB::table('common_member_verify'));
	    return $count;
	}
	
	public function range_common_member_verify($start = 0, $limit = 0, $sort = '') {
	    if($sort) {
	        $this->checkpk();
	    }
	    return DB::fetch_all('SELECT * FROM '.DB::table('common_member_verify').($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}

    public function updateareacode($uid, $areacode, $field = 'field8'){
        return DB::update($this->_table,array($field=>$areacode),'uid='.$uid);
    }

    public function updatemobile($uid, $phone){
        return DB::update($this->_table,array('mobile'=>$phone),'uid='.$uid);
    }
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>