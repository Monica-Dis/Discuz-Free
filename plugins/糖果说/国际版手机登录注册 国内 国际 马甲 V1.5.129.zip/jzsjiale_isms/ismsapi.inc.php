<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('plugin');
global $_G, $lang;

class ISMSApi
{
    /*
     * $areacode string 86
     * $phone string 18812345678
     * $code  string 123456
     * $type  int 0ceshi 1zhuce 2shenfenyanzheng 3denglu 4zhaohuimima 5yanzhengjiushouji 6app 7other
     * $uid   int
     * 
     * return
     * 1 success
     * 0 sms send error
     * -998 peizhi error
     * -1 phone error
     * -2 code error
     * -3 file error
     * -4 duanxinxiane error
     * -5 duanxinliukong error
     * -6 checkip error
     * -7 areacode error
     */
    public function smssend($areacode,$phone,$code,$type=0,$uid=0){
        $areacode = daddslashes(trim($areacode));
        $phone = daddslashes(trim($phone));
        $code = daddslashes(trim($code));
        $type = intval($type);
        $uid = intval($uid);
        
        if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/ismstools.inc.php')){
            @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/ismstools.inc.php';
        }else{
            return -3;
        }

        if(empty($areacode)){
            return -1;
        }

        if(empty($phone)){
            return -1;
        }
        
        if(empty($code)){
            return -2;
        }

        if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
            @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
            $utils = new ISMSUtils();
        }else{
            return -3;
        }
        if(!$utils->isMobile($phone,$areacode)){
            return -1;
        }
        
        global $_G;

        
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];
        $g_accesskeyid = $_config['g_accesskeyid'];
        $g_accesskeysecret = $_config['g_accesskeysecret'];
        $webbianma = $_G['charset'];
        $g_xiane = !empty($_config['g_xiane'])?$_config['g_xiane']:10;
        $g_zongxiane = ($_config['g_zongxiane']>0)?$_config['g_zongxiane']:0;
        $g_zhanghaoxiane = ($_config['g_zhanghaoxiane']>0)?$_config['g_zhanghaoxiane']:0;
        $g_isopenhtmlspecialchars = !empty($_config['g_isopenhtmlspecialchars'])?true:false;
        

        $smsareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
        $smsareacode = (array)unserialize($smsareacode['jisms_allareacode']);

        $areacodestatus = $utils->searchGetOne($areacode,'areacode','status',$smsareacode);
        if(!$areacodestatus){
            return -7;
        }

        $clentip = "";

        if($_config['g_checkip'] == 1 || $_config['g_checkip'] == 2){

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php';
            }else{
                return -3;
            }
            $checkip = new Checkip();

            $clentip = $checkip->get_client_ip();

            $isipok = $checkip->ipaccessok();

            if(!$isipok){
                return -6;
            }
        }
        if($_config['g_checkip'] == 5){

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php';
            }else{
                return -3;
            }
            $checkip = new Checkip();

            $clentip = $checkip->get_client_ip();

        }
        if($_config['g_checkip'] == 6 || $_config['g_checkip'] == 7){

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkipapi.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkipapi.class.php';
            }else{
                return -3;
            }
            $checkip = new Checkipapi();

            $clentip = $checkip->get_client_ip();

            $isipok = $checkip->ipaccessok();

            if(!$isipok){
                return -6;
            }
        }

        
        if($g_zongxiane){
            $phonesendallcount = C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->count_all_by_day();
        
            if($phonesendallcount >= $g_zongxiane){
                return -4;
            }
        }
        
        
        if($uid && $g_zhanghaoxiane && ($type == 2 || $type == 5)){
            $uidphonesendcount = C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->count_by_uid_day($uid);
             
            if($uidphonesendcount >= $g_zhanghaoxiane){
                return -4;
            }
        }
        
        if(empty($g_accesskeyid)){
            return -998;
        }
        if(empty($g_accesskeysecret)){
            return -998;
        }

        $g_templateid = "";
        $g_sign = "";
        
        if($type == 1){
            $g_openregister = $_config['g_openregister'];
        
            if(!$g_openregister){
                return -998;
            }else{
                if($areacode != '86'){
                    $g_templateid = $_config['g_gjregisterid'];
                    $g_sign = $_config['g_gjregistersign'];
                }else{
                    $g_templateid = $_config['g_registerid'];
                    $g_sign = $_config['g_registersign'];
                }
            }
        }elseif($type == 2 || $type == 6 || $type == 7){
            $g_openyanzheng = $_config['g_openyanzheng'];
        
            if(!$g_openyanzheng){
                return -998;
            }else{
                if($areacode != '86'){
                    $g_templateid = $_config['g_gjyanzhengid'];
                    $g_sign = $_config['g_gjyanzhengsign'];
                }else{
                    $g_templateid = $_config['g_yanzhengid'];
                    $g_sign = $_config['g_yanzhengsign'];
                }
            }
        }elseif($type == 3){
            $g_openlogin = $_config['g_openlogin'];
        
            if(!$g_openlogin){
                return -998;
            }else{
                if($areacode != '86'){
                    $g_templateid = $_config['g_gjloginid'];
                    $g_sign = $_config['g_gjloginsign'];
                }else{
                    $g_templateid = $_config['g_loginid'];
                    $g_sign = $_config['g_loginsign'];
                }
            }
        }elseif($type == 4){
            $g_openmima = $_config['g_openmima'];
        
            if(!$g_openmima){
                return -998;
            }else{
                if($areacode != '86'){
                    $g_templateid = $_config['g_gjmimaid'];
                    $g_sign = $_config['g_gjmimasign'];
                }else{
                    $g_templateid = $_config['g_mimaid'];
                    $g_sign = $_config['g_mimasign'];
                }
            }
        }elseif($type == 5){
            $g_openyanzheng = $_config['g_openyanzheng'];
        
            if(!$g_openyanzheng){
                return -998;
            }else{
                if($areacode != '86'){
                    $g_templateid = $_config['g_gjyanzhengid'];
                    $g_sign = $_config['g_gjyanzhengsign'];
                }else{
                    $g_templateid = $_config['g_yanzhengid'];
                    $g_sign = $_config['g_yanzhengsign'];
                }
            }
        }else{
            $g_openyanzheng = $_config['g_openyanzheng'];
        
            if(!$g_openyanzheng){
                return -998;
            }else{
                if($areacode != '86'){
                    $g_templateid = $_config['g_gjyanzhengid'];
                    $g_sign = $_config['g_gjyanzhengsign'];
                }else{
                    $g_templateid = $_config['g_yanzhengid'];
                    $g_sign = $_config['g_yanzhengsign'];
                }
            }
        }

        if($_config['g_checkip'] == 3 || $_config['g_checkip'] == 4){

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkphone.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkphone.class.php';
            }else{
                return -3;
            }
            $checkphone = new Checkphone();

            $checkdata = $checkphone->phoneaccessok($phone);
            $clentip = $checkdata['province'].'-'.$checkdata['city'].'-'.$checkdata['operator'];

            $isipok = $checkdata['code'];

            if(!$isipok){
                return -6;
            }

        }

        if($_config['g_checkip'] == 8 || $_config['g_checkip'] == 9){

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkphone_hc.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkphone_hc.class.php';
            }else{
                return -3;
            }
            $checkphonehc = new CheckphoneHc();

            $checkdata = $checkphonehc->phoneaccessok($phone, $areacode);
            $clentip = $checkdata['province'].'-'.$checkdata['city'].'-'.$checkdata['operator'].' / '.$checkdata['ip'];

            $isipok = $checkdata['code'];

            if(!$isipok){
                return -6;
            }

        }

        if($_config['g_checkip'] == 10){

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkphone_hc_ip.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkphone_hc_ip.class.php';
            }else{
                return -3;
            }
            $checkphonehcip = new CheckphoneHcIp();

            $clentip = $checkphonehcip->getphone_hc_ip($phone);

        }
        
        $phonesendcount = C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->count_by_phone_day($phone);
        
        if($phonesendcount >= $g_xiane){
            return -4;
        }
        
        if(empty($g_templateid)){
            return -998;
        }
        if(empty($g_sign)){
            return -998;
        }
   
       
        $sms_param_array = array();
        $sms_param_array['code']=(string)$code;

        $sms_param = json_encode($sms_param_array);
        
        $g_sign=$utils->getbianma($g_sign,$webbianma,$g_isopenhtmlspecialchars);
        $g_templateid=$utils->getbianma($g_templateid,$webbianma,$g_isopenhtmlspecialchars);
        
        //quoqishijian
        $g_youxiaoqi = $_config['g_youxiaoqi'];
        if(empty($g_youxiaoqi)){
            $g_youxiaoqi = 600;
        }
        //echo "====".date('Y-m-d H:i:s',strtotime("+".$g_youxiaoqi." second"));exit;
        $expire = strtotime("+".$g_youxiaoqi." second");
        
        
        $retdata = "";
        $phonecode = C::t('#jzsjiale_isms#jzsjiale_isms_code')->fetchfirst_by_phone($phone);
        if ($phonecode) {
            if (($phonecode['dateline'] + 60) > TIMESTAMP) {
                return -5;
            } else {
                $smstools = new ISMSTools();
                $smstools->__construct($g_accesskeyid, $g_accesskeysecret);
                $retdata = $smstools->smssend($code,$expire,$type,$uid,$areacode,$phone,$g_sign,$g_templateid,$sms_param,$clentip);
            }
        } else {
            $smstools = new ISMSTools();
            $smstools->__construct($g_accesskeyid, $g_accesskeysecret);
            $retdata = $smstools->smssend($code,$expire,$type,$uid,$areacode,$phone,$g_sign,$g_templateid,$sms_param,$clentip);
        }
        
        switch ($retdata){
            case 'success':
                return 1;
            case 'isv.MOBILE_NUMBER_ILLEGAL':
                return -1;
            case 'isv.BUSINESS_LIMIT_CONTROL':
                return -5;
            case 'error':
                return 0;
            default:
                return 0;
        }
        
    }
}
//From: d'.'is'.'m.ta'.'obao.com
?>