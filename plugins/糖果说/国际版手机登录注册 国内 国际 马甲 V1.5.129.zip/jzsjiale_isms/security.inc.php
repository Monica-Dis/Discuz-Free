<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201908141120
 * updatetime: 201908141121
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

define('JZSJIALE_ISMS_PLUGIN_ID', 'jzsjiale_isms');
define('JZSJIALE_ISMS_PLUGIN_ROOT_PATH', 'source/plugin/');
define('JZSJIALE_ISMS_PLUGIN_PATH', 'source/plugin/' . JZSJIALE_ISMS_PLUGIN_ID . '/');
define('JZSJIALE_ISMS_PLUGIN_STATIC_PATH', 'source/plugin/' . JZSJIALE_ISMS_PLUGIN_ID . '/static/');
define('JZSJIALE_ISMS_PLUGIN_TEMPLATE_SECURITY_PATH', 'source/plugin/' . JZSJIALE_ISMS_PLUGIN_ID . '/template/security/');
define('JZSJIALE_ISMS_PLUGIN_TEMPLATE_SECURITY_MOBILE_PATH', 'source/plugin/' . JZSJIALE_ISMS_PLUGIN_ID . '/template/touch/security/');
define('JZSJIALE_ISMS_PLUGIN_API', 'plugin.php?id=jzsjiale_isms:api');

global $_G, $lang;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';


$op = empty($_GET['op'])?'bindmobile':$_GET['op'];
$ac = empty($_GET['ac'])?'newbindmobile':$_GET['ac'];

loadcache('plugin');

$formhash =  addslashes($_GET['formhash'])? addslashes($_GET['formhash']):'';

if(!$_G['uid']){
    showmessage(plang('msg_need_login'), 'member.php?mod=logging&action=login');
}
$jsms_muban_pc = (array)unserialize($_G['setting']['jsms_muban_pc']);
$jsms_muban_mobile = (array)unserialize($_G['setting']['jsms_muban_mobile']);
$jsms_moreparameters = (array)unserialize($_G['setting']['jsms_moreparameters']);

if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_isms_wenti.php')){
    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_isms_wenti.php';
    $changjianwenti = $wenti;

}else{
    $wenti = C::t('#jzsjiale_isms#jzsjiale_isms_wenti')->getall();

    require_once libfile('function/cache');
    writetocache('jzsjiale_isms_wenti', getcachevars(array('wenti' => $wenti)));

    @include_once DISCUZ_ROOT.'./data/sysdata/cache_jzsjiale_isms_wenti.php';
    $changjianwenti = $wenti;

}

if ($op == 'bindmobile') {
    $navtype = 'bindmobile';
    if(defined('IN_MOBILE')){
        if (!$_config['g_openmobilebangding']) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }else{
        if (!$_config['g_openpcbangding']) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }

    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);

    if(!empty($userinfo) && !empty($userinfo['mobile'])){
        //userinfo and mobile not null start

        $member = C::t('common_member')->fetch_by_username($_G['username']);

        if(empty($member)){
            showmessage(plang('nousername'));
        }
        if($member['freeze'] > 0){
            showmessage(plang('dongjie'), 'home.php?mod=spacecp&ac=profile&op=password');
        }

        if(($userinfo[$field]=='86' || empty($userinfo[$field])) && preg_match("/^1[123456789]{1}\d{9}$/",$userinfo['mobile'])){
            $userinfo['areacode'] = '86';
            $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],7,4);
        }else{
            //magapp start
            if($_config['g_app'] == 'magapp'){
                $user_sms =  C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->get_by_mobile($userinfo['mobile']);
                if(!empty($user_sms) && (empty($userinfo[$field]) || $userinfo[$field] != $user_sms['areacode'])){
                    C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($userinfo['uid'], $user_sms['areacode'], $field);
                    $userinfo[$field] = $user_sms['areacode'];
                }
            }
            //magapp end

            if(empty($userinfo[$field])){
                showmessage(plang('pleasecheckphone'), 'plugin.php?id=jzsjiale_isms:security&op=checkphone');
            }

            $mobilelen = strlen($userinfo['mobile']);

            $userinfo['areacode'] = $userinfo[$field];
            if($mobilelen > 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],($mobilelen-4),4);
            }elseif($mobilelen > 0 && $mobilelen <= 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,1).'****'.substr($userinfo['mobile'],($mobilelen-2),2);
            }else{
                $userinfo = array();
            }
        }



        if ($ac == 'rebindmobile') {
            //rebindmobile start
            if((!defined('IN_MOBILE') && in_array('pcbindverifyoldphone',(array) unserialize($_config['g_bindoption']))) || (defined('IN_MOBILE') && in_array('mobilebindverifyoldphone',(array) unserialize($_config['g_bindoption'])))){

                if(empty($_GET['hashid']) && empty($_GET['sign'])){
                    include_once template('jzsjiale_isms:security/default/verifybindmobile');
                    return;
                }

                if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
                    @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
                    $utils = new ISMSUtils();
                }else{
                    showmessage(plang('msg_function_abnormal'), 'plugin.php?id=jzsjiale_isms:security');
                }

                if($_GET['uid'] && $_GET['uid'] == $_G['uid'] && $_GET['hashid'] && $_GET['sign'] === $utils->make_verify_sign($_GET['uid'], $_GET['hashid'])) {
                    $userinfo = array();

                    $hashid = $_GET['hashid'];
                    $uid = $_G['uid'];
                    $sign = $_GET['sign'];
                    include_once template('jzsjiale_isms:security/default/newbindmobile');
                }else{
                    showmessage(plang('msg_sign_error'), 'plugin.php?id=jzsjiale_isms:security');
                }

            }else{
                $userinfo = array();
                include_once template('jzsjiale_isms:security/default/newbindmobile');
            }

            //rebindmobile end

        }elseif ($ac == 'unbindmobile') {

            //unbindmobile start
            if((!defined('IN_MOBILE') && !in_array('pcunbind',(array) unserialize($_config['g_bindoption']))) || (defined('IN_MOBILE') && !in_array('mobileunbind',(array) unserialize($_config['g_bindoption'])))){
                include_once template('jzsjiale_isms:security/default/closed');
                return;
            }

            include_once template('jzsjiale_isms:security/default/unbindmobile');
            //unbindmobile end

        }elseif ($ac == 'emailverify') {

            //emailverify start
            if((!defined('IN_MOBILE') && !in_array('pcemailverify',(array) unserialize($_config['g_bindoption']))) || (defined('IN_MOBILE') && !in_array('mobileemailverify',(array) unserialize($_config['g_bindoption'])))){
                include_once template('jzsjiale_isms:security/default/closed');
                return;
            }

            if($_G['uid'] && !empty($member['email'])){
                $_GET['hash'] = empty($_GET['hash']) ? '' : $_GET['hash'];
                if($_GET['hash']) {
                    list($uid, $email, $time) = explode("\t", authcode($_GET['hash'], 'DECODE', md5(substr(md5($_G['config']['security']['authkey'].'jzsjiale_isms'), 0, 18))));
                    $uid = intval($uid);

                    if($uid && $uid == $_G['uid'] && isemail($email) && $email == $member['email'] && $time > TIMESTAMP - 86400) {

                        $userinfo = array();

                        if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
                            @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
                            $utils = new ISMSUtils();
                        }else{
                            showmessage(plang('msg_function_abnormal'), 'plugin.php?id=jzsjiale_isms:security');
                        }

                        $idstring = random(6);
                        $table_ext = $member['_inarchive'] ? '_archive' : '';
                        C::t('common_member_field_forum' . $table_ext)->update($_G['uid'], array('authstr' => "$_G[timestamp]\t1\t$idstring"));

                        $sign = $utils->make_verify_sign($_G['uid'], $idstring);

                        $url_forward = "plugin.php?id=jzsjiale_isms:security&op=bindmobile&ac=rebindmobile&uid=".$_G['uid']."&hashid=".$idstring."&sign=".$sign;
                        showmessage(plang('verifyemail_check_success_bindmobile'), $url_forward);
                    } else {
                        showmessage(plang('verifyemail_check_error'), 'plugin.php?id=jzsjiale_isms:security&op=bindmobile&ac=rebindmobile');
                    }
                }else{
                    $uid = $_G['uid'];
                    $email = $member['email'];
                    $hash = authcode("$uid\t$email\t$_G[timestamp]", 'ENCODE', md5(substr(md5($_G['config']['security']['authkey'].'jzsjiale_isms'), 0, 18)));
                    $verifyurl = $_G['siteurl'].'plugin.php?id=jzsjiale_isms:security&amp;op=bindmobile&amp;ac=emailverify&amp;hash='.urlencode($hash);
                    $mailsubject = plang('email_verify_subject');
                    $mailmessage = lang('plugin/jzsjiale_isms', 'email_verify_message', array(
                        'username' => $_G['member']['username'],
                        'bbname' => $_G['setting']['bbname'],
                        'siteurl' => $_G['siteurl'],
                        'url' => $verifyurl
                    ));

                    require_once libfile('function/mail');
                    if(!sendmail($email, $mailsubject, $mailmessage)) {
                        runlog('sendmail', "$email sendmail failed.");
                        showmessage(plang('verifyemail_error'), 'plugin.php?id=jzsjiale_isms:security&op=email');
                    }else{
                        showmessage(plang('verifyemail_success1').$email.plang('verifyemail_success2'), 'plugin.php?id=jzsjiale_isms:security');
                    }
                }

            }else{
                showmessage(plang('verifyemail_error'), 'plugin.php?id=jzsjiale_isms:security&op=email');
            }
            //emailverify end

        }else{

            include_once template('jzsjiale_isms:security/default/bindmobile');

        }
        //userinfo and mobile not null end
    }else{
        //newbindmobile start

        include_once template('jzsjiale_isms:security/default/newbindmobile');
        //newbindmobile end
    }


} elseif ($op == 'logonlog') {
    $navtype = 'logonlog';

    if (defined('IN_MOBILE')){
        if (!$_config['g_openmobilelogonlog']) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }else{
        if (!$_config['g_openpclogonlog']) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }

    include_once template('jzsjiale_isms:security/default/logonlog');
} elseif ($op == 'changepassword') {
    $navtype = 'changepassword';

    if (defined('IN_MOBILE')){
        if (!$_config['g_openmobilechangepwd']) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }else{
        if (!$_config['g_openpcchangepwd']) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }


    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);

    if(!empty($userinfo) && !empty($userinfo['mobile'])){
        $member = C::t('common_member')->fetch_by_username($_G['username']);

        if(empty($member)){
            showmessage(plang('nousername'));
        }
        if($member['freeze'] > 0){
            showmessage(plang('dongjie'), 'home.php?mod=spacecp&ac=profile&op=password');
        }


        if(($userinfo[$field]=='86' || empty($userinfo[$field])) && preg_match("/^1[123456789]{1}\d{9}$/",$userinfo['mobile'])){
            $userinfo['areacode'] = '86';
            $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],7,4);
        }else{

            //magapp start
            if($_config['g_app'] == 'magapp'){
                $user_sms =  C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->get_by_mobile($userinfo['mobile']);
                if(!empty($user_sms) && (empty($userinfo[$field]) || $userinfo[$field] != $user_sms['areacode'])){
                    C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($userinfo['uid'], $user_sms['areacode'], $field);
                    $userinfo[$field] = $user_sms['areacode'];
                }
            }
            //magapp end

            if(empty($userinfo[$field])){
                showmessage(plang('pleasecheckphone'), 'plugin.php?id=jzsjiale_isms:security&op=checkphone');
            }

            $mobilelen = strlen($userinfo['mobile']);

            $userinfo['areacode'] = $userinfo[$field];
            if($mobilelen > 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],($mobilelen-4),4);
            }elseif($mobilelen > 0 && $mobilelen <= 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,1).'****'.substr($userinfo['mobile'],($mobilelen-2),2);
            }else{
                $userinfo = array();
            }
        }


        if ($ac == 'rechangepassword') {
            if(empty($_GET['hashid']) && empty($_GET['sign'])){
                include_once template('jzsjiale_isms:security/default/changepasswordverifybindmobile');
                return;
            }

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
                $utils = new ISMSUtils();
            }else{
                showmessage(plang('msg_function_abnormal'), 'plugin.php?id=jzsjiale_isms:security&op=changepassword');
            }

            if($_GET['uid'] && $_GET['uid'] == $_G['uid'] && $_GET['hashid'] && $_GET['sign'] === $utils->make_verify_sign($_GET['uid'], $_GET['hashid'])) {
                $hashid = $_GET['hashid'];
                $uid = $_G['uid'];
                $sign = $_GET['sign'];
                include_once template('jzsjiale_isms:security/default/changepassword');
            }else{
                showmessage(plang('msg_sign_error'), 'plugin.php?id=jzsjiale_isms:security&op=changepassword');
            }
        }else{
            include_once template('jzsjiale_isms:security/default/changepasswordverifybindmobile');
        }
    }else{
        showmessage(plang('pleasebindphone'), 'plugin.php?id=jzsjiale_isms:security&op=bindmobile');
    }


}elseif ($op == 'changeusername') {
    $navtype = 'changeusername';

    if (defined('IN_MOBILE')){
        if (!$_config['g_openmobilechangeusername']) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }else{
        if (!$_config['g_openpcchangeusername']) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }

    $member = getuserbyuid($_G['uid'], 1);
    if (!$member || empty($member['uid'])) {
        $tip_desc = plang("tip_nouser");
        include_once template('jzsjiale_isms:security/default/closed');
        return;
    }elseif ($member['adminid'] == 1 || $member['adminid'] == 2) {
        $tip_desc = plang("tip_changeusername_account_invalid");
        include_once template('jzsjiale_isms:security/default/closed');
        return;
    }

    $groupid = $_G['groupid'];

    if ((!defined('IN_MOBILE') && !in_array($groupid, (array) unserialize($_config['g_pcchangeusernameusergroup']))) || (defined('IN_MOBILE') && !in_array($groupid, (array) unserialize($_config['g_mobilechangeusernameusergroup'])))){
        $tip_desc = plang("tip_rename_group_noaccess");
        include_once template('jzsjiale_isms:security/default/closed');
        return;
    }

    if ($_config['g_changeusernameinterval'] && $ac != 'log'){
        $lastlogdata = array();
        $lastlogdata=  C::t('#jzsjiale_isms#jzsjiale_isms_log')->fetch_one_by_uid_and_type($_G['uid'],'changeusername');

        if ($lastlogdata['dateline'] && TIMESTAMP < $lastlogdata['dateline'] + $_config['g_changeusernameinterval'] * 86400) {
            $message1 = $_config['g_changeusernameinterval'];
            $message2 = dgmdate($lastlogdata['dateline'], 'Y-m-d H:i:s');

            $tip_desc = plang("msg_err_rename_jiange_error1").$message1.plang("msg_err_rename_jiange_error2").$message2;
            $tip_desc .= "<br/>";
            $tip_desc .= "<br/>";
            $tip_desc .= "<a href='plugin.php?id=jzsjiale_isms:security&op=changeusername&ac=log' target='_self'>".plang("tip_see_changeusernamelog")."</a>";
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }


    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);

    if(!empty($userinfo) && !empty($userinfo['mobile'])){
        $member = C::t('common_member')->fetch_by_username($_G['username']);

        if(empty($member)){
            showmessage(plang('nousername'));
        }
        if($member['freeze'] > 0){
            showmessage(plang('dongjie'), 'home.php?mod=spacecp&ac=profile&op=password');
        }


        if(($userinfo[$field]=='86' || empty($userinfo[$field])) && preg_match("/^1[123456789]{1}\d{9}$/",$userinfo['mobile'])){
            $userinfo['areacode'] = '86';
            $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],7,4);
        }else{
            //magapp start
            if($_config['g_app'] == 'magapp'){
                $user_sms =  C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->get_by_mobile($userinfo['mobile']);
                if(!empty($user_sms) && (empty($userinfo[$field]) || $userinfo[$field] != $user_sms['areacode'])){
                    C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($userinfo['uid'], $user_sms['areacode'], $field);
                    $userinfo[$field] = $user_sms['areacode'];
                }
            }
            //magapp end

            if(empty($userinfo[$field])){
                showmessage(plang('pleasecheckphone'), 'plugin.php?id=jzsjiale_isms:security&op=checkphone');
            }

            $mobilelen = strlen($userinfo['mobile']);

            $userinfo['areacode'] = $userinfo[$field];
            if($mobilelen > 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],($mobilelen-4),4);
            }elseif($mobilelen > 0 && $mobilelen <= 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,1).'****'.substr($userinfo['mobile'],($mobilelen-2),2);
            }else{
                $userinfo = array();
            }
        }



        if ($ac == 'rechangeusername') {
            if(empty($_GET['hashid']) && empty($_GET['sign'])){
                include_once template('jzsjiale_isms:security/default/changeusernameverifybindmobile');
                return;
            }

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
                $utils = new ISMSUtils();
            }else{
                showmessage(plang('msg_function_abnormal'), 'plugin.php?id=jzsjiale_isms:security&op=changeusername');
            }

            if($_GET['uid'] && $_GET['uid'] == $_G['uid'] && $_GET['hashid'] && $_GET['sign'] === $utils->make_verify_sign($_GET['uid'], $_GET['hashid'])) {
                $hashid = $_GET['hashid'];
                $uid = $_G['uid'];
                $sign = $_GET['sign'];
                include_once template('jzsjiale_isms:security/default/changeusername');
            }else{
                showmessage(plang('msg_sign_error'), 'plugin.php?id=jzsjiale_isms:security&op=changeusername');
            }
        }elseif ($ac == 'log') {

            include_once template('jzsjiale_isms:security/default/changeusernamelog');
        }else{
            include_once template('jzsjiale_isms:security/default/changeusernameverifybindmobile');
        }
    }else{
        showmessage(plang('pleasebindphone'), 'plugin.php?id=jzsjiale_isms:security&op=bindmobile');
    }


}elseif ($op == 'ask') {
    $navtype = 'ask';

    if (defined('IN_MOBILE')){
        if (!$_config['g_openmobileask']) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }else{
        if (!$_config['g_openpcask']) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }

    $member = getuserbyuid($_G['uid'], 1);
    if (!$member || empty($member['uid'])) {
        $tip_desc = plang("tip_nouser");
        include_once template('jzsjiale_isms:security/default/closed');
        return;
    }

    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);

    if(!empty($userinfo) && !empty($userinfo['mobile'])){
        $member = C::t('common_member')->fetch_by_username($_G['username']);

        if(empty($member)){
            showmessage(plang('nousername'));
        }
        if($member['freeze'] > 0){
            showmessage(plang('dongjie'), 'home.php?mod=spacecp&ac=profile&op=password');
        }


        if(($userinfo[$field]=='86' || empty($userinfo[$field])) && preg_match("/^1[123456789]{1}\d{9}$/",$userinfo['mobile'])){
            $userinfo['areacode'] = '86';
            $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],7,4);
        }else{
            //magapp start
            if($_config['g_app'] == 'magapp'){
                $user_sms =  C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->get_by_mobile($userinfo['mobile']);
                if(!empty($user_sms) && (empty($userinfo[$field]) || $userinfo[$field] != $user_sms['areacode'])){
                    C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($userinfo['uid'], $user_sms['areacode'], $field);
                    $userinfo[$field] = $user_sms['areacode'];
                }
            }
            //magapp end

            if(empty($userinfo[$field])){
                showmessage(plang('pleasecheckphone'), 'plugin.php?id=jzsjiale_isms:security&op=checkphone');
            }

            $mobilelen = strlen($userinfo['mobile']);

            $userinfo['areacode'] = $userinfo[$field];
            if($mobilelen > 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],($mobilelen-4),4);
            }elseif($mobilelen > 0 && $mobilelen <= 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,1).'****'.substr($userinfo['mobile'],($mobilelen-2),2);
            }else{
                $userinfo = array();
            }
        }


        if ($ac == 'reask') {
            if(empty($_GET['hashid']) && empty($_GET['sign'])){
                include_once template('jzsjiale_isms:security/default/askverifybindmobile');
                return;
            }

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
                $utils = new ISMSUtils();
            }else{
                showmessage(plang('msg_function_abnormal'), 'plugin.php?id=jzsjiale_isms:security&op=ask');
            }

            if($_GET['uid'] && $_GET['uid'] == $_G['uid'] && $_GET['hashid'] && $_GET['sign'] === $utils->make_verify_sign($_GET['uid'], $_GET['hashid'])) {
                $hashid = $_GET['hashid'];
                $uid = $_G['uid'];
                $sign = $_GET['sign'];
                include_once template('jzsjiale_isms:security/default/ask');
            }else{
                showmessage(plang('msg_sign_error'), 'plugin.php?id=jzsjiale_isms:security&op=ask');
            }
        }else{
            include_once template('jzsjiale_isms:security/default/askverifybindmobile');
        }
    }else{
        showmessage(plang('pleasebindphone'), 'plugin.php?id=jzsjiale_isms:security&op=bindmobile');
    }


}elseif ($op == 'email') {
    $navtype = 'email';

    if (defined('IN_MOBILE')){
        if (!$_config['g_openmobileemail']) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }else{
        if (!$_config['g_openpcemail']) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }

    $member = getuserbyuid($_G['uid'], 1);
    if (!$member || empty($member['uid'])) {
        $tip_desc = plang("tip_nouser");
        include_once template('jzsjiale_isms:security/default/closed');
        return;
    }

    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);

    if(!empty($userinfo) && !empty($userinfo['mobile'])){
        $member = C::t('common_member')->fetch_by_username($_G['username']);

        if(empty($member)){
            showmessage(plang('nousername'));
        }
        if($member['freeze'] > 0){
            showmessage(plang('dongjie'), 'home.php?mod=spacecp&ac=profile&op=password');
        }


        if(($userinfo[$field]=='86' || empty($userinfo[$field])) && preg_match("/^1[123456789]{1}\d{9}$/",$userinfo['mobile'])){
            $userinfo['areacode'] = '86';
            $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],7,4);
        }else{
            //magapp start
            if($_config['g_app'] == 'magapp'){
                $user_sms =  C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->get_by_mobile($userinfo['mobile']);
                if(!empty($user_sms) && (empty($userinfo[$field]) || $userinfo[$field] != $user_sms['areacode'])){
                    C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($userinfo['uid'], $user_sms['areacode'], $field);
                    $userinfo[$field] = $user_sms['areacode'];
                }
            }
            //magapp end

            if(empty($userinfo[$field])){
                showmessage(plang('pleasecheckphone'), 'plugin.php?id=jzsjiale_isms:security&op=checkphone');
            }

            $mobilelen = strlen($userinfo['mobile']);

            $userinfo['areacode'] = $userinfo[$field];
            if($mobilelen > 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],($mobilelen-4),4);
            }elseif($mobilelen > 0 && $mobilelen <= 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,1).'****'.substr($userinfo['mobile'],($mobilelen-2),2);
            }else{
                $userinfo = array();
            }
        }


        if ($ac == 'reemail') {
            if(empty($_GET['hashid']) && empty($_GET['sign'])){
                include_once template('jzsjiale_isms:security/default/emailverifybindmobile');
                return;
            }

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
                $utils = new ISMSUtils();
            }else{
                showmessage(plang('msg_function_abnormal'), 'plugin.php?id=jzsjiale_isms:security&op=email');
            }

            if($_GET['uid'] && $_GET['uid'] == $_G['uid'] && $_GET['hashid'] && $_GET['sign'] === $utils->make_verify_sign($_GET['uid'], $_GET['hashid'])) {
                $hashid = $_GET['hashid'];
                $uid = $_G['uid'];
                $sign = $_GET['sign'];
                include_once template('jzsjiale_isms:security/default/email');
            }else{
                showmessage(plang('msg_sign_error'), 'plugin.php?id=jzsjiale_isms:security&op=email');
            }
        }else{
            include_once template('jzsjiale_isms:security/default/emailverifybindmobile');
        }
    }else{
        showmessage(plang('pleasebindphone'), 'plugin.php?id=jzsjiale_isms:security&op=bindmobile');
    }


}elseif ($op == 'logoff') {
    $navtype = 'logoff';

    if (defined('IN_MOBILE')){
        if (!$_config['g_openmobilelogoff'] || $_config['g_openmobilelogoff'] != 1) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }else{
        if (!$_config['g_openpclogoff'] || $_config['g_openpclogoff'] != 1) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }

    $member = getuserbyuid($_G['uid'], 1);
    if (!$member || empty($member['uid'])) {
        $tip_desc = plang("tip_nouser");
        include_once template('jzsjiale_isms:security/default/closed');
        return;
    }elseif ($member['adminid'] == 1 || $member['adminid'] == 2) {
        $tip_desc = plang("tip_logoff_account_invalid");
        include_once template('jzsjiale_isms:security/default/closed');
        return;
    }

    $groupid = $_G['groupid'];

    if ((!defined('IN_MOBILE') && !in_array($groupid, (array) unserialize($_config['g_pclogoffusergroup']))) || (defined('IN_MOBILE') && !in_array($groupid, (array) unserialize($_config['g_mobilelogoffusergroup'])))){
        $tip_desc = plang("tip_logoff_group_noaccess");
        include_once template('jzsjiale_isms:security/default/closed');
        return;
    }

    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);

    if(!empty($userinfo) && !empty($userinfo['mobile'])){
        $member = C::t('common_member')->fetch_by_username($_G['username']);

        if(empty($member)){
            showmessage(plang('nousername'));
        }
        if($member['freeze'] > 0){
            showmessage(plang('dongjie'), 'home.php?mod=spacecp&ac=profile&op=password');
        }


        if(($userinfo[$field]=='86' || empty($userinfo[$field])) && preg_match("/^1[123456789]{1}\d{9}$/",$userinfo['mobile'])){
            $userinfo['areacode'] = '86';
            $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],7,4);
        }else{
            //magapp start
            if($_config['g_app'] == 'magapp'){
                $user_sms =  C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->get_by_mobile($userinfo['mobile']);
                if(!empty($user_sms) && (empty($userinfo[$field]) || $userinfo[$field] != $user_sms['areacode'])){
                    C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($userinfo['uid'], $user_sms['areacode'], $field);
                    $userinfo[$field] = $user_sms['areacode'];
                }
            }
            //magapp end

            if(empty($userinfo[$field])){
                showmessage(plang('pleasecheckphone'), 'plugin.php?id=jzsjiale_isms:security&op=checkphone');
            }

            $mobilelen = strlen($userinfo['mobile']);

            $userinfo['areacode'] = $userinfo[$field];
            if($mobilelen > 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],($mobilelen-4),4);
            }elseif($mobilelen > 0 && $mobilelen <= 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,1).'****'.substr($userinfo['mobile'],($mobilelen-2),2);
            }else{
                $userinfo = array();
            }
        }


        if ($ac == 'nowlogoff') {
            if(empty($_GET['hashid']) && empty($_GET['sign'])){
                include_once template('jzsjiale_isms:security/default/logoffverifybindmobile');
                return;
            }

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
                $utils = new ISMSUtils();
            }else{
                showmessage(plang('msg_function_abnormal'), 'plugin.php?id=jzsjiale_isms:security&op=logoff');
            }

            if($_GET['uid'] && $_GET['uid'] == $_G['uid'] && $_GET['hashid'] && $_GET['sign'] === $utils->make_verify_sign($_GET['uid'], $_GET['hashid'])) {
                $hashid = $_GET['hashid'];
                $uid = $_G['uid'];
                $sign = $_GET['sign'];
                include_once template('jzsjiale_isms:security/default/logoff');
            }else{
                showmessage(plang('msg_sign_error'), 'plugin.php?id=jzsjiale_isms:security&op=logoff');
            }
        }else{
            include_once template('jzsjiale_isms:security/default/logoffverifybindmobile');
        }
    }else{
        showmessage(plang('pleasebindphone'), 'plugin.php?id=jzsjiale_isms:security&op=bindmobile');
    }


} elseif ($op == 'logoffapply') {
    $navtype = 'logoffapply';

    if (defined('IN_MOBILE')){
        if (!$_config['g_openmobilelogoff'] || $_config['g_openmobilelogoff'] != 2) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }else{
        if (!$_config['g_openpclogoff'] || $_config['g_openpclogoff'] != 2) {
            include_once template('jzsjiale_isms:security/default/closed');
            return;
        }
    }

    $member = getuserbyuid($_G['uid'], 1);
    if (!$member || empty($member['uid'])) {
        $tip_desc = plang("tip_nouser");
        include_once template('jzsjiale_isms:security/default/closed');
        return;
    }elseif ($member['adminid'] == 1 || $member['adminid'] == 2) {
        $tip_desc = plang("tip_logoff_account_invalid");
        include_once template('jzsjiale_isms:security/default/closed');
        return;
    }

    $groupid = $_G['groupid'];

    if ((!defined('IN_MOBILE') && !in_array($groupid, (array) unserialize($_config['g_pclogoffusergroup']))) || (defined('IN_MOBILE') && !in_array($groupid, (array) unserialize($_config['g_mobilelogoffusergroup'])))){
        $tip_desc = plang("tip_logoff_group_noaccess");
        include_once template('jzsjiale_isms:security/default/closed');
        return;
    }

    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);

    if(!empty($userinfo) && !empty($userinfo['mobile'])){
        $member = C::t('common_member')->fetch_by_username($_G['username']);

        if(empty($member)){
            showmessage(plang('nousername'));
        }
        if($member['freeze'] > 0){
            showmessage(plang('dongjie'), 'home.php?mod=spacecp&ac=profile&op=password');
        }

        if(($userinfo[$field]=='86' || empty($userinfo[$field])) && preg_match("/^1[123456789]{1}\d{9}$/",$userinfo['mobile'])){
            $userinfo['areacode'] = '86';
            $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],7,4);
        }else{
            //magapp start
            if($_config['g_app'] == 'magapp'){
                $user_sms =  C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->get_by_mobile($userinfo['mobile']);
                if(!empty($user_sms) && (empty($userinfo[$field]) || $userinfo[$field] != $user_sms['areacode'])){
                    C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($userinfo['uid'], $user_sms['areacode'], $field);
                    $userinfo[$field] = $user_sms['areacode'];
                }
            }
            //magapp end

            if(empty($userinfo[$field])){
                showmessage(plang('pleasecheckphone'), 'plugin.php?id=jzsjiale_isms:security&op=checkphone');
            }

            $mobilelen = strlen($userinfo['mobile']);

            $userinfo['areacode'] = $userinfo[$field];
            if($mobilelen > 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],($mobilelen-4),4);
            }elseif($mobilelen > 0 && $mobilelen <= 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,1).'****'.substr($userinfo['mobile'],($mobilelen-2),2);
            }else{
                $userinfo = array();
            }
        }

        if ($ac == 'nowlogoff') {
            if(empty($_GET['hashid']) && empty($_GET['sign'])){
                include_once template('jzsjiale_isms:security/default/logoffapplyverifybindmobile');
                return;
            }

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
                $utils = new ISMSUtils();
            }else{
                showmessage(plang('msg_function_abnormal'), 'plugin.php?id=jzsjiale_isms:security&op=logoffapply');
            }

            if($_GET['uid'] && $_GET['uid'] == $_G['uid'] && $_GET['hashid'] && $_GET['sign'] === $utils->make_verify_sign($_GET['uid'], $_GET['hashid'])) {
                $hashid = $_GET['hashid'];
                $uid = $_G['uid'];
                $sign = $_GET['sign'];
                include_once template('jzsjiale_isms:security/default/logoffapply');
            }else{
                showmessage(plang('msg_sign_error'), 'plugin.php?id=jzsjiale_isms:security&op=logoffapply');
            }
        }elseif ($ac == 'cancel') {
            $logoffapply_userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->fetch_one_by_uid_and_freeze($_G['uid'], '-1');
            if($logoffapply_userinfo){

                if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
                    @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
                    $utils = new ISMSUtils();
                }else{
                    showmessage(plang('msg_function_abnormal'), 'plugin.php?id=jzsjiale_isms:security&op=logoffapply');
                }


                $client_loginfo = $utils->get_log_info();
                $data = array(
                    'uid' => $member['uid'],
                    'username' => $member['username'],
                    'areacode' => $userinfo[$field],
                    'phone' => $userinfo['mobile'],
                    'type' => 'logoffapply',
                    'operationuid' => $_G['uid'],
                    'ip' => $client_loginfo['client_ip'],
                    'port' => $client_loginfo['client_port'],
                    'browser' => $client_loginfo['client_browser'],
                    'os' => $client_loginfo['client_os'],
                    'device' => $client_loginfo['client_device'],
                    'useragent' => $client_loginfo['client_useragent'],
                    'record' => 'cancel',
                    'dateline' => TIMESTAMP
                );

                C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

                C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->deletebyid($logoffapply_userinfo['id']);
                showmessage(plang('msg_logoffapply_cancel_ok'), 'plugin.php?id=jzsjiale_isms:security&op=logoffapply');
            }else{
                showmessage(plang('msg_logoffapply_cancel_error'), 'plugin.php?id=jzsjiale_isms:security&op=logoffapply');
            }
        }elseif ($ac == 'iknow') {
            $logoffapply_userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->fetch_one_by_uid_and_freeze($_G['uid'], '-2');
            if($logoffapply_userinfo){

                if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
                    @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
                    $utils = new ISMSUtils();
                }else{
                    showmessage(plang('msg_function_abnormal'), 'plugin.php?id=jzsjiale_isms:security&op=logoffapply');
                }


                $client_loginfo = $utils->get_log_info();
                $data = array(
                    'uid' => $member['uid'],
                    'username' => $member['username'],
                    'areacode' => $userinfo[$field],
                    'phone' => $userinfo['mobile'],
                    'type' => 'logoffapply',
                    'operationuid' => $_G['uid'],
                    'ip' => $client_loginfo['client_ip'],
                    'port' => $client_loginfo['client_port'],
                    'browser' => $client_loginfo['client_browser'],
                    'os' => $client_loginfo['client_os'],
                    'device' => $client_loginfo['client_device'],
                    'useragent' => $client_loginfo['client_useragent'],
                    'record' => 'iknow',
                    'dateline' => TIMESTAMP
                );

                C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

                C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->deletebyid($logoffapply_userinfo['id']);
                showmessage(plang('msg_logoffapply_iknow_ok'), 'plugin.php?id=jzsjiale_isms:security&op=logoffapply');
            }else{
                showmessage(plang('msg_logoffapply_iknow_error'), 'plugin.php?id=jzsjiale_isms:security&op=logoffapply');
            }
        }else{
            $logoffapply_userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->fetch_by_uid($_G['uid']);
            if($logoffapply_userinfo['freeze'] != '-1' && $logoffapply_userinfo['freeze'] != '-2'){
                include_once template('jzsjiale_isms:security/default/logoffapplyverifybindmobile');
            }else{
                if($logoffapply_userinfo['freeze'] == '-2'){
                    $logoffapply_info = C::t('#jzsjiale_isms#jzsjiale_isms_log')->fetch_one_by_uid_and_type($_G['uid'],'logoffapply');
                }
                include_once template('jzsjiale_isms:security/default/logoffapply_info');
            }

        }
    }else{
        showmessage(plang('pleasebindphone'), 'plugin.php?id=jzsjiale_isms:security&op=bindmobile');
    }


} elseif ($op == 'needverify') {
    $navtype = 'needverify';

    if(is_null(getglobal('isms_freeze')) || getglobal('isms_freeze') == 0){
        include_once template('jzsjiale_isms:security/default/closed');
        return;
    }


    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);

    if(!empty($userinfo) && !empty($userinfo['mobile'])){
        $member = C::t('common_member')->fetch_by_username($_G['username']);

        if(empty($member)){
            showmessage(plang('nousername'));
        }
        if($member['freeze'] > 0){
            showmessage(plang('dongjie'), 'home.php?mod=spacecp&ac=profile&op=password');
        }


        if(($userinfo[$field]=='86' || empty($userinfo[$field])) && preg_match("/^1[123456789]{1}\d{9}$/",$userinfo['mobile'])){
            $userinfo['areacode'] = '86';
            $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],7,4);
        }else{
            //magapp start
            if($_config['g_app'] == 'magapp'){
                $user_sms =  C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->get_by_mobile($userinfo['mobile']);
                if(!empty($user_sms) && (empty($userinfo[$field]) || $userinfo[$field] != $user_sms['areacode'])){
                    C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($userinfo['uid'], $user_sms['areacode'], $field);
                    $userinfo[$field] = $user_sms['areacode'];
                }
            }
            //magapp end

            if(empty($userinfo[$field])){
                showmessage(plang('pleasecheckphone'), 'plugin.php?id=jzsjiale_isms:security&op=checkphone');
            }

            $mobilelen = strlen($userinfo['mobile']);

            $userinfo['areacode'] = $userinfo[$field];
            if($mobilelen > 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],($mobilelen-4),4);
            }elseif($mobilelen > 0 && $mobilelen <= 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,1).'****'.substr($userinfo['mobile'],($mobilelen-2),2);
            }else{
                $userinfo = array();
            }
        }



        if(getglobal('isms_freeze') == 1){
            $tip_desc = plang("msg_err_location_login_password_tooshort");
        }elseif (getglobal('isms_freeze') == 2 || getglobal('isms_freeze') == 4){
            $tip_desc = plang("msg_err_location_login_outofdate");
        }elseif (getglobal('isms_freeze') == 3){
            $tip_desc = plang("msg_err_location_login_differentplaces");
        }else{
            $tip_desc = plang("msg_err_location_login_needverify");
        }
        include_once template('jzsjiale_isms:security/default/needverify');
    }else{
        showmessage(plang('pleasebindphone'), 'plugin.php?id=jzsjiale_isms:security&op=bindmobile');
    }

} elseif ($op == 'checkphone') {
    $navtype = 'checkphone';

    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);

    if(!empty($userinfo) && !empty($userinfo['mobile'])){
        $member = C::t('common_member')->fetch_by_username($_G['username']);

        if(empty($member)){
            showmessage(plang('nousername'));
        }

        if(preg_match("/^1[123456789]{1}\d{9}$/",$userinfo['mobile'])){
            if(empty($userinfo[$field]) || $userinfo[$field] == '86'){
                showmessage(plang('tiaozhuanzhong'), 'plugin.php?id=jzsjiale_isms:security&op=bindmobile');
            }

            $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],7,4);
        }else{
            $mobilelen = strlen($userinfo['mobile']);
            if(!empty($userinfo[$field])){
                showmessage(plang('tiaozhuanzhong'), 'plugin.php?id=jzsjiale_isms:security&op=bindmobile');
            }
            if($mobilelen > 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,3).'****'.substr($userinfo['mobile'],($mobilelen-4),4);
            }elseif($mobilelen > 0 && $mobilelen <= 7){
                $userinfo['phone'] = substr($userinfo['mobile'],0,1).'****'.substr($userinfo['mobile'],($mobilelen-2),2);
            }else{
                $userinfo = array();
            }
        }

        include_once template('jzsjiale_isms:security/default/checkphone');
    }else{
        showmessage(plang('pleasebindphone'), 'plugin.php?id=jzsjiale_isms:security&op=bindmobile');
    }

} else{
    showmessage(plang('tiaozhuanzhong'), 'plugin.php?id=jzsjiale_isms:security&op=bindmobile');
}


function plang($str) {
    return lang('plugin/jzsjiale_isms', $str);
}
?>