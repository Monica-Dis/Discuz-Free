<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class JzsjialeIsmsSetting {


	function menu() {
		global $_G;

echo <<<EOF
<style>
.floattop { display: none; }
.floattopempty { display: none; }
.mymenu { height:35px; }
.mymenu .floattop { display: inline; }
.mymenu .floattopempty { display: inline; }
</style>
EOF;

		echo '<div class="mymenu">';
		showsubmenu(lang('plugin/jzsjiale_isms', 'menu_root'), array(
            array(lang('plugin/jzsjiale_isms', 'menu_fanhui'), 'plugins&operation=config&identifier=jzsjiale_isms'),
            array(lang('plugin/jzsjiale_isms', 'menu_pc'), 'plugins&operation=config&identifier=jzsjiale_isms&pmod=muban&type=pc', $_GET['pmod'] == 'mubanpc'),
			array(lang('plugin/jzsjiale_isms', 'menu_mobile'), 'plugins&operation=config&identifier=jzsjiale_isms&pmod=muban&type=mobile', $_GET['pmod'] == 'mubanmobile'),
            array(lang('plugin/jzsjiale_isms', 'menu_wenti'), 'plugins&operation=config&identifier=jzsjiale_isms&pmod=muban&type=wenti', $_GET['pmod'] == 'wenti'),
            array(lang('plugin/jzsjiale_isms', 'menu_xieyi'), 'plugins&operation=config&identifier=jzsjiale_isms&pmod=muban&type=xieyi', $_GET['pmod'] == 'xieyi'),
            array(lang('plugin/jzsjiale_isms', 'menu_yinsi'), 'plugins&operation=config&identifier=jzsjiale_isms&pmod=muban&type=yinsi', $_GET['pmod'] == 'yinsi'),
		));
		echo '</div>';

	}


}