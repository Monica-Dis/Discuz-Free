<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
loadcache('plugin');
global $_G, $lang;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];

/////////tip start

echo '<div class="colorbox"><h4>'.plang('aboutlog').'</h4>'.
    '<table cellspacing="0" cellpadding="3"><tr>'.
    '<td valign="top">'.plang('logdescription').'</td></tr></table>'.
    '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

/////////tip end

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=log', 'enctype');


$keyword = daddslashes(trim($_GET['keyword']));
$type = daddslashes(trim($_GET['type']));
$uid = daddslashes(trim($_GET['uid']));
$ip = daddslashes(trim($_GET['ip']));

$page = intval($_GET['page']);
$page = $page > 0 ? $page : 1;
$pagesize = 20;
$start = ($page - 1) * $pagesize;

//20190728start
$map = array();
if(!empty($keyword)){
    $map['keyword'] = $keyword;
}
if(!empty($type) && $type != 'all'){
    $map['type'] = $type;
}
if(!empty($uid)){
    $map['uid'] = $uid;
}
if(!empty($ip)){
    $map['ip'] = $ip;
}

$alllog = C::t('#jzsjiale_isms#jzsjiale_isms_log')->range_by_map($map,$start,$pagesize,'DESC');
$count = C::t('#jzsjiale_isms#jzsjiale_isms_log')->count_by_map($map);

$type_options = "<option value='all'  " . (($type == 'all') ? "selected='selected'" : '') . ">" . plang('statusall') . "</option>"
    . "<option value='register' " . (($type == 'register') ? "selected='selected'" : '') . ">" . plang('logtype')['register'] . "</option>"
    . "<option value='login' " . (($type == 'login') ? "selected='selected'" : '') . ">" . plang('logtype')['login'] . "</option>"
    . "<option value='bind' " . (($type == 'bind') ? "selected='selected'" : '') . ">" . plang('logtype')['bind'] . "</option>"
    . "<option value='unbind' " . (($type == 'unbind') ? "selected='selected'" : '') . ">" . plang('logtype')['unbind'] . "</option>"
    . "<option value='forgotpassword' " . (($type == 'forgotpassword') ? "selected='selected'" : '') . ">" . plang('logtype')['forgotpassword'] . "</option>"
    . "<option value='changepassword' " . (($type == 'changepassword') ? "selected='selected'" : '') . ">" . plang('logtype')['changepassword'] . "</option>"
    . "<option value='verify' " . (($type == 'verify') ? "selected='selected'" : '') . ">" . plang('logtype')['verify'] . "</option>"
    . "<option value='logoff' " . (($type == 'logoff') ? "selected='selected'" : '') . ">" . plang('logtype')['logoff'] . "</option>"
    . "<option value='logoffapply' " . (($type == 'logoffapply') ? "selected='selected'" : '') . ">" . plang('logtype')['logoffapply'] . "</option>"
    . "<option value='logonlog' " . (($type == 'logonlog') ? "selected='selected'" : '') . ">" . plang('logtype')['logonlog'] . "</option>"
    . "<option value='changeusername' " . (($type == 'changeusername') ? "selected='selected'" : '') . ">" . plang('logtype')['changeusername'] . "</option>"
    . "<option value='changeusernamelog' " . (($type == 'changeusernamelog') ? "selected='selected'" : '') . ">" . plang('logtype')['changeusernamelog'] . "</option>"
    . "<option value='magappchangeusername' " . (($type == 'magappchangeusername') ? "selected='selected'" : '') . ">" . plang('logtype')['magappchangeusername'] . "</option>"
    . "<option value='freeze' " . (($type == 'freeze') ? "selected='selected'" : '') . ">" . plang('logtype')['freeze'] . "</option>"
    . "<option value='unfreeze' " . (($type == 'unfreeze') ? "selected='selected'" : '') . ">" . plang('logtype')['unfreeze'] . "</option>"
    . "<option value='needverify' " . (($type == 'needverify') ? "selected='selected'" : '') . ">" . plang('logtype')['needverify'] . "</option>"
    . "<option value='checkphone' " . (($type == 'checkphone') ? "selected='selected'" : '') . ">" . plang('logtype')['checkphone'] . "</option>";


showtablerow('', array('width="150"', 'width="150"', 'width="150"', ''), array(
plang('logtypetitle'),
"<select name=\"type\">$type_options</select>",
"uid:<input size=\"20\" name=\"uid\" type=\"text\" value=\"$uid\" />",
plang('userphone'),
"<input size=\"20\" name=\"keyword\" type=\"text\" value=\"$keyword\" />",
plang('smsip'),
"<input size=\"20\" name=\"ip\" type=\"text\" value=\"$ip\" />
<input class=\"btn\" type=\"submit\" value=\"" . cplang('search') . "\" />"
    )
);

showtableheader(plang('loglist').'(&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=more&module=logexport" style="color:red;">'.plang('exportlog').'</a>&nbsp;&nbsp;)');
showsubtitle(plang('loglisttitle'));
foreach($alllog as $d){
    showtablerow('', array('width="50"'), array(
    $d['id'],
    '<span title="'.$d['uid'].'"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=log&uid='.$d['uid'].'" target="_self">'.$d['uid'].'</a><a href="home.php?mod=space&uid='.$d['uid'].'&do=profile" target="_blank" style="color:green;" target="_self">'.(!empty($d['uid'])?'  @profile':'').'</a></span>',
    '<span title="'.$d['uid'].'"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=log&keyword='.$d['username'].'" target="_self">'.$d['username'].'</a></span>',
    '<span title="'.(!empty($d['phone'])?(!empty($d['areacode'])?$d['areacode']:'86'):'').'"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&areacodesearch=1&keyword='.(!empty($d['phone'])?(!empty($d['areacode'])?$d['areacode']:'86'):'').'" target="_blank">'.(!empty($d['phone'])?(!empty($d['areacode'])?($d['type']!='unbind'?$d['areacode']:'<del>'.$d['areacode'].'</del>'):((preg_match("/^1[123456789]{1}\d{9}$/",$d['phone']) || preg_match("/^861[123456789]{1}\d{9}$/",$d['phone']))?($d['type']!='unbind'?'86':'<del>86</del>'):'')):'').'</a></span>',
    '<span title="'.$d['phone'].'"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=log&keyword='.$d['phone'].'" target="_self">'.($d['type']!='unbind'?$d['phone']:'<del>'.$d['phone'].'</del>').'</a><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismslist&phone='.$d['phone'].'" style="color:green;" target="_self">'.(!empty($d['phone'])?'  @sms':'').'</a></span>',
    plang("logtype")[$d['type']].'('.$d['type'].')',
    get_record($d['record'], $d['type']),
    '<span title="'.$d['operationuid'].'"><a href="home.php?mod=space&uid='.$d['operationuid'].'&do=profile" target="_blank">'.$d['operationuid'].'</a></span>',
    '<span title="'.$d['ip'].'"><a href="http://ip.taobao.com/service/getIpInfo.php?ip='.$d['ip'].'" target="_blank">'.$d['ip'].'</a></span>',
    $d['port'],
    $d['os'],
    $d['browser'],
    $d['device'],
    '<span title="'.$d['useragent'].'" onclick="javascript:alert(\''.$d['useragent'].'\');" style="cursor:pointer;">'.plang('clickview').'</span>',
    dgmdate($d['dateline'], 'Y-m-d H:i:s'))
    );
}

$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=log&keyword='.$keyword.'&type='.$type.'&uid='.$uid.'&ip='.$ip;
$multipage = multi($count, $pagesize, $page, $mpurl);
//showsubmit('', '', '', '', $multipage);


//search start
showsubmit('', '', '', '', $multipage);

//search end


showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/


function get_record($record, $type = "") {
    $ret = "#";
    if(!empty($record)){

        if($type == "changeusername"){
            $tmp = (array)unserialize($record);
            $ret = plang('oldusername').$tmp['oldusername'].'<br/>'.plang('newusername').$tmp['newusername'];
        }elseif($type == "bind"){
            $tmp = (array)unserialize($record);
            $ret = plang('beforerebind_areacode').$tmp['beforerebind_areacode'].'<br/>'.plang('beforerebind_phone').$tmp['beforerebind_phone'];
        }elseif($type == "unbind"){
            $tmp = (array)unserialize($record);
            $ret = plang('beforebinding_areacode').$tmp['beforebinding_areacode'].'<br/>'.plang('beforebinding_phone').$tmp['beforebinding_phone'];
        }elseif($type == "verify" && !empty($record)){
            $ret = in_array($record,array('logoff','logoffapply','changepassword','changeusername'))?plang('logtype')[$record]:'#';
        }elseif($type == "logoff"){
            $ret = $record == 'ok'?plang('logoff_ok'):'#';
        }elseif($type == "logoffapply"){
            switch ($record){
                case 'apply':$ret = plang('logoffapply_ok');break;
                case 'cancel':$ret = plang('logoffapply_cancel');break;
                case 'iknow':$ret = plang('logoffapply_iknow');break;
                default: $ret = $record;break;
            }
        }elseif($type == "ask"){
            $ret = $record == 'ask'?plang('security_ask'):'#';
        }elseif($type == "email"){
            $ret = $record == 'email'?plang('security_email'):'#';
        }elseif($type == "login"){
            $ret = '#';
            if(!empty($record)){
                if($record == 'login_by_seccode'){
                    $ret = plang($record);
                }elseif (!empty($tmp = (array)unserialize($record)) && $tmp['logintype'] == 'login_by_mima'){
                    $ret = $tmp['type'].'+'.plang($tmp['logintype']);
                }
            }

            //$ret = (!empty($record) && in_array($record,array('login_by_seccode','login_by_mima')))?plang($record):'#';
        }elseif($type == "freeze"){
            switch ($record){
                case 1:
                    $ret = plang('memberstatus1');
                    break;
                case 2:
                    $ret = plang('memberstatus2');
                    break;
                case 3:
                    $ret = plang('memberstatus3');
                    break;
                case 4:
                    $ret = plang('memberstatus4');
                    break;
                case 5:
                    $ret = plang('memberstatus5');
                    break;
                default:
                    $ret = plang('memberstatus6');
                    break;
            }
        }elseif($type == "checkphone"){
            $tmp = (array)unserialize($record);
            $ret = "";
            switch ($tmp['status']){
                case 'success':
                    $ret = plang('checkphone_success').'<br/>'.plang('checkphone_userinput_areacode').$tmp['areacode'].'<br/>'.plang('beforerebind_userinput_phone').$tmp['phone'];
                    break;
                case 'error':
                    $ret = plang('checkphone_error').'<br/>'.plang('checkphone_userinput_areacode').$tmp['areacode'].'<br/>'.plang('beforerebind_userinput_phone').$tmp['phone'];
                    break;
                case 'updateareacode':
                    $ret = plang('checkphone_updateareacode').'<br/>'.plang('checkphone_before_update').$tmp['areacode_old'].'<br/>'.plang('checkphone_after_update').$tmp['areacode'];
                    break;
                case 'updatephone':
                    $ret = plang('checkphone_updatephone').'<br/>'.plang('checkphone_before_update').$tmp['phone_old'].'<br/>'.plang('checkphone_after_update').$tmp['phone'];
                    break;
                default:
                    $ret = plang('checkphone_error').'<br/>'.plang('checkphone_userinput_areacode').$tmp['areacode'].'<br/>'.plang('beforerebind_userinput_phone').$tmp['phone'];
                    break;
            }

        }else{
            $ret = $record;
        }
    }
    return $ret;
}

function plang($str) {
    return lang('plugin/jzsjiale_isms', $str);
}
//From: d'.'is'.'m.ta'.'obao.com
?>