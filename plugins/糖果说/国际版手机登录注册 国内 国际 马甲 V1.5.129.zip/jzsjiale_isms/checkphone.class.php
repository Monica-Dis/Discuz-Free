<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class Checkphone
{
    function phoneaccessok($phone="") {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];
        $g_checkip = $_config['g_checkip'];
        $g_checkipregion = $_config['g_checkipregion'];
        $g_checkipcity = $_config['g_checkipcity'];
        $webbianma = $_G['charset'];
        $ret_phone_info = array();


        if($g_checkip == 3){

            $phoneInfo = array();
            if (!empty($g_checkipregion) || !empty($g_checkipcity)) {
                $phoneInfo = $this->get_phone_data($phone);

                if($phoneInfo === false || $phoneInfo == "" || empty($phoneInfo) || empty($phoneInfo['detail']['province']) || empty($phoneInfo['detail']['area'][0]['city'])){
                    $phoneInfo = $this->get_phone_data($phone);
                }
                if($phoneInfo === false || $phoneInfo == "" || empty($phoneInfo) || empty($phoneInfo['detail']['province']) || empty($phoneInfo['detail']['area'][0]['city'])){
                    $ret_phone_info['code'] = false;
                    return $ret_phone_info;
                }
                $ret_phone_info['province'] = $this->getbianma($phoneInfo['detail']['province'],$webbianma);
                $ret_phone_info['city'] = $this->getbianma($phoneInfo['detail']['area'][0]['city'],$webbianma);
                $ret_phone_info['operator'] = $this->getbianma($phoneInfo['detail']['operator'],$webbianma);
            }else{
                $ret_phone_info['code'] = true;
                return $ret_phone_info;
            }

            if(!empty($g_checkipregion) && !empty($ret_phone_info)){
                $region_arr = array_filter(array_map("trim", explode("|",$g_checkipregion)));
                if (!empty($region_arr) && isset($ret_phone_info['province'])) {
                    if($this->CheckRegion($region_arr, $ret_phone_info['province'])){
                        $ret_phone_info['code'] = false;
                        return $ret_phone_info;
                    }
                }
            }
            if(!empty($g_checkipcity) && !empty($ret_phone_info)){
                $city_arr = array_filter(array_map("trim", explode("|",$g_checkipcity)));
                if (!empty($city_arr) && isset($ret_phone_info['city'])) {
                    if($this->CheckCity($city_arr, $ret_phone_info['city'])){
                        $ret_phone_info['code'] = false;
                        return $ret_phone_info;
                    }
                }
            }
            $ret_phone_info['code'] = true;
            return $ret_phone_info;
        }else if($g_checkip == 4){

            $phoneInfo = array();
            if (!empty($g_checkipregion) || !empty($g_checkipcity)) {
                $phoneInfo = $this->get_phone_data($phone);

                if($phoneInfo === false || $phoneInfo == "" || empty($phoneInfo) || empty($phoneInfo['detail']['province']) || empty($phoneInfo['detail']['area'][0]['city'])){
                    $phoneInfo = $this->get_phone_data($phone);
                }
                if($phoneInfo === false || $phoneInfo == "" || empty($phoneInfo) || empty($phoneInfo['detail']['province']) || empty($phoneInfo['detail']['area'][0]['city'])){
                    $ret_phone_info['code'] = false;
                    return $ret_phone_info;
                }
                $ret_phone_info['province'] = $this->getbianma($phoneInfo['detail']['province'],$webbianma);
                $ret_phone_info['city'] = $this->getbianma($phoneInfo['detail']['area'][0]['city'],$webbianma);
                $ret_phone_info['operator'] = $this->getbianma($phoneInfo['detail']['operator'],$webbianma);
            }else{
                $ret_phone_info['code'] = false;
                return $ret_phone_info;
            }


            if(!empty($g_checkipcity) && !empty($ret_phone_info)){
                $city_arr = array_filter(array_map("trim", explode("|",$g_checkipcity)));
                if (!empty($city_arr) && isset($ret_phone_info['city'])) {
                    if($this->CheckCity($city_arr, $ret_phone_info['city'])){
                        $ret_phone_info['code'] = true;
                        return $ret_phone_info;
                    }else{
                        $ret_phone_info['code'] = false;
                        return $ret_phone_info;
                    }
                }
            }
            if(!empty($g_checkipregion) && !empty($ret_phone_info)){
                $region_arr = array_filter(array_map("trim", explode("|",$g_checkipregion)));
                if (!empty($region_arr) && isset($ret_phone_info['province'])) {
                    if($this->CheckRegion($region_arr, $ret_phone_info['province'])){
                        $ret_phone_info['code'] = true;
                        return $ret_phone_info;
                    }else{
                        $ret_phone_info['code'] = false;
                        return $ret_phone_info;
                    }
                }
            }

            $ret_phone_info['code'] = false;
            return $ret_phone_info;
        }else{
            $ret_phone_info['code'] = true;
            return $ret_phone_info;
        }



    }

    private function CheckRegion($region_arr,$user_region){
        foreach($region_arr as $value){
            if(preg_match("/^{$value}*/", $user_region)){
                return true;
            }
        }
        return false;
    }
    
    private function CheckCity($city_arr,$user_city){
        foreach($city_arr as $value){
            if(preg_match("/^{$value}*/", $user_city)){
                return true;
            }
        }
        return false;
    }


    private function get_phone_data($phone=""){
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, "http://mobsec-dianhua.baidu.com/dianhua_api/open/location?tel=".$phone);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $data = curl_exec($curl);
        curl_close($curl);
        
        $phonedata = json_decode($data, true);
        if($phonedata['response'][$phone] == null || empty($phonedata['response'][$phone])){
            return false;
        }
        $data = $phonedata['response'][$phone];
        return $data;
    }


    private function getbianma($data, $webbianma = "gbk")
    {
        if ($webbianma == "gbk") {
            $data = diconv($data, 'UTF-8', 'GBK');
        }
        return $data;
    }
}
?>