<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';
$result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'smserror'));

$areacode = addslashes($_POST['country_code']);
$phone = addslashes($_POST['mobile']);
$device = addslashes($_POST['device']);
$remote_ip = addslashes($_POST['remote_ip']);
$key = addslashes($_POST['key']);
$type = 6;

if(empty($_config['g_appsafekey']) || empty($key) ||$_config['g_appsafekey'] != $key){
    $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'smserror').'(code.1001)');
    api_core::result_app($result);
}

if (empty($areacode)){
    $areacode = '86';
}elseif (!empty($areacode) && !preg_match("/^[0-9]+$/",$areacode)){
    $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'app_areacode_error'));
    api_core::result_app($result);
}
if (empty($phone)){
    $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'app_phone_null'));
    api_core::result_app($result);
}


if(!$utils->isMobile($phone,$areacode)){
    $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'app_phone_error'));
    api_core::result_app($result);
}


//send sms start
if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/ismsapi.inc.php')){
    @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/ismsapi.inc.php';
    $ismsapi = new ISMSApi();

    $codelength = 6;
    if(!empty($_config['g_seccodebits']) && $_config['g_seccodebits'] != 6){
        $codelength = $_config['g_seccodebits'];
    }
    $code = $utils->generate_code($codelength);

    if(empty($code) || $code == null){
        $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'app_generatecode_error'));
        api_core::result_app($result);
    }

    $ismemberarchive = false;
    $user =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_mobile($phone);
    if(empty($user) && $_config['g_memberarchive']){
        $user =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_archive_by_mobile($phone);
        $ismemberarchive = true;
    }
    $uid = $user['uid']?$user['uid']:0;
    $sendsmsresult = $ismsapi->smssend($areacode,$phone,$code,$type,$uid);


    switch ($sendsmsresult){
        case 1:
            if(!empty($user) && (empty($user[$field]) || $user[$field] != $areacode)){
                if(!$ismemberarchive){
                    C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($user['uid'], $areacode, $field);
                }else{
                    DB::query('UPDATE '.DB::table("common_member_profile_archive").' SET '.$field.' = '.$areacode.'  WHERE uid='.$user['uid']);
                }
            }
            $result = array('success'=>true,'code'=>$code);
            break;
        case 0:
            $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'smserror'));
            break;
        case -998:
            $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'api_sendsms_error998'));
            break;
        case -1:
            $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'api_sendsms_error1'));
            break;
        case -2:
            $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'api_sendsms_error2'));
            break;
        case -3:
            $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'api_sendsms_error3'));
            break;
        case -4:
            $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'api_sendsms_error4'));
            break;
        case -5:
            $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'api_sendsms_error5'));
            break;
        case -6:
            $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'api_sendsms_error6'));
            break;
        case -7:
            $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'api_sendsms_error7'));
            break;
        default:
            $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'smserror').'(code.1003.'.$sendsmsresult.')');
            break;
    }
    api_core::result_app($result);

}else{
    $result = array('success'=>false,'msg'=>lang('plugin/jzsjiale_isms', 'smserror').'(code.1002)');
    api_core::result_app($result);
}

//send sms end

api_core::result_app($result);

?>