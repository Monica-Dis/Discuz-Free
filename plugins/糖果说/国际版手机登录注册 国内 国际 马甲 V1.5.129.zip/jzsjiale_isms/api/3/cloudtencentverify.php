<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
	exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';

$result = array('code'=>1,'data'=>null,'msg'=>'msg_sendsms_error');
if ($_config['g_captcha'] != 5) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_notopen');
    api_core::result($result);
}

$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';
if ($formhash != FORMHASH){
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_fail');
    api_core::result($result);
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/lib/tencentcloud/captchaVerify.php')){
    @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/lib/tencentcloud/captchaVerify.php';
}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_abnormal');
    api_core::result($result);
}

if (empty($_config['g_captchaappid'])) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_configurationerror');
    api_core::result($result);
}

if (empty($_config['g_captchaappsecret'])) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_configurationerror');
    api_core::result($result);
}

if (empty($_POST['ticket'])) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
    api_core::result($result);
}

if (empty($_POST['randstr'])) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
    api_core::result($result);
}



$areacode = addslashes($_POST['areacode']);
$phone = addslashes($_POST['phone']);
$type = addslashes($_POST['type']);

if (empty($type) || !in_array($type,array(0,1,2,3,4,5))){
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
    api_core::result($result);
}

if ($type == 5){
    $finduser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);
    if (!empty($finduser['mobile'])){
        $phone = $finduser['mobile'];
    }else{
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_smssendphone_null');
        api_core::result($result);
    }

    $areacode = !empty($finduser[$field])?$finduser[$field]:'86';
}

if (empty($areacode) || !preg_match("/^[0-9]+$/",$areacode)){
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_error');
    api_core::result($result);
}
if (empty($phone)){
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_smssendphone_null');
    api_core::result($result);
}


if(!$utils->isMobile($phone,$areacode)){
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_smssendphone_error');
    api_core::result($result);
}


// check phone exist by changjiale 20190729
if ($type == 1 || $type == 2) {
    $user =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_mobile($phone);
    if(empty($user) && $_config['g_memberarchive']){
        $user =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_archive_by_mobile($phone);
    }
    if($user){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_phonebind');
        api_core::result($result);
    }
}elseif ($type == 3){
    $user =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($areacode, $phone, $field);
    if(empty($user) && $_config['g_memberarchive']){
        $user =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_archive_by_areacode_and_mobile($areacode, $phone, $field);
    }
    if(!$user){
        if(!$_config['g_phoneloginreg']){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_nouser');
            api_core::result($result);
        }
    }
}elseif ($type == 4){
    $user =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($areacode, $phone, $field);
    if(empty($user) && $_config['g_memberarchive']){
        $user =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_archive_by_areacode_and_mobile($areacode, $phone, $field);
    }
    if(!$user){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_nouser');
        api_core::result($result);
    }
}elseif ($type == 5){
    $user =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($areacode, $phone, $field);
    $olduser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);
    $oldmobile = $olduser['mobile'];

    if (!$user || $phone != $oldmobile) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_oldphonebind');
        api_core::result($result);
    }

}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
    api_core::result($result);
}



$clentip = "0.0.0.0";
if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php')){
    @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php';
    $checkip = new Checkip();

    $clentip = $checkip->get_client_ip();
}else{
    if(isset($_G['clientip']) && !empty($_G['clientip']))
    {
        $clentip = $_G['clientip'];
    }
}

$captchaVerify = new CaptchaVerify();
$secretId = trim($_config['g_txsecretid']);
$secretKey = trim($_config['g_txsecretkey']);
$captchaAppId = trim($_config['g_captchaappid']);
$appSecretKey = trim($_config['g_captchaappsecret']);
$ticket = $_POST['ticket'];
$userIp = $clentip;
$randstr = $_POST['randstr'];
$captchaType = 9;
$captchaVerify->__construct($secretId,$secretKey,$captchaAppId,$appSecretKey,$ticket,$userIp,$randstr,$captchaType);
$content = $captchaVerify->getCaptchaResult();
$result = json_decode($content,true);
if($result){
    if($result['CaptchaCode'] == 1){
        //print_r($result);

        //send sms start
        if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/ismsapi.inc.php')){
            @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/ismsapi.inc.php';
            $ismsapi = new ISMSApi();

            $codelength = 6;
            if(!empty($_config['g_seccodebits']) && $_config['g_seccodebits'] != 6){
                $codelength = $_config['g_seccodebits'];
            }
            $code = $utils->generate_code($codelength);

            if(empty($code) || $code == null){
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_generatecode_error');
                api_core::result($result);
            }

            $uid = $_G['uid']?$_G['uid']:($user['uid']?$user['uid']:0);
            $sendsmsresult = $ismsapi->smssend($areacode,$phone,$code,$type,$uid);

            switch ($sendsmsresult){
                case 1:
                    $user =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_mobile($phone);
                    if(!empty($user) && (empty($user[$field]) || $user[$field] != $areacode)){
                        C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($user['uid'], $areacode, $field);
                    }
                    $result = array('code'=>0,'data'=>null,'msg'=>'msg_sendsms_success');
                    break;
                case 0:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_sendsms_error');
                    break;
                case -998:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_sendsms_error998');
                    break;
                case -1:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_sendsms_error1');
                    break;
                case -2:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_sendsms_error2');
                    break;
                case -3:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_sendsms_error3');
                    break;
                case -4:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_sendsms_error4');
                    break;
                case -5:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_sendsms_error5');
                    break;
                case -6:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_sendsms_error6');
                    break;
                case -7:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_sendsms_error7');
                    break;
                default:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_sendsms_error');
                    break;
            }
            api_core::result($result);

        }else{
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_ok_sendsms_error');
            api_core::result($result);
        }
        //send sms end

    }else{
        $result = array('code'=>1,'data'=>'error '.$result['CaptchaCode'].':'.$result['CaptchaMsg'],'msg'=>'msg_captcha_fail');
        api_core::result($result);
    }
}else{
    $data = null;
    if(strpos($content,'SSL certificate problem') !==false){
        $data = 'cURL error 60: SSL certificate problem: unable to get local issuer certificate (see http://curl.haxx.se/libcurl/c/libcurl-errors.html)';
    }
    $result = array('code'=>1,'data'=>$data,'msg'=>'msg_captcha_fail');
    api_core::result($result);
}

api_core::result($result);

?>