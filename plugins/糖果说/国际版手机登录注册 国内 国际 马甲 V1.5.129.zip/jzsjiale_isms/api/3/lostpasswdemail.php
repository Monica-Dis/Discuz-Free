<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$result = array('code'=>1,'data'=>null,'msg'=>'msg_login_illegal');
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';

$referer = addslashes($_POST['referer']);

$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';

if (submitcheck('lostpasswdsubmit') && $formhash == FORMHASH && $_POST['discode'] == '32563'){


    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && !$_config['g_openpczhaohui']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && !$_config['g_openmobilezhaohui']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }

    $email = addslashes($_POST['email']);
    $username = addslashes(urldecode($_POST['username']));
    if($_G['charset'] == 'gbk'){
        $username = diconv($username,'UTF-8','GBK');
    }


    loaducenter();
    $email = strtolower(trim($email));
    if($username) {
        list($tmp['uid'], , $tmp['email']) = uc_get_user($username);
        $tmp['email'] = strtolower(trim($tmp['email']));
        if($email != $tmp['email']) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_getpasswd_account_notmatch');
            api_core::result($result);
        }
        $member = getuserbyuid($tmp['uid'], 1);
    } else {
        $emailcount = C::t('common_member')->count_by_email($email, 1);
        if(!$emailcount) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_lostpasswd_email_not_exist');
            api_core::result($result);
        }
        if($emailcount > 1) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_lostpasswd_many_users_use_email');
            api_core::result($result);
        }
        $member = C::t('common_member')->fetch_by_email($email, 1);
        list($tmp['uid'], , $tmp['email']) = uc_get_user(addslashes($member['username']));
        $tmp['email'] = strtolower(trim($tmp['email']));
    }
    if(!$member) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_getpasswd_account_notmatch');
        api_core::result($result);
    } elseif($member['adminid'] == 1 || $member['adminid'] == 2) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_getpasswd_account_invalid');
        api_core::result($result);
    }

    $table_ext = $member['_inarchive'] ? '_archive' : '';
    if($member['email'] != $tmp['email']) {
        C::t('common_member'.$table_ext)->update($tmp['uid'], array('email' => $tmp['email']));
    }

    if (($_POST['device'] == 'pc' && in_array('emaillostpwlimit', (array) unserialize($_config['g_pcdetailed'])))
        || ($_POST['device'] == 'mobile' && in_array('emaillostpwlimit', (array) unserialize($_config['g_mdetailed']))) ){

        $memberauthstr = C::t('common_member_field_forum'.$table_ext)->fetch($member['uid']);
        list($dateline, $operation, $idstring) = explode("\t", $memberauthstr['authstr']);
        if($dateline && $operation == 1 && $dateline>TIMESTAMP-900){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_getpasswd_has_send');
            api_core::result($result);
        }
    }

    $idstring = random(6);
    C::t('common_member_field_forum'.$table_ext)->update($member['uid'], array('authstr' => "$_G[timestamp]\t1\t$idstring"));
    require_once libfile('function/mail');
    require_once libfile('function/member');
    $get_passwd_subject = lang('email', 'get_passwd_subject');
    $get_passwd_message = lang(
        'email',
        'get_passwd_message',
        array(
            'username' => $member['username'],
            'bbname' => $_G['setting']['bbname'],
            'siteurl' => $_G['siteurl'],
            'uid' => $member['uid'],
            'idstring' => $idstring,
            'clientip' => $_G['clientip'],
            'sign' => make_getpws_sign($member['uid'], $idstring),
        )
    );
    if(!sendmail("$_GET[username] <$tmp[email]>", $get_passwd_subject, $get_passwd_message)) {
        runlog('sendmail', "$tmp[email] sendmail failed.");
    }

    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($member['uid']);
    if(empty($userinfo) && $_config['g_memberarchive']){
        $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_archive_by_uid($member['uid']);
    }
    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $member['uid'],
        'username' => $member['username'],
        'areacode' => $userinfo[$field],
        'phone' => $userinfo['mobile'],
        'type' => 'forgotpassword',
        'operationuid' => $member['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'record' => 'email',
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);


    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_getpasswd_send_succeed');
    api_core::result($result);

    //lostpasswd end


}

api_core::result($result);

?>