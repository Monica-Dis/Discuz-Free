<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$result = array('code'=>1,'data'=>null,'msg'=>'msg_login_illegal');

$referer = addslashes($_POST['referer']);
$url_forward = !empty($referer)?$referer:(!empty(dreferer())?dreferer():$_G['siteurl']);
if(strpos($url_forward, $_G['setting']['regname']) !== false || strpos($url_forward, 'buyinvitecode') !== false) {
    $url_forward = 'forum.php';
}


$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';

if (submitcheck('lostpasswdsubmit') && $formhash == FORMHASH && $_POST['discode'] == '32563'){


    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && !$_config['g_openpczhaohui']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && !$_config['g_openmobilezhaohui']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }

    $areacode = addslashes($_POST['areacode']);
    $phone = addslashes($_POST['phone']);
    $seccode = addslashes($_POST['seccode']);


    if (empty($areacode) || !preg_match("/^[0-9]+$/",$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_error');
        api_core::result($result);
    }

    //check areacode status by changjiale 20190801
    $smsareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
    $smsareacode = (array)unserialize($smsareacode['jisms_allareacode']);

    $areacodestatus = $utils->searchGetOne($areacode,'areacode','status',$smsareacode);
    if(!$areacodestatus){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_notopen');
        api_core::result($result);
    }

    if (empty($phone)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_smssendphone_null');
        api_core::result($result);
    }


    if(!$utils->isMobile($phone,$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_phone_formaterror');
        api_core::result($result);
    }

    if (empty($seccode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_seccode_empty');
        api_core::result($result);
    }

    //check seccode by changjiale 20190726

    $codeinfo = C::t('#jzsjiale_isms#jzsjiale_isms_code')->fetchfirst_by_areacode_phone_seccode($areacode,$phone,$seccode);
    if ($codeinfo) {
        if ((TIMESTAMP - $codeinfo[dateline]) > $_config['g_youxiaoqi']) {
            C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_seccodeguoqi');
            api_core::result($result);
        }
    } else {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_checkseccode');
        api_core::result($result);
    }

    C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);


    //check mobile user by changjiale 20190731
    $field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';
    $mobileuser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($areacode, $phone, $field);

    if(empty($mobileuser) && $_config['g_memberarchive']){
        $mobileuser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_archive_by_areacode_and_mobile($areacode, $phone, $field);
    }

    if(empty($mobileuser) || empty($mobileuser['mobile'])){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_weibangding');
        api_core::result($result);
    }


    //lostpasswd start

    $member = getuserbyuid($mobileuser['uid'], 1);
    if (!$member || empty($member['uid'])) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_weibangding');
        api_core::result($result);
    }elseif ($member['adminid'] == 1 || $member['adminid'] == 2) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_getpasswd_account_invalid');
        api_core::result($result);
    }



    $table_ext = $member['_inarchive'] ? '_archive' : '';
    $idstring = random(6);
    C::t('common_member_field_forum' . $table_ext)->update($member['uid'], array('authstr' => "$_G[timestamp]\t1\t$idstring"));
    require_once libfile('function/member');
    $sign = make_getpws_sign($member['uid'], $idstring);

    $url_forward = "member.php?mod=getpasswd&uid=".$member['uid']."&id=".$idstring."&sign=".$sign;

    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $member['uid'],
        'username' => $member['username'],
        'areacode' => $areacode,
        'phone' => $phone,
        'type' => 'forgotpassword',
        'operationuid' => $member['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'record' => 'mobile',
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);


    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_verify_success');
    api_core::result($result);

    //lostpasswd end


}

api_core::result($result);

?>