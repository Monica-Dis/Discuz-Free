<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$result = array('code'=>1,'data'=>null,'msg'=>'msg_register_illegal');

$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';
if (submitcheck('regsubmit') && $formhash == FORMHASH && $_POST['discode'] == '32563'){

    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && !$_config['g_openpcregister']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && !$_config['g_openmobileregister']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }

    //20200621 check invitecode start
    if(($_POST['device'] == 'pc' && in_array('invitecode', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('invitecode', (array) unserialize($_config['g_mregister'])))){
        $invitecode = addslashes($_POST['invitecode']);
        if (empty($invitecode)){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_invitecode_empty');
            api_core::result($result);
        }
        $invitecode_result = array();
        if($invite = C::t('common_invite')->fetch_by_code($invitecode)) {
            if(empty($invite['fuid']) && (empty($invite['endtime']) || $_G['timestamp'] < $invite['endtime'])) {
                $invitecode_result['uid'] = $invite['uid'];
                $invitecode_result['id'] = $invite['id'];
                $invitecode_result['appid'] = $invite['appid'];
            }
        }
        if(empty($invitecode_result)) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_invitecode_error');
            api_core::result($result);
        }
    }
    //20200621 check invitecode end

    $areacode = addslashes($_POST['areacode']);
    $phone = addslashes($_POST['phone']);
    $seccode = addslashes($_POST['seccode']);

    if (empty($areacode) || !preg_match("/^[0-9]+$/",$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_error');
        api_core::result($result);
    }

    //check areacode status by changjiale 20190801
    $smsareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
    $smsareacode = (array)unserialize($smsareacode['jisms_allareacode']);

    $areacodestatus = $utils->searchGetOne($areacode,'areacode','status',$smsareacode);
    if(!$areacodestatus){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_notopen');
        api_core::result($result);
    }

    if (empty($phone)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_smssendphone_null');
        api_core::result($result);
    }


    if(!$utils->isMobile($phone,$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_phone_formaterror');
        api_core::result($result);
    }

    if (empty($seccode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_seccode_empty');
        api_core::result($result);
    }

    //check seccode by changjiale 20190726

    $codeinfo = C::t('#jzsjiale_isms#jzsjiale_isms_code')->fetchfirst_by_areacode_phone_seccode($areacode,$phone,$seccode);
    if ($codeinfo) {
        if ((TIMESTAMP - $codeinfo[dateline]) > $_config['g_youxiaoqi']) {
            C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_seccodeguoqi');
            api_core::result($result);
        }
    } else {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_checkseccode');
        api_core::result($result);
    }


    //check mobile user by changjiale 20190726
    $field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';
    $mobileuser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($areacode, $phone, $field);

    if(!empty($mobileuser)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_mobile_exist');
        api_core::result($result);
    }

    $username = "";

    if(($_POST['device'] == 'pc' && in_array('username', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('username', (array) unserialize($_config['g_mregister'])))){
        $username = addslashes(urldecode($_POST['username']));
        if($_G['charset'] == 'gbk'){
            $username = diconv($username,'UTF-8','GBK');
        }
        if(empty($username)){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_newusername_empty');
            api_core::result($result);
        }
        $userNamelen = dstrlen($username);
        if ($userNamelen<3) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_len_short_invalid_error');
            api_core::result($result);
        }elseif($userNamelen > 15){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_len_long_invalid_error');
            api_core::result($result);
        }

        //20210513 username verify start
        if($_config['g_usernameverify'] != "none"){
            $usernameverifyregular = "";
            if($_config['g_usernameverify'] == "uv1"){
                if($_G['charset'] == 'gbk'){
                    $usernameverifyregular = "/^[\x{81}-\x{A0}\x{AA}-\x{FE}A-Za-z][\x{81}-\x{A0}\x{AA}-\x{FE}A-Za-z0-9_]+$/";
                }else{
                    $usernameverifyregular = "/^[\x{4E00}-\x{9FA5}A-Za-z][\x{4E00}-\x{9FA5}A-Za-z0-9_]+$/u";
                }
                if(!preg_match($usernameverifyregular, $username)){
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_verifyregular');
                    api_core::result($result);
                }
            }elseif($_config['g_usernameverify'] == "uv2"){
                $usernameverifyregular = "/^[A-Za-z][A-Za-z0-9_]+$/";
                if(!preg_match($usernameverifyregular, $username)){
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_verifyregular');
                    api_core::result($result);
                }
            }elseif($_config['g_usernameverify'] == "uvdiy"){
                $usernameverifyregular = $_config['g_diyusernameverifyregular'];
                if(!preg_match($usernameverifyregular, $username)){
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_verifyregular');
                    api_core::result($result);
                }
            }
        }
        //20210513 username verify end

        loaducenter();
        $ucresult = uc_user_checkname($username);

        if ($ucresult == -1) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_sensitive');
            api_core::result($result);
        } elseif ($ucresult == -2) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_shield');
            api_core::result($result);
        } elseif ($ucresult == -3) {
            if (C::t('common_member')->fetch_by_username($username) || C::t('common_member_archive')->fetch_by_username($username)) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_reged');
                api_core::result($result);
            } else {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_exist');
                api_core::result($result);
            }
        }


        $censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';

        if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_shield');
            api_core::result($result);
        }

    }else{
        //create username by changjiale 20190726
        $g_registerprefix = !empty($_config['g_registerprefix'])?$_config['g_registerprefix']:"isms_";
        $username = $g_registerprefix.$utils->get_rand_str(8);

        $user = C::t('common_member')->fetch_by_username($username);
        if($user){
            $username = $g_registerprefix.$utils->get_rand_str(8);

            $user = C::t('common_member')->fetch_by_username($username);
            if($user){
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_abnormal');
                api_core::result($result);
            }

        }
    }

    $gender = 0;
    if(($_POST['device'] == 'pc' && in_array('gender', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('gender', (array) unserialize($_config['g_mregister'])))) {
        $gender = addslashes($_POST['gender']);

        if(empty($gender) || $gender == "secrecy"){
            $gender = 0;
        }elseif($gender == "male"){
            $gender = 1;
        }elseif($gender == "female"){
            $gender = 2;
        }else{
            $gender = 0;
        }
    }else{
        $gender = 0;
    }


    $email = "";

    if(($_POST['device'] == 'pc' && in_array('email', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('email', (array) unserialize($_config['g_mregister'])))) {
        $email = addslashes($_POST['email']);

        $email = strtolower(trim($email));
        if(strlen($email) > 32) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_illegal');
            api_core::result($result);
        }
        if($_G['setting']['regmaildomain']) {
            $maildomainexp = '/('.str_replace("\r\n", '|', preg_quote(trim($_G['setting']['maildomainlist']), '/')).')$/i';
            if($_G['setting']['regmaildomain'] == 1 && !preg_match($maildomainexp, $email)) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_domain_illegal');
                api_core::result($result);
            } elseif($_G['setting']['regmaildomain'] == 2 && preg_match($maildomainexp, $email)) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_domain_illegal');
                api_core::result($result);
            }
        }

        loaducenter();
        $ucresult = uc_user_checkemail($email);

        if($ucresult == -4) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_illegal');
            api_core::result($result);
        } elseif($ucresult == -5) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_illegal');
            api_core::result($result);
        } elseif($ucresult == -6) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_duplicate');
            api_core::result($result);
        }


    }else{
        $g_emailprefix = !empty($_config['g_emailprefix'])?$_config['g_emailprefix']:"isms.com";
        $email = time().substr($phone,-3)."@".$g_emailprefix;
    }


    $password = "";

    if(($_POST['device'] == 'pc' && in_array('password', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('password', (array) unserialize($_config['g_mregister'])))) {
        $password = addslashes($_POST['password']);

        if($_G['setting']['pwlength']) {
            if(strlen($password) < $_G['setting']['pwlength']) {
                $result = array('code'=>1,'data'=>array('pwlength' => $_G['setting']['pwlength']),'msg'=>'msg_err_profile_password_tooshort');
                api_core::result($result);
            }
        }

        if($_G['setting']['strongpw']) {
            $strongpw_str = array();
            if(in_array(1, $_G['setting']['strongpw']) && !preg_match("/\d+/", $password)) {
                $strongpw_str[] = lang('member/template', 'strongpw_1');
            }
            if(in_array(2, $_G['setting']['strongpw']) && !preg_match("/[a-z]+/", $password)) {
                $strongpw_str[] = lang('member/template', 'strongpw_2');
            }
            if(in_array(3, $_G['setting']['strongpw']) && !preg_match("/[A-Z]+/", $password)) {
                $strongpw_str[] = lang('member/template', 'strongpw_3');
            }
            if(in_array(4, $_G['setting']['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $password)) {
                $strongpw_str[] = lang('member/template', 'strongpw_4');
            }
            if($strongpw_str) {
                $result = array('code'=>1,'data'=>array('strongpw_str' => implode(',', $strongpw_str)),'msg'=>'msg_err_password_weak');
                api_core::result($result);
            }
        }

    }else{
        $password = "Jisms".substr(md5(random(10)),0,12)."!";
    }


    $profile = array (
        "mobile" => $phone,
    );
    require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/uc.inc.php';

    $isreturnuid = 0;
    $emailstatus0 = 0;
    if(($_POST['device'] == 'pc' && in_array('emailstatus0', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('emailstatus0', (array) unserialize($_config['g_mregister'])))) {
        $emailstatus0 = 1;
    }
    if(($_POST['device'] == 'pc' && in_array('email', (array) unserialize($_config['g_pcregister'])) && in_array('verifyemail', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('email', (array) unserialize($_config['g_mregister'])) && in_array('verifyemail', (array) unserialize($_config['g_mregister'])))) {
        $emailstatus0 = 1;
    }


    //20200611 add ip check start
    if(($_POST['device'] == 'pc' && in_array('ipregctrl', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('ipregctrl', (array) unserialize($_config['g_mregister'])))) {
        loadcache('ipctrl');
        if($_G['cache']['ipctrl']['ipregctrl']) {
            foreach(explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
                if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
                    $ctrlip = $ctrlip.'%';
                    $_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
                    break;
                } else {
                    $ctrlip = $_G['clientip'];
                }
            }
        } else {
            $ctrlip = $_G['clientip'];
        }
        if($_G['setting']['regctrl']) {
            $ret_tmp = DB::result_first('SELECT COUNT(*) FROM '.DB::table('common_regip').' WHERE '.DB::field('ip', $ctrlip, 'like').' AND count=-1 AND dateline>'.($_G['timestamp']-$_G['setting']['regctrl']*3600).'  LIMIT 1');
            if($ret_tmp) {
                $result = array('code'=>1,'data'=>array('regctrl' => $_G['setting']['regctrl']),'msg'=>'msg_err_register_ctrl');
                api_core::result($result);
            }
        }

        $setregip = null;
        if($_G['setting']['regfloodctrl']) {
            $regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp']-86400);
            if($regip) {
                if($regip['count'] >= $_G['setting']['regfloodctrl']) {
                    $result = array('code'=>1,'data'=>array('regfloodctrl' => $_G['setting']['regfloodctrl']),'msg'=>'msg_err_register_flood_ctrl');
                    api_core::result($result);
                } else {
                    $setregip = 1;
                }
            } else {
                $setregip = 2;
            }
        }
    }
    //20200611 add ip check end


    $regverify = false;
    if(($_POST['device'] == 'pc' && $_config['g_openpcregister'] == 2) || ($_POST['device'] == 'mobile' && $_config['g_openmobileregister'] == 2)) {
        $regverify = true;
    }
    $uid = UC::regist($username,$password,$email,$profile,$isreturnuid,$emailstatus0,$regverify);

    if (!is_numeric($uid)) {
        if($uid == "username_len_invalid"){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_len_invalid');
            api_core::result($result);
        }elseif($uid == "password_len_invalid"){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_password_len_invalid');
            api_core::result($result);
        }elseif($uid == "invalid_email"){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_illegal');
            api_core::result($result);
        }else{
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_register_fail');
            api_core::result($result);
        }

    }else{
        if ($uid<=0) {
            switch ($uid) {
                case -4:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_illegal');
                    api_core::result($result);
                    break;
                case -5:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_illegal');
                    api_core::result($result);
                    break;
                case -6:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_duplicate');
                    api_core::result($result);
                    break;
                default:
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_register_fail');
                    api_core::result($result);
                    break;
            };
        }
    }

    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'areacode' => $areacode,
        'phone' => $phone,
        'type' => 'register',
        'operationuid' => $_G['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

    C::t('common_member_profile')->update($_G['uid'], array('mobile' => $phone,$field => $areacode,'gender' => $gender));

    C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);

    //verify start
    if($_config['g_isopenautoverify'] && $_config['g_mobileverify']){
        $verifyuid = $_G['uid'];
        $memberautoverify = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$verifyuid);
        if(empty($memberautoverify)){
            C::t('common_member_verify')->insert(array('uid' => $verifyuid,'verify'.$_config['g_mobileverify'] => 1));
        }else{
            C::t('common_member_verify')->update($verifyuid, array('verify'.$_config['g_mobileverify'] => 1));
        }

    }
    //verify end

    //xiaoxi start
    $welcomemsg = $_G['setting']['welcomemsg'];
    $welcomemsgtitle = $_G['setting']['welcomemsgtitle'];
    $welcomemsgtxt = $_G['setting']['welcomemsgtxt'];

    if($welcomemsg && !empty($welcomemsgtxt)) {
        $welcomemsgtitle = replacesitevar($welcomemsgtitle);
        $welcomemsgtxt = replacesitevar($welcomemsgtxt);
        if($welcomemsg == 1) {
            $welcomemsgtxt = nl2br(str_replace(':', '&#58;', $welcomemsgtxt));
            notification_add($uid, 'system', $welcomemsgtxt, array('from_id' => 0, 'from_idtype' => 'welcomemsg'), 1);
        }
    }

    //xiaoxi end


    //20200611 add ip check start
    if(($_POST['device'] == 'pc' && in_array('ipregctrl', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('ipregctrl', (array) unserialize($_config['g_mregister'])))) {
        if($setregip !== null) {
            if($setregip == 1) {
                C::t('common_regip')->update_count_by_ip($_G['clientip']);
            } else {
                C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => 1, 'dateline' => $_G['timestamp']));
            }
        }
        if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
            C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
            if($_G['setting']['regctrl']) {
                C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
            }
        }
    }
    //20200611 add ip check end

    require_once libfile('cache/userstats', 'function');
    build_cache_userstats();


    //20200621 check invitecode start
    if(($_POST['device'] == 'pc' && in_array('invitecode', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('invitecode', (array) unserialize($_config['g_mregister'])))){
        $invite = $invitecode_result;
        if($invite['id']) {
            $result_invite = C::t('common_invite')->count_by_uid_fuid($invite['uid'], $_G['uid']);
            if(!$result_invite) {
                C::t('common_invite')->update($invite['id'], array('fuid'=>$_G['uid'], 'fusername'=>$_G['username'], 'regdateline' => $_G['timestamp'], 'status' => 2));
                updatestat('invite');
            } else {
                $invite = array();
            }
        }
        if($invite['uid']) {
            if($_G['setting']['inviteconfig']['inviteaddcredit']) {
                updatemembercount($_G['uid'], array($_G['setting']['inviteconfig']['inviterewardcredit'] => $_G['setting']['inviteconfig']['inviteaddcredit']));
            }
            if($_G['setting']['inviteconfig']['invitedaddcredit']) {
                updatemembercount($invite['uid'], array($_G['setting']['inviteconfig']['inviterewardcredit'] => $_G['setting']['inviteconfig']['invitedaddcredit']));
            }
            $member_invite = getuserbyuid($invite['uid']);
            $invite['username'] = $member_invite['username'];
            require_once libfile('function/friend');
            friend_make($invite['uid'], $invite['username'], false);

            space_merge($invite, 'field_home');
            if(!empty($invite['privacy']['feed']['invite'])) {
                require_once libfile('function/feed');
                $tite_data = array('username' => '<a href="home.php?mod=space&uid='.$_G['uid'].'">'.$_G['username'].'</a>');
                feed_add('friend', 'feed_invite', $tite_data, '', array(), '', array(), array(), '', '', '', 0, 0, '', $invite['uid'], $invite['username']);
            }
            if($invite['appid']) {
                updatestat('appinvite');
            }
        }
    }
    //20200621 check invitecode end


    $referer = addslashes($_POST['referer']);
    $url_forward = !empty($referer)?$referer:(!empty(dreferer())?dreferer():$_G['siteurl']);
    if(strpos($url_forward, $_G['setting']['regname']) !== false || strpos($url_forward, 'buyinvitecode') !== false) {
        $url_forward = 'forum.php';
    }

    $url_forward = $_G['groupid'] == 8 ? 'home.php?mod=space&do=home' : $url_forward;

    if (defined('IN_MOBILE')){
        if($_config['g_mregforwardtype'] == 'shouye'){
            @include_once './data/sysdata/cache_domain.php';

            $url_forward = $domain['defaultindex'];
        }elseif($_config['g_mregforwardtype'] == 'diy' && !empty($_config['g_mregdiyurl'])){
            $url_forward = $_config['g_mregdiyurl'];
        }
    }else{
        if($_config['g_pcregforwardtype'] == 'shouye'){
            @include_once './data/sysdata/cache_domain.php';

            $url_forward = $domain['defaultindex'];
        }elseif($_config['g_pcregforwardtype'] == 'diy' && !empty($_config['g_pcregdiyurl'])){
            $url_forward = $_config['g_pcregdiyurl'];
        }
    }

    //verifyemail start
    if(($_POST['device'] == 'pc' && in_array('email', (array) unserialize($_config['g_pcregister'])) && in_array('verifyemail', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('email', (array) unserialize($_config['g_mregister'])) && in_array('verifyemail', (array) unserialize($_config['g_mregister'])))) {
        if($_G['uid'] && $email) {
            $uid = $_G['uid'];
            $timestamp = $_G['timestamp'];
            $idstring = substr(md5($email), 0, 6);
            C::t('common_member_field_forum')->update($uid, array('authstr' => "$timestamp\t3\t$idstring"));

            $hash = authcode("$uid\t$email\t$timestamp", 'ENCODE', md5(substr(md5($_G['config']['security']['authkey']), 0, 16)));
            $verifyurl = $_G['setting']['securesiteurl'].'home.php?mod=misc&amp;ac=emailcheck&amp;hash='.urlencode($hash);
            $mailsubject = lang('email', 'email_verify_subject');
            $mailmessage = lang('email', 'email_verify_message', array(
                'username' => $_G['member']['username'],
                'bbname' => $_G['setting']['bbname'],
                'siteurl' => $_G['siteurl'],
                'url' => $verifyurl
            ));

            if(!function_exists('sendmail')) {
                require_once libfile('function/mail');
            }
            if(!sendmail($email, $mailsubject, $mailmessage)) {
                $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_register_success_sendemail_error');
                api_core::result($result);
            }else{
                $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_register_success_email_verify');
                api_core::result($result);
            }
        }
    }
    //verifyemail end
    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_register_success');
    api_core::result($result);
}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_register_illegal');
    api_core::result($result);
}

api_core::result($result);

?>