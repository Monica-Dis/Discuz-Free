<?php

/**
 *      Authorr:DisM!应用中心 dism.taobao.com
 *      最新插件：http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$result = array('code'=>1,'data'=>null,'msg'=>'msg_login_illegal');

$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';


$referer = addslashes($_POST['referer']);
$url_forward = !empty($referer)?$referer:(!empty(dreferer())?dreferer():$_G['siteurl']);
if(strpos($url_forward, $_G['setting']['regname']) !== false || strpos($url_forward, 'buyinvitecode') !== false) {
    $url_forward = 'forum.php';
}

if ($_G['uid']) {
    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_login_success');
    api_core::result($result);
}


$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';

if (submitcheck('loginsubmit') && $formhash == FORMHASH && $_POST['discode'] == '32563'){

    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && !$_config['g_openpclogin']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && !$_config['g_openmobilelogin']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if (!in_array($_POST['logintype'], array('seccode', 'mima', 'mimahaiwai'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_logintype_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && !in_array($_POST['logintype'], (array) unserialize($_config['g_pclogintype']))){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_logintype_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && !in_array($_POST['logintype'], (array) unserialize($_config['g_mlogintype']))){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_logintype_closed');
        api_core::result($result);
    }


    $type = addslashes($_POST['type']);
    $account = addslashes(urldecode($_POST['account']));
    $password = addslashes($_POST['password']);

    if (!in_array($type, array('auto', 'mobile', 'username', 'email', 'uid'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_logintype_closed');
        api_core::result($result);
    }

    //20200618 login captcha start
    if($_config['g_captcha'] != 0 && in_array('loginmima', (array) unserialize($_config['g_othercaptcha']))){
        if (empty($_config['g_captchaappid'])) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_configurationerror');
            api_core::result($result);
        }

        if (empty($_config['g_captchaappsecret'])) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_configurationerror');
            api_core::result($result);
        }

        if ($_config['g_captcha'] == 2) {
            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/httpcurl.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/httpcurl.php';
            }else{
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_abnormal');
                api_core::result($result);
            }

            if (empty($_POST['ticket'])) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
                api_core::result($result);
            }

            if (empty($_POST['randstr'])) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
                api_core::result($result);
            }

            $clentip = "0.0.0.0";
            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php';
                $checkip = new Checkip();

                $clentip = $checkip->get_client_ip();
            }else{
                if(isset($_G['clientip']) && !empty($_G['clientip']))
                {
                    $clentip = $_G['clientip'];
                }
            }


            $httpcurl = new HttpCurl();

            $closessl = $_config['g_closessl'] ? 1 : 0;

            $url = "https://ssl.captcha.qq.com/ticket/verify";
            $params = array(
                "aid" => trim($_config['g_captchaappid']),
                "AppSecretKey" => trim($_config['g_captchaappsecret']),
                "Ticket" => $_POST['ticket'],
                "Randstr" => $_POST['randstr'],
                "UserIP" => $clentip
            );
            $paramstring = http_build_query($params);
            $content = $httpcurl->hcurl($url,null, $paramstring,0,$closessl);
            $result = json_decode($content,true);
            if(!$result || $result['response'] != 1) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_fail');
                api_core::result($result);
            }

        }elseif ($_config['g_captcha'] == 3) {
            if (empty($_config['g_captchascene'])) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_configurationerror');
                api_core::result($result);
            }

            $token = addslashes($_POST['token']);
            if (empty($token)) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
                api_core::result($result);
            }
            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/lib/vaptcha/vaptcha.class.php')) {
                @include_once DISCUZ_ROOT . './source/plugin/jzsjiale_isms/lib/vaptcha/vaptcha.class.php';
            }else{
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_abnormal');
                api_core::result($result);
            }
            Vaptcha::_init(trim($_config['g_captchaappid']), trim($_config['g_captchaappsecret']));
            $token = $_POST['token'];
            $scene = trim($_config['g_captchascene']);
            $content =  Vaptcha::validate($token, $scene);

            $result = json_decode($content,true);
            if(!$result || $result['success'] != 1) {
                //echo $result['response'].":".$result['err_msg'];
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_fail');
                api_core::result($result);
            }
        }elseif ($_config['g_captcha'] == 4) {
            if (empty($_POST['geetest_challenge'])) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
                api_core::result($result);
            }

            if (empty($_POST['geetest_validate'])) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
                api_core::result($result);
            }

            if (empty($_POST['geetest_seccode'])) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
                api_core::result($result);
            }

            if (empty($_POST['t'])) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
                api_core::result($result);
            }
            if (empty($_POST['clienttype']) || !in_array($_POST['clienttype'],array('web','h5','native'))) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
                api_core::result($result);
            }

            $clentip = "0.0.0.0";
            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php';
                $checkip = new Checkip();

                $clentip = $checkip->get_client_ip();
            }else{
                if(isset($_G['clientip']) && !empty($_G['clientip']))
                {
                    $clentip = $_G['clientip'];
                }
            }

            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/lib/geetest/class.geetestlib.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/lib/geetest/class.geetestlib.php';
            }else{
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_abnormal');
                api_core::result($result);
            }

            $GtSdk = new GeetestLib($_config['g_captchaappid'], $_config['g_captchaappsecret']);
            session_start();

            $data = array(
                "user_id" => $_SESSION['user_id'],
                "client_type" => $_POST['clienttype'],
                "ip_address" => $clentip
            );
            if ($_SESSION['gtserver'] == 1) {   //服务器正常
                $result = $GtSdk->success_validate($_POST['geetest_challenge'], $_POST['geetest_validate'], $_POST['geetest_seccode'], $data);
                if (!$result) {
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_fail');
                    api_core::result($result);
                }
            } else {  //failback
                if (!$GtSdk->fail_validate($_POST['geetest_challenge'],$_POST['geetest_validate'],$_POST['geetest_seccode'])) {

                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_fail');
                    api_core::result($result);
                }
            }

        }elseif ($_config['g_captcha'] == 5) {
            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/lib/tencentcloud/captchaVerify.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/lib/tencentcloud/captchaVerify.php';
            }else{
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_abnormal');
                api_core::result($result);
            }
            if (empty($_POST['ticket'])) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
                api_core::result($result);
            }

            if (empty($_POST['randstr'])) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
                api_core::result($result);
            }
            $clentip = "0.0.0.0";
            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php')){
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php';
                $checkip = new Checkip();

                $clentip = $checkip->get_client_ip();
            }else{
                if(isset($_G['clientip']) && !empty($_G['clientip']))
                {
                    $clentip = $_G['clientip'];
                }
            }

            $captchaVerify = new CaptchaVerify();
            $secretId = trim($_config['g_txsecretid']);
            $secretKey = trim($_config['g_txsecretkey']);
            $captchaAppId = trim($_config['g_captchaappid']);
            $appSecretKey = trim($_config['g_captchaappsecret']);
            $ticket = $_POST['ticket'];
            $userIp = $clentip;
            $randstr = $_POST['randstr'];
            $captchaType = 9;
            $captchaVerify->__construct($secretId,$secretKey,$captchaAppId,$appSecretKey,$ticket,$userIp,$randstr,$captchaType);
            $content = $captchaVerify->getCaptchaResult();
            $result = json_decode($content,true);
            if($result){
                if($result['CaptchaCode'] != 1){
                    $result = array('code'=>1,'data'=>'error '.$result['CaptchaCode'].':'.$result['CaptchaMsg'],'msg'=>'msg_captcha_fail');
                    api_core::result($result);
                }
            }else{
                $data = null;
                if(strpos($content,'SSL certificate problem') !==false){
                    $data = 'cURL error 60: SSL certificate problem: unable to get local issuer certificate (see http://curl.haxx.se/libcurl/c/libcurl-errors.html)';
                }
                $result = array('code'=>1,'data'=>$data,'msg'=>'msg_captcha_fail');
                api_core::result($result);
            }
        }else{
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_fail');
            api_core::result($result);
        }
    }
    //20200618 login captcha end

    if (empty($account)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_account_empty');
        api_core::result($result);
    }
    if (empty($password)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_password_empty');
        api_core::result($result);
    }

    $g_memberarchive = 0;
    if($_config['g_memberarchive']){
        $g_memberarchive = 1;
    }

    if($type == 'auto'){

        $defaultareacode = "86";
        if(!empty($_config['g_defaultareacode'])){
            $defaultareacode = $_config['g_defaultareacode'];
        }
        // mobile
        if($utils->isMobile($account,$defaultareacode)){
            $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($defaultareacode, $account, $field);

            if(empty($userinfo) && $_config['g_memberarchive']){
                $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_archive_by_areacode_and_mobile($defaultareacode, $account, $field);
            }
        }
        // username
        if(empty($userinfo)){
            if($_G['charset'] == 'gbk'){
                $account = diconv($account,'UTF-8','GBK');
            }
            $userinfo = C::t('common_member')->fetch_by_username($account,$g_memberarchive);
        }

        // email
        if(empty($userinfo) && $utils->isEmail($account)){
            $userinfo = C::t('common_member')->fetch_by_email($account, $g_memberarchive);
        }

        if(empty($userinfo)){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_nouser');
            api_core::result($result);
        }

        $member = getuserbyuid($userinfo['uid'], $g_memberarchive);
        if (!$member || empty($member['uid'])) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_nouser');
            api_core::result($result);
        }
        $username = $member['username'];
    }elseif($type == 'mobile'){

        $defaultareacode = "86";
        if(!empty($_config['g_defaultareacode'])){
            $defaultareacode = $_config['g_defaultareacode'];
        }

        if(!$utils->isMobile($account,$defaultareacode)){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_phone_formaterror');
            api_core::result($result);
        }

        //check mobile user by changjiale 20190731
        $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($defaultareacode, $account, $field);

        if(empty($userinfo) && $g_memberarchive){
            $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_archive_by_areacode_and_mobile($defaultareacode, $account, $field);
        }

        if(empty($userinfo) || empty($userinfo['mobile'])){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_weibangding');
            api_core::result($result);
        }

        $member = getuserbyuid($userinfo['uid'], $g_memberarchive);
        if (!$member || empty($member['uid'])) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_weibangding');
            api_core::result($result);
        }
        $username = $member['username'];
    }elseif($type == 'username'){
        $username = $account;
    }elseif($type == 'email'){
        $member = C::t('common_member')->fetch_by_email($account, $g_memberarchive);
        if (!$member || empty($member['uid'])) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_nouser');
            api_core::result($result);
        }
        $username = $member['username'];
    }elseif($type == 'uid'){
        $member = getuserbyuid($account, $g_memberarchive);
        if (!$member || empty($member['uid'])) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_nouser');
            api_core::result($result);
        }
        $username = $member['username'];
    }else{
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_logintype_closed');
        api_core::result($result);
    }


    $_G['uid'] = $_G['member']['uid'] = 0;
    $_G['username'] = $_G['member']['username'] = $_G['member']['password'] = '';


    //login start


    if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/uc.inc.php')){
        require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/uc.inc.php';
    }else{
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_abnormal');
        api_core::result($result);
    }


    $questionid = daddslashes($_POST['questionid']);
    $answer = addslashes(urldecode($_POST['answer']));
    if($_G['charset'] == 'gbk'){
        $answer = diconv($answer,'UTF-8','GBK');
    }

    if(intval($questionid) > 0 && empty($answer)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_answer_empty');
        api_core::result($result);
    }
    if(intval($questionid) == 0){
        $questionid = "";
        $answer = "";
    }


    if($_G['charset'] == 'gbk' && $type == 'username'){
        $username = diconv($username,'UTF-8','GBK');
    }

    $uid = UC::logincheck($username,$password,$questionid,$answer);


    if (!is_numeric($uid)) {

        if($uid == "too_many_errors"){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_logintoomany');
            api_core::result($result);
        }else{
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_login_fail');
            api_core::result($result);
        }

    }

    if($uid == -1) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_nouser');
        api_core::result($result);
    } elseif($uid == -2) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_mimaerror');
        api_core::result($result);
    } elseif($uid == -3) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_answerset');
        api_core::result($result);
    } elseif($uid <= 0 && $uid != -1 && $uid != -2 && $uid != -3) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_login_fail');
        api_core::result($result);
    }

    if($type == 'auto'){
        if($uid > 0){
            $member = getuserbyuid($uid, 1);
            if (!$member || empty($member['uid'])) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_login_fail');
                api_core::result($result);
            }
        }
    }elseif($type == 'mobile'){
        if($member['uid'] != $uid){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_login_fail');
            api_core::result($result);
        }
        $user =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_mobile($account);
        $user_sms =  C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->get_by_mobile($account);
        if(!empty($user) && !empty($user_sms) && (empty($user[$field]) || $user[$field] != $user_sms['areacode'])){
            C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($user['uid'], $user_sms['areacode'], $field);
        }
    }elseif($type == 'username'){
        if($uid > 0){
            $member = getuserbyuid($uid, 1);
            if (!$member || empty($member['uid'])) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_login_fail');
                api_core::result($result);
            }
        }
    }elseif($type == 'email'){
        if($uid > 0){
            $member = getuserbyuid($uid, 1);
            if (!$member || empty($member['uid'])) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_login_fail');
                api_core::result($result);
            }
        }
    }elseif($type == 'uid'){
        if($account != $uid){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_login_fail');
            api_core::result($result);
        }
    }else{
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_logintype_closed');
        api_core::result($result);
    }

    if(!empty($_config['g_onlyseccodeusergroup']) && in_array($member['groupid'], (array) unserialize($_config['g_onlyseccodeusergroup']))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_onlyseccodelogin');
        api_core::result($result);
    }

    if ($member['_inarchive']) {
        C::t('common_member_archive')->move_to_master($member['uid']);
    }
    setloginstatus($member, $_POST['cookietime'] ? 2592000 : 0);
    checkfollowfeed();
    if ($_G['group']['forcelogin']) {
        if ($_G['group']['forcelogin'] == 1) {
            clearcookies();
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_location_login_force_qq');
            api_core::result($result);
        } elseif ($_G['group']['forcelogin'] == 2 && $_GET['loginfield'] != 'email') {
            clearcookies();
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_location_login_force_mail');
            api_core::result($result);
        }
    }
    if ($_G['member']['lastip'] && $_G['member']['lastvisit']) {
        dsetcookie('lip', $_G['member']['lastip'] . ',' . $_G['member']['lastvisit']);
    }
    C::t('common_member_status')->update($_G['uid'], array('lastip' => $_G['clientip'], 'port' => $_G['remoteport'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));
    $ucsynlogin = $_G['setting']['allowsynlogin'] ? uc_user_synlogin($_G['uid']) : '';
    if(!empty($ucsynlogin)){
        dsetcookie('jzsjiale_isms_ucsynlogin',base64_encode($ucsynlogin));
    }

    if($type == 'auto' || $type == 'username' || $type == 'uid' || $type == 'email'){
        $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);
    }

    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'areacode' => $userinfo[$field],
        'phone' => $userinfo['mobile'],
        'type' => 'login',
        'operationuid' => $_G['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'record' => serialize(array('logintype' => 'login_by_mima','type'  => $type)),
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

    if ($_G['member']['adminid'] != 1 && in_array($_G['groupid'], (array) unserialize($_config['g_twoverifyusergroup']))) {
        if(in_array('weakpassword', (array) unserialize($_config['g_twoverify']))){
            $pwold = false;
            if($_G['setting']['strongpw'] && !$_G['setting']['pwdsafety']) {
                if(in_array(1, $_G['setting']['strongpw']) && !preg_match("/\d+/", $password)) {
                    $pwold = true;
                }
                if(in_array(2, $_G['setting']['strongpw']) && !preg_match("/[a-z]+/", $password)) {
                    $pwold = true;
                }
                if(in_array(3, $_G['setting']['strongpw']) && !preg_match("/[A-Z]+/", $password)) {
                    $pwold = true;
                }
                if(in_array(4, $_G['setting']['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $password)) {
                    $pwold = true;
                }
            }

            if($_G['setting']['accountguard']['loginpwcheck'] && $pwold) {
                $freeze = $pwold;
                if($_G['setting']['accountguard']['loginpwcheck'] == 2 && $freeze) {
                    $freeze_userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->fetch_by_uid($_G['uid']);
                    $freeze = 1;
                    if($freeze_userinfo){
                        C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->update_freeze_by_uid($_G['uid'],$freeze);
                    }else{
                        $data = array(
                            'uid' => $_G['uid'],
                            'freeze' => $freeze,
                            'dateline' => TIMESTAMP
                        );

                        C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->insert($data, true);
                    }

                    setglobal('isms_freeze',$freeze);
                    $data = array(
                        'uid' => $_G['uid'],
                        'username' => $_G['username'],
                        'areacode' => $userinfo[$field],
                        'phone' => $userinfo['mobile'],
                        'type' => 'freeze',
                        'operationuid' => $_G['uid'],
                        'ip' => $client_loginfo['client_ip'],
                        'port' => $client_loginfo['client_port'],
                        'browser' => $client_loginfo['client_browser'],
                        'os' => $client_loginfo['client_os'],
                        'device' => $client_loginfo['client_device'],
                        'useragent' => $client_loginfo['client_useragent'],
                        'record' => $freeze,
                        'dateline' => TIMESTAMP
                    );

                    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

                    $url_forward = 'plugin.php?id=jzsjiale_isms:security&op=changepassword';
                    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_err_location_login_password_tooshort');
                    api_core::result($result);
                }
            }
        }
        if(in_array('remotelogin', (array) unserialize($_config['g_twoverify']))){
            require_once libfile('function/misc');
            $lastipConvert = process_ipnotice(convertip($_G['member']['lastip']));
            $nowipConvert = process_ipnotice(convertip($_G['clientip']));
            if($lastipConvert != $nowipConvert && stripos($lastipConvert, $nowipConvert) == false && stripos($nowipConvert, $lastipConvert) == false) {
                $freeze_userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->fetch_by_uid($_G['uid']);
                $freeze = 3;
                if($freeze_userinfo){
                    C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->update_freeze_by_uid($_G['uid'],$freeze);
                }else{
                    $data = array(
                        'uid' => $_G['uid'],
                        'freeze' => $freeze,
                        'dateline' => TIMESTAMP
                    );

                    C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->insert($data, true);
                }
                setglobal('isms_freeze',$freeze);
                $data = array(
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'areacode' => $userinfo[$field],
                    'phone' => $userinfo['mobile'],
                    'type' => 'freeze',
                    'operationuid' => $_G['uid'],
                    'ip' => $client_loginfo['client_ip'],
                    'port' => $client_loginfo['client_port'],
                    'browser' => $client_loginfo['client_browser'],
                    'os' => $client_loginfo['client_os'],
                    'device' => $client_loginfo['client_device'],
                    'useragent' => $client_loginfo['client_useragent'],
                    'record' => $freeze,
                    'dateline' => TIMESTAMP
                );

                C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

                $url_forward = 'plugin.php?id=jzsjiale_isms:security&op=needverify';
                $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_err_location_login_differentplaces');
                api_core::result($result);

            }
        }
        if(in_array('longtimenologin', (array) unserialize($_config['g_twoverify']))){
            if ($_G['setting']['accountguard']['loginoutofdate'] && $_G['member']['lastvisit'] && TIMESTAMP - $_G['member']['lastvisit'] > 30 * 86400) {
                $freeze_userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->fetch_by_uid($_G['uid']);
                $freeze = 4;
                if($freeze_userinfo){
                    C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->update_freeze_by_uid($_G['uid'],$freeze);
                }else{
                    $data = array(
                        'uid' => $_G['uid'],
                        'freeze' => $freeze,
                        'dateline' => TIMESTAMP
                    );

                    C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->insert($data, true);
                }

                setglobal('isms_freeze',$freeze);
                $data = array(
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'areacode' => $userinfo[$field],
                    'phone' => $userinfo['mobile'],
                    'type' => 'freeze',
                    'operationuid' => $_G['uid'],
                    'ip' => $client_loginfo['client_ip'],
                    'port' => $client_loginfo['client_port'],
                    'browser' => $client_loginfo['client_browser'],
                    'os' => $client_loginfo['client_os'],
                    'device' => $client_loginfo['client_device'],
                    'useragent' => $client_loginfo['client_useragent'],
                    'record' => $freeze,
                    'dateline' => TIMESTAMP
                );

                C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

                $url_forward = 'plugin.php?id=jzsjiale_isms:security&op=needverify';
                $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_err_location_login_outofdate');
                api_core::result($result);
            }
        }
        if(in_array('noverifyinisms', (array) unserialize($_config['g_twoverify']))){
            if(!empty($userinfo['mobile'])){
                $curr_user_sendsms_count = C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->count_by_phone($userinfo['mobile']);
                if($curr_user_sendsms_count == 0){
                    $freeze_userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->fetch_by_uid($_G['uid']);
                    $freeze = 5;
                    if($freeze_userinfo){
                        C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->update_freeze_by_uid($_G['uid'],$freeze);
                    }else{
                        $data = array(
                            'uid' => $_G['uid'],
                            'freeze' => $freeze,
                            'dateline' => TIMESTAMP
                        );

                        C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->insert($data, true);
                    }

                    setglobal('isms_freeze',$freeze);
                    $data = array(
                        'uid' => $_G['uid'],
                        'username' => $_G['username'],
                        'areacode' => $userinfo[$field],
                        'phone' => $userinfo['mobile'],
                        'type' => 'freeze',
                        'operationuid' => $_G['uid'],
                        'ip' => $client_loginfo['client_ip'],
                        'port' => $client_loginfo['client_port'],
                        'browser' => $client_loginfo['client_browser'],
                        'os' => $client_loginfo['client_os'],
                        'device' => $client_loginfo['client_device'],
                        'useragent' => $client_loginfo['client_useragent'],
                        'record' => $freeze,
                        'dateline' => TIMESTAMP
                    );

                    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

                    $url_forward = 'plugin.php?id=jzsjiale_isms:security&op=needverify';
                    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_err_location_login_needverify');
                    api_core::result($result);
                }
            }
        }
    }


    $url_forward = $_G['groupid'] == 8 ? 'home.php?mod=space&do=home' : $url_forward;

    if (defined('IN_MOBILE')){
        if($_config['g_mforwardtype'] == 'shouye'){
            @include_once './data/sysdata/cache_domain.php';

            $url_forward = $domain['defaultindex'];
        }elseif($_config['g_mforwardtype'] == 'diy' && !empty($_config['g_mdiyurl'])){
            $url_forward = $_config['g_mdiyurl'];
        }
    }else{
        if($_config['g_pcforwardtype'] == 'shouye'){
            @include_once './data/sysdata/cache_domain.php';

            $url_forward = $domain['defaultindex'];
        }elseif($_config['g_pcforwardtype'] == 'diy' && !empty($_config['g_pcdiyurl'])){
            $url_forward = $_config['g_pcdiyurl'];
        }
    }

    setglobal('isms_freeze',0);
    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_login_success');
    api_core::result($result);

    //login end


}elseif ($_G['uid']){
    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_login_success');
    api_core::result($result);
}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_login_illegal');
    api_core::result($result);
}

api_core::result($result);

?>