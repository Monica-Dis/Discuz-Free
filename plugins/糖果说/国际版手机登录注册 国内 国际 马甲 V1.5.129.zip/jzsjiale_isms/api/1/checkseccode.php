<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$result = array('code'=>1,'data'=>null,'msg'=>'msg_err_checkseccode');

$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';
if (submitcheck('checksubmit') && $formhash == FORMHASH && $_POST['discode'] == '32563'){

    if (empty($_POST['device'])) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }

    if(($_POST['device'] == 'pc' && in_array('invitecode', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('invitecode', (array) unserialize($_config['g_mregister'])))){
        $invitecode = addslashes($_POST['invitecode']);
        if (empty($invitecode)){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_invitecode_empty');
            api_core::result($result);
        }
        $invitecode_result = array();
        if($invite = C::t('common_invite')->fetch_by_code($invitecode)) {
            if(empty($invite['fuid']) && (empty($invite['endtime']) || $_G['timestamp'] < $invite['endtime'])) {
                $invitecode_result['uid'] = $invite['uid'];
                $invitecode_result['id'] = $invite['id'];
                $invitecode_result['appid'] = $invite['appid'];
            }
        }
        if(empty($invitecode_result)) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_invitecode_error');
            api_core::result($result);
        }
    }

    $areacode = addslashes($_POST['areacode']);
    $phone = addslashes($_POST['phone']);
    $seccode = addslashes($_POST['seccode']);

    if (empty($areacode) || !preg_match("/^[0-9]+$/",$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_error');
        api_core::result($result);
    }

    //check areacode status by changjiale 20190801
    $smsareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
    $smsareacode = (array)unserialize($smsareacode['jisms_allareacode']);

    $areacodestatus = $utils->searchGetOne($areacode,'areacode','status',$smsareacode);
    if(!$areacodestatus){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_notopen');
        api_core::result($result);
    }

    if (empty($phone)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_smssendphone_null');
        api_core::result($result);
    }


    if(!$utils->isMobile($phone,$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_phone_formaterror');
        api_core::result($result);
    }

    if (empty($seccode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_seccode_empty');
        api_core::result($result);
    }

    //check seccode by changjiale 20190726

    $codeinfo = C::t('#jzsjiale_isms#jzsjiale_isms_code')->fetchfirst_by_areacode_phone_seccode($areacode,$phone,$seccode);
    if ($codeinfo) {
        if ((TIMESTAMP - $codeinfo[dateline]) > $_config['g_youxiaoqi']) {
            C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_seccodeguoqi');
            api_core::result($result);
        }
    } else {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_checkseccode');
        api_core::result($result);
    }


    $result = array('code'=>0,'data'=>null,'msg'=>'msg_checkseccode_success');
    api_core::result($result);
}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_checkseccode');
    api_core::result($result);
}

api_core::result($result);

?>