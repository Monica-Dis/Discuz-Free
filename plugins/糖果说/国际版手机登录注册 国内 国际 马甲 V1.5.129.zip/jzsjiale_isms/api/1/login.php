<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$result = array('code'=>1,'data'=>null,'msg'=>'msg_login_illegal');

$referer = addslashes($_POST['referer']);
$url_forward = !empty($referer)?$referer:(!empty(dreferer())?dreferer():$_G['siteurl']);
if(strpos($url_forward, $_G['setting']['regname']) !== false || strpos($url_forward, 'buyinvitecode') !== false) {
    $url_forward = 'forum.php';
}

if ($_G['uid']) {
    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_login_success');
    api_core::result($result);
}


$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';

if (submitcheck('loginsubmit') && $formhash == FORMHASH && $_POST['discode'] == '32563'){


    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && !$_config['g_openpclogin']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && !$_config['g_openmobilelogin']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if (!in_array($_POST['logintype'], array('seccode', 'mima', 'mimahaiwai'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_logintype_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && !in_array($_POST['logintype'], (array) unserialize($_config['g_pclogintype']))){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_logintype_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && !in_array($_POST['logintype'], (array) unserialize($_config['g_mlogintype']))){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_logintype_closed');
        api_core::result($result);
    }

    require_once libfile('function/misc');
    loaducenter();
    require_once libfile('function/member');

    $areacode = addslashes($_POST['areacode']);
    $phone = addslashes($_POST['phone']);
    $seccode = addslashes($_POST['seccode']);


    if (empty($areacode) || !preg_match("/^[0-9]+$/",$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_error');
        api_core::result($result);
    }

    //check areacode status by changjiale 20190801
    $smsareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
    $smsareacode = (array)unserialize($smsareacode['jisms_allareacode']);

    $areacodestatus = $utils->searchGetOne($areacode,'areacode','status',$smsareacode);
    if(!$areacodestatus){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_notopen');
        api_core::result($result);
    }

    if (empty($phone)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_smssendphone_null');
        api_core::result($result);
    }


    if(!$utils->isMobile($phone,$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_phone_formaterror');
        api_core::result($result);
    }

    if (empty($seccode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_seccode_empty');
        api_core::result($result);
    }

    //check seccode by changjiale 20190726

    $codeinfo = C::t('#jzsjiale_isms#jzsjiale_isms_code')->fetchfirst_by_areacode_phone_seccode($areacode,$phone,$seccode);
    if ($codeinfo) {
        if ((TIMESTAMP - $codeinfo[dateline]) > $_config['g_youxiaoqi']) {
            C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_seccodeguoqi');
            api_core::result($result);
        }
    } else {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_checkseccode');
        api_core::result($result);
    }

    C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);

    $_G['uid'] = $_G['member']['uid'] = 0;
    $_G['username'] = $_G['member']['username'] = $_G['member']['password'] = '';


    //check mobile user by changjiale 20190731
    $field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';
    $mobileuser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($areacode, $phone, $field);

    if(empty($mobileuser) && $_config['g_memberarchive']){
        $mobileuser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_archive_by_areacode_and_mobile($areacode, $phone, $field);
    }

    //Synchronized Registration for Unbound Mobile Phone Logon
    if(empty($mobileuser) || empty($mobileuser['mobile'])){
        if(!$_config['g_phoneloginreg']){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_weibangding');
            api_core::result($result);
        }else{

            //register start
            //create username by changjiale 20190726
            $g_registerprefix = !empty($_config['g_registerprefix'])?$_config['g_registerprefix']:"isms_";
            $username = $g_registerprefix.$utils->get_rand_str(8);

            $user = C::t('common_member')->fetch_by_username($username);
            if($user){
                $username = $g_registerprefix.$utils->get_rand_str(8);

                $user = C::t('common_member')->fetch_by_username($username);
                if($user){
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_abnormal');
                    api_core::result($result);
                }

            }

            //create username and password by changjiale 20190726
            $g_emailprefix = !empty($_config['g_emailprefix'])?$_config['g_emailprefix']:"isms.com";
            $email = time().substr($phone,-3)."@".$g_emailprefix;
            $password = "Jisms".substr(md5(random(10)),0,12)."!";

            $profile = array (
                "mobile" => $phone,
            );
            if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/uc.inc.php')){
                require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/uc.inc.php';
            }else{
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_abnormal');
                api_core::result($result);
            }

            //20200611 add ip check start
            if(($_POST['device'] == 'pc' && in_array('ipregctrl', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('ipregctrl', (array) unserialize($_config['g_mregister'])))) {
                loadcache('ipctrl');
                if($_G['cache']['ipctrl']['ipregctrl']) {
                    foreach(explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
                        if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
                            $ctrlip = $ctrlip.'%';
                            $_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
                            break;
                        } else {
                            $ctrlip = $_G['clientip'];
                        }
                    }
                } else {
                    $ctrlip = $_G['clientip'];
                }
                if($_G['setting']['regctrl']) {
                    $ret_tmp = DB::result_first('SELECT COUNT(*) FROM '.DB::table('common_regip').' WHERE '.DB::field('ip', $ctrlip, 'like').' AND count=-1 AND dateline>'.($_G['timestamp']-$_G['setting']['regctrl']*3600).'  LIMIT 1');
                    if($ret_tmp) {
                        $result = array('code'=>1,'data'=>array('regctrl' => $_G['setting']['regctrl']),'msg'=>'msg_err_register_ctrl');
                        api_core::result($result);
                    }
                }

                $setregip = null;
                if($_G['setting']['regfloodctrl']) {
                    $regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp']-86400);
                    if($regip) {
                        if($regip['count'] >= $_G['setting']['regfloodctrl']) {
                            $result = array('code'=>1,'data'=>array('regfloodctrl' => $_G['setting']['regfloodctrl']),'msg'=>'msg_err_register_flood_ctrl');
                            api_core::result($result);
                        } else {
                            $setregip = 1;
                        }
                    } else {
                        $setregip = 2;
                    }
                }
            }
            //20200611 add ip check end

            $regverify = false;
            if($_config['g_phoneloginreg'] == 2){
                $regverify = true;
            }

            $isreturnuid = 0;
            $uid = UC::regist($username,$password,$email,$profile,$isreturnuid,0,$regverify);

            if (!is_numeric($uid)) {
                if($uid == "username_len_invalid"){
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_len_invalid');
                    api_core::result($result);
                }elseif($uid == "password_len_invalid"){
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_password_len_invalid');
                    api_core::result($result);
                }elseif($uid == "invalid_email"){
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_illegal');
                    api_core::result($result);
                }else{
                    $result = array('code'=>1,'data'=>null,'msg'=>'msg_register_fail');
                    api_core::result($result);
                }

            }else{
                if ($uid<=0) {
                    switch ($uid) {
                        case -4:
                            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_illegal');
                            api_core::result($result);
                            break;
                        case -5:
                            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_illegal');
                            api_core::result($result);
                            break;
                        case -6:
                            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_duplicate');
                            api_core::result($result);
                            break;
                        default:
                            $result = array('code'=>1,'data'=>null,'msg'=>'msg_register_fail');
                            api_core::result($result);
                            break;
                    };
                }
            }

            $client_loginfo = $utils->get_log_info();
            $data = array(
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'areacode' => $areacode,
                'phone' => $phone,
                'type' => 'register',
                'operationuid' => $_G['uid'],
                'ip' => $client_loginfo['client_ip'],
                'port' => $client_loginfo['client_port'],
                'browser' => $client_loginfo['client_browser'],
                'os' => $client_loginfo['client_os'],
                'device' => $client_loginfo['client_device'],
                'useragent' => $client_loginfo['client_useragent'],
                'record' => 'login_by_seccode',
                'dateline' => TIMESTAMP
            );

            C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

            C::t('common_member_profile')->update($_G['uid'], array('mobile' => $phone,$field => $areacode));

            C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);

            //verify start
            if($_config['g_isopenautoverify'] && $_config['g_mobileverify']){
                $verifyuid = $_G['uid'];
                $memberautoverify = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$verifyuid);
                if(empty($memberautoverify)){
                    C::t('common_member_verify')->insert(array('uid' => $verifyuid,'verify'.$_config['g_mobileverify'] => 1));
                }else{
                    C::t('common_member_verify')->update($verifyuid, array('verify'.$_config['g_mobileverify'] => 1));
                }

            }
            //verify end

            //xiaoxi start
            $welcomemsg = $_G['setting']['welcomemsg'];
            $welcomemsgtitle = $_G['setting']['welcomemsgtitle'];
            $welcomemsgtxt = $_G['setting']['welcomemsgtxt'];

            if($welcomemsg && !empty($welcomemsgtxt)) {
                $welcomemsgtitle = replacesitevar($welcomemsgtitle);
                $welcomemsgtxt = replacesitevar($welcomemsgtxt);
                if($welcomemsg == 1) {
                    $welcomemsgtxt = nl2br(str_replace(':', '&#58;', $welcomemsgtxt));
                    notification_add($uid, 'system', $welcomemsgtxt, array('from_id' => 0, 'from_idtype' => 'welcomemsg'), 1);
                }
            }

            //xiaoxi end


            //20200611 add ip check start
            if(($_POST['device'] == 'pc' && in_array('ipregctrl', (array) unserialize($_config['g_pcregister']))) || ($_POST['device'] == 'mobile' && in_array('ipregctrl', (array) unserialize($_config['g_mregister'])))) {
                if($setregip !== null) {
                    if($setregip == 1) {
                        C::t('common_regip')->update_count_by_ip($_G['clientip']);
                    } else {
                        C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => 1, 'dateline' => $_G['timestamp']));
                    }
                }
                if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
                    C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
                    if($_G['setting']['regctrl']) {
                        C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
                    }
                }
            }
            //20200611 add ip check end

            require_once libfile('cache/userstats', 'function');
            build_cache_userstats();

            $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_login_success');
            api_core::result($result);

            //resigter end
        }
    }


    //login start

    $member = getuserbyuid($mobileuser['uid'], 1);
    if (!$member || empty($member['uid'])) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_weibangding');
        api_core::result($result);
    }
    if ($member['_inarchive']) {
        C::t('common_member_archive')->move_to_master($member['uid']);
    }
    setloginstatus($member, $_POST['cookietime'] ? 2592000 : 0);
    checkfollowfeed();
    if ($_G['group']['forcelogin']) {
        if ($_G['group']['forcelogin'] == 1) {
            clearcookies();
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_location_login_force_qq');
            api_core::result($result);
        } elseif ($_G['group']['forcelogin'] == 2 && $_GET['loginfield'] != 'email') {
            clearcookies();
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_location_login_force_mail');
            api_core::result($result);
        }
    }
    if ($_G['member']['lastip'] && $_G['member']['lastvisit']) {
        dsetcookie('lip', $_G['member']['lastip'] . ',' . $_G['member']['lastvisit']);
    }
    C::t('common_member_status')->update($_G['uid'], array('lastip' => $_G['clientip'], 'port' => $_G['remoteport'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));
    $ucsynlogin = $_G['setting']['allowsynlogin'] ? uc_user_synlogin($_G['uid']) : '';
    if(!empty($ucsynlogin)){
        dsetcookie('jzsjiale_isms_ucsynlogin',base64_encode($ucsynlogin));
    }

    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'areacode' => $areacode,
        'phone' => $phone,
        'type' => 'login',
        'operationuid' => $_G['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'record' => 'login_by_seccode',
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

    if ($_G['member']['adminid'] != 1 && in_array($_G['groupid'], (array) unserialize($_config['g_twoverifyusergroup']))) {

        if(in_array('remotelogin', (array) unserialize($_config['g_twoverify']))){
            require_once libfile('function/misc');
            $lastipConvert = process_ipnotice(convertip($_G['member']['lastip']));
            $nowipConvert = process_ipnotice(convertip($_G['clientip']));
            if($lastipConvert != $nowipConvert && stripos($lastipConvert, $nowipConvert) == false && stripos($nowipConvert, $lastipConvert) == false) {
                $freeze_userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->fetch_by_uid($_G['uid']);
                $freeze = 3;
                if($freeze_userinfo){
                    C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->update_freeze_by_uid($_G['uid'],$freeze);
                }else{
                    $data = array(
                        'uid' => $_G['uid'],
                        'freeze' => $freeze,
                        'dateline' => TIMESTAMP
                    );

                    C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->insert($data, true);
                }
                setglobal('isms_freeze',$freeze);
                $data = array(
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'areacode' => $userinfo[$field],
                    'phone' => $userinfo['mobile'],
                    'type' => 'freeze',
                    'operationuid' => $_G['uid'],
                    'ip' => $client_loginfo['client_ip'],
                    'port' => $client_loginfo['client_port'],
                    'browser' => $client_loginfo['client_browser'],
                    'os' => $client_loginfo['client_os'],
                    'device' => $client_loginfo['client_device'],
                    'useragent' => $client_loginfo['client_useragent'],
                    'record' => $freeze,
                    'dateline' => TIMESTAMP
                );

                C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

                $url_forward = 'plugin.php?id=jzsjiale_isms:security&op=needverify';
                $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_err_location_login_differentplaces');
                api_core::result($result);

            }
        }
    }


    $url_forward = $_G['groupid'] == 8 ? 'home.php?mod=space&do=home' : $url_forward;

    if (defined('IN_MOBILE')){
        if($_config['g_mforwardtype'] == 'shouye'){
            @include_once './data/sysdata/cache_domain.php';

            $url_forward = $domain['defaultindex'];
        }elseif($_config['g_mforwardtype'] == 'diy' && !empty($_config['g_mdiyurl'])){
            $url_forward = $_config['g_mdiyurl'];
        }
    }else{
        if($_config['g_pcforwardtype'] == 'shouye'){
            @include_once './data/sysdata/cache_domain.php';

            $url_forward = $domain['defaultindex'];
        }elseif($_config['g_pcforwardtype'] == 'diy' && !empty($_config['g_pcdiyurl'])){
            $url_forward = $_config['g_pcdiyurl'];
        }
    }

    setglobal('isms_freeze',0);

    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_login_success');
    api_core::result($result);

    //login end


}elseif ($_G['uid']){
    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_login_success');
    api_core::result($result);
}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_login_illegal');
    api_core::result($result);
}

api_core::result($result);

?>