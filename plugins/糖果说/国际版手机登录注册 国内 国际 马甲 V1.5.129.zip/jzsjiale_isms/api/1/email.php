<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$result = array('code'=>1,'data'=>null,'msg'=>'msg_operation_illegal');
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';


$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';
require_once libfile('function/member');

if (!$_G['uid']){
    $url_forward = "member.php?mod=logging&action=login";
    $result = array('code'=>1,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_need_login');
    api_core::result($result);
}
if (submitcheck('emailsubmit') && $_POST['uid'] && $_POST['uid'] == $_G['uid'] && $_POST['hashid'] && $_POST['sign'] === $utils->make_verify_sign($_POST['uid'], $_POST['hashid']) && $formhash == FORMHASH && $_POST['discode'] == '32563'){

    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && !$_config['g_openpcemail']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && !$_config['g_openmobileemail']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }

    $discuz_action = 141;


    $member = getuserbyuid($_POST['uid'], 1);
    $table_ext = isset($member['_inarchive']) ? '_archive' : '';
    $member = array_merge(C::t('common_member_field_forum'.$table_ext)->fetch($_POST['uid']), $member);
    list($dateline, $operation, $idstring) = explode("\t", $member['authstr']);

    if($dateline < TIMESTAMP - 86400 * 3 || $operation != 1 || $idstring != $_POST['hashid']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_sign_illegal');
        api_core::result($result);
    }

    $email = addslashes(urldecode($_POST['email']));
    if($_G['charset'] == 'gbk'){
        $email = diconv($email,'UTF-8','GBK');
    }
    if(empty($email)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_email_empty');
        api_core::result($result);
    }

    loaducenter();
    $ucresult = uc_user_edit(addslashes($member['username']), "", "", $email, 1);
    if($ucresult == -4) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_illegal');
        api_core::result($result);
    } elseif($ucresult == -5) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_domain_illegal');
        api_core::result($result);
    } elseif($ucresult == -6) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_email_duplicate');
        api_core::result($result);
    }

    C::t('common_member')->update($member['uid'], array('email' => $email, 'emailstatus' => 1));
    if(isset($member['_inarchive'])) {
        C::t('common_member_archive')->move_to_master($member['uid']);
    }
    C::t('common_member_field_forum')->update($_POST['uid'], array('authstr' => ''));


    $url_forward = "plugin.php?id=jzsjiale_isms:security&op=email";

    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($member['uid']);
    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $member['uid'],
        'username' => $member['username'],
        'areacode' => $userinfo[$field],
        'phone' => $userinfo['mobile'],
        'type' => 'email',
        'operationuid' => $member['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'record' => 'email',
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);


    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_change_success');
    api_core::result($result);

    //getpasswd end

}

api_core::result($result);

?>