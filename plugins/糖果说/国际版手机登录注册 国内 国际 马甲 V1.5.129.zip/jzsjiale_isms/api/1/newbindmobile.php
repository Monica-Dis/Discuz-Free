<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$result = array('code'=>1,'data'=>null,'msg'=>'msg_bind_illegal');

$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';

if (!$_G['uid']){
    $url_forward = "member.php?mod=logging&action=login";
    $result = array('code'=>1,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_need_login');
    api_core::result($result);
}

if (submitcheck('bindsubmit') && $formhash == FORMHASH && $_POST['discode'] == '32563'){

    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && !$_config['g_openpcbangding']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && !$_config['g_openmobilebangding']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }

    if(($_POST['device'] == 'pc' && in_array('pcbindverifyoldphone',(array) unserialize($_config['g_bindoption'])))
       || ($_POST['device'] == 'mobile' && in_array('mobilebindverifyoldphone',(array) unserialize($_config['g_bindoption'])))){

        $issignok = false;

        //Cell phone number is space-time to indicate new bound cell phone
        $finduser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);
        if (empty($finduser['mobile'])){
            $issignok = true;
        }

        if(!$issignok && $_POST['uid'] && $_POST['uid'] == $_G['uid'] && $_POST['hashid'] && $_POST['sign'] === $utils->make_verify_sign($_POST['uid'], $_POST['hashid'])) {

            $member = getuserbyuid($_POST['uid'], 1);
            $table_ext = isset($member['_inarchive']) ? '_archive' : '';
            $member = array_merge(C::t('common_member_field_forum'.$table_ext)->fetch($_POST['uid']), $member);
            list($dateline, $operation, $idstring) = explode("\t", $member['authstr']);

            if($dateline < TIMESTAMP - 86400 * 3 || $operation != 1 || $idstring != $_POST['hashid']) {
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_sign_illegal');
                api_core::result($result);
            }

            $issignok = true;
        }

        if(!$issignok){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_sign_error');
            api_core::result($result);
        }
    }

    $areacode = addslashes($_POST['areacode']);
    $phone = addslashes($_POST['phone']);
    $seccode = addslashes($_POST['seccode']);
    $password = addslashes($_POST['password']);



    if (empty($areacode) || !preg_match("/^[0-9]+$/",$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_error');
        api_core::result($result);
    }

    //check areacode status by changjiale 20190801
    $smsareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
    $smsareacode = (array)unserialize($smsareacode['jisms_allareacode']);

    $areacodestatus = $utils->searchGetOne($areacode,'areacode','status',$smsareacode);
    if(!$areacodestatus){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_notopen');
        api_core::result($result);
    }

    if (empty($phone)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_smssendphone_null');
        api_core::result($result);
    }


    if(!$utils->isMobile($phone,$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_phone_formaterror');
        api_core::result($result);
    }

    if (empty($seccode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_seccode_empty');
        api_core::result($result);
    }


    if ($_POST['device'] == 'pc' && in_array('pcbindmima',(array) unserialize($_config['g_bindoption'])) && empty($password)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_password_empty');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && in_array('mobilebindmima',(array) unserialize($_config['g_bindoption'])) && empty($password)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_password_empty');
        api_core::result($result);
    }

    //check mima
    if($_POST['device'] == 'pc' && in_array('pcbindmima',(array) unserialize($_config['g_bindoption']))){
        loaducenter();
        list($result) = uc_user_login($_G['uid'], $password, 1, 0);
        if ($result < 0){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_password_error');
            api_core::result($result);
        }
    }
    if($_POST['device'] == 'mobile' && in_array('mobilebindmima',(array) unserialize($_config['g_bindoption']))){
        loaducenter();
        list($result) = uc_user_login($_G['uid'], $password, 1, 0);
        if ($result < 0){
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_password_error');
            api_core::result($result);
        }
    }


    //check seccode by changjiale 20190726

    $codeinfo = C::t('#jzsjiale_isms#jzsjiale_isms_code')->fetchfirst_by_areacode_phone_seccode($areacode,$phone,$seccode);
    if ($codeinfo) {
        if ((TIMESTAMP - $codeinfo[dateline]) > $_config['g_youxiaoqi']) {
            C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_seccodeguoqi');
            api_core::result($result);
        }
    } else {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_checkseccode');
        api_core::result($result);
    }


    //check mobile user by changjiale 20190726
    $field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';
    $mobileuser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($areacode, $phone, $field);

    if(!empty($mobileuser)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_mobile_exist');
        api_core::result($result);
    }

    getuserprofile('mobile',$field);
    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'areacode' => $areacode,
        'phone' => $phone,
        'type' => 'bind',
        'operationuid' => $_G['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'record' => serialize(array('beforerebind_areacode' => $_G['member'][$field]?$_G['member'][$field]:'null','beforerebind_phone'  => $_G['member']['mobile']?$_G['member']['mobile']:'null')),
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

    C::t('common_member_profile')->update($_G['uid'], array('mobile' => $phone,$field => $areacode));

    C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);

    //verify start
    if($_config['g_isopenautoverify'] && $_config['g_mobileverify']){
        $verifyuid = $_G['uid'];
        $memberautoverify = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$verifyuid);
        if(empty($memberautoverify)){
            C::t('common_member_verify')->insert(array('uid' => $verifyuid,'verify'.$_config['g_mobileverify'] => 1));
        }else{
            C::t('common_member_verify')->update($verifyuid, array('verify'.$_config['g_mobileverify'] => 1));
        }

    }
    //verify end

    if(in_array(getglobal('isms_freeze'), array(2,3,4))){
        C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->deletebyuid($_G['uid']);

        $data = array(
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'areacode' => $areacode,
            'phone' => $phone,
            'type' => 'unfreeze',
            'operationuid' => $_G['uid'],
            'ip' => $client_loginfo['client_ip'],
            'port' => $client_loginfo['client_port'],
            'browser' => $client_loginfo['client_browser'],
            'os' => $client_loginfo['client_os'],
            'device' => $client_loginfo['client_device'],
            'useragent' => $client_loginfo['client_useragent'],
            'dateline' => TIMESTAMP
        );
        C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);
    }


    $url_forward = "plugin.php?id=jzsjiale_isms:security";

    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_bind_success');
    api_core::result($result);
}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_bind_illegal');
    api_core::result($result);
}

api_core::result($result);

?>