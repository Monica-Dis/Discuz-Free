<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$result = array('code'=>1,'data'=>null,'msg'=>'msg_login_illegal');
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';

$referer = addslashes($_POST['referer']);
$url_forward = !empty($referer)?$referer:(!empty(dreferer())?dreferer():$_G['siteurl']);
if(strpos($url_forward, $_G['setting']['regname']) !== false || strpos($url_forward, 'buyinvitecode') !== false) {
    $url_forward = 'forum.php';
}


$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';
require_once libfile('function/member');
if (submitcheck('getpasswdsubmit') && $_POST['uid'] && $_POST['hashid'] && $_POST['sign'] === make_getpws_sign($_POST['uid'], $_POST['hashid']) && $formhash == FORMHASH && $_POST['discode'] == '32563'){


    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && !$_config['g_openpczhaohui']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && !$_config['g_openmobilezhaohui']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }

    $discuz_action = 141;


    $member = getuserbyuid($_POST['uid'], 1);
    $table_ext = isset($member['_inarchive']) ? '_archive' : '';
    $member = array_merge(C::t('common_member_field_forum'.$table_ext)->fetch($_POST['uid']), $member);
    list($dateline, $operation, $idstring) = explode("\t", $member['authstr']);

    if($dateline < TIMESTAMP - 86400 * 3 || $operation != 1 || $idstring != $_POST['hashid']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_getpasswd_illegal');
        api_core::result($result);
    }

    $password = addslashes($_POST['password']);
    $repassword = addslashes($_POST['repassword']);

    if($password != $repassword){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_password_different');
        api_core::result($result);
    }

    if($_POST['password'] != $password) {
        showmessage('profile_passwd_illegal');
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_profile_passwd_illegal');
        api_core::result($result);
    }



    if($_G['setting']['pwlength']) {
        if(strlen($password) < $_G['setting']['pwlength']) {
            $result = array('code'=>1,'data'=>array('pwlength' => $_G['setting']['pwlength']),'msg'=>'msg_err_profile_password_tooshort');
            api_core::result($result);
        }
    }

    if($_G['setting']['strongpw']) {
        $strongpw_str = array();
        if(in_array(1, $_G['setting']['strongpw']) && !preg_match("/\d+/", $password)) {
            $strongpw_str[] = lang('member/template', 'strongpw_1');
        }
        if(in_array(2, $_G['setting']['strongpw']) && !preg_match("/[a-z]+/", $password)) {
            $strongpw_str[] = lang('member/template', 'strongpw_2');
        }
        if(in_array(3, $_G['setting']['strongpw']) && !preg_match("/[A-Z]+/", $password)) {
            $strongpw_str[] = lang('member/template', 'strongpw_3');
        }
        if(in_array(4, $_G['setting']['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $password)) {
            $strongpw_str[] = lang('member/template', 'strongpw_4');
        }
        if($strongpw_str) {
            $result = array('code'=>1,'data'=>array('strongpw_str' => implode(',', $strongpw_str)),'msg'=>'msg_err_password_weak');
            api_core::result($result);
        }
    }

    loaducenter();
    uc_user_edit(addslashes($member['username']), $password, $password, addslashes($member['email']), 1, 0);
    $password_random = md5(random(10));

    if(isset($member['_inarchive'])) {
        C::t('common_member_archive')->move_to_master($member['uid']);
    }
    C::t('common_member')->update($_POST['uid'], array('password' => $password_random));
    C::t('common_member_field_forum')->update($_POST['uid'], array('authstr' => ''));


    $url_forward = "member.php?mod=logging&action=login";

    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($member['uid']);
    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $member['uid'],
        'username' => $member['username'],
        'areacode' => $userinfo[$field],
        'phone' => $userinfo['mobile'],
        'type' => 'changepassword',
        'operationuid' => $member['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_getpasswd_succeed');
    api_core::result($result);

    //getpasswd end


}

api_core::result($result);

?>