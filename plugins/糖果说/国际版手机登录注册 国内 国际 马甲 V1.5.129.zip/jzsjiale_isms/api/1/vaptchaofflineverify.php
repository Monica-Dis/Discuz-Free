<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
	exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';

if ($_config['g_captcha'] != 3) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_notopen_offline_error');
    api_core::result($result);
}

$formhash = addslashes($_GET['formhash'])? addslashes($_GET['formhash']):'';
if ($formhash != FORMHASH){
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_fail_offline_error');
    api_core::result($result);
}

if (empty($_config['g_captchaappid'])) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_configurationerror_offline_error');
    api_core::result($result);
}

if (empty($_config['g_captchaappsecret'])) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_configurationerror_offline_error');
    api_core::result($result);
}

error_reporting(E_ALL);
if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/lib/vaptcha/vaptcha.class.php')){
    @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/lib/vaptcha/vaptcha.class.php';
    Vaptcha::_init(trim($_config['g_captchaappid']),trim($_config['g_captchaappsecret']));
    $msg = '';
    if(isset($_REQUEST['offline_action'])){
        if(isset($_GET['v'])) {
            echo Vaptcha::offline($_GET['offline_action'], $_GET['callback'], $_GET['v'], $_GET['knock']);
        } else {
            echo Vaptcha::offline($_GET['offline_action'], $_GET['callback']);
        }
    }else{
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_offline_error');
        api_core::result($result);
    }
}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_offline_error');
    api_core::result($result);
}
//From: d'.'is'.'m.ta'.'obao.com
?>