<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
	exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';


$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';
if ($formhash != FORMHASH){
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_getlog');
    api_core::result($result);
}
if (!$_G['uid']){
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_need_login');
    api_core::result($result);
}
$logdata = array();
$logdata=  C::t('#jzsjiale_isms#jzsjiale_isms_log')->fetch_by_uid_and_type($_G['uid'],'login');

//log start
$finduser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);
$client_loginfo = $utils->get_log_info();
$data = array(
    'uid' => $_G['uid'],
    'username' => $_G['username'],
    'areacode' => $finduser[$field],
    'phone' => $finduser['mobile'],
    'type' => 'logonlog',
    'operationuid' => $_G['uid'],
    'ip' => $client_loginfo['client_ip'],
    'port' => $client_loginfo['client_port'],
    'browser' => $client_loginfo['client_browser'],
    'os' => $client_loginfo['client_os'],
    'device' => $client_loginfo['client_device'],
    'useragent' => $client_loginfo['client_useragent'],
    'dateline' => TIMESTAMP
);

C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);


if(!empty($logdata)){
    $result = array('code'=>0,'data'=>$logdata,'msg'=>'');
    api_core::result($result);
}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_getlognull');
    api_core::result($result);
}
//From: d'.'is'.'m.ta'.'obao.com
?>