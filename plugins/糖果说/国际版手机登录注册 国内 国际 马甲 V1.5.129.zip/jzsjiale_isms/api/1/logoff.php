<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201909121510
 *      updatetime: 201909121652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$result = array('code'=>1,'data'=>null,'msg'=>'msg_operation_illegal');
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';


$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';
require_once libfile('function/member');

if (!$_G['uid']){
    $url_forward = "member.php?mod=logging&action=login";
    $result = array('code'=>1,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_need_login');
    api_core::result($result);
}
if (submitcheck('logoffsubmit') && $_POST['uid'] && $_POST['uid'] == $_G['uid'] && $_POST['hashid'] && $_POST['sign'] === $utils->make_verify_sign($_POST['uid'], $_POST['hashid']) && $formhash == FORMHASH && $_POST['discode'] == '32563'){

    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && (!$_config['g_openpclogoff'] || $_config['g_openpclogoff'] != 1)) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && (!$_config['g_openmobilelogoff'] || $_config['g_openmobilelogoff'] != 1)) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }

    $discuz_action = 141;

    $member = getuserbyuid($_G['uid'], 1);
    if (!$member || empty($member['uid'])) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_nouser');
        api_core::result($result);
    }elseif ($member['adminid'] == 1 || $member['adminid'] == 2) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_logoff_account_invalid');
        api_core::result($result);
    }

    $groupid = $_G['groupid'];

    if (($_POST['device'] == 'pc' && !in_array($groupid, (array) unserialize($_config['g_pclogoffusergroup'])))
        || ($_POST['device'] == 'mobile' && !in_array($groupid, (array) unserialize($_config['g_mobilelogoffusergroup']))) ){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_logoff_group_noaccess');
        api_core::result($result);
    }


    $table_ext = isset($member['_inarchive']) ? '_archive' : '';
    $member = array_merge(C::t('common_member_field_forum'.$table_ext)->fetch($_POST['uid']), $member);
    list($dateline, $operation, $idstring) = explode("\t", $member['authstr']);

    if($dateline < TIMESTAMP - 86400 * 3 || $operation != 1 || $idstring != $_POST['hashid']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_sign_illegal');
        api_core::result($result);
    }


    $confirm = addslashes(urldecode($_POST['confirm']));
    if($_G['charset'] == 'gbk'){
        $confirm = diconv($confirm,'UTF-8','GBK');
    }

    $password = addslashes($_POST['password']);

    if(empty($confirm)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_logoff_confirm');
        api_core::result($result);
    }
    if($confirm !== lang('plugin/jzsjiale_isms', 'verify_confirm')){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_logoff_confirm_text');
        api_core::result($result);
    }
    if (empty($password)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_password_empty');
        api_core::result($result);
    }
    //check password
    loaducenter();
    list($result) = uc_user_login($_G['uid'], $password, 1, 0);
    if ($result < 0){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_password_error');
        api_core::result($result);
    }


    $url_forward = $_G['siteurl'];

    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($member['uid']);
    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'areacode' => $userinfo[$field],
        'phone' => $userinfo['mobile'],
        'type' => 'logoff',
        'operationuid' => $_G['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'record' => 'ok',
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

    $uids = array();
    $uids[] = $_G['uid'];

    require_once libfile('function/delete');
    $numdeleted = deletemember($uids, 0);
    loaducenter();
    uc_user_delete($uids);

    if (C::memory()->enable) {
        C::memory()->clear();
    }

    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_logoff_success');
    api_core::result($result);

    //logoff end


}

api_core::result($result);

?>