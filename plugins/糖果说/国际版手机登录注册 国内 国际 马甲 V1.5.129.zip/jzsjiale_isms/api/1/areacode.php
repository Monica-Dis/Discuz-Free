<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
	exit('JZSJIALE_ISMS API Access Denied');
}

$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';
if ($formhash != FORMHASH){
    $data[0] = array("id"=>"1","country"=>"China","countrycn"=>lang('plugin/jzsjiale_isms', 'china'),"code"=>"CN","areacode"=>"86","img"=>"cn","sort"=>"1","status"=>"1","dateline"=>"1532163246");
    $result = array('code'=>1,'data'=>$data,'msg'=>'msg_err_getareacode');
    api_core::result($result);
}

// all areacode start
$allareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
$allareacode = (array)unserialize($allareacode['jisms_allareacode']);
if(!$allareacode || empty($allareacode) || $allareacode[0] === false){
    $allareacode = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->getallbystatus(1);

    $allareacodesettings = array('jisms_allareacode' => serialize($allareacode));
    C::t('common_setting')->update_batch($allareacodesettings);

    if($allareacode){
        updatecache('setting');
    }
}
// all areacode end

// common areacode start
$commonareacode = C::t('common_setting')->fetch_all(array('jisms_commonareacode'));
$commonareacode = (array)unserialize($commonareacode['jisms_commonareacode']);
if(!$commonareacode || empty($commonareacode) || $commonareacode[0] === false){
    $commonareacode = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->getallbysort(1);
    $commonareacodesettings = array('jisms_commonareacode' => serialize($commonareacode));
    C::t('common_setting')->update_batch($commonareacodesettings);

    if($commonareacode){
        updatecache('setting');
    }
}
// common areacode end


$returnareacode = array(
    'commonareacode' => array(),
    'allareacode' => array()
);

if(!empty($allareacode)){
    $returnareacode['allareacode'] = $allareacode;
    if(!empty($commonareacode)){
        $returnareacode['commonareacode'] = $commonareacode;
    }
}else{
    $returnareacode['allareacode'][0] = array("id"=>"1","country"=>"China","countrycn"=>lang('plugin/jzsjiale_isms', 'china'),"code"=>"CN","areacode"=>"86","img"=>"cn","sort"=>"1","status"=>"1","dateline"=>"1532163246");
}
$result = array('code'=>0,'data'=>$returnareacode,'msg'=>'');
api_core::result($result);

?>