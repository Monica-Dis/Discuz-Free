<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
	exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];

$result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_fail');
if ($_config['g_captcha'] != 4) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_notopen');
    api_core::result($result);
}

$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';
if ($formhash != FORMHASH){
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_fail');
    api_core::result($result);
}


if (empty($_config['g_captchaappid'])) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_configurationerror');
    api_core::result($result);
}

if (empty($_config['g_captchaappsecret'])) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_configurationerror');
    api_core::result($result);
}

if (empty($_POST['t'])) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
    api_core::result($result);
}
if (empty($_POST['clienttype']) || !in_array($_POST['clienttype'],array('web','h5','native'))) {
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_captcha_parametererror');
    api_core::result($result);
}


$clentip = "0.0.0.0";
if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php')){
    @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkip.class.php';
    $checkip = new Checkip();

    $clentip = $checkip->get_client_ip();
}else{
    if(isset($_G['clientip']) && !empty($_G['clientip']))
    {
        $clentip = $_G['clientip'];
    }
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/lib/geetest/class.geetestlib.php')){
    @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/lib/geetest/class.geetestlib.php';
}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_abnormal');
    api_core::result($result);
}

$GtSdk = new GeetestLib($_config['g_captchaappid'], $_config['g_captchaappsecret']);
session_start();

$data = array(
    "user_id" => $_G['uid']?$_G['uid']:0,
    "client_type" => $_POST['clienttype'],
    "ip_address" => $clentip
);

$status = $GtSdk->pre_process($data, 1);
$_SESSION['gtserver'] = $status;
$_SESSION['user_id'] = $data['user_id'];
$getdata = $GtSdk->get_response_str();
$getdata = json_decode($getdata,true);

if(!empty($getdata) && $getdata['success'] == 1 && !empty($getdata['gt']) && !empty($getdata['challenge'])&& !empty($getdata['new_captcha'])){
    $result = array('code'=>0,'data'=>$getdata,'msg'=>'msg_captcha_success');
    api_core::result($result);
}

api_core::result($result);

?>