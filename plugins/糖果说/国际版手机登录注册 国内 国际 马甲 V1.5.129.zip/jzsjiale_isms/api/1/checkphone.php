<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';

$result = array('code'=>1,'data'=>null,'msg'=>'msg_verify_fail');

$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';

if (!$_G['uid']){
    $url_forward = "member.php?mod=logging&action=login";
    $result = array('code'=>1,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_need_login');
    api_core::result($result);
}
if (submitcheck('checkphonesubmit') && $formhash == FORMHASH && $_POST['discode'] == '32563'){

    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }

    $areacode = addslashes($_POST['areacode']);
    $phone = addslashes($_POST['phone']);

    if (empty($areacode) || !preg_match("/^[0-9]+$/",$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_error');
        api_core::result($result);
    }
    if (empty($phone)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_smssendphone_null');
        api_core::result($result);
    }

    if(!$utils->isMobile($phone,$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_phone_formaterror');
        api_core::result($result);
    }


    //check areacode status by changjiale 20190801
    $smsareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
    $smsareacode = (array)unserialize($smsareacode['jisms_allareacode']);

    $areacodestatus = $utils->searchGetOne($areacode,'areacode','status',$smsareacode);
    if(!$areacodestatus){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_notopen');
        api_core::result($result);
    }



    $finduser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);
    if (empty($finduser['mobile'])){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_find_phone_null');
        api_core::result($result);
    }

    if(preg_match("/^1[123456789]{1}\d{9}$/",$finduser['mobile'])){
        if($finduser['mobile'] != $phone || $areacode != '86'){

            $client_loginfo = $utils->get_log_info();
            $data = array(
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'areacode' => $finduser[$field],
                'phone' => $finduser['mobile'],
                'type' => 'checkphone',
                'operationuid' => $_G['uid'],
                'ip' => $client_loginfo['client_ip'],
                'port' => $client_loginfo['client_port'],
                'browser' => $client_loginfo['client_browser'],
                'os' => $client_loginfo['client_os'],
                'device' => $client_loginfo['client_device'],
                'useragent' => $client_loginfo['client_useragent'],
                'record' => serialize(array('status' => 'error','areacode' => $areacode,'phone' => $phone)),
                'dateline' => TIMESTAMP
            );

            C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);


            $result = array('code'=>1,'data'=>null,'msg'=>'msg_check_phone_error');
            api_core::result($result);
        }
        if(empty($finduser[$field]) || $finduser[$field] != '86'){
            C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($_G['uid'], '86', $field);
        }
    }else{
        if($finduser['mobile'] != $areacode.$phone && !($finduser['mobile'] == $phone && $finduser[$field] == $areacode)){

            $client_loginfo = $utils->get_log_info();
            $data = array(
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'areacode' => $finduser[$field],
                'phone' => $finduser['mobile'],
                'type' => 'checkphone',
                'operationuid' => $_G['uid'],
                'ip' => $client_loginfo['client_ip'],
                'port' => $client_loginfo['client_port'],
                'browser' => $client_loginfo['client_browser'],
                'os' => $client_loginfo['client_os'],
                'device' => $client_loginfo['client_device'],
                'useragent' => $client_loginfo['client_useragent'],
                'record' => serialize(array('status' => 'error','areacode' => $areacode,'phone' => $phone)),
                'dateline' => TIMESTAMP
            );

            C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);


            $result = array('code'=>1,'data'=>null,'msg'=>'msg_check_phone_error');
            api_core::result($result);
        }
        if(empty($finduser[$field]) || $finduser[$field] != $areacode){
            C::t('#jzsjiale_isms#jzsjiale_isms_member')->updateareacode($_G['uid'], $areacode, $field);

            $client_loginfo = $utils->get_log_info();
            $data = array(
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'areacode' => $areacode,
                'phone' => $finduser['mobile'],
                'type' => 'checkphone',
                'operationuid' => $_G['uid'],
                'ip' => $client_loginfo['client_ip'],
                'port' => $client_loginfo['client_port'],
                'browser' => $client_loginfo['client_browser'],
                'os' => $client_loginfo['client_os'],
                'device' => $client_loginfo['client_device'],
                'useragent' => $client_loginfo['client_useragent'],
                'record' => serialize(array('status' => 'updateareacode','areacode' => $areacode,'areacode_old' => $finduser[$field])),
                'dateline' => TIMESTAMP
            );

            C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);
        }
        if($finduser['mobile'] == $phone && $finduser[$field] == $areacode && $finduser['mobile'] != $areacode.$phone){
            $phone_update = $areacode.$finduser['mobile'];
            C::t('#jzsjiale_isms#jzsjiale_isms_member')->updatemobile($_G['uid'], $phone_update);

            $client_loginfo = $utils->get_log_info();
            $data = array(
                'uid' => $_G['uid'],
                'username' => $_G['username'],
                'areacode' => $areacode,
                'phone' => $phone_update,
                'type' => 'checkphone',
                'operationuid' => $_G['uid'],
                'ip' => $client_loginfo['client_ip'],
                'port' => $client_loginfo['client_port'],
                'browser' => $client_loginfo['client_browser'],
                'os' => $client_loginfo['client_os'],
                'device' => $client_loginfo['client_device'],
                'useragent' => $client_loginfo['client_useragent'],
                'record' => serialize(array('status' => 'updatephone','phone' => $phone_update,'phone_old' => $finduser['mobile'])),
                'dateline' => TIMESTAMP
            );

            C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);
        }
    }

    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'areacode' => $areacode,
        'phone' => ($areacode == '86')?$phone:$areacode.$phone,
        'type' => 'checkphone',
        'operationuid' => $_G['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'record' => serialize(array('status' => 'success','areacode' => $areacode,'phone' => $phone)),
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);


    $referer = addslashes($_POST['referer']);
    $url_forward = !empty($referer)?$referer:'plugin.php?id=jzsjiale_isms:security';

    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_verify_success');
    api_core::result($result);
}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_verify_fail');
    api_core::result($result);
}

api_core::result($result);

?>