<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201909121510
 *      updatetime: 201909121652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$result = array('code'=>1,'data'=>null,'msg'=>'msg_operation_illegal');
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';


$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';
require_once libfile('function/member');

if (!$_G['uid']){
    $url_forward = "member.php?mod=logging&action=login";
    $result = array('code'=>1,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_need_login');
    api_core::result($result);
}
if (submitcheck('changeusernamesubmit') && $_POST['uid'] && $_POST['uid'] == $_G['uid'] && $_POST['hashid'] && $_POST['sign'] === $utils->make_verify_sign($_POST['uid'], $_POST['hashid']) && $formhash == FORMHASH && $_POST['discode'] == '32563'){

    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && !$_config['g_openpcchangeusername']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && !$_config['g_openmobilechangeusername']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }

    $discuz_action = 141;

    $member = getuserbyuid($_G['uid'], 1);
    if (!$member || empty($member['uid'])) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_nouser');
        api_core::result($result);
    }elseif ($member['adminid'] == 1 || $member['adminid'] == 2) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_changeusername_account_invalid');
        api_core::result($result);
    }

    $groupid = $_G['groupid'];

    if (($_POST['device'] == 'pc' && !in_array($groupid, (array) unserialize($_config['g_pcchangeusernameusergroup'])))
        || ($_POST['device'] == 'mobile' && !in_array($groupid, (array) unserialize($_config['g_mobilechangeusernameusergroup']))) ){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_rename_group_noaccess');
        api_core::result($result);
    }


    $table_ext = isset($member['_inarchive']) ? '_archive' : '';
    $member = array_merge(C::t('common_member_field_forum'.$table_ext)->fetch($_POST['uid']), $member);
    list($dateline, $operation, $idstring) = explode("\t", $member['authstr']);

    if($dateline < TIMESTAMP - 86400 * 3 || $operation != 1 || $idstring != $_POST['hashid']) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_sign_illegal');
        api_core::result($result);
    }

    if ($_config['g_changeusernameinterval']){
        $lastlogdata = array();
        $lastlogdata=  C::t('#jzsjiale_isms#jzsjiale_isms_log')->fetch_one_by_uid_and_type($_G['uid'],'changeusername');

        if ($lastlogdata['dateline'] && TIMESTAMP < $lastlogdata['dateline'] + $_config['g_changeusernameinterval'] * 86400) {
            $message1 = $_config['g_changeusernameinterval'];
            $message2 = dgmdate($lastlogdata['dateline'], 'Y-m-d H:i:s');

            $result = array('code'=>1,'data'=>array('message1'=>$message1,'message2'=>$message2),'msg'=>'msg_err_rename_jiange_error');
            api_core::result($result);
        }
    }


    $newusername = addslashes(urldecode($_POST['newusername']));
    if($_G['charset'] == 'gbk'){
        $newusername = diconv($newusername,'UTF-8','GBK');
    }


    if(empty($newusername)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_newusername_empty');
        api_core::result($result);
    }
    $userNamelen = dstrlen($newusername);
    if ($userNamelen<3) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_len_short_invalid_error');
        api_core::result($result);
    }elseif($userNamelen > 15){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_len_long_invalid_error');
        api_core::result($result);
    }


    //20210513 username verify start
    if($_config['g_usernameverify'] != "none"){
        $usernameverifyregular = "";
        if($_config['g_usernameverify'] == "uv1"){
            if($_G['charset'] == 'gbk'){
                $usernameverifyregular = "/^[\x{81}-\x{A0}\x{AA}-\x{FE}A-Za-z][\x{81}-\x{A0}\x{AA}-\x{FE}A-Za-z0-9_]+$/";
            }else{
                $usernameverifyregular = "/^[\x{4E00}-\x{9FA5}A-Za-z][\x{4E00}-\x{9FA5}A-Za-z0-9_]+$/u";
            }
            if(!preg_match($usernameverifyregular, $newusername)){
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_verifyregular');
                api_core::result($result);
            }
        }elseif($_config['g_usernameverify'] == "uv2"){
            $usernameverifyregular = "/^[A-Za-z][A-Za-z0-9_]+$/";
            if(!preg_match($usernameverifyregular, $newusername)){
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_verifyregular');
                api_core::result($result);
            }
        }elseif($_config['g_usernameverify'] == "uvdiy"){
            $usernameverifyregular = $_config['g_diyusernameverifyregular'];
            if(!preg_match($usernameverifyregular, $newusername)){
                $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_username_verifyregular');
                api_core::result($result);
            }
        }
    }
    //20210513 username verify end


    loaducenter();
    $ucresult = uc_user_checkname($newusername);

    if ($ucresult == -1) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_newusername_sensitive');
        api_core::result($result);
    } elseif ($ucresult == -2) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_newusername_shield');
        api_core::result($result);
    } elseif ($ucresult == -3) {
        if (C::t('common_member')->fetch_by_username($newusername) || C::t('common_member_archive')->fetch_by_username($newusername)) {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_newusername_reged');
            api_core::result($result);
        } else {
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_newusername_exist');
            api_core::result($result);
        }
    }


    $censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';

    if($_G['setting']['censoruser'] && @preg_match($censorexp, $newusername)) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_newusername_shield');
        api_core::result($result);
    }

    $utils->changename_for_dz($_G['username'], $newusername);
    $utils->changename_for_uc($_G['username'], $newusername);


    $url_forward = "plugin.php?id=jzsjiale_isms:security&op=changeusername";

    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($member['uid']);
    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $_G['uid'],
        'username' => $newusername,
        'areacode' => $userinfo[$field],
        'phone' => $userinfo['mobile'],
        'type' => 'changeusername',
        'operationuid' => $_G['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'record' => serialize(array('oldusername' => $_G['username'],'newusername'  => $newusername)),
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

    if (C::memory()->enable) {
        C::memory()->clear();
    }

    require_once libfile('cache/userstats', 'function');
    build_cache_userstats();

    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_change_success');
    api_core::result($result);

    //changeusername end


}

api_core::result($result);

?>