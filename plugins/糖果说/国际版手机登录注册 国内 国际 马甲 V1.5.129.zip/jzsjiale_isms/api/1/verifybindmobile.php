<?php

/**
 *      Authorr:DisM!Ӧ������ dism.taobao.com
 *      ���²����http://t.cn/Aiux1Jx1
 *      e-mail: 467783778@qq.com
 *      dismall: https://dism.taobao.com/?@32563.developer
 *      createtime: 201907021510
 *      updatetime: 201907021652
 */

if(!defined('IN_JZSJIALE_ISMS_API')) {
    exit('JZSJIALE_ISMS API Access Denied');
}

global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';

$result = array('code'=>1,'data'=>null,'msg'=>'msg_verify_fail');

$formhash = addslashes($_POST['formhash'])? addslashes($_POST['formhash']):'';

if (!$_G['uid']){
    $url_forward = "member.php?mod=logging&action=login";
    $result = array('code'=>1,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_need_login');
    api_core::result($result);
}
if (submitcheck('verifybindsubmit') && $formhash == FORMHASH && $_POST['discode'] == '32563'){

    if (!in_array($_POST['device'], array('pc', 'mobile'))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_device_illegal');
        api_core::result($result);
    }
    if ($_POST['device'] == 'pc' && (!$_config['g_openpcbangding'] || !in_array('pcbindverifyoldphone',(array) unserialize($_config['g_bindoption'])))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }
    if ($_POST['device'] == 'mobile' && (!$_config['g_openmobilebangding'] || !in_array('mobilebindverifyoldphone',(array) unserialize($_config['g_bindoption'])))) {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_closed');
        api_core::result($result);
    }

    $areacode = '86';
    $phone = '';
    $seccode = addslashes($_POST['seccode']);

    $finduser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);
    if (!empty($finduser['mobile'])){
        $phone = $finduser['mobile'];
    }else{
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_smssendphone_null');
        api_core::result($result);
    }

    $areacode = !empty($finduser[$field])?$finduser[$field]:'86';


    if (empty($areacode) || !preg_match("/^[0-9]+$/",$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_error');
        api_core::result($result);
    }

    //check areacode status by changjiale 20190801
    $smsareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
    $smsareacode = (array)unserialize($smsareacode['jisms_allareacode']);

    $areacodestatus = $utils->searchGetOne($areacode,'areacode','status',$smsareacode);
    if(!$areacodestatus){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_areacode_notopen');
        api_core::result($result);
    }


    if(!$utils->isMobile($phone,$areacode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_phone_formaterror');
        api_core::result($result);
    }

    if (empty($seccode)){
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_seccode_empty');
        api_core::result($result);
    }



    //check seccode by changjiale 20190726

    $codeinfo = C::t('#jzsjiale_isms#jzsjiale_isms_code')->fetchfirst_by_areacode_phone_seccode($areacode,$phone,$seccode);
    if ($codeinfo) {
        if ((TIMESTAMP - $codeinfo[dateline]) > $_config['g_youxiaoqi']) {
            C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);
            $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_seccodeguoqi');
            api_core::result($result);
        }
    } else {
        $result = array('code'=>1,'data'=>null,'msg'=>'msg_err_checkseccode');
        api_core::result($result);
    }


    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $_G['uid'],
        'username' => $_G['username'],
        'areacode' => $areacode,
        'phone' => $phone,
        'type' => 'verify',
        'operationuid' => $_G['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

    C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteby_areacode_seccode_phone($areacode,$phone,$seccode);

    $member = getuserbyuid($_G['uid'], 1);
    $idstring = random(6);
    $table_ext = $member['_inarchive'] ? '_archive' : '';
    C::t('common_member_field_forum' . $table_ext)->update($member['uid'], array('authstr' => "$_G[timestamp]\t1\t$idstring"));

    $sign = $utils->make_verify_sign($_G['uid'], $idstring);

    $url_forward = "plugin.php?id=jzsjiale_isms:security&op=bindmobile&ac=rebindmobile&uid=".$_G['uid']."&hashid=".$idstring."&sign=".$sign;

    $result = array('code'=>0,'data'=>array('url_forward'=>$url_forward),'msg'=>'msg_verify_success');
    api_core::result($result);
}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_verify_fail');
    api_core::result($result);
}

api_core::result($result);

?>