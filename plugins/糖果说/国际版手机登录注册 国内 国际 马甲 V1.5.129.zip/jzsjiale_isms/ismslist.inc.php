<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
global $_G, $lang;

if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
    @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
    $utils = new ISMSUtils();
}

if($act=='qingliweek1'){
    if(submitcheck('submit')){
        C::t('#jzsjiale_isms#jzsjiale_isms_code')->deleteweek1();
        C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->deleteweek1();
        cpmsg('jzsjiale_isms:qingliweek1ok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismslist', 'succeed');
    }
    cpmsg('jzsjiale_isms:delqingliweek1','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismslist&act=qingliweek1&submit=yes','form');
}elseif($act=='qingliall'){
    if(submitcheck('submit')){
        C::t('#jzsjiale_isms#jzsjiale_isms_code')->delall();
        C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->delall();
        cpmsg('jzsjiale_isms:qingliallok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismslist', 'succeed');
    }
    cpmsg('jzsjiale_isms:delqingliall','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismslist&act=qingliall&submit=yes','form');
}


//zongtiaoshu
loadcache('plugin');
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$phonesendallcount = C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->count_all_by_day();
$g_zongxiane = ($_config['g_zongxiane']>0)?$_config['g_zongxiane']:0;
echo "<span style='color:red;'>".plang("zongxiane")."</span>".($g_zongxiane?$g_zongxiane:plang("zongxianebuxiane"));
echo "<br/>";
echo "<span style='color:red;'>".plang("jinrifasong")."</span>".$phonesendallcount;


showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismslist', 'enctype');


$phone = daddslashes(trim($_GET['phone']));
$username = daddslashes(trim($_GET['username']));
$ip = daddslashes(trim($_GET['ip']));
$uid = daddslashes(trim($_GET['uid']));
$status = daddslashes(trim($_GET['status']));
$date = daddslashes(trim($_GET['date']));
$smstype = daddslashes(trim($_GET['smstype']));

$page = intval($_GET['page']);
$page = $page > 0 ? $page : 1;
$pagesize = 20;
$start = ($page - 1) * $pagesize;

//20170703start
$map = array();
if(!empty($phone)){
    $map['phone'] = $phone;
}
if(!empty($username)){
    $map['username'] = $username;
}
if(!empty($ip)){
    $map['ip'] = $ip;
}
if(!empty($uid)){
    $map['uid'] = $uid;
}
if(!empty($status) || $status == '0'){
    $map['status'] = $status;
}
if(!empty($smstype) || $smstype == '0'){
    $map['type'] = $smstype;
}
if(!empty($date)){
    $map['dateline'] = strtotime($date);
}

$allsmslist = C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->range_by_map($map,$start,$pagesize,'DESC');
$count = C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->count_by_map($map);

$type_options = "<option value=\"all\"  " . (($smstype == 'all') ? "selected='selected'" : '') . ">" . plang('allsmslisttype') . "</option>"
    . "<option value='0' " . (($smstype == '0') ? "selected='selected'" : '') . ">" . plang('typeceshi') . "</option>"
    . "<option value='1' " . (($smstype == '1') ? "selected='selected'" : '') . ">" . plang('typezhuce') . "</option>"
    . "<option value='2' " . (($smstype == '2') ? "selected='selected'" : '') . ">" . plang('typeshenfenyanzheng') . "</option>"
    . "<option value='3' " . (($smstype == '3') ? "selected='selected'" : '') . ">" . plang('typedenglu') . "</option>"
    . "<option value='4' " . (($smstype == '4') ? "selected='selected'" : '') . ">" . plang('typexiugaimima') . "</option>"
    . "<option value='6' " . (($smstype == '6') ? "selected='selected'" : '') . ">" . plang('typeapp') . "</option>"
    . "<option value='7' " . (($smstype == '7') ? "selected='selected'" : '') . ">" . plang('typeother') . "</option>";

$status_options = "<option value=\"all\"  " . (($status == 'all') ? "selected='selected'" : '') . ">" . plang('statusall') . "</option>"
                . "<option value='0' " . (($status == '0') ? "selected='selected'" : '') . ">" . plang('statuserror') . "</option>"
                . "<option value='1' " . (($status == '1') ? "selected='selected'" : '') . ">" . plang('statussuccess') . "</option>";

echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
showtablerow('', array('width="50"', 'width="60"', 'width="75"', 'width="80"', 'width="50"', 'width="60"', 'width="40"', ''), array(
plang('smsstarttime'),
"<input type=\"text\" onclick=\"showcalendar(event, this)\" value=\"$date\" name=\"date\" class=\"txt\"> ",
plang('smsstatus'),
"<select name=\"status\">$status_options</select> ",
plang('smslisttype'),
"<select name=\"smstype\">$type_options</select> ",
plang('smsphone'),
"<input size=\"15\" name=\"phone\" type=\"text\" value=\"$phone\" /> ",
plang('smsuid'),
"<input size=\"15\" name=\"uid\" type=\"text\" value=\"$uid\" /> ",
plang('smsusername'),
"<input size=\"15\" name=\"username\" type=\"text\" value=\"$username\" /> ",
plang('smsip'),
"<input size=\"15\" name=\"ip\" type=\"text\" value=\"$ip\" /> 
<input class=\"btn\" type=\"submit\" value=\"" . cplang('search') . "\" />"
    )
);
echo '<br/><span style="color:red;">'.plang('ipchecktip').'</span><br/>';
showtableheader(plang('smslist').'(&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismslist&act=qingliweek1" style="color:red;">'.plang('qingliweek1').'</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismslist&act=qingliall" style="color:blue;">'.plang('qingliall').'</a>&nbsp;&nbsp;&nbsp;&nbsp;)'.'&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://dism.taobao.com/?@jzsjiale_isms.plugin.doc/smserror" target="_blank" style="color:blue;">'.plang('smserrortable').'</a>&nbsp;&nbsp;&nbsp;&nbsp;');
showsubtitle(plang('smslisttitle'));
foreach($allsmslist as $d){
    showtablerow('', array('width="50"'), array(
    $d['id'],
    '<span title="'.$d['areacode'].'"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&areacodesearch=1&keyword='.$d['areacode'].'" target="_blank">'.$d['areacode'].'</a></span>',
    '<span title="'.$d['phone'].'"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&keyword='.$d['phone'].'" target="_self">'.$d['phone'].'</a><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=log&keyword='.$d['phone'].'" style="color:green;" target="_self">'.(!empty($d['phone'])?'  @log':'').'</a></span>',
    '<span title="'.$d['uid'].'"><a href="home.php?mod=space&uid='.$d['uid'].'&do=profile" target="_blank">'.$d['uid'].'</a></span>',
    '<span title="'.(!empty($d['username'])?$d['username']:"#").'"><a href="home.php?mod=space&uid='.$d['uid'].'&do=profile" target="_blank">'.(!empty($d['username'])?$d['username']:"#").'</a></span>',
    $d['seccode'],
    $utils->gettype($d['type']),
    $utils->getstatus($d['status']),
    dgmdate($d['dateline'], 'Y-m-d H:i:s'),
    $d['msg'],
    $d['ip'])
    );
}

$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismslist&phone='.$phone.'&status='.$status.'&date='.$date.'&uid='.$uid.'&username='.$username.'&smstype='.$smstype.'&ip='.$ip;
$multipage = multi($count, $pagesize, $page, $mpurl);
//showsubmit('', '', '', '', $multipage);


//search start
showsubmit('', '', '', '', $multipage);

//search end


showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/




function plang($str) {
    return lang('plugin/jzsjiale_isms', $str);
}
//From: d'.'is'.'m.ta'.'obao.com
?>