(function() {
    ISMSVD = function(vid, element, type, scene, offlineurl) {
        let it = this;
        this.vaptcha = null;
        this.token = null;
        this.reset = function() {};
        this.initVaptcha = function(vidType) {
            if (it.vaptcha) {
                if (!vidType) return it.vaptcha.reset();
                else it.vaptcha.destroy();
            }
            let options = {
                vid: vid,
                container: element,
                https: true,
                type: type,
                checkingAnimation: 'display',
                lang: 'zh-CN',
                ai: true,
                scene: scene,
                offline_server: offlineurl,
                //mode: 'offline'
                // color: type==='float'?'rgb(51, 51, 51)':'',
            };
            window.vaptcha(options).then(function(vaptcha_obj) {
                it.vaptcha = vaptcha_obj;
                vaptcha_obj.listen('pass', function() {
                    vaptchaCallback(vaptcha_obj.getToken());
                });

                type == 'invisible' ? it.vaptcha.validate() : it.vaptcha.render();
            })
        };
        this.initLoginVaptcha = function(vidType) {
            if (it.vaptcha) {
                if (!vidType) return it.vaptcha.reset();
                else it.vaptcha.destroy();
            }
            let options = {
                vid: vid,
                container: element,
                https: true,
                type: type,
                checkingAnimation: 'display',
                lang: 'zh-CN',
                ai: true,
                scene: scene,
                offline_server: offlineurl,
                //mode: 'offline'
                // color: type==='float'?'rgb(51, 51, 51)':'',
            };
            window.vaptcha(options).then(function(vaptcha_obj) {
                it.vaptcha = vaptcha_obj;
                vaptcha_obj.listen('pass', function() {
                    vaptchaLoginCallback(vaptcha_obj.getToken());
                });

                type == 'invisible' ? it.vaptcha.validate() : it.vaptcha.render();
            })
        }
    };
    ISMSVD.prototype = {
        constructor: ISMSVD,
    };
    
    window.ISMSVD = ISMSVD;
})();