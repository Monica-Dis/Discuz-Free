/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
(function(root, factory) {
    if (typeof define === 'function' && define.amd) {
        define([], factory);
    } else if (typeof module === 'object' && module.exports) {
        module.exports = factory();
    } else { root._ = factory(); }
}(this, function () {
    var _ = {};

    /* ------------------------------ inherits ------------------------------ */

    var inherits = _.inherits = (function (exports) {
        /* Inherit the prototype methods from one constructor into another.
         *
         * |Name      |Type    |Desc       |
         * |----------|--------|-----------|
         * |Class     |function|Child Class|
         * |SuperClass|function|Super Class|
         */

        /* example
         * function People(name) {
         *     this._name = name;
         * }
         * People.prototype = {
         *     getName: function () {
         *         return this._name;
         *     }
         * };
         * function Student(name) {
         *     this._name = name;
         * }
         * inherits(Student, People);
         * var s = new Student('RedHood');
         * s.getName(); // -> 'RedHood'
         */

        /* typescript
         * export declare function inherits(Class: Function, SuperClass: Function): void;
         */
        exports = function exports(Class, SuperClass) {
            if (objCreate) return (Class.prototype = objCreate(SuperClass.prototype));
            noop.prototype = SuperClass.prototype;
            Class.prototype = new noop();
        };

        var objCreate = Object.create;

        function noop() {}

        return exports;
    })({});

    /* ------------------------------ has ------------------------------ */

    var has = _.has = (function (exports) {
        /* Checks if key is a direct property.
         *
         * |Name  |Type   |Desc                            |
         * |------|-------|--------------------------------|
         * |obj   |object |Object to query                 |
         * |key   |string |Path to check                   |
         * |return|boolean|True if key is a direct property|
         */

        /* example
         * has({one: 1}, 'one'); // -> true
         */

        /* typescript
         * export declare function has(obj: {}, key: string): boolean;
         */
        var hasOwnProp = Object.prototype.hasOwnProperty;

        exports = function exports(obj, key) {
            return hasOwnProp.call(obj, key);
        };

        return exports;
    })({});

    /* ------------------------------ slice ------------------------------ */

    var slice = _.slice = (function (exports) {
        /* Create slice of source array or array-like object.
         *
         * |Name              |Type  |Desc                      |
         * |------------------|------|--------------------------|
         * |array             |array |Array to slice            |
         * |[start=0]         |number|Start position            |
         * |[end=array.length]|number|End position, not included|
         */

        /* example
         * slice([1, 2, 3, 4], 1, 2); // -> [2]
         */

        /* typescript
         * export declare function slice(array: any[], start?: number, end?: number): any[];
         */
        exports = function exports(arr, start, end) {
            var len = arr.length;

            if (start == null) {
                start = 0;
            } else if (start < 0) {
                start = Math.max(len + start, 0);
            } else {
                start = Math.min(start, len);
            }

            if (end == null) {
                end = len;
            } else if (end < 0) {
                end = Math.max(len + end, 0);
            } else {
                end = Math.min(end, len);
            }

            var ret = [];

            while (start < end) {
                ret.push(arr[start++]);
            }

            return ret;
        };

        return exports;
    })({});

    /* ------------------------------ isObj ------------------------------ */

    var isObj = _.isObj = (function (exports) {
        function _typeof(obj) {
            if (typeof Symbol === 'function' && typeof Symbol.iterator === 'symbol') {
                _typeof = function _typeof(obj) {
                    return typeof obj;
                };
            } else {
                _typeof = function _typeof(obj) {
                    return obj &&
                        typeof Symbol === 'function' &&
                        obj.constructor === Symbol &&
                        obj !== Symbol.prototype
                        ? 'symbol'
                        : typeof obj;
                };
            }
            return _typeof(obj);
        }

        /* Check if value is the language type of Object.
         *
         * |Name  |Type   |Desc                      |
         * |------|-------|--------------------------|
         * |val   |*      |Value to check            |
         * |return|boolean|True if value is an object|
         *
         * [Language Spec](http://www.ecma-international.org/ecma-262/6.0/#sec-ecmascript-language-types)
         */

        /* example
         * isObj({}); // -> true
         * isObj([]); // -> true
         */

        /* typescript
         * export declare function isObj(val: any): boolean;
         */
        exports = function exports(val) {
            var type = _typeof(val);

            return !!val && (type === 'function' || type === 'object');
        };

        return exports;
    })({});

    /* ------------------------------ nextTick ------------------------------ */

    var nextTick = _.nextTick = (function (exports) {
        function _typeof(obj) {
            if (typeof Symbol === 'function' && typeof Symbol.iterator === 'symbol') {
                _typeof = function _typeof(obj) {
                    return typeof obj;
                };
            } else {
                _typeof = function _typeof(obj) {
                    return obj &&
                        typeof Symbol === 'function' &&
                        obj.constructor === Symbol &&
                        obj !== Symbol.prototype
                        ? 'symbol'
                        : typeof obj;
                };
            }
            return _typeof(obj);
        }

        /* Next tick for both node and browser.
         *
         * |Name|Type    |Desc            |
         * |----|--------|----------------|
         * |cb  |function|Function to call|
         *
         * Use process.nextTick if available.
         *
         * Otherwise setImmediate or setTimeout is used as fallback.
         */

        /* example
         * nextTick(function () {
         *     // Do something...
         * });
         */

        /* typescript
         * export declare function nextTick(cb: Function): void;
         */
        if (
            (typeof process === 'undefined' ? 'undefined' : _typeof(process)) ===
                'object' &&
            process.nextTick
        ) {
            exports = process.nextTick;
        } else if (typeof setImmediate === 'function') {
            exports = function exports(cb) {
                setImmediate(ensureCallable(cb));
            };
        } else {
            exports = function exports(cb) {
                setTimeout(ensureCallable(cb), 0);
            };
        }

        function ensureCallable(fn) {
            if (typeof fn !== 'function')
                throw new TypeError(fn + ' is not a function');
            return fn;
        }

        return exports;
    })({});

    /* ------------------------------ noop ------------------------------ */

    var noop = _.noop = (function (exports) {
        /* A no-operation function.
         */

        /* example
         * noop(); // Does nothing
         */

        /* typescript
         * export declare function noop(): void;
         */
        exports = function exports() {};

        return exports;
    })({});

    /* ------------------------------ isBrowser ------------------------------ */

    var isBrowser = _.isBrowser = (function (exports) {
        function _typeof(obj) {
            if (typeof Symbol === 'function' && typeof Symbol.iterator === 'symbol') {
                _typeof = function _typeof(obj) {
                    return typeof obj;
                };
            } else {
                _typeof = function _typeof(obj) {
                    return obj &&
                        typeof Symbol === 'function' &&
                        obj.constructor === Symbol &&
                        obj !== Symbol.prototype
                        ? 'symbol'
                        : typeof obj;
                };
            }
            return _typeof(obj);
        }

        /* Check if running in a browser.
         */

        /* example
         * console.log(isBrowser); // -> true if running in a browser
         */

        /* typescript
         * export declare const isBrowser: boolean;
         */
        exports =
            (typeof window === 'undefined' ? 'undefined' : _typeof(window)) ===
                'object' &&
            (typeof document === 'undefined' ? 'undefined' : _typeof(document)) ===
                'object' &&
            document.nodeType === 9;

        return exports;
    })({});

    /* ------------------------------ allKeys ------------------------------ */

    var allKeys = _.allKeys = (function (exports) {
        /* Retrieve all the names of object's own and inherited properties.
         *
         * |Name  |Type  |Desc                       |
         * |------|------|---------------------------|
         * |obj   |object|Object to query            |
         * |return|array |Array of all property names|
         *
         * Members of Object's prototype won't be retrieved.
         */

        /* example
         * var obj = Object.create({zero: 0});
         * obj.one = 1;
         * allKeys(obj) // -> ['zero', 'one']
         */

        /* typescript
         * export declare function allKeys(obj: any): string[];
         */
        exports = function exports(obj) {
            var ret = [],
                key;

            for (key in obj) {
                ret.push(key);
            }

            return ret;
        };

        return exports;
    })({});

    /* ------------------------------ base64 ------------------------------ */

    _.base64 = (function (exports) {
        /* Basic base64 encoding and decoding.
         *
         * ### encode
         *
         * Turn a byte array into a base64 string.
         *
         * |Name  |Type  |Desc         |
         * |------|------|-------------|
         * |arr   |array |Byte array   |
         * |return|string|Base64 string|
         *
         * ### decode
         *
         * Turn a base64 string into a byte array.
         *
         * |Name  |Type  |Desc         |
         * |------|------|-------------|
         * |str   |string|Base64 string|
         * |return|array |Byte array   |
         */

        /* example
         * base64.encode([168, 174, 155, 255]); // -> 'qK6b/w=='
         * base64.decode('qK6b/w=='); // -> [168, 174, 155, 255]
         */

        /* typescript
         * export declare const base64: {
         *     encode(arr: number[]): string;
         *     decode(str: string): number[];
         * };
         */
        exports = {
            encode: function encode(arr) {
                var ret = [],
                    len = arr.length,
                    remain = len % 3;
                len = len - remain;

                for (var i = 0; i < len; i += 3) {
                    ret.push(
                        numToBase64((arr[i] << 16) + (arr[i + 1] << 8) + arr[i + 2])
                    );
                }

                len = arr.length;
                var tmp;

                if (remain === 1) {
                    tmp = arr[len - 1];
                    ret.push(code[tmp >> 2]);
                    ret.push(code[(tmp << 4) & 0x3f]);
                    ret.push('==');
                } else if (remain === 2) {
                    tmp = (arr[len - 2] << 8) + arr[len - 1];
                    ret.push(code[tmp >> 10]);
                    ret.push(code[(tmp >> 4) & 0x3f]);
                    ret.push(code[(tmp << 2) & 0x3f]);
                    ret.push('=');
                }

                return ret.join('');
            },
            decode: function decode(str) {
                var len = str.length,
                    remain = 0;
                if (str[len - 2] === '=') remain = 2;
                else if (str[len - 1] === '=') remain = 1;
                var ret = new Array((len * 3) / 4 - remain);
                len = remain > 0 ? len - 4 : len;

                for (var i = 0, j = 0; i < len; i += 4) {
                    var num = base64ToNum(str[i], str[i + 1], str[i + 2], str[i + 3]);
                    ret[j++] = (num >> 16) & 0xff;
                    ret[j++] = (num >> 8) & 0xff;
                    ret[j++] = num & 0xff;
                }

                var tmp;

                if (remain === 2) {
                    tmp =
                        (codeMap[str.charCodeAt(i)] << 2) |
                        (codeMap[str.charCodeAt(i + 1)] >> 4);
                    ret[j++] = tmp & 0xff;
                } else if (remain === 1) {
                    tmp =
                        (codeMap[str.charCodeAt(i)] << 10) |
                        (codeMap[str.charCodeAt(i + 1)] << 4) |
                        (codeMap[str.charCodeAt(i + 2)] >> 2);
                    ret[j++] = (tmp >> 8) & 0xff;
                    ret[j++] = tmp & 0xff;
                }

                return ret;
            }
        };
        var codeMap = [],
            code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

        for (var i = 0, len = code.length; i < len; i++) {
            codeMap[code.charCodeAt(i)] = i;
        }

        function numToBase64(num) {
            return (
                code[(num >> 18) & 0x3f] +
                code[(num >> 12) & 0x3f] +
                code[(num >> 6) & 0x3f] +
                code[num & 0x3f]
            );
        }

        function base64ToNum(str1, str2, str3, str4) {
            return (
                (codeMap[str1.charCodeAt(0)] << 18) |
                (codeMap[str2.charCodeAt(0)] << 12) |
                (codeMap[str3.charCodeAt(0)] << 6) |
                codeMap[str4.charCodeAt(0)]
            );
        }

        return exports;
    })({});

    /* ------------------------------ before ------------------------------ */

    var before = _.before = (function (exports) {
        /* Create a function that invokes less than n times.
         *
         * |Name  |Type    |Desc                                            |
         * |------|--------|------------------------------------------------|
         * |n     |number  |Number of calls at which fn is no longer invoked|
         * |fn    |function|Function to restrict                            |
         * |return|function|New restricted function                         |
         *
         * Subsequent calls to the created function return the result of the last fn invocation.
         */

        /* example
         * const fn = before(5, function() {});
         * fn(); // Allow function to be call 4 times at last.
         */

        /* typescript
         * export declare function before(n: number, fn: Function): Function;
         */
        exports = function exports(n, fn) {
            var memo;
            return function() {
                if (--n > 0) memo = fn.apply(this, arguments);
                if (n <= 1) fn = null;
                return memo;
            };
        };

        return exports;
    })({});

    /* ------------------------------ restArgs ------------------------------ */

    var restArgs = _.restArgs = (function (exports) {
        /* This accumulates the arguments passed into an array, after a given index.
         *
         * |Name        |Type    |Desc                                   |
         * |------------|--------|---------------------------------------|
         * |function    |function|Function that needs rest parameters    |
         * |[startIndex]|number  |The start index to accumulates         |
         * |return      |function|Generated function with rest parameters|
         */

        /* example
         * var paramArr = restArgs(function (rest) { return rest });
         * paramArr(1, 2, 3, 4); // -> [1, 2, 3, 4]
         */

        /* typescript
         * export declare function restArgs(fn: Function, startIndex?: number): Function;
         */
        exports = function exports(fn, startIdx) {
            startIdx = startIdx == null ? fn.length - 1 : +startIdx;
            return function() {
                var len = Math.max(arguments.length - startIdx, 0),
                    rest = new Array(len),
                    i;

                for (i = 0; i < len; i++) {
                    rest[i] = arguments[i + startIdx];
                } // Call runs faster than apply.

                switch (startIdx) {
                    case 0:
                        return fn.call(this, rest);

                    case 1:
                        return fn.call(this, arguments[0], rest);

                    case 2:
                        return fn.call(this, arguments[0], arguments[1], rest);
                }

                var args = new Array(startIdx + 1);

                for (i = 0; i < startIdx; i++) {
                    args[i] = arguments[i];
                }

                args[startIdx] = rest;
                return fn.apply(this, args);
            };
        };

        return exports;
    })({});

    /* ------------------------------ bind ------------------------------ */

    var bind = _.bind = (function (exports) {
        /* Create a function bound to a given object.
         *
         * |Name   |Type    |Desc                    |
         * |-------|--------|------------------------|
         * |fn     |function|Function to bind        |
         * |ctx    |*       |This binding of given fn|
         * |...rest|*       |Optional arguments      |
         * |return |function|New bound function      |
         */

        /* example
         * var fn = bind(function (msg) {
         *     console.log(this.name + ':' + msg);
         * }, {name: 'eustia'}, 'I am a utility library.');
         * fn(); // -> 'eustia: I am a utility library.'
         */

        /* typescript
         * export declare function bind(fn: Function, ctx: any, ...rest: any[]): Function;
         */

        /* dependencies
         * restArgs 
         */

        exports = restArgs(function(fn, ctx, rest) {
            return restArgs(function(callArgs) {
                return fn.apply(ctx, rest.concat(callArgs));
            });
        });

        return exports;
    })({});

    /* ------------------------------ isUndef ------------------------------ */

    var isUndef = _.isUndef = (function (exports) {
        /* Check if value is undefined.
         *
         * |Name  |Type   |Desc                      |
         * |------|-------|--------------------------|
         * |val   |*      |Value to check            |
         * |return|boolean|True if value is undefined|
         */

        /* example
         * isUndef(void 0); // -> true
         * isUndef(null); // -> false
         */

        /* typescript
         * export declare function isUndef(val: any): boolean;
         */
        exports = function exports(val) {
            return val === void 0;
        };

        return exports;
    })({});

    /* ------------------------------ toStr ------------------------------ */

    var toStr = _.toStr = (function (exports) {
        /* Convert value to a string.
         *
         * |Name  |Type  |Desc            |
         * |------|------|----------------|
         * |val   |*     |Value to convert|
         * |return|string|Resulted string |
         */

        /* example
         * toStr(null); // -> ''
         * toStr(1); // -> '1'
         * toStr(false); // -> 'false'
         * toStr([1, 2, 3]); // -> '1,2,3'
         */

        /* typescript
         * export declare function toStr(val: any): string;
         */
        exports = function exports(val) {
            return val == null ? '' : val.toString();
        };

        return exports;
    })({});

    /* ------------------------------ ucs2 ------------------------------ */

    var ucs2 = _.ucs2 = (function (exports) {
        /* UCS-2 encoding and decoding.
         *
         * ### encode
         *
         * Create a string using an array of code point values.
         *
         * |Name  |Type  |Desc                |
         * |------|------|--------------------|
         * |arr   |array |Array of code points|
         * |return|string|Encoded string      |
         *
         * ### decode
         *
         * Create an array of code point values using a string.
         *
         * |Name  |Type  |Desc                |
         * |------|------|--------------------|
         * |str   |string|Input string        |
         * |return|array |Array of code points|
         */

        /* example
         * ucs2.encode([0x61, 0x62, 0x63]); // -> 'abc'
         * ucs2.decode('abc'); // -> [0x61, 0x62, 0x63]
         * ''.length; // -> 2
         * ucs2.decode('').length; // -> 1
         */

        /* typescript
         * export declare const ucs2: {
         *     encode(arr: number[]): string;
         *     decode(str: string): number[];
         * };
         */
        // https://mathiasbynens.be/notes/javascript-encoding
        exports = {
            encode: function encode(arr) {
                return String.fromCodePoint.apply(String, arr);
            },
            decode: function decode(str) {
                var ret = [];
                var i = 0,
                    len = str.length;

                while (i < len) {
                    var c = str.charCodeAt(i++); // A high surrogate

                    if (c >= 0xd800 && c <= 0xdbff && i < len) {
                        var tail = str.charCodeAt(i++); // nextC >= 0xDC00 && nextC <= 0xDFFF

                        if ((tail & 0xfc00) === 0xdc00) {
                            // C = (H - 0xD800) * 0x400 + L - 0xDC00 + 0x10000
                            ret.push(((c & 0x3ff) << 10) + (tail & 0x3ff) + 0x10000);
                        } else {
                            ret.push(c);
                            i--;
                        }
                    } else {
                        ret.push(c);
                    }
                }

                return ret;
            }
        };

        return exports;
    })({});

    /* ------------------------------ utf8 ------------------------------ */

    var utf8 = _.utf8 = (function (exports) {
        /* UTF-8 encoding and decoding.
         *
         * ### encode
         *
         * Turn any UTF-8 decoded string into UTF-8 encoded string.
         *
         * |Name  |Type  |Desc            |
         * |------|------|----------------|
         * |str   |string|String to encode|
         * |return|string|Encoded string  |
         *
         * ### decode
         *
         * Turn any UTF-8 encoded string into UTF-8 decoded string.
         *
         * |Name      |Type   |Desc                  |
         * |----------|-------|----------------------|
         * |str       |string |String to decode      |
         * |safe=false|boolean|Suppress error if true|
         * |return    |string |Decoded string        |
         */

        /* example
         * utf8.encode('\uD800\uDC00'); // ->  '\xF0\x90\x80\x80'
         * utf8.decode('\xF0\x90\x80\x80'); // -> '\uD800\uDC00'
         */

        /* typescript
         * export declare const utf8: {
         *     encode(str: string): string;
         *     decode(str: string, safe?: boolean): string;
         * };
         */

        /* dependencies
         * ucs2 
         */ // https://encoding.spec.whatwg.org/#utf-8

        exports = {
            encode: function encode(str) {
                var codePoints = ucs2.decode(str);
                var byteArr = '';

                for (var i = 0, len = codePoints.length; i < len; i++) {
                    byteArr += encodeCodePoint(codePoints[i]);
                }

                return byteArr;
            },
            decode: function decode(str, safe) {
                byteArr = ucs2.decode(str);
                byteIdx = 0;
                byteCount = byteArr.length;
                codePoint = 0;
                bytesSeen = 0;
                bytesNeeded = 0;
                lowerBoundary = 0x80;
                upperBoundary = 0xbf;
                var codePoints = [];
                var tmp;

                while ((tmp = decodeCodePoint(safe)) !== false) {
                    codePoints.push(tmp);
                }

                return ucs2.encode(codePoints);
            }
        };
        var fromCharCode = String.fromCharCode;

        function encodeCodePoint(codePoint) {
            // U+0000 to U+0080, ASCII code point
            if ((codePoint & 0xffffff80) === 0) {
                return fromCharCode(codePoint);
            }

            var ret = '',
                count,
                offset; // U+0080 to U+07FF, inclusive

            if ((codePoint & 0xfffff800) === 0) {
                count = 1;
                offset = 0xc0;
            } else if ((codePoint & 0xffff0000) === 0) {
                // U+0800 to U+FFFF, inclusive
                count = 2;
                offset = 0xe0;
            } else if ((codePoint & 0xffe00000) == 0) {
                // U+10000 to U+10FFFF, inclusive
                count = 3;
                offset = 0xf0;
            }

            ret += fromCharCode((codePoint >> (6 * count)) + offset);

            while (count > 0) {
                var tmp = codePoint >> (6 * (count - 1));
                ret += fromCharCode(0x80 | (tmp & 0x3f));
                count--;
            }

            return ret;
        }

        var byteArr,
            byteIdx,
            byteCount,
            codePoint,
            bytesSeen,
            bytesNeeded,
            lowerBoundary,
            upperBoundary;

        function decodeCodePoint(safe) {
            /* eslint-disable no-constant-condition */
            while (true) {
                if (byteIdx >= byteCount && bytesNeeded) {
                    if (safe) return goBack();
                    throw new Error('Invalid byte index');
                }

                if (byteIdx === byteCount) return false;
                var byte = byteArr[byteIdx];
                byteIdx++;

                if (!bytesNeeded) {
                    // 0x00 to 0x7F
                    if ((byte & 0x80) === 0) {
                        return byte;
                    } // 0xC2 to 0xDF

                    if ((byte & 0xe0) === 0xc0) {
                        bytesNeeded = 1;
                        codePoint = byte & 0x1f;
                    } else if ((byte & 0xf0) === 0xe0) {
                        // 0xE0 to 0xEF
                        if (byte === 0xe0) lowerBoundary = 0xa0;
                        if (byte === 0xed) upperBoundary = 0x9f;
                        bytesNeeded = 2;
                        codePoint = byte & 0xf;
                    } else if ((byte & 0xf8) === 0xf0) {
                        // 0xF0 to 0xF4
                        if (byte === 0xf0) lowerBoundary = 0x90;
                        if (byte === 0xf4) upperBoundary = 0x8f;
                        bytesNeeded = 3;
                        codePoint = byte & 0x7;
                    } else {
                        if (safe) return goBack();
                        throw new Error('Invalid UTF-8 detected');
                    }

                    continue;
                }

                if (byte < lowerBoundary || byte > upperBoundary) {
                    if (safe) {
                        byteIdx--;
                        return goBack();
                    }

                    throw new Error('Invalid continuation byte');
                }

                lowerBoundary = 0x80;
                upperBoundary = 0xbf;
                codePoint = (codePoint << 6) | (byte & 0x3f);
                bytesSeen++;
                if (bytesSeen !== bytesNeeded) continue;
                var tmp = codePoint;
                codePoint = 0;
                bytesNeeded = 0;
                bytesSeen = 0;
                return tmp;
            }
        }

        function goBack() {
            var start = byteIdx - bytesSeen - 1;
            byteIdx = start + 1;
            codePoint = 0;
            bytesNeeded = 0;
            bytesSeen = 0;
            lowerBoundary = 0x80;
            upperBoundary = 0xbf;
            return byteArr[start];
        }

        return exports;
    })({});

    /* ------------------------------ root ------------------------------ */

    var root = _.root = (function (exports) {
        /* Root object reference, `global` in nodeJs, `window` in browser. */

        /* typescript
         * export declare const root: any;
         */

        /* dependencies
         * isBrowser 
         */

        exports = isBrowser ? window : global;

        return exports;
    })({});

    /* ------------------------------ detectMocha ------------------------------ */

    var detectMocha = _.detectMocha = (function (exports) {
        /* Detect if mocha is running.
         */

        /* example
         * detectMocha(); // -> True if mocha is running.
         */

        /* typescript
         * export declare function detectMocha(): boolean;
         */

        /* dependencies
         * root 
         */

        exports = function exports() {
            for (var i = 0, len = methods.length; i < len; i++) {
                var method = methods[i];
                if (typeof root[method] !== 'function') return false;
            }

            return true;
        };

        var methods = ['afterEach', 'after', 'beforeEach', 'before', 'describe', 'it'];

        return exports;
    })({});

    /* ------------------------------ keys ------------------------------ */

    var keys = _.keys = (function (exports) {
        /* Create an array of the own enumerable property names of object.
         *
         * |Name  |Type  |Desc                   |
         * |------|------|-----------------------|
         * |obj   |object|Object to query        |
         * |return|array |Array of property names|
         */

        /* example
         * keys({a: 1}); // -> ['a']
         */

        /* typescript
         * export declare function keys(obj: any): string[];
         */

        /* dependencies
         * has detectMocha 
         */

        if (Object.keys && !detectMocha()) {
            exports = Object.keys;
        } else {
            exports = function exports(obj) {
                var ret = [],
                    key;

                for (key in obj) {
                    if (has(obj, key)) ret.push(key);
                }

                return ret;
            };
        }

        return exports;
    })({});

    /* ------------------------------ optimizeCb ------------------------------ */

    var optimizeCb = _.optimizeCb = (function (exports) {
        /* Used for function context binding.
         */

        /* typescript
         * export declare function optimizeCb(fn: Function, ctx: any, argCount?: number): Function;
         */

        /* dependencies
         * isUndef 
         */

        exports = function exports(fn, ctx, argCount) {
            if (isUndef(ctx)) return fn;

            switch (argCount == null ? 3 : argCount) {
                case 1:
                    return function(val) {
                        return fn.call(ctx, val);
                    };

                case 3:
                    return function(val, idx, collection) {
                        return fn.call(ctx, val, idx, collection);
                    };

                case 4:
                    return function(accumulator, val, idx, collection) {
                        return fn.call(ctx, accumulator, val, idx, collection);
                    };
            }

            return function() {
                return fn.apply(ctx, arguments);
            };
        };

        return exports;
    })({});

    /* ------------------------------ types ------------------------------ */

    var types = _.types = (function (exports) {
        /* Used for typescript definitions only.
         */

        /* typescript
         * export declare namespace types {
         *     interface Collection<T> {}
         *     interface List<T> extends Collection<T> {
         *         [index: number]: T;
         *         length: number;
         *     }
         *     interface ListIterator<T, TResult> {
         *         (value: T, index: number, list: List<T>): TResult;
         *     }
         *     interface Dictionary<T> extends Collection<T> {
         *         [index: string]: T;
         *     }
         *     interface ObjectIterator<T, TResult> {
         *         (element: T, key: string, list: Dictionary<T>): TResult;
         *     }
         *     interface MemoIterator<T, TResult> {
         *         (prev: TResult, curr: T, index: number, list: List<T>): TResult;
         *     }
         *     interface MemoObjectIterator<T, TResult> {
         *         (prev: TResult, curr: T, key: string, list: Dictionary<T>): TResult;
         *     }
         * }
         * export declare const types: {}
         */
        exports = {};

        return exports;
    })({});

    /* ------------------------------ upperFirst ------------------------------ */

    var upperFirst = _.upperFirst = (function (exports) {
        /* Convert the first character of string to upper case.
         *
         * |Name  |Type  |Desc             |
         * |------|------|-----------------|
         * |str   |string|String to convert|
         * |return|string|Converted string |
         */

        /* example
         * upperFirst('red'); // -> Red
         */

        /* typescript
         * export declare function upperFirst(str: string): string;
         */
        exports = function exports(str) {
            if (str.length < 1) return str;
            return str[0].toUpperCase() + str.slice(1);
        };

        return exports;
    })({});

    /* ------------------------------ escapeRegExp ------------------------------ */

    _.escapeRegExp = (function (exports) {
        /* Escape special chars to be used as literals in RegExp constructors.
         *
         * |Name  |Type  |Desc            |
         * |------|------|----------------|
         * |str   |string|String to escape|
         * |return|string|Escaped string  |
         */

        /* example
         * escapeRegExp('[licia]'); // -> '\\[licia\\]'
         */

        /* typescript
         * export declare function escapeRegExp(str: string): string;
         */
        exports = function exports(str) {
            return str.replace(/\W/g, '\\$&');
        };

        return exports;
    })({});

    /* ------------------------------ identity ------------------------------ */

    var identity = _.identity = (function (exports) {
        /* Return the first argument given.
         *
         * |Name  |Type|Desc       |
         * |------|----|-----------|
         * |val   |*   |Any value  |
         * |return|*   |Given value|
         */

        /* example
         * identity('a'); // -> 'a'
         */

        /* typescript
         * export declare function identity<T>(val: T): T;
         */
        exports = function exports(val) {
            return val;
        };

        return exports;
    })({});

    /* ------------------------------ isAbsoluteUrl ------------------------------ */

    _.isAbsoluteUrl = (function (exports) {
        /* Check if an url is absolute.
         *
         * |Name  |Type   |Desc                   |
         * |------|-------|-----------------------|
         * |url   |string |Url to check           |
         * |return|boolean|True if url is absolute|
         */

        /* example
         * isAbsoluteUrl('http://www.surunzi.com'); // -> true
         * isAbsoluteUrl('//www.surunzi.com'); // -> false
         * isAbsoluteUrl('surunzi.com'); // -> false
         */

        /* typescript
         * export declare function isAbsoluteUrl(url: string): boolean;
         */
        exports = function exports(url) {
            return regAbsolute.test(url);
        };

        var regAbsolute = /^[a-z][a-z0-9+.-]*:/;

        return exports;
    })({});

    /* ------------------------------ objToStr ------------------------------ */

    var objToStr = _.objToStr = (function (exports) {
        /* Alias of Object.prototype.toString.
         *
         * |Name  |Type  |Desc                                |
         * |------|------|------------------------------------|
         * |val   |*     |Source value                        |
         * |return|string|String representation of given value|
         */

        /* example
         * objToStr(5); // -> '[object Number]'
         */

        /* typescript
         * export declare function objToStr(val: any): string;
         */
        var ObjToStr = Object.prototype.toString;

        exports = function exports(val) {
            return ObjToStr.call(val);
        };

        return exports;
    })({});

    /* ------------------------------ isArgs ------------------------------ */

    var isArgs = _.isArgs = (function (exports) {
        /* Check if value is classified as an arguments object.
         *
         * |Name  |Type   |Desc                                |
         * |------|-------|------------------------------------|
         * |val   |*      |Value to check                      |
         * |return|boolean|True if value is an arguments object|
         */

        /* example
         * (function () {
         *     isArgs(arguments); // -> true
         * })();
         */

        /* typescript
         * export declare function isArgs(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object Arguments]';
        };

        return exports;
    })({});

    /* ------------------------------ isArr ------------------------------ */

    var isArr = _.isArr = (function (exports) {
        /* Check if value is an `Array` object.
         *
         * |Name  |Type   |Desc                              |
         * |------|-------|----------------------------------|
         * |val   |*      |Value to check                    |
         * |return|boolean|True if value is an `Array` object|
         */

        /* example
         * isArr([]); // -> true
         * isArr({}); // -> false
         */

        /* typescript
         * export declare function isArr(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports =
            Array.isArray ||
            function(val) {
                return objToStr(val) === '[object Array]';
            };

        return exports;
    })({});

    /* ------------------------------ castPath ------------------------------ */

    var castPath = _.castPath = (function (exports) {
        /* Cast value into a property path array.
         *
         * |Name  |Type        |Desc               |
         * |------|------------|-------------------|
         * |path  |string array|Value to inspect   |
         * |[obj] |object      |Object to query    |
         * |return|array       |Property path array|
         */

        /* example
         * castPath('a.b.c'); // -> ['a', 'b', 'c']
         * castPath(['a']); // -> ['a']
         * castPath('a[0].b'); // -> ['a', '0', 'b']
         * castPath('a.b.c', {'a.b.c': true}); // -> ['a.b.c']
         */

        /* typescript
         * export declare function castPath(path: string | string[], obj?: any): string[];
         */

        /* dependencies
         * has isArr 
         */

        exports = function exports(str, obj) {
            if (isArr(str)) return str;
            if (obj && has(obj, str)) return [str];
            var ret = [];
            str.replace(regPropName, function(match, number, quote, str) {
                ret.push(quote ? str.replace(regEscapeChar, '$1') : number || match);
            });
            return ret;
        }; // Lodash _stringToPath

        var regPropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
            regEscapeChar = /\\(\\)?/g;

        return exports;
    })({});

    /* ------------------------------ safeGet ------------------------------ */

    var safeGet = _.safeGet = (function (exports) {
        /* Get object property, don't throw undefined error.
         *
         * |Name  |Type        |Desc                     |
         * |------|------------|-------------------------|
         * |obj   |object      |Object to query          |
         * |path  |array string|Path of property to get  |
         * |return|*           |Target value or undefined|
         */

        /* example
         * var obj = {a: {aa: {aaa: 1}}};
         * safeGet(obj, 'a.aa.aaa'); // -> 1
         * safeGet(obj, ['a', 'aa']); // -> {aaa: 1}
         * safeGet(obj, 'a.b'); // -> undefined
         */

        /* typescript
         * export declare function safeGet(obj: any, path: string | string[]): any;
         */

        /* dependencies
         * isUndef castPath 
         */

        exports = function exports(obj, path) {
            path = castPath(path, obj);
            var prop;
            prop = path.shift();

            while (!isUndef(prop)) {
                obj = obj[prop];
                if (obj == null) return;
                prop = path.shift();
            }

            return obj;
        };

        return exports;
    })({});

    /* ------------------------------ isDate ------------------------------ */

    var isDate = _.isDate = (function (exports) {
        /* Check if value is classified as a Date object.
         *
         * |Name  |Type   |Desc                          |
         * |------|-------|------------------------------|
         * |val   |*      |value to check                |
         * |return|boolean|True if value is a Date object|
         */

        /* example
         * isDate(new Date()); // -> true
         */

        /* typescript
         * export declare function isDate(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object Date]';
        };

        return exports;
    })({});

    /* ------------------------------ isFn ------------------------------ */

    var isFn = _.isFn = (function (exports) {
        /* Check if value is a function.
         *
         * |Name  |Type   |Desc                       |
         * |------|-------|---------------------------|
         * |val   |*      |Value to check             |
         * |return|boolean|True if value is a function|
         *
         * Generator function is also classified as true.
         */

        /* example
         * isFn(function() {}); // -> true
         * isFn(function*() {}); // -> true
         */

        /* typescript
         * export declare function isFn(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            var objStr = objToStr(val);
            return (
                objStr === '[object Function]' ||
                objStr === '[object GeneratorFunction]'
            );
        };

        return exports;
    })({});

    /* ------------------------------ isMiniProgram ------------------------------ */

    var isMiniProgram = _.isMiniProgram = (function (exports) {
        /* Check if running in wechat mini program.
         */

        /* example
         * console.log(isMiniProgram); // -> true if running in mini program.
         */

        /* typescript
         * export declare const isMiniProgram: boolean;
         */

        /* dependencies
         * isFn 
         */
        /* eslint-disable no-undef */

        exports = typeof wx !== 'undefined' && isFn(wx.openLocation);

        return exports;
    })({});

    /* ------------------------------ isNum ------------------------------ */

    var isNum = _.isNum = (function (exports) {
        /* Check if value is classified as a Number primitive or object.
         *
         * |Name  |Type   |Desc                                 |
         * |------|-------|-------------------------------------|
         * |val   |*      |Value to check                       |
         * |return|boolean|True if value is correctly classified|
         */

        /* example
         * isNum(5); // -> true
         * isNum(5.1); // -> true
         * isNum({}); // -> false
         */

        /* typescript
         * export declare function isNum(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object Number]';
        };

        return exports;
    })({});

    /* ------------------------------ isArrLike ------------------------------ */

    var isArrLike = _.isArrLike = (function (exports) {
        /* Check if value is array-like.
         *
         * |Name  |Type   |Desc                       |
         * |------|-------|---------------------------|
         * |val   |*      |Value to check             |
         * |return|boolean|True if value is array like|
         *
         * Function returns false.
         */

        /* example
         * isArrLike('test'); // -> true
         * isArrLike(document.body.children); // -> true;
         * isArrLike([1, 2, 3]); // -> true
         */

        /* typescript
         * export declare function isArrLike(val: any): boolean;
         */

        /* dependencies
         * isNum isFn 
         */

        var MAX_ARR_IDX = Math.pow(2, 53) - 1;

        exports = function exports(val) {
            if (!val) return false;
            var len = val.length;
            return isNum(len) && len >= 0 && len <= MAX_ARR_IDX && !isFn(val);
        };

        return exports;
    })({});

    /* ------------------------------ each ------------------------------ */

    var each = _.each = (function (exports) {
        /* Iterate over elements of collection and invokes iterator for each element.
         *
         * |Name    |Type        |Desc                          |
         * |--------|------------|------------------------------|
         * |obj     |object array|Collection to iterate over    |
         * |iterator|function    |Function invoked per iteration|
         * |[ctx]   |*           |Function context              |
         */

        /* example
         * each({'a': 1, 'b': 2}, function (val, key) {});
         */

        /* typescript
         * export declare function each<T>(
         *     list: types.List<T>,
         *     iterator: types.ListIterator<T, void>,
         *     ctx?: any
         * ): types.List<T>;
         * export declare function each<T>(
         *     object: types.Dictionary<T>,
         *     iterator: types.ObjectIterator<T, void>,
         *     ctx?: any
         * ): types.Collection<T>;
         */

        /* dependencies
         * isArrLike keys optimizeCb types 
         */

        exports = function exports(obj, iterator, ctx) {
            iterator = optimizeCb(iterator, ctx);
            var i, len;

            if (isArrLike(obj)) {
                for (i = 0, len = obj.length; i < len; i++) {
                    iterator(obj[i], i, obj);
                }
            } else {
                var _keys = keys(obj);

                for (i = 0, len = _keys.length; i < len; i++) {
                    iterator(obj[_keys[i]], _keys[i], obj);
                }
            }

            return obj;
        };

        return exports;
    })({});

    /* ------------------------------ createAssigner ------------------------------ */

    var createAssigner = _.createAssigner = (function (exports) {
        /* Used to create extend, extendOwn and defaults.
         *
         * |Name    |Type    |Desc                          |
         * |--------|--------|------------------------------|
         * |keysFn  |function|Function to get object keys   |
         * |defaults|boolean |No override when set to true  |
         * |return  |function|Result function, extend...    |
         */

        /* typescript
         * export declare function createAssigner(keysFn: Function, defaults: boolean): Function;
         */

        /* dependencies
         * isUndef each 
         */

        exports = function exports(keysFn, defaults) {
            return function(obj) {
                each(arguments, function(src, idx) {
                    if (idx === 0) return;
                    var keys = keysFn(src);
                    each(keys, function(key) {
                        if (!defaults || isUndef(obj[key])) obj[key] = src[key];
                    });
                });
                return obj;
            };
        };

        return exports;
    })({});

    /* ------------------------------ defaults ------------------------------ */

    var defaults = _.defaults = (function (exports) {
        /* Fill in undefined properties in object with the first value present in the following list of defaults objects.
         *
         * |Name  |Type  |Desc              |
         * |------|------|------------------|
         * |obj   |object|Destination object|
         * |*src  |object|Sources objects   |
         * |return|object|Destination object|
         */

        /* example
         * defaults({name: 'RedHood'}, {name: 'Unknown', age: 24}); // -> {name: 'RedHood', age: 24}
         */

        /* typescript
         * export declare function defaults(obj: any, ...src: any[]): any;
         */

        /* dependencies
         * createAssigner allKeys 
         */

        exports = createAssigner(allKeys, true);

        return exports;
    })({});

    /* ------------------------------ extend ------------------------------ */

    var extend = _.extend = (function (exports) {
        /* Copy all of the properties in the source objects over to the destination object.
         *
         * |Name       |Type  |Desc              |
         * |-----------|------|------------------|
         * |destination|object|Destination object|
         * |...sources |object|Sources objects   |
         * |return     |object|Destination object|
         */

        /* example
         * extend({name: 'RedHood'}, {age: 24}); // -> {name: 'RedHood', age: 24}
         */

        /* typescript
         * export declare function extend(destination: any, ...sources: any[]): any;
         */

        /* dependencies
         * createAssigner allKeys 
         */

        exports = createAssigner(allKeys);

        return exports;
    })({});

    /* ------------------------------ extendOwn ------------------------------ */

    var extendOwn = _.extendOwn = (function (exports) {
        /* Like extend, but only copies own properties over to the destination object.
         *
         * |Name       |Type  |Desc              |
         * |-----------|------|------------------|
         * |destination|object|Destination object|
         * |...sources |object|Sources objects   |
         * |return     |object|Destination object|
         */

        /* example
         * extendOwn({name: 'RedHood'}, {age: 24}); // -> {name: 'RedHood', age: 24}
         */

        /* typescript
         * export declare function extendOwn(destination: any, ...sources: any[]): any;
         */

        /* dependencies
         * keys createAssigner 
         */

        exports = createAssigner(keys);

        return exports;
    })({});

    /* ------------------------------ easing ------------------------------ */

    _.easing = (function (exports) {
        /* Easing functions adapted from http://jqueryui.com/ .
         *
         * |Name   |Type  |Desc                  |
         * |-------|------|----------------------|
         * |percent|number|Number between 0 and 1|
         * |return |number|Calculated number     |
         */

        /* example
         * easing.linear(0.5); // -> 0.5
         * easing.inElastic(0.5, 500); // -> 0.03125
         */

        /* typescript
         * export declare const easing: {
         *     linear(percent: number): number;
         *     inQuad(percent: number): number;
         *     outQuad(percent: number): number;
         *     inOutQuad(percent: number): number;
         *     outInQuad(percent: number): number;
         *     inCubic(percent: number): number;
         *     outCubic(percent: number): number;
         *     inQuart(percent: number): number;
         *     outQuart(percent: number): number;
         *     inQuint(percent: number): number;
         *     outQuint(percent: number): number;
         *     inExpo(percent: number): number;
         *     outExpo(percent: number): number;
         *     inSine(percent: number): number;
         *     outSine(percent: number): number;
         *     inCirc(percent: number): number;
         *     outCirc(percent: number): number;
         *     inElastic(percent: number, elasticity?: number): number;
         *     outElastic(percent: number, elasticity?: number): number;
         *     inBack(percent: number): number;
         *     outBack(percent: number): number;
         *     inOutBack(percent: number): number;
         *     outInBack(percent: number): number;
         *     inBounce(percent: number): number;
         *     outBounce(percent: number): number;
         * };
         */

        /* dependencies
         * each upperFirst 
         */

        exports.linear = function(t) {
            return t;
        };

        var pow = Math.pow,
            sqrt = Math.sqrt,
            sin = Math.sin,
            min = Math.min,
            asin = Math.asin,
            PI = Math.PI;
        var fns = {
            sine: function sine(t) {
                return 1 + sin((PI / 2) * t - PI / 2);
            },
            circ: function circ(t) {
                return 1 - sqrt(1 - t * t);
            },
            elastic: function elastic(t, m) {
                m = m || DEFAULT_ELASTICITY;
                if (t === 0 || t === 1) return t;
                var p = 1 - min(m, 998) / 1000,
                    st = t / 1,
                    st1 = st - 1,
                    s = (p / (2 * PI)) * asin(1);
                return -(pow(2, 10 * st1) * sin(((st1 - s) * (2 * PI)) / p));
            },
            back: function back(t) {
                return t * t * (3 * t - 2);
            },
            bounce: function bounce(t) {
                var pow2,
                    bounce = 4;
                /* eslint-disable no-empty */

                while (t < ((pow2 = pow(2, --bounce)) - 1) / 11) {}

                return (
                    1 / pow(4, 3 - bounce) - 7.5625 * pow((pow2 * 3 - 2) / 22 - t, 2)
                );
            }
        };
        each(['quad', 'cubic', 'quart', 'quint', 'expo'], function(name, i) {
            fns[name] = function(t) {
                return pow(t, i + 2);
            };
        });
        var DEFAULT_ELASTICITY = 400;
        each(fns, function(fn, name) {
            name = upperFirst(name);
            exports['in' + name] = fn;

            exports['out' + name] = function(t, m) {
                return 1 - fn(1 - t, m);
            };

            exports['inOut' + name] = function(t, m) {
                return t < 0.5 ? fn(t * 2, m) / 2 : 1 - fn(t * -2 + 2, m) / 2;
            };

            exports['outIn' + name] = function(t, m) {
                return t < 0.5
                    ? (1 - fn(1 - 2 * t, m)) / 2
                    : (fn(t * 2 - 1, m) + 1) / 2;
            };
        });

        return exports;
    })({});

    /* ------------------------------ invert ------------------------------ */

    var invert = _.invert = (function (exports) {
        /* Create an object composed of the inverted keys and values of object.
         *
         * |Name  |Type  |Desc               |
         * |------|------|-------------------|
         * |obj   |object|Object to invert   |
         * |return|object|New inverted object|
         *
         * If object contains duplicate values, subsequent values overwrite property assignments of previous values.
         */

        /* example
         * invert({a: 'b', c: 'd', e: 'f'}); // -> {b: 'a', d: 'c', f: 'e'}
         */

        /* typescript
         * export declare function invert(obj: any): any;
         */

        /* dependencies
         * each 
         */

        exports = function exports(obj) {
            var ret = {};
            each(obj, function(val, key) {
                ret[val] = key;
            });
            return ret;
        };

        return exports;
    })({});

    /* ------------------------------ isStr ------------------------------ */

    var isStr = _.isStr = (function (exports) {
        /* Check if value is a string primitive.
         *
         * |Name  |Type   |Desc                               |
         * |------|-------|-----------------------------------|
         * |val   |*      |Value to check                     |
         * |return|boolean|True if value is a string primitive|
         */

        /* example
         * isStr('licia'); // -> true
         */

        /* typescript
         * export declare function isStr(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object String]';
        };

        return exports;
    })({});

    /* ------------------------------ isAreaCode ------------------------------ */

    var isAreaCode = _.isAreaCode = (function (exports) {
        /* Check if it's a cell areacode number
         *
         * |Name       |Type   |Desc                  |
         * |-----------|-------|----------------------|
         * |areacode   |*      |areacode to check     |
         * |return     |boolean|True if value is empty|
         */

        /* example
         * isAreaCode('88'); // -> true
         * isAreaCode('aa'); // -> false
         */

        exports = function exports(areacode) {
            if (areacode == null || areacode == '' || !(/^[0-9]\d*$/.test(areacode))){
                return false;
            }
            return true;

        };

        return exports;
    })({});


    /* ------------------------------ isMobilePhone ------------------------------ */

    var isMobilePhone = _.isMobilePhone = (function (exports) {
        /* Check if it's a cell phone number
         *
         * |Name       |Type   |Desc                  |
         * |-----------|-------|----------------------|
         * |areacode   |*      |areacode to check     |
         * |phone      |*      |phone to check        |
         * |return     |boolean|True if value is empty|
         */

        /* example
         * isMobilePhone('88','1234567'); // -> true
         * isMobilePhone('86','234'); // -> false
         */

        exports = function exports(areacode = '86',phone) {
            if (areacode == null || areacode == '') areacode = '86';

            if (areacode == '86') {
                if(!(/^1[123456789]{1}\d{9}$/.test(phone))){
                    return false;
                }
                return true;
            }else if (areacode != '86') {
                if(!(/^[0-9]\d*$/.test(phone))){
                    return false;
                }
                return true;
            }

        };

        return exports;
    })({});

    /* ------------------------------ isSeccode ------------------------------ */

    var isSeccode = _.isSeccode = (function (exports) {
        /* Check if it's a seccode number
         *
         * |Name       |Type   |Desc                  |
         * |-----------|-------|----------------------|
         * |seccode    |*      |seccode  to check     |
         * |return     |boolean|True if value is empty|
         */

        /* example
         * isSeccode('123456'); // -> true
         * isSeccode('abdcef'); // -> false
         */

        exports = function exports(seccode) {
            if (seccode == null || seccode == '' || !(/^[0-9]\d*$/.test(seccode))){
                return false;
            }
            return true;

        };

        return exports;
    })({});

    /* ------------------------------ isEmpty ------------------------------ */

    var isEmpty = _.isEmpty = (function (exports) {
        /* Check if value is an empty object or array.
         *
         * |Name  |Type   |Desc                  |
         * |------|-------|----------------------|
         * |val   |*      |Value to check        |
         * |return|boolean|True if value is empty|
         */

        /* example
         * isEmpty([]); // -> true
         * isEmpty({}); // -> true
         * isEmpty(''); // -> true
         */

        /* typescript
         * export declare function isEmpty(val: any): boolean;
         */

        /* dependencies
         * isArrLike isArr isStr isArgs keys 
         */

        exports = function exports(val) {
            if (val == null) return true;

            if (isArrLike(val) && (isArr(val) || isStr(val) || isArgs(val))) {
                return val.length === 0;
            }

            return keys(val).length === 0;
        };

        return exports;
    })({});

    /* ------------------------------ toBool ------------------------------ */

    var toBool = _.toBool = (function (exports) {
        /* Convert value to a boolean.
         *
         * |Name  |Type   |Desc             |
         * |------|-------|-----------------|
         * |val   |*      |Value to convert |
         * |return|boolean|Converted boolean|
         */

        /* example
         * toBool(true); // -> true
         * toBool(null); // -> false
         * toBool(1); // -> true
         * toBool(0); // -> false
         * toBool('0'); // -> false
         * toBool('1'); // -> true
         * toBool('false'); // -> false
         */

        /* typescript
         * export declare function toBool(val: any): boolean;
         */

        /* dependencies
         * isStr 
         */

        exports = function exports(val) {
            if (isStr(val)) {
                val = val.toLowerCase();
                return val !== '0' && val !== '' && val !== 'false';
            }

            return !!val;
        };

        return exports;
    })({});

    /* ------------------------------ toNum ------------------------------ */

    var toNum = _.toNum = (function (exports) {
        /* Convert value to a number.
         *
         * |Name  |Type  |Desc            |
         * |------|------|----------------|
         * |val   |*     |Value to process|
         * |return|number|Resulted number |
         */

        /* example
         * toNum('5'); // -> 5
         */

        /* typescript
         * export declare function toNum(val: any): number;
         */

        /* dependencies
         * isNum isObj isFn isStr 
         */

        exports = function exports(val) {
            if (isNum(val)) return val;

            if (isObj(val)) {
                var temp = isFn(val.valueOf) ? val.valueOf() : val;
                val = isObj(temp) ? temp + '' : temp;
            }

            if (!isStr(val)) return val === 0 ? val : +val;
            return +val;
        };

        return exports;
    })({});

    /* ------------------------------ toInt ------------------------------ */

    var toInt = _.toInt = (function (exports) {
        /* Convert value to an integer.
         *
         * |Name  |Type  |Desc             |
         * |------|------|-----------------|
         * |val   |*     |Value to convert |
         * |return|number|Converted integer|
         */

        /* example
         * toInt(1.1); // -> 1
         * toInt(undefined); // -> 0
         */

        /* typescript
         * export declare function toInt(val: any): number;
         */

        /* dependencies
         * toNum 
         */

        exports = function exports(val) {
            if (!val) return val === 0 ? val : 0;
            val = toNum(val);
            return val - (val % 1);
        };

        return exports;
    })({});

    /* ------------------------------ format ------------------------------ */

    _.format = (function (exports) {
        /* Format string in a printf-like format.
         *
         * |Name     |Type  |Desc                               |
         * |---------|------|-----------------------------------|
         * |str      |string|String to format                   |
         * |...values|*     |Values to replace format specifiers|
         * |return   |string|Formatted string                   |
         *
         * ### Format Specifiers
         *
         * |Specifier|Desc                |
         * |---------|--------------------|
         * |%s       |String              |
         * |%d, %i   |Integer             |
         * |%f       |Floating point value|
         * |%o       |Object              |
         */

        /* example
         * format('%s_%s', 'foo', 'bar'); // -> 'foo bar'
         */

        /* typescript
         * export declare function format(str: string, ...values: any[]): string;
         */

        /* dependencies
         * restArgs toInt toNum toStr 
         */

        exports = restArgs(function(str, values) {
            var ret = '';

            for (var i = 0, len = str.length; i < len; i++) {
                var c = str[i];

                if (c !== '%' || values.length === 0) {
                    ret += c;
                    continue;
                }

                i++;
                var val = values.shift();

                switch (str[i]) {
                    case 'i':
                    case 'd':
                        ret += toInt(val);
                        break;

                    case 'f':
                        ret += toNum(val);
                        break;

                    case 's':
                        ret += toStr(val);
                        break;

                    case 'o':
                        ret += tryStringify(val);
                        break;

                    default:
                        i--;
                        values.unshift(val);
                        ret += c;
                }
            }

            return ret;
        });

        function tryStringify(obj) {
            try {
                return JSON.stringify(obj);
            } catch (err) {
                return '[Error Stringify]';
            }
        }

        return exports;
    })({});

    /* ------------------------------ isArrBuffer ------------------------------ */

    _.isArrBuffer = (function (exports) {
        /* Check if value is an ArrayBuffer.
         *
         * |Name  |Type   |Desc                           |
         * |------|-------|-------------------------------|
         * |val   |*      |Value to check                 |
         * |return|boolean|True if value is an ArrayBuffer|
         */

        /* example
         * isArrBuffer(new ArrayBuffer(8)); // -> true
         */

        /* typescript
         * export declare function isArrBuffer(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object ArrayBuffer]';
        };

        return exports;
    })({});

    /* ------------------------------ isBlob ------------------------------ */

    _.isBlob = (function (exports) {
        /* Check if value is a Blob.
         *
         * |Name  |Type   |Desc                   |
         * |------|-------|-----------------------|
         * |val   |*      |Value to check         |
         * |return|boolean|True if value is a Blob|
         */

        /* example
         * isBlob(new Blob([])); // -> true;
         * isBlob([]); // -> false
         */

        /* typescript
         * export declare function isBlob(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object Blob]';
        };

        return exports;
    })({});

    /* ------------------------------ isBool ------------------------------ */

    _.isBool = (function (exports) {
        /* Check if value is a boolean primitive.
         *
         * |Name  |Type   |Desc                      |
         * |------|-------|--------------------------|
         * |val   |*      |Value to check            |
         * |return|boolean|True if value is a boolean|
         */

        /* example
         * isBool(true); // -> true
         * isBool(false); // -> true
         * isBool(1); // -> false
         */

        /* typescript
         * export declare function isBool(val: any): boolean;
         */
        exports = function exports(val) {
            return val === true || val === false;
        };

        return exports;
    })({});

    /* ------------------------------ isBuffer ------------------------------ */

    _.isBuffer = (function (exports) {
        /* Check if value is a buffer.
         *
         * |Name  |Type   |Desc                     |
         * |------|-------|-------------------------|
         * |val   |*      |The value to check       |
         * |return|boolean|True if value is a buffer|
         */

        /* example
         * isBuffer(new Buffer(4)); // -> true
         */

        /* typescript
         * export declare function isBuffer(val: any): boolean;
         */

        /* dependencies
         * isFn 
         */

        exports = function(val) {
            if (val == null) return false;
            if (val._isBuffer) return true;

            return (
                val.constructor &&
                isFn(val.constructor.isBuffer) &&
                val.constructor.isBuffer(val)
            );
        };

        return exports;
    })({});

    /* ------------------------------ isClose ------------------------------ */

    _.isClose = (function (exports) {
        /* Check if values are close(almost equal) to each other.
         *
         * `abs(a-b) <= max(relTol * max(abs(a), abs(b)), absTol)`
         *
         * |Name       |Type   |Desc                    |
         * |-----------|-------|------------------------|
         * |a          |number |Number to compare       |
         * |b          |number |Number to compare       |
         * |relTol=1e-9|number |Relative tolerance      |
         * |absTol=0   |number |Absolute tolerance      |
         * |return     |boolean|True if values are close|
         */

        /* example
         * isClose(1, 1.0000000001); // -> true
         * isClose(1, 2); // -> false
         * isClose(1, 1.2, 0.3); // -> true
         * isClose(1, 1.2, 0.1, 0.3); // -> true
         */

        /* typescript
         * export declare function isClose(
         *     a: number,
         *     b: number,
         *     relTol?: number,
         *     absTol?: number
         * ): boolean;
         */

        /* dependencies
         * isNum 
         */

        exports = function exports(a, b, relTol, absTol) {
            if (!isNum(relTol)) relTol = 1e-9;
            if (!isNum(absTol)) absTol = 0;
            return abs(a - b) <= max(relTol * max(abs(a), abs(b)), absTol);
        };

        var abs = Math.abs,
            max = Math.max;

        return exports;
    })({});

    /* ------------------------------ isEl ------------------------------ */

    _.isEl = (function (exports) {
        /* Check if value is a DOM element.
         *
         * |Name  |Type   |Desc                          |
         * |------|-------|------------------------------|
         * |val   |*      |Value to check                |
         * |return|boolean|True if value is a DOM element|
         */

        /* example
         * isEl(document.body); // -> true
         */

        /* typescript
         * export declare function isEl(val: any): boolean;
         */
        exports = function exports(val) {
            return !!(val && val.nodeType === 1);
        };

        return exports;
    })({});

    /* ------------------------------ isEmail ------------------------------ */

    _.isEmail = (function (exports) {
        /* Loosely validate an email address.
         *
         * |Name  |Type   |Desc                                 |
         * |------|-------|-------------------------------------|
         * |val   |string |Value to check                       |
         * |return|boolean|True if value is an email like string|
         */

        /* example
         * isEmail('surunzi@foxmail.com'); // -> true
         */

        /* typescript
         * export declare function isEmail(val: string): boolean;
         */
        exports = function exports(val) {
            return regEmail.test(val);
        };

        var regEmail = /.+@.+\..+/;

        return exports;
    })({});

    /* ------------------------------ isEqual ------------------------------ */

    _.isEqual = (function (exports) {
        function _typeof(obj) {
            if (typeof Symbol === 'function' && typeof Symbol.iterator === 'symbol') {
                _typeof = function _typeof(obj) {
                    return typeof obj;
                };
            } else {
                _typeof = function _typeof(obj) {
                    return obj &&
                        typeof Symbol === 'function' &&
                        obj.constructor === Symbol &&
                        obj !== Symbol.prototype
                        ? 'symbol'
                        : typeof obj;
                };
            }
            return _typeof(obj);
        }

        /* Performs an optimized deep comparison between the two objects, to determine if they should be considered equal.
         *
         * |Name  |Type   |Desc                         |
         * |------|-------|-----------------------------|
         * |val   |*      |Value to compare             |
         * |other |*      |Other value to compare       |
         * |return|boolean|True if values are equivalent|
         */

        /* example
         * isEqual([1, 2, 3], [1, 2, 3]); // -> true
         */

        /* typescript
         * export declare function isEqual(val: any, other: any): boolean;
         */

        /* dependencies
         * isFn has keys 
         */

        exports = function exports(a, b) {
            return eq(a, b);
        };

        function deepEq(a, b, aStack, bStack) {
            var className = toString.call(a);
            if (className !== toString.call(b)) return false;

            switch (className) {
                case '[object RegExp]':
                case '[object String]':
                    return '' + a === '' + b;

                case '[object Number]':
                    if (+a !== +a) return +b !== +b;
                    return +a === 0 ? 1 / +a === 1 / b : +a === +b;

                case '[object Date]':
                case '[object Boolean]':
                    return +a === +b;
            }

            var areArrays = className === '[object Array]';

            if (!areArrays) {
                if (_typeof(a) != 'object' || _typeof(b) != 'object') return false;
                var aCtor = a.constructor,
                    bCtor = b.constructor;
                if (
                    aCtor !== bCtor &&
                    !(
                        isFn(aCtor) &&
                        aCtor instanceof aCtor &&
                        isFn(bCtor) &&
                        bCtor instanceof bCtor
                    ) &&
                    'constructor' in a &&
                    'constructor' in b
                )
                    return false;
            }

            aStack = aStack || [];
            bStack = bStack || [];
            var length = aStack.length;

            while (length--) {
                if (aStack[length] === a) return bStack[length] === b;
            }

            aStack.push(a);
            bStack.push(b);

            if (areArrays) {
                length = a.length;
                if (length !== b.length) return false;

                while (length--) {
                    if (!eq(a[length], b[length], aStack, bStack)) return false;
                }
            } else {
                var _keys = keys(a),
                    key;

                length = _keys.length;
                if (keys(b).length !== length) return false;

                while (length--) {
                    key = _keys[length];
                    if (!(has(b, key) && eq(a[key], b[key], aStack, bStack)))
                        return false;
                }
            }

            aStack.pop();
            bStack.pop();
            return true;
        }

        function eq(a, b, aStack, bStack) {
            if (a === b) return a !== 0 || 1 / a === 1 / b;
            if (a == null || b == null) return a === b;
            if (a !== a) return b !== b;

            var type = _typeof(a);

            if (type !== 'function' && type !== 'object' && _typeof(b) != 'object')
                return false;
            return deepEq(a, b, aStack, bStack);
        }

        return exports;
    })({});

    /* ------------------------------ isErr ------------------------------ */

    _.isErr = (function (exports) {
        /* Check if value is an error.
         *
         * |Name  |Type   |Desc                     |
         * |------|-------|-------------------------|
         * |val   |*      |Value to check           |
         * |return|boolean|True if value is an error|
         */

        /* example
         * isErr(new Error()); // -> true
         */

        /* typescript
         * export declare function isErr(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object Error]';
        };

        return exports;
    })({});

    /* ------------------------------ isInt ------------------------------ */

    var isInt = _.isInt = (function (exports) {
        /* Checks if value is classified as a Integer.
         *
         * |Name  |Type   |Desc                                 |
         * |------|-------|-------------------------------------|
         * |val   |*      |Value to check                       |
         * |return|boolean|True if value is correctly classified|
         */

        /* example
         * isInt(5); // -> true
         * isInt(5.1); // -> false
         * isInt({}); // -> false
         */

        /* typescript
         * export declare function isInt(val: any): boolean;
         */

        /* dependencies
         * isNum 
         */

        exports = function exports(val) {
            return isNum(val) && val % 1 === 0;
        };

        return exports;
    })({});

    /* ------------------------------ isEven ------------------------------ */

    _.isEven = (function (exports) {
        /* Check if number is even.
         *
         * |Name  |Type   |Desc                  |
         * |------|-------|----------------------|
         * |num   |number |Number to check       |
         * |return|boolean|True if number is even|
         */

        /* example
         * isEven(0); // -> true
         * isEven(1); // -> false
         * isEven(2); // -> true
         */

        /* typescript
         * export declare function isEven(num: number): boolean;
         */

        /* dependencies
         * isInt 
         */

        exports = function exports(num) {
            if (!isInt(num)) return false;
            return num % 2 === 0;
        };

        return exports;
    })({});

    /* ------------------------------ isFile ------------------------------ */

    _.isFile = (function (exports) {
        /* Check if value is a file.
         *
         * |Name  |Type   |Desc                   |
         * |------|-------|-----------------------|
         * |val   |*      |Value to check         |
         * |return|boolean|True if value is a file|
         */

        /* example
         * isFile(new File(['test'], "test.txt", {type: "text/plain"})); // -> true
         */

        /* typescript
         * export declare function isFile(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object File]';
        };

        return exports;
    })({});

    /* ------------------------------ isFinite ------------------------------ */

    var isFinite = _.isFinite = (function (exports) {
        /* Check if value is a finite primitive number.
         *
         * |Name  |Type   |Desc                            |
         * |------|-------|--------------------------------|
         * |val   |*      |Value to check                  |
         * |return|boolean|True if value is a finite number|
         */

        /* example
         * isFinite(3); // -> true
         * isFinite(Infinity); // -> false
         */

        /* typescript
         * export declare function isFinite(val: any): boolean;
         */

        /* dependencies
         * root 
         */

        var nativeIsFinite = root.isFinite,
            nativeIsNaN = root.isNaN;

        exports = function exports(val) {
            return nativeIsFinite(val) && !nativeIsNaN(parseFloat(val));
        };

        return exports;
    })({});

    /* ------------------------------ isGeneratorFn ------------------------------ */

    _.isGeneratorFn = (function (exports) {
        /* Check if value is a generator function.
         *
         * |Name  |Type   |Desc                                 |
         * |------|-------|-------------------------------------|
         * |val   |*      |Value to check                       |
         * |return|boolean|True if value is a generator function|
         */

        /* example
         * isGeneratorFn(function * () {}); // -> true;
         * isGeneratorFn(function () {}); // -> false;
         */

        /* typescript
         * export declare function isGeneratorFn(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object GeneratorFunction]';
        };

        return exports;
    })({});

    /* ------------------------------ isIp ------------------------------ */

    _.isIp = (function (exports) {
        /* Check if value is an IP address.
         *
         * |Name  |Type   |Desc                          |
         * |------|-------|------------------------------|
         * |str   |string |String to check               |
         * |return|boolean|True if value is an IP address|
         *
         * ### v4
         *
         * Check if value is an IPv4 address.
         *
         * ### v6
         *
         * Check if value is an IPv6 address.
         */

        /* example
         * isIp('192.168.191.1'); // -> true
         * isIp('1:2:3:4:5:6:7:8'); // -> true
         * isIp('test'); // -> false
         * isIp.v4('192.168.191.1'); // -> true
         * isIp.v6('1:2:3:4:5:6:7:8'); // -> true
         */

        /* typescript
         * export declare namespace isIp {
         *     function v4(str: string): boolean;
         *     function v6(str: string): boolean;
         * }
         * export declare function isIp(str: string): boolean;
         */
        exports = (function(_exports) {
            function exports(_x) {
                return _exports.apply(this, arguments);
            }

            exports.toString = function() {
                return _exports.toString();
            };

            return exports;
        })(function(str) {
            return exports.v4(str) || exports.v6(str);
        }); // https://github.com/sindresorhus/ip-regex

        var v4 =
            '(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)(?:\\.(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]\\d|\\d)){3}';
        var regV4 = new RegExp('^'.concat(v4, '$'));
        var v6seg = '[a-fA-F\\d]{1,4}';
        var v6 = [
            '(',
            '(?:'.concat(v6seg, ':){7}(?:').concat(v6seg, '|:)|'),
            '(?:'
                .concat(v6seg, ':){6}(?:')
                .concat(v4, '|:')
                .concat(v6seg, '|:)|'),
            '(?:'
                .concat(v6seg, ':){5}(?::')
                .concat(v4, '|(:')
                .concat(v6seg, '){1,2}|:)|'),
            '(?:'
                .concat(v6seg, ':){4}(?:(:')
                .concat(v6seg, '){0,1}:')
                .concat(v4, '|(:')
                .concat(v6seg, '){1,3}|:)|'),
            '(?:'
                .concat(v6seg, ':){3}(?:(:')
                .concat(v6seg, '){0,2}:')
                .concat(v4, '|(:')
                .concat(v6seg, '){1,4}|:)|'),
            '(?:'
                .concat(v6seg, ':){2}(?:(:')
                .concat(v6seg, '){0,3}:')
                .concat(v4, '|(:')
                .concat(v6seg, '){1,5}|:)|'),
            '(?:'
                .concat(v6seg, ':){1}(?:(:')
                .concat(v6seg, '){0,4}:')
                .concat(v4, '|(:')
                .concat(v6seg, '){1,6}|:)|'),
            '(?::((?::'
                .concat(v6seg, '){0,5}:')
                .concat(v4, '|(?::')
                .concat(v6seg, '){1,7}|:))'),
            ')(%[0-9a-zA-Z]{1,})?'
        ].join('');
        var regV6 = new RegExp('^'.concat(v6, '$'));

        exports.v4 = function(str) {
            return regV4.test(str);
        };

        exports.v6 = function(str) {
            return regV6.test(str);
        };

        return exports;
    })({});

    /* ------------------------------ isJson ------------------------------ */

    _.isJson = (function (exports) {
        /* Check if value is a valid JSON.
         *
         * It uses `JSON.parse()` and a `try... catch` block.
         *
         * |Name  |Type   |Desc                         |
         * |------|-------|-----------------------------|
         * |val   |string |JSON string                  |
         * |return|boolean|True if value is a valid JSON|
         */

        /* example
         * isJson('{"a": 5}'); // -> true
         * isJson("{'a': 5}"); // -> false
         */

        /* typescript
         * export declare function isJson(val: string): boolean;
         */
        exports = function exports(val) {
            try {
                JSON.parse(val);
                return true;
            } catch (e) {
                return false;
            }
        };

        return exports;
    })({});

    /* ------------------------------ isLeapYear ------------------------------ */

    _.isLeapYear = (function (exports) {
        /* Check if a year is a leap year.
         *
         * |Name  |Type   |Desc                       |
         * |------|-------|---------------------------|
         * |year  |number |Year to check              |
         * |return|boolean|True if year is a leap year|
         */

        /* example
         * isLeapYear(2000); // -> true
         * isLeapYear(2002); // -> false
         */

        /* typescript
         * export declare function isLeapYear(year: number): boolean;
         */
        exports = function exports(year) {
            return year % 400 === 0 || (year % 4 === 0 && year % 100 !== 0);
        };

        return exports;
    })({});

    /* ------------------------------ isMap ------------------------------ */

    _.isMap = (function (exports) {
        /* Check if value is a Map object.
         *
         * |Name  |Type   |Desc                  |
         * |------|-------|----------------------|
         * |val   |*      |Value to check        |
         * |return|boolean|True if value is a Map|
         */

        /* example
         * isMap(new Map()); // -> true
         * isMap(new WeakMap()); // -> false
         */

        /* typescript
         * export declare function isMap(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object Map]';
        };

        return exports;
    })({});

    /* ------------------------------ isMatch ------------------------------ */

    var isMatch = _.isMatch = (function (exports) {
        /* Check if keys and values in src are contained in obj.
         *
         * |Name  |Type   |Desc                              |
         * |------|-------|----------------------------------|
         * |obj   |object |Object to inspect                 |
         * |src   |object |Object of property values to match|
         * |return|boolean|True if object is match           |
         */

        /* example
         * isMatch({a: 1, b: 2}, {a: 1}); // -> true
         */

        /* typescript
         * export declare function isMatch(obj: any, src: any): boolean;
         */

        /* dependencies
         * keys 
         */

        exports = function exports(obj, src) {
            var _keys = keys(src),
                len = _keys.length;

            if (obj == null) return !len;
            obj = Object(obj);

            for (var i = 0; i < len; i++) {
                var key = _keys[i];
                if (src[key] !== obj[key] || !(key in obj)) return false;
            }

            return true;
        };

        return exports;
    })({});

    /* ------------------------------ memoize ------------------------------ */

    var memoize = _.memoize = (function (exports) {
        /* Memoize a given function by caching the computed result.
         *
         * |Name    |Type    |Desc                                |
         * |--------|--------|------------------------------------|
         * |fn      |function|Function to have its output memoized|
         * |[hashFn]|function|Function to create cache key        |
         * |return  |function|New memoized function               |
         */

        /* example
         * var fibonacci = memoize(function(n) {
         *     return n < 2 ? n : fibonacci(n - 1) + fibonacci(n - 2);
         * });
         */

        /* typescript
         * export declare function memoize(fn: Function, hashFn?: Function): Function;
         */

        /* dependencies
         * has 
         */

        exports = function exports(fn, hashFn) {
            var memoize = function memoize(key) {
                var cache = memoize.cache,
                    address = '' + (hashFn ? hashFn.apply(this, arguments) : key);
                if (!has(cache, address)) cache[address] = fn.apply(this, arguments);
                return cache[address];
            };

            memoize.cache = {};
            return memoize;
        };

        return exports;
    })({});

    /* ------------------------------ isMobile ------------------------------ */

    _.isMobile = (function (exports) {
        /* Check whether client is using a mobile browser using ua.
         *
         * |Name                  |Type   |Desc                                 |
         * |----------------------|-------|-------------------------------------|
         * |ua=navigator.userAgent|string |User agent                           |
         * |return                |boolean|True if ua belongs to mobile browsers|
         */

        /* example
         * isMobile(navigator.userAgent);
         */

        /* typescript
         * export declare function isMobile(ua?: string): boolean;
         */

        /* dependencies
         * isBrowser memoize 
         */

        var regMobileAll = /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i,
            regMobileFour = /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw-(n|u)|c55\/|capi|ccwa|cdm-|cell|chtm|cldc|cmd-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc-s|devi|dica|dmob|do(c|p)o|ds(12|-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(-|_)|g1 u|g560|gene|gf-5|g-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd-(m|p|t)|hei-|hi(pt|ta)|hp( i|ip)|hs-c|ht(c(-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i-(20|go|ma)|i230|iac( |-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|-[a-w])|libw|lynx|m1-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|-([1-8]|c))|phil|pire|pl(ay|uc)|pn-2|po(ck|rt|se)|prox|psio|pt-g|qa-a|qc(07|12|21|32|60|-[2-7]|i-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h-|oo|p-)|sdk\/|se(c(-|0|1)|47|mc|nd|ri)|sgh-|shar|sie(-|m)|sk-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h-|v-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl-|tdg-|tel(i|m)|tim-|t-mo|to(pl|sh)|ts(70|m-|m3|m5)|tx-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas-|your|zeto|zte-/i;
        exports = memoize(function(ua) {
            ua = ua || (isBrowser ? navigator.userAgent : '');
            return regMobileAll.test(ua) || regMobileFour.test(ua.substr(0, 4));
        });

        return exports;
    })({});

    /* ------------------------------ isNaN ------------------------------ */

    var isNaN = _.isNaN = (function (exports) {
        /* Check if value is an NaN.
         *
         * |Name  |Type   |Desc                   |
         * |------|-------|-----------------------|
         * |val   |*      |Value to check         |
         * |return|boolean|True if value is an NaN|
         *
         * Undefined is not an NaN, different from global isNaN function.
         */

        /* example
         * isNaN(0); // -> false
         * isNaN(NaN); // -> true
         */

        /* typescript
         * export declare function isNaN(val: any): boolean;
         */

        /* dependencies
         * isNum 
         */

        exports = function exports(val) {
            return isNum(val) && val !== +val;
        };

        return exports;
    })({});

    /* ------------------------------ isNil ------------------------------ */

    var isNil = _.isNil = (function (exports) {
        /* Check if value is null or undefined, the same as value == null.
         *
         * |Name  |Type   |Desc                              |
         * |------|-------|----------------------------------|
         * |val   |*      |Value to check                    |
         * |return|boolean|True if value is null or undefined|
         */

        /* example
         * isNil(null); // -> true
         * isNil(void 0); // -> true
         * isNil(undefined); // -> true
         * isNil(false); // -> false
         * isNil(0); // -> false
         * isNil([]); // -> false
         */

        /* typescript
         * export declare function isNil(val: any): boolean;
         */
        exports = function exports(val) {
            return val == null;
        };

        return exports;
    })({});

    /* ------------------------------ toSrc ------------------------------ */

    var toSrc = _.toSrc = (function (exports) {
        /* Convert function to its source code.
         *
         * |Name  |Type    |Desc               |
         * |------|--------|-------------------|
         * |fn    |function|Function to convert|
         * |return|string  |Source code        |
         */

        /* example
         * toSrc(Math.min); // -> 'function min() { [native code] }'
         * toSrc(function () {}) // -> 'function () { }'
         */

        /* typescript
         * export declare function toSrc(fn: Function): string;
         */

        /* dependencies
         * isNil 
         */

        exports = function exports(fn) {
            if (isNil(fn)) return '';

            try {
                return fnToStr.call(fn);
                /* eslint-disable no-empty */
            } catch (e) {}

            try {
                return fn + '';
                /* eslint-disable no-empty */
            } catch (e) {}

            return '';
        };

        var fnToStr = Function.prototype.toString;

        return exports;
    })({});

    /* ------------------------------ isNative ------------------------------ */

    _.isNative = (function (exports) {
        /* Check if value is a native function.
         *
         * |Name  |Type   |Desc                              |
         * |------|-------|----------------------------------|
         * |val   |*      |Value to check                    |
         * |return|boolean|True if value is a native function|
         */

        /* example
         * isNative(function () {}); // -> false
         * isNative(Math.min); // -> true
         */

        /* typescript
         * export declare function isNative(val: any): boolean;
         */

        /* dependencies
         * isObj isFn toSrc 
         */

        exports = function exports(val) {
            if (!isObj(val)) return false;
            if (isFn(val)) return regIsNative.test(toSrc(val)); // Detect host constructors (Safari > 4; really typed array specific)

            return regIsHostCtor.test(toSrc(val));
        };

        var hasOwnProperty = Object.prototype.hasOwnProperty;
        var regIsNative = new RegExp(
            '^' +
                toSrc(hasOwnProperty)
                    .replace(/[\\^$.*+?()[\]{}|]/g, '\\$&')
                    .replace(
                        /hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,
                        '$1.*?'
                    ) +
                '$'
        );
        var regIsHostCtor = /^\[object .+?Constructor\]$/;

        return exports;
    })({});

    /* ------------------------------ isNode ------------------------------ */

    _.isNode = (function (exports) {
        /* Check if running in node.
         */

        /* example
         * console.log(isNode); // -> true if running in node
         */

        /* typescript
         * export declare const isNode: boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports =
            typeof process !== 'undefined' && objToStr(process) === '[object process]';

        return exports;
    })({});

    /* ------------------------------ isNull ------------------------------ */

    _.isNull = (function (exports) {
        /* Check if value is an Null.
         *
         * |Name  |Type   |Desc                    |
         * |------|-------|------------------------|
         * |val   |*      |Value to check          |
         * |return|boolean|True if value is an Null|
         */

        /* example
         * isNull(null); // -> true
         */

        /* typescript
         * export declare function isNull(val: any): boolean;
         */
        exports = function exports(val) {
            return val === null;
        };

        return exports;
    })({});

    /* ------------------------------ isNumeric ------------------------------ */

    _.isNumeric = (function (exports) {
        /* Check if value is numeric.
         *
         * |Name  |Type   |Desc                    |
         * |------|-------|------------------------|
         * |val   |*      |Value to check          |
         * |return|boolean|True if value is numeric|
         */

        /* example
         * isNumeric(1); // -> true
         * isNumeric('1'); // -> true
         * isNumeric(Number.MAX_VALUE); // -> true
         * isNumeric(0xFF); // -> true
         * isNumeric(''); // -> false
         * isNumeric('1.1.1'); // -> false
         * isNumeric(NaN); // -> false
         */

        /* typescript
         * export declare function isNumeric(val: any): boolean;
         */

        /* dependencies
         * isStr isNaN isFinite isArr 
         */

        exports = function exports(val) {
            if (isStr(val)) val = val.replace(regComma, '');
            return !isNaN(parseFloat(val)) && isFinite(val) && !isArr(val);
        };

        var regComma = /,/g;

        return exports;
    })({});

    /* ------------------------------ isOdd ------------------------------ */

    _.isOdd = (function (exports) {
        /* Check if number is odd.
         *
         * |Name  |Type   |Desc                 |
         * |------|-------|---------------------|
         * |num   |number |Number to check      |
         * |return|boolean|True if number is odd|
         */

        /* example
         * isOdd(0); // -> false
         * isOdd(1); // -> true
         * isOdd(2); // -> false
         */

        /* typescript
         * export declare function isOdd(num: number): boolean;
         */

        /* dependencies
         * isInt 
         */

        exports = function exports(num) {
            if (!isInt(num)) return false;
            return num % 2 !== 0;
        };

        return exports;
    })({});

    /* ------------------------------ isPlainObj ------------------------------ */

    _.isPlainObj = (function (exports) {
        /* Check if value is an object created by Object constructor.
         *
         * |Name  |Type   |Desc                           |
         * |------|-------|-------------------------------|
         * |val   |*      |Value to check                 |
         * |return|boolean|True if value is a plain object|
         */

        /* example
         * isPlainObj({}); // -> true
         * isPlainObj([]); // -> false
         * isPlainObj(function () {}); // -> false
         */

        /* typescript
         * export declare function isPlainObj(val: any): boolean;
         */

        /* dependencies
         * isObj isArr isFn has 
         */

        exports = function exports(val) {
            if (!isObj(val)) return false;
            var ctor = val.constructor;
            if (!isFn(ctor)) return false;
            if (!has(ctor.prototype, 'isPrototypeOf')) return false;
            return !isArr(val) && !isFn(val);
        };

        return exports;
    })({});

    /* ------------------------------ isPrime ------------------------------ */

    _.isPrime = (function (exports) {
        /* Check if the provided integer is a prime number.
         *
         * |Name  |Type   |Desc                            |
         * |------|-------|--------------------------------|
         * |num   |number |Number to check                 |
         * |return|boolean|True if number is a prime number|
         */

        /* example
         * isPrime(11); // -> true
         * isPrime(8); // -> false
         */

        /* typescript
         * export declare function isPrime(num: number): boolean;
         */
        exports = function exports(num) {
            var boundary = Math.floor(Math.sqrt(num));

            for (var i = 2; i <= boundary; i++) {
                if (num % i === 0) {
                    return false;
                }
            }

            return num >= 2;
        };

        return exports;
    })({});

    /* ------------------------------ isPrimitive ------------------------------ */

    _.isPrimitive = (function (exports) {
        function _typeof(obj) {
            if (typeof Symbol === 'function' && typeof Symbol.iterator === 'symbol') {
                _typeof = function _typeof(obj) {
                    return typeof obj;
                };
            } else {
                _typeof = function _typeof(obj) {
                    return obj &&
                        typeof Symbol === 'function' &&
                        obj.constructor === Symbol &&
                        obj !== Symbol.prototype
                        ? 'symbol'
                        : typeof obj;
                };
            }
            return _typeof(obj);
        }

        /* Check if value is string, number, boolean or null.
         *
         * |Name  |Type   |Desc                        |
         * |------|-------|----------------------------|
         * |val   |*      |Value to check              |
         * |return|boolean|True if value is a primitive|
         */

        /* example
         * isPrimitive(5); // -> true
         * isPrimitive('abc'); // -> true
         * isPrimitive(false); // -> true
         */

        /* typescript
         * export declare function isPrimitive(val: any): boolean;
         */
        exports = function exports(val) {
            var type = _typeof(val);

            return val == null || (type !== 'function' && type !== 'object');
        };

        return exports;
    })({});

    /* ------------------------------ isPromise ------------------------------ */

    _.isPromise = (function (exports) {
        /* Check if value looks like a promise.
         *
         * |Name  |Type   |Desc                              |
         * |------|-------|----------------------------------|
         * |val   |*      |Value to check                    |
         * |return|boolean|True if value looks like a promise|
         */

        /* example
         * isPromise(new Promise(function () {})); // -> true
         * isPromise({}); // -> false
         */

        /* typescript
         * export declare function isPromise(val: any): boolean;
         */

        /* dependencies
         * isObj isFn 
         */

        exports = function exports(val) {
            return isObj(val) && isFn(val.then);
        };

        return exports;
    })({});

    /* ------------------------------ isRegExp ------------------------------ */

    _.isRegExp = (function (exports) {
        /* Check if value is a regular expression.
         *
         * |Name  |Type   |Desc                                 |
         * |------|-------|-------------------------------------|
         * |val   |*      |Value to check                       |
         * |return|boolean|True if value is a regular expression|
         */

        /* example
         * isRegExp(/a/); // -> true
         */

        /* typescript
         * export declare function isRegExp(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object RegExp]';
        };

        return exports;
    })({});

    /* ------------------------------ isRelative ------------------------------ */

    _.isRelative = (function (exports) {
        /* Check if path appears to be relative.
         *
         * |Name  |Type   |Desc                               |
         * |------|-------|-----------------------------------|
         * |path  |string |Path to check                      |
         * |return|boolean|True if path appears to be relative|
         */

        /* example
         * isRelative('README.md'); // -> true
         */

        /* typescript
         * export declare function isRelative(path: string): boolean;
         */
        exports = function exports(path) {
            return !regAbsolute.test(path);
        };

        var regAbsolute = /^([a-z]+:)?[\\/]/i;

        return exports;
    })({});

    /* ------------------------------ isRetina ------------------------------ */

    _.isRetina = (function (exports) {
        /* Determine if running on a high DPR device or not.
         */

        /* example
         * console.log(isRetina); // -> true if high DPR
         */

        /* typescript
         * export declare const isRetina: boolean;
         */

        /* dependencies
         * isBrowser 
         */

        var mediaQuery =
            '(-webkit-min-device-pixel-ratio: 1.25), (min--moz-device-pixel-ratio: 1.25), (-o-min-device-pixel-ratio: 5/4), (min-resolution: 1.25dppx)';
        exports =
            isBrowser &&
            (window.devicePixelRatio > 1.25 ||
                (window.matchMedia && window.matchMedia(mediaQuery).matches));

        return exports;
    })({});

    /* ------------------------------ isSet ------------------------------ */

    _.isSet = (function (exports) {
        /* Check if value is a Set object.
         *
         * |Name  |Type   |Desc                  |
         * |------|-------|----------------------|
         * |val   |*      |Value to check        |
         * |return|boolean|True if value is a Set|
         */

        /* example
         * isSet(new Set()); // -> true
         * isSet(new WeakSet()); // -> false
         */

        /* typescript
         * export declare function isSet(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object Set]';
        };

        return exports;
    })({});

    /* ------------------------------ isSorted ------------------------------ */

    _.isSorted = (function (exports) {
        /* Check if an array is sorted.
         *
         * |Name  |Type    |Desc                   |
         * |------|--------|-----------------------|
         * |arr   |array   |Array to check         |
         * |[cmp] |function|Comparator             |
         * |return|boolean |True if array is sorted|
         */

        /* example
         * isSorted([1, 2, 3]); // -> true
         * isSorted([3, 2, 1]); // -> false
         */

        /* typescript
         * export declare function isSorted(arr: any[], cmp?: Function): boolean;
         */
        exports = function exports(arr, cmp) {
            cmp = cmp || comparator;

            for (var i = 0, len = arr.length; i < len - 1; i++) {
                if (cmp(arr[i], arr[i + 1]) > 0) return false;
            }

            return true;
        };

        function comparator(a, b) {
            return a - b;
        }

        return exports;
    })({});

    /* ------------------------------ isStream ------------------------------ */

    _.isStream = (function (exports) {
        /* Check if value is a Node.js stream.
         *
         * |Name  |Type   |Desc                             |
         * |------|-------|---------------------------------|
         * |val   |*      |Value to check                   |
         * |return|boolean|True if value is a Node.js stream|
         */

        /* example
         * var stream = require('stream');
         *
         * isStream(new stream.Stream()); // -> true
         */

        /* typescript
         * export declare function isStream(val: any): boolean;
         */

        /* dependencies
         * isObj isFn 
         */

        exports = function(val) {
            return val !== null && isObj(val) && isFn(val.pipe);
        };

        return exports;
    })({});

    /* ------------------------------ isTypedArr ------------------------------ */

    _.isTypedArr = (function (exports) {
        /* Check if value is a typed array.
         *
         * |Name  |Type   |Desc                          |
         * |------|-------|------------------------------|
         * |val   |*      |Value to check                |
         * |return|boolean|True if value is a typed array|
         */

        /* example
         * isTypedArr([]); // -> false
         * isTypedArr(new Uint8Array(8)); // -> true
         */

        /* typescript
         * export declare function isTypedArr(val: any): boolean;
         */

        /* dependencies
         * objToStr each 
         */

        exports = function exports(val) {
            return !!map[objToStr(val)];
        };

        var map = {};
        each(
            [
                'Int8Array',
                'Int16Array',
                'Int32Array',
                'Uint8Array',
                'Uint8ClampedArray',
                'Uint16Array',
                'Uint32Array',
                'Float32Array',
                'Float64Array'
            ],
            function(val) {
                map['[object ' + val + ']'] = true;
            }
        );

        return exports;
    })({});

    /* ------------------------------ isUrl ------------------------------ */

    _.isUrl = (function (exports) {
        /* Loosely validate an url.
         *
         * |Name  |Type   |Desc                               |
         * |------|-------|-----------------------------------|
         * |val   |string |Value to check                     |
         * |return|boolean|True if value is an url like string|
         */

        /* example
         * isUrl('http://www.example.com?foo=bar&param=test'); // -> true
         */

        /* typescript
         * export declare function isUrl(val: string): boolean;
         */
        exports = function exports(val) {
            return regUrl.test(val);
        };

        var regUrl = /^(?:\w+:)?\/\/([^\s.]+\.\S{2}|localhost[:?\d]*)\S*$/;

        return exports;
    })({});

    /* ------------------------------ isWeakMap ------------------------------ */

    _.isWeakMap = (function (exports) {
        /* Check if value is a WeakMap object.
         *
         * |Name  |Type   |Desc                      |
         * |------|-------|--------------------------|
         * |val   |*      |Value to check            |
         * |return|boolean|True if value is a WeakMap|
         */

        /* example
         * isWeakMap(new Map()); // -> false
         * isWeakMap(new WeakMap()); // -> true
         */

        /* typescript
         * export declare function isWeakMap(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object WeakMap]';
        };

        return exports;
    })({});

    /* ------------------------------ isWeakSet ------------------------------ */

    _.isWeakSet = (function (exports) {
        /* Check if value is a WeakSet object.
         *
         * |Name  |Type   |Desc                      |
         * |------|-------|--------------------------|
         * |val   |*      |Value to check            |
         * |return|boolean|True if value is a WeakSet|
         */

        /* example
         * isWeakSet(new Set()); // -> false
         * isWeakSet(new WeakSet()); // -> true
         */

        /* typescript
         * export declare function isWeakSet(val: any): boolean;
         */

        /* dependencies
         * objToStr 
         */

        exports = function exports(val) {
            return objToStr(val) === '[object WeakSet]';
        };

        return exports;
    })({});

    /* ------------------------------ isWindows ------------------------------ */

    _.isWindows = (function (exports) {
        /* Check if platform is windows.
         */

        /* example
         * console.log(isWindows); // -> true if running on windows
         */

        /* typescript
         * export declare const isWindows: boolean;
         */

        exports = false;

        if (typeof process !== 'undefined') {
            exports =
                process.platform === 'win32' ||
                process.env.OSTYPE === 'cygwin' ||
                process.env.OSTYPE === 'msys';
        }

        return exports;
    })({});

    /* ------------------------------ loadJs ------------------------------ */

    var loadJs = _.loadJs = (function (exports) {
        /* Inject script tag into page with given src value.
         *
         * |Name|Type    |Desc           |
         * |----|--------|---------------|
         * |src |string  |Script source  |
         * |cb  |function|Onload callback|
         */

        /* example
         * loadJs('main.js', function (isLoaded) {
         *     // Do something...
         * });
         */

        /* typescript
         * export declare function loadJs(src: string, cb?: Function): void;
         */
        exports = function exports(src, cb) {
            var script = document.createElement('script');
            script.src = src;

            script.onload = function() {
                var isNotLoaded =
                    script.readyState &&
                    script.readyState != 'complete' &&
                    script.readyState != 'loaded';
                cb && cb(!isNotLoaded);
            };

            document.body.appendChild(script);
        };

        return exports;
    })({});

    /* ------------------------------ uniqId ------------------------------ */

    var uniqId = _.uniqId = (function (exports) {
        /* Generate a globally-unique id.
         *
         * |Name    |Type  |Desc              |
         * |--------|------|------------------|
         * |[prefix]|string|Id prefix         |
         * |return  |string|Globally-unique id|
         */

        /* example
         * uniqId('eusita_'); // -> 'eustia_xxx'
         */

        /* typescript
         * export declare function uniqId(prefix?: string): string;
         */
        var idCounter = 0;

        exports = function exports(prefix) {
            var id = ++idCounter + '';
            return prefix ? prefix + id : id;
        };

        return exports;
    })({});

    /* ------------------------------ keyCode ------------------------------ */

    _.keyCode = (function (exports) {
        /* Key codes and key names conversion.
         *
         * Get key code's name.
         *
         * |Name  |Type  |Desc                  |
         * |------|------|----------------------|
         * |code  |number|Key code              |
         * |return|string|Corresponding key name|
         *
         * Get key name's code.
         *
         * |Name  |Type  |Desc                  |
         * |------|------|----------------------|
         * |name  |string|Key name              |
         * |return|number|Corresponding key code|
         */

        /* example
         * keyCode(13); // -> 'enter'
         * keyCode('enter'); // -> 13
         */

        /* typescript
         * export declare function keyCode(name: string): number;
         * export declare function keyCode(code: number): string;
         */

        /* dependencies
         * isStr invert 
         */

        exports = function exports(val) {
            if (isStr(val)) return codeMap[val];
            return nameMap[val];
        };

        var codeMap = {
            backspace: 8,
            tab: 9,
            enter: 13,
            shift: 16,
            ctrl: 17,
            alt: 18,
            'pause/break': 19,
            'caps lock': 20,
            esc: 27,
            space: 32,
            'page up': 33,
            'page down': 34,
            end: 35,
            home: 36,
            left: 37,
            up: 38,
            right: 39,
            down: 40,
            insert: 45,
            delete: 46,
            windows: 91,
            'right windows': 92,
            'windows menu': 93,
            'numpad *': 106,
            'numpad +': 107,
            'numpad -': 109,
            'numpad .': 110,
            'numpad /': 111,
            'num lock': 144,
            'scroll lock': 145,
            ';': 186,
            '=': 187,
            ',': 188,
            '-': 189,
            '.': 190,
            '/': 191,
            '`': 192,
            '[': 219,
            '\\': 220,
            ']': 221,
            "'": 222
        }; // Lower case chars

        for (var i = 97; i < 123; i++) {
            codeMap[String.fromCharCode(i)] = i - 32;
        } // Numbers

        for (i = 48; i < 58; i++) {
            codeMap[i - 48] = i;
        } // Function keys

        for (i = 1; i < 13; i++) {
            codeMap['f' + i] = i + 111;
        } // Numpad keys

        for (i = 0; i < 10; i++) {
            codeMap['numpad ' + i] = i + 96;
        }

        var nameMap = invert(codeMap);

        return exports;
    })({});

    /* ------------------------------ repeat ------------------------------ */

    var repeat = _.repeat = (function (exports) {
        /* Repeat string n-times.
         *
         * |Name  |Type  |Desc            |
         * |------|------|----------------|
         * |str   |string|String to repeat|
         * |n     |number|Repeat times    |
         * |return|string|Repeated string |
         */

        /* example
         * repeat('a', 3); // -> 'aaa'
         * repeat('ab', 2); // -> 'abab'
         * repeat('*', 0); // -> ''
         */

        /* typescript
         * export declare function repeat(str: string, n: number): string;
         */
        exports = function exports(str, n) {
            var ret = '';
            if (n < 1) return '';

            while (n > 0) {
                if (n & 1) ret += str;
                n >>= 1;
                str += str;
            }

            return ret;
        };

        return exports;
    })({});

    /* ------------------------------ lpad ------------------------------ */

    var lpad = _.lpad = (function (exports) {
        /* Pad string on the left side if it's shorter than length.
         *
         * |Name   |Type  |Desc                  |
         * |-------|------|----------------------|
         * |str    |string|String to pad         |
         * |len    |number|Padding length        |
         * |[chars]|string|String used as padding|
         * |return |string|Resulted string       |
         */

        /* example
         * lpad('a', 5); // -> '    a'
         * lpad('a', 5, '-'); // -> '----a'
         * lpad('abc', 3, '-'); // -> 'abc'
         * lpad('abc', 5, 'ab'); // -> 'ababc'
         */

        /* typescript
         * export declare function lpad(str: string, len: number, chars?: string): string;
         */

        /* dependencies
         * repeat toStr 
         */

        exports = function exports(str, len, chars) {
            str = toStr(str);
            var strLen = str.length;
            chars = chars || ' ';
            if (strLen < len) str = (repeat(chars, len - strLen) + str).slice(-len);
            return str;
        };

        return exports;
    })({});

    /* ------------------------------ dateFormat ------------------------------ */

    _.dateFormat = (function (exports) {
        /* Simple but extremely useful date format function.
         *
         * |Name         |Type   |Desc                 |
         * |-------------|-------|---------------------|
         * |date=new Date|Date   |Date object to format|
         * |mask         |string |Format mask          |
         * |utc=false    |boolean|UTC or not           |
         * |gmt=false    |boolean|GMT or not           |
         *
         * |Mask|Description                                                      |
         * |----|-----------------------------------------------------------------|
         * |d   |Day of the month as digits; no leading zero for single-digit days|
         * |dd  |Day of the month as digits; leading zero for single-digit days   |
         * |ddd |Day of the week as a three-letter abbreviation                   |
         * |dddd|Day of the week as its full name                                 |
         * |m   |Month as digits; no leading zero for single-digit months         |
         * |mm  |Month as digits; leading zero for single-digit months            |
         * |mmm |Month as a three-letter abbreviation                             |
         * |mmmm|Month as its full name                                           |
         * |yy  |Year as last two digits; leading zero for years less than 10     |
         * |yyyy|Year represented by four digits                                  |
         * |h   |Hours; no leading zero for single-digit hours (12-hour clock)    |
         * |hh  |Hours; leading zero for single-digit hours (12-hour clock)       |
         * |H   |Hours; no leading zero for single-digit hours (24-hour clock)    |
         * |HH  |Hours; leading zero for single-digit hours (24-hour clock)       |
         * |M   |Minutes; no leading zero for single-digit minutes                |
         * |MM  |Minutes; leading zero for single-digit minutes                   |
         * |s   |Seconds; no leading zero for single-digit seconds                |
         * |ss  |Seconds; leading zero for single-digit seconds                   |
         * |l L |Milliseconds. l gives 3 digits. L gives 2 digits                 |
         * |t   |Lowercase, single-character time marker string: a or p           |
         * |tt  |Lowercase, two-character time marker string: am or pm            |
         * |T   |Uppercase, single-character time marker string: A or P           |
         * |TT  |Uppercase, two-character time marker string: AM or PM            |
         * |Z   |US timezone abbreviation, e.g. EST or MDT                        |
         * |o   |GMT/UTC timezone offset, e.g. -0500 or +0230                     |
         * |S   |The date's ordinal suffix (st, nd, rd, or th)                    |
         * |UTC:|Must be the first four characters of the mask                    |
         */

        /* example
         * dateFormat('isoDate'); // -> 2016-11-19
         * dateFormat('yyyy-mm-dd HH:MM:ss'); // -> 2016-11-19 19:00:04
         * dateFormat(new Date(), 'yyyy-mm-dd'); // -> 2016-11-19
         */

        /* typescript
         * export declare function dateFormat(
         *     date: Date,
         *     mask: string,
         *     utc?: boolean,
         *     gmt?: boolean
         * ): string;
         * export declare function dateFormat(
         *     mask: string,
         *     utc?: boolean,
         *     gmt?: boolean
         * ): string;
         */

        /* dependencies
         * isStr isDate toStr lpad 
         */

        exports = (function(_exports) {
            function exports(_x, _x2, _x3, _x4) {
                return _exports.apply(this, arguments);
            }

            exports.toString = function() {
                return _exports.toString();
            };

            return exports;
        })(function(date, mask, utc, gmt) {
            if (arguments.length === 1 && isStr(date) && !regNum.test(date)) {
                mask = date;
                date = undefined;
            }

            date = date || new Date();
            if (!isDate(date)) date = new Date(date);
            mask = toStr(exports.masks[mask] || mask || exports.masks['default']);
            var maskSlice = mask.slice(0, 4);

            if (maskSlice === 'UTC:' || maskSlice === 'GMT:') {
                mask = mask.slice(4);
                utc = true;
                if (maskSlice === 'GMT:') gmt = true;
            }

            var prefix = utc ? 'getUTC' : 'get',
                d = date[prefix + 'Date'](),
                D = date[prefix + 'Day'](),
                m = date[prefix + 'Month'](),
                y = date[prefix + 'FullYear'](),
                H = date[prefix + 'Hours'](),
                M = date[prefix + 'Minutes'](),
                s = date[prefix + 'Seconds'](),
                L = date[prefix + 'Milliseconds'](),
                o = utc ? 0 : date.getTimezoneOffset(),
                flags = {
                    d: d,
                    dd: padZero(d),
                    ddd: exports.i18n.dayNames[D],
                    dddd: exports.i18n.dayNames[D + 7],
                    m: m + 1,
                    mm: padZero(m + 1),
                    mmm: exports.i18n.monthNames[m],
                    mmmm: exports.i18n.monthNames[m + 12],
                    yy: toStr(y).slice(2),
                    yyyy: y,
                    h: H % 12 || 12,
                    hh: padZero(H % 12 || 12),
                    H: H,
                    HH: padZero(H),
                    M: M,
                    MM: padZero(M),
                    s: s,
                    ss: padZero(s),
                    l: padZero(L, 3),
                    L: padZero(Math.round(L / 10)),
                    t: H < 12 ? 'a' : 'p',
                    tt: H < 12 ? 'am' : 'pm',
                    T: H < 12 ? 'A' : 'P',
                    TT: H < 12 ? 'AM' : 'PM',
                    Z: gmt
                        ? 'GMT'
                        : utc
                            ? 'UTC'
                            : (toStr(date).match(regTimezone) || [''])
                                  .pop()
                                  .replace(regTimezoneClip, ''),
                    o:
                        (o > 0 ? '-' : '+') +
                        padZero(
                            Math.floor(Math.abs(o) / 60) * 100 + (Math.abs(o) % 60),
                            4
                        ),
                    S: ['th', 'st', 'nd', 'rd'][
                        d % 10 > 3 ? 0 : (((d % 100) - (d % 10) != 10) * d) % 10
                    ]
                };
            return mask.replace(regToken, function(match) {
                if (match in flags) return flags[match];
                return match.slice(1, match.length - 1);
            });
        });

        function padZero(str, len) {
            return lpad(toStr(str), len || 2, '0');
        }

        var regToken = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZWN]|'[^']*'|'[^']*'/g,
            regTimezone = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,
            regNum = /\d/,
            regTimezoneClip = /[^-+\dA-Z]/g;
        exports.masks = {
            default: 'ddd mmm dd yyyy HH:MM:ss',
            shortDate: 'm/d/yy',
            mediumDate: 'mmm d, yyyy',
            longDate: 'mmmm d, yyyy',
            fullDate: 'dddd, mmmm d, yyyy',
            shortTime: 'h:MM TT',
            mediumTime: 'h:MM:ss TT',
            longTime: 'h:MM:ss TT Z',
            isoDate: 'yyyy-mm-dd',
            isoTime: 'HH:MM:ss',
            isoDateTime: "yyyy-mm-dd'T'HH:MM:sso",
            isoUtcDateTime: "UTC:yyyy-mm-dd'T'HH:MM:ss'Z'",
            expiresHeaderFormat: 'ddd, dd mmm yyyy HH:MM:ss Z'
        };
        exports.i18n = {
            dayNames: [
                'Sun',
                'Mon',
                'Tue',
                'Wed',
                'Thu',
                'Fri',
                'Sat',
                'Sunday',
                'Monday',
                'Tuesday',
                'Wednesday',
                'Thursday',
                'Friday',
                'Saturday'
            ],
            monthNames: [
                'Jan',
                'Feb',
                'Mar',
                'Apr',
                'May',
                'Jun',
                'Jul',
                'Aug',
                'Sep',
                'Oct',
                'Nov',
                'Dec',
                'January',
                'February',
                'March',
                'April',
                'May',
                'June',
                'July',
                'August',
                'September',
                'October',
                'November',
                'December'
            ]
        };

        return exports;
    })({});

    /* ------------------------------ ltrim ------------------------------ */

    var ltrim = _.ltrim = (function (exports) {
        /* Remove chars or white-spaces from beginning of string.
         *
         * |Name   |Type        |Desc              |
         * |-------|------------|------------------|
         * |str    |string      |String to trim    |
         * |[chars]|string array|Characters to trim|
         * |return |string      |Trimmed string    |
         */

        /* example
         * ltrim(' abc  '); // -> 'abc  '
         * ltrim('_abc_', '_'); // -> 'abc_'
         * ltrim('_abc_', ['a', '_']); // -> 'bc_'
         */

        /* typescript
         * export declare function ltrim(str: string, chars?: string | string[]): string;
         */
        var regSpace = /^\s+/;

        exports = function exports(str, chars) {
            if (chars == null) return str.replace(regSpace, '');
            var start = 0,
                len = str.length,
                charLen = chars.length,
                found = true,
                i,
                c;

            while (found && start < len) {
                found = false;
                i = -1;
                c = str.charAt(start);

                while (++i < charLen) {
                    if (c === chars[i]) {
                        found = true;
                        start++;
                        break;
                    }
                }
            }

            return start >= len ? '' : str.substr(start, len);
        };

        return exports;
    })({});

    /* ------------------------------ matcher ------------------------------ */

    var matcher = _.matcher = (function (exports) {
        /* Return a predicate function that checks if attrs are contained in an object.
         *
         * |Name  |Type    |Desc                              |
         * |------|--------|----------------------------------|
         * |attrs |object  |Object of property values to match|
         * |return|function|New predicate function            |
         */

        /* example
         * const objects = [
         *     {a: 1, b: 2, c: 3 },
         *     {a: 4, b: 5, c: 6 }
         * ];
         * // filter(objects, matcher({a: 4, c: 6 }));
         */

        /* typescript
         * export declare function matcher(attrs: any): Function;
         */

        /* dependencies
         * extendOwn isMatch 
         */

        exports = function exports(attrs) {
            attrs = extendOwn({}, attrs);
            return function(obj) {
                return isMatch(obj, attrs);
            };
        };

        return exports;
    })({});

    /* ------------------------------ safeCb ------------------------------ */

    var safeCb = _.safeCb = (function (exports) {
        /* Create callback based on input value.
         */

        /* typescript
         * export declare function safeCb(val?: any, ctx?: any, argCount?: number): Function;
         */

        /* dependencies
         * isFn isObj optimizeCb matcher identity 
         */

        exports = function exports(val, ctx, argCount) {
            if (val == null) return identity;
            if (isFn(val)) return optimizeCb(val, ctx, argCount);
            if (isObj(val)) return matcher(val);
            return function(key) {
                return function(obj) {
                    return obj == null ? undefined : obj[key];
                };
            };
        };

        return exports;
    })({});

    /* ------------------------------ filter ------------------------------ */

    var filter = _.filter = (function (exports) {
        /* Iterates over elements of collection, returning an array of all the values that pass a truth test.
         *
         * |Name     |Type    |Desc                                   |
         * |---------|--------|---------------------------------------|
         * |obj      |array   |Collection to iterate over             |
         * |predicate|function|Function invoked per iteration         |
         * |[ctx]    |*       |Predicate context                      |
         * |return   |array   |Array of all values that pass predicate|
         */

        /* example
         * filter([1, 2, 3, 4, 5], function (val) {
         *     return val % 2 === 0;
         * }); // -> [2, 4]
         */

        /* typescript
         * export declare function filter<T>(
         *     list: types.List<T>,
         *     iterator: types.ListIterator<T, boolean>,
         *     context?: any
         * ): T[];
         * export declare function filter<T>(
         *     object: types.Dictionary<T>,
         *     iterator: types.ObjectIterator<T, boolean>,
         *     context?: any
         * ): T[];
         */

        /* dependencies
         * safeCb each types 
         */

        exports = function exports(obj, predicate, ctx) {
            var ret = [];
            predicate = safeCb(predicate, ctx);
            each(obj, function(val, idx, list) {
                if (predicate(val, idx, list)) ret.push(val);
            });
            return ret;
        };

        return exports;
    })({});

    /* ------------------------------ unique ------------------------------ */

    var unique = _.unique = (function (exports) {
        /* Create duplicate-free version of an array.
         *
         * |Name     |Type    |Desc                         |
         * |---------|--------|-----------------------------|
         * |arr      |array   |Array to inspect             |
         * |[compare]|function|Function for comparing values|
         * |return   |array   |New duplicate free array     |
         */

        /* example
         * unique([1, 2, 3, 1]); // -> [1, 2, 3]
         */

        /* typescript
         * export declare function unique(
         *     arr: any[],
         *     compare?: (a: any, b: any) => boolean | number
         * ): any[];
         */

        /* dependencies
         * filter 
         */

        exports = function exports(arr, compare) {
            compare = compare || isEqual;
            return filter(arr, function(item, idx, arr) {
                var len = arr.length;

                while (++idx < len) {
                    if (compare(item, arr[idx])) return false;
                }

                return true;
            });
        };

        function isEqual(a, b) {
            return a === b;
        }

        return exports;
    })({});

    /* ------------------------------ map ------------------------------ */

    var map = _.map = (function (exports) {
        /* Create an array of values by running each element in collection through iteratee.
         *
         * |Name     |Type        |Desc                          |
         * |---------|------------|------------------------------|
         * |object   |array object|Collection to iterate over    |
         * |iterator |function    |Function invoked per iteration|
         * |[context]|*           |Function context              |
         * |return   |array       |New mapped array              |
         */

        /* example
         * map([4, 8], function (n) { return n * n; }); // -> [16, 64]
         */

        /* typescript
         * export declare function map<T, TResult>(
         *     list: types.List<T>,
         *     iterator: types.ListIterator<T, TResult>,
         *     context?: any
         * ): TResult[];
         * export declare function map<T, TResult>(
         *     object: types.Dictionary<T>,
         *     iterator: types.ObjectIterator<T, TResult>,
         *     context?: any
         * ): TResult[];
         */

        /* dependencies
         * safeCb keys isArrLike types 
         */

        exports = function exports(obj, iterator, ctx) {
            iterator = safeCb(iterator, ctx);

            var _keys = !isArrLike(obj) && keys(obj),
                len = (_keys || obj).length,
                results = Array(len);

            for (var i = 0; i < len; i++) {
                var curKey = _keys ? _keys[i] : i;
                results[i] = iterator(obj[curKey], curKey, obj);
            }

            return results;
        };

        return exports;
    })({});

    /* ------------------------------ decodeUriComponent ------------------------------ */

    var decodeUriComponent = _.decodeUriComponent = (function (exports) {
        /* Better decodeURIComponent that does not throw if input is invalid.
         *
         * |Name  |Type  |Desc            |
         * |------|------|----------------|
         * |str   |string|String to decode|
         * |return|string|Decoded string  |
         */

        /* example
         * decodeUriComponent('%%25%'); // -> '%%%'
         * decodeUriComponent('%E0%A4%A'); // -> '\xE0\xA4%A'
         */

        /* typescript
         * export declare function decodeUriComponent(str: string): string;
         */

        /* dependencies
         * each ucs2 map utf8 
         */

        exports = function exports(str) {
            try {
                return decodeURIComponent(str);
            } catch (e) {
                var matches = str.match(regMatcher);

                if (!matches) {
                    return str;
                }

                each(matches, function(match) {
                    str = str.replace(match, decode(match));
                });
                return str;
            }
        };

        function decode(str) {
            str = str.split('%').slice(1);
            var bytes = map(str, hexToInt);
            str = ucs2.encode(bytes);
            str = utf8.decode(str, true);
            return str;
        }

        function hexToInt(numStr) {
            return +('0x' + numStr);
        }

        var regMatcher = /(%[a-f0-9]{2})+/gi;

        return exports;
    })({});

    /* ------------------------------ cookie ------------------------------ */

    var cookie = _.cookie = (function (exports) {
        /* Simple api for handling browser cookies.
         *
         * ### get
         *
         * Get cookie value.
         *
         * |Name  |Type  |Desc                      |
         * |------|------|--------------------------|
         * |key   |string|Cookie key                |
         * |return|string|Corresponding cookie value|
         *
         * ### set
         *
         * Set cookie value.
         *
         * |Name     |Type   |Desc          |
         * |---------|-------|--------------|
         * |key      |string |Cookie key    |
         * |val      |string |Cookie value  |
         * |[options]|object |Cookie options|
         * |return   |exports|Module cookie |
         *
         * ### remove
         *
         * Remove cookie value.
         *
         * |Name     |Type   |Desc          |
         * |---------|-------|--------------|
         * |key      |string |Cookie key    |
         * |[options]|object |Cookie options|
         * |return   |exports|Module cookie |
         */

        /* example
         * cookie.set('a', '1', {path: '/'});
         * cookie.get('a'); // -> '1'
         * cookie.remove('a');
         */

        /* typescript
         * export declare namespace cookie {
         *     interface IOptions {
         *         path?: string;
         *         expires?: number;
         *         domain?: string;
         *         secure?: boolean;
         *     }
         *     interface ICookie {
         *         get(key: string, options?: cookie.IOptions): string;
         *         set(key: string, val: string, options?: cookie.IOptions): ICookie;
         *         remove(key: string, options?: cookie.IOptions): ICookie;
         *     }
         * }
         * export declare const cookie: cookie.ICookie;
         */

        /* dependencies
         * defaults isNum isUndef decodeUriComponent 
         */

        var defOpts = {
            path: '/'
        };

        function setCookie(key, val, options) {
            if (!isUndef(val)) {
                options = options || {};
                options = defaults(options, defOpts);

                if (isNum(options.expires)) {
                    var expires = new Date();
                    expires.setMilliseconds(
                        expires.getMilliseconds() + options.expires * 864e5
                    );
                    options.expires = expires;
                }

                val = encodeURIComponent(val);
                key = encodeURIComponent(key);
                document.cookie = [
                    key,
                    '=',
                    val,
                    options.expires && '; expires=' + options.expires.toUTCString(),
                    options.path && '; path=' + options.path,
                    options.domain && '; domain=' + options.domain,
                    options.secure ? '; secure' : ''
                ].join('');
                return exports;
            }

            var cookies = document.cookie ? document.cookie.split('; ') : [],
                result = key ? undefined : {};

            for (var i = 0, len = cookies.length; i < len; i++) {
                var c = cookies[i],
                    parts = c.split('='),
                    name = decodeUriComponent(parts.shift());
                c = parts.join('=');
                c = decodeUriComponent(c);

                if (key === name) {
                    result = c;
                    break;
                }

                if (!key) result[name] = c;
            }

            return result;
        }

        exports = {
            get: setCookie,
            set: setCookie,
            remove: function remove(key, options) {
                options = options || {};
                options.expires = -1;
                return setCookie(key, '', options);
            }
        };

        return exports;
    })({});

    /* ------------------------------ toArr ------------------------------ */

    var toArr = _.toArr = (function (exports) {
        /* Convert value to an array.
         *
         * |Name  |Type |Desc            |
         * |------|-----|----------------|
         * |val   |*    |Value to convert|
         * |return|array|Converted array |
         */

        /* example
         * toArr({a: 1, b: 2}); // -> [{a: 1, b: 2}]
         * toArr('abc'); // -> ['abc']
         * toArr(1); // -> [1]
         * toArr(null); // -> []
         */

        /* typescript
         * export declare function toArr(val: any): any[];
         */

        /* dependencies
         * isArrLike map isArr isStr 
         */

        exports = function exports(val) {
            if (!val) return [];
            if (isArr(val)) return val;
            if (isArrLike(val) && !isStr(val)) return map(val);
            return [val];
        };

        return exports;
    })({});

    /* ------------------------------ Class ------------------------------ */

    var Class = _.Class = (function (exports) {
        /* Create JavaScript class.
         *
         * |Name     |Type    |Desc                             |
         * |---------|--------|---------------------------------|
         * |methods  |object  |Public methods                   |
         * |[statics]|object  |Static methods                   |
         * |return   |function|Function used to create instances|
         */

        /* example
         * var People = Class({
         *     initialize: function People(name, age) {
         *         this.name = name;
         *         this.age = age;
         *     },
         *     introduce: function () {
         *         return 'I am ' + this.name + ', ' + this.age + ' years old.';
         *     }
         * });
         *
         * var Student = People.extend({
         *     initialize: function Student(name, age, school) {
         *         this.callSuper(People, 'initialize', arguments);
         *
         *         this.school = school;
         *     },
         *     introduce: function () {
         *         return this.callSuper(People, 'introduce') + '\n I study at ' + this.school + '.';
         *     }
         * }, {
         *     is: function (obj) {
         *         return obj instanceof Student;
         *     }
         * });
         *
         * var a = new Student('allen', 17, 'Hogwarts');
         * a.introduce(); // -> 'I am allen, 17 years old. \n I study at Hogwarts.'
         * Student.is(a); // -> true
         */

        /* typescript
         * export declare namespace Class {
         *     class Base {
         *         toString(): string;
         *     }
         *     class IConstructor extends Base {
         *         constructor(...args: any[]);
         *         static extend(methods: any, statics: any): IConstructor;
         *         static inherits(Class: Function): void;
         *         static methods(methods: any): IConstructor;
         *         static statics(statics: any): IConstructor;
         *         [method: string]: any;
         *     }
         * }
         * export declare function Class(methods: any, statics?: any): Class.IConstructor;
         */

        /* dependencies
         * extend toArr inherits safeGet isMiniProgram 
         */

        exports = function exports(methods, statics) {
            return Base.extend(methods, statics);
        };

        function makeClass(parent, methods, statics) {
            statics = statics || {};
            var className =
                methods.className || safeGet(methods, 'initialize.name') || '';
            delete methods.className;
            var ctor;

            if (isMiniProgram) {
                ctor = function ctor() {
                    var args = toArr(arguments);
                    return this.initialize
                        ? this.initialize.apply(this, args) || this
                        : this;
                };
            } else {
                ctor = new Function(
                    'toArr',
                    'return function ' +
                        className +
                        '()' +
                        '{' +
                        'var args = toArr(arguments);' +
                        'return this.initialize ? this.initialize.apply(this, args) || this : this;' +
                        '};'
                )(toArr);
            }

            inherits(ctor, parent);
            ctor.prototype.constructor = ctor;

            ctor.extend = function(methods, statics) {
                return makeClass(ctor, methods, statics);
            };

            ctor.inherits = function(Class) {
                inherits(ctor, Class);
            };

            ctor.methods = function(methods) {
                extend(ctor.prototype, methods);
                return ctor;
            };

            ctor.statics = function(statics) {
                extend(ctor, statics);
                return ctor;
            };

            ctor.methods(methods).statics(statics);
            return ctor;
        }

        var Base = (exports.Base = makeClass(Object, {
            className: 'Base',
            callSuper: function callSuper(parent, name, args) {
                var superMethod = parent.prototype[name];
                return superMethod.apply(this, args);
            },
            toString: function toString() {
                return this.constructor.name;
            }
        }));

        return exports;
    })({});

    /* ------------------------------ mapObj ------------------------------ */

    _.mapObj = (function (exports) {
        /* Map for objects.
         *
         * |Name     |Type    |Desc                          |
         * |---------|--------|------------------------------|
         * |object   |object  |Object to iterate over        |
         * |iterator |function|Function invoked per iteration|
         * |[context]|*       |Function context              |
         * |return   |object  |New mapped object             |
         */

        /* example
         * mapObj({a: 1, b: 2}, function (val, key) { return val + 1 }); // -> {a: 2, b: 3}
         */

        /* typescript
         * export declare function mapObj<T, TResult>(
         *     object: types.Dictionary<T>,
         *     iterator: types.ObjectIterator<T, TResult>,
         *     context?: any
         * ): types.Dictionary<TResult>;
         */

        /* dependencies
         * safeCb keys types 
         */

        exports = function exports(obj, iterator, ctx) {
            iterator = safeCb(iterator, ctx);

            var _keys = keys(obj),
                len = _keys.length,
                ret = {};

            for (var i = 0; i < len; i++) {
                var curKey = _keys[i];
                ret[curKey] = iterator(obj[curKey], curKey, obj);
            }

            return ret;
        };

        return exports;
    })({});

    /* ------------------------------ some ------------------------------ */

    var some = _.some = (function (exports) {
        /* Check if predicate return truthy for any element.
         *
         * |Name     |Type        |Desc                                          |
         * |---------|------------|----------------------------------------------|
         * |obj      |array object|Collection to iterate over                    |
         * |predicate|function    |Function to invoked per iteration             |
         * |ctx      |*           |Predicate context                             |
         * |return   |boolean     |True if any element passes the predicate check|
         */

        /* example
         * some([2, 5], function (val) {
         *     return val % 2 === 0;
         * }); // -> true
         */

        /* typescript
         * export declare function some<T>(
         *     list: types.List<T>,
         *     iterator?: types.ListIterator<T, boolean>,
         *     context?: any
         * ): boolean;
         * export declare function some<T>(
         *     object: types.Dictionary<T>,
         *     iterator?: types.ObjectIterator<T, boolean>,
         *     context?: any
         * ): boolean;
         */

        /* dependencies
         * safeCb isArrLike keys types 
         */

        exports = function exports(obj, predicate, ctx) {
            predicate = safeCb(predicate, ctx);

            var _keys = !isArrLike(obj) && keys(obj),
                len = (_keys || obj).length;

            for (var i = 0; i < len; i++) {
                var key = _keys ? _keys[i] : i;
                if (predicate(obj[key], key, obj)) return true;
            }

            return false;
        };

        return exports;
    })({});

    /* ------------------------------ strToBytes ------------------------------ */

    var strToBytes = _.strToBytes = (function (exports) {
        /* Convert string into bytes.
         *
         * |Name  |Type  |Desc             |
         * |------|------|-----------------|
         * |str   |string|String to convert|
         * |return|array |Bytes array      |
         */

        /* example
         * strToBytes('licia'); // -> [108, 105, 99, 105, 97]
         */

        /* typescript
         * export declare function strToBytes(str: string): number[];
         */
        exports = function exports(str) {
            var bytes = [];

            for (var i = 0, len = str.length; i < len; i++) {
                bytes.push(str.charCodeAt(i) & 0xff);
            }

            return bytes;
        };

        return exports;
    })({});

    /* ------------------------------ md5 ------------------------------ */

    _.md5 = (function (exports) {
        /* MD5 implementation.
         *
         * |Name   |Type  |Desc              |
         * |-------|------|------------------|
         * |msg    |string|Message to encrypt|
         * |return |string|MD5 hash          |
         */

        /* example
         * md5('licia'); // -> 'e59f337d85e9a467f1783fab282a41d0'
         */

        /* typescript
         * export declare function md5(msg: string): string;
         */

        /* dependencies
         * utf8 strToBytes 
         */ // https://github.com/pvorb/node-md5

        exports = function exports(msg) {
            var bytes = strToBytes(utf8.encode(msg));
            var m = bytesToWords(bytes);
            var l = bytes.length * 8;
            var a = 1732584193;
            var b = -271733879;
            var c = -1732584194;
            var d = 271733878; // Swap endian

            for (var i = 0; i < m.length; i++) {
                m[i] =
                    (((m[i] << 8) | (m[i] >>> 24)) & 0x00ff00ff) |
                    (((m[i] << 24) | (m[i] >>> 8)) & 0xff00ff00);
            } // Padding

            m[l >>> 5] |= 0x80 << l % 32;
            m[(((l + 64) >>> 9) << 4) + 14] = l;

            for (var _i = 0; _i < m.length; _i += 16) {
                var aa = a;
                var bb = b;
                var cc = c;
                var dd = d;
                a = FF(a, b, c, d, m[_i + 0], 7, -680876936);
                d = FF(d, a, b, c, m[_i + 1], 12, -389564586);
                c = FF(c, d, a, b, m[_i + 2], 17, 606105819);
                b = FF(b, c, d, a, m[_i + 3], 22, -1044525330);
                a = FF(a, b, c, d, m[_i + 4], 7, -176418897);
                d = FF(d, a, b, c, m[_i + 5], 12, 1200080426);
                c = FF(c, d, a, b, m[_i + 6], 17, -1473231341);
                b = FF(b, c, d, a, m[_i + 7], 22, -45705983);
                a = FF(a, b, c, d, m[_i + 8], 7, 1770035416);
                d = FF(d, a, b, c, m[_i + 9], 12, -1958414417);
                c = FF(c, d, a, b, m[_i + 10], 17, -42063);
                b = FF(b, c, d, a, m[_i + 11], 22, -1990404162);
                a = FF(a, b, c, d, m[_i + 12], 7, 1804603682);
                d = FF(d, a, b, c, m[_i + 13], 12, -40341101);
                c = FF(c, d, a, b, m[_i + 14], 17, -1502002290);
                b = FF(b, c, d, a, m[_i + 15], 22, 1236535329);
                a = GG(a, b, c, d, m[_i + 1], 5, -165796510);
                d = GG(d, a, b, c, m[_i + 6], 9, -1069501632);
                c = GG(c, d, a, b, m[_i + 11], 14, 643717713);
                b = GG(b, c, d, a, m[_i + 0], 20, -373897302);
                a = GG(a, b, c, d, m[_i + 5], 5, -701558691);
                d = GG(d, a, b, c, m[_i + 10], 9, 38016083);
                c = GG(c, d, a, b, m[_i + 15], 14, -660478335);
                b = GG(b, c, d, a, m[_i + 4], 20, -405537848);
                a = GG(a, b, c, d, m[_i + 9], 5, 568446438);
                d = GG(d, a, b, c, m[_i + 14], 9, -1019803690);
                c = GG(c, d, a, b, m[_i + 3], 14, -187363961);
                b = GG(b, c, d, a, m[_i + 8], 20, 1163531501);
                a = GG(a, b, c, d, m[_i + 13], 5, -1444681467);
                d = GG(d, a, b, c, m[_i + 2], 9, -51403784);
                c = GG(c, d, a, b, m[_i + 7], 14, 1735328473);
                b = GG(b, c, d, a, m[_i + 12], 20, -1926607734);
                a = HH(a, b, c, d, m[_i + 5], 4, -378558);
                d = HH(d, a, b, c, m[_i + 8], 11, -2022574463);
                c = HH(c, d, a, b, m[_i + 11], 16, 1839030562);
                b = HH(b, c, d, a, m[_i + 14], 23, -35309556);
                a = HH(a, b, c, d, m[_i + 1], 4, -1530992060);
                d = HH(d, a, b, c, m[_i + 4], 11, 1272893353);
                c = HH(c, d, a, b, m[_i + 7], 16, -155497632);
                b = HH(b, c, d, a, m[_i + 10], 23, -1094730640);
                a = HH(a, b, c, d, m[_i + 13], 4, 681279174);
                d = HH(d, a, b, c, m[_i + 0], 11, -358537222);
                c = HH(c, d, a, b, m[_i + 3], 16, -722521979);
                b = HH(b, c, d, a, m[_i + 6], 23, 76029189);
                a = HH(a, b, c, d, m[_i + 9], 4, -640364487);
                d = HH(d, a, b, c, m[_i + 12], 11, -421815835);
                c = HH(c, d, a, b, m[_i + 15], 16, 530742520);
                b = HH(b, c, d, a, m[_i + 2], 23, -995338651);
                a = II(a, b, c, d, m[_i + 0], 6, -198630844);
                d = II(d, a, b, c, m[_i + 7], 10, 1126891415);
                c = II(c, d, a, b, m[_i + 14], 15, -1416354905);
                b = II(b, c, d, a, m[_i + 5], 21, -57434055);
                a = II(a, b, c, d, m[_i + 12], 6, 1700485571);
                d = II(d, a, b, c, m[_i + 3], 10, -1894986606);
                c = II(c, d, a, b, m[_i + 10], 15, -1051523);
                b = II(b, c, d, a, m[_i + 1], 21, -2054922799);
                a = II(a, b, c, d, m[_i + 8], 6, 1873313359);
                d = II(d, a, b, c, m[_i + 15], 10, -30611744);
                c = II(c, d, a, b, m[_i + 6], 15, -1560198380);
                b = II(b, c, d, a, m[_i + 13], 21, 1309151649);
                a = II(a, b, c, d, m[_i + 4], 6, -145523070);
                d = II(d, a, b, c, m[_i + 11], 10, -1120210379);
                c = II(c, d, a, b, m[_i + 2], 15, 718787259);
                b = II(b, c, d, a, m[_i + 9], 21, -343485551);
                a = (a + aa) >>> 0;
                b = (b + bb) >>> 0;
                c = (c + cc) >>> 0;
                d = (d + dd) >>> 0;
            }

            return bytesToHex(wordsToBytes(endian([a, b, c, d])));
        };

        function FF(a, b, c, d, x, s, t) {
            var n = a + ((b & c) | (~b & d)) + (x >>> 0) + t;
            return ((n << s) | (n >>> (32 - s))) + b;
        }

        function GG(a, b, c, d, x, s, t) {
            var n = a + ((b & d) | (c & ~d)) + (x >>> 0) + t;
            return ((n << s) | (n >>> (32 - s))) + b;
        }

        function HH(a, b, c, d, x, s, t) {
            var n = a + (b ^ c ^ d) + (x >>> 0) + t;
            return ((n << s) | (n >>> (32 - s))) + b;
        }

        function II(a, b, c, d, x, s, t) {
            var n = a + (c ^ (b | ~d)) + (x >>> 0) + t;
            return ((n << s) | (n >>> (32 - s))) + b;
        }

        function wordsToBytes(words) {
            var bytes = [];

            for (var b = 0, len = words.length * 32; b < len; b += 8) {
                bytes.push((words[b >>> 5] >>> (24 - (b % 32))) & 0xff);
            }

            return bytes;
        }

        function bytesToHex(bytes) {
            var hex = [];

            for (var i = 0, len = bytes.length; i < len; i++) {
                hex.push((bytes[i] >>> 4).toString(16));
                hex.push((bytes[i] & 0xf).toString(16));
            }

            return hex.join('');
        }

        function endian(n) {
            if (n.constructor == Number) {
                return (rotl(n, 8) & 0x00ff00ff) | (rotl(n, 24) & 0xff00ff00);
            }

            for (var i = 0; i < n.length; i++) {
                n[i] = endian(n[i]);
            }

            return n;
        }

        function rotl(n, b) {
            return (n << b) | (n >>> (32 - b));
        }

        function bytesToWords(bytes) {
            var words = [];

            for (var i = 0, b = 0, len = bytes.length; i < len; i++, b += 8) {
                words[b >>> 5] |= bytes[i] << (24 - (b % 32));
            }

            return words;
        }

        return exports;
    })({});

    /* ------------------------------ memStorage ------------------------------ */

    var memStorage = _.memStorage = (function (exports) {
        /* Memory-backed implementation of the Web Storage API.
         *
         * A replacement for environments where localStorage or sessionStorage is not available.
         */

        /* example
         * var localStorage = window.localStorage || memStorage;
         * localStorage.setItem('test', 'licia');
         */

        /* typescript
         * export declare const memStorage: typeof window.localStorage;
         */

        /* dependencies
         * keys 
         */

        exports = {
            getItem: function getItem(key) {
                return (API_KEYS[key] ? cloak[key] : this[key]) || null;
            },
            setItem: function setItem(key, val) {
                API_KEYS[key] ? (cloak[key] = val) : (this[key] = val);
            },
            removeItem: function removeItem(key) {
                API_KEYS[key] ? delete cloak[key] : delete this[key];
            },
            key: function key(i) {
                var keys = enumerableKeys();
                return i >= 0 && i < keys.length ? keys[i] : null;
            },
            clear: function clear() {
                var keys = uncloakedKeys();
                /* eslint-disable no-cond-assign */

                for (var i = 0, key; (key = keys[i]); i++) {
                    delete this[key];
                }

                keys = cloakedKeys();
                /* eslint-disable no-cond-assign */

                for (i = 0; (key = keys[i]); i++) {
                    delete cloak[key];
                }
            }
        };
        Object.defineProperty(exports, 'length', {
            enumerable: false,
            configurable: true,
            get: function get() {
                return enumerableKeys().length;
            }
        });
        var cloak = {};
        var API_KEYS = {
            getItem: 1,
            setItem: 1,
            removeItem: 1,
            key: 1,
            clear: 1,
            length: 1
        };

        function enumerableKeys() {
            return uncloakedKeys().concat(cloakedKeys());
        }

        function uncloakedKeys() {
            return keys(exports).filter(function(key) {
                return !API_KEYS[key];
            });
        }

        function cloakedKeys() {
            return keys(cloak);
        }

        return exports;
    })({});

    /* ------------------------------ now ------------------------------ */

    var now = _.now = (function (exports) {
        /* Gets the number of milliseconds that have elapsed since the Unix epoch.
         */

        /* example
         * now(); // -> 1468826678701
         */

        /* typescript
         * export declare function now(): number;
         */
        exports =
            Date.now ||
            function() {
                return new Date().getTime();
            };

        return exports;
    })({});

    /* ------------------------------ partial ------------------------------ */

    var partial = _.partial = (function (exports) {
        /* Partially apply a function by filling in given arguments.
         *
         * |Name       |Type    |Desc                                    |
         * |-----------|--------|----------------------------------------|
         * |fn         |function|Function to partially apply arguments to|
         * |...partials|*       |Arguments to be partially applied       |
         * |return     |function|New partially applied function          |
         */

        /* example
         * var sub5 = partial(function (a, b) { return b - a }, 5);
         * sub5(20); // -> 15
         */

        /* typescript
         * export declare function partial(fn: Function, ...partials: any[]): Function;
         */

        /* dependencies
         * restArgs toArr 
         */

        exports = restArgs(function(fn, partials) {
            return function() {
                var args = [];
                args = args.concat(partials);
                args = args.concat(toArr(arguments));
                return fn.apply(this, args);
            };
        });

        return exports;
    })({});

    /* ------------------------------ once ------------------------------ */

    var once = _.once = (function (exports) {
        /* Create a function that invokes once.
         *
         * |Name  |Type    |Desc                   |
         * |------|--------|-----------------------|
         * |fn    |function|Function to restrict   |
         * |return|function|New restricted function|
         */

        /* example
         * function init() {};
         * var initOnce = once(init);
         * initOnce();
         * initOnce(); // -> init is invoked once
         */

        /* typescript
         * export declare function once(fn: Function): Function;
         */

        /* dependencies
         * partial before 
         */

        exports = partial(before, 2);

        return exports;
    })({});

    /* ------------------------------ Emitter ------------------------------ */

    var Emitter = _.Emitter = (function (exports) {
        /* Event emitter class which provides observer pattern.
         *
         * ### on
         *
         * Bind event.
         *
         * ### off
         *
         * Unbind event.
         *
         * ### once
         *
         * Bind event that trigger once.
         *
         * |Name    |Type    |Desc          |
         * |--------|--------|--------------|
         * |event   |string  |Event name    |
         * |listener|function|Event listener|
         *
         * ### emit
         *
         * Emit event.
         *
         * |Name   |Type  |Desc                        |
         * |-------|------|----------------------------|
         * |event  |string|Event name                  |
         * |...args|*     |Arguments passed to listener|
         *
         * ### mixin
         *
         * [static] Mixin object class methods.
         *
         * |Name|Type  |Desc           |
         * |----|------|---------------|
         * |obj |object|Object to mixin|
         */

        /* example
         * var event = new Emitter();
         * event.on('test', function () { console.log('test') });
         * event.emit('test'); // Logs out 'test'.
         * Emitter.mixin({});
         */

        /* typescript
         * export declare namespace Emitter {
         *     function mixin(obj: any): any;
         * }
         * export declare class Emitter {
         *     on(event: string, listener: Function): Emitter;
         *     off(event: string, listener: Function): Emitter;
         *     once(event: string, listener: Function): Emitter;
         *     emit(event: string): Emitter;
         * }
         */

        /* dependencies
         * Class has each slice once 
         */

        exports = Class(
            {
                initialize: function Emitter() {
                    this._events = this._events || {};
                },
                on: function on(event, listener) {
                    this._events[event] = this._events[event] || [];

                    this._events[event].push(listener);

                    return this;
                },
                off: function off(event, listener) {
                    if (!has(this._events, event)) return;

                    this._events[event].splice(
                        this._events[event].indexOf(listener),
                        1
                    );

                    return this;
                },
                once: (function(_once) {
                    function once(_x, _x2) {
                        return _once.apply(this, arguments);
                    }

                    once.toString = function() {
                        return _once.toString();
                    };

                    return once;
                })(function(event, listener) {
                    this.on(event, once(listener));
                    return this;
                }),
                emit: function emit(event) {
                    if (!has(this._events, event)) return;
                    var args = slice(arguments, 1);
                    each(
                        this._events[event],
                        function(val) {
                            val.apply(this, args);
                        },
                        this
                    );
                    return this;
                }
            },
            {
                mixin: function mixin(obj) {
                    each(['on', 'off', 'once', 'emit'], function(val) {
                        obj[val] = exports.prototype[val];
                    });
                    obj._events = obj._events || {};
                }
            }
        );

        return exports;
    })({});

    /* ------------------------------ State ------------------------------ */

    var State = _.State = (function (exports) {
        /* Simple state machine.
         *
         * Extend from Emitter.
         *
         * ### constructor
         *
         * |Name   |Type  |Desc                  |
         * |-------|------|----------------------|
         * |initial|string|Initial state         |
         * |events |object|Events to change state|
         *
         * ### is
         *
         * Check current state.
         *
         * |Name  |Type   |Desc                                    |
         * |------|-------|----------------------------------------|
         * |value |string |State to check                          |
         * |return|boolean|True if current state equals given value|
         */

        /* example
         * var state = new State('empty', {
         *     load: {from: 'empty', to: 'pause'},
         *     play: {from: 'pause', to: 'play'},
         *     pause: {from: ['play', 'empty'], to: 'pause'},
         *     unload: {from: ['play', 'pause'], to: 'empty'}
         * });
         *
         * state.is('empty'); // -> true
         * state.load();
         * state.is('pause'); // -> true
         * state.on('play', function (src) {
         *     console.log(src); // -> 'eustia'
         * });
         * state.on('error', function (err, event) {
         *     // Error handler
         * });
         * state.play('eustia');
         */

        /* typescript
         * export declare class State extends Emitter {
         *     constructor(initial: string, events: any);
         *     is(state: string): boolean;
         *     [event: string]: any;
         * }
         */

        /* dependencies
         * Emitter each some toArr 
         */

        exports = Emitter.extend({
            className: 'State',
            initialize: function initialize(initial, events) {
                this.callSuper(Emitter, 'initialize');
                this.current = initial;
                var self = this;
                each(events, function(event, key) {
                    self[key] = buildEvent(key, event);
                });
            },
            is: function is(state) {
                return this.current === state;
            }
        });

        function buildEvent(name, event) {
            var from = toArr(event.from),
                to = event.to;
            return function() {
                var args = toArr(arguments);
                args.unshift(name);
                var hasEvent = some(
                    from,
                    function(val) {
                        return this.current === val;
                    },
                    this
                );

                if (hasEvent) {
                    this.current = to;
                    this.emit.apply(this, args);
                } else {
                    this.emit(
                        'error',
                        new Error(this.current + ' => ' + to + ' error'),
                        name
                    );
                }
            };
        }

        return exports;
    })({});

    /* ------------------------------ Promise ------------------------------ */

    var Promise = _.Promise = (function (exports) {
        /* Lightweight Promise implementation.
         *
         * [Promises spec](https://github.com/promises-aplus/promises-spec)
         */

        /* example
         * function get(url) {
         *     return new Promise(function (resolve, reject) {
         *         var req = new XMLHttpRequest();
         *         req.open('GET', url);
         *         req.onload = function () {
         *             req.status == 200 ? resolve(req.response) : reject(Error(req.statusText));
         *         };
         *         req.onerror = function () { reject(Error('Network Error')) };
         *         req.send();
         *     });
         * }
         *
         * get('test.json').then(function (result) {
         *     // Do something...
         * });
         */

        /* typescript
         */

        /* dependencies
         * Class isObj isFn State bind nextTick noop 
         */

        var Promise = (exports = Class(
            {
                initialize: function Promise(fn) {
                    if (!isObj(this))
                        throw new TypeError('Promises must be constructed via new');
                    if (!isFn(fn)) throw new TypeError(fn + ' is not a function');
                    var self = this;
                    this._state = new State('pending', {
                        fulfill: {
                            from: 'pending',
                            to: 'fulfilled'
                        },
                        reject: {
                            from: 'pending',
                            to: 'rejected'
                        },
                        adopt: {
                            from: 'pending',
                            to: 'adopted'
                        }
                    })
                        .on('fulfill', assignVal)
                        .on('reject', assignVal)
                        .on('adopt', assignVal);

                    function assignVal(val) {
                        self._value = val;
                    }

                    this._handled = false;
                    this._value = undefined;
                    this._deferreds = [];
                    doResolve(fn, this);
                },
                catch: function _catch(onRejected) {
                    return this.then(null, onRejected);
                },
                then: function then(onFulfilled, onRejected) {
                    var promise = new Promise(noop);
                    handle(this, new Handler(onFulfilled, onRejected, promise));
                    return promise;
                }
            },
            {
                all: function all(arr) {
                    var args = toArr(arr);
                    return new Promise(function(resolve, reject) {
                        if (args.length === 0) return resolve([]);
                        var remaining = args.length;

                        function res(i, val) {
                            try {
                                if (val && (isObj(val) || isFn(val))) {
                                    var then = val.then;

                                    if (isFn(then)) {
                                        then.call(
                                            val,
                                            function(val) {
                                                res(i, val);
                                            },
                                            reject
                                        );
                                        return;
                                    }
                                }

                                args[i] = val;
                                if (--remaining === 0) resolve(args);
                            } catch (e) {
                                reject(e);
                            }
                        }

                        for (var i = 0; i < args.length; i++) {
                            res(i, args[i]);
                        }
                    });
                },
                resolve: function resolve(val) {
                    if (val && isObj(val) && val.constructor === Promise) return val;
                    return new Promise(function(resolve) {
                        resolve(val);
                    });
                },
                reject: function reject(val) {
                    return new Promise(function(resolve, reject) {
                        reject(val);
                    });
                },
                race: function race(values) {
                    return new Promise(function(resolve, reject) {
                        for (var i = 0, len = values.length; i < len; i++) {
                            values[i].then(resolve, reject);
                        }
                    });
                }
            }
        ));
        var Handler = Class({
            initialize: function Handler(onFulfilled, onRejected, promise) {
                this.onFulfilled = isFn(onFulfilled) ? onFulfilled : null;
                this.onRejected = isFn(onRejected) ? onRejected : null;
                this.promise = promise;
            }
        });

        function reject(self, err) {
            self._state.reject(err);

            finale(self);
        }

        function resolve(self, val) {
            try {
                if (val === self)
                    throw new TypeError('A promise cannot be resolved with itself');

                if (val && (isObj(val) || isFn(val))) {
                    var then = val.then;

                    if (val instanceof Promise) {
                        self._state.adopt(val);

                        return finale(self);
                    }

                    if (isFn(then)) return doResolve(bind(then, val), self);
                }

                self._state.fulfill(val);

                finale(self);
            } catch (e) {
                reject(self, e);
            }
        }

        function finale(self) {
            for (var i = 0, len = self._deferreds.length; i < len; i++) {
                handle(self, self._deferreds[i]);
            }

            self._deferreds = null;
        }

        function handle(self, deferred) {
            while (self._state.is('adopted')) {
                self = self._value;
            }

            if (self._state.is('pending')) return self._deferreds.push(deferred);
            self._handled = true;
            nextTick(function() {
                var isFulfilled = self._state.is('fulfilled');

                var cb = isFulfilled ? deferred.onFulfilled : deferred.onRejected;
                if (cb === null)
                    return (isFulfilled ? resolve : reject)(
                        deferred.promise,
                        self._value
                    );
                var ret;

                try {
                    ret = cb(self._value);
                } catch (e) {
                    return reject(deferred.promise, e);
                }

                resolve(deferred.promise, ret);
            });
        }

        function doResolve(fn, self) {
            var done = false;

            try {
                fn(
                    function(val) {
                        if (done) return;
                        done = true;
                        resolve(self, val);
                    },
                    function(reason) {
                        if (done) return;
                        done = true;
                        reject(self, reason);
                    }
                );
            } catch (e) {
                if (done) return;
                done = true;
                reject(self, e);
            }
        }

        return exports;
    })({});

    /* ------------------------------ fetch ------------------------------ */

    _.fetch = (function (exports) {
        /* Turn XMLHttpRequest into promise like.
         *
         * Note: This is not a complete fetch pollyfill.
         *
         * |Name     |Type   |Desc           |
         * |---------|-------|---------------|
         * |url      |string |Request url    |
         * |[options]|object |Request options|
         * |return   |Promise|Request promise|
         */

        /* example
         * fetch('test.json', {
         *     method: 'GET',
         *     timeout: 3000,
         *     headers: {},
         *     body: ''
         * }).then(function (res) {
         *     return res.json();
         * }).then(function (data) {
         *     console.log(data);
         * });
         */

        /* typescript
         * export declare namespace fetch {
         *     interface IOptions {
         *         method?: string;
         *         timeout?: number;
         *         headers?: { [name: string]: string };
         *         body?: any;
         *     }
         *     interface IHeaders {
         *         keys(): string[];
         *         entries(): Array<string[]>;
         *         get(name: string): string;
         *         has(name: string): boolean;
         *     }
         *     interface IResult {
         *         ok: boolean;
         *         status: number;
         *         statusText: string;
         *         url: string;
         *         clone(): IResult;
         *         text(): Promise<string>;
         *         json(): Promise<any>;
         *         xml(): Promise<Document | null>;
         *         blob(): Promise<Blob>;
         *         headers: IHeaders;
         *     }
         * }
         * export declare function fetch(
         *     url: string,
         *     options?: fetch.IOptions
         * ): Promise<fetch.IResult>;
         */

        /* dependencies
         * Promise each defaults noop 
         */

        exports = (function(_exports) {
            function exports(_x, _x2) {
                return _exports.apply(this, arguments);
            }

            exports.toString = function() {
                return _exports.toString();
            };

            return exports;
        })(function(url, options) {
            options = options || {};
            defaults(options, exports.setting);
            return new Promise(function(resolve, reject) {
                var xhr = options.xhr(),
                    headers = options.headers,
                    body = options.body,
                    timeout = options.timeout,
                    abortTimer;
                xhr.withCredentials = options.credentials == 'include';

                xhr.onload = function() {
                    clearTimeout(abortTimer);
                    resolve(getRes(xhr));
                };

                xhr.onerror = reject;
                xhr.open(options.method, url, true);
                each(headers, function(val, key) {
                    xhr.setRequestHeader(key, val);
                });

                if (timeout > 0) {
                    setTimeout(function() {
                        xhr.onload = noop;
                        xhr.abort();
                        reject(Error('timeout'));
                    }, timeout);
                }

                xhr.send(body);
            });
        });

        var regHeaders = /^(.*?):\s*([\s\S]*?)$/gm;

        function getRes(xhr) {
            var _keys = [],
                all = [],
                headers = {},
                header;
            xhr.getAllResponseHeaders().replace(regHeaders, function(m, key, val) {
                key = key.toLowerCase();

                _keys.push(key); // Duplicated headers is possible.

                all.push([key, val]);
                header = headers[key];
                headers[key] = header ? header + ',' + val : val;
            });
            return {
                ok: xhr.status >= 200 && xhr.status < 400,
                status: xhr.status,
                statusText: xhr.statusText,
                url: xhr.responseURL,
                clone: function clone() {
                    return getRes(xhr);
                },
                text: function text() {
                    return Promise.resolve(xhr.responseText);
                },
                json: function json() {
                    return Promise.resolve(xhr.responseText).then(JSON.parse);
                },
                xml: function xml() {
                    return Promise.resolve(xhr.responseXML);
                },
                blob: function blob() {
                    return Promise.resolve(new Blob([xhr.response]));
                },
                headers: {
                    keys: function keys() {
                        return _keys;
                    },
                    entries: function entries() {
                        return all;
                    },
                    get: function get(name) {
                        return headers[name.toLowerCase()];
                    },
                    has: (function(_has) {
                        function has(_x3) {
                            return _has.apply(this, arguments);
                        }

                        has.toString = function() {
                            return _has.toString();
                        };

                        return has;
                    })(function(name) {
                        return has(headers, name);
                    })
                }
            };
        }

        exports.setting = {
            method: 'GET',
            headers: {},
            timeout: 0,
            xhr: function xhr() {
                return new XMLHttpRequest();
            }
        };

        return exports;
    })({});

    /* ------------------------------ fullscreen ------------------------------ */

    _.fullscreen = (function (exports) {
        /* Fullscreen api wrapper.
         *
         * ### request
         *
         * Request fullscreen.
         *
         * |Name  |Type   |Desc              |
         * |------|-------|------------------|
         * |[el]  |Element|Fullscreen element|
         *
         * ### exit
         *
         * Exit fullscreen.
         *
         * ### toggle
         *
         * Toggle fullscreen.
         *
         * |Name  |Type   |Desc              |
         * |------|-------|------------------|
         * |[el]  |Element|Fullscreen element|
         *
         * ### isActive
         *
         * Check Whether fullscreen is active.
         *
         * ### getEl
         *
         * Return Fullscreen element if exists.
         *
         * ### isEnabled
         *
         * Whether you are allowed to enter fullscreen.
         */

        /* example
         * fullscreen.request();
         * fullscreen.isActive(); // -> false, not a synchronous api
         * fullscreen.on('error', () => {});
         * fullscreen.on('change', () => {});
         */

        /* typescript
         * export declare namespace fullscreen {
         *     interface IFullscreen extends Emitter {
         *         request(el?: Element): void;
         *         exit(): void;
         *         toggle(el?: Element): void;
         *         isActive(): boolean;
         *         getEl(): Element | null;
         *         isEnabled(): boolean;
         *     }
         * }
         * export declare const fullscreen: fullscreen.IFullscreen;
         */

        /* dependencies
         * Emitter toBool 
         */

        var fnMap = [
            [
                'requestFullscreen',
                'exitFullscreen',
                'fullscreenElement',
                'fullscreenEnabled',
                'fullscreenchange',
                'fullscreenerror'
            ],
            [
                'webkitRequestFullscreen',
                'webkitExitFullscreen',
                'webkitFullscreenElement',
                'webkitFullscreenEnabled',
                'webkitfullscreenchange',
                'webkitfullscreenerror'
            ],
            [
                'mozRequestFullScreen',
                'mozCancelFullScreen',
                'mozFullScreenElement',
                'mozFullScreenEnabled',
                'mozfullscreenchange',
                'mozfullscreenerror'
            ],
            [
                'msRequestFullscreen',
                'msExitFullscreen',
                'msFullscreenElement',
                'msFullscreenEnabled',
                'MSFullscreenChange',
                'MSFullscreenError'
            ]
        ];
        var fn;

        for (var i = 0, len = fnMap.length; i < len; i++) {
            fn = fnMap[i];

            if (fn[1] in document) {
                break;
            }
        }

        exports = {
            request: function request() {
                var el =
                    arguments.length > 0 && arguments[0] !== undefined
                        ? arguments[0]
                        : document.documentElement;
                el[fn[0]]();
            },
            exit: function exit() {
                document[fn[1]]();
            },
            toggle: function toggle() {
                var el =
                    arguments.length > 0 && arguments[0] !== undefined
                        ? arguments[0]
                        : document.documentElement;
                this.isActive() ? this.exit() : this.request(el);
            },
            isActive: function isActive() {
                return toBool(this.getEl());
            },
            isEnabled: function isEnabled() {
                return toBool(document[fn[3]]);
            },
            getEl: function getEl() {
                return document[fn[2]];
            }
        };
        Emitter.mixin(exports);
        document.addEventListener(fn[4], function() {
            exports.emit('change');
        });
        document.addEventListener(fn[5], function() {
            exports.emit('error');
        });

        return exports;
    })({});

    /* ------------------------------ perfNow ------------------------------ */

    var perfNow = _.perfNow = (function (exports) {
        /* High resolution time up to microsecond precision.
         */

        /* example
         * var start = perfNow();
         *
         * // Do something.
         *
         * console.log(perfNow() - start);
         */

        /* typescript
         * export declare function perfNow(): number;
         */

        /* dependencies
         * now root 
         */

        var performance = root.performance,
            process = root.process,
            loadTime;

        if (performance && performance.now) {
            exports = function exports() {
                return performance.now();
            };
        } else if (process && process.hrtime) {
            var getNanoSeconds = function getNanoSeconds() {
                var hr = process.hrtime();
                return hr[0] * 1e9 + hr[1];
            };

            loadTime = getNanoSeconds() - process.uptime() * 1e9;

            exports = function exports() {
                return (getNanoSeconds() - loadTime) / 1e6;
            };
        } else {
            loadTime = now();

            exports = function exports() {
                return now() - loadTime;
            };
        }

        return exports;
    })({});

    /* ------------------------------ rmCookie ------------------------------ */

    _.rmCookie = (function (exports) {
        /* Loop through all possible path and domain to remove cookie.
         *
         * |Name|Type  |Desc      |
         * |----|------|----------|
         * |key |string|Cookie key|
         */

        /* example
         * rmCookie('test');
         */

        /* typescript
         * export declare function rmCookie(key: string): void;
         */

        /* dependencies
         * cookie 
         */

        exports = function exports(key) {
            var location = window.location,
                hostname = location.hostname,
                pathname = location.pathname,
                hostNames = hostname.split('.'),
                pathNames = pathname.split('/'),
                domain = '',
                pathLen = pathNames.length,
                path;
            if (del()) return;

            for (var i = hostNames.length - 1; i >= 0; i--) {
                var hostName = hostNames[i];
                if (hostName === '') continue;
                domain = domain === '' ? hostName : hostName + '.' + domain;
                path = '/';
                if (
                    del({
                        domain: domain,
                        path: path
                    }) ||
                    del({
                        domain: domain
                    })
                )
                    return;

                for (var j = 0; j < pathLen; j++) {
                    var pathName = pathNames[j];
                    if (pathName === '') continue;
                    path += pathName;
                    if (
                        del({
                            domain: domain,
                            path: path
                        }) ||
                        del({
                            path: path
                        })
                    )
                        return;
                    path += '/';
                    if (
                        del({
                            domain: domain,
                            path: path
                        }) ||
                        del({
                            path: path
                        })
                    )
                        return;
                }
            }

            function del(options) {
                options = options || {};
                cookie.remove(key, options);
                return !cookie.get(key);
            }
        };

        return exports;
    })({});

    /* ------------------------------ rtrim ------------------------------ */

    var rtrim = _.rtrim = (function (exports) {
        /* Remove chars or white-spaces from end of string.
         *
         * |Name   |Type        |Desc              |
         * |-------|------------|------------------|
         * |str    |string      |String to trim    |
         * |[chars]|string array|Characters to trim|
         * |return |string      |Trimmed string    |
         */

        /* example
         * rtrim(' abc  '); // -> ' abc'
         * rtrim('_abc_', '_'); // -> '_abc'
         * rtrim('_abc_', ['c', '_']); // -> '_ab'
         */

        /* typescript
         * export declare function rtrim(str: string, chars?: string | string[]): string;
         */
        var regSpace = /\s+$/;

        exports = function exports(str, chars) {
            if (chars == null) return str.replace(regSpace, '');
            var end = str.length - 1,
                charLen = chars.length,
                found = true,
                i,
                c;

            while (found && end >= 0) {
                found = false;
                i = -1;
                c = str.charAt(end);

                while (++i < charLen) {
                    if (c === chars[i]) {
                        found = true;
                        end--;
                        break;
                    }
                }
            }

            return end >= 0 ? str.substring(0, end + 1) : '';
        };

        return exports;
    })({});

    /* ------------------------------ trim ------------------------------ */

    var trim = _.trim = (function (exports) {
        /* Remove chars or white-spaces from beginning end of string.
         *
         * |Name  |Type        |Desc              |
         * |------|------------|------------------|
         * |str   |string      |String to trim    |
         * |chars |string array|Characters to trim|
         * |return|string      |Trimmed string    |
         */

        /* example
         * trim(' abc  '); // -> 'abc'
         * trim('_abc_', '_'); // -> 'abc'
         * trim('_abc_', ['a', 'c', '_']); // -> 'b'
         */

        /* typescript
         * export declare function trim(str: string, chars?: string | string[]): string;
         */

        /* dependencies
         * ltrim rtrim 
         */

        var regSpace = /^\s+|\s+$/g;

        exports = function exports(str, chars) {
            if (chars == null) return str.replace(regSpace, '');
            return ltrim(rtrim(str, chars), chars);
        };

        return exports;
    })({});

    /* ------------------------------ extractUrls ------------------------------ */

    _.extractUrls = (function (exports) {
        /* Extract urls from plain text.
         *
         * |Name  |Type  |Desc           |
         * |------|------|---------------|
         * |str   |string|Text to extract|
         * |return|array |Url list       |
         */

        /* example
         * var str = '[Official site: http://eustia.liriliri.io](http://eustia.liriliri.io)';
         * extractUrls(str); // -> ['http://eustia.liriliri.io']
         */

        /* typescript
         * export declare function extractUrls(str: string): string[];
         */

        /* dependencies
         * unique trim map toArr 
         */

        exports = function exports(str) {
            var urlList = toArr(str.match(regUrl));
            return unique(
                map(urlList, function(url) {
                    return trim(url);
                })
            );
        };

        var regUrl = /((https?)|(ftp)):\/\/[\w.]+[^ \f\n\r\t\v"\\<>[\]\u2100-\uFFFF(),]*/gi;

        return exports;
    })({});

    /* ------------------------------ isDataUrl ------------------------------ */

    _.isDataUrl = (function (exports) {
        /* Check if a string is a valid data url.
         *
         * |Name  |Type   |Desc                        |
         * |------|-------|----------------------------|
         * |str   |string |String to check             |
         * |return|boolean|True if string is a data url|
         */

        /* example
         * isDataUrl('http://eustia.liriliri.io'); // -> false
         * isDataUrl('data:text/plain;base64,SGVsbG8sIFdvcmxkIQ%3D%3D'); // -> true
         */

        /* typescript
         * export declare function isDataUrl(str: string): boolean;
         */

        /* dependencies
         * trim 
         */

        exports = function exports(str) {
            return regDataUrl.test(trim(str));
        }; // https://tools.ietf.org/html/rfc2397

        var regDataUrl = /^data:([a-z]+\/[a-z0-9-+.]+(;[a-z0-9-.!#$%*+.{}|~`]+=[a-z0-9-.!#$%*+.{}|~`]+)*)?(;base64)?,([a-z0-9!$&',()*+;=\-._~:@/?%\s]*?)$/i;

        return exports;
    })({});

    /* ------------------------------ query ------------------------------ */

    var query = _.query = (function (exports) {
        /* Parse and stringify url query strings.
         *
         * ### parse
         *
         * Parse a query string into an object.
         *
         * |Name  |Type  |Desc        |
         * |------|------|------------|
         * |str   |string|Query string|
         * |return|object|Query object|
         *
         * ### stringify
         *
         * Stringify an object into a query string.
         *
         * |Name  |Type  |Desc        |
         * |------|------|------------|
         * |obj   |object|Query object|
         * |return|string|Query string|
         */

        /* example
         * query.parse('foo=bar&eruda=true'); // -> {foo: 'bar', eruda: 'true'}
         * query.stringify({foo: 'bar', eruda: 'true'}); // -> 'foo=bar&eruda=true'
         * query.parse('name=eruda&name=eustia'); // -> {name: ['eruda', 'eustia']}
         */

        /* typescript
         * export declare const query: {
         *     parse(str: string): any;
         *     stringify(object: any): string;
         * };
         */

        /* dependencies
         * trim each isUndef isArr map isEmpty filter isObj 
         */

        exports = {
            parse: function parse(str) {
                var ret = {};
                str = trim(str).replace(regIllegalChars, '');
                each(str.split('&'), function(param) {
                    var parts = param.split('=');
                    var key = parts.shift(),
                        val = parts.length > 0 ? parts.join('=') : null;
                    key = decodeURIComponent(key);
                    val = decodeURIComponent(val);

                    if (isUndef(ret[key])) {
                        ret[key] = val;
                    } else if (isArr(ret[key])) {
                        ret[key].push(val);
                    } else {
                        ret[key] = [ret[key], val];
                    }
                });
                return ret;
            },
            stringify: function stringify(obj, arrKey) {
                return filter(
                    map(obj, function(val, key) {
                        if (isObj(val) && isEmpty(val)) return '';
                        if (isArr(val)) return exports.stringify(val, key);
                        return (
                            (arrKey
                                ? encodeURIComponent(arrKey)
                                : encodeURIComponent(key)) +
                            '=' +
                            encodeURIComponent(val)
                        );
                    }),
                    function(str) {
                        return str.length > 0;
                    }
                ).join('&');
            }
        };
        var regIllegalChars = /^(\?|#|&)/g;

        return exports;
    })({});

    /* ------------------------------ Url ------------------------------ */

    var Url = _.Url = (function (exports) {
        /* Simple url manipulator.
         *
         * ### constructor
         *
         * |Name        |Type  |Desc      |
         * |------------|------|----------|
         * |url=location|string|Url string|
         *
         * ### setQuery
         *
         * Set query value.
         *
         * |Name  |Type  |Desc       |
         * |------|------|-----------|
         * |name  |string|Query name |
         * |value |string|Query value|
         * |return|Url   |this       |
         *
         * |Name  |Type  |Desc        |
         * |------|------|------------|
         * |query |object|query object|
         * |return|Url   |this        |
         *
         * ### rmQuery
         *
         * Remove query value.
         *
         * |Name  |Type        |Desc      |
         * |------|------------|----------|
         * |name  |string array|Query name|
         * |return|Url         |this      |
         *
         * ### parse
         *
         * [static] Parse url into an object.
         *
         * |Name  |Type  |Desc      |
         * |------|------|----------|
         * |url   |string|Url string|
         * |return|object|Url object|
         *
         * ### stringify
         *
         * [static] Stringify url object into a string.
         *
         * |Name  |Type  |Desc      |
         * |------|------|----------|
         * |url   |object|Url object|
         * |return|string|Url string|
         *
         * An url object contains the following properties:
         *
         * |Name    |Desc                                                                                  |
         * |--------|--------------------------------------------------------------------------------------|
         * |protocol|The protocol scheme of the URL (e.g. http:)                                           |
         * |slashes |A boolean which indicates whether the protocol is followed by two forward slashes (//)|
         * |auth    |Authentication information portion (e.g. username:password)                           |
         * |hostname|Host name without port number                                                         |
         * |port    |Optional port number                                                                  |
         * |pathname|URL path                                                                              |
         * |query   |Parsed object containing query string                                                 |
         * |hash    |The "fragment" portion of the URL including the pound-sign (#)                        |
         */

        /* example
         * var url = new Url('http://example.com:8080?eruda=true');
         * console.log(url.port); // -> '8080'
         * url.query.foo = 'bar';
         * url.rmQuery('eruda');
         * url.toString(); // -> 'http://example.com:8080/?foo=bar'
         */

        /* typescript
         * export declare namespace Url {
         *     interface IUrl {
         *         protocol: string;
         *         auth: string;
         *         hostname: string;
         *         hash: string;
         *         query: any;
         *         port: string;
         *         pathname: string;
         *         slashes: boolean;
         *     }
         * }
         * export declare class Url {
         *     protocol: string;
         *     auth: string;
         *     hostname: string;
         *     hash: string;
         *     query: any;
         *     port: string;
         *     pathname: string;
         *     slashes: boolean;
         *     constructor(url?: string);
         *     setQuery(name: string, value: string): Url;
         *     setQuery(query: { [name: string]: string }): Url;
         *     rmQuery(name: string | string[]): Url;
         *     toString(): string;
         *     static parse(url: string): Url.IUrl;
         *     static stringify(object: Url.IUrl): string;
         * }
         */

        /* dependencies
         * Class extend trim query isEmpty each isArr toArr isBrowser isObj 
         */

        exports = Class(
            {
                className: 'Url',
                initialize: function initialize(url) {
                    if (!url && isBrowser) url = window.location.href;
                    extend(this, exports.parse(url || ''));
                },
                setQuery: function setQuery(name, val) {
                    var query = this.query;

                    if (isObj(name)) {
                        each(name, function(val, key) {
                            query[key] = val;
                        });
                    } else {
                        query[name] = val;
                    }

                    return this;
                },
                rmQuery: function rmQuery(name) {
                    var query = this.query;
                    if (!isArr(name)) name = toArr(name);
                    each(name, function(key) {
                        delete query[key];
                    });
                    return this;
                },
                toString: function toString() {
                    return exports.stringify(this);
                }
            },
            {
                parse: function parse(url) {
                    var ret = {
                            protocol: '',
                            auth: '',
                            hostname: '',
                            hash: '',
                            query: {},
                            port: '',
                            pathname: '',
                            slashes: false
                        },
                        rest = trim(url);
                    var proto = rest.match(regProto);

                    if (proto) {
                        proto = proto[0];
                        ret.protocol = proto.toLowerCase();
                        rest = rest.substr(proto.length);
                    }

                    if (proto) {
                        var slashes = rest.substr(0, 2) === '//';

                        if (slashes) {
                            rest = rest.slice(2);
                            ret.slashes = true;
                        }
                    }

                    if (slashes) {
                        var hostEnd = -1;

                        for (var i = 0, len = hostEndingChars.length; i < len; i++) {
                            var pos = rest.indexOf(hostEndingChars[i]);
                            if (pos !== -1 && (hostEnd === -1 || pos < hostEnd))
                                hostEnd = pos;
                        }

                        var host = rest.slice(0, hostEnd);
                        rest = rest.slice(hostEnd);
                        var atSign = host.lastIndexOf('@');

                        if (atSign !== -1) {
                            ret.auth = decodeURIComponent(host.slice(0, atSign));
                            host = host.slice(atSign + 1);
                        }

                        ret.hostname = host;
                        var port = host.match(regPort);

                        if (port) {
                            port = port[0];
                            if (port !== ':') ret.port = port.substr(1);
                            ret.hostname = host.substr(0, host.length - port.length);
                        }
                    }

                    var hash = rest.indexOf('#');

                    if (hash !== -1) {
                        ret.hash = rest.substr(hash);
                        rest = rest.slice(0, hash);
                    }

                    var queryMark = rest.indexOf('?');

                    if (queryMark !== -1) {
                        ret.query = query.parse(rest.substr(queryMark + 1));
                        rest = rest.slice(0, queryMark);
                    }

                    ret.pathname = rest || '/';
                    return ret;
                },
                stringify: function stringify(obj) {
                    var ret =
                        obj.protocol +
                        (obj.slashes ? '//' : '') +
                        (obj.auth ? encodeURIComponent(obj.auth) + '@' : '') +
                        obj.hostname +
                        (obj.port ? ':' + obj.port : '') +
                        obj.pathname;
                    if (!isEmpty(obj.query)) ret += '?' + query.stringify(obj.query);
                    if (obj.hash) ret += obj.hash;
                    return ret;
                }
            }
        );
        var regProto = /^([a-z0-9.+-]+:)/i,
            regPort = /:[0-9]*$/,
            hostEndingChars = ['/', '?', '#'];

        return exports;
    })({});

    /* ------------------------------ getUrlParam ------------------------------ */

    _.getUrlParam = (function (exports) {
        /* Get url param.
         *
         * |Name        |Type  |Desc            |
         * |------------|------|----------------|
         * |name        |string|Param name      |
         * |url=location|string|Url to get param|
         * |return      |string|Param value     |
         */

        /* example
         * getUrlParam('test', 'http://example.com/?test=true'); // -> 'true'
         */

        /* typescript
         * export declare function getUrlParam(name: string, url?:string): string | undefined;
         */

        /* dependencies
         * Url 
         */

        exports = function exports(name, url) {
            return new Url(url).query[name];
        };

        return exports;
    })({});

    /* ------------------------------ jsonp ------------------------------ */

    _.jsonp = (function (exports) {
        /* A simple jsonp implementation.
         *
         * |Name|Type  |Desc         |
         * |----|------|-------------|
         * |opts|object|Jsonp Options|
         *
         * Available options:
         *
         * |Name          |Type    |Desc                  |
         * |--------------|--------|----------------------|
         * |url           |string  |Request url           |
         * |data          |object  |Request data          |
         * |success       |function|Success callback      |
         * |param=callback|string  |Callback param        |
         * |[name]        |string  |Callback name         |
         * |error         |function|Error callback        |
         * |complete      |function|Callback after request|
         * |timeout       |number  |Request timeout       |
         */

        /* example
         * jsonp({
         *     url: 'http://example.com',
         *     data: {test: 'true'},
         *     success: function (data) {
         *         // ...
         *     }
         * });
         */

        /* typescript
         * export declare namespace jsonp {
         *     interface IOptions {
         *         url: string;
         *         data?: any;
         *         success?: Function;
         *         param?: string;
         *         name?: string;
         *         error?: Function;
         *         complete?: Function;
         *         timeout?: number;
         *     }
         * }
         * export declare function jsonp(opts: jsonp.IOptions): void;
         */

        /* dependencies
         * loadJs defaults noop uniqId query 
         */

        exports = (function(_exports) {
            function exports(_x) {
                return _exports.apply(this, arguments);
            }

            exports.toString = function() {
                return _exports.toString();
            };

            return exports;
        })(function(opts) {
            defaults(opts, exports.settings);
            var name = opts.name || uniqId('jsonp'),
                param = opts.param,
                timeout = opts.timeout,
                error = opts.error,
                success = opts.success,
                complete = opts.complete,
                data = opts.data,
                url = opts.url,
                timer,
                isTimeout = false;

            if (timeout > 0) {
                timer = setTimeout(function() {
                    isTimeout = true;
                    error(new Error('Timeout'));
                    complete();
                }, timeout);
            }

            window[name] = function(data) {
                success(data);
                complete();
                window[name] = noop;
            };

            data[param] = name;
            data = query.stringify(data);
            url += url.indexOf('?') > -1 ? '&' + data : '?' + data;
            loadJs(url, function(isLoaded) {
                if (isTimeout) return;
                if (timer) clearTimeout(timer);

                if (!isLoaded) {
                    error(new Error());
                    complete();
                }
            });
        });

        exports.settings = {
            data: {},
            param: 'callback',
            success: noop,
            error: noop,
            complete: noop,
            timeout: 0
        };

        return exports;
    })({});

    /* ------------------------------ safeDel ------------------------------ */

    _.safeDel = (function (exports) {
        /* Delete object property.
         *
         * |Name  |Type        |Desc                      |
         * |------|------------|--------------------------|
         * |obj   |object      |Object to query           |
         * |path  |array string|Path of property to delete|
         * |return|*           |Deleted value or undefined|
         */

        /* example
         * var obj = {a: {aa: {aaa: 1}}};
         * safeDel(obj, 'a.aa.aaa'); // -> 1
         * safeDel(obj, ['a', 'aa']); // -> {}
         * safeDel(obj, 'a.b'); // -> undefined
         */

        /* typescript
         * export declare function safeDel(obj: any, path: string | string[]): any;
         */

        /* dependencies
         * isUndef castPath 
         */

        exports = function exports(obj, path) {
            path = castPath(path, obj);
            var prop, ret;
            /* eslint-disable no-cond-assign */

            while ((prop = path.shift())) {
                ret = obj[prop];
                if (path.length === 0) delete obj[prop];
                obj = ret;
                if (isUndef(obj)) return;
            }

            return ret;
        };

        return exports;
    })({});

    /* ------------------------------ safeSet ------------------------------ */

    _.safeSet = (function (exports) {
        /* Set value at path of object.
         *
         * If a portion of path doesn't exist, it's created.
         *
         * |Name|Type        |Desc                   |
         * |----|------------|-----------------------|
         * |obj |object      |Object to modify       |
         * |path|array string|Path of property to set|
         * |val |*           |Value to set           |
         */

        /* example
         * var obj = {};
         * safeSet(obj, 'a.aa.aaa', 1); // obj = {a: {aa: {aaa: 1}}}
         * safeSet(obj, ['a', 'aa'], 2); // obj = {a: {aa: 2}}
         * safeSet(obj, 'a.b', 3); // obj = {a: {aa: 2, b: 3}}
         */

        /* typescript
         * export declare function safeSet(obj: any, path: string | string[], val: any): void;
         */

        /* dependencies
         * castPath isUndef 
         */

        exports = function exports(obj, path, val) {
            path = castPath(path, obj);
            var lastProp = path.pop(),
                prop;
            prop = path.shift();

            while (!isUndef(prop)) {
                if (!obj[prop]) obj[prop] = {};
                obj = obj[prop];
                prop = path.shift();
            }

            obj[lastProp] = val;
        };

        return exports;
    })({});

    /* ------------------------------ safeStorage ------------------------------ */

    _.safeStorage = (function (exports) {
        /* Use storage safely in safari private browsing and older browsers.
         *
         * |Name        |Type  |Desc             |
         * |------------|------|-----------------|
         * |type='local'|string|local or session |
         * |return      |object|Specified storage|
         */

        /* example
         * var localStorage = safeStorage('local');
         * localStorage.setItem('licia', 'util');
         */

        /* typescript
         * export declare function safeStorage(type?: string): typeof window.localStorage;
         */

        /* dependencies
         * memStorage 
         */

        exports = function exports(type) {
            type = type || 'local';
            var ret;

            switch (type) {
                case 'local':
                    ret = window.localStorage;
                    break;

                case 'session':
                    ret = window.sessionStorage;
                    break;
            }

            try {
                // Safari private browsing
                var x = 'test-localStorage-' + Date.now();
                ret.setItem(x, x);
                var y = ret.getItem(x);
                ret.removeItem(x);
                if (y !== x) throw new Error();
            } catch (e) {
                return memStorage;
            }

            return ret;
        };

        return exports;
    })({});

    /* ------------------------------ timeAgo ------------------------------ */

    _.timeAgo = (function (exports) {
        /* Format datetime with *** time ago statement.
         *
         * |Name          |Type  |Desc                     |
         * |--------------|------|-------------------------|
         * |date          |Date  |Date to calculate        |
         * |[now=new Date]|Date  |Current date             |
         * |return        |string|Formatted time ago string|
         */

        /* example
         * var now = new Date().getTime();
         * timeAgo(now - 1000 * 6); // -> right now
         * timeAgo(now + 1000 * 15); // -> in 15 minutes
         * timeAgo(now - 1000 * 60 * 60 * 5, now); // -> 5 hours ago
         */

        /* typescript
         * export declare function timeAgo(date: Date | number, now?: Date | number): string;
         */

        /* dependencies
         * isDate toInt 
         */

        exports = function exports(date, now) {
            if (!isDate(date)) date = new Date(date);
            now = now || new Date();
            if (!isDate(now)) now = new Date(now);
            var diff = (now - date) / 1000,
                i = 0,
                ago = diff > 0;
            diff = Math.abs(diff);

            while (diff >= secArr[i] && i < secArrLen) {
                diff /= secArr[i];
                i++;
            }

            diff = toInt(diff);
            i *= 2;
            if (diff > (i === 0 ? 9 : 1)) i += 1;
            return format(diff, i, ago);
        };

        var secArr = [60, 60, 24, 7, 365 / 7 / 12, 12],
            secArrLen = secArr.length;

        function format(diff, i, ago) {
            return exports.i18n[i][ago ? 0 : 1].replace('%s', diff);
        }

        exports.i18n = [
            ['just now', 'right now'],
            ['%s seconds ago', 'in %s seconds'],
            ['1 minute ago', 'in 1 minute'],
            ['%s minutes ago', 'in %s minutes'],
            ['1 hour ago', 'in 1 hour'],
            ['%s hours ago', 'in %s hours'],
            ['1 day ago', 'in 1 day'],
            ['%s days ago', 'in %s days'],
            ['1 week ago', 'in 1 week'],
            ['%s weeks ago', 'in %s weeks'],
            ['1 month ago', 'in 1 month'],
            ['%s months ago', 'in %s months'],
            ['1 year ago', 'in 1 year'],
            ['%s years ago', 'in %s years']
        ];

        return exports;
    })({});

    /* ------------------------------ timeTaken ------------------------------ */

    _.timeTaken = (function (exports) {
        /* Get execution time of a function.
         *
         * |Name  |Type    |Desc                    |
         * |------|--------|------------------------|
         * |fn    |function|Function to measure time|
         * |return|number  |Execution time, ms      |
         */

        /* example
         * timeTaken(function () {
         *     // Do something.
         * }); // -> Time taken to execute given function.
         */

        /* typescript
         * export declare function timeTaken(fn: Function): number;
         */

        /* dependencies
         * perfNow 
         */

        exports = function exports(fn) {
            var start = perfNow();
            fn();
            return perfNow() - start;
        };

        return exports;
    })({});

    /* ------------------------------ times ------------------------------ */

    _.times = (function (exports) {
        /* Invoke given function n times.
         *
         * |Name  |Type    |Desc                          |
         * |------|--------|------------------------------|
         * |n     |number  |Times to invoke function      |
         * |fn    |function|Function invoked per iteration|
         * |[ctx] |*       |Function context              |
         * |return|array   |Array of results              |
         */

        /* example
         * times(3, String); // -> ['0', '1', '2']
         */

        /* typescript
         * export declare function times<T>(n: number, fn: (n: number) => T, ctx?: any): T[];
         */

        /* dependencies
         * optimizeCb 
         */

        exports = function exports(n, fn, ctx) {
            var ret = Array(Math.max(0, n));
            fn = optimizeCb(fn, ctx, 1);

            for (var i = 0; i < n; i++) {
                ret[i] = fn(i);
            }

            return ret;
        };

        return exports;
    })({});

    /* ------------------------------ toDate ------------------------------ */

    _.toDate = (function (exports) {
        /* Convert value to a Date.
         *
         * |Name  |Type|Desc            |
         * |------|----|----------------|
         * |val   |*   |Value to convert|
         * |return|Date|Converted Date  |
         */

        /* example
         * toDate('20180501');
         * toDate('2018-05-01');
         * toDate(1525107450849);
         */

        /* typescript
         * export declare function toDate(val: any): Date;
         */

        /* dependencies
         * isDate isStr 
         */

        exports = function exports(val) {
            if (!val) return new Date();
            if (isDate(val)) return val;

            if (isStr(val)) {
                var match = val.match(regDate);
                if (match) return new Date(match[1], match[2] - 1, match[3]);
            }

            return new Date(val);
        };

        var regDate = /^(\d{4})-?(\d{2})-?(\d{1,2})$/;

        return exports;
    })({});

    /* ------------------------------ toEl ------------------------------ */

    _.toEl = (function (exports) {
        /* Convert html string to dom elements.
         *
         * There should be only one root element.
         *
         * |Name  |Type   |Desc        |
         * |------|-------|------------|
         * |str   |string |Html string |
         * |return|element|Html element|
         */

        /* example
         * toEl('<div>test</div>');
         */

        /* typescript
         * export declare function toEl(str: string): Element;
         */
        var doc = document;

        exports = function exports(str) {
            var fragment = doc.createElement('body');
            fragment.innerHTML = str;
            return fragment.childNodes[0];
        };

        if (doc.createRange && doc.body) {
            var range = doc.createRange();
            range.selectNode(doc.body);

            if (range.createContextualFragment) {
                exports = function exports(str) {
                    return range.createContextualFragment(str).childNodes[0];
                };
            }
        }

        return exports;
    })({});

    /* ------------------------------ topoSort ------------------------------ */

    _.topoSort = (function (exports) {
        /* Topological sorting algorithm.
         *
         * |Name  |Type |Desc        |
         * |------|-----|------------|
         * |edges |array|Dependencies|
         * |return|array|Sorted order|
         */

        /* example
         * topoSort([[1, 2], [1, 3], [3, 2]]); // -> [1, 3, 2]
         */

        /* typescript
         * export declare function topoSort(edges: any[]): any[];
         */
        exports = function exports(edges) {
            return sort(uniqueNodes(edges), edges);
        };

        function uniqueNodes(arr) {
            var ret = [];

            for (var i = 0, len = arr.length; i < len; i++) {
                var edge = arr[i];
                if (ret.indexOf(edge[0]) < 0) ret.push(edge[0]);
                if (ret.indexOf(edge[1]) < 0) ret.push(edge[1]);
            }

            return ret;
        }

        function sort(nodes, edges) {
            var cursor = nodes.length,
                sorted = new Array(cursor),
                visited = {},
                i = cursor;

            while (i--) {
                if (!visited[i]) visit(nodes[i], i, []);
            }

            function visit(node, i, predecessors) {
                if (predecessors.indexOf(node) >= 0) {
                    throw new Error('Cyclic dependency: ' + JSON.stringify(node));
                }

                if (visited[i]) return;
                visited[i] = true;
                var outgoing = edges.filter(function(edge) {
                    return edge[0] === node;
                });
                /* eslint-disable no-cond-assign */

                if ((i = outgoing.length)) {
                    var preds = predecessors.concat(node);

                    do {
                        var child = outgoing[--i][1];
                        visit(child, nodes.indexOf(child), preds);
                    } while (i);
                }

                sorted[--cursor] = node;
            }

            return sorted;
        }

        return exports;
    })({});

    /* ------------------------------ trigger ------------------------------ */

    _.trigger = (function (exports) {
        /* Trigger browser events.
         *
         * |Name         |Type   |Desc              |
         * |-------------|-------|------------------|
         * |[el=document]|element|Element to trigger|
         * |type         |string |Event type        |
         * |options      |object |Options           |
         */

        /* example
         * trigger(document.getElementById('#test'), 'mouseup');
         * trigger('keydown', {keyCode: 65});
         */

        /* typescript
         * export declare function trigger(el: Element, type: string, options?: any);
         * export declare function trigger(type: string, options?: any);
         */

        /* dependencies
         * isStr defaults extend 
         */ // https://developer.mozilla.org/en-US/docs/Web/Guide/Events/Creating_and_triggering_events

        exports = function exports(el, type, opts) {
            if (isStr(el)) {
                opts = type;
                type = el;
                el = document;
            }

            opts = opts || {};
            defaults(opts, defOpts);
            var event = document.createEvent('Event');
            event.initEvent(type, opts.bubbles, opts.cancelable);
            delete opts.bubbles;
            delete opts.cancelable;
            extend(event, opts);
            el.dispatchEvent(event);
        };

        var defOpts = {
            bubbles: true,
            cancelable: true
        };

        return exports;
    })({});

    /* ------------------------------ upperCase ------------------------------ */

    _.upperCase = (function (exports) {
        /* Convert string to upper case.
         *
         * |Name  |Type  |Desc             |
         * |------|------|-----------------|
         * |str   |string|String to convert|
         * |return|string|Uppercased string|
         */

        /* example
         * upperCase('test'); // -> 'TEST'
         */

        /* typescript
         * export declare function upperCase(str: string): string;
         */

        /* dependencies
         * toStr 
         */

        exports = function exports(str) {
            return toStr(str).toLocaleUpperCase();
        };

        return exports;
    })({});

    return _;
}));