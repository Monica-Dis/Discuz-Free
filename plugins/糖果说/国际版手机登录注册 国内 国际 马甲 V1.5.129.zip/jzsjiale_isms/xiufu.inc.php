<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_isms_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `areacode` smallint(9) NOT NULL DEFAULT '86',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `islogin` int(11) NOT NULL DEFAULT '0',
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX phone_name (`phone`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_isms_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `areacode` smallint(9) NOT NULL DEFAULT '86',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `operationuid` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(255) NOT NULL DEFAULT '',
  `port` int(6) NOT NULL DEFAULT '0',
  `browser` varchar(255) NOT NULL DEFAULT '',
  `os` varchar(255) NOT NULL DEFAULT '',
  `device` varchar(255) NOT NULL DEFAULT '',
  `useragent` varchar(1024) NOT NULL DEFAULT '',
  `record` text NOT NULL DEFAULT '',
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX phone_name (`phone`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_isms_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `areacode` smallint(9) NOT NULL DEFAULT '86',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `seccode` varchar(50) NOT NULL DEFAULT '',
  `expire` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX phone_name (`phone`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_isms_smslist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `areacode` smallint(9) NOT NULL DEFAULT '86',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `seccode` varchar(50) NOT NULL DEFAULT '',
  `ip` varchar(255) NOT NULL DEFAULT '',
  `port` int(6) NOT NULL DEFAULT '0',
  `msg` varchar(1024) NOT NULL DEFAULT '',
  `type` int(10) unsigned NOT NULL DEFAULT '0',
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX phone_name (`phone`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_isms_areacode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(255) NOT NULL DEFAULT '',
  `countrycn` varchar(255) NOT NULL DEFAULT '',
  `code` varchar(255) NOT NULL DEFAULT '',
  `areacode` smallint(9) NOT NULL DEFAULT '86',
  `img` varchar(1024) NOT NULL DEFAULT '',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` int(11) unsigned NOT NULL,
   PRIMARY KEY (`id`),
   INDEX country_name (`country`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_isms_wenti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL DEFAULT '',
  `question` varchar(255) NOT NULL DEFAULT '',
  `answer` varchar(1024) NOT NULL DEFAULT '',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `status` int(10) unsigned NOT NULL DEFAULT '0',
  `dateline` int(11) unsigned NOT NULL,
   PRIMARY KEY (`id`),
   INDEX question_name (`question`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_jzsjiale_isms_freeze` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT '0',
  `freeze` tinyint(1) NOT NULL DEFAULT '0',
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
   INDEX uid_name (`uid`)
) ENGINE=MyISAM;
EOF;

runquery($sql);


$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_isms_user'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_user')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('uid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_user')." add `uid` int(11) NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('areacode', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_user')." add `areacode` smallint(9) NOT NULL DEFAULT '86';";
    DB::query($sql);
}
if(!in_array('phone', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_user')." add `phone` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('islogin', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_user')." add `islogin` int(11) NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_user')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}
unset($col_field);



$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_isms_log'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('uid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `uid` int(11) NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('username', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `username` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('areacode', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `areacode` smallint(9) NOT NULL DEFAULT '86';";
    DB::query($sql);
}
if(!in_array('phone', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `phone` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('type', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `type` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('operationuid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `operationuid` int(11) NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('ip', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `ip` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('port', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `port` int(6) NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('browser', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `browser` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('os', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `os` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('device', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `device` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('useragent', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `useragent` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('record', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `record` text NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_log')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}
unset($col_field);




$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_isms_code'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_code')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('uid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_code')." add `uid` int(11) NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('areacode', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_code')." add `areacode` smallint(9) NOT NULL DEFAULT '86';";
    DB::query($sql);
}
if(!in_array('phone', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_code')." add `phone` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('seccode', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_code')." add `seccode` varchar(50) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('expire', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_code')." add `expire` int(10) unsigned NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_code')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}
unset($col_field);



$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_isms_smslist'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_smslist')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('uid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_smslist')." add `uid` int(11) NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('username', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_smslist')." add `username` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('areacode', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_smslist')." add `areacode` smallint(9) NOT NULL DEFAULT '86';";
    DB::query($sql);
}
if(!in_array('phone', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_smslist')." add `phone` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('seccode', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_smslist')." add `seccode` varchar(50) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('ip', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_smslist')." add `ip` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('port', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_smslist')." add `port` int(6) NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('msg', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_smslist')." add `msg` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('type', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_smslist')." add `type` int(10) unsigned NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('status', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_smslist')." add `status` int(10) unsigned NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_smslist')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}
unset($col_field);



$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_isms_areacode'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_areacode')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('country', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_areacode')." add `country` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('countrycn', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_areacode')." add `countrycn` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('code', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_areacode')." add `code` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('areacode', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_areacode')." add `areacode` smallint(9) NOT NULL DEFAULT '86';";
    DB::query($sql);
}
if(!in_array('img', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_areacode')." add `img` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('sort', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_areacode')." add `sort` int(10) unsigned NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('status', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_areacode')." add `status` int(10) unsigned NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_areacode')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}
unset($col_field);


$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_isms_wenti'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_wenti')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('type', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_wenti')." add `type` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('question', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_wenti')." add `question` varchar(255) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('answer', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_wenti')." add `answer` varchar(1024) NOT NULL DEFAULT '';";
    DB::query($sql);
}
if(!in_array('sort', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_wenti')." add `sort` int(10) unsigned NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('status', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_wenti')." add `status` int(10) unsigned NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_wenti')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}
unset($col_field);


$query = DB::query("SHOW COLUMNS FROM ".DB::table('jzsjiale_isms_freeze'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('id', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_freeze')." add `id` int(11) NOT NULL AUTO_INCREMENT;";
    DB::query($sql);
}
if(!in_array('uid', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_freeze')." add `uid` int(11) NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('freeze', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_freeze')." add `freeze` tinyint(1) NOT NULL DEFAULT '0';";
    DB::query($sql);
}
if(!in_array('dateline', $col_field)){
    $sql = "Alter table ".DB::table('jzsjiale_isms_freeze')." add `dateline` int(11) unsigned NOT NULL;";
    DB::query($sql);
}
unset($col_field);


$query = DB::query("SHOW COLUMNS FROM ".DB::table('common_member_status'));
while($row = DB::fetch($query)) {
    $col_field[]=$row['Field'];
}

if(!in_array('port', $col_field)){
    $sql = "Alter table ".DB::table('common_member_status')." add `port` smallint(6) NOT NULL DEFAULT '0';";
    DB::query($sql);
}
unset($col_field);

cpmsg('jzsjiale_isms:xiufuok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms', 'succeed');

?>