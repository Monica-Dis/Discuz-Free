<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class ISMSTools
{

    public $accesskeyid;
    
    public $accesskeysecret;
    
    public function __construct($accesskeyid = "",$accesskeysecret = ""){
        $this->accesskeyid = $accesskeyid;
        $this->accesskeysecret = $accesskeysecret ;
    }
    
    public function smssend($code,$expire,$type=0,$uid,$areacode = '86',$phoneNumbers = "",$signName = "",$templateCode = "",$templateParam = "",$ip = "")
    {
        if(empty($phoneNumbers) || empty($signName) || empty($templateCode) || empty($templateParam)){
            return;
        }
        
        if(empty($areacode)){
            $areacode = '86';
        }
        loadcache('plugin');
        global $_G;
        $webbianma = $_G['charset'];
        if(!empty($uid) && !in_array($uid,array("0",0))){
            $user = getuserbyuid($uid);
            $username = $user['username'];
        }else{
            $username = "#";
        }

        
        $isok = false;

        $retdata = "error";
        
        
        //mobile heimingdan jiance start
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];
        //haoduan heimingdan start
        if(!empty($_config['g_haoduanheimingdan'])){
            $g_haoduanheimingdan = $_config['g_haoduanheimingdan'];
            $g_haoduanheimingdan = explode(",",$g_haoduanheimingdan);
            foreach ($g_haoduanheimingdan as $hdhmd){
                if(!empty($hdhmd)){
                    $hdhmdlen = strlen($hdhmd);
                    $mobilesub = substr($phoneNumbers,0,$hdhmdlen);
                    if($mobilesub == $hdhmd){
                        $isok = false;
                        $retdata = "error";
                    
                        $smslist_heimingdan = array('dateline'=>TIMESTAMP);
                        $smslist_heimingdan['uid'] = $uid;
                        $smslist_heimingdan['username'] = $username;
                        $smslist_heimingdan['areacode'] = $areacode;
                        $smslist_heimingdan['phone'] = $phoneNumbers;
                        $smslist_heimingdan['seccode'] = $code;
                        $smslist_heimingdan['ip'] = $ip;
                        $smslist_heimingdan['msg'] = "(".$hdhmd.") hao duan hei ming dan !!!";
                        $smslist_heimingdan['type'] = $type;//type:0ceshi 1zhuce 2shenfenyanzheng 3denglu 4xiugaimima
                        $smslist_heimingdan['status'] = 0;
                        C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->insert($smslist_heimingdan,true);
                    
                        return $retdata;
                    }
                }
                
            }
            
        }
        //haoduan heimingdan end
        //shoujihao heimingdan start
        if(!empty($_config['g_mobileheimingdan'])){
            $g_mobileheimingdan = $_config['g_mobileheimingdan'];
            $g_mobileheimingdan = explode(",",$g_mobileheimingdan);
            if(in_array($phoneNumbers,$g_mobileheimingdan)){
                $isok = false;
                $retdata = "error";
            
                $smslist_heimingdan = array('dateline'=>TIMESTAMP);
                $smslist_heimingdan['uid'] = $uid;
                $smslist_heimingdan['username'] = $username;
                $smslist_heimingdan['areacode'] = $areacode;
                $smslist_heimingdan['phone'] = $phoneNumbers;
                $smslist_heimingdan['seccode'] = $code;
                $smslist_heimingdan['ip'] = $ip;
                $smslist_heimingdan['msg'] = "hei ming dan !!!";
                $smslist_heimingdan['type'] = $type;//type:0ceshi 1zhuce 2shenfenyanzheng 3denglu 4xiugaimima
                $smslist_heimingdan['status'] = 0;
                C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->insert($smslist_heimingdan,true);
            
                return $retdata;
            }
        }
        //shoujihao heimingdan end
        
        //mobile heimingdan jiance end
        
        
        //echo "==phoneNumbers:=".$phoneNumbers."---signName--".$signName.'==templateCode=='.$templateCode.'==templateParam=='.$templateParam;
        //exit;
      
        
        $g_ismsapi = $_config['g_ismsapi'];
        if(empty($g_ismsapi)){
            $g_ismsapi = "aliyun";
        }
        $ret = "";
        if($g_ismsapi == "aliyun"){
            //aliyun sms send start
            require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/interface/aliyun/aliyun.php';
            $sms = new ALIYUNISMS();
            $sms->__construct($this->accesskeyid, $this->accesskeysecret);
            
            
            if($_config['g_ismsdebug']){
                //$ret = '{"Message":"\u6ca1\u6709\u8bbf\u95ee\u6743\u9650","RequestId":"43C8D5C3-0EC7-4390-AC42-D12316AFB630","Code":"isv.BUSINESS_LIMIT_CONTROL"}';
                $ret = '{"Message":"OK","RequestId":"962AE9DB-EAF7-4098-A4FF-5F5F1B4F39B1","BizId":"108711042472^1111710451471","Code":"OK"}';
                
            }else{
                $ret = $sms->smssend($areacode,$phoneNumbers,$signName,$templateCode,$templateParam);
            }
            
            //sms send end
            
            
            //$ret = '{"Message":"\u6ca1\u6709\u8bbf\u95ee\u6743\u9650","RequestId":"43C8D5C3-0EC7-4390-AC42-D12316AFB630","Code":"isv.SMS_SIGNATURE_ILLEGAL"}';
            //$ret = '{"Message":"OK","RequestId":"962AE9DB-EAF7-4098-A4FF-5F5F1B4F39B1","BizId":"108711042472^1111710451471","Code":"OK"}';
            //echo "====".$ret;EXIT;
            $retinfo = json_decode($ret);
            
            //echo "===".$retinfo->Code;
            if($retinfo != null && $retinfo->Code == 'OK'){
                $retdata = "success";
                $isok = true;
            }elseif($retinfo != null && $retinfo->Code != 'OK'){
                $retdata = $retinfo->Code;
                $isok = false;
            }else{
                $retdata = "error";
                $isok = false;
            }
            
        }elseif($g_ismsapi == "qcloudsms"){

            //qcloudsms sms send start
            require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/interface/qcloudsms/qcloudsms.php';

            $qcloudsms = new QCLOUDSMSISMS();
            $qcloudsms->__construct($this->accesskeyid, $this->accesskeysecret);

            if($_config['g_ismsdebug']){
                //$ret = '{"code":"15","msg":"Remote service error","sub_code":"isv.BUSINESS_LIMIT_CONTROL","sub_msg":"\u89e6\u53d1\u5206\u949f\u7ea7\u6d41\u63a7Permits:1","request_id":"uu88g17ys4q"}';
                $ret = '{"result":0,"errmsg":"OK","ext":"","sid":"18:ce30e45b9ea243f0b6715874b012a599","fee":1}';

            }else{

                $paramarr = json_decode($templateParam,true);
                $templateParamQ = array($paramarr["code"]);

                $ret = $qcloudsms->smssend($areacode,$phoneNumbers,$signName,$templateCode,$templateParamQ);
            }


            //sms send end

            //$ret = '{"result":1031,"errmsg":"package format error, sdkappid not have this tpl_id","ext":""}';
            //{"ActionStatus":"FAIL","ErrorCode":60012,"ErrorInfo":"Rest Api need sdkappid"}
            //echo "====".$ret;EXIT;
            $retinfo = json_decode($ret);

            //echo "===".$retinfo->Code;
            if($retinfo != null && $retinfo->result == 0 && $retinfo->ActionStatus != 'FAIL'){
                $retdata = "success";
                $isok = true;
            }elseif($retinfo != null && $retinfo->result != 0){
                $retdata = $retinfo->result;
                $isok = false;
            }else{
                $retdata = "error";
                $isok = false;
            }
        }elseif($g_ismsapi == "smsbao"){

            //smsbao sms send start
            require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/interface/smsbao/smsbao.php';

            $smsbao = new SMSBAOISMS();
            $smsbao->__construct($this->accesskeyid, $this->accesskeysecret);

            if($_config['g_ismsdebug']){
                $ret = '0';
            }else{
                $templateCode = str_replace('{code}',$code,$templateCode);
                $ret = $smsbao->smssend($areacode,$phoneNumbers,$signName,$templateCode);
            }


            //sms send end

            if($ret == null || $ret == ''){
                $ret = 40;
            }

            if($ret == 0 || $ret == '0'){
                $retdata = "success";
                $isok = true;
            }elseif($ret != 0 && $ret != '0'){
                $retdata = $ret;
                $isok = false;
            }else{
                $retdata = "error";
                $isok = false;
            }
        }elseif($g_ismsapi == "smscn"){

            //qcloudsms sms send start
            require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/interface/smscn/smscn.php';

            $smscn = new SMSCNISMS();
            $smscn->__construct($this->accesskeyid, $this->accesskeysecret);

            if($_config['g_ismsdebug']){
                $ret = '{"stat":"100","message":"SUCCESS"}';
            }else{
                $ret = $smscn->smssend($areacode,$phoneNumbers,$signName,$templateCode,$templateParam);
            }


            //sms send end

            //$ret = '{"result":1031,"errmsg":"package format error, sdkappid not have this tpl_id","ext":""}';
            //{"ActionStatus":"FAIL","ErrorCode":60012,"ErrorInfo":"Rest Api need sdkappid"}
            //echo "====".$ret;EXIT;

            $retinfo = json_decode($ret);

            //var_dump($retinfo);
            //echo "===".$retinfo->stat;
            if($retinfo != null && ($retinfo->stat == "100" || $retinfo->stat == 100)){
                $retdata = "success";
                $isok = true;
            }elseif($retinfo != null && $retinfo->stat != "100" && $retinfo->stat != 100){
                $retdata = $retinfo->stat;
                $isok = false;
            }else{
                $retdata = "error";
                $isok = false;
            }
            if($_G['charset'] == 'gbk'){
                $ret = '{"stat":"'.$retinfo->stat.'","message":"'.diconv($retinfo->message,'UTF-8','GBK').'"}';
            }
        }elseif($g_ismsapi == "selfsms"){

            //self sms send start
            require_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/interface/selfsms/selfsms.php';

            $selfsms = new SELFISMS();
            $selfsms->__construct($this->accesskeyid, $this->accesskeysecret);

            if($_config['g_ismsdebug']){
                $selfret = array('status'=>'success','code'=>'0','msg'=>'');
                $ret = '0';
            }else{
                $selfret = $selfsms->smssend($areacode,$phoneNumbers,$signName,$templateCode,$code);
                $ret = $selfret['code'].'-'.$selfret['msg'];
            }
            //sms send end

            if($selfret['status'] == 'success'){
                $retdata = "success";
                $isok = true;
            }else{
                $retdata = "error";
                $isok = false;
            }
        }
            
            
        if($isok){
            $smscode = array('dateline'=>TIMESTAMP);
            $smscode['uid'] = $uid;
            $smscode['areacode'] = $areacode;
            $smscode['phone'] = $phoneNumbers;
            $smscode['seccode'] = $code;
            $smscode['expire'] = $expire;//guoqishijian
             
            if(C::t('#jzsjiale_isms#jzsjiale_isms_code')->insert($smscode,true)){
                $isok = true;
            }else{
                $isok = false;
            }
        }
        
        
        //if($isok){
            $smslist = array('dateline'=>TIMESTAMP);
            $smslist['uid'] = $uid;
            $smslist['username'] = $username;
            $smslist['areacode'] = $areacode;
            $smslist['phone'] = $phoneNumbers;
            $smslist['seccode'] = $code;
            $smslist['ip'] = $ip;
            $smslist['msg'] = $ret;
            $smslist['type'] = $type;//type:0ceshi 1zhuce 2shenfenyanzheng 3denglu 4xiugaimima
            $smslist['status'] = ($retdata == "success")?1:0;
            
            if(C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->insert($smslist,true)){
                $isok = true;
            }else{
                $isok = false;
            }
        //}
      
        
        return $retdata;
    }
}