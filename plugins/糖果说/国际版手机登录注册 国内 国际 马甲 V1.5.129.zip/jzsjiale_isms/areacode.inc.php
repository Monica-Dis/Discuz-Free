<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
loadcache('plugin');
global $_G, $lang;

if($act=='add'){
    if(submitcheck('submit')){

        $area = $_GET['area'];
        $dsp = array('dateline'=>TIMESTAMP);
        $dsp['country'] = daddslashes(trim($area['country']));
        $dsp['countrycn'] = daddslashes(trim($area['countrycn']));
        $dsp['code'] = daddslashes(trim($area['code']));
        $dsp['areacode'] = daddslashes(trim($area['areacode']));
        $dsp['img'] = daddslashes(trim($area['img']));
        $dsp['sort'] = daddslashes(trim($area['sort']));
        $dsp['status'] = daddslashes(trim($area['status']));

        /*
        if($_FILES['img']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['img'], 'common') && $upload->save(1)) {
                $dsp['img'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $dsp['img'] = !empty($_GET['img'])?trim($_GET['img']):"";
        }
*/
        if(empty($dsp['img'])){
            cpmsg('jzsjiale_isms:aimg_null', '', 'error');
        }
/*
        $pattern = "/^[a-zA-z]+:\/\/[^\s]*[.]{1}(gif|jpg|png|bmp|jpeg|SS2)$/is";
        if ( !preg_match( $pattern, $dsp['img'] ) )
        {
            cpmsg('jzsjiale_isms:aimg_feifa', '', 'error');
        }
*/

        if(empty($dsp['country'])){
            cpmsg('jzsjiale_isms:acountry_null', '', 'error');
        }

        if(empty($dsp['countrycn'])){
            cpmsg('jzsjiale_isms:acountrycn_null', '', 'error');
        }

        if(empty($dsp['code'])){
            cpmsg('jzsjiale_isms:acode_null', '', 'error');
        }

        if(empty($dsp['areacode'])){
            cpmsg('jzsjiale_isms:aareacode_null', '', 'error');
        }




        if(C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->insert($dsp,true)){
            recache();
            cpmsg('jzsjiale_isms:addok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode', 'succeed');
        }else{
            cpmsg('jzsjiale_isms:error', '', 'error');
        }

    }

    echo '<div class="colorbox"><h4>'.plang('aboutareacode').'</h4>'.
        '<table cellspacing="0" cellpadding="3"><tr>'.
        '<td valign="top">'.plang('areacodedescription').'</td></tr></table>'.
        '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';


    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=add', 'enctype');

    showsubmit('submit', 'submit');

    showtableheader(plang('addareacodetitle'), '');

    showsetting(plang('acountry'),'area[country]','','text','','',plang('acountry_msg'));
    showsetting(plang('acountrycn'),'area[countrycn]','','text','','',plang('acountrycn_msg'));
    showsetting(plang('acode'),'area[code]','','text','','',plang('acode_msg'));
    showsetting(plang('aareacode'),'area[areacode]','','text','','',plang('aareacode_msg'));
    showsetting(plang('aimg'),'area[img]','','text','','',plang('aimg_msg'));
    //showsetting(plang('aimg'), 'img', '', 'filetext','','',plang('aimg_msg'),'','aimg');
    showsetting(plang('asort'),'area[sort]','0','radio','','',plang('asort_msg'));
    showsetting(plang('astatus'),'area[status]','1','radio','','',plang('astatus_msg'));

    showsubmit('submit', 'submit');
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/


    dexit();
}elseif($act=='delete'){
    if($formhash != FORMHASH){
        cpmsg('jzsjiale_isms:formhash_error', '', 'error');
    }
	$id = dintval($_GET['id']);

	$area = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->fetch($id);
	if(empty($area))
		cpmsg('jzsjiale_isms:empty', '', 'error');
	if(submitcheck('submit')){
		C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->deletebyid($id);
		recache();
		cpmsg('jzsjiale_isms:delok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&page='.$_GET['page'], 'succeed');

	}
	cpmsg('jzsjiale_isms:deltitle','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=delete&submit=yes&id='.$id.'&page='.$_GET['page'],'form',array('title' => $area['countrycn']));
}elseif($act=='changestatus'){
    if($formhash != FORMHASH){
        cpmsg('jzsjiale_isms:formhash_error', '', 'error');
    }
	$id = dintval($_GET['id']);
	$status = dintval($_GET['status']);
	$area = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->fetch($id);
	if(empty($area))
		cpmsg('jzsjiale_isms:empty', '', 'error');

		C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->updatestatus($id,$status);
		recache();
		cpmsg('jzsjiale_isms:operationok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&page='.$_GET['page'], 'succeed');

}elseif($act=='changeallstatus'){
    if($formhash != FORMHASH){
        cpmsg('jzsjiale_isms:formhash_error', '', 'error');
    }
	$status = dintval($_GET['status']);
		C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->setallstatus($status);
		recache();
		cpmsg('jzsjiale_isms:operationok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode', 'succeed');

}elseif($act=='ischangyong'){
    if($formhash != FORMHASH){
        cpmsg('jzsjiale_isms:formhash_error', '', 'error');
    }
    $id = dintval($_GET['id']);
    $sort = dintval($_GET['sort']);
    $area = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->fetch($id);
    if(empty($area))
        cpmsg('jzsjiale_isms:empty', '', 'error');

    C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->updatesort($id,$sort);
    recache();
    cpmsg('jzsjiale_isms:operationok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&page='.$_GET['page'], 'succeed');

}elseif($act=='edit'){
	$id = dintval($_GET['id']);

	$area = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->fetch($id);
	if(empty($area))
		cpmsg('jzsjiale_isms:empty', '', 'error');

	if(submitcheck('submit')){
	    $area = $_GET['area'];
        $dsp = array('dateline'=>TIMESTAMP);
        $dsp['country'] = daddslashes(trim($area['country']));
        $dsp['countrycn'] = daddslashes(trim($area['countrycn']));
        $dsp['code'] = daddslashes(trim($area['code']));
        $dsp['areacode'] = daddslashes(trim($area['areacode']));
        $dsp['img'] = daddslashes(trim($area['img']));
        $dsp['sort'] = daddslashes(trim($area['sort']));
        $dsp['status'] = daddslashes(trim($area['status']));

        /*
        if($_FILES['img']) {
            if(file_exists(libfile('class/upload'))){
                require_once libfile('class/upload');
            }else{
                require_once libfile('discuz/upload', 'class');
            }
            $upload = new discuz_upload();
            if($upload->init($_FILES['img'], 'common') && $upload->save(1)) {
                $dsp['img'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
            }
        } else {
            $dsp['img'] = !empty($_GET['img'])?trim($_GET['img']):"";
        }
*/
        if(empty($dsp['img'])){
            cpmsg('jzsjiale_isms:aimg_null', '', 'error');
        }
/*
        $pattern = "/^[a-zA-z]+:\/\/[^\s]*[.]{1}(gif|jpg|png|bmp|jpeg|SS2)$/is";
        if ( !preg_match( $pattern, $dsp['img'] ) )
        {
            cpmsg('jzsjiale_isms:aimg_feifa', '', 'error');
        }
*/

        if(empty($dsp['country'])){
            cpmsg('jzsjiale_isms:acountry_null', '', 'error');
        }

        if(empty($dsp['countrycn'])){
            cpmsg('jzsjiale_isms:acountrycn_null', '', 'error');
        }

        if(empty($dsp['code'])){
            cpmsg('jzsjiale_isms:acode_null', '', 'error');
        }
        if(empty($dsp['areacode'])){
            cpmsg('jzsjiale_isms:aareacode_null', '', 'error');
        }

		if(C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->update($id,$dsp)){
		    recache();
			cpmsg('jzsjiale_isms:editok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode', 'succeed');
		}else{
			cpmsg('jzsjiale_isms:error', '', 'error');
		}



	}
	echo '<div class="colorbox"><h4>'.plang('aboutareacode').'</h4>'.
        '<table cellspacing="0" cellpadding="3"><tr>'.
        '<td valign="top">'.plang('areacodedescription').'</td></tr></table>'.
        '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';


    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=edit', 'enctype');

    showsubmit('submit', 'submit');

    echo'<input type="hidden" value="'.dhtmlspecialchars($area['id']).'" name="id"/>';
    showtableheader(plang('editareacodetitle'), '');

    showsetting(plang('acountry'),'area[country]',$area['country'],'text','','',plang('acountry_msg'));
    showsetting(plang('acountrycn'),'area[countrycn]',$area['countrycn'],'text','','',plang('acountrycn_msg'));
    showsetting(plang('acode'),'area[code]',$area['code'],'text','','',plang('acode_msg'));
    showsetting(plang('aareacode'),'area[areacode]',$area['areacode'],'text','','',plang('aareacode_msg'));
    showsetting(plang('aimg'),'area[img]',$area['img'],'text','','',plang('aimg_msg'));
    //showsetting(plang('aimg'), 'img', $area['img'], 'filetext','','',plang('aimg_msg'),'','aimg');
    showsetting(plang('asort'),'area[sort]',$area['sort'],'radio','','',plang('asort_msg'));
    showsetting(plang('astatus'),'area[status]',$area['status'],'radio','','',plang('astatus_msg'));

    showsubmit('submit', 'submit');
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/
	dexit();
}elseif($act=='recacheareacode'){
    if($formhash != FORMHASH){
        cpmsg('jzsjiale_isms:formhash_error', '', 'error');
    }
    recache();

    cpmsg('jzsjiale_isms:cache_success', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode', 'succeed');

    dexit();

}


function recache(){

    $allareacode = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->getallbystatus(1);
    $allareacodesettings = array('jisms_allareacode' => serialize($allareacode));
    C::t('common_setting')->update_batch($allareacodesettings);

    $commonareacode = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->getallbysort(1);
    $commonareacodesettings = array('jisms_commonareacode' => serialize($commonareacode));
    C::t('common_setting')->update_batch($commonareacodesettings);

    updatecache('setting');
}


/////////tip start

echo '<div class="colorbox"><h4>'.plang('aboutareacode').'</h4>'.
    '<table cellspacing="0" cellpadding="3"><tr>'.
    '<td valign="top">'.plang('areacodedescription').'</td></tr></table>'.
    '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

/////////tip end

echo '<link rel="stylesheet" type="text/css" href="source/plugin/jzsjiale_isms/static/css/tel/intlTelInput.css" />';

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode', 'enctype');


$keyword = daddslashes(trim($_GET['keyword']));
$areacodesearch = daddslashes(trim($_GET['areacodesearch']));

$page = intval($_GET['page']);
$page = $page > 0 ? $page : 1;
$pagesize = 20;
$start = ($page - 1) * $pagesize;

//20170703start
$map = array();
if(!empty($keyword)){
    if(!$areacodesearch){
        $map['keyword'] = $keyword;
    }else{
        $map['areacode'] = $keyword;
    }

}


$allsmsuser = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->range_by_map($map,$start,$pagesize,'DESC');
$count = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->count_by_map($map);


showtablerow('', array('width="150"', 'width="150"', 'width="150"', ''), array(
plang('countryareacode'),
"<input size=\"20\" name=\"keyword\" type=\"text\" value=\"$keyword\" />
<input class=\"btn\" type=\"submit\" value=\"" . cplang('search') . "\" />"
    )
);

showtableheader(plang('areacodelist').'(&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=add" style="color:red;">'.plang('addareacode').'</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=recacheareacode&formhash='.FORMHASH.'" style="color:red;">'.plang('recacheareacode').'</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=changeallstatus&status=1&formhash='.FORMHASH.'" style="color:red;">'.plang('allenable').'</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=changeallstatus&status=0&formhash='.FORMHASH.'" style="color:red;">'.plang('alldisable').'</a>&nbsp;&nbsp;&nbsp;&nbsp;)');
showsubtitle(plang('areacodelisttitle'));
foreach($allsmsuser as $d){
    showtablerow('', array('width="50"'), array(
    $d['id'],
    $d['countrycn'],
    $d['country'],
    $d['code'],
    $d['areacode'],
    '<div class="iti__flag iti__'.$d['img'].'"></div>',
    '<span title="'.($d['sort']?plang('yes'):plang('no')).'">'.($d['sort']?'<span style="color:green;">'.plang('yes').'</span>':'<span style="color:red;">'.plang('no').'</span>').'</span>',
    '<span title="'.($d['status']?plang('yes'):plang('no')).'">'.($d['status']?'<span style="color:green;">'.plang('yes').'</span>':'<span style="color:red;">'.plang('no').'</span>').'</span>',
    dgmdate($d['dateline'], 'Y-m-d H:i:s'),
    ($d['sort']?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=ischangyong&sort=0&id='.$d['id'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'" style="color:red;">'.plang('quxiaochangyong').'</a>':'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=ischangyong&sort=1&id='.$d['id'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'" style="color:green;">'.plang('changyong').'</a>').'&nbsp;&nbsp;'.($d['status']?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=changestatus&status=0&id='.$d['id'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'" style="color:red;">'.plang('disable').'</a>':'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=changestatus&status=1&id='.$d['id'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'" style="color:green;">'.plang('enable').'</a>').'&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=edit&id='.$d['id'].'" style="color:red;">'.plang('edit').'</a>&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&act=delete&id='.$d['id'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'" style="color:red;">'.plang('del').'</a>')
    );
}

$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&keyword='.$keyword;
$multipage = multi($count, $pagesize, $page, $mpurl);
//showsubmit('', '', '', '', $multipage);


//search start
showsubmit('', '', '', '', $multipage);

//search end


showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/




function plang($str) {
    return lang('plugin/jzsjiale_isms', $str);
}
//From: d'.'is'.'m.ta'.'obao.com
?>