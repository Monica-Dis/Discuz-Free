<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$act = $_GET['act'];
loadcache('plugin');
global $_G, $lang;


require_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/ismstools.inc.php';

if($act=='sendtest'){
    if(submitcheck('submit')){

        $setting = $_GET['setting'];
        $dsp = array();
        $dsp['phone'] = daddslashes(trim($setting['phone']));
        $dsp['areacode'] = daddslashes(trim($setting['areacode']));
         
        if(empty($dsp['phone'])){
            cpmsg('jzsjiale_isms:smssendphone_null', '', 'error');
        }
        if(empty($dsp['areacode'])){
            $dsp['areacode'] = 86;
        }

        if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
            @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
            $utils = new ISMSUtils();
        }
        if(!$utils->isMobile($dsp['phone'],$dsp['areacode'])){
            cpmsg('jzsjiale_isms:smssendphoneerror_null', '', 'error');
        }

        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];
        $g_accesskeyid = $_config['g_accesskeyid'];
        $g_accesskeysecret = $_config['g_accesskeysecret'];
        $webbianma = $_G['charset'];
        $g_xiane = $_config['g_xiane'];
        $g_isopenhtmlspecialchars = !empty($_config['g_isopenhtmlspecialchars'])?true:false;
        
        if(empty($g_accesskeyid) || empty($g_accesskeysecret)){
            cpmsg('jzsjiale_isms:noappkey', '', 'error');
        }

        $smsareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
        $smsareacode = (array)unserialize($smsareacode['jisms_allareacode']);

        $areacodestatus = $utils->searchGetOne($dsp['areacode'],'areacode','status',$smsareacode);
        if(!$areacodestatus){
            cpmsg('jzsjiale_isms:areacodestatuserror', '', 'error');
        }
        
        
        $phonesendcount = C::t('#jzsjiale_isms#jzsjiale_isms_smslist')->count_by_phone_day($dsp['phone']);
 
        if($phonesendcount >= $g_xiane){
            cpmsg('jzsjiale_isms:smsxiane', '', 'error');
        }
        
        $code = $utils->generate_code();
        
        if(empty($code) || $code == null){
            cpmsg('jzsjiale_isms:generatecodeerror', '', 'error');
        }

        //$g_yanzhengid = $_config['g_yanzhengid'];
        //$g_yanzhengsign = $_config['g_yanzhengsign'];
        
        if($dsp['areacode'] != '86'){
            $g_yanzhengid = $_config['g_gjyanzhengid'];
            $g_yanzhengsign = $_config['g_gjyanzhengsign'];
        }else{
            $g_yanzhengid = $_config['g_yanzhengid'];
            $g_yanzhengsign = $_config['g_yanzhengsign'];
        }
    
        if(empty($g_yanzhengid)){
            cpmsg('jzsjiale_isms:noyanzhengid', '', 'error');
        }
        if(empty($g_yanzhengsign)){
            cpmsg('jzsjiale_isms:noyanzhengsign', '', 'error');
        }
       
        
        $sms_param_array = array();
        $sms_param_array['code']=(string)$code;
        
        
        $sms_param = json_encode($sms_param_array);
      
        
        $g_yanzhengsign=$utils->getbianma($g_yanzhengsign,$webbianma,$g_isopenhtmlspecialchars);
        $g_yanzhengid=$utils->getbianma($g_yanzhengid,$webbianma,$g_isopenhtmlspecialchars);
        
        //quoqishijian
        $g_youxiaoqi = $_config['g_youxiaoqi'];
        if(empty($g_youxiaoqi)){
            $g_youxiaoqi = 600;
        }
        //echo "====".date('Y-m-d H:i:s',strtotime("+".$g_youxiaoqi." second"));exit;
        $expire = strtotime("+".$g_youxiaoqi." second");

        $uid = $_G['uid'];
        if(!$uid){
            cpmsg('jzsjiale_isms:nologin', '', 'error');
        }
        $ismstools = new ISMSTools();
        $ismstools->__construct($g_accesskeyid, $g_accesskeysecret);
        $retdata = $ismstools->smssend($code,$expire,0,$uid,$dsp['areacode'],$dsp['phone'],$g_yanzhengsign,$g_yanzhengid,$sms_param);

        switch ($retdata){
            case 'success':
                cpmsg('jzsjiale_isms:smssuccess', '', 'success');
                break;
            case 'error':
                cpmsg('jzsjiale_isms:smserror', '', 'error');
                break;
            case 'isv.BUSINESS_LIMIT_CONTROL':
                cpmsg('jzsjiale_isms:isvBUSINESS_LIMIT_CONTROL', '', 'error');
                break;
            case 'isv.MOBILE_NUMBER_ILLEGAL':
                cpmsg('jzsjiale_isms:isvMOBILE_NUMBER_ILLEGAL', '', 'error');
                break;
            case 'isv.SMS_TEMPLATE_ILLEGAL':
                cpmsg('jzsjiale_isms:isvSMS_TEMPLATE_ILLEGAL', '', 'error');
                break;
            case 'isv.SMS_SIGNATURE_ILLEGAL':
                cpmsg('jzsjiale_isms:isvSMS_SIGNATURE_ILLEGAL', '', 'error');
                break;
            case 'isv.AMOUNT_NOT_ENOUGH':
                cpmsg('jzsjiale_isms:isvAMOUNT_NOT_ENOUGH', '', 'error');
                break;
            case 'isv.OUT_OF_SERVICE':
                cpmsg('jzsjiale_isms:isvOUT_OF_SERVICE', '', 'error');
                break;
            case 'isv.INVALID_PARAMETERS':
                cpmsg('jzsjiale_isms:isvINVALID_PARAMETERS', '', 'error');
                break;
            case 'isp.RAM_PERMISSION_DENY':
                cpmsg('jzsjiale_isms:ispRAM_PERMISSION_DENY', '', 'error');
                break;
            case 'SignatureDoesNotMatch':
                cpmsg('jzsjiale_isms:SignatureDoesNotMatch', '', 'error');
                break;
            case 'InvalidTimeStamp.Expired':
                cpmsg('jzsjiale_isms:InvalidTimeStampExpired', '', 'error');
                break;
            case '1001':
                cpmsg('jzsjiale_isms:qcloudsmserr1001', '', 'error');
                break;
            case '1002':
                cpmsg('jzsjiale_isms:qcloudsmserr1002', '', 'error');
                break;
            case '1003':
                cpmsg('jzsjiale_isms:qcloudsmserr1003', '', 'error');
                break;
            case '1004':
                cpmsg('jzsjiale_isms:qcloudsmserr1004', '', 'error');
                break;
            case '1006':
                cpmsg('jzsjiale_isms:qcloudsmserr1006', '', 'error');
                break;
            case '1007':
                cpmsg('jzsjiale_isms:qcloudsmserr1007', '', 'error');
                break;
            case '1008':
                cpmsg('jzsjiale_isms:qcloudsmserr1008', '', 'error');
                break;
            case '1009':
                cpmsg('jzsjiale_isms:qcloudsmserr1009', '', 'error');
                break;
            case '1011':
                cpmsg('jzsjiale_isms:qcloudsmserr1011', '', 'error');
                break;
            case '1012':
                cpmsg('jzsjiale_isms:qcloudsmserr1012', '', 'error');
                break;
            case '1013':
                cpmsg('jzsjiale_isms:qcloudsmserr1013', '', 'error');
                break;
            case '1014':
                cpmsg('jzsjiale_isms:qcloudsmserr1014', '', 'error');
                break;
            case '1015':
                cpmsg('jzsjiale_isms:qcloudsmserr1015', '', 'error');
                break;
            case '1016':
                cpmsg('jzsjiale_isms:qcloudsmserr1016', '', 'error');
                break;
            case '1017':
                cpmsg('jzsjiale_isms:qcloudsmserr1017', '', 'error');
                break;
            case '1018':
                cpmsg('jzsjiale_isms:qcloudsmserr1018', '', 'error');
                break;
            case '1019':
                cpmsg('jzsjiale_isms:qcloudsmserr1019', '', 'error');
                break;
            case '1020':
                cpmsg('jzsjiale_isms:qcloudsmserr1020', '', 'error');
                break;
            case '1021':
                cpmsg('jzsjiale_isms:qcloudsmserr1021', '', 'error');
                break;
            case '1022':
                cpmsg('jzsjiale_isms:qcloudsmserr1022', '', 'error');
                break;
            case '1023':
                cpmsg('jzsjiale_isms:qcloudsmserr1023', '', 'error');
                break;
            case '1024':
                cpmsg('jzsjiale_isms:qcloudsmserr1024', '', 'error');
                break;
            case '1025':
                cpmsg('jzsjiale_isms:qcloudsmserr1025', '', 'error');
                break;
            case '1026':
                cpmsg('jzsjiale_isms:qcloudsmserr1026', '', 'error');
                break;
            case '1029':
                cpmsg('jzsjiale_isms:qcloudsmserr1029', '', 'error');
                break;
            case '1030':
                cpmsg('jzsjiale_isms:qcloudsmserr1030', '', 'error');
                break;
            case '1031':
                cpmsg('jzsjiale_isms:qcloudsmserr1031', '', 'error');
                break;
            case '1032':
                cpmsg('jzsjiale_isms:qcloudsmserr1032', '', 'error');
                break;
            case '1033':
                cpmsg('jzsjiale_isms:qcloudsmserr1033', '', 'error');
                break;
            case '1036':
                cpmsg('jzsjiale_isms:qcloudsmserr1036', '', 'error');
                break;
            case '-1':
                cpmsg('jzsjiale_isms:smsbao_1', '', 'error');
                break;
            case '-2':
                cpmsg('jzsjiale_isms:smsbao_2', '', 'error');
                break;
            case '30':
                cpmsg('jzsjiale_isms:smsbao30', '', 'error');
                break;
            case '40':
                cpmsg('jzsjiale_isms:smsbao40', '', 'error');
                break;
            case '41':
                cpmsg('jzsjiale_isms:smsbao41', '', 'error');
                break;
            case '42':
                cpmsg('jzsjiale_isms:smsbao42', '', 'error');
                break;
            case '43':
                cpmsg('jzsjiale_isms:smsbao43', '', 'error');
                break;
            case '50':
                cpmsg('jzsjiale_isms:smsbao50', '', 'error');
                break;
            case '51':
                cpmsg('jzsjiale_isms:smsbao51', '', 'error');
                break;
            default:
                cpmsg('jzsjiale_isms:smserror', '', 'error');
                break;
        }
        exit();
    }

}

/////////tip start

echo '<div class="colorbox"><h4>'.plang('aboutsmssend').'</h4>'.
'<table cellspacing="0" cellpadding="3"><tr>'.
'<td valign="top">'.plang('smssenddescription').'</td></tr></table>'.
'<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

/////////tip end


// all areacode start
$allareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
$allareacode = (array)unserialize($allareacode['jisms_allareacode']);
if(!$allareacode || empty($allareacode) || $allareacode[0] === false){
    $allareacode = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->getallbystatus(1);

    $allareacodesettings = array('jisms_allareacode' => serialize($allareacode));
    C::t('common_setting')->update_batch($allareacodesettings);

    updatecache('setting');
}
// all areacode end


showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismssend&act=sendtest', 'enctype');
showtableheader(plang('smssendtitle'), '');


foreach($allareacode as $k =>$v){
    $smsareacodeselect .= '<option value="'.$v['areacode'].'" '.($v['areacode'] == 86?"selected":"").'>'.$v['code'].'&nbsp;&nbsp;&nbsp;&nbsp;'.$v['countrycn'].'('.$v['country'].')&nbsp;&nbsp;&nbsp;&nbsp;+'.$v['areacode'].'</option>';
}

// common areacode start
$commonareacode = C::t('common_setting')->fetch_all(array('jisms_commonareacode'));
$commonareacode = (array)unserialize($commonareacode['jisms_commonareacode']);
if(!$commonareacode || empty($commonareacode) || $commonareacode[0] === false){
    $commonareacode = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->getallbysort(1);
    $commonareacodesettings = array('jisms_commonareacode' => serialize($commonareacode));
    C::t('common_setting')->update_batch($commonareacodesettings);

    updatecache('setting');
}
// common areacode end
if(!empty($commonareacode)){
    foreach($commonareacode as $k =>$v){
        $commonareacodeselect .= '<option value="'.$v['areacode'].'">'.$v['code'].'&nbsp;&nbsp;&nbsp;&nbsp;'.$v['countrycn'].'('.$v['country'].')&nbsp;&nbsp;&nbsp;&nbsp;+'.$v['areacode'].'</option>';
    }
    $smsareacodeselect = $commonareacodeselect.'<option value="" disabled="">------------------------------------</option>'.$smsareacodeselect;
}

if(empty($smsareacodeselect)){
    $smsareacodeselect = '<option value="86" selected>'.plang('china').'</option>';
}
showsetting(plang('smssendareacode'),'setting[areacode]','','<select name="setting[areacode]">'.$smsareacodeselect.'</select>','',0,plang('smssendareacode_msg'),1,'smssendareacode');
showsetting(plang('smssendphone'),'setting[phone]','','text','','',plang('smssendphone_msg'));

showsubmit('submit',plang('fasong'));
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/


echo '<br/>'.plang('smsapitest').'<br/>';
echo '<br/><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismssend&smsapitest=smsapitestqcloudsms" style="color:red;">'.plang('smsapitestqcloudsms').'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismssend&smsapitest=smsapitestaliyun" style="color:red;">'.plang('smsapitestaliyun').'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=ismssend&smsapitest=smsapitestsmsbao" style="color:red;">'.plang('smsapitestsmsbao').'</a>';
echo '<br/>';
if(!empty($_GET['smsapitest'])){
    if($_GET['smsapitest'] == "smsapitestqcloudsms"){
        $ip = 'yun.tim.qq.com';
        $pingret = ping($ip);
        foreach($pingret as $pingk => $pingv){
            echo $pingv."<br/>";
        }
        if($pingret['error']=='timeout'){
            echo plang('smsapitesterror')."<br/>";
        }else{
            echo plang('smsapitestok')."<br/>";
        }
    }elseif($_GET['smsapitest'] == "smsapitestaliyun"){
        $ip = 'dysmsapi.aliyuncs.com';
        $pingret = ping($ip);
        foreach($pingret as $pingk => $pingv){
            echo $pingv."<br/>";
        }
        if($pingret['error']=='timeout'){
            echo plang('smsapitesterror')."<br/>";
        }else{
            echo plang('smsapitestok')."<br/>";
        }
    }elseif($_GET['smsapitest'] == "smsapitestsmsbao"){
        $ip = 'api.smsbao.com';
        $pingret = ping($ip);
        foreach($pingret as $pingk => $pingv){
            echo $pingv."<br/>";
        }
        if($pingret['error']=='timeout'){
            echo plang('smsapitesterror')."<br/>";
        }else{
            echo plang('smsapitestok')."<br/>";
        }
    }
}


function ping($ip,$times=4)
{
    $info = array();
    if(!is_numeric($times) ||  $times-4<0)
    {
        $times = 4;
    }
    if (PATH_SEPARATOR==':' || DIRECTORY_SEPARATOR=='/')//linux
    {
        exec("ping $ip -c $times",$info);
        if (count($info) < 9)
        {
            $info['error']='timeout';
        }
    }
    else //windows
    {
        exec("ping $ip -n $times",$info);
        if (count($info) < 10)
        {
            $info['error']='timeout';
        }
    }
    return $info;
}


function plang($str) {
    return lang('plugin/jzsjiale_isms', $str);
}
//From: d'.'is'.'m.ta'.'obao.com
?>