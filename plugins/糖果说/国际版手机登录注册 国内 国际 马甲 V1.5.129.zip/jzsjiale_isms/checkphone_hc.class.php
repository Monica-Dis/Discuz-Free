<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class CheckphoneHc
{
    function phoneaccessok($phone = "", $areacode = "") {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];
        $g_checkip = $_config['g_checkip'];
        $g_appcode = $_config['g_appcode'];
        $g_checkipcountry = $_config['g_checkipcountry'];
        $g_checkipregion = $_config['g_checkipregion'];
        $g_checkipcity = $_config['g_checkipcity'];
        $g_checkipxuni = $_config['g_checkipxuni'];
        $webbianma = $_G['charset'];
        $ret_phone_info = array();


        if($g_checkip == 8){

            if($areacode != '86'){
                if(!empty($g_checkipcountry)){
                    $areacode_arr = array_filter(array_map("trim", explode("|",$g_checkipcountry)));
                    if($this->CheckAreacode($areacode_arr, $areacode)){
                        $ret_phone_info['code'] = false;
                        return $ret_phone_info;
                    }else{
                        $ret_phone_info['ip'] = $this->get_client_ip();
                        $ret_phone_info['code'] = true;
                        return $ret_phone_info;
                    }
                }else{
                    $ret_phone_info['ip'] = $this->get_client_ip();
                    $ret_phone_info['code'] = true;
                    return $ret_phone_info;
                }
            }

            $phoneInfo = array();
            if (!empty($g_checkipregion) || !empty($g_checkipcity) || !empty($g_checkipxuni)) {
                $phoneInfo = $this->get_phone_data($phone,$g_appcode);

                if($phoneInfo === false || $phoneInfo == "" || empty($phoneInfo) || empty($phoneInfo['prov']) || empty($phoneInfo['city'])){
                    $phoneInfo = $this->get_phone_data($phone,$g_appcode);
                }
                if($phoneInfo === false || $phoneInfo == "" || empty($phoneInfo) || empty($phoneInfo['prov']) || empty($phoneInfo['city'])){
                    $ret_phone_info['code'] = false;
                    return $ret_phone_info;
                }
                $ret_phone_info['province'] = $this->getbianma($phoneInfo['prov'],$webbianma);
                $ret_phone_info['city'] = $this->getbianma($phoneInfo['city'],$webbianma);
                $ret_phone_info['operator'] = $this->getbianma($phoneInfo['isp'],$webbianma);
                $ret_phone_info['ip'] = $this->get_client_ip();
            }else{
                $ret_phone_info['code'] = true;
                return $ret_phone_info;
            }

            if(!empty($g_checkipxuni) && !empty($ret_phone_info)){
                $xuni_arr = array_filter(array_map("trim", explode("|",$g_checkipxuni)));
                if (!empty($xuni_arr) && isset($ret_phone_info['operator'])) {
                    if($this->CheckXuni($xuni_arr, $ret_phone_info['operator'])){
                        $ret_phone_info['code'] = false;
                        return $ret_phone_info;
                    }
                }
            }

            if(!empty($g_checkipregion) && !empty($ret_phone_info)){
                $region_arr = array_filter(array_map("trim", explode("|",$g_checkipregion)));
                if (!empty($region_arr) && isset($ret_phone_info['province'])) {
                    if($this->CheckRegion($region_arr, $ret_phone_info['province'])){
                        $ret_phone_info['code'] = false;
                        return $ret_phone_info;
                    }
                }
            }
            if(!empty($g_checkipcity) && !empty($ret_phone_info)){
                $city_arr = array_filter(array_map("trim", explode("|",$g_checkipcity)));
                if (!empty($city_arr) && isset($ret_phone_info['city'])) {
                    if($this->CheckCity($city_arr, $ret_phone_info['city'])){
                        $ret_phone_info['code'] = false;
                        return $ret_phone_info;
                    }
                }
            }
            $ret_phone_info['code'] = true;
            return $ret_phone_info;
        }else if($g_checkip == 9){

            if($areacode != '86'){
                if(!empty($g_checkipcountry)){
                    $areacode_arr = array_filter(array_map("trim", explode("|",$g_checkipcountry)));
                    if($this->CheckAreacode($areacode_arr, $areacode)){
                        $ret_phone_info['ip'] = $this->get_client_ip();
                        $ret_phone_info['code'] = true;
                        return $ret_phone_info;
                    }else{
                        $ret_phone_info['code'] = false;
                        return $ret_phone_info;
                    }
                }else{
                    $ret_phone_info['code'] = false;
                    return $ret_phone_info;
                }
            }

            $phoneInfo = array();
            if (!empty($g_checkipregion) || !empty($g_checkipcity)) {
                $phoneInfo = $this->get_phone_data($phone,$g_appcode);

                if($phoneInfo === false || $phoneInfo == "" || empty($phoneInfo) || empty($phoneInfo['prov']) || empty($phoneInfo['city'])){
                    $phoneInfo = $this->get_phone_data($phone,$g_appcode);
                }
                if($phoneInfo === false || $phoneInfo == "" || empty($phoneInfo) || empty($phoneInfo['prov']) || empty($phoneInfo['city'])){
                    $ret_phone_info['code'] = false;
                    return $ret_phone_info;
                }
                $ret_phone_info['province'] = $this->getbianma($phoneInfo['prov'],$webbianma);
                $ret_phone_info['city'] = $this->getbianma($phoneInfo['city'],$webbianma);
                $ret_phone_info['operator'] = $this->getbianma($phoneInfo['isp'],$webbianma);
                $ret_phone_info['ip'] = $this->get_client_ip();
            }else{
                $ret_phone_info['code'] = false;
                return $ret_phone_info;
            }


            if(!empty($g_checkipcity) && !empty($ret_phone_info)){
                $city_arr = array_filter(array_map("trim", explode("|",$g_checkipcity)));
                if (!empty($city_arr) && isset($ret_phone_info['city'])) {
                    if($this->CheckCity($city_arr, $ret_phone_info['city'])){
                        $ret_phone_info['code'] = true;
                        return $ret_phone_info;
                    }else{
                        $ret_phone_info['code'] = false;
                        return $ret_phone_info;
                    }
                }
            }
            if(!empty($g_checkipregion) && !empty($ret_phone_info)){
                $region_arr = array_filter(array_map("trim", explode("|",$g_checkipregion)));
                if (!empty($region_arr) && isset($ret_phone_info['province'])) {
                    if($this->CheckRegion($region_arr, $ret_phone_info['province'])){
                        $ret_phone_info['code'] = true;
                        return $ret_phone_info;
                    }else{
                        $ret_phone_info['code'] = false;
                        return $ret_phone_info;
                    }
                }
            }

            $ret_phone_info['code'] = false;
            return $ret_phone_info;
        }else{
            $ret_phone_info['code'] = true;
            return $ret_phone_info;
        }



    }

    private function CheckAreacode($areacode_arr,$areacode){
        foreach($areacode_arr as $value){
            if($value == $areacode){
                return true;
            }
        }
        return false;
    }

    private function CheckXuni($xuni_arr,$user_isp){
        foreach($xuni_arr as $value){
            if(strpos($user_isp,$value)!==false){
                return true;
            }
        }
        return false;
    }

    private function CheckRegion($region_arr,$user_region){
        foreach($region_arr as $value){
            if(preg_match("/^{$value}*/", $user_region)){
                return true;
            }
        }
        return false;
    }
    
    private function CheckCity($city_arr,$user_city){
        foreach($city_arr as $value){
            if(preg_match("/^{$value}*/", $user_city)){
                return true;
            }
        }
        return false;
    }


    private function get_phone_data($phone="",$appcode=""){
        $host = "https://api04.aliyun.venuscn.com";
        $path = "/mobile";
        $method = "GET";
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $appcode);
        $querys = "mobile=".$phone;
        $bodys = "";
        $url = $host . $path . "?" . $querys;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        if (1 == strpos("$".$host, "https://"))
        {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }
        $data = curl_exec($curl);
        curl_close($curl);

        $phonedata = json_decode($data, true);
        if($phonedata['ret'] != '200' || empty($phonedata['ret'])){
            return false;
        }
        $data = $phonedata['data'];
        return $data;
    }

    //get ip
    private function get_client_ip()
    {
        global $_G;
        if (isset($_G['clientip']) and !empty($_G['clientip']))
        {
            return $_G['clientip'];
        }
        if (isset($_SERVER['HTTP_CLIENT_IP']) and !empty($_SERVER['HTTP_CLIENT_IP']))
        {
            return $_SERVER['HTTP_CLIENT_IP'];
        }
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) and !empty($_SERVER['HTTP_X_FORWARDED_FOR']))
        {
            return strtok($_SERVER['HTTP_X_FORWARDED_FOR'], ',');
        }
        if (isset($_SERVER['HTTP_PROXY_USER']) and !empty($_SERVER['HTTP_PROXY_USER']))
        {
            return $_SERVER['HTTP_PROXY_USER'];
        }
        if (isset($_SERVER['REMOTE_ADDR']) and !empty($_SERVER['REMOTE_ADDR']))
        {
            return $_SERVER['REMOTE_ADDR'];
        }
        else
        {
            return "0.0.0.0";
        }
    }

    private function getbianma($data, $webbianma = "gbk")
    {
        if ($webbianma == "gbk") {
            $data = diconv($data, 'UTF-8', 'GBK');
        }
        return $data;
    }
}
?>