<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class ISMSUtils
{
    function isMobile($mobile, $areacode = '86')
    {
        if (!is_numeric($mobile)) {
            return false;
        }
        if ($areacode == '86') {
            return preg_match("/^1[123456789]{1}\d{9}$/", $mobile) ? true : false;
        } else {
            return preg_match("/^[0-9]\d*$/", $mobile) ? true : false;
        }

    }

    function isMobileMagApp($mobile, $areacode = '86')
    {
        if (!is_numeric($mobile)) {
            return false;
        }
        if ($areacode == '86') {
            return (preg_match("/^1[123456789]{1}\d{9}$/", $mobile) || preg_match("/^861[123456789]{1}\d{9}$/", $mobile))? true : false;
        } else {
            return preg_match("/^[0-9]\d*$/", $mobile) ? true : false;
        }

    }

    function isEmail($email) {
        return preg_match("/^\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}$/",$email) ? true : false;
    }

    public function getbianma($data, $webbianma = "gbk", $openhtmlspecialchars = true)
    {
        if ($webbianma == "gbk") {
            $data = diconv($data, 'GBK', 'UTF-8');

        }
        if ($openhtmlspecialchars) {
            $data = isset($data) ? trim(htmlspecialchars($data, ENT_QUOTES)) : '';
        }
        return $data;
    }

    function generate_code($length = 6)
    {
        return rand(pow(10, ($length - 1)), pow(10, $length) - 1);
    }

    //type 0ceshi 1zhuce 2shenfenyanzheng 3denglu 4xiugaimima
    function gettype($type = 0)
    {
        $typestr = "";
        switch ($type) {
            case 0:
                $typestr = plang('typeceshi');
                break;
            case 1:
                $typestr = plang('typezhuce');
                break;
            case 2:
                $typestr = plang('typeshenfenyanzheng');
                break;
            case 3:
                $typestr = plang('typedenglu');
                break;
            case 4:
                $typestr = plang('typexiugaimima');
                break;
            case 5:
                $typestr = plang('typeshenfenyanzheng');
                break;
            case 6:
                $typestr = plang('typeapp');
                break;
            case 7:
                $typestr = plang('typeother');
                break;
            default:
                $typestr = plang('typeceshi');
                break;
        }
        return $typestr;
    }

    function getstatus($status = 0)
    {
        $statusstr = "";
        switch ($status) {
            case 0:
                $statusstr = plang('statuserror');
                break;
            case 1:
                $statusstr = plang('statussuccess');
                break;
            default:
                $statusstr = plang('statuserror');
                break;
        }
        return $statusstr;
    }

    function getmemberstatus($freeze = 0)
    {
        $statusstr = "";
        switch ($freeze) {
            case 0:
                $statusstr = plang('memberstatus0');
                break;
            case 1:
                $statusstr = plang('memberstatus1');
                break;
            case 2:
                $statusstr = plang('memberstatus2');
                break;
            case 3:
                $statusstr = plang('memberstatus3');
                break;
            case 4:
                $statusstr = plang('memberstatus4');
                break;
            case 5:
                $statusstr = plang('memberstatus5');
                break;
            default:
                $statusstr = plang('memberstatus0');
                break;
        }
        return $statusstr;
    }

    function searchGetOne($keywords, $field, $returnfield, $data)
    {
        if (!isset($keywords) || !isset($data) || !isset($field) || !isset($returnfield)) {
            return false;
        }
        for ($i = 0; $i < count($data); $i++) {
            if ($data[$i][$field] == $keywords) {
                $res = $data[$i][$returnfield];
                break;
            }
        }

        return $res;
    }

    function crypto_rand_secure($min, $max)
    {
        $range = $max - $min;
        if ($range < 1) return $min; // not so random...
        $log = ceil(log($range, 2));
        $bytes = (int)($log / 8) + 1; // length in bytes
        $bits = (int)$log + 1; // length in bits
        $filter = (int)(1 << $bits) - 1; // set all lower bits to 1
        do {
            $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
            $rnd = $rnd & $filter; // discard irrelevant bits
        } while ($rnd >= $range);
        return $min + $rnd;
    }

    function get_rand_str($length = 8)
    {
        $randstr = "";
        $codeAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $codeAlphabet .= "abcdefghijklmnopqrstuvwxyz";
        $codeAlphabet .= "0123456789";
        $max = strlen($codeAlphabet); // edited

        for ($i = 0; $i < $length; $i++) {
            $randstr .= $codeAlphabet[$this->crypto_rand_secure(0, $max)];
        }

        return $randstr;
    }

    //get ip
    public function get_client_ip()
    {
        global $_G;
        if (isset($_G['clientip']) and !empty($_G['clientip'])) {
            return $_G['clientip'];
        }
        if (isset($_SERVER['HTTP_CLIENT_IP']) and !empty($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
        }
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) and !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return strtok($_SERVER['HTTP_X_FORWARDED_FOR'], ',');
        }
        if (isset($_SERVER['HTTP_PROXY_USER']) and !empty($_SERVER['HTTP_PROXY_USER'])) {
            return $_SERVER['HTTP_PROXY_USER'];
        }
        if (isset($_SERVER['REMOTE_ADDR']) and !empty($_SERVER['REMOTE_ADDR'])) {
            return $_SERVER['REMOTE_ADDR'];
        } else {
            return "0.0.0.0";
        }
    }

    //get browser
    public function get_browser(){
        $browser = $_SERVER['HTTP_USER_AGENT'];
        if(preg_match('/360SE/', $browser)){
            $browser = "360se";
        }
        elseif (preg_match('/Maxthon/', $browser)){
            $browser = "Maxthon";
        }
        elseif (preg_match('/Tencent/', $browser)){
            $browser = "Tencent Browser";
        }
        elseif (preg_match('/QQBrowser/', $browser)){
            $browser = "QQ Browser";
        }
        elseif (preg_match('/Green/', $browser)){
            $browser = "Green Browser";
        }
        elseif (preg_match('/baidu/', $browser)){
            $browser = "Baidu Browser";
        }
        elseif (preg_match('/TheWorld/', $browser)){
            $browser = "The World";
        }
        elseif (preg_match('/MetaSr/', $browser)){
            $browser = "Sogou Browser";
        }
        elseif (preg_match('/Firefox/', $browser)){
            $browser = "Firefox";
        }
        elseif (preg_match('/MSIE\s6\.0/', $browser)){
            $browser = "IE6.0";
        }
        elseif (preg_match('/MSIE\s7\.0/', $browser)){
            $browser = "IE7.0";
        }
        elseif (preg_match('/MSIE\s8\.0/', $browser)){
            $browser = "IE8.0";
        }
        elseif (preg_match('/MSIE\s9\.0/', $browser)){
            $browser = "IE9.0";
        }
        elseif (preg_match('/Netscape/', $browser)){
            $browser = "Netscape";
        }
        elseif (preg_match('/Opera/', $browser)){
            $browser = "Opera";
        }
        elseif (preg_match('/Chrome/', $browser)){
            $browser = "Chrome";
        }
        elseif (preg_match('/Gecko/', $browser)){
            $browser = "Gecko";
        }
        elseif (preg_match('/Safari/', $browser)){
            $browser = "Safari";
        }
        else{
            $browser = "Unknow Browser";
        }
        return $browser;
    }

    //get os
    public function get_os(){
        $os = $_SERVER['HTTP_USER_AGENT'];
        if(preg_match('/NT\s5\.1/', $os)){
            $os = "Windows XP";
        }
        elseif (preg_match('/NT\s10\.0/', $os)){
            $os = "Windows 10";
        }
        elseif (preg_match('/NT\s6\.2/', $os)){
            $os = "Windows 8";
        }
        elseif (preg_match('/NT\s6\.1/', $os)){
            $os = "Windows 7";
        }
        elseif (preg_match('/NT\s6\.0/', $os)){
            $os = 'Windows Vista \ server 2008';
        }
        elseif (preg_match('/NT\s5\.2/', $os)){
            $os = "Windows Server 2003";
        }
        elseif (preg_match('/NT\s5/', $os)){
            $os = "Windows 2000";
        }
        elseif (preg_match('/Linux/', $os)){
            $os = "Linux";
        }
        elseif (preg_match('/Unix/', $os)){
            $os = "Unix";
        }
        elseif (preg_match('/Mac/', $os)){
            $os = "Mac OS";
        }
        elseif (preg_match('/NT/', $os)){
            $os = "Windows NT";
        }
        else{
            $os = "Unknow OS";
        }
        return $os;
    }

    //get device
    public function get_device(){
        $device = $_SERVER['HTTP_USER_AGENT'];
        if(strpos($device, 'Windows NT')){
            $device = "PC";
        }
        elseif (strpos($device, 'Mac OS X')){
            $device = 'Mac';
        }
        elseif (strpos($device, 'iPhone')){
            $device = 'iPhone';
        }
        elseif (strpos($device, 'Android')){
            $device = 'Android Mobile';
        }
        elseif (strpos($device, 'iPad')){
            $device = 'iPad';
        }
        elseif (strpos($device, 'iPod')){
            $device = 'iPod';
        }
        elseif (strpos($device, 'Windows Phone OS')){
            $device = 'Windows Phone Mobile';
        }
        else{
            $device = "Unknow Device";
        }
        return $device;
    }

    //get useragent
    public function get_useragent(){
        return $_SERVER['HTTP_USER_AGENT'];
    }

    //get port
    public function get_port(){
        global $_G;
        return !empty($_G['remoteport'])?$_G['remoteport']:($_SERVER['REMOTE_PORT']?$_SERVER['REMOTE_PORT']:0);
    }

    //get log info
    public function get_log_info(){
        $loginfo = array();

        $loginfo['client_ip'] = $this->get_client_ip();
        $loginfo['client_port'] = $this->get_port();
        $loginfo['client_browser'] = $this->get_browser();
        $loginfo['client_os'] = $this->get_os();
        $loginfo['client_device'] = $this->get_device();
        $loginfo['client_useragent'] = $this->get_useragent();

        return $loginfo;
    }


    public function make_verify_sign($uid, $idstring) {
        global $_G;
        $link = "{$_G['siteurl']}plugin.php?id=jzsjiale_isms:security&uid={$uid}&hashid={$idstring}";
        return dsign($link);
    }

    public function make_getpws_sign($uid, $idstring) {
        global $_G;
        $link = "{$_G['siteurl']}member.php?mod=getpasswd&uid={$uid}&id={$idstring}";
        return dsign($link);
    }

    public function changename_for_dz($oldusername, $newusername){
        $member = DB::fetch_first("SELECT * FROM " . DB::table('common_member') . " WHERE username='$oldusername'");
        if($member){
            DB::query("UPDATE " . DB::table('common_adminnote') . " SET admin='$newusername' WHERE admin='$oldusername'");
            DB::query("UPDATE " . DB::table('common_block') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('common_block_item') . " SET title='$newusername' WHERE title='$oldusername'");
            DB::query("UPDATE " . DB::table('common_block_item_data') . " SET title='$newusername' WHERE title='$oldusername'");
            DB::query("UPDATE " . DB::table('common_card_log') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('common_failedlogin') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('common_grouppm') . " SET author='$newusername' WHERE author='$oldusername'");
            DB::query("UPDATE " . DB::table('common_invite') . " SET fusername='$newusername' WHERE fusername='$oldusername'");
            DB::query("UPDATE " . DB::table('common_member') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('common_member_security') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('common_member_validate') . " SET admin='$newusername' WHERE admin='$oldusername'");
            DB::query("UPDATE " . DB::table('common_member_verify_info') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('common_mytask') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('common_report') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('common_session') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('common_word') . " SET admin='$newusername' WHERE admin='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_activityapply') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_announcement') . " SET author='$newusername' WHERE author='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_collection') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_collectioncomment') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_collectionfollow') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_collectionteamworker') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_forumrecommend') . " SET author='$newusername' WHERE author='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_groupuser') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_imagetype') . " SET name='$newusername' WHERE name='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_order') . " SET buyer='$newusername' WHERE buyer='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_order') . " SET admin='$newusername' WHERE admin='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_pollvoter') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_post') . " SET author='$newusername' WHERE author='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_postcomment') . " SET author='$newusername' WHERE author='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_promotion') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_ratelog') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_rsscache') . " SET author='$newusername' WHERE author='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_thread') . " SET author='$newusername' WHERE author='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_threadmod') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_trade') . " SET seller='$newusername' WHERE seller='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_tradelog') . " SET seller='$newusername' WHERE seller='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_tradelog') . " SET buyer='$newusername' WHERE buyer='$oldusername'");
            DB::query("UPDATE " . DB::table('forum_warning') . " SET author='$newusername' WHERE author='$oldusername'");
            DB::query("UPDATE " . DB::table('home_album') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_blog') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_clickuser') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_comment') . " SET author='$newusername' WHERE author='$oldusername'");
            DB::query("UPDATE " . DB::table('home_docomment') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_doing') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_feed') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_feed_app') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_follow') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_follow') . " SET fusername='$newusername' WHERE fusername='$oldusername'");
            DB::query("UPDATE " . DB::table('home_follow_feed') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_follow_feed_archiver') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_friend') . " SET fusername='$newusername' WHERE fusername='$oldusername'");
            DB::query("UPDATE " . DB::table('home_friend_request') . " SET fusername='$newusername' WHERE fusername='$oldusername'");
            DB::query("UPDATE " . DB::table('home_notification') . " SET author='$newusername' WHERE author='$oldusername'");
            DB::query("UPDATE " . DB::table('home_pic') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_poke') . " SET fromusername='$newusername' WHERE fromusername='$oldusername'");
            DB::query("UPDATE " . DB::table('home_share') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_show') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_specialuser') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('home_visitor') . " SET vusername='$newusername' WHERE vusername='$oldusername'");
            DB::query("UPDATE " . DB::table('home_specialuser') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('portal_article_title') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('portal_comment') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('portal_rsscache') . " SET author='$newusername' WHERE author='$oldusername'");
            DB::query("UPDATE " . DB::table('portal_topic') . " SET username='$newusername' WHERE username='$oldusername'");
            DB::query("UPDATE " . DB::table('portal_topic_pic') . " SET username='$newusername' WHERE username='$oldusername'");
            if(helper_dbtool::isexisttable('common_member_archive')) {
                DB::query("UPDATE " . DB::table('common_member_archive') . " SET username='$newusername' WHERE username='$oldusername'");
            }
        }
        return $member;
    }

    public function changename_for_uc($oldusername, $newusername){
        DB::query("UPDATE " . UC_DBTABLEPRE . "admins SET username='$newusername' WHERE username='$oldusername'");
        DB::query("UPDATE " . UC_DBTABLEPRE . "badwords SET admin='$newusername' WHERE admin='$oldusername'");
        DB::query("UPDATE " . UC_DBTABLEPRE . "feeds SET username='$newusername' WHERE username='$oldusername'");
        DB::query("UPDATE " . UC_DBTABLEPRE . "members SET username='$newusername' WHERE username='$oldusername'");
        DB::query("UPDATE " . UC_DBTABLEPRE . "mergemembers SET username='$newusername' WHERE username='$oldusername'");
        DB::query("UPDATE " . UC_DBTABLEPRE . "protectedmembers SET username='$newusername' WHERE username='$oldusername'");
    }


    function plang($str) {
        return lang('plugin/jzsjiale_isms', $str);
    }
}
?>