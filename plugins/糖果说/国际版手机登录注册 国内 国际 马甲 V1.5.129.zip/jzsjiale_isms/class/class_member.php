<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobile_logging_ctl {
    function mobile_logging_ctl() {
        require_once libfile('function/misc');
        loaducenter();
    }

    function on_login() {
        global $_G;
        if($_G['uid']) {
            $referer = dreferer();
            $ucsynlogin = $this->setting['allowsynlogin'] ? uc_user_synlogin($_G['uid']) : '';
            $param = array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle'], 'uid' => $_G['member']['uid']);
            showmessage('login_succeed', $referer ? $referer : './', $param, array('showdialog' => 1, 'locationtime' => true, 'extrajs' => $ucsynlogin));
        }

        list($seccodecheck) = seccheck('login');
        if(!empty($_GET['auth'])) {
            $dauth = authcode($_GET['auth'], 'DECODE', $_G['config']['security']['authkey']);
            list(,,,$secchecklogin2) = explode("\t", $dauth);
            if($secchecklogin2) {
                $seccodecheck = true;
            }
        }
        $seccodestatus = !empty($_GET['lssubmit']) ? false : $seccodecheck;
        $invite = getinvite();

        if(!submitcheck('loginsubmit', 1, $seccodestatus)) {

            $auth = '';
            $username = !empty($_G['cookie']['loginuser']) ? dhtmlspecialchars($_G['cookie']['loginuser']) : '';

            if(!empty($_GET['auth'])) {
                list($username, $password, $questionexist) = explode("\t", authcode($_GET['auth'], 'DECODE', $_G['config']['security']['authkey']));
                $username = dhtmlspecialchars($username);
                $auth = dhtmlspecialchars($_GET['auth']);
            }

            $cookietimecheck = !empty($_G['cookie']['cookietime']) || !empty($_GET['cookietime']) ? 'checked="checked"' : '';

            if($seccodecheck) {
                $seccode = random(6, 1) + $seccode{0} * 1000000;
            }

            if($this->extrafile && file_exists($this->extrafile)) {
                require_once $this->extrafile;
            }

            $navtitle = lang('core', 'title_login');

            $dreferer = addslashes($_G['cookie']['isms_login_referer']);
            if(!empty($dreferer) && !preg_match('/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+/',$dreferer)){
                $dreferer = $_G['siteurl'];
            }
            if(empty($dreferer)){
                $dreferer = dreferer();
                dsetcookie("isms_login_referer",$dreferer);
            }

            $pagetitle = lang('plugin/jzsjiale_isms', 'login_title')." - ";

            if(defined('IN_MOBILE')) {
                $jsms_muban_mobile = (array)unserialize($_G['setting']['jsms_muban_mobile']);
            }else{
                $jsms_muban_pc = (array)unserialize($_G['setting']['jsms_muban_pc']);
            }
            $jsms_muban_xieyi = (array)unserialize($_G['setting']['jsms_muban_xieyi']);
            $jsms_muban_yinsi = (array)unserialize($_G['setting']['jsms_muban_yinsi']);

            $jsms_ad = (array)unserialize($_G['setting']['jsms_ad']);

            include template($this->template);

        } else {

            $url ="member.php?mod=logging&action=login";
            showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);

        }

    }
}

class mobile_register_ctl {

	var $showregisterform = 1;

	function mobile_register_ctl() {
		global $_G;
		if($_G['setting']['bbclosed']) {
			if(($_GET['action'] != 'activation' && !$_GET['activationauth']) || !$_G['setting']['closedallowactivation'] ) {
				showmessage('register_disable', NULL, array(), array('login' => 1));
			}
		}

		loadcache(array('modreasons', 'stamptypeid', 'fields_required', 'fields_optional', 'fields_register', 'ipctrl'));
		require_once libfile('function/misc');
		require_once libfile('function/profile');
		if(!function_exists('sendmail')) {
			include libfile('function/mail');
		}
		loaducenter();
	}

	function on_register() {
		global $_G;

		if($_G['uid']) {
			$ucsynlogin = $this->setting['allowsynlogin'] ? uc_user_synlogin($_G['uid']) : '';
			$url_forward = dreferer();
			if(strpos($url_forward, $this->setting['regname']) !== false) {
				$url_forward = 'forum.php';
			}
			showmessage('login_succeed', $url_forward ? $url_forward : './', array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle'], 'uid' => $_G['uid']), array('extrajs' => $ucsynlogin));
		} elseif(!$this->setting['regclosed'] && (!$this->setting['regstatus'] || !$this->setting['ucactivation'])) {
			if($_GET['action'] == 'activation' || $_GET['activationauth']) {
				if(!$this->setting['ucactivation'] && !$this->setting['closedallowactivation']) {
					showmessage('register_disable_activation');
				}
			} elseif(!$this->setting['regstatus']) {
				if($this->setting['regconnect']) {
					dheader('location:connect.php?mod=login&op=init&referer=forum.php&statfrom=login_simple');
				}
                $regclosemessage = !$this->setting['regclosemessage'] ? lang('message', 'register_disable') : str_replace(array("\r", "\n"), '', $this->setting['regclosemessage']);
                include template($this->regclosed);
				//showmessage(!$this->setting['regclosemessage'] ? 'register_disable' : str_replace(array("\r", "\n"), '', $this->setting['regclosemessage']));
			}
		}

		$bbrules = & $this->setting['bbrules'];
		$bbrulesforce = & $this->setting['bbrulesforce'];
		$bbrulestxt = & $this->setting['bbrulestxt'];
		$welcomemsg = & $this->setting['welcomemsg'];
		$welcomemsgtitle = & $this->setting['welcomemsgtitle'];
		$welcomemsgtxt = & $this->setting['welcomemsgtxt'];
		$regname = $this->setting['regname'];

		if($this->setting['regverify']) {
			if($this->setting['areaverifywhite']) {
				$location = $whitearea = '';
				$location = trim(convertip($_G['clientip'], "./"));
				if($location) {
					$whitearea = preg_quote(trim($this->setting['areaverifywhite']), '/');
					$whitearea = str_replace(array("\\*"), array('.*'), $whitearea);
					$whitearea = '.*'.$whitearea.'.*';
					$whitearea = '/^('.str_replace(array("\r\n", ' '), array('.*|.*', ''), $whitearea).')$/i';
					if(@preg_match($whitearea, $location)) {
						$this->setting['regverify'] = 0;
					}
				}
			}

			if($_G['cache']['ipctrl']['ipverifywhite']) {
				foreach(explode("\n", $_G['cache']['ipctrl']['ipverifywhite']) as $ctrlip) {
					if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
						$this->setting['regverify'] = 0;
						break;
					}
				}
			}
		}

		$invitestatus = false;
		if($this->setting['regstatus'] == 2) {
			if($this->setting['inviteconfig']['inviteareawhite']) {
				$location = $whitearea = '';
				$location = trim(convertip($_G['clientip'], "./"));
				if($location) {
					$whitearea = preg_quote(trim($this->setting['inviteconfig']['inviteareawhite']), '/');
					$whitearea = str_replace(array("\\*"), array('.*'), $whitearea);
					$whitearea = '.*'.$whitearea.'.*';
					$whitearea = '/^('.str_replace(array("\r\n", ' '), array('.*|.*', ''), $whitearea).')$/i';
					if(@preg_match($whitearea, $location)) {
						$invitestatus = true;
					}
				}
			}

			if($this->setting['inviteconfig']['inviteipwhite']) {
				foreach(explode("\n", $this->setting['inviteconfig']['inviteipwhite']) as $ctrlip) {
					if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
						$invitestatus = true;
						break;
					}
				}
			}
		}

		$groupinfo = array();
		if($this->setting['regverify']) {
			$groupinfo['groupid'] = 8;
		} else {
			$groupinfo['groupid'] = $this->setting['newusergroupid'];
		}

		list($seccodecheck, $secqaacheck) = seccheck('register');
		$fromuid = !empty($_G['cookie']['promotion']) && $this->setting['creditspolicy']['promotion_register'] ? intval($_G['cookie']['promotion']) : 0;
		$username = isset($_GET['username']) ? $_GET['username'] : '';
		$bbrulehash = $bbrules ? substr(md5(FORMHASH), 0, 8) : '';
		$auth = $_GET['auth'];

		if(!$invitestatus) {
			$invite = getinvite();
		}
		$sendurl = $this->setting['sendregisterurl'] ? true : false;
		if($sendurl) {
			if(!empty($_GET['hash'])) {
				$_GET['hash'] = preg_replace("/[^\[A-Za-z0-9_\]%\s+-\/=]/", '', $_GET['hash']);
				$hash = explode("\t", authcode($_GET['hash'], 'DECODE', $_G['config']['security']['authkey']));
				if(is_array($hash) && isemail($hash[0]) && TIMESTAMP - $hash[1] < 259200) {
					$sendurl = false;
				}
			}
		}

		if(!submitcheck('regsubmit')) {

			if($_GET['action'] == 'activation') {
				$auth = explode("\t", authcode($auth, 'DECODE'));
				if(FORMHASH != $auth[1]) {
					showmessage('register_activation_invalid', 'member.php?mod=logging&action=login');
				}
				$username = $auth[0];
				$activationauth = authcode("$auth[0]\t".FORMHASH, 'ENCODE');
				$sendurl = false;
			}

			if(!$sendurl) {

				if($fromuid) {
					$member = getuserbyuid($fromuid);
					if(!empty($member)) {
						$fromuser = dhtmlspecialchars($member['username']);
					} else {
						dsetcookie('promotion');
					}
				}

				if($_GET['action'] == 'activation') {
					$auth = dhtmlspecialchars($auth);
				}

				if($seccodecheck) {
					$seccode = random(6, 1);
				}

				$username = dhtmlspecialchars($username);

				$htmls = $settings = array();
				foreach($_G['cache']['fields_register'] as $field) {
					$fieldid = $field['fieldid'];
					$html = profile_setting($fieldid, array(), false, false, true);
					if($html) {
						$settings[$fieldid] = $_G['cache']['profilesetting'][$fieldid];
						$htmls[$fieldid] = $html;
					}
				}

				$navtitle = $this->setting['reglinkname'];

				if($this->extrafile && file_exists($this->extrafile)) {
					require_once $this->extrafile;
				}
			}
			$bbrulestxt = nl2br("\n$bbrulestxt\n\n");
            $dreferer = addslashes($_G['cookie']['isms_login_referer']);
            if(!empty($dreferer) && !preg_match('/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+/',$dreferer)){
                $dreferer = $_G['siteurl'];
            }
            if(empty($dreferer)){
                $dreferer = dreferer();
                dsetcookie("isms_login_referer",$dreferer);
            }

            $pagetitle = lang('plugin/jzsjiale_isms', 'register_title')." - ";

            if(defined('IN_MOBILE')) {
                $jsms_muban_mobile = (array)unserialize($_G['setting']['jsms_muban_mobile']);
            }else{
                $jsms_muban_pc = (array)unserialize($_G['setting']['jsms_muban_pc']);
            }
            $jsms_muban_xieyi = (array)unserialize($_G['setting']['jsms_muban_xieyi']);
            $jsms_muban_yinsi = (array)unserialize($_G['setting']['jsms_muban_yinsi']);
            $jsms_ad = (array)unserialize($_G['setting']['jsms_ad']);

			include template($this->template);

		} else {
            $url ="member.php?mod=register";
            showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);

		}
	}

}

class mobile_lostpasswd_ctl{
    function mobile_lostpasswd_ctl() {
        require_once libfile('function/misc');
        loaducenter();
    }

    function on_lostpasswd(){
        global $_G;
        if($_G['uid']) {
            $referer = dreferer();
            $ucsynlogin = $this->setting['allowsynlogin'] ? uc_user_synlogin($_G['uid']) : '';
            $param = array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle'], 'uid' => $_G['member']['uid']);
            showmessage('login_succeed', $referer ? $referer : './', $param, array('showdialog' => 1, 'locationtime' => true, 'extrajs' => $ucsynlogin));
        }

        if(!submitcheck('lostpasswdsubmit')) {
            $dreferer = addslashes($_G['cookie']['isms_login_referer']);
            if(!empty($dreferer) && !preg_match('/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+/',$dreferer)){
                $dreferer = $_G['siteurl'];
            }
            if(empty($dreferer)){
                $dreferer = dreferer();
                dsetcookie("isms_login_referer",$dreferer);
            }

            $pagetitle = lang('plugin/jzsjiale_isms', 'lostpasswd_title')." - ";

            if(defined('IN_MOBILE')) {
                $jsms_muban_mobile = (array)unserialize($_G['setting']['jsms_muban_mobile']);
            }else{
                $jsms_muban_pc = (array)unserialize($_G['setting']['jsms_muban_pc']);
            }

            $jsms_muban_xieyi = (array)unserialize($_G['setting']['jsms_muban_xieyi']);
            $jsms_muban_yinsi = (array)unserialize($_G['setting']['jsms_muban_yinsi']);
            $jsms_ad = (array)unserialize($_G['setting']['jsms_ad']);

            include template($this->template);
        }else{
            $url ="member.php?mod=lostpasswd";
            showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);

        }


    }
}

class mobile_getpasswd_ctl{
    function mobile_getpasswd_ctl() {
        require_once libfile('function/misc');
        loaducenter();
    }

    function on_getpasswd(){
        global $_G;

        if($_GET['uid'] && $_GET['id'] && $_GET['sign'] === make_getpws_sign($_GET['uid'], $_GET['id'])) {
            $discuz_action = 141;


            $member = getuserbyuid($_GET['uid'], 1);
            $table_ext = isset($member['_inarchive']) ? '_archive' : '';
            $member = array_merge(C::t('common_member_field_forum'.$table_ext)->fetch($_GET['uid']), $member);
            list($dateline, $operation, $idstring) = explode("\t", $member['authstr']);

            if($dateline < TIMESTAMP - 86400 * 3 || $operation != 1 || $idstring != $_GET['id']) {
                showmessage('getpasswd_illegal', NULL);
            }

            if(!submitcheck('getpwsubmit') || $_GET['newpasswd1'] != $_GET['newpasswd2']) {
                $hashid = $_GET['id'];
                $uid = $_GET['uid'];

                $dreferer = addslashes($_G['cookie']['isms_login_referer']);
                if(!empty($dreferer) && !preg_match('/^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+/',$dreferer)){
                    $dreferer = $_G['siteurl'];
                }
                if(empty($dreferer)){
                    $dreferer = dreferer();
                    dsetcookie("isms_login_referer",$dreferer);
                }

                $pagetitle = lang('plugin/jzsjiale_isms', 'getpasswd_title')." - ";

                if(defined('IN_MOBILE')) {
                    $jsms_muban_mobile = (array)unserialize($_G['setting']['jsms_muban_mobile']);
                }else{
                    $jsms_muban_pc = (array)unserialize($_G['setting']['jsms_muban_pc']);
                }

                $jsms_muban_xieyi = (array)unserialize($_G['setting']['jsms_muban_xieyi']);
                $jsms_muban_yinsi = (array)unserialize($_G['setting']['jsms_muban_yinsi']);
                $jsms_ad = (array)unserialize($_G['setting']['jsms_ad']);

                include template($this->template);
            }else{
                $url ="member.php?mod=lostpasswd";
                showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);

            }

        }else{
            showmessage('parameters_error');
        }


    }
}
//From: d'.'is'.'m.ta'.'obao.com
?>