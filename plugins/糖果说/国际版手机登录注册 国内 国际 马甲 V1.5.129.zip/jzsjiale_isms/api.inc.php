<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
define('IN_JZSJIALE_ISMS_API', 1);

require_once 'source/plugin/jzsjiale_isms/apicore.class.php';

$modules = array('areacode','log','ticketverify','cloudtencentverify','notverify','vaptchaverify','vaptchaofflineverify','startgeetestverify','geetestverify','register','login','loginmima','loginmimahaiwai','lostpasswd','lostpasswdemail','getpasswd',
    'newbindmobile','unbindmobile','verifybindmobile','changepassword','changepasswordverifybindmobile',
    'changeusername','changeusernameverifybindmobile','changeusernamelog',
    'ask','askverifybindmobile','email','emailverifybindmobile',
    'logoffverifybindmobile','logoff','logoffapplyverifybindmobile','logoffapply','needverify','checkseccode','checkphone','sendsmsapi','checkinvitecode');

$defaultversions = '1';

if(!isset($_GET['module']) || !in_array($_GET['module'], $modules)) {
    $result = array('code'=>1,'data'=>null,'msg'=>'module_not_exists');
    api_core::result($result);
}

$_GET['version'] = !empty($_GET['version']) ? intval($_GET['version']) : (!$defaultversions ? 1 : $defaultversions);
//magapp start
global $_G;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
if($_config['g_app'] == 'magapp'){
    $_GET['version'] = '3';
}
//magapp end

if(empty($_GET['module']) || empty($_GET['version']) || !preg_match('/^[\w\.]+$/', $_GET['module']) || !preg_match('/^[\d\.]+$/', $_GET['version'])) {
    $result = array('code'=>1,'data'=>null,'msg'=>'param_error');
    api_core::result($result);
}

if(!empty($_GET['_auth'])) {
    unset($_GET['formhash'], $_POST['formhash']);
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
    @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
    $utils = new ISMSUtils();
}else{
    $result = array('code'=>1,'data'=>null,'msg'=>'msg_function_abnormal');
    api_core::result($result);
}

$apifile = 'source/plugin/jzsjiale_isms/api/'.$_GET['version'].'/'.$_GET['module'].'.php';

if(file_exists($apifile)) {
    require_once $apifile;
} else {
    if($_GET['version'] > 1) {
        for($i = $_GET['version']; $i >= 1; $i--) {
            $apifile = 'source/plugin/jzsjiale_isms/api/'.$i.'/'.$_GET['module'].'.php';
            if(file_exists($apifile)) {
                $_GET['version'] = $i;
                require_once $apifile;
                break;
            } elseif($i==1 && !file_exists($apifile)) {
                $result = array('code'=>1,'data'=>null,'msg'=>'module_not_exists');
                api_core::result($result);
            }
        }
    } else {
        $result = array('code'=>1,'data'=>null,'msg'=>'module_not_exists');
        api_core::result($result);
    }
}
