<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//From: d'.'is'.'m.ta'.'obao.com
?>
<iframe src="//dism.taobao.com/?@32563.developer" width="1100" height="2000" frameborder="0" scrolling="yes" style="margin-left:-3px; background:#F4FAFD" ></iframe>