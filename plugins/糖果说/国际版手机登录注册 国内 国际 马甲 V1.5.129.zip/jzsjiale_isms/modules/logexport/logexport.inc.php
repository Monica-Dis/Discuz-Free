<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 202001012040
 * updatetime: 202007280930
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

global $_G, $lang;
$act = $_GET['act'];

if($act=='logexport') {
    $d = daddslashes($_GET['d']);
    $starttime = addslashes($d['starttime']) ? strtotime(addslashes($d['starttime'])) : 0;
    $endtime = addslashes($d['endtime']) ? strtotime(addslashes($d['endtime'])) : 0;
    $count = !empty(addslashes($d['count']))?addslashes($d['count']):1000;

    if(!empty($starttime) && !empty($endtime)) {
        if($endtime <= $starttime && $starttime != '-1' && $endtime != '-1') {
            cpmsg(unicodeDecode('\u7ed3\u675f\u65e5\u671f\u4e0d\u80fd\u65e9\u4e8e\u5f00\u59cb\u65e5\u671f'), '', 'error');
        }
    }

    set_time_limit(0);

    $filename = "log-".date("Y-m-d H:i:s").'.csv';

    ob_end_clean();
    header('Content-Encoding: none');
    header('Content-Type: application/vnd.ms-excel;');
    header('Content-Disposition: attachment; filename='.$filename);
    header('Pragma: no-cache');
    header('Expires: 0');

    $head = [
        'id' => 'ID',
        'uid' => unicodeDecode('\u7528\u6237\u0075\u0069\u0064'),
        'username' => unicodeDecode('\u7528\u6237\u540d'),
        'areacode' => unicodeDecode('\u56fd\u9645\u533a\u53f7'),
        'phone' => unicodeDecode('\u624b\u673a\u53f7'),
        'type' => unicodeDecode('\u64cd\u4f5c\u7c7b\u578b'),
        'record' => unicodeDecode('\u5907\u6ce8'),
        'operationuid' => unicodeDecode('\u64cd\u4f5c\u4eba\u0075\u0069\u0064'),
        'ip' => unicodeDecode('\u64cd\u4f5c\u8bbe\u5907\u0049\u0050'),
        'port' => unicodeDecode('\u7aef\u53e3'),
        'browser' => unicodeDecode('\u64cd\u4f5c\u7cfb\u7edf'),
        'os' => unicodeDecode('\u4f7f\u7528\u6d4f\u89c8\u5668'),
        'device' => unicodeDecode('\u8bbe\u5907\u7c7b\u578b'),
        'useragent' => "USERAGENT",
        'dateline' => unicodeDecode('\u64cd\u4f5c\u65f6\u95f4'),
    ];

    $fp = fopen('php://output', 'a') or exit("Can't open php://output");

    $key = [];
    foreach ($head as $i => $v) {
        if($_G['charset'] != 'gbk') {
            $head[$i] = diconv($v, $_G['charset'], 'GBK');
        }

        array_push($key, $i);
    }

    fputcsv($fp, $head);

    $where = " 1=1 ";
    if(!empty($starttime) && !empty($endtime)) {
        $where .= " and dateline >= ".$starttime." and dateline <= ".$endtime;
    }elseif(!empty($starttime) && empty($endtime)) {
        $where .= " and dateline >= ".$starttime;
    }elseif(empty($starttime) && !empty($endtime)) {
        $where .= " and dateline <= ".$endtime;
    }else{
        $where = " 1=1 ";
    }
    $total = (int) DB::result_first("SELECT count(*) FROM ".DB::table('jzsjiale_isms_log').' WHERE '.$where);

    $page_size = $count > 10000 ? 10000 : $count;
    $limit = $count > 10000 ? 10000 : $count;
    $cnt = 0;


    for ($i = 0; $i < ceil($total/$page_size); $i++) {

        $lists = DB::fetch_all('SELECT * FROM '.DB::table('jzsjiale_isms_log').' WHERE '.$where.' ORDER BY id DESC '.DB::limit($i*$page_size, $limit));

        foreach ($lists as $k => $v) {
            $data = [];
            foreach ($key as $vkey) {
                if($_G['charset'] != 'gbk') {
                    $value = diconv($v[$vkey], $_G['charset'], 'GBK');
                }else{
                    $value = $v[$vkey];
                }
                if($vkey == 'dateline'){
                    $value = date('Y-m-d H:i:s',$value);
                }elseif($vkey == 'record'){
                    $value = get_record($value, $v['type']);
                    if($_G['charset'] != 'gbk') {
                        $value = diconv($value, $_G['charset'], 'GBK');
                    }
                }
                array_push($data, $value);
            }

            $cnt++;
            if ($limit == $cnt) {
                ob_flush();
                flush();
                $cnt = 0;
            }
            fputcsv($fp, $data);
        }
    }

    fclose($fp) or exit("Can't close php://output");
    exit();
}


function get_record($record, $type = "") {
    $ret = "#";
    if(!empty($record)){

        if($type == "changeusername"){
            $tmp = (array)unserialize($record);
            $ret = lang('plugin/jzsjiale_isms','oldusername').$tmp['oldusername'].';'.lang('plugin/jzsjiale_isms','newusername').$tmp['newusername'];
            $ret = cutstr_html($ret);
        }elseif($type == "bind"){
            $tmp = (array)unserialize($record);
            $ret = lang('plugin/jzsjiale_isms','beforerebind_areacode').$tmp['beforerebind_areacode'].';'.lang('plugin/jzsjiale_isms','beforerebind_phone').$tmp['beforerebind_phone'];
            $ret = cutstr_html($ret);
        }elseif($type == "unbind"){
            $tmp = (array)unserialize($record);
            $ret = lang('plugin/jzsjiale_isms','beforebinding_areacode').$tmp['beforebinding_areacode'].';'.lang('plugin/jzsjiale_isms','beforebinding_phone').$tmp['beforebinding_phone'];
            $ret = cutstr_html($ret);
        }elseif($type == "verify" && !empty($record)){
            $ret = in_array($record,array('logoff','changepassword','changeusername'))?lang('plugin/jzsjiale_isms','logtype')[$record]:'#';
            $ret = cutstr_html($ret);
        }elseif($type == "logoff"){
            $ret = $record == 'ok'?lang('plugin/jzsjiale_isms','logoff_ok'):'#';
            $ret = cutstr_html($ret);
        }elseif($type == "logoffapply"){
            switch ($record){
                case 'apply':$ret = lang('plugin/jzsjiale_isms','logoffapply_ok');break;
                case 'cancel':$ret = lang('plugin/jzsjiale_isms','logoffapply_cancel');break;
                case 'iknow':$ret = lang('plugin/jzsjiale_isms','logoffapply_iknow');break;
                default: $ret = $record;break;
            }
            $ret = cutstr_html($ret);
        }elseif($type == "ask"){
            $ret = $record == 'ask'?lang('plugin/jzsjiale_isms','security_ask'):'#';
            $ret = cutstr_html($ret);
        }elseif($type == "email"){
            $ret = $record == 'email'?lang('plugin/jzsjiale_isms','security_email'):'#';
            $ret = cutstr_html($ret);
        }elseif($type == "login"){
            $ret = '#';
            if(!empty($record)){
                if($record == 'login_by_seccode'){
                    $ret = lang('plugin/jzsjiale_isms',$record);
                }elseif (!empty($tmp = (array)unserialize($record)) && $tmp['logintype'] == 'login_by_mima'){
                    $ret = $tmp['type'].'+'.lang('plugin/jzsjiale_isms',$tmp['logintype']);
                }
            }
            //$ret = (!empty($record) && in_array($record,array('login_by_seccode','login_by_mima')))?lang('plugin/jzsjiale_isms',$record):'#';
        }elseif($type == "freeze"){
            switch ($record){
                case 1:
                    $ret = lang('plugin/jzsjiale_isms','memberstatus1');
                    break;
                case 2:
                    $ret = lang('plugin/jzsjiale_isms','memberstatus2');
                    break;
                case 3:
                    $ret = lang('plugin/jzsjiale_isms','memberstatus3');
                    break;
                case 4:
                    $ret = lang('plugin/jzsjiale_isms','memberstatus4');
                    break;
                case 5:
                    $ret = lang('plugin/jzsjiale_isms','memberstatus5');
                    break;
                default:
                    $ret = lang('plugin/jzsjiale_isms','memberstatus6');
                    break;
            }
            $ret = cutstr_html($ret);
        }elseif($type == "checkphone"){
            $tmp = (array)unserialize($record);
            $ret = "";
            switch ($tmp['status']){
                case 'success':
                    $ret = lang('plugin/jzsjiale_isms','checkphone_success').','.lang('plugin/jzsjiale_isms','checkphone_userinput_areacode').$tmp['areacode'].','.lang('plugin/jzsjiale_isms','beforerebind_userinput_phone').$tmp['phone'];
                    break;
                case 'error':
                    $ret = lang('plugin/jzsjiale_isms','checkphone_error').','.lang('plugin/jzsjiale_isms','checkphone_userinput_areacode').$tmp['areacode'].','.lang('plugin/jzsjiale_isms','beforerebind_userinput_phone').$tmp['phone'];
                    break;
                case 'updateareacode':
                    $ret = lang('plugin/jzsjiale_isms','checkphone_updateareacode').','.lang('plugin/jzsjiale_isms','checkphone_before_update').$tmp['areacode_old'].','.lang('plugin/jzsjiale_isms','checkphone_after_update').$tmp['areacode'];
                    break;
                case 'updatephone':
                    $ret = lang('plugin/jzsjiale_isms','checkphone_updatephone').','.lang('plugin/jzsjiale_isms','checkphone_before_update').$tmp['phone_old'].','.lang('plugin/jzsjiale_isms','checkphone_after_update').$tmp['phone'];
                    break;
                default:
                    $ret = lang('plugin/jzsjiale_isms','checkphone_error').','.lang('plugin/jzsjiale_isms','checkphone_userinput_areacode').$tmp['areacode'].','.lang('plugin/jzsjiale_isms','beforerebind_userinput_phone').$tmp['phone'];
                    break;
            }
            $ret = cutstr_html($ret);

        }else{
            $ret = $record;
        }
    }
    return $ret;
}

function cutstr_html($string){
    $string = strip_tags($string);
    return trim($string);
}

echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=more&module=logexport&act=logexport', 'enctype');

showtableheader(unicodeDecode('\u652f\u6301\u9009\u62e9\u65f6\u95f4\u6bb5\uff0c\u5bfc\u51fa\u64cd\u4f5c\u65e5\u5fd7\u6570\u636e\u5230\u0045\u0078\u0063\u0065\u006c\u002f\u0043\u0053\u0056\u3002'), '');

showsetting(unicodeDecode('\u5f00\u59cb\u65f6\u95f4'),'d[starttime]','','calendar','',0,unicodeDecode('\u4e3a\u7a7a\u8868\u793a\u4ece\u7b2c\u4e00\u6761\u6570\u636e\u5f00\u59cb'),1,'starttime');
showsetting(unicodeDecode('\u622a\u6b62\u65f6\u95f4'),'d[endtime]','','calendar','',0,unicodeDecode('\u4e3a\u7a7a\u8868\u793a\u83b7\u53d6\u5230\u6700\u540e\u4e00\u6761\u6570\u636e'),1,'endtime');
showsetting(unicodeDecode('\u6bcf\u6b21\u5904\u7406\u6761\u6570'),'d[count]','1000','text','','',unicodeDecode('\u6bcf\u6b21\u5904\u7406\u6761\u6570\uff0c\u670d\u52a1\u5668\u6027\u80fd\u8d8a\u597d\uff0c\u6b64\u503c\u53ef\u8bbe\u7f6e\u8d8a\u5927\uff0c\u8bf7\u586b\u5199\u6b63\u6574\u6570\u3002\u6700\u5927\u586b\u5199\u0031\u0030\u0030\u0030\u0030\u3002\uff08\u6ce8\u610f\uff1a\u6b64\u5904\u586b\u5199\u7684\u6761\u6570\uff0c\u4e0d\u4ee3\u8868\u5bfc\u51fa\u8fd9\u4e9b\u6761\u6570\u636e\uff0c\u800c\u662f\u7a0b\u5e8f\u6bcf\u6b21\u8bfb\u53d6\u3001\u5904\u7406\u6570\u636e\u7684\u6761\u6570\uff0c\u7a0b\u5e8f\u6267\u884c\u5b8c\u6210\u540e\uff0c\u5c06\u5bfc\u51fa\u7b26\u5408\u6761\u4ef6\u7684\u5168\u90e8\u6570\u636e\uff01\uff09'));


showsubmit('submit', 'submit');
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/


echo "<br/><br/>";
echo "<a href='javascript:;' onClick='javascript :history.back(-1);'>".unicodeDecode('\u8fd4\u56de\u4e0a\u4e00\u9875')."</a>";
?>