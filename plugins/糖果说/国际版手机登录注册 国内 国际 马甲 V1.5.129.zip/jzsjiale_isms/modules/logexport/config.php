<?php
/**
 * Created by jzsjiale.
 * User: jzsjiale
 * Date: 2019/1/10
 * Time: 10:47 AM
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$config = array(
    'dir'=>'logexport',
    'module'=>'logexport',
    'version'=>'1.0.3',
    'title'=>'\u64cd\u4f5c\u65e5\u5fd7\u6570\u636e\u5bfc\u51fa\u0045\u0078\u0063\u0065\u006c\u002f\u0043\u0053\u0056',
    'desc'=>'\u652f\u6301\u9009\u62e9\u65f6\u95f4\u6bb5\uff0c\u5bfc\u51fa\u64cd\u4f5c\u65e5\u5fd7\u6570\u636e\u5230\u0045\u0078\u0063\u0065\u006c\u002f\u0043\u0053\u0056\u3002'
);