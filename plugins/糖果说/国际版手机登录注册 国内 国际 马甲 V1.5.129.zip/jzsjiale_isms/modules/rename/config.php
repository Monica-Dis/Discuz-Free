<?php
/**
 * Created by jzsjiale.
 * User: jzsjiale
 * Date: 2019/1/10
 * Time: 10:47 AM
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$config = array(
    'dir'=>'rename',
    'module'=>'rename',
    'version'=>'1.0.3',
    'title'=>'\u540e\u53f0\u4fee\u6539\u7528\u6237\u540d',
    'desc'=>'\u540e\u53f0\u7ba1\u7406\u5458\u53ef\u5728\u540e\u53f0\u5bf9\u7528\u6237\u4fee\u6539\u7528\u6237\u540d'
);