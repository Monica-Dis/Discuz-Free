<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;
$act = $_GET['act'];

if($act=='rename') {
    $searchuid = daddslashes($_GET['searchuid']);
    $newusername = daddslashes($_GET['newusername']);
    if (empty($searchuid)) {
        cpmsg(unicodeDecode('\u0075\u0069\u0064\u4e0d\u80fd\u4e3a\u7a7a'), '', 'error');
    }
    if (empty($newusername)) {
        cpmsg(unicodeDecode('\u65b0\u7528\u6237\u540d\u4e0d\u80fd\u4e3a\u7a7a'), '', 'error');
    }

    $member = getuserbyuid($searchuid, 1);
    if (!$member || empty($member['uid'])) {
        cpmsg(unicodeDecode('\u672a\u67e5\u8be2\u5230\u8be5\u7528\u6237'), '', 'error');
    }elseif ($member['adminid'] == 1 || $member['adminid'] == 2) {
        cpmsg(unicodeDecode('\u62b1\u6b49\uff0c\u521b\u59cb\u4eba\u3001\u53d7\u4fdd\u62a4\u7528\u6237\u3001\u62e5\u6709\u7ad9\u70b9\u8bbe\u7f6e\u6743\u9650\u7684\u7528\u6237\u4e0d\u80fd\u4f7f\u7528\u8be5\u529f\u80fd\u4fee\u6539\u7528\u6237\u540d'), '', 'error');
    }
    $userNamelen = dstrlen($newusername);
    if ($userNamelen<3) {
        cpmsg(unicodeDecode('\u7528\u6237\u540d\u8fc7\u77ed'), '', 'error');
    }elseif($userNamelen > 15){
        cpmsg(unicodeDecode('\u7528\u6237\u540d\u8fc7\u957f'), '', 'error');
    }
    if($_G['charset'] == 'gbk'){
        $newusername = addslashes(dhtmlspecialchars($newusername,ENT_COMPAT,'GBK'));
    }else{
        $newusername = addslashes(dhtmlspecialchars($newusername,ENT_COMPAT,'utf-8'));
    }

    //20210513 username verify start
    if($_config['g_usernameverify'] != "none"){
        $usernameverifyregular = "";
        if($_config['g_usernameverify'] == "uv1"){
            if($_G['charset'] == 'gbk'){
                $usernameverifyregular = "/^[\x{81}-\x{A0}\x{AA}-\x{FE}A-Za-z][\x{81}-\x{A0}\x{AA}-\x{FE}A-Za-z0-9_]+$/";
            }else{
                $usernameverifyregular = "/^[\x{4E00}-\x{9FA5}A-Za-z][\x{4E00}-\x{9FA5}A-Za-z0-9_]+$/u";
            }
            if(!preg_match($usernameverifyregular, $newusername)){
                cpmsg($_G['cache']['plugin']['jzsjiale_isms']['g_usernameverifytip'], '', 'error');
            }
        }elseif($_config['g_usernameverify'] == "uv2"){
            $usernameverifyregular = "/^[A-Za-z][A-Za-z0-9_]+$/";
            if(!preg_match($usernameverifyregular, $newusername)){
                cpmsg($_G['cache']['plugin']['jzsjiale_isms']['g_usernameverifytip'], '', 'error');
            }
        }elseif($_config['g_usernameverify'] == "uvdiy"){
            $usernameverifyregular = $_config['g_diyusernameverifyregular'];
            if(!preg_match($usernameverifyregular, $newusername)){
                cpmsg($_G['cache']['plugin']['jzsjiale_isms']['g_usernameverifytip'], '', 'error');
            }
        }
    }
    //20210513 username verify end

    loaducenter();
    $ucresult = uc_user_checkname($newusername);

    if ($ucresult == -1) {
        cpmsg(unicodeDecode('\u65b0\u7528\u6237\u540d\u5305\u542b\u654f\u611f\u5b57\u7b26\u0021'), '', 'error');
    } elseif ($ucresult == -2) {
        cpmsg(unicodeDecode('\u65b0\u7528\u6237\u540d\u5305\u542b\u88ab\u7cfb\u7edf\u5c4f\u853d\u7684\u5b57\u7b26\u0021'), '', 'error');
    } elseif ($ucresult == -3) {
        if (C::t('common_member')->fetch_by_username($newusername) || C::t('common_member_archive')->fetch_by_username($newusername)) {
            cpmsg(unicodeDecode('\u8be5\u65b0\u7528\u6237\u540d\u5df2\u6ce8\u518c\uff0c\u8bf7\u66f4\u6362\u65b0\u7528\u6237\u540d\u0021'), '', 'error');
        } else {
            cpmsg(unicodeDecode('\u65b0\u7528\u6237\u540d\u5df2\u5b58\u5728\u0021'), '', 'error');
        }
    }


    $censorexp = '/^(' . str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
    if ($_G['setting']['censoruser'] && @preg_match($censorexp, $newusername)) {
        cpmsg(unicodeDecode('\u65b0\u7528\u6237\u540d\u5305\u542b\u88ab\u7cfb\u7edf\u5c4f\u853d\u7684\u5b57\u7b26\u0021'), '', 'error');
    }
    if (submitcheck('submit') && $_GET['confirm'] == 'yes') {

        $utils->changename_for_dz($member['username'], $newusername);
        $utils->changename_for_uc($member['username'], $newusername);


        $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($member['uid']);
        $client_loginfo = $utils->get_log_info();
        $data = array(
            'uid' => $member['uid'],
            'username' => $member['username'],
            'areacode' => $userinfo[$field],
            'phone' => $userinfo['mobile'],
            'type' => 'changeusername',
            'operationuid' => $_G['uid'],
            'ip' => $client_loginfo['client_ip'],
            'port' => $client_loginfo['client_port'],
            'browser' => $client_loginfo['client_browser'],
            'os' => $client_loginfo['client_os'],
            'device' => $client_loginfo['client_device'],
            'useragent' => $client_loginfo['client_useragent'],
            'record' => serialize(array('oldusername' => $member['username'],'newusername'  => $newusername)),
            'dateline' => TIMESTAMP
        );

        C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

        cpmsg(unicodeDecode('\u7528\u6237\u540d\u4fee\u6539\u6210\u529f'), 'action=plugins&operation=config&do=' . $pluginid . '&identifier=jzsjiale_isms&pmod=more&module=rename', 'succeed');

    }
    cpmsg(unicodeDecode('\u786e\u5b9a\u8981\u5c06\u0075\u0069\u0064\u4e3a\u3010').$searchuid.unicodeDecode('\u3011\u7684\u7528\u6237\u540d\u3010').$member['username'].unicodeDecode('\u3011\u4fee\u6539\u4e3a\u65b0\u7528\u6237\u540d\u3010').$newusername.unicodeDecode('\u3011\u5417\uff1f'), 'action=plugins&operation=config&do=' . $pluginid . '&identifier=jzsjiale_isms&pmod=more&module=rename&act=rename&submit=yes&confirm=yes&searchuid=' . $searchuid . '&newusername=' . $newusername, 'form', array());
    dexit();
}


$getuid = daddslashes($_GET['searchuid']);
$getusername = daddslashes($_GET['searchusername']);
$getnewusername = daddslashes($_GET['newusername']);
if(!empty($getuid) && empty($getusername)){
    $getusername = getuserbyuid($getuid, 1)['username'];
}
$adminscript = ADMINSCRIPT;
if ($getuid == "undefined"){
    $getuid = "";
}
if ($getusername == "undefined"){
    $getusername = "";
}
if ($getnewusername == "undefined"){
    $getnewusername = "";
}

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=more&module=rename&act=rename', 'enctype');

showtableheader(unicodeDecode('\u6839\u636e\u7528\u6237\u0075\u0069\u0064\u4fee\u6539\u7528\u6237\u540d'), '');

showsetting(unicodeDecode('\u5f85\u4fee\u6539\u7528\u6237\u0075\u0069\u0064'),'searchuid',$getuid,'text','','',plang('module_notnull')."&nbsp;&nbsp;&nbsp;&nbsp;<a href='javascript:;' onClick='JavaScript:rePage();' style='color:blue;'>".unicodeDecode('\u70b9\u51fb\u67e5\u770b\u002f\u6838\u5bf9\u7528\u6237\u540d')."</a>&nbsp;&nbsp;&nbsp;&nbsp;".(!empty($getusername)?"<span style='color:red;'>".unicodeDecode('\u8be5\u0075\u0069\u0064\u5bf9\u5e94\u7684\u7528\u6237\u540d\u662f\u003a')."<strong>".$getusername."</strong></span>":""),'id="searchuid"');
showsetting(unicodeDecode('\u65b0\u7528\u6237\u540d'),'newusername',$getnewusername,'text','','',plang('module_notnull'),'id="newusername"');

echo <<<EOF
<script type="text/javascript">
function rePage() {
  let searchuid = document.getElementById("searchuid").value;
  let newusername = document.getElementById("newusername").value;

  if (typeof(searchuid) == undefined){
      searchuid = "";
  }
  if (typeof(newusername) == undefined){
      newusername = "";
  }
  self.location.href="{$adminscript}?action=plugins&operation=config&do={$pluginid}&identifier=jzsjiale_isms&pmod=more&module=rename&searchuid="+searchuid+"&newusername="+newusername;
}
</script>

EOF;
showsubmit('submit', 'submit');
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/
echo "<br/><br/><br/><br/>";
echo "<a href='javascript:;' onClick='javascript :history.back(-1);'>".unicodeDecode('\u8fd4\u56de\u4e0a\u4e00\u9875')."</a>";
?>