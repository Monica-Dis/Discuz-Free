<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 202001012040
 * updatetime: 202001012040
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;
$act = $_GET['act'];

if($act=='pluginlist') {
    $pluginlists = daddslashes($_GET['pluginlists']);
    $pluginliststr = implode(",", $pluginlists);

    showtableheader(unicodeDecode('\u8bf7\u9009\u62e9\u9700\u8981\u5f3a\u5236\u7ed1\u5b9a\u624b\u673a\u7684\u63d2\u4ef6\uff0c\u70b9\u51fb\u63d0\u4ea4\u5373\u53ef\u81ea\u52a8\u751f\u6210\u63d2\u4ef6\u201c\u5f3a\u5236\u7ed1\u5b9a\u624b\u673a\u63d2\u4ef6\u5217\u8868\u201d\u529f\u80fd\u9700\u8981\u7684\u683c\u5f0f\uff0c\u590d\u5236\u5230\u63d2\u4ef6\u8bbe\u7f6e\u4e2d\u5373\u53ef\u3002'), '');

    showsetting(unicodeDecode('\u63d2\u4ef6\u5217\u8868'),'pluginliststr',$pluginliststr,'textarea','','','<span style="color:red;">'.unicodeDecode('\u8bf7\u590d\u5236\u6587\u672c\u6846\u4e2d\u7684\u5168\u90e8\u5185\u5bb9\uff0c\u5e76\u586b\u5230\u63d2\u4ef6\u8bbe\u7f6e\u201c\u5f3a\u5236\u7ed1\u5b9a\u624b\u673a\u63d2\u4ef6\u5217\u8868\u201d\u9009\u9879\u4e2d\u3002').'</span>','','pluginliststr');
    showtablefooter(); /*Dism��taobao��com*/

    echo "<a href='javascript:;' onClick='javascript :history.back(-1);'>".unicodeDecode('\u8fd4\u56de\u4e0a\u4e00\u9875')."</a>&nbsp;&nbsp;<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=jzsjiale_isms#varsnew[g_forceplugin]' target='_self'>".unicodeDecode('\u8df3\u8f6c\u5230\u63d2\u4ef6\u8bbe\u7f6e\u9879')."</a>";
    dexit();
}



showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=more&module=pluginlist&act=pluginlist', 'enctype');

showtableheader(unicodeDecode('\u8bf7\u9009\u62e9\u9700\u8981\u5f3a\u5236\u7ed1\u5b9a\u624b\u673a\u7684\u63d2\u4ef6\uff0c\u70b9\u51fb\u63d0\u4ea4\u5373\u53ef\u81ea\u52a8\u751f\u6210\u63d2\u4ef6\u201c\u5f3a\u5236\u7ed1\u5b9a\u624b\u673a\u63d2\u4ef6\u5217\u8868\u201d\u529f\u80fd\u9700\u8981\u7684\u683c\u5f0f\uff0c\u590d\u5236\u5230\u63d2\u4ef6\u8bbe\u7f6e\u4e2d\u5373\u53ef\u3002'), '');

$plugins = C::t('common_plugin')->fetch_all_data();
$pluginlist = array();
foreach ($plugins as $key => $value){
    if(!in_array($value['identifier'],array('jzsjiale_isms','jzsjiale_sms')))
    $pluginlist[] = array($value['identifier'],$value['name']);
}
$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$forceplugin = $_config['g_forceplugin'];
$forceplugin_arr = array();
if(!empty($forceplugin)){
    $forceplugin_arr = explode(',',$forceplugin);
}
showsetting(unicodeDecode('\u63d2\u4ef6\u5217\u8868'), array('pluginlists',$pluginlist), $forceplugin_arr, 'mcheckbox');

showsubmit('submit', 'submit');
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/
?>