<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 202004292025
 * updatetime: 202004292025
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;

if(submitcheck('settingsubmit')) {

    $setting = $_GET['setting'];
    $settings = array('jsms_moreparameters' => serialize($setting));
    C::t('common_setting')->update_batch($settings);

    updatecache('setting');

    cpmsg('setting_update_succeed', 'action=plugins&operation=config&do=' . $pluginid . '&identifier=jzsjiale_isms&pmod=more&module=moreparameters', 'succeed');

}

$setting = C::t('common_setting')->fetch_all(array('jsms_moreparameters'));
$setting = (array)unserialize($setting['jsms_moreparameters']);

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=more&module=moreparameters', 'enctype');
showsubmit('settingsubmit', 'submit');

showtableheader(unicodeDecode('\u9a6c\u7532\u0041\u0050\u0050\u76f8\u5173\u53c2\u6570\u8bbe\u7f6e'), '');

showsetting(unicodeDecode('\u9a6c\u7532\u0041\u0050\u0050\u57df\u540d'),'setting[magappurl]',$setting["magappurl"],'text','','',unicodeDecode('\u8bf7\u586b\u5199\u9a6c\u7532\u0041\u0050\u0050\u57df\u540d\uff0c\u7ed3\u5c3e\u4e0d\u8981\u201c\u002f\u201d\uff0c\u793a\u4f8b\uff1a\u0068\u0074\u0074\u0070\u003a\u002f\u002f\u0077\u0077\u0077\u002e\u0078\u0078\u0078\u002e\u0063\u006f\u006d'));
showsetting(unicodeDecode('\u9a6c\u7532\u0041\u0050\u0050\u5bc6\u94a5\u0053\u0065\u0063\u0072\u0065\u0074'),'setting[magappsecret]',$setting["magappsecret"],'text','','',unicodeDecode('\u8bf7\u586b\u5199\u9a6c\u7532\u0041\u0050\u0050\u5bc6\u94a5\u0053\u0065\u0063\u0072\u0065\u0074\uff0c\u5e76\u4e3a\u5176\u5206\u914d\u5bf9\u5e94\u7684\u6743\u9650\u3002\u76ee\u524d\u9700\u8981\u6b64\u8bbe\u7f6e\u7684\u529f\u80fd\u6709\uff1a\u0031\u3001\u5bf9\u63a5\u9a6c\u7532\u0041\u0050\u0050\u65f6\uff0c\u4fee\u6539\u7528\u6237\u540d\uff0c\u540c\u6b65\u66f4\u65b0\u9a6c\u7532\u0041\u0050\u0050\u7528\u6237\u540d\u3002'));
showsetting(unicodeDecode('\u9a6c\u7532\u0041\u0050\u0050\u5185\u9690\u85cf\u5b89\u5168\u4e2d\u5fc3\u9876\u90e8\u83dc\u5355'),'setting[magapphidetopbar]',$setting["magapphidetopbar"],'radio','','',unicodeDecode('\u9a6c\u7532\u0041\u0050\u0050\u5185\u5d4c\u5165\u624b\u673a\u7248\u5b89\u5168\u4e2d\u5fc3\u529f\u80fd\u9875\u9762\u65f6\uff0c\u662f\u5426\u9690\u85cf\u5b89\u5168\u4e2d\u5fc3\u9876\u90e8\u7684\u5bfc\u822a\u83dc\u5355\uff0c\u5f00\u542f\u6b64\u5f00\u5173\u540e\uff0c\u4ec5\u5bf9\u9a6c\u7532\u0041\u0050\u0050\u5185\u6709\u6548\uff0c\u5176\u4ed6\u6d4f\u89c8\u5668\u8bbf\u95ee\u4e0d\u53d7\u5f71\u54cd\u3002\u0028\u8be5\u529f\u80fd\u9002\u7528\u4e8e\u4e3b\u7a0b\u5e8f\u0056\u0031\u002e\u0035\u002e\u0037\u0032\u53ca\u4ee5\u4e0a\u7248\u672c\u0029'));


showtableheader(unicodeDecode('\u5176\u4ed6\u53c2\u6570\u8bbe\u7f6e'), '');

showsetting(unicodeDecode('\u7b2c\u4e09\u65b9\u63d2\u4ef6\u8df3\u8f6c\u767b\u5f55\u7ed5\u8fc7\u4e2d\u8f6c\u9875'),'setting[pluginlogin]',$setting["pluginlogin"],'textarea','','',unicodeDecode('\u90e8\u5206\u7b2c\u4e09\u65b9\u63d2\u4ef6\u529f\u80fd\u88ab\u672c\u63d2\u4ef6\u68c0\u6d4b\u9700\u8981\u767b\u5f55\u65f6\uff0c\u4f1a\u51fa\u73b0\u5148\u8df3\u8f6c\u0064\u0069\u0073\u0063\u0075\u007a\u81ea\u5e26\u767b\u5f55\u9875\uff0c\u518d\u8df3\u8f6c\u672c\u63d2\u4ef6\u767b\u5f55\u9875\u9762\u7684\u95ee\u9898\uff0c\u8be5\u8bbe\u7f6e\u7528\u4e8e\u53bb\u9664\u7b2c\u4e09\u65b9\u63d2\u4ef6\u529f\u80fd\u8df3\u8f6c\u4e2d\u8f6c\u9875\u7684\u95ee\u9898\u3002\u6bcf\u884c\u4ec5\u652f\u6301\u586b\u5199\u4e00\u6761\u53c2\u6570\uff0c\u591a\u6761\u53c2\u6570\u6362\u884c\u586b\u5199\uff0c\u6bcf\u884c\u53c2\u6570\u683c\u5f0f\u5982\uff1a\u201c\u63d2\u4ef6\u6807\u8bc6\u540d\u007c\u7528\u4e8e\u8bc6\u522b\u529f\u80fd\u7684\u53c2\u6570\u540d\u007c\u7528\u4e8e\u8bc6\u522b\u529f\u80fd\u7684\u53c2\u6570\u503c\u201d\uff0c\u4e0d\u542b\u5f15\u53f7\uff0c\u4f7f\u7528\u201c\u007c\u201d\u5206\u5272\uff0c\u793a\u4f8b\u0028\u5bf9\u98de\u9e1f\u62db\u8058\u53d1\u5e03\u6309\u94ae\u7684\u68c0\u6d4b\u0029\uff1a\u201c\u0066\u006e\u005f\u006a\u006f\u0062\u007c\u006d\u007c\u0070\u0075\u0062\u006c\u0069\u0073\u0068\u201d\uff0c\u4ec5\u7528\u4e8e\u7535\u8111\u7248\u3002'));


showsubmit('settingsubmit', 'submit');
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/


echo "<br/><br/><br/><br/>";
echo "<a href='javascript:;' onClick='javascript :history.back(-1);'>".unicodeDecode('\u8fd4\u56de\u4e0a\u4e00\u9875')."</a>";
?>