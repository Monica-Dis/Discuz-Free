<?php
/**
 * Created by jzsjiale.
 * User: jzsjiale
 * Date: 2020/4/29
 * Time: 10:47 AM
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$config = array(
    'dir'=>'moreparameters',
    'module'=>'moreparameters',
    'version'=>'1.0.2',
    'title'=>'\u66f4\u591a\u8f85\u52a9\u53c2\u6570\u8bbe\u7f6e',
    'desc'=>'\u672c\u529f\u80fd\u7528\u4e8e\u66f4\u591a\u8f85\u52a9\u53c2\u6570\u7684\u8bbe\u7f6e'
);