<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 202002191510
 * updatetime: 202002191510
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;
$act = $_GET['act'];

if($act=='handle') {

    $id = daddslashes($_GET['id']);
    $uid = daddslashes($_GET['uid']);
    $examine = daddslashes($_GET['examine']);
    $reason = daddslashes($_GET['reason']);


    if (empty($id) || empty($uid)) {
        cpmsg(unicodeDecode('\u6570\u636e\u5f02\u5e38\uff0c\u8bf7\u91cd\u8bd5'), '', 'error');
    }
    $logoffapply_userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->fetch_by_id($id);
    if(empty($logoffapply_userinfo) || $logoffapply_userinfo['uid'] != $uid || $logoffapply_userinfo['freeze'] != '-1'){
        cpmsg(unicodeDecode('\u6570\u636e\u5f02\u5e38\uff0c\u672a\u627e\u5230\u8be5\u7528\u6237\u7684\u6ce8\u9500\u7533\u8bf7\uff0c\u8bf7\u91cd\u8bd5'), '', 'error');
    }

    if (empty($examine) || !in_array($examine, array('agree','refuse'))) {
        cpmsg(unicodeDecode('\u8bf7\u8bbe\u7f6e\u5ba1\u6838\u7ed3\u679c'), '', 'error');
    }

    $member = getuserbyuid($uid, 1);
    if (!$member || empty($member['uid'])) {
        cpmsg(unicodeDecode('\u672a\u67e5\u8be2\u5230\u8be5\u7528\u6237'), '', 'error');
    }elseif ($member['adminid'] == 1 || $member['adminid'] == 2) {
        cpmsg(unicodeDecode('\u62b1\u6b49\uff0c\u521b\u59cb\u4eba\u3001\u53d7\u4fdd\u62a4\u7528\u6237\u3001\u62e5\u6709\u7ad9\u70b9\u8bbe\u7f6e\u6743\u9650\u7684\u7528\u6237\u4e0d\u80fd\u4f7f\u7528\u8be5\u529f\u80fd\u6ce8\u9500\u8d26\u6237'), '', 'error');
    }

    if($_G['charset'] == 'gbk'){
        $reason = addslashes(dhtmlspecialchars($reason,ENT_COMPAT,'GBK'));
    }else{
        $reason = addslashes(dhtmlspecialchars($reason,ENT_COMPAT,'utf-8'));
    }

    $examinelang = array();
    $examinelang['agree'] = unicodeDecode('\u540c\u610f');
    $examinelang['refuse'] = unicodeDecode('\u62d2\u7edd');

    $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($member['uid']);
    $client_loginfo = $utils->get_log_info();
    $data = array(
        'uid' => $member['uid'],
        'username' => $member['username'],
        'areacode' => $userinfo[$field],
        'phone' => $userinfo['mobile'],
        'type' => 'logoffapply',
        'operationuid' => $_G['uid'],
        'ip' => $client_loginfo['client_ip'],
        'port' => $client_loginfo['client_port'],
        'browser' => $client_loginfo['client_browser'],
        'os' => $client_loginfo['client_os'],
        'device' => $client_loginfo['client_device'],
        'useragent' => $client_loginfo['client_useragent'],
        'record' => $examinelang[$examine].','.$reason,
        'dateline' => TIMESTAMP
    );

    C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

    if($examine == 'agree'){
        $uids = array();
        $uids[] = $member['uid'];

        require_once libfile('function/delete');
        $numdeleted = deletemember($uids, 0);
        loaducenter();
        uc_user_delete($uids);

        if (C::memory()->enable) {
            C::memory()->clear();
        }

        C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->deletebyid($id);
    }elseif($examine == 'refuse'){
        C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->update_freeze_by_id($id, '-2');
    }


    cpmsg(unicodeDecode('\u64cd\u4f5c\u6210\u529f'), 'action=plugins&operation=config&do=' . $pluginid . '&identifier=jzsjiale_isms&pmod=more&module=logoffapply','success');
    dexit();
}elseif ($act=='manage'){
    $id = daddslashes($_GET['id']);
    $uid = daddslashes($_GET['uid']);
    if (empty($id) || empty($uid)) {
        cpmsg(unicodeDecode('\u6570\u636e\u5f02\u5e38\uff0c\u8bf7\u91cd\u8bd5'), '', 'error');
    }
    $logoffapply_userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->fetch_by_id($id);
    if(empty($logoffapply_userinfo) || $logoffapply_userinfo['uid'] != $uid){
        cpmsg(unicodeDecode('\u6570\u636e\u5f02\u5e38\uff0c\u672a\u627e\u5230\u8be5\u7528\u6237\u7684\u6ce8\u9500\u7533\u8bf7\uff0c\u8bf7\u91cd\u8bd5'), '', 'error');
    }

    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=more&module=logoffapply&act=handle&id='.$id.'&uid='.$uid, 'enctype');

    showtableheader(unicodeDecode('\u8bf7\u5bf9\u8be5\u7528\u6237\u7684\u6ce8\u9500\u7533\u8bf7\u8fdb\u884c\u5904\u7406\uff01\u0075\u0069\u0064\uff1a').$uid.'&nbsp;&nbsp;&nbsp;'.unicodeDecode('\u7528\u6237\u540d\uff1a').getuserbyuid($uid)['username'], '');

    $examineselect = "";
    $examineselect .= '<option value="agree">'.unicodeDecode('\u540c\u610f').'</option>';
    $examineselect .= '<option value="refuse">'.unicodeDecode('\u62d2\u7edd').'</option>';

    showsetting(unicodeDecode('\u5ba1\u6838\u7ed3\u679c'),'examine','','<select name="examine">'.$examineselect.'</select>','','',plang('module_notnull'));
    showsetting(unicodeDecode('\u5ba1\u6838\u610f\u89c1'),'reason','','textarea','','');

    showsubmit('submit', 'submit');
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/

    echo "<br/><br/><br/><br/>";
    echo "<a href='javascript:;' onClick='javascript :history.back(-1);'>".unicodeDecode('\u8fd4\u56de\u4e0a\u4e00\u9875')."</a>";
    dexit();
}


/////////tip start

echo '<div class="colorbox"><h4>'.unicodeDecode('\u5173\u4e8e\u7528\u6237\u8d26\u6237\u6ce8\u9500\u7533\u8bf7\u5ba1\u6838\u7684\u8bf4\u660e').'</h4>'.
    '<table cellspacing="0" cellpadding="3"><tr>'.
    '<td valign="top">'.unicodeDecode('\u0031\u3001\u60a8\u53ef\u4ee5\u5728\u6b64\u5bf9\u7528\u6237\u7684\u8d26\u6237\u6ce8\u9500\u7533\u8bf7\u8fdb\u884c\u5904\u7406\uff0c\u4e00\u65e6\u540c\u610f\uff0c\u7528\u6237\u7684\u8d26\u6237\u6570\u636e\u5c06\u88ab\u6e05\u9664\uff0c\u4e14\u65e0\u6cd5\u6062\u590d\uff0c\u8bf7\u614e\u91cd\u5904\u7406\uff01').'</td></tr></table>'.
    '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

/////////tip end

$page = intval($_GET['page']);
$page = $page > 0 ? $page : 1;
$pagesize = 20;
$start = ($page - 1) * $pagesize;

$alllogoffapply = C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->range_logoffapply($start,$pagesize,'DESC');
$count = C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->count_logoffapply();

showtableheader(unicodeDecode('\u7533\u8bf7\u5217\u8868'));
showsubtitle(array('id'=>'ID','uid'=>unicodeDecode('\u7528\u6237\u0055\u0049\u0044'),'username'=>unicodeDecode('\u7528\u6237\u540d'),'dateline'=>unicodeDecode('\u7533\u8bf7\u65f6\u95f4'),'manage'=>unicodeDecode('\u64cd\u4f5c')));

$key_i = 0;
foreach ($alllogoffapply as $key => $value){
    $key_i++;
    showtablerow('', array('style="width:30px;"', 'style="width:150px;"', 'style="width:150px;"', 'style="width:150px;"', 'style="width:100px;"'), array(
            $key_i,
            '<span title="'.$value['uid'].'"><a href="home.php?mod=space&uid='.$value['uid'].'&do=profile" target="_blank">'.$value['uid'].'</a></span>',
            '<span title="'.$value['uid'].'"><a href="home.php?mod=space&uid='.$value['uid'].'&do=profile" target="_blank">'.getuserbyuid($value['uid'])['username'].'</a></span>',
            dgmdate($value['dateline']),
            '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=more&module=logoffapply&act=manage&id='.$value['id'].'&uid='.$value['uid'].'" style="color:red;">'.unicodeDecode('\u5ba1\u6838').'</a>')
    );
}

$mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=more&module=logoffapply';
$multipage = multi($count, $pagesize, $page, $mpurl);

showsubmit('', '', '', '', $multipage);

showtablefooter(); /*Dism��taobao��com*/
?>