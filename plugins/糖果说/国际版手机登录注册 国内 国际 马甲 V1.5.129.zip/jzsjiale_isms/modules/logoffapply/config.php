<?php
/**
 * Created by jzsjiale.
 * User: jzsjiale
 * Date: 2019/1/10
 * Time: 10:47 AM
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$config = array(
    'dir'=>'logoffapply',
    'module'=>'logoffapply',
    'version'=>'1.0.0',
    'title'=>'\u7528\u6237\u8d26\u6237\u6ce8\u9500\u7533\u8bf7\u5ba1\u6838',
    'desc'=>'\u8be5\u529f\u80fd\u7528\u4e8e\u7528\u6237\u8d26\u6237\u6ce8\u9500\u7533\u8bf7\u7684\u5ba1\u6838\u7ba1\u7406\u3002'
);