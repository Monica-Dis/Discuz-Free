<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 202001051450
 * updatetime: 202001051450
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;
$act = $_GET['act'];

showtableheader(unicodeDecode('\u5c0f\u4e91\u0041\u0050\u0050\u77ed\u4fe1\u63a5\u53e3\u6269\u5c55\u4f7f\u7528\u8bf4\u660e'), '');

echo "<tr>";
echo "<td>1.".unicodeDecode('\u5b89\u88c5\u672c\u6269\u5c55\u7ec4\u4ef6\u540e\uff0c\u4ece\u7f51\u7ad9\u6839\u76ee\u5f55\u201c\u0073\u006f\u0075\u0072\u0063\u0065\u002f\u0070\u006c\u0075\u0067\u0069\u006e\u002f\u006a\u007a\u0073\u006a\u0069\u0061\u006c\u0065\u005f\u0069\u0073\u006d\u0073\u002f\u006d\u006f\u0064\u0075\u006c\u0065\u0073\u002f\u0078\u0069\u0061\u006f\u0079\u0075\u006e\u201d\u4e2d\uff0c\u627e\u5230\u5176\u4e2d\u7684\u0073\u0065\u006e\u0064\u0053\u006d\u0073\u002e\u0070\u0068\u0070\u6587\u4ef6\u3002')."</td>";
echo "</tr>";
echo "<tr>";
echo "<td>2.".unicodeDecode('\u8fdb\u5165\u5c0f\u4e91\u0061\u0070\u0070\u6269\u5c55\u76ee\u5f55\u006d\u006f\u0062\u0063\u0065\u006e\u0074\u002f\u0061\u0070\u0070\u002f\u0063\u006f\u006d\u0070\u006f\u006e\u0065\u006e\u0074\u0073\u002f\u0077\u0065\u0062\u002f')."</td>";
echo "</tr>";
echo "<tr>";
echo "<td>3.".unicodeDecode('\u5c06\u7b2c\u0031\u6b65\u627e\u5230\u7684\u0073\u0065\u006e\u0064\u0053\u006d\u0073\u002e\u0070\u0068\u0070\u6587\u4ef6\u653e\u5230\u7b2c\u0032\u6b65\u7684\u76ee\u5f55\u4e2d\u3002')."</td>";
echo "</tr>";
echo "<tr>";
echo "<td>4.".unicodeDecode('\u5c0f\u4e91\u63d2\u4ef6\u540e\u53f0\u77ed\u4fe1\u63a5\u53e3\u9009\u81ea\u52a9\u5f00\u53d1\u3002')."</td>";
echo "</tr>";
echo "<tr>";
echo "<td>5.".unicodeDecode('\u6d4b\u8bd5\u77ed\u4fe1\u529f\u80fd\u3002')."</td>";
echo "</tr>";
showtablefooter(); /*Dism��taobao��com*/
echo "<br/>";
echo "<a href='javascript:;' onClick='javascript :history.back(-1);'>".unicodeDecode('\u8fd4\u56de\u4e0a\u4e00\u9875')."</a>";


echo "<br/><br/><br/><br/>";
echo "<span style='color:red;'>".unicodeDecode('\u5c0f\u4e91\u0041\u0050\u0050\u77ed\u4fe1\u63a5\u53e3\u6d4b\u8bd5\u6587\u4ef6\uff0c\u0044\u0069\u0073\u0063\u0075\u007a\u5185\u90e8\u5f15\u7528\u6d4b\u8bd5\u4ee3\u7801\uff08\u719f\u6089\u7f16\u7a0b\u7684\u670b\u53cb\u5982\u6709\u9700\u8981\uff0c\u53ef\u8fdb\u884c\u6d4b\u8bd5\uff0c\u975e\u5fc5\u987b\u6d4b\u8bd5\u5185\u5bb9\uff0c\u8bf7\u6309\u7167\u4e0a\u8ff0\u6b65\u9aa4\u64cd\u4f5c\u5373\u53ef\uff01\uff09')."</span>";
echo "<br/><br/>";
echo "define('IN_APPBYME',1);";echo "<br/>";
echo "if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/modules/xiaoyun/sendSms.php')){";echo "<br/>";
echo "    require DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/modules/xiaoyun/sendSms.php';";echo "<br/>";
echo "\$sendsms = new sendSms();";echo "<br/>";
echo "\$ret = \$sendsms->sendCode('18812345678','123456','register');";echo "<br/>";
echo "echo 'ret:'.\$ret;";echo "<br/>";
echo "}";echo "<br/>";

?>