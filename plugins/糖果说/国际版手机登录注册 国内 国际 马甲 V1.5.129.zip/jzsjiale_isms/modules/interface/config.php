<?php
/**
 * Created by jzsjiale.
 * User: jzsjiale
 * Date: 2019/1/10
 * Time: 10:47 AM
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$config = array(
    'dir'=>'interface',
    'module'=>'interface',
    'version'=>'1.0.0',
    'title'=>'\u9a8c\u8bc1\u7801\u77ed\u4fe1\u53d1\u9001\u63a5\u53e3',
    'desc'=>'\u5982\u679c\u7f51\u7ad9\uff08\u0044\u0069\u0073\u0063\u0075\u007a\uff09\u4e2d\u7684\u5176\u4ed6\u63d2\u4ef6\u6216\u529f\u80fd\u4e5f\u9700\u8981\u53d1\u9001\u9a8c\u8bc1\u7801\u77ed\u4fe1\uff0c\u53ef\u4ee5\u76f4\u63a5\u8c03\u7528\u672c\u63a5\u53e3\uff0c\u65e0\u9700\u5355\u72ec\u96c6\u6210\u77ed\u4fe1\u4e1a\u52a1\uff0c\u65b9\u9762\u9a8c\u8bc1\u7801\u53d1\u9001\u529f\u80fd\u7684\u5b9e\u73b0\uff01'
);