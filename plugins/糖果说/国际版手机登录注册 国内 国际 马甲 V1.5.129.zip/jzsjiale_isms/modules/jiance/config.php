<?php
/**
 * Created by jzsjiale.
 * User: jzsjiale
 * Date: 2020/1/5
 * Time: 10:47 AM
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$config = array(
    'dir'=>'jiance',
    'module'=>'jiance',
    'version'=>'1.0.0',
    'title'=>'\u63d2\u4ef6\u8fd0\u884c\u73af\u5883\u68c0\u6d4b',
    'desc'=>'\u672c\u529f\u80fd\u7528\u4e8e\u672c\u63d2\u4ef6\u8fd0\u884c\u6240\u9700\u8fd0\u884c\u73af\u5883\u7684\u68c0\u6d4b\u3002'
);