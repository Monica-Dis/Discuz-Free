<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201909171510
 * updatetime: 201909171652
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

loadcache('plugin');
global $_G, $lang;

define('JZSJIALE_ISMS_PLUGIN_ID', 'jzsjiale_isms');
define('JZSJIALE_ISMS_PLUGIN_ROOT_PATH', 'source/plugin/');
define('JZSJIALE_ISMS_PLUGIN_PATH', 'source/plugin/' . JZSJIALE_ISMS_PLUGIN_ID . '/');
define('JZSJIALE_ISMS_PLUGIN_STATIC_PATH', 'source/plugin/' . JZSJIALE_ISMS_PLUGIN_ID . '/static/');
define('JZSJIALE_ISMS_PLUGIN_TEMPLATE_PC_PATH', 'source/plugin/' . JZSJIALE_ISMS_PLUGIN_ID . '/template/touch/frontend/');
define('JZSJIALE_ISMS_PLUGIN_API', 'plugin.php?id=jzsjiale_isms:api');

class mobileplugin_jzsjiale_isms {

    function global_header_mobile() {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];

        $g_extend = "";
        if (!empty($_config['g_mcss'])){
            $g_extend .= $_config['g_mcss'];
        }

        if ($_G['uid']){
            $g_extend .= "<script src='source/plugin/jzsjiale_isms/static/js/MiniDialog-es5.min.js'></script>";
        }

        if(!empty(getcookie('jzsjiale_isms_ucsynlogin'))){
            $g_extend .= base64_decode(getcookie('jzsjiale_isms_ucsynlogin'));
            dsetcookie('jzsjiale_isms_ucsynlogin','');
        }

        return $g_extend;
    }
    function global_footer_mobile() {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];

        if (!$_G['uid']){
            dsetcookie("isms_login_referer","");
            return;
        }

        $groupid = $_G['groupid'];
        $nobindpopup = "";
        if (in_array('popup', (array) unserialize($_config['g_mdetailed'])) && $_G['uid'] && in_array($groupid, (array) unserialize($_config['g_forceusergroup']))){
            //$finduser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);
            //if(empty($finduser['mobile'])){
            getuserprofile('mobile');
            if(empty($_G['member']['mobile'])){
               $nobindpopup = "<script>Dialog({title: '".$this->plang('tip_bindphone_title')."',content: '".$_config['g_forcetip']."',ok: {callback: function () {window.location.href = 'plugin.php?id=jzsjiale_isms:security&op=bindmobile';}}});</script>";

            }
        }


        $basescript = $_G['basescript'];
        $curm = CURMODULE;

        if($basescript != "home" || $curm != "space" || empty($_GET[mycenter])){
            return $nobindpopup;
        }

        if (!in_array('securitycenter',(array)unserialize($_config['g_mdetailed']))){
            return $nobindpopup;
        }

        include_once template('jzsjiale_isms:security/default/securitycenterbtn');
        return $securitycenterbtn.$nobindpopup;

    }


    public function common() {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];

        if (!$_G['uid']){
            return;
        }

        if(in_array('magapperror',(array) unserialize($_config['g_mdetailed'])) && strpos($_SERVER['HTTP_USER_AGENT'], 'php-requests') !== false ){
            return;
        }

        $groupid = $_G['groupid'];
        $basescript = $_G['basescript'];
        $curm = CURMODULE;

        getuserprofile('mobile');

        if(is_null(getglobal('isms_freeze'))){
            $freeze_userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->fetch_by_uid($_G['uid']);
            if($freeze_userinfo && $freeze_userinfo['freeze'] > 0){
                setglobal('isms_freeze',$freeze_userinfo['freeze']);
            }else{
                setglobal('isms_freeze',0);
            }
        }
        if(getglobal('isms_freeze') > 0 && $curm != "jzsjiale_isms" && $_GET['op'] != 'password' && $_GET['action'] != 'logout' && !submitcheck(['passwordsubmit'])){
            if(!empty($_G['member']['mobile'])){
                if(getglobal('isms_freeze') == 1){
                    showmessage($this->plang('msg_err_location_login_password_tooshort'), 'plugin.php?id=jzsjiale_isms:security&op=changepassword', 'succeed');
                }elseif(getglobal('isms_freeze') == 2 || getglobal('isms_freeze') == 4){
                    showmessage($this->plang('msg_err_location_login_outofdate'), 'plugin.php?id=jzsjiale_isms:security&op=needverify', 'succeed');
                }elseif(getglobal('isms_freeze') == 3){
                    showmessage($this->plang('msg_err_location_login_differentplaces'), 'plugin.php?id=jzsjiale_isms:security&op=needverify', 'succeed');
                }else{
                    showmessage($this->plang('msg_err_location_login_needverify'), 'plugin.php?id=jzsjiale_isms:security&op=needverify', 'succeed');
                }
            }else{
                showmessage($_config['g_forcetip'], 'plugin.php?id=jzsjiale_isms:security&op=bindmobile', 'succeed');
            }
        }

        if (!empty($_config['g_force']) && !empty($_config['g_forceusergroup'])){

            if (!in_array($groupid, (array) unserialize($_config['g_forceusergroup']))){
                return;
            }

            //$finduser = array();
            //$finduser =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);
            if(!empty($_G['member']['mobile'])){
                return;
            }

            //20201006 add
            if($_config['g_forcecountryip'] && !empty($_config['g_forcecountrycode'])){

                $g_forcecountrycode = explode(",", $_config['g_forcecountrycode']);
                if(!empty($_G['cookie']['jisms_forcecountrycode'])){
                    if(!in_array($_G['cookie']['jisms_forcecountrycode'], $g_forcecountrycode)){
                        return;
                    }
                }else{
                    if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkipapi.class.php')){
                        @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/checkipapi.class.php';
                        $checkip = new Checkipapi();
                        $ipdata = $checkip->get_ip_data();

                        $countrycode = $ipdata['countryCode'];

                        if(!empty($countrycode)){
                            dsetcookie('jisms_forcecountrycode', $countrycode, 2592000);
                            if(!in_array($countrycode, $g_forcecountrycode)){
                                return;
                            }
                        }
                    }
                }
            }
            //20201006 end

            if ($basescript == "forum" || $basescript == "group"){

                if($curm == "post" && in_array('forumpostandreply', (array) unserialize($_config['g_force']))){
                    if($_GET['action'] == "reply" && $_GET['infloat'] == "yes"){
                        showmessage('<a href="plugin.php?id=jzsjiale_isms&#58;security&op=bindmobile"><span style="color&#58;red;">'.$_config['g_forcetip'].'</span></a>', 'plugin.php?id=jzsjiale_isms:security&op=bindmobile', array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => true));
                    }elseif($_GET['action'] == "newthread" && $_GET['infloat'] == "yes"){
                        showmessage('<a href="plugin.php?id=jzsjiale_isms&#58;security&op=bindmobile"><span style="color&#58;red;">'.$_config['g_forcetip'].'</span></a>', 'plugin.php?id=jzsjiale_isms:security&op=bindmobile', array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => true));
                    }else{
                        if(defined('IN_MOBILE_API')){
                            showmessage($_config['g_forcetip'], 'plugin.php?id=jzsjiale_isms:security&op=bindmobile', 'succeed');
                        }else{
                            showmessage('<script type="text/javascript" reload="1">Dialog({title: "'.$this->plang('tip_bindphone_title').'",content: "'.$_config['g_forcetip'].'",ok: {callback: function () {window.location.href = "plugin.php?id=jzsjiale_isms:security&op=bindmobile";}}});</script>', '', array(), array('msgtype'	=> 3),1);
                        }
                    }

                }elseif($curm == "collection" && $_GET['action'] == "edit" && in_array('forumcollection', (array) unserialize($_config['g_force']))){
                    showmessage($_config['g_forcetip'], 'plugin.php?id=jzsjiale_isms:security&op=bindmobile', 'succeed');
                }elseif($curm == "group" && $_GET['action'] == "create" && in_array('groupcreate', (array) unserialize($_config['g_force']))){
                    showmessage($_config['g_forcetip'], 'plugin.php?id=jzsjiale_isms:security&op=bindmobile', 'succeed');
                }elseif($curm == "misc" && in_array('forumscore', (array) unserialize($_config['g_force']))){
                    showmessage($_config['g_forcetip'], 'plugin.php?id=jzsjiale_isms:security&op=bindmobile', array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => true));
                }elseif(in_array('forumview', (array) unserialize($_config['g_force'])) && !in_array($_GET['action'], array('checkpostrule'))){
                    showmessage($_config['g_forcetip'], 'plugin.php?id=jzsjiale_isms:security&op=bindmobile', 'succeed');
                }else{
                    return;
                }
            }elseif ($basescript == "portal"){
                if(($_GET['ac'] == "article" || $_GET['ac'] == "comment") && in_array('portalpostandreply', (array) unserialize($_config['g_force']))){
                    showmessage($_config['g_forcetip'], 'plugin.php?id=jzsjiale_isms:security&op=bindmobile', 'succeed');
                }elseif(in_array('portalview', (array) unserialize($_config['g_force'])) && !in_array($_GET['action'], array('checkpostrule'))){
                    showmessage($_config['g_forcetip'], 'plugin.php?id=jzsjiale_isms:security&op=bindmobile', 'succeed');
                }else{
                    return;
                }
            }elseif ($basescript == "home"){
                if(in_array('space', (array) unserialize($_config['g_force'])) && ($curm == "spacecp" || $curm == "space" || $curm == "follow") && (in_array($_GET['ac'],array("pm","profile","avatar","usergroup","privacy","blog","comment","click","doing","follow","share")) || in_array($_GET['do'],array("send","doing","notice")) )){
                    if($_GET['op'] == 'password' || submitcheck('passwordsubmit')){
                        return;
                    }
                    showmessage($_config['g_forcetip'], 'plugin.php?id=jzsjiale_isms:security&op=bindmobile', 'succeed');
                }

            }elseif ($basescript == "plugin"){
                if(in_array('plugin', (array) unserialize($_config['g_force'])) && !empty($_config['g_forceplugin'])){
                    $forceplugin = explode(',',$_config['g_forceplugin']);
                    if(in_array($curm,$forceplugin) ){
                        showmessage($_config['g_forcetip'], 'plugin.php?id=jzsjiale_isms:security&op=bindmobile', 'succeed');
                    }else{
                        return;
                    }

                }

            }else{
                return;
            }
        }
    }

    public function plang($str) {
        return lang('plugin/jzsjiale_isms', $str);
    }
}

class mobileplugin_jzsjiale_isms_member extends mobileplugin_jzsjiale_isms
{
    function register()
    {

        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];

        if($_G['uid']){
            return;
        }

        if (!$_config['g_openmobileregister']) {
            return;
        }

        if($_GET['regsubmit'] == 'yes'){
            $url ="member.php?mod=register";
            showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);
        }

        define('NOROBOT', TRUE);

        require_once('class/class_member.php');
        $_G['setting']['sendregisterurl']=1;

        $mobiletemplate = 'default';
        $jsms_muban_mobile = (array)unserialize($_G['setting']['jsms_muban_mobile']);
        if(!empty($jsms_muban_mobile['mobiletemplate'])){
            $mobiletemplate = $jsms_muban_mobile['mobiletemplate'];
        }

        $ctl_obj = new  mobile_register_ctl();
        $ctl_obj->setting = $_G['setting'];
        $ctl_obj->template = 'jzsjiale_isms:frontend/'.$mobiletemplate.'/register';
        if($_G['setting']['bbclosed']) {
            $ctl_obj->template = 'jzsjiale_isms:frontend/'.$mobiletemplate.'/bbclosed';
        }
        $ctl_obj->regclosed = 'jzsjiale_isms:frontend/'.$mobiletemplate.'/regclosed';
        $ctl_obj->on_register();
        exit;


    }

    function logging() {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];

        if($_G['uid']){
            return;
        }

        if ($_GET['viewlostpw']){
            if($_config['g_openmobilezhaohui']){
                $url ="member.php?mod=lostpasswd";
                showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);
            }else{
                return;
            }
        }

        if (!$_config['g_openmobilelogin']) {
            return;
        }

        if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && in_array('weixinautologin',(array) unserialize($_config['g_mdetailed']))){
            return;
        }

        if(submitcheck('loginsubmit') || $_GET['loginsubmit'] == 'yes' || $_GET['infloat'] == 'yes' || $_GET['inajax'] == '1'){
            $url ="member.php?mod=logging&action=login";
            showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);
        }

        define('NOROBOT', TRUE);

        require_once('class/class_member.php');
        $_G['setting']['sendregisterurl']=1;

        $mobiletemplate = 'default';
        $jsms_muban_mobile = (array)unserialize($_G['setting']['jsms_muban_mobile']);
        if(!empty($jsms_muban_mobile['mobiletemplate'])){
            $mobiletemplate = $jsms_muban_mobile['mobiletemplate'];
        }

        if(strpos($mobiletemplate,'spa') === false){
            $logintype = 'login_seccode';
            $g_mlogintype = (array) unserialize($_config['g_mlogintype']);
            if(empty($_GET['logintype'])){
                if ($_config['g_mdefaultlogintype'] == 'seccode' && in_array('seccode', $g_mlogintype)) {
                    $logintype = 'login_seccode';
                }elseif ($_config['g_mdefaultlogintype'] == 'mima' && in_array('mima', $g_mlogintype)) {
                    $logintype = 'login_mima';
                }elseif ($_config['g_mdefaultlogintype'] == 'mimahaiwai' && in_array('mimahaiwai', $g_mlogintype)) {
                    $logintype = 'login_mimahaiwai';
                }else{
                    if(count($g_mlogintype) > 0){

                        $logintype = 'login_'.$g_mlogintype[0];
                    }else{
                        return;
                    }
                }
            }else{
                if ($_GET['logintype'] == 'seccode' && in_array('seccode', $g_mlogintype)){
                    $logintype = 'login_seccode';
                }elseif ($_GET['logintype'] == 'mima' && in_array('mima', $g_mlogintype)){
                    $logintype = 'login_mima';
                }elseif ($_GET['logintype'] == 'mimahaiwai' && in_array('mimahaiwai', $g_mlogintype)){
                    $logintype = 'login_mimahaiwai';
                }else{
                    if(count($g_mlogintype) > 0){

                        $logintype = 'login_'.$g_mlogintype[0];
                    }else{
                        return;
                    }
                }
            }
        }else{
            $logintype = 'login';
        }


        $ctl_obj = new  mobile_logging_ctl();
        $ctl_obj->setting = $_G['setting'];
        $ctl_obj->template = 'jzsjiale_isms:frontend/'.$mobiletemplate.'/'.$logintype;
        if($_G['setting']['bbclosed']) {
            $ctl_obj->template = 'jzsjiale_isms:frontend/'.$mobiletemplate.'/bbclosed';
        }
        $ctl_obj->on_login();
        exit;
    }

    function lostpasswd(){
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];

        if($_G['uid']){
            $url = $_G['siteurl'];
            showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);
        }

        if (!$_config['g_openmobilezhaohui']) {
            return;
        }

        if (submitcheck('lostpwsubmit') || $_GET['lostpwsubmit'] == 'yes'){
            $url ="member.php?mod=lostpasswd";
            showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);
        }


        define('NOROBOT', TRUE);

        require_once('class/class_member.php');

        $mobiletemplate = 'default';
        $jsms_muban_mobile = (array)unserialize($_G['setting']['jsms_muban_mobile']);
        if(!empty($jsms_muban_mobile['mobiletemplate'])){
            $mobiletemplate = $jsms_muban_mobile['mobiletemplate'];
        }

        if(strpos($mobiletemplate,'spa') === false){
            $lostpasswdtmp = "lostpasswd";
            if(in_array($_config['g_openmobilezhaohui'], array('1','3'))){
                $lostpasswdtmp = "lostpasswd";
            }elseif(in_array($_config['g_openmobilezhaohui'], array('2','4'))){
                $lostpasswdtmp = "lostpasswd_email";
            }else{
                $lostpasswdtmp = "lostpasswd";
            }

            if(!empty($_GET['type']) && in_array($_config['g_openmobilezhaohui'], array('3','4'))){
                if($_GET['type'] == "mobile"){
                    $lostpasswdtmp = "lostpasswd";
                }elseif($_GET['type'] == "email"){
                    $lostpasswdtmp = "lostpasswd_email";
                }else{
                    $lostpasswdtmp = "lostpasswd";
                }
            }
        }else{
            $lostpasswdtmp = "lostpasswd";
        }

        $ctl_obj = new mobile_lostpasswd_ctl();
        $ctl_obj->setting = $_G['setting'];
        $ctl_obj->template = 'jzsjiale_isms:frontend/'.$mobiletemplate.'/'.$lostpasswdtmp;
        if($_G['setting']['bbclosed']) {
            $ctl_obj->template = 'jzsjiale_isms:frontend/'.$mobiletemplate.'/bbclosed';
        }
        $ctl_obj->on_lostpasswd();
        exit;

    }

    function getpasswd(){
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];

        if($_G['uid']){
            $url = $_G['siteurl'];
            showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);
        }

        if (!$_config['g_openmobilezhaohui']) {
            return;
        }

        if (submitcheck('getpwsubmit')){
            $url ="member.php?mod=lostpasswd";
            showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);
        }

        define('NOROBOT', TRUE);

        require_once('class/class_member.php');

        $mobiletemplate = 'default';
        $jsms_muban_mobile = (array)unserialize($_G['setting']['jsms_muban_mobile']);
        if(!empty($jsms_muban_mobile['mobiletemplate'])){
            $mobiletemplate = $jsms_muban_mobile['mobiletemplate'];
        }

        $ctl_obj = new mobile_getpasswd_ctl();
        $ctl_obj->setting = $_G['setting'];
        $ctl_obj->template =  'jzsjiale_isms:frontend/'.$mobiletemplate.'/getpasswd';
        if($_G['setting']['bbclosed']) {
            $ctl_obj->template = 'jzsjiale_isms:frontend/'.$mobiletemplate.'/bbclosed';
        }
        $ctl_obj->on_getpasswd();
        exit;

    }

}

class mobileplugin_jzsjiale_isms_home extends mobileplugin_jzsjiale_isms {

    function spacecp_profile() {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];

        if (!$_G['uid']){
            return;
        }


        if ($_config['g_openmobilebangding']){

            loadcache('profilesetting');
            if(empty($_G['cache']['profilesetting'])) {
                require_once libfile('function/cache');
                updatecache('profilesetting');
                loadcache('profilesetting');
            }

            $_G['cache']['profilesetting']['mobile']['available'] = 0;

            if($_config['g_isopenautoverify'] && $_config['g_mobileverify']){
                $_G['setting']['verify'][$_config['g_mobileverify']]['available'] = 0;
            }

        }

        if($_GET['op'] == 'password'){

            if($_GET['resend'] == '1'){
                return;
            }

            if($_G['member']['freeze'] > 0){
                $freeze_userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->fetch_by_uid($_G['uid']);
                $freeze = $_G['member']['freeze'] != '2' ? $_G['member']['freeze'] : 3;
                if($freeze_userinfo){
                    C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->update_freeze_by_uid($_G['uid'],$freeze);
                }else{
                    $data = array(
                        'uid' => $_G['uid'],
                        'freeze' => $freeze,
                        'dateline' => TIMESTAMP
                    );

                    C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->insert($data, true);
                }
                //$_G['jzsjiale_isms']['member']['freeze'] = $freeze;
                setglobal('isms_freeze',$freeze);

                $field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';
                $userinfo =  C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_uid($_G['uid']);
                @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
                $utils = new ISMSUtils();
                $client_loginfo = $utils->get_log_info();
                $data = array(
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'areacode' => $userinfo[$field],
                    'phone' => $userinfo['mobile'],
                    'type' => 'freeze',
                    'operationuid' => $_G['uid'],
                    'ip' => $client_loginfo['client_ip'],
                    'port' => $client_loginfo['client_port'],
                    'browser' => $client_loginfo['client_browser'],
                    'os' => $client_loginfo['client_os'],
                    'device' => $client_loginfo['client_device'],
                    'useragent' => $client_loginfo['client_useragent'],
                    'record' => $freeze,
                    'dateline' => TIMESTAMP
                );

                C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

                C::t('common_member')->update($_G['uid'], array('freeze' => 0));
                $_G['member']['freeze'] = 0;

                $url ="plugin.php?id=jzsjiale_isms:security&op=needverify";
                switch ($freeze){
                    case 1:
                        $url ="plugin.php?id=jzsjiale_isms:security&op=changepassword";
                        break;
                    case 2:
                        $url ="plugin.php?id=jzsjiale_isms:security&op=needverify";
                        break;
                    case 3:
                        $url ="plugin.php?id=jzsjiale_isms:security&op=needverify";
                        break;
                    default:
                        $url ="plugin.php?id=jzsjiale_isms:security&op=needverify";
                        break;

                }
                showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);

            }else{
                if($_GET['from'] != 'contact') {
                    if ($_config['g_openmobilechangepwd']){
                        $url ="plugin.php?id=jzsjiale_isms:security&op=changepassword";
                        showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">'.lang('plugin/jzsjiale_isms', 'tiaozhuanzhong').'</span><script type="text/javascript" reload="1">window.location.href="'.$url.'";</script>', '', array(), array('msgtype'	=> 3),1);
                    }
                }else{
                    $url = "plugin.php?id=jzsjiale_isms:security&op=email";
                    showmessage('<span style="display: inline-table;height:40px;line-height:40px;font-size:14px;font-height:14px;vertical-align:middle;text-align:center;">' . lang('plugin/jzsjiale_isms', 'tiaozhuanzhong') . '</span><script type="text/javascript" reload="1">window.location.href="' . $url . '";</script>', '', array(), array('msgtype' => 3), 1);
                }
            }
        }

    }


}
//From: d'.'is'.'m.ta'.'obao.com
?>