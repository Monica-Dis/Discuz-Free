<?php

/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$act = $_GET['act'];
$formhash =  $_GET['formhash']? $_GET['formhash']:'';
loadcache('plugin');
global $_G, $lang;

$_config = $_G['cache']['plugin']['jzsjiale_isms'];
$field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';

if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
    @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
    $utils = new ISMSUtils();
}

if($act == 'bangding'){
    if(submitcheck('submit')){

        $setting = $_GET['setting'];
        $dsp = array('dateline'=>TIMESTAMP);
        $dsp['username'] = daddslashes(trim($setting['username']));
        $dsp['areacode'] = daddslashes(trim($setting['areacode']));
        $dsp['phone'] = daddslashes(trim($setting['phone']));

        if(empty($dsp['username'])){
            cpmsg('jzsjiale_isms:dusername_null', '', 'error');
        }
        if(empty($dsp['areacode'])){
            $dsp['areacode'] = '86';
        }
        if(empty($dsp['phone'])){
            cpmsg('jzsjiale_isms:dphone_null', '', 'error');
        }
        if(!$utils->isMobile($dsp['phone'], $dsp['areacode'])){
            cpmsg('jzsjiale_isms:dphoneerror_null', '', 'error');
        }

        // 20190727 add start
        $smsuser = C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($dsp['areacode'], $dsp['phone'], $field);
        if (!empty($smsuser)) {
            cpmsg('jzsjiale_isms:phonecunzai', '', 'error');
        }
       
        $member = C::t('common_member')->fetch_by_username($dsp['username']);
        
        if(empty($member)){
            cpmsg('jzsjiale_isms:nousername', '', 'error');
        }

        $dsp['uid'] = $member['uid'];

        $update_mobile = $dsp['phone'];

        $client_loginfo = $utils->get_log_info();
        $data = array(
            'uid' => $dsp['uid'],
            'username' => $dsp['username'],
            'areacode' => $dsp['areacode'],
            'phone' => $update_mobile,
            'type' => 'bind',
            'operationuid' => $_G['uid'],
            'ip' => $client_loginfo['client_ip'],
            'port' => $client_loginfo['client_port'],
            'browser' => $client_loginfo['client_browser'],
            'os' => $client_loginfo['client_os'],
            'device' => $client_loginfo['client_device'],
            'useragent' => $client_loginfo['client_useragent'],
            'dateline' => TIMESTAMP
        );

        C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);
        C::t('common_member_profile')->update($dsp['uid'], array('mobile'=> $update_mobile,$field => $dsp['areacode']));

        //verify start
        if($_config['g_isopenautoverify'] && $_config['g_mobileverify']){
            $verifyuid = $dsp['uid'];
            $memberautoverify = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$verifyuid);
            if(empty($memberautoverify)){
                C::t('common_member_verify')->insert(array('uid' => $verifyuid,'verify'.$_config['g_mobileverify'] => 1));
            }else{
                C::t('common_member_verify')->update($verifyuid, array('verify'.$_config['g_mobileverify'] => 1));
            }

        }
        //verify end

        //gengxinrenzheng start
        $memberverifyres = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$dsp['uid']);
        for ($verifyx=1; $verifyx<=7; $verifyx++) {
            if($memberverifyres['verify'+$verifyx] != 1){
                $memberverifyinfores = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify_info').' WHERE uid = '.$dsp['uid'].' and verifytype = '.$verifyx);
                if(empty($memberverifyinfores)){
                    continue;
                }
                $verifyinfo = dunserialize($memberverifyinfores['field']);
                $verifyinfo['mobile'] = $dsp['phone'];

                C::t('common_member_verify_info')->update($memberverifyinfores['vid'], array('field' => serialize($verifyinfo)));
            }
        }
        //gengxinrenzheng end

        cpmsg('jzsjiale_isms:addok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser', 'succeed');

    }

    // all areacode start
    $allareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
    $allareacode = (array)unserialize($allareacode['jisms_allareacode']);
    if(!$allareacode || empty($allareacode) || $allareacode[0] === false){
        $allareacode = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->getallbystatus(1);

        $allareacodesettings = array('jisms_allareacode' => serialize($allareacode));
        C::t('common_setting')->update_batch($allareacodesettings);

        updatecache('setting');
    }
    // all areacode end

    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=bangding', 'enctype');
    showtableheader(plang('addbangdingtitle'), '');
    showsetting(plang('dusername'),'setting[username]','','text','','',plang('dusername_msg'));
    
    foreach($allareacode as $k =>$v){
        $smsareacodeselect .= '<option value="'.$v['areacode'].'" '.($v['areacode'] == 86?"selected":"").'>'.$v['code'].'&nbsp;&nbsp;&nbsp;&nbsp;'.$v['countrycn'].'('.$v['country'].')&nbsp;&nbsp;&nbsp;&nbsp;+'.$v['areacode'].'</option>';
    }
    if(empty($smsareacodeselect)){
        $smsareacodeselect = '<option value="86" selected>'.plang('china').'</option>';
    }
    showsetting(plang('smssendareacode'),'setting[areacode]','','<select name="setting[areacode]">'.$smsareacodeselect.'</select>','',0,plang('smssendareacode_msg'),1,'smssendareacode');
    showsetting(plang('dphone'),'setting[phone]','','text','','',plang('dphone_msg'));

    showsubmit('submit', 'submit');
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/

    exit();
}elseif($act=='jiechubangding'){
	$uid = dintval($_GET['uid']);
	$setting = C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_member_profile_by_uid($uid);
	if(empty($setting))
		cpmsg('jzsjiale_isms:empty', '', 'error');
	if(submitcheck('submit')){

        $client_loginfo = $utils->get_log_info();
        $data = array(
            'uid' => $uid,
            'username' => $setting['username'],
            'areacode' => !empty($setting[$field])?$setting[$field]:'86',
            'phone' => $setting['mobile'],
            'type' => 'unbind',
            'operationuid' => $_G['uid'],
            'ip' => $client_loginfo['client_ip'],
            'port' => $client_loginfo['client_port'],
            'browser' => $client_loginfo['client_browser'],
            'os' => $client_loginfo['client_os'],
            'device' => $client_loginfo['client_device'],
            'useragent' => $client_loginfo['client_useragent'],
            'record' => serialize(array('beforebinding_areacode' => (!empty($setting[$field])?$setting[$field]:'86'),'beforebinding_phone' => $setting['mobile'])),
            'dateline' => TIMESTAMP
        );

        C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);
        C::t('common_member_profile')->update($uid, array('mobile'=> '',$field => ''));

		//verify start
		if($_config['g_mobileverify']){
		    $verifyuid = $setting['uid'];
		    $memberautoverify = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$verifyuid);
		    if(empty($memberautoverify)){
		        C::t('common_member_verify')->insert(array('uid' => $verifyuid,'verify'.$_config['g_mobileverify'] => 0));
		    }else{
		        C::t('common_member_verify')->update($verifyuid, array('verify'.$_config['g_mobileverify'] => 0));
		    }
		
		}
		
		
		//verify end
		
		//gengxinrenzheng start
		$memberverifyres = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$uid);
    	for ($verifyx=1; $verifyx<=7; $verifyx++) {
        	if($memberverifyres['verify'+$verifyx] != 1){
        	    $memberverifyinfores = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify_info').' WHERE uid = '.$uid.' and verifytype = '.$verifyx);
        	    if(empty($memberverifyinfores)){
        	        continue;
        	    }
        	    $verifyinfo = dunserialize($memberverifyinfores['field']);
        	    $verifyinfo['mobile'] = "";
        	    
        	    C::t('common_member_verify_info')->update($memberverifyinfores['vid'], array('field' => serialize($verifyinfo)));
        	}
        }
		//gengxinrenzheng end
		
		cpmsg('jzsjiale_isms:jiechuok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser', 'succeed');
	}
	cpmsg('jzsjiale_isms:delbangding','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=jiechubangding&uid='.$uid.'&submit=yes','form',array('username' => $setting['username']));
}elseif($act=='piliangshanchuphone'){
	if(submitcheck('submit')){
	    DB::query("UPDATE ".DB::table('common_member_profile')." SET mobile = '',".$field." = ''");

	    //verify start
	    if($_config['g_mobileverify']){
	        DB::query("UPDATE ".DB::table('common_member_verify')." SET verify".$_config['g_mobileverify']." = 0");
	    }
	    //verify end
	    
		cpmsg('jzsjiale_isms:piliangshanchuok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser', 'succeed');
	}
	cpmsg('jzsjiale_isms:quedingpiliangshanchu','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=piliangshanchuphone&submit=yes','form',array());
}elseif($act=='lijibangding'){
    $uid = dintval($_GET['uid']);
    $memberinfo = C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_member_by_uid($uid);
    if(empty($memberinfo))
        cpmsg('jzsjiale_isms:empty', '', 'error');
    if(submitcheck('submit')){

        $setting = $_GET['setting'];
        $dsp = array('dateline'=>TIMESTAMP);
        $dsp['username'] = $memberinfo['username'];
        $dsp['areacode'] = daddslashes(trim($setting['areacode']));
        $dsp['phone'] = daddslashes(trim($setting['phone']));

        if(empty($dsp['username'])){
            cpmsg('jzsjiale_isms:dusername_null', '', 'error');
        }
        if(empty($dsp['areacode'])){
            $dsp['areacode'] = '86';
        }
        if(empty($dsp['phone'])){
            cpmsg('jzsjiale_isms:dphone_null', '', 'error');
        }
        if(!$utils->isMobile($dsp['phone'], $dsp['areacode'])){
            cpmsg('jzsjiale_isms:dphoneerror_null', '', 'error');
        }

        // 20190727 add start
        $smsuser = C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($dsp['areacode'], $dsp['phone'], $field);

        if (!empty($smsuser)) {
            cpmsg('jzsjiale_isms:phonecunzai', '', 'error');
        }

        $member = C::t('common_member')->fetch_by_username($dsp['username']);
        
        if(empty($member)){
            cpmsg('jzsjiale_isms:nousername', '', 'error');
        }

        $dsp['uid'] = $member['uid'];


        $update_mobile = $dsp['phone'];

        $client_loginfo = $utils->get_log_info();
        $data = array(
            'uid' => $dsp['uid'],
            'username' => $dsp['username'],
            'areacode' => $dsp['areacode'],
            'phone' => $update_mobile,
            'type' => 'bind',
            'operationuid' => $_G['uid'],
            'ip' => $client_loginfo['client_ip'],
            'port' => $client_loginfo['client_port'],
            'browser' => $client_loginfo['client_browser'],
            'os' => $client_loginfo['client_os'],
            'device' => $client_loginfo['client_device'],
            'useragent' => $client_loginfo['client_useragent'],
            'dateline' => TIMESTAMP
        );

        C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);
        C::t('common_member_profile')->update($dsp['uid'], array('mobile'=> $update_mobile,$field => $dsp['areacode']));

        //verify start
        if($_config['g_isopenautoverify'] && $_config['g_mobileverify']){
            $verifyuid = $dsp['uid'];
            $memberautoverify = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$verifyuid);
            if(empty($memberautoverify)){
                C::t('common_member_verify')->insert(array('uid' => $verifyuid,'verify'.$_config['g_mobileverify'] => 1));
            }else{
                C::t('common_member_verify')->update($verifyuid, array('verify'.$_config['g_mobileverify'] => 1));
            }

        }
        //verify end


        //gengxinrenzheng start
        $memberverifyres = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$dsp['uid']);
        for ($verifyx=1; $verifyx<=7; $verifyx++) {
            if($memberverifyres['verify'+$verifyx] != 1){
                $memberverifyinfores = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify_info').' WHERE uid = '.$dsp['uid'].' and verifytype = '.$verifyx);
                if(empty($memberverifyinfores)){
                    continue;
                }
                $verifyinfo = dunserialize($memberverifyinfores['field']);
                $verifyinfo['mobile'] = $dsp['phone'];

                C::t('common_member_verify_info')->update($memberverifyinfores['vid'], array('field' => serialize($verifyinfo)));
            }
        }
        //gengxinrenzheng end

        cpmsg('jzsjiale_isms:addok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser', 'succeed');
    }

    // all areacode start
    $allareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
    $allareacode = (array)unserialize($allareacode['jisms_allareacode']);
    if(!$allareacode || empty($allareacode) || $allareacode[0] === false){
        $allareacode = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->getallbystatus(1);

        $allareacodesettings = array('jisms_allareacode' => serialize($allareacode));
        C::t('common_setting')->update_batch($allareacodesettings);

        updatecache('setting');
    }
    // all areacode end

    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=lijibangding&uid='.$uid, 'enctype');
    showtableheader(plang('addbangdingtitle').'  '.plang('useruid').$memberinfo['uid'].';  '.plang('username').$memberinfo['username'], '');
    foreach($allareacode as $k =>$v){
        $smsareacodeselect .= '<option value="'.$v['areacode'].'" '.($v['areacode'] == 86?"selected":"").'>'.$v['code'].'&nbsp;&nbsp;&nbsp;&nbsp;'.$v['countrycn'].'('.$v['country'].')&nbsp;&nbsp;&nbsp;&nbsp;+'.$v['areacode'].'</option>';
    }
    if(empty($smsareacodeselect)){
        $smsareacodeselect = '<option value="86" selected>'.plang('china').'</option>';
    }
    showsetting(plang('smssendareacode'),'setting[areacode]','','<select name="setting[areacode]">'.$smsareacodeselect.'</select>','',0,plang('smssendareacode_msg'),1,'smssendareacode');
    showsetting(plang('dphone'),'setting[phone]','','text','','',plang('dphone_msg'));

    showsubmit('submit', 'submit');
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/

    exit();
}elseif($act=='jiechudongjie'){
    $uid = dintval($_GET['uid']);
    $memberinfo = C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_member_profile_by_uid($uid);
    if(empty($memberinfo))
        cpmsg('jzsjiale_isms:empty', '', 'error');
    if(submitcheck('submit')){

        C::t('#jzsjiale_isms#jzsjiale_isms_freeze')->deletebyuid($uid);

        $client_loginfo = $utils->get_log_info();
        $data = array(
            'uid' => $memberinfo['uid'],
            'username' => $memberinfo['username'],
            'areacode' => $memberinfo[$field],
            'phone' => $memberinfo['mobile'],
            'type' => 'unfreeze',
            'operationuid' => $_G['uid'],
            'ip' => $client_loginfo['client_ip'],
            'port' => $client_loginfo['client_port'],
            'browser' => $client_loginfo['client_browser'],
            'os' => $client_loginfo['client_os'],
            'device' => $client_loginfo['client_device'],
            'useragent' => $client_loginfo['client_useragent'],
            'dateline' => TIMESTAMP
        );

        C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);

        cpmsg('jzsjiale_isms:jiechudongjieok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser', 'succeed');
    }
    cpmsg('jzsjiale_isms:jiechudongjie','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=jiechudongjie&uid='.$uid.'&submit=yes','form',array('uid' => $uid));
}elseif($act=='xiugaibangding'){
    $uid = dintval($_GET['uid']);
    $memberinfo = C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_member_profile_by_uid($uid);
    if(empty($memberinfo))
        cpmsg('jzsjiale_isms:empty', '', 'error');
    if(submitcheck('submit')){

        $setting = $_GET['setting'];
        $dsp = array('dateline'=>TIMESTAMP);
        $dsp['username'] = $memberinfo['username'];
        $dsp['areacode'] = daddslashes(trim($setting['areacode']));
        $dsp['phone'] = daddslashes(trim($setting['phone']));

        if(empty($dsp['username'])){
            cpmsg('jzsjiale_isms:dusername_null', '', 'error');
        }
        if(empty($dsp['areacode'])){
            $dsp['areacode'] = '86';
        }
        if(empty($dsp['phone'])){
            cpmsg('jzsjiale_isms:dphone_null', '', 'error');
        }
        if(!$utils->isMobile($dsp['phone'], $dsp['areacode'])){
            cpmsg('jzsjiale_isms:dphoneerror_null', '', 'error');
        }

        // 20190727 add start
        $smsuser = C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_by_areacode_and_mobile($dsp['areacode'], $dsp['phone'], $field);

        if (!empty($smsuser) && $smsuser['uid'] != $memberinfo['uid']) {
            cpmsg('jzsjiale_isms:phonecunzai', '', 'error');
        }

        $member = C::t('common_member')->fetch_by_username($dsp['username']);

        if(empty($member)){
            cpmsg('jzsjiale_isms:nousername', '', 'error');
        }

        $dsp['uid'] = $member['uid'];


        $update_mobile = $dsp['phone'];

        $client_loginfo = $utils->get_log_info();
        $data = array(
            'uid' => $dsp['uid'],
            'username' => $dsp['username'],
            'areacode' => $dsp['areacode'],
            'phone' => $update_mobile,
            'type' => 'bind',
            'operationuid' => $_G['uid'],
            'ip' => $client_loginfo['client_ip'],
            'port' => $client_loginfo['client_port'],
            'browser' => $client_loginfo['client_browser'],
            'os' => $client_loginfo['client_os'],
            'device' => $client_loginfo['client_device'],
            'useragent' => $client_loginfo['client_useragent'],
            'record' => serialize(array('beforerebind_areacode' => $memberinfo[$field]?$memberinfo[$field]:'null','beforerebind_phone'  => $memberinfo['mobile']?$memberinfo['mobile']:'null')),
            'dateline' => TIMESTAMP
        );

        C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);
        C::t('common_member_profile')->update($dsp['uid'], array('mobile'=> $update_mobile,$field => $dsp['areacode']));

        //verify start
        if($_config['g_isopenautoverify'] && $_config['g_mobileverify']){
            $verifyuid = $dsp['uid'];
            $memberautoverify = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$verifyuid);
            if(empty($memberautoverify)){
                C::t('common_member_verify')->insert(array('uid' => $verifyuid,'verify'.$_config['g_mobileverify'] => 1));
            }else{
                C::t('common_member_verify')->update($verifyuid, array('verify'.$_config['g_mobileverify'] => 1));
            }

        }
        //verify end


        //gengxinrenzheng start
        $memberverifyres = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$dsp['uid']);
        for ($verifyx=1; $verifyx<=7; $verifyx++) {
            if($memberverifyres['verify'+$verifyx] != 1){
                $memberverifyinfores = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify_info').' WHERE uid = '.$dsp['uid'].' and verifytype = '.$verifyx);
                if(empty($memberverifyinfores)){
                    continue;
                }
                $verifyinfo = dunserialize($memberverifyinfores['field']);
                $verifyinfo['mobile'] = $dsp['phone'];

                C::t('common_member_verify_info')->update($memberverifyinfores['vid'], array('field' => serialize($verifyinfo)));
            }
        }
        //gengxinrenzheng end

        cpmsg('jzsjiale_isms:addok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser', 'succeed');
    }

    // all areacode start
    $allareacode = C::t('common_setting')->fetch_all(array('jisms_allareacode'));
    $allareacode = (array)unserialize($allareacode['jisms_allareacode']);
    if(!$allareacode || empty($allareacode) || $allareacode[0] === false){
        $allareacode = C::t('#jzsjiale_isms#jzsjiale_isms_areacode')->getallbystatus(1);

        $allareacodesettings = array('jisms_allareacode' => serialize($allareacode));
        C::t('common_setting')->update_batch($allareacodesettings);

        updatecache('setting');
    }
    // all areacode end

    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=xiugaibangding&uid='.$uid, 'enctype');
    showtableheader(plang('eidtbangdingtitle').'  '.plang('useruid').$memberinfo['uid'].';  '.plang('username').$memberinfo['username'], '');
    foreach($allareacode as $k =>$v){
        $smsareacodeselect .= '<option value="'.$v['areacode'].'" '.(($v['areacode'] == $memberinfo[$field] || ($utils->isMobile($memberinfo['mobile']) && empty($memberinfo[$field]) && $v['areacode'] == '86'))?"selected":"").'>'.$v['code'].'&nbsp;&nbsp;&nbsp;&nbsp;'.$v['countrycn'].'('.$v['country'].')&nbsp;&nbsp;&nbsp;&nbsp;+'.$v['areacode'].'</option>';
    }
    if(empty($smsareacodeselect)){
        $smsareacodeselect = '<option value="86" selected>'.plang('china').'</option>';
    }
    showsetting(plang('smssendareacode'),'setting[areacode]','','<select name="setting[areacode]">'.$smsareacodeselect.'</select>','',0,plang('smssendareacode_msg'),1,'smssendareacode');
    showsetting(plang('dphone'),'setting[phone]',$memberinfo['mobile'],'text','','',plang('dphone_msg'));

    showsubmit('submit', 'submit');
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/

    exit();
}elseif($act=='yijianpiliangjiechu'){
    if(submitcheck('yjpljcsubmit')){
        $uids = daddslashes($_GET['uids']);
        $uids = explode(',', $uids);
        foreach ($uids as $ukey => $uvalue){
            $uid = $uvalue;
            $setting = C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_member_profile_by_uid($uid);
            $client_loginfo = $utils->get_log_info();
            $data = array(
                'uid' => $uid,
                'username' => $setting['username'],
                'areacode' => !empty($setting[$field])?$setting[$field]:'86',
                'phone' => $setting['mobile'],
                'type' => 'unbind',
                'operationuid' => $_G['uid'],
                'ip' => $client_loginfo['client_ip'],
                'port' => $client_loginfo['client_port'],
                'browser' => $client_loginfo['client_browser'],
                'os' => $client_loginfo['client_os'],
                'device' => $client_loginfo['client_device'],
                'useragent' => $client_loginfo['client_useragent'],
                'record' => serialize(array('beforebinding_areacode' => (!empty($setting[$field])?$setting[$field]:'86'),'beforebinding_phone' => $setting['mobile'])),
                'dateline' => TIMESTAMP
            );

            C::t('#jzsjiale_isms#jzsjiale_isms_log')->insert($data, true);
            C::t('common_member_profile')->update($uid, array('mobile'=> '',$field => ''));

            //verify start
            if($_config['g_mobileverify']){
                $verifyuid = $setting['uid'];
                $memberautoverify = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$verifyuid);
                if(empty($memberautoverify)){
                    C::t('common_member_verify')->insert(array('uid' => $verifyuid,'verify'.$_config['g_mobileverify'] => 0));
                }else{
                    C::t('common_member_verify')->update($verifyuid, array('verify'.$_config['g_mobileverify'] => 0));
                }

            }


            //verify end

            //gengxinrenzheng start
            $memberverifyres = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify').' WHERE uid = '.$uid);
            for ($verifyx=1; $verifyx<=7; $verifyx++) {
                if($memberverifyres['verify'+$verifyx] != 1){
                    $memberverifyinfores = DB::fetch_first('SELECT * FROM '.DB::table('common_member_verify_info').' WHERE uid = '.$uid.' and verifytype = '.$verifyx);
                    if(empty($memberverifyinfores)){
                        continue;
                    }
                    $verifyinfo = dunserialize($memberverifyinfores['field']);
                    $verifyinfo['mobile'] = "";

                    C::t('common_member_verify_info')->update($memberverifyinfores['vid'], array('field' => serialize($verifyinfo)));
                }
            }
        }
        cpmsg('jzsjiale_isms:jiechuok', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser', 'succeed');
    }else{
        cpmsg('jzsjiale_isms:weixuanzedel', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser', 'error');
    }


}elseif($act=='exportplugin'){
    $addonid = 'jzsjiale_export.plugin';
    $array = cloudaddons_getmd5($addonid); //dis'.'m.tao'.'bao.com
    if(cloudaddons_open('&mod=app&ac=validator&addonid='.$addonid.($array !== false ? '&rid='.$array['RevisionID'].'&sn='.$array['SN'].'&rd='.$array['RevisionDateline'] : '')) === '0') {
        cpmsg(plang('export_plugin_not_install'), 'https://dism.taobao.com/?@jzsjiale_export.plugin', 'error', array('addonid' => $addonid));
    }else{
        cpmsg(plang('export_plugin_go'), 'action=plugins&operation=config&identifier=jzsjiale_export&pmod=export', 'succeed');
    }

}


/////////tip start

echo '<div class="colorbox"><h4>'.plang('aboutdzuser').'</h4>'.
    '<table cellspacing="0" cellpadding="3"><tr>'.
    '<td valign="top">'.plang('dzuserdescription').'</td></tr></table>'.
    '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

/////////tip end

if(!submitcheck('jiebangsubmit')) {

    showformheader('plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser', 'enctype');


    $keyword = daddslashes(trim($_GET['keyword']));
    $status = daddslashes(trim($_GET['status']));
    $uid = daddslashes(trim($_GET['uid']));

    $page = intval($_GET['page']);
    $page = $page > 0 ? $page : 1;
    $pagesize = 20;
    $start = ($page - 1) * $pagesize;

//20190728start
    $map = array();
    if(!empty($keyword)){
        $map['keyword'] = $keyword;
    }
    if(!empty($status) || $status == '0'){
        $map['status'] = $status;
    }
    if(!empty($uid)){
        $map['uid'] = $uid;
    }

    if(!empty($_GET['op']) && $_GET['op'] == "chazhaochongfu"){
        $alldzuser = C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_all_with_username_and_mobile_chachong($start,$pagesize,'ASC',$field);
        $count = C::t('#jzsjiale_isms#jzsjiale_isms_member')->count_all_with_username_and_mobile_chachong();
    }else{
        $alldzuser = C::t('#jzsjiale_isms#jzsjiale_isms_member')->fetch_all_with_username_and_mobile($map,$start,$pagesize,'DESC',$field);
        $count = C::t('#jzsjiale_isms#jzsjiale_isms_member')->count_all_with_username_and_mobile($map);
    }


    $status_options = "<option value=\"all\"  " . (($status == 'all') ? "selected='selected'" : '') . ">" . plang('statusalluser') . "</option>"
        . "<option value='1' " . (($status == '1') ? "selected='selected'" : '') . ">" . plang('statusbinduser') . "</option>"
        . "<option value='0' " . (($status == '0') ? "selected='selected'" : '') . ">" . plang('statusunbinduser') . "</option>";


    showtablerow('', array('width="150"', 'width="150"', 'width="150"', ''), array(
            "uid:<input size=\"20\" name=\"uid\" type=\"text\" value=\"$uid\" /> ",
            plang('userphone'),
            "<input size=\"20\" name=\"keyword\" type=\"text\" value=\"$keyword\" /> ",
            plang('bindstatus'),
            "<select name=\"status\">$status_options</select> ",
            "<input class=\"btn\" type=\"submit\" value=\"" . cplang('search') . "\" />"
        )
    );

    $usergroups = array();
    foreach(C::t('common_usergroup')->range() as $group) {
        switch($group['type']) {
            case 'system': $group['grouptitle'] = '<b>'.$group['grouptitle'].'</b>'; break;
            case 'special': $group['grouptitle'] = '<i>'.$group['grouptitle'].'</i>'; break;
        }
        $usergroups[$group['groupid']] = $group;
    }

    showtableheader(plang('dzuserlist').'(&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=bangding" style="color:red;">'.plang('bangding').'</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&op=chazhaochongfu" style="color:red;">'.plang('chazhaochongfu').'</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=members&operation=export">'.$lang['members_search_export'].plang('export_discuz').'</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=exportplugin" style="color:red;">'.$lang['members_search_export'].plang('export_plugin').'</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=piliangshanchuphone" style="color:blue;">'.plang('piliangshanchu').'</a>&nbsp;&nbsp;)');
    showsubtitle(plang('dzuserlisttitle'));
    foreach($alldzuser as $d){
        showtablerow('', array('style="width:150px;"', 'style="width:150px;"', 'style="width:100px;"', 'style="width:150px;"', 'style="width:150px;"', 'style="width:150px;"', 'style="width:150px;"', 'style="width:100px;"', 'style="width:50px;"', 'style="width:50px;"', 'style="width:150px;"', 'style="width:400px;"'), array(
                '<input class="checkbox" type="checkbox" name="delete[]" value="'.$d['uid'].'">'.'<span title="'.$d['uid'].'"><a href="admin.php?action=members&operation=edit&uid='.$d['uid'].'" target="_blank">'.$d['uid'].'</a></span>',
                '<span title="'.$d['uid'].'"><a href="home.php?mod=space&uid='.$d['uid'].'&do=profile" target="_blank">'.$d['username'].'</a></span>',
                $usergroups[$d['groupid']]['grouptitle'],
                '<span title="'.(!empty($d['phone'])?(!empty($d['areacode'])?$d['areacode']:'86'):'').'"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=areacode&areacodesearch=1&keyword='.(!empty($d['phone'])?(!empty($d['areacode'])?$d['areacode']:''):'').'" target="_blank">'.(!empty($d['phone'])?(!empty($d['areacode'])?$d['areacode']:''):'').'</a></span>',
                '<span title="'.$d['phone'].'"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&keyword='.$d['phone'].'" target="_self">'.$d['phone'].'</a></span>',
                dgmdate($d['dateline'], 'Y-m-d H:i:s'),
                dgmdate($d['lastvisit'], 'Y-m-d H:i:s'),
                $d['lastip'],
                $d['email'],
                $d['qq'],
                $utils->getmemberstatus($d['freeze']).'&nbsp;&nbsp;'.($d['freeze']>0?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=jiechudongjie&uid='.$d['uid'].'" style="color:blue;text-decoration:underline;">'.plang('memberstatuschange').'</a>':''),
                (!empty($d['phone'])? '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=xiugaibangding&uid='.$d['uid'].'" style="color:blue;">'.plang('xiugaibangding').'</a>&nbsp;|&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=jiechubangding&uid='.$d['uid'].'" style="color:red;">'.plang('jiechubangding').'</a>':'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=lijibangding&uid='.$d['uid'].'" style="color:green;">'.plang('lijibangding').'</a>').'&nbsp;|&nbsp;<a href="'.ADMINSCRIPT.'?action=members&operation=edit&uid='.$d['uid'].'" style="color:Orange;">'.plang('detail').'</a>&nbsp;|&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=more&module=rename&searchuid='.$d['uid'].'" style="color:purple;">'.plang('rename').'</a>')
        );
    }

    $mpurl = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&keyword='.$keyword.'&uid='.$uid.'&status='.$status.'&op='.$_GET['op'];
    $multipage = multi($count, $pagesize, $page, $mpurl);
//showsubmit('', '', '', '', $multipage);


//search start
    //showsubmit('', '', '', '', $multipage);

    showsubmit('jiebangsubmit', plang('piliangjiechubangding'), 'select_all', '', $multipage, false);
//search end


    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/
}else{
    if($_GET['delete']) {
        cpmsg('jzsjiale_isms:piliangdelbangding','action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser&act=yijianpiliangjiechu&uids='.implode(',',daddslashes($_GET['delete'])).'&yjpljcsubmit=yes','form',array('uids' => implode(',',daddslashes($_GET['delete']))));
    }else{
        cpmsg('jzsjiale_isms:weixuanzedel', 'action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=dzuser', 'error');
    }
}





function plang($str) {
    return lang('plugin/jzsjiale_isms', $str);
}
//From: d'.'is'.'m.ta'.'obao.com
?>