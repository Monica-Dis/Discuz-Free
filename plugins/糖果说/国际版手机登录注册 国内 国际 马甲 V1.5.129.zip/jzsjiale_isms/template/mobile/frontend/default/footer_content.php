<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<footer class="ISMSPage-footer">
    <!--{if $jsms_muban_mobile['footercopyright']}-->
    <div class="jzsjiale-isms-footer-copyright">
        <span>
        {$jsms_muban_mobile['footercopyright']}
        </span>
    </div>
    <!--{/if}-->
</footer>