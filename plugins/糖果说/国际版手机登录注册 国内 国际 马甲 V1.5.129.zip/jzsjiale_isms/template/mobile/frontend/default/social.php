<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<div class="login_dsf lb">
    <div class="login_line cl"><span class="login_font_bodybg f_c">{lang jzsjiale_isms:tip_social_login}</span></div>
    <div class="login_ico">
        <!--{if $jsms_muban_mobile['weixinurl']}-->
            <!--{if $jsms_muban_mobile['onlyweixin']}-->
                <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false}-->
                <a href="{$jsms_muban_mobile['weixinurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_mdetailed']))}{echo urlencode(dreferer());}{/if}">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-weixin"></use>
                    </svg>
                </a>
                <!--{/if}-->
            <!--{else}-->
            <a href="{$jsms_muban_mobile['weixinurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_mdetailed']))}{echo urlencode(dreferer());}{/if}">
                <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-weixin"></use>
                </svg>
            </a>
            <!--{/if}-->
        <!--{/if}-->
        <!--{if $jsms_muban_mobile['qqurl']}-->
        <a href="{$jsms_muban_mobile['qqurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_mdetailed']))}{echo urlencode(dreferer());}{/if}">
            <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-tubiao215"></use>
            </svg>
        </a>
        <!--{/if}-->
        <!--{if $jsms_muban_mobile['weibourl']}-->
        <a href="{$jsms_muban_mobile['weibourl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_mdetailed']))}{echo urlencode(dreferer());}{/if}">
            <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-weibo"></use>
            </svg>
        </a>
        <!--{/if}-->
        <!--{if $jsms_muban_mobile['googleurl']}-->
        <a href="{$jsms_muban_mobile['googleurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_mdetailed']))}{echo urlencode(dreferer());}{/if}">
            <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-google"></use>
            </svg>
        </a>
        <!--{/if}-->
        <!--{if $jsms_muban_mobile['facebookurl']}-->
        <a href="{$jsms_muban_mobile['facebookurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_mdetailed']))}{echo urlencode(dreferer());}{/if}">
            <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-facebook"></use>
            </svg>
        </a>
        <!--{/if}-->
        <!--{if $jsms_muban_mobile['twitterurl']}-->
        <a href="{$jsms_muban_mobile['twitterurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_mdetailed']))}{echo urlencode(dreferer());}{/if}">
            <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-twitter"></use>
            </svg>
        </a>
        <!--{/if}-->
        <!--{if $jsms_muban_mobile['weiruanurl']}-->
        <a href="{$jsms_muban_mobile['weiruanurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_mdetailed']))}{echo urlencode(dreferer());}{/if}">
            <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-weiruan"></use>
            </svg>
        </a>
        <!--{/if}-->
    </div>
</div>