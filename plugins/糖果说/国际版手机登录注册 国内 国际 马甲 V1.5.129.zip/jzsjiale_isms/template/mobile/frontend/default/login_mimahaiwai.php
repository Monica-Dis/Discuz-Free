<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/header')}
<div id="mobile_jzsjiale_isms_login_root">
    <main class="mobile_jzsjiale_i_sms_login_main">
        <div class="mobile_jzsjiale_isms_main_content">
            <div class="mobile-header">
                <a href="{echo $_G['siteurl'];}" target="_self" class="close">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-guanbi"></use>
                    </svg>
                </a>
                <div class="mobile-header-title">
                    <!--{if $jsms_muban_mobile['title']}-->
                    {$jsms_muban_mobile['title']}
                    <!--{elseif $jsms_muban_mobile['logo']}-->
                    <img src="{$jsms_muban_mobile['logo']}" class="mobile_jzsjiale_isms_main_content_header_title_img"/>
                    <!--{else}-->
                    {lang jzsjiale_isms:title_and_logo_null}
                    <!--{/if}-->
                </div>
                <div class="mobile-header-desc">
                    {$jsms_muban_mobile['logindesc']}
                </div>
            </div>
            <div class="mobile-content">
                <template>
                    <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>
                        <div class="mobile-input">
                            <div class="ISMSForm-account">
                                <div class="ISMSForm-areacodeSelect">
                                    <div class="ISMSForm-areacode">

                                        <i-select @on-change="togglePhoneStatus()" v-model="ISMSFormItem.areacode" class="JSelect_areacode" placeholder="{lang jzsjiale_isms:placeholder}" transfer>

                                            <i-option v-for="(item, index) in areacodeList.commonareacodeList" :value="item.areacode" :label="'+'+item.areacode" :key="item.index">
                                                {{ item.countrycn }}&nbsp;&nbsp;+{{ item.areacode }}
                                            </i-option>
                                            <i-option v-if="areacodeList.commonareacodeList && areacodeList.commonareacodeList.length >0" value="splitline" disabled>
                                                -------------------------------------
                                            </i-option>
                                            <i-option v-for="(item, index) in areacodeList.allareacodeList" :value="item.areacode" :label="'+'+item.areacode" :key="item.index">
                                                {{ item.countrycn }}&nbsp;&nbsp;+{{ item.areacode }}
                                            </i-option>


                                        </i-select>
                                    </div>
                                </div>
                                <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                    <div class="ISMSForm-accountInput Input-wrapper">
                                        <Input type="tel" @input="togglePhoneStatus()" @focus="err_phone = false" @blur="togglePhoneStatus()" v-model="ISMSFormItem.phone" name="phone" class="JInput" :maxlength="size_phone" :size="size_phone" placeholder="{lang jzsjiale_isms:tip_phone}"/>
                                    </div>
                                    <div class="ISMSFormInput-errorMask " :class="{ 'ISMSFormInput-errorMask-hidden' : !err_phone }">
                                        {{ msg_phone }}
                                    </div>
                                </div>
                            </div>
                            <div class="ISMSForm-password Input-border-bottom">
                                <div class="ISMSForm-inputhead">
                                    <div class="Popover ISMSForm-inputheight40-center">
                                        {lang jzsjiale_isms:tip_mima}
                                    </div>
                                </div>
                                <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                    <div class="Input-border-none Input-wrapper">
                                        <Input type="password" @input="togglePasswordStatus()" @focus="err_password = false" @blur="togglePasswordStatus()" v-model="ISMSFormItem.password" name="password" class="JInput" placeholder="{lang jzsjiale_isms:msg_mima_empty}"/>
                                    </div>
                                    <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_password }">
                                        {lang jzsjiale_isms:msg_mima_empty}
                                    </div>
                                </div>

                            </div>

                            <div v-if="isshow_question" class="ISMSForm-account">
                                <div class="ISMSForm-logintypeSelect">
                                    <div class="ISMSForm-logintype">

                                        <i-select v-model="ISMSFormItem.questionid" @on-change="toggleQuestionsStatus()" class="JSelect_logintype" placeholder="{lang jzsjiale_isms:placeholder}" transfer>

                                            <i-option v-for="(item, index) in questions" :value="item.id" :key="item.index">
                                                {{ item.lang }}
                                            </i-option>

                                        </i-select>
                                    </div>
                                </div>
                                <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                    <div class="ISMSForm-accountInput Input-wrapper">
                                        <Input type="text" @input="toggleQuestionsStatus()" @focus="err_answer = false" @blur="toggleQuestionsStatus()" v-model="ISMSFormItem.answer" name="answer" class="JInput" placeholder="{lang jzsjiale_isms:tip_answer}"/>
                                    </div>
                                    <div class="ISMSFormInput-errorMask " :class="{ 'ISMSFormInput-errorMask-hidden' : !err_answer }">
                                        {{ msg_answer }}
                                    </div>
                                </div>
                            </div>
                            <div class="ISMSForm-Login-type">
                                <!--{if in_array('mima', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_mlogintype']))}-->
                                <a href="member.php?mod=logging&action=login&logintype=mima" target="_self" class="JButton ISMSForm-Login-Type Button--plain">
                                    {lang jzsjiale_isms:tip_btn_loginmima}
                                </a>
                                <!--{/if}-->
                                <!--{if in_array('seccode', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_mlogintype']))}-->
                                <a href="member.php?mod=logging&action=login&logintype=seccode" target="_self" class="JButton ISMSForm-Login-Type Button--plain">
                                    {lang jzsjiale_isms:tip_btn_loginmobile}
                                </a>
                                <!--{/if}-->
                            </div>
                        </div>
                        <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton" <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] != 0 && in_array('loginmima', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_othercaptcha']))}--> <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}--> id="TencentCaptcha" data-appid="{$_G['cache']['plugin']['jzsjiale_isms']['g_captchaappid']}" data-cbfn="tencentLoginCaptchaCallback"<!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->id="TencentCaptcha" data-appid="{$_G['cache']['plugin']['jzsjiale_isms']['g_captchaappid']}" data-cbfn="cloudTencentLoginCaptchaCallback"<!--{/if}--> <!--{/if}-->>
                            {lang jzsjiale_isms:btn_login}
                        </button>
                    </i-form>
                </template>
            </div>
            <div class="otherbtn">
                <a href="member.php?mod={$_G[setting][regname]}" target="_self">{lang jzsjiale_isms:register_title}</a>
                <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_openmobilezhaohui']}-->
                <a href="member.php?mod=lostpasswd" target="_self">{lang jzsjiale_isms:lostpasswd_title}</a>
                <!--{/if}-->
            </div>

            <!--{if $jsms_muban_mobile['isshowsocial']}-->
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/social')}
            <!--{/if}-->
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/footer_content')}
        </div>
    </main>
</div>
<script>
    new Vue({
        el: '#mobile_jzsjiale_isms_login_root',
        data: {
            ISMSFormItem: {
                areacode: '86',
                phone: '',
                password: '',
                questionid: 0,
                answer: ''
            },
            areacodeList:{
                allareacodeList:[],
                commonareacodeList:[]
            },
            questions:[
                {'id':0,'lang':'{lang security_question}'},
                {'id':1,'lang':'{lang security_question_1}'},
                {'id':2,'lang':'{lang security_question_2}'},
                {'id':3,'lang':'{lang security_question_3}'},
                {'id':4,'lang':'{lang security_question_4}'},
                {'id':5,'lang':'{lang security_question_5}'},
                {'id':6,'lang':'{lang security_question_6}'},
                {'id':7,'lang':'{lang security_question_7}'},
            ],
            err_phone: false,
            msg_phone: "",
            err_password: false,
            msg_password: "",
            err_answer: false,
            msg_answer: "",
            btn_send: true,
            isshow_question: false,
            now_show_qrImage: false,
            countdown: 60,
            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] != 0 && in_array('loginmima', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_othercaptcha']))}-->
            captcha : [],
            <!--{/if}-->
            referer: '{eval echo strpos($dreferer,"jzsjiale_isms:security") !== false ? "plugin.php?id=jzsjiale_isms:security" : $dreferer;}'
        },
        beforeCreate(){
            let _this = this;
            //j_z_s_j_i_a_l_e_i_s_m_s_a_p_i
            axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                module: 'areacode',
                version: 1,
                formhash:'{FORMHASH}'
            }))
                .then(function (response) {

                    if(response['data']['code'] != 0){
                        _this.areacodeList.allareacodeList = response['data']['data'];
                        _this.areacodeList.commonareacodeList = response['data']['data'];

                        _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                    }else{
                        _this.areacodeList.allareacodeList = response['data']['data']['allareacode'];
                        _this.areacodeList.commonareacodeList = response['data']['data']['commonareacode'];
                    }
                })
                .catch(function (error) {
                    //console.log(error);
                    _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                });
        },
        computed: {
            size_phone: function () {
                let _this = this;
                return (_this.ISMSFormItem.areacode == '86' || _.isEmpty(_this.ISMSFormItem.areacode)) ? 11 : '';
            }
        },
        created() {
            let _this = this;
            if(!_.isEmpty(_.cookie.get("isms_phone"))){
                _this.ISMSFormItem.phone = _.cookie.get("isms_phone");
            }
            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_defaultareacode'] != ""}-->
            _this.ISMSFormItem.areacode = "{$_G['cache']['plugin']['jzsjiale_isms']['g_defaultareacode']}";
            <!--{/if}-->
        },
        mounted() {
            let _this = this;
            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] != 0 && in_array('loginmima', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_othercaptcha']))}-->

            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
            window.tencentLoginCaptchaCallback = _this.tencentLoginCaptchaCallback;
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
            window.vaptchaLoginCallback = _this.vaptchaLoginCallback;
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
            window.cloudTencentLoginCaptchaCallback = _this.cloudTencentLoginCaptchaCallback;
            <!--{/if}-->

            <!--{/if}-->
        },
        methods: {
            handleSubmit: function () {
                let _this = this;
                _this.loginPhoneVerify();
                _this.loginPasswordVerify();
                _this.toggleQuestionsStatus();
                if(_this.err_phone || _this.err_password){
                    return false;
                }

                <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] != 0 && in_array('loginmima', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_othercaptcha']))}-->

                <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
                let isms_v = new ISMSVD("{$_G['cache']['plugin']['jzsjiale_isms']['g_captchaappid']}", null, 'invisible', "{$_G['cache']['plugin']['jzsjiale_isms']['g_captchascene']}","/{JZSJIALE_ISMS_PLUGIN_API}&module=vaptchaofflineverify&version=1&formhash={FORMHASH}");
                isms_v.initLoginVaptcha();
                <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 4}-->
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'startgeetestverify',
                    version: 1,
                    clienttype: 'web',
                    t: (new Date()).getTime(),
                    formhash:'{FORMHASH}'
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                        }else{

                            initGeetest({
                                gt: response['data']['data']['gt'],
                                challenge: response['data']['data']['challenge'],
                                new_captcha: response['data']['data']['new_captcha'],
                                offline: !response['data']['data']['success'],
                                product: 'bind'
                            }, function(captchaObj){
                                captchaObj.onReady(function(){
                                    captchaObj.verify();
                                }).onSuccess(function(){
                                    _this.captcha['geetest_challenge'] = captchaObj.getValidate().geetest_challenge,
                                        _this.captcha['geetest_validate'] = captchaObj.getValidate().geetest_validate,
                                        _this.captcha['geetest_seccode'] = captchaObj.getValidate().geetest_seccode,
                                        _this.captcha['clienttype'] = 'web',
                                        _this.captcha['t'] = (new Date()).getTime(),

                                        _this.loginSubmit();

                                }).onClose(function () {
                                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                                }).onError(function(){
                                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                                });
                            });
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
                <!--{/if}-->

                <!--{else}-->
                _this.loginSubmit();
                <!--{/if}-->


            },
            loginSubmit: function () {
                let _this = this;

                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'loginmimahaiwai',
                    version: 1,
                    loginsubmit: 'yes',
                    discode: '32563',
                    areacode: _this.ISMSFormItem.areacode,
                    phone: _this.ISMSFormItem.phone,
                    password: _this.ISMSFormItem.password,
                    questionid: _this.ISMSFormItem.questionid,
                    answer: encodeURI(_this.ISMSFormItem.answer),
                    <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] != 0 && in_array('loginmima', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_othercaptcha']))}-->

                    <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
                    ticket: _this.captcha['ticket'],
                    randstr: _this.captcha['randstr'],
                    <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
                    token: _this.captcha['token'],
                    <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 4}-->
                    geetest_challenge: _this.captcha['geetest_challenge'],
                    geetest_validate: _this.captcha['geetest_validate'],
                    geetest_seccode: _this.captcha['geetest_seccode'],
                    clienttype: _this.captcha['clienttype'],
                    t: _this.captcha['t'],
                    <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
                    ticket: _this.captcha['ticket'],
                    randstr: _this.captcha['randstr'],
                    <!--{/if}-->

                    <!--{/if}-->
                    formhash:'{FORMHASH}',
                    logintype: 'mimahaiwai',
                    device: 'mobile',
                    cookietime: 2592000,
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            _this.${Message}.error({
                                content: jzsjiale_lang[response['data']['msg']],
                                duration: 5
                            });
                            if(response['data']['msg'] == 'msg_err_answerset'){
                                _this.isshow_question = true;
                            }
                        }else{
                            if(response['data']['msg'] == 'msg_err_location_login_outofdate'){

                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_location_login_outofdate'],
                                    duration: 10
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'plugin.php?id=jzsjiale_isms:security&op=needverify';
                                window.location.href = url_forward;
                            }else if(response['data']['msg'] == 'msg_err_location_login_password_tooshort'){

                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_location_login_password_tooshort'],
                                    duration: 10
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'plugin.php?id=jzsjiale_isms:security&op=changepassword';
                                window.location.href = url_forward;
                            }else if(response['data']['msg'] == 'msg_err_location_login_differentplaces'){

                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_location_login_differentplaces'],
                                    duration: 10
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'plugin.php?id=jzsjiale_isms:security&op=needverify';
                                window.location.href = url_forward;
                            }else if(response['data']['msg'] == 'msg_err_location_login_needverify'){

                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_location_login_needverify'],
                                    duration: 10
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'plugin.php?id=jzsjiale_isms:security&op=needverify';
                                window.location.href = url_forward;
                            }else{
                                _this.${Message}.success({
                                    content: jzsjiale_lang['msg_login_success'],
                                    duration: 10
                                });
                                _.cookie.remove("isms_phone");
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'{$_G["siteurl"]}';
                                window.location.href = url_forward;
                            }

                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] != 0 && in_array('loginmima', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_othercaptcha']))}-->

            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
            tencentLoginCaptchaCallback: function (res) {
                let _this = this;

                if(res.ret === 0 && !_.isEmpty(res.ticket) && !_.isEmpty(res.randstr)){
                    _this.captcha['ticket'] = res.ticket;
                    _this.captcha['randstr'] = res.randstr;
                    _this.loginSubmit();

                }else if(res.ret === 2){
                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                }else{
                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                }

            },
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
            vaptchaLoginCallback: function (token) {
                let _this = this;

                if(!_.isEmpty(token)){
                    _this.captcha['token'] = token;
                    _this.loginSubmit();
                }else{
                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                }

            },
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
            cloudTencentLoginCaptchaCallback: function (res) {
                let _this = this;

                if(res.ret === 0 && !_.isEmpty(res.ticket) && !_.isEmpty(res.randstr)){
                    _this.captcha['ticket'] = res.ticket;
                    _this.captcha['randstr'] = res.randstr;
                    _this.loginSubmit();

                }else if(res.ret === 2){
                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                }else{
                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                }

            },
            <!--{/if}-->

            <!--{/if}-->
            togglePhoneStatus: function () {
                let _this = this;
                _this.loginPhoneVerify();

            },
            togglePasswordStatus: function () {
                let _this = this;
                _this.loginPasswordVerify();

            },
            toggleQuestionsStatus: function () {
                let _this = this;
                _this.loginQuestionsVerify();

            },
            loginPhoneVerify: function(){
                let _this = this;
                if(_.isEmpty(_this.ISMSFormItem.areacode) || !_.isAreaCode(_this.ISMSFormItem.areacode)){
                    _this.err_phone = true;
                    _this.msg_phone = jzsjiale_lang['msg_areacode_error'];
                    return;
                }
                if(_.isEmpty(_this.ISMSFormItem.phone)){
                    _this.err_phone = true;
                    _this.msg_phone = jzsjiale_lang['msg_phone_empty'];
                    return;
                }else if(!_.isMobilePhone(_this.ISMSFormItem.areacode,_this.ISMSFormItem.phone)){
                    _this.err_phone = true;
                    _this.msg_phone = jzsjiale_lang['msg_phone_formaterror'];
                    return;
                }else{
                    _this.err_phone = false;
                    _this.msg_phone = "";
                    _.cookie.set("isms_phone",_this.ISMSFormItem.phone);
                    return;
                }
            },
            loginPasswordVerify: function(){
                let _this = this;

                if(_.isEmpty(_this.ISMSFormItem.password)){
                    _this.err_password = true;
                    _this.msg_password = jzsjiale_lang['msg_password_empty'];
                    return;
                }else{
                    _this.err_password = false;
                    _this.msg_password = "";
                    return;
                }

            },
            loginQuestionsVerify: function(){
                let _this = this;

                if(_this.ISMSFormItem.questionid > 0 && _.isEmpty(_this.ISMSFormItem.answer)){
                    _this.err_answer = true;
                    _this.msg_answer = jzsjiale_lang['msg_answer_empty2'];
                    return;
                }else{
                    _this.err_answer = false;
                    _this.msg_answer = "";
                    return;
                }

            }
        }
    })
</script>
<!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] != 0 && in_array('loginmima', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_othercaptcha']))}-->
<!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
<script>
    window.callback = function(res){
        //console.log(res);
        tencentLoginCaptchaCallback(res);
    }
</script>
<!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
<script>
    window.callback = function(token){
        //console.log(res);
        vaptchaLoginCallback(token);
    }
</script>
<!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
<script>
    window.callback = function(res){
        //console.log(res);
        cloudTencentLoginCaptchaCallback(res);
    }
</script>
<!--{/if}-->
<!--{/if}-->
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/footer')}