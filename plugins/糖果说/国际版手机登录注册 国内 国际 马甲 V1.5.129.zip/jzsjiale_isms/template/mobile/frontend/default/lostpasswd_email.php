<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/header')}
<div id="mobile_jzsjiale_isms_lostpasswd_root">
    <main class="mobile_jzsjiale_i_sms_lostpasswd_main">
        <div class="mobile_jzsjiale_isms_main_content">
            <div class="mobile-header">
                <a href="{echo $_G['siteurl'];}" target="_self" class="close">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-guanbi"></use>
                    </svg>
                </a>
                <div class="mobile-header-title">
                    <!--{if $jsms_muban_mobile['title']}-->
                    {$jsms_muban_mobile['title']}
                    <!--{elseif $jsms_muban_mobile['logo']}-->
                    <img src="{$jsms_muban_mobile['logo']}" class="mobile_jzsjiale_isms_main_content_header_title_img"/>
                    <!--{else}-->
                    {lang jzsjiale_isms:title_and_logo_null}
                    <!--{/if}-->
                </div>
                <div class="mobile-header-desc">
                    {$jsms_muban_mobile['lostpasswddesc']}
                </div>
            </div>
            <div class="mobile-content">
                <template>
                    <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>
                        <div class="mobile-input">
                            <div class="ISMSForm-common">
                                <div class="ISMSFormInput ISMSForm-commonInputContainer">
                                    <div class="Input-wrapper">
                                        <Input type="text" @input="toggleEmailStatus()" @focus="err_email = false" @blur="toggleEmailStatus()" v-model="ISMSFormItem.email" name="email" class="JInput" placeholder="{lang jzsjiale_isms:tip_lostpasswd_email}"/>
                                    </div>
                                    <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_email }">
                                        {{ msg_email }}
                                    </div>
                                </div>

                            </div>
                            <div class="ISMSForm-common">
                                <div class="ISMSFormInput ISMSForm-commonInputContainer">
                                    <div class="Input-wrapper">
                                        <Input type="text" v-model="ISMSFormItem.username" name="username" class="JInput" placeholder="{lang jzsjiale_isms:tip_lostpasswd_username}"/>
                                    </div>
                                    <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask ISMSFormInput-errorMask-hidden">

                                    </div>
                                </div>

                            </div>
                        </div>
                        <!--{if in_array($_G['cache']['plugin']['jzsjiale_isms']['g_openmobilezhaohui'],array('3','4'))}-->
                        <div class="ISMSForm-Login-type">

                            <a href="member.php?mod={$_G[setting][regname]}" target="_self" class="JButton ISMSForm-Login-Type Button--plain">
                                {lang jzsjiale_isms:tip_btn_register_account}
                            </a>

                            <a href="member.php?mod=lostpasswd&type=mobile" target="_self" class="JButton ISMSForm-Forgot-Password Button--plain">
                                {lang jzsjiale_isms:tip_btn_forgotpassword_mobile}
                            </a>

                        </div>
                        <!--{/if}-->
                        <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton">
                            {lang jzsjiale_isms:btn_lostpasswd}
                        </button>
                    </i-form>
                </template>
            </div>
            <div class="otherbtn">
                <a href="member.php?mod={$_G[setting][regname]}" target="_self">{lang jzsjiale_isms:register_title}</a>
                <a href="member.php?mod=logging&action=login" target="_self">{lang jzsjiale_isms:login_title}</a>
            </div>

            <!--{if $jsms_muban_mobile['isshowsocial']}-->
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/social')}
            <!--{/if}-->
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/footer_content')}
        </div>
    </main>
</div>
<script>
    new Vue({
        el: '#mobile_jzsjiale_isms_lostpasswd_root',
        data: {
            ISMSFormItem: {
                email: '',
                username: ''
            },
            err_email: false,
            msg_email: "",
            now_show_qrImage: false,
            referer: '{$dreferer}'
        },
        methods: {
            handleSubmit: function () {
                let _this = this;
                _this.lostpasswdEmailVerify();
                if(_this.err_email){
                    return false;
                }
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'lostpasswdemail',
                    version: 1,
                    lostpasswdsubmit: 'yes',
                    discode: '32563',
                    email: _this.ISMSFormItem.email,
                    username: encodeURI(_this.ISMSFormItem.username),
                    formhash:'{FORMHASH}',
                    device: 'mobile',
                    cookietime: 2592000,
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            _this.${Message}.error({
                                content: jzsjiale_lang[response['data']['msg']],
                                duration: 10
                            });
                        }else{
                            _this.${Message}.success({
                                content: jzsjiale_lang['msg_getpasswd_send_succeed'],
                                duration: 20
                            });
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            toggleEmailStatus: function () {
                let _this = this;
                _this.lostpasswdEmailVerify();
            },
            lostpasswdEmailVerify: function(){
                let _this = this;

                if(_.isEmpty(_this.ISMSFormItem.email)){
                    _this.err_email = true;
                    _this.msg_email = jzsjiale_lang['msg_email_empty'];
                    return;
                }else if(!_.isEmail(_this.ISMSFormItem.email)){
                    _this.err_email = true;
                    _this.msg_email = jzsjiale_lang['msg_email_format_error'];
                    return;
                }else{
                    _this.err_email = false;
                    _this.msg_email = "";
                    return;
                }

            }
        }
    })
</script>

{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/footer')}