<?php
/**
 * Created by jzsjiale.
 * User: jzsjiale
 * Date: 2019/9/18
 * Time: 10:47 AM
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$config = array(
    'dir'=>'default',
    'title'=>'\u9ed8\u8ba4\u6a21\u677f',
    'desc'=>'\u9ed8\u8ba4\u6a21\u677f'
);