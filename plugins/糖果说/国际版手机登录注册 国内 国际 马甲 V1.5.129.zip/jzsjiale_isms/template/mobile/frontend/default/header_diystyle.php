<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<style type="text/css">
    <!--{if $jsms_muban_mobile['titlecolor']}-->
    .mobile-header-title {
    color:{$jsms_muban_mobile['titlecolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_mobile['desccolor']}-->
    .mobile-header-desc {
    color:{$jsms_muban_mobile['desccolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_mobile['bgcolor']}-->
    .mobile-header {
    background-color: {$jsms_muban_mobile['bgcolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_mobile['btntextcolor']}-->
    .ISMSForm-submitButton{
    color: {$jsms_muban_mobile['btntextcolor']};
    border: unset!important;
    }
    <!--{/if}-->
    <!--{if $jsms_muban_mobile['btnbackgroundcolor']}-->
    .ISMSForm-submitButton{
    background-color: {$jsms_muban_mobile['btnbackgroundcolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_mobile['btnacolor']}-->
    .otherbtn a{
    color: {$jsms_muban_mobile['btnacolor']}!important;
    }
    <!--{/if}-->
    <!--{if $jsms_muban_mobile['socialcolor']}-->
    .login_ico a {
    color: {$jsms_muban_mobile['socialcolor']}!important;
    }
    <!--{/if}-->
    <!--{if $jsms_muban_mobile['footercolor']}-->
    .ISMSPage-footer {
    color: {$jsms_muban_mobile['footercolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_mobile['closecolor']}-->
    .mobile-header .close {
    color: {$jsms_muban_mobile['closecolor']}!important;
    }
    <!--{/if}-->
</style>