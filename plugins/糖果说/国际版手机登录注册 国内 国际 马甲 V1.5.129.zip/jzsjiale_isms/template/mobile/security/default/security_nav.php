<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<nav class="jzsjiale_isms_security_nav">
    <ol>
        <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_openmobilebangding']}-->
        <li><a class="jzsjiale_isms_security_link {eval echo $navtype == 'bindmobile'?'is-active':''}" href="plugin.php?id=jzsjiale_isms:security&op=bindmobile">
                <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-shouji1"></use>
                </svg>
                <span class="jzsjiale_isms_security_linkTxt">{lang jzsjiale_isms:security_nav_bind_mobile}</span></a>
        </li>
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_openmobilechangepwd']}-->
        <li><a class="jzsjiale_isms_security_link {eval echo $navtype == 'changepassword'?'is-active':''}" href="plugin.php?id=jzsjiale_isms:security&op=changepassword">
                <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-ai-password"></use>
                </svg>
                <span class="jzsjiale_isms_security_linkTxt">{lang jzsjiale_isms:security_nav_change_password}</span></a>
        </li>
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_openmobilechangeusername']}-->
        <li><a class="jzsjiale_isms_security_link {eval echo $navtype == 'changeusername'?'is-active':''}" href="plugin.php?id=jzsjiale_isms:security&op=changeusername">
                <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-yonghu"></use>
                </svg>
                <span class="jzsjiale_isms_security_linkTxt">{lang jzsjiale_isms:security_nav_change_username}</span></a>
        </li>
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_openmobilelogonlog']}-->
        <li><a class="jzsjiale_isms_security_link {eval echo $navtype == 'logonlog'?'is-active':''}" href="plugin.php?id=jzsjiale_isms:security&op=logonlog">
                <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-lvzhou_caozuorizhi"></use>
                </svg>
                <span class="jzsjiale_isms_security_linkTxt">{lang jzsjiale_isms:security_nav_logonlog}</span></a>
        </li>
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_openmobileask']}-->
        <li><a class="jzsjiale_isms_security_link {eval echo $navtype == 'ask'?'is-active':''}" href="plugin.php?id=jzsjiale_isms:security&op=ask">
                <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-wentifankui"></use>
                </svg>
                <span class="jzsjiale_isms_security_linkTxt">{lang jzsjiale_isms:security_nav_ask}</span></a>
        </li>
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_openmobileemail']}-->
        <li><a class="jzsjiale_isms_security_link {eval echo $navtype == 'email'?'is-active':''}" href="plugin.php?id=jzsjiale_isms:security&op=email">
                <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-youxiang"></use>
                </svg>
                <span class="jzsjiale_isms_security_linkTxt">{lang jzsjiale_isms:security_nav_email}</span></a>
        </li>
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_openmobilelogoff'] == 1}-->
        <li><a class="jzsjiale_isms_security_link {eval echo $navtype == 'logoff'?'is-active':''}" href="plugin.php?id=jzsjiale_isms:security&op=logoff">
                <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-lajixiang"></use>
                </svg>
                <span class="jzsjiale_isms_security_linkTxt">{lang jzsjiale_isms:security_nav_logoff}</span></a>
        </li>
        <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_openmobilelogoff'] == 2}-->
        <li><a class="jzsjiale_isms_security_link {eval echo $navtype == 'logoffapply'?'is-active':''}" href="plugin.php?id=jzsjiale_isms:security&op=logoffapply">
                <svg class="icon" aria-hidden="true">
                    <use xlink:href="#icon-lajixiang"></use>
                </svg>
                <span class="jzsjiale_isms_security_linkTxt">{lang jzsjiale_isms:security_nav_logoff}</span></a>
        </li>
        <!--{/if}-->
    </ol>
</nav>