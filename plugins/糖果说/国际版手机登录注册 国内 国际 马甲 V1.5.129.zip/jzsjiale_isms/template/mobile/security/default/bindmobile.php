<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header')}
<div id="mobile_jzsjiale_isms_security_root">
    <div>
        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header_topbar')}
    </div>
    <main class="jzsjiale_isms_security_main">
        <div class="jzsjiale_isms_security_main_page">
            <div class="jzsjiale_isms_security_mainColumn">
                <div class="jzsjiale_isms_security_mainContent">
                    <div class="jzsjiale_isms_security_mainContent_title">
                        <h2 class="jzsjiale_isms_security_main_title">
                            <!--{if $userinfo['phone']}-->
                            {lang jzsjiale_isms:tip_bind_title_exist}
                            <!--{else}-->
                            {lang jzsjiale_isms:tip_bind_title_notexist}
                            <!--{/if}-->
                        </h2>
                        <div class="jzsjiale_isms_security_main_desc">
                            <!--{if $userinfo['phone']}-->
                            {lang jzsjiale_isms:tip_bind_title_exist_desc}
                            <!--{else}-->
                            {lang jzsjiale_isms:tip_bind_title_notexist_desc}
                            <!--{/if}-->
                        </div>
                    </div>
                    <div class="jzsjiale_isms_security_mainContent_setting">

                        <div class="jzsjiale_isms_main_page">
                            <div class="JCard jzsjiale_isms_main_content">
                                <div class="jzsjiale_isms_main_content_inner">
                                    <div class="ISMSPage">
                                        <div class="ISMSPage_content">
                                            <template>
                                                <i-form @submit.native.prevent novalidate>
                                                    <div class="ISMSForm-account">
                                                        <div class="ISMSForm-bindSelect">
                                                            <div class="ISMSForm-bind">

                                                                        <span class="JButton JSelect_bind">
                                                                            {lang jzsjiale_isms:tip_username}
                                                                        </span>
                                                            </div>
                                                        </div>
                                                        <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                                        <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                            <div class="ISMSForm-accountInput Input-wrapper">
                                                                <Input type="text" class="JInput" value="{$_G['username']}" readonly/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="ISMSForm-account">
                                                        <div class="ISMSForm-bindSelect">
                                                            <div class="ISMSForm-bind">

                                                                        <span class="JButton JSelect_bind">
                                                                            {lang jzsjiale_isms:tip_bind_areacode}
                                                                        </span>
                                                            </div>
                                                        </div>
                                                        <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                                        <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                            <div class="ISMSForm-accountInput Input-wrapper">
                                                                <Input type="text" class="JInput" value="{$userinfo['areacode']}" readonly/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="ISMSForm-account">
                                                        <div class="ISMSForm-bindSelect">
                                                            <div class="ISMSForm-bind">

                                                                        <span class="JButton JSelect_bind">
                                                                            {lang jzsjiale_isms:tip_bind_phone}
                                                                        </span>
                                                            </div>
                                                        </div>
                                                        <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                                        <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                            <div class="ISMSForm-accountInput Input-wrapper">
                                                                <Input type="text" class="JInput" value="{$userinfo['phone']}" readonly/>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton">
                                                        {lang jzsjiale_isms:btn_change}
                                                    </button>
                                                </i-form>
                                            </template>
                                        </div>
                                    </div>
                                    <!--{if in_array('mobileunbind',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_bindoption']))}-->
                                    <div class="ISMSPage-loginbtn" onclick="javascript:window.location.href='plugin.php?id=jzsjiale_isms:security&op=bindmobile&ac=unbindmobile';">
                                        {lang jzsjiale_isms:tip_btn_phone_jiebang}<span>{lang jzsjiale_isms:tip_btn_jiebang}</span>
                                    </div>
                                    <!--{/if}-->
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div class="jzsjiale_isms_security_sideColumn">
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_question')}
        </div>

        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer_content')}
    </main>

    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/drawer_menu')}
</div>

<script>
    new Vue({
        el: '#mobile_jzsjiale_isms_security_root',
        data: {
            isheader_fixed: false,
            referer: '{$dreferer}',
            isopenmenu: false
        },
        mounted() {
            let _this = this;
            window.addEventListener('scroll', _this.handleScroll, true);
        },
        methods: {
            handleScroll() {
                let _this = this;
                let scrollY = window.scrollY;
                //console.log("scrollY:"+scrollY);
                if (scrollY > 130) {
                    _this.isheader_fixed = true;
                } else {
                    _this.isheader_fixed = false;
                }
            },
            handleSubmit: function () {
                let _this = this;
                window.location.href = 'plugin.php?id=jzsjiale_isms:security&op=bindmobile&ac=rebindmobile';
            }
        },
        destroyed: function () {
            window.removeEventListener('scroll', this.handleScroll);
        }
    })
</script>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer')}