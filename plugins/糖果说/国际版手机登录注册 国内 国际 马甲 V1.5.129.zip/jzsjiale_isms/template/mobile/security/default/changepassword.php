<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header')}
<div id="mobile_jzsjiale_isms_security_root">
    <div>
        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header_topbar')}
    </div>
    <main class="jzsjiale_isms_security_main">
        <div class="jzsjiale_isms_security_main_page">
            <div class="jzsjiale_isms_security_mainColumn">
                <div class="jzsjiale_isms_security_mainContent">
                    <div class="jzsjiale_isms_security_mainContent_title">
                        <h2 class="jzsjiale_isms_security_main_title">
                            {lang jzsjiale_isms:tip_changepasswd_title}
                        </h2>
                        <div class="jzsjiale_isms_security_main_desc">
                            {lang jzsjiale_isms:tip_changepasswd_title_desc}
                        </div>
                    </div>
                    <div class="jzsjiale_isms_security_mainContent_setting">

                        <div class="jzsjiale_isms_main_page">
                            <div class="JCard jzsjiale_isms_main_content">
                                <div class="jzsjiale_isms_main_content_inner">
                                    <div class="ISMSPage">
                                        <div class="ISMSPage_content">
                                            <template>
                                                <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>
                                                    <div class="ISMSForm-password">
                                                        <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                            <div class="Input-wrapper">
                                                                <Input type="password" @input="togglePasswordStatus()" @focus="err_password = false" @blur="togglePasswordStatus()" v-model="ISMSFormItem.password" name="password" class="JInput" placeholder="{lang jzsjiale_isms:tip_password}"/>
                                                            </div>
                                                            <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_password }">
                                                                {lang jzsjiale_isms:msg_mima_empty}
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <div class="ISMSForm-password">
                                                        <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                            <div class="Input-wrapper">
                                                                <Input type="password" @input="toggleRePasswordStatus()" @focus="err_repassword = false" @blur="toggleRePasswordStatus()" v-model="ISMSFormItem.repassword" name="repassword" class="JInput" placeholder="{lang jzsjiale_isms:tip_repassword}"/>
                                                            </div>
                                                            <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_repassword }">
                                                                {{ msg_repassword }}
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton">
                                                        {lang jzsjiale_isms:btn_submit}
                                                    </button>
                                                </i-form>
                                            </template>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div class="jzsjiale_isms_security_sideColumn">
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_question')}
        </div>

        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer_content')}
    </main>

    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/drawer_menu')}
</div>

<script>
    new Vue({
        el: '#mobile_jzsjiale_isms_security_root',
        data: {
            ISMSFormItem: {
                password: '',
                repassword: ''
            },
            err_password: false,
            msg_password: "",
            err_repassword: false,
            msg_repassword: "",
            isheader_fixed: false,
            referer: '{$dreferer}',
            isopenmenu: false
        },
        mounted() {
            let _this = this;
            window.addEventListener('scroll', _this.handleScroll, true);
        },
        methods: {
            handleScroll() {
                let _this = this;
                let scrollY = window.scrollY;
                //console.log("scrollY:"+scrollY);
                if (scrollY > 130) {
                    _this.isheader_fixed = true;
                } else {
                    _this.isheader_fixed = false;
                }
            },
            handleSubmit: function () {
                let _this = this;
                _this.passwordVerify();
                _this.rePasswordVerify();
                if(_this.err_password || _this.err_repassword){
                    return false;
                }

                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'changepassword',
                    version: 1,
                    changepasswordsubmit: 'yes',
                    discode: '32563',
                    hashid: '{$hashid}',
                    uid: '{$uid}',
                    sign: '{$sign}',
                    password: _this.ISMSFormItem.password,
                    repassword: _this.ISMSFormItem.repassword,
                    formhash:'{FORMHASH}',
                    device: 'mobile',
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            if(response['data']['msg'] == 'msg_err_profile_password_tooshort'){
                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_profile_password_tooshort1']+response['data']['data']['pwlength']+jzsjiale_lang['msg_err_profile_password_tooshort2'],
                                    duration: 5
                                });
                            }else if(response['data']['msg'] == 'msg_err_password_weak'){
                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_password_weak']+': '+response['data']['data']['strongpw_str'],
                                    duration: 10
                                });
                            }else if(response['data']['msg'] == 'msg_need_login'){
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'member.php?mod=logging&action=login';
                                window.location.href = url_forward;
                            }else{
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                            }
                        }else{
                            _this.${Message}.success({
                                content: jzsjiale_lang['msg_change_success'],
                                duration: 10
                            });
                            let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'{$_G["siteurl"]}';
                            window.location.href = url_forward;
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            togglePasswordStatus: function () {
                let _this = this;
                _this.passwordVerify();

            },
            toggleRePasswordStatus: function () {
                let _this = this;
                _this.rePasswordVerify();

            },
            passwordVerify: function(){
                let _this = this;

                if(_.isEmpty(_this.ISMSFormItem.password)){
                    _this.err_password = true;
                    _this.msg_password = jzsjiale_lang['msg_password_empty'];
                    return;
                }else{
                    _this.err_password = false;
                    _this.msg_password = "";
                    return;
                }

            },
            rePasswordVerify: function(){
                let _this = this;

                if(_.isEmpty(_this.ISMSFormItem.repassword)){
                    _this.err_repassword = true;
                    _this.msg_repassword = jzsjiale_lang['msg_password_empty'];
                    return;
                }else if(_this.ISMSFormItem.password != _this.ISMSFormItem.repassword){
                    _this.err_repassword = true;
                    _this.msg_repassword = jzsjiale_lang['msg_password_different'];
                    return;
                }else{
                    _this.err_repassword = false;
                    _this.msg_repassword = "";
                    return;
                }

            }
        },
        destroyed: function () {
            window.removeEventListener('scroll', this.handleScroll);
        }
    })
</script>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer')}