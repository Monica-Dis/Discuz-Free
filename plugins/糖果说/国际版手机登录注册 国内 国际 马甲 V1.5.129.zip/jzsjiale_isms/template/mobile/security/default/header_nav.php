<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<div class="jzsjiale_isms_security_userinfo">

    <ul>
        <!--{if $_G['uid']}-->
        <li>
            <a class="Tabs-link jzsjiale_isms_header_TabsLink" href="home.php?mod=space&uid={$_G['uid']}&do=profile">
                <Avatar src="<!--{avatar($_G[uid], big, true)}-->" size="large" class="avatar">{$_G['username']}</Avatar>
            </a>
        </li>
        <li>
            <a class="Tabs-link jzsjiale_isms_header_TabsLink" href="home.php?mod=space&uid={$_G['uid']}&do=profile">
                {$_G['username']}
            </a>
        </li>
        <li>
            <a class="Tabs-link jzsjiale_isms_header_TabsLink" href="{$_G['siteurl']}">
                {lang jzsjiale_isms:title_safetycenter_home}
            </a>
            <a class="Tabs-link jzsjiale_isms_header_TabsLink pipe" href="javascript:void(0);">
                |
            </a>
            <a class="Tabs-link jzsjiale_isms_header_TabsLink" href="member.php?mod=logging&action=logout&formhash={FORMHASH}">
                {lang logout}
            </a>
        </li>
        <!--{else}-->
        <li>
            <a class="Tabs-link jzsjiale_isms_header_TabsLink" href="home.php?mod=space&uid={$_G['uid']}&do=profile">
                <Avatar src="<!--{avatar($_G[uid], big, true)}-->" size="large" class="avatar">{$_G['username']}</Avatar>
            </a>
        </li>
        <li>
            <a class="Tabs-link jzsjiale_isms_header_TabsLink" href="member.php?mod=register">
                {lang jzsjiale_isms:register_title}
            </a>
        </li>
        <li>
            <a class="Tabs-link jzsjiale_isms_header_TabsLink" href="member.php?mod=logging&action=login">
                {lang jzsjiale_isms:login_title}
            </a>
        </li>
        <!--{/if}-->
    </ul>
</div>