<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header')}
<div id="mobile_jzsjiale_isms_security_root">
    <div>
        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header_topbar')}
    </div>
    <main class="jzsjiale_isms_security_main">
        <div class="jzsjiale_isms_security_main_page">
            <div class="jzsjiale_isms_security_mainColumn">
                <div class="jzsjiale_isms_security_mainContent">
                    <div class="jzsjiale_isms_security_mainContent_title">
                        <h2 class="jzsjiale_isms_security_main_title">
                            {lang jzsjiale_isms:tip_ask_title}
                        </h2>
                        <div class="jzsjiale_isms_security_main_desc">
                            {lang jzsjiale_isms:tip_ask_title_desc}
                        </div>
                    </div>
                    <div class="jzsjiale_isms_security_mainContent_setting">

                        <div class="jzsjiale_isms_main_page">
                            <div class="JCard jzsjiale_isms_main_content">
                                <div class="jzsjiale_isms_main_content_inner">
                                    <div class="ISMSPage">
                                        <div class="ISMSPage_content">
                                            <template>
                                                <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>

                                                    <div class="ISMSForm-account">
                                                        <div class="ISMSForm-logintypeSelect">
                                                            <div class="Popover ISMSForm-logintype" style="display: block!important;">

                                                                <i-select v-model="ISMSFormItem.questionid" @on-change="toggleQuestionsStatus()" class="JButton JSelect_logintype" size="large" style="height: 48px;border: none;" placeholder="{lang jzsjiale_isms:placeholder}" transfer>

                                                                    <i-option v-for="(item, index) in questions" :value="item.id" :key="item.index">
                                                                        {{ item.lang }}
                                                                    </i-option>

                                                                </i-select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="ISMSForm-password">
                                                        <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                            <div class="Input-wrapper">
                                                                <Input type="text" @input="toggleQuestionsStatus()" @focus="err_answer = false" @blur="toggleQuestionsStatus()" v-model="ISMSFormItem.answer" name="answer" class="JInput" placeholder="{lang jzsjiale_isms:tip_answer}"/>
                                                            </div>
                                                            <div class="ISMSFormInput-errorMask " :class="{ 'ISMSFormInput-errorMask-hidden' : !err_answer }">
                                                                {{ msg_answer }}
                                                            </div>
                                                        </div>

                                                    </div>

                                                    <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton">
                                                        {lang jzsjiale_isms:btn_submit}
                                                    </button>
                                                </i-form>
                                            </template>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div class="jzsjiale_isms_security_sideColumn">
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_question')}
        </div>

        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer_content')}
    </main>

    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/drawer_menu')}
</div>


<script>
    new Vue({
        el: '#mobile_jzsjiale_isms_security_root',
        data: {
            ISMSFormItem: {
                questionid: 0,
                answer: ''
            },
            questions:[
                {'id':0,'lang':'{lang jzsjiale_isms:security_question_0}'},
                {'id':1,'lang':'{lang security_question_1}'},
                {'id':2,'lang':'{lang security_question_2}'},
                {'id':3,'lang':'{lang security_question_3}'},
                {'id':4,'lang':'{lang security_question_4}'},
                {'id':5,'lang':'{lang security_question_5}'},
                {'id':6,'lang':'{lang security_question_6}'},
                {'id':7,'lang':'{lang security_question_7}'},
            ],
            err_answer: false,
            msg_answer: "",
            isheader_fixed: false,
            referer: '{$dreferer}',
            isopenmenu: false
        },
        mounted() {
            let _this = this;
            window.addEventListener('scroll', _this.handleScroll, true);
        },
        methods: {
            handleScroll() {
                let _this = this;
                let scrollY = window.scrollY;
                //console.log("scrollY:"+scrollY);
                if (scrollY > 130) {
                    _this.isheader_fixed = true;
                } else {
                    _this.isheader_fixed = false;
                }
            },
            handleSubmit: function () {
                let _this = this;
                _this.askQuestionsVerify();
                if(_this.err_newusername){
                    return false;
                }

                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'ask',
                    version: 1,
                    asksubmit: 'yes',
                    discode: '32563',
                    hashid: '{$hashid}',
                    uid: '{$uid}',
                    sign: '{$sign}',
                    questionid: _this.ISMSFormItem.questionid,
                    answer: encodeURI(_this.ISMSFormItem.answer),
                    formhash:'{FORMHASH}',
                    device: 'mobile',
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            if(response['data']['msg'] == 'msg_need_login'){
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'member.php?mod=logging&action=login';
                                window.location.href = url_forward;
                            }else{
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                            }
                        }else{
                            _this.${Message}.success({
                                content: jzsjiale_lang['msg_change_success'],
                                duration: 10
                            });
                            let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'{$_G["siteurl"]}';
                            window.location.href = url_forward;
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            toggleQuestionsStatus: function () {
                let _this = this;
                _this.askQuestionsVerify();

            },
            askQuestionsVerify: function(){
                let _this = this;

                if(_this.ISMSFormItem.questionid > 0 && _.isEmpty(_this.ISMSFormItem.answer)){
                    _this.err_answer = true;
                    _this.msg_answer = jzsjiale_lang['msg_answer_empty2'];
                    return;
                }else{
                    _this.err_answer = false;
                    _this.msg_answer = "";
                    return;
                }

            }
        },
        destroyed: function () {
            window.removeEventListener('scroll', this.handleScroll);
        }
    })
</script>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer')}