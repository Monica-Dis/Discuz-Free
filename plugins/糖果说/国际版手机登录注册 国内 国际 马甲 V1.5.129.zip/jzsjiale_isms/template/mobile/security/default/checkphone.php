<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header')}
<div id="mobile_jzsjiale_isms_security_root">
    <div>
        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header_topbar')}
    </div>
    <main class="jzsjiale_isms_security_main">
        <div class="jzsjiale_isms_security_main_page">
            <div class="jzsjiale_isms_security_mainColumn">
                <div class="jzsjiale_isms_security_mainContent">
                    <div class="jzsjiale_isms_security_mainContent_title">
                        <h2 class="jzsjiale_isms_security_main_title">
                            {lang jzsjiale_isms:tip_checkphone_title}
                        </h2>
                        <div class="jzsjiale_isms_security_main_desc">
                            <!--{if empty($tip_desc)}-->
                            {lang jzsjiale_isms:tip_checkphone_title_desc}
                            <!--{else}-->
                            {$tip_desc}
                            <!--{/if}-->
                        </div>
                    </div>
                    <div class="jzsjiale_isms_security_mainContent_setting">

                        <div class="jzsjiale_isms_main_page">
                            <div class="JCard jzsjiale_isms_main_content">
                                <div class="jzsjiale_isms_main_content_inner">
                                    <div class="ISMSPage">
                                        <div class="ISMSPage_content">
                                            <template>
                                                <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>
                                                    <div class="ISMSForm-account">
                                                        <div class="ISMSForm-bindSelect">
                                                            <div class="ISMSForm-bind">

                                                                        <span class="JButton JSelect_bind">
                                                                            {lang jzsjiale_isms:tip_bind_phone_areacode}
                                                                        </span>
                                                            </div>
                                                        </div>
                                                        <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                                        <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                            <div class="ISMSForm-accountInput Input-wrapper">
                                                                <Input type="text" class="JInput" value="{$userinfo['phone']}" readonly/>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="ISMSForm-account">
                                                        <div class="ISMSForm-bindSelect">
                                                            <div class="ISMSForm-bind">

                                                                        <span class="JButton JSelect_bind">
                                                                            {lang jzsjiale_isms:tip_bind_phone_areacode_desc}
                                                                        </span>
                                                            </div>
                                                        </div>
                                                        <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                            <div class="ISMSForm-accountInput Input-wrapper">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="ISMSForm-account">
                                                        <div class="ISMSForm-areacodeSelect">
                                                            <div class="Popover ISMSForm-areacode">

                                                                <i-select @on-change="togglePhoneStatus()" v-model="ISMSFormItem.areacode" class="JButton JSelect_areacode" placeholder="{lang jzsjiale_isms:placeholder}" transfer>

                                                                    <i-option v-for="(item, index) in areacodeList.commonareacodeList" :value="item.areacode" :key="item.index">
                                                                        {{ item.countrycn }}&nbsp;&nbsp;+{{ item.areacode }}
                                                                    </i-option>
                                                                    <i-option v-if="areacodeList.commonareacodeList && areacodeList.commonareacodeList.length >0" value="splitline" disabled>
                                                                        -------------------------------------
                                                                    </i-option>
                                                                    <i-option v-for="(item, index) in areacodeList.allareacodeList" :value="item.areacode" :key="item.index">
                                                                        {{ item.countrycn }}&nbsp;&nbsp;+{{ item.areacode }}
                                                                    </i-option>


                                                                </i-select>
                                                            </div>
                                                        </div>
                                                        <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                                        <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                            <div class="ISMSForm-accountInput Input-wrapper">
                                                                <Input type="tel" @input="togglePhoneStatus()" @focus="err_phone = false" @blur="togglePhoneStatus()" v-model="ISMSFormItem.phone" name="phone" class="JInput" :maxlength="size_phone" :size="size_phone" placeholder="{lang jzsjiale_isms:tip_phone}"/>
                                                            </div>
                                                            <div class="ISMSFormInput-errorMask " :class="{ 'ISMSFormInput-errorMask-hidden' : !err_phone }">
                                                                {{ msg_phone }}
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton">
                                                        {lang jzsjiale_isms:btn_submit}
                                                    </button>
                                                </i-form>
                                            </template>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>

        <div class="jzsjiale_isms_security_sideColumn">
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_question')}
        </div>

        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer_content')}
    </main>

    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/drawer_menu')}
</div>

<script>
    new Vue({
        el: '#mobile_jzsjiale_isms_security_root',
        data: {
            ISMSFormItem: {
                areacode: '86',
                phone: ''
            },
            areacodeList:{
                allareacodeList:[],
                commonareacodeList:[]
            },
            err_phone: false,
            msg_phone: "",
            isheader_fixed: false,
            referer: '{$dreferer}',
            isopenmenu: false
        },
        beforeCreate(){
            let _this = this;
            //j_z_s_j_i_a_l_e_i_s_m_s_a_p_i
            axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                module: 'areacode',
                version: 1,
                formhash:'{FORMHASH}'
            }))
                .then(function (response) {
                    if(response['data']['code'] != 0){
                        _this.areacodeList.allareacodeList = response['data']['data'];
                        _this.areacodeList.commonareacodeList = response['data']['data'];

                        _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                    }else{
                        _this.areacodeList.allareacodeList = response['data']['data']['allareacode'];
                        _this.areacodeList.commonareacodeList = response['data']['data']['commonareacode'];
                    }
                })
                .catch(function (error) {
                    //console.log(error);
                    _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                });
        },
        computed: {
            size_phone: function () {
                let _this = this;
                return (_this.ISMSFormItem.areacode == '86' || _.isEmpty(_this.ISMSFormItem.areacode)) ? 11 : '';
            }
        },
        mounted() {
            let _this = this;
            window.addEventListener('scroll', _this.handleScroll, true);
        },
        created() {
            let _this = this;
            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_defaultareacode'] != ""}-->
            _this.ISMSFormItem.areacode = "{$_G['cache']['plugin']['jzsjiale_isms']['g_defaultareacode']}";
            <!--{/if}-->
        },
        methods: {
            handleScroll() {
                let _this = this;
                let scrollY = window.scrollY;
                //console.log("scrollY:"+scrollY);
                if (scrollY > 130) {
                    _this.isheader_fixed = true;
                } else {
                    _this.isheader_fixed = false;
                }
            },
            handleSubmit: function () {
                let _this = this;
                _this.bindPhoneVerify();
                if(_this.err_phone){
                    return false;
                }

                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'checkphone',
                    version: 1,
                    checkphonesubmit: 'yes',
                    discode: '32563',
                    areacode: _this.ISMSFormItem.areacode,
                    phone: _this.ISMSFormItem.phone,
                    formhash:'{FORMHASH}',
                    device: 'mobile',
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            if(response['data']['msg'] == 'msg_need_login'){
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'member.php?mod=logging&action=login';
                                window.location.href = url_forward;
                            }else{
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                            }
                        }else{
                            _this.${Message}.success({
                                content: jzsjiale_lang['msg_verify_success'],
                                duration: 10
                            });
                            let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'{$_G["siteurl"]}';
                            window.location.href = url_forward;
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            togglePhoneStatus: function () {
                let _this = this;
                _this.bindPhoneVerify();

            },
            bindPhoneVerify: function(){
                let _this = this;
                if(_.isEmpty(_this.ISMSFormItem.areacode) || !_.isAreaCode(_this.ISMSFormItem.areacode)){
                    _this.err_phone = true;
                    _this.msg_phone = jzsjiale_lang['msg_areacode_error'];
                    return;
                }
                if(_.isEmpty(_this.ISMSFormItem.phone)){
                    _this.err_phone = true;
                    _this.msg_phone = jzsjiale_lang['msg_phone_empty'];
                    return;
                }else if(!_.isMobilePhone(_this.ISMSFormItem.areacode,_this.ISMSFormItem.phone)){
                    _this.err_phone = true;
                    _this.msg_phone = jzsjiale_lang['msg_phone_formaterror'];
                    return;
                }else{
                    _this.err_phone = false;
                    _this.msg_phone = "";
                    return;
                }
            },
        },
        destroyed: function () {
            window.removeEventListener('scroll', this.handleScroll);
        }
    })
</script>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer')}