<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<div class="">
    <div>
        <div class="FAQ" style="">
            <article class="jzsjiale_isms_security_FAQ">
                <h3 class="jzsjiale_isms_security_FAQ_pageTitle">
                    <span>{lang jzsjiale_isms:security_faq_changjianwenti}</span>
                </h3>
                <div class="jzsjiale_isms_security_FAQ_sectionWrap">
                    <section class="jzsjiale_isms_security_FAQ_section">
                        <Collapse simple>
                            <!--{eval $wentiindex = 1; }-->
                            <!--{loop $changjianwenti $wenti}-->
                            <!--{if $wenti['type'] == $navtype && $wenti['status'] == 1}-->
                            <Panel hide-arrow>
                                {$wentiindex}{lang jzsjiale_isms:security_faq_dunhao}{$wenti['question']}
                                <p slot="content">
                                    {$wenti['answer']}
                                </p>
                            </Panel>
                            <!--{eval $wentiindex++; }-->
                            <!--{/if}-->
                            <!--{/loop}-->

                        </Collapse>
                    </section>
                </div>
            </article>
        </div>
    </div>
</div>