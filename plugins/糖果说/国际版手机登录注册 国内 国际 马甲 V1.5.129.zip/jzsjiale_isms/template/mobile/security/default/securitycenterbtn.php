<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<!--{block securitycenterbtn}-->
{if $_GET[mod] == 'space' && $_GET[mycenter]}
<div class="myinfo_list cl">
    <ul>
        <li><a href="plugin.php?id=jzsjiale_isms:security">{lang jzsjiale_isms:title_safetycenter}</a></li>
    </ul>
</div>
{/if}
<!--{/block}-->