<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<Drawer title="{lang jzsjiale_isms:title_safetycenter_menu}" width="200px" :closable="true" :scrollable="true" v-model="isopenmenu">
    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_nav')}
    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header_nav')}
</Drawer>