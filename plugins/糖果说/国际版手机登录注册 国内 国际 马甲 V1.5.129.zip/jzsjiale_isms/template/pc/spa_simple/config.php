<?php
/**
 * Created by jzsjiale.
 * User: jzsjiale
 * Date: 2020/3/14
 * Time: 16:47 PM
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$config = array(
    'dir'=>'spa_simple',
    'title'=>'\u7b80\u6d01\u98ce\u683c\uff08\u0054\u0061\u0062\u9009\u9879\u5361\u5f0f\u6837\u5f0f\uff09\u0020\u0031\u002e\u0031\u002e\u0032\u0038',
    'desc'=>'\u7b80\u6d01\u98ce\u683c\uff08\u0054\u0061\u0062\u9009\u9879\u5361\u5f0f\u6837\u5f0f\uff09'
);