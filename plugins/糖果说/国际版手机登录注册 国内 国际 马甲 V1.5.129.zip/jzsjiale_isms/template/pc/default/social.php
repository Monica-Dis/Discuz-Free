<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<!--{if $jsms_muban_pc['apptype'] != 'none'}-->
<a href="javascript:;" @click="applogin()" target="_self">
    <svg class="icon" aria-hidden="true">
        <use xlink:href="#icon-app1"></use>
    </svg>
    <!--{if $jsms_muban_pc['sociatitle']}-->
    <span>{lang jzsjiale_isms:social_app}</span>
    <!--{/if}-->
</a>
<!--{/if}-->
<!--{if (empty($jsms_muban_pc['weixintype']) || $jsms_muban_pc['weixintype'] == 'diy') && $jsms_muban_pc['weixinurl']}-->
<a href="{$jsms_muban_pc['weixinurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pcdetailed']))}{echo urlencode(dreferer());}{/if}" target="_self">
    <svg class="icon" aria-hidden="true">
        <use xlink:href="#icon-weixin"></use>
    </svg>
    <!--{if $jsms_muban_pc['sociatitle']}-->
    <span>{lang jzsjiale_isms:social_weixin}</span>
    <!--{/if}-->
</a>
<!--{/if}-->
<!--{if $jsms_muban_pc['weixinbtn'] && !empty($jsms_muban_pc['weixintype']) && $jsms_muban_pc['weixintype'] != 'diy'}-->
<a href="javascript:;" @click="wechatlogin()" target="_self">
    <svg class="icon" aria-hidden="true">
        <use xlink:href="#icon-weixin"></use>
    </svg>
    <!--{if $jsms_muban_pc['sociatitle']}-->
    <span>{lang jzsjiale_isms:social_weixin}</span>
    <!--{/if}-->
</a>
<!--{/if}-->
<!--{if $jsms_muban_pc['qqurl']}-->
<a href="{$jsms_muban_pc['qqurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pcdetailed']))}{echo urlencode(dreferer());}{/if}" target="_self">
    <svg class="icon" aria-hidden="true">
        <use xlink:href="#icon-tubiao215"></use>
    </svg>
    <!--{if $jsms_muban_pc['sociatitle']}-->
    <span>{lang jzsjiale_isms:social_qq}</span>
    <!--{/if}-->
</a>
<!--{/if}-->
<!--{if $jsms_muban_pc['weibourl']}-->
<a href="{$jsms_muban_pc['weibourl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pcdetailed']))}{echo urlencode(dreferer());}{/if}" target="_self">
    <svg class="icon" aria-hidden="true">
        <use xlink:href="#icon-weibo"></use>
    </svg>
</a>
<!--{/if}-->
<!--{if $jsms_muban_pc['googleurl']}-->
<a href="{$jsms_muban_pc['googleurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pcdetailed']))}{echo urlencode(dreferer());}{/if}" target="_self">
    <svg class="icon" aria-hidden="true">
        <use xlink:href="#icon-google"></use>
    </svg>
</a>
<!--{/if}-->
<!--{if $jsms_muban_pc['facebookurl']}-->
<a href="{$jsms_muban_pc['facebookurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pcdetailed']))}{echo urlencode(dreferer());}{/if}" target="_self">
    <svg class="icon" aria-hidden="true">
        <use xlink:href="#icon-facebook"></use>
    </svg>
</a>
<!--{/if}-->
<!--{if $jsms_muban_pc['twitterurl']}-->
<a href="{$jsms_muban_pc['twitterurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pcdetailed']))}{echo urlencode(dreferer());}{/if}" target="_self">
    <svg class="icon" aria-hidden="true">
        <use xlink:href="#icon-twitter"></use>
    </svg>
</a>
<!--{/if}-->
<!--{if $jsms_muban_pc['weiruanurl']}-->
<a href="{$jsms_muban_pc['weiruanurl']}{if in_array('setreferer',(array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pcdetailed']))}{echo urlencode(dreferer());}{/if}" target="_self">
    <svg class="icon" aria-hidden="true">
        <use xlink:href="#icon-weiruan"></use>
    </svg>
</a>
<!--{/if}-->