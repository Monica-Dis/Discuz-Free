<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<div id="bg720yun_wrapper">
    <iframe class="bgiframe" sandbox="allow-scripts allow-same-origin" id="mh" src="{$jsms_muban_pc['bg720yun']}"></iframe>
</div>
<style>
    body {
        background-size:cover;
    }
    #bg720yun_wrapper {
        margin: 0px;
        padding: 0px;
    }

    #bg720yun_wrapper .bgiframe {
        position: absolute;
        width: 100%;
        height: 100%;
        min-width: 100%;
        min-height: 100%;
        border-width: 0px;

    }
    .jzsjiale_i_sms_main_page {
        background-color: unset!important;
        background-image: unset!important;
    }
    .jzsjiale_isms_main_content, .jzsjiale_isms_page_appdownloadBtn, .jzs-jiale-isms-footer-content{
        z-index: 1!important;
    }
    .jzs-jiale-isms-footer-content{
        position: relative;
    }
</style>