<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<div id="video_wrapper">
    <video id="bgvideo" autoplay="autoplay" {if $jsms_muban_pc['ismuted']}muted="muted"{/if} loop="loop" >
        <source src="{$jsms_muban_pc['bgvideo']}" type="video/mp4">
    </video>
    <!--{if $jsms_muban_pc['usermuted']}-->
    <a href="javascript:toggleMuted();" style="position: absolute;">
        <svg class="icon" aria-hidden="true" id="bgvideo_shengyinkai" {if $jsms_muban_pc['ismuted']}style="display:none;"{/if}>
            <use xlink:href="#icon-shengyinkai"></use>
        </svg>
        <svg class="icon" aria-hidden="true" id="bgvideo_shengyinguan" {if !$jsms_muban_pc['ismuted']}style="display:none;"{/if}>
            <use xlink:href="#icon-shengyinguanbi"></use>
        </svg>
    </a>
    <script>
        function toggleMuted(){
            let bgvideo = document.getElementById('bgvideo');
            if(bgvideo.muted){
                bgvideo.muted = false;
                document.getElementById("bgvideo_shengyinkai").style.display = "block";
                document.getElementById("bgvideo_shengyinguan").style.display = "none";
            }else{
                bgvideo.muted = true;
                document.getElementById("bgvideo_shengyinkai").style.display = "none";
                document.getElementById("bgvideo_shengyinguan").style.display = "block";
            }
        }
    </script>
    <!--{/if}-->
</div>
<style>
    body {
        background-size:cover;
    }
    #video_wrapper {
        margin: 0px;
        padding: 0px;
    }

    #video_wrapper video {
        position: fixed;
        top: 50%;
        left: 50%;
        z-index: -100;
        min-width: 100%;
        min-height: 100%;
        width: auto;
        height: auto;
        transform: translate(-50%, -50%);
    }

    .jzsjiale_i_sms_main_page {
        background-color: unset!important;
        background-image: unset!important;
    }
</style>