<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<!--{block loginbtn}-->
	<div class="fastlg_fm y" style="margin-right: 10px; padding-right: 10px">
		<p><a href="member.php?mod=logging&action=login" target="_self"><img src="source/plugin/jzsjiale_isms/static/images/login.png" style="width:124px;height:24px;" class="vm" /></a></p>
		<p class="hm xg1" style="padding-top: 2px;">{lang jzsjiale_isms:loginextratip}</p>
	</div>
<!--{/block}-->