<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<!--{block phonebindbtn}-->
<span class='pipe'>|</span><a class='phonebind_btn' href='plugin.php?id=jzsjiale_isms:security&op=bindmobile'><img src='source/plugin/jzsjiale_isms/static/images/sjbd.png' align='absmiddle' style='border-radius:2px;width:98px;height:20px;margin-top: -3px;margin-right: 3px;'/></a>
<!--{/block}-->