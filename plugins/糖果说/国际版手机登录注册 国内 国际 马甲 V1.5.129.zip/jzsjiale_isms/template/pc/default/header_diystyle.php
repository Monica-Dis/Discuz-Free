<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<style type="text/css">
    <!--{if $jsms_muban_pc['pianyi']}-->
    .jzsjiale_isms_main_content {
    margin-right:{$jsms_muban_pc['pianyi']};
    }
    .jzsjiale_isms_page_appdownloadBtn{
        margin: 30px auto 0px auto;
        margin-right:{$jsms_muban_pc['pianyi']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['titlecolor']}-->
    .jzsjiale_isms_main_content_header_title {
    color:{$jsms_muban_pc['titlecolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['desccolor']}-->
    .jzsjiale_isms_main_content_header_desc {
    color:{$jsms_muban_pc['desccolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['btntextcolor']}-->
    .ISMSForm-submitButton{
    color: {$jsms_muban_pc['btntextcolor']};
    border: unset!important;
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['btnacolor']}-->
    .ISMSForm-Login-Type{
    color: {$jsms_muban_pc['btnacolor']}!important;
    }
    .ISMSForm-Forgot-Password{
    color: {$jsms_muban_pc['btnacolor']}!important;
    opacity:0.7!important;
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['btnbackgroundcolor']}-->
    .ISMSForm-submitButton{
    background-color: {$jsms_muban_pc['btnbackgroundcolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['btnbackgroundhovercolor']}-->
    .ISMSForm-submitButton:hover{
    background-color: {$jsms_muban_pc['btnbackgroundhovercolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['appdownloadcolor']}-->
    .jzsjiale_isms_page_appdownloadBtn.JButton {
    color: {$jsms_muban_pc['appdownloadcolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['bgcolor']}-->
    .jzsjiale_i_sms_main_page {
    background-color: {$jsms_muban_pc['bgcolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['bgimg']}-->
    .jzsjiale_i_sms_main_page {
        background-image: url("{$jsms_muban_pc['bgimg']}");
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['footercolor']}-->
    .jzs-jiale-isms-footer-content {
    color: {$jsms_muban_pc['footercolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['footershadowcolor']}-->
    .jzs-jiale-isms-footer-content {
    text-shadow: 0 1px 2px {$jsms_muban_pc['footershadowcolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['socialcolor']}-->
    .ISMSPage-footer-social .icon, .ISMSPage-footer-social a span{
    color: {$jsms_muban_pc['socialcolor']}!important;
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['sociatitle']}-->
    .ISMSPage-footer-social a {
        margin-left: 8px!important;
    }
    .ISMSPage-footer-social a span{
        vertical-align: top;
        font-size: 12px;
    }
    <!--{/if}-->
</style>