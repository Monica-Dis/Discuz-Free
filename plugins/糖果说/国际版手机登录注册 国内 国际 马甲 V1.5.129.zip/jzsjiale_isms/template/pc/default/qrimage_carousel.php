<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<Carousel>
    <!--{if $jsms_muban_pc['appqrimageandroid']}-->
    <Carousel-Item>
        <Row>
            <Col span="24">
            <img src="{$jsms_muban_pc['appqrimageandroid']}" class="jzsjiale_isms_app_img"/>
            </Col>
        </Row>
        <Row>
            <Col span="24">
            <span class="jzsjiale_isms_app_title">
                                              {$jsms_muban_pc['appqrtitleandroid']}
                                          </span>
            </Col>
        </Row>
        <br/>
    </Carousel-Item>
    <!--{/if}-->
    <!--{if $jsms_muban_pc['appqrimageios']}-->
    <Carousel-Item>
        <Row>
            <Col span="24">
            <img src="{$jsms_muban_pc['appqrimageios']}" class="jzsjiale_isms_app_img"/>
            </Col>
        </Row>
        <Row>
            <Col span="24">
            <span class="jzsjiale_isms_app_title">
                                              {$jsms_muban_pc['appqrtitleios']}
                                          </span>
            </Col>
        </Row>
        <br/>
    </Carousel-Item>
    <!--{/if}-->
    <!--{if $jsms_muban_pc['appqrimagewxminapp']}-->
    <Carousel-Item>
        <Row>
            <Col span="24">
            <img src="{$jsms_muban_pc['appqrimagewxminapp']}" class="jzsjiale_isms_app_img"/>
            </Col>
        </Row>
        <Row>
            <Col span="24">
            <span class="jzsjiale_isms_app_title">
                                              {$jsms_muban_pc['appqrtitlewxminapp']}
                                          </span>
            </Col>
        </Row>
        <br/>
    </Carousel-Item>
    <!--{/if}-->
    <!--{if $jsms_muban_pc['appqrimagebaiduminapp']}-->
    <Carousel-Item>
        <Row>
            <Col span="24">
            <img src="{$jsms_muban_pc['appqrimagebaiduminapp']}" class="jzsjiale_isms_app_img"/>
            </Col>
        </Row>
        <Row>
            <Col span="24">
            <span class="jzsjiale_isms_app_title">
                                              {$jsms_muban_pc['appqrtitlebaiduminapp']}
                                          </span>
            </Col>
        </Row>
        <br/>
    </Carousel-Item>
    <!--{/if}-->
    <!--{if $jsms_muban_pc['appqrimagetoutiaominapp']}-->
    <Carousel-Item>
        <Row>
            <Col span="24">
            <img src="{$jsms_muban_pc['appqrimagetoutiaominapp']}" class="jzsjiale_isms_app_img"/>
            </Col>
        </Row>
        <Row>
            <Col span="24">
            <span class="jzsjiale_isms_app_title">
                                              {$jsms_muban_pc['appqrtitletoutiaominapp']}
                                          </span>
            </Col>
        </Row>
        <br/>
    </Carousel-Item>
    <!--{/if}-->
    <!--{if $jsms_muban_pc['appqrimagealipayminapp']}-->
    <Carousel-Item>
        <Row>
            <Col span="24">
            <img src="{$jsms_muban_pc['appqrimagealipayminapp']}" class="jzsjiale_isms_app_img"/>
            </Col>
        </Row>
        <Row>
            <Col span="24">
            <span class="jzsjiale_isms_app_title">
                                              {$jsms_muban_pc['appqrtitlealipayminapp']}
                                          </span>
            </Col>
        </Row>
        <br/>
    </Carousel-Item>
    <!--{/if}-->
    <!--{if $jsms_muban_pc['appqrimageqqminapp']}-->
    <Carousel-Item>
        <Row>
            <Col span="24">
            <img src="{$jsms_muban_pc['appqrimageqqminapp']}" class="jzsjiale_isms_app_img"/>
            </Col>
        </Row>
        <Row>
            <Col span="24">
            <span class="jzsjiale_isms_app_title">
                                              {$jsms_muban_pc['appqrtitleqqminapp']}
                                          </span>
            </Col>
        </Row>
        <br/>
    </Carousel-Item>
    <!--{/if}-->
    <!--{if $jsms_muban_pc['appqrimagekuaiminapp']}-->
    <Carousel-Item>
        <Row>
            <Col span="24">
            <img src="{$jsms_muban_pc['appqrimagekuaiminapp']}" class="jzsjiale_isms_app_img"/>
            </Col>
        </Row>
        <Row>
            <Col span="24">
            <span class="jzsjiale_isms_app_title">
                                              {$jsms_muban_pc['appqrtitlekuaiminapp']}
                                          </span>
            </Col>
        </Row>
        <br/>
    </Carousel-Item>
    <!--{/if}-->
</Carousel>