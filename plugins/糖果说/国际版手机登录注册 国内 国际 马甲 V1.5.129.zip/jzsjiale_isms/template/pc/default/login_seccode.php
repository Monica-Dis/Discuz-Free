<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/header')}
<div id="jzsjiale_isms_login_root">
    <main class="jzs_jiale_i_sms_login_main">
        <div class="jzsjiale_i_sms_main_page">
            <div class="jzsjiale_isms_login_content">

                <div class="JCard jzsjiale_isms_main_content">
                    <div class="jzsjiale_isms_main_content_header">
                        <!--{if !empty($jsms_muban_pc['weixintype']) && $jsms_muban_pc['weixintype'] != 'diy'}-->
                        <a href="javascript:;" @click="wechatlogin()" class="wechat" :style="{background:'url(source/plugin/jzsjiale_isms/template/pc/default/style/images/'+wechatbtnimg+') no-repeat top right'}"></a>
                            <!--{if !empty($jsms_muban_pc['weixintypetip']) || $jsms_muban_pc['weixintypetip'] != 0}-->
                            <span v-if="now_show_wechat == false" class="wechatlogin_tip">
                                <!--{if $jsms_muban_pc['weixintypetip'] == 1}-->
                                <svg class="icon" aria-hidden="true">
                                            <use xlink:href="#icon-weixin4"></use>
                                </svg>
                                <!--{/if}-->
                                {lang jzsjiale_isms:tip_wechat_login}
                            </span>
                            <span v-else class="accountlogin_tip">
                                <!--{if $jsms_muban_pc['weixintypetip'] == 1}-->
                                <svg class="icon" aria-hidden="true">
                                            <use xlink:href="#icon-shouji"></use>
                                </svg>
                                <!--{/if}-->
                                {lang jzsjiale_isms:tip_accountlogin_tip}
                            </span>
                            <!--{/if}-->
                        <!--{/if}-->
                        <div class="jzsjiale_isms_main_content_header_title">
                            <!--{if $jsms_muban_pc['title']}-->
                            {$jsms_muban_pc['title']}
                            <!--{elseif $jsms_muban_pc['logo']}-->
                            <img src="{$jsms_muban_pc['logo']}" class="jzsjiale_isms_main_content_header_title_img"/>
                            <!--{else}-->
                            {lang jzsjiale_isms:title_and_logo_null}
                            <!--{/if}-->
                        </div>
                        <div class="jzsjiale_isms_main_content_header_desc">
                            {$jsms_muban_pc['logindesc']}
                        </div>
                    </div>
                    <div class="jzsjiale_isms_main_content_inner">
                        <div class="ISMSPage">
                            <div class="ISMSPage_content">
                                <template>
                                    <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>
                                        <div class="ISMSForm-account">
                                            <div class="ISMSForm-areacodeSelect">
                                                <div class="Popover ISMSForm-areacode">

                                                    <i-select @on-change="togglePhoneStatus()" v-model="ISMSFormItem.areacode" class="JButton JSelect_areacode" placeholder="{lang jzsjiale_isms:placeholder}" transfer>

                                                        <i-option v-for="(item, index) in areacodeList.commonareacodeList" :value="item.areacode" :key="item.index">
                                                            {{ item.countrycn }}&nbsp;&nbsp;+{{ item.areacode }}
                                                        </i-option>
                                                        <i-option v-if="areacodeList.commonareacodeList && areacodeList.commonareacodeList.length >0" value="splitline" disabled>
                                                            -------------------------------------
                                                        </i-option>
                                                        <i-option v-for="(item, index) in areacodeList.allareacodeList" :value="item.areacode" :key="item.index">
                                                            {{ item.countrycn }}&nbsp;&nbsp;+{{ item.areacode }}
                                                        </i-option>


                                                    </i-select>
                                                </div>
                                            </div>
                                            <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                            <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                <div class="ISMSForm-accountInput Input-wrapper">
                                                    <Input type="tel" @input="togglePhoneStatus()" @focus="err_phone = false" @blur="togglePhoneStatus()" v-model="ISMSFormItem.phone" name="phone" class="JInput" :maxlength="size_phone" :size="size_phone" placeholder="{lang jzsjiale_isms:tip_phone}"/>
                                                </div>
                                                <div class="ISMSFormInput-errorMask " :class="{ 'ISMSFormInput-errorMask-hidden' : !err_phone }">
                                                    {{ msg_phone }}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="ISMSForm-seccode">
                                            <div class="ISMSForm-seccodeinput ISMSForm-seccodeinputContainer">
                                                <div class="ISMSForm-seccodeInput">
                                                    <div class="Input-wrapper">
                                                        <Input type="text" @input="toggleSeccodeStatus()" @focus="err_seccode = false" @blur="toggleSeccodeStatus()" v-model="ISMSFormItem.seccode" name="seccode" class="JInput" placeholder="{lang jzsjiale_isms:tip_seccode1}{$_G['cache']['plugin']['jzsjiale_isms']['g_seccodebits']}{lang jzsjiale_isms:tip_seccode2}"/>

                                                    </div>
                                                    <div class="ISMSFormInput-errorMask ISMSFormInput-errorSeccodeMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_seccode }">
                                                        {{ msg_seccode }}
                                                    </div>
                                                </div>
                                                <button v-if="btn_send" type="button" <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}--> id="TencentCaptcha" data-appid="{$_G['cache']['plugin']['jzsjiale_isms']['g_captchaappid']}" data-cbfn="tencentCaptchaCallback"<!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->id="TencentCaptcha" data-appid="{$_G['cache']['plugin']['jzsjiale_isms']['g_captchaappid']}" data-cbfn="cloudTencentCaptchaCallback"<!--{/if}-->
                                                @click="sendSeccode" :disabled="err_phone || !ISMSFormItem.phone"
                                                class="JButton ISMSForm-sendseccodeButton Button--plain">
                                                {lang jzsjiale_isms:btn_sendseccode}
                                                </button>
                                                <button v-else type="button" disabled class="JButton ISMSForm-sendseccodeButton Button--plain">
                                                    {{ countdown }} {lang jzsjiale_isms:btn_sendseccode_countdown}
                                                </button>
                                            </div>
                                        </div>
                                        <div class="ISMSForm-Login-type">
                                            <!--{if in_array('mima', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pclogintype']))}-->
                                            <a href="member.php?mod=logging&action=login&logintype=mima" target="_self" class="JButton ISMSForm-Login-Type Button--plain">
                                                {lang jzsjiale_isms:tip_btn_loginmima}
                                            </a>
                                            <!--{elseif in_array('mimahaiwai', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pclogintype']))}-->
                                            <a href="member.php?mod=logging&action=login&logintype=mimahaiwai" target="_self" class="JButton ISMSForm-Login-Type Button--plain">
                                                {lang jzsjiale_isms:tip_btn_loginmimahaiwai}
                                            </a>
                                            <!--{/if}-->
                                            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_openpczhaohui']}-->
                                            <a href="member.php?mod=lostpasswd" target="_self" class="JButton ISMSForm-Forgot-Password Button--plain">
                                                {lang jzsjiale_isms:tip_btn_forgotpassword}
                                            </a>
                                            <!--{/if}-->
                                        </div>
                                        <!--{if in_array('logincookietime', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pcdetailed']))}-->
                                        <div class="ISMSPage-footer">
                                          <span class="ISMSPage-declaration">
                                              <Checkbox v-model="cookietime_ckb" @click="cookietime_ckb = !cookietime_ckb" @on-change="handleChangeCookietimeCKB">{lang jzsjiale_isms:tip_login_cookietime}</Checkbox>
                                          </span>
                                        </div>
                                        <!--{/if}-->
                                        <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton">
                                            {lang jzsjiale_isms:btn_login}
                                        </button>
                                    </i-form>
                                </template>
                                <!--{if $jsms_muban_pc['isshowsocial']}-->
                                <div class="ISMSPage-footer-social">
                                    <span class="ISMSPage-social-login">
                                       <!--{if $jsms_muban_pc['socialtip']}-->
                                        {$jsms_muban_pc['socialtip']}
                                        <!--{else}-->
                                        {lang jzsjiale_isms:tip_social_login}
                                        <!--{/if}-->
                                    </span>
                                    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/social')}

                                </div>
                                <!--{/if}-->
                            </div>
                        </div>
                        <div class="ISMSPage-loginbtn" onclick="javascript:window.location.href='member.php?mod={$_G[setting][regname]}';">
                            {lang jzsjiale_isms:tip_btn_meiyouzhanghao}<span>{lang jzsjiale_isms:tip_btn_register}</span>
                        </div>
                        <!--{if $jsms_muban_pc['isshowappdownloadbtn']}-->
                        <div v-if="now_show_qrImage" class="ISMSPage-qrImage" :class="{ 'ISMSPage-qrImage-show' : now_show_qrImage }">
                            <div class="ISMSPage-qrImageContent">
                                {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/qrimage_carousel')}
                            </div>
                        </div>
                        <!--{/if}-->
                        <!--{if !empty($jsms_muban_pc['weixintype']) && $jsms_muban_pc['weixintype'] != 'diy'}-->
                        <div v-if="now_show_wechat" class="ISMSPage-qrImage" :class="{ 'ISMSPage-qrImage-show' : now_show_wechat }">
                            <div class="ISMSPage-wechatContent" style="background-color: #ffffff;">
                                <div class="jzsjiale_isms_wechat_title">
                                    <svg class="icon" aria-hidden="true">
                                        <use xlink:href="#icon-weixin4"></use>
                                    </svg>
                                    <span class="jzsjiale_isms_wechat_title_font">
                                {lang jzsjiale_isms:tip_wechat_login}
                            </span>
                                </div>
                                <div id="wechatroot" ref="wechatroot"></div>
                                <div class="jzsjiale_isms_wechat_scan">
                                    <svg class="icon" aria-hidden="true">
                                        <use xlink:href="#icon-saoyisao"></use>
                                    </svg>
                                    <span class="jzsjiale_isms_wechat_scan_font">
                                {lang jzsjiale_isms:tip_wechat_login_bottom}
                            </span>
                                </div>
                            </div>
                        </div>
                        <!--{/if}-->
                        <!--{if !empty($jsms_muban_pc['apptype']) && $jsms_muban_pc['apptype'] != 'none'}-->
                        <div v-if="now_show_app" class="ISMSPage-qrImage" :class="{ 'ISMSPage-qrImage-show' : now_show_app }">
                            <div class="ISMSPage-wechatContent" style="background-color: #ffffff;">
                                <div class="jzsjiale_isms_wechat_title">
                                    <svg class="icon" aria-hidden="true">
                                        <use xlink:href="#icon-saoyisao"></use>
                                    </svg>
                                    <span class="jzsjiale_isms_wechat_title_font">
                                        {lang jzsjiale_isms:social_app_title1}<span style="color:#ff444c;">&nbsp;{$jsms_muban_pc['apptitle']}&nbsp;</span>{lang jzsjiale_isms:social_app_title2}
                                    </span>
                                </div>
                                <div id="approot" ref="approot"></div>
                                <div class="jzsjiale_isms_wechat_scan">
                                    <span v-if="app_retcode == 202" class="jzsjiale_isms_wechat_scan_font" style="color:green;">
                                        {lang jzsjiale_isms:social_app_ret_202}
                                    </span>
                                    <span v-else-if="app_retcode == 203" class="jzsjiale_isms_wechat_scan_font" style="color:green;">
                                        {lang jzsjiale_isms:social_app_ret_203}
                                    </span>
                                    <span v-else-if="app_retcode == 204" class="jzsjiale_isms_wechat_scan_font" style="color:green;">
                                        {lang jzsjiale_isms:social_app_ret_204}
                                    </span>
                                </div>
                                <div class="jzsjiale_isms_wechat_scan" @click="applogin()" style="cursor: pointer;">
                                    <span class="jzsjiale_isms_wechat_scan_font">
                                        {lang jzsjiale_isms:social_close}
                                    </span>
                                </div>
                            </div>
                        </div>
                        <!--{/if}-->
                    </div>
                </div>
                <!--{if $jsms_muban_pc['isshowappdownloadbtn']}-->
                <button type="button" v-if="!now_show_qrImage" @click="now_show_qrImage = true" class="JButton jzsjiale_isms_page_appdownloadBtn">{$jsms_muban_pc['appdownloadtitle']}</button>
                <button type="button" v-else @click="now_show_qrImage = false" class="JButton jzsjiale_isms_page_appdownloadBtn">{$jsms_muban_pc['appdownloadclosetitle']}</button>
                <!--{/if}-->
            </div>
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/footer_content')}
        </div>
    </main>
</div>
<!--{if in_array('logincookietime', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pcdetailed']))}-->
<style type="text/css">
    .ISMSForm-submitButton{
        margin-top: 10px!important;
    }
</style>
<!--{/if}-->
<script>
    new Vue({
        el: '#jzsjiale_isms_login_root',
        data: {
            ISMSFormItem: {
                areacode: '86',
                phone: '',
                seccode: ''
            },
            areacodeList:{
                allareacodeList:[],
                commonareacodeList:[]
            },
            err_phone: false,
            msg_phone: "",
            err_seccode: false,
            msg_seccode: "",
            btn_send: true,
            <!--{if !empty($jsms_muban_pc['weixintype']) && $jsms_muban_pc['weixintype'] != 'diy'}-->
            wechatbtnimg: "wechat.svg",
            now_show_wechat: false,
            wechat_checkST: null,
            wechat_checkCount: 0,
            <!--{/if}-->
            <!--{if !empty($jsms_muban_pc['apptype']) && $jsms_muban_pc['apptype'] != 'none'}-->
            now_show_app: false,
            app_checkST: null,
            app_checkCount: 0,
            app_retcode: 0,
            <!--{/if}-->
            now_show_qrImage: false,
            <!--{if in_array('logincookietime', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pcdetailed']))}-->
            <!--{if in_array('autologincookietime', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pcdetailed']))}-->
            cookietime_ckb: true,
            cookietime: 2592000,
            <!--{else}-->
            cookietime_ckb: false,
            cookietime: 0,
            <!--{/if}-->
            <!--{else}-->
            cookietime: 2592000,
            <!--{/if}-->
            countdown: 60,
            referer: '{eval echo strpos($dreferer,"jzsjiale_isms:security") !== false ? "plugin.php?id=jzsjiale_isms:security" : $dreferer;}'
        },
        beforeCreate(){
            let _this = this;
            //j_z_s_j_i_a_l_e_i_s_m_s_a_p_i
            axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                module: 'areacode',
                version: 1,
                formhash:'{FORMHASH}'
            }))
                .then(function (response) {

                    if(response['data']['code'] != 0){
                        _this.areacodeList.allareacodeList = response['data']['data'];
                        _this.areacodeList.commonareacodeList = response['data']['data'];

                        _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                    }else{
                        _this.areacodeList.allareacodeList = response['data']['data']['allareacode'];
                        _this.areacodeList.commonareacodeList = response['data']['data']['commonareacode'];
                    }
                })
                .catch(function (error) {
                    //console.log(error);
                    _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                });
        },
        computed: {
            size_phone: function () {
                let _this = this;
                return (_this.ISMSFormItem.areacode == '86' || _.isEmpty(_this.ISMSFormItem.areacode)) ? 11 : '';
            }
        },
        <!--{if $jsms_muban_pc['isshowappdownloadbtn'] && !empty($jsms_muban_pc['weixintype']) && $jsms_muban_pc['weixintype'] != 'diy'}-->
        watch: {
            now_show_wechat: function (val) {
                let _this = this;
                if(val == true && _this.now_show_qrImage == true){
                    _this.now_show_qrImage = false;
                }
                if(val == true && _this.now_show_app == true){
                    _this.now_show_app = false;
                }
            },
            now_show_qrImage: function (val) {
                let _this = this;
                if(val == true && _this.now_show_wechat == true){
                    _this.now_show_wechat = false;
                    _this.wechatbtnimg = "wechat.svg";
                    _this.wechat_checkST = null;
                    _this.wechat_checkCount = 0;
                }
                if(val == true && _this.now_show_app == true){
                    _this.now_show_app = false;
                }
            }
        },
        <!--{/if}-->
        mounted() {
            let _this = this;
            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
            window.tencentCaptchaCallback = _this.tencentCaptchaCallback;
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
            window.vaptchaCallback = _this.vaptchaCallback;
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
            window.cloudTencentCaptchaCallback = _this.cloudTencentCaptchaCallback;
            <!--{/if}-->
        },
        created() {
            let _this = this;
            if(!_.isEmpty(_.cookie.get("isms_phone"))){
                _this.ISMSFormItem.phone = _.cookie.get("isms_phone");
            }
            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_defaultareacode'] != ""}-->
                _this.ISMSFormItem.areacode = "{$_G['cache']['plugin']['jzsjiale_isms']['g_defaultareacode']}";
            <!--{/if}-->
            <!--{if $jsms_muban_pc['defaultweixin'] == '1'}-->
            _this.wechatlogin();
            <!--{elseif $jsms_muban_pc['defaultweixin'] == '2'}-->
            _this.applogin();
            <!--{/if}-->
        },
        methods: {
            handleSubmit: function () {
                let _this = this;
                _this.loginPhoneVerify();
                _this.loginSeccodeVerify();
                if(_this.err_phone || _this.err_seccode){
                    return false;
                }
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'login',
                    version: 1,
                    loginsubmit: 'yes',
                    discode: '32563',
                    areacode: _this.ISMSFormItem.areacode,
                    phone: _this.ISMSFormItem.phone,
                    seccode: _this.ISMSFormItem.seccode,
                    formhash:'{FORMHASH}',
                    logintype: 'seccode',
                    device: 'pc',
                    cookietime: _this.cookietime,
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            if(response['data']['msg'] == 'msg_err_register_ctrl'){
                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_register_ctrl1']+response['data']['data']['regctrl']+jzsjiale_lang['msg_err_register_ctrl2'],
                                    duration: 10
                                });
                            }else if(response['data']['msg'] == 'msg_err_register_flood_ctrl'){
                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_register_flood_ctrl1']+response['data']['data']['regfloodctrl']+jzsjiale_lang['msg_err_register_flood_ctrl2'],
                                    duration: 10
                                });
                            }else{
                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                            }

                        }else{
                            if(response['data']['msg'] == 'msg_err_location_login_outofdate'){

                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_location_login_outofdate'],
                                    duration: 10
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'plugin.php?id=jzsjiale_isms:security&op=needverify';
                                window.location.href = url_forward;
                            }else if(response['data']['msg'] == 'msg_err_location_login_password_tooshort'){

                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_location_login_password_tooshort'],
                                    duration: 10
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'plugin.php?id=jzsjiale_isms:security&op=changepassword';
                                window.location.href = url_forward;
                            }else if(response['data']['msg'] == 'msg_err_location_login_differentplaces'){

                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_location_login_differentplaces'],
                                    duration: 10
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'plugin.php?id=jzsjiale_isms:security&op=needverify';
                                window.location.href = url_forward;
                            }else if(response['data']['msg'] == 'msg_err_location_login_needverify'){

                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_location_login_needverify'],
                                    duration: 10
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'plugin.php?id=jzsjiale_isms:security&op=needverify';
                                window.location.href = url_forward;
                            }else{
                                _this.${Message}.success({
                                    content: jzsjiale_lang['msg_login_success'],
                                    duration: 10
                                });
                                _.cookie.remove("isms_phone");
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'{$_G["siteurl"]}';
                                window.location.href = url_forward;
                            }

                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            togglePhoneStatus: function () {
                let _this = this;
                _this.loginPhoneVerify();

            },
            toggleSeccodeStatus: function () {
                let _this = this;
                _this.loginSeccodeVerify();
            },
            sendSeccode: function(){
                let _this = this;
                _this.loginPhoneVerify();
                if(_this.err_phone){
                    return false;
                }

                <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 0}-->
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'notverify',
                    version: 1,
                    areacode: _this.ISMSFormItem.areacode,
                    phone: _this.ISMSFormItem.phone,
                    type: 3,
                    formhash:'{FORMHASH}'
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                        }else{

                            _this.btn_send = false;

                            let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                            sendsmsjiange = parseInt(sendsmsjiange);
                            if(sendsmsjiange != "" && sendsmsjiange > 60){
                                _this.countdown = sendsmsjiange;
                            }else{
                                _this.countdown = 60;
                            }

                            let auth_timetimer =  setInterval(()=>{
                                _this.countdown--;
                                if(_this.countdown<=0){
                                    _this.btn_send = true;
                                    clearInterval(auth_timetimer);
                                }
                            }, 1000);

                            _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
                <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
                let isms_v = new ISMSVD("{$_G['cache']['plugin']['jzsjiale_isms']['g_captchaappid']}", null, 'invisible', "{$_G['cache']['plugin']['jzsjiale_isms']['g_captchascene']}","/{JZSJIALE_ISMS_PLUGIN_API}&module=vaptchaofflineverify&version=1&formhash={FORMHASH}");
                isms_v.initVaptcha();
                <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 4}-->
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'startgeetestverify',
                    version: 1,
                    clienttype: 'web',
                    t: (new Date()).getTime(),
                    formhash:'{FORMHASH}'
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                        }else{

                            initGeetest({
                                gt: response['data']['data']['gt'],
                                challenge: response['data']['data']['challenge'],
                                new_captcha: response['data']['data']['new_captcha'],
                                offline: !response['data']['data']['success'],
                                product: 'bind'
                            }, function(captchaObj){
                                captchaObj.onReady(function(){
                                    captchaObj.verify();
                                }).onSuccess(function(){
                                    //_this.${Message}.success(jzsjiale_lang['msg_captcha_success']);
                                    axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                                        module: 'geetestverify',
                                        version: 1,
                                        geetest_challenge: captchaObj.getValidate().geetest_challenge,
                                        geetest_validate: captchaObj.getValidate().geetest_validate,
                                        geetest_seccode: captchaObj.getValidate().geetest_seccode,
                                        areacode: _this.ISMSFormItem.areacode,
                                        phone: _this.ISMSFormItem.phone,
                                        type: 3,
                                        clienttype: 'web',
                                        t: (new Date()).getTime(),
                                        formhash:'{FORMHASH}'
                                    }))
                                        .then(function (response) {
                                            //console.log(response['data']);
                                            if(response['data']['code'] != 0){
                                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                                            }else{

                                                _this.btn_send = false;

                                                let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                                                sendsmsjiange = parseInt(sendsmsjiange);
                                                if(sendsmsjiange != "" && sendsmsjiange > 60){
                                                    _this.countdown = sendsmsjiange;
                                                }else{
                                                    _this.countdown = 60;
                                                }

                                                let auth_timetimer =  setInterval(()=>{
                                                    _this.countdown--;
                                                    if(_this.countdown<=0){
                                                        _this.btn_send = true;
                                                        clearInterval(auth_timetimer);
                                                    }
                                                }, 1000);

                                                _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                                            }

                                        })
                                        .catch(function (error) {
                                            //console.log(error);
                                            _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                                        });
                                }).onClose(function () {
                                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                                }).onError(function(){
                                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                                });
                            });
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
                <!--{/if}-->
            },
            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
            tencentCaptchaCallback: function (res) {
                let _this = this;

                if(res.ret === 0 && !_.isEmpty(res.ticket) && !_.isEmpty(res.randstr)){
                    axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                        module: 'ticketverify',
                        version: 1,
                        ticket: res.ticket,
                        randstr: res.randstr,
                        areacode: _this.ISMSFormItem.areacode,
                        phone: _this.ISMSFormItem.phone,
                        type: 3,
                        formhash:'{FORMHASH}'
                    }))
                        .then(function (response) {
                            //console.log(response['data']);
                            if(response['data']['code'] != 0){
                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                            }else{

                                _this.btn_send = false;

                                let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                                sendsmsjiange = parseInt(sendsmsjiange);
                                if(sendsmsjiange != "" && sendsmsjiange > 60){
                                    _this.countdown = sendsmsjiange;
                                }else{
                                    _this.countdown = 60;
                                }

                                let auth_timetimer =  setInterval(()=>{
                                    _this.countdown--;
                                    if(_this.countdown<=0){
                                        _this.btn_send = true;
                                        clearInterval(auth_timetimer);
                                    }
                                }, 1000);

                                _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                            }

                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                        });

                }else if(res.ret === 2){
                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                }else{
                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                }

            },
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
            vaptchaCallback: function (token) {
                let _this = this;

                if(!_.isEmpty(token)){
                    axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                        module: 'vaptchaverify',
                        version: 1,
                        token: token,
                        areacode: _this.ISMSFormItem.areacode,
                        phone: _this.ISMSFormItem.phone,
                        type: 3,
                        formhash:'{FORMHASH}'
                    }))
                        .then(function (response) {
                            //console.log(response['data']);
                            if(response['data']['code'] != 0){
                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                            }else{

                                _this.btn_send = false;

                                let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                                sendsmsjiange = parseInt(sendsmsjiange);
                                if(sendsmsjiange != "" && sendsmsjiange > 60){
                                    _this.countdown = sendsmsjiange;
                                }else{
                                    _this.countdown = 60;
                                }

                                let auth_timetimer =  setInterval(()=>{
                                    _this.countdown--;
                                    if(_this.countdown<=0){
                                        _this.btn_send = true;
                                        clearInterval(auth_timetimer);
                                    }
                                }, 1000);

                                _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                            }

                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                        });

                }else if(res.ret === 2){
                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                }else{
                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                }

            },
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
            cloudTencentCaptchaCallback: function (res) {
                let _this = this;

                if(res.ret === 0 && !_.isEmpty(res.ticket) && !_.isEmpty(res.randstr)){
                    axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                        module: 'cloudtencentverify',
                        version: 1,
                        ticket: res.ticket,
                        randstr: res.randstr,
                        areacode: _this.ISMSFormItem.areacode,
                        phone: _this.ISMSFormItem.phone,
                        type: 3,
                        formhash:'{FORMHASH}'
                    }))
                        .then(function (response) {
                            //console.log(response['data']);
                            if(response['data']['code'] != 0){
                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                            }else{

                                _this.btn_send = false;

                                let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                                sendsmsjiange = parseInt(sendsmsjiange);
                                if(sendsmsjiange != "" && sendsmsjiange > 60){
                                    _this.countdown = sendsmsjiange;
                                }else{
                                    _this.countdown = 60;
                                }

                                let auth_timetimer =  setInterval(()=>{
                                    _this.countdown--;
                                    if(_this.countdown<=0){
                                        _this.btn_send = true;
                                        clearInterval(auth_timetimer);
                                    }
                                }, 1000);

                                _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                            }

                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                        });

                }else if(res.ret === 2){
                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                }else{
                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                }

            },
            <!--{/if}-->
            loginPhoneVerify: function(){
                let _this = this;
                if(_.isEmpty(_this.ISMSFormItem.areacode) || !_.isAreaCode(_this.ISMSFormItem.areacode)){
                    _this.err_phone = true;
                    _this.msg_phone = jzsjiale_lang['msg_areacode_error'];
                    return;
                }
                if(_.isEmpty(_this.ISMSFormItem.phone)){
                    _this.err_phone = true;
                    _this.msg_phone = jzsjiale_lang['msg_phone_empty'];
                    return;
                }else if(!_.isMobilePhone(_this.ISMSFormItem.areacode,_this.ISMSFormItem.phone)){
                    _this.err_phone = true;
                    _this.msg_phone = jzsjiale_lang['msg_phone_formaterror'];
                    return;
                }else{
                    _this.err_phone = false;
                    _this.msg_phone = "";
                    _.cookie.set("isms_phone",_this.ISMSFormItem.phone);
                    return;
                }
            },
            loginSeccodeVerify: function(){
                let _this = this;
                if(_.isEmpty(_this.ISMSFormItem.seccode)){
                    _this.err_seccode = true;
                    _this.msg_seccode = jzsjiale_lang['msg_seccode_empty'];
                    return;
                }else if(!_.isSeccode(_this.ISMSFormItem.seccode)){
                    _this.err_seccode = true;
                    _this.msg_seccode = jzsjiale_lang['msg_seccode_formaterror'];
                    return;
                }else{
                    _this.err_seccode = false;
                    _this.msg_seccode = "";
                    return;
                }
            },
            <!--{if !empty($jsms_muban_pc['weixintype']) && $jsms_muban_pc['weixintype'] != 'diy'}-->
            wechatlogin: function(){
                let _this = this;
                if(_this.wechat_checkST){
                    clearTimeout(_this.wechat_checkST);
                    _this.wechat_checkCount = 0;
                }
                if(_this.now_show_wechat == false){
                    _this.now_show_wechat = true;
                    _this.wechatbtnimg = "pc.png";

                    let wechaturl = "";
                    <!--{if $jsms_muban_pc['weixintype'] == 'xigua'}-->
                    wechaturl = 'plugin.php?id=xigua_login:login&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'comiis'}-->
                    wechaturl = 'plugin.php?id=comiis_weixin&mod=wxlogin&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'strong'}-->
                    wechaturl = 'plugin.php?id=strong_wxlogin:bind&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'weiqing'}-->
                    wechaturl = 'plugin.php?id=wq_login&mod=scan&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'zimucms'}-->
                    wechaturl = 'plugin.php?id=zimucms_weixin:bind&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'feiniao'}-->
                    wechaturl = 'plugin.php?id=fn_wx_login:Bind&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'pn'}-->
                    wechaturl = 'plugin.php?id=pn_wechat:bind&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'duceapp'}-->
                    wechaturl = 'source/plugin/duceapp_wechat/logging.php?ac=bind&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'kekewxlogin'}-->
                    wechaturl = 'plugin.php?id=keke_wxlogin:show_qrcode&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == '1314wxlogin'}-->
                    wechaturl = 'plugin.php?id=addon_wx_login&mod=usercp&ac=bind&inajax=1';
                    <!--{else}-->
                    _this.now_show_wechat = false;
                    <!--{/if}-->

                    axios.get(wechaturl)
                        .then(function (response) {
                            //console.log(response['data']);

                            let wxhtml = response['data'];
                            let imgurl_reg = /<img(.*?)src="(.*?)"(.*?)>/ig;
                            let imgurl = imgurl_reg.exec(wxhtml)[2];

                            let checkurl_reg = "";
                            let checkurl = "";
                            <!--{if $jsms_muban_pc['weixintype'] == 'zimucms'}-->
                            checkurl_reg = /var(.*?)checkUrl(.*?)\=(.*?)\'(.*?)\'/ig;
                            checkurl = checkurl_reg.exec(wxhtml)[4];
                            checkurl = checkurl + new Date().getTime();
                            <!--{elseif $jsms_muban_pc['weixintype'] == 'feiniao'}-->
                            checkurl_reg = /var(.*?)CheckUrl(.*?)\=(.*?)\'(.*?)\'/ig;
                            checkurl = checkurl_reg.exec(wxhtml)[4];
                            checkurl = checkurl + new Date().getTime();
                            <!--{else}-->
                            checkurl_reg = /x\.get\(\'(.*?)\'(.*?)\,(.*?)function/ig;
                            checkurl = checkurl_reg.exec(wxhtml)[1];
                            <!--{/if}-->

                            let innerhtml = '<div class="c" align="center" style="width:100%;height:100%;"><img width="220" height="220" src="'+imgurl+'"/></div>';
                            _this.${refs}.wechatroot.innerHTML = innerhtml;

                            function wechat_checkstart(){
                                _this.wechat_checkST = setTimeout(wechat_check, 2000);
                            }
                            function wechat_check(){
                                axios.get(checkurl)
                                    .then(function (response) {
                                        //console.log("ret:"+response['data']);
                                        let xmlDoc = null;
                                        if (window.DOMParser) {
                                            let parser = new DOMParser();
                                            xmlDoc = parser.parseFromString(response['data'], "text/xml");
                                        } else {
                                            //IE
                                            xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
                                            xmlDoc.async = "false";
                                            xmlDoc.loadXML(response['data']);
                                        }
                                        let check_s = '';

                                        _this.wechat_checkCount++;
                                        <!--{if $jsms_muban_pc['weixintype'] == 'xigua'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 100) {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'comiis'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s == '1'){
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }else if(_this.wechat_checkCount > 75){
                                            clearTimeout(_this.wechat_checkST);
                                            _this.now_show_wechat = false;
                                            _this.wechatlogin();
                                        }else{
                                            wechat_checkstart();
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'strong'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 100) {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'weiqing'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 12) {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'zimucms'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s == '1' || check_s == '2'){
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }else if(_this.wechat_checkCount > 50){
                                            clearTimeout(_this.wechat_checkST);
                                            _this.now_show_wechat = false;
                                            _this.wechatlogin();
                                        }else{
                                            wechat_checkstart();
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'feiniao'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s == '1' || check_s == '2'){
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }else if(_this.wechat_checkCount > 50){
                                            clearTimeout(_this.wechat_checkST);
                                            _this.now_show_wechat = false;
                                            _this.wechatlogin();
                                        }else{
                                            wechat_checkstart();
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'pn'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 12) {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'duceapp'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1' || check_s == '2') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 60 || (_this.wechat_checkCount > 1 && check_s == '-2')) {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer + (_this.referer.indexOf('?') != -1 ? '&' : '?') + 'wxlogin=1';
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'kekewxlogin'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 12) {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == '1314wxlogin'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 20 || check_s == '-1' || check_s == '-2' || check_s == '2') {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{else}-->
                                        _this.now_show_wechat = false;
                                        clearTimeout(_this.wechat_checkST);
                                        _this.wechat_checkCount = 0;
                                        _this.wechatbtnimg = "wechat.svg";
                                        <!--{/if}-->
                                    })
                                    .catch(function (error) {
                                        //console.log(error);
                                        _this.${Message}.error('error');
                                    })
                            }

                            wechat_checkstart();
                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error('error');
                        });

                    return;
                }else{
                    _this.now_show_wechat = false;
                    clearTimeout(_this.wechat_checkST);
                    _this.wechat_checkCount = 0;
                    _this.wechatbtnimg = "wechat.svg";
                    return;
                }

            },
            <!--{/if}-->
            <!--{if !empty($jsms_muban_pc['apptype']) && $jsms_muban_pc['apptype'] != 'none'}-->
            applogin: function(){
                let _this = this;
                if(_this.app_checkST){
                    clearTimeout(_this.app_checkST);
                    _this.app_checkCount = 0;
                }
                if(_this.now_show_app == false){
                    _this.now_show_app = true;

                    let appurl = "";
                    <!--{if $jsms_muban_pc['apptype'] == 'zimu'}-->
                    appurl = 'plugin.php?id=zimucms_appscan&model=pcqrcode&inajax=1';
                    <!--{elseif $jsms_muban_pc['apptype'] == 'duceapp'}-->
                    appurl = 'plugin.php?id=duceapp_mpscan&ac=qrcode&inajax=1';
                    <!--{else}-->
                    _this.now_show_app = false;
                    <!--{/if}-->

                    axios.get(appurl)
                        .then(function (response) {
                            //console.log(response['data']);

                            let wxhtml = response['data'];
                            let imgurl_reg = /<img(.*?)src="(.*?)"(.*?)>/ig;
                            let imgurl = imgurl_reg.exec(wxhtml)[2];

                            let checkurl_reg = "";
                            let checkurl = "";
                            <!--{if $jsms_muban_pc['apptype'] == 'zimu'}-->
                            checkurl_reg = /document\.getElementById\(\'checkhashpcurl\'\)\.value(.*?)\=(.*?)\'(.*?)\'/ig;
                            checkurl = checkurl_reg.exec(wxhtml)[3];
                            <!--{elseif $jsms_muban_pc['apptype'] == 'duceapp'}-->
                            checkurl_reg = /x\.get\(\'(.*?)\'(.*?)\,(.*?)function/ig;
                            checkurl = checkurl_reg.exec(wxhtml)[1];
                            <!--{/if}-->

                            let innerhtml = '<div class="c" align="center" style="width:100%;height:100%;"><img width="220" height="220" src="'+imgurl+'"/></div>';
                            _this.${refs}.approot.innerHTML = innerhtml;

                            function app_checkstart(){
                                _this.app_checkST = setTimeout(app_check, 2000);
                            }
                            function app_check(){
                                axios.get(checkurl)
                                    .then(function (response) {
                                        //console.log("ret:"+response['data']);

                                        let xmlDoc = null;
                                        <!--{if $jsms_muban_pc['apptype'] == 'duceapp'}-->
                                        if (window.DOMParser) {
                                            let parser = new DOMParser();
                                            xmlDoc = parser.parseFromString(response['data'], "text/xml");
                                        } else {
                                            //IE
                                            xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
                                            xmlDoc.async = "false";
                                            xmlDoc.loadXML(response['data']);
                                        }
                                        <!--{/if}-->

                                        let check_s = '';

                                        _this.app_checkCount++;
                                        <!--{if $jsms_muban_pc['apptype'] == 'zimu'}-->
                                        check_s = response['data'];
                                        if(check_s != '200') {
                                            _this.app_retcode = check_s;
                                            if(check_s == '201' || check_s == '202') {
                                                app_checkstart();
                                            }else if(check_s == '203') {
                                                _this.now_show_app = false;
                                                clearTimeout(_this.app_checkST);
                                                _this.app_checkCount = 0;
                                            }else if(check_s == '204') {
                                                clearTimeout(_this.app_checkST);
                                                _this.now_show_app = false;
                                                _this.applogin();
                                            }
                                        } else {
                                            clearTimeout(_this.app_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{elseif $jsms_muban_pc['apptype'] == 'duceapp'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1' || check_s == '2') {
                                                app_checkstart();
                                            }
                                            if(check_s == '2') {
                                                _this.app_retcode = 202;
                                            }
                                            if(_this.app_checkCount >= 24 || (_this.app_checkCount > 1 && check_s == '-2')) {
                                                clearTimeout(_this.app_checkST);
                                                _this.now_show_app = false;
                                                _this.applogin();
                                            }
                                        } else {
                                            clearTimeout(_this.app_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{else}-->
                                        _this.now_show_app = false;
                                        clearTimeout(_this.app_checkST);
                                        _this.app_checkCount = 0;
                                        <!--{/if}-->
                                    })
                                    .catch(function (error) {
                                        //console.log(error);
                                        _this.${Message}.error('error');
                                    })
                            }

                            app_checkstart();
                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error('error');
                        });

                    return;
                }else{
                    _this.now_show_app = false;
                    clearTimeout(_this.app_checkST);
                    _this.app_checkCount = 0;
                    return;
                }

            },
            <!--{/if}-->
            <!--{if in_array('logincookietime', (array) unserialize($_G['cache']['plugin']['jzsjiale_isms']['g_pcdetailed']))}-->
            handleChangeCookietimeCKB: function() {
                let _this = this;
                if(_this.cookietime_ckb){
                    _this.cookietime = 2592000;
                }else{
                    _this.cookietime = 0;
                }
            }
            <!--{/if}-->
        }
    })
</script>
<!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
<script>
    window.callback = function(res){
        //console.log(res);
        tencentCaptchaCallback(res);
    }
</script>
<!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
<script>
    window.callback = function(token){
        //console.log(res);
        vaptchaCallback(token);
    }
</script>
<!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
<script>
    window.callback = function(res){
        //console.log(res);
        cloudTencentCaptchaCallback(res);
    }
</script>
<!--{/if}-->
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/footer')}