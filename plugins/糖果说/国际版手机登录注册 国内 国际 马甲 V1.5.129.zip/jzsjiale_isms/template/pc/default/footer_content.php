<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<footer class="jzs-jiale-isms-footer-content">
    <!--{if $jsms_muban_pc['footerlinks']}-->
    <!--{eval $footerlinks = explode(',',$jsms_muban_pc['footerlinks']);}-->
    <!--{eval $footerlinksarr = array();}-->
    <!--{eval foreach($footerlinks as $ftl) {}-->
    <!--{eval   if(!empty(explode('|',$ftl)[0]) && !empty(explode('|',$ftl)[1])) $footerlinksarr[] = explode('|',$ftl);}-->
    <!--{eval }}-->
    <div class="jzsjia-le-isms-footer-links">
        <!--{eval foreach($footerlinksarr as $ftla) {}-->
        <a target="_blank" rel="noopener noreferrer" href="<!--{eval echo $ftla[1];}-->"><!--{eval echo $ftla[0];}--></a>
        <!--{eval }}-->
    </div>
    <!--{/if}-->
    <!--{if $jsms_muban_pc['footercopyright']}-->
    <div class="jzsjiale-isms-footer-copyright">
        <span>
        {$jsms_muban_pc['footercopyright']}
        </span>
    </div>
    <!--{/if}-->
    <!--{if $jsms_muban_pc['footerother']}-->
    <div class="jzsjiale-isms-footer-other">
        <span>
        {$jsms_muban_pc['footerother']}
        </span>
    </div>
    <!--{/if}-->
</footer>