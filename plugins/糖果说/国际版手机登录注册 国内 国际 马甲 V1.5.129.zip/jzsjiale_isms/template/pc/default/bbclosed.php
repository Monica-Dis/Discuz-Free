<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/header')}
<div id="jzsjiale_isms_login_root">
    <main class="jzs_jiale_i_sms_login_main">
        <div class="jzsjiale_i_sms_main_page">
            <div class="jzsjiale_isms_login_content">

                <div class="JCard jzsjiale_isms_main_content">
                    <div class="jzsjiale_isms_main_content_header">

                        <div class="jzsjiale_isms_main_content_header_title">
                            <!--{if $jsms_muban_pc['title']}-->
                            {$jsms_muban_pc['title']}
                            <!--{elseif $jsms_muban_pc['logo']}-->
                            <img src="{$jsms_muban_pc['logo']}" class="jzsjiale_isms_main_content_header_title_img"/>
                            <!--{else}-->
                            {lang jzsjiale_isms:title_and_logo_null}
                            <!--{/if}-->
                        </div>
                        <div class="jzsjiale_isms_main_content_header_desc">
                            {$jsms_muban_pc['logindesc']}
                        </div>
                    </div>
                    <div class="jzsjiale_isms_main_content_inner">
                        <div class="ISMSPage">
                            <div class="ISMSPage_content">
                                <template>
                                    <div class="ISMSForm-bbclosed">
                                        <!--{if $closedreason = C::t('common_setting')->fetch('closedreason')}-->
                                        <h3 class="ISMSForm-bbclosed-title">{$closedreason}</h3>
                                        <!--{else}-->
                                        <h3 class="ISMSForm-bbclosed-title">{lang jzsjiale_isms:tip_bbclosed_title}</h3>
                                        <!--{/if}-->
                                        <img src="{JZSJIALE_ISMS_PLUGIN_TEMPLATE_PC_PATH}/default/style/images/weihu.png" class="jzsjiale_isms_img_closed"/>

                                    </div>
                                </template>
                            </div>
                        </div>

                        <!--{if $jsms_muban_pc['isshowappdownloadbtn']}-->
                        <div v-if="now_show_qrImage" class="ISMSPage-qrImage" :class="{ 'ISMSPage-qrImage-show' : now_show_qrImage }">
                            <div class="ISMSPage-qrImageContent">
                                {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/qrimage_carousel')}
                            </div>
                        </div>
                        <!--{/if}-->

                    </div>
                </div>
                <!--{if $jsms_muban_pc['isshowappdownloadbtn']}-->
                <button type="button" v-if="!now_show_qrImage" @click="now_show_qrImage = true" class="JButton jzsjiale_isms_page_appdownloadBtn">{$jsms_muban_pc['appdownloadtitle']}</button>
                <button type="button" v-else @click="now_show_qrImage = false" class="JButton jzsjiale_isms_page_appdownloadBtn">{$jsms_muban_pc['appdownloadclosetitle']}</button>
                <!--{/if}-->
            </div>
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/footer_content')}
        </div>
    </main>
</div>

<script>
    new Vue({
        el: '#jzsjiale_isms_login_root',
        data: {
            now_show_qrImage: false
        },
        methods: {

        }
    })
</script>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/footer')}