<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/header')}
<div id="jzsjiale_isms_lostpasswd_root">
    <main class="jzs_jiale_i_sms_lostpasswd_main">
        <div class="jzsjiale_i_sms_main_page">
            <div class="jzsjiale_isms_login_content">

                <div class="JCard jzsjiale_isms_main_content">
                    <div class="jzsjiale_isms_main_content_header">
                        <!--{if !empty($jsms_muban_pc['weixintype']) && $jsms_muban_pc['weixintype'] != 'diy'}-->
                        <a href="javascript:;" @click="wechatlogin()" class="wechat" :style="{background:'url(source/plugin/jzsjiale_isms/template/pc/default/style/images/'+wechatbtnimg+') no-repeat top right'}"></a>
                        <!--{if !empty($jsms_muban_pc['weixintypetip']) || $jsms_muban_pc['weixintypetip'] != 0}-->
                        <span v-if="now_show_wechat == false" class="wechatlogin_tip">
                                <!--{if $jsms_muban_pc['weixintypetip'] == 1}-->
                                <svg class="icon" aria-hidden="true">
                                            <use xlink:href="#icon-weixin4"></use>
                                </svg>
                            <!--{/if}-->
                                {lang jzsjiale_isms:tip_wechat_login}
                            </span>
                        <span v-else class="accountlogin_tip">
                                <!--{if $jsms_muban_pc['weixintypetip'] == 1}-->
                                <svg class="icon" aria-hidden="true">
                                            <use xlink:href="#icon-shouji"></use>
                                </svg>
                            <!--{/if}-->
                                {lang jzsjiale_isms:tip_accountlogin_tip}
                            </span>
                        <!--{/if}-->
                        <!--{/if}-->
                        <div class="jzsjiale_isms_main_content_header_title">
                            <!--{if $jsms_muban_pc['title']}-->
                            {$jsms_muban_pc['title']}
                            <!--{elseif $jsms_muban_pc['logo']}-->
                            <img src="{$jsms_muban_pc['logo']}" class="jzsjiale_isms_main_content_header_title_img"/>
                            <!--{else}-->
                            {lang jzsjiale_isms:title_and_logo_null}
                            <!--{/if}-->
                        </div>
                        <div class="jzsjiale_isms_main_content_header_desc">
                            {$jsms_muban_pc['lostpasswddesc']}
                        </div>
                    </div>
                    <div class="jzsjiale_isms_main_content_inner">
                        <div class="ISMSPage">
                            <div class="ISMSPage_content">
                                <template>
                                    <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>
                                        <div class="ISMSForm-common">
                                            <div class="ISMSFormInput ISMSForm-commonInputContainer">
                                                <div class="Input-wrapper">
                                                    <Input type="text" @input="toggleEmailStatus()" @focus="err_email = false" @blur="toggleEmailStatus()" v-model="ISMSFormItem.email" name="email" class="JInput" placeholder="{lang jzsjiale_isms:tip_lostpasswd_email}"/>
                                                </div>
                                                <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_email }">
                                                    {{ msg_email }}
                                                </div>
                                            </div>

                                        </div>
                                        <div class="ISMSForm-common">
                                            <div class="ISMSFormInput ISMSForm-commonInputContainer">
                                                <div class="Input-wrapper">
                                                    <Input type="text" v-model="ISMSFormItem.username" name="username" class="JInput" placeholder="{lang jzsjiale_isms:tip_lostpasswd_username}"/>
                                                </div>
                                                <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask ISMSFormInput-errorMask-hidden">

                                                </div>
                                            </div>

                                        </div>
                                        <!--{if in_array($_G['cache']['plugin']['jzsjiale_isms']['g_openpczhaohui'],array('3','4'))}-->
                                        <div class="ISMSForm-Login-type">

                                            <a href="member.php?mod={$_G[setting][regname]}" target="_self" class="JButton ISMSForm-Login-Type Button--plain">
                                                {lang jzsjiale_isms:tip_btn_register_account}
                                            </a>

                                            <a href="member.php?mod=lostpasswd&type=mobile" target="_self" class="JButton ISMSForm-Forgot-Password Button--plain">
                                                {lang jzsjiale_isms:tip_btn_forgotpassword_mobile}
                                            </a>

                                        </div>
                                        <!--{/if}-->
                                        <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton">
                                            {lang jzsjiale_isms:btn_lostpasswd}
                                        </button>
                                    </i-form>
                                </template>
                                <!--{if $jsms_muban_pc['isshowsocial']}-->
                                <div class="ISMSPage-footer-social">
                                    <span class="ISMSPage-social-login">
                                       <!--{if $jsms_muban_pc['socialtip']}-->
                                        {$jsms_muban_pc['socialtip']}
                                        <!--{else}-->
                                        {lang jzsjiale_isms:tip_social_login}
                                        <!--{/if}-->
                                    </span>
                                    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/social')}

                                </div>
                                <!--{/if}-->
                            </div>
                        </div>
                        <div class="ISMSPage-loginbtn" onclick="javascript:window.location.href='member.php?mod=logging&action=login';">
                            {lang jzsjiale_isms:tip_btn_yiyouzhanghao}<span>{lang jzsjiale_isms:tip_btn_login}</span>
                        </div>
                        <!--{if $jsms_muban_pc['isshowappdownloadbtn']}-->
                        <div v-if="now_show_qrImage" class="ISMSPage-qrImage" :class="{ 'ISMSPage-qrImage-show' : now_show_qrImage }">
                            <div class="ISMSPage-qrImageContent">
                                {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/qrimage_carousel')}
                            </div>
                        </div>
                        <!--{/if}-->
                        <!--{if !empty($jsms_muban_pc['weixintype']) && $jsms_muban_pc['weixintype'] != 'diy'}-->
                        <div v-if="now_show_wechat" class="ISMSPage-qrImage" :class="{ 'ISMSPage-qrImage-show' : now_show_wechat }">
                            <div class="ISMSPage-wechatContent" style="background-color: #ffffff;">
                                <div class="jzsjiale_isms_wechat_title">
                                    <svg class="icon" aria-hidden="true">
                                        <use xlink:href="#icon-weixin4"></use>
                                    </svg>
                                    <span class="jzsjiale_isms_wechat_title_font">
                                {lang jzsjiale_isms:tip_wechat_login}
                            </span>
                                </div>
                                <div id="wechatroot" ref="wechatroot"></div>
                                <div class="jzsjiale_isms_wechat_scan">
                                    <svg class="icon" aria-hidden="true">
                                        <use xlink:href="#icon-saoyisao"></use>
                                    </svg>
                                    <span class="jzsjiale_isms_wechat_scan_font">
                                {lang jzsjiale_isms:tip_wechat_login_bottom}
                            </span>
                                </div>
                            </div>
                        </div>
                        <!--{/if}-->
                        <!--{if !empty($jsms_muban_pc['apptype']) && $jsms_muban_pc['apptype'] != 'none'}-->
                        <div v-if="now_show_app" class="ISMSPage-qrImage" :class="{ 'ISMSPage-qrImage-show' : now_show_app }">
                            <div class="ISMSPage-wechatContent" style="background-color: #ffffff;">
                                <div class="jzsjiale_isms_wechat_title">
                                    <svg class="icon" aria-hidden="true">
                                        <use xlink:href="#icon-saoyisao"></use>
                                    </svg>
                                    <span class="jzsjiale_isms_wechat_title_font">
                                        {lang jzsjiale_isms:social_app_title1}<span style="color:#ff444c;">&nbsp;{$jsms_muban_pc['apptitle']}&nbsp;</span>{lang jzsjiale_isms:social_app_title2}
                                    </span>
                                </div>
                                <div id="approot" ref="approot"></div>
                                <div class="jzsjiale_isms_wechat_scan">
                                    <span v-if="app_retcode == 202" class="jzsjiale_isms_wechat_scan_font" style="color:green;">
                                        {lang jzsjiale_isms:social_app_ret_202}
                                    </span>
                                    <span v-else-if="app_retcode == 203" class="jzsjiale_isms_wechat_scan_font" style="color:green;">
                                        {lang jzsjiale_isms:social_app_ret_203}
                                    </span>
                                    <span v-else-if="app_retcode == 204" class="jzsjiale_isms_wechat_scan_font" style="color:green;">
                                        {lang jzsjiale_isms:social_app_ret_204}
                                    </span>
                                </div>
                                <div class="jzsjiale_isms_wechat_scan" @click="applogin()" style="cursor: pointer;">
                                    <span class="jzsjiale_isms_wechat_scan_font">
                                        {lang jzsjiale_isms:social_close}
                                    </span>
                                </div>
                            </div>
                        </div>
                        <!--{/if}-->
                    </div>
                </div>
                <!--{if $jsms_muban_pc['isshowappdownloadbtn']}-->
                <button type="button" v-if="!now_show_qrImage" @click="now_show_qrImage = true" class="JButton jzsjiale_isms_page_appdownloadBtn">{$jsms_muban_pc['appdownloadtitle']}</button>
                <button type="button" v-else @click="now_show_qrImage = false" class="JButton jzsjiale_isms_page_appdownloadBtn">{$jsms_muban_pc['appdownloadclosetitle']}</button>
                <!--{/if}-->
            </div>
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/footer_content')}
        </div>
    </main>
</div>

<script>
    new Vue({
        el: '#jzsjiale_isms_lostpasswd_root',
        data: {
            ISMSFormItem: {
                email: '',
                username: ''
            },
            err_email: false,
            msg_email: "",
            <!--{if !empty($jsms_muban_pc['weixintype']) && $jsms_muban_pc['weixintype'] != 'diy'}-->
            wechatbtnimg: "wechat.svg",
            now_show_wechat: false,
            wechat_checkST: null,
            wechat_checkCount: 0,
            <!--{/if}-->
            <!--{if !empty($jsms_muban_pc['apptype']) && $jsms_muban_pc['apptype'] != 'none'}-->
            now_show_app: false,
            app_checkST: null,
            app_checkCount: 0,
            app_retcode: 0,
            <!--{/if}-->
            now_show_qrImage: false,
            referer: '{$dreferer}'
        },
        created() {
            let _this = this;

            <!--{if $jsms_muban_pc['defaultweixin'] == '1'}-->
            _this.wechatlogin();
            <!--{elseif $jsms_muban_pc['defaultweixin'] == '2'}-->
            _this.applogin();
            <!--{/if}-->
        },
        <!--{if $jsms_muban_pc['isshowappdownloadbtn'] && !empty($jsms_muban_pc['weixintype']) && $jsms_muban_pc['weixintype'] != 'diy'}-->
        watch: {
            now_show_wechat: function (val) {
                let _this = this;
                if(val == true && _this.now_show_qrImage == true){
                    _this.now_show_qrImage = false;
                }
                if(val == true && _this.now_show_app == true){
                    _this.now_show_app = false;
                }
            },
            now_show_qrImage: function (val) {
                let _this = this;
                if(val == true && _this.now_show_wechat == true){
                    _this.now_show_wechat = false;
                    _this.wechatbtnimg = "wechat.svg";
                    _this.wechat_checkST = null;
                    _this.wechat_checkCount = 0;
                }
                if(val == true && _this.now_show_app == true){
                    _this.now_show_app = false;
                }
            }
        },
        <!--{/if}-->
        methods: {
            handleSubmit: function () {
                let _this = this;
                _this.lostpasswdEmailVerify();
                if(_this.err_email){
                    return false;
                }
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'lostpasswdemail',
                    version: 1,
                    lostpasswdsubmit: 'yes',
                    discode: '32563',
                    email: _this.ISMSFormItem.email,
                    username: encodeURI(_this.ISMSFormItem.username),
                    formhash:'{FORMHASH}',
                    device: 'pc',
                    cookietime: 2592000,
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            _this.${Message}.error({
                                content: jzsjiale_lang[response['data']['msg']],
                                duration: 10
                            });
                        }else{
                            _this.${Message}.success({
                                content: jzsjiale_lang['msg_getpasswd_send_succeed'],
                                duration: 20
                            });
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            toggleEmailStatus: function () {
                let _this = this;
                _this.lostpasswdEmailVerify();
            },
            lostpasswdEmailVerify: function(){
                let _this = this;

                if(_.isEmpty(_this.ISMSFormItem.email)){
                    _this.err_email = true;
                    _this.msg_email = jzsjiale_lang['msg_email_empty'];
                    return;
                }else if(!_.isEmail(_this.ISMSFormItem.email)){
                    _this.err_email = true;
                    _this.msg_email = jzsjiale_lang['msg_email_format_error'];
                    return;
                }else{
                    _this.err_email = false;
                    _this.msg_email = "";
                    return;
                }

            },
            <!--{if !empty($jsms_muban_pc['weixintype']) && $jsms_muban_pc['weixintype'] != 'diy'}-->
            wechatlogin: function(){
                let _this = this;
                if(_this.wechat_checkST){
                    clearTimeout(_this.wechat_checkST);
                    _this.wechat_checkCount = 0;
                }
                if(_this.now_show_wechat == false){
                    _this.now_show_wechat = true;
                    _this.wechatbtnimg = "pc.png";

                    let wechaturl = "";
                    <!--{if $jsms_muban_pc['weixintype'] == 'xigua'}-->
                    wechaturl = 'plugin.php?id=xigua_login:login&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'comiis'}-->
                    wechaturl = 'plugin.php?id=comiis_weixin&mod=wxlogin&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'strong'}-->
                    wechaturl = 'plugin.php?id=strong_wxlogin:bind&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'weiqing'}-->
                    wechaturl = 'plugin.php?id=wq_login&mod=scan&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'zimucms'}-->
                    wechaturl = 'plugin.php?id=zimucms_weixin:bind&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'feiniao'}-->
                    wechaturl = 'plugin.php?id=fn_wx_login:Bind&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'pn'}-->
                    wechaturl = 'plugin.php?id=pn_wechat:bind&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'duceapp'}-->
                    wechaturl = 'source/plugin/duceapp_wechat/logging.php?ac=bind&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == 'kekewxlogin'}-->
                    wechaturl = 'plugin.php?id=keke_wxlogin:show_qrcode&inajax=1';
                    <!--{elseif $jsms_muban_pc['weixintype'] == '1314wxlogin'}-->
                    wechaturl = 'plugin.php?id=addon_wx_login&mod=usercp&ac=bind&inajax=1';
                    <!--{else}-->
                    _this.now_show_wechat = false;
                    <!--{/if}-->

                    axios.get(wechaturl)
                        .then(function (response) {
                            //console.log(response['data']);

                            let wxhtml = response['data'];
                            let imgurl_reg = /<img(.*?)src="(.*?)"(.*?)>/ig;
                            let imgurl = imgurl_reg.exec(wxhtml)[2];

                            let checkurl_reg = "";
                            let checkurl = "";
                            <!--{if $jsms_muban_pc['weixintype'] == 'zimucms'}-->
                            checkurl_reg = /var(.*?)checkUrl(.*?)\=(.*?)\'(.*?)\'/ig;
                            checkurl = checkurl_reg.exec(wxhtml)[4];
                            checkurl = checkurl + new Date().getTime();
                            <!--{elseif $jsms_muban_pc['weixintype'] == 'feiniao'}-->
                            checkurl_reg = /var(.*?)CheckUrl(.*?)\=(.*?)\'(.*?)\'/ig;
                            checkurl = checkurl_reg.exec(wxhtml)[4];
                            checkurl = checkurl + new Date().getTime();
                            <!--{else}-->
                            checkurl_reg = /x\.get\(\'(.*?)\'(.*?)\,(.*?)function/ig;
                            checkurl = checkurl_reg.exec(wxhtml)[1];
                            <!--{/if}-->

                            let innerhtml = '<div class="c" align="center" style="width:100%;height:100%;"><img width="220" height="220" src="'+imgurl+'"/></div>';
                            _this.${refs}.wechatroot.innerHTML = innerhtml;

                            function wechat_checkstart(){
                                _this.wechat_checkST = setTimeout(wechat_check, 2000);
                            }
                            function wechat_check(){
                                axios.get(checkurl)
                                    .then(function (response) {
                                        //console.log("ret:"+response['data']);
                                        let xmlDoc = null;
                                        if (window.DOMParser) {
                                            let parser = new DOMParser();
                                            xmlDoc = parser.parseFromString(response['data'], "text/xml");
                                        } else {
                                            //IE
                                            xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
                                            xmlDoc.async = "false";
                                            xmlDoc.loadXML(response['data']);
                                        }
                                        let check_s = '';

                                        _this.wechat_checkCount++;
                                        <!--{if $jsms_muban_pc['weixintype'] == 'xigua'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 100) {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'comiis'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s == '1'){
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }else if(_this.wechat_checkCount > 75){
                                            clearTimeout(_this.wechat_checkST);
                                            _this.now_show_wechat = false;
                                            _this.wechatlogin();
                                        }else{
                                            wechat_checkstart();
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'strong'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 100) {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'weiqing'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 12) {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'zimucms'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s == '1' || check_s == '2'){
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }else if(_this.wechat_checkCount > 50){
                                            clearTimeout(_this.wechat_checkST);
                                            _this.now_show_wechat = false;
                                            _this.wechatlogin();
                                        }else{
                                            wechat_checkstart();
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'feiniao'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s == '1' || check_s == '2'){
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }else if(_this.wechat_checkCount > 50){
                                            clearTimeout(_this.wechat_checkST);
                                            _this.now_show_wechat = false;
                                            _this.wechatlogin();
                                        }else{
                                            wechat_checkstart();
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'pn'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 12) {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'duceapp'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1' || check_s == '2') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 60 || (_this.wechat_checkCount > 1 && check_s == '-2')) {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer + (_this.referer.indexOf('?') != -1 ? '&' : '?') + 'wxlogin=1';
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == 'kekewxlogin'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 12) {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{elseif $jsms_muban_pc['weixintype'] == '1314wxlogin'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1') {
                                                wechat_checkstart();
                                            }
                                            if(_this.wechat_checkCount >= 20 || check_s == '-1' || check_s == '-2' || check_s == '2') {
                                                clearTimeout(_this.wechat_checkST);
                                                _this.now_show_wechat = false;
                                                _this.wechatlogin();
                                            }
                                        } else {
                                            clearTimeout(_this.wechat_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{else}-->
                                        _this.now_show_wechat = false;
                                        clearTimeout(_this.wechat_checkST);
                                        _this.wechat_checkCount = 0;
                                        _this.wechatbtnimg = "wechat.svg";
                                        <!--{/if}-->
                                    })
                                    .catch(function (error) {
                                        //console.log(error);
                                        _this.${Message}.error('error');
                                    })
                            }

                            wechat_checkstart();
                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error('error');
                        });

                    return;
                }else{
                    _this.now_show_wechat = false;
                    clearTimeout(_this.wechat_checkST);
                    _this.wechat_checkCount = 0;
                    _this.wechatbtnimg = "wechat.svg";
                    return;
                }

            },
            <!--{/if}-->
            <!--{if !empty($jsms_muban_pc['apptype']) && $jsms_muban_pc['apptype'] != 'none'}-->
            applogin: function(){
                let _this = this;
                if(_this.app_checkST){
                    clearTimeout(_this.app_checkST);
                    _this.app_checkCount = 0;
                }
                if(_this.now_show_app == false){
                    _this.now_show_app = true;

                    let appurl = "";
                    <!--{if $jsms_muban_pc['apptype'] == 'zimu'}-->
                    appurl = 'plugin.php?id=zimucms_appscan&model=pcqrcode&inajax=1';
                    <!--{elseif $jsms_muban_pc['apptype'] == 'duceapp'}-->
                    appurl = 'plugin.php?id=duceapp_mpscan&ac=qrcode&inajax=1';
                    <!--{else}-->
                    _this.now_show_app = false;
                    <!--{/if}-->

                    axios.get(appurl)
                        .then(function (response) {
                            //console.log(response['data']);

                            let wxhtml = response['data'];
                            let imgurl_reg = /<img(.*?)src="(.*?)"(.*?)>/ig;
                            let imgurl = imgurl_reg.exec(wxhtml)[2];

                            let checkurl_reg = "";
                            let checkurl = "";
                            <!--{if $jsms_muban_pc['apptype'] == 'zimu'}-->
                            checkurl_reg = /document\.getElementById\(\'checkhashpcurl\'\)\.value(.*?)\=(.*?)\'(.*?)\'/ig;
                            checkurl = checkurl_reg.exec(wxhtml)[3];
                            <!--{elseif $jsms_muban_pc['apptype'] == 'duceapp'}-->
                            checkurl_reg = /x\.get\(\'(.*?)\'(.*?)\,(.*?)function/ig;
                            checkurl = checkurl_reg.exec(wxhtml)[1];
                            <!--{/if}-->

                            let innerhtml = '<div class="c" align="center" style="width:100%;height:100%;"><img width="220" height="220" src="'+imgurl+'"/></div>';
                            _this.${refs}.approot.innerHTML = innerhtml;

                            function app_checkstart(){
                                _this.app_checkST = setTimeout(app_check, 2000);
                            }
                            function app_check(){
                                axios.get(checkurl)
                                    .then(function (response) {
                                        //console.log("ret:"+response['data']);
                                        let xmlDoc = null;
                                        <!--{if $jsms_muban_pc['apptype'] == 'duceapp'}-->
                                        if (window.DOMParser) {
                                            let parser = new DOMParser();
                                            xmlDoc = parser.parseFromString(response['data'], "text/xml");
                                        } else {
                                            //IE
                                            xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
                                            xmlDoc.async = "false";
                                            xmlDoc.loadXML(response['data']);
                                        }
                                        <!--{/if}-->

                                        let check_s = '';

                                        _this.app_checkCount++;
                                        <!--{if $jsms_muban_pc['apptype'] == 'zimu'}-->
                                        check_s = response['data'];
                                        if(check_s != '200') {
                                            _this.app_retcode = check_s;
                                            if(check_s == '201' || check_s == '202') {
                                                app_checkstart();
                                            }else if(check_s == '203') {
                                                _this.now_show_app = false;
                                                clearTimeout(_this.app_checkST);
                                                _this.app_checkCount = 0;
                                            }else if(check_s == '204') {
                                                clearTimeout(_this.app_checkST);
                                                _this.now_show_app = false;
                                                _this.applogin();
                                            }
                                        } else {
                                            clearTimeout(_this.app_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{elseif $jsms_muban_pc['apptype'] == 'duceapp'}-->
                                        check_s = xmlDoc.getElementsByTagName("root")[0].childNodes[0].nodeValue;
                                        if(check_s != 'done') {
                                            if(check_s == '1' || check_s == '2') {
                                                app_checkstart();
                                            }
                                            if(check_s == '2') {
                                                _this.app_retcode = 202;
                                            }
                                            if(_this.app_checkCount >= 24 || (_this.app_checkCount > 1 && check_s == '-2')) {
                                                clearTimeout(_this.app_checkST);
                                                _this.now_show_app = false;
                                                _this.applogin();
                                            }
                                        } else {
                                            clearTimeout(_this.app_checkST);
                                            window.location.href = _this.referer;
                                        }
                                        <!--{else}-->
                                        _this.now_show_app = false;
                                        clearTimeout(_this.app_checkST);
                                        _this.app_checkCount = 0;
                                        <!--{/if}-->
                                    })
                                    .catch(function (error) {
                                        //console.log(error);
                                        _this.${Message}.error('error');
                                    })
                            }

                            app_checkstart();
                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error('error');
                        });

                    return;
                }else{
                    _this.now_show_app = false;
                    clearTimeout(_this.app_checkST);
                    _this.app_checkCount = 0;
                    return;
                }

            }
            <!--{/if}-->
        }
    })
</script>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':pc/default/footer')}