<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset={CHARSET}">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta name="renderer" content="webkit">
    <meta name="force-rendering" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>{$jsms_muban_pc['securityheadertitle']}</title>
    <meta name="description" content="{$jsms_muban_pc['securityheaderdescription']}" />
    <meta name="keywords" content="{$jsms_muban_pc['securityheaderkeywords']}" />
    <!--{if !$jsms_muban_pc['securityfavicon']}-->
    <link rel="icon" href="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}images/security.png" type="image/x-icon">
    <!--{else}-->
    <link rel="icon" href="{$jsms_muban_pc['securityfavicon']}" type="image/x-icon">
    <!--{/if}-->

    <!--{if $jsms_muban_pc['cdn'] == 0}-->

    <!--{if !$jsms_muban_pc['vuedebug']}-->
    <script type="text/javascript" src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/vue.min.js"></script>
    <!--{else}-->
    <script type="text/javascript" src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/vue.js"></script>
    <!--{/if}-->

    <link rel="stylesheet" type="text/css" href="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}css/iview.css">
    <script type="text/javascript" src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/iview.min.js"></script>
    <script type="text/javascript" src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/axios.min.js"></script>
    <script type="text/javascript" src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/qs.min.js"></script>

    <!--{elseif $jsms_muban_pc['cdn'] == 1}-->

    <!-- import Vue.js -->
    <!--{if !$jsms_muban_pc['vuedebug']}-->
    <script src="https://cdn.bootcss.com/vue/2.6.10/vue.min.js"></script>
    <!--{else}-->
    <script type="text/javascript" src="https://cdn.bootcss.com/vue/2.6.10/vue.js"></script>
    <!--{/if}-->
    <!-- import stylesheet -->
    <link rel="stylesheet" href="https://cdn.bootcss.com/iview/3.5.1/styles/iview.css">
    <!-- import iView -->
    <script src="https://cdn.bootcss.com/iview/3.5.1/iview.min.js"></script>
    <script src="https://cdn.bootcss.com/axios/0.19.0/axios.min.js"></script>
    <script src="https://cdn.bootcss.com/qs/6.7.0/qs.min.js"></script>


    <!--{elseif $jsms_muban_pc['cdn'] == 2}-->

    <!-- import Vue.js -->
    <!--{if !$jsms_muban_pc['vuedebug']}-->
    <script src="https://lib.baomitu.com/vue/2.6.10/vue.min.js"></script>
    <!--{else}-->
    <script type="text/javascript" src="https://lib.baomitu.com/vue/2.6.10/vue.js"></script>
    <!--{/if}-->
    <!-- import stylesheet -->
    <link rel="stylesheet" href="https://lib.baomitu.com/iview/3.5.3/styles/iview.css">
    <!-- import iView -->
    <script src="https://lib.baomitu.com/iview/3.5.3/iview.min.js"></script>
    <script src="https://lib.baomitu.com/axios/0.19.0/axios.min.js"></script>
    <script src="https://lib.baomitu.com/qs/6.9.0/qs.min.js"></script>


    <!--{elseif $jsms_muban_pc['cdn'] == 3}-->

    <!-- import Vue.js -->
    <!--{if !$jsms_muban_pc['vuedebug']}-->
    <script src="https://libs.cdnjs.net/vue/2.6.10/vue.min.js"></script>
    <!--{else}-->
    <script type="text/javascript" src="https://libs.cdnjs.net/vue/2.6.10/vue.js"></script>
    <!--{/if}-->
    <!-- import stylesheet -->
    <link rel="stylesheet" href="https://libs.cdnjs.net/iview/3.5.1/styles/iview.css">
    <!-- import iView -->
    <script src="https://libs.cdnjs.net/iview/3.5.1/iview.min.js"></script>
    <script src="https://libs.cdnjs.net/axios/0.19.0/axios.min.js"></script>
    <script src="https://libs.cdnjs.net/qs/6.7.0/qs.min.js"></script>

    <!--{elseif $jsms_muban_pc['cdn'] == 4}-->

    <!-- import Vue.js -->
    <!--{if !$jsms_muban_pc['vuedebug']}-->
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.10/dist/vue.min.js"></script>
    <!--{else}-->
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/vue@2.6.10/dist/vue.js"></script>
    <!--{/if}-->
    <!-- import stylesheet -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/iview@3.5.1/dist/styles/iview.css">
    <!-- import iView -->
    <script src="https://cdn.jsdelivr.net/npm/iview@3.5.1/dist/iview.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios@0.19.0/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/qs@6.7.0/dist/qs.min.js"></script>


    <!--{else}-->

    <!--{if !$jsms_muban_pc['vuedebug']}-->
    <script type="text/javascript" src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/vue.min.js"></script>
    <!--{else}-->
    <script type="text/javascript" src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/vue.js"></script>
    <!--{/if}-->

    <link rel="stylesheet" type="text/css" href="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}css/iview.css">
    <script type="text/javascript" src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/iview.min.js"></script>
    <script type="text/javascript" src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/axios.min.js"></script>
    <script type="text/javascript" src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/qs.min.js"></script>

    <!--{/if}-->

    <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
    <script src="https://ssl.captcha.qq.com/TCaptcha.js"></script>
    <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
    <script src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/vaptcha.js"></script>
    <script src="https://v.vaptcha.com/v3.js"></script>
    <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 4}-->
    <script src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/gt.js"></script>
    <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
    <script src="https://ssl.captcha.qq.com/TCaptcha.js"></script>
    <!--{/if}-->
    <script type="text/javascript" src="{JZSJIALE_ISMS_PLUGIN_STATIC_PATH}js/util.js"></script>
    <link rel="stylesheet" type="text/css" href="{JZSJIALE_ISMS_PLUGIN_TEMPLATE_SECURITY_PATH}default/style/css/style.css">

    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header_diystyle')}
    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header_iconfont')}

    <!--{if $jsms_muban_pc['securityextendcss']}-->
    {$jsms_muban_pc['securityextendcss']}
    <!--{/if}-->

</head>
<body class="Jzsjiale-ISMS-Security-Body">