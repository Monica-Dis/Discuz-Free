<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<header class="Jzsjiale_Isms_Header" :class="{ 'is_fixed' : isheader_fixed }">
    <div class="Jzsjiale_Isms_Header_Inner">
        <a href="plugin.php?id=jzsjiale_isms:security" class="jzsjiale_isms_header_title">
            <!--{if $jsms_muban_pc['securitytitle']}-->
            {$jsms_muban_pc['securitytitle']}
            <!--{elseif $jsms_muban_pc['title']}-->
            {$jsms_muban_pc['title']}
            <!--{elseif $jsms_muban_pc['logo']}-->
            <img src="{$jsms_muban_pc['logo']}" class="jzsjiale_isms_header_title_img"/>
            <!--{else}-->
            {lang jzsjiale_isms:title_safetycenter}
            <!--{/if}-->
        </a>
        <ul class="Tabs jzsjiale_isms_header_Tabs">
            <!--{eval $mnid = getcurrentnav();}-->
            <!--{eval $navindex = 0;}-->
            <!--{loop $_G['setting']['navs'] $nav}-->
            <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->
                <!--{if $navindex < $jsms_muban_pc['securitynavnum']}-->
                    <li class="Tabs-item jzsjiale_isms_header_Tab">
                        <a class="Tabs-link jzsjiale_isms_header_TabsLink" href="{$nav[filename]}">
                            {$nav[navname]}
                        </a>
                    </li>
                    <!--{eval $navindex++;}-->
                <!--{else}-->
                    <!--{eval break;}-->
                <!--{/if}-->

            <!--{/if}-->
            <!--{/loop}-->
        </ul>
        <div class="jzsjiale_isms_header_userInfo">
            <!--{if $_G['uid']}-->
            <a class="Tabs-link jzsjiale_isms_header_TabsLink" href="home.php?mod=space&uid={$_G['uid']}&do=profile">
                {$_G['username']}
            </a>
            <a class="Tabs-link jzsjiale_isms_header_TabsLink pipe" href="javascript:void(0);">
                |
            </a>
            <a class="Tabs-link jzsjiale_isms_header_TabsLink" href="member.php?mod=logging&action=logout&formhash={FORMHASH}">
                {lang logout}
            </a>
            <!--{else}-->
            <a class="Tabs-link jzsjiale_isms_header_TabsLink" href="member.php?mod=register">
                {lang jzsjiale_isms:register_title}
            </a>
            <a class="Tabs-link jzsjiale_isms_header_TabsLink pipe" href="javascript:void(0);">
                |
            </a>
            <a class="Tabs-link jzsjiale_isms_header_TabsLink" href="member.php?mod=logging&action=login">
                {lang jzsjiale_isms:login_title}
            </a>
            <!--{/if}-->
        </div>
    </div>
    <div></div>
</header>