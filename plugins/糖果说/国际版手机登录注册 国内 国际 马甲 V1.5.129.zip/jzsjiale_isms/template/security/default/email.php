<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header')}
<div id="jzsjiale_isms_security_root">
    <div>
        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header_nav')}
    </div>
    <main class="jzsjiale_isms_security_main">
        <div class="jzsjiale_isms_security_main_page">
            <div class="jzsjiale_isms_security_layout">
                <div>
                    <div class="jzsjiale_isms_security_mainColumn">
                        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_nav')}
                        <div class="jzsjiale_isms_security_mainContent">
                            <div class="jzsjiale_isms_security_mainContent_title">
                                <h2 class="jzsjiale_isms_security_main_title">
                                    {lang jzsjiale_isms:tip_email_title}
                                </h2>
                                <div class="jzsjiale_isms_security_main_desc">
                                    {lang jzsjiale_isms:tip_email_title_desc}
                                </div>
                            </div>
                            <div class="jzsjiale_isms_security_mainContent_setting">

                                <div class="jzsjiale_isms_main_page">
                                    <div class="JCard jzsjiale_isms_main_content">
                                        <div class="jzsjiale_isms_main_content_inner">
                                            <div class="ISMSPage">
                                                <div class="ISMSPage_content">
                                                    <template>
                                                        <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>
                                                           <div class="ISMSForm-password">
                                                                <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                                    <div class="Input-wrapper">
                                                                        <Input type="text" @input="toggleEmailStatus()" @focus="err_email = false" @blur="toggleEmailStatus()" v-model="ISMSFormItem.email" name="email" class="JInput" placeholder="{lang jzsjiale_isms:tip_email}"/>
                                                                    </div>
                                                                    <div class="ISMSFormInput-errorMask " :class="{ 'ISMSFormInput-errorMask-hidden' : !err_email }">
                                                                        {{ msg_email }}
                                                                    </div>
                                                                </div>

                                                            </div>

                                                            <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton">
                                                                {lang jzsjiale_isms:btn_submit}
                                                            </button>
                                                        </i-form>
                                                    </template>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                <div class="jzsjiale_isms_security_sideColumn">
                    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_question')}
                </div>

            </div>
        </div>

        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer_content')}
    </main>
</div>

<script>
    new Vue({
        el: '#jzsjiale_isms_security_root',
        data: {
            ISMSFormItem: {
                email: ''
            },
            err_email: false,
            msg_email: "",
            isheader_fixed: false,
            referer: '{$dreferer}'
        },
        mounted() {
            let _this = this;
            window.addEventListener('scroll', _this.handleScroll, true);
        },
        methods: {
            handleScroll() {
                let _this = this;
                let scrollY = window.scrollY;
                //console.log("scrollY:"+scrollY);
                if (scrollY > 130) {
                    _this.isheader_fixed = true;
                } else {
                    _this.isheader_fixed = false;
                }
            },
            handleSubmit: function () {
                let _this = this;
                _this.emailVerify();
                if(_this.err_email){
                    return false;
                }

                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'email',
                    version: 1,
                    emailsubmit: 'yes',
                    discode: '32563',
                    hashid: '{$hashid}',
                    uid: '{$uid}',
                    sign: '{$sign}',
                    email: encodeURI(_this.ISMSFormItem.email),
                    formhash:'{FORMHASH}',
                    device: 'pc',
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            if(response['data']['msg'] == 'msg_need_login'){
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'member.php?mod=logging&action=login';
                                window.location.href = url_forward;
                            }else{
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                            }
                        }else{
                            _this.${Message}.success({
                                content: jzsjiale_lang['msg_change_success'],
                                duration: 10
                            });
                            let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'{$_G["siteurl"]}';
                            window.location.href = url_forward;
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            toggleEmailStatus: function () {
                let _this = this;
                _this.emailVerify();

            },
            emailVerify: function(){
                let _this = this;

                if(_.isEmpty(_this.ISMSFormItem.email)){
                    _this.err_email = true;
                    _this.msg_email = jzsjiale_lang['msg_email_empty'];
                    return;
                }else if(!_.isEmail(_this.ISMSFormItem.email)){
                    _this.err_email = true;
                    _this.msg_email = jzsjiale_lang['msg_email_format_error'];
                    return;
                }else{
                    _this.err_email = false;
                    _this.msg_email = "";
                    return;
                }

            }
        },
        destroyed: function () {
            window.removeEventListener('scroll', this.handleScroll);
        }
    })
</script>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer')}