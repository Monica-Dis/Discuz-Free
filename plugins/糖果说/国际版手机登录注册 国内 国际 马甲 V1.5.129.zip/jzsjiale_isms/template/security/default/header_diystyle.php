<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<style type="text/css">
    <!--{if $jsms_muban_pc['securitytitlecolor']}-->
    .jzsjiale_isms_header_title, .jzsjiale_isms_header_title:hover {
    color:{$jsms_muban_pc['securitytitlecolor']};
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['securitybtntextcolor']}-->
    .ISMSForm-submitButton{
    color: {$jsms_muban_pc['securitybtntextcolor']};
    border: unset!important;
    }
    <!--{/if}-->
    <!--{if $jsms_muban_pc['securitybtnbackgroundcolor']}-->
    .ISMSForm-submitButton{
    background-color: {$jsms_muban_pc['securitybtnbackgroundcolor']};
    }
    <!--{/if}-->
</style>