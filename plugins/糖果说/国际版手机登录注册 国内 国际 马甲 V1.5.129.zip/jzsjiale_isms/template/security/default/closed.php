<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header')}
<div id="jzsjiale_isms_security_root">
    <div>
        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header_nav')}
    </div>
    <main class="jzsjiale_isms_security_main">
        <div class="jzsjiale_isms_security_main_page">
            <div class="jzsjiale_isms_security_layout">
                <div>
                    <div class="jzsjiale_isms_security_mainColumn">
                        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_nav')}
                        <div class="jzsjiale_isms_security_mainContent">
                            <div class="jzsjiale_isms_security_mainContent_title">
                                <h2 class="jzsjiale_isms_security_main_title">
                                    {lang jzsjiale_isms:tip_closed_title}
                                </h2>
                                <div class="jzsjiale_isms_security_main_desc">
                                    <!--{if empty($tip_desc)}-->
                                    {lang jzsjiale_isms:tip_closed_desc}
                                    <!--{else}-->
                                    {$tip_desc}
                                    <!--{/if}-->
                                </div>
                            </div>
                            <div class="jzsjiale_isms_security_mainContent_setting">

                                <img src="{JZSJIALE_ISMS_PLUGIN_TEMPLATE_SECURITY_PATH}/default/style/images/weihu.png" class="jzsjiale_isms_img_closed"/>

                            </div>

                        </div>
                    </div>
                </div>
                <div class="jzsjiale_isms_security_sideColumn">
                    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_question')}
                </div>

            </div>
        </div>

        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer_content')}
    </main>
</div>

<script>
    new Vue({
        el: '#jzsjiale_isms_security_root',
        data: {
            isheader_fixed: false,
            referer: '{$dreferer}'
        },
        mounted() {
            let _this = this;
            window.addEventListener('scroll', _this.handleScroll, true);
        },
        methods: {
            handleScroll() {
                let _this = this;
                let scrollY = window.scrollY;
                //console.log("scrollY:"+scrollY);
                if (scrollY > 130) {
                    _this.isheader_fixed = true;
                } else {
                    _this.isheader_fixed = false;
                }
            }
        },
        destroyed: function () {
            window.removeEventListener('scroll', this.handleScroll);
        }
    })
</script>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer')}