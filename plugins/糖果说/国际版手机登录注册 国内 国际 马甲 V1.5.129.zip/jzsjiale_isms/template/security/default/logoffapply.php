<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header')}
<div id="jzsjiale_isms_security_root">
    <div>
        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header_nav')}
    </div>
    <main class="jzsjiale_isms_security_main">
        <div class="jzsjiale_isms_security_main_page">
            <div class="jzsjiale_isms_security_layout">
                <div>
                    <div class="jzsjiale_isms_security_mainColumn">
                        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_nav')}
                        <div class="jzsjiale_isms_security_mainContent">
                            <div class="jzsjiale_isms_security_mainContent_title">
                                <h2 class="jzsjiale_isms_security_main_title">
                                    {lang jzsjiale_isms:tip_logoffapply_title}
                                </h2>
                                <div class="jzsjiale_isms_security_main_desc">
                                    {lang jzsjiale_isms:tip_logoffapply_title_desc}
                                </div>
                            </div>
                            <div class="jzsjiale_isms_security_mainContent_setting">

                                <div class="jzsjiale_isms_main_page">
                                    <div class="JCard jzsjiale_isms_main_content">
                                        <div class="jzsjiale_isms_main_content_inner">
                                            <div class="ISMSPage">
                                                <div class="ISMSPage_content">
                                                    <template>
                                                        <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>
                                                            <div class="ISMSForm-account">
                                                                <div class="ISMSForm-bindSelect">
                                                                    <div class="ISMSForm-bind">

                                                                        <span class="JButton JSelect_bind">
                                                                            {lang jzsjiale_isms:tip_username}
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                                <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                                                <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                                    <div class="ISMSForm-accountInput Input-wrapper">
                                                                        <Input type="text" class="JInput" value="{$_G['username']}" readonly/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="ISMSForm-input">
                                                                <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                                    <div class="Input-wrapper">
                                                                        <Input type="text" @input="toggleConfirmStatus()" @focus="err_confirm = false" @blur="toggleConfirmStatus()" v-model="ISMSFormItem.confirm" name="confirm" class="JInput" placeholder="{lang jzsjiale_isms:tip_confirm}"/>
                                                                    </div>
                                                                    <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_confirm }">
                                                                        {{ msg_confirm }}
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <div class="ISMSForm-password">
                                                                <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                                    <div class="Input-wrapper">
                                                                        <Input type="password" @input="togglePasswordStatus()" @focus="err_password = false" @blur="togglePasswordStatus()" v-model="ISMSFormItem.password" name="password" class="JInput" placeholder="{lang jzsjiale_isms:tip_verify_loginmima}"/>
                                                                    </div>
                                                                    <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_password }">
                                                                        {lang jzsjiale_isms:msg_mima_empty}
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton">
                                                                {lang jzsjiale_isms:btn_submit}
                                                            </button>
                                                        </i-form>
                                                    </template>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                <div class="jzsjiale_isms_security_sideColumn">
                    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_question')}
                </div>

            </div>
        </div>

        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer_content')}
    </main>
</div>

<script>
    new Vue({
        el: '#jzsjiale_isms_security_root',
        data: {
            ISMSFormItem: {
                confirm: '',
                password: ''
            },
            err_confirm: false,
            msg_confirm: "",
            err_password: false,
            msg_password: "",
            isheader_fixed: false,
            referer: '{$dreferer}'
        },
        mounted() {
            let _this = this;
            window.addEventListener('scroll', _this.handleScroll, true);
        },
        methods: {
            handleScroll() {
                let _this = this;
                let scrollY = window.scrollY;
                //console.log("scrollY:"+scrollY);
                if (scrollY > 130) {
                    _this.isheader_fixed = true;
                } else {
                    _this.isheader_fixed = false;
                }
            },
            handleSubmit: function () {
                let _this = this;
                _this.confirmVerify();
                _this.bindPasswordVerify();
                if(_this.err_confirm || _this.err_password){
                    return false;
                }

                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'logoffapply',
                    version: 1,
                    logoffapplysubmit: 'yes',
                    discode: '32563',
                    hashid: '{$hashid}',
                    uid: '{$uid}',
                    sign: '{$sign}',
                    confirm: encodeURI(_this.ISMSFormItem.confirm),
                    password: _this.ISMSFormItem.password,
                    formhash:'{FORMHASH}',
                    device: 'pc',
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            if(response['data']['msg'] == 'msg_need_login'){
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'member.php?mod=logging&action=login';
                                window.location.href = url_forward;
                            }else{
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                            }
                        }else{
                            _this.${Message}.success({
                                content: jzsjiale_lang['msg_logoffapply_success'],
                                duration: 10
                            });
                            let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'{$_G["siteurl"]}';
                            window.location.href = url_forward;
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            toggleConfirmStatus: function () {
                let _this = this;
                _this.confirmVerify();
            },
            togglePasswordStatus: function () {
                let _this = this;
                _this.bindPasswordVerify();
            },
            confirmVerify: function(){
                let _this = this;

                if(_.isEmpty(_this.ISMSFormItem.confirm)){
                    _this.err_confirm = true;
                    _this.msg_confirm = jzsjiale_lang['msg_err_logoff_confirm'];
                    return;
                }else if(!_.isEmpty(_this.ISMSFormItem.confirm)){
                    if(_this.ISMSFormItem.confirm !== jzsjiale_lang['verify_confirm']){
                        _this.err_confirm = true;
                        _this.msg_confirm = jzsjiale_lang['msg_err_logoff_confirm_text'];
                        return;
                    }else{
                        _this.err_confirm = false;
                        _this.msg_confirm = "";
                        return;
                    }
                }else{
                    _this.err_confirm = false;
                    _this.msg_confirm = "";
                    return;
                }

            },
            bindPasswordVerify: function(){
                let _this = this;

                if(_.isEmpty(_this.ISMSFormItem.password)){
                    _this.err_password = true;
                    _this.msg_password = jzsjiale_lang['msg_password_empty'];
                    return;
                }else{
                    _this.err_password = false;
                    _this.msg_password = "";
                    return;
                }

            }
        },
        destroyed: function () {
            window.removeEventListener('scroll', this.handleScroll);
        }
    })
</script>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer')}