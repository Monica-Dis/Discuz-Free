<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header')}
<div id="jzsjiale_isms_security_root">
    <div>
        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/header_nav')}
    </div>
    <main class="jzsjiale_isms_security_main">
        <div class="jzsjiale_isms_security_main_page">
            <div class="jzsjiale_isms_security_layout">
                <div>
                    <div class="jzsjiale_isms_security_mainColumn">
                        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_nav')}
                        <div class="jzsjiale_isms_security_mainContent">
                            <div class="jzsjiale_isms_security_mainContent_title">
                                <h2 class="jzsjiale_isms_security_main_title">
                                    {lang jzsjiale_isms:tip_verifybind_title}
                                </h2>
                                <div class="jzsjiale_isms_security_main_desc">
                                    {lang jzsjiale_isms:tip_verifybind_title_desc}
                                </div>
                            </div>
                            <div class="jzsjiale_isms_security_mainContent_setting">

                                <div class="jzsjiale_isms_main_page">
                                    <div class="JCard jzsjiale_isms_main_content">
                                        <div class="jzsjiale_isms_main_content_inner">
                                            <div class="ISMSPage">
                                                <div class="ISMSPage_content">
                                                    <template>
                                                        <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>
                                                            <div class="ISMSForm-account">
                                                                <div class="ISMSForm-bindSelect">
                                                                    <div class="ISMSForm-bind">

                                                                        <span class="JButton JSelect_bind">
                                                                            {lang jzsjiale_isms:tip_bind_areacode}
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                                <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                                                <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                                    <div class="ISMSForm-accountInput Input-wrapper">
                                                                        <Input type="text" class="JInput" value="{$userinfo['areacode']}" readonly/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="ISMSForm-account">
                                                                <div class="ISMSForm-bindSelect">
                                                                    <div class="ISMSForm-bind">

                                                                        <span class="JButton JSelect_bind">
                                                                            {lang jzsjiale_isms:tip_bind_phone}
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                                <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                                                <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                                                    <div class="ISMSForm-accountInput Input-wrapper">
                                                                        <Input type="text" class="JInput" value="{$userinfo['phone']}" readonly/>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="ISMSForm-seccode">
                                                                <div class="ISMSForm-seccodeinput ISMSForm-seccodeinputContainer">
                                                                    <div class="ISMSForm-seccodeInput">
                                                                        <div class="Input-wrapper">
                                                                            <Input type="text" @input="toggleSeccodeStatus()" @focus="err_seccode = false" @blur="toggleSeccodeStatus()" v-model="ISMSFormItem.seccode" name="seccode" class="JInput" placeholder="{lang jzsjiale_isms:tip_seccode1}{$_G['cache']['plugin']['jzsjiale_isms']['g_seccodebits']}{lang jzsjiale_isms:tip_seccode2}"/>

                                                                        </div>
                                                                        <div class="ISMSFormInput-errorMask ISMSFormInput-errorSeccodeMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_seccode }">
                                                                            {{ msg_seccode }}
                                                                        </div>
                                                                    </div>
                                                                    <button v-if="btn_send" type="button" <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}--> id="TencentCaptcha" data-appid="{$_G['cache']['plugin']['jzsjiale_isms']['g_captchaappid']}" data-cbfn="tencentCaptchaCallback"<!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->id="TencentCaptcha" data-appid="{$_G['cache']['plugin']['jzsjiale_isms']['g_captchaappid']}" data-cbfn="cloudTencentCaptchaCallback"<!--{/if}-->
                                                                    @click="sendSeccode"
                                                                    class="JButton ISMSForm-sendseccodeButton Button--plain">
                                                                    {lang jzsjiale_isms:btn_sendseccode}
                                                                    </button>
                                                                    <button v-else type="button" disabled class="JButton ISMSForm-sendseccodeButton Button--plain">
                                                                        {{ countdown }} {lang jzsjiale_isms:btn_sendseccode_countdown}
                                                                    </button>
                                                                </div>
                                                            </div>
                                                            <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton">
                                                                {lang jzsjiale_isms:btn_submit}
                                                            </button>
                                                        </i-form>
                                                    </template>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                <div class="jzsjiale_isms_security_sideColumn">
                    {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/security_question')}
                </div>

            </div>
        </div>

        {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer_content')}
    </main>
</div>

<script>
    new Vue({
        el: '#jzsjiale_isms_security_root',
        data: {
            ISMSFormItem: {
                seccode: ''
            },
            err_seccode: false,
            msg_seccode: "",
            btn_send: true,
            countdown: 60,
            isheader_fixed: false,
            referer: '{$dreferer}'
        },
        mounted() {
            let _this = this;
            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
            window.tencentCaptchaCallback = _this.tencentCaptchaCallback;
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
            window.vaptchaCallback = _this.vaptchaCallback;
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
            window.cloudTencentCaptchaCallback = _this.cloudTencentCaptchaCallback;
            <!--{/if}-->
            window.addEventListener('scroll', _this.handleScroll, true);
        },
        methods: {
            handleScroll() {
                let _this = this;
                let scrollY = window.scrollY;
                //console.log("scrollY:"+scrollY);
                if (scrollY > 130) {
                    _this.isheader_fixed = true;
                } else {
                    _this.isheader_fixed = false;
                }
            },
            handleSubmit: function () {
                let _this = this;
                _this.bindSeccodeVerify();
                if(_this.err_seccode){
                    return false;
                }

                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'askverifybindmobile',
                    version: 1,
                    verifybindsubmit: 'yes',
                    discode: '32563',
                    seccode: _this.ISMSFormItem.seccode,
                    formhash:'{FORMHASH}',
                    device: 'pc',
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            if(response['data']['msg'] == 'msg_need_login'){
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                                let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'member.php?mod=logging&action=login';
                                window.location.href = url_forward;
                            }else{
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                            }
                        }else{
                            _this.${Message}.success({
                                content: jzsjiale_lang['msg_verify_success'],
                                duration: 10
                            });
                            let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'{$_G["siteurl"]}';
                            window.location.href = url_forward;
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            toggleSeccodeStatus: function () {
                let _this = this;
                _this.bindSeccodeVerify();
            },
            sendSeccode: function(){
                let _this = this;

                <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 0}-->
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'notverify',
                    version: 1,
                    type: 5,
                    formhash:'{FORMHASH}'
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                        }else{

                            _this.btn_send = false;

                            let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                            sendsmsjiange = parseInt(sendsmsjiange);
                            if(sendsmsjiange != "" && sendsmsjiange > 60){
                                _this.countdown = sendsmsjiange;
                            }else{
                                _this.countdown = 60;
                            }

                            let auth_timetimer =  setInterval(()=>{
                                _this.countdown--;
                                if(_this.countdown<=0){
                                    _this.btn_send = true;
                                    clearInterval(auth_timetimer);
                                }
                            }, 1000);

                            _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
                <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
                let isms_v = new ISMSVD("{$_G['cache']['plugin']['jzsjiale_isms']['g_captchaappid']}", null, 'invisible', "{$_G['cache']['plugin']['jzsjiale_isms']['g_captchascene']}","/{JZSJIALE_ISMS_PLUGIN_API}&module=vaptchaofflineverify&version=1&formhash={FORMHASH}");
                isms_v.initVaptcha();
                <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 4}-->
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'startgeetestverify',
                    version: 1,
                    clienttype: 'web',
                    t: (new Date()).getTime(),
                    formhash:'{FORMHASH}'
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                        }else{

                            initGeetest({
                                gt: response['data']['data']['gt'],
                                challenge: response['data']['data']['challenge'],
                                new_captcha: response['data']['data']['new_captcha'],
                                offline: !response['data']['data']['success'],
                                product: 'bind'
                            }, function(captchaObj){
                                captchaObj.onReady(function(){
                                    captchaObj.verify();
                                }).onSuccess(function(){
                                    //_this.${Message}.success(jzsjiale_lang['msg_captcha_success']);
                                    axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                                        module: 'geetestverify',
                                        version: 1,
                                        geetest_challenge: captchaObj.getValidate().geetest_challenge,
                                        geetest_validate: captchaObj.getValidate().geetest_validate,
                                        geetest_seccode: captchaObj.getValidate().geetest_seccode,
                                        areacode: _this.ISMSFormItem.areacode,
                                        phone: _this.ISMSFormItem.phone,
                                        type: 5,
                                        clienttype: 'web',
                                        t: (new Date()).getTime(),
                                        formhash:'{FORMHASH}'
                                    }))
                                        .then(function (response) {
                                            //console.log(response['data']);
                                            if(response['data']['code'] != 0){
                                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                                            }else{

                                                _this.btn_send = false;

                                                let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                                                sendsmsjiange = parseInt(sendsmsjiange);
                                                if(sendsmsjiange != "" && sendsmsjiange > 60){
                                                    _this.countdown = sendsmsjiange;
                                                }else{
                                                    _this.countdown = 60;
                                                }

                                                let auth_timetimer =  setInterval(()=>{
                                                    _this.countdown--;
                                                    if(_this.countdown<=0){
                                                        _this.btn_send = true;
                                                        clearInterval(auth_timetimer);
                                                    }
                                                }, 1000);

                                                _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                                            }

                                        })
                                        .catch(function (error) {
                                            //console.log(error);
                                            _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                                        });
                                }).onClose(function () {
                                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                                }).onError(function(){
                                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                                });
                            });
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
                <!--{/if}-->

            },
            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
            tencentCaptchaCallback: function (res) {
                let _this = this;

                if(res.ret === 0 && !_.isEmpty(res.ticket) && !_.isEmpty(res.randstr)){
                    axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                        module: 'ticketverify',
                        version: 1,
                        ticket: res.ticket,
                        randstr: res.randstr,
                        type: 5,
                        formhash:'{FORMHASH}'
                    }))
                        .then(function (response) {
                            //console.log(response['data']);
                            if(response['data']['code'] != 0){
                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                            }else{

                                _this.btn_send = false;

                                let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                                sendsmsjiange = parseInt(sendsmsjiange);
                                if(sendsmsjiange != "" && sendsmsjiange > 60){
                                    _this.countdown = sendsmsjiange;
                                }else{
                                    _this.countdown = 60;
                                }

                                let auth_timetimer =  setInterval(()=>{
                                    _this.countdown--;
                                    if(_this.countdown<=0){
                                        _this.btn_send = true;
                                        clearInterval(auth_timetimer);
                                    }
                                }, 1000);

                                _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                            }

                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                        });

                }else if(res.ret === 2){
                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                }else{
                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                }

            },
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
            vaptchaCallback: function (token) {
                let _this = this;

                if(!_.isEmpty(token)){
                    axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                        module: 'vaptchaverify',
                        version: 1,
                        token: token,
                        areacode: _this.ISMSFormItem.areacode,
                        phone: _this.ISMSFormItem.phone,
                        type: 5,
                        formhash:'{FORMHASH}'
                    }))
                        .then(function (response) {
                            //console.log(response['data']);
                            if(response['data']['code'] != 0){
                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                            }else{

                                _this.btn_send = false;

                                let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                                sendsmsjiange = parseInt(sendsmsjiange);
                                if(sendsmsjiange != "" && sendsmsjiange > 60){
                                    _this.countdown = sendsmsjiange;
                                }else{
                                    _this.countdown = 60;
                                }

                                let auth_timetimer =  setInterval(()=>{
                                    _this.countdown--;
                                    if(_this.countdown<=0){
                                        _this.btn_send = true;
                                        clearInterval(auth_timetimer);
                                    }
                                }, 1000);

                                _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                            }

                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                        });

                }else if(res.ret === 2){
                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                }else{
                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                }

            },
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
            cloudTencentCaptchaCallback: function (res) {
                let _this = this;

                if(res.ret === 0 && !_.isEmpty(res.ticket) && !_.isEmpty(res.randstr)){
                    axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                        module: 'cloudtencentverify',
                        version: 1,
                        ticket: res.ticket,
                        randstr: res.randstr,
                        areacode: _this.ISMSFormItem.areacode,
                        phone: _this.ISMSFormItem.phone,
                        type: 5,
                        formhash:'{FORMHASH}'
                    }))
                        .then(function (response) {
                            //console.log(response['data']);
                            if(response['data']['code'] != 0){
                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                            }else{

                                _this.btn_send = false;

                                let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                                sendsmsjiange = parseInt(sendsmsjiange);
                                if(sendsmsjiange != "" && sendsmsjiange > 60){
                                    _this.countdown = sendsmsjiange;
                                }else{
                                    _this.countdown = 60;
                                }

                                let auth_timetimer =  setInterval(()=>{
                                    _this.countdown--;
                                    if(_this.countdown<=0){
                                        _this.btn_send = true;
                                        clearInterval(auth_timetimer);
                                    }
                                }, 1000);

                                _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                            }

                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                        });

                }else if(res.ret === 2){
                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                }else{
                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                }

            },
            <!--{/if}-->
            bindSeccodeVerify: function(){
                let _this = this;
                if(_.isEmpty(_this.ISMSFormItem.seccode)){
                    _this.err_seccode = true;
                    _this.msg_seccode = jzsjiale_lang['msg_seccode_empty'];
                    return;
                }else if(!_.isSeccode(_this.ISMSFormItem.seccode)){
                    _this.err_seccode = true;
                    _this.msg_seccode = jzsjiale_lang['msg_seccode_formaterror'];
                    return;
                }else{
                    _this.err_seccode = false;
                    _this.msg_seccode = "";
                    return;
                }
            },
        },
        destroyed: function () {
            window.removeEventListener('scroll', this.handleScroll);
        }
    })
</script>
<!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
<script>
    window.callback = function(res){
        //console.log(res);
        tencentCaptchaCallback(res);
    }
</script>
<!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
<script>
    window.callback = function(token){
        //console.log(res);
        vaptchaCallback(token);
    }
</script>
<!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
<script>
    window.callback = function(res){
        //console.log(res);
        cloudTencentCaptchaCallback(res);
    }
</script>
<!--{/if}-->
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':security/default/footer')}