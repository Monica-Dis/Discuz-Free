<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<!--{block securitycenterbtn}-->
    <span class="pipe">|</span>
    <a href="plugin.php?id=jzsjiale_isms:security" target="_blank">{lang jzsjiale_isms:title_safetycenter}</a>
<!--{/block}-->