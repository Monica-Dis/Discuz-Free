<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
<!--{if $jsms_moreparameters['magapphidetopbar'] && strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPPX') !== false}-->
<!--{else}-->
<header class="Jzsjiale_Isms_Header" :class="{ 'is_fixed' : isheader_fixed }">
    <div class="Jzsjiale_Isms_Header_Inner">
        <a href="plugin.php?id=jzsjiale_isms:security" class="jzsjiale_isms_header_title" target="_self">
            <!--{if $jsms_muban_mobile['securitytitle']}-->
            {$jsms_muban_mobile['securitytitle']}
            <!--{elseif $jsms_muban_mobile['title']}-->
            {$jsms_muban_mobile['title']}
            <!--{elseif $jsms_muban_mobile['logo']}-->
            <img src="{$jsms_muban_mobile['logo']}" class="jzsjiale_isms_header_title_img"/>
            <!--{else}-->
            {lang jzsjiale_isms:title_safetycenter}
            <!--{/if}-->
        </a>

        <a href="javascript:void(0);" onClick="javascript:history.back(-1);" class="back" target="_self">
            <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-fanhui"></use>
            </svg>
        </a>
        <a href="{$_G['siteurl']}" class="home" target="_self">
            <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-shouye"></use>
            </svg>
        </a>
        <a href="javascript:void(0);" @click="isopenmenu = true" class="menu">
            <svg class="icon" aria-hidden="true">
                <use xlink:href="#icon-caidan"></use>
            </svg>
        </a>

    </div>
</header>
<!--{/if}-->
<!--{if $jsms_muban_mobile['securitycirclemenu']}-->
<div class="circle_menu" @click="isopenmenu = true">{lang jzsjiale_isms:circle_menu}</div>
<!--{/if}-->