<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/spa_optimization/header')}
<div id="mobile_jzsjiale_isms_lostpasswd_root">
    <main class="mobile_jzsjiale_i_sms_lostpasswd_main">
        <div class="mobile_jzsjiale_isms_main_content">
            <div class="mobile-header">
                <a href="{echo $_G['siteurl'];}" target="_self" class="close">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-guanbi"></use>
                    </svg>
                </a>
                <div class="mobile-header-title">
                    <!--{if $jsms_muban_mobile['title']}-->
                    {$jsms_muban_mobile['title']}
                    <!--{elseif $jsms_muban_mobile['logo']}-->
                    <img src="{$jsms_muban_mobile['logo']}" class="mobile_jzsjiale_isms_main_content_header_title_img"/>
                    <!--{else}-->
                    {lang jzsjiale_isms:title_and_logo_null}
                    <!--{/if}-->
                </div>
                <div class="mobile-header-desc">
                    {$jsms_muban_mobile['lostpasswddesc']}
                </div>
            </div>
            <div class="mobile-content">
                <!--{if in_array($_G['cache']['plugin']['jzsjiale_isms']['g_openmobilezhaohui'],array('1','3','4'))}-->
                <div v-show="tabactive == 'mobile'">
                    <template>
                        <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>
                            <div class="mobile-input">
                                <div class="ISMSForm-account">
                                    <div class="ISMSForm-areacodeSelect">
                                        <div class="ISMSForm-areacode">

                                            <i-select @on-change="togglePhoneStatus()" v-model="ISMSFormItem.areacode" class="JSelect_areacode" placeholder="{lang jzsjiale_isms:placeholder}" transfer>

                                                <i-option v-for="(item, index) in areacodeList.commonareacodeList" :value="item.areacode" :label="'+'+item.areacode" :key="item.index">
                                                    {{ item.countrycn }}&nbsp;&nbsp;+{{ item.areacode }}
                                                </i-option>
                                                <i-option v-if="areacodeList.commonareacodeList && areacodeList.commonareacodeList.length >0" value="splitline" disabled>
                                                    -------------------------------------
                                                </i-option>
                                                <i-option v-for="(item, index) in areacodeList.allareacodeList" :value="item.areacode" :label="'+'+item.areacode" :key="item.index">
                                                    {{ item.countrycn }}&nbsp;&nbsp;+{{ item.areacode }}
                                                </i-option>


                                            </i-select>
                                        </div>
                                    </div>
                                    <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                    <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                        <div class="ISMSForm-accountInput Input-wrapper">
                                            <Input type="tel" @input="togglePhoneStatus()" @focus="err_phone = false" @blur="togglePhoneStatus()" v-model="ISMSFormItem.phone" name="phone" class="JInput" :maxlength="size_phone" :size="size_phone" placeholder="{lang jzsjiale_isms:tip_phone}"/>
                                        </div>
                                        <div class="ISMSFormInput-errorMask " :class="{ 'ISMSFormInput-errorMask-hidden' : !err_phone }">
                                            {{ msg_phone }}
                                        </div>
                                    </div>
                                </div>
                                <div class="ISMSForm-seccode">
                                    <div class="ISMSForm-seccodeinput ISMSForm-seccodeinputContainer">
                                        <div class="ISMSForm-seccodeInput">
                                            <div class="Input-wrapper">
                                                <Input type="text" @input="toggleSeccodeStatus()" @focus="err_seccode = false" @blur="toggleSeccodeStatus()" v-model="ISMSFormItem.seccode" name="seccode" class="JInput" placeholder="{lang jzsjiale_isms:tip_seccode1}{$_G['cache']['plugin']['jzsjiale_isms']['g_seccodebits']}{lang jzsjiale_isms:tip_seccode2}"/>

                                            </div>
                                            <div class="ISMSFormInput-errorMask ISMSFormInput-errorSeccodeMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_seccode }">
                                                {{ msg_seccode }}
                                            </div>
                                        </div>
                                        <button v-if="btn_send" type="button" <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}--> id="TencentCaptcha" data-appid="{$_G['cache']['plugin']['jzsjiale_isms']['g_captchaappid']}" data-cbfn="tencentCaptchaCallback"<!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->id="TencentCaptcha" data-appid="{$_G['cache']['plugin']['jzsjiale_isms']['g_captchaappid']}" data-cbfn="cloudTencentCaptchaCallback"<!--{/if}-->
                                        @click="sendSeccode" :disabled="err_phone || !ISMSFormItem.phone"
                                        class="JButton ISMSForm-sendseccodeButton Button--plain">
                                        {lang jzsjiale_isms:btn_mobile_sendseccode}
                                        </button>
                                        <button v-else type="button" disabled class="JButton ISMSForm-sendseccodeButton Button--plain">
                                            {{ countdown }} {lang jzsjiale_isms:btn_mobile_sendseccode_countdown}
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <!--{if in_array($_G['cache']['plugin']['jzsjiale_isms']['g_openmobilezhaohui'],array('3','4'))}-->
                            <div class="ISMSForm-Login-type">

                                <a href="member.php?mod={$_G[setting][regname]}" target="_self" class="JButton ISMSForm-Login-Type Button--plain">
                                    {lang jzsjiale_isms:tip_btn_register_account}
                                </a>

                                <a href="javascript:void(0)" @click="tabactive = 'email';" target="_self" class="JButton ISMSForm-Forgot-Password Button--plain">
                                    {lang jzsjiale_isms:tip_btn_forgotpassword_email}
                                </a>

                            </div>
                            <!--{/if}-->
                            <!--{if $jsms_ad['mad1']}-->
                            <div class="ad_frame">
                                <!--{if $jsms_ad['mad1link']}-->
                                <a href="{$jsms_ad['mad1link']}" target="_blank"><img src="{$jsms_ad['mad1']}" class="ad_img"/></a>
                                <!--{else}-->
                                <img src="{$jsms_ad['mad1']}" class="ad_img"/>
                                <!--{/if}-->
                            </div>
                            <!--{/if}-->
                            <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton">
                                {lang jzsjiale_isms:btn_lostpasswd}
                            </button>
                        </i-form>
                    </template>
                </div>
                <!--{/if}-->
                <!--{if in_array($_G['cache']['plugin']['jzsjiale_isms']['g_openmobilezhaohui'],array('2','3','4'))}-->
                <div v-show="tabactive == 'email'">
                    <template>
                         <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>
                             <div class="mobile-input">
                                 <div class="ISMSForm-common">
                                     <div class="ISMSFormInput ISMSForm-commonInputContainer">
                                         <div class="Input-wrapper">
                                             <Input type="text" @input="toggleEmailStatus()" @focus="err_email = false" @blur="toggleEmailStatus()" v-model="ISMSFormItem.email" name="email" class="JInput" placeholder="{lang jzsjiale_isms:tip_lostpasswd_email}"/>
                                         </div>
                                         <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_email }">
                                             {{ msg_email }}
                                         </div>
                                     </div>

                                 </div>
                                 <div class="ISMSForm-common">
                                     <div class="ISMSFormInput ISMSForm-commonInputContainer">
                                         <div class="Input-wrapper">
                                             <Input type="text" v-model="ISMSFormItem.username" name="username" class="JInput" placeholder="{lang jzsjiale_isms:tip_lostpasswd_username}"/>
                                         </div>
                                         <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask ISMSFormInput-errorMask-hidden">

                                         </div>
                                     </div>

                                 </div>
                             </div>
                             <!--{if in_array($_G['cache']['plugin']['jzsjiale_isms']['g_openmobilezhaohui'],array('3','4'))}-->
                             <div class="ISMSForm-Login-type">

                                 <a href="member.php?mod={$_G[setting][regname]}" target="_self" class="JButton ISMSForm-Login-Type Button--plain">
                                     {lang jzsjiale_isms:tip_btn_register_account}
                                 </a>

                                 <a href="javascript:void(0)" @click="tabactive = 'mobile';" target="_self" class="JButton ISMSForm-Forgot-Password Button--plain">
                                     {lang jzsjiale_isms:tip_btn_forgotpassword_mobile}
                                 </a>

                             </div>
                             <!--{/if}-->
                             <!--{if $jsms_ad['mad1']}-->
                             <div class="ad_frame">
                                 <!--{if $jsms_ad['mad1link']}-->
                                 <a href="{$jsms_ad['mad1link']}" target="_blank"><img src="{$jsms_ad['mad1']}" class="ad_img"/></a>
                                 <!--{else}-->
                                 <img src="{$jsms_ad['mad1']}" class="ad_img"/>
                                 <!--{/if}-->
                             </div>
                             <!--{/if}-->
                             <button type="primary" @click="handleSubmit_email()" class="JButton ISMSForm-submitButton">
                                 {lang jzsjiale_isms:btn_lostpasswd}
                             </button>
                         </i-form>
                    </template>
                </div>
                <!--{/if}-->
            </div>
            <div class="otherbtn">
                <a href="member.php?mod={$_G[setting][regname]}" target="_self">{lang jzsjiale_isms:register_title}</a>
                <a href="member.php?mod=logging&action=login" target="_self">{lang jzsjiale_isms:login_title}</a>
            </div>

            <!--{if $jsms_ad['mad2']}-->
            <div class="ad_frame2">
                <!--{if $jsms_ad['mad2link']}-->
                <a href="{$jsms_ad['mad2link']}" target="_blank"><img src="{$jsms_ad['mad2']}" class="ad_img"/></a>
                <!--{else}-->
                <img src="{$jsms_ad['mad2']}" class="ad_img"/>
                <!--{/if}-->
            </div>
            <!--{/if}-->
            <!--{if $jsms_muban_mobile['isshowsocial']}-->
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/spa_optimization/social')}
            <!--{/if}-->
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/spa_optimization/footer_content')}
        </div>
    </main>
</div>
<script>
    new Vue({
        el: '#mobile_jzsjiale_isms_lostpasswd_root',
        data: {
            ISMSFormItem: {
                areacode: '86',
                phone: '',
                seccode: '',
                email: '',
                username: ''
            },
            areacodeList:{
                allareacodeList:[],
                commonareacodeList:[]
            },
            err_phone: false,
            msg_phone: "",
            err_seccode: false,
            msg_seccode: "",
            err_email: false,
            msg_email: "",
            btn_send: true,
            now_show_qrImage: false,
            countdown: 60,
            tabactive: 'mobile',
            referer: '{$dreferer}'
        },
        beforeCreate(){
            let _this = this;
            //j_z_s_j_i_a_l_e_i_s_m_s_a_p_i
            axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                module: 'areacode',
                version: 1,
                formhash:'{FORMHASH}'
            }))
                .then(function (response) {

                    if(response['data']['code'] != 0){
                        _this.areacodeList.allareacodeList = response['data']['data'];
                        _this.areacodeList.commonareacodeList = response['data']['data'];

                        _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                    }else{
                        _this.areacodeList.allareacodeList = response['data']['data']['allareacode'];
                        _this.areacodeList.commonareacodeList = response['data']['data']['commonareacode'];
                    }
                })
                .catch(function (error) {
                    //console.log(error);
                    _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                });
        },
        computed: {
            size_phone: function () {
                let _this = this;
                return (_this.ISMSFormItem.areacode == '86' || _.isEmpty(_this.ISMSFormItem.areacode)) ? 11 : '';
            }
        },
        mounted() {
            let _this = this;
            <!--{if in_array($_G['cache']['plugin']['jzsjiale_isms']['g_openmobilezhaohui'],array('1','3','4'))}-->
            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
            window.tencentCaptchaCallback = _this.tencentCaptchaCallback;
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
            window.vaptchaCallback = _this.vaptchaCallback;
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
            window.cloudTencentCaptchaCallback = _this.cloudTencentCaptchaCallback;
            <!--{/if}-->
            <!--{/if}-->
        },
        created() {
            let _this = this;

            <!--{if in_array($_G['cache']['plugin']['jzsjiale_isms']['g_openmobilezhaohui'],array('1','3'))}-->
            _this.tabactive = 'mobile';
            <!--{elseif in_array($_G['cache']['plugin']['jzsjiale_isms']['g_openmobilezhaohui'],array('2','4'))}-->
            _this.tabactive = 'email';
            <!--{else}-->
            _this.tabactive = 'mobile';
            <!--{/if}-->

            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_defaultareacode'] != ""}-->
            _this.ISMSFormItem.areacode = "{$_G['cache']['plugin']['jzsjiale_isms']['g_defaultareacode']}";
            <!--{/if}-->
        },
        methods: {
            <!--{if in_array($_G['cache']['plugin']['jzsjiale_isms']['g_openmobilezhaohui'],array('1','3','4'))}-->
            handleSubmit: function () {
                let _this = this;
                _this.lostpasswdPhoneVerify();
                _this.lostpasswdSeccodeVerify();
                if(_this.err_phone || _this.err_seccode){
                    return false;
                }
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'lostpasswd',
                    version: 1,
                    lostpasswdsubmit: 'yes',
                    discode: '32563',
                    areacode: _this.ISMSFormItem.areacode,
                    phone: _this.ISMSFormItem.phone,
                    seccode: _this.ISMSFormItem.seccode,
                    formhash:'{FORMHASH}',
                    device: 'mobile',
                    cookietime: 2592000,
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                        }else{
                            _this.${Message}.success({
                                content: jzsjiale_lang['msg_verify_success'],
                                duration: 10
                            });
                            let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'{$_G["siteurl"]}';
                            window.location.href = url_forward;
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            <!--{/if}-->
            <!--{if in_array($_G['cache']['plugin']['jzsjiale_isms']['g_openmobilezhaohui'],array('2','3','4'))}-->
            handleSubmit_email: function () {
                let _this = this;
                _this.lostpasswdEmailVerify();
                if(_this.err_email){
                    return false;
                }
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'lostpasswdemail',
                    version: 1,
                    lostpasswdsubmit: 'yes',
                    discode: '32563',
                    email: _this.ISMSFormItem.email,
                    username: encodeURI(_this.ISMSFormItem.username),
                    formhash:'{FORMHASH}',
                    device: 'mobile',
                    cookietime: 2592000,
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            _this.${Message}.error({
                                content: jzsjiale_lang[response['data']['msg']],
                                duration: 10
                            });
                        }else{
                            _this.${Message}.success({
                                content: jzsjiale_lang['msg_getpasswd_send_succeed'],
                                duration: 20
                            });
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            <!--{/if}-->
            togglePhoneStatus: function () {
                let _this = this;
                _this.lostpasswdPhoneVerify();

            },
            toggleSeccodeStatus: function () {
                let _this = this;
                _this.lostpasswdSeccodeVerify();
            },
            <!--{if in_array($_G['cache']['plugin']['jzsjiale_isms']['g_openmobilezhaohui'],array('1','3','4'))}-->
            sendSeccode: function(){
                let _this = this;
                _this.lostpasswdPhoneVerify();
                if(_this.err_phone){
                    return false;
                }

                <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 0}-->
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'notverify',
                    version: 1,
                    areacode: _this.ISMSFormItem.areacode,
                    phone: _this.ISMSFormItem.phone,
                    type: 4,
                    formhash:'{FORMHASH}'
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                        }else{

                            _this.btn_send = false;

                            let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                            sendsmsjiange = parseInt(sendsmsjiange);
                            if(sendsmsjiange != "" && sendsmsjiange > 60){
                                _this.countdown = sendsmsjiange;
                            }else{
                                _this.countdown = 60;
                            }

                            let auth_timetimer =  setInterval(()=>{
                                _this.countdown--;
                                if(_this.countdown<=0){
                                    _this.btn_send = true;
                                    clearInterval(auth_timetimer);
                                }
                            }, 1000);

                            _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
                <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
                let isms_v = new ISMSVD("{$_G['cache']['plugin']['jzsjiale_isms']['g_captchaappid']}", null, 'invisible', "{$_G['cache']['plugin']['jzsjiale_isms']['g_captchascene']}","/{JZSJIALE_ISMS_PLUGIN_API}&module=vaptchaofflineverify&version=1&formhash={FORMHASH}");
                isms_v.initVaptcha();
                <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 4}-->
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'startgeetestverify',
                    version: 1,
                    clienttype: 'h5',
                    t: (new Date()).getTime(),
                    formhash:'{FORMHASH}'
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                        }else{

                            initGeetest({
                                gt: response['data']['data']['gt'],
                                challenge: response['data']['data']['challenge'],
                                new_captcha: response['data']['data']['new_captcha'],
                                offline: !response['data']['data']['success'],
                                product: 'bind'
                            }, function(captchaObj){
                                captchaObj.onReady(function(){
                                    captchaObj.verify();
                                }).onSuccess(function(){
                                    //_this.${Message}.success(jzsjiale_lang['msg_captcha_success']);
                                    axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                                        module: 'geetestverify',
                                        version: 1,
                                        geetest_challenge: captchaObj.getValidate().geetest_challenge,
                                        geetest_validate: captchaObj.getValidate().geetest_validate,
                                        geetest_seccode: captchaObj.getValidate().geetest_seccode,
                                        areacode: _this.ISMSFormItem.areacode,
                                        phone: _this.ISMSFormItem.phone,
                                        type: 4,
                                        clienttype: 'h5',
                                        t: (new Date()).getTime(),
                                        formhash:'{FORMHASH}'
                                    }))
                                        .then(function (response) {
                                            //console.log(response['data']);
                                            if(response['data']['code'] != 0){
                                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                                            }else{

                                                _this.btn_send = false;

                                                let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                                                sendsmsjiange = parseInt(sendsmsjiange);
                                                if(sendsmsjiange != "" && sendsmsjiange > 60){
                                                    _this.countdown = sendsmsjiange;
                                                }else{
                                                    _this.countdown = 60;
                                                }

                                                let auth_timetimer =  setInterval(()=>{
                                                    _this.countdown--;
                                                    if(_this.countdown<=0){
                                                        _this.btn_send = true;
                                                        clearInterval(auth_timetimer);
                                                    }
                                                }, 1000);

                                                _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                                            }

                                        })
                                        .catch(function (error) {
                                            //console.log(error);
                                            _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                                        });
                                }).onClose(function () {
                                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                                }).onError(function(){
                                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                                });
                            });
                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
                <!--{/if}-->
            },
            <!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
            tencentCaptchaCallback: function (res) {
                let _this = this;

                if(res.ret === 0 && !_.isEmpty(res.ticket) && !_.isEmpty(res.randstr)){
                    axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                        module: 'ticketverify',
                        version: 1,
                        ticket: res.ticket,
                        randstr: res.randstr,
                        areacode: _this.ISMSFormItem.areacode,
                        phone: _this.ISMSFormItem.phone,
                        type: 4,
                        formhash:'{FORMHASH}'
                    }))
                        .then(function (response) {
                            //console.log(response['data']);
                            if(response['data']['code'] != 0){
                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                            }else{

                                _this.btn_send = false;

                                let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                                sendsmsjiange = parseInt(sendsmsjiange);
                                if(sendsmsjiange != "" && sendsmsjiange > 60){
                                    _this.countdown = sendsmsjiange;
                                }else{
                                    _this.countdown = 60;
                                }

                                let auth_timetimer =  setInterval(()=>{
                                    _this.countdown--;
                                    if(_this.countdown<=0){
                                        _this.btn_send = true;
                                        clearInterval(auth_timetimer);
                                    }
                                }, 1000);

                                _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                            }

                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                        });

                }else if(res.ret === 2){
                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                }else{
                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                }

            },
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
            vaptchaCallback: function (token) {
                let _this = this;

                if(!_.isEmpty(token)){
                    axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                        module: 'vaptchaverify',
                        version: 1,
                        token: token,
                        areacode: _this.ISMSFormItem.areacode,
                        phone: _this.ISMSFormItem.phone,
                        type: 4,
                        formhash:'{FORMHASH}'
                    }))
                        .then(function (response) {
                            //console.log(response['data']);
                            if(response['data']['code'] != 0){
                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                            }else{

                                _this.btn_send = false;

                                let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                                sendsmsjiange = parseInt(sendsmsjiange);
                                if(sendsmsjiange != "" && sendsmsjiange > 60){
                                    _this.countdown = sendsmsjiange;
                                }else{
                                    _this.countdown = 60;
                                }

                                let auth_timetimer =  setInterval(()=>{
                                    _this.countdown--;
                                    if(_this.countdown<=0){
                                        _this.btn_send = true;
                                        clearInterval(auth_timetimer);
                                    }
                                }, 1000);

                                _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                            }

                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                        });

                }else if(res.ret === 2){
                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                }else{
                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                }

            },
            <!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
            cloudTencentCaptchaCallback: function (res) {
                let _this = this;

                if(res.ret === 0 && !_.isEmpty(res.ticket) && !_.isEmpty(res.randstr)){
                    axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                        module: 'cloudtencentverify',
                        version: 1,
                        ticket: res.ticket,
                        randstr: res.randstr,
                        areacode: _this.ISMSFormItem.areacode,
                        phone: _this.ISMSFormItem.phone,
                        type: 4,
                        formhash:'{FORMHASH}'
                    }))
                        .then(function (response) {
                            //console.log(response['data']);
                            if(response['data']['code'] != 0){
                                _this.${Message}.error(jzsjiale_lang[response['data']['msg']]);
                            }else{

                                _this.btn_send = false;

                                let sendsmsjiange = "{$_G['cache']['plugin']['jzsjiale_isms']['g_sendsmsjiange']}";
                                sendsmsjiange = parseInt(sendsmsjiange);
                                if(sendsmsjiange != "" && sendsmsjiange > 60){
                                    _this.countdown = sendsmsjiange;
                                }else{
                                    _this.countdown = 60;
                                }

                                let auth_timetimer =  setInterval(()=>{
                                    _this.countdown--;
                                    if(_this.countdown<=0){
                                        _this.btn_send = true;
                                        clearInterval(auth_timetimer);
                                    }
                                }, 1000);

                                _this.${Message}.success(jzsjiale_lang['msg_sendsms_success']);
                            }

                        })
                        .catch(function (error) {
                            //console.log(error);
                            _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                        });

                }else if(res.ret === 2){
                    _this.${Message}.info(jzsjiale_lang['msg_captcha_cancel']);
                }else{
                    _this.${Message}.error(jzsjiale_lang['msg_captcha_fail']);
                }

            },
            <!--{/if}-->
            <!--{/if}-->
            lostpasswdPhoneVerify: function(){
                let _this = this;
                if(_.isEmpty(_this.ISMSFormItem.areacode) || !_.isAreaCode(_this.ISMSFormItem.areacode)){
                    _this.err_phone = true;
                    _this.msg_phone = jzsjiale_lang['msg_areacode_error'];
                    return;
                }
                if(_.isEmpty(_this.ISMSFormItem.phone)){
                    _this.err_phone = true;
                    _this.msg_phone = jzsjiale_lang['msg_phone_empty'];
                    return;
                }else if(!_.isMobilePhone(_this.ISMSFormItem.areacode,_this.ISMSFormItem.phone)){
                    _this.err_phone = true;
                    _this.msg_phone = jzsjiale_lang['msg_phone_formaterror'];
                    return;
                }else{
                    _this.err_phone = false;
                    _this.msg_phone = "";
                    return;
                }
            },
            lostpasswdSeccodeVerify: function(){
                let _this = this;
                if(_.isEmpty(_this.ISMSFormItem.seccode)){
                    _this.err_seccode = true;
                    _this.msg_seccode = jzsjiale_lang['msg_seccode_empty'];
                    return;
                }else if(!_.isSeccode(_this.ISMSFormItem.seccode)){
                    _this.err_seccode = true;
                    _this.msg_seccode = jzsjiale_lang['msg_seccode_formaterror'];
                    return;
                }else{
                    _this.err_seccode = false;
                    _this.msg_seccode = "";
                    return;
                }
            },
            toggleEmailStatus: function () {
                let _this = this;
                _this.lostpasswdEmailVerify();
            },
            lostpasswdEmailVerify: function(){
                let _this = this;

                if(_.isEmpty(_this.ISMSFormItem.email)){
                    _this.err_email = true;
                    _this.msg_email = jzsjiale_lang['msg_email_empty'];
                    return;
                }else if(!_.isEmail(_this.ISMSFormItem.email)){
                    _this.err_email = true;
                    _this.msg_email = jzsjiale_lang['msg_email_format_error'];
                    return;
                }else{
                    _this.err_email = false;
                    _this.msg_email = "";
                    return;
                }

            }
        }
    })
</script>
<!--{if $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 2}-->
<script>
    window.callback = function(res){
        //console.log(res);
        tencentCaptchaCallback(res);
    }
</script>
<!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 3}-->
<script>
    window.callback = function(token){
        //console.log(res);
        vaptchaCallback(token);
    }
</script>
<!--{elseif $_G['cache']['plugin']['jzsjiale_isms']['g_captcha'] == 5}-->
<script>
    window.callback = function(res){
        //console.log(res);
        cloudTencentCaptchaCallback(res);
    }
</script>
<!--{/if}-->
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/spa_optimization/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/spa_optimization/footer')}