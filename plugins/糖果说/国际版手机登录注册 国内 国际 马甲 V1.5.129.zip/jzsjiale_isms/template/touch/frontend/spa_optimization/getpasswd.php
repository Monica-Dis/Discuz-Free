<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/spa_optimization/header')}
<div id="mobile_jzsjiale_isms_lostpasswd_root">
    <main class="mobile_jzsjiale_i_sms_lostpasswd_main">
        <div class="mobile_jzsjiale_isms_main_content">
            <div class="mobile-header">
                <a href="{echo $_G['siteurl'];}" target="_self" class="close">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-guanbi"></use>
                    </svg>
                </a>
                <div class="mobile-header-title">
                    <!--{if $jsms_muban_mobile['title']}-->
                    {$jsms_muban_mobile['title']}
                    <!--{elseif $jsms_muban_mobile['logo']}-->
                    <img src="{$jsms_muban_mobile['logo']}" class="mobile_jzsjiale_isms_main_content_header_title_img"/>
                    <!--{else}-->
                    {lang jzsjiale_isms:title_and_logo_null}
                    <!--{/if}-->
                </div>
                <div class="mobile-header-desc">
                    {$jsms_muban_mobile['getpasswddesc']}
                </div>
            </div>
            <div class="mobile-content">
                <template>
                    <i-form :model="ISMSFormItem" @submit.native.prevent novalidate>
                        <div class="mobile-input">
                            <div class="ISMSForm-account">
                                <div class="ISMSForm-logintypeSelect">
                                    <div class="ISMSForm-logintype">

                                                    <span class="JSelect_logintype">
                                                        {lang jzsjiale_isms:tip_logintype_username}
                                                    </span>
                                    </div>
                                </div>
                                <span class="ISMSForm-accountSeperator">&nbsp;</span>
                                <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                    <div class="ISMSForm-accountInput Input-wrapper">
                                        <Input type="text" class="JInput" value="{$member[username]}" readonly/>
                                    </div>
                                </div>
                            </div>
                            <div class="ISMSForm-password">
                                <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                    <div class="Input-wrapper">
                                        <Input type="password" @input="togglePasswordStatus()" @focus="err_password = false" @blur="togglePasswordStatus()" v-model="ISMSFormItem.password" name="password" class="JInput" placeholder="{lang jzsjiale_isms:tip_password}"/>
                                    </div>
                                    <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_password }">
                                        {lang jzsjiale_isms:msg_mima_empty}
                                    </div>
                                </div>

                            </div>
                            <div class="ISMSForm-password">
                                <div class="ISMSFormInput ISMSForm-accountInputContainer">
                                    <div class="Input-wrapper">
                                        <Input type="password" @input="toggleRePasswordStatus()" @focus="err_repassword = false" @blur="toggleRePasswordStatus()" v-model="ISMSFormItem.repassword" name="repassword" class="JInput" placeholder="{lang jzsjiale_isms:tip_repassword}"/>
                                    </div>
                                    <div class="ISMSFormInput-errorMask ISMSFormInput-errorPasswordMask" :class="{ 'ISMSFormInput-errorMask-hidden' : !err_repassword }">
                                        {{ msg_repassword }}
                                    </div>
                                </div>

                            </div>
                        </div>
                        <button type="primary" @click="handleSubmit()" class="JButton ISMSForm-submitButton">
                            {lang jzsjiale_isms:btn_getpasswd}
                        </button>
                    </i-form>
                </template>
            </div>
            <div class="otherbtn">
                <a href="member.php?mod={$_G[setting][regname]}" target="_self">{lang jzsjiale_isms:register_title}</a>
                <a href="member.php?mod=logging&action=login" target="_self">{lang jzsjiale_isms:login_title}</a>
            </div>

            <!--{if $jsms_muban_mobile['isshowsocial']}-->
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/spa_optimization/social')}
            <!--{/if}-->
            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/spa_optimization/footer_content')}
        </div>
    </main>
</div>
<script>
    new Vue({
        el: '#mobile_jzsjiale_isms_lostpasswd_root',
        data: {
            ISMSFormItem: {
                password: '',
                repassword: ''
            },
            err_password: false,
            msg_password: "",
            err_repassword: false,
            msg_repassword: "",
            now_show_qrImage: false,
            referer: '{$dreferer}'
        },
        methods: {
            handleSubmit: function () {
                let _this = this;
                _this.lostPasswordVerify();
                _this.lostRePasswordVerify();
                if(_this.err_password || _this.err_repassword){
                    return false;
                }
                axios.post('{JZSJIALE_ISMS_PLUGIN_API}', Qs.stringify({
                    module: 'getpasswd',
                    version: 1,
                    getpasswdsubmit: 'yes',
                    discode: '32563',
                    hashid: '{$hashid}',
                    uid: '{$uid}',
                    sign: '{$_GET["sign"]}',
                    password: _this.ISMSFormItem.password,
                    repassword: _this.ISMSFormItem.repassword,
                    formhash:'{FORMHASH}',
                    device: 'mobile',
                    cookietime: 2592000,
                    referer: _this.referer
                }))
                    .then(function (response) {
                        //console.log(response['data']);
                        if(response['data']['code'] != 0){
                            if(response['data']['msg'] == 'msg_err_profile_password_tooshort'){
                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_profile_password_tooshort1']+response['data']['data']['pwlength']+jzsjiale_lang['msg_err_profile_password_tooshort2'],
                                    duration: 5
                                });
                            }else if(response['data']['msg'] == 'msg_err_password_weak'){
                                _this.${Message}.error({
                                    content: jzsjiale_lang['msg_err_password_weak']+': '+response['data']['data']['strongpw_str'],
                                    duration: 10
                                });
                            }else{
                                _this.${Message}.error({
                                    content: jzsjiale_lang[response['data']['msg']],
                                    duration: 5
                                });
                            }
                        }else{
                            _this.${Message}.success({
                                content: jzsjiale_lang['msg_getpasswd_succeed'],
                                duration: 5
                            });
                            let url_forward = !_.isEmpty(response['data']['data']['url_forward'])?response['data']['data']['url_forward']:'{$_G["siteurl"]}';
                            let location_timetimer =  setInterval(()=>{
                                window.location.href = url_forward;
                                clearInterval(location_timetimer);
                            }, 2000);


                        }

                    })
                    .catch(function (error) {
                        //console.log(error);
                        _this.${Message}.error(jzsjiale_lang['msg_request_fail']);
                    });
            },
            togglePasswordStatus: function () {
                let _this = this;
                _this.lostPasswordVerify();

            },
            toggleRePasswordStatus: function () {
                let _this = this;
                _this.lostRePasswordVerify();

            },
            lostPasswordVerify: function(){
                let _this = this;

                if(_.isEmpty(_this.ISMSFormItem.password)){
                    _this.err_password = true;
                    _this.msg_password = jzsjiale_lang['msg_password_empty'];
                    return;
                }else{
                    _this.err_password = false;
                    _this.msg_password = "";
                    return;
                }

            },
            lostRePasswordVerify: function(){
                let _this = this;

                if(_.isEmpty(_this.ISMSFormItem.repassword)){
                    _this.err_repassword = true;
                    _this.msg_repassword = jzsjiale_lang['msg_password_empty'];
                    return;
                }else if(_this.ISMSFormItem.password != _this.ISMSFormItem.repassword){
                    _this.err_repassword = true;
                    _this.msg_repassword = jzsjiale_lang['msg_password_different'];
                    return;
                }else{
                    _this.err_repassword = false;
                    _this.msg_repassword = "";
                    return;
                }

            }
        }
    })
</script>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/spa_optimization/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/spa_optimization/footer')}