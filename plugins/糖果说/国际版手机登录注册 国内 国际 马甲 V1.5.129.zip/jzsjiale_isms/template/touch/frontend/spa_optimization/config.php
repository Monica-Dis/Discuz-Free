<?php
/**
 * Created by jzsjiale.
 * User: jzsjiale
 * Date: 2019/9/18
 * Time: 10:47 AM
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$config = array(
    'dir'=>'spa_optimization',
    'title'=>'\u9ed8\u8ba4\u6a21\u677f\u4f18\u5316\u7248\u0020\u0031\u002e\u0031\u002e\u0032',
    'desc'=>'\u9ed8\u8ba4\u6a21\u677f\u4f18\u5316\u7248\uff0c\u4e3b\u8981\u4f18\u5316\u4e86\u4e09\u79cd\u767b\u5f55\u7c7b\u578b\u7684\u5207\u6362\u65b9\u5f0f\u3002'
);