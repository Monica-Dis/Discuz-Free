<?php if(!defined('IN_DISCUZ')) exit('JZSJIALE_ISMS Access Denied');?>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/header')}
<div id="mobile_jzsjiale_isms_login_root">
    <main class="mobile_jzsjiale_i_sms_login_main">
        <div class="mobile_jzsjiale_isms_main_content">
            <div class="mobile-header">
                <a href="{echo $_G['siteurl'];}" target="_self" class="close">
                    <svg class="icon" aria-hidden="true">
                        <use xlink:href="#icon-guanbi"></use>
                    </svg>
                </a>
                <div class="mobile-header-title">
                    <!--{if $jsms_muban_mobile['title']}-->
                    {$jsms_muban_mobile['title']}
                    <!--{elseif $jsms_muban_mobile['logo']}-->
                    <img src="{$jsms_muban_mobile['logo']}" class="mobile_jzsjiale_isms_main_content_header_title_img"/>
                    <!--{else}-->
                    {lang jzsjiale_isms:title_and_logo_null}
                    <!--{/if}-->
                </div>
                <div class="mobile-header-desc">
                    {$jsms_muban_mobile['logindesc']}
                </div>
            </div>
            <div class="mobile-content">
                <template>
                    <div class="ISMSForm-bbclosed">
                        <!--{if $closedreason = C::t('common_setting')->fetch('closedreason')}-->
                        <h3 class="ISMSForm-bbclosed-title">{$closedreason}</h3>
                        <!--{else}-->
                        <h3 class="ISMSForm-bbclosed-title">{lang jzsjiale_isms:tip_bbclosed_title}</h3>
                        <!--{/if}-->
                        <img src="{JZSJIALE_ISMS_PLUGIN_TEMPLATE_PC_PATH}/default/style/images/weihu.png" class="jzsjiale_isms_img_closed"/>

                    </div>
                </template>
            </div>

            {eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/footer_content')}
        </div>
    </main>
</div>
<script>
    new Vue({
        el: '#mobile_jzsjiale_isms_login_root',
        data: {
        },
        methods: {

        }
    })
</script>
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/lang_cn')}
{eval include template(JZSJIALE_ISMS_PLUGIN_ID.':frontend/default/footer')}