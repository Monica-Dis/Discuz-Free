<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/interface/qcloudsms/sdk/SmsSenderUtil.php';
include_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/interface/qcloudsms/sdk/SmsSingleSender.php';

use Qcloud\Sms\SmsSingleSender;

class QCLOUDSMSISMS
{

    public $appid;
    
    public $appkey;
    
    public function __construct($appid = "",$appkey = ""){
        $this->appid = $appid;
        $this->appkey = $appkey ;
    }
    
    
    public function smssend($areacode = '86',$phoneNumbers = "",$signName = "",$templateCode = "",$templateParam = "")
    {
        if(empty($phoneNumbers) || empty($signName) || empty($templateCode) || empty($templateParam)){
            return;
        }

        if(empty($areacode)){
            $areacode = '86';
        }


        date_default_timezone_set('Asia/Shanghai');

        try {

            $ssender = new SmsSingleSender($this->appid, $this->appkey);

            $result = $ssender->sendWithParam($areacode, $phoneNumbers, $templateCode,
                $templateParam, $signName, "", "");  // 签名参数未提供或者为空时，会使用默认签名发送短信

            return $result;
        }catch (Exception $e) {
          return  $e->getMessage();
        }

    }
}