<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class SMSBAOISMS
{

    public $accesskeyid;

    public $accesskeysecret;

    public function __construct($accesskeyid = "",$accesskeysecret = ""){
        $this->accesskeyid = $accesskeyid;
        $this->accesskeysecret = $accesskeysecret ;
    }
    
    
    public function smssend($areacode = '86',$phoneNumbers = "",$signName = "",$templateCode = "")
    {
        if(empty($phoneNumbers) || empty($signName) || empty($templateCode)){
            return;
        }

        if(empty($areacode)){
            $areacode = '86';
        }


        date_default_timezone_set('Asia/Shanghai');

        try {
            $accessKeyId = $this->accesskeyid;
            $accessKeySecret = $this->accesskeysecret;

            if($areacode == '86'){
                $smsapi = "http://api.smsbao.com/";
                $user = $accessKeyId;
                $pass = md5($accessKeySecret);
                $content = urlencode($signName.$templateCode);
                $phone = $phoneNumbers;
                $sendurl = $smsapi."sms?u=".$user."&p=".$pass."&m=".$phone."&c=".$content;
                $result =file_get_contents($sendurl);
            }else{
                $smsapi = "http://api.smsbao.com/";
                $user = $accessKeyId;
                $pass = md5($accessKeySecret);
                $content = urlencode($signName.$templateCode);
                $phone = urlencode("+".$areacode.$phoneNumbers);
                $sendurl = $smsapi."wsms?u=".$user."&p=".$pass."&m=".$phone."&c=".$content;
                $result =file_get_contents($sendurl);
            }

            return $result;
        }catch (Exception $e) {
            return  $e->getMessage();
        }

    }
}