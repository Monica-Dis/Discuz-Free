<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class SMSCNISMS
{

    public $accesskeyid;

    public $accesskeysecret;

    public function __construct($accesskeyid = "",$accesskeysecret = ""){
        $this->accesskeyid = $accesskeyid;
        $this->accesskeysecret = $accesskeysecret ;
    }


    public function smssend($areacode = '86',$phoneNumbers = "",$signName = "",$templateCode = "",$templateParam = "")
    {
        if(empty($phoneNumbers) || empty($signName) || empty($templateCode) || empty($templateParam)){
            return;
        }

        if(empty($areacode)){
            $areacode = '86';
        }


        date_default_timezone_set('Asia/Shanghai');

        try {
            $accessKeyId = $this->accesskeyid;
            $accessKeySecret = $this->accesskeysecret;

            if($areacode == '86'){
                $smsapi = "http://api.sms.cn/";
                $user = $accessKeyId;
                $pass = $accessKeySecret;
                $content = urlencode($templateParam);
                $phone = $phoneNumbers;
                $template = $templateCode;
                $sendurl = $smsapi."sms/?ac=send&uid=".$user."&pwd=".$pass."&mobile=".$phone."&content=".$content."&template=".$template;
                $result =file_get_contents($sendurl);
            }else{
                $smsapi = "http://api.sms.cn/";
                $user = $accessKeyId;
                $pass = $accessKeySecret;
                $content = urlencode($templateParam);
                $phone = $areacode.$phoneNumbers;
                $template = $templateCode;
                $sendurl = $smsapi."sms/?ac=sendint&uid=".$user."&pwd=".$pass."&mobile=".$phone."&content=".$content."&template=".$template;
                $result =file_get_contents($sendurl);
            }

            return $result;
        }catch (Exception $e) {
            return  $e->getMessage();
        }

    }
}