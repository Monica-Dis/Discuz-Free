<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class CheckphoneHcIp
{
    function getphone_hc_ip($phone="") {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_isms'];
        $g_checkip = $_config['g_checkip'];
        $g_appcode = $_config['g_appcode'];
        $webbianma = $_G['charset'];
        $ret_phone_info = array();


        if($g_checkip == 10){

            $phoneInfo = array();
            $phoneInfo = $this->get_phone_data($phone,$g_appcode);
            $ret_phone_info['province'] = $this->getbianma($phoneInfo['prov'],$webbianma);
            $ret_phone_info['city'] = $this->getbianma($phoneInfo['city'],$webbianma);
            $ret_phone_info['operator'] = $this->getbianma($phoneInfo['isp'],$webbianma);


            $ipInfo = $this->get_client_ip();

            $ret_phone_info = $ret_phone_info['province'].'-'.$ret_phone_info['city'].'-'.$ret_phone_info['operator'].' / '.$ipInfo;

            return $ret_phone_info;
        }else{
            $ret_phone_info = "null";
            return $ret_phone_info;
        }



    }

    private function get_phone_data($phone="",$appcode=""){
        $host = "https://api04.aliyun.venuscn.com";
        $path = "/mobile";
        $method = "GET";
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $appcode);
        $querys = "mobile=".$phone;
        $bodys = "";
        $url = $host . $path . "?" . $querys;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        if (1 == strpos("$".$host, "https://"))
        {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }
        $data = curl_exec($curl);
        curl_close($curl);

        $phonedata = json_decode($data, true);
        if($phonedata['ret'] != '200' || empty($phonedata['ret'])){
            return false;
        }
        $data = $phonedata['data'];
        return $data;
    }

    //get ip
    private function get_client_ip()
    {
        global $_G;
        if (isset($_G['clientip']) and !empty($_G['clientip']))
        {
            return $_G['clientip'];
        }
        if (isset($_SERVER['HTTP_CLIENT_IP']) and !empty($_SERVER['HTTP_CLIENT_IP']))
        {
            return $_SERVER['HTTP_CLIENT_IP'];
        }
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) and !empty($_SERVER['HTTP_X_FORWARDED_FOR']))
        {
            return strtok($_SERVER['HTTP_X_FORWARDED_FOR'], ',');
        }
        if (isset($_SERVER['HTTP_PROXY_USER']) and !empty($_SERVER['HTTP_PROXY_USER']))
        {
            return $_SERVER['HTTP_PROXY_USER'];
        }
        if (isset($_SERVER['REMOTE_ADDR']) and !empty($_SERVER['REMOTE_ADDR']))
        {
            return $_SERVER['REMOTE_ADDR'];
        }
        else
        {
            return "0.0.0.0";
        }
    }

    private function getbianma($data, $webbianma = "gbk")
    {
        if ($webbianma == "gbk") {
            $data = diconv($data, 'UTF-8', 'GBK');
        }
        return $data;
    }
}
?>