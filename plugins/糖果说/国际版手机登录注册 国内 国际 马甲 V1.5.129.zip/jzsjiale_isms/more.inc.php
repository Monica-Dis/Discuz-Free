<?php
/**
 * Authorr:DisM!Ӧ������ dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * e-mail: 467783778@qq.com
 * dismall: https://dism.taobao.com/?@32563.developer
 * createtime: 201907021510
 * updatetime: 201907021652
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
loadcache('plugin');
global $_G, $lang;
$_config = $_G['cache']['plugin']['jzsjiale_isms'];

if(empty($_GET['module'])) {
    /////////tip start

    echo '<div class="colorbox"><h4>'.plang('aboutmodules').'</h4>'.
        '<table cellspacing="0" cellpadding="3"><tr>'.
        '<td valign="top">'.plang('modulesdescription').'</td></tr></table>'.
        '<div style="width:95%" align="right">'.plang('copyright').'</div></div>';

    /////////tip end

    showtableheader(plang('module_list'));
    showsubtitle(plang('module_list_title'));

    $modules = getModulesDir();
    $modules_arr = array();
    $modules_version_arr = array();
    foreach ($modules as $key => $value){
        showtablerow('', array('style="width:30px;"', 'style="width:150px;"', 'style="width:60px;"', 'style="width:200px;"', 'style="width:100px;"'), array(
                $key+1,
                unicodeDecode($value['title']),
                unicodeDecode($value['version']),
                unicodeDecode($value['desc']),
                '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=jzsjiale_isms&pmod=more&module='.$value['module'].'" style="color:red;">'.plang('module_open').'</a>')
        );
        $modules_arr[] = $value['module'];
        $modules_version_arr[$value['module']] = $value['version'];
    }

    showtablefooter(); /*Dism��taobao��com*/

    if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/httpcurl.php')){
        @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/httpcurl.php';
        header('Content-type:text/html;charset='.$_G['charset']);

        $httpcurl = new HttpCurl();

        $closessl = $_config['g_closessl'] ? 1 : 0;

        $url = "https://www.tangguoshuo.com/isms/sub.json";
        $params = array();
        $paramstring = http_build_query($params);
        $content = $httpcurl->hcurl($url,null, $paramstring,0,$closessl);
        $result = json_decode($content,true);

        echo "<br/><br/><br/>";

        showtableheader(plang('no_install_module_list'));
        showsubtitle(plang('module_list_title'));
        $not_install_index = 1;
        foreach ($result as $key1 => $value1){
            if(!in_array($value1['module'],$modules_arr) || (in_array($value1['module'],$modules_arr) && $value1['version'] > $modules_version_arr[$value1['module']])){
                showtablerow('', array('style="width:30px;"', 'style="width:150px;"', 'style="width:60px;"', 'style="width:200px;"', 'style="width:100px;"'), array(
                        $not_install_index,
                        unicodeDecode($value1['title']),
                        (in_array($value1['module'],$modules_arr) && $value1['version'] > $modules_version_arr[$value1['module']])?$modules_version_arr[$value1['module']].' -> <span style="color:red;">'.unicodeDecode($value1['version']).'</span>':unicodeDecode($value1['version']),
                        unicodeDecode($value1['desc']),
                        '<a href="'.$value1['url'].'" style="color:blue;">'.plang('no_install_module_view').'</a>')
                );
                $not_install_index++;
            }
        }
        showtablefooter(); /*Dism��taobao��com*/
    }

}else{
    $field = (!empty($_config['g_areacodefield']) && in_array($_config['g_areacodefield'], array('field1', 'field2', 'field3', 'field4', 'field5', 'field6', 'field7', 'field8')))?$_config['g_areacodefield']:'field8';

    if(file_exists(DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php')){
        @include_once DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/utils.class.php';
        $utils = new ISMSUtils();
    }else{
        cpmsg('jzsjiale_isms:module_utils_error', '', 'error');
    }

    $modulefile = DISCUZ_ROOT . './source/plugin/jzsjiale_isms/modules/'.$_GET['module'].'/'.$_GET['module'].'.inc.php';
    if(file_exists($modulefile)) {

        require_once $modulefile;
    }else{
        cpmsg('jzsjiale_isms:module_not_exists', '', 'error');
    }
}

function unicodeDecode($unicode_str)
{
    $json = '{"str":"' . $unicode_str . '"}';
    $arr = json_decode($json, true);
    if (empty($arr)) return '';
    global $_G;
    if($_G['charset'] == "gbk"){
        $arr['str'] = diconv($arr['str'],'UTF-8','GBK');
    }

    return $arr['str'];

}

function getModulesDir(){
    $moduledir = DISCUZ_ROOT.'./source/plugin/jzsjiale_isms/modules';
    $modulesdir = dir($moduledir);
    $modules = array();

    while($entry = $modulesdir->read()) {
        if(!in_array($entry, array('.', '..')) && is_dir($moduledir.'/'.$entry)) {

            $entrydir = $moduledir.'/'.$entry;
            if(file_exists($entrydir.'/config.php')) {
                @include_once $entrydir.'/config.php';

                if(!empty($config) && $config != null){
                    $modules[] = $config;
                }
            }

        }
    }
    return $modules;
}
function plang($str) {
    return lang('plugin/jzsjiale_isms', $str);
}