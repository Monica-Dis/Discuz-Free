<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_jzsjiale_qzsms {
	//TODO - Insert your code here
    function common()
    {
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_qzsms'];

        if (!$_config['g_isopen'] || $_G['groupid'] != 7 || ($_G['basescript'] == 'plugin' && CURMODULE == 'jzsjiale_sms') || ($_G['basescript'] == 'plugin' && CURMODULE == 'jzsjiale_isms') || ($_G['basescript'] == 'plugin' && in_array(CURMODULE, explode(',',$_config['g_mianplugins']))) || ($_G['basescript'] == 'misc' && CURMODULE == 'seccode') || ($_G['basescript'] == 'member' && in_array(CURMODULE, array('register','logging','lostpasswd','getpasswd'))) || ($_G['basescript'] == 'connect' && CURMODULE == 'login')) {
            return;
        }else{
            $url ="member.php?mod=logging&action=login";
            if($_config['g_plugin'] == 'isms'){
                $url ="member.php?mod=logging&action=login";
            }elseif ($_config['g_plugin'] == 'sms'){
                $url ="member.php?mod=logging&action=login&phonelogin=yes";
            }else{
                $url ="member.php?mod=logging&action=login";
            }
            header("Location: $url");
            die(0);
        }
    }
}
//From: Dism_taobao_com
?>