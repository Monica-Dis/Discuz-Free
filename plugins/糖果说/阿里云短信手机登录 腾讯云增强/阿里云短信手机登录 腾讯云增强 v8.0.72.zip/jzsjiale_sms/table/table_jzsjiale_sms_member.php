<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_jzsjiale_sms_member extends discuz_table
{
	public function __construct() {
		$this->_table = 'common_member_profile';
		$this->_pk    = 'uid';
		parent::__construct(); /*dism - taobao - com*/
	}

	
	public function fetch_by_mobile($phone) {
	    $user = array();
	    if($phone) {
	        $user = DB::fetch_first('SELECT * FROM %t WHERE mobile=%s', array($this->_table, $phone));
	    }
	    return $user;
	}

    public function fetch_archive_by_mobile($phone) {
        $user = array();
        if($phone) {
            $user = DB::fetch_first('SELECT * FROM '.DB::table("common_member_profile_archive").'  WHERE mobile=%s', array($phone));
        }
        return $user;
    }
   
	public function fetch_by_uid($uid) {
	    $user = array();
	    if($uid) {
	        $user = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array($this->_table, $uid));
	    }
	    return $user;
	}
	
	public function fetch_member_by_uid($uid) {
	    $user = array();
	    if($uid) {
	        $user = DB::fetch_first('SELECT * FROM '.DB::table('common_member').' WHERE uid='.$uid);
	    }
	    return $user;
	}

    public function fetch_all_with_username_and_mobile($map = array(),$start = 0, $limit = 0, $sort = '') {
        $dzuserlist = array();
        $wheresql = " 1=1 ";

        foreach ($map as $mapkey => $mapvalue){
            if($mapkey == "keyword"){
                $wheresql .=  " and sf.mobile like '%".$mapvalue."%' or s.username like '%".$mapvalue."%' ";
            }elseif($mapkey == "status"){
                if($mapvalue == '1'){
                    $wheresql .=  ' and sf.mobile != \'\' ';
                }elseif($mapvalue == '0'){
                    $wheresql .=  ' and sf.mobile = \'\' ';
                }
            }else{
                $wheresql .=  ' and '.$mapkey.' = '.$mapvalue.' ';
            }

        }

        $dzuserlist = DB::fetch_all("SELECT sf.uid as uid,sf.mobile as phone,s.email as email,sf.qq as qq,s.groupid as groupid,s.username as username,s.regdate as dateline
				FROM ".DB::table('common_member_profile')." sf
				RIGHT JOIN ".DB::table('common_member')." s USING(uid)
	            WHERE ".$wheresql.($sort ? ' ORDER BY s.uid '. $sort : '').DB::limit($start, $limit));

        return $dzuserlist;
    }

    public function count_all_with_username_and_mobile($map = array()) {

        $wheresql = " 1=1 ";
        foreach ($map as $mapkey => $mapvalue){
            if($mapkey == "keyword"){
                $wheresql .=  " and sf.mobile like '%".$mapvalue."%' or s.username like '%".$mapvalue."%' ";
            }elseif($mapkey == "status"){
                if($mapvalue == '1'){
                    $wheresql .=  ' and sf.mobile != \'\' ';
                }elseif($mapvalue == '0'){
                    $wheresql .=  ' and sf.mobile = \'\' ';
                }
            }else{
                $wheresql .=  ' and '.$mapkey.' = '.$mapvalue.' ';
            }

        }
        $count = (int) DB::result_first("SELECT count(*)
				FROM ".DB::table('common_member_profile')." sf
				RIGHT JOIN ".DB::table('common_member')." s USING(uid)
	            WHERE ".$wheresql);

        return $count;
    }


    public function fetch_all_with_username_and_mobile_chachong($start = 0, $limit = 0, $sort = '') {
        $dzuserlist = array();

        $dzuserchongfulist = DB::fetch_all("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE mobile <> '' GROUP BY mobile having count(1)>1");

        $mobiles = array();
        foreach ($dzuserchongfulist as $dzuserdata){
            if(!empty($dzuserdata['mobile'])){
                $mobiles[]=$dzuserdata['mobile'];
            }

        }

        if (!empty($mobiles)){
            $dzuserlist = DB::fetch_all("SELECT sf.uid as uid,sf.mobile as phone,s.email as email,sf.qq as qq,s.groupid as groupid,s.username as username,s.regdate as dateline
				FROM ".DB::table('common_member_profile')." sf
				RIGHT JOIN ".DB::table('common_member')." s USING(uid)
	            WHERE sf.mobile in (".dimplode($mobiles).") ".($sort ? ' ORDER BY sf.mobile ASC,s.uid '. $sort : '').DB::limit($start, $limit));

        }

        return $dzuserlist;
    }

    public function count_all_with_username_and_mobile_chachong() {

        $count = 0;
        $dzuserchongfulist = DB::fetch_all("SELECT mobile FROM ".DB::table('common_member_profile')." WHERE mobile <> '' GROUP BY mobile having count(1)>1");

        $mobiles = array();
        foreach ($dzuserchongfulist as $dzuserdata){
            if(!empty($dzuserdata['mobile'])){
                $mobiles[]=$dzuserdata['mobile'];
            }
        }

        if (!empty($mobiles)){
            $count = (int) DB::result_first("SELECT count(*)
    				FROM ".DB::table('common_member_profile')." sf
    				RIGHT JOIN ".DB::table('common_member')." s USING(uid)
    	            WHERE sf.mobile in (".dimplode($mobiles).") ");
        }
        return $count;
    }



    public function fetch_all_with_username_and_mobile_verify($map = array(),$start = 0, $limit = 0, $sort = '',$verify = 1) {
        $dzuserlist = array();
        $wheresql = " 1=1 ";

        foreach ($map as $mapkey => $mapvalue){
            if($mapkey == "keyword"){
                $wheresql .=  " and sf.mobile like '%".$mapvalue."%' or s.username like '%".$mapvalue."%' ";
            }elseif($mapkey == "status"){
                if($mapvalue == '1'){
                    $wheresql .=  ' and sv.verify'.$verify.' = 1 ';
                }elseif($mapvalue == '0'){
                    $wheresql .=  ' and (sv.verify'.$verify.' != 1 or sv.uid is null) ';
                }
            }else{
                $wheresql .=  ' and '.$mapkey.' = '.$mapvalue.' ';
            }

        }

        $dzuserlist = DB::fetch_all("SELECT sf.uid as uid,sf.mobile as phone,s.email as email,sf.qq as qq,s.groupid as groupid,s.username as username,s.regdate as dateline,sv.verify".$verify." as verify
				FROM (".DB::table('common_member')." s
				LEFT JOIN ".DB::table('common_member_profile')." sf USING(uid))
	            LEFT JOIN ".DB::table('common_member_verify')." sv USING(uid)
	            WHERE ".$wheresql.($sort ? ' ORDER BY s.uid '. $sort : '').DB::limit($start, $limit));

        return $dzuserlist;
    }

    public function count_all_with_username_and_mobile_verify($map = array(),$verify = 1) {

        $wheresql = " 1=1 ";
        foreach ($map as $mapkey => $mapvalue){
            if($mapkey == "keyword"){
                $wheresql .=  " and sf.mobile like '%".$mapvalue."%' or s.username like '%".$mapvalue."%' ";
            }elseif($mapkey == "status"){
                if($mapvalue == '1'){
                    $wheresql .=  ' and sv.verify'.$verify.' = 1 ';
                }elseif($mapvalue == '0'){
                    $wheresql .=  ' and (sv.verify'.$verify.' != 1 or sv.uid is null) ';
                }
            }else{
                $wheresql .=  ' and '.$mapkey.' = '.$mapvalue.' ';
            }

        }
        $count = (int) DB::result_first("SELECT count(*)
				FROM (".DB::table('common_member')." s
				LEFT JOIN ".DB::table('common_member_profile')." sf USING(uid))
	            LEFT JOIN ".DB::table('common_member_verify')." sv USING(uid)
	            WHERE ".$wheresql);

        return $count;
    }
	
	public function count_by_isexists_mobile($isexistsmobile=true) {
	    $where = " ";
	    if($isexistsmobile){
	        $where .= " mobile is not null and mobile <> '' ";
	    }else{
	        $where .= " mobile is null or mobile = '' ";
	    }
	    $count = (int) DB::result_first("SELECT count(*) FROM ".DB::table($this->_table).' WHERE '.$where);
	    return $count;
	}
	
	public function range_by_isexists_mobile($isexistsmobile=true,$start = 0, $limit = 0, $sort = '') {
	    $where = " ";
	    if($isexistsmobile){
	        $where .= " mobile is not null and mobile <> '' ";
	    }else{
	        $where .= " mobile is null or mobile = '' ";
	    }
	    if($sort) {
	        $this->checkpk();
	    }
	    return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' WHERE '.$where.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
	
	
	public function count_common_member_verify() {
	    $count = (int) DB::result_first("SELECT count(*) FROM ".DB::table('common_member_verify'));
	    return $count;
	}
	
	public function range_common_member_verify($start = 0, $limit = 0, $sort = '') {
	    if($sort) {
	        $this->checkpk();
	    }
	    return DB::fetch_all('SELECT * FROM '.DB::table('common_member_verify').($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}
}
//From: Dism_taobao_com
?>