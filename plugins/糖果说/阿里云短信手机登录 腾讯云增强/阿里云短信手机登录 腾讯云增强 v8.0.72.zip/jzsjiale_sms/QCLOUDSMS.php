<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_sms/qcloudsms/SmsSenderUtil.php';
include_once  DISCUZ_ROOT.'./source/plugin/jzsjiale_sms/qcloudsms/SmsSingleSender.php';

use Qcloud\Sms\SmsSingleSender;

class QCLOUDSMSSMS
{

    public $appid;
    
    public $appkey;
    
    public function __construct($appid = "",$appkey = ""){
        $this->appid = $appid;
        $this->appkey = $appkey ;
    }
    
    
    public function smssend($phoneNumbers = "",$signName = "",$templateCode = "",$templateParam = "")
    {
        if(empty($phoneNumbers) || empty($signName) || empty($templateCode) || empty($templateParam)){
            return;
        }

        date_default_timezone_set('Asia/Shanghai');

        try {

            $ssender = new SmsSingleSender($this->appid, $this->appkey);

            $result = $ssender->sendWithParam("86", $phoneNumbers, $templateCode,
                $templateParam, $signName, "", "");  // 签名参数未提供或者为空时，会使用默认签名发送短信

            return $result;
        }catch (Exception $e) {
          return  $e->getMessage();
        }

    }
}