<?php
/**
 * admin_invite.inc.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-3
 * Time: 下午11:13
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$act = isset($_GET['act']) ? trim($_GET['act']) : '';

loadcache("cache");

if($act == "backup"){
    $tables = array(
        'invite_aboc','invite_exchange_log','invite_goods','invite_poster','invite_mobile',
    );
    $sql = '';
    foreach($tables as $v){
        $sql .= "TRUNCATE ".DB::table($v).";\r\n";
        $rows = DB::fetch_all("SELECT * FROM ".DB::table($v));
        foreach($rows as $v2){
            $sql .= "INSERT INTO `".DB::table($v)."` ";
            $temp = array();
            foreach($v2 as $k3=>$v3){
                $temp[$k3] = "'".addcslashes($v3,"'")."'";
            }
            $sql .= "(".join(',',array_keys($temp)).") VALUES(".join(',',$temp).");\r\n";
        }
    }
    $rows = DB::fetch_all("SELECT uid,invite_change,invite_num FROM ".DB::table("common_member")." WHERE invite_change!=0 OR invite_num!=0");
    foreach($rows as $v){
        $sql .= "UPDATE ".DB::table("common_member")." SET invite_change='{$v['invite_change']}',invite_num='{$v['invite_num']}' WHERE uid='{$v['uid']}';\r\n";
    }
    $sql .= "\r\n\r\n";
    if(strtolower(CHARSET)!='utf-8'){
        $sql = iconv(CHARSET,'utf-8',$sql);
    }
    ob_end_clean();
    ob_start();
    $filename = 'invite_aboc_backup'.date("Y-m-d").'.sql';
    header("Content-type:application/txt");
    header("Content-Disposition:attachment;filename=\"$filename\"");
    echo $sql;
    echo "\r\n";
    exit;
}
if(submitcheck('reduction')){
    if($_FILES['file']['error'] != UPLOAD_ERR_OK){
        cpmsg_error(lang('plugin/invite_aboc', 'aboc105'));
    }
    if(substr(strtolower($_FILES['file']['name']),-4)!='.sql'){
        cpmsg_error(lang('plugin/invite_aboc', 'aboc106'));
    }
    $content = file_get_contents($_FILES['file']['tmp_name']);
    if(strtolower(CHARSET)!='utf-8'){
        $content = iconv('utf-8',CHARSET,$content);
    }
    $content = substr($content,0,-22);
    runquery($content);
    cpmsg(lang('plugin/invite_aboc', 'aboc107'));
    exit;
}

showformheader("plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_backup",'enctype');
showtableheader(lang('plugin/invite_aboc', 'aboc108'));
showtablerow('',array(),array(lang('plugin/invite_aboc', 'aboc109'),'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=invite_aboc&act=backup&pmod=admin_backup">'.lang('plugin/invite_aboc', 'aboc110').'</a>'));
$formhash = FORMHASH;
$selectfile = lang('plugin/invite_aboc', 'aboc112');
$huanyuan = lang('plugin/invite_aboc', 'aboc111');
$str = <<<DDD
{$selectfile}:<input type="file" name="file" id="file" style="border:none;" />
<input type="hidden" name="formhash" value="{$formhash}" />
<input type="submit" value="{$huanyuan}" name="reduction" id="reduction" class="btn">
DDD;

showtablerow('',array(),array(lang('plugin/invite_aboc', 'aboc111'),$str));
showtablefooter(); /*dism - taobao - com*/ /*dism·taobao·com*/
showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/