<?php
/**
 * public.inc.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 17-4-15
 * Time: 上午11:15
 * Ver : 1.0.0
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache("plugin");
$invite_setting = C::t("#invite_aboc#invite_aboc")->get_setting();
$_G['cache']['plugin']['invite_aboc'] = array_merge($_G['cache']['plugin']['invite_aboc'],$invite_setting);
$invite_setting = $_G['cache']['plugin']['invite_aboc'];
//debug($invite_setting);