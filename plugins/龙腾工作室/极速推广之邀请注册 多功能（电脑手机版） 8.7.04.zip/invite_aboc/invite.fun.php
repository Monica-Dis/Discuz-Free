<?php
/**
 * invite.fun.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 16-8-21
 * Time: 下午11:31
 * Ver : 1.0.0
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function output_json($error,$msg='',$other=array()){
	$data = array(
		'error' => $error,
		'msg'   => $msg,
		'other' => $other,
	);
	if(CHARSET != 'utf-8'){
		$data = invite_iconv($data,CHARSET,'utf-8');
	}
	echo json_encode($data);exit;
}

function invite_iconv($str,$inchar='utf-8',$outchar='gbk'){
	if(is_array($str)){
		$newstr = array();
		foreach ($str as $key=>$row){
			$newstr[$key] = invite_iconv($row,$inchar,$outchar);
		}
	}
	else{
		$newstr = iconv($inchar,$outchar,$str);
	}
	return $newstr;
}


function invite_send_sms($mobile,$code){
	$setting = $GLOBALS['_G']['cache']['plugin']['invite_aboc'];
	include_once  dirname(__FILE__) ."/aliyu/TopSdk.php";
	include_once  dirname(__FILE__) ."/aliyu/top/TopClient.php";
	include_once  dirname(__FILE__) ."/aliyu/top/request/AlibabaAliqinFcSmsNumSendRequest.php";
	include_once  dirname(__FILE__) ."/aliyu/top/ResultSet.php";
	include_once  dirname(__FILE__) ."/aliyu/top/RequestCheckUtil.php";
	$c = new TopClient;
	$c->appkey = $setting["Appkey"];
	$c->secretKey = $setting["SecretKey"];
	$req = new AlibabaAliqinFcSmsNumSendRequest;
	$req->setExtend();
	$req->setSmsType("normal");
	$req->setSmsFreeSignName($setting["SignName"]);
	$req->setSmsParam(json_encode(array(
		"code" => $code
	)));
	$req->setRecNum($mobile);
	$req->setSmsTemplateCode($setting["SmsTemplateCode"]);
	$resp = $c->execute($req);
	$res=json_encode($resp);
	$obj=json_decode($res,true);
	if(isset($obj['result']['err_code']) && $obj['result']['err_code'] == 0){
		return true;
	} else {
		return $obj['msg'].$obj['sub_msg'];
	}


}

function get_menu(){
    $menus = array(
        'menu1' => array(lang('plugin/invite_aboc', 'menu1'),''),
        'menu2' => array(lang('plugin/invite_aboc', 'menu2'),'list'),
        'menu3' => array(lang('plugin/invite_aboc', 'menu3'),'doexchange'),
        'menu4' => array(lang('plugin/invite_aboc', 'menu4'),'exchange'),
        'menu5' => array(lang('plugin/invite_aboc', 'menu5'),'share'),
        'menu6' => array(lang('plugin/invite_aboc', 'menu6'),'top'),
    );
    $config = C::t("common_setting")->fetch("invite_aboc_menu" , true);
    $config = array_filter($config);
    if(!$config){
        foreach($menus as $key => $menu){
            $menus[$key][2] = $menu[0];
        }
        return $menus;
    }
    $result = array();
    foreach($config as $key => $title) {
        if(isset($menus[$key])){
            $menus[$key][2] = $title;
            $result[$key] = $menus[$key];
        }
    }
    return $result;
}


function invite_init_session(){
	if (!session_id()) session_start();
}

/**
 * @param $uids
 *
 * @author aboc
 * @return array
 */
function get_users($uids){
	$uids = array_filter($uids);
	if(!$uids){
		return array();
	}
	$rows = DB::fetch_all("SELECT * FROM ".DB::table("common_member")." WHERE uid IN(".join(',',$uids).")");
	$data = array();
	foreach($rows as $v){
		$data[$v['uid']] = $v;
	}
	return $data;
}

function file_ext($filename)
{
    return strtolower(trim(substr(strrchr($filename, '.'), 1, 10)));
}

if(!function_exists("exif_imagetype")){
    function exif_imagetype($filename){
        $ext = file_ext($filename);
        return $ext == "png" ? IMAGETYPE_PNG:IMAGETYPE_JPEG;
    }
}


function _imagecreate($filename){
//		$ext = strtolower(file_ext($filename));
	$check = exif_imagetype($filename);
	switch ($check){
		case IMAGETYPE_PNG:
			return imagecreatefrompng($filename);
			break;
		default:
			return imagecreatefromjpeg($filename);
			break;
	}
}