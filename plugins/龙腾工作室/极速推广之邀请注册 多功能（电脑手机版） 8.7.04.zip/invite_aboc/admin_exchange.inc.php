<?php
/**
 * admin_invite.inc.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-3
 * Time: 下午11:13
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$act = isset($_GET['act']) ? trim($_GET['act']) : '';
loadcache("cache");
$goods_types = array(
    'goods' => lang('plugin/invite_aboc', 'aboc47'),
    'extcredits'=>lang('plugin/invite_aboc', 'aboc48'),
    'group' => lang('plugin/invite_aboc', 'aboc49'),
);

if(submitcheck('del','post')){
    if(!isset($_GET['delete']) || !is_array($_GET['delete'])){
        cpmsg_error(lang('plugin/invite_aboc', 'sc'));
    }
    $_GET['delete'] = array_map("intval",$_GET['delete']);
    DB::delete("invite_exchange_log","log_id IN(".join(',',$_GET['delete']).")");
    cpmsg(lang('plugin/invite_aboc', 'sccg'));
}

if($act == "") {
    showformheader("plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_exchange","","sform","get");
    showtableheader();
    ?>
    <input name="action" value="plugins" type="hidden"/>
    <input name="operation" value="config" type="hidden"/>
    <input name="do" value="<?php echo $plguinid;?>" type="hidden"/>
    <input name="identifier" value="invite_aboc" type="hidden"/>
    <input name="pmod" value="admin_exchange" type="hidden"/>
    <table class="tb tb2 ">
        <tbody>
        <tr class="hover">
            <td style="width:430px;">
                <?php echo lang('plugin/invite_aboc', 'ss'); ?>
                <?php echo lang('plugin/invite_aboc', 'aboc50');?><select name="types" id="">
                    <option value="0"><?php echo lang('plugin/invite_aboc', 'aboc11');?></option>
                    <?php
                    foreach($goods_types as $k => $v){
                        $selected = $k==@$_GET['types']?' selected':'';
                        echo '<option value="'.$k.'" '.$selected.'>'.$v.'</option>';
                    }
                    ?>
                </select>
                <?php echo lang('plugin/invite_aboc', 'aboc51');?> <select name="status" id="status">
                    <option value="-2"><?php echo lang('plugin/invite_aboc', 'aboc11');?></option>
                    <option value="0" <?php echo @$_GET['status']=='0'?'selected':'' ?>><?php echo lang('plugin/invite_aboc', 'aboc52');?></option>
                    <option value="1" <?php echo @$_GET['status']=='1'?'selected':'' ?>><?php echo lang('plugin/invite_aboc', 'aboc53');?></option>
                    <option value="-1" <?php echo @$_GET['status']=='-1'?'selected':'' ?>><?php echo lang('plugin/invite_aboc', 'aboc54');?></option>
                </select>
                <?php echo lang('plugin/invite_aboc', 'aboc55');?><input type="text" value="<?php echo @$_GET['username']; ?>" name="username" style="width: 80px;" class="txt">
                <?php echo lang('plugin/invite_aboc', 'aboc56');?><input type="text" value="<?php echo @$_GET['keyword']; ?>" name="keyword" style="width: 80px;" class="txt">
                <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>"/>
                <input type="submit" name="do_action" value="<?php echo lang('plugin/invite_aboc', 'ss'); ?>" class="btn" />
            </td>
        </tr>
        </tbody>
    </table>
    <?php
    showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/
    $pagenum = 20;
    $page = isset($_GET['page'])?intval($_GET['page']):1;
    $where = " WHERE 1=1";
    if(isset($_GET['types']) && $_GET['types']){
        $where .= " AND g.types='{$_GET['types']}'";
    }
    if(isset($_GET['status']) && $_GET['status']!=-2){
        $where .= " AND l.status='{$_GET['status']}'";
    }
    if(isset($_GET['keyword']) && $_GET['keyword']){
        $where .= " AND l.name like '%{$_GET['keyword']}%'";
    }
    $total = DB::fetch_first("select count(log_id) as num from " . DB::table("invite_exchange_log") ." l LEFT JOIN ".DB::table("invite_goods")." g ON l.goods_id=g.goods_id ". $where);
    $total = isset($total['num']) ? $total['num'] : 0;
    $list = DB::fetch_all("select * from ".DB::table("invite_exchange_log")." l LEFT JOIN  " . DB::table("invite_goods") . " g ON l.goods_id=g.goods_id $where ORDER BY FIELD(l.status,0,1,-1),l.log_id DESC " . DB::limit(($page - 1) * $pagenum, $pagenum));
    foreach($list as $k => $v){
        $list[$k]['types'] = isset($goods_types[$v['types']])?$goods_types[$v['types']]:lang('plugin/invite_aboc', 'aboc57');
    }
    $pagelist = multi($total, $pagenum, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_exchange",ceil($total/$pagenum), 10,true);
    showformheader("plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_exchange");
    ?>
    <table class="tb tb2 ">
        <tbody>
        <tr class="header">
            <th style="width:20px;"></th>
            <th>ID</th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc19');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc58');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc59');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc60');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc63');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc61');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc62');?></th>
        </tr>
        <?php
        foreach($list as $v) {
            ?>
            <tr class="hover" id="reply_<?php echo $v['log_id'];?>">
                <td>
                    <input type="checkbox" value="<?php echo $v['goods_id'];?>" name="delete[]" class="checkbox">
                </td>
                <td><?php echo $v['log_id'];?></td>
                <td><?php echo $v['username'];?></td>
                <td><?php echo $v['types'];?></td>
                <td><?php echo $v['name'];?></td>
                <td><?php echo $v['invite_num'];?></td>
                <td><?php
                    switch($v['status']){
                        case 1:
                            echo lang('plugin/invite_aboc', 'aboc53');
                            break;
                        case -1:
                            echo lang('plugin/invite_aboc', 'aboc54');
                            break;
                        default:
                            echo lang('plugin/invite_aboc', 'aboc52');
                            break;
                    }
                    ?></td>
                <td><?php echo date("Y-m-d H:i:s",$v['add_time']);?></td>
                <td>
                    <?php
                    if($v['status'] == 0):
                    ?>
                    <a href="<?php ADMINSCRIPT ?>?action=plugins&operation=config&do=<?php echo $pluginid;?>&identifier=invite_aboc&pmod=admin_exchange&act=view&log_id=<?php echo $v['log_id'];?>"><?php echo lang('plugin/invite_aboc', 'aboc64');?></a>
                        <?php
                    else:
                        ?>
                        <a href="<?php ADMINSCRIPT ?>?action=plugins&operation=config&do=<?php echo $pluginid;?>&identifier=invite_aboc&pmod=admin_exchange&act=view&log_id=<?php echo $v['log_id'];?>"><?php echo lang('plugin/invite_aboc', 'aboc65');?></a>
                    <?php
                        endif;
                        ?>
                </td>
            </tr>
        <?php
        }
        ?>
        <tr><td class="td25">&nbsp;</td><td colspan="15"><div class="fixsel">
                    <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>" />
                    <input type="submit" value="<?php echo lang('plugin/invite_aboc', 'delete'); ?>" name="del" id="submit_submit" class="btn">
                </div></td></tr>
        </tbody>
    </table>
    <?php
    showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/
    ?>
    <table>
        <tbody>
        <tr>
            <td colspan="5">
                <div class="cuspages right">
                    <?php echo $pagelist; ?>
                </div>
            </td>
        </tr>
        </tbody>
    </table>
<?php
}
elseif($act=="view"){
    $log_id = isset($_GET['log_id'])?intval($_GET['log_id']):0;
    $info = C::t("#invite_aboc#invite_exchange_log")->fetch($log_id);
    if(!$info){
        cpmsg_error(lang('plugin/invite_aboc', 'aboc66'));
    }
    if(submitcheck('deal')){
        if($info['status']!=0){
            cpmsg_error(lang('plugin/invite_aboc', 'aboc67'));
        }
        $new_status = isset($_GET['new_status'])?intval($_GET['new_status']):0;
        if($new_status!=0){
            C::t("#invite_aboc#invite_exchange_log")->deal_exchange($log_id,$new_status==1?1:-1);
        }else{
            //
        }
        cpmsg(lang('plugin/invite_aboc', 'aboc68'));
    }
    showformheader("plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_exchange&act=view&log_id=".$info['log_id']);
    showtableheader(lang('plugin/invite_aboc', 'aboc69'));
    showtablerow('','',array(lang('plugin/invite_aboc', 'aboc70'),$info['username']));
    showtablerow('','',array(lang('plugin/invite_aboc', 'aboc71'),'<a href="".ADMINSCRIPT."?action=plugins&operation=config&do='.$pluginid.'&identifier=invite_aboc&pmod=admin_goods&act=add&goods_id='.$info['goods_id'].'">'.$info['name'].'</a>'));
    showtablerow('','',array(lang('plugin/invite_aboc', 'aboc72'),$info['invite_num']));
    if($info['attr']){
        $info['data'] = array();
        $info['attr'] = @unserialize($info['attr']);
        foreach($info['attr'] as $k => $v){
            $info['data'][] = $k.":".$v;
        }
        if($info['data']) {
            showtablerow( '', '', array( lang('plugin/invite_aboc', 'aboc73'), join( '<br/ >', $info['data'] ) ) );
        }
    }
    switch($info['status']){
        case 0:
            $info['status_name'] = lang('plugin/invite_aboc', 'aboc52');
            break;
        case 1:
            $info['status_name'] = lang('plugin/invite_aboc', 'aboc53');
            break;
        case -1:
            $info['status_name'] = lang('plugin/invite_aboc', 'aboc54');
            break;
    }
    showtablerow('','',array(lang('plugin/invite_aboc', 'aboc63'),$info['status_name']));
    if($info['status'] == 0){
        $info['new_status'] = array();
        $status = array(
            0=>lang('plugin/invite_aboc', 'aboc52'),
            1=>lang('plugin/invite_aboc', 'aboc53'),
            -1=>lang('plugin/invite_aboc', 'aboc54'),
        );
        foreach(array(0,1,-1) as $v){
            $info['new_status'][] = '<label><input type="radio" name="new_status" value="'.$v.'" '.($v==$info['status']?"checked":"").' />&nbsp;'.$status[$v].'</label>';
        }
        showtablerow('','',array(lang('plugin/invite_aboc', 'aboc74'),join('&nbsp;',$info['new_status'])));
        showtablerow('','',array("",'<input type="submit" name="deal" class="btn" value="'.lang('plugin/invite_aboc', 'aboc75').'" />&nbsp;&nbsp;<input type="button" class="btn" onclick="window.history.go(-1)" value="'.lang('plugin/invite_aboc', 'aboc76').'" />'));
    } else {
        showtablerow('','',array("",'<input type="button" class="btn" onclick="window.history.go(-1)" value="'.lang('plugin/invite_aboc', 'aboc76').'" />'));
    }
    ?>
    <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>"/>
<?php
    showtablefooter(); /*dism - taobao - com*/ /*dism·taobao·com*/
    showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/
}
//d'.'i'.'sm.ta'.'o'.'bao.com
?>
<script src="source/plugin/invite_aboc/template/jquery-1.7.2.min.js" /></script>
<script>
var ajQ = jQuery.noConflict(true);
ajQ(function(){
})
</script>