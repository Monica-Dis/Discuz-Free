<?php
/**
 * table_invite_goods.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-2
 * Time: 下午6:54
 */

class table_invite_exchange_log extends discuz_table {

    public $set = array();

    function __construct() {
        $this->_table = 'invite_exchange_log';
        $this->_pk    = 'log_id';
        parent::__construct(); /*dism·taobao·com*/
        global $_G;
        $this->set = $_G['cache']['plugin']['invite_aboc'];
    }

    /**
     * @param $goods_id
     * @param $_G
     * @param $invite_aboc
     *
     * @author aboc
     */
    function exchange( $goods_id) {
        global $_G;
        $invite_aboc = $this->set;
        $goods_info = C::t( "#invite_aboc#invite_goods" )->fetch( $goods_id );
        if ( ! $goods_info ) {
            return '-2|'.lang('plugin/invite_aboc', 'aboc34');
        }
        if ( $goods_info['stock'] <= 0 ) {
            return '-3|'.lang('plugin/invite_aboc', 'aboc35');
        }
        $userinfo = C::t("common_member")->fetch_by_username($_G['username']);
        $can_invite = $userinfo['invite_num'] -$userinfo['invite_change'];;
        if ( $can_invite < $goods_info['price'] ) {
            return '-4|'.lang('plugin/invite_aboc', 'aboc36');
        }
        $attr = array();
        $data = array(
            'uid'        => $_G['uid'],
            'username'   => $_G['username'],
            'goods_id'   => $goods_id,
            'status'     => 0,
            'name'       => addslashes($goods_info['title']),
            'attr'       => addslashes($attr),
            'add_time'   => TIMESTAMP,
            'number'     => 1,
            'invite_num' => intval($goods_info['price']),
        );
        $status = $invite_aboc['exchange_people'] ? 0 : 1;
        if ( $goods_info['types'] == 'goods' ) {
            $_GET['other'] = array_map( "trim", $_GET['other'] );
            $_GET['other'] = array_map( "addslashes", $_GET['other'] );
            $attr           = $_GET['other'];
            if ( ! isset( $attr[lang('plugin/invite_aboc', 'aboc37')] ) && $attr[lang('plugin/invite_aboc', 'aboc37')] == "" ) {
                return '-5|'.lang('plugin/invite_aboc', 'aboc38');
            }
            if ( ! isset( $attr[lang('plugin/invite_aboc', 'aboc39')] ) && $attr[lang('plugin/invite_aboc', 'aboc39')] == "" ) {
                return '-5|'.lang('plugin/invite_aboc', 'aboc40');
            }
            if ( ! isset( $attr[lang('plugin/invite_aboc', 'aboc41')] ) && $attr[lang('plugin/invite_aboc', 'aboc41')] == "" ) {
                return '-5|'.lang('plugin/invite_aboc', 'aboc42');
            }
            $data['attr'] = $attr;
        }
        $data['attr'] = serialize($data['attr']);
        if(DB::update("common_member",array(
            'invite_change' => $userinfo['invite_change']+$goods_info['price'],
        ),"uid='{$_G['uid']}'")){
            DB::query("UPDATE ".DB::table("invite_goods")." SET sales=sales+1,stock=stock-1 WHERE goods_id='$goods_id' LIMIT 1");
            $result =  DB::insert("invite_exchange_log",$data);
            if(!$result){
                return '-6|'.lang('plugin/invite_aboc', 'aboc43');
            }
            if($status == 1){
                //立即生效
                $this->deal_exchange(DB::insert_id(),$status);
                return '1|'.lang('plugin/invite_aboc', 'aboc44');
            } else {
                return '1|'.lang('plugin/invite_aboc', 'aboc45');
            }
        }else{
            return '0|'.lang('plugin/invite_aboc', 'aboc46');
        }
    }

    function deal_exchange($log_id,$status=1){
        $info = $this->get_info($log_id);
        if(!$info){
            return false;
        }
        if($info['status']!=0){
            return false;
        }
        $goods_info = C::t( "#invite_aboc#invite_goods" )->fetch( $info['goods_id'] );
        if(!$goods_info){
            return false;
        }
        switch($goods_info['types']){
            case 'goods':

                break;
            case 'extcredits':
                updatemembercount($info['uid'], array('extcredits' . $goods_info['attr'] => $goods_info['number']));
                break;
            case 'group':
                $this->update_user_group($info['uid'] , intval($goods_info['attr']) ,  $goods_info['day'] * 1);
                break;
        }
        if($status==-1){
            //拒绝,邀请返还
            $userinfo = C::t("common_member")->fetch_by_username($info['username']);
            DB::update("common_member",array(
                'invite_change'=> intval($userinfo['invite_change'] - $info['invite_num']),
            ),"uid='{$info['uid']}'");
        }
        $this->update($log_id,array(
            "status"=>1,
        ));
        return true;
    }

    function get_info($log_id){
        $row = DB::fetch_first("SELECT * FROM ".DB::table("invite_exchange_log")." WHERE log_id='$log_id' LIMIT 1");
        if($row){
            $row['attr'] = @unserialize($row['attr']);
        }
        return $row;
    }

    function get_last_list($limit = 10){
        $rows  = DB::fetch_all("SELECT username,name,invite_num FROM ".DB::table("invite_exchange_log")." ORDER BY log_id DESC LIMIT $limit");
        return $rows;
    }


    function update_user_group($uid, $newgroupid , $day ){
        require_once libfile('function/forum');
        $member = !empty($uid) ? C::t('common_member')->fetch($uid, false, 1) : C::t('common_member')->fetch_by_username($_GET['username'], 1);
        if(!$member) {
            return false;
        }
        $tableext = isset($member['_inarchive']) ? '_archive' : '';

        $membermf = C::t('common_member_field_forum'.$tableext)->fetch($uid);


        $main = array(
            'time' => $day > 0  ?  TIMESTAMP + $day * 86400 : 0,
            'adminid' => $member['adminid'],
            'groupid' => $member['groupid'],
        );
        $groupterms = array(
            "ext" => array(),
            "main" => array(),
        );

        if ( $membermf) {
            $result = @unserialize($membermf['groupterms']);
            if ( $result) {
                $groupterms = $result;
            }
        }

//        $groupterms["ext"][$newgroupid] = $day > 0  ?  TIMESTAMP + $day * 86400 : 0;
        $groupterms['main'] = $main;


        $grouptermsnew = serialize($groupterms);
        $groupexpirynew = groupexpiry($groupterms);

        C::t('common_member'.$tableext)->update($member['uid'], array('groupid'=>$newgroupid, 'groupexpiry'=>$groupexpirynew));
        if(C::t('common_member_field_forum'.$tableext)->fetch($member['uid'])) {
            C::t('common_member_field_forum'.$tableext)->update($member['uid'], array('groupterms' => $grouptermsnew));
        } else {
            C::t('common_member_field_forum'.$tableext)->insert(array('uid' => $member['uid'], 'groupterms' => $grouptermsnew));
        }

        return true;

    }


} 