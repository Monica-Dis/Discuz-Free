<?php
/**
 * table_invite_goods.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-2
 * Time: 下午6:54
 */

class table_invite_mobile extends discuz_table {

    public $set = array();

    function __construct() {
        $this->_table = 'invite_mobile';
        $this->_pk    = 'mobile';
        parent::__construct(); /*dism·taobao·com*/
        global $_G;
        $this->set = $_G['cache']['plugin']['invite_aboc'];
    }


    function check_mobile($mobile){
        return DB::fetch_first("SELECT * FROM %t WHERE mobile=%s ", array($this->_table, $mobile));
    }


} 