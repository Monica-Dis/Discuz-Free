<?php
/**
 * table_invite_goods.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-2
 * Time: 下午6:54
 */

class table_invite_goods extends discuz_table {

    public $set = array();

    function __construct() {
        $this->_table = 'invite_goods';
        $this->_pk    = 'goods_id';
        parent::__construct(); /*dism·taobao·com*/
        global $_G;
        $this->set = $_G['cache']['plugin']['invite_aboc'];
    }

    function add($f,$goods_id){
        $data = array(
            'types' => addslashes($f['types']),
            'title' => addslashes($f['title']),
            'number' => intval($f['number']),
            'stock'  => intval($f['stock']),
            'price'  => intval($f['price']),
            'description'=> addslashes($f['description']),
            'day'    => intval($f['day']),
        );
        if(!$goods_id){
            $data['add_time'] = TIMESTAMP;
        }
        if($data['types'] == 'group'){
            $data['number'] = 1;
            $data['attr'] = intval($f['groupid']);
        }
        if($data['types'] == 'extcredits'){
            $data['attr'] = intval($f['extcredits']);
        }
        if($goods_id){
            $this->update($goods_id,$data);
        } else {
            $goods_id = $this->insert( $data, true );
        }
        return $goods_id;
    }


    /**
     * @author aboc
     * @return array
     */
    function get_goods_list(){
        $rows = DB::fetch_all("SELECT goods_id,types,title,number,stock,attr,price,description FROM ".DB::table("invite_goods")." ORDER BY types ASC,goods_id ASC");
        foreach($rows as $k => $v){
            switch($v['types']){
                case 'goods':
                    $rows[$k]['types_name'] = lang('plugin/invite_aboc', 'aboc47');
                    break;
                case 'extcredits':
                    $rows[$k]['types_name'] = lang('plugin/invite_aboc', 'aboc48');
                    break;
                case 'group':
                    $rows[$k]['types_name'] = lang('plugin/invite_aboc', 'aboc49');
                    break;
            }
        }
        return $rows;
    }

} 