<?php

/**
 * table_invite_aboc.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-2
 * Time: 下午6:54
 */
class table_invite_aboc extends discuz_table {

	public $set = array();

	function __construct() {
		$this->_table = 'invite_aboc';
		$this->_pk    = 'uid';
		parent::__construct(); /*dism·taobao·com*/
		global $_G;
		loadcache("plugin");
		$invite_setting = $this->get_setting();


		$_G['cache']['plugin']['invite_aboc'] = array_merge($_G['cache']['plugin']['invite_aboc'],$invite_setting);
		$this->set                 = $_G['cache']['plugin']['invite_aboc'];
		$this->set['ban_group_id'] = @unserialize( $this->set['ban_group_id'] );
	}


	function update_fromuid( $uid, $username, $fromuid, $member ) {
		global $_G;
//       print_r($member);exit;
        if ( $uid == $fromuid  || $fromuid == 0) {
            dsetcookie( "promotion_u", "", 1800 );

            return;
        }

        $check_fromuid = $this->get_fromuid($uid);
        if($check_fromuid) {
            return;
        }


        $frominfo = C::t( "common_member" )->fetch( $fromuid );
		if ( ! $frominfo ) {
			return;
		}
		if( ( $_G['timestamp'] -  $member['regdate'])>180){
			return;
		}
		$status = 0;
//        if($this->set['invite_type'] == 1) {
//            if (DB::fetch_first("SELECT * FROM %t WHERE addip=%s LIMIT 1", array($this->_table, $_G['clientip']))) {
//                $status = 0;
//            } else {
//                $status = 1;
//            }
//            if($member['groupid'] == 8){
//                $status = 0;
//            }
//        }
		if ( ! DB::fetch_first( "SELECT * FROM %t WHERE uid='%d' AND fromuid='%d' LIMIT 1", array(
			$this->_table,
			$uid,
			$fromuid
		) )
		) {
			DB::insert( $this->_table, array(
				'uid'      => $uid,
				'username' => $username,
				'fromuid'  => $fromuid,
				'addtime'  => $_G['timestamp'],
				'addip'    => $_G['clientip'],
				'status'   => $status,
				'groupid'  => $member['groupid'],
				'level'    => 1,
				'integral' => 0,
			) );
			$fromuids = $this->get_invite_users( $uid );
			foreach ( $fromuids as $k => $v ) {
				if ( $k > 1 ) {
					DB::insert( $this->_table, array(
						'uid'      => $uid,
						'username' => $username,
						'fromuid'  => $v,
						'addtime'  => $_G['timestamp'],
						'addip'    => $_G['clientip'],
						'status'   => $status,
						'groupid'  => $member['groupid'],
						'level'    => $k,
						'integral' => 0,
					) );
				}
			}
		}
	}

	function get_fromuid_num( $fromuid, $status = 1, $temp = 0 ) {
		if ( $temp ) {
			$row = DB::fetch_first( "SELECT COUNT(uid) AS num FROM %t WHERE fromuid='%d' AND( (status=$status AND groupid=8) OR status='2')", array(
				$this->_table,
				$fromuid
			) );
		} else {
			$row = DB::fetch_first( "SELECT COUNT(uid) AS num FROM %t WHERE fromuid='%d' AND status=$status AND groupid!=8", array(
				$this->_table,
				$fromuid
			) );
		}

		return $row['num'];
	}

	function update_invite( $member ) {
		global $_G;
		if ( $this->set['invite_type'] == 3 ) {
			$status = 2;
			if ( $this->set['up_group'] ) {
				$extgroupids = $member['extgroupids'] ? explode("\t", $member['extgroupids']) : array();
				$membergroup = C::t('common_usergroup')->fetch_by_credits($member['credits']);
				if ( $member['groupid'] == $this->set['up_group'] || $membergroup['groupid'] == $this->set['up_group'] || (in_array($this->set['up_group'],$extgroupids) &&(!$member['groupexpiry'] || $member['groupexpiry']>TIMESTAMP)  )) {
						$status = 1;
				}
			} elseif ( $this->set['up_time'] ) {
				$member_count = C::t( "common_member_count" )->fetch( $member['uid'] );
				if ( $member_count && $member_count['oltime'] > 0 && $member_count['oltime'] >= ($this->set['up_time']/60) ) {
					$status = 1;
				}
			}
		}
		if ( $this->set['invite_type'] == 2 ) {
			DB::update( "common_member_profile", array( "mobile" => $member['mobile'] ), "uid='{$member['uid']}'" );
			DB::update( "common_member", array( "mobilestatus" => 1, "groupid" => 10 ), "uid='{$member['uid']}'" );
			if ( C::t( "#invite_aboc#invite_mobile" )->check_mobile( $member['mobile'] ) ) {
				return;
			}

			$status = 1;
			if ( DB::fetch_first( "SELECT * FROM %t WHERE addip=%s AND status=1 LIMIT 1", array(
				$this->_table,
				$_G['clientip']
			) )
			) {
				$status = 0;
			}
			DB::insert( "invite_mobile", array( "mobile" => $member['mobile'], "addtime" => TIMESTAMP ) );
			//
		}
		if ( $this->set['invite_type'] == 1 || $this->set['invite_type'] == 3 || $this->set['invite_type'] == 4 ) {
			if ( DB::fetch_first( "SELECT * FROM %t WHERE addip=%s AND status=1  LIMIT 1", array(
				$this->_table,
				$_G['clientip']
			) )
			) {
				$status = 0;
			}
		}
		if ( $this->set['invite_type'] ) {
			$data = array(
				'groupid' => $member['groupid'],
			);
			if (isset($status)){
				$data['status'] = $status;
			}
			DB::update( "invite_aboc", $data, "uid='{$member['uid']}' AND status IN(0,2)" );
			$from_users = $this->get_invite_users( $member['uid'] );
			$this->set_invite_num( $from_users, $member['uid'] );
		}

		return $status ? true : false;
	}

	/**
	 * save invite_aboc setting
	 *
	 * @param $data
	 *
	 * @author aboc
	 * @return mixed
	 */
	function save_setting($data){
		return C::t("common_setting")->update_batch(array("invite_aboc_s"=>$data));
	}

	/**
	 * get invite_aboc setting
	 *
	 * @author aboc
	 * @return mixed
	 */
	function get_setting(){
		$data = C::t("common_setting")->fetch("invite_aboc_s" ,true);
		if(!isset($data['invite_type'])){
			if(!is_array($data)){
				$data = array();
			}
			$data['invite_type'] = 3;
		}
		return $data;
	}


	function post_setting(){
		$options = array(
			"exchange_people",
			"invite_1",
			"invite_2",
			"invite_3",
			"invite_type",
			"explain_1",
			"explain_2",
			"explain_3",
			"invite_introduce",
			"Appkey",
			"Secretkey",
			"SmsTemplateCode",
			"SignName",
			"up_group",
			"up_time",
			"pay_1",
			"pay_2",
			"pay_3",
			"pay_type",
		);
		$data = $this->get_setting();
		foreach($options as $v){
			if(isset($_GET['varsnew'][$v])){
				$data[$v] = addslashes(trim($_GET['varsnew'][$v]));
			}
		}
		$this->save_setting($data);
	}

	function get_invite_users( $uid ) {
		$users = array();
		for ( $i = 1; $i <= 3; $i ++ ) {
			$uid = $this->get_fromuid( $uid );
			if ( $uid ) {
				$users[ $i ] = $uid;
			}
		}

		return $users;
	}

	function set_invite_num( $users, $uid ) {
		foreach ( $users as $k => $v ) {
			if ( isset( $this->set[ 'invite_' . $k ] ) && $this->set[ 'invite_' . $k ] ) {
				$num = abs( intval( $this->set[ 'invite_' . $k ] ) );
				if ( DB::update( "invite_aboc", array( "integral" => $num ), "uid='$uid' AND status='1' AND fromuid='$v' AND level='" . ( $k ) . "'" ) ) {
					DB::query( "UPDATE " . DB::table( "common_member" ) . " SET invite_num=invite_num+{$num} WHERE uid='$v'" );
				}
			}
		}
	}

	function get_from_user_list( $uid ) {
		$rows = DB::fetch_all( "SELECT fromuid,level FROM %t WHERE uid='%d' order by level asc", array(
			$this->_table,
			$uid
		) );
		if ( ! $rows ) {
			return array();
		}
		$ids = array();
		foreach ( $rows as $k => $v ) {
			$ids[ $v['level'] ] = $v['fromuid'];
		}
		$users = $this->get_fromuser( $ids );

		return $users;
	}

	function get_fromuid( $uid ) {
		$row = DB::fetch_first( "SELECT fromuid FROM %t WHERE uid='%d' AND `level`=1", array( $this->_table, $uid ) );

		return $row ? $row['fromuid'] : 0;
	}

	function get_fromuser( $uids ) {
		if ( ! $uids ) {
			return;
		}
		$rows  = DB::fetch_all( "SELECT uid,username,groupid FROM " . DB::table( "common_member" ) . " WHERE uid IN(" . join( ",", $uids ) . ")" );
		$users = array();
		foreach ( $rows as $v ) {
			$users[ $v['uid'] ] = $v;
		}
//        print_r($users);
		foreach ( $uids as $k => $v ) {
			$uids[ $k ] = isset( $users[ $v ] ) ? $users[ $v ] : array();
		}

		return $uids;
	}

	function change_invite( $username, $number ) {
		$userinfo = C::t( "common_member" )->fetch_by_username( $username );
		if ( ! $userinfo ) {
			return lang( 'plugin/invite_aboc', 'aboc30' );
		}
		$total = $this->get_fromuid_num( $userinfo['uid'] );
		$total -= $userinfo['invite_change'];
		if ( $number > $total ) {
			return lang( 'plugin/invite_aboc', 'aboc31' ) . $total;
		}
		if ( DB::update( "common_member", array(
			"invite_change" => $userinfo['invite_change'] + $number
		), "uid='{$userinfo['uid']}'" )
		) {
			return 1;
		} else {
			return lang( 'plugin/invite_aboc', 'aboc32' );
		}
	}

	function get_parent_uid($uid){
		$rows = DB::fetch_all( "SELECT fromuid,level FROM %t WHERE uid='%d' AND status=1 ORDER BY level ASC", array( $this->_table, $uid ) );
		if($rows ){
			$data = array();
			foreach($rows as $v){
				$data[$v['level']] = $v['fromuid'];
			}
			return $data;
		} else {
			return array();
		}
	}

	/**
	 * @param $mobile
	 *
	 * @author aboc
	 * @return array
	 */
	function check_mobile( $mobile ) {
		return DB::fetch_first( "SELECT m.uid FROM " . DB::table( "common_member" ) . " m LEFT JOIN " . DB::table( "common_member_profile" ) . " mp ON m.uid=mp.uid WHERE mobile='$mobile' AND mobilestatus=1" );
	}
} 