<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
/**
 * table_invite_goods.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-2
 * Time: 下午6:54
 */

class table_invite_poster extends discuz_table {

    public $set = array();

    function __construct() {
        $this->_table = 'invite_poster';
        $this->_pk    = 'poster_id';
        parent::__construct(); /*dism·taobao·com*/
        global $_G;
        $this->set = $_G['cache']['plugin']['invite_aboc'];
    }

    /**
     * @param $f
     * @param $poseter_id
     * @return mixed
     */
    function add($f,$poseter_id){
        $data = array(
            'title' => addslashes($f['title']),
            'data' => addslashes($f['data']),
            'image' => addslashes($f['image']),
        );
        if(!$poseter_id){
            $data['add_time'] = TIMESTAMP;
        }

        if($poseter_id){
            $this->update($poseter_id,$data);
        } else {
            $poseter_id = $this->insert( $data, true );
        }
        return $poseter_id;
    }


    /**
     * @author aboc
     * @return array
     */
    function get_poster_list(){
        $rows = DB::fetch_all("SELECT * FROM ".DB::table("invite_poster")." ORDER BY poster_id ASC");
        return $rows;
    }

} 