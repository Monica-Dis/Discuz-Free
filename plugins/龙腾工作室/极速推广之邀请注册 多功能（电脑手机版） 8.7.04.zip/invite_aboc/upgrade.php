<?php
// +----------------------------------------------------------------------
// | Fileanme: upgrade.php
// +----------------------------------------------------------------------
// | Description: 邀请注�?
// +----------------------------------------------------------------------
// | Author: aboc <mayinhua@gmail.com>
// +----------------------------------------------------------------------
// | Date: 201404019
// +----------------------------------------------------------------------
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = array();
$table = DB::table("invite_aboc");
$membertable = DB::table("common_member");
$sql['3.0.5'] =  "ALTER TABLE `$table` ADD `groupid` INT(3) NOT NULL DEFAULT '0' , ADD INDEX (`groupid`) ";
$sql['3.0.51']="ALTER TABLE `$membertable` ADD `invite_change` INT(10) NOT NULL DEFAULT '0' ;";
$goods_table = DB::table("invite_goods");
$exchange_table = DB::table("invite_exchange_log");
$sql['3.2.0'] = <<<DDD
CREATE TABLE `$goods_table` (
  `goods_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `types` enum('goods','extcredits','group') NOT NULL DEFAULT 'goods',
  `title` varchar(100) NOT NULL,
  `stock` int(10) NOT NULL DEFAULT '1',
  `number` int(10) unsigned NOT NULL DEFAULT '1',
  `attr` varchar(100) NOT NULL DEFAULT '',
  `price` int(10) NOT NULL DEFAULT '1',
  `description` text,
  `add_time` int(10) NOT NULL DEFAULT '0',
  `sales` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`goods_id`),
  KEY `types` (`types`)
) ENGINE=MyISAM;
CREATE TABLE `$exchange_table` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `username` char(20) NOT NULL,
  `goods_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `invite_num` int(10) NOT NULL DEFAULT '0',
  `number` int(10) NOT NULL,
  `add_time` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `attr` varchar(1000) NOT NULL DEFAULT '',
  PRIMARY KEY (`log_id`),
  KEY `status` (`status`)
) ENGINE=MyISAM;
DDD;
$invitemobile_table = DB::table("invite_mobile");
$sql['4.0.0'] = <<<BBB
ALTER TABLE `$membertable` ADD COLUMN `mobilestatus` tinyint(1) NOT NULL default '0' AFTER `status`;
ALTER TABLE `$membertable` ADD COLUMN `invite_num`  int(10) NOT NULL DEFAULT 0 AFTER `invite_change`;
CREATE TABLE `{$invitemobile_table}` (
  `mobile` char(11) NOT NULL,
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mobile`)
) ENGINE=MyISAM;
BBB;
$sql['4.0.1']= <<<BBB
ALTER TABLE `$table`
ADD COLUMN `level`  tinyint(1) NOT NULL DEFAULT 1 AFTER `groupid`,
ADD COLUMN `integral`  int(10) NOT NULL DEFAULT 0 AFTER `level`,
ADD INDEX (`level`) ;
BBB;
$sql['4.0.2'] = <<<DDD
ALTER TABLE `$table`
MODIFY COLUMN `fromuid`  int(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `username`,
DROP PRIMARY KEY,
ADD PRIMARY KEY (`uid`, `fromuid`);
DDD;
$sql['5.0.6'] = <<<DDD
ALTER TABLE `$goods_table`
MODIFY COLUMN `attr`  varchar(100) CHARACTER SET gbk COLLATE gbk_chinese_ci NOT NULL AFTER `number`,
ADD COLUMN `day`  int(10) NOT NULL DEFAULT 0 AFTER `sales`;

DDD;

$forum_order_table = DB::table("forum_order");
$sql['5.1.0']  = <<<DDD
ALTER TABLE `$forum_order_table`
ADD COLUMN `invite_aboc`  tinyint(1) NOT NULL DEFAULT 0 AFTER `ip`,
ADD INDEX (`uid`, `invite_aboc`) ;
DDD;

$poster_table  = DB::table("invite_poster");
$sql['8.6.9'] = <<<DDD
CREATE TABLE `$poster_table` (
  `poster_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `data` varchar(1000) NOT NULL,
  `image` varchar(100) NOT NULL,
  `add_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`poster_id`)
) ENGINE=MyISAM;
INSERT INTO `$poster_table`(`poster_id`, `title`, `data`, `image`, `add_time`) VALUES (1, 'poster1', '211,480,546,815', '../../source/plugin/invite_aboc/imgs/poster/1.jpg', 1608119839);
INSERT INTO `$poster_table`(`poster_id`, `title`, `data`, `image`, `add_time`) VALUES (2, 'poster2', '298,873,490,1065', '../../source/plugin/invite_aboc/imgs/poster/2.jpg', 1608119839);
INSERT INTO `$poster_table`(`poster_id`, `title`, `data`, `image`, `add_time`) VALUES (3, 'poster3', '274,912,498,1136', '../../source/plugin/invite_aboc/imgs/poster/3.jpg', 1608119839);
INSERT INTO `$poster_table`(`poster_id`, `title`, `data`, `image`, `add_time`) VALUES (4, 'poster4', '295,823,481,1009', '../../source/plugin/invite_aboc/imgs/poster/4.jpg', 1608119839);
INSERT INTO `$poster_table`(`poster_id`, `title`, `data`, `image`, `add_time`) VALUES (5, 'poster5', '302,627,444,769', '../../source/plugin/invite_aboc/imgs/poster/5.jpg', 1608119839);
DDD;

foreach($sql as $k => $v){
    if(version_compare($_GET['fromversion'] ,$k,'<')){
	    if($v) {
		    runquery( $v );
	    }
    }
}

if(version_compare($_GET['fromversion'] ,'4.0.0','<')){
	//升级 invite_num
	@set_time_limit(300);
	$rows = DB::fetch_all("SELECT COUNT(uid) AS num,fromuid FROM $table WHERE status='1' AND groupid!=8 GROUP BY fromuid");
	foreach($rows as $v){
		DB::update("common_member",array("invite_num" => $v['num']),"uid='{$v['fromuid']}'");
	}
}
if(version_compare($_GET['fromversion'] ,'4.0.1','<')){
	DB::query("UPDATE $table SET integral='1' WHERE status='1'");
}

$finish = true;
?>