<?php
/**
 * invite.inc.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-1
 * Time: 下午11:00
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once "public.inc.php";
//error_reporting(E_ALL);
include_once "invite.fun.php";
invite_init_session();
$act = isset($_GET['act']) ? trim($_GET['act']) :'';
if($act == 'send'){
    $mobile = isset($_GET['mobile']) ? trim($_GET['mobile']) :'';
    if($mobile == ""){
        output_json(lang('plugin/invite_aboc', 'aboc141'));
    }
    if(!preg_match('/^1\d{10}$/',$mobile)){
        output_json(lang('plugin/invite_aboc', 'aboc142'));
    }
    if(isset($_SESSION['invite_code'])){
        if((TIMESTAMP - $_SESSION['invite_code']['expire'])<90){
            output_json(lang('plugin/invite_aboc', 'aboc143').(90-(TIMESTAMP - $_SESSION['invite_code']['expire'])).lang('plugin/invite_aboc', 'aboc144'));
        }
    }
    if(C::t("#invite_aboc#invite_aboc")->check_mobile($mobile)){
        output_json(lang('plugin/invite_aboc', 'aboc145'));
    }
    $_SESSION['invite_code'] = array(
        'mobile' => $mobile,
        "code"  => mt_rand(111111,999999),
        "expire" => TIMESTAMP,
        "num"    => 0,
        "status" => 0,
    );
//    var_dump($_SESSION);
//    output_json("",$_SESSION['invite_code']['code']);
    if(invite_send_sms($mobile,$_SESSION['invite_code']['code'])){
        output_json("",lang('plugin/invite_aboc', 'aboc147'));
    } else {
        output_json(lang('plugin/invite_aboc', 'aboc148'));
    }
}