<?php
/**
 * invite.inc.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-1
 * Time: 下午11:00
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
header("location:plugin.php?id=invite_aboc:invite");