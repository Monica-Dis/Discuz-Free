var str = '<iframe name="ajaxPost" onload="showpop(this)" id="ajaxPost" src="about:blank" style="display: none;"></iframe>';
str += '<input type="file" style="display: none" name="file" id="ajaxUpload" onchange="upImagePost()" value="1" />' +
    '</form>';
document.write(str);



var xhr = new XMLHttpRequest();


//上传进度事件
xhr.upload.addEventListener("progress", function(result) {
    if (result.lengthComputable) {
        //上传进度
        var percent = (result.loaded / result.total * 100).toFixed(2);
    }
}, false);

xhr.addEventListener("readystatechange", function() {
    var result = xhr;
    if (result.status != 200) { //error
        console.log('fail', result.status, result.statusText, result.response);
    }
    else if (result.readyState == 4) { //finished
        console.log('success', result);
        var text = result.responseText.split("||");
        console.info(text)
        if(text.length != 3){
            return;
        }
        jQuery("#poseter_privew").prop("src" , text[0] + text[1])
        jQuery("#image").val( text[1])
        crop();
    }
});

function crop() {
    jQuery("#poseter_privew").show();
    var select = jQuery("#data").val();
    if(select == ""){
        select = "50,50,150,150";
    }
    select = select.split(",");
    jQuery("#poseter_privew").Jcrop({
        aspectRatio:1,
        bgFade: true,
        bgOpacity: .6,
        setSelect: select,
        onSelect: function (e) {
            console.info(e);
            jQuery("#data").val(e.x+','+e.y+','+e.x2+','+e.y2);
        }
    },function(){
        jcrop_api = this;
    });
}

function upImage() {
    document.getElementById("ajaxUpload").click();
}

function upImagePost() {

    var files = document.getElementById('ajaxUpload').files;

    if(files.length == 0) return;


    var form = new FormData(),
        file = files[0];
    form.append('file', file);
    form.append('upload', 1);
    form.append('formhash', formhash);
    xhr.open("post", uploadImageUrl, true);
    xhr.send(form);
}

function showpop(o) {
    var result = o.contentWindow.document.body.textContent;
    console.info(result);
}

if( jQuery("#poseter_privew").length > 0 ){
    if(jQuery("#poseter_privew").attr("src") != ""){

        crop();
    }
}