<?php
/**
 *	[�?请注�?(invite_aboc.install)] (c) 2021 by dism.taobao.com
 *	Version: 1.0.0
 *	Date: 2014-8-30 21:01
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$table = DB::table("invite_aboc");
$membertable = DB::table("common_member");
$sql = <<<EOF
CREATE TABLE `{$table}` (
  `uid` int(10) unsigned NOT NULL,
  `username` varchar(20) NOT NULL,
  `fromuid` int(10) NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL DEFAULT '0',
  `addip` varchar(15) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `groupid` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `fromid` (`fromuid`),
  KEY `timestamp` (`addtime`,`status`),
  KEY `groupid` (`groupid`)
) ENGINE=MyISAM;
ALTER TABLE `$membertable` ADD `invite_change` INT(10) NOT NULL DEFAULT '0' ;
ALTER TABLE `$membertable` ADD COLUMN `mobilestatus` tinyint(1) NOT NULL default '0' AFTER `status`;
ALTER TABLE `$membertable` ADD COLUMN `invite_num`  int(10) NOT NULL DEFAULT 0 AFTER `invite_change`;
EOF;

runquery($sql);
$goods_table = DB::table("invite_goods");
$exchange_table = DB::table("invite_exchange_log");
$invitemobile_table = DB::table("invite_mobile");
$sql = <<<DDD
CREATE TABLE `$goods_table` (
  `goods_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `types` enum('goods','extcredits','group') NOT NULL DEFAULT 'goods',
  `title` varchar(100) NOT NULL,
  `stock` int(10) NOT NULL DEFAULT '1',
  `number` int(10) unsigned NOT NULL DEFAULT '1',
  `attr` varchar(100) NOT NULL DEFAULT '',
  `price` int(10) NOT NULL DEFAULT '1',
  `description` text,
  `add_time` int(10) NOT NULL DEFAULT '0',
  `sales` int(10) NOT NULL DEFAULT '0',
  `day` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`goods_id`),
  KEY `types` (`types`)
) ENGINE=MyISAM;
CREATE TABLE `$exchange_table` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `username` char(20) NOT NULL,
  `goods_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `invite_num` int(10) NOT NULL DEFAULT '0',
  `number` int(10) NOT NULL,
  `add_time` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `attr` varchar(1000) NOT NULL DEFAULT '',
  PRIMARY KEY (`log_id`),
  KEY `status` (`status`)
) ENGINE=MyISAM;
CREATE TABLE `{$invitemobile_table}` (
  `mobile` char(11) NOT NULL,
  `addtime` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mobile`)
) ENGINE=MyISAM;
ALTER TABLE `$table`
ADD COLUMN `level`  tinyint(1) NOT NULL DEFAULT 1 AFTER `groupid`,
ADD COLUMN `integral`  int(10) NOT NULL DEFAULT 0 AFTER `level`,
ADD INDEX (`level`) ;
ALTER TABLE `$table`
MODIFY COLUMN `fromuid`  int(10) UNSIGNED NOT NULL DEFAULT 0 AFTER `username`,
DROP PRIMARY KEY,
ADD PRIMARY KEY (`uid`, `fromuid`);
DDD;
runquery($sql);
$forum_order_table = DB::table("forum_order");
$sql = <<<DDD
ALTER TABLE `$forum_order_table`
ADD COLUMN `invite_aboc`  tinyint(1) NOT NULL DEFAULT 0 AFTER `ip`,
ADD INDEX (`uid`, `invite_aboc`) ;
DDD;

runquery($sql);

$poster_table  = DB::table("invite_poster");
$sql = <<<DDD
CREATE TABLE `$poster_table` (
  `poster_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `data` varchar(1000) NOT NULL,
  `image` varchar(100) NOT NULL,
  `add_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`poster_id`)
) ENGINE=MyISAM;
DDD;

runquery($sql);


$sql = <<<DDD
INSERT INTO `$poster_table`(`poster_id`, `title`, `data`, `image`, `add_time`) VALUES (1, 'poster1', '211,480,546,815', '../../source/plugin/invite_aboc/imgs/poster/1.jpg', 1608119839);
INSERT INTO `$poster_table`(`poster_id`, `title`, `data`, `image`, `add_time`) VALUES (2, 'poster2', '298,873,490,1065', '../../source/plugin/invite_aboc/imgs/poster/2.jpg', 1608119839);
INSERT INTO `$poster_table`(`poster_id`, `title`, `data`, `image`, `add_time`) VALUES (3, 'poster3', '274,912,498,1136', '../../source/plugin/invite_aboc/imgs/poster/3.jpg', 1608119839);
INSERT INTO `$poster_table`(`poster_id`, `title`, `data`, `image`, `add_time`) VALUES (4, 'poster4', '295,823,481,1009', '../../source/plugin/invite_aboc/imgs/poster/4.jpg', 1608119839);
INSERT INTO `$poster_table`(`poster_id`, `title`, `data`, `image`, `add_time`) VALUES (5, 'poster5', '302,627,444,769', '../../source/plugin/invite_aboc/imgs/poster/5.jpg', 1608119839);
DDD;
runquery($sql);



$finish = true;
?>