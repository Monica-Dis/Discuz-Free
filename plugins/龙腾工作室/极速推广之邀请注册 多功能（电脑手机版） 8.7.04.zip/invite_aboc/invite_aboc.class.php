<?php
/**
 *    [邀请注册(invite_aboc.{modulename})] (c) 2021 by dism.taobao.com
 *    Version: 1.0.0
 *    Date: 2014-8-30 21:01
 */

if ( ! defined( 'IN_DISCUZ' ) ) {
	exit( 'Access Denied' );
}
include_once "invite.fun.php";
invite_init_session();

class plugin_invite_aboc {

	public $set = array();

	function __construct() {
		$this->plugin_invite_aboc();
	}

	function plugin_invite_aboc() {
		global $_G;
		include_once "public.inc.php";
		$this->set                 = $_G['cache']['plugin']['invite_aboc'];
		$this->set['ban_group_id'] = @unserialize( $this->set['ban_group_id'] );
	}

	function common() {
		global $_G;
//		print_r($_G['setting']);exit;
		if ( ! empty( $_G['cookie']['promotion'] ) ) {
			dsetcookie( "promotion_u", $_G['cookie']['promotion'], 1800 );
		}
		if ( $this->set['invite_type'] == 1  || $this->set['invite_type'] == 4 || $this->set['invite_type'] == 3 ) {
			$fromuid = ! empty( $_G['cookie']['promotion_u'] ) ? $_G['cookie']['promotion_u'] : 0;
			if ( $fromuid && $_G['uid'] ) {
//            print_r($_G['cookie']);
				C::t( "#invite_aboc#invite_aboc" )->update_fromuid( $_G['uid'], $_G['username'], $fromuid, $_G['member'] );
			}
			if ( $this->set['invite_type'] == 1  || $this->set['invite_type'] == 4 ) {
				if ( $_G['member']['groupid'] != 8 && $_G['member']['emailstatus'] == 1 ) {
					if ( C::t( "#invite_aboc#invite_aboc" )->update_invite( $_G['member'] ) ) {
						return;
					}
				}
			} elseif ( $this->set['invite_type'] == 3 ) {
				if ( $result = C::t( "#invite_aboc#invite_aboc" )->update_invite( $_G['member'] ) ) {
					return;
				}
			}
		}
		if ( $this->set['invite_type'] == 2 ) {
			$_GET['handlekey'] = 'register';
			if ( submitcheck( "regsubmit" ) ) {
				$mobile     = isset( $_GET['mobile'] ) ? trim( $_GET['mobile'] ) : '';
				$mobilecode = isset( $_GET['mobilecode'] ) ? trim( $_GET['mobilecode'] ) : '';
				if ( ! preg_match( '/^1\d{10}$/', $mobile ) ) {
					showmessage( lang( 'plugin/invite_aboc', 'aboc129' ) );
				}
				if ( $mobilecode == "" ) {
					showmessage( lang( 'plugin/invite_aboc', 'aboc130' ) );
				}
				if ( ! isset( $_SESSION['invite_code'] ) || $_SESSION['invite_code']['expire'] < ( TIMESTAMP - 1800 ) ) {
					showmessage( lang( 'plugin/invite_aboc', 'aboc131' ) );
				}
//            var_dump($_SESSION['invite_code']);exit;
				if ( $_SESSION['invite_code']['expire']['num'] >= 3 ) {
					if ( $_SESSION['invite_code']['expire'] > ( TIMESTAMP - 90 ) ) {
						showmessage( lang( 'plugin/invite_aboc', 'aboc132' ) );
					} else {
						unset( $_SESSION['invite_code'] );
					}
					showmessage( lang( 'plugin/invite_aboc', 'aboc133' ) );
				}
				if ( C::t( "#invite_aboc#invite_aboc" )->check_mobile( $mobile ) ) {
					showmessage( lang( 'plugin/invite_aboc', 'aboc134' ) );
				}
				if ( $_SESSION['invite_code']['mobile'] != $mobile || $_SESSION['invite_code']['code'] != $mobilecode ) {
					$_SESSION['invite_code']['expire']['num'] ++;
					//.$_SESSION['invite_code']['code']
					showmessage( lang( 'plugin/invite_aboc', 'aboc135' ) );
				}
				$_SESSION['invite_code']['status'] = 1;
			}



			if ( defined( "IN_MOBILE" ) && IN_MOBILE == 2 ) {
				$fromuid = ! empty( $_G['cookie']['promotion_u'] ) ? $_G['cookie']['promotion_u'] : 0;
				if ( $fromuid && $_G['uid'] ) {
//            print_r($_G['cookie']);
					C::t( "#invite_aboc#invite_aboc" )->update_fromuid( $_G['uid'], $_G['username'], $fromuid, $_G['member'] );
				}
				if ( isset( $_SESSION['invite_code']['status'] ) && $_SESSION['invite_code']['status'] ) {
					$member = C::t( "common_member" )->fetch( $_G['uid'] );
					if ( $member && $member['mobilestatus'] == 0 ) {
						C::t( "#invite_aboc#invite_aboc" )->update_invite( array(
							"uid"     => $member['uid'],
							"groupid" => 10,
							"mobile"  => $_SESSION['invite_code']['mobile'],
						) );
						unset( $_SESSION['invite_code']['status'] );
						dsetcookie( "promotion_u", "", 1800 );
					}
				}
			}
		}
//        $fromuid = !empty($_G['cookie']['promotion']) && $_G['setting']['creditspolicy']['promotion_register'] ? intval($_G['cookie']['promotion']) : 0;


	}

	function register_message( $value ) {
		global $_G;
		if ( $this->set['invite_type'] == 2 ) {
			$user_info = $value['param'][2];
			$fromuid   = ! empty( $_G['cookie']['promotion_u'] ) ? $_G['cookie']['promotion_u'] : 0;
			if ( $fromuid && $_G['uid'] ) {
//            print_r($_G['cookie']);
				C::t( "#invite_aboc#invite_aboc" )->update_fromuid( $_G['uid'], $_G['username'], $fromuid, $_G['member'] );
			}
			if ( isset( $_SESSION['invite_code']['status'] ) && $_SESSION['invite_code']['status'] ) {
				$member = C::t( "common_member" )->fetch( $_G['uid'] );
				if ( $member && $member['mobilestatus'] == 0 ) {
					C::t( "#invite_aboc#invite_aboc" )->update_invite( array(
						"uid"     => $user_info['uid'],
						"groupid" => 10,
						"mobile"  => $_SESSION['invite_code']['mobile'],
					) );
					unset( $_SESSION['invite_code']['status'] );
					dsetcookie( "promotion_u", "", 1800 );
				}
			}
		}
	}

	function global_footer() {
		global $_G;
		$d = '';
			if ( isset( $_GET['register'] ) && $_GET['register'] && !$_G['uid'] ) {
				$d = <<<DDD
        <script type="text/javascript">
        window.location.href = 'member.php?mod={$GLOBALS['_G']['setting']['regname']}';
        </script>
DDD;
			}
		if ( $this->set['invite_type'] == 2 ) {
			if ( defined( "IN_MOBILE" ) && IN_MOBILE == 2 && isset( $_GET['mod'] ) && $_GET['mod'] == $GLOBALS['_G']['setting']['regname'] ) {
				$FORMHASH = FORMHASH;
				$aboc136  = lang( 'plugin/invite_aboc', 'aboc136' );
				$aboc137  = lang( 'plugin/invite_aboc', 'aboc137' );
				$aboc138  = lang( 'plugin/invite_aboc', 'aboc138' );
				$aboc139  = lang( 'plugin/invite_aboc', 'aboc139' );
				$d        = <<<LLL
<script type="text/javascript">
var ajQ = $;
       $(".login_from ul").append('<li class="bl_none"><input type="text" id="mobile" name="mobile" value=""  class="px"  size="30" autocomplete="off" placeholder="{$aboc136}" maxlength="11" required /></li>');
       $(".login_from ul").append('<li><button id="btn_get_mobile_code" class="pn" type="button" onclick="get_mobile_code();" style="width:90%">{$aboc137}</button></li>');
       $(".login_from ul").append('<li class="bl_none"><input type="text" id="mobilecode" name="mobilecode" value="" class="px"  size="30" autocomplete="off" placeholder="{$aboc138}" maxlength="11" required /></li>');
       function get_mobile_code(){
    var mobile = ajQ("#mobile").val();
    if(mobile==""){
    popup.open( "{$aboc139}","alert");
    }
    ajQ.ajax({
      url:"plugin.php?id=invite_aboc:invite_sms",
      type:"post",
      data:{act:"send",formhash:"{$FORMHASH}",mobile:mobile},
      dataType:"json",
      success:function(d){
          if(d.error != ""){
            popup.open( d.error,"alert");
          } else{
            popup.open( d.msg,"alert");
          }
      }
    });
  }
        </script>
LLL;

			}
		}
		if ( $this->set['invite_type'] == 4 ) {
			$aboc153 = lang( 'plugin/invite_aboc', 'aboc153' );
			$d .= <<<DDD
<script type="text/javascript">
       $(".login_from ul").append('<li class="bl_none"><input type="text" id="fromuid" name="fromuid" value=""  class="px"  size="30" autocomplete="off" placeholder="{$aboc153}" maxlength="11" required /></li>');
        </script>
DDD;
		}
		$this->_get_forum_order($GLOBALS['_G']['uid']);
		return $d;
	}

	private function _get_forum_order($uid){
			global $_G;
		$setting = $_G['setting'];
		if(!$setting['creditstrans'] || !$uid){
			return;
		}
		$rows = DB::fetch_all("SELECT * FROM ".DB::table("forum_order")." WHERE status=2 AND uid='$uid' AND invite_aboc=0");
		if($rows){
			//找上级
			$fromusers = C::t("#invite_aboc#invite_aboc")->get_parent_uid($uid);

			foreach($rows as $k => $v) {
                $return = 0;
				foreach ( $fromusers as $level => $fromuid ) {
					if ( ! isset( $_G['cache']['plugin']['invite_aboc'][ 'pay_' . $level ] ) || $_G['cache']['plugin']['invite_aboc'][ 'pay_' . $level ] <= 0 ) {
						continue;
					}
					if(!$_G['cache']['plugin']['invite_aboc']['pay_type']){
						continue;
					}
					updatemembercount( $fromuid, array( 'extcredits' . $_G['cache']['plugin']['invite_aboc']['pay_type'] => ceil($v['amount'] * $_G['cache']['plugin']['invite_aboc'][ 'pay_' . $level ] / 100) ), true, 'TRC', 0, lang( 'plugin/invite_aboc', 'aboc188' ), "FROM",serialize(array(
						"title" => $level.lang( 'plugin/invite_aboc', 'aboc186' ).$_G['username'].lang( 'plugin/invite_aboc', 'aboc187' ),
						"uid" => $_G['uid'],
						"amount" => $v['amount'],
						"paytime"=> $v['confirmdate'],
						"orderid"=> $v['orderid'],
						"level"  => $level,
					)) );
					$return = 1;
				}
                C::t('forum_order')->update($v['orderid'], array('invite_aboc' => $return?1:-1));
			}

		}
	}

}

class plugin_invite_aboc_member extends plugin_invite_aboc {


	function register_input_output() {
		global $_G;
		if ( $this->set['invite_type'] == 2 ) {
			include_once template( "invite_aboc:regiseter_input" );

//			$return;
		} else if($this->set['invite_type'] == 4) {
			include_once template( "invite_aboc:regiseter_input_from_uid" );
			$return = $returnfromuid;
		}
		return $return;
	}

}

class mobileplugin_invite_aboc extends plugin_invite_aboc {


	function global_footer_mobile() {
		global $_G;
		$d = $this->global_footer();
		if ( $_G['uid'] ) {
			$aboc140 = lang( 'plugin/invite_aboc', 'aboc140' );
			$d .= <<<DDD
            <style>
            .invite_footer{line-height:2.6;text-align:center;}
            .invite_footer a{font-size:14px;color:red}
            </style>
<div class="invite_footer">
<a href="plugin.php?id=invite_aboc:invite">{$aboc140}</a>
</div>
DDD;

		}

		return $d;
	}
}
