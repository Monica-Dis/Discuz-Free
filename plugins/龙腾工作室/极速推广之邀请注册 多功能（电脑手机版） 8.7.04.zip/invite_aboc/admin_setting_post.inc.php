<?php
/**
 * admin_invite.inc.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-3
 * Time: 下午11:13
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(submitcheck("setting",0)){
    C::t("#invite_aboc#invite_aboc")->post_setting();


    $menu_sort = isset($_GET['menu_sort']) ? $_GET['menu_sort'] : array();
    $menu_title = isset($_GET['menu_title']) ? $_GET['menu_title'] : array();

    asort($menu_sort);

    $menus = array();
    foreach($menu_sort as $key => $_){
        if(isset($menu_title[$key])) {
            $menus[$key] = $menu_title[$key];
        }
    }
    C::t("common_setting")->update("invite_aboc_menu" , $menus);

    cpmsg(lang('plugin/invite_aboc', 'aboc91'),"",'succeed');
}