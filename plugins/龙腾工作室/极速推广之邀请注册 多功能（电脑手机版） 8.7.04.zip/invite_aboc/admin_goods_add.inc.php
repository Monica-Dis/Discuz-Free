<?php
/**
 * admin_invite.inc.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-3
 * Time: 下午11:13
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once 'admin_goods.inc.php';