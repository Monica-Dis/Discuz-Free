<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
error_reporting(E_ALL);
ini_set("display_errors","on");

include_once dirname(__FILE__)."/qrcode.class.php";
include_once dirname(__FILE__)."/invite.fun.php";
$list  = C::t("#invite_aboc#invite_poster")->get_poster_list();

$key = isset($_GET['key']) ? intval($_GET['key']) : 0;

if(!$list){
    exit;
}
if($key > count($list)){
    $key = 0;
}

$info = $list[$key];
$attachdir = $_G['setting']['attachdir'];
$pic = realpath($attachdir . $info['image']);

if(!$pic || !file_exists($pic)){
    exit;
}
$info['data'] = explode(',' , $info['data']);
$url = isset($_GET['url'])?trim($_GET['url']):$_G['siteurl'];


$pic_path =  $_G['setting']['attachdir'].date("Y/m").'/'.$info['poster_id'];

if(!is_dir($pic_path)){
    mkdir($pic_path, 0777 ,true);
}

$new_pic = $pic_path."_{$_G['uid']}.jpg";


QRcode::png($url,$new_pic."_.png","L",5,2);
$im = _imagecreate($pic);
$qrcode_im = _imagecreate($new_pic."_.png");





imagecopyresized($im, $qrcode_im, $info['data'][0],$info['data'][1], 0, 0, $info['data'][2] - $info['data'][0],$info['data'][3] - $info['data'][1], imagesx($qrcode_im), imagesy($qrcode_im));
imagejpeg($im,$new_pic);





header("Content-Type: image/jpeg");
echo file_get_contents($new_pic);