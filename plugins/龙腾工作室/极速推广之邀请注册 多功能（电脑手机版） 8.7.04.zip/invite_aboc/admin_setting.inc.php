<?php
/**
 * admin_invite.inc.php
 * 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-3
 * Time: 下午11:13
 */
if ( ! defined( 'IN_DISCUZ' ) || ! defined( 'IN_ADMINCP' ) ) {
	exit( 'Access Denied' );
}
include_once "invite.fun.php";
include_once "public.inc.php";
include_once "admin_setting_post.inc.php";
?>
	<script src="source/plugin/invite_aboc/template/jquery-1.7.2.min.js"></script>
	<script>
		var ajQ = jQuery.noConflict(true);
		ajQ(function($){
				select_type($("[name='varsnew[invite_type]']").val());
			    $("[name='varsnew[invite_type]']").change(function(){
				   select_type($(this).val());
			    });
		});
		function select_type(n){
			switch (n){
				case '1':
				case '4':
					var o = ajQ("[name='varsnew[Appkey]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).hide();
					ajQ(ot).hide();
					var o = ajQ("[name='varsnew[Secretkey]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).hide();
					ajQ(ot).hide();
					var o = ajQ("[name='varsnew[SmsTemplateCode]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).hide();
					ajQ(ot).hide();
					var o = ajQ("[name='varsnew[SignName]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).hide();
					ajQ(ot).hide();
					var o = ajQ("[name='varsnew[up_group]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).hide();
					ajQ(ot).hide();
					var o = ajQ("[name='varsnew[up_time]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).hide();
					ajQ(ot).hide();
					break;
				case '2':
					var o = ajQ("[name='varsnew[up_group]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).hide();
					ajQ(ot).hide();
					var o = ajQ("[name='varsnew[up_time]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).hide();
					ajQ(ot).hide();
					var o = ajQ("[name='varsnew[Appkey]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).show();
					ajQ(ot).show();
					var o = ajQ("[name='varsnew[Secretkey]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).show();
					ajQ(ot).show();
					var o = ajQ("[name='varsnew[SmsTemplateCode]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).show();
					ajQ(ot).show();
					var o = ajQ("[name='varsnew[SignName]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).show();
					ajQ(ot).show();
					break;
				case '3':
					var o = ajQ("[name='varsnew[Appkey]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).hide();
					ajQ(ot).hide();
					var o = ajQ("[name='varsnew[Secretkey]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).hide();
					ajQ(ot).hide();
					var o = ajQ("[name='varsnew[SmsTemplateCode]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).hide();
					ajQ(ot).hide();
					var o = ajQ("[name='varsnew[SignName]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).hide();
					ajQ(ot).hide();
					var o = ajQ("[name='varsnew[up_group]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).show();
					ajQ(ot).show();
					var o = ajQ("[name='varsnew[up_time]']").closest("tr");
					var ot = ajQ(o).prev("tr");
					ajQ(o).show();
					ajQ(ot).show();
					break;
			}
		}
	</script>
<?php
showformheader( "plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_setting", "", "sform", "post" );
showtableheader();
showsetting(lang( 'plugin/invite_aboc', 'aboc164' ),array("varsnew[invite_type]",array(
	array(1 , lang( 'plugin/invite_aboc', 'aboc165' )),
	array(2 , lang( 'plugin/invite_aboc', 'aboc166' )),
		array(3, lang( 'plugin/invite_aboc', 'aboc167' )),
		array(4, lang( 'plugin/invite_aboc', 'aboc1671' )),
)),$invite_setting["invite_type"],"select");
showsetting(lang( 'plugin/invite_aboc', 'aboc168' ),"varsnew[Appkey]",$invite_setting["Appkey"],"text","",0,lang( 'plugin/invite_aboc', 'aboc169' ));
showsetting(lang( 'plugin/invite_aboc', 'aboc170' ),"varsnew[Secretkey]",$invite_setting["Secretkey"],"text","",0,lang( 'plugin/invite_aboc', 'aboc171' ));
showsetting(lang( 'plugin/invite_aboc', 'aboc172' ),"varsnew[SmsTemplateCode]",$invite_setting["SmsTemplateCode"],"text","",0,lang( 'plugin/invite_aboc', 'aboc173' ));
showsetting(lang( 'plugin/invite_aboc', 'aboc174' ),"varsnew[SignName]",$invite_setting["SignName"],"text","",0,lang( 'plugin/invite_aboc', 'aboc175' ));
$query = C::t('common_usergroup')->range_orderby_credit();
$groupselect = array(array("",""));
$grouptitle = array();
foreach($query as $group) {
	$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
	if(!isset($grouptitle[$group['type']])){
		$groupselect[] = array(
			0,$lang['usergroups_'.$group['type']],1,
		);
		$grouptitle[$group['type']]= 1;
	}
	$groupselect[] = array(
		$group['groupid'],'&nbsp;&nbsp;&nbsp;'.$group['grouptitle'],
	);
}
showsetting(lang( 'plugin/invite_aboc', 'aboc176' ),array("varsnew[up_group]",$groupselect),$invite_setting["up_group"],"select","",0,lang( 'plugin/invite_aboc', 'aboc177' ));
showsetting(lang( 'plugin/invite_aboc', 'aboc178' ),"varsnew[up_time]",$invite_setting["up_time"],"number","",0,lang( 'plugin/invite_aboc', 'aboc179' ));

showtitle(lang( 'plugin/invite_aboc', 'menu_custom' ));
$menus = get_menu();
$index = 0;
foreach($menus as $key => $menu) {
    echo '<tr ><td class="td25"><input type="text" class="txt" size="2" name="menu_sort['.$key.']" value="'.$index.'"></td><td><div><input type="text" class="txt" size="20" name="menu_title['.$key.']" value="'.$menu[2].'"></div></td><td>'.$menu[0].'</td></tr>';
    $index ++;
}
showhiddenfields( array(
	'formhash' => FORMHASH
) );
showsubmit( 'setting', lang( 'plugin/invite_aboc', 'aboc75' ) );

showtablefooter(); /*dism - taobao - com*/ /*dism·taobao·com*/
showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/