<?php

/**
 * 	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * 	$DisM!Ӧ�����ģ�dism.taobao.com $
 * 	$���²����http://t.cn/Aiux1Jx1 $
 * 	$Id: userip.inc.php 107 2013-05-27 02:43:47Z HonHoo $
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$page = empty($_GET['page']) ? 1 : intval($_GET['page']);
if ($page < 1)
    $page = 1;
$perpage = 20;
$start = ($page - 1) * $perpage;
if(!$_G['uid']){
    showmessage(lang('plugin/userip', 'aboc19'));
}
if($_G['cache']['plugin']['userip']['open_record']!=1){
    showmessage(lang('plugin/userip', 'aboc19'));
}
$where = " WHERE uid='{$_G['uid']}'";
$row = DB::fetch_first("SELECT COUNT(*) AS num FROM ".DB::table("common_member_userip").$where);
$count = $row['num'];
$list = DB::fetch_all("SELECT * FROM ".DB::table("common_member_userip").$where." ORDER BY dateline DESC LIMIT $start,$perpage");
foreach($list as $k => $v){
    $list[$k]['dateline'] = dgmdate($v['dateline'],"Y-m-d H:i:s");
}
if ($count) {
    $multi = multi($count, $perpage, $page, "plugin.php?id=userip:show");
}
include template("userip:show");