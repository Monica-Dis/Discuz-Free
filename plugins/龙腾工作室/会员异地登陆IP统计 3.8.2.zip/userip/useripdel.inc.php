<?php
/**
 *	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *	$DisM!Ӧ�����ģ�dism.taobao.com $
 *	$���²����http://t.cn/Aiux1Jx1 $
 *	$Id: useripcp.inc.php 41 2013-04-22 06:28:41Z HonHoo $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$_GET = daddslashes($_GET);
$_POST = daddslashes($_POST);
$useriplang = lang('plugin/userip');

if(submitcheck("dellog")){
    if(isset($_POST['cleardate'])&&$_POST['cleardate']!=""){
        $times = strtotime($_POST['cleardate']);
        DB::delete("common_member_userip", "dateline<='$times'");
    }else{
        DB::delete("common_member_userip","1=1");
    }
    cpmsg($useriplang['aboc15'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=userip&pmod=useripcp', 'succeed');
    exit;
}

@set_time_limit(0);
$prepage = 20;
$page = max(1, $_GET['page']);
$start_limit = ($page - 1) * $prepage;
?>
<script type="text/javascript" src="static/js/calendar.js"></script>
<?php
showformheader("plugins&operation=config&do=$pluginid&identifier=userip&pmod=useripdel");
    showtableheader();
    showtitle($useriplang['aboc16']);
    showsetting($useriplang['aboc17'], "cleardate", "", "calendar", 0, 0, $useriplang['aboc18'], "", "", "false");
    showsubmit('dellog');
    showtablefooter();
    showformfooter(); /*Dism��taobao��com*/