<?php
/**
 *	DisM!Ӧ�����ģ�dism.taobao.com
 *	$Author: DisM!Ӧ������ $
 *	$From: DisM.taobao.Com $
 *	$Id: useriptop.inc.php 41 2013-11-20 06:28:41Z Aboc $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$_GET = daddslashes($_GET);
$_POST = daddslashes($_POST);
$useriplang = lang('plugin/userip');
if(submitcheck("delete","post")){
    if (!isset($_POST['ids']) || !is_array($_POST['ids']) || !$_POST['ids']) {
        cpmsg($useriplang['aboc21']);
    }
    if(DB::delete("common_member_useriplog","logid IN(".join(',',$_POST['ids']).")")){
        cpmsg($useriplang['aboc3'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=userip&pmod=useriplog', 'succeed');
    } else {
        cpmsg($useriplang['aboc4']);
    }
    exit;
}


@set_time_limit(0);
$prepage = 20;
$page = max(1, $_GET['page']);
$start_limit = ($page - 1) * $prepage;
$username =  isset($_GET['username'])?trim($_GET['username']):'';
$where = ' 1=1';
if(isset($_GET['search'])){
    if($username!="")
    $where .= " AND username='$username'";
}
$url = 'admin.php?action=plugins&identifier=userip&pmod=useriplog';
$count = DB::result_first('SELECT count(uid) FROM '.DB::table("common_member_useriplog")." WHERE $where");
if($count) {
	$multipage = multi($count, $prepage, $page, $url.$urladd);
	$limit ="LIMIT $start_limit, $prepage";
	$list = DB::fetch_all('SELECT * FROM '.DB::table("common_member_useriplog")." WHERE $where ORDER BY logid DESC ".$limit);
    $rows = DB::fetch_all('SELECT groupid,grouptitle FROM '.DB::table('common_usergroup'));
    $group_list = array();
    foreach($rows as $v){
        $group_list[$v['groupid']] = $v['grouptitle'];
    }
    foreach($list as $k => $v){
        $list[$k]['beforegroup'] = isset($group_list[$v['beforegid']])?$group_list[$v['beforegid']]:'δ֪';
        $list[$k]['aftergroup'] = isset($group_list[$v['aftergid']])?$group_list[$v['aftergid']]:'δ֪';
        $list[$k]['addtime'] = dgmdate($v['addtime'],"Y-m-d H:i:s");
    }
}
$urladd = '&page='.$page;
?>
<?php
showformheader("plugins&operation=config&do=$pluginid&identifier=userip&pmod=useriptop","","sform","get");
//admin.php?action=plugins&operation=config&do=10&identifier=aboc_mall&pmod=admin_goods
?>
<input type="hidden" name="action" value="plugins" />
<input type="hidden" name="operation" value="config" />
<input type="hidden" name="do" value="<?php echo $pluginid?>" />
<input type="hidden" name="identifier" value="userip" />
<input type="hidden" name="pmod" value="useriplog" />
<table class="tb tb2 ">
	<tbody>
            <tr class="hover">
                <td style="width:430px;">
                    <?php echo $useriplang['aboc8'];?><input type="text" value="<?php echo isset($_GET['username'])?$_GET['username']:'';?>" name="username" class="txt">
                    <input type="submit" name="search" value="<?php echo $useriplang['aboc10'];?>" class="btn" />
                </td>
            </tr>
	</tbody>
</table>
<?php
showformfooter(); /*Dism��taobao��com*/
showformheader("plugins&operation=config&do=$pluginid&identifier=userip&pmod=useriplog");
?>
<table class="tb tb2 ">
	<tbody>
		<tr class="header">
            <th style="width:20px;"></th>
			<th><?php echo $useriplang['username'];?></th>
			<th><?php echo $useriplang['beforegroup'];?></th>
            <th><?php echo $useriplang['aftergroup'];?></th>
            <th><?php echo $useriplang['memo'];?></th>
			<th><?php echo $useriplang['changetime'];?></th>
		</tr>
		<?php foreach($list as $member) {?>
		<tr class="hover" id="member_<?php echo $member['uid'];?>">
                    <td>
                        <input type="checkbox" value="<?php echo $member['logid'];?>" name="ids[]" class="checkbox">
                    </td>
			<td>
				<a href="admin.php?action=plugins&identifier=userip&pmod=useripcp&uid=<?php echo $member['uid'];?>"><?php echo $member['username'];?></a>
			</td>
			<td><?php echo $member['beforegroup'];?></td>
            <td><?php echo $member['aftergroup'];?></td>
            <td><?php echo $member['memo'];?></td>
			<td><?php echo $member['addtime'];?></td>
		</tr>
		<?php } ?>
                <tr>
                    <td class="td25">
                        <input type="checkbox" onclick="checkAll('prefix', this.form, 'id')" class="checkbox" id="chkallHqdf" name="chkall">
                        </td>
                        <td colspan="15">
                            <div class="fixsel">
                                <input type="submit" value="<?php echo $useriplang['delete'];?>" name="delete" id="submit_submit" class="btn">
                            </div>
                        </td>
                </tr>
	</tbody>
</table>
<?php
echo '<input type="hidden" name="formhash" value="'.FORMHASH.'" />';
showformfooter(); /*Dism��taobao��com*/
?>
<table>
	<tbody>
		<tr>
			<td colspan="5">
				<div class="cuspages right">
					<?php echo $multipage; ?>
				</div>
			</td>
		</tr>
	</tbody>
</table>
