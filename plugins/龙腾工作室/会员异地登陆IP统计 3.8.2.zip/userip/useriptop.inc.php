<?php
/**
 *	DisM!Ӧ�����ģ�dism.taobao.com
 *	$Author: DisM!Ӧ������ $
 *	$From: DisM.taobao.Com $
 *	$Id: useriptop.inc.php 41 2013-11-20 06:28:41Z Aboc $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$_GET = daddslashes($_GET);
$_POST = daddslashes($_POST);
$useriplang = lang('plugin/userip');

if(submitcheck("submit")){
    if(!$_POST['groupid']){
        cpmsg($useriplang['aboc1']);
    }
    if(!isset($_POST['uids']) || !is_array($_POST['uids']) || !$_POST['uids']){
        cpmsg($useriplang['aboc2']);
    }
if(DB::update("common_member", array('groupid'=>  intval($_POST['groupid'])), "uid IN(".  join(',', $_POST['uids']).")")){
    cpmsg($useriplang['aboc3'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=userip&pmod=useriptop', 'succeed');
} else{
    cpmsg($useriplang['aboc4']);
}
    exit;
}


@set_time_limit(0);
$prepage = 20;
$page = max(1, $_GET['page']);
$start_limit = ($page - 1) * $prepage;
$username =  isset($_GET['username'])?trim($_GET['username']):'';
$ipcount = isset($_GET['ipcount'])?intval($_GET['ipcount']):0;
$where = ' uc.uid>0';
if(isset($_GET['search'])){
    if($username!="")
    $where .= " AND u.username='$username'";
}
if(isset($_GET['edit'])){
    if($username==""){
        cpmsg($useriplang['aboc5']);
    }
    $info = DB::fetch_first("SELECT * FROM ".DB::table("common_member")." WHERE username='$username'");
    if(!$info){
        cpmsg($useriplang['aboc6']);
    }
    if($ipcount==0){
        DB::delete(DB::table("common_member_useripcount"), "uid='{$info['uid']}'");
        DB::delete(DB::table("common_member_userip"), "uid='{$info['uid']}'");
    }else{
        DB::update("common_member_useripcount", array("ipcount"=>$ipcount), "uid='{$info['uid']}'");
    }
    cpmsg($useriplang['aboc7'],$_SERVER['HTTP_REFERER']);
    exit;
}
$url = 'admin.php?action=plugins&identifier=userip&pmod=useriptop';
$data = "$useriplang[username],$useriplang[dateline],$useriplang[ip],$useriplang[addr]\r\n";
$count = DB::result_first('SELECT count(DISTINCT uc.uid) FROM '.DB::table("common_member_useripcount").' uc LEFT JOIN '.DB::table('common_member_userip')." u ON uc.uid=u.uid WHERE $where");
if($count) {
	$multipage = multi($count, $prepage, $page, $url.$urladd);
	$limit ="LIMIT $start_limit, $prepage";
	$query = DB::query('SELECT DISTINCT u.uid,u.username,uc.ipcount FROM '.DB::table("common_member_useripcount").' uc LEFT JOIN '.DB::table('common_member_userip')." u ON uc.uid=u.uid WHERE $where ORDER BY uc.ipcount DESC,dateline DESC ".$limit);
	$list = array();
	while($value = DB::fetch($query)) {
		$value['usergroup'] = DB::result_first('SELECT grouptitle FROM '.DB::table('common_member')." m,".DB::table('common_usergroup')." u WHERE m.uid='$value[uid]' AND m.groupid=u.groupid");
		$list[] = $value;
		$data .= "$value[username],".date('Y-m-d H:i:s', $value['dateline']).",$value[ip],".$value['area']."\r\n";
	}
}
$urladd = '&page='.$page;
?>
<?php
showformheader("plugins&operation=config&do=$pluginid&identifier=userip&pmod=useriptop","","sform","get");
//admin.php?action=plugins&operation=config&do=10&identifier=aboc_mall&pmod=admin_goods
?>
<input type="hidden" name="action" value="plugins" />
<input type="hidden" name="operation" value="config" />
<input type="hidden" name="do" value="<?php echo $pluginid?>" />
<input type="hidden" name="identifier" value="userip" />
<input type="hidden" name="pmod" value="useriptop" />
<table class="tb tb2 ">
	<tbody>
            <tr class="hover">
                <td style="width:430px;">
                    <?php echo $useriplang['aboc8'];?><input type="text" value="<?php echo isset($_GET['username'])?$_GET['username']:'';?>" name="username" class="txt">
                    <?php echo $useriplang['aboc9'];?><input type="text" value="<?php echo isset($_GET['ipcount'])?$_GET['ipcount']:'';?>" name="ipcount" class="txt">
                </td>
                <td>
                    <input type="submit" name="search" value="<?php echo $useriplang['aboc10'];?>" class="btn" />
                    <input type="submit" name="edit" onclick="return confirm('<?php echo $useriplang['aboc11'];?>')" value="<?php echo $useriplang['aboc12'];?>" class="btn" />
                </td>
            </tr>
	</tbody>
</table>
<?php
showformfooter(); /*Dism��taobao��com*/
showformheader("plugins&operation=config&do=$pluginid&identifier=userip&pmod=useriptop");
?>
<table class="tb tb2 ">
	<tbody>
		<tr class="header">
                    <th style="width:20px;"></th>
			<th><?php echo $useriplang['username'];?></th>
			<th><?php echo $useriplang['usergroup'];?></th>
			<th><?php echo $useriplang['areacount'];?></th>
		</tr>
		<?php foreach($list as $member) {?>
		<tr class="hover" id="member_<?php echo $member['uid'];?>">
                    <td>
                        <input type="checkbox" value="<?php echo $member['uid'];?>" name="uids[]" class="checkbox">
                    </td>
			<td>
				<a href="admin.php?action=plugins&identifier=userip&pmod=useripcp&uid=<?php echo $member['uid'];?>"><?php echo $member['username'];?></a>
			</td>
			<td><?php echo $member['usergroup'];?></td>
			<td><?php echo $member['ipcount'];?></td>
		</tr>
		<?php } ?>
                <tr>
                    <td class="td25">
                        <input type="checkbox" onclick="checkAll('prefix', this.form, 'uid')" class="checkbox" id="chkallHqdf" name="chkall">
                        </td>
                        <td colspan="15">
                            <div class="fixsel">
                                <?php
                                $groups = DB::fetch_all("SELECT * FROM ".DB::table("common_usergroup")." ORDER BY groupid ASC");
                                ?>
                                <select name="groupid">
                                    <option value="0"><?php echo $useriplang['aboc13'];?></option>
                                    <?php
                                    foreach($groups as $v){
                                        echo '<option value="'.$v['groupid'].'">'.$v['grouptitle'].'</option>';
                                    }
                                    ?>
                                </select>
                                <input type="submit" value="<?php echo $useriplang['aboc14'];?>" name="submit" id="submit_submit" class="btn">
                            </div>
                        </td>
                </tr>
	</tbody>
</table>
<?php
echo '<input type="hidden" name="formhash" value="'.FORMHASH.'" />';
showformfooter(); /*Dism��taobao��com*/
?>
<table>
	<tbody>
		<tr>
			<td colspan="5">
				<div class="cuspages right">
					<?php echo $multipage; ?>
				</div>
			</td>
		</tr>
	</tbody>
</table>
