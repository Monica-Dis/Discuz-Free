<?php
/**
 *	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *	$DisM!Ӧ�����ģ�dism.taobao.com $
 *	$���²����http://t.cn/Aiux1Jx1 $
 *	$Id: uninstall.php 40 2013-04-22 04:26:38Z HonHoo $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS pre_common_member_useripcount;
DROP TABLE IF EXISTS pre_common_member_userip;
DROP TABLE IF EXISTS pre_common_member_useriplog;
EOF;

runquery($sql);

$finish = TRUE;