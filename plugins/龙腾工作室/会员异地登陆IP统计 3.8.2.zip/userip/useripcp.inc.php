<?php
/**
 *	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *	$DisM!Ӧ�����ģ�dism.taobao.com $
 *	$���²����http://t.cn/Aiux1Jx1 $
 *	$Id: useripcp.inc.php 41 2013-04-22 06:28:41Z HonHoo $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$_GET = daddslashes($_GET);
$useriplang = lang('plugin/userip');



@set_time_limit(0);

if(submitcheck("submit")){
    if(!$_POST['groupid']){
        cpmsg($useriplang['aboc1']);
    }
    if(!isset($_POST['uids']) || !is_array($_POST['uids']) || !$_POST['uids']){
        cpmsg($useriplang['aboc2']);
    }
    if(DB::update("common_member", array('groupid'=>  intval($_POST['groupid'])), "uid IN(".  join(',', $_POST['uids']).")")){
        cpmsg($useriplang['aboc3'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=userip&pmod=useripcp', 'succeed');
    } else{
        cpmsg($useriplang['aboc4']);
    }
    exit;
}

$prepage = 20;
$page = max(1, $_GET['page']);
$start_limit = ($page - 1) * $prepage;

$where = array();
if($_GET['username']) {
	$usernamearr = explode(',', $_GET['username']);
	foreach($usernamearr as $username) {
		if(strpos('*', $username) !== false) {
			$username = str_replace('*', '%', $username);
			$w[] = "username LIKE '$username'";
		} else {
			$newuusernamearr[] = $username;
		}
	}
	$w[] = "username IN ('".implode("','", $newuusernamearr)."')";
	$urladd .= '&username='.$_GET['username'];
	$where[] = implode(' AND ', $w) ? implode(' AND ', $w) : '1';
}
if($_GET['ipcount']) {
	$query = DB::query('SELECT uid FROM '.DB::table('common_member_useripcount')." WHERE ipcount='$_GET[ipcount]'");
	$uids = array();
	while($value = DB::fetch($query)) {
		$uids[] = $value['uid'];
	}
        if($uids){
            $where[] = " uid IN(".  join(',', $uids).")";
        }
}
if($_GET['groupid']) {
	$query = DB::query('SELECT uid FROM '.DB::table('common_member')." WHERE groupid='$_GET[groupid]'");
        $uids = array();
	while($value = DB::fetch($query)) {
		$uids[] = $value['uid'];
	}
        if($uids){
            $where[] = " uid IN(".  join(',', $uids).")";
        }
}
if($_GET['uid']) {
	$uidarr = explode(',', $_GET['uid']);
	foreach($uidarr as $uid) {
		if(intval($uid)) {
			$newuidarr[] = $uid;
		}
	}
	$where[] = "uid IN ('".implode("','", $newuidarr)."')";
	$urladd .= '&uid='.$_GET['uid'];
}
if($_GET['area']) {
	$where[] = "area LIKE '%".$_GET['area']. "%'";
	$urladd .= '&area='.$_GET['area'];
}
if($_GET['ip']) {
    $where[] = "ip LIKE '".$_GET['ip']. "%'";
    $urladd .= '&ip='.$_GET['ip'];
}
if($_GET['dateline_after']) {
	$where[] = "dateline >= '".strtotime($_GET['dateline_after']). "'";
	$urladd .= '&dateline_after='.$_GET['dateline_after'];
}
if($_GET['dateline_before']) {
	$where[] = "dateline < '".(strtotime($_GET['dateline_before'])+60*60*24). "'";
	$urladd .= '&dateline_before='.$_GET['dateline_before'];
}
$where = implode(' AND ', $where) ? implode(' AND ', $where) : '1';
$url = 'admin.php?action=plugins&identifier=userip&pmod=useripcp';
$count = DB::result_first('SELECT count(uid) FROM '.DB::table('common_member_userip')." WHERE $where");
if($_GET['op'] == 'export') {
    if(!$count){
        cpmsg_error("not found");
    }
    $data = "$useriplang[username],$useriplang[dateline],$useriplang[ip],$useriplang[addr]\r\n";
    $list = DB::fetch_all('SELECT * FROM '.DB::table('common_member_userip')." WHERE $where ORDER BY dateline DESC");
    foreach($list as $key=> $value){
        if($key!=0){
            $data .= "\r\n";
        }
        $data .= "$value[username],".date('Y-m-d H:i:s', $value['dateline']).",$value[ip],".$value['area'];
    }
    ob_end_clean();
    dheader('Cache-control: max-age=0');
    dheader('Expires: '.gmdate('D, d M Y H:i:s', TIMESTAMP - 31536000).' GMT');
    dheader('Content-Encoding: none');
    dheader('Content-Disposition: attachment; filename='.date('Y-m-d_').time().'.csv');
    dheader('Content-Type: text/plain');
    echo $data;
    echo "\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n";
    ob_end_flush();
    exit;
}
if($count) {
	$multipage = multi($count, $prepage, $page, $url.$urladd);
	$limit = $_GET['op']!='export' ? "LIMIT $start_limit, $prepage" : '';
	$query = DB::query('SELECT * FROM '.DB::table('common_member_userip')." WHERE $where ORDER BY dateline DESC $limit");
	$list = array();
	while($value = DB::fetch($query)) {
		$value['ipcount'] = DB::result_first('SELECT ipcount FROM '.DB::table('common_member_useripcount')." WHERE uid='$value[uid]'");
		$value['usergroup'] = DB::result_first('SELECT grouptitle FROM '.DB::table('common_member')." m,".DB::table('common_usergroup')." u WHERE m.uid='$value[uid]' AND m.groupid=u.groupid");
		$list[] = $value;
		$data .= "$value[username],".date('Y-m-d H:i:s', $value['dateline']).",$value[ip],".$value['area']."\r\n";
	}
}

$urladd = '&page='.$page;
showformheader("plugins&operation=config&do=$pluginid&identifier=userip&pmod=useripcp");
?>
<table class="tb tb2 ">
	<tbody>
		<tr>
			<th class="partition" colspan="5">
				<?php echo $useriplang['total'];?><strong> <?php echo $count;?> </strong><?php echo $useriplang['users'];?>
                <a href="<?php echo "http://".$_SERVER ['HTTP_HOST'].$_SERVER['REQUEST_URI'];?>&op=export">[<?php echo $useriplang['export']?>]</a>
			</th>
		</tr>
	</tbody>
</table>
<table class="tb tb2 ">
	<tbody>
		<tr class="header">
            <td></td>
			<th><?php echo $useriplang['username'];?></th>
			<th><?php echo $useriplang['usergroup'];?></th>
			<th><?php echo $useriplang['ip'];?></th>
			<th><?php echo $useriplang['addr'];?></th>
			<th><?php echo $useriplang['areacount'];?></th>
			<th><?php echo $useriplang['dateline'];?></th>
		</tr>
		<?php foreach($list as $member) {?>
		<tr class="hover" id="member_<?php echo $member['uid'];?>">
            <td>
                <input type="checkbox" value="<?php echo $member['uid'];?>" name="uids[]" class="checkbox">
            </td>
			<td>
				<a href="admin.php?action=plugins&identifier=userip&pmod=useripcp&uid=<?php echo $member['uid'];?>"><?php echo $member['username'];?></a>
			</td>
			<td><?php echo $member['usergroup'];?></td>
			<td><?php echo $member['ip'];?></td>
			<td><?php echo $member['area'];?></td>
			<td><?php echo $member['ipcount'];?></td>
			<td><?php echo date('Y-m-d H:i:s', $member['dateline']);?></td>
		</tr>
		<?php } ?>
        <?php if($list): ?>
            <tr>
                <td class="td25">
                    <input type="checkbox" onclick="checkAll('prefix', this.form, 'uid')" class="checkbox" id="chkallHqdf" name="chkall">
                </td>
                <td colspan="6">
                    <div class="fixsel">
                        <?php
                        $groups = DB::fetch_all("SELECT * FROM ".DB::table("common_usergroup")." ORDER BY groupid ASC");
                        ?>
                        <select name="groupid">
                            <option value="0"><?php echo $useriplang['aboc13'];?></option>
                            <?php
                            foreach($groups as $v){
                                echo '<option value="'.$v['groupid'].'">'.$v['grouptitle'].'</option>';
                            }
                            ?>
                        </select>
                        <input type="submit" value="<?php echo $useriplang['aboc14'];?>" name="submit" id="submit_submit" class="btn">
                    </div>
                </td>
            </tr>
    <?php endif;?>
	</tbody>
</table>
<?php
echo '<input type="hidden" name="formhash" value="'.FORMHASH.'" />';
showformfooter(); /*Dism��taobao��com*/
?>
<table>
	<tbody>
		<tr>
			<td colspan="5">
				<div class="cuspages right">
					<?php echo $multipage; ?>
				</div>
			</td>
		</tr>
	</tbody>
</table>
