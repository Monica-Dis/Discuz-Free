<?php
/**
 *	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *	$DisM!Ӧ�����ģ�dism.taobao.com $
 *	$���²����http://t.cn/Aiux1Jx1 $
 *	$Id: userip.inc.php 107 2013-05-27 02:43:47Z HonHoo $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$useriplang = lang('plugin/userip');
$groupselect = array();
include_once(DISCUZ_ROOT.'source/discuz_version.php');
if(DISCUZ_VERSION < 'X2.5') {
	$query = DB::query("SELECT groupid, type, grouptitle, creditshigher, radminid FROM ".DB::table('common_usergroup')." WHERE type='member' AND creditshigher='0' OR (groupid NOT IN ('5', '6', '7') AND radminid<>'1' AND type<>'member') ORDER BY (creditshigher<>'0' || creditslower<>'0'), creditslower, groupid");
	while($group = DB::fetch($query)) {
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		if($group['type'] == 'member' && $group['creditshigher'] == 0) {
			$groupselect[$group['type']] .= "<option value=\"$group[groupid]\" selected>$group[grouptitle]</option>\n";
		} else {
			$groupselect[$group['type']] .= "<option value=\"$group[groupid]\">$group[grouptitle]</option>\n";
		}
	}
} else {
	$query = C::t('common_usergroup')->fetch_all_not(array(6, 7), true);
	foreach($query as $group) {
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		$groupselect[$group['type']] .= "<option value=\"$group[groupid]\" ".(in_array($group['groupid'], $usergroupid) ? 'selected' : '').">$group[grouptitle]</option>\n";
	}
}
$groupselect = '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
	($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
	($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
	'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup>';
?>
<table id="tips" class="tb tb2 ">
    <tbody>
        <tr>
            <th class="partition">
                <?php echo $useriplang['searchlog'];?>
            </th>
        </tr>
    </tbody>
</table>
<form id="searchform" action="admin.php?action=plugins&identifier=userip&pmod=useripcp" autocomplete="off" method="get" name="searchform">
    <input type="hidden" name="action" value="plugins"/>
    <input type="hidden" name="identifier" value="userip"/>
    <input type="hidden" name="pmod" value="useripcp"/>
    <input type="hidden" value="<?php echo FORMHASH;?>" name="formhash">
    <input type="hidden" value="" name="scrolltop" id="formscrolltop">
    <input type="hidden" value="" name="anchor">
    <table class="tb tb2 ">
        <tbody>
            <tr>
                <td s="1" class="td27" colspan="2">
                    <?php echo $useriplang['username'];?>:
                </td>
            </tr>
            <tr class="noborder">
                <td class="vtop rowform">
                    <input type="text" class="txt" value="" name="username">
                </td>
                <td s="1" class="vtop tips2">
                    <?php echo $useriplang['usernametips'];?>
                </td>
            </tr>
            <tr>
                <td s="1" class="td27" colspan="2">
                    <?php echo $useriplang['usergroup'];?>:
                </td>
            </tr>
            <tr class="noborder">
                <td class="vtop rowform">
                    <select name="groupid" size="10"><?php echo $groupselect;?></select>
                </td>
                <td s="1" class="vtop tips2">
                </td>
            </tr>
            <tr>
                <td s="1" class="td27" colspan="2">
                    <?php echo $useriplang['uid'];?>:
                </td>
            </tr>
            <tr class="noborder">
                <td class="vtop rowform">
                    <input type="text" class="txt" value="" name="uid">
                </td>
                <td s="1" class="vtop tips2">
                    <?php echo $useriplang['uidtips'];?>
                </td>
            </tr>
            <tr>
                <td s="1" class="td27" colspan="2">
                    <?php echo $useriplang['addr'];?>:
                </td>
            </tr>
            <tr class="noborder">
                <td class="vtop rowform">
                    <input type="text" class="txt" value="" name="area">
                </td>
                <td s="1" class="vtop tips2">
                    <?php echo $useriplang['addrtips'];?>
                </td>
            </tr>
            <tr>
                <td s="1" class="td27" colspan="2">
                    <?php echo $useriplang['areacount'];?>:
                </td>
            </tr>
            <tr class="noborder">
                <td class="vtop rowform">
                    <input type="text" class="txt" value="" name="ipcount">
                </td>
                <td s="1" class="vtop tips2">
                    <?php echo $useriplang['areacounttips'];?>
                </td>
            </tr>
            <tr>
                <td s="1" class="td27" colspan="2">
                    <?php echo $useriplang['ip'];?>:
                </td>
            </tr>
            <tr class="noborder">
                <td class="vtop rowform">
                    <input type="text" class="txt" value="" name="ip">
                </td>
                <td s="1" class="vtop tips2">
                    <?php echo $useriplang['iptips'];?>
                </td>
            </tr>
            <tr>
                 <td class="vtop rowform" colspan="2">
                    <p class="td27m">
                        <?php echo $useriplang['betweentime'];?>:
                    </p>
                    <input type="text" onclick="showcalendar(event, this)" style="width: 108px; margin-right: 5px;"
                    value="" name="dateline_after" class="txt">
                    --
                    <input type="text" onclick="showcalendar(event, this)" style="width: 108px; margin-left: 5px;"
                    value="" name="dateline_before" class="txt">
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <div class="fixsel">
                        <input type="submit" value="<?php echo $useriplang['search'];?>" name="searchsubmit"
                        id="submit_submit" class="btn">
                    </div>
                </td>
            </tr>
            <script type="text/JavaScript">
                _attachEvent(document.documentElement, 'keydown',
                function(e) {
                    entersubmit(e, 'submit');
                });
            </script>
        </tbody>
    </table>
	<script type="text/javascript" src="static/js/calendar.js"></script>
</form>