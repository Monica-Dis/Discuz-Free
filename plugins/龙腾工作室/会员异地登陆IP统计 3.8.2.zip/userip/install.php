<?php
/**
 *	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *	$DisM!Ӧ�����ģ�dism.taobao.com $
 *	$���²����http://t.cn/Aiux1Jx1 $
 *	$Id: install.php 39 2013-04-22 04:25:19Z HonHoo $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS pre_common_member_useripcount;
CREATE TABLE pre_common_member_useripcount (
  `uid` mediumint(8) unsigned NOT NULL,
  `ipcount` int(10) unsigned NOT NULL,
  KEY `uid` (`uid`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS pre_common_member_userip;
CREATE TABLE pre_common_member_userip (
  `uid` mediumint(8) unsigned NOT NULL,
  `username` char(15) NOT NULL DEFAULT '',
  `sid`  char(6) NOT NULL DEFAULT '',
  `ip` char(15) NOT NULL DEFAULT '',
  `area` varchar(64) NOT NULL DEFAULT '',
  `dateline` int(10) unsigned NOT NULL,
  KEY `uid` (`uid`, `ip`),
  KEY `username` (`username`),
  KEY `area` (`area`),
  KEY `dateline` (`dateline`)
) TYPE=MyISAM;

DROP TABLE IF EXISTS pre_common_member_useriplog;
CREATE TABLE `pre_common_member_useriplog` (
  `logid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `username` char(20) NOT NULL,
  `beforegid` tinyint(1) NOT NULL,
  `aftergid` tinyint(1) NOT NULL,
  `addtime` int(10) NOT NULL DEFAULT '0',
  `memo` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`logid`),
  KEY `uid` (`uid`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM;


EOF;

runquery($sql);

$finish = TRUE;

?>