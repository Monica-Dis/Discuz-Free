<?php
/**
 *	CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *	$DisM!Ӧ�����ģ�dism.taobao.com $
 *	$���²����http://t.cn/Aiux1Jx1 $
 *	$Id: userip.class.php 52 2013-04-25 08:50:11Z HonHoo $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_userip {

	function plugin_userip() {
		global $_G;

		include_once template('userip:module');
	}

	function common() {
		global $_G;
        if(!$this->check_control_group()){
            return;
        }
		if($_G['uid'] && !$_G['cookie']['member_login_status']) {
                    require_once libfile('function/misc');
                    $area = trim(str_replace('-', '', convertip($_G['clientip'])));
            $province = lang('plugin/userip', 'province');
            $province = explode("��",$province);
            foreach($province as $v){
                if(stripos($area,$v)!==false){
                    $area = $v;
                    break;
                }
            }
			$loginfo = DB::fetch_first("SELECT uid FROM ".DB::table('common_member_userip')." WHERE sid='$_G[sid]' AND uid='$_G[uid]' AND ip='$_G[clientip]'");
			if(!$loginfo) {
				$userip = DB::fetch_first("SELECT uid FROM ".DB::table('common_member_userip')." WHERE uid='$_G[uid]' AND area='$area'");
				if(!$userip) { //�����ڣ���ʾ���µ�ַ
					$uid = DB::result_first("SELECT uid FROM ".DB::table('common_member_useripcount')." WHERE uid='$_G[uid]'");
					if($uid) {
						DB::query("UPDATE ".DB::table('common_member_useripcount')." SET ipcount=ipcount+1 WHERE uid='$_G[uid]'");
					} else {
						$data = array(
							'uid'=> $_G['uid'],
							'ipcount'=> 1,
						);
						DB::insert('common_member_useripcount' ,$data);
					}
				}
				$data = array(
							'uid'=> $_G['uid'],
							'username'=> $_G['username'],
							'sid'=> $_G['sid'],
							'ip' => $_G['clientip'],
							'area' => $area,
							'dateline' => TIMESTAMP,
						);
				DB::insert('common_member_userip' ,$data);
			}
			dsetcookie('member_login_status', true);
		}
	}

	function global_footer() {
		global $_G;
        if(!$this->check_control_group()){
            return;
        }
		$params = $_G['cache']['plugin']['userip'];
		if(($params['notice1'] || $params['notice2']) && $_G['cookie']['loginunusual']!=-1) {
			$style = '';
			$ipcount = DB::result_first("SELECT ipcount FROM ".DB::table('common_member_useripcount')." WHERE uid='$_G[uid]'");
                        if($params['open_record']){
                            $view_record = '<br /><a href="plugin.php?id=userip:show" target="_blank">&gt;&gt;'.lang('plugin/userip', 'aboc20').'</a>';
                        } else {
                            $view_record = '';
                        }
			if($ipcount>=$params['notice1'] && $ipcount<$params['notice2']) {
				if($params['notice1_color']) {
					$style = 'color:'.$params['notice1_color'];
				}
				$params['notice1_content'] = str_replace("\r\n", "<br>", $params['notice1_content']);
                if($params['notice1_group'] && $_G['groupid']!=1){
                    if($params['notice1_group']!=$_G['groupid']){
                        DB::update("common_member", array('groupid'=>  $params['notice1_group']), "uid ='{$_G['uid']}'");
                        DB::insert("common_member_useriplog",array(
                            'uid' =>$_G['uid'],
                            'username'=>$_G['username'],
                            'beforegid'=>$_G['groupid'],
                            'aftergid'=>$params['notice1_group'],
                            'addtime'=>TIMESTAMP,
                            'memo'   => str_replace('{n}',$ipcount,lang('plugin/userip', 'first_notice')) ,
                        ));
                    }
                }
				return ui_tpl_global_footer($params['notice1_content'].$view_record, $style);
			} elseif($ipcount>=$params['notice2']) {
				if($params['notice2_color']) {
					$style = 'color:'.$params['notice2_color'];
				}
				$params['notice2_content'] = str_replace("\r\n", "<br>", $params['notice2_content']);
                if($params['notice2_group'] && $_G['groupid']!=1){
                    if($params['notice2_group']!=$_G['groupid']){
                        DB::update("common_member", array('groupid'=>  $params['notice2_group']), "uid ='{$_G['uid']}'");
                        DB::insert("common_member_useriplog",array(
                            'uid' =>$_G['uid'],
                            'username'=>$_G['username'],
                            'beforegid'=>$_G['groupid'],
                            'aftergid'=>$params['notice1_group'],
                            'addtime'=>TIMESTAMP,
                            'memo'   =>str_replace('{n}',$ipcount,lang('plugin/userip', 'second_notice')),
                        ));
                    }
                }
				return ui_tpl_global_footer($params['notice2_content'].$view_record, $style);
			}
		}
	}

    private function check_control_group(){
        global $_G;
        $control_group = unserialize($_G['cache']['plugin']['userip']['control_group']);
        if($control_group){
            foreach($control_group as $k => $v){
                if(empty($v)){
                    unset($control_group[$k]);
                }
            }
        }
        if($control_group){
            if(in_array($_G['groupid'],$control_group)){
                return true;
            } else{
                return fale;
            }
        }else{
            return true;
        }
    }
}

class plugin_userip_member extends plugin_userip {

	function logging_method() {
		global $_G;
		if($_GET['action'] == 'logout') {
			dsetcookie('member_login_status', '');
		}
	}
}
?>