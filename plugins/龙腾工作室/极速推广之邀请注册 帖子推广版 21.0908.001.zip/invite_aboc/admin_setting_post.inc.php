<?php
/**
 * admin_invite.inc.php
 * 应用更新支持：https://dism.taobao.com
* 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-3
 * Time: 下午11:13
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(submitcheck("setting",0)){
if(isset($_GET['share_thread_pic']) || isset($_FILES['share_thread_pic'])){
	if(!isset($_GET['share_thread_pic'])) {

		if ( $_FILES['share_thread_pic']['error'] == UPLOAD_ERR_OK ) {
			$upload = new discuz_upload();

			$upload->init( $_FILES['share_thread_pic'], 'album' );
			$attach = $upload->attach;
//			var_dump($attach);
			if ( ! $attach['isimage'] ) {
				cpmsg_error(lang( 'plugin/invite_aboc', 'aboc218' ));
			}
			if ( ! $upload->error() ) {
				$upload->save();
			}
			if ( $err =  $upload->error() ) {
				cpmsg_error($err);
			}

			$_GET['varsnew']['share_thread_pic'] = $attach['attachment'];
		}

	} else {
		$_GET['varsnew']['share_thread_pic'] = $_GET['share_thread_pic'];
	}
}

    C::t("#invite_aboc#invite_aboc")->post_setting();

    $menu_sort = isset($_GET['menu_sort']) ? $_GET['menu_sort'] : array();
    $menu_title = isset($_GET['menu_title']) ? $_GET['menu_title'] : array();

    asort($menu_sort);

    $menus = array();
    foreach($menu_sort as $key => $_){
        if(isset($menu_title[$key])) {
            $menus[$key] = $menu_title[$key];
        }
    }
    C::t("common_setting")->update("invite_aboc_menu" , $menus);

    cpmsg(lang('plugin/invite_aboc', 'aboc91'),"",'succeed');
}