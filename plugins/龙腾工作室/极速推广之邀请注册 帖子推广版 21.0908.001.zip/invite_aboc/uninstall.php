<?php
/**
 *	[邀请注册(invite_aboc.uninstall)] (C)2014-2099 Powered by aboc.
 *	Version: 1.0.0
 *	Date: 2014-8-30 21:01
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$table = DB::table('invite_aboc');
$membertable = DB::table("common_member");
$tablegoods = DB::table("invite_goods");
$tablemobile = DB::table("invite_mobile");
$tableexchange = DB::table("invite_exchange_log");
$forum_order_table = DB::table("forum_order");
$share_log_table = DB::table("invite_aboc_share_log");
$poster_table = DB::table("invite_poster");
$log_table = DB::table("invite_aboc_log");
$url_table = DB::table("invite_url");
$card_table = DB::table("common_card");
$sql = <<<EOF
DROP TABLE IF EXISTS `$table`;
DROP TABLE IF EXISTS `$tablegoods`;
DROP TABLE IF EXISTS `$tableexchange`;
DROP TABLE IF EXISTS `$tablemobile`;
DROP TABLE IF EXISTS `$share_log_table`;
DROP TABLE IF EXISTS `$log_table`;
DROP TABLE IF EXISTS `$poster_table`;
DROP TABLE IF EXISTS `$url_table`;
ALTER TABLE `$membertable` DROP `invite_change`;
ALTER TABLE `$membertable` DROP `mobilestatus`;
ALTER TABLE `$membertable` DROP `invite_num`;
ALTER TABLE `$forum_order_table` DROP `invite_aboc`;
ALTER TABLE `$card_table` DROP `invite_aboc`;
EOF;

runquery($sql);
$finish = true;
?>