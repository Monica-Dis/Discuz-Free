<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
/**
 * wordmarkinimage ????????????????????
 * ??????????
 * 1??????????
 * $tpl=new wordmarkinimage;
 * 2????????????????
 * $tpl->img(??????,??????,???array(0,0,0), ??????x, ??????y, ????????,???????,??????);
 * ?????$tpl->img('abc.jpg','??????????',array(0,0,0),30,50,'ziti.ttf',30,0)
 * ??
 */
class wordmarkinimage {
	public $error = '';
	private $image;
	private $img_info;
	private $img_width;
	private $img_height;
	private $img_im;
	private $img_text;
	private $img_ttf = '';
	private $img_new;
	private $img_text_size;
	private $img_text_color;
	private $img_text_positonx = 0;
	private $img_text_positony = 0;
	private $img_angle = 0;
	/**
	 * ??????????
	 * @var bool
	 */
	private $is_position = false;
	private $bg_color = array();
	private $text_align = 'center';
	private $offset_horizontal = 0; //?????
	private $offset_vertical = 0; //??????
	private $position = 'top';
	private $bg_height = 0;

	/**
	 * @param string $img    ??????
	 * @param string $txt??????????????
	 * @param array  $color   0-255?????????
	 * @param int    $x?????????????
	 * @param int    $y?????????????
	 * @param string $ttf??????????
	 * @param int    $size??????????
	 * @param int    $angle???????
	 */
	function img($img , $txt , $color = array(0,0,0), $x = 0, $y = 0, $ttf = 'font/msyh.ttf', $size = 12, $angle = 0) {
		if ( isset( $img ) && file_exists( $img ) ) {//???????????
			if ( file_exists( $ttf ) ) {
				$this->img_ttf = $ttf;
			} else {
				$this->error =  'font' . $ttf . ' not found' ;
				return false;
			}
			$this->image             = $img;
			$this->img_text          = $txt;
			$this->img_text_size     = $size;
			$this->img_text_color    = $color;
			$this->img_text_positonx = $x;
			$this->img_text_positony = $y;
			$this->img_angle        = $angle;
			return $this->create_im();
		} else {
			$this->error =  $img . ' not found' ;
			return false;
		}
	}

	/**
	 * @param        $img
	 * @param        $txt
	 * @param array  $color
	 * @param string $text_align
	 * @param string $position
	 * @param string $ttf
	 * @param int    $size
	 * @param int    $offset_horizontal
	 * @param int    $offset_vertical
	 * @param string $bg_color   ???????????????????
	 *
	 * @return bool
	 */
	function img_position($img,$txt,$color=array(0,0,0),$text_align='center',$position='top',$ttf='font/msyh.ttf',$size=12,$offset_horizontal=0,$offset_vertical=0,$bg_color=array()){
		if ( isset( $img ) && file_exists( $img ) ) {//???????????
			if ( file_exists( $ttf ) ) {
				$this->img_ttf = $ttf;
			} else {
				$this->error =  'font ' . $ttf . ' not found ' ;
				return false;
			}
			$this->image          = $img;
			$this->img_text       = $txt;
			$this->img_text_size  = $size;
			$this->img_text_color = $color;
			$this->is_position    = true;
			$this->bg_color       = $bg_color;
			$this->text_align     = $text_align;
			$this->position       = $position;
			$this->offset_horizontal         = $offset_horizontal;
			$this->offset_vertical         = $offset_vertical;
			return $this->create_im();
		} else {
			$this->error = $img . ' not found' ;
			return false;
		}
		return true;
	}

	private function create_im() {

		$this->img_info   = getimagesize( $this->image );
		$this->img_width  = $this->img_info[0];//????
		$this->img_height = $this->img_info[1];//????

		//?????????
		switch ( $this->img_info[2] ) {
			case 1:
				$this->img_im = imagecreatefromgif( $this->image );
				break;
			case 2:
				$this->img_im = imagecreatefromjpeg( $this->image );
				break;
			case 3:
				$this->img_im = imagecreatefrompng( $this->image );
				break;
			default:
				$this->error = 'error pic format';
				return false;
		}

		return $this->img_text();
	}


	private function img_text() {
		imagesavealpha($this->img_im, true);
		imagealphablending( $this->img_im, true );

		//?????
		$color      = imagecolorallocate( $this->img_im, $this->img_text_color[0], $this->img_text_color[1], $this->img_text_color[2] );
		if($this->is_position) {
			$ttf_im     = imagettfbbox( $this->img_text_size, $this->img_angle, $this->img_ttf, $this->img_text );
			$w          = $ttf_im[2] - $ttf_im[6];
			$h          = $ttf_im[3] - $ttf_im[7];

            unset( $ttf_im );
            
            //?????
			if($this->text_align == 'center'){
				$this->img_text_positonx = ceil(($this->img_width - $w) /2)+$this->offset_horizontal;
			}
			elseif($this->text_align == 'right'){
				$this->img_text_positonx = ceil($this->img_width-$w)-$this->offset_horizontal;
			} else {
				$this->img_text_positonx = 0+$this->offset_horizontal;
			}
            
            //??????
			if($this->position == 'bottom'){
				$this->img_text_positony = $this->img_height - $this->offset_vertical - ceil($h/2);
			}
			elseif($this->position == 'middle'){
				$this->img_text_positony = ceil($this->img_height /2)+$this->offset_vertical;
			}
			else {
				//top
				$this->img_text_positony = $this->offset_vertical + $h;
			}
            
			if($this->bg_color){
				$this->bg_height = $h+6;
			}
		}

		$this->background();

		$this->img_new = @imagettftext( $this->img_im, $this->img_text_size, $this->img_angle, $this->img_text_positonx, $this->img_text_positony, $color, $this->img_ttf, $this->img_text );

		@unlink( $this->image );//?????
		switch ( $this->img_info[2] ) {//????????????
			case 1:
				imagegif( $this->img_im, $this->image );
				break;
			case 2:
				imagejpeg( $this->img_im, $this->image,100 );
				break;
			case 3:
				imagepng( $this->img_im, $this->image,9 );
				break;
			default:
				$this->error = 'deal image error' ;
				return false;
		}
		$this->img_nothing();
		return true;
	}

	private function background(){
		if(!$this->bg_color){
			return;
		}
		$offset = ceil($this->bg_height/4);
		$x = $this->img_text_positony-ceil(($this->bg_height)/2)-$offset;
		$result = imagefilledrectangle($this->img_im,0,$x,$this->img_width,$x+$this->bg_height,imagecolorallocate($this->img_im,$this->bg_color[0],$this->bg_color[1],$this->bg_color[2]));
	}

	//??????
	private function img_nothing() {
		unset( $this->img_info );
		imagedestroy( $this->img_im );
	}
}

