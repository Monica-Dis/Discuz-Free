<?php
/**
 * admin_invite.inc.php
 * 应用更新支持：https://dism.taobao.com
* 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-3
 * Time: 下午11:13
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once "public.inc.php";
$act = isset($_GET['act']) ? trim($_GET['act']) : '';



    if(submitcheck('submit')){
        $f = array_map("trim", $_GET);
        if($f['username'] == ""){
            cpmsg_error(lang('plugin/invite_aboc', 'aboc195'));
        }
        $number = intval($f['number']);
        if($number <= 0){
	        cpmsg_error(lang('plugin/invite_aboc', 'aboc196'));
        }

        $userinfo = C::t("common_member")->fetch_by_username($f['username']);
        if(!$userinfo){
	        cpmsg_error(lang('plugin/invite_aboc', 'aboc197'));
        }
        if(DB::update("common_member",array("invite_num"=>$userinfo['invite_num'] + $number),"uid='{$userinfo['uid']}'")){

                cpmsg(lang('plugin/invite_aboc', 'aboc198').($userinfo['invite_num'] + $number),"action=plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_integral_add",'succeed');
        } else {
            cpmsg_error(lang('plugin/invite_aboc', 'aboc93'));
        }
    }
    showformheader("plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_integral_add&");
        showtableheader( lang('plugin/invite_aboc', 'aboc193').$invite_setting['integral_name'] );
    showsetting(lang('plugin/invite_aboc', 'aboc70'),'username','','text','',0,lang('plugin/invite_aboc', 'aboc70'));
    showsetting(lang('plugin/invite_aboc', 'aboc194'),'number','','number','',0,lang('plugin/invite_aboc', 'aboc194'), '');
    showhiddenfields(array(
        'formhash'=>FORMHASH
    ));
    showsubmit('submit',lang('plugin/invite_aboc', 'aboc75'));

    showtablefooter(); /*dism·taobao·com*/


