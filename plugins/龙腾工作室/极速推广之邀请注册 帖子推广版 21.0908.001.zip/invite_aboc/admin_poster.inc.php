<?php
if ( ! defined( 'IN_DISCUZ' ) || ! defined( 'IN_ADMINCP' ) ) {
    exit( 'Access Denied' );
}
include_once "public.inc.php";

$act = isset($_GET['act']) ? trim($_GET['act']) : '';
$siteurl = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'];

if( $act == "add") {

    $poster_id = isset($_GET['poster_id']) ? intval($_GET['poster_id']) : 0;

    $info = C::t("#invite_aboc#invite_poster")->fetch($poster_id);
    if($poster_id && !$info){
        cpmsg_error(lang('plugin/invite_aboc', 'aboc330'));
    }
//print_r($info);exit;
    if(submitcheck('submit')){
        $f = array_map("trim", $_GET);
        if($f['title'] == ""){
            cpmsg_error(lang('plugin/invite_aboc', 'aboc331'));
        }

        if($f['image'] == ""){
            cpmsg_error(lang('plugin/invite_aboc', 'aboc332'));
        }

        $result = C::t("#invite_aboc#invite_poster")->add($f,$poster_id);
        if($result){
            if($poster_id){
                cpmsg(lang('plugin/invite_aboc', 'aboc333'),"action=plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_poster",'succeed');
            } else {
                cpmsg(lang('plugin/invite_aboc', 'aboc334'),"action=plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_poster",'succeed');
            }
        } else {
            cpmsg_error(lang('plugin/invite_aboc', 'aboc335'));
        }
    }
    showformheader("plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_poster&act=add&poster_id=".$poster_id, 'enctype="multipart/form-data"');
    if($info){
        showtableheader( lang('plugin/invite_aboc', 'aboc336') );
    } else {
        showtableheader( lang('plugin/invite_aboc', 'aboc337') );
    }
    showsetting(lang('plugin/invite_aboc', 'aboc338'),'title',$info?$info['title']:'','text','',0,lang('plugin/invite_aboc', 'aboc97'));

    $image = $info ? $info['image'] : '';
//    $siteurl = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'];
    $image_url = $image ? $siteurl. $image:"";
    $formhash = FORMHASH;
    $data = $info ? $info['data'] : '';
    $upload_pic = lang('plugin/invite_aboc', 'aboc339');
    $str = <<<DDD
<script src="source/plugin/invite_aboc/imgs/js/jcrop/js/jquery.min.js"></script>
<script>var uploadImageUrl= 'admin.php?action=plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_poster&act=upload',formhash='$formhash';jQuery.noConflict(); </script>
<script src="source/plugin/invite_aboc/imgs/js/jcrop/js/jquery.Jcrop.min.js"></script>
<link rel="stylesheet" href="source/plugin/invite_aboc/imgs/js/jcrop/css/jquery.Jcrop.min.css" />
<div>
<a href="javascript:;" onclick="upImage()">$upload_pic</a>
</div>
<div>
<input type="hidden" name="image" id="image" value="$image" >
<input type="hidden" name="data" id="data" value="$data" >
<img src="$image_url" style="display: none" id="poseter_privew" />
</div>
<script src="source/plugin/invite_aboc/imgs/js/admin.js"></script>
DDD;


    showsetting(lang('plugin/invite_aboc', 'aboc340'),'image',$info?$info['image']:'',$str,'',0,lang('plugin/invite_aboc', 'aboc341'));


    showhiddenfields(array(
        'formhash'=>FORMHASH
    ));
    showsubmit('submit',lang('plugin/invite_aboc', 'aboc75'));

    showtablefooter(); /*dism��taobao��com*/

}
elseif($act == 'upload'){
    ob_end_clean();
    ob_start();


    $image = "";
    $upload = new discuz_upload();
    if($upload->init($_FILES['file'], 'common') && $upload->save(1)) {

        echo $siteurl.'||'.'common/'.$upload->attach['attachment'].'||';
    }
    ob_end_flush();
}
elseif($act == "delete"){
    if(submitcheck('del','post')){
        if(!isset($_GET['delete']) || !is_array($_GET['delete'])){
            cpmsg_error(lang('plugin/invite_aboc', 'sc'));
        }
        $_GET['delete'] = array_map("intval",$_GET['delete']);
        DB::delete("invite_poster","poster_id IN(".join(',',$_GET['delete']).")");
        cpmsg(lang('plugin/invite_aboc', 'sccg'));
    }
}
else{

?>
    <table class="tb tb2 ">
        <tbody>
        <tr class="hover">
            <td style="width:430px;text-align: left">
                <a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=58&identifier=invite_aboc&pmod=admin_poster&act=add" style="font-weight: normal;"><?php echo lang('plugin/invite_aboc', 'aboc337');?></a>
            </td>
        </tr>
        </tbody>
    </table>
<?php


    $list  = C::t("#invite_aboc#invite_poster")->get_poster_list();
    showformheader("plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_poster&act=delete");
    ?>
    <table class="tb tb2 ">
        <tbody>
        <tr class="header">
            <th style="width:20px;"></th>
            <th>ID</th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc338');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc340');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc61');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc62');?></th>
        </tr>
        <?php
        foreach($list as $k => $v) {
            ?>
            <tr class="hover">
                <td>
                    <input type="checkbox" value="<?php echo $v['poster_id'];?>" name="delete[]" class="checkbox">
                </td>
                <td><?php echo $v['poster_id'];?></td>
                <td><?php echo $v['title'];?></td>
                <td><img src="<?php echo $siteurl.$v['image'];?>" style="max-width: 200px;max-height: 300px;" /></td>
                <td><?php echo date("Y-m-d H:i:s",$v['add_time']);?></td>
                <td>
                    <a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $pluginid;?>&identifier=invite_aboc&pmod=admin_poster&act=add&poster_id=<?php echo $v['poster_id'];?>"><?php echo lang('plugin/invite_aboc', 'aboc83');?></a>
                </td>
            </tr>
            <?php
        }
        ?>
        <tr><td class="td25">&nbsp;</td><td colspan="15"><div class="fixsel">
                    <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>" />
                    <input type="submit" value="<?php echo lang('plugin/invite_aboc', 'delete'); ?>" name="del" id="submit_submit" class="btn">
                </div></td></tr>
        </tbody>
    </table>
    <?php
    showformfooter();

}


