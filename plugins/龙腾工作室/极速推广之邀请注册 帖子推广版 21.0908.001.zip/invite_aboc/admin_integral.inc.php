<?php
/**
 * admin_invite.inc.php
 * 应用更新支持：https://dism.taobao.com
* 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-3
 * Time: 下午11:13
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once "public.inc.php";
include_once "admin_setting_post.inc.php";

showformheader("plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_integral","enctype","sform","post");
showtableheader( );
showsetting(lang( 'plugin/invite_aboc', 'aboc180' ).$invite_setting['integral_name'],"varsnew[invite_1]",$invite_setting["invite_1"],"number");
showsetting(lang( 'plugin/invite_aboc', 'aboc181' ).$invite_setting['integral_name'],"varsnew[invite_2]",$invite_setting["invite_2"],"number");
showsetting(lang( 'plugin/invite_aboc', 'aboc182' ).$invite_setting['integral_name'],"varsnew[invite_3]",$invite_setting["invite_3"],"number");
$pay_option = array();
foreach($_G['setting']['extcredits'] as $k => $v){
    $pay_option[] = array($k,$v['title']);
}
showsetting(lang( 'plugin/invite_aboc', 'aboc1821' ),array("varsnew[pay_type]",$pay_option),$invite_setting["pay_type"],"select");
showsetting(lang( 'plugin/invite_aboc', 'aboc183' ),"varsnew[pay_1]",$invite_setting["pay_1"],"text","",0,"%");
showsetting(lang( 'plugin/invite_aboc', 'aboc184' ),"varsnew[pay_2]",$invite_setting["pay_2"],"text","",0,"%");
showsetting(lang( 'plugin/invite_aboc', 'aboc185' ),"varsnew[pay_3]",$invite_setting["pay_3"],"text","",0,"%");

showsetting(lang( 'plugin/invite_aboc', 'aboc217' ),"share_thread_pic",$invite_setting["share_thread_pic"],"filetext","",0,lang( 'plugin/invite_aboc', 'aboc219' ));

showhiddenfields(array(
    'formhash'=>FORMHASH
));
showsubmit('setting',lang('plugin/invite_aboc', 'aboc75'));

showtablefooter(); /*dism·taobao·com*/
showformfooter();