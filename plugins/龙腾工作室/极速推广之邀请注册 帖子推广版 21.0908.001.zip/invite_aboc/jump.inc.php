<?php
/**
 * jump.inc.php
 * 应用更新支持：https://dism.taobao.com
* 最新插件：http://t.cn/Aiux1Jx1
 * Date: 19-7-30
 * Time: 下午11:12
 * Ver : 1.0.0
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once "invite.fun.php";
include_once "public.inc.php";


$fromuid = isset($_GET['fromuid'])?intval($_GET['fromuid']):0;
$tid = isset($_GET['tid'])?intval($_GET['tid']):0;


C::t("#invite_aboc#invite_aboc_share_log")->integral($tid,$fromuid);


header("location:forum.php?mod=viewthread&tid=".$tid);