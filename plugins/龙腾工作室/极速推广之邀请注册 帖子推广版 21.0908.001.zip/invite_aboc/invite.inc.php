<?php
/**
 * invite.inc.php
 * 应用更新支持：https://dism.taobao.com
* 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-1
 * Time: 下午11:00
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once "invite.fun.php";
include_once "public.inc.php";
loadcache('pluginlanguage_template');


$promotion_url_copied = lang("home/template", "promotion_url_copied");

$isAppbyme = strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false;
$http = _https() ? 'https://' : 'http://';
if($isAppbyme && !$_G['uid']){
	exit('<script language="javascript" src="mobcent/app/web/js/appbyme/appbyme.js"></script><script>connectAppbymeJavascriptBridge(function(bridge){
		AppbymeJavascriptBridge.login(function(data){
			top.location.href="'.$http.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].'";
		});
	});
	</script>');
}

if(!$_G['uid']){
	showmessage(lang('plugin/invite_aboc', 'aboc193'), 'member.php?mod=logging&action=login&referer='.dreferer(),'error');
}
$member_extcredits = C::t("common_member_count")->fetch($_G['uid']);

//print_r($member_extcredits);
//print_r($_G['setting']['extcredits']);

$share_url = $_G['siteurl'] . 'forum.php?register=1&fromuid=' . $_G['uid'];

$invite_aboc = $_G['cache']['plugin']['invite_aboc'];
$invite_aboc['ban_group_id'] = @unserialize($invite_aboc['ban_group_id']);
$do = isset($_GET['do']) ? trim($_GET['do']) : '';

$menus = get_menu();



$last_exchange = C::t("#invite_aboc#invite_exchange_log")->get_last_list();


	if(empty($_G['cache']['usergroups'])) {
		loadcache('usergroups');
	}
	$where = " WHERE fromuid='{$_G['uid']}'";
	$invite_total = DB::fetch_first("select count(a.uid) as num from " . DB::table("invite_aboc")." a " . $where."");
	$invite_total['status_1'] = C::t("#invite_aboc#invite_aboc")->get_fromuid_num($_G['uid'],1);
	$invite_total['status_0'] = C::t("#invite_aboc#invite_aboc")->get_fromuid_num($_G['uid'],0);
	$invite_total['status_0_temp'] = C::t("#invite_aboc#invite_aboc")->get_fromuid_num($_G['uid'],0,1);
	$from_users = C::t("#invite_aboc#invite_aboc")->get_fromuser(C::t("#invite_aboc#invite_aboc")->get_invite_users($_G['uid']));
	
	$new_userlist = DB::fetch_all('SELECT * FROM %t WHERE status=1 and level=1 ORDER BY addtime DESC LIMIT 0,8', array('invite_aboc'));
	$new_userlistarr = array();
	foreach($new_userlist as $k => $v){
		$fromuid = getuserbyuid($v['fromuid']);
		$new_userlistarr[$k] = $v;
		$new_userlistarr[$k]['fromuid_name'] = $fromuid['username'];
		$new_userlistarr[$k]['groupid_name'] = $_G['cache']['usergroups'][$v['groupid']]['grouptitle'];
		$new_userlistarr[$k]['addtime'] = $v['addtime'] ? dgmdate($v['addtime']) : '';
	}
if ($do == "") {
    $is_ban = $invite_aboc['ban_group_id']&&in_array($_G['member']['groupid'],$invite_aboc['ban_group_id'])?1:0;
    $upgrade_group = isset($_G['cache']['usergroups'][$invite_aboc['upgrade_group_id']]['grouptitle']) ? $_G['cache']['usergroups'][$invite_aboc['upgrade_group_id']]['grouptitle'] : '';

}elseif($do == 'list'){
    $page = isset($_GET['page'])?intval($_GET['page']):1;
    $num = 15;
    $where = " WHERE fromuid='{$_G['uid']}'";
    $total = DB::fetch_first("select count(a.uid) as num from " . DB::table("invite_aboc")." a " . $where);
    $total = isset($total['num']) ? $total['num'] : 0;
    $list = DB::fetch_all("select a.*,m.groupid,a.groupid as groupid3,groupexpiry from " . DB::table("invite_aboc") . " a LEFT JOIN ".DB::table("common_member")." m ON a.uid=m.uid  $where ORDER BY addtime DESC " .(!isset($_GET['excel'])? DB::limit(($page - 1) * $num, $num):''));
//    print_r($list);
    foreach($list as $k => $v){
        if(isset($_G['cache']['usergroups'][$v['groupid']]['grouptitle'])){
            $list[$k]['group'] = $_G['cache']['usergroups'][$v['groupid']]['grouptitle'];
        } else {
            $list[$k]['group'] = lang('plugin/invite_aboc', 'wz');
        }
    }
    if(isset($_GET['excel'])){
        header("Content-type:application/vnd.ms-excel");
        header("Content-Disposition:attachment;filename=list-" . date("Y-m-d") . ".xls");
        ?>
        <table cellspacing="0" cellpadding="0" border="1" class="dt mtm">
            <tr>
                <th><?php echo lang('plugin/invite_aboc', 'username');?></th>
                <th><?php echo lang('plugin/invite_aboc', 'group');?></th>
                <th><?php echo lang('plugin/invite_aboc', 'addtime');?></th>
                <th><?php echo lang('plugin/invite_aboc', 'status');?></th>
            </tr>
            <?php
            foreach($list as $key=> $value) {
                ?>
                <tr>
                    <td><?php echo $value['username'];?></a></td>
                    <td><?php echo $value['group'];?></td>
                    <td><?php echo date("Y-m-d H:i:s",$value['addtime']);?></td>
                    <td>
                        <?php
                        if($value['status']){
                            echo lang('plugin/invite_aboc', 'good');
                        } else {
                            if($value['groupid3'] == 8){
                                echo "<span style='color:blue'>" . lang('plugin/invite_aboc', 'bad_temp') . "</span>";
                            } else {
                                echo "<span style='color:red'>" . lang('plugin/invite_aboc', 'bad') . "</span>";
                            }
                        }
                        ?>
                    </td>
                </tr>
            <?php
            }
            ?>
        </table>
        <?php
        exit;
    }
    $pagelist = multi($total, $num, $page, "plugin.php?id=invite_aboc:invite&do=list", ceil($total / $num),10, true);
	$thisurl = 'plugin.php?'.$_SERVER['QUERY_STRING'];
}
elseif($do == 'share'){
	$page = isset($_GET['page'])?intval($_GET['page']):1;
	$num = 15;
	$where = " WHERE fromuid='{$_G['uid']}'";
	$total = DB::fetch_first("select COUNT(f.log_id) AS num  from " . DB::table("invite_aboc_share_log") ." f LEFT JOIN ".DB::table("forum_thread")." t ON t.tid=f.tid  " .$where." ");
	$total = isset($total['num']) ? $total['num'] : 0;
	$list = DB::fetch_all("select *,f.dateline as fdateline  from " . DB::table("invite_aboc_share_log") ." f  LEFT JOIN ".DB::table("forum_thread")." t ON t.tid=f.tid  " .$where." ORDER BY log_id DESC " .(!isset($_GET['excel'])? DB::limit(($page - 1) * $num, $num):''));
//    print_r($list);
	foreach($list as $k => $v){

	}

	$pagelist = multi($total, $num, $page, "plugin.php?id=invite_aboc:invite&do=share", ceil($total / $num),10, true);
	$thisurl = 'plugin.php?'.$_SERVER['QUERY_STRING'];
}
elseif($do == 'exchange'){
    $page = isset($_GET['page'])?intval($_GET['page']):1;
    $num = 15;
    $where = " WHERE uid='{$_G['uid']}'";
    $total = DB::fetch_first("select count(*) as num from " . DB::table("invite_exchange_log")." a " . $where);
    $total = isset($total['num']) ? $total['num'] : 0;
    $list = DB::fetch_all("select * from " . DB::table("invite_exchange_log") . " a   $where ORDER BY FIELD(status,0,1,-1),log_id DESC " . DB::limit(($page - 1) * $num, $num));
    foreach($list as $k => $v){
        switch($v['status']){
            case 0:
                $list[$k]['status_name'] = lang('plugin/invite_aboc', 'aboc52');
                break;
            case 1:
                $list[$k]['status_name'] = lang('plugin/invite_aboc', 'aboc53');
                break;
            case -1:
                $list[$k]['status_name'] = lang('plugin/invite_aboc', 'aboc54');
                break;
        }
    }
    $pagelist = multi($total, $num, $page, "plugin.php?id=invite_aboc:invite&do=exchange", ceil($total / $num),10, true);
}
elseif($do == 'doexchange'){
	$goods_list = C::t("#invite_aboc#invite_goods")->get_goods_list();
	$can_invite =  $_G['member']['invite_num'] -$_G['member']['invite_change'];
	if(submitcheck('change',1)){
		$goods_id = isset($_GET['goods_id'])?intval($_GET['goods_id']):0;
		if(!$goods_id){
			echo '-1|'.lang('plugin/invite_aboc', 'aboc104');exit;
		}
		echo C::t("#invite_aboc#invite_exchange_log")->exchange( $goods_id, $_G, $invite_aboc);exit;
	}
}
elseif($do == 'top'){
    $week_time = strtotime("-1week",$_G['timestamp']);

    $share_top = DB::fetch_all("SELECT sl.fromuid,m.username,COUNT(sl.log_id) AS num FROM %t sl LEFT JOIN %t m ON sl.fromuid=m.uid WHERE sl.dateline>=%d GROUP BY sl.fromuid ORDER BY num DESC",array("invite_aboc_share_log","common_member",$week_time));


	$share_integral_top = DB::fetch_all("SELECT sl.uid,m.username,SUM(sl.number) AS num FROM %t sl LEFT JOIN %t m ON sl.uid=m.uid WHERE sl.dateline>=%d GROUP BY sl.uid ORDER BY num DESC",array("invite_aboc_log","common_member",$week_time));


	$exchange_list = DB::fetch_all("SELECT uid,username,name FROM %t  WHERE status=1 ORDER BY log_id DESC LIMIT 10",array("invite_exchange_log"));
//	print_r($exchange_list);
//    print_r($share_top);
}

$key = isset($_GET['key']) ? intval($_GET['key']) : 0;
$siteurl = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'];
$poster_list  = C::t("#invite_aboc#invite_poster")->get_poster_list();
$next_key = $key +1;
$poster_count = count($poster_list);
if($next_key >= $poster_count ){
    $next_key = 0;
}


include template("invite_aboc:invite");

function _https(){
    if(!isset($_SERVER['HTTPS'])) return false;
		if($_SERVER['HTTPS'] === 1){
			return true;
		}else if($_SERVER['HTTPS'] === 'on'){
			return true;
		}else if($_SERVER['SERVER_PORT'] == 443){
			return true;
		}
    return false;
}