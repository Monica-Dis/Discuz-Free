<?php
/**
 * jump.inc.php
 * 应用更新支持：https://dism.taobao.com
* 最新插件：http://t.cn/Aiux1Jx1
 * Date: 19-7-30
 * Time: 11:12
 * Ver : 1.0.0
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
error_reporting(E_ALL);
ini_set("display_errors","on");
include_once "invite.fun.php";
include_once "public.inc.php";

$invite_setting = $_G['cache']['plugin']['invite_aboc'] ;

$fromuid = isset($_GET['fromuid'])?intval($_GET['fromuid']):0;
$tid = isset($_GET['tid'])?intval($_GET['tid']):0;

$url = isset($_GET['url'])?trim($_GET['url']):$_G['siteurl'];

$thread = C::t("forum_thread")->fetch($tid);


//print_r($invite_setting);
$pic = $_G['setting']['attachdir'].'album/'.$invite_setting['share_thread_pic'];

if(!file_exists($pic) || !$thread){
	exit;
}

include_once "wordmarkinimage.class.php";
include_once 'qrcode.class.php';
$invite_setting['share_thread_content_hb'] = str_replace(
	array('{subject}','{username}'),
	array($thread['subject'],$_G['username']),
	$invite_setting['share_thread_content_hb']);
$invite_setting['share_thread_content_hb'] = nl2br($invite_setting['share_thread_content_hb']);
$invite_setting['share_thread_content_hb'] = explode("<br />", $invite_setting['share_thread_content_hb'],3);


$new_pic = $pic."_{$fromuid}_{$tid}.jpg";


QRcode::png($url,$new_pic."_.png","L",5,2);
$im = _imagecreate($pic);
$qrcode_im = _imagecreate($new_pic."_.png");

imagecopy($im,$qrcode_im,272,925,0,0,250,250);

imagejpeg($im,$new_pic);

$img = new wordmarkinimage();

if(strtolower(CHARSET) !="utf-8"){
	foreach($invite_setting['share_thread_content_hb'] as $k => $value){
		$invite_setting['share_thread_content_hb'][$k] = iconv(CHARSET,"UTF-8",$value);
	}
}

if(isset($invite_setting['share_thread_content_hb'][0]) && $invite_setting['share_thread_content_hb'][0]) {
	$img->img_position( $new_pic, $invite_setting['share_thread_content_hb'][0], array(
		0,
		0,
		0
	), "center", "top", dirname( __FILE__ ) . "/font/msyh.ttf", 16, 0, 380 );
}
if(isset($invite_setting['share_thread_content_hb'][1]) && $invite_setting['share_thread_content_hb'][1]) {
	$img->img_position( $new_pic, $invite_setting['share_thread_content_hb'][1], array(
		0,
		0,
		0
	), "center", "top", dirname( __FILE__ ) . "/font/msyh.ttf", 16, 0, 435 );
}
if(isset($invite_setting['share_thread_content_hb'][2]) && $invite_setting['share_thread_content_hb'][2]) {
	$img->img_position( $new_pic, $invite_setting['share_thread_content_hb'][2], array(
		215,
		0,
		59
	), "center", "top", dirname( __FILE__ ) . "/font/msyh.ttf", 16, 0, 510 );
}
//header("location:source/plugin/invite_aboc/imgs/share_pic.png");
header("Content-Type: image/jpeg");
echo file_get_contents($new_pic);
//imagepng($im);