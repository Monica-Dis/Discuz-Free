<?php
/**
 * admin_invite.inc.php
 * 应用更新支持：https://dism.taobao.com
* 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-3
 * Time: 下午11:13
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once "public.inc.php";
$act = isset($_GET['act']) ? trim($_GET['act']) : '';
$goods_id = isset($_GET['goods_id']) ? intval($_GET['goods_id']) : 0;
loadcache("cache");

$goods_types = array(
    'goods' => lang('plugin/invite_aboc', 'aboc47'),
    'extcredits'=>lang('plugin/invite_aboc', 'aboc48'),
    'group' => lang('plugin/invite_aboc', 'aboc49'),
    'weixin' => lang('plugin/invite_aboc', 'aboc199'),
    'alipay' => lang('plugin/invite_aboc', 'aboc200'),
);

if(submitcheck('del','post')){
    if(!isset($_GET['delete']) || !is_array($_GET['delete'])){
        cpmsg_error(lang('plugin/invite_aboc', 'sc'));
    }
    $_GET['delete'] = array_map("intval",$_GET['delete']);
    DB::delete("invite_goods","goods_id IN(".join(',',$_GET['delete']).")");
    cpmsg(lang('plugin/invite_aboc', 'sccg'));
}

if($act == "") {
    include_once "admin_setting_post.inc.php";
    showformheader("plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_goods","","sform","post");
    showtableheader( );
//    print_r($invite_setting);
    ?>
    <tr><td colspan="2" class="td27" s="1"><?php echo lang('plugin/invite_aboc', 'aboc154');?></td></tr>
    <tr class="noborder" onmouseover="setfaq(this, 'faqa2f1')"><td class="vtop rowform">
            <ul onmouseover="altStyle(this);"><li class="checked"><input class="radio" type="radio" name="varsnew[exchange_people]" value="1" <?php  echo (isset($invite_setting['exchange_people'])&&$invite_setting['exchange_people'])?"checked":""  ?>>&nbsp;<?php echo lang('plugin/invite_aboc', 'aboc155');?></li><li><input class="radio" type="radio" name="varsnew[exchange_people]" <?php  echo (!isset($invite_setting['exchange_people'])||!$invite_setting['exchange_people'])?"checked":""  ?> value="0">&nbsp;<?php echo lang('plugin/invite_aboc', 'aboc156');?></li></ul></td><td class="vtop tips2" s="1"><?php echo lang('plugin/invite_aboc', 'aboc157');?></td></tr>
    <?php

    showhiddenfields(array(
        'formhash'=>FORMHASH
    ));
    showsubmit('setting',lang('plugin/invite_aboc', 'aboc75'));

    showtablefooter(); /*dism·taobao·com*/
    showformfooter();

    showformheader("plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_goods","","sform","get");
    showtableheader();
?>
    <input name="action" value="plugins" type="hidden"/>
    <input name="operation" value="config" type="hidden"/>
    <input name="do" value="<?php echo $plguinid;?>" type="hidden"/>
    <input name="identifier" value="invite_aboc" type="hidden"/>
    <input name="pmod" value="admin_goods" type="hidden"/>
    <table class="tb tb2 ">
        <tbody>
        <tr class="hover">
            <td style="width:430px;">
                <?php echo lang('plugin/invite_aboc', 'ss'); ?>
                <?php echo lang('plugin/invite_aboc', 'aboc77');?><select name="types" id="">
                    <option value="0"><?php echo lang('plugin/invite_aboc', 'aboc11');?></option>
                    <?php
                    foreach($goods_types as $k => $v){
                        $selected = $k==@$_GET['types']?' selected':'';
                        echo '<option value="'.$k.'" '.$selected.'>'.$v.'</option>';
                    }
                    ?>
                </select>
                <?php echo lang('plugin/invite_aboc', 'aboc78');?><input type="text" value="<?php echo @$_GET['keyword']; ?>" name="keyword" style="width: 80px;" class="txt">
                <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>"/>
                <input type="submit" name="do_action" value="<?php echo lang('plugin/invite_aboc', 'ss'); ?>" class="btn" />
                &nbsp;&nbsp;
                <a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=58&identifier=invite_aboc&pmod=admin_goods_add&act=add" style="font-weight: normal;float: right;"><?php echo lang('plugin/invite_aboc', 'aboc79');?></a>
            </td>
        </tr>
        </tbody>
    </table>
    <?php
    showformfooter();
$pagenum = 20;
$page = isset($_GET['page'])?intval($_GET['page']):1;
$where = " WHERE 1=1";
if(isset($_GET['types']) && $_GET['types']){
    $where .= " AND types='{$_GET['types']}'";
}
if(isset($_GET['keyword']) && $_GET['keyword']){
    $where .= " AND title like '%{$_GET['keyword']}%'";
}
$total = DB::fetch_first("select count(goods_id) as num from " . DB::table("invite_goods") . $where);
$total = isset($total['num']) ? $total['num'] : 0;
$list = DB::fetch_all("select * from " . DB::table("invite_goods") . " $where ORDER BY goods_id DESC " . DB::limit(($page - 1) * $pagenum, $pagenum));
foreach($list as $k => $v){
    $list[$k]['types'] = isset($goods_types[$v['types']])?$goods_types[$v['types']]:lang('plugin/invite_aboc', 'aboc57');
}
$pagelist = multi($total, $pagenum, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_invite",ceil($total/$pagenum), 10,true);



    showformheader("plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_goods");
    ?>
    <table class="tb tb2 ">
        <tbody>
        <tr class="header">
            <th style="width:20px;"></th>
            <th>ID</th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc58');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc59');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc80').$invite_aboc['integral_name'].lang('plugin/invite_aboc', 'aboc80_1');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc81');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc82');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc62');?></th>
        </tr>
        <?php
        foreach($list as $v) {
            ?>
            <tr class="hover" id="reply_<?php echo $v['goods_id'];?>">
                <td>
                    <input type="checkbox" value="<?php echo $v['goods_id'];?>" name="delete[]" class="checkbox">
                </td>
                <td><?php echo $v['goods_id'];?></td>
                <td><?php echo $v['types'];?></td>
                <td><?php echo $v['title'];?></td>
                <td><?php echo $v['price'];?></td>
                <td><?php echo $v['sales'];?></td>
                <td><?php echo date("Y-m-d H:i:s",$v['add_time']);?></td>
                <td>
                    <a href="<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&do=<?php echo $pluginid;?>&identifier=invite_aboc&pmod=admin_goods&act=add&goods_id=<?php echo $v['goods_id'];?>"><?php echo lang('plugin/invite_aboc', 'aboc83');?></a>
                </td>
            </tr>
        <?php
        }
        ?>
        <tr><td class="td25">&nbsp;</td><td colspan="15"><div class="fixsel">
                    <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>" />
                    <input type="submit" value="<?php echo lang('plugin/invite_aboc', 'delete'); ?>" name="del" id="submit_submit" class="btn">
                </div></td></tr>
        </tbody>
    </table>
    <?php
    showformfooter();
    ?>
    <table>
        <tbody>
        <tr>
            <td colspan="5">
                <div class="cuspages right">
                    <?php echo $pagelist; ?>
                </div>
            </td>
        </tr>
        </tbody>
    </table>
<?php
}
elseif($act == 'add'){
    $info = C::t("#invite_aboc#invite_goods")->fetch($goods_id);
    if($goods_id && !$info){
        cpmsg_error(lang('plugin/invite_aboc', 'aboc84'));
    }
    if(submitcheck('submit')){
        $f = array_map("trim", $_GET);
        if($f['title'] == ""){
            cpmsg_error(lang('plugin/invite_aboc', 'aboc85'));
        }
        if(in_array($f['types'],array('goods','extcredits'))){
            $f['number'] = intval($f['number']);
            if($f['number'] < 1){
                cpmsg_error(lang('plugin/invite_aboc', 'aboc86'));
            }
        }
        if($f['types'] == 'extcredits' && !intval($f['extcredits'])){
            cpmsg_error(lang('plugin/invite_aboc', 'aboc87'));
        }
        if($f['types'] == 'group' && !intval($f['groupid'])){
            cpmsg_error(lang('plugin/invite_aboc', 'aboc88'));
        }
        if(intval($f['stock'])<0){
            cpmsg_error(lang('plugin/invite_aboc', 'aboc89'));
        }
        if(intval($f['price'])<1){
            cpmsg_error(lang('plugin/invite_aboc', 'aboc90').$invite_aboc['integral_name'].lang('plugin/invite_aboc', 'aboc90_1'));
        }
        $result = C::t("#invite_aboc#invite_goods")->add($f,$goods_id);
        if($result){
            if($goods_id){
                cpmsg(lang('plugin/invite_aboc', 'aboc91'),"action=plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_goods",'succeed');
            } else {
                cpmsg(lang('plugin/invite_aboc', 'aboc92'),"action=plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_goods",'succeed');
            }
        } else {
            cpmsg_error(lang('plugin/invite_aboc', 'aboc93'));
        }
    }
    showformheader("plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_goods&act=add&goods_id=".$goods_id);
    if($info){
        showtableheader( lang('plugin/invite_aboc', 'aboc94') );
    } else {
        showtableheader( lang('plugin/invite_aboc', 'aboc95') );
    }
    showsetting(lang('plugin/invite_aboc', 'aboc96'),'title',$info?$info['title']:'','text','',0,lang('plugin/invite_aboc', 'aboc97'));
    $from_types = array();
    foreach($goods_types as $k =>$v){
        $from_types[] = array($k,$v);
    }
    showsetting(lang('plugin/invite_aboc', 'aboc98'),array('types',$from_types),$info?$info['types']:'goods','select','',0,'',' onchange="show_type(this.value)"');
    //group
    $rows = C::t("common_usergroup")->fetch_all_by_type(array('system','special'));
    $groupds = array(
        array(0,''),
    );
    foreach($rows as $v){
        $groupds[] = array($v['groupid'],$v['grouptitle']);
    }
    showsetting(lang('plugin/invite_aboc', 'aboc49'),array('groupid',$groupds),$info?$info['attr']:'0','select','',0,'',' class="groupid"');
    showsetting(lang('plugin/invite_aboc', 'aboc151'),'day',$info?$info['day']:1,'number','',0,lang('plugin/invite_aboc', 'aboc152'), 'data-type="day"');
    //ext
    $extcredits = array(
        array(0,''),
    );
    foreach($_G['setting']['extcredits'] as $k=> $v){
        $extcredits[] = array($k,$v['title']);
    }
    showsetting(lang('plugin/invite_aboc', 'aboc99'),array('extcredits',$extcredits),$info?$info['attr']:'','select','',0,'',' class="extcredits"');
    showsetting(lang('plugin/invite_aboc', 'aboc100'),'number',$info?$info['number']:1,'number','',0,lang('plugin/invite_aboc', 'aboc101'), ' data-type="xnumber"');
    showsetting(lang('plugin/invite_aboc', 'aboc80').$invite_setting['integral_name'],'price',$info?$info['price']:1,'number');
    showsetting(lang('plugin/invite_aboc', 'aboc102'),'stock',$info?$info['stock']:999,'number');
    showsetting(lang('plugin/invite_aboc', 'aboc103'),'description',$info?$info['description']:'','textarea');
    showhiddenfields(array(
        'formhash'=>FORMHASH
    ));
    showsubmit('submit',lang('plugin/invite_aboc', 'aboc75'));

    showtablefooter(); /*dism·taobao·com*/

}
?>
<script src="source/plugin/invite_aboc/template/jquery-1.7.2.min.js" /></script>
<script>
var ajQ = jQuery.noConflict(true);
ajQ(function(){
    show_type('<?php echo $info?$info['types']:'goods'; ?>');
})
function show_type(n){
    var gp = ajQ(".groupid").closest('tr');
    var gp_day = ajQ("input[data-type=day]").closest('tr');
    var ep = ajQ(".extcredits").closest('tr');
    var np = ajQ("input[data-type=xnumber]").closest('tr');
    if(n=='goods' || n == 'alipay' || n == 'weixin'){
        ajQ(gp).hide();
        ajQ(gp).prev().hide();
        ajQ(gp_day).hide();
        ajQ(gp_day).prev().hide();
        ajQ(ep).hide();
        ajQ(ep).prev().hide();
        ajQ(np).show();
        ajQ(np).prev().show();
    }
    else if(n == 'group'){
        ajQ(gp).show();
        ajQ(gp).prev().show();
        ajQ(gp_day).show();
        ajQ(gp_day).prev().show();
        ajQ(ep).hide();
        ajQ(ep).prev().hide();
        ajQ(np).hide();
        ajQ(np).prev().hide();
    }
    else if(n == 'extcredits'){
        ajQ(ep).show();
        ajQ(ep).prev().show();
        ajQ(gp).hide();
        ajQ(gp).prev().hide();
        ajQ(gp_day).hide();
        ajQ(gp_day).prev().hide();
        ajQ(np).show();
        ajQ(np).prev().show();
    }
}
</script>