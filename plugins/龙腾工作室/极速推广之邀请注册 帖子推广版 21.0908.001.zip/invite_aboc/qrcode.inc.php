<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


$text = isset($_GET['text']) ? trim($_GET['text']) : 'Discuz!';

include_once dirname(__FILE__)."/qrcode.class.php";

echo QRcode::png($text, false, "L", 4, 2);