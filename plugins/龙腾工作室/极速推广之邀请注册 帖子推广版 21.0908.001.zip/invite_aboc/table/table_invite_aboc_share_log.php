<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
/**
 * table_invite_goods.php
 * Ӧ�ø���֧�֣�https://dism.taobao.com
* ���²����http://t.cn/Aiux1Jx1
 * Date: 14-9-2
 * Time: ����6:54
 */

class table_invite_aboc_share_log extends discuz_table {

    public $set = array();

    function __construct() {
        $this->_table = 'invite_aboc_share_log';
        $this->_pk    = 'log_id';
        parent::__construct(); /*dism �� taobao �� com*/
        global $_G;
        $this->set = $_G['cache']['plugin']['invite_aboc'];
    }



    function integral($tid,$fromuid){
    	global $_G;
    	if($fromuid == $_G['uid']){
    		return;
	    }
	    $ip = $_G['clientip'];
    	if(true) { //�����в��ж�
		    if ( DB::fetch_first( "SELECT log_id FROM %t WHERE tid=%d AND fromuid=%d AND ((uid>0 and uid=%d) OR ip=%s)", array(
			    $this->_table,
			    $tid,
			    $fromuid,
			    $_G['uid'],
			    $ip
		    ) ) ) {
			    return;
		    }
	    }
	    if(DB::insert("invite_aboc_share_log",array(
	    	"tid" => $tid,
		    "fromuid"=>$fromuid,
		    "uid" => $_G['uid'],
		    "ip" => $ip,
		    "dateline" => $_G['timestamp'],
	    ))){
			$share_thread = intval($this->set['share_thread']);
		    $share_thread_first = intval($this->set['share_thread_first']);
			$share_thread_digest = intval($this->set['share_thread_digest']);
			$share_thread_digest_day = intval($this->set['share_thread_digest_day']);
			$share_thread_highlight = intval($this->set['share_thread_highlight']);
			$share_thread_highlight_day = intval($this->set['share_thread_highlight_day']);
			$thread = C::t("forum_thread")->fetch($tid);
			if(!$thread){
				return true;
			}
			if($share_thread > 0){
				C::t("#invite_aboc#invite_aboc_log")->dodo($fromuid,$share_thread,lang('plugin/invite_aboc', 'share__1'));
				if($fromuid != $_G['uid']) {
					 sendpm( $fromuid, lang( 'plugin/invite_aboc', 'integral_message' ), lang( 'plugin/invite_aboc', 'share__1' ), 1, 0, 0 ) ;
				}
			}
			if($share_thread_first > 0){
				C::t("#invite_aboc#invite_aboc_log")->dodo($thread['authorid'],$share_thread_first,lang('plugin/invite_aboc', 'share__2'));
				if($fromuid != $thread['authorid']) {
					sendpm( $thread['authorid'], lang( 'plugin/invite_aboc', 'integral_message' ), lang( 'plugin/invite_aboc', 'share__2' ), 1, 0, 0 ) ;
				}
			}
		    require_once libfile('function/post');
		    require_once libfile('function/misc');
			$share_num = DB::fetch_first("SELECT COUNT(log_id) AS num FROM %t WHERE tid=%d",array($this->_table,$tid) );
		    $share_num = $share_num['num'];
		    $this->set['share_thread_digest_type'] = intval($this->set['share_thread_digest_type']);
//		    echo 2;
//		    var_dump($share_thread_digest > 0 , $share_thread_digest <= $share_num  ,$this->set['share_thread_digest_type'] > $thread['digest'],$this->set['share_thread_digest_type']);
//		    echo "+".intval($this->set["share_thread_digest_day"])."day";exit;
		    //����
			if($share_thread_digest > 0 && $share_thread_digest <= $share_num  && $this->set['share_thread_digest_type'] > $thread['digest'] ){
//				echo 1;
					C::t('forum_thread')->update($tid, array('digest' => intval($this->set['share_thread_digest_type']), 'moderated' => 1), true);
					$extsql = array();
					if ($this->set['share_thread_digest_type'] > 0 && $thread['digest'] == 0) {
						$extsql = array('digestposts' => 1);
					}
					updatecreditbyaction('digest', $thread['authorid'], $extsql, '', $this->set['share_thread_digest_type'] - $thread['digest']);
				$operation = 'digest';
					$expiration   = checkexpiration_invite( dgmdate(strtotime("+".$share_thread_digest_day."day",$_G['timestamp']),"Y-m-d H:i:s"), $operation );
					$digestlevel  = $this->set['share_thread_digest_type'];
					$moderatetids = array( $tid );
					$modaction    = $digestlevel ? ( $expiration ? 'EDI' : 'DIG' ) : 'UDG';
					updatemodlog( $moderatetids, $modaction, $expiration ,0,"system");

//				print_r($moderatetids);exit;
				C::t('forum_threadmod')->update_by_tid_action($moderatetids, array('DIG', 'UDI', 'EDI', 'UED'), array('status' =>0));
//				modlog($thread, $modaction);

				$modactioncode = lang('forum/modaction');
				$modtype = $modaction;
				$modaction = $modactioncode[$modaction];
//				sendreasonpm($thread, 'reason_moderate', array('tid' => $thread['tid'], 'subject' => $thread['subject'], 'modaction' => $modaction, 'reason' => "", 'from_id' => 0, 'from_idtype' => 'moderate_'.$modtype), 'post');
			}
			//�Ӵ�
			if($share_thread_highlight >0 && $share_thread_highlight <= $share_num){
				$highlight_style = mt_rand(0,7);
				$highlight_color = mt_rand(0,8);
				$highlight_bgcolor = '';
				$expiration = checkexpiration_invite(dgmdate(strtotime("+".$share_thread_highlight_day."day",$_G['timestamp']),"Y-m-d H:i:s"), $operation);
				$stylebin = '';
				for($i = 1; $i <= 3; $i++) {
					$stylebin .= empty($highlight_style[$i]) ? '0' : '1';
				}

				$highlight_style = bindec($stylebin);
				$bgcolor = dhtmlspecialchars(preg_replace("/[^\[A-Za-z0-9#]/", '', $highlight_bgcolor));
				$tidsarr = array($tid);
				C::t('forum_thread')->update($tidsarr, array('highlight'=>$highlight_style.$highlight_color, 'moderated'=>1, 'bgcolor' => $bgcolor), true);
				C::t('forum_forumrecommend')->update($tidsarr, array('highlight' => $highlight_style.$highlight_color));
				C::t('forum_threadhidelog')->delete_by_tid($tidsarr);

				$modaction = ($highlight_style + $highlight_color) ? ($expiration ? 'EHL' : 'HLT') : 'UHL';
				$expiration = $modaction == 'UHL' ? 0 : $expiration;


				C::t('common_member_secwhite')->add($thread['authorid']);

				C::t('forum_threadmod')->update_by_tid_action($tidsarr, array('HLT', 'UHL', 'EHL', 'UEH'), array('status' => 0));

			}

    		return true;
	    } else {
	    	return false;
	    }
    }


} 