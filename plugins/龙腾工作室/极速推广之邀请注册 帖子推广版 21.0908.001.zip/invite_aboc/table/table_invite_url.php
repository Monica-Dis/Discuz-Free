<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
/**
 * table_invite_goods.php
 * 应用更新支持：https://dism.taobao.com
* 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-2
 * Time: 下午6:54
 */

class table_invite_url extends discuz_table {

    public $set = array();

    private $api_url = array(
        1 => "http://mrw.so/api.php",
        2 => "https://api.xiaomark.com/v1/link/create",
    );

    function __construct() {
        $this->_table = 'invite_url';
        $this->_pk    = 'mobile';
        parent::__construct(); /*dism · taobao · com*/
        global $_G;
        $this->set = $_G['cache']['plugin']['invite_aboc'];
        $this->set['use_short_url'] = intval($this->set['use_short_url']);
    }



    function url($source_url,$create = false){




        $row = DB::fetch_first("SELECT * FROM %t WHERE source_url=%s LIMIT 1", array(
            $this->_table , $source_url
        ) );

        if ($row) {
            return $row['url'];
        }
        if(!$create) {
            return $source_url;
        }

        //create

        return $this->api_url($source_url);

    }


    private function api_url($url){
        global $_G;
        if(!$this->set['use_short_url']){
            return $url;
        }
        if($this->set['short_url_key'] ==""){
            return $url;
        }
        if(!$_G['uid']){
            return $url;
        }


        if(!isset($this->api_url[$this->set['use_short_url']])){
            return $url;
        }

        $api_url = $this->api_url[$this->set['use_short_url']];

        try {
            if ( $this->set['use_short_url'] == 1) {
                $data = array(
                    'url'  => $url,
                    'format' => 'json',
                    'callback' => '',
                    'key'  => $this->set['short_url_key'],
                    'expireDate' => '',
                );

                $result = file_get_contents($api_url . '?' . http_build_query($data));

                $result = json_decode($result, true);

                if ($result["err"] != "") {
                    return $url;
                }
                $result_url = $result['url'];
            }
            else if ( $this->set['use_short_url'] == 2) {
                $data = array (
                    'apikey' => $this->set['short_url_key'],
                    'domain' => '',
                    'origin_url' => $url,
                    'report' => true,
                    'webhook' => true,
                    'webhook_scene' => 'aboc',
                );
                $data_string = json_encode($data);

                $ch = curl_init($api_url);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch, CURLOPT_POSTFIELDS,$data_string);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/json',
                        'Content-Length: ' . strlen($data_string))
                );

                $result = curl_exec($ch);
//                print_r($result);exit;
                $result = json_decode($result, true);

                if($result['code'] != 0) {
                    return $url;
                }
                $result_url = $result['data']['link']['url'];

            }
            else{
                return $url;
            }


            DB::insert($this->_table, array(
                "url" => $result_url,
                "source_url" => $url,
                "uid"  => $_G['uid'],
                "add_time"  => time()
            ));
            return $result_url;
        }catch (Exception $exception){
            return $url;
        }
    }






} 