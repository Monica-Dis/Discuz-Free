<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
/**
 * table_invite_goods.php
 * Ӧ�ø���֧�֣�https://dism.taobao.com
* ���²����http://t.cn/Aiux1Jx1
 * Date: 14-9-2
 * Time: ����6:54
 */

class table_invite_aboc_log extends discuz_table {

    public $set = array();

    function __construct() {
        $this->_table = 'invite_aboc_log';
        $this->_pk    = 'log_id';
        parent::__construct(); /*dism �� taobao �� com*/
        global $_G;
        $this->set = $_G['cache']['plugin']['invite_aboc'];
    }



    function dodo($uid,$number,$memo){
    	global $_G;
    	if(DB::insert("invite_aboc_log",array(
    		"uid"  => $uid,
		    "number" => $number,
		    "memo"  => $memo,
		    "dateline" => $_G['timestamp']
	    ))){
    		if($number > 0){
    			//DB::update("common_member",array("invite_num"=>$userinfo['invite_num'] + $number),"uid='{$userinfo['uid']}'")
			    DB::query("UPDATE ".DB::table("common_member")." SET invite_num=invite_num+{$number} WHERE uid='$uid'");


		    }

		    return true;
	    } else {
    		return false;
	    }
    }



} 