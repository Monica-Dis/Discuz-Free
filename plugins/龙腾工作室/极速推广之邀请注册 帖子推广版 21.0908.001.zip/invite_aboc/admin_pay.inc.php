<?php
/**
 * admin_invite.inc.php
 * 应用更新支持：https://dism.taobao.com
* 最新插件：http://t.cn/Aiux1Jx1
 * Date: 14-9-3
 * Time: 下午11:13
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once "invite.fun.php";
showtableheader();
?>
    <table class="tb tb2 ">
        <tbody>
        <tr class="hover">
            <td style="width:430px;">
                <a href="<?php echo ADMINSCRIPT.'?'.$_SERVER['QUERY_STRING'];?>&excel=1"><?php echo lang('plugin/invite_aboc', 'aboc14');?></a>
            </td>
        </tr>
        </tbody>
    </table>
<?php
$pagenum = isset($_GET['excel'])?5000000:20;
$page = isset($_GET['page'])?intval($_GET['page']):1;
$where = " WHERE l.operation='TRC' AND f.title='FROM'";

$total = DB::fetch_first("select count(f.logid) as num from " . DB::table("common_credit_log_field") ." f LEFT JOIN ".DB::table("common_credit_log")." l ON l.logid=f.logid ". $where);
$total = isset($total['num']) ? $total['num'] : 0;
$list = DB::fetch_all("select *  from " . DB::table("common_credit_log_field") ." f LEFT JOIN ".DB::table("common_credit_log")." l ON l.logid=f.logid " .$where."  ORDER BY f.logid DESC  ". DB::limit(($page - 1) * $pagenum, $pagenum));
foreach($list as $k => $v){
    $list[$k]['types'] = isset($goods_types[$v['types']])?$goods_types[$v['types']]:lang('plugin/invite_aboc', 'aboc57');
}
$uids = array();
foreach($list as $k => $v){
    $list[$k]['text'] = @unserialize($v['text']);
    $uids[$v['uid']] = $v['uid'];
    $uids[$list[$k]['text']['uid']] = $list[$k]['text']['uid'];
}
$users = get_users($uids);
$pagelist = multi($total, $pagenum, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=invite_aboc&pmod=admin_share",ceil($total/$pagenum), 10,true);//



if(isset($_GET['excel'])) {
    ob_end_clean();
    ob_start();
    header( "Content-type:application/vnd.ms-excel" );
    header( "Content-Disposition:attachment;filename=list-" . date( "Y-m-d" ) . ".xls" );
    ?>
    <table class="tb tb2 ">
        <tbody>
        <tr class="header">
            <th>ID</th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc158');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc159').$invite_aboc['integral_name'];?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc160');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc161');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc162');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc163');?></th>
        </tr>
        <?php
        foreach($list as $v) {
            ?>
            <tr class="hover" id="reply_<?php echo $v['logid'];?>">
                <td><?php echo $v['logid'];?></td>
                <td><?php echo isset($users[$v['uid']])?$users[$v['uid']]['username']:'';?></td>
                <td><?php echo $v['extcredits'.$_G['setting']['creditstrans']];?></td>
                <td><?php echo isset($users[$v['text']['uid']])?$users[$v['text']['uid']]['username']:'';?></td>
                <td><?php echo $v['text']['amount'];?></td>
                <td><?php echo date("Y-m-d H:i:s",$v['text']['paytime']);?></td>
                <td><?php echo isset($v['text']['level'])?$v['text']['level']:"&nbsp;";?></td>
            </tr>
            <?php
        }
        ?>
        <tr><td class="td25">&nbsp;</td><td colspan="15"><div class="fixsel">
                    <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>" />
                </div></td></tr>
        </tbody>
    </table>
<?php
    exit;
}

?>
    <table class="tb tb2 ">
        <tbody>
        <tr class="header">
            <th>ID</th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc158');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc159');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc160');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc161');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc162');?></th>
            <th><?php echo lang('plugin/invite_aboc', 'aboc163');?></th>
        </tr>
        <?php
        foreach($list as $v) {
            ?>
            <tr class="hover" id="reply_<?php echo $v['logid'];?>">
                <td><?php echo $v['logid'];?></td>
                <td><?php echo isset($users[$v['uid']])?$users[$v['uid']]['username']:'';?></td>
                <td><?php echo $v['extcredits'.$_G['setting']['creditstrans']];?></td>
                <td><?php echo isset($users[$v['text']['uid']])?$users[$v['text']['uid']]['username']:'';?></td>
                <td><?php echo $v['text']['amount'];?></td>
                <td><?php echo date("Y-m-d H:i:s",$v['text']['paytime']);?></td>
                <td><?php echo isset($v['text']['level'])?$v['text']['level']:"&nbsp;";?></td>
            </tr>
            <?php
        }
        ?>
        <tr><td class="td25">&nbsp;</td><td colspan="15"><div class="fixsel">
                    <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>" />
                </div></td></tr>
        </tbody>
    </table>
    <table>
        <tbody>
        <tr>
            <td colspan="5">
                <div class="cuspages right">
                    <?php echo $pagelist; ?>
                </div>
            </td>
        </tr>
        </tbody>
    </table>