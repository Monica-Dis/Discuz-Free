<?php
/**
 * invite.inc.php
 * Ӧ�ø���֧�֣�https://dism.taobao.com
* ���²����http://t.cn/Aiux1Jx1
 * Date: 14-9-1
 * Time: ����11:00
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$invite_aboc = $_G['cache']['plugin']['invite_aboc'];
$invite_aboc['ban_group_id'] = @unserialize($invite_aboc['ban_group_id']);

$do = isset($_GET['do']) ? trim($_GET['do']) :'';

if($do == "") {
	header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
	header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
	header('Pragma: no-cache');
    $goods_list = C::t("#invite_aboc#invite_goods")->get_goods_list();
//    $can_invite = C::t("#invite_aboc#invite_aboc")->get_fromuid_num($_G['uid']);
    $can_invite =  $_G['member']['invite_num'] -$_G['member']['invite_change'];
    echo '<?xml version="1.0" encoding="gbk"?>
<root><![CDATA[';
    include template( "invite_aboc:doexchange" );
    echo ']]></root>';
    exit;
} else if($do == 'change') {
    if(submitcheck('change',1)){
        $goods_id = isset($_GET['goods_id'])?intval($_GET['goods_id']):0;
        if(!$goods_id){
            echo '-1|'.lang('plugin/invite_aboc', 'aboc104');exit;
        }
        echo C::t("#invite_aboc#invite_exchange_log")->exchange( $goods_id, $_G, $invite_aboc);exit;

    }
}