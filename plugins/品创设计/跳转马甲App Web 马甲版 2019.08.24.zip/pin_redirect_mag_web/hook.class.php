<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/


if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class plugin_pin_redirect_mag_web
{

}


// +----------------------------------------------------------------------
// | �ֻ�����
// +----------------------------------------------------------------------
class mobileplugin_pin_redirect_mag_web extends plugin_pin_redirect_mag_web
{
    public function global_footer_mobile()
    {
        global $_G;
        $pluginCache = $_G['cache']['plugin']['pin_redirect_mag_web'];

        if (isset($pluginCache['isOpen'])
            && $pluginCache['isOpen']
            && isset($pluginCache['isJumpAppWebRoot'])
            && $pluginCache['isJumpAppWebRoot']) {

            $thread = $_G['thread'];
            $tid = $thread['tid'];
            $baseUrl = trim($pluginCache['jumpBaseUrl']);//��ת��BaseUrl

            if (isset($tid) && !empty($tid)) {
                return;
            }

            $appUrl = '/mag/wap/v1/wap/waphome';
            $jumpUrl = $baseUrl . $appUrl;
            header('Location:' . $jumpUrl);
        }

        return;
    }
}


class mobileplugin_pin_redirect_mag_web_forum extends mobileplugin_pin_redirect_mag_web
{

    //top  ������ app webҳ��
    function viewthread_top_mobile()
    {
        global $_G;
        $pluginCache = $_G['cache']['plugin']['pin_redirect_mag_web'];

        if (isset($pluginCache['isOpen']) && $pluginCache['isOpen']) {

            $thread = $_G['thread'];
            $tid = $thread['tid'];
            $baseUrl = trim($pluginCache['jumpBaseUrl']);//��ת��BaseUrl
            $appThemeColor = trim($pluginCache['appThemeColor']);//����App������ɫ bba883

            if (isset($tid) && !empty($tid)) {
                $appUrl = '/mag/circle/v1/forum/threadWapPage?tid=' . $tid . '&themecolor=' . $appThemeColor;
                $jumpUrl = $baseUrl . $appUrl;
                header('Location:' . $jumpUrl);
            }
        }

        return;
    }

}



