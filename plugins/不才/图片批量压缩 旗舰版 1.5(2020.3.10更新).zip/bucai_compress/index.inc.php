<?php
/**
 * H5ͼƬѹ�����ϴ��ֻ���
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$ac = $_GET['ac'];
$page = $_GET['page'];
loadcache('plugin');
$bucai=$_G['cache']['plugin']['bucai_compress'];
include_once "./source/plugin/bucai_compress/bucai_compress.php";
$compress = new compress();	
if($ac == 'bucai_compress'){
	if($_POST['formhash'] != FORMHASH){
		echo 'Access Denied.<br><a href="javascript:history.go(-1)">'.lang('plugin/bucai_compress','goback').'</script>';
		exit();
	}
	$width = $bucai['width']	;
	$height = $bucai['height'];
	$quality = $bucai['quality'];
	$img_file = $_POST['img_url'];
	$ispng = $bucai['ispng'];
	if(count($img_file) < 1){
		echo lang('plugin/bucai_compress','bucai_noselect').'<br><a href="javascript:history.go(-1)">'.lang('plugin/bucai_compress','goback').'</script>';
	}else{
		foreach($img_file as $img_url) { 
			if(!$compress->bucai_gif($img_url)){
				$compress->createThumbImage($img_url, $width, $height, $img_url,250,250,$quality,$ispng);
			}
		}	
		echo lang('plugin/bucai_compress','compress_succees').'<br><a href="javascript:history.go(-1)">'.lang('plugin/bucai_compress','goback').'</script>';
	}
}else if($ac == 'bucai_post'){
	$path_type = $_POST['type'];
	$path_date = $_POST['bucai_date'];
	if(!$path_type){
		$path_type = $_GET['path'];
		$path_date = $_GET['bucai_date'];
	}else{
		if($_POST['formhash'] != FORMHASH){
			echo 'Access Denied.<br><a href="javascript:history.go(-1)">'.lang('plugin/bucai_compress','goback').'</script>';
			exit();
		}	
	}
	if(!$page || $page < 1){
		$page = 1;
	}
	$count = 0;
	$attdir = $_G['setting']['attachdir'];
	$pos = strrpos($attdir,".");
	$pre_dir = substr($attdir,$pos);
	$files = $compress->bucai_dir($pre_dir.$path_type,$path_date);
	if(!empty($path_date)){
		$files_date[$path_date] = $files;
		$files = array();
		$files = $files_date;
	}
	$img_lists = $compress->bucai_path($pre_dir,$path_type,$files);
	$img_list = $img_lists['file'];
	$count = $img_lists['num'];
	$perpage = $bucai['perpage'];
	$start = ($page-1)*$perpage;
	$mpurl .= '&perpage='.$perpage;
	$perpages = array($perpage => ' selected');
	$mpurl =ADMINSCRIPT.'?action=plugins&operation=config&identifier=bucai_compress&pmod=index&ac=bucai_post&path='.$path_type.'&bucai_date='.$path_date.$mpurl;
	showformheader('plugins&operation=config&identifier=bucai_compress&pmod=index&ac=bucai_compress');
	showtableheader('');
	showsubtitle(array('select', lang('plugin/bucai_compress','bucai_file'), lang('plugin/bucai_compress','bucai_image')));
	if($count) {
		for ( $i=0 ; $i < $perpage ; $i++ ){
			$start ++;
			if($start < $count){
				echo "<tr><td><input type=\"checkbox\" class=\"checkbox\" name=\"img_url[]\" value=\"{$img_list[$start]}\"></td><td>{$img_list[$start]}</td><td><img src='{$img_list[$start]}' width=28 height=28 align=right/></td></tr>";		
			}	
		}
		$multipage = multi($count, $perpage, $page, $mpurl);
	}
	echo "<tr><td><input type=\"checkbox\" name=\"chkall\" id=\"chkall\" class=\"checkbox\" onclick=\"checkAll('prefix', this.form, 'img_url')\" ><label for=\"chkall\">".cplang('select_all')."</label></td><td></td><td>$multipage</td></tr>";
	showsubmit('menusubmit', 'submit');
	showtablefooter();/*dis'.'m.tao'.'bao.com*/
	showformfooter();
}else if($ac == '' || $ac == 'bucai_get'){
	showformheader('plugins&operation=config&identifier=bucai_compress&pmod=index&ac=bucai_post');
	echo '<table width="450px;">
		<tr height="50px;">
			<td>'.lang('plugin/bucai_compress','bucai_select_path').'</td>
			<td><lable for="forum"><input type="radio" name="type" id="forum" checked="checked" value="forum" >'.lang('plugin/bucai_compress','bucai_forum').'</lable><lable for="portal"><input type="radio" name="type" id="portal" value="portal" >'.lang('plugin/bucai_compress','bucai_portal').'</lable><lable for="album"><input type="radio" name="type" id="album" value="album" >'.lang('plugin/bucai_compress','bucai_album').'</lable></td>
			<td></td>
		</tr>
		<tr height="50px;">
			<td>'.lang('plugin/bucai_compress','bucai_date').'</td>
			<td><input type="text" name="bucai_date" value="" placeholder="202002" >
			<td>202002</td>
		</tr>';
	showsubmit('menusubmit', 'submit');
	showformfooter();	
}
//From: Dism��taobao��com
?>