<?php
/**
 * ͼƬѹ�����ϴ��ֻ���
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
class compress {

	function createThumbImage($name, $width, $height, $tmp_name,$minwidth,$minheight,$quality=100,$ispng){
		$imgInfo=$this->getImageInfo($tmp_name); 
		if($imgInfo['width'] > $minwidth  || $imgInfo['height'] > $minheight){
			$srcImg=$this->getImageType($tmp_name, $imgInfo);
			$size=$this->setNewSize($tmp_name, $width, $height, $imgInfo);
			$newImg=$this->bucaiPaintImage($srcImg, $size, $imgInfo);
			return $this->createNewImage($newImg, $name, $imgInfo,$quality,$ispng);			
		}
	}

	private function createNewImage($newImg, $Name, $imgInfo,$quality,$ispng){
		if($imgInfo['type'] == '3' and $ispng > 0){
			imagepng($newImg, $Name);
		}else{
			imagejpeg($newImg, $Name,$quality);
		}		
		imagedestroy($newImg);
	}

	private function bucaiPaintImage($srcImg, $size, $imgInfo){
		$newImg=imagecreatetruecolor($size["width"], $size["height"]);
		if($imgInfo['type'] == 3){
			$alpha = imagecolorallocatealpha($newImg,0,0,0,127);
			imagefill($newImg,0,0,$alpha);	
		}
		imagecopyresized($newImg, $srcImg,0,0,0,0,$size["width"],$size["height"],$imgInfo["width"],$imgInfo["height"]);	
		imagesavealpha($newImg, true);			
		imagedestroy($srcImg);
		return $newImg;
	}

	private function setNewSize($tmp_name, $width, $height, $imgInfo){
		$size["width"]=$imgInfo["width"];
		$size["height"]=$imgInfo["height"];

		if($width < $imgInfo["width"] and $width > 1){
			$size["width"]=$width;
		}
		if($height < $imgInfo["height"] and $height > 1){
			$size["height"]=$height;
		}

		if($imgInfo["width"]*$size["width"] > $imgInfo["height"] * $size["height"]){
			$size["height"]=round($imgInfo["height"]*$size["width"]/$imgInfo["width"]);
		}else{
			$size["width"]=round($imgInfo["width"]*$size["height"]/$imgInfo["height"]);
		}
		return $size;
	}

	private function getImageInfo($tmp_name){
		$data=getimagesize($tmp_name);
		$imageInfo["width"]=$data[0];
		$imageInfo["height"]=$data[1];
		$imageInfo["type"]=$data[2];
		return $imageInfo;
	}
	function bucai_gif($filename) {
		$fp = fopen($filename,'rb');
		$filecontent = fread($fp,filesize($filename));
		fclose($fp);
		$strpos = strpos($filecontent,chr(0x21).chr(0xff).chr(0x0b).'NETSCAPE2.0');
		return ($strpos === false) ? 0 : 1;
	}
	private function getImageType($tmp_name, $imgInfo){
		switch($imgInfo["type"]){
			case 1: 
				$img=imagecreatefromgif($tmp_name);
				break;
			case 2: 
				$img=imageCreatefromjpeg($tmp_name);
				break;
			case 3: 
				$img=imageCreatefrompng($tmp_name);
				break;
			default:
				return false;
		}
		return $img;
	}
	function bucai_dir($dir,$path_date) {
		if(!empty($path_date )){
			$dir = $dir."/".$path_date;
		}
		if(@$handle = opendir($dir)) {
			while(($file = readdir($handle)) !== false) {
				if($file != ".." && $file != ".") {
					if(is_dir($dir."/".$file)) { 
						$files[$file] = $this->bucai_dir($dir."/".$file);
					} else { 
						$files[] = $file;
					}
				}
			}
			closedir($handle);
			return $files;
		}
	}
	function bucai_path($pre_dir,$path_type,$path){
		foreach($path as $path_y_k=>$path_y_v){
			if(is_array($path_y_v)){
				foreach($path_y_v as $path_d_k=>$path_d_v){
					if(is_array($path_d_v)){
						foreach($path_d_v as $filename){
							$path_file = $pre_dir.$path_type."/".$path_y_k."/".$path_d_k."/".$filename;
							$file_pos = strrpos($path_file,".");
							$file_ext = strtolower(substr($path_file,$file_pos+1));
							if(in_array($file_ext,array('jpg','jpeg','png','gif'))){
								$img_list['file'][] = $path_file;
								$count++;					
							}
						}		
					}
				}
			}
		}
		$img_list['num'] = $count;
		return $img_list;
	}
}
