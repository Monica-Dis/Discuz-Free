<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_autocomment {
	function global_footer(){
		global $_G;
		loadcache('plugin');
		$vars = $_G['cache']['plugin']['autocomment'];
		$maxtime=intval($vars['maxtime']);
		$last=0;
		$cidlist=array();
		if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_autocomment_last.php')){
			@require_once DISCUZ_ROOT.'./data/sysdata/cache_autocomment_last.php';
		}
		if($_G['timestamp']-$last>$maxtime){
			$cats='';
			if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_autocomment_cats.php')){
				@require_once DISCUZ_ROOT.'./data/sysdata/cache_autocomment_cats.php';
			}
			if($cats) $catlist=explode(',',$cats);
			else return '<!--autocomment No any cat open-->';//未开启任何栏目的自动回复
			$maxnum=intval($vars['maxnum']);
			$count=DB::result_first("select count(*) from ".DB::table('portal_article_count')." where catid in($cats) and commentnum<'$maxnum'");
			if($count<=0) return '<!--autocomment count=0 by maxnum<'.$maxnum.'-->';
			$limit=rand(0,$count-1);
			$item=DB::fetch_first("select aid,catid from ".DB::table('portal_article_count')." where catid in($cats) and commentnum<'$maxnum' order by aid desc limit $limit,1");
			//$item=DB::fetch_first("select aid,catid from ".DB::table('portal_article_count')." where catid in($cats) and commentnum<'$maxnum' order by rand()");
			$aid=$item['aid'];
			$catid=$item['catid'];
			if(!$aid) return '<!--autocomment filter by maxnum-->';
			/** contents cache **/
			$data=array();
			if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_autocomment_'.$catid.'.php')){
				@require_once DISCUZ_ROOT.'./data/sysdata/cache_autocomment_'.$catid.'.php';
			}
			$r=count($data);
			if($r) $content=$data[rand(0,$r)];
			if(!$content){
				/** free contents **/
				$data=array();
				$content= explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$vars['contents']));
				foreach($content as $k=>$v){
					$v=trim($v);
					if($v) $data[]=$v;
				}
				$r=count($data);
				if($r) $content=$data[rand(0,$r)];
			}
			if(!$content){
				return '<!--autocomment contents is empty -->';
			}	
			/* Get user */
			$ruids=explode(",",trim($vars['ruids']));
			$majia_id=$ruids[rand(0,count($ruids))];
			$user=C::t('common_member')->fetch_all_username_by_uid(array($majia_id));
			$majia_name=$user[$majia_id];
			if(!$majia_id||!$majia_name){//重复拿一次
				$majia_id=$ruids[rand(0,count($ruids))];
				$user=C::t('common_member')->fetch_all_username_by_uid(array($majia_id));
				$majia_name=$user[$majia_id];
			}
			if(!$majia_id||!$majia_name) return '<!--autocomment Can\'t get majia-->';
			$comment=array(
				'uid'=>$majia_id,
				'username'=>$majia_name,
				'id'=>$aid,
				'idtype'=>'aid',
				'postip'=>$_G['clientip'],
				'dateline'=>$_G['timestamp'],
				'status'=>'0',
				'message'=>addslashes($content),
			);
			$cid=DB::insert('portal_comment',$comment,true);
			if($cid){
				$len=array_push($cidlist,array('aid'=>$aid,'cid'=>$cid,'dateline'=>TIMESTAMP));
				if($len>20){//数组中只保存最近20条
					array_shift($cidlist);
				}				
				DB::query("update ".DB::table('portal_article_count')." set commentnum=commentnum+1 where aid='$aid'");
				@require_once libfile('function/cache');
				$cacheArray = "\$last=".$_G['timestamp'].";\n";
				$cacheArray .= "\$cidlist=".arrayeval($cidlist).";\n";
				writetocache('autocomment_last',$cacheArray);
				return '<!--autocomment reply ok aid='.$aid.' cid='.$cid.'-->';
			}else{
				return '<!--autocomment Insert error-->';
			}
		}else{
			return '<!--autocomment last='.date('Y-m-d H:i:s',$last).'-->';
		}
	}
}

class plugin_autocomment_portal extends plugin_autocomment{
}
//From: Dism·taobao·com
?>