<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
require_once libfile('function/portalcp');
loadcache('portalcategory');
$portalcategory = $_G['cache']['portalcategory'];
if(empty($portalcategory) && C::t('portal_category')->count()) {
	updatecache('portalcategory');
	loadcache('portalcategory', true);
	$portalcategory = $_G['cache']['portalcategory'];
}
if($_GET['op']=='edit'){
	$catid=intval($_GET['catid']);
	if(submitcheck('editsubmit')){
		$data=array();
		$content= explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$_POST['content']));
		foreach($content as $k=>$v){
			$v=trim($v);
			if($v) $data[]=$v;
		}
		@require_once libfile('function/cache');
		$cacheArray = "\$data=".arrayeval($data).";\n";
		writetocache('autocomment_'.$catid,$cacheArray);	
		cpmsg(lang('plugin/autocomment','edit_ok'),'action=plugins&operation=config&identifier=autocomment&pmod=item', 'succeed');
	}else{
		$content='';
		if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_autocomment_'.$catid.'.php')){
			@require_once DISCUZ_ROOT.'./data/sysdata/cache_autocomment_'.$catid.'.php';
			$content=trim(implode("\r\n",$data));
		}
		showformheader("plugins&operation=config&identifier=autocomment&pmod=item&op=edit&catid=$catid");
		showtableheader(lang('plugin/autocomment','edit_title',array('catname'=>$portalcategory[$catid]['catname'])),'nobottom');	
		showsetting(lang('plugin/autocomment','edit_content'),'content',$content,'textarea','', 0,lang('plugin/autocomment','edit_content_tip'));	
		showsubmit('editsubmit');
		showtablefooter();
		showformfooter();/*Dism_taobao-com*/
	}
	
}elseif(!submitcheck('editsubmit')){
	showtableheader(lang('plugin/autocomment','tips'));
	showtablerow('',array('colspan="9" class="tipsblock"'), array(lang('plugin/autocomment','info')));
	$cats='';
	if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_autocomment_cats.php')){
		@require_once DISCUZ_ROOT.'./data/sysdata/cache_autocomment_cats.php';
	}
	if($cats) $cats=explode(',',$cats);
	$tdstyle = array('width="25"', 'width="60"', '', 'width="160"', 'width="160"', 'width="160"', 'width="160"', 'width="30"', 'width="185"', 'width="100"');
	showformheader("plugins&operation=config&identifier=autocomment&pmod=item");
	showtableheader(lang('plugin/autocomment','list_title'), 'nobottom', 'style="min-width:900px;*width:900px;"');
	showsubtitle(array('', '', 'portalcategory_name', 'portalcategory_articles',lang('plugin/autocomment','list_menu_1'),lang('plugin/autocomment','list_menu_2'),lang('plugin/autocomment','list_menu_3')), 'header', $tdstyle);
	foreach ($portalcategory as $key=>$value) {
		if($value['level'] == 0) {
			echo showcategoryrow($key, 0, '');
		}
	}
	showsubmit('editsubmit');
	showtablefooter();
	showformfooter();/*Dism_taobao-com*/

	$langs = array();
	$keys = array('portalcategory_addcategory', 'portalcategory_addsubcategory', 'portalcategory_addthirdcategory');
	foreach ($keys as $key) {
		$langs[$key] = cplang($key);
	}
}else{
	$cats='';
	foreach($_POST['portal'] as $catid=>$v){
		$cats.=empty($cats)? $catid:','.$catid;
	}
	@require_once libfile('function/cache');
	$cacheArray = "\$cats='$cats';\n";
	writetocache('autocomment_cats',$cacheArray);
	cpmsg(lang('plugin/autocomment','list_update'), 'action=plugins&operation=config&identifier=autocomment&pmod=item', 'succeed');
}

	

function showcategoryrow($key, $level = 0, $last = '') {
	global $_G,$cats;
	loadcache('portalcategory');
	$value = $_G['cache']['portalcategory'][$key];
	$return = '';

	include_once libfile('function/portalcp');
	$value['articles'] = category_get_num('portal', $key);
	$publish = '';
	if(empty($_G['cache']['portalcategory'][$key]['disallowpublish'])) {
		$publish = '&nbsp;<a href="portal.php?mod=portalcp&ac=article&catid='.$key.'" target="_blank">'.cplang('portalcategory_publish').'</a>';
	}
	if(in_array($value['catid'],$cats)) $selected=" checked ";
	else $selected='';
	$cnum='0'.lang('plugin/autocomment','comments');
	if(file_exists(DISCUZ_ROOT.'./data/sysdata/cache_autocomment_'.$value['catid'].'.php')){
		@require_once DISCUZ_ROOT.'./data/sysdata/cache_autocomment_'.$value['catid'].'.php';
		$cnum=intval(count($data)).lang('plugin/autocomment','comments');
	}
	if($level == 2) {
		$class = $last ? 'lastchildboard' : 'childboard';
		$return = '<tr class="hover" id="cat'.$value['catid'].'"><td>&nbsp;</td><td class="td25"><input type="text" class="txt" name="neworder['.$value['catid'].']" value="'.$value['displayorder'].'" /></td><td><div class="'.$class.'">'.
		'<input type="text" class="txt" name="name['.$value['catid'].']" value="'.$value['catname'].'" />'.
		'</div>'.
		'</td><td>'.$value['articles'].'</td>'.
		'<td><input class="checkbox" type="checkbox" value="1" name="portal['.$value['catid'].']" '.$selected.'></td>'.
		'<td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=autocomment&pmod=item&op=edit&catid='.$value['catid'].'">'.lang('plugin/autocomment','edit').'</a></td>'.
		'<td>'.$cnum.'</td>'.
		'</tr>';
	} elseif($level == 1) {
		$return = '<tr class="hover" id="cat'.$value['catid'].'"><td>&nbsp;</td><td class="td25"><input type="text" class="txt" name="neworder['.$value['catid'].']" value="'.$value['displayorder'].'" /></td><td><div class="board">'.
		'<input type="text" class="txt" name="name['.$value['catid'].']" value="'.$value['catname'].'" />'.
		'</td><td>'.$value['articles'].'</td>'.
		'<td><input class="checkbox" type="checkbox" value="1" name="portal['.$value['catid'].']" '.$selected.'></td>'.
		'<td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=autocomment&pmod=item&op=edit&catid='.$value['catid'].'">'.lang('plugin/autocomment','edit').'</a></td>'.
		'<td>'.$cnum.'</td>'.
		'</tr>';
		for($i=0,$L=count($value['children']); $i<$L; $i++) {
			$return .= showcategoryrow($value['children'][$i], 2, $i==$L-1);
		}
	} else {
		$childrennum = count($_G['cache']['portalcategory'][$key]['children']);
		$toggle = $childrennum > 25 ? ' style="display:none"' : '';
		$return = '<tbody><tr class="hover" id="cat'.$value['catid'].'"><td onclick="toggle_group(\'group_'.$value['catid'].'\')"><a id="a_group_'.$value['catid'].'" href="javascript:;">'.($toggle ? '[+]' : '[-]').'</a></td>'
		.'<td class="td25"><input type="text" class="txt" name="neworder['.$value['catid'].']" value="'.$value['displayorder'].'" /></td><td><div class="parentboard">'.
		'<input type="text" class="txt" name="name['.$value['catid'].']" value="'.$value['catname'].'" />'.
		'</div>'.
		'</td><td>'.$value['articles'].'</td>'.
		'<td><input class="checkbox" type="checkbox" value="1" name="portal['.$value['catid'].']" '.$selected.'></td>'.
		'<td><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=autocomment&pmod=item&op=edit&catid='.$value['catid'].'">'.lang('plugin/autocomment','edit').'</a></td>'.
		'<td>'.$cnum.'</td>'.
		'</tr></tbody>
		<tbody id="group_'.$value['catid'].'"'.$toggle.'>';
		for($i=0,$L=count($value['children']); $i<$L; $i++) {
			$return .= showcategoryrow($value['children'][$i], 1, '');
		}
	}
	return $return;
}
//From: Dism_taobao_com	
?>