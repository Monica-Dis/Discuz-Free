function LuobocDanmu() {
    var luoboc_danmu, luoboc_danmu_div, luoboc_danmu_id, peizhi, danmu_hf_input, danmu_hf_yanzheng, huifu_html,hf_shuru;

    this.kaishi = function (peizhis) {
        if(!peizhis){
            return false;
        }
        luoboc_danmu = class_dom("luoboc_danmu");
        if(!luoboc_danmu){
            return false;
        }
        luoboc_danmu_div = class_dom("luoboc_danmu_div");
        luoboc_danmu_id = document.getElementById("luoboc_danmu");
        peizhi = {
            siteurl: peizhis.siteurl,
            url: peizhis.siteurl + peizhis.url,
            formhash: peizhis.formhash,
            sudu: peizhis.sudu,
            touming: peizhis.touming,
            zanting: peizhis.zidong,
            juli: peizhis.juli,
            uid: peizhis.uid,
            sid: peizhis.sid,
            fid: peizhis.fid,
            tid: peizhis.tid,
            pid: 0,
            allreplies: peizhis.allreplies,
            hang: peizhis.hang,
            wangzhi: peizhis.wangzhi,
            zidong: peizhis.zidong,
            xunhuan: peizhis.xunhuan,
            guanbi: peizhis.guanbi,
            vip_jianju: peizhis.vip_jianju,
            vip_beijing: peizhis.vip_beijing,
            css_uid: peizhis.css_uid,
            huifu: peizhis.huifu,
            huifu_width: peizhis.huifu_peizhi.width,
            huifu_height: 0,
            huifu_zhnkai: peizhis.huifu_peizhi.zhnkai,
            huifu_placeholder: peizhis.huifu_peizhi.placeholder,
            huifu_submit: peizhis.huifu_peizhi.submit,
            huifu_fabucg: peizhis.huifu_peizhi.fabucg,
            xunhuan_if: false,
            dingshi: 0,
            jihe: [],
            jihes: [],
            tongdao: [],
            div_width: luoboc_danmu_id.clientWidth,
            div_left: luoboc_danmu_id.getBoundingClientRect().left,
            div_height: 0,
            div_zhnkai: peizhis.zhamkai,
            isMobile: goPAGE(peizhis.isMobile),
            setTimeout: [],
            page: 0,
            ajax: false,
            ajax_jia: 0,
            items_height: 0,
            biaoqing: if_func('showMenu'),
            yanzhengma: false,
        }
        dengdai();
        roll();
    }

    // 点击暂停开始
    var roll = function () {
        luoboc_danmu_id.addEventListener('click', function () {
            if(!peizhi.zidong) {
                peizhi.zidong = peizhi.zanting = true;
                jiazai();
            }else{
                rolls();
            }
        });
    }

    // 等待加载完成执行，更新DIV-left位置信息
    var dengdai = function () {
        jiazai();
        peizhi.div_height = luoboc_danmu.clientHeight;
        if(!peizhi.div_zhnkai){
            luoboc_danmu.style.height = '34px';
            peizhi.zidong = false;
        }else{
            if(!peizhi.zidong) {
                luoboc_danmu_id.style.height = peizhi.div_height - 34 + 'px';
            }
        }
        peizhi.huifu_height = 34;

        if(peizhi.isMobile){
            xuanfu_top();

            huifu_htmls = document.createElement("div");
            var huifu_zhnkai = 'luoboc_icon_you',div_zhnkai = 'luoboc_icon_shang';
            if(!peizhi.huifu_zhnkai){
                huifu_zhnkai = 'luoboc_icon_pinglun';
            }
            if(!peizhi.div_zhnkai){
                div_zhnkai = 'luoboc_icon_xia';
            }
            add_c(huifu_htmls, 'luoboc_danmu_huifu');
    
            var html = '<div class="luoboc_danmu_ico"><div class="luoboc_danmu_dm_shouqi luoboc_dmy"><span class="luoboc_dm_icon '+div_zhnkai+'"></span></div>';
    
            // 回复
            if(peizhi.huifu && peizhi.uid){
    
                html += '<div class="luoboc_danmu_hf_shouqi luoboc_dmy"><span class="luoboc_dm_icon '+huifu_zhnkai+'"></span></div></div><div class="luoboc_danmu_hf_shuru"><div class="luoboc_danmu_hf_touxiang"><img src="uc_server/avatar.php?uid='+peizhi.uid+'&size=small&ts=1"></div><input type="text" name="luoboc_danmu_hf" id="luoboc_danmu_hf_input" value="" autocomplete="off" class="" placeholder="'+peizhi.huifu_placeholder+'"><button type="submit" class="luoboc_danmu_hf_submit">'+peizhi.huifu_submit+'</button>';
            }
    
            huifu_htmls.innerHTML = html + '</div>';
            huifu_html = luoboc_danmu_div.appendChild(huifu_htmls);

        }else{
            huifu_html = class_dom("luoboc_danmu_huifu");

        }
        
        if(peizhi.huifu && peizhi.uid){
            huifu_html.style.height = peizhi.huifu_height + 'px';
            huifu_html.querySelector(".luoboc_danmu_ico").style.width = '84px';

            danmu_hf_yanzheng = document.getElementById("luoboc_danmu_yanzheng");
            if(danmu_hf_yanzheng){
                peizhi.yanzhengma = true;
            }

            hf_shuru = huifu_html.querySelector(".luoboc_danmu_hf_shuru");
            huifu_kuang();
            if(!peizhi.huifu_zhnkai){
                hf_shuru.style.width = '0px';
            }
            setTimeout(function () {
                peizhi.div_width = luoboc_danmu_id.clientWidth;
                if(!peizhi.huifu_width || peizhi.div_width - 84 < peizhi.huifu_width){
                    peizhi.huifu_width = peizhi.div_width - 84;
                    if(peizhi.huifu_zhnkai){
                        hf_shuru.style.width = peizhi.huifu_width + 'px';
                    }else{
                        hf_shuru.style.width = '0px';
                    }
                }
            }, 0);
        }

        // 点击关闭弹幕
        var luoboc_danmu_dm_shouqi = huifu_html.querySelector(".luoboc_danmu_dm_shouqi");
        luoboc_danmu_dm_shouqi.addEventListener('click', function () {
            huadong_guanbi(luoboc_danmu, 500);
            if(this.querySelector(".luoboc_icon_shang") != null){
                rep_c(this.querySelector(".luoboc_dm_icon"), 'luoboc_icon_shang', 'luoboc_icon_xia');
            }else{
                rep_c(this.querySelector(".luoboc_dm_icon"), 'luoboc_icon_xia', 'luoboc_icon_shang');
            }
        });

        if(!peizhi.isMobile && document.getElementById("switchwidth")){
            document.getElementById("switchwidth").addEventListener('click', function () {
                peizhi.div_width = luoboc_danmu_id.clientWidth;
                peizhi.div_left = luoboc_danmu_id.getBoundingClientRect().left;
                qingkong();
                if(peizhi.huifu_width){
                    if(peizhi.div_width < peizhi.huifu_width){
                        peizhi.huifu_width = peizhi.div_width - 84;
                        hf_shuru.style.width = peizhi.huifu_width + 'px';
                    }
                }else{
                    peizhi.huifu_width = peizhi.div_width - 84;
                    hf_shuru.style.width = peizhi.huifu_width + 'px';
                }
            });
        }
    }

    var jiazai = function() {
        setTimeout(function () {
            peizhi.div_left = luoboc_danmu_id.getBoundingClientRect().left;
            if (peizhi.zidong) {
                ajax_dm(peizhi.url, { formhash: peizhi.formhash, allreplies: peizhi.allreplies, tid: peizhi.tid});
            }
        }, 0);
    }

    // 弹幕通道
    var xunhuan = function () {
        for (var i = 0; i < peizhi.jihe.length; i++) {
            var tongdao = tongdao_js();
            if (tongdao < 0 || !peizhi.zanting) {
                break;
            }
            peizhi.tongdao[tongdao] = true;
            luoboc_danmu_danmu(peizhi.jihe[i], tongdao);
            if (peizhi.xunhuan) {
                peizhi.jihes.push(peizhi.jihe[i]);
            }
            peizhi.jihe.splice(i, 1);
        }
        if (peizhi.jihe.length > 0) {
            if (peizhi.jihe.length < peizhi.hang && peizhi.ajax && !peizhi.xunhuan_if) {
                peizhi.ajax = false;
                ajax_dm(peizhi.url, { formhash: peizhi.formhash, allreplies: peizhi.allreplies, page: peizhi.page, tid: peizhi.tid});
            }
            setTimeout(function () {
                xunhuan();
            }, 100);
        } else {
            if (peizhi.xunhuan) {
                peizhi.xunhuan_if = true;
                peizhi.jihe = peizhi.jihes;
                peizhi.jihes = [];
                xunhuan();
            }
        }
    }
    // 加入弹幕
    var luoboc_danmu_danmu = function (danmu, tongdao) {
        if(danmu["message"] == ''){
            peizhi.tongdao[tongdao] = false;
            return false;
        }
        var item = document.createElement("div"), html, target;

        if (peizhi.wangzhi) {
            if (peizhi.wangzh == 2) {
                target = ' target="_blank"_blank';
            }
            html = '<a href="forum.php?mod=redirect&goto=findpost&ptid=' + peizhi.tid + '&pid=' + danmu["pid"] + '&fromuid=1"' + target + '>' + danmu["message"] + '</a>';
        } else {
            html = '<span>' + danmu["message"] + '</span>';
        }

        if (danmu.hasOwnProperty('avtm') && danmu["avtm"] == 1 && danmu.hasOwnProperty('authorid')) {
            html = '<div class="luoboc_danmu-avtm"><img src="' + peizhi.siteurl + 'uc_server/avatar.php?uid=' + danmu["authorid"] + '&size=small&ts=1"></div>' + html;
        }
        item.innerHTML = html;
        add_c(item, 'luoboc_danmu-item');
        if (danmu['pid'] == 0) {
            add_c(item, 'luoboc_danmu-post');
        }
        if (danmu.hasOwnProperty('gid')) {
            add_c(item, 'luoboc_danmu-gid' + danmu['gid']);
        }
        if (danmu.hasOwnProperty('vip')) {
            add_c(item, 'luoboc_danmu-vip');
        }
        if (peizhi.css_uid) {
            if (danmu.hasOwnProperty('authorid')) {
                add_c(item, 'luoboc_danmu-uid' + danmu["authorid"]);
            }
            if (peizhi.tid) {
                add_c(item, 'luoboc_danmu-tid' + peizhi.tid);
            }
            if (peizhi.fid) {
                add_c(item, 'luoboc_danmu-fid' + peizhi.fid);
            }
        }
        var transform = 'translateX(' + (peizhi.div_width + 100) + 'px)';
        item.style.transform = transform;
        item.style.transition = transition;

        var items = luoboc_danmu_id.appendChild(item);
        var transition = 'transform ' + (peizhi.sudu + (items.clientWidth / 100)) + 's linear 0s';
        items.setAttribute('style', liulanqi() + 'transform:' + transform + ';transition:' + liulanqi() + transition);

        if (!peizhi.items_height) {
            peizhi.items_height = items.clientHeight;
            peizhi.div_height = peizhi.items_height * peizhi.hang + (peizhi.hang * peizhi.juli);
            luoboc_danmu.style.height = peizhi.div_height + peizhi.huifu_height + 'px';
            luoboc_danmu_id.style.height = peizhi.div_height + 'px';
        }

        var top = items.clientHeight * tongdao ? items.clientHeight * tongdao + (peizhi.juli * tongdao) : 0;
        item.style.top = top + 'px';
        var danmukuan = items.clientWidth + 100;

        items.style.transform = 'translateX(-' + (danmukuan) + 'px)';
        // 鼠标移入暂停
        items.addEventListener(nameMap('move'), function () {
            zanting_dange(items);
            if (peizhi.zanting) {
                add_c(items, 'zindex');
            }
        });
        // 鼠标移出开始
        items.addEventListener(nameMap('leave'), function () {
            if (peizhi.zanting) {
                kaishi_dange(items);
                remove_c(items, 'zindex');
            }
        });
        // 动画结束删除
        items.addEventListener("webkitTransitionEnd", function () {
            luoboc_danmu_id.removeChild(items);
            if(peizhi.guanbi && luoboc_danmu_id.innerHTML == ''){
                huadong_guanbi(luoboc_danmu, 500);
            }
        });
        // 弹幕移动事件
        peizhi.setTimeout[danmu["pid"]] = setTimeout(function () {
            danmus();
        }, 1000);
        function danmus() {
            if (Math.round(peizhi.div_width - danmukuan) >= Math.round(items.getBoundingClientRect().left - peizhi.div_left) - 100) {
                peizhi.tongdao[tongdao] = false;
                delete peizhi.setTimeout[danmu["pid"]];
            } else {
                peizhi.setTimeout[danmu["pid"]] = setTimeout(danmus, 100);
            }
        }
    }
    // 弹幕占位判断
    var tongdao_js = function () {
        if (peizhi.tongdao.length == peizhi.hang) {
            for (var i = 0; i < peizhi.tongdao.length; i++) {
                if (!peizhi.tongdao[i]) {
                    return i;
                }
            }
            return -1;
        } else {
            return peizhi.tongdao.length ? peizhi.tongdao.length : 0;
        }
    }

    // 判断弹幕暂停开始
    var rolls = function () {
        if (peizhi.zanting) {
            zanting();
        } else {
            dj_kaishi();
        }
        peizhi.zanting = !peizhi.zanting;
    }

    // 清空弹幕
    var qingkong = function () {
        luoboc_danmu_id.innerHTML = '';
    }

    // 弹幕暂停
    var zanting = function () {
        var items = luoboc_danmu_id.getElementsByClassName('luoboc_danmu-item');
        for (var i = 0; i < items.length; i++) {
            zanting_dange(items[i]);
        }
    }
    // 弹幕单个暂停
    var zanting_dange = function (items) {
        var weizhi = Math.round(items.getBoundingClientRect().left - peizhi.div_left);
        var transform = items.style.transform;
        transform = transform.replace(/X\([-\d]+px/g, 'X(' + weizhi + 'px');
        items.style.transform = transform;
        items.style.transition = liulanqi() + 'transform 0s linear';
    }
    // 弹幕开始
    var dj_kaishi = function () {
        var items = luoboc_danmu_id.getElementsByClassName('luoboc_danmu-item');
        for (var i = 0; i < items.length; i++) {
            kaishi_dange(items[i]);
        }
    }

    // 弹幕单个开始
    var kaishi_dange = function (items) {
        var kuan = Math.round(items.clientWidth);
        var xs_kuan = peizhi.div_width + kuan + 100;
        // 计算每秒移动百分比
        var bfb = (xs_kuan / (peizhi.sudu + (items.clientWidth / 100))) / xs_kuan;
        var right = Math.round(items.getBoundingClientRect().right - peizhi.div_left) + 50;
        var weizhi = ((right / xs_kuan) / bfb).toFixed(1);
        if (weizhi < 0.1) {
            weizhi = 0.1;
        }
        items.style.transition = liulanqi() + 'transform ' + weizhi + 's linear';
        var transform = items.style.transform;
        transform = transform.replace(/X\([-\d]+px/g, 'X(-' + kuan + 'px');
        items.style.transform = transform;
    }


    // 展开显示和隐藏
    var huadong_guanbi = function (element, time) {
        if (typeof window.getComputedStyle == "undefined") return;

        if(peizhi.div_zhnkai){
            qingkong();
            peizhi.zanting = true;
            rolls();
            element.style.height = "34px";
            element.style.transition = "none";
            element.style.overflow = "hidden";
            setTimeout(function() {
                luoboc_danmu_id.style.display = 'none';
            }, time);
            peizhi.div_zhnkai = false;
            
        }else{
            element.style.height = peizhi.div_height + peizhi.huifu_height + "px";
            element.style.overflow = "";
            luoboc_danmu_id.style.display = 'block';
            setTimeout(function() {
                peizhi.zanting = false;
                rolls();
            }, time);
            peizhi.div_zhnkai = true;
        }
        element.style.transition = "height " + time + "ms";
    };

    var huifu_kuang = function() { // 回复内容
        var hf_submit = huifu_html.querySelector(".luoboc_danmu_hf_submit"),hf_submit_if = false, hf_shouqi = huifu_html.querySelector(".luoboc_danmu_hf_shouqi");
        danmu_hf_input = huifu_html.querySelector("#luoboc_danmu_hf_input");
        danmu_hf_input.onblur = function () {
            if(danmu_hf_input.placeholder == ''){
                danmu_hf_input.placeholder = peizhi.huifu_placeholder;
            }
        };
        danmu_hf_input.onclick = function() {
            if(danmu_hf_input.placeholder){
                danmu_hf_input.placeholder = '';
            }
            if(peizhi.yanzhengma && peizhi.isMobile){
                danmu_hf_yanzheng.style.display = 'block';
            }
        };
        hf_shouqi.onclick = function() {
            if(hf_shuru.style.width == '0px'){
                hf_shuru.style.width = peizhi.huifu_width + 'px';
                hf_shuru.style.transition = 'width 2s';
                hf_shouqi.style.marginRight = '10px';
                add_c(hf_shouqi, 'luoboc_dmy');
                rep_c(hf_shouqi.querySelector('.luoboc_dm_icon'), 'luoboc_icon_pinglun', 'luoboc_icon_you');
            }else{
                hf_shuru.style.transition = 'width 2s';
                hf_shuru.style.width = '0px';
                setTimeout(function() {
                    remove_c(hf_shouqi, 'luoboc_dmy');
                    if(hf_shuru.style.width == '0px'){
                        rep_c(hf_shouqi.querySelector('.luoboc_dm_icon'), 'luoboc_icon_you', 'luoboc_icon_pinglun');
                    }
                }, 2000);
                hf_shouqi.style.marginRight = '0px';

            }
        };
        hf_submit.onmouseover = function () {
            if(danmu_hf_input.value != '' && !hf_submit_if){
                hf_submit_if = true;
            }
            if(danmu_hf_input.value && peizhi.yanzhengma){

                danmu_hf_yanzheng.style.display = 'block';
                var id = danmu_hf_yanzheng.querySelector(".p_pop").id;
                var yz_id = danmu_hf_yanzheng.querySelector("#" + id);

                danmu_hf_yanzheng.querySelector("input.txt").onclick = function(){
                    yz_id.style.top = danmu_hf_yanzheng.offsetTop + 'px !important';
                    yz_id.style.left = danmu_hf_yanzheng.offsetLeft  + 'px !important';
                }
            }
        };
        hf_submit.onclick = function() { // 弹幕发布
            if(!danmu_hf_input.value){
                return false;
            }
            var yanzhengma = '';
            if(peizhi.yanzhengma){
                var seccodeverify = danmu_hf_yanzheng.querySelector(".txt");
                if(seccodeverify){
                    yanzhengma = seccodeverify.value;
                }

                if(peizhi.isMobile){
                    danmu_hf_yanzheng.style.display = 'block';
                }else{
                    if(yanzhengma){
                        hf_shuru.querySelector("#seccodeverify").value = yanzhengma;
                    }
                    return true;
                }
            }
        
            var post = {
                message: danmu_hf_input.value,
                seccodehash: 'cS' + peizhi.sid,
                seccodemodid: 'forum::ajax',
                seccodeverify: yanzhengma,
                posttime: Date.parse(new Date()) / 1000,
                formhash: peizhi.formhash,
                usesig: peizhi.uid,
                subject: ''
            }

            ajax('forum.php?mod=post&action=reply&fid=' + peizhi.fid + '&tid='+ peizhi.tid +'&extra=&replysubmit=yes&infloat=yes&handlekey=fastpost&inajax=1', post, function(fanhui){
                var result = fanhui.responseXML;

                patt = /pid':'\d+',/g;
                if(!patt.exec(fanhui.responseText)){
                    evalscript(result.lastChild.firstChild.nodeValue);
                    return false;
                }
                
                peizhi.jihe.unshift({pid: 0, message: post.message, authorid: peizhi.uid})
                danmu_hf_input.value = '';
                if(peizhi.yanzhengma){
                    seccodeverify.value = '';
                    danmu_hf_yanzheng.style.display = 'none';
                }
            });
        };
    }

    // 判断是不是手机，返回不同事件
    var nameMap = function (zanting) {
        switch (zanting) {
            case 'click':
                return peizhi.isMobile ? 'touchstart' : 'mousedown';
            case 'move':
                return peizhi.isMobile ? 'touchmove' : 'mousemove';
            case 'leave':
                return peizhi.isMobile ? 'touchend' : 'mouseleave';
            default:
                return 'mousedown';
        }
    }
    // 判断是否为移动端
    var goPAGE = function (pandu) {
        var ua = navigator.userAgent;
        if (ua.match(/(iPhone|iPod|Android|ios)/i)) {
            if (pandu != true) {
                return true;
            }
        }
        return pandu;
    }
    // 浏览器兼容
    var liulanqi = function () {
        var userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
        var isOpera = userAgent.indexOf("Opera") > -1;
        if (isOpera) {
            return "-o-"
        };
        if (userAgent.indexOf("Firefox") > -1) {
            return "-moz-";
        }
        if (userAgent.indexOf("Chrome") > -1) {
            return "-webkit-";
        }
        if (userAgent.indexOf("Safari") > -1) {
            return "-webkit-";
        }
        if (userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1 && !isOpera) {
            return "-ms-";
        }
        return "";
    }

    // 请求弹幕 
    var ajax_dm = function (url, data) {
        if(peizhi.pid){
            data['pid'] = peizhi.pid;
        }
        ajax(url, data, function (xmlhttp){
            var danmu = JSON.parse(xmlhttp.responseText);
            if (!danmu && !danmu.hasOwnProperty("content")) {
                return;
            }
            if (danmu.hasOwnProperty('tid')) {
                peizhi.tid = danmu['tid'];
            }
            if (danmu.hasOwnProperty('pid')) {
                peizhi.pid = danmu['pid'];
            }
            for (var key in danmu['content']) {
                peizhi.jihe[key] = danmu['content'][key];
                peizhi.ajax_jia++;
            }
            if (danmu.hasOwnProperty('page')) {
                peizhi.page = danmu['page'];
                if(peizhi.page > 0){
                    peizhi.ajax = true;
                }
            }
            if (peizhi.dingshi == 0) {
                peizhi.dingshi = 1;
                xunhuan();
            }
        });
    }

    // 请求
    var ajax = function (url, data, huidiao) {
        var xmlhttp;
        if (window.XMLHttpRequest) {
            xmlhttp = new XMLHttpRequest();
        } else {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                huidiao(xmlhttp);
            }
        }
        xmlhttp.open("POST", url, true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send(formatParams(data));
    }

    // 处理ajax 请求数据
    var formatParams = function (data) {
        var arr = [];
        for (var name in data) {
            arr.push(encodeURIComponent(name) + "=" + encodeURIComponent(data[name]));
        }
        arr.push(("v=" + Math.random()).replace(".", ""));
        return arr.join("&");
    }

    // 判断是否为函数
    var if_func = function(funcName){
        try {
            if (typeof (eval(funcName)) == "function") {
                return true;
            }
        } catch (e) { }
        return false;
    }

    // 悬浮顶部
    var xuanfu_top = function(){
        var div_top = luoboc_danmu.offsetTop;
        var xuanfu_zhanwei = class_dom("xuanfu_zhanwei");
        if(xuanfu_zhanwei){
            window.onscroll = function(){
                var top = document.documentElement.scrollTop || document.body.scrollTop;
                if(top > div_top){
                    xuanfu_zhanwei.style.display = 'block';
                    xuanfu_zhanwei.style.height = luoboc_danmu.clientHeight + 'px';
                    luoboc_danmu.style.position = 'fixed';
                    luoboc_danmu.style.top = '0';
                }else{
                    luoboc_danmu.style.position = 'relative';
                    xuanfu_zhanwei.style.display = 'none';
                }
            }
        }
    }

    var class_dom = function(clas){
        var dom = document.getElementsByClassName(clas);
        if(dom == null){
            return false
        }
        return dom[0];
    }

    var add_c = function (div, clas){
        if(classIndexOf_c(div, clas) == -1){
            classVal = div.getAttribute("class");
            classVal = classVal ? classVal.concat(' ' + clas) : clas;
            div.setAttribute("class", classVal);
        }
    }

    var remove_c = function (div, clas){
        if(div.className != ""){
            var arrClassName = div.className.split(" ");
            var _index = classIndexOf_c(div, clas);
            if(_index != -1){
                arrClassName.splice(_index,1);
            }
            div.className = arrClassName.join(" ");
        }
    }

    var rep_c = function (div, clas, clas1){
        classVal = div.getAttribute("class").replace(clas, clas1);
        div.setAttribute("class", classVal);
    }

    var classIndexOf_c = function (div, clas){
        var arrClassName = div.className.split(" ");
        for(var i = 0; i < arrClassName.length; i++){
            if(arrClassName[i] == clas){
                return i;
            }
        }
        return -1;
    }
}