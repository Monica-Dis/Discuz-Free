<?php 
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied!');
}
$luoboc_urls = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=luoboc_danmu&pmod=wap';
$luoboc_url = '?' . $luoboc_urls;

if(empty($_G['cache']['luoboc_danmu'])){
    loadcache('luoboc_danmu');
}
$QC['huancun'] = $_G['cache']['luoboc_danmu'];

if($_GET['formhash'] == FORMHASH && !empty($_GET['gx'])){
    $wap = daddslashes($_GET['wap']);

    $wap['kai'] = intval($wap['kai']);
    $wap['changdu'] = intval($wap['changdu']);
    $wap['sudu'] = intval($wap['sudu']);
    $wap['daxiao'] = intval($wap['daxiao']);
    $wap['juli'] = intval($wap['juli']);
    $wap['jianju'] = intval($wap['jianju']);
    $wap['weizhi'] = intval($wap['weizhi']);
    $wap['xuanfu'] = intval($wap['xuanfu']);
    $wap['div_kuan'] = intval($wap['div_kuan']);
    $wap['touming'] = intval($wap['touming']) > 10 || intval($wap['touming']) < 0 ? 0 : intval($wap['touming']);

    foreach($wap as $k => $v){
        $QC['huancun'][$k] = $v;
    }

    save_syscache('luoboc_danmu', $QC['huancun']);
    cpmsg("luoboc_danmu:gengxin_cg", $luoboc_urls, "succeed");
}


$wap = dhtmlspecialchars($QC['huancun']);
include template('luoboc_danmu:wap');