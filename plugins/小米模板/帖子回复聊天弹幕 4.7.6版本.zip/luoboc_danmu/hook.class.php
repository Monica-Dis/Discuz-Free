<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied!');
}

class luoboc_danmu_base {

    public $QC = array();
    public $cg = false;
    
    public function peizhi($wap = false){
        global $_G;
        if(empty($_G['cache']['plugin']['luoboc_danmu'])){
            loadcache('plugin');
        }
        $this->QC = $_G['cache']['plugin']['luoboc_danmu'];
        $this->zy_peizhi();
        if($wap){
            $this->wap_canshu();
        }
    }

    // 读取自定义缓存
    public function zy_peizhi(){
        global $_G;
        if(empty($_G['cache']['luoboc_danmu'])){
            loadcache('luoboc_danmu');
        }
        $this->QC['huancun'] = $_G['cache']['luoboc_danmu'];
    }

    // 手机端参数
    public function wap_canshu(){
        if(!empty($this->QC['huancun']) && !empty($this->QC['huancun']['kai'])){
            $wap = $this->QC['huancun'];
            if(!empty($wap['changdu'])) $this->QC['changdu'] = $wap['changdu'];
            if(!empty($wap['sudu'])) $this->QC['sudu'] = $wap['sudu'];
            if(!empty($wap['daxiao'])) $this->QC['daxiao'] = $wap['daxiao'];
            if(!empty($wap['yanse'])) $this->QC['yanse'] = $wap['yanse'];
            if(!empty($wap['beijing'])) $this->QC['beijing'] = $wap['beijing'];
            if(!empty($wap['beijing_shubiao'])) $this->QC['beijing_shubiao'] = $wap['beijing_shubiao'];
            if(!empty($wap['miaobian'])) $this->QC['miaobian'] = $wap['miaobian'];
            if(!empty($wap['miaobian_zdy'])) $this->QC['miaobian_zdy'] = $wap['miaobian_zdy'];
            if(!empty($wap['bianju'])) $this->QC['bianju'] = $wap['bianju'];
            if(!empty($wap['juli'])) $this->QC['juli'] = $wap['juli'];
            if(!empty($wap['touming'])) $this->QC['touming'] = $wap['touming'];
            if(!empty($wap['jianju'])) $this->QC['jianju'] = $wap['jianju'];
            if(!empty($wap['weizhi'])) $this->QC['weizhi'] = $wap['weizhi'];
            if(!empty($wap['xuanfu'])) $this->QC['xuanfu'] = $wap['xuanfu'];
            if(!empty($wap['nei_bianju'])) $this->QC['nei_bianju'] = $wap['nei_bianju'];
            if(!empty($wap['wai_bianju'])) $this->QC['wai_bianju'] = $wap['wai_bianju'];
            if(!empty($wap['div_kuan'])) $this->QC['div_kuan'] = $wap['div_kuan'];
            if(!empty($wap['css'])) $this->QC['css'] = $wap['css'];
        }
    }

    // 判读是否满足条件开启弹幕
    public function if_tiaojian(){
        global $_G;
        $this->QC['bnakuai'] = unserialize($this->QC['bnakuai']);
        $this->QC['yonghuzu'] = unserialize($this->QC['yonghuzu']);
        $this->QC['tiezi'] = explode(',', $this->QC['tiezi']);
        if(($_G['forum_thread']['allreplies'] >= $this->QC['xianshi'] || $this->QC['xianshi'] == 0) && in_array($_G['groupid'], $this->QC['yonghuzu'])){
            if(in_array($_G['tid'], $this->QC['tiezi'])){
                return true;
            }
            if(in_array($_G['fid'], $this->QC['bnakuai'])){
                return true;
            }
        }
        return false;
    }

    // 判断设置弹幕位置
    public function weizhi($id, $wap = false){
        global $_G,$hiddenreplies,$post;
        $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);

        if($needhiddenreply || $this->cg || !empty($_G['inajax']) || $_G['page'] > 1){ // 判断是否为AJAX
            return array();
        }
        $this->peizhi($wap);
        if($wap && empty($this->QC['huancun']['kai'])){
            return array();
        }
        if(!$this->if_tiaojian() || $this->QC['weizhi'] != $id){
            return array();
        }
        $this->cg = true;
        return $this->huancun_shezhi($wap);
    }

    // 读取配置缓存
    public function huancun_shezhi($wap){
        global $_G,$secqaacheck,$seccodecheck;
        $wap_css = $huancun_peizhi = false;
        $zhonduan = $wap ? 'wap' : 'pc';
        if(empty($this->QC['huancun']['html'][$zhonduan.'peizhi'])){
            $peizhi = $this->shezhi($wap);
        }else{
            $peizhi = array($zhonduan.'peizhi' => $this->QC['huancun']['html'][$zhonduan.'peizhi']);
            $wap_css = true;
        }

        // 回复处理
        $huifu_kai = 0;
        if(!empty($this->QC['huancun']['huifu']['kai'])){
            $waps = $wap ? 2 : 1;
            if(in_array($waps, $this->QC['huancun']['huifu']['zhongduan']) && in_array($_G['groupid'], $this->QC['huancun']['huifu']['yonghuzu'])){
                $huifu_kai = 1;
            }
        }

        $style_html = $xuanfu_class = '';
        // 手机悬浮顶部
        if($wap && $this->QC['huancun']['xuanfu'] == 2){
            $xuanfu_class = ' xuanfu';
        }

        if(empty($this->QC['huancun_peizhi']) && !empty($peizhi['style'])){
            $style = dhtmlspecialchars($peizhi['style']);
            $style_html = '<style>'.$style.'</style>';
            $huancun_peizhi = true;
        }

        if(!empty($peizhi[$zhonduan.'peizhi'])){
            $peizhis = $peizhi[$zhonduan.'peizhi'];
            $peizhis['uid'] = intval($_G['uid']);
            $peizhis['sid'] = $_G['sid'];
            $peizhis['allreplies'] = intval($_G['forum_thread']['allreplies']);
            $peizhis['formhash'] = FORMHASH;
            $peizhis['fid'] = intval($_G['fid']);
            $peizhis['tid'] = intval($_G['tid']);
            $peizhis['isMobile'] = $wap;
            $peizhis['huifu'] = $huifu_kai;

            $peizhis['yanzhengma'] = false;
            if($secqaacheck || $seccodecheck){
                $peizhis['yanzhengma'] = true;
            }

            $peizhiss = json_encode($peizhis);
        }else{
            $peizhis = '{}';
        }

        if($_G['charset'] == 'gbk'){
            $peizhis['huifu_peizhi']['placeholder'] = diconv($peizhis['huifu_peizhi']['placeholder'], 'UTF-8', 'gbk');
            $peizhis['huifu_peizhi']['submit'] = diconv($peizhis['huifu_peizhi']['submit'], 'UTF-8', 'gbk');
        }

        include template('luoboc_danmu:danmu');
        return $return;
    }

    public function shezhi($wap){
        require_once './source/plugin/luoboc_danmu/peizhi.class.php';
        $PeiZhi = new PeiZhi();
        return $PeiZhi->peizhis($this->QC, $wap);
    }
} 


class plugin_luoboc_danmu extends luoboc_danmu_base {

}   


class plugin_luoboc_danmu_forum extends plugin_luoboc_danmu {

    public function viewthread_postbutton_top_output() {
        // 加载配置
        return $this->weizhi(1);
    }

    public function viewthread_beginline_output() {
        return $this->weizhi(2);
    }


    public function viewthread_posttop_output() {
        $html = $this->weizhi(3);
        if($html){
            return array(
                0 => $html,
            );
        }
        return array();
    }

    public function viewthread_postbottom_output() {
        $html = $this->weizhi(4);
        if($html){
            return array(
                0 => $html,
            );
        }
        return array();

    }

    public function viewthread_endline_output() {
        $html = $this->weizhi(5);
        if($html){
            return array(
                0 => $html,
            );
        }
        return array();
    }
}


class mobileplugin_luoboc_danmu_forum extends plugin_luoboc_danmu {

    public function viewthread_top_mobile_output() {
        return $this->weizhi(1, true);
    }

    public function viewthread_posttop_mobile_output() {
        $html = $this->weizhi(2, true);
        if($html){
            return array(
                0 => $html,
            );
        }
        $html = $this->weizhi(4, true);
        if($html){
            return array(
                1 => $html,
            );
        }
        return array();
    }
    public function viewthread_postbottom_mobile_output() {
        $html = $this->weizhi(3, true);
        if($html){
            return array(
                0 => $html,
            );
        }
        return array();
    }
}
?>