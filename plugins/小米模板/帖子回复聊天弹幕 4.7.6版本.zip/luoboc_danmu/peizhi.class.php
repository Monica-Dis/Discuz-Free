<?php 
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
    exit('Access Denied!');
}

class PeiZhi{

    public function peizhis($QC, $wap, $url = 'plugin.php?id=luoboc_danmu:api'){
        global $_G;
        $url = dhtmlspecialchars($url);
        $peizhi = array(
            'zidong' => !empty($QC['zidong']) ? true : false,
            'zhamkai' => !empty($QC['zhamkai']) ? true : false,
            'sudu' => intval($QC['sudu']),
            'hang' => intval($QC['hang']),
            'daxiao' => intval($QC['daxiao']),
            'juli' => empty($QC['juli']) ? 15 : intval($QC['juli']),
            'touming' => intval($QC['touming']),
            'jianju' => intval($QC['jianju']),
            'weizhi' => intval($QC['weizhi']),
            'wangzhi' => intval($QC['wangzhi']),
            'xunhuan' => intval($QC['xunhuan']),
            'guanbi' => intval($QC['guanbi']),
            'yanse' => $QC['yanse'] ? $QC['yanse'] : '#fff',
            'beijing' => $QC['beijing'],
            'beijing_shubiao' => $QC['beijing_shubiao'],
            'ziti_shubiao' => $QC['ziti_shubiao'] ? $QC['ziti_shubiao'] : '#fff',
            'bianju' => $QC['bianju'],
            'wai_bianju' => $QC['wai_bianju'],
            'miaobian' => $QC['miaobian'],
            'miaobian_zdy' => $QC['miaobian_zdy'],
            'vip_jianju' => $QC['vip_jianju'],
            'vip_beijing' => $QC['vip_beijing'],
            'css' => $QC['css'],
            'css_uid' => intval($QC['css_uid']),
            'xuanfu' => intval($QC['xuanfu']),
            'div_kuan' => intval($QC['div_kuan']),
        );
        $zdyi_css = $jianju = $xuanfu = '';

        // 弹幕透明
        if($peizhi['touming'] > 10 || $peizhi['touming'] < 1){
            $peizhi['touming'] = 10;
        }
        $peizhi['touming'] = $peizhi['touming'] / 10;
        // 字体大小
        if($peizhi['daxiao']){
            $itme_h = $peizhi['daxiao'] + 6;
            $itme_fz = $peizhi['daxiao'];
        }else{
            $itme_h = 22;
            $itme_fz = 16;
        }
        // 字体间距
        if($peizhi['jianju']){
            $jianju = 'letter-spacing:'.$peizhi['jianju'].'px;';
        }
        // 背景
        $peizhi['beijing'] = $this->fenge($peizhi['beijing']);

        // 鼠标移动背景
        $peizhi['beijing_shubiao'] = $this->fenge($peizhi['beijing_shubiao']);

        // 模块内边距
        $nei_bianju = explode('|', $peizhi['nei_bianju']);
        if(count($nei_bianju) == 4){
            $peizhi['nei_bianju'] = implode('px ', $this->intvals($nei_bianju));
        }else{
            $peizhi['nei_bianju'] = '10px 0';
        }

        // 模块外边距
        $wai_bianju = explode('|', $peizhi['wai_bianju']);
        if(count($wai_bianju) == 4){
            $peizhi['wai_bianju'] = implode('px ', $this->intvals($wai_bianju));
        }else{
            $peizhi['wai_bianju'] = '10px 0';
        }

        // 内边距
        $bianju = explode('|', $peizhi['bianju']);
        if(count($bianju) == 4){
            $peizhi['bianju'] = implode('px ', $this->intvals($bianju));
        }else{
            $peizhi['bianju'] = '8px 20';
        }
        // 弹幕描边
        if($peizhi['miaobian']){
            if($peizhi['miaobian_kuan']){
                $peizhi['miaobian'] = 'text-shadow:'.$peizhi['miaobian_zdy'];
            }else{
                $peizhi['miaobian'] = 'text-shadow: 0 0 2px '.$peizhi['miaobian'].', 0 1px 0 '.$peizhi['miaobian'].', 0 0 2px '.$peizhi['miaobian'].', 0 0 1px '.$peizhi['miaobian'].';';
            }
        }
        // 弹幕模式
        if($peizhi['xuanfu'] == 2 && !$wap){
            $xuanfu = 'absolute';
        }elseif($peizhi['xuanfu'] == 3){
            $xuanfu = 'absolute;left:0;right:0';
        }else{
            $xuanfu = 'relative';
        }
        // 弹幕整体div宽度
        $div_kuan = $peizhi['div_kuan'] ? $peizhi['div_kuan'].'px' : '100%';

        // 回复处理
        $huifu_peizhi = array('width' => 0, 'yanse' => '#ff613b', 'anniu' => '#ff6428;background: linear-gradient(90deg,#ff850b 0,#ff5945)', 'placeholder' => '', 'submit' => lang('plugin/luoboc_danmu', 'fabiao'), 'zhiti' => '#fff', 'post' => '#fff', 'post_zhiti' => '#fff', 'zhnkai' => false);
        if(!empty($QC['huancun']['huifu']['kai'])){
            $huifu = $QC['huancun']['huifu'];
            $waps = $wap ? 2 : 1;
            if(in_array($waps, $huifu['zhongduan'])){
                // 宽度
                if($wap){
                    $huifu_peizhi['width'] = !empty($huifu['wapinput_kuan']) ? intval($huifu['wapinput_kuan']) : 0;
                }else{
                    $huifu_peizhi['width'] = !empty($huifu['pcinput_kuan']) ? intval($huifu['pcinput_kuan']) : 0;
                }

                $huifu_peizhi['zhnkai'] = $huifu['zhnkai'] ? true : false;
            
                if($huifu_peizhi['width'] == 0){
                    $huifu_peizhi['widths'] = '100%';
                }else {
                    $huifu_peizhi['widths'] = $huifu_peizhi['width'].'px';
                }

                // 边框颜色
                if($huifu['yanse']){
                    $huifu_peizhi['yanse'] = $huifu['yanse'];
                    $huifu_peizhi['yanse'] = $this->fenge($huifu_peizhi['yanse']);
                }

                // 按钮背景
                if($huifu['anniu']){
                    $huifu_peizhi['anniu'] = $huifu['anniu'];
                    $huifu_peizhi['anniu'] = $this->fenge($huifu_peizhi['anniu']);
                }

                // 输入框内提示文字
                if(!empty($huifu['placeholder'])){
                    $huifu_peizhi['placeholder'] = $huifu['placeholder'];
                }
                if(!empty($huifu['submit'])){
                    $huifu_peizhi['submit'] = $huifu['submit'];
                }

                // 按钮字体颜色
                if(!empty($huifu['zhiti'])){
                    $huifu_peizhi['zhiti'] = $huifu['zhiti'];
                }

                // 刚发布弹幕字体颜色
                if(!empty($huifu['post_zhiti'])){
                    $huifu_peizhi['post_zhiti'] = $huifu['post_zhiti'];
                }

                // 刚发布弹幕背景
                if($huifu['post']){
                    $huifu_peizhi['post'] = $huifu['post'];
                    $huifu_peizhi['post'] = $this->fenge($huifu_peizhi['post']);
                }
                
                $huifu_peizhi['fabucg'] = lang('plugin/luoboc_danmu', 'fabuchenggong');
            }
        }

        // 手机悬浮顶部背景
        $peizhi['xuanfu_beijing'] = '';
        if(!empty($QC['huancun']['xuanfu_beijing'])){
            $peizhi['xuanfu_beijing'] = $this->fenge($QC['huancun']['xuanfu_beijing']);
        }

        if($peizhi['css']){
            $zdyi_css = $peizhi['css'];
        }
        if($peizhi['vip_beijing']){
            $zdyi_css .= '#luoboc_danmu .luoboc_danmu-vip{background: '.$this->fenge($peizhi['vip_beijing']).';}';
        }
        if($peizhi['vip_jianju']){
            $zdyi_css .= '#luoboc_danmu .luoboc_danmu-vip a,.luoboc_danmu-item span{color: '.$peizhi['vip_jianju'].';}';
        }
        $style = <<<EOF
.luoboc_danmu{position:$xuanfu;width:$div_kuan;height:220px;margin:$peizhi[wai_bianju]px;padding:$peizhi[nei_bianju]px;}
.luoboc_danmu_div{position:relative;width:100%;height:100%}
#luoboc_danmu{opacity:$peizhi[touming]}
#luoboc_danmu{position:absolute;top:0;right:0;bottom:0;left:0;z-index:1;visibility:visible;overflow:hidden;width:100%;font-family:PingFangSC-Regular,sans-serif;cursor:pointer;}
.luoboc_danmu-item a,.luoboc_danmu-item span{display: block;color: $peizhi[yanse];height:100%;overflow:hidden;vertical-align: middle;$jianju$peizhi[miaobian]}
#luoboc_danmu .luoboc_danmu-item{background: $peizhi[beijing];border-radius: 24px;padding: $peizhi[bianju]px;position: absolute;height: ${itme_h}px;font-size: ${itme_fz}px;line-height: ${itme_h}px;z-index: 1;visibility: visible;font-family: PingFangSC-Regular, sans-serif;}
#luoboc_danmu .luoboc_danmu-item:hover{background: $peizhi[beijing_shubiao];color: $peizhi[ziti_shubiao]}
#luoboc_danmu .luoboc_danmu-item:hover a{color: $peizhi[ziti_shubiao]}
#luoboc_danmu .luoboc_danmu-item.zindex{z-index: 2;}
.luoboc_danmu-item .luoboc_danmu-avtm {vertical-align: middle;width: ${itme_h}px;height: 100%;border-radius: 100%;float: left;margin-right: 10px;overflow:hidden;background:#fff;}
.luoboc_danmu-item .luoboc_danmu-avtm img {width: auto;height: 100%;}
.luoboc_danmu-item a img,.luoboc_danmu-item span img{height:100%;vertical-align:middle;padding:0 9px;}
.luoboc_danmu-item .luoboc_danmu-post{color: $huifu_peizhi[post_zhiti];background: $huifu_peizhi[post];}
.luoboc_danmu_huifu{position:absolute;right:0;bottom:0px;z-index:1;}
.luoboc_danmu_hf_shuru{position:relative;display:inline-block;vertical-align:middle;white-space:nowrap;width: calc($huifu_peizhi[widths] - 84px);z-index:1;overflow: hidden;}
.luoboc_danmu_hf_touxiang{position:absolute;top:5px;left:5px;overflow:hidden;width:24px;height:24px;border-radius:24px;background:#ff603d}
.luoboc_danmu_hf_touxiang img{width:100%;height:100%;}
#luoboc_danmu_hf_input{float:left;height:34px;z-index:1;display:inline-block;;overflow:hidden;box-sizing:border-box;padding:6px 34px;width:calc(100% - 66px);border:none;border-radius:17px 0 0 17px;background:#fff;background-size:0;color:#ccc;text-indent:0;font-size:14px;line-height:20px;zoom:1;border: 1px solid #ff613b;vertical-align:middle;}
#luoboc_danmu_hf_input:focus{outline:0;border: 1px solid $huifu_peizhi[yanse];}
.luoboc_danmu_hf_submit{width:66px;height:34px;display:inline-block;outline:0;border:none;border-radius:0 16px 16px 0;background: #525254;background-color:$huifu_peizhi[anniu];color:$huifu_peizhi[zhiti];font-size:14px;line-height:32px;cursor:pointer;vertical-align:middle;}
#luoboc_danmu_yanzheng{float:right;display:none}.luoboc_danmu-wap #luoboc_danmu_yanzheng{background: #ffff;}
@font-face{font-family:iconfont;src:url(/source/plugin/luoboc_danmu/font/iconfont.eot?t=1590507469301);src:url(/source/plugin/luoboc_danmu/font/iconfont.eot?t=1590507469301#iefix) format('embedded-opentype'),url(/source/plugin/luoboc_danmu/font/iconfont.woff2?t=1590507469301) format('woff2'),url(/source/plugin/luoboc_danmu/font/iconfont.woff?t=1590507469301) format('woff'),url(/source/plugin/luoboc_danmu/font/iconfont.ttf?t=1590507469301) format('truetype'),url(/source/plugin/luoboc_danmu/font/iconfont.svg?t=1590507469301#iconfont) format('svg')}
.luoboc_dm_icon{display:inline-block;width:32px;height:32px;text-transform:none;font-weight:400;font-variant:normal;font-size:32px;font-family:iconfont!important;-moz-transition:font-size .25s ease-out 0s;speak:none;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}
.luoboc_danmu_ico{float:left;display:inline-block;width:34px;height:34px;z-index:1;}
.luoboc_icon_pinglun{font-size:30px}.luoboc_icon_zuo:before{content:'\\de61d'}.luoboc_icon_pinglun:before{content:'\\de507'}.luoboc_icon_you:before{content:'\\de88a'}.luoboc_icon_xia:before{content:'\\de662'}.luoboc_icon_shang:before{content:'\\de501'}.luoboc_icon_shang,.luoboc_icon_xia{font-size:29px;}.luoboc_danmu-wap .luoboc_icon_shang, .luoboc_danmu-wap.luoboc_icon_xia{font-size:31px;}
.luoboc_danmu_dm_shouqi,.luoboc_danmu_hf_shouqi{float:left;display:inline-block;width:32px;height:100%;line-height:38px;margin-right:10px;color:#ff7f13;cursor:pointer;vertical-align:middle}
.luoboc_danmu-wap .luoboc_danmu_dm_shouqi,.luoboc_danmu-wap .luoboc_danmu_hf_shouqi{line-height:34px;}
.luoboc_dm_icon:hover{color:#ff0000;}.luoboc_danmu.xuanfu{background:$peizhi[xuanfu_beijing];z-index:1;margin-top:0}
$zdyi_css
EOF;

        $peizhis = array(
            'zidong' => $peizhi['zidong'],
            'zhamkai' => $peizhi['zhamkai'],
            'siteurl' => $_G['siteurl'],
            'url' => $url,
            'sudu' => $peizhi['sudu'],
            'touming' => $peizhi['touming'],
            'juli' => $peizhi['juli'],
            'hang' => $peizhi['hang'],
            'wangzhi' => $peizhi['wangzhi'],
            'xunhuan' => $peizhi['xunhuan'],
            'guanbi' => $peizhi['guanbi'],
            'vip_jianju' => $peizhi['vip_jianju'],
            'vip_beijing' => $peizhi['vip_beijing'],
            'css_uid' => $peizhi['css_uid'],
            // 'wab_div_kuan' => $wab_div_kuan,
            'huifu_peizhi' => array(
                'width' => $huifu_peizhi['width'],
                'placeholder' => $this->iconvs($huifu_peizhi['placeholder']),
                'submit' => $this->iconvs($huifu_peizhi['submit']),
                'fabucg' => $this->iconvs($huifu_peizhi['fabucg']),
                'zhnkai' => $huifu_peizhi['zhnkai'],
            )
        );

        // 缓存配置，缓存css
        if($QC['huancun_peizhi'] == 1){
            $QC['huancun']['html'] = $peizhis;
            save_syscache('luoboc_danmu', $QC['huancun']);
            $this->xieru_css($style, $wap);
        }
        $zhonduan = $wap ? 'wap' : 'pc';
        return array('style' => $style, $zhonduan.'peizhi' => $peizhis);
    }
    
    public function iconvs($str){
        global $_G;
        if($_G['charset'] == 'gbk'){
            $str = iconv("GB2312", "UTF-8//IGNORE", $str);
        }
        return $str;
    }

    public function intvals($arr){
        $fanhui = array();
        foreach($arr as $k => $v){
            $fanhui[] = intval($v);
        }
        return $fanhui;
    }

    public function xieru_css($css, $wap){
        if($wap){
            $myfile = fopen("./source/plugin/luoboc_danmu/static/wap.css", "w+") or die("Unable to open file!");
        }else{
            $myfile = fopen("./source/plugin/luoboc_danmu/template/extend_module.css", "w+") or die("Unable to open file!");
            $css = <<<EOF
/** forum::viewthread,group::viewthread **/
$css
/** end **/
EOF;
        }
        fwrite($myfile, $css);
        fclose($myfile);
    }

    public function fenge($str){
        $arr = explode('|', $str);
        if(count($arr) > 1){
            $str = $arr[0].';'.$arr[1];
        }
        return $str;
    }
}