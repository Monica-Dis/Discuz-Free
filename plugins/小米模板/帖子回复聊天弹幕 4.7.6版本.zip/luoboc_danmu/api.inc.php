<?php 
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || $_GET['formhash'] != FORMHASH) {
    exit('Access Denied!');
}
if (!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
if(isset($_G['cache']['plugin']['luoboc_danmu'])){
    $QC = $_G['cache']['plugin']['luoboc_danmu'];
}else{
    exit('{"error": "No plug-ins configured"}');
}

require_once libfile('function/discuzcode');

$tid = intval($_GET['tid']);
$page = intval($_GET['page']) + 1;
$allreplies = intval($_GET['allreplies']);
$changdu = empty($QC['changdu']) ? 48 : intval($QC['changdu']);
$hang_limit = intval($QC['hang']) > 3 ? intval($QC['hang']) * 3 : 10;
$limit = $page * $hang_limit;
$postarr = array();

// 随机回复
if($QC['suiji'] == 1){
    $pid = intval($_GET['pid']);

    if(empty($pid)){
        $rand = rands();
    }else{
        $rand = $pid;
    }
    $postarr = chaxun_rand($rand, $hang_limit);
    
    if($postarr && !empty($postarr[count($postarr) -1]['pid'])){
        $pid = intval($postarr[count($postarr) -1]['pid']);
    }

    if(intval($QC['suiji_zuida']) != 0 && $limit > intval($QC['suiji_zuida'])){
        $page = 0;
        $pid = 0;
    }

}else{
    if($allreplies > 0){
        $postarr = chaxun($tid, $limit);
    }
    // 回复少于设置，随机抽取
    if(!empty($QC['suiji_buquan']) && count($postarr) < $hang_limit){
        $shuliang = explode('|', $QC['suiji_buquan']);
        $xianzhi = true;
        if(!empty($shuliang[1]) && intval($shuliang[1]) <= $limit){
            $xianzhi = false;
        }
        if($xianzhi && $allreplies < intval($shuliang[0])){
            $rand = rands();
            $limit = $limit - $allreplies > $hang_limit - count($postarr) ? $hang_limit - count($postarr) : $limit - $allreplies;
            $postarrs = chaxun_rand($rand, $limit);
            if($postarrs){
                $postarr = array_merge($postarr, $postarrs);
            }
        }else{
            $page = 0;
        }

    }else{
        if(count($postarr) < $hang_limit){
            $page = 0;
        }
    }
}

$usre = array();
// 头像，彩色弹幕
if(!empty($QC['touxiang']) || !empty($QC['caise_kaiguan'])){
    $usre_id = $vip_yonghuzu = $touxiang = array();
    foreach($postarr as $k => $v){
        $usre_id[] = intval($v['authorid']);
    }
    if($usre_id){
        $usre_arr = DB::fetch_all('SELECT uid,avatarstatus,groupid FROM %t WHERE uid in (%i)', array('common_member', implode(',', $usre_id)));
    }
    if(!empty($QC['vip_yonghuzu'])){
        $vip_yonghuzu = unserialize($QC['vip_yonghuzu']);
    }
    if(!empty($QC['touxiang'])){
        $touxiang = unserialize($QC['touxiang']);
    }
    foreach($usre_arr as $k => $v){
        $arr = array();
        if(in_array($v['groupid'], $vip_yonghuzu)){
            $arr['vip'] = 1;
        }
        if(in_array($v['groupid'], $touxiang)){
            if($v['avatarstatus'] == 1 || !empty($QC['touxiang_moren'])){
                $arr['avtm'] = 1;
            }
        }
        if($arr){
            $arr['gid'] = $v['groupid'];
            $usre[$v['uid']] = $arr;
        }
    }
}

foreach($postarr as $k => $v){
    $postarr[$k]['message'] = cutstr(preg_replace('/\[.*?\]|<.*?>|\n/', '', $postarr[$k]['message']), $changdu, '');
    if($QC['biaoqing'] == 1){
        $postarr[$k]['message'] = parsesmiles($postarr[$k]['message']);
    }
    if($usre && !empty($usre[$v['authorid']])){
        $postarr[$k] = array_merge($postarr[$k], $usre[$v['authorid']]);
    }
    if($_G['charset'] == 'gbk'){
        $postarr[$k]['message'] = diconv($postarr[$k]['message'], 'gbk', 'UTF-8');
    }
}

$arr = array('count' => count($postarr), 'page' => $page, 'tid' => $tid, 'content' => $postarr);
if($pid){
    $arr['pid'] = $pid;
}
echo json_encode($arr);
exit();


function chaxun($tid, $limit){
    global $hang_limit;
    return DB::fetch_all('SELECT pid,message,authorid FROM %t WHERE tid = %d AND position > 1 limit %d,%d', array('forum_post', $tid, $limit - $hang_limit, $hang_limit));
}

function chaxun_rand($rand, $limit){
    return DB::fetch_all('SELECT pid,message,authorid FROM %t WHERE pid > %d AND position > 1 limit %d,%d', array('forum_post', $rand, 0, $limit));
}

function rands(){
    $count = C::t('forum_post')->count();
    return rand(1, intval($count));
}