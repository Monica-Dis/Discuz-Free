<?php 
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied!');
}
$luoboc_urls = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=luoboc_danmu&pmod=huifu';
$luoboc_url = '?' . $luoboc_urls;

if(empty($_G['cache']['luoboc_danmu'])){
    loadcache('luoboc_danmu');
}
$QC['huancun'] = $_G['cache']['luoboc_danmu'];

if($_GET['formhash'] == FORMHASH && !empty($_GET['gx'])){
    $huifu = daddslashes($_GET['huifu']);
    $huifu['kai'] = intval($huifu['kai']);
    $huifu['zhongduan'] = dintval($huifu['zhongduan'], true);
    $huifu['yonghuzu'] = dintval($huifu['yonghuzu'], true);
    $huifu['bankuai'] = dintval($huifu['bankuai'], true);
    $huifu['pcinput_kuan'] = intval($huifu['pcinput_kuan']);
    $huifu['wapinput_kuan'] = intval($huifu['wapinput_kuan']);

    $html = $QC['huancun']['html'];
    $QC['huancun']['huifu'] = $huifu;
    $QC['huancun']['html'] = $html;

    save_syscache('luoboc_danmu', $QC['huancun']);
    cpmsg("luoboc_danmu:gengxin_cg", $luoboc_urls, "succeed");
}

$huifu = dhtmlspecialchars($QC['huancun']['huifu']);
$zhongduan = duoxuan($huifu['zhongduan']);
$optgroups = optgroupss($huifu['yonghuzu']);
$forumlists = forumlists($huifu['bankuai']);
include template('luoboc_danmu:huifu');

// 开启类型
function duoxuan($value){
    $value = is_array($value) ? $value : array();
    $type = '<option value="1">'.dhtmlspecialchars(lang('plugin/luoboc_danmu', 'huifu_zhongduan1')).'</option>'."\n".'<option value="2">'.dhtmlspecialchars(lang('plugin/luoboc_danmu', 'huifu_zhongduan2')).'</option>';
    foreach($value as $v) {
        $v = intval($v);
        $type = str_replace('<option value="'.$v.'">', '<option value="'.$v.'" selected>', $type);
    }
    return $type;
}

// 用户组多选
function optgroupss($user=array()){
    global $lang;
    $query = C::t('common_usergroup')->fetch_all_not(0, true);
    $usergroupid = isset($user) && is_array($user) ? $user : array();
    $groupselect = array();
	foreach($query as $group) {
        $group = dhtmlspecialchars($group);
		$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
		$groupselect[$group['type']] .= "<option value=\"$group[groupid]\" ".(in_array($group['groupid'], $usergroupid) ? 'selected' : '').">$group[grouptitle]</option>\n";
	}
	$groupselect = '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
		($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
		($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
		'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup>';
    return '<select name="huifu[yonghuzu][]" multiple="multiple" size="10">'.$groupselect.'</select>';
}

// 板块多选
function forumlists($value){
    $value = is_array($value) ? $value : array();
    require_once libfile('function/forumlist');
    $type = '<select name="huifu[bankuai][]" size="10" multiple="multiple"><option value="">'.cplang('plugins_empty').'</option>'.forumselect(FALSE, 0, 0, TRUE).'</select>';
    foreach($value as $v) {
        $v = intval($v);
        $type = str_replace('<option value="'.$v.'">', '<option value="'.$v.'" selected>', $type);
    }
    return $type;
}