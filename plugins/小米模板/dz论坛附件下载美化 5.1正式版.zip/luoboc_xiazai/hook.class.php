<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied!');
}

class luoboc_xiazai_base {

    public $QC = array();
    public $config = false;
    
    public function peizhi(){
        global $_G;
        if(empty($_G['cache']['plugin']['luoboc_xiazai'])){
            loadcache('plugin');
        }
        $this->QC = $_G['cache']['plugin']['luoboc_xiazai'];

        loadcache('luoboc_xiazai');
        if(empty($_G['cache']['luoboc_xiazai'])){
            $_G['cache']['luoboc_xiazai'] = array();
        }
        $this->QC['huancun'] = $_G['cache']['luoboc_xiazai'];
        if(!empty($this->QC['huancun']['text'])){
            $this->QC['huancun']['text'] = dhtmlspecialchars($this->QC['huancun']['text']);
        }else{
            $this->QC['huancun']['text'] = array();
        }

        $this->QC['yonghu'] = $this->QC['yonghu'] ? unserialize($this->QC['yonghu']) : array();
        $this->QC['bankuai'] = $this->QC['bankuai'] ? unserialize($this->QC['bankuai']) : array();
        $this->QC['name_changdu'] = $this->QC['name_changdu'] ? intval($this->QC['name_changdu']) : 36;
        if($this->QC['vip']){
            $this->QC['vip_yonghu'] = $this->QC['vip_yonghu'] ? unserialize($this->QC['vip_yonghu']) : array();
            $this->QC['vip_bankuai'] = $this->QC['vip_bankuai'] ? unserialize($this->QC['vip_bankuai']) : array();
            $this->QC['is_vip'] = in_array($_G['groupid'], $this->QC['vip_yonghu']) || $_G['groupid'] == 1;
            $this->QC['is_vip_bankuai'] = in_array($_G['fid'], $this->QC['vip_bankuai']);
            $this->QC['vip'] = $this->QC['is_vip_bankuai'] || $_G['groupid'] == 1 ? true : false;
        }else{
            $this->QC['is_vip'] = $this->QC['is_vip_qx'] = $this->QC['is_vip_bankuai'] = false;
        }
        $this->config = true;
    }

    // 加载内容
    public function html($wap = false){
        if($_GET['mod'] != 'viewthread'){
            return '';
        }
        global $_G, $postlist, $postarr, $post;
        if(!$this->config){
            $this->peizhi();
        }
        if(!in_array($_G['groupid'], $this->QC['yonghu']) || !in_array($_G['fid'], $this->QC['bankuai'])){
            return '';
        }
        $postarrs = reset($postarr);

        if(empty($postarrs) || empty($postarrs['position']) || ($postarrs['position'] != 1 && $_G['page'] > 1)){
            return '';
        }
        $message = $postarrs['message'];
        // 查找附件
        $msglower = strtolower($message);
        $pid = $postarrs['pid'];
        if(strpos($msglower, '[/hide]') !== FALSE && $pid) {
            $message = $this->messages($message, $pid, $msglower);
        }
        preg_match_all('/\[attach[\]](\d+)\[\/attach\]/', $message, $sids);
        $on_attachlist = ($this->QC['on_attachlist'] == 2 || $this->QC['on_attachlist'] == 3) && (!empty($post[$pid]["attachlist"]) || !empty($postlist[$pid]["attachlist"]));

        if(!empty($sids[1]) || $on_attachlist){
            $sid = !empty($sids[1]) ? $sids[1] : array();
            if($_GET['inajax'] == 1){
                if($on_attachlist){
                    if($this->QC['on_attachlist'] == 3){
                        $sid = array_merge($sid, $post[$pid]["attachlist"]);
                    }
                    $postlist[$pid]["attachlist"] = array();
                    $post[$pid]["attachlist"] = array();
                }
                if($sid){
                    $html = $this->htmls($post, $post, $sid, $wap, 1);
                    if(is_array($html)){
                        $post = $html['post'];
                        $post['message'] .= $html['html'];
                    }
                }
            }else{
                $post_list = $postlist[$pid];
                if($on_attachlist){
                    if($this->QC['on_attachlist'] == 3){
                        $sid = array_merge($sid, $postlist[$pid]["attachlist"]);
                    }
                    $post_list["attachlist"] = $postlist[$pid]["attachlist"] = array();
                    $post["attachlist"] = array();
                }
                if($sid){
                    $html = $this->htmls($postarrs, $post_list, $sid, $wap);
                    if(is_array($html)){
                        $postlist[$pid] = $html['post'];
                        if(!$wap || $this->QC['wap_body']){
                            $postlist[$pid]['message'] .= $html['html'];
                            return '';
                        }
                        return $html['html'];
                    }
                }
            }
        }
        return '';
    }

    public function htmls($postarr, $post, $sids, $wap = false, $inajax = 0){
        global $_G;
        $grouptitle = empty($_G['cache']['usergroups'][$_G['groupid']]['grouptitle']) ? '' : $_G['cache']['usergroups'][$_G['groupid']]['grouptitle'];

        include_once template('luoboc_xiazai:moban');
        $pid = $postarr['pid'];
        $attachmentss = $post['attachments'];
        
        $tj = count($sids);
        $peizhi = $return_html = $sid_arr = $no_vip_down_arr = array();
        $js = $last = $no_vip_down = 0;

        foreach($sids as $k => $sid){
            $js ++;
            if(!in_array($sid, $sid_arr) && !empty($attachmentss[$sid])){
                if($tj == $js) $last = 1;
                $html = $this->download_url($attachmentss[$sid], $wap, $last);
                if($html){
                    // VIP 附件设置了下载权限
                    if($html['readperm'] && $this->QC['is_vip'] && $_G['group']['readaccess'] < $html['readperm']){
                        $no_vip_down += 1;
                    }
                    $return_html[] = $html;
                    $sid_arr[] = $sid;
                }
            }
        }
        if(!$return_html) return '';
        if($no_vip_down){
            if($no_vip_down == count($return_html)){
                $no_vip_down = 2;
            }else{
                $no_vip_down = 1;
            }
        }else{
            $no_vip_down = 0;
        }
        // 过滤附件html
        if($pid){
            $texts = 'luoboc_ignore_Js_op_brss' . mt_rand(1000, 99999);
            if($wap){
                $post['message'] = preg_replace('/(<div id="attach_.*?<\/div>)/is', $texts, $post['message']);
                $post['message'] = preg_replace('/([\s]*'.$texts.'[\s]*<br \/>|'.$texts.')/is', '', $post['message']);

            }else{
                preg_match_all('/(<ignore_js_op.*?<\/ignore_js_op>)/is', $post['message'], $message);

                $aimg = array();
                if(!empty($message[0])){
                    foreach($message[0] as $k => $v){
                        preg_match('/id="aimg_(\d+)"/is', $v, $attach_id);
                        if(!empty($attach_id[1])){
                            $aimg[$attach_id[1]] = $v;
                            $text = "[message_aimg]".$attach_id[1]."[/message_aimg]";
                        }
                        $post['message'] = preg_replace('/(<ignore_js_op.*?<\/ignore_js_op>[\s]*)/is', $text, $post['message'], 1);
                    }
                }
    
                foreach($aimg as $k =>$v){
                    $post['message'] = preg_replace('/(\[message_aimg\]'.$k.'\[\/message_aimg\])/is', $v, $post['message'], 1);
                }
                $post['message'] = preg_replace('/([\s]*'.$texts.'[\s]*<br \/>|'.$texts.'|\[message_aimg\]\d+\[\/message_aimg\])/is', '', $post['message']);
                if(strpos($post['message'], 'class="showhide"><h4>') !== false){
                    $post['message'] = preg_replace('/(<div class="showhide"><h4>.*?<\/h4>(\s+)<\/div><br \/>)/is', '', $post['message']);
                }
            }
        }

        $peizhi = array(
            'vip' => $this->QC['vip'],
            'is_vip_bankuai' => $this->QC['is_vip_bankuai'],
            'is_vip' => $this->QC['is_vip'],
            'no_vip_down' => $no_vip_down,
            'title' => $this->QC['biaoti_k'],
            'grouptitle' => $grouptitle,
            'vip_url' => dhtmlspecialchars($this->QC['vip_url']),
            'return_html' => $return_html,
            'text' => $this->QC['huancun']['text'],
            'from' => $_GET['from'],
            'extcredits'  => $_G['setting']['extcredits'][$_G['setting']['creditstransextra']['1']]['unit'] . $_G['setting']['extcredits'][$_G['setting']['creditstransextra']['1']]['title'],
        );

         // 不是vip下载时提示
        if($this->QC['vip'] && $this->QC['is_vip_bankuai'] && !$this->QC['is_vip']){

            $peizhi['group'] = $this->text('group');
            $peizhi['novip'] = $this->text('novip');
            $peizhi['grouptitle'] = $grouptitle;
            $peizhi['vip_url'] = dhtmlspecialchars($this->QC['vip_url']);
            $peizhi['novip_url'] = $this->text('novip_url');
        }

        $html = '';
        $zhonduan = $wap ? 'wap' : 'pc';
        if($this->QC['huancun_peizhi'] == 1){
            if(empty($this->QC['huancun'][$zhonduan.'huancun'])){
                $html = '<style>'.$this->css($wap).'</style>';
            }

        }else{
            $html = '<style>'.$this->css($wap).'</style>';
        }

        $peizhi['html'] = $html;
        $return_html = html_html($peizhi);
        return array(
            'html' => $html.$return_html,
            'post' => $post,
        );
    }

    // 附件隐藏处理
    public function messages($message, $pid, $msglower){

        global $_G, $authorreplyexist, $pdateline, $authorid;

        @include_once DISCUZ_ROOT.'./source/discuz_version.php';
        $version_arr = array('x2.5', 'x3.0', 'x3.1', 'x3.2');
        $version = strtolower(DISCUZ_VERSION);

        if($_G['setting']['hideexpiration'] && $pdateline && (TIMESTAMP - $pdateline) / 86400 > $_G['setting']['hideexpiration']) {
            $message = preg_replace("/\[hide[=]?(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/is", "\\3", $message);
            $msglower = strtolower($message);
        }

        if(strpos($msglower, '[hide=d') !== FALSE) {
            if(in_array($version, $version_arr)){
                $message = preg_replace("/\[hide=(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/ies", "expirehide('\\1','\\2','\\3', $pdateline)", $message);
            }else{
                $message = preg_replace_callback("/\[hide=(d\d+)?[,]?(\d+)?\]\s*(.*?)\s*\[\/hide\]/is", create_function('$matches', 'return expirehide($matches[1], $matches[2], $matches[3], '.intval($pdateline).');'), $message);
            }

            $msglower = strtolower($message);
        }

        if(strpos($msglower, '[hide]') !== FALSE) {
            if($authorreplyexist === null) {
                if(!$_G['forum']['ismoderator']) {
                    if($_G['uid']) {
                        $_post = C::t('forum_post')->fetch('tid:'.$_G['tid'], $pid);
                        $authorreplyexist = $_post['tid'] == $_G['tid'] ? C::t('forum_post')->fetch_pid_by_tid_authorid($_G['tid'], $_G['uid']) : false;
                    }
                } else {
                    $authorreplyexist = true;
                }
            }
            if(!$authorreplyexist){
                $message = preg_replace('/\[hide.*?\[\/hide\]/', '', $message);
            }
        }

        if(strpos($msglower, '[hide=') !== FALSE) {
            if(in_array($version, $version_arr)){
                $message = preg_replace("/\[hide=(\d+)\]\s*(.*?)\s*\[\/hide\]/ies", "creditshide(\\1,'\\2', $pid, $authorid)", $message);
            }else{
                $message = preg_replace_callback("/\[hide=(\d+)\]\s*(.*?)\s*\[\/hide\]/is", create_function('$matches', 'return creditshide($matches[1], $matches[2], '.intval($pid).', '.intval($authorid).');'), $message);
            }

        }
        return $message;
    }

    // css加载
    public function css($wap){
        global $_G;
        $peizhi = array(
            'zitis' => $this->QC['zitis'],
            'biaoti' => $this->QC['biaoti_k'],
            'biaoti_bj' => $this->QC['biaoti_bj'],
            'biaoti_wz' => $this->QC['biaoti_wz'],
            'biaoti_bianju' => $this->fenge($this->QC['biaoti_bianju']),
            'bianju' => $this->fenge($this->QC['bianju']),
            'gaoliang' => $this->QC['gaoliang'],
            'beijing' => $this->QC['beijing'],
            'css' => $this->QC['css'],
            'fengge' => $this->QC['fengge'],
            'url' => $_G['siteroot'] == '/' ? $_G['siteurl'] : $_G['siteurl'] . preg_replace('/^\//', '', $_G['siteroot']),
        );

        if($this->QC['biaoti_k']){
            $biaoti_top = 20;
        }else{
            $biaoti_top = 0;
        }

        $peizhi['bianjus'] = $peizhi['bianju_yj'] = $peizhi['biaoti_bianjus'] = $peizhi['fengge2_title'] = '';
        if($this->QC['bianju']){
            $peizhi['bianjus'] = 'border:'.$peizhi['bianju']['px'].'px solid '.$peizhi['bianju']['se'].';';
            $peizhi['bianju_yj'] = 'border-radius:'.$peizhi['bianju']['yj'].';';
            $peizhi['fengge1_xiazai'] = 'padding:'. $biaoti_top .'px 10px 10px';
        }else{
            $peizhi['fengge1_xiazai'] = 'padding:20px 0';
        }

        if($this->QC['biaoti_bianju']){
            $peizhi['biaoti_bianjus'] = 'border:'.$peizhi['biaoti_bianju']['px'].'px solid '.$peizhi['biaoti_bianju']['se'].';border-radius:'.$peizhi['biaoti_bianju']['yj'].';';
            if($this->QC['fengge'] == 2) {
                $px = intval($peizhi['biaoti_bianju']['px']);
                $peizhi['fengge1_xiazai'] = 'padding:0 10px 10px';
                $peizhi['fengge2_title'] = 'margin-left:-'. ($px + 10) .'px;margin-right:-'. ($px + 10) .'px;';
            }
            
        }
    
        $styles = $styles_wap = '';

        if($wap){

            $peizhi['fengge'] = $this->QC['fengge_wap'] ? $this->QC['fengge_wap'] : 1;
            $peizhi['wap_body']  = $this->QC['wap_body'];
            $styles_wap = html_wap_css($peizhi);
        }

        $styles = html_fengge_css($peizhi);

        $style = html_common_css($peizhi);
        $style .= $styles . $styles_wap . $peizhi['css'];

        if($this->QC['huancun_peizhi'] == 1){
            $zhonduan = $wap ? 'wap' : 'pc';
            $this->QC['huancun'][$zhonduan."huancun"] = 1;
            save_syscache('luoboc_xiazai', $this->QC['huancun']);
            $this->xieru_css($style, $wap);
        }
        return dhtmlspecialchars($style);
    }

    // 缓存配置
    public function xieru_css($css, $wap){
        if($wap){
            $file = "./source/plugin/luoboc_xiazai/static/wap.css";
        }else{
            $file = "./source/plugin/luoboc_xiazai/template/extend_common.css";
            $css = <<<EOF
/** forum::viewthread,group::viewthread **/
$css
/** end **/
EOF;
        }
        $myfile = fopen($file, "w+") or die("Unable to open file!");
        fwrite($myfile, $css);
        fclose($myfile);
    }

    public function fenge($str){
        $arr = explode('|', $str);
        if(count($arr) > 0){
            $str = array(
                'px' => $arr[0],
                'se' => '',
                'yj' => '0px'
            );
            if(count($arr) > 1){
                $str['se'] = $arr[1];
            }
            if(count($arr) > 2){
                $str['yj'] = $arr[2] . 'px';
            }
        }
        return $str;
    }

    // 格式
    public function geshi($ext){

        if(preg_match("/zip|rar|arj|arc|cab|lzh|lha|tar|gz/", $ext)) {
			return 3;
		} elseif(preg_match("/mp4|avi|flv|rmvb|mov|3gp|f4v|mpg|swf|m3u8/", $ext)) {
            return 8;
        } elseif(preg_match("/ppt|doc|dot|wpt|wps/", $ext)) {
            return 5;
        } elseif(preg_match("/xls/", $ext)) {
            return 14;
        } elseif(preg_match("/ppt|pot|pps/", $ext)) {
            return 15;
        } elseif(preg_match("/js|css|htm/", $ext)) {
            return 7;
        } elseif(preg_match("/mp3|wma|mpeg|wmv|aac|cda|flac|ape/", $ext)) {
            return 9;
        } elseif(preg_match("/bmp|webp|tif/", $ext)) {
            return 11;
        } elseif(preg_match("/exe|msi|com|bat|dll/", $ext)) {
            return 2;
        } elseif(preg_match("/fon|fon|woff|eot/", $ext)) {
            return 2;
        }
        return 0;
    }

    // 自定义格式图标
    public function zdy_icos(){
        $tubiao = explode("\n", $this->QC['tubiao']);
        $this->QC['tubiao_s'] = array();
        foreach($tubiao as $k => $v){
            $vs = explode("|", $v);
            if(count($vs) > 1){
                $this->QC['tubiao_s'][$vs[0]] = $vs[1];
            }
        }
    }

    public function icos($ext){

        $img_dir = 'source/plugin/luoboc_xiazai/static/imgea/';

        // 优先自定义图标
        if($this->QC['tubiao']){
            if(!$this->QC['tubiao_s']){
                $this->zdy_icos();
            }
            if(!empty($this->QC['tubiao_s'][$ext])){
                return $img_dir . $this->QC['tubiao_s'][$ext];
            }
        }

        $arr = array('bak', 'dbf', 'pcd', 'sch', 'chm', 'iso', 'torrent', 'txt', 'apk', 'ipa');
        if(in_array($ext, $arr)){
            return  $img_dir . $ext . '.png';
        }

        $typeid = $this->geshi($ext);

        if(!$typeid) {
            $typeid = attachtype($ext."\t", 'id');
        }

        $icos = array(
            0 => 'weizhi',
            1 => 'weizhi',
            2 => 'exe',
            3 => 'zip',
            4 => 'zip',
            5 => 'word',
            6 => 'txt',
            7 => 'html',
            8 => 'mp4',
            9 => 'mp3',
            10 => 'mp4',
            11 => 'img',
            12 => 'pdf',
            13 => 'torrent',
            14 => 'excel',
            15 => 'ppt',
        );

        if(empty($icos[$typeid])){
            $typeid = 0;
        }
        return $img_dir . $icos[$typeid] . '.png';
    }

    public function text($key){
        return empty($this->QC['huancun']['text'][$key]) ? '' : $this->QC['huancun']['text'][$key];
    }

    // 拼凑下载地址
    public function download_url($attach, $wap, $last = 0){
        global $_G;
        $return_arr = array();
        if(!$attach['attachimg']) { 
            $return_arr = array(
                'aid' => $attach['aid'],
                'price' => $attach['price'],
                'payed' => $attach['payed'],
                'tid' => $attach['tid'],
                'filename' => $attach['filename'],
                'filenames' => cutstr($attach['filename'], $this->QC['name_changdu']),
                'dateline' => strpos($attach['dateline'], 'span') > 0 ? $attach['dateline'] : '<span>'.$attach['dateline'].'</span>',
                'ext_img' => $this->icos($attach['ext']),
                'ext' => $attach['ext'],
                'last' => $last ? 'luoboc_xiazai_on' : '',
                'ctrlid' => $_GET['from'] != 'preview' && !$wap,
                'attachsize' => $attach['attachsize'],
                'downloads' => $attach['downloads'],
                'readperm' => $attach['readperm'],
                'readperms' => $_G['group']['readaccess'] >= $attach['readperm'],
            );

            $is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G['forum_thread']['archiveid'] : '';

            if($this->QC['vip'] && $this->QC['is_vip_bankuai'] && !$this->QC['is_vip']){
                $url = 'javascript:;" onclick="luoboc_xiazai_novip_tishi()';
            }else{
                if(!$attach['price'] || $attach['payed']) {
                    $aidencode = packaids($attach);
                    $url = 'forum.php?mod=attachment'.$is_archive.'&amp;aid=' . $aidencode;
                } else { 
                    $url = 'forum.php?mod=misc&amp;action=attachpay&amp;aid='.$attach['aid'].'&amp;tid='.$attach['tid'].'';
                    if(!$wap){
                        $url .= '" onclick="showWindow(\'attachpay\', this.href)';
                    }
                }
            }
            $return_arr['url'] = $url;

        }
        return $return_arr;
    }

    // 不登录也显示附件下载列表
    public function display($wap = false){
        global $_G;
        if($_G['uid']){
            return '';
        }
        if(!$this->config){
            $this->peizhi();
        }
        if(in_array($_G['groupid'], $this->QC['yonghu'])){
            $_G['group']['allowgetattach'] = 1;
        }
        
        // 插件嵌入点位置移动
        if($wap && $this->QC['hook_paixu'] && !empty($_G['setting']['hookscript']['forum']['viewthread']['outputfuncs']['viewthread_postbottom'])){
            $viewthread_postbottom = $_G['setting']['hookscript']['forum']['viewthread']['outputfuncs']['viewthread_postbottom'];

            foreach($viewthread_postbottom as $k => $v){
                if($v[0] == 'luoboc_xiazai'){

                    $hook_paixu = str_split($this->QC['hook_paixu']);
                    if(count($hook_paixu) == 2){
                        switch ($hook_paixu[0]){
                        case '+':
                            $wizhi = $k - intval($hook_paixu[1]);
                            break;
                        case '-':
                            $wizhi = $k + intval($hook_paixu[1]);
                            break;
                        default:
                            $wizhi = $k - intval($hook_paixu[1]);
                        }
                    }else{
                        $wizhi = $k;
                    }

                    unset($viewthread_postbottom[$k]);
                    array_splice($viewthread_postbottom, $wizhi, 0, array($v));
                }
            }
            $_G['setting']['hookscript']['forum']['viewthread']['outputfuncs']['viewthread_postbottom'] = $viewthread_postbottom;
        }
        return '';
    }
} 


class plugin_luoboc_xiazai extends luoboc_xiazai_base {
}


class plugin_luoboc_xiazai_forum extends plugin_luoboc_xiazai {
    public function viewthread_top(){
        $this->display();
        return array();
    }

    public function viewthread_postbottom_output(){
        return array(0 => $this->html());
    }
}

class mobileplugin_luoboc_xiazai_forum extends plugin_luoboc_xiazai {

    public function viewthread_top_mobile(){
        $this->display(true);
        return array();
    }

    public function viewthread_postbottom_mobile_output(){
        return array(0 => $this->html(true));
    }
}
//From: di'.'sm.t'.'aoba'.'o.com
?>