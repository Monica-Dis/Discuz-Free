<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('discuz_version');
define('DSA_RENAMES', DISCUZ_ROOT . './source/plugin/dsa_renames/');

if (empty($_library) || !is_object($_library)) {
	$_library = new plugin_dsa_renames_library;
}

class plugin_dsa_renames_library {

	private $config = array();

	public function __construct() {
		global $_G;
		loadcache('plugin');
		$this->config = (array) $_G['cache']['plugin']['dsa_renames'];
		$this->minmax();
		$this->config['groups'] = array_filter(dunserialize($this->config['groups']));
	}

	public function getConfig() {
		return $this->config;
	}

	public function getUserbyuid($uid, $field = '*', $fetch_archive = 0) {
		$user = getuserbyuid($uid, $fetch_archive);
		if ($field === '*') {
			return $user;
		}
		return $user[$field];
	}

	public function getUsercredit($uid, $type = 'all') {
		$query = C::t('common_member_count')->fetch($uid);
		$credit = array(
			'1' => $query['extcredits1'],
			'2' => $query['extcredits2'],
			'3' => $query['extcredits3'],
			'4' => $query['extcredits4'],
			'5' => $query['extcredits5'],
			'6' => $query['extcredits6'],
			'7' => $query['extcredits7'],
			'8' => $query['extcredits8']
		);
		if ($type === 'all') {
			return $credit;
		}
		return $credit[$type] ? $credit[$type] : 0;
	}

	public function getIpfrom($ip) {
		require_once libfile('function/misc');
		$data = str_replace('- ', '', convertip($ip));
		if ($data == '' || $data == 'LAN' || $data == 'Invalid IP Address' || $data == 'Invalid IP data file' || $data == 'System Error' || $data == 'Unknown') {
			$data = lang('plugin/dsa_renames', 'lib_getipfrom_1');
		}
		return $data;
	}

	public function getGrouppermission() {
		if (is_array($this->config['groups']) && count($this->config['groups']) > 0) {
			return in_array(getGlobal('groupid'), $this->config['groups']);
		}
		return true;
	}

	public function getRenamelog() {
		$uid = getGlobal('uid');
		$data = $uid ? C::t('#dsa_renames#dsa_renameslog')->fetch_first_by_uid($uid) : array();
		$data['allowday'] = 1;
		if ($data['dateline'] && TIMESTAMP < $data['dateline'] + $this->config['days'] * 86400) {
			$data['allowday'] = 0;
		}
		return $data;
	}

	public function curl($url, $post = array(), $cookie = array(), $timeout = 15) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		if (!empty($post)) {
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post, 'curl_query_', '&'));
		}
		if (!empty($cookie)) {
			curl_setopt($ch, CURLOPT_COOKIE, http_build_query($cookie, '', ';'));
		}
		$result = curl_exec($ch);
		if ($errno = curl_errno($ch)) {
			$result = curl_error($ch);
		}
		curl_close($ch);
		return array($errno, $result);
	}

	public function splicesql($oldname, $newname) {
		$sql = array();
		$tables = @include (DSA_RENAMES . './data/tables.php');
		// UCenter
		if (!empty($tables['uc'])) {
			$uc = $this->tablepre(true);
			foreach ($tables['uc'] as $key => $value) {
				if ($key && $value) {
					$sql[] = "UPDATE {$uc}{$key} SET " . DB::field($value, $newname) . " WHERE " . DB::field($value, $oldname);
				}
			}
		}
		// Discuz!
		if (!empty($tables['dz'])) {
			$dz = $this->tablepre();
			// Sub table
			$query = DB::query("SHOW TABLE STATUS LIKE '{$dz}forum_%'");
			while ($value = DB::fetch($query)) {
				if (preg_match("/^{$dz}forum_post_\d+$|^{$dz}forum_thread_\d+$/i", $value['Name'])) {
					$value['Name'] = str_replace($dz, '', $value['Name']);
					if (strpos($value['Name'], 'forum_thread') === false) {
						$tables['dz'][$value['Name']] = 'author';
					} else {
						$tables['dz'][$value['Name']] = 'author|lastposter';
					}
				}
			}
			// Custom
			$other = @include (DSA_RENAMES . './data/other.php');
			if (!empty($other)) {
				foreach ($other as $key => $value) {
					if ($key && $value) {
						$tables['dz'][$key] = $value;
					}
				}
			}
			foreach ($tables['dz'] as $key => $value) {
				if ($key && $value) {
					$value = array_filter(explode('|', $value));
					foreach ($value as $field) {
						$sql[] = "UPDATE {$dz}{$key} SET " . DB::field($field, $newname) . " WHERE " . DB::field($field, $oldname);
					}
				}
			}
		}
		return $sql;
	}

	public function getgpc($keys, $method = 'GP', $chv = true) {
		if (empty($keys)) return '';
		if (is_array($keys)) {
			$data = array();
			foreach ($keys as $key => $value) {
				$data[$key] = $this->getgpc($value, $method);
			}
			return $data;
		}
		return $this->chv(getgpc($keys, $method), $chv);
	}

	public function alltable() {
		$alltable = @include (DSA_RENAMES . './data/alltable.php');
		return $alltable;
	}

	public function tablefield($name) {
		$query = DB::query("SHOW COLUMNS FROM `{$name}`");
		$field = array();
		while ($value = DB::fetch($query)) {
			$field[] = $value['Field'];
		}
		return $field;
	}

	public function tablepre($uc = false) {
		if ($uc) {
			if (!defined('UC_DBTABLEPRE')) {
				loaducenter();
			}
			$tablepre = UC_DBTABLEPRE;
		} else {
			$db = DB::object();
			$tablepre = $db->tablepre;
		}
		return $tablepre;
	}

	public function show($message, $url_forward = '', $values = array(), $extraparam = array(), $custom = 0) {
		if ($_GET['inajax']) {
			$vars = explode(':', $message);
			if (count($vars) == 2) {
				$show_message = lang('plugin/' . $vars[0], $vars[1], $values);
			} else {
				$show_message = lang('message', $message, $values);
			}
			echo $show_message;
			exit;
		}
		showmessage($message, $url_forward, $values, $extraparam, $custom);	
	}

	public function write($data, $path = '') {
		return $this->writeover($path, "<?php\r\n!defined('IN_DISCUZ') && exit('Access Denied');\r\n//Do not modify this file, please!\r\nreturn " . $this->exportvar($data) . ";\r\n?>");
	}

	public function chv($string, $encode = false) {
		if (empty($string)) return '';
		if (is_array($string)) {
			$data = array();
			foreach ($string as $key => $value) {
				$data[$key] = $this->chv($value, $encode);
			}
			return $data;
		}
		$search = array('"',"'",'..',')','<','=');
		$replace = array('&quot;','&#039;','&#46;&#46;','&#41;','&#60;','&#61;');
		return $encode ? str_ireplace($search, $replace, $string) : str_ireplace($replace, $search, $string);
	}

	public function slashes($string, $encode = true) {
		if (empty($string)) return '';
		if (is_array($string)) {
			$data = array();
			foreach ($string as $key => $value) {
				$data[$key] = $this->slashes($value, $encode);
			}
			return $data;
		}
		return $encode ? addslashes($string) : stripslashes($string);
	}

	private function writeover($fileName, $data, $method = 'rb+', $ifLock = true, $ifChmod = true) {
		touch($fileName);
		$handle = fopen($fileName, $method);
		$ifLock && flock($handle, LOCK_EX);
		$writeCheck = fwrite($handle, $data);
		$method == 'rb+' && ftruncate($handle, strlen($data));
		fclose($handle);
		$ifChmod && @chmod($fileName, 0777);
		return $writeCheck;
	}

	private function exportvar($input, $indent = '') {
		switch (gettype($input)) {
			case 'string' :
				return "'" . str_replace(array("\\", "'"), array("\\\\", "\'"), $input) . "'";
			case 'array' :
				$output = "array(\r\n";
				foreach ($input as $key => $value) {
					$output .= $indent . "\t" . $this->exportvar($key, $indent . "\t") . ' => ' . $this->exportvar($value, $indent . "\t");
					$output .= ",\r\n";
				}
				$output .= $indent . ')';
				return $output;
			case 'boolean' :
				return $input ? 'true' : 'false';
			case 'NULL' :
				return 'NULL';
			case 'integer' :
			case 'double' :
			case 'float' :
				return "'" . (string) $input . "'";
		}
		return 'NULL';
	}

	private function minmax() {
		$min = intval($this->config['length_min']);
		$max = intval($this->config['length_max']);
		if (!is_numeric($min) || $min < 3 || $min > 15) {
			$min = 3;
		}
		if (!is_numeric($max) || $max < 3 || $max > 15) {
			$max = 15;
		}
		if ($min > $max) {
			$min = 3;
			$max = 15;
		}
		$this->config['length_min'] = $min;
		$this->config['length_max'] = $max;
	}
}
