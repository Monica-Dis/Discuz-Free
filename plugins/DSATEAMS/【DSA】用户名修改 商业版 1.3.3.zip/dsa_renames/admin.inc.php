<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once (DISCUZ_ROOT . './source/plugin/dsa_renames/require/lib.class.php');

$_basemod = 'admin';
$_formurl = "plugins&operation=config&do={$pluginid}&identifier=dsa_renames&pmod={$_basemod}";
$_jumpurl = "action={$_formurl}";
$_baseurl = ADMINSCRIPT . '?' . $_jumpurl;

$tablepre = $_library->tablepre();
$alltable = $_library->alltable();
if (!submitcheck('dosubmit')) {
	$query = DB::query("SHOW TABLE STATUS LIKE '{$tablepre}%'");
	$tables = array();
	while ($value = DB::fetch($query)) {
		$key = str_replace($tablepre, '', $value['Name']);
		if ($value['Name'] != '' && !in_array($key, $alltable) && $value['Name'] != $tablepre . 'dsa_renameslog' && !preg_match("/^{$tablepre}forum_post_\d+$|^{$tablepre}forum_thread_\d+$/i", $value['Name'])) {
			$tables[] = array(
				'key' => $key,
				'name' => $value['Name'],
				'field' => $_library->tablefield($value['Name'])
			);
		}
	}
	$conf = @include (DSA_RENAMES . './data/other.php');
	include template('dsa_renames:admin');
} else {
	$config = $_library->getgpc('config', 'P');
	if (empty($config)) {
		$config = array();
	}
	foreach ($config as $key => $value) {
		$value = array_filter(explode('|', $value));
		if (empty($value)) {
			$config[$key] = '';
			continue;
		}
		$config[$key] = implode('|', $value);
		$tablename = $tablepre . $key;
		$field = $_library->tablefield($tablename);
		foreach ($value as $setfield) {
			if (!in_array($setfield, $field)) {
				cpmsg('dsa_renames:admin_setting_failed_1', $_jumpurl, 'error', array('tablename' => $tablename, 'setfield' => $setfield));
			}
		}
	}
	if ($_library->write($config, DSA_RENAMES . './data/other.php')) {
		cpmsg('dsa_renames:admin_setting_success', $_jumpurl, 'succeed');
	}
	cpmsg_error('dsa_renames:admin_setting_failed_2');
}
