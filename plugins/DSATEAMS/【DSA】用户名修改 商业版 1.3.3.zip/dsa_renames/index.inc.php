<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/dsa_renames/require/lib.class.php';

$basename = 'home.php?mod=spacecp&ac=plugin&op=profile&id=dsa_renames:index';
$_rename = $_library->getConfig();
$_isallowuse = $_library->getGrouppermission();
$_renamelogs = $_library->getRenamelog();
$_extcredits = $_G['setting']['extcredits'];
$_rename['money'] = (int) $_rename['money'];
$_rename['freetime'] = (int) $_rename['freetime'];
$currtime = C::t('#dsa_renames#dsa_renameslog')->count_by_uid($_G['uid']) + 1;
$isAppbyme = stripos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false ? true : false;
$isMagappx = stripos($_SERVER['HTTP_USER_AGENT'], 'Magappx') !== false ? true : false;
$isInapp = $isAppbyme || $isMagappx;

if (submitcheck('dosubmit')) {
	$newname = trim($_library->getgpc('newname', 'P', false));
	if (empty($newname)) {
		$_library->show('dsa_renames:index_newname_empty');
	}
	if ($_G['username'] == $newname) {
		$_library->show('dsa_renames:index_newname_sames');
	}
	$newnamelen = dstrlen($newname);
	if ($newnamelen < $_rename['length_min']) {
		$_library->show('dsa_renames:index_newname_short', '', array('length' => $_rename['length_min']));
	} elseif ($newnamelen > $_rename['length_max']) {
		$_library->show('dsa_renames:index_newname_long', '', array('length' => $_rename['length_max']));
	}
	loaducenter();
	$ucresult = uc_user_checkname($newname);
	if ($ucresult == -1) {
		$_library->show('dsa_renames:index_newname_sensitive');
	} elseif ($ucresult == -2) {
		$_library->show('dsa_renames:index_newname_shield');
	} elseif ($ucresult == -3) {
		if (C::t('common_member')->fetch_by_username($newname) || C::t('common_member_archive')->fetch_by_username($newname)) {
			$_library->show('dsa_renames:index_newname_reged');
		} else {
			$_library->show('dsa_renames:index_newname_exist');
		}
	}
	$censorexp = '/^(' . str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
	if ($_G['setting']['censoruser'] && @preg_match($censorexp, $newname)) {
		$_library->show('dsa_renames:index_newname_shield');
	}
	if (!$_isallowuse) {
		$_library->show('dsa_renames:index_group_banned');
	}
	if (!$_renamelogs['allowday']) {
		$_library->show('dsa_renames:index_interval_days', '', array('days' => $_rename['days'], 'lasttime' => dgmdate($_renamelogs['dateline'], 'Y-m-d H:i:s')));
	}
	if ($currtime >= $_rename['freetime'] && $_rename['money'] > 0 && $_rename['credit']) {
		if ($_library->getUsercredit($_G['uid'], $_rename['credit']) < $_rename['money']) {
			$_library->show('dsa_renames:index_price_message', '', array(
				'money'  => $_rename['money'],
				'credit' => $_extcredits[$_rename['credit']]['title']
			));
		}
		$creditlog = array(
			'title'   => lang('plugin/dsa_renames', 'index_modify_username_1'),
			'content' => lang('plugin/dsa_renames', 'index_modify_username_2')
		);
		updatemembercount($_G['uid'], array(
			$_rename['credit'] => -$_rename['money']
		), true, '', 0, $creditlog['title'], $creditlog['title'], $creditlog['content']);
	}
	C::t('#dsa_renames#dsa_renameslog')->insert(array(
		'uid'      => $_G['uid'],
		'oldname'  => $_G['username'],
		'newname'  => $newname,
		'clientip' => $_G['clientip'],
		'dateline' => TIMESTAMP
	));
	$sqls = $_library->splicesql($oldname = $_G['username'], $newname);
	if ($sqls) {
		foreach ($sqls as $sql) {
			DB::query($sql);
		}
	}
	if (C::memory()->enable) {
		C::memory()->clear();
	}
	$newmember = C::t('common_member')->fetch($_G['uid']);
	if ($newmember['username'] != $newname) {
		C::t('common_member')->clear_cache($_G['uid']);
		C::t('common_member_status')->clear_cache($_G['uid']);
		C::t('common_member_count')->clear_cache($_G['uid']);
		C::t('common_member_profile')->clear_cache($_G['uid']);
		C::t('common_member_field_home')->clear_cache($_G['uid']);
		C::t('common_member_field_forum')->clear_cache($_G['uid']);
		C::t('home_follow')->clear_cache($_G['uid']);
	}
	if ($_rename['apptype'] == 2 && !empty($_rename['magurl']) && !empty($_rename['magsecret'])) {
		$_rename['magurl'] = rtrim($_rename['magurl'], '/');
		$_library->curl($_rename['magurl'] . '/mag/open/api/updateUserName', array(
			'user_id' => $_G['uid'],
			'secret'  => $_rename['magsecret']
		));
		if (!empty($_rename['mag_ass_open']) && !empty($_rename['mag_ass_content'])) {
			$assistantMsg = str_replace(array('#newname#', '#oldname#'), array($newname, $oldname), $_rename['mag_ass_content']);
			$_library->curl($_rename['magurl'] . '/mag/operative/v1/assistant/sendAssistantMsg', array(
				'user_id'          => $_G['uid'],
				'type'             => 'remind',
				'content'          => diconv($assistantMsg, CHARSET, 'UTF-8'),
				'assistant_secret' => $_rename['mag_ass_secret'],
				'secret'           => $_rename['magsecret'],
				'is_push'          => 1
			));
		}
	}
	if ($_GET['inajax']) {
		echo 'index_modify_success';
		exit;
	}
	$_library->show('dsa_renames:index_modify_success', $basename, array(), array('showmsg' => true, 'alert' => 'right'));
}
else {
	if (empty($_rename['onlyapp']) || $isInapp) {
		$page = (int) $_library->getgpc('page');
		$error_credit = $error_allowday = '';
		if ($currtime >= $_rename['freetime']) {
			if ($_rename['money'] > 0 && $_rename['credit'] && $_library->getUsercredit($_G['uid'], $_rename['credit']) < $_rename['money']) {
				$error_credit = lang('plugin/dsa_renames', 'index_price_message', array(
					'money'  => $_rename['money'],
					'credit' => $_extcredits[$_rename['credit']]['title']
				));
			}
		}
		if (!$_renamelogs['allowday']) {
			$error_allowday = lang('plugin/dsa_renames', 'index_interval_days', array(
				'days'     => $_rename['days'],
				'lasttime' => dgmdate($_renamelogs['dateline'], 'Y-m-d H:i:s')
			));
		}
		$scriptlang = lang('plugin/dsa_renames', 'index_modify_success');
		$sqladd = DB::field('uid', $_G['uid']) . ' ORDER BY `dateline` DESC';
		list($pages, $query, $query_total) = C::t('#dsa_renames#dsa_renameslog')->fetch_all_by_paging($page, 10, $sqladd, $basename);
	} else {
		$down_title = lang('plugin/dsa_renames', 'index_down_title', array('appname' => $_rename['appname']));
		$down_qrcode = lang('plugin/dsa_renames', 'index_down_qrcode', array('appname' => $_rename['appname']));
		$down_button = lang('plugin/dsa_renames', 'index_down_button', array('appname' => $_rename['appname']));
	}
	$navtitle = $metakeywords = $metadescription = $_rename['title'] ? $_rename['title'] : lang('plugin/dsa_renames', 'index_navtitle');
	if (!defined('IN_MOBILE')) {
		$defaultop = '';
		$profilegroup = C::t('common_setting')->fetch('profilegroup', true);
		$operation = 'plugin';
	}
	include template('dsa_renames:index');
	dexit();
}
