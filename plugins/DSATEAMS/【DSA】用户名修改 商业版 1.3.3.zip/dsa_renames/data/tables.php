<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//Do not modify this file, please!
//Support X2.5 - X3.2

return array(
	'uc' => array(
		'members'          => 'username',
		'mergemembers'     => 'username',
		'protectedmembers' => 'username',
		'admins'           => 'username',
		'badwords'         => 'admin',
		'feeds'            => 'username'
	),
	'dz' => array(
		'common_member'              => 'username',
		'common_member_crime'        => 'operator',
		'common_member_security'     => 'username',
		'common_member_validate'     => 'admin',
		'common_member_verify_info'  => 'username',
		'common_adminnote'           => 'admin',
		'common_banned'              => 'admin',
		'common_block'               => 'username',
		'common_block_item'          => 'title',
		'common_block_item_data'     => 'title|username',
		'common_diy_data'            => 'username',
		'common_card_log'            => 'username',
		'common_failedlogin'         => 'username',
		'common_grouppm'             => 'author',
		'common_invite'              => 'fusername',
		'common_mytask'              => 'username',
		'common_report'              => 'username|opname',
		'common_session'             => 'username',
		'common_word'                => 'admin',
		'forum_activityapply'        => 'username',
		'forum_announcement'         => 'author',
		'forum_collection'           => 'username',
		'forum_collectioncomment'    => 'username',
		'forum_collectionfollow'     => 'username',
		'forum_collectionteamworker' => 'username',
		'forum_debate'               => 'umpire|bestdebater',
		'forum_forumrecommend'       => 'author',
		'forum_groupuser'            => 'username',
		'forum_order'                => 'buyer|admin',
		'forum_pollvoter'            => 'username',
		'forum_post'                 => 'author',
		'forum_postcomment'          => 'author',
		'forum_promotion'            => 'username',
		'forum_ratelog'              => 'username',
		'forum_rsscache'             => 'author',
		'forum_thread'               => 'author|lastposter',
		'forum_threadmod'            => 'username',
		'forum_trade'                => 'seller|lastbuyer',
		'forum_tradecomment'         => 'rater|ratee',
		'forum_tradelog'             => 'seller|buyer',
		'forum_warning'              => 'operator|author',
		'home_album'                 => 'username',
		'home_blog'                  => 'username',
		'home_clickuser'             => 'username',
		'home_comment'               => 'author',
		'home_docomment'             => 'username',
		'home_doing'                 => 'username',
		'home_feed'                  => 'username',
		'home_feed_app'              => 'username',
		'home_follow'                => 'username|fusername',
		'home_follow_feed'           => 'username',
		'home_follow_feed_archiver'  => 'username',
		'home_friend'                => 'fusername',
		'home_friend_request'        => 'fusername',
		'home_notification'          => 'author',
		'home_pic'                   => 'username',
		'home_poke'                  => 'fromusername',
		'home_share'                 => 'username',
		'home_show'                  => 'username',
		'home_specialuser'           => 'username|opusername',
		'home_visitor'               => 'vusername',
		'portal_article_title'       => 'username|author',
		'portal_category'            => 'username',
		'portal_comment'             => 'username',
		'portal_rsscache'            => 'author',
		'portal_topic'               => 'username',
		'portal_topic_pic'           => 'username'
	)
);
