<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$ac = getgpc('ac');
if (in_array($ac, array('checkusername'))) {
	require_once DISCUZ_ROOT . './source/plugin/dsa_renames/require/lib.class.php';
}

if ($ac == 'qrcode') {
	if ($url = urldecode(getgpc('url'))) {
		require_once DISCUZ_ROOT . './source/plugin/dsa_renames/require/qrcode.class.php';
		QRcode::png($url, false, QR_ECLEVEL_M, 5, 3, false);
	}
	exit;
}
elseif ($ac == 'checkusername') {
	$_rename = $_library->getConfig();
	$username = trim($_GET['username']);
	if (strtolower(CHARSET) == 'gbk') {
		$username = diconv($username, 'utf-8', CHARSET);
	}
	$usernamelen = dstrlen($username);
	if ($usernamelen < $_rename['length_min']) {
		showmessage('dsa_renames:index_newname_short', '', array('length' => $_rename['length_min']), array('handle' => false));
	} elseif ($usernamelen > $_rename['length_max']) {
		showmessage('dsa_renames:index_newname_long', '', array('length' => $_rename['length_max']), array('handle' => false));
	}
	loaducenter();
	$ucresult = uc_user_checkname($username);
	if ($ucresult == -1) {
		showmessage('profile_username_illegal', '', array(), array('handle' => false));
	} elseif ($ucresult == -2) {
		showmessage('profile_username_protect', '', array(), array('handle' => false));
	} elseif ($ucresult == -3) {
		if (C::t('common_member')->fetch_by_username($username) || C::t('common_member_archive')->fetch_by_username($username)) {
			showmessage('register_check_found', '', array(), array('handle' => false));
		} else {
			showmessage('register_activation', '', array(), array('handle' => false));
		}
	}
	$censorexp = '/^(' . str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
	if ($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
		showmessage('profile_username_protect', '', array(), array('handle' => false));
	}
	showmessage('succeed', '', array(), array('handle' => false));
}

if (!defined('IN_MOBILE')) {
	header('location: home.php?mod=spacecp&ac=plugin&op=profile&id=dsa_renames:index');
} else {
	header('location: home.php?mod=spacecp&ac=plugin&op=profile&id=dsa_renames:index&mobile=2');
}
exit;
