<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once (DISCUZ_ROOT . './source/plugin/dsa_renames/require/lib.class.php');

$_basemod = 'admin_log';
$_formurl = "plugins&operation=config&do={$pluginid}&identifier=dsa_renames&pmod={$_basemod}";
$_jumpurl = "action={$_formurl}";
$_baseurl = ADMINSCRIPT . '?' . $_jumpurl;

$q = $_library->getgpc('q');
if (empty($q)) {
	list($page, $uid, $username) = $_library->getgpc(array('page', 'uid', 'username'));
	$page = (int) $page;
	$sqladd = 1;
	$pageurl = "{$_baseurl}&a={$a}";
	if (submitcheck('dosubmit', 1)) {
		if (is_numeric($uid)) {
			$sqladd .= ' AND ' . DB::field('uid', $uid);
			$pageurl .= "&uid={$uid}";
		}
		if ($username) {
			$username = rawurldecode($username);
			$sqladd .= ' AND (' . DB::field('oldname', str_replace('*', '%', $username), 'like') . ' OR ' . DB::field('newname', str_replace('*', '%', $username), 'like') . ')';
			$pageurl .= '&username=' . rawurlencode($username);
		}
		$pageurl .= '&dosubmit=1&formhash=' . FORMHASH;
	}
	$sqladd .= ' ORDER BY `dateline` DESC';
	list($pages, $query, $query_total) = C::t('#dsa_renames#dsa_renameslog')->fetch_all_by_paging($page, 20, $sqladd, $pageurl);
	include template('dsa_renames:admin');
} elseif ($q == 'delete') {
	if (!submitcheck('delsubmit')) {
		cpmsg_error('Access Denied');
	}
	$delete = $_library->getgpc('delete');
	$eachnum = is_array($delete) ? count($delete) : 0;
	if ($eachnum) {
		C::t('#dsa_renames#dsa_renameslog')->delete($delete);
		cpmsg('dsa_renames:admin_delete_success', $_jumpurl, 'succeed', array('eachnum' => $eachnum));
	}
	cpmsg_error('dsa_renames:admin_delete_failed');
} else {
	cpmsg_error('Access Denied');
}
