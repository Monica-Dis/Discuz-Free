<?php
/**
 *	[�������(zxsq_code.{modulename})] (C)2013-2099 Powered by DisM!Ӧ�����ģ�dism.taobao.com.
 *	Version: v1.0
 *	Date: 2015-6-10
 **/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'function/code.php';

class plugin_zxsq_code {
	function checkflag() {
		global $_G;
		if(array_key_exists('zxsq_plugin_flags', $_G)) {
			if(in_array('zxsq_code', $_G['zxsq_plugin_flags']) || in_array('zxsq_markdown', $_G['zxsq_plugin_flags'])) {
				return True;
			}
		}
		return False;
	}

	function checkPortal() {
		global $_G;
		if($_G['cache']['plugin']['zxsq_code']['portal']) {
			return true;
		}
		return false;		
	}

	function global_header() {
		// ���������Դ�ļ�
		if(!$this->checkflag() && CURMODULE != 'view') {
			return "";
		}
		//�����������
		$code = new Highlight();
		$hilight = $code->header();

		//�������ʱ�Ų���ű�
		if(CURMODULE == 'viewthread') {
			return $hilight;
		}

		if(CURMODULE == 'view' && $this->checkPortal()) {
			return $hilight;
		}
		return "";
	}
	
	function setflag($item) {
		global $_G;
		if(array_key_exists("zxsq_plugin_flags", $_G)) {
			$zxsq_plugin_flags = $_G['zxsq_plugin_flags'];
		}else {
			$zxsq_plugin_flags = array();
		}
		$zxsq_plugin_flags[] = $item;
		setglobal("zxsq_plugin_flags", $zxsq_plugin_flags);
	}

	function discuzcode($param) {
		global $_G;
		//print_r($_G['discuzcodemessage']);	
		// ���������û�� tex �Ļ��򲻳�������ƥ��
		if (strpos($_G['discuzcodemessage'], '[/pre]') === false) {
			return false;
		}
		$this->setflag('zxsq_code');
		// ���ڽ���discuzcodeʱִ�ж� tex �Ľ���
		$pattern = '/\s?\[pre\][\n\r]*(.+?)[\n\r]*\[\/pre\]\s?/s';
		if($param['caller'] == 'discuzcode') {
			$_G['discuzcodemessage'] = preg_replace_callback($pattern, array($this,'optex'), $_G['discuzcodemessage']);
		} else {
			$_G['discuzcodemessage'] = preg_replace('/\[\/?pre\]/s', '', $_G['discuzcodemessage']);
		}
	}
	function optex($match) {
		$texcode = $match[1];
		$res = new Highlight();
		return $res->run($texcode);
	}
}


class plugin_zxsq_code_forum extends plugin_zxsq_code {
	//�ص��������滻<br />
	function delbr($match) {
		$match[2] = str_replace("<br />", "", $match[2]);
		$match[2] = str_replace("[zxsq-anti-bbcode-", "[", $match[2]);
		
		//$match[2] = preg_replace("#(<br />)?<br />([^<][^b][^r][^\s][^/][^>])?#m", "\\1", $match[2]);
		//�滻code�ж����&amp;
		if(substr($match[1], 0, 5) == "<code") {
			$match[2] = str_replace("&amp;", "&", $match[2]);
		}
		return $match[1] . $match[2] . $match[3];
	}	

	function viewthread_bottom_output() {
		global $postlist;
		$pattern = array();
		$pattern[] = '/(<code class=)(.+?)(<\/code>)/s';
		$pattern[] = '/(<code>)(.+?)(<\/code>)/s';
		foreach($postlist as $pid => $post) {
			for($i=0; $i<count($pattern); $i++) {
				$post['message'] = preg_replace_callback($pattern[$i],array($this,'delbr'),$post['message']);
			}
			$postlist[$pid] = $post;
		}
		return '';
	}

}

class plugin_zxsq_code_group extends plugin_zxsq_code_forum {
}

class mobileplugin_zxsq_code extends plugin_zxsq_code {
	function global_header_mobile() {
		return parent::global_header();
	}
}

class mobileplugin_zxsq_code_forum extends plugin_zxsq_code_forum {
}
