<?php
/**
 * Code HighLight 处理函数
 *
 * $Id: code.php  i@annhe.net  2015-6-18 $
 **/

if(!defined('IN_DISCUZ')) {
		exit('Access Denied');
}

class Highlight {
	function header() {
		global $_G;
		@extract($_G['cache']['plugin']['zxsq_code']);

		$jsdir = "highlight-10.7/";
		if($version == "old") {
			$jsdir = "highlight/";
		}
		$dir = "source/plugin/zxsq_code/tools/" . $jsdir;
		$css = $dir . "styles/";
		$js = $dir . "highlight.pack.js";

		if($hilightStyle=="") {
				$hilightStyle="far";
		}

		// 新版css名字变化
		if($version == "new") {
			$styles = array(
				"brown_paper" => "brown-paper",
				"darkula" => "darcula",
				"ir_black" => "ir-black",
				"monokai_sublime" => "monokai-sublime",
				"paraiso.dark" => "paraiso-dark",
				"paraiso.light" => "paraiso-light",
				"school_book" => "school-book",
				"solarized_dark" => "solarized-dark",
				"solarized_light" => "solarized-light",
			);
			if(substr($hilightStyle, 0, 7) == "atelier") $hilightStyle = str_replace(".", "-", $hilightStyle);
			if(array_key_exists($hilightStyle, $styles)) $hilightStyle = $styles[$hilightStyle];
		}

		$css = $css . $hilightStyle . ".css";

		// 自定义 highlight.js
		if($custom) {
			$css = $customcss;
			$js = $customjs;
		}

		$hilightcss = '<link rel="stylesheet" href="' . $css . '" />';
		$hilightcss .= '<link rel="stylesheet" href="source/plugin/zxsq_code/css/code.css" />';
		$hilightjs = '<script src="' . $js . '" charset="utf-8"></script>';


		$hilightrun = "<script>hljs.initHighlightingOnLoad();</script>";
		return $hilightcss . $hilightjs . $hilightrun;

	}
	
	function run($texcode) {
		global $_G;
		@extract($_G['cache']['plugin']['zxsq_code']);
		if($codeHeight<=0) {
			$codeHeight=4000;
		}
		$texcode = preg_replace('/\[((?!\/?attach)\w+?)\]/', "[zxsq-anti-bbcode-\${1}]", $texcode);
		include template('zxsq_code:code');
		return trim($code);
	}
}
