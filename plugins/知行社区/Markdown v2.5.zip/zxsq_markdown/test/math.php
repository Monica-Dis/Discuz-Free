<?php
/**
 * Usage:
 * File Name: test.php
 * Author: annhe  
 * Mail: dism_taobao_com
 * Created Time: 2020-07-19 15:46:36
 **/

define("IN_DISCUZ", 1);
require_once '../tools/parsedown/ExtParsedown.php';

$inline1 = '$f(x)=a \cdot x^2+b \cdot x+c$';

$block1 = <<<'EOF'
$$A=\begin{pmatrix}
a_{11} & a_{12} & a_{13} \\
0 & a_{22} & a_{23} \\
0 & 0 & a_{33}
\end{pmatrix}$$
EOF;

$script = '$<script>alert("1");</script>$';

$dollar = <<<'EOF'
今天花了 \\\$10, 明天 \\\$20

后天 $30
EOF;


$parse = new ExtParsedown();
$parse->setSafeMode(true);
$parse->setBreaksEnabled(true);

print_r($parse->text($inline1));
print("\n");
print_r($parse->text($block1));
print("\n");
print_r($parse->text($script));
print("\n");
print_r($parse->text($dollar));
print("\n");
