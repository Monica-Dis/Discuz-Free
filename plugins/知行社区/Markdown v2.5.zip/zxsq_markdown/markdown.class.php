<?php
/**
 *	[Markdown(zxsq_markdown.{modulename})] Copyright (c) 2021 by dism.taobao.com
 *	Version: v1.0
 *	Date: 2015-7-18 12:36
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'function/markdown.php';

class plugin_zxsq_markdown {
	private $postId = 1;
	function checkflag() {
		global $_G;
		if(array_key_exists('zxsq_plugin_flags', $_G)) {
			if(in_array('zxsq_markdown', $_G['zxsq_plugin_flags'])) {
				return True;
			}
		}
		return False;
	}
	
	function setflag($item) {
		global $_G;
		if(array_key_exists("zxsq_plugin_flags", $_G)) {
			$zxsq_plugin_flags = $_G['zxsq_plugin_flags'];
		}else {
			$zxsq_plugin_flags = array();
		}
		$zxsq_plugin_flags[] = $item;
		setglobal("zxsq_plugin_flags", $zxsq_plugin_flags);
	}

	function checkPortal() {
		global $_G;
		if($_G['cache']['plugin']['zxsq_markdown']['portal']) {
			return true;
		}
		return false;
	}

	function checkCodeTools() {
		global $_G;
		if($_G['cache']['plugin']['zxsq_markdown']['codeTools']) {
			return true;
		}
		return false;
	}

	function global_header() {
		// ���������Դ�ļ�
		if(!$this->checkflag() && CURMODULE != 'view') {
			return "";
		}

		//markdown css
		$markdown = new Markdown();
		$parsecss = $markdown->header();

		//�������ʱ�Ų���ű�
		if(CURMODULE == 'viewthread') {
			$sHeader = $parsecss;
			if($this->checkCodeTools()) {
				$lang = lang('plugin/zxsq_markdown');
				$sScript = '<div id="zxsq-markdown-code-tools" style="display:none"><span class="show">' . $lang['showcode'] . '</span>';
				$sScript .= '<span class="hide">' . $lang['hidecode'] . '</span>';
				$sScript .= '<span class="copy">' . $lang['copycode'] . '</span>';
				$sScript .= '<span class="copysucc">' . $lang['copysucc'] . '</span></div>';
				$sHeader .= $sScript;
			}
			return $sHeader;
		}


		if(CURMODULE == 'view' && $this->checkPortal()) {
			return $parsecss;
		}
		return "";
	}
	
	function global_footer() {
		global $_G;
		if(CURMODULE == 'view' && $this->checkPortal()) {
			return '<script src="source/plugin/zxsq_markdown/js/portal-markdown.js"></script>';
		}
		if(CURMODULE == 'viewthread' && $this->checkCodeTools() & $this->checkflag()) {
			return '<script src="source/plugin/zxsq_markdown/js/code-tools.js"></script>';
		}
		return "";
	}

	function discuzcode($param) {
		global $_G;
		//print_r($_G['discuzcodemessage']);	
		// ���������û�� tex �Ļ��򲻳�������ƥ��
		if (strpos($_G['discuzcodemessage'], '[/md]') === false || strpos($_G['discuzcodemessage'], '[nomd]') > -1) {
			return false;
		}
		$this->setflag('zxsq_markdown');
		
		// ���ڽ���discuzcodeʱִ�ж� tex �Ľ���
		$pattern = '/\s?\[md\][\n\r]*(.+?)[\n\r]*\[\/md\]\s?/s';
		if($param['caller'] == 'discuzcode') {
			$this->postId = $param['param'][12];
			$_G['discuzcodemessage'] = preg_replace_callback($pattern, array($this,'optex'), $_G['discuzcodemessage']);
		}
	}
	function optex($match) {
		$texcode = $match[1];
		$md = new Markdown();
		return $md->run($texcode, $this->postId);
	}
	
}


class plugin_zxsq_markdown_forum extends plugin_zxsq_markdown {
	//�ص��������滻<br />
	function delbr($match) {
		$match[2] = str_replace("<br /><br />", "<markdown-newline-br />", $match[2]);
		$match[2] = str_replace("<br />", "", $match[2]);
		$match[2] = str_replace("<markdown-newline-br />", "<br />", $match[2]);
		$match[2] = str_replace("[zxsq-anti-bbcode-", "[", $match[2]);
		
		//$match[2] = str_replace("[zxsq-anti-bbcode-", "[", $match[2]);
		//�滻code�ж����&amp;
		if(substr($match[1], 0, 5) == "<code") {
			$match[2] = str_replace("&amp;", "&", $match[2]);
		}
		// ֧��mermaid
		if($match[1] == '<pre><code class="mermaid">')
		{
			return '<div class="mermaid">' . str_replace("&amp;", "&", $match[2]) . '</div>';
		}
		return $match[1] . $match[2] . $match[3];
	}	

	function toc($pid, $collapseDepth) {
		if(intval($collapseDepth) < 0 || intval($collapseDepth) > 6 || $collapseDepth == "") {
			$collapseDepth = "0";
		}

		$script = "<script>" .
			"(function(){" .
			"var basePath = window.location.href.split('#')[0].split('/').pop();" .
			"tocbot.init({" . 
			"tocSelector: '#markdown_toc_" . $pid . "'," . 
			"contentSelector: '#postmessage_" . $pid . "'," .
			"headingSelector: 'h1, h2, h3'," .
			"collapseDepth: " . $collapseDepth . "," .
			"basePath: basePath" .
			//"ignoreSelector: '.attach_nopermission'," .
			//"smoothScroll: false," .
			"});" .
			"})();" .
			"</script>";
		return($script);
	}
	function viewthread_bottom_output() {
		global $postlist;
		global $_G;
		@extract($_G['cache']['plugin']['zxsq_markdown']);

		$pattern = array();
		$pattern[] = '|(parsedown-markdown")(.+?)(parsedown-markdown-end_FLAG_ZXSQ)|s';
		$pattern[] = '|(<pre><code class="mermaid">)(.+?)(</code></pre>)|s'; // ֧��mermaid
		foreach($postlist as $pid => $post) {
			for($i=0; $i<count($pattern); $i++) {
				$post['message'] = preg_replace_callback($pattern[$i],array($this,'delbr'),$post['message']);
				// ����ʾ[nomd]��ǩ
			}
			$post['message'] = str_replace("[nomd]", "", $post['message']);
			// $post['first'] Ϊ 1 ʱ�������������˴�ֻ����������Ŀ¼��һ��ҳ����Ŀ¼��������
			// Ref: https://github.com/tscanlin/tocbot/issues/186
			if(strpos($post['message'], "parsedown-markdown") > -1 && $toc && $post['first'])
			{
				$post['message'] .= $this->toc($pid, $collapseDepth);
			}
			$postlist[$pid] = $post;
		}
		return '';
	}

	function viewthread_sidebottom_output() {
		$ret = array();
		global $postlist;
		foreach($postlist as $pid => $post)
		{
			if($post['first']) {
				$ret[] = '<nav class="toc toc-side relative z-1 transition--300 absolute" id="markdown_toc_' . $pid . '"></nav>';
			}
		}
		return $ret;
	}

}

class plugin_zxsq_markdown_group extends plugin_zxsq_markdown_forum {
}

class mobileplugin_zxsq_markdown extends plugin_zxsq_markdown {
	function global_header_mobile() {
		return parent::global_header();
	}
}

class mobileplugin_zxsq_markdown_forum extends plugin_zxsq_markdown_forum {
}
