<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$Config = $_G['cache']['plugin']['fn_house_wx'];
if($_GET['ac'] == 'openid'){
	$Url = 'https://api.weixin.qq.com/sns/jscode2session?appid='.$Config['min_appid'].'&secret='.$Config['min_app_secret'].'&js_code='.$_GET['code'].'&grant_type=authorization_code';
	$Res = dfsockopen($Url);
	echo $Res ? $Res : file_get_contents($Url);
	exit();
}else if($_GET['ac'] == 'pay'){
	@require_once("source/plugin/fn_pay/class/FnPay.Class.php");
	$PayId = intval($_GET['order_id']);
	if(!$PayId){
		exit('No PayId');
	}

	$FnPay->UpdatePay($PayId,array('paytype'=>'min_wx'));//����֧������
	$PayFirst = $FnPay->GetPayFirst($PayId);//��ȡ֧������
	$PayIdTime = $PayId.'_'.time();
	$Subject = $FnPay->IconvGbkUtf($PayFirst['title']);//�ַ���ת��

	@require_once("source/plugin/fn_pay/class/WxPay.Class.php");

	$WxPay = new WxPay($Config['min_appid'],$Config['min_app_secret'],$Config['min_key'],$Config['min_mchid']);
	$UnifiedOrderParameters = $WxPay->GetUnifiedOrderParameters($PayIdTime,$Subject,$PayFirst['money'],'JSAPI',$_GET['openid']);
	$JsApiParameters = $WxPay->GetJsApiParameters($UnifiedOrderParameters);
	echo json_encode($JsApiParameters);
	exit();
}
//From: Dism_taobao_com
?>