<?php
/**
 *	[������ͬ�Ƿ���(fn_house.{modulename})] (C)2016-2099 Powered by ��������.
 *	Version: 1.0
 *	Date: 2018-7-23 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_house/Function.inc.php');

$navtitle = $metakeywords = $metadescription = $Fn_House->Config['PluginVar']['Title'];

$_GET['m'] = $_GET['m'] ? $_GET['m'] : 'index';

$Mod = array('index','list','list_disc','list_article','view','view_disc','view_article','publish','user','user_info_list','user_info_list_log','user_info_list_collection','user_disc_list_collection','user_demand_list','admin_info_list','calculation','demand_list','entrust','list_entrust','store','user_agent_info','view_agent','buy_store_level','user_store_team','list_store','user_entrust_list','user_access_record_list','list_agent');

if(!in_array($_GET['m'],$Mod)){
	exit('No Data');
}

if(!$_G['uid'] && in_array($_GET['m'],array('publish','user','user_info_list','user_info_list_collection','user_disc_list_collection','user_info_list_log','user_demand_list','admin_info_list','entrust','user_agent_info','buy_store_level','user_store_team','user_entrust_list','user_access_record_list'))){
	Fn_Login();
}

$UserInfo = $_G['uid'] ? $Fn_House->GetUserInfo() : '';

$HomeSearchList = array_filter(explode(",",$Fn_House->Config['PluginVar']['HomeSearch']));

$Fn_House->Config['LangVar']['KXSZ'] = $_G['uid'] ? str_replace(array('{Discount}'),array($UserInfo['top_discount']),$Fn_House->Config['LangVar']['KXSZ']) : '';
$Fn_House->Config['LangVar']['OnlineServiceWxTips'] = str_replace(array('{wx}'),array($Fn_House->Config['PluginVar']['AppOnlineWx']),$Fn_House->Config['LangVar']['OnlineServiceWxTips']);

$Fn_House->Config['LangVar']['WalletBalance'] = str_replace(array('{wallet_title}'),array($Fn_House->Config['PluginVar']['WalletTitle']),$Fn_House->Config['LangVar']['WalletBalance']);
$Fn_House->Config['LangVar']['Currency'] = str_replace(array('{wallet_title}'),array($Fn_House->Config['PluginVar']['WalletTitle']),$Fn_House->Config['LangVar']['Currency']);

if(!checkmobile()){//���԰�
	
	//��ʱ��ά��
	@require_once libfile('class/qrcode','plugin/fn_assembly');
	$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
	if(!file_exists($File) || !filesize($File)) {
		QRcode::png($Fn_House->Config['Url'], $File, QR_ECLEVEL_L,5,2);
	}
	$AddQrCode = base64_encode(file_get_contents($File));
	@unlink($File);

	if(!file_exists($File) || !filesize($File)) {
		QRcode::png($Fn_House->Config['UserAgentInfoUrl'], $File, QR_ECLEVEL_L,5,2);
	}
	$AgentQrCode = base64_encode(file_get_contents($File));
	@unlink($File);
	//��ʱ��ά��End

	if(in_array($_GET['m'],array('demand_list','list_agent','view_agent','list_store','store','entrust')) || !$Fn_House->Config['PluginVar']['PcQrSwitch']){

		if(!file_exists($File) || !filesize($File)) {
			QRcode::png($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"], $File, QR_ECLEVEL_L,5,2);
		}
		$QrCode = base64_encode(file_get_contents($File));
		@unlink($File);

		include template('fn_house:index_qrcode');
		exit();
	}
}

if($_GET['m'] == 'index'){//��ҳ
	
	if(!checkmobile()){//���԰�
		$Fn_House->Config['PluginVar']['IndexTemplet'] = 'index';
		$PcHomeSeo = array_filter(explode("#",$Fn_House->Config['PluginVar']['PcHomeSeo']));
		$PcFriendLink = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['PcFriendLink']));
		
		$navtitle = $PcHomeSeo[0] ? $PcHomeSeo[0] : $navtitle;
		$metakeywords = $PcHomeSeo[1] ? $PcHomeSeo[1] : $navtitle;
		$metadescription = $PcHomeSeo[2] ? $PcHomeSeo[2] : $navtitle;
		
		$DiscIndexList = $Fn_House->GetDiscIndexList(array('limit'=>$Fn_House->Config['PluginVar']['PcIndexDiscNum']));

		//¥����Ѷ
		if($Fn_House->Config['PluginVar']['PcHomeArticle']){
			$SlideArticleList = $Fn_House->GetAjaxArticleList(array('limit'=>$Fn_House->Config['PluginVar']['PcArticleSlideNum'],'display'=>1,'slide'=>1));
			$HotArticleList = $Fn_House->GetAjaxArticleList(array('limit'=>1,'display'=>1,'hot'=>1));
			$ArticleList = $Fn_House->GetAjaxArticleList(array('limit'=>8,'display'=>1));
		}
		
	}else{

		$DiscIndexList = $Fn_House->GetDiscIndexList(array('limit'=>$Fn_House->Config['PluginVar']['IndexDiscNum']));

		//¥����Ѷ
		$ArticleList = $Fn_House->Config['PluginVar']['HomeArticle'] ? $Fn_House->GetAjaxArticleList(array('limit'=>5,'display'=>1)) : '';

		$Banners = $Fn_House->Config['PluginVar']['banners'];

		$IndexNav = $Fn_House->Config['PluginVar']['navs'];

		$MinIndexNav = $Fn_House->Config['PluginVar']['min_nav'];
	}


	$Count = $Fn_House->Config['PluginVar']['HomeCountSwitch'] ? $Fn_House->GetIndexCount() : ''; //ͳ��

	$NoticeList = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['NoticeList']));
	
	$AgentUserList = $Fn_House->GetIndexAgentUserList();
	
	if($Fn_House->Config['PluginVar']['HomeAgentRenovationCompany'] && file_exists(DISCUZ_ROOT.'./source/plugin/fn_renovation/Function.inc.php')){
		@require_once (DISCUZ_ROOT .'./source/plugin/fn_renovation/Function.inc.php');
		$IndexCompanyHotList = $Fn_Renovation->GetIndexCompanyHotList();
	}


	if($Fn_House->Config['PluginVar']['IndexTemplet'] == 'index'){
		
		$InfoIndexTopList = $Fn_House->Config['PluginVar']['HomeInfoTopSwitch'] ? $Fn_House->GetInfoIndexTopList() : '';
	}

	$_GET['m'] = $Fn_House->Config['PluginVar']['IndexTemplet'];
	
}else if($_GET['m'] == 'list'){//�б�
	$_GET['class'] = in_array($_GET['class'],array(1,2,3,4,5,6,7)) ? $_GET['class'] : 1;

	if(mb_detect_encoding($_GET['keyword'],array('ASCII','UTF-8','GB2312','GBK','BIG5','EUC-CN')) != 'EUC-CN' || CHARSET != 'gbk'){
		$_GET['keyword'] = $_GET['keyword'] ? diconv($_GET['keyword'],mb_detect_encoding($_GET['keyword'], array('ASCII','UTF-8','GB2312','GBK','BIG5','EUC-CN')),CHARSET) : '';
	}

	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['IndexNav'][$_GET['class']];

	if(!checkmobile()){//���԰�
		$PcListSeo = TextareaArray($Fn_House->Config['PluginVar']['PcListSeo']);
		$SeoArray =  array_filter(explode("#",$PcListSeo[$_GET['class']]));
		$navtitle = $SeoArray[0] ? $SeoArray[0] : $navtitle;
		$metakeywords = $SeoArray[1] ? $SeoArray[1] : $navtitle;
		$metadescription = $SeoArray[2] ? $SeoArray[2] : $navtitle;

		$ListAd = TextareaArray($Fn_House->Config['PluginVar']['PcListHouseAd']);
		$ListAdArray =  array_filter(explode('#',$ListAd[$_GET['class']]));
		
	}

	$Fn_House->Config['WxShare']['WxUrl'] = $Fn_House->Config['ListUrl'].'&class='.$_GET['class'].'&keyword='.$_GET['keyword'];

}else if($_GET['m'] == 'view'){//����
	$Item = $Fn_House->GetViewthread($_GET['iid']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['title'].'_'.$Fn_House->Config['LangVar']['IndexNav'][$Item['class']];

		if(!checkmobile()){//���԰�
			$Seo = str_replace(array('{title}','{class}','{content}'),array($Item['title'],$Fn_House->Config['LangVar']['IndexNav'][$Item['class']],cutstr(strip_tags($Item['param']['content']),150)),explode("#",$Fn_House->Config['PluginVar']['PcViewSeo']));
			$navtitle = $Seo[0] ? $Seo[0] : $navtitle;
			$metakeywords = $Seo[1] ? $Seo[1] : $navtitle;
			$metadescription = $Seo[2] ? $Seo[2] : $navtitle;
		}

		if((!$Item['display'] || !$Item['payment_state']) && $Item['uid'] != $_G['uid'] && !$Fn_House->Admin){
			$Msg = $Fn_House->Config['LangVar']['HousingAudit'];
		}else if($Fn_House->Config['PluginVar']['ExpiryTime'] && $Item['updateline'] < strtotime("-".intval($Fn_House->Config['PluginVar']['ExpiryTime'])." day",time()) && $Item['topdateline'] < time() && !$Fn_House->Admin){
			$Msg = $Fn_House->Config['LangVar']['ExpiredTips'];
		}else{
			//if(!$Fn_House->GetUserInfoPayLogFirst($Item['id']) && !$Fn_House->Admin && $Item['uid'] != $_G['uid']){
			if(!$Fn_House->GetUserInfoPayLogFirst($Item['id'])){
				$SeeInfoMoney = TextareaArray($Fn_House->Config['PluginVar']['SeeInfoMoney']);
				$SeeInfoMoney = $SeeInfoMoney[$Item['class']];
				$AppSeeInfoMoney = TextareaArray($Fn_House->Config['PluginVar']['AppSeeInfoMoney']);
				$AppSeeInfoMoney = $AppSeeInfoMoney[$Item['class']];
				$PublishHint = AppYes ? str_replace(array('{money}','{br}'),array('<span class="ColorRed">'.$AppSeeInfoMoney.'</span>','<br>'),$Fn_House->Config['PluginVar']['SeeInfoMoneyTips']) : str_replace(array('{money}','{br}'),array('<span class="ColorRed">'.$SeeInfoMoney.'</span>','<br>'),$Fn_House->Config['PluginVar']['SeeInfoMoneyTips']);
				$AppPublishHint = str_replace(array('{money}','{br}','{AppMoney}','{Down}'),array('<span class="FFFFFColor">'.$SeeInfoMoney.'</span>','<br>','<span class="ColorRed">'.($AppSeeInfoMoney ? $AppSeeInfoMoney : $Fn_House->Config['LangVar']['MianFei']).'</span>','<a href="'.$Config['PluginVar']['AppLink'].'" class="ColorRed">'.$Fn_House->Config['LangVar']['Down'].'</a>'),$Fn_House->Config['PluginVar']['AppSeeInfoMoneyTips']);
				$SeeInfoMoney = AppYes && App ? $AppSeeInfoMoney : $SeeInfoMoney;
				if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php') && $SeeInfoMoney){//֧������
					@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
					$PayList = $FnPay->GetPayList();
					$PayTitle = $Fn_House->Config['LangVar']['InfoPayLogTitle'];
				}
			}

			$Item['mobile'] = $Fn_House->Config['PluginVar']['AgentViewTel'] && $Fn_House->Config['PluginVar']['OnlineMobile'] && $UserInfo['id'] && !$UserInfo['vip'] ? $Fn_House->Config['PluginVar']['OnlineMobile'] : $Item['mobile'];
			
			$VideoHtml = GetVideoHtml($Item['video_url'],$Item['param']['cover']);

			$ReportList = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['ReportList']));

			foreach (array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['NearbyMatching']))as $Key => $Val) {
				$NearbyMatching[$Key] = $Val;
				$NearbyMatchingJson[$Key] = urlencode($Val);
			}
			$NearbyMatchingJs = $NearbyMatchingJson ? urldecode(json_encode($NearbyMatchingJson)) : '';
			
			if(!$Item['param']['images']){
				unset($Item['param']['images']);
				$Item['param']['images'][] = $Fn_House->Config['PluginVar']['ViewCoverPath'];
			}

			$PreviewImage = json_encode($Item['param']['images']);//ͼƬ��

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_House->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_House->TableInfo,$Item['id'],$ClickNum);

			if($_G['uid']){
				//���������¼
				$Fn_House->InsertInfoLog($Item['id']);

				//�ҵ��ղ�
				$MyInfoCollectArray = $Fn_House->GetUserInfoCollectArray();
				if(in_array($Item['id'],$MyInfoCollectArray)){
					$MyCollect = true;
				}
			}
			
			$Fn_House->Config['LangVar']['NoWxTips'] = str_replace(array("{wx}"),array($Item['param']['wx']),$Fn_House->Config['LangVar']['NoWxTips']);
			
		}

		//���ַ��´�
		if(in_array($Item['class'],array(1)) && $Item['price']){
			$DownPayments = intval($Item['price'] * 0.3);
			$Loan = $Item['price'] - $DownPayments;
		}
		
		//��ά��
		if($Fn_House->Config['PluginVar']['QrParameterSwitch'] && checkmobile()){
	
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.intval($Item['id']).'.jpg';
			if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
				@unlink($File);
				@require_once libfile('class/wechat','plugin/fn_assembly');
				$WechatClient = new Fn_WeChatClient($Fn_House->Config['PluginVar']['WxAppid'], $Fn_House->Config['PluginVar']['WxSecret']);
				$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.$Item['id'],'expire'=>2592000)));
				DownloadImg($QrUrl,$File);
			}
			$QrCode = base64_encode(file_get_contents($File));

		}else{
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
			if(!file_exists($File) || !filesize($File)) {
				@require_once libfile('class/qrcode','plugin/fn_assembly');
				QRcode::png($Fn_House->Rewrite($_GET['m'],array('iid'=>$Item['id'])), $File, QR_ECLEVEL_L,5,2);
			}
			$QrCode = base64_encode(file_get_contents($File));
			@unlink($File);
		}
		
		//����
		if($Item['class'] == 2){
			$FclassArray = $Fn_House->Config['LangVar']['RentalTypeArray'];
		}else if($Item['class'] == 3){
			$FclassArray = $Fn_House->Config['LangVar']['ShopTypeArray'];
		}
		$Fn_House->Config['WxShare']['WxUrl'] = $Fn_House->Rewrite($_GET['m'],array('iid'=>$Item['id']));
		$Fn_House->Config['WxShare']['WxTitle'] = str_replace(array('{title}','{class}','{fclass}'),array($Item['title'],$Fn_House->Config['LangVar']['IndexNav'][$Item['class']],$FclassArray[$Item['vice_class']]),$Fn_House->Config['PluginVar']['ViewShareTitle']);
		$Fn_House->Config['WxShare']['WxImg'] = $Item['param']['cover'] ? (strpos($Item['param']['cover'],'http') !== false ? $Item['param']['cover'] : $_G['siteurl'].$Item['param']['cover']) : $Fn_House->Config['WxShare']['WxImg'];
		
	}else{
		$navtitle = $Msg = $Fn_House->Config['LangVar']['NoViewData'];
	}
}else if($_GET['m'] == 'demand_list'){//������
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['Demand'];
	$_GET['type'] = in_array($_GET['type'],array(1,2)) ? $_GET['type'] : 0;
	$TypeClass = array($_GET['type']=>'Hover');

	$Money = $Fn_House->Config['PluginVar']['DemandMoney'];
	$AppMoney = $Fn_House->Config['PluginVar']['DemandAppMoney'];

	$PublishHint = $AppMoney && AppYes ? str_replace(array('{Money}','{br}'),array('<span class="ColorRed">'.$AppMoney.'</span>','<br>'),$Fn_House->Config['PluginVar']['DemandMoneyTips']) : str_replace(array('{Money}','{br}'),array('<span class="ColorRed">'.$Money.'</span>','<br>'),$Fn_House->Config['PluginVar']['DemandMoneyTips']);
	
	$AppPublishHint = str_replace(array('{Money}','{br}','{AppMoney}','{Down}'),array('<span class="FFFFFColor">'.$Money.'</span>','<br>','<span class="ColorRed">'.$AppMoney.'</span>','<a href="'.$Config['PluginVar']['AppLink'].'" class="ColorRed">'.$Fn_House->Config['LangVar']['Down'].'</a>'),$Fn_House->Config['PluginVar']['AppDemandMoneyTips']);

	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
		$PayTitle = $Fn_House->Config['LangVar']['DemandPayLogTitle'];
	}

	$Fn_House->Config['WxShare']['WxUrl'] = $Fn_House->Config['DemandListUrl'];
	$Fn_House->Config['WxShare']['WxTitle'] = $Fn_House->Config['PluginVar']['DemandShareTitle'];
	$Fn_House->Config['WxShare']['WxDes'] = $Fn_House->Config['PluginVar']['DemandShareDesc'];

}else if($_GET['m'] == 'publish'){//����
	
	$_GET['class'] = in_array($_GET['class'],array(1,2,3,4,5,6,7,99)) ? $_GET['class'] : 1; 
	
	$DataArea = MobileSelectAreaJs($Fn_House->Area);
	
	$Fn_House->Config['PluginVar']['InterviewSwitch'] = in_array($_GET['class'],$Fn_House->Config['PluginVar']['InterviewSwitchs']) ? true : false;//����
	
	$DescTemplateList = TextareaArray($Fn_House->Config['PluginVar']['DescTemplate']);
	$DescTemplate =  array_filter(explode('|',$DescTemplateList[$_GET['class']]));

	if($_GET['class'] == 1){
		for($I = 1 ;$I < 101;$I++){
			$CountFloor[$I] = $Fn_House->Config['LangVar']['Gong'].$I.$Fn_House->Config['LangVar']['Floor'];
		}
		$HuXingData = MobileSelectJs($Fn_House->Config['LangVar']['RoomArray'],$Fn_House->Config['LangVar']['OfficeArray'],$Fn_House->Config['LangVar']['GuardArray']);
		$DecorationTypeData = $Fn_House->Config['PluginVar']['PublishOrientationSwitch'] ? MobileSelectJs($Fn_House->Config['LangVar']['DecorationArray'],$Fn_House->Config['LangVar']['OrientationArray']) : MobileSelectJs($Fn_House->Config['LangVar']['DecorationArray']);
		$FloorData = MobileSelectJs($Fn_House->Config['LangVar']['FloorArray'],$CountFloor,$Fn_House->Config['LangVar']['HouseTypeArray']);
		$TagArray = $Fn_House->Config['LangVar']['HouseTagArray'];
		
		$Price = $Fn_House->Config['LangVar']['Price'];
		$Company = $Fn_House->Config['LangVar']['WanYuan'];
		$Fn_House->Config['LangVar']['PricePlaceholder'] = $Fn_House->Config['LangVar']['PriceErr'];
		
		$Money = $Fn_House->Config['PluginVar']['HouseMoney'];
		$AppMoney = $Fn_House->Config['PluginVar']['HouseAppMoney'];
		$TopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['HouseTopMoney']));

	}else if($_GET['class'] == 2){
		$RentalTypeData = MobileSelectJs($Fn_House->Config['LangVar']['RentalTypeArray']);
		$HuXingData = MobileSelectJs($Fn_House->Config['LangVar']['RoomArray'],$Fn_House->Config['LangVar']['OfficeArray'],$Fn_House->Config['LangVar']['GuardArray']);
		$DecorationTypeData = $Fn_House->Config['PluginVar']['PublishOrientationSwitch'] ? MobileSelectJs($Fn_House->Config['LangVar']['DecorationArray'],$Fn_House->Config['LangVar']['HouseTypeArray'],$Fn_House->Config['LangVar']['OrientationArray']) : MobileSelectJs($Fn_House->Config['LangVar']['DecorationArray'],$Fn_House->Config['LangVar']['HouseTypeArray']);
		//$HouseTypeData = MobileSelectJs($Fn_House->Config['LangVar']['HouseTypeArray']);
		$PriceTimeData = MobileSelectJs($Fn_House->Config['LangVar']['RentTimeArray']);

		$TagArray = $Fn_House->Config['LangVar']['RentalHouseTagArray'];

		$_GET['vice_class'] = in_array($_GET['vice_class'],array(1,2,3)) ? $_GET['vice_class'] : 1; 
		
		$Price = $Fn_House->Config['LangVar']['Rent'];
		$Company = $Fn_House->Config['LangVar']['Yuan'].'/'.reset($Fn_House->Config['LangVar']['RentTimeArray']).'('.$Fn_House->Config['LangVar']['Optional'].')';
		$Fn_House->Config['LangVar']['PricePlaceholder'] = $Fn_House->Config['LangVar']['RentErr'];
		$PriceTime = key($Fn_House->Config['LangVar']['RentTimeArray']);

		$Money = $Fn_House->Config['PluginVar']['RentalMoney'];
		$AppMoney = $Fn_House->Config['PluginVar']['RentalAppMoney'];
		$TopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['RentalTopMoney']));

	}else if($_GET['class'] == 3){
		$TagArray = $Fn_House->Config['LangVar']['ShopTagArray'];

		$Fn_House->Config['LangVar']['HouseContent'] = $Fn_House->Config['LangVar']['ShopContent'];
		$Fn_House->Config['LangVar']['SmallAreaName'] = $Fn_House->Config['LangVar']['SmallAreaTo'];
		$Fn_House->Config['LangVar']['SmallAreaPlaceholder'] = $Fn_House->Config['LangVar']['SmallAreaPlaceholderTo'];
		
		$TypeData = MobileSelectJs($Fn_House->Config['LangVar']['ShopTypeArray']);
		$ManagementTpyeData = MobileSelectJs($Fn_House->Config['LangVar']['ManagementTpyeArray']);

		$ShopManagementTypeData = MobileSelectJs($Fn_House->Config['LangVar']['ShopManagementTypeArray']);

		$PriceTimeData = MobileSelectJs($Fn_House->Config['LangVar']['RentTimeArray']);

		$_GET['vice_class'] = in_array($_GET['vice_class'],array(1,2,3)) ? $_GET['vice_class'] : 1;

		$Price = $Fn_House->Config['LangVar']['Rent'];
		$Company = $Fn_House->Config['LangVar']['Yuan'].'/'.reset($Fn_House->Config['LangVar']['RentTimeArray']).'('.$Fn_House->Config['LangVar']['Optional'].')';

		$Fn_House->Config['LangVar']['PricePlaceholder'] = $Fn_House->Config['LangVar']['PricePlaceholderTo'];
		$PriceTime = key($Fn_House->Config['LangVar']['RentTimeArray']);

		$Money = $Fn_House->Config['PluginVar']['ShopMoney'];
		$AppMoney = $Fn_House->Config['PluginVar']['ShopAppMoney'];
		$TopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['ShopTopMoney']));

	}else if($_GET['class'] == 4){
		$TagArray = $Fn_House->Config['LangVar']['WorkShopTagArray'];

		$Fn_House->Config['LangVar']['HouseContent'] = $Fn_House->Config['LangVar']['WorkShopContent'];
		$Fn_House->Config['LangVar']['SmallAreaName'] = $Fn_House->Config['LangVar']['SmallAreaTo'];
		$Fn_House->Config['LangVar']['SmallAreaPlaceholder'] = $Fn_House->Config['LangVar']['SmallAreaPlaceholderTo'];
		
		$PriceTimeData = MobileSelectJs($Fn_House->Config['LangVar']['RentTimeArray']);

		$_GET['vice_class'] = in_array($_GET['vice_class'],array(1,2,3)) ? $_GET['vice_class'] : 1;

		$Price = $Fn_House->Config['LangVar']['Rent'];
		$Company = $Fn_House->Config['LangVar']['Yuan'].'/'.reset($Fn_House->Config['LangVar']['RentTimeArray']).'('.$Fn_House->Config['LangVar']['Optional'].')';

		$Fn_House->Config['LangVar']['PricePlaceholder'] = $Fn_House->Config['LangVar']['PricePlaceholderTo'];
		$PriceTime = key($Fn_House->Config['LangVar']['RentTimeArray']);

		$Money = $Fn_House->Config['PluginVar']['WorkShopMoney'];
		$AppMoney = $Fn_House->Config['PluginVar']['WorkShopAppMoney'];
		$TopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['WorkShopTopMoney']));

	}else if($_GET['class'] == 5){
		$TagArray = $Fn_House->Config['LangVar']['OfficeTagArray'];

		$Fn_House->Config['LangVar']['HouseContent'] = $Fn_House->Config['LangVar']['OfficeContent'];
		$Fn_House->Config['LangVar']['SmallAreaName'] = $Fn_House->Config['LangVar']['SmallAreaTo'];
		$Fn_House->Config['LangVar']['SmallAreaPlaceholder'] = $Fn_House->Config['LangVar']['SmallAreaPlaceholderTo'];
		
		$PriceTimeData = MobileSelectJs($Fn_House->Config['LangVar']['RentTimeArray']);

		$_GET['vice_class'] = in_array($_GET['vice_class'],array(1,2,3)) ? $_GET['vice_class'] : 1;

		$Price = $Fn_House->Config['LangVar']['Rent'];
		$Company = $Fn_House->Config['LangVar']['Yuan'].'/'.reset($Fn_House->Config['LangVar']['RentTimeArray']).'('.$Fn_House->Config['LangVar']['Optional'].')';

		$Fn_House->Config['LangVar']['PricePlaceholder'] = $Fn_House->Config['LangVar']['PricePlaceholderTo'];
		$PriceTime = key($Fn_House->Config['LangVar']['RentTimeArray']);

		$Money = $Fn_House->Config['PluginVar']['OfficeMoney'];
		$AppMoney = $Fn_House->Config['PluginVar']['OfficeAppMoney'];
		$TopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['OfficeTopMoney']));

	}else if($_GET['class'] == 6){
		$TagArray = $Fn_House->Config['LangVar']['WarehouseTagArray'];

		$Fn_House->Config['LangVar']['HouseContent'] = $Fn_House->Config['LangVar']['WarehouseContent'];
		$Fn_House->Config['LangVar']['SmallAreaName'] = $Fn_House->Config['LangVar']['SmallAreaTo'];
		$Fn_House->Config['LangVar']['SmallAreaPlaceholder'] = $Fn_House->Config['LangVar']['SmallAreaPlaceholderTo'];
		
		$PriceTimeData = MobileSelectJs($Fn_House->Config['LangVar']['RentTimeArray']);

		$_GET['vice_class'] = in_array($_GET['vice_class'],array(1,2,3)) ? $_GET['vice_class'] : 1;

		$Price = $Fn_House->Config['LangVar']['Rent'];
		$Company = $Fn_House->Config['LangVar']['Yuan'].'/'.reset($Fn_House->Config['LangVar']['RentTimeArray']).'('.$Fn_House->Config['LangVar']['Optional'].')';

		$Fn_House->Config['LangVar']['PricePlaceholder'] = $Fn_House->Config['LangVar']['PricePlaceholderTo'];
		$PriceTime = key($Fn_House->Config['LangVar']['RentTimeArray']);

		$Money = $Fn_House->Config['PluginVar']['WarehouseMoney'];
		$AppMoney = $Fn_House->Config['PluginVar']['WarehouseAppMoney'];
		$TopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['WarehouseTopMoney']));

	}else if($_GET['class'] == 7){
		$TagArray = $Fn_House->Config['LangVar']['LandTagArray'];

		$Fn_House->Config['LangVar']['HouseContent'] = $Fn_House->Config['LangVar']['LandContent'];
		$Fn_House->Config['LangVar']['SmallAreaName'] = $Fn_House->Config['LangVar']['SmallAreaTo'];
		$Fn_House->Config['LangVar']['SmallAreaPlaceholder'] = $Fn_House->Config['LangVar']['SmallAreaPlaceholderTo'];
		
		$PriceTimeData = MobileSelectJs($Fn_House->Config['LangVar']['RentTimeArray']);

		$_GET['vice_class'] = in_array($_GET['vice_class'],array(1,2,3)) ? $_GET['vice_class'] : 1;

		$Price = $Fn_House->Config['LangVar']['Rent'];
		$Company = $Fn_House->Config['LangVar']['Yuan'].'/'.reset($Fn_House->Config['LangVar']['RentTimeArray']).'('.$Fn_House->Config['LangVar']['Optional'].')';

		$Fn_House->Config['LangVar']['PricePlaceholder'] = $Fn_House->Config['LangVar']['PricePlaceholderTo'];
		$PriceTime = key($Fn_House->Config['LangVar']['RentTimeArray']);

		$Money = $Fn_House->Config['PluginVar']['LandMoney'];
		$AppMoney = $Fn_House->Config['PluginVar']['LandAppMoney'];
		$TopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['LandTopMoney']));

	}else if($_GET['class'] == 99){
		$_GET['vice_class'] = in_array($_GET['vice_class'],array(1,2)) ? $_GET['vice_class'] : 1;

	}

	//�༭
	if($Fn_House->Admin){
		$Item = $Fn_House->GetMyViewthread($_GET['class'],$_GET['iid'],'',true);
	}else if(($UserInfo['intermediary'] && $UserInfo['identity'] == 1)){
		$Item = $Fn_House->GetMyViewthread($_GET['class'],$_GET['iid'],' and agent_id = '.$UserInfo['agent_id'],true);
	}else{
		$Item = $Fn_House->GetMyViewthread($_GET['class'],$_GET['iid']);
	}
	
	/*if(!$Item){//�ŵ�Ȩ��
		if($UserInfo['agent_id'] && !$UserInfo['store_display']){
			$Msg = $Fn_House->Config['LangVar']['StoreErrArray'][1];
		}else if($UserInfo['agent_id'] && !$UserInfo['store_vip']){
			$GoVip = true;
			$Msg = $Fn_House->Config['LangVar']['StoreErrArray'][2];
		}
	}*/

	if(in_array($_G['uid'],$Fn_House->Config['PluginVar']['GlobalProhibitUis'])){
		$Msg = $Fn_House->Config['PluginVar']['GlobalProhibitUisTips'];
	}else if(in_array($_G['uid'],$Fn_House->Config['PluginVar']['ProhibitUis']) && !$UserInfo['vip']){//�����û�����
		$ProhibitUis = true;
		$Msg = $Fn_House->Config['PluginVar']['ProhibitUisTips'];
	}

	if($Fn_House->Config['PluginVar']['AgentVerifyAddSwitch'] && $Fn_House->Config['PluginVar']['AgentAuthenticationSwitch'] && $UserInfo['id'] && !$UserInfo['verify']){//��֤�ſɷ���
		$Msg = $Fn_House->Config['LangVar']['AgentVerifyAddErr'];
	}

	if($Item){
		$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['EditPublishTitle'].'-'.$Fn_House->Config['LangVar']['PublishNavArray'][$_GET['class']];

		$_GET['vice_class'] = $_GET['class'] != 99 ? $Item['vice_class'] : $Item['type'];
		$_GET['class'] = $_GET['class'] != 99 ? $Item['class'] : $_GET['class'];
		$Images = $Item['param']['images'] ? json_encode($Item['param']['images']) : '';
		$ItemConfigure = array_filter(explode(",",$Item['configure']));
		$ItemTag = array_filter(explode(",",$Item['tag']));
		$Fn_House->Config['LangVar']['PublishBtn'] = $Fn_House->Config['LangVar']['EditPublishBtn'];
		
		if(in_array($_GET['class'],array(3,4,5,6,7))){
			if($_GET['vice_class'] == 1){
				$Price = $Fn_House->Config['LangVar']['Rent'];
				$Company = $Fn_House->Config['LangVar']['Yuan'].'/'.reset($Fn_House->Config['LangVar']['RentTimeArray']).'('.$Fn_House->Config['LangVar']['Optional'].')';
			}else if($_GET['vice_class'] == 2){
				$Price = $Fn_House->Config['LangVar']['Price'];
				$Company = $Fn_House->Config['LangVar']['WanYuan'];
			}else if($_GET['vice_class'] == 3){
				$Price = $Fn_House->Config['LangVar']['TransferFee'];
				$Company = $Fn_House->Config['LangVar']['WanYuan'];
			}
		}
		
	}else{
		$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['PublishTitle'].'-'.$Fn_House->Config['LangVar']['PublishNavArray'][$_GET['class']];
	}

	$PublishHint = $AppMoney && AppYes ? str_replace(array('{Money}','{br}'),array('<span class="ColorRed">'.$AppMoney.'</span>','<br>'),$Fn_House->Config['PluginVar']['PublishHint']) : str_replace(array('{Money}','{br}'),array('<span class="ColorRed">'.$Money.'</span>','<br>'),$Fn_House->Config['PluginVar']['PublishHint']);
	
	$AppPublishHint = str_replace(array('{Money}','{br}','{AppMoney}','{Down}'),array('<span class="FFFFFColor">'.$Money.'</span>','<br>','<span class="ColorRed">'.($AppMoney ? $AppMoney : $Fn_House->Config['LangVar']['MianFei']).'</span>','<a href="'.$Config['PluginVar']['AppLink'].'" class="ColorRed">'.$Fn_House->Config['LangVar']['Down'].'</a>'),$Fn_House->Config['PluginVar']['AppPublishHint']);

	$Money = AppYes && App ? $AppMoney : $Money;

	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}

	$PayTitle = $Fn_House->Config['LangVar']['ListPublishe'].$Fn_House->Config['LangVar']['PublishNavArray'][$_GET['class']];

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

}else if($_GET['m'] == 'user'){//��Ա����
	
	if($UserInfo['vip'] || $UserInfo['due_time']){

		$navtitle = $metadescription = $metakeywords = $UserInfo['identity'] == 1 ? $Fn_House->Config['LangVar']['StoreUserTitle'] : $Fn_House->Config['LangVar']['AgentUserTitle'];

		if($UserInfo['identity'] == 1){//�곤
			$AgentItem = $Fn_House->GetAgentthread($UserInfo['agent_id']);
			//��Ƭ
			$ImgBgBase64 = base64_encode(file_get_contents('source/plugin/fn_house/static/images/store_card_bg.jpg'));
			//��ά��
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
			if(!file_exists($File) || !filesize($File)) {
				@require_once libfile('class/qrcode','plugin/fn_assembly');
				QRcode::png($Fn_House->Config['StoreJoinUrl'].$AgentItem['id'], $File, QR_ECLEVEL_L,5,2);
			}
			$QrCode = base64_encode(file_get_contents($File));
			@unlink($File);

			$CoverBase64 = base64_encode(dfsockopen(strpos($AgentItem['face'],'http') !== false ? $AgentItem['face'] : $_G['siteurl'].$AgentItem['face']));
			$CoverBase64 = $CoverBase64 ? $CoverBase64 : base64_encode(file_get_contents($AgentItem['face'],0,stream_context_create(array('http'=>array('timeout'=>1000)))));
			$CoverBase64 = $CoverBase64 ? $CoverBase64 : base64_encode(CurlGet(str_replace('https','http',$AgentItem['face'])));
			if($AgentItem['ico']){
				$IcoBase64 = base64_encode(dfsockopen(strpos($AgentItem['ico'],'http') !== false ? $AgentItem['ico'] : $_G['siteurl'].$AgentItem['ico']));
			}
			//��ƬEnd
		}
		
		$AgentTopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['AgentTopMoney']));

		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
			@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
			$PayList = $FnPay->GetPayList();
		}

		$UserInfoList = $Fn_House->GetAjaxUserInfoList(array('limit'=>'3'));

	}else{
		$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['UserTitle'];
	
		$UserInfoLogCount = $Fn_House->GetUserInfoLogCount();//�����ʷ

		$UserInfoCount = $Fn_House->GetUserInfoCount();//�ҷ����ķ�Դ����

		$UserDiscCount = $Fn_House->GetUserDiscCount();//¥������

		$UserInfoCollectionCount = $Fn_House->GetUserInfoCollectionCount();//�ղ�����

		$UserDemandCount = $Fn_House->GetUserDemandCount();//�ҷ���������������
		
		$UserInfoList = $Fn_House->GetAjaxUserInfoList(array('limit'=>'3'));

	}

}else if($_GET['m'] == 'user_disc_list_collection'){//��ע¥��
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['UserDiscCollectionTitle'];
	
}else if($_GET['m'] == 'user_info_list_log'){//�����ʷ
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['BrowseHistory'];
	
}else if($_GET['m'] == 'user_info_list_collection'){//�ҵ��ղ�
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['CollectionTitle'];
	
}else if($_GET['m'] == 'user_info_list'){//�ҷ����ķ�Դ
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['UserHouseList'];

	$HouseTopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['HouseTopMoney']));
	$RentalTopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['RentalTopMoney']));
	$ShopTopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['ShopTopMoney']));
	$WorkShopTopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['WorkShopTopMoney']));
	$OfficeTopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['OfficeTopMoney']));
	$WarehouseTopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['WarehouseTopMoney']));
	$LandTopMoney = array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['LandTopMoney']));
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}

}else if($_GET['m'] == 'user_entrust_list'){//ί���б�
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['EntrustListTitle'];

}else if($_GET['m'] == 'user_demand_list'){//�ҷ�����������
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['UserDemandList'];
	$UserDemandList = $Fn_House->GetUserDemandList();

}else if($_GET['m'] == 'user_agent_info'){//�޸ı༭��������
	
	$navtitle = $metadescription = $metakeywords = $UserInfo['vip'] ? $Fn_House->Config['LangVar']['UserAgentInfoTitle'] : $Fn_House->Config['LangVar']['FixedWebNavAddAgent'];
	
	if(!$UserInfo['vip']){
		$AgentGroupList = $Fn_House->GetAgentGroupList();
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
			@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
			$PayList = $FnPay->GetPayList();
		}

		$PayTitle = $Fn_House->Config['LangVar']['AgentPayTitle'];
		$Msg = $Fn_House->Config['LangVar']['BuyStoreLevelOpenOK'];
	}

	//�ŵ��б�
	$AgentList = !$UserInfo['agent_id'] ? $Fn_House->GetAjaxAgentList() : '';
	
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

}else if($_GET['m'] == 'user_store_team'){
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['TeamMembers'];
	if($UserInfo['identity'] != 1){
		$Msg = $Fn_House->Config['LangVar']['NoStoreErr'];
	}
}else if($_GET['m'] == 'admin_info_list'){//������Դ
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['AdminInfoTitle'];
}else if($_GET['m'] == 'calculation'){//��������
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['CalculationTitle'];
}else if($_GET['m'] == 'list_disc'){//¥���б�

	if(mb_detect_encoding($_GET['keyword'],array('ASCII','UTF-8','GB2312','GBK','BIG5','EUC-CN')) != 'EUC-CN' || CHARSET != 'gbk'){
		$_GET['keyword'] = $_GET['keyword'] ? diconv($_GET['keyword'],mb_detect_encoding($_GET['keyword'], array('ASCII','UTF-8','GB2312','GBK','BIG5','EUC-CN')),CHARSET) : '';
	}

	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['DiscListTitle'];

	if(!checkmobile()){//���԰�
		$PcListDiscSeo = array_filter(explode("#",$Fn_House->Config['PluginVar']['PcListDiscSeo']));
		$navtitle = $PcListDiscSeo[0] ? $PcListDiscSeo[0] : $navtitle;
		$metakeywords = $PcListDiscSeo[1] ? $PcListDiscSeo[1] : $navtitle;
		$metadescription = $PcListDiscSeo[2] ? $PcListDiscSeo[2] : $navtitle;
	}
	
	$Fn_House->Config['WxShare']['WxUrl'] = $Fn_House->Config['ListDiscUrl'].'&keyword='.$_GET['keyword'];

}else if($_GET['m'] == 'view_disc'){//¥������
	
	$Item = $Fn_House->GetViewDiscthread($_GET['iid']);
	if($Item['display']){
		$navtitle = $metadescription = $metakeywords = $Item['title'];
		if(!checkmobile()){//���԰�
			$SeoArray =  array_filter(explode("#",$Item['param']['seo'])) ? array_filter(explode("#",$Item['param']['seo'])) : str_replace(array('{title}','{content}'),array($Item['title'],cutstr(strip_tags($Item['param']['content']),150)),explode("#",$Fn_House->Config['PluginVar']['PcViewDiscSeo']));
			$navtitle = $SeoArray[0] ? $SeoArray[0] : $navtitle;
			$metakeywords = $SeoArray[1] ? $SeoArray[1] : $navtitle;
			$metadescription = $SeoArray[2] ? $SeoArray[2] : $navtitle;
		}
		//������ۼ�
		$ClickRand = array_filter(explode("-",$Fn_House->Config['PluginVar']['ClickRand']));
		$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
		Click($Fn_House->TableDisc,$Item['id'],$ClickNum);
		
		$VideoHtml = GetVideoHtml($Item['param']['video_url'],$Item['param']['cover']);
		
		foreach (array_filter(explode("\r\n",$Fn_House->Config['PluginVar']['NearbyMatching']))as $Key => $Val) {
			$NearbyMatching[$Key] = $Val;
			$NearbyMatchingJson[$Key] = urlencode($Val);
		}
		$NearbyMatchingJs = $NearbyMatchingJson ? urldecode(json_encode($NearbyMatchingJson)) : '';
		
		$PreviewImage = $Item['param']['images'] ? json_encode($Item['param']['images']) : '';//ͼƬ��

		$PreviewAlbum = $Item['param']['album'] ? json_encode($Item['param']['album']) : '';//���
		
		$DiscAgentList = $Item['param']['agent_uids'] ? $Fn_House->GetDiscAgentList($Item['param']['agent_uids']) : '';

		if($_G['uid']){
			//���������¼
			$Fn_House->InsertDiscoLog($Item['id']);
			//�ҵ��ղ�
			$MyDiscCollectArray = $Fn_House->GetUserDiscCollectArray();
			if(in_array($Item['id'],$MyDiscCollectArray)){
				$MyCollect = true;
			}
		}

		//¥����Ѷ
		$ArticleList = $Fn_House->GetAjaxArticleList(array('limit'=>5,'disc_id'=>$Item['id'],'display'=>1));
		
		//¥�̻���
		$DiscHuXingList = $Fn_House->GetDiscHuXingList($Item['id']);
		
		//�۸�����
		foreach (array_filter(explode("\n",$Item['param']['trend']))as $Key => $Val) {
			$TrendArray = array_filter(explode("|",$Val));
			$TrendList[$Key]['price'] = $TrendArray[2];
			$TrendList[$Key]['month'] = $TrendArray[1];
			$TrendList[$Key]['year'] = $TrendArray[0];
		}
		$TrendListJson = $TrendList ? json_encode($TrendList) : '';
		
		//�ܱ�¥��
		$PeripheryList = !$Item['param']['periphery_switch'] ? $Fn_House->GetDiscPeripheryList($Item['lat'],$Item['lng'],5000) : '';
		
		//�Ź��б�
		$GroupBuyingList = $Fn_House->Config['PluginVar']['DiscGroupBuyingSwitch'] ? $Fn_House->GetDiscMobileList($Item['id'],3) : '';
		$Fn_House->Config['LangVar']['ViewGroupBuyingTitle'] = str_replace(array('{count}','{title}'),array(count($GroupBuyingList),$Item['title']),$Fn_House->Config['LangVar']['ViewGroupBuyingTitle']);

		//����
		$Fn_House->Config['WxShare']['WxUrl'] = $Fn_House->Rewrite($_GET['m'],array('iid'=>$Item['id']));
		$Fn_House->Config['WxShare']['WxTitle'] = str_replace(array('{title}'),array($Item['title']),$Fn_House->Config['PluginVar']['ViewDiscShareTitle']);
		$Fn_House->Config['WxShare']['WxImg'] = $Item['param']['cover'] ? $Item['param']['cover'] : $Fn_House->Config['WxShare']['WxImg'];

		//��ά��
		if($Fn_House->Config['PluginVar']['QrParameterSwitch'] && checkmobile()){
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.intval($Item['id']).'.jpg';
			if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
				@unlink($File);
				@require_once libfile('class/wechat','plugin/fn_assembly');
				$WechatClient = new Fn_WeChatClient($Fn_House->Config['PluginVar']['WxAppid'], $Fn_House->Config['PluginVar']['WxSecret']);
				$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.$Item['id'],'expire'=>2592000)));
				DownloadImg($QrUrl,$File);
			}
			$QrCode = base64_encode(file_get_contents($File));
		}else{
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
			if(!file_exists($File) || !filesize($File)) {
				@require_once libfile('class/qrcode','plugin/fn_assembly');
				QRcode::png($Fn_House->Rewrite($_GET['m'],array('iid'=>$Item['id'])), $File, QR_ECLEVEL_L,5,2);
			}
			$QrCode = base64_encode(file_get_contents($File));
			@unlink($File);
		}
		
			
	}else{
		$navtitle = $Msg = $Fn_House->Config['LangVar']['NoViewDiscData'];
	}

}else if($_GET['m'] == 'list_article'){//��Ѷ�б�

	$ArticleClassList = $Fn_House->GetArticleClassList();
	reset($ArticleClassList);
	$FirstKey = key($ArticleClassList);
	//$_GET['classid'] = $_GET['classid'] ? $_GET['classid'] : $FirstKey;
	$DiscItem = $Fn_House->GetViewDiscthread($_GET['disc_id']);
	$ClassItem = $ArticleClassList[$_GET['classid']];
	$navtitle = $metadescription = $metakeywords = $DiscItem ? $DiscItem['title'].$Fn_House->Config['LangVar']['DiscDynamic'] : ($ClassItem ? $ClassItem['title'] : $Fn_House->Config['LangVar']['ArticleListAllTitle']);
	
	
	if(!checkmobile()){//���԰�
		if(!$DiscItem){
			$navtitle = $ClassItem['seo_title'] ? $ClassItem['seo_title'] : $navtitle;
			$metakeywords = $ClassItem['seo_keyword'] ? $ClassItem['seo_keyword'] : $navtitle;
			$metadescription = $ClassItem['seo_desc'] ? $ClassItem['seo_desc']  : $navtitle;
		}
		

		$HotDiscList = $Fn_House->GetDiscIndexList(array('limit'=>5,'hot'=>1));

		$DiscList = $Fn_House->GetDiscIndexList(array('limit'=>5));
	
	}
	
	$Fn_House->Config['WxShare']['WxUrl'] = $Fn_House->Config['ListArticleUrl'].'&classid='.$_GET['classid'].'&disc_id='.$_GET['disc_id'].'&keyword='.$_GET['keyword'];

}else if($_GET['m'] == 'view_article'){//��Ѷ����
	
	$Item = $Fn_House->GetViewArticlethread($_GET['aid']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['title'];

		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_House->Admin){
			$Msg = $Fn_House->Config['LangVar']['ArticleInAudit'];
		}else{
			if($Item['jump']){
				dheader('Location:'.$Item['jump_link']);
				exit();
			}
			if(!checkmobile()){
				$Seo = str_replace(array('{title}','{class}','{content}'),array($Item['title'],$Item['class_title'],($Item['describe'] ? $Item['describe'] : cutstr(strip_tags($Item['content']),150))),explode("#",$Fn_House->Config['PluginVar']['PcArticleSeo']));
				$navtitle = $Seo[0] ? $Seo[0] : $navtitle;
				$metakeywords = $Seo[1] ? $Seo[1] : $navtitle;
				$metadescription = $Seo[2] ? $Seo[2] : $navtitle;
			}

			$DiscItem = $Fn_House->GetViewDiscthread($Item['disc_id']);
			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_House->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_House->TableArticle,$Item['id'],$ClickNum);
			
			//����
			$Fn_House->Config['WxShare']['WxUrl'] = $Fn_House->Rewrite($_GET['m'],array('aid'=>$Item['id']));
			$Fn_House->Config['WxShare']['WxTitle'] = $navtitle;
			$Fn_House->Config['WxShare']['WxDes'] = $Item['describe'] ? DeleteHtml($Item['describe']) : $Fn_House->Config['WxShare']['WxDes'];

		}
	}else{
		$navtitle = $Msg = $Fn_House->Config['LangVar']['NoArticleDiscData'];
	}

}else if($_GET['m'] == 'entrust'){//ί��
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['EntrustTitle'];
	$_GET['class'] = in_array($_GET['class'],array(1,2,3)) ? $_GET['class'] : 1; 

	$Company = $Fn_House->Config['LangVar']['Yuan'].'/'.reset($Fn_House->Config['LangVar']['RentTimeArray']);
	$PriceTime = key($Fn_House->Config['LangVar']['RentTimeArray']);
	$PriceTimeData = MobileSelectJs($Fn_House->Config['LangVar']['RentTimeArray']);

}else if($_GET['m'] == 'list_entrust'){//ί���б�
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['EntrustListTitle'];
	$_GET['class'] = in_array($_GET['class'],array(1,2,3)) ? $_GET['class'] : 1; 

}else if($_GET['m'] == 'publish_agent'){//�����ŵ��༭
	
	$Item = $Fn_House->GetAgentthread($_GET['aid'],true);
	if($Item['uid'] != $_G['uid']){
		unset($Item);
	}

	$navtitle = $metadescription = $metakeywords = $Item ? $Fn_House->Config['LangVar']['PublishAgentEdit'] : $Fn_House->Config['LangVar']['PublishAgentTitle'];

	$Fn_House->Config['LangVar']['PublishSgentBtn'] = $Item ? $Fn_House->Config['LangVar']['PublishSgentEditBtn'] : $Fn_House->Config['LangVar']['PublishSgentBtn'];

	$DataArea = MobileSelectAreaJs($Fn_House->Area);

	//$AgentGroupList = $Fn_House->GetAgentGroupList();

	$BannerArray = $Item['banner'] ? json_encode($Item['banner']) : '';

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}


}else if($_GET['m'] == 'view_agent'){//��������ҳ
	$Item = $Fn_House->GetUserInfo($_GET['auid']);

	$navtitle = $metadescription = $metakeywords = str_replace('{name}',$Item['name'],$Fn_House->Config['LangVar']['ViewAgentTitle']);
	if($Item['work_state'] == 1 && $Item['vip']){

		$Fn_House->Config['LangVar']['NoWxTips'] = str_replace(array("{wx}"),array($Item['wx']),$Fn_House->Config['LangVar']['NoWxTips']);

		//������ۼ�
		$ClickRand = array_filter(explode("-",$Fn_House->Config['PluginVar']['ClickRand']));
		$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
		Click($Fn_House->TableAgentUser,$Item['id'],$ClickNum);

		//��ά��
		if($Fn_House->Config['PluginVar']['QrParameterSwitch'] && checkmobile()){
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.intval($Item['id']).'.jpg';
			if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
				@unlink($File);
				@require_once libfile('class/wechat','plugin/fn_assembly');
				$WechatClient = new Fn_WeChatClient($Fn_House->Config['PluginVar']['WxAppid'], $Fn_House->Config['PluginVar']['WxSecret']);
				$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.$Item['id'],'expire'=>2592000)));
				DownloadImg($QrUrl,$File);
			}
			$QrCode = base64_encode(file_get_contents($File));
		}else{
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
			if(!file_exists($File) || !filesize($File)) {
				@require_once libfile('class/qrcode','plugin/fn_assembly');
				QRcode::png($Fn_House->Rewrite($_GET['m'],array('auid'=>$Item['id'])), $File, QR_ECLEVEL_L,5,2);
			}
			$QrCode = base64_encode(file_get_contents($File));
			@unlink($File);
		}
		
		//����
		$Fn_House->Config['WxShare']['WxUrl'] = $Fn_House->Rewrite($_GET['m'],array('auid'=>$Item['id']));
		$Fn_House->Config['WxShare']['WxTitle'] = $navtitle;
		$Fn_House->Config['WxShare']['WxImg'] = $Item['face'] ? $Item['face'] : $Fn_House->Config['WxShare']['WxImg'];
		
	}else{
		$Msg = $Fn_House->Config['LangVar']['NoAgentErr'];
	}
	
}else if($_GET['m'] == 'list_agent'){//�������б�

	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['ListAgentTitle'];
	$AgentUserList = $Fn_House->GetAjaxAgentUserList();
	
}else if($_GET['m'] == 'list_store'){//�ŵ��б�

	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['ListStoreTitle'];
	//$AgentList = $Fn_House->GetAjaxAgentList();
	
}else if($_GET['m'] == 'store'){//�ŵ�չʾ
	$Item = $Fn_House->GetAgentthread($_GET['aid']);

	$Item['content'] = str_replace("\r\n","<br>",stripslashes($Item['content']));
	
	$navtitle = $metadescription = $metakeywords = $Item['title'];
	
	if($Item['display']){
		
		$StoreAgentList = $Fn_House->GetStoreAgentList($Item['id']);//�Ŷӳ�Ա

		$PreviewImage = $Item['banner'] ? json_encode($Item['banner']) : '';//ͼƬ��

		//������ۼ�
		$ClickRand = array_filter(explode("-",$Fn_House->Config['PluginVar']['ClickRand']));
		$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
		Click($Fn_House->TableAgent,$Item['id'],$ClickNum);

		//��ά��
		if($Fn_House->Config['PluginVar']['QrParameterSwitch'] && checkmobile()){
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.intval($Item['id']).'.jpg';
			if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
				@unlink($File);
				@require_once libfile('class/wechat','plugin/fn_assembly');
				$WechatClient = new Fn_WeChatClient($Fn_House->Config['PluginVar']['WxAppid'], $Fn_House->Config['PluginVar']['WxSecret']);
				$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.$Item['id'],'expire'=>2592000)));
				DownloadImg($QrUrl,$File);
			}
			$QrCode = base64_encode(file_get_contents($File));
		}else{
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
			if(!file_exists($File) || !filesize($File)) {
				@require_once libfile('class/qrcode','plugin/fn_assembly');
				QRcode::png($Fn_House->Rewrite($_GET['m'],array('aid'=>$Item['id'])), $File, QR_ECLEVEL_L,5,2);
			}
			$QrCode = base64_encode(file_get_contents($File));
			@unlink($File);
		}
		
		//����
		$Fn_House->Config['WxShare']['WxUrl'] = $Fn_House->Rewrite($_GET['m'],array('aid'=>$Item['id']));
		$Fn_House->Config['WxShare']['WxTitle'] = $navtitle;
		$Fn_House->Config['WxShare']['WxImg'] = $Item['logo'] ? $Item['logo'] : $Fn_House->Config['WxShare']['WxImg'];

	}else{
		$Msg = $Fn_House->Config['LangVar']['NoStoreErr'];
	}
	
}else if($_GET['m'] == 'buy_store_level'){//�������ײ�
	
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['BuyStoreLevelTitle'];
	
	$AgentGroupList = $Fn_House->GetAgentGroupList();
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}

	$PayTitle = $Fn_House->Config['LangVar']['AgentPayTitle'];

	if($UserInfo['vip']){
		$Fn_House->Config['LangVar']['BuyStoreLevelOpen'] = $Fn_House->Config['LangVar']['BuyStoreLevelRenew'];
		$Msg = $Fn_House->Config['LangVar']['BuyStoreLevelRenewOk'];
	}else{
		$Msg = $Fn_House->Config['LangVar']['BuyStoreLevelOpenOK'];
	}

	
}else if($_GET['m'] == 'store_join'){
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['StoreJoinTitle'];
	$Data = $Fn_House->GetStoreJoin($_GET['aid']);
	$Data['Msg'] = urldecode($Data['Msg']);
}else if($_GET['m'] == 'user_access_record_list'){
	$navtitle = $metadescription = $metakeywords = $Fn_House->Config['LangVar']['AccessRecord'];
	if(!$UserInfo['vip'] || !$UserInfo['access_record']){
		$Msg = $Fn_House->Config['LangVar']['AccessRecordErr'];
	}else{
		$Item = $Fn_House->GetViewthread($_GET['iid']);
	}
}

function NavInspect($Mod,$Url){
	global $_G,$Item;
	$StrReplaceArray = array('{','}');
	$StrReplaceArrayTo = array('','');
	$Rewrite = dunserialize($_G['setting']['fn_house_rewrite']);
	if($Mod == 'view'){
		$Rule = str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite['list_'.$Item['class']]['rule']);
	}else if($Mod == 'view_disc'){
		$Rule = str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite['list_disc']['rule']);
	}else if($Mod == 'view_disc'){
		$Rule = str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite['list_disc']['rule']);
	}
	return str_replace('[siteurl]','',$Url) == $Rule ? true : false;
}

include template('fn_house:'.$_GET['m']);

?>