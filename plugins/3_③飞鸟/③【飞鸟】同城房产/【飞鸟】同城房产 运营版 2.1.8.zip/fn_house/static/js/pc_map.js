
//地图周边控件
window['map_local'] = null;
window['map'] = null;
window['mPoint'] = null;
window['map_panorama'] = null;


var obj_Overlay = {};
function ComplexCustomOverlay( point, text, address, sid ){
	window['maplist'] ='';
	this._point = point;
	this._text  = text;
	this._overText = text ;
	this._address = address;
	this._sid = sid;
}

function AddMarker(point,i_title,i_address,i_id){
	obj_Overlay[i_id] = new ComplexCustomOverlay(point,i_title,i_address,i_id);
	window['map'].addOverlay(obj_Overlay[i_id]);
}

var options = {
	onSearchComplete: function(results){
		$('.fixed_load').hide();
		if(window['map_local'].getStatus() == BMAP_STATUS_SUCCESS){

			if(!$.isEmptyObject(obj_Overlay)){
				for(var key in obj_Overlay){
					window['map'].removeOverlay(obj_Overlay[key]);
				}
				obj_Overlay={};
				$('.ViewMapAddress ul').empty();
			}
			for(var i = 0; i < results.getCurrentNumPois(); i ++){
				var Lng = results.getPoi(i).point.lng;
				var Lat = results.getPoi(i).point.lat;
				var A1 = new BMap.Point(Lng,Lat);
				AddMarker(A1,results.getPoi(i).title,results.getPoi(i).address,results.getPoi(i).uid);
				$('.ViewMapAddress ul').append('<li DataLng="'+Lng+'" DataLat="'+Lat+'"><div class="clearfix"><div class="Title">'+results.getPoi(i).title+'</div><div class="Rice" style="display:none;">'+(window['map'].getDistance(window['mPoint'],A1)).toFixed(0)+'\u7c73</div></div><p>'+results.getPoi(i).address+'</p></li>')
			}

			setTimeout(function(){
				$('.ViewMapAddress ul').find('li').click(function(Event){
					Event.preventDefault();
					var A2 = new BMap.Point(parseFloat($(this).attr('DataLng')),parseFloat($(this).attr('DataLat')));
					remove_overlay();
					var tit = $(this).find('.Title').text();
					AddMarker(A2,tit,null,88);
					window['map'].panTo(A2);
					$(this).addClass('Hover').siblings('li').removeClass('Hover');
				});
			},200);
			function remove_overlay(){
				window['map'].clearOverlays();
			}
		}else{
			if(!$.isEmptyObject(obj_Overlay)){
				for(var key in obj_Overlay){
					window['map'].removeOverlay(obj_Overlay[key]);
				}
				obj_Overlay={};
				$('.ViewMapAddress ul').empty();
			}
			$('.ViewMapAddress ul').append('<li class="NoData"><span class="iconfont">&#xe613;</span>\u5468\u8fb9\u8fd8\u6ca1\u6709\u8be5\u914d\u5957\u54e6</li>')
		}
	}
};
function SetMapDefault(){
    var marker,latitude=$('#AreaXY').attr('DataLat'),longitude=$('#AreaXY').attr('DataLng');

    window['map'] = new BMap.Map("ViewMapContet");
    window['map'].addControl(new BMap.NavigationControl()); //添加默认缩放平移控件

    window['mPoint'] = new BMap.Point(longitude,latitude);
	translateCallback(window['mPoint']);
	
	function translateCallback(ggpoint){
		if(latitude===0||longitude===0){
			window['map'].centerAndZoom(window['icity'],15);
		}else{
			var myIcon = new BMap.Icon("/source/plugin/fn_house/static/images/map_ico.png",new BMap.Size(22, 26),{offset: new BMap.Size(0, 0),imageOffset: new BMap.Size(0, 0)});
			marker = new BMap.Marker(ggpoint,{icon: myIcon});
			marker.disableMassClear();
			window['map'].addOverlay(window['LmapMarker']);
			window['map'].centerAndZoom(ggpoint, 15);
			window['map'].addOverlay(marker);
		}
    }
    window['map'].enableScrollWheelZoom(); //启用滚轮放大缩小
    window['map'].enableContinuousZoom(); //启用地图惯性拖拽
    //window['map'].disableDragging();     //禁止拖拽
	window['map'].addControl(new BMap.NavigationControl());  //添加默认缩放平移控件
	//周边控件
	window['map_local'] = new BMap.LocalSearch(window['map'], options);
	window['map_local'].searchNearby(SearchNearbyArr[0],window['mPoint'],500);
	$('.ViewMapNav li').click(function(Event){
		Event.preventDefault();
		$('.fixed_load').show();
		$('.ViewMapAddress ul').empty();
		$(this).addClass('Hover').siblings().removeClass('Hover');
		zb_style = parseInt($(this).attr('data-val'));
		window['map_local'].searchNearby(SearchNearbyArr[parseInt($(this).attr('DataVal'))],window['mPoint'],500);
	});

	// var panoramaService = new BMap.PanoramaService(); 
	// panoramaService.getPanoramaByLocation(window['mPoint'],1000, function(data){ 
	// 	if (data == null) { 
	// 		$('#DetailPanorama').hide();
	// 		return; 
	// 	}else{
	// 		window['map_panorama'] = new BMap.Map('ViewPanorama');
	// 		window['map_panorama'].centerAndZoom(window['mPoint'], 12);
	// 		window['map_panorama'].addTileLayer(new BMap.PanoramaCoverageLayer());
			
	// 		var Panorama = new BMap.Panorama('ViewPanorama');
	// 		Panorama.PanoramaData
	// 		Panorama.show()
	// 		Panorama.setPov({heading: -40, pitch: 6});
	// 		setTimeout(function(){
	// 			Panorama.setId(data.id);
	// 		},1000);
	// 	}
	// });
}

ComplexCustomOverlay.prototype = new BMap.Overlay();
ComplexCustomOverlay.prototype.initialize = function(map){
	this._map = map;
	var div = this._div = document.createElement("div");
	div.style.position = "absolute";
	div.style.zIndex = BMap.Overlay.getZIndex(this._point.lat);
	div.style.color = "#fff";
	div.style.height = "30px";
	div.style.padding = "0 10px";
	div.style.lineHeight = "30px";
	div.style.whiteSpace = "nowrap";
	div.style.MozUserSelect = "none";
	div.style.backgroundColor = "#199752";
	div.style.opacity = ".8";
	div.style.borderRadius = "3px";
	div.style.fontSize = "14px";
	div.style.cursor = "pointer";
	var span = this._span = document.createElement("span");
	div.appendChild(span);
	span.appendChild(document.createTextNode(this._text));
	var span2 = document.createElement("span");
	span2.style.position = 'absolute';
	span2.style.width='0';
	span2.style.height='0';
	span2.style.borderTop= '6px solid #199752';
	span2.style.borderLeft='6px solid transparent';
	span2.style.borderRight='6px solid transparent';
	span2.style.top='30px';
	span2.style.left= '10px';
	div.appendChild(span2);
	var that = this;
	div.onmouseover = function(){
		this.getElementsByTagName("span")[1].style.borderTop = '6px solid #f9b337';
		this.style.backgroundColor = '#f9b337';
		this.style.zIndex = 99;
	}
	div.onmouseout = function(){
		this.getElementsByTagName("span")[1].style.borderTop = '6px solid #199752';
		this.style.backgroundColor = '#199752';
		this.style.zIndex = BMap.Overlay.getZIndex(that._point.lat);
	}
	map.getPanes().labelPane.appendChild(div);
	return div;
}
ComplexCustomOverlay.prototype.draw = function(){
	var map = this._map;
	var pixel = map.pointToOverlayPixel(this._point);
	this._div.style.left = pixel.x - 20 + "px";
	this._div.style.top  = pixel.y - 33 + "px";
}

function SetPanorama(){
	window['map_panorama'] = new BMap.Map('ViewPanorama');
	var panoramaService = new BMap.PanoramaService();
	var marker2;
	var myData;

	var geolocation = new BMap.Geolocation();
	geolocation.getCurrentPosition(function (r) {
		if (this.getStatus() == BMAP_STATUS_SUCCESS) {
			window['map_panorama'].centerAndZoom(new BMap.Point(r.point.lng, r.point.lat), 16);
		}

		window['map_panorama'].enableScrollWheelZoom(true);
		// 覆盖区域图层测试
		window['map_panorama'].addTileLayer(new BMap.PanoramaCoverageLayer());

		//var stCtrl = new BMap.PanoramaControl(); //构造全景控件
		//stCtrl.setOffset(new BMap.Size(20, 20));
		//window['map_panorama'].addControl(stCtrl);//添加全景控件
		//stCtrl.addEventListener("click",function (t){alert("ok");});

		//var panorama = new BMap.Panorama('panorama'); //默认为显示导航控件
		//panorama.setPosition(new BMap.Point(r.point.lng,r.point.lat));

		//创建小狐狸
		var pt = new BMap.Point(r.point.lng, r.point.lat);
		var myIcon = new BMap.Icon("location.png", new BMap.Size(24, 28));
		myIcon.setImageSize(new BMap.Size(24, 28));
		marker2 = new BMap.Marker(pt, { icon: myIcon });  // 创建标注
		marker2.enableDragging();

		var opts = {
			position: pt,
			offset: new BMap.Size(-55, -105)    //设置文本偏移量
		}

		var lableContent = "<div class=\"marker\"><img id=\"myImg\" src=\"noImg.png\"/><div id=\"myDesc\"></div></div>";

		var myLabel = new BMap.Label(lableContent, opts);
		marker2.setLabel(myLabel);

		window['map_panorama'].addOverlay(marker2);

		myLabel.addEventListener("click", function (obj) {
			if (myData != null) {
				debugger;
				var panorama = window['map_panorama'].getPanorama();//获取实例对象
				panorama.setId(myData.id);
				panorama.show();
			}
		});

		marker2.addEventListener("dragend", function (t) {
			myData = null;
			var p = marker2.getPosition();
			test(p.lng, p.lat);

			//alert("marker的位置是" + p.lng + "," + p.lat);

		});

	}, { enableHighAccuracy: true });



	function test(lng, lat) {
		$("#myDesc").html("加载中......");
		panoramaService.getPanoramaByLocation(new BMap.Point(lng, lat), function (data) {
			var panoramaInfo = "";
			if (data == null) {
				$("#myDesc").html("");
				return;
			}
			myData = data;
			panoramaInfo += '全景id为：' + data.id + '\n';
			panoramaInfo += '坐标为：' + data.position.lng + ':' + data.position.lat + '\n';
			//alert(panoramaInfo);
			getImg(data);
		});
	}

	function getImg(data) {
		$("#myImg").attr('src', "http://api.map.baidu.com/panorama/v2?ak=L3mypLAsYc8N2ynGFNGOFvGMCYULak63&width=120&height=100&location=" + data.position.lng + "," + data.position.lat + "&fov=180");
		$("#myDesc").html(data.description);
	}
}


