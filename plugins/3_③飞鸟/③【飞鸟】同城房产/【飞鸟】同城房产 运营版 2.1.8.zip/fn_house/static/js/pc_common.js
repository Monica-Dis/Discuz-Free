function formatNumber(n) {
	n = n.toString()
	return n[1] ? n : '0' + n
}
// 日期重整 xx-xx
function formatTime_Creat(date) {
    // var year = date.getYear();
    var month = date.getMonth() + 1 ;
    var day = date.getDate() ;
    var hour = date.getHours() ;
    var minute = date.getMinutes() ;
    var second = date.getSeconds() ;
    return formatNumber( month ) +'-'+ formatNumber( day )  ;
    // if(hasYear==true){
        
    // }else{
    //     return formatNumber( month ) +'-'+ formatNumber( day )  ;
    // }
}

// 数字变化封装
$.fn.countTo = function (options) {
    options = options || {};
    //当options未被初始化，即typeof options = 'undefined'时，执行后面部分即var options = {}来初始化一个对象

    return $(this).each(function () {
        var settings = $.extend({}, $.fn.countTo.defaults, {
            from: $(this).data('from'),
            to: $(this).data('to'),
            speed: $(this).data('speed'),
            refreshInterval: $(this).data('refresh-interval'),
            decimals: $(this).data('decimals')
        }, options);
        //更新值多少次，每次更新值多快
        var loops = Math.ceil(settings.speed / settings.refreshInterval),
            increment = (settings.to - settings.from) / loops;

        //引用和变量每次更新将改变
        var self = this,//返回html对象
            $self = $(this),//返回返回一个jquery对象
            loopCount = 0,
            value = settings.from,
            data = $self.data('countTo') || {};//获取jauery方法对象

        $self.data('countTo', data);//赋值

        //如果存在间隔，则清除它
        if (data.interval) {
            clearInterval(data.interval);
        }
        data.interval = setInterval(updateTimer, settings.refreshInterval);

        //用开始的值初始化
        render(value);

        function updateTimer() {
            value += increment;
            loopCount++;

            render(value);

            if (typeof (settings.onUpdate) == 'function') {
                settings.onUpdate.call(self, value);
            }

            if (loopCount >= loops) {
                $self.removeData('countTo');
                clearInterval(data.interval);
                value = settings.to;

                if (typeof (settings.onComplete) == 'function') {
                    settings.onComplete.call(self, value);
                }
            }
        }

        function render(value) {
            var formattedValue = settings.formatter.call(self, value, settings);
            $self.html(formattedValue);
        }
    });
};
$.fn.countTo.defaults = {
    from: 0,  
    to: 0,   
    speed: 500,  
    refreshInterval: 10, 
    decimals: 0,  
    formatter: formatter, 
    onUpdate: null, 
    onComplete: null 
};
function formatter(value, settings) {
    return value.toFixed(settings.decimals);
}
function count(options) {
    var $this = $(this);
    options = $.extend({}, options || {}, $this.data('countToOptions') || {});
    $this.countTo(options);
}
// 数字变化封装 end

// 详情页banner图
$.fn.detailBan = function(){
    var that = $(this);
    var oPic = that.find(".ViewBox");
    var oPicVideo = that.find(".videoBox");
    var oHandle = that.find(".Handle");
    var oList = that.find(".ViewListBox");
    var oBigPic = that.find(".ViewBigBox");

    var oPrev = that.find(".View-prev");
    var oNext = that.find(".View-next");

    var oListLi = oList.find("li");
    var len2 = oListLi.length;

    var oListUl = oList.find("ul");
    var w2 = oListLi.outerWidth();

    oListUl.width(w2 * len2)

    var index = 0;

    var num = 5;
    var num2 = Math.ceil(num / 2);

    var oPicImg;
    oPicImg = oListLi.eq(index).css("backgroundImage").replace('url(','').replace(')','');
    oPic.css({"background-image":"url("+oPicImg+")"})

    if(oListLi.attr('dataVideo') != 'videoBoxShow'){
        oBigPic.find('.BigTu').css({"background-image":"url("+oPicImg+")"})
    }else{
        oPicVideo.css({"display":"block"})
    }

    function Change() {
        if(len2<5){
            oListUl.stop().animate({'left':0})
        }else{
            if(index < num2){
                oListUl.stop().animate({'left':0})
            }else if(index + num2 <= len2){
                oListUl.stop().animate({'left':- (index - num2 + 1) * w2})
            }else{
                oListUl.stop().animate({'left':- (len2 - num) * w2})
            }
        }
        for (var i = 0; i < len2; i++) {
            oListLi[i].className = "";
            if(i == index){
                oListLi[i].className = "on";
            }
        }
        if(oListLi.eq(index).attr('dataVideo') != 'videoBoxShow'){
            oPicVideo.css({"display":"none"})
        }else{
            oPicVideo.css({"display":"block"})
        }
        oPicImg = oListLi.eq(index).css("backgroundImage").replace('url(','').replace(')','');
        oPic.css({"background-image":"url("+oPicImg+")"})
        oBigPic.find('.BigTu').css({"background-image":"url("+oPicImg+")"})
    };

    oNext.click(function(){
        index ++;
        index = index == len2 ? 0 : index;
        Change();
    });
    oPrev.click(function(){
        index --;
        index = index == -1 ? len2 -1 : index;
        Change();
    });
    for (var i = 0; i < len2; i++) {
        oListLi[i].index = i;
        oListLi[i].onclick = function(){
            index = this.index;
            Change();
        }
    }

    // 放大图
    oPic.mousemove(function(e) {
        if(oListLi.eq(index).attr('dataVideo') != 'videoBoxShow'){
            oBigPic.show();
            oHandle.show();
        }
        var myX = e.pageX -oPic.offset().left - oHandle.width()/2;
		var myY = e.pageY -oPic.offset().top - oHandle.height()/2;
		
		// 约束左上
		if(myX<0){myX=0;}
		if(myY<0){myY=0;}
		// 约束右下
		if( myX > oPic.width()-oHandle.width() ){
			myX = oPic.width()-oHandle.width()	
		}
		if( myY > oPic.height()- oHandle.height() ){
			myY = oPic.height()- oHandle.height()	
        }
        oHandle.css({ left:myX , top:myY });

        var beishuX = (oBigPic.find('.BigTu').width()-oHandle.width()-50)/oPic.width();  
        var beishuY = (oBigPic.find('.BigTu').height()- oHandle.height()-76)/oPic.height();   	
		oBigPic.find('.BigTu').css({ 
			left: -myX * beishuX ,
			top: -myY *  beishuY 
		})
    }).mouseleave(function(){
		oBigPic.hide();
        oHandle.hide();
	})


}

function get_point(){
	var search_txt = document.getElementById('search_txt');
	if(search_txt.value == ''){
		alert('\u8bf7\u8f93\u5165\u641c\u7d22\u5173\u952e\u5b57');
		return false;
	}
	var myGeo = new BMap.Geocoder();
	myGeo.getPoint(search_txt.value, function(point){
	  if (point) {
		window['map'].removeOverlay(window['marker']);
		window['marker'] = new BMap.Marker(point);
		window['map'].centerAndZoom(point, 15);
		window['x'] = point.lng;
		window['y'] = point.lat;
		window['map'].addOverlay(window['marker']);
	  }else{
		 alert('\u6ca1\u6709\u627e\u5230\u76f8\u5173\u5730\u5740\uff01');
	  }
	}, window['CITY'] );
}

function biaozhu_cancel(){
	$('#MapIframe').hide();
}

function biaozhu_ok(){
	if(window['x'] === 0 || window['y'] === 0){
		alert('\u8bf7\u5728\u5730\u56fe\u4e0a\u627e\u5230\u60a8\u8981\u7684\u4f4d\u7f6e\u5355\u51fb\u5730\u56fe\u8fdb\u884c\u6807\u6ce8\uff01');
		return false;
	}
	var Geocoder = new BMap.Geocoder();
	Geocoder.getLocation(new BMap.Point(window['x'],window['y']), function(rs){
		$('input[name="lat"]').val(rs.point.lat);
		$('input[name="lng"]').val(rs.point.lng);
		$('input[name="community"]').val(rs.addressComponents.street + rs.addressComponents.streetNumber);
		$('.Map').html('\u5df2\u6807\u6ce8\u4f4d\u7f6e<span class="FFFFFColor iconfont">&#xe629;</span>').addClass('FFFFFColor');
		biaozhu_cancel();
	});
}

function translateCallback(ggpoint){
	if(window['latitude'] == '' || window['longitude'] == ''){
		window['map'].centerAndZoom(window['CITY'] ,15);
	}else{

		window['marker'] = new BMap.Marker(ggpoint);
		window['map'].centerAndZoom(ggpoint, 15);
		window['map'].addOverlay(window['marker']);
		window['x'] = ggpoint.lng;
		window['y'] = ggpoint.lat;
	}
}

function biaozhu(){
	var MapIframe = $('#MapIframe');
	if(MapIframe.attr('DataShow')==='1'){
		MapIframe.show();
		return false;
	}
	if(window['CITY'] === '') window['CITY'] = '\u5e7f\u5dde';
	window['x'] = $('input[name="lng"]').val();
	window['y'] = $('input[name="lat"]').val();
	window['map'] = new BMap.Map("AllMap");
	window['map'].addControl(new BMap.NavigationControl());
	window['latitude'] = $('input[name="lat"]').val();
	window['longitude'] = $('input[name="lng"]').val();

	window['point']=new BMap.Point(window['longitude'],window['latitude']);

	translateCallback(window['point']);
		
	window['map'].addEventListener("click",function(e){
		var point2 = new BMap.Point(e.point.lng, e.point.lat);
		window['map'].removeOverlay(window['marker']);
		window['marker'] = new BMap.Marker(point2);
		window['map'].addOverlay(window['marker']);
		window['x'] = e.point.lng;
		window['y'] = e.point.lat;
	});
	window['map'].enableScrollWheelZoom();
	window['map'].enableContinuousZoom();
	window['map'].addControl(new BMap.NavigationControl());
	window['map'].addControl(new BMap.NavigationControl({anchor: BMAP_ANCHOR_BOTTOM_LEFT, type: BMAP_NAVIGATION_CONTROL_PAN}));
	MapIframe.attr('DataShow','1').show();
	return false;
}