//地图周边控件
window['map_local'] = null;
window['map'] = null;
window['mPoint'] = null;

function AddMarker(point,i_title,i_address,i_id){
  obj_Overlay[i_id] = new ComplexCustomOverlay(point,i_title,i_address,i_id);
  window['map'].addOverlay(obj_Overlay[i_id]);
}
var options = {
	onSearchComplete: function(results){
		$('.fixed_load').hide();
		if(window['map_local'].getStatus() == BMAP_STATUS_SUCCESS){

			if(!$.isEmptyObject(obj_Overlay)){
				for(var key in obj_Overlay){
					window['map'].removeOverlay(obj_Overlay[key]);
				}
				obj_Overlay={};
				$('.ViewMapAddress ul').empty();
			}
			for(var i = 0; i < results.getCurrentNumPois(); i ++){
				var Lng = results.getPoi(i).point.lng;
				var Lat = results.getPoi(i).point.lat;
				var A1 = new BMap.Point(Lng,Lat);
				AddMarker(A1,results.getPoi(i).title,results.getPoi(i).address,results.getPoi(i).uid);
				$('.ViewMapAddress ul').append('<li DataLng="'+Lng+'" DataLat="'+Lat+'"><div class="Title">'+results.getPoi(i).title+'</div><div class="Rice"><em class="iconfont">&#xe6c9;</em><span>'+(window['map'].getDistance(window['mPoint'],A1)).toFixed(0)+'\u7c73</span></div></li>');
			}

			setTimeout(function(){
				$('.ViewMapAddress ul').find('li').click(function(Event){
					Event.preventDefault();
					var A2 = new BMap.Point(parseFloat($(this).attr('DataLng')),parseFloat($(this).attr('DataLat')));
					remove_overlay();
					var tit = $(this).find('.Title').text();
					AddMarker(A2,tit,null,88);
					window['map'].panTo(A2);
					$(this).addClass('Hover').siblings('li').removeClass('Hover');
				});
			},200);
			function remove_overlay(){
				window['map'].clearOverlays();
			}
		}else{
			if(!$.isEmptyObject(obj_Overlay)){
				for(var key in obj_Overlay){
					window['map'].removeOverlay(obj_Overlay[key]);
				}
				obj_Overlay={};
				$('.ViewMapAddress ul').empty();
			}
			$('.ViewMapAddress ul').append('<li class="NoData"><span class="iconfont">&#xe613;</span>\u5468\u8fb9\u8fd8\u6ca1\u6709\u8be5\u914d\u5957\u54e6</li>')
		}
	}
};
function SetMapDefault(){
	var marker,latitude=$('#AreaXY').attr('DataLat'),longitude=$('#AreaXY').attr('DataLng');

	window['map'] = new BMap.Map("ViewMapContet");
	window['map'].addControl(new BMap.NavigationControl());

	window['mPoint'] = new BMap.Point(longitude,latitude);
	translateCallback(window['mPoint']);
	
	function translateCallback(ggpoint){
		if(latitude===0||longitude===0){
			window['map'].centerAndZoom(window['icity'],15);
		}else{
			var myIcon = new BMap.Icon("/source/plugin/fn_house/static/images/map_ico.png",new BMap.Size(22, 26),{offset: new BMap.Size(0, 0),imageOffset: new BMap.Size(0, 0)});
			marker = new BMap.Marker(ggpoint,{icon: myIcon});
			marker.disableMassClear();
			window['map'].addOverlay(window['LmapMarker']);
			window['map'].centerAndZoom(ggpoint, 15);
			window['map'].addOverlay(marker);
		}
	}
	//window['map'].enableScrollWheelZoom();    //启用滚轮放大缩小，默认禁用
	//window['map'].enableContinuousZoom();    //启用地图惯性拖拽，默认禁用
	window['map'].disableDragging();     //禁止拖拽
	window['map'].addControl(new BMap.NavigationControl());  //添加默认缩放平移控件
	//周边控件
	window['map_local'] = new BMap.LocalSearch(window['map'], options);
	window['map_local'].searchNearby(SearchNearbyArr[0],window['mPoint'],500);
	$('.ViewMapNav span').click(function(Event){
		Event.preventDefault();
		$('.fixed_load').show();
		$('.ViewMapAddress ul').empty();
		$(this).addClass('Hover').siblings().removeClass('Hover');
		zb_style = parseInt($(this).attr('data-val'));
		window['map_local'].searchNearby(SearchNearbyArr[parseInt($(this).attr('DataVal'))],window['mPoint'],500);
		$("html,body").animate({scrollTop:$('.ViewMapNav').offset().top},0);
	});
}
var obj_Overlay = {};
function ComplexCustomOverlay( point, text, address, sid ){
	window['maplist'] ='';
	this._point = point;
	this._text  = text;
	this._overText = text ;
	this._address = address;
	this._sid = sid;
}
ComplexCustomOverlay.prototype = new BMap.Overlay();
ComplexCustomOverlay.prototype.initialize = function(map){
	this._map = map;
	var div = this._div = document.createElement("div");
	div.style.position = "absolute";
	div.style.zIndex = BMap.Overlay.getZIndex(this._point.lat);
	div.style.color = "#fff";
	div.style.height = "0.45rem";
	div.style.padding = "0 0.2rem";
	div.style.lineHeight = "0.45rem";
	div.style.whiteSpace = "nowrap";
	div.style.MozUserSelect = "none";
	div.style.backgroundColor = "#199752";
	div.style.opacity = ".8";
	div.style.borderRadius = "0.03rem";
	div.style.fontSize = "0.24rem";
	div.style.cursor = "pointer";
	var span = this._span = document.createElement("span");
	div.appendChild(span);
	span.appendChild(document.createTextNode(this._text));
	var span2 = document.createElement("span");
	span2.style.position = 'absolute';
	span2.style.width='0';
	span2.style.height='0';
	span2.style.borderTop= '6px solid #199752';
	span2.style.borderLeft='6px solid transparent';
	span2.style.borderRight='6px solid transparent';
	span2.style.top='0.45rem';
	span2.style.left= '0.3rem';
	div.appendChild(span2);
	var that = this;
	div.onmouseover = function(){
		this.getElementsByTagName("span")[1].style.borderTop = '6px solid #f9b337';
		this.style.backgroundColor = '#f9b337';
		this.style.zIndex = 99;
	}
	div.onmouseout = function(){
		this.getElementsByTagName("span")[1].style.borderTop = '6px solid #199752';
		this.style.backgroundColor = '#199752';
		this.style.zIndex = BMap.Overlay.getZIndex(that._point.lat);
	}
	map.getPanes().labelPane.appendChild(div);
	return div;
}
ComplexCustomOverlay.prototype.draw = function(){
	var map = this._map;
	var pixel = map.pointToOverlayPixel(this._point);
	this._div.style.left = pixel.x - 20 + "px";
	this._div.style.top  = pixel.y - 33 + "px";
}