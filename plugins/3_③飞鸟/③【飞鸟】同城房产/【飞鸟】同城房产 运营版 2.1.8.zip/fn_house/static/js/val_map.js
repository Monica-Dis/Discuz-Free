window['Lmap'] = null;
window['LmapMarker'] = null;
window['defaultMarker'] = null;
window['GPSpoint'] = null;

function TitControl(){
	this.defaultAnchor = BMAP_ANCHOR_TOP_LEFT;
	this.defaultOffset = new BMap.Size(parseInt($(window).width()/2-90,10),10);
}
TitControl.prototype = new BMap.Control();
TitControl.prototype.initialize = function(map){
	var div = document.createElement("div");
	div.appendChild(document.createTextNode("\u8bf7\u62d6\u52a8\u5730\u56fe\u6807\u6ce8\u60a8\u7684\u4f4d\u7f6e"));
	div.style.color = "#ffffff";
	div.style.fontSize = "0.22rem";
	div.style.padding = "0.1rem 0";
	div.style.width = "3rem";
	div.style.textAlign = "center";
	div.style.backgroundColor = "rgba(255,153,51,.6)";
	map.getContainer().appendChild(div);
	return div;
}
function ZoomControl(){
	this.defaultAnchor = BMAP_ANCHOR_TOP_LEFT;
	this.defaultOffset = new BMap.Size(parseInt($(window).width()/2-60,10),101);
}
ZoomControl.prototype = new BMap.Control();
ZoomControl.prototype.initialize = function(map){
	var div = document.createElement("div");
	div.appendChild(document.createTextNode("\u5b83\u5728\u8fd9\u91cc"));
	div.style.color = "#ffffff";
	div.style.fontSize = "0.22rem";
	div.style.padding = "0.1rem 0 0 0.18rem";
	div.style.width = "1.55rem";
	div.style.height = "0.65rem";
	div.style.cursor = "pointer";
	div.style.background = "url("+window['Default_tplPath']+"/images/iamhere.png) no-repeat 0 0";
	div.style.backgroundSize ="cover";
	div.onclick = function(e){
		var Geocoder = new BMap.Geocoder();
		Geocoder.getLocation(new BMap.Point(window['Lmap'].getCenter().lng,window['Lmap'].getCenter().lat), function(rs){
			Locum(window['Lmap'].getCenter().lng,window['Lmap'].getCenter().lat,rs.addressComponents.street + rs.addressComponents.streetNumber);
		});
	}
	map.getContainer().appendChild(div);
	return div;
}
function LocationControl(){
	this.defaultAnchor = BMAP_ANCHOR_BOTTOM_RIGHT;
	this.defaultOffset = new BMap.Size(10,10);
}
LocationControl.prototype = new BMap.Control();
LocationControl.prototype.initialize = function(map){
	var div = document.createElement("div");
	div.style.width = "30px";
	div.style.height = "30px";
	div.style.border = "1px solid #ddd";
	div.style.borderRadius = "2px";
	div.style.background = "rgba(255,255,255,.5) url("+window['Default_tplPath']+"images/default-40x40.png) no-repeat 5px 5px";
	div.style.backgroundSize = "20px auto";
	map.getContainer().appendChild(div);
	div.onclick = function(e){
		e.preventDefault();
		var point=window['LmapMarker'].getPosition();
		searchLocation2(point);
		window['Lmap'].panTo(point);
	}
	return div;
}
function LocationControl(){
	this.defaultAnchor = BMAP_ANCHOR_BOTTOM_RIGHT;
	this.defaultOffset = new BMap.Size(10,10);
}
function addOverlayLocation(e){
	var ico = new BMap.Icon(window['Default_tplPath']+"images/markers_ico.png", new BMap.Size(14,14),{anchor: new BMap.Size(7, 4),imageOffset:new BMap.Size(-105, 0),imageSize:new BMap.Size(150, 150)});
	window['LmapMarker'] = new BMap.Marker(e,{icon:ico});
	window['LmapMarker'].disableMassClear();
	window['Lmap'].addOverlay(window['LmapMarker']);
	window['Lmap'].addControl(new LocationControl());

	if($('#s_search_key').val()!==''){
		//return;
	}
	window['Lmap'].panTo(e);
	SearchLocation(e);
}
function showGPSLocation(point){
	addOverlayLocation(point);
}

function Locum(lng,lat,community){
	$('input[name=lng]').val(lng);
	$('input[name=lat]').val(lat);
	$('input[name=community]').val(community);
	$('.Map').addClass('FFFFFColor').html('\u5df2\u6807\u6ce8<span class="FFFFFColor iconfont">&#xe629;</span>');
	$('.PublishSgentMapMain').stop().animate({bottom:"-200%"},200,function(){});
}

function locationCallBack(){
	var LngVal = $('input[name=lng]').val(),LatVal = $('input[name=lat]').val();
	if(LngVal == '' && LatVal == ''){
		if(window['LocationSwitch'] == 0 && window['DefaultLng'] != '' && window['DefaultLat'] != ''){
			LngVal = window['DefaultLng'],LatVal = window['DefaultLat'];
		}else{
			getLocation(showMapGPSre);
		}
	}
	window['Lmap'] = new BMap.Map("PublishSgentMapContent",{enableMapClick :false});
	window['Lmap'].addControl(new BMap.NavigationControl({anchor: BMAP_ANCHOR_TOP_RIGHT, type: BMAP_NAVIGATION_CONTROL_SMALL}));
	window['Lmap'].addControl(new ZoomControl());
	window['Lmap'].addControl(new TitControl());
	
	//if(LngVal == '' && LatVal == '' && ){
		//window['Lmap'].centerAndZoom(window['CITY'],18);
	//}else{
		var DefaultPoint = new BMap.Point(LngVal,LatVal);
		window['Lmap'].centerAndZoom(DefaultPoint,18);
		var ico = new BMap.Icon(window['Default_tplPath']+"images/markers_ico.png", new BMap.Size(15,15),{anchor: new BMap.Size(7, 7),imageOffset:new BMap.Size(-150, -232),imageSize:new BMap.Size(300, 300)});
		window['defaultMarker'] = new BMap.Marker(DefaultPoint,{icon:ico});
		window['defaultMarker'].disableMassClear();
		window['Lmap'].addOverlay(window['defaultMarker']);
		SearchLocation(DefaultPoint);
	//}

	window['Lmap'].addEventListener("dragend", function(e){
		SearchLocation(window['Lmap'].getCenter());
	});
	window['Lmap'].addEventListener("touchend", function(e){
		SearchLocation(window['Lmap'].getCenter());
	});
}

$(document).on('click',".MapBtn",function(Event){
	var KeywordVal = $('input[name=keyword]').val();
	if(KeywordVal == ''){
		layer.open({content:'\u8bf7\u8f93\u5165\u5c0f\u533a\u3001\u5355\u4f4d\u3001\u5b66\u6821\u3001\u5546\u5708\u3001\u5730\u5740',skin: 'msg',time: 2});
		return false;
	}
	SearchLocation2(KeywordVal,window['CITY']);
	return false;
});

function SearchLocation(point){
	var mOption = {
		poiRadius : 500,           //�뾶Ϊ500���ڵ�POI,Ĭ��100��
		numPois : 12                //�оٳ�12��POI,Ĭ��10��
	}
	var myGeo = new BMap.Geocoder();
	window['Lmap'].clearOverlays();  
	myGeo.getLocation(point,function mCallback(rs){
		var allPois = rs.surroundingPois;       //��ȡȫ��POI���õ�뾶Ϊ100������6��POI�㣩
		var Html = '';
		for(var i = 0; i < allPois.length; i ++){
			Html += '<li DataLng="'+allPois[i].point.lng+'" DataLat="'+allPois[i].point.lat+'"><div class="Info"><div class="Title">'+allPois[i].title+'</div><div class="Address">'+allPois[i].address+'</div></div><div class="PointBtn FFFFFColor FFFFFBorderColor">\u5b83\u5728\u8fd9\u91cc</div></li>';
		}
		$('.PublishSgentMapList ul').html(Html);

		$('.PublishSgentMapList ul').on('click','.Info',function(e){
			e.preventDefault();
			var point = new BMap.Point($(this).parent().attr('DataLng'),$(this).parent().attr('DataLat'));
			window['Lmap'].panTo(point);
		});

		$('.PublishSgentMapList ul').find('.PointBtn').click(function(e){
			e.preventDefault();
			var Geocoder = new BMap.Geocoder();
			Geocoder.getLocation(new BMap.Point($(this).parent().attr('DataLng'),$(this).parent().attr('DataLat')), function(rs){
				Locum(rs.point.lng,rs.point.lat,rs.addressComponents.street + rs.addressComponents.streetNumber);
			});
		});

	},mOption);	
}

function SearchLocation2(Val,City){
	window['Lmap'].centerAndZoom(City,18);
	setTimeout(function(){
		var options = {
			pageCapacity:6,
			onSearchComplete: function(results){
				if (local.getStatus() == BMAP_STATUS_SUCCESS){
					var Html = '';
					for(var i = 0; i < results.getCurrentNumPois(); i ++){
						if(i===0){
							window['Lmap'].panTo(new BMap.Point(results.getPoi(i).point.lng,results.getPoi(i).point.lat));
						}
						Html += '<li DataLng="'+results.getPoi(i).point.lng+'" DataLat="'+results.getPoi(i).point.lat+'"><div class="Info"><div class="Title">'+results.getPoi(i).title+'</div><div class="Address">'+results.getPoi(i).address+'</div></div><div class="PointBtn FFFFFColor FFFFFBorderColor">\u5b83\u5728\u8fd9\u91cc</div></li>';
					}
					
					$('.PublishSgentMapList ul').html(Html);

					$('.PublishSgentMapList ul').on('click','.Info',function(e){
						e.preventDefault();
						var point = new BMap.Point($(this).parent().attr('DataLng'),$(this).parent().attr('DataLat'));
						window['Lmap'].panTo(point);
					});

					$('.PublishSgentMapList ul').find('.PointBtn').click(function(e){
						e.preventDefault();
						var Geocoder = new BMap.Geocoder();
						Geocoder.getLocation(new BMap.Point($(this).parent().attr('DataLng'),$(this).parent().attr('DataLat')), function(rs){
							Locum(rs.point.lng,rs.point.lat,rs.addressComponents.street + rs.addressComponents.streetNumber);
						});
					});
				}else{
					$('.PublishSgentMapList ul').html('');
				}
			}
		};
		var local = new BMap.LocalSearch(window['Lmap'], options);
		local.search(Val);
	},200);
}