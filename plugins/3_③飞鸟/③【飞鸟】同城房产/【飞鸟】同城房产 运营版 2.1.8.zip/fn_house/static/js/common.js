window.addEventListener("DOMContentLoaded", function() {
	var AdSwiper = new Swiper('.Ad .swiper-container',{
		autoplay:7000,
		calculateHeight:true,
		pagination : '.pagination'
    });
});


function showMapGPSre(point){
	if(typeof showGPSLocation !== 'undefined'){
		showGPSLocation(point);
		window['GPSpoint'] = point;
	}
	var geoc = new BMap.Geocoder();
	geoc.getLocation(point, function(rs){
		var addComp = rs.addressComponents;
		$('#CurLocation').html(addComp.district + addComp.street + addComp.streetNumber);
	});
}

function getLocation(callback){
	var geolocation = new BMap.Geolocation();
	geolocation.getCurrentPosition(function(r){
		if(this.getStatus() == BMAP_STATUS_SUCCESS){
			callback&&callback.call(this,r.point);

			window['GPSpoint'] = r.point;
		}
		else {
			if(typeof keyvalues !== 'undefined'){getPagingGlobal();}
			MSGwindowShow('location','0','\u62b1\u6b49\uff0c\u6211\u4eec\u6ca1\u6709\u83b7\u53d6\u5230\u60a8\u7684\u4f4d\u7f6e\u4fe1\u606f','','');
		}        
	},{enableHighAccuracy: true});
}