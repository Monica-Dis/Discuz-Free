var MyTrend;
function GetEcharts(brower){
	var X_Obj = [];
	var Y_Obj = [];
	$.each(brower,function(Index,Item){
		X_Obj.push(Item.year+'-'+Item.month);
		Y_Obj.push(Item.price);
	});

	if (MyTrend != null && MyTrend != "" && MyTrend != undefined) {  
		MyTrend.dispose();  
	} 

	MyTrend = echarts.init(document.getElementById('ViewDiscCanvas'));

	var option = {
		title: {
			left: 'center',
			text: $('.ViewDiscTrendMain .Title').html()
		},
		grid: {
			left: '3%',
			right: '5%',
			bottom: '3%',
			containLabel: true
		},
		tooltip : {
			trigger: 'axis',
			axisPointer: {
				type: 'cross',
				label: {
					backgroundColor: '#6a7985'
				}
			}
		},
		xAxis: {
			type: 'category',
			boundaryGap: false,
			data: X_Obj,
			axisLabel: {color: '#2b2b2b'},
			axisLine: {lineStyle: {color: '#0087cc',width: 2}}
		},
		
		series: [{
			data: Y_Obj,
			name: '\u5747\u4ef7',
			type: 'line',
			smooth: true,
			itemStyle: {normal:{color:'#29c6c8',lineStyle:{color: '#29c6c8'}}},
			areaStyle: {normal:{color:'#ace7e7'}},
			item: {normal:{color:'#ace7e7'}},
			markArea: {normal:{color:'#ace7e7'}}
		}],
		yAxis: {
			type: 'value',
			name: '\u5747\u4ef7',
			nameTextStyle: {color: '#999'},
			axisLabel: {color: '#2b2b2b'},
			axisLine: {lineStyle: {color: '#0087cc',width: 2}},
			axisTick: {show: false},
			splitLine: {show: false}
		}
	};
	MyTrend.setOption(option);
}