// 计算税费
function SetShuiFei(){
    var DataPrice = $('#PriceAndSize').attr('DataPrice'),DataSize = $('#PriceAndSize').attr('DataSize');
    var TwoYear = $('#TwoYear'),FirstSet = $('#FirstSet');
    if(DataPrice == ''){
        $('#ShuiFeiCon').hide();
        return;
    }

    var total = parseInt(DataPrice)*10000;
    var yingyeshui = 0,geshui = 0.01,qishui = 0.01;

    if(TwoYear.val()==='1'){//不满两年
		//yingyeshui = parseInt(total/1.05*0.05);
		//yingyeshui = .12*yingyeshui+yingyeshui;
		yingyeshui = parseInt(total*.0538);
	}
	if(TwoYear.val()==='2'){//满五唯一 免个税
		geshui = 0;
	}
	if(FirstSet.val()==='1'){//二套
		if(parseFloat(DataSize)>90){qishui = 0.02}
	}else{
		if(parseFloat(DataSize)>90){qishui = 0.015}
	}
    var json_data = [];
	var arr1 = {name:'契税',value:qishui*total};
	json_data.push(arr1);
	var arr2 = {name:'增值税',value:yingyeshui};
	json_data.push(arr2);
	var arr3 = {name:'个税',value:geshui*total};
	json_data.push(arr3);
	ShowTaxation(json_data);
	EchartStr(json_data);
}

function ShowTaxation(arr){
	var QiShuiNode = $('#QiShuiNode'),ZengZhiNode = $('#ZengZhiNode'),GeShuiNode = $('#GeShuiNode'),AllShuiNode = $('#AllShuiNode');
	QiShuiNode.html(arr[0].value+'元')
	ZengZhiNode.html(arr[1].value+'元')
	GeShuiNode.html(arr[2].value+'元')
	var total = arr[0].value + arr[1].value+arr[2].value;
	AllShuiNode.html(total+'元');
}


// 基于准备好的dom，初始化echarts实例
var myChart;
function EchartStr(brower){
	if (myChart != null && myChart != "" && myChart != undefined) {  
		myChart.dispose();  
	} 
	myChart = echarts.init(document.getElementById('ChartBox'));
	var option = {
		title: {
			text: ''
		},
		tooltip : {
			trigger: 'item',
			formatter: "{a} <br/>{b} : {c} ({d}%)"
		},
		
		series: [{
			name: '税费',
			type: 'pie',
			radius: ['50%', '70%'],
			color: ["#FF4500","#87CEEB", "#DB70D7"],
			data: brower
		}]
		
	};
	myChart.setOption(option);
}
