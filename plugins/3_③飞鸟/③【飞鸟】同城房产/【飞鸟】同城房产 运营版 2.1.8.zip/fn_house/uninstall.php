<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS pre_fn_house_demand;
DROP TABLE IF EXISTS pre_fn_house_info;
DROP TABLE IF EXISTS pre_fn_house_info_collection;
DROP TABLE IF EXISTS pre_fn_house_info_log;
DROP TABLE IF EXISTS pre_fn_house_info_pay_log;
DROP TABLE IF EXISTS pre_fn_house_info_report;
DROP TABLE IF EXISTS pre_fn_house_disc;
DROP TABLE IF EXISTS pre_fn_house_disc_collection;
DROP TABLE IF EXISTS pre_fn_house_disc_huxing;
DROP TABLE IF EXISTS pre_fn_house_disc_log;
DROP TABLE IF EXISTS pre_fn_house_disc_mobile;
DROP TABLE IF EXISTS pre_fn_house_entrust;
DROP TABLE IF EXISTS pre_fn_house_demand_pay_log;
DROP TABLE IF EXISTS pre_fn_house_agent;
DROP TABLE IF EXISTS pre_fn_house_agent_group;
DROP TABLE IF EXISTS pre_fn_house_agent_user;
DROP TABLE IF EXISTS pre_fn_house_agent_user_refresh_info_log;
DROP TABLE IF EXISTS pre_fn_house_article;
DROP TABLE IF EXISTS pre_fn_house_article_class;
DROP TABLE IF EXISTS pre_fn_house_wallet_log;

EOF;
runquery($sql);
$finish = TRUE;
?>