<?php

/**
 *	cronname:cron_pubid
 *	week:-1
 *	day:-1
 *	hour:-1
 *	minute:0,5,10,15,20,25,30,35,40,45,50,55
 *	desc:������ѯ
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_house/Function.inc.php');

$PayLog = DB::fetch_all('SELECT * FROM '.DB::table($Fn_House->TablePayLog).' where state = 0 and payment_type = \'app\' and pubid <> \'\' order by order_id DESC');

foreach($PayLog as $K => $V){
	if($Config['PluginVar']['AppType'] == 1){//���׶�����ѯ
		$Data = $Fn_House->GetAjaxMagCheckOrder($V['pubid'],$V['order_id']);
	}else if($Config['PluginVar']['AppType'] == 2){//ǧ��������ѯ
		$Data = $Fn_House->GetAjaxCheckQFPay($V['pubid'],$V['order_id']);
	}

	if($Data['State'] != 200 && ($V['dateline'] + 600) < time()){
		DB::delete($Fn_House->TablePayLog,'order_id = '.intval($V['order_id']));
	}
}
//From: Dism��taobao��com
?>