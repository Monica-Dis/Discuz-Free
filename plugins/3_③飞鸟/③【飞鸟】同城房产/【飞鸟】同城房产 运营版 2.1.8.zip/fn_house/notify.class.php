<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('FN_IN_API')) {
	exit('Access Denied');
}
loadcache('plugin');
function NotifyUpdatePay($OrderId,$Identification,$Money,$PayType,$TransactionId){
	global $_G;
	$OrderId = addslashes($OrderId);
	$Identification = addslashes($Identification);
	$Money = addslashes($Money);
	$PayType = addslashes($PayType);
	$TransactionId = addslashes($TransactionId);
	$TablePayLog = 'fn_pay_log';
	$TableInfo = 'fn_house_info';
	$TableInfoPayLog = 'fn_house_info_pay_log';
	$TableDemandPayLog = 'fn_house_demand_pay_log';
	$TableAgent = 'fn_house_agent';
	$TableAgentUser = 'fn_house_agent_user';
	$PayLog = DB::fetch_first('SELECT * FROM '.DB::table($TablePayLog).' where order_id = '.$OrderId.' and money = '.$Money);
	if($PayLog && $PayLog['state'] != 1){
		$Data = array('state'=>1,'payment_type'=>$PayType,'pubid'=>$TransactionId,'pay_time'=>time());
		if(DB::update($TablePayLog,$Data,'order_id='.$OrderId)){
			$PayLog['param'] = unserialize($PayLog['param']);
			if($PayLog['param']['event'] == 'publish_info'){//������Ϣ
				$UpData['payment_state'] = 1;
				if(DB::update($TableInfo,$UpData,'id = '.$PayLog['param']['iid'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'refresh_info'){//ˢ��
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableInfo,$UpData,'id = '.$PayLog['param']['iid'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'top_info'){//�ö�
				$UpData['topdateline'] = $PayLog['param']['topdateline'];
				$UpData['updateline'] = $PayLog['param']['updateline'];
				$UpData['payment_state'] = 1;
				if(DB::update($TableInfo,$UpData,'id = '.$PayLog['param']['iid'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'info_pay_log'){//����Դ��ϵ��ʽ
				$UpData = $PayLog['param']['insert_info_pay_log'];
				if(DB::insert($TableInfoPayLog,$UpData)){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'demand_pay_log'){//����������ϵ��ʽ
				$UpData = $PayLog['param']['insert_demand_pay_log'];
				if(DB::insert($TableDemandPayLog,$UpData)){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'buy_store_level'){//��������פ�ײ�
				$UpData['group_id'] = $PayLog['param']['group_id'];
				$UpData['due_time'] = $PayLog['param']['due_time'];
				$UpData['money'] = $PayLog['param']['money'];
				if(DB::update($TableAgentUser,$UpData,'id = '.$PayLog['param']['auid'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'refresh_agent_user'){//ˢ�¾������б�
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableAgentUser,$UpData,'id = '.$PayLog['param']['auid'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'top_agent_user'){//�ö��������б�
				$UpData['topdateline'] = $PayLog['param']['topdateline'];
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableAgentUser,$UpData,'id = '.$PayLog['param']['auid'])){
					DB::update($TableInfo,array('agent_id'=>$PayLog['param']['agent_id'],'publish_type'=>2),' uid = '.intval($PayLog['param']['uid']));
					return true;
				}else{
					return false;
				}
			}
		}
	}
}
//dis'.'m.t'.'ao'.'bao.com
?>