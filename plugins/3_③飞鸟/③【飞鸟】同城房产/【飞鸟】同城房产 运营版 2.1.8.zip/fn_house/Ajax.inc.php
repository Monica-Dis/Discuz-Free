<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_house/Function.inc.php');

if($_GET['f'] == 'GetAjaxPublish' && $_GET['formhash'] == formhash() && $_G['uid']){//������Ϣ
	echo urldecode(json_encode($Fn_House->GetAjaxPublish($_GET)));

}else if($_GET['f'] == 'GetAjaxPublishAgent' && $_GET['formhash'] == formhash() && $_G['uid']){//�ŵ���פ
	echo urldecode(json_encode($Fn_House->GetAjaxPublishAgent($_GET)));

}else if($_GET['f'] == 'GetAjaxBuyStoreLevel' && $_GET['formhash'] == formhash() && $_G['uid']){//��ͨ�ŵ��ײ�
	echo urldecode(json_encode($Fn_House->GetAjaxBuyStoreLevel($_GET)));

}else if($_GET['f'] == 'GetAjaxUserAgentInfo' && $_GET['formhash'] == formhash() && $_G['uid']){//�༭��������
	echo urldecode(json_encode($Fn_House->GetAjaxUserAgentInfo($_GET)));

}else if($_GET['f'] == 'GetAjaxEntrust' && $_GET['formhash'] == formhash() && $_G['uid']){//ί��
	echo urldecode(json_encode($Fn_House->GetAjaxEntrust($_GET)));

}else if($_GET['f'] == 'GetAjaxList' && $_GET['formhash'] == formhash()){//���ַ�/���ⷿ/����
	echo CJSON::encode($Fn_House->GetAjaxList($_GET));

}else if($_GET['f'] == 'GetAjaxDiscList'){//¥��

	echo CJSON::encode($Fn_House->GetAjaxDiscList($_GET));

}else if($_GET['f'] == 'GetAjaxArticleList' && $_GET['formhash'] == formhash()){//��Ѷ�б�
	echo CJSON::encode($Fn_House->GetAjaxArticleList($_GET));

}else if($_GET['f'] == 'GetAjaxAgentUserList' && $_GET['formhash'] == formhash()){//�������б�

	echo CJSON::encode($Fn_House->GetAjaxAgentUserList($_GET));

}else if($_GET['f'] == 'GetAjaxAgentList' && $_GET['formhash'] == formhash()){//�ŵ��б�

	echo CJSON::encode($Fn_House->GetAjaxAgentList($_GET));

}else if($_GET['f'] == 'GetAjaxEntrustList' && $_GET['formhash'] == formhash()){//ί��
	echo CJSON::encode($Fn_House->GetAjaxEntrustList($_GET));

}else if($_GET['f'] == 'GetAjaxDemandList' && $_GET['formhash'] == formhash()){//�������б�
	echo CJSON::encode($Fn_House->GetAjaxDemandList($_GET));

}else if($_GET['f'] == 'GetAjaxUserInfoList' && $_GET['formhash'] == formhash() && $_G['uid']){//�ҵķ�Դ
	echo CJSON::encode($Fn_House->GetAjaxUserInfoList($_GET));

}else if($_GET['f'] == 'GetAjaxUserStoreTeamList' && $_GET['formhash'] == formhash() && $_G['uid']){//�Ŷӳ�Ա
	echo CJSON::encode($Fn_House->GetAjaxUserStoreTeamList($_GET));

}else if($_GET['f'] == 'GetAjaxOpAgentUser' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['auid']){//�Ŷӳ�Ա
	echo urldecode(json_encode($Fn_House->GetAjaxOpAgentUser($_GET['auid'],$_GET['action'])));

}else if($_GET['f'] == 'GetAjaxUserInfoListLog' && $_GET['formhash'] == formhash() && $_G['uid']){//�����¼
	echo CJSON::encode($Fn_House->GetAjaxUserInfoListLog($_GET));

}else if($_GET['f'] == 'GetAjaxUserAccessrecordList' && $_GET['formhash'] == formhash() && $_G['uid']){//���ʼ�¼
	echo CJSON::encode($Fn_House->GetAjaxUserAccessrecordList($_GET));

}else if($_GET['f'] == 'GetAjaxUserInfoListCollection' && $_GET['formhash'] == formhash() && $_G['uid']){//�ղ�
	echo CJSON::encode($Fn_House->GetAjaxUserInfoListCollection($_GET));

}else if($_GET['f'] == 'GetAjaxAdminInfoList' && $_GET['formhash'] == formhash() && $_G['uid']){//�ղ�
	echo CJSON::encode($Fn_House->GetAjaxAdminInfoList($_GET));

}else if($_GET['f'] == 'GetAjaxUserInfoOp' && $_GET['formhash'] == formhash() && $_GET['Op'] && $_GET['iid'] && $_G['uid']){
	echo urldecode(json_encode($Fn_House->GetAjaxUserInfoOp($_GET['Op'],$_GET['iid'],$_GET['field'],$_GET['value'])));

}else if($_GET['f'] == 'GetAjaxUserDemandOp' && $_GET['formhash'] == formhash() && $_GET['Op'] && $_GET['did'] && $_G['uid']){
	echo urldecode(json_encode($Fn_House->GetAjaxUserDemandOp($_GET['Op'],$_GET['did'],$_GET['field'],$_GET['value'])));

}else if($_GET['f'] == 'GetAjaxInfoCollect' && $_GET['formhash'] == formhash() && $_GET['iid'] && $_G['uid']){
	echo urldecode(json_encode($Fn_House->GetAjaxInfoCollect($_GET['iid'])));

}else if($_GET['f'] == 'GetAjaxDiscCollect' && $_GET['formhash'] == formhash() && $_GET['iid'] && $_G['uid']){
	echo urldecode(json_encode($Fn_House->GetAjaxDiscCollect($_GET['iid'])));

}else if($_GET['f'] == 'GetAjaxReport' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['iid']){//�ٱ��û�
	echo urldecode(json_encode($Fn_House->GetAjaxReport($_GET)));

}else if($_GET['f'] == 'GetAjaxRefresh' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['iid'] && $_GET['class']){//ˢ��
	
	echo urldecode(json_encode($Fn_House->GetAjaxRefresh($_GET)));

}else if($_GET['f'] == 'GetAjaxInfoPayLog' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['iid']){//���Ѳ鿴��͵绰

	$SeeInfoMoney = TextareaArray($Fn_House->Config['PluginVar']['SeeInfoMoney']);
	$AppSeeInfoMoney = TextareaArray($Fn_House->Config['PluginVar']['AppSeeInfoMoney']);
	echo json_encode($Fn_House->GetAjaxPayLog(array('event'=>'info_pay_log','money'=>App && $AppSeeInfoMoney[$_GET['class']] ? $AppSeeInfoMoney[$_GET['class']] : $SeeInfoMoney[$_GET['class']],'iid'=>$_GET['iid'])));

}else if($_GET['f'] == 'GetAjaxAgentUserRefreshInfo' && $_GET['formhash'] == formhash() && $_G['uid']){//������ˢ�·�Դ
	
	echo urldecode(json_encode($Fn_House->GetAjaxAgentUserRefreshInfo($_GET)));

}else if($_GET['f'] == 'GetAjaxAgentUserRefresh' && $_GET['formhash'] == formhash() && $_G['uid']){//������ˢ��
	
	echo urldecode(json_encode($Fn_House->GetAjaxAgentUserRefresh($_GET)));

}else if($_GET['f'] == 'GetAjaxTop' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['iid'] && $_GET['class'] && $_GET['money']){//�ö�
	
	echo urldecode(json_encode($Fn_House->GetAjaxTop($_GET)));

}else if($_GET['f'] == 'GetAjaxAgentUserTop' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['money']){//�ö�������
	
	echo urldecode(json_encode($Fn_House->GetAjaxAgentUserTop($_GET)));

	//echo json_encode($Fn_House->GetAjaxPayLog(array('event'=>'top_agent_user','money'=>$_GET['money'],'day'=>$_GET['day'],'auid'=>$_GET['auid'])));

}else if($_GET['f'] == 'GetAjaxDemandPayLog' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['did']){//���Ѳ鿴��͵绰

	$Money = $Fn_House->Config['PluginVar']['DemandAppMoney'] && App ? $Fn_House->Config['PluginVar']['DemandAppMoney'] : $Fn_House->Config['PluginVar']['DemandMoney'];
	echo json_encode($Fn_House->GetAjaxPayLog(array('event'=>'demand_pay_log','money'=>$Money,'did'=>$_GET['did'])));

}else if($_GET['f'] == 'GetAjaxUpload' && $_GET['formhash'] == formhash()){//�ϴ�ͼƬ
	echo urldecode(json_encode(GetAjaxUpload($_FILES)));

}else if($_GET['f'] == 'GetAjaxMobile' && $_GET['formhash'] == formhash()){
	echo urldecode(json_encode($Fn_House->GetAjaxMobile($_GET)));

}else if($_GET['f'] == 'GetAjaxAdminEditInfoFields' && $_GET['formhash'] == formhash() && $_G['uid']){//����Ա�޸��ֶ�ֵ
	echo urldecode(json_encode($Fn_House->GetAjaxAdminEditInfoFields($_GET['iid'],$_GET['field'],$_GET['val'])));
}
//From: Dism��taobao��com
?>