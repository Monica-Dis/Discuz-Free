<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once libfile('function/core','plugin/fn_assembly');
@require_once libfile('class/magapp','plugin/fn_assembly');
@require_once libfile('class/qfapp','plugin/fn_assembly');
@require_once libfile('class/pay','plugin/fn_assembly');
@require_once libfile('class/json','plugin/fn_assembly');

class Fn_House{
	public function __construct() {
		global $_G,$plugin,$Config;
		loadcache('plugin');
		loadcache('fn_house_setting');
		foreach($_G['cache']['fn_house_setting'] as $key => $value) {
			$this->Config['PluginVar'][$key] = is_array($value) ? $value : stripslashes($value);
		}
		//������ά�뿪��
		if(!$this->Config['PluginVar']['QrParameterSwitch'] && QrParameterSwitch){
			$this->Config['PluginVar']['WxAppid'] = $Config['PluginVar']['WxAppid'];
			$this->Config['PluginVar']['WxSecret'] = $Config['PluginVar']['WxSecret'];
		}
		$this->Config['PluginVar']['QrParameterSwitch'] = $this->Config['PluginVar']['QrParameterSwitch'] ? $this->Config['PluginVar']['QrParameterSwitch'] : (QrParameterSwitch ? QrParameterSwitch : 0);
		//������ά�뿪�� End
		$this->Area = SelectArray($this->Config['PluginVar']['Area']);
		$this->Config['LangVar'] = lang('plugin/fn_house');
		$this->Config['LangVar']['ManagementTpyeArray'] = TextareaArray($this->Config['PluginVar']['ManagementTpyeList']);
		$this->Config['LangVar']['ShopManagementTypeArray'] = TextareaArray($this->Config['PluginVar']['ShopTypeList']);
		$this->Config['LangVar']['DepositArray'] = TextareaArray($this->Config['PluginVar']['DepositList']);
		$this->Config['LangVar']['YearsArray'] = TextareaArray($this->Config['PluginVar']['YearsList']);
		$this->Config['LangVar']['HouseTypeArray'] = TextareaArray($this->Config['PluginVar']['HouseTypeList']);
		$this->Config['LangVar']['PropertyRightArray'] = TextareaArray($this->Config['PluginVar']['PropertyRightList']);
		$this->Config['LangVar']['HouseTagArray'] = TextareaArray($this->Config['PluginVar']['HouseTagList']);
		$this->Config['LangVar']['RentalHouseTagArray'] = TextareaArray($this->Config['PluginVar']['RentalHouseTagList']);
		$this->Config['LangVar']['ShopTagArray'] = TextareaArray($this->Config['PluginVar']['ShopTagList']);
		$this->Config['LangVar']['WorkShopTagArray'] = TextareaArray($this->Config['PluginVar']['WorkShopTagList']);
		$this->Config['LangVar']['OfficeTagArray'] = TextareaArray($this->Config['PluginVar']['OfficeTagList']);
		$this->Config['LangVar']['WarehouseTagArray'] = TextareaArray($this->Config['PluginVar']['WarehouseTagList']);
		$this->Config['LangVar']['LandTagArray'] = TextareaArray($this->Config['PluginVar']['LandTagList']);
		$this->Config['LangVar']['ConfigureTagArray'] = TextareaArray($this->Config['PluginVar']['ConfigureTagList']);
		$this->Config['LangVar']['RentTimeArray'] = TextareaArray($this->Config['PluginVar']['RentTime']);
		$this->Config['LangVar']['DiscDecorationArray'] = TextareaArray($this->Config['PluginVar']['DiscDecorationTag']);
		$this->Config['LangVar']['DiscHouseTypeArray'] = TextareaArray($this->Config['PluginVar']['DiscHouseTypeList']);
		$this->Config['LangVar']['DiscTagArray'] = TextareaArray($this->Config['PluginVar']['DiscTagList']);
		$this->Config['LangVar']['DiscHuXingTagArray'] = TextareaArray($this->Config['PluginVar']['DiscHuXingTagList']);
		$this->Config['LangVar']['DiscJiaGeArray'] = TextareaArray($this->Config['PluginVar']['DiscJiaGeList']);
		$this->Config['LangVar']['BusinessRateArray'] = TextareaArray($this->Config['PluginVar']['BusinessRateArray']);
		$this->Config['LangVar']['FundRateArray'] = TextareaArray($this->Config['PluginVar']['FundRateArray']);
		$this->Config['LangVar']['LoanTermArray'] = TextareaArray($this->Config['PluginVar']['LoanTermArray']);
		
		$this->Config['PluginVar']['InfoNavList'] = explode(',',$this->Config['PluginVar']['InfoNavList']);
		$this->Config['PluginVar']['ModularListCount'] = count($this->Config['PluginVar']['ModularList']);

		$this->AdminUidsList = array_filter(explode(",",$this->Config['PluginVar']['AdminUids']));
		$this->Admin = in_array($_G['uid'],$this->AdminUidsList) ? true : false;
		$this->Config['PluginVar']['ProhibitUis'] = array_filter(explode(",",$this->Config['PluginVar']['ProhibitUis']));
		$this->Config['PluginVar']['GlobalProhibitUis'] = array_filter(explode(",",$this->Config['PluginVar']['GlobalProhibitUis']));

		$this->Config['Path'] = 'source/plugin/fn_house';
		$this->Config['StaticPath'] = $_G['siteroot'].$this->Config['Path'].'/static';
		$this->Config['StaticPicPath'] = $this->Config['Path'].'/attachment/';
		$this->Config['Url'] = $_G['siteurl'].'plugin.php?id=fn_house'.($_GET['formapp'] ? '&formapp='.$_GET['formapp'] : '');
		$this->Config['ListUrl'] = $this->Config['Url'].'&m=list';
		$this->Config['ListDiscUrl'] = $this->Config['Url'].'&m=list_disc';
		$this->Config['ListEntrustUrl'] = $this->Config['Url'].'&m=list_entrust';
		$this->Config['ListStoreUrl'] = $this->Config['Url'].'&m=list_store';
		$this->Config['ListAgentUrl'] = $this->Config['Url'].'&m=list_agent';
		$this->Config['ListArticleUrl'] = $this->Config['Url'].'&m=list_article';
		$this->Config['UserUrl'] = $this->Config['Url'].'&m=user';
		$this->Config['ViewUrl'] = $this->Config['Url'].'&m=view&iid=';
		$this->Config['ViewDiscUrl'] = $this->Config['Url'].'&m=view_disc&iid=';
		$this->Config['ViewArticleUrl'] = $this->Config['Url'].'&m=view_article&aid=';
		$this->Config['CalculationUrl'] = $this->Config['Url'].'&m=calculation';
		$this->Config['PublishAgentUrl'] = $this->Config['Url'].'&m=publish_agent';
		$this->Config['ViewAgentUrl'] = $this->Config['Url'].'&m=view_agent&auid=';
		$this->Config['StoreUrl'] = $this->Config['Url'].'&m=store&aid=';
		$this->Config['StoreJoinUrl'] = $this->Config['Url'].'&m=store_join&aid=';
		$this->Config['UserStoreTeamUrl'] = $this->Config['Url'].'&m=user_store_team';
		$this->Config['EntrustUrl'] = $this->Config['Url'].'&m=entrust';
		$this->Config['PublishUrl'] = $this->Config['Url'].'&m=publish';
		$this->Config['DemandListUrl'] = $this->Config['Url'].'&m=demand_list&type=';
		$this->Config['UserInfoListUrl'] = $this->Config['Url'].'&m=user_info_list';
		$this->Config['UserAccessRecordListUrl'] = $this->Config['Url'].'&m=user_access_record_list&iid=';
		$this->Config['UserEntrustListUrl'] = $this->Config['Url'].'&m=user_entrust_list';
		$this->Config['UserAgentInfoUrl'] = $this->Config['Url'].'&m=user_agent_info';
		$this->Config['UserInfoListLogUrl'] = $this->Config['Url'].'&m=user_info_list_log';
		$this->Config['UserInfoListCollectionUrl'] = $this->Config['Url'].'&m=user_info_list_collection';
		$this->Config['UserDiscListCollectionUrl'] = $this->Config['Url'].'&m=user_disc_list_collection';
		$this->Config['UserDemandListUrl'] = $this->Config['Url'].'&m=user_demand_list&type=';
		$this->Config['BuyStoreLevelUrl'] = $this->Config['Url'].'&m=buy_store_level';
		$this->Config['AdminInfoListUrl'] = $this->Config['Url'].'&m=admin_info_list';
		
		$this->Config['AjaxUrl'] =  $_G['siteroot'].'plugin.php?id=fn_house:Ajax'.($_GET['formapp'] ? '&formapp='.$_GET['formapp'] : '');
		$this->Config['WxShare'] = array(
			'WxTitle' => $this->Config['PluginVar']['WxTitle'],
			'WxDes' => $this->Config['PluginVar']['WxDes'],
			'WxImg' => strpos($this->Config['PluginVar']['WxImg'],'http') !== false ? $this->Config['PluginVar']['WxImg'] : $_G['siteurl'].$this->Config['PluginVar']['WxImg'],
			'WxUrl' => $this->Rewrite('index')
		);


		if(!is_dir(DISCUZ_ROOT.$this->Config['StaticPicPath'])){
			dmkdir(DISCUZ_ROOT.$this->Config['StaticPicPath']);
		}
		
		$this->TableArticle = 'fn_house_article';
		$this->TableArticleClass = 'fn_house_article_class';
		$this->TableInfo = 'fn_house_info';
		$this->TableInfoLog = 'fn_house_info_log';
		$this->TableInfoPayLog = 'fn_house_info_pay_log';
		$this->TableInfoReport = 'fn_house_info_report';
		$this->TableInfoCollection = 'fn_house_info_collection';
		$this->TableDemand = 'fn_house_demand';
		$this->TableDemandPayLog = 'fn_house_demand_pay_log';
		$this->TablePayLog = 'fn_house_pay_log';
		$this->TableDisc = 'fn_house_disc';
		$this->TableDiscMobile = 'fn_house_disc_mobile';
		$this->TableDiscCollection = 'fn_house_disc_collection';
		$this->TableDiscLog = 'fn_house_disc_log';
		$this->TableDiscHuXing = 'fn_house_disc_huxing';
		$this->TableEntrust = 'fn_house_entrust';
		$this->TableAgentGroup = 'fn_house_agent_group';
		$this->TableAgent = 'fn_house_agent';
		$this->TableAgentUser = 'fn_house_agent_user';
		$this->TableAgentUserRefreshInfoLog = 'fn_house_agent_user_refresh_info_log';
		$this->TableWalletLog = 'fn_house_wallet_log';
		
		$this->Pay = new Fn_PayLog();
		$this->MagApp = new MagApp($this->Config['PluginVar']['MagSecret'],$this->Config['PluginVar']['MagAssistantSecret'],$this->Config['PluginVar']['MagAssistantPush']);
		$this->QHApp = new QHApp($this->Config['PluginVar']['qf_type'],$this->Config['PluginVar']['qf_sr_type'],$this->Config['PluginVar']['qf_from_id']);
		$this->Config['AppPaymentId'] = $this->QHApp->AppPaymentId;
		
		
	}

	public function GetUserInfo($Auid=''){
		global $_G,$Config;

		@require_once libfile('function/forum');

		$Where = $Auid ? 'where AU.id='.intval($Auid) : 'where AU.uid='.intval($_G['uid']);
		
		$UserInfo = DB::fetch_first('SELECT AU.*,A.title as store_title,A.dateline as store_dateline,A.click as agent_click,A.display as store_display,A.province,A.city,A.dist,A.community,AG.ico,AG.day_info_count,AG.info_count,AG.examine,AG.entrust_data,AG.access_record,AG.access_record_mobile,AG.info_my,AG.vr,AG.day_refresh_count,AG.top_discount FROM '.DB::table($this->TableAgentUser).' AU LEFT JOIN `'.DB::table($this->TableAgent).'` A on A.id = AU.agent_id LEFT JOIN `'.DB::table($this->TableAgentGroup).'` AG on AG.id = AU.group_id '.$Where.' order by id desc');
		
		if($UserInfo){
			
			
			$UserInfo['intermediary'] = $UserInfo['work_state'] == 1 ? true : false;
			$UserInfo['vip'] = $UserInfo['due_time'] >= time() ? true : false;
//
			$UserInfo['username'] = $UserInfo['name'];
			$UserInfo['logo'] = $UserInfo['logo'] ? $UserInfo['logo'] : discuz_uc_avatar($_G['uid'],middle,true);
			$UserInfo['mobile'] =  $UserInfo['mobile'] ? $UserInfo['mobile'] : GetMobile();

			$UserInfo['province_text'] = $this->Area[$UserInfo['province']]['content'].($UserInfo['city'] ? '-'.$this->Area[$UserInfo['city']]['content'] : '').($UserInfo['dist'] ? '-'.$this->Area[$UserInfo['dist']]['content'] : '');

//			$UserInfo['info_store_count'] =  DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and agent_id = '.$UserInfo['agent_id']);
//
//			$UserInfo['info_store_click_count'] =  DB::result_first('SELECT sum(click) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and agent_id = '.$UserInfo['agent_id']);
//
//			$UserInfo['info_store_click_count'] = $UserInfo['info_store_click_count'] ? $UserInfo['info_store_click_count'] : 0;

			$UserInfo['info_agent_count'] =  DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and uid = '.$UserInfo['uid']);

			$UserInfo['info_agent_click_count'] =  DB::result_first('SELECT sum(click) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and uid = '.$UserInfo['uid']);

			$UserInfo['info_agent_click_count'] = $UserInfo['info_agent_click_count'] ? $UserInfo['info_agent_click_count'] : 0;
		
			$UserInfo['info_agent_reduce_day_count'] = $UserInfo['day_info_count'] - DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and uid = '.intval($_G['uid']).' and dateline >= '.strtotime(date('Y-m-d',time())).' and dateline <= '.strtotime(date('Y-m-d 23:59:59',time())));

			$UserInfo['info_agent_reduce_count'] = $UserInfo['info_count'] - DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and deal = 0 and uid = '.intval($_G['uid']).($UserInfo['before_dateline'] ? ' and dateline >= '.$UserInfo['before_dateline'] : ''));;
			
			$UserInfo['info_agent_reduce_day_refresh_count'] = $UserInfo['day_refresh_count'] - DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableAgentUserRefreshInfoLog).' where uid = '.intval($_G['uid']).' and type = 1 and dateline >= '.strtotime(date('Y-m-d',time())).' and dateline <= '.strtotime(date('Y-m-d 23:59:59',time())));

			
			foreach(array_filter(explode(",",$this->Config['PluginVar']['HomeSearch'])) as $Val) {
				if(in_array($Val,array(1,2,3,4,5,6,7))){
					$UserInfo['info_agent_count_array'][$Val] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where display = 1 and payment_state = 1 and class = '.$Val.' and uid = '.$UserInfo['uid']);
				}
			}

		}else if(!$UserInfo){
			$UserInfo['face'] = discuz_uc_avatar($_G['uid'],middle,true);
			$UserInfo['mobile'] = GetMobile();
			$UserInfo['username'] = $_G['username'];
		}
		return $UserInfo;
	}

	/* ���� */
	public function GetViewthread($Id){
		
		$Item = DB::fetch_first('SELECT I.* FROM '.DB::table($this->TableInfo).' I where I.id = '.intval($Id));
		if($Item){
			@require_once libfile('function/forum');
			$Item['param'] = unserialize($Item['param']);
			$Item['param']['price_time'] = $Item['param']['price_time'] ? $Item['param']['price_time'] : 2;
			$Item['content'] = $Item['content'] ? $Item['content'] : $Item['param']['content'];
			$Item['content'] = str_replace("\r\n","<br>",stripslashes($Item['content']));
			$Item['param']['cover'] = $Item['param']['cover'] ? $Item['param']['cover'] : $this->Config['PluginVar']['CoverPath'];
			$Item['configure_list'] = array_filter(explode(",",$Item['configure']));
			
			$Item['huxing'] = $Item['room'].$this->Config['LangVar']['Room'].$Item['office'].$this->Config['LangVar']['Office'].$Item['guard'].$this->Config['LangVar']['Guard'];
			$Item['province_text'] = $this->Area[$Item['province']]['content'].($Item['city'] ? '-'.$this->Area[$Item['city']]['content'] : '').($Item['dist'] ? '-'.$this->Area[$Item['dist']]['content'] : '');
			if($Item['class'] == 1){
				$Item['unit_price'] = $Item['price'] ? intval($Item['price'] * 10000 / $Item['square']) : '';
			}

			$AgentUser = DB::fetch_first('SELECT * FROM '.DB::table($this->TableAgentUser).' where uid = '.intval($Item['uid']).' and agent_id = '.intval($Item['agent_id']));

			$AgentUser =  $AgentUser ? $this->GetUserInfo($AgentUser['id']) : '';
			$Item['face'] = $AgentUser['intermediary'] ? $AgentUser['face'] : discuz_uc_avatar($Item['uid'],middle,true);
			$Item['agent_user'] = $AgentUser;
			$Item['name'] = $AgentUser['intermediary'] && $AgentUser['name'] ? $AgentUser['name'] : $Item['name'];
			$Item['mobile'] = $Item['mobile'] ? $Item['mobile'] : $Item['param']['mobile'];
			$Item['mobile'] = $Item['agent_user']['vip'] || $Item['agent_user']['due_time'] ? $Item['agent_user']['mobile'] : $Item['mobile'];
			$Item['param']['wx'] = $Item['agent_user']['vip'] || $Item['agent_user']['due_time'] ? $Item['agent_user']['wx'] : $Item['param']['wx'];

		}
		return $Item;
	}

	/* ¥������ */
	public function GetViewDiscthread($Id){
		
		$Item = DB::fetch_first('SELECT D.* FROM '.DB::table($this->TableDisc).' D where D.id = '.intval($Id));
		if($Item){
			@require_once libfile('function/forum');
			$Item['url'] = $this->Rewrite('view_disc',array('iid'=>$Item['id']));
			$Item['param'] = unserialize($Item['param']);
			$Item['param']['content'] = stripslashes($Item['param']['content']);
			$Item['param']['sales_community'] = $Item['param']['sales_community'] ? $Item['param']['sales_community'] : $Item['community'];
			$Item['province_text'] = $this->Area[$Item['province']]['content'].($Item['city'] ? '-'.$this->Area[$Item['city']]['content'] : '').($Item['dist'] ? '-'.$this->Area[$Item['dist']]['content'] : '');
			if(!$Item['price']){
				$Item['price'] = $this->Config['LangVar']['PriceUndetermined'];
				$Item['price_text'] = '';
			}elseif($Item['price'] == 9999999){
				$Item['price'] = $this->Config['LangVar']['YiFangYiJia'];
				$Item['price_text'] = '';
			}else{
				$Item['price_text'] = $this->Config['LangVar']['Yuan'].'/'.$this->Config['LangVar']['SquareMetre'];
			}
		}
		return $Item;
	}

	/* ��Ѷ���� */
	public function GetViewArticlethread($Id){
		$Item = DB::fetch_first('SELECT A.*,C.title as class_title,D.title as disc_title FROM '.DB::table($this->TableArticle).' A LEFT JOIN `'.DB::table($this->TableArticleClass).'` C on C.id = A.classid LEFT JOIN `'.DB::table($this->TableDisc).'` D on D.id = A.disc_id where A.id = '.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['content'] = stripslashes($Item['content']);
			$Item['prev'] = DB::fetch_first('SELECT A.* FROM '.DB::table($this->TableArticle).' A where A.classid = '.intval($Item['classid']).' and A.display = 1 and A.id < '.intval($Item['id']));
			$Item['next'] = DB::fetch_first('SELECT A.* FROM '.DB::table($this->TableArticle).' A where A.classid = '.intval($Item['classid']).' and A.display = 1 and A.id > '.intval($Item['id']));
			$Item['prev_html'] = $Item['prev'] ? '<a href="'.$this->Rewrite('view_article',array('aid'=>$Item['prev']['id'])).'" class="prev">'.$this->Config['LangVar']['Prev'].':<span>'.$Item['prev']['title'].'</span></a>' : '<a class="prev">'.$this->Config['LangVar']['Prev'].':<span>'.$this->Config['LangVar']['MeiYouLe'].'</span></a>';
			$Item['next_html'] = $Item['next'] ? '<a href="'.$this->Rewrite('view_article',array('aid'=>$Item['next']['id'])).'" class="next">'.$this->Config['LangVar']['Next'].':<span>'.$Item['next']['title'].'</span></a>' : '<a class="next">'.$this->Config['LangVar']['Next'].':<span>'.$this->Config['LangVar']['MeiYouLe'].'</span></a>';
		}

		return $Item;
	}

	/* �û��Լ�������Ϣ */
	public function GetMyViewthread($Class,$Id,$Where = null,$Admin = false){
		global $_G;
		if($Class == 99){//������
			$Item = DB::fetch_first('SELECT D.* FROM '.DB::table($this->TableDemand).' D where D.uid = '.intval($_G['uid']).' and D.id = '.intval($Id));
			if($Item){
				$Item['param'] = unserialize($Item['param']);
				$Item['province_text'] = $this->Area[$Item['province']]['content'].($Item['city'] ? '-'.$this->Area[$Item['city']]['content'] : '').($Item['dist'] ? '-'.$this->Area[$Item['dist']]['content'] : '');
			}
		}else{
			
			$Item = DB::fetch_first('SELECT I.* FROM '.DB::table($this->TableInfo).' I where I.id = '.intval($Id).($Admin != true ? ' and I.uid = '.intval($_G['uid']) : '').' and I.class = '.intval($Class).$Where);
			
			if($Item){
				$Item['param'] = unserialize($Item['param']);
				$Item['huxing'] = $Item['room'].$this->Config['LangVar']['Room'].$Item['office'].$this->Config['LangVar']['Office'].$Item['guard'].$this->Config['LangVar']['Guard'];
				$Item['province_text'] = $this->Area[$Item['province']]['content'].($Item['city'] ? '-'.$this->Area[$Item['city']]['content'] : '').($Item['dist'] ? '-'.$this->Area[$Item['dist']]['content'] : '');
				$Item['mobile'] = $Item['mobile'] ? $Item['mobile'] : $Item['param']['mobile'];
				$Item['content'] = $Item['content'] ? $Item['content'] : $Item['param']['content'];
				$Item['content'] = str_replace("\r\n","<br>",stripslashes($Item['content']));
			};
		}
		
		return $Item;
	}

	/* �б� */
	public function GetAjaxList($Get){
		$Results = array();
		$Get = StrToGBK($Get);
		$Page = $Get['page'] ? intval($Get['page']):0;
		$Where = ' and I.display = 1 and I.payment_state = 1';
		$Order = in_array($Get['order'],array('updateline','dateline')) ? 'I.'.$Get['order'] : 'I.updateline';

		if($this->Config['PluginVar']['ExpiryTime']){
			$Where .= ' and ( I.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()).' or I.topdateline >= '.time().' ) ';
		}
		
		if($Get['agent_id']){
			$Where .= ' and I.agent_id = '.intval($Get['agent_id']);
		}

		if($Get['new_uid']){
			$Where .= ' and I.uid = '.intval($Get['new_uid']);
		}

		if($Get['class']){
			$Where .= ' and I.class = '.intval($Get['class']);
		}

		if($Get['vice_class']){
			$Where .= ' and I.vice_class = '.intval($Get['vice_class']);
		}

		if($Get['vr_url']){
			$Where .= ' and I.vr_url != \'\'';
		}

		if($Get['publish_type']){
			$Where .= ' and I.publish_type = '.intval($Get['publish_type']);
		}

		if($Get['keyword']){
			$Where .= ' and (I.title like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') or I.name like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') or I.small_area like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') or I.id = '.intval($Get['keyword']).' )';
		}

		if($Get['province']){
			$Where .= ' and I.province = \''.addslashes(strip_tags($Get['province'])).'\'';
			if($Get['city']){
				$Where .= ' and I.city = \''.addslashes(strip_tags($Get['city'])).'\'';
				if($Get['dist']){
					$Where .= ' and I.dist = \''.addslashes(strip_tags($Get['dist'])).'\'';
				}
			}
		}

		if($Get['price']){
			$PriceArray = explode('-',$Get['price']);
			if($PriceArray[0] && $PriceArray[1]){
				$Where .= ' and I.price >= '.intval($PriceArray[0]).' and I.price <='.intval($PriceArray[1]);
			}else if($PriceArray[0]){
				$Where .= ' and I.price <='.intval($PriceArray[0]);
			}else if($PriceArray[1]){
				$Where .= ' and I.price >='.intval($PriceArray[1]);
			}
		}

		if($Get['square']){
			$SquareArray = explode('-',$Get['square']);
			if($SquareArray[0] && $SquareArray[1]){
				$Where .= ' and I.square >= '.intval($SquareArray[0]).' and I.square <='.intval($SquareArray[1]);
			}else if($SquareArray[0]){
				$Where .= ' and I.square <='.intval($SquareArray[0]);
			}else if($SquareArray[1]){
				$Where .= ' and I.square >='.intval($SquareArray[1]);
			}
		}

		if($Get['room']){
			$Where .= $Get['room'] >= 6 ? ' and I.room >= '.intval($Get['room']) : ' and I.room = '.intval($Get['room']);
		}

		if($Get['house_type']){
			$Where .= ' and I.house_type = '.intval($Get['house_type']);
		}

		if($Get['decoration_type']){
			$Where .= ' and I.decoration_type = '.intval($Get['decoration_type']);
		}

		if($Get['orientation']){
			$Where .= ' and I.orientation = '.intval($Get['orientation']);
		}

		if($Get['shops_type']){
			$Where .= ' and I.shops_type = '.intval($Get['shops_type']);
		}

		if($Get['management_type']){
			$Where .= ' and (';
			foreach (array_filter(explode(',',$Get['management_type'])) as $Key => $Val) {
				if($Val == end(array_filter(explode(',',$Get['management_type'])))){
					$Where .= ' I.management_type = '.intval($Val);
				}else{
					$Where .= ' I.management_type = '.intval($Val).' or';
				}
			}
			$Where .= ')';
		}

		if($Get['configure']){
			foreach (array_filter(explode(',',$Get['configure'])) as $Key => $Val) {
				$Where .= ' and FIND_IN_SET('.intval($Val).',I.configure)';
			}
		}
		
		if($Get['tag']){
			foreach (array_filter(explode(',',$Get['tag'])) as $Key => $Val) {
				$Where .= ' and FIND_IN_SET('.intval($Val).',I.tag)';
			}
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$FetchSql = 'SELECT I.* FROM '.DB::table($this->TableInfo).' I'.$Where.' order by I.topdateline > '.time().' desc,'.$Order.' desc,I.id desc '.$Limit;
		$Results = $this->InfoListFormat(DB::fetch_all($FetchSql),$this->Config['PluginVar']['ListClickSwitch'] ? true : false);
		
		return $Results;
	}

	/* ¥���б� */
	public function GetAjaxDiscList($Get){
		$Results = array();
		$Get = StrToGBK($Get);
		$Page = $Get['page'] ? intval($Get['page']):0;
		$Where = ' and D.display = 1';
		$Order = 'D.updateline';
	
		if($Get['keyword']){
			$Where .= ' and ( D.title like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
		}

		if($Get['province']){
			$Where .= ' and D.province = \''.addslashes(strip_tags($Get['province'])).'\'';
			if($Get['city']){
				$Where .= ' and D.city = \''.addslashes(strip_tags($Get['city'])).'\'';
				if($Get['dist']){
					$Where .= ' and D.dist = \''.addslashes(strip_tags($Get['dist'])).'\'';
				}
			}
		}

		if($Get['price']){
			$PriceArray = explode('-',$Get['price']);
			if($PriceArray[0] && $PriceArray[1]){
				$Where .= ' and D.price >= '.intval($PriceArray[0]).' and D.price <='.intval($PriceArray[1]);
			}else if($PriceArray[0]){
				$Where .= ' and D.price <='.intval($PriceArray[0]);
			}else if($PriceArray[1]){
				$Where .= ' and D.price >='.intval($PriceArray[1]);
			}
		}

		if($Get['state']){
			$Where .= ' and D.state = '.intval($Get['state']);
		}

		if($Get['house_type']){
			foreach (array_filter(explode(',',$Get['house_type'])) as $Key => $Val) {
				$Where .= ' and FIND_IN_SET('.intval($Val).',D.house_type)';
			}
		}

		if($Get['decoration_type']){
			$Where .= ' and D.decoration_type = '.intval($Get['decoration_type']);
		}

		if($Get['type']){
			$Where .= ' and D.type = '.intval($Get['type']);
		}
	
		if($Get['tag']){
			foreach (array_filter(explode(',',$Get['tag'])) as $Key => $Val) {
				$Where .= ' and FIND_IN_SET('.intval($Val).',D.tag)';
			}
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$FetchSql = 'SELECT D.* FROM '.DB::table($this->TableDisc).' D '.$Where.' order by D.topdateline > '.time().' desc,'.$Order.' desc,D.dateline desc '.$Limit;
		$Results = $this->DiscListFormat(DB::fetch_all($FetchSql),true);
		
		return $Results;
	}

	/* ¥���б� */
	public function GetAjaxEntrustList($Get){
		$Results = array();
		$Get = StrToGBK($Get);
		$Page = $Get['page'] ? intval($Get['page']):0;
		$Where = '';
		$Order = 'E.dateline';
	
		if($Get['keyword']){
			$Where .= ' and ( E.address like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
		}

		if($Get['class']){
			$Where .= ' and E.class = '.intval($Get['class']);
		}
		
		if($Get['square']){
			$SquareArray = explode('-',$Get['square']);
			if($SquareArray[0] && $SquareArray[1]){
				$Where .= ' and E.square >= '.intval($SquareArray[0]).' and E.square <='.intval($SquareArray[1]);
			}else if($SquareArray[0]){
				$Where .= ' and E.square <='.intval($SquareArray[0]);
			}else if($SquareArray[1]){
				$Where .= ' and E.square >='.intval($SquareArray[1]);
			}
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$FetchSql = 'SELECT E.* FROM '.DB::table($this->TableEntrust).' E '.$Where.' order by '.$Order.' desc '.$Limit;
		$Results = $this->EntrustListFormat(DB::fetch_all($FetchSql));
		
		return $Results;
	}
	
	/* �ö���Դ */
	public function GetInfoIndexTopList($Class=null){
		$Results = array();
		if($Class){
			$Where = ' and class in('.intval($Class).')';
		}
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableInfo).' where topdateline >= '.time().' and payment_state = 1 and display = 1 '.$Where.' order by updateline desc';
		$Results = $this->InfoListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}

	/* ��ҳͳ�� */
	public function GetIndexCount(){
		$Count = array();
		$Count['hand'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and display = 1 and class = 1');
		$Count['disc'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableDisc).' where display = 1');
		$Count['agent'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableAgentUser).' where work_state = 1 and due_time >= '.time());
		return $Count;
	}

	/* ��ҳ�Ƽ� */
	public function GetInfoIndexList($Class,$ViceClass=null){
		$Results = array();
		if($ViceClass){
			$Where = ' and vice_class in('.intval($ViceClass).')';
		}
		if($this->Config['PluginVar']['IndexHotSwitch']){
			$Where .= ' and hot = 1';
		}

		if($this->Config['PluginVar']['ExpiryTime']){
			$Where .= ' and updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time());
		}

		$limit = checkmobile() ? $this->Config['PluginVar']['IndexListNum'] : 10;

		$limit = $limit ? $limit : 5;
		
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableInfo).' where class = '.intval($Class).' and payment_state = 1 and display = 1 '.$Where.' order by topdateline > '.time().' desc,updateline desc limit 0,'.$limit;

		$Results = $this->InfoListFormat(DB::fetch_all($FetchSql));

		return $Results;

	}

	/* ��ҳ¥���Ƽ� */
	public function GetDiscIndexList($Get = array()){
		$Results = array();
	
		if($this->Config['PluginVar']['IndexDiscHotSwitch'] || $Get['hot']){
			$Where .= ' and hot = 1';
		}

		$limit = $Get['limit'] ? $Get['limit'] : $this->Config['PluginVar']['IndexDiscNum'];
		
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableDisc).' where display = 1 '.$Where.' order by topdateline > '.time().' desc,updateline desc limit 0,'.$limit;

		$Results = $this->DiscListFormat(DB::fetch_all($FetchSql));

		return $Results;

	}
	
	/* �ҵķ�Դ */
	public function GetAjaxUserInfoList($Get){
		global $_G;
		$UserInfo = $this->GetUserInfo();
		$Results = array();
		$Get = StrToGBK($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0;
		
		if($UserInfo['work_state'] == 1 && $UserInfo['identity'] == 1){//�ŵ����Ա
			$Where = ' and I.payment_state = 1 and  I.agent_id = '.intval($UserInfo['agent_id']);
		}else{
			$Where = ' and I.payment_state = 1 and  I.uid = '.intval($_G['uid']);
		}
		$Order = 'I.updateline';
		

		if($Get['keyword']){
			$Where .= ' and (I.title like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') or I.name like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') or I.small_area like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') or I.username like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') or I.id = '.intval($Get['keyword']).' )';
		}


		if(intval($Get['class'])){
			$Where .= ' and I.class = '.intval($Get['class']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $Get['limit'] ? $Get['limit'] : 10;
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];
		
		$FetchSql = 'SELECT I.* FROM '.DB::table($this->TableInfo).' I'.$Where.' order by I.topdateline > '.time().' desc,'.$Order.' desc,I.dateline desc '.$Limit;
		$Results = $this->InfoListFormat(DB::fetch_all($FetchSql));

		return $Results;
	}

	/* �����¼ */
	public function GetAjaxUserInfoListLog($Get){
		global $_G;
		$Results = array();
		$Get = StrToGBK($Get);
		$Page = $Get['page'] ? intval($Get['page']) : 0;
		
		$Where = ' and L.uid = '.intval($_G['uid']);
		$Order = 'L.updateline';
		
		if($Get['class']){
			$Where .= ' and I.class = '.intval($Get['class']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];
		
		if($Get['class'] == 88){
			$Where = ' and L.uid = '.intval($_G['uid']);
			$Results = $this->DiscListFormat(DB::fetch_all("SELECT D.*,L.updateline as see_updateline FROM %t AS L,%t AS D where D.id = L.iid ".$Where." order by $Order desc,L.dateline desc $Limit",array($this->TableDiscLog,$this->TableDisc)));
		}else{
			$Results = $this->InfoListFormat(DB::fetch_all("SELECT I.*,L.updateline as see_updateline FROM %t AS L,%t AS I ".$Where." And I.id = L.iid order by $Order desc,L.dateline desc $Limit",array($this->TableInfoLog,$this->TableInfo)));
		}
		return $Results;

	}

	/* ��Դ���ʼ�¼ */
	public function GetAjaxUserAccessrecordList($Get){
		global $_G;
		$Results = array();
		$Get = StrToGBK($Get);
		$Page = $Get['page'] ? intval($Get['page']) : 0;
		
		$Order = 'L.updateline';
		
		if($Get['iid']){
			$Where .= ' and L.iid = '.intval($Get['iid']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 'LIMIT '.($Page * 20).',20';
		$Results = $this->AccessrecordListFormat(DB::fetch_all("SELECT L.* FROM %t AS L,%t AS I ".$Where." And I.id = L.iid order by $Order desc,L.dateline desc $Limit",array($this->TableInfoLog,$this->TableInfo)));
		
		return $Results;

	}

	/* �ҵ��ղؼ�¼ */
	public function GetAjaxUserInfoListCollection($Get){
		global $_G;
		$Results = array();
		$Get = StrToGBK($Get);
		$Page = $Get['page'] ? intval($Get['page']) : 0;
		
		$Where = ' and C.uid = '.intval($_G['uid']);
		$Order = 'C.dateline';
		
		if($Get['class']){
			$Where .= ' and I.class = '.intval($Get['class']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];
		
		if($Get['class'] == 88){
			$Results = $this->DiscListFormat(DB::fetch_all("SELECT D.* FROM %t AS C,%t AS D where D.id = C.iid and C.uid = ".intval($_G['uid'])." order by $Order desc,C.id desc $Limit",array($this->TableDiscCollection,$this->TableDisc)));
		}else{
			$Results = $this->InfoListFormat(DB::fetch_all("SELECT I.* FROM %t AS C,%t AS I ".$Where." And I.id = C.iid order by $Order desc,C.id desc $Limit",array($this->TableInfoCollection,$this->TableInfo)));
		}
		
		return $Results;

	}

	/* ��ѡ���� */
	public function GetDiscAgentList($Uids){
		$Results = array();
		$Results =  $this->AgentUserListFormat(DB::fetch_all('SELECT AU.*,A.title as store_title  FROM '.DB::table($this->TableAgentUser).' AU LEFT JOIN `'.DB::table($this->TableAgent).'` A on A.id = AU.agent_id where AU.id in('.$Uids.') ORDER BY field(AU.id,'.$Uids.')'));
		return $Results;
	}

	/* �ܱ�¥�� */
	public function GetDiscPeripheryList($Lat,$Lng,$Radius){
		$Cope = CalcScope($Lat,$Lng,$Radius);

		$this->Config['PluginVar']['ViewHotListNum'] = $this->Config['PluginVar']['ViewHotListNum'] ? $this->Config['PluginVar']['ViewHotListNum'] : 10;

		$FetchSql = 'SELECT * FROM '.DB::table($this->TableDisc).' where display = 1 and lat < '.$Cope['maxLat'].' and lat > '.$Cope['minLat'].' and lng < '.$Cope['maxLng'].' and lng > '.$Cope['minLng'].' order by id desc limit 0,'.$this->Config['PluginVar']['ViewHotListNum'];

		$Results = $this->DiscListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}
	/* ���б� */
	public function GetDiscMobileList($Id,$Type=null,$Limit=null){
		if($Type){
			$Where = ' and type = '.intval($Type);
		}
		if($Limit){
			$Limit = ' limit 0,'.intval($Limit);
		}
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableDiscMobile).' where iid = '.intval($Id).$Where.' order by id desc'.$Limit);
	}
	
	/* ¥�̻��� */
	public function GetDiscHuXingList($Id){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableDiscHuXing).' where iid = '.intval($Id).' order by id desc');
	}

	/* ��Ѷ�б� */
	public function GetAjaxArticleList($Get){
	
		$Results = array();

		$Get = EncodeURIToUrldeCode($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Where = '';

		if($Get['keyword']){
			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);
			$Where .= ' and ( A.title like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
		}

		if($Get['classid']){
			$Where .= ' and A.classid = '.intval($Get['classid']);
		}

		if($Get['no_id']){
			$Where .= ' and A.id not in('.intval($Get['no_id']).')';
		}

		if($Get['disc_id']){
			$Where .= ' and A.disc_id = '.intval($Get['disc_id']);
		}

		if($Get['display']){
			$Where .= ' and A.display = '.intval($Get['display']);
		}

		if($Get['hot']){
			$Where .= ' and A.hot = '.intval($Get['hot']);
		}

		if($Get['slide']){
			$Where .= ' and A.slide = '.intval($Get['slide']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 15;
		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];

		$Results = $this->ArticleListFormat(DB::fetch_all("SELECT A.*,C.title as class_title,D.title as disc_title FROM ".DB::table($this->TableArticle)." A LEFT JOIN `".DB::table($this->TableArticleClass)."` C on C.id = A.classid LEFT JOIN `".DB::table($this->TableDisc)."` D on D.id = A.disc_id ".$Where." order by A.topdateline > ".time()." desc, A.updateline desc,A.id desc".$Limit));
		
		return $Results;
	}

	/* �б���ʽת�� */
	public function InfoListFormat($Array,$Click=false){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Val['param']['price_time'] = $Val['param']['price_time'] ? $Val['param']['price_time'] : 2;
			$Array[$Key]['url'] = $this->Rewrite('view',array('iid'=>$Val['id']));
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['param']['tag_list'] = $Val['param']['tag_list'] ? $Val['param']['tag_list'] : '';
			$Array[$Key]['param']['cover'] = $Val['param']['cover'] ? $Val['param']['cover'] : $this->Config['PluginVar']['CoverPath'];
			$Array[$Key]['ftitle'] = $this->Config['LangVar']['IndexNav'][$Val['class']];
			$Array[$Key]['huxing'] = $Val['class'] == 1 ? $Val['room'].$this->Config['LangVar']['Room'].$Val['office'].$this->Config['LangVar']['Office'] : $this->Config['LangVar']['RoomArray'][$Val['room']];
			$Array[$Key]['province_text'] = $this->Area[$Val['province']]['content'].($Val['city'] ? '-'.$this->Area[$Val['city']]['content'] : '').($Val['dist'] ? '-'.$this->Area[$Val['dist']]['content'] : '');
			$Array[$Key]['house_type'] = $this->Config['LangVar']['HouseTypeArray'][$Val['house_type']];
			$Array[$Key]['decoration_type'] = $this->Config['LangVar']['DecorationArray'][$Val['decoration_type']];
			$Array[$Key]['management_type'] = $this->Config['LangVar']['ManagementTpyeArray'][$Val['management_type']];
			$Array[$Key]['shops_type'] = $this->Config['LangVar']['ShopManagementTypeArray'][$Val['shops_type']];
			$Array[$Key]['display_text'] = $Val['display'] ? $this->Config['LangVar']['Display1'] : $this->Config['LangVar']['Display0'];
			$Array[$Key]['overdue_text'] = $this->Config['PluginVar']['ExpiryTime'] && $Val['updateline'] < strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()) && $Val['topdateline'] < time() ? $this->Config['LangVar']['BeOverdueTips'] : '';
			$Array[$Key]['dateline'] = $Val['dateline'] ? FormatDate($Val['dateline'],'Y-m-d') : '';
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d') : '';
			$Array[$Key]['see_updateline'] = $Val['see_updateline'] ? date('Y-m-d',$Val['see_updateline']) : '';
			$Array[$Key]['publish_type_text'] = $this->Config['LangVar']['PublishTypeArray'][$Val['publish_type']];
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['topdateline'] = $Val['topdateline'] > time() ? date('Y-m-d H:i',$Val['topdateline']) : '';

			$Array[$Key]['vice_class_text'] = in_array($Val['class'],array(3,4,5,6,7)) ? $this->Config['LangVar']['ShopTypeArray'][$Val['vice_class']] : $this->Config['LangVar']['RentalTypeArray'][$Val['vice_class']];

			$Array[$Key]['param']['content'] = cutstr(DeleteHtml($Val['param']['content']),90); 
			$Array[$Key]['username'] = DeleteHtml($Val['username']);

			if(!$Val['price']){
				$Array[$Key]['price'] = $this->Config['LangVar']['Interview'];
				$Array[$Key]['price_text'] = '';
			}else{
				if(($Val['class'] == 1) || (in_array($Val['class'],array(3,4,5,6,7)) && in_array($Val['vice_class'],array(2,3)))){
					$Array[$Key]['price_text'] = $this->Config['LangVar']['Wan'];
				}else if(($Val['class'] == 2) || (in_array($Val['class'],array(3,4,5,6,7)) && in_array($Val['vice_class'],array(1)))){

					$Array[$Key]['price_text'] = $this->Config['LangVar']['Yuan'].'/'.$this->Config['LangVar']['RentTimeArray'][$Val['param']['price_time']];
				}
			}
			
			if($Val['class'] == 1){
				$Array[$Key]['refresh'] = $this->Config['PluginVar']['HouseRefreshMoney'] ? 1 : 0;
				$Array[$Key]['top'] = $this->Config['PluginVar']['HouseTopMoney'] ? 1 : 0;
			}else if($Val['class'] == 2){
				$Array[$Key]['refresh'] = $this->Config['PluginVar']['RentalRefreshMoney'] ? 1 : 0;
				$Array[$Key]['top'] = $this->Config['PluginVar']['RentalTopMoney'] ? 1 : 0;
			}else if($Val['class'] == 3){
				$Array[$Key]['refresh'] = $this->Config['PluginVar']['ShopRefreshMoney'] ? 1 : 0;
				$Array[$Key]['top'] = $this->Config['PluginVar']['ShopTopMoney'] ? 1 : 0;
			}else if($Val['class'] == 4){
				$Array[$Key]['refresh'] = $this->Config['PluginVar']['WorkShopRefreshMoney'] ? 1 : 0;
				$Array[$Key]['top'] = $this->Config['PluginVar']['WorkShopTopMoney'] ? 1 : 0;
			}else if($Val['class'] == 5){
				$Array[$Key]['refresh'] = $this->Config['PluginVar']['OfficeRefreshMoney'] ? 1 : 0;
				$Array[$Key]['top'] = $this->Config['PluginVar']['OfficeTopMoney'] ? 1 : 0;
			}else if($Val['class'] == 6){
				$Array[$Key]['refresh'] = $this->Config['PluginVar']['WarehouseRefreshMoney'] ? 1 : 0;
				$Array[$Key]['top'] = $this->Config['PluginVar']['WarehouseTopMoney'] ? 1 : 0;
			}else if($Val['class'] == 7){
				$Array[$Key]['refresh'] = $this->Config['PluginVar']['LandRefreshMoney'] ? 1 : 0;
				$Array[$Key]['top'] = $this->Config['PluginVar']['LandTopMoney'] ? 1 : 0;
			}
			
			if($Click){
				//������ۼ�
				$ClickRand = array_filter(explode("-",$this->Config['PluginVar']['ClickRand']));
				$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
				Click($this->TableInfo,$Val['id'],$ClickNum);
			}
			
		}
		return $Array;
	}

	/* ¥���б���ʽת�� */
	public function DiscListFormat($Array,$Click=false){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['url'] = $this->Rewrite('view_disc',array('iid'=>$Val['id']));
			$Array[$Key]['cover'] = $Val['param']['cover'] ? $Val['param']['cover'] : $this->Config['PluginVar']['CoverPath'];
			$Array[$Key]['province_text'] = $this->Area[$Val['province']]['content'].($Val['city'] ? '-'.$this->Area[$Val['city']]['content'] : '').($Val['dist'] ? '-'.$this->Area[$Val['dist']]['content'] : '');
			$Array[$Key]['decoration_type'] = $this->Config['LangVar']['DiscDecorationArray'][$Val['decoration_type']];
			$Array[$Key]['state_text'] = $this->Config['LangVar']['SalesStateArray'][$Val['state']];
			$Array[$Key]['tag_list'] = $Val['param']['tag_list'] ? $Val['param']['tag_list'] : '';
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['dateline'] = date('Y-m-d',$Val['dateline']);
			$Array[$Key]['updateline'] = date('Y-m-d',$Val['updateline']);
			$Array[$Key]['see_updateline'] = $Val['see_updateline'] ? date('Y-m-d',$Val['see_updateline']) : '';
			if(!$Val['price']){
				$Array[$Key]['price'] = $this->Config['LangVar']['PriceUndetermined'];
				$Array[$Key]['price_text'] = '';
			}elseif($Val['price'] == 9999999){
				$Array[$Key]['price'] = $this->Config['LangVar']['YiFangYiJia'];
				$Array[$Key]['price_text'] = '';
			}else{
				$Array[$Key]['price_text'] = $this->Config['LangVar']['Yuan'].'/'.$this->Config['LangVar']['SquareMetre'];
			}

			$Array[$Key]['param'] = '';

			if($Click){
				//������ۼ�
				$ClickRand = array_filter(explode("-",$this->Config['PluginVar']['ClickRand']));
				$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
				Click($this->TableDisc,$Val['id'],$ClickNum);
			}
		}
		return $Array;
	}

	/* ��Ѷ�б���ʽת�� */
	public function ArticleListFormat($Array){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['url'] = !$Val['jump'] ? $this->Rewrite('view_article',array('aid'=>$Val['id'])) : $Val['jump_link'];
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['username'] = DeleteHtml($Val['username']); 
			$Array[$Key]['describe'] = $Val['describe'] ? DeleteHtml($Val['describe']) : cutstr(DeleteHtml($Val['content']),180);
			$Array[$Key]['content'] = '';
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['dateline'] = date('Y-m-d',$Val['dateline']);
			$Array[$Key]['updateline'] = date('Y-m-d',$Val['updateline']);
			$Array[$Key]['thumbnail'] = $Val['thumbnail'] ? $Val['thumbnail'] : $this->Config['PluginVar']['ArticleCoverPath'];
		}
		return $Array;
	}
	
	/* ί�з�Դ��ʽ�� */
	public function EntrustListFormat($Array){
		global $_G,$_GET;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['mobile'] = $_GET['m'] == 'user_entrust_list' ? $Val['mobile'] : '';
			$Array[$Key]['wx'] = '';
			$Array[$Key]['dateline_text'] = date('Y-m-d',$Val['dateline']);
			$Array[$Key]['class_text'] = $this->Config['LangVar']['IndexNavArray'][$Val['class']];
			if($Val['class'] == 2){
				$Array[$Key]['price_text'] = $this->Config['LangVar']['Yuan'].'/'.$this->Config['LangVar']['RentTimeArray'][$Val['param']['price_time']];
			}else{
				$Array[$Key]['price_text'] = $this->Config['LangVar']['Wan'];
			}
		}
		return $Array;
	}

	/* ���ʼ�¼��ʽ�� */
	public function AccessrecordListFormat($Array){
		global $_G,$_GET;
		foreach ($Array as $Key => $Val) {
			$Mobile = GetMobile($Val['uid']);
			$Array[$Key]['mobile'] = $Mobile ? $Mobile : $this->Config['LangVar']['Nothing'];
			$Array[$Key]['dateline'] = date('Y-m-d H:i',$Val['dateline']);
			$Array[$Key]['updateline'] = $Val['updateline'] ? date('Y-m-d H:i',$Val['updateline']) : '';
			
		}
		return $Array;
	}

	//������Ϣ 
	public function GetAjaxPublish($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		
		if($Get['class'] == 99){//����������

			$Item = $this->GetMyViewthread($Get['class'],$Get['iid']);

			$DemandData['type'] = intval($Get['vice_class']);
			$DemandData['uid'] = intval($_G['uid']);
			$DemandData['username'] = addslashes(strip_tags($_G['username']));
			$DemandData['name'] = censor(addslashes(strip_tags($Get['demand_name'])));
			$DemandData['mobile'] = censor(addslashes(strip_tags($Get['demand_mobile'])));
			$DemandData['title'] = censor(addslashes(strip_tags($Get['demand_title'])));
			$DemandData['content'] = censor(addslashes(strip_tags($Get['demand_content'])));
			$DemandData['province'] = censor(addslashes(strip_tags($Get['province'])));
			$DemandData['city'] = censor(addslashes(strip_tags($Get['city'])));
			$DemandData['dist'] = censor(addslashes(strip_tags($Get['dist'])));
			
			$DemandData['display'] = $this->Config['PluginVar']['DemandAddSwitch'] ? 0 : 1;
			$DemandData['payment_state'] = 1;

			if(!$DemandData['province']){//�����ж�
				$Data['Msg'] = urlencode($this->Config['LangVar']['DemandAreaPlaceholder']);
				return $Data;
			}

			if(!$DemandData['title']){//�����ж�
				$Data['Msg'] = urlencode($this->Config['LangVar']['DemandTitlePlaceholder']);
				return $Data;
			}

			if(!$DemandData['content']){//�����ж�
				$Data['Msg'] = urlencode($this->Config['LangVar']['DemandContentErr']);
				return $Data;
			}

			if(!$DemandData['name']){//�ƺ��ж�
				$Data['Msg'] = urlencode($this->Config['LangVar']['DemandNamePlaceholder']);
				return $Data;
			}
			
			//�ֻ������ж�
			$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
			if(!$DemandData['mobile']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['DemandMobilePlaceholder']);
				return $Data;
			}else if(!preg_match($IsMob,$DemandData['mobile'])){
				$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
				return $Data;
			}
			
			if($Item){
			
				$DemandData['display'] = 0;
				$DemandData['edit_dateline'] = time();
				if(DB::update($this->TableDemand,$DemandData,'id = '.intval($Item['id']))){
					$Data['Id'] = $Item['id'];
					$Data['Url'] = $this->Config['DemandListUrl'].$Item['type'];
					$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk'].(!$DemandData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));
					$Data['State'] = 200;
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
				}
					
			}else{
				$DemandData['dateline'] = $DemandData['edit_dateline'] = time();
				$DemandId = DB::insert($this->TableDemand,$DemandData,true);
				if($DemandId){
					$Data['Id'] = $DemandId;
					$Data['Url'] = $this->Config['DemandListUrl'].$DemandData['type'];
					$Data['Msg'] = urlencode($this->Config['LangVar']['PublishSuccess'].(!$DemandData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));
					$Data['State'] = 200;
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['PublishFail']);
				}
			}
			
		}else if(in_array($Get['class'],array(1,2,3,4,5,6,7))){//���ַ� ���ⷿ ���� ���� д��¥ �ֿ� ����
			$UserInfo = $this->GetUserInfo();
			if($this->Admin){
				$Item = $this->GetMyViewthread($_GET['class'],$_GET['iid'],'',true);
			}else if(($UserInfo['intermediary'] && $UserInfo['identity'] == 1)){
				$Item = $this->GetMyViewthread($Get['class'],$Get['iid'],' and agent_id = '.$UserInfo['agent_id'],true);
			}else{
				$Item = $this->GetMyViewthread($Get['class'],$Get['iid']);
			}
			
			$UpData['title'] = censor(addslashes(strip_tags($Get['title'])));
			$UpData['class'] = intval($Get['class']);
			$UpData['vice_class'] = intval($Get['vice_class']);
			$UpData['uid'] = $Item['uid'] ? intval($Item['uid']) : intval($_G['uid']);
			$UpData['username'] = $Item['username'] ? addslashes(strip_tags($Item['username'])) : addslashes(strip_tags($_G['username']));
			$UpData['name'] = censor(addslashes(strip_tags($Get['name'])));
			$UpData['small_area'] = censor(addslashes(strip_tags($Get['small_area'])));
			$UpData['community'] = addslashes(strip_tags($Get['community']));
			$UpData['lat'] = censor(addslashes(strip_tags($Get['lat'])));
			$UpData['lng'] = censor(addslashes(strip_tags($Get['lng'])));
			$UpData['price'] = !$Get['interview'] ? addslashes(strip_tags($Get['price'])) : '';
			$UpData['square'] = intval($Get['square']);
			$UpData['floor'] = intval($Get['floor']);
			$UpData['count_floor'] = intval($Get['count_floor']);
			$UpData['room'] = intval($Get['room']);
			$UpData['office'] = intval($Get['office']);
			$UpData['guard'] = intval($Get['guard']);
			$UpData['deposit'] = intval($Get['deposit']);
			$UpData['house_type'] = intval($Get['house_type']);
			$UpData['decoration_type'] = intval($Get['decoration_type']);
			$UpData['years'] = intval($Get['years']);
			$UpData['orientation'] = intval($Get['orientation']);
			$UpData['property_right'] = intval($Get['property_right']);
			$UpData['management_type'] = intval($Get['management_type']);
			$UpData['shops_type'] = intval($Get['shops_type']);
			$UpData['tag'] = addslashes(strip_tags($Get['tag']));
			$UpData['configure'] = addslashes(strip_tags($Get['configure']));
			if($this->Config['PluginVar']['PublishTypeSwitch'] && !$this->Config['PluginVar']['AgentSwitch']){
				$UpData['publish_type'] = $Get['publish_type'] ? intval($Get['publish_type']) : 1;
			}else{
				if($UserInfo['vip']){
					$UpData['publish_type'] = $Item['publish_type'] ? $Item['publish_type'] : 2;
					$UpData['agent_id'] = $UserInfo['agent_id'];
				}else{
					$UpData['publish_type'] = $Item['publish_type'] ? $Item['publish_type'] : 1;
				}
			}
			
			if($UpData['class'] == 2 || ($UpData['class'] == 3 && $UpData['vice_class'] == 1)){
				$UpData['display'] = $this->Config['PluginVar']['InfoAddLeaseSwitch'] ? 0 : 1;
			}else{
				$UpData['display'] = $this->Config['PluginVar']['InfoAddSwitch'] ? 0 : 1;
			}

			$UpData['province'] = addslashes(strip_tags($Get['province']));
			$UpData['city'] = addslashes(strip_tags($Get['city']));
			$UpData['dist'] = addslashes(strip_tags($Get['dist']));
			$UpData['vr_url'] = addslashes(strip_tags($Get['vr_url']));
			$UpData['mobile'] = addslashes(strip_tags($Get['mobile']));

			$UpData['content'] = str_replace($this->Config['LangVar']['PublishReplace'],array(''),censor(addslashes(strip_tags($Get['content']))));
			
			$Param['wx'] = $Get['mobile_wx'] ? $UpData['mobile'] : addslashes(strip_tags($Get['wx']));
			$Param['mastermobile'] = addslashes(strip_tags($Get['mastermobile']));
			$Param['price_time'] = intval($Get['price_time']);
			
			foreach(array_filter(explode(';',$Get['new_images'][0])) as $Key => $Val) {
				$Get['new_images'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
			}
			$Param['images'] = is_array($Get['new_images']) && isset($Get['new_images'])  ? $Get['new_images'] : '';
			$Param['cover'] = $Get['new_images'][0];
			
			if($UpData['class'] == 1){
				$TagArray = $this->Config['LangVar']['HouseTagArray'];
				$Money = $this->Config['PluginVar']['HouseMoney'];
				$AppMoney = $this->Config['PluginVar']['HouseAppMoney'];
			}else if($UpData['class'] == 2){
				$TagArray = $this->Config['LangVar']['RentalHouseTagArray'];
				$Money = $this->Config['PluginVar']['RentalMoney'];
				$AppMoney = $this->Config['PluginVar']['RentalAppMoney'];
				
			}else if($UpData['class'] == 3){
				$TagArray = $this->Config['LangVar']['ShopTagArray'];
				$Money = $this->Config['PluginVar']['ShopMoney'];
				$AppMoney = $this->Config['PluginVar']['ShopAppMoney'];
			}else if($UpData['class'] == 4){
				$TagArray = $this->Config['LangVar']['WorkShopTagArray'];
				$Money = $this->Config['PluginVar']['WorkShopMoney'];
				$AppMoney = $this->Config['PluginVar']['WorkShopAppMoney'];
			}else if($UpData['class'] == 5){
				$TagArray = $this->Config['LangVar']['OfficeTagArray'];
				$Money = $this->Config['PluginVar']['OfficeMoney'];
				$AppMoney = $this->Config['PluginVar']['OfficeAppMoney'];
			}else if($UpData['class'] == 6){
				$TagArray = $this->Config['LangVar']['WarehouseTagArray'];
				$Money = $this->Config['PluginVar']['WarehouseMoney'];
				$AppMoney = $this->Config['PluginVar']['WarehouseAppMoney'];
			}else if($UpData['class'] == 7){
				$TagArray = $this->Config['LangVar']['LandTagArray'];
				$Money = $this->Config['PluginVar']['LandMoney'];
				$AppMoney = $this->Config['PluginVar']['LandAppMoney'];
			}

			if($UpData['tag']){
				foreach(array_filter(explode(",",$UpData['tag'])) as $Key => $Val) {
					$Param['tag_list'][] = $TagArray[$Val];
				}
			}

			if($UserInfo['vip'] && !$Item && $this->Config['PluginVar']['AgentSwitch']){//�н��ж�
	
				if($UserInfo['day_info_count']){//ÿ�շ�������
					$InfoDayCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and uid = '.intval($_G['uid']).' and dateline >= '.strtotime(date('Y-m-d',time())).' and dateline <= '.strtotime(date('Y-m-d 23:59:59',time())));
					if($InfoDayCount >= $UserInfo['day_info_count']){
						$Data['Msg'] = urlencode($this->Config['LangVar']['InfoDayCountErr']);
						return $Data;
					}
				}

				if($UserInfo['info_count']){//����������
		
					$InfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and deal = 0 and uid = '.intval($_G['uid']).($UserInfo['before_dateline'] ? ' and dateline >= '.$UserInfo['before_dateline'] : ''));
					if($InfoCount >= $UserInfo['info_count']){
						$Data['Msg'] = urlencode($this->Config['LangVar']['InfoCountErr']);
						return $Data;
					}
				}

				$UpData['display'] = $UserInfo['examine'] ? 1 : 0;
		
			}else if($this->Config['PluginVar']['PersonalAddNum']){//������������
				$InfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and uid = '.intval($_G['uid']));
				
				if($InfoCount >= $this->Config['PluginVar']['PersonalAddNum'] && !$Item){
					$Data['State'] = 202;
					$Data['Msg'] = urlencode(str_replace('{Num}',$this->Config['PluginVar']['PersonalAddNum'],$this->Config['LangVar']['PersonalAddNumErr']));
					return $Data;
				}
				
			}

			if(!$Param['images'] && $this->Config['PluginVar']['PublishImageSwitch']){// ͼƬ�ж�
				$Data['Msg'] = urlencode($this->Config['LangVar']['FormImagesTitle']);
				return $Data;
			}

			$this->Config['PluginVar']['InterviewSwitch'] = in_array($UpData['class'],$this->Config['PluginVar']['InterviewSwitchs']) ? true : false;

			if($Get['class'] == 1){//���ַ��ж�
				
				if(!$UpData['small_area'] && $this->Config['PluginVar']['PublishsSmallAreaFillSwitch']){//С��
					$Data['Msg'] = urlencode($this->Config['LangVar']['SmallAreaPlaceholder']);
					return $Data;
				}

				if(!$UpData['room']){//����
					$Data['Msg'] = urlencode($this->Config['LangVar']['HuXingPlaceholder']);
					return $Data;
				}

				if(!$UpData['decoration_type']){//װ��
					$Data['Msg'] = urlencode($this->Config['LangVar']['DecorationPlaceholder']);
					return $Data;
				}

				if(!$UpData['orientation'] && $this->Config['PluginVar']['PublishOrientationSwitch'] && $this->Config['PluginVar']['PublishOrientationRequiredwitch']){//����
					$Data['Msg'] = urlencode($this->Config['LangVar']['OrientationPlaceholder']);
					return $Data;
				}

				if(!$UpData['floor']){//¥��
					$Data['Msg'] = urlencode($this->Config['LangVar']['HouseFloorPlaceholder']);
					return $Data;
				}

				if(!$UpData['house_type']){//���������ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['HouseTypePlaceholder']);
					return $Data;
				}

				if(dstrlen($UpData['small_area']) > $this->Config['PluginVar']['SmallAreaLength'] && $this->Config['PluginVar']['SmallAreaLength']){//С������������
					$Data['Msg'] = urlencode(str_replace('{Num}',$this->Config['PluginVar']['SmallAreaLength'],$this->Config['LangVar']['SmallAreaLengthErr']));
					return $Data;
				}
		
				if(!$UpData['province']){//λ��
					$Data['Msg'] = urlencode($this->Config['LangVar']['HouseAreaPlaceholder']);
					return $Data;
				}

				if((!$UpData['lat'] || !$UpData['lng']) && $this->Config['PluginVar']['PublishMapSwitch'] && !MinWxApp){//��γ���ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['TaggingErr']);
					return $Data;
				}

				if(!$UpData['square']){//����ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['SquarePlaceholder']);
					return $Data;
				}else if($UpData['square'] && !preg_match("/^[0-9]+$/",$UpData['square'])){
					$Data['Msg'] = urlencode($this->Config['LangVar']['SquareErr2']);
					return $Data;
				}
			
				if(!$UpData['price'] && !$this->Config['PluginVar']['InterviewSwitch']){//����ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['PriceErr']);
					return $Data;
				}else if($UpData['price'] && !preg_match("/^[0-9.]+$/",$UpData['price'])){
					$Data['Msg'] = urlencode($this->Config['LangVar']['PriceErr2']);
					return $Data;
				}

				

			}else if($Get['class'] == 2){//���ⷿ�ж�

				if(!$UpData['small_area'] && $this->Config['PluginVar']['PublishsSmallAreaFillSwitch']){//С��
					$Data['Msg'] = urlencode($this->Config['LangVar']['SmallAreaPlaceholder']);
					return $Data;
				}

				if(!$UpData['room']){//����
					$Data['Msg'] = urlencode($this->Config['LangVar']['HuXingPlaceholder']);
					return $Data;
				}

				if(!$UpData['decoration_type']){//װ��
					$Data['Msg'] = urlencode($this->Config['LangVar']['DecorationPlaceholder']);
					return $Data;
				}

				if(!$UpData['house_type']){//���������ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['HouseTypePlaceholder']);
					return $Data;
				}

				if(!$UpData['orientation'] && $this->Config['PluginVar']['PublishOrientationSwitch'] && $this->Config['PluginVar']['PublishOrientationRequiredwitch']){//����
					$Data['Msg'] = urlencode($this->Config['LangVar']['OrientationPlaceholder']);
					return $Data;
				}

				if(dstrlen($UpData['small_area']) > $this->Config['PluginVar']['SmallAreaLength'] && $this->Config['PluginVar']['SmallAreaLength']){//С������������
					$Data['Msg'] = urlencode(str_replace('{Num}',$this->Config['PluginVar']['SmallAreaLength'],$this->Config['LangVar']['SmallAreaLengthErr']));
					return $Data;
				}
		
				if(!$UpData['province']){//λ��
					$Data['Msg'] = urlencode($this->Config['LangVar']['HouseAreaPlaceholder']);
					return $Data;
				}

				if((!$UpData['lat'] || !$UpData['lng']) && $this->Config['PluginVar']['PublishMapSwitch'] && !MinWxApp){//��γ���ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['TaggingErr']);
					return $Data;
				}

				if(!$UpData['square']){//����ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['SquarePlaceholder']);
					return $Data;
				}else if($UpData['square'] && !preg_match("/^[0-9]+$/",$UpData['square'])){
					$Data['Msg'] = urlencode($this->Config['LangVar']['SquareErr2']);
					return $Data;
				}

				if(!$UpData['price'] && !$this->Config['PluginVar']['InterviewSwitch']){//����ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['PriceErr']);
					return $Data;
				}else if($UpData['price'] && !preg_match("/^[0-9.]+$/",$UpData['price'])){
					$Data['Msg'] = urlencode($this->Config['LangVar']['PriceErr2']);
					return $Data;
				}
				
			}else if($Get['class'] == 3){//�����ж�

				if(dstrlen($UpData['small_area']) > $this->Config['PluginVar']['SmallAreaLength'] && $this->Config['PluginVar']['SmallAreaLength']){//С������������
					$Data['Msg'] = urlencode(str_replace('{Num}',$this->Config['PluginVar']['SmallAreaLength'],$this->Config['LangVar']['SmallAreaLengthErr']));
					return $Data;
				}

				if(!$UpData['province']){//λ��
					$Data['Msg'] = urlencode($this->Config['LangVar']['HouseAreaPlaceholder']);
					return $Data;
				}

				if((!$UpData['lat'] || !$UpData['lng']) && $this->Config['PluginVar']['PublishMapSwitch'] && !MinWxApp){//��γ���ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['TaggingErr']);
					return $Data;
				}

				if(!$UpData['square']){//����ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['SquarePlaceholder']);
					return $Data;
				}else if($UpData['square'] && !preg_match("/^[0-9]+$/",$UpData['square'])){
					$Data['Msg'] = urlencode($this->Config['LangVar']['SquareErr2']);
					return $Data;
				}

				if(!$UpData['price'] && !$this->Config['PluginVar']['InterviewSwitch']){//����ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['PriceErr']);
					return $Data;
				}else if($UpData['price'] && !preg_match("/^[0-9.]+$/",$UpData['price'])){
					$Data['Msg'] = urlencode($this->Config['LangVar']['PriceErr2']);
					return $Data;
				}

				if(!$UpData['management_type']){//��Ӫ�����ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['ManagementTpyePlaceholder']);
					return $Data;
				}

				if(!$UpData['shops_type']){//���������ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['ShopTypePlaceholder']);
					return $Data;
				}

			}else if(in_array($Get['class'],array(4,5,6,7))){//����/д��¥/�ֿ�/�����ж�

				if(dstrlen($UpData['small_area']) > $this->Config['PluginVar']['SmallAreaLength'] && $this->Config['PluginVar']['SmallAreaLength']){//С������������
					$Data['Msg'] = urlencode(str_replace('{Num}',$this->Config['PluginVar']['SmallAreaLength'],$this->Config['LangVar']['SmallAreaLengthErr']));
					return $Data;
				}

				if(!$UpData['province']){//λ��
					$Data['Msg'] = urlencode($this->Config['LangVar']['HouseAreaPlaceholder']);
					return $Data;
				}

				if((!$UpData['lat'] || !$UpData['lng']) && $this->Config['PluginVar']['PublishMapSwitch'] && !MinWxApp){//��γ���ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['TaggingErr']);
					return $Data;
				}

				if(!$UpData['square']){//����ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['SquarePlaceholder']);
					return $Data;
				}else if($UpData['square'] && !preg_match("/^[0-9]+$/",$UpData['square'])){
					$Data['Msg'] = urlencode($this->Config['LangVar']['SquareErr2']);
					return $Data;
				}

				if(!$UpData['price'] && !$this->Config['PluginVar']['InterviewSwitch']){//����ж�
					$Data['Msg'] = urlencode($this->Config['LangVar']['PriceErr']);
					return $Data;
				}else if($UpData['price'] && !preg_match("/^[0-9.]+$/",$UpData['price'])){
					$Data['Msg'] = urlencode($this->Config['LangVar']['PriceErr2']);
					return $Data;
				}

			}

			if(!$UpData['name']){//�����ж�
				$Data['Msg'] = urlencode($this->Config['LangVar']['ContactsPlaceholder']);
				return $Data;
			}
			
			//�ֻ������ж�
			$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
			if(!$UpData['mobile']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['ContactNumberPlaceholder']);
				return $Data;
			}else if(!preg_match($IsMob,$UpData['mobile'])){
				$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
				return $Data;
			}

			if(!$UpData['title']){//�����ж�
				$Data['Msg'] = urlencode($this->Config['LangVar']['PublishTitlePlaceholder']);
				return $Data;
			}

			$UpData['param'] = serialize($Param);
			
			$Money = AppYes && App ? $AppMoney : $Money;

			if($Item){//����
				$UpData['display'] = $this->Config['PluginVar']['EditDisplaySwitch'] || ($UserInfo['vip'] && !$UserInfo['examine']) ? 0 : $Item['display'];
				$UpData['edit_dateline'] = time();
				if(DB::update($this->TableInfo,$UpData,'id = '.intval($Item['id']))){
					$Data['Id'] = $Item['id'];
					$Data['Url'] = $this->Config['ViewUrl'].$Item['id'];
					$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));

					if((($Money && !$this->Admin && !$UserInfo['vip']) || ($Get['top'] && !$this->Admin)) && !$Item['payment_state']){
						if($Get['top']){
							$TopArray = array_filter(explode("|",$Get['top']));
							$Money = $UserInfo['vip'] && $UserInfo['top_discount'] ? $TopArray[1] * ($UserInfo['top_discount'] / 10) : $TopArray[1];
							$PayLog = $this->GetAjaxPayLog(array('event'=>'top_info','money'=>$Money,'day'=>$TopArray[0],'iid'=>$Item['id'],'class'=>$UpData['class']));
						}else{
							$Money = $AppMoney && App ? $AppMoney : $Money;
							$PayLog = $this->GetAjaxPayLog(array('money'=>$Money,'event'=>'publish_info','iid'=>$Item['id'],'class'=>$UpData['class']));
						}
						
						$Data['Money'] = $Money;
						$Data['PayId'] = $PayLog['Id'];
						$Data['State'] = 201;
					}else{
						$Data['State'] = 200;
					}

				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
				}
			}else{//���
				if(($Money && !$this->Admin && !$UserInfo['vip']) || ($Get['top'] && !$this->Admin)){
					$Money = $AppMoney && App ? $AppMoney : $Money;
					$UpData['payment_state'] = 0;
				}else{
					$UpData['payment_state'] = 1;
				}
				$UpData['dateline'] = $UpData['updateline'] = time();

				$InfoId = DB::insert($this->TableInfo,$UpData,true);
				if($InfoId){
					$Data['Id'] = $InfoId;
					$Data['Url'] = $this->Config['ViewUrl'].$InfoId;
					$Data['Msg'] = urlencode($this->Config['LangVar']['PublishSuccess'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));

					if(($Money && !$this->Admin && !$UserInfo['vip']) || ($Get['top'] && !$this->Admin)){
						if($Get['top']){
							$TopArray = array_filter(explode("|",$Get['top']));
							$Money = $UserInfo['vip'] && $UserInfo['top_discount'] ? $TopArray[1] * ($UserInfo['top_discount'] / 10) : $TopArray[1];
							$PayLog = $this->GetAjaxPayLog(array('event'=>'top_info','money'=>$Money,'day'=>$TopArray[0],'iid'=>$InfoId,'class'=>$UpData['class']));
						}else{
							$PayLog = $this->GetAjaxPayLog(array('money'=>$Money,'event'=>'publish_info','iid'=>$InfoId,'class'=>$UpData['class']));
						}
						
						$Data['Money'] = $Money;
						$Data['PayId'] = $PayLog['Id'];
						$Data['State'] = 201;
					}else{
						$Data['State'] = 200;
					}
					
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['PublishFail']);
				}
			}

			//��Ϣ֪ͨ
			if(!$UpData['display']){
				foreach($this->AdminUidsList as $Key => $Val) {
					
					if(DzNotice){
						notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
							'url'=>$this->Config['ViewUrl'].$Data['Id'],
							'msg'=>str_replace(array('{Title}'),array($UpData['title']),$this->Config['LangVar']['InfoPush'])
						),1);//ϵͳ֪ͨ
					}
					
					if($Config['PluginVar']['AppType'] == 1){//������������
						$PushData['Uid'] = $Val;
						$PushData['Type'] = 'pictemp';
						$PushData['Content'] = array(
							"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
							"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
							"link"=> $this->Config['ViewUrl'].$Data['Id'],
							"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
							"extra_info"=>array(
								array(
									"key"=>'',
									"val"=>diconv(str_replace(array('{Title}'),array($UpData['title']),$this->Config['LangVar']['InfoPush']),CHARSET,'UTF-8')
								)
							)
						);
						$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
					}
				}

				if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
					$PushData['Uid'] = implode(',',$this->AdminUidsList);
					$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
					$PushData['Content'] = array(
						'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						'date'=>date('Y-m-d H:i:s'),
						'setting'=>array(),
						'content' => diconv(str_replace(array('{Title}'),array($UpData['title']),$this->Config['LangVar']['InfoPush']),CHARSET,'UTF-8'),
						'url'=>$this->Config['ViewUrl'].$Data['Id']
					);
					$this->QHApp->GetMessagesTemplate($PushData);
				}
			}
			//��Ϣ֪ͨEnd
		}

		return $Data;

	}

	//ί�з�Դ
	public function GetAjaxEntrust($Get){
		global $_G,$Config;

		$Get = StrToGBK($Get);
		$UpData['class'] = intval($Get['class']);
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['name'] = censor(addslashes(strip_tags($Get['name'])));
		$UpData['address'] = censor(addslashes(strip_tags($Get['address'])));
		$UpData['square'] = intval($Get['square']);
		$UpData['price'] = censor(addslashes(strip_tags($Get['price'])));
		$UpData['mobile'] = censor(addslashes(strip_tags($Get['mobile'])));
		$UpData['wx'] = censor(addslashes(strip_tags($Get['wx'])));
		$Param['price_time'] = $PriceTime = intval($Get['price_time']);
		
		if(!$UpData['address']){//��ַ
			$Data['Msg'] = urlencode($this->Config['LangVar']['CommunityToPlaceholder']);
			return $Data;
		}

		if(!$UpData['square']){//���
			$Data['Msg'] = urlencode($this->Config['LangVar']['SquarePlaceholder']);
			return $Data;
		}

		if(!$UpData['price']){//���
			$Data['Msg'] = urlencode($this->Config['LangVar']['OfferPlaceholder']);
			return $Data;
		}

		if(!$UpData['price']){//����ж�
			$Data['Msg'] = urlencode($this->Config['LangVar']['PriceErr']);
			return $Data;
		}else if($UpData['price'] && !preg_match("/^[0-9.]+$/",$UpData['price'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['PriceErr2']);
			return $Data;
		}

		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		if(!$UpData['mobile']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactNumberPlaceholder']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['mobile'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
			return $Data;
		}

		$UpData['param'] = $Param ? serialize($Param) : '';
		$UpData['dateline'] = time();
		$EId = DB::insert($this->TableEntrust,$UpData,true);
		
		if($EId){
			$Data['Id'] = $EId;
			$Data['Msg'] = urlencode($this->Config['LangVar']['EntrustSuccess']);
			$Data['State'] = 200;

			//��Ϣ֪ͨ
			$Content = '<br>'.$this->Config['LangVar']['Community'].$this->Config['LangVar']['MaoHao'].$UpData['address'].'<br>'.$this->Config['LangVar']['Square'].$this->Config['LangVar']['MaoHao'].$UpData['square'].'<br>'.$this->Config['LangVar']['Offer'].$this->Config['LangVar']['MaoHao'].$UpData['price'].( $UpData['class'] == 2 ? $this->Config['LangVar']['Yuan'].'/'.$this->Config['LangVar']['RentTimeArray'][$PriceTime] : $this->Config['LangVar']['WanYuan']).'<br>'.$this->Config['LangVar']['Contacts'].$this->Config['LangVar']['MaoHao'].$UpData['name'].'<br>'.$this->Config['LangVar']['Mobile'].$this->Config['LangVar']['MaoHao'].$UpData['mobile'].'<br>'.$this->Config['LangVar']['WxTitle'].$this->Config['LangVar']['MaoHao'].$UpData['wx'];
			

			if($Get['push_uid']){
				$this->AdminUidsList[] = $Get['push_uid'];
				$this->AdminUidsList = array_unique($this->AdminUidsList);
			}
			
			foreach($this->AdminUidsList as $Key => $Val) {
				if(DzNotice){
					notification_add($Val,'system','{msg}',array(
						'msg'=>str_replace(array('{Content}'),array($Content),$this->Config['LangVar']['EntrustPushContent'])
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['EntrustPushTitle'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['EntrustPushTag'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['Url'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>diconv($this->Config['LangVar']['Community'],CHARSET,'UTF-8'),
								"val"=>diconv($UpData['address'],CHARSET,'UTF-8')
							),
							array(
								"key"=>diconv($this->Config['LangVar']['Square'],CHARSET,'UTF-8'),
								"val"=>diconv($UpData['square'],CHARSET,'UTF-8')
							),
							array(
								"key"=>diconv($this->Config['LangVar']['Offer'],CHARSET,'UTF-8'),
								"val"=>diconv($UpData['price'].( $UpData['class'] == 2 ? $this->Config['LangVar']['Yuan'].'/'.$this->Config['LangVar']['RentTimeArray'][$PriceTime] : $this->Config['LangVar']['WanYuan']),CHARSET,'UTF-8')
							),
							array(
								"key"=>diconv($this->Config['LangVar']['Contacts'],CHARSET,'UTF-8'),
								"val"=>diconv($UpData['name'],CHARSET,'UTF-8')
							),
							array(
								"key"=>diconv($this->Config['LangVar']['Mobile'],CHARSET,'UTF-8'),
								"val"=>diconv($UpData['mobile'],CHARSET,'UTF-8')
							),
							array(
								"key"=>diconv($this->Config['LangVar']['WxTitle'],CHARSET,'UTF-8'),
								"val"=>diconv($UpData['wx'],CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}

				if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
					$PushData['Uid'] = implode(',',$this->AdminUidsList);
					$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['EntrustPushTitle'])),CHARSET,'UTF-8');
					$PushData['Content'] = array(
						'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['EntrustPushTag'])),CHARSET,'UTF-8'),
						'date'=>date('Y-m-d H:i:s'),
						'setting'=>array(
							array(
								"setKey"=>diconv($this->Config['LangVar']['Community'],CHARSET,'UTF-8'),
								"setValue"=>diconv($UpData['address'],CHARSET,'UTF-8')
							),
							array(
								"setKey"=>diconv($this->Config['LangVar']['Square'],CHARSET,'UTF-8'),
								"setValue"=>diconv($UpData['square'],CHARSET,'UTF-8')
							),
							array(
								"setKey"=>diconv($this->Config['LangVar']['Offer'],CHARSET,'UTF-8'),
								"setValue"=>diconv($UpData['price'].( $UpData['class'] == 2 ? $this->Config['LangVar']['Yuan'].'/'.$this->Config['LangVar']['RentTimeArray'][$PriceTime] : $this->Config['LangVar']['WanYuan']),CHARSET,'UTF-8')
							),
							array(
								"setKey"=>diconv($this->Config['LangVar']['Contacts'],CHARSET,'UTF-8'),
								"setValue"=>diconv($UpData['name'],CHARSET,'UTF-8')
							),
							array(
								"setKey"=>diconv($this->Config['LangVar']['Mobile'],CHARSET,'UTF-8'),
								"setValue"=>diconv($UpData['mobile'],CHARSET,'UTF-8')
							),
							array(
								"setKey"=>diconv($this->Config['LangVar']['WxTitle'],CHARSET,'UTF-8'),
								"setValue"=>diconv($UpData['wx'],CHARSET,'UTF-8')
							)
						),
						'content' => '',
						'url'=>$this->Config['Url']
					);
					$this->QHApp->GetMessagesTemplate($PushData);
				}

			}
			//��Ϣ֪ͨEnd
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['EntrustFail']);
		}
		return $Data;

	}

	/* �������б� */
	public function GetAjaxDemandList($Get){
		$Results = array();
		$Get = StrToGBK($Get);
		$Page = $Get['page'] ? intval($Get['page']) : 0;
		$Where = ' and D.display = 1 and D.payment_state = 1';
		$Order = 'D.edit_dateline';
		
		if($Get['type']){
			$Where .= ' and D.type = '.intval($Get['type']);
		}

		if($Get['did']){
			$Where .= ' and D.id != '.intval($Get['did']);
		}
		
		if(!$Page && $Get['did']){
			$TopResults = $this->DemandListFormat(DB::fetch_all('SELECT D.* FROM '.DB::table($this->TableDemand).' D where D.display = 1 and D.payment_state = 1 and D.id = '.intval($Get['did'])));
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['DemandListNum'] = $this->Config['PluginVar']['DemandListNum'] ? $this->Config['PluginVar']['DemandListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['DemandListNum']).','.$this->Config['PluginVar']['DemandListNum'];

		$FetchSql = 'SELECT D.* FROM '.DB::table($this->TableDemand).' D '.$Where .' order by '.$Order.' desc '.$Limit;
		$Results = $this->DemandListFormat(DB::fetch_all($FetchSql));
			
		array_splice($Results,0,0,$TopResults);

		return $Results;
	}

	/* ������ת�� */
	public function DemandListFormat($Array){
		@require_once libfile('function/forum');
		$DemandPayLogArray = $this->GetUserDemandPayLogArray();
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['type_title'] = $this->Config['LangVar']['DemandTypeArray'][$Val['type']];
			$Array[$Key]['address'] = $this->Area[$Val['province']]['content'].($Val['city'] ? '-'.$this->Area[$Val['city']]['content'] : '').($Val['dist'] ? '-'.$this->Area[$Val['dist']]['content'] : '');
			$Array[$Key]['edit_dateline'] = date('Y-m-d H:i',$Val['edit_dateline']);
			$Array[$Key]['name'] = cutstr($Val['name'],8);
			$Array[$Key]['face'] = discuz_uc_avatar($Val['uid'],middle,true);
			$Array[$Key]['pay'] = in_array($Val['id'],$DemandPayLogArray) ? 1 : 0;
			$Array[$Key]['mobile'] = ($this->Admin) || ($this->Config['PluginVar']['DemandMoney'] && $Array[$Key]['pay']) || !$this->Config['PluginVar']['DemandMoney'] ? $Val['mobile'] : '';
			
		}
		return $Array;
	}

	/* ָ���Լ����������б� */
	public function GetUserDemandList($Uid=null){
		global $_G;
		$Uid = $Uid ? intval($Uid) : intval($_G['uid']);
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableDemand).' where payment_state = 1 and uid = '.$Uid.' order by id');
	}

	/* ָ���Լ����������б����� */
	public function GetUserDemandCount($Uid=null){
		global $_G;
		$Uid = $Uid ? intval($Uid) : intval($_G['uid']);
		return DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableDemand).' where payment_state = 1 and uid = '.$Uid.' order by id');
	}

	/* �����¼���� */
	public function GetUserInfoLogCount($Uid=null){
		global $_G;
		$Uid = $Uid ? intval($Uid) : intval($_G['uid']);
		return DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoLog).' where uid = '.$Uid.' order by id');
	}

	/* ָ���Լ��ķ�Դ�б����� */
	public function GetUserInfoCount($Uid=null){
		global $_G;
		$Uid = $Uid ? intval($Uid) : intval($_G['uid']);
		return DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and uid = '.$Uid.' order by id');
	}

	/* ��ע¥������ */
	public function GetUserDiscCount($Uid=null){
		global $_G;
		$Uid = $Uid ? intval($Uid) : intval($_G['uid']);
		return DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableDiscCollection).' where uid = '.$Uid.' order by id');
	}

	/* ��Դ�ղ����� */
	public function GetUserInfoCollectionCount($Uid=null){
		global $_G;
		$Uid = $Uid ? intval($Uid) : intval($_G['uid']);
		return DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoCollection).' where uid = '.$Uid.' order by id');
	}

	/* �û������Լ��ķ�Դ */
	public function GetAjaxUserInfoOp($Op,$Id,$Field=null,$Value=null){
		global $_G;
		$Id = intval($Id);
		$Uid = intval($_G['uid']);
		if($Op == 'Del'){
			if($this->Config['PluginVar']['ViewDayDel'] && DB::fetch_first('SELECT * FROM '.DB::table($this->TableInfo).' where id = '.$Id.' and dateline >= '.strtotime(date('Y-m-d',time())).' and dateline <= '.strtotime(date('Y-m-d 23:59:59',time())))){
				$Data['Msg'] = urlencode($this->Config['PluginVar']['ViewDayDelTips']);
				return $Data;
			}
			if(DB::delete($this->TableInfo,'id ='.$Id.' and uid = '.$Uid)){
				DB::delete($this->TableInfoLog,'iid ='.$Id);
				DB::delete($this->TableInfoCollection,'iid ='.$Id);
				DB::delete($this->TableInfoReport,'iid ='.$Id);
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else if($Op == 'Edit'){
			if(DB::update($this->TableInfo,array($Field=>addslashes(strip_tags($Value))),'id = '.$Id.' and uid = '.$Uid)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
	}

	/* �û������Լ������� */
	public function GetAjaxUserDemandOp($Op,$Id,$Field=null,$Value=null){
		global $_G;
		$Id = intval($Id);
		$Uid = intval($_G['uid']);
		if($Op == 'Del'){
			if(DB::delete($this->TableDemand,'id ='.$Id.' and uid = '.$Uid)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else if($Op == 'Edit'){
			if(DB::update($this->TableDemand,array($Field=>addslashes(strip_tags($Value))),'id = '.$Id.' and uid = '.$Uid)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
	}

	/* �ղط�Դ */
	public function GetAjaxInfoCollect($Id){
		global $_G;
		$GetData['uid'] = intval($_G['uid']);
		$GetData['username'] = addslashes(strip_tags($_G['username']));
		$GetData['iid'] = intval($Id);
		$GetData['dateline'] = time();
		
		$Collect = DB::fetch_first('SELECT * FROM '.DB::table($this->TableInfoCollection).' where uid = '.$GetData['uid'].' and iid = '.$GetData['iid']);

		if($Collect){
			DB::delete($this->TableInfoCollection,'uid ='.$GetData['uid'].' and iid = '.$GetData['iid']);
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['DelCollectionHouseTitle']);
		}else{
			if(DB::insert($this->TableInfoCollection,$GetData)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['OkCollectionHouseTitle']);
			}
		}
		return $Data;
	}

	/* �ҵ��ղط�Դ */
	public function GetUserInfoCollectArray(){
		global $_G;
		$MyCollectArray = DB::fetch_all('SELECT iid FROM '.DB::table($this->TableInfoCollection).' where uid = '.intval($_G['uid']).' order by id desc');
		foreach($MyCollectArray as $Key => $Val) {
			$MyCollectIdArray[] = $Val['iid'];
		}
		return $MyCollectIdArray;
	}

	/* �ҵĹ���Դ������¼ */
	public function GetUserInfoPayLogFirst($iid){
		global $_G;
		return DB::fetch_first('SELECT * FROM '.DB::table($this->TableInfoPayLog).' where uid = '.intval($_G['uid']).' and iid = '.intval($iid));
	}

	/* �ղ�¥�� */
	public function GetAjaxDiscCollect($Id){
		global $_G;
		$GetData['uid'] = intval($_G['uid']);
		$GetData['username'] = addslashes(strip_tags($_G['username']));
		$GetData['iid'] = intval($Id);
		$GetData['dateline'] = time();
		
		$Collect = DB::fetch_first('SELECT * FROM '.DB::table($this->TableDiscCollection).' where uid = '.$GetData['uid'].' and iid = '.$GetData['iid']);

		if($Collect){
			DB::delete($this->TableDiscCollection,'uid ='.$GetData['uid'].' and iid = '.$GetData['iid']);
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['DelCollectionHouseTitle']);
		}else{
			if(DB::insert($this->TableDiscCollection,$GetData)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['OkCollectionDiscTitle']);
			}
		}
		return $Data;
	}

	/* �ҵ��ղ�¥�� */
	public function GetUserDiscCollectArray(){
		global $_G;
		$MyCollectArray = DB::fetch_all('SELECT iid FROM '.DB::table($this->TableDiscCollection).' where uid = '.intval($_G['uid']).' order by id desc');
		foreach($MyCollectArray as $Key => $Val) {
			$MyCollectIdArray[] = $Val['iid'];
		}
		return $MyCollectIdArray;
	}
	
	/* �ҵ������� */
	public function GetUserDemandPayLogArray(){
		global $_G;
		$Array = DB::fetch_all('SELECT did FROM '.DB::table($this->TableDemandPayLog).' where uid = '.intval($_G['uid']).' order by id desc');
		foreach($Array as $Key => $Val) {
			$ArrayId[] = $Val['did'];
		}
		return $ArrayId;
	}
	
	/* ����/���¶��ַ�/���ⷿ�������¼ */
	public function InsertInfoLog($Id){
		global $_G;
		$InfoLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableInfoLog).' where iid = '.intval($Id).' and uid = '.intval($_G['uid']));
		if($InfoLog){
			DB::update($this->TableInfoLog,array('updateline'=>time()),'id = '.intval($InfoLog['id']));
		}else{
			$Data['iid'] = intval($Id);
			$Data['uid'] = intval($_G['uid']);
			$Data['username'] = addslashes(strip_tags($_G['username']));
			$Data['dateline'] = $Data['updateline'] = time();
			DB::insert($this->TableInfoLog,$Data);
		}
	}

	/* ����¥�������¼ */
	public function InsertDiscoLog($Id){
		global $_G;
		$InfoLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableDiscLog).' where iid = '.intval($Id).' and uid = '.intval($_G['uid']));
		if($InfoLog){
			DB::update($this->TableDiscLog,array('updateline'=>time()),'id = '.intval($InfoLog['id']));
		}else{
			$Data['iid'] = intval($Id);
			$Data['uid'] = intval($_G['uid']);
			$Data['username'] = addslashes(strip_tags($_G['username']));
			$Data['dateline'] = $Data['updateline'] = time();
			DB::insert($this->TableDiscLog,$Data);
		}
	}

	/* �ٱ��û� */
	public function GetAjaxReport($Get){
		global $_G,$Config;
		$Get = StrToGBK($Get);
		$GetData['uid'] = intval($_G['uid']);
		$GetData['username'] = addslashes(strip_tags($_G['username']));
		$GetData['ip'] = addslashes(strip_tags($_G['clientip']));
		$GetData['iid'] = intval($Get['iid']);
		$GetData['content'] = censor(addslashes(strip_tags($Get['content'])));
		$GetData['state'] = 0;
		$GetData['dateline'] = time();
		
		if(in_array($_G['uid'],array_filter(explode(",",$this->Config['PluginVar']['ReportProhibitUis'])))){//���ξٱ�
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportProhibitErr']);
			return $Data;
		}

		if($this->Config['PluginVar']['ReportNum'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoReport).' where uid = '.intval($_G['uid']).' and iid = '.intval($Get['iid'])) >= $this->Config['PluginVar']['ReportNum']){
			$Data['Msg'] = urlencode(str_replace(array('{num}'),array($this->Config['PluginVar']['ReportNum']),$this->Config['PluginVar']['ReportNumTips']));
			return $Data;
		}

		if(!$GetData['content']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportContentErr']);
			return $Data;
		}
		if(DB::insert($this->TableInfoReport,$GetData)){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportOk']);
			$Data['State'] = 200;

			//��Ϣ֪ͨ
			$Msg = str_replace(array('{Content}'),array($GetData['content']),$this->Config['LangVar']['ReportPush']);
			$Item = $this->GetViewthread($Get['iid']);

			foreach($this->AdminUidsList as $Key => $Val) {//����Ա֪ͨ
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$this->Config['ViewUrl'].$GetData['iid'],
						'msg'=>$Msg
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['ViewUrl'].$GetData['iid'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv($Msg,CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}

			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv($Msg,CHARSET,'UTF-8'),
					'url'=>$this->Config['ViewUrl'].$GetData['iid']
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
			//��Ϣ֪ͨEnd

		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportErr']);
		}
		return $Data;
	}

	/* �û��ֻ���� */
	public function GetAjaxMobile($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$GetData['uid'] = intval($_G['uid']);
		$GetData['username'] = addslashes(strip_tags($_G['username']));
		$GetData['iid'] = intval($Get['iid']);
		$GetData['type'] = intval($Get['type']);
		$GetData['name'] = censor(addslashes(strip_tags($Get['name'])));
		$GetData['mobile'] = censor(addslashes(strip_tags($Get['mobile'])));
		if(!checkmobile()){
			$port = 1;
		}else{
			if(WxApp){
				$port = 2;
			}else if(App){
				$port = 4;
			}else{
				$port = 3;
			}
		}
		$GetData['port'] = $port;
		
		if(!$GetData['name']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactsPlaceholder']);
			return $Data;
		}

		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		if(!$GetData['mobile']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactNumberPlaceholder']);
			return $Data;
		}else if(!preg_match($IsMob,$GetData['mobile'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
			return $Data;
		}

		$CheCkMobile = DB::fetch_first('SELECT * FROM '.DB::table($this->TableDiscMobile).' where iid = '.$GetData['iid'].' and mobile = '.$GetData['mobile'].' and type = '.$GetData['type']);

		if($CheCkMobile){
			$GetData['updateline'] = time();
			DB::update($this->TableDiscMobile,$GetData,'id = '.intval($CheCkMobile['id']));
			$Data['Msg'] = urlencode($this->Config['LangVar']['DiscMobileMsg'][$GetData['type']]);
			$Data['State'] = 200;
		}else{
			$GetData['dateline'] = time();
			if(DB::insert($this->TableDiscMobile,$GetData)){
				$Data['Msg'] = urlencode($this->Config['LangVar']['DiscMobileMsg'][$GetData['type']]);
				$Data['State'] = 200;
				
				//��Ϣ֪ͨEnd
				$Item = $this->GetViewDiscthread($GetData['iid']);
				$Content = '<br>'.$this->Config['LangVar']['Contacts'].$this->Config['LangVar']['MaoHao'].$GetData['name'].'<br>'.$this->Config['LangVar']['Mobile'].$this->Config['LangVar']['MaoHao'].$GetData['mobile'].'<br>'.$this->Config['LangVar']['Type'].$this->Config['LangVar']['MaoHao'].$this->Config['LangVar']['DiscMobileTypeArray'][$GetData['type']];
				
				foreach(array_filter(explode(",",$Item['param']['push_uids'])) as $Key => $Val) {
					$this->AdminUidsList[] = $Val;
				}
				$this->AdminUidsList = array_unique($this->AdminUidsList);
				foreach($this->AdminUidsList as $Key => $Val) {
					if(DzNotice){
						notification_add($Val,'system','{msg}',array(
							'msg'=>str_replace(array('{Title}','{Content}'),array($Item['title'],$Content),$this->Config['LangVar']['DiscMobilePushContent'])
						),1);//ϵͳ֪ͨ
					}
					if($Config['PluginVar']['AppType'] == 1){//������������
						$PushData['Uid'] = $Val;
						$PushData['Type'] = 'pictemp';
						$PushData['Content'] = array(
							"tag"=> diconv(str_replace(array('{Title}'),array($Item['title']),$this->Config['LangVar']['DiscMobilePushTitle']),CHARSET,'UTF-8'),
							"title"=> diconv($this->Config['LangVar']['Content'],CHARSET,'UTF-8'),
							"link"=> $this->Config['ViewDiscUrl'].$Item['id'],
							"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
							"extra_info"=>array(
								array(
									"key"=>diconv($this->Config['LangVar']['Contacts'],CHARSET,'UTF-8'),
									"val"=>diconv($GetData['name'],CHARSET,'UTF-8')
								),
								array(
									"key"=>diconv($this->Config['LangVar']['Mobile'],CHARSET,'UTF-8'),
									"val"=>diconv($GetData['mobile'],CHARSET,'UTF-8')
								),
								array(
									"key"=>diconv($this->Config['LangVar']['Type'],CHARSET,'UTF-8'),
									"val"=>diconv($this->Config['LangVar']['DiscMobileTypeArray'][$GetData['type']],CHARSET,'UTF-8')
								)
							)
						);
						$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
					}
				}
				if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
					$PushData['Uid'] = implode(',',$this->AdminUidsList);
					$PushData['Msg'] = diconv(str_replace(array('{Title}'),array($Item['title']),$this->Config['LangVar']['DiscMobilePushTitle']),CHARSET,'UTF-8');
					$PushData['Content'] = array(
						'title'=>diconv(str_replace(array('{Title}'),array($Item['title']),$this->Config['LangVar']['DiscMobilePushTitle']),CHARSET,'UTF-8'),
						'date'=>date('Y-m-d H:i:s'),
						'setting'=>array(
							array(
								"setKey"=>diconv($this->Config['LangVar']['Contacts'],CHARSET,'UTF-8'),
								"setValue"=>diconv($GetData['name'],CHARSET,'UTF-8')
							),
							array(
								"setKey"=>diconv($this->Config['LangVar']['Mobile'],CHARSET,'UTF-8'),
								"setValue"=>diconv($GetData['mobile'],CHARSET,'UTF-8')
							),
							array(
								"setKey"=>diconv($this->Config['LangVar']['Type'],CHARSET,'UTF-8'),
								"setValue"=>diconv($this->Config['LangVar']['DiscMobileTypeArray'][$GetData['type']],CHARSET,'UTF-8')
							)
						),
						'content' => '',
						'url'=>$this->Config['ViewDiscUrl'].$Item['id']
					);
					$this->QHApp->GetMessagesTemplate($PushData);
				}
				//��Ϣ֪ͨEnd

				if($Item['param']['push_mobile']){//����֪ͨ
					@require_once libfile('class/short_message','plugin/fn_assembly');
					if($Config['PluginVar']['ShortMessageType'] == 1){
						$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
						$TemplateParam = array('title'=>$Item['title'],'name'=>$GetData['name'],'form_type'=>$this->Config['LangVar']['FormTypeArray'][$GetData['type']],'phone'=>$GetData['mobile']);
					}else if($Config['PluginVar']['ShortMessageType'] == 2){
						$TemplateCode = str_replace(array('{title}','{name}','{form_type}','{phone}'),array($Item['title'],$GetData['name'],$this->Config['LangVar']['FormTypeArray'][$GetData['type']],$GetData['mobile']),$this->Config['PluginVar']['ChanyooNotice']);
						$TemplateParam = array();
					}
					$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$Item['param']['push_mobile'],$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$GetData['uid'],$GetData['username'],'fn_house',2);
				}

			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DiscMobileMsgErr']);
			}
		}

		return $Data;
	}

	/* ����Ա������Դ�б� */
	public function GetAjaxAdminInfoList($Get){
		global $_G;
		$Results = array();
		$Get = StrToGBK($Get);
		if($this->Admin){
			$Where = ' and I.payment_state = 1';
			if($Get['type'] == 'Hot0'){
				$Where .= ' and I.hot = 0';
			}else if($Get['type'] == 'Hot1'){
				$Where .= ' and I.hot = 1';
			}else if($Get['type'] == 'Deal0'){
				$Where .= ' and I.deal = 0';
			}else if($Get['type'] == 'Deal1'){
				$Where .= ' and I.deal = 1';
			}else if($Get['type'] == 'Display0'){
				$Where .= ' and I.display = 0';
			}else if($Get['type'] == 'Display1'){
				$Where .= ' and I.display = 1';
			}
			
			$Order = 'I.edit_dateline';

			$Page = $Get['page'] ? intval($Get['page']) : 0;

			$Where = preg_replace('/and/','where',$Where,1);
			$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
			$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];
			
			$FetchSql = 'SELECT I.* FROM '.DB::table($this->TableInfo).' I'.$Where.' order by '.$Order.' desc,I.dateline desc '.$Limit;
			$Results = $this->InfoListFormat(DB::fetch_all($FetchSql));

		}
		return $Results;
	}

	/* ����Ա�޸��ֶ�ֵ */
	public function GetAjaxAdminEditInfoFields($Id,$Field,$Val){
		global $_G;
		if($this->Admin){
			$UpData[$Field] = intval($Val);
			DB::update($this->TableInfo,$UpData,'id = '.intval($Id));
		}
		$Data['State'] = 200;
		return $Data;
	}

	/* �ŵ��ײ��б� */
	public function GetAgentGroupList(){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableAgentGroup).' where display = 1 order by displayorder desc');//��������
	}

	/* �ŵ����� */
	public function GetAgentthread($Id,$My = false){
		global $_G;
		$Item = $My ? DB::fetch_first('SELECT A.*,AU.face,AG.ico FROM '.DB::table($this->TableAgent).' A LEFT JOIN `'.DB::table($this->TableAgentUser).'` AU on AU.agent_id = A.id and AU.uid = A.uid LEFT JOIN `'.DB::table($this->TableAgentGroup).'` AG on AG.id = A.group_id where A.uid = '.intval($_G['uid'])) : DB::fetch_first('SELECT A.*,AU.face,AG.ico FROM '.DB::table($this->TableAgent).' A LEFT JOIN `'.DB::table($this->TableAgentUser).'` AU on AU.agent_id = A.id and AU.uid = A.uid LEFT JOIN `'.DB::table($this->TableAgentGroup).'` AG on AG.id = A.group_id where A.id = '.intval($Id));

		if($Item){
			$Item['store_vip'] = $Item['due_time'] > time() ? true : false;
			$Item['province_text'] = $this->Area[$Item['province']]['content'].($Item['city'] ? '-'.$this->Area[$Item['city']]['content'] : '').($Item['dist'] ? '-'.$this->Area[$Item['dist']]['content'] : '');

			$Item['banner'] = array_filter(explode(",",$Item['banner']));
			
			$Item['info_count'] =  DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where display = 1 and payment_state = 1 and agent_id = '.$Item['id']);

			$Item['agent_user_count'] =  DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableAgentUser).' where work_state = 1 and agent_id = '.$Item['id'].' and due_time >= '.time());

		}
		return $Item;
	}

	/* �����ŵ� */
	public function GetStoreJoin($Aid){
		global $_G;
		$Data = array();
		$Item = $this->GetAgentthread($Aid);
		if($Item){

			if(!$Item['store_vip'] || !$Item['display']){//δ��ͨ�ŵ��ײͣ��ݲ�֧�����ӳ�Ա
				$Data['Msg'] = urlencode($this->Config['LangVar']['StoreJoinErrArray'][4]);
				return $Data;
			}
			
			//��ѯ�Ƿ��Ѽ�����ŵ�
			$CheCkUserInfo = DB::fetch_first('SELECT * FROM '.DB::table($this->TableAgentUser).' where uid = '.intval($_G['uid']).' and agent_id = '.intval($Aid));
			
			if($CheCkUserInfo){
				$Data['Msg'] = urlencode($this->Config['LangVar']['StoreJoinErrArray'][2]);
				return $Data;
			}

			@require_once libfile('function/forum');

			//���Ӿ�����
			$AUID = DB::insert($this->TableAgentUser,array(
				'uid'=>intval($_G['uid']),
				'username'=>addslashes(strip_tags($_G['username'])),
				'face'=> discuz_uc_avatar($_G['uid'],middle,true),
				'agent_id'=>intval($Aid),
				'name'=>addslashes(strip_tags($_G['username'])),
				'mobile'=>GetMobile(),
				'identity'=>2,
				'work_state'=>2,
				'dateline'=>time()
			),true);

			if($AUID){
				$Data['Msg'] = urlencode($this->Config['LangVar']['StoreJoinErrArray'][200]);
				$Data['State'] = 200;
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['StoreJoinErrArray'][3]);
			}
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['StoreJoinErrArray'][1]);
		}
		return $Data;

	}

	/* �ŵ��Ŷӳ�Ա */
	public function GetStoreAgentList($Agentid){
		return $this->AgentUserListFormat(DB::fetch_all('SELECT * FROM '.DB::table($this->TableAgentUser).' where agent_id = '.intval($Agentid).' and work_state = 1 and due_time >= '.time().' ORDER BY topdateline > '.time().' desc,updateline DESC'));//��������
	}

	/*  �Ҷ��� ��÷� */
	public function GetIndexAgentUserList(){
		$Results = array();
		$Results =  $this->AgentUserListFormat(DB::fetch_all('SELECT AU.*,A.title as store_title  FROM '.DB::table($this->TableAgentUser).' AU LEFT JOIN `'.DB::table($this->TableAgent).'` A on A.id = AU.agent_id where AU.due_time >= '.time().' AND AU.work_state = 1 ORDER BY AU.topdateline > '.time().' desc, AU.updateline DESC LIMIT 0,20'));
		return $Results;
	}

	/* �������б� */
	public function GetAjaxAgentUserList($Get=null){
		
		$Results = array();
		$Get = StrToGBK($Get);
		$Page = $Get['page'] ? intval($Get['page']) : 0;
		$Where = ' and AU.due_time >= '.time().' and AU.work_state = 1';
		$Order = 'AU.updateline';
	
		if($Get['keyword']){
			$Where .= ' and ( AU.name like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];
		
		$Results = $this->AgentUserListFormat(DB::fetch_all('SELECT AU.*,AG.ico,A.province,A.city,A.dist,A.community,A.title as agent_title FROM '.DB::table($this->TableAgentUser).' AU LEFT JOIN `'.DB::table($this->TableAgentGroup).'` AG on AG.id = AU.group_id LEFT JOIN `'.DB::table($this->TableAgent).'` A on A.id = AU.agent_id '.$Where.' ORDER BY AU.topdateline > '.time().' desc,'.$Order.' DESC '.$Limit));

		return $Results;
	}

	/* �ŵ��б� */
	public function GetAjaxAgentList($Get=array()){
		$Results = array();
		
		$Where = ' and A.display = 1 ';

		$Get = StrToGBK($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0;

		if($Get['keyword']){
			$Where .= ' and ( A.title like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 'LIMIT '.($Page * 10).',10';

		$Results = $this->AgentListFormat(DB::fetch_all('SELECT A.* FROM '.DB::table($this->TableAgent).' A '.$Where.' order by A.topdateline > '.time().' desc,A.updateline desc '.$Limit));
		return $Results;
	}

	/* �ҵ��Ŷӳ�Ա */
	public function GetAjaxUserStoreTeamList($Get){
		global $_G;
		$UserInfo = $this->GetUserInfo();
		$Results = array();
		$Get = StrToGBK($Get);
		
		$Page = $Get['page'] ? intval($Get['page']) : 0;
		
		$Where = ' and agent_id = '.intval($UserInfo['agent_id']);

		if($Get['work_state']){//�ŵ����Ա
			$Where .= ' and work_state = '.intval($Get['work_state']);
		}

		$Order = 'id';

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];
		
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableAgentUser).$Where.' order by '.$Order.' desc '.$Limit;
		$Results = $this->TeamAgentUserListFormat(DB::fetch_all($FetchSql));

		return $Results;
	}

	/* �Ŷӳ�Ա��ʽת�� */
	public function TeamAgentUserListFormat($Array){
		global $_G;
		
		foreach ($Array as $Key => $Val) {
			$InfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where  payment_state = 1 and uid = '.$Val['uid']);

			$InfoDayCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where  payment_state = 1 and uid = '.$Val['uid'].' and dateline >= '.strtotime(date('Y-m-d',time())).' and dateline <='.strtotime(date('Y-m-d 23:59:59',time())));

			$InfoYesterdayCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where  payment_state = 1 and uid = '.$Val['uid'].' and dateline >= '.strtotime(date('Y-m-d 00:00:00',time()-3600*24)).' and dateline <='.strtotime(date('Y-m-d 23:59:59',time()-3600*24)));

			$Array[$Key]['work_state_text'] = $this->Config['LangVar']['WorkStateArray'][$Val['work_state']];
			$Array[$Key]['dateline_text'] = date('Y-m-d',$Val['dateline']);
			$Array[$Key]['count_text'] = str_replace(array('{Count}','{YesterdayCount}','{DayCount}','{Click}'),array($InfoCount,$InfoYesterdayCount,$InfoDayCount,$Val['click']),$this->Config['LangVar']['AgentUserCountText']);

		}
		return $Array;
	}

	/* ���������� */
	public function GetAjaxOpAgentUser($Auid,$Action){
		global $_G;
		$UserInfo = $this->GetUserInfo();
		$AgentUserUserInfo = $this->GetUserInfo($Auid);
		if($AgentUserUserInfo['agent_id'] == $UserInfo['agent_id']){
			if($Action == 'agree'){//ͬ��
				if($UserInfo['number']){//�������ж�
					$AgentUserCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableAgentUser).' where  work_state = 1 and agent_id = '.$AgentUserUserInfo['agent_id']);
					
					if($AgentUserCount >= $UserInfo['number']){
						$Data['Msg'] = urlencode($this->Config['LangVar']['StoreNumberMaxErr']);
						return $Data;
					}
				}

				DB::update($this->TableAgentUser,array('work_state'=>1),'id = '.intval($Auid));
				DB::update($this->TableInfo,array('agent_id'=>$AgentUserUserInfo['agent_id'],'publish_type'=>2),'uid = '.intval($AgentUserUserInfo['uid']));
			}else if($Action == 'refuse'){//�ܾ�
				DB::delete($this->TableAgentUser,'id ='.intval($Auid));
			}
			$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			$Data['State'] = 200;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['OpErr']);
		}
		return $Data;
	}

	/* �����˸�ʽת�� */
	public function AgentUserListFormat($Array){
		global $_G;
		foreach ($Array as $Key => $Val) {

			$Array[$Key]['url'] = $this->Rewrite('view_agent',array('auid'=>$Val['id']));

			$Array[$Key]['vip'] = $Val['due_time'] > time() ? true : false;

			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? true : false;
			
			$Array[$Key]['info_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where display = 1 and payment_state = 1 and uid = '.$Val['uid']);

			$Array[$Key]['info_count_text'] = str_replace(array('{Count}'),array($Array[$Key]['info_count']),$this->Config['LangVar']['StorInfoCout']);

			$Array[$Key]['mobile'] = $Val['mobile'] ? $Val['mobile'] : GetMobile();

			$Array[$Key]['agent_title'] = $Val['agent_title'] ? $Val['agent_title'] : '';

			$Array[$Key]['province_text'] = $this->Area[$Val['province']]['content'].($Val['city'] ? '-'.$this->Area[$Val['city']]['content'] : '').($Val['dist'] ? '-'.$this->Area[$Val['dist']]['content'] : '');

		}
		return $Array;
	}

	/* �ŵ��ʽת�� */
	public function AgentListFormat($Array){
		global $_G;
		foreach ($Array as $Key => $Val) {
			
			$Array[$Key]['url'] = $this->Rewrite('store',array('aid'=>$Val['id']));

			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? true : false;

			$Array[$Key]['province_text'] = $this->Area[$Val['province']]['content'].($Val['city'] ? '-'.$this->Area[$Val['city']]['content'] : '').($Val['dist'] ? '-'.$this->Area[$Val['dist']]['content'] : '');

			$Array[$Key]['store_vip'] = $Val['due_time'] > time() ? true : false;
			
			$Array[$Key]['info_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where display = 1 and payment_state = 1 and agent_id = '.$Val['id']);

			$Array[$Key]['agent_user_count'] =  DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableAgentUser).' where due_time >= '.time().' and work_state = 1 and agent_id = '.$Val['id']);

			$Array[$Key]['info_count_text'] = str_replace(array('{Count}'),array($Array[$Key]['info_count']),$this->Config['LangVar']['StorInfoCout']);

			$Array[$Key]['agent_user_count_text'] = str_replace(array('{Count}'),array($Array[$Key]['agent_user_count']),$this->Config['LangVar']['StorAgentCout']);
			
			$Array[$Key]['info_list'] = $this->InfoListFormat(DB::fetch_all('SELECT * FROM '.DB::table($this->TableInfo).' where display = 1 and payment_state = 1 and agent_id = '.$Val['id'].' order by topdateline > '.time().' desc,updateline desc,dateline desc limit 3'));

		}
		return $Array;
	}

	/* ��������פ */
	public function GetAjaxUserAgentInfo($Get){
		global $_G,$Config;

		$Get = EncodeURIToUrldeCode($Get);
		$UserInfo = $this->GetUserInfo();
		//$AgentUserInfo = $this->GetUserInfo($Get['auid']);
		
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
	
		foreach(array_filter(explode(';',$Get['new_face'][0])) as $Key => $Val) {
			$Get['new_face'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach(array_filter(explode(';',$Get['new_qr'][0])) as $Key => $Val) {
			$Get['new_qr'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		
		$UpData['face'] = addslashes(strip_tags($Get['new_face'][0]));
		$UpData['qr'] = addslashes(strip_tags($Get['new_qr'][0]));

		$UpData['name'] = censor(addslashes(strip_tags($Get['name'])));
		$UpData['full_name'] = addslashes(strip_tags($Get['full_name']));
		$UpData['id_number'] = addslashes(strip_tags($Get['id_number']));
		$UpData['mobile'] = censor(addslashes(strip_tags($Get['mobile'])));
		$UpData['wx'] = $Get['mobile_wx'] ? $UpData['mobile'] : censor(addslashes(strip_tags($Get['wx'])));
		$UpData['identity'] = 2;
		$UpData['work_state'] = 1;
		$UpData['agent_id'] = intval($Get['agent_id']);

		if(!$UpData['face']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AgentLogoErr']);
			return $Data;
		}

		if(!$UpData['name']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactsPlaceholder']);
			return $Data;
		}
		
		if(!$UpData['full_name'] && $this->Config['PluginVar']['AgentAuthenticationSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['FullNamePlaceholder']);
			return $Data;
		}

		if(!$UpData['id_number'] && $this->Config['PluginVar']['AgentAuthenticationSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['IdNumberPlaceholder']);
			return $Data;
		}else if($this->Config['PluginVar']['AgentAuthenticationSwitch'] && dstrlen($UpData['id_number']) != 18){
			$Data['Msg'] = urlencode($this->Config['LangVar']['IdNumberErr']);
			return $Data;
		}else if($this->Config['PluginVar']['AgentAuthenticationSwitch'] && DB::fetch_first('SELECT * FROM '.DB::table($this->TableAgentUser).' where id_number = \''.$UpData['id_number'].'\' and uid != '.$UpData['uid'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['IdNumberErr1']);
			return $Data;
		}

		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		if(!$UpData['mobile']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactNumberPlaceholder']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['mobile'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
			return $Data;
		}

		if($CheckMobileData = DB::fetch_first('SELECT * FROM '.DB::table($this->TableAgentUser).' where mobile = '.$UpData['mobile'].' and uid != '.$UpData['uid'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileRepeatErr']);
			return $Data;
		}

		if(!$UpData['agent_id'] && $this->Config['PluginVar']['ChoiceStoreSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactsPlaceholder']);
			return $Data;
		}

		if($this->Config['PluginVar']['AgentAuthenticationSwitch'] && (($UserInfo && !$UserInfo['verify']) || !$UserInfo)){//��֤�ж�
			
			$headers = array();
			array_push($headers, "Authorization:APPCODE " . $this->Config['PluginVar']['AuthenticationCode']);
			
			$url = 'https://phonecheck.market.alicloudapi.com/phoneAuthentication';

			$Res = json_decode(CurlPost($url,array('idNo'=>$UpData['id_number'],'name'=>diconv($UpData['full_name'],CHARSET,'UTF-8'),'phoneNo'=>$UpData['mobile']),$headers),true);
			
			if($Res['respCode'] === '0008'){
				$Data['Msg'] = urlencode($this->Config['LangVar']['AgentVerifyAddErr0008']);
				return $Data;
			}else if($Res['respCode'] !== '0000'){
				$Data['Msg'] = urlencode(diconv($Res['respMessage'],'UTF-8',CHARSET));
				return $Data;
			}else{
				$UpData['verify'] = 1;
			}
			
		}

		if($UserInfo['id']){
			DB::update($this->TableAgentUser,$UpData,'id = '.intval($UserInfo['id']));
			if($UserInfo['vip']){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['AddAgentOk']);
				$Data['State'] = 201;
			}
		}else{
			$UpData['dateline'] = $UpData['updateline'] = time();
			$AUID = DB::insert($this->TableAgentUser,$UpData,true);
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddAgentOk']);
			$Data['State'] = 201;
		}

		return $Data;


	}

	/* ��פ�ŵ� */
	public function GetAjaxPublishAgent($Get){
		global $_G,$Config;

		$Get = StrToGBK($Get);

		$Item = $this->GetAgentthread($Get['aid']);
		
		$UpData['title'] = censor(addslashes(strip_tags($Get['title'])));
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['province'] = censor(addslashes(strip_tags($Get['province'])));
		$UpData['city'] = censor(addslashes(strip_tags($Get['city'])));
		$UpData['dist'] = censor(addslashes(strip_tags($Get['dist'])));
		$UpData['community'] = censor(addslashes(strip_tags($Get['community'])));
		$UpData['tel'] = censor(addslashes(strip_tags($Get['tel'])));
		$UpData['content'] = censor(addslashes(strip_tags($Get['content'])));
		
		foreach($Get['new_face'] as $Key => $Val) {
			$Get['new_face'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($Get['new_banner'] as $Key => $Val) {
			$Get['new_banner'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		

		$UpData['logo'] = addslashes(strip_tags($Get['new_face'][0]));

		$UpData['banner'] = is_array($Get['new_banner']) && isset($Get['new_banner']) ? implode(',',$Get['new_banner']) : '';
		
		if(!$Get['new_face'][0]){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AgentLogoErr']);
			return $Data;
		}

		if(!$UpData['title']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AgentTitlePlaceholder']);
			return $Data;
		}

		if(!$UpData['province']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AgentRegionPlaceholder']);
			return $Data;
		}

		if(!$UpData['community']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CommunityPlaceholder']);
			return $Data;
		}

		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		$IsTel = "/".$Config['PluginVar']['LandlineMatch']."/";

		if(!$UpData['tel']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AgentTelPlaceholder']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['tel']) && !preg_match($IsTel,$UpData['tel'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AgentTelErr']);
			return $Data;
		}

		/*if(!$UpData['group_id'] && (!$Item['payment_state'] || !$Item['store_vip'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ChoicePackagePlaceholder']);
			return $Data;
		}

		$ItemGroup = DB::fetch_first('SELECT * FROM '.DB::table($this->TableAgentGroup).' where id = '.$UpData['group_id']);*/

		if($Item){
			$UpData['updateline'] = time();
			if(DB::update($this->TableAgent,$UpData,'id = '.intval($Item['id']))){
			
				$Data['Id'] = $Item['id'];
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
				/*if($ItemGroup['money'] && !$Item['payment_state']){
					$PayLog = $this->GetAjaxPayLog(array('money'=>$ItemGroup['money'],'event'=>'publish_agent','aid'=>$Item['id'],'month'=>$ItemGroup['group_time']));
					$Data['Money'] = $ItemGroup['money'];
					$Data['PayId'] = $PayLog['Id'];
					$Data['State'] = 201;
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
					$Data['State'] = 202;
				}*/
				$Data['State'] = 202;
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
		}else{
			/*if($ItemGroup['money']){
				$UpData['payment_state'] = 0;
			}else{
				$UpData['payment_state'] = 1;
			}*/
			$UpData['dateline'] = $UpData['updateline'] = time();

			$AId = DB::insert($this->TableAgent,$UpData,true);
			
			if($AId){
				//���Ӿ�����
				DB::insert($this->TableAgentUser,array(
					'uid'=>$UpData['uid'],
					'username'=>$UpData['username'],
					'face'=>addslashes(strip_tags($Get['new_face'][0])),
					'agent_id'=>$AId,
					'name'=>$UpData['username'],
					'mobile'=>$UpData['tel'],
					'identity'=>1,
					'work_state'=>1,
					'dateline'=>time()
				));

				//�޸ĵ�ǰ�û��ķ�Դ״̬
				DB::update($this->TableInfo,array('agent_id'=>$AId,'publish_type'=>2),'uid = '.intval($UpData['uid']));

				$Data['Id'] = $AId;
				$Data['Msg'] = urlencode($this->Config['LangVar']['AgentSuccess']);
				/*if($ItemGroup['money']){
					$PayLog = $this->GetAjaxPayLog(array('money'=>$ItemGroup['money'],'event'=>'publish_agent','aid'=>$AId,'month'=>$ItemGroup['group_time']));
					$Data['Money'] = $ItemGroup['money'];
					$Data['PayId'] = $PayLog['Id'];
					$Data['State'] = 201;
				}else{
					$Data['State'] = 200;
				}*/
				$Data['State'] = 200;
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['AgentErr']);
			}

		}
		return $Data;
	}

	/* ��ͨ�ײ� */
	public function GetAjaxBuyStoreLevel($Get){
		global $_G;
		$ItemGroup = DB::fetch_first('SELECT * FROM '.DB::table($this->TableAgentGroup).' where id = '.$Get['group_id']);
		if(!$ItemGroup){
			$Data['Msg'] = urlencode($this->Config['LangVar']['PayErr']);
		}else{
			$UserInfo = $this->GetUserInfo();
			if($ItemGroup['money']){
				$PayLog = $this->GetAjaxPayLog(array('money'=>$ItemGroup['money'],'event'=>'buy_store_level','auid'=>$UserInfo['id'],'agent_id'=>$UserInfo['agent_id'],'group_id'=>$ItemGroup['id'],'month'=>$ItemGroup['group_time']));
				$Data['Money'] = $ItemGroup['money'];
				$Data['PayId'] = $PayLog['Id'];
				$Data['State'] = 200;
			}else{
				$UpData['group_id'] = $ItemGroup['id'];
				$UpData['due_time'] = $UserInfo['due_time'] >= time() && $UserInfo['group_id'] == $ItemGroup['id'] ? strtotime("+".intval($ItemGroup['group_time'])."  month",$UserInfo['due_time']) : strtotime("+".intval($ItemGroup['group_time'])."  month",time());
				DB::update($this->TableAgentUser,$UpData,'id = '.$UserInfo['id']);
				DB::update($this->TableInfo,array('agent_id'=>$UserInfo['agent_id'],'publish_type'=>2),' uid = '.intval($UserInfo['uid']));
				$Data['Msg'] = urlencode($UserInfo['vip'] ? $this->Config['LangVar']['BuyStoreLevelRenewOk'] : $this->Config['LangVar']['BuyStoreLevelOpenOK']);
				$Data['State'] = 201;
			}
			
		}
		return $Data;
	}

	/* ������ˢ�� */
	public function GetAjaxAgentUserRefresh($Get){
		global $_G;
		
		$Get = EncodeURIToUrldeCode($Get);

		$UserInfo = $this->GetUserInfo();

		if($UserInfo['vip'] && $UserInfo['money'] && $UserInfo['money'] >= intval($this->Config['PluginVar']['AgentRefreshMoney'])){
			if($this->InsertWalletLog($UserInfo['id'],intval($this->Config['PluginVar']['AgentRefreshMoney']),$this->Config['LangVar']['WalletBalanceTypeArray']['3'])){
				DB::query("UPDATE ".DB::table($this->TableAgentUser)." SET money = money - ".intval($this->Config['PluginVar']['AgentRefreshMoney']).",updateline = ".time()." WHERE id = ".intval($UserInfo['id']));
				$Data['State'] = 201;
				$Data['Msg'] = urlencode($this->Config['LangVar']['RefreshOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['OpErr']);
			}
		}else{
			$Data = $this->GetAjaxPayLog(array('event'=>'refresh_agent_user','money'=>$this->Config['PluginVar']['AgentRefreshMoney'],'auid'=>$UserInfo['id']));
		}

		return $Data;
	}

	/* �������ö� */
	public function GetAjaxAgentUserTop($Get){
		global $_G;
		
		$Get = EncodeURIToUrldeCode($Get);

		$UserInfo = $this->GetUserInfo();

		if($UserInfo['vip'] && $UserInfo['money'] && $UserInfo['money'] >= intval($Get['money'])){
			if($this->InsertWalletLog($UserInfo['id'],intval($Get['money']),$this->Config['LangVar']['WalletBalanceTypeArray']['4'])){
				DB::query("UPDATE ".DB::table($this->TableAgentUser)." SET money = money - ".intval($Get['money']).",updateline = ".time().",topdateline = ".($UserInfo['topdateline'] >= time() ? strtotime("+".intval($Get['day'])." day",$UserInfo['topdateline']) : strtotime("+".intval($Get['day'])." day",time()))." WHERE id = ".intval($UserInfo['id']));
				$Data['State'] = 201;
				$Data['Msg'] = urlencode($this->Config['LangVar']['SetTopOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['OpErr']);
			}
		}else{
			$Data = $this->GetAjaxPayLog(array('event'=>'top_agent_user','money'=>$Get['money'],'day'=>$Get['day'],'auid'=>$UserInfo['id']));
		}

		return $Data;
	}

	/* ˢ�·�Դ */
	public function GetAjaxRefresh($Get){
		global $_G;
		
		$Get = EncodeURIToUrldeCode($Get);

		$UserInfo = $this->GetUserInfo();
	
		if($Get['class'] == 1){
			$Money = $this->Config['PluginVar']['HouseRefreshMoney'];
		}else if($Get['class'] == 2){
			$Money = $this->Config['PluginVar']['RentalRefreshMoney'];
		}else if($Get['class'] == 3){
			$Money = $this->Config['PluginVar']['ShopRefreshMoney'];
		}else if($Get['class'] == 4){
			$Money = $this->Config['PluginVar']['WorkShopRefreshMoney'];
		}else if($Get['class'] == 5){
			$Money = $this->Config['PluginVar']['OfficeRefreshMoney'];
		}else if($Get['class'] == 6){
			$Money = $this->Config['PluginVar']['WarehouseRefreshMoney'];
		}else if($Get['class'] == 7){
			$Money = $this->Config['PluginVar']['LandRefreshMoney'];
		}
		

		if($UserInfo['vip'] && $UserInfo['day_refresh_count'] && $UserInfo['info_agent_reduce_day_refresh_count']){//�ײ�ˢ��
			$UpData['iid'] = intval($Get['iid']);
			$UpData['uid'] = intval($_G['uid']);
			$UpData['username'] = addslashes(strip_tags($_G['username']));
			$UpData['dateline'] = time();
			
			$LogId = DB::insert($this->TableAgentUserRefreshInfoLog,$UpData,true);
			if($LogId && DB::update($this->TableInfo,array('updateline'=> time()),' id = '.intval($Get['iid']))){
				$Data['State'] = 202;
				$Data['Msg'] = urlencode($this->Config['LangVar']['RefreshOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DayRefreshInfoErr2']);
			}
			return $Data;
		}else if($UserInfo['vip'] && $UserInfo['money'] && $UserInfo['money'] >= intval($Money)){
			if($this->InsertWalletLog($UserInfo['id'],$Money,$this->Config['LangVar']['WalletBalanceTypeArray']['1'].$Get['iid'])){
				DB::update($this->TableInfo,array('updateline'=>time()),' id = '.intval($Get['iid']));
				DB::query("UPDATE ".DB::table($this->TableAgentUser)." SET money = money - ".intval($Money)." WHERE id = ".intval($UserInfo['id']));
				$Data['State'] = 202;
				$Data['Msg'] = urlencode($this->Config['LangVar']['RefreshOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DayRefreshInfoErr2']);
			}
			return $Data;
		}else{
			if(!$UserInfo['vip'] && !$UserInfo['due_time'] && $this->Config['PluginVar']['RefreshDayNum'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableAgentUserRefreshInfoLog).' where iid = '.intval($Get['iid']).' and uid = '.intval($_G['uid']).' and type = 2 and dateline >= '.strtotime(date('Y-m-d')).' and dateline <='.strtotime(date('Y-m-d 23:59:59'))) < $this->Config['PluginVar']['RefreshDayNum']){
				$UpData['iid'] = intval($Get['iid']);
				$UpData['uid'] = intval($_G['uid']);
				$UpData['username'] = addslashes(strip_tags($_G['username']));
				$UpData['type'] =2;
				$UpData['dateline'] = time();
				$LogId = DB::insert($this->TableAgentUserRefreshInfoLog,$UpData,true);
				if($LogId && DB::update($this->TableInfo,array('updateline'=>time()),' id = '.intval($Get['iid']))){
					$Data['State'] = 201;
					$Data['Msg'] = urlencode($this->Config['LangVar']['RefreshOk']);
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['DayRefreshInfoErr2']);
				}
			}else{
				$Data = $this->GetAjaxPayLog(array('event'=>'refresh_info','money'=>$Money,'iid'=>$Get['iid'],'class'=>$Get['class']));
			}
		}

		return $Data;
	}

	/* �ö�ְλ */
	public function GetAjaxTop($Get){
		global $_G;
		
		$Get = EncodeURIToUrldeCode($Get);

		$UserInfo = $this->GetUserInfo();
		
		if($UserInfo['vip'] && $UserInfo['money'] >= intval($Get['original_money']) && $this->InsertWalletLog($UserInfo['id'],$Get['original_money'],$this->Config['LangVar']['WalletBalanceTypeArray']['2'].$Get['iid'])){

			$Item = $this->GetViewthread($Get['iid']);
			$Topdateline = $Item['topdateline'] >= time() ? strtotime("+".intval($Get['day'])." day",$Item['topdateline']) : strtotime("+".intval($Get['day'])." day",time());
			DB::update($this->TableInfo,array('updateline'=>time(),'topdateline'=>$Topdateline),' id = '.intval($Get['iid']));

			DB::query("UPDATE ".DB::table($this->TableAgentUser)." SET money = money - ".intval($Get['original_money'])." WHERE id = ".intval($UserInfo['id']));

			$Data['State'] = 201;
			$Data['topdateline'] = date('Y-m-d H:i',$Topdateline);
			return $Data;
		}else{
			return $this->GetAjaxPayLog(array('event'=>'top_info','money'=>$Get['money'],'day'=>$Get['day'],'iid'=>$Get['iid']));
		}

	}

	/* ��Ѷ���� */
	public function GetArticleClassList(){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableArticleClass).' where display = 1 order by displayorder asc',array(),'id');//��������
	}

	/* ���������¼ */
	public function InsertWalletLog($AgentId,$Money,$Content){
		global $_G;
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['agent_id'] = intval($AgentId);
		$UpData['content'] = addslashes(strip_tags($Content));
		$UpData['money'] = intval($Money);
		$UpData['dateline'] = time();
		if(DB::insert($this->TableWalletLog,$UpData)){
			return true;
		}else{
			return false;
		}
	}

	/* α��̬ */
	public function Rewrite($Mod,$ModArray = array()){
		global $_G;
		loadcache('fn_house_rewrite');
		$Rewrite = $_G['cache']['fn_house_rewrite'];
		if($Rewrite[$Mod]['available'] && !MinWxApp){
			$StrReplaceArray = array('{','}');
			$StrReplaceArrayTo = array('','');
			foreach($ModArray as $Key => $Val) {
				$StrReplaceArray[] = $Key;
				$StrReplaceArrayTo[] = $Val;
			}
			$Url = $_G['siteurl'].str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite[$Mod]['rule']);
		}else{
			if(in_array($Mod,array('list_1','list_2','list_3','list_4','list_5','list_6','list_7'))){
				$Array = explode('_',$Mod);
				$Mod = $Array[0];
				$ModArray = array('class'=>$Array[1]);
			}
			$Url = $this->Config['Url'].'&m='.$Mod.( !empty($ModArray) ? '&'.http_build_query($ModArray) : '' );
		}
		return $Url;
	}
	
	/* ����֧����¼ */
	public function GetAjaxPayLog($Get){
		global $_G;
		$Get = StrToGBK($Get);
		$Param['event'] = addslashes(strip_tags($Get['event']));
		if($Param['event'] == 'publish_info'){
			$Param['iid'] = $Get['iid'];
			$Content = $this->Config['LangVar']['ListPublishe'].$this->Config['LangVar']['IndexNav'][$Get['class']].'(ID:'.$Get['iid'].')';
		}else if($Param['event'] == 'refresh_info'){
			$Param['iid'] = $Get['iid'];
			$Param['updateline'] = time();
			$Content = $this->Config['LangVar']['Refresh'].$this->Config['LangVar']['IndexNav'][$Get['class']].'(ID:'.$Get['iid'].')';
		}else if($Param['event'] == 'top_info'){
			$Item = $this->GetViewthread($Get['iid']);
			$Param['iid'] = $Get['iid'];
			$Param['topdateline'] = $Item['topdateline'] >= time() ? strtotime("+".intval($Get['day'])." day",$Item['topdateline']) : strtotime("+".intval($Get['day'])." day",time());
			$Param['updateline'] = time();
			$Content = $this->Config['LangVar']['SetTop'].$this->Config['LangVar']['IndexNav'][$Get['class']].'(ID:'.$Get['iid'].')';
		}else if($Param['event'] == 'info_pay_log'){
			$Param['iid'] = $Get['iid'];
			$Param['insert_info_pay_log'] = array('iid'=>$Get['iid'],'uid'=>$_G['uid'],'username'=>$_G['username'],'dateline'=>time(),'updateline'=>time());
			$Content = $this->Config['LangVar']['InfoPayLogContent'].$Get['iid'];
			
		}else if($Param['event'] == 'demand_pay_log'){
			$Param['did'] = $Get['did'];
			$Param['insert_demand_pay_log'] = array('did'=>$Get['did'],'uid'=>$_G['uid'],'username'=>$_G['username'],'dateline'=>time());
			$Content = $this->Config['LangVar']['DemandPayLogContent'].$Get['did'];
			$Item = DB::fetch_first('SELECT mobile FROM '.DB::table($this->TableDemand).' where id = '.intval($Get['did']));
			$Mobile = $Item['mobile'];
		}else if($Param['event'] == 'buy_store_level'){
			$UserInfo = $this->GetUserInfo();
			$GroupItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableAgentGroup).' where id = '.$Get['group_id']);
			$Param['group_id'] = $Get['group_id'];
			$Param['auid'] = $Get['auid'];
			$Param['money'] = $GroupItem['currency'] + $UserInfo['money'];
			$Param['due_time'] = $UserInfo['due_time'] >= time() && $UserInfo['group_id'] == $Param['group_id'] ? strtotime("+".intval($Get['month'])."  month",$UserInfo['due_time']) : strtotime("+".intval($Get['month'])."  month",time());
			$Content = $this->Config['LangVar']['PayAgentContent'].$Get['auid'];
		}else if($Param['event'] == 'refresh_agent_user'){//ˢ�¾������б�
			$Param['auid'] = $Get['auid'];
			$Param['updateline'] = time();
			$Content = $this->Config['LangVar']['RefreshAgentUser'];
		}else if($Param['event'] == 'top_agent_user'){//�ö��������б�
			$UserInfo = $this->GetUserInfo();
			$Param['uid'] = $_G['uid'];
			$Param['agent_id'] = $Get['agent_id'];
			$Param['auid'] = $Get['auid'];
			$Param['topdateline'] = $UserInfo['topdateline'] >= time() ? strtotime("+".intval($Get['day'])." day",$UserInfo['topdateline']) : strtotime("+".intval($Get['day'])." day",time());
			$Param['updateline'] = time();
			$Content = $this->Config['LangVar']['TopAgentUser'];
		}
		$Data = $this->Pay->PayLogInsert($Get['money'],$Param,$Content,'fn_house');
		$Data['Mobile'] = $Mobile;
		return $Data;
	}
}

$Fn_House = new Fn_House;
?>