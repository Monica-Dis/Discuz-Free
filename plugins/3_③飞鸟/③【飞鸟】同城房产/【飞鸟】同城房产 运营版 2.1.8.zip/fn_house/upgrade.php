<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_house_agent` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `banner` text NOT NULL,
  `province` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `dist` varchar(20) NOT NULL,
  `community` varchar(255) NOT NULL,
  `lat` varchar(20) NOT NULL,
  `lng` varchar(20) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `due_time` int(11) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `before_dateline` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`group_id`,`uid`,`display`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_agent_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `info_my` tinyint(1) unsigned NOT NULL,
  `day_refresh_count` tinyint(3) unsigned NOT NULL,
  `day_info_count` int(11) unsigned NOT NULL,
  `info_count` int(11) unsigned NOT NULL,
  `number` int(11) unsigned NOT NULL,
  `examine` tinyint(1) unsigned NOT NULL,
  `entrust_data` tinyint(1) unsigned NOT NULL,
  `access_record` tinyint(1) unsigned NOT NULL,
  `access_record_mobile` tinyint(1) unsigned NOT NULL,
  `top_discount` varchar(20) NOT NULL,
  `currency` int(11) unsigned NOT NULL,
  `vr` tinyint(1) unsigned NOT NULL,
  `money` varchar(20) NOT NULL,
  `group_time` tinyint(3) unsigned NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_agent_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `group_id` tinyint(2) unsigned NOT NULL,
  `face` varchar(255) NOT NULL,
  `agent_id` int(11) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `full_name` varchar(30) NOT NULL,
  `id_number` varchar(20) NOT NULL,
  `verify` tinyint(1) unsigned NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `wx` varchar(50) NOT NULL,
  `qr` varchar(255) NOT NULL,
  `identity` tinyint(2) unsigned NOT NULL,
  `work_state` tinyint(1) unsigned NOT NULL,
  `money` int(11) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `due_time` int(11) unsigned NOT NULL,
  `before_dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`group_id`,`agent_id`,`verify`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_agent_user_refresh_info_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `iid` int(11) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`iid`,`uid`,`type`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `classid` int(11) unsigned NOT NULL,
  `disc_id` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `describe` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `jump` tinyint(1) unsigned NOT NULL,
  `jump_link` varchar(255) NOT NULL,
  `slide` tinyint(1) unsigned NOT NULL,
  `hot` tinyint(1) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`classid`,`disc_id`,`uid`,`display`,`hot`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_article_class` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_keyword` varchar(255) NOT NULL,
  `seo_desc` varchar(255) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_demand` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `province` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `dist` varchar(20) NOT NULL,
  `display` tinyint(3) unsigned NOT NULL,
  `payment_state` tinyint(1) unsigned NOT NULL,
  `deal` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `edit_dateline` int(11) unsigned NOT NULL,
  `param` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`type`,`uid`,`payment_state`,`display`,`deal`)
) ENGINE=MyISAM;


CREATE TABLE IF NOT EXISTS `pre_fn_house_demand_pay_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `did` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`did`,`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_disc` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `province` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `dist` varchar(20) NOT NULL,
  `community` varchar(255) NOT NULL,
  `lat` varchar(20) NOT NULL,
  `lng` varchar(20) NOT NULL,
  `price` int(11) unsigned NOT NULL,
  `count_price` decimal(11,2) unsigned NOT NULL,
  `tag` varchar(128) NOT NULL,
  `house_type` varchar(128) NOT NULL,
  `decoration_type` tinyint(2) unsigned NOT NULL,
  `type` tinyint(2) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `hot` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`state`,`type`,`display`,`hot`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_disc_collection` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `iid` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`iid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_disc_huxing` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `iid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `cover` varchar(255) NOT NULL,
  `room` tinyint(2) unsigned NOT NULL,
  `office` tinyint(2) unsigned NOT NULL,
  `guard` tinyint(2) unsigned NOT NULL,
  `orientation` tinyint(2) unsigned NOT NULL,
  `price` int(11) unsigned NOT NULL,
  `square` int(11) unsigned NOT NULL,
  `tag` varchar(30) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`iid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_disc_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `iid` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`iid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_disc_mobile` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `iid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `type` tinyint(2) unsigned NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `port` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`iid`)
) ENGINE=MyISAM;


CREATE TABLE IF NOT EXISTS `pre_fn_house_entrust` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `wx` varchar(30) NOT NULL,
  `class` tinyint(3) unsigned NOT NULL,
  `address` varchar(255) NOT NULL,
  `square` int(11) unsigned NOT NULL,
  `price` varchar(20) NOT NULL,
  `param` mediumtext NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `handle_dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) unsigned NOT NULL,
  `publish_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `class` tinyint(2) unsigned NOT NULL,
  `vice_class` tinyint(2) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `small_area` varchar(255) NOT NULL,
  `province` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `dist` varchar(20) NOT NULL,
  `community` varchar(255) NOT NULL,
  `lat` varchar(20) NOT NULL,
  `lng` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL,
  `square` int(11) unsigned NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `vr_url` varchar(255) NOT NULL,
  `floor` tinyint(4) unsigned NOT NULL,
  `count_floor` tinyint(4) unsigned NOT NULL,
  `room` tinyint(2) unsigned NOT NULL,
  `office` tinyint(2) unsigned NOT NULL,
  `guard` tinyint(2) unsigned NOT NULL,
  `deposit` tinyint(2) unsigned NOT NULL,
  `house_type` tinyint(2) unsigned NOT NULL,
  `decoration_type` tinyint(2) unsigned NOT NULL,
  `years` tinyint(3) unsigned NOT NULL,
  `orientation` tinyint(2) unsigned NOT NULL,
  `property_right` tinyint(3) unsigned NOT NULL,
  `management_type` tinyint(2) unsigned NOT NULL,
  `shops_type` tinyint(2) unsigned NOT NULL,
  `configure` varchar(128) NOT NULL,
  `tag` varchar(128) NOT NULL,
  `content` text NOT NULL,
  `param` mediumtext NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `hot` tinyint(1) unsigned NOT NULL,
  `payment_state` tinyint(1) unsigned NOT NULL,
  `deal` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `edit_dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`agent_id`,`publish_type`,`uid`,`class`,`vice_class`,`display`,`payment_state`,`hot`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_info_collection` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `iid` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`iid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_info_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `iid` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`iid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_info_pay_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `iid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`iid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_info_report` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `iid` int(11) unsigned NOT NULL,
  `content` varchar(2000) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `handle_dateline` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`iid`,`state`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_pay_log` (
  `order_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `pubid` varchar(255) NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `pay_time` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `payment_type` varchar(30) NOT NULL,
  `content` varchar(255) NOT NULL,
  `param` mediumtext NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `idx` (`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_house_wallet_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `agent_id` int(11) unsigned NOT NULL,
  `content` varchar(255) NOT NULL,
  `money` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`agent_id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$InfoTableField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_house_info'));
$InfoToArray = MysqlToArray($InfoTableField);

$AgentGroupTableField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_house_agent_group'));
$AgentGroupToArray = MysqlToArray($AgentGroupTableField);

$AgentUserTableField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_house_agent_user'));
$AgentUserToArray = MysqlToArray($AgentUserTableField);

$InfoRefreshLogField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_house_agent_user_refresh_info_log'));
$InfoRefreshLogToArray = MysqlToArray($InfoRefreshLogField);

$ArticleField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_house_article'));
$ArticleToArray = MysqlToArray($ArticleField);

$disc_mobile_field = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_house_disc_mobile'));
$disc_mobile_array = MysqlToArray($disc_mobile_field);

if(!in_array('top_discount',$AgentGroupToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_agent_group` ADD `top_discount` VARCHAR( 20 ) NOT NULL AFTER `access_record_mobile` ;
EOF;
	runquery($UpSql);
}

if(!in_array('info_my',$AgentGroupToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_agent_group` ADD `info_my` TINYINT( 1 ) UNSIGNED NOT NULL AFTER `ico` ;
EOF;
	runquery($UpSql);
}

if(!in_array('type',$InfoRefreshLogToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_agent_user_refresh_info_log` ADD `type` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '1' AFTER `iid` ;
EOF;
	runquery($UpSql);
}

if(!in_array('describe',$ArticleToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_article` ADD `describe` VARCHAR( 255 ) NOT NULL AFTER `thumbnail` ;
EOF;
	runquery($UpSql);
}

if(!in_array('money',$AgentUserToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_agent_user` ADD `money` INT( 11 ) UNSIGNED NOT NULL AFTER `work_state` ;
EOF;
	runquery($UpSql);
}

if(!in_array('currency',$AgentGroupToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_agent_group` ADD `currency` INT( 11 ) UNSIGNED NOT NULL AFTER `top_discount` ;
EOF;
	runquery($UpSql);
}

if(!in_array('vr',$AgentGroupToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_agent_group` ADD `vr` TINYINT( 1 ) UNSIGNED NOT NULL AFTER `currency` ;
EOF;
	runquery($UpSql);
}

if(!in_array('vr_url',$InfoToArray) && !in_array('video_url',$InfoToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_info` ADD `video_url` VARCHAR( 255 ) NOT NULL AFTER `square` ,
ADD `vr_url` VARCHAR( 255 ) NOT NULL AFTER `video_url` ;
EOF;
	runquery($UpSql);
}

if(!in_array('qr',$AgentUserToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_agent_user` ADD `qr` VARCHAR( 255 ) NOT NULL AFTER `wx` ;
EOF;
	runquery($UpSql);
}

if(!in_array('mobile',$InfoToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_info` ADD `mobile` VARCHAR( 20 ) NOT NULL AFTER `name` ;
EOF;
	runquery($UpSql);
}

if(!in_array('content',$InfoToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_info` ADD `content` TEXT NOT NULL AFTER `tag` ;
EOF;
	runquery($UpSql);
}

if(!in_array('port',$disc_mobile_array)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_disc_mobile` ADD `port` TINYINT( 1 ) UNSIGNED NOT NULL AFTER `mobile` ;
EOF;
	runquery($UpSql);
}

if(!in_array('display',$AgentGroupToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_house_agent_group` ADD `display` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '1' AFTER `displayorder` ;
EOF;
	runquery($UpSql);
}

$UpSql = <<<EOF
	 ALTER TABLE `pre_fn_house_info` CHANGE `price` `price` VARCHAR( 20 ) NOT NULL ;
EOF;
runquery($UpSql);

function MysqlToArray($Array) {
    $temp = array();
    foreach ($Array as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}

$finish = TRUE;
?>