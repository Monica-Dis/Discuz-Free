<?php


if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$list  = DB::fetch_all("SELECT * FROM %t where state = 1 ORDER BY order_id ASC " .DB::limit(0,10000), array('fn_house_pay_log'));

$paysql = "insert INTO ".DB::table('fn_pay_log')." (uid,username,pubid,money,state,pay_time,dateline,payment_type,content,param,source) values";

foreach ($list as $row) {
	$paysql .= "('".$row['uid']."','".$row['username']."','".$row['pubid']."','".$row['money']."','".$row['state']."','".$row['pay_time']."','".$row['dateline']."','".$row['payment_type']."','".$row['content']."','".$row['param']."','fn_house'),";
}
$paysql = substr($paysql,0,strlen($paysql)-1);
if(DB::query($paysql)){
	echo 'ok';
	@unlink(DISCUZ_ROOT.'source/plugin/fn_house/move.inc.php');
	exit();
}
//From: Dism��taobao��com
?>