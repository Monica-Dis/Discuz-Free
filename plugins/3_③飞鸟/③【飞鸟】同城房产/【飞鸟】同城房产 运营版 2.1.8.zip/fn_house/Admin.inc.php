<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_admin/fn_admin.inc.php')){
	list($id,$name) = explode('_',$plugin['identifier']);
	$AdminUrl = $_G['siteurl'].'plugin.php?id=fn_admin&mod='.$name;
	showtableheader(); /*dism _taobao _com*/
	showsetting('&#31649;&#29702;&#20837;&#21475;', 'AdminUrl',$AdminUrl, 'text','','','<a href="'.$AdminUrl.'" target="_blank" style="color:red;">&#28857;&#20987;&#25171;&#24320;</a>');
	showtablefooter(); /*dism-taobao-com*/
}else{
	showtableheader('', 'nobottom');
	showtitle(lang('plugin/fn_assembly','MsgBox_title'));
	showtablerow('', array('class="vtop tips2" colspan="3"'), array(lang('plugin/fn_assembly','NoAdmin')));
	showtablefooter(); /*dism-taobao-com*/
}