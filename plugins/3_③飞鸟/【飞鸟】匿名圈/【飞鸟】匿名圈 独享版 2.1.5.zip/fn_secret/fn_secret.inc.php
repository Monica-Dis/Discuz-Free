<?php
/**
 *	[����������Ȧ(fn_secret.{modulename})] (C)2016-2099 Powered by ��������.
 *	Version: 1.0
 *	Date: 2018-2-28 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_secret/Function.inc.php');

/* ���Զ�ά����� */
$navtitle = $Fn_Secret->Config['PluginVar']['Title'];
$metakeywords = $Fn_Secret->Config['PluginVar']['Keywords'];
$metadescription = $Fn_Secret->Config['PluginVar']['Description'];

if(!checkmobile() && $Fn_Secret->Config['PluginVar']['PcQrSwitch'] && !in_array($_GET['m'],array('down_qr'))){
	if($Fn_Secret->Config['PluginVar']['QrParameterSwitch']){
		$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.intval($Item['id']).'.jpg';
		if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
			@unlink($File);
			@require_once libfile('class/wechat','plugin/fn_assembly');
			$WechatClient = new Fn_WeChatClient($Fn_Secret->Config['PluginVar']['WxAppid'], $Fn_Secret->Config['PluginVar']['WxSecret']);
			$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____index____0','expire'=>2592000)));
			DownloadImg($QrUrl,$File);
		}
		$QrCode = base64_encode(file_get_contents($File));
	}else{
		$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
		if(!file_exists($File) || !filesize($File)) {
			@require_once libfile('class/qrcode','plugin/fn_assembly');
			QRcode::png($_G['siteurl'].'plugin.php?id=fn_secret', $File, QR_ECLEVEL_L,5,2);
		}
		$QrCode = base64_encode(file_get_contents($File));
		@unlink($File);
	}
	include template('fn_secret:index_qrcode');
	exit();
}
/* ���Զ�ά����� End */

$_GET['m'] = $_GET['m'] ? $_GET['m'] : 'index';
$AllWord = $Fn_Secret->GetAllWord(1);//�����б�

if($Fn_Secret->Config['PluginVar']['AddAppSwitch'] && !App){
	$AddAppSwitch = true;
}else{
	if(in_array($_GET['m'],array('user','add')) && $Fn_Secret->Config['PluginVar']['AddLoginSwitch'] && !$_G['uid']){
		Fn_Login();
	}	
}

$AdminOp = in_array($_G['uid'],array_filter(explode(",",$Fn_Secret->Config['PluginVar']['AdminUids']))) ? 1 : 0;

if($_GET['m'] == 'add'){//���ӻ���
	$navtitle = $metakeywords = $metadescription = $Fn_Secret->Config['LangVar']['AddSecretTitle'];
	foreach(array_filter(explode("\r\n",$Fn_Secret->Config['PluginVar']['FastAddContent'])) as $Key => $Val) {
		$Array = array_filter(explode("=",$Val));
		$FastAddContent[$Key]['content'] = $Array[0];
		$FastAddContent[$Key]['word_id'] = $Array[1];
	}

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
		$Fn_Secret->Config['LangVar']['AddHBImgsPlaceholder'] = str_replace(array("{Num}"),array($Fn_Secret->Config['PluginVar']['AddUploadNum']),$Fn_Secret->Config['LangVar']['AddHBImgsPlaceholder']);
		$AddUploadGroups = array_filter(unserialize($Fn_Secret->Config['PluginVar']['AddUploadGroups']));
	}

}else if($_GET['m'] == 'viewthread'){//С��������
	$Item = $Fn_Secret->GetViewthread($_GET['sid']);
	if($Item){
		$navtitle = $metakeywords = $metadescription = strip_tags($Item['content']);
		$Item['param'] = unserialize($Item['param']);

		//���λ
		$ViewContentAd = array_filter(explode("\r\n",$Fn_Secret->Config['PluginVar']['ViewContentAd']));

		if($_G['uid']){
			//�ҵĵ���
			$MySupporIdArray = $Fn_Secret->GetFirstMySupportArray($_G[uid]);
			if(in_array($Item['id'],$MySupporIdArray)){
				$SupporCssColor = 'style="color:'.$Fn_Secret->Config['PluginVar']['Color'].'"';
			}
		}
		//�����б�
		$CommentList = $Fn_Secret->GetAjaxPostList($Item['id'],$_GET['pid']);
		//ָ��Pid�����б�
		$PidCommentList = $_GET['pid'] ? $Fn_Secret->GetPidPostList($Item['id'],$_GET['pid']) : '';

		//������ۼ�
		$ClickRand = array_filter(explode("-",$Fn_Secret->Config['PluginVar']['ClickRand']));
		$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
		Click($Fn_Secret->TableSecret,$Item['id'],$ClickNum);

		//ͼƬ��
		$Item['param']['imgs'] = array_filter(explode(',',$Item['param']['imgs']));
		$PreviewImage = $Item['param']['imgs'] ? json_encode($Item['param']['imgs']) : '';
		//����
		$Fn_Secret->Config['WxShare']['WxTitle'] = $Fn_Secret->Config['WxShare']['WxDes'] = $navtitle;
		$Fn_Secret->Config['WxShare']['WxUrl'] = $Fn_Secret->Config['ViewthreadUrl'].$Item['id'];
		$Fn_Secret->Config['WxShare']['WxImg'] = $Item['param']['face'] ? $Item['param']['face'] : $Fn_Secret->Config['WxShare']['WxImg'];
		$Fn_Secret->Config['WxShare']['WxImg'] = strpos($Fn_Secret->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Secret->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Secret->Config['WxShare']['WxImg'];
		$Fn_Secret->Config['WxShare']['WxImg'] = str_replace(array("\r","\n"),array('',''),$Fn_Secret->Config['WxShare']['WxImg']);
	
		//��Ƭ
		$ImgBgBase64 = base64_encode(file_get_contents('source/plugin/fn_secret/static/images/card_bg.jpg'));
		$ItemImgBase64 = base64_encode(file_get_contents('source/plugin/fn_secret/static/images/item/'.rand(1,11).'.png'));

		//��ά��
		if($Fn_Secret->Config['PluginVar']['QrParameterSwitch'] && checkmobile()){
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.intval($Item['id']).'.jpg';
			if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
				@unlink($File);
				@require_once libfile('class/wechat','plugin/fn_assembly');
				$WechatClient = new Fn_WeChatClient($Fn_Secret->Config['PluginVar']['WxAppid'], $Fn_Secret->Config['PluginVar']['WxSecret']);
				$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.$Item['id'],'expire'=>2592000)));
				DownloadImg($QrUrl,$File);
			}
			$QrCode = base64_encode(file_get_contents($File));
		}else{
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
			if(!file_exists($File) || !filesize($File)) {
				@require_once libfile('class/qrcode','plugin/fn_assembly');
				QRcode::png($Fn_Secret->Config['ViewthreadUrl'].$Item['id'], $File, QR_ECLEVEL_L,5,2);
			}
			$QrCode = base64_encode(file_get_contents($File));
			@unlink($File);
		}
		//��ƬEnd
	}else{
		exit('No Data');
	}
}else if($_GET['m'] == 'allword'){//ȫ������
	$navtitle = $metakeywords = $metadescription = $Fn_Secret->Config['LangVar']['AllWord'];
}else if($_GET['m'] == 'user'){//��Ա����
	$navtitle = $metakeywords = $metadescription = $Fn_Secret->Config['LangVar']['UserTitle'];
}else if($_GET['m'] == 'index'){
	if($_GET['wid']){
		$Word = $AllWord[$_GET['wid']];
		$navtitle = $metakeywords = $metadescription = '#'.$Word['title'].'#';
	}else{
		$HotWord = $Fn_Secret->GetHotWord();//�Ƽ�����
	}
	$Navs = array_filter(explode(",",$Fn_Secret->Config['PluginVar']['Navs']));
	if(!$Navs){$Navs[] = 10;}

	if(MagApp && $Fn_Secret->Config['PluginVar']['FastAddSwitch'] && $Fn_Secret->Config['PluginVar']['FastAddContent']){
		$ImgBgBase64 = base64_encode(file_get_contents('source/plugin/fn_secret/static/images/card_bg.jpg'));
		$ItemImgBase64 = base64_encode(file_get_contents('source/plugin/fn_secret/static/images/item/'.rand(1,11).'.png'));
	}

	//���λ
	$HomeTopAd = array_filter(explode("\r\n",$Fn_Secret->Config['PluginVar']['HomeTopAd']));

}else if($_GET['m'] == 'down_qr'){
	if($Fn_Secret->Config['PluginVar']['QrParameterSwitch']){
		$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.intval($Item['id']).'.jpg';
		if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
			@unlink($File);
			@require_once libfile('class/wechat','plugin/fn_assembly');
			$WechatClient = new Fn_WeChatClient($Fn_Secret->Config['PluginVar']['WxAppid'], $Fn_Secret->Config['PluginVar']['WxSecret']);
			$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.$_GET['bid'],'expire'=>2592000)));
			DownloadImg($QrUrl,$File);
		}
		$QrCode = base64_encode(file_get_contents($File));

	}else{
		$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
		if(!file_exists($File) || !filesize($File)) {
			@require_once libfile('class/qrcode','plugin/fn_assembly');
			QRcode::png(urldecode($_GET['url']), $File, QR_ECLEVEL_L,8,2);
		}
		$QrCode = base64_encode(file_get_contents($File));
		@unlink($File);
	}
	$Fn_Secret->Config['PluginVar']['PcQrText'] = $Fn_Secret->Config['LangVar']['BusinessDownQrText'];
	include template('fn_secret:index_qrcode');
	exit();
}else{
	exit('No Data');
}
include template('fn_secret:'.$_GET['m']);
?>