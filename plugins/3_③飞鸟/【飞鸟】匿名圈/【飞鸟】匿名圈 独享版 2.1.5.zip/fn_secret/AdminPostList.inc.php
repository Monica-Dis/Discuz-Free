<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_secret/Function.inc.php');

$Operation = in_array($_GET['Operation'], array('Del','Edit','Display')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&keyword='.$_GET['keyword'].'&page='.$_GET['page'].'&sid='.$_GET['sid'].'&display='.$_GET['display'];
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ���� */
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		$DisplaySelected = array($_GET['display']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Secret->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}"></td>
						<th>{$Fn_Secret->Config['LangVar']['ContentID']}</th><td><input type="text" class="txt" name="sid" value="{$_GET['sid']}"></td>
						<th>{$Fn_Secret->Config['LangVar']['DisplayTitle']}</th><td>
						<select name="display">
							<option value="">{$Fn_Secret->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$DisplaySelected['1']}>{$Fn_Secret->Config['LangVar']['Yes']}</option>
							<option value="0"{$DisplaySelected['0']}>{$Fn_Secret->Config['LangVar']['No']}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Secret->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'P.pid';
		if(in_array($_GET['display'],array('0','1'))){
			$Where .= ' and P.display = '.intval($_GET['display']);
		}
		if($_GET['sid']){
			$Where .= ' and P.sid = '.intval($_GET['sid']);
		}
		if($_GET['keyword']){
			$Where .= ' and concat(P.content,P.uid,P.username) like(\'%'.addslashes(dhtmlspecialchars(str_replace(array('%','_'),array('',''),$_GET['keyword']))).'%\')';
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		
		$TdStyle = $Fn_Secret->Config['PluginVar']['AdminUserSwitch'] ? array('width="80"', 'width="200"', 'width="250"','width="60"','width="60"','width="130"',) : array('width="80"', 'width="200"','width="100"', 'width="250"','width="60"','width="60"','width="130"',);

		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'Module', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_Secret->Config['LangVar']['InfoListTitle']);
		if($Fn_Secret->Config['PluginVar']['AdminUserSwitch']){
			showsubtitle(array(
            'ID',
			$Fn_Secret->Config['LangVar']['ContentTitle'],
			$Fn_Secret->Config['LangVar']['PostContentTitle'],
			$Fn_Secret->Config['LangVar']['ReplyCountTitle'],
			$Fn_Secret->Config['LangVar']['DisplayTitle'],
			$Fn_Secret->Config['LangVar']['TimeTitle'],
			$Fn_Secret->Config['LangVar']['OperationTitle']
		), 'header tbm',$TdStyle);
		}else{
			showsubtitle(array(
            'ID',
			$Fn_Secret->Config['LangVar']['ContentTitle'],
			'Uid/'.$Fn_Secret->Config['LangVar']['UserNameTitle'],
			$Fn_Secret->Config['LangVar']['PostContentTitle'],
			$Fn_Secret->Config['LangVar']['ReplyCountTitle'],
			$Fn_Secret->Config['LangVar']['DisplayTitle'],
			$Fn_Secret->Config['LangVar']['TimeTitle'],
			$Fn_Secret->Config['LangVar']['OperationTitle']
		), 'header tbm',$TdStyle);
		}
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($ModulesList as $Module) {
			if($Fn_Secret->Config['PluginVar']['AdminUserSwitch']){
				showtablerow('', array('class="td25"', 'class="td28"'), array(
					'<input type="checkbox" class="checkbox" name="ids[]" value="'.$Module['pid'].'" />'.$Module['pid'],
					'<a href="'.$Fn_Secret->Config['ViewthreadUrl'].$Module['sid'].'&pid='.$Module['pid'].'" target="_blank">'.cutstr($Module['Scontent'],25).'</a>',
					$Module['content'],
					$Module['reply_count'],
					!$Module['display'] ? '<span style="color:red">'.$Fn_Secret->Config['LangVar']['No'].'</span>' : $Fn_Secret->Config['LangVar']['Yes'],
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$OpCpUrl.'&Operation=Edit&pid='.$Module['pid'].'">'.$Fn_Secret->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Display&pid='.$Module['pid'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_Secret->Config['LangVar']['DisplayNoTitle'] : $Fn_Secret->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&pid='.$Module['pid'].'&formhash='.FORMHASH.'">'.$Fn_Secret->Config['LangVar']['DelTitle'].'</a>'
				));
			}else{
				showtablerow('', array('class="td25"', 'class="td28"'), array(
					'<input type="checkbox" class="checkbox" name="ids[]" value="'.$Module['pid'].'" />'.$Module['pid'],
					'<a href="'.$Fn_Secret->Config['ViewthreadUrl'].$Module['sid'].'&pid='.$Module['pid'].'" target="_blank">'.cutstr($Module['Scontent'],25).'</a>',
					$Module['uid'].'/'.$Module['username'],
					$Module['content'],
					$Module['reply_count'],
					!$Module['display'] ? '<span style="color:red">'.$Fn_Secret->Config['LangVar']['No'].'</span>' : $Fn_Secret->Config['LangVar']['Yes'],
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$OpCpUrl.'&Operation=Edit&pid='.$Module['pid'].'">'.$Fn_Secret->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Display&pid='.$Module['pid'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_Secret->Config['LangVar']['DisplayNoTitle'] : $Fn_Secret->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&pid='.$Module['pid'].'&formhash='.FORMHASH.'">'.$Fn_Secret->Config['LangVar']['DelTitle'].'</a>'
				));
			}
			
		}
		showsubmit('Submit','submit','<input name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" type="checkbox"><label for="chkall">'.$Fn_Secret->Config['LangVar']['ChkAll'].'</label>&nbsp;&nbsp;<input name="optype" id="OptypeDel" value="Del" class="radio" type="radio"><label for="OptypeDel">'.$Fn_Secret->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<input name="optype" id="OptypeDisplay" value="Display" class="radio" type="radio"><label for="OptypeDisplay">'.$Fn_Secret->Config['LangVar']['DisplayTitle'].'</label>&nbsp;<select name="new_display"><option value="1">'.$Fn_Secret->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_Secret->Config['LangVar']['No'].'</option></select>','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism _ taobao _ com*/
		showformfooter(); /*dism��taobao��com*/
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['ids']) && is_array($_GET['ids'])){
			if($_GET['optype'] == 'Del'){//ȫɾ
				//ɾ��ѡ����Ƶ
				foreach($_GET['ids'] as $Key => $Val) {
					$Val = intval($Val);
					$Item = $Val ? DB::fetch_first('SELECT * FROM '.DB::table($Fn_Secret->TableSecretPost).' where pid = '.$Val) : array();
					if($Item){
						DB::query("UPDATE ".DB::table($Fn_Secret->TableSecret)." SET comment_count = comment_count-1 WHERE id=".$Item['sid']);
						if($Item['rid']){
							$RItem =  DB::fetch_first('SELECT * FROM '.DB::table($Fn_Secret->TableSecretPost).' where pid = '.$Item['rid']);
							if($RItem['reply_count']){
								DB::query("UPDATE ".DB::table($Fn_Secret->TableSecretPost)." SET reply_count = reply_count - 1 WHERE pid=".intval($Item['rid']));
							}
						}
						DB::delete($Fn_Secret->TableSecretPost,'pid ='.$Val);
					}
				}
				cpmsg($Fn_Secret->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'Display'){//��ʾ
				$UpData['display'] = intval($_GET['new_display']);
				DB::update($Fn_Secret->TableSecretPost,$UpData,'pid in( '.implode(',',$_GET['ids']).' )');
				cpmsg($Fn_Secret->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}
		}else{
			cpmsg($Fn_Secret->Config['LangVar']['UpdateErr'],'','error');
		}

	}
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['pid']){//ɾ��
	$PId = intval($_GET['pid']);
	$Item = $PId ? DB::fetch_first('SELECT * FROM '.DB::table($Fn_Secret->TableSecretPost).' where pid = '.$PId) : array();
	if($Item){
		DB::query("UPDATE ".DB::table($Fn_Secret->TableSecret)." SET comment_count = comment_count-1 WHERE id=".$Item['sid']);
		if($Item['rid']){
			$RItem =  DB::fetch_first('SELECT * FROM '.DB::table($Fn_Secret->TableSecretPost).' where pid = '.$Item['rid']);
			if($RItem['reply_count']){
				DB::query("UPDATE ".DB::table($Fn_Secret->TableSecretPost)." SET reply_count = reply_count - 1 WHERE pid=".intval($Item['rid']));
			}
		}
		DB::delete($Fn_Secret->TableSecretPost,'pid ='.$PId);
		cpmsg($Fn_Secret->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
	}else{
		cpmsg($Fn_Secret->Config['LangVar']['DelErr'],'','error');
	}
	
}else if($Operation == 'Display' && $_GET['formhash'] == formhash() && $_GET['pid']){//�Ƿ���ʾ
	$PId = intval($_GET['pid']);
	$UpData['display'] = intval($_GET['value']);
	DB::update($Fn_Secret->TableSecretPost,$UpData,'pid ='.$PId);
	cpmsg($Fn_Secret->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'Edit'){//�༭����
	$PId = intval($_GET['pid']);
	$Item = $PId ? DB::fetch_first('SELECT * FROM '.DB::table($Fn_Secret->TableSecretPost).' where pid = '.$PId) : array();
	if($Item['param']){$Item['param'] = unserialize($Item['param']);}
	$Title = $Fn_Secret->Config['LangVar']['EditTitle'];
	if(!submitcheck('DetailSubmit')) {
		$formUrl = ltrim(rawurldecode(cpurl()),'action=');
		showformheader($formUrl,'enctype');
		showtableheader();
		showtitle($Title);
		showsetting($Fn_Secret->Config['LangVar']['PostContentTitle'], 'content', $Item['content'], 'textarea');
		showsetting($Fn_Secret->Config['LangVar']['NameTitle'], 'name', $Item['param']['name'], 'text');
		
		$FaceArray =  array_filter(explode("\n",$Fn_Secret->Config['PluginVar']['Faca']));
		$FaceHtml = '<div class="ImgList FaceImgList">';
		foreach($FaceArray as $Key => $Val) {
			$Class = strpos($Val,$Item['param']['face']) !== false ? ' class="Hover"' : '';
			$FaceHtml .= '<img src="'.$Val.'"'.$Class.'>';
		}
		$FaceHtml .= '</div>';
		showsetting($Fn_Secret->Config['LangVar']['FaceTitle'], 'face', $Item['param']['face'], 'text','','',$FaceHtml);
		showsetting($Fn_Secret->Config['LangVar']['DisplayTitle'], 'display', $Item['display'], 'radio');
		if($Item['dateline']){
		showsetting($Fn_Secret->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
		}
		showtablefooter(); /*dism _ taobao _ com*/
		showsubmit('DetailSubmit');
		showformfooter(); /*dism��taobao��com*/
		echo '
		<style>.ImgList img{margin:0 0 2px 2px;border:2px solid #fff;cursor:pointer;width:60px;height:60px;}.ImgList img.Hover{border-color:'.$Fn_Secret->Config['PluginVar']['Color'].';}</style><script type="text/javascript" src="static/js/calendar.js"></script>
		<script src="'.$Fn_Secret->Config['StaticPath'].'/js/jquery-1.9.1.min.js?{VERHASH}"></script>
		<script>
		var FN = jQuery.noConflict(); 
		FN(document).on("click",".ImgList img",function(e){
			var ParentsClass = FN(this).parents(".ImgList").attr("class");
			if(ParentsClass.indexOf("FaceImgList") >=0){
				FN("input[name=face]").val(FN(this).attr("src"));
			}
			FN(this).addClass("Hover").siblings().removeClass("Hover");
		});
		</script>
	';
	}else{
		$Data['content'] = addslashes(strip_tags($_GET['content']));
		$Data['display'] = intval($_GET['display']);
		$Param['name'] = addslashes(strip_tags($_GET['name']));
		$Param['face'] = addslashes(strip_tags($_GET['face']));
		$Data['param'] = serialize($Param);
		if($Item){
			$Data['dateline'] = strtotime($_GET['dateline']);
			DB::update($Fn_Secret->TableSecretPost,$Data,'pid = '.$PId);
		}
		cpmsg($Fn_Secret->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	}
	
}
/* ��Ƶ�б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Secret;
	$FetchSql = 'SELECT S.content as Scontent,P.* FROM '.DB::table($Fn_Secret->TableSecretPost).' P LEFT JOIN '.DB::table($Fn_Secret->TableSecret).' S on S.id = P.sid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ��Ƶ���� */
function GetModulesCount($Where=null){
	global $Fn_Secret;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Secret->TableSecretPost).' P '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>