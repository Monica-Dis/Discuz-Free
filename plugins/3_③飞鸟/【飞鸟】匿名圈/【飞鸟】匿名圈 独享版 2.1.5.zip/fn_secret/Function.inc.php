<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


@require_once libfile('function/core','plugin/fn_assembly');
@require_once libfile('class/magapp','plugin/fn_assembly');
@require_once libfile('class/qfapp','plugin/fn_assembly');
@require_once libfile('class/json','plugin/fn_assembly');

class Fn_Secret{
	public function __construct() {
		global $_G,$plugin,$Config;
		loadcache('plugin');
		$this->Config['PluginVar'] = (array) $_G['cache']['plugin']['fn_secret'];
		$this->Config['PluginVar']['AddUploadNum']= $this->Config['PluginVar']['AddUploadNum'] ? $this->Config['PluginVar']['AddUploadNum'] : 9;
		//参数二维码开关
		if(!$this->Config['PluginVar']['QrParameterSwitch'] && QrParameterSwitch){
			$this->Config['PluginVar']['WxAppid'] = $Config['PluginVar']['WxAppid'];
			$this->Config['PluginVar']['WxSecret'] = $Config['PluginVar']['WxSecret'];
		}
		$this->Config['PluginVar']['QrParameterSwitch'] = $this->Config['PluginVar']['QrParameterSwitch'] ? $this->Config['PluginVar']['QrParameterSwitch'] : (QrParameterSwitch ? QrParameterSwitch : 0);
		//参数二维码开关 End
		$this->Config['LangVar'] = lang('plugin/fn_secret');
		$this->Config['Path'] = 'source/plugin/fn_secret';
		$this->Config['StaticPath'] = $this->Config['Path'].'/static';
		$this->Config['StaticPicPath'] = $this->Config['Path'].'/attachment/';
		$this->Config['Url'] = $_G['siteurl'].'plugin.php?id=fn_secret';
		$this->Config['ViewthreadUrl'] =  $this->Config['Url'].'&m=viewthread&sid=';
		$this->Config['AllWordUrl'] =  $this->Config['Url'].'&m=allword';
		$this->Config['AddUrl'] =  $this->Config['Url'].'&m=add';
		$this->Config['UserUrl'] =  $this->Config['Url'].'&m=user';
		$this->Config['DownQrUrl'] = $this->Config['Url'].'&m=down_qr&url=';
		$this->Config['AjaxUrl'] =  'plugin.php?id=fn_secret:Ajax';
		$this->Config['WxShare'] = array(
			'WxTitle' => $this->Config['PluginVar']['WxTitle'],
			'WxDes' => $this->Config['PluginVar']['WxDes'],
			'WxImg' => strpos($this->Config['PluginVar']['WxImg'],'http') !== false ? $this->Config['PluginVar']['WxImg'] : $_G['siteurl'].$this->Config['PluginVar']['WxImg'],
			'WxUrl' => $this->Config['Url']
		);
		
		if(!is_dir(DISCUZ_ROOT.$this->Config['StaticPicPath'])){
			mkdir(DISCUZ_ROOT.$this->Config['StaticPicPath']);
		}
		$this->TableSecret = 'fn_secret';
		$this->TableSecretWord = 'fn_secret_word';
		$this->TableSecretSupport = 'fn_secret_support';
		$this->TableSecretPost = 'fn_secret_post';
		$this->TableSecretPostTableId = 'fn_secret_post_tableid';
		$this->TableSecretBusiness = 'fn_secret_business';

		$this->MagApp = new MagApp($this->Config['PluginVar']['MagSecret'],$this->Config['PluginVar']['MagAssistantSecret'],$this->Config['PluginVar']['MagAssistantPush']);
		$this->QHApp = new QHApp($this->Config['PluginVar']['qf_type'],$this->Config['PluginVar']['qf_sr_type'],$this->Config['PluginVar']['qf_from_id']);

	}
	//用户小秘密和评论列表
	public function GetAjaxUserList($Get){
		global $_G;
		$Get = StrToGBK($Get);
		$Uid = intval($_G['uid']);
		$Page = $Get['page'] ? intval($Get['page']):0;
		$this->Config['PluginVar']['UserNum'] = $this->Config['PluginVar']['UserNum'] ? $this->Config['PluginVar']['UserNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['UserNum']).','.$this->Config['PluginVar']['UserNum'];
		$Results = array();
		if($Get['type'] == 'UserList'){
			$FetchSql = 'SELECT W.title as Ttitle,B.title as b_title,B.display as b_display,B.link as b_link,S.* FROM '.DB::table($this->TableSecret).' S LEFT JOIN '.DB::table($this->TableSecretWord).' W on W.id = S.wid LEFT JOIN '.DB::table($this->TableSecretBusiness).' B on B.id = S.bid where S.uid = '.$Uid.' order by S.updateline desc,S.dateline desc '.$Limit;
			$Results = $this->ListFormat(DB::fetch_all($FetchSql));
		}else if($Get['type'] == 'UserPost'){
			$FetchSql = 'SELECT * FROM '.DB::table($this->TableSecretPost).' where uid = '.$Uid.' and display = 1 order by dateline desc '.$Limit;
			$Results = $this->POstListFormat(DB::fetch_all($FetchSql));
		}
		return $Results;
	}
	/* 小秘密详情 */
	public function GetViewthread($Id){
		$Id = intval($Id);
		$FirstSql = 'SELECT W.title as Ttitle,B.title as b_title,B.display as b_display,B.link as b_link,S.* FROM '.DB::table($this->TableSecret).' S LEFT JOIN '.DB::table($this->TableSecretWord).' W on W.id = S.wid LEFT JOIN '.DB::table($this->TableSecretBusiness).' B on B.id = S.bid where S.id = '.$Id;
		return DB::fetch_first($FirstSql);
	}
	/* 小秘密列表 */
	public function GetAjaxList($Get){
		$Results = array();
		$Get = StrToGBK($Get);
		$Page = $Get['page'] ? intval($Get['page']):0;
		
		$Where = '';
		$Order = 'S.updateline';
		if($Get['type'] == 'New'){
			$Order = 'S.dateline';
		}else if($Get['type'] == 'Hot'){
			$Order = 'S.updateline';
			if($this->Config['PluginVar']['ListHotVal']){
				$Where .= ' and (S.support_count >= '.$this->Config['PluginVar']['ListHotVal'].' OR S.comment_count >= '.$this->Config['PluginVar']['ListHotVal'].')';
			}
			if($this->Config['PluginVar']['ListHotDataline']){
				$Where .= ' and S.dateline >= '.strtotime("-".$this->Config['PluginVar']['ListHotDataline']." hours",time());	
			}
		}else if($Get['type'] == 'Nearby'){//附近小秘密
			$Order = 'S.updateline';
			if($Get['lng'] && $Get['lat']){
				$SquarePoint = $this->GetReturnSquarePoint($Get['lng'],$Get['lat'],$this->Config['PluginVar']['Distance']);
				$Where .= ' and S.lat <> 0 and S.lat > '.$SquarePoint['right-bottom']['lat'].' and S.lat < '.$SquarePoint['left-top']['lat'].' and S.lng > '.$SquarePoint['left-top']['lng'].' and S.lng < '.$SquarePoint['right-bottom']['lng'];
			}else{
				return $Results;
			}
		}

		if($_GET['wid']){
			$Where .= ' and S.wid = '.intval($_GET['wid']);
		}
		$Where .= ' and S.display = 1 and S.fast_add_display = 1';
		$Where = preg_replace('/and/','where',$Where,1);
		
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$FetchSql = 'SELECT W.title as Ttitle,B.title as b_title,B.display as b_display,B.link as b_link,S.* FROM '.DB::table($this->TableSecret).' S LEFT JOIN '.DB::table($this->TableSecretWord).' W on W.id = S.wid LEFT JOIN '.DB::table($this->TableSecretBusiness).' B on B.id = S.bid '.$Where .' order by topdateline > '.time().' desc,'.$Order.' desc,S.dateline desc '.$Limit;
		$Results = $this->ListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}

	/* 小秘密列表格式转换 */
	public function ListFormat($Array){
		global $_G;
		$MySupporIdArray = $this->GetFirstMySupportArray($_G['uid']);
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['username'] = $Val['username'];
			$Content = $this->Config['PluginVar']['ListLength'] ? cutstr($Val['content'],$this->Config['PluginVar']['ListLength']) : $Val['content'];
			$Array[$Key]['content'] = dstrlen($Content) > $this->Config['PluginVar']['ListLength'] && $this->Config['PluginVar']['ListLength'] ? $Content.'<span style=color:'.$this->Config['PluginVar']['Color'].'>'.$this->Config['LangVar']['FullText'].'</span>': $Content;
			$Array[$Key]['param']['imgs'] = array_slice(array_filter(explode(',',$Val['param']['imgs'])),0,9);
			$Array[$Key]['param']['imgs_count'] = count($Array[$Key]['param']['imgs']) > 9 ? 9 : count($Array[$Key]['param']['imgs']);
			$Array[$Key]['dateline'] = FormatDate($Val['dateline']);
			$Array[$Key]['Ttitle'] = $Val['Ttitle'] ? '#'.$Val['Ttitle'].'#' : '';
			$Array[$Key]['MySupport'] = in_array($Val['id'],$MySupporIdArray) ? 1 : 0;
			$Array[$Key]['Top'] = $Val['topdateline'] > time() ? 1 : 0;
			if($this->Config['PluginVar']['ListCommentNum']){
				$ListCommentLength = $this->Config['PluginVar']['ListCommentLength'] ? $this->Config['PluginVar']['ListCommentLength'] : 50;
				$Order = $this->Config['PluginVar']['ListCommentOrder'] ? $this->Config['PluginVar']['ListCommentOrder'] : 'dateline';
				$CommentList = $this->POstListFormat(DB::fetch_all('SELECT P.* FROM '.DB::table($this->TableSecretPost).' P where P.sid = '.$Val['id'].' and display = 1 and floor_host != 1 order by P.'.$Order.' desc limit 0,'.$this->Config['PluginVar']['ListCommentNum']),$ListCommentLength);
				$Array[$Key]['CommentList'] = $CommentList;
			}else{
				$Array[$Key]['CommentList'] = '';
			}

		}
		return $Array;
	}

	/* 我的小秘密点赞 */
	public function GetFirstMySupportArray(){
		global $_G;
		$Uid = intval($_G['uid']);
		$MySupportArray = DB::fetch_all('SELECT sid FROM '.DB::table($this->TableSecretSupport).' where uid = '.$Uid.' order by id desc');
		foreach ($MySupportArray as $key => $val) {
			$MySupportIdArray[] = $MySupportArray[$key]['sid'];
		}
		return $MySupportIdArray;
	}
	/* 小秘密点赞 */
	public function GetAjaxMySupport($Id){
		global $_G;
		$Uid = intval($_G['uid']);
		$Id = intval($Id);
		$MySupport= DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecretSupport).' where uid = '.$Uid.' and sid = '.$Id);
		$Item =  $this->GetViewthread($Id);
		if(!$MySupport && $Item){
			$InsData['uid'] = $Uid;
			$InsData['username'] = addslashes(strip_tags($_G['username']));
			$InsData['sid'] = $Id;
			$InsData['wid'] = intval($Item['wid']);
			$InsData['bid'] = intval($Item['bid']);
			$InsData['dateline'] = time();
			if(DB::insert($this->TableSecretSupport,$InsData) && DB::query("UPDATE ".DB::table($this->TableSecret)." SET support_count = support_count+1,updateline = ".time()." WHERE id=$Id")){
				$State = 1;
			}
		}else{
			$State = 0;
		}
		return $State;
	}

	/* 分享 */
	public function GetAjaxShare($Id,$Type){
		global $_G;
		$Id = intval($Id);
		$Item = $this->GetViewthread($Id);
		$AGENT = $_SERVER["HTTP_USER_AGENT"];
		/*if((strpos($AGENT,'Appbyme') !== false || strpos($AGENT,'MAGAPPX') !== false || strpos($AGENT,'QianFan') !== false || strpos($AGENT,'MicroMessenger') !== false) && $Item){*/
		if($Item){
			if(DB::query("UPDATE ".DB::table($this->TableSecret)." SET share_count = share_count+1 WHERE id=$Id")){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['ShareOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['ShareErr']);
			}
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['ShareErr']);
		}
		return $Data;
		
	}
	/* 指定Pid评论列表 */
	public function GetPidPostList($Id,$NoPid=null){
		$Id = intval($Id);
		if($NoPid){
			$Where = ' and pid in('.addslashes(strip_tags($NoPid)).')';
		}
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableSecretPost).' where sid = '.$Id.' and display = 1'.$Where.' order by dateline desc';
		$Results = $this->POstListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}
	/* 评论列表 */
	public function GetAjaxPostList($Id,$NoPid=null,$Page=null){
		global $_G;
		$Page = $Page ? intval($Page):0;
		$Id = intval($Id);
		$Where = '';
		if($NoPid){
			$Where .= ' and pid not in('.addslashes(strip_tags($NoPid)).')';
		}
		
		if(!in_array($_G['uid'],array_filter(explode(",",$this->Config['PluginVar']['AdminUids'])))){
			$Where .= ' and display = 1';
		}

		$this->Config['PluginVar']['PostNum'] = $this->Config['PluginVar']['PostNum'] ? $this->Config['PluginVar']['PostNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['PostNum']).','.$this->Config['PluginVar']['PostNum'];
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableSecretPost).' where sid = '.$Id.$Where.' order by dateline desc '.$Limit;
		$Results = $this->POstListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}
	/* 评论列表格式转换 */
	public function PostListFormat($Array,$ContentLength=0){
		foreach ($Array as $Key => $Val) {
			$Array[$Key]['username'] = $Val['username'];
			$Array[$Key]['param'] = unserialize($Val['param']);
			$Array[$Key]['dateline'] = FormatDate($Val['dateline']);
			$Array[$Key]['content'] = $ContentLength ? cutstr($Val['content'],$ContentLength) : $Val['content'];
			if($Val['rid']){
				$RPost = DB::fetch_first('SELECT content FROM '.DB::table($this->TableSecretPost).' where pid = '.intval($Val['rid']).' and display = 1');
				$Array[$Key]['rcontent'] = $RPost['content'] ? $this->Config['LangVar']['ReplyTitle'].$this->Config['LangVar']['Mao'].$RPost['content'] : '';
			}else{
				$Array[$Key]['rcontent'] = '';
			}
		}
		return $Array;
	}
	/* 评论 */
	public function GetAjaxComment($Id,$Content,$Type='Comment',$Rid=null){
		global $_G,$Config;
		$Uid = intval($_G['uid']);
		$Id = intval($Id);
		$Rid = intval($Rid);
		$Content = censor(addslashes(strip_tags(StrToGBK($Content))));
		$Data = array();
		//用户组判断
		$CommentGroups = array_filter(unserialize($this->Config['PluginVar']['CommentGroups']));
		if($CommentGroups && !in_array($_G['member']['groupid'],$CommentGroups)){//用户组限制
			$Data['Msg'] = $this->Config['LangVar']['CommentGroupsErr'];
			return $Data;
		}
		//违规词
		if($this->Config['PluginVar']['ViolationWordSwitch']){
			$censor = discuz_censor::instance();
			$censor->check($Content);
			if($censor->modbanned()){
				$Data['Msg'] = $this->Config['LangVar']['WordBanned'];
				return $Data;
			}
		}
		
		//字符限制
		if($this->Config['PluginVar']['CommentMinLength'] && dstrlen($Content) < $this->Config['PluginVar']['CommentMinLength']){//内容不能为空
			$Data['Msg'] = $this->Config['LangVar']['CommentMinLengthErr'];
			return $Data;
		}

		//时间限制
		if($Uid){
			$MyComment = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecretPost).' where uid = '.$Uid.' order by pid DESC');
		}else{
			$MyComment = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecretPost).' where useip = \''.addslashes(strip_tags($_G['clientip'])).'\' order by pid DESC');
		}
		if($this->Config['PluginVar']['CommentTime'] && time() < strtotime("+".$this->Config['PluginVar']['CommentTime']." second",$MyComment['dateline'])){
			$TIME = $this->Config['PluginVar']['CommentTime'] - (time() - $MyComment['dateline']);
			$Data['Msg'] = str_replace('{TIME}',$TIME,$this->Config['LangVar']['CommentTimeErr']);
			return $Data;
		}
		$Item = $this->GetViewthread($Id);
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Pid = DB::insert($this->TableSecretPostTableId,array('pid'=>''),true);
			$NameArray =  array_filter(explode("\r\n",$this->Config['PluginVar']['Name']));
			$FaceArray =  array_filter(explode("\r\n",$this->Config['PluginVar']['Faca']));
			$InsData['pid'] = intval($Pid);
			$InsData['wid'] = intval($Item['wid']);
			$InsData['bid'] = intval($Item['bid']);
			$InsData['sid'] = $Id;
			$InsData['rid'] = $Rid;
			$InsData['content'] = $Content;
			$InsData['uid'] = $Uid;
			$InsData['username'] = addslashes(strip_tags($_G['username']));
			$InsData['display'] = $this->Config['PluginVar']['CommentSwitch'] ? 0 : 1;
			$InsData['dateline'] = time();
			$InsData['useip'] = addslashes(strip_tags($_G['clientip']));
			if($this->Config['PluginVar']['MysqlType']){
				$PostPosition = DB::fetch_first('SELECT position FROM '.DB::table($this->TableSecretPost).' where sid = '.$Id.' order by pid desc');
				$InsData['position'] = $PostPosition['position'] + 1;
			}
			if($Uid && $Uid == $Item['uid']){
				$InsData['floor_host'] = 1;
				$Param['face'] = addslashes(strip_tags($Item['param']['face']));
				$Param['name'] = addslashes(strip_tags($Item['param']['name']));
			}else{
				$MyPost = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecretPost).' where sid = '.$Id.' and uid = '.$Uid);
				if($MyPost){
					$MyPost['param'] = unserialize($MyPost['param']);
					$Param['face'] = addslashes(strip_tags($MyPost['param']['face']));
					$Param['name'] = addslashes(strip_tags($MyPost['param']['name']));
				}else{
					$Param['face'] = addslashes(strip_tags($FaceArray[rand(0,count($FaceArray)-1)]));
					$Param['name'] = addslashes(strip_tags($NameArray[rand(0,count($NameArray)-1)]));
				}
			}

			$InsData['param'] = serialize($Param);
			if(DB::insert($this->TableSecretPost,$InsData) && DB::query("UPDATE ".DB::table($this->TableSecret)." SET comment_count = comment_count+1,updateline = ".time()." WHERE id=$Id")){
				if($this->Config['PluginVar']['CommentSwitch']){
					$Data['Msg'] = $this->Config['LangVar']['CommentSwitchErr'];
					return $Data;
				}else{
					if($Rid && $RPost = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecretPost).' where pid = '.$Rid.' and display = 1')){
						DB::query("UPDATE ".DB::table($this->TableSecretPost)." SET reply_count = reply_count+1 WHERE pid=".$Rid);
						$Data['rcontent'] = $this->Config['LangVar']['ReplyTitle'].$this->Config['LangVar']['Mao'].$RPost['content'];
					}
					$Data['State'] = 200;
					$Data['dateline'] = FormatDate($InsData['dateline']);
					$Data['name'] = $Param['name'];
					$Data['face'] = $Param['face'];
					$Data['content'] = $InsData['content'];
					//dz系统通知
					$Msg = $this->Config['LangVar']['PushCommentTitle'].$this->Config['LangVar']['Mao'].cutstr(strip_tags($Item['content']),20);
					$Url = $this->Config['ViewthreadUrl'].$Item['id'].'&pid='.$Pid;
					if($RPost['uid'] && $RPost['uid'] != $Uid){//回复通知
						if($this->Config['PluginVar']['ReplyNoticeSwitch'] && $Uid && $Uid != $Item['uid']){//回复是否通知楼主
							notification_add($Item['uid'],'system','<a href="{url}">{msg}</a>',array(
								'url'=>$Url,
								'msg'=>$Msg
							),1);
						}
						$Msg = $this->Config['LangVar']['PushReplyTitle'].$this->Config['LangVar']['Mao'].cutstr(strip_tags($RPost['content']),20);
						notification_add($RPost['uid'],'system','<a href="{url}">{msg}</a>',array(
							'url'=>$Url,
							'msg'=>$Msg
						),1);
	
					}else{
						notification_add($Item['uid'],'system','<a href="{url}">{msg}</a>',array(
							'url'=>$Url,
							'msg'=>$Msg
						),1);
					}
					//dz系统通知 End
					if($Config['PluginVar']['AppType'] == 1){//马甲助手推送
						$Cover = strpos($Param['face'],'http') !== false ? $Param['face'] : $_G['siteurl'].$Param['face'];
						$PushData['Uid'] = $Item['uid'];
						$PushData['Type'] = 'pictemp';
						$PushData['Content'] = array(
							"tag"=> diconv($this->Config['LangVar']['PushCommentTitle'],CHARSET,'UTF-8'),
							"title"=> diconv($this->Config['LangVar']['PushCommentTitle'],CHARSET,'UTF-8'),
							"link"=> $Url,
							"pic_url"=> $Cover,
							"extra_info"=>array(
								array(
									"key"=> diconv($Param['name'],CHARSET,'UTF-8'),
									"val"=> diconv($InsData['content'],CHARSET,'UTF-8')
								)
							)
						);
			
						if($RPost['uid'] && $RPost['uid'] != $Uid){//回复通知
							if($this->Config['PluginVar']['ReplyNoticeSwitch'] && $Uid && $Uid != $Item['uid']){//回复是否通知楼主
								$this->MagApp->GetSendAssistantMsg($PushData);
							}
							$PushData['Uid'] = $RPost['uid'];
							$PushData['Content']['tag'] = $PushData['Content']['title'] = diconv($this->Config['LangVar']['PushReplyTitle'],CHARSET,'UTF-8');
							$this->MagApp->GetSendAssistantMsg($PushData);
							
						}else{
							if($Uid && $Uid != $Item['uid']){//评论
								$this->MagApp->GetSendAssistantMsg($PushData);
							}
						}
					}else if($Config['PluginVar']['AppType'] == 2){//千帆模板消息
						$PushData['Uid'] = $Item['uid'];
						$PushData['Type'] = 'pictemp';
						$PushData['Content'] = array(
							'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['PushCommentTitle'])),CHARSET,'UTF-8'),
							'date'=>date('Y-m-d H:i:s'),
							'setting'=>array(
								array(
									"setKey"=> diconv($Param['name'],CHARSET,'UTF-8'),
									"setValue"=> diconv($InsData['content'],CHARSET,'UTF-8')
								)
							),
							'content' => '',
							'url'=>$Url
						);
			
						if($RPost['uid'] && $RPost['uid'] != $Uid){//回复通知
							if($this->Config['PluginVar']['ReplyNoticeSwitch'] && $Uid && $Uid != $Item['uid']){//回复是否通知楼主
								$this->QHApp->GetMessagesTemplate($PushData);
							}
							$PushData['Uid'] = $RPost['uid'];
							$PushData['Content']['title'] = diconv($this->Config['LangVar']['PushReplyTitle'],CHARSET,'UTF-8');
							$this->QHApp->GetMessagesTemplate($PushData);
							
						}else{
							if($Uid && $Uid != $Item['uid']){//评论
								$this->QHApp->GetMessagesTemplate($PushData);
							}
						}
					}
					
					return $Data;
				}
			}else{
				$Data['Msg'] = $this->Config['LangVar']['CommentErr'];
				return $Data;
			}
		}else{
			$Data['Msg'] = $this->Config['LangVar']['ItemNullErr'];
			return $Data;
		}
	}
	/* 快捷发布 */
	public function GetAjaxFastAdd(){
		global $_G;
		
		foreach(array_filter(explode("\r\n",$this->Config['PluginVar']['FastAddContent'])) as $Key => $Val) {
			$Array = array_filter(explode("=",$Val));
			$FastAddContent[$Key]['content'] = $Array[0];
			$FastAddContent[$Key]['word_id'] = $Array[1];
		}

		$Uid = intval($_G['uid']);
		$FaceArray =  array_filter(explode("\r\n",$this->Config['PluginVar']['Faca']));
		$NameArray =  array_filter(explode("\r\n",$this->Config['PluginVar']['Name']));
		$AddGroups = array_filter(unserialize($this->Config['PluginVar']['AddGroups']));

		$InsData = array();
		$Rand = rand(0,(count($FastAddContent)-1));
		$InsData['content'] = censor(addslashes(strip_tags($FastAddContent[$Rand]['content'])));
		$InsData['wid'] = intval($FastAddContent[$Rand]['word_id']);
		$InsData['uid'] = $Uid;
		$InsData['username'] = addslashes(strip_tags($_G['username']));
		$InsData['dateline'] = time();
		$InsData['updateline'] = time();
		$InsData['useip'] = addslashes(strip_tags($_G['clientip']));
		$InsData['display'] = 1;
		$InsData['fast_add_display'] = $this->Config['PluginVar']['FastAddDisplay'] ? 1 : 0;
		$Param['face'] = addslashes(strip_tags($FaceArray[rand(0,count($FaceArray)-1)]));
		$Param['name'] = addslashes(strip_tags($NameArray[rand(0,count($NameArray)-1)]));
		$InsData['param'] = serialize($Param);
		
		if(!$InsData['content']){//内容不能为空
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContentNullErr']);
			return $Data;
		}

		if($Uid){
			$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecret).' where uid = '.$Uid.' and content = \''.$InsData['content'].'\'');
		}else{
			$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecret).' where useip = \''.addslashes(strip_tags($_G['clientip'])).'\' and content = \''.$InsData['content'].'\'');
		}

		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Data['Content'] = $Data['Share_Content'] = urlencode(cutstr(strip_tags($InsData['content']),210));
			$Data['Share_Ico'] = strpos($Item['param']['face'],'http') !== false ? urlencode($Item['param']['face']) : urlencode($_G['siteurl'].$Item['param']['face']);
			$Data['Url'] = urlencode($this->Config['ViewthreadUrl'].$Item['id']);
			$Data['State'] = 200;
			$Data['SId'] = $Item['id'];
			return $Data;
		}
		
		//时间限制
		if($Uid){
			$MySecret = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecret).' where uid = '.$Uid.' order by id DESC');
		}else{
			$MySecret = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecret).' where useip = \''.addslashes(strip_tags($_G['clientip'])).'\' order by id DESC');
		}

		if($this->Config['PluginVar']['AddTime'] && time() < strtotime("+".$this->Config['PluginVar']['AddTime']." second",$MySecret['dateline'])){
			$TIME = $this->Config['PluginVar']['AddTime'] - (time() - $MySecret['dateline']);
			$Data['Msg'] = str_replace('{TIME}',$TIME,$this->Config['LangVar']['AddTimeErr']);
			return $Data;
		}

		if($AddGroups && !in_array($_G['member']['groupid'],$AddGroups)){//用户组限制
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddGroupsErr']);
			return $Data;
		}
		$Id = DB::insert($this->TableSecret,$InsData,true);
		if($Id){
			$Data['Content'] = $Data['Share_Content'] = urlencode(cutstr(strip_tags($InsData['content']),210));
			$Data['Share_Ico'] = strpos($Param['face'],'http') !== false ? urlencode($Param['face']) : urlencode($_G['siteurl'].$Param['face']);
			$Data['Url'] = urlencode($this->Config['ViewthreadUrl'].$Id);
			$Data['State'] = 200;
			$Data['SId'] = $Id;
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddErr']);
			return $Data;
		}	

	}

	/* 发布小秘密 */
	public function GetAjaxAdd($Post){
		global $_G;
		$Post = EncodeURIToUrldeCode($Post);
		$Uid = intval($_G['uid']);
		$FaceArray =  array_filter(explode("\r\n",$this->Config['PluginVar']['Faca']));
		$NameArray =  array_filter(explode("\r\n",$this->Config['PluginVar']['Name']));
		$AddGroups = array_filter(unserialize($this->Config['PluginVar']['AddGroups']));
		$ItemBusiness = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecretBusiness).' where id = '.intval($Post['bid']).' order by id DESC');
		$InsData = array();
		$InsData['content'] = censor(addslashes(strip_tags($Post['content'])));
		$InsData['wid'] = intval($Post['wid']);
		$InsData['bid'] = $ItemBusiness['display'] ? intval($Post['bid']) : '';
		$InsData['uid'] = $Uid;
		$InsData['username'] = addslashes(strip_tags($_G['username']));
		$InsData['dateline'] = time();
		$InsData['updateline'] = time();
		$InsData['useip'] = addslashes(strip_tags($_G['clientip']));
		$InsData['lat'] = addslashes(strip_tags($Post['lat']));
		$InsData['lng'] = addslashes(strip_tags($Post['lng']));
		$InsData['display'] = $this->Config['PluginVar']['ExamineSwitch'] ? 0 : 1;
		$Param['face'] = addslashes(strip_tags($FaceArray[rand(0,count($FaceArray)-1)]));
		$Param['name'] = addslashes(strip_tags($NameArray[rand(0,count($NameArray)-1)]));
		//时间限制
		if($Uid){
			$MySecret = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecret).' where uid = '.$Uid.' order by id DESC');
		}else{
			$MySecret = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecret).' where useip = \''.addslashes(strip_tags($_G['clientip'])).'\' order by id DESC');
		}
		if($this->Config['PluginVar']['AddTime'] && time() < strtotime("+".$this->Config['PluginVar']['AddTime']." second",$MySecret['dateline'])){
			$TIME = $this->Config['PluginVar']['AddTime'] - (time() - $MySecret['dateline']);
			$Data['Msg'] = str_replace('{TIME}',$TIME,$this->Config['LangVar']['AddTimeErr']);
			return $Data;
		}

		if($AddGroups && !in_array($_G['member']['groupid'],$AddGroups)){//用户组限制
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddGroupsErr']);
			return $Data;
		}
		if(!$InsData['content']){//内容不能为空
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContentNullErr']);
			return $Data;
		}
		//违规词
		if($this->Config['PluginVar']['ViolationWordSwitch']){
			$censor = discuz_censor::instance();
			$censor->check($InsData['content']);
			if($censor->modbanned()){
				$Data['Msg'] = $this->Config['LangVar']['WordBanned'];
				return $Data;
			}
		}
		//字符限制
		if($this->Config['PluginVar']['AddMinLength'] && dstrlen($InsData['content']) < $this->Config['PluginVar']['AddMinLength']){//内容不能为空
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddMinLengthErr']);
			return $Data;
		}
		if($this->Config['PluginVar']['AddWordSwitch'] && !$InsData['wid']){//没有选择标签
			$Data['Msg'] = urlencode($this->Config['LangVar']['WordNullErr']);
			return $Data;
		}

		if($this->Config['PluginVar']['AddUpload']){
			$ImgsArray = array();
			foreach(array_filter(explode(';',$Post['imgs'][0])) as $Key => $Val) {
				$ImgsArray[$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
			}
			$Param['imgs'] = $ImgsArray ? implode(',',array_slice($ImgsArray,0,$this->Config['PluginVar']['AddUploadNum'])) : '';
		}

		$InsData['param'] = serialize($Param);
		$InsData['content'] = str_replace(array("\r\n","\n"),array('<br>','<br>'),$InsData['content']);
		$Id = DB::insert($this->TableSecret,$InsData,true);
		if($Id){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddOk']);
			$Data['State'] = 200;
			$Data['SId'] = $Id;
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddErr']);
			return $Data;
		}		
	}
	/* 用户操作小秘密 */
	public function GetAjaxUserOp($Op,$Id){
		global $_G;
		$Id = intval($Id);
		$Uid = intval($_G['uid']);
		if(!$this->Config['PluginVar']['UserDel']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
		$Item = $this->GetViewthread($Id);
		if(!$Item){
			$Data['Msg'] = $this->Config['LangVar']['ItemNullErr'];
			return $Data;
		}
		if($Op == 'Del'){
			if(DB::delete($this->TableSecret,'id ='.$Id.' and uid = '.$Uid)){
				DB::delete($this->TableSecretPost,'sid ='.$Id);
				DB::delete($this->TableSecretSupport,'sid ='.$Id);
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
	}
	/* 用户操作小秘密评论 */
	public function GetAjaxUserOpPost($Op,$Id){
		global $_G;
		$Id = intval($Id);
		$Uid = intval($_G['uid']);
		if(!$this->Config['PluginVar']['UserDel']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
		$Post = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecretPost).' where pid = '.$Id.' and uid = '.$Uid);
		if(!$Post){
			$Data['Msg'] = $this->Config['LangVar']['CommentNullErr'];
			return $Data;
		}
		if($Op == 'Del'){
			if(DB::delete($this->TableSecretPost,'pid ='.$Id.' and uid = '.$Uid)){
				DB::query("UPDATE ".DB::table($this->TableSecret)." SET comment_count = comment_count-1 WHERE id=".intval($Post['sid']));
				if($Post['rid']){
					DB::query("UPDATE ".DB::table($this->TableSecretPost)." SET reply_count = reply_count-1 WHERE pid=".intval($Post['rid']));
				}
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}

	}
	/* 管理员操作小秘密 */
	public function GetAjaxAdminOp($Op,$Id){
		global $_G;
		$Id = intval($Id);
		if(!in_array($_G['uid'],array_filter(explode(",",$this->Config['PluginVar']['AdminUids'])))){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
		$Item = $this->GetViewthread($Id);
		if(!$Item){
			$Data['Msg'] = $this->Config['LangVar']['ItemNullErr'];
			return $Data;
		}
		if($Op == 'Del'){
			if(DB::delete($this->TableSecret,'id ='.$Id)){
				DB::delete($this->TableSecretPost,'sid ='.$Id);
				DB::delete($this->TableSecretSupport,'sid ='.$Id);
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else if($Op == 'Display'){
			if(DB::update($this->TableSecret,array('display'=>0),'id = '.$Id)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
	}
	/* 管理员操作小秘密评论 */
	public function GetAjaxAdminOpPost($Op,$Id,$Value=null){
		global $_G;
		$Id = intval($Id);
		if(!in_array($_G['uid'],array_filter(explode(",",$this->Config['PluginVar']['AdminUids'])))){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
		$Post = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSecretPost).' where pid = '.$Id);
		if(!$Post){
			$Data['Msg'] = $this->Config['LangVar']['CommentNullErr'];
			return $Data;
		}
		if($Op == 'Del'){
			if(DB::delete($this->TableSecretPost,'pid ='.$Id)){
				DB::query("UPDATE ".DB::table($this->TableSecret)." SET comment_count = comment_count-1 WHERE id=".intval($Post['sid']));
				if($Post['rid']){
					DB::query("UPDATE ".DB::table($this->TableSecretPost)." SET reply_count = reply_count-1 WHERE pid=".intval($Post['rid']));
				}
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else if($Op == 'Display'){
			if(DB::update($this->TableSecretPost,array('display'=>intval($Value)),'pid = '.$Id)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}

	}
	/* 推荐话题 */
	public function GetHotWord(){
		$Where =  ' where display = 1 and hot = 1';
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableSecretWord).$Where.' order by displayorder ASC';
		$List = DB::fetch_all($FetchSql);
		foreach ($List as $Key => $Val) {
			$List[$Key]['param'] = unserialize($Val['param']);
			$ReturnList[$Val['id']] = $List[$Key];
		}
		return $ReturnList;
	}
	/* 全部标题 */
	public function GetAllWord($Display=null){
		$Display = intval($Display);
		if($Display){
			$Where =  ' where display = '.$Display;
		}
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableSecretWord).$Where.' order by displayorder ASC';
		$List = DB::fetch_all($FetchSql);
		foreach ($List as $Key => $Val) {
			$List[$Key]['param'] = unserialize($Val['param']);
			$ReturnList[$Val['id']] = $List[$Key];
		}
		return $ReturnList;
	}

	/* 全部商家 */
	public function GetAllBusiness($Display=null){
		$Display = intval($Display);
		if($Display){
			$Where =  ' where display = '.$Display;
		}
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableSecretBusiness).$Where.' order by id ASC',array(),'id');
	}
	

	/* 查询单个 */
	public function QueryOne($TableName=null,$Id=null,$Where=null){
		$FirstSql = 'SELECT * FROM '.DB::table($TableName).' where id = '.$Id.' '.$Where;
		return DB::fetch_first($FirstSql);	
	}

	/** 
	 *计算某个经纬度的周围某段距离的正方形的四个点 
	 * 
	 *@param lng float 经度 
	 *@param lat float 纬度 
	 *@param distance float 该点所在圆的半径，该圆与此正方形内切，默认值为0.5千米 
	 *@return array 正方形的四个点的经纬度坐标 
	 */  
	 public function GetReturnSquarePoint($Lng,$Lat,$Distance=0.5){
		$EARTH_RADIUS = 6371;//地球半径，平均半径为6371km  
		$Dlng =  2 * asin(sin($Distance / ( 2 * $EARTH_RADIUS)) / cos(deg2rad($Lat)));  
		$Dlng = rad2deg($Dlng);  
		$Dlat = $Distance / $EARTH_RADIUS;  
		$Dlat = rad2deg($Dlat);  
		return array(  
			'left-top'=>array('lat'=>$Lat + $Dlat,'lng'=>$Lng-$Dlng),  
			'right-top'=>array('lat'=>$Lat + $Dlat, 'lng'=>$Lng + $Dlng),  
			'left-bottom'=>array('lat'=>$Lat - $Dlat, 'lng'=>$Lng - $Dlng),  
			'right-bottom'=>array('lat'=>$Lat - $Dlat, 'lng'=>$Lng + $Dlng)  
		);  
	 }  
}

$Fn_Secret = new Fn_Secret;
?>