<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
@require_once (DISCUZ_ROOT .'./source/plugin/fn_secret/Function.inc.php');

$Operation = in_array($_GET['Operation'], array('Display','Del','OpValue','AllDel')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&page='.$_GET['page'].'&keyword='.$_GET['keyword'].'&display='.$_GET['display'].'&wid='.$_GET['wid'].'&order='.$_GET['order'];
$OpSecretCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminSecret';
$OpPostCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminPostList';

if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		$OpCpUrl = $SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = in_array($_GET['order'], array('id','click','support_count','comment_count','share_count','topdateline')) ? 'S.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'S.id';
		if($_GET['keyword']){
			$Where .= ' and concat(S.username,S.uid,S.content) like(\'%'.addslashes(dhtmlspecialchars(str_replace(array('%','_'),array('',''),$_GET['keyword']))).'%\')';
		}
		if(in_array($_GET['display'],array('0','1'))){
			$Where .= ' and S.display = '.intval($_GET['display']);
		}
		if($_GET['wid']){
			$Where .= ' and S.wid = '.intval($_GET['wid']);
		}

		if($_GET['bid']){
			$Where .= ' and S.bid = '.intval($_GET['bid']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ���� */
		$DisplaySelected = array($_GET['display']=>' selected');
		$OrderSelected = array($_GET['order']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Secret->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>{$Fn_Secret->Config['LangVar']['WordID']}</th><td><input type="text" class="txt" name="wid" value="{$_GET['wid']}" size="6">
						</td>
						<th>{$Fn_Secret->Config['LangVar']['BusinessTitle']}ID</th><td><input type="text" class="txt" name="bid" value="{$_GET['bid']}" size="6">
						</td>
						<th>{$Fn_Secret->Config['LangVar']['DisplayTitle']}</th><td>
						<select name="display">
							<option value="">{$Fn_Secret->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$DisplaySelected['1']}>{$Fn_Secret->Config['LangVar']['Yes']}</option>
							<option value="0"{$DisplaySelected['0']}>{$Fn_Secret->Config['LangVar']['No']}</option>
						</select>
						</td>
						<th>{$Fn_Secret->Config['LangVar']['SortTitle']}</th><td colspan="3"><select name="order">
						<option value="id"{$OrderSelected['id']}>id</option>
						<option value="click"{$OrderSelected['click']}>{$Fn_Secret->Config['LangVar']['Click']}</option>
						<option value="support_count"{$OrderSelected['support_count']}>{$Fn_Secret->Config['LangVar']['SupportCount']}</option>
						<option value="comment_count"{$OrderSelected['comment_count']}>{$Fn_Secret->Config['LangVar']['CommentCount']}</option>
						<option value="share_count"{$OrderSelected['share_count']}>{$Fn_Secret->Config['LangVar']['ShareCount']}</option>
						<option value="topdateline"{$OrderSelected['topdateline']}>{$Fn_Secret->Config['LangVar']['TopDateline']}</option>
						</select>&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Secret->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">&nbsp;&nbsp;<a href="{$OpCpUrl}&Operation=Add"><b>{$Fn_Secret->Config['LangVar']['AddScore']}</b></a></td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */

		/* ģ����� */
		if($Fn_Secret->Config['PluginVar']['AdminUserSwitch']){
			$TdStyle = array('width="80"', 'width="200"','width="100"','width="50"','width="50"','width="50"','width="50"','width="60"','width="130"','width="130"','');
		}else{
			$TdStyle = array('width="80"', 'width="200"','width="100"','width="100"','width="50"','width="50"','width="50"','width="50"','width="60"','width="130"','width="130"','');
		}
		
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'QiangLouModule', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_Secret->Config['LangVar']['InfoListTitle']);
		if($Fn_Secret->Config['PluginVar']['AdminUserSwitch']){
			showsubtitle(array(
				'ID',
				$Fn_Secret->Config['LangVar']['ContentTitle'],
				$Fn_Secret->Config['LangVar']['WordTitle'],
				$Fn_Secret->Config['LangVar']['Click'],
				$Fn_Secret->Config['LangVar']['SupportCount'],
				$Fn_Secret->Config['LangVar']['CommentCount'],
				$Fn_Secret->Config['LangVar']['ShareCount'],
				$Fn_Secret->Config['LangVar']['DisplayTitle'],
				$Fn_Secret->Config['LangVar']['TopDateline'],
				$Fn_Secret->Config['LangVar']['TimeTitle'],
				$Fn_Secret->Config['LangVar']['OperationTitle']
			), 'header tbm',$TdStyle);
		}else{
			showsubtitle(array(
				'ID',
				$Fn_Secret->Config['LangVar']['ContentTitle'],
				$Fn_Secret->Config['LangVar']['WordTitle'],
				'Uid/'.$Fn_Secret->Config['LangVar']['UserNameTitle'],
				$Fn_Secret->Config['LangVar']['Click'],
				$Fn_Secret->Config['LangVar']['SupportCount'],
				$Fn_Secret->Config['LangVar']['CommentCount'],
				$Fn_Secret->Config['LangVar']['ShareCount'],
				$Fn_Secret->Config['LangVar']['DisplayTitle'],
				$Fn_Secret->Config['LangVar']['TopDateline'],
				$Fn_Secret->Config['LangVar']['TimeTitle'],
				$Fn_Secret->Config['LangVar']['OperationTitle']
			), 'header tbm',$TdStyle);
		}
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			if($Fn_Secret->Config['PluginVar']['AdminUserSwitch']){
				showtablerow('', array('class="td25"', 'class="td28"'), array(
					'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'],
					'<div title="'.$Module['content'].'">'.cutstr($Module['content'],25).'</div>',
					$Module['Ttitle'],
					$Module['click'],
					$Module['support_count'],
					$Module['comment_count'],
					$Module['share_count'],
					!$Module['display'] ? '<span style="color:red">'.$Fn_Secret->Config['LangVar']['No'].'</span>' : $Fn_Secret->Config['LangVar']['Yes'],
					$Module['topdateline'] ? date('Y-m-d H:i',$Module['dateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Secret->Config['ViewthreadUrl'].$Module['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$OpSecretCpUrl.'&Operation=Edit&sid='.$Module['id'].'">'.$Fn_Secret->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpPostCpUrl.'&sid='.$Module['id'].'">'.$Fn_Secret->Config['LangVar']['OpCommentTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Display&sid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_Secret->Config['LangVar']['DisplayNoTitle'] : $Fn_Secret->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&sid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Secret->Config['LangVar']['DelTitle'].'</a>'
				));
			}else{
				showtablerow('', array('class="td25"', 'class="td28"'), array(
					'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'],
					'<div title="'.$Module['content'].'">'.cutstr($Module['content'],25).'</div>',
					$Module['Ttitle'],
					$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
					$Module['click'],
					$Module['support_count'],
					$Module['comment_count'],
					$Module['share_count'],
					!$Module['display'] ? '<span style="color:red">'.$Fn_Secret->Config['LangVar']['No'].'</span>' : $Fn_Secret->Config['LangVar']['Yes'],
					$Module['topdateline'] ? date('Y-m-d H:i',$Module['dateline']) : '',
					date('Y-m-d H:i',$Module['dateline']),
					'<a href="'.$Fn_Secret->Config['ViewthreadUrl'].$Module['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$OpSecretCpUrl.'&Operation=Edit&sid='.$Module['id'].'">'.$Fn_Secret->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpPostCpUrl.'&sid='.$Module['id'].'">'.$Fn_Secret->Config['LangVar']['OpCommentTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Display&sid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_Secret->Config['LangVar']['DisplayNoTitle'] : $Fn_Secret->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&sid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Secret->Config['LangVar']['DelTitle'].'</a>'
				));
			}
		}
		showsubmit('Submit','submit','del','<a href="'.$OpCpUrl.'&Operation=AllDel">'.$Fn_Secret->Config['LangVar']['AllDel'].'</a>',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism _ taobao _ com*/
		showformfooter(); /*dism��taobao��com*/
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_Secret->TableSecret,'id ='.$Val);
				DB::delete($Fn_Secret->TableSecretPost,'sid ='.$Val);
				DB::delete($Fn_Secret->TableSecretSupport,'sid ='.$Val);
			}
			cpmsg($Fn_Secret->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_Secret->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['sid']){//ɾ��
	$SId = intval($_GET['sid']);
	DB::delete($Fn_Secret->TableSecret,'id ='.$SId);
	DB::delete($Fn_Secret->TableSecretPost,'sid ='.$SId);
	DB::delete($Fn_Secret->TableSecretSupport,'sid ='.$SId);
	cpmsg($Fn_Secret->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'Display' && $_GET['formhash'] == formhash() && $_GET['sid']){//�Ƿ���ʾ
	$SId = intval($_GET['sid']);
	$Value = intval($_GET['value']);
	EditFields($Fn_Secret->TableSecret,$SId,'display',$Value);
	cpmsg($Fn_Secret->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'AllDel'){//ȫ��ɾ��
	if(!submitcheck('DetailSubmit')) {
		$formUrl = ltrim(rawurldecode(cpurl()),'action=');
		showformheader($formUrl,'enctype');
		showtableheader();
		showtitle($Fn_Secret->Config['LangVar']['AllDel']);
		showsetting($Fn_Secret->Config['LangVar']['AllDelTime'],array('dateline',DyadicArray($Fn_Secret->Config['LangVar']['AllDelTimeArray'],$Fn_Secret->Config['LangVar']['SelectNull'])),'','select','','',$Fn_Secret->Config['LangVar']['AllDelTimeTips']);
		showtablefooter(); /*dism _ taobao _ com*/
		showsubmit('DetailSubmit');
		showformfooter(); /*dism��taobao��com*/
	}else{
		if(!$_GET['dateline']){
			cpmsg($Fn_Secret->Config['LangVar']['AllDelTimeErr'],'','error');
			exit();
		}
		$I = 0;
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($Fn_Secret->TableSecret).' where dateline <= '.strtotime("-".intval($_GET['dateline'])." day",time()).' order by id desc') as $Key => $Value) {
			$SId = intval($Value['id']);
			DB::delete($Fn_Secret->TableSecret,'id ='.$SId);
			DB::delete($Fn_Secret->TableSecretPost,'sid ='.$SId);
			DB::delete($Fn_Secret->TableSecretSupport,'sid ='.$SId);
			$I++;
		}
		if($I){
			cpmsg($Fn_Secret->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_Secret->Config['LangVar']['AllDelNoContentErr'],'','error');
		}
		
	}
}
/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Secret;
	$FetchSql = 'SELECT W.title as Ttitle,S.* FROM '.DB::table($Fn_Secret->TableSecret).' S LEFT JOIN '.DB::table($Fn_Secret->TableSecretWord).' W on W.id = S.wid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Secret;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Secret->TableSecret).' S '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>