<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_secret/Function.inc.php');
$OpSecretListCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminSecretList';
if(!submitcheck('Submit')){
	$MpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
	foreach($_GET as $key => $val){
		$MpUrl.= '&'.$key.'='.$val;
	}
	$Where = '';
	$Order = 'W.id';
	$Limit = 30;
	$Page = $_GET['page']?intval($_GET['page']):1;

	$TdStyle = array('width="20"', 'width="80"', 'width="80"', 'width="80"', 'width="80"', 'width="300"', 'width="60"');
	$formUrl = ltrim(rawurldecode(cpurl()),'action=');
	showtagheader('div', 'banner_module', true);
	showformheader($formUrl,'enctype="multipart/form-data"');
	showtableheader($Fn_Secret->Config['LangVar']['BannerDisplayTitle']);
	showsubtitle(array(
		'ID',
		$Fn_Secret->Config['LangVar']['DisplayOrder'],
		$Fn_Secret->Config['LangVar']['Title'],
		$Fn_Secret->Config['LangVar']['DisplayTitle'],
		$Fn_Secret->Config['LangVar']['HotTitle'],
		$Fn_Secret->Config['LangVar']['CoverTitle'].$Fn_Secret->Config['LangVar']['CoverSize'],
		$Fn_Secret->Config['LangVar']['WordCount'],
		$Fn_Secret->Config['LangVar']['OperationTitle']
	), 'header tbm',$TdStyle);
	$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
	foreach ($ModulesList as $Module) {
		$Module['param'] = unserialize($Module['param']);
		if($Module['display'] == 1){
			$CheckedD = "checked='checked'";
			$CheckedN = '';
		}else{
			$CheckedN = "checked='checked'";
			$CheckedD = '';
		}
		if($Module['hot'] == 1){
			$HotCheckedD = "checked='checked'";
			$HotCheckedN = '';
		}else{
			$HotCheckedN = "checked='checked'";
			$HotCheckedD = '';
		}
		showtablerow('', array('class="td25"', 'class="td28"'), array(
			'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'],
			'<input type="text" class="txt" size="2" name="displayorder['.$Module['id'].']" value="'.$Module['displayorder'].'" />',
			'<input type="text" size="30" name="title['.$Module['id'].']" value="'.$Module['title'].'" />',
			'<label><input name="display['.$Module['id'].']" type="radio" value="1" '.$CheckedD.'/>'.$Fn_Secret->Config['LangVar']['Yes'].'</label><label><input name="display['.$Module['id'].']" type="radio" value="0" '.$CheckedN.'/>'.$Fn_Secret->Config['LangVar']['No'].'</label>',
			'<label><input name="hot['.$Module['id'].']" type="radio" value="1" '.$HotCheckedD.'/>'.$Fn_Secret->Config['LangVar']['Yes'].'</label><label><input name="hot['.$Module['id'].']" type="radio" value="0" '.$HotCheckedN.'/>'.$Fn_Secret->Config['LangVar']['No'].'</label>',
			'<a href="'.$Module['param']['cover'].'" target="_blank"><img src="'.$Module['param']['cover'].'" style="width:60px;float:left;display:inline;margin:0 5px 0 0;"></a><input type="hidden" size="30" name="cover['.$Module['id'].']" value="'.$Module['param']['cover'].'" /> <input name="file_cover['.$Module['id'].']" value="" class="txt uploadbtn" type="file" style="width:200px;">',
			'<a href="'.$OpSecretListCpUrl.'&wid='.$Module['id'].'">'.DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_Secret->TableSecret).' where wid = '.$Module['id']).'</a>',
			'<a href="'.$Fn_Secret->Config['Url'].'&wid='.$Module['id'].'" target="_blank">'.cplang('view').'</a>'
		));
	}
	showtablerow('', array('class="td25"', 'class="td28"'), array(
		cplang('add_new'),
		sprintf('<input type="text" class="txt" size="2" maxlength="4" name="new_displayorder" value="" />'),
		sprintf('<input type="text" size="30" name="new_title" value="" />'),
		sprintf('<label><input name="new_display" type="radio" value="1" checked="checked"/>'.$Fn_Secret->Config['LangVar']['Yes'].'</label><label><input name="new_display" type="radio" value="0" />'.$Fn_Secret->Config['LangVar']['No'].'</label>'),
		sprintf('<label><input name="new_hot" type="radio" value="1"/>'.$Fn_Secret->Config['LangVar']['Yes'].'</label><label><input name="new_hot" type="radio" value="0" checked="checked"/>'.$Fn_Secret->Config['LangVar']['No'].'</label>'),
		sprintf('<input name="new_cover" value="" class="txt uploadbtn" type="file" style="width:200px;">'),
		'',
		''
	));
	showsubmit('Submit', 'submit', 'del','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
    showtablefooter(); /*dism _ taobao _ com*/
	showformfooter(); /*dism��taobao��com*/
	showtagfooter('div');
}else{
	// ɾ��ѡ�л���
    if (isset($_POST['delete']) && is_array($_POST['delete'])) {
		foreach($_POST['delete'] as $Id){
			$Id = intval($Id);
			$Item = $Fn_Secret->QueryOne($Fn_Secret->TableSecretWord,$Id);
			if($Item){
				$Item['param'] = unserialize($Item['param']);
				unlink(DISCUZ_ROOT.$Item['param']['cover']);//ɾ��ͼƬ
				DB::delete($Fn_Secret->TableSecretWord,'id ='.$Id);
				DB::delete($Fn_Secret->TableSecret,'wid ='.$Id);
				DB::delete($Fn_Secret->TableSecretPost,'wid ='.$Id);
				DB::delete($Fn_Secret->TableSecretSupport,'wid ='.$Id);
			}
		}
	}
	//���»���
	if (isset($_POST['displayorder']) && is_array($_POST['displayorder'])) {
		foreach ($_POST['displayorder'] as $Id => $displayorder) {
			$UpIns = array();
			$Id = intval($Id);
			$UpIns['title'] =  addslashes(strip_tags($_POST['title'][$Id]));
			$UpIns['displayorder'] =  intval($displayorder);
			$UpIns['display'] =  intval($_POST['display'][$Id]);
			$UpIns['hot'] =  intval($_POST['hot'][$Id]);
			if($_FILES['file_cover']['size'][$Id]){
				$Cover = array(
					'name' => $_FILES['file_cover']['name'][$Id],
					'type' => $_FILES['file_cover']['type'][$Id],
					'tmp_name' => $_FILES['file_cover']['tmp_name'][$Id],
					'error' => $_FILES['file_cover']['error'][$Id],
					'size' => $_FILES['file_cover']['size'][$Id]
				);
				$Item = $Fn_Secret->QueryOne($Fn_Secret->TableSecretWord,$Id);
				$Item['param'] = unserialize($Item['param']);
				$UpCover = Fn_Upload($Cover,$Item['param']['cover']);
				if($UpCover['Errorcode']){
					cpmsg($Fn_Video->Config['LangVar']['ImgErr'],'','error');
				}else{
					$UpParam['cover'] = addslashes(strip_tags($UpCover['Path']));
				}
			}else{
				$UpParam['cover']=  addslashes(strip_tags($_POST['cover'][$Id]));
			}
			$UpIns['param'] = serialize($UpParam);
			DB::update($Fn_Secret->TableSecretWord,$UpIns,'id = '.$Id);
		}
    }
	//���ӻ���
    if($_POST['new_title']) {
		$Ins = array();
		$Ins['title'] = addslashes(strip_tags($_POST['new_title']));
		$Ins['displayorder'] = intval($_POST['new_displayorder']);
		$Ins['display'] = intval($_POST['new_display']);
		$Ins['hot'] = intval($_POST['new_hot']);
		$Ins['dateline'] = time();
		if($_FILES['new_cover']['size']){
			$CoverFile = Fn_Upload($_FILES['new_cover']);
			if($CoverFile['Errorcode']){
				cpmsg($Fn_Secret->Config['LangVar']['ImgErr'],'','error');
			}else{
				$InsParam['cover']  = addslashes(strip_tags($CoverFile['Path']));
			}
		}
		$Ins['param'] = serialize($InsParam);
		DB::insert($Fn_Secret->TableSecretWord,$Ins);
    }
	cpmsg($Fn_Secret->Config['LangVar']['UpdateOk'],rawurldecode(cpurl()),'succeed');
}

/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Secret;
	$FetchSql = 'SELECT W.* FROM '.DB::table($Fn_Secret->TableSecretWord).' W '.$Where.' order by '.$Order.' asc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Secret;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Secret->TableSecretWord).' W '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>