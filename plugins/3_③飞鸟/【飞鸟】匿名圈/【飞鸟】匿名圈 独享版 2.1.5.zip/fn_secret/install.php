<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_secret` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `wid` int(11) unsigned NOT NULL,
  `bid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `support_count` int(11) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(11) unsigned NOT NULL DEFAULT '0',
  `share_count` int(11) unsigned NOT NULL DEFAULT '0',
  `lat` varchar(30) NOT NULL,
  `lng` varchar(30) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `displayorder` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `click` int(11) unsigned NOT NULL,
  `useip` varchar(50) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `fast_add_display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `display` (`display`),
  KEY `wid` (`wid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_secret_post` (
  `pid` int(11) unsigned NOT NULL,
  `sid` int(11) unsigned NOT NULL,
  `wid` int(11) unsigned NOT NULL,
  `bid` int(11) unsigned NOT NULL,
  `rid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(11) NOT NULL,
  `content` text NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `useip` varchar(30) NOT NULL,
  `reply_count` int(11) unsigned NOT NULL,
  `support_count` int(11) unsigned NOT NULL,
  `floor_host` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `position` int(11) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`sid`,`position`),
  KEY `uid` (`uid`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_secret_post_tableid` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_secret_support` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `sid` int(11) unsigned NOT NULL,
  `wid` int(11) unsigned NOT NULL,
  `bid` int(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_secret_word` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `hot` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `displayorder` tinyint(4) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_secret_business` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
?>