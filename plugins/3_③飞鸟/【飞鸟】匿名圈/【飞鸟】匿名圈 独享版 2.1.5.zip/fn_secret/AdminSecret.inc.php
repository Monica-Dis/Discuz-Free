<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
@require_once (DISCUZ_ROOT .'./source/plugin/fn_secret/Function.inc.php');

$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&sid='.$_GET['sid'];
$SId = intval($_GET['sid']);
$Item = $SId ? $Fn_Secret->QueryOne($Fn_Secret->TableSecret,$SId) : array();
if($Item['param']){$Item['param'] = unserialize($Item['param']);}
$Title = $Fn_QHB->Config['LangVar']['AddTitle'];
$AllWord = $Fn_Secret->GetAllWord(1);//����
$AllBusiness = $Fn_Secret->GetAllBusiness(1);//����
if(!submitcheck('DetailSubmit')) {
	$OpTitle = $Fn_Secret->Config['LangVar']['AddTitle'];
	if($Item) {
		$OpTitle = $Fn_Secret->Config['LangVar']['EditTitle'];
	}

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

	$formUrl = ltrim(rawurldecode(cpurl()),'action=');
	showformheader($formUrl.'&sid='.$Item['id'],'enctype');
	showtableheader();
	showtitle($OpTitle);
	showsetting($Fn_Secret->Config['LangVar']['ContentTitle'], 'content', str_replace("<br>","\r\n",$Item['content']), 'textarea');
	$WordHtml = '<div class="WordList">';
	foreach($AllWord as $Key => $Val) {
		$WordClass = $Val['id'] == $Item['wid'] ? ' class="Hover"' : '';
		$WordHtml .= '<span Title="'.$Val['title'].'" Id="'.$Val['id'].'"'.$WordClass.'>#'.$Val['title'].'#</span>';
	}
	$WordHtml .= '</div>';
	showsetting($Fn_Secret->Config['LangVar']['WordTitle'], 'wid', $Item['wid'] ? $Item['wid'].'-'.$AllWord[$Item['wid']]['title'] : '', 'text','readonly','',$WordHtml);

	$SelectBusinessList = array(array('0',$Fn_Secret->Config['LangVar']['SelectNull']));
	foreach($AllBusiness as $Val) {
		$SelectBusinessList[] = array($Val['id'], $Val['title']);
	}
	
	showsetting($Fn_Secret->Config['LangVar']['BusinessTitle'], array('bid', $SelectBusinessList), $Item['bid'], 'select');
		
	$FaceArray =  array_filter(explode("\n",$Fn_Secret->Config['PluginVar']['Faca']));
	$FaceHtml = '<div class="ImgList FaceImgList">';
	foreach($FaceArray as $Key => $Val) {
		$Class = strpos($Val,$Item['param']['face']) !== false ? ' class="Hover"' : '';
		$FaceHtml .= '<img src="'.$Val.'"'.$Class.'>';
	}
	$FaceHtml .= '</div>';
	showsetting($Fn_Secret->Config['LangVar']['FaceTitle'], 'face', $Item['param']['face'], 'text','','',$FaceHtml);
	
	/*$ImgsArray =  array_filter(explode(",",$Item['param']['imgs']));
	$ImgsHtml = '<div class="ImgList ImgsList">';
	foreach($ImgsArray as $Key => $Val) {
		$Class = strpos($Val,$Item['param']['imgs']) !== false ? ' class="Hover"' : '';
		$ImgsHtml .= '<img src="'.$Val.'"'.$Class.' style="height:auto;">';
	}
	$ImgsHtml .= '</div>';
	showsetting($Fn_Secret->Config['LangVar']['Imgs'], 'imgs', $Item['param']['imgs'] ? str_replace(',',"\n",$Item['param']['imgs']) : '', 'textarea','','',$ImgsHtml);*/

	echo '<tr><td colspan="2" class="td27 title" s="1">'.$Fn_Secret->Config['LangVar']['Imgs'].'</td></tr><tr class="noborder"><td class="vtop rowform" colspan="2"><div class="PublishFormImages"><div class="PhotoControl" id="ImgsPhotoControl"><i class="icon-plus">+</i><input type="file" class="Filedata" multiple="multiple" name="Filedata"/></div><div class="both"></div></div></td></tr>';
	
	showsetting($Fn_Secret->Config['LangVar']['Click'], 'click', $Item['click'], 'text');
	showsetting($Fn_Secret->Config['LangVar']['SupportCount'], 'support_count', $Item['support_count'], 'text');
	showsetting($Fn_Secret->Config['LangVar']['CommentCount'], 'comment_count', $Item['comment_count'], 'text');
	showsetting($Fn_Secret->Config['LangVar']['ShareCount'], 'share_count', $Item['share_count'], 'text');
	showsetting($Fn_Secret->Config['LangVar']['CommentSwitch'], 'comment_switch',$Item['param']['comment_switch'], 'radio');

	showsetting('UID', 'uid',$Item['uid'] ? $Item['uid'] : $_G['uid'], 'text');
	
	showsetting($Fn_Secret->Config['LangVar']['TopDateline'], 'topdateline',$Item['topdateline'] ? date('Y-m-d H:i',$Item['topdateline']) : '', 'calendar','','','',1);

	showsetting($Fn_Secret->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
	
	if($Item['dateline']){
	showsetting($Fn_Secret->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
	}

	showtablefooter(); /*dism _ taobao _ com*/
	showsubmit('DetailSubmit');
	showformfooter(); /*dism��taobao��com*/

	$UpLoadHtml  = '';
	if($Item['param']['imgs']){
		foreach(array_filter(explode(",",$Item['param']['imgs'])) as $Key => $Val) {
			$ImagesJsArray[] = '"'.$Val.'"';
		}
		$UpLoadHtml .= '
		var InputArray = new Array('.implode(',',$ImagesJsArray).');
		jQuery("#ImgsPhotoControl").AppUpload({InputName:"new_imgs",InputExist:true,InputArray:InputArray});';

	}else{
		$UpLoadHtml .= 'jQuery("#ImgsPhotoControl").AppUpload({InputName:"new_imgs"});';
	}
	
	echo '
	<style>.WordList span{cursor:pointer;border-radius:5px;display:inline-block;padding:2px 8px;border:1px solid #999;margin:0 7px 0 0;}.WordList span.Hover{background:'.$Fn_Secret->Config['PluginVar']['Color'].';color:#fff;border-color:'.$Fn_Secret->Config['PluginVar']['Color'].';}.ImgList img{margin:0 0 2px 2px;border:2px solid #fff;cursor:pointer;width:60px;height:60px;}.ImgList img.Hover{border-color:'.$Fn_Secret->Config['PluginVar']['Color'].';}.BgColorList span{margin:0 0 2px 2px;border:2px solid #fff;cursor:pointer;width:60px;height:60px;display:inline-block}.BgColorList span.Hover{border-color:'.$Fn_Secret->Config['PluginVar']['Color'].';}.PublishFormImages .PhotoControl{width:80px;line-height:80px;height:80px;font-size:28px;margin-right:10px;}.PublishFormImages .PhotoControl .Close{width:20px;height:20px;}</style><script type="text/javascript" src="static/js/calendar.js"></script>
	<script src="'.$Config['StaticPath'].'/js/jquery-1.9.1.min.js?{VERHASH}"></script>
	'.$UploadConfig['CssJsHtml'].'
	<script>
	var FN = jQuery.noConflict(); 
	'.$UpLoadHtml.'
	FN(document).on("click",".WordList span",function(e){
		var ID = FN(this).attr("Id");
		var Title = FN(this).attr("Title");
		FN("input[name=wid]").val(ID+"-"+Title);
		FN(this).addClass("Hover").siblings().removeClass("Hover");
	});
	FN(document).on("click",".ImgList img",function(e){
		var ParentsClass = FN(this).parents(".ImgList").attr("class");
		if(ParentsClass.indexOf("FaceImgList") >=0){
			FN("input[name=face]").val(FN(this).attr("src"));
		}
		FN(this).addClass("Hover").siblings().removeClass("Hover");
	});
	</script>
	';
}else{
	
	$Data['content'] = censor(addslashes(str_replace("\r\n","<br>",$_GET['content'])));
	$Data['wid'] = intval(reset(explode('-',$_GET['wid'])));
	$Data['bid'] = intval($_GET['bid']);
	$Data['click'] = intval($_GET['click']);
	$Data['support_count'] = intval($_GET['support_count']);
	$Data['comment_count'] = intval($_GET['comment_count']);
	$Data['share_count'] = intval($_GET['share_count']);
	$Data['topdateline'] = $_GET['topdateline'] ? strtotime($_GET['topdateline']) : '';
	$Data['display'] = intval($_GET['display']);
	$Data['uid'] = intval($_GET['uid']);
	$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
	$Data['username'] = addslashes(strip_tags($Member['username']));
	$FaceArray =  array_filter(explode("\r\n",$Fn_Secret->Config['PluginVar']['Faca']));
	$NameArray =  array_filter(explode("\r\n",$Fn_Secret->Config['PluginVar']['Name']));
	$Param['name'] = $_GET['name'] ? addslashes(strip_tags($_GET['name'])) : addslashes(strip_tags($NameArray[rand(0,count($NameArray)-1)]));
	$Param['face'] = $_GET['face'] ? addslashes(strip_tags($_GET['face'])) : addslashes(strip_tags($FaceArray[rand(0,count($FaceArray)-1)]));
	$Param['comment_switch'] = intval($_GET['comment_switch']);
	
	foreach($_GET['new_imgs'] as $Key => $Val) {
		$_GET['new_imgs'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
	}
	$Param['imgs'] = is_array($_GET['new_imgs']) && isset($_GET['new_imgs'])  ? implode(',',array_filter($_GET['new_imgs'])) : '';
	$Data['param'] = serialize($Param);
	if($Item){
		$Data['dateline'] = strtotime($_GET['dateline']);
		DB::update($Fn_Secret->TableSecret,$Data,'id = '.$SId);
		DB::update($Fn_Secret->TableSecretPost,array('wid'=>$Data['wid'],'bid'=>$Data['bid']),'sid = '.$SId);
		DB::update($Fn_Secret->TableSecretSupport,array('wid'=>$Data['wid'],'bid'=>$Data['bid']),'sid = '.$SId);
		if($Item['uid'] != $Data['uid']){
			DB::update($Fn_Secret->TableSecretPost,array('floor_host'=>0),'sid = '.$SId.' and uid ='.$Item['uid']);
			DB::update($Fn_Secret->TableSecretPost,array('floor_host'=>1),'sid = '.$SId.' and uid ='.$Data['uid']);
		}
	}else{
		$Data['dateline'] = time();
		$Data['display'] = 1;
		DB::insert($Fn_Secret->TableSecret,$Data);
	}
	cpmsg($Fn_Secret->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}
//From: Dism��taobao��com
?>