<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_wallet/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_wallet/Common.php');
require_once DISCUZ_ROOT . './source/plugin/fn_wallet/lib/wechat.lib.class.php';
$WechatClient = new WeChatClient($Fn_Wallet->Config[PluginVar][WxAppid], $Fn_Wallet->Config[PluginVar][WxSecret]);
$Model = addslashes($_GET['Model']);
if($_GET['code']){
	$Token = $WechatClient->getAccessTokenByCode($_GET['code']);
	if(!$Token['openid']){
		 showmessage($Fn_Wallet->Config['LangVar']['ToGrantAuthorizationErr'].($Token['errmsg'] ?'AccessToken:'. $Token['errmsg']:''),$Fn_Wallet->Config['Url']);
	}
	$SnsapiUserInfo = in_array('snsapi_userinfo', explode(',', $Token['scope'])) ? true : false;
	if(!$SnsapiUserInfo){
		$Info = $WechatClient->getUserInfoById($Token['openid'], 'zh_CN');
		if($Info['openid']){
			$UserInfo = $Info;
		}else{
			showmessage($Fn_Wallet->Config['LangVar']['ToGrantAuthorizationErr'].($Token['errmsg'] ?'AccessToken:'. $Token['errmsg']:''),$Fn_Wallet->Config['Url']);
		}
	}else{
		$UserInfo = $WechatClient->getUserInfoByAuth($Token['access_token'], $Token['openid']);
	}

	if($UserInfo['errcode']){
		showmessage($FnWxLogin->Config[LangVar][ToGrantAuthorizationErr].($UserInfo['errmsg'] ? ' UserInfo:'.$UserInfo['errmsg'] : ''),$Fn_Wallet->Config['Url']);
	}
	
	if(DB::update($Fn_Wallet->TableWallet,array('openid'=>$UserInfo['openid'],'unionid'=>$UserInfo['unionid']),'uid = '.intval($_G['uid']))){
		SetOauthCookie($UserInfo,$Token);
		dheader('Location:'.$Fn_Wallet->Config['Url']);
	}else{
		showmessage($FnWxLogin->Config[LangVar][ToGrantAuthorizationErr].($UserInfo['errmsg'] ? ' UserInfo:'.$UserInfo['errmsg'] : ''),$Fn_Wallet->Config['Url']);
	}
}else{
	showmessage('quickclear_noperm',$Fn_Wallet->Config['Url']);
}

function SetOauthCookie($UserInfo, $AccessToken){
    global $_G;
    dsetcookie('wxoauth', authcode($UserInfo['openid'] . "\t" . $UserInfo['unionid'] . "\t" . $_G['uid'] . "\t" . dhtmlspecialchars(diconv($UserInfo['nickname'], 'utf-8', CHARSET)) . "\t" . $UserInfo['headimgurl'] . "\t" . TIMESTAMP, 'ENCODE'), 7200, 1, true);
    dsetcookie('wxtoken', authcode($AccessToken['access_token'] . "\t" . $AccessToken['refresh_token'], 'ENCODE'), 7200, 1, true);
}
//From: Dism��taobao��com
?>