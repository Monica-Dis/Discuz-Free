$(function() {  
	FastClick.attach(document.body);  
});
window.addEventListener("DOMContentLoaded", function() {
	
});