<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$plugin_fn_wallet = DB::table('fn_wallet');
$plugin_fn_wallet_log = DB::table('fn_wallet_log');
$plugin_fn_wallet_withdrawals_log = DB::table('fn_wallet_withdrawals_log');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `$plugin_fn_wallet` (
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `alipay` varchar(100) NOT NULL,
  `wx` varchar(100) NOT NULL,
  `name` varchar(30) NOT NULL,
  `openid` varchar(255) NOT NULL,
  `unionid` varchar(255) NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `$plugin_fn_wallet_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `content` varchar(255) NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `plugin` varchar(100) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `$plugin_fn_wallet_withdrawals_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `fee` decimal(11,2) unsigned NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/fn_wallet/discuz_plugin_fn_wallet.xml');
@unlink(DISCUZ_ROOT . './source/plugin/fn_wallet/discuz_plugin_fn_wallet_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/fn_wallet/discuz_plugin_fn_wallet_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/fn_wallet/discuz_plugin_fn_wallet_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/fn_wallet/discuz_plugin_fn_wallet_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/fn_wallet/install.php');
$finish = TRUE;/*DISM-TAOBAO_COM*/
@unlink(DISCUZ_ROOT . './source/plugin/fn_wallet/discuz_plugin_fn_wallet.xml');
@unlink(DISCUZ_ROOT . './source/plugin/fn_wallet/discuz_plugin_fn_wallet_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/fn_wallet/discuz_plugin_fn_wallet_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/fn_wallet/discuz_plugin_fn_wallet_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/fn_wallet/discuz_plugin_fn_wallet_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/fn_wallet/install.php');
?>