<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class Fn_Wallet{
	public function __construct() {
		global $_G;
		loadcache('plugin');
		$this->Config['PluginVar'] = (array) $_G['cache']['plugin']['fn_wallet'];
		$this->Config['LangVar'] = lang('plugin/fn_wallet');
		$this->Config['Path'] = 'source/plugin/fn_wallet';
		$this->Config['StaticPath'] = $this->Config['Path'].'/static';
		$this->Config['Url'] = $_G['siteurl'].'plugin.php?id=fn_wallet';
		$this->Config['WithdrawalsUrl'] =  $this->Config['Url'].'&m=withdrawals';
		$this->Config['BalanceUrl'] =  $this->Config['Url'].'&m=balance';
		$this->Config['SetupUrl'] =  $this->Config['Url'].'&m=setup';
		$this->Config['AjaxUrl'] =  $this->Config['Url'].':Ajax';
		$this->TableWallet = 'fn_wallet';
		$this->TableWalletLog = 'fn_wallet_log';
		$this->TableWalletWithdrawalsLog = 'fn_wallet_withdrawals_log';
	}
	/* 资料 */
	public function GetUserInfo(){
		global $_G;
		$Uid = intval($_G['uid']);
		$FirstSql = 'SELECT M.username as musername,W.* FROM '.DB::table($this->TableWallet).' W LEFT JOIN '.DB::table('common_member').' M on M.uid = W.uid WHERE W.uid = '.$Uid;
		$UserInfo = DB::fetch_first($FirstSql);
		$UserInfo['money'] = $UserInfo['money'] ? $UserInfo['money'] : 0;
		return $UserInfo;
	}


	/* 明细And提现记录 */
	public function GetAjaxList($Value=null){
		global $_G;
		$Uid = intval($_G['uid']);
		$Value = in_array($Value,array('All','Income','Expenditure','Withdrawals')) ? $Value : 'All';
		$Results = array();
		if($Value == 'All'){//全部
			$FetchSql = 'SELECT W.* FROM '.DB::table($this->TableWalletLog).' W LEFT JOIN '.DB::table('common_member').' M on M.uid = W.uid WHERE W.uid = '.$Uid.' order by W.id desc';
			$Results = DB::fetch_all($FetchSql);
		}else if($Value == 'Income'){//收入
			$FetchSql = 'SELECT W.* FROM '.DB::table($this->TableWalletLog).' W LEFT JOIN '.DB::table('common_member').' M on M.uid = W.uid WHERE W.uid = '.$Uid.' AND W.type = 1 order by W.id desc';
			$Results = DB::fetch_all($FetchSql);
		}else if($Value == 'Expenditure'){//支出
			$FetchSql = 'SELECT W.* FROM '.DB::table($this->TableWalletLog).' W LEFT JOIN '.DB::table('common_member').' M on M.uid = W.uid WHERE W.uid = '.$Uid.' AND W.type = 2 order by W.id desc';
			$Results = DB::fetch_all($FetchSql);
		}else if($Value == 'Withdrawals'){//提现记录
			$FetchSql = 'SELECT L.* FROM '.DB::table($this->TableWalletWithdrawalsLog).' L LEFT JOIN '.DB::table('common_member').' M on M.uid = L.uid WHERE L.uid = '.$Uid.' order by id desc';
			$Results = DB::fetch_all($FetchSql);
		}
		
		foreach ($Results as $Key => $Val){
			if($Value == 'All' || $Value == 'Income' || $Value == 'Expenditure'){//明细
				$Results[$Key]['dateline'] = date('Y-m-d',$Val['dateline']);
				$Results[$Key]['type_html'] = $Val['type'] == 1 ? '+' : '-';
			}else if($Value == 'Withdrawals'){//提现记录
				$Results[$Key]['dateline'] = date('Y-m-d',$Val['dateline']);
				$Results[$Key]['state_text'] = $this->Config['LangVar']['AdminWithdrawalsState'][$Val['state']];
			}
		}
		return $Results;
	}
	
	/* 添加资料 */
	public function GetAjaxSetup($Post){
		global $_G;
		$Post = $this->StrToGBK($Post);
		$UserInfo = $this->GetUserInfo();
		$Data = array();
		if(!$Post['name']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NamePlaceholder']);
			return $Data;
		}

		if(!$Post['alipay'] && !$Post['wx']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AlipayWxPlaceholder']);
			return $Data;
		}

		$UpData['name'] = addslashes(strip_tags($Post['name']));
		$UpData['alipay'] = addslashes(strip_tags($Post['alipay']));
		$UpData['wx'] = addslashes(strip_tags($Post['wx']));
		
		if($UserInfo){
			if(DB::update($this->TableWallet,$UpData,'uid = '.$UserInfo['uid'])){
				$Data['Msg'] = urlencode($this->Config['LangVar']['SetupOk']);
				$Data['State'] = 200;
				return $Data;
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['SetupErr']);
				return $Data;
			}
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['SetupErr']);
			return $Data;
		}
	}
	/* 提现 */
	public function GetAjaxWithdrawals($Get){
		global $_G;
		$Uid = intval($_G['uid']);
		$UserInfo = $this->GetUserInfo();
		$Get['money'] = addslashes(strip_tags($Get['money']));

		if(!$this->Config['PluginVar']['Switch'] && $this->Config['PluginVar']['NoSwitchPrompt']){
			$Data['Msg'] = urlencode($this->Config['PluginVar']['NoSwitchPrompt']);
			return $Data;
		}
		
		if($this->Config['PluginVar']['AutomaticSwitch']){//微信内提现
			if(!$UserInfo['openid']){
				$Data['Msg'] = urlencode($this->Config['PluginVar']['WxPrompt']);
				return $Data;
			}
		}
		
		if(!$Get['money']){//没有填余额
			$Data['Msg'] = urlencode($this->Config['LangVar']['WithdrawalsMoneyErr']);
			return $Data;
		}

		if(!is_numeric($Get['money'])){//不是数字
			$Data['Msg'] = urlencode($this->Config['LangVar']['WithdrawalsMoneyIsNumErr']);
			return $Data;
		}
		
		if($this->Config['PluginVar']['WithdrawalsTime']){//时间限制
			$WalletWithdrawalsLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableWalletWithdrawalsLog).' WHERE uid = '.$Uid.' order by dateline desc');
			$WithdrawalsTime = strtotime("+".$this->Config['PluginVar']['WithdrawalsTime']." hours",$WalletWithdrawalsLog['dateline']);
			if(time() < $WithdrawalsTime){
				$TIME = '<span style=color:red>'.date('m-d H:i',$WithdrawalsTime).'</span>';
				$Data['Msg'] = urlencode(str_replace('{TIME}',$TIME,$this->Config['LangVar']['WithdrawalsTimeErr']));
				return $Data;
			}
		}

		if($Get['money'] < $this->Config['PluginVar']['WithdrawalsMinMoney']){//最低提现
			$Data['Msg'] = urlencode(str_replace('{num}',$this->Config['PluginVar']['WithdrawalsMinMoney'],$this->Config['LangVar']['WithdrawalsMinMoneyErr']));
			return $Data;
		}

		if($Get['money'] > $UserInfo['money']){//超出余额
			$Data['Msg'] = urlencode($this->Config['LangVar']['WithdrawalsMoneyNotEnoughErr']);
			return $Data;
		}

		if($Get['money'] > $this->Config['PluginVar']['WithdrawalsMaxMoney']){//最高提现
			$Data['Msg'] = urlencode(str_replace('{num}',$this->Config['PluginVar']['WithdrawalsMaxMoney'],$this->Config['LangVar']['WithdrawalsMaxMoneyErr']));
			return $Data;
		}
		$Fee = sprintf("%.2f",($Get['money'] * $this->Config['PluginVar']['Proceduresfee']) / 100);//手续费
		$Money = $Get['money'] - $Fee;
		$InsData['uid'] = $Uid;
		$InsData['username'] = addslashes(strip_tags($_G['username']));
		$InsData['fee'] = $Fee;
		$InsData['money'] = $Money;
		$InsData['dateline'] = time();
		$Id = DB::insert($this->TableWalletWithdrawalsLog,$InsData,true);
		if($Id && DB::query("UPDATE ".DB::table($this->TableWallet)." SET money = money-".$Get['money']." WHERE uid=".$Uid)){
			if($this->Config['PluginVar']['AutomaticSwitch']){//自动提现
				if($this->Config['PluginVar']['AutomaticExamineSwitch']){//自动提现需要审核
					$Data['State'] = 200;
					$Data['Msg'] = urlencode($this->Config['LangVar']['ManualWithdrawalsSuccess']);
					return $Data;
				}else{
					$FromXml = $this->Params($Money,$this->Config['LangVar']['WithdrawalsContentTo'],$UserInfo['openid'],$Id);
					$TradeNoId = reset(explode('fn',$FromXml['partner_trade_no']));
					if($FromXml['result_code'] == 'SUCCESS'){
						$WithdrawalsLogData['state'] = 1;
						$WithdrawalsLogData['transaction_id'] = addslashes(strip_tags($FromXml['payment_no']));
						$LogData['uid'] = $Uid;
						$LogData['content'] = addslashes(strip_tags($this->Config['LangVar']['WithdrawalsContentTo']));
						$LogData['money'] = $Get['money'];
						$LogData['type'] = 2;
						$LogData['plugin'] = 'fn_wallet';
						$LogData['dateline'] = time();
						DB::update($this->TableWalletWithdrawalsLog,$WithdrawalsLogData,'id = '.intval($TradeNoId));
						DB::insert($this->TableWalletLog,$LogData);
						$Data['State'] = 200;
						$Data['Msg'] = urlencode($this->Config['LangVar']['WithdrawalsSuccess']);
						return $Data;
					}else{
						$WithdrawalsLogData['content'] = diconv($FromXml['err_code_des'],'UTF-8',CHARSET);
						$WithdrawalsLogData['state'] = 2;
						if(DB::query("UPDATE ".DB::table($this->TableWallet)." SET money = money+".$Get['money']." WHERE uid=".$Uid) && DB::update($this->TableWalletWithdrawalsLog,$WithdrawalsLogData,'id = '.$Id)){
							$Data['Msg'] = urlencode(diconv($FromXml['err_code_des'],'UTF-8',CHARSET));
							return $Data;
						}
					}
				}
			}else{//手动提现
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['ManualWithdrawalsSuccess']);
				return $Data;
			}
			
		}else{
			DB::delete($this->TableWalletWithdrawalsLog,'id ='.$Id);
			$Data['Msg'] = urlencode($this->Config['LangVar']['WithdrawalsFail']);
			return $Data;
		}
	}
	
	/**
	 * 创建支付数组
	 * $Amount=>金额
	 * $Desc=>描述
	 * $Openid=>用户Openid
	 * $TradeNo=>商户订单号
	**/

	public function Params($Amount,$Desc,$Openid,$TradeNo){
		global $_G;
		$Url = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';
		$Params["mch_appid"]        = $this->Config['PluginVar']['WxAppid'];   //公众账号appid
		$Params["mchid"]            = $this->Config['PluginVar']['WxMchid'];   //商户号 微信支付平台账号
		$Params["nonce_str"]        = $this->getNonceStr();   //随机字符串
		$Params["partner_trade_no"] = $TradeNo.'fn'.time().mt_rand(1,99);           //商户订单号
		$Params["amount"]           = $Amount * 100;          //金额
		$Params["desc"]             = diconv($Desc,CHARSET,'UTF-8');            //企业付款描述
		$Params["openid"]           = $Openid;          //用户openid
		$Params["check_name"]       = 'NO_CHECK';       //不检验用户姓名
		$Params['spbill_create_ip'] = $_G['clientip'];   //获取IP
		$Params["sign"] = $this->MakeSign($Params);//签名
		$Xml = $this->ToXml($Params);
		$Data = $this->FromXml($this->CurlPostSsl($Url,$this->ToXml($Params)));
		return $Data;
	}

	/**
	 * 输出xml字符
	 * @throws WxPayException
	**/
	private function ToXml($Array){
    	$xml = "<xml>";
		foreach ($Array as $key=>$val){
    		if (is_numeric($val)){
    			$xml.="<".$key.">".$val."</".$key.">";
    		}else{
    			$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
    		}
        }
		$xml.="</xml>";
		return $xml; 
	}

	/**
     * 将xml转为array
     * @param string $xml
     */
	private function FromXml($xml){
        $FromXmlData = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);		
		return $FromXmlData;
	}
	
	/**
	 * 
	 * 产生随机字符串，不长于32位
	 * @param int $length
	 * @return 产生的随机字符串
	 */
	private static function getNonceStr($length = 32) {
		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";  
		$str ="";
		for ( $i = 0; $i < $length; $i++ )  {  
			$str .= substr($chars, mt_rand(0, strlen($chars)-1), 1);  
		} 
		return $str;
	}

	/**
	 * 生成签名
	 * @return 签名，本函数不覆盖sign成员变量，如要设置签名需要调用SetSign方法赋值
	 */
	private function MakeSign($Obj){
		foreach($Obj as $key => $value){
			$Parameters[$key] = $value;
		}
		//签名步骤一：按字典序排序参数
		ksort($Parameters);
		$string = $this->formatBizQueryParaMap($Parameters);
		//签名步骤二：在string后加入KEY
		$string = $string . "&key=".$this->Config['PluginVar']['WxKey'];
		//签名步骤三：MD5加密
		$string = md5($string);
		//签名步骤四：所有字符转为大写
		$result = strtoupper($string);
		return $result;
	}

	/**
     *  作用：格式化参数，签名过程需要使用
    */
    private function formatBizQueryParaMap($Parameters) {
        $buff = "";
		foreach ($Parameters as $k => $v)
		{
			if($k != "sign" && $v != "" && !is_array($v)){
				$buff .= $k . "=" . $v . "&";
			}
		}
		
		$buff = trim($buff, "&");
		return $buff;
    }
	/**
     *  作用：Post证书
    */
    private function CurlPostSsl($Url, $Xml, $Second=30){
		$Ch = curl_init();
		//超时时间
		curl_setopt($Ch,CURLOPT_TIMEOUT,$Second);
		//将curl_exec()获取的信息以文件流的形式返回，而不是直接输出。
		curl_setopt($Ch,CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($Ch,CURLOPT_URL,$Url);
		//根据curl版本有不同默认值 设置一下放心
		curl_setopt($Ch,CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($Ch,CURLOPT_SSL_VERIFYHOST,false);
		//以下两种方式需选择一种 双向检测证书
		/******* 此处必须为文件服务器根目录绝对路径 不可使用变量代替*********/
		curl_setopt($ch,CURLOPT_SSLCERTTYPE,'PEM');
		curl_setopt($Ch,CURLOPT_SSLCERT,DISCUZ_ROOT . 'source'.DIRECTORY_SEPARATOR.'plugin'.DIRECTORY_SEPARATOR.'fn_wallet'.DIRECTORY_SEPARATOR.'cash'.DIRECTORY_SEPARATOR.'apiclient_cert.pem');
		curl_setopt($ch,CURLOPT_SSLKEYTYPE,'PEM');
		curl_setopt($Ch,CURLOPT_SSLKEY,DISCUZ_ROOT . 'source'.DIRECTORY_SEPARATOR.'plugin'.DIRECTORY_SEPARATOR.'fn_wallet'.DIRECTORY_SEPARATOR.'cash'.DIRECTORY_SEPARATOR.'apiclient_key.pem');

		curl_setopt($Ch,CURLOPT_POST, 1);
		curl_setopt($Ch,CURLOPT_POSTFIELDS,$Xml);
		$Data = curl_exec($Ch);
		if($Data){
			curl_close($Ch);
			return $Data;
		}else {
			$Error = curl_errno($Ch);
			"call faild, errorCode:$Error\n";
			curl_close($Ch);
			return false;
		}
	}

	/* 查询单个 */
	public function QueryOne($TableName,$Id,$Where){
		$FirstSql = 'SELECT * FROM '.DB::table($TableName).' where id = '.$Id.' '.$Where;
		return DB::fetch_first($FirstSql);	
	}
	/* 
	修改表的数据
	table_name=>
	ids=>id
	fields=>字段
    val=>值
	*/
	public function EditFields($TableName,$Ids,$Fields,$Val){
		if(is_array($Ids)){
			$Ids = implode(',',$Ids);
		}else{
			$Ids = $Ids;
		}
		$UpData[$Fields] = $Val;
		if(DB::update($TableName,$UpData,'id in( '.$Ids.' )')){
			return true;
		}else{
			return false;
		}
	}
	
	/* 编码转换 */
	public static function StrToGBK($string,$ajax_status){
		global $_G;
		if($_G['charset'] == 'gbk'){
			if($ajax_status == true){
				if(is_array($string)){
					return eval('return '.iconv("GB2312","UTF-8//IGNORE",var_export($string,true).';')); 
				}else{
					return iconv('GB2312', 'UTF-8', $string);
				}
			}else{
				if(is_array($string)){
					$StringArr = array();
					foreach($string as $key=>$value){
						$encode = mb_detect_encoding($value, array('UTF-8','GB2312','GBK'));
						if($encode == 'UTF-8'){
							$StringArr[$key] = iconv('UTF-8','GB2312//IGNORE',$value);
						}else if($encode == 'EUC-CN'){
							$StringArr[$key] = $value;
						}
					}
					return $StringArr;
				}else{
					$encode = mb_detect_encoding($string, array('UTF-8','GB2312','GBK'));
					if($encode == 'UTF-8'){
						return iconv('UTF-8','GB2312//IGNORE', $string);
					}else if($encode == 'EUC-CN'){
						return $string;
					}
				}
			}
		}else{
			return $string;
		}
        
    }

	public function HexToRgb($colour){ 
		if($colour[0] == '#'){ 
			$colour = substr( $colour, 1 ); 
		} 
		if(strlen( $colour ) == 6){ 
			list( $r, $g, $b ) = array( $colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5] ); 
		}elseif(strlen($colour) == 3){ 
			list( $r, $g, $b ) = array( $colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2] ); 
		}else{ 
			return false; 
		} 
		$r = hexdec( $r ); 
		$g = hexdec( $g ); 
		$b = hexdec( $b ); 
		return array( 'red' => $r, 'green' => $g, 'blue' => $b ); 
	} 
}
//From: Dism·taobao·com
?>