<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class Fn_Clock{
	public function __construct() {
		global $_G,$plugin;
		loadcache('plugin');
		$this->Config['PluginVar'] = (array) $_G['cache']['plugin']['fn_clock'];
		$this->Config['LangVar'] = lang('plugin/fn_clock');
		$this->Config['Path'] = 'source/plugin/fn_clock';
		$this->Config['StaticPath'] = $this->Config['Path'].'/static';
		$this->Config['Url'] = $_G['siteurl'].'plugin.php?id=fn_clock';
		$this->Config['UserUrl'] = $this->Config['Url'].'&m=user';
		$this->Config['RuleUrl'] = $this->Config['Url'].'&m=rule';
		$this->Config['PayOkUrl'] = $this->Config['Url'].'&m=payok';
		$this->Config['MagUrl'] = $this->Config['Url'].'&m=mag';
		$this->Config['QfUrl'] = $this->Config['Url'].'&m=qf';
		$this->Config['WalletUrl'] = $_G['siteurl'].'plugin.php?id=fn_wallet';
		$this->Config['RankingUrl'] =  $this->Config['Url'].'&m=ranking';
		$this->Config['ShareUrl'] =  $this->Config['Url'].'&m=share&userid='.$_G['uid'];
		$this->Config['AjaxUrl'] =  'plugin.php?id=fn_clock:Ajax';
		$this->Config['WxShare'] = array(
			'WxTitle' => $this->Config['PluginVar']['WxTitle'],
			'WxDes' => $this->Config['PluginVar']['WxDes'],
			'WxImg' => strpos($this->Config['PluginVar']['WxImg'],'http') !== false ? $this->Config['PluginVar']['WxImg'] : $_G['siteurl'].$this->Config['PluginVar']['WxImg'],
			'WxUrl' => $this->Config['Url']
		);
		$this->TodayStartTime = strtotime(date('Y-m-d '.$this->Config['PluginVar']['StartTime']));
		$this->TodayEndTime = strtotime(date('Y-m-d '.$this->Config['PluginVar']['EndTime']));
		$this->TomorrowStartTime = strtotime('+1day',$this->TodayStartTime);
		$this->TomorrowEndTime = strtotime('+1day',$this->TodayEndTime);
		$this->TomorrowSetTime = time() > $this->TodayEndTime ? $this->TomorrowEndTime : $this->TodayEndTime;//明日日打卡最迟时间
		$this->TodaySetTime = time() < $this->TodayStartTime ? strtotime('-1day',$this->TodayEndTime) : $this->TodayEndTime;//TodaySetTime:今日打卡最迟时间

		$this->TodayJudge = time() > strtotime(date('Y-m-d 00:00:00',$this->TomorrowSetTime)) && time() < $this->TodayStartTime ? true : 
		false;

		$this->TomorrowJudge = time() > strtotime(date('Y-m-d 00:00:00',$this->TomorrowSetTime)) && time() < $this->TodayEndTime ? true : 
		false;

		$this->CountDownTime = strtotime(date('Y-m-d '.$this->Config['PluginVar']['StartTime'],$this->TomorrowSetTime));//倒计时
		
		//赞助商
		$this->Sponsor = $this->Config['PluginVar']['SponsorEndTime'] && strtotime($this->Config['PluginVar']['SponsorEndTime'].' '.$this->Config['PluginVar']['EndTime']) > time() ? true : false;

		//奖励规则
		$this->Reward = $this->Config['PluginVar']['RewardEndTime'] && strtotime($this->Config['PluginVar']['RewardEndTime'].' '.$this->Config['PluginVar']['EndTime']) > time() ? true : false;
		
		$this->HB = false;

		$this->TableClock = 'fn_clock';
		$this->TableClockLog = 'fn_clock_log';
		$this->TableClockPayLog = 'fn_clock_pay_log';
		$this->TableClockTimeLog = 'fn_clock_time_log';
		$this->TableClockUid = 'fn_clock_uid';
		$this->TableClockShare = 'fn_clock_share';

		if($this->Config['PluginVar']['AppType'] != '2' && $this->Config['PluginVar']['AppType'] != '1'){//不是千帆、马甲
			if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_wallet/wallet.class.php')){
				@include DISCUZ_ROOT.'./source/plugin/fn_wallet/wallet.class.php';
			}
		}

		if($this->Config['PluginVar']['AppType'] == '1' && !file_exists(DISCUZ_ROOT.'/source/plugin/fn_clock/weixin/fromversion.txt')){//1.7以下版本更改瓜分金额状态
			$TodayEndTime = strtotime(date('Y-m-d '.$this->Config['PluginVar']['EndTime']));
			$Time = time() < $TodayEndTime ? strtotime('-1day',$TodayEndTime) : $TodayEndTime;
			DB::update($this->TableClock,array('refund_state'=>1),'set_time <='.$Time);
			file_put_contents(DISCUZ_ROOT.'/source/plugin/fn_clock/weixin/fromversion.txt',$Time);
		}
	}
	/* 用户资料 */
	public function GetUserInfo($Uid){
		global $_G;
		$Uid = intval($Uid);
		$UserInfo = array();
		if($Uid){
			$FirstSql = 'SELECT M.*,C.extcredits1,C.extcredits2,C.extcredits3,C.extcredits4,C.extcredits5,C.extcredits6,C.extcredits7,C.extcredits8 FROM '.DB::table('common_member').' M LEFT JOIN '.DB::table('common_member_count').' C on C.uid = M.uid  where M.uid = '.$Uid;
			$UserInfo = DB::fetch_first($FirstSql);

			$UserInfo['InvestmentMoneyCount'] = DB::result_first('SELECT sum(money) FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' And display = 1');
			$UserInfo['InvestmentMoneyCount'] = $UserInfo['InvestmentMoneyCount'] ? $UserInfo['InvestmentMoneyCount'] : 0;
			
			if($this->Config['PluginVar']['UserMoneySwitch']){//是否包括本金
				$UserInfo['IncomeMoneyCount'] = DB::result_first('SELECT sum(income_money) FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' And display = 1');
				$UserInfo['IncomeMoneyCount'] = $UserInfo['IncomeMoneyCount'] ? $UserInfo['IncomeMoneyCount'] : 0;
			}else{
				$IncomeMoneyCount = DB::result_first('SELECT sum(income_money) FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' And display = 1');
				
				$MoneyCount = DB::result_first('SELECT sum(money) FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' And display = 1 and state = 1');
				$UserInfo['IncomeMoneyCount'] = $IncomeMoneyCount - $MoneyCount;
				$UserInfo['IncomeMoneyCount'] = $UserInfo['IncomeMoneyCount'] > 0 ? $UserInfo['IncomeMoneyCount'] : 0;
			}
			
			$UserInfo['ClockCount'] = DB::result_first('SELECT count(*) FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' And display = 1 and state = 1');
			$UserInfo['ClockCount'] = $UserInfo['ClockCount'] ? $UserInfo['ClockCount'] : 0;

			/* 支付掉单重新查询 */
			$this->GetCheckPubid();
			/* 支付掉单重新查询 End */

			$UserInfo['Clock'] = DB::fetch_first('SELECT * FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' and set_time = '.$this->TodayEndTime.' and display = 1 and state = 0 order by dateline desc');

			if(!$UserInfo['Clock']){//打卡完，是否继续打卡
				$UserInfo['Clock'] = DB::fetch_first('SELECT * FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' and set_time = '. $this->TomorrowEndTime.' and display = 1 and state = 0 order by dateline desc');
				if($UserInfo['Clock']){
					$UserInfo['Clock']['Continuity'] = true;
					$this->CountDownTime =strtotime(date('Y-m-d '.$this->Config['PluginVar']['StartTime'],$UserInfo['Clock']['set_time']));
				}
			}
			$UserInfo['MyClock'] = DB::fetch_first('SELECT * FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' and set_time = '.$this->TodaySetTime.' And display = 1 order by dateline desc');
			$HBMoney = 0;
			if($this->Config['PluginVar']['AppType'] == '2'){//千帆、写入钱包
				$UserClockList = DB::fetch_all('SELECT * FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' And display = 1  order by dateline desc limit 0,30');
				$Ids = array();
	
				foreach ($UserClockList as $Key => $Val){
					if($Val['state']  == 1 && $Val['income_money'] != 0.00 && !$Val['refund_state']){
						if($this->QFAddBalance($Uid,$Val['income_money'])){
							$Ids[] = $Val['id'];
							$HBMoney = $HBMoney+$Val['income_money'];
							$this->HB = true;
						}
					}else if($Val['state']  == 2 && $Val['refund_state'] == 2){
						if($this->QFAddBalance($Uid,$Val['money'])){
							$Ids[] = $Val['id'];
							$HBMoney = $HBMoney+$Val['money'];
							$this->HB = true;
						}
					}
				}
				if($Ids){
					if(DB::update($this->TableClock,array('refund_state'=>1),'id IN('.implode(',',$Ids).')')){
						unset($Ids);
					}
				}			
			}else if($this->Config['PluginVar']['AppType'] == '1'){//马甲、入钱包
				$UserClockList = DB::fetch_all('SELECT * FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' And display = 1 order by dateline desc limit 0,30');
				$Ids = array();
				$HBMoney = 0;
				foreach ($UserClockList as $Key => $Val){
					if($Val['state']  == 1 && $Val['income_money'] != 0.00 && !$Val['refund_state']){
						if($this->GetMagAccountTransfer($Uid,$Val['income_money'],$this->Config['LangVar']['Text66'])){
							$Ids[] = $Val['id'];
							$HBMoney = $HBMoney+$Val['income_money'];
							$this->HB = true;
						}
					}else if($Val['state']  == 2 && $Val['refund_state'] == 2){
						if($this->GetMagAccountTransfer($Uid,$Val['money'],$this->Config['LangVar']['Text42'])){
							$Ids[] = $Val['id'];
							$HBMoney = $HBMoney+$Val['money'];
							$this->HB = true;
						}
					}
				}
				if($Ids){
					if(DB::update($this->TableClock,array('refund_state'=>1),'id IN('.implode(',',$Ids).')')){
						unset($Ids);
					}
				}

				//把钱包的余额，写入马甲钱包
				if($this->Config['PluginVar']['NewSwitch']){
					$MyWallet = DB::fetch_first('SELECT * FROM '.DB::table('fn_wallet').' where uid = '.$Uid);
					if(floatval($MyWallet['money']) != 0){
						if($this->GetMagAccountTransfer($Uid,$MyWallet['money'],$this->Config['LangVar']['Text89'])){
							$Data['uid'] = intval($Uid);
							$Data['content'] = addslashes(strip_tags($this->Config['LangVar']['Text89']));
							$Data['money'] = addslashes(strip_tags($MyWallet['money']));
							$Data['type'] = 2;
							$Data['plugin'] = 'fn_clock';
							$Data['dateline'] = time();
							if(DB::insert('fn_wallet_log',$Data) && DB::query("UPDATE ".DB::table('fn_wallet')." SET money = money - ".$MyWallet['money']." WHERE uid=".$Uid)){
								$HBMoney = $HBMoney+$MyWallet['money'];
								$this->HB = true;
							}
							
						}
					}
				}
			}else{
				FnWallet::WalletFetchByUid($Uid);//创建钱包
			}
			$UserInfo['HBMoney'] = $HBMoney;
		}
		return $UserInfo;
	}

	/* 战绩明细 */
	public function GetUserClockList(){
		global $_G;
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableClock).' where uid = '.intval($_G['uid']).' and display = 1 order by set_time desc';
		return DB::fetch_all($FetchSql);//返回数据
	}
	/* 今日瓜分金额 */
	public function GetTodayMoneyCount(){
		$FetchSql = 'SELECT sum(money) FROM '.DB::table($this->TableClock).' where set_time = '.$this->TodayEndTime.' and display = 1';
		$TodayMoneyCount = DB::result_first($FetchSql);//返回总数
		$TodayMoneyCount =  $TodayMoneyCount ? $TodayMoneyCount : 0;
		if($this->GetTodayUserCount() && $this->Reward){
			$TodayMoneyCount = $TodayMoneyCount + $this->GetFreeRule($this->GetTodayUserCount());
		}
		return $TodayMoneyCount;
	}
	/* 今日参加打卡总人数 */
	public function GetTodayUserCount(){
		$FetchSql = 'SELECT count(*) FROM '.DB::table($this->TableClock).' where set_time = '.$this->TodayEndTime.' and display = 1';
		$TodayUserCount = DB::result_first($FetchSql);//返回总数
		return $TodayUserCount ? $TodayUserCount : 0;
	}
	/* 明日瓜分金额 */
	public function GetTomorrowMoneyCount(){
		$FetchSql = 'SELECT sum(money) FROM '.DB::table($this->TableClock).' where set_time = '.$this->TomorrowSetTime.' and display = 1';
		$TomorrowMoneyCount = DB::result_first($FetchSql);//返回总数
		$TomorrowMoneyCount =  $TomorrowMoneyCount ? $TomorrowMoneyCount : 0;
		if($this->GetTomorrowUserCount() && $this->Reward){
			$TomorrowMoneyCount = $TomorrowMoneyCount + $this->GetFreeRule($this->GetTomorrowUserCount());
		}
		return $TomorrowMoneyCount;
		
	}
	/* 明日参加打卡总人数 */
	public function GetTomorrowUserCount(){
		$FetchSql = 'SELECT count(*) FROM '.DB::table($this->TableClock).' where set_time = '.$this->TomorrowSetTime.' and display = 1';
		$TomorrowUserCount = DB::result_first($FetchSql);//返回总数
		return $TomorrowUserCount ? $TomorrowUserCount : 0;
	}
	/* 明日参加打卡列表 */
	public function GetTomorrowUserList(){
		$FetchSql = 'SELECT uid FROM '.DB::table($this->TableClock).' where set_time = '.$this->TomorrowSetTime.' and display = 1 GROUP BY uid order by dateline desc LIMIT 0,10';
		return DB::fetch_all($FetchSql);//返回数据
	}
	/* 今日打卡成功总数 */
	public function GetClockSuccessCount(){
		$FirstSql = 'SELECT count(*) FROM '.DB::table($this->TableClock).' where set_time = '.$this->TodaySetTime.' AND display = 1 and state = 1';
		return DB::result_first($FirstSql);
	}

	/* 今日打卡失败总数 */
	public function GetClockFailCount(){
		$FirstSql = 'SELECT count(*) FROM '.DB::table($this->TableClock).' where set_time ='.$this->TodaySetTime.' AND display = 1 and state = 2';
		return DB::result_first($FirstSql);
	}

	/* 今日早起之星 */
	public function GetTodayMorningFirst(){
		$FirstSql = 'SELECT M.username as musername,C.* FROM '.DB::table($this->TableClock).' C LEFT JOIN '.DB::table('common_member').' M on M.uid = C.uid where C.set_time = '.$this->TodaySetTime.'  AND C.display = 1 and C.state = 1 order by C.clock_time ASC';
		return DB::fetch_first($FirstSql);
	}

	/* 今日手气之星 */
	public function GetLuckFirst(){
		$FirstSql = 'SELECT M.username as musername,C.* FROM '.DB::table($this->TableClock).' C LEFT JOIN '.DB::table('common_member').' M on M.uid = C.uid where C.set_time = '.$this->TodaySetTime.'  AND C.display = 1 and C.state = 1 and C.income_money != \'0.00\' order by C.income_money DESC';
		return DB::fetch_first($FirstSql);
	}

	/* 今日毅力之星 */
	public function GetTodayWillFirst(){
		if($this->Config['PluginVar']['WillSwitch']){
			$FirstSql = 'SELECT M.username as musername,C.*,count(C.id) as count FROM '.DB::table($this->TableClock).' C LEFT JOIN '.DB::table('common_member').' M on M.uid = C.uid where C.display = 1 and C.state = 1 GROUP BY uid order by count DESC';
		}else{
			$FirstSql = 'SELECT M.username as musername,C.* FROM '.DB::table($this->TableClock).' C LEFT JOIN '.DB::table('common_member').' M on M.uid = C.uid where C.set_time = '.$this->TodaySetTime.'  AND C.display = 1 and C.state = 1 and C.display_even = 1 order by C.count DESC';
		}
		return DB::fetch_first($FirstSql);
	}
	public function GetShareFirst(){
		global $_G;
		if($_G['uid']){
			$FirstSql = 'SELECT * FROM '.DB::table($this->TableClockShare).' where uid = '.intval($_G['uid']).' order by id DESC';
			return DB::fetch_first($FirstSql);
		}
	}
	/* 排行榜 */
	public function GetAjaxRangKing($Value=null){
		global $_G;
		if($this->Config['PluginVar']['MillionaireNavSwitch']){
			$Value = in_array($Value,array('Morning','Luck','Will','Millionaire')) ? $Value : 'Millionaire';
		}else{
			$Value = in_array($Value,array('Morning','Luck','Will','Millionaire')) ? $Value : 'Luck';
		}
		$Limit = $this->Config['PluginVar']['RanKingNum'] ? $this->Config['PluginVar']['RanKingNum'] : 30;
		$Results = array();
		if($Value == 'Morning'){//早起之星
			$Results = DB::fetch_all('SELECT M.username as musername,C.* FROM '.DB::table($this->TableClock).' C LEFT JOIN '.DB::table('common_member').' M on M.uid = C.uid where C.set_time = '.$this->TodaySetTime.'  AND C.display = 1 and C.state = 1 order by C.clock_time ASC limit 0,'.$Limit);
		}else if($Value == 'Luck'){//幸运之星
			$Results = DB::fetch_all('SELECT M.username as musername,C.* FROM '.DB::table($this->TableClock).' C LEFT JOIN '.DB::table('common_member').' M on M.uid = C.uid where C.set_time = '.$this->TodaySetTime.'  AND C.display = 1 and C.state = 1 and C.income_money != \'0.00\' order by C.income_money DESC limit 0,'.$Limit);
		}else if($Value == 'Will'){//毅力之星
			if($this->Config['PluginVar']['WillSwitch']){
				$Results = DB::fetch_all('SELECT M.username as musername,C.*,count(id) as count FROM '.DB::table($this->TableClock).' C LEFT JOIN '.DB::table('common_member').' M on M.uid = C.uid where C.display = 1 and C.state = 1 GROUP BY uid order by count DESC limit 0,'.$Limit);
			}else{
				$Results = DB::fetch_all('SELECT M.username as musername,C.* FROM '.DB::table($this->TableClock).' C LEFT JOIN '.DB::table('common_member').' M on M.uid = C.uid where C.set_time = '.$this->TodaySetTime.'  AND C.display = 1 and C.state = 1 and C.display_even = 1 order by C.count DESC limit 0,'.$Limit);
			}
		}else if($Value == 'Millionaire'){//土豪榜
			if($this->Config['PluginVar']['MillionaireMoneySwitch']){
				$Results = DB::fetch_all('SELECT M.username as musername,sum(C.income_money) as sum,C.* FROM '.DB::table($this->TableClock).' C LEFT JOIN '.DB::table('common_member').' M on M.uid = C.uid where C.display = 1 and C.state = 1 GROUP BY uid ORDER BY sum DESC LIMIT 0,'.$Limit);
			}else{
				$Results = DB::fetch_all('SELECT M.username as musername,sum(C.income_money) - sum(C.money) as sum,C.* FROM '.DB::table($this->TableClock).' C LEFT JOIN '.DB::table('common_member').' M on M.uid = C.uid where C.display = 1 and C.state = 1 GROUP BY uid ORDER BY sum DESC LIMIT 0,'.$Limit);
			}
		}
		foreach ($Results as $Key => $Val){
			if($Value == 'Morning'){//早起之星
				$Text = date('H:i:s',$Val['clock_time']).'<em>'.$this->Config['LangVar']['Text13'].'</em>';
			}else if($Value == 'Luck'){//幸运之星
				$Text = $Val['income_money'].'<em>'.$this->Config['LangVar']['Yuan'].'</em>';
			}else if($Value == 'Will'){//毅力之星
				if($this->Config['PluginVar']['WillSwitch']){
					$Text = $Val['count'] ? str_replace('{Num}','<em>'.$Val['count'].'</em>',$this->Config['LangVar']['Text102']) : str_replace('{Num}','<em>0</em>',$this->Config['LangVar']['Text102']);
				}else{
					$Text = $Val['count'] ? str_replace('{Num}','<em>'.$Val['count'].'</em>',$this->Config['LangVar']['Text16']) : str_replace('{Num}','<em>0</em>',$this->Config['LangVar']['Text16']);
				}
				
			}else if($Value == 'Millionaire'){//土豪榜
				$Text = $Val['sum'].'<em>'.$this->Config['LangVar']['Yuan'].'</em>';
			}
			$Results[$Key]['text'] = $Text;
		}
		return $Results;
	}
	/* 虚拟数据 */
	public function GetFictitious(){
		global $_G;
		$Uids = array_filter(explode("\n",$this->Config['PluginVar']['FictitiousUids']));
		if($Uids && !file_exists(DISCUZ_ROOT.'/source/plugin/fn_clock/weixin/'.date('Ymd',$this->TomorrowEndTime).'.txt') && $this->Config['PluginVar']['FictitiousTime'] && time() > strtotime(date('Y-m-d '.$this->Config['PluginVar']['FictitiousTime']))){
			if(count($Uids) > 1000){
				$Count = rand(count($Uids) - 100,count($Uids));
			}else if(count($Uids) > 500){
				$Count = rand(count($Uids) - 50,count($Uids));
			}else if(count($Uids) > 200){
				$Count = rand(count($Uids) - 20,count($Uids));
			}else if(count($Uids) > 100){
				$Count = rand(count($Uids) - 10,count($Uids));
			}else if(count($Uids) > 50){
				$Count = rand(count($Uids) - 5,count($Uids));
			}else{
				$Count = count($Uids);
			}
			$FictitiousRate = floor($Count * ($this->Config['PluginVar']['FictitiousRate'] / 100));
			$FictitiousSql = "insert INTO ".DB::table($this->TableClock)." (display_even,count,uid,username,set_time,dateline,display,money,refund_state,state,clock_time,fictitious) values";

			for($i = 0;$i < $Count;$i++){
				$UidArray = array_filter(explode("=",$Uids[$i]));
				$ClockTime = '';
				$State = 2;
				if($i < $FictitiousRate){
					$ClockTime = $this->TomorrowEndTime - rand(100,1000);
					$State = 1;
				}
				$FictitiousSql .= "('0','0','".intval($UidArray['0'])."','".addslashes(strip_tags($UidArray[1]))."','".$this->TomorrowEndTime."','".time()."','1','".addslashes(strip_tags($this->Config['PluginVar']['Money']))."','1','".$State."','".$ClockTime."','1'),";
			}
			$FictitiousSql = substr($FictitiousSql,0,strlen($FictitiousSql)-1);
			if(DB::query($FictitiousSql)){
				file_put_contents(DISCUZ_ROOT.'/source/plugin/fn_clock/weixin/'.date('Ymd',$this->TomorrowEndTime).'.txt',date('Ymd',$this->TomorrowEndTime));
			}
		}
	}
	/* 分享 */
	public function GetAjaxShare($Type){
		global $_G;
		$InsData['uid'] = intval($_G['uid']);
		$InsData['username'] = addslashes(strip_tags($_G['username']));
		$InsData['type'] = addslashes(strip_tags($Type));
		$InsData['url'] = addslashes(strip_tags(dreferer()));
		$InsData['dateline'] =  time();
		if(strpos($_SERVER["HTTP_USER_AGENT"],'QianFan') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'MicroMessenger') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme') !== false){
			if(DB::insert($this->TableClockShare,$InsData)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['Text96']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['Text97']);
			}
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['Text97']);
		}
		return $Data;
	}
	/* 检测 */
	public function GetAjaxCheckClock($Get){
		global $_G;
		$Uid = intval($_G[uid]);
		$Data = array();
		$Get = $this->StrToGBK($Get);
		if(!$_G[uid]){
			if(strpos($_SERVER["HTTP_USER_AGENT"],'QianFan') !== false){
				$ToKen = json_decode($this->GetActionAuthCode($_COOKIE['wap_token'],$this->Config['PluginVar']['qf_secret']),true);
				if($ToKen['uid']){
					require_once libfile('function/member');
					$Member = getuserbyuid($ToKen['uid'],1);
					$CookieTime = 1296000;
					setloginstatus($Member, $CookieTime);
				}else{
					$Data['State'] = 201;
					return $Data;	
				}
			}else if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX') !== false){
				$UserInfo = $this->GetMagUserInfo();
				if($UserInfo['user_id']){
					require_once libfile('function/member');
					$Member = getuserbyuid($UserInfo['user_id'],1);
					$CookieTime = 1296000;
					setloginstatus($Member, $CookieTime);
				}else{
					$Data['State'] = 201;
					return $Data;	
				}
			}else{
				$Data['State'] = 201;
				return $Data;	
			}
		}

		if(in_array($_G['uid'],array_filter(explode(",",$this->Config['PluginVar']['ProhibitUids'])))){
			$Data['Msg'] = urlencode($this->Config['LangVar']['Text108']);
			return $Data;
		}
		/* 支付掉单重新查询 */
		if($this->GetCheckPubid()){
			$Data['Msg'] = urlencode($this->Config['LangVar']['Text73']);
			$Data['State'] = 202;
			return $Data;
		};
		/* 支付掉单重新查询 End */
		
		if(time() > strtotime(date('Y-m-d 23:50:00')) && time() < strtotime(date('Y-m-d 23:59:59'))){
			$Data['Msg'] = urlencode($this->Config['LangVar']['Text85']);
			return $Data;
		}

		if(time() > strtotime(date('Y-m-d '.$this->Config['PluginVar']['ClockProhibitStartTime'])) && time() < strtotime(date('Y-m-d '.$this->Config['PluginVar']['ClockProhibitEndTime']))){
			if($this->Config['PluginVar']['ContinuityClockSwitch']){
				$TimeClock = DB::fetch_first('SELECT * FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' and set_time = '.$this->TodayEndTime.' order by dateline DESC');
				if(!$TimeClock || !$TimeClock['display']){
					$Data['Msg'] = urlencode($this->Config['PluginVar']['ClockTimePrompt']);
					return $Data;
				}
			}else{
				$Data['Msg'] = urlencode($this->Config['PluginVar']['ClockTimePrompt']);
				return $Data;
			}
		}
		
		$RepeatClock = DB::fetch_first('SELECT * FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' and set_time = '.$this->TomorrowEndTime.' and display = 1 order by dateline DESC');
		if($RepeatClock && $RepeatClock['state'] != 1){//已经支付过，防止恶意刷数据
			$Data['Msg'] = urlencode($this->Config['LangVar']['Text29']);
			return $Data;
		}
		
		if($this->Config['PluginVar']['ProhibitAddress'] && $this->CheCkRestrictedAreas($this->Config['PluginVar']['ProhibitAddress'],$Get['lat'],$Get['lng'])){//地区限制
			$Data['Msg'] = urlencode(str_replace(array('{Address}'),array($this->Config['PluginVar']['ProhibitAddress']),$this->Config['LangVar']['ProhibitAddressErr']));
			return $Data;
		}
		if(strpos($_SERVER["HTTP_USER_AGENT"],'QianFan') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX') !== false){
			$Data['State'] = 200;
		}else{
			$PayLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableClockPayLog).' where uid = '.$Uid.' and state = 0 order by datetime DESC');
			if(!$PayLog){
				$PayLog = $this->GetInsertPayLog('','');
				$Data['Id'] = $PayLog['Pid'];
			}else{
				$Data['Id'] = $PayLog['id'];
			}
			$Data['State'] = 200;
		}
		return $Data;
	}
	public function GetInsertClock($Uid=null,$UserName=null){
		global $_G;
		$Uid = $Uid ? intval($Uid) : intval($_G[uid]);

		$MyClock = DB::fetch_first('SELECT * FROM '.DB::table($this->TableClock).' where uid = '.intval($Uid).' and set_time = '.$this->TomorrowEndTime.' and display = 1 order by dateline desc');
		if($MyClock){
			$Data['Id'] = $MyClock['id'];
			$Data['State'] = true;
			return $Data;
		}else{
			$InsData['display_even'] = 0;
			$InsData['count'] = 0;
			$InsData['uid'] = $Uid;
			$InsData['username'] = $UserName ? addslashes(strip_tags($UserName)) : addslashes(strip_tags($_G['username']));
			$InsData['set_time'] = $this->TomorrowEndTime;
			$InsData['dateline'] = time();
			$InsData['display'] = 1;
			$InsData['money'] = addslashes(strip_tags($this->Config['PluginVar']['Money']));
			$Id = DB::insert($this->TableClock,$InsData,true);
			if($Id){
				$Data['Id'] = $Id;
				$Data['State'] = true;
				return $Data;
			}
		}
		
	}
	//检测是否支付成功，防止丢单
	public function GetCheckPubid(){
		global $_G;
		$MyClock = DB::fetch_first('SELECT * FROM '.DB::table($this->TableClock).' where uid = '.intval($_G['uid']).' and set_time = '.$this->TomorrowEndTime.' and display = 1 order by dateline desc');

		if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX') !== false){
			$ClockPayLog = DB::fetch_all('SELECT * FROM '.DB::table($this->TableClockPayLog).' where uid = '.intval($_G['uid']).' and state = 0 and type = \'mag\' order by id DESC');
		}else if(strpos($_SERVER["HTTP_USER_AGENT"],'QianFan') !== false){
			$ClockPayLog = DB::fetch_all('SELECT * FROM '.DB::table($this->TableClockPayLog).' where uid = '.intval($_G['uid']).' and state = 0 and type = \'qf\' order by id DESC');
		}
		if(!$MyClock){
			foreach($ClockPayLog as $K => $V){
				if($V['type'] == 'mag'){
					if($this->GetAjaxMagCheckOrder($V['pubid']) == 200){
						return true;
						break;
					};
				}else if($V['type'] == 'qf'){
					if($this->QFPay($V['pubid'],true) == 200){
						return true;
						break;
					};
				}
			}
		}
	}	
	//支付记录
	public function GetInsertPayLog($Pubid,$OrderId,$PaymentType=null,$Type=null,$State=0){
		global $_G;
		$InsData['pubid'] = addslashes(strip_tags($Pubid));
		$InsData['order_id'] = $OrderId ? $OrderId : time().rand(0,999999999);
		$InsData['uid'] = intval($_G['uid']);
		$InsData['username'] = addslashes(strip_tags($_G['username']));
		$InsData['money'] = addslashes(strip_tags($this->Config['PluginVar']['Money']));
		$InsData['payment_type'] = addslashes(strip_tags($PaymentType));
		$InsData['type'] = addslashes(strip_tags($Type));
		$InsData['datetime'] = time();
		$InsData['state'] = $State;
		$Id = DB::insert($this->TableClockPayLog,$InsData,true);
		if($Id){
			$Data['Pid'] = $Id;
			$Data['OrderId'] = $InsData['order_id'];
			$Data['State'] = 200;
			return $Data;
		}
	}
	//创建支付
	public function GetAjaxPay($OrderId,$Title,$Event,$Money,$PayType,$NotifyUrl=null){
		global $_G;
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){
			@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
			$NotifyUrl = empty($NotifyUrl) ? $_G['siteurl'].'plugin.php?id=fn_clock&m=payok&orderid=' : $NotifyUrl;
			$PayId = $FnPay->GetInsertPay($OrderId,$this->StrToGBK($Title),'fn_clock',$Event,$Money,$PayType,$NotifyUrl);
			$Data = array();
			$Data['PayUrl'] = $_G['siteurl'].'plugin.php?id=fn_pay&payid='.$PayId;
			$Data['State'] = 200;
			return $Data;
		}
	}
	/* 马甲支付 */
	public function GetAjaxMagOrder($Uid,$Money,$Title){//下单
		global $_G;
		$Uid = intval($Uid);
		$TradeNo = time().rand(0,999999999);
		$Url = 'http://'.$this->Config['PluginVar']['MagDomain'].'/core/pay/pay/unifiedOrder?trade_no='.$TradeNo.'&callback='.urlencode($_G['siteurl']).'&amount='.$Money.'&title='.$Title.'&user_id='.$Uid.'&to_user_id=&des='.$Title.'&remark='.$Title.'&secret='.$this->Config['PluginVar']['MagSecret'].'&to_account=true';
		$Data = dfsockopen($Url);
		if(!$Data){
			$Data = file_get_contents($Url);
		}
		$Res = json_decode($Data,true);
		if($Res['success'] == true){
			$Res['data']['trade_no'] = $TradeNo;
		}
		return $Res;
	}
	public function GetAjaxMagCheckOrder($UnionOrderNum){//查询订单状态
		global $_G;
		$Uid = intval($_G['uid']);
		$Url = 'http://'.$this->Config['PluginVar']['MagDomain'].'/core/pay/pay/orderStatusQuery?unionOrderNum='.$UnionOrderNum.'&secret='.$this->Config['PluginVar']['MagSecret'];
		$Data = dfsockopen($Url);
		if(!$Data){
			$Data = file_get_contents($Url);
		}
		$Res = json_decode($Data,true);
		$CheckClockPayLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableClockPayLog).' where pubid = \''.$UnionOrderNum.'\' AND uid = '.$Uid.' and state = 0');
		if($Res['success'] && $Res['paycode'] == 1 && $CheckClockPayLog){
			$DataClock = $this->GetInsertClock();
			if($DataClock['Id'] && $DataClock['State']){
				$UpPatLog['content'] = str_replace('Num',$DataClock['Id'],$this->Config['LangVar']['Text67']);
				$UpPatLog['state'] = 1;
				$UpPatLog['pay_time'] = time();
				if(DB::update($this->TableClockPayLog,$UpPatLog,'id='.$CheckClockPayLog['id'])){
					$State = 200;
				}
			}
			return $State;
		}else{
			DB::delete($this->TableClockPayLog,'uid ='.$Uid.' And pubid = \''.$UnionOrderNum.'\'');
		}
	}
	private function GetMagAccountTransfer($Uid,$Amount,$Remark,$OutTradeCode=null){
		$OutTradeCode = $OutTradeCode ? $OutTradeCode :  time().rand(0,999999999);
		$Uid = intval($Uid);
		$Remark = diconv($Remark,CHARSET,'UTF-8');
		$Url = 'http://'.$this->Config['PluginVar']['MagDomain'].'/core/pay/pay/accountTransfer?secret='.$this->Config['PluginVar']['MagSecret'].'&user_id='.$Uid.'&amount='.$Amount.'&remark='.$Remark.'&out_trade_code='.$OutTradeCode;
		$Data = dfsockopen($Url);
		if(!$Data) {
			$Data = file_get_contents($Url);
		}
		$Data = json_decode($Data,true);
		if($Data['success'] && $Data['code'] == 101){
			return true;
		}
	}
	public function GetMagUserInfo(){
		$UserAgent = $_SERVER['HTTP_USER_AGENT'];
		$Info = explode("|",$UserAgent);
		$Url = 'http://'.$this->Config['PluginVar']['MagDomain'].'/mag/cloud/cloud/getUserInfo?token='.$Info[7].'&secret='.$this->Config['PluginVar']['MagSecret'];
		$Data = dfsockopen($Url);
		if(!$Data) {
			$Data = file_get_contents($Url);
		}
		$Data = json_decode($Data,true);
		if($Data['data']){
			return $Data['data'];
		}
	}
	public function GetAjaxInsert(){
		global $_G;
		$InsData['uid'] = intval($_G['uid']);
		$ClockUid = $this->GetFirstClockUid();
		if($ClockUid){
			$State = 200;
		}else{
			 if(DB::insert($this->TableClockUid,$InsData)){
				$State = 200;
			 }
		}
		return $State;
	}
	public function GetFirstClockUid(){
		global $_G;
		$ClockUid = DB::fetch_first('SELECT * FROM '.DB::table($this->TableClockUid).' where uid = '.intval($_G['uid']));
		return $ClockUid;
	}

	public function GetDelClockUid(){
		global $_G;
		if(DB::delete($this->TableClockUid,'uid ='.intval($_G['uid']))){
			return true;
		}
	}
	/* 马甲支付 End */
	/* 千帆支付 */
	public function QFPay($QFId,$State=false){
		global $_G;
		$QFId = addslashes(strip_tags($QFId));
		$Uid = intval($_G['uid']);
		$Data = array(
			'order_id' => $QFId,
			'nonce' => $this->QFNonce()
		);
		$Data['sign'] = $this->QFSign($Data,$this->Config['PluginVar']['qf_secret']);
		$R = http_build_query($Data);
		$Url = 'http://'.$this->Config['PluginVar']['qf_hostname']. '.qianfanapi.com/api1_2/orders/query?'.$R;
		$QFData = dfsockopen($Url);
		if(!$QFData) {
			$QFData = file_get_contents($Url);
		}
		$CheckClockPayLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableClockPayLog).' where pubid = \''.$QFId.'\' AND uid = '.$Uid.' and state = 0');
		$QFData = json_decode($QFData,true);
		if(($QFData['data'][$QFId]['result'] == 1 || ($QFData['data'][$QFId]['result'] == 2 && $QFData['data'][$QFId]['status'] != 20)) && $CheckClockPayLog){
			$DataClock = $this->GetInsertClock();
			if($DataClock['Id'] && $DataClock['State']){
				$UpPatLog['content'] = str_replace('Num',$DataClock['Id'],$this->Config['LangVar']['Text67']);
				$UpPatLog['state'] = 1;
				$UpPatLog['pay_time'] = time();
				if(DB::update($this->TableClockPayLog,$UpPatLog,'id='.$CheckClockPayLog['id'])){
					$State = 200;
				}
			}
			return $State;
		}else if(!$QFData['data'][$QFId]['result'] && $State){
			DB::delete($this->TableClockPayLog,'uid ='.$Uid.' And pubid = \''.$QFId.'\'');
		}
	}
	private function QFAddBalance($Uid,$Money){//金额写入
		$Uid = intval($Uid);
		$Data = array(
			'uid' => $Uid,
			'amount'=> $Money * 100,
			'type'=> $this->Config['PluginVar']['qf_sr_type'],
			'nonce' => $this->QFNonce()
		);
		$Data['sign'] = $this->QFSign($Data,$this->Config['PluginVar']['qf_secret']);
		$Url = 'http://'.$this->Config['PluginVar']['qf_hostname']. '.qianfanapi.com/api1_2/balance/add';
		$QFData = $this->PostCurlInit($Url,$Data);
		if(!$QFData) {
			$QFData = dfsockopen($Url,0,$Data);
		}
		$Return = json_decode($QFData,true);
		if($Return['data']){
			return true;
		}
	}
	public function GetActionAuthCode($wap_token = '', $secret_key = '',$operation = 'DECODE') {
		$wap_token = str_replace(' ','+',urldecode($wap_token));

		$ckey_length = 4;

		$secret_key = md5($secret_key);
		$keya = md5(substr($secret_key, 0, 16));
		$keyb = md5(substr($secret_key, 16, 16));
		$keyc = $ckey_length ? ($operation == 'DECODE' ? substr($wap_token, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';

		$cryptkey = $keya.md5($keya.$keyc);
		$key_length = strlen($cryptkey);

		$wap_token = $operation == 'DECODE' ? base64_decode(substr($wap_token, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($wap_token.$keyb), 0, 16).$wap_token;
		$string_length = strlen($wap_token);

		$result = '';
		$box = range(0, 255);

		$rndkey = array();
		for($i = 0; $i <= 255; $i++) {
			$rndkey[$i] = ord($cryptkey[$i % $key_length]);
		}

		for($j = $i = 0; $i < 256; $i++) {
			$j = ($j + $box[$i] + $rndkey[$i]) % 256;
			$tmp = $box[$i];
			$box[$i] = $box[$j];
			$box[$j] = $tmp;
		}

		for($a = $j = $i = 0; $i < $string_length; $i++) {
			$a = ($a + 1) % 256;
			$j = ($j + $box[$a]) % 256;
			$tmp = $box[$a];
			$box[$a] = $box[$j];
			$box[$j] = $tmp;
			$result .= chr(ord($wap_token[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
		}

		if($operation == 'DECODE') {
			if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
				return substr($result, 26);
			} else {
				return '';
			}
		} else {
			return $keyc.str_replace('=', '', base64_encode($result));
		}
	}
	private function QFNonce($length = 32){
		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";
		$str   = "";
		for ($i = 0; $i < $length; $i++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}
	private function QFSign($params, $secret){
		ksort($params);
		$sparams = array();
		foreach ($params as $k => $v) {
			if ("@" != substr($v, 0, 1)) {
				$sparams[] = "$k=$v";
			}
		}
		$sparams[] = "secret=" . $secret;
		return strtoupper(md5(implode("&", $sparams)));
	}
	/* 千帆支付 End */
	/* 开始打卡 */
	public function GetAjaxClock(){
		global $_G;
		$Uid = intval($_G['uid']);
		$UserInfo = $this->GetUserInfo($Uid);
		$Info = $UserInfo['Clock'];
		if($Info){
			//记录打卡时间
			$TimeLogData['uid'] =  $Uid;
			$TimeLogData['cid'] =  $Info['id'];
			$TimeLogData['username'] =  addslashes(strip_tags($_G['username']));
			$TimeLogData['clock_time'] = time();
			if(DB::insert($this->TableClockTimeLog,$TimeLogData)){
				if($Info['state'] == 1){//已经打卡了
					$Data['Msg'] = urlencode($this->Config['LangVar']['Text36']);
					return $Data;
				}
				if(time() < $this->CountDownTime){//未开始
					$Data['State'] = 201;
					return $Data;
				}else if(time() > $Info['set_time']){//时间已过
					$Data['State'] = 202;
					return $Data;
				}else{
					$LastClock = DB::fetch_first('SELECT * FROM '.DB::table($this->TableClock).' where uid = '.$Uid.' and set_time = '.strtotime('-1day',$this->TodayEndTime).' and display = 1 and state = 1 order by dateline DESC');//是否连续签到
					$DisplayEven = $LastClock ? 1 : 0;
					$Count = $LastClock['count'] + 1;
					$UpData = array('state'=>1,'clock_time'=>time(),'display_even'=>$DisplayEven,'count'=>$Count);
					if(DB::update($this->TableClock,$UpData,'id='.$Info['id'])){
						$Data['State'] = 200;
						return $Data;
					}else{
						$Data['Msg'] = urlencode($this->Config['LangVar']['Text30']);
						return $Data;
					}
				}
			};
			//记录打卡时间 End
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['Text30']);
			return $Data;
		}
	}
	/* 开始结算 */
	public function GetClockSettlementMoney(){
		global $_G;
		$StateLogList = DB::fetch_all('SELECT * FROM '.DB::table($this->TableClockLog).' where set_time = '.$this->TodayEndTime.' and state = 1');//返回已分配红包列表
		if(time() > $this->TodayEndTime && !$StateLogList){
			$UserList = DB::fetch_all('SELECT * FROM '.DB::table($this->TableClock).' where set_time = '.$this->TodayEndTime.' and display = 1 and state = 1');//返回打卡列表
			$NoClockUserList = DB::fetch_all('SELECT * FROM '.DB::table($this->TableClock).' where set_time = '.$this->TodayEndTime.' and display = 1 and state = 0');//返回未打卡列表
			
			if($UserList){//有人打卡
				$LogList = DB::fetch_all('SELECT * FROM '.DB::table($this->TableClockLog).' where set_time = '.$this->TodayEndTime.' and state = 0');//返回未分配红包列表
				if($LogList){
					$ClockLogUpSql = "UPDATE ".DB::table($this->TableClockLog)." SET uid = CASE id {Uid} END,state = CASE id {State} END,cid = CASE id {Cid} END";//红包

					$ClockUpSql = "UPDATE ".DB::table($this->TableClock)." SET income_money = CASE id ";//打卡
					
					if($this->Config['PluginVar']['AppType'] != '2' && $this->Config['PluginVar']['AppType'] != '1'){//不是千帆、马甲
						$WalletLogInsertSql = "insert INTO ".DB::table(FnWallet::$TableWalletLog)." (uid,content,money,type,plugin,dateline) values";//钱包明细
						$WalletUpSql = "UPDATE ".DB::table(FnWallet::$TableWallet)." SET money = CASE uid ";//钱包相加
					}

					foreach($UserList as $Key=>$Val){
						$UpData['income_money'] = addslashes(strip_tags($LogList[$Key]['money']));

						$ClockLogUidWhen .= sprintf("WHEN %d THEN %s ",$LogList[$Key]['id'],intval($Val['uid']));
						$ClockLogStateWhen .= sprintf("WHEN %d THEN %s ",$LogList[$Key]['id'],1);
						$ClockLogCidWhen .= sprintf("WHEN %d THEN %s ",$LogList[$Key]['id'],intval($Val['id']));
						$ClockLogUpIds[] = $LogList[$Key]['id'];

						$ClockUpSql .= sprintf("WHEN %d THEN %s ",$Val['id'],$UpData['income_money']);
						$ClockUpIds[] = $Val['id'];
						
						if($this->Config['PluginVar']['AppType'] != '2' && $this->Config['PluginVar']['AppType'] != '1'){//不是千帆、马甲
							$WalletLogInsertSql .= "('".intval($Val['uid'])."','".addslashes(strip_tags($this->Config['LangVar']['Text66']))."','".$UpData['income_money']."','1','fn_clock','".time()."'),";

							$WalletUpSql .= sprintf("WHEN %d THEN %s ",$Val['uid'],'money + '.$UpData['income_money']);
							$UidIds[] = $Val['uid'];
						}

					}
					
					$ClockLogUpSql .= " WHERE id IN (".implode(',',$ClockLogUpIds).")";
					$ClockLogUpSql = str_replace(array('{Uid}','{State}','{Cid}'),array($ClockLogUidWhen,$ClockLogStateWhen,$ClockLogCidWhen),$ClockLogUpSql);
					
					$ClockUpSql .= "END WHERE id IN (".implode(',',$ClockUpIds).")";
					
					if($this->Config['PluginVar']['AppType'] != '2' && $this->Config['PluginVar']['AppType'] != '1'){//不是千帆、马甲
						$WalletLogInsertSql = substr($WalletLogInsertSql,0,strlen($WalletLogInsertSql)-1);
						$WalletUpSql .= "END WHERE uid IN (".implode(',',$UidIds).")";
					}

					if(DB::query($ClockUpSql) && DB::query($ClockLogUpSql)){//瓜分金额
						if($this->Config['PluginVar']['AppType'] != '2' && $this->Config['PluginVar']['AppType'] != '1'){//不是千帆、马甲
							if(FnWallet::WalletLogInsertByQuery($WalletLogInsertSql)){//增加钱包记录
								FnWallet::WalletLogInsertByQuery($WalletUpSql);//给用户增加钱包金额
							}
						}
					}

					DB::query("UPDATE ".DB::table($this->TableClock)." SET state = 2 WHERE set_time = ".$this->TodayEndTime.' and state = 0 and display = 1');//没有打卡的改变失败状态

				}else{
					$MoneyCount = $ToMoneyCount = DB::result_first('SELECT sum(money) FROM '.DB::table($this->TableClock).' where set_time = '.$this->TodayEndTime.' and display = 1');//返回总金额
					
					if(($this->Config['PluginVar']['SponsorEndTime'] == date('Y-m-d') || $this->Sponsor) && $this->Config['PluginVar']['SponsorMoneySwitch']){//赞助费用计算打卡费用内
						$MoneyCount = $MoneyCount + $this->Config['PluginVar']['SponsorMoney'];
					}

					$PercentMoney = $this->Config['PluginVar']['PercentMoney'] ?  ($MoneyCount - ($MoneyCount * $this->Config['PluginVar']['PercentMoney']) / 100) : '';//收取费用
					
					$UserMoney = count($UserList) * $this->Config['PluginVar']['Money'];
					
					if($PercentMoney >= $UserMoney){
						$MoneyCount = $PercentMoney;
					}
					
					if(($MoneyCount - count($UserList)) < $this->Config['PluginVar']['LessNum']){//收取打卡费用小于多少不收取打卡费用
						$MoneyCount = $ToMoneyCount;
					}

					if(($this->Config['PluginVar']['SponsorEndTime'] == date('Y-m-d') || $this->Sponsor) && !$this->Config['PluginVar']['SponsorMoneySwitch']){//赞助费用不计算打卡费用内
						$MoneyCount = $MoneyCount + $this->Config['PluginVar']['SponsorMoney'];
					}

					
					if($this->Reward){//奖励规则
						$UserCount = DB::result_first('SELECT count(*) FROM '.DB::table($this->TableClock).' where set_time = '.$this->TodayEndTime.' and display = 1');//返回总人数
						$MoneyCount = $MoneyCount + $this->GetFreeRule($UserCount);
					}
					
					$BonusArray = $this->GetRandBonus($MoneyCount,count($UserList),$this->Config['PluginVar']['Money']);
					$LogSql= "insert INTO ".DB::table($this->TableClockLog)." (money,set_time,dateline) values";
					foreach($BonusArray as $Key=>$Val){
						$InsData['money'] = addslashes(strip_tags($Val));
						$InsData['set_time'] = intval($this->TodayEndTime);
						$InsData['dateline'] = time();
						$LogSql .= "('".$InsData['money']."','".$InsData['set_time']."','".$InsData['dateline']."'),";
					}
					$LogSql = substr($LogSql,0,strlen($LogSql)-1);
					DB::query($LogSql);
				}
			}else{//没人打卡
				if($NoClockUserList){
					if($this->Config['PluginVar']['AppType'] != '2' && $this->Config['PluginVar']['AppType'] != '1'){//不是千帆、马甲
						$WalletLogInsertSql = "insert INTO ".DB::table(FnWallet::$TableWalletLog)." (uid,content,money,type,plugin,dateline) values";
						$WalletUpSql = "UPDATE ".DB::table(FnWallet::$TableWallet)." SET money = CASE uid ";
						foreach($NoClockUserList as $Key=>$Val){

							$WalletLogInsertSql .= "('".intval($Val['uid'])."','".addslashes(strip_tags($this->Config['LangVar']['Text42']))."','".$Val['money']."','1','fn_clock','".time()."'),";
							
							$WalletUpSql .= sprintf("WHEN %d THEN %s ",$Val['uid'],'money + '.$Val['money']);
							$UidIds[] = $Val['uid'];
						}
						$WalletLogInsertSql = substr($WalletLogInsertSql,0,strlen($WalletLogInsertSql)-1);

						$WalletUpSql .= "END WHERE uid IN (".implode(',',$UidIds).")";
					}


					if(DB::query("UPDATE ".DB::table($this->TableClock)." SET state = 2,refund_state = 2 WHERE set_time = ".$this->TodayEndTime.' and state = 0 and display = 1')){//没有打卡的改变状态
						if($this->Config['PluginVar']['AppType'] != '2' && $this->Config['PluginVar']['AppType'] != '1'){//不是千帆、马甲
							if(FnWallet::WalletLogInsertByQuery($WalletLogInsertSql)){//增加钱包记录
								FnWallet::WalletLogInsertByQuery($WalletUpSql);//还款给用户
							}
						}
					}
				}
			}
		}
	}

	/** 
	 *   
	 * @param $Total 红包总额 
	 * @param $Count 红包个数 
	 * @param $Min 每个小红包的最小额 
	 * @return 存放生成的每个小红包的值的一维数组 
	 */  
	public function GetRandBonus($Total=0,$Count=0,$Min=1){
		$LeftTotal = $Total - ($Count * $Min);
		if($LeftTotal){
			$LeftTotalArray = $this->GetRedGift($LeftTotal,$Count);
		}
		for($i = 0;$i < $Count;$i++){
			$Result[$i] = $Min + $LeftTotalArray['MoneySum'][$i+1];
		}
		shuffle($Result);
		return $Result;
	}
	/**
	 * @param $Total [红包总额]
	 * @param int $num [发几个]
	 * @return array[生成红包金额]
	 */
	public function GetRedGift($Total, $Num){
		$Min = 0.01;
		$Wamp = array();
		$ReturnData = array();
		for ($i = 1; $i < $Num; ++$i) {
			$SafeTotal = ($Total - ($Num - $i) * $Min) / ($Num - $i); //红包金额的最大值
			if ($SafeTotal < 0) break;
			$Money = @mt_rand($Min * 100, $SafeTotal * 100) / 100;//随机产生一个红包金额
			$Total = $Total - $Money;//剩余红包总额
			$Wamp[$i] = round($Money, 2);//保留两位有效数字
		}
		$Wamp[$i] = round($Total, 2);
		
		$ReturnData['MoneySum'] = $Wamp;
		$ReturnData['newTotal'] = array_sum($Wamp);
		return $ReturnData;
	}
	public function DiffBetweenTwoDays($Day1, $Day2){
	  $Second1 = strtotime($Day1);
	  $Second2 = strtotime($Day2);
	  if ($Second1 < $Second2) {
		$Tmp = $Second2;
		$Second2 = $Second1;
		$Second1 = $Tmp;
	  }
	  return ($Second1 - $Second2) / 86400;
	}
	//模拟访问Post
	public function PostCurlInit($Url, $Data) {
		global $_G;
		if (!function_exists('curl_init')) {
			return '';
		}
		$Ip = rand(1,255).".".rand(1,255).".".rand(1,255).".".rand(1,255)."";
		$Header = array();
		$Header[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8';
		$Header[] = 'Accept-Encoding: gzip, deflate, sdch';
		$Header[] = 'Accept-Language: zh-CN,zh;q=0.8';
		$Header[] = 'Cache-Control: max-age=0';
		$Header[] = 'Connection: keep-alive';
		$Header[] = 'Connection: keep-alive';
		$Header[] = 'X-FORWARDED-FOR:'.$Ip;
		$Header[] = 'CLIENT-IP:'.$Ip;
		$Ch = curl_init();
		curl_setopt($Ch, CURLOPT_URL, $Url);
		curl_setopt($Ch, CURLOPT_HTTPHEADER, $Header);
		curl_setopt($Ch, CURLOPT_REFERER, $_G['siteurl']); //构造来路
		curl_setopt($Ch, CURLOPT_ENCODING, 'gzip');
		curl_setopt($Ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36');// 保存到字符串而不是输出
		# curl_setopt( $Ch, CURLOPT_HEADER, 1);
		curl_setopt($Ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($Ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($Ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($Ch, CURLOPT_POST, 1);
		curl_setopt($Ch, CURLOPT_POSTFIELDS, $Data);
		$Data = curl_exec($Ch);
		if (!$Data) {
			error_log(curl_error($Ch));
		}
		curl_close($Ch);
		return $Data;
	}
	/* 查询单个 */
	public function QueryOne($TableName,$Id,$Where=null){
		$FirstSql = 'SELECT * FROM '.DB::table($TableName).' where id = '.$Id.' '.$Where;
		return DB::fetch_first($FirstSql);	
	}
	/* 
	修改表的数据
	table_name=>
	ids=>id
	fields=>字段
    val=>值
	*/
	public function EditFields($TableName,$Ids,$Fields,$Val){
		if(is_array($Ids)){
			$Ids = implode(',',$Ids);
		}else{
			$Ids = $Ids;
		}
		$UpData[$Fields] = $Val;
		if(DB::update($TableName,$UpData,'id in( '.$Ids.' )')){
			return true;
		}else{
			return false;
		}
	}

	/* 编码转换 */
	public function StrToGBK($string,$ajax_status=null){
		global $_G;
		if($_G['charset'] == 'gbk'){
			if($ajax_status == true){
				if(is_array($string)){
					return eval('return '.iconv("GB2312","UTF-8//IGNORE",var_export($string,true).';')); 
				}else{
					return iconv('GB2312', 'UTF-8', $string);
				}
			}else{
				if(is_array($string)){
					$StringArr = array();
					foreach($string as $key=>$value){
						$encode = mb_detect_encoding($value, array('UTF-8','GB2312','GBK'));
						if($encode == 'UTF-8'){
							$StringArr[$key] = iconv('UTF-8','GB2312//IGNORE',$value);
						}else if($encode == 'EUC-CN'){
							$StringArr[$key] = $value;
						}
					}
					return $StringArr;
				}else{
					$encode = mb_detect_encoding($string, array('UTF-8','GB2312','GBK'));
					if($encode == 'UTF-8'){
						return iconv('UTF-8','GB2312//IGNORE', $string);
					}else if($encode == 'EUC-CN'){
						return $string;
					}
				}
			}
		}else{
			return $string;
		}
        
    }

	/* 微信分享_GetSignPackage */
	public function WeixinGetSignPackage(){
		require DISCUZ_ROOT.'/'.$this->Config['Path']."/weixin/jssdk.php";
		$jssdk = new JSSDK($this->Config['PluginVar']['WxAppid'], $this->Config['PluginVar']['WxSecret']);
		return $jssdk->getSignPackage();
	}
	/* 地区检测 */
	private function CheCkRestrictedAreas($CheCkAreas,$Lat=null,$Lng=null){
		global $_G;
		$CheCkAreasArr = array_filter(explode(",",$CheCkAreas));
		if($Lat && $Lng && (strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'QianFan') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'MicroMessenger') !== false)){//经纬度限
			if($_G['cookie']['FnAddress']){
				foreach($CheCkAreasArr as $Key=>$Val){
					if(strpos($_G['cookie']['FnAddress'],$Val) !== false){
						return false;
					}
				}
				return true;
			}else{
				$Location = json_decode(dfsockopen('https://apis.map.qq.com/ws/geocoder/v1/?location='.$Lat.','.$Lng.'&key='.$this->Config['PluginVar']['MapKey'].'&get_poi=1'),true);
				$Location['result']['address'] = diconv($Location['result']['address'],'UTF-8',CHARSET);
				if($Location['status'] === 0 && $Location['result']['address']){
					dsetcookie('FnAddress',$Location['result']['address'],3600);
					foreach($CheCkAreasArr as $Key=>$Val){
						if(strpos($Location['result']['address'],$Val) !== false){
							return false;
						}
					}
					return true;
				}
			}
		}else{//ip限制
			if($_G['cookie']['FnAddress']){
				foreach($CheCkAreasArr as $Key=>$Val){
					if(strpos($_G['cookie']['FnAddress'],$Val) !== false){
						return false;
					}
				}
				return true;
			}else{
				$Location = json_decode(dfsockopen("https://apis.map.qq.com/ws/location/v1/ip?ip=".$_G['clientip'].'&key='.$this->Config['PluginVar']['MapKey']),true);
				$Address = diconv($Location['result']['ad_info']['province'],'UTF-8',CHARSET).diconv($Location['result']['ad_info']['city'],'UTF-8',CHARSET);
				dsetcookie('FnAddress',$Address,60);
				foreach($CheCkAreasArr as $Key=>$Val){
					if(strpos($Address,$Val) !== false){
						return false;
					}
				}
				return true;
			}
		}
	}
	
	/* 地区检测 End */
	
	/* 免费打卡规则返回金额 */
	private function GetFreeRule($Count){
		$FreeRuleArr = explode("\n",$this->Config['PluginVar']['Reward']);
		foreach($FreeRuleArr as $Key=>$Val){
			$Arr = explode('=',$Val);
			if($Key == (count($FreeRuleArr) - 1)){
				if($Count >= $Arr[0]){
					return $Arr[1];
				}
			}else{
				$ToArr = explode('=',$FreeRuleArr[$Key+1]);
				if($Count >= $Arr[0] && $Count < $ToArr[0]){
					return $Arr[1];
				}
			}
		}
	}
}
//From: Dism_taobao-com
?>