<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_clock` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `refund_state` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `income_money` decimal(11,2) unsigned NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `clock_time` int(11) unsigned NOT NULL,
  `set_time` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `count` int(11) unsigned NOT NULL,
  `display_even` tinyint(1) unsigned NOT NULL,
  `fictitious` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_clock_log` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `cid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `set_time` int(11) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_clock_pay_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `pubid` varchar(255) NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `pay_time` int(11) unsigned NOT NULL,
  `datetime` int(11) unsigned NOT NULL,
  `payment_type` varchar(50) NOT NULL,
  `content` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_clock_time_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `clock_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_clock_uid` (
  `uid` int(11) unsigned NOT NULL
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_clock_share` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `type` varchar(20) NOT NULL,
  `url` varchar(255) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$ClockTableField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_clock'));
$ClockPayLogTableField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_clock_pay_log'));

$ClockToArray = MysqlToArray($ClockTableField);
$ClockPayLogToArray = MysqlToArray($ClockPayLogTableField);

if(in_array('pay_money',$ClockToArray) && in_array('pay_state',$ClockToArray)){
$UpSql = <<<EOF
	ALTER TABLE `pre_fn_clock` CHANGE `pay_money` `money` DECIMAL( 11, 2 ) UNSIGNED NOT NULL;
	ALTER TABLE `pre_fn_clock` CHANGE `pay_state` `display` TINYINT( 1 ) UNSIGNED NOT NULL;
EOF;
	runquery($UpSql);
}

if(!in_array('username',$ClockToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_clock` ADD `username` VARCHAR( 100 ) NOT NULL AFTER `uid` ;
EOF;
	runquery($UpSql);
}

if(!in_array('refund_state',$ClockToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_clock` ADD `refund_state` TINYINT( 1 ) UNSIGNED NOT NULL AFTER `state` ;
EOF;
	runquery($UpSql);
}

if(!in_array('fictitious',$ClockToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_clock` ADD `fictitious` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '0' AFTER `display_even` ;
EOF;
	runquery($UpSql);
}


if(!in_array('username',$ClockPayLogToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_clock_pay_log` ADD `username` VARCHAR( 100 ) NOT NULL AFTER `uid` ;
EOF;
	runquery($UpSql);
}

$UpSql = <<<EOF
	ALTER TABLE  `pre_fn_clock_pay_log` CHANGE  `order_id`  `order_id` VARCHAR( 255 ) NOT NULL;
EOF;
runquery($UpSql);

//1.7�汾
if($_GET['fromversion'] < 1.7){
	loadcache('plugin');
	if($_G['cache']['plugin']['fn_clock']['AppType'] == 1 && !file_exists(DISCUZ_ROOT.'/source/plugin/fn_clock/weixin/fromversion.txt')){
		$TodayEndTime = strtotime(date('Y-m-d '.$_G['cache']['plugin']['fn_clock']['EndTime']));
		$Time = time() < $TodayEndTime ? strtotime('-1day',$TodayEndTime) : $TodayEndTime;
		$UpSql = <<<EOF
			UPDATE `pre_fn_clock` SET `refund_state` = '1' WHERE set_time <= $Time;
EOF;
		runquery($UpSql);
		file_put_contents(DISCUZ_ROOT.'/source/plugin/fn_clock/weixin/fromversion.txt',$Time);
	};

	$WalletTableField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_wallet'));
	$WalletToArray = MysqlToArray($WalletTableField);
	if(!in_array('username',$WalletToArray)) {
	$UpSql = <<<EOF
		ALTER TABLE `pre_fn_wallet` ADD `username` VARCHAR( 100 ) NOT NULL AFTER `uid` ;
EOF;
		runquery($UpSql);
	}
	$WalletWithdrawalsLogTableField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_wallet_withdrawals_log'));
	$WalletWithdrawalsLogToArray = MysqlToArray($WalletWithdrawalsLogTableField);
	if(in_array('name',$WalletWithdrawalsLogToArray) && in_array('alipay',$WalletWithdrawalsLogToArray) && in_array('wx',$WalletWithdrawalsLogToArray)){
		$UpSql = <<<EOF
		ALTER TABLE `pre_fn_wallet_withdrawals_log` CHANGE `name` `username` VARCHAR( 100 ) NOT NULL;
		ALTER TABLE `pre_fn_wallet_withdrawals_log` CHANGE `alipay` `content` VARCHAR( 255 ) NOT NULL;
		ALTER TABLE `pre_fn_wallet_withdrawals_log` CHANGE `wx` `fee` DECIMAL( 11, 2 ) UNSIGNED NOT NULL;
EOF;
		runquery($UpSql);
	}
}
//1.7�汾End

function MysqlToArray($Array) {
    $temp = array();
    foreach ($Array as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
$finish = TRUE;
?>