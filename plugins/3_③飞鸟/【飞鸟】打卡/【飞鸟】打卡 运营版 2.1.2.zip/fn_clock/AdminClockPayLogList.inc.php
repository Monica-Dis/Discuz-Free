<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_clock/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_clock/Common.php');
$Operation = in_array($_GET['Operation'], array('OpValue','AllDel')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&page='.$_GET[page].'&keyword='.$_GET[keyword].'&state='.$_GET[state];
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'L.id';
		if($_GET['keyword']){
			$Where .= ' and concat(L.username,L.uid,L.pubid,L.order_id) like(\'%'.addslashes(dhtmlspecialchars($_GET[keyword])).'%\')';
		}
		if($_GET['state'] === '0' || $_GET['state'] === '1' || $_GET['state'] === '2'){
			$Where .= ' and L.state = '.intval($_GET['state']);
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ���� */
		$StateSelected = array($_GET['state']=>' selected');
		$DayMoneyCount = GetModulesDayMoneyCount() ? GetModulesDayMoneyCount() : 0;
		$MoneyCount = GetModulesMoneyCount() ? GetModulesMoneyCount() : 0;
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Clock->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}">
						</td>

						<th>{$Fn_Clock->Config['LangVar']['StateTitle']}</th>
						<td>
						<select name="state">
							<option value="">{$Fn_Clock->Config['LangVar']['SelectNull']}</option>
							<option value="0"{$StateSelected['0']}>{$Fn_Clock->Config['LangVar']['PayState']['0']}</option>
							<option value="1"{$StateSelected['1']}>{$Fn_Clock->Config['LangVar']['PayState']['1']}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Clock->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">&nbsp;&nbsp;{$Fn_Clock->Config['LangVar']['Text75']}<span style="color:red;font-weight:bold;">{$DayMoneyCount}</span>&nbsp;&nbsp;{$Fn_Clock->Config['LangVar']['Text76']}<span style="color:red;font-weight:bold;">{$MoneyCount}</span>
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		

		/* ģ����� */
		$TdStyle = array('width="50"', 'width="250"','width="50"','width="80"','width="150"','width="60"','width="80"','width="80"');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'QiangLouModule', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_Clock->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
			'ID',
			$Fn_Clock->Config['LangVar']['Text70'],
			'Uid',
			$Fn_Clock->Config['LangVar']['UserNameTitle'],
			$Fn_Clock->Config['LangVar']['Text71'],
			$Fn_Clock->Config['LangVar']['MoneyTitle'],
			$Fn_Clock->Config['LangVar']['StateTitle'],
			$Fn_Clock->Config['LangVar']['Text72'],
			$Fn_Clock->Config['LangVar']['TimeTitle'].'/'.$Fn_Clock->Config['LangVar']['UpdateTime']
		), 'header tbm',$TdStyle);
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($ModulesList as $Module) {
			$Module['pay_time'] = $Module['pay_time'] ? date('Y-m-d H:i',$Module['pay_time']) : '';
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'],
				$Module['pubid'],
				$Module['uid'],
				$Module['username'] ? $Module['username'] : $Module['musername'],
				$Module['content'],
				$Module['money'],
				$Module['state'] ? $Fn_Clock->Config['LangVar']['PayState'][$Module['state']]:'<span style="color:red">'.$Fn_Clock->Config['LangVar']['PayState'][$Module['state']].'</span>',
				$Module['payment_type'],
				date('Y-m-d H:i',$Module['datetime']).'<br>'.$Module['pay_time']
			));
		}
		showsubmit('Submit','submit','del','<a href="'.$OpCpUrl.'&Operation=AllDel&formhash='.FORMHASH.'" >'.$Fn_Clock->Config['LangVar']['OneKeyDel'].'</a>',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter();/*Dism��taobao��com*/
		showformfooter();
		showtagfooter('div');
		echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_Clock->TableClockPayLog,'id ='.$Val);
			}
			cpmsg($Fn_Clock->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_Clock->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Operation == 'AllDel' && $_GET['formhash'] == formhash()){
	DB::delete($Fn_Clock->TableClockPayLog,'state = 0');
	cpmsg($Fn_Clock->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}
/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Clock;
	$FetchSql = 'SELECT M.username as musername,L.* FROM '.DB::table($Fn_Clock->TableClockPayLog).' L LEFT JOIN '.DB::table('common_member').' M on M.uid = L.uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* �������� */
function GetModulesDayMoneyCount(){
	global $Fn_Clock;
	$FetchSql = 'SELECT sum(L.money) FROM '.DB::table($Fn_Clock->TableClockPayLog).' L WHERE L.datetime >= '.strtotime(date('Y-m-d 00:00:00')).' and L.state = 1';
	return DB::result_first($FetchSql);//��������
}
/* ͳ�ƽ�� */
function GetModulesMoneyCount(){
	global $Fn_Clock;
	$FetchSql = 'SELECT sum(L.money) FROM '.DB::table($Fn_Clock->TableClockPayLog).' L where L.state = 1';
	return DB::result_first($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where){
	global $Fn_Clock;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Clock->TableClockPayLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>