<?php
/**
 *	[【飞鸟】打卡(fn_clock.{modulename})] (C)2016-2099 Powered by 飞鸟工作室.
 *	Version: 1.0
 *	Date: 2017-10-3 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_clock/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_clock/Common.php');
if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){
	@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
	$PayList = $FnPay->GetPayList();
}
if($WxApp){//微信分享
	$Fn_Clock->Config['SignPackage'] = $Fn_Clock->WeixinGetSignPackage();
}

/* 电脑二维码访问 */
if(!checkmobile() && $Fn_Clock->Config['PluginVar']['PcQrSwitch']){
	$PcUrl = $_G[siteurl].'plugin.php?id=fn_clock';
	$QrSize = 5;
	$Dir = 'data/cache/qrcode/';//存储路径
	$File = $Dir.'fn_clock.jpg';
	if(!file_exists($File) || !filesize($File)) {
		dmkdir($Dir);
		require_once DISCUZ_ROOT.'source/plugin/fn_clock/qrcode.class.php';
		QRcode::png($PcUrl, $File, QR_ECLEVEL_L, $QrSize);
	}
	$QrCode = base64_encode(file_get_contents($File));
	unlink($File);
	include template('fn_clock:index_qrcode');
	exit();
}
/* 电脑二维码访问 End */

/* 微信内访问 */
if(!$WxApp && $Fn_Clock->Config['PluginVar']['WxSwitch']){
	$navtitle = $metakeywords = $metadescription = $Fn_Clock->Config['LangVar']['Text86'];
	include template('fn_clock:nowx');
	exit();
}
/* 微信内访问 */

$_GET['m'] = empty($_GET['m']) ? 'index' : $_GET['m'];//初始化模板
//登录
if($_GET['m'] == 'user'){
	if(!$_G['uid']){
		if($Appbyme){//小云登录
			exit('
				<script language="javascript" src="source/plugin/fn_clock/static/js/appbyme.js"></script>
				<script>
				connectSQJavascriptBridge(function(bridge){
					sq.login(function(userInfo){
						if(userInfo.userId != 0){
							sq.logout(function(info){
								alert("'.$Fn_Clock->Config[LangVar][AppBymeErr].'");
							});
						}else{
							window.location.reload(true);
						}
					});
				});
				</script>
			');
		}else if($MagApp){//马甲登录
			exit('
				<script src="source/plugin/fn_clock/static/js/mag.js"></script>
				<script>
					mag.toLogin(function(rs){
						window.location.reload(true);
					});
				</script>
			');
		}else if($QFApp){//千帆登录
			exit('
				<script>
				function QFH5ready(){
					QFH5.jumpLogin(function(state,data){
						if(state==1){
							QFH5.refresh(1);
						}else{
							alert(data.error);//data.error: string
						}
					});
				}
				</script>
			');			
		}else{
			if(checkmobile()){
				header("HTTP/1.1 303 See Other");
				Header("Location: member.php?mod=logging&action=login"); 
			}else{
				showmessage('to_login', '', array(), array('showmsg' => true,'login' => 1));
				exit();
			}
		}
	}
}

$UserInfo = $Fn_Clock->GetUserInfo($_G['uid']);//用户资料
$Fn_Clock->Config['LangVar']['Text92'] = str_replace(array('{Money}'),array($UserInfo['IncomeMoneyCount']),$Fn_Clock->Config['LangVar']['Text92']);
$Fn_Clock->GetClockSettlementMoney();//结算每天瓜分打卡金额
$TomorrowMoneyCount = $ShareMoneyCount = $Fn_Clock->GetTomorrowMoneyCount();//明日瓜分金额
if($Fn_Clock->Sponsor){
	$ShareMoneyCount = $Fn_Clock->Config['PluginVar']['SponsorFictitiousMoney'] ? $Fn_Clock->Config['PluginVar']['SponsorFictitiousMoney'] + $ShareMoneyCount : $Fn_Clock->Config['PluginVar']['SponsorMoney'] + $ShareMoneyCount;
}

$Fn_Clock->Config['WxShare']['WxTitle'] = str_replace(array('{InvestmentMoneyCount}','{IncomeMoneyCount}','{ClockCount}','{Money}'),array($UserInfo['InvestmentMoneyCount'],$UserInfo['IncomeMoneyCount'],$UserInfo['ClockCount'],$ShareMoneyCount),$Fn_Clock->Config['PluginVar']['WxTitle']);
$Fn_Clock->Config['WxShare']['WxDes'] = str_replace(array('{InvestmentMoneyCount}','{IncomeMoneyCount}','{ClockCount}','{Money}'),array($UserInfo['InvestmentMoneyCount'],$UserInfo['IncomeMoneyCount'],$UserInfo['ClockCount'],$ShareMoneyCount),$Fn_Clock->Config['PluginVar']['WxDes']);

if($_GET['m'] == 'user'){//会员中心
	$navtitle = $metakeywords = $metadescription = $Fn_Clock->Config['LangVar']['Text17'];
	$UserClockList = $Fn_Clock->GetUserClockList();//打卡列表
	$Fn_Clock->Config['WxShare']['WxTitle'] = $Fn_Clock->Config['PluginVar']['RecordTitle'] ? str_replace(array('{InvestmentMoneyCount}','{IncomeMoneyCount}','{ClockCount}','{Money}'),array($UserInfo['InvestmentMoneyCount'],$UserInfo['IncomeMoneyCount'],$UserInfo['ClockCount'],$ShareMoneyCount),$Fn_Clock->Config['PluginVar']['RecordTitle']) : $Fn_Clock->Config['WxShare']['WxTitle'];//分享标题

	$Fn_Clock->Config['WxShare']['WxDes'] = $Fn_Clock->Config['PluginVar']['RecordDes'] ? str_replace(array('{InvestmentMoneyCount}','{IncomeMoneyCount}','{ClockCount}','{Money}'),array($UserInfo['InvestmentMoneyCount'],$UserInfo['IncomeMoneyCount'],$UserInfo['ClockCount'],$ShareMoneyCount),$Fn_Clock->Config['PluginVar']['RecordDes']) : $Fn_Clock->Config['WxShare']['WxDes'];//分享描述

	$Fn_Clock->Config['WxShare']['WxUrl'] = $Fn_Clock->Config['PluginVar']['SharePageSwitch'] && $_G['uid'] ? $Fn_Clock->Config['ShareUrl'] : $Fn_Clock->Config['WxShare']['WxUrl'];

	//广告图
	$Ad = array_filter(explode("\n",$Fn_Clock->Config['PluginVar']['UserAd']));

}else if($_GET['m'] == 'rule'){//规则
	$navtitle = $metakeywords = $metadescription = $Fn_Clock->Config['LangVar']['Text24'];
}else if($_GET['m'] == 'payok'){//支付成功
	$navtitle = $metakeywords = $metadescription = $Fn_Clock->Config['LangVar']['Text26'];

	$PayOkText = $Fn_Clock->Config['LangVar']['Text26'];
	$PayOkPrompt = str_replace(array('{StartTime}','{EndTime}'),array($Fn_Clock->Config['PluginVar']['StartTime'],$Fn_Clock->Config['PluginVar']['EndTime']),$Fn_Clock->Config['LangVar']['Text59']);
}else if($_GET['m'] == 'mag'){//马甲支付
	$Subject = $navtitle = $metadescription = $metakeywords = $Fn_Clock->Config['LangVar']['Text13'];
	$ClockUid = $Fn_Clock->GetFirstClockUid();
	if($ClockUid){
		if($Fn_Clock->GetDelClockUid()){
			$_GET['m'] = 'payok';
			$navtitle = $metakeywords = $metadescription = $Fn_Clock->Config['LangVar']['Text26'];
			$PayOkText = $Fn_Clock->Config['LangVar']['Text26'];
			$PayOkPrompt = str_replace(array('{StartTime}','{EndTime}'),array($Fn_Clock->Config['PluginVar']['StartTime'],$Fn_Clock->Config['PluginVar']['EndTime']),$Fn_Clock->Config['LangVar']['Text59']);
		}
	}else{
		$Subject = diconv($Subject,CHARSET,'UTF-8');
		$MagWalletType = unserialize($Fn_Clock->Config['PluginVar']['MagWalletType']);
		$wallet = in_array('1',$MagWalletType) ? 1 : 0 ;
		$alipay = in_array('2',$MagWalletType) ? 1 : 0 ;
		$weixin = in_array('3',$MagWalletType) ? 1 : 0 ;
		$ClockPayLog = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Clock->TableClockPayLog).' where uid = '.intval($_G['uid']).' and state = 0 and type = \'mag\' order by id DESC');
		if($ClockPayLog){
			$MagOrder['data']['unionOrderNum'] = $ClockPayLog['pubid'];
			$MagOrder['data']['trade_no'] = $ClockPayLog['order_id'];
		}else{
			$MagOrder = $Fn_Clock->GetAjaxMagOrder($_G['uid'],$Fn_Clock->Config['PluginVar']['Money'],$Subject);
			if($MagOrder['data']['unionOrderNum']){
				$PayLog = $Fn_Clock->GetInsertPayLog($MagOrder['data']['unionOrderNum'],$MagOrder['data']['trade_no'],'app','mag');
			}
		}
	}
}else if($_GET['m'] == 'ranking'){//排行榜
	$navtitle = $metadescription = $metakeywords = $Fn_Clock->Config['LangVar']['Text84'];
	$Fn_Clock->Config['PluginVar']['RanKingNum'] = $Fn_Clock->Config['PluginVar']['RanKingNum'] ? $Fn_Clock->Config['PluginVar']['RanKingNum'] : 30;
	$Fn_Clock->Config['WxShare']['WxUrl'] = $Fn_Clock->Config['RankingUrl'];
	$Fn_Clock->Config['WxShare']['WxTitle'] = $Fn_Clock->Config['PluginVar']['RanKingTitle'] ? $Fn_Clock->Config['PluginVar']['RanKingTitle'] : $Fn_Clock->Config['WxShare']['WxTitle'];
	$Fn_Clock->Config['WxShare']['WxDes'] = $Fn_Clock->Config['PluginVar']['RanKingDes'] ? $Fn_Clock->Config['PluginVar']['RanKingDes'] : $Fn_Clock->Config['WxShare']['WxDes'];
	
	//广告图
	$Ad = array_filter(explode("\n",$Fn_Clock->Config['PluginVar']['RanKingAd']));

	if(time() < $Fn_Clock->TodayStartTime || time() > $Fn_Clock->TodayEndTime){
		$ClockSuccessCount = $Fn_Clock->GetClockSuccessCount();//打卡成功人数
		$ClockFailCount = $Fn_Clock->GetClockFailCount();//打卡失败人数
		$TodayMorning = $Fn_Clock->GetTodayMorningFirst();//早起之星
		$Luck = $Fn_Clock->GetLuckFirst();//幸运之星
		$TodayWill = $Fn_Clock->GetTodayWillFirst();//毅力之星
	}else{
		$ClockSuccessCount = $ClockFailCount = 0;
	}
	
	$WillCount = $TodayWill['count'] ? $TodayWill['count'] : 0;
	$WillText = $Fn_Clock->Config['PluginVar']['WillSwitch'] ? str_replace('{Num}',$WillCount,$Fn_Clock->Config['LangVar']['Text102']) : str_replace('{Num}',$WillCount,$Fn_Clock->Config['LangVar']['Text16']);
	
	$Luck['income_money'] = $Luck['income_money'] ? $Luck['income_money'] : '0';

}else if($_GET['m'] == 'index'){

	$navtitle = $Fn_Clock->Config['PluginVar']['Title'];
	$metakeywords = $Fn_Clock->Config['PluginVar']['Keywords'];
	$metadescription = $Fn_Clock->Config['PluginVar']['Description'];
	$TomorrowUserCount = $Fn_Clock->GetTomorrowUserCount();//明日打卡总人数
	$TomorrowUserList = $Fn_Clock->GetTomorrowUserList();//明日参加打卡列表
	$ClockSuccessCount = $Fn_Clock->GetClockSuccessCount();//打卡成功人数
	$ClockFailCount = $Fn_Clock->GetClockFailCount();//打卡失败人数
	$TodayMorning = $Fn_Clock->GetTodayMorningFirst();//早起之星
	$Luck = $Fn_Clock->GetLuckFirst();//幸运之星
	$TodayWill = $Fn_Clock->GetTodayWillFirst();//毅力之星
	if($Fn_Clock->Config['PluginVar']['ShareSwitch'] && $_G['uid']){
		$MyShare = $Fn_Clock->GetShareFirst();
		if($MyShare){
			$CountDays = $Fn_Clock->DiffBetweenTwoDays(date('Y-m-d',$MyShare['dateline']),date('Y-m-d'));
			$ShareState = $CountDays >= $Fn_Clock->Config['PluginVar']['ShareDay'] ? true : false;
		}else{
			$ShareState = true;
		}
		$Fn_Clock->Config['LangVar']['Text95'] = str_replace('{Money}',$Fn_Clock->Config['PluginVar']['Money'],$Fn_Clock->Config['LangVar']['Text95']);
	}
	
	$Fn_Clock->Config['LangVar']['Text1'] = $Fn_Clock->TomorrowJudge ? $Fn_Clock->Config['LangVar']['Text38'] : $Fn_Clock->Config['LangVar']['Text1'];

	$Fn_Clock->Config['LangVar']['Text2'] = str_replace('{Num}',$TomorrowUserCount,$Fn_Clock->Config['LangVar']['Text2']);

	$Fn_Clock->Config['LangVar']['Text8'] = str_replace('{Money}',$Fn_Clock->Config['PluginVar']['Money'],$Fn_Clock->Config['LangVar']['Text8']);

	$WillCount = $TodayWill['count'] ? $TodayWill['count'] : 0;
	$WillText = $Fn_Clock->Config['PluginVar']['WillSwitch'] ? str_replace('{Num}',$WillCount,$Fn_Clock->Config['LangVar']['Text102']) : str_replace('{Num}',$WillCount,$Fn_Clock->Config['LangVar']['Text16']);
	
	
	$SponsorMoney = $Fn_Clock->Config['PluginVar']['SponsorFictitiousMoney'] ? $Fn_Clock->Config['PluginVar']['SponsorFictitiousMoney'] : $Fn_Clock->Config['PluginVar']['SponsorMoney'];
	
	$Fn_Clock->Config['LangVar']['Text34'] = $Fn_Clock->Sponsor ? str_replace(array('{Num}','{SponsorMoney}'),array($TomorrowMoneyCount,'+'.$SponsorMoney),$Fn_Clock->Config['LangVar']['Text34']) : str_replace(array('{Num}','{SponsorMoney}'),array($TomorrowMoneyCount,''),$Fn_Clock->Config['LangVar']['Text34']);
	
	if($Fn_Clock->Config['PluginVar']['SponsorEndTime'] == date('Y-m-d') || $Fn_Clock->Sponsor){
		$Fn_Clock->Config['LangVar']['Text40'] = str_replace(array('{Num}'),array($Fn_Clock->GetTodayMoneyCount() + $SponsorMoney),$Fn_Clock->Config['LangVar']['Text40']);
	}else{
		$Fn_Clock->Config['LangVar']['Text40'] = str_replace(array('{Num}'),array($Fn_Clock->GetTodayMoneyCount()),$Fn_Clock->Config['LangVar']['Text40']);
	}
	
	$Luck['income_money'] = $Luck['income_money'] ? $Luck['income_money'] : '0';
	if($UserInfo['MyClock']['state'] == 1){
		$MyClockDes = $Fn_Clock->TodayJudge ? $Fn_Clock->Config['LangVar']['Text51'] : $Fn_Clock->Config['LangVar']['Text50'];
		$MyClockDes = $UserInfo['MyClock']['income_money'] !== '0.00' ? str_replace('{Num}',$UserInfo['MyClock']['income_money'],$MyClockDes) : $Fn_Clock->Config['LangVar']['Text54'];
	}else if($UserInfo['MyClock']['state'] == 2){
		$MyClockDes = $Fn_Clock->TodayJudge ? $Fn_Clock->Config['LangVar']['Text53'] : $Fn_Clock->Config['LangVar']['Text52'];
	}
	//第一次访问页面
	$Fn_Clock->Config['LangVar']['FixedMaskRuleContent'] = str_replace(array('{Money}','{StartTime}','{EndTime}'),array($Fn_Clock->Config['PluginVar']['Money'],$Fn_Clock->Config['PluginVar']['StartTime'],$Fn_Clock->Config['PluginVar']['EndTime']),$Fn_Clock->Config['LangVar']['FixedMaskRuleContent']);

	//支付标题
	$PayTitle = $Fn_Clock->Config['LangVar']['Text28'];

	//广告图
	$Ad = array_filter(explode("\n",$Fn_Clock->Config['PluginVar']['BottomAd']));

	if($Fn_Clock->Config['PluginVar']['FictitiousSwitch']){//虚拟数据
		$Fn_Clock->GetFictitious();
	}

	//晒战绩
	$Fn_Clock->Config['WxShare']['WxRecordTitle'] = $Fn_Clock->Config['PluginVar']['RecordTitle'] ? str_replace(array('{InvestmentMoneyCount}','{IncomeMoneyCount}','{ClockCount}','{Money}'),array($UserInfo['InvestmentMoneyCount'],$UserInfo['IncomeMoneyCount'],$UserInfo['ClockCount'],$ShareMoneyCount),$Fn_Clock->Config['PluginVar']['RecordTitle']) : $Fn_Clock->Config['WxShare']['WxTitle'];//分享标题
	$Fn_Clock->Config['WxShare']['WxRecordDes'] = $Fn_Clock->Config['PluginVar']['RecordDes'] ? str_replace(array('{InvestmentMoneyCount}','{IncomeMoneyCount}','{ClockCount}','{Money}'),array($UserInfo['InvestmentMoneyCount'],$UserInfo['IncomeMoneyCount'],$UserInfo['ClockCount'],$ShareMoneyCount),$Fn_Clock->Config['PluginVar']['RecordDes']) : $Fn_Clock->Config['WxShare']['WxDes'];//分享描述
	$Fn_Clock->Config['WxShare']['WxRecordUrl'] = $Fn_Clock->Config['PluginVar']['SharePageSwitch'] && $_G['uid'] ? $Fn_Clock->Config['ShareUrl'] : $Fn_Clock->Config['WxShare']['WxUrl'];
}else if($_GET['m'] == 'share'){//分享

	$HeUserInfo = $Fn_Clock->GetUserInfo($_GET['userid']);//用户资料
	$ShareToday = $Fn_Clock->TodayJudge ? $Fn_Clock->Config['LangVar']['Text105'] : $Fn_Clock->Config['LangVar']['Text104'];
	//广告图
	$SharePageCalendarArray = array_filter(explode("\n",$Fn_Clock->Config['PluginVar']['SharePageCalendar']));
	$SharePageCalendar = $SharePageCalendarArray[date('j') - 1] ? array_filter(explode('|',$SharePageCalendarArray[date('j') - 1])) : '';
	$navtitle = $Fn_Clock->Config['PluginVar']['RecordTitle'] ? str_replace(array('{InvestmentMoneyCount}','{IncomeMoneyCount}','{ClockCount}','{Money}'),array($HeUserInfo['InvestmentMoneyCount'],$HeUserInfo['IncomeMoneyCount'],$HeUserInfo['ClockCount'],$ShareMoneyCount),$Fn_Clock->Config['PluginVar']['RecordTitle']) : $Fn_Clock->Config['WxShare']['WxTitle'];//分享标题
}else{
	exit('No Data');
}
include template('fn_clock:'.$_GET['m']);
?>