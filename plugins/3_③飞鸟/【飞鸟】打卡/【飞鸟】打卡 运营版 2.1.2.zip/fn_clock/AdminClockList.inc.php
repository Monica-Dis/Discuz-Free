<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_clock/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_clock/Common.php');
$Operation = in_array($_GET['Operation'], array('Del','OpValue')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&page='.$_GET[page].'&set_time='.$_GET[set_time].'&keyword='.$_GET[keyword].'&display='.$_GET[display].'&state='.$_GET[state].'&order='.$_GET[order];
$OpTimeLogUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminClockTimeLogList';

if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ���� */
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		$StateSelected = array($_GET['state']=>' selected');
		$PayStateSelected = array($_GET['display']=>' selected');
		$OrderSelected = array($_GET['order']=>' selected');
		$CountHtml = $Fn_Clock->Config['PluginVar']['WillSwitch'] ? '' : '<option value="count"'.$OrderSelected['count'].'>'.$Fn_Clock->Config['LangVar']['Text47'].'</option>';
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Clock->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}"></td>
						<th>{$Fn_Clock->Config['LangVar']['Text61']}</th><td><input type="text" class="txt" name="set_time" value="{$_GET['set_time']}" onclick="showcalendar(event, this, 0)"></td>
						<th>{$Fn_Clock->Config['LangVar']['DisplayTitle']}</th>
						<td>
						<select name="display">
							<option value="">{$Fn_Clock->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$PayStateSelected['1']}>{$Fn_Clock->Config['LangVar']['Yes']}</option>
							<option value="0"{$PayStateSelected['0']}>{$Fn_Clock->Config['LangVar']['No']}</option>
						</select>
						</td>
						<th>{$Fn_Clock->Config['LangVar']['StateTitle']}</th>
						<td>
						<select name="state">
							<option value="">{$Fn_Clock->Config['LangVar']['SelectNull']}</option>
							<option value="0"{$StateSelected['0']}>{$Fn_Clock->Config['LangVar']['ClockState']['0']}</option>
							<option value="1"{$StateSelected['1']}>{$Fn_Clock->Config['LangVar']['ClockState']['1']}</option>
							<option value="2"{$StateSelected['2']}>{$Fn_Clock->Config['LangVar']['ClockState']['2']}</option>
						</select>
						</td>

						<th>{$Fn_Clock->Config['LangVar']['SortTitle']}</th>
						<td>
						<select name="order">
							<option value="">{$Fn_Clock->Config['LangVar']['SelectNull']}</option>
							<option value="id"{$OrderSelected['id']}>{$Fn_Clock->Config['LangVar']['TimeTitle']}</option>
							<option value="clock_time"{$OrderSelected['clock_time']}>{$Fn_Clock->Config['LangVar']['Text44']}</option>
							<option value="income_money"{$OrderSelected['income_money']}>{$Fn_Clock->Config['LangVar']['Text46']}</option>
							{$CountHtml}
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Clock->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = in_array($_GET['order'], array('id','clock_time','income_money','count')) ? 'C.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'C.id';
		if($_GET['keyword']){
			$Where .= ' and concat(C.username,C.uid) like(\'%'.addslashes(dhtmlspecialchars($_GET[keyword])).'%\')';
		}
		if($_GET['set_time']){
			$Where .= ' and C.set_time = '.strtotime(date('Y-m-d '.$Fn_Clock->Config['PluginVar']['EndTime'],strtotime($_GET['set_time'])));
		}
		if($_GET['state'] === '0' || $_GET['state'] === '1' || $_GET['state'] === '2'){
			$Where .= ' and C.state = '.intval($_GET['state']);
		}
		if($_GET['display'] === '0' || $_GET['display'] === '1'){
			$Where .= ' and C.display = '.intval($_GET['display']);
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		if($Fn_Clock->Config['PluginVar']['WillSwitch']){
			$TdStyle = array('width="80"', 'width="50"','width="80"','width="80"','width="120"','width="60"','width="100"','width="80"','width="120"');
		}else{
			$TdStyle = array('width="80"', 'width="50"','width="80"','width="80"','width="120"','width="60"','width="100"','width="100"','width="80"','width="120"');
		}
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'QiangLouModule', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_Clock->Config['LangVar']['InfoListTitle']);
		if($Fn_Clock->Config['PluginVar']['WillSwitch']){
			showsubtitle(array(
				'ID',
				'Uid',
				$Fn_Clock->Config['LangVar']['UserNameTitle'],
				$Fn_Clock->Config['LangVar']['Text46'],
				/*$Fn_Clock->Config['LangVar']['Text48'],*/
				$Fn_Clock->Config['LangVar']['Text44'],
				$Fn_Clock->Config['LangVar']['StateTitle'],
				$Fn_Clock->Config['LangVar']['Text49'],
				$Fn_Clock->Config['LangVar']['DisplayTitle'],
				$Fn_Clock->Config['LangVar']['TimeTitle'],
				$Fn_Clock->Config['LangVar']['OperationTitle']
			), 'header tbm',$TdStyle);
		}else{
			showsubtitle(array(
				'ID',
				'Uid',
				$Fn_Clock->Config['LangVar']['UserNameTitle'],
				$Fn_Clock->Config['LangVar']['Text46'],
				/*$Fn_Clock->Config['LangVar']['Text48'],*/
				$Fn_Clock->Config['LangVar']['Text44'],
				$Fn_Clock->Config['LangVar']['StateTitle'],
				$Fn_Clock->Config['LangVar']['Text49'],
				$Fn_Clock->Config['LangVar']['Text47'],
				$Fn_Clock->Config['LangVar']['DisplayTitle'],
				$Fn_Clock->Config['LangVar']['TimeTitle'],
				$Fn_Clock->Config['LangVar']['OperationTitle']
			), 'header tbm',$TdStyle);
		}
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($ModulesList as $Module) {
			$OpPayStateHtml = !$Module['display'] ? '<a href="'.$OpCpUrl.'&Operation=OpValue&cid='.$Module['id'].'&display_t=1&formhash='.FORMHASH.'">'.$Fn_Clock->Config['LangVar']['DisplayIsTitle'].'</a>&nbsp;&nbsp;' : '<a href="'.$OpCpUrl.'&Operation=OpValue&cid='.$Module['id'].'&display_t=0&formhash='.FORMHASH.'">'.$Fn_Clock->Config['LangVar']['DisplayNoTitle'].'</a>&nbsp;&nbsp;';
			if($Fn_Clock->Config['PluginVar']['WillSwitch']){
				showtablerow('', array('class="td25"', 'class="td28"'), array(
					'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'],
					$Module['uid'],
					$Module['username'] ? $Module['username'] : $Module['musername'],
					$Module['income_money'],
					/*$Module['money'],*/
					$Module['clock_time'] ? date('Y-m-d H:i',$Module['clock_time']) : '',
					$Fn_Clock->Config['LangVar']['ClockState'][$Module['state']],
					$Module['display_even'] ? $Fn_Clock->Config['LangVar']['Yes']:'<span style="color:red">'.$Fn_Clock->Config['LangVar']['No'].'</span>',
					$Module['display'] ? $Fn_Clock->Config['LangVar']['Yes']:'<span style="color:red">'.$Fn_Clock->Config['LangVar']['No'].'</span>',
					date('Y-m-d H:i',$Module['dateline']),
					$OpPayStateHtml.'<a href="'.$OpTimeLogUrl.'&cid='.$Module['id'].'">'.$Fn_Clock->Config['LangVar']['Text78'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&cid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Clock->Config['LangVar']['DelTitle'].'</a>'
				));
			}else{
				showtablerow('', array('class="td25"', 'class="td28"'), array(
					'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'],
					$Module['uid'],
					$Module['username'] ? $Module['username'] : $Module['musername'],
					$Module['income_money'],
					/*$Module['money'],*/
					$Module['clock_time'] ? date('Y-m-d H:i',$Module['clock_time']) : '',
					$Fn_Clock->Config['LangVar']['ClockState'][$Module['state']],
					$Module['display_even'] ? $Fn_Clock->Config['LangVar']['Yes']:'<span style="color:red">'.$Fn_Clock->Config['LangVar']['No'].'</span>',
					$Module['count'],
					$Module['display'] ? $Fn_Clock->Config['LangVar']['Yes']:'<span style="color:red">'.$Fn_Clock->Config['LangVar']['No'].'</span>',
					date('Y-m-d H:i',$Module['dateline']),
					$OpPayStateHtml.'<a href="'.$OpTimeLogUrl.'&cid='.$Module['id'].'">'.$Fn_Clock->Config['LangVar']['Text78'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&cid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Clock->Config['LangVar']['DelTitle'].'</a>'
				));
			}

		}
		showsubmit('Submit','submit','del','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter();/*Dism��taobao��com*/
		showformfooter();
		showtagfooter('div');
		echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_Clock->TableClockLog,'cid ='.$Val);
				DB::delete($Fn_Clock->TableClock,'id ='.$Val);
			}
			cpmsg($Fn_Clock->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_Clock->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Operation == 'OpValue' && $_GET['formhash'] == formhash() && $_GET['cid']){
	$Cid = intval($_GET['cid']);
	$Data['display'] = intval($_GET['display_t']);
	DB::update($Fn_Clock->TableClock,$Data,'id = '.$Cid);
	cpmsg($Fn_Clock->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['cid']){
	$Cid = intval($_GET['cid']);
	DB::delete($Fn_Clock->TableClockLog,'cid ='.$Cid);
	DB::delete($Fn_Clock->TableClock,'id ='.$Cid);
	cpmsg($Fn_Clock->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}
/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Clock;
	$FetchSql = 'SELECT M.username as musername,C.* FROM '.DB::table($Fn_Clock->TableClock).' C LEFT JOIN '.DB::table('common_member').' M on M.uid = C.uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ���� */
function GetModulesCount($Where){
	global $Fn_Clock;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Clock->TableClock).' C '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao-com
?>