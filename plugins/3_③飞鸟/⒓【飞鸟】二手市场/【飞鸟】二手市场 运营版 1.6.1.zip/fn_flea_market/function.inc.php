<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class Fn_Flea_Market{
	public function __construct() {
		global $_G;
		loadcache('plugin');
		$this->Config[PluginVar] = (array) $_G['cache']['plugin']['fn_flea_market'];
		$this->Config[ExtcreditTilte] = $_G[setting][extcredits][$this->Config[PluginVar][extcredit_type]][title];
		$this->Address = $this->SelectArray($this->Config[PluginVar][address]);
		$this->Config[LangVar] = lang('plugin/fn_flea_market');
		$this->Config[Path] = 'source/plugin/fn_flea_market';
		$this->Config[StaticPath] = $this->Config[Path].'/static';
		$this->Config[StaticPicPath] = $this->Config[Path].'/attachment/';
		$this->Config[Url] = $_G[siteurl].'plugin.php?id=fn_flea_market';
		$this->Config[ClassUrl] = $this->Config[Url].'&m=class';
		$this->Config[InfoUrl] = $this->Config[Url].'&m=info&iid=';
		$this->Config[ListUrl] = $this->Config[Url].'&m=list&classid=';
		$this->Config[AddUrl] = $this->Config[Url].'&m=add';
		$this->Config[UserUrl] = $this->Config[Url].'&m=user';
		$this->Config[PayUrl] = empty($this->Config[PluginVar][pay_link]) ?   $this->Config[Url].'&m=pay':$this->Config[PluginVar][pay_link];
		$this->Config[UserCollectUrl] = $this->Config[Url].'&m=user_collect';
		$this->Config[UserInfoEditUrl] = $this->Config[Url].'&m=user_info_edit';
		$this->Config[HeUserUrl] = $this->Config[Url].'&m=he_user&uid=';
		$this->Config[AjaxUrl] = $this->Config[Url].':ajax';
		$this->Config[WxShare] = array(
			'WxTitle' => $this->Config[PluginVar][wx_title],
			'WxDes' => $this->Config[PluginVar][wx_des],
			'WxImg' => $_G[siteurl].$this->Config[PluginVar][wx_img],
			'WxUrl' => $this->Config[Url]
		);
		if(!is_dir(DISCUZ_ROOT.$this->Config[StaticPicPath])){
			mkdir(DISCUZ_ROOT.$this->Config[StaticPicPath]);
		}
		$this->TableBanner = 'fn_flea_market_banner';
		$this->TableClass = 'fn_flea_market_class';
		$this->TableInfo = 'fn_flea_market_info';
		$this->TablePay = 'fn_flea_market_pay';
		$this->TableMemberProfile = 'fn_member_profile';
		$this->TableCollect = 'fn_flea_market_collect';
	}
	/* �������� */
	public function GetAddInfo($Post){
		global $_G;
		require_once 'ImageCrop.Class.php';
		require_once (DISCUZ_ROOT.'./source/class/discuz/discuz_upload.php');
		$UpLoad = new discuz_upload();
		$Ins = array();
		$data = array();
		$UserInfo = $this->GetUserInfo($_G[uid]);
		$Post = $this->ArrayAddslashes($this->StrToGBK($Post));
		$Ins[uid] = $_G[uid];
		$Ins[title] = $Post[title];
		$Ins[mobile] = $Post[mobile];
		$Ins[wx] = $Post[wx];
		$Ins[qq] = $Post[qq];
		$Ins[realname] = $Post[realname];
		$Ins[classid] = $Post[classid];
		$Ins[type] = $Post[type];
		$Ins[classid] = end(explode(',',$Post[classid]));
		$Ins[address] = end(explode(',',$Post[address]));
		$Ins[degree] = $Post[degree];
		$Ins[money] = $Post[money];
		$Ins[body] = $Post[body];
		$Ins[time] = time();
		$Ins[display] = 1;
		$AddOk = $this->Config[LangVar][AddOk];
		if($this->Config[PluginVar][add_switch] == 1){
			$Ins[display] = 0;
			$AddOk = $this->Config[LangVar][AddOkToExamine];
		}
		if(!empty($Post[sticktime])){
			$StickArray = explode('_',$Post[sticktime]);
			$Ins[sticktime] = strtotime("+".$StickArray[0]." hour");
			$ExtcreditNum = $this->Config[PluginVar][extcredit_num] + $StickArray[1];
		}else{
			$ExtcreditNum = $this->Config[PluginVar][extcredit_num];
		}
		if(!in_array($_G[member][groupid],unserialize($this->Config[PluginVar][user_group]))){//�û���Ȩ��
			$data[status] = $this->StrToGBK($this->Config[LangVar][UserGroupErr],true);
			return json_encode($data);
		}
		if($UserInfo[ExtcreditNumber] < $ExtcreditNum){//���ּ��
			$data[status] = $this->StrToGBK(str_replace('{ExtcreditText}',$this->Config[ExtcreditTilte],$this->Config[LangVar][ExtcreditNumErr]),true);
			return json_encode($data);
		}
		if(!$Ins[title]){//������
			$data[status] = $this->StrToGBK($this->Config[LangVar][TitleErr],true);
			return json_encode($data);
		}
		if(!$Ins[classid]){//������
			$data[status] = $this->StrToGBK($this->Config[LangVar][ClassErr],true);
			return json_encode($data);
		}
		if(!$Ins[address]){//��ַ���
			$data[status] = $this->StrToGBK($this->Config[LangVar][AddressErr],true);
			return json_encode($data);
		}
		if(!$Ins[degree]){//�¾ɳ̶ȼ��
			$data[status] = $this->StrToGBK($this->Config[LangVar][DegreeErr],true);
			return json_encode($data);
		}
		if(!$Ins[money]){//�����۸���
			$data[status] = $this->StrToGBK($this->Config[LangVar][MoneyErr],true);
			return json_encode($data);
		}
		/*if(empty($Ins[body])){//����������
			$data[status] = $this->StrToGBK($this->Config[LangVar][BodyErr],true);
			return json_encode($data);
		}*/

		if($Post['thumbnailnew']['0']) {
			$Ins['thumbnail'] = addslashes(strip_tags($Post['thumbnailnew']['0']));
			if(strpos($Ins['thumbnail'],'http') === false){
				$Ic=new ImageCrop(DISCUZ_ROOT.$Ins['thumbnail'],DISCUZ_ROOT.$Ins['thumbnail']); 
				$Ic->Crop($this->Config[PluginVar][tailor_width],$this->Config[PluginVar][tailor_height],1); 
				$Ic->SaveImage();
				$Ic->destory();
			}
		}else if($Post['thumbnail_new_arr']){
			$Ins['thumbnail'] = $Post['thumbnail_new_arr'];
		}else{
			$data[status] = $this->StrToGBK($this->Config[LangVar][ThumbnaiErr],true);
			return json_encode($data);
		}
		if($Ins['type'] == 1){
			if(is_array($Post['detailspic_orientation']) && isset($Post['detailspic_orientation'])){
				$Ins['detailspic'] = addslashes(strip_tags(implode(',',$Post['detailspic_orientation'])));
			}else if($Post['detailspic_orientation_arr']){
				$Ins['detailspic'] = addslashes(strip_tags($Post['detailspic_orientation_arr']));
			}else{
				$data[status] = $this->StrToGBK($this->Config[LangVar][DetailsPicErr],true);
				return json_encode($data);
			}
		}

		if(DB::insert($this->TableInfo,$Ins)){
			updatemembercount($Ins[uid],array("extcredits".$this->Config[PluginVar][extcredit_type] => -$ExtcreditNum));
			$data[status] = $this->StrToGBK($AddOk,true);
			$data[state] = 1;
			return json_encode($data);
		}else{
			$data[status] = $this->StrToGBK($this->Config[LangVar][AddErr],true);
			return json_encode($data);
		}

	}
	/* ��ҳ�б� */
	public function GetHomeList($Classid){
		$Where = ' where display = 1 and classid in('.$Classid.')'.'AND state = 0 and display = 1';
		if($this->Config[PluginVar][home_type]){
			$Where .= ' and type = '.$this->Config[PluginVar][home_type];
		}
		if($this->Config[PluginVar][home_order] == 'stick_rand'){
			$Where .= ' and sticktime > '.time();
			$Order = 'RAND()';
		}else if($this->Config[PluginVar][home_order] == 'stick_time'){
			$Where .= ' and sticktime > '.time();
			$Order = ' time desc';
		}else if($this->Config[PluginVar][home_order] == 'time'){
			$Order = ' time desc';
		}else if($this->Config[PluginVar][home_order] == 'collectcount'){
			$Order = ' collect_count desc';
		}else if($this->Config[PluginVar][home_order] == 'click'){
			$Order = ' click desc';
		}
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableInfo).$Where.' order by '.$Order.' limit '.$this->Config[PluginVar][home_num];
		return $this->GetInfoReplace(DB::fetch_all($FetchSql));
	}
	/* ������Ϣ */
	public function GetInfo($Id){
		$Id = $this->ArrayAddslashes($Id);
		$FirstSql = 'SELECT M.username,FP.*,P.*,I.* FROM '.DB::table($this->TableInfo).' I LEFT JOIN '.DB::table('common_member_profile').' P on P.uid = I.uid LEFT JOIN  '.DB::table($this->TableMemberProfile).' FP on FP.uid = I.uid LEFT JOIN  '.DB::table('common_member').' M on M.uid = I.uid where I.id ='.$Id;
		$InfoArray[] = DB::fetch_first($FirstSql);
		$InfoArray = $this->GetInfoReplace($InfoArray);
		return $InfoArray[0];
	}
	/* �����ֿ� */
	public function GetLikeList($Classid,$Type){
		foreach ($this->Config[LangVar][TypeList] as $key => $val) {
			if($Type == $val){
				$Type = $key;
			}
		}
		$Where = ' where classid = '.$Classid.' and type = '.$Type . ' AND state = 0 and display = 1';
		if($this->Config[PluginVar][like_order] == 'stick_rand'){
			$Where .= ' and sticktime > '.time();
			$Order = 'RAND()';
		}else if($this->Config[PluginVar][like_order] == 'stick_time'){
			$Where .= ' and sticktime > '.time();
			$Order = ' time desc';
		}else if($this->Config[PluginVar][like_order] == 'time'){
			$Order = ' time desc';
		}else if($this->Config[PluginVar][like_order] == 'collectcount'){
			$Order = ' collect_count desc';
		}else if($this->Config[PluginVar][like_order] == 'click'){
			$Order = ' click desc';
		}
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableInfo).$Where.' order by '.$Order.' limit '.$this->Config[PluginVar][like_num];
		return $this->GetInfoReplace(DB::fetch_all($FetchSql));
	}
	/* �ҵ��ղ�InfoId */
	public function GetFirstMyCollectArray($Uid){
		$Uid = $this->ArrayAddslashes($Uid);
		$FetchSql = 'SELECT info_id FROM '.DB::table($this->TableCollect).' where uid = '.$Uid.' order by id desc';
		$MyCollectArray =  DB::fetch_all($FetchSql);
		foreach ($MyCollectArray as $key => $val) {
			$MyCollectInfoIdArray[] = $MyCollectArray[$key][info_id];
		}
		return $MyCollectInfoIdArray;
	}
	/* �ղر��� */
	public function GetAjaxMyCollect($Uid,$Id){
		$Uid = $this->ArrayAddslashes($Uid);
		$Id = $this->ArrayAddslashes($Id);
		$FirstSql= 'SELECT * FROM '.DB::table($this->TableCollect).' where uid = '.$Uid.' and info_id = '.$Id;
		$MyCollect = DB::fetch_first($FirstSql);
		$Info =  DB::fetch_first('SELECT * FROM '.DB::table($this->TableInfo).' where id = '.$Id);
		if(empty($MyCollect) && $Info){
			$Ins[uid] = $Uid;
			$Ins[info_id] = $Id;
			$Ins[type] = $Info[type];
			if(DB::insert($this->TableCollect,$Ins) && DB::query("UPDATE ".DB::table($this->TableInfo)." SET collect_count = collect_count+1 WHERE id=$Id")){
				$Results = 1;
			}
		}else{
			if(DB::delete($this->TableCollect,'info_id = '.$Id.' and uid = '.$Uid) && DB::query("UPDATE ".DB::table($this->TableInfo)." SET collect_count = collect_count-1 WHERE id=$Id")){
				$Results = 0;
			}
		}
		return json_encode($Results);
	}
	/* ��������� */
	public function Click($Table,$Id){
		$Table = $this->ArrayAddslashes($Table);
		$Id = $this->ArrayAddslashes($Id);
		DB::query("UPDATE ".DB::table($Table)." SET click = click+1 WHERE id=$Id");
	}
	/* �û����� */
	public function GetUserInfo($Uid){
		$Uid = $this->ArrayAddslashes($Uid);
		$FirstSql = 'SELECT fp.*,m.*,p.*,c.extcredits1,c.extcredits2,c.extcredits3,c.extcredits4,c.extcredits5,c.extcredits6,c.extcredits7,c.extcredits8 FROM '.DB::table('common_member').' m LEFT JOIN '.DB::table($this->TableMemberProfile).' fp on fp.uid = '.$Uid.' LEFT JOIN '.DB::table('common_member_count').' c on c.uid = '.$Uid.' LEFT JOIN '.DB::table('common_member_profile').' p on p.uid = '.$Uid.' where m.uid = '.$Uid;
		$UserInfo = DB::fetch_first($FirstSql);
		$UserInfo[ExtcreditNumber] = $UserInfo[extcredits.$this->Config[PluginVar][extcredit_type]];
		return $UserInfo;
	}
	/* �޸��û����� */
	public function GetUserInfoEdit($Post){
		global $_G;
		$DzMPIns = array();
		$FnMPIns = array();
		$Data = array();
		$Post = $this->ArrayAddslashes($this->StrToGBK($Post));
		$DzMPIns[realname] = $Post[realname];
		$DzMPIns[mobile] = $Post[mobile];
		$DzMPIns[qq] = $Post[qq];
		$FnMPIns[wx] = $Post[wx];
		$FnBemberProfile = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMemberProfile).' where uid = '.$_G[uid]);
		if(empty($FnBemberProfile)){
			$Member[uid] = $_G[uid];
			DB::insert($this->TableMemberProfile,$Member);
		}
		DB::update($this->TableMemberProfile,$FnMPIns,'uid = '.$_G[uid]);
		DB::update('common_member_profile',$DzMPIns,'uid = '.$_G[uid]);
		$Data[state] = 1;
		return json_encode($Data);
	}
	/* �����б� */
	public function GetAjaxList($Get){
		global $_G;
		$Get = $this->ArrayAddslashes($this->StrToGBK($Get));
		$Where = ' where I.display = 1';
		if(!empty($Get[type])){
			$Where .= ' and I.type = '.$Get[type].' And I.state = 0';
		}
		if(!empty($Get[classid])){
			$Where .= ' and I.classid in('.$this->GetSonClassIds($Get[classid]).')';
		}
		if(!empty($Get[address])){
			$AddressArray = $this->GetSonSelectIds($this->Address,$Get[address]);
			$AddressArray[] =  $Get[address];
			$Where .= ' and instr(\''.implode(',',$AddressArray).'\',I.address)';
		}
		if(!empty($Get[degree])){
			$Where .= ' and I.degree = '.$Get[degree];
		}
		if(!empty($Get[money])){
			$MoneyArray = explode('-',$Get[money]);
			$Where .= ' and I.money > '.$MoneyArray[0].' and I.money < '.$MoneyArray[1];
		}
		if(!empty($Get[keywords])){
			$Where .= ' and I.title like(\'%'.$Get[keywords].'%\')';
		}
		if(empty($Get[order])){
			$Order = 'I.time desc';
		}else{
			$DescASC = explode('-',$Get[order]);
			if(!$DescASC[1]){
				$DescASC[1] = 'desc';
			}
			$Order = 'I.'.$DescASC[0].' '.$DescASC[1];
		}
		$FetchSql = 'SELECT C.*,I.* FROM '.DB::table($this->TableInfo).' I LEFT JOIN '.DB::table($this->TableClass).' C ON C.id = I.classid '.$Where.' order by sticktime > '.time().' desc,'.$Order.' limit '.$Get[p] * $this->Config[PluginVar][list_num].','.$this->Config[PluginVar][list_num];
		$Results = $this->StrToGBK($this->GetInfoReplace(DB::fetch_all($FetchSql)),true);
		return json_encode($Results);
	}
	/* �û������б� */
	public function GetAjaxUserList($Get,$Uid){
		global $_G;
		$Uid = $this->ArrayAddslashes($Uid);
		$Get = $this->ArrayAddslashes($this->StrToGBK($Get));
		$Where = ' where I.uid = '.$Uid.' and I.display = 1';
		if(!empty($Get[type])){
			$Where .= ' and I.type = '.$Get[type];
		}
		$FetchSql = 'SELECT C.*,I.* FROM '.DB::table($this->TableInfo).' I LEFT JOIN '.DB::table($this->TableClass).' C ON C.id = I.classid '.$Where.' order by I.id desc';
		$Results = $this->StrToGBK($this->GetInfoReplace(DB::fetch_all($FetchSql)),true);
		return json_encode($Results);
	}
	/* �����ö� */
	public function GetAjaxStick($Get){
		global $_G;
		$Get = $this->ArrayAddslashes($Get);
		$UserInfo = $this->GetUserInfo($_G[uid]);
		if(is_numeric($Get[sticktime]) && is_numeric($Get[integral]) && $UserInfo[ExtcreditNumber] > $Get[integral]){
			$Info = $this->QueryOne($this->TableInfo,$Get[iid]);
			if($Info[sticktime] > time()){
				$UpIns[sticktime] = strtotime("+".$Get[sticktime]." hour",$Info[sticktime]);
			}else{
				$UpIns[sticktime] = strtotime("+".$Get[sticktime]." hour");
			}
			if(DB::update($this->TableInfo,$UpIns,'id = '.$Get[iid].' and uid ='.$_G[uid])){
				updatemembercount($_G[uid],array("extcredits".$this->Config[PluginVar][extcredit_type] => -$Get[integral]));
				$Results[state] = 1;
				$Results[content] = $this->Config[LangVar][StickOk];
			}else{
				$Results[state] = 0;
				$Results[content] = str_replace('extcredit',$this->Config[ExtcreditTilte],$this->Config[LangVar][StickErr]);
			}
		}else{
			$Results[state] = 0;
			$Results[content] = str_replace('extcredit',$this->Config[ExtcreditTilte],$this->Config[LangVar][StickErr]);
		}
		return json_encode($this->StrToGBK($Results,true));
	}
	/* ����ˢ�� */
	public function GetAjaRefresh($Id){
		global $_G;
		$Id = $this->ArrayAddslashes($Id);
		$UserInfo = $this->GetUserInfo($_G[uid]);
		if($UserInfo[ExtcreditNumber] > $this->Config[PluginVar][refresh_extcredit_num]){
			$UpIns[time] = time();
			if(DB::update($this->TableInfo,$UpIns,'id = '.$Id.' and uid ='.$_G[uid])){
				updatemembercount($_G[uid],array("extcredits".$this->Config[PluginVar][extcredit_type] => -$this->Config[PluginVar][refresh_extcredit_num]));
				$Results[state] = 1;
				$Results[content] = $this->Config[LangVar][RefreshOk];
			}else{
				$Results[state] = 0;
				$Results[content] = str_replace('extcredit',$this->Config[ExtcreditTilte],$this->Config[LangVar][RefreshErr]);
			}
		}else{
			$Results[state] = 0;
			$Results[content] = str_replace('extcredit',$this->Config[ExtcreditTilte],$this->Config[LangVar][RefreshErr]);
		}
		return json_encode($this->StrToGBK($Results,true));
	}
	/* ������ת�� */
	public function GetAjaxSetUpSell($Id){
		$Id = intval($Id);
		if($this->EditFields($this->TableInfo,$Id,'type',3) == true){
			$Results = 1;
		}else{
			$Results = 0;
		}
		return json_encode($Results);
	}
	/* ɾ��������Ϣ */
	public function GetAjaxDelInfo($Id){
		$Id = intval($Id);
		$Info = $this->QueryOne($this->TableInfo,$Id);
		if(!$this->Config[PluginVar][DelSwitch]){
			if($this->EditFields($this->TableInfo,$Id,'state',1) == true){
				$Results = 1;
			}else{
				$Results = 0;
			}
		}else{
			if($this->Del($this->TableInfo,$Id) == true){
				$Results = 1;
			}else{
				$Results = 0;
			}
		}
		return json_encode($Results);
	}
	/* �ҵ��ղ� */
	public function GetAjaxCollectList($Type){
		global $_G;
		if($Type){
			$Where = ' and type ='.$Type;
		}
		$FetchSql = 'SELECT info_id FROM '.DB::table($this->TableCollect).' where uid = '.$_G[uid].$Where.' order by id desc';
		$MyInfoIdArray = DB::fetch_all($FetchSql);
		foreach ($MyInfoIdArray as $key => $value) {
			$InfoIdArray[] = $MyInfoIdArray[$key][info_id];
		}
		if(!empty($InfoIdArray)){
			$FetchSql = 'SELECT C.*,I.* FROM '.DB::table($this->TableInfo).' I LEFT JOIN '.DB::table($this->TableClass).' C on C.id = I.classid where I.id in('.implode(',',$InfoIdArray).') and I.display = 1 order by I.id desc';
			$Results = $this->StrToGBK($this->GetInfoReplace(DB::fetch_all($FetchSql)),true);
		}
		return json_encode($Results);
	}
	/* ȡ���ղ� */
	public function GetAjaxDelCollect($Id){
		global $_G;
		$Id = $this->ArrayAddslashes($Id);
		if(DB::delete($this->TableCollect,'info_id ='.$Id.' and uid = '.$_G[uid]) && DB::query("UPDATE ".DB::table($this->TableInfo)." SET collect_count = collect_count-1 WHERE id=$Id")){
			$Results = 1;
		}else{
			$Results = 0;
		}
		return json_encode($Results);
	}
	/* ��Ʒ�ֶ�ת�� */
	public function GetInfoReplace($Array){

		foreach ($Array as $key => $val) {
			$Array[$key][time] = date('Y-m-d',$Array[$key][time]);
			$Array[$key][degree] = $this->Config[LangVar][DegreeList][$Array[$key][degree]];
			$Array[$key][typenum] = $Array[$key][type];
			$Array[$key][type] = $this->Config[LangVar][TypeList][$Array[$key][type]];
			$AddressArray = $this->GetFatherSelectIds($this->Address,$Array[$key][address]);
			$Address = '';
			for($i = 0;$i < count($AddressArray);$i++){
				$Address .=  $this->Address[$AddressArray[$i]][content];
			}
			$Array[$key][address] = $Address;
			if($Array[$key][sticktime] > time()){
				$Array[$key][stick_state] = 1;
			}else{
				$Array[$key][stick_state] = 0;
			}
			if(!empty($Array[$key][sticktime])){
				$Array[$key][sticktime] = date('Y-m-d H:i',$Array[$key][sticktime]);
			}
		}
		return $Array;
	}
	/* SelectArray */
	public function SelectArray($String){
		$Array = explode("\r\n",$String);
		foreach ($Array as $key => $val) {
			$KeyVal = explode("=",$val);
			$SubKey = trim($KeyVal[0]);
			$subvalue = trim($KeyVal[1]);
			$SelectArrayVar = array(
				'content'=>$subvalue,
				'optionid'=>$SubKey,
				'foptionid'=>trim(substr($SubKey, 0, strrpos($SubKey, '.'))) ? trim(substr($SubKey, 0, strrpos($SubKey, '.'))) : '0',
				'count'=>count(explode('.', $SubKey))
			);
			$SubKeyarr = explode('.', $SubKey);
				if($CountSubKeyarr = count($SubKeyarr)) {
					$TmpKey = '';
					for($i = 0;$i < $CountSubKeyarr;$i++) {
						$SubKeyarr[$i] = trim($SubKeyarr[$i]);
						if(isset($SelectArrayVar['level'])) {
							if(($CountSubKeyarr - $i) > $SelectArrayVar['level']) {
								$SelectArrayVar['level'] = $CountSubKeyarr - $i;
							}
						} else {
							$SelectArrayVar['level'] = $CountSubKeyarr - $i;
						}
						$TmpKey .= $SubKeyarr[$i].'.';
					}
				}
			$SelectArray[$SubKey] = $SelectArrayVar;
		}
		ksort($SelectArray);
		foreach ($SelectArray as $key => $val) {
			if(!empty($val[foptionid])){
				$SelectArray[$val[foptionid]][children][] = $val[optionid];
			}
		}
		return $SelectArray;
	}
	//��ȡSelect�ϼ�IDS
	public function GetFatherSelectIds($Array,$Optionid){
		$Arr = array();
        foreach ($Array as $K=>$V) {
			if((string)$Optionid === (string)$K){
				$Arr[] = $V[optionid];
				$Arr = array_merge($this->GetFatherSelectIds($Array,$V['foptionid']),$Arr);
			}
		}
		return $Arr;
    }
	//��ȡSelect�¼�IDS
	public function GetSonSelectIds($Array,$FOptionid){
		$Arr = array();
        foreach ($Array as $K=>$V) {
			if((string)$FOptionid === (string)$V[foptionid]){
				$Arr[] = $V[optionid];
				$Arr = array_merge($this->GetSonSelectIds($Array,$V['optionid']),$Arr);
			}
		}
		return $Arr;
    }
	/* ��ַ���� */
	public function GetShowSelect($Array,$Name='classid',$Shownull=true,$Current=''){
		global $_G;
		$Select = "<select id=\"$Name\" name=\"$Name\" class=\"ps vm\">";
		if($Shownull) {
			$Select .= '<option value="">'.$this->Config[LangVar][SelectNull].'</option>';
		}
		foreach ($Array as $Value) {
			$selected = ($Current && $Current==$Value['optionid']) ? 'selected="selected"' : '';
			if($Value['level'] == 1) {
				$Select .= "<option value=\"$Value[optionid]\"$selected>$Value[content]</option>";
			}else if($Value['level'] == 2) {
				$Select .= "<option value=\"$Value[optionid]\"$selected>-- $Value[content]</option>";
			}else if($Value['level'] == 3) {
				$Select .= "<option value=\"$Value[optionid]\"$selected>---- $Value[content]</option>";
			}
		}
		$Select .= "</select>";
		return $Select;
	}

	/* ȫ������ */
	public function GetAllClass($Display){
		$Display = $this->ArrayAddslashes($Display);
		if(!empty($Display)){
			$Where =  ' where display = '.$Display;
		}
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableClass).$Where.' order by displayorder ASC';
		$AllClassList = DB::fetch_all($FetchSql);
		foreach ($AllClassList as $key => $val) {
			$ReturnClassList[$val[id]] = $AllClassList[$key];
		}
		foreach ($ReturnClassList as $key => $val) {
			if(!empty($val[bclassid])){
				$ReturnClassList[$val[bclassid]][children][] = $val[id];
			}
		}
		return $ReturnClassList;
	}
	/* ��Ŀ���� */
	public function GetClassShowSelect($Array,$Name='classid', $Shownull=true, $Current='',$Tow) {
		global $_G;
		$Select = "<select id=\"$Name\" name=\"$Name\" class=\"ps vm\">";
		if($Shownull) {
			$Select .= '<option value="">'.$this->Config[LangVar][SelectNull].'</option>';
		}
		foreach ($Array as $Value) {
			if($Value['level'] == 0) {
				$selected = ($Current && $Current==$Value['id']) ? 'selected="selected"' : '';
				$Select .= "<option value=\"$Value[id]\"$selected>$Value[name]</option>";
				if(!$Value['children']) {
					continue;
				}
				foreach ($Value['children'] as $ClassId) {
					$selected = ($Current && $Current==$ClassId) ? 'selected="selected"' : '';
					$Select .= "<option value=\"{$Array[$ClassId][id]}\"$selected>-- {$Array[$ClassId][name]}</option>";
					if($Tow != true){
						if($Array[$ClassId]['children']) {
							foreach ($Array[$ClassId]['children'] as $ClassId2) {
								$selected = ($Current && $Current==$ClassId2) ? 'selected="selected"' : '';
								$Select .= "<option value=\"{$Array[$ClassId2][id]}\"$selected>---- {$Array[$ClassId2][name]}</option>";
							}
						}
					}
				}
			}
		}
		$Select .= "</select>";
		return $Select;
	}
	//��ȡ����ĿID��
	public function GetSonClassIds($BClassId){
        $Array[] = $BClassId;
        do{
            $Ids = '';
            $Temp = DB::fetch_all('SELECT id FROM '.DB::table($this->TableClass).' where bclassid in('.$BClassId.')');
            foreach ($Temp as $V)
            {
                $Array[] = $V['id'];
                $Ids .= ','.$V['id'];
            }
            $Ids = substr($Ids, 1, strlen($Ids));
            $BClassId = $Ids;
        }
        while (!empty($Temp));
        $Ids = implode(',', $Array);
        return $Ids;
    }
	/* һά����ת��ά���� */
	public function DyadicArray($Array){
		$DyadicArray = array();
		foreach($Array as $K => $V) {
			$DyadicArray[] = array($K,$V);
		}
		return $DyadicArray;
	}
	/*  ͼƬ�ϴ� */
	public function UploadIconBanner($Files,$DelUsedFiles,$ImageCrop=false,$Type=1,$Width,$Height){
		require_once 'ImageCrop.Class.php';
		require_once (DISCUZ_ROOT.'./source/class/discuz/discuz_upload.php');
		$Upload = new discuz_upload();
		if($Upload->init($Files, 'common') && $Upload->save(1)) {
			$Path = $_G['setting']['attachdir'].'common/'.$Upload->attach['attachment'];
			$Name = explode('/',$Upload->attach['attachment']);
			$MPicUrl = DISCUZ_ROOT.$this->Config[StaticPicPath].$Name[1];
			if(copy($Upload->attach['target'],$MPicUrl)){
				if($ImageCrop && $Width && $Height){
					$Ic=new ImageCrop($MPicUrl,$MPicUrl);
					$Ic->Crop($Width,$Height,$Type); 
					$Ic->SaveImage();
					$Ic->destory();
				}
				$Path = $this->Config[StaticPicPath].$Name[1];
				unlink($Upload->attach['target']);
				unlink(DISCUZ_ROOT.$DelUsedFiles);
			}
			return $Path;
		}
	}
	/* ����ͼ�б� */
	public function GetModulesBanner($Type){
		if(!empty($Type)){
			$Where = ' where type = '.$Type;
		}
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableBanner).$Where.' order by displayorder asc';
		return DB::fetch_all($FetchSql);//��������
	}
	/* ����֧�� */
	public function GetPay($Post){
		global $_G;
		$Post = $this->ArrayAddslashes($this->StrToGBK($Post));
		$ins[uid] = $_G[uid];
		$ins[money] = $Post[Money];
		$ins[givemoney] = $Post[GiveMoney];
		$ins[paytype] = $Post[PayType];
		$ins[establish_time] = time();
		if(!is_numeric($ins[money])){
			$data[status] = $this->StrToGBK($this->Config[LangVar][pay_err],true);
			return json_encode($data);
		}
		$Id = DB::insert($this->TablePay,$ins,true);
		if($Id){
			if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){
				@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
				$PayId = $FnPay->GetInsertPay($Id,$this->Config[ExtcreditTilte].$this->Config[LangVar][PaySubject],'fn_flea_market','ershouchongzhi',$ins[money],$ins[paytype],$_G['siteurl'].'plugin.php?id=fn_flea_market&m=pay&state=ok&orderid=');
			}
			$data[PayUrl] = $_G['siteurl'].'plugin.php?id=fn_pay&payid='.$PayId;
			$data[state] = 1;
			return json_encode($data);
		}else{
			$data[status] = $this->StrToGBK($this->Config[LangVar][pay_err],true);
			return json_encode($data);
		}
	}

	/* ʱ�� */
	public function GetTime($Time,$String){
		if(!empty($Time)){
			if(empty($String)){
				$String = 'Y-m-d H:i:s';
			}
			return date($String,$Time);
		}
	}
	/* ״̬ */
	public function GetState($State){
		if($State == 0){
			$State = '<span style="color:red;">'.$this->Config[LangVar][StateNo].'</span>';
		}else if($State == 1){
			$State = $this->Config[LangVar][StateIs];
		}
		return $State;
	}
	/* ��ѯ���� */
	public function QueryOne($TableName,$Id,$Where){
		$FirstSql = 'SELECT * FROM '.DB::table($TableName).' where id = '.$Id.' '.$Where;
		return DB::fetch_first($FirstSql);	
	}
	/* 
	�޸ı�������
	table_name=>
	ids=>id
	fields=>�ֶ�
    val=>ֵ
	*/
	public function EditFields($TableName,$Ids,$Fields,$Val){
		if(is_array($Ids)){
			$Ids = implode(',',$Ids);
		}else{
			$Ids = $Ids;
		}
		$UpData[$Fields] = $Val;
		if(DB::update($TableName,$UpData,'id in( '.$Ids.' )')){
			return true;
		}else{
			return false;
		}
	}
	/* 
	ɾ������
	table_name=>����
	ids=>id
	*/
	public function Del($TableName,$Ids,$Where){
		if(is_array($Ids)){
			$Ids = implode(',',$Ids);
		}else{
			$Ids = $Ids;
		}
		if(DB::delete($TableName,'id in( '.$Ids.' )'.$Where)){
			return true;
		}else{
			return false;
		}
	}
	public function GetArray($Array,$IdField,$PField){
		$ReturnArray = array();
		foreach($Array as $Item){  
			//�ж��Ƿ������������==  
			if(isset($Array[$Item[$PField]])){     //�������������Ƿ��и÷���  �� isset($Array[0])  isset($Array[1])  
				$Array[$Item[$PField]]['son'][] = &$Array[$Item[$IdField]]; //��������ݱ仯,$ReturnArray�����ֵ�ͱ仯  
			}else{  
				$ReturnArray[] = &$Array[$Item[$IdField]];   //�����ĵ�ַ����$ReturnArray  
			}    
		}
		return $ReturnArray;
	}
	/* GetSelectMobileJs */
	public function GetSelectMobileJs($Array,$SelectArray,$Type){
		$FirstJs = 'var '.$SelectArray[0].' = [';
		$SecondJs = ','.$SelectArray[1].' = {';
		$ThirdJs = ','.$SelectArray[2].' = {';
		if($Type == 'class'){
			$ListArray = $this->GetArray($Array,'id','bclassid');
			$ContentField = 'name';
			$IdField = 'id';
		}else{

			$ListArray = $this->GetArray($Array,'optionid','foptionid');
			$ContentField = 'content';
			$IdField = 'optionid';
		}
		foreach($ListArray  as $K => $V){
			$FirstJsArray[] = "{'value': '$V[$IdField]', 'content': '$V[$ContentField]'}";
			$SecondText = '"'.$V[$IdField].'": [';
			foreach($ListArray[$K][son] as $Key => $Val){
				$SecondValArray[] = "{'value': '$Val[$IdField]', 'content': '$Val[$ContentField]'}";
				$ThirdText = '"'.$Val[$IdField].'": [';
				foreach($ListArray[$K][son][$Key][son] as $TKey => $Value){
					$ThirdValArray[] = "{'value': '$Value[$IdField]', 'content': '$Value[$ContentField]'}";
				}
				$ThirdText = $ThirdText.implode(',',$ThirdValArray)."]";
				unset($ThirdValArray);
				$ThirdJsArray[] = $ThirdText;
			}
			$SecondText = $SecondText.implode(',',$SecondValArray)."]";
			unset($SecondValArray);
			$SecondJsArray[] = $SecondText;
		}

		$FirstJs .= implode(',',$FirstJsArray).']';
		$SecondJs .= implode(',',$SecondJsArray).'}';
		$ThirdJs .= implode(',',$ThirdJsArray).'};';
		$SelectMobileJs = $FirstJs.$SecondJs.$ThirdJs;
		return $SelectMobileJs;
	}
	/* ����ת�� */
	public static function StrToGBK($string,$ajax_status){
		global $_G;
		if($_G[charset] == 'gbk'){
			if($ajax_status == true){
				if(is_array($string)){
					return eval('return '.iconv("GB2312","UTF-8//IGNORE",var_export($string,true).';')); 
				}else{
					return iconv('GB2312', 'UTF-8', $string);
				}
			}else{
				if(is_array($string)){
					$StringArr = array();
					foreach($string as $key=>$value){
						$encode = mb_detect_encoding($value, array('UTF-8','GB2312','GBK'));
						if($encode == 'UTF-8'){
							$StringArr[$key] = iconv('UTF-8','GB2312//IGNORE',$value);
						}else if($encode == 'EUC-CN'){
							$StringArr[$key] = $value;
						}
					}
					return $StringArr;
				}else{
					$encode = mb_detect_encoding($string, array('UTF-8','GB2312','GBK'));
					if($encode == 'UTF-8'){
						return iconv('UTF-8','GB2312//IGNORE', $string);
					}else if($encode == 'EUC-CN'){
						return $string;
					}
				}
			}
		}else{
			return $string;
		}
        
    }
	/* ΢�ŷ���_GetSignPackage */
	public function WeixinGetSignPackage(){
		require_once $this->Config[Path]."/weixin/jssdk.php";
		$jssdk = new JSSDK($this->Config[PluginVar][wx_appid], $this->Config[PluginVar][wx_secret]);
		return $jssdk->GetSignPackage();
	}
	
	/* sqlת�� */
	public function ArrayAddslashes($String) {
		if(is_array($String)) {
			foreach($String as $key => $val) {
				$String[$key] = $this->ArrayAddslashes($val);
			}
		} else {
			if(is_numeric($String)){
				if(is_int($String)){
					$String = dhtmlspecialchars((int)$String);
				}else{
					$String = dhtmlspecialchars((float)$String);
				}
			}else{
				$String = dhtmlspecialchars(addslashes($String));
			}
			
		}
		return $String;
	}
}
//From: Dism��taobao��com
?>