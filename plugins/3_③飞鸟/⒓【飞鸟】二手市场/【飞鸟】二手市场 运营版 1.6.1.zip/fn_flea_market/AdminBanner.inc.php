<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_flea_market/function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_flea_market/common.inc.php');
if(!submitcheck('BannerSubmit')){
	$formUrl = ltrim(rawurldecode(cpurl()),'action=');
	showtagheader('div', 'banner_module', true);
	showformheader($formUrl,'enctype="multipart/form-data"');
	showtableheader($Fn_Flea_Market->Config[LangVar][BannerDisplayTitle]);
	showsubtitle(array(
		'', 'display_order',
		$Fn_Flea_Market->Config[LangVar][BannerTitle],
		$Fn_Flea_Market->Config[LangVar][BannerLink],
		$Fn_Flea_Market->Config[LangVar][BannerImg],
		$Fn_Flea_Market->Config[LangVar][BannerType]
	));
	$ModulesBannerList = $Fn_Flea_Market->GetModulesBanner();
	foreach ($ModulesBannerList as $module) {
		if($module[type] == 2){
			$CheckedM = "checked='checked'";
			$CheckedPc = '';
		}else if($module[type] == 1){
			$CheckedPc = "checked='checked'";
			$CheckedM = '';
		}
		showtablerow('', array('class="td25"', 'class="td28"'), array(
			'<input type="checkbox" class="checkbox" name="delete[]" value="'.$module[id].'" />',
			'<input type="text" class="txt" size="2" name="displayorder['.$module[id].']" value="'.$module[displayorder].'" />',
			'<input type="text" size="30" name="title['.$module[id].']" value="'.$module[title].'" />',
			'<input type="text" size="30" name="link['.$module[id].']" value="'.$module[link].'" />',
			'<a href="'.$module[img].'" target="_blank"><img src="'.$module[img].'" style="width:60px;float:left;display:inline;margin:0 5px 0 0;"></a><input type="hidden" size="30" name="img['.$module[id].']" value="'.$module[img].'" /> <input name="file_img['.$module[id].']" value="" class="txt uploadbtn" type="file" style="width:200px;">',
			'<label><input name="type['.$module[id].']" type="radio" value="1" '.$CheckedPc.'/>'.$Fn_Flea_Market->Config[LangVar][BannerPc].'</label><label><input name="type['.$module[id].']" type="radio" value="2" '.$CheckedM.'/>'.$Fn_Flea_Market->Config[LangVar][BannerM].'</label>'
		));
	}
	showtablerow('', array('class="td25"', 'class="td28"'), array(
		cplang('add_new'),
		sprintf('<input type="text" class="txt" size="2" maxlength="4" name="new_displayorder" value="" />'),
		sprintf('<input type="text" size="30" name="new_title" value="" />'),
		sprintf('<input type="text" size="30" name="new_link" value="" />'),
		sprintf('<input name="new_img" value="" class="txt uploadbtn" type="file" style="width:265px;">'),
		sprintf('<label><input name="new_type" type="radio" value="1" checked="checked"/>'.$Fn_Flea_Market->Config[LangVar][BannerPc].'</label><label><input name="new_type" type="radio" value="2" />'.$Fn_Flea_Market->Config[LangVar][BannerM].'</label>')
	));
	showsubmit('BannerSubmit', 'submit', 'del');
    showtablefooter();/*Dism_taobao_com*/
	/*dism��taobao-com*/showformfooter();
	showtagfooter('div');
}else{
	$Post = $Fn_Flea_Market->ArrayAddslashes($_POST);
	// ɾ��ѡ�н���ͼ
    if (isset($Post['delete'])) {
		foreach($Post['delete'] as $id){
			unlink(DISCUZ_ROOT.$Post[img][$id]);//ɾ��ͼƬ
		}
		DB::delete($Fn_Flea_Market->TableBanner,'id in('.implode(',',$Post['delete']).')');
	}
	// ���½���ͼ
    if(!empty($Post['displayorder'])) {
		foreach ($Post['displayorder'] as $id => $displayorder) {
			$UpIns = array();
			$UpIns[link] =  $Post[link][$id];
			$UpIns[displayorder] =  $displayorder;
			$UpIns[title] =  $Post[title][$id];
			$UpIns[type] =  $Post[type][$id];
			if(!empty($_FILES['file_img'][size][$id])) {
				$Banner = array(
					'name' => $_FILES[file_img][name][$id],
					'type' => $_FILES[file_img][type][$id],
					'tmp_name' => $_FILES[file_img][tmp_name][$id],
					'error' => $_FILES[file_img][error][$id],
					'size' => $_FILES[file_img][size][$id]
				);
				$UpIns[img] = $Fn_Flea_Market->UploadIconBanner($Banner,$Post[img][$id]);
			}else{
				$UpIns[img] =  $Post[img][$id];
			}
			DB::update($Fn_Flea_Market->TableBanner,$UpIns,'id = '.$id);
		}
    }
	//�����½���ͼ
    if (!empty($_FILES['new_img'][size])) {
		$Ins = array();
		$Ins[link] = $Post[new_link];
		$Ins[displayorder] = $Post[new_displayorder];
		$Ins[type] = $Post[new_type];
		$Ins[title] = $Post[new_title];
		$Ins[img] = $Fn_Flea_Market->UploadIconBanner($_FILES['new_img']);
		DB::insert($Fn_Flea_Market->TableBanner,$Ins);
    }
	cpmsg($Fn_Flea_Market->Config[LangVar][UpdateOk],rawurldecode(cpurl()),'succeed');
}
//From: Dism��taobao��com
?>