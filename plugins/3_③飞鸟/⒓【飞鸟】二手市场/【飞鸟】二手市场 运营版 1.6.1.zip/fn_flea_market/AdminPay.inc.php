<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_flea_market/function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_flea_market/common.inc.php');
if(!submitcheck('PaySubmit')){
	/* ���� */
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}
	$StateSelected = array($_GET['state']=>' selected');
	$OrderSelected = array($_GET['order']=>' selected');
	$PayTypeSelected = array($_GET['paytype']=>' selected');
	$SearPayListOption = '<select name="paytype"><option value="">'.$Fn_Flea_Market->Config[LangVar][SelectNull].'</option>';
	foreach($PayList as $key => $val){
		$SearPayListOption .= '<option value="'.$val[Type].'" '.$PayTypeSelected[$val[Type]].'>'.$val[Name].'</option>';
	}
	$SearPayListOption .= '</select>';
	$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
	echo <<<SEARCH
	<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
		<div style="margin-top:8px;">
			<table cellspacing="4" cellpadding="4">
				<tr>
					<th>{$Fn_Flea_Market->Config[LangVar][UidTitle]}</th><td><input type="text" class="txt" size="10" name="uid" value="$_GET[uid]"></td>
					<th>{$Fn_Flea_Market->Config[LangVar][PayTypeTitle]}</th><td>$SearPayListOption</td>
					<th>{$Fn_Flea_Market->Config[LangVar][State]}</th><td><select name="state"><option value="">{$Fn_Flea_Market->Config[LangVar][SelectNull]}</option><option value="1"  $StateSelected[1]>{$Fn_Flea_Market->Config[LangVar][StateIs]}</option><option value="0"$StateSelected[0]>{$Fn_Flea_Market->Config[LangVar][StateNo]}</option></select></td>
					<th>{$Fn_Flea_Market->Config[LangVar][SortTitle]}</th><td><select name="order"><option value="id"$OrderSelected[id]>ID</option><option value="establish_time"$OrderSelected[establish_time]>{$Fn_Flea_Market->Config[LangVar][EstablishTimeTitle]}</option><option value="pay_time"$OrderSelected[pay_time]>{$Fn_Flea_Market->Config[LangVar][PayTimeTitle]}</option><option value="money"$OrderSelected[money]>{$Fn_Flea_Market->Config[LangVar][MoneyTitle]}</option></select></td>
					<td><input type="submit" name="searchsubmit" value="{$Fn_Flea_Market->Config[LangVar][SearchTitle]}" class="btn"></td>
				</tr>
			</table>
		</div>
	</form>
SEARCH;
	/* ���� end */
	/* ��ѯ���� */
	$_GET = $Fn_Flea_Market->ArrayAddslashes($_GET);
	$MpUrl = $SearUrl;
	foreach($_GET as $K => $V){
		$MpUrl.= '&'.$K.'='.$V;
	}
	$Where = '';
	if(!empty($_GET[order])){
		$Order = 'p.'.$_GET[order];
	}else{
		$Order = 'p.id';
	}
	if(!empty($_GET[uid])){
		$Where .= ' and p.uid = '.$_GET[uid];
	}
	if($_GET[state] == '0'|| $_GET[state] == '1'){
		$Where .= ' and p.state = '.$_GET[state];
	}
	if(!empty($_GET[paytype])){
		$Where .= ' and p.paytype = \''.$_GET[paytype].'\'';
	}
	$Where = preg_replace('/and/','where',$Where,1);
	$Limit = 25;
	$Page = $_GET['page']?intval($_GET['page']):1;
	/* ��ѯ���� end */
	$formUrl = ltrim(rawurldecode(cpurl()),'action=');
	showtagheader('div', 'PayModule', true);
	showformheader($formUrl,'enctype="multipart/form-data"');
	showtableheader($Fn_Flea_Market->Config[LangVar][PayList]);
	showsubtitle(array(
        'ID',$Fn_Flea_Market->Config[LangVar][UidTitle],
		$Fn_Flea_Market->Config[LangVar][UidNameTitle],
		$Fn_Flea_Market->Config[LangVar][MoneyTitle],
		$Fn_Flea_Market->Config[LangVar][GiveMoneyTitle],
		$Fn_Flea_Market->Config[LangVar][PayTypeTitle],
		$Fn_Flea_Market->Config[LangVar][EstablishTimeTitle],
		$Fn_Flea_Market->Config[LangVar][PayTimeTitle],
		$Fn_Flea_Market->Config[LangVar][State]
	));
	$ModulesPayList = GetModulesPay($Page,$Limit,$Where,$Order);
	foreach ($ModulesPayList as $Module) {
		showtablerow('', array('class="td25"', 'class="td28"'), array(
			'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module[id].'" />'.$Module[id],
			$Module[uid],
			$Module[username],
			$Module[money],
			$Module[givemoney],
			$Module[paytype],
			$Fn_Flea_Market->GetTime($Module[establish_time]),
			$Fn_Flea_Market->GetTime($Module[pay_time]),
			$Fn_Flea_Market->GetState($Module[state])
		));
	}
	showsubmit('PaySubmit','submit','del','',multi(GetModulesPayCount($Where),$Limit,$Page,$MpUrl));
    showtablefooter();/*Dism_taobao_com*/
	/*dism��taobao-com*/showformfooter();
	showtagfooter('div');
}else{
	$_POST = $Fn_Flea_Market->ArrayAddslashes($_POST);
	if (isset($_POST['delete'])) {
		DB::delete($Fn_Flea_Market->TablePay,'id in('.implode(',',$_POST['delete']).')');
		cpmsg($Fn_Flea_Market->Config[LangVar][DelOk],rawurldecode(cpurl()),'succeed');
	}else{
		cpmsg($Fn_Flea_Market->Config[LangVar][DelErr],'','error');
	}
}

/* ֧���б� */
function GetModulesPay($Page,$Limit,$Where,$Order){
	global $Fn_Flea_Market;
	$FetchSql = 'SELECT p.*,m.username FROM '.DB::table($Fn_Flea_Market->TablePay).' p  LEFT JOIN `'.DB::table('common_member').'` m on m.uid=p.uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1)*$Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ֧���б����� */
function GetModulesPayCount($Where){
	global $Fn_Flea_Market;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Flea_Market->TablePay).' p '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>