<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('FN_IN_API')) {
	exit('Access Denied');
}
loadcache('plugin');
function NotifyUpdatePay($OrderId,$Identification,$Money,$PayType){
	global $_G,$FnPay;
	$OrderId = $FnPay->ArrayAddslashes($OrderId);
	$Identification = $FnPay->ArrayAddslashes($Identification);
	$Money = $FnPay->ArrayAddslashes($Money);
	$PayType = $FnPay->ArrayAddslashes($PayType);
	$Table = 'fn_flea_market_pay';
	$PayInfo = DB::fetch_first('SELECT * FROM '.DB::table($Table).' where id = '.$OrderId.' and money ='.$Money);
	if(!empty($PayInfo) && $PayInfo[state] != 1){
		$ExtcreditType = $_G['cache']['plugin']['fn_flea_market']['extcredit_type'];
		$Proportion = $_G['cache']['plugin']['fn_flea_market']['proportion'];
		$ExtcreditsCount = $Proportion * $PayInfo[money] + $PayInfo[givemoney];
		$Data = array('state'=>1,'paytype'=>$PayType,'pay_time'=>time());
		if(DB::update($Table,$Data,'id='.$OrderId)){
			updatemembercount($PayInfo[uid],array("extcredits".$ExtcreditType =>$ExtcreditsCount));
			return true;
		}else{
			return false;
		}
	}
}
//From: Dism��taobao��com
?>