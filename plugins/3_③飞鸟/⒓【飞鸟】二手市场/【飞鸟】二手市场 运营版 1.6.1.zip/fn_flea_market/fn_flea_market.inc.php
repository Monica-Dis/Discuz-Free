<?php
/**
 *	[�����������г�(fn_flea_market.{modulename})] (C)2016-2099 Powered by DisM!Ӧ������ (https://DisM.Taobao.COm/).
 *	Version: 1.0
 *	Date: 2017-5-5 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_flea_market/function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_flea_market/common.inc.php');
$_GET[m] = empty($_GET[m]) ? 'index' : $_GET[m];//��ʼ��ģ��
$AllClassList = $Fn_Flea_Market->GetAllClass(1);
if($_GET[m] == 'add' || $_GET[m] == 'user' || $_GET[m] == 'user_collect' || $_GET[m] == 'user_info_edit' || $_GET[m] == 'pay' || $_GET[m] == 'he_user'){
	if(empty($_G[uid])){
		if(checkmobile()){
			header("HTTP/1.1 303 See Other");
			Header("Location: member.php?mod=logging&action=login&mobile=2"); 
		}else{
			showmessage('to_login', '', array(), array('showmsg' => true,'login' => 1));
			exit();
		}
	}else{
		$UserInfo = $Fn_Flea_Market->GetUserInfo($_G[uid]);
	}
}
if($_GET[m] == 'info' && !empty($_GET[iid])){//��������
	if($WxApp){
		$App = false;
	}
	$InfoArray = $Fn_Flea_Market->GetInfo($_GET[iid]);
	$InfoArray[detailspic] = array_filter(explode(',',$InfoArray[detailspic]));
	$navtitle = $InfoArray[title].'_'.$Fn_Flea_Market->Config[LangVar][DetailsTitle];
	$title = $Fn_Flea_Market->Config[LangVar][DetailsTitle];
	if(!empty($InfoArray)){
		$Fn_Flea_Market->Click($Fn_Flea_Market->TableInfo,$_GET[iid]);
		$LikeList = $Fn_Flea_Market->GetLikeList($InfoArray[classid],$InfoArray[type]);
	}
	if(!empty($_G[uid])){
		$MyCollectInfoIdArray = $Fn_Flea_Market->GetFirstMyCollectArray($_G[uid]);
		if(in_array($_GET[iid],$MyCollectInfoIdArray)){
			$CssColor = 'style="color:'.$Fn_Flea_Market->Config[PluginVar][zt_color].'"';
		}
	}
	$Fn_Flea_Market->Config[SignPackage] = $Fn_Flea_Market->WeixinGetSignPackage();
	$Fn_Flea_Market->Config[WxShare][WxTitle] = $InfoArray[type].'-'.$InfoArray[title];
	$Fn_Flea_Market->Config[WxShare][WxDes] = $InfoArray[body];
	$Fn_Flea_Market->Config[WxShare][WxImg] = $_G[siteurl].$InfoArray[thumbnail];
	$Fn_Flea_Market->Config[WxShare][WxUrl] = $Fn_Flea_Market->Config[InfoUrl].$InfoArray[id];
}else if($_GET[m] == 'add'){//����
	$navtitle = $title = $Fn_Flea_Market->Config[LangVar][AddTitle];
	if($_GET[type] == 2){
		$navtitle = $title = $Fn_Flea_Market->Config[LangVar][AddSeekTitle];
		$Fn_Flea_Market->Config[LangVar][RemindMoney] = $Fn_Flea_Market->Config[LangVar][RemindSeekMoney];
		$Fn_Flea_Market->Config[LangVar][ThumbnailTitle] = $Fn_Flea_Market->Config[LangVar][ThumbnailSeekTitle];
		$Fn_Flea_Market->Config[LangVar][AddSubmit] = $Fn_Flea_Market->Config[LangVar][AddSeekSubmit];
	}
	
	if($WxApp){
		$App = false;
	}
	$StickList = explode("\r\n",$Fn_Flea_Market->Config[PluginVar][stick]);
	$AddressMobileJs = $Fn_Flea_Market->GetSelectMobileJs($Fn_Flea_Market->Address,array('Provinces','Citys','Countys'));
	$ClassMobileJs = $Fn_Flea_Market->GetSelectMobileJs($Fn_Flea_Market->GetAllClass(1),array('FirstClass','SecondClass','ThirdClass'),'class');

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_upload/upload.class.php')){
		@include DISCUZ_ROOT.'./source/plugin/fn_upload/upload.class.php';
		$UploadConfig = FnUpload::Config();
	}

}else if($_GET[m] == 'user'){//��Ա����
	$StickList = explode("\r\n",$Fn_Flea_Market->Config[PluginVar][stick]);
	$navtitle = $Fn_Flea_Market->Config[LangVar][UserTitle];
	$Fn_Flea_Market->Config[SignPackage] = $Fn_Flea_Market->WeixinGetSignPackage();
}else if($_GET[m] == 'user_collect'){//�ղ�����
	$navtitle = $title = $Fn_Flea_Market->Config[LangVar][CollectionTitle];
}else if($_GET[m] == 'user_info_edit'){//�޸�����
	$navtitle = $title = $Fn_Flea_Market->Config[LangVar][UserEditProfileTitle];
}else if($_GET[m] == 'pay'){ //֧������
	if($_GET[state] == 'ok'){
		$navtitle = $title = $Fn_Flea_Market->Config[LangVar][PayOk];
	}else{
		$navtitle = $title = $Fn_Flea_Market->Config[LangVar][PayTitle];
		$MoneyList = explode("\r\n",$Fn_Flea_Market->Config[PluginVar][extcredit_list]);
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){
			@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
			$PayList = $FnPay->GetPayList();
		}
	}
}else if($_GET[m] == 'he_user'){//��������
	$navtitle = $title = $Fn_Flea_Market->Config[LangVar][HeUserTitle];
	$UserInfo = $Fn_Flea_Market->GetUserInfo($_GET[uid]);
}else if($_GET[m] == 'list'){//�б�
	if($_GET[keywords]){
		$navtitle = $_GET[keywords].'-'.$Fn_Flea_Market->Config[LangVar][SearchListTitle];
	}else if($_GET[classid]){
		$navtitle = $AllClassList[$_GET[classid]][bname].'-'.$Fn_Flea_Market->Config[LangVar][InfoListTitle];
		$keywords = $AllClassList[$_GET[classid]][keywords];
		$description = $AllClassList[$_GET[classid]][description];
		$title = $AllClassList[$_GET[classid]][name];
	}else{
		$navtitle = $keywords = $description = $Fn_Flea_Market->Config[LangVar][InfoListTitle];

	}
}else if($_GET[m] == 'class'){//����
	$navtitle = $Fn_Flea_Market->Config[LangVar][ClassSeoTitle];
	foreach ($AllClassList as $K => $V) {
		if(!$V[bclassid]){
			$NanList[] = $V;
		}
	}
}else{
	$navtitle = $Fn_Flea_Market->Config[PluginVar][title];
	$keywords = $Fn_Flea_Market->Config[PluginVar][keywords];
	$description = $Fn_Flea_Market->Config[PluginVar][description];
	foreach ($AllClassList as $K => $V) {
		if(!$V[bclassid]){
			$NanList[] = $V;
		}
	}
	if(checkmobile()){
		$BannerList = $Fn_Flea_Market->GetModulesBanner(2);
	}else{
		$BannerList = $Fn_Flea_Market->GetModulesBanner(1);
	}
}
include template('fn_flea_market:'.$_GET[m]);
?>