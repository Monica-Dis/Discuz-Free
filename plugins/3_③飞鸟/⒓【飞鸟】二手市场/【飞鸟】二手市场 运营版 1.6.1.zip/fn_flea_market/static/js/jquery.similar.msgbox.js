(function () {  
    $.MsgBox = {  
        Alert: function (title, msg,callback) {  
            GenerateHtml("alert", title, msg);  
            btnOk(callback);  //alertֻ�ǵ�����Ϣ�����û��Ҫ�õ��ص�����callback  
            btnNo();  
        },  
        Confirm: function (title, msg, callback) {  
            GenerateHtml("confirm", title, msg);  
            btnOk(callback);  
            btnNo();  
        }  
    }  
    //����Html  
    var GenerateHtml = function (type, title, msg) {  
        var _html = "";  
        _html += '<div id="mb_box"></div><div id="mb_con"><span id="mb_tit">' + title + '</span>';  
        _html += '<div id="mb_msg">' + msg + '</div><div id="mb_btnbox">';  
        if (type == "alert") {  
            _html += '<span id="mb_btn_ok">'+config.MsgBox_ok+'</span>';  
        }  
        if (type == "confirm") {  
            _html += '<span id="mb_btn_ok">'+config.MsgBox_ok+'</span>';  
            _html += '<span id="mb_btn_no">'+config.MsgBox_no+'</span>';  
        }  
        _html += '</div></div>';  
        //�����Ƚ�_html���ӵ�body��������Css��ʽ  
        $("body").append(_html);   
        //����Css  
         GenerateCss();  
    }  
    //����Css  
    var GenerateCss = function () {  
        var _widht = document.documentElement.clientWidth;  //��Ļ��  
        var _height = document.documentElement.clientHeight; //��Ļ��  
        var boxWidth = $("#mb_con").width(); 
        var boxHeight = $("#mb_con").height();  
        //����ʾ�����  
        //$("#mb_con").css({ top: (_height - boxHeight) / 2 - 40 + "px", left: (_widht - boxWidth) / 2 + "px" });  
    }  
    //ȷ����ť�¼�  
    var btnOk = function (callback) {  
        $("#mb_btn_ok").click(function () {  
            $("#mb_box,#mb_con").remove();  
            if (typeof (callback) == 'function') {  
                callback();  
            }  
        });  
    }  
    //ȡ����ť�¼�  
    var btnNo = function () {  
        $("#mb_btn_no,#mb_ico").click(function () {  
            $("#mb_box,#mb_con").remove();  
        });  
    }  
})();
