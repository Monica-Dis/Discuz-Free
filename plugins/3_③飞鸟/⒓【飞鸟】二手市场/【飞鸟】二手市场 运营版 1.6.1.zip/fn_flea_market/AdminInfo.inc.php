<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_flea_market/function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_flea_market/common.inc.php');
$AllClass = $Fn_Flea_Market->GetAllClass();
$Operation = in_array($_GET[Operation], array('Del','Edit','Display')) ? $_GET[Operation] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
if($Operation == 'List'){//��Ʒ�б�
	if(!submitcheck('InfoSubmit')) {
		/* ���� */
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		$ClassShowSelect = $Fn_Flea_Market->GetClassShowSelect($AllClass,'classid',true,$_GET[classid]);
		$DisplaySelected = array($_GET['display']=>' selected');
		$StickSelected = array($_GET['stick']=>' selected');
		$OrderSelected = array($_GET['order']=>' selected');
		$TypeSelected = array($_GET['type']=>' selected');
		$StateSelected = array($_GET['state']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Flea_Market->Config[LangVar][InfoId]}</th><td><input type="text" class="txt" name="infoid" value="{$_GET[infoid]}"></td>
						<th>{$Fn_Flea_Market->Config[LangVar][InfoTitle]}</th><td><input type="text" class="txt" name="title" value="{$_GET[title]}"></td>
					</tr>
					<tr>
						<th>{$Fn_Flea_Market->Config[LangVar][UidTitle]}</th><td><input type="text" class="txt" name="uid" value="{$_GET[uid]}"></td>
						<th>{$Fn_Flea_Market->Config[LangVar][ClassTitle]}</th><td>{$ClassShowSelect}</td>
					</tr>
					<tr>
						<th>{$Fn_Flea_Market->Config[LangVar][DisplayTitle]}</th><td colspan="3"><select name="display"><option value="">{$Fn_Flea_Market->Config[LangVar][AllTitle]}</option><option value="1"  $DisplaySelected[1]>{$Fn_Flea_Market->Config[LangVar][Yes]}</option><option value="0"$DisplaySelected[0]>{$Fn_Flea_Market->Config[LangVar][No]}</option></select>&nbsp;&nbsp;{$Fn_Flea_Market->Config[LangVar][StickTitle]}&nbsp;<select name="stick"><option value="">{$Fn_Flea_Market->Config[LangVar][AllTitle]}</option><option value="1"  $StickSelected[1]>{$Fn_Flea_Market->Config[LangVar][Yes]}</option></select>&nbsp;&nbsp;{$Fn_Flea_Market->Config[LangVar][InfoTypeTitle]}&nbsp;<select name="type"><option value="">{$Fn_Flea_Market->Config[LangVar][AllTitle]}</option><option value="1"  $TypeSelected[1]>{$Fn_Flea_Market->Config[LangVar][TypeList][1]}</option><option value="2"  $TypeSelected[2]>{$Fn_Flea_Market->Config[LangVar][TypeList][2]}</option></select>&nbsp;&nbsp;{$Fn_Flea_Market->Config[LangVar][State]}&nbsp;<select name="state"><option value="">{$Fn_Flea_Market->Config[LangVar][AllTitle]}</option><option value="1"  $StateSelected[1]>{$Fn_Flea_Market->Config[LangVar][InfoState][1]}</option><option value="0"  $StateSelected[0]>{$Fn_Flea_Market->Config[LangVar][InfoState][0]}</option></select>&nbsp;&nbsp;{$Fn_Flea_Market->Config[LangVar][InfoMoneyTitle]}&nbsp;<input type="text" class="txt" name="min_money" value="{$_GET[min_money]}" size="4">&nbsp;-&nbsp;<input type="text" class="txt" name="max_money" value="{$_GET[max_money]}" size="4"></td>
					</tr>
					<tr>
						<th>{$Fn_Flea_Market->Config[LangVar][OrderTitle]}</th><td colspan="3"><select name="order">
						<option value="id"{$OrderSelected[id]}>id</option>
						<option value="time"{$OrderSelected[time]}>{$Fn_Flea_Market->Config[LangVar][TimeTitle]}</option>
						<option value="sticktime"{$OrderSelected[sticktime]}>{$Fn_Flea_Market->Config[LangVar][StickTimeTitle]}</option>
						<option value="click"{$OrderSelected[click]}>{$Fn_Flea_Market->Config[LangVar][ClickTitle]}</option>
						<option value="collect_count"{$OrderSelected[collect_count]}>{$Fn_Flea_Market->Config[LangVar][CollectTitle]}</option>
						</select>&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Flea_Market->Config[LangVar][SearchSubmit]}" class="btn" type="submit"></td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		/* ��ѯ���� */
		$_GET = $Fn_Flea_Market->ArrayAddslashes($_GET);
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		if($_GET[order]){
			$Order = 'I.'.$_GET[order];
		}else{
			$Order = 'I.id';
		}
		if($_GET[infoid]){
			$Where .= ' and I.id = '.$_GET[infoid];
		}
		if($_GET[title]){
			$Where .= ' and I.title like(\'%'.$_GET[title].'%\')';
		}
		if($_GET[uid]){
			$Where .= ' and I.uid = '.$_GET[uid];
		}
		if($_GET[classid]){
			$Where .= ' and I.classid in('.$Fn_Flea_Market->GetSonClassIds($_GET[classid]).')';
		}
		if($_GET[display] == '1' || $_GET[display] == '0'){
			$Where .= ' and I.display = '.$_GET[display];
		}
		if($_GET[stick]){
			$Where .= ' and I.sticktime > '.time();
		}
		if($_GET[type]){
			$Where .= ' and I.type = '.$_GET[type];
		}
		if($_GET[state] == '0' || $_GET[state]){
			$Where .= ' and I.state = '.$_GET[state];
		}
		if($_GET[min_money]){
			$Where .= ' and I.money > '.$_GET[min_money];
		}
		if($_GET[max_money]){
			$Where .= ' and I.money < '.$_GET[max_money];
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		$TdStyle = array('width="20"', 'width="130"', 'width="60"','width="60"','width="40"','width="60"','width="60"','width="120"','width="80"','width="120"','width="120"','width="50"','width=180');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'PayModule', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_Flea_Market->Config[LangVar][InfoListTitle]);
		showsubtitle(array(
            'ID',
			$Fn_Flea_Market->Config[LangVar][InfoTitle],
			$Fn_Flea_Market->Config[LangVar][UidTitle],
			$Fn_Flea_Market->Config[LangVar][ClassTitle],
			$Fn_Flea_Market->Config[LangVar][InfoTypeTitle],
			$Fn_Flea_Market->Config[LangVar][InfoMoneyTitle],
			$Fn_Flea_Market->Config[LangVar][DegreeTitle],
			$Fn_Flea_Market->Config[LangVar][AddressTitle],
			$Fn_Flea_Market->Config[LangVar][State],
			$Fn_Flea_Market->Config[LangVar][StickTimeTitle],
			$Fn_Flea_Market->Config[LangVar][TimeTitle],
			$Fn_Flea_Market->Config[LangVar][DisplayTitle],
			$Fn_Flea_Market->Config[LangVar][OperationTitle]
		), 'header',$TdStyle);
		$InfoList = GetModulesInfoList($Page,$Limit,$Where,$Order);
		$OpInfoCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($InfoList as $Module) {
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				'<input type="checkbox" class="checkbox" name="ids[]" value="'.$Module[id].'" />'.$Module[id],
				$Module[title],
				$Module[uid],
				$Module[name],
				$Module[type],
				$Module[money],
				$Module[degree],
				$Module[address],
				$Fn_Flea_Market->Config[LangVar][InfoState][$Module[state]],
				$Module[sticktime],
				$Module[time],
				(!empty($Module['display']) ? $Fn_Flea_Market->Config[LangVar][Yes] : '<span style="color:red">'.$Fn_Flea_Market->Config[LangVar][No].'<span>'),
				'<a href="'.$Fn_Flea_Market->Config[InfoUrl].$Module['id'].'&admin=yes" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$OpInfoCpUrl.'&Operation=Edit&iid='.$Module['id'].'">'.$Fn_Flea_Market->Config[LangVar][EditTitle].'</a>&nbsp;&nbsp;<a href="'.$OpInfoCpUrl.'&Operation=Display&iid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_Flea_Market->Config[LangVar][DisplayNoTitle] : $Fn_Flea_Market->Config[LangVar][DisplayIsTitle]).'</a>&nbsp;&nbsp;<a href="'.$OpInfoCpUrl.'&Operation=Del&iid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Flea_Market->Config[LangVar][DelTitle].'</a>',
			));
		}
		showsubmit('InfoSubmit','submit','<input name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" type="checkbox"><label for="chkall">'.$Fn_Flea_Market->Config[LangVar][ChkAll].'</label>&nbsp;&nbsp;<input name="optype" id="OptypeDel" value="Del" class="radio" type="radio"><label for="OptypeDel">'.$Fn_Flea_Market->Config[LangVar][DelTitle].'</label>&nbsp;&nbsp;<input name="optype" id="OptypeDisplay" value="Display" class="radio" type="radio"><label for="OptypeDisplay">'.$Fn_Flea_Market->Config[LangVar][DisplayTitle].'</label>&nbsp;<select name="display"><option value="1">'.$Fn_Flea_Market->Config[LangVar][Yes].'</option><option value="0">'.$Fn_Flea_Market->Config[LangVar][No].'</option></select>&nbsp;&nbsp;<input name="optype" id="OptypeMove" value="Move" class="radio" type="radio"><label for="OptypeMove">'.$Fn_Flea_Market->Config[LangVar][MoveClassTitle].'</label>&nbsp;'.$Fn_Flea_Market->GetClassShowSelect($AllClass,'classid',true).'&nbsp;&nbsp;<input name="optype" id="OptypeState" value="State" class="radio" type="radio"><label for="OptypeState">'.$Fn_Flea_Market->Config[LangVar][State].'</label>&nbsp;<select name="state"><option value="0">'.$Fn_Flea_Market->Config[LangVar][InfoState][0].'</option><option value="1">'.$Fn_Flea_Market->Config[LangVar][InfoState][1].'</option></select>','',multi(GetModulesInfoCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter();/*Dism_taobao_com*/
		/*dism��taobao-com*/showformfooter();
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if($_GET[optype] == 'Del' && $_GET[ids]){//ȫɾ
			if($Fn_Flea_Market->Del($Fn_Flea_Market->TableInfo,$_GET[ids])){
				cpmsg($Fn_Flea_Market->Config[LangVar][DelOk],$CpMsgUrl,'succeed');
			}else{
				cpmsg($Fn_Flea_Market->Config[LangVar][DelErr],'','error');
			}
		}else if($_GET[optype] == 'Display' && $_GET[ids]){//��ʾ
			$Fn_Flea_Market->EditFields($Fn_Flea_Market->TableInfo,$_GET[ids],'display',$_GET[display]);
			cpmsg($Fn_Flea_Market->Config[LangVar][UpdateOk],$CpMsgUrl,'succeed');
		}else if($_GET[optype] == 'Move' && $_GET[classid] && $_GET[ids]){//�Ƶ�����
			$Fn_Flea_Market->EditFields($Fn_Flea_Market->TableInfo,$_GET[ids],'classid',$_GET[classid]);
			cpmsg($Fn_Flea_Market->Config[LangVar][UpdateOk],$CpMsgUrl,'succeed');
		}else if($_GET[optype] == 'State' && $_GET[ids]){//����״̬
			$Fn_Flea_Market->EditFields($Fn_Flea_Market->TableInfo,$_GET[ids],'state',$_GET[state]);
			cpmsg($Fn_Flea_Market->Config[LangVar][UpdateOk],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_Flea_Market->Config[LangVar][InfoOpErr],'','error');
		}
	}
}else if($Operation == 'Edit' && !empty($_GET[iid])){//�༭
	$Info = $Fn_Flea_Market->QueryOne($Fn_Flea_Market->TableInfo,$_GET[iid]);
	$Info[detailspic] = explode(',',$Info[detailspic]);
	
	if(!submitcheck('EditSubmit')) {
		$formUrl = ltrim(rawurldecode(cpurl()),'action=');
		showformheader($formUrl,'enctype');
		showtableheader();
		showtitle($Fn_Flea_Market->Config[LangVar][InfoEditTitle]);
		showsetting($Fn_Flea_Market->Config[LangVar][InfoTypeTitle],array('type',array(array('1',$Fn_Flea_Market->Config[LangVar][TypeList][1]),array('2',$Fn_Flea_Market->Config[LangVar][TypeList][2])),true), $Info['type'], 'mradio');
		showsetting($Fn_Flea_Market->Config[LangVar][InfoTitle], 'title',$Info['title'], 'text');
		showsetting($Fn_Flea_Market->Config[LangVar][ClassTitle], '','',$Fn_Flea_Market->GetClassShowSelect($AllClass,'classid',true,$Info[classid]));
		showsetting($Fn_Flea_Market->Config[LangVar][AddressTitle], '','',$Fn_Flea_Market->GetShowSelect($Fn_Flea_Market->Address,'address',true,$Info['address']));
		showsetting($Fn_Flea_Market->Config[LangVar][DegreeTitle], array('degree',$Fn_Flea_Market->DyadicArray($Fn_Flea_Market->Config[LangVar][DegreeList])),$Info['degree'],'select');
		showsetting($Fn_Flea_Market->Config[LangVar][InfoMoneyTitle], 'money', $Info['money'], 'text');
		showsetting($Fn_Flea_Market->Config[LangVar][InfoDesTitle], 'body', $Info['body'], 'textarea');
		showsetting($Fn_Flea_Market->Config[LangVar][RealnameTitle], 'realname', $Info['realname'], 'text');
		showsetting($Fn_Flea_Market->Config[LangVar][MobileTitle], 'mobile', $Info['mobile'], 'text');
		showsetting($Fn_Flea_Market->Config[LangVar][WxTitle], 'wx', $Info['wx'], 'text');
		showsetting($Fn_Flea_Market->Config[LangVar][QqTitle], 'qq', $Info['qq'], 'text');
		showsetting($Fn_Flea_Market->Config[LangVar][StickTimeTitle], 'sticktime',empty($Info['sticktime']) ? '':date('Y-m-d H:i',$Info['sticktime']), 'calendar','','','',1);
		showsetting($Fn_Flea_Market->Config[LangVar][TimeTitle], 'time',empty($Info['time']) ? '':date('Y-m-d H:i',$Info['time']), 'calendar','','','',1);
		showsetting($Fn_Flea_Market->Config[LangVar][DisplayTitle], 'display', $Info['display'], 'radio');
		showsetting($Fn_Flea_Market->Config[LangVar][SetUpInfoState1], 'state', $Info['state'], 'radio');
		if($Info['thumbnail']) {
			$ThumbnailHtml = '<label><input type="checkbox" class="checkbox" name="delthumbnail" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Info['thumbnail'].'" target="_blank"><img src="'.$Info['thumbnail'].'" width="100"/></a><input type="hidden" value="'.$Info['thumbnail'].'" name="thumbnail"><br />';
		}
		showsetting($Fn_Flea_Market->Config[LangVar][InfoThumbnailTitle], 'thumbnailnew','', 'filetext', '', 0, $ThumbnailHtml);
		for($i = 0 ;$i < count($Info['detailspic']);$i++) {
			if($Info['detailspic'][$i] != '') {
				$DetailsPicHtml[$i] = '<label><input type="checkbox" class="checkbox" name="deldetailspic[]" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Info['detailspic'][$i].'" target="_blank"><img src="'.$Info['detailspic'][$i].'" width="100"/></a><input type="hidden" value="'.$Info['detailspic'][$i].'" name="detailspic[]"><br />';
			}
			showsetting($Fn_Flea_Market->Config[LangVar][InfoDetailsPicTitle].($i+1), 'detailspicnew[]','', 'filetext', '', 0, $DetailsPicHtml[$i]);
		}
		showtablefooter();/*Dism_taobao_com*/
		showsubmit('EditSubmit');
		/*dism��taobao-com*/showformfooter();
		echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
	}else{
		$Get = $Fn_Flea_Market->ArrayAddslashes($_GET);
		$UpData[type] = $Get[type];
		$UpData[title] = $Get[title];
		$UpData[classid] = $Get[classid];
		$UpData[address] = $Get[address];
		$UpData[degree] = $Get[degree];
		$UpData[money] = $Get[money];
		$UpData[body] = $Get[body];
		$UpData[realname] = $Get[realname];
		$UpData[mobile] = $Get[mobile];
		$UpData[wx] = $Get[wx];
		$UpData[qq] = $Get[qq];
		$UpData[sticktime] = strtotime($Get[sticktime]);
		$UpData[time] = strtotime($Get[time]);
		$UpData[display] = $Get[display];
		$UpData[state] = $Get[state];

		if($Get[delthumbnail] == 'yes'){
			unlink(DISCUZ_ROOT.$Get[thumbnail]);
			$UpData[thumbnail] = '';
		}
		if($_FILES['thumbnailnew'][size]){
			$UpData[thumbnail] = $Fn_Flea_Market->UploadIconBanner($_FILES['thumbnailnew'],$Get[thumbnail],true,1,$Fn_Flea_Market->Config[PluginVar][tailor_width],$Fn_Flea_Market->Config[PluginVar][tailor_height]);
		}else if(!empty($Get[thumbnailnew])){
			$UpData[thumbnail] = $Get[thumbnailnew];
		}
		for($i = 0;$i < count($_FILES[detailspicnew][size]);$i++){
			if($_FILES[detailspicnew][size][$i] != 0 && $_FILES[detailspicnew][error][$i] != 4){
				$DetailsPicArray = array(
					'name' => $_FILES[detailspicnew][name][$i],
					'type' => $_FILES[detailspicnew][type][$i],
					'tmp_name' => $_FILES[detailspicnew][tmp_name][$i],
					'error' => $_FILES[detailspicnew][error][$i],
					'size' => $_FILES[detailspicnew][size][$i]
				);
				$DetailsPic[$i] = $Fn_Flea_Market->UploadIconBanner($DetailsPicArray,$Get[detailspic][$i]);
			}else if($Get[deldetailspic][$i] == 'yes'){
				unlink(DISCUZ_ROOT.$Get[deldetailspic][$i]);
				$DetailsPic[$i] = '';
			}else{
				$DetailsPic[$i] = $Get[detailspic][$i];
			}
		}
		$UpData[detailspic] = implode(',',array_filter($DetailsPic));
		if(DB::update($Fn_Flea_Market->TableInfo,$UpData,'id = '.$Get['iid'])){
			cpmsg($Fn_Flea_Market->Config[LangVar][UpdateOk],rawurldecode(cpurl()),'succeed');
		}else{
			cpmsg($Fn_Flea_Market->Config[LangVar][UpdateErr],'','error');
		}
	}
}else if($Operation == 'Display' && $_GET[formhash] == formhash() && !empty($_GET[iid])){//��ʾ
	$Fn_Flea_Market->EditFields($Fn_Flea_Market->TableInfo,$_GET[iid],'display',$_GET[value]);
	cpmsg($Fn_Flea_Market->Config[LangVar][UpdateOk],$CpMsgUrl,'succeed');
}else if($Operation == 'Del' && $_GET[formhash] == formhash() && !empty($_GET[iid])){//ɾ��
	if($Fn_Flea_Market->Del($Fn_Flea_Market->TableInfo,$_GET[iid])){
		cpmsg($Fn_Flea_Market->Config[LangVar][DelOk],$CpMsgUrl,'succeed');
	}else{
		cpmsg($Fn_Flea_Market->Config[LangVar][DelErr],'','error');
	}
}
/* ��Ʒ�б� */
function GetModulesInfoList($Page,$Limit,$Where,$Order){
	global $Fn_Flea_Market;
	$FetchSql = 'SELECT C.name,I.* FROM '.DB::table($Fn_Flea_Market->TableInfo).' I  LEFT JOIN `'.DB::table($Fn_Flea_Market->TableClass).'` C on C.id=I.classid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1)*$Limit).','.$Limit;
	return $Fn_Flea_Market->GetInfoReplace(DB::fetch_all($FetchSql));//��������
}
/* ��Ʒ���� */
function GetModulesInfoCount($Where){
	global $Fn_Flea_Market;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Flea_Market->TableInfo).' I '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>