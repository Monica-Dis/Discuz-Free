<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_flea_market/function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_flea_market/common.inc.php');
$Operation = in_array($_GET[Operation], array('Del', 'Add', 'Edit')) ? $_GET[Operation] : 'List';
$AllClass = $Fn_Flea_Market->GetAllClass();
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
if($Operation == 'List'){
	if(!submitcheck('EditSubmit')) {
		$formUrl = ltrim(rawurldecode(cpurl()),'action=');
		$TdStyle = array('width="25"', 'width="60"', 'width="350"', '','width="80"','width="80"','width="200"');
		showformheader($formUrl,'MarketClass');
		echo '<div style="height:30px;line-height:30px;"><a href="javascript:;" onclick="show_all()">'.cplang('show_all').'</a> | <a href="javascript:;" onclick="hide_all()">'.cplang('hide_all').'</a></div>';
		showtableheader('', '', 'style="min-width:900px;*width:900px;"');
		showsubtitle(array('', '',$Fn_Flea_Market->Config[LangVar][ClassNameTitle],$Fn_Flea_Market->Config[LangVar][ClassBNameTitle], $Fn_Flea_Market->Config[LangVar][ClassInfoCount],$Fn_Flea_Market->Config[LangVar][DisplayTitle], $Fn_Flea_Market->Config[LangVar][OperationTitle]), 'header tbm',$TdStyle);
		foreach ($AllClass as $Key=>$Value) {
				if($Value['level'] == 0) {
					echo ShowClassRow($Key, 0, '');
				}
		}
		echo '<tbody><tr><td>&nbsp;</td><td colspan="8"><div><a class="addtr" href="'.ADMINSCRIPT.'?'.rawurldecode(cpurl()).'&Operation=Add&bclassid=0">'.$Fn_Flea_Market->Config[LangVar][AddClassTitle].'</a></div></td></tr></tbody>';
		showsubmit('EditSubmit');
		showtablefooter();/*Dism_taobao_com*/
		/*dism��taobao-com*/showformfooter();
	}else{
		 foreach($_POST['name'] as $key=>$value) {
			$UpData[displayorder] = $_POST[neworder][$key];
			$UpData[bname] = $_POST[bname][$key];
			$UpData[name] = $_POST[name][$key];
			DB::update($Fn_Flea_Market->TableClass,$UpData,'id = '.$key);
		 }
		 cpmsg($Fn_Flea_Market->Config[LangVar][ClassEditOk],$CpMsgUrl,'succeed');
	}
}else if($Operation == 'Add' || $Operation == 'Edit'){
	$Bclassid = intval($_GET['bclassid']);
	$Class = $_GET['classid'] ? $AllClass[$_GET['classid']] : array();
	$OpClassTitle = $Fn_Flea_Market->Config[LangVar][EditClassTitle];
	if($Operation == 'Add') {
		$OpClassTitle = $Fn_Flea_Market->Config[LangVar][AddClassTitle];
		$Class['display'] = 1;
		$Class[bclassid] = $Bclassid;
	}
	if($Bclassid) {
		$OpClassTitle .= '-'.$Fn_Flea_Market->Config[LangVar][BClassTitle].$AllClass[$Bclassid][name];
	}
	if(!submitcheck('DetailSubmit')) {
		$formUrl = ltrim(rawurldecode(cpurl()),'action=');
		showformheader($formUrl,'enctype');
		showtableheader();
		showtitle($OpClassTitle);
		showsetting($Fn_Flea_Market->Config[LangVar][ClassNameTitle], 'name', $Class['name'], 'text');
		showsetting($Fn_Flea_Market->Config[LangVar][ClassBNameTitle], 'bname', $Class['bname'], 'text');
		showsetting('portalcategory_keyword', 'keywords', $Class['keywords'], 'text');
		showsetting('portalcategory_summary', 'description', $Class['description'], 'textarea');
		showsetting($Fn_Flea_Market->Config[LangVar][BClassTitle], '','',$Fn_Flea_Market->GetClassShowSelect($AllClass,'bclassid',true,$Class[bclassid],true));
		if($Class['ico']) {
			$IcoHtml = '<label><input type="checkbox" class="checkbox" name="delico" value="yes" /> '.$lang['delete'].'</label><br /><img src="'.$Class['ico'].'" width="100"/><input type="hidden" value="'.$Class['ico'].'" name="ico"><br />';
		}
		showsetting($Fn_Flea_Market->Config[LangVar][ClassIcoTitle], 'iconew', $Class['iconew'], 'filetext', '', 0, $IcoHtml);
		showsetting($Fn_Flea_Market->Config[LangVar][SortTitle], 'displayorder', $Class['displayorder'], 'text');
		showsetting($Fn_Flea_Market->Config[LangVar][DisplayTitle], 'display', $Class['display'], 'radio');
		showtablefooter();/*Dism_taobao_com*/
		showsubmit('DetailSubmit');
		/*dism��taobao-com*/showformfooter();
	}else{
		$Post = $Fn_Flea_Market->ArrayAddslashes($_POST);
		if(!$Post[bname]){
			$Post[bname] = $Post[name];
		}
		$Data = array(
			'name'=>$Post[name],
			'bname'=>$Post[bname],
			'keywords'=>$Post[keywords],
			'description'=>$Post[description],
			'display'=>$Post[display],
			'bclassid'=>$Post[bclassid],
			'displayorder'=>$Post[displayorder]
		);
		if($Post[bclassid]){
			$Data[level] = $AllClass[$Post[bclassid]][level]+1;
		}
		if($_GET['classid']){
			if($_GET['classid'] == $Post[bclassid]){
				cpmsg($Fn_Flea_Market->Config[LangVar][EditClassErr],'','error');
			}
			if($Post[delico] == 'yes'){
				unlink(DISCUZ_ROOT.$Post[ico]);
				$Data[ico] = '';
			}
			if($_FILES['iconew'][size]){
				$Data[ico] = $Fn_Flea_Market->UploadIconBanner($_FILES['iconew'],$Post[ico]);
			}else if(!empty($Post[iconew])){
				$Data[ico] = $Post[iconew];
			}
			DB::update($Fn_Flea_Market->TableClass,$Data,'id = '.$_GET['classid']);
		}else{
			if($Post[bclassid]){
				$Data[level] = $AllClass[$Post[bclassid]][level]+1;
			}
			if($_FILES['iconew'][size]){
				$Data[ico] = $Fn_Flea_Market->UploadIconBanner($_FILES['iconew']);
			}else if(!empty($Post[iconew])){
				$Data[ico] = $Post[iconew];
			}
			$_GET['classid'] = DB::insert($Fn_Flea_Market->TableClass,$Data,true);
		}
		cpmsg($Fn_Flea_Market->Config[LangVar][ClassEditOk],$CpMsgUrl,'succeed');
	}
}else if($Operation == 'Del' && $_GET[formhash] == formhash() && !empty($_GET['classid'])){
	$SonClassIds =  $Fn_Flea_Market->GetSonClassIds($_GET['classid']);
	//ɾ����ĿAnd��Ʒ
	DB::delete($Fn_Flea_Market->TableClass,'id in ('.$SonClassIds.')');
	DB::delete($Fn_Flea_Market->TableInfo,'classid in ('.$SonClassIds.')');
	cpmsg($Fn_Flea_Market->Config[LangVar][DelOk],$CpMsgUrl,'succeed');
}
function ShowClassRow($Key, $Level = 0, $Last = ''){
	global $_G,$AllClass,$Fn_Flea_Market,$pluginid,$plugin;
	$Value = $AllClass[$Key];
	$value['info_count'] = GetClassCount($Key);
	$OpInfoCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminInfo';
	$OpClassCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
	if($Level == 2) {
		$Class = $Last ? 'lastchildboard' : 'childboard';
		$Return = '<tr class="hover" id="'.$Value['id'].'"><td>&nbsp;</td><td class="td25"><input type="text" class="txt" name="neworder['.$Value['id'].']" value="'.$Value['displayorder'].'" /></td><td><div class="'.$Class.'">'.
		'<input type="text" class="txt" name="name['.$Value['id'].']" value="'.$Value['name'].'" />'.
		'</div>'.
		'</td><td><input type="text" class="txt" name="bname['.$Value['id'].']" Value="'.$Value['bname'].'" />'.
		'</td>'.
		'<td>'.$value['info_count'].'</td><td>'.(!empty($Value['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$Fn_Flea_Market->Config[ListUrl].$Value['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$OpClassCpUrl.'&Operation=Edit&classid='.$Value['id'].'">'.$Fn_Flea_Market->Config[LangVar][EditTitle].'</a>&nbsp;&nbsp;<a href="'.$OpClassCpUrl.'&Operation=Del&classid='.$Value['id'].'&formhash='.FORMHASH.'">'.$Fn_Flea_Market->Config[LangVar][DelTitle].'</a>&nbsp;&nbsp;<a href="'.$OpInfoCpUrl.'&classid='.$Value['id'].'">'.$Fn_Flea_Market->Config[LangVar][ClassOpInfo].'</a>&nbsp;&nbsp;</td></tr>';
	}else if($Level == 1) {
		$Return = '<tr class="hover" id="'.$Value['id'].'"><td>&nbsp;</td><td class="td25"><input type="text" class="txt" name="neworder['.$Value['id'].']" value="'.$Value['displayorder'].'" /></td><td><div class="board">'.
		'<input type="text" class="txt" name="name['.$Value['id'].']" value="'.$Value['name'].'" />'.
		'<a class="addchildboard" href="'.$OpClassCpUrl.'&Operation=Add&bclassid='.$Value['id'].'">'.$Fn_Flea_Market->Config[LangVar][AddClassSonSonTitle].'</a></div>'.
		'</td><td><input type="text" class="txt" name="bname['.$Value['id'].']" Value="'.$Value['bname'].'" />'.
		'</td>'.
		'<td>'.$value['info_count'].'</td><td>'.(!empty($Value['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$Fn_Flea_Market->Config[ListUrl].$Value['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$OpClassCpUrl.'&Operation=Edit&classid='.$Value['id'].'">'.$Fn_Flea_Market->Config[LangVar][EditTitle].'</a>&nbsp;&nbsp;<a href="'.$OpClassCpUrl.'&Operation=Del&classid='.$Value['id'].'&formhash='.FORMHASH.'">'.$Fn_Flea_Market->Config[LangVar][DelTitle].'</a>&nbsp;&nbsp;<a href="'.$OpInfoCpUrl.'&classid='.$Value['id'].'">'.$Fn_Flea_Market->Config[LangVar][ClassOpInfo].'</a>&nbsp;&nbsp;</td></tr>';
		for($i=0,$L=count($Value['children']); $i<$L; $i++) {
			$Return .= ShowClassRow($Value['children'][$i], 2, $i==$L-1);
		}
	}else{
		$Childrennum = count(implode(',',$AllClass[$Key]['children']));
		$Toggle = $Childrennum > 25 ? ' style="display:none"' : '';
		$Return = '<tbody><tr class="hover" id="'.$Value['id'].'"><td onclick="toggle_group(\'group_'.$Value['id'].'\')"><a id="a_group_'.$Value['id'].'" href="javascript:;">'.($Toggle ? '[+]' : '[-]').'</a></td>'
		.'<td class="td25"><input type="text" class="txt" name="neworder['.$Value['id'].']" Value="'.$Value['displayorder'].'" /></td><td><div class="parentboard">'.
		'<input type="text" class="txt" name="name['.$Value['id'].']" Value="'.$Value['name'].'" />'.
		'</div>'.
		'</td><td><input type="text" class="txt" name="bname['.$Value['id'].']" Value="'.$Value['bname'].'" />'.
		'</td>'.
		'<td>'.$value['info_count'].'</td><td>'.(!empty($Value['display']) ? cplang('yes') : cplang('no')).'</td>'.
		'<td><a href="'.$Fn_Flea_Market->Config[ListUrl].$Value['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$OpClassCpUrl.'&Operation=Edit&classid='.$Value['id'].'">'.$Fn_Flea_Market->Config[LangVar][EditTitle].'</a>&nbsp;&nbsp;<a href="'.$OpClassCpUrl.'&Operation=Del&classid='.$Value['id'].'&formhash='.FORMHASH.'">'.$Fn_Flea_Market->Config[LangVar][DelTitle].'</a>&nbsp;&nbsp;<a href="'.$OpInfoCpUrl.'&classid='.$Value['id'].'">'.$Fn_Flea_Market->Config[LangVar][ClassOpInfo].'</a>&nbsp;&nbsp;</td></tr></tbody>
		<tbody id="group_'.$Value['id'].'"'.$Toggle.'>';
		for($i=0,$L=count($Value['children']); $i<$L; $i++) {
			$Return .= ShowClassRow($Value['children'][$i], 1, '');
		}
		$Return .= '</tdoby><tr><td>&nbsp;</td><td colspan="10"><div class="lastboard"><a class="addtr" href="'.$OpClassCpUrl.'&Operation=Add&bclassid='.$Value['id'].'">'.$Fn_Flea_Market->Config[LangVar][AddClassSonTitle].'</a></td></div>';
	}
	return $Return;
}
function GetClassCount($ClassId){
	global $Fn_Flea_Market;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Flea_Market->TableInfo).' where classid = '.$ClassId;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>