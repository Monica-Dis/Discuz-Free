<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_flea_market_class` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bclassid` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `bname` varchar(100) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `ico` varchar(255) NOT NULL DEFAULT '',
  `displayorder` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_flea_market_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `realname` varchar(30) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `wx` varchar(30) NOT NULL,
  `qq` varchar(20) NOT NULL,
  `classid` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `address` varchar(80) NOT NULL,
  `degree` tinyint(2) unsigned NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `body` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `detailspic` text NOT NULL,
  `sticktime` int(11) unsigned NOT NULL,
  `time` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL DEFAULT '0',
  `collect_count` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_flea_market_pay` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `money` decimal(11,2) unsigned NOT NULL,
  `givemoney` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `establish_time` int(11) unsigned NOT NULL,
  `pay_time` int(11) unsigned NOT NULL,
  `paytype` varchar(20) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_flea_market_banner` (
  `id` tinyint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `link` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `displayorder` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_member_profile` (
  `uid` int(11) unsigned NOT NULL,
  `wx` varchar(50) NOT NULL
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_flea_market_collect` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `info_id` int(11) unsigned NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
EOF;

runquery($sql);

$InfoTableField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_flea_market_info'));
$InfoToArray = MysqlToArray($InfoTableField);
if (!in_array('state',$InfoToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_flea_market_info`  ADD `state` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '0' AFTER `type`;
EOF;
	runquery($UpSql);
}
$UpSql = <<<EOF
	ALTER TABLE `pre_fn_flea_market_class` CHANGE `id` `id` INT( 11 ) UNSIGNED NOT NULL AUTO_INCREMENT;
	ALTER TABLE `pre_fn_flea_market_class` CHANGE `bclassid` `bclassid` INT( 11 ) UNSIGNED NOT NULL; 
EOF;
runquery($UpSql);

$UpSql = <<<EOF
	ALTER TABLE `pre_fn_flea_market_info` CHANGE `classid` `classid` INT( 11 ) UNSIGNED NOT NULL;
EOF;
runquery($UpSql);

function MysqlToArray($Array) {
    $temp = array();
    foreach ($Array as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
$finish = TRUE;/*dism-Taobao-com*/
?>