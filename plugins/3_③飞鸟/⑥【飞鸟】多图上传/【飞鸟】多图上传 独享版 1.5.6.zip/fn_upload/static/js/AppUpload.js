(function ($) {
    $.fn.AppUpload = function(options) {
		var FnApp = {
			MagApp: function() {
				return navigator.userAgent.match(/MAGAPPX/i) ? true: false;
			},
			Appbyme: function() {
				return navigator.userAgent.match(/Appbyme/i) ? true: false;
			},
			QFApp: function() {
				return navigator.userAgent.match(/QianFan/i) ? true: false;
			},
			WxApp: function() {
				return navigator.userAgent.match(/MicroMessenger/i) ? true: false;
			},
			iPhoneApp: function() {
				return navigator.userAgent.match(/(iPhone|iPad|iPod|iOS)/i) ? true: false;
			}
		};
		var FnHtml = function(ImgLink,InputName){
			var ReplaceFiledataInput = '';
			if(!FnApp.MagApp() && !FnApp.Appbyme() && !FnApp.WxApp()){
				ReplaceFiledataInput = '<input type="file" class="ReplaceFiledata" name="ReplaceFiledata[]"/>';
			}
			return '<div class="PhotoControl PhotoControlApp"> <span class="Close" style="display:block;"></span> <i class="icon-plus">+</i><div class="FilePic" style="display:block;"><table cellpadding="0" cellspacing="0"><tr><td><div class="PhotoControlImg" style="background:url('+ImgLink+') no-repeat center;background-size:contain;"></div><input type="hidden" name="'+InputName+'[]" value="'+ImgLink+'" class="InputFile"/></td></tr></table></div>'+ReplaceFiledataInput+'</div>';
		}
		return $(this).each(function() { 
			$.fn.AppUpload.deflunt={
				InputName:'imgs',//ͼƬ����Name
				Multiple:false,//�Ƿ񵥸�ͼ
				InputExist:false,//�Ƿ���ر���ͼƬ
				InputArray:null//����
			};
			var opts = $.extend({},$.fn.AppUpload.deflunt,options);
			var _This = $(this);
			if(opts.InputExist){
				for(var i = 0;i < InputArray.length; i++){
					_This.before(FnHtml(InputArray[i],opts.InputName));
				}
			}
			//��App��ͼ�ϴ�
			if(!FnApp.MagApp() && !FnApp.Appbyme() && !FnApp.WxApp()){
				var Filedata = _This.find('.Filedata');
				Filedata.on('change', function() {//�ϴ�ͼƬ
					for(var i = 0; i < this.files.length; i++) {
						$('.fixed_load').show();
						var files1 = [];
						files1.push(this.files[i]);
						$.buildfileupload({
							uploadurl: 'plugin.php?id=fn_upload:swfupload&operation='+UploadConfig.operation+'&type=image&inajax=yes&infloat=yes&simple=2&source='+UploadConfig.source,
							files: files1,
							uploadformdata: {uid:UploadConfig.Uid,hash:UploadConfig.Auth},
							uploadinputname: 'Filedata',
							maxfilesize:UploadConfig.MaxFileSize,
							success: function(Data){
								$('.fixed_load').hide();
								if(UploadConfig.operation == 'upload'){
									if(Data == ''){
										alert(UploadConfig.uploadpicfailed);
										return false;
									}
									var DataArray = Data.split('|');
									if(DataArray[0] == 'DISCUZUPLOAD' && DataArray[2] == 0){
										var ImgLink = DataArray[5];
										if(opts.Multiple){
											_This.siblings('.PhotoControlApp').remove()
										}
										_This.before(FnHtml(ImgLink,opts.InputName));
									}else{
										var sizelimit = '';
										if(DataArray[7] == 'ban') {
											sizelimit = UploadConfig.uploadpicatttypeban;
										} else if(DataArray[7] == 'perday') {
											sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[8]/1024)+'K)';
										} else if(DataArray[7] > 0) {
											sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[7]/1024)+'K)';
										}
										alert(STATUSMSG[DataArray[2]] + sizelimit);
									}
								}else if(UploadConfig.operation == 'poll'){
									var DataArray = JSON.parse(Data);
									if(DataArray.errorcode == 0 && DataArray.aid != 0){
										var ImgLink = DataArray.bigimg;
										if(opts.Multiple){
											_This.siblings('.PhotoControlApp').remove()
										}
										_This.before(FnHtml(ImgLink,opts.InputName));
									}else{
										alert(STATUSMSG[DataArray.errorcode]);
									}
								}
								
							},
							error:function(){
								$('.fixed_load').hide();
								alert(UploadConfig.uploadpicfailed);
							}
						});
					}
					
				});
				//�滻ͼƬ
				$(document).on('change','.ReplaceFiledata',function(){
					var _FilePic =  $(this).siblings('.FilePic');
					var _ImgThis = _FilePic.find('.PhotoControlImg');
					var _InputFile = _FilePic.find('.InputFile');
					for(var i = 0; i < this.files.length; i++) {
						$('.fixed_load').show();
						var files1 = [];
						files1.push(this.files[i]);
						$.buildfileupload({
							uploadurl: 'plugin.php?id=fn_upload:swfupload&operation='+UploadConfig.operation+'&type=image&inajax=yes&infloat=yes&simple=2&source='+UploadConfig.source,
							files: files1,
							uploadformdata: {uid:UploadConfig.Uid,hash:UploadConfig.Auth},
							uploadinputname: 'Filedata',
							maxfilesize:UploadConfig.MaxFileSize,
							success: function(Data){
								$('.fixed_load').hide();
								if(UploadConfig.operation == 'upload'){
									if(Data == ''){
										alert(UploadConfig.uploadpicfailed);
										return false;
									}
									var DataArray = Data.split('|');
									if(DataArray[0] == 'DISCUZUPLOAD' && DataArray[2] == 0){
										var ImgLink = DataArray[5];
										_ImgThis.css("background-image",'url('+ImgLink+')');
										_InputFile.val(ImgLink);
									}else{
										var sizelimit = '';
										if(DataArray[7] == 'ban') {
											sizelimit = UploadConfig.uploadpicatttypeban;
										} else if(DataArray[7] == 'perday') {
											sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[8]/1024)+'K)';
										} else if(DataArray[7] > 0) {
											sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[7]/1024)+'K)';
										}
										alert(STATUSMSG[DataArray[2]] + sizelimit);
									}
								}else if(UploadConfig.operation == 'poll'){
									var DataArray = JSON.parse(Data);
									if(DataArray.errorcode == 0 && DataArray.aid != 0){
										var ImgLink = DataArray.bigimg;
										_ImgThis.css("background-image",'url('+ImgLink+')');
										_InputFile.val(ImgLink);
									}else{
										alert(STATUSMSG[DataArray.errorcode]);
									}
								}
							},
							error:function(){
								$('.fixed_load').hide();
								alert(UploadConfig.uploadpicfailed);
							}
						});
					}
				});
				//�滻ͼƬ End
			}
			//��App��ͼ�ϴ� End

			/* ΢�ų�ʼ�� */
			if(FnApp.WxApp()){
				wx.config({
					//debug:true,
					appId: UploadConfig.appId,
					timestamp: UploadConfig.timestamp,
					nonceStr: UploadConfig.nonceStr,
					signature: UploadConfig.signature,
					jsApiList: ['checkJsApi','chooseImage','previewImage','uploadImage','downloadImage']
				});
			}
			/* ΢�ų�ʼ�� End */

			//App�ϴ�ͼƬ
			_This.on('click',function(){
				if(FnApp.MagApp()){//����App�ϴ�ͼƬ
					mag.picPick({
					  preview: function(res){
						 $('.fixed_load').show();
					  },
					  success: function(res){
						if(opts.Multiple){
							_This.siblings('.PhotoControlApp').remove()
						}
						var ImgLink = 'http://'+UploadConfig.MagDomain+'/core/attachment/attachment/attach?aid='+res.aid;
						_This.before(FnHtml(ImgLink,opts.InputName));
						$('.fixed_load').hide();
					  },
					  fail: function(res){
						$('.fixed_load').hide();
						mag.toast(UploadConfig.uploadpicfailed);
					  },
					});
					return false;
				}else if(FnApp.Appbyme()){//С��App�ϴ�ͼƬ
					sq3.startPhotoUpload({
						moduleType:'plugin',//�����ϴ���Դģ��('forum�����ӣ�album����ᣬpm��˽�ţ�topic:����, plugin:�����Ĭ�ϣ�plugin)
						beforeAsyncProcess: function(data) {
							$('.fixed_load').show();
						},
						success: function(data) {
							$('.fixed_load').hide();
							$.each(data, function(Index, Obj) {
								if(opts.Multiple){
									_This.siblings('.PhotoControlApp').remove()
								}
								if(FnApp.iPhoneApp()){
									_This.before(FnHtml(Obj.urlName,opts.InputName));
								}else{
									_This.before(FnHtml(Obj.picPath,opts.InputName));
								}
								
							});
							
						},
						error: function(data) {
							$('.fixed_load').hide();
							sq3.toast({text:data.errMsg,isLong: false});
						},
						complete: function(result) {
							
						}
					});
					return false;
				}else if(FnApp.WxApp()){//΢���ϴ�ͼƬ
					var WxCount = opts.Multiple ? 1 : 9;
					var images = {localId:[]};  
					wx.chooseImage({//ѡ��ͼƬ
						count: WxCount, // ������ѡ���ͼƬ������Ĭ��9
						sizeType: ['compressed'], // original ԭͼ��compressed ѹ��ͼ��Ĭ�϶��߶���
						success: function (res) {
							images.localId = res.localIds;// ����ѡ����Ƭ�ı���ID�б���localId������Ϊimg��ǩ��src������ʾͼƬ
							var i = 0, length = images.localId.length;
							images.serverId = "";
							function Fn_Upload() { 
								wx.uploadImage({ 
									localId: images.localId[i], 
									success: function(res) { 
										i++; 
										images.serverId += ("&serverId[]="+res.serverId);
										if(i < length) { 
											Fn_Upload(); 
										}else{
											$.ajax({
												type: "GET",
												url: "plugin.php?id=fn_upload:WxDownload"+images.serverId+'&source='+UploadConfig.source,
												dataType: "json",
												beforeSend:function(XMLHttpRequest){
													$('.fixed_load').show();
												},
												success: function(Data){
													$('.fixed_load').hide();
													if(!Data || Data.length <1) {
														alert(UploadConfig.uploadpicfailed);
														return false;
													}
													for(var i=0; i<Data.length; i++){
														var DataArray = Data[i].split('|');
														if(UploadConfig.operation == 'upload'){
															if(DataArray[0] == 'DISCUZUPLOAD' && DataArray[2] == 0){
																if(opts.Multiple){
																	_This.siblings('.PhotoControlApp').remove()
																}
																var ImgLink = DataArray[5];
																_This.before(FnHtml(ImgLink,opts.InputName));
															}else{
																var sizelimit = '';
																if(DataArray[7] == 'ban') {
																	sizelimit = UploadConfig.uploadpicatttypeban;
																} else if(DataArray[7] == 'perday') {
																	sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[8]/1024)+'K)';
																} else if(DataArray[7] > 0) {
																	sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[7]/1024)+'K)';
																}
																alert(STATUSMSG[DataArray[2]] + sizelimit);
															}
														}else if(UploadConfig.operation == 'poll'){
															if(DataArray[3] == 0 && DataArray[0] != 0){
																if(opts.Multiple){
																	_This.siblings('.PhotoControlApp').remove()
																}
																var ImgLink = DataArray[2];
																_This.before(FnHtml(ImgLink,opts.InputName));
															}else{
																alert(STATUSMSG[DataArray[3]]);
															}
														}

													}
												},
												error:function(XMLHttpRequest){
													$('.fixed_load').hide();
												}
											});
										}
									}, 
									fail: function(res) { 
										alert(JSON.stringify(res)); 
									} 
								}); 
							} 
							Fn_Upload();
						}
					});
					return false;
				}

			});
			$(document).on('click',".PhotoControlApp .PhotoControlImg",function(){//�滻ͼƬ
				var _ImgThis =  $(this);
				var _InputFile =  $(this).siblings('.InputFile');
				if(FnApp.MagApp()){//����App�滻ͼƬ
					mag.picPick({
						preview: function(res){
							$('.fixed_load').show();
						},
						success: function(res){
							var ImgLink = 'http://'+UploadConfig.MagDomain+'/core/attachment/attachment/attach?aid='+res.aid;
							_ImgThis.css("background-image",'url('+ImgLink+')');
							_InputFile.val(ImgLink);
							$('.fixed_load').hide();
						},
						fail: function(res){
							$('.fixed_load').hide();
							mag.toast(UploadConfig.uploadpicfailed);
						},
					});
				}else if(FnApp.Appbyme()){//С��App�滻ͼƬ
					sq3.startPhotoUpload({
						moduleType:'plugin',//�����ϴ���Դģ��('forum�����ӣ�album����ᣬpm��˽�ţ�topic:����, plugin:�����Ĭ�ϣ�plugin)
						beforeAsyncProcess: function(data) {
							$('.fixed_load').show();
						},
						success: function(data) {
							$('.fixed_load').hide();
							$.each(data, function(Index, Obj) {
								if(FnApp.iPhoneApp()){
									_ImgThis.css("background-image",'url('+Obj.urlName+')');
									_InputFile.val(Obj.urlName);
								}else{
									_ImgThis.css("background-image",'url('+Obj.picPath+')');
									_InputFile.val(Obj.picPath);
								}
							});
							
						},
						error: function(data) {
							$('.fixed_load').hide();
							sq3.toast({text:data.errMsg,isLong: false});
						},
						complete: function(result) {
							
						}
					});
				}else if(FnApp.WxApp()){//΢���滻ͼƬ
					var images = {localId:[]};
					wx.chooseImage({//ѡ��ͼƬ
						count: 1, // ������ѡ���ͼƬ������Ĭ��9
						sizeType: ['compressed'], // original ԭͼ��compressed ѹ��ͼ��Ĭ�϶��߶���
						success: function (res) {
							images.localId = res.localIds;// ����ѡ����Ƭ�ı���ID�б���localId������Ϊimg��ǩ��src������ʾͼƬ
							var i = 0, length = images.localId.length;
							images.serverId = "";
							function Fn_Upload() { 
								wx.uploadImage({ 
									localId: images.localId[i], 
									success: function(res) { 
										i++; 
										images.serverId += ("&serverId[]="+res.serverId);
										if(i < length) { 
											Fn_Upload(); 
										}else{
											$.ajax({
												type: "GET",
												url: "plugin.php?id=fn_upload:WxDownload"+images.serverId+'&source='+UploadConfig.source,
												dataType: "json",
												beforeSend:function(XMLHttpRequest){
													$('.fixed_load').show();
												},
												success: function(Data){
													$('.fixed_load').hide();
													if(!Data || Data.length <1) {
														alert(UploadConfig.uploadpicfailed);
														return false;
													}
													for(var i=0; i<Data.length; i++){
														var DataArray = Data[i].split('|');
														if(UploadConfig.operation == 'upload'){
															if(DataArray[0] == 'DISCUZUPLOAD' && DataArray[2] == 0){
																var ImgLink = DataArray[5];
																_ImgThis.css("background-image",'url('+ImgLink+')');
																_InputFile.val(ImgLink);
															}else{
																var sizelimit = '';
																if(DataArray[7] == 'ban') {
																	sizelimit = UploadConfig.uploadpicatttypeban;
																} else if(DataArray[7] == 'perday') {
																	sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[8]/1024)+'K)';
																} else if(DataArray[7] > 0) {
																	sizelimit = UploadConfig.donotcross+Math.ceil(DataArray[7]/1024)+'K)';
																}
																alert(STATUSMSG[DataArray[2]] + sizelimit);
															}
														}else if(UploadConfig.operation == 'poll'){
															if(DataArray[3] == 0 && DataArray[0] != 0){
																var ImgLink = DataArray[2];
																_ImgThis.css("background-image",'url('+ImgLink+')');
																_InputFile.val(ImgLink);
															}else{
																alert(STATUSMSG[DataArray[3]]);
															}
														}
														
													}
												},
												error:function(XMLHttpRequest){
													$('.fixed_load').hide();
												}
											});
										}
									}, 
									fail: function(res) { 
										alert(JSON.stringify(res)); 
									} 
								}); 
							} 
							Fn_Upload();
						}
					});
				}
			});
			//App�ϴ�ͼƬEnd
			$(document).on('click',".PhotoControlApp .Close",function(){
				$(this).parent('.PhotoControlApp').remove();
				return false;
			});
		}); 
	}
})(jQuery);