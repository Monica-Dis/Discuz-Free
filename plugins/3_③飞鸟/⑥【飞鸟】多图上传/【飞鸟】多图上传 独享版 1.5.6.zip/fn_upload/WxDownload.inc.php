<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
$ServerIdArr = $_GET['serverId'];
$WxAppid = $_G['cache']['plugin']['fn_upload']['WxAppid'];
$WxSecret = $_G['cache']['plugin']['fn_upload']['WxSecret'];
$Temp = $Data = array();
if($ServerIdArr){
	$Url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$WxAppid&secret=$WxSecret";
    $Res = json_decode(dfsockopen($Url));
    $AccessToken = $Res->access_token;
	foreach ($ServerIdArr as $ServerId) {
		$Temp[] = "https://file.api.weixin.qq.com/cgi-bin/media/get?access_token=$AccessToken&media_id=$ServerId";		
	}
	if(is_array($Temp) && $Temp){
		require_once libfile('class/image');
		require_once libfile('function/upload');
		$upload = new discuz_upload();
		foreach($Temp as $ImageUrl) {
			$Hash  = md5($ImageUrl);
			if($ImageUrl && preg_match('/^(https:\/\/|\.)/i',$ImageUrl) && !isset($existentimg[$Hash])){
				$existentimg[$Hash] = $ImageUrl;
				$Content = HttpGet($ImageUrl);
				if(!$Content){
					$Content = file_get_contents($ImageUrl);
				}
				if(empty($Content)) continue;
		
				$attach['ext'] = 'jpg';
				$attach['name']  =  uniqid('wx'.time());
				$attach['thumb'] = '';
				$attach['isimage'] = 1;
				$attach['extension'] = $upload->get_target_extension($attach['ext']);
				$attach['attachdir'] = $upload->get_target_dir('forum');
				$attach['attachment'] = $attach['attachdir'] . $upload->get_target_filename('forum').'.'.$attach['extension'];
				$attach['target'] = getglobal('setting/attachdir').'./forum/'.$attach['attachment'];
				if(!@$fp = fopen($attach['target'], 'wb')) {
					continue;
				}else{
					flock($fp, 2);
					fwrite($fp, $Content);
					fclose($fp);
				}
				if(!$upload->get_image_info($attach['target'])) {
					@unlink($attach['target']);
					continue;
				}
				$attach['size'] = filesize($attach['target']);
				$upload->attach = $attach;

				if(!$_G['cache']['plugin']['fn_upload']['RemoteAttachments'] || ($_G['cache']['plugin']['fn_upload']['OssAccessId'] && $_G['cache']['plugin']['fn_upload']['OssAccessKey'] && $_G['cache']['plugin']['fn_upload']['OssEndPoint']) ){
					/* ͼƬ�ж� */
					if($_G['group']['maxattachsize'] && $upload->attach['size'] > $_G['group']['maxattachsize']) {
						$ErrorSizelimit = $_G['group']['maxattachsize'];
						@unlink($attach['target']);
						UploadMsg(3, 0, '', '', $ErrorSizelimit);
					}

					loadcache('attachtype');
					if($_G['fid'] && isset($_G['cache']['attachtype'][$_G['fid']][$upload->attach['ext']])) {
						$maxsize = $_G['cache']['attachtype'][$_G['fid']][$upload->attach['ext']];
					} elseif(isset($_G['cache']['attachtype'][0][$upload->attach['ext']])) {
						$maxsize = $_G['cache']['attachtype'][0][$upload->attach['ext']];
					}
					if(isset($maxsize)) {
						if(!$maxsize) {
							$ErrorSizelimit = 'ban';
							@unlink($attach['target']);
							UploadMsg(4, 0, '', '', $ErrorSizelimit);
						} elseif($upload->attach['size'] > $maxsize) {
							$ErrorSizelimit = $maxsize;
							@unlink($attach['target']);
							UploadMsg(5, 0, '', '', $ErrorSizelimit);
						}
					}
					if($upload->attach['size'] && $_G['group']['maxsizeperday']) {
						$todaysize = getuserprofile('todayattachsize') + $upload->attach['size'];
						if($todaysize >= $_G['group']['maxsizeperday']) {
							$ErrorSizelimit = 'perday|'.$_G['group']['maxsizeperday'];
							@unlink($attach['target']);
							UploadMsg(11, 0, '', '', $ErrorSizelimit);
						}
					}
					/* ͼƬ�ж� End */
					if($upload->attach['isimage']) {
						if($_G['setting']['thumbsource'] && $_G['setting']['sourcewidth'] && $_G['setting']['sourceheight']) {
							$image = new image();
							$thumb = $image->Thumb($upload->attach['target'], '', $_G['setting']['sourcewidth'], $_G['setting']['sourceheight'], 1, 1) ? 1 : 0;
							$width = $image->imginfo['width'];
							$upload->attach['size'] = $image->imginfo['size'];
						}
						if($_G['setting']['thumbstatus']) {
							$image = new image();
							$thumb = $image->Thumb($upload->attach['target'], '', $_G['setting']['thumbwidth'], $_G['setting']['thumbheight'], $_G['setting']['thumbstatus'], 0) ? 1 : 0;
							$width = $image->imginfo['width'];
						}
						if($_G['setting']['thumbsource'] || !$_G['setting']['thumbstatus']) {
							list($width) = @getimagesize($upload->attach['target']);
						}
						if($_G['setting']['watermarkstatus'] && empty($_G['forum']['disablewatermark'])) {
							$image = new image();
							$image->Watermark($attach['target'], '', 'forum');
							$upload->attach['size'] = $image->imginfo['size'];
						}
					}
					$Aid = 1;
					/*$Aid = getattachnewaid();

					$insert = array(
						'aid' => $Aid,
						'dateline' => $_G['timestamp'],
						'filename' => dhtmlspecialchars(censor($upload->attach['name'])),
						'filesize' => $upload->attach['size'],
						'attachment' => $upload->attach['attachment'],
						'isimage' => $upload->attach['isimage'],
						'uid' => $_G[uid],
						'thumb' => $thumb,
						'remote' => '0',
						'width' => $width,
					);
			
					C::t('forum_attachment_unused')->insert($insert);*/

					$upload->attach['attachment'] = $_G['setting']['attachurl'].'forum/'.$upload->attach['attachment'];
					
					if($_G['cache']['plugin']['fn_upload']['OssAccessId'] && $_G['cache']['plugin']['fn_upload']['OssAccessKey'] && $_G['cache']['plugin']['fn_upload']['OssEndPoint']){
						 @include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/common.php';
						 if($ImageUrl = AliOssUpload($upload->attach['name'].'.'.$upload->attach['ext'],$upload->attach['attachment'],$_GET['source'])) {
							@unlink(DISCUZ_ROOT.$upload->attach['attachment']);
							$upload->attach['attachment'] = $ImageUrl;
						}

					}
					$Data[] = UploadMsg(0,$Aid,$upload->attach['attachment'],$upload->attach['name']);
				}else{//Զ�̸���
					if(!$upload->attach['isimage']) {
						$errorcode = 4;
					} else {
						$upload->save();
						$errorcode = 0;
					}
					
					if($attach['isimage']) {
						require_once libfile('class/image');
						$image = new image();
						$thumbimgwidth = 300;
						$thumbimgheight = 300;
						$attach['thumb'] = $image->Thumb($attach['target'], '', $thumbimgwidth, $thumbimgheight, 2);
						$image->Watermark($attach['target'], '', 'forum');
						$imginfo = @getimagesize($attach['target']);
						if($imginfo !== FALSE) {
							$attach['width'] = $imginfo[0];
						}
					}
					if(getglobal('setting/ftp/on') && ((!$_G['setting']['ftp']['allowedexts'] && !$_G['setting']['ftp']['disallowedexts']) || ($_G['setting']['ftp']['allowedexts'] && in_array($attach['ext'], $_G['setting']['ftp']['allowedexts'])) || ($_G['setting']['ftp']['disallowedexts'] && !in_array($attach['ext'], $_G['setting']['ftp']['disallowedexts']))) && (!$_G['setting']['ftp']['minsize'] || $attach['size'] >= $_G['setting']['ftp']['minsize'] * 1024)) {
						if(ftpcmd('upload', 'forum/'.$attach['attachment']) && (!$attach['thumb'] || ftpcmd('upload', 'forum/'.getimgthumbname($attach['attachment'])))) {
							@unlink($_G['setting']['attachdir'].'/forum/'.$attach['attachment']);
							@unlink($_G['setting']['attachdir'].'/forum/'.getimgthumbname($attach['attachment']));
							$attach['remote'] = 1;
						} else {
							if(getglobal('setting/ftp/mirror')) {
								@unlink($attach['target']);
								@unlink(getimgthumbname($attach['target']));
								$errorcode = 5;
							}
						}
					}
					if(!$errorcode) {
						$aid = intval($_GET['aid']);
						$setarr = array(
								'uid' => $_G['uid'],
								'filename' => $attach['name'],
								'attachment' => $attach['attachment'],
								'filesize' => $attach['size'],
								'thumb' => $attach['thumb'],
								'remote' => $attach['remote'],
								'dateline' => $_G['timestamp'],
								'width' => $attach['width']
						);
						$image = array();
						if($aid) {
							$image = C::t('forum_polloption_image')->fetch($aid);
						}
						if($image['uid'] == $_G['uid']) {
							C::t('forum_polloption_image')->update($aid, $setarr);
							@unlink($_G['setting']['attachdir'].'/forum/'.$image['attachment']);
							@unlink($_G['setting']['attachdir'].'/forum/'.getimgthumbname($image['attachment']));
							$attach['attachid'] = $aid;
						} else {
							$attach['attachid'] = C::t('forum_polloption_image')->insert($setarr, true);
						}

						require_once libfile('function/home');
						$smallimg = pic_get($attach['attachment'], 'forum', $attach['thumb'], $attach['remote']);
						$bigimg = pic_get($attach['attachment'], 'forum', 0, $attach['remote']);
						$Data[] = $attach['attachid'].'|'.$smallimg.'|'.$bigimg.'|'.$errorcode;
					} else {
						$Data[] = '0|0|0|'.$errorcode;
					}
				}
			}
		}
	}
	echo json_encode($Data);
	exit;
}else{
	echo json_encode(array());
	exit;
}
				
function HttpGet($url) {
    $res = dfsockopen($url);
	if(!$res){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_TIMEOUT, 500);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_URL, $url);

		$res = curl_exec($curl);
		curl_close($curl);
	}
    return $res;
}

function UploadMsg($Statusid, $Aid, $Attachment=null, $Name=null, $ErrorSizelimit = 0) {
    $Return = 'DISCUZUPLOAD|'.'1'.'|'.$Statusid.'|'. $Aid .'|1|'. $Attachment .'|'.$Name.'|'. $ErrorSizelimit;
    if($ErrorSizelimit){
        echo json_encode(array($Return));
        exit;
    }
    return $Return;
}
?>