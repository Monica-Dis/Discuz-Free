<?php


if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/Result.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/OssClient.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/XmlConfig.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Core/MimeTypes.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Core/OssException.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Core/OssUtil.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Http/RequestCore.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Http/RequestCore_Exception.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Http/ResponseCore.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/BucketInfo.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/BucketListInfo.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/CorsConfig.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/CorsRule.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/GetLiveChannelHistory.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/GetLiveChannelInfo.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/GetLiveChannelStatus.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/LifecycleAction.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/LifecycleConfig.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/LifecycleRule.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/ListMultipartUploadInfo.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/ListPartsInfo.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/LiveChannelConfig.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/LiveChannelHistory.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/LiveChannelInfo.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/LiveChannelListInfo.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/LoggingConfig.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/ObjectInfo.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/ObjectListInfo.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/PartInfo.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/PrefixInfo.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/RefererConfig.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/UploadInfo.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/WebsiteConfig.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Model/CnameConfig.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/PutSetDeleteResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/AclResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/AppendResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/BodyResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/CallbackResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/CopyObjectResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/DeleteObjectsResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/ExistResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/GetCnameResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/GetCorsResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/GetLifecycleResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/GetLiveChannelHistoryResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/GetLiveChannelInfoResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/GetLiveChannelStatusResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/GetLoggingResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/GetRefererResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/GetWebsiteResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/HeaderResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/InitiateMultipartUploadResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/ListBucketsResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/ListLiveChannelResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/ListMultipartUploadResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/ListObjectsResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/ListPartsResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/PutLiveChannelResult.php';
include_once DISCUZ_ROOT.'source/plugin/fn_upload/lib/OSS/Result/UploadPartResult.php';

use \OSS\OssClient;

function AliOssUpload($Name,$File,$Source){
    global $_G;
	loadcache('plugin');
    try{
        $OssClient = new OssClient($_G['cache']['plugin']['fn_upload']['OssAccessId'], $_G['cache']['plugin']['fn_upload']['OssAccessKey'], $_G['cache']['plugin']['fn_upload']['OssEndPoint'], false);
        $Ret = $OssClient->uploadFile($_G['cache']['plugin']['fn_upload']['OssBucket'], ($Source ? $Source.'/' : '').date('Ymd').'/'.$Name, DISCUZ_ROOT.$File);
    }catch (Exception $E){
        $Ret = array( 'oss-request-url' => $E->getMessage() );
    }	
    $Rurl = $Ret['oss-request-url'] ? $Ret['oss-request-url'] : '';
    if($_G['cache']['plugin']['fn_upload']['OssUrl']){
        $R = parse_url($Rurl);
        $Rurl = str_replace($R['scheme']."://".$R['host'], $_G['cache']['plugin']['fn_upload']['OssUrl'], $Rurl);
    }
    return $Rurl;
}


?>