<?php
/**
 *	[【飞鸟】相亲交友(fn_xiangqin.{modulename})] (C)2016-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2018-4-30 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/'.$plugin_id.'/config.php');
$mat = $fn_xiangqin->matList[$_GET['mat_id']];
if(!$mat){
	showmessage('&#32418;&#23064;&#19981;&#23384;&#22312;');
	exit();
}
if($setting['WxAppid'] && $setting['WxSecret']){
	if(WxApp){
		if($_GET['code']){
			@require_once libfile('class/wechat','plugin/fn_assembly');
			$wechatClient = new Fn_WeChatClient($setting['WxAppid'],$setting['WxSecret']);
			$token = $wechatClient->getAccessTokenByCode($_GET['code']);
			if($token['openid']){
				C::t('#fn_xiangqin#fn_love_mat')->update(array('openid'=>$token['openid']),$mat['id']);
				checkMat();
				showmessage('&#32465;&#23450;&#25104;&#21151;&#65292;&#35831;&#21047;&#26032;&#32418;&#23064;&#31649;&#29702;&#39029;&#38754;');
			}else{
				showmessage('&#32465;&#23450;&#22833;&#36133;');
			}
			exit();
		}else{
			if(strpos($setting['WxOauthDomain'],'oauth2.htm') !== false) {
				$jumpUrl = $setting['WxOauthDomain'].'?appid='.$setting['WxAppid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.urlencode($jumpReferer);
			}else{
				$jumpUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$setting['WxAppid'].'&redirect_uri=' . urlencode($jumpReferer).'&response_type=code&scope=snsapi_userinfo&state='. md5(FORMHASH).'#wechat_redirect';
			}
			dheader('Location:'.$jumpUrl);
			exit();
		}
	}else{
		showmessage('&#35831;&#20351;&#29992;&#24494;&#20449;&#25195;&#30721;');
	}
}else{
	showmessage('&#27809;&#26377;&#35774;&#32622;&#24494;&#20449;&#65;&#80;&#80;&#73;&#68;&#65292;&#35831;&#21069;&#24448;&#21069;&#21488;&#31649;&#45;&#12299;&#30456;&#20146;&#61;&#12299;&#24120;&#35268;&#35774;&#32622;&#45;&#12299;&#20844;&#20247;&#21495;&#35774;&#32622;');
}
function checkMat(){
	global $fn_xiangqin;
	$check = array();
	foreach(C::t('#fn_xiangqin#fn_love_mat')->fetch_all_by_list() as $val){
		$check[$val['id']] = $val;
	}
	savecache('fn_love_mat',$check);
}
//From: Dism·taobao·com
?>