<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_love_activity` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `banner` text NOT NULL,
  `price_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `price` decimal(11,2) unsigned NOT NULL,
  `price_1` decimal(11,2) unsigned NOT NULL,
  `price_2` decimal(11,2) unsigned NOT NULL,
  `vip_price` decimal(11,2) unsigned NOT NULL,
  `real_verify` tinyint(1) unsigned NOT NULL,
  `user_audit` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `signup_start_dateline` int(11) unsigned NOT NULL,
  `signup_end_dateline` int(11) unsigned NOT NULL,
  `start_dateline` int(11) unsigned NOT NULL,
  `end_dateline` int(11) unsigned NOT NULL,
  `address` varchar(255) NOT NULL,
  `male_number` smallint(5) unsigned NOT NULL,
  `female_number` smallint(5) unsigned NOT NULL,
  `vip_act` tinyint(1) unsigned NOT NULL,
  `content` text NOT NULL,
  `share_title` varchar(255) NOT NULL,
  `share_desc` varchar(255) NOT NULL,
  `share_logo` varchar(255) NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_activity_signup` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `vid` int(11) unsigned NOT NULL,
  `sex` tinyint(1) unsigned NOT NULL,
  `audit_state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `aid` (`aid`,`uid`,`vid`,`audit_state`,`sex`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_con_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `vid` int(11) unsigned NOT NULL,
  `love_vid` int(11) unsigned NOT NULL,
  `event_type` tinyint(2) unsigned NOT NULL,
  `pull` int(11) unsigned NOT NULL,
  `currency` int(11) unsigned NOT NULL,
  `imkey` int(11) unsigned NOT NULL,
  `act` int(11) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `content` varchar(255) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `vid` (`vid`,`uid`,`love_vid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_follow` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(11) unsigned NOT NULL,
  `love_vid` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`vid`,`love_vid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_gift` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `money` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `displayorder` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_gift_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `gift_id` int(11) unsigned NOT NULL,
  `vid` int(11) unsigned NOT NULL,
  `love_vid` int(11) unsigned NOT NULL,
  `count` int(11) unsigned NOT NULL,
  `currency` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gift_id` (`gift_id`,`vid`,`love_vid`,`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_look` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(11) unsigned NOT NULL,
  `love_vid` int(11) unsigned NOT NULL,
  `count` int(11) unsigned NOT NULL DEFAULT '1',
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`vid`,`love_vid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_mat` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `staff_id` int(11) unsigned NOT NULL,
  `openid` char(32) NOT NULL,
  `name` varchar(30) NOT NULL,
  `wx` varchar(30) NOT NULL,
  `qrcode` varchar(255) NOT NULL,
  `head_portrait` varchar(255) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `displayorder` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `staff_id` (`staff_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_meal` (
  `id` tinyint(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL,
  `icon` varchar(255) NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` varchar(255) NOT NULL,
  `currency` int(11) unsigned NOT NULL,
  `imkey` int(11) unsigned NOT NULL,
  `pull` int(11) unsigned NOT NULL,
  `act` int(11) unsigned NOT NULL,
  `day` smallint(3) unsigned NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `limit` tinyint(2) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `displayorder` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_meal_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `vid` int(11) unsigned NOT NULL,
  `group_id` tinyint(3) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`vid`,`group_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `per_check` tinyint(1) unsigned NOT NULL,
  `mat_id` int(11) unsigned NOT NULL,
  `group_id` tinyint(3) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(20) NOT NULL,
  `openid` char(32) NOT NULL,
  `unionid` char(32) NOT NULL,
  `head_portrait` varchar(255) NOT NULL,
  `video_type` tinyint(1) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `name` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `wx` varchar(20) NOT NULL,
  `sex` tinyint(1) unsigned NOT NULL,
  `age` tinyint(3) unsigned NOT NULL,
  `birth` varchar(20) NOT NULL,
  `animal` tinyint(2) unsigned NOT NULL,
  `constellation` tinyint(2) unsigned NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `height` tinyint(3) unsigned NOT NULL,
  `education` tinyint(2) unsigned NOT NULL,
  `marriage` tinyint(1) unsigned NOT NULL,
  `nation` tinyint(2) unsigned NOT NULL,
  `family` tinyint(1) unsigned NOT NULL,
  `month_income` tinyint(2) unsigned NOT NULL,
  `only` tinyint(1) unsigned NOT NULL,
  `child` tinyint(1) unsigned NOT NULL,
  `want_child` tinyint(1) unsigned NOT NULL,
  `occupation` tinyint(2) unsigned NOT NULL,
  `vehicle` tinyint(1) unsigned NOT NULL,
  `house` tinyint(1) unsigned NOT NULL,
  `when_marry` tinyint(1) unsigned NOT NULL,
  `shape` tinyint(1) unsigned NOT NULL,
  `smoke` tinyint(1) unsigned NOT NULL,
  `drink` tinyint(1) unsigned NOT NULL,
  `religion` tinyint(2) unsigned NOT NULL,
  `graduate_school` varchar(50) NOT NULL,
  `major` varchar(20) NOT NULL,
  `company` varchar(50) NOT NULL,
  `company_nature` tinyint(2) unsigned NOT NULL,
  `position` varchar(20) NOT NULL,
  `album` text NOT NULL,
  `hobby` varchar(255) NOT NULL,
  `hobby_arr` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `introduce` varchar(255) NOT NULL,
  `req_tag` varchar(255) NOT NULL,
  `req_age_min` tinyint(3) unsigned NOT NULL,
  `req_age_max` tinyint(3) unsigned NOT NULL,
  `req_height_min` tinyint(3) unsigned NOT NULL,
  `req_height_max` tinyint(3) unsigned NOT NULL,
  `req_month_income` tinyint(2) unsigned NOT NULL,
  `req_education` tinyint(2) unsigned NOT NULL,
  `req_nation` tinyint(2) unsigned NOT NULL,
  `req_house` tinyint(1) unsigned NOT NULL,
  `req_vehicle` tinyint(1) unsigned NOT NULL,
  `req_marriage` tinyint(2) unsigned NOT NULL,
  `req_want_child` tinyint(1) unsigned NOT NULL,
  `req_smoke` tinyint(1) unsigned NOT NULL,
  `req_drink` tinyint(1) unsigned NOT NULL,
  `req_accept_child` tinyint(1) unsigned NOT NULL,
  `pull` int(11) unsigned NOT NULL,
  `currency` int(11) unsigned NOT NULL,
  `imkey` int(11) unsigned NOT NULL,
  `act` int(11) unsigned NOT NULL,
  `open_contact` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `open_love` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `phone_verify` tinyint(1) unsigned NOT NULL,
  `real_verify` tinyint(1) unsigned NOT NULL,
  `education_verify` tinyint(1) unsigned NOT NULL,
  `vehicle_verify` tinyint(1) unsigned NOT NULL,
  `house_verify` tinyint(1) unsigned NOT NULL,
  `offline_verify` tinyint(1) unsigned NOT NULL,
  `audit_state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `refuse_tips` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `seal` tinyint(3) unsigned NOT NULL,
  `hot` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `channel` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `due_time` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `editdateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  `wxdateline` int(11) unsigned NOT NULL,
  `day_refresh_dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`sex`,`education`,`marriage`,`month_income`,`occupation`,`id`,`req_month_income`,`req_education`,`req_house`,`req_vehicle`,`display`,`audit_state`,`seal`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_user_contact_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `vid` int(11) unsigned NOT NULL,
  `love_vid` int(11) unsigned NOT NULL,
  `imkey` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `vid` (`vid`,`love_vid`,`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_user_far_single` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(11) unsigned NOT NULL,
  `mat_id` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `album` text NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `id` (`id`,`vid`,`display`,`mat_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_user_follow_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mat_id` int(11) unsigned NOT NULL,
  `vid` int(11) unsigned NOT NULL,
  `pic` text NOT NULL,
  `content` text NOT NULL,
  `follow_dateline` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mat_id` (`mat_id`,`vid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_user_pull_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mat_id` int(11) unsigned NOT NULL,
  `vid` int(11) unsigned NOT NULL,
  `love_vid` int(11) unsigned NOT NULL,
  `state` tinyint(2) unsigned NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `pull_dateline` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `vid` (`vid`,`love_vid`,`state`,`mat_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_user_report` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `vid` int(11) unsigned NOT NULL,
  `love_vid` int(11) unsigned NOT NULL,
  `type` tinyint(2) unsigned NOT NULL,
  `evidence` text NOT NULL,
  `content` varchar(255) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `handle_dateline` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`vid`,`love_vid`,`type`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_love_verify` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `vid` int(11) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `cert_img` text NOT NULL,
  `content` text NOT NULL,
  `audit_state` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `refuse_tips` varchar(255) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`vid`,`type`,`audit_state`)
) ENGINE=MyISAM;

ALTER TABLE `pre_fn_love_user` CHANGE `req_education` `req_education` TINYINT( 2 ) UNSIGNED NOT NULL;
ALTER TABLE `pre_fn_love_user` CHANGE `req_marriage` `req_marriage` TINYINT( 2 ) UNSIGNED NOT NULL;
ALTER TABLE `pre_fn_love_meal` CHANGE `day` `day` SMALLINT( 3 ) UNSIGNED NOT NULL;

EOF;

runquery($sql);

$user_field = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_love_user'));
$user_array = MysqlToArray($user_field);

$activity_field = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_love_activity'));
$activity_array = MysqlToArray($activity_field);

$mat_field = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_love_mat'));
$mat_array = MysqlToArray($mat_field);

if(!in_array('comment',$user_array)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_love_user` ADD `comment` TEXT NOT NULL AFTER `hobby_arr` ;
EOF;
	runquery($UpSql);
}

if(!in_array('introduce',$user_array)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_love_user` ADD `introduce` VARCHAR( 255 ) NOT NULL AFTER `comment` ;
EOF;
	runquery($UpSql);
}

if(!in_array('remarks',$user_array)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_love_user` ADD `remarks` TEXT NOT NULL AFTER `refuse_tips` ;
EOF;
	runquery($UpSql);
}

if(!in_array('day_refresh_dateline',$user_array)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_love_user` ADD `day_refresh_dateline` INT( 11 ) UNSIGNED NOT NULL AFTER `wxdateline` ;
EOF;
	runquery($UpSql);
}

if(!in_array('price_type',$activity_array)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_love_activity` ADD `price_type` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '1' AFTER `banner` ;
EOF;
	runquery($UpSql);
}

if(!in_array('price_1',$activity_array) && !in_array('price_2',$activity_array)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_love_activity` ADD `price_1` DECIMAL( 11, 2 ) UNSIGNED NOT NULL AFTER `price` ,
	ADD `price_2` DECIMAL( 11, 2 ) UNSIGNED NOT NULL AFTER `price_1` ;
EOF;
	runquery($UpSql);
}

if(!in_array('user_audit',$activity_array)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_love_activity` ADD `user_audit` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '1' AFTER `real_verify` ;
EOF;
	runquery($UpSql);
}

if(!in_array('video_type',$user_array) && !in_array('video_url',$user_array)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_love_user` ADD `video_type` TINYINT( 1 ) NOT NULL AFTER `head_portrait` ,
	ADD `video_url` VARCHAR( 255 ) NOT NULL AFTER `video_type` ;
EOF;
	runquery($UpSql);
}

if(!in_array('offline_verify',$user_array)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_love_user` ADD `offline_verify` TINYINT( 1 ) UNSIGNED NOT NULL AFTER `house_verify` ;
EOF;
	runquery($UpSql);
}

if(!in_array('staff_id',$mat_array)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_love_mat` ADD `staff_id` INT( 11 ) UNSIGNED NOT NULL AFTER `uid` ;
	ALTER TABLE `pre_fn_love_mat` ADD INDEX ( `staff_id` ) 
EOF;
	runquery($UpSql);
}

function MysqlToArray($Array) {
    $temp = array();
    foreach ($Array as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}

$finish = TRUE;
?>