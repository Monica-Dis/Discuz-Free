<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
$sql = <<<EOF
	INSERT INTO `pre_fn_ad` (`id`, `plugin`, `classId`, `pic`, `title`, `url`, `startTime`, `endTime`, `display`, `displayorder`, `dateline`) VALUES('', 'fn_xiangqin', 'banner', '/source/plugin/fn_xiangqin/static/images/banner1.jpg', '2', '', 0, 0, 1, 1, 1628332389);
	INSERT INTO `pre_fn_nav` (`id`, `plugin`, `classId`, `icon`, `onIcon`, `title`, `url`, `top`, `displayorder`) VALUES
('', 'fn_xiangqin', 'nav', '/source/plugin/fn_xiangqin/static/images/nav_1.png', '', '红娘推荐', '[siteurl]plugin.php?id=fn_xiangqin&mod=list_hot', 0, 1),
('', 'fn_xiangqin', 'nav', '/source/plugin/fn_xiangqin/static/images/nav_2.png', '', '会员推荐', '[siteurl]plugin.php?id=fn_xiangqin&mod=list_vip', 0, 2),
('', 'fn_xiangqin', 'nav', '/source/plugin/fn_xiangqin/static/images/nav_3.png', '', '实名制专区', '[siteurl]plugin.php?id=fn_xiangqin&mod=list_cert', 0, 3),
('', 'fn_xiangqin', 'nav', '/source/plugin/fn_xiangqin/static/images/nav_4.png', '', '红娘', '[siteurl]plugin.php?id=fn_xiangqin&mod=mat', 0, 4),
('', 'fn_xiangqin', 'navBottom', '/source/plugin/fn_xiangqin/static/images/home.png', '/source/plugin/fn_xiangqin/static/images/homed.png', '首页', '[siteurl]plugin.php?id=fn_xiangqin', 0, 1),
('', 'fn_xiangqin', 'navBottom', '/source/plugin/fn_xiangqin/static/images/activity.png', '/source/plugin/fn_xiangqin/static/images/activityd.png', '活动', '[siteurl]plugin.php?id=fn_xiangqin&mod=activity&form=list', 0, 2),
('', 'fn_xiangqin', 'navBottom', '/source/plugin/fn_xiangqin/static/images/mat.png', '/source/plugin/fn_xiangqin/static/images/matd.png', '红娘', '[siteurl]plugin.php?id=fn_xiangqin&mod=mat&tab=1', 0, 3),
('', 'fn_xiangqin', 'navBottom', '/source/plugin/fn_xiangqin/static/images/user.png', '/source/plugin/fn_xiangqin/static/images/userd.png', '我的', '[siteurl]plugin.php?id=fn_xiangqin&mod=user', 0, 4),
('', 'fn_xiangqin', 'navMiddle', '/source/plugin/fn_xiangqin/static/images/index-nav-pic1.png', '', '我要置顶', 'plugin.php?id=fn_xiangqin&mod=user&top=1', 0, 1),
('', 'fn_xiangqin', 'navMiddle', '/source/plugin/fn_xiangqin/static/images/index-nav-pic2.png', '', '会员推荐', 'plugin.php?id=fn_xiangqin&mod=list_vip', 0, 2),
('', 'fn_xiangqin', 'navMiddle', '/source/plugin/fn_xiangqin/static/images/index-nav-pic3.png', '', '活动专区', 'plugin.php?id=fn_xiangqin&mod=activity&form=list', 0, 3),
('', 'fn_xiangqin', 'navMiddle', '/source/plugin/fn_xiangqin/static/images/index-nav-pic5.png', '', '牵线展示区', 'plugin.php?id=fn_xiangqin&mod=list_pull', 0, 4);
EOF;
runquery($sql);
echo 'ok';
function MysqlToArray($Array) {
    $temp = array();
    foreach ($Array as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}

function runquery($sql) {
	global $_G;
	$tablepre = $_G['config']['db'][1]['tablepre'];
	$dbcharset = $_G['config']['db'][1]['dbcharset'];
	
	$sql = diconv($sql,mb_detect_encoding($sql, array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET);
	$sql = str_replace(array(' cdb_', ' `cdb_', ' pre_', ' `pre_'), array(' {tablepre}', ' `{tablepre}', ' {tablepre}', ' `{tablepre}'), $sql);
	$sql = str_replace("\r", "\n", str_replace(array(' {tablepre}', ' `{tablepre}'), array(' '.$tablepre, ' `'.$tablepre), $sql));

	$ret = array();
	$num = 0;
	foreach(explode(";\n", trim($sql)) as $query) {
		$queries = explode("\n", trim($query));
		foreach($queries as $query) {
			$ret[$num] .= $query[0] == '#' || $query[0].$query[1] == '--' ? '' : $query;
		}
		$num++;
	}
	unset($sql);

	foreach($ret as $query) {
		$query = trim($query);
		if($query) {

			if(substr($query, 0, 12) == 'CREATE TABLE') {
				$name = preg_replace("/CREATE TABLE ([a-z0-9_]+) .*/is", "\\1", $query);
				DB::query(createtable($query, $dbcharset));

			} else {
				DB::query($query);
			}

		}
	}
}

function createtable($sql, $dbcharset) {
	$type = strtoupper(preg_replace("/^\s*CREATE TABLE\s+.+\s+\(.+?\).*(ENGINE|TYPE)\s*=\s*([a-z]+?).*$/isU", "\\2", $sql));
	$type = in_array($type, array('MYISAM', 'HEAP')) ? $type : 'MYISAM';
	return preg_replace("/^\s*(CREATE TABLE\s+.+\s+\(.+?\)).*$/isU", "\\1", $sql).
	(DB::$db->version() > '4.1' ? " ENGINE=$type DEFAULT CHARSET=$dbcharset" : " TYPE=$type");
}
@unlink(DISCUZ_ROOT .'./source/plugin/fn_xiangqin/209update.inc.php');