<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_xiangqin/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_xiangqin/Common.php');
$Operation = in_array($_GET['Operation'], array('Del','State')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&page='.$_GET['page'].'&keyword='.$_GET['keyword'].'&state='.$_GET['state'].'&order='.$_GET['order'];

if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		$OpCpUrl = $MpUrl = $SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		/* ��ѯ���� */
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'R.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'R.id';
		if($_GET['keyword']){
			$Where .= ' and concat(R.username,R.uid,R.content) like(\'%'.addslashes(dhtmlspecialchars(str_replace(array('%','_'),array('',''),$_GET['keyword']))).'%\')';
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ���� */
		$StateSelected = array($_GET['state']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_XiangQin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['StateTitle']}</th><td>
						<select name="state">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="0"{$StateSelected['0']}>{$Fn_XiangQin->Config['LangVar']['ReportStateArray'][0]}</option>
							<option value="1"{$StateSelected['1']}>{$Fn_XiangQin->Config['LangVar']['ReportStateArray'][1]}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_XiangQin->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */

		/* ģ����� */		
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'Module', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_XiangQin->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
			'ID',
			$Fn_XiangQin->Config['LangVar']['ReportPeople'],
			$Fn_XiangQin->Config['LangVar']['CoverReportPeople'],
			$Fn_XiangQin->Config['LangVar']['Content'],
			$Fn_XiangQin->Config['LangVar']['StateTitle'],
			$Fn_XiangQin->Config['LangVar']['TimeTitle'],
			$Fn_XiangQin->Config['LangVar']['HandleTime'],
			$Fn_XiangQin->Config['LangVar']['OperationTitle']
		), 'header tbm');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			showtablerow('', array(), array(
				'<input type="checkbox" class="checkbox" name="ids[]" value="'.$Module['id'].'" />'.$Module['id'],
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
				$Module['report_uid'].'/'.$Module['report_username'].'/'.$Module['report_name'].'&nbsp;<a href="'.$Fn_XiangQin->Config['HeUserUrl'].$Module['report_uid'].'" target="_blank">['.$Fn_XiangQin->Config['LangVar']['See'].']</a>',
				$Module['content'],
				$Module['state'] ? $Fn_XiangQin->Config['LangVar']['ReportStateArray'][$Module['state']] : '<span style="color:red">'.$Fn_XiangQin->Config['LangVar']['ReportStateArray'][$Module['state']].'</span>',
				date('Y-m-d H:i',$Module['dateline']),
				$Module['handle_dateline'] ? date('Y-m-d H:i',$Module['handle_dateline']) : '',
				'&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=State&rid='.$Module['id'].'&value='.(!empty($Module['state']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['state']) ? $Fn_XiangQin->Config['LangVar']['OpReportStateArray'][0] : $Fn_XiangQin->Config['LangVar']['OpReportStateArray'][1]).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&rid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_XiangQin->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','submit','<input name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" type="checkbox"><label for="chkall">'.$Fn_XiangQin->Config['LangVar']['ChkAll'].'</label>&nbsp;&nbsp;<label><input name="optype" value="Del" class="radio" type="radio">'.$Fn_XiangQin->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<label><input name="optype" value="State" class="radio" type="radio">'.$Fn_XiangQin->Config['LangVar']['StateTitle'].'</label>&nbsp;<select name="statenew"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_XiangQin->Config['LangVar']['OpReportStateArray'][1].'</option><option value="0">'.$Fn_XiangQin->Config['LangVar']['OpReportStateArray'][0].'</option></select>','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['ids']) && is_array($_GET['ids'])){
			if($_GET['optype'] == 'Del'){//ȫɾ
				foreach($_GET['ids'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_XiangQin->TableReport,'id ='.$Val);
				}
				cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'State' && in_array($_GET['statenew'],array('0','1'))){
				foreach($_GET['ids'] as $Key => $Val) {
					$Val = intval($Val);
					$UpData['state'] = intval($_GET['statenew']);
					$UpData['handle_dateline'] = time();
					DB::update($Fn_XiangQin->TableReport,$UpData,'id = '.$Val);
				}
				cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else{
				cpmsg($Fn_XiangQin->Config['LangVar']['OpErr'],'','error');
			}
		}else{
			cpmsg($Fn_XiangQin->Config['LangVar']['OpErr'],'','error');
		}
	}
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['rid']){//ɾ��
	$Rid = intval($_GET['rid']);
	DB::delete($Fn_XiangQin->TableReport,'id ='.$Rid);
	cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'State' && $_GET['formhash'] == formhash() && $_GET['rid']){//ɾ��
	$Rid = intval($_GET['rid']);
	$UpData['state'] = intval($_GET['value']);
	$UpData['handle_dateline'] = time();
	DB::update($Fn_XiangQin->TableReport,$UpData,'id = '.$Rid);
	cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}
/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT M.username as report_username,M.name as report_name,R.* FROM '.DB::table($Fn_XiangQin->TableReport).' R LEFT JOIN `'.DB::table($Fn_XiangQin->TableMember).'` M on M.uid=R.report_uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TableReport).' R '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>