<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$temp = in_array($_GET['form'],array('user','info','look','follow','service','gift','cert','certedu','certcar','certhouse','admin','admin_cert_view')) ? $mod.'_'.$_GET['form'] : $mod;

$navtitle = $metakeywords = $metadescription = $setting['lang']['user_title_arr'][($_GET['form'] ? $_GET['form'] : $mod).'_title'];

if(!$_G['uid']){
	Fn_Login();
}else{
	$fn_xiangqin->getWxOpenId();
}

//ͼƬ�ϴ�
if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
	@require_once libfile('class/upload','plugin/fn_assembly');
	$UploadConfig = fn_upload::Config();
}

if($_GET['form'] == 'info'){
	$userInfo = $fn_xiangqin->getUserInfo();
	if(!$userInfo['id'] || ($userInfo['id'] && !$userInfo['per_check'])){
		$perfect = 1;
		$heightData = MobileSelectJs($fn_xiangqin->setting['lang']['weight_arr'],$fn_xiangqin->setting['lang']['occupation_arr'],$fn_xiangqin->setting['lang']['family_arr'],$fn_xiangqin->setting['lang']['nation_arr']);
		$vehicleData = MobileSelectJs($fn_xiangqin->setting['lang']['vehicle_arr'],$fn_xiangqin->setting['lang']['house_arr'],$fn_xiangqin->setting['lang']['smoke_arr'],$fn_xiangqin->setting['lang']['drink_arr']);
		$onlyData = MobileSelectJs($fn_xiangqin->setting['lang']['only_arr'],$fn_xiangqin->setting['lang']['child_arr'],$fn_xiangqin->setting['lang']['want_child_arr'],$fn_xiangqin->setting['lang']['when_marry_arr']);
		$reqHeightData = MobileSelectJs($fn_xiangqin->setting['lang']['age_arr'],$fn_xiangqin->getArrayCombine($fn_xiangqin->setting['lang']['age_arr'],0,$fn_xiangqin->setting['lang']['Unlimited']),$fn_xiangqin->setting['lang']['height_arr'],$fn_xiangqin->getArrayCombine($fn_xiangqin->setting['lang']['height_arr'],0,$fn_xiangqin->setting['lang']['Unlimited']));
		$reqIncomeData = MobileSelectJs($fn_xiangqin->getArrayCombine($fn_xiangqin->setting['lang']['month_income_arr'],99,$fn_xiangqin->setting['lang']['Unlimited']),$fn_xiangqin->getArrayCombine($fn_xiangqin->setting['lang']['education_arr'],99,$fn_xiangqin->setting['lang']['Unlimited']),$fn_xiangqin->getArrayCombine($fn_xiangqin->setting['lang']['marriage_arr'],99,$fn_xiangqin->setting['lang']['Unlimited']));
	}
	
}
include template($plugin_id.':'.$temp);
?>