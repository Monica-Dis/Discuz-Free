<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once libfile('class/json','plugin/fn_assembly');

class fn_xiangqin_api{
	public $common;
	public function __construct() {
		global $fn_xiangqin;
		$this->common = $fn_xiangqin;
		$this->common->_G['cache']['fn_love_gift'] ? '' : $this->common->getCheckGift();
		$this->common->_G['cache']['fn_love_mat'] ? '' : $this->common->getCheckMat();
		$this->common->setting['tabbar'] = $this->getFormReplaceSiteurl($this->common->navList['navBottom']);
		$this->common->setting['tabbarCount'] = count($this->common->navList['navBottom']);
		$this->common->setting['share_url'] = $this->common->getUrl('index');
		$this->mat = C::t('#fn_xiangqin#fn_love_mat')->fetch_by_uid($this->common->_G['uid']);
		$this->common->setting['admin'] = $this->mat ? true : $this->common->setting['admin'];
	}
	
	private function getSetting(){
		return $this->common->setting;
	}

	private function getCheckFormhash($get = array()){
		return $get['formhash'] != FORMHASH ? true : false;
	}

	public function getIndex($get = array()){//��ҳ
		$userInfo = $this->common->getUserInfo();
		if(!$get['srcoll']){
			$res['setting'] = $this->getSetting();
			
			$get['sex'] = $userInfo['sex'] && $this->common->setting['home_sex'] ? ($userInfo['sex'] == 1 ? 2 : 1) : '';
			$res['setting']['lang']['sex_arr'] = array_merge(array('0'=>$res['setting']['lang']['Unlimited']),$res['setting']['lang']['sex_arr']);
			$res['setting']['lang']['real_verify_arr'] = array('0'=>$res['setting']['lang']['Unlimited'],'1'=>$res['setting']['lang']['Yes']);
			$res['setting']['lang']['education_arr'] = array_merge(array('0'=>$res['setting']['lang']['Unlimited']),$res['setting']['lang']['education_arr']);
			$res['setting']['lang']['month_income_arr'] = array_merge(array('0'=>$res['setting']['lang']['Unlimited']),$res['setting']['lang']['month_income_arr']);
			$res['setting']['lang']['marriage_arr'] = array_merge(array('0'=>$res['setting']['lang']['Unlimited']),$res['setting']['lang']['marriage_arr']);
			$res['setting']['lang']['nation_arr'] = array_merge(array('0'=>$res['setting']['lang']['Unlimited']),$res['setting']['lang']['nation_arr']);

			$res['banner'] = $this->common->adList['banner'];
			$res['navBottomAd'] = $this->common->adList['navBottom'];
			$res['nav'] = $this->getFormReplaceSiteurl($this->common->navList['nav']);
			$res['navMiddle'] = $this->getFormReplaceSiteurl($this->common->navList['navMiddle']);
			$res['noticeList'] = $this->common->noticeList;
		}
		$info = C::t('#fn_xiangqin#fn_love_user')->fetch_all_by_list(array('display'=>'1','seal'=>'0','audit_state'=>'1','user_id'=>$get['user_id'],'age_min'=>$get['age_min'],'age_max'=>$get['age_max'],'height_min'=>$get['height_min'],'height_max'=>$get['height_max'],'sex'=>$get['sex'],'index_real_verify'=>$get['real_verify'],'education'=>$get['education'],'month_income'=>$get['month_income'],'marriage'=>$get['marriage'],'nation'=>$get['nation'],'hot'=>!$userInfo['id'] && $this->common->setting['home_hot'] ? 1 : ''),'updateline',$get['page'],10,'',true);
		$res['infoList'] = $this->getFormInfoList($info['list']);
		$res['userInfo'] = $userInfo;
		return $res;
	}

	public function getListHot($get = array()){//�����Ƽ�
		if(!$get['srcoll']){
			$res['setting'] = $this->getSetting();
			$res['userInfo'] = $this->common->getUserInfo();
			$res['setting']['share_url'] = $this->common->getUrl('list_hot');
		}
		$info = C::t('#fn_xiangqin#fn_love_user')->fetch_all_by_list(array('display'=>'1','seal'=>'0','audit_state'=>'1','hot'=>1),'updateline',$get['page'],10,'',true);
		$res['infoList'] = $this->getFormInfoList($info['list']);
		return $res;
	}

	public function getListVip($get = array()){//��Ա�Ƽ�
		if(!$get['srcoll']){
			$res['setting'] = $this->getSetting();
			$res['userInfo'] = $this->common->getUserInfo();
			$res['setting']['share_url'] = $this->common->getUrl('list_vip');
		}
		$info = C::t('#fn_xiangqin#fn_love_user')->fetch_all_by_list(array('display'=>'1','seal'=>'0','audit_state'=>'1','is_vip'=>1),'updateline',$get['page'],10,'',true);
		$res['infoList'] = $this->getFormInfoList($info['list']);
		return $res;
	}

	public function getListCert($get = array()){//ʵ���б�
		if(!$get['srcoll']){
			$res['setting'] = $this->getSetting();
			$res['userInfo'] = $this->common->getUserInfo();
			$res['setting']['share_url'] = $this->common->getUrl('list_cert');
		}
		$info = C::t('#fn_xiangqin#fn_love_user')->fetch_all_by_list(array('display'=>'1','seal'=>'0','audit_state'=>'1','real_verify'=>1),'updateline',$get['page'],10,'',true);
		$res['infoList'] = $this->getFormInfoList($info['list']);
		return $res;
	}

	public function getListOffline($get = array()){//�����б�
		if(!$get['srcoll']){
			$res['setting'] = $this->getSetting();
			$res['userInfo'] = $this->common->getUserInfo();
			$res['setting']['share_url'] = $this->common->getUrl('list_offline');
		}
		$info = C::t('#fn_xiangqin#fn_love_user')->fetch_all_by_list(array('display'=>'1','seal'=>'0','audit_state'=>'1','offline_verify'=>1),'updateline',$get['page'],10,'',true);
		$res['infoList'] = $this->getFormInfoList($info['list']);
		return $res;
	}

	public function getListFarSingle($get = array()){//�ѵ��б�
		if(!$get['srcoll']){
			$res['setting'] = $this->getSetting();
			$res['userInfo'] = $this->common->getUserInfo();
			$res['setting']['share_url'] = $this->common->getUrl('list_far_single');
		}
		$info = C::t('#fn_xiangqin#fn_love_user_far_single')->fetch_all_by_list(array('display'=>'1'),'updateline',$get['page'],10,'',true);
		$res['infoList'] = $this->getFormFarSingleList($info['list']);
		return $res;
	}

	public function getListPull($get = array()){//ǣ���б�
		if(!$get['srcoll']){
			$res['setting'] = $this->getSetting();
			$res['userInfo'] = $this->common->getUserInfo();
			$res['setting']['share_url'] = $this->common->getUrl('list_pull');
		}
		$info = C::t('#fn_xiangqin#fn_love_user_pull_log')->fetch_all_by_list(array('state'=>array('2','4')),'dateline',$get['page'],10,'',true);
		$res['infoList'] = $this->getFormPullList($info['list']);
		return $res;
	}

	public function getView($get = array()){//��Ϣ����ҳ
		$res['setting'] = $this->getSetting();
		$res['hobbyBottomAd'] = $this->common->adList['hobbyBottom'];
		$res['userInfo'] = $this->common->getUserInfo();
		$res['giftList'] = $this->common->_G['cache']['fn_love_gift'];
		$item = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($get['vid']);
		if($item){
			$item['mat'] = $this->common->matList[$item['mat_id']];
			if($item['id'] != $res['userInfo']['id'] && !$res['setting']['admin']){
				$item['errMsg'] = '';
				if($res['userInfo']['seal'] && $res['userInfo']['id']){
					$item['errMsg'] = '&#24744;&#30340;&#30456;&#20146;&#36134;&#25143;&#24050;&#23553;&#65292;&#31105;&#27490;&#35775;&#38382;';
				}else if($item['seal']){
					$item['errMsg'] = '&#35813;&#29992;&#25143;&#30456;&#20146;&#36164;&#26009;&#24050;&#34987;&#23553;&#65292;&#31105;&#27490;&#26597;&#30475;';
				}else if(!$item['display']){
					$item['errMsg'] = '&#35813;&#29992;&#25143;&#30456;&#20146;&#36164;&#26009;&#19981;&#23384;&#22312;';
				}else if($item['audit_state'] == '2' || $item['audit_state'] == '3'){
					$item['errMsg'] = '&#35813;&#29992;&#25143;&#30456;&#20146;&#36164;&#26009;&#23457;&#26680;&#20013;';
				}else if($item['open_love'] == 3){
					$item['errMsg'] = '&#35813;&#29992;&#25143;&#30456;&#20146;&#36164;&#26009;&#20165;&#32418;&#23064;&#26597;&#30475;';
				}/*else if($item['open_love'] == 2 && !$res['userInfo']['vip']){
					$item['errMsg'] = '&#35813;&#29992;&#25143;&#30456;&#20146;&#36164;&#26009;&#20165;&#23545;&#20250;&#21592;&#26597;&#30475;';
				}*/
			}
			if(!$item['errMsg']){
				//������ۼ�
				C::t('#fn_xiangqin#fn_love_user')->update_by_click_count($item['id']);
				if($res['userInfo']['id'] != $item['id'] && $res['userInfo']['id'] && $res['userInfo']['audit_state'] == 1 && $res['userInfo']['display'] && !$res['userInfo']['seal']){//���ʼ�¼
					$lookItem = C::t('#fn_xiangqin#fn_love_look')->fetch_by_vid($res['userInfo']['id'],$item['id']);
					$lookItem ? C::t('#fn_xiangqin#fn_love_look')->update_by_count($lookItem['id']) : C::t('#fn_xiangqin#fn_love_look')->insert(array('vid'=>intval($res['userInfo']['id']),'love_vid'=>intval($item['id']),'dateline'=>time(),'updateline'=>time()),true);
					if(in_array($lookItem['count']+1,array_filter(explode(",",$this->common->setting['look_count_push'])))){
						$lookName = $item['due_time'] > time() ? $res['userInfo']['name'] : cutstr($res['userInfo']['name'],3,'').$this->common->setting['lang']['sex_to_arr'][$res['userInfo']['sex']];
						$this->common->getLookNotice($item['id'],$this->common->getUrl('user',array('form'=>'look','type'=>1)),str_replace(array('[--name--]','[--count--]'),array($lookName,$lookItem['count']+1),$this->common->setting['lang']['lookNoticeMsg']),$lookName);
					}
				}
			}
			$age = date('Y') - date('Y',$item['birth']);
			if($item['age'] != $age){
				C::t('#fn_xiangqin#fn_love_user')->update(array('age'=>$age),$item['id']);
				$item['age'] = $age;
			}

			$item['follow'] = C::t('#fn_xiangqin#fn_love_follow')->fetch_by_vid($res['userInfo']['id'],$item['id']); //��ע
			$item['contact'] = $res['setting']['admin'] ? true : C::t('#fn_xiangqin#fn_love_user_contact_log')->fetch_by_vid($res['userInfo']['id'],$item['id']);//��ϵ��ʽ
			if(!$item['contact']){$item['phone'] = $item['wx'] = '';}
			$item['video_html'] = GetVideoHtml($item['video_url'],$item['video_pic']); //��ע
			
			$item = $this->common->getFormUser($item);

			$giftLog = $this->getViewGiftList(array('love_vid'=>$item['id']));
			$item['giftList'] = $giftLog['giftList'];
			$item['giftCount'] = array_sum(array_map(function($val){return $val['counts'];},$item['giftList']));
	
			//��������
			$res['setting']['share_title'] = $item['share_title'];;
			$res['setting']['share_desc'] = $item['share_desc'];;
			$res['setting']['share_logo'] = $item['head_portrait'];
			$res['setting']['share_url'] = $item['url'];
		}
		$res['item'] = $item;
		return $res;
	}

	public function getViewAdminOp($get = array()){//������Ϣ

		$get = EncodeURIToUrldeCode($get);
		$item = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($get['vid']);
		if(!$this->common->setting['admin']){
			$res['msg'] = '&#26080;&#26435;&#25805;&#20316;';
			return $res;
		}
		if($get['op'] == 'del'){
			C::t('#fn_xiangqin#fn_love_user')->delete_by_id($get['vid']);
			$res['state'] = 200;
			$res['msg'] = $this->common->setting['lang']['DelOk'];
		}else if($get['op'] == 'edit'){
			$data = $get['field'] == 'audit_state' && $get['value'] == 3 ? array($get['field']=>addslashes(strip_tags($get['value'])),'refuse_tips'=>addslashes(strip_tags($get['content']))) : array($get['field']=>addslashes(strip_tags($get['value'])));
			C::t('#fn_xiangqin#fn_love_user')->update($data,$get['vid']);
			$res['state'] = 200;
			$res['msg'] = $this->common->setting['lang']['UpdateOk'];
			if($get['field'] == 'audit_state'){
				$this->common->getAuditNotice($item['id'],$get['value'],$this->common->getUrl('user'),str_replace(array('[--audit_state--]'),array($this->common->setting['lang']['audit_state_arr'][$get['value']]),$this->common->setting['lang']['userNoticeMsg']));
			}else if($get['field'] == 'seal' && $get['value']){
				$this->common->getSealNotice($item['id'],$this->common->getUrl('user'),$this->common->setting['lang']['sealNoticeMsg']);
			}
		}
		return $res;
	}

	public function getFollowListAdmin($get = array()){//������¼
		if(!$this->common->setting['admin']){
			$res['msg'] = '&#26080;&#26435;&#25805;&#20316;';
			return $res;
		}
		$log = C::t('#fn_xiangqin#fn_love_user_follow_log')->fetch_all_by_list(array('vid'=>$get['vid']),'dateline',0,1000,true);
		$res['list'] = $this->getFormfollowLogList($log['list']);
		$res['state'] = 200;
		return $res;
	}	

	public function getFollowAdmin($get = array()){//д����

		$get = EncodeURIToUrldeCode($get);
		$item = C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($get['vid']);
		if(!$this->common->setting['admin']){
			$res['msg'] = '&#26080;&#26435;&#25805;&#20316;';
			return $res;
		}
		$data['mat_id'] = $this->mat['id'];
		$data['vid'] = $item['id'];
		$data['content'] = addslashes(strip_tags($get['content']));
		$data['follow_dateline'] = time();
		$data['dateline'] = time();
		$id = C::t('#fn_xiangqin#fn_love_user_follow_log')->insert($data);
		if($id){
			$res['state'] = 200;
			$res['msg'] = '&#20445;&#23384;&#25104;&#21151;';
		}else{
			$res['msg'] = '&#20445;&#23384;&#22833;&#36133;';
		}
		return $res;
	}


	public function getViewGiftList($get = array()){//�����б�
		$giftLog = C::t('#fn_xiangqin#fn_love_gift_log')->fetch_all_by_list(array('love_vid'=>$get['love_vid']),'dateline',0,100,'','gift_id');
		$res['giftList'] = $giftLog['list'];
		$res['giftCount'] = array_sum(array_map(function($val){return $val['counts'];},$res['giftList']));
		return $res;
	}

	public function getViewFollow($get = array()){//��ע
		$userInfo = $this->common->getUserInfo();
		if(!$userInfo['id']){
			$res['state'] = 202;
			$res['msg'] = '&#24744;&#36824;&#27809;&#26377;&#22635;&#20889;&#36164;&#26009;';
			return $res;
		}else if($userInfo['id'] == $get['vid']){
			$res['msg'] = '&#33258;&#24049;&#19981;&#33021;&#20851;&#27880;&#33258;&#24049;&#21734;';
			return $res;
		}

		$followItem = C::t('#fn_xiangqin#fn_love_follow')->fetch_by_vid($userInfo['id'],$get['vid']);
		if($followItem){
			C::t('#fn_xiangqin#fn_love_follow')->delete_by_id($followItem['id']);
			$res['state'] = 201;
			$res['msg'] = '&#21462;&#28040;&#20851;&#27880;';
		}else{
			C::t('#fn_xiangqin#fn_love_follow')->insert(array('vid'=>intval($userInfo['id']),'love_vid'=>intval($get['vid']),'dateline'=>time()),true);
			$res['state'] = 200;
			$res['msg'] = '&#20851;&#27880;&#25104;&#21151;';
		}
		return $res;
	}

	public function getGiftGive($get = array()){//������
		$userInfo = $this->common->getUserInfo();
		if(!$userInfo['id']){
			$res['state'] = 202;
			$res['msg'] = '&#24744;&#36824;&#27809;&#26377;&#22635;&#20889;&#36164;&#26009;';
			return $res;
		}else if($userInfo['id'] == $get['vid']){
			$res['msg'] = '&#33258;&#24049;&#19981;&#33021;&#32473;&#33258;&#24049;&#36865;&#31036;&#29289;&#21734;';
			return $res;
		}

		$giftItem = C::t('#fn_xiangqin#fn_love_gift')->fetch_by_id($get['gift_id']);
		$currency = $giftItem['money'] * $get['count'];
		if(!$giftItem){
			$res['msg'] = '&#31036;&#29289;&#19981;&#23384;&#22312;';
			return $res;
		}else if($userInfo['currency'] < $currency){
			$res['state'] = 201;
			$res['msg'] = ($userInfo['sex'] == 1 ? '&#24069;&#21733;&#65292;' : '&#32654;&#22899;&#65292;').'&#24744;&#30340;&#37329;&#24065;&#19981;&#36275;&#21734;';
			return $res;
		}

		$giftlogId = C::t('#fn_xiangqin#fn_love_gift_log')->insert(array(
			'gift_id'=>intval($giftItem['id']),
			'uid'=>intval($this->common->_G['uid']),
			'vid'=>intval($userInfo['id']),
			'love_vid'=>intval($get['vid']),
			'count'=>intval($get['count']),
			'currency'=>intval($currency),
			'dateline'=>time()
		));

		if($giftlogId){
			$member = $this->common->getView($get['vid']);
			C::t('#fn_xiangqin#fn_love_user')->update_by_count($userInfo['id'],'currency',$currency,'-');
			C::t('#fn_xiangqin#fn_love_con_log')->insert(array('uid'=>intval($this->common->_G['uid']),'vid'=>intval($userInfo['id']),'love_vid'=>intval($get['vid']),'currency'=>intval($currency),'event_type'=>1,'content'=>str_replace(array('[--name--]','[--count--]','[--title--]'),array($member['name'],$currency,$giftItem['title']),$this->common->setting['lang']['con_log_content']['gift']),'dateline'=>time()));
			$res['state'] = 200;
			$res['msg'] = '&#36192;&#36865;&#25104;&#21151;<br>'.($userInfo['sex'] == 1 ? '&#24069;&#21733;&#65292;' : '&#32654;&#22899;&#65292;').'&#35874;&#35874;&#24744;&#36865;&#30340;&#31036;&#29289;&#21734;';
		}
		return $res;
	}
	
	public function getContact($get = array()){//�鿴��ϵ��ʽ
		$userInfo = $this->common->getUserInfo();
		if(!$userInfo['id']){
			$res['state'] = 202;
			$res['msg'] = '&#24744;&#36824;&#27809;&#26377;&#22635;&#20889;&#36164;&#26009;';
			return $res;
		}else if($userInfo['id'] == $get['vid']){
			$res['msg'] = '&#19981;&#33021;&#26597;&#30475;&#33258;&#24049;&#30340;&#32852;&#31995;&#26041;&#24335;&#21734;';
			return $res;
		}else if($userInfo['audit_state'] == 3){
			$res['msg'] = '&#24744;&#30340;&#36164;&#26009;&#26410;&#36890;&#36807;&#23457;&#26680;&#65292;&#19981;&#33021;&#26597;&#30475;&#32852;&#31995;&#26041;&#24335;';
			return $res;
		}
			
		$member = $this->common->getView($get['vid']);
		if($this->common->setting['viewContact']){
			$res['state'] = 204;
			$res['msg'] = $this->common->setting['viewContactTips'];
			return $res;
		}else if($member['open_contact'] == 2 && !$userInfo['vip']){
			$res['msg'] = '&#35813;&#29992;&#25143;&#32852;&#31995;&#26041;&#24335;&#20165;&#23545;&#20250;&#21592;&#26597;&#30475;';
			return $res;
		}else if($member['open_contact'] == 3){
			$res['msg'] = '&#35813;&#29992;&#25143;&#32852;&#31995;&#26041;&#24335;&#19981;&#23545;&#22806;&#20844;&#24320;&#65292;&#35831;&#32852;&#31995;&#32418;&#23064;&#29301;&#32447;';
			return $res;
		}else if(!$userInfo['real_verify'] && $this->common->setting['contact_cert']){
			$res['state'] = 203;
			$res['msg'] = '&#24744;&#27809;&#26377;&#23454;&#21517;&#35748;&#35777;&#65292;&#19981;&#33021;&#26597;&#30475;&#32852;&#31995;&#26041;&#24335;';
			return $res;
		}
		
		if($this->common->setting['contact_limit'] && !$this->common->setting['viewContact'] && C::t('#fn_xiangqin#fn_love_user_contact_log')->fetch_by_vid_day($userInfo['id']) >= $this->common->setting['contact_limit']){
			$res['msg'] = '&#27599;&#22825;&#21482;&#33021;&#38480;&#21046;&#26597;&#30475;'.$this->common->setting['contact_limit'].'&#20010;&#32852;&#31995;&#26041;&#24335;&#21734;';
			return $res;
		}

		$contactLog = C::t('#fn_xiangqin#fn_love_user_contact_log')->fetch_by_vid($userInfo['id'],$get['vid']);
		if($contactLog){
			$res['msg'] = '&#24744;&#24050;&#32463;&#26597;&#30475;&#36807;&#84;&#65;&#30340;&#32852;&#31995;&#26041;&#24335;&#20102;&#21734;';
			return $res;
		}

		$imkey = intval($this->common->setting['imkey']);
		if($userInfo['imkey'] < intval($imkey)){
			$res['state'] = 201;
			$res['msg'] = ($userInfo['sex'] == 1 ? '&#24069;&#21733;&#65292;' : '&#32654;&#22899;&#65292;').'&#24744;&#30340;&#38053;&#21273;&#19981;&#22815;&#20102;&#21734;';
			return $res;
		}

		$contactLogId = C::t('#fn_xiangqin#fn_love_user_contact_log')->insert(array(
			'uid'=>intval($this->common->_G['uid']),
			'vid'=>intval($userInfo['id']),
			'love_vid'=>intval($get['vid']),
			'imkey'=>$imkey,
			'dateline'=>time(),
			'updateline'=>time()
		));

		if($contactLogId){
			C::t('#fn_xiangqin#fn_love_user')->update_by_count($userInfo['id'],'imkey',$imkey,'-');
			C::t('#fn_xiangqin#fn_love_con_log')->insert(array('uid'=>intval($this->common->_G['uid']),'vid'=>intval($userInfo['id']),'love_vid'=>intval($get['vid']),'imkey'=>intval($imkey),'event_type'=>2,'content'=>str_replace(array('[--name--]','[--count--]'),array($member['name'],$imkey),$this->common->setting['lang']['con_log_content']['contact']),'dateline'=>time()));
			$res['state'] = 200;
			$res['phone'] = $member['phone'];
			$res['wx'] = $member['wx'];
			$res['msg'] = '&#26597;&#30475;&#25104;&#21151;<br>'.($userInfo['sex'] == 1 ? '&#24069;&#21733;&#65292;' : '&#32654;&#22899;&#65292;').'&#35874;&#35874;&#24744;&#23545;&#25105;&#24863;&#20852;&#36259;&#21734;';
		}
		return $res;
	}

	public function getReportPost($get = array()){//�ٱ�

		if($this->getCheckFormhash($get)){
			$res['msg'] = $this->common->setting['lang']['OpErr'];
			return $res;
		}
		
		$userInfo = $this->common->getUserInfo();
		if(!$userInfo['id']){
			$res['msg'] = '&#24744;&#36824;&#27809;&#26377;&#22635;&#20889;&#36164;&#26009;';
			return $res;
		}else if($userInfo['id'] == $get['vid']){
			$res['msg'] = '&#35831;&#21247;&#20030;&#25253;&#33258;&#24049;';
			return $res;
		}

		$reportLog = C::t('#fn_xiangqin#fn_love_user_report')->fetch_by_vid($userInfo['id'],$get['vid']);
		if($reportLog){
			$res['msg'] = '&#24744;&#24050;&#32463;&#20030;&#25253;&#36807;&#20102;&#65292;&#35831;&#21247;&#37325;&#22797;&#20030;&#25253;&#65281;';
			return $res;
		}
		
		$get = EncodeURIToUrldeCode($get);
		$data['uid'] = intval($this->common->_G['uid']);
		$data['vid'] = intval($userInfo['id']);
		$data['love_vid'] = intval($get['vid']);
		$data['type'] = intval($get['type']);
		$data['content'] = addslashes(strip_tags($get['content']));
		$data['dateline'] = time();
		foreach(array_filter(explode(';',$get['new_evidence'][0])) as $key => $val) {
			$get['new_evidence'][$key] = strpos($val,'http') !== false ? $val : $this->common->_G['siteurl'].$val;
		}
		$data['evidence'] = is_array($get['new_evidence']) && isset($get['new_evidence']) ? implode(',',$get['new_evidence']) : '';

		if(!$data['type']){
			$res['msg'] = '&#35831;&#36873;&#25321;&#20030;&#25253;&#21407;&#22240;';
			return $res;
		}
		if(!$data['content']){
			$res['msg'] = '&#35831;&#22635;&#20889;&#24744;&#30340;&#20030;&#25253;&#29702;&#30001;';
			return $res;
		}
		$reportId = C::t('#fn_xiangqin#fn_love_user_report')->insert($data,true);
		if($reportId){
			$res['state'] = 200;
			$res['msg'] = '&#20030;&#25253;&#25104;&#21151;';
		}else{
			$res['msg'] = '&#20030;&#25253;&#22833;&#36133;';
		}
		return $res;
	}
	
	public function getMat($get = array()){//����
		$res['setting'] = $this->getSetting();
		$res['userInfo'] = $this->common->getUserInfo();
		$matList = $this->common->matList;
		$res['matList'] = $matList[$res['userInfo']['mat_id']] ? array($matList[$res['userInfo']['mat_id']]) : $matList;
		return $res;
	}
	

	public function getPayment($get = array()){//�ײ�
		$res['setting'] = $this->getSetting();
		$res['userInfo'] = $this->common->getUserInfo();
		$res['mealList'] = C::t('#fn_xiangqin#fn_love_meal')->fetch_all_by_list(array('display'=>1));
		return $res;
	}

	public function getPaymentPay($get = array()){//�����ײ�
		$item = C::t('#fn_xiangqin#fn_love_meal')->fetch_by_id($get['mid']);
		$userInfo = $this->common->getUserInfo();
		if(!$item || !$userInfo['id']){
			$res['msg'] = $this->common->setting['lang']['OpErr'];
			return $res;
		}

		if(C::t('#fn_xiangqin#fn_love_meal_log')->first_by_vid_count($userInfo['id'],$item['id']) >= $item['limit']){
			$res['msg'] = str_replace(array('{limit}'),array($item['limit']),$this->common->setting['lang']['setmealLimitErr']);
			return $res;
		}
		
		if($item['type'] == 1){
			$groupData['group_id'] = $item['id'];
			$groupData['currency'] = $userInfo['currency'] + $item['currency'];
			$groupData['imkey'] = $userInfo['imkey'] + $item['imkey'];
			$groupData['act'] = $item['act'];
			$groupData['pull'] = $item['pull'];
			$groupData['due_time'] = $userInfo['vip'] && $userInfo['group_id'] == $item['id'] ? strtotime("+".intval($item['day'])." day",$userInfo['due_strtotime']) : strtotime("+".intval($item['day'])."  day",time());
			$event = 'buy_setmeal_vip';
		}else if($item['type'] == 2){
			$groupData['currency'] = $userInfo['currency'] + $item['currency'];
			$event = 'buy_setmeal_currency';
		}else if($item['type'] == 3){
			$groupData['imkey'] = $userInfo['imkey'] + $item['imkey'];
			$event = 'buy_setmeal_imkey';
		}
		$groupPayData = array('uid'=>$userInfo['uid'],'vid'=>$userInfo['id'],'group_id'=>$item['id'],'dateline'=>time());
		if($item['money']){//���ѿ�ͨ
			$payLog = $this->GetAjaxPayLog(array('money'=>$item['money'],'event'=>$event,'group_id'=>$item['id'],'user_id'=>$userInfo['id'],'group_data'=>$groupData,'group_pay_data'=>$groupPayData));
			$res['payid'] = $payLog['Id'];
			$res['state'] = 201;
			$res['money'] = $item['money'];
			$res['paytitle'] = str_replace(array('{group_id}','{title}'),array($item['id'],$item['title']), $this->common->setting['lang']['setmealPayTitle']);
		}else{//��ѿ�ͨ
			
		}
		$res['msg'] = $this->common->setting['lang']['setmealInfoPaySuccess'];
		return $res;
	}
	
	public function getPoster($get = array()){//����
		global $Config;
		$res['setting'] = $this->getSetting();
		$res['userInfo'] = $this->common->getUserInfo();
		$res['item'] = $this->common->getView($get['vid']);
		//��ά��
		if($this->common->setting['QrParameterSwitch']){
			$file = $Config['QrcodePath'].reset(array_filter(explode(":",$get['id']))).'_view_'.$res['item']['id'].'.jpg';
			if(!file_exists($file) || !filesize($file) || (filesize($file) && file_exists($file) && filemtime($file) + 1296000 <= time())) {
				@unlink($file);
				@require_once libfile('class/wechat','plugin/fn_assembly');
				$wechatClient = new Fn_WeChatClient($this->common->setting['WxAppid'], $this->common->setting['WxSecret']);
				$qrUrl = $wechatClient->getQrcodeImgUrlByTicket($wechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$get['id']))).'____view____'.intval($res['item']['id']),'expire'=>2592000)));
				DownloadImg($qrUrl,$file);
			}
			$res['item']['qrcode'] = base64_encode(file_get_contents($file));
		}else{
			$file = $Config['QrcodePath'].reset(array_filter(explode(":",$get['id']))).'.jpg';
			if(!file_exists($file) || !filesize($file)) {
				@require_once libfile('class/qrcode','plugin/fn_assembly');
				QRcode::png($res['item']['url'], $file, QR_ECLEVEL_L,5,2);
			}
			$res['item']['qrcode'] = base64_encode(file_get_contents($file));
			@unlink($file);
		}
		return $res;
	}
	
	public function getActivityList($get = array()){//��б�
		if(!$get['srcoll']){
			$res['setting'] = $this->getSetting();
			$res['userInfo'] = $this->common->getUserInfo();
		}
		$info = C::t('#fn_xiangqin#fn_love_activity')->fetch_all_by_list(array('display'=>'1'),'updateline',$get['page'],10);
		$res['infoList'] = $this->getFormActivityList($info['list']);
		return $res;
	}

	public function getActivityView($get = array()){//�����
		$res['setting'] = $this->getSetting();
		$res['userInfo'] = $this->common->getUserInfo();
		$item = C::t('#fn_xiangqin#fn_love_activity')->fetch_by_id($get['aid']);
		if($item){
			//������ۼ�
			C::t('#fn_xiangqin#fn_love_activity')->update_by_click_count($item['id']);
			$item = $this->common->getFormActivity($item);
			$signup = C::t('#fn_xiangqin#fn_love_activity_signup')->fetch_all_by_list(array('aid'=>$item['id'],'audit_state'=>1),'dateline',0,6,true);
			$item['signupList'] = $signup['list'];
			$item['signupCount'] = $signup['count'];
			$res['item'] = $item;
			$res['setting']['share_title'] = $item['share_title'];;
			$res['setting']['share_desc'] = $item['share_desc'];;
			$res['setting']['share_logo'] = $item['share_logo'];
			$res['setting']['share_url'] = $item['share_url'];
		}
		return $res;
	}

	public function getActivitySignup($get = array()){//����
		
		$userInfo = $this->common->getUserInfo();
		$item = C::t('#fn_xiangqin#fn_love_activity')->fetch_by_id($get['aid']);
		if(time() > $item['signup_end_dateline']){
			$res['msg'] = '&#25253;&#21517;&#24050;&#32467;&#26463;';
			return $res;
		}else if(time() > $item['end_dateline']){
			$res['msg'] = '&#27963;&#21160;&#24050;&#32467;&#26463;';
			return $res;
		}else if(!$userInfo['id']){
			$res['state'] = 202;
			$res['msg'] = '&#24744;&#36824;&#27809;&#26377;&#22635;&#20889;&#36164;&#26009;';
			return $res;
		}else if(!$item['display']){
			$res['msg'] = '&#27963;&#21160;&#19981;&#23384;&#22312;';
			return $res;
		}else if($userInfo['audit_state'] == 2 && $item['user_audit']){
			$res['msg'] = '&#24744;&#30340;&#36164;&#26009;&#23457;&#26680;&#20013;&#65292;&#19981;&#33021;&#21442;&#21152;&#27963;&#21160;';
			return $res;
		}else if($userInfo['audit_state'] == 3 && $item['user_audit']){
			$res['msg'] = '&#24744;&#30340;&#36164;&#26009;&#23457;&#26680;&#25298;&#32477;&#20102;&#65292;&#19981;&#33021;&#21442;&#21152;&#27963;&#21160;';
			return $res;
		}else if($userInfo['seal'] == 1){
			$res['msg'] = '&#24744;&#30340;&#36164;&#26009;&#34987;&#23553;&#20102;&#65292;&#19981;&#33021;&#21442;&#21152;&#27963;&#21160;';
			return $res;
		}else if($item['real_verify'] && !$userInfo['real_verify']){
			$res['state'] = 203;
			$res['msg'] = '&#26412;&#27425;&#27963;&#21160;&#24517;&#39035;&#23454;&#21517;&#35748;&#35777;&#25165;&#33021;&#21442;&#21152;';
			return $res;
		}else if($item['female_number'] && $userInfo['sex'] == 2 && C::t('#fn_xiangqin#fn_love_activity_signup')->first_by_count(' where s.sex = 2 and s.aid= '.$item['id'].' and audit_state = 1') >= $item['female_number']){
			$res['msg'] = '&#22899;&#29983;&#25253;&#21517;&#20154;&#25968;&#22815;&#21862;&#65292;&#24744;&#19981;&#33021;&#21442;&#21152;&#27963;&#21160;&#20102;&#21734;';
			return $res;
		}else if($item['male_number'] && $userInfo['sex'] == 1 && C::t('#fn_xiangqin#fn_love_activity_signup')->first_by_count(' where s.sex = 1 and s.aid= '.$item['id'].' and audit_state = 1') >= $item['male_number']){
			$res['msg'] = '&#30007;&#29983;&#25253;&#21517;&#20154;&#25968;&#22815;&#21862;&#65292;&#24744;&#19981;&#33021;&#21442;&#21152;&#27963;&#21160;&#20102;&#21734;';
			return $res;
		}
		
		if(C::t('#fn_xiangqin#fn_love_activity_signup')->fetch_by_vid($userInfo['id'],$item['id'])){
			$res['msg'] = '&#35831;&#21247;&#37325;&#22797;&#21442;&#21152;&#25253;&#21517;';
			return $res;
		}

		$insert['uid'] = intval($this->common->_G['uid']);
		$insert['vid'] = intval($userInfo['id']);
		$insert['aid'] = intval($get['aid']);
		$insert['sex'] = intval($userInfo['sex']);
		$insert['dateline'] = time();

		if($item['price_type'] == 1){
			$money = $userInfo['vip'] ? $item['vip_price'] : $item['price'];
		}else if($item['price_type'] == 2){
			$money = $userInfo['sex'] == 1 ? $item['price_1'] : $item['price_2'];
		}
		if($userInfo['vip'] && $item['vip_act'] && $userInfo['act'] && $money > 0){
			C::t('#fn_xiangqin#fn_love_user')->update_by_count($userInfo['id'],'act',1,'-');
			C::t('#fn_xiangqin#fn_love_con_log')->insert(array('uid'=>intval($this->common->_G['uid']),'vid'=>intval($userInfo['id']),'love_vid'=>intval($userInfo['id']),'act'=>1,'event_type'=>4,'content'=>str_replace(array('[--name--]'),array($userInfo['name']),$this->common->setting['lang']['con_log_content']['activity_signup']),'dateline'=>time()));
			C::t('#fn_xiangqin#fn_love_activity_signup')->insert($insert);
			$res['state'] = 200;
		}else if($money > 0){
			$payLog = $this->GetAjaxPayLog(array('money'=>$money,'event'=>'activity_signup','insert_data'=>$insert));
			$res['payid'] = $payLog['Id'];
			$res['state'] = 201;
			$res['money'] = $money;
			$res['paytitle'] = $this->common->setting['lang']['activitySignupPayTitle'];
		}else{
			C::t('#fn_xiangqin#fn_love_activity_signup')->insert($insert);
			$res['state'] = 200;
		}
		$res['msg'] = '&#24685;&#21916;&#24744;&#65292;&#25253;&#21517;&#25104;&#21151;';
		return $res;
	}
	
	public function getUserAdminList($get = array()){//�����û�
		$userInfo = $this->common->getUserInfo();
		if(!$get['srcoll']){
			$res['setting'] = $this->getSetting();
			$res['userInfo'] = $userInfo;
		}
		list($field,$value) = explode('|', $get['type']);
		$info = $this->common->setting['admin'] ? C::t('#fn_xiangqin#fn_love_user')->fetch_all_by_list(array('display'=>'1',$field=>$value),'updateline',$get['page'],20) : '';
		$res['list'] = $this->getFormInfoList($info['list']);
		return $res;
	}

	public function getUser($get = array()){//��Ա����
		$res['setting'] = $this->getSetting();
		$res['userInfo'] = $this->common->getUserInfo();
		$res['userInfo']['look_count'] = C::t('#fn_xiangqin#fn_love_look')->first_by_love_vid_count($res['userInfo']['id']);
		$res['userInfo']['follow_count'] = C::t('#fn_xiangqin#fn_love_follow')->first_by_love_vid_count($res['userInfo']['id']);
		$res['userInfo']['my_follow_count'] = C::t('#fn_xiangqin#fn_love_follow')->first_by_vid_count($res['userInfo']['id']);
		return $res;
	}

	public function getUserInfoData($get = array()){//�༭����
		$res['setting'] = $this->getSetting();
		$res['userInfo'] = $this->common->getUserInfo();
		if($res['userInfo']['id']){
			$res['userInfo']['head_portrait'] = array_filter(explode(",",$res['userInfo']['head_portrait']));
			$res['userInfo']['album'] = array_filter(explode(",",$res['userInfo']['album']));
			$res['userInfo']['birth'] = $res['userInfo']['birth'] ? date('Y-m-d',$res['userInfo']['birth']) : '';
			$res['userInfo']['hobby'] = array_filter(explode(",",$res['userInfo']['hobby']));
			$res['userInfo']['hobby_arr'] = dunserialize($res['userInfo']['hobby_arr']);

		}else{
			foreach(DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_love_user')) as $k => $s) {
				$res['userInfo'][$s['Field']] = '';
			}
			$res['userInfo']['hobby'] = array();
			$res['userInfo']['birth'] = '';
		}
		return $res;
	}

	public function getUserInfoPost($get = array()){//��������

		$res = array();
		$get = EncodeURIToUrldeCode($get);
		if($this->getCheckFormhash($get)){
			$res['msg'] = $this->common->setting['lang']['OpErr'];
			return $res;
		}

		$userInfo = $this->common->getUserInfo();
		$data['per_check'] = $userInfo['per_check'] ? $userInfo['per_check'] : $get['per_check'];
		$data['uid'] = $userInfo['uid'] ? $userInfo['uid'] : intval($this->common->_G['uid']);
		$data['username'] = $userInfo['uid'] ? $userInfo['username'] : addslashes(strip_tags($this->common->_G['username']));
		$data['name'] = addslashes(strip_tags($get['name']));
		$data['phone'] = addslashes(strip_tags($get['phone']));
		$data['wx'] = addslashes(strip_tags($get['wx']));
		$data['graduate_school'] = addslashes(strip_tags($get['graduate_school']));
		$data['major'] = addslashes(strip_tags($get['major']));
		$data['company'] = addslashes(strip_tags($get['company']));
		$data['position'] = addslashes(strip_tags($get['position']));
		$data['birth'] = $get['birth'] ? strtotime($get['birth']) : '';
		$data['introduce'] = addslashes(strip_tags($get['introduce']));
		//����-��Ф
		$birthext = $this->common->birthext($data['birth']);
		$data['constellation'] = intval($birthext['constellation']);
		$data['animal'] = intval($birthext['animal']);
		$data['age'] = date('Y') - date('Y',$data['birth']);
		$data['sex'] = intval($get['sex']);
		$data['weight'] = intval($get['weight']);
		$data['height'] = intval($get['height']);
		$data['education'] = intval($get['education']);
		$data['marriage'] = intval($get['marriage']);
		$data['nation'] = intval($get['nation']);
		$data['family'] = intval($get['family']);
		$data['month_income'] = intval($get['month_income']);
		$data['only'] = $get['only'] == 1 ? intval($get['only']) : 0;
		$data['child'] = intval($get['child']);
		$data['want_child'] = intval($get['want_child']);
		$data['occupation'] = intval($get['occupation']);
		$data['vehicle'] = intval($get['vehicle']);
		$data['house'] = intval($get['house']);
		$data['when_marry'] = intval($get['when_marry']);
		$data['shape'] = intval($get['shape']);
		$data['smoke'] = intval($get['smoke']);
		$data['drink'] = intval($get['drink']);
		$data['religion'] = intval($get['religion']);
		$data['hobby'] = implode(',',array_filter(explode(';',$get['hobby'][0])));
		$hobby_arr = array();
		foreach(array_filter(explode(';',$get['hobby'][0])) as $k => $v) {
			$hobby_arr[$k] = $this->common->setting['lang']['hobby_arr'][$v];
		}
		$data['hobby_arr'] = $hobby_arr ? serialize($hobby_arr) : '';
		$data['company_nature'] = intval($get['company_nature']);
		$data['req_age_min'] = intval($get['req_age_min']);
		$data['req_age_max'] = intval($get['req_age_max']);
		$data['req_height_min'] = intval($get['req_height_min']);
		$data['req_height_max'] = intval($get['req_height_max']);
		$data['req_month_income'] = intval($get['req_month_income']);
		$data['req_education'] = intval($get['req_education']);
		$data['req_nation'] = intval($get['req_nation']);
		$data['req_house'] = $get['req_house'] == 1 ? intval($get['req_house']) : 0;
		$data['req_vehicle'] = $get['req_vehicle'] == 1 ? intval($get['req_vehicle']) : 0;
		$data['req_marriage'] = intval($get['req_marriage']);
		$data['req_want_child'] = intval($get['req_want_child']);
		$data['req_smoke'] = intval($get['req_smoke']);
		$data['req_drink'] = intval($get['req_drink']);
		$data['req_accept_child'] = intval($get['req_accept_child']);
		$data['open_contact'] = $get['open_contact'] ? intval($get['open_contact']) : 1;
		$data['open_love'] = $get['open_love'] ? intval($get['open_love']) : 1;
		foreach(array_filter(explode(';',$get['new_album'][0])) as $key => $val) {
			$get['new_album'][$key] = strpos($val,'http') !== false ? $val : $this->common->_G['siteurl'].$val;
		}
		$data['album'] = is_array($get['new_album']) && isset($get['new_album']) ? implode(',',$get['new_album']) : '';

		foreach(array_filter(explode(';',$get['new_head_portrait'][0])) as $key => $val) {
			$get['new_head_portrait'][$key] = strpos($val,'http') !== false ? $val : $this->common->_G['siteurl'].$val;
		}
		$data['head_portrait'] = is_array($get['new_head_portrait']) && isset($get['new_head_portrait']) ? implode(',',$get['new_head_portrait']) : '';
		
		if(!$data['head_portrait']){
			$res['msg'] = $this->common->setting['lang']['head_portrait_tips'];
			return $res;
		}

		if(!$data['name']){
			$res['msg'] = $this->common->setting['lang']['name_tips'];
			return $res;
		}
		
		//�ֻ������ж�
		$mobileMatch = "/".$this->common->setting['common_setting']['MobileMatch']."/";
		if(!$data['phone']){
			$res['msg'] = $this->common->setting['lang']['phone_tips'];
			return $res;
		}else if(!preg_match($mobileMatch,$data['phone'])){
			$res['msg'] = '&#25163;&#26426;&#21495;&#30721;&#26684;&#24335;&#19981;&#27491;&#30830;';
			return $res;
		}
		if(!$userInfo['id'] && $checkPhone = C::t('#fn_xiangqin#fn_love_user')->fetch_by_phone_nouid($data['phone'],$this->common->_G['uid'])){//�����Ƿ����
			$res['msg'] = '&#25163;&#26426;&#21495;&#30721;&#24050;&#23384;&#22312;&#65292;&#35831;&#26356;&#25442;&#25163;&#26426;&#21495;&#30721;';
			return $res;
		}
		//�ֻ������ж� END
		//��֤���ж�
		if(!$userInfo['id']){
			if(!$get['code']){
				$res['msg'] = '&#35831;&#36755;&#20837;&#25163;&#26426;&#39564;&#35777;&#30721;';
				return $res;
			}
			$checkCode = C::t('#fn_assembly#fn_send_sms_log')->fetch_by_check_code($data['phone'],$this->common->_G['uid'],$get['code']);
			if(!$checkCode){
				$res['msg'] = '&#39564;&#35777;&#30721;&#19981;&#27491;&#30830;&#65292;&#35831;&#37325;&#26032;&#36755;&#20837;';
				return $res;
			}else{
				$data['phone_verify'] = 1;
			}
		}
		//��֤���ж� End
		if(!$data['sex']){
			$res['msg'] = $this->common->setting['lang']['sex_tips'];
			return $res;
		}
		if($data['per_check']){
			if(!$data['birth']){
				$res['msg'] = $this->common->setting['lang']['birth_tips'];
				return $res;
			}

			if(!$data['height']){
				$res['msg'] = $this->common->setting['lang']['height_tips'];
				return $res;
			}

			if(!$data['weight']){
				$res['msg'] = $this->common->setting['lang']['weight_tips'];
				return $res;
			}

			if(!$data['education']){
				$res['msg'] = $this->common->setting['lang']['education_tips'];
				return $res;
			}

			if(!$data['month_income']){
				$res['msg'] = $this->common->setting['lang']['month_income_tips'];
				return $res;
			}

			if(!$data['occupation']){
				$res['msg'] = $this->common->setting['lang']['occupation_tips'];
				return $res;
			}

			if(!$data['marriage']){
				$res['msg'] = $this->common->setting['lang']['marriage_tips'];
				return $res;
			}

			if(!in_array($data['only'],array('1','0'))){
				$res['msg'] = $this->common->setting['lang']['only_tips'];
				return $res;
			}

			if(!$data['family']){
				$res['msg'] = $this->common->setting['lang']['family_tips'];
				return $res;
			}

			if(!$data['nation']){
				$res['msg'] = $this->common->setting['lang']['nation_tips'];
				return $res;
			}

			if(!$data['child']){
				$res['msg'] = $this->common->setting['lang']['child_tips'];
				return $res;
			}

			if(!$data['want_child']){
				$res['msg'] = $this->common->setting['lang']['want_child_tips'];
				return $res;
			}

			if(!$data['vehicle']){
				$res['msg'] = $this->common->setting['lang']['vehicle_tips'];
				return $res;
			}

			if(!$data['house']){
				$res['msg'] = $this->common->setting['lang']['house_tips'];
				return $res;
			}

			if(!$data['when_marry']){
				$res['msg'] = $this->common->setting['lang']['when_marry_tips'];
				return $res;
			}

			if(!$data['wx'] && $this->common->setting['wxRequired']){
				$res['msg'] = $this->common->setting['lang']['wx_tips'];
				return $res;
			}

			if(!$data['req_age_min']){
				$res['msg'] = $this->common->setting['lang']['req_age_tips'];
				return $res;
			}else if($data['req_age_min'] >= $data['req_age_max'] && $data['req_age_max']){
				$res['msg'] = $this->common->setting['lang']['req_age_min_tips'];
				return $res;
			}

			if(!$data['req_height_min']){
				$res['msg'] = $this->common->setting['lang']['req_height_tips'];
				return $res;
			}else if($data['req_height_min'] >= $data['req_height_max'] && $data['req_height_max']){
				$res['msg'] = $this->common->setting['lang']['req_height_min_tips'];
				return $res;
			}

			if(!$data['req_month_income']){
				$res['msg'] = $this->common->setting['lang']['req_month_income_tips'];
				return $res;
			}
			
			if(!$data['req_education']){
				$res['msg'] = $this->common->setting['lang']['req_education_tips'];
				return $res;
			}
		}
		if($userInfo['id']){
			$data['audit_state'] = $userInfo['audit_state'];
			$diff = array_diff($data,$userInfo);
			foreach(array('head_portrait','name','month_income','wx','album','introduce') as $k => $v) {
				if(array_key_exists($v,$diff)){
					$editContent[] = $this->common->setting['lang'][$v];
					$data['audit_state'] = 2;
				}
			}
			$this->common->setting['lang']['infoNoticeMsg'] = $editContent ? $this->common->setting['lang']['infoNoticeMsg'].$this->common->setting['lang']['infoNoticeCenter'].implode(',',$editContent) : $this->common->setting['lang']['infoNoticeMsg'];

			$data['editdateline'] = time();
			C::t('#fn_xiangqin#fn_love_user')->update($data,$userInfo['id']);
			$res['vid'] = $userInfo['id'];
			$res['state'] = 200;
			$res['msg'] = $data['audit_state'] == 2 ? '&#26032;&#36164;&#26009;&#23558;&#37325;&#26032;&#23457;&#26680;' : '&#20462;&#25913;&#36164;&#26009;&#25104;&#21151;';
		}else{
			$data['dateline'] = $data['updateline'] = time();
			$data['audit_state'] = 2;
			$data['channel'] = WxApp ? 2 : (App ? 3 : 1);
			$data['mat_id'] = $userInfo['mat_id'] = $this->common->matList[$get['mat_id']] ? $get['mat_id'] : array_rand($this->common->matList);
			$res['vid'] = C::t('#fn_xiangqin#fn_love_user')->insert($data,true);
			$res['state'] = 200;
			$res['msg'] = '&#30456;&#20146;&#36164;&#26009;&#25552;&#20132;&#25104;&#21151;&#65292;&#32418;&#23064;&#20250;&#31532;&#19968;&#26102;&#38388;&#23457;&#26680;';
		}

		if($data['audit_state'] == 2 && $data['per_check']){//֪ͨ�������
			$matList = $this->common->matList[$userInfo['mat_id']] ? array($this->common->matList[$userInfo['mat_id']]) : $this->common->matList;
			foreach($matList as $k => $v) {
				$this->common->getNotice($v['uid'],$v['openid'],$this->common->getUrl('view',array('vid'=>$res['vid'])),str_replace(array('[--name--]'),array($data['name']),$this->common->setting['lang']['infoNoticeMsg']),$this->common->setting['lang']['auditNotice']);
			}
		}
		return $res;
	}

	public function getSendOut($get = array()){//������֤��
		$phone = addslashes(strip_tags(trim($get['phone'])));
		//�ֻ������ж�
		$mobileMatch = "/".$this->common->setting['common_setting']['MobileMatch']."/";
		if(!$phone){
			$res['msg'] = $this->common->setting['lang']['phone_tips'];
			return $res;
		}else if(!preg_match($mobileMatch,$phone)){
			$res['msg'] = '&#25163;&#26426;&#21495;&#30721;&#26684;&#24335;&#19981;&#27491;&#30830;';
			return $res;
		}
		if($checkPhone = C::t('#fn_xiangqin#fn_love_user')->fetch_by_phone_nouid($phone,$this->common->_G['uid'])){//�����Ƿ����
			$res['msg'] = '&#25163;&#26426;&#21495;&#30721;&#24050;&#23384;&#22312;&#65292;&#35831;&#26356;&#25442;&#25163;&#26426;&#21495;&#30721;';
			return $res;
		}

		$checkLog = C::t('#fn_assembly#fn_send_sms_log')->fetch_by_check($phone,$this->common->_G['uid']);//�Ƿ���ⷢ����
		if($checkLog){
			$res['state'] = 200;
			$res['msg'] = '&#21457;&#36865;&#25104;&#21151;';
			return $res;
		}
		
		if($this->common->setting['common_setting']['ShortMessageType'] == 1){
			$templateCode = $this->common->setting['AliCodeId'];
			$templateParam = array('code'=>rand(100000,999999));
		}else if($this->common->setting['common_setting']['ShortMessageType'] == 2){
			$code = rand(100000,999999);
			$templateCode = str_replace(array('{phone}','{code}'),array($this->common->setting['common_setting']['MobileAreaCode'].$phone,$code),$this->common->setting['lang']['templateCode']);
			$templateParam = array('code'=>$code);
		}
		@require_once libfile('class/short_message','plugin/fn_assembly');
		$sendSms = fn_short_message::send_sms($this->common->setting['common_setting']['MobileAreaCode'].$phone,$this->common->setting['AliAutograph'],$templateCode,$templateParam,$this->common->_G['uid'],$this->common->_G['username'],'fn_xiangqin',1);

		if($sendSms['State'] == 200){
			$res['msg'] = '&#21457;&#36865;&#25104;&#21151;';
			$res['state'] = 200;
		}else{
			$res['msg'] = $sendSms['Msg'];
		}
		return $res;
	}

	public function getUserInfoEdit($get = array()){//�޸��û�����
		$res = array();
		$get = EncodeURIToUrldeCode($get);
		if($this->getCheckFormhash($get)){
			$res['msg'] = $this->common->setting['lang']['OpErr'];
			return $res;
		}
		$userInfo = $this->common->getUserInfo();
		if(!$userInfo['id']){
			$res['msg'] = '&#24744;&#36824;&#27809;&#26377;&#22635;&#20889;&#36164;&#26009;';
			return $res;
		}else if($userInfo['id'] && $userInfo['audit_state'] == 2){
			$res['msg'] = '&#36164;&#26009;&#23457;&#26680;&#20013;&#65292;&#26242;&#26102;&#19981;&#33021;&#20462;&#25913;';
			return $res;
		}else if($userInfo['id'] && $userInfo['audit_state'] == 3){
			$res['msg'] = '&#36164;&#26009;&#34987;&#25298;&#32477;&#65292;&#26242;&#26102;&#19981;&#33021;&#20462;&#25913;';
			return $res;
		}else if($userInfo['id'] && $userInfo['seal']){
			$res['msg'] = '&#36134;&#25143;&#24050;&#23553;&#65292;&#26242;&#26102;&#19981;&#33021;&#20462;&#25913;';
			return $res;
		}
		C::t('#fn_xiangqin#fn_love_user')->update(array($get['field']=>$get['value']),$userInfo['id']);
		$res['state'] = 200;
		$res['msg'] = $this->common->setting['lang']['UpdateOk'];
		return $res;
	}

	public function getCertView($get = array()){//��֤����
		$res['setting'] = $this->getSetting();
		$res['userInfo'] = $this->common->getUserInfo();
		if($res['setting']['admin']){
			$res['item'] = C::t('#fn_xiangqin#fn_love_verify')->fetch_by_id($get['vid']);
			if($res['item']){
				$res['item']['content'] = dunserialize($res['item']['content']);
				$res['item']['dateline'] = date('Y-m-d H:i',$res['item']['dateline']);
				$res['item']['updateline'] = date('Y-m-d H:i',$res['item']['updateline']);
			}
		}
		return $res;
	}
	
	public function getCertViewAdminOp($get = array()){//��֤����
		$get = EncodeURIToUrldeCode($get);
		$item = C::t('#fn_xiangqin#fn_love_verify')->fetch_by_id($get['vid']);
		if(!$this->common->setting['admin']){
			$res['msg'] = '&#26080;&#26435;&#25805;&#20316;';
			return $res;
		}
		if($get['op'] == 'edit'){
			$data = $get['field'] == 'audit_state' && $get['value'] == 3 ? array($get['field']=>addslashes(strip_tags($get['value'])),'refuse_tips'=>addslashes(strip_tags($get['content']))) : array($get['field']=>addslashes(strip_tags($get['value'])));
			C::t('#fn_xiangqin#fn_love_verify')->update($data,$get['vid']);
			$res['state'] = 200;
			$res['msg'] = $this->common->setting['lang']['UpdateOk'];
			if($get['field'] == 'audit_state'){
				$verifyUrlArr = array('1'=>'cert','2'=>'certedu','3'=>'certcar','4'=>'certhouse');
				$verifyArr = array('1'=>'real_verify','2'=>'education_verify','3'=>'vehicle_verify','4'=>'house_verify');
				$pushUrl = $this->common->getUrl('user',array('form'=>$verifyUrlArr[$item['type']]));
				$noticeMsg = str_replace(array('[--type--]','[--audit_state--]'),array($this->common->setting['lang']['user_verify_arr'][$item['type']],$this->common->setting['lang']['audit_state_arr'][$get['value']]),$this->common->setting['lang']['verifyNoticeMsg']);
				if($get['value'] == 1){
					C::t('#fn_xiangqin#fn_love_user')->update(array($verifyArr[$item['type']]=>1),$item['vid']);
					$this->common->getAuditNotice($item['vid'],$get['value'],$pushUrl,$noticeMsg);
				}else if($get['value'] == 3){
					$this->common->getAuditNotice($item['vid'],$get['value'],$pushUrl,$noticeMsg);
				}
			}
		}
		return $res;
	}
	
	public function getUserCert($get = array()){//��֤
		$res['setting'] = $this->getSetting();
		$res['userInfo'] = $this->common->getUserInfo();
		$res['verifyItem'] = C::t('#fn_xiangqin#fn_love_verify')->fetch_by_vid($res['userInfo']['id'],$get['type']);
		return $res;
	}

	public function getUserCertPost($get = array()){//�ύ��֤
		$res = array();
		$get = EncodeURIToUrldeCode($get);
		if($this->getCheckFormhash($get)){
			$res['msg'] = $this->common->setting['lang']['OpErr'];
			return $res;
		}
		
		$userInfo =	$this->common->getUserInfo();
		$verifyItem = C::t('#fn_xiangqin#fn_love_verify')->fetch_by_vid($userInfo['id'],$get['type']);
		if($verifyItem['audit_state'] == 1){//���ͨ�� ��ֹ�޸�
			$res['msg'] = '&#23457;&#26680;&#36890;&#36807;&#65292;&#31105;&#27490;&#20462;&#25913;';
			return $res;
		}else if(in_array($get['type'],array(2,3,4)) && $this->common->setting['certedu_car_house'] && !$userInfo['real_verify']){
			$res['state'] = 202;
			$res['msg'] = '&#24744;&#36824;&#27809;&#26377;&#23454;&#21517;&#35748;&#35777;&#65292;&#31105;&#27490;&#20854;&#20182;&#35748;&#35777;';
			return $res;
		}
		foreach(array_filter(explode(';',$get['new_cert_img'][0])) as $key => $val) {
			$get['new_cert_img'][$key] = strpos($val,'http') !== false ? $val : $this->common->_G['siteurl'].$val;
		}
		$data['cert_img'] = is_array($get['new_cert_img']) && isset($get['new_cert_img']) ? implode(',',$get['new_cert_img']) : '';
		$data['uid'] = intval($this->common->_G['uid']);
		$data['vid'] = intval($userInfo['id']);
		$data['type'] = intval($get['type']);
		if($get['type'] == 1){//��ʵ������֤
			if($get['name'] == ''){
				$res['msg'] = '&#35831;&#36755;&#20837;&#30495;&#23454;&#22995;&#21517;';
				return $res;
			}
			if($get['id_number'] == ''){
				$res['msg'] = '&#35831;&#36755;&#20837;&#36523;&#20221;&#35777;&#21495;';
				return $res;
			}else if($get['id_number'] && dstrlen($get['id_number']) != 18){
				$res['msg'] = '&#36523;&#20221;&#35777;&#21495;&#26684;&#24335;&#19981;&#27491;&#30830;';
				return $res;
			}else if(C::t('#fn_xiangqin#fn_love_verify')->fetch_by_id_number(addslashes(strip_tags($get['id_number'])),$data['vid'])){
				$res['msg'] = '&#35813;&#36523;&#20221;&#35777;&#21495;&#24050;&#35748;&#35777;&#65292;&#35831;&#21247;&#37325;&#22797;&#35748;&#35777;';
				return $res;
			}
			if($data['cert_img'] == ''){
				$res['msg'] = '&#35831;&#19978;&#20256;&#27491;&#33080;&#33258;&#25293;&#29031;';
				return $res;
			}

			$currency = $this->common->setting['certCurrency'];
			if($userInfo['currency'] < $currency && $currency){
				$res['state'] = 201;
				$res['msg'] = '&#24744;&#30340;&#37329;&#24065;&#19981;&#36275;&#21734;';
				return $res;
			}else if(!$this->common->setting['appcode']){
				$res['msg'] = '&#26410;&#24320;&#21551;&#35748;&#35777;&#21151;&#33021;';
				return $res;
			}

			$data['content']['name']['title'] = $this->common->setting['lang']['name'];
			$data['content']['name']['value'] = $get['name'];
			$data['content']['name']['content'] = $get['name'];
			$data['content']['id_number']['title'] = $this->common->setting['lang']['id_number'];
			$data['content']['id_number']['value'] = $get['id_number'];
			$data['content']['id_number']['content'] = $get['id_number'];
			
			/* ��������֤ */
			$file = GetAjaxBase64Image(array($data['cert_img']));
			$image = urlencode(str_replace('data:image/jpeg;base64,','',$file[0]));
			$bodys = "idCard=".$get['id_number']."&name=".diconv($get['name'],CHARSET,'UTF-8')."&image=" . $image;
			//�ӿ���֤
			$headers = array();
			array_push($headers, "Authorization:APPCODE " . $this->common->setting['appcode']);
			//����API��Ҫ�󣬶������Ӧ��Content-Type
			array_push($headers, "Content-Type".":"."application/x-www-form-urlencoded; charset=UTF-8");
			//���ط�У��
			$random = time();
			array_push($headers, "X-Ca-Nonce".":". $random);
			$resApi = json_decode($this->common->getAliApiCurl('https://edis3p.market.alicloudapi.com/edis_ctid_id_name_image',"POST",$bodys,$headers),true);
			if((string)$resApi['code'] !== '0000'){
				$res['msg'] = $resApi['msg'] ? diconv($resApi['msg'],'UTF-8',CHARSET) : '&#36523;&#20221;&#35777;&#20449;&#24687;&#19981;&#21305;&#37197;';
				return $res;
			}else if((string)$resApi['code'] === '0000'){
				$data['audit_state'] = 1;
			}
			if($currency){
				C::t('#fn_xiangqin#fn_love_user')->update_by_count($userInfo['id'],'currency',$currency,'-');
				C::t('#fn_xiangqin#fn_love_con_log')->insert(array('uid'=>intval($this->common->_G['uid']),'vid'=>intval($userInfo['id']),'love_vid'=>intval($userInfo['id']),'currency'=>intval($currency),'event_type'=>3,'content'=>str_replace(array('[--name--]'),array($userInfo['name']),$this->common->setting['lang']['con_log_content']['cert']),'dateline'=>time()));
			}
			/* ��������֤ END */

		}else if($get['type'] == 2){//ѧ����֤
			if($get['school'] == ''){
				$res['msg'] = '&#35831;&#36755;&#20837;&#27605;&#19994;&#23398;&#26657;';
				return $res;
			}
			if($get['education'] == ''){
				$res['msg'] = '&#35831;&#36873;&#25321;&#30495;&#23454;&#23398;&#21382;';
				return $res;
			}
			if($data['cert_img'] == ''){
				$res['msg'] = '&#35831;&#19978;&#20256;&#24744;&#30340;&#27605;&#19994;&#35777;&#20070;&#12289;&#23398;&#20301;&#35777;&#20070;&#25110;&#23398;&#20449;&#32593;&#25130;&#22270;';
				return $res;
			}
			$data['content']['school']['title'] = $this->common->setting['lang']['graduate_school'];
			$data['content']['school']['value'] = $get['school'];
			$data['content']['school']['content'] = $get['school'];
			$data['content']['education']['title'] = $this->common->setting['lang']['education'];
			$data['content']['education']['value'] = $get['education'];
			$data['content']['education']['content'] = $this->common->setting['lang']['education_arr'][$get['education']];
		}else if($get['type'] == 3){//����֤
			if($data['cert_img'] == ''){
				$res['msg'] = '&#35831;&#19978;&#20256;&#24744;&#30340;&#26426;&#21160;&#36710;&#34892;&#39542;&#35777;';
				return $res;
			}
		}else if($get['type'] == 4){//����֤
			if($data['cert_img'] == ''){
				$res['msg'] = '&#35831;&#19978;&#20256;&#24744;&#30340;&#26426;&#21160;&#36710;&#34892;&#39542;&#35777;';
				return $res;
			}
		}
		$data['content'] = $data['content'] ? serialize($data['content']) : '';
		if($verifyItem){
			$data['updateline'] = time();
			$data['audit_state'] = $verifyItem['audit_state'];
			C::t('#fn_xiangqin#fn_love_verify')->update($data,$verifyItem['id']);
			$res['id'] = $verifyItem['id'];
		}else{
			$data['dateline'] = $data['updateline'] = time();
			$data['audit_state'] = $data['audit_state'] ? $data['audit_state'] : 2;
			$id = $res['id'] = C::t('#fn_xiangqin#fn_love_verify')->insert($data,true);
		}
		$res['state'] = 200;
		$res['msg'] = '&#25552;&#20132;&#25104;&#21151;&#65292;&#31561;&#24453;&#23457;&#26680;&#65292;&#23457;&#26680;&#21069;&#21487;&#20462;&#25913;';
		if($data['audit_state'] == 1){
			$res['msg'] = '&#24685;&#21916;&#24744;&#65292;&#35748;&#35777;&#25104;&#21151;&#65281;';
			$verifyArr = array('1'=>'real_verify','2'=>'education_verify','3'=>'vehicle_verify','4'=>'house_verify');
			C::t('#fn_xiangqin#fn_love_user')->update(array($verifyArr[$data['type']]=>$data['audit_state']),$userInfo['id']);
		}else if($data['audit_state'] == 2){
			$matList = $this->common->matList[$userInfo['mat_id']] ? array($this->common->matList[$userInfo['mat_id']]) : $this->common->matList;
			foreach($matList as $k => $v) {
				$this->common->getNotice($v['uid'],$v['openid'],$this->common->getUrl('user',array('form'=>'admin_cert_view','vid'=>$res['id'])),str_replace(array('[--name--]','[--type--]'),array($userInfo['name'],$this->common->setting['lang']['user_verify_arr'][$get['type']]),$this->common->setting['lang']['verifyAdminNoticeMsg']),$this->common->setting['lang']['auditNotice']);
			}
		}
		return $res;
	}

	public function getUserTop($get = array()){//�ö�
		$userInfo = $this->common->getUserInfo();
		if(!$userInfo['id']){
			$res['state'] = 202;
			$res['msg'] = '&#24744;&#36824;&#27809;&#26377;&#22635;&#20889;&#36164;&#26009;';
			return $res;
		}else if(!$this->common->setting['topCurrency']){
			$res['msg'] = '&#32622;&#39030;&#21151;&#33021;&#26410;&#24320;&#21551;';
			return $res;
		}else if($userInfo['id'] && $userInfo['audit_state'] == 2){
			$res['msg'] = '&#36164;&#26009;&#23457;&#26680;&#20013;&#65292;&#26242;&#26102;&#19981;&#33021;&#32622;&#39030;';
			return $res;
		}else if($userInfo['id'] && $userInfo['audit_state'] == 3){
			$res['msg'] = '&#36164;&#26009;&#34987;&#25298;&#32477;&#65292;&#26242;&#26102;&#19981;&#33021;&#32622;&#39030;';
			return $res;
		}else if($userInfo['id'] && $userInfo['seal']){
			$res['msg'] = '&#36134;&#25143;&#24050;&#23553;&#65292;&#26242;&#26102;&#19981;&#33021;&#32622;&#39030;';
			return $res;
		}
		
		$currency = $this->common->setting['topCurrency'] * $get['day'];
		if($userInfo['currency'] < $currency){
			$res['state'] = 201;
			$res['msg'] = ($userInfo['sex'] == 1 ? '&#24069;&#21733;&#65292;' : '&#32654;&#22899;&#65292;').'&#24744;&#30340;&#37329;&#24065;&#19981;&#36275;&#21734;';
			return $res;
		}
		$topdateline = $userInfo['topdateline'] >= time() ? strtotime("+".intval($get['day'])." day",$userInfo['topdateline']) : strtotime("+".intval($get['day'])." day",time());
		C::t('#fn_xiangqin#fn_love_user')->update(array('topdateline'=>$topdateline),$userInfo['id']);
		C::t('#fn_xiangqin#fn_love_user')->update_by_count($userInfo['id'],'currency',$currency,'-');
		C::t('#fn_xiangqin#fn_love_con_log')->insert(array('uid'=>intval($this->common->_G['uid']),'vid'=>intval($userInfo['id']),'love_vid'=>intval($userInfo['vid']),'currency'=>intval($currency),'event_type'=>5,'content'=>str_replace(array('[--name--]','[--day--]'),array($userInfo['name'],$get['day']),$this->common->setting['lang']['con_log_content']['top']),'dateline'=>time()));
		$res['state'] = 200;
		$res['msg'] = '&#36192;&#36865;&#25104;&#21151;<br>'.($userInfo['sex'] == 1 ? '&#24069;&#21733;&#65292;' : '&#32654;&#22899;&#65292;').'&#24685;&#21916;&#24744;&#65292;&#32622;&#39030;&#25104;&#21151;';
		$res['top'] = true;
		$res['topdateline'] = date('Y-m-d',$topdateline);
		$res['currency'] = $userInfo['currency'] - $currency;
		return $res;
	}

	public function getUserLook($get = array()){//�ҵķ����б�
		$userInfo = $this->common->getUserInfo();
		if(!$get['srcoll']){
			$res['setting'] = $this->getSetting();
			$res['userInfo'] = $userInfo;
		}
		$where = $get['type'] != 2 ? array('love_vid'=>$userInfo['id']) : array('vid'=>$userInfo['id']);
		$logRes = $userInfo['id'] ? C::t('#fn_xiangqin#fn_love_look')->fetch_all_by_list($where,'dateline',$get['page'],10,true) : '';
		$res['list'] = $this->getFormLookList($logRes['list']);
		$res['count'] = $logRes['count'] ? $logRes['count'] : 0;
		return $res;
	}

	public function getUserFollow($get = array()){//�ҵĹ�ע�б�
		$userInfo = $this->common->getUserInfo();
		if(!$get['srcoll']){
			$res['setting'] = $this->getSetting();
			$res['userInfo'] = $userInfo;
		}
		$where = $get['type'] != 2 ? array('love_vid'=>$userInfo['id']) : array('vid'=>$userInfo['id']);
		$logRes = $userInfo['id'] ? C::t('#fn_xiangqin#fn_love_follow')->fetch_all_by_list($where,'dateline',$get['page'],10,true) : '';
		$res['list'] = $this->getFormFollowList($logRes['list']);
		$res['count'] = $logRes['count'] ? $logRes['count'] : 0;
		return $res;
	}

	public function getUserGift($get = array()){//�ҵ������б�
		$userInfo = $this->common->getUserInfo();
		if(!$get['srcoll']){
			$res['setting'] = $this->getSetting();
			$res['userInfo'] = $userInfo;
		}
		$where = $get['type'] != 2 ? array('love_vid'=>$userInfo['id']) : array('vid'=>$userInfo['id']);
		$logRes = $userInfo['id'] ? C::t('#fn_xiangqin#fn_love_gift_log')->fetch_all_by_list($where,'dateline',$get['page'],10,'','id') : '';
		$res['list'] = $this->getFormGiftList($logRes['list']);
		return $res;
	}

	public function getUserService($get = array()){//��������
		$res['setting'] = $this->getSetting();
		return $res;
	}

	private function getFormInfoList($arr){//�б�ת��
		$userInfo = $this->common->getUserInfo();
		foreach($arr as $key => $val){
			$arr[$key] = $this->common->getFormUser($val);
			$arr[$key]['follow'] = C::t('#fn_xiangqin#fn_love_follow')->fetch_by_vid($userInfo['id'],$val['id']); //��ע
			$arr[$key]['contact'] = C::t('#fn_xiangqin#fn_love_user_contact_log')->fetch_by_vid($userInfo['id'],$val['id']);//��ϵ��ʽ
			if(!$arr[$key]['contact']){$arr[$key]['phone'] = $arr[$key]['wx'] = '';}
		}
		return $arr;
	}

	private function getFormFarSingleList($arr){//�ѵ�ת��
		foreach($arr as $key => $val){
			$arr[$key]['userInfo'] = $this->common->getView($val['vid']);
			$arr[$key]['content'] =  str_replace("\r\n","<br>",$val['content']);
			$arr[$key]['album'] =  array_filter(explode(",",$val['album']));
			$arr[$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d');
			$arr[$key]['updateline'] =  FormatDate($val['updateline'],'Y-m-d');
		}
		return $arr;
	}

	private function getFormPullList($arr){//ǣ��ת��
		foreach($arr as $key => $val){
			$arr[$key]['userInfo'] = $this->common->getView($val['vid']);
			$arr[$key]['heUserInfo'] = $this->common->getView($val['love_vid']);
			$arr[$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d');
		}
		return $arr;
	}

	private function getFormLookList($arr){//����ת��
		foreach($arr as $key => $val){
			$arr[$key]['userInfo'] = $this->common->getView($val['vid']);
			$arr[$key]['heUserInfo'] = $this->common->getView($val['love_vid']);
			$arr[$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d');
		}
		return $arr;
	}

	private function getFormFollowList($arr){//��עת��
		foreach($arr as $key => $val){
			$arr[$key]['userInfo'] = $this->common->getView($val['vid']);
			$arr[$key]['heUserInfo'] = $this->common->getView($val['love_vid']);
			$arr[$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d');
		}
		return $arr;
	}

	private function getFormGiftList($arr){//����ת��
		foreach($arr as $key => $val){
			$arr[$key]['userInfo'] = $this->common->getView($val['vid']);
			$arr[$key]['userInfo']['count_tips'] = str_replace(array('[--name--]','[--count--]','[--title--]'),array($arr[$key]['userInfo']['name'],$val['currency'],$val['title']),$this->common->setting['lang']['user_gift_tips']['2']);
			$arr[$key]['heUserInfo'] = $this->common->getView($val['love_vid']);
			$arr[$key]['heUserInfo']['count_tips'] = str_replace(array('[--count--]','[--title--]'),array($val['currency'],$val['title']),$this->common->setting['lang']['user_gift_tips']['1']);
			$arr[$key]['dateline'] =  FormatDate($val['dateline'],'Y-m-d');
		}
		return $arr;
	}

	private function getFormActivityList($arr){//��б�ת��
		foreach($arr as $key => $val){
			$arr[$key] = $this->common->getFormActivity($val);
		}
		return $arr;
	}

	private function getFormfollowLogList($arr){//�����б�ת��
		foreach($arr as $key => $val){
			$arr[$key]['follow_dateline'] = date('Y-m-d',$val['follow_dateline']);
			$arr[$key]['dateline'] = date('Y-m-d',$val['dateline']);
		}
		return $arr;
	}

	private function getFormTextareaArr($arr,$replaceArr,$symbol = "|"){
		$res = array();
		foreach($arr as $key => $val){
			foreach(array_filter(explode($symbol,$val)) as $k => $v){
				$res[$key][$replaceArr[$k]] = $v;
			}
		}
		return $res;
	}

	private function getFormReplaceSiteurl($arr){
		foreach($arr as $key => $val){
			foreach($val as $k => $v){
				$arr[$key][$k] = str_replace('[siteurl]',$this->common->_G['siteurl'],$v);
			}
		}
		return $arr;
	}
	
	public function getUpload($get = array()){
		if($this->getCheckFormhash($get)){
			$res['msg'] = $this->common->setting['lang']['OpErr'];
			return $res;
		}
		$data = GetAjaxUpload($_FILES);
		if($data['State'] == 200){
			$res['state'] = $data['State'];
			$res['path'] = urldecode($data['Path']);
		}else{
			$res['msg'] = '&#29983;&#25104;&#20986;&#38169;&#20102;';
		}
		return $res;
	}
	
	/* ����֧����¼ */
	private function getAjaxPayLog($get = array()){
		$get = EncodeURIToUrldeCode($get);
		$param['event'] = addslashes(strip_tags($get['event']));
		$userInfo = $this->common->getUserInfo();
		$mat = $this->common->matList[$userInfo['mat_id']];
		if($param['event'] == 'buy_setmeal_vip' || $param['event'] == 'buy_setmeal_currency' || $param['event'] == 'buy_setmeal_imkey'){//�����ײ�
			$item = C::t('#fn_xiangqin#fn_love_meal')->fetch_by_id($get['group_id']);
			$param['group_data'] = $get['group_data'];
			$param['group_pay_data'] = $get['group_pay_data'];
			$param['group_id'] = $get['group_id'];
			$param['user_id'] = $get['user_id'];
			$content = str_replace(array('{group_id}','{title}'),array($item['id'],$item['title']), $this->common->setting['lang']['setmealPayContent']);
		}else if($param['event'] == 'activity_signup'){//����
			$item = C::t('#fn_xiangqin#fn_love_activity')->fetch_by_id($get['insert_data']['aid']);
			$param['insert_data'] = $get['insert_data'];
			$content = str_replace(array('{aid}','{title}','{name}','{user_id}'),array($item['id'],$item['title'],$userInfo['name'],$userInfo['id']), $this->common->setting['lang']['activitySignupContent']);
		}
		return $this->common->pay->PayLogInsert($get['money'],$param,$content,'fn_xiangqin',$mat['staff_id']);
	}
}
$api = new fn_xiangqin_api;
$action = $_GET['action'];
echo CJSON::encode($api->$action($_GET));
exit();
?>