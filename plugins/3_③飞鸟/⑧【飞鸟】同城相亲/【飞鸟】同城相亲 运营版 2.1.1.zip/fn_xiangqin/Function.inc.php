<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@require_once libfile('function/core','plugin/fn_assembly');
@require_once libfile('class/magapp','plugin/fn_assembly');
@require_once libfile('class/qfapp','plugin/fn_assembly');
@require_once libfile('class/pay','plugin/fn_assembly');

class Fn_XiangQin{
	public function __construct() {
		global $_G,$plugin;
		loadcache('plugin');
		$this->Config['PluginVar'] = (array) $_G['cache']['plugin']['fn_xiangqin'];
		$this->AdminUidsList = $this->MatchmakerAdminUidsList = array_filter(explode(",",$this->Config['PluginVar']['AdminUids']));
		$this->ExamineTwoList = array_filter(explode("\r\n",$this->Config['PluginVar']['ExamineTwoList']));
		$this->AuthenticationExamineTwoList = array_filter(explode("\r\n",$this->Config['PluginVar']['AuthenticationExamineTwoList']));
		$this->Config['PluginVar']['Navs'] = array_filter(explode("\r\n",$this->Config['PluginVar']['Navs']));
		$this->Admin = in_array($_G['uid'],$this->AdminUidsList) ? true : false;
		
		$this->Config['LangVar'] = lang('plugin/fn_xiangqin');
		$this->Config['LangVar']['MonthIncomeArray'] = TextareaArray($this->Config['PluginVar']['MonthIncomeList']);
		$this->Config['LangVar']['OccupationArray'] = TextareaArray($this->Config['PluginVar']['OccupationList']);
		$this->Config['LangVar']['EthnicArray'] = TextareaArray($this->Config['PluginVar']['Ethnic']);
		$this->Config['LangVar']['BirthLocalArray'] = SelectArray($this->Config['PluginVar']['BirthLocal']);
		$this->Config['LangVar']['ResideArray'] = SelectArray($this->Config['PluginVar']['Reside']);
		$this->Config['LangVar']['HobbyArray'] = TextareaArray($this->Config['PluginVar']['Hobby']);
		$this->Config['Path'] = 'source/plugin/fn_xiangqin';
		$this->Config['StaticPath'] = $this->Config['Path'].'/static';
		$this->Config['StaticPicPath'] = $this->Config['Path'].'/attachment/';
		$this->Config['Url'] = $_G['siteurl'].'plugin.php?id=fn_xiangqin'.($_GET['formapp'] ? '&formapp='.$_GET['formapp'] : '');
		$this->Config['HeUserUrl'] = $this->Config['Url'].'&m=he_user&user_id=';
		$this->Config['UserUrl'] = $this->Config['Url'].'&m=user';
		$this->Config['UserViewLogUrl'] = $this->Config['Url'].'&m=user_view_log';
		$this->Config['VipUrl'] = $this->Config['Url'].'&m=vip';
		$this->Config['DisplayUrl'] = $this->Config['Url'].'&m=display';
		$this->Config['UserInfoUrl'] = $this->Config['Url'].'&m=user_info';
		$this->Config['UserAuthenticationUrl'] = $this->Config['Url'].'&m=user_authentication';
		$this->Config['ConditionUrl'] = $this->Config['Url'].'&m=condition';
		$this->Config['AlbumUrl'] = $this->Config['Url'].'&m=album';
		$this->Config['MonologueUrl'] = $this->Config['Url'].'&m=monologue';
		$this->Config['CardUrl'] = $this->Config['Url'].'&m=card';
		$this->Config['SetTopUrl'] = $this->Config['Url'].'&m=set_top';
		$this->Config['ReportUrl'] = $this->Config['Url'].'&m=report';
		$this->Config['CollectUrl'] = $this->Config['Url'].'&m=collect';
		$this->Config['PayLogUrl'] = $this->Config['Url'].'&m=pay_log';
		$this->Config['HelpUrl'] = $this->Config['Url'].'&m=help';
		$this->Config['AdminListUrl'] = $this->Config['Url'].'&m=admin_list';
		$this->Config['HdUrl'] = $this->Config['Url'].'&m=hd';
		$this->Config['AjaxUrl'] =  'plugin.php?id=fn_xiangqin:Ajax'.($_GET['formapp'] ? '&formapp='.$_GET['formapp'] : '');
		$this->Config['WxShare'] = array(
			'WxTitle' => $this->Config['PluginVar']['WxTitle'],
			'WxDes' => $this->Config['PluginVar']['WxDes'],
			'WxImg' => strpos($this->Config['PluginVar']['WxImg'],'http') !== false ? $this->Config['PluginVar']['WxImg'] : $_G['siteurl'].$this->Config['PluginVar']['WxImg'],
			'WxUrl' => $this->Config['Url']
		);
		if(!is_dir(DISCUZ_ROOT.$this->Config['StaticPicPath'])){
			mkdir(DISCUZ_ROOT.$this->Config['StaticPicPath']);
		}
		
		$this->TableMember = 'fn_member';
		$this->TablePayLog = 'fn_xiangqin_pay_log';
		$this->TableCondition = 'fn_xiangqin_condition';
		$this->TableSendSmsLog = 'fn_send_sms_log';
		$this->TableReport = 'fn_xiangqin_report';
		$this->TableCollect = 'fn_xiangqin_collect';
		$this->TableMatchmaker = 'fn_xiangqin_matchmaker';
		$this->TableAuthentication = 'fn_xiangqin_authentication';
		$this->TablePull = 'fn_xiangqin_pull';
		$this->TableViewLog = 'fn_xiangqin_view_log';
		$this->TableSeeLog = 'fn_xiangqin_see_log';
		
		$this->Pay = new Fn_PayLog();
		$this->MagApp = new MagApp($this->Config['PluginVar']['MagSecret'],$this->Config['PluginVar']['MagAssistantSecret'],$this->Config['PluginVar']['MagAssistantPush']);
		$this->QHApp = new QHApp($this->Config['PluginVar']['qf_type'],$this->Config['PluginVar']['qf_sr_type'],$this->Config['PluginVar']['qf_from_id']);
		$this->Config['AppPaymentId'] = $this->QHApp->AppPaymentId;
		
		$this->Config['Matchmaker'] = $this->GetMatchmakerUserInfo($_G['uid']);
		
		if($this->Config['Matchmaker']){
			$this->MatchmakerAdminUidsList[] = $this->Config['Matchmaker']['uid'];
		}
	}
	/* 用户资料 */
	public function GetUserInfo($Uid){
		
		$Uid = intval($Uid);
		$MemBer = DB::fetch_first('SELECT M.* FROM '.DB::table($this->TableMember).' M where M.uid = '.$Uid);
		if($MemBer){
			$MemBer['param'] = unserialize($MemBer['param']);
			$MemBer['face'] = $MemBer['face'] ? $MemBer['face'] : ($MemBer['sex'] == 1 ? $this->Config['PluginVar']['DefaultFace1'] : $this->Config['PluginVar']['DefaultFace2']);
			$MemBer['face'] = strpos($MemBer['face'],'http') !== false ? $MemBer['face'] : $_G['siteurl'].$MemBer['face'];
			$MemBer['date_birth'] = $MemBer['birth'] ? date('Y-m-d',$MemBer['birth']) : '';
			$MemBer['vip'] = time() < $MemBer['vip_time'] ? true : false;
			$MemBer['lead_line'] = $MemBer['vip'] ? $MemBer['lead_line'] : 0;
			$MemBer['see_line'] = $MemBer['vip'] ? $MemBer['see_line'] : 0;
				
			$MemBer['settop'] = time() < $MemBer['top_dateline'] ? true : false;
			$MemBer['displaydate'] = time() < $MemBer['display_dateline'] ? true : false;
			$MemBer['album_count'] = $MemBer['param']['album'] ? count($MemBer['param']['album']) : '';
			$MemBer['birth_local'] = $this->Config['LangVar']['BirthLocalArray'][$MemBer['birth_province']]['content'].$this->Config['LangVar']['BirthLocalArray'][$MemBer['birth_city']]['content'].$this->Config['LangVar']['BirthLocalArray'][$MemBer['birth_dist']]['content'];
			$MemBer['reside'] = $this->Config['LangVar']['ResideArray'][$MemBer['reside_province']]['content'].$this->Config['LangVar']['ResideArray'][$MemBer['reside_city']]['content'].$this->Config['LangVar']['ResideArray'][$MemBer['reside_dist']]['content'];
			$MemBer['hobby_array'] = array_filter(explode(",",$MemBer['hobby']));
			$MemBer['condition'] = array_filter(DB::fetch_first('SELECT * FROM '.DB::table($this->TableCondition).' where uid = '.$Uid));
			$MemBer['authentication'] = DB::fetch_first('SELECT * FROM '.DB::table($this->TableAuthentication).' where uid = '.$Uid);

			$MemBer['v'] = $MemBer['authentication']['examine'] == 1 ? true : false;
			
			unset($MemBer['condition']['uid']);
			unset($MemBer['condition']['updateline']);
			unset($MemBer['condition']['dateline']);
		}
		return $MemBer;
	}
	
	/* 红娘资料 */
	public function GetMatchmakerUserInfo($Uid){
		$MemBer = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMatchmaker).' M where M.uid = '.intval($Uid));
		if($MemBer){
			$MemBer['param'] = unserialize($MemBer['param']);
		}
		return $MemBer;
	}

	/* 红娘列表 */
	public function GetMatchmakerList(){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableMatchmaker));
	}

	/* 用户手机号 */
	public function GetMobile(){
		global $_G,$Config;
		if($Config['PluginVar']['AppType'] == 2){
			$Mobile = DB::fetch_first('SELECT phone as mobile FROM '.DB::table('phonebind').' where uid = '.intval($_G['uid']));
		}else{
			$Mobile = DB::fetch_first('SELECT mobile FROM '.DB::table('common_member_profile').' where uid = '.intval($_G['uid']));
		}
		
		return $Mobile['mobile'];
	}
	/* 列表 */
	public function GetAjaxList($Get){
		global $_G;
		$Results = array();
		$Get = StrToGBK($Get);
		$UserInfo = $this->GetUserInfo($_G['uid']);
		$Page = $Get['page'] ? intval($Get['page']) : 0;
		$Where = ' and M.display = 1 and M.examine = 1 and M.seal = 0';
		$Order = 'M.dateline';
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		if($Get['type'] == 'Matching'){
			
			if($UserInfo['condition']['c_min_age'] && $UserInfo['condition']['c_max_age']){
				$Where .= ' and M.age >= '.intval($UserInfo['condition']['c_min_age']).' and M.age <= '.intval($UserInfo['condition']['c_max_age']);
			}

			if($UserInfo['condition']['c_min_height'] && $UserInfo['condition']['c_max_height']){
				$Where .= ' and M.height >= '.intval($UserInfo['condition']['c_min_height']).' and M.height <= '.intval($UserInfo['condition']['c_max_height']);
			}

			if($UserInfo['condition']['c_month_income']){
				$Where .= ' and M.month_income = '.intval($UserInfo['condition']['c_month_income']);
			}

			if($UserInfo['condition']['c_education']){
				$Where .= ' and M.education >= '.intval($UserInfo['condition']['c_education']);
			}

			if($UserInfo['condition']['c_marriage']){
				$Where .= ' and M.marriage = '.intval($UserInfo['condition']['c_marriage']);
			}

			if($UserInfo['condition']['c_ethnic']){
				$Where .= ' and M.ethnic = '.intval($UserInfo['condition']['c_ethnic']);
			}

			if($UserInfo['condition']['c_house'] == 2){
				$Where .= ' and M.house in (2,3)';
			}

			if($UserInfo['condition']['c_vehicle'] == 2){
				$Where .= ' and M.vehicle in (2,3,4)';
			}
			$Where .= $UserInfo['sex'] == 1 ? ' and M.sex = 2' : ' and M.sex = 1';
		}
		if($Get['keyword']){
			if(is_numeric($Get['keyword']) && strpos($Get['keyword'],$this->Config['PluginVar']['MatchmakingCardNum']) === 0){
				$Get['keyword'] = substr_replace($Get['keyword'],'',0,dstrlen($this->Config['PluginVar']['MatchmakingCardNum']));
			}
			$Where .= " and (M.uid = '$Get[keyword]' or M.name like '%$Get[keyword]%')";
		}else{
			if($Get['home']){
				$Where .= ' and M.home = '.intval($Get['home']);
			}

			if($Get['sex'] && $Get['type'] != 'Matching'){
				$Where .= ' and M.sex = '.intval($Get['sex']);
			}

			if($Get['age']){
				$AgeArray = array_filter(explode("-",$Get['age']));
				if($AgeArray[0] && $AgeArray[1]){
					$Where .= ' and M.age >= '.intval($AgeArray[0]);
					$Where .= ' and M.age <= '.intval($AgeArray[1]);
				}else if($AgeArray[0]){
					$Where .= ' and M.age <= '.intval($AgeArray[0]);
				}else if($AgeArray[1]){
					$Where .= ' and M.age >= '.intval($AgeArray[1]);
				}
			}

			if($Get['height']){
				$HeightArray = array_filter(explode("-",$Get['height']));
				if($HeightArray[0] && $HeightArray[1]){
					$Where .= ' and M.height >= '.intval($HeightArray[0]);
					$Where .= ' and M.height <= '.intval($HeightArray[1]);
				}else if($HeightArray[0]){
					$Where .= ' and M.height <= '.intval($HeightArray[0]);
				}else if($HeightArray[1]){
					$Where .= ' and M.height >= '.intval($HeightArray[1]);
				}
			}

			if($Get['month_income']){
				$Where .= ' and M.month_income = '.intval($Get['month_income']);
			}

			if($Get['marriage']){
				$Where .= ' and M.marriage = '.intval($Get['marriage']);
			}

			if($Get['education']){
				$Where .= ' and M.education = '.intval($Get['education']);
			}
			if(in_array($Get['lead_line_state'],array('0','1'))){
				$Where .= ' and M.lead_line_state = '.intval($Get['lead_line_state']);
			}
		}
		
		$Where = preg_replace('/and/','where',$Where,1);

		$FetchSql = 'SELECT M.*,A.examine as a_examine FROM '.DB::table($this->TableMember).' M LEFT JOIN `'.DB::table($this->TableAuthentication).'` A on A.uid = M.uid '.$Where .' order by M.top_dateline > '.time().' desc,'.$Order.' desc,M.id desc '.$Limit;
		
		$Results = DB::fetch_all($FetchSql);
		
		if($this->Config['PluginVar']['HomeAd'] && !$Page && $Results){//加广告
			$HomeAd = array_filter(explode("|",$this->Config['PluginVar']['HomeAd']));//广告
			$HomeAdArray[] = array('link'=>$HomeAd['4'] ? $HomeAd['4'] : '','face'=>$HomeAd['3'],'ftitle'=>$HomeAd['2'],'title'=>$HomeAd['1']);
			array_splice($Results,$HomeAd[0]-1,0,$HomeAdArray);
		}
		$Results = $this->ListFormat($Results,array_filter(explode(',',$_GET['collect_uids'])));
		return $Results;
	}
	/* 管理员列表 */
	public function GetAjaxAdminList($Get){
		global $_G;
		$Results = array();
		$Get = StrToGBK($Get);
		if($this->Admin || $this->Config['Matchmaker']){
			if($Get['type'] == 'Examine1'){
				$Where = ' and M.examine = 1';
			}else if($Get['type'] == 'Examine2'){
				$Where = ' and M.examine = 2';
			}else if($Get['type'] == 'Examine3'){
				$Where = ' and M.examine = 3';
			}else if($Get['type'] == 'Display0'){
				$Where = ' and M.display = 0';
			}else if($Get['type'] == 'Display1'){
				$Where = ' and M.display = 1';
			}else if($Get['type'] == 'VIP'){
				$Where = ' and M.vip_time >= '.time();
			}
			
			if($this->Config['Matchmaker'] && !in_array($this->Config['Matchmaker']['uid'],$this->AdminUidsList)){
				$Where .= ' and M.mid >= '.intval($this->Config['Matchmaker']['uid']);
			}

			$Order = 'M.updateline';
			$Page = $Get['page'] ? intval($Get['page']) : 0;
			$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
			$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];
			$Where = preg_replace('/and/','where',$Where,1);
			$FetchSql = 'SELECT M.*,A.examine as a_examine FROM '.DB::table($this->TableMember).' M LEFT JOIN `'.DB::table($this->TableAuthentication).'` A on A.uid = M.uid '.$Where .' order by '.$Order.' desc,M.dateline desc '.$Limit;

			$Results = $this->ListFormat(DB::fetch_all($FetchSql));
		}
		return $Results;
	}
	/* 列表格式转换 */
	public function ListFormat($Array,$CollectArray=null){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['face'] = $Val['face'] ? $Val['face'] : ($Val['sex'] == 1 ? $this->Config['PluginVar']['DefaultFace1'] : $this->Config['PluginVar']['DefaultFace2']);
			$Array[$Key]['mobile'] = '';
			$Array[$Key]['param']['wx'] = '';
			$Array[$Key]['param']['qq'] = '';
			$Array[$Key]['month_income_text'] = $this->Config['LangVar']['MonthIncomeArray'][$Val['month_income']];
			$Array[$Key]['height_text'] = $this->Config['LangVar']['UserInfoHeightArray'][$Val['height']];
			$Array[$Key]['weight_text'] = $this->Config['LangVar']['UserInfoWeightArray'][$Val['weight']];
			$Array[$Key]['top_val'] = time() < $Val['top_dateline'] ? 1 : 0;
			$Array[$Key]['vip_val'] = time() < $Val['vip_time'] ? 1 : 0;
			$Array[$Key]['v'] = $Val['a_examine'] == 1 ? 1 : 0;
			$Array[$Key]['house_val'] = in_array($Val['house'],array(2,3)) ? 1 : 0;
			$Array[$Key]['vehicle_val'] = in_array($Val['vehicle'],array(2,3,4)) ? 1 : 0;
			$Array[$Key]['collect'] = in_array($Val['uid'],$CollectArray) ? 1 : 0;
			$Array[$Key]['ad'] = $Array[$Key]['title'] ? 1 : 0;
			if($Val['name_type'] == 2){
				$Array[$Key]['name'] =  $this->Config['LangVar']['BianHao'].':'.$this->Config['PluginVar']['MatchmakingCardNum'].$Val['uid'];
			}else if($Val['name_type'] == 3){
				$Array[$Key]['name'] =  cutstr($Val['name'],3,'').$this->Config['LangVar']['SexToArray'][$Val['sex']];
			}
			
		}
		return $Array;
	}
	/* 编辑基本资料 */
	public function GetAjaxUserInfo($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$UserInfo = $this->GetUserInfo($_G['uid']);
		$GetData['uid'] = intval($_G['uid']);
		$GetData['username'] = addslashes(strip_tags($_G['username']));
		$GetData['name'] = censor(addslashes(strip_tags($Get['name'])));
		$GetData['name_type'] = intval($Get['name_type']);
		$GetData['sex'] = intval($Get['sex']);
		$GetData['birth'] = strtotime($Get['birth']);
		$GetData['birth_province'] = addslashes(strip_tags($Get['birth_province']));
		$GetData['birth_city'] = addslashes(strip_tags($Get['birth_city']));
		$GetData['birth_dist'] = addslashes(strip_tags($Get['birth_dist']));
		$GetData['reside_province'] = addslashes(strip_tags($Get['reside_province']));
		$GetData['reside_city'] = addslashes(strip_tags($Get['reside_city']));
		$GetData['reside_dist'] = addslashes(strip_tags($Get['reside_dist']));
		$GetData['height'] = intval($Get['height']);
		$GetData['weight'] = intval($Get['weight']);
		$GetData['blood'] = intval($Get['blood']);
		$GetData['ethnic'] = intval($Get['ethnic']);
		$GetData['company'] = censor(addslashes(strip_tags($Get['company'])));
		$GetData['education'] = intval($Get['education']);
		$GetData['marriage'] = intval($Get['marriage']);
		$GetData['child'] = intval($Get['child']);
		$GetData['mobile'] = addslashes(strip_tags(trim($Get['mobile'])));
		$GetData['occupation'] = intval($Get['occupation']);
		$GetData['month_income'] = intval($Get['month_income']);
		$GetData['house'] = intval($Get['house']);
		$GetData['vehicle'] = intval($Get['vehicle']);
		$GetData['hobby'] = addslashes(strip_tags($Get['hobby']));
		$Wx = array_filter(explode(';',$Get['wx']));
		$Param['wx'] = addslashes(strip_tags($Wx[0]));
		$Param['qq'] = censor(addslashes(strip_tags($Get['qq'])));
		$Param['monologue'] = censor(addslashes(strip_tags($Get['monologue'])));
		$GetData['display'] = !$UserInfo ? 1 : $UserInfo['display'];
		$GetData['examine'] = 2;//待审核
		$GetData['param'] = serialize($Param);
		
		if($Get['facenew'][0]) {//头像判断
			$GetData['face'] = addslashes(strip_tags($Get['facenew'][0]));
		}else if($Get['face']){
			$GetData['face'] = addslashes(strip_tags($Get['face']));
		}else if($this->Config['PluginVar']['FaceSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddFaceErr']);
			return $Data;
		}

		if(!$GetData['name']){//姓名判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['NamePlaceholder']);
			return $Data;
		}

		if(!$GetData['name_type']){//姓名显示判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['NameTypeTips']);
			return $Data;
		}

		if(!$GetData['sex']){//性别判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['SexPlaceholder']);
			return $Data;
		}
		
		if(!$GetData['birth']){//出生日期判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['BirthPlaceholder']);
			return $Data;
		}
		if(!$GetData['birth_province'] && $this->Config['PluginVar']['BirthLocal']){//出生地判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['BirthLocalPlaceholder']);
			return $Data;
		}
		if(!$GetData['reside_province'] && $this->Config['PluginVar']['Reside']){//居住地判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResidePlaceholder']);
			return $Data;
		}
		if(!$GetData['height']){//身高判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['HeightPlaceholder']);
			return $Data;
		}

		if(!$GetData['height']){//体重判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['WeightPlaceholder']);
			return $Data;
		}

		if(!$GetData['ethnic'] && $UserInfo){//民族判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['EthnicPlaceholder']);
			return $Data;
		}

		if(!$GetData['company'] && $UserInfo){//工作单位判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyPlaceholder']);
			return $Data;
		}

		if(!$GetData['education']){//学历判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['EducationPlaceholder']);
			return $Data;
		}

		if(!$GetData['marriage']){//婚姻状况判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['MarriagePlaceholder']);
			return $Data;
		}

		if((!QFApp && !MagApp) || $this->Config['PluginVar']['AppRegisterMobileSwitch']){//App内不用判断
			//手机号码判断
			$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
			if(!$GetData['mobile']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['MobilePlaceholder']);
				return $Data;
			}else if(!preg_match($IsMob,$GetData['mobile'])){
				$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
				return $Data;
			}
			if(!$UserInfo && $CheckMobileData = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where mobile = '.$GetData['mobile'].' and uid != '.$GetData['uid'])){
				$Data['Msg'] = urlencode($this->Config['LangVar']['MobileRepeatErr']);
				return $Data;
			}
			//手机号码判断 End
			
			//验证码判断
			if(!$UserInfo){
				if(!$Get['code']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['CodePlaceholder']);
					return $Data;
				}
				$CheckSendSmsLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSendSmsLog).' where state = 200 and cache_dateline > '.time().' and uid = '.intval($_G['uid']).' and mobile = '.$GetData['mobile'].' and code = '.$Get['code'].' and sms_type = 1 order by id desc');
				if(!$CheckSendSmsLog){
					$Data['Msg'] = urlencode($this->Config['LangVar']['CodeErr']);
					return $Data;
				}
			}
			//验证码判断 End
		}else{
			$GetData['mobile'] = $this->GetMobile();
		}
		
		if(!$Param['wx'] && $this->Config['PluginVar']['WxRequiredSwitch']){//微信号判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['WxPlaceholder']);
			return $Data;
		}else if($this->Config['PluginVar']['WxRequiredSwitch'] && !preg_match("/^[A-Za-z0-9_-]+$/",$Param['wx'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['WxChineseErr']);
			return $Data;
		}
		
		if(!$GetData['occupation']){//职业判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['OccupationPlaceholder']);
			return $Data;
		}

		if(!$GetData['month_income']){//月收入判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['MonthIncomePlaceholder']);
			return $Data;
		}

		if(!$GetData['house']){//居住情况判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['HousePlaceholder']);
			return $Data;
		}

		if(!$GetData['vehicle']){//购车情况判断
			$Data['Msg'] = urlencode($this->Config['LangVar']['VehiclePlaceholder']);
			return $Data;
		}
		if($this->Config['PluginVar']['FaceSwitch']){
			$GetData['face'] = strpos($GetData['face'],'http') !== false ? $GetData['face'] : $_G['siteurl'].$GetData['face'];
		}
		//星座-生肖
		$Birthext = $this->Birthext($GetData['birth']);
		$GetData['constellation'] = intval($Birthext['constellation']);
		$GetData['animal'] = intval($Birthext['animal']);
		$GetData['age'] = date('Y') - date('Y',$GetData['birth']);
		if($UserInfo){
			$UserInfo['param']['wx'] = $Param['wx'];
			$UserInfo['param']['qq'] = $Param['qq'];
			$UserInfo['param']['monologue'] = $Param['monologue'];
			$GetData['param'] = serialize($UserInfo['param']);
			$GetData['updateline'] = time();
			if(DB::update($this->TableMember,$GetData,'uid = '.$GetData['uid'])){
				$Data['Msg'] = urlencode($this->Config['LangVar']['UserInfoSuccess']);
				$Data['State'] = 200;
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UserInfoFail']);
			}
		}else{
			$HeMatchmakerUserInfo = $this->GetMatchmakerUserInfo($Get['mid']);
			$GetData['mid'] = $HeMatchmakerUserInfo ? intval($Get['mid']) : '';
			$GetData['mobile_display'] = $this->Config['PluginVar']['UserMobileWxSwitch'] ? 0 : 1;
			$GetData['wx_display'] = $this->Config['PluginVar']['UserMobileWxSwitch'] ? 0 : 1;
			$GetData['dateline'] = $GetData['updateline'] = time();
			$GetData['source'] = App ? 1 : 2;
			if(DB::insert($this->TableMember,$GetData)){
				$Data['Msg'] = urlencode($this->Config['LangVar']['UserInfoSuccess'].'<br>'.$this->Config['LangVar']['GuideCondition']);
				$Data['State'] = 201;
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UserInfoFail']);
			}
		}
		//消息通知
		if($UserInfo['examine'] != 2){
			foreach($this->MatchmakerAdminUidsList as $Key => $Val) {
				notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
					'url'=>$this->Config['HeUserUrl'].$GetData['uid'],
					'msg'=>str_replace(array('{Uid}','{Username}','{Name}'),array($GetData['uid'],$GetData['username'],$GetData['name']),$this->Config['LangVar']['DPush'])
				),1);//系统通知
				if($Config['PluginVar']['AppType'] == 1){//马甲助手推送
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['HeUserUrl'].$GetData['uid'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=> '',
								"val"=> diconv(str_replace(array('{Uid}','{Username}','{Name}'),array($GetData['uid'],$GetData['username'],$GetData['name']),$this->Config['LangVar']['DPush']),CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}

			if($Config['PluginVar']['AppType'] == 2){//千帆模板消息推送
				$PushData['Uid'] = implode(',',$this->MatchmakerAdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv(str_replace(array('{Uid}','{Username}','{Name}'),array($GetData['uid'],$GetData['username'],$GetData['name']),$this->Config['LangVar']['DPush']),CHARSET,'UTF-8'),
					'url'=>$this->Config['HeUserUrl'].$GetData['uid']
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
		}
		//消息通知End
		return $Data;
	}
	/* 发送验证码 */
	public function GetAjaxSendOut($Mobile){
		global $_G,$Config;
		$Data = array();
		$Mobile = addslashes(strip_tags(trim($Mobile)));
		//手机号码判断
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		if(!$Mobile){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobilePlaceholder']);
			return $Data;
		}else if(!preg_match($IsMob,$Mobile)){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
			return $Data;
		}
		
		if($CheckProfileData = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where mobile = '.$Mobile.' and uid != '.intval($_G['uid']))){//号码是否存在
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileRepeatErr']);
			return $Data;
		}

		$CheckSendSmsLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSendSmsLog).' where state = 200 and cache_dateline > '.time().' and uid = '.intval($_G['uid']).' and mobile = '.$Mobile.' and sms_type = 1 order by id desc');//是否恶意发短信

		if($CheckSendSmsLog){
			$Data['Msg'] = urlencode($this->Config['LangVar']['SendOutOk']);
			$Data['State'] = 200;
			return $Data;
		}

		@require_once libfile('class/short_message','plugin/fn_assembly');
		if($Config['PluginVar']['ShortMessageType'] == 1){
			$TemplateCode = $this->Config['PluginVar']['AliCodeId'];
			$TemplateParam = array('code'=>rand(100000,999999));
		}else if($Config['PluginVar']['ShortMessageType'] == 2){
			$Code = rand(100000,999999);
			$TemplateCode = str_replace(array('{Mobile}','{Code}'),array($Config['PluginVar']['MobileAreaCode'].$Mobile,$Code),$this->Config['LangVar']['TemplateCode']);
			$TemplateParam = array('code'=>$Code);
		}
		$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$Mobile,$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$_G['uid'],$_G['username'],'fn_xiangqin',1);

		if($SendSms['State'] == 200){
			$Data['Msg'] = urlencode($this->Config['LangVar']['SendOutOk']);
			$Data['State'] = 200;
		}else{
			$Data['Msg'] = urlencode($SendSms['Msg']);
		}
		return $Data;
	}
	/* 择偶条件 */
	public function GetAjaxCondition($Get){
		global $_G;
		$Get = StrToGBK($Get);
		$UserInfo = $this->GetUserInfo($_G['uid']);
		$GetData['uid'] = intval($_G['uid']);
		$GetData['c_min_age'] = intval($Get['c_min_age']);
		$GetData['c_max_age'] = intval($Get['c_max_age']);
		$GetData['c_min_height'] = intval($Get['c_min_height']);
		$GetData['c_max_height'] = intval($Get['c_max_height']);
		$GetData['c_month_income'] = intval($Get['c_month_income']);
		$GetData['c_education'] = intval($Get['c_education']);
		$GetData['c_marriage'] = intval($Get['c_marriage']);
		$GetData['c_ethnic'] = intval($Get['c_ethnic']);
		$GetData['c_house'] = intval($Get['c_house']);
		$GetData['c_vehicle'] = intval($Get['c_vehicle']);
		$GetData['c_shape'] = intval($Get['c_shape']);
		$GetData['c_want_child'] = intval($Get['c_want_child']);
		$GetData['c_smoke'] = intval($Get['c_smoke']);
		$GetData['c_drink'] = intval($Get['c_drink']);
		$GetData['c_occupation'] = censor(addslashes(strip_tags($Get['c_occupation'])));
		
		$FieldArray = array('c_min_age','c_min_height','c_month_income','c_education','c_marriage','c_ethnic','c_house','c_vehicle','c_shape','c_want_child','c_smoke','c_drink','c_occupation');
		$I = 0;
		foreach($FieldArray as $Key => $Val) {
			if($GetData[$Val]){
				$I++;
			}
		}
		if($I < 5){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ConditionNumErr']);
			return $Data;
		}

		if($GetData['c_min_age'] && $GetData['c_min_age'] > $GetData['c_max_age']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AgeErr']);
			return $Data;
		}

		if($GetData['c_min_height'] && $GetData['c_min_height'] > $GetData['c_max_height']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['HeightErr']);
			return $Data;
		}

		
		$UserCondition = DB::fetch_first('SELECT * FROM '.DB::table($this->TableCondition).' where uid = '.$GetData['uid']);
		if($UserCondition){
			$GetData['updateline'] = time();
			if(DB::update($this->TableCondition,$GetData,'uid = '.$GetData['uid'])){
				$Data['Msg'] = urlencode($this->Config['LangVar']['UserConditionSuccess']);
				$Data['State'] = 200;
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UserConditionFail']);
			}
		}else{
			$GetData['dateline'] = time();
			if(DB::insert($this->TableCondition,$GetData)){
				if(empty($UserInfo['param']['album'])){
					$Data['Msg'] = $UserInfo['sex'] == 1 ? urlencode($this->Config['LangVar']['UserConditionSuccess'].'<br>'.$this->Config['LangVar']['AlbumSex1201']) : urlencode($this->Config['LangVar']['UserConditionSuccess'].'<br>'.$this->Config['LangVar']['AlbumSex2201']);
					$Data['State'] = 201;
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['UserConditionSuccess']);
					$Data['State'] = 200;
				}
				
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UserConditionFail']);
			}
		}
		return $Data;
	}
	/* 保存相册 */
	public function GetAjaxAlbum($Get){
		global $_G;
		$Get = StrToGBK($Get);
		$UserInfo = $this->GetUserInfo($_G['uid']);
		if(!$UserInfo){//未编辑基本资料
			$Data['Msg'] = urlencode($this->Config['LangVar']['BasicInformationNull']);
			$Data['State'] = 201;
			return $Data;
		}
		if(is_array($Get['imgs']) && isset($Get['imgs'])){
			$UserInfo['param']['album'] = array_filter($Get['imgs']);
		}else if($Get['album']){
			$UserInfo['param']['album'] = array_filter(explode(',',$Get['album']));
		}else{
			$UserInfo['param']['album'] = '';
		}/*else{//没有上传相册
			$Data['Msg'] = urlencode($this->Config['LangVar']['AlbumErr']);
			return $Data;
		}*/
		foreach($UserInfo['param']['album'] as $Key => $Val) {
			$UserInfo['param']['album'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		if(!$UserInfo['vip']){//非VIP张数限制
			$UserInfo['param']['album'] = array_slice($UserInfo['param']['album'],0,$this->Config['PluginVar']['AlbumNum']);
		}

		$GetData['param'] = serialize($UserInfo['param']);

		if(DB::update($this->TableMember,$GetData,'uid = '.intval($UserInfo['uid']))){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AlbumSuccess']);
			$Data['State'] = 200;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AlbumFail']);
		}
		return $Data;
	}
	/* 举报用户 */
	public function GetAjaxReport($Get){
		global $_G,$Config;
		$Get = StrToGBK($Get);
		$GetData['uid'] = intval($_G['uid']);
		$GetData['username'] = addslashes(strip_tags($_G['username']));
		$GetData['ip'] = addslashes(strip_tags($_G['clientip']));
		$GetData['report_uid'] = intval($Get['report_uid']);
		$GetData['content'] = censor(addslashes(strip_tags($Get['content'])));
		$GetData['state'] = 0;
		$GetData['dateline'] = time();
		if($GetData['uid'] == $GetData['report_uid']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportOwnErr']);
			return $Data;
		}
		$HeUserInfo = $this->GetUserInfo($GetData['report_uid']);
		$GetData['mid'] = intval($HeUserInfo['mid']);
		if(!$HeUserInfo){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoHeUserInfoErr']);
			return $Data;
		}

		if(!$GetData['content']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportContentErr']);
			return $Data;
		}
		if(DB::insert($this->TableReport,$GetData)){
			//消息通知
			foreach($this->MatchmakerAdminUidsList as $Key => $Val) {
				notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
					'url'=>$this->Config['HeUserUrl'].$GetData['report_uid'],
					'msg'=>$this->Config['LangVar']['ReportNoticeMsg'].$GetData['content']
				),1);//系统通知
				if($Config['PluginVar']['AppType'] == 1){//马甲助手推送
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['HeUserUrl'].$GetData['report_uid'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=> '',
								"val"=> diconv($this->Config['LangVar']['ReportNoticeMsg'].$GetData['content'],CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}
			if($Config['PluginVar']['AppType'] == 2){//千帆模板消息推送
				$PushData['Uid'] = implode(',',$this->MatchmakerAdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv($this->Config['LangVar']['ReportNoticeMsg'].$GetData['content'],CHARSET,'UTF-8'),
					'url'=>$this->Config['HeUserUrl'].$GetData['report_uid']
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
			//消息通知End
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportOk']);
			$Data['State'] = 200;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportErr']);
		}
		return $Data;
	}

	/* 收藏 */
	public function GetAjaxCollect($CollectUid){
		global $_G,$Config;
		$GetData['uid'] = intval($_G['uid']);
		$GetData['collect_uid'] = intval($CollectUid);
		$GetData['dateline'] = time();
		
		if($GetData['uid'] == $GetData['collect_uid']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CollectMyErr']);
			return $Data;
		}

		$Collect = DB::fetch_first('SELECT * FROM '.DB::table($this->TableCollect).' where uid = '.$GetData['uid'].' and collect_uid = '.$GetData['collect_uid']);

		if($Collect){
			DB::delete($this->TableCollect,'uid ='.$GetData['uid'].' and collect_uid = '.$GetData['collect_uid']);
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['CollectCancel']);
		}else{
			if(DB::insert($this->TableCollect,$GetData)){
				//消息通知
				$UserInfo = $this->GetUserInfo($_G['uid']);
				notification_add($GetData['collect_uid'],'system','<a href="{url}">{msg}</a>',array(
					'url'=> $this->Config['UserUrl'],
					'msg'=> str_replace('{Sex}',$this->Config['LangVar']['SexTextArray'][$UserInfo['sex']],$this->Config['LangVar']['CollectNoticeMsg'])
				),1);//系统通知
				if($Config['PluginVar']['AppType'] == 1){//马甲助手推送
					$PushData['Uid'] = $GetData['collect_uid'];
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['CollectNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['CollectNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['UserUrl'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=> '',
								"val"=> diconv(str_replace('{Sex}',$this->Config['LangVar']['SexTextArray'][$UserInfo['sex']],$this->Config['LangVar']['CollectNoticeMsg']),CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}else if($Config['PluginVar']['AppType'] == 2){//千帆模板消息推送
					$PushData['Uid'] = $GetData['collect_uid'];
					$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['CollectNotice'])),CHARSET,'UTF-8');
					$PushData['Content'] = array(
						'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['CollectNotice'])),CHARSET,'UTF-8'),
						'date'=>date('Y-m-d H:i:s'),
						'setting'=>array(),
						'content' => diconv(str_replace('{Sex}',$this->Config['LangVar']['SexTextArray'][$UserInfo['sex']],$this->Config['LangVar']['CollectNoticeMsg']),CHARSET,'UTF-8'),
						'url'=>$this->Config['UserUrl']
					);
					$this->QHApp->GetMessagesTemplate($PushData);
				}
				//消息通知End
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['CollectOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['CollectErr']);
			}
		}
		return $Data;
	}

	/* 我的收藏InfoId */
	public function GetFirstMyCollectArray(){
		global $_G;
		$Uid = intval($_G['uid']);
		$FetchSql = 'SELECT collect_uid FROM '.DB::table($this->TableCollect).' where uid = '.$Uid.' order by id desc';
		$MyCollectArray =  DB::fetch_all($FetchSql);
		foreach ($MyCollectArray as $key => $val) {
			$MyCollectIdArray[] = $MyCollectArray[$key]['collect_uid'];
		}
		return $MyCollectIdArray;
	}
	/* 收藏列表 */
	public function GetCollecList($Uid,$Field){
		$ToField = $Field == 'uid' ? 'collect_uid' : 'uid';
		$FetchSql = 'SELECT M.* FROM '.DB::table($this->TableCollect).' C LEFT JOIN `'.DB::table($this->TableMember).'` M on M.uid = C.'.$ToField.' WHERE C.'.$Field.' = '.intval($Uid).' order by C.dateline desc';
		$Results = $this->ListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}
	/* 收藏总数 */
	public function GetCollecCount($Uid,$Field){
		$CollecCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableCollect).' where '.$Field.' = '.intval($Uid));
		return $CollecCount;
	}

	/* 浏览列表 */
	public function GetAjaxUserViewLogList($Uid,$Field,$Page){

		$ToField = $Field == 'uid' ? 'view_uid' : 'uid';
		
		$Page = $Page ? intval($Page) : 0;

		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$FetchSql = 'SELECT M.* FROM '.DB::table($this->TableViewLog).' C LEFT JOIN `'.DB::table($this->TableMember).'` M on M.uid = C.'.$ToField.' WHERE C.'.$Field.' = '.intval($Uid).' order by C.dateline desc '.$Limit;
		$Results = $this->ListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}

	/* 添加浏览记录 */
	public function InsertViewLog($Uid){
		global $_G;
		$ViewLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableViewLog).' where view_uid = '.intval($Uid).' and uid = '.intval($_G['uid']));
		if($ViewLog){
			DB::update($this->TableViewLog,array('updateline'=>time()),'id = '.intval($ViewLog['id']));
		}else{
			if($Uid != $_G['uid']){
				$Data['view_uid'] = intval($Uid);
				$Data['uid'] = intval($_G['uid']);
				$Data['dateline'] = $Data['updateline'] = time();
				DB::insert($this->TableViewLog,$Data);
			}	
		}
	}

	/* 我的收藏查看联系方式记录 */
	public function GetFirstMySeeArray(){
		global $_G;
		
		$FetchSql = 'SELECT view_uid FROM '.DB::table($this->TableSeeLog).' where uid = '.intval($_G['uid']).( $this->Config['PluginVar']['SeeDueTime'] ? ' and updateline >= '.strtotime("-".intval($this->Config['PluginVar']['SeeDueTime'])." day",time()) : '').' order by id desc';
		
		$MySeeArray =  DB::fetch_all($FetchSql);
		foreach ($MySeeArray as $key => $val) {
			$MySeeIdArray[] = $MySeeArray[$key]['view_uid'];
		}
		return $MySeeIdArray;
	}

	/* 添加查看联系方式记录 */
	public function GetAjaxInsertSeeLog($Uid){
		global $_G;
		
		$UserInfo = $this->GetUserInfo($_G['uid']);
		
		if(!$UserInfo['vip']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['SeeErr']);
			return $Data;
		}

		if(!$UserInfo['see_line']){
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['LeftoverSeeLineErr']);
			return $Data;
		}

		$HeUserInfo = $this->GetUserInfo($Uid);
		$SeeLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSeeLog).' where view_uid = '.intval($Uid).' and uid = '.intval($_G['uid']));
		if($SeeLog){
			if(DB::update($this->TableSeeLog,array('updateline'=>time()),'id = '.intval($SeeLog['id']))){
				$Data['State'] = 200;
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['SeeErr']);
			}
		}else{
			if($Uid != $_G['uid']){
				$UpData['view_uid'] = intval($Uid);
				$UpData['uid'] = intval($_G['uid']);
				$UpData['dateline'] = $UpData['updateline'] = time();
				if(DB::insert($this->TableSeeLog,$UpData)){
					$Data['State'] = 200;
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['SeeErr']);
				}
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['SeeErr']);

			}
		}
		if($Data['State'] == 200){
			$Data['mobile'] = $HeUserInfo['mobile'];
			$Data['wx'] = $HeUserInfo['param']['wx'];
			$Data['qq'] = $HeUserInfo['param']['qq'];
			DB::query("UPDATE ".DB::table($this->TableMember)." SET see_line = see_line-1 WHERE uid=".intval($_G['uid']));
		}
		return $Data;
	}

	/* 查看总数 */
	public function GetViewLogCount($Uid,$Field){
		$CollecCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableViewLog).' where '.$Field.' = '.intval($Uid));
		return $CollecCount;
	}

	/* 提交实名认证 */
	public function GetAjaxUserAuthentication($Get){
		global $_G,$Config;
		$Get = StrToGBK($Get);
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['examine'] = 0;
		
		foreach($Get['new_just'] as $Key => $Val) {
			$Get['new_just'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($Get['new_back'] as $Key => $Val) {
			$Get['new_back'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach($Get['new_hold'] as $Key => $Val) {
			$Get['new_hold'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$UpData['just'] = addslashes(strip_tags($Get['new_just'][0]));
		$UpData['back'] = addslashes(strip_tags($Get['new_back'][0]));
		$UpData['hold'] = addslashes(strip_tags($Get['new_hold'][0]));
		$UpData['full_name'] = addslashes(strip_tags($Get['full_name']));
		$UpData['id_number'] = addslashes(strip_tags($Get['id_number']));
		$UpData['mobile'] = addslashes(strip_tags($Get['mobile']));
		
		if($this->Config['PluginVar']['AuthenticationApiSwitch']){
			$this->Config['LangVar']['AuthenticationOk'] = $this->Config['LangVar']['AuthenticationApiOk'];
			if(!$UpData['full_name']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['RealNameTips']);
				return $Data;
			}

			if(!$UpData['id_number']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['IDNumberTips']);
				return $Data;
			}

			//手机号码判断
			$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
			if(!$UpData['mobile']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['PhoneNumberTips']);
				return $Data;
			}else if(!preg_match($IsMob,$UpData['mobile'])){
				$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
				return $Data;
			}
			
			//接口认证
			$headers = array();
			array_push($headers, "Authorization:APPCODE " . $this->Config['PluginVar']['AuthenticationCode']);
			$url = 'https://phonecheck.market.alicloudapi.com/phoneAuthentication';
			$Res = json_decode(CurlPost($url,array('idNo'=>$UpData['id_number'],'name'=>diconv($UpData['full_name'],CHARSET,'UTF-8'),'phoneNo'=>$UpData['mobile']),$headers),true);

			if($Res['respCode'] === '0008'){
				$Data['Msg'] = urlencode($this->Config['LangVar']['AgentVerifyAddErr0008']);
				return $Data;
			}else if($Res['respCode'] !== '0000'){
				$Data['Msg'] = urlencode(diconv($Res['respMessage'],'UTF-8',CHARSET));
				return $Data;
			}else{
				$UpData['examine'] = 1;
			}

		}else{
			if(!$UpData['just']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['AuthenticationJustErr']);
				return $Data;
			}

			if(!$UpData['back']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['AuthenticationBackErr']);
				return $Data;
			}

			if(!$UpData['hold']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['AuthenticationHoldErr']);
				return $Data;
			}
		}
		
		$Authentication = DB::fetch_first('SELECT * FROM '.DB::table($this->TableAuthentication).' where uid = '.$UpData['uid']);
		
		if($Authentication){
			$UpData['updateline'] = time();
			if(DB::update($this->TableAuthentication,$UpData,'uid = '.intval($Authentication['uid']))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['AuthenticationOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['AuthenticationErr']);
			}
		}else{
			$UpData['dateline'] = $UpData['updateline'] = time();
			if(DB::insert($this->TableAuthentication,$UpData)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['AuthenticationOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['AuthenticationErr']);
			}
		}
		
		//消息通知
		if(!$this->Config['PluginVar']['AuthenticationApiSwitch']){
			$UserInfo = $this->GetUserInfo($UpData['uid']);
			foreach($this->MatchmakerAdminUidsList as $Key => $Val) {
				notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
					'url'=>$this->Config['HeUserUrl'].$UpData['uid'],
					'msg'=>str_replace(array('{Uid}','{Username}','{Name}'),array($UpData['uid'],$UpData['username'],$UserInfo['name']),$this->Config['LangVar']['DPushAuthentication'])
				),1);//系统通知
				if($Config['PluginVar']['AppType'] == 1){//马甲助手推送
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['HeUserUrl'].$UpData['uid'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=> '',
								"val"=> diconv(str_replace(array('{Uid}','{Username}','{Name}'),array($UpData['uid'],$UpData['username'],$UserInfo['name']),$this->Config['LangVar']['DPushAuthentication']),CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}

			if($Config['PluginVar']['AppType'] == 2){//千帆模板消息推送
				$PushData['Uid'] = implode(',',$this->MatchmakerAdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv(str_replace(array('{Uid}','{Username}','{Name}'),array($UpData['uid'],$UpData['username'],$UserInfo['name']),$this->Config['LangVar']['DPushAuthentication']),CHARSET,'UTF-8'),
					'url'=>$this->Config['HeUserUrl'].$UpData['uid']
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
		}
		//消息通知End
		
		return $Data;


	}

	/* 到期VIP消息推送 */
	public function GetExpireVipPush($Uid){
		global $_G,$Config;
		$UserInfo = $this->GetUserInfo($Uid);
		//消息通知
		$Url = $this->Config['UserUrl'];
		$Msg = str_replace(array('{name}'),array($UserInfo['name']),$this->Config['PluginVar']['ExpireVip']);
		notification_add($Uid,'system','<a href="{url}">{msg}</a>',array(
			'url'=>$Url,
			'msg'=>$Msg
		),1);//系统通知
		if($Config['PluginVar']['AppType'] == 1){//马甲助手推送
			$PushData['Uid'] = $Uid;
			$PushData['Type'] = 'pictemp';
			$PushData['Content'] = array(
				"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NoticePush'])),CHARSET,'UTF-8'),
				"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NoticePush'])),CHARSET,'UTF-8'),
				"link"=> $Url,
				"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
				"extra_info"=>array(
					array(
						"key"=> '',
						"val"=> diconv($Msg,CHARSET,'UTF-8')
					)
				)
			);
			$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
		}else if($Config['PluginVar']['AppType'] == 2){//千帆模板消息推送
			$PushData['Uid'] = $Uid;
			$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['NoticePush'])),CHARSET,'UTF-8');
			$PushData['Content'] = array(
				'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['NoticePush'])),CHARSET,'UTF-8'),
				'date'=>date('Y-m-d H:i:s'),
				'setting'=>array(),
				'content' => diconv($Msg,CHARSET,'UTF-8'),
				'url'=>$Url
			);
			$this->QHApp->GetMessagesTemplate($PushData);
		}
		//消息通知End
		//短信通知
		if($this->Config['PluginVar']['ExpireVipSmsSwitch']){
			@require_once libfile('class/short_message','plugin/fn_assembly');
			if($Config['PluginVar']['ShortMessageType'] == 1){
				$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
				$TemplateParam = array('remark'=>$Msg);
			}else if($Config['PluginVar']['ShortMessageType'] == 2){
				$TemplateCode = str_replace(array('{Msg}'),array($Msg),$this->Config['PluginVar']['ChanyooNotice']);
				$TemplateParam = array();
			}
			$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$UserInfo['mobile'],$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$UserInfo['uid'],$UserInfo['username'],'fn_xiangqin',2);
		}
		//短信通知End
		DB::update($this->TableMember,array('expire_vip_push'=>1),'uid = '.intval($Uid));
		return true;
	}
	/* 封号解封消息推送 */
	public function GetSealPush($Uid,$Val){
		global $_G,$Config;
		$UserInfo = $this->GetUserInfo($Uid);
		//消息通知
		$Url = $this->Config['UserUrl'];
		$Msg = str_replace(array('{name}','{time}'),array($UserInfo['name'],date('H:i:s')),$this->Config['LangVar']['SealPush'][$Val]);
		notification_add($Uid,'system','<a href="{url}">{msg}</a>',array(
			'url'=>$Url,
			'msg'=>$Msg
		),1);//系统通知
		if($Config['PluginVar']['AppType'] == 1){//马甲助手推送
			$PushData['Uid'] = $Uid;
			$PushData['Type'] = 'pictemp';
			$PushData['Content'] = array(
				"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NoticePush'])),CHARSET,'UTF-8'),
				"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NoticePush'])),CHARSET,'UTF-8'),
				"link"=> $Url,
				"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
				"extra_info"=>array(
					array(
						"key"=> '',
						"val"=> diconv($Msg,CHARSET,'UTF-8')
					)
				)
			);
			$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
		}else if($Config['PluginVar']['AppType'] == 2){//千帆模板消息推送
			$PushData['Uid'] = $Uid;
			$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['NoticePush'])),CHARSET,'UTF-8');
			$PushData['Content'] = array(
				'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['NoticePush'])),CHARSET,'UTF-8'),
				'date'=>date('Y-m-d H:i:s'),
				'setting'=>array(),
				'content' => diconv($Msg,CHARSET,'UTF-8'),
				'url'=>$Url
			);
			$this->QHApp->GetMessagesTemplate($PushData);
		}
		//消息通知End
		//短信通知
		if($this->Config['PluginVar']['ExamineSealSmsSwitch']){
			@require_once libfile('class/short_message','plugin/fn_assembly');
			if($Config['PluginVar']['ShortMessageType'] == 1){
				$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
				$TemplateParam = array('remark'=>$Msg);
			}else if($Config['PluginVar']['ShortMessageType'] == 2){
				$TemplateCode = str_replace(array('{Msg}'),array($Msg),$this->Config['PluginVar']['ChanyooNotice']);
				$TemplateParam = array();
			}
			$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$UserInfo['mobile'],$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$UserInfo['uid'],$UserInfo['username'],'fn_xiangqin',2);
		}
		//短信通知End
		return true;
	}

	/* 实名认证审核推送 */
	public function GetAuthenticationExaminePush($Uid,$Val,$Refusal=null){
		global $_G,$Config;
		$UserInfo = $this->GetUserInfo($Uid);
		//消息通知
		if($Val == 1){
			$Url = $this->Config['UserUrl'];
			$Msg = $this->Config['LangVar']['AuthenticatioExaminePush1'];
		}else if($Val == 2){
			$Url = $this->Config['UserUrl'];
			$Msg = $this->Config['LangVar']['AuthenticatioExaminePush2'];
		}
		$Msg = str_replace(array('{name}','{time}'),array($UserInfo['name'],date('H:i:s')),$Msg);
		notification_add($Uid,'system','<a href="{url}">{msg}</a>',array(
			'url'=>$Url,
			'msg'=>$Msg
		),1);//系统通知
		if($Config['PluginVar']['AppType'] == 1){//马甲助手推送
			$PushData['Uid'] = $Uid;
			$PushData['Type'] = 'pictemp';
			$PushData['Content'] = array(
				"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
				"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
				"link"=> $Url,
				"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
				"extra_info"=>array(
					array(
						"key"=> '',
						"val"=> diconv($Msg,CHARSET,'UTF-8')
					)
				)
			);
			$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
		}else if($Config['PluginVar']['AppType'] == 2){//千帆模板消息推送
			$PushData['Uid'] = $Uid;
			$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
			$PushData['Content'] = array(
				'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
				'date'=>date('Y-m-d H:i:s'),
				'setting'=>array(),
				'content' => diconv($Msg,CHARSET,'UTF-8'),
				'url'=>$Url
			);
			$this->QHApp->GetMessagesTemplate($PushData);
		}
		//消息通知End

		//短信通知
		if($this->Config['PluginVar']['ExamineSealSmsSwitch']){
			@require_once libfile('class/short_message','plugin/fn_assembly');
			if($Config['PluginVar']['ShortMessageType'] == 1){
				$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
				$TemplateParam = array('remark'=>$Msg);
			}else if($Config['PluginVar']['ShortMessageType'] == 2){
				$TemplateCode = str_replace(array('{Msg}'),array($Msg),$this->Config['PluginVar']['ChanyooNotice']);
				$TemplateParam = array();
			}
			$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$UserInfo['mobile'],$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$UserInfo['uid'],$UserInfo['username'],'fn_xiangqin',2);
		}
		//短信通知End

		return true;
	}

	/* 审核推送 */
	public function GetExaminePush($Uid,$Val,$Refusal=null){
		global $_G,$Config;
		$UserInfo = $this->GetUserInfo($Uid);
		//消息通知
		if($Val == 1){
			$Url = $this->Config['Url'];
			$Msg = $this->Config['LangVar']['ExaminePush1'];
		}else if($Val == 3){
			$Url = $this->Config['UserUrl'];
			$Msg = $this->Config['LangVar']['ExaminePush3'];
			//$Msg = $Refusal ? $this->Config['LangVar']['ExaminePush3'].$Refusal : $this->Config['LangVar']['ExaminePush3'].$this->Config['LangVar']['Wu'];
		}
		$Msg = str_replace(array('{name}','{time}'),array($UserInfo['name'],date('H:i:s')),$Msg);
		notification_add($Uid,'system','<a href="{url}">{msg}</a>',array(
			'url'=>$Url,
			'msg'=>$Msg
		),1);//系统通知
		if($Config['PluginVar']['AppType'] == 1){//马甲助手推送
			$PushData['Uid'] = $Uid;
			$PushData['Type'] = 'pictemp';
			$PushData['Content'] = array(
				"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
				"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
				"link"=> $Url,
				"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
				"extra_info"=>array(
					array(
						"key"=> '',
						"val"=> diconv($Msg,CHARSET,'UTF-8')
					)
				)
			);
			$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
		}else if($Config['PluginVar']['AppType'] == 2){//千帆模板消息推送
			$PushData['Uid'] = $Uid;
			$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
			$PushData['Content'] = array(
				'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
				'date'=>date('Y-m-d H:i:s'),
				'setting'=>array(),
				'content' => diconv($Msg,CHARSET,'UTF-8'),
				'url'=>$Url
			);
			$this->QHApp->GetMessagesTemplate($PushData);
		}
		//消息通知End

		//短信通知
		if($this->Config['PluginVar']['ExamineSealSmsSwitch']){
			@require_once libfile('class/short_message','plugin/fn_assembly');
			if($Config['PluginVar']['ShortMessageType'] == 1){
				$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
				$TemplateParam = array('remark'=>$Msg);
			}else if($Config['PluginVar']['ShortMessageType'] == 2){
				$TemplateCode = str_replace(array('{Msg}'),array($Msg),$this->Config['PluginVar']['ChanyooNotice']);
				$TemplateParam = array();
			}
			$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$UserInfo['mobile'],$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$UserInfo['uid'],$UserInfo['username'],'fn_xiangqin',2);
		}
		//短信通知End

		return true;
	}
	/* 管理员修改字段值 */
	public function GetAjaxAdminEditFields($UserId,$Field,$Val,$Refusal=null){
		global $_G;
		//是否红娘
		$HeUserInfo = $this->GetUserInfo($UserId);//用户资料
		if($this->Admin || $HeUserInfo['mid'] == $this->Config['Matchmaker']['uid']){
			require_once libfile('function/admin','plugin/fn_admin');

			if($Field == 'authentication_examine'){

				$UpData['examine'] = intval($Val);
				if($Val == 2){
					$Refusal = StrToGBK($Refusal);
					$UpData['reason'] = addslashes(strip_tags($Refusal));
				}
				$this->GetAuthenticationExaminePush($UserId,$Val,$Refusal);
				
				DB::update($this->TableAuthentication,$UpData,'uid = '.intval($UserId));
			}else{
				if($Field == 'examine' && in_array($Val,array('1','3'))){//审核推送
					$Refusal = StrToGBK($Refusal);
					$HeUserInfo['param']['refusal'] = $Refusal;
					$UpData['param'] = serialize($HeUserInfo['param']);
					$this->GetExaminePush($UserId,$Val,$Refusal);

					GetInsertDoLog('examine_user_xiangqin',$_GET['id'],array('uid'=>$UserId,'examine'=>$Val));//操作记录

				}else if($Field == 'seal'){
					$this->GetSealPush($UserId,$Val);
					GetInsertDoLog('seal_user_xiangqin',$_GET['id'],array('uid'=>$UserId,'seal'=>$Val));//操作记录
				}else if($Field == 'home'){
					GetInsertDoLog('home_user_xiangqin',$_GET['id'],array('uid'=>$UserId,'home'=>$Val));//操作记录
				}else if($Field == 'display'){
					GetInsertDoLog('display_user_xiangqin',$_GET['id'],array('uid'=>$UserId,'display'=>$Val));//操作记录
				}else if($Field == 'lead_line_state'){
					GetInsertDoLog('lead_line_state_xiangqin',$_GET['id'],array('uid'=>$UserId,'lead_line_state'=>$Val));//操作记录
				}
				$UpData[$Field] = intval($Val);
				DB::update($this->TableMember,$UpData,'uid = '.intval($UserId));
			}
			
		}
		$Data['State'] = 200;
		return $Data;
	}
	/* 管理员减少牵线次数 */
	public function GetAjaxAdminReduceLeadLine($UserId){
		global $_G;
		$HeUserInfo = $this->GetUserInfo($UserId);
		if($this->Admin || $HeUserInfo['mid'] == $this->Config['Matchmaker']['uid']){
			require_once libfile('function/admin','plugin/fn_admin');
			if(!$HeUserInfo['lead_line']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['ReduceLeadLineErr']);
			}else{
				DB::query("UPDATE ".DB::table($this->TableMember)." SET lead_line = lead_line-1 WHERE uid=".intval($UserId));
				GetInsertDoLog('lead_line_user_xiangqin',$_GET['id'],array('uid'=>$UserId));//操作记录
				$Data['State'] = 200;
			}
		}
		return $Data;
	}
	/* 用户修改字段值 */
	public function GetAjaxUserEditFields($Field,$Val){
		global $_G;
		$UpData[$Field] = intval($Val);
		DB::update($this->TableMember,$UpData,'uid = '.intval($_G['uid']));
		$Data['State'] = 200;
		return $Data;
	}
	
	/* 支付记录列表 */
	public function GetMyPayLogList(){
		global $_G;
		return DB::fetch_all('SELECT * FROM '.DB::table($this->Pay->TablePayLog).' where uid = '.intval($_G['uid']).' and state = 1');
	}

	/* 创建支付记录 */
	public function GetAjaxPayLog($Get){
		global $_G;
		$Get = StrToGBK($Get);
		$UserInfo = $this->GetUserInfo($_G['uid']);
		$Param['event'] = addslashes(strip_tags($Get['event']));
		if($Param['event'] == 'vip'){
			$Param['vip_time'] = $UserInfo['vip'] ? strtotime("+".intval($Get['day'])." day",$UserInfo['vip_time']) : strtotime("+".intval($Get['day'])." day",time());
			$Param['lead_line'] = $UserInfo['vip'] ? $UserInfo['lead_line'] + $Get['lead_line'] : $Get['lead_line'];
			$Param['see_line'] = $UserInfo['vip'] ? $UserInfo['see_line'] + $Get['see_line'] : $Get['see_line'];
			$Param['vip_title'] = addslashes(strip_tags($Get['vip_title']));
			if($Get['top_date']){
				$Param['top_dateline'] = $UserInfo['settop'] ? strtotime("+".intval($Get['top_date'])." hours",$UserInfo['top_dateline']) : strtotime("+".intval($Get['top_date'])." hours",time());
			}else{
				$Param['top_dateline'] = $UserInfo['top_dateline'];
			}
			$Content = $UserInfo['vip'] ? $this->Config['LangVar']['RenewVipTitle'] : $this->Config['LangVar']['GouVipTitle'];
		}else if($Param['event'] == 'settop'){
			$Param['top_dateline'] = $UserInfo['settop'] ? strtotime("+".intval($Get['day'])." day",$UserInfo['top_dateline']) : strtotime("+".intval($Get['day'])." day",time());
			$Content = $this->Config['LangVar']['SetTopPayTitle'];
		}else if($Param['event'] == 'display'){
			$Param['display_dateline'] = $UserInfo['displaydate'] ? strtotime("+".intval($Get['day'])." day",$UserInfo['display_dateline']) : strtotime("+".intval($Get['day'])." day",time());
			$Content = $this->Config['LangVar']['DisplayPrice'];
		}

		return $this->Pay->PayLogInsert($Get['money'],$Param,$Content,'fn_xiangqin',$UserInfo['mid']);

	}

	//查询马甲订单状态
	public function GetAjaxMagCheckOrder($UnionOrderNum,$OrderId){
		global $_G;
		$OrderStatus = $this->MagApp->GetOrderStatusQuery($UnionOrderNum);
		$PayLog = DB::fetch_first('SELECT * FROM '.DB::table($this->Pay->TablePayLog).' where order_id = '.intval($OrderId).' and uid = '.intval($_G['uid']));
		if($OrderStatus && $PayLog){
			if($PayLog['state'] != 1){
				$UpData = array('state'=>1,'payment_type'=>'app','pay_time'=>time());
				if(DB::update($this->Pay->TablePayLog,$UpData,'order_id = '.intval($OrderId))){
					$PayLog['param'] = unserialize($PayLog['param']);
					if($PayLog['param']['event'] == 'vip'){//购买Vip
						$Member = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where uid = '.$PayLog['uid']);
						$MemBer['param'] = unserialize($MemBer['param']);
						$MemBer['param']['vip_title'] = $PayLog['param']['vip_title'];
						$VipUpData['param'] = serialize($MemBer['param']);
						$VipUpData['vip_time'] = $PayLog['param']['vip_time'];
						$VipUpData['lead_line'] = $PayLog['param']['lead_line'];
						$VipUpData['see_line'] = $PayLog['param']['see_line'];
						$VipUpData['expire_vip_push'] = 0;
						$VipUpData['top_dateline'] = $PayLog['param']['top_dateline'];
						DB::update($this->TableMember,$VipUpData,'uid = '.$PayLog['uid']);
					}else if($PayLog['param']['event'] == 'settop'){//置顶
						$TopUpData['top_dateline'] = $PayLog['param']['top_dateline'];
						DB::update($this->TableMember,$TopUpData,'uid = '.$PayLog['uid']);
					}else if($PayLog['param']['event'] == 'display'){//购买隐藏卡
						$TopUpData['display_dateline'] = $PayLog['param']['display_dateline'];
						DB::update($this->TableMember,$TopUpData,'uid = '.$PayLog['uid']);
					}
				}
			}
			$Data['State'] = 200;
			return $Data;
		}
	}

	//查询千帆订单状态
	public function GetAjaxCheckQFPay($UnionOrderNum,$OrderId){
		global $_G;
		$OrderStatus = $this->QHApp->GetOrdersQuery($UnionOrderNum);
		$PayLog = DB::fetch_first('SELECT * FROM '.DB::table($this->Pay->TablePayLog).' where order_id = '.intval($OrderId).' and uid = '.intval($_G['uid']));
		if($OrderStatus && $PayLog){
			if($PayLog['state'] != 1){
				$UpData = array('state'=>1,'payment_type'=>'app','pay_time'=>time());
				if(DB::update($this->Pay->TablePayLog,$UpData,'order_id = '.intval($OrderId))){
					$PayLog['param'] = unserialize($PayLog['param']);
					if($PayLog['param']['event'] == 'vip'){//购买Vip
						$Member = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where uid = '.$PayLog['uid']);
						$MemBer['param'] = unserialize($MemBer['param']);
						$MemBer['param']['vip_title'] = $PayLog['param']['vip_title'];
						$VipUpData['param'] = serialize($MemBer['param']);
						$VipUpData['vip_time'] = $PayLog['param']['vip_time'];
						$VipUpData['lead_line'] = $PayLog['param']['lead_line'];
						$VipUpData['see_line'] = $PayLog['param']['see_line'];
						$VipUpData['expire_vip_push'] = 0;
						$VipUpData['top_dateline'] = $PayLog['param']['top_dateline'];
						DB::update($this->TableMember,$VipUpData,'uid = '.$PayLog['uid']);
					}else if($PayLog['param']['event'] == 'settop'){//置顶
						$TopUpData['top_dateline'] = $PayLog['param']['top_dateline'];
						DB::update($this->TableMember,$TopUpData,'uid = '.$PayLog['uid']);
					}else if($PayLog['param']['event'] == 'display'){//购买隐藏卡
						$TopUpData['display_dateline'] = $PayLog['param']['display_dateline'];
						DB::update($this->TableMember,$TopUpData,'uid = '.$PayLog['uid']);
					}
				}
			}
			$Data['State'] = 200;
			return $Data;
		}
	}

	/** 
	 判断干支、生肖和星座 
	*/
	public function Birthext($BirthTime){ 
		$Y = Date('Y',$BirthTime); 
		$M = Date('m',$BirthTime); 
		$D = Date('d',$BirthTime); 
		$Num = array(1222,120,219,321,420,521,622,723,823,923,1024,1123,1221);
		for($I = 0; $I < count($Num); $I++){
			if(intval($M.$D) >= $Num[$I] && intval($M.$D) < $Num[$I+1]){
				$Constellation = $I;
				break;
			}else{
				$Constellation = 0;
			}
		}
		$Result['constellation'] = $Constellation + 1;
		$Result['animal'] = (($Y - 4) % 12) + 1;
		return $Result; 
	}

}
$Fn_XiangQin = new Fn_XiangQin;
?>