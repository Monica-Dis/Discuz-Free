<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_fn_love_follow extends  discuz_table{
    
    public function __construct(){
        $this->_table = 'fn_love_follow';
        $this->_pk = 'id';
    }

    public function insert($data, $return_insert_id = false){
        return DB::insert($this->_table, $data, $return_insert_id);
    }

	public function fetch_by_vid($vid,$love_vid){
		global $_G;
        return DB::fetch_first("SELECT * FROM %t WHERE vid = %d and love_vid = %d LIMIT 1", array(
            $this->_table,
            $vid,
			$love_vid
        ));
    }

	public function delete_by_id_vid($id,$vid){
		global $_G;
		return DB::delete($this->_table,array($this->_pk=>$id,'vid'=>$vid));
    }

	public function delete_by_id($id){
		C::t('#fn_xiangqin#fn_love_gift_log')->delete_by_gift_id($id);
		return DB::delete($this->_table,array($this->_pk=>$id));
    }

	public function delete_by_vid($vid){
		DB::delete($this->_table,array('love_vid'=>$vid));
		return DB::delete($this->_table,array('vid'=>$vid));
    }

	public function update_by_count($id,$count = 1){
		return DB::query("update ".DB::table($this->_table)." SET count = count + ".intval($count)." where $this->_pk = ".intval($id));
	}
	
	public function fetch_all_by_list($get = array(),$order = 'dateline',$page = 0, $limit = 3,$count = false){
		
		$where = '';
		
		if($get['vid']){
			$where .= ' and f.vid = '.intval($get['vid']);
		}

		if($get['love_vid']){
			$where .= ' and f.love_vid = '.intval($get['love_vid']);
		}
		
		$where = preg_replace('/and/','where',$where,1);

		$res['list'] = DB::fetch_all("SELECT * FROM ".DB::table($this->_table)." f $where ORDER BY f.".$order." DESC,f.id DESC ".DB::limit(($page * $limit), $limit));

		$res['count'] = $count ? $this->first_by_count($where) : '';
		
		return $res;
	}

	public function first_by_count($where = null){
		return DB::result_first("SELECT COUNT(*) FROM ".DB::table($this->_table)." f ".$where);
	}

	public function first_by_love_vid_count($love_vid){
		return DB::result_first("SELECT COUNT(*) FROM ".DB::table($this->_table)." where love_vid = ".intval($love_vid));
	}

	public function first_by_vid_count($vid){
		return DB::result_first("SELECT COUNT(*) FROM ".DB::table($this->_table)." where vid = ".intval($vid));
	}
}