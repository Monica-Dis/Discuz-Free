<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_fn_love_user_far_single extends  discuz_table{
    
    public function __construct(){
        $this->_table = 'fn_love_user_far_single';
        $this->_pk = 'id';
    }

    public function insert($data, $return_insert_id = false){
        return DB::insert($this->_table, $data, $return_insert_id);
    }

	public function update($data = array(),$id){
		return DB::update($this->_table,$data,array($this->_pk=>$id));
    }

	public function fetch_by_id($id){
        return DB::fetch_first('SELECT * FROM %t WHERE id=%d LIMIT 1', array(
            $this->_table,
            $id
        ));
    }

	public function delete_by_id($id){
		return DB::delete($this->_table,array($this->_pk=>$id));
    }

	public function delete_by_vid($vid){
		return DB::delete($this->_table,array('vid'=>$vid));
    }

	public function fetch_all_by_list($get = array(),$order = 'dateline',$page = 0, $limit = 3,$count = false){
		$where = '';
		
		if($get['mat_id']){
			$where .= ' and l.mat_id = '.intval($get['mat_id']);
		}

		if($get['vid']){
			$where .= ' and l.vid = '.intval($get['vid']);
		}

		if(in_array($get['display'],array('0','1'))){
            $where .= ' and l.display = '.intval($get['display']);
        }

		$where = preg_replace('/and/','where',$where,1);

		$res['list'] = DB::fetch_all("SELECT l.* FROM ".DB::table($this->_table)." l $where ORDER BY l.".$order." DESC,l.id DESC ".DB::limit(($page * $limit), $limit));

		$res['count'] = $count ? $this->first_by_count($where) : '';
		
		return $res;
	}

	public function first_by_count($where = null){
		return DB::result_first("SELECT COUNT(*) FROM ".DB::table($this->_table)." l ".$where);
	}
}