<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_fn_love_activity extends  discuz_table{
    
    public function __construct(){
        $this->_table = 'fn_love_activity';
        $this->_pk = 'id';
    }

    public function insert($data, $return_insert_id = false){
        return DB::insert($this->_table, $data, $return_insert_id);
    }

	public function update($data = array(),$id){
		return DB::update($this->_table,$data,array($this->_pk=>$id));
    }

	public function fetch_by_id($id){
        return DB::fetch_first('SELECT * FROM %t WHERE id=%d LIMIT 1', array(
            $this->_table,
            $id
        ));
    }

	public function delete_by_id($id){
		C::t('#fn_xiangqin#fn_love_activity_signup')->delete_by_aid($id);
		return DB::delete($this->_table,array($this->_pk=>$id));
    }
	
	public function fetch_all_by_list($get = array(),$order = 'dateline',$page = 0, $limit = 30,$count = false){
		
		$where = '';
		
		if($get['id']){
			$where .= ' and a.id = '.intval($get['id']);
		}

		$where = preg_replace('/and/','where',$where,1);

		$res['list'] = DB::fetch_all("SELECT * FROM ".DB::table($this->_table)." a $where ORDER BY a.".$order." DESC,a.id DESC ".DB::limit(($page * $limit), $limit));

		$res['count'] = $count ? $this->first_by_count($where) : '';
		
		return $res;
	}

	public function first_by_count($where = null){
		return DB::result_first("SELECT COUNT(*) FROM ".DB::table($this->_table)." a ".$where);
	}

	public function update_by_click_count($id,$count = 1){
		return DB::query("update ".DB::table($this->_table)." SET click = click + ".intval($count)." where $this->_pk = ".intval($id));
	}

}