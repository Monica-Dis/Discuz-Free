<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_fn_love_user extends  discuz_table{
    
    public function __construct(){
        $this->_table = 'fn_love_user';
        $this->_pk = 'id';
    }

    public function insert($data = array(), $return_insert_id = false){
        return DB::insert($this->_table, $data, $return_insert_id);
    }

	public function update($data = array(),$id){
		return DB::update($this->_table,$data,array($this->_pk=>$id));
    }

	public function delete_by_id($id){
		$item = $this->fetch_by_id($id);
		C::t('#fn_xiangqin#fn_love_look')->delete_by_vid($id);
		C::t('#fn_xiangqin#fn_love_follow')->delete_by_vid($id);
		C::t('#fn_xiangqin#fn_love_gift_log')->delete_by_vid($id);
		C::t('#fn_xiangqin#fn_love_meal_log')->delete_by_vid($id);
		C::t('#fn_xiangqin#fn_love_verify')->delete_by_vid($id);
		C::t('#fn_xiangqin#fn_love_con_log')->delete_by_vid($id);
		C::t('#fn_xiangqin#fn_love_user_contact_log')->delete_by_vid($id);
		C::t('#fn_xiangqin#fn_love_user_follow_log')->delete_by_vid($id);
		C::t('#fn_xiangqin#fn_love_user_pull_log')->delete_by_vid($id);
		C::t('#fn_xiangqin#fn_love_user_report')->delete_by_vid($id);
		C::t('#fn_xiangqin#fn_love_user_far_single')->delete_by_vid($id);
		C::t('#fn_xiangqin#fn_love_activity_signup')->delete_by_vid($id);
		return DB::delete($this->_table,array($this->_pk=>$id));
    }

	public function fetch_by_id($id){
        $item = DB::fetch_first('SELECT * FROM %t WHERE id=%d LIMIT 1', array(
            $this->_table,
            $id
        ));
		return $item;
    }

	public function fetch_by_uid($uid){
        return DB::fetch_first('SELECT u.*,m.title as group_title,m.icon as group_icon FROM %t u LEFT JOIN `'.DB::table("fn_love_meal").'` m on m.id = u.group_id WHERE uid=%d  LIMIT 1', array(
            $this->_table,
            $uid
        ));
    }

	public function fetch_by_phone_nouid($phone,$uid){
        return DB::fetch_first('SELECT * FROM %t WHERE phone = %s and uid!=%d LIMIT 1', array(
            $this->_table,
            $phone,
            $uid
        ));
    }

	public function fetch_all_by_list($get = array(),$order = 'dateline',$page = 0, $limit = 3,$count = false,$topOrder = false,$expireTime = false){
		global $_G;
        $where = '';
		
		if($get['keyword']){
			$get['keyword'] = str_replace(array('%','_'),array('',''),$get['keyword']);
			$where .= ' and (u.name like(\'%'.addslashes(strip_tags($get['keyword'])).'%\') or u.phone like(\'%'.addslashes(strip_tags($get['keyword'])).'%\') )';
		}

		if(in_array($get['display'],array('0','1'))){
            $where .= ' and u.display = '.intval($get['display']);
        }

		if(in_array($get['hot'],array('0','1'))){
            $where .= ' and u.hot = '.intval($get['hot']);
        }

		if($get['is_vip']){
            $where .= ' and u.due_time >= '.time();
        }

		if(in_array($get['expired'],array('1'))){
			$where .=  ' and u.due_time != \'\' and u.due_time < '.time();
		}

		if($get['audit_state']){
            $where .= ' and u.audit_state = '.intval($get['audit_state']);
        }

		if($get['group_id']){
            $where .= ' and u.group_id = '.intval($get['group_id']);
        }

		if($get['channel']){
            $where .= ' and u.channel = '.intval($get['channel']);
        }

		if($get['vid']){
            $where .= ' and u.id = '.intval($get['vid']);
        }

		if($get['uid']){
            $where .= ' and u.uid = '.intval($get['uid']);
        }

		if($get['user_id']){
            $where .= ' and u.id = '.intval($get['user_id']);
        }

		if($get['open_contact']){
            $where .= ' and u.open_contact = '.intval($get['open_contact']);
        }

		if($get['open_love']){
			if(is_array($get['open_love'])){
				$where .= ' and u.open_love in('.implode(',',$get['open_love']).')';
			}else{
				$where .= ' and u.open_love = '.intval($get['open_love']);
			}
            
        }

		if($get['sex']){
            $where .= ' and u.sex = '.intval($get['sex']);
        }

		if($get['marriage']){
            $where .= ' and u.marriage = '.intval($get['marriage']);
        }

		if($get['month_income']){
            $where .= ' and u.month_income = '.intval($get['month_income']);
        }

		if($get['nation']){
            $where .= ' and u.nation = '.intval($get['nation']);
        }

		if($get['education']){
            $where .= ' and u.education = '.intval($get['education']);
        }

		if(in_array($get['real_verify'],array('0','1'))){
            $where .= ' and u.real_verify = '.intval($get['real_verify']);
        }

		if(in_array($get['offline_verify'],array('0','1'))){
            $where .= ' and u.offline_verify = '.intval($get['offline_verify']);
        }

		if($get['index_real_verify']){
            $where .= ' and u.real_verify = '.intval($get['index_real_verify']);
        }
		
		if(in_array($get['seal'],array('0','1'))){
            $where .= ' and u.seal = '.intval($get['seal']);
        }

		if($get['mat_id']){
            $where .= ' and u.mat_id = '.intval($get['mat_id']);
        }

		if($get['ids']){
            $where .= ' and u.id in('.addslashes(strip_tags($get['ids'])).')';
        }

		if($get['height_min'] && $get['height_max']){
            $where .= ' and u.height >= '.intval($get['height_min']).' and u.height <= '.intval($get['height_max']);
        }else if($get['height_min']){
			 $where .= ' and u.height >= '.intval($get['height_min']);
		}else if($get['height_max']){
			 $where .= ' and u.height <= '.intval($get['height_max']);
		}

		if($get['age_min'] && $get['age_max']){
            $where .= ' and u.age >= '.intval($get['age_min']).' and u.age <= '.intval($get['age_max']);
        }else if($get['age_min']){
			 $where .= ' and u.age >= '.intval($get['age_min']);
		}else if($get['age_max']){
			 $where .= ' and u.age <= '.intval($get['age_max']);
		}

		$order = $order ? 'u.'.$order : 'u.id';
		
		$where = preg_replace('/and/','where',$where,1);
		
		$res['list'] = DB::fetch_all("SELECT u.*,m.title as group_title FROM ".DB::table($this->_table)." u LEFT JOIN `".DB::table("fn_love_meal")."` m on m.id = u.group_id $where ORDER BY ".($topOrder ? "u.topdateline > ".time()." desc," : "" ).$order." desc,u.id desc ".DB::limit(($page * $limit), $limit));
		
		$res['count'] = $count ? $this->first_by_count($where) : '';

		return $res;
    }

	public function first_by_count($where = null){
		return DB::result_first("SELECT COUNT(*) FROM ".DB::table($this->_table)." u ".$where);
	}

	public function update_by_click_count($id,$count = 1){
		return DB::query("update ".DB::table($this->_table)." SET click = click + ".intval($count)." where $this->_pk = ".intval($id));
	}

	public function update_by_count($id,$field = 'currency',$count = 1,$symbol = '+'){
		return DB::query("update ".DB::table($this->_table)." SET $field = $field $symbol ".intval($count)." where $this->_pk = ".intval($id));
	}

}