<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_fn_love_user_contact_log extends  discuz_table{
    
    public function __construct(){
        $this->_table = 'fn_love_user_contact_log';
        $this->_pk = 'id';
    }

    public function insert($data, $return_insert_id = false){
        return DB::insert($this->_table, $data, $return_insert_id);
    }

	public function fetch_by_vid($vid,$love_vid){
        return DB::fetch_first("SELECT * FROM %t WHERE vid = %d and love_vid = %d LIMIT 1", array(
            $this->_table,
            $vid,
			$love_vid
        ));
    }

	public function fetch_by_vid_day($vid){
        return DB::result_first("SELECT COUNT(*) FROM %t WHERE vid = %d and updateline >= ".strtotime(date('Y-m-d'))." and updateline <=".strtotime(date('Y-m-d 23:59:59'))." LIMIT 1", array(
            $this->_table,
            $vid,
			$love_vid
        ));
    }

	public function delete_by_id($id){
		return DB::delete($this->_table,array($this->_pk=>$id));
    }

	public function delete_by_vid($vid){
		DB::delete($this->_table,array('love_vid'=>$vid));
		return DB::delete($this->_table,array('vid'=>$vid));
    }

	public function fetch_all_by_list($get = array(),$order = 'dateline',$page = 0, $limit = 100,$count = false){
		
		$where = '';
		
		if($get['uid']){
			$where .= ' and l.uid = '.intval($get['uid']);
		}

		if($get['vid']){
			$where .= ' and l.vid = '.intval($get['vid']);
		}

		if($get['love_vid']){
			$where .= ' and l.love_vid = '.intval($get['love_vid']);
		}
		
		$where = preg_replace('/and/','where',$where,1);

		$res['list'] = DB::fetch_all("SELECT l.* FROM ".DB::table($this->_table)." l $where ORDER BY l.".$order." DESC,l.id DESC ".DB::limit(($page * $limit), $limit));

		$res['count'] = $count ? $this->first_by_count($where) : '';
		
		return $res;
	}

	public function first_by_count($where = null){
		return DB::result_first("SELECT COUNT(*) FROM ".DB::table($this->_table)." l ".$where);
	}

}