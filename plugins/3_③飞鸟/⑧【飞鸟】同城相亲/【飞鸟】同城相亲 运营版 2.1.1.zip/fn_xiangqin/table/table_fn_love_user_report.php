<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_fn_love_user_report extends  discuz_table{
    
    public function __construct(){
        $this->_table = 'fn_love_user_report';
        $this->_pk = 'id';
    }

    public function insert($data, $return_insert_id = false){
        return DB::insert($this->_table, $data, $return_insert_id);
    }
	
	public function update($data = array(),$id){
		return DB::update($this->_table,$data,array($this->_pk=>$id));
    }

	public function fetch_by_vid($vid,$love_vid){
		global $_G;
        return DB::fetch_first("SELECT * FROM %t WHERE vid = %d and love_vid = %d LIMIT 1", array(
            $this->_table,
            $vid,
			$love_vid
        ));
    }

	public function delete_by_id_vid($id,$vid){
		global $_G;
		return DB::delete($this->_table,array($this->_pk=>$id,'vid'=>$vid));
    }

	public function delete_by_id($id){
		return DB::delete($this->_table,array($this->_pk=>$id));
    }

	public function delete_by_vid($vid){
		DB::delete($this->_table,array('love_vid'=>$vid));
		return DB::delete($this->_table,array('vid'=>$vid));
    }


	public function fetch_all_by_list($get = array(),$order = 'dateline',$page = 0, $limit = 30,$count = false){
		
		$where = '';
		
		if($get['uid']){
			$where .= ' and r.uid = '.intval($get['uid']);
		}

		if($get['vid']){
			$where .= ' and r.vid = '.intval($get['vid']);
		}

		if($get['love_vid']){
			$where .= ' and r.love_vid = '.intval($get['love_vid']);
		}

		if(in_array($get['state'],array('0','1'))){
			$where .= ' and r.state = '.intval($get['state']);
		}

		if($get['type']){
			$where .= ' and r.type = '.intval($get['type']);
		}
		
		$where = preg_replace('/and/','where',$where,1);

		$res['list'] = DB::fetch_all("SELECT * FROM ".DB::table($this->_table)." r $where ORDER BY r.".$order." DESC,r.id DESC ".DB::limit(($page * $limit), $limit));

		$res['count'] = $count ? $this->first_by_count($where) : '';
		
		return $res;
	}

	public function first_by_count($where = null){
		return DB::result_first("SELECT COUNT(*) FROM ".DB::table($this->_table)." r ".$where);
	}

}