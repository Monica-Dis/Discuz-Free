<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_fn_love_activity_signup extends  discuz_table{
    
    public function __construct(){
        $this->_table = 'fn_love_activity_signup';
        $this->_pk = 'id';
    }

    public function insert($data, $return_insert_id = false){
        return DB::insert($this->_table, $data, $return_insert_id);
    }

	public function update($data = array(),$id){
		return DB::update($this->_table,$data,array($this->_pk=>$id));
    }

	public function fetch_by_id($id){
        return DB::fetch_first('SELECT * FROM %t WHERE id=%d LIMIT 1', array(
            $this->_table,
            $id
        ));
    }

	public function fetch_by_vid($vid,$aid){
        return DB::fetch_first("SELECT * FROM %t WHERE vid = %d and aid = %d LIMIT 1", array(
            $this->_table,
            $vid,
			$aid
        ));
    }

	public function delete_by_id($id){
		return DB::delete($this->_table,array($this->_pk=>$id));
    }

	public function delete_by_vid($vid){
		return DB::delete($this->_table,array('vid'=>$vid));
    }

	public function delete_by_aid($vid){
		return DB::delete($this->_table,array('aid'=>$vid));
    }
	
	public function fetch_all_by_list($get = array(),$order = 'dateline',$page = 0, $limit = 30,$count = false){
		
		$where = '';
		
		if($get['id']){
			$where .= ' and s.id = '.intval($get['id']);
		}

		if($get['aid']){
			$where .= ' and s.aid = '.intval($get['aid']);
		}

		if($get['vid']){
			$where .= ' and s.vid = '.intval($get['vid']);
		}

		if($get['uid']){
			$where .= ' and s.uid = '.intval($get['uid']);
		}

		if($get['sex']){
			$where .= ' and s.sex = '.intval($get['sex']);
		}

		if($get['audit_state']){
			$where .= ' and s.audit_state = '.intval($get['audit_state']);
		}

		$where = preg_replace('/and/','where',$where,1);

		$res['list'] = DB::fetch_all("SELECT s.*,u.head_portrait,u.name,u.phone FROM ".DB::table($this->_table)." s LEFT JOIN `".DB::table("fn_love_user")."` u on u.id = s.vid $where ORDER BY s.".$order." DESC,s.id DESC ".DB::limit(($page * $limit), $limit));

		$res['count'] = $count ? $this->first_by_count($where) : '';
		
		return $res;
	}

	public function first_by_count($where = null){
		return DB::result_first("SELECT COUNT(*) FROM ".DB::table($this->_table)." s ".$where);
	}
}