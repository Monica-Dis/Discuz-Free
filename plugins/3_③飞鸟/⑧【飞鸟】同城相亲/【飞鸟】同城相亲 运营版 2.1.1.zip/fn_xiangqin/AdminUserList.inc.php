<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_xiangqin/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_xiangqin/Common.php');
$Operation = in_array($_GET['Operation'], array('Del','Display','Condition','Home','Seal')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&page='.$_GET['page'].'&keyword='.$_GET['keyword'].'&sex='.$_GET['sex'].'&home='.$_GET['home'].'&mobile_display='.$_GET['mobile_display'].'&display='.$_GET['display'].'&examine='.$_GET['examine'].'&seal='.$_GET['seal'].'&order='.$_GET['order'];
$OpUserCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminUser';
$OpConditionCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&formhash='.FORMHASH.'&Operation=Condition&uid=';
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		$OpCpUrl = $MpUrl = $SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		/* ��ѯ���� */
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = in_array($_GET['order'], array('id','top_dateline','click','vip_time')) ? 'M.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'M.id';
		if($_GET['keyword']){
			$Where .= ' and concat(M.username,M.uid,M.name) like(\'%'.addslashes(dhtmlspecialchars(str_replace(array('%','_'),array('',''),$_GET['keyword']))).'%\')';
		}
		if(in_array($_GET['sex'],array('1','2'))){
			$Where .= ' and M.sex = '.intval($_GET['sex']);
		}
		if(in_array($_GET['display'],array('0','1'))){
			$Where .= ' and M.display = '.intval($_GET['display']);
		}
		if(in_array($_GET['seal'],array('0','1'))){
			$Where .= ' and M.seal = '.intval($_GET['seal']);
		}
		if(in_array($_GET['mobile_display'],array('0','1'))){
			$Where .= ' and M.mobile_display = '.intval($_GET['mobile_display']);
		}
		if(in_array($_GET['home'],array('0','1'))){
			$Where .= ' and M.home = '.intval($_GET['home']);
		}


		if(in_array($_GET['examine'],array('1','2','3'))){
			$Where .= ' and M.examine = '.intval($_GET['examine']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ���� */
		$SexSelected = array($_GET['sex']=>' selected');
		$MobileDisplaySelected = array($_GET['mobile_display']=>' selected');
		$DisplaySelected = array($_GET['display']=>' selected');
		$ExamineSelected = array($_GET['examine']=>' selected');
		$SealSelected = array($_GET['seal']=>' selected');
		$HomeSelected = array($_GET['home']=>' selected');
		$OrderSelected = array($_GET['order']=>' selected');
		
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_XiangQin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['SexTitle']}</th><td>
						<select name="sex">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$SexSelected['1']}>{$Fn_XiangQin->Config['LangVar']['SexArray']['1']}</option>
							<option value="2"{$SexSelected['2']}>{$Fn_XiangQin->Config['LangVar']['SexArray']['2']}</option>
						</select>
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['MobileDisplayTitle']}</th><td>
						<select name="mobile_display">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$MobileDisplaySelected['1']}>{$Fn_XiangQin->Config['LangVar']['Yes']}</option>
							<option value="0"{$MobileDisplaySelected['0']}>{$Fn_XiangQin->Config['LangVar']['No']}</option>
						</select>
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['DisplayTitle']}</th><td>
						<select name="display">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$DisplaySelected['1']}>{$Fn_XiangQin->Config['LangVar']['Yes']}</option>
							<option value="0"{$DisplaySelected['0']}>{$Fn_XiangQin->Config['LangVar']['No']}</option>
						</select>
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['ExamineState']}</th><td>
						<select name="examine">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$ExamineSelected['1']}>{$Fn_XiangQin->Config['LangVar']['ExamineArray'][1]}</option>
							<option value="2"{$ExamineSelected['2']}>{$Fn_XiangQin->Config['LangVar']['ExamineArray'][2]}</option>
							<option value="3"{$ExamineSelected['3']}>{$Fn_XiangQin->Config['LangVar']['ExamineArray'][3]}</option>
						</select>
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['SealTitle']}</th><td>
						<select name="seal">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$SealSelected['1']}>{$Fn_XiangQin->Config['LangVar']['Yes']}</option>
							<option value="0"{$SealSelected['0']}>{$Fn_XiangQin->Config['LangVar']['No']}</option>
						</select>
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['HomeTitle']}</th><td>
						<select name="home">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$HomeSelected['1']}>{$Fn_XiangQin->Config['LangVar']['Yes']}</option>
							<option value="0"{$HomeSelected['0']}>{$Fn_XiangQin->Config['LangVar']['No']}</option>
						</select>
						</td>
					</tr>
					<tr>
						
						<th>{$Fn_XiangQin->Config['LangVar']['SortTitle']}</th><td colspan="3"><select name="order">
						<option value="id"{$OrderSelected['id']}>id</option>
						<option value="click"{$OrderSelected['click']}>{$Fn_XiangQin->Config['LangVar']['Click']}</option>
						<option value="top_dateline"{$OrderSelected['top_dateline']}>{$Fn_XiangQin->Config['LangVar']['TopDateline']}</option>
						<option value="vip_time"{$OrderSelected['vip_time']}>VIP{$Fn_XiangQin->Config['LangVar']['UserVipTime']}</option>
						</select>&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_XiangQin->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">&nbsp;&nbsp;<a href="{$OpCpUrl}&Operation=Add"><b>{$Fn_XiangQin->Config['LangVar']['AddScore']}</b></a></td>
						{$CitysHtml}
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */

		/* ģ����� */		
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'Module', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_XiangQin->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
			'ID',
			'Uid/'.$Fn_XiangQin->Config['LangVar']['UserNameTitle'],
			$Fn_XiangQin->Config['LangVar']['NameTitle'],
			$Fn_XiangQin->Config['LangVar']['SexTitle'],
			$Fn_XiangQin->Config['LangVar']['ContactTitle'],
			$Fn_XiangQin->Config['LangVar']['MobileDisplayTitle'],
			$Fn_XiangQin->Config['LangVar']['WxTitle'],
			$Fn_XiangQin->Config['LangVar']['ExamineState'],
			$Fn_XiangQin->Config['LangVar']['DisplayTitle'],
			$Fn_XiangQin->Config['LangVar']['SealTitle'],
			$Fn_XiangQin->Config['LangVar']['HomeTitle'],
			'VIP'.$Fn_XiangQin->Config['LangVar']['UserVipTime'],
			$Fn_XiangQin->Config['LangVar']['TopDateline'],
			$Fn_XiangQin->Config['LangVar']['TimeTitle'].'/'.$Fn_XiangQin->Config['LangVar']['UpdateTime'],
			$Fn_XiangQin->Config['LangVar']['OperationTitle']
		), 'header tbm');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {
			$Module['param'] = unserialize($Module['param']);
			showtablerow('', array(), array(
				'<input type="checkbox" class="checkbox" name="uids[]" value="'.$Module['uid'].'" />'.$Module['id'],
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
				$Module['face'] ? $Module['name'].' <img src="'.$Module['face'].'" height="30">' : $Module['name'],
				$Fn_XiangQin->Config['LangVar']['SexArray'][$Module['sex']],
				$Module['mobile'],
				!$Module['mobile_display'] ? $Fn_XiangQin->Config['LangVar']['No'] : $Fn_XiangQin->Config['LangVar']['Yes'],
				$Module['param']['wx'],
				in_array($Module['examine'],array(2,3)) ? '<span style="color:red">'.$Fn_XiangQin->Config['LangVar']['ExamineArray'][$Module['examine']].'</span>' : $Fn_XiangQin->Config['LangVar']['ExamineArray'][$Module['examine']],
				!$Module['display'] ? '<span style="color:red">'.$Fn_XiangQin->Config['LangVar']['No'].'</span>' : $Fn_XiangQin->Config['LangVar']['Yes'],
				$Module['seal'] ? '<span style="color:red">'.$Fn_XiangQin->Config['LangVar']['Yes'].'</span>' : $Fn_XiangQin->Config['LangVar']['No'],
				$Module['home'] ? '<span style="color:red">'.$Fn_XiangQin->Config['LangVar']['Yes'].'</span>' : $Fn_XiangQin->Config['LangVar']['No'],
				$Module['vip_time'] && $Module['vip_time'] > time() ? date('Y-m-d H:i',$Module['vip_time']).' '.$Module['param']['vip_title'] : '',
				$Module['top_dateline'] && $Module['top_dateline'] > time() ? date('Y-m-d H:i',$Module['top_dateline']) : '',
				date('Y-m-d H:i',$Module['dateline']).'<br>'.date('Y-m-d H:i',$Module['updateline']),
				'<a href="'.$Fn_XiangQin->Config['HeUserUrl'].$Module['uid'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$OpUserCpUrl.'&Operation=Edit&uid='.$Module['uid'].'">'.$Fn_XiangQin->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="javascript:;" onclick="showWindow(\'fn_wx_login_bind'.$Module['uid'].'\', \''.$OpConditionCpUrl.$Module['uid'].'\')">'.$Fn_XiangQin->Config['LangVar']['ConditionTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Display&uid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_XiangQin->Config['LangVar']['DisplayNoTitle'] : $Fn_XiangQin->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Seal&uid='.$Module['id'].'&value='.(!empty($Module['seal']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['seal']) ? $Fn_XiangQin->Config['LangVar']['SealNo'] : $Fn_XiangQin->Config['LangVar']['SealYes']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Home&uid='.$Module['id'].'&value='.(!empty($Module['home']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['home']) ? $Fn_XiangQin->Config['LangVar']['NoHomeTitle'] : $Fn_XiangQin->Config['LangVar']['HomeTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&uid='.$Module['uid'].'&formhash='.FORMHASH.'">'.$Fn_XiangQin->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		/* �ܾ�����Html */
		$RefusalHtml = '<select name="refusal"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option>';
		foreach ($Fn_XiangQin->ExamineTwoList as $Val) {
			$RefusalHtml .= '<option value="'.$Val.'">'.$Val.'</option>';
		}
		$RefusalHtml .= '</select>';
		/* �ܾ�����Html End*/
		showsubmit('Submit','submit','<input name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" type="checkbox"><label for="chkall">'.$Fn_XiangQin->Config['LangVar']['ChkAll'].'</label>&nbsp;&nbsp;<label><input name="optype" value="Del" class="radio" type="radio">'.$Fn_XiangQin->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<label><input name="optype" value="Display" class="radio" type="radio">'.$Fn_XiangQin->Config['LangVar']['DisplayTitle'].'</label>&nbsp;<select name="displaynew"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_XiangQin->Config['LangVar']['Yes'].'</option><option value="0">'.$Fn_XiangQin->Config['LangVar']['No'].'</option></select>&nbsp;&nbsp;<label><input name="optype" value="Examine" class="radio" type="radio">'.$Fn_XiangQin->Config['LangVar']['ExamineState'].'</label>&nbsp;<select name="examinenew"><option value="">'.$Fn_XiangQin->Config['LangVar']['SelectNull'].'</option><option value="1">'.$Fn_XiangQin->Config['LangVar']['ExamineArray'][1].'</option><option value="2">'.$Fn_XiangQin->Config['LangVar']['ExamineArray'][2].'</option><option value="3">'.$Fn_XiangQin->Config['LangVar']['ExamineArray'][3].'</option></select>&nbsp;'.$Fn_XiangQin->Config['LangVar']['RefusalTitle'].'&nbsp;'.$RefusalHtml,'',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		echo '<style>#Module .td25{width:auto;}</style><script> var disallowfloat = "'.$_G['setting']['disallowfloat'].'"</script>';

		/* ģ����� End */
	}else{
		if(isset($_GET['uids']) && is_array($_GET['uids'])){
			if($_GET['optype'] == 'Del'){//ȫɾ
				foreach($_GET['uids'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_XiangQin->TableMember,'uid ='.$Val);
					DB::delete($Fn_XiangQin->TableCondition,'uid ='.$Val);
				}
				cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'Examine' && $_GET['examinenew']){//���״̬
				foreach($_GET['uids'] as $Key => $Val) {
					$Val = intval($Val);
					if($_GET['examinenew'] == 3){//�ܾ�����
						$HeUserInfo = $Fn_XiangQin->GetUserInfo($Val);//�û�����
						$HeUserInfo['param']['refusal'] = $_GET['refusal'];
						$UpData['param'] = serialize($HeUserInfo['param']);
					}
					if(in_array($_GET['examinenew'],array('1','3'))){
						$Fn_XiangQin->GetExaminePush($Val,$_GET['examinenew'],$_GET['refusal']);//��Ϣ����
					}
					$UpData['examine'] = intval($_GET['examinenew']);
					DB::update($Fn_XiangQin->TableMember,$UpData,'uid = '.$Val);
				}
				cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else if($_GET['optype'] == 'Display' && in_array($_GET['displaynew'],array('0','1'))){
				foreach($_GET['uids'] as $Key => $Val) {
					$Val = intval($Val);
					DB::update($Fn_XiangQin->TableMember,array('display'=>intval($_GET['displaynew'])),'uid = '.$Val);
				}
				cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else{
				cpmsg($Fn_XiangQin->Config['LangVar']['OpErr'],'','error');
			}
		}else{
			cpmsg($Fn_XiangQin->Config['LangVar']['OpErr'],'','error');
		}
	}
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['uid']){//ɾ��
	$Uid = intval($_GET['uid']);
	DB::delete($Fn_XiangQin->TableMember,'uid ='.$Uid);
	DB::delete($Fn_XiangQin->TableCondition,'uid ='.$Uid);
	cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'Display' && $_GET['formhash'] == formhash() && $_GET['uid']){//�Ƿ���ʾ
	$Uid = intval($_GET['uid']);
	$Value = intval($_GET['value']);
	$Fn_XiangQin->EditFields($Fn_XiangQin->TableMember,$Uid,'display',$Value);
	cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'Seal' && $_GET['formhash'] == formhash() && $_GET['uid']){//��Ŵ���
	$Uid = intval($_GET['uid']);
	$Value = intval($_GET['value']);
	$Fn_XiangQin->EditFields($Fn_XiangQin->TableMember,$Uid,'seal',$Value);
	cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'Home' && $_GET['formhash'] == formhash() && $_GET['uid']){//�Ƽ���ҳ
	$Uid = intval($_GET['uid']);
	$Value = intval($_GET['value']);
	$Fn_XiangQin->EditFields($Fn_XiangQin->TableMember,$Uid,'home',$Value);
	cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'Condition' && $_GET['formhash'] == formhash() && $_GET['uid']){
	$UserInfo = $Fn_XiangQin->GetUserInfo($_GET['uid']);//�û�����
	include template("fn_xiangqin:admin_condition");
	exit();
}
/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_XiangQin;
	if($Fn_XiangQin->Config['PluginVar']['AppType'] == 2){//ǧ����ȡ�ֻ���
		$FetchSql = 'SELECT P.phone as mobile,M.* FROM '.DB::table($Fn_XiangQin->TableMember).' M LEFT JOIN `'.DB::table('phonebind').'` P on P.uid=M.uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	}else{
		$FetchSql = 'SELECT P.mobile,M.* FROM '.DB::table($Fn_XiangQin->TableMember).' M LEFT JOIN `'.DB::table('common_member_profile').'` P on P.uid=M.uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	}
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TableMember).' M '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>