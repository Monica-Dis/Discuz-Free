<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_xiangqin/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_xiangqin/Common.php');
$Operation = in_array($_GET['Operation'], array('OpValue','AllDel')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&page='.$_GET['page'].'&keyword='.$_GET['keyword'].'&state='.$_GET['state'].'&start_time='.$_GET['start_time'].'&end_time='.$_GET['end_time'];
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'L.order_id';
		if($_GET['keyword']){
			$Where .= ' and concat(L.username,L.uid,L.pubid) like(\'%'.addslashes(dhtmlspecialchars($_GET[keyword])).'%\')';
		}
		if($_GET['start_time']){
			$Where .= ' and L.dateline >= '.strtotime($_GET['start_time']);
		}
		if($_GET['end_time']){
			$Where .= ' and L.dateline <= '.strtotime(date('Y-m-d 23:59:59',strtotime($_GET['end_time'])));
		}
		if(in_array($_GET['state'],array('0','1'))){
			$Where .= ' and L.state = '.intval($_GET['state']);
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ���� */
		$StateSelected = array($_GET['state']=>' selected');
		$DayMoneyCount = GetModulesDayMoneyCount() ? GetModulesDayMoneyCount() : 0;
		$MoneyCount = GetModulesMoneyCount() ? GetModulesMoneyCount() : 0;
		$ScreenMoneyCount = GetModulesScreenMoneyCount($Where) ? GetModulesScreenMoneyCount($Where) : 0;
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_XiangQin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['StartTime']}</th>
						<td><input type="text" class="txt" name="start_time" value="{$_GET[start_time]}" onclick="showcalendar(event, this)" size="10">
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['EndTime']}</th>
						<td><input type="text" class="txt" name="end_time" value="{$_GET[end_time]}" onclick="showcalendar(event, this)" size="10">
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['StateTitle']}</th>
						<td>
						<select name="state">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="0"{$StateSelected['0']}>{$Fn_XiangQin->Config['LangVar']['PayState']['0']}</option>
							<option value="1"{$StateSelected['1']}>{$Fn_XiangQin->Config['LangVar']['PayState']['1']}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_XiangQin->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">&nbsp;&nbsp;{$Fn_XiangQin->Config['LangVar']['ToDayIncomeCount']}<span style="color:red;font-weight:bold;">{$DayMoneyCount}</span>&nbsp;&nbsp;{$Fn_XiangQin->Config['LangVar']['IncomeCount']}<span style="color:red;font-weight:bold;">{$MoneyCount}</span>&nbsp;&nbsp;{$Fn_XiangQin->Config['LangVar']['ScreenPay']}<span style="color:red;font-weight:bold;">{$ScreenMoneyCount}</span>
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		

		/* ģ����� */
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'QiangLouModule', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_XiangQin->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
			'ID',
			$Fn_XiangQin->Config['LangVar']['PubidTitle'],
			'Uid/'.$Fn_XiangQin->Config['LangVar']['UserNameTitle'],
			$Fn_XiangQin->Config['LangVar']['DetailsTitle'],
			$Fn_XiangQin->Config['LangVar']['MoneyTitle'],
			$Fn_XiangQin->Config['LangVar']['StateTitle'],
			$Fn_XiangQin->Config['LangVar']['PaymentType'],
			$Fn_XiangQin->Config['LangVar']['TimeTitle'].'/'.$Fn_XiangQin->Config['LangVar']['UpdateTime']
		), 'header tbm');
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($ModulesList as $Module) {
			$Module['pay_time'] = $Module['pay_time'] ? date('Y-m-d H:i',$Module['pay_time']) : '';
			showtablerow('', array(), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['order_id'].'" />'.$Module['id'],
				$Module['pubid'],
				$Module['uid'].'/'.$Module['username'],
				$Module['content'],
				$Module['money'],
				$Module['state'] ? $Fn_XiangQin->Config['LangVar']['PayState'][$Module['state']]:'<span style="color:red">'.$Fn_XiangQin->Config['LangVar']['PayState'][$Module['state']].'</span>',
				$Module['payment_type'],
				date('Y-m-d H:i',$Module['dateline']).'<br>'.$Module['pay_time']
			));
		}
		showsubmit('Submit','submit','del','<a href="'.$OpCpUrl.'&Operation=AllDel&formhash='.FORMHASH.'" >'.$Fn_XiangQin->Config['LangVar']['OneKeyDel'].'</a>',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_XiangQin->TablePayLog,'order_id ='.$Val);
			}
			cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_XiangQin->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Operation == 'AllDel' && $_GET['formhash'] == formhash()){
	DB::delete($Fn_XiangQin->TablePayLog,'state = 0');
	cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}
/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT M.username as musername,L.* FROM '.DB::table($Fn_XiangQin->TablePayLog).' L LEFT JOIN '.DB::table('common_member').' M on M.uid = L.uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* �������� */
function GetModulesDayMoneyCount(){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT sum(L.money) FROM '.DB::table($Fn_XiangQin->TablePayLog).' L WHERE L.pay_time >= '.strtotime(date('Y-m-d 00:00:00')).' and L.state = 1';
	return DB::result_first($FetchSql);//��������
}
/* ɸѡ���� */
function GetModulesScreenMoneyCount($Where){
	global $Fn_XiangQin;
	if($Where){
		$FetchSql = 'SELECT sum(L.money) FROM '.DB::table($Fn_XiangQin->TablePayLog).' L '.$Where;
		return DB::result_first($FetchSql);//��������
	}
}
/* ͳ�ƽ�� */
function GetModulesMoneyCount(){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT sum(L.money) FROM '.DB::table($Fn_XiangQin->TablePayLog).' L where L.state = 1';
	return DB::result_first($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TablePayLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: dis'.'m.tao'.'bao.com
?>