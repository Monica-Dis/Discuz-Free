<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_xiangqin/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_xiangqin/Common.php');
$Operation = in_array($_GET['Operation'], array('Del')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&page='.$_GET['page'].'&keyword='.$_GET['keyword'].'&state='.$_GET['state'].'&order='.$_GET['order'];

if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		$OpCpUrl = $MpUrl = $SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		/* ��ѯ���� */
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.id';
		if($_GET['keyword']){
			$Where .= ' and concat(L.username,L.uid) like(\'%'.addslashes(dhtmlspecialchars(str_replace(array('%','_'),array('',''),$_GET['keyword']))).'%\')';
		}

		if(in_array($_GET['state'],array('200','201'))){
			$Where .= ' and L.state = '.intval($_GET['state']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ���� */

		$StateSelected = array($_GET['state']=>' selected');

		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_XiangQin->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}">
						</td>
						<th>{$Fn_XiangQin->Config['LangVar']['StateTitle']}</th><td>
						<select name="state">
							<option value="">{$Fn_XiangQin->Config['LangVar']['SelectNull']}</option>
							<option value="200"{$StateSelected['200']}>{$Fn_XiangQin->Config['LangVar']['SendSmsState']['200']}</option>
							<option value="201"{$StateSelected['201']}>{$Fn_XiangQin->Config['LangVar']['SendSmsState']['201']}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_XiangQin->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */

		/* ģ����� */		
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'Module', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_XiangQin->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
			'ID',
			'Uid/'.$Fn_XiangQin->Config['LangVar']['UserNameTitle'],
			$Fn_XiangQin->Config['LangVar']['MobileTitle'],
			$Fn_XiangQin->Config['LangVar']['CodeTitle'],
			$Fn_XiangQin->Config['LangVar']['ApiType'],
			$Fn_XiangQin->Config['LangVar']['StateTitle'],
			$Fn_XiangQin->Config['LangVar']['TimeTitle'],
		), 'header tbm');
		
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		
		foreach ($ModulesList as $Module) {

			showtablerow('', array(), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'],
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
				$Module['mobile'],
				$Module['code'],
				$Fn_XiangQin->Config['LangVar']['ApiTypeArray'][$Module['type']],
				$Module['state'] == 200 ? $Fn_XiangQin->Config['LangVar']['SendSmsState'][$Module['state']] : $Fn_XiangQin->Config['LangVar']['SendSmsState'][$Module['state']].$Module['msg'],
				date('Y-m-d H:i',$Module['dateline'])
			));
		}
		showsubmit('Submit','submit','del','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		showtagfooter('div');
		echo '<style>#Module .td25{width:auto;}</style>';
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_XiangQin->TableSendSmsLog,'id ='.$Val);
			}
			cpmsg($Fn_XiangQin->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_XiangQin->Config['LangVar']['DelErr'],'','error');
		}
	}
}
/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT L.* FROM '.DB::table($Fn_XiangQin->TableSendSmsLog).' L '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_XiangQin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_XiangQin->TableSendSmsLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>