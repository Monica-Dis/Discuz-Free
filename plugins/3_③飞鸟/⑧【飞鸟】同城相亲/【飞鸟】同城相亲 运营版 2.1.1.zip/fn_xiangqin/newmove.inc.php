<?php
/**
 *	[【飞鸟】相亲交友(fn_xiangqin.{modulename})] (C)2016-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2018-4-30 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT.'./source/plugin/fn_xiangqin/config.php');

foreach(DB::fetch_all("SELECT * FROM ".DB::table('fn_xiangqin_matchmaker')) as $k => $v){
	$v['param'] = dunserialize($v['param']);
	$mat['uid'] = $v['uid'];
	$mat['name'] = $v['name'];
	$mat['wx'] = $v['param']['wx'];
	$mat['qrcode'] = $v['param']['wx_qr'];
	$mat['head_portrait'] = $v['param']['face'];
	$mat['display'] = 1;
	$check = C::t('#fn_xiangqin#fn_love_mat')->fetch_by_uid($v['uid']);
	!$check ? C::t('#fn_xiangqin#fn_love_mat')->insert($mat) : '';
}
$i = 0;
$matList =  DB::fetch_all("SELECT * FROM ".DB::table('fn_love_mat')." ORDER BY displayorder ASC",'','uid');
foreach(DB::fetch_all('SELECT M.* FROM '.DB::table('fn_member').' AS M order by M.top_dateline > '.time().' desc,M.updateline desc,M.id desc') as $k => $v){
	$v['param'] = dunserialize($v['param']);
	$mat = $matList[$v['mid']];
	$user['per_check'] = 1;
	$user['phone_verify'] = 1;
	$user['uid'] = $v['uid'];
	$user['mat_id'] = $mat['id'];
	$user['username'] = $v['username'];
	$user['head_portrait'] = $v['face'];
	$user['name'] = $v['name'];
	$user['phone'] = $v['mobile'];
	$user['wx'] = $v['param']['wx'];
	$user['sex'] = $v['sex'];
	$user['age'] = $v['age'];
	$user['birth'] = $v['birth'];
	$user['animal'] = $v['animal'];
	$user['constellation'] = $v['constellation'];
	$user['weight'] = $v['weight'];
	$user['height'] = $v['height'];
	$user['education'] = $v['education'];
	$user['marriage'] = $v['marriage'];
	$user['nation'] = $v['ethnic'];
	$user['month_income'] = $v['month_income'];
	$user['vehicle'] = $v['vehicle'];
	$user['house'] = $v['house'];
	$user['company'] = $v['company'];
	$user['occupation'] = $v['occupation'];
	$user['album'] = implode(',',$v['param']['album']);
	$user['hobby'] = $v['hobby'];
	$hobby_arr = array();
	foreach(array_filter(explode(',',$user['hobby'])) as $kk => $vv) {
		$hobby_arr[$kk] = $fn_xiangqin->setting['lang']['hobby_arr'][$vv];
	}
	$user['hobby_arr'] = $hobby_arr ? serialize($hobby_arr) : '';
	$v['condition'] = array_filter(DB::fetch_first('SELECT * FROM '.DB::table('fn_xiangqin_condition').' where uid = '.$v['uid']));
	$user['req_age_min'] = $v['condition']['c_min_age'];
	$user['req_age_max'] = $v['condition']['c_max_age'];
	$user['req_height_min'] = $v['condition']['c_min_height'];
	$user['req_height_max'] = $v['condition']['c_max_height'];
	$user['req_month_income'] = $v['condition']['c_month_income'];
	$user['req_education'] = $v['condition']['c_education'];
	$user['req_nation'] = $v['condition']['c_ethnic'];
	$user['req_house'] = $v['condition']['c_house'];
	$user['req_vehicle'] = $v['condition']['c_vehicle'];
	$user['req_marriage'] = $v['condition']['c_marriage'];
	$user['req_want_child'] = $v['condition']['c_want_child'];
	$user['req_smoke'] = $v['condition']['c_smoke'];
	$user['req_drink'] = $v['condition']['c_drink'];
	$user['pull'] = $v['see_line'];
	$user['display'] = $v['display'];
	$user['audit_state'] = $v['examine'];
	$user['seal'] = $v['seal'];
	$user['hot'] = $v['home'];
	$user['click'] = $v['click'];
	$user['due_time'] = $v['vip_time'];
	$user['dateline'] = $v['dateline'];
	$user['updateline'] = $v['updateline'];
	$user['topdateline'] = $v['top_dateline'];
	$check = C::t('#fn_xiangqin#fn_love_user')->fetch_by_uid($v['uid']);
	if(!$check){
		C::t('#fn_xiangqin#fn_love_user')->insert($user);
		$i++;
	}
}
if($i){
	echo '&#25104;&#21151;&#36716;&#31227;'.$i.'&#20010;&#30456;&#20146;&#29992;&#25143;';
}
//From: Dism·taobao·com
?>