<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
header("Content-type: text/html; charset=utf-8");
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
if(!submitcheck('DetailSubmit')) {
	$formUrl = ltrim(rawurldecode(cpurl()),'action=');
	showtableheader('', 'nobottom');
	showtitle('&#28201;&#39336;&#25552;&#37266;&#65292;&#30830;&#23450;&#21021;&#22987;&#21270;&#25968;&#25454;&#21527;&#65311;');
	showformheader($formUrl,'enctype');
	showsubmit('DetailSubmit','&#25105;&#30830;&#23450;');
	showformfooter(); /*Dism_taobao-com*/
	showtablefooter(); /*dism·taobao·com*/
}else{

$sql = <<<EOF

DELETE FROM `pre_fn_ad` WHERE `pre_fn_ad`.`plugin` = 'fn_xiangqin';
INSERT INTO `pre_fn_ad` (`id`, `plugin`, `classId`, `pic`, `title`, `url`, `startTime`, `endTime`, `display`, `displayorder`, `dateline`) VALUES('', 'fn_xiangqin', 'banner', '/source/plugin/fn_xiangqin/static/images/banner1.jpg', '2', '', 0, 0, 1, 1, 1628332389);
INSERT INTO `pre_fn_nav` (`id`, `plugin`, `classId`, `icon`, `onIcon`, `title`, `url`, `top`, `displayorder`) VALUES
('', 'fn_xiangqin', 'nav', '/source/plugin/fn_xiangqin/static/images/nav_1.png', '', '红娘推荐', '[siteurl]plugin.php?id=fn_xiangqin&mod=list_hot', 0, 1),
('', 'fn_xiangqin', 'nav', '/source/plugin/fn_xiangqin/static/images/nav_2.png', '', '会员推荐', '[siteurl]plugin.php?id=fn_xiangqin&mod=list_vip', 0, 2),
('', 'fn_xiangqin', 'nav', '/source/plugin/fn_xiangqin/static/images/nav_3.png', '', '实名制专区', '[siteurl]plugin.php?id=fn_xiangqin&mod=list_cert', 0, 3),
('', 'fn_xiangqin', 'nav', '/source/plugin/fn_xiangqin/static/images/nav_4.png', '', '红娘', '[siteurl]plugin.php?id=fn_xiangqin&mod=mat', 0, 4),
('', 'fn_xiangqin', 'navBottom', '/source/plugin/fn_xiangqin/static/images/home.png', '/source/plugin/fn_xiangqin/static/images/homed.png', '首页', '[siteurl]plugin.php?id=fn_xiangqin', 0, 1),
('', 'fn_xiangqin', 'navBottom', '/source/plugin/fn_xiangqin/static/images/activity.png', '/source/plugin/fn_xiangqin/static/images/activityd.png', '活动', '[siteurl]plugin.php?id=fn_xiangqin&mod=activity&form=list', 0, 2),
('', 'fn_xiangqin', 'navBottom', '/source/plugin/fn_xiangqin/static/images/mat.png', '/source/plugin/fn_xiangqin/static/images/matd.png', '红娘', '[siteurl]plugin.php?id=fn_xiangqin&mod=mat&tab=1', 0, 3),
('', 'fn_xiangqin', 'navBottom', '/source/plugin/fn_xiangqin/static/images/user.png', '/source/plugin/fn_xiangqin/static/images/userd.png', '我的', '[siteurl]plugin.php?id=fn_xiangqin&mod=user', 0, 4),
('', 'fn_xiangqin', 'navMiddle', '/source/plugin/fn_xiangqin/static/images/index-nav-pic1.png', '', '我要置顶', 'plugin.php?id=fn_xiangqin&mod=user&top=1', 0, 1),
('', 'fn_xiangqin', 'navMiddle', '/source/plugin/fn_xiangqin/static/images/index-nav-pic2.png', '', '会员推荐', 'plugin.php?id=fn_xiangqin&mod=list_vip', 0, 2),
('', 'fn_xiangqin', 'navMiddle', '/source/plugin/fn_xiangqin/static/images/index-nav-pic3.png', '', '活动专区', 'plugin.php?id=fn_xiangqin&mod=activity&form=list', 0, 3),
('', 'fn_xiangqin', 'navMiddle', '/source/plugin/fn_xiangqin/static/images/index-nav-pic5.png', '', '牵线展示区', 'plugin.php?id=fn_xiangqin&mod=list_pull', 0, 4);

DELETE FROM `pre_fn_html_temp` WHERE `pre_fn_html_temp`.`plugin` = 'fn_xiangqin';
INSERT INTO `pre_fn_html_temp` (`id`, `plugin`, `classId`, `title`, `temp`, `display`, `displayorder`) VALUES
('', 'fn_xiangqin', '1', '模板一', '<section><section style=\\"margin-bottom: -1em;\\">\n            <section style=\\"width: 100%;text-align: left;\\" data-width=\\"100%\\">\n                <section style=\\"display: inline-block;box-shadow: #9fbfdb 4px 4px 0px;border-radius:6px ;\\">\n                    <section data-bgless=\\"spin\\" data-bglessp=\\"180\\" style=\\"color:#fff;background: #006785;border-radius:6px ;padding: 4px;\\">\n                        <section style=\\"border-radius:6px;border: 1px dashed #fff;\\">\n                            <section class=\\"135brush\\" data-brushtype=\\"text\\" style=\\"font-size:17px;font-weight: bold; text-align: center;letter-spacing:1.5px;padding:0em 0.6em;\\">\n                                \n								编号：[--id--]\n                            </section>\n                        </section>\n                    </section>\n                </section>\n            </section>\n        </section>\n        <section data-bdless=\\"spin\\" data-bdlessp=\\"220\\" data-bdopacity=\\"50%\\" style=\\"width: 100%;border: 1px dashed #9fbfdb;border-radius:6px ;\\" data-width=\\"100%\\">\n            <section style=\\"padding:4px;\\">\n                <section data-bgless=\\"spin\\" data-bglessp=\\"280\\" data-bgopacity=\\"50%\\" style=\\"background:#cdeaff;color:#2f2f2f;border-radius:6px ;\\">\n                    <section class=\\"135brush\\" style=\\"padding: 2em 1em 1em; letter-spacing: 1.5px; text-align: justify;\\">\n					    <p>[--head_portrait--]</p>\n						<p style=\\"font-size: 14px;\\">性别：[--sex--]</p>\n						<p style=\\"font-size: 14px;\\">年龄：[--age--]</p>\n						<p style=\\"font-size: 14px;\\">星座：[--constellation--]</p>\n						<p style=\\"font-size: 14px;\\">属相：[--animal--]</p>\n						<p style=\\"font-size: 14px;\\">身高：[--height--]</p>\n						<p style=\\"font-size: 14px;\\">体重：[--weight--]</p>\n						<p style=\\"font-size: 14px;\\">月收入：[--month_income--]</p>\n						<p style=\\"font-size: 14px;\\">婚姻状况：[--marriage--]</p>\n                        <p><span style=\\"font-size: 14px;\\">【提醒】<span style=\\"color: #2f2f2f; font-size: 10px; letter-spacing: 1.5px; text-align: justify; background-color: #cdeaff; text-decoration-line: underline;\\">长按二维码识别查看</span></span></p>\n                        <p>[--qr--]</p>\n                    </section>\n                </section>\n            </section>\n        </section>\n    </section>', 1, 1),
('', 'fn_xiangqin', '2', '女模板一', '<section><section style=\\"margin-bottom: -1em;\\">\n            <section style=\\"width: 100%;text-align: left;\\" data-width=\\"100%\\">\n                <section style=\\"display: inline-block;box-shadow: #9fbfdb 4px 4px 0px;border-radius:6px ;\\">\n                    <section data-bgless=\\"spin\\" data-bglessp=\\"180\\" style=\\"color:#fff;background: #006785;border-radius:6px ;padding: 4px;\\">\n                        <section style=\\"border-radius:6px;border: 1px dashed #fff;\\">\n                            <section class=\\"135brush\\" data-brushtype=\\"text\\" style=\\"font-size:17px;font-weight: bold; text-align: center;letter-spacing:1.5px;padding:0em 0.6em;\\">\n                                \n								编号：[--id--]\n                            </section>\n                        </section>\n                    </section>\n                </section>\n            </section>\n        </section>\n        <section data-bdless=\\"spin\\" data-bdlessp=\\"220\\" data-bdopacity=\\"50%\\" style=\\"width: 100%;border: 1px dashed #9fbfdb;border-radius:6px ;\\" data-width=\\"100%\\">\n            <section style=\\"padding:4px;\\">\n                <section data-bgless=\\"spin\\" data-bglessp=\\"280\\" data-bgopacity=\\"50%\\" style=\\"background:#cdeaff;color:#2f2f2f;border-radius:6px ;\\">\n                    <section class=\\"135brush\\" style=\\"padding: 2em 1em 1em; letter-spacing: 1.5px; text-align: justify;\\">\n					    <p>[--head_portrait--]</p>\n						<p style=\\"font-size: 14px;\\">性别：[--sex--]</p>\n						<p style=\\"font-size: 14px;\\">年龄：[--age--]</p>\n						<p style=\\"font-size: 14px;\\">星座：[--constellation--]</p>\n						<p style=\\"font-size: 14px;\\">属相：[--animal--]</p>\n						<p style=\\"font-size: 14px;\\">身高：[--height--]</p>\n						<p style=\\"font-size: 14px;\\">体重：[--weight--]</p>\n						<p style=\\"font-size: 14px;\\">月收入：[--month_income--]</p>\n						<p style=\\"font-size: 14px;\\">婚姻状况：[--marriage--]</p>\n                        <p><span style=\\"font-size: 14px;\\">【提醒】<span style=\\"color: #2f2f2f; font-size: 10px; letter-spacing: 1.5px; text-align: justify; background-color: #cdeaff; text-decoration-line: underline;\\">长按二维码识别查看</span></span></p>\n                        <p>[--qr--]</p>\n                    </section>\n                </section>\n            </section>\n        </section>\n    </section>', 1, 1);

DROP TABLE `pre_fn_love_gift`;
CREATE TABLE IF NOT EXISTS `pre_fn_love_gift` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `money` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `displayorder` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

INSERT INTO `pre_fn_love_gift` (`id`, `title`, `icon`, `money`, `display`, `displayorder`) VALUES
(1, '浪漫千秋', 'http://dev.yili6.com/source/plugin/fn_assembly/attachment/fn_assembly/fn_16103754795ffc61371954f.png', 58, 1, 0),
(2, '幸福摩天轮', 'http://dev.yili6.com/source/plugin/fn_assembly/attachment/fn_assembly/fn_16103755785ffc619a4350d.png', 88, 1, 1),
(3, '冰糖葫芦', 'http://dev.yili6.com/source/plugin/fn_assembly/attachment/fn_assembly/fn_16103756225ffc61c672277.png', 10, 1, 2),
(4, '保时捷', 'http://dev.yili6.com/source/plugin/fn_assembly/attachment/fn_assembly/fn_16103756445ffc61dcdc424.png', 12, 1, 3),
(5, '兰博基尼', 'http://dev.yili6.com/source/plugin/fn_assembly/attachment/fn_assembly/fn_16103756705ffc61f6b4d17.png', 30, 1, 4),
(6, '真爱超跑', 'http://dev.yili6.com/source/plugin/fn_assembly/attachment/fn_assembly/fn_16103756915ffc620b1c9b8.png', 39, 1, 5),
(7, '玛莎拉蒂', 'http://dev.yili6.com/source/plugin/fn_assembly/attachment/fn_assembly/fn_16103757225ffc622a637a7.png', 88, 1, 6),
(8, '真爱永恒', 'http://dev.yili6.com/source/plugin/fn_assembly/attachment/fn_assembly/fn_16103757425ffc623eb1cb3.png', 1314, 1, 7);

DROP TABLE `pre_fn_love_meal`;
CREATE TABLE IF NOT EXISTS `pre_fn_love_meal` (
  `id` tinyint(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL,
  `icon` varchar(255) NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` varchar(255) NOT NULL,
  `currency` int(11) unsigned NOT NULL,
  `imkey` int(11) unsigned NOT NULL,
  `pull` int(11) unsigned NOT NULL,
  `act` int(11) unsigned NOT NULL,
  `day` smallint(3) unsigned NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `limit` tinyint(2) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `displayorder` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM;

INSERT INTO `pre_fn_love_meal` (`id`, `type`, `icon`, `title`, `content`, `currency`, `imkey`, `pull`, `act`, `day`, `money`, `limit`, `display`, `displayorder`) VALUES
(1, 1, '', '铂金会员（半年）', '铂金会员（半年） 赠送钥匙20把、免费相亲活动3次、红娘主动牵线2次、朋友圈推广等', 0, 20, 2, 3, 182, '0.01', 0, 1, 0),
(2, 1, '', '钻石会员（一年）', '钻石会员（一年） 赠送钥匙40把、免费相亲活动6次、红娘主动牵线5次、朋友圈推广等', 0, 40, 5, 6, 365, '688.00', 0, 1, 1),
(3, 1, '', '至尊豪华会员', '至尊豪华会员有效期12个月赠送金币5200，钥匙80把，牵线次数12次，活动9次，朋友圈推广等', 5200, 80, 12, 9, 365, '999.00', 0, 1, 2),
(4, 2, '', '6元62个金币', '', 62, 0, 0, 0, 0, '0.01', 0, 1, 0),
(5, 2, '', '49元520金币', '', 520, 0, 0, 0, 0, '49.00', 0, 1, 1),
(6, 2, '', '120元1314金币', '', 1314, 0, 0, 0, 0, '120.00', 0, 1, 2),
(7, 3, '', '128元5个沟通钥匙', '', 0, 5, 0, 0, 0, '128.00', 0, 1, 4);

EOF;
	runquery(diconv($sql,mb_detect_encoding($sql, array('ASCII','UTF-8','GB2312','GBK','BIG5')),CHARSET));
	cpmsg('&#24685;&#21916;&#24744;&#65292;&#21021;&#22987;&#21270;&#25104;&#21151;',$CpMsgUrl,'succeed');
}