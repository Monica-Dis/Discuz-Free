<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$plugin_id = $plugin_id == 'fn_admin' || !$plugin_id ? 'fn_xiangqin' : $plugin_id;
$apiUrl = $_G['siteroot'].'plugin.php?id='.$plugin_id.'&mod=api&action=';
$referer = $_GET['referer'] ? urldecode($_GET['referer']) : dreferer();
$backReferer = base64_encode($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"]);
$jumpReferer = base64_decode($backReferer);

@require_once libfile('class/magapp','plugin/fn_assembly');
@require_once libfile('class/qfapp','plugin/fn_assembly');
@require_once libfile('class/pay','plugin/fn_assembly');
@require_once libfile('function/forum');

class fn_xiangqin{
	
	public function __construct() {
		global $_G,$Config;
		$this->plugin_id = 'fn_xiangqin';
		loadcache('plugin');
		loadcache('fn_love_gift');
		loadcache('fn_love_mat');
		loadcache('fn_ad_'.$this->plugin_id);
		loadcache('fn_nav_'.$this->plugin_id);
		loadcache('fn_notice_'.$this->plugin_id);
		loadcache($this->plugin_id.'_setting');
		foreach($_G['cache'][$this->plugin_id.'_setting'] as $key => $value) {
			$setting[$key] = is_array($value) ? $value : stripslashes($value);
		}
		$setting['common_setting'] = $Config['PluginVar'];
		$setting['common_setting']['StaticPicPath'] = $Config['StaticPicPath'];
		$setting['common_setting']['StaticPath'] = $Config['StaticPath'];
		$setting['lang'] = lang('plugin/'.$this->plugin_id);
		$path = 'source/plugin/'.$this->plugin_id;
		$setting['static'] = $_G['siteroot'].$path.'/static';
		$setting['url'] = $_G['siteurl'].'plugin.php?id='.$this->plugin_id.($_GET['formapp'] ? '&formapp='.$_GET['formapp'] : '');
		$this->setting = $setting;
		
		$this->matList = $_G['cache']['fn_love_mat'];
		$this->adList = $_G['cache']['fn_ad_'.$this->plugin_id];
		$this->navList = $_G['cache']['fn_nav_'.$this->plugin_id];
		$this->noticeList = $_G['cache']['fn_notice_'.$this->plugin_id];

		$this->setting['adminList'] = array_filter(explode(",",$this->setting['admin']));
		$this->setting['admin']= in_array($_G['uid'],$this->setting['adminList']) ? true : false;
		$this->setting['AppPaymentId'] = $this->setting['qf_type'] ? $this->setting['qf_type'] : $this->setting['common_setting']['qf_type'];
		$this->_G = $_G;
		$this->pay = new Fn_PayLog();
		$this->magApp = new MagApp($this->setting['MagSecret'],$this->setting['MagAssistantSecret'],$this->setting['MagAssistantPush']);
		$this->qfApp = new QHApp($this->setting['qf_type'],$this->setting['qf_sr_type'],$this->setting['qf_from_id']);
		
		$this->setting['lang']['education_arr'] = TextareaArray($this->setting['education']);
		$this->setting['lang']['nation_arr'] = TextareaArray($this->setting['nation']);
		$this->setting['lang']['month_income_arr'] = TextareaArray($this->setting['month_income']);
		$this->setting['lang']['occupation_arr'] = TextareaArray($this->setting['occupation']);
		$this->setting['lang']['religion_arr'] = TextareaArray($this->setting['religion']);
		$this->setting['lang']['hobby_arr'] = TextareaArray($this->setting['hobby']);
		$this->setting['lang']['report_arr'] = TextareaArray($this->setting['report_list']);

		//������ά�뿪��
		if(!$this->setting['QrParameterSwitch'] && QrParameterSwitch){
			$this->setting['WxAppid'] = $this->setting['common_setting']['WxAppid'];
			$this->setting['WxSecret'] = $this->setting['common_setting']['WxSecret'];
		}
		$this->setting['QrParameterSwitch'] = $this->setting['QrParameterSwitch'] ? $this->setting['QrParameterSwitch'] : (QrParameterSwitch ? QrParameterSwitch : 0);
		//������ά�뿪�� End
		
	}

	public function getUrl($mod,$form = array()){
		global $_G;
		loadcache($this->plugin_id.'_rewrite');
		$rewrite = $_G['cache'][$this->plugin_id.'_rewrite'];
		$rewriteName =  $form['form'] ? $mod.'_'.$form['form'] : $mod;
		if($rewrite[$rewriteName]['available'] && !MinWxApp){
			$strReplaceArray = array('{','}');
			$strReplaceArrayTo = array('','');
			foreach($form as $k => $v) {
				$strReplaceArray[] = $k;
				$strReplaceArrayTo[] = $v;
			}
			$url = $this->_G['siteurl'].str_replace($strReplaceArray,$strReplaceArrayTo,$rewrite[$rewriteName]['rule']);
		}else{
			$url = $this->setting['url'].'&mod='.$mod.( !empty($form) ? '&'.http_build_query($form) : '' );
		}
		return $url;
	}

	public function getView($id){
		return $this->getFormUser(C::t('#fn_xiangqin#fn_love_user')->fetch_by_id($id));
	}

	public function getUserInfo(){
		$userInfo = $this->_G['uid'] ? C::t('#fn_xiangqin#fn_love_user')->fetch_by_uid($this->_G['uid']) : array();
		if($userInfo){
			$userInfo['vip'] = $userInfo['due_time'] > time() ? true : false;
			$userInfo['due_strtotime'] = $userInfo['due_time'];
			$userInfo['due_time'] = $userInfo['vip'] ? date('Y-m-d',$userInfo['due_time']) : '';
			$userInfo['top'] = $userInfo['topdateline'] > time() ? true : false;
			$userInfo['topdateline'] = $userInfo['top'] ? date('Y-m-d',$userInfo['topdateline']) : '';
			//���ƶ�
			$perfectField = array('name','sex','head_portrait','birth','weight','height','education','marriage','occupation','only','family','nation','child','want_child','vehicle','house','when_marry','shape','smoke','drink','hobby','req_age_min','req_height_min','req_month_income','req_education','req_nation','req_marriage');
			$i = 0;
			foreach($perfectField as $k => $v) {
				if($userInfo[$v]){
					$i++;
				}
			}
			$userInfo['perfect'] = intval(100 / count($perfectField) * $i);
			//���ƶ�End

			$userInfo['age'] != date('Y') - date('Y',$userInfo['birth']) ? C::t('#fn_xiangqin#fn_love_user')->update(array('age'=>date('Y') - date('Y',$userInfo['birth'])),$userInfo['id']) : '';

			//ÿ��ˢ��
			if($this->setting['day_refresh'] && $userInfo['day_refresh_dateline'] <= time()){
				C::t('#fn_xiangqin#fn_love_user')->update(array('updateline'=>time(),'day_refresh_dateline'=>strtotime("+".$this->setting['day_refresh_time']." hours",time())),$userInfo['id']);
			}
		}else{
			$userInfo['head_portrait'] = discuz_uc_avatar($this->_G['uid'],middle,true);
			$userInfo['name'] = $this->_G['username'];
			$userInfo['id'] = 0;
		}
		$userInfo['perfect_tips'] = str_replace(array('[--count--]'),array(intval($userInfo['perfect'])),$this->setting['lang']['perfect_tips']);
		$userInfo['poster_url'] = $this->getUrl('poster',array('vid'=>$userInfo['id']));
		$userInfo['mat_url'] = $this->getUrl('mat',array('vid'=>$userInfo['id']));
		return $userInfo;
	}

	public function getNotice($uid,$openid = null,$url,$msg,$name){//֪ͨģ��
		if($openid && $this->setting['noticeTemplate']){
			$templateParam = array(
				'touser' => $openid,
				'template_id' => $this->setting['noticeTemplate'],
				'url' => $url,
				'topcolor' => '#ff0000',
				'data' =>array(
					'first'=>array('value'=>diconv($name, CHARSET, 'UTF-8')),
					'keyword1'=>array('value'=>diconv($msg, CHARSET, 'UTF-8'),'color'=>'#fe0000'),
					'keyword2'=>array('value'=>date('Y-m-d H:i',time()),'color'=>'#ff4a03'),
					'remark'=>array('value'=>'')
				)
			);
			$this->getPushWxTemplate($templateParam);
		}
		
		if($this->setting['common_setting']['AppType'] == 1){
			$pushData['Uid'] = $uid;
			$pushData['Type'] = 'pictemp';
			$pushData['Content'] = array(
				"tag"=> diconv(addslashes(strip_tags($this->setting['lang']['auditNotice'])),CHARSET,'UTF-8'),
				"title"=> diconv(addslashes(strip_tags($this->setting['lang']['auditNotice'])),CHARSET,'UTF-8'),
				"link"=> $url,
				"pic_url"=> $this->_G['siteurl'].$this->setting['common_setting']['StaticPath'].'/images/notice.png',
				"extra_info"=>array(
					array(
						"key"=>'',
						"val"=>diconv($msg,CHARSET,'UTF-8')
					)
				)
			);
			$this->magApp->GetSendAssistantMsg($pushData);
		}else if($this->setting['common_setting']['AppType'] == 2){
			$pushData['Uid'] = is_array($uid) ? implode(',',$uid) : $uid;
			$pushData['Msg'] = diconv(addslashes(strip_tags($this->setting['lang']['auditNotice'])),CHARSET,'UTF-8');
			$pushData['Content'] = array(
				'title'=>diconv(addslashes(strip_tags($this->setting['lang']['auditNotice'])),CHARSET,'UTF-8'),
				'date'=>date('Y-m-d H:i:s'),
				'setting'=>array(),
				'content' => diconv($msg,CHARSET,'UTF-8'),
				'url'=>$url
			);
			$this->qfApp->GetMessagesTemplate($pushData);
		}
	}

	public function getLookNotice($id,$url,$msg,$name){//����֪ͨ
		$member = $this->getView($id);
		if($member['openid'] && $this->setting['lookTemplate']){
			$templateParam = array(
				'touser' => $member['openid'],
				'template_id' => $this->setting['lookTemplate'],
				'url' => $url,
				'topcolor' => '#ff0000',
				'data' =>array(
					'first'=>array('value'=>diconv($msg, CHARSET, 'UTF-8')),
					'keyword1'=>array('value'=>diconv($name, CHARSET, 'UTF-8')),
					'keyword2'=>array('value'=>date('Y-m-d H:i',time())),
					'remark'=>array('value'=>'')
				)
			);
			$this->getPushWxTemplate($templateParam);
		}
		
		if($this->setting['common_setting']['AppType'] == 1){
			$pushData['Uid'] = $member['uid'];
			$pushData['Type'] = 'pictemp';
			$pushData['Content'] = array(
				"tag"=> diconv(addslashes(strip_tags($this->setting['lang']['lookNotice'])),CHARSET,'UTF-8'),
				"title"=> diconv(addslashes(strip_tags($this->setting['lang']['lookNotice'])),CHARSET,'UTF-8'),
				"link"=> $url,
				"pic_url"=> $this->_G['siteurl'].$this->setting['common_setting']['StaticPath'].'/images/notice.png',
				"extra_info"=>array(
					array(
						"key"=>'',
						"val"=>diconv($msg,CHARSET,'UTF-8')
					)
				)
			);
			$this->magApp->GetSendAssistantMsg($pushData);
		}else if($this->setting['common_setting']['AppType'] == 2){
			$pushData['Uid'] = $member['uid'];
			$pushData['Msg'] = diconv(addslashes(strip_tags($this->setting['lang']['lookNotice'])),CHARSET,'UTF-8');
			$pushData['Content'] = array(
				'title'=>diconv(addslashes(strip_tags($this->setting['lang']['lookNotice'])),CHARSET,'UTF-8'),
				'date'=>date('Y-m-d H:i:s'),
				'setting'=>array(),
				'content' => diconv($msg,CHARSET,'UTF-8'),
				'url'=>$url
			);
			$this->qfApp->GetMessagesTemplate($pushData);
		}
	}

	public function getSealNotice($id,$url,$msg){//���֪ͨ
		$member = $this->getView($id);
		if($member['openid'] && $this->setting['sealTemplate']){//��Ϣ����
			$templateParam = array(
				'touser' => $member['openid'],
				'template_id' => $this->setting['sealTemplate'],
				'url' => $url,
				'topcolor' => '#ff0000',
				'data' =>array(
					'first'=>array('value'=>diconv($msg, CHARSET, 'UTF-8')),
					'keyword1'=>array('value'=>diconv($member['name'], CHARSET, 'UTF-8')),
					'keyword2'=>array('value'=>date('Y-m-d H:i',time())),
					'remark'=>array('value'=>'')
				)
			);
			$this->getPushWxTemplate($templateParam);
		}
		
		if($this->setting['common_setting']['AppType'] == 1){
			$pushData['Uid'] = $member['uid'];
			$pushData['Type'] = 'pictemp';
			$pushData['Content'] = array(
				"tag"=> diconv(addslashes(strip_tags($this->setting['lang']['sealNotice'])),CHARSET,'UTF-8'),
				"title"=> diconv(addslashes(strip_tags($this->setting['lang']['sealNotice'])),CHARSET,'UTF-8'),
				"link"=> $url,
				"pic_url"=> $this->_G['siteurl'].$this->setting['common_setting']['StaticPath'].'/images/notice.png',
				"extra_info"=>array(
					array(
						"key"=>'',
						"val"=>diconv($msg,CHARSET,'UTF-8')
					)
				)
			);
			$this->magApp->GetSendAssistantMsg($pushData);
		}else if($this->setting['common_setting']['AppType'] == 2){
			$pushData['Uid'] = $member['uid'];
			$pushData['Msg'] = diconv(addslashes(strip_tags($this->setting['lang']['sealNotice'])),CHARSET,'UTF-8');
			$pushData['Content'] = array(
				'title'=>diconv(addslashes(strip_tags($this->setting['lang']['sealNotice'])),CHARSET,'UTF-8'),
				'date'=>date('Y-m-d H:i:s'),
				'setting'=>array(),
				'content' => diconv($msg,CHARSET,'UTF-8'),
				'url'=>$url
			);
			$this->qfApp->GetMessagesTemplate($pushData);
		}
		//����֪ͨ
		if($this->setting['seal_sms']){
			@require_once libfile('class/short_message','plugin/fn_assembly');
			if($this->setting['common_setting']['ShortMessageType'] == 1){
				$templateCode = $this->setting['AliNoticeId'];
				$templateParam = array('remark'=>$msg);
			}else if($this->setting['common_setting']['ShortMessageType'] == 2){
				$templateCode = str_replace(array('{Msg}'),array($msg),$this->setting['ChanyooNotice']);
				$templateParam = array();
			}
			$SendSms = fn_short_message::send_sms($this->setting['common_setting']['MobileAreaCode'].$member['phone'],$this->setting['AliAutograph'],$templateCode,$templateParam,$member['uid'],$member['username'],'fn_xiangqin',2);
		}
		//����֪ͨEnd
	}

	public function getAuditNotice($id,$audit_state,$url,$msg){//���֪ͨ
		$member = $this->getView($id);
		if($member['openid'] && $this->setting['auditTemplate']){//��Ϣ����
			$templateParam = array(
				'touser' => $member['openid'],
				'template_id' => $this->setting['auditTemplate'],
				'url' => $url,
				'topcolor' => '#ff0000',
				'data' =>array(
					'first'=>array('value'=>diconv($msg, CHARSET, 'UTF-8')),
					'keyword1'=>array('value'=>diconv($member['name'], CHARSET, 'UTF-8')),
					'keyword2'=>array('value'=>diconv($this->setting['lang']['audit_state_arr'][$audit_state], CHARSET, 'UTF-8')),
					'keyword3'=>array('value'=>date('Y-m-d H:i',time())),
					'remark'=>array('value'=>'')
				)
			);
			$this->getPushWxTemplate($templateParam);
		}
		
		if($this->setting['common_setting']['AppType'] == 1){
			$pushData['Uid'] = $member['uid'];
			$pushData['Type'] = 'pictemp';
			$pushData['Content'] = array(
				"tag"=> diconv(addslashes(strip_tags($this->setting['lang']['auditNotice'])),CHARSET,'UTF-8'),
				"title"=> diconv(addslashes(strip_tags($this->setting['lang']['auditNotice'])),CHARSET,'UTF-8'),
				"link"=> $url,
				"pic_url"=> $this->_G['siteurl'].$this->setting['common_setting']['StaticPath'].'/images/notice.png',
				"extra_info"=>array(
					array(
						"key"=>diconv($this->setting['lang']['auditResult'],CHARSET,'UTF-8'),
						"val"=>diconv($msg,CHARSET,'UTF-8')
					)
				)
			);
			$this->magApp->GetSendAssistantMsg($pushData);
		}else if($this->setting['common_setting']['AppType'] == 2){
			$pushData['Uid'] = $member['uid'];
			$pushData['Msg'] = diconv(addslashes(strip_tags($this->setting['lang']['auditNotice'])),CHARSET,'UTF-8');
			$pushData['Content'] = array(
				'title'=>diconv(addslashes(strip_tags($this->setting['lang']['auditNotice'])),CHARSET,'UTF-8'),
				'date'=>date('Y-m-d H:i:s'),
				'setting'=>array(),
				'content' => diconv($msg,CHARSET,'UTF-8'),
				'url'=>$url
			);
			$this->qfApp->GetMessagesTemplate($pushData);
		}

		//����֪ͨ
		if($this->setting['audit_state_sms']){
			@require_once libfile('class/short_message','plugin/fn_assembly');
			if($this->setting['common_setting']['ShortMessageType'] == 1){
				$templateCode = $this->setting['AliNoticeId'];
				$templateParam = array('remark'=>$msg);
			}else if($this->setting['common_setting']['ShortMessageType'] == 2){
				$templateCode = str_replace(array('{Msg}'),array($msg),$this->setting['ChanyooNotice']);
				$templateParam = array();
			}
			$SendSms = fn_short_message::send_sms($this->setting['common_setting']['MobileAreaCode'].$member['phone'],$this->setting['AliAutograph'],$templateCode,$templateParam,$member['uid'],$member['username'],'fn_xiangqin',2);
		}
		//����֪ͨEnd
	}

	public function getPushWxTemplate($template){
		if($this->setting['WxAppid'] && $this->setting['WxSecret']){
			@require_once libfile('class/wechat','plugin/fn_assembly');
			$wechatClient = new Fn_WeChatClient($this->setting['WxAppid'],$this->setting['WxSecret']);
			$wechatClient->send_weixintemplate(json_encode($template));
		}
	}

	public function getFormUser($item){//����ת��
		$item['url'] = $this->getUrl('view',array('vid'=>$item['id']));
		$item['name'] = in_array($_GET['mod'],array('api')) && $this->setting['user_id'] ? $this->setting['lang']['user_id'].':'.$item['id'] : $item['name'];
		$item['poster_url'] = $this->getUrl('poster',array('vid'=>$item['id']));
		$item['vip'] = $item['due_time'] > time() ? true : false;
		$item['due_time'] = $item['due_time'] ? date('Y-m-d',$item['due_time']) : '';
		$item['top'] = $item['topdateline'] > time() ? true : false;
		$item['age'] = $item['age'].$this->setting['lang']['sui'];
		$item['height'] = $item['height'].'cm';
		$item['weight'] = $item['weight'].'kg';
		$item['year'] = date('Y',$item['birth']);
		$item['birth'] = date('Y-m-d',$item['birth']);
		$item['animal'] = $this->setting['lang']['animal_arr'][$item['animal']];
		$item['constellation'] = $this->setting['lang']['constellation_arr'][$item['constellation']];
		$item['sex_text'] = $this->setting['lang']['sex_arr'][$item['sex']];
		$item['education'] = $this->setting['lang']['education_arr'][$item['education']];
		$item['marriage'] = $this->setting['lang']['marriage_arr'][$item['marriage']];
		$item['nation'] = $this->setting['lang']['nation_arr'][$item['nation']];
		$item['month_income'] = $this->setting['lang']['month_income_arr'][$item['month_income']];
		$item['family'] = $this->setting['lang']['family_arr'][$item['family']];
		$item['vehicle'] = $this->setting['lang']['vehicle_arr'][$item['vehicle']];
		$item['house'] = $this->setting['lang']['house_arr'][$item['house']];
		$item['smoke'] = $this->setting['lang']['smoke_arr'][$item['smoke']];
		$item['drink'] = $this->setting['lang']['drink_arr'][$item['drink']];
		$item['religion'] = $item['religion'] ? $this->setting['lang']['religion_arr'][$item['religion']] : '';
		$item['occupation'] = $this->setting['lang']['occupation_arr'][$item['occupation']];
		$item['child'] = $this->setting['lang']['child_arr'][$item['child']];
		$item['want_child'] = $this->setting['lang']['want_child_arr'][$item['want_child']];
		$item['when_marry'] = $this->setting['lang']['when_marry_arr'][$item['when_marry']];
		$item['hobby'] = array_filter(explode(",",$item['hobby']));
		$item['hobby_arr'] = dunserialize($item['hobby_arr']);
		
		$item['req_age_text'] = $item['req_age_max'] && $item['req_age_min'] ? $item['req_age_min'].'-'.$item['req_age_max'].$this->setting['lang']['sui'] : $item['req_age_min'].$this->setting['lang']['sui'].$this->setting['lang']['above'].'';
		$item['req_height_text'] = $item['req_height_max'] && $item['req_height_min'] ? $item['req_height_min'].'-'.$item['req_height_max'].'cm' : $item['req_height_min'].'cm'.$this->setting['lang']['above'].'';

		$item['req_month_income'] = $this->setting['lang']['month_income_arr'][$item['req_month_income']];
		$item['req_education'] = $this->setting['lang']['education_arr'][$item['req_education']];
		$item['req_marriage'] = $this->setting['lang']['marriage_arr'][$item['req_marriage']];
		$item['req_nation'] = $this->setting['lang']['nation_arr'][$item['req_nation']];
		$item['req_accept_child'] = $this->setting['lang']['req_accept_child_arr'][$item['req_accept_child']];
		$item['req_want_child'] = $this->setting['lang']['req_want_child_arr'][$item['req_want_child']];
		$item['req_smoke'] = $this->setting['lang']['req_smoke_arr'][$item['req_smoke']];
		$item['req_drink'] = $this->setting['lang']['req_drink_arr'][$item['req_drink']];
		$item['req_house'] = $item['req_house'] ? $this->setting['lang']['Yes'] : '';
		$item['req_vehicle'] = $item['req_vehicle'] ? $this->setting['lang']['Yes'] : '';
		$item['album'] = array_filter(explode(",",$item['album']));

		$item['replaceFront'] = $replaceFront = array('[--url--]','[--qr--]','[--id--]','[--head_portrait--]','[--name--]','[--age--]','[--constellation--]','[--animal--]','[--sex--]','[--height--]','[--weight--]','[--marriage--]','[--month_income--]','[--house--]','[--vehicle--]');
		$item['replaceAfter'] = $replaceAfter = array($item['url'],'<img src="[--qrcode_url--]" style="width:100px;height:100px;">',$item['id'],$item['head_portrait'] ? '<img src="'.$item['head_portrait'].'" style="height:170px;object-fit:cover;width:170px;">' : '',$item['name'],$item['age'],$item['constellation'],$item['animal'],$item['sex_text'],$item['height'],$item['weight'],$item['marriage'],$item['month_income'],$item['house'],$item['vehicle']);

		//$item['user_wx_temp'] = str_replace($replaceFront,$replaceAfter,$this->setting['user_wx_temp_'.$item['sex']]);
		$item['copy_temp'] = str_replace($replaceFront,$replaceAfter,$this->setting['copyContent']);
		$item['view_title'] = str_replace($replaceFront,$replaceAfter,$this->setting['view_title']);
		$item['share_title'] = str_replace($replaceFront,$replaceAfter,$this->setting['view_share_title']);
		$item['share_desc'] = str_replace($replaceFront,$replaceAfter,$this->setting['view_share_desc']);
		$item['share_logo'] = $item['head_portrait'];
		$item['share_url'] = $item['url'];
		return $item;
	}

	public function getFormActivity($item){//����ת�� 
		$item['url'] = $this->getUrl('activity',array('form'=>'view','aid'=>$item['id']));
		$item['banner'] = array_filter(explode(",",$item['banner']));
		$item['content'] = stripslashes($item['content']);
		$item['signup_end'] = time() > $item['signup_end_dateline'] ? true : '';
		$item['signup_end_dateline'] = date('Y-m-d H:i',$item['signup_end_dateline']);
		$item['end'] = time() > $item['end_dateline'] ? true : '';
		$item['end_dateline'] = date('Y-m-d H:i',$item['end_dateline']);
		$item['share_title'] = $item['share_title'] ? $item['share_title'] : $item['title'];
		$item['share_desc'] = $item['share_desc'];
		$item['share_logo'] = $item['share_logo'];
		$item['share_url'] = $item['url'];
		return $item;
	}

	public function getWxOpenId(){
		global $jumpReferer;
		$userInfo = $this->getUserInfo();
		if(WxApp && $userInfo['id']){
			if($_GET['code']){
				@require_once libfile('class/wechat','plugin/fn_assembly');
				$wechatClient = new Fn_WeChatClient($this->setting['WxAppid'],$this->setting['WxSecret']);
				$token = $wechatClient->getAccessTokenByCode($_GET['code']);
				if($token['openid']){
					C::t('#fn_xiangqin#fn_love_user')->update(array('openid'=>$token['openid'],'wxdateline'=>time()),$userInfo['id']);
				}
			}else if(time() >= strtotime("+10 day",$userInfo['wxdateline'])){
				if(strpos($this->setting['WxOauthDomain'],'oauth2.htm') !== false) {
					$jumpUrl = $this->setting['WxOauthDomain'].'?appid='.$this->setting['WxAppid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.urlencode($jumpReferer);
				}else{
					$jumpUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$this->setting['WxAppid'].'&redirect_uri=' . urlencode($jumpReferer).'&response_type=code&scope=snsapi_userinfo&state='. md5(FORMHASH).'#wechat_redirect';
				}
				dheader('Location:'.$jumpUrl);
				exit();
			}
		}
	}

	public function getAliApiCurl($url,$method,$bodys,$headers){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($curl, CURLOPT_FAILONERROR, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HEADER, true);
		if(1 == strpos("$".$url, "https://")){
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		}
		curl_setopt($curl, CURLOPT_POSTFIELDS, $bodys);
		if(curl_exec($curl)) {
			$content = curl_multi_getcontent($curl);
			if(curl_getinfo($curl, CURLINFO_HTTP_CODE) == '200') {
				$headerSize = curl_getinfo($curl, CURLINFO_HEADER_SIZE);  // ��ȡheader����
				$content = substr($content, $headerSize);  // ��ȡ��header
			}
		}
		return $content;
	}
	
	public function getCheckGift(){//���ﻺ��
		$res = C::t('#fn_xiangqin#fn_love_gift')->fetch_all_by_list(array('display'=>1),'displayorder',$page - 1,100,true,'','');
		savecache('fn_love_gift',$res['list']);
	}

	public function getCheckMat(){//���ﻺ��
		$check = array();
		foreach(C::t('#fn_xiangqin#fn_love_mat')->fetch_all_by_list() as $val){
			$check[$val['id']] = $val;
		}
		savecache('fn_love_mat',$check);
	}

	/* �ع����� */
	public function getArrayCombine($arr,$key = 0,$text){
		$arrKey = array_keys($arr);
		$arrVal = array_values($arr);
		array_unshift($arrKey,$key);
		array_unshift($arrVal,$text);
		return array_combine($arrKey,$arrVal);
	}

	/** 
	 �жϸ�֧����Ф������ 
	*/
	public function birthext($birth){ 
		$y = Date('Y',$birth); 
		$m = Date('m',$birth); 
		$d = Date('d',$birth); 
		$num = array(1222,120,219,321,420,521,622,723,823,923,1024,1123,1221);
		if(intval($m.$d) == 1221){
			$result['constellation'] = 12;
		}else{
			for($i = 0; $i < count($num); $i++){
				if(intval($m.$d) >= $num[$i] && intval($m.$d) < $num[$i+1]){
					$constellation = $i;
					break;
				}else{
					$constellation = 0;
				}
			}
			$result['constellation'] = $constellation + 1;
		}
		
		$result['animal'] = (($y - 4) % 12) + 1;
		return $result; 
	}

}
$fn_xiangqin = new $plugin_id;
$setting = $fn_xiangqin->setting;
?>