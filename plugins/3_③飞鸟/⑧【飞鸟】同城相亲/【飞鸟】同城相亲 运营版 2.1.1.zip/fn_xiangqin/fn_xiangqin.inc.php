<?php
/**
 *	[【飞鸟】相亲交友(fn_xiangqin.{modulename})] (C)2016-2099 Powered by DisM.Taobao.Com.
 *	Version: 1.0
 *	Date: 2018-4-30 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
$mod_array = array('index','list_hot','list_vip','list_cert','list_offline','list_far_single','list_pull','mat','view','user','poster','payment','activity','api');
if(!in_array($mod,$mod_array)){
	exit('No Data');
}else{
	@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
	@require_once (DISCUZ_ROOT .'./source/plugin/'.$plugin_id.'/config.php');
	if($setting['PcQrSwitch'] && !checkmobile() && !$fn_xiangqin->setting['admin']){
		$file = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
		if(!file_exists($file) || !filesize($file)) {
			@require_once libfile('class/qrcode','plugin/fn_assembly');
			QRcode::png($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"], $file, QR_ECLEVEL_L,5,2);
		}
		$QrCode = base64_encode(file_get_contents($file));
		@unlink($file);
		include template($plugin_id.':index_qrcode');
		exit();
	}
	@require_once (DISCUZ_ROOT .'./source/plugin/'.$plugin_id.'/mod/'.$mod.'.inc.php');

}
//From: Dism·taobao·com
?>