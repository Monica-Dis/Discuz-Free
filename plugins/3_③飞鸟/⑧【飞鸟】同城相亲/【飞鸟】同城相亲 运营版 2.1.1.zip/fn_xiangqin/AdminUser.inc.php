<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_xiangqin/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_xiangqin/Common.php');
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&uid='.$_GET['uid'];
$Uid = intval($_GET['uid']);
$UserInfo = $Uid ? $Fn_XiangQin->GetUserInfo($Uid) : array();
if(!submitcheck('DetailSubmit')) {
	$OpTitle = $Fn_XiangQin->Config['LangVar']['AddTitle'];
	if($UserInfo) {
		$OpTitle = $Fn_XiangQin->Config['LangVar']['EditTitle'];
	}

	$formUrl = ltrim(rawurldecode(cpurl()),'action=');
	showformheader($formUrl,'enctype');
	showtableheader();
	showtitle($OpTitle);
	
	if($UserInfo['face']) {
		$FacaHtml = '<label><input type="checkbox" class="checkbox" name="delface" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$UserInfo['face'].'" target="_blank"><img src="'.$UserInfo['face'].'" width="100"/></a><input type="hidden" value="'.$UserInfo['face'].'" name="face"><br />';
	}
	showsetting($Fn_XiangQin->Config['LangVar']['AddFace'], 'facenew','', 'filetext', '', 0, $FacaHtml);

	showsetting($Fn_XiangQin->Config['LangVar']['NameTitle'], 'name', $UserInfo['name'], 'text','','','<input type="hidden" value="'.$UserInfo['param']['refusal'].'" name="refusal"><input type="hidden" value="'.$UserInfo['param']['vip_title'].'" name="vip_title">');

	showsetting($Fn_XiangQin->Config['LangVar']['SexTitle'],array('sex',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['SexArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['sex'],'select');
	
	showsetting($Fn_XiangQin->Config['LangVar']['BirthTitle'], 'birth', $UserInfo['birth'] ?  date('Y-m-d',$UserInfo['birth']) : '', 'calendar','','','');
	
	showsetting($Fn_XiangQin->Config['LangVar']['HeightTitle'],array('height',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['UserInfoHeightArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['height'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['WeightTitle'],array('weight',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['UserInfoWeightArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['weight'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['BloodTitle'],array('blood',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['BloodArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['blood'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['EthnicTitle'],array('ethnic',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['EthnicArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['ethnic'],'select');
	
	showsetting($Fn_XiangQin->Config['LangVar']['CompanyTitle'], 'company', $UserInfo['company'], 'text');

	showsetting($Fn_XiangQin->Config['LangVar']['EducationTitle'],array('education',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['EducationArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['education'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['MarriageTitle'],array('marriage',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['MarriageArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['marriage'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['ChildTitle'],array('child',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['ChildArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['child'],'select');
	
	showsetting($Fn_XiangQin->Config['LangVar']['MobileTitle'], 'mobile', $UserInfo['mobile'], 'text');

	showsetting($Fn_XiangQin->Config['LangVar']['MobileDisplayTitle'], 'mobile_display', $UserInfo ? $UserInfo['mobile_display'] : 1 , 'radio');

	showsetting($Fn_XiangQin->Config['LangVar']['WxTitle'], 'wx', $UserInfo['param']['wx'], 'text');
	
	showsetting($Fn_XiangQin->Config['LangVar']['UserNavWx'], 'wx_display', $UserInfo ? $UserInfo['wx_display'] : 1 , 'radio');


	showsetting($Fn_XiangQin->Config['LangVar']['QQTitle'], 'qq', $UserInfo['param']['qq'], 'text');

	showsetting($Fn_XiangQin->Config['LangVar']['MonthIncomeTitle'],array('month_income',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['MonthIncomeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['month_income'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['HouseTitle'],array('house',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['HouseArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['house'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['VehicleTitle'],array('vehicle',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['VehicleArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['vehicle'],'select');
	
	$AlbumHtml = $Fn_XiangQin->Config['LangVar']['AdminAlbumPrompt'].'<div class="ImgList ImgsList">';
	foreach($UserInfo['param']['album'] as $Key => $Val) {
		$AlbumHtml .= '<img src="'.$Val.'">';
	}
	$AlbumHtml .= '</div>';

	showsetting($Fn_XiangQin->Config['LangVar']['HeUserAlbum'], 'album', $UserInfo['param']['album'] ? implode("\n",$UserInfo['param']['album']) : '', 'textarea','','',$AlbumHtml);

	showsetting($Fn_XiangQin->Config['LangVar']['MonologueTitle'], 'monologue', $UserInfo['param']['monologue'], 'textarea');

	if($UserInfo['param']['identity']) {
		$IdentityHtml = '<label><input type="checkbox" class="checkbox" name="delidentity" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$UserInfo['param']['identity'].'" target="_blank"><img src="'.$UserInfo['param']['identity'].'" width="100"/></a><input type="hidden" value="'.$UserInfo['param']['identity'].'" name="identity"><br />';
	}
	showsetting($Fn_XiangQin->Config['LangVar']['IdentityTitle'], 'identitynew','', 'filetext', '', 0, $IdentityHtml);
	//��ż����
	showtitle($Fn_XiangQin->Config['LangVar']['ConditionTitle']);//��ż����
	
	showsetting($Fn_XiangQin->Config['LangVar']['AdminMinAgeTitle'],array('c_min_age',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['AgeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_min_age'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['AdminMaxAgeTitle'],array('c_max_age',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['AgeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_max_age'],'select');
	
	showsetting($Fn_XiangQin->Config['LangVar']['AdminMinHeightTitle'],array('c_min_height',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['HeightArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_min_height'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['AdminMaxHeightTitle'],array('c_max_height',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['HeightArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_max_height'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['MonthIncomeTitle'],array('c_month_income',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['MonthIncomeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_month_income'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['EducationTitle'],array('c_education',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['EducationArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_education'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['MarriageTitle'],array('c_marriage',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['MarriageArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_marriage'],'select');
	
	showsetting($Fn_XiangQin->Config['LangVar']['WhetherHouse'],array('c_house',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['WhetherHouseArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_house'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['WhetherVehicle'],array('c_vehicle',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['WhetherVehicleArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_vehicle'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['ShapeTitle'],array('c_shape',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['ShapeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_shape'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['WantChildTitle'],array('c_want_child',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['WantChildArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_want_child'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['SmokeTitle'],array('c_smoke',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['SmokeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_smoke'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['DrinkTitle'],array('c_drink',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['SmokeArray'],$Fn_XiangQin->Config['LangVar']['SelectNullTo'])),$UserInfo['condition']['c_drink'],'select');

	//��ż���� End
	if($UserInfo['uid']){
		showsetting('UID', 'uidnew', $UserInfo['uid'], 'text','readonly');
	}else{
		showsetting('UID', 'uidnew', $UserInfo['uid'], 'text');
	}
	
	showsetting($Fn_XiangQin->Config['LangVar']['Click'], 'click', $UserInfo['click'], 'text');

	showsetting('VIP'.$Fn_XiangQin->Config['LangVar']['UserVipTime'], 'vip_time',$UserInfo['vip_time'] ? date('Y-m-d H:i',$UserInfo['vip_time']) : '', 'calendar','','','',1);

	showsetting($Fn_XiangQin->Config['LangVar']['TopDateline'], 'top_dateline',$UserInfo['top_dateline'] ? date('Y-m-d H:i',$UserInfo['top_dateline']) : '', 'calendar','','','',1);

	showsetting($Fn_XiangQin->Config['LangVar']['ExamineState'],array('examine',$Fn_XiangQin->DyadicArray($Fn_XiangQin->Config['LangVar']['ExamineArray'])),$UserInfo['examine'],'select');

	showsetting($Fn_XiangQin->Config['LangVar']['DisplayTitle'], 'display', $UserInfo ? $UserInfo['display'] : 1, 'radio');

	showsetting($Fn_XiangQin->Config['LangVar']['SealTitle'], 'seal',$UserInfo['seal'], 'radio');

	if($UserInfo['dateline']){
	showsetting($Fn_XiangQin->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$UserInfo['dateline']), 'calendar','','','',1);
	}


	showtablefooter(); /*dism��taobao��com*/
	showsubmit('DetailSubmit');
	showformfooter(); /*Dism_taobao-com*/
	echo '<style>.ImgList img{margin:0 0 2px 2px;border:2px solid #fff;height:60px;}</style><script type="text/javascript" src="static/js/calendar.js"></script>';
}else{
	$Data['name'] = addslashes(strip_tags($_GET['name']));
	$Data['sex'] = intval($_GET['sex']);
	$Data['birth'] = $_GET['birth'] ? strtotime($_GET['birth']) : '';
	//����-��Ф
	$Birthext = $Fn_XiangQin->Birthext($Data['birth']);
	$Data['constellation'] = intval($Birthext['constellation']);
	$Data['animal'] = intval($Birthext['animal']);
	$Data['animal'] = intval($Birthext['animal']);
	$Data['age'] = date('Y') - date('Y',$Data['birth']);
	$Data['height'] = intval($_GET['height']);
	$Data['weight'] = intval($_GET['weight']);
	$Data['blood'] = intval($_GET['blood']);
	$Data['ethnic'] = intval($_GET['ethnic']);
	$Data['company'] = addslashes(strip_tags($_GET['company']));
	$Data['education'] = intval($_GET['education']);
	$Data['marriage'] = intval($_GET['marriage']);
	$Data['child'] = intval($_GET['child']);
	$ProfileData['mobile'] = addslashes(strip_tags($_GET['mobile']));
	$Data['month_income'] = intval($_GET['month_income']);
	$Data['mobile_display'] = intval($_GET['mobile_display']);
	$Data['house'] = intval($_GET['house']);
	$Data['vehicle'] = intval($_GET['vehicle']);
	$Data['uid'] = intval($_GET['uidnew']);
	$Data['click'] = intval($_GET['click']);
	$Data['vip_time'] = $_GET['vip_time'] ? strtotime($_GET['vip_time']) : '';
	$Data['top_dateline'] = $_GET['top_dateline'] ? strtotime($_GET['top_dateline']) : '';
	$Data['examine'] = intval($_GET['examine']);
	$Data['display'] = intval($_GET['display']);
	$Data['seal'] = intval($_GET['seal']);
	$Param['wx'] =  addslashes(strip_tags($_GET['wx']));
	$Param['qq'] =  addslashes(strip_tags($_GET['qq']));
	$Param['monologue'] = addslashes(strip_tags($_GET['monologue']));
	$Param['refusal'] = addslashes(strip_tags($_GET['refusal']));
	$Param['vip_title'] = addslashes(strip_tags($_GET['vip_title']));
	$Param['album'] = $_GET['album'] ? array_filter(explode("\n",str_replace("\r","",$_GET['album']))) : '';
	//��ż����
	$ConditionData['uid'] = $Data['uid'];
	$ConditionData['c_min_age'] = intval($_GET['c_min_age']);
	$ConditionData['c_max_age'] = intval($_GET['c_max_age']);
	$ConditionData['c_min_height'] = intval($_GET['c_min_height']);
	$ConditionData['c_max_height'] = intval($_GET['c_max_height']);
	$ConditionData['c_month_income'] = intval($_GET['c_month_income']);
	$ConditionData['c_education'] = intval($_GET['c_education']);
	$ConditionData['c_marriage'] = intval($_GET['c_marriage']);
	$ConditionData['c_house'] = intval($_GET['c_house']);
	$ConditionData['c_vehicle'] = intval($_GET['c_vehicle']);
	$ConditionData['c_shape'] = intval($_GET['c_shape']);
	$ConditionData['c_want_child'] = intval($_GET['c_want_child']);
	$ConditionData['c_smoke'] = intval($_GET['c_smoke']);
	$ConditionData['c_drink'] = intval($_GET['c_drink']);
	//��ż����End
	/* ͷ�� */
	if($_GET['delface'] == 'yes'){
		unlink(DISCUZ_ROOT.$UserInfo['face']);
		$Data['face'] = '';
	}else{
		$Data['face'] = addslashes(strip_tags($_GET['face']));
	}
	if($_FILES['facenew']['size']){
		$FaceFile = $Fn_XiangQin->UploadIconBanner($_FILES['facenew'],DISCUZ_ROOT.$UserInfo['face']);
		if($FaceFile['Errorcode']){
			cpmsg($Fn_XiangQin->Config['LangVar']['ImgErr'],'','error');
		}else{
			$Data['face']  = $FaceFile['Path'];
		}
	}else if($_GET['facenew']){
		$Data['face'] = addslashes(strip_tags($_GET['facenew']));
	}
	/* ͷ�� End */
	/* ����֤��Ƭ */
	if($_GET['delidentity'] == 'yes'){
		unlink(DISCUZ_ROOT.$UserInfo['identity']);
		$Param['identity'] = '';
	}else{
		$Param['identity'] = addslashes(strip_tags($_GET['identity']));
	}
	if($_FILES['identitynew']['size']){
		$IdentityFile = $Fn_XiangQin->UploadIconBanner($_FILES['identitynew'],DISCUZ_ROOT.$UserInfo['identity']);
		if($IdentityFile['Errorcode']){
			cpmsg($Fn_XiangQin->Config['LangVar']['ImgErr'],'','error');
		}else{
			$Param['identity']  = $IdentityFile['Path'];
		}
	}else if($_GET['identitynew']){
		$Param['identity'] = addslashes(strip_tags($_GET['identitynew']));
	}
	/* ����֤��Ƭ End */
	$Data['param'] = serialize($Param);
	$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
	if($Member){
		$Data['username'] = addslashes(strip_tags($Member['username']));
		if($UserInfo){
			if($UserInfo['uid'] != $Data['uid']){//����û��Ƿ����
				$CheckUserInfo = $Fn_XiangQin->GetUserInfo($Data['uid']);
				if($CheckUserInfo){
					cpmsg($Fn_XiangQin->Config['LangVar']['CheckUserErr'],'','error');
				}
			}
			$Data['updateline'] = $ConditionData['updateline'] = time();
			DB::update($Fn_XiangQin->TableMember,$Data,'uid = '.$Data['uid']);
			DB::update('common_member_profile',array('mobile'=>$ProfileData['mobile']),'uid = '.$Data['uid']);
			if($UserInfo['condition']){
				DB::update($Fn_XiangQin->TableCondition,$ConditionData,'uid = '.$Data['uid']);
			}else{
				DB::insert($Fn_XiangQin->TableCondition,$ConditionData);
			}
			cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
		}else{
			$CheckUserInfo = $Fn_XiangQin->GetUserInfo($Data['uid']);
			if($CheckUserInfo){//����û��Ƿ����
				cpmsg($Fn_XiangQin->Config['LangVar']['CheckUserErr'],'','error');
			}else{
				$Data['dateline'] = $Data['updateline'] = $ConditionData['dateline'] = $ConditionData['updateline'] = time();
				DB::insert($Fn_XiangQin->TableMember,$Data);
				DB::insert($Fn_XiangQin->TableCondition,$ConditionData);
				DB::update('common_member_profile',array('mobile'=>$ProfileData['mobile']),'uid = '.$Data['uid']);
				cpmsg($Fn_XiangQin->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}
		}
	}else{
		cpmsg($Fn_XiangQin->Config['LangVar']['NoUserErr'],'','error');
	}
	
}
//From: Dism��taobao��com
?>