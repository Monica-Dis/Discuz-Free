function e(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, t = function() {
    function e(e, n) {
        for (var t = 0; t < n.length; t++) {
            var i = n[t];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(e, i.key, i);
        }
    }
    return function(n, t, i) {
        return t && e(n.prototype, t), i && e(n, i), n;
    };
}(), i = function() {
    function i() {
        e(this, i), this.__init();
    }
    return t(i, [ {
        key: "__init",
        value: function() {
            this.__initTools(), this.__initDefaults(), this.__initMethods();
        }
    }, {
        key: "__initTools",
        value: function() {
            this.tools = {
                isArray: function(e) {
                    return Array.isArray(e);
                },
                isObject: function(e) {
                    return null !== e && "object" === (void 0 === e ? "undefined" : n(e));
                },
                isNumber: function(e) {
                    return "number" == typeof e;
                },
                isDate: function(e) {
                    return "[object Date]" === Object.prototype.toString.call(e);
                },
                isUndefined: function(e) {
                    return void 0 === e;
                },
                toJson: function(e, n) {
                    if (!this.isUndefined(e)) return this.isNumber(n) || (n = n ? 2 : null), JSON.stringify(e, null, n);
                },
                serializeValue: function(e) {
                    return this.isObject(e) ? this.isDate(e) ? e.toISOString() : this.toJson(e) : e;
                },
                encodeUriQuery: function(e, n) {
                    return encodeURIComponent(e).replace(/%40/gi, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%3B/gi, ";").replace(/%20/g, n ? "%20" : "+");
                },
                paramSerializer: function(e) {
                    var t = this;
                    if (!e) return "";
                    var i = [];
                    for (var r in e) {
                        var o = function(n) {
                            var r = e[n];
                            if (null === r || t.isUndefined(r)) return {
                                v: void 0
                            };
                            t.isArray(r) ? r.forEach(function(e) {
                                i.push(t.encodeUriQuery(n) + "=" + t.encodeUriQuery(t.serializeValue(e)));
                            }) : i.push(t.encodeUriQuery(n) + "=" + t.encodeUriQuery(t.serializeValue(r)));
                        }(r);
                        if ("object" === (void 0 === o ? "undefined" : n(o))) return o.v;
                    }
                    return i.join("&");
                },
                buildUrl: function(e, n) {
                    var t = this.paramSerializer(n);
                    return t.length > 0 && (e += (-1 == e.indexOf("?") ? "?" : "&") + t), e;
                }
            };
        }
    }, {
        key: "__initDefaults",
        value: function() {
            this.noPromiseMethods = [ "stopRecord", "pauseVoice", "stopVoice", "pauseBackgroundAudio", "stopBackgroundAudio", "showNavigationBarLoading", "hideNavigationBarLoading", "createAnimation", "createContext", "hideKeyboard", "stopPullDownRefresh" ], 
            this.instanceSource = {
                method: Object.keys(wx)
            };
        }
    }, {
        key: "__initMethods",
        value: function() {
            var e = this;
            for (var n in this.instanceSource) this.instanceSource[n].forEach(function(n, t) {
                e[n] = function() {
                    for (var t = arguments.length, i = Array(t), r = 0; r < t; r++) i[r] = arguments[r];
                    if (-1 !== e.noPromiseMethods.indexOf(n) || "on" === n.substr(0, 2) || /\w+Sync$/.test(n)) {
                        var o;
                        return (o = wx)[n].apply(o, i);
                    }
                    return e.__defaultRequest.apply(e, [ n ].concat(i));
                };
            });
            [ "navigateTo", "redirectTo", "switchTab", "reLaunch" ].forEach(function(n, t) {
                e[n] = function(t, i) {
                    var r = {
                        url: t
                    };
                    return "switchTab" !== n && (r.url = e.tools.buildUrl(t, i)), e.__defaultRequest(n, r);
                };
            }), this.navigateBack = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
                return wx.navigateBack({
                    delta: e
                });
            };
        }
    }, {
        key: "__defaultRequest",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return new Promise(function(t, i) {
                n.success = function(e) {
                    return t(e);
                }, n.fail = function(e) {
                    return i(e);
                }, wx[e](n);
            });
        }
    } ]), i;
}();

exports.default = i;