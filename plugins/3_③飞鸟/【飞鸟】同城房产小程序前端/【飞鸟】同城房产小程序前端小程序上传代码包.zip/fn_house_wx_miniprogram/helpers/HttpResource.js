function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var r = function() {
    function e(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, r, n) {
        return r && e(t.prototype, r), n && e(t, n), t;
    };
}(), n = e(require("../etc/config")), o = e(require("../assets/plugins/wx-resource/lib/index")), i = function() {
    function e(r, n, o, i) {
        t(this, e), Object.assign(this, {
            url: r,
            paramDefaults: n,
            actions: o,
            options: i
        });
    }
    return r(e, [ {
        key: "init",
        value: function() {
            var e = new o.default(this.setUrl(this.url), this.paramDefaults, this.actions, this.options);
            return e.interceptors.use(this.setInterceptors()), e;
        }
    }, {
        key: "setUrl",
        value: function(e) {
            return "" + n.default.basePath + e;
        }
    }, {
        key: "setInterceptors",
        value: function() {
            return {
                request: function(e) {
                    return e.header = e.header || {}, e.header["content-type"] = "application/json", 
                    -1 !== e.url.indexOf("/api") && wx.getStorageSync("token") && (e.header.Authorization = "Bearer " + wx.getStorageSync("token")), 
                    wx.showLoading({
                        title: "加载中"
                    }), e;
                },
                requestError: function(e) {
                    return wx.hideLoading(), Promise.reject(e);
                },
                response: function(e) {
                    return wx.hideLoading(), 401 === e.statusCode && (wx.removeStorageSync("token"), 
                    wx.redirectTo({
                        url: "/pages/login/index"
                    })), e;
                },
                responseError: function(e) {
                    return wx.hideLoading(), Promise.reject(e);
                }
            };
        }
    } ]), e;
}();

exports.default = i;