function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function a(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function r(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var i = function() {
    function e(e, t) {
        for (var a = 0; a < t.length; a++) {
            var r = t[a];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, a, r) {
        return a && e(t.prototype, a), r && e(t, r), t;
    };
}(), s = e(require("../assets/plugins/wx-request/lib/index")), u = e(require("../etc/config")), n = function(e) {
    function n(e) {
        t(this, n);
        var r = a(this, (n.__proto__ || Object.getPrototypeOf(n)).call(this, e));
        return r.$$prefix = "", r.$$path = {
            wechatSignUp: "api.php?id=xigua_hx&ac=user&signup=1",
            wechatSignIn: "api.php?id=xigua_hx&ac=user&signin=1",
            decryptData: "api.php?id=xigua_hx&ac=datadecrypt",
            signIn: "api.php?id=xigua_hx&ac=signin",
            signOut: "api.php?id=xigua_hx&ac=user&signout=1",
            banner: "api.php?id=xigua_hx&ac=banner",
            classify: "api.php?id=xigua_hx&ac=classify",
            goods: "api.php?id=xigua_hx&ac=goods",
            search: "api.php?id=xigua_hx&ac=list_item&",
            cart: "api.php?id=xigua_hx&ac=cart",
            address: "api.php?id=xigua_hx&ac=address",
            order: "api.php?id=xigua_hx&ac=order",
            pub: "api.php?id=xigua_hx&ac=pub",
            upload: "api.php?id=xigua_hx&ac=uploader",
            prepare: "api.php?id=xigua_hx&ac=prepare"
        }, r.interceptors.use({
            request: function(e) {
                return e.header = e.header || {}, e.header["content-type"] = "application/json", 
                -1 !== e.url.indexOf("/api") && wx.getStorageSync("token") && (e.header.Authorization = "Bearer " + wx.getStorageSync("token")), 
                wx.showLoading({
                    title: "加载中"
                }), e;
            },
            requestError: function(e) {
                return wx.hideLoading(), Promise.reject(e);
            },
            response: function(e) {
                return wx.hideLoading(), 401 === e.statusCode && (wx.removeStorageSync("token"), 
                wx.redirectTo({
                    url: "/pages/login/index"
                })), e;
            },
            responseError: function(e) {
                return wx.hideLoading(), Promise.reject(e);
            }
        }), r;
    }
    return r(n, s.default), i(n, [ {
        key: "wechatSignUp",
        value: function(e) {
            return this.postRequest(this.$$path.wechatSignUp, {
                data: e
            });
        }
    }, {
        key: "pub",
        value: function(e) {
            return this.postRequest(this.$$path.pub, {
                data: e
            });
        }
    }, {
        key: "upload",
        value: function(e) {
            return e.url = u.default.basePath + this.$$path.upload, console.log(e), wx.uploadFile(e);
        }
    }, {
        key: "wechatSignIn",
        value: function(e) {
            return this.postRequest(this.$$path.wechatSignIn, {
                data: e
            });
        }
    }, {
        key: "wechatDecryptData",
        value: function(e) {
            return this.postRequest(this.$$path.decryptData, {
                data: e
            });
        }
    }, {
        key: "signIn",
        value: function(e) {
            return this.postRequest(this.$$path.signIn, {
                data: e
            });
        }
    }, {
        key: "startOrder",
        value: function(e) {
            return this.postRequest(this.$$path.prepare, {
                data: e
            });
        }
    }, {
        key: "signOut",
        value: function() {
            return this.postRequest(this.$$path.signOut);
        }
    }, {
        key: "getBanners",
        value: function(e) {
            return this.getRequest(this.$$path.banner, {
                data: e
            });
        }
    }, {
        key: "search",
        value: function(e) {
            return this.getRequest(this.$$path.search, {
                data: e
            });
        }
    }, {
        key: "getGoods",
        value: function(e) {
            return this.getRequest(this.$$path.goods, {
                data: e
            });
        }
    }, {
        key: "getClassify",
        value: function(e) {
            return this.getRequest(this.$$path.classify, {
                data: e
            });
        }
    }, {
        key: "getDetail",
        value: function(e) {
            return this.getRequest(this.$$path.goods + "/" + e);
        }
    }, {
        key: "getCartByUser",
        value: function() {
            return this.getRequest(this.$$path.cart);
        }
    }, {
        key: "addCartByUser",
        value: function(e) {
            return this.postRequest(this.$$path.cart, {
                data: {
                    goods: e
                }
            });
        }
    }, {
        key: "putCartByUser",
        value: function(e, t) {
            return this.putRequest(this.$$path.cart + "/" + e, {
                data: t
            });
        }
    }, {
        key: "delCartByUser",
        value: function(e) {
            return this.deleteRequest(this.$$path.cart + "/" + e);
        }
    }, {
        key: "clearCartByUser",
        value: function() {
            return this.postRequest(this.$$path.cart + "/clear");
        }
    }, {
        key: "getAddressList",
        value: function(e) {
            return this.getRequest(this.$$path.address, {
                data: e
            });
        }
    }, {
        key: "getAddressDetail",
        value: function(e) {
            return this.getRequest(this.$$path.address + "/" + e);
        }
    }, {
        key: "postAddress",
        value: function(e) {
            return this.postRequest(this.$$path.address, e);
        }
    }, {
        key: "putAddress",
        value: function(e, t) {
            return this.putRequest(this.$$path.address + "/" + e, {
                data: t
            });
        }
    }, {
        key: "deleteAddress",
        value: function(e, t) {
            return this.deleteRequest(this.$$path.address + "/" + e);
        }
    }, {
        key: "getDefalutAddress",
        value: function() {
            return this.getRequest(this.$$path.address + "/default");
        }
    }, {
        key: "setDefalutAddress",
        value: function(e) {
            return this.postRequest(this.$$path.address + "/default/" + e);
        }
    }, {
        key: "getOrderList",
        value: function(e) {
            return this.getRequest(this.$$path.order, {
                data: e
            });
        }
    }, {
        key: "getOrderDetail",
        value: function(e) {
            return this.getRequest(this.$$path.order + "/" + e);
        }
    }, {
        key: "postOrder",
        value: function(e) {
            return this.postRequest(this.$$path.order, {
                data: e
            });
        }
    }, {
        key: "putOrder",
        value: function(e, t) {
            return this.putRequest(this.$$path.order + "/" + e, {
                data: t
            });
        }
    }, {
        key: "deleteOrder",
        value: function(e, t) {
            return this.deleteRequest(this.$$path.order + "/" + e);
        }
    } ]), n;
}();

exports.default = n;