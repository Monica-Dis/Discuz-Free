function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var n = e(require("./assets/plugins/wx-validate/WxValidate")), t = e(require("./assets/plugins/wx-service/WxService")), a = e(require("./helpers/HttpResource")), i = e(require("./helpers/HttpService")), r = e(require("./etc/config"));

App({
    onLaunch: function() {},
    onShow: function() {},
    onShareAppMessage: function() {
        return {
            title: r.default.appName,
            desc: r.default.appDesc,
            path: "/pages/index/index"
        };
    },
    onHide: function() {
        console.log("onHide");
    },
    getUserInfo: function() {
        var e = this;
        return this.WxService.login().then(function(n) {
            return e.WxService.getUserInfo();
        }).then(function(n) {
            return console.log(n), e.globalData.encData = n, e.globalData.userInfo = n.userInfo, 
            e.globalData.userInfo;
        });
    },
    globalData: {
        userInfo: null,
        encData: null,
        domain: r.default.domain + "/plugin.php?id=fn_house&formapp=miniprogram",
        ajaxdomain: r.default.domain + "/plugin.php?id=fn_house_wx"
    },
    renderImage: function(e) {
        return e ? -1 !== e.indexOf("http") || -1 !== e.indexOf("https") ? e : "" + this.__config.domain + e : "";
    },
    WxValidate: function(e, t) {
        return new n.default(e, t);
    },
    HttpResource: function(e, n, t, i) {
        return new a.default(e, n, t, i).init();
    },
    HttpService: new i.default({
        baseURL: r.default.basePath
    }),
    WxService: new t.default(),
    __config: r.default
});