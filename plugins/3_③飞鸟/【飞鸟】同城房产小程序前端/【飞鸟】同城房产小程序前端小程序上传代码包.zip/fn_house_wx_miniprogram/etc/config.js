Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = {
    basePath: "https://你的域名/source/plugin/fn_house_wx/",
    color: "#00c07b",
    domain: "https://你的域名/",
    appLogo: "",
    appName: "【飞鸟】同城房产",
    appDesc: "【飞鸟】同城房产",
    appId: "你的小程序的APPID"
};