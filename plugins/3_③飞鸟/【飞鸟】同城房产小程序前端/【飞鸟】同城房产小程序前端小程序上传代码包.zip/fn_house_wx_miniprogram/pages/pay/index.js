var a = getApp();

Page({
    data: {},
    onLoad: function(t) {
        wx.showLoading({
            title: "加载中"
        }), wx.login({
            success: function(e) {
                var n = e.code;
                wx.request({
                    url: a.globalData.ajaxdomain + "&ac=openid&code=" + n,
                    method: "GET",
                    header: {
                        "content-type": "application/x-www-form-urlencoded",
                        Accept: "application/json"
                    },
                    success: function(e) {
                        var n = e.data.openid;
                        wx.request({
                            url: a.globalData.ajaxdomain + "&ac=pay",
                            method: "POST",
                            header: {
                                "content-type": "application/x-www-form-urlencoded",
                                Accept: "application/json"
                            },
                            data: {
                                order_id: t.order_id,
                                openid: n
                            },
                            success: function(e) {
                                wx.hideLoading(), wx.requestPayment({
                                    timeStamp: e.data.timeStamp + "",
                                    nonceStr: e.data.nonceStr,
                                    package: e.data.package,
                                    signType: "MD5",
                                    paySign: e.data.paySign,
                                    success: function(e) {
                                        "requestPayment:ok" == e.errMsg ? wx.showToast({
                                            title: "恭喜您，支付成功",
                                            icon: "success",
                                            duration: 6e3,
                                            success: function() {
                                                var e = getCurrentPages(), n = (e[e.length - 1], e[e.length - 2]);
                                                t.notify_url ? n.setData({
                                                    path: decodeURIComponent(t.notify_url)
                                                }) : n.setData({
                                                    path: a.globalData.domain
                                                }), wx.navigateBack();
                                            }
                                        }) : wx.navigateBack();
                                    },
                                    fail: function(a) {
                                        wx.navigateBack();
                                    },
                                    complete: function(e) {
                                        "requestPayment:ok" == e.errMsg ? wx.showToast({
                                            title: "恭喜您，支付成功",
                                            icon: "success",
                                            duration: 6e3,
                                            success: function() {
                                                var e = getCurrentPages(), n = (e[e.length - 1], e[e.length - 2]);
                                                t.notify_url ? n.setData({
                                                    path: decodeURIComponent(t.notify_url)
                                                }) : n.setData({
                                                    path: a.globalData.domain
                                                }), wx.navigateBack();
                                            }
                                        }) : wx.navigateBack();
                                    }
                                });
                            },
                            fail: function(a) {
                                console.log(a.data);
                            }
                        });
                    }
                });
            }
        });
    }
});