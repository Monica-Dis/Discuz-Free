var a = getApp();

Page({
    data: {
        path: "",
        share_title: "",
        share_desc: ""
    },
    onLoad: function(t) {
        var e = this;
        t.url ? e.setData({
            path: decodeURIComponent(t.url) + (decodeURIComponent(t.url).indexOf("?") >= 0 ? "&" : "?") + "formapp=miniprogram"
        }) : e.setData({
            path: a.globalData.domain
        });
    },
    bindmessage: function(a) {
        var t = this;
        t.setData({
            share_title: a.detail.data[0].share_title
        }), t.setData({
            share_desc: a.detail.data[0].share_desc
        });
    },
    onShareAppMessage: function(a) {
        var t = this;
        return {
            title: t.data.share_title,
            path: "/pages/index/index?url=" + encodeURIComponent(t.data.path),
            success: function(a) {
                wx.showToast({
                    title: "恭喜您，分享成功",
                    icon: "success",
                    duration: 1500
                });
            },
            fail: function(a) {}
        };
    }
});