<?php
/**
 * 
 * DisM!出品 必属精品
 * DisM!应用中心所有 https://dism.Taobao.Com
 * 专业Discuz!应用插件、模板正版采购提供代下载服务、技术支持等全方位服务...
 * 我们致力于为站长提供正版Discuz!应用而努力
 * E-mail: dism.taobao@qq.com
 * 工作时间: 周一到周五早上09:00-12:00, 下午13:00-18:00, 晚上19:30-23:30(周六、日休息)
 * DisM!用户交流群: ①群778390776
 * 
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class FnPay{
	public function __construct() {
		global $_G;
		loadcache('plugin');
		$this->Config['PluginVar'] = (array) $_G['cache']['plugin']['fn_pay'];
		$this->Config['LangVar'] = lang('plugin/fn_pay');
		$this->Config['Static'] = 'source/plugin/fn_pay/static';
		$this->Table = 'fn_pay';
	}
	/**
	 * GetInsertPay 创建支付记录
	 * $OrderId Int 订单id
	 * $Subject String 标题
	 * $Source String 来源
	 * $Identification String 类型
	 * $Money Int 金额
	 * $Paytype String 支付类型
	 * $NotifyUrl String 返回链接
	*/
	public function GetInsertPay($OrderId,$Subject,$Source,$Identification,$Money,$Paytype,$NotifyUrl){
		$OrderId = $this->ArrayAddslashes($OrderId);
		$Subject = $this->ArrayAddslashes($Subject);
		$Source = $this->ArrayAddslashes($Source);
		$Identification = $this->ArrayAddslashes($Identification);
		$Money = $this->ArrayAddslashes($Money);
		$Paytype = $this->ArrayAddslashes($Paytype);
		$NotifyUrl = $this->ArrayAddslashes($NotifyUrl);
		$Result = $this->GetCheckPay($OrderId,$Source,$Identification);
		$Data = array(
			'orderid'=>$OrderId,
			'title'=>$Subject,
			'money'=>$Money,
			'source'=>$Source,
			'identification'=>$Identification,
			'paytype'=>$Paytype,
			'notify_url'=>$NotifyUrl,
			'establish_time'=>time()
		);
		if(!empty($Result)){
			$this->UpdatePay($Result[id],$Data);
			$Id =  $Result[id];
		}else{
			$Id = DB::insert($this->Table,$Data,true);
		}
		return $Id;
	}
	/* 获取支付链接 */
	public function GetPayUrl($OrderId,$Source,$Identification){
		global $_G;
		$OrderId = $this->ArrayAddslashes($OrderId);
		$Source = $this->ArrayAddslashes($Source);
		$Identification = $this->ArrayAddslashes($Identification);
		$FirstSql = 'SELECT * FROM '.DB::table($this->Table).' where orderid = '.$OrderId.' and source = \''.$Source.'\' and identification = \''.$Identification.'\'';
		$PayInfo = DB::fetch_first($FirstSql);
		if($PayInfo){
			$data[PayUrl] = $_G['siteurl'].'plugin.php?id=fn_pay&payid='.$PayInfo[id];
			$data[state] = 1;
			return $data;
		}else{
			$data[status] = $this->Config[PluginVar][No_OrderId];
			return $data;
		}
	}
	/* 支付方式 */
	public function GetPayList(){
		$PayList = array();
		$WxBrowser = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;
		$AppBymeBrowser = strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false;
		if($this->Config['PluginVar']['alipay_switch'] && !$WxBrowser && $this->Config['PluginVar']['alipay_partner'] && $this->Config['PluginVar']['alipay_key']){
			$PayList['AliPay']['Logo'] = 'source/plugin/fn_pay/static/images/alipay.png';
			$PayList['AliPay']['Name'] = $this->Config['LangVar']['AliPayName'];
			$PayList['AliPay']['Type'] = 'alipay';
		}
		if($this->Config['PluginVar']['wx_switch'] && $this->Config['PluginVar']['wx_appid'] && $this->Config['PluginVar']['wx_secret'] && $this->Config['PluginVar']['wx_mchid'] && $this->Config['PluginVar']['wx_key']){
			if(!checkmobile() || $WxBrowser){
				$PayList['WxPay']['Logo'] = 'source/plugin/fn_pay/static/images/wx.png';
				$PayList['WxPay']['Name'] = $this->Config['LangVar']['WxPayName'];
				$PayList['WxPay']['Type'] = 'wx';
			}
		}
		
		if($this->Config['PluginVar']['wx_switch'] && $this->Config['PluginVar']['wx_h5_switch'] && $this->Config['PluginVar']['wx_appid'] && $this->Config['PluginVar']['wx_key'] && $this->Config['PluginVar']['wx_mchid']){
			if(checkmobile() && !$WxBrowser){
				$PayList['WxPay']['Logo'] = 'source/plugin/fn_pay/static/images/wx.png';
				$PayList['WxPay']['Name'] = $this->Config['LangVar']['WxPayName'];
				$PayList['WxPay']['Type'] = 'h5_wx';
			}
		}
		
		if($this->Config['PluginVar']['app_wx_switch'] && $this->Config['PluginVar']['app_wx_appid'] && $this->Config['PluginVar']['app_wx_key'] && $this->Config['PluginVar']['app_wx_mchid']){
			if($AppBymeBrowser){
				$PayList['WxPay']['Logo'] = 'source/plugin/fn_pay/static/images/wx.png';
				$PayList['WxPay']['Name'] = $this->Config['LangVar']['WxPayName'];
				$PayList['WxPay']['Type'] = 'appbyme_wx';
			}
		}

		if($this->Config['PluginVar']['palpay_switch'] && $this->Config['PluginVar']['palpay_number']){
			$PayList['PalPay']['Logo'] = 'source/plugin/fn_pay/static/images/palpay.jpg';
			$PayList['PalPay']['Name'] = $this->Config['LangVar']['PayPalName'];
			$PayList['PalPay']['Type'] = 'palpay';
		}
		
		return $PayList;
	}
	/* 检测订单是否存在 */
	public function GetCheckPay($OrderId,$Source,$Identification){
		return DB::fetch_first('select * from %t where orderid=%s and source=%s and identification=%s',array($this->Table,$OrderId,$Source,$Identification));
	}
	/* 查询单个支付记录 */
	public function GetPayFirst($Id){
		$Id = $this->ArrayAddslashes($Id);
		return DB::fetch_first('select * from %t where id=%d',array($this->Table,$Id));
	}

	/* 更新支付记录 */
	public function UpdatePay($Id,$Array){
		$Id = $this->ArrayAddslashes($Id);
		$Array = $this->ArrayAddslashes($Array);
		return DB::update($this->Table,$Array,'id='.$Id);
	}
	/* 支付记录 */
	public function ShowModuleViewPay(){
		/* 搜索 */
		$StateSelected = array($_GET['state']=>' selected');
		$OrderSelected = array($_GET['order']=>' selected');
		$PayTypeSelected = array($_GET['paytype']=>' selected');
		$SearPayListOption = '<select name="paytype"><option value="">'.$this->Config[LangVar][SelectNull].'</option>';
		foreach($this->GetPayList() as $key => $val){
			$SearPayListOption .= '<option value="'.$val[Type].'" '.$PayTypeSelected[$val[Type]].'>'.$val[Name].'</option>';
		}
		$SearPayListOption .= '</select>';
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$this->Config[LangVar][TransactionIdTitle]}</th><td><input type="text" class="txt" size="15" name="transaction_id" value="$_GET[transaction_id]"></td>
						<th>{$this->Config[LangVar][OrderIdTitle]}</th><td><input type="text" class="txt" size="5" name="orderid" value="$_GET[orderid]"></td>
						<th>{$this->Config[LangVar][Title]}</th><td><input type="text" class="txt" size="5" name="title" value="$_GET[title]"></td>
						<th>{$this->Config[LangVar][SourceTitle]}</th><td><input type="text" class="txt" size="5" name="source" value="$_GET[source]"></td>
						<th>{$this->Config[LangVar][PayTypeTitle]}</th><td>$SearPayListOption</td>
						<th>{$this->Config[LangVar][State]}</th><td><select name="state"><option value="">{$this->Config[LangVar][SelectNull]}</option><option value="1"  $StateSelected[1]>{$this->Config[LangVar][StateIs]}</option><option value="0"$StateSelected[0]>{$this->Config[LangVar][StateNo]}</option></select></td>
						<th>{$this->Config[LangVar][Sort]}</th><td><select name="order"><option value="id"$OrderSelected[id]>ID</option><option value="establish_time"$OrderSelected[establish_time]>{$this->Config[LangVar][EstablishTimeTitle]}</option><option value="pay_time"$OrderSelected[pay_time]>{$this->Config[LangVar][PayTimeTitle]}</option><option value="money"$OrderSelected[money]>{$this->Config[LangVar][MoneyTitle]}</option></select></td>
						<td><input type="submit" name="searchsubmit" value="{$this->Config[LangVar][SearTitle]}" class="btn"></td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* 搜索 end */
		/* 查询条件 */
		$_POST = $this->ArrayAddslashes($_POST);
		$MpUrl = $SearUrl;
		foreach($_POST as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$_GET = $this->ArrayAddslashes($_GET);
		$Where = '';
		if(!empty($_GET[order])){
			$Order = $_GET[order];
		}else{
			$Order = 'id';
		}
		
		if($_GET[state] == '0'|| $_GET[state] == '1'){
			$Where .= ' and state = '.$_GET[state];
		}
		if(!empty($_GET[paytype])){
			$Where .= ' and paytype = \''.$_GET[paytype].'\'';
		}
		
		if($_GET['orderid']){
			$Where .= ' and concat(orderid) like(\'%'.addslashes(dhtmlspecialchars($_GET[orderid])).'%\')';
		}

		if($_GET['transaction_id']){
			$Where .= ' and concat(transaction_id) like(\'%'.addslashes(dhtmlspecialchars($_GET[transaction_id])).'%\')';
		}

		if($_GET['title']){
			$Where .= ' and concat(title) like(\'%'.addslashes(dhtmlspecialchars($_GET[title])).'%\')';
		}

		if($_GET['source']){
			$Where .= ' and concat(source) like(\'%'.addslashes(dhtmlspecialchars($_GET[source])).'%\')';
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 25;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* 查询条件 end */
		$formUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'PayModule', true);
		showformheader($formUrl,'enctype="multipart/form-data"');
		showtableheader($this->Config[LangVar][PayList]);
		showsubtitle(array(
            'ID',$this->Config[LangVar][OrderIdTitle],
			$this->Config[LangVar][TransactionIdTitle],
			$this->Config[LangVar][Title],
			$this->Config[LangVar][MoneyTitle],
			$this->Config[LangVar][SourceTitle],
			$this->Config[LangVar][IdentificationTitle],
			$this->Config[LangVar][PayTypeTitle],
			$this->Config[LangVar][EstablishTimeTitle],
			$this->Config[LangVar][PayTimeTitle],
			$this->Config[LangVar][State]
		));
		$ModulesPayList = $this->GetModulesPay($Page,$Limit,$Where,$Order);
		foreach ($ModulesPayList as $module) {
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$module[id].'" />'.$module[id],
				$module[orderid],
				$module[transaction_id],
				$module[title],
				$module[money],
				$module[source],
				$module[identification],
				$module[paytype],
				$this->GetTime($module[establish_time]),
				$this->GetTime($module[pay_time]),
				$this->GetState($module[state])
			));
		}
		showsubmit('PaySubmit','submit','del','',multi($this->GetModulesPayCount(),$Limit,$Page,$MpUrl));
        showtablefooter();/*Dism·taobao·com*/
		/*Dism_taobao_com*/showformfooter();
		showtagfooter('div');
	}

	/* 支付列表 */
	public function GetModulesPay($Page,$Limit,$Where=null,$Order){
		$fetch_sql = 'SELECT * FROM '.DB::table($this->Table).$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
		return DB::fetch_all($fetch_sql);//返回数据
	}
	/* 支付列表总数 */
	public function GetModulesPayCount($Where=null){
		$fetch_sql = 'SELECT COUNT(*) FROM '.DB::table($this->Table).$Where;
		return DB::result_first($fetch_sql);//返回数据
	}
	/* 时间 */
	public function GetTime($Time){
		if(!empty($Time)){
			return date('Y-m-d H:i:s',$Time);
		}
	}
	/* 状态 */
	public function GetState($State){
		if($State == 0){
			$State = '<span style="color:red;">'.$this->Config[LangVar][StateNo].'</span>';
		}else if($State == 1){
			$State = $this->Config[LangVar][StateIs];
		}
		return $State;
	}
	/* 删除支付记录 */
	public function SubmitModulePay(){
		global $_G;
		$_POST = $this->ArrayAddslashes($_POST);
		// 删除选中轮播图
        if (isset($_POST['delete'])) {
           DB::delete($this->Table,'id in('.implode(',',$_POST['delete']).')');
        }
	}

	/* 判断curl是否开启 */
	public function CurlVersion(){
		if(!function_exists('curl_version')){
			exit('Please open curl extension');
		}
	}
	/* 字符串转义 */
	public function ArrayAddslashes($string) {
		if(is_array($string)){
			foreach($string as $key => $val) {
				$string[$key] = $this->ArrayAddslashes($val);
			}
		} else {
			$string = addslashes($string);
		}
		return $string;
	}
	/* gbk转utf-8 */
	public function IconvGbkUtf($String){
		global $_G;
		if($_G['charset'] == 'gbk'){
			if(is_array($String)){
				foreach($String as $Key => $Val) {
					$String[$Key] = $this->IconvGbkUtf($Val);
				}
			}else{
				$Encoding = mb_detect_encoding($String, array("ASCII",'UTF-8',"GB2312","GBK",'BIG5'));
				$String = mb_convert_encoding($String,'UTF-8',$Encoding);
			}
		}
		return $String;
	}
}
$FnPay = new FnPay;
?>