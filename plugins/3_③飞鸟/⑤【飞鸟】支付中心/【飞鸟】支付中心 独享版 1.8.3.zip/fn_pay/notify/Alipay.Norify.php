<?php
/* *
 * 功能：支付宝服务器异步通知页面
 * 版本：3.3
 * 日期：2017-05-11
 */
define('FN_IN_API', true);
define('CURSCRIPT', 'api');
require_once('../../../../source/class/class_core.php');
$discuz = C::app();
$discuz->init();

require_once("../class/FnPay.Class.php");
require_once("../class/Alipay.Class.php");
require_once("../class/alipay_notify.class.php");
$AliPay = new AliPay;
//计算得出通知验证结果
$alipayNotify = new AlipayNotify($AliPay->Config);
$verify_result = $alipayNotify->verifyNotify();
if($verify_result) {//验证成功	
    //获取支付宝的通知返回参数，可参考技术文档中服务器异步通知参数列表
	//商户订单号
	$out_trade_no = $_POST['out_trade_no'];
	//支付宝交易号
	$trade_no = $_POST['trade_no'];
	//交易状态
	$trade_status = $_POST['trade_status'];
    if($_POST['trade_status'] == 'TRADE_FINISHED' || $_POST['trade_status'] == 'TRADE_SUCCESS') {
		$PayIdTime = explode('_', $_POST['out_trade_no']);
		$Id = $PayIdTime[0];
		$PayFirst = $FnPay->GetPayFirst($Id);//获取支付订单
		require '../../'.$PayFirst['source'].'/notify.class.php';
		$State = NotifyUpdatePay($PayFirst['orderid'],$PayFirst['identification'],$PayFirst['money'],$PayFirst['paytype'],$_POST['trade_no']);
        if($State == true){
			$FnPay->UpdatePay($Id,array('state'=>1,'pay_time'=>time(),'transaction_id'=>$_POST[trade_no]));//更改支付状态
		}
    }
}
else {
    echo "fail";
}
//d'.'is'.'m.ta'.'obao.com
?>