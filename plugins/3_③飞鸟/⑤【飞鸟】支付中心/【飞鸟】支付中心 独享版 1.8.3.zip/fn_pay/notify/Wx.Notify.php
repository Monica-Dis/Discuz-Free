<?php
define('FN_IN_API', true);
define('CURSCRIPT', 'api');
require '../../../../source/class/class_core.php';
if(!$_GET['echostr']){
	$_GET['formhash'] = formhash();
}
$discuz = C::app();
$discuz->init();
loadcache('plugin');
require '../class/FnPay.Class.php';
$FnPay->CurlVersion();//判断curl是否开启
if(function_exists('file_get_contents')){
	$Xml = file_get_contents("php://input");
}else{
	$Xml = $GLOBALS["HTTP_RAW_POST_DATA"];
}
$WxNotify = new WxNotify;
$FromXml = $WxNotify->FromXml($Xml);
$OutTradeNo = $FromXml['out_trade_no'];
$PayIdTime = explode('_', $OutTradeNo);
$Id = $PayIdTime[0];
$PayFirst = $FnPay->GetPayFirst($Id);//获取支付订单
if(in_array($PayFirst['paytype'],array('appbyme_wx'))){
	$Key = $WxNotify->Config['app_wx_key'];
}else if(in_array($PayFirst['paytype'],array('min_wx')) && $PayFirst['source'] == 'fn_house'){
	$Key = $_G['cache']['plugin']['fn_house_wx']['min_key'];	
}else if(in_array($PayFirst['paytype'],array('min_wx')) && $PayFirst['source'] == 'fn_xiangqin'){
	$Key = $_G['cache']['plugin']['fn_xiangqin_wx']['min_key'];	
}else if(in_array($PayFirst['paytype'],array('min_wx')) && $PayFirst['source'] == 'fn_job'){
	$Key = $_G['cache']['plugin']['fn_job_wx']['min_key'];	
}else{
	$Key = $WxNotify->Config['wx_key'];
}
if($WxNotify->GetCheckSign($FromXml,$Key)){
	if($FromXml['result_code'] == 'SUCCESS'){
		require '../../'.$PayFirst['source'].'/notify.class.php';
		$State = NotifyUpdatePay($PayFirst['orderid'],$PayFirst['identification'],$PayFirst['money'],$PayFirst['paytype'],$FromXml['transaction_id']);
        if($State == true){
			$FnPay->UpdatePay($Id,array('state'=>1,'pay_time'=>time(),'transaction_id'=>$FromXml[transaction_id]));//更改支付状态
		}
		$return = array();
		$return['return_code'] = 'SUCCESS';  //SUCCESS/FAIL   SUCCESS表示商户接收通知成功并校验成功
		$return['return_msg'] = 'ok';  //返回信息，如非空，为错误原因
	}else{
		$return = array();
		$return['return_code'] = 'FAIL';  //SUCCESS/FAIL   SUCCESS表示商户接收通知成功并校验成功
		$return['return_msg'] = 'ERROR';  //返回信息，如非空，为错误原因
	}
	echo $WxNotify->ToXml($return);
}
class WxNotify{
	public function __construct() {
		global $_G;
		loadcache('plugin');
		$this->Config = (array)$_G['cache']['plugin']['fn_pay'];
	}
	/**
	 * 输出xml字符
	 * @throws WxPayException
	**/
	public function ToXml($Array){
    	$xml = "<xml>";
		foreach ($Array as $key=>$val){
    		if (is_numeric($val)){
    			$xml.="<".$key.">".$val."</".$key.">";
    		}else{
    			$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
    		}
        }
		$xml.="</xml>";
		return $xml; 
	}
	/**
     * 将xml转为array
     * @param string $xml
     */
	public function FromXml($xml){
        $FromXmlData = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);		
		return $FromXmlData;
	}
	/**
	 * 生成签名
	 * @return 签名，本函数不覆盖sign成员变量，如要设置签名需要调用SetSign方法赋值
	 */
	public function MakeSign($Obj,$Key){
		foreach($Obj as $key => $value){
			$Parameters[$key] = $value;
		}
		//签名步骤一：按字典序排序参数
		ksort($Parameters);
		$string = $this->ToUrlParams($Parameters,true);
		//签名步骤二：在string后加入KEY
		$string = $string . "&key=".$Key;
		//签名步骤三：MD5加密
		$string = md5($string);
		//签名步骤四：所有字符转为大写
		$result = strtoupper($string);
		return $result;
	}
	/**
	 * 
	 * 拼接签名字符串
	 * @param array $urlObj
	 * 
	 * @return 返回已经拼接好的字符串
	 */
	public function ToUrlParams($urlObj,$urlencode){
		$buff = "";
		ksort($urlObj);
		foreach ($urlObj as $k => $v){
			if($urlencode){
			   $v = urlencode($v);
			}
			$buff.=$k."=".$v."&";
		}
		$reqPar;
		if (strlen($buff) > 0){
			$reqPar = substr($buff, 0, strlen($buff)-1);
		}
		return $reqPar;
	}
	/**
	 * 检测签名是否正确
	 * 返回True FALSE
	*/
	public function GetCheckSign($FromXml,$Key){
		$TmpXml = $FromXml;
		unset($TmpXml['sign']);
		$MakeSign = $this->MakeSign($TmpXml,$Key);//本地签名
		if ($FromXml['sign'] == $MakeSign) {
			return TRUE;
		}
		return FALSE;
	}
}
//d'.'is'.'m.ta'.'obao.com
?>