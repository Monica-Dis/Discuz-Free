<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_pay/class/FnPay.Class.php');
$FnPay = new FnPay;
if(!submitcheck('PaySubmit')){
	$FnPay->ShowModuleViewPay();
}else{
	$FnPay->SubmitModulePay();
	cpmsg($FnPay->Config[LangVar][UpdateOk],rawurldecode(cpurl()),'succeed');
}
//d'.'is'.'m.ta'.'obao.com
?>