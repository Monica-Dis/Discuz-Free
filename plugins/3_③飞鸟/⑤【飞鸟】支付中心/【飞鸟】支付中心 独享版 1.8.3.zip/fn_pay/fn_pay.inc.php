<?php
/**
 * 
 * DisM!出品 必属精品
 * DisM!应用中心所有 https://dism.Taobao.Com
 * 专业Discuz!应用插件、模板正版采购提供代下载服务、技术支持等全方位服务...
 * 我们致力于为站长提供正版Discuz!应用而努力
 * E-mail: dism.taobao@qq.com
 * 工作时间: 周一到周五早上09:00-12:00, 下午13:00-18:00, 晚上19:30-23:30(周六、日休息)
 * DisM!用户交流群: ①群778390776
 * 
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once("source/plugin/fn_pay/class/FnPay.Class.php");
$PayId = intval($_GET['payid']);
if(!$PayId){
	exit('No PayId');
}
$FnPay->CurlVersion();//判断curl是否开启
if(in_array($_GET['paytype'],array('alipay','appbyme_wx','wx','h5_wx','palpay'))){
	$FnPay->UpdatePay($PayId,array('paytype'=>$_GET['paytype']));//更改支付类型
}
$PayFirst = $FnPay->GetPayFirst($PayId);//获取支付订单
if($PayFirst['state'] == 1){//支付订单是否已支付
	showmessage($FnPay->Config['LangVar']['OrderIdAlreadyPaid']);
}
if(empty($PayFirst)){//支付订单不存在
	showmessage($FnPay->Config['LangVar']['No_OrderId']);
}
$PayIdTime = $PayId.'_'.time();//
$NotifyUrl = $PayFirst['notify_url'].$PayFirst['orderid'];//返回链接
$Subject = diconv($PayFirst['title'],CHARSET,'UTF-8');//字符串转码
if($PayFirst['paytype'] == 'wx'){//微信充值
	require_once("source/plugin/fn_pay/class/WxPay.Class.php");
	$WxPay = new WxPay;
	if(strpos($_SERVER["HTTP_USER_AGENT"],'MicroMessenger') > 0){//微信浏览器支付
		$openid = $WxPay->GetOpenid();
		$UnifiedOrderParameters = $WxPay->GetUnifiedOrderParameters($PayIdTime,$Subject,$PayFirst['money'],'JSAPI',$openid);
        $JsApiParameters = $WxPay->GetJsApiParameters($UnifiedOrderParameters);
        include template('fn_pay:wx');
        exit;
	}else{//电脑支付
		$UnifiedOrderParameters = $WxPay->GetUnifiedOrderParameters($PayIdTime,$Subject,$PayFirst['money'],'NATIVE');
		$FromXml = $WxPay->FromXml($WxPay->postXmlCurl($WxPay->ToXml($UnifiedOrderParameters),"https://api.mch.weixin.qq.com/pay/unifiedorder"));
		$qrcode_url = $_G['siteurl'].'plugin.php?id=fn_assembly:qrcode&url='.base64_encode($FromXml['code_url']);
		include template('fn_pay:wx_qrcode');
		exit();
	}
}else if($PayFirst['paytype'] == 'h5_wx'){//H5微信支付
	require_once("source/plugin/fn_pay/class/WxPay.Class.php");
	$WxPay = new WxPay;
	$UnifiedOrderParameters = $WxPay->GetUnifiedOrderParameters($PayIdTime,$Subject,$PayFirst['money'],'MWEB');
	$FromXml = $WxPay->FromXml($WxPay->postXmlCurl($WxPay->ToXml($UnifiedOrderParameters),"https://api.mch.weixin.qq.com/pay/unifiedorder"));
	include template('fn_pay:h5_wx');
	exit;
}else if($PayFirst['paytype'] == 'appbyme_wx'){//小云微信支付
	require_once("source/plugin/fn_pay/class/WxPay.Class.php");
	$WxPay = new WxPay;
	$UnifiedOrderParameters = $WxPay->GetUnifiedOrderParameters($PayIdTime,$Subject,$PayFirst['money'],'APP');
	$JsApiParameters = $WxPay->GetJsApiParameters($UnifiedOrderParameters,$PayFirst['paytype']);
	include template('fn_pay:appbyme_wx');
}else if($PayFirst['paytype'] == 'alipay'){
	header("Content-type: text/html; charset=utf-8");
	require_once("class/Alipay.Class.php");
	require_once("class/alipay_submit.class.php");
	$AliPay = new AliPay;
	//商户订单号，商户网站订单系统中唯一订单号，必填
    $out_trade_no = $PayIdTime;
	//订单名称，必填
	$subject = $Subject;
	//付款金额，必填
	$total_fee = $PayFirst['money'];
	//收银台页面上，商品展示的超链接，必填
	$show_url = $_G['siteurl'];
	//商品描述，可空
	$body = '';
	if(!checkmobile()){//支付宝手机支付
		$AliPay->Config['service'] = 'create_direct_pay_by_user';
	}
	$parameter = array(
		"service"       => $AliPay->Config['service'],
		"partner"       => $AliPay->Config['partner'],
		"seller_id"  => $AliPay->Config['seller_id'],
		"payment_type"	=> $AliPay->Config['payment_type'],
		"notify_url"	=> $AliPay->Config['notify_url'],
		"return_url"	=> $AliPay->Config['return_url'],
		"_input_charset"	=> trim(strtolower($AliPay->Config['input_charset'])),
		"out_trade_no"	=> $out_trade_no,
		"subject"	=> $subject,
		"total_fee"	=> $total_fee,
		"show_url"	=> $show_url,
		//"app_pay"	=> "Y",//启用此参数能唤起钱包APP支付宝
		"body"	=> $body,
	);
	//建立请求
	$alipaySubmit = new AlipaySubmit($AliPay->Config);
	$html_text = $alipaySubmit->buildRequestForm($parameter,"get", "确认");
	echo $html_text;
}else if($PayFirst['paytype'] == 'palpay'){
	$PaypalNotifyUrl = $_G['siteurl'] . 'source/plugin/fn_pay/notify/Palpay.Notify.php';
	$ReturnUrl = $_G['siteurl'] . 'source/plugin/fn_pay/notify/Palpay.Return.php';
	$Price = round($PayFirst['money'] * $FnPay->Config['PluginVar']['palpay_rate'], 2);//rmb=>usd
	echo '<br /><form style="text-align:center;" id="form1" name="form1" action="https://www.paypal.com/cgi-bin/webscr" method="post" class="paypal">
				<input type="hidden" name="cmd" value="_xclick">
				<input type="hidden" name="business" value="'.$FnPay->Config['PluginVar']['palpay_number'].'">
				<input type="hidden" name="item_name" value="'.$subject.'">
				<input type="hidden" name="item_number" value="">
				<input type="hidden" name="amount" value="'.$Price.'">
				<input type="hidden" name="currency_code" value="'.$FnPay->Config['PluginVar']['palpay_country'].'">
				<input type="hidden" name="return" value="'.$ReturnUrl.'">
				<input type="hidden" name="notify_url" value="'.$PaypalNotifyUrl.'">
				<input type="hidden" name="cancel_return" value="'.$ReturnUrl.'">
				<input type="hidden" name="invoice" value="'.$PayIdTime.'">
				<input type="hidden" name="charset" value="utf-8">
				<input type="hidden" name="no_shipping" value="1">
				<input type="hidden" name="no_note" value="">
				<input type="hidden" name="rm" value="2">
				</form><br /><script type="text/javascript">function load_submit(){document.form1.submit()}load_submit();</script>
	';
    exit();
}
//d'.'is'.'m.ta'.'obao.com
?>