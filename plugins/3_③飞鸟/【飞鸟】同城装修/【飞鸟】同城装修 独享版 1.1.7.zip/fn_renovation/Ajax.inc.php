<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_renovation/Function.inc.php');

if($_GET['f'] == 'GetAjaxForm' && $_GET['formhash'] == formhash()){//�����ռ�

	echo urldecode(json_encode($Fn_Renovation->GetAjaxForm($_GET)));

}else if($_GET['f'] == 'GetAjaxMaterialForm' && $_GET['formhash'] == formhash()){//���ı����ռ�

	echo urldecode(json_encode($Fn_Renovation->GetAjaxMaterialForm($_GET)));

}else if($_GET['f'] == 'GetAjaxUserFormList' && $_GET['formhash'] == formhash()){//�����б�

	echo CJSON::encode($Fn_Renovation->GetAjaxUserFormList($_GET));

}else if($_GET['f'] == 'GetAjaxUserMaterialFormList' && $_GET['formhash'] == formhash()){//���ı����б�

	echo CJSON::encode($Fn_Renovation->GetAjaxUserMaterialFormList($_GET));

}else if($_GET['f'] == 'GetAjaxCompanyList' && $_GET['formhash'] == formhash()){//��˾�б�

	echo CJSON::encode($Fn_Renovation->GetAjaxCompanyList($_GET));

}else if($_GET['f'] == 'GetAjaxCommunityList' && $_GET['formhash'] == formhash()){//С���б�

	echo CJSON::encode($Fn_Renovation->GetAjaxCommunityList($_GET));

}else if($_GET['f'] == 'GetAjaxBuildList' && $_GET['formhash'] == formhash()){//�����б�

	echo CJSON::encode($Fn_Renovation->GetAjaxBuildList($_GET));

}else if($_GET['f'] == 'GetAjaxCaseList' && $_GET['formhash'] == formhash()){//�����б�

	echo CJSON::encode($Fn_Renovation->GetAjaxCaseList($_GET));

}else if($_GET['f'] == 'GetAjaxBuildInfoList' && $_GET['formhash'] == formhash()){//������Ϣ�б�

	echo CJSON::encode($Fn_Renovation->GetAjaxBuildInfoList($_GET));

}else if($_GET['f'] == 'GetAjaxMaterialCompanyList' && $_GET['formhash'] == formhash()){//���Ĺ�˾�б�
	
	echo CJSON::encode($Fn_Renovation->GetAjaxMaterialCompanyList($_GET));

}else if($_GET['f'] == 'GetAjaxMaterialCaseList' && $_GET['formhash'] == formhash()){//���İ����б�
	
	echo CJSON::encode($Fn_Renovation->GetAjaxMaterialCaseList($_GET));

}else if($_GET['f'] == 'GetAjaxGoodsList' && $_GET['formhash'] == formhash()){//��Ʒ�б�
	
	echo CJSON::encode($Fn_Renovation->GetAjaxGoodsList($_GET));

}else if($_GET['f'] == 'GetAjaxArtisanList' && $_GET['formhash'] == formhash()){//ʦ���б�

	echo CJSON::encode($Fn_Renovation->GetAjaxArtisanList($_GET));

}else if($_GET['f'] == 'GetAjaxUserCompany' && $_GET['formhash'] == formhash() && $_G['uid']){//�༭��˾

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserCompany($_GET)));

}else if($_GET['f'] == 'GetAjaxUserCase' && $_GET['formhash'] == formhash() && $_G['uid']){//�༭����

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserCase($_GET)));

}else if($_GET['f'] == 'GetAjaxUserCaseOp' && $_GET['formhash'] == formhash()  && $_GET['Op'] && $_GET['case_id'] && $_GET['company_id'] && $_G['uid']){//��������

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserCaseOp($_GET['Op'],$_GET['case_id'],$_GET['company_id'],$_GET['field'],$_GET['value'])));

}else if($_GET['f'] == 'GetAjaxUserRefreshCase' && $_GET['formhash'] == formhash() && $_G['uid']){//���ˢ�·�Դ
	
	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserRefreshCase($_GET)));

}else if($_GET['f'] == 'GetAjaxRefreshCase' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['case_id']){//����ˢ�°���

	echo json_encode($Fn_Renovation->GetAjaxPayLog(array('event'=>'refresh_case','money'=>$Fn_Renovation->Config['PluginVar']['CaseRefreshMoney'],'case_id'=>$_GET['case_id'])));

}else if($_GET['f'] == 'GetAjaxUserBuild' && $_GET['formhash'] == formhash() && $_G['uid']){//�༭�ڽ�����

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserBuild($_GET)));

}else if($_GET['f'] == 'GetAjaxUserBuildOp' && $_GET['formhash'] == formhash()  && $_GET['Op'] && $_GET['build_id'] && $_GET['company_id'] && $_G['uid']){//��������

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserBuildOp($_GET['Op'],$_GET['build_id'],$_GET['company_id'],$_GET['field'],$_GET['value'])));

}else if($_GET['f'] == 'GetAjaxUserBuildInfo' && $_GET['formhash'] == formhash() && $_G['uid']){//�༭�ڽ����ؽ���

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserBuildInfo($_GET)));

}else if($_GET['f'] == 'GetAjaxUserBuildInfoOp' && $_GET['formhash'] == formhash()  && $_GET['Op'] && $_GET['iid'] && $_GET['company_id'] && $_G['uid']){//��������

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserBuildInfoOp($_GET['Op'],$_GET['iid'],$_GET['company_id'],$_GET['field'],$_GET['value'])));

}else if($_GET['f'] == 'GetAjaxUserDesign' && $_GET['formhash'] == formhash() && $_G['uid']){//�༭���ʦ

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserDesign($_GET)));

}else if($_GET['f'] == 'GetAjaxUserDesignOp' && $_GET['formhash'] == formhash()  && $_GET['Op'] && $_GET['design_id'] && $_GET['company_id'] && $_G['uid']){//�������ʦ

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserDesignOp($_GET['Op'],$_GET['design_id'],$_GET['company_id'],$_GET['field'],$_GET['value'])));

}else if($_GET['f'] == 'GetAjaxUserMaterialCompany' && $_GET['formhash'] == formhash() && $_G['uid']){//�༭��˾

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserMaterialCompany($_GET)));

}else if($_GET['f'] == 'GetAjaxUserMaterialCase' && $_GET['formhash'] == formhash() && $_G['uid']){//�༭��Ʒ

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserMaterialCase($_GET)));

}else if($_GET['f'] == 'GetAjaxUserMaterialCaseOp' && $_GET['formhash'] == formhash()  && $_GET['Op'] && $_GET['cid'] && $_GET['company_id'] && $_G['uid']){//�������İ���

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserMaterialCaseOp($_GET['Op'],$_GET['cid'],$_GET['company_id'],$_GET['field'],$_GET['value'])));

}else if($_GET['f'] == 'GetAjaxUserGoods' && $_GET['formhash'] == formhash() && $_G['uid']){//�༭��Ʒ

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserGoods($_GET)));

}else if($_GET['f'] == 'GetAjaxUserGoodsOp' && $_GET['formhash'] == formhash()  && $_GET['Op'] && $_GET['gid'] && $_GET['company_id'] && $_G['uid']){//������Ʒ

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserGoodsOp($_GET['Op'],$_GET['gid'],$_GET['company_id'],$_GET['field'],$_GET['value'])));

}else if($_GET['f'] == 'GetAjaxUserArtisan' && $_GET['formhash'] == formhash() && $_G['uid']){//�༭ʦ��

	echo urldecode(json_encode($Fn_Renovation->GetAjaxUserArtisan($_GET)));

}else if($_GET['f'] == 'GetAjaxSendOut' && $_GET['formhash'] == formhash() && $_G['uid']){//������֤��
	echo urldecode(json_encode($Fn_Renovation->GetAjaxSendOut($_GET['mobile'])));

}else if($_GET['f'] == 'GetAjaxAdminEditFields' && $_GET['formhash'] == formhash() && $_G['uid']){//����Ա�޸��ֶ�ֵ
	
	echo urldecode(json_encode($Fn_Renovation->GetAjaxAdminEditFields($_GET['table'],$_GET['aid'],$_GET['field'],$_GET['val'])));

}else if($_GET['f'] == 'GetAjaxRefreshArtisan' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['aid']){//ˢ��ʦ��
	
	echo json_encode($Fn_Renovation->GetAjaxPayLog(array('event'=>'refresh_artisan','money'=>$Fn_Renovation->Config['PluginVar']['ArtisanRefreshMoney'],'aid'=>$_GET['aid'])));

}else if($_GET['f'] == 'GetAjaxTopArtisan' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['aid'] && $_GET['money']){//�ö�ʦ��

	echo json_encode($Fn_Renovation->GetAjaxPayLog(array('event'=>'top_artisan','money'=>$_GET['money'],'day'=>$_GET['day'],'aid'=>$_GET['aid'])));

}else if($_GET['f'] == 'GetAjaxBuyStoreLevel' && $_GET['formhash'] == formhash() && $_G['uid']){//��ͨ�ŵ�/��˾�ײ�
	
	echo urldecode(json_encode($Fn_Renovation->GetAjaxBuyStoreLevel($_GET)));

}else if($_GET['f'] == 'GetAjaxCompanyRefresh' && $_GET['formhash'] == formhash() && $_G['uid']){//ˢ��װ�޹�˾

	echo urldecode(json_encode($Fn_Renovation->GetAjaxCompanyRefresh($_GET)));

}else if($_GET['f'] == 'GetAjaxCompanyTop' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['company_id']){//�ö�װ�޹�˾

	echo json_encode($Fn_Renovation->GetAjaxPayLog(array('event'=>'company_top','money'=>$_GET['money'],'day'=>$_GET['day'],'company_id'=>$_GET['company_id'])));

}else if($_GET['f'] == 'GetAjaxBuyStoreLevelMaterial' && $_GET['formhash'] == formhash() && $_G['uid']){//��ͨ�ŵ�/��˾�ײ�
	
	echo urldecode(json_encode($Fn_Renovation->GetAjaxBuyStoreLevelMaterial($_GET)));

}else if($_GET['f'] == 'GetAjaxMaterialCompanyRefresh' && $_GET['formhash'] == formhash() && $_G['uid']){//ˢ�½��Ĺ�˾

	echo urldecode(json_encode($Fn_Renovation->GetAjaxMaterialCompanyRefresh($_GET)));

}else if($_GET['f'] == 'GetAjaxMaterialCompanyTop' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['company_id']){//�ö����Ĺ�˾

	echo json_encode($Fn_Renovation->GetAjaxPayLog(array('event'=>'material_company_top','money'=>$_GET['money'],'day'=>$_GET['day'],'company_id'=>$_GET['company_id'])));

}else if($_GET['f'] == 'GetAjaxUpload' && $_GET['formhash'] == formhash()){//�ϴ�ͼƬ

	echo urldecode(json_encode(GetAjaxUpload($_FILES)));
}
//From: dis'.'m.tao'.'bao.com
?>