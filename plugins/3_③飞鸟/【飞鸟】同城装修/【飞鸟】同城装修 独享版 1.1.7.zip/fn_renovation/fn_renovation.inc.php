<?php
/**
 *	[������װ��(fn_renovation.{modulename})] (C)2016-2099 Powered by ��������.
 *	Version: 1.0.0
 *	Date: 2019-12-9 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_renovation/Function.inc.php');

$navtitle = $metakeywords = $metadescription = $Fn_Renovation->Config['PluginVar']['Title'];

$_GET['m'] = $_GET['m'] ? $_GET['m'] : 'index';

$Mod = array('index','material','free_quote','design','inspect','list_company','list_case','list_community','list_build','list_artisan','list_material_company','list_goods','list_material_case','view_company','view_build','view_design','view_case','view_community','view_artisan','view_material_company','view_goods','view_material_case','user','user_company','user_case_list','user_case','user_build_list','user_build','user_build_info_list','user_build_info','user_design','user_design_list','buy_store_level','user_form_list','user_artisan','user_material','user_material_company','buy_store_level_material','user_material_form_list','user_material_case_list','user_goods_list','user_goods','user_material_case');

if(!in_array($_GET['m'],$Mod)){
	exit('No Data');
}

/* ���Զ�ά����� */
if(!checkmobile() && (!$Fn_Renovation->Config['PluginVar']['PcQrSwitch'] || in_array($_GET['m'],array('material','free_quote','design','inspect','list_company','list_case','list_community','list_build','list_artisan','list_material_company','list_goods','list_material_case','view_company','view_build','view_design','view_case','view_community','view_artisan','view_material_company','view_goods','view_material_case','user_artisan')))){
	$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
	if(!file_exists($File) || !filesize($File)) {
		@require_once libfile('class/qrcode','plugin/fn_assembly');
		QRcode::png($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"], $File, QR_ECLEVEL_L,5,2);
	}
	$QrCode = base64_encode(file_get_contents($File));
	@unlink($File);
	include template('fn_renovation:index_qrcode');
	exit();
}
/* ���Զ�ά����� End */

if(!$_G['uid'] && in_array($_GET['m'],array('user','user_company','user_case_list','user_case','user_build_list','user_build','user_build_info_list','user_build_info','user_design','user_design_list','buy_store_level','user_form_list','user_artisan','user_material','user_material_company','user_material_form_list','buy_store_level_material','user_material_case_list','user_goods_list','user_goods','user_material_case'))){
	Fn_Login();
}else if(in_array($_GET['m'],array('user_case_list','user_case','user_build_list','user_build','user_build_info_list','user_build_info','user_design','user_design_list','buy_store_level','user_form_list'))){
	$CompanyItem = $Fn_Renovation->GetUserCompanyAdmin($_GET['company_id']);
}else if(in_array($_GET['m'],array('user_goods_list','user_goods','user_material_case','user_material_case_list','buy_store_level_material','user_material_form_list'))){
	$CompanyItem = $Fn_Renovation->GetUserMaterialCompanyAdmin($_GET['company_id']);
}

$UserInfo = $_G['uid'] ? $Fn_Renovation->GetUserInfo() : array();
$UserInfo['company'] = $_GET['company_id'] ? $UserInfo['company_list'][$_GET['company_id']] : $UserInfo['company'];

$FooterNav = $Fn_Renovation->Config['PluginVar']['footer_nav'];

$FooterAddNav = $Fn_Renovation->Config['PluginVar']['add_nav'];

if(in_array($_GET['m'],array('index','free_quote','design'))){
	$FormCompanyList = $Fn_Renovation->GetAjaxCompanyList(array('limit'=>100));
	$FormCompanyListJosn = array();
	foreach ($FormCompanyList as $Key => $Val) {
		$FormCompanyListJosn[$Key]['title']= urlencode($Val['name']);
		$FormCompanyListJosn[$Key]['value']= $Val['id'];
	}
	$FormCompanyListJosn = $FormCompanyListJosn ? urldecode(json_encode($FormCompanyListJosn)) : '';
}


if($_GET['m'] == 'index'){//��ҳ
	//���ͼ
	$Banners = $Fn_Renovation->Config['PluginVar']['banners'];
	$IndexNav = $Fn_Renovation->Config['PluginVar']['navs'];
	
	$MinIndexNav = $Fn_Renovation->Config['PluginVar']['min_index_nav'];

	$Fn_Renovation->Config['PluginVar']['count_family_tips'] = str_replace(array('{count}'),array($Fn_Renovation->Config['PluginVar']['count_family'] + $Fn_Renovation->GetCountForm(1)),$Fn_Renovation->Config['PluginVar']['count_family_tips']);
	$HuXingData = MobileSelectJs($Fn_Renovation->Config['LangVar']['RoomArray'],$Fn_Renovation->Config['LangVar']['OfficeArray'],$Fn_Renovation->Config['LangVar']['TouletArray'],$Fn_Renovation->Config['LangVar']['BalconyArray']);

	$IndexCompanyHotList = $Fn_Renovation->GetIndexCompanyHotList();

	

	$PanoramaCase = $Fn_Renovation->Config['PluginVar']['HomePanorama'] ? $Fn_Renovation->GetAjaxCaseList(array('display'=>1,'class'=>2,'limit'=>$Fn_Renovation->Config['PluginVar']['index_case2_num'])) : '';

	$MaterialCompanyHotList = $Fn_Renovation->Config['PluginVar']['HomeMaterialCompany'] ? $Fn_Renovation->GetIndexMaterialCompanyHotList() : '';

	$Goods = $Fn_Renovation->Config['PluginVar']['HomeGoods'] ? $Fn_Renovation->GetAjaxGoodsList(array('display'=>1,'index'=>1,'limit'=>$Fn_Renovation->Config['PluginVar']['material_index_goods_num'])) : '';

	if(!checkmobile()){//���԰�
		$PcHomeSeo = array_filter(explode("#",$Fn_Renovation->Config['PluginVar']['PcHomeSeo']));
		$FriendLink = array_filter(explode("\r\n",$Fn_Renovation->Config['PluginVar']['PcFriendLink']));
		$FormContent = array_filter(explode("\r\n",$Fn_Renovation->Config['PluginVar']['PcFormContent']));
		$navtitle = $PcHomeSeo[0] ? $PcHomeSeo[0] : $navtitle;
		$metakeywords = $PcHomeSeo[1] ? $PcHomeSeo[1] : $navtitle;
		$metadescription = $PcHomeSeo[2] ? $PcHomeSeo[2] : $navtitle;
		$Case = $Fn_Renovation->GetAjaxCaseList(array('display'=>1,'class'=>1,'limit'=>6));
	}else{
		$Case = $Fn_Renovation->Config['PluginVar']['HomeCase'] ? $Fn_Renovation->GetAjaxCaseList(array('display'=>1,'class'=>1,'limit'=>$Fn_Renovation->Config['PluginVar']['index_case_num'])) : '';
	}

}else if($_GET['m'] == 'free_quote'){//��ѱ���

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['free_quote_title'];

	$Fn_Renovation->Config['PluginVar']['count_family_tips'] = str_replace(array('{count}'),array($Fn_Renovation->Config['PluginVar']['count_family'] + $Fn_Renovation->GetCountForm(1)),$Fn_Renovation->Config['PluginVar']['count_family_tips']);

	$HuXingData = MobileSelectJs($Fn_Renovation->Config['LangVar']['RoomArray'],$Fn_Renovation->Config['LangVar']['OfficeArray'],$Fn_Renovation->Config['LangVar']['TouletArray'],$Fn_Renovation->Config['LangVar']['BalconyArray']);

	$ImgsArray = TextareaArray($Fn_Renovation->Config['PluginVar']['free_quote_imgs']);

	$TextsArray = TextareaArray($Fn_Renovation->Config['PluginVar']['free_quote_texts']);

	$StyleTextArray = urldecode(json_encode(ArrayUrlencode(array_filter(explode("|",$Fn_Renovation->Config['PluginVar']['free_quote_style_text'])))));

	$StyleImgArray = array();
	foreach(array_filter(explode("\r\n",$Fn_Renovation->Config['PluginVar']['free_quote_style_img'])) as $Key => $Val) {
		$StyleImgArray[] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
	}
	$PreviewStyleImg = $StyleImgArray ? json_encode($StyleImgArray) : '';
	
	$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m']);
	$Fn_Renovation->Config['WxShare']['WxTitle'] = $navtitle.'_'.$Fn_Renovation->Config['PluginVar']['Title'];

}else if($_GET['m'] == 'design'){//�������

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['design_title'];
		
	$ContentImgsArray = array_filter(explode("\r\n",$Fn_Renovation->Config['PluginVar']['design_content']));

	$ServiceImgsArray = array_filter(explode("\r\n",$Fn_Renovation->Config['PluginVar']['design_service_content']));

	$Fn_Renovation->Config['PluginVar']['design_form_tips'] = str_replace(array('{count}'),array($Fn_Renovation->Config['PluginVar']['count_family'] + $Fn_Renovation->GetCountForm(2)),$Fn_Renovation->Config['PluginVar']['design_form_tips']);

	$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m']);
	$Fn_Renovation->Config['WxShare']['WxTitle'] = $navtitle.'_'.$Fn_Renovation->Config['PluginVar']['Title'];

}else if($_GET['m'] == 'inspect'){//רҵ�鷿
	
	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['inspect_title'];

	$ImgsArray = TextareaArray($Fn_Renovation->Config['PluginVar']['inspect_imgs']);

	$TextsArray = TextareaArray($Fn_Renovation->Config['PluginVar']['inspect_texts']);

	$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m']);
	$Fn_Renovation->Config['WxShare']['WxTitle'] = $navtitle.'_'.$Fn_Renovation->Config['PluginVar']['Title'];

}else if($_GET['m'] == 'list_company'){//��˾�б�
	
	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['list_company_title'];

	$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m']);
	$Fn_Renovation->Config['WxShare']['WxTitle'] = $navtitle.'_'.$Fn_Renovation->Config['PluginVar']['Title'];

}else if($_GET['m'] == 'list_community'){//С���б�
	
	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['list_community_title'];

	$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m']);
	$Fn_Renovation->Config['WxShare']['WxTitle'] = $navtitle.'_'.$Fn_Renovation->Config['PluginVar']['Title'];

}else if($_GET['m'] == 'list_case'){//�����б�

	$_GET['class'] = in_array($_GET['class'],array('1','2','3')) ? $_GET['class'] : 1;

	$CompanyItem = $Fn_Renovation->GetViewCompanythread($_GET['company_id']);

	$CommunityItem = $Fn_Renovation->GetViewCommunitythread($_GET['community_id']);

	$navtitle = $metadescription = $metakeywords = $CompanyItem['name'].$Fn_Renovation->Config['LangVar']['list_case_title'][$_GET['class']];

	$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Config['ListCaseUrl'].'&'.http_build_query(array('class'=>$_GET['class'],'company_id'=>$_GET['company_id'],'community_id'=>$_GET['community_id']));
	$Fn_Renovation->Config['WxShare']['WxTitle'] = $navtitle.'_'.$Fn_Renovation->Config['PluginVar']['Title'];

}else if($_GET['m'] == 'list_build'){//�����б�

	$CompanyItem = $Fn_Renovation->GetViewCompanythread($_GET['company_id']);

	$CommunityItem = $Fn_Renovation->GetViewCommunitythread($_GET['community_id']);

	$navtitle = $metadescription = $metakeywords = $CompanyItem['name'].$Fn_Renovation->Config['LangVar']['list_build_title'];

	$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Config['ListBuildUrl'].'&'.http_build_query(array('company_id'=>$_GET['company_id'],'community_id'=>$_GET['community_id']));
	$Fn_Renovation->Config['WxShare']['WxTitle'] = $navtitle.'_'.$Fn_Renovation->Config['PluginVar']['Title'];

}else if($_GET['m'] == 'list_artisan'){//ʦ���б�
	
	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['list_artisan_title'];
	$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m']);
	$Fn_Renovation->Config['WxShare']['WxTitle'] = $navtitle.'_'.$Fn_Renovation->Config['PluginVar']['Title'];

}else if($_GET['m'] == 'view_company'){//��˾����

	$Item = $Fn_Renovation->GetViewCompanythread($_GET['cid']);

	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['name'];
		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_Renovation->Admin){
			$Msg = $Fn_Renovation->Config['LangVar']['CompanyInAudit'];
		}else{

			$PreviewBanner = $Item['banner'] ? json_encode($Item['banner']) : '';//ͼƬ��

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Renovation->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Renovation->TableCompany,$Item['id'],$ClickNum);

			//����
			$Case = $Fn_Renovation->GetAjaxCaseList(array('display'=>1,'company_id'=>$Item['id'],'class'=>1,'limit'=>$Fn_Renovation->Config['PluginVar']['company_case_num']));
			$CaseCount = str_replace(array('{count}'),array($Case['count']),$Fn_Renovation->Config['LangVar']['CaseCount']);

			//ȫ������
			$PanoramaCase = $Fn_Renovation->GetAjaxCaseList(array('display'=>1,'company_id'=>$Item['id'],'class'=>2,'limit'=>$Fn_Renovation->Config['PluginVar']['company_case2_num']));
			$PanoramaCaseCount = str_replace(array('{count}'),array($PanoramaCase['count']),$Fn_Renovation->Config['LangVar']['CaseCount']);

			//����
			$Build = $Fn_Renovation->GetAjaxBuildList(array('display'=>1,'company_id'=>$Item['id'],'limit'=>$Fn_Renovation->Config['PluginVar']['company_build_num']));
			$Fn_Renovation->Config['LangVar']['BuildCount'] = str_replace(array('{count}'),array($Build['count']),$Fn_Renovation->Config['LangVar']['BuildCount']);

			//����Ŷ�
			$DesignList = $Fn_Renovation->GetCompanyDesignList($Item['id']);
			$Fn_Renovation->Config['LangVar']['TeamDesignCount'] = str_replace(array('{count}'),array(count($DesignList)),$Fn_Renovation->Config['LangVar']['TeamDesignCount']);

			//����
			$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m'],array('cid'=>$Item['id']));
			$Fn_Renovation->Config['WxShare']['WxTitle'] = str_replace(array('{name}','{address}'),array($Item['name'],$Item['province_text'].$Item['community']),$Fn_Renovation->Config['PluginVar']['company_share_title']);
			$Fn_Renovation->Config['WxShare']['WxDes'] = str_replace(array('{name}','{address}'),array($Item['name'],$Item['province_text'].$Item['community']),$Fn_Renovation->Config['PluginVar']['company_share_desc']);
			$Fn_Renovation->Config['WxShare']['WxImg'] = $Item['logo'] ? $Item['logo'] : $Fn_Renovation->Config['WxShare']['WxImg'];
			//����End
		}
	}else{
		$navtitle = $Msg = $Fn_Renovation->Config['LangVar']['NoViewCompanyData'];
	}

}else if($_GET['m'] == 'view_case'){//����

	$Item = $Fn_Renovation->GetViewCasethread($_GET['cid']);

	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['title'];
		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_Renovation->Admin){
			$Msg = $Fn_Renovation->Config['LangVar']['CaseInAudit'];
		}else{
			
			$Fn_Renovation->Config['LangVar']['PublishedIn'] = str_replace(array('{time}'),array(FormatDate($Item['updateline'],'Y-m-d H:i')),$Fn_Renovation->Config['LangVar']['PublishedIn']);

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Renovation->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Renovation->TableCase,$Item['id'],$ClickNum);

			//����
			$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m'],array('cid'=>$Item['id']));
			$Fn_Renovation->Config['WxShare']['WxTitle'] = $Item['title'].'_'.$Fn_Renovation->Config['PluginVar']['Title'];
			$Fn_Renovation->Config['WxShare']['WxImg'] = $Item['thumbnail'] ? $Item['thumbnail'] : $Fn_Renovation->Config['WxShare']['WxImg'];
			//����End
		}
	}else{
		$navtitle = $Msg = $Fn_Renovation->Config['LangVar']['NoViewCaseData'];
	}

}else if($_GET['m'] == 'view_build'){//ʩ������
	$Item = $Fn_Renovation->GetViewBuildthread($_GET['bid']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['title'];
		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_Renovation->Admin){
			$Msg = $Fn_Renovation->Config['LangVar']['BuildInAudit'];
		}else{

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Renovation->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Renovation->TableBuild,$Item['id'],$ClickNum);

			//����
			$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m'],array('bid'=>$Item['id']));
			$Fn_Renovation->Config['WxShare']['WxTitle'] = $Item['title'].'_'.$Fn_Renovation->Config['PluginVar']['Title'];
			$Fn_Renovation->Config['WxShare']['WxImg'] = $Item['company']['logo'] ? $Item['company']['logo'] : $Fn_Renovation->Config['WxShare']['WxImg'];
			//����End
		}
	}else{
		$navtitle = $Msg = $Fn_Renovation->Config['LangVar']['NoViewBuildData'];
	}
}else if($_GET['m'] == 'view_design'){//���ʦ
	$Item = $Fn_Renovation->GetViewDesignthread($_GET['did']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['name'].$Fn_Renovation->Config['LangVar']['Designer'];
		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_Renovation->Admin){
			$Msg = $Fn_Renovation->Config['LangVar']['DesignInAudit'];
		}else{
			
			$PreviewFace = $Item['face'] ? json_encode(array($Item['face'])) : '';//ͷ��

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Renovation->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Renovation->TableDesign,$Item['id'],$ClickNum);

			//����
			$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m'],array('did'=>$Item['id']));
			$Fn_Renovation->Config['WxShare']['WxTitle'] = $Item['name'].$Fn_Renovation->Config['LangVar']['Designer'].'_'.$Fn_Renovation->Config['PluginVar']['Title'];
			$Fn_Renovation->Config['WxShare']['WxImg'] = $Item['face'] ? $Item['face'] : $Fn_Renovation->Config['WxShare']['WxImg'];
			//����End
		}
	}else{
		$navtitle = $Msg = $Fn_Renovation->Config['LangVar']['NoViewDesignData'];
	}
}else if($_GET['m'] == 'view_community'){//С��
	$Item = $Fn_Renovation->GetViewCommunitythread($_GET['cid']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['name'];
		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_Renovation->Admin){
			$Msg = $Fn_Renovation->Config['LangVar']['CommunityInAudit'];
		}else{
			
			$PreviewThumbnail = $Item['thumbnail'] ? json_encode(array($Item['thumbnail'])) : '';//ͼƬ��
			
			//����
			$Case = $Fn_Renovation->GetAjaxCaseList(array('display'=>1,'community_id'=>$Item['id'],'class'=>1,'limit'=>$Fn_Renovation->Config['PluginVar']['community_case_num']));
			$CaseCount = str_replace(array('{count}'),array($Case['count']),$Fn_Renovation->Config['LangVar']['CaseCount']);

			//ȫ������
			$PanoramaCase = $Fn_Renovation->GetAjaxCaseList(array('display'=>1,'community_id'=>$Item['id'],'class'=>2,'limit'=>$Fn_Renovation->Config['PluginVar']['community_case2_num']));
			$PanoramaCaseCount = str_replace(array('{count}'),array($PanoramaCase['count']),$Fn_Renovation->Config['LangVar']['CaseCount']);

			//����
			$Build = $Fn_Renovation->GetAjaxBuildList(array('display'=>1,'community_id'=>$Item['id'],'limit'=>$Fn_Renovation->Config['PluginVar']['community_build_num']));
			$Fn_Renovation->Config['LangVar']['BuildCount'] = str_replace(array('{count}'),array($Build['count']),$Fn_Renovation->Config['LangVar']['BuildCount']);

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Renovation->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Renovation->TableCommunity,$Item['id'],$ClickNum);

			//����
			$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m'],array('cid'=>$Item['id']));
			$Fn_Renovation->Config['WxShare']['WxTitle'] = $Item['name'].'_'.$Fn_Renovation->Config['PluginVar']['Title'];
			$Fn_Renovation->Config['WxShare']['WxImg'] = $Item['thumbnail'] ? $Item['thumbnail'] : $Fn_Renovation->Config['WxShare']['WxImg'];
			//����End
		}
	}else{
		$navtitle = $Msg = $Fn_Renovation->Config['LangVar']['NoViewCommunityData'];
	}
}else if($_GET['m'] == 'view_artisan'){//ʦ��
	$Item = $Fn_Renovation->GetViewArtisanthread($_GET['aid']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['name'];
		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_Renovation->Admin){
			$Msg = $Fn_Renovation->Config['LangVar']['ArtisanInAudit'];
		}else{

			if($_G['uid'] == $Item['uid']){

				if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
					@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
					$PayList = $FnPay->GetPayList();
				}
			}
			
			$PreviewFace = $Item['face'] ? json_encode(array($Item['face'])) : '';//ͷ��
			
			$PreviewWorkStyle = $Item['param']['work_style'] ? json_encode($Item['param']['work_style']) : '';//�������

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Renovation->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Renovation->TableArtisan,$Item['id'],$ClickNum);

			//����
			$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m'],array('aid'=>$Item['id']));
			$Fn_Renovation->Config['WxShare']['WxTitle'] = $Item['name'].'_'.$Fn_Renovation->Config['PluginVar']['Title'];
			$Fn_Renovation->Config['WxShare']['WxImg'] = $Item['face'] ? $Item['face'] : $Fn_Renovation->Config['WxShare']['WxImg'];
			//����End
		}
	}else{
		$navtitle = $Msg = $Fn_Renovation->Config['LangVar']['NoViewArtisanData'];
	}
}else if($_GET['m'] == 'user'){//��Ա����

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserTitle'];
	
	$UserCompanyAd = $Fn_Renovation->Config['PluginVar']['user_ad'];

	if(!checkmobile()){
		$UserFormList = $Fn_Renovation->GetAjaxUserFormList(array('company_id'=>$UserInfo['company']['id'],'limit'=>5));
		$UserCaseList = $Fn_Renovation->GetAjaxCaseList(array('company_id'=>$UserInfo['company']['id'],'limit'=>5));
		$UserBuildList = $Fn_Renovation->GetAjaxBuildList(array('company_id'=>$UserInfo['company']['id'],'limit'=>5));
		$UserDesignList = $Fn_Renovation->GetUserCompanyDesignList($UserInfo['company']['id']);
	}

	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}

}else if($_GET['m'] == 'user_company'){//��פor�༭

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserCompany'];
	
	$DataArea = MobileSelectAreaJs($Fn_Renovation->Area);
	
	$Item = !$_GET['new'] ? $UserInfo['company'] : '';

	$Banner = $Item['banner'] ? json_encode($Item['banner']) : '';
	
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['EditCompany'];
	}
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}
}else if($_GET['m'] == 'user_case_list'){//�ҵİ����б�

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserCaseList'];

	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}
	
}else if($_GET['m'] == 'user_case'){//�༭����

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserCase'];
	
	$_GET['class'] = in_array($_GET['class'],array('1','2','3')) ? $_GET['class'] : 1;

	$Item = $Fn_Renovation->GetViewCasethread($_GET['case_id']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserCaseEdit'];
		$_GET['class']  = $Item['class'];
	}
	
	$DataArea = MobileSelectAreaJs($Fn_Renovation->Area);

	if($_GET['class'] == 1){

		$ContentImgs = $Item['param']['content_imgs'] ? json_encode($Item['param']['content_imgs']) : '';
		$DataArea = MobileSelectAreaJs($Fn_Renovation->Area);
		$DataStyle = MobileSelectJs($Fn_Renovation->Config['LangVar']['style'],$Fn_Renovation->Config['LangVar']['apartment'],$Fn_Renovation->Config['LangVar']['case_money'],$Fn_Renovation->Config['LangVar']['case_type']);
		$StyleText  = $Item ? $Item['style_text'].' '.$Item['apartment_text'].' '.$Item['money_text'].' '.$Item['type_text'] : '';

	}else if($_GET['class'] == 2){

		$DataArea = MobileSelectAreaJs($Fn_Renovation->Area);
		$DataStyle = MobileSelectJs($Fn_Renovation->Config['LangVar']['style'],$Fn_Renovation->Config['LangVar']['apartment'],$Fn_Renovation->Config['LangVar']['case_money']);
		$StyleText  =  $Item ? $Item['style_text'].' '.$Item['apartment_text'].' '.$Item['money_text'] : '';

	}else if($_GET['class'] == 3){
		
	
	}
	$DesignArray = array();
	foreach ($Fn_Renovation->GetCompanyDesignList($_GET['company_id']) as $Key => $Val) {
		$DesignArray[$Val['id']] = $Val['name'];
	}
	$DataDesign = $DesignArray ? MobileSelectJs($DesignArray) : '';

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}
}else if($_GET['m'] == 'user_build_list'){//�ҵĹ����б�

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserBuildList'];
	
}else if($_GET['m'] == 'user_build'){//�༭�ڽ�����

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserBuild'];
	
	$DataArea = MobileSelectAreaJs($Fn_Renovation->Area);
	$DataStyle = MobileSelectJs($Fn_Renovation->Config['LangVar']['style'],$Fn_Renovation->Config['LangVar']['apartment'],$Fn_Renovation->Config['LangVar']['DecorationFormArray']);

	$Item = $Fn_Renovation->GetViewBuildthread($_GET['build_id']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserBuildEdit'];
	}

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}
}else if($_GET['m'] == 'user_build_info_list'){//�ҵĹ��ؽ�����Ϣ����
	
	$BuildItem = $Fn_Renovation->GetViewBuildthread($_GET['build_id']);

	$navtitle = $metadescription = $metakeywords = $BuildItem['title'].$Fn_Renovation->Config['LangVar']['UserBuildInfoList'];
	
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

}else if($_GET['m'] == 'user_design_list'){//�ҵ����ʦ�б�

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserDesignList'];
	
	//����Ŷ�
	$DesignList = $Fn_Renovation->GetUserCompanyDesignList($_GET['company_id']);

}else if($_GET['m'] == 'user_design'){//�༭���ʦ

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserDesign'];
	
	$DataExperience = MobileSelectJs($Fn_Renovation->Config['LangVar']['design_experience']);

	$Item = $Fn_Renovation->GetViewDesignthread($_GET['design_id']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserDesignEdit'];
	}

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}
}else if($_GET['m'] == 'user_form_list'){//�ҵ�����ͻ�

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserFormList'];

}else if($_GET['m'] == 'buy_store_level'){//��˾�ײ�
	
	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['BuyStoreLevelTitle'];
	
	$CompanyGroupList = $Fn_Renovation->GetCompanyGroupList();
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}

	$PayTitle = $Fn_Renovation->Config['LangVar']['PayCompanyContentPayTitle'];

	if($CompanyItem['vip']){
		$Fn_Renovation->Config['LangVar']['BuyStoreLevelOpen'] = $Fn_Renovation->Config['LangVar']['BuyStoreLevelRenew'];
		$Msg = $Fn_Renovation->Config['LangVar']['BuyStoreLevelRenewOk'];
	}else{
		$Msg = $Fn_Renovation->Config['LangVar']['BuyStoreLevelOpenOK'];
	}
}else if($_GET['m'] == 'user_artisan'){//ʦ����פ
	
	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserArtisan'];
	
	$DataWorkYears = MobileSelectJs($Fn_Renovation->Config['LangVar']['ArtisanWorkYears']);
	
	$Item = $UserInfo['artisan'];
	
	$WorkStyle = $Item['param']['work_style'] ? json_encode($Item['param']['work_style']) : '';

	if($Item){
		$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserArtisanEdit'];
	}
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}
	
 	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}
	
	$PayTitle = $Fn_Renovation->Config['LangVar']['PayArtisanTitle'];
	if($Item['vip']){
		$Msg = $Fn_Renovation->Config['LangVar']['ArtisanRenewOk'];
	}else{
		$Msg = $Fn_Renovation->Config['LangVar']['ArtisanOpenOK'];
	}
}else if($_GET['m'] == 'material'){
	
	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['PluginVar']['MaterialTitle'];

	$Banners = $Fn_Renovation->Config['PluginVar']['material_banners'];

	$ClassList = $Fn_Renovation->GetMaterialClassList();

	$IndexCompanyHotList = $Fn_Renovation->GetIndexMaterialCompanyHotList();

	$Case = $Fn_Renovation->GetAjaxMaterialCaseList(array('display'=>1,'index'=>1,'limit'=>$Fn_Renovation->Config['PluginVar']['material_index_case_num']));

	$Goods = $Fn_Renovation->GetAjaxGoodsList(array('display'=>1,'index'=>1,'limit'=>$Fn_Renovation->Config['PluginVar']['material_index_goods_num']));

	//����
	$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m']);
	$Fn_Renovation->Config['WxShare']['WxTitle'] = $Fn_Renovation->Config['PluginVar']['MaterialWxTitle'];
	$Fn_Renovation->Config['WxShare']['WxDes'] = $Fn_Renovation->Config['PluginVar']['MaterialWxDes'];
	$Fn_Renovation->Config['WxShare']['WxImg'] = strpos($Fn_Renovation->Config['PluginVar']['MaterialWxImg'],'http') !== false ? $Fn_Renovation->Config['PluginVar']['MaterialWxImg'] : $_G['siteurl'].$Fn_Renovation->Config['PluginVar']['MaterialWxImg'];
	//����End

}else if($_GET['m'] == 'list_material_case'){

	$Item = $Fn_Renovation->GetViewMaterialCompanythread($_GET['company_id']);

	$navtitle = $metadescription = $metakeywords = str_replace('{company_name}',$Item['name'],$Fn_Renovation->Config['LangVar']['list_material_case_title']);

	$Case = $Fn_Renovation->GetAjaxMaterialCaseList(array('display'=>1,'company_id'=>$_GET['company_id'],'limit'=>100));

	$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Config['ListMaterialCaseUrl'].'&'.http_build_query(array('company_id'=>$_GET['company_id']));
	$Fn_Renovation->Config['WxShare']['WxTitle'] = $navtitle.'_'.$Fn_Renovation->Config['PluginVar']['Title'];

}else if($_GET['m'] == 'list_goods'){

	$Item = $Fn_Renovation->GetViewMaterialCompanythread($_GET['company_id']);

	$navtitle = $metadescription = $metakeywords = str_replace('{company_name}',$Item['name'],$Fn_Renovation->Config['LangVar']['list_goods_title']);

	$Goods = $Fn_Renovation->GetAjaxGoodsList(array('display'=>1,'company_id'=>$_GET['company_id'],'limit'=>100));

	$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Config['ListGoodsUrl'].'&'.http_build_query(array('company_id'=>$_GET['company_id']));
	$Fn_Renovation->Config['WxShare']['WxTitle'] = $navtitle.'_'.$Fn_Renovation->Config['PluginVar']['Title'];

}else if($_GET['m'] == 'list_material_company'){

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['list_material_company_title'];

	$ClassList = $Fn_Renovation->GetMaterialClassList();

	$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m']);
	$Fn_Renovation->Config['WxShare']['WxTitle'] = $navtitle.'_'.$Fn_Renovation->Config['PluginVar']['Title'];

}else if($_GET['m'] == 'view_material_company'){

	$Item = $Fn_Renovation->GetViewMaterialCompanythread($_GET['cid']);

	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['name'];
		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_Renovation->Admin){
			$Msg = $Fn_Renovation->Config['LangVar']['CompanyInAudit'];
		}else{

			$PreviewBanner = $Item['banner'] ? json_encode($Item['banner']) : '';//ͼƬ��

			//��Ʒ
			$Goods = $Fn_Renovation->GetAjaxGoodsList(array('display'=>1,'company_id'=>$Item['id'],'limit'=>$Fn_Renovation->Config['PluginVar']['company_goods_num']));
			$GoodsCount = str_replace(array('{count}'),array($Goods['count']),$Fn_Renovation->Config['LangVar']['CaseCount']);

			//����
			$Case = $Fn_Renovation->GetAjaxMaterialCaseList(array('display'=>1,'company_id'=>$Item['id'],'limit'=>$Fn_Renovation->Config['PluginVar']['material_company_case_num']));
			$CaseCount = str_replace(array('{count}'),array($Case['count']),$Fn_Renovation->Config['LangVar']['CaseCount']);

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Renovation->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Renovation->TableMaterialCompany,$Item['id'],$ClickNum);

			//����
			$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m'],array('cid'=>$Item['id']));
			$Fn_Renovation->Config['WxShare']['WxTitle'] = str_replace(array('{name}','{address}'),array($Item['name'],$Item['province_text'].$Item['community']),$Fn_Renovation->Config['PluginVar']['material_company_share_title']);
			$Fn_Renovation->Config['WxShare']['WxDes'] = str_replace(array('{name}','{address}'),array($Item['name'],$Item['province_text'].$Item['community']),$Fn_Renovation->Config['PluginVar']['material_company_share_desc']);
			$Fn_Renovation->Config['WxShare']['WxTitle'] = $Item['name'].'_'.$Fn_Renovation->Config['PluginVar']['Title'];
			$Fn_Renovation->Config['WxShare']['WxImg'] = $Item['logo'] ? $Item['logo'] : $Fn_Renovation->Config['WxShare']['WxImg'];
			//����End
		}
	}else{
		$navtitle = $Msg = $Fn_Renovation->Config['LangVar']['NoViewCompanyData'];
	}

}else if($_GET['m'] == 'view_material_case'){//���İ���

	$Item = $Fn_Renovation->GetViewMaterialCasethread($_GET['cid']);

	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['title'];
		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_Renovation->Admin){
			$Msg = $Fn_Renovation->Config['LangVar']['CaseInAudit'];
		}else{

			$PreviewBanner = $Item['banner'] ? json_encode($Item['banner']) : '';//ͼƬ��

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Renovation->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Renovation->TableMaterialCase,$Item['id'],$ClickNum);

			//����
			$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m'],array('cid'=>$Item['id']));
			$Fn_Renovation->Config['WxShare']['WxTitle'] = $Item['title'].'_'.$Fn_Renovation->Config['PluginVar']['Title'];
			$Fn_Renovation->Config['WxShare']['WxImg'] = $Item['param']['thumbnail'] ? $Item['param']['thumbnail'] : $Fn_Renovation->Config['WxShare']['WxImg'];
			//����End
		}
	}else{
		$navtitle = $Msg = $Fn_Renovation->Config['LangVar']['NoViewCaseData'];
	}
}else if($_GET['m'] == 'view_goods'){//��Ʒ

	$Item = $Fn_Renovation->GetViewGoodsthread($_GET['gid']);

	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['title'];
		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_Renovation->Admin){
			$Msg = $Fn_Renovation->Config['LangVar']['GoodsInAudit'];
		}else{

			$PreviewBanner = $Item['banner'] ? json_encode($Item['banner']) : '';//ͼƬ��

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Renovation->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Renovation->TableMaterialGoods,$Item['id'],$ClickNum);

			//����
			$Fn_Renovation->Config['WxShare']['WxUrl'] = $Fn_Renovation->Rewrite($_GET['m'],array('gid'=>$Item['id']));
			$Fn_Renovation->Config['WxShare']['WxTitle'] = $Item['title'].'_'.$Fn_Renovation->Config['PluginVar']['Title'];
			$Fn_Renovation->Config['WxShare']['WxImg'] = $Item['thumbnail'] ? $Item['thumbnail'] : $Fn_Renovation->Config['WxShare']['WxImg'];
			//����End
		}
	}else{
		$navtitle = $Msg = $Fn_Renovation->Config['LangVar']['NoViewGoodsData'];
	}
}else if($_GET['m'] == 'user_material'){//��Ա����

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserTitle'];
	
	$UserCompanyAd = $Fn_Renovation->Config['PluginVar']['material_user_ad'];

	if(!checkmobile()){
		$UserFormList = $Fn_Renovation->GetAjaxUserMaterialFormList(array('company_id'=>$UserInfo['material_company']['id'],'limit'=>5));
		$UserGoodsList = $Fn_Renovation->GetAjaxGoodsList(array('company_id'=>$UserInfo['material_company']['id'],'limit'=>5));
	}

	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}

}else if($_GET['m'] == 'user_material_company'){//װ����פor�༭

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserMaterialCompany'];

	$ClassList = $Fn_Renovation->GetMaterialClassList();
	$SelectClassList = array();
	foreach($ClassList as $Key => $Val){
		$SelectClassList[$Val['id']] = $Val['name'];
	}
	$DataClassList = MobileSelectJs($SelectClassList);
	$DataArea = MobileSelectAreaJs($Fn_Renovation->Area);
	
	$Item = !$_GET['new'] ? $UserInfo['material_company'] : '';

	$Banner = $Item['banner'] ? json_encode($Item['banner']) : '';
	
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['EditCompany'];
	}
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}
}else if($_GET['m'] == 'user_material_form_list'){//�ҵ�����ͻ�

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserFormList'];

}else if($_GET['m'] == 'user_material_case_list'){//�ҵĽ��İ����б�

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserCaseList'];

}else if($_GET['m'] == 'user_material_case'){//�༭��Ʒ

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserMaterialCase'];
	
	$Item = $Fn_Renovation->GetViewMaterialCasethread($_GET['cid']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserMaterialCaseEdit'];
		$BannerImgs = $Item['banner'] ? json_encode($Item['banner']) : '';
		$ProductsImgs = $Item['products'] ? json_encode($Item['products']) : '';
	}

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}
}else if($_GET['m'] == 'user_goods_list'){//�ҵ���Ʒ�б�

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserGoodsList'];

}else if($_GET['m'] == 'user_goods'){//�༭��Ʒ

	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserGoods'];
	
	$Item = $Fn_Renovation->GetViewGoodsthread($_GET['gid']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['UserGoodsEdit'];
		$BannerImgs = $Item['banner'] ? json_encode($Item['banner']) : '';
		$ProductsImgs = $Item['products'] ? json_encode($Item['products']) : '';
	}

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}
}else if($_GET['m'] == 'buy_store_level_material'){//���Ĺ�˾�ײ�
	
	$navtitle = $metadescription = $metakeywords = $Fn_Renovation->Config['LangVar']['BuyStoreLevelTitle'];
	
	$CompanyGroupList = $Fn_Renovation->GetMaterialCompanyGroupList();
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}

	$PayTitle = $Fn_Renovation->Config['LangVar']['PayCompanyContentPayTitle'];

	if($CompanyItem['vip']){
		$Fn_Renovation->Config['LangVar']['BuyStoreLevelOpen'] = $Fn_Renovation->Config['LangVar']['BuyStoreLevelRenew'];
		$Msg = $Fn_Renovation->Config['LangVar']['BuyStoreLevelRenewOk'];
	}else{
		$Msg = $Fn_Renovation->Config['LangVar']['BuyStoreLevelOpenOK'];
	}
}

function NavInspect($Mod,$Url){
	global $_G,$Item;
	$StrReplaceArray = array('{','}');
	$StrReplaceArrayTo = array('','');
	$Rewrite = dunserialize($_G['setting']['fn_renovation_rewrite']);
	if($Mod == 'view'){
		$Rule = str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite['list_'.$Item['class']]['rule']);
	}else if($Mod == 'view_disc'){
		$Rule = str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite['list_disc']['rule']);
	}else if($Mod == 'view_disc'){
		$Rule = str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite['list_disc']['rule']);
	}
	return str_replace('[siteurl]','',$Url) == $Rule ? true : false;
}

include template('fn_renovation:'.$_GET['m']);
?>