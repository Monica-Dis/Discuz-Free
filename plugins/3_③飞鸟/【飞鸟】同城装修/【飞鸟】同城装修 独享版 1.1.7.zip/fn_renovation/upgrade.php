<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_artisan` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` tinyint(3) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `face` varchar(255) NOT NULL,
  `name` varchar(20) NOT NULL,
  `tag` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `range` varchar(255) NOT NULL,
  `work_years` int(4) unsigned NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `mobile_verify` tinyint(1) unsigned NOT NULL,
  `grade` varchar(10) NOT NULL,
  `param` mediumtext NOT NULL,
  `verify` tinyint(1) unsigned NOT NULL,
  `experience` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  `due_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_build` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `community_id` int(11) unsigned NOT NULL,
  `community_name` varchar(50) NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `style` tinyint(2) unsigned NOT NULL,
  `apartment` tinyint(2) unsigned NOT NULL,
  `money` varchar(20) NOT NULL,
  `square` int(11) unsigned NOT NULL,
  `forms` tinyint(1) unsigned NOT NULL,
  `stage` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_build_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `build_id` int(11) unsigned NOT NULL,
  `stage` tinyint(1) unsigned NOT NULL,
  `content` text NOT NULL,
  `param` mediumtext NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_case` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `design_id` int(11) unsigned NOT NULL,
  `community_id` int(11) unsigned NOT NULL,
  `class` tinyint(2) unsigned NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `style` tinyint(2) unsigned NOT NULL,
  `apartment` tinyint(2) unsigned NOT NULL,
  `money` tinyint(2) unsigned NOT NULL,
  `square` int(11) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `local` tinyint(2) unsigned NOT NULL,
  `space` tinyint(2) unsigned NOT NULL,
  `url` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `param` mediumtext NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_case_refresh_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `case_id` int(11) unsigned NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_community` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `province` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `dist` varchar(20) NOT NULL,
  `community` varchar(50) NOT NULL,
  `lat` varchar(20) NOT NULL,
  `lng` varchar(20) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_company` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` tinyint(3) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `admin_uid` varchar(255) NOT NULL,
  `banner` text NOT NULL,
  `logo` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `landline` varchar(30) NOT NULL,
  `content` mediumtext NOT NULL,
  `province` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `dist` varchar(20) NOT NULL,
  `community` varchar(100) NOT NULL,
  `lat` varchar(20) NOT NULL,
  `lng` varchar(20) NOT NULL,
  `tag` varchar(100) NOT NULL,
  `grade` varchar(10) NOT NULL,
  `param` mediumtext NOT NULL,
  `verify` tinyint(1) unsigned NOT NULL,
  `experience` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  `due_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_company_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `param` mediumtext NOT NULL,
  `money` varchar(20) NOT NULL,
  `group_time` tinyint(3) unsigned NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `experience` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;


CREATE TABLE IF NOT EXISTS `pre_fn_renovation_company_group_log` (
  `company_id` int(11) unsigned NOT NULL,
  `banner` tinyint(1) unsigned NOT NULL,
  `build_count` int(11) unsigned NOT NULL,
  `case_count` int(11) unsigned NOT NULL,
  `team_count` int(11) unsigned NOT NULL,
  `refresh_type` tinyint(1) unsigned NOT NULL,
  `day_refresh_count` int(11) unsigned NOT NULL,
  `refresh_count` int(11) unsigned NOT NULL,
  `top_discount` varchar(20) NOT NULL,
  `hot` tinyint(1) unsigned NOT NULL,
  `examine` tinyint(1) unsigned NOT NULL,
  `sms` tinyint(1) unsigned NOT NULL,
  `wx` tinyint(1) unsigned NOT NULL,
  UNIQUE KEY `company_id` (`company_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_form` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `form_type` tinyint(2) unsigned NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `url` varchar(255) NOT NULL,
  `count` int(11) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `form_id` int(10) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_member` (
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  `unionid` varchar(50) NOT NULL,
  `subscribe` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  UNIQUE KEY `uid` (`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_team_design` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `face` varchar(255) NOT NULL,
  `name` varchar(30) NOT NULL,
  `title` varchar(30) NOT NULL,
  `experience` tinyint(2) unsigned NOT NULL,
  `idea` text NOT NULL,
  `content` text NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_material_case` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `banner` text NOT NULL,
  `content` text NOT NULL,
  `products` text NOT NULL,
  `param` mediumtext NOT NULL,
  `index` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_material_class` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bclassid` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `ico` varchar(255) NOT NULL DEFAULT '',
  `displayorder` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_material_company` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` tinyint(3) unsigned NOT NULL,
  `classid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `admin_uid` varchar(255) NOT NULL,
  `banner` text NOT NULL,
  `logo` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `landline` varchar(30) NOT NULL,
  `content` mediumtext NOT NULL,
  `province` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `dist` varchar(20) NOT NULL,
  `community` varchar(100) NOT NULL,
  `lat` varchar(20) NOT NULL,
  `lng` varchar(20) NOT NULL,
  `tag` varchar(100) NOT NULL,
  `grade` varchar(10) NOT NULL,
  `param` mediumtext NOT NULL,
  `verify` tinyint(1) unsigned NOT NULL,
  `experience` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  `due_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_material_company_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `param` mediumtext NOT NULL,
  `money` varchar(20) NOT NULL,
  `group_time` tinyint(3) unsigned NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `experience` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_material_company_group_log` (
  `company_id` int(11) unsigned NOT NULL,
  `banner` tinyint(1) unsigned NOT NULL,
  `goods_count` int(11) unsigned NOT NULL,
  `case_count` int(11) unsigned NOT NULL,
  `hot` tinyint(1) unsigned NOT NULL,
  `case_examine` tinyint(1) unsigned NOT NULL,
  `examine` tinyint(1) unsigned NOT NULL,
  `sms` tinyint(1) unsigned NOT NULL,
  `wx` tinyint(1) unsigned NOT NULL,
  UNIQUE KEY `company_id` (`company_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_material_form` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `form_type` tinyint(2) unsigned NOT NULL,
  `name` varchar(30) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `url` varchar(255) NOT NULL,
  `count` int(11) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_renovation_material_goods` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `min_title` varchar(255) NOT NULL,
  `banner` text NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `price` decimal(11,2) unsigned NOT NULL,
  `original_price` decimal(11,2) unsigned NOT NULL,
  `price_name` tinyint(2) unsigned NOT NULL,
  `content` text NOT NULL,
  `products` text NOT NULL,
  `param` mediumtext NOT NULL,
  `index` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$ArtisanTableField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_renovation_artisan'));
$ArtisanToArray = MysqlToArray($ArtisanTableField);

$FormTableField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_renovation_form'));
$FormToArray = MysqlToArray($FormTableField);

if(!in_array('mobile_verify',$ArtisanToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_renovation_artisan` ADD `mobile_verify` TINYINT( 1 ) UNSIGNED NOT NULL AFTER `mobile` ;
EOF;
	runquery($UpSql);
}

if(!in_array('type',$FormToArray) && !in_array('form_id',$FormToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_renovation_form` ADD `type` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '1' AFTER `count` ,
	ADD `form_id` INT UNSIGNED NOT NULL AFTER `type` ;
EOF;
	runquery($UpSql);
}

$UpSql = <<<EOF
	 ALTER TABLE `pre_fn_renovation_case` CHANGE `square` `square` INT( 11 ) UNSIGNED NOT NULL;
	 ALTER TABLE `pre_fn_renovation_build` CHANGE `square` `square` INT( 11 ) UNSIGNED NOT NULL;
EOF;
runquery($UpSql);

function MysqlToArray($Array) {
    $temp = array();
    foreach ($Array as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}

$finish = TRUE;
?>