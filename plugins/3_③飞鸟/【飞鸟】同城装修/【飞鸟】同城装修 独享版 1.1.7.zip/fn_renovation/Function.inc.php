<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once libfile('function/core','plugin/fn_assembly');
@require_once libfile('class/magapp','plugin/fn_assembly');
@require_once libfile('class/qfapp','plugin/fn_assembly');
@require_once libfile('class/pay','plugin/fn_assembly');
@require_once libfile('class/json','plugin/fn_assembly');

class Fn_Renovation{
	public function __construct() {
		global $_G,$plugin;
		loadcache('plugin');
		loadcache('fn_renovation_setting');
		foreach($_G['cache']['fn_renovation_setting'] as $key => $value) {
			$this->Config['PluginVar'][$key] = is_array($value) ? $value : stripslashes($value);
		}

		$this->Area = SelectArray($this->Config['PluginVar']['Area']);
		$this->AdminUidsList = array_filter(explode(",",$this->Config['PluginVar']['AdminUids']));
		$this->Admin = in_array($_G['uid'],$this->AdminUidsList) ? true : false;
		$this->Config['PluginVar']['inspect_content1'] = stripslashes($this->Config['PluginVar']['inspect_content1']);
		$this->Config['PluginVar']['inspect_content2'] = stripslashes($this->Config['PluginVar']['inspect_content2']);

		$this->Config['LangVar'] = lang('plugin/fn_renovation');
		$this->Config['LangVar']['design_experience'] = TextareaArray($this->Config['PluginVar']['design_experience']);
		$this->Config['LangVar']['style'] = TextareaArray($this->Config['PluginVar']['style']);
		$this->Config['LangVar']['apartment'] = TextareaArray($this->Config['PluginVar']['apartment']);
		$this->Config['LangVar']['case_type'] = TextareaArray($this->Config['PluginVar']['case_type']);
		$this->Config['LangVar']['local'] = TextareaArray($this->Config['PluginVar']['local']);
		$this->Config['LangVar']['case_money'] = TextareaArray($this->Config['PluginVar']['case_money']);
		$this->Config['LangVar']['ArtisanWorkYears'] = TextareaArray($this->Config['PluginVar']['ArtisanWorkYears']);
		$this->Config['LangVar']['ArtisanRepair'] = TextareaArray($this->Config['PluginVar']['ArtisanRepair']);
		$this->Config['LangVar']['ArtisanInstall'] = TextareaArray($this->Config['PluginVar']['ArtisanInstall']);
		$this->Config['LangVar']['ArtisanRenovation'] = TextareaArray($this->Config['PluginVar']['ArtisanRenovation']);
		$this->Config['LangVar']['ArtisanOther'] = TextareaArray($this->Config['PluginVar']['ArtisanOther']);
		$this->Config['LangVar']['GoodsType'] = TextareaArray($this->Config['PluginVar']['GoodsType']);
		$this->Config['LangVar']['GoodsPriceTag'] = TextareaArray($this->Config['PluginVar']['GoodsPriceTag']);

		$this->Config['Path'] = 'source/plugin/fn_renovation';
		$this->Config['StaticPath'] =$_G['siteroot'].$this->Config['Path'].'/static';
		$this->Config['StaticPicPath'] = $this->Config['Path'].'/attachment/';
		$this->Config['Url'] = $_G['siteurl'].'plugin.php?id=fn_renovation'.($_GET['formapp'] ? '&formapp='.$_GET['formapp'] : '');
		$this->Config['FreeQuoteUrl'] = $this->Config['Url'].'&m=free_quote';
		$this->Config['InspectUrl'] = $this->Config['Url'].'&m=inspect';
		$this->Config['DesignUrl'] = $this->Config['Url'].'&m=design';
		$this->Config['MaterialUrl'] = $this->Config['Url'].'&m=material';
		$this->Config['ListCompanyUrl'] = $this->Config['Url'].'&m=list_company';
		$this->Config['ListCaseUrl'] = $this->Config['Url'].'&m=list_case';
		$this->Config['ListBuildUrl'] = $this->Config['Url'].'&m=list_build';
		$this->Config['ListCommunityUrl'] = $this->Config['Url'].'&m=list_community';
		$this->Config['ListArtisanUrl'] = $this->Config['Url'].'&m=list_artisan';
		$this->Config['ListGoodsUrl'] = $this->Config['Url'].'&m=list_goods';
		$this->Config['ListMaterialCompanyUrl'] = $this->Config['Url'].'&m=list_material_company';
		$this->Config['ListMaterialCaseUrl'] = $this->Config['Url'].'&m=list_material_case';
		$this->Config['ViewCaseUrl'] = $this->Config['Url'].'&m=view_case&cid=';
		$this->Config['ViewDesignUrl'] = $this->Config['Url'].'&m=view_design&did=';
		$this->Config['ViewCompanyUrl'] = $this->Config['Url'].'&m=view_company&cid=';
		$this->Config['ViewBuildUrl'] = $this->Config['Url'].'&m=view_build&bid=';
		$this->Config['ViewCommunityUrl'] = $this->Config['Url'].'&m=view_community&cid=';
		$this->Config['ViewArtisanUrl'] = $this->Config['Url'].'&m=view_artisan&aid=';
		$this->Config['ViewMaterialCompanyUrl'] = $this->Config['Url'].'&m=view_material_company&cid=';
		$this->Config['ViewGoodsUrl'] = $this->Config['Url'].'&m=view_goods&gid=';
		$this->Config['ViewMaterialCaseUrl'] = $this->Config['Url'].'&m=view_material_case&cid=';
		$this->Config['UserUrl'] = $this->Config['Url'].'&m=user';
		$this->Config['UserCompanyUrl'] = $this->Config['Url'].'&m=user_company';
		$this->Config['UserCaseListUrl'] = $this->Config['Url'].'&m=user_case_list';
		$this->Config['UserCaseUrl'] = $this->Config['Url'].'&m=user_case';
		$this->Config['UserBuildListUrl'] = $this->Config['Url'].'&m=user_build_list';
		$this->Config['UserBuildUrl'] = $this->Config['Url'].'&m=user_build';
		$this->Config['UserBuildInfoListUrl'] = $this->Config['Url'].'&m=user_build_info_list';
		$this->Config['UserBuildInfoUrl'] = $this->Config['Url'].'&m=user_build_info';
		$this->Config['UserDesignListUrl'] = $this->Config['Url'].'&m=user_design_list';
		$this->Config['UserDesignUrl'] = $this->Config['Url'].'&m=user_design';
		$this->Config['UserFormListUrl'] = $this->Config['Url'].'&m=user_form_list';
		$this->Config['UserArtisanUrl'] = $this->Config['Url'].'&m=user_artisan';
		$this->Config['BuyStoreLevelUrl'] = $this->Config['Url'].'&m=buy_store_level';
		$this->Config['UserMaterialUrl'] = $this->Config['Url'].'&m=user_material';
		$this->Config['UserMaterialCompanyUrl'] = $this->Config['Url'].'&m=user_material_company';
		$this->Config['UserMaterialCaseListUrl'] = $this->Config['Url'].'&m=user_material_case_list';
		$this->Config['UserMaterialCaseUrl'] = $this->Config['Url'].'&m=user_material_case';
		$this->Config['UserGoodsListUrl'] = $this->Config['Url'].'&m=user_goods_list';
		$this->Config['UserGoodsUrl'] = $this->Config['Url'].'&m=user_goods';
		$this->Config['UserMaterialFormListUrl'] = $this->Config['Url'].'&m=user_material_form_list';
		$this->Config['BuyStoreLevelMaterialUrl'] = $this->Config['Url'].'&m=buy_store_level_material';

		$this->Config['AjaxUrl'] =  $_G['siteroot'].'plugin.php?id=fn_renovation:Ajax'.($_GET['formapp'] ? '&formapp='.$_GET['formapp'] : '');
		$this->Config['WxShare'] = array(
			'WxTitle' => $this->Config['PluginVar']['WxTitle'],
			'WxDes' => $this->Config['PluginVar']['WxDes'],
			'WxImg' => strpos($this->Config['PluginVar']['WxImg'],'http') !== false ? $this->Config['PluginVar']['WxImg'] : $_G['siteurl'].$this->Config['PluginVar']['WxImg'],
			'WxUrl' => $this->Config['Url']
		);

		if(!is_dir(DISCUZ_ROOT.$this->Config['StaticPicPath'])){
			dmkdir(DISCUZ_ROOT.$this->Config['StaticPicPath']);
		}
		
		$this->TableArtisan = 'fn_renovation_artisan';
		$this->TableBuild = 'fn_renovation_build';
		$this->TableBuildInfo = 'fn_renovation_build_info';
		$this->TableCase = 'fn_renovation_case';
		$this->TableCaseRefreshLog = 'fn_renovation_case_refresh_log';
		$this->TableCommunity = 'fn_renovation_community';
		$this->TableCompany = 'fn_renovation_company';
		$this->TableCompanyGroup = 'fn_renovation_company_group';
		$this->TableCompanyGroupLog = 'fn_renovation_company_group_log';
		$this->TableForm = 'fn_renovation_form';
		$this->TableMember = 'fn_renovation_member';
		$this->TableDesign = 'fn_renovation_team_design';
		$this->TableMaterialClass = 'fn_renovation_material_class';
		$this->TableMaterialCase = 'fn_renovation_material_case';
		$this->TableMaterialCompanyGroup = 'fn_renovation_material_company_group';
		$this->TableMaterialCompany = 'fn_renovation_material_company';
		$this->TableMaterialCompanyGroupLog = 'fn_renovation_material_company_group_log';
		$this->TableMaterialGoods = 'fn_renovation_material_goods';
		$this->TableMaterialForm = 'fn_renovation_material_form';

		$this->Pay = new Fn_PayLog();
		$this->MagApp = new MagApp($this->Config['PluginVar']['MagSecret'],$this->Config['PluginVar']['MagAssistantSecret'],$this->Config['PluginVar']['MagAssistantPush']);
		$this->QHApp = new QHApp($this->Config['PluginVar']['qf_type'],$this->Config['PluginVar']['qf_sr_type'],$this->Config['PluginVar']['qf_from_id']);
		$this->Config['AppPaymentId'] = $this->QHApp->AppPaymentId;
	}

	
	public function GetUserInfo(){
		global $_G;
		$UserInfo = array();
		foreach(DB::fetch_all('SELECT id FROM '.DB::table($this->TableCompany).' where ( uid = '.intval($_G['uid']).' or FIND_IN_SET('.intval($_G['uid']).',admin_uid)) order by dateline asc,id asc') as $Key => $Val) {
			$UserInfo['company_list'][$Val['id']] = $this->GetUserCompanyAdmin($Val['id']);
		}
		$UserInfo['company'] = reset($UserInfo['company_list']);

		foreach(DB::fetch_all('SELECT id FROM '.DB::table($this->TableMaterialCompany).' where ( uid = '.intval($_G['uid']).' or FIND_IN_SET('.intval($_G['uid']).',admin_uid)) order by dateline asc,id asc') as $Key => $Val) {
			$UserInfo['material_company_list'][$Val['id']] = $this->GetUserMaterialCompanyAdmin($Val['id']);
		}
		$UserInfo['material_company'] = reset($UserInfo['material_company_list']);

		$UserInfo['artisan'] = DB::fetch_first('SELECT A.* FROM '.DB::table($this->TableArtisan).' A where A.uid = '.intval($_G['uid']));
		if($UserInfo['artisan']){
			$UserInfo['artisan']['param'] = unserialize($UserInfo['artisan']['param']);
			$UserInfo['artisan']['tag_array'] = array_filter(explode(",",$UserInfo['artisan']['tag']));
			$UserInfo['artisan']['vip'] = $UserInfo['artisan']['due_time'] > time() ? true : false;
		}
		return $UserInfo;
	}

	public function GetUserCompanyAdmin($Id){
		global $_G;
		$CompanyItem = $this->GetViewCompanythread($Id);
		if(!$CompanyItem){
			$CompanyItem['msg'] = $this->Config['LangVar']['NoViewCompanyData'];
		}else if(!$CompanyItem['display'] && $CompanyItem){
			$CompanyItem['msg'] = $this->Config['LangVar']['CompanyInAudit'];
		}else if($CompanyItem['uid'] != $_G['uid'] && !in_array($_G['uid'],array_filter(explode(",",$CompanyItem['admin_uid'])))){
			$CompanyItem['msg'] = $this->Config['LangVar']['NoAuthority'];
		}

		if($CompanyItem['id']){
			
			$CompanyItem['RemnantCaseCount'] = $CompanyItem['group_case_count'] - DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableCase).' where company_id = '.intval($CompanyItem['id']));

			$CompanyItem['RemnantBuildCount'] = $CompanyItem['group_build_count'] - DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableBuild).' where company_id = '.intval($CompanyItem['id']));

			$CompanyItem['RemnantDesignCount'] = $CompanyItem['team_count'] - DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableDesign).' where company_id = '.intval($CompanyItem['id']));

			$CompanyItem['RemnantRefreshCount'] = $CompanyItem['refresh_count'] - DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableCaseRefreshLog).' where company_id = '.intval($CompanyItem['id']));

			$CompanyItem['RemnantDayRefreshCount'] = $CompanyItem['day_refresh_count'] - DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableCaseRefreshLog).' where company_id = '.intval($CompanyItem['id']).' and dateline >= '.strtotime(date('Y-m-d',time())).' and dateline <= '.strtotime(date('Y-m-d 23:59:59',time())));
		}
		return $CompanyItem;
	}

	public function GetUserMaterialCompanyAdmin($Id){
		global $_G;
		$CompanyItem = $this->GetViewMaterialCompanythread($Id);
		if(!$CompanyItem){
			$CompanyItem['msg'] = $this->Config['LangVar']['NoViewCompanyData'];
		}else if(!$CompanyItem['display'] && $CompanyItem){
			$CompanyItem['msg'] = $this->Config['LangVar']['CompanyInAudit'];
		}else if($CompanyItem['uid'] != $_G['uid'] && !in_array($_G['uid'],array_filter(explode(",",$CompanyItem['admin_uid'])))){
			$CompanyItem['msg'] = $this->Config['LangVar']['NoAuthority'];
		}

		if($CompanyItem['id']){

			$CompanyItem['RemnantCaseCount'] = $CompanyItem['group_case_count'] - DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableMaterialCase).' where company_id = '.intval($CompanyItem['id']));
			
			$CompanyItem['RemnantGoodsCount'] = $CompanyItem['group_goods_count'] - DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableMaterialGoods).' where company_id = '.intval($CompanyItem['id']));

		}
		return $CompanyItem;
	}

	/* ��˾���� */
	public function GetViewCompanythread($Id,$Field = 'id',$Where = null){
		$Item = DB::fetch_first('SELECT C.*,AG.title,AG.ico,AGL.case_count as group_case_count,AGL.build_count as group_build_count,AGL.team_count,AGL.examine,AGL.refresh_count,AGL.day_refresh_count,AGL.refresh_type,AGL.banner as group_banner,AGL.sms as group_sms FROM '.DB::table($this->TableCompany).' C LEFT JOIN `'.DB::table($this->TableCompanyGroup).'` AG on AG.id = C.group_id LEFT JOIN `'.DB::table($this->TableCompanyGroupLog).'` AGL on AGL.company_id = C.id where C.'.$Field.' = '.intval($Id).$Where);
		if($Item){

			$Item['param'] = unserialize($Item['param']);
			$Item['banner'] = array_filter(explode(",",$Item['banner']));
			$Item['content'] = stripslashes($Item['content']);
			$Item['vip'] = $Item['due_time'] > time() ? true : false;
			$Item['logo'] = $Item['logo']  ? $Item['logo'] : $this->Config['PluginVar']['CompanyDefaultPath'];
			$Item['province_text'] = $this->Area[$Item['province']]['content'].($Item['city'] ? '-'.$this->Area[$Item['city']]['content'] : '').($Item['dist'] ? '-'.$this->Area[$Item['dist']]['content'] : '');
			$Item['case_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableCase).' where display = 1 and company_id = '.intval($Item['id']));
			$Item['build_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableBuild).' where display = 1 and company_id = '.intval($Item['id']));
			$Item['case_count_tips'] = str_replace(array('{count}'),array($Item['case_count']),$this->Config['LangVar']['DesignCaseCountTips']);
			$Item['admin'] = array_unique(array_filter(explode(",",$Item['admin_uid'].','.$Item['uid'])));
			$Item['grade_html'] = '';
			for($I = 1;$I < 6;$I++){
				$Array = array_filter(explode(".",$Item['grade']));
				if($Array['1'] && $I - 1 == $Array['0']){
					$Item['grade_html'] .= '<i class="Half"></i>';
				}else if($I < $Item['grade'] || $I == $Item['grade']){
					$Item['grade_html'] .= '<i></i>';
				}else{
					$Item['grade_html'] .= '<i class="Nothing"></i>';
				}
			}
		}
		return $Item;
	}

	/* �������� */
	public function GetViewCasethread($Id,$Field = 'id'){
		$Item = DB::fetch_first('SELECT C.* FROM '.DB::table($this->TableCase).' C where C.'.$Field.' = '.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['content'] = stripslashes($Item['content']);
			$Item['style_text'] = $this->Config['LangVar']['style'][$Item['style']];
			$Item['apartment_text'] = $this->Config['LangVar']['apartment'][$Item['apartment']];
			$Item['money_text'] = $this->Config['LangVar']['case_money'][$Item['money']];
			$Item['type_text'] = $this->Config['LangVar']['case_type'][$Item['type']];
			$Item['company'] = $this->GetViewCompanythread($Item['company_id']);
			$Item['community'] = $this->GetViewCommunitythread($Item['community_id']);
			$Item['design'] = $this->GetViewDesignthread($Item['design_id']);
		}
		return $Item;
	}

	/* С������ */
	public function GetViewCommunitythread($Id,$Field = 'id'){
		$Item = DB::fetch_first('SELECT C.* FROM '.DB::table($this->TableCommunity).' C where C.'.$Field.' = '.intval($Id));
		if($Item){

			$Item['thumbnail'] = $Item['thumbnail']  ? $Item['thumbnail'] : $this->Config['PluginVar']['CommunityDefaultPath'];
			$Item['province_text'] = $this->Area[$Item['province']]['content'].($Item['city'] ? '-'.$this->Area[$Item['city']]['content'] : '').($Item['dist'] ? '-'.$this->Area[$Item['dist']]['content'] : '');
			$Item['case_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableCase).' where display = 1 and community_id = '.intval($Item['id']));
			$Item['build_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableBuild).' where display = 1 and community_id = '.intval($Item['id']));

		}
		return $Item;
	}
	
	/* �������� */
	public function GetViewBuildthread($Id,$Field = 'id'){
		$Item = DB::fetch_first('SELECT B.* FROM '.DB::table($this->TableBuild).' B where B.'.$Field.' = '.intval($Id));
		if($Item){
			$Item['style_text'] = $this->Config['LangVar']['style'][$Item['style']];
			$Item['apartment_text'] = $this->Config['LangVar']['apartment'][$Item['apartment']];
			$Item['forms_text'] = $this->Config['LangVar']['DecorationFormArray'][$Item['forms']];
			$Item['stage_text'] = $this->Config['LangVar']['StageMinArray'][$Item['stage']];
			$Item['company'] = $this->GetViewCompanythread($Item['company_id']);
		}
		return $Item;
	}

	/* ������� */
	public function GetViewDesignthread($Id,$Where = null){
		$Item = DB::fetch_first('SELECT D.*,C.landline FROM '.DB::table($this->TableDesign).' D LEFT JOIN `'.DB::table($this->TableCompany).'` C on C.id = D.company_id where D.id = '.intval($Id).$Where);
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['experience_text'] = $this->Config['LangVar']['design_experience'][$Item['experience']];
		}
		return $Item;
	}

	/* ���Ĺ�˾���� */
	public function GetViewMaterialCompanythread($Id,$Field = 'id',$Where = null){
		$Item = DB::fetch_first('SELECT C.*,MC.name as class_name,AG.title,AG.ico,AGL.case_count as group_case_count,AGL.goods_count as group_goods_count,AGL.banner as group_banner,AGL.sms as group_sms,AGL.examine,AGL.case_examine FROM '.DB::table($this->TableMaterialCompany).' C LEFT JOIN `'.DB::table($this->TableMaterialCompanyGroup).'` AG on AG.id = C.group_id LEFT JOIN `'.DB::table($this->TableMaterialCompanyGroupLog).'` AGL on AGL.company_id = C.id LEFT JOIN `'.DB::table($this->TableMaterialClass).'` MC on MC.id = C.classid where C.'.$Field.' = '.intval($Id).$Where);
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['banner'] = array_filter(explode(",",$Item['banner']));
			$Item['content'] = stripslashes($Item['content']);
			$Item['vip'] = $Item['due_time'] > time() ? true : false;
			$Item['logo'] = $Item['logo']  ? $Item['logo'] : $this->Config['PluginVar']['MaterialCompanyDefaultPath'];
			$Item['province_text'] = $this->Area[$Item['province']]['content'].($Item['city'] ? '-'.$this->Area[$Item['city']]['content'] : '').($Item['dist'] ? '-'.$this->Area[$Item['dist']]['content'] : '');
			$Item['case_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableMaterialCase).' where display = 1 and company_id = '.intval($Item['id']));
			$Item['goods_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableMaterialGoods).' where display = 1 and company_id = '.intval($Item['id']));
			$Item['material_count_tips'] = str_replace(array('{case_count}','{goods_count}'),array($Item['case_count'],$Item['goods_count']),$this->Config['LangVar']['material_count_tips']);
			$Item['admin'] = array_unique(array_filter(explode(",",$Item['admin_uid'].','.$Item['uid'])));
			$Item['grade_html'] = '';
			for($I = 1;$I < 6;$I++){
				$Array = array_filter(explode(".",$Item['grade']));
				if($Array['1'] && $I - 1 == $Array['0']){
					$Item['grade_html'] .= '<i class="Half"></i>';
				}else if($I < $Item['grade'] || $I == $Item['grade']){
					$Item['grade_html'] .= '<i></i>';
				}else{
					$Item['grade_html'] .= '<i class="Nothing"></i>';
				}
			}
		}
		return $Item;
	}

	/* ���İ������� */
	public function GetViewMaterialCasethread($Id,$Field = 'id'){
		$Item = DB::fetch_first('SELECT C.* FROM '.DB::table($this->TableMaterialCase).' C where C.'.$Field.' = '.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['banner'] = array_filter(explode(",",$Item['banner']));
			$Item['products'] = array_filter(explode(",",$Item['products']));
			$Item['content'] = stripslashes($Item['content']);
			$Item['company'] = $this->GetViewMaterialCompanythread($Item['company_id']);
		}
		return $Item;
	}

	/* ��Ʒ���� */
	public function GetViewGoodsthread($Id,$Field = 'id'){
		$Item = DB::fetch_first('SELECT G.* FROM '.DB::table($this->TableMaterialGoods).' G where G.'.$Field.' = '.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['banner'] = array_filter(explode(",",$Item['banner']));
			$Item['products'] = array_filter(explode(",",$Item['products']));
			$Item['content'] = stripslashes($Item['content']);
			$Item['type_text'] = $this->Config['LangVar']['GoodsType'][$Item['type']];
			$Item['price_name_text'] = $this->Config['LangVar']['GoodsPriceTag'][$Item['price_name']];
			$Item['company'] = $this->GetViewMaterialCompanythread($Item['company_id']);
		}
		return $Item;
	}

	/* ʦ������ */
	public function GetViewArtisanthread($Id,$Field = 'id',$Where = null){
		$Item = DB::fetch_first('SELECT A.* FROM '.DB::table($this->TableArtisan).' A where A.'.$Field.' = '.intval($Id).$Where);
		if($Item){

			$Item['param'] = unserialize($Item['param']);
			$Item['content'] = stripslashes($Item['content']);
			$Item['vip'] = $Item['due_time'] > time() ? true : false;
			$Item['face'] = $Item['face']  ? $Item['face'] : $this->Config['PluginVar']['ArtisanDefaultPath'];
			$Item['work_years_age'] = date('Y') - $Item['work_years'] >= 1 ? date('Y') - $Item['work_years'] : 1;
			$Item['grade_html'] = '';
			for($I = 1;$I < 6;$I++){
				$Array = array_filter(explode(".",$Item['grade']));
				if($Array['1'] && $I - 1 == $Array['0']){
					$Item['grade_html'] .= '<i class="Half"></i>';
				}else if($I < $Item['grade'] || $I == $Item['grade']){
					$Item['grade_html'] .= '<i></i>';
				}else{
					$Item['grade_html'] .= '<i class="Nothing"></i>';
				}
			}
		}
		return $Item;
	}
	
	/* ��˾�Ƽ� */
	public function GetIndexCompanyHotList(){
		return $this->CompanyListFormat(DB::fetch_all("SELECT C.* FROM %t AS C,%t AS G where C.due_time >= ".time()." and G.company_id = C.id and G.hot = 1 and C.display = 1 order by C.updateline desc,C.id desc",array($this->TableCompany,$this->TableCompanyGroupLog)));
	}
	
	/* ��˾�б� */
	public function GetAjaxCompanyList($Get){
		
		$Get = StrToGBK($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Where = '';

		if($Get['keyword']){
			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);
			$Where .= ' and (C.name like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\'))';
		}

		if($Get['province']){
			$Where .= ' and C.province = \''.addslashes(strip_tags($Get['province'])).'\'';
			if($Get['city']){
				$Where .= ' and C.city = \''.addslashes(strip_tags($Get['city'])).'\'';
				if($Get['dist']){
					$Where .= ' and C.dist = \''.addslashes(strip_tags($Get['dist'])).'\'';
				}
			}
		}

		if(in_array($Get['verify'],array('0','1'))){
			$Where .= ' and C.verify = '.intval($Get['verify']);
		}

		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 10;

		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];

		return $this->CompanyListFormat(DB::fetch_all('SELECT C.*,G.title,G.ico FROM '.DB::table($this->TableCompany).' C LEFT JOIN `'.DB::table($this->TableCompanyGroup).'` G on G.id = C.group_id where C.display = 1 '.$Where.' order by C.due_time > '.time().' desc,C.topdateline > '.time().' desc, C.updateline desc,C.id desc'.$Limit));

	}

	/* С���б� */
	public function GetAjaxCommunityList($Get){
		
		$Get = StrToGBK($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Where = '';

		if($Get['keyword']){
			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);
			$Where .= ' and (C.name like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\'))';
		}

		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 10;

		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];

		return $this->CommunityListFormat(DB::fetch_all('SELECT C.* FROM '.DB::table($this->TableCommunity).' C where C.display = 1 '.$Where.' order by C.topdateline > '.time().' desc, C.updateline desc,C.id desc'.$Limit));

	}

	/* �����б� */
	public function GetAjaxCaseList($Get){
		
		$Get = StrToGBK($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Where = '';

		if($Get['keyword']){
			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);
			$Where .= ' and ( C.title like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
		}

		if(in_array($Get['display'],array('0','1'))){
			$Where .= ' and C.display = '.intval($Get['display']);
		}

		if($Get['company_id']){
			$Where .= ' and C.company_id = '.intval($Get['company_id']);
		}

		if($Get['community_id']){
			$Where .= ' and C.community_id = '.intval($Get['community_id']);
		}

		if($Get['design_id']){
			$Where .= ' and C.design_id = '.intval($Get['design_id']);
		}

		if($Get['class']){
			$Where .= ' and C.class = '.intval($Get['class']);
		}

		if($Get['style']){
			$Where .= ' and C.style = '.intval($Get['style']);
		}

		if($Get['apartment']){
			$Where .= ' and C.apartment = '.intval($Get['apartment']);
		}

		if($Get['money']){
			$Where .= ' and C.money = '.intval($Get['money']);
		}

		if($Get['type']){
			$Where .= ' and C.type = '.intval($Get['type']);
		}

		if($Get['province'] && !$Get['community_id']){
			$CommunityIds = array();
			foreach (DB::fetch_all('SELECT id FROM '.DB::table($this->TableCommunity).' where display = 1 and province = '.intval($Get['province']).' order by topdateline > '.time().' desc,updateline desc,id desc') as $Key => $Val) {
				$CommunityIds[] = $Val['id'];
			}
			if(array_filter($CommunityIds)){
				$Where .= ' and C.community_id in('.implode(',',array_filter($CommunityIds)).')';
			}else{
				$Results['list'] = array();
				$Results['count'] = 0;
				return  $Results;
			}
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 10;
		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];

		$Results['list'] = $this->CaseListFormat(DB::fetch_all("SELECT C.*,CC.name as company_name,CC.logo as company_logo FROM ".DB::table($this->TableCase)." C LEFT JOIN `".DB::table($this->TableCompany)."` CC on CC.id = C.company_id ".$Where." order by C.topdateline > ".time()." desc, C.updateline desc,C.id desc".$Limit));

		$Results['count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableCase).' C '.$Where);
		
		return $Results;
	}

	/* �����б� */
	public function GetAjaxBuildList($Get){
		
		$Get = StrToGBK($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Where = '';

		if($Get['keyword']){
			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);
			$Where .= ' and ( B.title like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
		}

		if(in_array($Get['display'],array('0','1'))){
			$Where .= ' and B.display = '.intval($Get['display']);
		}

		if($Get['company_id']){
			$Where .= ' and B.company_id = '.intval($Get['company_id']);
		}

		if($Get['community_id']){
			$Where .= ' and B.community_id = '.intval($Get['community_id']);
		}

		if($Get['style']){
			$Where .= ' and B.style = '.intval($Get['style']);
		}

		if($Get['stage']){
			$Where .= ' and B.stage = '.intval($Get['stage']);
		}

		if($Get['forms']){
			$Where .= ' and B.forms = '.intval($Get['forms']);
		}

		if($Get['province'] && !$Get['community_id']){
			$CommunityIds = array();
			foreach (DB::fetch_all('SELECT id FROM '.DB::table($this->TableCommunity).' where display = 1 and province = '.intval($Get['province']).' order by topdateline > '.time().' desc,updateline desc,id desc') as $Key => $Val) {
				$CommunityIds[] = $Val['id'];
			}
			if(array_filter($CommunityIds)){
				$Where .= ' and B.community_id in('.implode(',',array_filter($CommunityIds)).')';
			}else{
				$Results['list'] = array();
				$Results['count'] = 0;
				return  $Results;
			}
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 10;
		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];

		$Results['list'] = $this->BuildListFormat(DB::fetch_all("SELECT B.*,C.name as company_name,C.logo as company_logo FROM ".DB::table($this->TableBuild)." B LEFT JOIN `".DB::table($this->TableCompany)."` C on C.id = B.company_id ".$Where." order by B.updateline desc,B.id desc".$Limit));
		
		$Results['count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableBuild).' B '.$Where);

		return $Results;
	}

	/* ������Ϣ�б� */
	public function GetAjaxBuildInfoList($Get){
		
		$Get = StrToGBK($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Where = '';

		if($Get['build_id']){
			$Where .= ' and B.build_id = '.intval($Get['build_id']);
		}

		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 10;
		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];

		return $this->BuildInfoListFormat(DB::fetch_all("SELECT B.* FROM %t AS B where B.display = 1 ".$Where." order by B.updateline desc,B.id desc".$Limit,array($this->TableBuildInfo)));
	}

	/* ���Ĺ�˾�Ƽ� */
	public function GetIndexMaterialCompanyHotList(){
		return $this->MaterialCompanyListFormat(DB::fetch_all("SELECT C.* FROM %t AS C,%t AS G where C.due_time >= ".time()." and G.company_id = C.id and G.hot = 1 and C.display = 1 order by C.updateline desc,C.id desc",array($this->TableMaterialCompany,$this->TableMaterialCompanyGroupLog)));
	}

	/* ���Ĺ�˾�б� */
	public function GetAjaxMaterialCompanyList($Get){
		
		$Get = StrToGBK($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Where = '';

		if($Get['keyword']){
			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);
			$Where .= ' and (C.name like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\'))';
		}

		if($Get['province']){
			$Where .= ' and C.province = \''.addslashes(strip_tags($Get['province'])).'\'';
			if($Get['city']){
				$Where .= ' and C.city = \''.addslashes(strip_tags($Get['city'])).'\'';
				if($Get['dist']){
					$Where .= ' and C.dist = \''.addslashes(strip_tags($Get['dist'])).'\'';
				}
			}
		}

		if(in_array($Get['verify'],array('0','1'))){
			$Where .= ' and C.verify = '.intval($Get['verify']);
		}

		if($Get['classid']){
			$Where .= ' and C.classid = '.intval($Get['classid']);
		}

		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 10;

		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];

		return $this->MaterialCompanyListFormat(DB::fetch_all('SELECT C.*,G.title,G.ico FROM '.DB::table($this->TableMaterialCompany).' C LEFT JOIN `'.DB::table($this->TableMaterialCompanyGroup).'` G on G.id = C.group_id where C.display = 1 '.$Where.' order by C.due_time > '.time().' desc,C.topdateline > '.time().' desc, C.updateline desc,C.id desc'.$Limit));

	}

	/* ���İ����б� */
	public function GetAjaxMaterialCaseList($Get){
		
		$Get = StrToGBK($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Where = '';

		if($Get['keyword']){
			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);
			$Where .= ' and ( C.title like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
		}

		if(in_array($Get['display'],array('0','1'))){
			$Where .= ' and C.display = '.intval($Get['display']);
		}

		if($Get['company_id']){
			$Where .= ' and C.company_id = '.intval($Get['company_id']);
		}

		if($Get['index']){
			$Where .= ' and C.index = '.intval($Get['index']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 10;
		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];

		$Results['list'] = $this->MaterialCaseListFormat(DB::fetch_all("SELECT C.*,MC.name as company_name,MC.logo as company_logo FROM ".DB::table($this->TableMaterialCase)." C LEFT JOIN `".DB::table($this->TableMaterialCompany)."` MC on MC.id = C.company_id ".$Where." order by C.topdateline > ".time()." desc, C.updateline desc,C.id desc".$Limit));

		$Results['count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableMaterialCase).' C '.$Where);
		
		return $Results;
	}

	/* ������Ʒ�б� */
	public function GetAjaxGoodsList($Get){
		
		$Get = StrToGBK($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Where = '';

		if($Get['keyword']){
			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);
			$Where .= ' and ( G.title like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
		}

		if(in_array($Get['display'],array('0','1'))){
			$Where .= ' and G.display = '.intval($Get['display']);
		}

		if($Get['company_id']){
			$Where .= ' and G.company_id = '.intval($Get['company_id']);
		}

		if($Get['type']){
			$Where .= ' and G.type = '.intval($Get['type']);
		}

		if($Get['index']){
			$Where .= ' and G.index = '.intval($Get['index']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 10;
		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];

		$Results['list'] = $this->GoodsListFormat(DB::fetch_all("SELECT G.*,C.name as company_name,C.logo as company_logo FROM ".DB::table($this->TableMaterialGoods)." G LEFT JOIN `".DB::table($this->TableMaterialCompany)."` C on C.id = G.company_id ".$Where." order by G.topdateline > ".time()." desc, G.updateline desc,G.id desc".$Limit));

		$Results['count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableMaterialGoods).' G '.$Where);
		
		return $Results;
	}

	/* ʦ���б� */
	public function GetAjaxArtisanList($Get){
		
		$Get = StrToGBK($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		
		$Where = $this->Config['PluginVar']['ArtisanListVip'] ? ' and A.due_time >= '.time() : '';

		if($Get['keyword']){
			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);
			$Where .= ' and ( A.name like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') or A.range like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
		}

		if(in_array($Get['display'],array('0','1'))){
			$Where .= ' and A.display = '.intval($Get['display']);
		}
		$TagArray = array_filter(explode(',',$Get['decoration'].','.$Get['install'].','.$Get['repair'].','.$Get['other']));
		if($TagArray){
			foreach($TagArray as $K => $V){
				$Where .= ' and FIND_IN_SET('.intval($V).',A.tag)';
			}
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 10;
		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];

		$Results['list'] = $this->ArtisanListFormat(DB::fetch_all("SELECT A.* FROM ".DB::table($this->TableArtisan).' A '.$Where." order by A.topdateline > ".time()." desc, A.updateline desc,A.id desc".$Limit));

		$Results['count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableArtisan).' A '.$Where);
		
		return $Results;
	}
	
	/* ��˾����Ŷ� */
	public function GetCompanyDesignList($CompanyId){
		return $this->DesignListFormat(DB::fetch_all("SELECT D.*,C.name as company_name FROM %t AS D,%t AS C where C.id = D.company_id and D.company_id = ".intval($CompanyId)." and D.display = 1 order by D.updateline desc,D.id desc",array($this->TableDesign,$this->TableCompany)));
	}

	/* �ҵĹ�˾����Ŷ� */
	public function GetUserCompanyDesignList($CompanyId){
		return $this->DesignListFormat(DB::fetch_all("SELECT D.*,C.name as company_name FROM %t AS D,%t AS C where C.id = D.company_id and D.company_id = ".intval($CompanyId)." order by D.updateline desc,D.id desc",array($this->TableDesign,$this->TableCompany)));
	}

	/* ��˾�б���ʽת�� */
	public function CompanyListFormat($Array,$Click=false){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['url'] = $this->Rewrite('view_company',array('cid'=>$Val['id']));
			$Array[$Key]['username'] = DeleteHtml($Val['username']);
			$Array[$Key]['name'] = DeleteHtml($Val['name']);
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['vip'] = $Val['due_time'] > time() ? 1 : '';
			$Array[$Key]['logo'] = $Val['logo'] ? $Val['logo'] : $this->Config['PluginVar']['CompanyDefaultPath'];
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d') : '';
			$Array[$Key]['province_text'] = $this->Area[$Val['province']]['content'].($Val['city'] ? '-'.$this->Area[$Val['city']]['content'] : '').($Val['dist'] ? '-'.$this->Area[$Val['dist']]['content'] : '');
			$Array[$Key]['content'] = cutstr(DeleteHtml($Val['content']),30);
			$Array[$Key]['case_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableCase).' where display = 1 and company_id = '.intval($Val['id']));
			$Array[$Key]['build_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableBuild).' where display = 1 and company_id = '.intval($Val['id']));
			$Array[$Key]['grade_html'] = '';
			for($I = 1;$I < 6;$I++){
				$GradeArray = array_filter(explode(".",$Val['grade']));
				if($GradeArray['1'] && $I - 1 == $GradeArray['0']){
					$Array[$Key]['grade_html'] .= '<i class=Half></i>';
				}else if($I < $Val['grade'] || $I == $Val['grade']){
					$Array[$Key]['grade_html'] .= '<i></i>';
				}else{
					$Array[$Key]['grade_html'] .= '<i class=Nothing></i>';
				}
			}
			if($Click){
				Click($this->TableCompany,$Val['id']);
			}
			
		}
		return $Array;
	}

	/* �����б���ʽת�� */
	public function CaseListFormat($Array,$Click=false){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['url'] = $this->Rewrite('view_case',array('cid'=>$Val['id']));
			$Array[$Key]['username'] = DeleteHtml($Val['username']);
			$Array[$Key]['title'] = DeleteHtml($Val['title']);
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['topdateline'] = $Val['topdateline'] ? date('Y-m-d H:i',$Val['topdateline']) : $Val['topdateline'];
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d') : '';
			$Array[$Key]['content'] = cutstr(DeleteHtml($Val['content']),50);
			$Array[$Key]['class_text'] = $this->Config['LangVar']['ClassArray'][$Val['class']];
			$Array[$Key]['style_text'] = $this->Config['LangVar']['style'][$Val['style']];
			$Array[$Key]['apartment_text'] = $this->Config['LangVar']['apartment'][$Val['apartment']];
			$Array[$Key]['money_text'] = $this->Config['LangVar']['case_money'][$Val['money']];
			$Array[$Key]['type_text'] = $this->Config['LangVar']['case_type'][$Val['type']];
			$Array[$Key]['min_class'] = $Val['class'];
			$Array[$Key]['display_text'] = $Val['display'] ? $this->Config['LangVar']['Display1'] : $this->Config['LangVar']['Display0'];
			if($Click){
				Click($this->TableCase,$Val['id']);
			}
		}
		return $Array;
	}

	/* С���б���ʽת�� */
	public function CommunityListFormat($Array,$Click=false){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Array[$Key]['url'] = $this->Rewrite('view_community',array('cid'=>$Val['id']));
			$Array[$Key]['name'] = DeleteHtml($Val['name']);
			$Array[$Key]['thumbnail'] = $Val['thumbnail'] ? $Val['thumbnail'] : $this->Config['PluginVar']['CommunityDefaultPath'];
			$Array[$Key]['province_text'] = $this->Area[$Val['province']]['content'].($Val['city'] ? '-'.$this->Area[$Val['city']]['content'] : '').($Val['dist'] ? '-'.$this->Area[$Val['dist']]['content'] : '');
			$Array[$Key]['case_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableCase).' where display = 1 and community_id = '.intval($Val['id']));
			$Array[$Key]['build_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableBuild).' where display = 1 and community_id = '.intval($Val['id']));
			if($Click){
				Click($this->TableCommunity,$Val['id']);
			}
		}
		return $Array;
	}

	/* �����б���ʽת�� */
	public function BuildListFormat($Array,$Click=false){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Array[$Key]['url'] = $this->Rewrite('view_build',array('bid'=>$Val['id']));
			$Array[$Key]['title'] = DeleteHtml($Val['title']);
			$Array[$Key]['style_text'] = $this->Config['LangVar']['style'][$Val['style']];
			$Array[$Key]['apartment_text'] = $this->Config['LangVar']['apartment'][$Val['apartment']];
			$Array[$Key]['forms_text'] = $this->Config['LangVar']['DecorationFormArray'][$Val['forms']];
			$Array[$Key]['stage_text'] = $this->Config['LangVar']['StageArray'][$Val['stage']];
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d') : '';
			$InfoList = $this->BuildInfoListFormat(DB::fetch_all("SELECT B.* FROM %t AS B where B.display = 1 and B.build_id = ".intval($Val['id'])." order by B.updateline desc,B.id desc limit 0,1",array($this->TableBuildInfo)));
			$Array[$Key]['info_list'] = $InfoList[0] ? $InfoList[0] : '';
			if($Click){
				Click($this->TableBuild,$Val['id']);
			}
		}
		return $Array;
	}

	/* ���ؽ����б���ʽת�� */
	public function BuildInfoListFormat($Array){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['stage_text'] = $this->Config['LangVar']['StageArray'][$Val['stage']];
			$Array[$Key]['content'] = DeleteHtml($Val['content']);
		}
		return $Array;
	}
	
	/* ����б���ʽת�� */
	public function DesignListFormat($Array,$Click=false){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Array[$Key]['url'] = $this->Rewrite('view_design',array('did'=>$Val['id']));
			$Array[$Key]['username'] = DeleteHtml($Val['username']);
			$Array[$Key]['name'] = DeleteHtml($Val['name']);
			$Array[$Key]['company_name'] = DeleteHtml($Val['company_name']);
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d') : '';
			$Array[$Key]['content'] = cutstr(DeleteHtml($Val['content']),30);
			$Array[$Key]['idea'] = cutstr(DeleteHtml($Val['idea']),30);
			$Array[$Key]['experience_text'] = $this->Config['LangVar']['design_experience'][$Val['experience']];
			if($Click){
				Click($this->TableDesign,$Val['id']);
			}
			
		}
		return $Array;
	}

	/* ���Ĺ�˾�б���ʽת�� */
	public function MaterialCompanyListFormat($Array,$Click=false){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			
			$Array[$Key]['url'] = $this->Rewrite('view_material_company',array('cid'=>$Val['id']));
			$Array[$Key]['username'] = DeleteHtml($Val['username']);
			$Array[$Key]['name'] = DeleteHtml($Val['name']);
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['vip'] = $Val['due_time'] > time() ? 1 : '';
			$Array[$Key]['logo'] = $Val['logo'] ? $Val['logo'] : $this->Config['PluginVar']['MaterialCompanyDefaultPath'];
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d') : '';
			$Array[$Key]['province_text'] = $this->Area[$Val['province']]['content'].($Val['city'] ? '-'.$this->Area[$Val['city']]['content'] : '').($Val['dist'] ? '-'.$this->Area[$Val['dist']]['content'] : '');
			$Array[$Key]['content'] = '';
			$Array[$Key]['case_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableMaterialCase).' where display = 1 and company_id = '.intval($Val['id']));
			$Array[$Key]['goods_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableMaterialGoods).' where display = 1 and company_id = '.intval($Val['id']));
			$Array[$Key]['param'] = '';
			$Array[$Key]['grade_html'] = '';
			for($I = 1;$I < 6;$I++){
				$GradeArray = array_filter(explode(".",$Val['grade']));
				if($GradeArray['1'] && $I - 1 == $GradeArray['0']){
					$Array[$Key]['grade_html'] .= '<i class=Half></i>';
				}else if($I < $Val['grade'] || $I == $Val['grade']){
					$Array[$Key]['grade_html'] .= '<i></i>';
				}else{
					$Array[$Key]['grade_html'] .= '<i class=Nothing></i>';
				}
			}
			if($Click){
				Click($this->TableCompany,$Val['id']);
			}
			
		}
		return $Array;
	}

	/* ���İ����б���ʽת�� */
	public function MaterialCaseListFormat($Array,$Click=false){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['thumbnail'] = $Val['param']['thumbnail'];
			$Array[$Key]['url'] = $this->Rewrite('view_material_case',array('cid'=>$Val['id']));
			$Array[$Key]['username'] = DeleteHtml($Val['username']);
			$Array[$Key]['title'] = DeleteHtml($Val['title']);
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d') : '';
			$Array[$Key]['display_text'] = $Val['display'] ? $this->Config['LangVar']['Display1'] : $this->Config['LangVar']['Display0'];
			$Array[$Key]['content'] = '';
			$Array[$Key]['param'] = '';
			if($Click){
				Click($this->TableMaterialCase,$Val['id']);
			}
			
		}
		return $Array;
	}

	/* ��Ʒ�б���ʽת�� */
	public function GoodsListFormat($Array,$Click=false){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['thumbnail'] = $Val['param']['thumbnail'];
			$Array[$Key]['url'] = $this->Rewrite('view_goods',array('gid'=>$Val['id']));
			$Array[$Key]['username'] = DeleteHtml($Val['username']);
			$Array[$Key]['title'] = DeleteHtml($Val['title']);
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d') : '';
			$Array[$Key]['type_text'] = $this->Config['LangVar']['GoodsType'][$Val['type']];
			$Array[$Key]['price_name_text'] = $this->Config['LangVar']['GoodsPriceTag'][$Val['price_name']];
			$Array[$Key]['display_text'] = $Val['display'] ? $this->Config['LangVar']['Display1'] : $this->Config['LangVar']['Display0'];
			$Array[$Key]['content'] = '';
			$Array[$Key]['param'] = '';
			if($Click){
				Click($this->TableMaterialGoods,$Val['id']);
			}
			
		}
		return $Array;
	}

	/* ʦ���б���ʽת�� */
	public function ArtisanListFormat($Array,$Click=false){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['url'] = $this->Rewrite('view_artisan',array('aid'=>$Val['id']));
			$Array[$Key]['username'] = DeleteHtml($Val['username']);
			$Array[$Key]['name'] = DeleteHtml($Val['name']);
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['vip'] = $Val['due_time'] > time() ? 1 : '';
			$Array[$Key]['face'] = $Val['face'] ? $Val['face'] : $this->Config['PluginVar']['ArtisanDefaultPath'];
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d') : '';
			$Array[$Key]['content'] = cutstr(DeleteHtml($Val['content']),30);
			$Array[$Key]['range'] = cutstr(DeleteHtml($Val['range']),30);
			$Array[$Key]['work_years_age'] = date('Y') - $Val['work_years'] >= 1 ? date('Y') - $Val['work_years'] : 1;
			$Array[$Key]['grade_html'] = '';
			for($I = 1;$I < 6;$I++){
				$GradeArray = array_filter(explode(".",$Val['grade']));
				if($GradeArray['1'] && $I - 1 == $GradeArray['0']){
					$Array[$Key]['grade_html'] .= '<i class=Half></i>';
				}else if($I < $Val['grade'] || $I == $Val['grade']){
					$Array[$Key]['grade_html'] .= '<i></i>';
				}else{
					$Array[$Key]['grade_html'] .= '<i class=Nothing></i>';
				}
			}
			if($Click){
				Click($this->TableArtisan,$Val['id']);
			}
			
		}
		return $Array;
	}

	/* �ײ��б� */
	public function GetCompanyGroupList(){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableCompanyGroup).' order by displayorder desc');//��������
	}

	/* ��ͨ�ײ� */
	public function GetAjaxBuyStoreLevel($Get){
		global $_G;
		$ItemGroup = DB::fetch_first('SELECT * FROM '.DB::table($this->TableCompanyGroup).' where id = '.$Get['group_id']);
		if(!$ItemGroup){
			$Data['Msg'] = urlencode($this->Config['LangVar']['PayErr']);
		}else{
			$Item = $this->GetViewCompanythread($Get['company_id']);
			$ItemGroup['param'] = unserialize($ItemGroup['param']);

			if($ItemGroup['money']){
				$PayLog = $this->GetAjaxPayLog(array('money'=>$ItemGroup['money'],'event'=>'buy_store_level','company_id'=>$Item['id'],'group_id'=>$ItemGroup['id'],'month'=>$ItemGroup['group_time']));
				$Data['Money'] = $ItemGroup['money'];
				$Data['PayId'] = $PayLog['Id'];
				$Data['State'] = 200;
			}else{
				if($Item['experience'] && $ItemGroup['experience']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['ExperienceTips']);
				}else{
					$UpData['group_id'] = $ItemGroup['id'];
					$UpData['due_time'] = $Item['due_time'] >= time() && $Item['group_id'] == $ItemGroup['id'] ? strtotime("+".intval($ItemGroup['group_time'])."  month",$Item['due_time']) : strtotime("+".intval($ItemGroup['group_time'])."  month",time());
					$UpData['experience'] = $ItemGroup['experience'] ? 1 : 0;
					$UpData['display'] = 1;
					DB::update($this->TableCompany,$UpData,'id = '.$Item['id']);

					/* Ȩ������ */
					$GroupLogItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableCompanyGroupLog).' where company_id = '.$Item['id']);
					$GroupLogUpData['company_id'] = $Get['company_id'];
					$GroupLogUpData['refresh_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? $ItemGroup['param']['refresh_count'] + $GroupLogItem['refresh_count'] : $ItemGroup['param']['refresh_count'];
					$GroupLogUpData['day_refresh_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? $ItemGroup['param']['day_refresh_count'] + $GroupLogItem['param']['day_refresh_count'] : $ItemGroup['day_refresh_count'];
					$GroupLogUpData['case_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? $ItemGroup['param']['case_count'] + $GroupLogItem['case_count'] : $ItemGroup['param']['case_count'];
					$GroupLogUpData['build_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? $ItemGroup['param']['build_count'] + $GroupLogItem['build_count'] : $ItemGroup['param']['build_count'];
					$GroupLogUpData['team_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? $ItemGroup['param']['team_count'] + $GroupLogItem['team_count'] : $ItemGroup['param']['team_count'];
					$GroupLogUpData['examine'] = $ItemGroup['param']['examine'];
					$GroupLogUpData['top_discount'] = $ItemGroup['param']['top_discount'];
					$GroupLogUpData['hot'] = $ItemGroup['param']['hot'];
					$GroupLogUpData['refresh_type'] = $ItemGroup['param']['refresh_type'];
					$GroupLogUpData['sms'] = $ItemGroup['param']['sms'];
					$GroupLogUpData['banner'] = $ItemGroup['param']['banner'];
					$GroupLogItem ? DB::update($this->TableCompanyGroupLog,$GroupLogUpData,'company_id = '.$Item['id']) : DB::insert($this->TableCompanyGroupLog,$GroupLogUpData);
					/* Ȩ������ */

					$Data['Msg'] = urlencode($Item['vip'] ? $this->Config['LangVar']['BuyStoreLevelRenewOk'] : $this->Config['LangVar']['BuyStoreLevelOpenOK']);
					$Data['State'] = 201;
				}
				
			}
			
		}
		return $Data;
	}

	/* ˢ��װ�޹�˾ */
	public function GetAjaxCompanyRefresh($Get){
		global $_G;
		return $this->GetAjaxPayLog(array('event'=>'company_refresh','money'=>$this->Config['PluginVar']['company_refresh_money'],'company_id'=>$Get['company_id'],'updateline'=>time()));
		return $Data;
	}

	//���湫˾����
	public function GetAjaxUserCompany($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->GetViewCompanythread($Get['company_id']);
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['name'] = censor(addslashes(strip_tags($Get['name'])));
		$UpData['province'] = addslashes(strip_tags($Get['province']));
		$UpData['city'] = addslashes(strip_tags($Get['city']));
		$UpData['dist'] = addslashes(strip_tags($Get['dist']));
		$UpData['community'] = censor(addslashes(strip_tags($Get['community'])));
		$UpData['lat'] = addslashes(strip_tags($Get['lat']));
		$UpData['lng'] = addslashes(strip_tags($Get['lng']));
		$UpData['landline'] = censor(addslashes(strip_tags($Get['landline'])));
		$UpData['mobile'] = censor(addslashes(strip_tags($Get['mobile'])));
		$UpData['content'] = addslashes(str_replace("\r\n","<br>",$Get['content']));
		$UpData['display'] = $Item ? $Item['display'] : ( $this->Config['PluginVar']['CompanyDisplaySwitch'] ? 0 : 1 );
		
		foreach(array_filter(explode(';',$Get['new_logo'][0])) as $Key => $Val) {
			$Get['new_logo'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$UpData['logo'] = $Get['new_logo'][0];

		foreach(array_filter(explode(';',$Get['new_banner'][0])) as $Key => $Val) {
			$Get['new_banner'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$UpData['banner'] = is_array($Get['new_banner']) && isset($Get['new_banner']) ? implode(',',array_filter($Get['new_banner'])) : '';

		foreach(array_filter(explode(';',$Get['new_license'][0])) as $Key => $Val) {
			$Get['new_license'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['license'] = $Get['new_license'][0];
		
		if(!$UpData['logo']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['UploadLogoTips']);
			return $Data;
		}

		if(!$Param['license'] && $this->Config['PluginVar']['CompanyLicenseSwitch'] && !$Item['verify']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['UploadLicenseTips']);
			return $Data;
		}
		
		if(!$UpData['name']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyNamePlaceholder']);
			return $Data;
		}

		if(!$UpData['province']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RegionPlaceholder']);
			return $Data;
		}

		if(!$UpData['lat'] && !$UpData['lng'] && $this->Config['PluginVar']['CompanyMapSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['TaggingTips']);
			return $Data;
		}

		if(!$UpData['community']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyCommunityPlaceholder']);
			return $Data;
		}

		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		$IsLandline = "/".$Config['PluginVar']['LandlineMatch']."/";
		if(!$UpData['landline']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactPlaceholder']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['landline']) && !preg_match($IsLandline,$UpData['landline'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
			return $Data;
		}

		if(!$UpData['mobile']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ShortMessageTelTips']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['mobile'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr1']);
			return $Data;
		}

		$UpData['param'] = serialize($Param);

		if($Item){//����
			$Data['Id'] = $Item['id'];
			if(DB::update($this->TableCompany,$UpData,'id = '.intval($Item['id']))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);	
			}
		}else{//���
			$UpData['dateline'] = $UpData['updateline'] = time();
			$Data['Id'] = DB::insert($this->TableCompany,$UpData,true);
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddCompanyOk']);
		}

		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_crm')){
			@require_once (DISCUZ_ROOT.'./source/plugin/fn_crm/Function.inc.php');
			if(!DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where project = \'fn_renovation\' and  project_id = '.$Data['Id'])){
				DB::insert($Fn_Crm->TableCustomer,array('name'=>$UpData['name'],'project'=>'fn_renovation','project_id'=>$Data['Id'],'decision_mobile'=>$UpData['mobile'],'dateline'=>time()));
			}
		}

		//��Ϣ֪ͨ
		if(!$UpData['display'] && !$Item){
			foreach($this->AdminUidsList as $Key => $Val) {
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$this->Config['ViewCompanyUrl'].$Data['Id'],
						'msg'=>str_replace(array('{Title}'),array($UpData['name']),$this->Config['LangVar']['CompanyPush'])
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['ViewCompanyUrl'].$Data['Id'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv(str_replace(array('{Title}'),array($UpData['name']),$this->Config['LangVar']['CompanyPush']),CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}
			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv(str_replace(array('{Title}'),array($UpData['name']),$this->Config['LangVar']['CompanyPush']),CHARSET,'UTF-8'),
					'url'=>$this->Config['ViewCompanyUrl'].$Data['Id']
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
		}
		//��Ϣ֪ͨEnd

		return $Data;
	}

	//���永��
	public function GetAjaxUserCase($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->GetViewCasethread($Get['case_id']);
		$CommunityItem = $this->GetViewCommunitythread($Get['community_id']);
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['company_id'] = intval($Get['company_id']);
		$UpData['community_id'] = intval($Get['community_id']);
		$UpData['design_id'] = intval($Get['design_id']);
		$UpData['title'] = addslashes(strip_tags($Get['title']));
		$UpData['class'] = in_array($Get['class'],array('1','2','3')) ? intval($Get['class']) : 1;
		$UpData['style'] = intval($Get['style']);
		$UpData['apartment'] = intval($Get['apartment']);
		$UpData['money'] = intval($Get['money']);
		$UpData['square'] = intval($Get['square']);
		$UpData['type'] = intval($Get['type']);
		$UpData['local'] = intval($Get['local']);
		$UpData['space'] = intval($Get['space']);
		$UpData['url'] = addslashes(strip_tags($Get['url']));
		$UpData['content'] = addslashes(str_replace("\r\n","<br>",$Get['content']));

		foreach(array_filter(explode(';',$Get['new_thumbnail'][0])) as $Key => $Val) {
			$Get['new_thumbnail'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$UpData['thumbnail'] = $Get['new_thumbnail'][0];

		foreach(array_filter(explode(';',$Get['new_content_imgs'][0])) as $Key => $Val) {
			$Get['new_content_imgs'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['content_imgs'] = is_array($Get['new_content_imgs']) && isset($Get['new_content_imgs']) ? $Get['new_content_imgs'] : '';

		$CompanyItem = $this->GetUserCompanyAdmin($Get['company_id']);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}else if(!$CompanyItem['vip']){
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoVipErr']);
			return $Data;
		}else if($CompanyItem['vip'] && $CompanyItem['group_case_count'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableCase).' where display = 1 and company_id = '.intval($CompanyItem['id'])) >= $CompanyItem['group_case_count'] && !$Item){
			$Data['Msg'] = urlencode(str_replace('{count}',$CompanyItem['group_case_count'],$this->Config['LangVar']['UserCaseCountErr']));
			return $Data;
		}

		if(!$UpData['thumbnail']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ThumbnailTips']);
			return $Data;
		}

		if(!$UpData['title']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CaseAddTitlePlaceholder']);
			return $Data;
		}
		
		if($UpData['class'] == 1){
			if(!$Param['content_imgs']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['CasePicturesTips']);
				return $Data;
			}

			if(!$UpData['square']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['CaseSquarePlaceholder']);
				return $Data;
			}else if($UpData['square'] && !preg_match("/^[0-9.]+$/",$UpData['square'])){
				$Data['Msg'] = urlencode($this->Config['LangVar']['SquareErr2']);
				return $Data;
			}

		}else if($UpData['class'] == 2){
			if(!$UpData['url']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['CaseUrlPlaceholder']);
				return $Data;
			}
		}else if($UpData['class'] == 3){
			
		}
		
		if(!$UpData['style']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CaseStylePlaceholder'][$UpData['class']]);
			return $Data;
		}

		if(!$CommunityItem){
			$Get['community_name'] = str_replace(array('%','_'),array('',''),$Get['community_name']);
			$CommunityItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableCommunity).' where name like(\'%'.addslashes(strip_tags($Get['community_name'])).'%\')');
			if(!$CommunityItem){
				$CommunityUpData['name'] = censor(addslashes(strip_tags($Get['community_name'])));
				$CommunityUpData['uid'] = $UpData['uid'];
				$CommunityUpData['username'] = $UpData['username'];
				$CommunityUpData['province'] = addslashes(strip_tags($Get['province']));
				$CommunityUpData['city'] = addslashes(strip_tags($Get['city']));
				$CommunityUpData['dist'] = addslashes(strip_tags($Get['dist']));
				$CommunityUpData['community'] = censor(addslashes(strip_tags($Get['community'])));
				$CommunityUpData['lat'] = addslashes(strip_tags($Get['lat']));
				$CommunityUpData['lng'] = addslashes(strip_tags($Get['lng']));
				$CommunityUpData['display'] = 1;
				$CommunityUpData['dateline'] = $CommunityUpData['updateline'] = time();
				
				if(!$CommunityUpData['province']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['RegionPlaceholder']);
					return $Data;
				}

				if(!$CommunityUpData['lat'] && !$CommunityUpData['lng']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['TaggingTips']);
					return $Data;
				}
				$UpData['community_id'] = DB::insert($this->TableCommunity,$CommunityUpData,true);
			}else{
				$UpData['community_id'] = intval($CommunityItem['id']);
			}
		}
		

		$UpData['param'] = serialize($Param);
		if($Item){//����
			if(DB::update($this->TableCase,$UpData,'id = '.intval($Item['id']))){
				$Data['State'] = 200;
				$Data['Id'] = $Item['id'];
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);	
			}
		}else{//���
			$UpData['display'] = $CompanyItem['examine'] ? 1 : 0;
			$UpData['dateline'] = $UpData['updateline'] = time();
			$Data['Id'] = DB::insert($this->TableCase,$UpData,true);
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddOk'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));;
		}

		//��Ϣ֪ͨ
		if(!$UpData['display']){
			foreach($this->AdminUidsList as $Key => $Val) {
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$this->Config['ViewCaseUrl'].$Data['Id'],
						'msg'=>str_replace(array('{Title}'),array($UpData['title']),$this->Config['LangVar']['CasePush'])
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['ViewCaseUrl'].$Data['Id'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv(str_replace(array('{Title}'),array($UpData['title']),$this->Config['LangVar']['CasePush']),CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}

			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv(str_replace(array('{Title}'),array($UpData['title']),$this->Config['LangVar']['CasePush']),CHARSET,'UTF-8'),
					'url'=>$this->Config['ViewCaseUrl'].$Data['Id']
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
		}
		//��Ϣ֪ͨEnd
		return $Data;
	}

	/* �������� */
	public function GetAjaxUserCaseOp($Op,$Id,$CompanyId,$Field=null,$Value=null){
		global $_G;
		$Id = intval($Id);
		$CompanyId = intval($CompanyId);
		$CompanyItem = $this->GetUserCompanyAdmin($CompanyId);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}
		if($Op == 'Del'){
			if(DB::delete($this->TableCase,'id ='.$Id.' and company_id = '.$CompanyId)){
				DB::delete($this->TableCaseRefreshLog,'case_id ='.$Id);
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else if($Op == 'Edit'){
			if(DB::update($this->TableCase,array($Field=>addslashes(strip_tags($Value))),'id = '.$Id.' and company_id = '.$CompanyId)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
	}

	/* ���ˢ�°��� */
	public function GetAjaxUserRefreshCase($Get){
		global $_G;
		$Get = EncodeURIToUrldeCode($Get);

		$CompanyItem = $this->GetUserCompanyAdmin($Get['company_id']);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}

		if(!$CompanyItem['vip']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoRefreshAuthority']);
			return $Data;
		}

		if(!$CompanyItem['RemnantRefreshCount'] && $CompanyItem['refresh_count'] && $CompanyItem['refresh_type'] == 2){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RefreshCountErr']);
			return $Data;
		}

		if(!$CompanyItem['RemnantDayRefreshCount'] && $CompanyItem['day_refresh_count'] && $CompanyItem['refresh_type'] == 1){
			$Data['Msg'] = urlencode($this->Config['LangVar']['DayRefreshErr']);
			return $Data;
		}
	
		$UpData['case_id'] = intval($Get['case_id']);
		$UpData['company_id'] = intval($Get['company_id']);
		$UpData['dateline'] = time();
		
		$LogId = DB::insert($this->TableCaseRefreshLog,$UpData,true);
		if($LogId && DB::update($this->TableCase,array('updateline'=>time()),' id = '.intval($Get['case_id']))){
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['RefreshOk']);
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['DayRefreshErr2']);
		}
		return $Data;
	}

	//�����ڽ�����
	public function GetAjaxUserBuild($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->GetViewBuildthread($Get['build_id']);
		$CommunityItem = $this->GetViewCommunitythread($Get['community_id']);
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['company_id'] = intval($Get['company_id']);
		$UpData['community_id'] = intval($Get['community_id']);
		$UpData['community_name'] = censor(addslashes(strip_tags($CommunityItem['name'])));
		$UpData['title'] = censor(addslashes(strip_tags($Get['title'])));
		$UpData['style'] = intval($Get['style']);
		$UpData['apartment'] = intval($Get['apartment']);
		$UpData['forms'] = intval($Get['forms']);
		$UpData['square'] = intval($Get['square']);
		$UpData['money'] = addslashes(strip_tags($Get['money']));
		$UpData['stage'] = intval($Get['stage']);

		foreach(array_filter(explode(';',$Get['new_thumbnail'][0])) as $Key => $Val) {
			$Get['new_thumbnail'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$UpData['thumbnail'] = $Get['new_thumbnail'][0];
		
		$CompanyItem = $this->GetUserCompanyAdmin($Get['company_id']);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}else if(!$CompanyItem['vip']){
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoVipErr']);
			return $Data;
		}else if($CompanyItem['vip'] && $CompanyItem['group_build_count'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableBuild).' where display = 1 and company_id = '.intval($CompanyItem['id'])) >= $CompanyItem['group_build_count'] && !$Item){
			$Data['Msg'] = urlencode(str_replace('{count}',$CompanyItem['group_build_count'],$this->Config['LangVar']['UserBuildCountErr']));
			return $Data;
		}

		if(!$UpData['thumbnail']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ThumbnailTips']);
			return $Data;
		}

		if(!$UpData['title']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['DecorationTitlePlaceholder']);
			return $Data;
		}

		if(!$UpData['square']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['DecorationSquarePlaceholder']);
			return $Data;
		}else if($UpData['square'] && !preg_match("/^[0-9.]+$/",$UpData['square'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['SquareErr2']);
			return $Data;
		}


		if(!$UpData['money']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['DecorationFeePlaceholder']);
			return $Data;
		}else if($UpData['money'] && !preg_match("/^[0-9.]+$/",$UpData['money'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['DecorationFeeErr2']);
			return $Data;
		}

		if(!$UpData['style']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['DecorationStylePlaceholder']);
			return $Data;
		}

		if(!$CommunityItem){
			$Get['community_name'] = str_replace(array('%','_'),array('',''),$Get['community_name']);
			$CommunityItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableCommunity).' where name like(\'%'.addslashes(strip_tags($Get['community_name'])).'%\')');
			if(!$CommunityItem){
				$CommunityUpData['name'] = censor(addslashes(strip_tags($Get['community_name'])));
				$CommunityUpData['uid'] = $UpData['uid'];
				$CommunityUpData['username'] = $UpData['username'];
				$CommunityUpData['province'] = addslashes(strip_tags($Get['province']));
				$CommunityUpData['city'] = addslashes(strip_tags($Get['city']));
				$CommunityUpData['dist'] = addslashes(strip_tags($Get['dist']));
				$CommunityUpData['community'] = censor(addslashes(strip_tags($Get['community'])));
				$CommunityUpData['lat'] = addslashes(strip_tags($Get['lat']));
				$CommunityUpData['lng'] = addslashes(strip_tags($Get['lng']));
				$CommunityUpData['display'] = 1;
				$CommunityUpData['dateline'] = $CommunityUpData['updateline'] = time();
				
				if(!$CommunityUpData['province']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['RegionPlaceholder']);
					return $Data;
				}

				if(!$CommunityUpData['lat'] && !$CommunityUpData['lng']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['TaggingTips']);
					return $Data;
				}
				$UpData['community_id'] = DB::insert($this->TableCommunity,$CommunityUpData,true);
				$UpData['community_name'] = $CommunityUpData['name'];
			}else{
				$UpData['community_id'] = intval($CommunityItem['id']);
				$UpData['community_name'] = censor(addslashes(strip_tags($CommunityItem['name'])));
			}
		}

		if($Item){//����
			if(DB::update($this->TableBuild,$UpData,'id = '.intval($Item['id']))){
				$Data['State'] = 200;
				$Data['Id'] = $Item['id'];
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);	
			}
		}else{//���
			$UpData['display'] = 1;
			$UpData['dateline'] = $UpData['updateline'] = time();
			$Data['Id'] = DB::insert($this->TableBuild,$UpData,true);
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddOk']);
		}
		
		return $Data;
	}

	/* �������� */
	public function GetAjaxUserBuildOp($Op,$Id,$CompanyId,$Field=null,$Value=null){
		global $_G;
		$Id = intval($Id);
		$CompanyId = intval($CompanyId);
		$CompanyItem = $this->GetUserCompanyAdmin($CompanyId);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}
		if($Op == 'Del'){
			if(DB::delete($this->TableBuild,'id ='.$Id.' and company_id = '.$CompanyId)){
				DB::delete($this->TableBuildInfo,'build_id ='.$Id);
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else if($Op == 'Edit'){
			if(DB::update($this->TableBuild,array($Field=>addslashes(strip_tags($Value))),'id = '.$Id.' and company_id = '.$CompanyId)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
	}

	//�����ڽ�������Ϣ
	public function GetAjaxUserBuildInfo($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableBuildInfo).' where id = '.intval($Get['iid']));
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['build_id'] = intval($Get['build_id']);
		$UpData['content'] = censor(addslashes(strip_tags($Get['content'])));
		$UpData['stage'] = intval($Get['stage']);
		foreach(array_filter(explode(';',$Get['new_imgs'][0])) as $Key => $Val) {
			$Get['new_imgs'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['imgs'] = is_array($Get['new_imgs']) && isset($Get['new_imgs'])  ? array_filter($Get['new_imgs']) : '';
		$Param['imgs_count'] = count($Param['imgs']);
		$UpData['param'] = serialize($Param);
		
		$CompanyItem = $this->GetUserCompanyAdmin($Get['company_id']);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}else if(!$CompanyItem['vip']){
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoVipErr']);
			return $Data;
		}

		if(!$Param['imgs'] && !$UpData['content']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['UserBuildInfoErr']);
			return $Data;
		}

		if($Item){//����
			if(DB::update($this->TableBuildInfo,$UpData,'id = '.intval($Item['id']))){
				$Data['State'] = 200;
				$Data['Id'] = $Item['id'];
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);	
			}
		}else{//���
			$UpData['display'] = 1;
			$UpData['dateline'] = $UpData['updateline'] = time();
			$Data['Id'] = DB::insert($this->TableBuildInfo,$UpData,true);
			$Data['Id'] ? DB::update($this->TableBuild,array('stage'=>$UpData['stage'],'updateline'=>time()),'id = '.intval($UpData['build_id'])) : '';
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddOk']);
		}
		return $Data;
	}

	/* ����������Ϣ */
	public function GetAjaxUserBuildInfoOp($Op,$Id,$CompanyId,$Field=null,$Value=null){
		global $_G;
		$Id = intval($Id);
		$CompanyId = intval($CompanyId);
		$CompanyItem = $this->GetUserCompanyAdmin($CompanyId);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}
		if($Op == 'Del'){
			if(DB::delete($this->TableBuildInfo,'id ='.$Id)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else if($Op == 'Edit'){
			if(DB::update($this->TableBuildInfo,array($Field=>addslashes(strip_tags($Value))),'id = '.$Id)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
	}

	//�������ʦ
	public function GetAjaxUserDesign($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->GetViewDesignthread($Get['design_id']);
	
		$UpData['company_id'] = intval($Get['company_id']);
		$UpData['name'] = censor(addslashes(strip_tags($Get['name'])));
		$UpData['title'] = censor(addslashes(strip_tags($Get['title'])));
		$UpData['experience'] = intval($Get['experience']);
		$UpData['idea'] = censor(addslashes(strip_tags($Get['idea'])));
		$UpData['content'] = addslashes(str_replace("\r\n","<br>",strip_tags($Get['content'])));

		foreach(array_filter(explode(';',$Get['new_face'][0])) as $Key => $Val) {
			$Get['new_face'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$UpData['face'] = $Get['new_face'][0];

		$CompanyItem = $this->GetUserCompanyAdmin($Get['company_id']);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}else if(!$CompanyItem['vip']){
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoVipErr']);
			return $Data;
		}else if($CompanyItem['vip'] && $CompanyItem['team_count'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableDesign).' where display = 1 and state = 1 and company_id = '.intval($CompanyItem['id'])) >= $CompanyItem['team_count'] && !$Item){
			$Data['Msg'] = urlencode(str_replace('{count}',$CompanyItem['team_count'],$this->Config['LangVar']['UserDesignCountErr']));
			return $Data;
		}

		if(!$UpData['face']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['HeadPortraitPlaceholder']);
			return $Data;
		}

		if(!$UpData['name']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['DesignNamePlaceholder']);
			return $Data;
		}

		if(!$UpData['title']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['DesignTitlePlaceholder']);
			return $Data;
		}

		if(!$UpData['experience']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ExperiencePlaceholder']);
			return $Data;
		}

		if($Item){//����
			$UpData['updateline'] = time();
			if(DB::update($this->TableDesign,$UpData,'id = '.intval($Item['id']))){
				$Data['State'] = 200;
				$Data['Id'] = $Item['id'];
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);	
			}
		}else{//���
			$UpData['display'] = 1;
			$UpData['dateline'] = $UpData['updateline'] = time();
			$Data['Id'] = DB::insert($this->TableDesign,$UpData,true);
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddOk']);
		}
		
		return $Data;
	}

	/* �������ʦ */
	public function GetAjaxUserDesignOp($Op,$Id,$CompanyId,$Field=null,$Value=null){
		global $_G;
		$Id = intval($Id);
		$CompanyId = intval($CompanyId);
		$CompanyItem = $this->GetUserCompanyAdmin($CompanyId);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}
		if($Op == 'Del'){
			if(DB::delete($this->TableDesign,'id ='.$Id.' and company_id = '.$CompanyId)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else if($Op == 'Edit'){
			if(DB::update($this->TableDesign,array($Field=>addslashes(strip_tags($Value))),'id = '.$Id.' and company_id = '.$CompanyId)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
	}

	//���ķ����б�
	public function GetMaterialClassList(){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableMaterialClass).' where display = 1 '.$Where.' order by displayorder asc','','id');
	}

	/* ˢ�½��Ĺ�˾ */
	public function GetAjaxMaterialCompanyRefresh($Get){
		global $_G;
		return $this->GetAjaxPayLog(array('event'=>'material_company_refresh','money'=>$this->Config['PluginVar']['material_company_refresh_money'],'company_id'=>$Get['company_id'],'updateline'=>time()));
		return $Data;
	}

	/* �����ײ��б� */
	public function GetMaterialCompanyGroupList(){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableMaterialCompanyGroup).' order by displayorder desc');//��������
	}

	/* ���Ŀ�ͨ�ײ� */
	public function GetAjaxBuyStoreLevelMaterial($Get){
		global $_G;
		$ItemGroup = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMaterialCompanyGroup).' where id = '.$Get['group_id']);
		if(!$ItemGroup){
			$Data['Msg'] = urlencode($this->Config['LangVar']['PayErr']);
		}else{
			$Item = $this->GetViewMaterialCompanythread($Get['company_id']);
			$ItemGroup['param'] = unserialize($ItemGroup['param']);

			if($ItemGroup['money']){
				$PayLog = $this->GetAjaxPayLog(array('money'=>$ItemGroup['money'],'event'=>'buy_store_level_material','company_id'=>$Item['id'],'group_id'=>$ItemGroup['id'],'month'=>$ItemGroup['group_time']));
				$Data['Money'] = $ItemGroup['money'];
				$Data['PayId'] = $PayLog['Id'];
				$Data['State'] = 200;
			}else{
				if($Item['experience'] && $ItemGroup['experience']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['ExperienceTips']);
				}else{
					$UpData['group_id'] = $ItemGroup['id'];
					$UpData['due_time'] = $Item['due_time'] >= time() && $Item['group_id'] == $ItemGroup['id'] ? strtotime("+".intval($ItemGroup['group_time'])."  month",$Item['due_time']) : strtotime("+".intval($ItemGroup['group_time'])."  month",time());
					$UpData['experience'] = $ItemGroup['experience'] ? 1 : 0;
					$UpData['display'] = 1;
					DB::update($this->TableMaterialCompany,$UpData,'id = '.$Item['id']);

					/* Ȩ������ */
					$GroupLogItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMaterialCompanyGroupLog).' where company_id = '.$Item['id']);
					$GroupLogUpData['company_id'] = $Get['company_id'];
					$GroupLogUpData['goods_count'] = $this->Config['PluginVar']['MaterialGroupSuperpositionSwitch'] ? $ItemGroup['param']['goods_count'] + $GroupLogItem['goods_count'] : $ItemGroup['param']['goods_count'];
					$GroupLogUpData['case_count'] = $this->Config['PluginVar']['MaterialGroupSuperpositionSwitch'] ? $ItemGroup['param']['case_count'] + $GroupLogItem['case_count'] : $ItemGroup['param']['case_count'];
					
					$GroupLogUpData['case_examine'] = $ItemGroup['param']['case_examine'];
					$GroupLogUpData['examine'] = $ItemGroup['param']['examine'];
					$GroupLogUpData['hot'] = $ItemGroup['param']['hot'];
					$GroupLogUpData['sms'] = $ItemGroup['param']['sms'];
					$GroupLogUpData['banner'] = $ItemGroup['param']['banner'];
					$GroupLogItem ? DB::update($this->TableMaterialCompanyGroupLog,$GroupLogUpData,'company_id = '.$Item['id']) : DB::insert($this->TableMaterialCompanyGroupLog,$GroupLogUpData);
					/* Ȩ������ */

					$Data['Msg'] = urlencode($Item['vip'] ? $this->Config['LangVar']['BuyStoreLevelRenewOk'] : $this->Config['LangVar']['BuyStoreLevelOpenOK']);
					$Data['State'] = 201;
				}
				
			}
			
		}
		return $Data;
	}

	//���潨�Ĺ�˾����
	public function GetAjaxUserMaterialCompany($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->GetViewMaterialCompanythread($Get['company_id']);
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['name'] = censor(addslashes(strip_tags($Get['name'])));
		$UpData['province'] = addslashes(strip_tags($Get['province']));
		$UpData['city'] = addslashes(strip_tags($Get['city']));
		$UpData['dist'] = addslashes(strip_tags($Get['dist']));
		$UpData['community'] = censor(addslashes(strip_tags($Get['community'])));
		$UpData['lat'] = addslashes(strip_tags($Get['lat']));
		$UpData['lng'] = addslashes(strip_tags($Get['lng']));
		$UpData['landline'] = censor(addslashes(strip_tags($Get['landline'])));
		$UpData['mobile'] = censor(addslashes(strip_tags($Get['mobile'])));
		$UpData['classid'] = intval($Get['classid']);
		$UpData['content'] = addslashes(str_replace("\r\n","<br>",$Get['content']));
		$UpData['display'] = $Item ? $Item['display'] : ( $this->Config['PluginVar']['CompanyDisplaySwitch'] ? 0 : 1 );
		
		foreach(array_filter(explode(';',$Get['new_logo'][0])) as $Key => $Val) {
			$Get['new_logo'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$UpData['logo'] = $Get['new_logo'][0];

		foreach(array_filter(explode(';',$Get['new_banner'][0])) as $Key => $Val) {
			$Get['new_banner'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$UpData['banner'] = is_array($Get['new_banner']) && isset($Get['new_banner']) ? implode(',',array_filter($Get['new_banner'])) : '';
		
		foreach(array_filter(explode(';',$Get['new_license'][0])) as $Key => $Val) {
			$Get['new_license'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['license'] = $Get['new_license'][0];
		
		if(!$UpData['logo']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['UploadLogoTips']);
			return $Data;
		}

		if(!$Param['license'] && $this->Config['PluginVar']['MaterialCompanyLicenseSwitch'] && !$Item['verify']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['UploadLicenseTips']);
			return $Data;
		}
		
		if(!$UpData['name']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyNamePlaceholder']);
			return $Data;
		}

		if(!$UpData['classid']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyClassTips']);
			return $Data;
		}

		if(!$UpData['province']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RegionPlaceholder']);
			return $Data;
		}

		if(!$UpData['lat'] && !$UpData['lng'] && $this->Config['PluginVar']['CompanyMapSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['TaggingTips']);
			return $Data;
		}

		if(!$UpData['community']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyCommunityPlaceholder']);
			return $Data;
		}

		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		$IsLandline = "/".$Config['PluginVar']['LandlineMatch']."/";
		if(!$UpData['landline']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactPlaceholder']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['landline']) && !preg_match($IsLandline,$UpData['landline'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
			return $Data;
		}

		if(!$UpData['mobile']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ShortMessageTelTips']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['mobile'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr1']);
			return $Data;
		}

		$UpData['param'] = serialize($Param);

		if($Item){//����
			$Data['Id'] = $Item['id'];
			if(DB::update($this->TableMaterialCompany,$UpData,'id = '.intval($Item['id']))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);	
			}
		}else{//���
			$UpData['dateline'] = $UpData['updateline'] = time();
			$Data['Id'] = DB::insert($this->TableMaterialCompany,$UpData,true);
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddCompanyOk']);
		}

		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_crm')){
			@require_once (DISCUZ_ROOT.'./source/plugin/fn_crm/Function.inc.php');
			if(!DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where project = \'fn_renovation_material\' and  project_id = '.$Data['Id'])){
				DB::insert($Fn_Crm->TableCustomer,array('name'=>$UpData['name'],'project'=>'fn_renovation_material','project_id'=>$Data['Id'],'decision_mobile'=>$UpData['mobile'],'dateline'=>time()));
			}
		}

		//��Ϣ֪ͨ
		if(!$UpData['display'] && !$Item){
			foreach($this->AdminUidsList as $Key => $Val) {
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$this->Config['ViewMaterialCompanyUrl'].$Data['Id'],
						'msg'=>str_replace(array('{Title}'),array($UpData['name']),$this->Config['LangVar']['CompanyPush'])
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['ViewMaterialCompanyUrl'].$Data['Id'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv(str_replace(array('{Title}'),array($UpData['name']),$this->Config['LangVar']['CompanyPush']),CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}
			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv(str_replace(array('{Title}'),array($UpData['name']),$this->Config['LangVar']['CompanyPush']),CHARSET,'UTF-8'),
					'url'=>$this->Config['ViewMaterialCompanyUrl'].$Data['Id']
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
		}
		//��Ϣ֪ͨEnd

		return $Data;
	}

	//���潨�İ���
	public function GetAjaxUserMaterialCase($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->GetViewMaterialCasethread($Get['gid']);
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['company_id'] = intval($Get['company_id']);
		$UpData['title'] = censor(addslashes(strip_tags($Get['title'])));
		$UpData['content'] = censor(addslashes(str_replace("\r\n","<br>",$Get['content'])));

		foreach(array_filter(explode(';',$Get['new_banner'][0])) as $Key => $Val) {
			$Get['new_banner'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach(array_filter(explode(';',$Get['new_products'][0])) as $Key => $Val) {
			$Get['new_products'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$UpData['banner'] = is_array($Get['new_banner']) && isset($Get['new_banner']) ? implode(',',array_filter($Get['new_banner'])) : '';
		$UpData['products'] = is_array($Get['new_products']) && isset($Get['new_products']) ? implode(',',array_filter($Get['new_products'])) : '';
		
		$CompanyItem = $this->GetUserMaterialCompanyAdmin($Get['company_id']);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}else if(!$CompanyItem['vip']){
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoVipErr']);
			return $Data;
		}else if($CompanyItem['vip'] && $CompanyItem['group_case_count'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableMaterialCase).' where display = 1 and company_id = '.intval($CompanyItem['id'])) >= $CompanyItem['group_case_count'] && !$Item){
			$Data['Msg'] = urlencode(str_replace('{count}',$CompanyItem['group_case_count'],$this->Config['LangVar']['UserMaterialCaseCountErr']));
			return $Data;
		}

		if(!$UpData['banner']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ProductsErr']);
			return $Data;
		}

		if(!$UpData['title']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CaseAddTitlePlaceholder']);
			return $Data;
		}

		if(!$UpData['content'] && !$UpData['products']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CaseDetailErr']);
			return $Data;
		}

		$Param['thumbnail'] = $Get['new_banner'][0];
		$UpData['param'] = serialize($Param);

		if($Item){//����
			if(DB::update($this->TableMaterialCase,$UpData,'id = '.intval($Item['id']))){
				$Data['State'] = 200;
				$Data['Id'] = $Item['id'];
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);	
			}
		}else{//���
			$UpData['display'] = $CompanyItem['case_examine'] ? 1 : 0;
			$UpData['dateline'] = $UpData['updateline'] = time();
			$Data['Id'] = DB::insert($this->TableMaterialCase,$UpData,true);
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddOk'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));;
		}

		//��Ϣ֪ͨ
		if(!$UpData['display']){
			$PushMsg = str_replace(array('{Title}'),array($UpData['title']),$this->Config['LangVar']['CasePush']);
			$PushUrl = $this->Config['ViewMaterialCaseUrl'].$Data['Id'];
			foreach($this->AdminUidsList as $Key => $Val) {
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$PushUrl,
						'msg'=>$PushMsg
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"link"=> $PushUrl,
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv($PushMsg,CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}

			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv($PushMsg,CHARSET,'UTF-8'),
					'url'=>$PushUrl
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
		}
		//��Ϣ֪ͨEnd
		return $Data;
	}

	/* �������İ��� */
	public function GetAjaxUserMaterialCaseOp($Op,$Id,$CompanyId,$Field=null,$Value=null){
		global $_G;
		$Id = intval($Id);
		$CompanyId = intval($CompanyId);
		$CompanyItem = $this->GetUserMaterialCompanyAdmin($CompanyId);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}
		if($Op == 'Del'){
			if(DB::delete($this->TableMaterialCase,'id ='.$Id.' and company_id = '.$CompanyId)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else if($Op == 'Edit'){
			if(DB::update($this->TableMaterialCase,array($Field=>addslashes(strip_tags($Value))),'id = '.$Id.' and company_id = '.$CompanyId)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
	}

	//������Ʒ
	public function GetAjaxUserGoods($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->GetViewGoodsthread($Get['gid']);
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['company_id'] = intval($Get['company_id']);
		$UpData['title'] = censor(addslashes(strip_tags($Get['title'])));
		$UpData['min_title'] = censor(addslashes(strip_tags($Get['min_title'])));
		$UpData['type'] = intval($Get['type']);
		$UpData['price_name'] = intval($Get['price_name']);
		$UpData['price'] = sprintf("%.2f",substr(sprintf("%.3f",$Get['price']),0,-2));
		$UpData['original_price'] = sprintf("%.2f",substr(sprintf("%.3f",$Get['original_price']),0,-2));
		$UpData['content'] = censor(addslashes(str_replace("\r\n","<br>",$Get['content'])));

		foreach(array_filter(explode(';',$Get['new_banner'][0])) as $Key => $Val) {
			$Get['new_banner'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		foreach(array_filter(explode(';',$Get['new_products'][0])) as $Key => $Val) {
			$Get['new_products'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$UpData['banner'] = is_array($Get['new_banner']) && isset($Get['new_banner']) ? implode(',',array_filter($Get['new_banner'])) : '';
		$UpData['products'] = is_array($Get['new_products']) && isset($Get['new_products']) ? implode(',',array_filter($Get['new_products'])) : '';
		
		$CompanyItem = $this->GetUserMaterialCompanyAdmin($Get['company_id']);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}else if(!$CompanyItem['vip']){
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoVipErr']);
			return $Data;
		}else if($CompanyItem['vip'] && $CompanyItem['group_goods_count'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableMaterialGoods).' where display = 1 and company_id = '.intval($CompanyItem['id'])) >= $CompanyItem['group_goods_count'] && !$Item){
			$Data['Msg'] = urlencode(str_replace('{count}',$CompanyItem['group_goods_count'],$this->Config['LangVar']['UserGoodsCountErr']));
			return $Data;
		}

		if(!$UpData['banner']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ProductsErr']);
			return $Data;
		}

		if(!$UpData['title']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['DecorationTitlePlaceholder']);
			return $Data;
		}

		if(!$UpData['price']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['OriginalPriceTips']);
			return $Data;
		}

		if(!$UpData['original_price']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['DiscountPriceTips']);
			return $Data;
		}

		if(!$UpData['content'] && !$UpData['products']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['GoodsDetailErr']);
			return $Data;
		}

		$Param['thumbnail'] = $Get['new_banner'][0];
		$UpData['param'] = serialize($Param);

		if($Item){//����
			if(DB::update($this->TableMaterialGoods,$UpData,'id = '.intval($Item['id']))){
				$Data['State'] = 200;
				$Data['Id'] = $Item['id'];
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);	
			}
		}else{//���
			$UpData['display'] = $CompanyItem['examine'] ? 1 : 0;
			$UpData['dateline'] = $UpData['updateline'] = time();
			$Data['Id'] = DB::insert($this->TableMaterialGoods,$UpData,true);
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddOk'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));;
		}

		//��Ϣ֪ͨ
		if(!$UpData['display']){
			$PushMsg = str_replace(array('{Title}'),array($UpData['title']),$this->Config['LangVar']['GoodsPush']);
			$PushUrl = $this->Config['ViewGoodsUrl'].$Data['Id'];
			foreach($this->AdminUidsList as $Key => $Val) {
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$PushUrl,
						'msg'=>$PushMsg
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"link"=> $PushUrl,
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv($PushMsg,CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}

			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv($PushMsg,CHARSET,'UTF-8'),
					'url'=>$PushUrl
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
		}
		//��Ϣ֪ͨEnd
		return $Data;
	}

	/* ������Ʒ */
	public function GetAjaxUserGoodsOp($Op,$Id,$CompanyId,$Field=null,$Value=null){
		global $_G;
		$Id = intval($Id);
		$CompanyId = intval($CompanyId);
		$CompanyItem = $this->GetUserMaterialCompanyAdmin($CompanyId);
		if($CompanyItem['msg']){
			$Data['Msg'] = urlencode($CompanyItem['msg']);
			return $Data;
		}
		if($Op == 'Del'){
			if(DB::delete($this->TableMaterialGoods,'id ='.$Id.' and company_id = '.$CompanyId)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else if($Op == 'Edit'){
			if(DB::update($this->TableMaterialGoods,array($Field=>addslashes(strip_tags($Value))),'id = '.$Id.' and company_id = '.$CompanyId)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
	}

	//����ʦ��
	public function GetAjaxUserArtisan($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);

		foreach(array_filter(explode(';',$Get['new_face'][0])) as $Key => $Val) {
			$Get['new_face'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$UpData['face'] = $Get['new_face'][0];
		
		
		foreach(array_filter(explode(';',$Get['new_work_style'][0])) as $Key => $Val) {
			$Get['new_work_style'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}

		$TagArray = array();
		$TagTextArray = array();

		foreach(array_filter(explode(',',$Get['decoration'])) as $Key => $Val) {
			$TagArray[] = $Val;
			$TagTextArray[] = $this->Config['LangVar']['ArtisanRenovation'][$Val];
		}
		foreach(array_filter(explode(',',$Get['install'])) as $Key => $Val) {
			$TagArray[] = $Val;
			$TagTextArray[] = $this->Config['LangVar']['ArtisanInstall'][$Val];
		}
		foreach(array_filter(explode(',',$Get['repair'])) as $Key => $Val) {
			$TagArray[] = $Val;
			$TagTextArray[] = $this->Config['LangVar']['ArtisanRepair'][$Val];
		}
		foreach(array_filter(explode(',',$Get['other'])) as $Key => $Val) {
			$TagArray[] = $Val;
			$TagTextArray[] = $this->Config['LangVar']['ArtisanOther'][$Val];
		}

		$UserInfo = $this->GetUserInfo();
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['name'] = censor(addslashes(strip_tags($Get['name'])));
		$UpData['range'] = censor(addslashes(strip_tags($Get['range'])));
		$UpData['mobile'] = censor(addslashes(strip_tags($Get['mobile'])));
		$UpData['tag'] = implode(',',array_filter($TagArray));
		$UpData['work_years'] = intval($Get['work_years']);
		$UpData['content'] = censor(addslashes(str_replace("\r\n","<br>",$Get['content'])));
	
		$Param['work_style'] =  is_array($Get['new_work_style']) && isset($Get['new_work_style'])  ? $Get['new_work_style'] : '';
		$Param['tag_list'] =  is_array($TagTextArray) && isset($TagTextArray) ? $TagTextArray : '';
		
		if(!$UpData['face']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['HeadPortraitPlaceholder']);
			return $Data;
		}

		if(!$UpData['name']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['FullNameTips']);
			return $Data;
		}

		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		$IsLandline = "/".$Config['PluginVar']['LandlineMatch']."/";
		if(!$UpData['mobile']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['TelephoneTips']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['mobile']) && !preg_match($IsLandline,$UpData['mobile'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
			return $Data;
		}

		//��֤���ж�
		if($this->Config['PluginVar']['ArtisanMobileSwitch'] && !$UserInfo['artisan']['mobile_verify']){
			if(!$Get['code']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['CodePlaceholder']);
				return $Data;
			}
			$CheckSendSmsLog = DB::fetch_first('SELECT * FROM '.DB::table('fn_send_sms_log').' where state = 200 and cache_dateline > '.time().' and uid = '.intval($_G['uid']).' and mobile = '.$UpData['mobile'].' and code = '.$Get['code'].' and sms_type = 1 order by id desc');
			if(!$CheckSendSmsLog){
				$Data['Msg'] = urlencode($this->Config['LangVar']['CodeErr']);
				return $Data;
			}
			$UpData['mobile_verify'] = 1;
		}
		//��֤���ж� End

		if(!$UpData['range']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RangeTips']);
			return $Data;
		}

		if(!$UpData['work_years']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['WorkYearsTips']);
			return $Data;
		}

		if(!$UpData['tag']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['SkillTips']);
			return $Data;
		}

		if(!$UpData['content']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['SelfIntroductionTips']);
			return $Data;
		}

		if(!$Get['group_id'] && !$UserInfo['artisan']['vip']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ArtisanServiceTips']);
			return $Data;
		}
		
		$UpData['param'] = serialize($Param);

		$ArtisanGroupList = $this->Config['PluginVar']['artisan_group'];
		$Group = $ArtisanGroupList[$Get['group_id']];

		if($UserInfo['artisan']){//����

			DB::update($this->TableArtisan,$UpData,'id = '.intval($UserInfo['artisan']['id']));
			$Data['Id'] = $UserInfo['artisan']['id'];
			if($Group['money']){
				$PayLog = $this->GetAjaxPayLog(array('event'=>'artisan_vip','group_id'=>$Group['id'],'money'=>$Group['money'],'day'=>$Group['day'],'top_day'=>$Group['top_day'],'aid'=>$UserInfo['artisan']['id']));
				$Data['Money'] = $Group['money'];
				$Data['PayId'] = $PayLog['Id'];
				$Data['State'] = 201;
			}else{
				
				if(!$UserInfo['artisan']['experience'] && !$UserInfo['artisan']['vip']){
					$UpData['experience']  = 1;
					$UpData['updateline'] = time();
					$UpData['group_id']  = $Get['group_id'];
					$UpData['due_time']  = strtotime('+'.$Group['day'].' day',time());
					$UpData['topdateline'] = $Group['top_day'] ? strtotime('+'.$Group['top_day'].' day',time()) : '';
					$UpData['display'] = $this->Config['PluginVar']['ArtisanGroupFree'] ? 0 : 1;
					DB::update($this->TableArtisan,$UpData,'id = '.intval($UserInfo['artisan']['id']));
				}

				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk'].(!$UpData['display'] && $Get['group_id'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));
			}
			
		}else{//���
			$UpData['dateline'] = $UpData['updateline'] = time();
			$Data['Id'] = $ArtisanId = DB::insert($this->TableArtisan,$UpData,true);
			if($ArtisanId){
				if($Group['money']){
					$PayLog = $this->GetAjaxPayLog(array('event'=>'artisan_vip','group_id'=>$Group['id'],'money'=>$Group['money'],'day'=>$Group['day'],'top_day'=>$Group['top_day'],'aid'=>$ArtisanId));
					$Data['Money'] = $Group['money'];
					$Data['PayId'] = $PayLog['Id'];
					$Data['State'] = 201;
				}else{
					
					$UpData['experience']  = 1;
					$UpData['group_id']  = $Get['group_id'];
					$UpData['due_time']  = strtotime('+'.$Group['day'].' day',time());
					$UpData['topdateline'] = $Group['top_day'] ? strtotime('+'.$Group['top_day'].' day',time()) : '';
					$UpData['display'] = $this->Config['PluginVar']['ArtisanGroupFree'] ? 0 : 1;
					DB::update($this->TableArtisan,$UpData,'id = '.intval($ArtisanId));

					$Data['State'] = 200;
					$Data['Msg'] = urlencode($this->Config['LangVar']['AddArtisanOk'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));
				}
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['OpErr']);
			}
		}

		//��Ϣ֪ͨ
		if(!$UpData['display'] && !$UserInfo['artisan'] && !$Get['money']){
			foreach($this->AdminUidsList as $Key => $Val) {
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$this->Config['ViewArtisanUrl'].$Data['Id'],
						'msg'=>str_replace(array('{name}'),array($UpData['name']),$this->Config['LangVar']['ArtisanPush'])
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['ViewArtisanUrl'].$Data['Id'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv(str_replace(array('{name}'),array($UpData['name']),$this->Config['LangVar']['ArtisanPush']),CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}

			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv(str_replace(array('{name}'),array($UpData['name']),$this->Config['LangVar']['ArtisanPush']),CHARSET,'UTF-8'),
					'url'=>$this->Config['ViewArtisanUrl'].$Data['Id']
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
		}
		//��Ϣ֪ͨEnd

		return $Data;
	}

	/* ������֤�� */
	public function GetAjaxSendOut($Mobile){
		global $_G,$Config;
		$Data = array();
		$Mobile = addslashes(strip_tags(trim($Mobile)));
		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		if(!$Mobile){
			$Data['Msg'] = urlencode($this->Config['LangVar']['TelephoneTips']);
			return $Data;
		}else if(!preg_match($IsMob,$Mobile)){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
			return $Data;
		}
		
		if($CheckProfileData = DB::fetch_first('SELECT * FROM '.DB::table($this->TableArtisan).' where mobile = '.$Mobile.' and uid != '.intval($_G['uid']))){//�����Ƿ����
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileRepeatErr']);
			return $Data;
		}

		$CheckSendSmsLog = DB::fetch_first('SELECT * FROM '.DB::table('fn_send_sms_log').' where state = 200 and cache_dateline > '.time().' and uid = '.intval($_G['uid']).' and mobile = '.$Mobile.' and sms_type = 1 order by id desc');//�Ƿ���ⷢ����

		if($CheckSendSmsLog){
			$Data['Msg'] = urlencode($this->Config['LangVar']['SendOutOk']);
			$Data['State'] = 200;
			return $Data;
		}

		@require_once libfile('class/short_message','plugin/fn_assembly');
		if($Config['PluginVar']['ShortMessageType'] == 1){
			$TemplateCode = $this->Config['PluginVar']['AliCodeId'];
			$TemplateParam = array('code'=>rand(100000,999999));
		}else if($Config['PluginVar']['ShortMessageType'] == 2){
			$Code = rand(100000,999999);
			$TemplateCode = str_replace(array('{Mobile}','{Code}'),array($Config['PluginVar']['MobileAreaCode'].$Mobile,$Code),$this->Config['LangVar']['TemplateCode']);
			$TemplateParam = array('code'=>$Code);
		}
		$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$Mobile,$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$_G['uid'],$_G['username'],'fn_renovation',1);

		if($SendSms['State'] == 200){
			$Data['Msg'] = urlencode($this->Config['LangVar']['SendOutOk']);
			$Data['State'] = 200;
		}else{
			$Data['Msg'] = urlencode($SendSms['Msg']);
		}
		return $Data;
	}

	/* ��������ͳ�� */
	public function GetCountForm($Type){
		return DB::result_first('SELECT sum(count) FROM '.DB::table($this->TableForm).($Type ? ' where form_type = '.intval($Type) : ''));
	}

	/* �����ռ� */
	public function GetAjaxForm($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$UpData['ip'] = addslashes(strip_tags($_G['clientip']));
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['name'] = censor(addslashes(strip_tags($Get['name'])));
		$UpData['mobile'] = censor(addslashes(strip_tags($Get['mobile'])));
		$UpData['form_type'] = intval($Get['form_type']);
		$UpData['url'] = addslashes(strip_tags($Get['url']));
		$UpData['company_id'] = intval($Get['company_id']);
		
		if($this->Config['PluginVar']['FormTime']){
			if($_G['uid']){
				$MyLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableForm).' where uid = '.intval($_G['uid']).' and form_type = '.$UpData['form_type'].' order by updateline desc');
			}else{
				$MyLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableForm).' where ip = \''.addslashes(strip_tags($_G['clientip'])).'\' and form_type = '.$UpData['form_type'].' order by updateline desc');
			}
			if(time() < strtotime("+".$this->Config['PluginVar']['FormTime']." second",$MyLog['updateline'])){//ʱ������
				$TIME = $this->Config['PluginVar']['FormTime'] - (time() - $MyLog['updateline']);
				$Data['Msg'] = urlencode(str_replace('{time}',$TIME,$this->Config['PluginVar']['FormTimeTips']));
				return $Data;
			}
		}
		
		if(!$UpData['name']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NamePlaceholder']);
			return $Data;
		}

		$ParseArray = parse_url($UpData['url']);
		parse_str($ParseArray['query'],$UrlArray);

		if($UpData['form_type'] == 1){//װ��Ԥ��

			if((checkmobile()) || (!checkmobile() && $Get['m'] != 'index')){

				$Param['form_list']['square'] = array('title' => $this->Config['LangVar']['HouseSquare'],'value' => intval($Get['square']));
				$Param['form_list']['huxing'] = array('title' => $this->Config['LangVar']['HouseHuXing'],'value' => addslashes(strip_tags($Get['huxing'])));
				$Param['form_list']['type'] = array('title' => $this->Config['LangVar']['DecorationForm'],'value' => $this->Config['LangVar']['DecorationFormArray'][$Get['type']]);

				if(!$Param['form_list']['square']['value']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['HouseSquarePlaceholder']);
					return $Data;
				}

				if(!$Param['form_list']['huxing']['value']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['HouseHuXingPlaceholder']);
					return $Data;
				}

				if(!$Param['form_list']['type']['value']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['DecorationFormTips']);
					return $Data;
				}
			}
		}else if($UpData['form_type'] == 5){//ԤԼ���ʦ
			$DesignItem = $this->GetViewDesignthread($UrlArray['did']);
			if($DesignItem){
				$Param['form_list']['name'] = array('title' => $this->Config['LangVar']['Designer'].$this->Config['LangVar']['FullName'],'value' => addslashes(strip_tags($DesignItem['name'])));
			}
		}else if($UpData['form_type'] == 6){//ԤԼ�ι۹���
			$BuildItem = $this->GetViewBuildthread($UrlArray['bid']);
			if($BuildItem){
				$Param['form_list']['content'] = array('title' => $this->Config['LangVar']['yygd'],'value' => addslashes(strip_tags($BuildItem['title'])));
			}
		}else if($UpData['form_type'] == 7){//ԤԼ�ι۹���
			$CaseItem = $this->GetViewCasethread($UrlArray['cid']);
			if($CaseItem){
				$Param['form_list']['content'] = array('title' => $this->Config['LangVar']['sqal'],'value' => addslashes(strip_tags($CaseItem['title'])));
			}
		}			

		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		$IsLandline = "/".$Config['PluginVar']['LandlineMatch']."/";
		if(!$UpData['mobile']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['PhoneNumberTips']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['mobile']) && !preg_match($IsLandline,$UpData['mobile'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr1']);
			return $Data;
		}
		
		$UpData['param'] = $Param ? serialize($Param) : '';
		
		$CompanyIds = array_filter(explode(",",$Get['company_ids']));

		if($_G['uid']){
			$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableForm).' where uid = '.intval($_G['uid']).' and form_type = '.$UpData['form_type'].' and mobile = '.$UpData['mobile'].' and company_id = '.$UpData['company_id'].' order by id desc');
		}else{
			$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableForm).' where ip = \''.addslashes(strip_tags($_G['clientip'])).'\' and form_type = '.$UpData['form_type'].' and mobile = '.$UpData['mobile'].' and company_id = '.$UpData['company_id'].' order by id desc');
		}

		if($CompanyIds){
			foreach($CompanyIds as $Key => $Val) {
				$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableForm).' where uid = '.intval($_G['uid']).' and form_type = '.$UpData['form_type'].' and mobile = '.$UpData['mobile'].' and company_id = '.intval($Val).' order by id desc');
				if($Item){
					$UpData['updateline'] = time();
					$UpData['count'] = $Item['count'] + 1;
					$UpData['company_id'] = $Val;
					DB::update($this->TableForm,$UpData,'id = '.intval($Item['id']));
				}else{
					$UpData['dateline'] = $UpData['updateline'] = time();
					$UpData['count'] = 1;
					$UpData['company_id'] = $Val;
					$FormId = DB::insert($this->TableForm,$UpData,true);
				}
			}
			$Data['Msg'] = urlencode($this->Config['LangVar']['FormSuccessArray'][$UpData['form_type']]);
			$Data['State'] = 200;
		}else{
			if($Item){//����
				$UpData['updateline'] = time();
				$UpData['count'] = $Item['count'] + 1;
				if(DB::update($this->TableForm,$UpData,'id = '.intval($Item['id']))){
					$Data['Msg'] = urlencode($this->Config['LangVar']['FormSuccessArray'][$UpData['form_type']]);
					$Data['State'] = 200;
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['FormFail']);
				}
			}else{
				$UpData['dateline'] = $UpData['updateline'] = time();
				$UpData['count'] = 1;
				$FormId = DB::insert($this->TableForm,$UpData,true);
				if($FormId){
					$Data['Msg'] = urlencode($this->Config['LangVar']['FormSuccessArray'][$UpData['form_type']]);
					$Data['State'] = 200;
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['FormFail']);
				}
			}
		}

		$CompanyIds = $CompanyIds ? $CompanyIds : array($UpData['company_id']);
		foreach($CompanyIds as $K => $V) {
			$CompanyItem = $this->GetUserCompanyAdmin($V);
			if($CompanyItem['vip'] || $this->Config['PluginVar']['CompanyNotice']){
				
				$UpData['mobile'] = $this->Config['PluginVar']['CompanyNotice'] && !$CompanyItem['vip'] ? substr_replace($UpData['mobile'],'****',-8,4) : $UpData['mobile'];
				$FormPush = str_replace(array('{name}','{form_type}','{phone}'),array($UpData['name'],$this->Config['LangVar']['FormTypeArray'][$UpData['form_type']],$UpData['mobile']),$this->Config['PluginVar']['FormPush']);
				$UrlPush =  $this->Config['UserFormListUrl'].'&company_id='.$CompanyItem['id'];
				foreach($CompanyItem['admin'] as $Key => $Val) {
					
					if(DzNotice){
						notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
							'url'=>$UrlPush,
							'msg'=>$FormPush
						),1);//ϵͳ֪ͨ
					}
					if($Config['PluginVar']['AppType'] == 1){//������������
						$PushData['Uid'] = $Val;
						$PushData['Type'] = 'pictemp';
						$PushData['Content'] = array(
							"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"link"=> $UrlPush,
							"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
							"extra_info"=>array(
								array(
									"key"=>'',
									"val"=>diconv($FormPush,CHARSET,'UTF-8')
								)
							)
						);
						$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
					}
				}

				if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
					$PushData['Uid'] = implode(',',$CompanyItem['admin']);
					$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8');
					$PushData['Content'] = array(
						'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
						'date'=>date('Y-m-d H:i:s'),
						'setting'=>array(),
						'content' => diconv($FormPush,CHARSET,'UTF-8'),
						'url'=>$UrlPush
					);
					$this->QHApp->GetMessagesTemplate($PushData);
				}

				if(($CompanyItem['group_sms'] && $CompanyItem['vip']) || (!$CompanyItem['vip'] && $this->Config['PluginVar']['CompanyNotice'])){//����֪ͨ
					@require_once libfile('class/short_message','plugin/fn_assembly');
					if($Config['PluginVar']['ShortMessageType'] == 1){
						$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
						$TemplateParam = array('name'=>$UpData['name'],'form_type'=>$this->Config['LangVar']['FormTypeArray'][$UpData['form_type']]);
					}else if($Config['PluginVar']['ShortMessageType'] == 2){
						$TemplateCode = str_replace(array('{name}','{form_type}'),array($UpData['name'],$this->Config['LangVar']['FormTypeArray'][$UpData['form_type']]),$this->Config['PluginVar']['ChanyooNotice']);
						$TemplateParam = array();
					}
					$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$CompanyItem['mobile'],$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$CompanyItem['uid'],$CompanyItem['username'],'fn_renovation',2);
				}
			}
		}
		
		return $Data;
	}

	/* �ҵı����б� */
	public function GetAjaxUserFormList($Get){
		global $_G;
		$Results = array();

		$Get = StrToGBK($Get);

		$CompanyItem = $this->GetUserCompanyAdmin($Get['company_id']);
		if($CompanyItem['msg']){
			$Results['Msg'] = $CompanyItem['msg'];
			return $Results;
		}else if(!$CompanyItem['vip']){
			$Results['State'] = 201;
			$Results['Msg'] = $this->Config['LangVar']['NoVipErr1'];
			return $Results;
		}

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Where = '';

		if($Get['company_id']){
			$Where .= ' company_id = '.intval($Get['company_id']);
		}

		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 10;
		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];
		
		$Results['list'] = $this->FormListFormat(DB::fetch_all("SELECT * FROM %t where company_id = ".intval($Get['company_id'])." order by updateline desc,id desc".$Limit,array($this->TableForm)));
		$Results['State'] = 200;
		return $Results;
	}

	/* �����б���ʽת�� */
	public function FormListFormat($Array){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['param']['form_list'] = $Val['param']['form_list'] ? $Val['param']['form_list'] : '';
			$Array[$Key]['param']['form_list'] = $Val['param']['form_list'] ? $Val['param']['form_list'] : '';
			$Array[$Key]['form_type_text'] = $this->Config['LangVar']['FormTypeArray'][$Val['form_type']];
		}
		return $Array;
	}

	/* ���ı�������ͳ�� */
	public function GetCountMaterialForm($Type){
		return DB::result_first('SELECT sum(count) FROM '.DB::table($this->TableMaterialForm).($Type ? ' where form_type = '.intval($Type) : ''));
	}

	/* ���ı����ռ� */
	public function GetAjaxMaterialForm($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$UpData['ip'] = addslashes(strip_tags($_G['clientip']));
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['name'] = censor(addslashes(strip_tags($Get['name'])));
		$UpData['mobile'] = censor(addslashes(strip_tags($Get['mobile'])));
		$UpData['form_type'] = intval($Get['form_type']);
		$UpData['url'] = addslashes(strip_tags($Get['url']));
		$UpData['company_id'] = intval($Get['company_id']);
		
		if($this->Config['PluginVar']['FormTime']){
			if($_G['uid']){
				$MyLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMaterialForm).' where uid = '.intval($_G['uid']).' and form_type = '.$UpData['form_type'].' order by updateline desc');
			}else{
				$MyLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMaterialForm).' where ip = \''.addslashes(strip_tags($_G['clientip'])).'\' and form_type = '.$UpData['form_type'].' order by updateline desc');
			}
			if(time() < strtotime("+".$this->Config['PluginVar']['FormTime']." second",$MyLog['updateline'])){//ʱ������
				$TIME = $this->Config['PluginVar']['FormTime'] - (time() - $MyLog['updateline']);
				$Data['Msg'] = urlencode(str_replace('{time}',$TIME,$this->Config['PluginVar']['FormTimeTips']));
				return $Data;
			}
		}
		
		if(!$UpData['name']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NamePlaceholder']);
			return $Data;
		}

		$ParseArray = parse_url($UpData['url']);
		parse_str($ParseArray['query'],$UrlArray);

		if($UpData['form_type'] == 2){//��������Ʒ
			$GoodsItem = $this->GetViewGoodsthread($UrlArray['gid']);
			if($GoodsItem){
				$Param['form_list']['content'] = array('title' => $this->Config['LangVar']['xkdsp'],'value' => addslashes(strip_tags($GoodsItem['title'])));
			}
		}else if($UpData['form_type'] == 3){//������
			$CaseItem = $this->GetViewMaterialCasethread($UrlArray['cid']);
			if($CaseItem){
				$Param['form_list']['content'] = array('title' => $this->Config['LangVar']['yxdal'],'value' => addslashes(strip_tags($CaseItem['title'])));
			}
		}	

		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		$IsLandline = "/".$Config['PluginVar']['LandlineMatch']."/";
		if(!$UpData['mobile']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['PhoneNumberTips']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['mobile']) && !preg_match($IsLandline,$UpData['mobile'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr1']);
			return $Data;
		}
		
		$UpData['param'] = $Param ? serialize($Param) : '';
		
		$CompanyIds = array_filter(explode(",",$Get['company_ids']));

		if($_G['uid']){
			$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMaterialForm).' where uid = '.intval($_G['uid']).' and form_type = '.$UpData['form_type'].' and mobile = '.$UpData['mobile'].' and company_id = '.$UpData['company_id'].' order by id desc');
		}else{
			$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMaterialForm).' where ip = \''.addslashes(strip_tags($_G['clientip'])).'\' and form_type = '.$UpData['form_type'].' and mobile = '.$UpData['mobile'].' and company_id = '.$UpData['company_id'].' order by id desc');
		}

		if($CompanyIds){
			foreach($CompanyIds as $Key => $Val) {
				$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMaterialForm).' where uid = '.intval($_G['uid']).' and form_type = '.$UpData['form_type'].' and mobile = '.$UpData['mobile'].' and company_id = '.intval($Val).' order by id desc');
				if($Item){
					$UpData['updateline'] = time();
					$UpData['count'] = $Item['count'] + 1;
					$UpData['company_id'] = $Val;
					DB::update($this->TableMaterialForm,$UpData,'id = '.intval($Item['id']));
				}else{
					$UpData['dateline'] = $UpData['updateline'] = time();
					$UpData['count'] = 1;
					$UpData['company_id'] = $Val;
					$FormId = DB::insert($this->TableMaterialForm,$UpData,true);
				}
			}
			$Data['Msg'] = urlencode($this->Config['LangVar']['MaterialFormSuccessArray'][$UpData['form_type']]);
			$Data['State'] = 200;
		}else{
			if($Item){//����
				$UpData['updateline'] = time();
				$UpData['count'] = $Item['count'] + 1;
				if(DB::update($this->TableMaterialForm,$UpData,'id = '.intval($Item['id']))){
					$Data['Msg'] = urlencode($this->Config['LangVar']['MaterialFormSuccessArray'][$UpData['form_type']]);
					$Data['State'] = 200;
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['FormFail']);
				}
			}else{
				$UpData['dateline'] = $UpData['updateline'] = time();
				$UpData['count'] = 1;
				$FormId = DB::insert($this->TableMaterialForm,$UpData,true);
				if($FormId){
					$Data['Msg'] = urlencode($this->Config['LangVar']['MaterialFormSuccessArray'][$UpData['form_type']]);
					$Data['State'] = 200;
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['FormFail']);
				}
			}
		}

		$CompanyIds = $CompanyIds ? $CompanyIds : array($UpData['company_id']);
		foreach($CompanyIds as $K => $V) {
			$CompanyItem = $this->GetUserMaterialCompanyAdmin($V);
			if($CompanyItem['vip'] || $this->Config['PluginVar']['MaterialCompanyNotice']){
				$UpData['mobile'] = $this->Config['PluginVar']['MaterialCompanyNotice'] && !$CompanyItem['vip'] ? substr_replace($UpData['mobile'],'****',-8,4) : $UpData['mobile'];
				$FormPush = str_replace(array('{name}','{form_type}','{phone}'),array($UpData['name'],$this->Config['LangVar']['MaterialFormTypeArray'][$UpData['form_type']],$UpData['mobile']),$this->Config['PluginVar']['MaterialFormPush']);
				$UrlPush = $this->Config['UserMaterialFormListUrl'].'&company_id='.$CompanyItem['id'];
				foreach($CompanyItem['admin'] as $Key => $Val) {
					if(DzNotice){
						notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
							'url'=>$UrlPush,
							'msg'=>$FormPush
						),1);//ϵͳ֪ͨ
					}
					if($Config['PluginVar']['AppType'] == 1){//������������
						$PushData['Uid'] = $Val;
						$PushData['Type'] = 'pictemp';
						$PushData['Content'] = array(
							"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"link"=> $UrlPush,
							"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
							"extra_info"=>array(
								array(
									"key"=>'',
									"val"=>diconv($FormPush,CHARSET,'UTF-8')
								)
							)
						);
						$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
					}
				}

				if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
					$PushData['Uid'] = implode(',',$CompanyItem['admin']);
					$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8');
					$PushData['Content'] = array(
						'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
						'date'=>date('Y-m-d H:i:s'),
						'setting'=>array(),
						'content' => diconv($FormPush,CHARSET,'UTF-8'),
						'url'=>$UrlPush
					);
					$this->QHApp->GetMessagesTemplate($PushData);
				}

				if(($CompanyItem['group_sms'] && $CompanyItem['vip']) || (!$CompanyItem['vip'] && $this->Config['PluginVar']['MaterialCompanyNotice'])){//����֪ͨ
					@require_once libfile('class/short_message','plugin/fn_assembly');
					if($Config['PluginVar']['ShortMessageType'] == 1){
						$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
						$TemplateParam = array('name'=>$UpData['name'],'form_type'=>$this->Config['LangVar']['MaterialFormTypeArray'][$UpData['form_type']]);
					}else if($Config['PluginVar']['ShortMessageType'] == 2){
						$TemplateCode = str_replace(array('{name}','{form_type}'),array($UpData['name'],$this->Config['LangVar']['MaterialFormTypeArray'][$UpData['form_type']]),$this->Config['PluginVar']['ChanyooNotice']);
						$TemplateParam = array();
					}
					$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$CompanyItem['mobile'],$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$CompanyItem['uid'],$CompanyItem['username'],'fn_renovation',2);
				}
			}
		}
		
		return $Data;
	}

	/* �ҵĽ��ı����б� */
	public function GetAjaxUserMaterialFormList($Get){
		global $_G;
		$Results = array();

		$Get = StrToGBK($Get);

		$CompanyItem = $this->GetUserMaterialCompanyAdmin($Get['company_id']);
		if($CompanyItem['msg']){
			$Results['Msg'] = $CompanyItem['msg'];
			return $Results;
		}else if(!$CompanyItem['vip']){
			$Results['State'] = 201;
			$Results['Msg'] = $this->Config['LangVar']['NoVipErr1'];
			return $Results;
		}

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Where = '';

		if($Get['company_id']){
			$Where .= ' company_id = '.intval($Get['company_id']);
		}

		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 10;
		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];
		
		$Results['list'] = $this->MaterialFormListFormat(DB::fetch_all("SELECT * FROM %t where company_id = ".intval($Get['company_id'])." order by updateline desc,id desc".$Limit,array($this->TableMaterialForm)));
		$Results['State'] = 200;
		return $Results;
	}

	/* ���ı����б���ʽת�� */
	public function MaterialFormListFormat($Array){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['param']['form_list'] = $Val['param']['form_list'] ? $Val['param']['form_list'] : '';
			$Array[$Key]['param']['form_list'] = $Val['param']['form_list'] ? $Val['param']['form_list'] : '';
			$Array[$Key]['form_type_text'] = $this->Config['LangVar']['MaterialFormTypeArray'][$Val['form_type']];
		}
		return $Array;
	}

	/* ����Ա�޸��ֶ�ֵ */
	public function GetAjaxAdminEditFields($Table,$Id,$Field,$Val){
		global $_G;
		if($this->Admin){
			$UpData[$Field] = intval($Val);
			DB::update($Table,$UpData,'id = '.intval($Id));
		}
		$Data['State'] = 200;
		return $Data;
	}

	/* α��̬ */
	public function Rewrite($Mod,$ModArray = array()){
		global $_G;
		$Rewrite = dunserialize($_G['setting']['fn_renovation_rewrite']);
		if($Rewrite[$Mod]['available'] && !MinWxApp){
			$StrReplaceArray = array('{','}');
			$StrReplaceArrayTo = array('','');
			foreach($ModArray as $Key => $Val) {
				$StrReplaceArray[] = $Key;
				$StrReplaceArrayTo[] = $Val;
			}
			$Url = $_G['siteurl'].str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite[$Mod]['rule']);
		}else{
			
			if(in_array($Mod,array('list_case_1','list_case_2','list_case_3'))){
				$Array = explode('_',$Mod);
				$Mod = $Array[0].'_'.$Array[1];
				$ModArray = array('class'=>$Array[2]);
			}

			$Url = $this->Config['Url'].'&m='.$Mod.( !empty($ModArray) ? '&'.http_build_query($ModArray) : '' );
		}
		return $Url;
	}
	
	
	/* ����֧����¼ */
	public function GetAjaxPayLog($Get,$EncodeURI = true){
		global $_G;
	
		$Get = $EncodeURI ? EncodeURIToUrldeCode($Get) : $Get;

		$Param['event'] = addslashes(strip_tags($Get['event']));

		if($Param['event'] == 'refresh_case'){//ˢ��ְλ
			$Param['case_id'] = $Get['case_id'];
			$Param['updateline'] = time();
			$Content = $this->Config['LangVar']['RefreshCase'].'(ID:'.$Get['case_id'].')';
		}else if($Param['event'] == 'buy_store_level'){
			$Item = $this->GetViewCompanythread($Get['company_id']);
			$GroupItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableCompanyGroup).' where id = '.$Get['group_id']);
			$GroupItem['param'] = unserialize($GroupItem['param']);
			$GroupLogItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableCompanyGroupLog).' where company_id = '.$Item['id']);

			$Param['data']['company_id'] = $Get['company_id'];
			$Param['data']['refresh_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? $GroupItem['param']['refresh_count'] + $GroupLogItem['refresh_count'] : $GroupItem['param']['refresh_count'];
			$Param['data']['day_refresh_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? $GroupItem['param']['day_refresh_count'] + $GroupLogItem['param']['day_refresh_count'] : $GroupItem['day_refresh_count'];

			$Param['data']['case_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? $GroupItem['param']['case_count'] + $GroupLogItem['case_count'] : $GroupItem['param']['case_count'];
			$Param['data']['build_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? $GroupItem['param']['build_count'] + $GroupLogItem['build_count'] : $GroupItem['param']['build_count'];
			$Param['data']['team_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? $GroupItem['param']['team_count'] + $GroupLogItem['team_count'] : $GroupItem['param']['team_count'];

			$Param['data']['examine'] = $GroupItem['param']['examine'];
			$Param['data']['top_discount'] = $GroupItem['param']['top_discount'];
			$Param['data']['hot'] = $GroupItem['param']['hot'];
			$Param['data']['refresh_type'] = $GroupItem['param']['refresh_type'];
			$Param['data']['sms'] = $GroupItem['param']['sms'];
			$Param['data']['banner'] = $GroupItem['param']['banner'];

			$Param['group_log'] = $GroupLogItem ? true : false;
			
			$Param['company_id'] = $Get['company_id'];
			$Param['group_id'] = $Get['group_id'];
			$Param['experience'] = $GroupLogItem['experience'] && !$Item['experience'] ? 1 : ( $Item['experience'] ? 1 : 0);
			$Param['due_time'] = $Item['due_time'] >= time() && $Item['group_id'] == $Param['group_id'] ? strtotime("+".intval($Get['month'])."  month",$Item['due_time']) : strtotime("+".intval($Get['month'])."  month",time());
			$Content = $this->Config['LangVar']['PayCompanyContent'].$Get['company_id'];
		}else if($Param['event'] == 'company_refresh'){
			$Param['company_id'] = $Get['company_id'];
			$Param['updateline'] = $Get['updateline'];
			$Content = $this->Config['LangVar']['PayRefreshCompanyContent'].$Get['company_id'];
		}else if($Param['event'] == 'company_top'){
			$Item = $this->GetViewCompanythread($Get['company_id']);
			$Param['company_id'] = $Get['company_id'];
			$Param['topdateline'] = $Item['topdateline'] >= time() ? strtotime("+".intval($Get['day'])." day",$Item['topdateline']) : strtotime("+".intval($Get['day'])." day",time());
			$Param['updateline'] = time();
			$Content = $this->Config['LangVar']['PayTopCompanyContent'].'(ID:'.$Get['company_id'].')';
		}else if($Param['event'] == 'buy_store_level_material'){
			$Item = $this->GetViewMaterialCompanythread($Get['company_id']);
			$GroupItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMaterialCompanyGroup).' where id = '.$Get['group_id']);
			$GroupItem['param'] = unserialize($GroupItem['param']);
			$GroupLogItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMaterialCompanyGroupLog).' where company_id = '.$Item['id']);

			$Param['data']['company_id'] = $Get['company_id'];
			$Param['data']['goods_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? $GroupItem['param']['goods_count'] + $GroupLogItem['goods_count'] : $GroupItem['param']['goods_count'];
			$Param['data']['case_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? $GroupItem['param']['case_count'] + $GroupLogItem['param']['case_count'] : $GroupItem['case_count'];
			
			$Param['data']['case_examine'] = $GroupItem['param']['case_examine'];
			$Param['data']['examine'] = $GroupItem['param']['examine'];
			$Param['data']['hot'] = $GroupItem['param']['hot'];
			$Param['data']['sms'] = $GroupItem['param']['sms'];
			$Param['data']['banner'] = $GroupItem['param']['banner'];

			$Param['group_log'] = $GroupLogItem ? true : false;
			
			$Param['company_id'] = $Get['company_id'];
			$Param['group_id'] = $Get['group_id'];
			$Param['experience'] = $GroupLogItem['experience'] && !$Item['experience'] ? 1 : ( $Item['experience'] ? 1 : 0);
			$Param['due_time'] = $Item['due_time'] >= time() && $Item['group_id'] == $Param['group_id'] ? strtotime("+".intval($Get['month'])."  month",$Item['due_time']) : strtotime("+".intval($Get['month'])."  month",time());

			$Content = $this->Config['LangVar']['PayCompanyContent'].$Get['company_id'];
		}else if($Param['event'] == 'material_company_refresh'){
			$Param['company_id'] = $Get['company_id'];
			$Param['updateline'] = $Get['updateline'];
			$Content = $this->Config['LangVar']['PayRefreshMaterialCompanyContent'].$Get['company_id'];
		}else if($Param['event'] == 'material_company_top'){
			$Item = $this->GetViewMaterialCompanythread($Get['company_id']);
			$Param['company_id'] = $Get['company_id'];
			$Param['topdateline'] = $Item['topdateline'] >= time() ? strtotime("+".intval($Get['day'])." day",$Item['topdateline']) : strtotime("+".intval($Get['day'])." day",time());
			$Param['updateline'] = time();
			$Content = $this->Config['LangVar']['PayTopMaterialCompanyContent'].'(ID:'.$Get['company_id'].')';
		}else if($Param['event'] == 'artisan_vip'){
			$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableArtisan).' where id = '.$Get['aid']);
			$Param['aid'] = $Get['aid'];
			$Param['group_id'] = $Get['group_id'];
			$Param['due_time'] = $Item['due_time'] >= time() && $Item['group_id'] == $Param['group_id'] ? strtotime('+'.$Get['day'].' day',$Item['due_time']) : strtotime('+'.$Get['day'].' day',time());
			if($Get['top_day']){
				$Param['topdateline'] = $Item['topdateline'] < time() ? strtotime('+'.$Get['top_day'].' day',time()) : strtotime('+'.$Get['top_day'].' day',$Item['topdateline']);
			}
			$Content = $this->Config['LangVar']['PayArtisanContent'].$Get['aid'];
		}else if($Param['event'] == 'refresh_artisan'){//ˢ��ʦ��
			$Param['aid'] = $Get['aid'];
			$Param['updateline'] = time();
			$Content = $this->Config['LangVar']['RefreshArtisan'].'(ID:'.$Get['aid'].')';
		}else if($Param['event'] == 'top_artisan'){//�ö�ʦ��
			$Item = $this->GetViewArtisanthread($Get['aid']);
			$Param['aid'] = $Get['aid'];
			$Param['topdateline'] = $Item['topdateline'] >= time() ? strtotime("+".intval($Get['day'])." day",$Item['topdateline']) : strtotime("+".intval($Get['day'])." day",time());
			$Param['updateline'] = time();
			$Content = $this->Config['LangVar']['SetTopArtisan'].'(ID:'.$Get['aid'].')';
		}
		return $this->Pay->PayLogInsert($Get['money'],$Param,$Content,'fn_renovation');

	}
}

$Fn_Renovation = new Fn_Renovation;

?>