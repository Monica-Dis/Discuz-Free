<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('FN_IN_API')) {

	exit('Access Denied');

}

loadcache('plugin');

function NotifyUpdatePay($OrderId,$Identification,$Money,$PayType,$TransactionId){

	global $_G;

	$OrderId = addslashes($OrderId);

	$Identification = addslashes($Identification);

	$Money = addslashes($Money);

	$PayType = addslashes($PayType);

	$TransactionId = addslashes($TransactionId);
	$TablePayLog = 'fn_pay_log';
	$TableCase = 'fn_renovation_case';
	$TableCompany = 'fn_renovation_company';
	$TableCompanyGroupLog = 'fn_renovation_company_group_log';
	$TableMaterialCompany = 'fn_renovation_material_company';
	$TableMaterialCompanyGroupLog = 'fn_renovation_material_company_group_log';
	$TableArtisan = 'fn_renovation_artisan';

	$PayLog = DB::fetch_first('SELECT * FROM '.DB::table($TablePayLog).' where order_id = '.$OrderId.' and money = '.$Money);
	if($PayLog && $PayLog['state'] != 1){
		
$Data = array('state'=>1,'payment_type'=>$PayType,'pubid'=>$TransactionId,'pay_time'=>time());
		if(DB::update($TablePayLog,$Data,'order_id='.$OrderId)){
			$PayLog['param'] = unserialize($PayLog['param']);
			if($PayLog['param']['event'] == 'refresh_case'){//ˢ�°���
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableCase,$UpData,'id = '.$PayLog['param']['case_id'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'buy_store_level'){//��˾��פ�ײ�
				$UpData['group_id'] = $PayLog['param']['group_id'];
				$UpData['due_time'] = $PayLog['param']['due_time'];
				$UpData['experience'] = $PayLog['param']['experience'];
				$UpData['display'] = 1;
				if(DB::update($TableCompany,$UpData,'id = '.$PayLog['param']['company_id'])){
					$PayLog['param']['group_log'] ? DB::update($TableCompanyGroupLog,$PayLog['param']['data'],'company_id = '.$PayLog['param']['company_id']) : DB::insert($TableCompanyGroupLog,$PayLog['param']['data']);

					if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_crm')){
						$company = DB::fetch_first('SELECT * FROM '.DB::table($TableCompany).' where id = '.$PayLog['param']['company_id']);
						$customer = DB::fetch_first('SELECT * FROM '.DB::table('fn_crm_customer').' where project = \'fn_renovation\' and  project_id = '.$PayLog['param']['company_id']);
						
						!$customer ? DB::insert('fn_crm_customer',array('name'=>$company['name'],'project'=>'fn_renovation','project_id'=>$company['id'],'decision_mobile'=>$company['mobile'],'dateline'=>time(),'expire_dateline'=>$UpData['due_time'],'level'=>1)) : DB::update('fn_crm_customer',array('expire_dateline'=>$UpData['due_time'],'level'=>1),'id = '.$customer['id']);

					}

					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'company_refresh'){//ˢ�¹�˾
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableCompany,$UpData,'id = '.$PayLog['param']['company_id'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'company_top'){//�ö���˾
				$UpData['topdateline'] = $PayLog['param']['topdateline'];
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableCompany,$UpData,'id = '.$PayLog['param']['company_id'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'buy_store_level_material'){//��˾��פ�ײ�
				$UpData['group_id'] = $PayLog['param']['group_id'];
				$UpData['due_time'] = $PayLog['param']['due_time'];
				$UpData['experience'] = $PayLog['param']['experience'];
				$UpData['display'] = 1;
				if(DB::update($TableMaterialCompany,$UpData,'id = '.$PayLog['param']['company_id'])){
					$PayLog['param']['group_log'] ? DB::update($TableMaterialCompanyGroupLog,$PayLog['param']['data'],'company_id = '.$PayLog['param']['company_id']) : DB::insert($TableMaterialCompanyGroupLog,$PayLog['param']['data']);

					if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_crm')){
						$company = DB::fetch_first('SELECT * FROM '.DB::table($TableMaterialCompany).' where id = '.$PayLog['param']['company_id']);
						$customer = DB::fetch_first('SELECT * FROM '.DB::table('fn_crm_customer').' where project = \'fn_renovation_material\' and  project_id = '.$PayLog['param']['company_id']);
						
						!$customer ? DB::insert('fn_crm_customer',array('name'=>$company['name'],'project'=>'fn_renovation_material','project_id'=>$company['id'],'decision_mobile'=>$company['mobile'],'dateline'=>time(),'expire_dateline'=>$UpData['due_time'],'level'=>1)) : DB::update('fn_crm_customer',array('expire_dateline'=>$UpData['due_time'],'level'=>1),'id = '.$customer['id']);

					}


					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'material_company_refresh'){//ˢ�¹�˾
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableMaterialCompany,$UpData,'id = '.$PayLog['param']['company_id'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'material_company_top'){//�ö���˾
				$UpData['topdateline'] = $PayLog['param']['topdateline'];
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableMaterialCompany,$UpData,'id = '.$PayLog['param']['company_id'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'artisan_vip'){//��פʦ��
				$UpData['display'] = 1;
				$UpData['due_time'] = $PayLog['param']['due_time'];
				$UpData['group_id'] = $PayLog['param']['group_id'];
				$UpData['updateline'] = time();
				if($PayLog['param']['topdateline']){
					$UpData['topdateline'] = $PayLog['param']['topdateline'];
				}
				if(DB::update($TableArtisan,$UpData,'id = '.$PayLog['param']['aid'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'refresh_artisan'){//ˢ��ʦ��
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableArtisan,$UpData,'id = '.$PayLog['param']['aid'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'top_artisan'){//�ö�ʦ��
				$UpData['topdateline'] = $PayLog['param']['topdateline'];
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableArtisan,$UpData,'id = '.$PayLog['param']['aid'])){
					return true;
				}else{
					return false;
				}
			}
		}

	}

}
//From: d'.'is'.'m.ta'.'obao.com
?>