<?php
/**
 *	[������ͬ����Ƹ(fn_job.{modulename})] (C)2016-2099 Powered by ��������.
 *	Version: 1.0
 *	Date: 2019-3-25 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_job/Function.inc.php');

$navtitle = $metakeywords = $metadescription = $Fn_Job->Config['PluginVar']['Title'];

$_GET['m'] = $_GET['m'] ? $_GET['m'] : 'index';

$Mod = array('index','list','list_resume','list_company','list_article','view_job','view_resume','view_company','view_article','user','user_resume','user_resume_apply_log','user_resume_collection_log','user_company_collection_log','user_company','user_info_list','publish','user_company_apply_log','user_company_follow_list','user_resume_see_log','buy_store_level','user_company_interview_list','user_resume_interview_list','user_resume_matching_list','google_map','hr_tools','hr_tools_list','view_fair');

if(!in_array($_GET['m'],$Mod)){
	exit('No Data');
}
/* ���Զ�ά����� */
if(!checkmobile() && (!$Fn_Job->Config['PluginVar']['PcSwitch'] || in_array($_GET['m'],array('view_fair')))){
	if($Fn_Job->Config['PluginVar']['QrParameterSwitch']){
		$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.$_GET['fid'].'.jpg';
		if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
			@unlink($File);
			@require_once libfile('class/wechat','plugin/fn_assembly');
			$WechatClient = new Fn_WeChatClient($Fn_Job->Config['PluginVar']['WxAppid'], $Fn_Job->Config['PluginVar']['WxSecret']);
			$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.intval($_GET['fid']),'expire'=>2592000)));
			DownloadImg($QrUrl,$File);
		}
		$QrCode = base64_encode(file_get_contents($File));
	}else{
		$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
		if(!file_exists($File) || !filesize($File)) {
			@require_once libfile('class/qrcode','plugin/fn_assembly');
			QRcode::png($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"], $File, QR_ECLEVEL_L,5,2);
		}
		$QrCode = base64_encode(file_get_contents($File));
		@unlink($File);
	}
	include template('fn_job:index_qrcode');
	exit();
}
/* ���Զ�ά����� End */

if(!$_G['uid'] && in_array($_GET['m'],array('user','user_resume','user_resume_apply_log','user_resume_collection_log','user_company_collection_log','user_company','user_info_list','publish','user_company_apply_log','user_resume_see_log','buy_store_level','user_company_interview_list','user_resume_interview_list','user_resume_matching_list','user_company_follow_list'))){
	Fn_Login();
}

$UserInfo = $_G['uid'] ? $Fn_Job->GetUserInfo() : array();

$BackReferer = base64_encode($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"]);

$JumpReferer = base64_decode($BackReferer);

$FnReferer = base64_decode($_GET['back_referer']);

$Fn_Job->Config['LangVar']['KXSZ'] = $_G['uid'] ? str_replace(array('{Discount}'),array($UserInfo['company']['top_discount']),$Fn_Job->Config['LangVar']['KXSZ']) : '';
$Fn_Job->Config['LangVar']['OnlineServiceWxTips'] = str_replace(array('{wx}'),array($Fn_Job->Config['PluginVar']['AppOnlineWx']),$Fn_Job->Config['LangVar']['OnlineServiceWxTips']);
$Fn_Job->Config['LangVar']['CompanyWalletBalance'] = str_replace(array('{wallet_title}'),array($Fn_Job->Config['PluginVar']['CompanyWalletTitle']),$Fn_Job->Config['LangVar']['CompanyWalletBalance']);
$Fn_Job->Config['LangVar']['Currency'] = str_replace(array('{wallet_title}'),array($Fn_Job->Config['PluginVar']['CompanyWalletTitle']),$Fn_Job->Config['LangVar']['Currency']);

//ǿ�ƹ�ע���ں� 
if($Fn_Job->Config['PluginVar']['WxFollowSwitch'] && WxApp && $_G['uid']){
	if($_GET['code']){
		@require_once libfile('class/wechat','plugin/fn_assembly');
		$WechatClient = new Fn_WeChatClient($Fn_Job->Config['PluginVar']['WxAppid'], $Fn_Job->Config['PluginVar']['WxSecret']);
		$Token = $WechatClient->getAccessTokenByCode($_GET['code']);
		if($Token['openid']){
			$WxUserInfo = $WechatClient->getUserInfoById($Token['openid'],'zh_CN');
			if($WxUserInfo['openid']){
				$Subscribe = ($WxUserInfo['subscribe']) || ($UserInfo['subscribe'] && !$SnsapiUserInfo) ? true : false;
				$NoSubscribe = !$Subscribe ? true : false;
				if($_G['uid']){
					!$UserInfo['uid'] ? DB::insert($Fn_Job->TableMember,array('uid'=>intval($_G['uid']),'username'=>addslashes(strip_tags($_G['username'])),'openid'=>addslashes(strip_tags($WxUserInfo['openid'])),'unionid'=>addslashes(strip_tags($WxUserInfo['unionid'])),'subscribe'=>$Subscribe,'dateline'=>time(),'updateline'=>time())) : DB::update($Fn_Job->TableMember,array('openid'=>addslashes(strip_tags($WxUserInfo['openid'])),'unionid'=>addslashes(strip_tags($WxUserInfo['unionid'])),'subscribe'=>$Subscribe,'updateline'=>time()),'uid = '.intval($_G['uid']));
				}
				
			}
		}
	}elseif($UserInfo['subscribe'] && time() >= strtotime("+2 day",$UserInfo['updateline'])){
		if(strpos($Fn_Job->Config['PluginVar']['WxOauthDomain'],'oauth2.htm') !== false) {
			$JumpUrl = $Fn_Job->Config['PluginVar']['WxOauthDomain'].'?appid='.$Fn_Job->Config['PluginVar']['WxAppid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.urlencode($JumpReferer);
		}else{
			$JumpUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$Fn_Job->Config['PluginVar']['WxAppid'].'&redirect_uri=' . urlencode($JumpReferer).'&response_type=code&scope=snsapi_userinfo&state='. md5(FORMHASH).'#wechat_redirect';
		}
		dheader('Location:'.$JumpUrl);
		exit();
	}else if(!$UserInfo['subscribe'] && time() < strtotime("+120 second",$UserInfo['updateline'])){
		$NoSubscribe = false;
	}else if(!$UserInfo['subscribe']){
		if(strpos($Fn_Job->Config['PluginVar']['WxOauthDomain'],'oauth2.htm') !== false) {
			$JumpUrl = $Fn_Job->Config['PluginVar']['WxOauthDomain'].'?appid='.$Fn_Job->Config['PluginVar']['WxAppid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.urlencode($JumpReferer);
		}else{
			$JumpUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$Fn_Job->Config['PluginVar']['WxAppid'].'&redirect_uri=' . urlencode($JumpReferer).'&response_type=code&scope=snsapi_userinfo&state='. md5(FORMHASH).'#wechat_redirect';
		}
		dheader('Location:'.$JumpUrl);
		exit();
	}
}
//ǿ�ƹ�ע���ں�End

//�����Ƿ�֪ͨ�û�
$Fn_Job->GetExpiryPushInfo();

//�ö������Ƿ�֪ͨ�û�
$Fn_Job->GetTopExpiryPushInfo();

//��˾�����Ƿ�֪ͨ�û�
$Fn_Job->GetVipExpiryPushCompany();

if(!checkmobile()){//���԰�
	
	@require_once libfile('class/qrcode','plugin/fn_assembly');
	
	//��ά������
	$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
	if(!file_exists($File) || !filesize($File)) {
		@require_once libfile('class/qrcode','plugin/fn_assembly');
		QRcode::png($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"], $File, QR_ECLEVEL_L,5,2);
	}
	$QrCode = base64_encode(file_get_contents($File));
	@unlink($File);
	//��ά������End
}

$_GET['m'] = $_GET['m'] == 'publish' && !$UserInfo['company'] && $Fn_Job->Config['PluginVar']['InfoCompany'] ? 'user_company' : $_GET['m'];

if($_GET['m'] == 'index'){//��ҳ
	
	//���ͼ
	$Banners =$Fn_Job->Config['PluginVar']['banners'];
	
	$IndexNav = $Fn_Job->Config['PluginVar']['navs'];

	$NoticeList = array_filter(explode("\r\n",$Fn_Job->Config['PluginVar']['NoticeList']));

	$IndexHotJobList = array_filter(TextareaArray($Fn_Job->Config['PluginVar']['IndexHotJob']));
	
	$IndexCompanyHotList = $Fn_Job->GetIndexCompanyHotList();
	
	$Count = $Fn_Job->GetCount();

	if(!checkmobile()){//���԰�
		
		$Seo = array_filter(explode("#",$Fn_Job->Config['PluginVar']['PcHomeSeo']));
		$navtitle = $Seo[0] ? $Seo[0] : $navtitle;
		$metakeywords = $Seo[1] ? $Seo[1] : $navtitle;
		$metadescription = $Seo[2] ? $Seo[2] : $navtitle;
		
		$PcIndexHotJobList = array_filter(TextareaArray($Fn_Job->Config['PluginVar']['PcIndexHotJob']));
		$PcHotSearch = array_filter(explode("\r\n",$Fn_Job->Config['PluginVar']['PcHotSearch']));
		$JobCountArray = str_split($Count['job']);
		$PcFriendLink = array_filter(explode("\r\n",$Fn_Job->Config['PluginVar']['PcFriendLink']));
		
		//��������
		$PcHomeSearchList = array_filter(explode(",",$Fn_Job->Config['PluginVar']['PcHomeSearchList']));

		//ְλ+�˲�+��˾
		$JobList = $Fn_Job->GetAjaxList(array('class'=>1,'limit'=>$Fn_Job->Config['PluginVar']['PcHomeJobNum']));
		$JobListConcurrent = $Fn_Job->GetAjaxList(array('class'=>2,'limit'=>$Fn_Job->Config['PluginVar']['PcHomeJobNum']));
		$ResumeList = $Fn_Job->GetAjaxListResume(array('limit'=>$Fn_Job->Config['PluginVar']['PcHomeResumeNum']));

		$ArticleList = $Fn_Job->Config['PluginVar']['PcHomeArticle'] ? $Fn_Job->GetAjaxArticleList(array('limit'=>$Fn_Job->Config['PluginVar']['PcHomeArticleNum'],'display'=>1,'hot'=>$Fn_Job->Config['PluginVar']['PcHomeArticleHot'])) : '';
	}else{
		$ArticleList = $Fn_Job->Config['PluginVar']['HomeArticle'] ? $Fn_Job->GetAjaxArticleList(array('limit'=>$Fn_Job->Config['PluginVar']['HomeArticleNum'],'display'=>1,'hot'=>$Fn_Job->Config['PluginVar']['HomeArticleHot'])) : '';
	}
	
}else if($_GET['m'] == 'list'){

	$navtitle = $metadescription = $metakeywords = ($_GET['top'] ? $Fn_Job->Config['LangVar']['JP'].'-' : '').(in_array($_GET['class'],array(1,2)) ? $Fn_Job->Config['LangVar']['ListTitleArray'][$_GET['class']] : $Fn_Job->Config['LangVar']['ListTitleArray'][0]);
	$_GET['keyword'] = $_GET['keyword'] ? diconv(urldecode(urldecode($_GET['keyword'])),mb_detect_encoding($_GET['keyword'],array('UTF-8','GB2312','GBK'))) : '';
	if(!checkmobile()){//���԰�
		$Seo = TextareaArray($Fn_Job->Config['PluginVar']['PcListSeo']);
		$SeoArray =  array_filter(explode("#",$Seo[in_array($_GET['class'],array(1,2)) ? $_GET['class'] : 0]));
		$navtitle = $SeoArray[0] ? $SeoArray[0] : $navtitle;
		$metakeywords = $SeoArray[1] ? $SeoArray[1] : $navtitle;
		$metadescription = $SeoArray[2] ? $SeoArray[2] : $navtitle;
	}else{
		$share = TextareaArray($Fn_Job->Config['PluginVar']['JobListShare']);
		list($share_title,$share_desc) =  array_filter(explode("#",$share[in_array($_GET['class'],array(1,2)) ? $_GET['class'] : 0]));
	}

	$Fn_Job->Config['WxShare']['WxUrl'] = $Fn_Job->Config['ListUrl'].'&class='.$_GET['class'].'&keyword='.$_GET['keyword'];
	$Fn_Job->Config['WxShare']['WxTitle'] = $share_title ? $share_title : $Fn_Job->Config['WxShare']['WxTitle'];
	$Fn_Job->Config['WxShare']['WxDes'] = $share_desc ? $share_desc : $Fn_Job->Config['WxShare']['WxDes'];

}else if($_GET['m'] == 'list_resume'){

	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['ListResume'];

	if(mb_detect_encoding($_GET['keyword'],array('ASCII','UTF-8','GB2312','GBK','BIG5','EUC-CN')) != 'EUC-CN' || CHARSET != 'gbk'){
		$_GET['keyword'] = $_GET['keyword'] ? diconv($_GET['keyword'],mb_detect_encoding($_GET['keyword'], array('ASCII','UTF-8','GB2312','GBK','BIG5','EUC-CN')),CHARSET) : '';
	}

	if(!checkmobile()){//���԰�
		$Seo = array_filter(explode("#",$Fn_Job->Config['PluginVar']['PcResumeSeo']));
		$navtitle = $Seo[0] ? $Seo[0] : $navtitle;
		$metakeywords = $Seo[1] ? $Seo[1] : $navtitle;
		$metadescription = $Seo[2] ? $Seo[2] : $navtitle;
	}else{
		list($share_title,$share_desc) =  array_filter(explode("#",$Fn_Job->Config['PluginVar']['ResumeListShare']));
	}

	$Fn_Job->Config['WxShare']['WxUrl'] = $Fn_Job->Config['ListResumeUrl'].'&keyword='.$_GET['keyword'];
	$Fn_Job->Config['WxShare']['WxTitle'] = $share_title ? $share_title : $Fn_Job->Config['WxShare']['WxTitle'];
	$Fn_Job->Config['WxShare']['WxDes'] = $share_desc ? $share_desc : $Fn_Job->Config['WxShare']['WxDes'];

}else if($_GET['m'] == 'list_company'){

	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['ListCompany'];
	
	if(mb_detect_encoding($_GET['keyword'],array('ASCII','UTF-8','GB2312','GBK','BIG5','EUC-CN')) != 'EUC-CN' || CHARSET != 'gbk'){
		$_GET['keyword'] = $_GET['keyword'] ? diconv($_GET['keyword'],mb_detect_encoding($_GET['keyword'], array('ASCII','UTF-8','GB2312','GBK','BIG5','EUC-CN')),CHARSET) : '';
	}

	if(!checkmobile()){//���԰�
		$Seo = array_filter(explode("#",$Fn_Job->Config['PluginVar']['PcCompanySeo']));
		$navtitle = $Seo[0] ? $Seo[0] : $navtitle;
		$metakeywords = $Seo[1] ? $Seo[1] : $navtitle;
		$metadescription = $Seo[2] ? $Seo[2] : $navtitle;
	}else{
		list($share_title,$share_desc) =  array_filter(explode("#",$Fn_Job->Config['PluginVar']['CompanyListShare']));
	}

	$Fn_Job->Config['WxShare']['WxUrl'] = $Fn_Job->Config['ListCompanyUrl'].'&keyword='.$_GET['keyword'];
	$Fn_Job->Config['WxShare']['WxTitle'] = $share_title ? $share_title : $Fn_Job->Config['WxShare']['WxTitle'];
	$Fn_Job->Config['WxShare']['WxDes'] = $share_desc ? $share_desc : $Fn_Job->Config['WxShare']['WxDes'];

}else if($_GET['m'] == 'list_article'){//��Ѷ�б�
	
	if(mb_detect_encoding($_GET['keyword'],array('ASCII','UTF-8','GB2312','GBK','BIG5','EUC-CN')) != 'EUC-CN' || CHARSET != 'gbk'){
		$_GET['keyword'] = $_GET['keyword'] ? diconv($_GET['keyword'],mb_detect_encoding($_GET['keyword'], array('ASCII','UTF-8','GB2312','GBK','BIG5','EUC-CN')),CHARSET) : '';
	}
	$ArticleClassList = $Fn_Job->GetArticleClassList();
	reset($ArticleClassList);
	$FirstKey = key($ArticleClassList);
	//$_GET['classid'] = $_GET['classid'] ? $_GET['classid'] : $FirstKey;
	$ClassItem = $ArticleClassList[$_GET['classid']];
	$navtitle = $metadescription = $metakeywords = $ClassItem ? $ClassItem['title'] : $Fn_Job->Config['LangVar']['ArticleListAllTitle'];
	
	if(!checkmobile()){//���԰�
		$navtitle = $ClassItem['seo_title'] ? $ClassItem['seo_title'] : $navtitle;
		$metakeywords = $ClassItem['seo_keyword'] ? $ClassItem['seo_keyword'] : $navtitle;
		$metadescription = $ClassItem['seo_desc'] ? $ClassItem['seo_desc']  : $navtitle;
		$ArticleHotList = $Fn_Job->GetAjaxArticleList(array('limit'=>10,'display'=>1,'hot'=>1,'classid'=>$ClassItem['id']));
		$ArticleList = $Fn_Job->GetAjaxArticleList(array('limit'=>10,'display'=>1,'classid'=>$ClassItem['id']));
	}
	$Fn_Job->Config['WxShare']['WxTitle'] = $navtitle;
	$Fn_Job->Config['WxShare']['WxUrl'] = $Fn_Job->Config['ListArticleUrl'].'&classid='.$_GET['classid'].'&company_id='.$_GET['company_id'].'&keyword='.$_GET['keyword'];

}else if($_GET['m'] == 'publish'){//������Ƹ

	$navtitle = $metadescription = $metakeywords = $_GET['class'] ? $Fn_Job->Config['LangVar']['PublishTitleArray'][$_GET['class']] : $Fn_Job->Config['LangVar']['PostJob'];
	
	$Money = $Fn_Job->Config['PluginVar']['PublishMoney'];
	$AppMoney = $Fn_Job->Config['PluginVar']['AppPublishMoney'];
	$TopMoney = $Fn_Job->Config['PluginVar']['job_top'];
	
	$PublishHint = $AppMoney ? str_replace(array('{Money}','{br}'),array('<span class="ColorRed">'.$AppMoney.'</span>','<br>'),$Fn_Job->Config['PluginVar']['PublishHint']) : str_replace(array('{Money}','{br}'),array('<span class="ColorRed">'.$Money.'</span>','<br>'),$Fn_Job->Config['PluginVar']['PublishHint']);
	
	$AppPublishHint = str_replace(array('{Money}','{br}','{AppMoney}','{Down}'),array('<span class="FFFFFColor">'.$Money.'</span>','<br>','<span class="ColorRed">'.($AppMoney ? $AppMoney : $Fn_Job->Config['LangVar']['MianFei']).'</span>','<a href="'.$Config['PluginVar']['AppLink'].'" class="ColorRed">'.$Fn_Job->Config['LangVar']['Down'].'</a>'),$Fn_Job->Config['PluginVar']['AppPublishHint']);

	$Money = AppYes && App ? $AppMoney : $Money;
	
	array_unshift($Fn_Job->Config['LangVar']['EducationArray'],$Fn_Job->Config['LangVar']['Unlimited']);
	array_unshift($Fn_Job->Config['LangVar']['ExperienceArray'],$Fn_Job->Config['LangVar']['Unlimited']);
	
	$DataArea = MobileSelectAreaJs($Fn_Job->Area);
	$DataClassList = MobileSelectAreaJs($Fn_Job->ClassList);
	$DataMonthWages = MobileSelectJs($Fn_Job->Config['LangVar']['MonthWagesArray']);
	$DataEducation = MobileSelectJs($Fn_Job->Config['LangVar']['EducationArray']);
	$DataExperience = MobileSelectJs($Fn_Job->Config['LangVar']['ExperienceArray']);
	$DataSettlement = MobileSelectJs($Fn_Job->Config['LangVar']['SettlementArray']);
	$DataMonthWagesType = MobileSelectJs($Fn_Job->Config['LangVar']['MonthWagesTypeArray']);
	
	if(!$Fn_Job->Admin){
		if(in_array($_G['uid'],$Fn_Job->Config['PluginVar']['GlobalProhibitUis'])){
			$Msg = $Fn_Job->Config['PluginVar']['GlobalProhibitUisTips'];
		}else if($Fn_Job->Config['PluginVar']['PublishAppSwitch'] && !App){
			$Msg = $Fn_Job->Config['PluginVar']['PublishAppTips'];
		}else if($Fn_Job->Config['PluginVar']['PublishVipSwitch'] && !$UserInfo['company']['vip']){
			if($UserInfo['company']){
				$Msg = $Fn_Job->Config['LangVar']['PublishVipSwitchErr'];
				$Btn = $Fn_Job->Config['LangVar']['ResumeSeeCompanyBtn'];
				$Url = $Fn_Job->Config['BuyStoreLevelUrl'];
			}else{
				$Msg = $Fn_Job->Config['LangVar']['PublishVipSwitchErr1'];
				$Btn = $Fn_Job->Config['LangVar']['ResumeSeeNoCompanyBtn'];
				$Url = $Fn_Job->Config['UserCompanyUrl'];
			}
		}else if($UserInfo['company'] && !$UserInfo['company']['display']){
			$Msg = $Fn_Job->Config['LangVar']['PublishNoCompanyErr'];
		}
	}

	if($Fn_Job->Admin){
		$Item = $Fn_Job->GetViewthread($_GET['iid']);
	}else{
		$Item = $Fn_Job->GetViewthread($_GET['iid'],' and I.uid = '.$_G['uid']);
	}

	if($Item){
		$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['PublishEditTitleArray'][$Item['class']];
		$_GET['class'] = $Item['class'];
		$Fn_Job->Config['LangVar']['PublishBtn'] = $Fn_Job->Config['LangVar']['PublishEditBtn'];
		$ItemTag = array_filter(explode(",",$Item['tag']));
		$Item['content'] = str_replace("<br>","\r\n",stripslashes($Item['content']));
	}else{
		$ItemTag = array_filter(explode(",",$UserInfo['company']['tag']));
	}
	
	if(!$UserInfo['company']){
		$DataScale = MobileSelectJs($Fn_Job->Config['LangVar']['ScaleArray']);
		$DataClass = MobileSelectJs($Fn_Job->Config['LangVar']['CompanyClassArray']);
		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
	}
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}
	$PayTitle = $Fn_Job->Config['LangVar']['PublishTitleArray'][$_GET['class']];

}else if($_GET['m'] == 'view_job'){
	$Item = $Fn_Job->GetViewthread($_GET['iid']);
	if($Item){
		
		$navtitle = $metadescription = $metakeywords = $Item['title'];
		if(!checkmobile()){//���԰�
			$Seo = str_replace(array('{title}','{class}','{company_name}','{address}','{month_wages}','{education}','{experience}','{settlement}','{cycle}','{content}','{contacts}'),array($Item['title'],$Item['classid_min_text'],$Item['company']['name'],$Item['province_text'].'['.$Item['community'].']',$Item['month_wages_text'],$Item['education_text'],$Item['experience_text'],$Item['settlement_text'],$Item['cycle_text'],cutstr(strip_tags($Item['content']),150),$Item['c_contacts']),explode("#",$Fn_Job->Config['PluginVar']['PcJobSeo']));
			$navtitle = $Seo[0] ? $Seo[0] : $navtitle;
			$metakeywords = $Seo[1] ? $Seo[1] : $navtitle;
			$metadescription = $Seo[2] ? $Seo[2] : $navtitle;
		}
		
		if((!$Item['display'] || !$Item['payment_state']) && $Item['uid'] != $_G['uid'] && !$Fn_Job->Admin){
			$Msg = $Fn_Job->Config['LangVar']['InfoInAudit'];
		}else if($Fn_Job->Config['PluginVar']['ExpiryTime'] && $Item['updateline'] < strtotime("-".intval($Fn_Job->Config['PluginVar']['ExpiryTime'])." day",time()) && $Item['topdateline'] < time() && !$Fn_Job->Admin){
			$Msg = $Fn_Job->Config['LangVar']['ExpiredTips'];
		}else{
			
			$Item['company']['hide_mobile'] = $Fn_Job->Config['PluginVar']['JobCompanyHideMobile'] ? 1 : $Item['company']['hide_mobile'];

			$ReportList = array_filter(explode("\r\n",$Fn_Job->Config['PluginVar']['ReportList']));
			
			$PreviewAlbum = $Item['company']['param']['album'] ? json_encode($Item['company']['param']['album']) : '';//ͼƬ��

			$JobCompanyList = $Fn_Job->Config['PluginVar']['JobCompanyListSwitch'] ? $Fn_Job->GetAjaxJobCompanyList(array('company_id'=>$Item['company_id'],'no_id'=>$Item['id'])) : '';//����ְλ
		
			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Job->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Job->TableInfo,$Item['id'],$ClickNum);

			if($_G['uid']){
				
				//�ҵ�����ְλ
				$MyApplyLog = in_array($Item['id'],$Fn_Job->GetUserInfoApplyLogArray()) ? true : false;
				
				//�ҵ��ղ�
				$MyCollect = in_array($Item['id'],$Fn_Job->GetUserInfoCollectArray()) ? true : false;
			}

			if((!$MyApplyLog && $Fn_Job->Config['PluginVar']['JobContactSwitch']) || ($Fn_Job->Config['PluginVar']['JobTelResumeSwitch'] && !$UserInfo['resume'])){
				$Item['content'] = preg_replace('/(1[358]{1}[0-9])[0-9]{4}([0-9]{4})/i', '$1****$2', $Item['content']);
				$Item['content'] = preg_replace('/([0-9]{3,4}-)?([0-9]{3})[0-9]{4}/i', '$1$2****', $Item['content']);
			}

			//��ά��
			if($Fn_Job->Config['PluginVar']['QrParameterSwitch']){
				$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.$Item['id'].'.jpg';
				if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
					@unlink($File);
					@require_once libfile('class/wechat','plugin/fn_assembly');
					$WechatClient = new Fn_WeChatClient($Fn_Job->Config['PluginVar']['WxAppid'], $Fn_Job->Config['PluginVar']['WxSecret']);
					$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.intval($Item['id']),'expire'=>2592000)));
					DownloadImg($QrUrl,$File);
				}
				$QrCode = base64_encode(file_get_contents($File));
			}else{
				$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
				if(!file_exists($File) || !filesize($File)) {
					@require_once libfile('class/qrcode','plugin/fn_assembly');
					QRcode::png($Fn_Job->Rewrite($_GET['m'],array('iid'=>$Item['id'])), $File, QR_ECLEVEL_L,5,2);
				}
				$QrCode = base64_encode(file_get_contents($File));
				@unlink($File);
			}
			//����
			$replaceArray = array('{id}','{title}','{class}','{classid}','{company_name}','{address}','{month_wages}','{month_wages_text}','{education}','{experience}','{settlement}','{cycle}','{url}','{mobile}','{content}','{contacts}','{tag}');
			$isreplaceArray = array($Item['id'],$Item['title'],$Item['classid_min_text'],$Item['classid_min_text'],$Item['company']['name'],$Item['province_text'].'['.$Item['community'].']',$Item['month_wages_text'],$Item['month_wages_text'],$Item['education_text'],$Item['experience_text'],$Item['settlement_text'],$Item['cycle_text'],$Fn_Job->Rewrite('view_job',array('iid'=>$Item['id'])),$Item['mobile'],strip_tags($Item['content']),$Item['c_contacts'],implode('|',$Item['param']['tag_list']));
			$Fn_Job->Config['PluginVar']['JobCopyContent'] = str_replace($replaceArray,$isreplaceArray,$Fn_Job->Config['PluginVar']['JobCopyContent']);
			//����END
			//����
			$Fn_Job->Config['WxShare']['WxUrl'] = $Fn_Job->Rewrite($_GET['m'],array('iid'=>$Item['id']));
			$Fn_Job->Config['WxShare']['WxTitle'] = str_replace($replaceArray,$isreplaceArray,$Fn_Job->Config['PluginVar']['JobShareTitle']);
			$Fn_Job->Config['WxShare']['WxDes'] = str_replace($replaceArray,$isreplaceArray,$Fn_Job->Config['PluginVar']['JobShareDesc']);
			$Fn_Job->Config['WxShare']['WxImg'] = $Item['company']['logo'] ? $Item['company']['logo'] : $Fn_Job->Config['WxShare']['WxImg'];
			$Fn_Job->Config['WxShare']['WxImg'] = strpos($Fn_Job->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Job->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Job->Config['WxShare']['WxImg'];
			
			//����End
		}
	}else{
		$navtitle = $Msg = $Fn_Job->Config['LangVar']['NoViewData'];
	}
}else if($_GET['m'] == 'view_company'){//��˾����
	$Item = $Fn_Job->GetViewCompanythread($_GET['cid']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['name'];
		if(!checkmobile()){//���԰�
			$Seo = str_replace(array('{name}','{type}','{scale}','{content}'),array($Item['name'],$Item['type_text'],$Item['scale_text'],cutstr(strip_tags($Item['content']),150)),explode("#",$Fn_Job->Config['PluginVar']['PcCompanyViewSeo']));
			$navtitle = $Seo[0] ? $Seo[0] : $navtitle;
			$metakeywords = $Seo[1] ? $Seo[1] : $navtitle;
			$metadescription = $Seo[2] ? $Seo[2] : $navtitle;
		}
		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_Job->Admin){
			$Msg = $Fn_Job->Config['LangVar']['CompanyInAudit'];
		}else{

			$PreviewAlbum = $Item['param']['album'] ? json_encode($Item['param']['album']) : '';//ͼƬ��

			$JobCompanyList = $Fn_Job->GetAjaxJobCompanyList(array('company_id'=>$Item['id']));//����ְλ

			//�ü����Ƿ�Ͷ�˱���˾ְλ
			$ApplyInfoResume = $Fn_Job->Config['PluginVar']['JobApplySwitch'] ? $Fn_Job->GetUserInfoApplyLogState($_G['uid'],$Item['id']) : false;
			
			$Fn_Job->Config['LangVar']['CompanyFollowTips'] = str_replace("{type_text}",$Item['type_text'],$Fn_Job->Config['LangVar']['CompanyFollowTips']);
			$Follow = $Fn_Job->GetCompanyFollowFirst($_G['uid'],$Item['id']);
			
			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Job->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Job->TableCompany,$Item['uid'],$ClickNum,'uid');
			
			//��ά��
			$Fn_Job->Config['LangVar']['TaZiLiao'] = str_replace("{type_text}",$Item['type_text'],$Fn_Job->Config['LangVar']['TaZiLiao']);
			if($Fn_Job->Config['PluginVar']['QrParameterSwitch']){
				$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.$Item['id'].'.jpg';
				if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
					@unlink($File);
					@require_once libfile('class/wechat','plugin/fn_assembly');
					$WechatClient = new Fn_WeChatClient($Fn_Job->Config['PluginVar']['WxAppid'], $Fn_Job->Config['PluginVar']['WxSecret']);
					$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.intval($Item['id']),'expire'=>2592000)));
					DownloadImg($QrUrl,$File);
				}
				$QrCode = base64_encode(file_get_contents($File));
			}else{
				$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
				if(!file_exists($File) || !filesize($File)) {
					@require_once libfile('class/qrcode','plugin/fn_assembly');
					QRcode::png($Fn_Job->Rewrite($_GET['m'],array('cid'=>$Item['id'])), $File, QR_ECLEVEL_L,5,2);
				}
				$QrCode = base64_encode(file_get_contents($File));
				@unlink($File);
			}
			
			//����
			$info_list = '';
			foreach($JobCompanyList as $key => $val) {
				$info_list .= ($key ? "\r\n" : '').$val['title'].'---'.$val['month_wages_text'];
			}
			$replaceArray = array('{name}','{mobile}','{scale}','{class}','{content}','{tag}','{job_list}','{url}');
			$isreplaceArray = array($Item['name'],$Item['mobile'],$Item['scale_text'],$Item['class_text'],strip_tags($Item['content']),implode('|',$Item['param']['tag_list']),$info_list,$Fn_Job->Rewrite('view_company',array('cid'=>$Item['id'])));
			$Fn_Job->Config['PluginVar']['CompanyCopyContent'] = str_replace($replaceArray,$isreplaceArray,$Fn_Job->Config['PluginVar']['CompanyCopyContent']);
			//���� END

			//����
			$Fn_Job->Config['WxShare']['WxUrl'] = $Fn_Job->Rewrite($_GET['m'],array('cid'=>$Item['id']));
			$Fn_Job->Config['WxShare']['WxTitle'] = $Fn_Job->Config['PluginVar']['CompanyShareTitle'] ? str_replace($replaceArray,$isreplaceArray,$Fn_Job->Config['PluginVar']['CompanyShareTitle']) : $Item['name'].'_'.$Fn_Job->Config['PluginVar']['Title'];
			$Fn_Job->Config['WxShare']['WxImg'] = $Item['logo'] ? $Item['logo'] : $Fn_Job->Config['WxShare']['WxImg'];
			//����End
		}
	}else{
		$navtitle = $Msg = $Fn_Job->Config['LangVar']['NoViewCompanyData'];
	}
}else if($_GET['m'] == 'view_resume'){//��������

	$Item = $Fn_Job->GetViewResumethread($_GET['rid']);
	if($Item){
		if($UserInfo['company']['id']){
			$InfoApplyLog = $Fn_Job->GetUserInfoApplyLogState($Item['uid'],$UserInfo['company']['id']);
			//�ü����Ƿ�Ͷ�˱���˾ְλ
			$ApplyInfoResume = ($Fn_Job->Config['PluginVar']['ApplyInfoResumeSwitch'] && !$UserInfo['company']['vip']) || ($UserInfo['company']['apply_resume'] && $UserInfo['company']['vip'])  ? $InfoApplyLog : false;
			$InfoApplyLog ? $Fn_Job->MyApplyLogUpdataSee($Item['uid'],$UserInfo['company']['id']) : '';

		}

		$Item['full_name'] = $Fn_Job->Config['PluginVar']['ResumeNameSwitch'] || ($InfoApplyLog && $Fn_Job->Config['PluginVar']['ResumeJobNameSwitch']) ?  $Item['full_name'] : cutstr($Item['full_name'],3,'').$Fn_Job->Config['LangVar']['SexToArray'][$Item['sex']];

		$navtitle = $metadescription = $metakeywords = $Item['full_name'].$Fn_Job->Config['LangVar']['ViewResume'];
		if(!checkmobile()){//���԰�
			$Seo = str_replace(array('{name}','{sex}','{age}','{education}','{experience}','{expect_job}','{expect_month_wages}','{expect_address}','{tag}','{content}','{qr}','{link}'),array($Item['full_name'],$Item['sex_text'],$Item['age'],$Item['education_text'],$Item['experience_text'],$Item['expect_job'],$Item['expect_month_wages_text'],$Item['expect_province_text'],implode('|',$Item['param']['tag_list']),cutstr(strip_tags($Item['content']),150)),explode("#",$Fn_Job->Config['PluginVar']['PcResumeViewSeo']));
			$navtitle = $Seo[0] ? $Seo[0] : $navtitle;
			$metakeywords = $Seo[1] ? $Seo[1] : $navtitle;
			$metadescription = $Seo[2] ? $Seo[2] : $navtitle;
		}	

		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_Job->Admin){
			$Msg = $Fn_Job->Config['LangVar']['ResumeInAudit'];
		}else{

			$ReportList = array_filter(explode("\r\n",$Fn_Job->Config['PluginVar']['ResumeReportList']));
			
			$PreviewFace = $Item['face'] ? json_encode(array(strpos($Item['face'],'http') !== false ? $Item['face'] : $_G['siteurl'].$Item['face'])) : '';//ͷ��

			$PreviewWorks = $Item['param']['works'] ? json_encode($Item['param']['works']) : '';//ͼƬ��
			$PreviewLife = $Item['param']['life'] ? json_encode($Item['param']['life']) : '';//ͼƬ��

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Job->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Job->TableResume,$Item['uid'],$ClickNum,'uid');

			$ResumePackage = array_filter(explode("\r\n",$Fn_Job->Config['PluginVar']['ResumePackage']));

			if($_G['uid']){

				//�Ƿ񷢲���ְλ
				$ResumeDownInfo = $Fn_Job->Config['PluginVar']['ResumeDownInfoSwitch'] && $UserInfo['company']['id'] && $Fn_Job->GetAjaxJobCompanyList(array('company_id'=>$UserInfo['company']['id'])) ? true : false;
	
				//�ҵĲ鿴����
				$MySeeLog = $Fn_Job->GetUserResumeSeeLogFirst($Item['uid']);
				
				//�ҵ��ղ�
				$MyCollect = in_array($Item['uid'],$Fn_Job->GetUserResumeCollectArray()) ? true : false;
				
				if(!$UserInfo['company']){
					$Fn_Job->Config['LangVar']['ResumeSeeMoneyTips'] = $Fn_Job->Config['LangVar']['ResumeSeeMoneyNoCompanyTips'];
					$Fn_Job->Config['LangVar']['ResumeSeeCompanyBtn'] = $Fn_Job->Config['LangVar']['ResumeSeeNoCompanyBtn'];
					$Fn_Job->Config['BuyStoreLevelUrl'] = $Fn_Job->Config['UserCompanyUrl'];
				}
				
				$Fn_Job->Config['LangVar']['ResumeSeeMoneyTips'] = $UserInfo['company'] ?  $Fn_Job->Config['LangVar']['ResumeSeeMoneyTips'] : $Fn_Job->Config['LangVar']['ResumeSeeMoneyNoCompanyTips'];
				$Fn_Job->Config['LangVar']['ResumeSeeMoneyTips'] = str_replace(array("{Money}","{ResumePackage}"),array($Fn_Job->Config['PluginVar']['ResumeSeeMoney'],$ResumePackage ? $Fn_Job->Config['LangVar']['ResumePackageMoneyTips'] : ''),$Fn_Job->Config['LangVar']['ResumeSeeMoneyTips']);
				
				
				if(($MySeeLog || $ApplyInfoResume) && $Fn_Job->Config['PluginVar']['ResumeIntervieSwitchw'] && $UserInfo['company']['id']){
					$JobCompanyList = array();
					foreach($Fn_Job->GetAjaxJobCompanyList(array('company_id'=>$UserInfo['company']['id'])) as $Key => $Val) {
						$JobCompanyList[$Val['id']] = $Val['classid_min_text'];
					}
					$DataJobCompanyList = $JobCompanyList ? MobileSelectJs($JobCompanyList) : '';

					//�ҵ���������
					$MyInterview = $Fn_Job->GetUserInterviewFirst($UserInfo['company']['id'],$Item['uid']);
				}
				
			}

			if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
				@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
				$PayList = $FnPay->GetPayList();
			}
			//��ά��
			if($Fn_Job->Config['PluginVar']['QrParameterSwitch']){
				$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.$Item['id'].'.jpg';
				if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
					@unlink($File);
					@require_once libfile('class/wechat','plugin/fn_assembly');
					$WechatClient = new Fn_WeChatClient($Fn_Job->Config['PluginVar']['WxAppid'], $Fn_Job->Config['PluginVar']['WxSecret']);
					$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.intval($Item['uid']),'expire'=>2592000)));
					DownloadImg($QrUrl,$File);
				}
				$QrCode = base64_encode(file_get_contents($File));
			}else{
				$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
				if(!file_exists($File) || !filesize($File)) {
					@require_once libfile('class/qrcode','plugin/fn_assembly');
					QRcode::png($Fn_Job->Rewrite($_GET['m'],array('rid'=>$Item['uid'])), $File, QR_ECLEVEL_L,5,2);
				}
				$QrCode = base64_encode(file_get_contents($File));
				@unlink($File);
			}
			//����
			$info_list = '';
			foreach($JobCompanyList as $key => $val) {
				$info_list .= ($key ? "\r\n" : '').$val['title'].'---'.$val['month_wages_text'];
			}
			$replaceArray = array('{name}','{mobile}','{sex}','{age}','{education}','{experience}','{expect_job}','{expect_month_wages}','{expect_address}','{tag}','{content}','{url}');
			$isreplaceArray = array($Item['full_name'],$Item['mobile'],$Item['sex_text'],$Item['age'],$Item['education_text'],$Item['experience_text'],$Item['expect_job'],$Item['expect_month_wages_text'],$Item['expect_province_text'],implode('|',$Item['param']['tag_list']),strip_tags($Item['content']),$Fn_Job->Rewrite($_GET['m'],array('rid'=>$Item['uid'])));
			$Fn_Job->Config['PluginVar']['ResumeCopyContent'] = str_replace($replaceArray,$isreplaceArray,$Fn_Job->Config['PluginVar']['ResumeCopyContent']);
			//���� END

			//����
			$Fn_Job->Config['WxShare']['WxUrl'] = $Fn_Job->Rewrite($_GET['m'],array('rid'=>$Item['uid']));
			$Fn_Job->Config['WxShare']['WxTitle'] = str_replace($replaceArray,$isreplaceArray,$Fn_Job->Config['PluginVar']['ResumeShareTitle']);
			$Fn_Job->Config['WxShare']['WxImg'] = $Item['face'] ? $Item['face'] : $Fn_Job->Config['WxShare']['WxImg'];
			$Fn_Job->Config['WxShare']['WxImg'] = strpos($Fn_Job->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Job->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Job->Config['WxShare']['WxImg'];
			//����End
		}
		
	}else{
		$navtitle = $Msg = $Fn_Job->Config['LangVar']['NoViewResumeData'];
	}
}else if($_GET['m'] == 'view_article'){//��Ѷ����
	
	$Item = $Fn_Job->GetViewArticlethread($_GET['aid']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['title'];

		if(!$Item['display'] && $Item['uid'] != $_G['uid'] && !$Fn_Job->Admin){
			$Msg = $Fn_Job->Config['LangVar']['ArticleInAudit'];
		}else{
			if($Item['jump']){
				dheader('Location:'.$Item['jump_link']);
				exit();
			}
			if(!checkmobile()){
				$Seo = str_replace(array('{title}','{class}','{content}'),array($Item['title'],$Item['class_title'],($Item['describe'] ? $Item['describe'] : cutstr(strip_tags($Item['content']),150))),explode("#",$Fn_Job->Config['PluginVar']['PcArticleSeo']));
				$navtitle = $Seo[0] ? $Seo[0] : $navtitle;
				$metakeywords = $Seo[1] ? $Seo[1] : $navtitle;
				$metadescription = $Seo[2] ? $Seo[2] : $navtitle;
			}

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Fn_Job->Config['PluginVar']['ClickRand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Job->TableArticle,$Item['id'],$ClickNum);

			if(!checkmobile()){//���԰�
				$ArticleClassList = $Fn_Job->GetArticleClassList();
				$ArticleHotList = $Fn_Job->GetAjaxArticleList(array('limit'=>10,'display'=>1,'hot'=>1,'classid'=>$Item['classid']));
				$ArticleList = $Fn_Job->GetAjaxArticleList(array('limit'=>10,'display'=>1,'classid'=>$Item['classid']));
			}
			
			//����
			$Fn_Job->Config['WxShare']['WxUrl'] = $Fn_Job->Rewrite($_GET['m'],array('aid'=>$Item['id']));
			$Fn_Job->Config['WxShare']['WxTitle'] = $navtitle;
			$Fn_Job->Config['WxShare']['WxDes'] = $Item['describe'] ? DeleteHtml($Item['describe']) : $Fn_Job->Config['WxShare']['WxDes'];

		}
	}else{
		$navtitle = $Msg = $Fn_Job->Config['LangVar']['NoArticleDiscData'];
	}

}else if($_GET['m'] == 'user'){//��Ա����

	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['UserTitle'];
	$Fn_Job->Config['LangVar']['UserPerfectTips'] = str_replace(array('{perfect}'),array(($UserInfo['resume']['perfect'] ? $UserInfo['resume']['perfect'] : 0).'%'),$Fn_Job->Config['LangVar']['UserPerfectTips']);
	$Fn_Job->Config['LangVar']['OverdueInfoCount'] = str_replace(array('{num}'),array($UserInfo['OverdueInfoCount']),$Fn_Job->Config['LangVar']['OverdueInfoCount']);

	$ResumeTopMoney = array_filter(explode("\r\n",$Fn_Job->Config['PluginVar']['ResumeTopMoney']));
	
	$ResumePackage = array_filter(explode("\r\n",$Fn_Job->Config['PluginVar']['ResumePackage']));

	$ResumeUserNav = array_filter(explode("\r\n",$Fn_Job->Config['PluginVar']['ResumeUserNav']));

	$CompanyUserNav = array_filter(explode("\r\n",$Fn_Job->Config['PluginVar']['CompanyUserNav']));

	$Fn_Job->Config['PluginVar']['OnlineWxPath'] = $Fn_Job->Config['PluginVar']['ResumeOnlineWxPath'] && ($UserInfo['identity'] == 2 || !$UserInfo['identity']) ? $Fn_Job->Config['PluginVar']['ResumeOnlineWxPath'] : $Fn_Job->Config['PluginVar']['OnlineWxPath'];
	$Fn_Job->Config['PluginVar']['AppOnlineWx'] = $Fn_Job->Config['PluginVar']['ResumeAppOnlineWx'] && ($UserInfo['identity'] == 2 || !$UserInfo['identity']) ? $Fn_Job->Config['PluginVar']['ResumeAppOnlineWx'] : $Fn_Job->Config['PluginVar']['AppOnlineWx'];

	$UserInfoList = $Fn_Job->GetAjaxUserInfoList();//�ҵķ���

	if(!checkmobile()){//���԰�
		$UserMatchingInfoList = $Fn_Job->GetAjaxUserMatchingInfoList();//ְλ�Ƽ�
	}

	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}

}else if($_GET['m'] == 'user_company'){//�༭��˾

	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['UserCompany'];

	$Album = $UserInfo['company']['param']['album'] ? json_encode($UserInfo['company']['param']['album']) : '';
	
	$DataArea = MobileSelectAreaJs($Fn_Job->Area);
	$DataScale = MobileSelectJs($Fn_Job->Config['LangVar']['ScaleArray']);
	$DataClass = MobileSelectJs($Fn_Job->Config['LangVar']['CompanyClassArray']);
	$ItemTag = array_filter(explode(",",$UserInfo['company']['tag']));
	
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

	$Fn_Job->Config['WxShare']['WxUrl'] = $Fn_Job->Config['UserCompanyUrl'];

}else if($_GET['m'] == 'user_info_list'){//ְλ����

	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['JobOp'];
	$TopMoney = array_filter($Fn_Job->Config['PluginVar']['job_top']);
	$UserInfoList = $Fn_Job->GetAjaxUserInfoList();
	
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}
}else if($_GET['m'] == 'user_resume'){//���ӱ༭����

	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['UserResumeAdd'];
	
	$Works = $UserInfo['resume']['param']['works'] ? json_encode($UserInfo['resume']['param']['works']) : '';

	$Life = $UserInfo['resume']['param']['life'] ? json_encode($UserInfo['resume']['param']['life']) : '';

	$ResumeContent = array_filter(explode("\r\n",$Fn_Job->Config['PluginVar']['ResumeContent']));
	if($UserInfo['resume']){
		$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['UserResumeEdit'];
		$ItemTag = array_filter(explode(",",$UserInfo['resume']['tag']));
		$ItemSpecial = array_filter(explode(",",$UserInfo['resume']['special']));
	}else{
		$Referer = urldecode($_GET['freferer']);
	}

	$DataArea = MobileSelectAreaJs($Fn_Job->Area,true);
	$DataBirthYear = MobileSelectJs($Fn_Job->Config['LangVar']['BirthYearArray']);
	$DataEducation = MobileSelectJs($Fn_Job->Config['LangVar']['EducationArray']);
	$DataExperience = MobileSelectJs($Fn_Job->Config['LangVar']['ExperienceArray']);
	$DataExpectMonthWages = MobileSelectJs($Fn_Job->Config['LangVar']['ExpectMonthWagesArray']);

	$Fn_Job->Config['LangVar']['ResumeExpectJobNumTips'] = str_replace('{num}',$Fn_Job->Config['PluginVar']['ResumeExpectJobNum'],$Fn_Job->Config['LangVar']['ResumeExpectJobNumTips']);

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
		@require_once libfile('class/upload','plugin/fn_assembly');
		$UploadConfig = fn_upload::Config();
	}

}else if($_GET['m'] == 'user_resume_apply_log'){//�����¼
	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['ApplicationRecord'];
	$InfoApplyLogList = $Fn_Job->GetUserInfoApplyLogList();

}else if($_GET['m'] == 'user_resume_collection_log'){//ְλ�ղ�
	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['JobCollection'];
	$InfoCollectionLogList = $Fn_Job->GetUserInfoCollectionLogList();

}else if($_GET['m'] == 'user_resume_matching_list'){//ְλƥ�����
	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['MatchingTitle'];
	$Item = $Fn_Job->GetViewthread($_GET['iid']);
	$Fn_Job->Config['LangVar']['MyRecommendListTitle'] = str_replace(array('{classid_min_text}'),array($Item['classid_min_text']),$Fn_Job->Config['LangVar']['MyRecommendListTitle']);
	
}else if($_GET['m'] == 'user_company_collection_log'){//�����ղ�
	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['UserCompanyHeadNavArray'][3];
	$CompanyCollectionLogList = $Fn_Job->GetUserCompanyCollectionLogList();

}else if($_GET['m'] == 'user_resume_see_log'){//�鿴��ϵ�ļ���
	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['UserCompanyHeadNavArray'][2];

}else if($_GET['m'] == 'user_company_apply_log'){//ӦƸ�ļ���
	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['UserCompanyHeadNavArray'][1];
	
	if(checkmobile()){ 
		array_unshift($Fn_Job->Config['LangVar']['ResumeSeeArray'],$Fn_Job->Config['LangVar']['Unlimited']);
	}
	$DataResumeSeeArray = MobileSelectJs($Fn_Job->Config['LangVar']['ResumeSeeArray']);
	
	array_unshift($Fn_Job->Config['LangVar']['ResumeSignList'],$Fn_Job->Config['LangVar']['Unlimited']);
	$DataResumeSignList = MobileSelectJs($Fn_Job->Config['LangVar']['ResumeSignList']);
	
	if($UserInfo['company']['id']){
		$JobCompanyList = array('0'=>$Fn_Job->Config['LangVar']['AllJob']);
		foreach($Fn_Job->GetAjaxJobCompanyList(array('company_id'=>$UserInfo['company']['id'])) as $Key => $Val) {
			$JobCompanyList[$Val['id']] = $Val['title'];
		}
		$DataJobCompanyList = $JobCompanyList ? MobileSelectJs($JobCompanyList) : '';
	}
	
}else if($_GET['m'] == 'user_company_interview_list'){//���������
	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['UserCompanyHeadNavArray'][4];

}else if($_GET['m'] == 'user_resume_interview_list'){//�����������
	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['ResumeIntervieTo'];

}else if($_GET['m'] == 'user_company_follow_list'){//��ע�Ĺ�˾
	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['CompanyFollowTitle'];
	$CompanyFollowList = $Fn_Job->GetCompanyFollowList(array('rid'=>$_G['uid']));

}else if($_GET['m'] == 'buy_store_level'){//��˾�ײ�
	
	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['BuyStoreLevelTitle'];
	
	$CompanyGroupList = $Fn_Job->GetCompanyGroupList(' where display = 1');
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
		@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
		$PayList = $FnPay->GetPayList();
	}

	$PayTitle = $Fn_Job->Config['LangVar']['PayCompanyContentPayTitle'];

	if($UserInfo['company']['vip']){
		$Fn_Job->Config['LangVar']['BuyStoreLevelOpen'] = $Fn_Job->Config['LangVar']['BuyStoreLevelRenew'];
		$Msg = $Fn_Job->Config['LangVar']['BuyStoreLevelRenewOk'];
	}else{
		$Msg = $Fn_Job->Config['LangVar']['BuyStoreLevelOpenOK'];
	}
}else if($_GET['m'] == 'hr_tools'){//Hr��������ҳ
	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['HrTools'];
	$HrToolsList = $Fn_Job->GetHrToolsList();
}else if($_GET['m'] == 'hr_tools_list'){//Hr�������б�
	$HrToolsList = $Fn_Job->GetHrToolsList();
	$navtitle = $metadescription = $metakeywords = $HrToolsList[$_GET['classid']]['title'].'_'.$Fn_Job->Config['LangVar']['HrTools'];
	$HrToolsInfoList = $Fn_Job->GetHrToolsInfoList(array('classid'=>$_GET['classid']));
}else if($_GET['m'] == 'view_fair'){//��Ƹ��
	
	$Item = $Fn_Job->GetViewFairthread($_GET['fid']);
	if($Item){
		
		$navtitle = $metadescription = $metakeywords = $Item['title'];

		if(!$Item['display'] && !$Fn_Job->Admin){
			$Msg = $Fn_Job->Config['LangVar']['FairInAudit'];
		}else{

			$MyFairCompany = $UserInfo['company']['id'] ? $Fn_Job->GetMyFairCompany($Item['id'],$UserInfo['company']['id']) : '';

			$Item['param']['top_money'] = array_filter(explode("\r\n",$Item['param']['top_money']));

			$Fn_Job->Config['PluginVar']['HeaderSwitch'] = $Item['param']['head_nav'];

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Item['param']['click_rand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Job->TableFair,$Item['id'],$ClickNum,'id');

			//��ά��
			if($Fn_Job->Config['PluginVar']['QrParameterSwitch']){
				$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.$Item['id'].'.jpg';
				if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
					@unlink($File);
					@require_once libfile('class/wechat','plugin/fn_assembly');
					$WechatClient = new Fn_WeChatClient($Fn_Job->Config['PluginVar']['WxAppid'], $Fn_Job->Config['PluginVar']['WxSecret']);
					$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.$Item['id'],'expire'=>2592000)));
					DownloadImg($QrUrl,$File);
				}
				$QrCode = base64_encode(file_get_contents($File));
			}else{
				$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
				if(!file_exists($File) || !filesize($File)) {
					@require_once libfile('class/qrcode','plugin/fn_assembly');
					QRcode::png($Fn_Job->Rewrite($_GET['m'],array('fid'=>$Item['id'])), $File, QR_ECLEVEL_L,5,2);
				}
				$QrCode = base64_encode(file_get_contents($File));
				@unlink($File);
			}
		
			//����
			$Fn_Job->Config['WxShare']['WxUrl'] = $Fn_Job->Rewrite($_GET['m'],array('fid'=>$Item['id']));
			$Fn_Job->Config['WxShare']['WxTitle'] = $Item['param']['share_title'] ? $Item['param']['share_title'] :  $Item['title'];
			$Fn_Job->Config['WxShare']['WxDes'] = $Item['param']['share_desc'] ? $Item['param']['share_desc'] :  $Item['title'];
			$Fn_Job->Config['WxShare']['WxImg'] = $Item['param']['share_img'] ? $Item['param']['share_img'] : $Fn_Job->Config['WxShare']['WxImg'];
			$Fn_Job->Config['WxShare']['WxImg'] = strpos($Fn_Job->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Job->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Job->Config['WxShare']['WxImg'];
			//����End

			if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
				@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
				$PayList = $FnPay->GetPayList();
			}

			$PayTitle = $Fn_Job->Config['LangVar']['FairOnlineApplicationPay'];
		}
		
	}else{
		$navtitle = $Msg = $Fn_Job->Config['LangVar']['NoViewFairData'];
	}

	//$navtitle = $metadescription = $metakeywords = $HrToolsList[$_GET['classid']]['title'].'_'.$Fn_Job->Config['LangVar']['HrTools'];
	
}else if($_GET['m'] == 'google_map'){//�ȸ��ͼ
	$navtitle = $metadescription = $metakeywords = $Fn_Job->Config['LangVar']['MapTitle'];

}
function NavInspect($Mod,$Url){
	global $_G,$Item;
	$StrReplaceArray = array('{','}');
	$StrReplaceArrayTo = array('','');
	$Rewrite = dunserialize($_G['setting']['fn_job_rewrite']);
	if($Mod == 'view_job'){
		$Rule = str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite['list_'.$Item['class']]['rule']);
	}else if($Mod == 'view_resume'){
		$Rule = str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite['list_resume']['rule']);
	}else if($Mod == 'view_company'){
		$Rule = str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite['list_company']['rule']);
	}else if($Mod == 'hr_tools_list'){
		$Rule = str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite['hr_tools']['rule']);
	}
	return str_replace('[siteurl]','',$Url) == $Rule ? true : false;
}
include template('fn_job:'.$_GET['m']);
?>