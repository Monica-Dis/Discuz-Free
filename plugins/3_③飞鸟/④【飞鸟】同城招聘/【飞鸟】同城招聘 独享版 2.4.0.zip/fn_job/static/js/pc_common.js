// 手机端二维码
$(document).on('mouseenter', ".GoToWeb", function (Event) {
    $(this).addClass('Hover');
}).on('mouseleave', ".GoToWeb", function (Event) {
    $(this).removeClass('Hover');
})
// 手机端二维码end

$(document).on('mouseenter', ".IsLogin", function (Event) {
    $(this).addClass('Hover');
    $(this).find("dl").show();
}).on('mouseleave', ".IsLogin", function (Event) {
    $(this).removeClass('Hover');
    $(this).find("dl").hide();
})
$(document).on('mouseenter', ".IsLogin dd", function (Event) {
    $(this).addClass('Hover');
}).on('mouseleave', ".IsLogin dd", function (Event) {
    $(this).removeClass('Hover');
})

 //轮播箭头封装
 $.fn.slideBtn = function(){
    var that = $(this);
    that.mouseenter(function() {
        that.find(".preBtn,.nextBtn").fadeIn(600);
    }).mouseleave(function() {
        that.find(".preBtn,.nextBtn").fadeOut(600);
    });
}
//轮播箭头封装 end




