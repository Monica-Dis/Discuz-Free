<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('FN_IN_API')) {

	exit('Access Denied');

}

loadcache('plugin');

function NotifyUpdatePay($OrderId,$Identification,$Money,$PayType,$TransactionId){

	global $_G;

	$OrderId = addslashes($OrderId);

	$Identification = addslashes($Identification);

	$Money = addslashes($Money);

	$PayType = addslashes($PayType);

	$TransactionId = addslashes($TransactionId);
	$TablePayLog = 'fn_pay_log';
	$TableInfo = 'fn_job_info';
	$TableCompany = 'fn_job_company';
	$TableCompanyGroupLog = 'fn_job_company_group_log';
	$TableResume = 'fn_job_resume';
	$TableResumeSeeLog = 'fn_job_resume_see_log';
	$TableFairCompany = 'fn_job_fair_company';
	$PayLog = DB::fetch_first('SELECT * FROM '.DB::table($TablePayLog).' where order_id = '.$OrderId.' and money = '.$Money);
	if($PayLog && $PayLog['state'] != 1){
		@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
		@require_once (DISCUZ_ROOT .'./source/plugin/fn_job/Function.inc.php');
		
$Data = array('state'=>1,'payment_type'=>$PayType,'pubid'=>$TransactionId,'pay_time'=>time());
		if(DB::update($TablePayLog,$Data,'order_id='.$OrderId)){
			$PayLog['param'] = unserialize($PayLog['param']);
			if($PayLog['param']['event'] == 'publish_info'){//������Ϣ
				$UpData['payment_state'] = 1;
				if(DB::update($TableInfo,$UpData,'id = '.$PayLog['param']['iid'])){
					DB::update($TableCompany,array('display'=>1),'id = '.$PayLog['param']['company_id']);
					$Fn_Job->GetCompanyFollowPush($PayLog['param']['iid']);
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'refresh_info'){//ˢ��
				$UpData['updateline'] = $PayLog['param']['updateline'];
				$UpData['expiry_push'] = 0;
				$UpData['hide'] = 1;
				if(DB::update($TableInfo,$UpData,'id = '.$PayLog['param']['iid'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'top_info'){//�ö�
				$UpData['topdateline'] = $PayLog['param']['topdateline'];
				$UpData['updateline'] = $PayLog['param']['updateline'];
				$UpData['top_expiry_push'] = 0;
				$UpData['payment_state'] = 1;
				$UpData['hide'] = 1;
				if(DB::update($TableInfo,$UpData,'id = '.$PayLog['param']['iid'])){
					DB::update($TableCompany,array('display'=>1,'resume_package_count'=>$PayLog['param']['resume_package_count']),'id = '.$PayLog['param']['company_id']);
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'refresh_resume'){//ˢ�¼���
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableResume,$UpData,'uid = '.$PayLog['param']['rid'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'top_resume'){//�ö�����
				$UpData['topdateline'] = $PayLog['param']['topdateline'];
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableResume,$UpData,'uid = '.$PayLog['param']['rid'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'resume_see_log'){//������ϵ��ʽ
				if($PayLog['param']['slid']){
					if(DB::update($TableResumeSeeLog,array('updateline'=>time()),'id = '.$PayLog['param']['slid'])){
						return true;
					}else{
						return false;
					}
				}else{
					$Id = DB::insert($TableResumeSeeLog,$PayLog['param']['insert'],true);
					DB::query("UPDATE ".DB::table($TableResumeSeeLog)." SET down_count = down_count + 1 WHERE uid = ".intval($PayLog['param']['insert']['rid']));
					if($Id){
						return true;
					}else{
						return false;
					}
				}
			}else if($PayLog['param']['event'] == 'buy_store_level'){//��˾��פ�ײ�
				$UpData['group_id'] = $PayLog['param']['group_id'];
				$UpData['due_time'] = $PayLog['param']['due_time'];
				$UpData['money'] = $PayLog['param']['money'];
				$UpData['vip_expiry_push'] = 0;
				if(DB::update($TableCompany,$UpData,'id = '.$PayLog['param']['company_id'])){

					$PayLog['param']['group_log'] ? DB::update($TableCompanyGroupLog,$PayLog['param']['data'],'company_id = '.$PayLog['param']['company_id']) : DB::insert($TableCompanyGroupLog,$PayLog['param']['data']);

					if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_crm')){
						$company = DB::fetch_first('SELECT * FROM '.DB::table($TableCompany).' where id = '.$PayLog['param']['company_id']);
						$customer = DB::fetch_first('SELECT * FROM '.DB::table('fn_crm_customer').' where project = \'fn_job\' and  project_id = '.$PayLog['param']['company_id']);
						
						!$customer ? DB::insert('fn_crm_customer',array('name'=>$company['name'],'project'=>'fn_job','project_id'=>$company['id'],'decision_mobile'=>$company['mobile'],'dateline'=>time(),'expire_dateline'=>$UpData['due_time'],'level'=>1)) : DB::update('fn_crm_customer',array('expire_dateline'=>$UpData['due_time'],'level'=>1),'id = '.$customer['id']);

					}

					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'resume_package'){//���������
				$UpData['resume_package_count'] = $PayLog['param']['resume_package_count'];
				if(DB::update($TableCompany,$UpData,'id = '.$PayLog['param']['company_id'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'fair_company'){//��Ƹ�ᱨ��
				$Id = DB::insert($TableFairCompany,$PayLog['param']['insert'],true);
				if($Id){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'refresh_fair'){//ˢ����Ƹ��
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableFairCompany,$UpData,'id = '.$PayLog['param']['fcid'])){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'top_fair'){//�ö���Ƹ��
				$UpData['topdateline'] = $PayLog['param']['topdateline'];
				$UpData['updateline'] = $PayLog['param']['updateline'];
				if(DB::update($TableFairCompany,$UpData,'id = '.$PayLog['param']['fcid'])){
					return true;
				}else{
					return false;
				}
			}
		}

	}

}
//dis'.'m.tao'.'bao.com
?>