<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_job_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `classid` int(11) unsigned NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `describe` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `jump` tinyint(1) unsigned NOT NULL,
  `jump_link` varchar(255) NOT NULL,
  `hot` tinyint(1) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`classid`,`company_id`,`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_article_class` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_keyword` varchar(255) NOT NULL,
  `seo_desc` varchar(255) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_company` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `admin_uid` varchar(255) NOT NULL,
  `group_id` tinyint(3) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `name_verify` tinyint(1) unsigned NOT NULL,
  `logo` varchar(255) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `scale` tinyint(1) unsigned NOT NULL,
  `classid` int(11) unsigned NOT NULL,
  `province` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `dist` varchar(20) NOT NULL,
  `community` varchar(50) NOT NULL,
  `lat` varchar(20) NOT NULL,
  `lng` varchar(20) NOT NULL,
  `contacts` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `sms_mobile` varchar(20) NOT NULL,
  `mobile_verify` tinyint(1) unsigned NOT NULL,
  `content` mediumtext NOT NULL,
  `tag` varchar(100) NOT NULL,
  `video_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `video_url` varchar(255) NOT NULL,
  `video_pic` varchar(255) NOT NULL,
  `param` mediumtext NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `money` int(11) unsigned NOT NULL,
  `verify` tinyint(1) unsigned NOT NULL,
  `resume_package_count` int(11) unsigned NOT NULL,
  `vip_expiry_push` tinyint(1) unsigned NOT NULL,
  `vip_stop` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vip_stop_date` int(11) unsigned NOT NULL,
  `hide_mobile` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `due_time` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `idx` (`group_id`,`uid`,`type`,`classid`,`scale`,`display`,`vip_stop`,`hide_mobile`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_company_follow` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(11) unsigned NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`rid`,`company_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_company_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `refresh_count` int(11) unsigned NOT NULL,
  `day_refresh_count` tinyint(3) unsigned NOT NULL,
  `refresh_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `day_info_count` int(11) unsigned NOT NULL,
  `info_count` int(11) unsigned NOT NULL,
  `resume_count` int(11) unsigned NOT NULL,
  `resume_day_count` int(11) unsigned NOT NULL,
  `examine` tinyint(1) unsigned NOT NULL,
  `top_discount` varchar(20) NOT NULL,
  `currency` int(11) unsigned NOT NULL,
  `hot` tinyint(1) unsigned NOT NULL,
  `hide` tinyint(1) unsigned NOT NULL,
  `apply_resume` tinyint(1) unsigned NOT NULL,
  `money` varchar(20) NOT NULL,
  `original_price` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `group_time` tinyint(3) unsigned NOT NULL,
  `displayorder` tinyint(3) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_company_group_log` (
  `company_id` int(11) unsigned NOT NULL,
  `refresh_count` int(11) unsigned NOT NULL,
  `day_refresh_count` tinyint(3) unsigned NOT NULL,
  `refresh_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `day_info_count` int(11) unsigned NOT NULL,
  `info_count` int(11) unsigned NOT NULL,
  `resume_count` int(11) unsigned NOT NULL,
  `resume_day_count` int(11) unsigned NOT NULL,
  `examine` tinyint(1) unsigned NOT NULL,
  `top_discount` varchar(20) NOT NULL,
  `hot` tinyint(1) unsigned NOT NULL,
  `hide` tinyint(1) unsigned NOT NULL,
  `apply_resume` tinyint(1) unsigned NOT NULL,
  KEY `idx` (`company_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_company_wallet_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `content` varchar(255) NOT NULL,
  `money` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`company_id`,`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_fair` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL,
  `banner` varchar(255) NOT NULL,
  `banner_link` varchar(255) NOT NULL,
  `start_time` int(11) unsigned NOT NULL,
  `end_time` int(11) unsigned NOT NULL,
  `content` text NOT NULL,
  `param` mediumtext NOT NULL,
  `money` varchar(20) NOT NULL,
  `groups` varchar(30) NOT NULL,
  `tel` varchar(30) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`type`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_fair_company` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fid` int(11) unsigned NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `hot` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`fid`,`company_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_hr_tools` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` varchar(255) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `displayorder` tinyint(3) NOT NULL,
  `display` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_hr_tools_info` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `file_url` varchar(255) NOT NULL,
  `display` tinyint(1) NOT NULL,
  `dateline` int(11) NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `idx` (`classid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(30) NOT NULL,
  `title` varchar(255) NOT NULL,
  `class` tinyint(1) NOT NULL,
  `bbclassid` varchar(20) NOT NULL,
  `bclassid` varchar(20) NOT NULL,
  `classid` varchar(20) NOT NULL,
  `province` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `dist` varchar(20) NOT NULL,
  `community` varchar(100) NOT NULL,
  `lat` varchar(20) NOT NULL,
  `lng` varchar(20) NOT NULL,
  `month_wages` int(11) NOT NULL,
  `month_wages_type` tinyint(2) unsigned NOT NULL,
  `settlement` tinyint(2) unsigned NOT NULL,
  `cycle` tinyint(2) unsigned NOT NULL,
  `number` int(11) unsigned NOT NULL,
  `education` tinyint(2) NOT NULL,
  `experience` tinyint(2) NOT NULL,
  `content` text NOT NULL,
  `tag` varchar(128) NOT NULL,
  `param` mediumtext NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `display` tinyint(1) NOT NULL,
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `payment_state` tinyint(1) unsigned NOT NULL,
  `payment_type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `expiry_push` tinyint(1) unsigned NOT NULL,
  `top_expiry_push` tinyint(3) unsigned NOT NULL,
  `apply_count` int(10) unsigned NOT NULL,
  `click` int(11) NOT NULL,
  `dateline` int(11) NOT NULL,
  `edit_dateline` int(11) NOT NULL,
  `updateline` int(11) NOT NULL,
  `topdateline` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`company_id`,`uid`,`class`,`month_wages`,`settlement`,`cycle`,`education`,`experience`,`display`,`hide`,`payment_state`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_info_apply_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `iid` int(11) unsigned NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `fid` int(11) unsigned NOT NULL,
  `see` tinyint(1) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`iid`,`company_id`,`fid`,`type`,`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_info_collection` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `iid` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`iid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_info_refresh_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `iid` int(11) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `uid` int(11) unsigned NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`iid`,`type`,`uid`,`company_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_info_report` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `iid` int(11) unsigned NOT NULL,
  `content` varchar(2000) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `handle_dateline` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`iid`,`state`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_interview` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `rid` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `contacts` varchar(50) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `interview_dateline` int(11) unsigned NOT NULL,
  `address` varchar(100) NOT NULL,
  `content` varchar(255) NOT NULL,
  `param` mediumtext NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`company_id`,`uid`,`rid`,`state`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_member` (
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `identity` tinyint(1) unsigned NOT NULL,
  `openid` varchar(50) NOT NULL,
  `unionid` varchar(50) NOT NULL,
  `subscribe` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  UNIQUE KEY `uid` (`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_resume` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `face` varchar(255) NOT NULL,
  `full_name` varchar(30) NOT NULL,
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `birth_year` int(4) unsigned NOT NULL,
  `age` tinyint(3) unsigned NOT NULL,
  `education` tinyint(2) unsigned NOT NULL,
  `experience` tinyint(2) unsigned NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `wx` varchar(50) NOT NULL,
  `expect_job` varchar(255) NOT NULL,
  `expect_job_classid` varchar(100) NOT NULL,
  `expect_month_wages` tinyint(2) unsigned NOT NULL,
  `expect_province` varchar(20) NOT NULL,
  `expect_city` varchar(20) NOT NULL,
  `expect_dist` varchar(20) NOT NULL,
  `tag` varchar(100) NOT NULL,
  `special` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `verify` tinyint(1) unsigned NOT NULL,
  `mobile_verify` tinyint(1) unsigned NOT NULL,
  `down_count` int(10) unsigned NOT NULL,
  `apply_count` int(11) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  `edit_dateline` int(11) unsigned NOT NULL,
  `day_refresh_dateline` int(11) unsigned NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `idx` (`uid`,`sex`,`age`,`education`,`experience`,`verify`,`display`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_resume_collection` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `rid` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`rid`,`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_resume_report` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `rid` int(11) unsigned NOT NULL,
  `content` varchar(2000) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `handle_dateline` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`company_id`,`rid`,`state`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_resume_see_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `rid` int(11) unsigned NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `mode` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`rid`,`company_id`,`mode`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_job_resume_sign` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `company_id` int(11) unsigned NOT NULL,
  `rid` int(11) unsigned NOT NULL,
  `sign` tinyint(2) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx` (`uid`,`company_id`,`rid`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
?>