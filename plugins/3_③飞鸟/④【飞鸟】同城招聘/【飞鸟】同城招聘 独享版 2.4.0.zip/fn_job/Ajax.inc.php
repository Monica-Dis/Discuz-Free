<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_job/Function.inc.php');

if($_GET['f'] == 'GetAjaxIndexList'){//��ҳ��Ϣ

	echo CJSON::encode($Fn_Job->GetAjaxIndexList($_GET));

}else if($_GET['f'] == 'GetAjaxList'){//ְλ�б�

	echo CJSON::encode($Fn_Job->GetAjaxList($_GET));

}else if($_GET['f'] == 'GetAjaxListResume'){//�˲��б�

	echo CJSON::encode($Fn_Job->GetAjaxListResume($_GET));

}else if($_GET['f'] == 'GetAjaxListCompany'){//��˾�б�

	echo CJSON::encode($Fn_Job->GetAjaxListCompany($_GET));

}else if($_GET['f'] == 'GetAjaxArticleList'){//��Ѷ�б�

	echo CJSON::encode($Fn_Job->GetAjaxArticleList($_GET));

}else if($_GET['f'] == 'GetAjaxPublish' && $_GET['formhash'] == formhash() && $_G['uid']){//������Ϣ

	echo urldecode(json_encode($Fn_Job->GetAjaxPublish($_GET)));

}else if($_GET['f'] == 'GetAjaxReport' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['iid']){//�ٱ��û�

	echo urldecode(json_encode($Fn_Job->GetAjaxReport($_GET)));

}else if($_GET['f'] == 'GetAjaxSimilarJobList' && $_GET['formhash'] == formhash()){//����ְλ

	echo CJSON::encode($Fn_Job->GetAjaxSimilarJobList($_GET));

}else if($_GET['f'] == 'GetAjaxInfoApplyLog' && $_GET['formhash'] == formhash() && $_GET['iid'] && $_G['uid']){//����ְλ

	echo urldecode(json_encode($Fn_Job->GetAjaxInfoApplyLog($_GET['iid'],$_GET['fid'])));

}else if($_GET['f'] == 'GetAjaxUserCompanyApplyLog' && $_GET['formhash'] == formhash() && $_G['uid']){//��˾�鿴�����ְλ
	
	echo CJSON::encode($Fn_Job->GetAjaxUserCompanyApplyLog($_GET));

}else if($_GET['f'] == 'GetAjaxDelCompanyApplyLog' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['alid']){//��˾ɾ�������ְλ

	echo urldecode(json_encode($Fn_Job->GetAjaxDelCompanyApplyLog($_GET['alid'])));

}else if($_GET['f'] == 'GetAjaxCompanyFollow' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['company_id']){//��ע��˾

	echo urldecode(json_encode($Fn_Job->GetAjaxCompanyFollow($_GET['company_id'])));

}else if($_GET['f'] == 'GetAjaxUserResumeSeeLogList' && $_GET['formhash'] == formhash() && $_G['uid']){//��˾�鿴�����ְλ
	
	echo CJSON::encode($Fn_Job->GetAjaxUserResumeSeeLogList($_GET));

}else if($_GET['f'] == 'GetAjaxResumeSeeLog' && $_GET['formhash'] == formhash() && $_GET['rid'] && $_G['uid']){//�鿴��ϵ��ʽ

	echo urldecode(json_encode($Fn_Job->GetAjaxResumeSeeLog($_GET['rid'])));

}else if($_GET['f'] == 'GetAjaxResumeSign' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['rid'] && $_GET['sign']){//���

	echo urldecode(json_encode($Fn_Job->GetAjaxResumeSign($_GET)));

}else if($_GET['f'] == 'GetAjaxResumeReport' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['rid']){//�ٱ��û�

	echo urldecode(json_encode($Fn_Job->GetAjaxResumeReport($_GET)));

}else if($_GET['f'] == 'GetAjaxInterviewJob' && $_GET['formhash'] == formhash() && $_GET['rid'] && $_G['uid']){//��������

	echo urldecode(json_encode($Fn_Job->GetAjaxInterviewJob($_GET)));

}else if($_GET['f'] == 'GetAjaxUserCompanyInterviewList' && $_GET['formhash'] == formhash() && $_G['uid']){//��˾���������б�
	
	echo CJSON::encode($Fn_Job->GetAjaxUserCompanyInterviewList($_GET));

}else if($_GET['f'] == 'GetAjaxUserResumeInterviewList' && $_GET['formhash'] == formhash() && $_G['uid']){//��ְ�����������б�
	
	echo CJSON::encode($Fn_Job->GetAjaxUserResumeInterviewList($_GET));

}else if($_GET['f'] == 'GetAjaxDelCompanyInterview' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['iid']){//��˾ɾ����������

	echo urldecode(json_encode($Fn_Job->GetAjaxDelCompanyInterview($_GET['iid'])));

}else if($_GET['f'] == 'GetAjaxUserResumeMatchingList' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['iid']){//ְλƥ���˲�
	
	echo CJSON::encode($Fn_Job->GetAjaxUserResumeMatchingList($_GET));

}else if($_GET['f'] == 'GetAjaxInfoCollect' && $_GET['formhash'] == formhash() && $_GET['iid'] && $_G['uid']){//�ղ�ְλ

	echo urldecode(json_encode($Fn_Job->GetAjaxInfoCollect($_GET['iid'])));

}else if($_GET['f'] == 'GetAjaxFairCompanyList'){//��Ƹ����빫˾
	
	echo CJSON::encode($Fn_Job->GetAjaxFairCompanyList($_GET));

}else if($_GET['f'] == 'GetAjaxFairSignUp' && $_GET['formhash'] == formhash() && $_GET['fid'] && $_G['uid']){//��Ƹ�ᱨ��

	echo urldecode(json_encode($Fn_Job->GetAjaxFairSignUp($_GET)));

}else if($_GET['f'] == 'GetAjaxFairRefresh' && $_GET['formhash'] == formhash() && $_G['uid']){//ˢ����Ƹ��

	echo urldecode(json_encode($Fn_Job->GetAjaxFairRefresh($_GET)));

}else if($_GET['f'] == 'GetAjaxFairTop' && $_GET['formhash'] == formhash() && $_G['uid']){//�ö���Ƹ��

	echo urldecode(json_encode($Fn_Job->GetAjaxFairTop($_GET)));

}else if($_GET['f'] == 'GetAjaxUserCompany' && $_GET['formhash'] == formhash() && $_G['uid']){//�༭��˾

	echo urldecode(json_encode($Fn_Job->GetAjaxUserCompany($_GET)));

}else if($_GET['f'] == 'GetAjaxCompanyHideMobile' && $_GET['formhash'] == formhash() && $_G['uid']){//�޸Ĺ�˾�绰״̬

	echo urldecode(json_encode($Fn_Job->GetAjaxCompanyHideMobile()));

}else if($_GET['f'] == 'GetAjaxUserResume' && $_GET['formhash'] == formhash() && $_G['uid']){//�༭����

	echo urldecode(json_encode($Fn_Job->GetAjaxUserResume($_GET)));

}else if($_GET['f'] == 'GetAjaxSendOut' && $_GET['formhash'] == formhash() && $_G['uid']){//������֤��
	echo urldecode(json_encode($Fn_Job->GetAjaxSendOut($_GET['mobile'],$_GET['resume'])));

}else if($_GET['f'] == 'GetAjaxResumeCollect' && $_GET['formhash'] == formhash() && $_GET['rid'] && $_G['uid']){//�ղؼ���

	echo urldecode(json_encode($Fn_Job->GetAjaxResumeCollect($_GET['rid'])));

}else if($_GET['f'] == 'GetAjaxUserIdentity' && $_GET['formhash'] == formhash() && $_GET['value']){//����ת��

	echo urldecode(json_encode($Fn_Job->GetAjaxUserIdentity($_GET['value'])));

}else if($_GET['f'] == 'GetAjaxResumePackage' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['money'] && $_GET['num']){//���������
	
	echo urldecode(json_encode($Fn_Job->GetAjaxResumePackage($_GET)));

}else if($_GET['f'] == 'GetAjaxUserResumeState' && $_GET['formhash'] == formhash() && $_GET['value']){//����״̬ת��

	echo urldecode(json_encode($Fn_Job->GetAjaxUserResumeState($_GET['value'])));

}else if($_GET['f'] == 'GetAjaxUserInfoOp' && $_GET['formhash'] == formhash() && $_GET['Op'] && $_GET['iid'] && $_G['uid']){

	echo urldecode(json_encode($Fn_Job->GetAjaxUserInfoOp($_GET['Op'],$_GET['iid'],$_GET['field'],$_GET['value'])));

}else if($_GET['f'] == 'GetAjaxUserHideInfo' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['iid']){//����/��ʾְλ

	echo urldecode(json_encode($Fn_Job->GetAjaxUserHideInfo($_GET)));

}else if($_GET['f'] == 'GetAjaxRefresh' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['iid']){//ˢ��
	
	echo urldecode(json_encode($Fn_Job->GetAjaxRefresh($_GET)));

}else if($_GET['f'] == 'GetAjaxAllRefresh' && $_GET['formhash'] == formhash() && $_G['uid']){//ˢ��

	echo urldecode(json_encode($Fn_Job->GetAjaxAllRefresh()));

}else if($_GET['f'] == 'GetAjaxTop' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['iid'] && $_GET['money']){//�ö�

	echo urldecode(json_encode($Fn_Job->GetAjaxTop($_GET)));

}else if($_GET['f'] == 'GetAjaxRefreshResume' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['rid']){//ˢ�¼���
	
	if($Fn_Job->Config['PluginVar']['ResumeRefreshMoney']){
		echo json_encode($Fn_Job->GetAjaxPayLog(array('event'=>'refresh_resume','money'=>$Fn_Job->Config['PluginVar']['ResumeRefreshMoney'],'rid'=>$_GET['rid'])));
	}else{
		DB::update($Fn_Job->TableResume,array('updateline'=>time()),'uid = '.intval($_GET['rid']));
		echo urldecode(json_encode(array('State'=>'201')));
	}

}else if($_GET['f'] == 'GetAjaxTopResume' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['rid'] && $_GET['money']){//�ö�����

	echo json_encode($Fn_Job->GetAjaxPayLog(array('event'=>'top_resume','money'=>$_GET['money'],'day'=>$_GET['day'],'rid'=>$_GET['rid'])));

}else if($_GET['f'] == 'GetAjaxBuyStoreLevel' && $_GET['formhash'] == formhash() && $_G['uid']){//��ͨ�ŵ�/��˾�ײ�
	echo urldecode(json_encode($Fn_Job->GetAjaxBuyStoreLevel($_GET)));

}else if($_GET['f'] == 'GetAjaxUserRefreshInfo' && $_GET['formhash'] == formhash() && $_G['uid']){//���ˢ��ְλ
	
	echo urldecode(json_encode($Fn_Job->GetAjaxUserRefreshInfo($_GET)));

}else if($_GET['f'] == 'GetAjaxUserWalletRefreshInfo' && $_GET['formhash'] == formhash() && $_G['uid']){//���ˢ��ְλ
	
	echo urldecode(json_encode($Fn_Job->GetAjaxUserWalletRefreshInfo($_GET)));

}else if($_GET['f'] == 'GetAjaxAdminEditInfoFields' && $_GET['formhash'] == formhash() && $_G['uid']){//����Ա�޸��ֶ�ֵ
	echo urldecode(json_encode($Fn_Job->GetAjaxAdminEditInfoFields($_GET['iid'],$_GET['field'],$_GET['val'])));

}else if($_GET['f'] == 'GetAjaxAdminEditResumeFields' && $_GET['formhash'] == formhash() && $_G['uid']){//����Ա�޸��ֶ�ֵ
	echo urldecode(json_encode($Fn_Job->GetAjaxAdminEditResumeFields($_GET['rid'],$_GET['field'],$_GET['val'])));

}else if($_GET['f'] == 'GetAjaxAdminEditCompanyFields' && $_GET['formhash'] == formhash() && $_G['uid']){//����Ա�޸��ֶ�ֵ
	echo urldecode(json_encode($Fn_Job->GetAjaxAdminEditCompanyFields($_GET['cid'],$_GET['field'],$_GET['val'])));

}else if($_GET['f'] == 'GetAjaxUpload' && $_GET['formhash'] == formhash()){//�ϴ�ͼƬ
	echo urldecode(json_encode(GetAjaxUpload($_FILES)));
}
//From: d'.'is'.'m.ta'.'obao.com
?>