<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once libfile('function/core','plugin/fn_assembly');
@require_once libfile('class/magapp','plugin/fn_assembly');
@require_once libfile('class/qfapp','plugin/fn_assembly');
@require_once libfile('class/pay','plugin/fn_assembly');
@require_once libfile('class/json','plugin/fn_assembly');

class Fn_Job{
	public function __construct() {
		global $_G,$plugin,$Config;
		loadcache('plugin');
		loadcache('fn_job_setting');
		foreach($_G['cache']['fn_job_setting'] as $key => $value) {
			$this->Config['PluginVar'][$key] = is_array($value) ? $value : stripslashes($value);
		}
	
		$this->Area = SelectArray($this->Config['PluginVar']['Area']);
		$this->ClassList = SelectArray($this->Config['PluginVar']['Class']);
		$this->AdminUidsList = array_filter(explode(",",$this->Config['PluginVar']['AdminUids']));
		$this->Admin = in_array($_G['uid'],$this->AdminUidsList) ? true : false;
		$this->Config['PluginVar']['GlobalProhibitUis'] = array_filter(explode(",",$this->Config['PluginVar']['GlobalProhibitUis']));
		$this->Config['PluginVar']['ResumeProhibitUids'] = array_filter(explode(",",$this->Config['PluginVar']['ResumeProhibitUids']));
		$this->Config['PluginVar']['VipProhibitUids'] = array_filter(explode(",",$this->Config['PluginVar']['VipProhibitUids']));
		
		//������ά�뿪��
		if(!$this->Config['PluginVar']['QrParameterSwitch'] && QrParameterSwitch){
			$this->Config['PluginVar']['WxAppid'] = $Config['PluginVar']['WxAppid'];
			$this->Config['PluginVar']['WxSecret'] = $Config['PluginVar']['WxSecret'];
		}
		$this->Config['PluginVar']['QrParameterSwitch'] = $this->Config['PluginVar']['QrParameterSwitch'] ? $this->Config['PluginVar']['QrParameterSwitch'] : (QrParameterSwitch ? QrParameterSwitch : 0);
		//������ά�뿪�� End
		
		$this->Config['LangVar'] = lang('plugin/fn_job');
		$this->Config['LangVar']['MonthWagesArray'] = TextareaArray($this->Config['PluginVar']['MonthWages']);
		$this->Config['LangVar']['EducationArray'] = TextareaArray($this->Config['PluginVar']['Education']);
		$this->Config['LangVar']['ExperienceArray'] = TextareaArray($this->Config['PluginVar']['Experience']);
		$this->Config['LangVar']['WelfareArray'] = TextareaArray($this->Config['PluginVar']['Welfare']);
		$this->Config['LangVar']['SettlementArray'] = TextareaArray($this->Config['PluginVar']['Settlement']);
		$this->Config['LangVar']['CycleArray'] = TextareaArray($this->Config['PluginVar']['Cycle']);
		$this->Config['LangVar']['MonthWagesTypeArray'] = TextareaArray($this->Config['PluginVar']['MonthWagesType']);
		$this->Config['LangVar']['ScaleArray'] = TextareaArray($this->Config['PluginVar']['Scale']);
		$this->Config['LangVar']['CompanyClassArray'] = TextareaArray($this->Config['PluginVar']['CompanyClass']);
		$this->Config['LangVar']['ExpectMonthWagesArray'] = TextareaArray($this->Config['PluginVar']['ExpectMonthWages']);
		$this->Config['LangVar']['ResumeTagArray'] = TextareaArray($this->Config['PluginVar']['ResumeTag']);
		$this->Config['LangVar']['ResumeStateTips'] = TextareaArray($this->Config['PluginVar']['ResumeStateTips']);
		$this->Config['LangVar']['ResumeSignList'] = TextareaArray($this->Config['PluginVar']['ResumeSignList']);
		$this->Config['LangVar']['ResumeSpecialList'] = TextareaArray($this->Config['PluginVar']['ResumeSpecialList']);

		$this->Config['Path'] = 'source/plugin/fn_job';
		$this->Config['StaticPath'] =  $_G['siteroot'].$this->Config['Path'].'/static';
		$this->Config['StaticPicPath'] = $this->Config['Path'].'/attachment/';
		$this->Config['Url'] = $_G['siteurl'].'plugin.php?id=fn_job'.($_GET['formapp'] ? '&formapp='.$_GET['formapp'] : '');
		$this->Config['ListUrl'] = $this->Config['Url'].'&m=list';
		$this->Config['ListResumeUrl'] = $this->Config['Url'].'&m=list_resume';
		$this->Config['ListCompanyUrl'] = $this->Config['Url'].'&m=list_company';
		$this->Config['ListArticleUrl'] = $this->Config['Url'].'&m=list_article';
		$this->Config['PublishUrl'] = $this->Config['Url'].'&m=publish';
		$this->Config['UserUrl'] = $this->Config['Url'].'&m=user';
		$this->Config['UserResumeUrl'] = $this->Config['Url'].'&m=user_resume';
		$this->Config['UserResumeApplyLogUrl'] = $this->Config['Url'].'&m=user_resume_apply_log';
		$this->Config['UserResumeCollectionLogUrl'] = $this->Config['Url'].'&m=user_resume_collection_log';
		$this->Config['UserCompanyCollectionLogUrl'] = $this->Config['Url'].'&m=user_company_collection_log';
		$this->Config['UserCompanyUrl'] = $this->Config['Url'].'&m=user_company';
		$this->Config['UserCompanyApplyLogUrl'] = $this->Config['Url'].'&m=user_company_apply_log';
		$this->Config['UserCompanyInterviewListUrl'] = $this->Config['Url'].'&m=user_company_interview_list';
		$this->Config['UserCompanyFollowListUrl'] = $this->Config['Url'].'&m=user_company_follow_list';
		$this->Config['UserResumeSeeLogUrl'] = $this->Config['Url'].'&m=user_resume_see_log';
		$this->Config['UserResumeInterviewListUrl'] = $this->Config['Url'].'&m=user_resume_interview_list';
		$this->Config['UserResumeMatchingListUrl'] = $this->Config['Url'].'&m=user_resume_matching_list';
		$this->Config['UserInfoListUrl'] = $this->Config['Url'].'&m=user_info_list';
		$this->Config['ViewJobUrl'] = $this->Config['Url'].'&m=view_job&iid=';
		$this->Config['ViewResumeUrl'] = $this->Config['Url'].'&m=view_resume&rid=';
		$this->Config['ViewCompanyUrl'] = $this->Config['Url'].'&m=view_company&cid=';
		$this->Config['ViewFairUrl'] = $this->Config['Url'].'&m=view_fair&fid=';
		$this->Config['ViewArticleUrl'] = $this->Config['Url'].'&m=view_article&aid=';
		$this->Config['BuyStoreLevelUrl'] = $this->Config['Url'].'&m=buy_store_level';
		$this->Config['HrToolsUrl'] = $this->Config['Url'].'&m=hr_tools';
		$this->Config['HrToolsListUrl'] = $this->Config['Url'].'&m=hr_tools_list&classid=';
		$this->Config['GoogleMapUrl'] = $this->Config['Url'].'&m=google_map';
		
		$this->Config['AjaxUrl'] =  $_G['siteroot'].'plugin.php?id=fn_job:Ajax'.($_GET['formapp'] ? '&formapp='.$_GET['formapp'] : '');
		$this->Config['WxShare'] = array(
			'WxTitle' => $this->Config['PluginVar']['WxTitle'],
			'WxDes' => $this->Config['PluginVar']['WxDes'],
			'WxImg' => strpos($this->Config['PluginVar']['WxImg'],'http') !== false ? $this->Config['PluginVar']['WxImg'] : $_G['siteurl'].$this->Config['PluginVar']['WxImg'],
			'WxUrl' => $this->Rewrite('index')
		);

		if(!is_dir(DISCUZ_ROOT.$this->Config['StaticPicPath'])){
			dmkdir(DISCUZ_ROOT.$this->Config['StaticPicPath']);
		}
		
		$this->TableArticle = 'fn_job_article';
		$this->TableArticleClass = 'fn_job_article_class';
		$this->TableMember = 'fn_job_member';
		$this->TableInfo = 'fn_job_info';
		$this->TableInfoReport = 'fn_job_info_report';
		$this->TableInfoCollection = 'fn_job_info_collection';
		$this->TableInfoApplyLog = 'fn_job_info_apply_log';
		$this->TableCompany = 'fn_job_company';
		$this->TableCompanyFollow = 'fn_job_company_follow';
		$this->TableCompanyGroup = 'fn_job_company_group';
		$this->TableCompanyGroupLog = 'fn_job_company_group_log';
		$this->TableCompanyWalletLog = 'fn_job_company_wallet_log';
		$this->TableFair = 'fn_job_fair';
		$this->TableFairCompany = 'fn_job_fair_company';
		$this->TableResume = 'fn_job_resume';
		$this->TableResumeCollection = 'fn_job_resume_collection';
		$this->TableResumeReport = 'fn_job_resume_report';
		$this->TableResumeSeeLog = 'fn_job_resume_see_log';
		$this->TableResumeSign= 'fn_job_resume_sign';
		$this->TableInfoRefreshLog = 'fn_job_info_refresh_log';
		$this->TableInterview = 'fn_job_interview';
		$this->TableHrTools = 'fn_job_hr_tools';
		$this->TableHrToolsInfo = 'fn_job_hr_tools_info';
		
		$this->Pay = new Fn_PayLog();
		$this->MagApp = new MagApp($this->Config['PluginVar']['MagSecret'],$this->Config['PluginVar']['MagAssistantSecret'],$this->Config['PluginVar']['MagAssistantPush']);
		$this->QHApp = new QHApp($this->Config['PluginVar']['qf_type'],$this->Config['PluginVar']['qf_sr_type'],$this->Config['PluginVar']['qf_from_id']);
		$this->Config['AppPaymentId'] = $this->QHApp->AppPaymentId;
		
	}

	public function GetUserInfo(){
		global $_G;
		@require_once libfile('function/forum');
		$UserInfo = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where uid = '.intval($_G['uid']));
		$UserInfo['face'] = discuz_uc_avatar($_G['uid'],'middle',true);
		$UserInfo['mobile'] = GetMobile();
		$UserInfo['resume'] = DB::fetch_first('SELECT * FROM '.DB::table($this->TableResume).' where uid = '.intval($_G['uid']));

		$UserInfo['company'] = DB::fetch_first('SELECT C.*,AG.title,AG.ico,AGL.day_refresh_count,AGL.day_info_count,AGL.info_count,AGL.resume_count,AGL.resume_day_count,AGL.examine,AGL.refresh_count,AGL.top_discount,AGL.refresh_type,AGL.hide,AGL.apply_resume FROM '.DB::table($this->TableCompany).' C LEFT JOIN `'.DB::table($this->TableCompanyGroup).'` AG on AG.id = C.group_id LEFT JOIN `'.DB::table($this->TableCompanyGroupLog).'` AGL on AGL.company_id = C.id where ( C.uid = '.intval($_G['uid']).' or FIND_IN_SET('.intval($_G['uid']).',C.admin_uid))');

		$UserInfo['CollectionResumeCount'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResumeCollection).' where uid = '.intval($_G['uid']));
		$UserInfo['CollectionInfoCount'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoCollection).' where uid = '.intval($_G['uid']));
		$UserInfo['CompanyFollowCount'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableCompanyFollow).' where rid = '.intval($_G['uid']));
		$UserInfo['ApplyLogCount'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoApplyLog).' where uid = '.intval($_G['uid']));
		$UserInfo['CompanyApplyLogCount'] = $UserInfo['company']['id'] ? DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoApplyLog).' where company_id = '.intval($UserInfo['company']['id'])) : 0;
		$UserInfo['ResumeSeeLogCount'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResumeSeeLog).' where '.($UserInfo['company']['id'] ? 'company_id = '.intval($UserInfo['company']['id']) : ' uid = '.intval($_G['uid']) ).($this->Config['PluginVar']['ResumeSeeDueTime'] ? ' and updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ResumeSeeDueTime'])." day",time()) : ''));
		$UserInfo['CompanyInterviewCount'] = $UserInfo['company']['id'] ? DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInterview).' where company_id = '.intval($UserInfo['company']['id'])) : 0;
		$UserInfo['ResumeInterviewCount'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInterview).' where rid = '.intval($_G['uid']));
		$UserInfo['OverdueInfoCount'] = $this->Config['PluginVar']['ExpiryTime'] ? DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where uid = '.intval($_G['uid']).' and updateline < '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time())) : '';
		
		if($UserInfo['company']){

			$UserInfo['company']['param'] = unserialize($UserInfo['company']['param']);
			$UserInfo['company']['vip'] = $UserInfo['company']['due_time'] > time() && !$UserInfo['company']['vip_stop'] ? true : false;
			$UserInfo['company']['logo'] = $UserInfo['company']['logo']  ? $UserInfo['company']['logo'] : $this->Config['PluginVar']['CompanyLogoPath'];
			$UserInfo['company']['province_text'] = $this->Area[$UserInfo['company']['province']]['content'].($UserInfo['company']['city'] ? '-'.$this->Area[$UserInfo['company']['city']]['content'] : '').($UserInfo['company']['dist'] ? '-'.$this->Area[$UserInfo['company']['dist']]['content'] : '');
			$UserInfo['company']['type_text'] = $this->Config['LangVar']['CompanyTypeArray'][$UserInfo['company']['type']];

			$UserInfo['company']['use_refresh_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoRefreshLog).' where company_id = '.intval($UserInfo['company']['id']).' and type = 1');
			$UserInfo['company']['use_day_refresh_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoRefreshLog).' where company_id = '.intval($UserInfo['company']['id']).' and type = 1 and dateline >= '.strtotime(date('Y-m-d',time())).' and dateline <= '.strtotime(date('Y-m-d 23:59:59',time())));
			$UserInfo['company']['use_info_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_type = 2 and payment_state = 1 and company_id = '.intval($UserInfo['company']['id']));
			$UserInfo['company']['use_resume_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResumeSeeLog).' where mode = 2 and company_id = '.intval($UserInfo['company']['id']));

			$UserInfo['RemnantRefreshCount'] = $UserInfo['company']['refresh_count'] - $UserInfo['company']['use_refresh_count'];

			$UserInfo['RemnantDayRefreshCount'] = $UserInfo['company']['day_refresh_count'] - $UserInfo['company']['use_day_refresh_count'];

			$UserInfo['RemnantInfoCount'] = $UserInfo['company']['info_count'] - $UserInfo['company']['use_info_count'];

			$UserInfo['RemnantResumeCount'] = $UserInfo['company']['resume_count'] - $UserInfo['company']['use_resume_count'];

			$UserInfo['company']['admin'] = array_unique(array_filter(explode(",",$UserInfo['company']['admin_uid'].','.$UserInfo['company']['uid'])));

		}
		
		if($UserInfo['resume']){
			
			$UserInfo['resume']['param'] = unserialize($UserInfo['resume']['param']);
			
			$UserInfo['resume']['province_text'] = $this->Area[$UserInfo['resume']['expect_province']]['content'].($UserInfo['resume']['expect_city'] ? '-'.$this->Area[$UserInfo['resume']['expect_city']]['content'] : '').($UserInfo['resume']['expect_dist'] ? '-'.$this->Area[$UserInfo['resume']['expect_dist']]['content'] : '');
			
			$UserInfo['resume']['face'] = $UserInfo['resume']['face'] ? $UserInfo['resume']['face'] : ($UserInfo['resume']['mobile_verify'] == 1 ? $this->Config['PluginVar']['ResumeFace1Path'] : $this->Config['PluginVar']['ResumeFace2Path']);

			$UserInfo['resume']['down_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResumeSeeLog).' where rid = '.intval($UserInfo['resume']['uid']));

			//���ƶ�
			$PerfectField = array('full_name','sex','face','birth_year','age','education','experience','mobile','expect_job','expect_month_wages','expect_province','tag','content','work_experience_list','educational_experience_list');
			$I = 0;
			foreach($PerfectField as $Key => $Val) {
				if(in_array($Val,array('work_experience_list','educational_experience_list'))){
					if($UserInfo['resume']['param'][$Val]){
						$I++;
					}
				}else if($UserInfo['resume'][$Val]){
					$I++;
				}
			}
			$UserInfo['resume']['perfect'] = intval(100 / count($PerfectField) * $I);
			//���ƶ�End

			//ÿ��ˢ�¼���
			if($this->Config['PluginVar']['ResumeDayRefreshSwitch'] && $UserInfo['resume']['day_refresh_dateline'] <= time() && !$this->Admin){
				DB::update($this->TableResume,array('updateline'=>time(),'day_refresh_dateline'=>strtotime("+".$this->Config['PluginVar']['ResumeDayRefreshTime']." hours",time())),'uid = '.intval($UserInfo['resume']['uid']));
			}
		}
		return $UserInfo;
	}
	
	//����ת��
	public function GetAjaxUserIdentity($Value){
		global $_G;
		$UserInfo = $this->GetUserInfo();
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['identity'] = in_array($Value,array('1','2')) ? intval($Value) : 1;
		if(!$UserInfo['uid']){
			$UpData['dateline'] = $UpData['updateline'] = time();
			if(DB::insert($this->TableMember,$UpData)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UserIdentitySwitchOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UserIdentitySwitchErr']);
			}

		}else{
			if(DB::update($this->TableMember,$UpData,'uid = '.intval($_G['uid']))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UserIdentitySwitchOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UserIdentitySwitchErr']);
			}
		}
		return $Data;
	}

	/* ְλ���� */
	public function GetViewthread($Id,$Where = null){
		
		$Item = DB::fetch_first('SELECT I.* FROM '.DB::table($this->TableInfo).' I where I.id = '.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['content'] = stripslashes($Item['content']);
			$Item['class_text'] = $this->Config['LangVar']['ClassArray'][$Item['class']];
			$Item['classid_text'] = $this->ClassList[$Item['bbclassid']]['content'].($Item['bclassid'] ? '-'.$this->ClassList[$Item['bclassid']]['content'] : '').($Item['classid'] ? '-'.$this->ClassList[$Item['classid']]['content'] : '');
			$Item['classid_min_text'] = $this->ClassList[$Item['classid']]['content'].(!$Item['classid'] ? $this->ClassList[$Item['bclassid']]['content'] : '').(!$Item['bclassid'] ? $this->ClassList[$Item['bbclassid']]['content'] : '');
			$Item['company'] = DB::fetch_first('SELECT C.*,AG.title,AG.ico,AGL.day_refresh_count,AGL.day_info_count,AGL.info_count,AGL.resume_count,AGL.resume_day_count,AGL.examine,AGL.refresh_count,AGL.top_discount FROM '.DB::table($this->TableCompany).' C LEFT JOIN `'.DB::table($this->TableCompanyGroup).'` AG on AG.id = C.group_id LEFT JOIN `'.DB::table($this->TableCompanyGroupLog).'` AGL on AGL.company_id = C.id where C.id = '.intval($Item['company_id']));
			$Item['month_wages_text'] = $Item['class'] == 1 ? ($Item['month_wages'] ? $this->Config['LangVar']['MonthWagesArray'][$Item['month_wages']] : $this->Config['LangVar']['Interview']) : $Item['month_wages'].$this->Config['LangVar']['MonthWagesTypeArray'][$Item['month_wages_type']];
			
			if($Item['company']){
				$Item['company']['param'] = unserialize($Item['company']['param']);
				$Item['company']['content'] = strip_tags(stripslashes($Item['company']['content']));
				$Item['company']['vip'] = $Item['company']['due_time'] > time() && !$Item['company']['vip_stop'] ? true : false;
				$Item['company']['logo'] = $Item['company']['logo']  ? $Item['company']['logo'] : $this->Config['PluginVar']['CompanyLogoPath'];
				$Item['company']['province_text'] = $this->Area[$Item['company']['province']]['content'].($Item['company']['city'] ? '-'.$this->Area[$Item['company']['city']]['content'] : '').($Item['company']['dist'] ? '-'.$this->Area[$Item['company']['dist']]['content'] : '');
				$Item['company']['type_text'] = $this->Config['LangVar']['CompanyTypeArray'][$Item['company']['type']];
			}
			
			$Item['province_text'] = $this->Area[$Item['company']['province']]['content'].($Item['company']['city'] ? '-'.$this->Area[$Item['company']['city']]['content'] : '').($Item['company']['dist'] ? '-'.$this->Area[$Item['company']['dist']]['content'] : '');

			$Item['mobile'] = $Item['mobile'] ? $Item['mobile'] : $Item['company']['mobile'];

			$Item['apply_log_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoApplyLog).' where iid = '.intval($Item['id']));
			$Item['apply_log_count_tips'] = str_replace(array('{num}'),array($Item['apply_log_count']),$this->Config['LangVar']['apply_log_count_tips']);

			$Item['collection_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoCollection).' where iid = '.intval($Item['id']));
			$Item['collection_tips'] = str_replace(array('{num}'),array($Item['collection_count']),$this->Config['LangVar']['collection_tips']);

		}
		return $Item;
	}

	/* ��˾���� */
	public function GetViewCompanythread($Id,$Field = 'id'){
		$Item = DB::fetch_first('SELECT C.*,AG.title,AG.ico,AGL.day_refresh_count,AGL.day_info_count,AGL.info_count,AGL.resume_count,AGL.resume_day_count,AGL.examine,AGL.refresh_count,AGL.top_discount FROM '.DB::table($this->TableCompany).' C LEFT JOIN `'.DB::table($this->TableCompanyGroup).'` AG on AG.id = C.group_id LEFT JOIN `'.DB::table($this->TableCompanyGroupLog).'` AGL on AGL.company_id = C.id where C.'.$Field.' = '.intval($Id));
		if($Item){

			$Item['param'] = unserialize($Item['param']);
			$Item['content'] = stripslashes($Item['content']);
			$Item['video_url'] = stripslashes($Item['video_url']);
			$Item['vip'] = $Item['due_time'] > time() && !$Item['vip_stop'] ? true : false;
			$Item['logo'] = $Item['logo']  ? $Item['logo'] : $this->Config['PluginVar']['CompanyLogoPath'];
			$Item['province_text'] = $this->Area[$Item['province']]['content'].($Item['city'] ? '-'.$this->Area[$Item['city']]['content'] : '').($Item['dist'] ? '-'.$this->Area[$Item['dist']]['content'] : '');
			$Item['type_text'] = $this->Config['LangVar']['CompanyTypeArray'][$Item['type']];
			$Item['scale_text'] = $this->Config['LangVar']['ScaleArray'][$Item['scale']];
			$Item['class_text'] = $this->Config['LangVar']['CompanyClassArray'][$Item['classid']];
			$Item['admin'] = array_unique(array_filter(explode(",",$Item['admin_uid'].','.$Item['uid'])));
			$Item['url'] = $this->Rewrite('view_company',array('cid'=>$Item['id']));
		}
		return $Item;
	}

	/* �������� */
	public function GetViewResumethread($Id){
		$Item = DB::fetch_first('SELECT R.* FROM '.DB::table($this->TableResume).' R where R.uid = '.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['content'] = stripslashes($Item['content']);
			$Item['tag_list'] = array_filter(explode(",",$Item['tag']));
			$Item['province_text'] = $this->Area[$Item['expect_province']]['content'].($Item['expect_city'] ? '-'.$this->Area[$Item['expect_city']]['content'] : '').($Item['expect_dist'] ? '-'.$this->Area[$Item['expect_dist']]['content'] : '');
			$Item['sex_text'] = $this->Config['LangVar']['SexArray'][$Item['sex']];
			$Item['expect_month_wages_text'] = $this->Config['LangVar']['ExpectMonthWagesArray'][$Item['expect_month_wages']];
			$Item['education_text'] = $this->Config['LangVar']['EducationArray'][$Item['education']];
			$Item['experience_text'] = $this->Config['LangVar']['ExperienceArray'][$Item['experience']];
			$Item['expect_province_text'] = $Item['expect_province'] ? $this->Area[$Item['expect_province']]['content'].($Item['expect_city'] ? '-'.$this->Area[$Item['expect_city']]['content'] : '').($Item['expect_dist'] ? '-'.$this->Area[$Item['expect_dist']]['content'] : '') : $this->Config['LangVar']['Unlimited'];
			$Item['face'] = $Item['face'] ? $Item['face'] : ($Item['sex'] == 1 ? $this->Config['PluginVar']['ResumeFace1Path'] : $this->Config['PluginVar']['ResumeFace2Path']);
			$Item['down_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResumeSeeLog).' where rid = '.intval($Item['uid']));
			$Item['url'] = $this->Rewrite('view_resume',array('rid'=>$Item['uid']));

			//���ƶ�
			$PerfectField = array('full_name','sex','face','birth_year','age','education','experience','mobile','expect_job','expect_month_wages','expect_province','tag','content','work_experience_list','educational_experience_list');
			$I = 0;
			foreach($PerfectField as $Key => $Val) {
				if(in_array($Val,array('work_experience_list','educational_experience_list'))){
					if($Item['param'][$Val]){
						$I++;
					}
				}else if($Item[$Val]){
					$I++;
				}
			}
			$Item['perfect'] = intval(100 / count($PerfectField) * $I);
			//���ƶ�End

		}
		return $Item;
	}

	/* ��Ƹ������ */
	public function GetViewFairthread($Id){
		$Item = DB::fetch_first('SELECT F.* FROM '.DB::table($this->TableFair).' F where F.id = '.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['param']['navs'] = array_filter(explode("\r\n",$Item['param']['navs']));
			$Item['param']['pop_nav'] = array_filter(explode("\r\n",$Item['param']['pop_nav']));
			$FictitiousArray = explode("|",$Item['param']['fictitious']);
			$Item['company_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableFairCompany).' where display = 1 and fid = '.intval($Item['id'])) + $FictitiousArray['0'];
			$Item['apply_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoApplyLog).' where fid = '.intval($Item['id'])) + $FictitiousArray['2'];
			$Item['click'] =  $Item['click'] + $FictitiousArray['3'];
			$Item['job_count'] =  $FictitiousArray['1'];
			foreach(DB::fetch_all('SELECT * FROM '.DB::table($this->TableFairCompany).' where display = 1 and fid = '.intval($Item['id']).' order by dateline desc,id desc') as $Key => $Val) {
				$Item['job_count'] += DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where display = 1 and payment_state = 1 and company_id = '.intval($Val['company_id']).($this->Config['PluginVar']['ExpiryTime'] ? ' and ( updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()).' or topdateline >= '.time().' ) ' : ''));
			}
		}
		return $Item;
	}

	/* ��Ѷ���� */
	public function GetViewArticlethread($Id){
		$Item = DB::fetch_first('SELECT A.*,C.title as class_title,COM.name as company_name FROM '.DB::table($this->TableArticle).' A LEFT JOIN `'.DB::table($this->TableArticleClass).'` C on C.id = A.classid LEFT JOIN `'.DB::table($this->TableCompany).'` COM on COM.id = A.company_id where A.id = '.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['content'] = stripslashes($Item['content']);
			$Item['prev'] = DB::fetch_first('SELECT A.* FROM '.DB::table($this->TableArticle).' A where A.classid = '.intval($Item['classid']).' and A.display = 1 and A.id < '.intval($Item['id']));
			$Item['next'] = DB::fetch_first('SELECT A.* FROM '.DB::table($this->TableArticle).' A where A.classid = '.intval($Item['classid']).' and A.display = 1 and A.id > '.intval($Item['id']));
			$Item['prev_html'] = $Item['prev'] ? '<a href="'.$this->Rewrite('view_article',array('aid'=>$Item['prev']['id'])).'" class="prev">'.$this->Config['LangVar']['Prev'].':<span>'.$Item['prev']['title'].'</span></a>' : '<a class="prev">'.$this->Config['LangVar']['Prev'].':<span>'.$this->Config['LangVar']['MeiYouLe'].'</span></a>';
			$Item['next_html'] = $Item['next'] ? '<a href="'.$this->Rewrite('view_article',array('aid'=>$Item['next']['id'])).'" class="next">'.$this->Config['LangVar']['Next'].':<span>'.$Item['next']['title'].'</span></a>' : '<a class="next">'.$this->Config['LangVar']['Next'].':<span>'.$this->Config['LangVar']['MeiYouLe'].'</span></a>';
		}

		return $Item;
	}

	//ְλ����
	public function GetInfoCount(){
		return DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' I where I.display = 1 and I.payment_state = 1 '.($this->Config['PluginVar']['ExpiryTime'] ? ' and ( I.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()).' or I.topdateline >= '.time().' ) ' : ''));//��������
	}

	//����ͳ��
	public function GetCount(){
		$Count = array();
		$FictitiousCount = explode("|",$this->Config['PluginVar']['IndexCountFictitious']);
		$Count['job'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' I where I.display = 1 and I.payment_state = 1 '.($this->Config['PluginVar']['ExpiryTime'] ? ' and ( I.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()).' or I.topdateline >= '.time().' ) ' : '')) + $FictitiousCount['1'];
		$Count['resume'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResume).' where display = 1') + $FictitiousCount['2'];
		$Count['company'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableCompany).' where display = 1') + $FictitiousCount['0'];
		$Count['click'] = ClickRoundNumber(DB::result_first('SELECT sum(click) FROM '.DB::table($this->TableInfo).' I where I.display = 1 and I.payment_state = 1') + DB::result_first('SELECT sum(click) FROM '.DB::table($this->TableResume).' where display = 1') + DB::result_first('SELECT sum(click) FROM '.DB::table($this->TableCompany).' where display = 1')  + $FictitiousCount['3']);
		return $Count;
	}

	//�����Ƽ�
	public function GetIndexCompanyHotList(){
		return $this->CompanyListFormat(DB::fetch_all("SELECT C.* FROM %t AS C,%t AS G where C.due_time >= ".time()." and C.vip_stop = 0 and G.company_id = C.id and G.hot = 1 and C.display = 1 order by C.updateline desc,C.id desc limit 0,".(!checkmobile() ? $this->Config['PluginVar']['PcHomeCompanyNum'] : $this->Config['PluginVar']['HomeCompanyNum']),array($this->TableCompany,$this->TableCompanyGroupLog)));
	}

	//��ҳ�б�
	public function GetAjaxIndexList($Get){
		$Get = StrToGBK($Get);
		$Results = array();

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Value = in_array($Get['value'],array(1,2)) ? $Get['value'] : 1; 

		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		if($Value == 1){//����ְλ
			$Where = ' and I.display = 1 and I.payment_state = 1 and I.hide = 1';
			$Order = 'I.updateline';
			if($this->Config['PluginVar']['ExpiryTime']){
				$Where .= ' and ( I.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()).' or I.topdateline >= '.time().' ) ';
			}
			
			$Where = preg_replace('/and/','where',$Where,1);
			$FetchSql = 'SELECT I.*,C.id as cid,C.mobile as c_mobile,C.name,C.content as c_content,C.param as c_param,C.due_time,C.vip_stop,C.logo,C.type as c_type,C.verify,G.ico FROM '.DB::table($this->TableInfo).' I LEFT JOIN `'.DB::table($this->TableCompany).'` C on C.id = I.company_id LEFT JOIN `'.DB::table($this->TableCompanyGroup).'` G on G.id = C.group_id '.$Where.' order by I.topdateline > '.time().' desc,'.$Order.' desc,I.dateline desc '.$Limit;
			$Results = $this->InfoListFormat(DB::fetch_all($FetchSql));

		}else if($Value == 2){//�����˲�

			$Where = ' and R.display = 1 and R.state in(1,3)';
			$Order = 'R.updateline';
			
			if($this->Config['PluginVar']['ResumeExpiryTime']){
				$Where .= ' and ( R.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ResumeExpiryTime'])." day",time()).' or R.topdateline >= '.time().' ) ';
			}

			if(!$this->Config['PluginVar']['ResumeListDownSwitch'] ){
				$UserResumeSeeLog = $this->GetUserResumeSeeLogArray();
				$Where .= $UserResumeSeeLog ? ' and R.uid not in('.implode(',',$UserResumeSeeLog).')' : '';
			}

			$Where = preg_replace('/and/','where',$Where,1);
			
			$FetchSql = 'SELECT R.* FROM '.DB::table($this->TableResume).' R '.$Where.' order by R.topdateline > '.time().' desc,'.$Order.' desc,R.dateline desc '.$Limit;
			$Results = $this->ResumeListFormat(DB::fetch_all($FetchSql));
		}

		return $Results;
	}

	/* ְλ�б� */
	public function GetAjaxList($Get){
		$Get = StrToGBK($Get);

		$Results = array();

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		
		$this->Config['PluginVar']['ListNum'] = $Get['limit'] ? $Get['limit'] : $this->Config['PluginVar']['ListNum'];
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];
		
		$Where = ' and I.display = 1 and I.payment_state = 1 and I.hide = 1';
		
		$Order = in_array($Get['order'],array('updateline','dateline')) ? 'I.'.$Get['order'] : 'I.updateline';
		
		if($this->Config['PluginVar']['ExpiryTime']){
			$Where .= ' and ( I.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()).' or I.topdateline >= '.time().' ) ';
		}

		if(in_array($Get['class'],array(1,2))){
			$Where .= ' and I.class = '.intval($Get['class']);
		}
		

		if($Get['keyword']){

			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);

			//��ѯ��˾
			$CompanyIds = array();
			foreach (DB::fetch_all('SELECT id FROM '.DB::table($this->TableCompany).' where display = 1 and name like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') order by id desc') as $Key => $Val) {
				$CompanyIds[] = $Val['id'];
			}
			if(array_filter($CompanyIds)){
				$Where .= ' and (I.company_id in('.implode(',',array_filter($CompanyIds)).') or I.title like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
			}else{
				$Where .= ' and I.title like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\')';
			}
			//��ѯ��˾
		}

		if($Get['province']){
			$Where .= ' and I.province = \''.addslashes(strip_tags($Get['province'])).'\'';
			if($Get['city']){
				$Where .= ' and I.city = \''.addslashes(strip_tags($Get['city'])).'\'';
				if($Get['dist']){
					$Where .= ' and I.dist = \''.addslashes(strip_tags($Get['dist'])).'\'';
				}
			}
		}

		if($Get['bbclassid']){
			$Where .= ' and I.bbclassid = \''.addslashes(strip_tags($Get['bbclassid'])).'\'';
			if($Get['bclassid']){
				$Where .= ' and I.bclassid = \''.addslashes(strip_tags($Get['bclassid'])).'\'';
				if($Get['classid']){
					$Where .= ' and I.classid = \''.addslashes(strip_tags($Get['classid'])).'\'';
				}
			}
		}

		if($Get['month_wages']){
			$Where .= ' and I.month_wages = '.intval($Get['month_wages']);
		}

		if($Get['experience']){
			$Where .= ' and I.experience = '.intval($Get['experience']);
		}

		if($Get['education']){
			$Where .= ' and I.education = '.intval($Get['education']);
		}
		
		if($Get['cycle']){
			$Where .= ' and I.cycle = '.intval($Get['cycle']);
		}

		if($Get['settlement']){
			$Where .= ' and I.settlement = '.intval($Get['settlement']);
		}

		if($Get['tag']){
			foreach (array_filter(explode(',',$Get['tag'])) as $Key => $Val) {
				$Where .= ' and FIND_IN_SET('.intval($Val).',I.tag)';
			}
		}

		if(in_array($Get['top'],array('0','1'))){
			$Where .= $Get['top'] ? ' and I.topdateline >= '.time() : ' and I.topdateline <= '.time();
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$FetchSql = 'SELECT I.*,C.id as cid,C.mobile as c_mobile,C.name,C.content as c_content,C.param as c_param,C.due_time,C.vip_stop,C.logo,C.type as c_type,C.verify,G.ico FROM '.DB::table($this->TableInfo).' I LEFT JOIN `'.DB::table($this->TableCompany).'` C on C.id = I.company_id LEFT JOIN `'.DB::table($this->TableCompanyGroup).'` G on G.id = C.group_id '.$Where.' order by I.topdateline > '.time().' desc,'.$Order.' desc,I.id desc '.$Limit;
		$Results = $this->InfoListFormat(DB::fetch_all($FetchSql),true);
		return $Results;
	}

	/* �˲��б� */
	public function GetAjaxListResume($Get){
		$Get = StrToGBK($Get);

		$Results = array();

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		
		$this->Config['PluginVar']['ListNum'] = $Get['limit'] ? $Get['limit'] : $this->Config['PluginVar']['ListNum'];
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];
		
		$Where = ' and R.display = 1 and state in(1,3)';
		
		$Order = 'R.updateline';

		if($this->Config['PluginVar']['ResumeExpiryTime']){
			$Where .= ' and ( R.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ResumeExpiryTime'])." day",time()).' or R.topdateline >= '.time().' ) ';
		}

		if(!$this->Config['PluginVar']['ResumeListDownSwitch'] ){
			$UserResumeSeeLog = $this->GetUserResumeSeeLogArray();
			$Where .= $UserResumeSeeLog ? ' and R.uid not in('.implode(',',$UserResumeSeeLog).')' : '';
		}
	
		if($Get['keyword']){

			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);
			$Where .= ' and (R.expect_job like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') or R.full_name like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
			
		}

		if($Get['province']){
			$Where .= ' and R.expect_province = \''.addslashes(strip_tags($Get['province'])).'\'';
			if($Get['city']){
				$Where .= ' and R.expect_city = \''.addslashes(strip_tags($Get['city'])).'\'';
				if($Get['dist']){
					$Where .= ' and R.expect_dist = \''.addslashes(strip_tags($Get['dist'])).'\'';
				}
			}
		}


		if($Get['expect_month_wages']){
			$Where .= ' and R.expect_month_wages = '.intval($Get['expect_month_wages']);
		}
		
		if($Get['education']){
			$Where .= ' and R.education = '.intval($Get['education']);
		}

		if($Get['experience']){
			$Where .= ' and R.experience = '.intval($Get['experience']);
		}

		if($Get['sex']){
			$Where .= ' and R.sex = '.intval($Get['sex']);
		}

		if($Get['min_age'] && $Get['max_age']){
			$Where .= ' and R.age >= '.intval($Get['min_age']).' and R.age <= '.intval($Get['max_age']);
		}else if($Get['min_age']){
			$Where .= ' and R.age >= '.intval($Get['min_age']);
		}else if($Get['max_age']){
			$Where .= ' and R.age <= '.intval($Get['max_age']);
		}

		if(in_array($Get['verify'],array('0','1'))){
			$Where .= ' and R.verify = '.intval($Get['verify']);
		}
			
		if($Get['classid']){
			$Where .= ' and FIND_IN_SET(\''.addslashes(strip_tags($Get['classid'])).'\',R.expect_job_classid)';
		}else if($Get['bclassid']){
			$Where .= ' and FIND_IN_SET(\''.addslashes(strip_tags($Get['bclassid'])).'\',R.expect_job_classid)';
		}else if($Get['bbclassid']){
			$Where .= ' and FIND_IN_SET(\''.addslashes(strip_tags($Get['bbclassid'])).'\',R.expect_job_classid)';
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$FetchSql = 'SELECT R.*FROM '.DB::table($this->TableResume).' R '.$Where.' order by R.topdateline > '.time().' desc,'.$Order.' desc,R.dateline desc '.$Limit;
		$Results = $this->ResumeListFormat(DB::fetch_all($FetchSql),true);
		return $Results;
	}

	/* ��˾�б� */
	public function GetAjaxListCompany($Get){
		$Get = StrToGBK($Get);

		$Results = array();

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];
		
		$Where = ' and C.display = 1';
		
		$Order = 'C.updateline';
	
		if($Get['keyword']){

			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);
			$Where .= ' and (C.name like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
			
		}

		if($Get['province']){
			$Where .= ' and C.province = \''.addslashes(strip_tags($Get['province'])).'\'';
			if($Get['city']){
				$Where .= ' and C.city = \''.addslashes(strip_tags($Get['city'])).'\'';
				if($Get['dist']){
					$Where .= ' and C.dist = \''.addslashes(strip_tags($Get['dist'])).'\'';
				}
			}
		}

		if($Get['scale']){
			$Where .= ' and C.scale = '.intval($Get['scale']);
		}
		
		if($Get['type']){
			$Where .= ' and C.type = '.intval($Get['type']);
		}

		if(in_array($Get['verify'],array('0','1'))){
			$Where .= ' and C.verify = '.intval($Get['verify']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$FetchSql = 'SELECT C.*,AG.title,AG.ico,AGL.day_refresh_count,AGL.day_info_count,AGL.info_count,AGL.resume_count,AGL.resume_day_count,AGL.examine,AGL.refresh_count,AGL.top_discount FROM '.DB::table($this->TableCompany).' C LEFT JOIN `'.DB::table($this->TableCompanyGroup).'` AG on AG.id = C.group_id LEFT JOIN `'.DB::table($this->TableCompanyGroupLog).'` AGL on AGL.company_id = C.id '.$Where.' order by (C.due_time > '.time().' and C.vip_stop = 0) desc,C.topdateline > '.time().' desc,'.$Order.' desc,C.dateline desc '.$Limit;
		$Results = $this->CompanyListFormat(DB::fetch_all($FetchSql),true);
		return $Results;
	}

	/* ��Ѷ�б� */
	public function GetAjaxArticleList($Get){
	
		$Results = array();

		$Get = EncodeURIToUrldeCode($Get);

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;

		$Where = '';

		if($Get['keyword']){
			$Get['keyword'] = str_replace(array('%','_'),array('',''),$Get['keyword']);
			$Where .= ' and ( A.title like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\') )';
		}

		if($Get['classid']){
			$Where .= ' and A.classid = '.intval($Get['classid']);
		}

		if($Get['no_id']){
			$Where .= ' and A.id not in('.intval($Get['no_id']).')';
		}

		if($Get['company_id']){
			$Where .= ' and A.company_id = '.intval($Get['company_id']);
		}

		if($Get['display']){
			$Where .= ' and A.display = '.intval($Get['display']);
		}

		if($Get['hot']){
			$Where .= ' and A.hot = '.intval($Get['hot']);
		}

		if($Get['slide']){
			$Where .= ' and A.slide = '.intval($Get['slide']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Get['limit'] = $Get['limit'] ? $Get['limit'] : 15;
		$Limit = ' LIMIT '.($Page * $Get['limit']).','.$Get['limit'];

		$Results = $this->ArticleListFormat(DB::fetch_all("SELECT A.*,C.title as class_title,COM.name as company_name FROM ".DB::table($this->TableArticle)." A LEFT JOIN `".DB::table($this->TableArticleClass)."` C on C.id = A.classid LEFT JOIN `".DB::table($this->TableCompany)."` COM on COM.id = A.company_id ".$Where." order by A.topdateline > ".time()." desc, A.updateline desc,A.id desc".$Limit));
		
		return $Results;
	}

	/* ��Ѷ���� */
	public function GetArticleClassList(){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableArticleClass).' where display = 1 order by displayorder asc',array(),'id');//��������
	}

	//����ְλ
	public function GetAjaxJobCompanyList($Get){
		$Get = EncodeURIToUrldeCode($Get);
		$Results = array();
		$Where = ' and I.display = 1 and I.payment_state = 1 and I.hide = 1';
		$Order = 'I.updateline';

		if($this->Config['PluginVar']['ExpiryTime']){
			$Where .= ' and ( I.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()).' or I.topdateline >= '.time().' ) ';
		}

		if($Get['company_id']){
			$Where .= ' and I.company_id = '.intval($Get['company_id']);
		}

		if($Get['no_id']){
			$Where .= ' and I.id != '.intval($Get['no_id']);
		}
		

		$Where = preg_replace('/and/','where',$Where,1);
		
		$FetchSql = 'SELECT I.*,C.mobile as c_mobile,C.name,C.content as c_content,C.param as c_param,C.due_time,C.vip_stop,C.logo,C.type as c_type,C.verify,G.ico FROM '.DB::table($this->TableInfo).' I LEFT JOIN `'.DB::table($this->TableCompany).'` C on C.id = I.company_id LEFT JOIN `'.DB::table($this->TableCompanyGroup).'` G on G.id = C.group_id '.$Where.' order by I.topdateline > '.time().' desc,'.$Order.' desc,I.dateline desc ';
		$Results = $this->InfoListFormat(DB::fetch_all($FetchSql));
		
		return $Results;
	}

	//����ְλ
	public function GetAjaxSimilarJobList($Get){
		$Get = EncodeURIToUrldeCode($Get);
		$Results = array();
		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		$Where = ' and I.display = 1 and I.payment_state = 1 and I.hide = 1';
		$Order = 'I.updateline';

		if($this->Config['PluginVar']['ExpiryTime']){
			$Where .= ' and ( I.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()).' or I.topdateline >= '.time().' ) ';
		}

		if($Get['class']){
			$Where .= ' and I.class = '.intval($Get['class']);
		}

		if($Get['bbclassid']){
			$Where .= ' and I.bbclassid = \''.addslashes(strip_tags($Get['bbclassid'])).'\'';
			if($Get['bclassid']){
				$Where .= ' and I.bclassid = \''.addslashes(strip_tags($Get['bclassid'])).'\'';
				if($Get['classid']){
					$Where .= ' and I.classid = \''.addslashes(strip_tags($Get['classid'])).'\'';
				}
			}
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$FetchSql = 'SELECT I.*,C.id as cid,C.mobile as c_mobile,C.name,C.content as c_content,C.param as c_param,C.due_time,C.vip_stop,C.logo,C.type as c_type,C.verify,G.ico FROM '.DB::table($this->TableInfo).' I LEFT JOIN `'.DB::table($this->TableCompany).'` C on C.id = I.company_id LEFT JOIN `'.DB::table($this->TableCompanyGroup).'` G on G.id = C.group_id '.$Where.' order by I.topdateline > '.time().' desc,'.$Order.' desc,I.dateline desc '.$Limit;
		$Results = $this->InfoListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}

	//ְλ�Ƽ�
	public function GetAjaxUserMatchingInfoList(){
		$UserInfo = $this->GetUserInfo();
		$Results = array();
		if($UserInfo['resume']){
			$Where = ' and I.display = 1 and I.payment_state = 1 and I.uid != '.$UserInfo['resume']['uid'];
			$Order = 'I.updateline';

			if($this->Config['PluginVar']['ExpiryTime']){
				$Where .= ' and ( I.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()).' or I.topdateline >= '.time().' ) ';
			}
			
			if($UserInfo['resume']['expect_job_classid']){
				$ExpectJobClassid = array();
				foreach(array_filter(explode(",",$UserInfo['resume']['expect_job_classid'])) as $Key => $Val) {
					$ExpectJobClassid[] = "'".$Val."'";
				}
				$Where .= ' and ( I.bbclassid in('.implode(',',$ExpectJobClassid).') or I.bclassid in('.implode(',',$ExpectJobClassid).') or I.classid in('.implode(',',$ExpectJobClassid).') ) ';
			}else{
				$Where .= ' and I.title like(\'%'.$UserInfo['resume']['expect_job'].'%\')';
			}
			
			$Where = preg_replace('/and/','where',$Where,1);

			$this->Config['PluginVar']['ListNum'] = 10;

			$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

			$FetchSql = 'SELECT I.*,C.mobile as c_mobile,C.name,C.content as c_content,C.param as c_param,C.due_time,C.vip_stop,C.logo,C.type as c_type,C.verify,G.ico FROM '.DB::table($this->TableInfo).' I LEFT JOIN `'.DB::table($this->TableCompany).'` C on C.uid = I.uid LEFT JOIN `'.DB::table($this->TableCompanyGroup).'` G on G.id = C.group_id '.$Where.' order by I.topdateline > '.time().' desc,'.$Order.' desc,I.dateline desc '.$Limit;

			$Results = $this->InfoListFormat(DB::fetch_all($FetchSql));
		
		}
		
		return $Results;
	}

	/* �б���ʽת�� */
	public function InfoListFormat($Array,$Click=false){
		global $_G;
		
		$UserInfoApplyLogArray = $this->Config['PluginVar']['ListApplySwitch'] ? $this->GetUserInfoApplyLogArray() : '';
		
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['url'] = $this->Rewrite('view_job',array('iid'=>$Val['id']));
			$Array[$Key]['company_url'] = $this->Rewrite('view_company',array('cid'=>$Val['cid']));
			$Array[$Key]['username'] = DeleteHtml($Val['username']);
			$Array[$Key]['title'] = DeleteHtml($Val['title']);
			$Array[$Key]['name'] = DeleteHtml($Val['name']);
			$Array[$Key]['display_text'] = $Val['display'] ? $this->Config['LangVar']['Display1'] : $this->Config['LangVar']['Display0'];
			$Array[$Key]['display_text'] = !$Val['hide'] ? $this->Config['LangVar']['HideIn'] : $Array[$Key]['display_text'];
			$Array[$Key]['overdue_text'] = $this->Config['PluginVar']['ExpiryTime'] && $Val['updateline'] < strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()) && $Val['topdateline'] < time() ? $this->Config['LangVar']['BeOverdueTips'] : '';
			$Array[$Key]['pc_class'] = $Val['class'];
			$Array[$Key]['class_text'] = $this->Config['LangVar']['ClassArray'][$Val['class']];
			$Array[$Key]['classid_text'] = $this->ClassList[$Val['bbclassid']]['content'].($Val['bclassid'] ? '-'.$this->ClassList[$Val['bclassid']]['content'] : '').($Val['classid'] ? '-'.$this->ClassList[$Val['classid']]['content'] : '');
			$Array[$Key]['classid_min_text'] = $this->ClassList[$Val['classid']]['content'].(!$Val['classid'] ? $this->ClassList[$Val['bclassid']]['content'] : '').(!$Val['bclassid'] ? $this->ClassList[$Val['bbclassid']]['content'] : '');
			$Array[$Key]['param']['tag_list'] = $Val['param']['tag_list'] ? $Val['param']['tag_list'] : '';
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['dateline'] = $Val['updateline'] ? FormatDate($Val['dateline'],'Y-m-d') : '';
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d') : '';
			$Array[$Key]['settlement_text'] = $this->Config['LangVar']['SettlementArray'][$Val['settlement']];
			$Array[$Key]['cycle_text'] = $this->Config['LangVar']['CycleArray'][$Val['cycle']] ;
			$Array[$Key]['education_text'] = $Val['education'] ? $this->Config['LangVar']['EducationArray'][$Val['education']] : $this->Config['LangVar']['EducationSamll'].' '.$this->Config['LangVar']['Unlimited'];
			$Array[$Key]['experience_text'] = $Val['experience'] ? $this->Config['LangVar']['ExperienceArray'][$Val['experience']] : $this->Config['LangVar']['ExperienceSamll'].' '.$this->Config['LangVar']['Unlimited'];
			$Array[$Key]['refresh'] = $this->Config['PluginVar']['RefreshMoney'] ? 1 : 0;
			$Array[$Key]['province_text'] = $this->Area[$Val['province']]['content'].($Val['city'] ? '-'.$this->Area[$Val['city']]['content'] : '').($Val['dist'] ? '-'.$this->Area[$Val['dist']]['content'] : '');
			$Array[$Key]['contents'] = $Val['content']; 
			$Array[$Key]['content'] = cutstr(DeleteHtml($Val['content']),90); 
			if($Val['class'] == 1){
				$Array[$Key]['month_wages_text'] = $Val['month_wages'] ? $this->Config['LangVar']['MonthWagesArray'][$Val['month_wages']] : $this->Config['LangVar']['Interview'];
			}else if($Val['class'] == 2){
				$Array[$Key]['month_wages_text'] = $Val['month_wages'].$this->Config['LangVar']['MonthWagesTypeArray'][$Val['month_wages_type']];
			}

			$Array[$Key]['matching_count'] = in_array($_GET['m'],array('user_info_list')) ? $this->GetAjaxUserResumeMatchingList(array('iid'=>$Val['id']),true) : 0;

			$Array[$Key]['apply_log'] = in_array($Val['id'],$UserInfoApplyLogArray) ? 1 : 0;
			$Array[$Key]['apply_log_btn'] = $Array[$Key]['apply_log'] ? $this->Config['LangVar']['IsApplicationPositionTo'] : $this->Config['LangVar']['ApplicationPosition'];
			$Array[$Key]['mobile'] = $Val['mobile'] ? $Val['mobile'] : $Val['c_mobile'];
			//��˾
			$Val['c_param'] = unserialize($Val['c_param']);
			$Array[$Key]['c_param'] = $Val['c_param'];
			$Array[$Key]['c_param']['album'] = $Val['c_param']['album'] ? $Val['c_param']['album'] : '';
			$Array[$Key]['vip'] = $Val['due_time'] > time() && !$Val['vip_stop'] ? 1 : '';
			$Array[$Key]['logo'] = $Val['logo'] ? $Val['logo'] : $this->Config['PluginVar']['CompanyLogoPath'];
			$Array[$Key]['c_content'] = cutstr(DeleteHtml($Val['c_content']),44);
			$Array[$Key]['type_text'] = $this->Config['LangVar']['CompanyTypeArray'][$Val['c_type']];
			
			
			if($Click){
				Click($this->TableInfo,$Val['id']);
			}
			
		}
		return $Array;
	}

	/* �����б���ʽת�� */
	public function ResumeListFormat($Array,$Click=false){
		global $_G;
		$UserInfo = $_G['uid'] ? $this->GetUserInfo() : array();
		foreach ($Array as $Key => $Val) {
			$InfoApplyLog = $this->Config['PluginVar']['ResumeJobNameSwitch'] && !$this->Config['PluginVar']['ResumeNameSwitch'] ? $this->GetUserInfoApplyLogState($Val['uid'],$UserInfo['company']['id']) : '';
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['url'] = $this->Rewrite('view_resume',array('rid'=>$Val['uid']));
			$Array[$Key]['username'] = DeleteHtml($Val['username']);
			$Array[$Key]['param']['tag_list'] = $Val['param']['tag_list'] ? $Val['param']['tag_list'] : '';
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['new'] = $this->Config['PluginVar']['ResumeListNewTag'] && $Val['dateline'] > strtotime("-".intval($this->Config['PluginVar']['ResumeListNewTagTime'])." hours",time()) ? 1 : 0;
			$Array[$Key]['sign_text'] = $Val['sign'] ? $this->Config['LangVar']['ResumeSignList'][$Val['sign']] : '';
			$Array[$Key]['sex_text'] = $this->Config['LangVar']['SexArray'][$Val['sex']];
			$Array[$Key]['expect_month_wages_text'] = $this->Config['LangVar']['ExpectMonthWagesArray'][$Val['expect_month_wages']];
			$Array[$Key]['education_text'] = $this->Config['LangVar']['EducationArray'][$Val['education']];
			$Array[$Key]['experience_text'] = $this->Config['LangVar']['ExperienceArray'][$Val['experience']];
			$Array[$Key]['expect_province_text'] = $Val['expect_province'] ? $this->Area[$Val['expect_province']]['content'].($Val['expect_city'] ? '-'.$this->Area[$Val['expect_city']]['content'] : '').($Val['expect_dist'] ? '-'.$this->Area[$Val['expect_dist']]['content'] : '') : $this->Config['LangVar']['Unlimited'];
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d') : '';
			$Array[$Key]['apply_dateline'] = $Val['apply_dateline'] ? FormatDate($Val['apply_dateline'],'Y-m-d') : '';
			$Array[$Key]['updateline'] = $Val['see_dateline'] ? FormatDate($Val['see_dateline'],'Y-m-d') : $Array[$Key]['updateline'];
			$Array[$Key]['interview_dateline'] = $Val['interview_dateline'] ? date('Y-m-d H:i',$Val['interview_dateline']) : '';
			$Array[$Key]['see'] = $Val['see'] ? $Val['see'] : '';
			$Array[$Key]['alid'] = $Val['alid'] ? $Val['alid'] : '';
			$Array[$Key]['iid'] = $Val['iid'] ? $Val['iid'] : '';
			$Array[$Key]['info_title'] = $Val['info_title'] ? $Val['info_title'] : '';
			$Array[$Key]['content'] = cutstr(DeleteHtml($Val['content']),50);
			$Array[$Key]['full_name_to'] = $Val['full_name'];
			$Array[$Key]['full_name'] = $this->Config['PluginVar']['ResumeNameSwitch'] || $InfoApplyLog ? $Val['full_name'] : cutstr($Val['full_name'],3,'').$this->Config['LangVar']['SexToArray'][$Val['sex']];
			$Array[$Key]['face'] = $Val['face'] ? $Val['face'] : ($Val['sex'] == 1 ? $this->Config['PluginVar']['ResumeFace1Path'] : $this->Config['PluginVar']['ResumeFace2Path']);
			if($Click){
				Click($this->TableResume,$Val['uid'],1,'uid');
			}
			
		}
		return $Array;
	}

	/* ��˾�б���ʽת�� */
	public function CompanyListFormat($Array,$Click=false,$infoLimit=2){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['url'] = $this->Rewrite('view_company',array('cid'=>$Val['id']));
			$Array[$Key]['username'] = $Val['username'];
			$Array[$Key]['name'] = $Val['name'];
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['vip'] = $Val['due_time'] > time() && !$Val['vip_stop'] ? 1 : '';
			$Array[$Key]['logo'] = $Val['logo'] ? $Val['logo'] : $this->Config['PluginVar']['CompanyLogoPath'];
			$Array[$Key]['expect_month_wages_text'] = $this->Config['LangVar']['ExpectMonthWagesArray'][$Val['expect_month_wages']];
			$Array[$Key]['type_text'] = $this->Config['LangVar']['CompanyTypeArray'][$Val['type']];
			$Array[$Key]['scale_text'] = $this->Config['LangVar']['ScaleArray'][$Val['scale']];
			$Array[$Key]['class_text'] = $this->Config['LangVar']['CompanyClassArray'][$Val['classid']];
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d') : '';
			$Array[$Key]['province_text'] = $this->Area[$Val['province']]['content'].($Val['city'] ? '-'.$this->Area[$Val['city']]['content'] : '').($Val['dist'] ? '-'.$this->Area[$Val['dist']]['content'] : '');	$Array[$Key]['info_count'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where display = 1 and payment_state = 1  and hide = 1 and company_id = '.intval($Val['id']).($this->Config['PluginVar']['ExpiryTime'] ? ' and ( updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()).' or topdateline >= '.time().' ) ' : ''));
			$Array[$Key]['info_count_text'] = str_replace(array('{count}'),array($Array[$Key]['info_count']),$this->Config['LangVar']['CompanyCountTips']);
			$Array[$Key]['info_list'] = $this->InfoListFormat(DB::fetch_all('SELECT * FROM '.DB::table($this->TableInfo).' where display = 1 and payment_state = 1 and hide = 1 and company_id = '.intval($Val['id']).($this->Config['PluginVar']['ExpiryTime'] ? ' and ( updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()).' or topdateline >= '.time().' ) ' : '').' order by topdateline > '.time().' desc,updateline desc,dateline desc limit '.intval($infoLimit)));
			$Array[$Key]['content'] = cutstr(DeleteHtml($Val['content']),30);
			$Array[$Key]['interview_dateline'] = $Val['interview_dateline'] ? date('Y-m-d H:i',$Val['interview_dateline']) : '';
			$Array[$Key]['i_updateline'] = $Val['i_updateline'] ? date('Y-m-d H:i',$Val['i_updateline']) : '';
			$ApplyInfoResume = $this->Config['PluginVar']['JobApplySwitch']  ? $this->GetUserInfoApplyLogState($_G['uid'],$Val['id']) : false;
			$Array[$Key]['apply_info_resume'] = $ApplyInfoResume ? 1 : 0;

			if($Click){
				Click($this->TableCompany,$Val['id']);
			}
			
		}
		return $Array;
	}

	/* ��Ѷ�б���ʽת�� */
	public function ArticleListFormat($Array){
		global $_G;
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['url'] = !$Val['jump'] ? $this->Rewrite('view_article',array('aid'=>$Val['id'])) : $Val['jump_link'];
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['username'] = DeleteHtml($Val['username']); 
			$Array[$Key]['describe'] = $Val['describe'] ? DeleteHtml($Val['describe']) : cutstr(DeleteHtml($Val['content']),180);
			$Array[$Key]['content'] = '';
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['dateline'] = date('Y-m-d',$Val['dateline']);
			$Array[$Key]['updateline'] = date('Y-m-d',$Val['updateline']);
			$Array[$Key]['thumbnail'] = $Val['thumbnail'] ? $Val['thumbnail'] : $this->Config['PluginVar']['ArticleCoverPath'];
		}
		return $Array;
	}

	//������Ϣ 
	public function GetAjaxPublish($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		if($this->Admin){
			$Item = $this->GetViewthread($Get['iid']);
		}else{
			$Item = $this->GetViewthread($Get['iid'],' and I.uid = '.$_G['uid']);
		}
		$UserInfo = $this->GetUserInfo();
		$UpData['company_id'] = $Item['company_id'] ? $Item['company_id'] : $UserInfo['company']['id'];
		$UpData['uid'] = $Item['uid'] ? $Item['uid'] : intval($_G['uid']);
		$UpData['username'] =  $Item['username'] ? $Item['username'] : addslashes(strip_tags($_G['username']));
		$UpData['title'] = censor(addslashes(strip_tags($Get['title'])));
		$UpData['class'] = intval($Get['class']);
		$UpData['bbclassid'] = addslashes(strip_tags($Get['bbclassid']));
		$UpData['bclassid'] = addslashes(strip_tags($Get['bclassid']));
		$UpData['classid'] = addslashes(strip_tags($Get['classid']));
		if(!$Item){
			$UpData['province'] = $CompanyData['province'] = $UserInfo['company']['province'] ? $UserInfo['company']['province'] : addslashes(strip_tags($Get['province']));
			$UpData['city'] = $CompanyData['city'] = $UserInfo['company']['city'] ? $UserInfo['company']['city'] : addslashes(strip_tags($Get['city']));
			$UpData['dist'] = $CompanyData['dist'] = $UserInfo['company']['dist'] ? $UserInfo['company']['dist'] : addslashes(strip_tags($Get['dist']));
			$UpData['community'] = $CompanyData['community'] = $UserInfo['company']['community'] ? $UserInfo['company']['community'] : censor(addslashes(strip_tags($Get['company_community'])));
			$UpData['lat'] = $CompanyData['lat'] = $UserInfo['company']['lat'] ? $UserInfo['company']['lat'] :  addslashes(strip_tags($Get['lat']));
			$UpData['lng'] = $CompanyData['lng'] = $UserInfo['company']['lng'] ? $UserInfo['company']['lng'] :  addslashes(strip_tags($Get['lng']));
		}
		$UpData['month_wages'] = $Get['interview'] ? '' : intval($Get['month_wages']);
		$UpData['month_wages_type'] = intval($Get['month_wages_type']);
		$UpData['settlement'] = intval($Get['settlement']);
		$UpData['cycle'] = intval($Get['cycle']);
		$UpData['number'] = intval($Get['number']);
		$UpData['education'] = intval($Get['education']);
		$UpData['experience'] = intval($Get['experience']);
		$UpData['content'] = censor(addslashes(str_replace("\r\n","<br>",$Get['content'])));
		$UpData['tag'] = $CompanyData['tag'] = censor(addslashes(strip_tags($Get['tag'])));
		$UpData['mobile'] = $CompanyData['mobile'] = trim(addslashes(strip_tags($Get['mobile'])));
		if($UpData['class'] == 2){
			$UpData['display'] = $this->Config['PluginVar']['InfoAddSwitch2'] ? 0 : 1;
		}else{
			$UpData['display'] = $this->Config['PluginVar']['InfoAddSwitch'] ? 0 : 1;
		}

		if($UpData['tag']){
			foreach(array_filter(explode(",",$UpData['tag'])) as $Key => $Val) {
				if($this->Config['LangVar']['WelfareArray'][$Val]){
					$Param['tag_list'][] = $CompanyParam['tag_list'][] = $this->Config['LangVar']['WelfareArray'][$Val];
				}
			}
		}
		if($UserInfo['company']['vip'] && !$Item){//��˾�ײ��ж�

			/*if($UserInfo['company']['day_info_count']){//ÿ�շ�������
				$InfoDayCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and uid = '.intval($_G['uid']).' and dateline >= '.strtotime(date('Y-m-d',time())).' and dateline <= '.strtotime(date('Y-m-d 23:59:59',time())));
				if($InfoDayCount >= $UserInfo['company']['day_info_count']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['InfoDayCountErr']);
					return $Data;
				}
			}*/

			if($UserInfo['company']['info_count']){//����������
		
				$InfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_type = 2 and payment_state = 1 and company_id = '.intval($UserInfo['company']['id']));
				if($InfoCount >= $UserInfo['company']['info_count']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['InfoCountErr']);
					return $Data;
				}
			}

			$UpData['display'] = $UserInfo['company']['examine'] ? 1 : 0;
			$UpData['payment_type'] = 2;

		}else if($this->Config['PluginVar']['PersonalAddNum']){//������������
			$InfoCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where payment_state = 1 and '.($UserInfo['company']['id'] ? 'company_id = '.intval($UserInfo['company']['id']) : 'uid = '.intval($_G['uid'])));
			if($InfoCount >= $this->Config['PluginVar']['PersonalAddNum'] && !$Item){
				$Data['State'] = 202;
				$Data['Msg'] = urlencode(str_replace('{Num}',$this->Config['PluginVar']['PersonalAddNum'],$this->Config['LangVar']['PersonalAddNumErr']));
				return $Data;
			}
				
		}

		if(!$UpData['bbclassid']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['JobCategoryPlaceholder']);
			return $Data;
		}

		if($UpData['class'] == 1){
			if(!$UpData['month_wages'] && !$Get['interview']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['MonthWagesPlaceholder']);
				return $Data;
			}

			if(!$UpData['number'] && $this->Config['PluginVar']['NumberSwitch'] && $this->Config['PluginVar']['NumberMustSwitch']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['NeedNumberTips']);
				return $Data;
			}

		}else if($UpData['class'] == 2){
			if(!$UpData['month_wages']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['JobMonthWagesPlaceholder']);
				return $Data;
			}

			if(!$UpData['settlement']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['SettlementPlaceholder']);
				return $Data;
			}
		}
		
		if(!$UpData['title']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RecruitTitleErr']);
			return $Data;
		}

		if(!$UpData['content']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['PositionContentErr']);
			return $Data;
		}

		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		$IsLandline = "/".$Config['PluginVar']['LandlineMatch']."/";
		if(!$UpData['mobile']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactNumberPlaceholder']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['mobile']) && !preg_match($IsLandline,$UpData['mobile'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
			return $Data;
		}

		//��֤���ж�
		if($this->Config['PluginVar']['CompanyMobileSwitch']){
			if(($UserInfo['company'] && $UpData['mobile'] != $UserInfo['company']['mobile']) || ($UserInfo['company'] && !$UserInfo['mobile_verify']) || (!$UserInfo['company'])){
				if(!$Get['code']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['CodePlaceholder']);
					if($UserInfo['company'] && $UpData['mobile'] != $UserInfo['company']['mobile']){
						$Data['State'] = 203;
					}
					return $Data;
				}
				$CheckSendSmsLog = DB::fetch_first('SELECT * FROM '.DB::table('fn_send_sms_log').' where state = 200 and cache_dateline > '.time().' and uid = '.intval($_G['uid']).' and mobile = '.$UpData['mobile'].' and code = '.$Get['code'].' and sms_type = 1 order by id desc');
				if(!$CheckSendSmsLog){
					$Data['Msg'] = urlencode($this->Config['LangVar']['CodeErr']);
					return $Data;
				}
				$CompanyData['mobile_verify'] = 1;
				$CompanyData['mobile'] = $UpData['mobile'];
			}
		}
		//��֤���ж� End

		
		if(!$UserInfo['company'] && !$this->Admin){//��ҵ���
			foreach(array_filter(explode(';',$Get['new_logo'][0])) as $Key => $Val) {
				$Get['new_logo'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
			}
			foreach(array_filter(explode(';',$Get['new_license'][0])) as $Key => $Val) {
				$Get['new_license'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
			}
			foreach(array_filter(explode(';',$Get['new_album'][0])) as $Key => $Val) {
				$Get['new_album'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
			}
			
			$CompanyData['logo'] = $Get['new_logo'][0];
			$CompanyData['scale'] = intval($Get['scale']);
			$CompanyData['classid'] = intval($Get['company_classid']);
			$CompanyData['sms_mobile'] = addslashes(strip_tags($Get['sms_mobile']));
			$CompanyParam['license'] = $Get['new_license'][0];
			$CompanyParam['album'] = is_array($Get['new_album']) && isset($Get['new_album']) ? $Get['new_album'] : '';
			
			if(!$CompanyData['sms_mobile'] && $this->Config['PluginVar']['PublishSmsMobileSwitch']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['ShortMessageTelTips']);
				return $Data;
			}else if(!preg_match($IsMob,$CompanyData['sms_mobile']) && $this->Config['PluginVar']['PublishSmsMobileSwitch']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
				return $Data;
			}
		
			if(!$CompanyData['logo'] && $this->Config['PluginVar']['PublishLogoSwitch'] && $this->Config['PluginVar']['PublishLogoFillSwitch']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['UploadLogoTips']);
				return $Data;
			}

			if(!$CompanyParam['license'] && $this->Config['PluginVar']['PublishLicenseSwitch'] && $this->Config['PluginVar']['PublishLicenseFillSwitch']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['UploadLicenseTips']);
				return $Data;
			}

			if(!$CompanyParam['album'] && $this->Config['PluginVar']['PublishAlbumSwitch'] && $this->Config['PluginVar']['PublishAlbumFillSwitch']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['UploadHuanJingTips']);
				return $Data;
			}

			if(!$Get['company_name']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyNameErr']);
				return $Data;
			}else if(!$UserInfo['company']['name_verify'] && $this->Config['PluginVar']['CompanyNameSwitch'] && $Get['company_name']){
			
				$headers = array();
				array_push($headers, "Authorization:APPCODE " . $this->Config['PluginVar']['ApiAppCode']);
				
				$url = 'https://bankpros.market.alicloudapi.com/comdata';

				$Res = json_decode(CurlPost($url,array('com'=>diconv($Get['company_name'],CHARSET,'UTF-8')),$headers),true);
				
				if($Res['error_code'] !== 0){
					$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyNameErr2']);
					return $Data;
				}else{
					$CompanyData['name_verify'] = 1;
				}
			}

			if(!$CompanyData['scale'] && $this->Config['PluginVar']['PublishScaleSwitch']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['ScalePlaceholder']);
				return $Data;
			}

			if(!$CompanyData['classid'] && $this->Config['PluginVar']['PublishCompanyClassSwitch'] && $this->Config['PluginVar']['PublishCompanyClassFillSwitch']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyClassPlaceholder']);
				return $Data;
			}

			if(!$Get['province']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['RegionPlaceholder']);
				return $Data;
			}

			if(!$Get['lat'] && !$Get['lng'] && $this->Config['PluginVar']['PublishMapSwitch']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['TaggingTips']);
				return $Data;
			}

			if(!$Get['company_community']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyCommunityPlaceholder']);
				return $Data;
			}
			$CompanyData['uid'] = intval($_G['uid']);
			$CompanyData['username'] = addslashes(strip_tags($_G['username']));
			$CompanyData['name'] = censor(addslashes(strip_tags($Get['company_name'])));
			$CompanyData['type'] = intval($Get['company_type']);
			$CompanyData['display'] = $this->Config['PluginVar']['PublishCompanyDisplay'] ? 1 : 0;
			$CompanyData['dateline'] = $CompanyData['updateline'] = time();
			$CompanyData['param'] = serialize($CompanyParam);

			$UpData['company_id'] = DB::insert($this->TableCompany,$CompanyData,true);

			if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_crm')){
				@require_once (DISCUZ_ROOT.'./source/plugin/fn_crm/Function.inc.php');
				if(!DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where project = \'fn_job\' and  project_id = '.$UpData['company_id'])){
					DB::insert($Fn_Crm->TableCustomer,array('name'=>$CompanyData['name'],'project'=>'fn_job','project_id'=>$UpData['company_id'],'decision_mobile'=>$CompanyData['mobile'],'dateline'=>time()));
				}
			}
		}else if($this->Config['PluginVar']['CompanyMobileSwitch'] && $UserInfo['company'] && $CompanyData['mobile_verify']){
			DB::update($this->TableCompany,$CompanyData,'id = '.intval($UserInfo['company']['id']));
		}

		$UpData['param'] = serialize($Param);

		!$UserInfo['uid'] ? DB::insert($this->TableMember,array('uid'=>$UpData['uid'],'username'=>$UpData['username'],'identity'=>1,'dateline'=>time(),'updateline'=>time())) : '';//���ݱ�ʶ
		
		$Money = $this->Config['PluginVar']['PublishMoney'];
		$AppMoney = $this->Config['PluginVar']['AppPublishMoney'];
		$Money = AppYes && App ? $AppMoney : $Money;
		if($Item){//����
			$UpData['edit_dateline'] = time();
			$UpData['display'] = $this->Config['PluginVar']['InfoEditSwitch'] && !$this->Admin ? 0 : $Item['display'];
			$UpData['payment_state'] = $Item['payment_state'];
			if(DB::update($this->TableInfo,$UpData,'id = '.intval($Item['id']))){
				$Data['Id'] = $Item['id'];
				$Data['Url'] = $this->Config['ViewJobUrl'].$Item['id'];
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));
				if((($Money && !$this->Admin && !$UserInfo['company']['vip']) || ($Get['top'] && !$this->Admin)) && !$Item['payment_state']){
					if($Get['top']){
						$TopArray = array_filter(explode("|",$Get['top']));
						$Money = $UserInfo['company']['vip'] && $UserInfo['company']['top_discount'] ? $TopArray[1] * ($UserInfo['company']['top_discount'] / 10) : $TopArray[1];
						$PayLog = $this->GetAjaxPayLog(array('event'=>'top_info','money'=>$Money,'day'=>$TopArray[0],'iid'=>$Item['id']));
					}else{
						$Money = $AppMoney && App ? $AppMoney : $Money;
						$PayLog = $this->GetAjaxPayLog(array('money'=>$Money,'event'=>'publish_info','iid'=>$Item['id']));
					}
						
					$Data['Money'] = $Money;
					$Data['PayId'] = $PayLog['Id'];
					$Data['State'] = 201;
				}else{
					$Data['State'] = 200;
				}
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
		}else{//���
			if(($Money && !$this->Admin && !$UserInfo['company']['vip']) || ($Get['top'] && !$this->Admin)){
				$Money = $AppMoney && App ? $AppMoney : $Money;
				$UpData['payment_state'] = 0;
			}else{
				$UpData['payment_state'] = 1;
			}
			$UpData['dateline'] = $UpData['updateline'] = time();

			$InfoId = DB::insert($this->TableInfo,$UpData,true);
			if($InfoId){
	
				$Data['Id'] = $InfoId;
				$Data['Url'] = $this->Config['ViewJobUrl'].$InfoId;
				$Data['Msg'] = urlencode($this->Config['LangVar']['PublishSuccess'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));

				$TopArray = array_filter(explode("|",$Get['top']));
				$TopMoney = $UserInfo['company']['vip'] && $UserInfo['company']['top_discount'] ? $TopArray[1] * ($UserInfo['company']['top_discount'] / 10) : $TopArray[1];
	
				if($Get['top'] && $UserInfo['company']['vip'] && $UserInfo['company']['money'] >= intval($TopMoney) && $this->InsertCompanyWalletLog($UserInfo['company']['id'],$TopMoney,$this->Config['LangVar']['CompanyWalletBalanceTypeArray']['2'].$InfoId)){
					$UpData['display'] = 1;
					$UpData['payment_state'] = 1;
					$UpData['topdateline'] = strtotime("+".intval($TopArray[0])." day",time());
					DB::update($this->TableInfo,$UpData,' id = '.intval($InfoId));
					DB::query("UPDATE ".DB::table($this->TableCompany)." SET money = money - ".intval($TopMoney)." WHERE id = ".intval($UserInfo['company']['id']));
					$Data['State'] = 200;
					$this->GetCompanyFollowPush($InfoId);
				}else if(($Money && !$this->Admin && !$UserInfo['company']['vip']) || ($Get['top'] && !$this->Admin)){
					if($Get['top']){
						$Money = $TopMoney;
						$PayLog = $this->GetAjaxPayLog(array('event'=>'top_info','money'=>$Money,'day'=>$TopArray[0],'iid'=>$InfoId));
					}else{
						$PayLog = $this->GetAjaxPayLog(array('money'=>$Money,'event'=>'publish_info','iid'=>$InfoId));
					}
					$Data['Money'] = $Money;
					$Data['PayId'] = $PayLog['Id'];
					$Data['State'] = 201;
				}else{
					DB::update($this->TableCompany,array('display'=>1),'uid = '.intval($_G['uid']));
					$Data['State'] = 200;
					$this->GetCompanyFollowPush($InfoId);
				}
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['PublishFail']);
			}
		}

		//��Ϣ֪ͨ
		if(!$UpData['display'] && $UpData['payment_state']){
			foreach($this->AdminUidsList as $Key => $Val) {
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$this->Config['ViewJobUrl'].$Data['Id'],
						'msg'=>str_replace(array('{Title}'),array($UpData['title']),$this->Config['LangVar']['InfoPush'])
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['ViewJobUrl'].$Data['Id'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv(str_replace(array('{Title}'),array($UpData['title']),$this->Config['LangVar']['InfoPush']),CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}
			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv(str_replace(array('{Title}'),array($UpData['title']),$this->Config['LangVar']['InfoPush']),CHARSET,'UTF-8'),
					'url'=>$this->Config['ViewJobUrl'].$Data['Id']
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
		}
		//��Ϣ֪ͨEnd
		return $Data;
	}

	/* ƥ���ע��ְλ���� */
	public function GetCompanyFollowPush($iid){
		global $_G,$Config;
		$Item = $this->GetViewthread($iid);
		$ClassId = $Item['classid'] ? $Item['classid'] : ($Item['bclassid'] ? $Item['bclassid'] : $Item['bbclassid']);
		$Where .= ' where (R.expect_job like(\'%'.$this->ClassList[$ClassId]['content'].'%\') or FIND_IN_SET(\''.$ClassId.'\',R.expect_job_classid)) ';
		$Limit = 'LIMIT 0,1000';
		$uids = array();
		foreach(DB::fetch_all("SELECT R.* FROM ".DB::table($this->TableCompanyFollow)." AS CF,".DB::table($this->TableResume)." AS R ".$Where." and CF.company_id = ".intval($Item['company_id'])." and CF.rid = R.uid order by CF.dateline desc") as $Val) {
			$uids[] = $Val['uid'];
			$NoticeMsg = str_replace(array('{classid_min_text}','{company_name}'),array($Item['classid_min_text'],$Item['company']['name']),$this->Config['LangVar']['CompanyFollowPushInfo']);
			$PushUrl = $this->Config['ViewJobUrl'].$iid;
			$WxUserInfo = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where uid = '.intval($Val['uid']));
			if($this->Config['PluginVar']['NoticeTemplate'] && $WxUserInfo['openid']){//ģ����Ϣ֪ͨ
				$TemplateParam = array(
					'touser' => $WxUserInfo['openid'],
					'template_id' => $this->Config['PluginVar']['NoticeTemplate'],
					'url' => $PushUrl,
					'topcolor' => '#ff0000',
					'data' =>array(
						'first'=>array('value'=>diconv($NoticeMsg, CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['Color']),
						'keyword1'=>array('value'=>diconv($this->Config['PluginVar']['Title'], CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['FFColor']),
						'keyword2'=>array('value'=>date('Y-m-d H:i',time()),'color'=>$this->Config['PluginVar']['FColor']),
						'remark'=>array('value'=>'')
					)
				);
				@require_once libfile('class/wechat','plugin/fn_assembly');
				$WechatClient = new Fn_WeChatClient($this->Config['PluginVar']['WxAppid'],$this->Config['PluginVar']['WxSecret']);
				$WechatClient->send_weixintemplate(json_encode($TemplateParam));
			}else{
				if(DzNotice){
					notification_add($Val['uid'],'system','<a href="{url}">{msg}</a>',array(
						'url'=>$PushUrl,
						'msg'=>$NoticeMsg
					),1);//ϵͳ֪ͨ
				}
			}
					
			if($Config['PluginVar']['AppType'] == 1){//������������
				$PushData['Uid'] = $Val['uid'];
				$PushData['Type'] = 'pictemp';
				$PushData['Content'] = array(
					"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
					"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
					"link"=> $PushUrl,
					"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
					"extra_info"=>array(
						array(
							"key"=>'',
							"val"=>diconv($NoticeMsg,CHARSET,'UTF-8')
						)
					)
				);
				$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
			}
		}

		if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
			$PushData['Uid'] = implode(',',$uids);
			$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8');
			$PushData['Content'] = array(
				'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
				'date'=>date('Y-m-d H:i:s'),
				'setting'=>array(),
				'content' => diconv($NoticeMsg,CHARSET,'UTF-8'),
				'url'=>$PushUrl
			);
			$this->QHApp->GetMessagesTemplate($PushData);
		}
	}

	/* ����ʱ������ */
	public function GetExpiryPushInfo(){
		global $Config;
		if($this->Config['PluginVar']['ExpiryTime'] && $this->Config['PluginVar']['ExpiryTimeSwitch'] && date('H',time()) >= 9 && date('H',time()) <= 22){
			foreach($this->InfoListFormat(DB::fetch_all('SELECT I.* FROM '.DB::table($this->TableInfo).' I where I.display = 1 and I.payment_state = 1 and I.hide = 1 and I.expiry_push != 1 and I.topdateline < '.time().' and I.updateline < '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()).' order by I.id desc ')) as $Val) {
				//��Ϣ֪ͨ
				$NoticeMsg = str_replace(array('{classid_min_text}'),array($Val['classid_min_text']),$this->Config['LangVar']['ExpiryPushInfo']);
				$CompanyItem = $this->GetViewCompanythread($Val['company_id']);
				foreach($CompanyItem['admin'] as $K => $V) {
					$WxUserInfo = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where uid = '.intval($V));
					if($this->Config['PluginVar']['NoticeTemplate'] && $WxUserInfo['openid']){//ģ����Ϣ֪ͨ
						$TemplateParam = array(
							'touser' => $WxUserInfo['openid'],
							'template_id' => $this->Config['PluginVar']['NoticeTemplate'],
							'url' => $this->Config['UserInfoListUrl'],
							'topcolor' => '#ff0000',
							'data' =>array(
								'first'=>array('value'=>diconv($NoticeMsg, CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['Color']),
								'keyword1'=>array('value'=>diconv($this->Config['PluginVar']['Title'], CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['FFColor']),
								'keyword2'=>array('value'=>date('Y-m-d H:i',time()),'color'=>$this->Config['PluginVar']['FColor']),
								'remark'=>array('value'=>'')
							)
						);
						@require_once libfile('class/wechat','plugin/fn_assembly');
						$WechatClient = new Fn_WeChatClient($this->Config['PluginVar']['WxAppid'],$this->Config['PluginVar']['WxSecret']);
						$WechatClient->send_weixintemplate(json_encode($TemplateParam));
					}else{
						if(DzNotice){
							notification_add($V,'system','<a href="{url}">{msg}</a>',array(
								'url'=>$this->Config['UserInfoListUrl'],
								'msg'=>$NoticeMsg
							),1);//ϵͳ֪ͨ
						}
					}
					
					if($Config['PluginVar']['AppType'] == 1){//������������
						$PushData['Uid'] = $V;
						$PushData['Type'] = 'pictemp';
						$PushData['Content'] = array(
							"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"link"=> $this->Config['UserInfoListUrl'],
							"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
							"extra_info"=>array(
								array(
									"key"=>'',
									"val"=>diconv($NoticeMsg,CHARSET,'UTF-8')
								)
							)
						);
						$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
					}
				}
				if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
					$PushData['Uid'] = implode(',',$CompanyItem['admin']);
					$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8');
					$PushData['Content'] = array(
						'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
						'date'=>date('Y-m-d H:i:s'),
						'setting'=>array(),
						'content' => diconv($NoticeMsg,CHARSET,'UTF-8'),
						'url'=>$this->Config['UserInfoListUrl']
					);
					$this->QHApp->GetMessagesTemplate($PushData);
				}
				if($this->Config['PluginVar']['ShortMessageSwitch']){//����֪ͨ
					@require_once libfile('class/short_message','plugin/fn_assembly');
					if($Config['PluginVar']['ShortMessageType'] == 1){
						$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
						$TemplateParam = array('remark'=>$NoticeMsg);
					}else if($Config['PluginVar']['ShortMessageType'] == 2){
						$TemplateCode = str_replace(array('{Msg}'),array($NoticeMsg),$this->Config['PluginVar']['ChanyooNotice']);
						$TemplateParam = array();
					}
					$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].($CompanyItem['sms_mobile'] ? $CompanyItem['sms_mobile'] : $Val['mobile']),$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$Val['uid'],$Val['username'],'fn_job',2);
				}
				//��Ϣ֪ͨEnd
				DB::update($this->TableInfo,array('expiry_push'=>1),'id = '.$Val['id']);
			}
		}
	}

	/* �ö�����ʱ������ */
	public function GetTopExpiryPushInfo(){
		global $Config;

		if($this->Config['PluginVar']['TopExpiryTimeSwitch'] && date('H',time()) >= 9 && date('H',time()) <= 22){
			foreach($this->InfoListFormat(DB::fetch_all('SELECT I.* FROM '.DB::table($this->TableInfo).' I where I.display = 1 and I.payment_state = 1 and I.top_expiry_push != 1 and I.topdateline < '.time().' and I.topdateline != \'\' '.($this->Config['PluginVar']['TopExpiryTime'] ? ' and I.topdateline >='.strtotime($this->Config['PluginVar']['TopExpiryTime']) : '').' order by I.id desc ')) as $Val) {
				
				//��Ϣ֪ͨ
				$NoticeMsg = str_replace(array('{classid_min_text}'),array($Val['classid_min_text']),$this->Config['LangVar']['TopExpiryPushInfo']);
				$CompanyItem = $this->GetViewCompanythread($Val['company_id']);
				foreach($CompanyItem['admin'] as $K => $V) {
					$WxUserInfo = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where uid = '.intval($V));
					if($this->Config['PluginVar']['NoticeTemplate'] && $WxUserInfo['openid']){//ģ����Ϣ֪ͨ
						$TemplateParam = array(
							'touser' => $WxUserInfo['openid'],
							'template_id' => $this->Config['PluginVar']['NoticeTemplate'],
							'url' => $this->Config['UserInfoListUrl'],
							'topcolor' => '#ff0000',
							'data' =>array(
								'first'=>array('value'=>diconv($NoticeMsg, CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['Color']),
								'keyword1'=>array('value'=>diconv($this->Config['PluginVar']['Title'], CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['FFColor']),
								'keyword2'=>array('value'=>date('Y-m-d H:i',time()),'color'=>$this->Config['PluginVar']['FColor']),
								'remark'=>array('value'=>'')
							)
						);
						@require_once libfile('class/wechat','plugin/fn_assembly');
						$WechatClient = new Fn_WeChatClient($this->Config['PluginVar']['WxAppid'],$this->Config['PluginVar']['WxSecret']);
						$WechatClient->send_weixintemplate(json_encode($TemplateParam));
					}else{
						if(DzNotice){
							notification_add($V,'system','<a href="{url}">{msg}</a>',array(
								'url'=>$this->Config['UserInfoListUrl'],
								'msg'=>$NoticeMsg
							),1);//ϵͳ֪ͨ
						}
					}
					
					if($Config['PluginVar']['AppType'] == 1){//������������
						$PushData['Uid'] = $V;
						$PushData['Type'] = 'pictemp';
						$PushData['Content'] = array(
							"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"link"=> $this->Config['UserInfoListUrl'],
							"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
							"extra_info"=>array(
								array(
									"key"=>'',
									"val"=>diconv($NoticeMsg,CHARSET,'UTF-8')
								)
							)
						);
						$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
					}
				}

				if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
					$PushData['Uid'] = implode(',',$CompanyItem['admin']);
					$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8');
					$PushData['Content'] = array(
						'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
						'date'=>date('Y-m-d H:i:s'),
						'setting'=>array(),
						'content' => diconv($NoticeMsg,CHARSET,'UTF-8'),
						'url'=>$this->Config['UserInfoListUrl']
					);
					$this->QHApp->GetMessagesTemplate($PushData);
				}
				
				if($this->Config['PluginVar']['ShortMessageSwitch']){//����֪ͨ
					@require_once libfile('class/short_message','plugin/fn_assembly');
					if($Config['PluginVar']['ShortMessageType'] == 1){
						$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
						$TemplateParam = array('remark'=>$NoticeMsg);
					}else if($Config['PluginVar']['ShortMessageType'] == 2){
						$TemplateCode = str_replace(array('{Msg}'),array($NoticeMsg),$this->Config['PluginVar']['ChanyooNotice']);
						$TemplateParam = array();
					}
					$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].($CompanyItem['sms_mobile'] ? $CompanyItem['sms_mobile'] : $Val['mobile']),$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$Val['uid'],$Val['username'],'fn_job',2);
				}
				//��Ϣ֪ͨEnd
				DB::update($this->TableInfo,array('top_expiry_push'=>1),'id = '.$Val['id']);
			}
		}
	}
	
	/* ��˾��Ա����ʱ������ */
	public function GetVipExpiryPushCompany(){
		global $Config;

		if($this->Config['PluginVar']['VipExpiryTimeSwitch'] && date('H',time()) >= 9 && date('H',time()) <= 22){
			foreach($this->InfoListFormat(DB::fetch_all('SELECT C.* FROM '.DB::table($this->TableCompany).' C where C.display = 1 and C.vip_expiry_push != 1 and C.due_time < '.time().' and C.vip_stop = 0 and C.due_time != \'\' '.($this->Config['PluginVar']['VipExpiryTime'] ? ' and C.due_time >='.strtotime($this->Config['PluginVar']['VipExpiryTime']) : '').' order by C.id desc ')) as $Val) {
				
				//��Ϣ֪ͨ
				$NoticeMsg = $this->Config['LangVar']['VipExpiryPushCompany'];
				$CompanyItem = $this->GetViewCompanythread($Val['id']);
				foreach($CompanyItem['admin'] as $K => $V) {
					$WxUserInfo = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where uid = '.intval($V));
					if($this->Config['PluginVar']['NoticeTemplate'] && $WxUserInfo['openid']){//ģ����Ϣ֪ͨ
						$TemplateParam = array(
							'touser' => $WxUserInfo['openid'],
							'template_id' => $this->Config['PluginVar']['NoticeTemplate'],
							'url' => $this->Config['BuyStoreLevelUrl'],
							'topcolor' => '#ff0000',
							'data' =>array(
								'first'=>array('value'=>diconv($NoticeMsg, CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['Color']),
								'keyword1'=>array('value'=>diconv($this->Config['PluginVar']['Title'], CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['FFColor']),
								'keyword2'=>array('value'=>date('Y-m-d H:i',time()),'color'=>$this->Config['PluginVar']['FColor']),
								'remark'=>array('value'=>'')
							)
						);
						@require_once libfile('class/wechat','plugin/fn_assembly');
						$WechatClient = new Fn_WeChatClient($this->Config['PluginVar']['WxAppid'],$this->Config['PluginVar']['WxSecret']);
						$WechatClient->send_weixintemplate(json_encode($TemplateParam));
					}else{
						if(DzNotice){
							notification_add($V,'system','<a href="{url}">{msg}</a>',array(
								'url'=>$this->Config['BuyStoreLevelUrl'],
								'msg'=>$NoticeMsg
							),1);//ϵͳ֪ͨ
						}
					}
					
					if($Config['PluginVar']['AppType'] == 1){//������������
						$PushData['Uid'] = $V;
						$PushData['Type'] = 'pictemp';
						$PushData['Content'] = array(
							"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"link"=> $this->Config['BuyStoreLevelUrl'],
							"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
							"extra_info"=>array(
								array(
									"key"=>'',
									"val"=>diconv($NoticeMsg,CHARSET,'UTF-8')
								)
							)
						);
						$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
					}
				}
				
				if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
					$PushData['Uid'] = implode(',',$CompanyItem['admin']);
					$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8');
					$PushData['Content'] = array(
						'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
						'date'=>date('Y-m-d H:i:s'),
						'setting'=>array(),
						'content' => diconv($NoticeMsg,CHARSET,'UTF-8'),
						'url'=>$this->Config['UserInfoListUrl']
					);
					$this->QHApp->GetMessagesTemplate($PushData);
				}


				if($this->Config['PluginVar']['ShortMessageSwitch']){//����֪ͨ
					@require_once libfile('class/short_message','plugin/fn_assembly');
					if($Config['PluginVar']['ShortMessageType'] == 1){
						$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
						$TemplateParam = array('remark'=>$NoticeMsg);
					}else if($Config['PluginVar']['ShortMessageType'] == 2){
						$TemplateCode = str_replace(array('{Msg}'),array($NoticeMsg),$this->Config['PluginVar']['ChanyooNotice']);
						$TemplateParam = array();
					}
					$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].($CompanyItem['sms_mobile'] ? $CompanyItem['sms_mobile'] : $Val['mobile']),$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$Val['uid'],$Val['username'],'fn_job',2);
				}
				//��Ϣ֪ͨEnd
				DB::update($this->TableCompany,array('vip_expiry_push'=>1),'id = '.$Val['id']);
			}
		}
	}

	/* ������ʾְλ */
	public function GetAjaxUserHideInfo($Get){
		global $_G;
		$Get = EncodeURIToUrldeCode($Get);

		$UserInfo = $this->GetUserInfo();

		/*if(!$UserInfo['company']['vip']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoRefreshAuthority']);
			return $Data;
		}*/

		if(!$UserInfo['company']['hide'] && $UserInfo['company']['vip']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoAuthority']);
			return $Data;
		}

		$Item = $this->GetViewthread($Get['iid']);
		
		if(DB::update($this->TableInfo,array('hide'=> $Item['hide'] ? 0 : 1),' id = '.intval($Get['iid']))){
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
		}
		return $Data;
	}

	/* ����ˢ��ְλ */
	public function GetAjaxRefresh($Get){
		global $_G;
		
		$Get = EncodeURIToUrldeCode($Get);

		$UserInfo = $this->GetUserInfo();

		if(!$UserInfo['company']['vip'] && !$UserInfo['company']['due_time'] && $this->Config['PluginVar']['RefreshDayNum'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoRefreshLog).' where iid = '.intval($Get['iid']).' and company_id = '.intval($UserInfo['company']['id']).' and type = 2 and dateline >= '.strtotime(date('Y-m-d')).' and dateline <='.strtotime(date('Y-m-d 23:59:59'))) < $this->Config['PluginVar']['RefreshDayNum']){
			$UpData['iid'] = intval($Get['iid']);
			$UpData['uid'] = intval($_G['uid']);
			$UpData['company_id'] = intval($UserInfo['company']['id']);
			$UpData['username'] = addslashes(strip_tags($_G['username']));
			$UpData['type'] =2;
			$UpData['dateline'] = time();
			$LogId = DB::insert($this->TableInfoRefreshLog,$UpData,true);
			if($LogId && DB::update($this->TableInfo,array('updateline'=>time(),'expiry_push'=>0),' id = '.intval($Get['iid']))){
				$Data['State'] = 201;
				$Data['Msg'] = urlencode($this->Config['LangVar']['RefreshOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DayRefreshInfoErr2']);
			}
		}else{
			$Data = $this->GetAjaxPayLog(array('event'=>'refresh_info','money'=>$this->Config['PluginVar']['RefreshMoney'],'iid'=>$Get['iid']));
		}
		return $Data;
	}

	/* ���ˢ��ְλ */
	public function GetAjaxUserRefreshInfo($Get){
		global $_G;
		$Get = EncodeURIToUrldeCode($Get);

		$UserInfo = $this->GetUserInfo();

		if(!$UserInfo['company']['vip']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoRefreshAuthority']);
			return $Data;
		}

		if(!$UserInfo['RemnantRefreshCount'] && $UserInfo['company']['refresh_count'] && $UserInfo['company']['refresh_type'] == 2){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RefreshInfoErr']);
			return $Data;
		}

		if(!$UserInfo['RemnantDayRefreshCount'] && $UserInfo['company']['day_refresh_count'] && $UserInfo['company']['refresh_type'] == 1){
			$Data['Msg'] = urlencode($this->Config['LangVar']['DayRefreshInfoErr']);
			return $Data;
		}
	
		$UpData['iid'] = intval($Get['iid']);
		$UpData['uid'] = intval($_G['uid']);
		$UpData['company_id'] = intval($UserInfo['company']['id']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['dateline'] = time();
		
		$LogId = DB::insert($this->TableInfoRefreshLog,$UpData,true);
		if($LogId && DB::update($this->TableInfo,array('updateline'=>time(),'expiry_push'=>0,'hide'=>1),' id = '.intval($Get['iid']))){
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['RefreshOk']);
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['DayRefreshInfoErr2']);
		}
		return $Data;
	}

	/* ���ˢ��ְλ */
	public function GetAjaxUserWalletRefreshInfo($Get){
		global $_G;
		$Get = EncodeURIToUrldeCode($Get);

		$UserInfo = $this->GetUserInfo();

		if(!$UserInfo['company']['vip']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoRefreshAuthority']);
			return $Data;
		}

		if($UserInfo['company']['money'] < intval($this->Config['PluginVar']['RefreshMoney'])){
			$Data['Msg'] = urlencode(str_replace(array('{wallet_title}'),array($this->Config['PluginVar']['CompanyWalletTitle']),$this->Config['LangVar']['CompanyWalletBalanceErr']));
			return $Data;
		}

		if($this->InsertCompanyWalletLog($UserInfo['company']['id'],$this->Config['PluginVar']['RefreshMoney'],$this->Config['LangVar']['CompanyWalletBalanceTypeArray']['1'].$Get['iid'])){
			DB::update($this->TableInfo,array('updateline'=>time(),'expiry_push'=>0,'hide'=>1),' id = '.intval($Get['iid']));
			DB::query("UPDATE ".DB::table($this->TableCompany)." SET money = money - ".intval($this->Config['PluginVar']['RefreshMoney'])." WHERE id = ".intval($UserInfo['company']['id']));
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['RefreshOk']);
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['DayRefreshInfoErr2']);
		}
		return $Data;
	}

	/* ȫ��ˢ�� */
	public function GetAjaxAllRefresh(){
		global $_G;
		$UserInfo = $this->GetUserInfo();

		if(!$UserInfo['company']['vip']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoRefreshAuthority']);
			return $Data;
		}

		if(!$UserInfo['RemnantRefreshCount'] && $UserInfo['company']['refresh_count'] && $UserInfo['company']['refresh_type'] == 2){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RefreshInfoErr']);
			return $Data;
		}

		if(!$UserInfo['RemnantDayRefreshCount'] && $UserInfo['company']['day_refresh_count'] && $UserInfo['company']['refresh_type'] == 1){
			$Data['Msg'] = urlencode($this->Config['LangVar']['DayRefreshInfoErr']);
			return $Data;
		}
		
		$I = 0;
		foreach(DB::fetch_all('SELECT * FROM '.DB::table($this->TableInfo).' where company_id = '.intval($UserInfo['company']['id']).' and display = 1 and payment_state = 1 and hide = 1 order by updateline desc') as $Key => $Val ){
			$UpData['iid'] = intval($Val['id']);
			$UpData['uid'] = intval($_G['uid']);
			$UpData['company_id'] = intval($UserInfo['company']['id']);
			$UpData['username'] = addslashes(strip_tags($_G['username']));
			$UpData['dateline'] = time();
			$LogId = DB::insert($this->TableInfoRefreshLog,$UpData,true);
			if($LogId && DB::update($this->TableInfo,array('updateline'=>time(),'expiry_push'=>0),' id = '.intval($Val['id']))){
				$I++;
			}
		}
		if($I){
			$Data['State'] = 200;
			$Data['Msg'] = urlencode(str_replace(array('{num}'),array($I),$this->Config['LangVar']['AllRefreshOk']));
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['DayRefreshInfoErr2']);
		}
		return $Data;
	}

	/* �ö�ְλ */
	public function GetAjaxTop($Get){
		global $_G;
		
		$Get = EncodeURIToUrldeCode($Get);

		$UserInfo = $this->GetUserInfo();

		if($this->Config['PluginVar']['JobTopLimit'] && $this->Config['PluginVar']['JobTopLimit'] <= DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where topdateline > '.time().' and company_id = '.intval($UserInfo['company']['id']))){
			$Data['Msg'] = urlencode(str_replace(array('{count}'),array($this->Config['PluginVar']['JobTopLimit']),$this->Config['PluginVar']['JobTopLimitTips']));
			return $Data;
		}
		
		if($UserInfo['company']['vip'] && $UserInfo['company']['money'] >= intval($Get['original_money']) && $this->InsertCompanyWalletLog($UserInfo['company']['id'],$Get['original_money'],$this->Config['LangVar']['CompanyWalletBalanceTypeArray']['2'].$Get['iid'])){

			$Item = $this->GetViewthread($Get['iid']);

			DB::update($this->TableInfo,array('updateline'=>time(),'expiry_push'=>0,'top_expiry_push'=>0,'hide'=>1,'topdateline'=>$Item['topdateline'] >= time() ? strtotime("+".intval($Get['day'])." day",$Item['topdateline']) : strtotime("+".intval($Get['day'])." day",time())),' id = '.intval($Get['iid']));

			DB::query("UPDATE ".DB::table($this->TableCompany)." SET money = money - ".intval($Get['original_money'])." WHERE id = ".intval($UserInfo['company']['id']));

			$Data['State'] = 201;

			return $Data;
		}else{
			return $this->GetAjaxPayLog(array('event'=>'top_info','money'=>$Get['money'],'day'=>$Get['day'],'resume'=>$Get['resume'],'iid'=>$Get['iid']));
		}

	}

	/* �ҵķ���ְλ */
	public function GetAjaxUserInfoList(){
		global $_G;
		$Results = array();
		$UserInfo = $this->GetUserInfo();
		$Where = ' and I.payment_state = 1 and '.($UserInfo['company']['id'] ? 'I.company_id = '.intval($UserInfo['company']['id']) : ' I.uid = '.intval($_G['uid']));
		$Order = 'I.updateline';
		$Where = preg_replace('/and/','where',$Where,1);
		$FetchSql = 'SELECT I.* FROM '.DB::table($this->TableInfo).' I'.$Where.' order by I.topdateline > '.time().' desc,'.$Order.' desc,I.dateline desc ';
		$Results = $this->InfoListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}

	/* ��̨�Ƽ�ְλ */
	public function GetAdminApplyLog($Id,$Rid){
		global $_G,$Config;
		$Item = $this->GetViewthread($Id);
		$ResumeItem = $this->GetViewResumethread($Rid);
		$GetData['uid'] = intval($ResumeItem['uid']);
		$GetData['username'] = addslashes(strip_tags($ResumeItem['username']));
		$GetData['iid'] = intval($Id);
		$GetData['company_id'] = intval($Item['company_id']);
		$GetData['dateline'] = time();
		$GetData['type'] = 2;
		$ApplyLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableInfoApplyLog).' where uid = '.$GetData['uid'].' and iid = '.$GetData['iid']);
		if($ApplyLog){
			$Data['Msg'] = urlencode($this->Config['LangVar']['IsApplicationPositionErr']);
			return $Data;
		}else{
			if(DB::insert($this->TableInfoApplyLog,$GetData)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['RecommendSuccess']);
				$ResumeItem['full_name'] = $this->Config['PluginVar']['ResumeNameSwitch'] ? $ResumeItem['full_name'] : cutstr($ResumeItem['full_name'],3,'').$this->Config['LangVar']['SexToArray'][$ResumeItem['sex']];
				//��Ϣ֪ͨ
				$NoticeMsg = str_replace(array('{name}','{classid_min_text}'),array($this->Config['PluginVar']['Title'],$Item['classid_min_text']),$this->Config['LangVar']['RecommendApplyLogPush']);
				
				$CompanyItem = $this->GetViewCompanythread($Item['company_id']);
				foreach($CompanyItem['admin'] as $K => $V) {
					$WxUserInfo = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where uid = '.intval($V));
					if($this->Config['PluginVar']['NoticeTemplate'] && $WxUserInfo['openid']){//ģ����Ϣ֪ͨ
						$TemplateParam = array(
							'touser' => $WxUserInfo['openid'],
							'template_id' => $this->Config['PluginVar']['NoticeTemplate'],
							'url' => $this->Config['ViewResumeUrl'].$ResumeItem['uid'],
							'topcolor' => '#ff0000',
							'data' =>array(
								'first'=>array('value'=>diconv($NoticeMsg, CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['Color']),
								'keyword1'=>array('value'=>diconv($this->Config['PluginVar']['Title'], CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['FFColor']),
								'keyword2'=>array('value'=>date('Y-m-d H:i',time()),'color'=>$this->Config['PluginVar']['FColor']),
								'remark'=>array('value'=>'')
							)
						);
						@require_once libfile('class/wechat','plugin/fn_assembly');
						$WechatClient = new Fn_WeChatClient($this->Config['PluginVar']['WxAppid'],$this->Config['PluginVar']['WxSecret']);
						$WechatClient->send_weixintemplate(json_encode($TemplateParam));
					}else{
						if(DzNotice){
							notification_add($V,'system','<a href="{url}">{msg}</a>',array(
								'url'=>$this->Config['ViewResumeUrl'].$ResumeItem['uid'],
								'msg'=>$NoticeMsg
							),1);//ϵͳ֪ͨ
						}
					}
					
					if($Config['PluginVar']['AppType'] == 1){//������������
						$PushData['Uid'] = $V;
						$PushData['Type'] = 'pictemp';
						$PushData['Content'] = array(
							"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"link"=> $this->Config['ViewResumeUrl'].$ResumeItem['uid'],
							"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
							"extra_info"=>array(
								array(
									"key"=>'',
									"val"=>diconv($NoticeMsg,CHARSET,'UTF-8')
								)
							)
						);
						$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
					}
				}

				if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
					$PushData['Uid'] = implode(',',$CompanyItem['admin']);
					$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8');
					$PushData['Content'] = array(
						'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
						'date'=>date('Y-m-d H:i:s'),
						'setting'=>array(),
						'content' => diconv($NoticeMsg,CHARSET,'UTF-8'),
						'url'=>$this->Config['ViewResumeUrl'].$ResumeItem['uid']
					);
					$this->QHApp->GetMessagesTemplate($PushData);
				}
				
				if($this->Config['PluginVar']['ShortMessageSwitch']){//����֪ͨ
					@require_once libfile('class/short_message','plugin/fn_assembly');
					if($Config['PluginVar']['ShortMessageType'] == 1){
						$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
						$TemplateParam = array('remark'=>$NoticeMsg);
					}else if($Config['PluginVar']['ShortMessageType'] == 2){
						$TemplateCode = str_replace(array('{Msg}'),array($NoticeMsg),$this->Config['PluginVar']['ChanyooNotice']);
						$TemplateParam = array();
					}
					$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$Item['mobile'],$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$Item['uid'],$Item['username'],'fn_job',2);
				}
				//��Ϣ֪ͨEnd
				
			}
		}
		return $Data;
	}

	/* ����ְλ */
	public function GetAjaxInfoApplyLog($Id,$Fid = null){
		global $_G,$Config;
		$Item = $this->GetViewthread($Id);
		if($Item['uid'] == $_G['uid']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MyApplicationPositionErr']);
			return $Data;
		}

		if(!$Item['display'] && $Item){
			$Data['Msg'] = urlencode($this->Config['LangVar']['InfoInAudit']);
			return $Data;
		}

		if(!$Item['hide'] && $Item){
			$Data['Msg'] = urlencode($this->Config['LangVar']['InfoInAuditHide']);
			return $Data;
		}

		$UserInfo = $this->GetUserInfo();
		if(!$UserInfo['resume']){
			$Data['State'] = 202;
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoResumeErr']);
			return $Data;
		}else if(!$UserInfo['resume']['display']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeDisplayErr']);
			return $Data;
		}
		
		if(in_array($_G['uid'],array_filter(explode(",",$this->Config['PluginVar']['prohibit_apply_uid'])))){
			$Data['Msg'] = urlencode($this->Config['PluginVar']['prohibit_apply_uid_tips']);
			return $Data;
		}

		if($this->Config['PluginVar']['ResumeApplyInfoNum'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoApplyLog).' where uid = '.intval($_G['uid']).' and dateline >= '.strtotime(date('Y-m-d')).' and dateline <='.strtotime(date('Y-m-d 23:59:59'))) >= $this->Config['PluginVar']['ResumeApplyInfoNum']){
			$Data['Msg'] = urlencode(str_replace(array('{num}'),array($this->Config['PluginVar']['ResumeApplyInfoNum']),$this->Config['PluginVar']['ResumeApplyInfoNumTips']));
			return $Data;
		}
		
		$GetData['uid'] = intval($_G['uid']);
		$GetData['username'] = addslashes(strip_tags($_G['username']));
		$GetData['iid'] = intval($Id);
		$GetData['fid'] = intval($Fid);
		$GetData['company_id'] = intval($Item['company_id']);
		$GetData['dateline'] = time();

		$ApplyLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableInfoApplyLog).' where uid = '.$GetData['uid'].' and iid = '.$GetData['iid']);

		if($ApplyLog){
			$Data['Msg'] = urlencode($this->Config['LangVar']['IsApplicationPositionErr']);
			return $Data;
		}else{
			if(DB::insert($this->TableInfoApplyLog,$GetData)){
				if($UserInfo['resume'] && $UserInfo['resume']['state'] == 2 && $this->Config['PluginVar']['ResumeApplyInfoSwitch']){
					DB::update($this->TableResume,array('state'=> 1),' uid = '.intval($UserInfo['resume']['uid']));
				}
				
				if($UserInfo['resume'] && $this->Config['PluginVar']['ResumeRefreshSwitch']){
					DB::update($this->TableResume,array('updateline'=> time()),' uid = '.intval($UserInfo['resume']['uid']));
				}

				DB::query("UPDATE ".DB::table($this->TableInfo)." SET apply_count = apply_count + 1 WHERE id=".intval($Id));
				DB::query("UPDATE ".DB::table($this->TableResume)." SET apply_count = apply_count + 1 WHERE uid=".intval($UserInfo['resume']['uid']));
				
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['OkApplicationPosition']);
				$UserInfo['resume']['full_name'] = $this->Config['PluginVar']['ResumeNameSwitch'] ? $UserInfo['resume']['full_name'] : cutstr($UserInfo['resume']['full_name'],3,'').$this->Config['LangVar']['SexToArray'][$UserInfo['resume']['sex']];
				//��Ϣ֪ͨ
				
				$NoticeMsg = str_replace(array('{name}','{classid_min_text}'),array($UserInfo['resume']['full_name'],$Item['classid_min_text']),$this->Config['LangVar']['InfoApplyLogPush']);
				$NoticeUrl = $this->Config['ViewResumeUrl'].$UserInfo['resume']['uid'];
				$CompanyItem = $this->GetViewCompanythread($Item['company_id']);
				foreach($CompanyItem['admin'] as $Key => $Val) {
					$WxUserInfo = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where uid = '.intval($Val));
					if($this->Config['PluginVar']['ApplyTemplate'] && $WxUserInfo['openid']){//ģ����Ϣ֪ͨ
						$TemplateParam = array(
							'touser' => $WxUserInfo['openid'],
							'template_id' => $this->Config['PluginVar']['ApplyTemplate'],
							'url' => $NoticeUrl,
							'topcolor' => '#ff0000',
							'data' =>array(
								'first'=>array('value'=>diconv($this->Config['LangVar']['InfoApplyLogTemplateTitle'], CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['Color']),
								'keyword1'=>array('value'=>diconv($Item['title'], CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['FFColor']),
								'keyword2'=>array('value'=>diconv($UserInfo['resume']['full_name'], CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['FColor']),
								'remark'=>array('value'=>'')
							)
						);
						@require_once libfile('class/wechat','plugin/fn_assembly');
						$WechatClient = new Fn_WeChatClient($this->Config['PluginVar']['WxAppid'], $this->Config['PluginVar']['WxSecret']);
						$WechatClient->send_weixintemplate(json_encode($TemplateParam));
					}else{
						if(DzNotice){
							notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
								'url'=>$NoticeUrl,
								'msg'=>$NoticeMsg
							),1);//ϵͳ֪ͨ
						}
					}
					
					if($Config['PluginVar']['AppType'] == 1){//������������
						$PushData['Uid'] = $Val;
						$PushData['Type'] = 'pictemp';
						$PushData['Content'] = array(
							"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
							"link"=> $NoticeUrl,
							"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
							"extra_info"=>array(
								array(
									"key"=>'',
									"val"=>diconv($NoticeMsg,CHARSET,'UTF-8')
								)
							)
						);
						$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
					}
				
				}

				if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
					$PushData['Uid'] = implode(',',$CompanyItem['admin']);
					$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8');
					$PushData['Content'] = array(
						'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
						'date'=>date('Y-m-d H:i:s'),
						'setting'=>array(),
						'content' => diconv($NoticeMsg,CHARSET,'UTF-8'),
						'url'=>$this->Config['UserCompanyApplyLogUrl']
					);
					$this->QHApp->GetMessagesTemplate($PushData);
				}
				
				
				if($this->Config['PluginVar']['ShortMessageSwitch']){//����֪ͨ
					@require_once libfile('class/short_message','plugin/fn_assembly');
					if($Config['PluginVar']['ShortMessageType'] == 1){
						$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
						$TemplateParam = array('remark'=>$NoticeMsg);
					}else if($Config['PluginVar']['ShortMessageType'] == 2){
						$TemplateCode = str_replace(array('{Msg}'),array($NoticeMsg),$this->Config['PluginVar']['ChanyooNotice']);
						$TemplateParam = array();
					}
					$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].($CompanyItem['sms_mobile'] ? $CompanyItem['sms_mobile'] : $Item['mobile']),$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$Item['uid'],$Item['username'],'fn_job',2);
				}
				//��Ϣ֪ͨEnd
			}
		}
		return $Data;
	}

	/* �ҵ�����ְλId */
	public function GetUserInfoApplyLogArray(){
		global $_G;
		$MyApplyLogArray = DB::fetch_all('SELECT iid FROM '.DB::table($this->TableInfoApplyLog).' where uid = '.intval($_G['uid']).' order by id desc');
		foreach($MyApplyLogArray as $Key => $Val) {
			$MyApplyLogIdArray[] = $Val['iid'];
		}
		return $MyApplyLogIdArray;
	}

	/* �ҵ�����ְλ */
	public function GetUserInfoApplyLogList(){
		global $_G;
		$Where = ' and A.uid = '.intval($_G['uid']);
		$Order = 'A.dateline';
		$Where = preg_replace('/and/','where',$Where,1);
		return $this->InfoListFormat(DB::fetch_all("SELECT I.*,CC.id as cid,CC.name,CC.content as c_content,CC.param as c_param,CC.due_time,CC.vip_stop,CC.logo,CC.type as c_type,CC.verify,G.ico FROM %t AS A,%t AS I LEFT JOIN `".DB::table($this->TableCompany)."` CC on CC.id = I.company_id LEFT JOIN `".DB::table($this->TableCompanyGroup)."` G on G.id = CC.group_id ".$Where." And I.id = A.iid order by ".$Order." desc,A.id desc",array($this->TableInfoApplyLog,$this->TableInfo)));
	}

	/* �Ƿ�����ù�˾�µ�ְλ */
	public function GetUserInfoApplyLogState($Uid,$CompanyUid){
		global $_G;
		return $Uid ? DB::fetch_first('SELECT L.*,SI.sign FROM '.DB::table($this->TableInfoApplyLog).' L LEFT JOIN '.DB::table($this->TableResumeSign).' SI on SI.rid = L.uid and SI.company_id = '.intval($CompanyUid).' where L.uid = '.intval($Uid).' and L.company_id = '.intval($CompanyUid)) : false;
	}

	/* ��˾�鿴�����ְλ */
	public function GetAjaxUserCompanyApplyLog($Get){
		global $_G;
		$Results = array();
		$Get = EncodeURIToUrldeCode($Get);
		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		$Where = $Get['company_id'] ? ' and A.company_id = '.intval($Get['company_id']) : ' and A.uid = '.intval($_G['uid']);
		$Order = 'A.dateline';

		if($Get['iid']){
			$Where .= ' and A.iid = '.intval($Get['iid']);
		}

		if(in_array($Get['see'],array('1','2'))){
			$Where .= ' and A.see = '.($Get['see'] == 1 ? 0 : 1);
		}

		if($Get['sign']){
			//��ѯ���
			$SignUids = array();
			foreach (DB::fetch_all('SELECT rid FROM '.DB::table($this->TableResumeSign).' where '.($Get['company_id'] ? 'company_id = '.intval($Get['company_id']) : 'uid = '.intval($_G['uid'])).' and sign = '.intval($Get['sign']).' order by id desc') as $Key => $Val) {
				$SignUids[] = $Val['rid'];
			}
			if(array_filter($SignUids)){
				$Where .= ' and A.uid in('.implode(',',array_filter($SignUids)).')';
			}else{
				return $Results;
			}
			//��ѯ���
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$Results = $this->ResumeListFormat(DB::fetch_all("SELECT SI.sign,R.*,A.see,A.type as apply_type,A.dateline as apply_dateline,A.id as alid,A.iid,I.title as info_title FROM (%t AS A,%t AS R,%t AS I) LEFT JOIN `".DB::table($this->TableResumeSign)."` SI on SI.rid = R.uid and ".($Get['company_id'] ? 'SI.company_id = I.company_id' : 'SI.uid = I.uid')." ".$Where." And R.uid = A.uid And A.iid = I.id order by ".$Order." desc,A.id desc ".$Limit,array($this->TableInfoApplyLog,$this->TableResume,$this->TableInfo)));
		return $Results;
	}

	/* ��˾ɾ�������ְλ */
	public function GetAjaxDelCompanyApplyLog($Id){
		global $_G;
		$UserInfo = $this->GetUserInfo();
		$Item = DB::fetch_first('SELECT iid,uid FROM '.DB::table($this->TableInfoApplyLog).' where id= '.intval($Id));
		if(DB::delete($this->TableInfoApplyLog,'company_id ='.intval($UserInfo['company']['id']).' and id = '.intval($Id))){
			DB::query("UPDATE ".DB::table($this->TableInfo)." SET apply_count = apply_count - 1 WHERE id=".intval($Item['iid']));
			DB::query("UPDATE ".DB::table($this->TableResume)." SET apply_count = apply_count - 1 WHERE uid=".intval($Item['uid']));
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
		}
		return $Data;
	}

	/* �Ƿ��ע */
	public function GetCompanyFollowFirst($rid,$company_id){
		return DB::fetch_first('SELECT * FROM '.DB::table($this->TableCompanyFollow).' where rid = '.intval($rid).' and company_id = '.intval($company_id));
	}
	
	/* ��ע��˾ */
	public function GetAjaxCompanyFollow($company_id){
		global $_G;
		$UserInfo = $this->GetUserInfo();
		if(!$UserInfo['resume']){
			$Data['State'] = 202;
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoResumeFollowErr']);
			return $Data;
		}

		$UpData['company_id'] = intval($company_id);
		$UpData['rid'] = intval($_G['uid']);
		$UpData['dateline'] = time();
		
		$CompanyFollowLog = $this->GetCompanyFollowFirst($UpData['rid'],$UpData['company_id']);
		if($CompanyFollowLog){
			DB::delete($this->TableCompanyFollow,'id ='.intval($CompanyFollowLog['id']));
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyFollowCancel']);
		}else{
			DB::insert($this->TableCompanyFollow,$UpData);
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyFollowSuccess']);
		}
		return $Data;
	}

	/* ��ע��˾�б� */
	public function GetCompanyFollowList($Get){
		global $_G;
		$Results = array();
		$Get = EncodeURIToUrldeCode($Get);
		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		$Where = '';
		$Order = 'dateline';
		
		if($Get['rid']){
			$Where .= ' and rid = '.intval($Get['rid']);
		}

		if($Get['company_id']){
			$Where .= ' and company_id = '.intval($Get['company_id']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = ' LIMIT 0,1000';
		
		foreach(DB::fetch_all("SELECT * FROM ".DB::table($this->TableCompanyFollow).$Where." order by ".$Order." desc ".$Limit) as $key => $val) {
			$Results[$key] = $val;
			$Results[$key]['resume'] = $this->GetViewResumethread($val['rid']);
			$Results[$key]['company'] = $this->GetViewCompanythread($val['company_id']);
		}
		return $Results;
	}

	/* ����Ƿ�鿴���ü��� */
	public function MyApplyLogUpdataSee($Id,$CompanyId){
		global $_G;
		DB::update($this->TableInfoApplyLog,array('see'=>1),'uid = '.intval($Id).' and company_id = '.intval($CompanyId));
	}

	/* �鿴��ϵ��ʽ */
	public function GetAjaxResumeSeeLog($Id){
		global $_G;
	
		if($Id == $_G['uid']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeSeeLogRepeatMyErr']);
			return $Data;
		}

		if(in_array($_G['uid'],$this->Config['PluginVar']['ResumeProhibitUids'])){
			$Data['Msg'] = urlencode($this->Config['PluginVar']['ResumeProhibitTips']);
			return $Data;
		}

		$UserInfo = $this->GetUserInfo();
		
		$GetData['uid'] = intval($_G['uid']);
		$GetData['company_id'] = intval($UserInfo['company']['id']);
		$GetData['rid'] = intval($Id);
		$GetData['mode'] = 1;
		$GetData['dateline'] = $GetData['updateline'] = time();
		
		if(!$UserInfo['company']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeDownSwitchErr']);
			$Data['State'] = 203;
			return $Data;
		}

		if($UserInfo['company'] && !$UserInfo['company']['display']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeCompanyDisplayErr']);
			return $Data;
		}

		//�Ƿ񷢲���ְλ
		$ResumeDownInfo = $this->Config['PluginVar']['ResumeDownInfoSwitch'] && $UserInfo['company']['id'] && $this->GetAjaxJobCompanyList(array('company_id'=>$UserInfo['company']['id'])) ? true : false;
		if(!$ResumeDownInfo && $this->Config['PluginVar']['ResumeDownInfoSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeDownInfo']);
			$Data['State'] = 204;
			return $Data;
		}

		$SeeLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableResumeSeeLog).' where '.( $UserInfo['company']['id'] ? 'company_id = '.intval($UserInfo['company']['id']) : ' uid = '.intval($_G['uid']) ).' and rid = '.intval($Id));
		
		if($SeeLog && $this->Config['PluginVar']['ResumeSeeDueTime'] && $SeeLog['updateline'] >= strtotime("-".intval($this->Config['PluginVar']['ResumeSeeDueTime'])." day",time())){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeSeeLogRepeatErr']);
			return $Data;
		}else if($SeeLog && !$this->Config['PluginVar']['ResumeSeeDueTime']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeSeeLogRepeatErr']);
			return $Data;
		}
	
		if(($this->Config['PluginVar']['ResumeSeeMoney'] && !$UserInfo['company']['vip'] && !$UserInfo['company']['resume_package_count']) || ($UserInfo['RemnantResumeCount'] <= 0 && $UserInfo['company']['vip'] && !$UserInfo['company']['resume_package_count'] && $UserInfo['company']['money'] < intval($this->Config['PluginVar']['ResumeSeeMoney']))){//ֱ�ӹ���

			if(!$UserInfo['company']['vip'] && $this->Config['PluginVar']['ResumeDayDownCount'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResumeSeeLog).' where '.( $UserInfo['company']['id'] ? 'company_id = '.intval($UserInfo['company']['id']) : ' uid = '.intval($_G['uid']) ).' and updateline >= '.strtotime(date('Y-m-d')).' and updateline <='.strtotime(date('Y-m-d 23:59:59'))) >= $this->Config['PluginVar']['ResumeDayDownCount']){//��������
				$Data['State'] = 202;
				$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeDayCountToErr']);
				return $Data;
			}
			$PayLog = $this->GetAjaxPayLog(array('money'=>$this->Config['PluginVar']['ResumeSeeMoney'],'event'=>'resume_see_log','insert'=>$GetData,'rid'=>$Id,'slid'=>$SeeLog['id']));
			$Data['Money'] = $this->Config['PluginVar']['ResumeSeeMoney'];
			$Data['PayId'] = $PayLog['Id'];
			$Data['State'] = 200;
		}else{//��ѹ���
			
			if($UserInfo['company']['resume_package_count']){//������
				if($UserInfo['company']['vip'] && $UserInfo['company']['resume_day_count'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResumeSeeLog).' where company_id = '.intval($UserInfo['company']['id']).' and updateline >= '.strtotime(date('Y-m-d')).' and updateline <='.strtotime(date('Y-m-d 23:59:59'))) >= $UserInfo['company']['resume_day_count']){//����ÿ�մ�����ѯ
					$Data['State'] = 202;
					$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeDayCountErr']);
					return $Data;
				}else if(!$UserInfo['company']['vip'] && $this->Config['PluginVar']['ResumeDayDownCount'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResumeSeeLog).' where company_id = '.intval($UserInfo['company']['id']).' and updateline >= '.strtotime(date('Y-m-d')).' and updateline <='.strtotime(date('Y-m-d 23:59:59'))) >= $this->Config['PluginVar']['ResumeDayDownCount']){//��������
					$Data['State'] = 202;
					$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeDayCountToErr']);
					return $Data;
				}
				$GetData['mode'] = $UpData['mode'] = 3;
				DB::query("UPDATE ".DB::table($this->TableCompany)." SET resume_package_count = resume_package_count - 1 WHERE id = ".intval($UserInfo['company']['id']));

			}else if($UserInfo['company']['vip']){

				$GetData['mode'] = $UpData['mode'] = 2;

				if($UserInfo['company']['resume_count'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResumeSeeLog).' where company_id = '.intval($UserInfo['company']['id']).' and mode = 2') >= $UserInfo['company']['resume_count']){//����������ѯ
					if($UserInfo['company']['money'] >= intval($this->Config['PluginVar']['ResumeSeeMoney'])){
						$this->InsertCompanyWalletLog($UserInfo['company']['id'],$this->Config['PluginVar']['ResumeSeeMoney'],$this->Config['LangVar']['CompanyWalletBalanceTypeArray']['3'].$GetData['rid']);
						DB::query("UPDATE ".DB::table($this->TableCompany)." SET money = money - ".intval($this->Config['PluginVar']['ResumeSeeMoney'])." WHERE id = ".intval($UserInfo['company']['id']));
						$GetData['mode'] = $UpData['mode'] = 4;
					}else{
						$Data['State'] = 202;
						$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeCountErr']);
						return $Data;
					}
				}else if(!$UserInfo['company']['resume_count'] && $UserInfo['company']['money'] && $UserInfo['company']['money'] >= intval($this->Config['PluginVar']['ResumeSeeMoney'])){
					$this->InsertCompanyWalletLog($UserInfo['company']['id'],$this->Config['PluginVar']['ResumeSeeMoney'],$this->Config['LangVar']['CompanyWalletBalanceTypeArray']['3'].$GetData['rid']);
					DB::query("UPDATE ".DB::table($this->TableCompany)." SET money = money - ".intval($this->Config['PluginVar']['ResumeSeeMoney'])." WHERE id = ".intval($UserInfo['company']['id']));
					$GetData['mode'] = $UpData['mode'] = 4;
				}
				
				if($UserInfo['company']['resume_day_count'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResumeSeeLog).' where company_id = '.intval($UserInfo['company']['id']).' and mode = 2 and updateline >= '.strtotime(date('Y-m-d')).' and updateline <='.strtotime(date('Y-m-d 23:59:59'))) >= $UserInfo['company']['resume_day_count']){//����ÿ�մ�����ѯ
					$Data['State'] = 202;
					$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeDayCountErr']);
					return $Data;
				}
			}	

			$UpData['updateline'] = time();
			if($SeeLog){
				if(DB::update($this->TableResumeSeeLog,$UpData,'id = '.intval($SeeLog['id']))){
					$Data['State'] = 201;
					$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeSeeLogOk']);
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
				}
			}else{
				$SeeLogId = DB::insert($this->TableResumeSeeLog,$GetData,true);
				if($SeeLogId){
					DB::query("UPDATE ".DB::table($this->TableResume)." SET down_count = down_count + 1 WHERE uid = ".intval($Id));
					$Data['State'] = 201;
					$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeSeeLogOk']);
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
				}
			}
			if($Data['State'] == 201){//��Ϣ֪ͨ
				//��Ϣ֪ͨ
				$NoticeMsg = str_replace(array('{company_name}'),array($UserInfo['company']['id'] ? $UserInfo['company']['name'] : $_G['username']),$this->Config['LangVar']['DownResumePushInfo']);
				$PushUrl = $UserInfo['company']['id'] ? $this->Rewrite('view_company',array('cid'=>$UserInfo['company']['id'])) : $this->Config['UserUrl'];
				$WxUserInfo = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where uid = '.intval($Id));
				if($this->Config['PluginVar']['NoticeTemplate'] && $WxUserInfo['openid']){//ģ����Ϣ֪ͨ
					$TemplateParam = array(
						'touser' => $WxUserInfo['openid'],
						'template_id' => $this->Config['PluginVar']['NoticeTemplate'],
						'url' => $PushUrl,
						'topcolor' => '#ff0000',
						'data' =>array(
							'first'=>array('value'=>diconv($this->Config['LangVar']['NewsNotice'], CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['Color']),
							'keyword1'=>array('value'=>diconv($NoticeMsg, CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['FFColor']),
							'keyword2'=>array('value'=>date('Y-m-d H:i',time()),'color'=>$this->Config['PluginVar']['FColor']),
							'remark'=>array('value'=>'')
						)
					);
					@require_once libfile('class/wechat','plugin/fn_assembly');
					$WechatClient = new Fn_WeChatClient($this->Config['PluginVar']['WxAppid'],$this->Config['PluginVar']['WxSecret']);
					$WechatClient->send_weixintemplate(json_encode($TemplateParam));
				}else{
					if(DzNotice){
						notification_add($Id,'system','<a href="{url}">{msg}</a>',array(
							'url'=>$PushUrl,
							'msg'=>$NoticeMsg
						),1);//ϵͳ֪ͨ
					}
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Id;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
						"link"=> $PushUrl,
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv($NoticeMsg,CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}
			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = $Id;
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv($NoticeMsg,CHARSET,'UTF-8'),
					'url'=>$PushUrl
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
			//��Ϣ֪ͨEnd
		}
		return $Data;
	}

	/* ��˾�鿴��ϵ��ְλ�б� */
	public function GetAjaxUserResumeSeeLogList($Get){
		global $_G;
		$Results = array();
		$Get = EncodeURIToUrldeCode($Get);
		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		$Where = $Get['company_id'] ? ' and SL.company_id = '.intval($Get['company_id']) : ' and SL.uid = '.intval($_G['uid']);
		$Order = 'SL.updateline';

		if($this->Config['PluginVar']['ResumeSeeDueTime']){
			$Where .= ' and SL.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ResumeSeeDueTime'])." day",time());
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];
		
		$Results = $this->ResumeListFormat(DB::fetch_all("SELECT SI.sign,R.*,SL.updateline as see_dateline,SL.id as slid FROM (%t AS SL,%t AS R) LEFT JOIN `".DB::table($this->TableResumeSign)."` SI on SI.rid = R.uid and ".($Get['company_id'] ? 'SI.company_id = SL.company_id' : 'SI.uid = SL.uid')." ".$Where." And R.uid = SL.rid order by ".$Order." desc,SL.id desc ".$Limit,array($this->TableResumeSeeLog,$this->TableResume)));
		return $Results;
	}

	/* ����������ϵ��ʽ */
	public function GetUserResumeSeeLogFirst($rid = null){
		global $_G;
		$UserInfo = $this->GetUserInfo();
		return DB::fetch_first('SELECT S.id,S.rid,SI.sign FROM '.DB::table($this->TableResumeSeeLog).' S LEFT JOIN '.DB::table($this->TableResumeSign).' SI on SI.rid = S.rid and '.($UserInfo['company']['id'] ? 'SI.company_id = S.company_id' : ' SI.uid = S.uid ').' where '.($UserInfo['company']['id'] ? 'S.company_id = '.intval($UserInfo['company']['id']) : ' S.uid = '.intval($_G['uid'])).($this->Config['PluginVar']['ResumeSeeDueTime'] ? ' and S.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ResumeSeeDueTime'])." day",time()) : '').' and S.rid = '.intval($rid).' order by id desc');
	}

	/* �鿴��ϵ��ʽId */
	public function GetUserResumeSeeLogArray(){
		global $_G;
		$UserInfo = $this->GetUserInfo();
		$Array = DB::fetch_all('SELECT id,rid FROM '.DB::table($this->TableResumeSeeLog).' where '.($UserInfo['company']['id'] ? 'company_id = '.intval($UserInfo['company']['id']) : ' uid = '.intval($_G['uid'])).($this->Config['PluginVar']['ResumeSeeDueTime'] ? ' and updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ResumeSeeDueTime'])." day",time()) : '').' order by id desc');
		foreach($Array as $Key => $Val) {
			$IdArray[$Val['id']] = $Val['rid'];
		}
		return $IdArray;
	}

	/* ��������-��� */
	public function GetAjaxInterviewJob($Get){
		global $_G,$Config;

		$Get = EncodeURIToUrldeCode($Get);

		$ResumeItem = $this->GetViewResumethread($Get['rid']);
		if(!$ResumeItem){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoViewResumeData']);
			return $Data;
		}
		
		$UserInfo = $this->GetUserInfo();
		if(!$UserInfo['company']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['InterviewNoCompanyErr']);
			$Data['State'] = 203;
			return $Data;
		}

		$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableResumeSeeLog).' where id = '.intval($Get['iid']));
		$UpData['company_id'] = intval($UserInfo['company']['id']);
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['title'] = addslashes(strip_tags($Get['title']));
		$UpData['rid'] = intval($Get['rid']);
		$UpData['contacts'] = addslashes(strip_tags($Get['contacts']));
		$UpData['mobile'] = addslashes(strip_tags($Get['mobile']));
		$UpData['interview_dateline'] = $Get['interview_dateline'] ? strtotime($Get['interview_dateline']) : '';
		$UpData['address'] = addslashes(strip_tags($Get['address']));
		$UpData['content'] = addslashes(strip_tags($Get['content']));
		
		if(!$UpData['title']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['IntervieJobTips']);
			return $Data;
		}

		if(!$UpData['contacts']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactPlaceholder']);
			return $Data;
		}

		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		$IsLandline = "/".$Config['PluginVar']['LandlineMatch']."/";
		if(!$UpData['mobile']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactNumberPlaceholder']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['mobile']) && !preg_match($IsLandline,$UpData['mobile'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
			return $Data;
		}

		if(!$UpData['interview_dateline']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['InterviewDatelineTips']);
			return $Data;
		}

		if(!$UpData['address']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['InterviewAddressTips']);
			return $Data;
		}
		$UpData['param'] = serialize($Param);
		if($Item){//����
			$UpData['updateline'] = time();
			if(DB::update($this->TableInterview,$UpData,'id = '.intval($Item['id']))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['InterviewSuccess']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['InterviewFail']);
			}
		}else{//���
			$UpData['dateline'] = $UpData['updateline'] = time();
			$Id = DB::insert($this->TableInterview,$UpData,true);
			if($Id){
				$Data['Id'] = $Id;
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['InterviewSuccess']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['InterviewFail']);
			}
		}

		if($Data['State'] == 200){
			//��Ϣ֪ͨ
			$ResumeItem['full_name'] = $this->Config['PluginVar']['ResumeNameSwitch'] ? $ResumeItem['full_name'] : cutstr($ResumeItem['full_name'],3,'').$this->Config['LangVar']['SexToArray'][$ResumeItem['sex']];

			$NoticeMsg = str_replace(array('{title}','{company}','{contacts}','{mobile}','{interview_dateline}','{address}'),array($UpData['title'],$UserInfo['company']['name'],$UpData['contacts'],$UpData['mobile'],date('Y-m-d H:i',$UpData['interview_dateline']),$UpData['address']),$this->Config['LangVar']['InterviewPush']);
			$NoticeMsg = $UpData['content'] ? $NoticeMsg.str_replace(array('{content}'),array($UpData['content']),$this->Config['LangVar']['InterviewPushContent']) : $NoticeMsg;

			$PushUrl = $UserInfo['company'] ? $this->Config['ViewCompanyUrl'].$UserInfo['company']['id'] : $this->Config['UserResumeInterviewListUrl'];
				
			$WxUserInfo = DB::fetch_first('SELECT * FROM '.DB::table($this->TableMember).' where uid = '.intval($ResumeItem['uid']));
			if($this->Config['PluginVar']['InterviewTemplate'] && $WxUserInfo['openid']){//ģ����Ϣ֪ͨ
				$TemplateParam = array(
					'touser' => $WxUserInfo['openid'],
					'template_id' => $this->Config['PluginVar']['InterviewTemplate'],
					'url' => $PushUrl,
					'topcolor' => '#ff0000',
					'data' =>array(
						'first'=>array('value'=>diconv($this->Config['LangVar']['InterviewTemplateTitle'], CHARSET, 'UTF-8'),'color'=>$this->Config['PluginVar']['Color']),
						'job'=>array('value'=>diconv($UpData['title'], CHARSET, 'UTF-8'),'color'=>'#ff0000'),
						'company'=>array('value'=>diconv($UserInfo['company']['name'], CHARSET, 'UTF-8'),'color'=>'#ff0000'),
						'time'=>array('value'=>date('Y-m-d H:i',$UpData['interview_dateline']),'color'=>'#ff0000'),
						'address'=>array('value'=>diconv($UpData['address'], CHARSET, 'UTF-8'),'color'=>'#ff0000'),
						'contact'=>array('value'=>diconv($UpData['contacts'], CHARSET, 'UTF-8'),'color'=>'#ff0000'),
						'tel'=>array('value'=>diconv($UpData['mobile'], CHARSET, 'UTF-8'),'color'=>'#ff0000'),
						'remark'=>array('value'=>$UpData['content'])
					)
				);
				@require_once libfile('class/wechat','plugin/fn_assembly');
				$WechatClient = new Fn_WeChatClient($this->Config['PluginVar']['WxAppid'], $this->Config['PluginVar']['WxSecret']);
				$WechatClient->send_weixintemplate(json_encode($TemplateParam));
			}else{
				if(DzNotice){
					notification_add($ResumeItem['uid'],'system','<a href="{url}">{msg}</a>',array(
						'url'=>$PushUrl,
						'msg'=>$NoticeMsg
					),1);//ϵͳ֪ͨ
				}
			}
				
			if($Config['PluginVar']['AppType'] == 1){//������������
				$PushData['Uid'] = $ResumeItem['uid'];
				$PushData['Type'] = 'pictemp';
				$PushData['Content'] = array(
					"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
					"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
					"link"=> $PushUrl,
					"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
					"extra_info"=>array(
						array(
							"key"=>'',
							"val"=>diconv($NoticeMsg,CHARSET,'UTF-8')
						)
					)
				);
				$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
			}else if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = $ResumeItem['uid'];
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['NewsNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv($NoticeMsg,CHARSET,'UTF-8'),
					'url'=>$PushUrl
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}

			if($this->Config['PluginVar']['ShortMessageSwitch']){//����֪ͨ
				$NoticeSms = str_replace(array('{name}'),array($ResumeItem['full_name']),$this->Config['LangVar']['InterviewSmsPush']);
				@require_once libfile('class/short_message','plugin/fn_assembly');
				if($Config['PluginVar']['ShortMessageType'] == 1){
					$TemplateCode = $this->Config['PluginVar']['AliNoticeId'];
					$TemplateParam = array('remark'=>$NoticeSms);
				}else if($Config['PluginVar']['ShortMessageType'] == 2){
					$TemplateCode = str_replace(array('{Msg}'),array($NoticeSms),$this->Config['PluginVar']['ChanyooNotice']);
					$TemplateParam = array();
				}
				$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$ResumeItem['mobile'],$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$ResumeItem['uid'],$ResumeItem['username'],'fn_job',2);
			}
			//��Ϣ֪ͨEnd
		}
		return $Data;
	}

	/* ��˾���������б� */
	public function GetAjaxUserCompanyInterviewList($Get){
		global $_G;
		$Results = array();
		$Get = EncodeURIToUrldeCode($Get);
		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		$Where = ' and I.company_id = '.intval($Get['company_id']);
		$Order = 'I.updateline';

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$Results = $this->ResumeListFormat(DB::fetch_all("SELECT R.*,I.title as i_title,I.interview_dateline,I.updateline as see_dateline,I.id as iid,I.content as i_content FROM %t AS I,%t AS R ".$Where." And R.uid = I.rid order by ".$Order." desc,I.id desc ".$Limit,array($this->TableInterview,$this->TableResume)));
		return $Results;
	}

	/* ��ְ�����������б� */
	public function GetAjaxUserResumeInterviewList($Get){
		global $_G;
		$Results = array();
		$Get = EncodeURIToUrldeCode($Get);
		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		$Where = ' and I.rid = '.intval($_G['uid']);
		$Order = 'I.updateline';

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$Results = $this->CompanyListFormat(DB::fetch_all("SELECT C.*,I.title as i_title,I.interview_dateline,I.updateline as i_updateline,I.id as iid,I.content as i_content,I.contacts as i_contacts,I.mobile as i_mobile,I.address as i_address,I.state as i_state,AG.title,AG.ico,AGL.day_refresh_count,AGL.day_info_count,AGL.info_count,AGL.resume_count,AGL.resume_day_count,AGL.examine,AGL.refresh_count,AGL.top_discount FROM %t AS I,%t AS C LEFT JOIN `".DB::table($this->TableCompanyGroup)."` AG on AG.id = C.group_id LEFT JOIN `".DB::table($this->TableCompanyGroupLog)."` AGL on AGL.company_id = C.id ".$Where." And C.id = I.company_id order by ".$Order." desc,I.id desc ".$Limit,array($this->TableInterview,$this->TableCompany)));
		return $Results;
	}

	/* �ҵ��������� */
	public function GetUserInterviewFirst($CompanyId,$Id){
		return DB::fetch_first('SELECT * FROM '.DB::table($this->TableInterview).' where company_id = '.intval($CompanyId).' and rid = '.intval($Id).' order by id desc');
	}

	/* ��������Id */
	public function GetUserInterviewIdArray(){
		global $_G;
		$Array = DB::fetch_all('SELECT rid FROM '.DB::table($this->TableInterview).' where company_id = '.intval($_G['uid']).' order by id desc');
		foreach($Array as $Key => $Val) {
			$IdArray[] = $Val['rid'];
		}
		return $IdArray;
	}

	/* ��˾ɾ���������� */
	public function GetAjaxDelCompanyInterview($Id){
		global $_G;
		$UserInfo = $this->GetUserInfo();
		if(DB::delete($this->TableInterview,'company_id ='.intval($UserInfo['company']['id']).' and id = '.intval($Id))){
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
		}
		return $Data;
	}

	/* �ղ�ְλ */
	public function GetAjaxInfoCollect($Id){
		global $_G;
		$GetData['uid'] = intval($_G['uid']);
		$GetData['username'] = addslashes(strip_tags($_G['username']));
		$GetData['iid'] = intval($Id);
		$GetData['dateline'] = time();
		
		$Collect = DB::fetch_first('SELECT * FROM '.DB::table($this->TableInfoCollection).' where uid = '.$GetData['uid'].' and iid = '.$GetData['iid']);

		if($Collect){
			DB::delete($this->TableInfoCollection,'uid ='.$GetData['uid'].' and iid = '.$GetData['iid']);
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['DelCollectionTitle']);
		}else{
			if(DB::insert($this->TableInfoCollection,$GetData)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['OkCollectionTitle']);
			}
		}
		return $Data;
	}

	/* �ҵ��ղ�ְλID */
	public function GetUserInfoCollectArray(){
		global $_G;
		$MyCollectArray = DB::fetch_all('SELECT iid FROM '.DB::table($this->TableInfoCollection).' where uid = '.intval($_G['uid']).' order by id desc');
		foreach($MyCollectArray as $Key => $Val) {
			$MyCollectIdArray[] = $Val['iid'];
		}
		return $MyCollectIdArray;
	}

	/* ���ղص�ְλ */
	public function GetUserInfoCollectionLogList(){
		global $_G;
		$Where = ' and C.uid = '.intval($_G['uid']);
		$Order = 'C.dateline';
		$Where = preg_replace('/and/','where',$Where,1);
		return $this->InfoListFormat(DB::fetch_all("SELECT I.*,CC.id as cid,CC.name,CC.content as c_content,CC.param as c_param,CC.due_time,CC.vip_stop,CC.logo,CC.type as c_type,CC.verify,G.ico FROM %t AS C,%t AS I LEFT JOIN `".DB::table($this->TableCompany)."` CC on CC.id = I.company_id LEFT JOIN `".DB::table($this->TableCompanyGroup)."` G on G.id = CC.group_id ".$Where." And I.id = C.iid order by ".$Order." desc,C.id desc",array($this->TableInfoCollection,$this->TableInfo)));
	}
	
	/* ְλƥ���˲� */
	public function GetAjaxUserResumeMatchingList($Get,$Count = false){
		global $_G;
		$Results = array();
		$Get = EncodeURIToUrldeCode($Get);
		$Page = $Get['page'] ? intval($Get['page']) - 1 : 0 ;

		$Where = ' and R.display = 1 and R.state = 1';
		$Order = 'R.updateline';

		if($this->Config['PluginVar']['ResumeExpiryTime']){
			$Where .= ' and ( R.updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ResumeExpiryTime'])." day",time()).' or R.topdateline >= '.time().' ) ';
		}
		
		$Item = $this->GetViewthread($Get['iid']);
		$ClassId = $Item['classid'] ? $Item['classid'] : ($Item['bclassid'] ? $Item['bclassid'] : $Item['bbclassid']);
		$Where .= ' and (R.expect_job like(\'%'.$this->ClassList[$ClassId]['content'].'%\') or FIND_IN_SET(\''.$ClassId.'\',R.expect_job_classid)) ';
		
		$Uids = array($Item['uid']);
		foreach(DB::fetch_all("SELECT uid FROM ".DB::table($this->TableInfoApplyLog).' where iid = '.$Item['id']) as $Key => $Val) {
			$Uids[] = $Val['uid'];
		}
		if($Uids){
			$Where .= ' and R.uid not in('.implode(',',$Uids).')';
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $Get['limit'] ? $Get['limit'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$Results = $Count ? DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResume).' R '.$Where) : $this->ResumeListFormat(DB::fetch_all("SELECT R.* FROM ".DB::table($this->TableResume)." AS R ".$Where." GROUP BY R.uid order by R.topdateline > ".time()." desc,".$Order." desc,R.dateline desc ".$Limit));

		return $Results;
	}

	/* �ٱ�ְλ */
	public function GetAjaxReport($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$GetData['uid'] = intval($_G['uid']);
		$GetData['username'] = addslashes(strip_tags($_G['username']));
		$GetData['ip'] = addslashes(strip_tags($_G['clientip']));
		$GetData['iid'] = intval($Get['iid']);
		$GetData['content'] = censor(addslashes(strip_tags($Get['content'])));
		$GetData['state'] = 0;
		$GetData['dateline'] = time();
		
		$UserInfo = $this->GetUserInfo();
		if(!$UserInfo['resume'] && $this->Config['PluginVar']['ReportResumeSwitch']){
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoResumeReportErr']);
			return $Data;
		}

		if($UserInfo['resume'] && $this->Config['PluginVar']['ReportResumeSwitch'] && $this->Config['PluginVar']['ReportResumeDisplay'] && !$UserInfo['resume']['display']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeReportDisplayErr']);
			return $Data;
		}

		if(in_array($_G['uid'],array_filter(explode(",",$this->Config['PluginVar']['ReportProhibitUis'])))){//���ξٱ�
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportProhibitErr']);
			return $Data;
		}
		
		if($this->Config['PluginVar']['ReportNum'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfoReport).' where uid = '.intval($_G['uid']).' and iid = '.intval($Get['iid'])) >= $this->Config['PluginVar']['ReportNum']){
			$Data['Msg'] = urlencode(str_replace(array('{num}'),array($this->Config['PluginVar']['ReportNum']),$this->Config['PluginVar']['ReportNumTips']));
			return $Data;
		}

		if(!$GetData['content']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportContentErr']);
			return $Data;
		}
		if(DB::insert($this->TableInfoReport,$GetData)){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportOk']);
			$Data['State'] = 200;

			//��Ϣ֪ͨ
			$Msg = str_replace(array('{Content}'),array($GetData['content']),$this->Config['LangVar']['ReportPush']);
			$Item = $this->GetViewthread($Get['iid']);

			foreach($this->AdminUidsList as $Key => $Val) {//����Ա֪ͨ
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$this->Config['ViewJobUrl'].$GetData['iid'],
						'msg'=>$Msg
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['ViewJobUrl'].$GetData['iid'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv($Msg,CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}
			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv($Msg,CHARSET,'UTF-8'),
					'url'=>$this->Config['ViewJobUrl'].$GetData['iid']
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
			//��Ϣ֪ͨEnd

		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportErr']);
		}
		return $Data;
	}
	
	//�����ŵ�/��˾����
	public function GetAjaxUserCompany($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$UserInfo = $this->GetUserInfo();
		$UpData['uid'] = $UserInfo['company']['uid'] ? intval($UserInfo['company']['uid']) : intval($_G['uid']);
		$UpData['username'] = $UserInfo['company']['username'] ? addslashes(strip_tags($UserInfo['company']['username'])) : addslashes(strip_tags($_G['username']));
		$UpData['name'] = censor(addslashes(strip_tags($Get['name'])));
		$UpData['type'] = intval($Get['type']);
		$UpData['scale'] = intval($Get['scale']);
		$UpData['classid'] = intval($Get['classid']);
		$UpData['province'] = addslashes(strip_tags($Get['province']));
		$UpData['city'] = addslashes(strip_tags($Get['city']));
		$UpData['dist'] = addslashes(strip_tags($Get['dist']));
		$UpData['community'] = addslashes(strip_tags($Get['community']));
		$UpData['lat'] = addslashes(strip_tags($Get['lat']));
		$UpData['lng'] = addslashes(strip_tags($Get['lng']));
		$UpData['contacts'] = censor(addslashes(strip_tags($Get['contacts'])));
		$UpData['mobile'] = trim(addslashes(strip_tags($Get['mobile'])));
		$UpData['sms_mobile'] = trim(addslashes(strip_tags($Get['sms_mobile'])));
		$UpData['content'] = addslashes(str_replace("\r\n","<br>",$Get['content']));
		$UpData['tag'] = addslashes(strip_tags($Get['tag']));
		foreach(array_filter(explode(",",$UpData['tag'])) as $Key => $Val) {
			if($this->Config['LangVar']['WelfareArray'][$Val]){
				$Param['tag_list'][] = $this->Config['LangVar']['WelfareArray'][$Val];
			}
		}
		$UpData['display'] = $UserInfo['company'] ? ($this->Config['PluginVar']['CompanyEditSwitch'] ? 0 : $UserInfo['company']['display']) : ($this->Config['PluginVar']['CompanyDisplaySwitch'] ? 0 : 1);
		
		foreach(array_filter(explode(';',$Get['new_logo'][0])) as $Key => $Val) {
			$Get['new_logo'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$UpData['logo'] = $Get['new_logo'][0];

		foreach(array_filter(explode(';',$Get['new_license'][0])) as $Key => $Val) {
			$Get['new_license'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['license'] = $Get['new_license'][0];

		foreach(array_filter(explode(';',$Get['new_album'][0])) as $Key => $Val) {
			$Get['new_album'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['album'] = is_array($Get['new_album']) && isset($Get['new_album']) ? $Get['new_album'] : '';
		
		if(!$UpData['logo'] && $this->Config['PluginVar']['CompanyLogoSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['UploadLogoTips']);
			return $Data;
		}

		if(!$Param['license'] && $this->Config['PluginVar']['CompanyLicenseSwitch'] && !$UserInfo['company']['verify']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['UploadLicenseTips']);
			return $Data;
		}
		
		if(!$UpData['name']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyNameErr']);
			return $Data;
		}else if(!$UserInfo['company']['name_verify'] && $this->Config['PluginVar']['CompanyNameSwitch'] && $UpData['name']){
			
			$headers = array();
			array_push($headers, "Authorization:APPCODE " . $this->Config['PluginVar']['ApiAppCode']);
			
			$url = 'https://bankpros.market.alicloudapi.com/comdata';

			$Res = json_decode(CurlPost($url,array('com'=>diconv($UpData['name'],CHARSET,'UTF-8')),$headers),true);
			
			if($Res['error_code'] !== 0){
				$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyNameErr2']);
				return $Data;
			}else{
				$UpData['name_verify'] = 1;
			}
		}

		if(!$UpData['scale']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ScalePlaceholder']);
			return $Data;
		}

		if(!$UpData['classid'] && $this->Config['PluginVar']['CompanyClassSwitch'] && $this->Config['PluginVar']['CompanyClassMust']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ClassPlaceholder']);
			return $Data;
		}
		
		if(!$UpData['province']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RegionPlaceholder']);
			return $Data;
		}

		if(!$UpData['lat'] && !$UpData['lng'] && $this->Config['PluginVar']['CompanyMapSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['TaggingTips']);
			return $Data;
		}

		if(!$UpData['community']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CompanyCommunityPlaceholder']);
			return $Data;
		}

		if(!$UpData['contacts']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactPlaceholder']);
			return $Data;
		}

		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		$IsLandline = "/".$Config['PluginVar']['LandlineMatch']."/";
		if(!$UpData['mobile']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactNumberPlaceholder']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['mobile']) && !preg_match($IsLandline,$UpData['mobile'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
			return $Data;
		}

		if(!$UpData['sms_mobile'] && $this->Config['PluginVar']['CompanySmsMobileSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ShortMessageTelTips']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['sms_mobile']) && $this->Config['PluginVar']['CompanySmsMobileSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr']);
			return $Data;
		}

		//��֤���ж�
		if($this->Config['PluginVar']['CompanyMobileSwitch']){
			if(($UserInfo['company'] && $UpData['mobile'] != $UserInfo['company']['mobile']) || ($UserInfo['company'] && !$UserInfo['mobile_verify']) || (!$UserInfo['company'])){
				if(!$Get['code']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['CodePlaceholder']);
					if($UserInfo['company'] && $UpData['mobile'] != $UserInfo['company']['mobile']){
						$Data['State'] = 202;
					}
					return $Data;
				}
				$CheckSendSmsLog = DB::fetch_first('SELECT * FROM '.DB::table('fn_send_sms_log').' where state = 200 and cache_dateline > '.time().' and uid = '.intval($_G['uid']).' and mobile = '.$UpData['mobile'].' and code = '.$Get['code'].' and sms_type = 1 order by id desc');
				if(!$CheckSendSmsLog){
					$Data['Msg'] = urlencode($this->Config['LangVar']['CodeErr']);
					return $Data;
				}
				$UpData['mobile_verify'] = 1;
			}
		}
		//��֤���ж� End

		$UpData['param'] = serialize($Param);

		!$UserInfo['uid'] ? DB::insert($this->TableMember,array('uid'=>$UpData['uid'],'username'=>$UpData['username'],'identity'=>1,'dateline'=>time(),'updateline'=>time())) : '';//���ݱ�ʶ

		if($UserInfo['company']){//����
			$Data['Id'] = $UserInfo['company']['id'];

			if(DB::update($this->TableCompany,$UpData,'id = '.intval($UserInfo['company']['id']))){
				DB::update($this->TableInfo,array('province'=>$UpData['province'],'city'=>$UpData['city'],'dist'=>$UpData['dist'],'community'=>$UpData['community']),'company_id = '.$UserInfo['company']['id']);
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);	
			}
		}else{//���
			$UpData['dateline'] = $UpData['updateline'] = time();
			$Data['Id'] = DB::insert($this->TableCompany,$UpData,true);
			$Data['State'] = !$UpData['display'] ? 200 : 201;
			$Data['Msg'] = urlencode(!$UpData['display'] ? $this->Config['LangVar']['AddOk'].'<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : $this->Config['LangVar']['AddCompanyOk']);
		}

		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_crm')){
			@require_once (DISCUZ_ROOT.'./source/plugin/fn_crm/Function.inc.php');
			if(!DB::fetch_first('SELECT * FROM '.DB::table($Fn_Crm->TableCustomer).' where project = \'fn_job\' and  project_id = '.$Data['Id'])){
				DB::insert($Fn_Crm->TableCustomer,array('name'=>$UpData['name'],'decision_name'=>$UpData['contacts'],'project'=>'fn_job','project_id'=>$Data['Id'],'decision_mobile'=>$UpData['mobile'],'dateline'=>time()));
			}
		}
		
		//��Ϣ֪ͨ
		if((!$UpData['display'] && !$UserInfo['company']) || ($UserInfo['company'] && $this->Config['PluginVar']['CompanyEditSwitch'] && !$UpData['display'])){
			foreach($this->AdminUidsList as $Key => $Val) {
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$this->Config['ViewCompanyUrl'].$Data['Id'],
						'msg'=>str_replace(array('{Title}'),array($UpData['name']),$this->Config['LangVar']['CompanyPush'])
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['ViewCompanyUrl'].$Data['Id'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv(str_replace(array('{Title}'),array($UpData['name']),$this->Config['LangVar']['CompanyPush']),CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}
			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv(str_replace(array('{Title}'),array($UpData['name']),$this->Config['LangVar']['CompanyPush']),CHARSET,'UTF-8'),
					'url'=>$this->Config['ViewCompanyUrl'].$Data['Id']
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
		}
		//��Ϣ֪ͨEnd

		return $Data;
	}

	//�޸Ĺ�˾���ص绰״̬
	public function GetAjaxCompanyHideMobile(){
		global $_G,$Config;
		$UserInfo = $this->GetUserInfo();
		if(!$UserInfo['company']){//����
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoViewCompanyData']);
			return $Data;
		}
		if(DB::update($this->TableCompany,array('hide_mobile'=>$UserInfo['company']['hide_mobile'] ? 0 : 1),'id = '.intval($UserInfo['company']['id']))){
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
		}
		return $Data;
	}

	/* ��ͨ�ײ� */
	public function GetAjaxBuyStoreLevel($Get){
		global $_G;
		$ItemGroup = DB::fetch_first('SELECT * FROM '.DB::table($this->TableCompanyGroup).' where id = '.$Get['group_id']);
		if(!$ItemGroup){
			$Data['Msg'] = urlencode($this->Config['LangVar']['PayErr']);
		}else{
			$UserInfo = $this->GetUserInfo();
			if($ItemGroup['money']){
				$PayLog = $this->GetAjaxPayLog(array('money'=>$ItemGroup['money'],'event'=>'buy_store_level','company_id'=>$UserInfo['company']['id'],'group_id'=>$ItemGroup['id'],'month'=>$ItemGroup['group_time']));
				$Data['Money'] = $ItemGroup['money'];
				$Data['PayId'] = $PayLog['Id'];
				$Data['State'] = 200;
			}else{
				$UpData['group_id'] = $ItemGroup['id'];
				$UpData['due_time'] = $UserInfo['company']['due_time'] >= time() && $UserInfo['group_id'] == $ItemGroup['id'] ? strtotime("+".intval($ItemGroup['group_time'])."  month",$UserInfo['company']['due_time']) : strtotime("+".intval($ItemGroup['group_time'])."  month",time());
				DB::update($this->TableCompany,$UpData,'id = '.$UserInfo['company']['id']);

				
				/* Ȩ������ */
				$GroupLogItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableCompanyGroupLog).' where company_id = '.$UserInfo['company']['id']);
				
				$GroupLogUpData['refresh_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? ($UserInfo['company']['vip'] ? $ItemGroup['refresh_count'] + $GroupLogItem['refresh_count'] : $ItemGroup['refresh_count'] + $UserInfo['company']['use_refresh_count']) : $ItemGroup['refresh_count'];

				$GroupLogUpData['info_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? ($UserInfo['company']['vip'] ? $ItemGroup['info_count'] + $GroupLogItem['info_count'] : $ItemGroup['info_count'] + $UserInfo['company']['use_info_count']) : $ItemGroup['info_count'];

				$GroupLogUpData['resume_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? ($UserInfo['company']['vip'] ? $ItemGroup['resume_count'] + $GroupLogItem['resume_count'] : $ItemGroup['resume_count'] + $UserInfo['company']['use_resume_count']) : $ItemGroup['resume_count'];
				
				$GroupLogUpData['day_refresh_count'] = $ItemGroup['day_refresh_count'];
				$GroupLogUpData['day_info_count'] = $ItemGroup['day_info_count'];
				$GroupLogUpData['resume_day_count'] = $ItemGroup['resume_day_count'];
				$GroupLogUpData['examine'] = $ItemGroup['examine'];
				$GroupLogUpData['top_discount'] = $ItemGroup['top_discount'];
				$GroupLogUpData['hot'] = $ItemGroup['hot'];
				$GroupLogUpData['refresh_type'] = $ItemGroup['refresh_type'];
				$GroupLogUpData['apply_resume'] = $ItemGroup['apply_resume'];
				$GroupLogUpData['hide'] = $ItemGroup['hide'];
				$GroupLogUpData['company_id'] = $UserInfo['company']['id'];


				$GroupLogItem ? DB::update($this->TableCompanyGroupLog,$GroupLogUpData,'company_id = '.$UserInfo['company']['id']) : DB::insert($this->TableCompanyGroupLog,$GroupLogUpData);
				/* Ȩ������ */

				$Data['Msg'] = urlencode($UserInfo['company']['vip'] ? $this->Config['LangVar']['BuyStoreLevelRenewOk'] : $this->Config['LangVar']['BuyStoreLevelOpenOK']);
				$Data['State'] = 201;
			}
			
		}
		return $Data;
	}

	/* ��������� */
	public function GetAjaxResumePackage($Get){
		global $_G;
		$UserInfo = $this->GetUserInfo();
		if(!$UserInfo['company']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumePackageBuyErr']);
			$Data['State'] = 201;
			return $Data;
		}

		//�Ƿ񷢲���ְλ
		$ResumeDownInfo = $this->Config['PluginVar']['ResumeDownInfoSwitch'] && $UserInfo['company']['id'] && $this->GetAjaxJobCompanyList(array('company_id'=>$UserInfo['company']['id'])) ? true : false;
		if(!$ResumeDownInfo && $this->Config['PluginVar']['ResumeDownInfoSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumePackageInfoTips']);
			$Data['State'] = 202;
			return $Data;
		}

		return $this->GetAjaxPayLog(array('event'=>'resume_package','money'=>$Get['money'],'num'=>$Get['num']));
	}

	/* �ŵ��ײ��б� */
	public function GetCompanyGroupList($where = null){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableCompanyGroup).' '.$where.' order by displayorder desc');//��������
	}

	/* ���������¼ */
	public function InsertCompanyWalletLog($CompanyId,$Money,$Content){
		global $_G;
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['company_id'] = intval($CompanyId);
		$UpData['content'] = addslashes(strip_tags($Content));
		$UpData['money'] = intval($Money);
		$UpData['dateline'] = time();
		if(DB::insert($this->TableCompanyWalletLog,$UpData)){
			return true;
		}else{
			return false;
		}
	}
	//�������
	public function GetAjaxUserResume($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$UserInfo = $this->GetUserInfo();
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['full_name'] = trim(addslashes(strip_tags($Get['full_name'])));
		$UpData['sex'] = intval($Get['sex']);
		$UpData['birth_year'] = intval($Get['birth_year']);
		$UpData['age'] = date('Y',time()) - $UpData['birth_year'];
		$UpData['education'] = intval($Get['education']);
		$UpData['experience'] = intval($Get['experience']);
		$UpData['expect_job'] = addslashes(strip_tags($Get['expect_job']));
		$UpData['expect_job_classid'] = addslashes(strip_tags($Get['expect_job_classid']));
		$UpData['expect_month_wages'] = intval($Get['expect_month_wages']);
		$UpData['expect_province'] = addslashes(strip_tags($Get['expect_province']));
		$UpData['expect_city'] = addslashes(strip_tags($Get['expect_city']));
		$UpData['expect_dist'] = addslashes(strip_tags($Get['expect_dist']));
		$UpData['mobile'] = trim(addslashes(strip_tags($Get['mobile'])));
		$UpData['wx'] = addslashes(strip_tags($Get['wx']));
		$UpData['content'] = addslashes(str_replace("\r\n","<br>",$Get['content']));
		$UpData['tag'] = addslashes(strip_tags($Get['tag']));
		$UpData['special'] = addslashes(strip_tags($Get['special']));
		$UpData['state'] = intval($Get['state']);
		$UpData['display'] = $UserInfo['resume'] ? $UserInfo['resume']['display'] : 1;

		foreach(array_filter(explode(';',$Get['new_face'][0])) as $Key => $Val) {
			$Get['new_face'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$UpData['face'] = $Get['new_face'][0];

		foreach(array_filter(explode(';',$Get['new_works'][0])) as $Key => $Val) {
			$Get['new_works'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['works'] = is_array($Get['new_works']) && isset($Get['new_works']) ? $Get['new_works'] : '';

		foreach(array_filter(explode(';',$Get['new_life'][0])) as $Key => $Val) {
			$Get['new_life'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['life'] = is_array($Get['new_life']) && isset($Get['new_life']) ? $Get['new_life'] : '';

		if($UpData['tag']){
			foreach(array_filter(explode(",",$UpData['tag'])) as $Key => $Val) {
				$Param['tag_list'][] = $this->Config['LangVar']['ResumeTagArray'][$Val];
			}
		}
	
		$Param['work_experience_list'] = array_filter(explode(';',$Get['work_experience'][0])) ? array_filter(explode(';',$Get['work_experience'][0])) : '';
		$Param['educational_experience_list'] = array_filter(explode(';',$Get['educational_experience'][0])) ? array_filter(explode(';',$Get['educational_experience'][0])) : '';

		if(!$UpData['face'] && $this->Config['PluginVar']['ResumeFaceSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['UploadFaceTips']);
			return $Data;
		}

		if(!$UpData['birth_year']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['BirthYearPlaceholder']);
			return $Data;
		}

		if(!$UpData['education']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeEducationPlaceholder']);
			return $Data;
		}

		if(!$UpData['experience']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeExperiencePlaceholder']);
			return $Data;
		}

		if(!$UpData['full_name']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeFullNamePlaceholder']);
			return $Data;
		}

		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		$IsLandline = "/".$Config['PluginVar']['LandlineMatch']."/";
		if(!$UpData['mobile']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactNumberPlaceholder']);
			return $Data;
		}else if(!preg_match($IsMob,$UpData['mobile'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr1']);
			return $Data;
		}

		//��֤���ж�
		if($this->Config['PluginVar']['ResumeMobileSwitch']){
			$CheckProfileData = DB::fetch_first('SELECT * FROM '.DB::table($this->TableResume).' where mobile = '.$UpData['mobile'].' and uid != '.$UpData['uid']);
			if(($UserInfo['resume'] && $UpData['mobile'] != $UserInfo['resume']['mobile']) || (!$UserInfo['resume'])){
				if($CheckProfileData){
					$Data['Msg'] = urlencode($this->Config['LangVar']['MobileRepeatErr']);
					return $Data;
				}
				
				if(!$Get['code']){
					$Data['Msg'] = urlencode($this->Config['LangVar']['CodePlaceholder']);
					if($UserInfo['resume'] && $UpData['mobile'] != $UserInfo['resume']['mobile']){
						$Data['State'] = 201;
					}
					return $Data;
				}
				$CheckSendSmsLog = DB::fetch_first('SELECT * FROM '.DB::table('fn_send_sms_log').' where state = 200 and cache_dateline > '.time().' and uid = '.intval($_G['uid']).' and mobile = '.$UpData['mobile'].' and code = '.$Get['code'].' and sms_type = 1 order by id desc');
				if(!$CheckSendSmsLog){
					$Data['Msg'] = urlencode($this->Config['LangVar']['CodeErr']);
					return $Data;
				}
				$UpData['mobile_verify'] = 1;
			}
		}
		//��֤���ж� End
		
		if($this->Config['PluginVar']['ResumeWxSwitch'] && $this->Config['PluginVar']['ResumeWxNullSwitch']){
			if(!$UpData['wx']){
				$Data['Msg'] = urlencode($this->Config['LangVar']['WxPlaceholder']);
				return $Data;
			}else if(!preg_match("/^[A-Za-z0-9_-]+$/",$UpData['wx'])){
				$Data['Msg'] = urlencode($this->Config['LangVar']['WxChineseErr']);
				return $Data;
			}
		}

		if(!$UpData['expect_job']){
			$Data['Msg'] = urlencode($this->Config['PluginVar']['ResumeExpectJob'] ? $this->Config['LangVar']['ExpectJobPlaceholder'] : $this->Config['LangVar']['ExpectJobPlaceholderTo']);
			return $Data;
		}

		if(!$UpData['expect_month_wages']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ExpectMonthWagesPlaceholder']);
			return $Data;
		}

		if(!$UpData['expect_province'] && $this->Config['PluginVar']['ResumeExpectProvinceRequired']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ExpectRegionPlaceholder']);
			return $Data;
		}

		if(!$UpData['content']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeDescribePlaceholder']);
			return $Data;
		}

		if(!$UpData['content'] && $this->Config['PluginVar']['ResumeContentSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeDescribePlaceholder']);
			return $Data;
		}

		if(!$Param['life'] && $this->Config['PluginVar']['ResumeLifeSwitch'] && $this->Config['PluginVar']['ResumeLifeRequiredSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['LifePlaceholder']);
			return $Data;
		}

		if(!$Param['work_experience_list'] && $this->Config['PluginVar']['ResumeWorkExperienceSwitch'] && !in_array($UpData['experience'],array_filter(explode(',',$this->Config['PluginVar']['ResumeWorkEducation'])))){
			$Data['Msg'] = urlencode($this->Config['LangVar']['WorkExperiencePlaceholder']);
			return $Data;
		}

		if(!$Param['educational_experience_list'] && $this->Config['PluginVar']['ResumeEducationalExperienceSwitch']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['EducationalExperiencePlaceholder']);
			return $Data;
		}

		$UpData['param'] = serialize($Param);
		
		!$UserInfo['uid'] ? DB::insert($this->TableMember,array('uid'=>$UpData['uid'],'username'=>$UpData['username'],'identity'=>2,'dateline'=>time(),'updateline'=>time())) : '';//���ݱ�ʶ
	
		if($UserInfo['resume']){//����
			$UpData['edit_dateline'] = time();
			$UpData['display'] = $this->Config['PluginVar']['ResumeEditDisplaySwitch'] ?  0 : $UpData['display'];
			if(DB::update($this->TableResume,$UpData,'uid = '.intval($_G['uid']))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);	
			}
		}else{//���
			$UpData['display'] = $this->Config['PluginVar']['ResumeDisplaySwitch'] ?  0 : 1;
			$UpData['dateline'] = $UpData['updateline'] = time();
			DB::insert($this->TableResume,$UpData);
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddOk'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));
		}
		
		//��Ϣ֪ͨ
		if(!$UpData['display']){
			foreach($this->AdminUidsList as $Key => $Val) {
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$this->Config['ViewResumeUrl'].$UpData['uid'],
						'msg'=>str_replace(array('{Title}'),array($UpData['full_name']),$this->Config['LangVar']['ResumePush'])
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"link"=> $this->Config['ViewResumeUrl'].$UpData['uid'],
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv(str_replace(array('{Title}'),array($UpData['full_name']),$this->Config['LangVar']['ResumePush']),CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}

			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv(str_replace(array('{Title}'),array($UpData['full_name']),$this->Config['LangVar']['ResumePush']),CHARSET,'UTF-8'),
					'url'=>$this->Config['ViewResumeUrl'].$UpData['uid']
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
		}
		//��Ϣ֪ͨEnd


		return $Data;
	}

	/* ������֤�� */
	public function GetAjaxSendOut($Mobile,$resume = true){
		global $_G,$Config;
		$Data = array();
		$Mobile = addslashes(strip_tags(trim($Mobile)));
		//�ֻ������ж�
		$IsMob = "/".$Config['PluginVar']['MobileMatch']."/";
		if(!$Mobile){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ContactNumberPlaceholder']);
			return $Data;
		}else if(!preg_match($IsMob,$Mobile)){
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileErr1']);
			return $Data;
		}
		
		if($CheckProfileData = DB::fetch_first('SELECT * FROM '.DB::table($this->TableResume).' where mobile = '.$Mobile.' and uid != '.intval($_G['uid'])) && $resume){//�����Ƿ����
			$Data['Msg'] = urlencode($this->Config['LangVar']['MobileRepeatErr']);
			return $Data;
		}

		$CheckSendSmsLog = DB::fetch_first('SELECT * FROM '.DB::table('fn_send_sms_log').' where state = 200 and cache_dateline > '.time().' and uid = '.intval($_G['uid']).' and mobile = '.$Mobile.' and sms_type = 1 order by id desc');//�Ƿ���ⷢ����

		if($CheckSendSmsLog){
			$Data['Msg'] = urlencode($this->Config['LangVar']['SendOutOk']);
			$Data['State'] = 200;
			return $Data;
		}

		@require_once libfile('class/short_message','plugin/fn_assembly');
		if($Config['PluginVar']['ShortMessageType'] == 1){
			$TemplateCode = $this->Config['PluginVar']['AliCodeId'];
			$TemplateParam = array('code'=>rand(100000,999999));
		}else if($Config['PluginVar']['ShortMessageType'] == 2){
			$Code = rand(100000,999999);
			$TemplateCode = str_replace(array('{Mobile}','{Code}'),array($Config['PluginVar']['MobileAreaCode'].$Mobile,$Code),$this->Config['LangVar']['TemplateCode']);
			$TemplateParam = array('code'=>$Code);
		}
		$SendSms = fn_short_message::send_sms($Config['PluginVar']['MobileAreaCode'].$Mobile,$this->Config['PluginVar']['AliAutograph'],$TemplateCode,$TemplateParam,$_G['uid'],$_G['username'],'fn_job',1);

		if($SendSms['State'] == 200){
			$Data['Msg'] = urlencode($this->Config['LangVar']['SendOutOk']);
			$Data['State'] = 200;
		}else{
			$Data['Msg'] = urlencode($SendSms['Msg']);
		}
		return $Data;
	}

	
	//����״̬ת��
	public function GetAjaxUserResumeState($Value){
		global $_G;
	
		if(DB::update($this->TableResume,array('state'=>intval($Value)),'uid = '.intval($_G['uid']))){
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeStateOk']);
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['ResumeStateErr']);
		}
		return $Data;
	}
	
	/* ��� */
	public function GetAjaxResumeSign($Get){
		global $_G;
		
		$UserInfo = $this->GetUserInfo();
		
		$SignItem = DB::fetch_first('SELECT id,rid FROM '.DB::table($this->TableResumeSign).' where '.($UserInfo['company']['id'] ? 'company_id = '.intval($UserInfo['company']['id']) : ' uid = '.intval($_G['uid'])).' and rid = '.intval($Get['rid']).' order by id desc');
		
		$UpData['company_id'] = $UserInfo['company'] ? intval($UserInfo['company']['id']) : '';
		$UpData['uid'] = intval($_G['uid']);
		$UpData['rid'] = intval($Get['rid']);
		$UpData['sign'] = intval($Get['sign']);
		if($SignItem){
			if(DB::update($this->TableResumeSign,$UpData,'id = '.intval($SignItem['id']))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['SignSuccess']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['SignFail']);
			}
		}else{
			$UpData['dateline'] = time();
			if(DB::insert($this->TableResumeSign,$UpData)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['SignSuccess']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['SignFail']);
			}

		}
		return $Data;
	}

	/* �ٱ����� */
	public function GetAjaxResumeReport($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$UserInfo = $this->GetUserInfo();
		$GetData['company_id'] = $UserInfo['company'] ? intval($UserInfo['company']['id']) : '';
		$GetData['uid'] = intval($_G['uid']);
		$GetData['username'] = addslashes(strip_tags($_G['username']));
		$GetData['ip'] = addslashes(strip_tags($_G['clientip']));
		$GetData['rid'] = intval($Get['rid']);
		$GetData['content'] = censor(addslashes(strip_tags($Get['content'])));
		$GetData['state'] = 0;
		$GetData['dateline'] = time();
		if(in_array($_G['uid'],array_filter(explode(",",$this->Config['PluginVar']['ResumeReportProhibitUis'])))){//���ξٱ�
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportProhibitErr']);
			return $Data;
		}
		
		if($this->Config['PluginVar']['ResumeReportNum'] && DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableResumeReport).' where uid = '.intval($_G['uid']).' and rid = '.intval($Get['rid'])) >= $this->Config['PluginVar']['ResumeReportNum']){
			$Data['Msg'] = urlencode(str_replace(array('{num}'),array($this->Config['PluginVar']['ResumeReportNum']),$this->Config['PluginVar']['ResumeReportNumTips']));
			return $Data;
		}

		if(!$GetData['content']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportContentErr']);
			return $Data;
		}
		if(DB::insert($this->TableResumeReport,$GetData)){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportOk']);
			$Data['State'] = 200;

			//��Ϣ֪ͨ
			$Msg = str_replace(array('{Content}'),array($GetData['content']),$this->Config['LangVar']['ResumeReportPush']);
			$Url = $this->Config['ViewResumeUrl'].$GetData['rid'];

			foreach($this->AdminUidsList as $Key => $Val) {//����Ա֪ͨ
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$Url,
						'msg'=>$Msg
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8'),
						"link"=> $Url,
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv($Msg,CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}
			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['ReportNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv($Msg,CHARSET,'UTF-8'),
					'url'=>$Url
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
			//��Ϣ֪ͨEnd

		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['ReportErr']);
		}
		return $Data;
	}

	/* �ղؼ��� */
	public function GetAjaxResumeCollect($Id){
		global $_G;
		$GetData['uid'] = intval($_G['uid']);
		$GetData['username'] = addslashes(strip_tags($_G['username']));
		$GetData['rid'] = intval($Id);
		$GetData['dateline'] = time();
		
		$Collect = DB::fetch_first('SELECT * FROM '.DB::table($this->TableResumeCollection).' where uid = '.$GetData['uid'].' and rid = '.$GetData['rid']);

		if($Collect){
			DB::delete($this->TableResumeCollection,'uid ='.$GetData['uid'].' and rid = '.$GetData['rid']);
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['DelCollectionTitle']);
		}else{
			if(DB::insert($this->TableResumeCollection,$GetData)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['OkCollectionTitle']);
			}
		}
		return $Data;
	}

	/* �ҵ��ղؼ���Ids */
	public function GetUserResumeCollectArray(){
		global $_G;
		$MyCollectArray = DB::fetch_all('SELECT rid FROM '.DB::table($this->TableResumeCollection).' where uid = '.intval($_G['uid']).' order by id desc');
		foreach($MyCollectArray as $Key => $Val) {
			$MyCollectIdArray[] = $Val['rid'];
		}
		return $MyCollectIdArray;
	}
	
	/* ���ղصļ��� */
	public function GetUserCompanyCollectionLogList(){
		global $_G;
		$Where = ' and C.uid = '.intval($_G['uid']);
		$Order = 'C.dateline';
		$Where = preg_replace('/and/','where',$Where,1);
		return $this->ResumeListFormat(DB::fetch_all("SELECT R.* FROM %t AS C,%t AS R ".$Where." And R.uid = C.rid order by ".$Order." desc,C.id desc",array($this->TableResumeCollection,$this->TableResume)));
	}

	/* ��Ƹ����ҵ�μ����� */
	public function GetMyFairCompany($fid,$company_id){
		return DB::fetch_first('SELECT * FROM '.DB::table($this->TableFairCompany).' where company_id = '.intval($company_id).' and fid = '.intval($fid));
	}

	/* ��Ƹ�������ҵ */
	public function GetAjaxFairCompanyList($Get){
		global $_G;

		$Results = array();
		$Get = EncodeURIToUrldeCode($Get);
		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		$Where = ' and FC.display = 1 and FC.fid = '.intval($Get['fid']);
		$Order = 'FC.updateline';

		if($Get['keyword']){
			$Where .= ' and C.name like(\'%'.addslashes(strip_tags($Get['keyword'])).'%\')';
		}

		if($Get['classid']){
			if($Get['classid'] == 'hot'){
				$Where .= ' and FC.hot = 1';
			}else{
				$Where .= ' and C.classid = '.intval($Get['classid']);
			}
			
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = 20;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$Results = $this->CompanyListFormat(DB::fetch_all("SELECT FC.hot as company_hot,C.*,FC.topdateline FROM ".DB::table($this->TableFairCompany)." AS FC,".DB::table($this->TableCompany)." AS C ".$Where." And C.id = FC.company_id order by FC.topdateline > ".time()." desc,".$Order." desc,FC.id desc ".$Limit));
		return $Results;

	}

	/* ��Ƹ�ᱨ�� */
	public function GetAjaxFairSignUp($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$UserInfo = $this->GetUserInfo();
		$Item = $this->GetViewFairthread($Get['fid']);

		if(!$Item){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoViewFairData']);
			return $Data;
		}

		if(time() > $Item['end_time']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['YJS']);
			return $Data;
		}

		if(!$UserInfo['company']){
			$Data['State'] = 201;
			return $Data;
		}
		
		$UpData['fid'] = intval($Item['id']);
		$UpData['company_id'] = intval($UserInfo['company']['id']);
		$UpData['type'] = 2;
		$UpData['display'] = $Item['param']['sign_up_examine'] ? 0 : 1;
		$UpData['dateline'] = $UpData['updateline'] = time();

		$FairCompanyLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableFairCompany).' where company_id = '.$UpData['company_id'].' and fid = '.$UpData['fid']);
		if($FairCompanyLog){
			$Data['Msg'] = urlencode($this->Config['LangVar']['FairOnlineApplicationRepeatErr']);
			return $Data;
		}

		if($Item['param']['sign_up_info'] && !DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableInfo).' where display = 1 and payment_state = 1 and hide = 1 and company_id = '.intval($UserInfo['company']['id']).($this->Config['PluginVar']['ExpiryTime'] ? ' and updateline >= '.strtotime("-".intval($this->Config['PluginVar']['ExpiryTime'])." day",time()) : '') )){
			$Data['Msg'] = urlencode($this->Config['LangVar']['FairInfoErr']);
			$Data['State'] = 202;
			return $Data;
		}
		
		if($Item['money'] && ((!$UserInfo['company']['vip']) || (!in_array($UserInfo['company']['group_id'],explode(',',$Item['groups'])) && $UserInfo['company']['vip']))){//���ѱ���
			$UpData['display'] = 1;
			$PayLog = $this->GetAjaxPayLog(array('money'=>$Item['money'],'event'=>'fair_company','insert'=>$UpData,'fid'=>$UpData['fid']));
			$Data['State'] = 203;
			$Data['Money'] = $Item['money'];
			$Data['PayId'] = $PayLog['Id'];
			return $Data;
		}else if(in_array($UserInfo['company']['group_id'],explode(',',$Item['groups'])) && $UserInfo['company']['vip']){
			$UpData['display'] = 1;
		}

		$Id = DB::insert($this->TableFairCompany,$UpData,true);
		if($Id){
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['FairOnlineApplicationOk'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['OpErr']);
		}

		//��Ϣ֪ͨ
		if(!$UpData['display'] && $Data['State'] == 200){
			$NotificationUrl = $this->Rewrite('view_fair',array('fid'=>$Item['id']));
			$NotificationMsg = str_replace(array('{Title}'),array($UserInfo['company']['name']),$this->Config['LangVar']['FairCompanyPush']);
			foreach($this->AdminUidsList as $Key => $Val) {
				if(DzNotice){
					notification_add($Val,'system','<a href="{url}">{msg}</a>',array(
						'url'=>$NotificationUrl,
						'msg'=>$NotificationMsg
					),1);//ϵͳ֪ͨ
				}
				if($Config['PluginVar']['AppType'] == 1){//������������
					$PushData['Uid'] = $Val;
					$PushData['Type'] = 'pictemp';
					$PushData['Content'] = array(
						"tag"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"title"=> diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
						"link"=> $NotificationUrl,
						"pic_url"=> $_G['siteurl'].$Config['StaticPath'].'/images/notice.png',
						"extra_info"=>array(
							array(
								"key"=>'',
								"val"=>diconv($NotificationMsg,CHARSET,'UTF-8')
							)
						)
					);
					$ReturnAssistantMsg = $this->MagApp->GetSendAssistantMsg($PushData);
				}
			}
			if($Config['PluginVar']['AppType'] == 2){//ǧ��ģ����Ϣ����
				$PushData['Uid'] = implode(',',$this->AdminUidsList);
				$PushData['Msg'] = diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8');
				$PushData['Content'] = array(
					'title'=>diconv(addslashes(strip_tags($this->Config['LangVar']['AuditNotice'])),CHARSET,'UTF-8'),
					'date'=>date('Y-m-d H:i:s'),
					'setting'=>array(),
					'content' => diconv($NotificationMsg,CHARSET,'UTF-8'),
					'url'=>$NotificationUrl
				);
				$this->QHApp->GetMessagesTemplate($PushData);
			}
		}
		//��Ϣ֪ͨEnd

		return $Data;
	}

	/* ˢ����Ƹ�� */
	public function GetAjaxFairRefresh($Get){
		global $_G;
		$Get = EncodeURIToUrldeCode($Get);
		$UserInfo = $this->GetUserInfo();
		$Item = $this->GetViewFairthread($Get['fid']);
		if(!$Item){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoViewFairData']);
			return $Data;
		}

		if(time() > $Item['end_time']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['YJS']);
			return $Data;
		}

		if(!$UserInfo['company']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoViewCompanyData']);
			return $Data;
		}

		$MyFairCompany = $this->GetMyFairCompany($Item['id'],$UserInfo['company']['id']);

		if($UserInfo['company']['vip'] && $UserInfo['company']['money'] >= intval($Item['param']['refresh_money'])){
			if($this->InsertCompanyWalletLog($UserInfo['company']['id'],$Item['param']['refresh_money'],str_replace(array('{id}','{company_id}','{company_name}'),array($Item['id'],$UserInfo['company']['id'],$UserInfo['company']['name']),$this->Config['LangVar']['CompanyWalletBalanceTypeArray']['4']))){
				DB::update($this->TableFairCompany,array('updateline'=>time()),' id = '.intval($MyFairCompany['id']));
				DB::query("UPDATE ".DB::table($this->TableCompany)." SET money = money - ".intval($Item['param']['refresh_money'])." WHERE id = ".intval($UserInfo['company']['id']));
				$Data['State'] = 201;
				$Data['Msg'] = urlencode($this->Config['LangVar']['RefreshOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DayRefreshInfoErr2']);
			}
		}else{
			$Data = $this->GetAjaxPayLog(array('event'=>'refresh_fair','money'=>$Item['param']['refresh_money'],'fid'=>$Item['id'],'fcid'=>$MyFairCompany['id']));
		}
		return $Data;
	}

	/* �ö���Ƹ�� */
	public function GetAjaxFairTop($Get){
		global $_G;
		
		$Get = EncodeURIToUrldeCode($Get);
		$UserInfo = $this->GetUserInfo();
		$Item = $this->GetViewFairthread($Get['fid']);
		if(!$Item){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoViewFairData']);
			return $Data;
		}

		if(time() > $Item['end_time']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['YJS']);
			return $Data;
		}

		if(!$UserInfo['company']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoViewCompanyData']);
			return $Data;
		}

		$MyFairCompany = $this->GetMyFairCompany($Item['id'],$UserInfo['company']['id']);
		$Topdateline = $MyFairCompany['topdateline'] >= time() ? strtotime("+".intval($Get['day'])." day",$MyFairCompany['topdateline']) : strtotime("+".intval($Get['day'])." day",time());
		if($UserInfo['company']['vip'] && $UserInfo['company']['money'] >= intval($Get['original_money'])){
			if($this->InsertCompanyWalletLog($UserInfo['company']['id'],$Get['original_money'],str_replace(array('{id}','{company_id}'),array($Item['id'],$UserInfo['company']['id']),$this->Config['LangVar']['CompanyWalletBalanceTypeArray']['5']))){
				DB::update($this->TableFairCompany,array('updateline'=>time(),'topdateline'=>$Topdateline),' id = '.intval($MyFairCompany['id']));
				DB::query("UPDATE ".DB::table($this->TableCompany)." SET money = money - ".intval($Get['original_money'])." WHERE id = ".intval($UserInfo['company']['id']));
				$Data['State'] = 201;
				$Data['Msg'] = urlencode($this->Config['LangVar']['SetTopOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			}
		}else{
			$Data = $this->GetAjaxPayLog(array('event'=>'top_fair','money'=>$Get['money'],'day'=>$Get['day'],'fid'=>$Item['id'],'fcid'=>$MyFairCompany['id'],'topdateline'=>$Topdateline));
		}
		return $Data;

	}

	/* Hr����������б� */
	public function GetHrToolsList(){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableHrTools).' where display = 1 order by displayorder ASC',array(),'id');//��������
	}

	/* Hr�������ĵ��б� */
	public function GetHrToolsInfoList($Get){

		$Where = ' and I.display = 1';
		$Order = 'I.dateline';

		if($Get['classid']){
			$Where .= ' and I.classid = '.intval($Get['classid']);
		}

		$Where = preg_replace('/and/','where',$Where,1);

		return DB::fetch_all('SELECT I.* FROM '.DB::table($this->TableHrToolsInfo).' I '.$Where.' order by '.$Order .' desc');//��������
	}

	/* �û������Լ���ְλ */
	public function GetAjaxUserInfoOp($Op,$Id,$Field=null,$Value=null){
		global $_G;
		$Id = intval($Id);
		$Uid = intval($_G['uid']);
		$UserInfo = $this->GetUserInfo();
		if($Op == 'Del'){
			if(DB::delete($this->TableInfo,'id ='.$Id.' and company_id = '.intval($UserInfo['company']['id']))){
				DB::delete($this->TableInfoCollection,'iid ='.$Id);
				DB::delete($this->TableInfoReport,'iid ='.$Id);
				DB::delete($this->TableInfoApplyLog,'iid ='.$Id);
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else if($Op == 'Edit'){
			if(DB::update($this->TableInfo,array($Field=>addslashes(strip_tags($Value))),'id = '.$Id.' and uid = '.$Uid)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
	}

	/* ����Ա�޸��ֶ�ֵ */
	public function GetAjaxAdminEditInfoFields($Id,$Field,$Val){
		global $_G;
		if($this->Admin){
			$UpData[$Field] = intval($Val);
			DB::update($this->TableInfo,$UpData,'id = '.intval($Id));
		}
		$Data['State'] = 200;
		return $Data;
	}

	/* ����Ա�޸��ֶ�ֵ */
	public function GetAjaxAdminEditResumeFields($Id,$Field,$Val){
		global $_G;
		if($this->Admin){
			$UpData[$Field] = intval($Val);
			DB::update($this->TableResume,$UpData,'uid = '.intval($Id));
		}
		$Data['State'] = 200;
		return $Data;
	}

	/* ����Ա�޸��ֶ�ֵ */
	public function GetAjaxAdminEditCompanyFields($Id,$Field,$Val){
		global $_G;
		if($this->Admin){
			$UpData[$Field] = intval($Val);
			DB::update($this->TableCompany,$UpData,'id = '.intval($Id));
		}
		$Data['State'] = 200;
		return $Data;
	}

	/* α��̬ */
	public function Rewrite($Mod,$ModArray = array()){
		global $_G;
		loadcache('fn_job_rewrite');
		$Rewrite = $_G['cache']['fn_job_rewrite'];
		if($Rewrite[$Mod]['available'] && !MinWxApp){
			$StrReplaceArray = array('{','}');
			$StrReplaceArrayTo = array('','');
			foreach($ModArray as $Key => $Val) {
				$StrReplaceArray[] = $Key;
				$StrReplaceArrayTo[] = $Val;
			}
			$Url = $_G['siteurl'].str_replace($StrReplaceArray,$StrReplaceArrayTo,$Rewrite[$Mod]['rule']);
		}else{
			if(in_array($Mod,array('list_1','list_2'))){
				$Array = explode('_',$Mod);
				$Mod = $Array[0];
				$ModArray = array('class'=>$Array[1]);
			}
			$Url = $this->Config['Url'].'&m='.$Mod.( !empty($ModArray) ? '&'.http_build_query($ModArray) : '' );
		}
		return $Url;
	}
	
	/* ����֧����¼ */
	public function GetAjaxPayLog($Get){
		global $_G;

		$Get = EncodeURIToUrldeCode($Get);

		$Param['event'] = addslashes(strip_tags($Get['event']));

		if($Param['event'] == 'publish_info'){//����ְλ
			$Item = $this->GetViewthread($Get['iid']);
			$Param['iid'] = $Get['iid'];
			$Param['company_id'] = $Item['company_id'];
			$Content = str_replace(array('{iid}','{company_id}','{company_name}'),array($Get['iid'],$Item['company_id'],$Item['company']['name']),$this->Config['LangVar']['ListPublishePayContent']);
		}else if($Param['event'] == 'refresh_info'){//ˢ��ְλ
			$Item = $this->GetViewthread($Get['iid']);
			$Param['iid'] = $Get['iid'];
			$Param['updateline'] = time();
			$Content = str_replace(array('{iid}','{company_id}','{company_name}'),array($Get['iid'],$Item['company_id'],$Item['company']['name']),$this->Config['LangVar']['RefreshInfoPayContent']);
		}else if($Param['event'] == 'top_info'){//�ö�ְλ
			$Item = $this->GetViewthread($Get['iid']);
			$ItemCompany = $this->GetViewCompanythread($Item['company_id']);
			$Param['iid'] = $Get['iid'];
			$Param['uid'] = $_G['uid'];
			$Param['resume_package_count'] = $Get['resume'] + $ItemCompany['resume_package_count'];
			$Param['company_id'] = $Item['company_id'];
			$Param['topdateline'] = $Item['topdateline'] >= time() ? strtotime("+".intval($Get['day'])." day",$Item['topdateline']) : strtotime("+".intval($Get['day'])." day",time());
			$Param['updateline'] = time();
			$Content = str_replace(array('{iid}','{company_id}','{company_name}'),array($Get['iid'],$Item['company_id'],$Item['company']['name']),$this->Config['LangVar']['SetTopInfoPayContent']);
		}else if($Param['event'] == 'refresh_resume'){//ˢ�¼���
			$Param['rid'] = $Get['rid'];
			$Param['updateline'] = time();
			$Content = $this->Config['LangVar']['ResumeRefresh'].'(ID:'.$Get['rid'].')';
		}else if($Param['event'] == 'top_resume'){//�ö�����
			$UserInfo = $this->GetUserInfo();
			$Param['rid'] = $Get['rid'];
			$Param['topdateline'] = $UserInfo['resume']['topdateline'] >= time() ? strtotime("+".intval($Get['day'])." day",$UserInfo['resume']['topdateline']) : strtotime("+".intval($Get['day'])." day",time());
			$Param['updateline'] = time();
			$Content = $this->Config['LangVar']['SetTopResume'].'(ID:'.$Get['rid'].')';
		}else if($Param['event'] == 'resume_see_log'){//�����鿴��ϵ��ʽ
			$Param['insert'] = $Get['insert'];
			$Param['slid'] = $GetData['slid'];
			$ItemCompany = $this->GetViewCompanythread($Get['insert']['company_id']);
			$Content = str_replace(array('{rid}','{company_id}','{company_name}'),array($Get['rid'],$Get['insert']['company_id'],$ItemCompany['name']),$this->Config['LangVar']['ResumeSeeLogPayContent']);
		}else if($Param['event'] == 'buy_store_level'){
			$UserInfo = $this->GetUserInfo();
			$GroupItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableCompanyGroup).' where id = '.$Get['group_id']);
			$GroupLogItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableCompanyGroupLog).' where company_id = '.$Get['company_id']);

			$Param['data']['company_id'] = $Get['company_id'];

			$Param['data']['refresh_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? ($UserInfo['company']['vip'] ? $GroupItem['refresh_count'] + $GroupLogItem['refresh_count'] : $GroupItem['refresh_count'] + $UserInfo['company']['use_refresh_count']) : $GroupItem['refresh_count'];

			$Param['data']['info_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? ($UserInfo['company']['vip'] ? $GroupItem['info_count'] + $GroupLogItem['info_count'] : $GroupItem['info_count'] + $UserInfo['company']['use_info_count']) : $GroupItem['info_count'];

			$Param['data']['resume_count'] = $this->Config['PluginVar']['GroupSuperpositionSwitch'] ? ($UserInfo['company']['vip'] ? $GroupItem['resume_count'] + $GroupLogItem['resume_count'] : $GroupItem['resume_count'] + $UserInfo['company']['use_resume_count']) : $GroupItem['resume_count'];
			
			$Param['data']['day_refresh_count'] = $GroupItem['day_refresh_count'];
			$Param['data']['day_info_count'] = $GroupItem['day_info_count'];
			$Param['data']['resume_day_count'] = $GroupItem['resume_day_count'];
			$Param['data']['examine'] = $GroupItem['examine'];
			$Param['data']['top_discount'] = $GroupItem['top_discount'];
			$Param['data']['hot'] = $GroupItem['hot'];
			$Param['data']['refresh_type'] = $GroupItem['refresh_type'];
			$Param['data']['apply_resume'] = $GroupItem['apply_resume'];
			$Param['data']['hide'] = $GroupItem['hide'];
			$Param['group_log'] = $GroupLogItem ? true : false;
			
			$Param['company_id'] = $Get['company_id'];
			$Param['group_id'] = $Get['group_id'];
			$Param['money'] = $GroupItem['currency'] + $UserInfo['company']['money'];
			$Param['due_time'] = $UserInfo['company']['due_time'] >= time() && $UserInfo['company']['group_id'] == $Param['group_id'] ? strtotime("+".intval($Get['month'])."  month",$UserInfo['company']['due_time']) : strtotime("+".intval($Get['month'])."  month",time());
			$Content = str_replace(array('{id}','{company_name}','{gid}'),array($UserInfo['company']['id'],$UserInfo['company']['name'],$GroupItem['id']),$this->Config['LangVar']['PayCompanyContent']);

		}else if($Param['event'] == 'resume_package'){//���������
			$UserInfo = $this->GetUserInfo();
			$Param['company_id'] = $UserInfo['company']['id'];
			$Param['resume_package_count'] = $UserInfo['company']['resume_package_count'] + $Get['num'];
			$Content = str_replace(array('{company_id}','{company_name}'),array($UserInfo['company']['id'],$UserInfo['company']['name']),$this->Config['LangVar']['ResumePackageBuyContent']);
		}else if($Param['event'] == 'fair_company'){//��Ƹ�ᱨ��
			$Param['insert'] = $Get['insert'];
			$Content = str_replace(array('{id}','{company_id}'),array($Get['insert']['fid'],$Get['insert']['company_id']),$this->Config['LangVar']['FairOnlineApplicationPayContent']);
		}else if($Param['event'] == 'refresh_fair'){//ˢ����Ƹ��
			$UserInfo = $this->GetUserInfo();
			$Param['fcid'] = $Get['fcid'];
			$Param['updateline'] = time();
			$Content = str_replace(array('{id}','{company_id}','{company_name}'),array($Get['fid'],$UserInfo['company']['id'],$UserInfo['company']['name']),$this->Config['LangVar']['CompanyWalletBalanceTypeArray']['4']);
		}else if($Param['event'] == 'top_fair'){//�ö���Ƹ��
			$UserInfo = $this->GetUserInfo();
			$Param['fcid'] = $Get['fcid'];
			$Param['topdateline'] = $Get['topdateline'];
			$Param['updateline'] = time();
			$Content = str_replace(array('{id}','{company_id}','{company_name}'),array($Get['fid'],$UserInfo['company']['id'],$UserInfo['company']['name']),$this->Config['LangVar']['CompanyWalletBalanceTypeArray']['5']);
		}
		
		return $this->Pay->PayLogInsert($Get['money'],$Param,$Content,'fn_job');

	}
}

$Fn_Job = new Fn_Job;
?>