<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_qhb` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `ftitle` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `start_time` int(11) unsigned NOT NULL,
  `end_time` int(11) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `displayorder` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `pay_state` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_qhb_banner` (
  `id` tinyint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `link` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `displayorder` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_qhb_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `floor` int(11) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;


CREATE TABLE IF NOT EXISTS `pre_fn_qhb_member_info` (
  `uid` int(11) unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `tel` varchar(30) NOT NULL,
  `content` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `dateline` int(11) unsigned NOT NULL
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_qhb_post` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `floor` varchar(100) NOT NULL,
  `good_count` int(11) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_qhb_share_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_qhb_post_floorid` (
  `tid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tid`,`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_qhb_post_nofloorid` (
  `tid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tid`,`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);


$QHBTableField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_qhb'));
$QHBToArray = MysqlToArray($QHBTableField);
if(!in_array('click',$QHBToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_qhb` ADD `click` INT( 11 ) UNSIGNED NOT NULL AFTER `display` ;
EOF;
	runquery($UpSql);
}

$UpSql = <<<EOF
	ALTER TABLE `pre_fn_qhb` CHANGE `param` `param` MEDIUMTEXT NOT NULL;
EOF;
runquery($UpSql);


function MysqlToArray($Array) {
    $temp = array();
    foreach ($Array as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}
$finish = TRUE;
?>