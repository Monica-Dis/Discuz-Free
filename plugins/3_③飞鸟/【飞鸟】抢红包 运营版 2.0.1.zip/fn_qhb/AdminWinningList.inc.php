<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Common.php');
$Operation = in_array($_GET['Operation'], array('Del')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ���� */
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		$StateSelected = array($_GET['state']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_QHB->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}"></td>
						<th>Tid</th><td><input type="text" class="txt" name="tid" value="{$_GET['tid']}"></td>

						<th>{$Fn_QHB->Config['LangVar']['StateTitle']}</th><td>
						<select name="state">
							<option value="">{$Fn_QHB->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$StateSelected['1']}>{$Fn_QHB->Config['LangVar']['HbState']['1']}</option>
							<option value="0"{$StateSelected['0']}>{$Fn_QHB->Config['LangVar']['HbState']['0']}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_QHB->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'L.id';
		if($_GET['tid']){
			$Where .= ' and L.tid = '.intval($_GET['tid']);
		}
		if(in_array($_GET['state'],array('0','1'))){
			$Where .= ' and L.state = '.intval($_GET['state']);
		}
		if($_GET['keyword']){
			$Where .= ' and concat(L.uid,L.username,L.money) like(\'%'.addslashes(dhtmlspecialchars($_GET['keyword'])).'%\')';
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		$TdStyle = array('width="20"', 'width="400"','width="30"', 'width="80"','width="60"','width="60"','width="60"');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'QiangLouModule', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_QHB->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
            'ID',
			$Fn_QHB->Config['LangVar']['Title'],
			'Uid',
			$Fn_QHB->Config['LangVar']['UserNameTitle'],
			$Fn_QHB->Config['LangVar']['MoneyTitle'],
			$Fn_QHB->Config['LangVar']['WinningFloorTtile'],
			$Fn_QHB->Config['LangVar']['StateTitle'],
			$Fn_QHB->Config['LangVar']['WinningTimeTtile']
		), 'header tbm',$TdStyle);
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				$Module['id'],
				'<a href="'.$Fn_QHB->Config['ViewThreadUrl'].$Module['tid'].'" target="_blank">'.'['.$Module['ftitle'].']'.$Module['title'].'</a>',
				$Module['uid'],
				$Module['username'],
				$Module['money'],
				$Module['floor'],
				$Module['state'] ? $Fn_QHB->Config['LangVar']['HbState']['1'] : '<span style="color:red">'.$Fn_QHB->Config['LangVar']['HbState']['0'].'<span>',
				date('Y-m-d H:i',$Module['dateline'])
			));
		}
		showsubmit('','','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        /*Dism_taobao_com*/showtablefooter();
		showformfooter();/*Dism��taobao��com*/
		showtagfooter('div');
		/* ģ����� End */
	}
}
/* ��Ƶ�б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_QHB;
	$FetchSql = 'SELECT T.title,T.ftitle,L.* FROM '.DB::table($Fn_QHB->TableHBLog).' L LEFT JOIN '.DB::table('common_member').' M on M.uid = L.uid LEFT JOIN '.DB::table($Fn_QHB->TableQHB).' T on T.id = L.tid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ��Ƶ���� */
function GetModulesCount($Where){
	global $Fn_QHB;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_QHB->TableHBLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>