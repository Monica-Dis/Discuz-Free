<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Common.php');
$Operation = in_array($_GET['Operation'], array('Del','Edit')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ���� */
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_QHB->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}"></td>
						<th>Tid</th><td><input type="text" class="txt" name="tid" value="{$_GET['tid']}">&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_QHB->Config['LangVar']['SearchSubmit']}" class="btn" type="submit"></td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'P.id';
		if($_GET['tid']){
			$Where .= ' and P.tid = '.intval($_GET['tid']);
		}
		if($_GET['keyword']){
			$Where .= ' and concat(P.content,P.uid,P.username) like(\'%'.addslashes(dhtmlspecialchars($_GET['keyword'])).'%\')';
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		$TdStyle = array('width="20"', 'width="300"','width="30"', 'width="50"','width="150"','width="60"','width="130"');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'QiangLouModule', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_QHB->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
            'ID',
			$Fn_QHB->Config['LangVar']['Title'],
			'Uid',
			$Fn_QHB->Config['LangVar']['UserNameTitle'],
			$Fn_QHB->Config['LangVar']['PostContentTitle'],
			$Fn_QHB->Config['LangVar']['LouCeng'],
			$Fn_QHB->Config['LangVar']['TimeTitle'],
			$Fn_QHB->Config['LangVar']['OperationTitle']
		), 'header tbm',$TdStyle);
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'],
				'<a href="'.$Fn_QHB->Config['ViewThreadUrl'].$Module['tid'].'" target="_blank">'.'['.$Module['ftitle'].']'.$Module['title'].'</a>',
				$Module['uid'],
				$Module['username'],
				$Module['content'],
				$Module['state'] ? $Module['floor'] : '-'.$Module['floor'],
				date('Y-m-d H:i',$Module['dateline']),
				'<a href="'.$OpCpUrl.'&Operation=Edit&pid='.$Module['id'].'">'.$Fn_QHB->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&pid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_QHB->Config['LangVar']['DelTitle'].'</a>'
			));
		}
		showsubmit('Submit','submit','del','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        /*Dism_taobao_com*/showtablefooter();
		showformfooter();/*Dism��taobao��com*/
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_QHB->TablePost,'id ='.$Val);
			}
			cpmsg($Fn_QHB->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_QHB->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Operation == 'Edit'){//�Ƿ���ʾ
	$PId = intval($_GET['pid']);
	$Info = $PId ? $Fn_QHB->QueryOne($Fn_QHB->TablePost,$PId) : array();
	$Title = $Fn_QHB->Config['LangVar']['EditTitle'];
	if(!submitcheck('DetailSubmit')) {
		$formUrl = ltrim(rawurldecode(cpurl()),'action=');
		showformheader($formUrl,'enctype');
		showtableheader();
		showtitle($Title);
		showsetting($Fn_QHB->Config['LangVar']['PostContentTitle'], 'content', $Info['content'], 'textarea');
		/*Dism_taobao_com*/showtablefooter();
		showsubmit('DetailSubmit');
		showformfooter();/*Dism��taobao��com*/
	}else{
		$Data['content'] = addslashes($_GET['content']);//�豣��html����
		if($Info){
			DB::update($Fn_QHB->TablePost,$Data,'id = '.$PId);
		}
		cpmsg($Fn_QHB->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	}
	
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['pid']){//ɾ��
	$PId = intval($_GET['pid']);
	DB::delete($Fn_QHB->TablePost,'id ='.$PId);
	cpmsg($Fn_QHB->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}
/* ��Ƶ�б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_QHB;
	$FetchSql = 'SELECT T.title,T.ftitle,P.* FROM '.DB::table($Fn_QHB->TablePost).' P LEFT JOIN '.DB::table('common_member').' M on M.uid = P.uid LEFT JOIN '.DB::table($Fn_QHB->TableQHB).' T on T.id = P.tid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ��Ƶ���� */
function GetModulesCount($Where=null){
	global $Fn_QHB;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_QHB->TablePost).' P '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>