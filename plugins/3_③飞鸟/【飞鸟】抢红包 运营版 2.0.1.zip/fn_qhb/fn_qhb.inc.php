<?php
/**
 *	[�����������(fn_qhb.{modulename})] (C)2016-2099 Copyright (c) 2020 by dism.taobao.com
 *	Version: 1.0
 *	Date: 2017-8-3 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Common.php');
if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){
	@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
	$PayList = $FnPay->GetPayList();
}


/* ���Զ�ά����� */
if(!checkmobile() && $Fn_QHB->Config['PluginVar']['PcQrSwitch'] && $_GET['m'] != 'calculation'){
	$PcUrl = $_G[siteurl].'plugin.php?id=fn_qhb';
	$QrSize = 5;
	$Dir = 'data/cache/qrcode/';//�洢·��
	$File = $Dir.'fn_qhb.jpg';
	if(!file_exists($File) || !filesize($File)) {
		dmkdir($Dir);
		require_once DISCUZ_ROOT.'source/plugin/fn_qhb/qrcode.class.php';
		QRcode::png($PcUrl, $File, QR_ECLEVEL_L, $QrSize);
	}
	$QrCode = base64_encode(file_get_contents($File));
	unlink($File);
	include template('fn_qhb:index_qrcode');
	exit();
}
/* ���Զ�ά����� End */



if($WxApp){//΢�ŷ���
	$Fn_QHB->Config['SignPackage'] = $Fn_QHB->WeixinGetSignPackage();
}

$_GET['m'] = empty($_GET['m']) ? 'index' : $_GET['m'];//��ʼ��ģ��

//��¼
if($_GET['m'] == 'user' || $_GET['m'] == 'user_add_info' || $_GET['m'] == 'add' || $_GET['m'] == 'user_hb_log' || $_GET['m'] == 'share'){
	
	if(!$_G['uid']){
		if($Appbyme){//С�Ƶ�¼
			exit('
				<script language="javascript" src="source/plugin/fn_qhb/static/js/appbyme.js"></script>
				<script>
				connectSQJavascriptBridge(function(bridge){
					sq.login(function(userInfo){
						if(userInfo.userId != 0){
							sq.logout(function(info){
								alert("'.$Fn_QHB->Config['LangVar']['AppBymeErr'].'");
							});
						}else{
							window.location.reload(true);
						}
					});
				});
				</script>
			');
		}else if($MagApp){//���׵�¼
			$UserInfo = $Fn_QHB->GetMagUserInfo();
			if($UserInfo['user_id']){
				require_once libfile('function/member');
				$Member = getuserbyuid($UserInfo['user_id'],1);
				$CookieTime = 1296000;
				setloginstatus($Member, $CookieTime);
			}else{
				exit('
					<script src="source/plugin/fn_qhb/static/js/mag.js"></script>
					<script>
						mag.toLogin(function(rs){
							window.location.reload(true);
						});
					</script>
				');
			}
			
		}else if($QFApp){//ǧ����¼
			$ToKen = json_decode($Fn_QHB->GetActionAuthCode($_COOKIE['wap_token'],$Fn_QHB->Config['PluginVar']['qf_secret']),true);
			if($ToKen['uid']){
				require_once libfile('function/member');
				$Member = getuserbyuid($ToKen['uid'],1);
				$CookieTime = 1296000;
				setloginstatus($Member, $CookieTime);
			}else{
				exit('
					<script>
					function QFH5ready(){
						QFH5.jumpLogin(function(state,data){
							if(state==1){
								QFH5.refresh(1);
							}else{
								alert(data.error);//data.error: string
							}
						});
					}
					</script>
				');	
			}
					
		}else{
			if(checkmobile()){
				header("HTTP/1.1 303 See Other");
				Header("Location: member.php?mod=logging&action=login"); 
			}else{
				showmessage('to_login', '', array(), array('showmsg' => true,'login' => 1));
				exit();
			}
		}
	}
}
$UserInfo = $_G['uid'] ? $Fn_QHB->GetUserInfo($_G['uid']) : '';

if($_GET['m'] == 'add'){//�����
	
	$navtitle = $metakeywords = $metadescription = $Fn_QHB->Config['LangVar']['AddHBTitle'];
	$Fn_QHB->Config['PluginVar']['BonusRule'] = str_replace(array('{input}','{em}','{/em}'),array('<input type="tel" value="" name="money" class="Color" id="Money" style="border-color:'.$Fn_QHB->Config['PluginVar']['Color'].'">','<em>','</em>'),$Fn_QHB->Config['PluginVar']['BonusRule']);
	$Fn_QHB->Config['LangVar']['AddHBFixedPrompt'] = str_replace(array('{ExtensionMoney}'),array($Fn_QHB->Config['PluginVar']['ExtensionMoney']),$Fn_QHB->Config['LangVar']['AddHBFixedPrompt']);

	
	$FtitleLength = $Fn_QHB->Config['PluginVar']['FtitleLength'] ? $Fn_QHB->Config['PluginVar']['FtitleLength'] : 20;
	$TitleLength = $Fn_QHB->Config['PluginVar']['TitleLength'] ? $Fn_QHB->Config['PluginVar']['TitleLength'] : 50; 
	$Fn_QHB->Config['LangVar']['PrefixPlaceholder'] = str_replace(array('{Num}'),array($FtitleLength),$Fn_QHB->Config['LangVar']['PrefixPlaceholder']);
	$Fn_QHB->Config['LangVar']['AddHBTitlePlaceholder'] = str_replace(array('{Num}'),array($TitleLength),$Fn_QHB->Config['LangVar']['AddHBTitlePlaceholder']);

	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_upload/upload.class.php')){
		@include DISCUZ_ROOT.'./source/plugin/fn_upload/upload.class.php';
		$UploadConfig = FnUpload::Config();
	}
	//֧������
	$PayTitle = $navtitle;
	
}else if($_GET['m'] == 'viewthread'){//����ҳ
	$Info = $Fn_QHB->GetViewthreadInfo($_GET['tid']);
	if($Info){
		if(!$_G['uid']){
			if($MagApp){//����ͬ��
				$UserInfo = $Fn_QHB->GetMagUserInfo();
				if($UserInfo['user_id']){
					require_once libfile('function/member');
					$Member = getuserbyuid($UserInfo['user_id'],1);
					$CookieTime = 1296000;
					setloginstatus($Member, $CookieTime);
				}
			}else if($QFApp){//ǧ��ͬ��
				$ToKen = json_decode($Fn_QHB->GetActionAuthCode($_COOKIE['wap_token'],$Fn_QHB->Config['PluginVar']['qf_secret']),true);
				if($ToKen['uid']){
					require_once libfile('function/member');
					$Member = getuserbyuid($ToKen['uid'],1);
					$CookieTime = 1296000;
					setloginstatus($Member, $CookieTime);
				}
			}
		}
		$Info['param'] = unserialize($Info['param']);
		$navtitle = $Info['title'].'-'.$Info['ftitle'];
		$metakeywords = $navtitle;
		$metadescription = $Info['content'];
		$title = $Fn_QHB->Config['LangVar']['ViewthreadTitle'];

		$Fn_QHB->Click($Fn_QHB->TableQHB,$Info['id']);//������ۼ�

		$WinningFloorList = array_filter(explode("\n",$Info['param']['winning_floor']));//�н�¥��

		$Info['param']['content'] = stripslashes($Info['param']['content']);
		$Info['param']['rulecontent'] = stripslashes($Info['param']['rulecontent']);
		$Info['param']['brand'] = $Info['param']['brand'] ? $Info['param']['brand'] : $Info['musername'];
		$Fn_QHB->Config['LangVar']['PostCountTtile'] = str_replace('{num}',$Info['PostCount'],$Fn_QHB->Config['LangVar']['PostCountTtile']);
		if($Info['start_time'] > time()){
			$MessageText = $Fn_QHB->Config['LangVar']['WKS'].' '.$Fn_QHB->Config['LangVar']['PostCountTtile'];
		}else if(time() > $Info['end_time']){
			$MessageText = $Fn_QHB->Config['LangVar']['YJS'].' '.$Fn_QHB->Config['LangVar']['PostCountTtile'];
		}else{
			$MessageText = $Fn_QHB->Config['LangVar']['JXZ'];
		}

		if(!$Info['param']['winningresultsort']){
			$PostMoneyRankingList = $Fn_QHB->GetPostMoneyRanking($Info['id'],9);//�н����
		}else if($Info['param']['winningresultsort'] == 1){
			$PostMoneyRankingList = $Fn_QHB->GetPostMoneyList($Info['id'],9);//�н����
		}
		$Info['param']['winning_prompt'] = str_replace(array('{p}','{/p}'),array('<p>','</p>'),$Info['param']['winning_prompt']);
		
		if($Info['param']['winningfloorhidden']){
			foreach($WinningFloorList as $Key => $Val ){
				$ToArray = array_filter(explode("|",$Val));
				$Money += $ToArray[0] * count(explode(',',$ToArray[1]));
				$Num += count(explode(',',$ToArray[1]));
			}
			$HbCount = $Fn_QHB->GetHbCount($Info['id']);
			$Fn_QHB->Config['LangVar']['WinningFloorHiddenDes'] = str_replace(array('{Money}','{Num}','{NumTo}'),array($Money,$Num,$HbCount),$Fn_QHB->Config['LangVar']['WinningFloorHiddenDes']);
		}
		
		//����ͼ
		$Ads = array_filter(explode("\n",$Info['param']['ads']));
		
		//����
		$Fn_QHB->Config['WxShare']['WxTitle'] = $Info['param']['wx_title'] ? $Info['param']['wx_title'] : '['.$Info['ftitle'].']'.$Info['title'];
		$Fn_QHB->Config['WxShare']['WxDes'] = $Info['param']['wx_des'] ? $Info['param']['wx_des'] : $Fn_QHB->Config['WxShare']['WxDes'];
		$Fn_QHB->Config['WxShare']['WxUrl'] = $Fn_QHB->GetRandShare() ? $Fn_QHB->GetRandShare().'/plugin.php?id=fn_qhb&m=viewthread&tid='.$Info['id'] : $Fn_QHB->Config['ViewThreadUrl'].$Info['id'];
		$Fn_QHB->Config['WxShare']['WxImg'] = $Info['param']['wx_img'] ? $Info['param']['wx_img'] : $Info['thumbnail'];
		$Fn_QHB->Config['WxShare']['WxImg'] = strpos($Fn_QHB->Config['WxShare']['WxImg'],'http') !== false ? $Fn_QHB->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_QHB->Config['WxShare']['WxImg'];

	}else{
		exit('Errer: No Data');
	}
}else if($_GET['m'] == 'winning_floor'){//�н�¥��
	$Info = $Fn_QHB->GetViewthreadInfo($_GET['tid']);
	if($Info){
		$Info['param'] = unserialize($Info['param']);
		$navtitle = $metakeywords = $metadescription = $Fn_QHB->Config['LangVar']['WinningFloorTtile'];
		$WinningFloorList = array_filter(explode("\n",$Info['param']['winning_floor']));//�н�¥��
	}else{
		exit('Errer: No Data');
	}
}else if($_GET['m'] == 'ranking'){//���а�
	$navtitle = $metadescription = $metakeywords = $Fn_QHB->Config['LangVar']['RankingTitle'];
	if($_GET['tid']){
		$MoneyRankingList = $Fn_QHB->GetPostMoneyRanking($_GET['tid']);
	}else{
		$MoneyRankingList = $Fn_QHB->GetPostMoneyRanking();
	}
	
}else if($_GET['m'] == 'poster'){//���ɺ���
	$navtitle = $metadescription = $metakeywords = $Fn_QHB->Config['LangVar']['Poster'];

}else if($_GET['m'] == 'share'){//����
	
	$Info = $Fn_QHB->GetViewthreadInfo($_GET['tid']);
	if($Info){
		$Info['param'] = unserialize($Info['param']);
		$CountMoney =  $Fn_QHB->GetCountMoney($Info['id']);
		$Info['param']['sharesuccesstitle'] = str_replace(array('{Money}','{CountMoney}'),array($_GET['money'],$CountMoney),$Info['param']['sharesuccesstitle']);
		$Info['param']['sharesuccessdesc'] = str_replace(array('{Money}','{CountMoney}'),array($_GET['money'],$CountMoney),$Info['param']['sharesuccessdesc']);

		$navtitle = $metakeywords = $metadescription = $Info['param']['sharesuccesstitle'];
		//����
		$Fn_QHB->Config['WxShare']['WxTitle'] = $Info['param']['sharesuccesstitle'] ? $Info['param']['sharesuccesstitle'] : '['.$Info['ftitle'].']'.$Info['title'];
		$Fn_QHB->Config['WxShare']['WxDes'] = $Info['param']['sharesuccessdesc'] ? $Info['param']['sharesuccessdesc'] : addslashes(strip_tags($Info['param']['content']));
		$Fn_QHB->Config['WxShare']['WxUrl'] = $Fn_QHB->GetRandShare() ? $Fn_QHB->GetRandShare().'/plugin.php?id=fn_qhb&m=viewthread&tid='.$Info['id'] : $Fn_QHB->Config['ViewThreadUrl'].$Info['id'];
		$Fn_QHB->Config['WxShare']['WxImg'] = $Info['param']['wx_img'] ? $Info['param']['wx_img'] : $Info['thumbnail'];
		$Fn_QHB->Config['WxShare']['WxImg'] = strpos($Fn_QHB->Config['WxShare']['WxImg'],'http') !== false ? $Fn_QHB->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_QHB->Config['WxShare']['WxImg'];
	}else{
		exit('Errer: No Data');
	}
}else if($_GET['m'] == 'he_user'){//������Աҳ
	$navtitle = $metadescription = $metakeywords = $Fn_QHB->Config['LangVar']['HeUserTitle'];
	$HeUserInfo = $Fn_QHB->GetUserInfo($_GET['uid']);
	if(!$HeUserInfo){
		exit('Errer: No Data');
	}else{
		$HeViewthreadList = $Fn_QHB->GetViewthreadListUid($HeUserInfo['uid'],1);//Ta�����ĺ��
		$HeViewthreadListJoin = $Fn_QHB->GetViewthreadListJoinUid($HeUserInfo['uid'],1);//Ta�����
	}
}else if($_GET['m'] == 'user'){//��Աҳ
	$navtitle = $metadescription = $metakeywords = $Fn_QHB->Config['LangVar']['UserTitle'];
	$MyViewthreadList = $Fn_QHB->GetViewthreadListUid($_G['uid']);//�ҷ����ĺ��
	$MyViewthreadListJoin = $Fn_QHB->GetViewthreadListJoinUid($_G['uid']);//�Ҳ����
}else if($_GET['m'] == 'user_add_info'){//���ӻ�Ա�����Ϣ
	$navtitle = $metadescription = $metakeywords = $Fn_QHB->Config['LangVar']['AddUserInfoTitle'];
	$Info = $Fn_QHB->GetViewthreadUidInfo($_G['uid']);
	//ͼƬ�ϴ�
	if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_upload/upload.class.php')){
		@include DISCUZ_ROOT.'./source/plugin/fn_upload/upload.class.php';
		$UploadConfig = FnUpload::Config();
	}
}else if($_GET['m'] == 'user_hb_log'){//����б�
	$navtitle = $metadescription = $metakeywords = $Fn_QHB->Config['LangVar']['HbLogTitle'];
	$HbList = $Fn_QHB->GetHbList();
}else if($_GET['m'] == 'payok'){
	$navtitle = $metadescription = $metakeywords = $Fn_QHB->Config['LangVar']['AddHBBOk'];
}else if($_GET['m'] == 'calculation'){
	if($_POST['formhash'] == formhash() && $_POST['f'] == 'calculation'){
		foreach($_POST['num'] as $Key => $Val){
			$Num += $Val;
		}
		$NoRand = $Fn_QHB->NoRand(1,$_POST['max'],$Num);
		$Html = '';
		foreach($_POST['money'] as $Key => $Val){
			if($Val){
				$Html .= $Val.'|';
				if($Key){
					$J = $Key - 1;
					$Limit += $_POST['num'][$J];
				}else{
					$Limit = 0;
				}
				$NoRandTo = array_slice($NoRand,$Limit,$_POST['num'][$Key]);
				if($_POST['rand']){
					asort($NoRandTo);
				}
				$Html .= implode(',',$NoRandTo);
				$Html .= "\r\n";
			}
		}
	}


	$navtitle = $metadescription = $metakeywords = $Fn_QHB->Config['LangVar']['CalculationTitle'];
}else if($_GET['m'] == 'index'){
	$navtitle = $Fn_QHB->Config['PluginVar']['Title'];
	$metakeywords = $Fn_QHB->Config['PluginVar']['Keywords'];
	$metadescription = $Fn_QHB->Config['PluginVar']['Description'];
	$BannerList = $Fn_QHB->GetModulesBanner();//���
	$ViewthreadList = $Fn_QHB->GetIndexViewthreadList();//�б�
	$NavList = array_filter(explode("\n",$Fn_QHB->Config['PluginVar']['NavList']));//����

}else{
	exit('Errer: No Data');
}
include template('fn_qhb:'.$_GET['m']);
?>