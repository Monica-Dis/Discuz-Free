<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Common.php');
$Operation = in_array($_GET['Operation'], array('Del','Edit','Add')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ���� */
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_QHB->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}">&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_QHB->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">&nbsp;&nbsp;<a href="{$OpCpUrl}&Operation=Edit">{$Fn_QHB->Config['LangVar']['AddUserInfoTitle']}</a></td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'I.dateline';
		if($_GET['keyword']){
			$Where .= ' and concat(I.uid,I.username) like(\'%'.addslashes(dhtmlspecialchars($_GET['keyword'])).'%\')';
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		$TdStyle = array('width="80"','width="80"', 'width="80"','width="120"','width="150"','width="60"','width="120"');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'QiangLouModule', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_QHB->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
            'Uid',
			$Fn_QHB->Config['LangVar']['UserNameTitle'],
			$Fn_QHB->Config['LangVar']['NameTitle'],
			$Fn_QHB->Config['LangVar']['CallTitle'],
			$Fn_QHB->Config['LangVar']['ContentTitle'],
			'Logo',
			$Fn_QHB->Config['LangVar']['TimeTitle'],
			$Fn_QHB->Config['LangVar']['OperationTitle']
		), 'header tbm',$TdStyle);
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['uid'].'" />'.$Module['uid'],
				$Module['username'],
				$Module['name'],
				$Module['tel'],
				$Module['content'],
				$Module['logo'] ? '<a href="'.$Module['logo'].'" target="_blank"><img src="'.$Module['logo'].'" width="50" height="50"></a>' : '',
				date('Y-m-d H:i',$Module['dateline']),
				'<a href="'.$OpCpUrl.'&Operation=Edit&uid='.$Module['uid'].'">'.$Fn_QHB->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&uid='.$Module['uid'].'&formhash='.FORMHASH.'">'.$Fn_QHB->Config['LangVar']['DelTitle'].'</a>'
			));
		}
		showsubmit('Submit','submit','del','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        /*Dism_taobao_com*/showtablefooter();
		showformfooter();/*Dism��taobao��com*/
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_QHB->TableMemberInfo,'uid ='.$Val);
			}
			cpmsg($Fn_QHB->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_QHB->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Operation == 'Edit' || $Operation == 'Add'){//�Ƿ���ʾ
	$UId = intval($_GET['uid']);
	$Info = $UId ? DB::fetch_first('SELECT * FROM '.DB::table($Fn_QHB->TableMemberInfo).' where uid = '.$UId) : array();
	$Title = $Fn_QHB->Config['LangVar']['EditTitle'];
	if(!submitcheck('DetailSubmit')) {
		$formUrl = ltrim(rawurldecode(cpurl()),'action=');
		showformheader($formUrl,'enctype');
		showtableheader();
		showtitle($Title);
		showsetting($Fn_QHB->Config['LangVar']['NameTitle'], 'name', $Info['name'], 'text');
		showsetting($Fn_QHB->Config['LangVar']['CallTitle'], 'tel', $Info['tel'], 'text');
		showsetting($Fn_QHB->Config['LangVar']['ContentTitle'], 'content', $Info['content'], 'textarea');
		
		if($Info['logo']) {
			$LogoHtml = '<label><input type="checkbox" class="checkbox" name="dellogo" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Info['logo'].'" target="_blank"><img src="'.$Info['logo'].'" width="100"/></a><input type="hidden" value="'.$Info['logo'].'" name="logo"><br />'.$Fn_QHB->Config['LangVar']['InfoLogoPrompt'];
		}else{
			$LogoHtml  = $Fn_QHB->Config['LangVar']['InfoLogoPrompt'];
		}
		showsetting($Fn_QHB->Config['LangVar']['InfoLogoTitle'], 'logonew','', 'filetext', '', 0, $LogoHtml);

		showsetting('Uid', 'newuid', $Info['uid'], 'text');
		/*Dism_taobao_com*/showtablefooter();
		showsubmit('DetailSubmit');
		showformfooter();/*Dism��taobao��com*/
	}else{
		$Data['name'] = addslashes(strip_tags($_GET['name']));
		$Data['tel'] = addslashes(strip_tags($_GET['tel']));
		$Data['content'] = addslashes($_GET['content']);//�豣��html����
		$Data['uid'] = intval($_GET['newuid']);
		/* ��ϵ��ʽ�ж� */
		$IsMob = "/^1[3-5,8]{1}[0-9]{9}$/";
		$IsTel = "/^([0-9]{3,4}-)?[0-9]{7,8}$/";
		if(!preg_match($IsMob,$_GET['tel']) && !preg_match($IsTel,$_GET['tel'])){
			cpmsg($Fn_QHB->Config['LangVar']['CallErr'],'','error');
		}

		/* ���ͼ */
		if($_GET['dellogo'] == 'yes'){
			unlink(DISCUZ_ROOT.$Info['logo']);
			$Data['logo'] = '';
		}
		if($_FILES['logonew']['size']){
			$LogoFile = $Fn_QHB->UploadIconBanner($_FILES['logonew'],$Info['logo']);
			if($LogoFile['Errorcode']){
				cpmsg($Fn_QHB->Config['LangVar']['ImgErr'],'','error');
			}else{
				$Data['logo'] = $LogoFile['Path'];
			}
		}else if($_GET['logonew']){
			$Data['logo'] = addslashes($_GET['logonew']);
		}
		/* ���ͼ End */
		
		$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
		if($Member){
			$Data['username'] = addslashes(strip_tags($Member['username']));
			if($Info){
				DB::update($Fn_QHB->TableMemberInfo,$Data,'uid = '.$UId);
			}else{
				$Data['dateline'] = time();
				DB::insert($Fn_QHB->TableMemberInfo,$Data);
			}
			cpmsg($Fn_QHB->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_QHB->Config['LangVar']['NoUserErr'],'','error');
		}
	}
	
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['uid']){//ɾ��
	$UId = intval($_GET['uid']);
	DB::delete($Fn_QHB->TableMemberInfo,'uid ='.$UId);
	cpmsg($Fn_QHB->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}
/* ��Ƶ�б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_QHB;
	$FetchSql = 'SELECT I.* FROM '.DB::table($Fn_QHB->TableMemberInfo).' I '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ��Ƶ���� */
function GetModulesCount($Where){
	global $Fn_QHB;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_QHB->TableMemberInfo).' I '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>