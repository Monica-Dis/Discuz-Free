<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class Fn_QHB{
	public function __construct() {
		global $_G,$plugin;
		loadcache('plugin');
		$this->Config['PluginVar'] = (array) $_G['cache']['plugin']['fn_qhb'];
		$this->Config['LangVar'] = lang('plugin/fn_qhb');
		$this->Config['Path'] = 'source/plugin/fn_qhb';
		$this->Config['StaticPath'] = $this->Config['Path'].'/static';
		$this->Config['StaticPicPath'] = $this->Config['Path'].'/attachment/';
		$this->Config['DataPath'] = DISCUZ_ROOT.'/data/fn/';
		$this->Config['DataPluginPath'] = $this->Config[DataPath].$plugin['identifier'].'/';
		$this->Config['Url'] = $_G['siteurl'].'plugin.php?id=fn_qhb';
		$this->Config['AddUrl'] =  $this->Config['Url'].'&m=add';
		$this->Config['ViewThreadUrl'] =  $this->Config['Url'].'&m=viewthread&tid=';
		$this->Config['ViewWinningFloorUrl'] =  $this->Config['Url'].'&m=winning_floor&tid=';
		$this->Config['RankingUrl'] =  $this->Config['Url'].'&m=ranking&tid=';
		$this->Config['HeUserUrl'] =  $this->Config['Url'].'&m=he_user&uid=';
		$this->Config['UserUrl'] =  $this->Config['Url'].'&m=user';
		$this->Config['UserInfoUrl'] =  $this->Config['Url'].'&m=user_add_info';
		$this->Config['WithdrawalsUrl'] =  $this->Config['Url'].'&m=withdrawals';
		$this->Config['WithdrawalsLogUrl'] =  $this->Config['Url'].'&m=withdrawals_log';
		$this->Config['CalculationUrl'] =  $this->Config['Url'].'&m=calculation';
		$this->Config['WalletUrl'] = $_G['siteurl'].'plugin.php?id=fn_wallet';
		$this->Config['UserHbUrl'] = $this->Config['Url'].'&m=user_hb_log';
		$this->Config['PosterUrl'] = $this->Config['Url'].'&m=poster';
		$this->Config['AjaxUrl'] =  $this->Config['Url'].':Ajax';
		$this->Config['WxShare'] = array(
			'WxTitle' => $this->Config['PluginVar']['WxTitle'],
			'WxDes' => $this->Config['PluginVar']['WxDes'],
			'WxImg' => strpos($this->Config['PluginVar']['WxImg'],'http') !== false ? $this->Config['PluginVar']['WxImg'] : $_G['siteurl'].$this->Config['PluginVar']['WxImg'],
			'WxUrl' => $this->GetRandShare() ? $this->GetRandShare().'/plugin.php?id=fn_qhb' : $this->Config['Url']
		);
		
		if(!is_dir(DISCUZ_ROOT.$this->Config['StaticPicPath'])){
			mkdir(DISCUZ_ROOT.$this->Config['StaticPicPath']);
		}
		if(!is_dir($this->Config['DataPath'])){
			mkdir($this->Config['DataPath']);
		}
		if(!is_dir($this->Config['DataPluginPath'])){
			mkdir($this->Config['DataPluginPath']);
		}
		$this->TableQHB = 'fn_qhb';
		$this->TableBanner = 'fn_qhb_banner';
		$this->TablePost = 'fn_qhb_post';
		$this->TableHBLog = 'fn_qhb_log';
		$this->TableMemberInfo = 'fn_qhb_member_info';
		$this->TableShareLog = 'fn_qhb_share_log';
		$this->TablePostFloorId = 'fn_qhb_post_floorid';
		$this->TablePostNoFloorId = 'fn_qhb_post_nofloorid';
		$this->Config['LangVar'][AddHBMoneyMinErr] = str_replace(array('{Money}'),array($this->Config['PluginVar']['AddMinMoney']),$this->Config['LangVar']['AddHBMoneyMinErr']);

		if($this->Config['PluginVar']['AppType'] != '2' && $this->Config['PluginVar']['AppType'] != '1'){//不是千帆、马甲
			if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_wallet/wallet.class.php')){
				@include DISCUZ_ROOT.'./source/plugin/fn_wallet/wallet.class.php';
			}
		}
	}
	/* 随机分享域名 */
	public function GetRandShare(){
		$ShareDomainArr = array_filter(explode("\r\n",$this->Config['PluginVar']['ShareDomain']));
		if($ShareDomainArr){
			return $ShareDomainArr[rand(0,count($ShareDomainArr) - 1)].'/';
		}
	}
	/* 用户资料 */
	public function GetUserInfo($Uid){
		$Uid = intval($Uid);
		$FirstSql = 'SELECT I.name,I.tel,I.content,I.logo,G.*,M.*,C.extcredits1,C.extcredits2,C.extcredits3,C.extcredits4,C.extcredits5,C.extcredits6,C.extcredits7,C.extcredits8 FROM '.DB::table('common_member').' M LEFT JOIN '.DB::table('common_member_count').' C on C.uid = '.$Uid.' LEFT JOIN '.DB::table('common_usergroup').' G on G.groupid = M.groupid LEFT JOIN '.DB::table($this->TableMemberInfo).' I on I.uid = M.uid where M.uid = '.$Uid;
		$UserInfo = DB::fetch_first($FirstSql);
		$UserInfo['money'] = $UserInfo['money'] ? $UserInfo['money'] : 0;
		$UserInfo['CountMoney'] = DB::result_first('SELECT sum(money) FROM '.DB::table($this->TableQHB).' where uid = '.$Uid.' and pay_state = 1');
		$UserInfo['CountMoney'] = $UserInfo['CountMoney'] ? $UserInfo['CountMoney'] : 0;
		$UserInfo['CountHBMoney'] = DB::result_first('SELECT sum(money) FROM '.DB::table($this->TableHBLog).' where uid = '.$Uid);
		$UserInfo['CountHBMoney'] = $UserInfo['CountHBMoney'] ? $UserInfo['CountHBMoney'] : 0;

		$UserInfo['CountHBMoneyState'] = DB::result_first('SELECT count(*) FROM '.DB::table($this->TableHBLog).' where state = 0 and uid = '.$Uid);

		$UserInfo['CountPost'] = DB::result_first('SELECT count(*) FROM '.DB::table($this->TablePost).' where uid = '.$Uid);
		return $UserInfo;
	}
	public function GetCountMoney($Id){
		global $_G;
		$Uid = intval($_G['uid']);
		$Id = intval($Id);
		$CountMoney = DB::result_first('SELECT sum(money) FROM '.DB::table($this->TableHBLog).' where uid = '.$Uid.' and tid = '.$Id);
		return $CountMoney ? $CountMoney : 0;
	} 
	/* 首页红包列表 */
	public function GetIndexViewthreadList(){
		$Where = ' where T.display = 1';
		$FetchSql = 'SELECT G.stars,T.* FROM '.DB::table($this->TableQHB).' T LEFT JOIN '.DB::table('common_member').' M on M.uid = T.uid LEFT JOIN '.DB::table('common_usergroup').' G on G.groupid = M.groupid '.$Where.' order by T.displayorder desc';
		return DB::fetch_all($FetchSql);
	}
	/* 用户发布红包列表 */
	public function GetViewthreadListUid($Uid,$Display=null){
		$Uid = intval($Uid);
		$Display = intval($Display);
		if($Display){
			$Where .= ' And T.display = '.$Display;
		}
		$FetchSql = 'SELECT G.stars,T.* FROM '.DB::table($this->TableQHB).' T LEFT JOIN '.DB::table('common_member').' M on M.uid = T.uid LEFT JOIN '.DB::table('common_usergroup').' G on G.groupid = M.groupid where T.uid = '.$Uid.$Where.' order by T.displayorder desc';;
		return DB::fetch_all($FetchSql);
	}
	/* 用户参与红包列表  */
	public function GetViewthreadListJoinUid($Uid){
		$Uid = intval($Uid);
		$Where = ' Where P.uid = '.$Uid;
		$TidData = DB::fetch_all("SELECT P.tid FROM ".DB::table($this->TablePost)." P ".$Where." GROUP BY P.tid ORDER BY tid DESC");
		$TidList = array();
		foreach ($TidData as $Key => $Val) {
			$TidList[] = $Val['tid'];
		}
		if($TidList){
			$FetchSql = 'SELECT G.stars,T.* FROM '.DB::table($this->TableQHB).' T LEFT JOIN '.DB::table('common_member').' M on M.uid = T.uid LEFT JOIN '.DB::table('common_usergroup').' G on G.groupid = M.groupid where T.id in('.implode(',',$TidList).') And T.display = 1 order by T.displayorder desc';;
			return DB::fetch_all($FetchSql);
		}
	}
	/* 点击率增加 */
	public function Click($Table,$Id){
		$Id = intval($Id);
		DB::query("UPDATE ".DB::table($Table)." SET click = click+1 WHERE id=$Id");
	}
	/* 抢红包详情 */
	public function GetViewthreadInfo($Id){
		$Id = intval($Id);
		$FirstSql = 'SELECT I.name,I.logo,I.tel,I.content,G.stars,M.username as musername,T.* FROM '.DB::table($this->TableQHB).' T LEFT JOIN '.DB::table('common_member').' M on M.uid = T.uid LEFT JOIN '.DB::table($this->TableMemberInfo).' I on I.uid = T.uid LEFT JOIN '.DB::table('common_usergroup').' G on G.groupid = M.groupid where T.id = '.$Id;
		$Info = DB::fetch_first($FirstSql);
		$Info['PostCount'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TablePost).' where tid = '.$Id);
		$Info['ShareCount'] = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableShareLog).' where tid = '.$Id);
		return $Info;
	}
	/* 抢红包详情-Uid */
	public function GetViewthreadUidInfo($Uid){
		$Uid = intval($Uid);
		$FirstSql = 'SELECT G.stars,T.* FROM '.DB::table($this->TableQHB).' T LEFT JOIN '.DB::table('common_member').' M on M.uid = T.uid LEFT JOIN '.DB::table('common_usergroup').' G on G.groupid = M.groupid where T.uid = '.$Uid;
		return DB::fetch_first($FirstSql);
	}
	/* 评论列表 */
	public function GetAjaxPostList($Id,$Page=null){
		$Page = $Page ? intval($Page):0;
		$Id = intval($Id);
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['PostNum']).','.$this->Config['PluginVar']['PostNum'];
		$FetchSql = 'SELECT G.stars,P.* FROM '.DB::table($this->TablePost).' P LEFT JOIN '.DB::table('common_member').' M on M.uid = P.uid LEFT JOIN '.DB::table('common_usergroup').' G on G.groupid = M.groupid where P.tid = '.$Id.' order by P.id desc '.$Limit;
		$Results = $this->POstListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}
	/* 评论列表格式转换 */
	public function POstListFormat($Array){
		foreach ($Array as $Key => $Val) {
			$Array[$Key]['dateline'] = date('Y-m-d H:i:s',$Val['dateline']);
		}
		return $Array;
	}
	/* 发红包排行榜 */
	public function GetMoneyRanking(){
		$Limit = $this->Config['PluginVar']['RanKingLimit'] ? $this->Config['PluginVar']['RanKingLimit'] : 100;
		$Data = DB::fetch_all("SELECT M.username,Q.uid,sum(Q.money) as sum FROM ".DB::table($this->TableQHB)." Q LEFT JOIN ".DB::table('common_member')." M on M.uid = Q.uid WHERE Q.display = 1 and pay_state = 1 GROUP BY Q.uid ORDER BY sum DESC limit ".$Limit);
		return $Data;
	}
	/* 中奖结果 */
	public function GetPostMoneyList($Id,$Limit){
		$Id = intval($Id);
		$Limit = $Limit ? $Limit : $this->Config['PluginVar']['RanKingLimit'];
		$Limit = $Limit ? $Limit : 100;
		if($Id){
			$Where = ' Where L.tid = '.$Id;
		}
		$Data = DB::fetch_all("SELECT M.username,L.uid,L.money as sum FROM ".DB::table($this->TableHBLog)." L LEFT JOIN ".DB::table('common_member')." M on M.uid = L.uid ".$Where." GROUP BY L.uid ORDER BY id DESC limit ".$Limit);
		return $Data;
	}
	/* 抢钱排行榜 */
	public function GetPostMoneyRanking($Id,$Limit){
		$Id = intval($Id);
		$Limit = $Limit ? $Limit : $this->Config['PluginVar']['RanKingLimit'];
		$Limit = $Limit ? $Limit : 100;
		if($Id){
			$Where = ' Where L.tid = '.$Id;
		}
		$Data = DB::fetch_all("SELECT M.username,L.uid,sum(L.money) as sum FROM ".DB::table($this->TableHBLog)." L LEFT JOIN ".DB::table('common_member')." M on M.uid = L.uid ".$Where." GROUP BY L.uid ORDER BY sum DESC limit ".$Limit);
		return $Data;
	}
	/* 盖楼排行榜 */
	public function GetPostRanking($Id){
		$Id = intval($Id);
		$Limit = $this->Config['PluginVar']['RanKingLimit'] ? $this->Config['PluginVar']['RanKingLimit'] : 100;
		if($Id){
			$Where = ' Where P.tid = '.$Id;
		}
		$Data = DB::fetch_all("SELECT M.username,P.uid,count(P.id) as sum FROM ".DB::table($this->TablePost)." P LEFT JOIN ".DB::table('common_member')." M on M.uid = P.uid ".$Where." GROUP BY P.uid ORDER BY sum DESC limit ".$Limit);
		return $Data;
	}
	/* 红包列表 */
	public function GetHbList(){
		global $_G;
		$Where = ' Where uid = '.intval($_G['uid']);
		$Data = DB::fetch_all("SELECT * FROM ".DB::table($this->TableHBLog).$Where." ORDER BY state asc");
		return $Data;
	}
	/* 中奖个数 */
	public function GetHbCount($Id){
		global $_G;
		$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($this->TableHBLog).' where tid = '.intval($Id);
		return DB::result_first($FetchSql);//返回总数
	}

	public function GetAjaxHbState($Id){
		global $_G;
		$Id = intval($Id);
		$Uid = intval($_G['uid']);
		$Log =  DB::fetch_first('SELECT * FROM '.DB::table($this->TableHBLog).' where uid = '.$Uid.' and id = '.$Id);
		if($Log){
			if($Log['state'] == 1){
				$Data['State'] = 201;
				$Data['Msg'] = urlencode($this->Config['LangVar']['HbErr1']);
			}else{
				$HBState = false;
				if($this->Config['PluginVar']['AppType'] == 2){//千帆发红包
					if($this->QFAddBalance($Uid,$Log['money'])){
						$HBState = true;
					}
				}else if($this->Config['PluginVar']['AppType'] == 1){//马甲发红包
					if($this->GetMagAccountTransfer($Uid,$Log['money'],$this->Config['LangVar']['WalletContent'])){
						$HBState = true;
					};
				}else{//飞鸟钱包
					if(FnWallet::WalletLogInsertBy($Uid,$this->Config['LangVar']['WalletContent'],$Log['money'],1,'fn_qhb')){
						$HBState = true;
					}
				}
				if($HBState && DB::update($this->TableHBLog,array('state'=>1),'id='.$Id)){
					$Data['State'] = 200;
					$Data['Msg'] = urlencode($this->Config['LangVar']['HbOk']);
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['HbErr']);
				}
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoHbErr']);
			return $Data;
		}
	}
	/* 分享 */
	public function GetAjaxShare($Id,$Type){
		global $_G;
		$Id = intval($Id);
		$Uid = intval($_G['uid']);
		$Info = $this->GetViewthreadInfo($Id);
		$AGENT = $_SERVER["HTTP_USER_AGENT"];
		if((strpos($AGENT,'Appbyme') !== false || strpos($AGENT,'MAGAPPX') !== false || strpos($AGENT,'QianFan') !== false || strpos($AGENT,'MicroMessenger') !== false) && $Info){
			$InsData['tid'] = $Id;
			$InsData['uid'] = $Uid;
			$InsData['username'] = addslashes(strip_tags($_G['username']));
			$InsData['type'] = addslashes(strip_tags($Type));
			$InsData['dateline'] = time();
			if(DB::insert($this->TableShareLog,$InsData)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['ShareOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['ShareErr']);
			}
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['ShareErr']);
		}
		return $Data;
		
	}
	/* 抢红包回帖 */
	public function GetAjaxMessage($Id,$Content,$Lat,$Lng){
		global $_G;
		$Id = intval($Id);
		$Uid = intval($_G['uid']);
		$Content = addslashes(strip_tags($this->StrToGBK($Content)));
		$Data = array();
		if(!$Content){//检测是否为空
			$Data['Msg'] = $this->Config['LangVar']['MessageNullErr'];
			return $Data;
		}
		$censor = discuz_censor::instance();
		$censor->check($Content);
		if($censor->modbanned()){//违规词
			$Data['Msg'] = $this->Config['LangVar']['WordBanned'];
			return $Data;
		}
		$Info = $this->GetViewthreadInfo($Id);
		if($Info){
			$Info['param'] = unserialize($Info['param']);
			$MyLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TablePost).' where tid = '.$Id.' and uid = '.$Uid.' order by id desc');
			if(time() < strtotime("+".$Info['param']['repeat_time']." second",$MyLog['dateline'])){//时间限制
				$TIME = $Info['param']['repeat_time'] - (time() - $MyLog['dateline']);
				$Data['Msg'] = str_replace('{TIME}',$TIME,$this->Config['LangVar']['InfoTimeErr']);
				return $Data;
			}
			if($Info['start_time'] < time() && $Info['end_time'] > time()){//活动开始
				if($Info['param']['prohibit_address'] && $this->CheCkRestrictedAreas($Info['param']['prohibit_address'],$Lat,$Lng)){//地区限制
					$Data['Msg'] = str_replace(array('{Address}'),array($Info['param']['prohibit_address']),$this->Config['LangVar']['ProhibitAddressErr']);
					return $Data;
				}
				if($Content != $Info['param']['pass']){//口令不匹配
					$Data['Msg'] = str_replace('{K}',$Info['param']['pass'],$this->Config['LangVar']['PassErr']);
					return $Data;
				}


				
				$PostCount = DB::result_first('SELECT count(*) FROM '.DB::table($this->TablePost).' where dateline > '.$Info['start_time'].' and dateline < '.$Info['end_time'].' and uid = '.$Uid);//抢楼次数
				$ShareLog = DB::result_first('SELECT count(*) FROM '.DB::table($this->TableShareLog).' where tid = '.$Id.' AND uid = '.$Uid.' order by id desc');
		
				if($Info['param']['limitswitch']){//限制每人抢几次
					if(!$ShareLog){
						$Data['State'] = 201;
						return $Data;
					}else if($PostCount >= $Info['param']['frequency']){
						$Data['Msg'] = $this->Config['LangVar']['LimitSwitchErr'];
						return $Data;
					}
				}else{
					if($Info['param']['shareloop']){
						$ShareLog = $Info['param']['sharenumlimit'] && $ShareLog >= $Info['param']['sharenumlimit'] ? $Info['param']['sharenumlimit'] : $ShareLog;
						$Num = $Info['param']['frequency'] + ($ShareLog * $Info['param']['sharenum']);
						if($Info['param']['sharenumlimit'] && $ShareLog >= $Info['param']['sharenumlimit'] && $PostCount >= $Num){
							$Data['Msg'] = $this->Config['LangVar']['ShareNumLimitErr'];
							return $Data;
						}else if($PostCount >= $Num){//超过次数需要分享
							$Data['State'] = 201;
							return $Data;
						}
					}else{
						if($PostCount >= $Info['param']['frequency'] && !$ShareLog){//超过次数需要分享
							$Data['State'] = 201;
							return $Data;
						}
					}
				}
				$Floor = DB::insert($this->TablePostFloorId,array('tid'=>$Info['id']),true);

				$Ins['tid'] = $Result['tid'] = $Id;
				$Ins['uid'] = $Result['uid'] = $Uid;
				$Ins['username'] = $Result['username'] = addslashes(strip_tags($_G['username']));
				$Ins['content'] = $Content;
				$Ins['floor'] = $Result['floor'] = $Floor;
				$Ins['state'] = $Result['State'] = 1;
				$Ins['dateline'] = time();
				$Pid = DB::insert($this->TablePost,$Ins,true);
				if($Pid){
					$Result['dateline'] = date('Y-m-d H:i:s',time());
					$UserGroup = DB::fetch_first('SELECT stars FROM '.DB::table('common_usergroup').' where groupid = '.$_G[member][groupid]);
					$Result['stars'] = $UserGroup['stars'];
					$Data['Result'] = $Result;
					$WinningFloorArray = explode("\n",$Info['param']['winning_floor']);
					foreach($WinningFloorArray as $Val){//抢红包
						$MoneyArray = explode('|',$Val);
						$Money = $MoneyArray[0];
						$FloorArray = explode(',',$MoneyArray[1]);
						if(in_array($Floor,$FloorArray)){//抢到红包
							
							$HBLog['tid'] = $Id;
							$HBLog['uid'] = $Uid;
							$HBLog['username'] =  addslashes(strip_tags($_G['username']));
							$HBLog['money'] = addslashes(strip_tags($Money));
							$HBLog['floor'] = $Floor;
							$HBLog['dateline'] = time();
							$HBId = DB::insert($this->TableHBLog,$HBLog,true);
							$HBState = false;
							if($HBId){
								if($this->Config['PluginVar']['AppType'] == 2){//千帆发红包
									if($this->QFAddBalance($Uid,$Money)){
										$HBState = true;
									}
								}else if($this->Config['PluginVar']['AppType'] == 1){//马甲发红包
									if($this->GetMagAccountTransfer($Uid,$Money,$this->Config['LangVar']['WalletContent'])){
										$HBState = true;
									};
								}else{//飞鸟钱包
									if(FnWallet::WalletLogInsertBy($Uid,$this->Config['LangVar']['WalletContent'],$Money,1,'fn_qhb')){
										$HBState = true;
									}
								}
								if($HBState){
									$Data['HBId'] = '';
									DB::update($this->TableHBLog,array('state'=>1),'id='.$HBId);
								}else{
									$Data['HBId'] = $HBId;
								}
								
								$Data['State'] = 202;//中奖，抢到楼层
								$Data['Money'] = sprintf("%.2f",$Money);//中奖，抢到楼层
								$Data['Msg'] = str_replace(array('{FLOOR}'),array($Floor),$this->Config['LangVar']['GXN']);
								$CountMoney = $this->GetCountMoney($Id);
								$Data['ShareTitle'] = str_replace(array('{Money}','{CountMoney}'),array($Data['Money'],$CountMoney),$Info['param']['sharesuccesstitle']);
								$Data['ShareDes'] = str_replace(array('{Money}','{CountMoney}'),array($Data['Money'],$CountMoney),$Info['param']['sharesuccessdesc']);
								return $Data;
							}else{
								$Data['Msg'] =  $this->Config['LangVar']['SystemErr'];
								return $Data;	
							}
						}
					}
					$Data['State'] = 203;//未中奖，抢到楼层
					$Data['Msg'] = str_replace(array('{FLOOR}'),array($Floor),$this->Config['LangVar']['HYH']);
					return $Data;
				}else{
					$Data['Msg'] = $this->Config['LangVar']['InfoErr'];
					return $Data;
				}
			}else{//活动未开始
				if($Info['param']['startcommentswitch'] && time() < $Info['start_time']){
					$Data['Msg'] = $this->Config['LangVar']['StartCommentErr'];
					return $Data;
				}

				if($Info['param']['endcommentswitch'] && time() > $Info['end_time']){
					$Data['Msg'] = $this->Config['LangVar']['EndCommentErr'];
					return $Data;
				}

				$Floor = DB::insert($this->TablePostNoFloorId,array('tid'=>$Info['id']),true);
				$Ins['tid'] = $Result['tid'] = $Id;
				$Ins['uid'] = $Result['uid'] = $Uid;
				$Ins['username'] = $Result['username'] = addslashes(strip_tags($_G['username']));
				$Ins['content'] = $Content;
				$Ins['floor'] = $Result['floor'] = $Floor;
				$Ins['dateline'] = time();
				$Pid = DB::insert($this->TablePost,$Ins,true);
				if($Pid){
					$Result['dateline'] = date('Y-m-d H:i:s',time());
					$UserGroup = DB::fetch_first('SELECT stars FROM '.DB::table('common_usergroup').' where groupid = '.$_G['member']['groupid']);
					$Result['stars'] = $UserGroup['stars'];
					$Data['State'] = 200;
					$Data['Result'] = $Result;
					return $Data;
				}else{
					$Data['Msg'] = $this->Config['LangVar']['InfoErr'];
					return $Data;
				}
			}
		}else{//无活动
			$Data['Msg'] = $this->Config['LangVar']['NoInfoErr'];
			return $Data;
		}
	}
	/* 发红包 */
	public function GetAjaxAdd($Post){
		global $_G;
		$Post = $this->StrToGBK($Post);
		$InsData = array();
		$InsData['ftitle'] = addslashes(strip_tags($Post['ftitle']));
		$InsData['title'] = addslashes(strip_tags($Post['title']));
		$Content = addslashes(strip_tags($Post['content']));
		$InsData['money'] = addslashes(strip_tags($Post['money']));
		$InsData['start_time'] = $Post['start_time'] ? strtotime($Post['start_time']) : time();
		$InsData['end_time'] = strtotime($Post['end_time']);
		$InsData['uid'] = intval($_G['uid']);
		$InsData['username'] = addslashes(strip_tags($_G['username']));
		$InsData['dateline'] = time();
		
		$Param['pass'] = addslashes(strip_tags($Post['pass']));
		$Param['tel'] = addslashes(strip_tags($Post['tel']));
		$Param['brand'] = addslashes(strip_tags($Post['brand']));
		$Param['message'] = addslashes(strip_tags($Post['message']));
		$FtitleLength = $this->Config['PluginVar']['FtitleLength'] ? $this->Config['PluginVar']['FtitleLength'] : 20;
		$TitleLength = $this->Config['PluginVar']['TitleLength'] ? $this->Config['PluginVar']['TitleLength'] : 50; 
		if(!$InsData['ftitle']){//前缀
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddHBFtitleErr']);
			return $Data;
		}else if(dstrlen($InsData['ftitle']) > $FtitleLength){
			$Data['Msg'] = urlencode(str_replace('{Num}',$FtitleLength,$this->Config['LangVar']['AddHBFTitleLengthErr']));
			return $Data;
		}
		if(!$InsData['title']){//标题
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddHBTitleErr']);
			return $Data;
		}else if(dstrlen($InsData['title']) > $TitleLength){
			$Data['Msg'] = urlencode(str_replace('{Num}',$TitleLength,$this->Config['LangVar']['AddHBTitleLengthErr']));
			return $Data;
		}
	
		if(!$Content){//内容
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddHBContentErr']);
			return $Data;
		}
		if(!$Param['pass']){//口令
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddHBPassErr']);
			return $Data;
		}
		if(!$InsData['money']){//金额
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddHBMoneyErr']);
			return $Data;
		}
		if($InsData['money'] < $this->Config['PluginVar']['AddMinMoney']){//金额限制
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddHBMoneyMinErr']);
			return $Data;
		}
		/* 联系方式判断 */
		$IsMob = "/^1[3-7,8]{1}[0-9]{9}$/";
		$IsTel = "/^([0-9]{3,4}-)?[0-9]{7,8}$/";
		if($this->Config['PluginVar']['TelPregMatch']){
			$IsMob = '/'.$this->Config['PluginVar']['TelPregMatch'].'/';
		}

		if($this->Config['PluginVar']['PhonePregMatch']){
			$IsTel = '/'.$this->Config['PluginVar']['PhonePregMatch'].'/';
		}
		
		if(!preg_match($IsMob,$Param['tel']) && !preg_match($IsTel,$Param['tel'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CallErr']);
			return $Data;
		}

		if($InsData['end_time'] <= $InsData['start_time']){//结束时间检测
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddHBEndTimeErr']);
			return $Data;
		}
		
		if(is_array($Post['imgs']) && isset($Post['imgs'])){
			$ImgArr = array_filter($Post['imgs']);
		}else if($Post['imgsarr']){
			$ImgArr = explode(',',array_filter($Post['imgsarr']));
		}
		$Content = '<p>'.$Content.'</p>';
		foreach($ImgArr as $Val){  
			$Content .= '<img src="'.$Val.'">';
		}
		$Param['content'] = addslashes($Content);

		$InsData['param'] = serialize($Param);

		$Id = DB::insert($this->TableQHB,$InsData,true);
		if($Id){
			$Data['Id'] = $Id;
			$Data['State'] = 200;
			$Data['Money'] = $InsData['money'] + ($InsData['money'] * $this->Config['PluginVar']['ExtensionMoney'] / 100);
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AddHBBErr']);
			return $Data;
		}


	}
	/* 获取个人信息展示页 */
	public function GetMemberInfo($Uid){
		$Uid = intval($Uid);
		return DB::fetch_first('SELECT * FROM '.DB::table($this->TableMemberInfo).' where uid = '.$Uid);
	}
	/* 添加个人信息展示页 */
	public function GetAjaxAddMemberInfo($Post){
		global $_G;
		$Post = $this->StrToGBK($Post);
		$Uid = intval($_G['uid']);
		$MemberInfo = $this->GetMemberInfo($Uid);
		$Data = array();
		if($this->Config['PluginVar'][UserAddInfoSwitch]){//没有发过红包不能添加个人信息展示
			if(!$this->GetViewthreadUidInfo($Uid)){
				$Data['Msg'] = urlencode($this->Config['PluginVar']['UserAddInfoHBPrompt']);
				$Data['State'] = 404;
				return $Data;
			}
		}
		$MaxTime = strtotime("+".$this->Config['PluginVar']['UserAddInfoTime']." day",$MemberInfo['dateline']);
		if(time() < $MaxTime){//时间限制
			$Data['Msg'] = urlencode(str_replace('{TIME}',date('Y-m-d H:i:s',$MaxTime),$this->Config['LangVar']['UserAddInfoTimeErr']));
			return $Data;
		}
		if(!$Post['name']){//用户名是否为空
			$Data['Msg'] = urlencode($this->Config['LangVar']['NamePrompt']);
			return $Data;
		}
		/* 联系方式判断 */
		$IsMob = "/^1[3-7,8]{1}[0-9]{9}$/";
		$IsTel = "/^([0-9]{3,4}-)?[0-9]{7,8}$/";
		if($this->Config['PluginVar']['TelPregMatch']){
			$IsMob = '/'.$this->Config['PluginVar']['TelPregMatch'].'/';
		}
		if($this->Config['PluginVar']['PhonePregMatch']){
			$IsTel = '/'.$this->Config['PluginVar']['PhonePregMatch'].'/';
		}
		if(!preg_match($IsMob,$Post['tel']) && !preg_match($IsTel,$Post['tel'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CallErr']);
			return $Data;
		}
		if($this->Config['PluginVar']['PhonePregMatch']){
			$IsTel = '/'.$this->Config['PluginVar']['PhonePregMatch'].'/';
		}

//		if(!$Post['content']){//描述不能为空
//			$Data['Msg'] = urlencode($this->Config['LangVar']['ContentPrompt']);
//			return $Data;
//		}
		
		if($Post['logonew']['0']) {
			$UpData['logo'] = addslashes(strip_tags($Post['logonew']['0']));
		}else if($Post['logo']){
			$UpData['logo'] = addslashes(strip_tags($Post['logo']));
		}else{
			$UpData['logo'] = '';
		}/*else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['InfoLogoErr']);
			return $Data;
		}*/
		$UpData['uid'] = $Uid;
		$UpData['name'] = addslashes(strip_tags($Post['name']));
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['tel'] = addslashes(strip_tags($Post['tel']));
		$UpData['content'] = addslashes(strip_tags($Post['content']));
		$UpData['dateline'] = time();
		if($MemberInfo){
			if(DB::update($this->TableMemberInfo,$UpData,'uid = '.$Uid)){
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
				$Data['State'] = 200;
				return $Data;
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
				return $Data;
			}
		}else{
			if(DB::insert($this->TableMemberInfo,$UpData)){
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
				$Data['State'] = 200;
				return $Data;
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
				return $Data;
			}
		}
	}
	/* 马甲支付 */
	public function GetAjaxMagOrder($Uid,$Money,$Title){//下单
		global $_G;
		$Uid = intval($Uid);
		$Title = addslashes(diconv($Title,CHARSET,'UTF-8'));
		$TradeNo = rand(1,999).'_'.time();
		$Url = 'http://'.$this->Config['PluginVar']['MagDomain'].'/core/pay/pay/unifiedOrder?trade_no='.$TradeNo.'&callback='.urlencode($_G['siteurl']).'&amount='.$Money.'&title='.$Title.'&user_id='.$Uid.'&to_user_id=&des='.$Title.'&remark='.$Title.'&secret='.$this->Config['PluginVar']['MagSecret'].'&to_account=true';
		$Data = dfsockopen($Url);
		if(!$Data){
			$Data = file_get_contents($Url);
		}
		$Res = json_decode($Data,true);
		if($Res['success'] == true){
			$Res['data']['trade_no'] = $TradeNo;
		}
		return $Res;
	}
	public function GetAjaxMagCheckOrder($UnionOrderNum,$Id){//查询订单状态
		global $_G;
		$Uid = intval($_G['uid']);
		$Id = intval($Id);
		$Url = 'http://'.$this->Config['PluginVar']['MagDomain'].'/core/pay/pay/orderStatusQuery?unionOrderNum='.$UnionOrderNum.'&secret='.$this->Config['PluginVar']['MagSecret'];
		$Data = dfsockopen($Url);
		if(!$Data){
			$Data = file_get_contents($Url);
		}
		$Res = json_decode($Data,true);
		$Info = DB::fetch_first('SELECT * FROM '.DB::table($this->TableQHB).' where id = '.$Id.' and uid = '.$Uid);
		if($Res['success'] && $Id){
			if($Info && $Info['State'] != 1 && $Info['pay_state'] != 1){
				$UpData = array('pay_state'=>1);
				if(DB::update($this->TableQHB,$UpData,'id='.$Id)){
					$State = 1;
				}else{
					$State = 0;
				}
			}else{
				$State = 0;
			}
			return $State;
		}
	}
	
	private function GetMagAccountTransfer($Uid,$Amount,$Remark,$OutTradeCode=null){
		$OutTradeCode = $OutTradeCode ? $OutTradeCode :  time().rand(0,999999999);
		$Uid = intval($Uid);
		$Remark = diconv($Remark,CHARSET,'UTF-8');
		$Url = 'http://'.$this->Config['PluginVar']['MagDomain'].'/core/pay/pay/accountTransfer?secret='.$this->Config['PluginVar']['MagSecret'].'&user_id='.$Uid.'&amount='.$Amount.'&remark='.$Remark.'&out_trade_code='.$OutTradeCode;
		$Data = dfsockopen($Url);
		if(!$Data) {
			$Data = file_get_contents($Url);
		}
		$Data = json_decode($Data,true);
		if($Data['success'] && $Data['code'] == 101){
			return true;
		}
	}
	public function GetMagUserInfo(){
		$UserAgent = $_SERVER['HTTP_USER_AGENT'];
		$Info = explode("|",$UserAgent);
		$Url = 'http://'.$this->Config['PluginVar']['MagDomain'].'/mag/cloud/cloud/getUserInfo?token='.$Info[7].'&secret='.$this->Config['PluginVar']['MagSecret'];
		$Data = dfsockopen($Url);
		if(!$Data) {
			$Data = file_get_contents($Url);
		}
		$Data = json_decode($Data,true);
		if($Data['data']){
			return $Data['data'];
		}
	}
	/* 马甲支付 End */
	/* 千帆支付 */
	public function QFPay($QFId,$Id){
		global $_G;
		$QFId = addslashes(strip_tags($QFId));
		$Uid = intval($_G['uid']);
		$Data = array(
			'order_id' => $QFId,
			'nonce' => $this->QFNonce()
		);
		$Data['sign'] = $this->QFSign($Data,$this->Config['PluginVar']['qf_secret']);
		$R = http_build_query($Data);
		$Url = 'http://'.$this->Config['PluginVar']['qf_hostname']. '.qianfanapi.com/api1_2/orders/query?'.$R;
		$QFData = dfsockopen($Url);
		if(!$QFData) {
			$QFData = file_get_contents($Url);
		}
		$Info = DB::fetch_first('SELECT * FROM '.DB::table($this->TableQHB).' where id = '.$Id.' and uid = '.$Uid);
		$QFData = json_decode($QFData,true);
		if(($QFData['data'][$QFId]['result'] == 1 || $QFData['data'][$QFId]['result'] == 2) && $Info){
			if($Info && $Info['state'] != 1 && $Info['pay_state'] != 1){
				$Data = array('pay_state'=>1);
				if(DB::update($this->TableQHB,$Data,'id='.$Id)){
					$State = 1;
				}else{
					$State = 0;
				}
			}else{
				$State = 0;
			}
			return $State;
		}
	}
	private function QFAddBalance($Uid,$Money){//金额写入
		$Uid = intval($Uid);
		$Data = array(
			'uid' => $Uid,
			'amount'=> $Money * 100,
			'type'=> $this->Config['PluginVar']['qf_sr_type'],
			'nonce' => $this->QFNonce()
		);
		$Data['sign'] = $this->QFSign($Data,$this->Config['PluginVar']['qf_secret']);
		$Url = 'http://'.$this->Config['PluginVar']['qf_hostname']. '.qianfanapi.com/api1_2/balance/add';
		$QFData = $this->PostCurlInit($Url,$Data);
		if(!$QFData) {
			$QFData = dfsockopen($Url,0,$Data);
		}
		$Return = json_decode($QFData,true);
		if($Return['data']){
			return true;
		}
	}
	public function GetActionAuthCode($wap_token = '', $secret_key = '',$operation = 'DECODE') {
		$wap_token = str_replace(' ','+',urldecode($wap_token));

		$ckey_length = 4;

		$secret_key = md5($secret_key);
		$keya = md5(substr($secret_key, 0, 16));
		$keyb = md5(substr($secret_key, 16, 16));
		$keyc = $ckey_length ? ($operation == 'DECODE' ? substr($wap_token, 0, $ckey_length): substr(md5(microtime()), -$ckey_length)) : '';

		$cryptkey = $keya.md5($keya.$keyc);
		$key_length = strlen($cryptkey);

		$wap_token = $operation == 'DECODE' ? base64_decode(substr($wap_token, $ckey_length)) : sprintf('%010d', $expiry ? $expiry + time() : 0).substr(md5($wap_token.$keyb), 0, 16).$wap_token;
		$string_length = strlen($wap_token);

		$result = '';
		$box = range(0, 255);

		$rndkey = array();
		for($i = 0; $i <= 255; $i++) {
			$rndkey[$i] = ord($cryptkey[$i % $key_length]);
		}

		for($j = $i = 0; $i < 256; $i++) {
			$j = ($j + $box[$i] + $rndkey[$i]) % 256;
			$tmp = $box[$i];
			$box[$i] = $box[$j];
			$box[$j] = $tmp;
		}

		for($a = $j = $i = 0; $i < $string_length; $i++) {
			$a = ($a + 1) % 256;
			$j = ($j + $box[$a]) % 256;
			$tmp = $box[$a];
			$box[$a] = $box[$j];
			$box[$j] = $tmp;
			$result .= chr(ord($wap_token[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
		}

		if($operation == 'DECODE') {
			if((substr($result, 0, 10) == 0 || substr($result, 0, 10) - time() > 0) && substr($result, 10, 16) == substr(md5(substr($result, 26).$keyb), 0, 16)) {
				return substr($result, 26);
			} else {
				return '';
			}
		} else {
			return $keyc.str_replace('=', '', base64_encode($result));
		}
	}
	private function QFNonce($length = 32){
		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";
		$str   = "";
		for ($i = 0; $i < $length; $i++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}
	private function QFSign($params, $secret){
		ksort($params);
		$sparams = array();
		foreach ($params as $k => $v) {
			if ("@" != substr($v, 0, 1)) {
				$sparams[] = "$k=$v";
			}
		}
		$sparams[] = "secret=" . $secret;
		return strtoupper(md5(implode("&", $sparams)));
	}
	//模拟访问Post
	public function PostCurlInit($Url, $Data) {
		global $_G;
		if (!function_exists('curl_init')) {
			return '';
		}
		$Ip = rand(1,255).".".rand(1,255).".".rand(1,255).".".rand(1,255)."";
		$Header = array();
		$Header[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8';
		$Header[] = 'Accept-Encoding: gzip, deflate, sdch';
		$Header[] = 'Accept-Language: zh-CN,zh;q=0.8';
		$Header[] = 'Cache-Control: max-age=0';
		$Header[] = 'Connection: keep-alive';
		$Header[] = 'Connection: keep-alive';
		$Header[] = 'X-FORWARDED-FOR:'.$Ip;
		$Header[] = 'CLIENT-IP:'.$Ip;
		$Ch = curl_init();
		curl_setopt($Ch, CURLOPT_URL, $Url);
		curl_setopt($Ch, CURLOPT_HTTPHEADER, $Header);
		curl_setopt($Ch, CURLOPT_REFERER, $_G['siteurl']); //构造来路
		curl_setopt($Ch, CURLOPT_ENCODING, 'gzip');
		curl_setopt($Ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36');// 保存到字符串而不是输出
		# curl_setopt( $Ch, CURLOPT_HEADER, 1);
		curl_setopt($Ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($Ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($Ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($Ch, CURLOPT_POST, 1);
		curl_setopt($Ch, CURLOPT_POSTFIELDS, $Data);
		$Data = curl_exec($Ch);
		if (!$Data) {
			error_log(curl_error($Ch));
		}
		curl_close($Ch);
		return $Data;
	}
	/* 千帆支付 End */
	//创建支付
	public function GetAjaxPay($OrderId,$Title,$Event,$Money,$PayType,$NotifyUrl=null){
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){
			@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
			$NotifyUrl = empty($NotifyUrl) ? $_G['siteurl'].'plugin.php?id=fn_qhb&m=payok&orderid=' : $NotifyUrl;
			$PayId = $FnPay->GetInsertPay($OrderId,$this->StrToGBK($Title),'fn_qhb',$Event,$Money,$PayType,$NotifyUrl);
			$Data = array();
			$Data['PayUrl'] = $_G['siteurl'].'plugin.php?id=fn_pay&payid='.$PayId;
			$Data['State'] = 200;
			return $Data;
		}
	} 
	/* 删除修改记录 */
	public function AjaxDel($Id){
		global $_G;
		$Id = intval($Id);
		$Uid = intval($_G['uid']);
		if(DB::delete($this->TableQHB,'id = '.$Id.' and uid = '.$Uid)){
			$Data['State'] = 200;
			return $Data;
		}
	}
	/*  图片上传 */
	public function UploadIconBanner($Files,$DelUsedFiles=null,$ImageCrop=false,$Type=1,$Width,$Height){
		require_once 'ImageCrop.Class.php';
		require_once (DISCUZ_ROOT.'./source/class/discuz/discuz_upload.php');
		$Upload = new discuz_upload();
		if($Upload->init($Files, 'common') && $Upload->save(0)) {
			$Path = $_G['setting']['attachdir'].'common/'.$Upload->attach['attachment'];
			$Name = explode('/',$Upload->attach['attachment']);
			$MPicUrl = DISCUZ_ROOT.$this->Config['StaticPicPath'].$Name[1];
			if(copy($Upload->attach['target'],$MPicUrl)){
				if($ImageCrop && $Width && $Height){
					$Ic=new ImageCrop($MPicUrl,$MPicUrl);
					$Ic->Crop($Width,$Height,$Type); 
					$Ic->SaveImage();
					$Ic->destory();
				}
				$Path = $this->Config['StaticPicPath'].$Name[1];
				unlink($Upload->attach['target']);
				unlink(DISCUZ_ROOT.$DelUsedFiles);
			}
			$File['Path'] = $Path;
			return $File;
		}else{
			$File['Errorcode'] = $Upload->errorcode;
			return $File;
		}
	}

	/* 焦点图列表 */
	public function GetModulesBanner($Type=null){
		if(!empty($Type)){
			$Where = ' where type = '.$Type;
		}
		$FetchSql = 'SELECT * FROM '.DB::table($this->TableBanner).$Where.' order by displayorder ASC';
		return DB::fetch_all($FetchSql);//返回数据
	}

	/* 查询单个 */
	public function QueryOne($TableName,$Id,$Where=null){
		$FirstSql = 'SELECT * FROM '.DB::table($TableName).' where id = '.$Id.' '.$Where;
		return DB::fetch_first($FirstSql);	
	}
	/* 
	修改表的数据
	table_name=>
	ids=>id
	fields=>字段
    val=>值
	*/
	public function EditFields($TableName,$Ids,$Fields,$Val){
		if(is_array($Ids)){
			$Ids = implode(',',$Ids);
		}else{
			$Ids = $Ids;
		}
		$UpData[$Fields] = $Val;
		if(DB::update($TableName,$UpData,'id in( '.$Ids.' )')){
			return true;
		}else{
			return false;
		}
	}
	/* 
	删除数据
	table_name=>表名
	ids=>id
	*/
	public function Del($TableName,$Ids,$Where=null){
		if(is_array($Ids)){
			$Ids = implode(',',$Ids);
		}else{
			$Ids = $Ids;
		}
		if(DB::delete($TableName,'id in( '.$Ids.' )'.$Where)){
			return true;
		}else{
			return false;
		}
	}
	public function GetArray($Array,$IdField,$PField){
		$ReturnArray = array();
		foreach($Array as $Item){  
			//判断是否有数组的索引==  
			if(isset($Array[$Item[$PField]])){     //查找数组里面是否有该分类  如 isset($Array[0])  isset($Array[1])  
				$Array[$Item[$PField]]['son'][] = &$Array[$Item[$IdField]]; //上面的内容变化,$ReturnArray里面的值就变化  
			}else{  
				$ReturnArray[] = &$Array[$Item[$IdField]];   //把他的地址给了$ReturnArray  
			}    
		}
		return $ReturnArray;
	}
	/* 编码转换 */
	public static function StrToGBK($string,$ajax_status=null){
		global $_G;
		if($_G['charset'] == 'gbk'){
			if($ajax_status == true){
				if(is_array($string)){
					return eval('return '.iconv("GB2312","UTF-8//IGNORE",var_export($string,true).';')); 
				}else{
					return iconv('GB2312', 'UTF-8', $string);
				}
			}else{
				if(is_array($string)){
					$StringArr = array();
					foreach($string as $key=>$value){
						$encode = mb_detect_encoding($value, array('UTF-8','GB2312','GBK'));
						if($encode == 'UTF-8'){
							$StringArr[$key] = iconv('UTF-8','GB2312//IGNORE',$value);
						}else if($encode == 'EUC-CN'){
							$StringArr[$key] = $value;
						}
					}
					return $StringArr;
				}else{
					$encode = mb_detect_encoding($string, array('UTF-8','GB2312','GBK'));
					if($encode == 'UTF-8'){
						return iconv('UTF-8','GB2312//IGNORE', $string);
					}else if($encode == 'EUC-CN'){
						return $string;
					}
				}
			}
		}else{
			return $string;
		}
        
    }
	/* 微信分享_GetSignPackage */
	public function WeixinGetSignPackage(){
		require DISCUZ_ROOT.'/'.$this->Config['Path']."/weixin/jssdk.php";
		$jssdk = new JSSDK($this->Config['PluginVar']['WxAppid'], $this->Config['PluginVar']['WxSecret']);
		return $jssdk->getSignPackage();
	}

	/* 地区检测 */
	private function CheCkRestrictedAreas($CheCkAreas,$Lat=null,$Lng=null){
		global $_G;
		$CheCkAreasArr = array_filter(explode(",",$CheCkAreas));
		if($Lat && $Lng && (strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'QianFan') !== false || strpos($_SERVER["HTTP_USER_AGENT"],'MicroMessenger') !== false)){//经纬度限
			if($_G['cookie']['FnAddress']){
				foreach($CheCkAreasArr as $Key=>$Val){
					if(strpos($_G['cookie']['FnAddress'],$Val) !== false){
						return false;
					}
				}
				return true;
			}else{
				$Location = json_decode(dfsockopen('https://apis.map.qq.com/ws/geocoder/v1/?location='.$Lat.','.$Lng.'&key='.$this->Config['PluginVar']['MapKey'].'&get_poi=1'),true);
				$Location['result']['address'] = diconv($Location['result']['address'],'UTF-8',CHARSET);
				if($Location['status'] === 0 && $Location['result']['address']){
					dsetcookie('FnAddress',$Location['result']['address'],3600);
					foreach($CheCkAreasArr as $Key=>$Val){
						if(strpos($Location['result']['address'],$Val) !== false){
							return false;
						}
					}
					return true;
				}
			}
		}else{//ip限制
			if($_G['cookie']['FnAddress']){
				foreach($CheCkAreasArr as $Key=>$Val){
					if(strpos($_G['cookie']['FnAddress'],$Val) !== false){
						return false;
					}
				}
				return true;
			}else{
				$Location = json_decode(dfsockopen("https://apis.map.qq.com/ws/location/v1/ip?ip=".$_G['clientip'].'&key='.$this->Config['PluginVar']['MapKey']),true);
				$Address = diconv($Location['result']['ad_info']['province'],'UTF-8',CHARSET).diconv($Location['result']['ad_info']['city'],'UTF-8',CHARSET);
				dsetcookie('FnAddress',$Address,60);
				foreach($CheCkAreasArr as $Key=>$Val){
					if(strpos($Address,$Val) !== false){
						return false;
					}
				}
				return true;
			}
		}
	}

	public function NoRand($Begin=0,$End=20,$Limit=5){
		$RandArray=range($Begin,$End);
		shuffle($RandArray);//调用现成的数组随机排列函数
		return array_slice($RandArray,0,$Limit);//截取前$limit个
	} 

	/* 一维数组转二维数组 */
	public function DyadicArray($Array){
		$DyadicArray = array();
		foreach($Array as $K => $V) {
			$DyadicArray[] = array($K,$V);
		}
		return $DyadicArray;
	}
}
//From: Dism_taobao_com
?>