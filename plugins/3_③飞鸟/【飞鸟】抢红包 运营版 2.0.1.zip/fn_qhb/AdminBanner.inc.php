<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Common.php');
if(!submitcheck('BannerSubmit')){
	$formUrl = ltrim(rawurldecode(cpurl()),'action=');
	showtagheader('div', 'banner_module', true);
	showformheader($formUrl,'enctype="multipart/form-data"');
	showtableheader($Fn_QHB->Config['LangVar']['BannerDisplayTitle']);
	showsubtitle(array(
		'', 'display_order',
		$Fn_QHB->Config['LangVar']['BannerTitle'],
		$Fn_QHB->Config['LangVar']['BannerLink'],
		$Fn_QHB->Config['LangVar']['BannerImg']
	));
	$ModulesBannerList = $Fn_QHB->GetModulesBanner();
	foreach ($ModulesBannerList as $module) {
		showtablerow('', array('class="td25"', 'class="td28"'), array(
			'<input type="checkbox" class="checkbox" name="delete[]" value="'.$module['id'].'" />',
			'<input type="text" class="txt" size="2" name="displayorder['.$module['id'].']" value="'.$module['displayorder'].'" />',
			'<input type="text" size="30" name="title['.$module['id'].']" value="'.$module['title'].'" />',
			'<input type="text" size="30" name="link['.$module['id'].']" value="'.$module['link'].'" />',
			'<a href="'.$module['img'].'" target="_blank"><img src="'.$module['img'].'" style="width:60px;float:left;display:inline;margin:0 5px 0 0;"></a><input type="hidden" size="30" name="img['.$module['id'].']" value="'.$module['img'].'" /> <input name="file_img['.$module['id'].']" value="" class="txt uploadbtn" type="file" style="width:200px;">'
		));
	}
	showtablerow('', array('class="td25"', 'class="td28"'), array(
		cplang('add_new'),
		sprintf('<input type="text" class="txt" size="2" maxlength="4" name="new_displayorder" value="" />'),
		sprintf('<input type="text" size="30" name="new_title" value="" />'),
		sprintf('<input type="text" size="30" name="new_link" value="" />'),
		sprintf('<input name="new_img" value="" class="txt uploadbtn" type="file" style="width:265px;">'),
	));
	showsubmit('BannerSubmit', 'submit', 'del');
    /*Dism_taobao_com*/showtablefooter();
	showformfooter();/*Dism��taobao��com*/
	showtagfooter('div');
}else{
	// ɾ��ѡ�н���ͼ
    if (isset($_POST['delete']) && is_array($_POST['delete'])) {
		foreach($_POST['delete'] as $Id){
			$Id = intval($Id);
			$QiangLou = $Fn_QHB->QueryOne($Fn_QHB->TableBanner,$Id);
			if($QiangLou){
				unlink(DISCUZ_ROOT.$QiangLou['img']);//ɾ��ͼƬ
				DB::delete($Fn_QHB->TableBanner,'id ='.$Id);
			}
		}
	}
	// ���½���ͼ
    if(!empty($_POST['displayorder'])) {
		foreach ($_POST['displayorder'] as $Id => $displayorder) {
			$UpIns = array();
			$Id = intval($Id);
			$UpIns['link'] =  addslashes($_POST['link'][$Id]);
			$UpIns['displayorder'] =  intval($displayorder);
			$UpIns['title'] =  addslashes($_POST['title'][$Id]);
			$UpIns['type'] =  intval($_POST['type'][$Id]);
			if(!empty($_FILES['file_img']['size'][$Id])) {
				$Banner = array(
					'name' => $_FILES['file_img']['name'][$Id],
					'type' => $_FILES['file_img']['type'][$Id],
					'tmp_name' => $_FILES['file_img']['tmp_name'][$Id],
					'error' => $_FILES['file_img']['error'][$Id],
					'size' => $_FILES['file_img']['size'][$Id]
				);
				$BannerInfo = $Fn_QHB->QueryOne($Fn_QHB->TableBanner,$Id);
				$UpImg = $Fn_QHB->UploadIconBanner($Banner,$BannerInfo['img']);
				if($UpImg['Errorcode']){
					cpmsg($Fn_QHB->Config['LangVar']['ImgErr'],'','error');
				}else{
					$UpIns['img'] = addslashes($UpImg['Path']);
				}
			}else{
				$UpIns['img'] =  addslashes($_POST['img'][$Id]);
			}
			DB::update($Fn_QHB->TableBanner,$UpIns,'id = '.$Id);
		}
    }
	//�����½���ͼ
    if (!empty($_FILES['new_img']['size'])) {
		$Ins = array();
		$Ins['link'] = addslashes($_POST['new_link']);
		$Ins['displayorder'] = intval($_POST['new_displayorder']);
		$Ins['type'] = intval($_POST['new_type']);
		$Ins['title'] = addslashes($_POST['new_title']);
		$ImgFile = $Fn_QHB->UploadIconBanner($_FILES['new_img']);
		if($ImgFile['Errorcode']){
			cpmsg($Fn_QHB->Config['LangVar']['ImgErr'],'','error');
		}else{
			$Ins['img'] = addslashes($ImgFile['Path']);
		}
		DB::insert($Fn_QHB->TableBanner,$Ins);
    }
	cpmsg($Fn_QHB->Config['LangVar']['UpdateOk'],rawurldecode(cpurl()),'succeed');
}
//From: Dism_taobao_com
?>