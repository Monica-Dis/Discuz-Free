<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Common.php');
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&tid='.$_GET['tid'];
$TId = intval($_GET['tid']);
$Info = $TId ? $Fn_QHB->QueryOne($Fn_QHB->TableQHB,$TId) : array();
if($Info['param']){$Info['param'] = unserialize($Info['param']);}
$Title = $Fn_QHB->Config['LangVar']['AddTitle'];
if(!submitcheck('DetailSubmit')) {
	if($Info) {
		$Title = $Fn_QHB->Config['LangVar']['EditTitle'];
		$Info['imgs'] = explode(',',$Info['imgs']);
	}
	if(CHARSET == 'gbk'){
		echo '<script src="'.$Fn_QHB->Config['StaticPath'].'/kindeditor/kindeditor-min.js" type="text/javascript"></script><script src="'.$Fn_QHB->Config['StaticPath'].'/kindeditor/lang/zh_cn_gbk.js" type="text/javascript"></script><script type="text/javascript" src="static/js/calendar.js"></script>';
	}else{
		echo '<script src="'.$Fn_QHB->Config['StaticPath'].'/kindeditor/kindeditor-min.js" type="text/javascript"></script><script src="'.$Fn_QHB->Config['StaticPath'].'/kindeditor/lang/zh_cn_utf.js" type="text/javascript"></script><script type="text/javascript" src="static/js/calendar.js"></script>';
	}
	
	$formUrl = ltrim(rawurldecode(cpurl()),'action=');
	showformheader($formUrl,'enctype');
	showtableheader();
	showtitle($Title);
	
	showsetting($Fn_QHB->Config['LangVar']['Title'], 'title', $Info['title'], 'text');
	showsetting($Fn_QHB->Config['LangVar']['FTitle'], 'ftitle', $Info['ftitle'], 'text');
	showsetting($Fn_QHB->Config['LangVar']['PassTitle'], 'pass', $Info['param']['pass'], 'text');
	showsetting($Fn_QHB->Config['LangVar']['MoneyTitle'], 'money', $Info['money'], 'text');
	
	if($Info['thumbnail']) {
		$ThumbnailHtml = '<label><input type="checkbox" class="checkbox" name="delthumbnail" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Info['thumbnail'].'" target="_blank"><img src="'.$Info['thumbnail'].'" width="100"/></a><input type="hidden" value="'.$Info['thumbnail'].'" name="thumbnail"><br />'.$Fn_QHB->Config['LangVar']['ThumbnailPrompt'];
	}else{
		$ThumbnailHtml = $Fn_QHB->Config['LangVar']['ThumbnailPrompt'];
	}
	showsetting($Fn_QHB->Config['LangVar']['ThumbnailTitle'], 'thumbnailnew','', 'filetext', '', 0, $ThumbnailHtml);

	showsetting($Fn_QHB->Config['LangVar']['WinningFloorTtile'], 'winning_floor', $Info['param']['winning_floor'], 'textarea','','',$Fn_QHB->Config['LangVar']['WinningFloorPrompt']);
	showsetting($Fn_QHB->Config['LangVar']['StartTimeTitle'], 'start_time',$Info['start_time'] ? date('Y-m-d H:i',$Info['start_time']):'', 'calendar','','','',1);
	showsetting($Fn_QHB->Config['LangVar']['EndTimeTitle'], 'end_time',$Info['end_time']?date('Y-m-d H:i',$Info['end_time']):'', 'calendar','','','',1);
	showsetting($Fn_QHB->Config['LangVar']['RepeatTimeTitle'], 'repeat_time', $Info['param']['repeat_time'], 'text','','',$Fn_QHB->Config['LangVar']['RepeatTimePrompt']);

	showsetting($Fn_QHB->Config['LangVar']['WinningTitle'], 'winning_prompt', $Info['param']['winning_prompt'], 'textarea','','',$Fn_QHB->Config['LangVar']['WinningPrompt']);
	
	showsetting($Fn_QHB->Config['LangVar']['AppTitle'], 'app', $Info['param']['app'], 'radio');

	showsetting($Fn_QHB->Config['LangVar']['IsAppPromptSwitch'], 'apppromptswitch', $Info['param']['apppromptswitch'], 'radio','','',$Fn_QHB->Config['LangVar']['IsAppPromptSwitchPrompt']);

	showsetting($Fn_QHB->Config['LangVar']['NoAppPromptSwitch'], 'noapppromptswitch', $Info['param']['noapppromptswitch'], 'radio','','',$Fn_QHB->Config['LangVar']['NoAppPromptSwitchPrompt']);

	showsetting($Fn_QHB->Config['LangVar']['WinningFloorHiddenTitle'], 'winningfloorhidden', $Info['param']['winningfloorhidden'], 'radio','','',$Fn_QHB->Config['LangVar']['WinningFloorHiddenPrompt']);

	showsetting($Fn_QHB->Config['LangVar']['HiddenFloor'], 'hiddenfloor', $Info['param']['hiddenfloor'], 'radio');
	showsetting($Fn_QHB->Config['LangVar']['EmptyInputTitle'], 'emptyinput', $Info['param']['emptyinput'], 'radio','','',$Fn_QHB->Config['LangVar']['EmptyInputPrompt']);
	showsetting($Fn_QHB->Config['LangVar']['StartCommentSwitch'], 'startcommentswitch', $Info['param']['startcommentswitch'], 'radio');
	showsetting($Fn_QHB->Config['LangVar']['EndCommentSwitch'], 'endcommentswitch', $Info['param']['endcommentswitch'], 'radio');
	
	showsetting($Fn_QHB->Config['LangVar']['ShareLoopTitle'], 'shareloop', $Info['param']['shareloop'], 'radio','','',$Fn_QHB->Config['LangVar']['ShareLoopPrompt']);
	
	showsetting($Fn_QHB->Config['LangVar']['ShareMode'],array('sharemode',$Fn_QHB->DyadicArray($Fn_QHB->Config['LangVar']['ShareModeArr'])),$Info['param']['sharemode'],'select','','',$Fn_QHB->Config['LangVar']['ShareModePrompt']);

	showsetting($Fn_QHB->Config['LangVar']['ShareNum'], 'sharenum', $Info['param']['sharenum'], 'text');

	showsetting($Fn_QHB->Config['LangVar']['ShareNumLimit'], 'sharenumlimit', $Info['param']['sharenumlimit'], 'text','','',$Fn_QHB->Config['LangVar']['ShareNumLimitPrompt']);


	showsetting($Fn_QHB->Config['LangVar']['FrequencyTitle'], 'frequency', $Info['param']['frequency'], 'text','','',$Fn_QHB->Config['LangVar']['FrequencyPrompt']);

	showsetting($Fn_QHB->Config['LangVar']['LimitSwitch'], 'limitswitch', $Info['param']['limitswitch'], 'radio','','',$Fn_QHB->Config['LangVar']['LimitSwitchPrompt']);

	showsetting($Fn_QHB->Config['LangVar']['ProhibitAddress'], 'prohibit_address', $Info['param']['prohibit_address'], 'text','','',$Fn_QHB->Config['LangVar']['ProhibitAddressPrompt']);

	showsetting($Fn_QHB->Config['LangVar']['MusicTitle'], 'music', $Info['param']['music'], 'text','','',$Fn_QHB->Config['LangVar']['MusicPrompt']);
	

	showsetting($Fn_QHB->Config['LangVar']['WinningResultSort'],array('winningresultsort',$Fn_QHB->DyadicArray($Fn_QHB->Config['LangVar']['WinningResultArr'])),$Info['param']['winningresultsort'],'select');
	
	showsetting($Fn_QHB->Config['LangVar']['UserInfoSwitch'], 'userinfoswitch', $Info['param']['userinfoswitch'], 'radio','','',$Fn_QHB->Config['LangVar']['UserInfoSwitchPrompt']);

	showsetting($Fn_QHB->Config['LangVar']['UserInfoLink'], 'userinfolink', $Info['param']['userinfolink'], 'text');


	//�����
	echo '<tr><td colspan="2" class="td27" s="1">'.$Fn_QHB->Config['LangVar']['ContentTitle'].'</td></tr><tr class="noborder"><td class="vtop rowform" colspan="2"><textarea id="content" name="content" style="width:80%;height:500px;visibility:hidden;">'.stripslashes($Info['param']['content']).'</textarea></td></tr>';

	//��ϸ����
	echo '<tr><td colspan="2" class="td27" s="1">'.$Fn_QHB->Config['LangVar']['DetailedRules'].'</td></tr><tr class="noborder"><td class="vtop rowform" colspan="2"><textarea id="rulecontent" name="rulecontent" style="width:80%;height:500px;visibility:hidden;">'.stripslashes($Info['param']['rulecontent']).'</textarea></td></tr>';

	showsetting($Fn_QHB->Config['LangVar']['BrandTitle'], 'brand', $Info['param']['brand'], 'text');
	showsetting($Fn_QHB->Config['LangVar']['TelTitle'], 'tel', $Info['param']['tel'], 'text');
	showsetting($Fn_QHB->Config['LangVar']['MessageTitle'], 'message', $Info['param']['message'], 'textarea');
	if($Info['param']['ad_img']) {
		$AdImgHtml = '<label><input type="checkbox" class="checkbox" name="deladimg" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Info['param']['ad_img'].'" target="_blank"><img src="'.$Info['param']['ad_img'].'" width="100"/></a><input type="hidden" value="'.$Info['param']['ad_img'].'" name="ad_img"><br />'.$Fn_QHB->Config['LangVar']['AdPrompt'];
	}else{
		$AdImgHtml  = $Fn_QHB->Config['LangVar']['AdPrompt'];
	}

	showsetting($Fn_QHB->Config['LangVar']['AdTitle'], 'adimgnew','', 'filetext', '', 0, $AdImgHtml);
	showsetting($Fn_QHB->Config['LangVar']['AdLink'], 'ad_link', $Info['param']['ad_link'], 'text');

	showsetting($Fn_QHB->Config['LangVar']['MoreAdTitle'], 'ads', $Info['param']['ads'], 'textarea','','',$Fn_QHB->Config['LangVar']['MoreAdPrompt']);
	
	showsetting($Fn_QHB->Config['LangVar']['WxTitle'], 'wx_title', $Info['param']['wx_title'], 'text');
	if($Info['param']['wx_img']) {
		$WxImgHtml = '<label><input type="checkbox" class="checkbox" name="delwximg" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Info['param']['wx_img'].'" target="_blank"><img src="'.$Info['param']['wx_img'].'" width="100"/></a><input type="hidden" value="'.$Info['param']['wx_img'].'" name="wx_img"><br />'.$Fn_QHB->Config['LangVar']['WxImgPrompt'];
	}else{
		$WxImgHtml = $Fn_QHB->Config['LangVar']['WxImgPrompt'];
	}
	showsetting($Fn_QHB->Config['LangVar']['WxImgTitle'], 'wximgnew','', 'filetext', '', 0, $WxImgHtml);
	showsetting($Fn_QHB->Config['LangVar']['WxDesTitle'], 'wx_des', $Info['param']['wx_des'], 'textarea');
	
	showsetting($Fn_QHB->Config['LangVar']['ShareSuccessTitle'], 'sharesuccesstitle', $Info['param']['sharesuccesstitle'] ? $Info['param']['sharesuccesstitle'] : $Fn_QHB->Config['LangVar']['ShareSuccessDefault'], 'text','','',$Fn_QHB->Config['LangVar']['ShareSuccessPrompt']);

	showsetting($Fn_QHB->Config['LangVar']['ShareSuccessDesc'], 'sharesuccessdesc', $Info['param']['sharesuccessdesc'] ? $Info['param']['sharesuccessdesc'] : $Fn_QHB->Config['LangVar']['ShareSuccessDefault'], 'textarea','','',$Fn_QHB->Config['LangVar']['ShareSuccessPrompt']);

	showsetting('Uid', 'uid',$Info['uid'] ? $Info['uid'] : $_G['uid'], 'text');
	showsetting($Fn_QHB->Config['LangVar']['ClickTitle'], 'click', $Info['click'], 'text');
	showsetting('display_order', 'displayorder', $Info['displayorder'], 'text');
	showsetting($Fn_QHB->Config['LangVar']['PayTitle'], 'pay_state', $Info['pay_state'], 'radio');
	showsetting($Fn_QHB->Config['LangVar']['DisplayTitle'], 'display', $Info['display'], 'radio');
	if($Info['dateline']){
	showsetting($Fn_QHB->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Info['dateline']), 'calendar','','','',1);
	}
	

	/*Dism_taobao_com*/showtablefooter();
	showsubmit('DetailSubmit');
	showformfooter();/*Dism��taobao��com*/

	echo '
		<script type="text/javascript">  
		var options = {  
		filterMode : true,  
		allowImageUpload : true,  
		allowFlashUpload : false,  
		allowMediaUpload : false,  
		allowFileManager : false,  
		items : ["source", "|", "fullscreen", "undo", "redo", "print", "cut", "copy", "paste",
            "plainpaste", "wordpaste", "|", "justifyleft", "justifycenter", "justifyright",
            "justifyfull", "insertorderedlist", "insertunorderedlist", "indent", "outdent", "subscript",
            "superscript", "|", "selectall", "clearhtml","quickformat","|",
            "formatblock", "fontname", "fontsize", "|", "forecolor", "hilitecolor", "bold",
            "italic", "underline", "strikethrough", "lineheight", "removeformat", "|", "image", "table", "hr", "emoticons", "link", "unlink", "|", "about"]
		};  
		var editor = new Array();  
		KindEditor.ready(function(K) {  
		editor[0] = K.create("#content",options);
		editor[1] = K.create("#rulecontent",options);
		});  
		</script>
	';
}else{

	$Data['title'] = addslashes(strip_tags($_GET['title']));
	$Data['ftitle'] = addslashes(strip_tags($_GET['ftitle']));
	
	$Data['money'] = addslashes(strip_tags($_GET['money']));
	$Data['start_time'] = $_GET['start_time'] ? strtotime($_GET['start_time']) : '';
	$Data['end_time'] = $_GET['end_time'] ? strtotime($_GET['end_time']) : '';
	$Data['displayorder'] = intval($_GET['displayorder']);
	$Data['display'] = intval($_GET['display']);
	$Data['click'] = intval($_GET['click']);
	$Data['pay_state'] = intval($_GET['pay_state']);
	$Data['uid'] = intval($_GET['uid']);

	$Param['content'] = addslashes($_GET['content']);
	$Param['rulecontent'] = addslashes($_GET['rulecontent']);
	$Param['pass'] = addslashes(strip_tags($_GET['pass']));
	$Param['winning_floor'] = addslashes(strip_tags($_GET['winning_floor']));
	$Param['repeat_time'] = intval($_GET['repeat_time']);
	$Param['winning_prompt'] = addslashes(strip_tags($_GET['winning_prompt']));
	$Param['winningfloorhidden'] = addslashes(strip_tags($_GET['winningfloorhidden']));
	$Param['hiddenfloor'] = intval($_GET['hiddenfloor']);
	$Param['emptyinput'] = intval($_GET['emptyinput']);
	$Param['startcommentswitch'] = intval($_GET['startcommentswitch']);
	$Param['endcommentswitch'] = intval($_GET['endcommentswitch']);
	$Param['shareloop'] = intval($_GET['shareloop']);
	$Param['sharemode'] = intval($_GET['sharemode']);
	$Param['sharenumlimit'] = intval($_GET['sharenumlimit']);
	$Param['sharenum'] = intval($_GET['sharenum']);
	$Param['frequency'] = intval($_GET['frequency']);
	$Param['limitswitch'] = intval($_GET['limitswitch']);
	$Param['userinfoswitch'] = intval($_GET['userinfoswitch']);
	$Param['userinfolink'] = addslashes(strip_tags($_GET['userinfolink']));
	$Param['winningresultsort'] = intval($_GET['winningresultsort']);
	$Param['prohibit_address'] = addslashes(strip_tags($_GET['prohibit_address']));
	$Param['music'] = addslashes(strip_tags($_GET['music']));
	$Param['brand'] = addslashes(strip_tags($_GET['brand']));
	$Param['tel'] = addslashes(strip_tags($_GET['tel']));
	$Param['message'] = addslashes(strip_tags($_GET['message']));
	$Param['ad_link'] = addslashes(strip_tags($_GET['ad_link']));
	$Param['ads'] = addslashes(strip_tags($_GET['ads']));
	$Param['app'] = intval($_GET['app']);
	$Param['apppromptswitch'] = intval($_GET['apppromptswitch']);
	$Param['noapppromptswitch'] = intval($_GET['noapppromptswitch']);
	$Param['wx_title'] = addslashes(strip_tags($_GET['wx_title']));
	$Param['wx_des'] = addslashes(strip_tags($_GET['wx_des']));
	$Param['sharesuccesstitle'] = addslashes(strip_tags($_GET['sharesuccesstitle']));
	$Param['sharesuccessdesc'] = addslashes(strip_tags($_GET['sharesuccessdesc']));
	/* ����ͼ */
	if($_GET['delthumbnail'] == 'yes'){
		unlink(DISCUZ_ROOT.$Info['thumbnail']);
		$Data['thumbnail'] = '';
	}
	if($_FILES['thumbnailnew']['size']){
		$ThumbnailFile = $Fn_QHB->UploadIconBanner($_FILES['thumbnailnew'],$Info['thumbnail']);
		if($ThumbnailFile['Errorcode']){
			cpmsg($Fn_QHB->Config['LangVar']['ImgErr'],'','error');
		}else{
			$Data['thumbnail']  = $ThumbnailFile['Path'];
		}

	}else if($_GET['thumbnailnew']){
		$Data['thumbnail'] = addslashes(strip_tags($_GET['thumbnailnew']));
	}
	/* ����ͼ End */
	
	/* ���ͼ */
	if($_GET['deladimg'] == 'yes'){
		unlink(DISCUZ_ROOT.$Info['ad_img']);
		$Param['ad_img'] = '';
	}else{
		$Param['ad_img'] = addslashes(strip_tags($_GET['ad_img']));
	}
	if($_FILES['adimgnew']['size']){
		$AdFile = $Fn_QHB->UploadIconBanner($_FILES['adimgnew'],$Info['ad_img']);
		if($AdFile['Errorcode']){
			cpmsg($Fn_QHB->Config['LangVar']['ImgErr'],'','error');
		}else{
			$Param['ad_img'] = $AdFile['Path'];
		}
	}else if($_GET['adimgnew']){
		$Param['ad_img'] = addslashes(strip_tags($_GET['adimgnew']));
	}
	/* ���ͼ End */

	/* ΢�ŷ���ͼ */
	if($_GET['delwximg'] == 'yes'){
		unlink(DISCUZ_ROOT.$Info['param']['wx_img']);
		$Param['wx_img'] = '';
	}else{
		$Param['wx_img'] = addslashes(strip_tags($_GET['wx_img']));
	}
	if($_FILES['wximgnew']['size']){
		$WxFile = $Fn_QHB->UploadIconBanner($_FILES['wximgnew'],$Info['param']['wx_img']);
		if($WxFile['Errorcode']){
			cpmsg($Fn_QHB->Config['LangVar']['ImgErr'],'','error');
		}else{
			$Param['wx_img']  = $WxFile['Path'];
		}
	}else if($_GET['wximgnew']){
		$Param['wx_img'] = addslashes(strip_tags($_GET['wximgnew']));
	}
	/* ΢�ŷ���ͼ End */
	
	$Data['param'] = serialize($Param);
	
	$Member = DB::fetch_first('SELECT username FROM '.DB::table('common_member').' where uid = '.$Data['uid']);
	if($Member){
		$Data['username'] = addslashes(strip_tags($Member['username']));
		if($Info){
			$Data['dateline'] = strtotime($_GET['dateline']);
			DB::update($Fn_QHB->TableQHB,$Data,'id = '.$TId);
		}else{
			$Data['dateline'] = time();
			$Data['pay_state'] = 1;
			DB::insert($Fn_QHB->TableQHB,$Data);
		}
		cpmsg($Fn_QHB->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');

	}else{
		cpmsg($Fn_QHB->Config['LangVar']['NoUserErr'],'','error');
	}

}
//From: Dism_taobao_com
?>