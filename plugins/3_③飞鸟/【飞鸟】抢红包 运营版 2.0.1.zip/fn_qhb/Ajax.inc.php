<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Common.php');
if($_GET[f] == 'GetAjaxMessage' && $_GET['tid'] && $_G['uid'] && $_GET['formhash'] == formhash()){//��¥
	echo json_encode($Fn_QHB->StrToGBK($Fn_QHB->GetAjaxMessage($_GET['tid'],$_GET['content'],$_GET['lat'],$_GET['lng']),true));
}else if($_GET[f] == 'GetAjaxPostList' && $_GET['tid'] && $_GET['formhash'] == formhash()){//�����б�
	echo json_encode($Fn_QHB->StrToGBK($Fn_QHB->GetAjaxPostList($_GET['tid'],$_GET['page']),true));

}else if($_GET[f] == 'GetMoneyRanking' && $_GET['formhash'] == formhash()){//�������а�
	echo json_encode($Fn_QHB->StrToGBK($Fn_QHB->GetMoneyRanking(),true));

}else if($_GET[f] == 'GetPostMoneyRanking' && $_GET['formhash'] == formhash()){//��Ǯ���а�
	echo json_encode($Fn_QHB->StrToGBK($Fn_QHB->GetPostMoneyRanking($_GET['tid']),true));

}else if($_GET[f] == 'GetPostRanking' && $_GET['formhash'] == formhash()){//��¥���а�
	echo json_encode($Fn_QHB->StrToGBK($Fn_QHB->GetPostRanking($_GET['tid']),true));

}else if($_POST[f] == 'GetAjaxAddMemberInfo' && $_POST['formhash'] == formhash() && $_G['uid']){//���Ӹ���չʾҳ
	echo urldecode(json_encode($Fn_QHB->GetAjaxAddMemberInfo($_POST)));

}else if($_POST[f] == 'GetAjaxAdd' && $_POST['formhash'] == formhash() && $_G['uid']){//�����
	echo urldecode(json_encode($Fn_QHB->GetAjaxAdd($_POST,$_G['uid'])));

}else if($_GET[f] == 'GetAjaxPay' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET[orderid] && $_GET['title'] && $_GET['event'] && $_GET['money'] && $_GET['paytype']){//����֧��
	echo urldecode(json_encode($Fn_QHB->GetAjaxPay($_GET['orderid'],$_GET['title'],$_GET['event'],$_GET['money'],$_GET['paytype'])));

}else if($_GET[f] == 'AjaxDel' && $_GET['formhash'] == formhash() && $_GET['tid'] && $_G['uid']){//ɾ�������
	echo json_encode($Fn_QHB->AjaxDel($_GET['tid']));

}else if($_GET[f] == 'GetAjaxMagOrder' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['title'] && $_GET['money']){//�����µ�
	echo json_encode($Fn_QHB->GetAjaxMagOrder($_G['uid'],$_GET['money'],$_GET['title']));

}else if($_GET[f] == 'GetAjaxMagCheckOrder' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['UnionOrderNum'] && $_GET['tid']){//���׶�����ѯ
	echo json_encode($Fn_QHB->GetAjaxMagCheckOrder($_GET['UnionOrderNum'],$_GET['tid']));

}else if($_GET[f] == 'QFPay' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['qfid'] && $_GET['tid']){//ǧ��������ѯ
	echo urldecode(json_encode($Fn_QHB->QFPay($_GET['qfid'],$_GET['tid'])));
	
}else if($_GET[f] == 'GetAjaxShare' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['tid']){
	echo urldecode(json_encode($Fn_QHB->GetAjaxShare($_GET['tid'],$_GET['type'])));

}else if($_GET[f] == 'GetAjaxHbState' && $_GET['formhash'] == formhash() && $_G['uid'] && $_GET['lid']){
	echo urldecode(json_encode($Fn_QHB->GetAjaxHbState($_GET['lid'])));
}
//From: Dism_taobao_com
?>