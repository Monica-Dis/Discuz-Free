<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Common.php');
$Operation = in_array($_GET['Operation'], array('Del','OpValue')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&page='.$_GET[page].'&keyword='.$_GET[keyword];
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'S.id';
		if($_GET['keyword']){
			$Where .= ' and concat(S.username,S.uid,S.type) like(\'%'.addslashes(dhtmlspecialchars($_GET[keyword])).'%\')';
		}
		if($_GET['tid']){
			$Where .= ' and S.tid = '.intval($_GET['tid']);
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ���� */
		$StateSelected = array($_GET['state']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_QHB->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}"></td>
						<th>Tid</th><td><input type="text" class="txt" name="tid" value="{$_GET['tid']}" size="5">
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_QHB->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">	
						</td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */

		/* ģ����� */
		$TdStyle = array('width="80"', 'width="300"','width="80"','width="100"','width="80"','');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'QiangLouModule', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_QHB->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
			'ID',
			$Fn_QHB->Config['LangVar']['Title'],
			'Uid',
			$Fn_QHB->Config['LangVar']['UserNameTitle'],
			$Fn_QHB->Config['LangVar']['ShareTypeTitle'],
			$Fn_QHB->Config['LangVar']['ShareTimeTitle']
		), 'header tbm',$TdStyle);
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'],
				'<a href="'.$Fn_QHB->Config['ViewThreadUrl'].$Module['tid'].'" target="_blank">'.'['.$Module['ftitle'].']'.$Module['title'].'</a>',
				$Module['uid'],
				$Module['username'],
				$Module['type'],
				date('Y-m-d H:i:s',$Module['dateline'])
			));
		}
		showsubmit('Submit','submit','del','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        /*Dism_taobao_com*/showtablefooter();
		showformfooter();/*Dism��taobao��com*/
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_QHB->TableShareLog,'id ='.$Val);
			}
			cpmsg($Fn_QHB->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_QHB->Config['LangVar']['DelErr'],'','error');
		}
	}
}
/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_QHB;
	$FetchSql = 'SELECT T.title,T.ftitle,S.* FROM '.DB::table($Fn_QHB->TableShareLog).' S LEFT JOIN '.DB::table('common_member').' M on M.uid = S.uid LEFT JOIN '.DB::table($Fn_QHB->TableQHB).' T on T.id = S.tid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where){
	global $Fn_QHB;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_QHB->TableShareLog).' S '.$Where;
	return DB::result_first($FetchSql);//��������
}

?>