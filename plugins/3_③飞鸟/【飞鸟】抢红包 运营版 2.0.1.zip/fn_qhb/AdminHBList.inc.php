<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_qhb/Common.php');
$Operation = in_array($_GET['Operation'], array('Del','Display')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
$OpQHBCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminHB';
$OpWinningListCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminWinningList';
$OpCommentListCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminPostList';
$OpShareListCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminShareList';

if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ���� */
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		$EndTimeSelected = array($_GET['EndTime']=>' selected');
		$OrderSelected = array($_GET['order']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>ID</th><td><input type="text" class="txt" name="tid" value="{$_GET['tid']}"></td>
						<th>{$Fn_QHB->Config['LangVar']['Title']}</th><td><input type="text" class="txt" name="title" value="{$_GET['title']}"></td>
						<th>{$Fn_QHB->Config['LangVar']['IsEndTime']}</th><td>
						<select name="EndTime">
							<option value="">{$Fn_QHB->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$EndTimeSelected['1']}>{$Fn_QHB->Config['LangVar']['Yes']}</option>
							<option value="0"{$EndTimeSelected['0']}>{$Fn_QHB->Config['LangVar']['No']}</option>
						</select>
						</td>
						<th>{$Fn_QHB->Config['LangVar']['SortTitle']}</th><td colspan="3"><select name="order">
						<option value="id"{$OrderSelected['id']}>id</option>
						<option value="displayorder"{$OrderSelected['displayorder']}>{$Fn_QHB->Config['LangVar']['DisplayOrder']}</option>
						</select>&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_QHB->Config['LangVar']['SearchSubmit']}" class="btn" type="submit"></td>
					</tr>
					
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = in_array($_GET['order'], array('id','displayorder')) ? 'Q.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'Q.id';
		if($_GET['tid']){
			$Where .= ' and Q.id = '.intval($_GET['tid']);
		}
		if($_GET['title']){
			$Where .= ' and concat(Q.title,Q.ftitle) like(\'%'.addslashes(dhtmlspecialchars($_GET['title'])).'%\')';
		}
		if($_GET['EndTime']){
			$Where .= ' and Q.end_time < '.time();
		}else if($_GET['EndTime'] == '0'){
			$Where .= ' and Q.end_time > '.time();
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		$TdStyle = array('width="20"','width="130"', 'width="80"','width="120"','width="120"','width="120"','width="55"','width="55"','width="55"','width="55"','width="55"','width="55"','width="55"','');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'QiangLouModule', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_QHB->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
            'ID',
			$Fn_QHB->Config['LangVar']['Title'],
			$Fn_QHB->Config['LangVar']['PassTitle'],
			$Fn_QHB->Config['LangVar']['StartTimeTitle'],
			$Fn_QHB->Config['LangVar']['EndTimeTitle'],
			$Fn_QHB->Config['LangVar']['TimeTitle'],
			$Fn_QHB->Config['LangVar']['ParticipateCount'],
			$Fn_QHB->Config['LangVar']['WinningNumCount'],
			$Fn_QHB->Config['LangVar']['YQJE'],
			$Fn_QHB->Config['LangVar']['ShareTitle'],
			$Fn_QHB->Config['LangVar']['DisplayOrder'],
			$Fn_QHB->Config['LangVar']['PayTitle'],
			$Fn_QHB->Config['LangVar']['DisplayTitle'],
			$Fn_QHB->Config['LangVar']['OperationTitle']
		), 'header tbm',$TdStyle);
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($ModulesList as $Module) {
			$PostData = DB::fetch_all("SELECT P.uid FROM ".DB::table($Fn_QHB->TablePost)." P Where P.tid = ".$Module['id']." GROUP BY P.uid");
			$HBData = DB::fetch_all("SELECT L.uid FROM ".DB::table($Fn_QHB->TableHBLog)." L Where L.tid = ".$Module['id']." GROUP BY L.uid");
			$ShareCount = DB::result_first('SELECT COUNT(*) FROM '.DB::table($Fn_QHB->TableShareLog).' where tid = '.$Module['id']);
			$HBCount = DB::result_first("SELECT sum(money) as sum FROM ".DB::table($Fn_QHB->TableHBLog)." L Where L.tid = ".$Module['id']);
			$Module['param'] = unserialize($Module['param']);
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'],
				'<a href="'.$Fn_QHB->Config['ViewThreadUrl'].$Module['id'].'" target="_blank">'.'['.$Module['ftitle'].']'.$Module['title'].'</a>',
				$Module['param']['pass'],
				$Module['start_time'] ? date('Y-m-d H:i',$Module['start_time']) : '',
				$Module['end_time'] ? date('Y-m-d H:i',$Module['end_time']) : '',
				date('Y-m-d H:i',$Module['dateline']),
				count($PostData),
				count($HBData),
				$HBCount ? $HBCount : 0,
				$ShareCount,
				$Module['displayorder'],
				$Module['pay_state'] ? $Fn_QHB->Config['LangVar']['Yes'] : '<span style="color:red">'.$Fn_QHB->Config['LangVar']['No'].'<span>',
				$Module['display'] ? $Fn_QHB->Config['LangVar']['Yes'] : '<span style="color:red">'.$Fn_QHB->Config['LangVar']['No'].'<span>',
				'<a href="'.$Fn_QHB->Config['ViewThreadUrl'].$Module['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$OpQHBCpUrl.'&tid='.$Module['id'].'">'.$Fn_QHB->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Display&tid='.$Module['id'].'&value='.(!empty($Module['display']) ? 0:1).'&formhash='.FORMHASH.'">'.(!empty($Module['display']) ? $Fn_QHB->Config['LangVar']['DisplayNoTitle'] : $Fn_QHB->Config['LangVar']['DisplayIsTitle']).'</a>&nbsp;&nbsp;<a href="'.$OpWinningListCpUrl.'&tid='.$Module['id'].'">'.$Fn_QHB->Config['LangVar']['WinningOperationTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCommentListCpUrl.'&tid='.$Module['id'].'">'.$Fn_QHB->Config['LangVar']['CommentOperationTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpShareListCpUrl.'&tid='.$Module['id'].'">'.$Fn_QHB->Config['LangVar']['ShareLogTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&tid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_QHB->Config['LangVar']['DelTitle'].'</a>',
			));
		}

		showsubmit('Submit','submit','del','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        /*Dism_taobao_com*/showtablefooter();
		showformfooter();/*Dism��taobao��com*/
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_QHB->TableQHB,'id ='.$Val);
				DB::delete($Fn_QHB->TablePost,'tid ='.$Val);
				DB::delete($Fn_QHB->TableHBLog,'tid ='.$Val);
				DB::delete($Fn_QHB->TableShareLog,'tid ='.$Val);
				DB::delete($Fn_QHB->TablePostFloorId,'tid ='.$Val);
				DB::delete($Fn_QHB->TablePostNoFloorId,'tid ='.$Val);
			}
			cpmsg($Fn_QHB->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_QHB->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Operation == 'Display' && $_GET['formhash'] == formhash() && $_GET['tid']){//�Ƿ���ʾ
	$TId = intval($_GET['tid']);
	$Value = intval($_GET['value']);
	$Fn_QHB->EditFields($Fn_QHB->TableQHB,$TId,'display',$Value);
	cpmsg($Fn_QHB->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['tid']){//ɾ��
	$TId = intval($_GET['tid']);
	DB::delete($Fn_QHB->TableQHB,'id ='.$TId);
	DB::delete($Fn_QHB->TablePost,'tid ='.$TId);
	DB::delete($Fn_QHB->TableHBLog,'tid ='.$TId);
	DB::delete($Fn_QHB->TableShareLog,'tid ='.$TId);
	DB::delete($Fn_QHB->TablePostFloorId,'tid ='.$TId);
	DB::delete($Fn_QHB->TablePostNoFloorId,'tid ='.$TId);
	cpmsg($Fn_QHB->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}
/* ��Ƶ�б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_QHB;
	$FetchSql = 'SELECT Q.* FROM '.DB::table($Fn_QHB->TableQHB).' Q '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ��Ƶ���� */
function GetModulesCount($Where=null){
	global $Fn_QHB;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_QHB->TableQHB).' Q '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism_taobao_com
?>