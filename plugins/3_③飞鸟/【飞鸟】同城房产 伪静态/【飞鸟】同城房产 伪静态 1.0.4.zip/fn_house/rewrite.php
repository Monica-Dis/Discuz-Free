<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {

	exit('Access Denied');

}

if(!$Fn_Admin->CheckUserGroup('house_all') && !$Fn_Admin->CheckUserGroup('house_rewrite')){//Ȩ���ж�
	fn_cpmsg($Fn_Admin->Config['LangVar']['NoAuthorityErr'],'','error');
	exit();
}

@require_once libfile('function/cache');

$CpMsgUrl = $OpCpUrl = $MpUrl = $FormUrl = $Fn_Admin->Config['IframeItemUrl'];

$SubModel = in_array($_GET['submodel'], array('setup','rule')) ? $_GET['submodel'] : 'setup';
$NavClass = array($SubModel=>'btn-info Hover');

$RewriteSetUp = lang('plugin/fn_assembly','RewriteSetUp');
$RewriteRule = lang('plugin/fn_assembly','RewriteRule');
//����
echo <<<Nav
<div class="SubModelNav">
  <ul>
	<li class="{$NavClass['setup']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=setup" target="_self">{$RewriteSetUp}</a></li>
    <li class="{$NavClass['rule']}"><a href="{$Fn_Admin->Config[IframeItemUrl]}&submodel=rule" target="_self">{$RewriteRule}</a></li>
  </ul>
  <div class="both"></div>
</div>
Nav;

$rewrite_name = 'fn_'.$_GET['mod'].'_rewrite';
loadcache($rewrite_name);

if($SubModel == 'setup'){//����
	
	if(!submitcheck('rewritesubmit')) {

		echo '<div class="alert alert-primary" role="alert">'.lang('plugin/fn_assembly','URLRewriteTips').'</div>';
		showtagheader('div', 'row', true,'row');
		showtagheader('div', 'col-12', true,'col-12');
		showtagheader('div', 'box', true,'box');
		showtagheader('div', 'box-body', true,'box-body');
		showtagheader('div', 'table-responsive', true,'table-responsive');
		showformheader($FormUrl.'&submodel='.$SubModel);
		showtableheader('','table mt-0 table-hover no-wrap dataTable no-footer');
		showsubtitle(array('setting_seo_pages', 'setting_seo_vars', 'setting_seo_rule', 'available'));
		$rewrite = array(
			'index' => array('house'),
			'list_disc' => array('house_disc'),
			'view_disc' => array('house_disc/{iid}.htm','{iid}'),
			'list_1' => array('house_second_hand'),
			'list_2' => array('house_rental'),
			'list_3' => array('house_shops'),
			'list_4' => array('house_workshop'),
			'list_5' => array('house_office'),
			'list_6' => array('house_warehouse'),
			'list_7' => array('house_land'),
			'view' => array('house_view/{iid}.htm','{iid}'),
			'list_agent' => array('house_agent'),
			'view_agent' => array('house_view_agent/{auid}.htm','{auid}'),
			'list_store' => array('house_store'),
			'store' => array('house_store/{aid}.htm','{aid}'),
			'list_article' => array('house_article'),
			'view_article' => array('house_article/{aid}.htm','{aid}'),
			'calculation' => array('house_calculation')
		);
		$rewrite_setting = $_G['cache'][$rewrite_name];
		$RewriteLang = lang('plugin/fn_house','RewriteArray');
		foreach($rewrite as $key => $value) {
			$rule = $rewrite_setting[$key]['rule'] ? $rewrite_setting[$key]['rule'] : $value[0];
			$available = $rewrite_setting[$key]['available'] ? ' checked="checked"' : '';
			showtablerow('', array('class="w200"', 'class="w150"', 'class=""'), array(
				$RewriteLang[$key],
				$value[1],
				'<input type="text" name="'.$rewrite_name.'['.$key.'][rule]" class="form-control w300" value="'.$rule.'" />',
				'<input type="checkbox" class="filled-in" id="checkbox_'.$key.'" name="'.$rewrite_name.'['.$key.'][available]" value="1"'.$available.'><label for="checkbox_'.$key.'"></label>'
			));
		}
		showsubmit('rewritesubmit', '&#20445;&#23384;&#37197;&#32622;');
		showtablefooter();/*Dism_taobao-com*/
		showformfooter();
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');
		showtagfooter('div');

	}else{
		savecache($rewrite_name,$_GET[$rewrite_name]);
		fn_cpmsg(lang('plugin/fn_assembly','rewrite_update_succeed'), $CpMsgUrl.'&submodel='.$SubModel, 'succeed');
	}

}else if($SubModel == 'rule'){//����
	$rule = array();
	$rewrite = $_G['cache'][$rewrite_name];
	
	$rewritedata = array(
		'rulesearch' => array(
			'index' => $rewrite['index']['rule'],
			'list_disc' => $rewrite['list_disc']['rule'],
			'view_disc' => $rewrite['view_disc']['rule'],
			'list_1' => $rewrite['list_1']['rule'],
			'list_2' => $rewrite['list_2']['rule'],
			'list_3' => $rewrite['list_3']['rule'],
			'list_4' => $rewrite['list_4']['rule'],
			'list_5' => $rewrite['list_5']['rule'],
			'list_6' => $rewrite['list_6']['rule'],
			'list_7' => $rewrite['list_7']['rule'],
			'view' => $rewrite['view']['rule'],
			'list_agent' => $rewrite['list_agent']['rule'],
			'view_agent' => $rewrite['view_agent']['rule'],
			'list_store' => $rewrite['list_store']['rule'],
			'store' => $rewrite['store']['rule'],
			'list_article' => $rewrite['list_article']['rule'],
			'view_article' => $rewrite['view_article']['rule'],
			'calculation' => $rewrite['calculation']['rule']
		),
		'rulereplace' => array(
			'index' => 'plugin.php?id=fn_house',
			'list_disc' => 'plugin.php?id=fn_house&m=list_disc',
			'view_disc' => 'plugin.php?id=fn_house&m=view_disc&iid={iid}',
			'list_1' => 'plugin.php?id=fn_house&m=list&class=1',
			'list_2' => 'plugin.php?id=fn_house&m=list&class=2',
			'list_3' => 'plugin.php?id=fn_house&m=list&class=3',
			'list_4' => 'plugin.php?id=fn_house&m=list&class=4',
			'list_5' => 'plugin.php?id=fn_house&m=list&class=5',
			'list_6' => 'plugin.php?id=fn_house&m=list&class=6',
			'list_7' => 'plugin.php?id=fn_house&m=list&class=7',
			'view' => 'plugin.php?id=fn_house&m=view&iid={iid}',
			'list_agent' => 'plugin.php?id=fn_house&m=list_agent',
			'view_agent' => 'plugin.php?id=fn_house&m=view_agent&auid={auid}',
			'list_store' => 'plugin.php?id=fn_house&m=list_store',
			'store' => 'plugin.php?id=fn_house&m=store&aid={aid}',
			'list_article' => 'plugin.php?id=fn_house&m=list_article',
			'view_article' => 'plugin.php?id=fn_house&m=view_article&aid={aid}',
			'calculation' => 'plugin.php?id=fn_house&m=calculation'
		),
		'rulevars' => array(
			'index' => array(),
			'list_disc' => array(),
			'view_disc' => array('{iid}' => '([0-9]+)'),
			'list_1' => array(),
			'list_2' => array(),
			'list_3' => array(),
			'list_4' => array(),
			'list_5' => array(),
			'list_6' => array(),
			'list_7' => array(),
			'view' => array('{iid}' => '([0-9]+)'),
			'list_agent' => array(),
			'view_agent' => array('{auid}' => '([0-9]+)'),
			'list_store' => array(),
			'store' => array('{aid}' => '([0-9]+)'),
			'list_article' => array(),
			'view_article' => array('{aid}' => '([0-9]+)'),
			'calculation' => array()
		)
	);
	$rule['{apache1}'] = $rule['{apache2}'] = $rule['{iis}'] = $rule['{iis7}'] = $rule['{zeus}'] = $rule['{nginx}'] = '';
	
	foreach($rewritedata['rulesearch'] as $k => $v) {
		
		if(!$rewrite[$k]['available']) {
			continue;
		}
		
		$v = !$_G['setting']['rewriterule'][$k] ? $v : $_G['setting']['rewriterule'][$k];
		
		$pvmaxv = count($rewritedata['rulevars'][$k]) + 2;
		$vkeys = array_keys($rewritedata['rulevars'][$k]);
		
		$rewritedata['rulereplace'][$k] = pvsort($vkeys, $v, $rewritedata['rulereplace'][$k]);
		
		$v = str_replace($vkeys, $rewritedata['rulevars'][$k], addcslashes($v, '?*+^$.[]()|'));
		$rule['{apache1}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^(.*/)*'.$v.'$ $1/'.pvadd($rewritedata['rulereplace'][$k])."&%1\n";
		if($k != 'forum_archiver') {
			$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^'.$v.'$ '.$rewritedata['rulereplace'][$k]."&%1\n";
		} else {
			$rule['{apache2}'] .= 'RewriteCond %{QUERY_STRING} ^(.*)$'."\n".'RewriteRule ^archiver/'.$v.'$ archiver/'.$rewritedata['rulereplace'][$k]."&%1\n";
		}
		$rule['{iis}'] .= 'RewriteRule ^(.*)/'.$v.'(\?(.*))*$ $1/'.addcslashes(pvadd($rewritedata['rulereplace'][$k]).'&$'.($pvmaxv + 1), '.?')."\n";
		$rule['{iis7}'] .= '&lt;rule name="'.$k.'"&gt;'."\n\t".'&lt;match url="^(.*/)*'.str_replace('\.', '.', $v).'\?*(.*)$" /&gt;'."\n\t".'&lt;action type="Rewrite" url="{R:1}/'.str_replace(array('&', 'page\%3D'), array('&amp;amp;', 'page%3D'), addcslashes(pvadd($rewritedata['rulereplace'][$k], 1).'&{R:'.$pvmaxv.'}', '?')).'" /&gt;'."\n".'&lt;/rule&gt;'."\n";
		$rule['{zeus}'] .= 'match URL into $ with ^(.*)/'.$v.'\?*(.*)$'."\n".'if matched then'."\n\t".'set URL = $1/'.pvadd($rewritedata['rulereplace'][$k]).'&$'.$pvmaxv."\nendif\n";
		$rule['{nginx}'] .= 'rewrite ^([^\.]*)/'.$v.'$ $1/'.stripslashes(pvadd($rewritedata['rulereplace'][$k]))." last;\n";
	}
	showtagheader('div', 'row', true,'row');
	showtagheader('div', 'col-12', true,'col-12');
	showtagheader('div', 'box', true,'box');
	showtagheader('div', 'box-body', true,'box-body');
	echo '<style>h1{font-size:18px;}</style>';
	echo str_replace(array_keys($rule), $rule, cplang('rewrite_message'));
	showtagfooter('div');
	showtagfooter('div');
	showtagfooter('div');
	showtagfooter('div');
	
}
function pvsort($key, $v, $s) {
	$r = '/';
	$p = '';
	foreach($key as $k) {
		$r .= $p.preg_quote($k);
		$p = '|';
	}
	$r .= '/';
	preg_match_all($r, $v, $a);
	$a = $a[0];
	$a = array_flip($a);
	foreach($a as $key => $value) {
		$s = str_replace($key, '$'.($value + 1), $s);
	}
	return $s;
}

function pvadd($s, $t = 0) {
	$s = str_replace(array('$5', '$4', '$3', '$2', '$1'), array('~6', '~5', '~4', '~3', '~2'), $s);
	if(!$t) {
		return str_replace(array('~6', '~5', '~4', '~3', '~2'), array('$6', '$5', '$4', '$3', '$2'), $s);
	} else {
		return str_replace(array('~6', '~5', '~4', '~3', '~2'), array('{R:6}', '{R:5}', '{R:4}', '{R:3}', '{R:2}'), $s);
	}

}
//From: Dism��taobao��com
?>