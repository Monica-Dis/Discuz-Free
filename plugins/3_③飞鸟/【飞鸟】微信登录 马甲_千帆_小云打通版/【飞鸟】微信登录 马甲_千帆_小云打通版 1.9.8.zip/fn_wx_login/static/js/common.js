$(function() {  
	FastClick.attach(document.body);  
});
window.addEventListener("DOMContentLoaded", function() {
	
});

$(window).load(function() {
	$('.fixed_load').fadeOut('slow');
});