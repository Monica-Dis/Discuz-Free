<?php
/**
 *	[������΢�ŵ�¼(fn_wx_login.{modulename})] ���²����http://t.cn/Aiux1Jx1
 *	Version: 1.0
 *	Date: 2017-8-3 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once(DISCUZ_ROOT .'./source/plugin/fn_wx_login/Function.inc.php');
$FnWxLogin = new FnWxLogin;
if($_G['uid'] && $FnWxLogin->TableBindUser){
    if($BindUser = $FnWxLogin->BindUserFetchByUid($_G['uid'])) {
		$_G['member']['openid']    = $BindUser['openid'];
        $_G['member']['unionid']   = $BindUser['unionid'];
        $_G['member']['subscribe'] = $BindUser['subscribe'] == 1 ? 1 : 0;
        CURSCRIPT == 'home' && $_G['member']['isregister'] = $BindUser['isregister'];
        unset($BindUser);
    }
}
//���԰�
class plugin_fn_wx_login{
    function global_login_extra(){
        global $_G;
		$FnWxLoginData = $_G['cache']['plugin']['fn_wx_login'];
		if (!$_G['uid'] && $FnWxLoginData['WxRegister']) {
            include template('fn_wx_login:GlobalLogin');
            return $Html;
        }
    }
    function global_usernav_extra1(){
        global $_G;
		$FnWxLoginData = $_G['cache']['plugin']['fn_wx_login'];
		if(!$_G['uid'] || $_G['member']['unionid'] || $_G['member']['openid']) {
            return;
        }
		if($_G['uid'] && $FnWxLoginData['WxRegister']) {
            include template('fn_wx_login:GlobalUserNav');
            return $Html;
        }
    }
}

class plugin_fn_wx_login_member extends plugin_fn_wx_login{

	function logging_method(){
        global $_G;
        $FnWxLoginData = $_G['cache']['plugin']['fn_wx_login'];
        if($FnWxLoginData['WxRegister']) {
            include template('fn_wx_login:WxLogin');
            return $Html;
        }
    }
	
	function register_logging_method(){
		global $_G;
		$FnWxLoginData = $_G['cache']['plugin']['fn_wx_login'];
		if($FnWxLoginData['WxRegister']){
			include template('fn_wx_login:WxLogin');
            return $Html;
        }
    }

}
//���԰� End

//�ֻ���
class mobileplugin_fn_wx_login{
	function common(){
		global $_G;
		$FnWxLoginData = $_G['cache']['plugin']['fn_wx_login'];
		if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
			$WxApp = true;
		}
		if($FnWxLoginData['MobileRegister'] && !$_G['uid'] && $WxApp && $_GET['id'] != 'fn_wx_login' && strpos($_GET['id'], 'qianfan') === false && CURMODULE != 'logout' && $_GET['id'] != 'fn_house_wx'){
			$Http = ((isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') || (isset($_SERVER['HTTP_X_CLIENT_SCHEME']) && $_SERVER['HTTP_X_CLIENT_SCHEME'] == 'https')) ? 'https://' : 'http://';
			if(isset($_SERVER['HTTP_X_REWRITE_URL'])){
                $RequestUri = $_SERVER['HTTP_X_REWRITE_URL'];
            }else if(isset($_SERVER['REQUEST_URI'])) {
                $RequestUri = $_SERVER['REQUEST_URI'];
            }else if(isset($_SERVER['REDIRECT_URL'])) {
                $RequestUri = $_SERVER['REDIRECT_URL'];
            }else if(isset($_SERVER['ORIG_PATH_INFO'])) {
                $RequestUri = $_SERVER['ORIG_PATH_INFO'];
				if($_SERVER['QUERY_STRING']){
                    $RequestUri .= '?' .$_SERVER['QUERY_STRING'];
                }
            }
			$Referer = $Http.$_SERVER['HTTP_HOST'].$RequestUri;
			if(CURMODULE == 'logging' || CURMODULE == 'register'){
				$Referer = dreferer();
			}

			if(strpos($FnWxLoginData['WxOauthDomain'],'oauth2.htm') !== false) {
				 $LoginUrl = $FnWxLoginData['WxOauthDomain'].'?appid='.$FnWxLoginData['WxAppid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&Referer=' . urlencode($Referer));
			}else{
				$LoginUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$FnWxLoginData['WxAppid'].'&redirect_uri=' . urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&Referer='.urlencode($Referer)).'&response_type=code&scope=snsapi_userinfo&state='. md5(FORMHASH).'#wechat_redirect';
			}
			dheader('Location:'.$LoginUrl);
		}
	}
	function global_footer_mobile(){
		global $_G;
		$FnWxLoginData = $_G['cache']['plugin']['fn_wx_login'];
		if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
			$WxApp = true;
		}
		if(CURMODULE == 'register' && $FnWxLoginData['WxRegister'] && $WxApp){
			$Referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '') : dreferer();
			if(strpos($FnWxLoginData['WxOauthDomain'],'oauth2.htm') !== false) {
				 $LoginUrl = $FnWxLoginData['WxOauthDomain'].'?appid='.$FnWxLoginData['WxAppid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&Referer=' . urlencode($Referer));
			}else{
				$LoginUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$FnWxLoginData['WxAppid'].'&redirect_uri=' . urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&Referer='.urlencode($Referer)).'&response_type=code&scope=snsapi_userinfo&state='. md5(FORMHASH).'#wechat_redirect';
			}
			include template('fn_wx_login:GlobalFooter');
            return $Html;
		}

		/*if($FnWxLoginData['MobileRegister'] && !$_G['uid'] && $WxApp){
			$Http = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') || (isset($_SERVER['HTTP_X_CLIENT_SCHEME']) && $_SERVER['HTTP_X_CLIENT_SCHEME'] == 'https')) ? 'https://' : 'http://';
			if(isset($_SERVER['HTTP_X_REWRITE_URL'])){
                $RequestUri = $_SERVER['HTTP_X_REWRITE_URL'];
            }else if(isset($_SERVER['REQUEST_URI'])) {
                $RequestUri = $_SERVER['REQUEST_URI'];
            }else if(isset($_SERVER['REDIRECT_URL'])) {
                $RequestUri = $_SERVER['REDIRECT_URL'];
            }else if(isset($_SERVER['ORIG_PATH_INFO'])) {
                $RequestUri = $_SERVER['ORIG_PATH_INFO'];
				if($_SERVER['QUERY_STRING']){
                    $RequestUri .= '?' .$_SERVER['QUERY_STRING'];
                }
            }
			$Referer = $Http.$_SERVER['HTTP_HOST'].$RequestUri;
			if(CURMODULE == 'logging'){
				$Referer = dreferer();
			}
			if(strpos($FnWxLoginData['WxOauthDomain'],'oauth2.htm') !== false) {
				 $LoginUrl = $FnWxLoginData['WxOauthDomain'].'?appid='.$FnWxLoginData['WxAppid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&Referer=' . urlencode($Referer));
			}else{
				$LoginUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$FnWxLoginData['WxAppid'].'&redirect_uri=' . urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&Referer='.urlencode($Referer)).'&response_type=code&scope=snsapi_userinfo&state='. md5(FORMHASH).'#wechat_redirect';
			}
			dheader('Location:'.$LoginUrl);
		}*/

	}

}

class mobileplugin_fn_wx_login_member extends mobileplugin_fn_wx_login{
	
	function logging_bottom_mobile(){
		global $_G;
		$FnWxLoginData = $_G['cache']['plugin']['fn_wx_login'];
		if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
			$WxApp = true;
		}
		if($FnWxLoginData['WxRegister'] && $WxApp){
			$Referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '') : dreferer();
			if(strpos($FnWxLoginData['WxOauthDomain'],'oauth2.htm') !== false) {
				 $LoginUrl = $FnWxLoginData['WxOauthDomain'].'?appid='.$FnWxLoginData['WxAppid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&Referer=' . urlencode($Referer));
			}else{
				$LoginUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$FnWxLoginData['WxAppid'].'&redirect_uri=' . urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&Referer='.urlencode($Referer)).'&response_type=code&scope=snsapi_userinfo&state='. md5(FORMHASH).'#wechat_redirect';
			}
			include template('fn_wx_login:GlobalFooter');
            return $Html;
		}

	}

}
//�ֻ��� End
?>