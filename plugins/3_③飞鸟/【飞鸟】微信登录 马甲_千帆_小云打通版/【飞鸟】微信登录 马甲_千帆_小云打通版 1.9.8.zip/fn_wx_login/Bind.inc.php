<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, [DisM!] (C)2001-2099 DisM Inc.
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once(DISCUZ_ROOT .'./source/plugin/fn_wx_login/Function.inc.php');
require_once(DISCUZ_ROOT .'./source/plugin/fn_wx_login/Common.inc.php');
if($_G['uid']){//检查是否绑定过
    $CheckUser = $FnWxLogin->BindUserFetchByUid($_G['uid']);
    if($CheckUser){
        showmessage($FnWxLogin->Config['LangVar']['IsToGrantAuthorizationErr']);
    }
	$Data['uid'] = $_G['uid'];
}
$Data['dateline'] = $_G['timestamp'];
$Data['code'] = $Hash = random(10);
DB::insert($FnWxLogin->TableAuthCode,$Data);

$Referer = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '') : dreferer();

if(strpos($FnWxLogin->Config['PluginVar']['WxOauthDomain'],'oauth2.htm') !== false){
	$LoginUrl = $FnWxLogin->Config['PluginVar']['WxOauthDomain'].'?appid='.$FnWxLogin->Config['PluginVar']['WxAppid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&Hash='.$Hash.'&Referer=' . urlencode($Referer));
}else{
	$LoginUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$FnWxLogin->Config['PluginVar']['WxAppid'].'&redirect_uri=' . urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&Hash='.$Hash.'&Referer='.urlencode($Referer)).'&response_type=code&scope=snsapi_userinfo&state='. md5(FORMHASH).'#wechat_redirect';
}

$QrSize = 5;
$Dir = 'data/cache/qrcode/';//存储路径
$File = $Dir.'fn_wx_login'.$Data['code'].'.jpg';
if(!file_exists($File) || !filesize($File)) {
    dmkdir($Dir);
    require_once DISCUZ_ROOT.'source/plugin/fn_wx_login/Class/Qrcode.Class.php';
    QRcode::png($LoginUrl, $File, QR_ECLEVEL_L, $QrSize);
}
$QrCode = base64_encode(file_get_contents($File));
unlink($File);
include template("fn_wx_login:QrCode");
?>