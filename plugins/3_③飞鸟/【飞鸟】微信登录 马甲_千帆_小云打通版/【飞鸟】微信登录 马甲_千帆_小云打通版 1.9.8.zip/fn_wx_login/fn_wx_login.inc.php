<?php
/**
 *	[������΢�ŵ�¼(fn_wx_login.{modulename})] ���²����http://t.cn/Aiux1Jx1
 *	Version: 1.0
 *	Date: 2017-8-3 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_wx_login/Function.inc.php');
require_once DISCUZ_ROOT . './source/plugin/fn_wx_login/Class/Wechat.Lib.Class.php';
$FnWxLogin = new FnWxLogin;
$WechatClient = new Fn_WeChatClient($FnWxLogin->Config['PluginVar']['WxAppid'], $FnWxLogin->Config['PluginVar']['WxSecret']);
$Model = addslashes($_GET['Model']);
$Hash = addslashes($_GET['Hash']);
$Referer = dreferer();
$Referer2 = explode('Referer=',GetUrl());
if ($Referer2[1]) {
    $Referer = urldecode($Referer2[1]);
}
$Referer = strpos($Referer,'?') ? $Referer : preg_replace('/&/','?',$Referer,1);
$RefererArr = parse_url($Referer);
parse_str($RefererArr['query'],$RefererArr['query']);
unset($RefererArr['query']['code']);
unset($RefererArr['query']['state']);
$Referer = $RefererArr['scheme'].'://'.$RefererArr['host'].$RefererArr['path'].'?'.http_build_query($RefererArr['query']);
if($Model == 'OAuth'){
	if($Hash) {
        $IsPcuid = $FnWxLogin->AuthCodeFetchByCode($Hash);
        if($IsPcuid['uid'] > 0) {
            require_once libfile('function/member');
            $Member = getuserbyuid($IsPcuid['uid'], 1);
            $CookieTime = 1296000;
            setloginstatus($Member, $CookieTime);
        }
    }
	if($_GET['code']){
		$Token = $WechatClient->getAccessTokenByCode($_GET['code']);
		if(!$Token['openid']){
			 showmessage($FnWxLogin->Config['LangVar']['ToGrantAuthorizationErr'].($Token['errmsg'] ?'AccessToken:'. $Token['errmsg']:''),$Referer);
		}
		//$Referer = $Referer.(strpos($Referer, '?') ? '&':'?').'code='.$_GET['code'].'&state='.$_GET['state'];
		$SnsapiUserInfo = in_array('snsapi_userinfo', explode(',', $Token['scope'])) ? true : false;
		if(!$SnsapiUserInfo){
			$Info = $WechatClient->getUserInfoById($Token['openid'], 'zh_CN');
			if($Info['openid']){
				$UserInfo = $Info;
			}else{
				if(strpos($FnWxLogin->Config['PluginVar']['WxOauthDomain'],'oauth2.htm') !== false || strpos($FnWxLogin->Config['PluginVar']['WxOauthDomain'],'get-weixin-code.html') !== false){
					$Redirect = $FnWxLogin->Config['PluginVar']['WxOauthDomain'].'?appid='.$FnWxLogin->Config['PluginVar']['WxAppid']. '&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='. urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&IsRegister=ToRegister&Hash='.$Hash.'&GetInfo='.$_GET['GetInfo'].'&Referer=' . urlencode($Referer));
				}else{
					$Redirect = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$FnWxLogin->Config['PluginVar']['WxAppid'].'&redirect_uri=' . urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&IsRegister=ToRegister&Hash=' .$Hash.'&GetInfo='.$_GET['GetInfo'].'&Referer='.urlencode($Referer)).'&response_type=code&scope=snsapi_userinfo&state='.md5(FORMHASH).'#wechat_redirect';
				}
			}
		}else{
			$UserInfo = $WechatClient->getUserInfoByAuth($Token['access_token'], $Token['openid']);
		}
		if($UserInfo['errcode']){
            showmessage($FnWxLogin->Config['LangVar']['ToGrantAuthorizationErr'].($UserInfo['errmsg'] ? ' UserInfo:'.$UserInfo['errmsg'] : ''));
        }

		if($_GET['GetInfo']){
            SetOauthCookie($UserInfo, $Token);
			if(!$UserInfo['subscribe'] && $FnWxLogin->Config['PluginVar']['FollowSwitch']){
				dheader('Location:'.$_G['siteurl'].'plugin.php?id=fn_wx_login:follow&referer='.urlencode($Referer));
			}else{
				dheader('Location:'.$Referer);
			}
        }
		
		require_once libfile('function/member');
		/* �Ƿ�����Ȩ */
		if($Token['unionid']){
			$BindMember = CheckBindBemberApp($Token['unionid']);
        }

		if(!$BindMember && $UserInfo['unionid']){
			$BindMember = CheckBindBemberApp($UserInfo['unionid']);
        }

		if(!$BindMember && $Token['openid']){
           $BindMember = $FnWxLogin->BindUserFetchByOpenid($Token['openid']);
        }

		if(!$BindMember && $UserInfo['openid']){
            $BindMember = $FnWxLogin->BindUserFetchByOpenid($UserInfo['openid']);
        }
		if($BindMember) {
            $Member = getuserbyuid($BindMember['uid']);
            if(!$Member) {
				$FnWxLogin->BindUserDeletebyField('id',$BindMember[id]);
                unset($BindMember);
            }
        }
		/* �Ƿ�����Ȩ End */
		if($_G['uid']){//���˺�
			if($BindMember && $BindMember['uid'] != $_G['uid']){
                showmessage($FnWxLogin->Config['LangVar']['RepeatBindingErr'],'home.php?mod=space&do=profile',array('username' => $_G['member']['username']));
                exit;
            }
			if($BindMemberTo = $FnWxLogin->BindUserFetchByUid($_G[uid])) {
                $_G['member']['openid'] = $BindMemberTo['openid'];
                $_G['member']['unionid'] = $BindMemberTo['unionid'];
                $_G['member']['subscribe'] = $BindMemberTo['subscribe'] == 1 ? 1 : 0;
                $_G['member']['isregister'] = $BindMemberTo['isregister'];
                unset($BindMemberTo);
            }
			if($BindMember){
				$BindUserUpData = array('nickname' => dhtmlspecialchars(diconv($UserInfo['nickname'], 'utf-8', CHARSET)), 'counts' => $bind_member['counts'] + 1, 'lastauth' => TIMESTAMP, 'subscribe' => $UserInfo['subscribe'], 'unionid' => $UserInfo['unionid'], 'openid' => $UserInfo['openid']);
				DB::update($FnWxLogin->TableBindUser,$BindUserUpData,'id='.$BindMember[id]);
			}else{
				$BindUserData = array('openid' => $UserInfo['openid'], 'uid' => $_G['uid'], 'username' => $_G['username'], 'nickname' => dhtmlspecialchars(diconv($UserInfo['nickname'], 'utf-8', CHARSET)), 'sex' => intval($UserInfo['sex']), 'dateline' => TIMESTAMP, 'unionid' => $UserInfo['unionid'], 'lastauth' => TIMESTAMP, 'counts' => 1, 'status' => '1', 'subscribe' => $UserInfo['subscribe']);
				DB::insert($FnWxLogin->TableBindUser,$BindUserData);
				/* ���� And С��App And ǧ��*/
				if($FnWxLogin->Config['PluginVar']['App'] == 'mag'){//����App
					$InsData = array('userid' => $_G['uid'],'name' => dhtmlspecialchars(diconv($UserInfo['nickname'])), 'openid' => $UserInfo['openid'], 'unionid' => $UserInfo['unionid'],'create_time'=>time());
					DB::insert($FnWxLogin->TableUserWeixinRelations,$InsData);
				}else if($FnWxLogin->Config['PluginVar']['App'] == 'qf'){//ǧ��
					$InsData = array('uid' => $_G['uid'], 'weibotype' => 'wechat', 'nickname' => dhtmlspecialchars(diconv($UserInfo['nickname'])), 'openid' => $UserInfo['openid'], 'unionid' => $UserInfo['unionid'],'dateline'=>time());
					DB::insert($FnWxLogin->TableThirdbind,$InsData);
				}else if($FnWxLogin->Config['PluginVar']['App'] == 'appbyme'){//С��App
					$InsData = array('uid' =>$_G['uid'], 'openid' => '', 'status' => '1', 'type' => '1', 'param' => $UserInfo['unionid']);
					DB::insert($FnWxLogin->TableAppbymeConnection,$InsData);
				}
				/* ���� And С��App And ǧ��*/
			}
			if($Hash){
				$AuthCodeUpData = array('unionid'=>$UserInfo['unionid'],'openid'=>$UserInfo['openid']);
				DB::update($FnWxLogin->TableAuthCode,$AuthCodeUpData,'code=\''.$Hash.'\'');
			}
			SetOauthCookie($UserInfo,$Token);
			if(!$UserInfo['subscribe'] && $FnWxLogin->Config['PluginVar']['FollowSwitch']){
				dheader('Location:'.$_G['siteurl'].'plugin.php?id=fn_wx_login:follow&referer='.urlencode($Referer));
			}else{
				dheader('Location:'.$Referer);
			}
		}else{//��ע��
			if($BindMember){//����Ȩֱ�ӵ�¼
				BindLogin($BindMember);
				$BindUserUpData = array('username' => $BindMember['username'], 'nickname' => dhtmlspecialchars($UserInfo['nickname'] ?  diconv($UserInfo['nickname'], 'utf-8', CHARSET) : ''), 'counts' => $BindMember['counts']+1, 'lastauth' => TIMESTAMP, 'subscribe' => $UserInfo['subscribe'], 'unionid' => $UserInfo['unionid'], 'openid' => $UserInfo['openid']);
				DB::update($FnWxLogin->TableBindUser,$BindUserUpData,'id='.$BindMember['id']);
				if($_G['setting']['allowsynlogin']) {
                    loaducenter();
                    $ucsynlogin = uc_user_synlogin($BindMember['uid']);
                }
				if($Hash){
					$AuthCodeUpData = array('unionid'=>$UserInfo['unionid'],'openid'=>$UserInfo['openid']);
					DB::update($FnWxLogin->TableAuthCode,$AuthCodeUpData,'code=\''.$Hash.'\'');
				}
				SetOauthCookie($UserInfo,$Token);
				if(!$UserInfo['subscribe'] && $FnWxLogin->Config['PluginVar']['FollowSwitch']){
					dheader('Location:'.$_G['siteurl'].'plugin.php?id=fn_wx_login:follow&referer='.urlencode($Referer));
				}else{
					echo "<script language='javascript'
					type='text/javascript'>"; 
					echo "window.location.href='$Referer'"; 
					echo "</script>";  
					//dheader('Location:'.$Referer);
					exit();
				}
				exit();
			}else{//δ��Ȩ
				if($FnWxLogin->Config['PluginVar']['WxRegister']){
					if($_GET['IsRegister'] != 'ToRegister' && $FnWxLogin->Config['PluginVar']['BindOldUser']){//�����û�
						if(strpos($FnWxLogin->Config['PluginVar']['WxOauthDomain'],'oauth2.htm') !== false || strpos($FnWxLogin->Config['PluginVar']['WxOauthDomain'],'get-weixin-code.html') !== false){
                            $Redirect = $FnWxLogin->Config['PluginVar']['WxOauthDomain'].'?appid='.$FnWxLogin->Config['PluginVar']['WxAppid']. '&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='. urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&IsRegister=ToRegister&Hash='.$Hash.'&Referer=' . urlencode($Referer));
                        } else {
                            $Redirect = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$FnWxLogin->Config['PluginVar']['WxAppid'].'&redirect_uri=' . urlencode($_G['siteurl'].'plugin.php?id=fn_wx_login&Model=OAuth&IsRegister=ToRegister&Hash=' .$Hash.'&Referer='.urlencode($Referer)).'&response_type=code&scope=snsapi_userinfo&state='.md5(FORMHASH).'#wechat_redirect';
                        }
                        $LoginUrl = $Redirect;
                        include template('fn_wx_login:FirstBind');
                        exit;
					}
					$Uid = NewRegister(GetName($UserInfo[nickname]),$UserInfo[sex]);//ע���˺�
					if($Uid){
						if($UserInfo[headimgurl]){//�ϴ�ͷ��
							require_once DISCUZ_ROOT . './source/plugin/fn_wx_login/Class/Wechat.Class.php';
							Fn_WeChat::syncAvatar($Uid,$UserInfo[headimgurl]);
						}
						$BindUserData = array('openid' => $UserInfo['openid'], 'uid' => $Uid, 'username' => $_G['username'], 'nickname' => dhtmlspecialchars($UserInfo['nickname'] ?  diconv($UserInfo['nickname'], 'utf-8', CHARSET) : ''), 'sex' => intval($UserInfo['sex']), 'dateline' => TIMESTAMP, 'unionid' => $UserInfo['unionid'], 'lastauth' => TIMESTAMP, 'counts' => 1, 'subscribe' => $UserInfo['subscribe'], 'isregister' =>1);
						DB::insert($FnWxLogin->TableBindUser,$BindUserData);
						/* ���� And С��App And ǧ�� */
						if($FnWxLogin->Config['PluginVar']['App'] == 'mag'){//����App
							$InsData = array('userid' => $Uid,'name' => dhtmlspecialchars($UserInfo['nickname'] ?  diconv($UserInfo['nickname'], 'utf-8', CHARSET) : ''), 'openid' => $UserInfo['openid'], 'unionid' => $UserInfo['unionid'],'create_time'=>time());
							DB::insert($FnWxLogin->TableUserWeixinRelations,$InsData);	
						}else if($FnWxLogin->Config['PluginVar']['App'] == 'qf'){//ǧ��
							$InsData = array('uid' => $Uid, 'weibotype' => 'wechat', 'nickname' => dhtmlspecialchars($UserInfo['nickname'] ?  diconv($UserInfo['nickname'], 'utf-8', CHARSET) : ''), 'openid' => $UserInfo['openid'], 'unionid' => $UserInfo['unionid'],'dateline'=>time());
							DB::insert($FnWxLogin->TableThirdbind,$InsData);
						}else if($FnWxLogin->Config['PluginVar']['App'] == 'appbyme'){//С��App
							$InsData = array('uid' => $Uid, 'openid' => '', 'status' => '1', 'type' => '1', 'param' => $UserInfo['unionid']);
							DB::insert($FnWxLogin->TableAppbymeConnection,$InsData);
						}
						/* ���� And С��App And ǧ��*/
						if($Hash){
							$AuthCodeData = array('unionid'=>$UserInfo['unionid'],'openid'=>$UserInfo['openid']);
							DB::update($FnWxLogin->TableAuthCode,$AuthCodeData,'code=\''.$Hash.'\'');
						}
						if($FnWxLogin->Config['PluginVar']['Extcredit'] && $FnWxLogin->Config['PluginVar']['ExtcreditNum']){//���»���
                            updatemembercount($_G['uid'], array('extcredits'.$FnWxLogin->Config['PluginVar']['Extcredit'] => $FnWxLogin->Config['PluginVar']['ExtcreditNum']));
                        }
						SetOauthCookie($UserInfo,$Token);
                        if(!$UserInfo['subscribe'] && $FnWxLogin->Config['PluginVar']['FollowSwitch']){
							dheader('Location:'.$_G['siteurl'].'plugin.php?id=fn_wx_login:follow&referer='.urlencode($Referer));
						}else{
							dheader('Location:'.$Referer);
						}
					}else{
						showmessage($FnWxLogin->Config['LangVar']['AutomaticRegisterErr'],$Referer);
					}
				}
			}
		}
	}else{
		showmessage('quickclear_noperm');
	}
}else if($Model == 'CheckHash'){
	$CodeInfo = $FnWxLogin->AuthCodeFetchByCode($Hash);
	if($_G['uid']){
		$CheckUser = $FnWxLogin->BindUserFetchByUid($_G['uid']);
		if($CodeInfo['openid']) {
            $User = $FnWxLogin->BindUserFetchByOpenid($CodeInfo['openid']);
            if($User['uid'] != $_G['uid']){
				$FnWxLogin->AuthCodeDeletebyField('code',$Hash);
                echo '<root>4</root>';
                exit;
            }
        }
		if($CodeInfo['unionid']) {
			$User = $FnWxLogin->BindUserFetchByUnionid($CodeInfo['unionid']);
			if($User['uid'] != $_G['uid']){
				$FnWxLogin->AuthCodeDeletebyField('code',$Hash);
                echo '<root>4</root>';
                exit;
            }
        }
		if($CheckUser) {
            $FnWxLogin->AuthCodeDeletebyField('code',$Hash);
            echo '<root>1</root>';
            exit;
        }else{
            echo '<root>0</root>';
            exit;
        }
	}else{
		if($CodeInfo['openid']){
			require_once libfile('function/member');
			$CheckUser = $FnWxLogin->BindUserFetchByOpenid($CodeInfo['openid']);
			$Uid = $CheckUser['uid'];
			if(!($Member = getuserbyuid($Uid, 1))) {
                $FnWxLogin->AuthCodeDeletebyField('code',$Hash);
                echo '<root>3</root>';
                exit;
            }else{
                if(isset($Member['_inarchive'])) {
                    C::t('common_member_archive')->move_to_master($Uid);
                }
            }
			$CookieTime = 1296000;
            setloginstatus($Member, $CookieTime);
			$FnWxLogin->AuthCodeDeletebyField('openid',$CodeInfo['openid']);
			echo '<root>2</root>';
            exit;
		}else if($CodeInfo['unionid']){
			require_once libfile('function/member');
			$CheckUser = $FnWxLogin->BindUserFetchByUnionid($CodeInfo['unionid']);
			$Uid = $CheckUser['uid'];
			if(!($Member = getuserbyuid($Uid, 1))) {
				$FnWxLogin->AuthCodeDeletebyField('code',$Hash);
                echo '<root>3</root>';
                exit;
            }else{
                if(isset($Member['_inarchive'])) {
                    C::t('common_member_archive')->move_to_master($Uid);
                }
            }
			$CookieTime = 1296000;
            setloginstatus($Member, $CookieTime);
			$FnWxLogin->AuthCodeDeletebyField('unionid',$CodeInfo['unionid']);
			echo '<root>2</root>';
            exit;
		}else{
            echo '<root>0</root>';
            exit;
        }
	}
}else if($Model == 'Tip'){
	$Op        = $_GET['Op'];
    $Url       = dreferer();
    $Alert     = 'error';
    $CloseTime = 1;
    if($Op == 'BindSuccess'){
        $Tip       = $FnWxLogin->Config['LangVar']['BindSuccess'];
        $Alert     = 'right';
        $CloseTime = 0;
    }else if($Op == 'LoginSuccess') {
        $Tip       = $FnWxLogin->Config['LangVar']['LoginSuccess'];
        $Alert     = 'right';
        $CloseTime = 0;
    }else if($Op == 'Error'){
        $Tip       = $FnWxLogin->Config['LangVar']['OpError'];
        $Alert     = 'error';
        $CloseTime = 1;
    }elseif($Op == 'BindError'){
        $Tip       = $FnWxLogin->Config['LangVar']['BindError'];
        $Alert     = 'error';
        $CloseTime = 1;
    }
    $Ext = array(
        'alert' => $Alert,
        'showdialog' => 1
    );
    if($CloseTime){
        $Ext['closetime'] = 3;
    }else{
        $Ext['locationtime'] = 3;
    }
    showmessage($Tip,$Url,array(),$Ext);
}else if($Model == 'MobileBindUser' && $_POST['formhash'] == formhash()){//���û��󶨵�¼
	global $_G;
	$UserName = StrToGBK($_GET['account_username']);
    $PassWord = $_GET['account_password'];
	loaducenter();
	list($Result) = uc_user_login($UserName,$PassWord, 0, 0);
	if($Result >= 0){
        $Member = getuserbyuid($Result, 1);
        if(!$Member) {
            return false;
        }
        require_once libfile('function/member');
        $CookieTime = 1296000;
        setloginstatus($Member, $CookieTime);
        C::t('common_member_status')->update($Result, array('lastip' => $_G['clientip'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));
        if ($_G['setting']['allowsynlogin']){
            loaducenter();
            $ucsynlogin = uc_user_synlogin($Result);
        }
        echo $_G['uid'];
    }
}

//����ת��
function GetName($UserName){
    global $_G,$FnWxLogin;
	$FnWxLogin->Config['PluginVar']['Random'] = $FnWxLogin->Config['PluginVar']['Random'] ? $FnWxLogin->Config['PluginVar']['Random'] : 5;
    $NewUserName = cutstr(diconv(FilterEmoji($UserName),'utf-8'), 15, '');
    if ($NewUserName) {
        $censorexp = '/^(' . str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote($_G['setting']['censoruser'] = trim($_G['setting']['censoruser']), '/')) . ')$/i';
        $NewUserName = preg_replace($censorexp, '', $NewUserName);
        $guestexp = '\\xA1\\xA1|\\xAC\\xA3|^Guest|^\\xD3\\xCE\\xBF\\xCD|\\xB9\\x43\\xAB\\xC8';
        $NewUserName = preg_replace("/\\s+|^c:\\con\\con|[%,\\*\"\\s\\<\\>\\&]|{$guestexp}/is", '', $NewUserName);
    }
    if(dstrlen($NewUserName) >= 3){
        loaducenter();
        if(uc_get_user($NewUserName)){
            $NewUserName = cutstr($NewUserName, 6, '');
            $NewUserName = $FnWxLogin->Config['PluginVar']['RegPrefix'].$NewUserName.'_'.random($FnWxLogin->Config['PluginVar']['Random']);
        }
    }else{
        if($NewUserName) {
            $NewUserName = $FnWxLogin->Config['PluginVar']['RegPrefix'].$NewUserName.'_'.random($FnWxLogin->Config['PluginVar']['Random']);
        } else {
            $NewUserName = $FnWxLogin->Config['PluginVar']['RegPrefix'].random($FnWxLogin->Config['PluginVar']['Random']);
        }
    }
    return $NewUserName;
}

//ע��
function NewRegister($NickName,$Sex){
	global $_G,$FnWxLogin,$WxApp;
	loaducenter();
	if(!$NickName){
		if($WxApp){
			echo Fn_WeChatServer::getXml4Txt(lang('message', 'undefined_action'));
			exit;
		}else{
			showmessage('undefined_action');
		}
	}
	$GroupId = $FnWxLogin->Config['PluginVar']['NewGroupId'] ? $FnWxLogin->Config['PluginVar']['NewGroupId'] : $_G['setting']['newusergroupid'];
	$PassWord = md5(random(10));
	$Email = 'wx_' . strtolower(random(10)).'@null.null';
	/* �Զ�ע����֤ */
	if(dstrlen($NickName) > 15) {
        if($WxApp) {
			echo Fn_WeChatServer::getXml4Txt(lang('message', 'profile_username_toolong'));
			exit;
        }else{
			showmessage('profile_username_toolong');
        }
    }
	$censorexp = '/^(' . str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote($_G['setting']['censoruser'] = trim($_G['setting']['censoruser']), '/')) . ')$/i';
    if(@preg_match($censorexp, $NickName)) {
		if($WxApp){
			echo Fn_WeChatServer::getXml4Txt(lang('message', 'profile_username_protect'));
            exit;
        }else{
            showmessage('profile_username_protect');
        }
    }
	/* �Զ�ע����֤ End */
	/* �Ƿ����ע����� */
	if(!$FnWxLogin->Config['PluginVar']['IgnoreRule']) {
		loadcache('ipctrl');
        if($_G['cache']['ipctrl']['ipregctrl']){
            foreach (explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
                if (preg_match("/^(" . preg_quote($ctrlip = trim($ctrlip), '/') . ")/", $_G['clientip'])) {
                    $ctrlip = $ctrlip . '%';
                    $_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
                    break;
                } else {
                    $ctrlip = $_G['clientip'];
                }
            }
        }else{
            $ctrlip = $_G['clientip'];
        }
        if($_G['setting']['regctrl']){
            if (C::t('common_regip')->count_by_ip_dateline($ctrlip, $_G['timestamp'] - $_G['setting']['regctrl'] * 3600)) {
                if($WxApp) {
                    echo Fn_WeChatServer::getXml4Txt(lang('message', 'register_ctrl', array('regctrl' => $_G['setting']['regctrl'])));
                    exit;
                }else{
					showmessage('register_ctrl', null, array('regctrl' => $_G['setting']['regctrl']));
                }
            }
        }
        $setregip = null;
        if($_G['setting']['regfloodctrl']){
            $regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp'] - 86400);
            if($regip) {
                if($regip['count'] >= $_G['setting']['regfloodctrl']) {
                    if($WxApp) {
                        echo Fn_WeChatServer::getXml4Txt(lang('message', 'register_flood_ctrl', array('regfloodctrl' => $_G['setting']['regfloodctrl'])));
                        exit;
                    }else{
						showmessage('register_flood_ctrl', null, array('regfloodctrl' => $_G['setting']['regfloodctrl']));
                    }
                }else{
                    $setregip = 1;
                }
            }else{
                $setregip = 2;
            }
        }
        if($setregip !== null){
            if($setregip == 1){
                C::t('common_regip')->update_count_by_ip($_G['clientip']);
            }else{
                C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => 1, 'dateline' => $_G['timestamp']));
            }
        }
	}
	/* �Ƿ����ע����� End */
	$Uid = uc_user_register(addslashes($NickName),$PassWord,$Email, '', '', $_G['clientip']);
	if($Uid <= 0){
		if($WxApp){
			if($Uid == -1){
                echo Fn_WeChatServer::getXml4Txt(lang('message', 'profile_username_illegal'));
            }else if($Uid == -2){
                echo Fn_WeChatServer::getXml4Txt(lang('message', 'profile_username_protect'));
            }else if($Uid == -3){
                echo Fn_WeChatServer::getXml4Txt(lang('message', 'profile_username_duplicate'));
            }else if($Uid == -4){
                echo Fn_WeChatServer::getXml4Txt(lang('message', 'profile_email_illegal'));
            }else if($Uid == -5){
                echo Fn_WeChatServer::getXml4Txt(lang('message', 'profile_email_domain_illegal'));
            }else if($Uid == -6){
                echo Fn_WeChatServer::getXml4Txt(lang('message', 'profile_email_duplicate'));
            }else{
                echo Fn_WeChatServer::getXml4Txt(lang('message', 'undefined_action'));
            }
            exit;
		}else{
			if($Uid == -1){
                showmessage('profile_username_illegal');
            }else if($Uid == -2){
                showmessage('profile_username_protect');
            }else if($Uid == -3){
                showmessage('profile_username_duplicate');
            }else if($Uid == -4){
                showmessage('profile_email_illegal');
            }else if($Uid == -5){
                showmessage('profile_email_domain_illegal');
            }else if($Uid == -6){
                showmessage('profile_email_duplicate');
            }else{
                showmessage('undefined_action');
            }
		}
	}
	$InitArr = array('credits' => explode(',', $_G['setting']['initcredits']), 'profile' => array('gender' => $Sex));
	C::t('common_member')->insert($Uid,$NickName,$PassWord,$Email,$_G['clientip'],$GroupId, $InitArr);
	if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']){
        C::t('common_regip')->delete_by_dateline($_G['timestamp'] - ($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72) * 3600);
        if($_G['setting']['regctrl']){
            C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
        }
    }
    if($_G['setting']['regverify'] == 2){
        C::t('common_member_validate')->insert(array('uid' => $Uid, 'submitdate' => $_G['timestamp'], 'moddate' => 0, 'admin' => '', 'submittimes' => 1, 'status' => 0, 'message' => '', 'remark' => ''), false, true);
        manage_addnotify('verifyuser');
    }
	setloginstatus(array('uid' => $Uid, 'username' => $NickName, 'password' => $PassWord, 'groupid' => $GroupId), 0);
    include_once libfile('function/stat');
    updatestat('register');
	return $Uid;
}

function SetOauthCookie($UserInfo, $AccessToken){
    global $_G;
    dsetcookie('wxoauth', authcode($UserInfo['openid'] . "\t" . $UserInfo['unionid'] . "\t" . $_G['uid'] . "\t" . dhtmlspecialchars($UserInfo['nickname'] ?  diconv($UserInfo['nickname'], 'utf-8', CHARSET) : '') . "\t" . $UserInfo['headimgurl'] . "\t" . TIMESTAMP, 'ENCODE'), 7200, 1, true);
    dsetcookie('wxtoken', authcode($AccessToken['access_token'] . "\t" . $AccessToken['refresh_token'], 'ENCODE'), 7200, 1, true);
}

//��Ȩ��¼
function BindLogin($BindMember){
    global $_G;
    if(!($Member = getuserbyuid($BindMember['uid'],1))) {
        return false;
    }
    require_once libfile('function/member');
    $CookieTime = 1296000;
    setloginstatus($Member, $CookieTime);
    C::t('common_member_status')->update($BindMember['uid'], array('lastip' => $_G['clientip'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));
    return true;
}

//��ǰUrl
function GetUrl(){
    $SysProtocal = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') || (isset($_SERVER['HTTP_X_CLIENT_SCHEME']) && $_SERVER['HTTP_X_CLIENT_SCHEME'] == 'https')) ? 'https://' : 'http://';
    $PhpSelf = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
    $PathInfo = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
    $RelateUrl = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $PhpSelf.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $PathInfo);
    return $SysProtocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$RelateUrl;
}
//����App And С��App And ǧ��
function CheckBindBemberApp($Unionid){
	global $FnWxLogin,$_G;
	$BindMember = $FnWxLogin->BindUserFetchByUnionid($Unionid);
	if($FnWxLogin->Config['PluginVar']['App'] == 'mag'){//����App
		$MagBindMemberTo = $FnWxLogin->UserWeixinRelationsFetchByUnionid($Unionid);
		if($MagBindMemberTo && !$BindMember){
			$MemberProfile = DB::fetch_first("SELECT gender FROM %t WHERE uid = %s", array('common_member_profile', $MagBindMemberTo['uid']));
			$InsData = array('openid' => '', 'uid' => $MagBindMemberTo['userid'], 'username' => '', 'nickname' => '', 'sex' => $MemberProfile[gender], 'dateline' => TIMESTAMP, 'unionid' => $MagBindMemberTo['unionid'], 'lastauth' => TIMESTAMP, 'counts' => 1, 'subscribe' => 0);
			if(DB::insert($FnWxLogin->TableBindUser,$InsData)){
				$ReturnBindMember = $FnWxLogin->BindUserFetchByUnionid($Unionid);
			}
		}
		if(!$MagBindMemberTo && $BindMember){
			$InsData = array('userid' => $BindMember['uid'],'name' => $BindMember['nickname'], 'openid' => $BindMember['openid'], 'unionid' => $BindMember['unionid'],'create_time'=>time());
			if(DB::insert($FnWxLogin->TableUserWeixinRelations,$InsData)){
				$ReturnBindMember = $BindMember;
			}
		}
		if($MagBindMemberTo && $BindMember){
			$ReturnBindMember = $BindMember;
		}
	}else if($FnWxLogin->Config['PluginVar']['App'] == 'qf'){//ǧ��
		$QfBindMemberTo = $FnWxLogin->ThirdbindFetchByUnionid($Unionid);
		if($QfBindMemberTo && !$BindMember){
			$MemberProfile = DB::fetch_first("SELECT gender FROM %t WHERE uid = %s", array('common_member_profile', $QfBindMemberTo['uid']));
			$InsData = array('openid' => '', 'uid' => $QfBindMemberTo['uid'], 'username' => '', 'nickname' => '', 'sex' => $MemberProfile[gender], 'dateline' => TIMESTAMP, 'unionid' => $QfBindMemberTo['unionid'], 'lastauth' => TIMESTAMP, 'counts' => 1, 'subscribe' => 0);
			if(DB::insert($FnWxLogin->TableBindUser,$InsData)){
				$ReturnBindMember = $FnWxLogin->BindUserFetchByUnionid($Unionid);
			}
		}
		if(!$QfBindMemberTo && $BindMember){
			$InsData = array('uid' => $BindMember['uid'], 'weibotype' => 'wechat', 'nickname' => $BindMember['nickname'], 'openid' => $BindMember['openid'], 'unionid' => $BindMember['unionid'],'dateline'=>time());
			if(DB::insert($FnWxLogin->TableThirdbind,$InsData)){
				$ReturnBindMember = $BindMember;
			}
		}
		if($QfBindMemberTo && $BindMember){
			$ReturnBindMember = $BindMember;
		}
	}else if($FnWxLogin->Config['PluginVar']['App'] == 'appbyme'){//С��App
		$AppbymeBindMemberTo = $FnWxLogin->AppbymeConnectionFetchByUnionid($Unionid);
		if($AppbymeBindMemberTo && !$BindMember){
			$MemberProfile = DB::fetch_first("SELECT gender FROM %t WHERE uid = %s", array('common_member_profile', $AppbymeBindMemberTo['uid']));
			$InsData = array('openid' => '', 'uid' => $AppbymeBindMemberTo['uid'], 'username' => '', 'nickname' => '', 'sex' => $MemberProfile[gender], 'dateline' => TIMESTAMP, 'unionid' => $AppbymeBindMemberTo['param'], 'lastauth' => TIMESTAMP, 'counts' => 1, 'subscribe' => 0);
			if(DB::insert($FnWxLogin->TableBindUser,$InsData)){
				$ReturnBindMember = $FnWxLogin->BindUserFetchByUnionid($Unionid);
			}
		}

		if(!$AppbymeBindMemberTo && $BindMember){
			$InsData = array('uid' => $BindMember['uid'], 'openid' => '', 'status' => '1', 'type' => '1', 'param' => $BindMember['unionid']);
			if(DB::insert($FnWxLogin->TableAppbymeConnection,$InsData)){
				$ReturnBindMember = $BindMember;
			}
		}
		
		if($AppbymeBindMemberTo && $BindMember){
			$ReturnBindMember = $BindMember;
		}
	}else{
		$ReturnBindMember = $BindMember;
	}
	return $ReturnBindMember;
}
/* ����ת�� */
function StrToGBK($string,$ajax_status=null){
	global $_G;
	if($_G['charset'] == 'gbk'){
		if($ajax_status == true){
			if(is_array($string)){
				return eval('return '.iconv("GB2312","UTF-8//IGNORE",var_export($string,true).';')); 
			}else{
				return iconv('GB2312', 'UTF-8', $string);
			}
		}else{
			if(is_array($string)){
				$StringArr = array();
				foreach($string as $key=>$value){
					$encode = mb_detect_encoding($value, array('UTF-8','GB2312','GBK'));
					if($encode == 'UTF-8'){
						$StringArr[$key] = iconv('UTF-8','GB2312//IGNORE',$value);
					}else if($encode == 'EUC-CN'){
						$StringArr[$key] = $value;
					}
				}
				return $StringArr;
			}else{
				$encode = mb_detect_encoding($string, array('UTF-8','GB2312','GBK'));
				if($encode == 'UTF-8'){
					return iconv('UTF-8','GB2312//IGNORE', $string);
				}else if($encode == 'EUC-CN'){
					return $string;
				}
			}
		}
	}else{
		return $string;
	}    
}
function Match412(array $Match) {
        return strlen($Match[0]) >= 4 ? '' : $Match[0];
}

function FilterEmoji($Str){
	$Str = preg_replace_callback( '/./u', 'Match412', $Str);
	$Str = diconv($Str, 'utf-8', 'gbk');
	$Str = diconv($Str, 'gbk', 'utf-8');
	$Str = SafeReplace($Str);
	return $Str;
}

function SafeReplace($String){
	$String = str_replace('%20','',$String);
	$String = str_replace('%27','',$String);
	$String = str_replace('%2527','',$String);
	$String = str_replace('*','',$String);
	$String = str_replace('"','&quot;',$String);
	$String = str_replace("'",'',$String);
	$String = str_replace('"','',$String);
	$String = str_replace(';','',$String);
	$String = str_replace('<','&lt;',$String);
	$String = str_replace('>','&gt;',$String);
	$String = str_replace("{",'',$String);
	$String = str_replace('}','',$String);
	$String = str_replace('\\','',$String);
	return $String;
}
//From: Dism��taobao��com
?>