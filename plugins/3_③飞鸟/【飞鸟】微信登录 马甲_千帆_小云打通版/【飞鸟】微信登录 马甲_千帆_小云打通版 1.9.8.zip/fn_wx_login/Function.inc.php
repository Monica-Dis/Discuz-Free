<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class FnWxLogin{
	public function __construct() {
		global $_G,$plugin;
		loadcache('plugin');
		$this->Config[PluginVar] = (array) $_G['cache']['plugin']['fn_wx_login'];
		$this->Config[LangVar] = lang('plugin/fn_wx_login');
		$this->Config[Path] = 'source/plugin/fn_wx_login';
		$this->Config[StaticPath] = $this->Config[Path].'/static';
		$this->TableAuthCode = 'fn_wx_login_authcode';
		$this->TableBindUser = 'fn_wx_login_binduser';
		$this->TableAppbymeConnection = 'appbyme_connection';
		$this->TableThirdbind = 'thirdbind';
		$this->TableUserWeixinRelations = 'user_weixin_relations';
	}
	
	public function AuthCodeFetchByCode($Code){
		return DB::fetch_first("SELECT * FROM %t WHERE code = %s", array($this->TableAuthCode, $Code));
	}
	
	public function AuthCodeDeletebyField($Field,$Value){
		return DB::delete($this->TableAuthCode, DB::field($Field,$Value));
	}
	
	public function BindUserFetchByid($Id){
		return DB::fetch_first("SELECT * FROM %t WHERE id = %s", array($this->TableBindUser, $Id));
	}

	public function BindUserFetchByUid($Uid){
		return DB::fetch_first("SELECT * FROM %t WHERE uid = %s", array($this->TableBindUser, $Uid));
	}
	
	public function BindUserFetchByUnionid($Unionid){
		return DB::fetch_first("SELECT * FROM %t WHERE unionid = %s", array($this->TableBindUser, $Unionid));
	}

	public function BindUserFetchByOpenid($Openid){
		return DB::fetch_first("SELECT * FROM %t WHERE openid = %s", array($this->TableBindUser, $Openid));
	}
	
	public function BindUserDeletebyField($Field,$Value){
		return DB::delete($this->TableBindUser, DB::field($Field,$Value));
	}

	public function AppbymeConnectionFetchByUnionid($Unionid){
		return DB::fetch_first("SELECT * FROM %t WHERE param = %s", array($this->TableAppbymeConnection, $Unionid));
	}

	public function AppbymeConnectionDeletebyField($Field,$Value){
		return DB::delete($this->TableAppbymeConnection, DB::field($Field,$Value));
	}

	public function ThirdbindFetchByUnionid($Unionid){
		return DB::fetch_first("SELECT * FROM %t WHERE unionid = %s", array($this->TableThirdbind, $Unionid));
	}

	public function ThirdbindDeletebyField($Field,$Value){
		return DB::delete($this->TableThirdbind, DB::field($Field,$Value));
	}

	public function UserWeixinRelationsFetchByUnionid($Unionid){
		return DB::fetch_first("SELECT * FROM %t WHERE unionid = %s", array($this->TableUserWeixinRelations, $Unionid));
	}

	public function UserWeixinRelationsDeletebyField($Field,$Value){
		return DB::delete($this->TableUserWeixinRelations, DB::field($Field,$Value));
	}
}
//From: Dism��taobao��com
?>