<?php
/**
 *	[������΢�ŵ�¼(fn_wx_login.{modulename})] ���²����http://t.cn/Aiux1Jx1
 *	Version: 1.0
 *	Date: 2017-8-3 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_wx_login/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_wx_login/Common.inc.php');
if(checkmobile()){
	$navtitle = $metakeywords = $metadescription = $FnWxLogin->Config['LangVar']['FollowTitle'];
	$Referer = $_GET['referer'] ? urldecode($_GET['referer']) : $_G['siteurl'];
	include template("fn_wx_login:follow");
}else{
	dheader('Location:'.$_G['siteurl']);
}
//From: Dism��taobao��com
?>