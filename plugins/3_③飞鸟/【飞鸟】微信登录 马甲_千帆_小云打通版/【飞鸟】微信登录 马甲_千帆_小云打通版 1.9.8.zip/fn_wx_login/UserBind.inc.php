<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, [DisM!] (C)2001-2099 DisM Inc.
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once(DISCUZ_ROOT .'./source/plugin/fn_wx_login/Function.inc.php');
require_once(DISCUZ_ROOT .'./source/plugin/fn_wx_login/Common.inc.php');
if($BindUser = $FnWxLogin->BindUserFetchByUid($_G[uid])){
	$_G['member']['openid']    = $BindUser['openid'];
	$_G['member']['unionid']   = $BindUser['unionid'];
	$_G['member']['subscribe'] = $BindUser['subscribe'] == 1 ? 1 : 0;
};
$Url = "home.php?mod=spacecp&ac=plugin&id=fn_wx_login:UserBind";
if(submitcheck("UnBindSubmit")){//解除绑定
	if($BindUser[openid]){
		$FnWxLogin->AuthCodeDeletebyField('openid',$BindUser[openid]);
	}else if($BindUser[unionid]){
		$FnWxLogin->AuthCodeDeletebyField('unionid',$BindUser[unionid]);
	}
	/* 马甲 And 小云App And 千帆App*/
	if($FnWxLogin->Config[PluginVar][App] == 'mag'){//马甲App
		$FnWxLogin->UserWeixinRelationsDeletebyField('userid',$_G[uid]);
	}else if($FnWxLogin->Config[PluginVar][App] == 'qf'){//千帆App
		$FnWxLogin->ThirdbindDeletebyField('uid',$_G[uid]);

	}else if($FnWxLogin->Config[PluginVar][App] == 'appbyme'){//小云App
		$FnWxLogin->AppbymeConnectionDeletebyField('uid',$_G[uid]);
	}
	/* 马甲 And 小云App And 千帆App*/
	$FnWxLogin->BindUserDeletebyField('uid',$_G[uid]);
	showmessage($FnWxLogin->Config[LangVar][CancelAccountSuccess], $Url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));
}else if(submitcheck("EditBindSubmit")){//修改用户名 And 密码 And 邮箱
	if($FnWxLogin->Config[PluginVar][UserNameSwitch]){
		$UpData[username] = addslashes(strip_tags($_GET['username']));
		if($UpData[username] != $_G[member][username]){
			if(C::t('common_member')->fetch_uid_by_username($UpData['username']) || C::t('common_member_archive')->fetch_uid_by_username($UpData['username'])) {
				showmessage($FnWxLogin->Config[LangVar][UserAlreadyExistsErr], $Url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));
			}
		}
	}
	$UpData['password'] = addslashes(strip_tags($_GET['password']));
	$UpData['email'] = addslashes(trim(strip_tags($_GET['email'])));
	if(!$UpData['password']){
		showmessage($FnWxLogin->Config[LangVar][PleasePasswordErr], $Url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));
	}

	if($UpData['password'] != addslashes(strip_tags($_GET['password1']))){
		showmessage($FnWxLogin->Config[LangVar][TwoPasswordErr], $Url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));
	}
	
	$CheckEmail = C::t('common_member')->fetch_by_email($UpData[email]);
	
	if($CheckEmail && $_G['uid'] != $CheckEmail['uid']){
		showmessage($FnWxLogin->Config[LangVar][MailboxRegisteredErr], $Url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));
	}
	if($UpData[email] != $_G[member][email]) {
		include_once libfile('function/member');
		checkemail($UpData['email']);
	}

	loaducenter();
	//修改密码
	$UcResult = uc_user_edit(addslashes($_G['username']),$UpData['password'],$UpData['password'],$UpData[email], 1,'');
	if($UcResult < 0) {
        if($UcResult == -4) {
            showmessage($FnWxLogin->Config[LangVar][MailboxIncorrect], $Url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3)); 
        }else if($UcResult == -5){
			showmessage($FnWxLogin->Config[LangVar][MailboxIncorrect], $Url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3)); 
        }else if($UcResult == -6){
			showmessage($FnWxLogin->Config[LangVar][MailboxRegisteredErr], $Url, array(), array('alert' => 'right', 'showdialog' => 1, 'locationtime' => 3));
        }
    }
	//修改邮箱
	if($UpData[email] != $_G[member][email]) {
		emailcheck_send($_G[uid], $UpData[email]);
		dsetcookie('newemail', "$_G[uid]\t$UpData[email]\t$_G[timestamp]", 31536000);
	}
	//修改用户名
	if($FnWxLogin->Config[PluginVar][UserNameSwitch] && $UpData[username] != $_G[member][username]){
		global $uc_controls;
        DB::query('UPDATE %t SET username = %s WHERE username = %s', array('common_member', $UpData[username], $_G['username']));
        $uc_controls['user']->db->query("UPDATE " . UC_DBTABLEPRE . "members SET username='$UpData[username]' WHERE username='{$_G[username]}'");
        C::t('common_member')->update_cache($_G['uid'], array('username' => $UpData[username]));
	}
	$BindUserUpData = array('status'=>1);
	DB::update($FnWxLogin->TableBindUser,$BindUserUpData,'uid = '.$_G['uid']);
	showmessage($FnWxLogin->Config[LangVar][EditOk],$Url);
}
//From: Dism·taobao·com
?>