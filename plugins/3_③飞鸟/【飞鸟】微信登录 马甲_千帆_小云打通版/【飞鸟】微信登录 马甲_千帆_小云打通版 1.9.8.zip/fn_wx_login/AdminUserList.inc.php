<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_wx_login/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_wx_login/Common.inc.php');
$Operation = in_array($_GET[Operation], array('Del')) ? $_GET[Operation] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
if($Operation == 'List'){//�û��б�
	if(!submitcheck('WxSubmit')) {
		/* ���� */
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>Uid</th><td><input type="text" class="txt" name="uid" value="{$_GET[uid]}" size="5"></td>
						<th>{$FnWxLogin->Config[LangVar][UserNameTitle]}</th><td><input type="text" class="txt" name="username" value="{$_GET[username]}" size="10"></td>
						<th>{$FnWxLogin->Config[LangVar][WxNameTitle]}</th><td><input type="text" class="txt" name="nickname" value="{$_GET[nickname]}" size="10"></td>
						<th>openid/unionid</th><td><input type="text" class="txt" name="ouid" value="{$_GET[ouid]}">&nbsp;&nbsp;<input name="SearchSubmit" value="{$FnWxLogin->Config[LangVar][SearchSubmit]}" class="btn" type="submit"></td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		if($_GET[order]){
			$Order = 'B.'.dhtmlspecialchars($_GET[order]);
		}else{
			$Order = 'B.id';
		}
		if($_GET[uid]){
			$Where .= ' and B.uid = '.intval($_GET[uid]);
		}
		if($_GET[username]){
			$Where .= ' and concat(B.username) like(\'%'.dhtmlspecialchars($_GET[username]).'%\')';
		}
		if($_GET[nickname]){
			$Where .= ' and concat(B.nickname) like(\'%'.dhtmlspecialchars($_GET[nickname]).'%\')';
		}
		if($_GET[ouid]){
			$Where .= ' and concat(B.openid,B.unionid) like(\'%'.dhtmlspecialchars($_GET[ouid]).'%\')';
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		$TdStyle = array('width="15"', 'width="130"', 'width="130"','width="40"','width="130"','width="60"','width="120"','120');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'UserModule', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($FnWxLogin->Config[LangVar][InfoListTitle]);
		showsubtitle(array(
            'UID',
			$FnWxLogin->Config[LangVar][UserNameTitle],
			$FnWxLogin->Config[LangVar][WxNameTitle],
			$FnWxLogin->Config[LangVar][SexTitle],
			$FnWxLogin->Config[LangVar][LastLoginTitle],
			$FnWxLogin->Config[LangVar][LoginCountTitle],
			'OpenId',
			'UnionId',
			$FnWxLogin->Config[LangVar][OpTitle]
		), 'header tbm',$TdStyle);
		$UserList = GetModulesUserList($Page,$Limit,$Where,$Order);
		$OpUserCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($UserList as $Module) {
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				$Module[uid],
				$Module[username],
				$Module[nickname],
				$FnWxLogin->Config[LangVar][Sex][$Module[sex]],
				date("y-m-d H:i:s",$Module['lastauth']),
				$Module[counts],
				$Module[openid],
				$Module[unionid],
				'[<a href="'.ADMINSCRIPT.'?action=members&operation=edit&uid='.$Module[uid].'">'.$FnWxLogin->Config[LangVar][DetailsTitle].'</a>]&nbsp;&nbsp;[<a href="'.ADMINSCRIPT.'?action=members&operation=ban&uid='.$Module[uid].'">'.$FnWxLogin->Config[LangVar][ProhibitTitle].'</a>]&nbsp;&nbsp;[<a href="'.$OpUserCpUrl.'&Operation=Del&bid='.$Module['id'].'&formhash='.FORMHASH.'">'.$FnWxLogin->Config[LangVar][RelieveTitle].'</a>]'
			));
		}
		showsubmit('','','','',multi(GetModulesUserCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter();/*dis'.'m.tao'.'bao.com*/
		showformfooter();
		showtagfooter('div');
		/* ģ����� End */
	}
}else if($Operation == 'Del' && $_GET[formhash] == formhash() && $_GET[bid]){
	$Bid = intval($_GET[bid]);
	$BindInfo = $FnWxLogin->BindUserFetchByid($Bid);
	if($BindInfo){
		if($BindInfo[openid]){
			$FnWxLogin->AuthCodeDeletebyField('openid',$BindInfo[openid]);
		}else if($BindInfo[unionid]){
			$FnWxLogin->AuthCodeDeletebyField('unionid',$BindInfo[unionid]);
		}
		/* ���� And С��App And ǧ��App */
		if($FnWxLogin->Config[PluginVar][App] == 'mag'){//����App
			$FnWxLogin->UserWeixinRelationsDeletebyField('userid',$BindInfo[uid]);
		}else if($FnWxLogin->Config[PluginVar][App] == 'qf'){//ǧ��App
			$FnWxLogin->ThirdbindDeletebyField('uid',$BindInfo[uid]);
		}else if($FnWxLogin->Config[PluginVar][App] == 'appbyme'){//С��App
			$FnWxLogin->AppbymeConnectionDeletebyField('uid',$BindInfo[uid]);
		}
		/* ���� And С��App And ǧ��App */
		$FnWxLogin->BindUserDeletebyField('id',$BindInfo[id]);

		cpmsg($FnWxLogin->Config[LangVar][RelieveOk],$CpMsgUrl,'succeed');
	}else{
		cpmsg($FnWxLogin->Config[LangVar][RelieveErr],'','error');
	}
}
/* �û��б� */
function GetModulesUserList($Page,$Limit,$Where,$Order){
	global $FnWxLogin;
	$FetchSql = 'SELECT B.* FROM '.DB::table($FnWxLogin->TableBindUser).' B '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1)*$Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ��Ƶ���� */
function GetModulesUserCount($Where){
	global $FnWxLogin;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($FnWxLogin->TableBindUser).' B '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>