<?php
/**
 *	[������Ҫ��ʲô(fn_eat.{modulename})] (C)2016-2099 Powered by ��������.
 *	Version: 1.0
 *	Date: 2018-3-4 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_eat/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_eat/Common.php');

/* ���Զ�ά����� */
if(!checkmobile()){
	$navtitle = $metakeywords = $metadescription = $Fn_Eat->Config['PluginVar']['Title'];
	$PcUrl = $_G['siteurl'].'plugin.php?id=fn_eat';
	$QrSize = 5;
	$Dir = 'data/cache/qrcode/';//�洢·��
	$File = $Dir.'fn_eat.jpg';
	if(!file_exists($File) || !filesize($File)) {
		dmkdir($Dir);
		require_once DISCUZ_ROOT.'source/plugin/fn_eat/qrcode.class.php';
		QRcode::png($PcUrl, $File, QR_ECLEVEL_L, $QrSize);
	}
	$QrCode = base64_encode(file_get_contents($File));
	unlink($File);
	
	include template('fn_eat:index_qrcode');
	exit();
}
/* ���Զ�ά����� End */

if($WxApp){//΢�ŷ���
	$Fn_Eat->Config['SignPackage'] = $Fn_Eat->WeixinGetSignPackage();
}

if($Fn_Eat->Config['PluginVar']['AppSwitch'] && !$MagApp && !$QFApp && !$Appbyme && $Fn_Eat->Config['PluginVar']['AppLink']){//App��
	$AppSwitch = true;
}

$_GET['m'] = $_GET['m'] ? $_GET['m'] : 'index';
if($_GET['m'] == 'index'){//��ҳ
	$navtitle = $metakeywords = $metadescription = $Fn_Eat->Config['PluginVar']['Title'];
	$FoodMenu = array();
	if($Fn_Eat->Config['PluginVar']['TotalFoodMenu']){
		$FoodMenu = array_filter(explode("\n",str_replace("\r","",$Fn_Eat->Config['PluginVar']['TotalFoodMenu'])));
	}else{
		if(time() < strtotime(date('Y-m-d 10:00:00')) && time() > strtotime(date('Y-m-d 06:00:00'))){//���
			$FoodMenu = array_filter(explode("\n",str_replace("\r","",$Fn_Eat->Config['PluginVar']['MorningFoodMenu'])));
			$Text = $Fn_Eat->Config['LangVar']['Morning'];
		}else if(time() > strtotime(date('Y-m-d 10:00:00')) && time() < strtotime(date('Y-m-d 21:00:00'))){//������
			$FoodMenu = array_filter(explode("\n",str_replace("\r","",$Fn_Eat->Config['PluginVar']['NoonEveningFoodMenu'])));
			if(time() < strtotime(date('Y-m-d 15:00:00'))){
				$Text = $Fn_Eat->Config['LangVar']['Noon'];
			}else{
				$Text = $Fn_Eat->Config['LangVar']['Afternoon'];
			}
		}else{//��ҹ
			$FoodMenu = array_filter(explode("\n",str_replace("\r","",$Fn_Eat->Config['PluginVar']['NightEveningFoodMenu'])));
			$Text = $Fn_Eat->Config['LangVar']['NightEvening'];
			$NightEveningPromptArray = array_filter(explode("\n",str_replace("\r","",$Fn_Eat->Config['PluginVar']['NightEveningPrompt'])));
			$NightEveningPrompt = $NightEveningPromptArray ? $NightEveningPromptArray[rand(0,count($NightEveningPromptArray)-1)] : '';
			$NightEvening = true;
		}
	}
	foreach($Fn_Eat->Config['LangVar']['FixedTitle'] as $Key => $Val) {
		$Fn_Eat->Config['LangVar']['FixedTitle'][$Key] = str_replace(array('{Text}'),array($Text),$Val);
	}
	foreach ($FoodMenu as $Key => $Val) {
		$FoodMenuJs[] = '"'.$Val.'"';
	}
	$FoodMenuJs = '['.implode(',',$FoodMenuJs).']';
	
	//��ť����
	$Member = DB::fetch_first('SELECT P.gender FROM '.DB::table('common_member').' M LEFT JOIN '.DB::table('common_member_profile').' P on P.uid = M.uid  where M.uid = '.intval($_G['uid']));
	if($Member['gender'] && $Fn_Eat->Config['PluginVar']['BtnSex'.$Member['gender']]){
		$BtnSexArray = array_filter(explode("\n",str_replace("\r","",$Fn_Eat->Config['PluginVar']['BtnSex'.$Member['gender']])));
	}else{
		$BtnSexArray = array_filter(explode("\n",str_replace("\r","",$Fn_Eat->Config['PluginVar']['BtnSex'])));
	}
	$Fn_Eat->Config['LangVar']['FixedBtn'][2] = $BtnSexArray ? $BtnSexArray[rand(0,count($BtnSexArray)-1)] : $Fn_Eat->Config['LangVar']['FixedBtn'][2];


}else{
	exit('No Data');
}
include template('fn_eat:'.$_GET['m']);
?>