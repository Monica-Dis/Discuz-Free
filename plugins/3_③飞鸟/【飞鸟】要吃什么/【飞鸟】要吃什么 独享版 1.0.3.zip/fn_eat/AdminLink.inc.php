<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_eat/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_eat/Common.php');
showtableheader();/*DisM-Taobao_Com*/
showsetting($Fn_Eat->Config['LangVar']['PluginLink'], 'PluginLink',$_G['siteurl'].'plugin.php?id=fn_eat', 'text');
showtablefooter();/*Dism��taobao��com*/
?>