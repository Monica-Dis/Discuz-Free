<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_wallet/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_wallet/Common.php');
$Operation = in_array($_GET['Operation'], array('Del','OpValue')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ���� */
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		$StateSelected = array($_GET['state']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Wallet->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}"></td>
						<th>{$Fn_Wallet->Config['LangVar']['StateTitle']}</th>
						<td>
						<select name="state">
							<option value="">{$Fn_Wallet->Config['LangVar']['SelectNull']}</option>
							<option value="0"{$StateSelected['0']}>{$Fn_Wallet->Config['LangVar']['AdminWithdrawalsState']['0']}</option>
							<option value="1"{$StateSelected['1']}>{$Fn_Wallet->Config['LangVar']['AdminWithdrawalsState']['1']}</option>
							<option value="2"{$StateSelected['2']}>{$Fn_Wallet->Config['LangVar']['AdminWithdrawalsState']['2']}</option>

						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Wallet->Config['LangVar']['SearchSubmit']}" class="btn" type="submit"></td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'L.id';
		if($_GET['keyword']){
			$Where .= ' and concat(L.username,L.uid,L.transaction_id,L.content) like(\'%'.addslashes(dhtmlspecialchars($_GET[keyword])).'%\')';
		}
		if($_GET['state'] === '0' || $_GET['state'] === '1' || $_GET['state'] === '2'){
			$Where .= ' and L.state = '.intval($_GET['state']);
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		if($Fn_Wallet->Config['PluginVar']['AutomaticSwitch']){//�Զ�����
			$TdStyle = array('width="30"', 'width="50"','width="70"','width="250"','width="200"','width="80"','width="80"','width="80"','width="130"');
			$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
			showtagheader('div', 'Module', true);
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader($Fn_Wallet->Config['LangVar']['InfoListTitle']);
			showsubtitle(array(
				'ID',
				'Uid',
				$Fn_Wallet->Config['LangVar']['UserNameTitle'],
				$Fn_Wallet->Config['LangVar']['WithdrawalsTransactionIdTitle'],
				$Fn_Wallet->Config['LangVar']['WalletContentTitle'],
				$Fn_Wallet->Config['LangVar']['WithdrawalsFeeTitle'],
				$Fn_Wallet->Config['LangVar']['MoneyTitle'],
				$Fn_Wallet->Config['LangVar']['StateTitle'],
				$Fn_Wallet->Config['LangVar']['TimeTitle'],
				$Fn_Wallet->Config['LangVar']['OperationTitle']
			), 'header tbm',$TdStyle);
		}else{//�ֶ�����
			$TdStyle = array('width="30"', 'width="50"','width="70"','width="80"','width="150"','width="150"','width="80"','width="80"','width="80"','width="130"');
			$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
			showtagheader('div', 'Module', true);
			showformheader($FormUrl,'enctype="multipart/form-data"');
			showtableheader($Fn_Wallet->Config['LangVar']['InfoListTitle']);
			showsubtitle(array(
				'ID',
				'Uid',
				$Fn_Wallet->Config['LangVar']['UserNameTitle'],
				$Fn_Wallet->Config['LangVar']['NameTitle'],
				$Fn_Wallet->Config['LangVar']['WalletAlipayTitle'],
				$Fn_Wallet->Config['LangVar']['WalletWxTitle'],
				$Fn_Wallet->Config['LangVar']['WithdrawalsFeeTitle'],
				$Fn_Wallet->Config['LangVar']['MoneyTitle'],
				$Fn_Wallet->Config['LangVar']['StateTitle'],
				$Fn_Wallet->Config['LangVar']['TimeTitle'],
				$Fn_Wallet->Config['LangVar']['OperationTitle']
			), 'header tbm',$TdStyle);
		}
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($ModulesList as $Module) {
			if($Module['state'] == '1'){
				$StateHtml = '<span style=color:#68ae20>'.$Fn_Wallet->Config['LangVar']['AdminWithdrawalsState'][$Module['state']].'</span>';
			}else if($Module['state'] == '2'){
				$StateHtml = '<span style=color:red>'.$Fn_Wallet->Config['LangVar']['AdminWithdrawalsState'][$Module['state']].'</span>';
			}else{
				$StateHtml = '<span style=color:#ff7916>'.$Fn_Wallet->Config['LangVar']['AdminWithdrawalsState'][$Module['state']].'</span>';
			}
			if($Fn_Wallet->Config['PluginVar']['AutomaticSwitch']){//�Զ�����
				$OpStateHtml = !$Module['state'] ? '<a href="'.$OpCpUrl.'&Operation=OpValue&lid='.$Module['id'].'&state=1&formhash='.FORMHASH.'">'.$Fn_Wallet->Config['LangVar']['ExamineTitle'].'</a>&nbsp;&nbsp;' : '';
				
				if($Fn_Wallet->Config['PluginVar']['AutomaticExamineSwitch']){
					$Checkbox = '<input type="checkbox" class="checkbox" name="ids[]" value="'.$Module['id'].'" />'.$Module['id'];
				}else{
					$Checkbox = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'];
				}
				showtablerow('', array('class="td25"', 'class="td28"'), array(
					$Checkbox,
					$Module['uid'],
					$Module['musername'],
					$Module['transaction_id'],
					$Module['content'],
					$Module['fee'],
					$Module['money'],
					$StateHtml,
					date('Y-m-d H:i',$Module['dateline']),
					$OpStateHtml.'<a href="'.$OpCpUrl.'&Operation=Del&lid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Wallet->Config['LangVar']['DelTitle'].'</a>'
				));
			}else{//�ֶ�����
				$OpStateHtml = !$Module['state'] ? '<a href="'.$OpCpUrl.'&Operation=OpValue&lid='.$Module['id'].'&state=1&formhash='.FORMHASH.'">'.$Fn_Wallet->Config['LangVar']['AdminWithdrawalsStateOp1'].'</a>&nbsp;&nbsp;' : '';
				showtablerow('', array('class="td25"', 'class="td28"'), array(
					'<input type="checkbox" class="checkbox" name="ids[]" value="'.$Module['id'].'" />'.$Module['id'],
					$Module['uid'],
					$Module['musername'],
					$Module['name'],
					$Module['alipay'],
					$Module['wx'],
					$Module['fee'],
					$Module['money'],
					$StateHtml,
					date('Y-m-d H:i',$Module['dateline']),
					$OpStateHtml.'<a href="'.$OpCpUrl.'&Operation=Del&lid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Wallet->Config['LangVar']['DelTitle'].'</a>'
				));
			}
		}
		if($Fn_Wallet->Config['PluginVar']['AutomaticSwitch'] && !$Fn_Wallet->Config['PluginVar']['AutomaticExamineSwitch']){//�Զ�����
				showsubmit('Submit','submit','del','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
		}else{
			$StateText = $Fn_Wallet->Config['PluginVar']['AutomaticSwitch'] && $Fn_Wallet->Config['PluginVar']['AutomaticExamineSwitch'] ? $Fn_Wallet->Config['LangVar']['ExamineTitle'] : $Fn_Wallet->Config['LangVar']['AdminWithdrawalsState']['1'];
			showsubmit('Submit','submit','<input name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" type="checkbox"><label for="chkall">'.$Fn_Wallet->Config['LangVar']['ChkAll'].'</label>&nbsp;&nbsp;<input name="optype" id="OptypeDel" value="Del" class="radio" type="radio"><label for="OptypeDel">'.$Fn_Wallet->Config['LangVar']['DelTitle'].'</label>&nbsp;&nbsp;<input name="optype" id="OptypeState" value="State" class="radio" type="radio"><label for="OptypeState">'.$Fn_Wallet->Config['LangVar']['StateTitle'].'</label>&nbsp;<select name="state"><option value="0">'.$Fn_Wallet->Config['LangVar']['SelectNull'].'</option><option value="1">'.$StateText.'</option></select>','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
		}
        showtablefooter();
		showformfooter();/*Dism_taobao_com*/
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if($Fn_Wallet->Config['PluginVar']['AutomaticSwitch'] && !$Fn_Wallet->Config['PluginVar']['AutomaticExamineSwitch']){//�Զ�����
			if(isset($_GET['delete']) && is_array($_GET['delete'])){
				foreach($_GET['delete'] as $Key => $Val) {
					$Val = intval($Val);
					DB::delete($Fn_Wallet->TableWalletWithdrawalsLog,'id ='.$Val);
				}
				cpmsg($Fn_Wallet->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
			}else{
				cpmsg($Fn_Wallet->Config['LangVar']['DelErr'],'','error');
			}
		}else{//�ֶ�����
			if(isset($_GET['ids']) && is_array($_GET['ids'])){
				foreach($_GET['ids'] as $Key => $Val) {
					$Val = intval($Val);
					$Log = $Fn_Wallet->QueryOne($Fn_Wallet->TableWalletWithdrawalsLog,$Val);
					if($_GET['optype'] == 'Del'){//ɾ��
						if(!$Log['state']){
							DB::query("UPDATE ".DB::table($Fn_Wallet->TableWallet)." SET money = money+".($Log['money']+$Log['fee'])." WHERE uid=".$Log['uid']);
						}
						DB::delete($Fn_Wallet->TableWalletWithdrawalsLog,'id ='.$Val);
					}else if($_GET['optype'] == 'State' && $_GET['state']){//����������
						$Data['state'] = intval($_GET['state']);
						if($Log && !$Log['state']){
							$LogData['uid'] = intval($Log['uid']);
							$LogData['content'] = addslashes(strip_tags($Fn_Wallet->Config['LangVar']['WithdrawalsContentTo']));
							$LogData['money'] = addslashes(strip_tags($Log['money'] + $Log['fee']));
							$LogData['type'] = 2;
							$LogData['plugin'] = addslashes(strip_tags('fn_wallet'));
							$LogData['dateline'] = time();
							if($Fn_Wallet->Config['PluginVar']['AutomaticExamineSwitch'] && $Fn_Wallet->Config['PluginVar']['AutomaticSwitch']){//�Զ������ֶ����
								$UserInfoTo = DB::fetch_first('SELECT M.username as musername,W.* FROM '.DB::table($Fn_Wallet->TableWallet).' W LEFT JOIN '.DB::table('common_member').' M on M.uid = W.uid WHERE W.uid = '.$Log['uid']);
								$FromXml = $Fn_Wallet->Params($Log['money'],$Fn_Wallet->Config['LangVar']['WithdrawalsContentTo'],$UserInfoTo['openid'],$Log['id']);
								$TradeNoId = reset(explode('fn',$FromXml['partner_trade_no']));
								if($FromXml['result_code'] == 'SUCCESS'){
									$Data['transaction_id'] = addslashes(strip_tags($FromXml['payment_no']));
									if(DB::update($Fn_Wallet->TableWalletWithdrawalsLog,$Data,'id = '.$Log['id'])){
										DB::insert($Fn_Wallet->TableWalletLog,$LogData);
									}
								}else{
									$Msg = diconv($FromXml['err_code_des'],'UTF-8',CHARSET);
									cpmsg($Msg,'','error');
								}
							}else{//�ֶ��������
								if(DB::update($Fn_Wallet->TableWalletWithdrawalsLog,$Data,'id = '.$Log['id'])){
									DB::insert($Fn_Wallet->TableWalletLog,$LogData);
								}
							}
						}
					}
				}
				if($_GET['optype'] == 'Del'){//ɾ��
					cpmsg($Fn_Wallet->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
				}else if($_GET['optype'] == 'State'){//����������
					cpmsg($Fn_Wallet->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
				}else{
					cpmsg($Fn_Wallet->Config['LangVar']['UpdateErr'],'','error');
				}
			}else{
				cpmsg($Fn_Wallet->Config['LangVar']['UpdateErr'],'','error');
			}
		}

	}
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['lid']){
	$Lid = intval($_GET['lid']);
	if(!$Fn_Wallet->Config['PluginVar']['AutomaticSwitch'] || ($Fn_Wallet->Config['PluginVar']['AutomaticSwitch'] && $Fn_Wallet->Config['PluginVar']['AutomaticExamineSwitch'])){
		$Log = $Fn_Wallet->QueryOne($Fn_Wallet->TableWalletWithdrawalsLog,$Lid);
		if(!$Log['state']){
			DB::query("UPDATE ".DB::table($Fn_Wallet->TableWallet)." SET money = money+".($Log['money']+$Log['fee'])." WHERE uid=".$Log['uid']);
		}
	}
	DB::delete($Fn_Wallet->TableWalletWithdrawalsLog,'id ='.$Lid);
	cpmsg($Fn_Wallet->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');

}else if($Operation == 'OpValue' && $_GET['formhash'] == formhash() && $_GET['lid'] && $_GET['state']){
	$Lid = intval($_GET['lid']);
	$Data['state'] = intval($_GET['state']);
	$Log = $Fn_Wallet->QueryOne($Fn_Wallet->TableWalletWithdrawalsLog,$Lid);
	if($Log){
		$LogData['uid'] = intval($Log['uid']);
		$LogData['content'] = addslashes(strip_tags($Fn_Wallet->Config['LangVar']['WithdrawalsContentTo']));
		$LogData['money'] = addslashes(strip_tags($Log['money'] + $Log['fee']));
		$LogData['type'] = 2;
		$LogData['plugin'] = addslashes(strip_tags('fn_wallet'));
		$LogData['dateline'] = time();
		if($Fn_Wallet->Config['PluginVar']['AutomaticExamineSwitch'] && $Fn_Wallet->Config['PluginVar']['AutomaticSwitch']){//�Զ������ֶ����
			$UserInfoTo = DB::fetch_first('SELECT M.username as musername,W.* FROM '.DB::table($Fn_Wallet->TableWallet).' W LEFT JOIN '.DB::table('common_member').' M on M.uid = W.uid WHERE W.uid = '.$Log['uid']);
			$FromXml = $Fn_Wallet->Params($Log['money'],$Fn_Wallet->Config['LangVar']['WithdrawalsContentTo'],$UserInfoTo['openid'],$Log['id']);
			$TradeNoId = reset(explode('fn',$FromXml['partner_trade_no']));
			if($FromXml['result_code'] == 'SUCCESS'){
				$Data['transaction_id'] = addslashes(strip_tags($FromXml['payment_no']));
				if(DB::update($Fn_Wallet->TableWalletWithdrawalsLog,$Data,'id = '.$Lid)){
					DB::insert($Fn_Wallet->TableWalletLog,$LogData);
					cpmsg($Fn_Wallet->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
				}else{
					cpmsg($Fn_Wallet->Config['LangVar']['UpdateErr'],'','error');
				}
			}else{
				$Msg = diconv($FromXml['err_code_des'],'UTF-8',CHARSET);
				cpmsg($Msg,'','error');
			}
		}else{
			if(DB::update($Fn_Wallet->TableWalletWithdrawalsLog,$Data,'id = '.$Lid)){
				DB::insert($Fn_Wallet->TableWalletLog,$LogData);
				cpmsg($Fn_Wallet->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
			}else{
				cpmsg($Fn_Wallet->Config['LangVar']['UpdateErr'],'','error');
			}
		}
	}else{
		cpmsg($Fn_Wallet->Config['LangVar']['UpdateErr'],'','error');
	}
}
/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Wallet;
	$FetchSql = 'SELECT W.name,W.wx,W.alipay,M.username as musername,L.* FROM '.DB::table($Fn_Wallet->TableWalletWithdrawalsLog).' L LEFT JOIN '.DB::table('common_member').' M on M.uid = L.uid LEFT JOIN '.DB::table($Fn_Wallet->TableWallet).' W on W.uid = L.uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ���� */
function GetModulesCount($Where){
	global $Fn_Wallet;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Wallet->TableWalletWithdrawalsLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>