<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_wallet/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_wallet/Common.php');
$Operation = in_array($_GET['Operation'], array('Del','Edit')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
$OpLogCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminWalletUserLogList';
$OpWithdrawalsLogCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminWalletUserWithdrawalsLog';
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ���� */
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		$EndTimeSelected = array($_GET['EndTime']=>' selected');
		$OrderSelected = array($_GET['order']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Wallet->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}">&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Wallet->Config['LangVar']['SearchSubmit']}" class="btn" type="submit"></td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'W.uid';
		if($_GET['keyword']){
			$Where .= ' and concat(W.username,W.uid) like(\'%'.addslashes(dhtmlspecialchars($_GET[keyword])).'%\')';
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		$TdStyle = array('width="80"', 'width="100"', 'width="80"', 'width="80"', 'width="100"','width="200"','width="200"','width="80"');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'Module', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_Wallet->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
            'Uid',
			$Fn_Wallet->Config['LangVar']['UserNameTitle'],
			$Fn_Wallet->Config['LangVar']['NameTitle'],
			$Fn_Wallet->Config['LangVar']['AlipayTitle'],
			$Fn_Wallet->Config['LangVar']['WxTitle'],
			'OpenId',
			'Unionid',
			$Fn_Wallet->Config['LangVar']['MoneyTitle'],
			$Fn_Wallet->Config['LangVar']['OperationTitle']
		), 'header tbm',$TdStyle);
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['uid'].'" />'.$Module['uid'],
				$Module['musername'],
				$Module['name'],
				$Module['alipay'],
				$Module['wx'],
				$Module['openid'],
				$Module['unionid'],
				$Module['money'],
				'<a href="'.$OpCpUrl.'&Operation=Edit&uid='.$Module['uid'].'">'.$Fn_Wallet->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpLogCpUrl.'&uid='.$Module['uid'].'">'.$Fn_Wallet->Config['LangVar']['IncomeExpenditureTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpWithdrawalsLogCpUrl.'&keyword='.$Module['musername'].'">'.$Fn_Wallet->Config['LangVar']['WithdrawalsLogTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&uid='.$Module['uid'].'&formhash='.FORMHASH.'">'.$Fn_Wallet->Config['LangVar']['DelTitle'].'</a>'
			));
		}
		showsubmit('Submit','submit','del','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter();
		showformfooter();/*Dism_taobao_com*/
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_Wallet->TableWallet,'uid ='.$Val);
				DB::delete($Fn_Wallet->TableWalletLog,'uid ='.$Val);
				DB::delete($Fn_Wallet->TableWalletWithdrawalsLog,'uid ='.$Val);
			}
			cpmsg($Fn_Wallet->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_Wallet->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['uid']){//ɾ��
	$Uid = intval($_GET['uid']);
	DB::delete($Fn_Wallet->TableWallet,'uid ='.$Uid);
	DB::delete($Fn_Wallet->TableWalletLog,'uid ='.$Uid);
	DB::delete($Fn_Wallet->TableWalletWithdrawalsLog,'uid ='.$Uid);
	cpmsg($Fn_Wallet->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'Edit'){
	$Uid = intval($_GET['uid']);
	$UserInfo = $Uid ? DB::fetch_first('SELECT * FROM '.DB::table($Fn_Wallet->TableWallet).' where uid = '.$Uid) : array();
	$Title = $Fn_Wallet->Config['LangVar']['EditTitle'];
	if($UserInfo){
		if(!submitcheck('DetailSubmit')) {
			$formUrl = ltrim(rawurldecode(cpurl()),'action=');
			showformheader($formUrl,'enctype');
			showtableheader();
			showtitle($Title);
			
			showsetting($Fn_Wallet->Config['LangVar']['NameTitle'], 'name', $UserInfo['name'], 'text');
			showsetting($Fn_Wallet->Config['LangVar']['AlipayTitle'], 'alipay', $UserInfo['alipay'], 'text');
			showsetting($Fn_Wallet->Config['LangVar']['WxTitle'], 'wx', $UserInfo['wx'], 'text');

			showtablefooter();
			showsubmit('DetailSubmit');
			showformfooter();/*Dism_taobao_com*/
		}else{
			$Data['name'] = addslashes(strip_tags($_GET['name']));
			$Data['alipay'] = addslashes(strip_tags($_GET['alipay']));
			$Data['wx'] = addslashes(strip_tags($_GET['wx']));
			DB::update($Fn_Wallet->TableWallet,$Data,'uid = '.$Uid);
			cpmsg($Fn_Wallet->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
		}
	}else{
		cpmsg($Fn_Wallet->Config['LangVar']['DelErr'],'','UpdateErr');
	}
}
/* ��Ƶ�б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Wallet;
	$FetchSql = 'SELECT M.username as musername,W.* FROM '.DB::table($Fn_Wallet->TableWallet).' W LEFT JOIN '.DB::table('common_member').' M on M.uid = W.uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ��Ƶ���� */
function GetModulesCount($Where){
	global $Fn_Wallet;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Wallet->TableWallet).' W '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>