<?php
/**
 *	[������Ǯ������(fn_wallet.{modulename})] (C)2016-2099 Powered by ��������.
 *	Version: 1.0
 *	Date: 2017-10-3 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_wallet/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_wallet/Common.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_wallet/wallet.class.php');
//����Ƿ��¼
if(!$_G['uid']){
	$Dreferer = $Fn_Wallet->Config['Url'];
	if($Appbyme){//С�Ƶ�¼
		exit('
			<script language="javascript" src="source/plugin/fn_wallet/static/js/appbyme.js"></script>
			<script>
			connectSQJavascriptBridge(function(bridge){
				sq.login(function(userInfo){
					if(userInfo.userId != 0){
						sq.logout(function(info){
							alert("'.$Fn_Wallet->Config['LangVar']['AppBymeErr'].'");
						});
					}else{
						window.location.reload(true);
					}
				});
			});
			</script>
		');
	}else if($MagApp){//���׵�¼
		exit('
			<script src="source/plugin/fn_wallet/static/js/mag.js"></script>
			<script>
				mag.toLogin(function(rs){
					window.location.reload(true);
				});
			</script>
		');
	}else if($QFApp){//ǧ����¼
		exit('
			<script>
			function QFH5ready(){
				QFH5.jumpLogin(function(state,data){
					if(state==1){
						QFH5.refresh(1);
					}else{
						alert(data.error);//data.error: string
					}
				});
			}
			</script>
		');
	}else{
		if(checkmobile()){
			header("HTTP/1.1 303 See Other");
			Header("Location: member.php?mod=logging&action=login"); 
		}else{
			showmessage('to_login', '', array(), array('showmsg' => true,'login' => 1));
			exit();
		}
	}
}else{
	FnWallet::WalletFetchByUid($_G['uid']);
	$UserInfo = $Fn_Wallet->GetUserInfo();
	if($WxApp && $UserInfo && !$UserInfo['openid'] && !$UserInfo['unionid'] && $Fn_Wallet->Config['PluginVar']['WxAppid']){
		if(strpos($Fn_Wallet->Config['PluginVar']['WxOauthDomain'],'oauth2.htm') !== false){
			$LoginUrl = $Fn_Wallet->Config['PluginVar']['WxOauthDomain'].'?appid='.$Fn_Wallet->Config['PluginVar']['WxAppid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.urlencode($_G['siteurl'].'/plugin.php?id=fn_wallet:OAuth');
		}else{
			$LoginUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$Fn_Wallet->Config['PluginVar']['WxAppid'].'&redirect_uri=' . urlencode($_G['siteurl'].'/plugin.php?id=fn_wallet:OAuth').'&response_type=code&scope=snsapi_userinfo&state='. md5(FORMHASH).'#wechat_redirect';
		}
		dheader('Location:'.$LoginUrl);
	}
}

$_GET['m'] = in_array($_GET['m'],array('index','withdrawals','balance','setup')) ? $_GET['m'] : 'index';
if($_GET['m'] == 'withdrawals'){
	
	$navtitle = $metakeywords = $metadescription = $Fn_Wallet->Config['LangVar']['WithdrawalsContent'];

	$Fn_Wallet->Config['LangVar']['Text5'] = str_replace('{num}',$Fn_Wallet->Config['PluginVar']['Proceduresfee'],$Fn_Wallet->Config['LangVar']['Text5']);

	$Fn_Wallet->Config['LangVar']['WithdrawalsMoneyPlaceholder'] = str_replace('{num}',$Fn_Wallet->Config['PluginVar']['WithdrawalsMinMoney'],$Fn_Wallet->Config['LangVar']['WithdrawalsMoneyPlaceholder']);
}else if($_GET['m'] == 'balance'){
	$navtitle = $metakeywords = $metadescription = $Fn_Wallet->Config['LangVar']['Text2'];
}else if($_GET['m'] == 'setup'){
	$navtitle = $metakeywords = $metadescription = $Fn_Wallet->Config['LangVar']['SetupTitle'];
}else if($_GET['m'] == 'index'){
	$navtitle = $metakeywords = $metadescription = $Fn_Wallet->Config['PluginVar']['Title'];
	$Color = $Fn_Wallet->HexToRgb($Fn_Wallet->Config[PluginVar][Color]);
}else{
	exit('No Data');
}
include template('fn_wallet:'.$_GET['m']);
?>