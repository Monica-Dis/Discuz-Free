<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_wallet/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_wallet/Common.php');
$Operation = in_array($_GET['Operation'], array('Del')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ���� */
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		$TypeSelected = array($_GET['type']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Wallet->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}"></td>
						<th>{$Fn_Wallet->Config['LangVar']['PluginTitle']}</th><td><input type="text" class="txt" name="plugin" value="{$_GET['plugin']}"></td>
						<th>Uid</th><td><input type="text" class="txt" name="uid" value="{$_GET['uid']}"></td>
						<th>{$Fn_Wallet->Config['LangVar']['WalletTypeTitle']}</th>
						<td>
						<select name="type">
							<option value="">{$Fn_Wallet->Config['LangVar']['SelectNull']}</option>
							<option value="1"{$TypeSelected['1']}>{$Fn_Wallet->Config['LangVar']['IncomeExpenditure']['1']}</option>
							<option value="2"{$TypeSelected['2']}>{$Fn_Wallet->Config['LangVar']['IncomeExpenditure']['2']}</option>
						</select>
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Wallet->Config['LangVar']['SearchSubmit']}" class="btn" type="submit"></td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'L.id';
		if($_GET['uid']){
			$Where .= ' and L.uid = '.intval($_GET['uid']);
		}
		if($_GET['type']){
			$Where .= ' and L.type = '.intval($_GET['type']);
		}
		if($_GET['keyword']){
			$Where .= ' and concat(L.content) like(\'%'.addslashes(dhtmlspecialchars($_GET['keyword'])).'%\')';
		}
		if($_GET['plugin']){
			$Where .= ' and concat(L.plugin) like(\'%'.addslashes(dhtmlspecialchars($_GET['plugin'])).'%\')';
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		$TdStyle = array('width="20"', 'width="50"','width="80"','width="100"','width="80"','width="80"','width="80"');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'QiangLouModule', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_Wallet->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
			'ID',
            'Uid',
			$Fn_Wallet->Config['LangVar']['UserNameTitle'],
			$Fn_Wallet->Config['LangVar']['WalletContentTitle'],
			$Fn_Wallet->Config['LangVar']['MoneyTitle'],
			$Fn_Wallet->Config['LangVar']['WalletTypeTitle'],
			$Fn_Wallet->Config['LangVar']['PluginTitle'],
			$Fn_Wallet->Config['LangVar']['TimeTitle']
		), 'header tbm',$TdStyle);
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		foreach ($ModulesList as $Module) {
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				$Module['id'],
				$Module['uid'],
				$Module['musername'],
				$Module['content'],
				$Module['type'] == 1 ? '+'.$Module['money'] : '-'.$Module['money'],
				$Fn_Wallet->Config['LangVar']['IncomeExpenditure'][$Module['type']],
				$Module['plugin'],
				date('Y-m-d H:i',$Module['dateline'])
			));
		}
		showsubmit('','','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter();
		showformfooter();/*Dism_taobao_com*/
		showtagfooter('div');
		/* ģ����� End */
	}
}
/* ��Ƶ�б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Wallet;
	$FetchSql = 'SELECT M.username as musername,L.* FROM '.DB::table($Fn_Wallet->TableWalletLog).' L LEFT JOIN '.DB::table('common_member').' M on M.uid = L.uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ��Ƶ���� */
function GetModulesCount($Where){
	global $Fn_Wallet;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Wallet->TableWalletLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>