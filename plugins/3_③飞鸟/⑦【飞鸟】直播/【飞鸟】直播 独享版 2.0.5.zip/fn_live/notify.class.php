<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('FN_IN_API')) {
	exit('Access Denied');
}
loadcache('plugin');
function NotifyUpdatePay($OrderId,$Identification,$Money,$PayType,$TransactionId){
	global $_G;
	loadcache('plugin');
	$OrderId = addslashes($OrderId);
	$Identification = addslashes($Identification);
	$Money = addslashes($Money);
	$PayType = addslashes($PayType);
	$TransactionId = addslashes($TransactionId);
	$TablePayLog = 'fn_pay_log';

	$TableLivePayLog = 'fn_live_pay_log';
	$TableLiveComment = 'fn_live_comment';
	$TableLiveGiftLog = 'fn_live_gift_log';

	$PayLog = DB::fetch_first('SELECT * FROM '.DB::table($TablePayLog).' where order_id = '.$OrderId.' and money = '.$Money);
	if($PayLog && $PayLog['state'] != 1){
		$Data = array('state'=>1,'payment_type'=>$PayType,'pubid'=>$TransactionId,'pay_time'=>time());
		if(DB::update($TablePayLog,$Data,'order_id='.$OrderId)){
			$PayLog['param'] = unserialize($PayLog['param']);
			if($PayLog['param']['event'] == 'live_pay_log'){//���ѹۿ�ֱ��
				$Id = DB::insert($TableLivePayLog,$PayLog['param']['insert'],true);
				if($Id){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'live_redpacket_send'){
				$Id = DB::insert($TableLiveComment,$PayLog['param']['insert'],true);
				if($Id){
					return true;
				}else{
					return false;
				}
			}else if($PayLog['param']['event'] == 'live_gift'){
				$InsertCid = DB::insert($TableLiveComment,$PayLog['param']['comment_insert'],true);
				$PayLog['param']['gift_log_insert']['father_cid'] = $InsertCid;
				$Id = DB::insert($TableLiveGiftLog,$PayLog['param']['gift_log_insert'],true);
				if($Id){
					if($PayLog['param']['participant_reward']){
						$FnGlobalLogin = true;
						@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
						@require_once (DISCUZ_ROOT .'./source/plugin/fn_live/Function.inc.php');
						$HBState = false;
						if($_G['cache']['plugin']['fn_assembly']['AppType'] == 2){//ǧ�������
							$ReturnBalance = $Fn_Live->QHApp->GetBalanceAdd($PayLog['param']['participant_reward']['uid'],$PayLog['param']['participant_reward']['money']);
							if($ReturnBalance['state'] == 200){
								$HBState = true;
							}
						}else if($_G['cache']['plugin']['fn_assembly']['AppType'] == 1){//���׷����
							$ReturnBalance = $Fn_Live->MagApp->GetMagAccountTransfer($PayLog['param']['participant_reward']['uid'],$PayLog['param']['participant_reward']['money'],$Fn_Live->Config['LangVar']['GiftSharing']);
							if($ReturnBalance['state'] == 200){
								$HBState = true;
							};
						}else{//����Ǯ��
							if(FnWallet::WalletLogInsertBy($PayLog['param']['participant_reward']['uid'],$Fn_Live->Config['LangVar']['GiftSharing'],$PayLog['param']['participant_reward']['money'],1,'fn_live')){
								$HBState = true;
							}
						}
						if($HBState){
							DB::update($Fn_Live->TableGiftLog,array('branch_state'=>1),'id='.$Id);
						}
					}

					return true;
				}else{
					return false;
				}
			}
		}
	}
}
//From: dis'.'m.tao'.'bao.com
?>