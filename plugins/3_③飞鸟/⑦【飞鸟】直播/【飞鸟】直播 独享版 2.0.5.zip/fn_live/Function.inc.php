<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once libfile('function/core','plugin/fn_assembly');
@require_once libfile('class/magapp','plugin/fn_assembly');
@require_once libfile('class/qfapp','plugin/fn_assembly');
@require_once libfile('class/pay','plugin/fn_assembly');
@require_once libfile('class/json','plugin/fn_assembly');

if(!in_array($Config['PluginVar']['AppType'],array('1','2')) && file_exists(DISCUZ_ROOT.'./source/plugin/fn_wallet/wallet.class.php')){//��ǧ�������׼��ط���Ǯ��
	@include DISCUZ_ROOT.'./source/plugin/fn_wallet/wallet.class.php';
}

class Fn_Live{
	public function __construct() {
		global $_G,$plugin;
		loadcache('plugin');
		loadcache('fn_live_setting');
		foreach($_G['cache']['fn_live_setting'] as $key => $value) {
			$this->Config['PluginVar'][$key] = is_array($value) ? $value : stripslashes($value);
		}
		
		$this->Config['PluginVar']['ProhibitRedpacketUids'] = array_filter(explode(",",$this->Config['PluginVar']['ProhibitRedpacketUids']));

		//������ά�뿪��
		if(!$this->Config['PluginVar']['QrParameterSwitch'] && QrParameterSwitch){
			$this->Config['PluginVar']['WxAppid'] = $Config['PluginVar']['WxAppid'];
			$this->Config['PluginVar']['WxSecret'] = $Config['PluginVar']['WxSecret'];
		}
		$this->Config['PluginVar']['QrParameterSwitch'] = $this->Config['PluginVar']['QrParameterSwitch'] ? $this->Config['PluginVar']['QrParameterSwitch'] : (QrParameterSwitch ? QrParameterSwitch : 0);
		//������ά�뿪�� End

		$this->Config['LangVar'] = lang('plugin/fn_live');

		$this->Config['Path'] = 'source/plugin/fn_live';
		$this->Config['StaticPath'] =$_G['siteroot'].$this->Config['Path'].'/static';
		$this->Config['StaticPicPath'] = $this->Config['Path'].'/attachment/';
		$this->Config['Url'] = $_G['siteurl'].'plugin.php?id=fn_live'.($_GET['formapp'] ? '&formapp='.$_GET['formapp'] : '');
		$this->Config['ListViewUrl'] = $this->Config['Url'].'&m=list_view&nid=';
		$this->Config['ViewUrl'] = $this->Config['Url'].'&m=view&lid=';
		$this->Config['WalletUrl'] = $_G['siteurl'].'plugin.php?id=fn_wallet';
		
		$this->Config['AjaxUrl'] =  $_G['siteroot'].'plugin.php?id=fn_live:Ajax'.($_GET['formapp'] ? '&formapp='.$_GET['formapp'] : '');
		$this->Config['WxShare'] = array(
			'WxTitle' => $this->Config['PluginVar']['WxTitle'],
			'WxDes' => $this->Config['PluginVar']['WxDes'],
			'WxImg' => strpos($this->Config['PluginVar']['WxImg'],'http') !== false ? $this->Config['PluginVar']['WxImg'] : $_G['siteurl'].$this->Config['PluginVar']['WxImg'],
			'WxUrl' => $this->Config['Url']
		);

		if(!is_dir(DISCUZ_ROOT.$this->Config['StaticPicPath'])){
			dmkdir(DISCUZ_ROOT.$this->Config['StaticPicPath']);
		}

		$this->TableNumber = 'fn_live_number';
		$this->TableLive = 'fn_live';
		$this->TableComment = 'fn_live_comment';
		$this->TableGift = 'fn_live_gift';
		$this->TableGiftLog = 'fn_live_gift_log';
		$this->TableInfo = 'fn_live_info';
		$this->TableInviteLog = 'fn_live_invite_log';
		$this->TableParticipant = 'fn_live_participant';
		$this->TablePassLog = 'fn_live_pass_log';
		$this->TableLivePayLog = 'fn_live_pay_log';
		$this->TableRedpacketLog = 'fn_live_redpacket_log';
		$this->TableVisitLog = 'fn_live_visit_log';
		
		$this->Pay = new Fn_PayLog();
		$this->MagApp = new MagApp($this->Config['PluginVar']['MagSecret'],$this->Config['PluginVar']['MagAssistantSecret'],$this->Config['PluginVar']['MagAssistantPush']);
		$this->QHApp = new QHApp($this->Config['PluginVar']['qf_type'],$this->Config['PluginVar']['qf_sr_type']);
		$this->Config['AppPaymentId'] = $this->QHApp->AppPaymentId;
	}

	/* ֱ������ */
	public function GetViewthread($Id,$Where = null){
		global $_G,$Config;
		$Item = DB::fetch_first('SELECT N.title as number_title,N.display as number_display,L.* FROM '.DB::table($this->TableLive).' L LEFT JOIN `'.DB::table($this->TableNumber).'` N on N.id = L.number_id where L.id = '.intval($Id));
		if($Item){

			$Item['param'] = unserialize($Item['param']);
			$Item['param']['content2'] = stripslashes($Item['param']['content2']);
			$Item['param']['content3'] = stripslashes($Item['param']['content3']);
			$Item['param']['player_weight'] = $Item['param']['player_weight'] ? $Item['param']['player_weight'] : 1280;
			$Item['param']['player_height'] = $Item['param']['player_height'] ? $Item['param']['player_height'] : 720;	
			if(AppYes){
				if(!App){
					$Item['param']['money_tips'] = $Item['param']['money_app_tips'];
				}else{
					if(!$Item['param']['money_app']){
						$Item['param']['visit_limit'] = 1;
					}else{
						$Item['param']['money'] = $Item['param']['money_app'];
					}
					$Item['param']['m3u8'] = $Item['param']['app_m3u8'] ? $Item['param']['app_m3u8'] : $Item['param']['m3u8'];
				}
			}

			$Item['param']['money_tips'] = str_replace(array('{money}','{money_app}','{br}'),array($Item['param']['money'],$Item['param']['money_app'],'<br>'),$Item['param']['money_tips']);
			
			$Item['admin'] = in_array($_G['uid'],array_filter(explode(',',$Item['param']['admin_uids']))) ? true : false;
			$Item['admin_info'] = in_array($_G['uid'],array_filter(explode(',',$Item['param']['admin_info_uids']))) ? true : false;
			$Item['admin_participant_reward'] = in_array($_G['uid'],array_filter(explode(',',$Item['param']['admin_participant_reward_uids']))) ? true : false;

		}
		return $Item;
	}

	/* ����Iframe��Ƶ */
	public function AnalysisIframe($Id){
		$Item = $this->GetViewthread($Id);
		$IframeUrl = $Item['param']['iframe_url'];
		$Http = IsHttps();
		if($Item['param']['analysis_url_switch']){
			$IframeHtml = "<iframe height='100%' width='100%' src='".$this->Config['PluginVar']['AnalysisUrl'].$IframeUrl."' frameborder=0 'allowfullscreen'></iframe>";
		}else if(strpos($IframeUrl,'youku.com') !== false){//�ſ�
			$YouKuArray = array_filter(explode('/id_',$IframeUrl));
			$YouKuArray = explode('.html',$YouKuArray[1]);
			$IframeUrl = $Http.'player.youku.com/embed/'.$YouKuArray[0];
			$IframeHtml = "<iframe height='100%' width='100%' src='".$IframeUrl."' frameborder=0 'allowfullscreen'></iframe>";
		}else if(strpos($IframeUrl,'tudou.com') !== false){//�ſ�
			$TuDouArray = array_filter(explode('/',$IframeUrl));
			$TuDouArray = explode('.html',$TuDouArray[count($TuDouArray)]);
			$IframeUrl = $Http.'player.youku.com/embed/'.$TuDouArray[0];
			$IframeHtml = "<iframe height='100%' width='100%' src='".$IframeUrl."' frameborder=0 'allowfullscreen'></iframe>";
		}else if(strpos($IframeUrl,'v.qq.com') !== false){//��Ѷ
			$TxArray = array_filter(explode('/',$IframeUrl));
			$TxArray = explode('.html',$TxArray[count($TxArray)]);
			$IframeUrl = $Http.'v.qq.com/iframe/player.html?vid='.$TxArray[0].'&tiny=0&auto=0';
			$IframeHtml = "<iframe height='100%' width='100%' src='".$IframeUrl."' frameborder=0 'allowfullscreen'></iframe>";
		}else if(strpos($IframeUrl,'v.qq.com') !== false){//��Ѷ
			$TxArray = array_filter(explode('/',$IframeUrl));
			$TxArray = explode('.html',$TxArray[count($TxArray)]);
			$IframeUrl = $Http.'v.qq.com/iframe/player.html?vid='.$TxArray[0].'&tiny=0&auto=0';
			$IframeHtml = "<iframe height='100%' width='100%' src='".$IframeUrl."' frameborder=0 'allowfullscreen'></iframe>";
		}else if(strpos($IframeUrl,'youtube.com') !== false){//youtube
			$YouTubeArray = array_filter(explode('v=',$IframeUrl));
			$String = $YouTubeArray[count($YouTubeArray)-1];
			$IframeUrl = $Http.'www.youtube.com/embed/'.$String;
			$IframeHtml = "<iframe height='100%' width='100%' src='".$IframeUrl."' frameborder=0 'allowfullscreen'></iframe>";
		}
		return $IframeHtml;
	}
	
	public function FormatPlayer($Item){
		if($Item['param']['player_type'] == 'huya'){//����
			$loginurl = 'https://m.huya.com/' . $Item['param']['room_id'];
			$response = CurlGet('https://m.huya.com/' . $Item['param']['room_id'],'',array(
				'get_url' => true,
                'user-agent' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1'
            ));
			if(preg_match('|<video[^>]+src="([^"]+)"|i', $response, $r)) {
                $Item['param']['m3u8'] = $r[1];
				$Item['param']['rtmp'] = $r[1];
            } else {
                $Item['param']['m3u8'] = '';
            }
			$Item['param']['player_type'] = 'm3u8';
		}else if($Item['param']['player_type'] == 'yy'){//YYֱ��
			$loginurl = 'http://interface.yy.com/hls/get/0/' . $Item['param']['sid'] . '/' . $Item['param']['ssid'] . '?appid=0&excid=1200&type=m3u8&isHttps=0&callback=jsonp2';
            $response = CurlGet(
                $loginurl, '', array(
                    'referer' => 'http://wap.yy.com/mobileweb/' . $Item['param']['sid'] . '/' . $Item['param']['ssid'] . '?tempId=' . $Item['param']['temp_id'] . '',
                )
            );
			
			if(preg_match('|"hls":"(.*?)","|i', $response, $r)) {
                $Item['param']['m3u8'] = $r[1];
				$Item['param']['rtmp'] = $r[1];
            } else {
                $Item['param']['m3u8'] = '';
            }
			$Item['param']['player_type'] = 'm3u8';
		}else if($Item['param']['player_type'] == 'qq'){//���羺
			$loginurl = 'http://egame.qq.com/'.$Item['param']['qq_room_id'];
            $response = CurlGet($loginurl);
            $pattern = "/\"playUrl\"\s*:\s*\"(.*?)\"/is";
            $playUrl = preg_match($pattern, $response, $match);
			$Item['param']['m3u8'] = str_replace('flv', 'm3u8', $match[1]);
			$Item['param']['rtmp'] = $match[1];
			$Item['param']['player_type'] = 'm3u8';
		}
		return $Item;
	}
	
	

	/* ֱ���б� */
	public function GetAjaxList($Get){
		
		$Get = StrToGBK($Get);

		$Results = array();

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		
		$this->Config['PluginVar']['ListNum'] = $Get['limit'] ? $Get['limit'] : $this->Config['PluginVar']['ListNum'];
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];
		
		$Where = ' and L.display = 1';
		
		$Order = 'L.updateline';

		if($Get['number_id']){
			$Where .= ' and L.number_id = '.intval($Get['number_id']);
		}

		if($Get['state']){
			$Where .= ' and L.state = '.intval($Get['state']);
		}

		$Where = preg_replace('/and/','where',$Where,1);
		$FetchSql = 'SELECT N.title as number_title,N.display as number_display,L.* FROM '.DB::table($this->TableLive).' L LEFT JOIN `'.DB::table($this->TableNumber).'` N on N.id = L.number_id '.$Where.' order by L.topdateline > '.time().' desc,'.$Order.' desc,L.dateline desc '.$Limit;
		$Results = $this->LiveListFormat(DB::fetch_all($FetchSql));
		return $Results;

	}

	/* �б���ʽת�� */
	private function LiveListFormat($Array,$Click=false){
		global $_G;
		
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['content'] = cutstr(DeleteHtml($Val['content']),90); 
			$Array[$Key]['param']['content2'] = ''; 
			$Array[$Key]['param']['content3'] = '';
			$Array[$Key]['param']['jump_url'] = $Val['param']['jump_url'] ? $Val['param']['jump_url'] : '';
			$Array[$Key]['updateline'] = $Val['updateline'] ? date('Y-m-d H:i',$Val['updateline']) : '';

			if($Click){
				Click($this->TableLive,$Val['id']);
			}
			
		}
		return $Array;
	}

	/* ͼ������ */
	public function GetViewInfo($Id,$Where = null){
		global $_G,$Config;
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableInfo).' where id = '.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
		}
		return $Item;
	}

	/* ����ͼ��ֱ�� */
	public function GetAjaxPublishInfo($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->GetViewthread($Get['lid']);
		if(!$Item || (!$Item['display'] && $Item)){//ֱ��������
			$Data['Msg'] = $this->Config['LangVar']['NoLiveData'];
			return $Data;
		}
		
		if(!$Item['admin_info']){
			$Data['Msg'] = $this->Config['LangVar']['NoPermission'];
			return $Data;
		}

		$InfoItem = $this->GetViewInfo($Get['iid']);

		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['lid'] = intval($Get['lid']);
		$UpData['live_name_id'] = intval($Get['live_name_id']);
		$UpData['content'] = addslashes(strip_tags($Get['info_content']));
		$UpData['video_url'] = addslashes(strip_tags($Get['video_url']));
		$UpData['display'] = $InfoItem ? $InfoItem['display'] : 1;
		foreach(array_filter(explode(';',$Get['new_images'][0])) as $Key => $Val) {
			$Get['new_images'][$Key] = strpos($Val,'http') !== false ? $Val : $_G['siteurl'].$Val;
		}
		$Param['images'] = is_array($Get['new_images']) && isset($Get['new_images']) ? $Get['new_images'] : '';
		$Param['count_images'] = count($Param['images']);
		$Param['name'] = $Item['param']['live_name_id_array'][$UpData['live_name_id']]['name'];
		$Param['face'] = $Item['param']['live_name_id_array'][$UpData['live_name_id']]['face'];

		$UpData['param'] = serialize($Param);
		
		if($Param['images']){
			$UpData['type'] = 2;
		}else if($UpData['video_url']){
			$UpData['type'] = 3;
		}else{
			$UpData['type'] = 1;
		}

		if($InfoItem){
			if(DB::update($this->TableInfo,$UpData,'id = '.intval($InfoItem['id']))){
				$Data['Msg'] = $this->Config['LangVar']['UpdateOk'];
				$Data['State'] = 200;
				$Data['item'] = array();
				$Data['item']['id'] = $InfoItem['id'];
				$UpData['updateline'] = $InfoItem['updateline'];
			}else{
				$Data['Msg'] = $this->Config['LangVar']['UpdateErr'];
			}
		}else{
			$UpData['dateline'] = $UpData['updateline'] = time();
			$InfoId = DB::insert($this->TableInfo,$UpData,true);
			if($InfoId){
				$Data['insert'] = 1;
				$Data['State'] = 200;
				$Data['Msg'] = $this->Config['LangVar']['PublishSuccess'];
				$Data['item'] = array();
				$Data['item']['id'] = $InfoId;
			}else{
				$Data['Msg'] = $this->Config['LangVar']['PublishFail'];
			}
		}
		$Data['live_name_id'] = intval($UpData['live_name_id']);
		$Data['item']['name'] = $Item['param']['live_name_id_array'][$UpData['live_name_id']]['name'];
		$Data['item']['face'] = $Item['param']['live_name_id_array'][$UpData['live_name_id']]['face'];
		$Data['item']['content'] = addslashes(strip_tags($UpData['content']));
		$Data['item']['images'] = $Param['images'];
		$Data['item']['count_images'] = $Param['count_images'];
		$Data['item']['video_url'] = $UpData['video_url'];
		$Data['item']['count'] = DB::result_first('SELECT count(*) FROM '.DB::table($this->TableInfo).' where lid = '.intval($Get['lid']).' and display = 1');
		$Data['item']['count_text'] = str_replace("{count}",$Data['item']['count'],$this->Config['LangVar']['InfoCountTips']);
		$Data['item']['updateline'] = $UpData['updateline'] > strtotime(date('Y-m-d')) && $UpData['updateline'] < strtotime(date('Y-m-d 23:59:59')) ? date('H:i',$UpData['updateline']) : date('m-d H:i',$UpData['updateline']);
		return $Data;
	
	}

	/* ͼ���б� */
	public function GetAjaxInfoList($Get){
		global $_G;

		$Item = $this->GetViewthread($Get['lid']);
		
		$Results = array();

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		$this->Config['PluginVar']['ListNum'] = $Get['limit'] ? $Get['limit'] : 10;
		$Limit = $Get['judge_type'] && $Get['judge_type'] == 'first' ? '' : 'LIMIT 0,'.$this->Config['PluginVar']['ListNum'];
		$Order = 'I.id';
		$By = $Get['by'] ? $Get['by'] : 'desc';
		$Where = '';

		if(!$Get['admin']){
			$Where .= ' and I.display = 1';
		}
		
		if($Get['lid']){
			$Where .= ' and I.lid = '.intval($Get['lid']);
		}
		
		if($Get['judge_type'] == 'last' && $Get['judge_id']){
			$Where .= ' and I.id < '.intval($Get['judge_id']);
		}else if($Get['judge_type'] == 'first' && $Get['judge_id']){
			$Where .= ' and I.id > '.intval($Get['judge_id']);
		}

		$Where = preg_replace('/and/','where',$Where,1);

		$FetchSql = 'SELECT I.* FROM '.DB::table($this->TableInfo).' I '.$Where.' order by '.$Order.' '.$By.',I.updateline '.$By.' '.$Limit;
		
		$Results['List'] = $this->InfoListFormat(DB::fetch_all($FetchSql));
		$Results['count'] = DB::result_first('SELECT count(*) FROM '.DB::table($this->TableInfo).' where lid = '.intval($Get['lid']).' and display = 1');
		$Results['count_text'] = str_replace("{count}",$Results['count'],$this->Config['LangVar']['InfoCountTips']);
		return $Results;
	}

	/* ͼ��ֱ����ʽ�� */
	private function InfoListFormat($Array){
		global $_G;
		@require_once libfile('function/forum');
		foreach ($Array as $Key => $Val) {
			$Array[$Key]['param'] = unserialize($Val['param']);
			$Array[$Key]['username'] = DeleteHtml($Val['username']); 
			$Array[$Key]['content'] = DeleteHtml($Val['content']);
			$Array[$Key]['dateline'] = $Val['dateline'] > strtotime(date('Y-m-d')) && $Val['dateline'] < strtotime(date('Y-m-d 23:59:59')) ? date('H:i',$Val['dateline']) : date('m-d H:i',$Val['dateline']);
			$Array[$Key]['updateline'] = $Val['updateline'] > strtotime(date('Y-m-d')) && $Val['updateline'] < strtotime(date('Y-m-d 23:59:59')) ? date('H:i',$Val['updateline']) : date('m-d H:i',$Val['updateline']);
		}

		return $Array;
	}

	/* ����Ա�������� */
	public function GetAjaxAdminInfo($Op,$iid,$Lid,$Field=null,$Value=null){
		global $_G;
		$Item = $this->GetViewthread($Lid);
		if(!$Item){//ֱ��������
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoLiveData']);
			return $Data;
		}
		
		if(!$Item['admin_info']){//Ȩ���ж�
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoPermission']);
			return $Data;
		}
		
		if($Op == 'Del'){//ɾ��
			if(DB::delete($this->TableInfo,'id ='.intval($iid))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
		}else{
			if(DB::update($this->TableComment,array($Field=>$Value),'id = '.intval($Cid))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
		}
		return $Data;
	}

	/* �������� */
	public function GetAjaxComment($Get){
		global $_G,$Config;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->GetViewthread($Get['lid']);
		if(!$Item || (!$Item['display'] && $Item)){//ֱ��������
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoLiveData']);
			return $Data;
		}

		if($Item['param']['money'] && !in_array($Item['id'],$this->GetUserLivePayLogArray()) && $Item['param']['visit_limit'] == 2){//δ���ѽ�ֹ����
			$Data['Msg'] = urlencode($Item['param']['no_pay_comment_tips']);
			return $Data;
		}

		if($Item['param']['comment_prohibit']){//��ֹ����
			$Data['Msg'] = urlencode($Item['param']['comment_prohibit_tips']);
			return $Data;
		}

		if($Item['param']['app_comment'] && !App){//APP�ڲſ�����
			$Data['Msg'] = urlencode($Item['param']['app_commen_tips']);
			return $Data;
		}

		if(in_array($_G['uid'],$Item['param']['comment_forbidden_words_array'])){//����
			$Data['Msg'] = urlencode($Item['param']['comment_forbidden_words_tips']);
			return $Data;
		}

		if(!$Get['content']){//�����ж�
			$Data['Msg'] = urlencode($Item['param']['comment_input_null_tips']);
			return $Data;
		}
		
		if($Item['param']['comment_time']){
			$MyLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableComment).' where lid = '.$Item['id'].' and uid = '.intval($_G['uid']).' order by id desc');
			if(time() < strtotime("+".$Item['param']['comment_time']." second",$MyLog['dateline'])){//ʱ������
				$TIME = $Item['param']['comment_time'] - (time() - $MyLog['dateline']);
				$Data['Msg'] = urlencode(str_replace('{TIME}',$TIME,$Item['param']['comment_time_tips']));
				return $Data;
			}
		}
		
		$UpData['rid'] = intval($Get['rid']);
		$UpData['lid'] = intval($Get['lid']);
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['content'] = censor(addslashes(strip_tags($Get['content'])));
		$UpData['type'] = 1;
		$UpData['display'] = $Item['param']['comment_display'] ? 0 : 1;
		$UpData['dateline'] = $UpData['updateline'] = time();

		$CId = DB::insert($this->TableComment,$UpData,true);
		if($CId){
			@require_once libfile('function/forum');
			$Data['State'] = 200;
			$Data['Id'] = $CId;
			$Data['Uid'] = $_G['uid'];
			$Data['Display'] = $UpData['display'];
			$Data['Msg'] = urlencode($this->Config['LangVar']['CommentSuccess'].(!$UpData['display'] ? '<br><span style=color:red>'.$this->Config['LangVar']['QuickReview'].'</span>' : ''));
			$Data['face'] = discuz_uc_avatar($_G['uid'],middle,true);
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['CommentFail']);
		}
		return $Data;
	}

	/* �����б� */
	public function GetAjaxCommentList($Get){
		global $_G;

		$Get = StrToGBK($Get);
		$Item = $this->GetViewthread($Get['lid']);
		
		$Results = array();

		$Page = $Get['page'] ? intval($Get['page']) : 0 ;
		$this->Config['PluginVar']['ListNum'] = $Get['limit'] ? $Get['limit'] : 10;
		$Limit = $Get['judge_type'] && $Get['judge_type'] == 'first' ? '' : 'LIMIT 0,'.$this->Config['PluginVar']['ListNum'];
		$Order = 'C.id';
		$Where = '';

		if(!$Get['admin']){
			$Where .= ' and C.display = 1';
		}
		
		if($Get['lid']){
			$Where .= ' and C.lid = '.intval($Get['lid']);
		}

		if($Get['judge_type'] == 'last' && $Get['judge_id']){
			$Where .= ' and C.id < '.intval($Get['judge_id']).' and ( C.topdateline = \'\' or C.topdateline <= '.time().')';
		}else if($Get['judge_type'] == 'first' && $Get['judge_id']){
			$Where .= ' and C.id > '.intval($Get['judge_id']).' and ( C.topdateline = \'\' or C.topdateline <= '.time().')';
		}

		$Where = preg_replace('/and/','where',$Where,1);

		$FetchSql = 'SELECT C.* FROM '.DB::table($this->TableComment).' C '.$Where.' order by C.topdateline > '.time().' desc,'.$Order.' desc,C.dateline desc '.$Limit;
		
		$Results['List'] = $this->CommentListFormat(DB::fetch_all($FetchSql),$Item['param']['comment_forbidden_words_array']);

		return $Results;
	}
	
	/* ���۸�ʽ�� */
	private function CommentListFormat($Array,$ForbiddenArray = null){
		global $_G,$Config;
		@require_once libfile('function/forum');
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['username'] = DeleteHtml($Val['username']); 
			$Array[$Key]['content'] = in_array($Val['type'],array('3','4')) ? str_replace(array("\\","\/","'","\"",$Config['LangVar']['fenhao'],$Config['LangVar']['wanhao']),"",$Val['content']) : DeleteHtml($Val['content']);
			$Array[$Key]['dateline'] = $Val['dateline'] ? FormatDate($Val['dateline'],'Y-m-d H:i') : '';
			$Array[$Key]['updateline'] = $Val['updateline'] ? FormatDate($Val['updateline'],'Y-m-d H:i') : '';
			$Array[$Key]['return_top'] = $Val['topdateline'] > time() ? 1 : 0;
			$Array[$Key]['face'] = discuz_uc_avatar($Val['uid'],middle,true);
			$Array[$Key]['forbidden'] = in_array($Val['uid'],$ForbiddenArray) ? 1 : 0;
			$Array[$Key]['redpacket_list'] = '';
		}

		return $Array;
	}

	/* ����Ա�������� */
	public function GetAjaxAdminComment($Op,$Cid,$Lid,$Field=null,$Value=null){
		global $_G;
		$Item = $this->GetViewthread($Lid);
		if(!$Item){//ֱ��������
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoLiveData']);
			return $Data;
		}
		
		if(!$Item['admin']){//Ȩ���ж�
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoPermission']);
			return $Data;
		}
		
		if($Op == 'Del'){//ɾ��
			if(DB::delete($this->TableComment,'id ='.intval($Cid))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
		}else if($Op == 'Forbidden'){//���� or ���
			$Param = $Item['param'];
			if($Value == 0){//����
				$Param['comment_forbidden_words_array'][] = $Field;
				$Param['comment_forbidden_words_array'] = array_unique($Param['comment_forbidden_words_array']);
				$Param['comment_forbidden_words'] = implode("\r\n",array_filter($Param['comment_forbidden_words_array']));
				$Forbidden = 1;
			}else{//���
				$Index = array_search($Field,$Param['comment_forbidden_words_array']);
				if($Index !== FALSE){
					array_splice($Param['comment_forbidden_words_array'], $Index, 1); 
				}
				$Param['comment_forbidden_words'] = implode("\r\n",array_filter($Param['comment_forbidden_words_array']));
				$Forbidden = 0;

			}
			if(DB::update($this->TableLive,array('param'=>serialize($Param)),'id = '.intval($Lid))){
				//DB::update($this->TableComment,array('display'=> !$Value ? 0 : 1),'lid = '.intval($Lid).' and uid = '.intval($Field));
				$Data['State'] = 200;
				$Data['Forbidden'] = $Forbidden;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
		}else{
			if(DB::update($this->TableComment,array($Field=>$Value),'id = '.intval($Cid))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
		}
		return $Data;
	}

	/* �����б� */
	public function GetGiftList($Where = null){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableGift).' '.$Where.' order by displayorder asc');//��������
	}

	/* �������� */
	public function GetViewGift($Id){
		return DB::fetch_first('SELECT * FROM '.DB::table($this->TableGift).' where id = '.intval($Id));
	}
	
	/* ������ */
	public function GetAjaxGiftPay($Get){
		global $_G;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->GetViewthread($Get['lid']);
		if(!$Item){//ֱ��������
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoLiveData']);
			return $Data;
		}
		$GiftItem = $this->GetViewGift($Get['gift_id']);
		if(!$GiftItem){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoGiftData']);
			return $Data;
		}

		$ParticipantItem = $this->GetViewParticipant($Get['be_reward_id']);
		if($ParticipantItem && !$ParticipantItem['display']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['ParticipantRewardDisplayErr']);
			return $Data;
		}
		
		$GiftLogInsert['lid'] = $Item['id'];
		$GiftLogInsert['uid'] = intval($_G['uid']);
		$GiftLogInsert['username'] = addslashes(strip_tags($_G['username']));
		$GiftLogInsert['be_reward_id'] = $ParticipantItem ? intval($Get['be_reward_id']) : '';
		$GiftLogInsert['gift_id'] = intval($GiftItem['id']);
		$GiftLogInsert['money'] = $GiftItem['money'];
		$GiftLogInsert['branch_state'] = 1;
		$GiftLogInsert['dateline'] = time();

		$CommentInsert['lid'] = $Item['id'];
		$CommentInsert['uid'] = intval($_G['uid']);
		$CommentInsert['username'] = addslashes(strip_tags($_G['username']));
		$CommentInsert['content'] = $ParticipantItem ? str_replace(array('{username}','{money}','{gift_title}','{gift_ico}','{name}'),array($CommentInsert['username'],$GiftItem['money'],$GiftItem['title'],($GiftItem['ico'] ? '<img src='.$GiftItem['ico'].'>' : ''),$ParticipantItem['name']),$Item['param']['participant_gift_comment']) : str_replace(array('{username}','{money}','{gift_title}','{gift_ico}'),array($CommentInsert['username'],$GiftItem['money'],$GiftItem['title'],($GiftItem['ico'] ? '<img src='.$GiftItem['ico'].'>' : '')),$Item['param']['gift_comment']);
		$CommentInsert['type'] = 4;
		$CommentInsert['money'] = $GiftItem['money'];
		$CommentInsert['display'] = 1;
		$CommentInsert['dateline'] = $CommentInsert['updateline'] = time();
		
		if($ParticipantItem && $Item['param']['participant_reward_percentage']){
			$ParticipantReward['uid'] = $ParticipantItem['uid'];
			$ParticipantReward['money'] = $GiftLogInsert['branch_money'] = sprintf("%.2f",$GiftItem['money'] * $Item['param']['participant_reward_percentage'] / 100);
			$GiftLogInsert['branch_state'] = 0;
		}
		$PayLog = $this->GetAjaxPayLog(array('money'=>$GiftItem['money'],'event'=>'live_gift','gift_log_insert'=>$GiftLogInsert,'comment_insert'=>$CommentInsert,'lid'=>$Item['id'],'gift_id'=>$GiftItem['id'],'participant_reward'=>$ParticipantReward),false);
		$Data['Money'] = $GiftItem['money'];
		$Data['PayId'] = $PayLog['Id'];
		$Data['State'] = 200;
		return $Data;

	}

	/* �������б� */
	public function GetAjaxGiftLogList($Get){
		global $_G;

		$Item = $this->GetViewthread($Get['lid']);
		if(!$Item){//ֱ��������
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoLiveData']);
			return $Data;
		}

		$Data['State'] = 200;
		$Data['count_money'] = DB::result_first('SELECT SUM(money) FROM '.DB::table($this->TableGiftLog).' where lid = '.intval($Get['lid']));
		$Data['count_money'] = $Data['count_money'] ? $Data['count_money'] : '0.00';
		$Data['results'] = array();
		$Data['results'] = $this->GiftLogListFormat(DB::fetch_all('SELECT G.title as gift_title,G.ico as gift_ico,L.* FROM '.DB::table($this->TableGiftLog).' L LEFT JOIN `'.DB::table($this->TableGift).'` G on G.id = L.gift_id where L.lid = '.intval($Get['lid']).' order by id desc,dateline desc'),$Item['param']['gift_log_content']);
		return $Data;
	}

	/* �������¼��ʽ�� */
	private function GiftLogListFormat($Array,$GiftLogContent = null){
		@require_once libfile('function/forum');
		
		foreach ($Array as $Key => $Val) {
			
			$Array[$Key]['username'] = DeleteHtml($Val['username']); 
			$Array[$Key]['face'] = discuz_uc_avatar($Val['uid'],middle,true);
			$Array[$Key]['content'] = str_replace(array('{username}','{money}','{gift_title}','{gift_ico}'),array($Val['username'],$Val['money'],$Val['gift_title'],($Val['gift_ico'] ? '<img src='.$Val['gift_ico'].'>' : '')),$GiftLogContent);
			$Array[$Key]['dateline'] = date('Y-m-d H:i',$Val['dateline']);

		}
		return $Array;
	}

	/* ����� */
	public function GetAjaxRedpacketSend($Get){
		global $_G;
		$Get = EncodeURIToUrldeCode($Get);

		$Item = $this->GetViewthread($Get['lid']);
		if(!$Item){//ֱ��������
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoLiveData']);
			return $Data;
		}

		if(!$Get['money']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RedpacketSendArray']['11']);
			return $Data;
		}else if(!preg_match('/^[0-9]+(.[0-9]{1,2})?$/',$Get['money'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RedpacketSendArray']['14']);
			return $Data;
		}
		
		if(!$Get['redpacket_number']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RedpacketSendArray']['12']);
			return $Data;
		}else if(!is_numeric($Get['redpacket_number'])){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RedpacketSendArray']['15']);
			return $Data;
		}

		if(dstrlen($Get['redpacket_content']) >= 30){
			$Data['Msg'] = urlencode($this->Config['LangVar']['RedpacketSendArray']['13']);
			return $Data;
		}
		
		$Insert['lid'] = $Item['id'];
		$Insert['uid'] = intval($_G['uid']);
		$Insert['username'] = addslashes(strip_tags($_G['username']));
		$Insert['money'] = intval($Get['money']*100) / 100;
		$Insert['content'] = $Get['redpacket_content'] ? addslashes(strip_tags($Get['redpacket_content'])) : $this->Config['LangVar']['RedpacketContentDefaul'];
		$Insert['type'] = 2;
		$Insert['redpacket_number'] = intval($Get['redpacket_number']);
		$Insert['redpacket_type'] = in_array($Get['redpacket_type'],array('1','2')) ? $Get['redpacket_type'] : 1;
		$Insert['display'] = 1;
		$Insert['dateline'] = $Insert['updateline'] = time();
			

		@require_once libfile('class/rand_pedpacket','plugin/fn_assembly');
		$rand_pedpacket = new rand_pedpacket($Insert['money'],$Insert['redpacket_number'],0.01,$Insert['redpacket_type']);
		$rand_handle = $rand_pedpacket->handle();
		if($rand_handle['error'] == 1){
			$Data['Msg'] = urlencode(str_replace(array('{money}'),array($rand_handle['msg']),$this->Config['LangVar']['NotEnoughPedpacketErr']));
			return $Data;
		}
		$Insert['count_money'] = array_sum($rand_handle['items']);
		$Insert['redpacket_list'] = serialize($rand_handle['items']);
		$Insert['money'] = $Insert['redpacket_type'] == 2 ? $Insert['money'] * $Insert['redpacket_number'] : $Insert['money'];
		$PayLog = $this->GetAjaxPayLog(array('money'=>$Insert['money'],'event'=>'live_redpacket_send','insert'=>$Insert,'lid'=>$Item['id']),false);
		$Data['Money'] = $Insert['money'];
		$Data['PayId'] = $PayLog['Id'];
		$Data['State'] = 200;
		return $Data;

	}

	/* ������� */
	public function GetViewComment($cid,$lid){
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableComment).' where id = '.intval($cid).' and lid = '.intval($lid));
		if($Item){
			$Item['redpacket_list'] = unserialize($Item['redpacket_list']);
		}
		return $Item;
	}

	/* �жϺ�� */
	public function GetAjaxCollarRedpacket($Get){
		global $_G;
		$Get = StrToGBK($Get);
		
		if(in_array($_G['uid'],$this->Config['PluginVar']['ProhibitRedpacketUids'])){
			$Data['Msg'] = urlencode($this->Config['PluginVar']['ProhibitRedpacketTips']);
			return $Data;
		}
		
		$Item = $this->GetViewthread($Get['lid']);
		if(!$Item){//ֱ��������
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoLiveData']);
			return $Data;
		}
		
		$CommentItem = $this->GetViewComment($Get['cid'],$Get['lid']);
		
		if(!$CommentItem){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoRedpacketData']);
			return $Data;
		}
		
		if($Item['param']['pedpacket_app'] && !App){
			$Data['Msg'] = urlencode($Item['param']['pedpacket_app_tips']);
			return $Data;
		}

		@require_once libfile('function/forum');
		$Data['face'] = discuz_uc_avatar($CommentItem['uid'],middle,true);
		$Data['username'] = urlencode($CommentItem['username']);
		$Data['content'] = urlencode($CommentItem['content']);
		if(DB::fetch_first('SELECT * FROM '.DB::table($this->TableRedpacketLog).' where uid = '.intval($_G['uid']).' and lid = '.intval($Get['lid']).' and cid = '.intval($Get['cid']))){
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['CollarRedpacketArray']['1']);
			return $Data;
		}

		if(DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableRedpacketLog).' where lid = '.intval($Get['lid']).' and cid = '.intval($Get['cid'])) >= $CommentItem['redpacket_number']){//�������
			$Data['State'] = 202;
			$Data['Msg'] = urlencode($this->Config['LangVar']['CollarRedpacketArray']['2']);
			return $Data;
		}
		$Data['State'] = 200;
		$Data['type_tips'] = urlencode($this->Config['LangVar']['RedpacketTypeTipsArray'][$CommentItem['redpacket_type']]);
		return $Data;
	}

	/* ��ʼ���� */
	public function GetAjaxCollarRedpacketLoad($Get){
		global $_G,$Config;
		$Get = StrToGBK($Get);
		
		if(in_array($_G['uid'],$this->Config['PluginVar']['ProhibitRedpacketUids'])){
			$Data['Msg'] = urlencode($this->Config['PluginVar']['ProhibitRedpacketTips']);
			return $Data;
		}

		$Item = $this->GetViewthread($Get['lid']);
		if(!$Item){//ֱ��������
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoLiveData']);
			return $Data;
		}
		
		$CommentItem = $this->GetViewComment($Get['cid'],$Get['lid']);
		
		if(!$CommentItem){
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoRedpacketData']);
			return $Data;
		}
		
		if($Item['param']['pedpacket_app'] && !App){
			$Data['Msg'] = urlencode($Item['param']['pedpacket_app_tips']);
			return $Data;
		}

		@require_once libfile('function/forum');
		$Data['face'] = discuz_uc_avatar($CommentItem['uid'],middle,true);
		$Data['username'] = urlencode($CommentItem['username']);
		$Data['content'] = urlencode($CommentItem['content']);

		if(DB::fetch_first('SELECT * FROM '.DB::table($this->TableRedpacketLog).' where uid = '.intval($_G['uid']).' and lid = '.intval($Get['lid']).' and cid = '.intval($Get['cid']))){
			$Data['State'] = 201;
			$Data['Msg'] = urlencode($this->Config['LangVar']['CollarRedpacketArray']['1']);
			return $Data;
		}

		$CountPedpacketLog = DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableRedpacketLog).' where lid = '.intval($Get['lid']).' and cid = '.intval($Get['cid']));

		if($CountPedpacketLog >= $CommentItem['redpacket_number']){//�������
			$Data['State'] = 202;
			$Data['Msg'] = urlencode($this->Config['LangVar']['CollarRedpacketArray']['2']);
			return $Data;
		}
		

		$UpData['lid'] = intval($Get['lid']);
		$UpData['cid'] = intval($Get['cid']);
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['redpacket_type'] = $CommentItem['redpacket_type'];
		$UpData['money'] = $CommentItem['redpacket_list'][$CountPedpacketLog];
		$UpData['dateline'] =  time();
		
		$InsertCid = DB::insert($this->TableComment,array(
			'lid'=>$UpData['lid'],
			'uid'=>$UpData['uid'],
			'username'=>$UpData['username'],
			'content'=> str_replace(array('{username}','{money}'),array($UpData['username'],$UpData['money']),$this->Config['LangVar']['CommentType3Content']),
			'type'=>3,
			'money'=>$UpData['money'],
			'display'=>1,
			'dateline'=>time(),
			'updateline'=>time()
		),true);

		$UpData['father_cid'] = $InsertCid;
		$Id = DB::insert($this->TableRedpacketLog,$UpData,true);

		if($Id){
			$HBState = false;
			if($Config['PluginVar']['AppType'] == 2){//ǧ�������
				$ReturnBalance = $this->QHApp->GetBalanceAdd($UpData['uid'],$UpData['money']);
				if($ReturnBalance['state'] == 200){
					$HBState = true;
				}
			}else if($Config['PluginVar']['AppType'] == 1){//���׷����
				$ReturnBalance = $this->MagApp->GetMagAccountTransfer($UpData['uid'],$UpData['money'],$this->Config['LangVar']['WalletContent']);
				if($ReturnBalance['state'] == 200){
					$HBState = true;
				};
			}else{//����Ǯ��
				if(FnWallet::WalletLogInsertBy($UpData['uid'],$this->Config['LangVar']['WalletContent'],$UpData['money'],1,'fn_live')){
					$HBState = true;
				}
			}
			$HBState ? DB::update($this->TableRedpacketLog,array('state'=>1),'id='.$Id) : '';
			$Data['id'] = $InsertCid;
			$Data['content'] = urlencode(str_replace(array('{username}','{money}'),array($UpData['username'],$UpData['money']),$this->Config['LangVar']['CommentType3Content']));
			$Data['State'] = 200;
			

		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['PedpacketFail']);
		}
		
		return $Data;
	}

	/* ����д��Ǯ�� */
	public function GetAjaxAddBalance($Id){
		global $_G,$Config;
		
		$MyPedpacketLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableRedpacketLog).' where uid = '.intval($_G['uid']).' and id = '.intval($Id).' and state = 0');
		if($MyPedpacketLog){
			$HBState = false;
			if($Config['PluginVar']['AppType'] == 2){//ǧ�������
				$ReturnBalance = $this->QHApp->GetBalanceAdd($MyPedpacketLog['uid'],$MyPedpacketLog['money']);
				if($ReturnBalance['state'] == 200){
					$HBState = true;
				}
			}else if($Config['PluginVar']['AppType'] == 1){//���׷����
				$ReturnBalance = $this->MagApp->GetMagAccountTransfer($MyPedpacketLog['uid'],$MyPedpacketLog['money'],$this->Config['LangVar']['WalletContent']);
				if($ReturnBalance['state'] == 200){
					$HBState = true;
				};
			}else{//����Ǯ��
				if(FnWallet::WalletLogInsertBy($MyPedpacketLog['uid'],$this->Config['LangVar']['WalletContent'],$MyPedpacketLog['money'],1,'fn_live')){
					$HBState = true;
				}
			}
			if($HBState && DB::update($this->TableRedpacketLog,array('state'=>1),'id='.$MyPedpacketLog['id'])){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['PedpacketStateMsgArray']['1']);
			}else{
				$Data['Msg'] = urlencode($BalanceMsg['msg']);
			}
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['PedpacketStateMsgArray']['2']);
		}

		return $Data;
		
	}

	/* ����б� */
	public function GetAjaxRedpacketListLog($Get){
		global $_G;
		$Get = StrToGBK($Get);
		$Item = $this->GetViewthread($Get['lid']);
		if(!$Item){//ֱ��������
			$Data['Msg'] = $this->Config['LangVar']['NoLiveData'];
			return $Data;
		}

		$CommentItem = $this->GetViewComment($Get['cid'],$Get['lid']);

		if(!$CommentItem){
			$Data['Msg'] = $this->Config['LangVar']['NoRedpacketData'];
			return $Data;
		}

		@require_once libfile('function/forum');
		$Data['face'] = discuz_uc_avatar($CommentItem['uid'],middle,true);
		$Data['username'] = DeleteHtml($CommentItem['username']);
		$Data['content'] = DeleteHtml($CommentItem['content']);
		$MyPedpacketLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableRedpacketLog).' where uid = '.intval($_G['uid']).' and lid = '.intval($Get['lid']).' and cid = '.intval($Get['cid']));
		$Data['my'] = $MyPedpacketLog ? 1 : 0;
		$Data['money'] = $MyPedpacketLog['money'];
		$Data['state'] = $MyPedpacketLog['state'];
		$Data['pedpacket_log_id'] = $MyPedpacketLog['id'];
		$Data['count_money_tips'] = str_replace(array('{num}','{count_money}'),array($CommentItem['redpacket_number'],$CommentItem['count_money']),$this->Config['LangVar']['RedpacketCountTips'].(DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableRedpacketLog).' where lid = '.intval($Get['lid']).' and cid = '.intval($Get['cid'])) >= $CommentItem['redpacket_number'] ? $this->Config['LangVar']['YBQG'] : ''));
	
		$Data['results'] = array();
		$Data['results'] = $this->PedpacketLogListFormat(DB::fetch_all('SELECT * FROM '.DB::table($this->TableRedpacketLog).' where lid = '.intval($Get['lid']).' and cid = '.intval($Get['cid']).' order by id desc,dateline desc'));
		return $Data;
	}

	/* �ҵĺ���б� */
	public function GetAjaxMyRedpacketListLog(){
		global $_G;
		$Results = array();
		$Results = $this->PedpacketLogListFormat(DB::fetch_all('SELECT * FROM '.DB::table($this->TableRedpacketLog).' where uid = '.intval($_G['uid']).' order by state = 0 desc, id desc,dateline desc'));
		return $Results;
	}

	/* �����¼��ʽ�� */
	private function PedpacketLogListFormat($Array){
		@require_once libfile('function/forum');
		foreach ($Array as $Key => $Val) {
			$Array[$Key]['username'] = DeleteHtml($Val['username']); 
			$Array[$Key]['face'] = discuz_uc_avatar($Val['uid'],middle,true);
			$Array[$Key]['dateline'] = date('Y-m-d H:i',$Val['dateline']);
			$Array[$Key]['state_text'] = $Val['state'] == 1 ? $this->Config['LangVar']['PedpacketStateArray']['1'] : $this->Config['LangVar']['LQDQB'];
		}
		return $Array;
	}

	/* ���� */
	public function GetPosterInviteLog($Id,$Uid){
		global $_G;
		if($Uid != $_G['uid']){
			if($_G['uid']){
				$MyInviteLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableInviteLog).' where invite_uid = '.intval($_G['uid']).' and lid = '.intval($Id));
			}else{
				$MyInviteLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableInviteLog).' where invite_ip = \''.addslashes(strip_tags($_G['clientip'])).'\' and lid = '.intval($Id));
			}
			if(!$MyInviteLog){
				DB::insert($this->TableInviteLog,array(
					'lid'=>intval($Id),
					'uid'=>intval($Uid),
					'invite_uid'=>intval($_G['uid']),
					'invite_ip'=>addslashes(strip_tags($_G['clientip'])),
					'count'=>1,
					'dateline'=>time()
				));
			}
		}
		
	}

	/* ���ʼ�¼ */
	public function GetVisitLog($id){
		global $_G;
		
		if($_G['uid']){
			$MyVisitLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableVisitLog).' where uid = '.intval($_G['uid']).' and lid = '.intval($id));
		}else{
			$MyVisitLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableVisitLog).' where ip = \''.addslashes(strip_tags($_G['clientip'])).'\' and lid = '.intval($id));
		}
		if(!$MyVisitLog){
			DB::insert($this->TableVisitLog,array(
				'lid'=>intval($id),
				'uid'=>intval($_G['uid']),
				'ip'=>addslashes(strip_tags($_G['clientip'])),
				'count'=>1,
				'dateline'=>time(),
				'updateline'=>time()
			));
		}else{
			DB::query("UPDATE ".DB::table($this->TableVisitLog)." SET count = count + 1,updateline = ".time()." WHERE id = ".intval($MyVisitLog['id']));
		}
	}

	/* ���а� */
	public function GetAjaxRankingList($Get){
		global $_G;

		$Results['List'] = array();
		$Item = $this->GetViewthread($Get['lid']);

		if($Get['type'] == 1){//�����
			$Results['List'] = DB::fetch_all('SELECT uid,username,sum(money) money FROM '.DB::table($this->TableGiftLog).' where lid = '.intval($Get['lid']).' group by uid order by money desc, id desc limit 0 , '.$Item['param']['ranking_limit']);
		}else if($Get['type'] == 2){//�������
			$Results['List'] = DB::fetch_all('SELECT uid,username,sum(count_money) money FROM '.DB::table($this->TableComment).' where lid = '.intval($Get['lid']).' and display = 1 and type = 2 group by uid order by money desc, id desc limit 0 , '.$Item['param']['ranking_limit']);
		}else if($Get['type'] == 3){//������
			$Results['List'] = DB::fetch_all('SELECT uid,username,sum(money) money FROM '.DB::table($this->TableRedpacketLog).' where lid = '.intval($Get['lid']).' group by uid order by money desc, id desc limit 0 , '.$Item['param']['ranking_limit']);
		}else if($Get['type'] == 4){//ѡ�ִ������а�
			$Results['List'] = DB::fetch_all('SELECT P.uid,P.thumbnail,P.name username,sum(L.money) money FROM '.DB::table($this->TableGiftLog).' L LEFT JOIN `'.DB::table($this->TableParticipant).'` P on P.id = L.be_reward_id where L.lid = '.intval($Get['lid']).' and L.be_reward_id != \'\' group by L.be_reward_id order by money desc, L.id desc limit 0 , '.$Item['param']['ranking_limit']);
		}else if($Get['type'] == 5){//�����
			$Results['List'] = DB::fetch_all('SELECT L.uid,M.username,sum(L.count) money FROM '.DB::table($this->TableInviteLog).' L LEFT JOIN `'.DB::table('common_member').'` M on M.uid = L.uid where L.lid = '.intval($Get['lid']).' group by L.uid order by money desc, id desc limit 0 , '.$Item['param']['ranking_limit']);
		}
		$Results['List'] = $this->RankingListFormat($Results['List']);
		return $Results;
	}

	/* ���а��ʽ�� */
	private function RankingListFormat($Array){
		@require_once libfile('function/forum');
		foreach ($Array as $Key => $Val) {
			$Array[$Key]['username'] = DeleteHtml($Val['username']); 
			$Array[$Key]['face'] = $Val['thumbnail'] ? $Val['thumbnail'] : discuz_uc_avatar($Val['uid'],middle,true);

		}
		return $Array;
	}

	/* ֱ�������� */
	public function GetNumberViewthread($Id,$Where = null){
		
		$Item = DB::fetch_first('SELECT N.* FROM '.DB::table($this->TableNumber).' N where N.id = '.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['param']['state_array'] = $Item['param']['state'] ? TextareaArray($Item['param']['state']) : TextareaArray(str_replace("<br>","\r\n",$this->Config['LangVar']['StateTitleDefaul']));
		}
		return $Item;
	}

	/* ֱ�����б� */
	public function GetNumberList(){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableNumber).' where display = 1 order by topdateline > '.time().' desc,updateline desc,dateline desc');//��������
	}

	/* ѡ������ */
	public function GetViewParticipant($Id){
		return DB::fetch_first('SELECT * FROM '.DB::table($this->TableParticipant).' where id = '.intval($Id));
	}

	/* ѡ���б� */
	public function GetParticipantList($Id,$Where = null){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableParticipant).' where lid = '.intval($Id).' '.$Where.' order by updateline desc,dateline desc');//��������
	}

	/* ����Ա����ѡ�� */
	public function GetAjaxAdminParticipant($Op,$Pid,$Lid,$Field=null,$Value=null){
		global $_G;
		$Item = $this->GetViewthread($Lid);
		if(!$Item){//ֱ��������
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoLiveData']);
			return $Data;
		}
		
		if(!$Item['admin_participant_reward']){//Ȩ���ж�
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoPermission']);
			return $Data;
		}
		
		if($Op == 'Del'){//ɾ��
			if(DB::delete($this->TableParticipant,'id ='.intval($Pid))){
				foreach(DB::fetch_all('SELECT * FROM '.DB::table($this->TableGiftLog).' where be_reward_id = '.intval($Pid).' order by dateline desc') as $Key => $Val) {
					DB::delete($this->TableComment,'id ='.$Val['father_cid']);
					DB::delete($this->TableGiftLog,'id ='.$Val['id']);
				}
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
		}else{
			if(DB::update($this->TableParticipant,array($Field=>$Value),'id = '.intval($Pid))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
		}
		return $Data;
	}

	
	/* ���ѹۿ� */
	public function GetAjaxLivePayWatch($Id){
		global $_G;
		$Item = $this->GetViewthread($Id);
		if(!$Item){//ֱ��������
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoLiveData']);
			return $Data;
		}

		$CheckPayLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TableLivePayLog).' where lid = '.intval($Id).' and uid = '.intval($_G['uid']));
		if($CheckPayLog){
			$Data['Msg'] = urlencode($this->Config['LangVar']['CheckPayLogErr']);
			return $Data;
		}
		
		$Insert['lid'] = $Item['id'];
		$Insert['uid'] = intval($_G['uid']);
		$Insert['username'] = addslashes(strip_tags($_G['username']));
		$Insert['money'] = $Item['param']['money'];
		$Insert['dateline'] = time();

		$PayLog = $this->GetAjaxPayLog(array('money'=>$Item['param']['money'],'event'=>'live_pay_log','insert'=>$Insert,'lid'=>$Id),false);
		$Data['Money'] = $Item['param']['money'];
		$Data['PayId'] = $PayLog['Id'];
		$Data['State'] = 200;

		return $Data;
	}

	/* �ҵĸ��ѹۿ�Id */
	public function GetUserLivePayLogArray(){
		global $_G;
		$MyArray = DB::fetch_all('SELECT lid FROM '.DB::table($this->TableLivePayLog).' where uid = '.intval($_G['uid']).' order by id desc');
		foreach($MyArray as $Key => $Val) {
			$MyIdArray[] = $Val['lid'];
		}
		return $MyIdArray;
	}

	/* ����������� */
	public function GetUserLivePass($Id){
		global $_G;
		return DB::fetch_first('SELECT * FROM '.DB::table($this->TablePassLog).' where lid = '.intval($Id).' and uid = '.intval($_G['uid']));
	
	}

	/* ������� */
	public function GetAjaxPass($Get){
		global $_G;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->GetViewthread($Get['lid']);
		if(!$Item){//ֱ��������
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoLiveData']);
			return $Data;
		}

		$CheckPassLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TablePassLog).' where lid = '.intval($Get['lid']).' and uid = '.intval($_G['uid']));
	
		$UpData['lid'] = $Item['id'];
		$UpData['uid'] = intval($_G['uid']);
		$UpData['username'] = addslashes(strip_tags($_G['username']));
		$UpData['pass'] = addslashes(strip_tags($Get['pass']));

		if(!$UpData['pass']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['PasswordErr'][1]);
			return $Data;
		}else if($Item['param']['pass'] != $UpData['pass']){
			$Data['Msg'] = urlencode($this->Config['LangVar']['PasswordErr'][2]);
			return $Data;
		}

		if($CheckPassLog){
			$UpData['updateline'] = time();
			if(DB::update($this->TablePassLog,$UpData,'id = '.intval($CheckPassLog['id']))){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['PasswordErr'][3]);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['OpErr']);
			}
		}else{
			$UpData['dateline'] = $UpData['updateline'] = time();
			$Id = DB::insert($this->TablePassLog,$UpData,true);
			if($Id){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['PasswordErr'][3]);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['OpErr']);
			}
		}
		return $Data;
	}
	
	/* ����֧����¼ */
	public function GetAjaxPayLog($Get,$EncodeURI = true){
		global $_G;
	
		$Get = $EncodeURI ? EncodeURIToUrldeCode($Get) : $Get;

		$Param['event'] = addslashes(strip_tags($Get['event']));

		if($Param['event'] == 'live_pay_log'){//���ѹۿ�ֱ��
			$Param['insert'] = $Get['insert'];
			$Content = $this->Config['LangVar']['LiveId'].'(ID:'.$Get['lid'].')';
		}else if($Param['event'] == 'live_redpacket_send'){
			$Param['insert'] = $Get['insert'];
			$Content = $this->Config['LangVar']['RedpacketSendArray']['1'].'----'.$this->Config['LangVar']['LiveId'].'(ID:'.$Get['lid'].')';
		}else if($Param['event'] == 'live_gift'){
			$Param['gift_log_insert'] = $Get['gift_log_insert'];
			$Param['comment_insert'] = $Get['comment_insert'];
			$Param['participant_reward'] = $Get['participant_reward'];
			$Content = $this->Config['LangVar']['LiveId'].'(ID:'.$Get['lid'].')----'.$this->Config['LangVar']['GivingGift'].'(ID:'.$Get['gift_id'].')';
		}
		return $this->Pay->PayLogInsert($Get['money'],$Param,$Content,'fn_live');

	}
}

$Fn_Live = new Fn_Live;

?>