<?php
/**
 *	[������ֱ��(fn_live.{modulename})] Copyright 2001-2099 DisM!Ӧ������.
 *	Version: 1.0   _���²����http://t.cn/Aiux1Jx1.0
 *	Date: 2019-8-25 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_live/Function.inc.php');

$navtitle = $metakeywords = $metadescription = $Fn_Live->Config['PluginVar']['Title'];

$_GET['m'] = $_GET['m'] ? $_GET['m'] : 'index';

$Mod = array('index','list','list_view','view');

if(!in_array($_GET['m'],$Mod)){
	exit('No Data');
}

if(!$_G['uid'] && in_array($_GET['m'],array(''))){
	Fn_Login();
}

if($_GET['m'] == 'index'){//��ҳ
	$NumberList = $Fn_Live->GetNumberList();
}else if($_GET['m'] == 'list_view'){
	$Item = $Fn_Live->GetNumberViewthread($_GET['nid']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['title'];
		if(!$Item['display'] && !$Fn_Live->Admin){
			$Msg = $Fn_Live->Config['LangVar']['NumberInAudit'];
		}else{
			$Fn_Live->Config['PluginVar']['Color'] = $Item['param']['color'];

			//�б�
			$Get['limt'] = 1000;
			if(!$Item['param']['navs']){
				$AllList = $Fn_Live->GetAjaxList(array('limit'=>1000,'number_id'=>$Item['id']));
			}
			
			//�����
			Click($Fn_Live->TableNumber,$Item['id'],1);

			//����
			$Fn_Live->Config['WxShare']['WxUrl'] = $Fn_Live->Config['ListViewUrl'].$Item['id'];
			$Fn_Live->Config['WxShare']['WxTitle'] = $Item['title'] ? $Item['title'].'-'.$Fn_Live->Config['WxShare']['WxTitle'] : $Fn_Live->Config['WxShare']['WxTitle'];
			$Fn_Live->Config['WxShare']['WxDes'] = $Item['content'] ? $Item['content'] : $Fn_Live->Config['WxShare']['WxDes'];
			$Fn_Live->Config['WxShare']['WxImg'] = $Item['logo'] ? $Item['logo'] : $Fn_Live->Config['WxShare']['WxImg'];
			$Fn_Live->Config['WxShare']['WxImg'] = strpos($Fn_Live->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Live->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Live->Config['WxShare']['WxImg'];
			//����End
		}
	}else{
		
		$navtitle = $Msg = $Fn_Live->Config['LangVar']['NoNumberData'];
	}
}else if($_GET['m'] == 'view'){
	$Item = $Fn_Live->GetViewthread($_GET['lid']);
	if($Item){
		$navtitle = $metadescription = $metakeywords = $Item['title'];
		if((!$Item['display'] || !$Item['number_display']) && !$Fn_Live->Admin){
			$Msg = $Fn_Live->Config['LangVar']['LiveInAudit'];
		}else{

			/* ���Զ�ά����� */
			if(!checkmobile() && $Item['param']['PcQrSwitch']){
				$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
				if(!file_exists($File) || !filesize($File)) {
					@require_once libfile('class/qrcode','plugin/fn_assembly');
					QRcode::png($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"], $File, QR_ECLEVEL_L,5,2);
				}
				$QrCode = base64_encode(file_get_contents($File));
				@unlink($File);
				include template('fn_live:index_qrcode');
				exit();
			}
			/* ���Զ�ά����� End */

			$Item = $Fn_Live->FormatPlayer($Item);

			$Fn_Live->Config['PluginVar']['Color'] = $Item['param']['color'];
			$Fn_Live->Config['PluginVar']['FColor'] = $Item['param']['fcolor'];
			$FirstKey = key($Item['param']['navs_array']);
			
			if($Item['param']['gift'] && (array_key_exists(1,$Item['param']['navs_array']) || array_key_exists(6,$Item['param']['navs_array']))){
				$GiftList = $Item['param']['gift_list'] ? $Fn_Live->GetGiftList(' where id in('.implode(',',$Item['param']['gift_list']).')') : '';//�����б�
			}
			
			if($Item['param']['gift'] && array_key_exists(6,$Item['param']['navs_array'])){//ѡ���б�
				$ParticipantList = $Fn_Live->GetParticipantList($Item['id'],$Item['admin_participant_reward'] ? '' : ' and display = 1');
			}

			//���ʼ�¼
			if($Item['param']['visit']){
				$Fn_Live->GetVisitLog($Item['id']);
			}

			//������ۼ�
			$ClickRand = array_filter(explode("-",$Item['param']['click_rand']));
			$ClickNum = $ClickRand ? rand($ClickRand[0],$ClickRand[1]): 1;
			Click($Fn_Live->TableLive,$Item['id'],$ClickNum);

			if($_G['uid']){
				//�����¼
				$MyPayLog = in_array($Item['id'],$Fn_Live->GetUserLivePayLogArray()) || $Item['admin'] ? true : false;
				
				//�����¼
				$MyPassLog = $Item['param']['visit_limit'] == 3 ? $Fn_Live->GetUserLivePass($Item['id']) : '';
				$MyPassword = $MyPassLog || $Item['admin'] ? true : false;
				
				$MyPassword = ($Item['param']['pass'] != $MyPassLog['pass']) || (time() >= strtotime("+".$Item['param']['pass_time']." second",$MyPassLog['updateline']) && $Item['param']['pass_time']) ? false : true;

			}

			if($Item['param']['poster']){
				$Item['param']['poster_invite'] && $_GET['uid'] ? $Fn_Live->GetPosterInviteLog($Item['id'],$_GET['uid']) : '';
				//��ά��
				if($Item['param']['qr_code_switch']){
					$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.intval($Item['id']).($_G['uid'] && $Item['param']['poster_invite'] ? '_'.$_G['uid'] : '').'.jpg';
					if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
						@unlink($File);
						@require_once libfile('class/wechat','plugin/fn_assembly');
						$WechatClient = new Fn_WeChatClient($Fn_Live->Config['PluginVar']['WxAppid'] ? $Fn_Live->Config['PluginVar']['WxAppid'] : $Config['PluginVar']['WxAppid'] , $Fn_Live->Config['PluginVar']['WxSecret'] ? $Fn_Live->Config['PluginVar']['WxSecret'] : $Config['PluginVar']['WxSecret']);
						$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.$Item['id'].'|'.$_G['uid'],'expire'=>2592000)));
						DownloadImg($QrUrl,$File);
					}
					$QrCode = base64_encode(file_get_contents($File));
				}else{
					$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
					if(!file_exists($File) || !filesize($File)) {
						@require_once libfile('class/qrcode','plugin/fn_assembly');
						QRcode::png($Fn_Live->Config['ViewUrl'].$Item['id'].($_G['uid'] && $Item['param']['poster_invite'] ? '&uid='.$_G['uid'] : ''), $File, QR_ECLEVEL_L,5,2);
					}
					$QrCode = base64_encode(file_get_contents($File));
					@unlink($File);
				}

				@require_once libfile('function/forum');
				$Face = discuz_uc_avatar($_G['uid'],'middle',true);
			}

			//����
			$Fn_Live->Config['WxShare']['WxUrl'] = $Fn_Live->Config['ViewUrl'].$Item['id'].($_G['uid'] && $Item['param']['poster_invite'] ? '&uid='.$_G['uid'] : '');
			$Fn_Live->Config['WxShare']['WxTitle'] = $Item['param']['share_title'] ? $Item['param']['share_title'] : $Fn_Live->Config['WxShare']['WxTitle'];
			$Fn_Live->Config['WxShare']['WxDes'] = $Item['param']['share_desc'] ? $Item['param']['share_desc'] : $Fn_Live->Config['WxShare']['WxDes'];
			$Fn_Live->Config['WxShare']['WxImg'] = $Item['param']['share_img'] ? $Item['param']['share_img'] : $Fn_Live->Config['WxShare']['WxImg'];
			$Fn_Live->Config['WxShare']['WxImg'] = strpos($Fn_Live->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Live->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Live->Config['WxShare']['WxImg'];
			//����End

			if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){//֧������
				@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
				$PayList = $FnPay->GetPayList();
			}

			//ͼƬ�ϴ�
			if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php') && $Item['admin_info']){
				@require_once libfile('class/upload','plugin/fn_assembly');
				$UploadConfig = fn_upload::Config();
			}
		}
	}else{
		
		$navtitle = $Msg = $Fn_Live->Config['LangVar']['ֱ��������'];
	}
}
include template('fn_live:'.$_GET['m']);
?>