<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_live` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(11) unsigned NOT NULL,
  `number_id` int(11) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `param` mediumtext NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `start_dateline` int(11) unsigned NOT NULL,
  `end_dateline` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_live_comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rid` int(11) unsigned NOT NULL,
  `lid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `redpacket_number` int(11) unsigned NOT NULL,
  `redpacket_type` tinyint(1) unsigned NOT NULL,
  `redpacket_list` mediumtext NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `count_money` decimal(11,2) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_live_gift` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `ico` varchar(255) NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `displayorder` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_live_gift_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `be_reward_id` int(11) unsigned NOT NULL,
  `lid` int(11) unsigned NOT NULL,
  `gift_id` int(11) unsigned NOT NULL,
  `father_cid` int(11) unsigned NOT NULL,
  `money` decimal(11,2) NOT NULL,
  `branch_money` decimal(11,2) unsigned NOT NULL,
  `branch_state` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_live_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `lid` int(11) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `live_name_id` int(11) unsigned NOT NULL,
  `content` text NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `param` mediumtext NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_live_invite_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `invite_uid` int(11) unsigned NOT NULL,
  `invite_ip` varchar(20) NOT NULL,
  `count` int(10) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_live_number` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `param` mediumtext NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `topdateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_live_participant` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `param` mediumtext NOT NULL,
  `ticket` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_live_pass_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `pass` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_live_pay_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `class_id` int(11) unsigned NOT NULL,
  `number_id` int(11) unsigned NOT NULL,
  `lid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `dateline` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_live_redpacket_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(255) NOT NULL,
  `lid` int(11) unsigned NOT NULL,
  `cid` int(11) unsigned NOT NULL,
  `father_cid` int(11) unsigned NOT NULL,
  `money` decimal(11,2) NOT NULL,
  `redpacket_type` tinyint(2) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_live_visit_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `ip` varchar(20) NOT NULL,
  `count` int(10) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
?>