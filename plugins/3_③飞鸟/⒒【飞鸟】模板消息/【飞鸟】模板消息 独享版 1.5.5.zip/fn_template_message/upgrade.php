<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_template_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `template_id` varchar(80) NOT NULL,
  `type` int(1) NOT NULL,
  `title` varchar(200) NOT NULL,
  `primary_industry` varchar(200) NOT NULL,
  `deputy_industry` varchar(200) NOT NULL,
  `content` varchar(2000) NOT NULL,
  `example` varchar(2000) NOT NULL,
  `param` varchar(5000) NOT NULL,
  `last_send` int(11) unsigned NOT NULL,
  `send_count` int(11) unsigned NOT NULL,
  `succeed_count` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `template_id` (`template_id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_fn_template_message_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  `content` varchar(8000) NOT NULL,
  `dateline` int(11) NOT NULL,
  `openid` varchar(32) NOT NULL,
  `uid` int(11) NOT NULL,
  `template_id` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_fn_template_message_user` (
  `uid` int(11) NOT NULL,
  `param` varchar(2000) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_fn_template_message_fans` (
  `openid` varchar(32) NOT NULL,
  `info` varchar(8000) NOT NULL,
  `subscribe_time` int(11) unsigned NOT NULL,
  `send_count` int(11) unsigned NOT NULL,
  `last_send` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  UNIQUE KEY `openid` (`openid`)
) ENGINE=InnoDB;

EOF;

runquery($sql);


$FansTableField = DB::fetch_all("SHOW COLUMNS FROM %t", array('fn_template_message_fans'));
$FansToArray = MysqlToArray($FansTableField);
if(!in_array('dateline',$FansToArray)) {
	$UpSql = <<<EOF
	ALTER TABLE `pre_fn_template_message_fans` ADD `dateline` INT( 11 ) UNSIGNED NOT NULL AFTER `last_send` ;
EOF;
	runquery($UpSql);
}

function MysqlToArray($Array) {
    $temp = array();
    foreach ($Array as $k => $s) {
        $temp[] = $s['Field'];
    }
    return $temp;
}

$finish = TRUE;/*dism-Taobao-com*/
?>