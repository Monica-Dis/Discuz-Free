<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_template_message/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_template_message/Common.php');
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
if(submitcheck('Submit') || ($_GET['postdosubmit']=='yes' && $_GET['formhash'] == formhash())){
	$Limit = 20;
	$Current = isset($_GET['Current']) && $_GET['Current'] > 0 ? intval($_GET['Current']) : 0;
	$Next = $Current + $Limit;
	$Item = $_GET['item'];
	$Item['template'] = $Item['param'] ? $Item['param'][$Item['template_id']] : $Item['template'];
    unset($Item['param']);
    $TemplateId = $Item['template_id'];
	$FieldUidName = $Fn_Template_Message->Config['PluginVar']['WxTable'] == 'user_weixin_relations' ? 'userid' : 'uid';
	switch($Item['target']){
		case 'target_uid':
            $Uids = explode(',', trim($Item['uid']));
            foreach ($Uids as $Key => $Val) {
                $Uids[$Key] = intval($Val);
            }
            if($Uids){
                $OpenIds = DB::fetch_all("SELECT openid,".$FieldUidName." FROM %t WHERE ".$FieldUidName." IN (%n) AND openid<>''", array($Fn_Template_Message->Config['PluginVar']['WxTable'], $Uids),$FieldUidName);
            }
			break;
		case 'target_openid':
            $Uids = array();
            foreach (explode("\n", trim($Item['openid'])) as $Key => $Val) {
                $Uids[$Key] = trim($Val);
            }
            if($Uids){
                $OpenIds = DB::fetch_all("SELECT openid,".$FieldUidName." FROM %t WHERE openid IN (%n)", array($Fn_Template_Message->Config['PluginVar']['WxTable'], $Uids),$FieldUidName);
            }
            break;
		case 'target_group':
            if($Item['group']){
                $OpenIds = DB::fetch_all("SELECT w.openid,m.uid FROM %t AS w, %t AS m WHERE m.uid=w.".$FieldUidName." AND m.groupid IN (%n) AND w.openid<>'' ORDER BY m.uid ASC LIMIT $Current,$Limit ", array($Fn_Template_Message->Config['PluginVar']['WxTable'],'common_member',$Item['group']), 'uid');
            }
            $State = $OpenIds ? 1 : 0;
            break;
		case 'target_all':
            $OpenIds = DB::fetch_all("SELECT w.openid,m.uid FROM %t AS w, %t AS m WHERE m.uid=w.".$FieldUidName." AND w.openid<>'' ORDER BY m.uid ASC LIMIT $Current,$Limit ", array($Fn_Template_Message->Config['PluginVar']['WxTable'],'common_member'), 'uid');
			$State = $OpenIds ? 1 : 0;
			break;
		case 'target_all_fans':
            $OpenIds = DB::fetch_all("SELECT f.openid FROM %t AS f ORDER BY f.dateline ASC LIMIT $Current,$Limit", array($Fn_Template_Message->TableTemplateMessageFans), 'openid');
			$State = $OpenIds ? 1 : 0;
			break;
		case 'target_uids':
            list($Minuid, $Maxuid) = explode('-', trim($Item['uids']));
            if($Minuid && $Maxuid && ($Minuid<=$Maxuid)){
                $Minuid = intval($Minuid);
                $Maxuid = intval($Maxuid);
                $OpenIds = DB::fetch_all("SELECT w.openid,m.uid FROM %t AS w, %t AS m WHERE m.uid=w.".$FieldUidName." AND m.uid>=$Minuid AND m.uid<=$Maxuid AND w.openid<>'' ORDER BY m.uid ASC LIMIT $Current,$Limit ", array($Fn_Template_Message->Config['PluginVar']['WxTable'],'common_member'), 'uid');
                $State = $OpenIds ? 1 : 0;
            }
			break;
	}
	foreach ($OpenIds as $Uid => $OpenidItem) {
		$OpenId = $OpenidItem['openid'];
		$Member = getuserbyuid($Uid);
		$Data = $Item['template'];
		foreach ($Data as $Key => $Val) {
			$Val['value'] = str_replace(array(
				'{note}',
				'{time}',
				'{author}',
				'{username}',
				'{type}',
			), array(
				'',
				date('Y-m-d H:i:s', TIMESTAMP),
				$_G['username'],
				$Member['username'],
				$Fn_Template_Message->Config['LangVar']['System'],
			), $Val['value']);
			$Data[$Key]['value'] = diconv($Val['value'], CHARSET, 'UTF-8');
		}
		$TemplateParam = array(
			'touser' => $OpenId,
			'template_id' => $TemplateId,
			'url' => $Item['url'],
			'topcolor' => '#ff0000',
			'data' => $Data
		);
		$Data['url'] = array('value' => $Item['url']);
		$SuccessData = array(
			'uid' => intval($Member['uid']),
			'openid' => $OpenId,
			'template_id' => $TemplateId,
			'dateline' => TIMESTAMP,
			'content' => json_encode($Data),
		);
		$Result = $Fn_Template_Message->GetSendTemplate($TemplateParam);//����
		if(isset($Result['errcode']) && (int)$Result['errcode'] === 0){
			$SuccessData['code'] = 0;
			$SuccessData['msg'] = addslashes($Fn_Template_Message->Config['LangVar']['LogState'][1]);//�豣��Html
			DB::query("UPDATE %t SET last_send=%s,send_count=send_count+1,succeed_count=succeed_count+%d WHERE template_id=%s", array($Fn_Template_Message->TableTemplateMessage, TIMESTAMP,1,$TemplateId));
			DB::query('UPDATE %t SET last_send=%s, send_count=send_count+1 WHERE openid=%s', array($Fn_Template_Message->TableTemplateMessageFans,TIMESTAMP,$OpenId));
		}else{
			$SuccessData['code'] = $Result['errcode'];
			$SuccessData['msg'] = addslashes(strip_tags($Result['errmsg']));
			DB::query("UPDATE %t SET last_send=%s,send_count=send_count+1,succeed_count=succeed_count+%d WHERE template_id=%s", array($Fn_Template_Message->TableTemplateMessage, TIMESTAMP,0,$TemplateId));
		}
		DB::insert($Fn_Template_Message->TableTemplateMessageLog,$SuccessData);
	}
	if($State) {
        $AppendUrl = http_build_query(array('item' =>$Item));
        $CpMsgUrl = $CpMsgUrl."&Current=$Next&postdosubmit=yes&formhash=".FORMHASH.'&'.$AppendUrl;
		cpmsg(sprintf($Fn_Template_Message->Config['LangVar']['ManualPushProcessing'],$Current,$Next), $CpMsgUrl,'loading');
    }else{
        cpmsg($Fn_Template_Message->Config['LangVar']['ManualPushSucceed'],$CpMsgUrl, 'succeed');
    }
}else{
	$ModulesList = GetModulesList(1,100,'','id');
	foreach($ModulesList as $Key => $Val) {
		$Ext = array();
		foreach($ModulesList as $K => $V) {
			$Ext['ext'.$V['id']] = $V['id'] == $Val['id'] ? '' : 'none';
		}
		$List[] = array($Key,$Val['title'], $Ext);
	}
	$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
	showformheader($FormUrl);
	showtableheader();
	showsetting($Fn_Template_Message->Config['LangVar']['TemplateTitle'], array('item[template_id]',$List, true), $List[0][0], 'mradio');
	$Check = 1;
	foreach ($ModulesList as $Module) {
		$Id = $Module['id'];
		$TemplateId = $Module['template_id'];
		$Module['param'] = unserialize($Module['param']);
		$Tpl = '<table>';
		foreach (explode("\n", $Module['content']) as $Key => $Val) {
			list($First, $Secnd) = explode($Fn_Template_Message->Config['LangVar']['Dou'], $Val);
			if(!$Secnd){
				$Secnd = $First;
			}
			$Secnd = str_replace(array('{{','.DATA}}'), '', $Secnd);
			$First = str_replace(array('{{','.DATA}}'), '', $First);
			$Ck = $Module['id']."_".$Key;
			$Tpl .= '<tr class="noborder nopadding"><td>'.$First.'</td><td><input name="item[param]['.$TemplateId.']['.$Secnd.'][value]" value="'.$Module['param'][$Secnd]['value'].'"/>
			</td><td>
			<input name="item[param]['.$TemplateId.']['.$Secnd.'][color]" id="'.$Ck.'_v" type="text" class="txt" style="float:left;" value="'.$Module['param'][$Secnd]['color'].'" onchange="updatecolorpreview(\''.$Ck.'\')">
			<input id="'.$Ck.'" type="button" class="colorwd" onclick="return showcolor1(\''.$Ck.'\');" style="background:'.$Module['param'][$Secnd]['color'].'">
			<span id="'.$Ck.'_menu" style="display: none"><iframe id="'.$Ck.'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>
			</td></tr>';
		}
		$Tpl .= '</table>';
		showtagheader('tbody', 'ext'.$Module['id'], $Check, 'sub');
		echo <<<HTML
		<tr><td class="vtop" colspan="2"><div style="width:500px">$Tpl</div></td></tr>
HTML;
		showtagfooter('tbody');
		$Check = 0;
	}
	showsetting($Fn_Template_Message->Config['LangVar']['PushUrl'], 'item[url]', $_G['siteurl'], 'text', '','',$Fn_Template_Message->Config['LangVar']['PushUrlPrompt']);
	
	showsetting($Fn_Template_Message->Config['LangVar']['PushTarget'], array('item[target]', array(
    array('target_uid',$Fn_Template_Message->Config['LangVar']['SpecifiedUser'], array('target_all'=> 'none', 'target_group' => 'none', 'target_uid' => '', 'target_openid' => 'none', 'target_uids' => 'none')),
    array('target_uids', $Fn_Template_Message->Config['LangVar']['UidRange'], array('target_all'=> 'none', 'target_group' => 'none', 'target_uid' => 'none', 'target_openid' => 'none', 'target_uids' => '')),
    array('target_openid', 'OpenId', array('target_all'=> 'none', 'target_group' => 'none', 'target_uid' => 'none', 'target_openid' => '', 'target_uids' => 'none')),
    array('target_group', $Fn_Template_Message->Config['LangVar']['UserGroup'], array('target_all'=> 'none', 'target_group' => '', 'target_uid' => 'none', 'target_openid' => 'none', 'target_uids' => 'none')),
    array('target_all', $Fn_Template_Message->Config['LangVar']['AllBindingUser'], array('target_all'=> '', 'target_group' => 'none', 'target_uid' => 'none', 'target_openid' => 'none', 'target_uids' => 'none')),
	array('target_all_fans', $Fn_Template_Message->Config['LangVar']['AllFans'], array('target_all'=> '', 'target_group' => 'none', 'target_uid' => 'none', 'target_openid' => 'none', 'target_uids' => 'none')),
), TRUE), 'target_uid', 'mradio');
	
	showtagheader('tbody', 'target_all', 0, '');
	showtagfooter('tbody');

	showtagheader('tbody', 'target_group', 0, '');
	$Groups = $Forums = array();
	foreach(C::t('common_usergroup')->range() as $Group) {
		$Groups[] = array($Group['groupid'], $Group['grouptitle']);
	}
	showsetting(lang('plugin/xigua_x', 'group1'), array('item[group][]', $Groups), '', 'mselect');
	showtagfooter('tbody');

	showtagheader('tbody', 'target_uid', 1, '');
	showsetting($Fn_Template_Message->Config['LangVar']['UserUid'], 'item[uid]', '', 'text','','', $Fn_Template_Message->Config['LangVar']['UserUidPrompt']);
	showtagfooter('tbody');

	showtagheader('tbody', 'target_uids', 0, '');
	showsetting($Fn_Template_Message->Config['LangVar']['UidRange'], 'item[uids]', '', 'text','','', $Fn_Template_Message->Config['LangVar']['UidRangePrompt']);
	showtagfooter('tbody');

	showtagheader('tbody', 'target_openid',0,'');
	showsetting('OpenId', 'item[openid]', '', 'textarea','','',$Fn_Template_Message->Config['LangVar']['OpenIdPrompt']);
	showtagfooter('tbody');

	showsubmit('Submit');
	showtablefooter();/*Dism_taobao_com*/
	/*dism��taobao-com*/showformfooter();
	echo "
	<style>.tb2 .rowform{width:600px}</style>
	<script>
    function showcolor1(ck) {
        document.getElementById(ck+'_frame').src='static/image/admincp/getcolor.htm?'+ck+'|'+ck+'_v';
        showMenu({ctrlid:ck});
    }
	</script>
	";
}
/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Template_Message;
	return DB::fetch_all('SELECT * FROM '.DB::table($Fn_Template_Message->TableTemplateMessage).$Where.' ORDER BY '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit, array(), 'template_id');//��������
}
//From: Dism��taobao��com
?>