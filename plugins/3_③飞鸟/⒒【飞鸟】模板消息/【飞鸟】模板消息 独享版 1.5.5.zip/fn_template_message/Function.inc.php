<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class Fn_Template_Message{
	public function __construct() {
		global $_G,$plugin;
		loadcache('plugin');
		$this->Config['PluginVar'] = (array) $_G['cache']['plugin']['fn_template_message'];
		$this->Config['LangVar'] = lang('plugin/fn_template_message');
		$this->Config['Path'] = 'source/plugin/fn_template_message';
		$this->Config['StaticPath'] = $this->Config['Path'].'/static';
		$this->Config['StaticCaChe'] = $this->Config['Path'].'/cache/';
		$this->Config['ApiUrl'] = 'https://api.weixin.qq.com';
		$this->TableTemplateMessage = 'fn_template_message';
		$this->TableTemplateMessageLog = 'fn_template_message_log';
		$this->TableTemplateMessageUser = 'fn_template_message_user';
		$this->TableTemplateMessageFans = 'fn_template_message_fans';

		if(!is_dir(DISCUZ_ROOT.$this->Config['StaticCaChe'])){
			mkdir(DISCUZ_ROOT.$this->Config['StaticCaChe']);
		}

	}
	
	/* ��ȡģ���б� */
	public function GetAllPrivateTemplate() {
        $AccessToken = $this->GetAccessToken();
        $Res = $this->HttpGet($this->Config['ApiUrl'].'/cgi-bin/template/get_all_private_template?access_token='.$AccessToken);
        if($this->CheckIsSuc($Res)){
            return json_decode($Res,true);
        }
        return false;
    }
	/* ����ģ����Ϣ */
	public function GetSendTemplate($Data, $NoCache = 0){
		$AccessToken = $this->GetAccessToken();
		$Result = $this->HttpPost($this->Config['ApiUrl'].'/cgi-bin/message/template/send?access_token='.$AccessToken,json_encode($Data));
		if($Result === null){
            $Result = $this->GetSendTemplate($Data, 1);
        }
		return json_decode($Result,true);
	}
	/* ��ȡ��˿�б� */
	public function GetAllFans($NextOpenid=null){
		$AccessToken = $this->GetAccessToken();
		$Res = $this->HttpGet($this->Config['ApiUrl'].'/cgi-bin/user/get?access_token='.$AccessToken.'&next_openid='.$NextOpenid);
		return json_decode($Res,true);
	}
	/* ��ȡ��˿��Ϣ */
	public function GetFansInfo($OpenId){
		$AccessToken = $this->GetAccessToken();
		$Res = $this->HttpGet($this->Config['ApiUrl'].'/cgi-bin/user/info?access_token='.$AccessToken.'&openid='.$OpenId.'&lang=zh_CN');
		return json_decode($Res,true);
	}
	/* ��ȡAccessToken */
	public function GetAccessToken() {
//		$Data = json_decode(file_get_contents(DISCUZ_ROOT."./source/plugin/fn_template_message/access_token.json"));
//		if($Data->expire_time < time()){
			$Url = $this->Config['ApiUrl'].'/cgi-bin/token?grant_type=client_credential&appid='.$this->Config['PluginVar']['WxAppid'].'&secret='.$this->Config['PluginVar']['WxSecret'];
			$Res = json_decode($this->HttpGet($Url));
			$AccessToken = $Res->access_token;
//			if($AccessToken) {
//				$Data->expire_time = time() + 7000;
//				$Data->AccessToken = $AccessToken;
//				$Fp = fopen(DISCUZ_ROOT."./source/plugin/fn_template_message/access_token.json", "w");
//				fwrite($Fp, json_encode($Data));
//				fclose($Fp);
//			}
//		}else{
//		  $AccessToken = $Data->AccessToken;
//		}
		return $AccessToken;
	}
	public function HttpGet($Url){
		$Res = dfsockopen($Url);
		if(!$Res){
			$Curl = curl_init();
			curl_setopt($Curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($Curl, CURLOPT_TIMEOUT, 500);
			curl_setopt($Curl, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($Curl, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($Curl, CURLOPT_URL, $Url);
			$Res = curl_exec($Curl);
			curl_close($Curl);
		}
		return $Res;
	}
	public function HttpPost($Url, $Data){
        if (!function_exists('curl_init')) {
            return '';
        }
        $Ch = curl_init();
        curl_setopt($Ch, CURLOPT_URL, $Url);
        curl_setopt($Ch, CURLOPT_RETURNTRANSFER, 1);
        # curl_setopt( $Ch, CURLOPT_HEADER, 1);

        curl_setopt($Ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($Ch, CURLOPT_SSL_VERIFYHOST, FALSE);

        curl_setopt($Ch, CURLOPT_POST, 1);
        curl_setopt($Ch, CURLOPT_POSTFIELDS, $Data);
        $Data = curl_exec($Ch);
        if (!$Data) {
            error_log(curl_error($Ch));
        }
        curl_close($Ch);
        return $Data;
	}

	public function CheckIsSuc($Res){
        $Result = true;
        if (is_string($Res)) {
            $Res = json_decode($Res, true);
        }
        if (isset($Res['errcode']) && (0 !== (int)$Res['errcode'])) {
            $Result = false;
            if($Res['errcode'] == '40001'){
                $Result = null;
            }
        }
        return $Result;
    }

	/* ��ʼ���� */
	public function GetAutoPush(){
		global $_G;
		if($this->Config['PluginVar']['AutoPushSwitch'] && $this->Config['PluginVar']['WxAppid'] && $this->Config['PluginVar']['WxSecret'] && $this->Config['PluginVar']['WxTable']){
			$FieldUidName = $this->Config['PluginVar']['WxTable'] == 'user_weixin_relations' ? 'userid' : 'uid';
			$ReplaceArray  = array('&nbsp;',$this->Config['LangVar']['View'], $this->Config['LangVar']['Click'], '&rsaquo;', '&raquo;', strip_tags($this->GetUnescape('&#26597;&#30475;')));
			$TemplateSys = DB::fetch_first("SELECT * FROM %t WHERE type=%d", array($this->TableTemplateMessage,2));
			$TemplateRep = DB::fetch_first("SELECT * FROM %t WHERE type=%d", array($this->TableTemplateMessage,1));
			$Where = $this->Config['PluginVar']['PushTime'] ? ' AND h.dateline >= '.strtotime($this->Config['PluginVar']['PushTime']).' ' : '';
			$TaskList = DB::fetch_all("SELECT h.*,w.openid FROM %t AS h,%t AS w WHERE h.uid=w.".$FieldUidName." AND h.new=1 ".$Where." AND h.uid>0 AND w.openid<>'' ORDER BY h.id DESC LIMIT 0,1",array('home_notification',$this->Config['PluginVar']['WxTable']));
			foreach ($TaskList as $Item) {
				if($Item){
					DB::query('UPDATE %t SET new=0 WHERE id=%d',array('home_notification', $Item['id']));
					$Groups = unserialize($this->Config['PluginVar']['Groups']);
					$ActionType = unserialize($this->Config['PluginVar']['Type']);
					$TemplateSysParam = unserialize($TemplateSys['param']);
					$TemplateRepParam = unserialize($TemplateRep['param']);
					$OpenId = addslashes(strip_tags($Item['openid']));
					$Note = str_replace($ReplaceArray,'',$this->GetUnescape(strip_tags($Item['note'])));
					if($TemplateUser = $this->GetUser($Item['uid'])){
						 $TemplateUser['param'] = unserialize($TemplateUser['param']);
						 if((isset($TemplateUser['param'][$Item['type']]) && (int)$TemplateUser['param'][$Item['type']]==0) || (strpos($Item['type'], 'verify') !==false && (int)$TemplateUser['param']['verify'] == 0)){
							$ErrorData = array(
								'uid'=>intval($Item['uid']),
								'openid'=>$OpenId,
								'template_id'=>$TemplateId,
								'dateline'=> TIMESTAMP,
								'content'=> json_encode(array()),
								'code' => '-1',
								'msg' => addslashes(strip_tags($this->Config['LangVar']['LogState'][3]))
							);
							DB::insert($this->TableTemplateMessageLog,$ErrorData);
							continue;
						 }
					}
					$SystemArray = $RepArray = array();
					foreach($ActionType as $Key => $Val) {
						if(in_array($Val, array('post', 'pcomment'))){
							$RepArray[] = $Val;
						}else{
							$SystemArray[] = $Val;
						}
					}
					if((in_array($Item['type'],$SystemArray) || strpos($Item['type'], 'verify') !== false ) && $TemplateSysParam){
						$TemplateId = addslashes(strip_tags($TemplateSys['template_id']));
						$Member = getuserbyuid($Item['uid']);
						if(!in_array($Member['groupid'],$Groups)){
							$ErrorData = array(
								'uid'=>intval($Member['uid']),
								'openid'=>$OpenId,
								'template_id'=>$TemplateId,
								'dateline'=> TIMESTAMP,
								'content'=> json_encode(array()),
								'code' => '-1',
								'msg' => addslashes(strip_tags($this->Config['LangVar']['LogState'][5]))
							);
							DB::insert($this->TableTemplateMessageLog,$ErrorData);
							continue;
						}
						$Author = getuserbyuid($Item['authorid']);
						if(preg_match_all("/<a(.+?)href=(['\"]?)([^>\s]+)\\2([^>]*)>/i", $Item['note'], $MatchAll)){
							$Link = array_pop($MatchAll[3]);
							if($Link == 'about:blank'){
								$Link = array_pop($MatchAll[3]);
							}
							$Url = ($Link ? $this->GetReplaceLink($Link) : './home.php?mod=space&do=notice&view=system');
							
						}else{
							$Url = $_G['siteurl'].'./home.php?mod=space&do=notice&view=system';
						}
						$I = 0;
						foreach ($TemplateSysParam as $Key => $Val) {
							$Val['value'] = str_replace(array(
								'{note}',
								'{time}',
								'{author}',
								'{username}',
								'{type}'
							), array(
								$Note,
								dgmdate($Item['dateline'], 'Y-m-d H:i:s'),
								$Author['username'],
								$Member['username'],
								$this->Config['LangVar']['System'],
							), $Val['value']);

							if(!$Val['value']){
								$I++;
							}
							$TemplateSysParam[$Key]['value'] = diconv($Val['value'], CHARSET, 'UTF-8');
						}
						if($I > (count($TemplateSysParam) - 1)){
							$ErrorData = array(
								'uid'=>intval($Member['uid']),
								'openid'=>$OpenId,
								'template_id'=>$TemplateId,
								'dateline'=> TIMESTAMP,
								'content'=> json_encode(array()),
								'code' => '-1',
								'msg' => addslashes(strip_tags($this->Config['LangVar']['LogState'][5]))
							);
							DB::insert($this->TableTemplateMessageLog,$ErrorData);
							continue;
						}
						$Data = $TemplateSysParam;
					}else if(in_array($Item['type'], $RepArray) && $TemplateRepParam){
						$TemplateId = addslashes(strip_tags($TemplateRep['template_id']));
						$Member = getuserbyuid($Item['uid']);
						if(!in_array($Member['groupid'],$Groups)){
							$ErrorData = array(
								'uid'=>intval($Member['uid']),
								'openid'=>$OpenId,
								'template_id'=>$TemplateId,
								'dateline'=> TIMESTAMP,
								'content'=> json_encode(array()),
								'code' => '-1',
								'msg' => addslashes(strip_tags($this->Config['LangVar']['LogState'][4]))
							);
							DB::insert($this->TableTemplateMessageLog,$ErrorData);
							continue;
						}
						$Author = getuserbyuid($Item['authorid']);
						if($Item['from_idtype'] == 'quote'){
							$Tid = DB::result_first('SELECT tid FROM %t WHERE pid=%d',array('forum_post', $Item['from_id']));
							$Url = $_G['siteurl'].'forum.php?mod=viewthread&tid='.$Tid;
						}else if(preg_match_all("/<a(.+?)href=(['\"]?)([^>\s]+tid[^>\s]+)\\2([^>]*)>/i", $Item['note'], $MatchAll)){
							$Link = array_pop($MatchAll[3]);
							if($Link == 'about:blank'){
								$Link = array_pop($MatchAll[3]);
							}
							$Url = $this->GetReplaceLink($Link);
						}else{
							$Url = $_G['siteurl'];
						}
						$I = 0;
						foreach ($TemplateRepParam as $Key => $Val) {
							$Val['value'] = str_replace(array(
								'{note}',
								'{time}',
								'{author}',
								'{username}',
								'{type}'
							), array(
								$Note,
								dgmdate($Item['dateline'], 'Y-m-d H:i:s'),
								$Author['username'],
								$Member['username'],
								$this->Config['LangVar']['Reply'],
							), $Val['value']);

							if(!$Val['value']){
								$I++;
							}
							$TemplateRepParam[$Key]['value'] = diconv($Val['value'], CHARSET, 'UTF-8');
						}
						if($I > (count($TemplateRepParam) - 1)){
							$ErrorData = array(
								'uid'=>intval($Member['uid']),
								'openid'=>$OpenId,
								'template_id'=>$TemplateId,
								'dateline'=> TIMESTAMP,
								'content'=> json_encode(array()),
								'code' => '-2',
								'msg' => addslashes(strip_tags($this->Config['LangVar']['LogState'][5]))
							);
							DB::insert($this->TableTemplateMessageLog,$ErrorData);
							continue;
						}
						$Data = $TemplateRepParam;
					}else{
						DB::query('UPDATE %t SET new=0 WHERE id=%d',array('home_notification', $Item['id']));
						$ErrorData = array(
							'uid'=>intval($Item['uid']),
							'openid'=>$OpenId,
							'template_id'=>$TemplateId,
							'dateline'=> TIMESTAMP,
							'content'=> json_encode(array()),
							'code' => '-1',
							'msg' => addslashes(strip_tags($this->Config['LangVar']['LogState'][6].$Item['type']))
						);
						DB::insert($this->TableTemplateMessageLog,$ErrorData);
						continue;
					}
					$TemplateParam = array(
						'touser' => $OpenId,
						'template_id' => $TemplateId,
						'url' => $Url,
						'topcolor' => '#ff0000',
						'data' => $Data
					);
					$Data['url'] = array('value' => $Url);
					$SuccessData = array(
						'uid' => intval($Item['uid']),
						'openid' => $OpenId,
						'template_id' => $TemplateId,
						'dateline' => TIMESTAMP,
						'content' => json_encode($Data),
					);
					$Result = $this->GetSendTemplate($TemplateParam);//����
					if(isset($Result['errcode']) && (int)$Result['errcode'] === 0){
						$SuccessData['code'] = 0;
						$SuccessData['msg'] = addslashes($this->Config['LangVar']['LogState'][1]);//�豣��Html
						DB::query("UPDATE %t SET last_send=%s,send_count=send_count+1,succeed_count=succeed_count+%d WHERE template_id=%s", array($this->TableTemplateMessage, TIMESTAMP,1,$TemplateId));

						DB::query('UPDATE %t SET last_send=%s, send_count=send_count+1 WHERE openid=%s', array($this->TableTemplateMessageFans,TIMESTAMP,$OpenId));
					}else{
						$SuccessData['code'] = $Result['errcode'];
						$SuccessData['msg'] = addslashes(strip_tags($Result['errmsg']));
						DB::query("UPDATE %t SET last_send=%s,send_count=send_count+1,succeed_count=succeed_count+%d WHERE template_id=%s", array($this->TableTemplateMessage, TIMESTAMP,0,$TemplateId));
					}
					DB::insert($this->TableTemplateMessageLog,$SuccessData);
				}
			}
		}
	}
	/* �滻Link */
	public function GetReplaceLink($Link){
		global $_G;
		if(!in_array(strtolower(substr($Link, 0, 6)), array('http:/', 'https:', 'ftp://'))){
			$Link = $_G['siteurl'].$Link;
		}
		return $Link;
	}

	public function GetUnescape($String) {
		$String = rawurldecode($String);
		preg_match_all("/(?:%u.{4})|&#x.{4};|&#\d+;|.+/U",$String,$MatchAll);
		$Array = $MatchAll[0];
		foreach($Array as $Key => $Val) {
			if(substr($Val,0,2) == "%u"){
				$Array[$Key] = iconv("UCS-2BE","UTF-8",pack("H4",substr($Val,-4)));
			}
			elseif(substr($Val,0,3) == "&#x"){
				$Array[$Key] = iconv("UCS-2BE","UTF-8",pack("H4",substr($Val,3,-1)));
			}
			elseif(substr($Val,0,2) == "&#") {
				$Array[$Key] = iconv("UCS-2BE","UTF-8",pack("n",substr($Val,2,-1)));
			}
		}
		return implode("",$Array);
	}
	public function GetUser($Uid){
		return DB::fetch_first('SELECT * FROM '.DB::table($this->TableTemplateMessageUser).' where uid = '.intval($Uid));
	}

	public function GetInsertUser($Uid,$Param){
		if(DB::insert($this->TableTemplateMessageUser,array('uid' => intval($Uid),'param'=>serialize($Param)), false, true)){
			return true;
		}
	}
}
//From: Dism��taobao��com
?>