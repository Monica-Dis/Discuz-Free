<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_template_message/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_template_message/Common.php');
$Operation = in_array($_GET['Operation'], array('Del','AllDel')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&page='.$_GET['page'].'&keyword='.$_GET['keyword'].'&order='.$_GET['order'].'&state='.$_GET['state'];

if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ���� */
		$MpUrl = $SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());	
		$StateSelected = array($_GET['state']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Template_Message->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}">
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Template_Message->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">
						</td>
						
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = in_array($_GET['order'], array('id')) ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.id';
		if($_GET['keyword']){
			$Where .= ' and concat(L.openid,L.uid,L.msg) like(\'%'.addslashes(dhtmlspecialchars($_GET['keyword'])).'%\')';
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */

		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'Module', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_Template_Message->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
			'ID',
			'OpenId',
			$Fn_Template_Message->Config['LangVar']['UidTheRecipient'],
			$Fn_Template_Message->Config['LangVar']['Content'],
			'Url',
			$Fn_Template_Message->Config['LangVar']['MessageType'],
			$Fn_Template_Message->Config['LangVar']['StateTitle'],
			$Fn_Template_Message->Config['LangVar']['TimeTitle']
		), 'header tbm');
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());


		foreach ($ModulesList as $Module) {
			$Content = json_decode($Module['content'], true);
			foreach ($Content as $Key => $Val) {
				$Content[$Key]['value'] = diconv($Val['value'],'UTF-8');
			}
			$Html = '<table>';
			foreach (explode("\n", $Module['Tcontent']) as $Key => $Val) {
				list($First, $Secnd) = explode($Fn_Template_Message->Config['LangVar']['Dou'], $Val);
				if (!$Secnd) {
					$Secnd = $First;
					$First = '';
				}
				$Secnd = str_replace(array('{{', '.DATA}}'), '', $Secnd);
				$First = str_replace(array('{{', '.DATA}}'), '', $First);
				$Color = $Content[$Secnd]['color'] ? "color:".$Content[$Secnd]['color'] :'';

				$Html .= '<tr class="nopadding noborder">'.($First ? '<td>'.$First.'</td>': '').'<td style="'.$Color.'"'.($First ? '' : ' colspan=2').'><div style="max-width:300px">'.$Content[$Secnd]['value'].'</div></td></tr>';
			}
			$Html .= '</table>';
			
			$Content['url']['value'] = str_replace('&mobile=2', '', $Content['url']['value']);
			showtablerow('', array(), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'],
				$Module['openid'],
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '',
				$Html,
				'<div style="max-width:250px"><a href="'.$Content['url']['value'].'" target="_blank">'.$Content['url']['value'].'</a></div>',
				$Module['title'],
				$Module['msg'],
				date('Y-m-d H:i:s',$Module['dateline']),
			));
		}
		showsubmit('Submit','submit','del','<a href="'.$OpCpUrl.'&Operation=AllDel&formhash='.FORMHASH.'">'.$Fn_Template_Message->Config['LangVar']['OneKeyClearance'].'</a>',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter();/*Dism_taobao_com*/
		/*dism��taobao-com*/showformfooter();
		showtagfooter('div');
		/* ģ����� End */
		echo '<style> table tr.nopadding td{padding:0 3px!important;height:20px} </style>';
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_Template_Message->TableTemplateMessageLog,'id ='.$Val);
			}
			cpmsg($Fn_Template_Message->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_Template_Message->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Operation == 'AllDel' && $_GET['formhash'] == formhash()){
	DB::query("DELETE FROM %t WHERE 1", array($Fn_Template_Message->TableTemplateMessageLog));
	cpmsg($Fn_Template_Message->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}
/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Template_Message;
	$FetchSql = 'SELECT L.*,T.title,T.content as Tcontent,M.username FROM '.DB::table($Fn_Template_Message->TableTemplateMessageLog).' L LEFT JOIN '.DB::table($Fn_Template_Message->TableTemplateMessage).' T on T.template_id = L.template_id LEFT JOIN '.DB::table('common_member').' M on M.uid = L.uid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
/* ���� */
function GetModulesCount($Where){
	global $Fn_Template_Message;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Template_Message->TableTemplateMessageLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao��com
?>