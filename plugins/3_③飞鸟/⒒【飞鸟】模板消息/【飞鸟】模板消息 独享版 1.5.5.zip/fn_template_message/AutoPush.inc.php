<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-09-01
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['formhash'] == formhash()){
	require_once (DISCUZ_ROOT .'./source/plugin/fn_template_message/Function.inc.php');
	require_once (DISCUZ_ROOT .'./source/plugin/fn_template_message/Common.php');
	$FileUrl = DISCUZ_ROOT.$Fn_Template_Message->Config['StaticCaChe'].'lasttime.json';
	$Lasttime = file_get_contents($FileUrl);
    if(TIMESTAMP > (intval($Lasttime) + intval($Fn_Template_Message->Config['PluginVar']['TimeInterval']))){
		file_put_contents($FileUrl,TIMESTAMP);
		$Fn_Template_Message->GetAutoPush();
        exit(''.formhash());
    }else{
        exit(''.formhash());
    }
}