<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_template_message/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_template_message/Common.php');
$Operation = in_array($_GET['Operation'], array('Del','AllDel','ImmediateAccess','Reset')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&page='.$_GET['page'].'&keyword='.$_GET['keyword'].'&order='.$_GET['order'].'&state='.$_GET['state'];
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		$MpUrl = $OpCpUrl = $SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());	
		showtableheader($Fn_Template_Message->Config['LangVar']['InitFans']);
		showsetting($Fn_Template_Message->Config['LangVar']['InitFans'], '', '',
			'<a href="'.$OpCpUrl.'&Operation=ImmediateAccess&formhash='.FORMHASH.'">'.$Fn_Template_Message->Config['LangVar']['ImmediateAccessFans'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=AllDel&formhash='.FORMHASH.'">'.$Fn_Template_Message->Config['LangVar']['DelAllFans'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Reset&formhash='.FORMHASH.'">'.$Fn_Template_Message->Config['LangVar']['ResetLastSend'].'</a>'
		);
		showtablefooter();/*Dism_taobao_com*/

		/* ���� */
		$StateSelected = array($_GET['state']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Template_Message->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}">
						&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Template_Message->Config['LangVar']['SearchSubmit']}" class="btn" type="submit">
						</td>
						
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = in_array($_GET['order'], array('dateline')) ? 'F.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'F.dateline';
		if($_GET['keyword']){
			$Where .= ' and concat(F.openid) like(\'%'.addslashes(dhtmlspecialchars($_GET['keyword'])).'%\')';
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */

		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'Module', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_Template_Message->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
			'ID',
			'OpenId',
			$Fn_Template_Message->Config['LangVar']['FaceName'],
			$Fn_Template_Message->Config['LangVar']['Sex'],
			$Fn_Template_Message->Config['LangVar']['Address'],
			$Fn_Template_Message->Config['LangVar']['FollowDate'],
			$Fn_Template_Message->Config['LangVar']['FansSendCount'],
			$Fn_Template_Message->Config['LangVar']['FansLastSend']
		), 'header tbm');
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpenIds = array();
		foreach($ModulesList as $Item) {
			if(!array_filter(unserialize($Item['info']))){
				$OpenIds[] = $Item['openid'];
			}
		}
		foreach($OpenIds as $Val) {
			$FansInfoList[] = $Fn_Template_Message->GetFansInfo($Val);
		}
		foreach ($FansInfoList as $Info) {

			$Info['nickname'] = diconv(RemoveEmoji($Info['nickname']), 'UTF-8', CHARSET);
			$Info['country'] = diconv($Info['country'], 'UTF-8', CHARSET);
			$Info['province'] = diconv($Info['province'], 'UTF-8', CHARSET);
			$Info['city'] = diconv($Info['city'], 'UTF-8', CHARSET);
			$SeriInfo = serialize($Info);
			DB::update($Fn_Template_Message->TableTemplateMessageFans,array('info'=>$SeriInfo,'subscribe_time' => $Info['subscribe_time']),'openid = \''.$Info['openid'].'\'');
			$ModulesList[$Info['openid']]['info'] = $SeriInfo;
			$ModulesList[$Info['openid']]['subscribe_time'] = $Info['subscribe_time'];
		}
		foreach ($ModulesList as $Module) {
			$Module['info'] = unserialize($Module['info']);
			$FaceNameHtml = '<img src="'.$Module['info']['headimgurl'].'" style="width:25px;height:25px;"> '.$Module['info']['nickname'];
			showtablerow('', array(), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['openid'].'" />',
				$Module['openid'],
				$FaceNameHtml,
				$Fn_Template_Message->Config['LangVar']['SexArray'][$Module['info']['sex']],
				$Module['info']['country'].' '.$Module['info']['province'].' ' .$Module['info']['city'],
				date('Y-m-d H:i:s',$Module['subscribe_time']),
				$Module['send_count'],
				$Module['last_send'] ? date('Y-m-d H:i:s',$Module['last_send']) : ''
			));
		}
		showsubmit('Submit','submit','del','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter();/*Dism_taobao_com*/
		/*dism��taobao-com*/showformfooter();
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val =addslashes(strip_tags($Val));
				DB::delete($Fn_Template_Message->TableTemplateMessageFans,'openid = \''.$Val.'\'');
			}
			cpmsg($Fn_Template_Message->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_Template_Message->Config['LangVar']['DelErr'],'','error');
		}
	}
}else if($Operation == 'ImmediateAccess' && $_GET['formhash'] == formhash()){//��ȡ��˿
	$OpenIds = array();
	$AllFansList = $Fn_Template_Message->GetAllFans();
	if($AllFansList['data']['openid']) {
        $OpenIds = array_merge($OpenIds, $AllFansList['data']['openid']);
    }
	while($AllFansList['next_openid']) {
        $AllFansList = $Fn_Template_Message->GetAllFans($AllFansList['next_openid']);
        if ($AllFansList['data']['openid']) {
            $OpenIds = array_merge($OpenIds, $AllFansList['data']['openid']);
        }
    }
	$FansInsertSql = "INSERT IGNORE INTO ".DB::table($Fn_Template_Message->TableTemplateMessageFans)." (openid,dateline) values";
	foreach ($OpenIds as $Key => $Val) {
		$FansInsertSql .= "('".addslashes(strip_tags($Val))."','".time()."'),";
    }
	$FansInsertSql = substr($FansInsertSql,0,strlen($FansInsertSql)-1);
	DB::query($FansInsertSql);
	cpmsg($Fn_Template_Message->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'AllDel' && $_GET['formhash'] == formhash()){//ɾ����˿
	DB::query("DELETE FROM %t WHERE 1", array($Fn_Template_Message->TableTemplateMessageFans));
	cpmsg($Fn_Template_Message->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}else if($Operation == 'Reset' && $_GET['formhash'] == formhash()){//����ʱ��
	DB::query('UPDATE %t SET last_send = 0 ', array($Fn_Template_Message->TableTemplateMessageFans));
	cpmsg($Fn_Template_Message->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}
/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Template_Message;
	$FetchSql = 'SELECT F.* FROM '.DB::table($Fn_Template_Message->TableTemplateMessageFans).' F '.$Where.' order by '.$Order.' desc  LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql, array(),'openid');//��������
}
/* ���� */
function GetModulesCount($Where){
	global $Fn_Template_Message;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Template_Message->TableTemplateMessageFans).' F '.$Where;
	return DB::result_first($FetchSql);//��������
}
function RemoveEmoji($Str) {
	if(CHARSET == 'gbk'){
		return $Str;
	}else{
		$TmpStr = preg_replace("#(\\\ud[0-9a-f]{3})#ie","",json_encode($Str));
		return json_decode($TmpStr);
	}
}
//From: Dism��taobao��com
?>