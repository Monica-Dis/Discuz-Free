<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_template_message/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_template_message/Common.php');
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];

if(submitcheck('UpDate','ok') && $_GET['formhash'] == FORMHASH){
	$TemplateList = $Fn_Template_Message->GetAllPrivateTemplate();
	if($TemplateList){
		$TemplateListData = array();
		foreach ($TemplateList['template_list'] as $Key => $Val) {
			foreach ($Val as $K => $V) {
                $Val[$K] = diconv($V, 'UTF-8', CHARSET);
            }
			$TemplateListData[] = $Val;
		}
		foreach($TemplateListData as $Index => $Item) {
			$Row = DB::fetch_first("SELECT * FROM %t WHERE template_id=%s", array($Fn_Template_Message->TableTemplateMessage,$Item['template_id']));
			if($Row){
				DB::update($Fn_Template_Message->TableTemplateMessage,$Item,'id = '.intval($Row['id']));
            }else{
                DB::insert($Fn_Template_Message->TableTemplateMessage,$Item);
            }
		}
		cpmsg($Fn_Template_Message->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
	}else{
		cpmsg($Fn_Template_Message->Config['LangVar']['UpdateErr'],'','error');
	}
}else if(!submitcheck('Submit')){
	$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
	$TdStyle = array('width="60"', 'width="380"','width="100"','width="100"');
	showtips($Fn_Template_Message->Config['LangVar']['Tip']);
	showtagheader('div', 'Module', true);
	showformheader($FormUrl,'enctype="multipart/form-data"');
	showtableheader($Fn_Template_Message->Config['LangVar']['TemplateList']);
	$ModulesList = GetModulesList(1,100,'','id');
	showsubtitle(array(
		'Id',
		$Fn_Template_Message->Config['LangVar']['TemplateId'],
		$Fn_Template_Message->Config['LangVar']['TemplateName'],
		$Fn_Template_Message->Config['LangVar']['TemplateType'],
		$Fn_Template_Message->Config['LangVar']['TemplateColor'],
		$Fn_Template_Message->Config['LangVar']['TemplateSituation']
	), 'header',$TdStyle);
	foreach ($ModulesList as $Module) {
		$Module['param'] = unserialize($Module['param']);
		$Tpl = '<table cellpadding="0" cellspacing="0">';
		foreach (explode("\n", $Module['content']) as $Key => $Val) {
			list($First, $Secnd) = explode($Fn_Template_Message->Config['LangVar']['Dou'], $Val);
			if(!$Secnd){
				$Secnd = $First;
			}
			$Secnd = str_replace(array('{{','.DATA}}'), '', $Secnd);
			$First = str_replace(array('{{','.DATA}}'), '', $First);
			$Ck = $Module['id']."_".$Key;
			$Tpl .= '<tr class="noborder nopadding"><td>'.$First.'</td><td><input name="item['.$Module['id'].'][param]['.$Secnd.'][value]" value="'.$Module['param'][$Secnd]['value'].'"/>
			</td><td>
			<input name="item['.$Module['id'].'][param]['.$Secnd.'][color]" id="'.$Ck.'_v" type="text" class="txt" style="float:left;" value="'.$Module['param'][$Secnd]['color'].'" onchange="updatecolorpreview(\''.$Ck.'\')">
			<input id="'.$Ck.'" type="button" class="colorwd" onclick="return showcolor1(\''.$Ck.'\');" style="background:'.$Module['param'][$Secnd]['color'].'">
			<span id="'.$Ck.'_menu" style="display: none"><iframe id="'.$Ck.'_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>
			</td></tr>';
		}
		$Tpl .= '</table>';
		showtablerow('', array('class="td25"', 'class="td28"'), array(
			'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['id'].'" />'.$Module['id'],
			$Module['template_id'],
			$Module['title'],
			'<select name="item['.$Module['id'].'][type]"><option value="0" '.($Module['type']==0?'selected':'').'>'.$Fn_Template_Message->Config['LangVar']['TemplateTypeArray'][0].'</option><option value="1" '.($Module['type']==1?'selected':'').'>'.$Fn_Template_Message->Config['LangVar']['TemplateTypeArray'][1].'</option><option value="2" '.($Module['type']==2?'selected':'').'>'.$Fn_Template_Message->Config['LangVar']['TemplateTypeArray'][2].'</option></select>',
			$Tpl,
			($Module['last_send'] ? $Fn_Template_Message->Config['LangVar']['LastSendTitle'].':'.date('m-d H:i:s', $Module['last_send']).'<br>':'').$Module['succeed_count'].'/'.$Module['send_count']
		));

	}
	showsubmit('Submit','submit','del','<a href="'.ADMINSCRIPT.'?'.$CpMsgUrl.'&UpDate=ok&formhash='.FORMHASH.'">'.$Fn_Template_Message->Config['LangVar']['ObtainTemplateTitle'].'</a>');
    showtablefooter();/*Dism_taobao_com*/
	/*dism��taobao-com*/showformfooter();
	showtagfooter('div');

	echo "<style> table tr.nopadding td{padding:2px 3px!important;height:20px} </style>
		<script>
		function showcolor1(ck) {
			document.getElementById(ck+'_frame').src='static/image/admincp/getcolor.htm?'+ck+'|'+ck+'_v';
			showMenu({ctrlid:ck});
		}
		</script>
	";
}else{
	foreach ($_GET['item'] as $Key => $Val) {//����ģ���б�ֵ
        $Val['param'] = serialize($Val['param']);
		DB::update($Fn_Template_Message->TableTemplateMessage,$Val,'id = '.intval($Key));
    }
	if(isset($_GET['delete']) && is_array($_GET['delete'])){//ɾ��ģ��
		foreach($_GET['delete'] as $Key => $Val) {
			$Val = intval($Val);
			DB::delete($Fn_Template_Message->TableTemplateMessage,'id ='.$Val);
		}
	}
	cpmsg($Fn_Template_Message->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}

/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Template_Message;
	$FetchSql = 'SELECT * FROM '.DB::table($Fn_Template_Message->TableTemplateMessage).$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}
//From: Dism��taobao��com
?>