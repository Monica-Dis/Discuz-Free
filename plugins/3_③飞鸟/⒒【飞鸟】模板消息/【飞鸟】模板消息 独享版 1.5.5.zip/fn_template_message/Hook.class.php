<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-09-01
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_fn_template_message{
    function global_footer(){
        global $_G;
		loadcache('plugin');
        if(!$_G['uid']){
			return false;
		}
        $Config = $_G['cache']['plugin']['fn_template_message'];
        if(!$Config['AutoPushSwitch'] || !$Config['WxAppid'] || !$Config['WxSecret'] || !$Config['WxTable']){
            return false;
        }
        $TimeInterval = intval($Config['TimeInterval']) * 1000;
        if($TimeInterval < 5000){
            $TimeInterval = 5000;
        }
        $Formhash = FORMHASH;
        return <<<HTML
		<script>
		var Formhash = '$Formhash';
		Check_AutoPush();
		var Check_Interval = setInterval(Check_AutoPush, $TimeInterval);
		function Check_AutoPush(){
			var xhr = new XMLHttpRequest();
			xhr.open("GET", "plugin.php?id=fn_template_message:AutoPush&formhash="+Formhash, true);
			xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
			xhr.onreadystatechange = function(){ if (xhr.readyState == 4 && xhr.status == 200) {
				if(xhr.responseText=='stop' || xhr.responseText.length>20 || xhr.responseText.length<1){
				  clearInterval(Check_Interval);  
				}else{
					Formhash = xhr.responseText;
				}
			}  };
			xhr.send();
		}
		</script>
HTML;
    }
}
class  mobileplugin_fn_template_message extends plugin_fn_template_message{
    function global_footer_mobile(){
        return parent::global_footer();
    }
}