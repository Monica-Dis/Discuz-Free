<?php
/**
 *	[������ģ����Ϣ(fn_template_message.{modulename})] (C)2016-2099 Powered by DisM!Ӧ������ (https://DisM.Taobao.COm/).
 *	Version: 1.0
 *	Date: 2018-3-4 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_template_message/Function.inc.php');
require_once (DISCUZ_ROOT .'./source/plugin/fn_template_message/Common.php');
$Url = "home.php?mod=spacecp&ac=plugin&id=fn_template_message:MyTemplate";
$User = $Fn_Template_Message->GetUser($_G['uid']);
$TypeArray = unserialize($Fn_Template_Message->Config['PluginVar']['Type']);
if($User){$User['param'] = unserialize($User['param']);}
if($_GET['formhash'] == FORMHASH){
	if(checkmobile()){
		foreach($TypeArray as $Key => $Val) {
            if(!$_GET['param'][$Val]){
                $_GET['param'][$Val] = 0;
            }
        }
	}
	if($Fn_Template_Message->GetInsertUser($_G['uid'],$_GET['param'])){
		if(checkmobile()){
			echo urldecode(json_encode(array('State'=>'200','Msg'=>$Fn_Template_Message->Config['LangVar']['UpdateOk'])));
			exit();
		}else{
			showmessage($Fn_Template_Message->Config['LangVar']['DoSuccess'],$Url);
		}
    }else{
		if(checkmobile()){
			echo urldecode(json_encode(array('State'=>'200','Msg'=>$Fn_Template_Message->Config['LangVar']['UpdateErr'])));
			exit();
		}
	}
}
if(checkmobile()){
	if(!$_G['uid']){
		if(checkmobile()){
			header("HTTP/1.1 303 See Other");
			Header("Location: member.php?mod=logging&action=login"); 
		}else{
			showmessage('to_login', '', array(), array('showmsg' => true,'login' => 1));
			exit();
		}
	}
	$navtitle = $metakeywords = $metadescription = $Fn_Template_Message->Config['LangVar']['SwitchTitle'];
    include_once template('fn_template_message:MyTemplate');
	exit;
}else if(strpos($_SERVER['PHP_SELF'],'plugin.php') !== false){
	header('Location:'.$Url);
	exit();
}
//From: Dism��taobao��com
?>