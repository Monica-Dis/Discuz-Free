<?php
/**
 *	[������Ƶ������(fn_play.{modulename})] (C)2016-2099 Powered by DisM!Ӧ������ (https://DisM.Taobao.COm/).
 *	Version: 1.0
 *	Date: 2016-8-22 10:27
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(strpos($_GET[id],'aitoupiao') !== false){$AitouPiao = true;}
if(!$AitouPiao){require_once libfile('class/replace_play','plugin/fn_play');}
class plugin_fn_play {
	function discuzcode($param) {
		global $_G;
		
		$pluginvar=$_G['cache']['plugin']['fn_play'];
		if($param['caller'] == 'discuzcode' && in_array($_G['fid'], unserialize($pluginvar['section']))){
			if (strstr($_G['discuzcodemessage'],'[/media]')){
				$_G['discuzcodemessage'] = preg_replace_callback("/\[media(.*?)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i","replace_play",$_G['discuzcodemessage']);
			}
			if (strstr($_G['discuzcodemessage'],'[/video]')){
				$_G['discuzcodemessage'] = preg_replace_callback("/\[video(.*?)\]\s*([^\[\<\r\n]+?)\s*\[\/video\]/i","replace_play",$_G['discuzcodemessage']);
			}

		}
	}
}
class mobileplugin_fn_play {
	function discuzcode($param) {
		global $_G;
		$pluginvar=$_G['cache']['plugin']['fn_play'];
		if($param['caller'] == 'discuzcode' && in_array($_G['fid'], unserialize($pluginvar['section']))){
			if (strstr($_G['discuzcodemessage'],'[/media]')){
				$_G['discuzcodemessage'] = preg_replace_callback("/\[media(.*?)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i","replace_play",$_G['discuzcodemessage']);
			}
			if (strstr($_G['discuzcodemessage'],'[/video]')){
				$_G['discuzcodemessage'] = preg_replace_callback("/\[video(.*?)\]\s*([^\[\<\r\n]+?)\s*\[\/video\]/i","replace_play",$_G['discuzcodemessage']);
			}
		}
	}
}
//֧���Ż�
class plugin_fn_play_portal{
	function view_fn_output() {
        global $content;
		if(strstr($content[content],'</object>')){
			$content[content] = str_replace(array("\r\n","\r","\n"),array('','',''),$content[content]);
			$content[content] = preg_replace_callback("/<object classid=\"(.*?)name=\"url\" value=\"(.*?)\">(.*?)<\/object>/i","replace_play",$content[content]);
		}
    }
}
//֧���Ż�
class mobileplugin_fn_play_portal{
	function view_fn_output() {
        global $content;
		if(strstr($content[content],'</object>')){
			$content[content] = str_replace(array("\r\n","\r","\n"),array('','',''),$content[content]);
			$content[content] = preg_replace_callback("/<object classid=\"(.*?)name=\"url\" value=\"(.*?)\">(.*?)<\/object>/i","replace_play",$content[content]);
		}
    }
}
//From: Dism��taobao��com
?>