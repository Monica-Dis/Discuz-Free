<?php
/**
 *	[������ͬ�ǻ(fn_hd.{modulename})] (C)2016-2099 Powered by ��������.
 *	Version: 1.0
 *	Date: 2018-7-23 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_hd/Function.inc.php');

$navtitle = $metakeywords = $metadescription = $Fn_Hd->Config['PluginVar']['Title'];

/* ���Զ�ά����� */
if(!checkmobile() && $Fn_Hd->Config['PluginVar']['PcQrSwitch'] && !in_array($_GET['m'],'sign_up_op','verification_search','verification','export_sign_up_list')){
	if($Fn_Hd->Config['PluginVar']['QrParameterSwitch']){
		@require_once libfile('class/wechat','plugin/fn_assembly');
		$WechatClient = new Fn_WeChatClient($Fn_Hd->Config['PluginVar']['WxAppid'], $Fn_Hd->Config['PluginVar']['WxSecret']);
		$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____index____0','expire'=>2592000)));
		$QrCode = base64_encode(dfsockopen($QrUrl));
		$QrCode = $QrCode ? $QrCode : base64_encode(file_get_contents($QrUrl));
		$QrCode = $QrCode ? $QrCode : base64_encode(CurlGet(str_replace('https','http',$QrUrl)));
	}else{
		$PcUrl = $_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"];
		$QrSize = 5;
		$Dir = 'data/cache/qrcode/';//�洢·��
		$File = $Dir.'fn_hd.jpg';
		if(!file_exists($File) || !filesize($File)) {
			dmkdir($Dir);
			@require_once libfile('class/qrcode','plugin/fn_assembly');
			QRcode::png($PcUrl, $File, QR_ECLEVEL_L, $QrSize,2);
		}
		$QrCode = base64_encode(file_get_contents($File));
		unlink($File);
	}

	include template('fn_hd:index_qrcode');
	exit();
}
/* ���Զ�ά����� End */

$_GET['m'] = $_GET['m'] ? $_GET['m'] : 'index';

$Mod = array('index','view','sign_up','sign_up_list','sign_up_op','ticket','verification_search','verification','join','vip','export_sign_up_list');

if(!in_array($_GET['m'],$Mod)){
	exit('No Data');
}

if(!$_G['uid'] && in_array($_GET['m'],array('vip','export_sign_up_list','sign_up','sign_up_op','ticket','verification_search','verification','join'))){
	Fn_Login();
}

$UserInfo = $Fn_Hd->GetUserInfo();

if($_GET['m'] == 'index'){
	//���ͼ
	$Banners = $Fn_Hd->Config['PluginVar']['banners'];
	
	$ClassList = $Fn_Hd->GetClassList();
	if($_GET['classid']){
		$navtitle = $metakeywords = $metadescription = $ClassList[$_GET['classid']]['name'];
	}
}else if($_GET['m'] == 'view'){
	$Item = $Fn_Hd->GetViewthread($_GET['aid']);
	
	if($Item){

		$navtitle = $metakeywords = $metadescription = $Item['title'];

		if($Item['xiangqin'] && $Item['param']['xiangqin_more_cost_list'] && ($Item['param']['male_people'] || $Item['param']['female_people'])){
			$Fn_Hd->Config['LangVar']['RegistrationInformationFtitle'] = $Fn_Hd->Config['LangVar']['UnlimitedRegistrationInformationFtitle'];
			if($Item['param']['male_people']){
				$Fn_Hd->Config['LangVar']['RegistrationInformationFtitle'] .= $Fn_Hd->Config['LangVar']['MaleLeftoverCount']; 
			}

			if($Item['param']['female_people']){
				$Fn_Hd->Config['LangVar']['RegistrationInformationFtitle'] .= $Fn_Hd->Config['LangVar']['femaleLeftoverCount']; 
			}

			$Fn_Hd->Config['LangVar']['RegistrationInformationFtitle'] = str_replace(array("{Count}","{AdoptCount}","{MaleLeftoverCount}","{FemaleLeftoverCount}"),array($Fn_Hd->GetSignUpCount(' and aid = '.$Item['id']),$Fn_Hd->GetSignUpCount(' and examine  = 1 and aid = '.$Item['id']),$Item['param']['male_people'] - $Fn_Hd->GetSignUpCount(' and sex = 1 and examine  = 1 and aid = '.$Item['id']),$Item['param']['female_people'] - $Fn_Hd->GetSignUpCount(' and sex = 2 and examine  = 1 and aid = '.$Item['id'])),$Fn_Hd->Config['LangVar']['RegistrationInformationFtitle']);

		}else{
			$Fn_Hd->Config['LangVar']['RegistrationInformationFtitle'] = $Item['param']['people'] ? $Fn_Hd->Config['LangVar']['RegistrationInformationFtitle'] : $Fn_Hd->Config['LangVar']['UnlimitedRegistrationInformationFtitle'];

			$Fn_Hd->Config['LangVar']['RegistrationInformationFtitle'] = str_replace(array("{Count}","{AdoptCount}","{LeftoverCount}"),array($Fn_Hd->GetSignUpCount(' and aid = '.$Item['id']),$Fn_Hd->GetSignUpCount(' and examine  = 1 and aid = '.$Item['id']),$Item['param']['people'] - $Fn_Hd->GetSignUpCount(' and examine  = 1 and aid = '.$Item['id'])),$Fn_Hd->Config['LangVar']['RegistrationInformationFtitle']);
		}
		
		//�����б�
		$SignUpList = $Fn_Hd->GetAjaxSignUpList(array('limit'=>5,'aid'=>$Item['id']));
		
		//��������
		$SignUpItem = $Fn_Hd->GetSignUp($Item['id']);

		//������ۼ�
		Click($Fn_Hd->TableHd,$Item['id'],1);
		
		if(in_array($_G['uid'],array_filter(explode(",",$Item['param']['v_uids'])))){//����Ա
			$AdminOp = true;
		}

		if($Item['param']['post_switch']){//����
			$CommentList = $Fn_Hd->GetAjaxPostList($Item['id'],$_GET['pid']);
			//ָ��Pid�����б�
			$PidCommentList = $_GET['pid'] ? $Fn_Hd->GetPidPostList($Item['id'],$_GET['pid']) : '';

		}

		//����
		$Fn_Hd->Config['WxShare']['WxTitle'] = $Item['param']['share_title'] ? $Item['param']['share_title'] : $Item['title'];
		$Fn_Hd->Config['WxShare']['WxDes'] = $Item['param']['share_desc'] ? $Item['param']['share_desc'] : $Item['title'];
		$Fn_Hd->Config['WxShare']['WxUrl'] = $Fn_Hd->Config['ViewUrl'].$Item['id'];
		$Fn_Hd->Config['WxShare']['WxImg'] = $Item['param']['share_logo'] ? $Item['param']['share_logo'] : $Fn_Hd->Config['WxShare']['WxImg'];
		$Fn_Hd->Config['WxShare']['WxImg'] = strpos($Fn_Hd->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Hd->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Hd->Config['WxShare']['WxImg'];
		$Fn_Hd->Config['WxShare']['WxImg'] = str_replace(array("\r","\n"),array('',''),$Fn_Hd->Config['WxShare']['WxImg']);
		//���� End
		

		//֧��
		$PayTitle = $Fn_Hd->Config['LangVar']['SignUpPayTitle'];
		$PaymentMsg = $Fn_Hd->Config['LangVar']['SignUpAppOk'];
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){
			@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
			$PayList = $FnPay->GetPayList();
		}
		
		if($Item['vip_id']){//�Ƿ��Ա
			$VipItem = $Fn_Hd->GetVipView($Item['vip_id']);
			$VipMember = $Fn_Hd->GetVipMember($Item['vip_id']);
			$VipLink = $Fn_Hd->Config['VipUrl'].$Item['vip_id'];
			$Fn_Hd->Config['LangVar']['GoVip'] = str_replace(array("{Title}"),array($VipItem['title']),$Fn_Hd->Config['LangVar']['GoVip']);
			$VipTitle = $VipItem['title'];
			$Fn_Hd->Config['LangVar']['VipPrompt'] = str_replace(array("{Title}"),array($VipItem['title']),$Fn_Hd->Config['LangVar']['VipPrompt']);
			$CostVipTips =  str_replace(array("{Title}"),array($VipItem['title']),$Fn_Hd->Config['LangVar']['CostVipTips']);
		}

		//�Ƿ�����
		if($Item['xiangqin']){
			$XiangQinUserInfo = $Fn_Hd->Fn_XiangQin->GetUserInfo($_G['uid']);
			$BasicInformationNull = App ? $Fn_Hd->Fn_XiangQin->Config['LangVar']['AppBasicInformationNull'] : $Fn_Hd->Fn_XiangQin->Config['LangVar']['BasicInformationNull'];
			$UserInfoUrl = $Fn_Hd->Fn_XiangQin->Config['UserInfoUrl'];
			$VipLink = $Fn_Hd->Fn_XiangQin->Config['VipUrl'];
			$NotifyUrl = $_G['siteurl'].'plugin.php?id=fn_xiangqin&m=hd';
			$Fn_Hd->Config['LangVar']['GoVip'] = $Fn_Hd->Config['LangVar']['GoVipXiangQin'];
			$VipTitle = $Fn_Hd->Config['LangVar']['VipTitle'];
			$Fn_Hd->Config['LangVar']['VipPrompt'] = str_replace(array("{Title}"),array('VIP'),$Fn_Hd->Config['LangVar']['VipPrompt']);
			$CostVipTips = $Fn_Hd->Config['LangVar']['CostXiangQinVipTips'];
		}

		//��ά��
		if($Fn_Hd->Config['PluginVar']['QrParameterSwitch']){
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'_'.$_GET['m'].'_'.intval($Item['id']).'.jpg';
			if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 1296000 <= time())) {
				@unlink($File);
				@require_once libfile('class/wechat','plugin/fn_assembly');
				$WechatClient = new Fn_WeChatClient($Fn_Hd->Config['PluginVar']['WxAppid'], $Fn_Hd->Config['PluginVar']['WxSecret']);
				$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____'.$_GET['m'].'____'.$Item['id'],'expire'=>2592000)));
				DownloadImg($QrUrl,$File);
			}
			$QrCode = base64_encode(file_get_contents($File));
		}else{
			$File = $Config['QrcodePath'].reset(array_filter(explode(":",$_GET['id']))).'.jpg';
			if(!file_exists($File) || !filesize($File)) {
				@require_once libfile('class/qrcode','plugin/fn_assembly');
				QRcode::png($Fn_Hd->Config['ViewUrl'].$Item['id'], $File, QR_ECLEVEL_L,5,2);
			}
			$QrCode = base64_encode(file_get_contents($File));
			@unlink($File);
		}
		//��ά�� End

	}else{
		exit('No Data');
	}
}else if($_GET['m'] == 'sign_up'){

	$navtitle = $metakeywords = $metadescription = $Fn_Hd->Config['LangVar']['GoSignUp'];

	$Item = $Fn_Hd->GetViewthread($_GET['aid']);
	if($Item){
		
		$Fn_Hd->Config['LangVar']['LimitPeopleErr'] = str_replace(array("{Num}"),array($Item['param']['limit_people']),$Fn_Hd->Config['LangVar']['LimitPeopleErr']);
		
		$SignUpItem = $Fn_Hd->GetSignUp($Item['id']);

		if($SignUpItem){
			if((($Item['param']['payment_type'] == 1 && $Item['param']['money']) || $Item['param']['payment_type'] == 2 && $Item['param']['extcredits']) && $SignUpItem['display'] == 1){
				$navtitle = $metakeywords = $metadescription = $Fn_Hd->Config['LangVar']['EditSignUpBtn'];
				$PaymentState = true;
			}else{
				$navtitle = $metakeywords = $metadescription = $Fn_Hd->Config['LangVar']['EditSignUp'];
			}
			
		}
		$FormHtml = '';
		if($Item['param']['more_cost_list'] && !$Item['param']['sign_up_data_switch']){
			$FormHtml .= '<li><div class="Title"><span class="ColorRed">*</span>'.$Fn_Hd->Config['LangVar']['SignUpType'].'</div><div class="Select iconfont"><select name="more_cost[]">';
			foreach($Item['param']['more_cost_list'] as $Key => $Val) {
				 $FormHtml .= '<option value="'.$Key.'"'.($Key == $_GET['more_cost'] ? ' selected="selected"' : '').'>'.$Val['title'].'</option>';
			}
			$FormHtml .= '</select></div></li>';
		}
		$GetFormHtml = $Fn_Hd->GetFormHtml($Item['param']['sign_up_form']);//����
		$FormHtml .= $GetFormHtml['Html'];
		$FileJs = $GetFormHtml['FileJs'];

		//��Ƿ��ѿ�ʼ
		if(in_array($Item['state'],array('0'))){
			$Msg = $Fn_Hd->Config['LangVar']['StateArray'][$Item['state']];
		}else if($Item['state'] != 1){
			$Msg = $Fn_Hd->Config['LangVar']['StateArray'][2];
		}else if($Fn_Hd->GetSignUpCount(' and examine  = 1 and aid = '.$Item['id']) >= $Item['param']['people'] && $Item['param']['people']){
			$Msg = $Fn_Hd->Config['LangVar']['PeopleErr'];
		}
		
		if($Item['param']['payment_type'] == 2 && $Item['param']['extcredits']){//����֧��
			$Extcredits = $UserInfo['extcredits'.$Item['param']['extcredits_type']];
			$Fn_Hd->Config['LangVar']['SignUpExtcredits'] = str_replace(array('{ExtcreditsTitle}'),array($Item['param']['extcredits_title']),$Fn_Hd->Config['LangVar']['SignUpExtcredits']);
		}else if($Item['param']['payment_type'] == 1 && ($Item['param']['money'] || $Item['param']['more_cost_list'])){//�ֽ�֧��
			$PayTitle = $Fn_Hd->Config['LangVar']['SignUpPayTitle'];
			$PaymentMsg = $Fn_Hd->Config['LangVar']['SignUpAppOk'];

			if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){
				@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
				$PayList = $FnPay->GetPayList();
			}
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

	}else{
		exit('No Data');
	}
}else if($_GET['m'] == 'sign_up_list'){//�����б�
	$navtitle = $metakeywords = $metadescription = $Fn_Hd->Config['LangVar']['SignUpListTitle'];
	$Item = $Fn_Hd->GetViewthread($_GET['aid']);
	if(!$Item){
		exit('No Data');
	}
}else if($_GET['m'] == 'export_sign_up_list'){//���������б�
	$navtitle = $metakeywords = $metadescription = $Fn_Hd->Config['LangVar']['SignUpListTitle'];
	$Item = $Fn_Hd->GetViewthread($_GET['aid']);
	if(!$Item){
		exit('No Data');
	}else{
		$SignUpList = $Fn_Hd->GetAjaxSignUpList(array('limit'=>1000,'type'=>'1','aid'=>$_GET['aid']));
		foreach($SignUpList as $Key => $Val){
			$FormList = array();
			foreach ($Val['param']['form_list'] as $KK=>$VV) {
				foreach($VV as $V){
					$FormListString .= "$V[title]:$V[value] ";
				}
				$FormList[] = $FormListString;
				unset($FormListString);

			}
			$DataSignUpList[$Key]['title'] = $Item['title'];
			$DataSignUpList[$Key]['username'] = $Val['uid'].'/'.$Val['username'];
			$DataSignUpList[$Key]['count'] = $Val['count'];
			$DataSignUpList[$Key]['form_list'] = implode('---------',$FormList);
			$DataSignUpList[$Key]['code'] = $Val['code'];
			$DataSignUpList[$Key]['cost'] = $Val['param']['cost'];
			$DataSignUpList[$Key]['state'] = $Fn_Hd->Config['LangVar']['VerificationStateArray'][$Val['state']];
			$DataSignUpList[$Key]['statedateline'] = $Val['statedateline'] ? date('Y-m-d H:i',$Val['statedateline']) : '';
			$DataSignUpList[$Key]['dateline'] = $Val['dateline'];
		}
		ExportExcel($DataSignUpList,array($Fn_Hd->Config['LangVar']['ActivityTitle'],'Uid/'.$Fn_Hd->Config['LangVar']['UserNameTitle'],$Fn_Hd->Config['LangVar']['EnrolmentCount'],$Fn_Hd->Config['LangVar']['RegistrationInformation'],$Fn_Hd->Config['LangVar']['VoucherCode'],$Fn_Hd->Config['LangVar']['MoneyTitle'],$Fn_Hd->Config['LangVar']['VerificationState'],$Fn_Hd->Config['LangVar']['UseTime'],$Fn_Hd->Config['LangVar']['TimeTitle']),'fn_hd_'.$_GET['aid']);
		exit();
	}

}else if($_GET['m'] == 'sign_up_op'){//���������û�
	$navtitle = $metakeywords = $metadescription = $Fn_Hd->Config['LangVar']['SignUpOpTitle'];
	$Item = $Fn_Hd->GetSignUp($_GET['aid'],$_GET['sid'],false);
	if(in_array($Item['display'],array('0'))){
		$Msg = $Fn_Hd->Config['LangVar']['NoDataSignUp'];
	}else if(!in_array($_G['uid'],array_filter(explode(",",$Item['hparam']['v_uids'])))){
		$Msg = $Fn_Hd->Config['LangVar']['NoJurisdiction'];
	}
	
}else if($_GET['m'] == 'ticket'){//�ƾ֤
	$navtitle = $metakeywords = $metadescription = $Fn_Hd->Config['LangVar']['TicketTitle'];
	$Item = $Fn_Hd->GetSignUp($_GET['aid'],$_GET['sid']);
	if(in_array($Item['display'],array('0')) || !in_array($Item['examine'],array('1'))){
		$Msg = $Fn_Hd->Config['LangVar']['NoTicketErr'];
	}

	if(!$Msg){
		$Url = $Fn_Hd->Config['VerificationUrl'].$Item['id'].'&aid='.$Item['aid'];
		$QrSize = 7;
		$Dir = 'data/cache/qrcode/';//�洢·��
		$File = $Dir.'fn_hd_'.$Item['id'].'.jpg';
		if(!file_exists($File) || !filesize($File)) {
			dmkdir($Dir);
			@require_once libfile('class/qrcode','plugin/fn_assembly');
			QRcode::png($Url, $File, QR_ECLEVEL_L, $QrSize,2);
		}
		$QrCode = base64_encode(file_get_contents($File));
		unlink($File);
	}
}else if($_GET['m'] == 'verification'){//�ƾ֤����
	$navtitle = $metakeywords = $metadescription = $Fn_Hd->Config['LangVar']['VerificationTitle'];
	$Item = $Fn_Hd->GetSignUp($_GET['aid'],$_GET['sid'],false);
	if(in_array($Item['display'],array('0'))){
		$Msg = $Fn_Hd->Config['LangVar']['NoTicketErr'];
	}else if(!in_array($_G['uid'],array_filter(explode(",",$Item['hparam']['v_uids'])))){
		$Msg = $Fn_Hd->Config['LangVar']['NoJurisdiction'];
	}

}else if($_GET['m'] == 'verification_search'){//�ƾ֤������
	$navtitle = $metakeywords = $metadescription = $Fn_Hd->Config['LangVar']['VerificationSearch'];
	$Item = $Fn_Hd->GetViewthread($_GET['aid']);
	if($Item){
		$Fn_Hd->Config['LangVar']['VerificationSearchCount'] = str_replace(array("{Count}"),array($Fn_Hd->GetSignUpCount(' and state = 1 and aid = '.$Item['id'])),$Fn_Hd->Config['LangVar']['VerificationSearchCount']);

		if(!in_array($_G['uid'],array_filter(explode(",",$Item['param']['v_uids'])))){
			$Msg = $Fn_Hd->Config['LangVar']['NoJurisdiction'];
		}
	}else{
		exit('No Data');
	}

}else if($_GET['m'] == 'join'){//�ҵĲ���
	$navtitle = $metakeywords = $metadescription = $Fn_Hd->Config['LangVar']['JoinTitle'];

}else if($_GET['m'] == 'vip'){//��Ա��
	$Item = $Fn_Hd->GetVipView($_GET['vid']);
	if($Item){
		$navtitle = $metakeywords = $metadescription = $Item['title'];
		$VipMember = $Fn_Hd->GetVipMember($Item['id']);
		$Item['param']['bank_vip_count'] = str_replace(array("{Count}"),array('<span class=ColorRed>'.($Item['param']['bank_vip_count_fictitious']+$Fn_Hd->GetVipMemberCount($Item['id'])).'</span>'),$Item['param']['bank_vip_count']);

		$Item['param']['no_vip_info'] = str_replace(array("{Username}"),array($_G['username']),$Item['param']['no_vip_info']);
		$Item['param']['is_vip_info'] = str_replace(array("{Username}"),array($_G['username']),$Item['param']['is_vip_info']);
		
		$Fn_Hd->Config['PluginVar']['Color'] = $Item['param']['theme_color'];

		$NotifyUrl = strpos(dreferer(),'m=view') !== false ? dreferer() : $Fn_Hd->Config['VipUrl'].$Item['id'];

		if($VipMember['is_vip']){
			$VipBtn = $Fn_Hd->Config['LangVar']['IsVipBtn'];
			$PayTitle = str_replace(array("{Title}"),array($Item['title']),$Fn_Hd->Config['LangVar']['IsVipPayTitle']);
			$PaymentMsg = $Fn_Hd->Config['LangVar']['IsVipPaymentMsg'];
		}else{
			$VipBtn = $Fn_Hd->Config['LangVar']['VipBtn'];
			$PayTitle = str_replace(array("{Title}"),array($Item['title']),$Fn_Hd->Config['LangVar']['VipPayTitle']);
			$PaymentMsg = $Fn_Hd->Config['LangVar']['VipPaymentMsg'];
		}
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php')){
			@include DISCUZ_ROOT.'./source/plugin/fn_pay/class/FnPay.Class.php';
			$PayList = $FnPay->GetPayList();
		}
	}else{
		exit('No Data');
	}
	
}
include template('fn_hd:'.$_GET['m']);
?>