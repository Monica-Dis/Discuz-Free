<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once libfile('function/core','plugin/fn_assembly');
@require_once libfile('class/magapp','plugin/fn_assembly');
@require_once libfile('class/qfapp','plugin/fn_assembly');
@require_once libfile('class/pay','plugin/fn_assembly');
@require_once libfile('function/forum');
@require_once libfile('class/json','plugin/fn_assembly');

class Fn_Hd{
	public function __construct() {
		global $_G,$plugin,$Config;
		loadcache('plugin');
		loadcache('fn_hd_setting');
		foreach($_G['cache']['fn_hd_setting'] as $key => $value) {
			$this->Config['PluginVar'][$key] = is_array($value) ? $value : stripslashes($value);
		}
		//参数二维码开关
		if(!$this->Config['PluginVar']['QrParameterSwitch'] && QrParameterSwitch){
			$this->Config['PluginVar']['WxAppid'] = $Config['PluginVar']['WxAppid'];
			$this->Config['PluginVar']['WxSecret'] = $Config['PluginVar']['WxSecret'];
		}
		$this->Config['PluginVar']['QrParameterSwitch'] = $this->Config['PluginVar']['QrParameterSwitch'] ? $this->Config['PluginVar']['QrParameterSwitch'] : (QrParameterSwitch ? QrParameterSwitch : 0);
		//参数二维码开关 End
		$this->Config['LangVar'] = lang('plugin/fn_hd');
		$this->Config['Path'] = 'source/plugin/fn_hd';
		$this->Config['StaticPath'] = $this->Config['Path'].'/static';
		$this->Config['StaticPicPath'] = $this->Config['Path'].'/attachment/';
		$this->Config['Url'] = $_G['siteurl'].'plugin.php?id=fn_hd';
		$this->Config['AddUrl'] = $this->Config['Url'].'&m=add';
		$this->Config['VipUrl'] = $this->Config['Url'].'&m=vip&vid=';
		$this->Config['ViewUrl'] = $this->Config['Url'].'&m=view&aid=';
		$this->Config['SignUpListUrl'] = $this->Config['Url'].'&m=sign_up_list&aid=';
		$this->Config['SignUpUrl'] = $this->Config['Url'].'&m=sign_up&aid=';
		$this->Config['ExportSignUpListUrl'] = $this->Config['Url'].'&m=export_sign_up_list&aid=';
		$this->Config['SignUpOpUrl'] = $this->Config['Url'].'&m=sign_up_op&sid=';
		$this->Config['TicketUrl'] = $this->Config['Url'].'&m=ticket&sid=';
		$this->Config['VerificationUrl'] = $this->Config['Url'].'&m=verification&sid=';
		$this->Config['VerificationSearchUrl'] = $this->Config['Url'].'&m=verification_search&aid=';
		$this->Config['JoinUrl'] = $this->Config['Url'].'&m=join';
		$this->Config['AjaxUrl'] =  'plugin.php?id=fn_hd:Ajax';
		$this->Config['WxShare'] = array(
			'WxTitle' => $this->Config['PluginVar']['WxTitle'],
			'WxDes' => $this->Config['PluginVar']['WxDes'],
			'WxImg' => strpos($this->Config['PluginVar']['WxImg'],'http') !== false ? $this->Config['PluginVar']['WxImg'] : $_G['siteurl'].$this->Config['PluginVar']['WxImg'],
			'WxUrl' => $this->Config['Url']
		);

		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_xiangqin')){
			//@require_once DISCUZ_ROOT.'./source/plugin/fn_xiangqin/Function.inc.php';
			//$this->Fn_XiangQin = $Fn_XiangQin;
		}
		
		if(!is_dir(DISCUZ_ROOT.$this->Config['StaticPicPath'])){
			mkdir(DISCUZ_ROOT.$this->Config['StaticPicPath']);
		}
		$this->TableHd = 'fn_hd';
		$this->TableClass = 'fn_hd_class';
		$this->TableField = 'fn_hd_field';
		$this->TableSignUp = 'fn_hd_sign_up';
		$this->Pay->TablePayLog = 'fn_hd_pay_log';
		$this->TablePost = 'fn_hd_post';
		$this->TablePostTableId = 'fn_hd_post_tableid';
		$this->TableVip = 'fn_hd_vip';
		$this->TableVipMember = 'fn_hd_vip_member';
		
		$this->Pay = new Fn_PayLog();
		$this->MagApp = new MagApp($this->Config['PluginVar']['MagSecret']);
		$this->QHApp = new QHApp($this->Config['PluginVar']['qf_type']);
		$this->Config['AppPaymentId'] = $this->QHApp->AppPaymentId;
	}

	/* 用户资料 */
	public function GetUserInfo($Uid=null){
		global $_G;
		$Uid = $Uid ? intval($Uid) : intval($_G['uid']);
		$UserInfo = DB::fetch_first('SELECT M.*,C.extcredits1,C.extcredits2,C.extcredits3,C.extcredits4,C.extcredits5,C.extcredits6,C.extcredits7,C.extcredits8 FROM '.DB::table('common_member').' M LEFT JOIN '.DB::table('common_member_count').' C on C.uid = M.uid where M.uid = '.$Uid);
		if($UserInfo){
			$UserInfo['face'] = discuz_uc_avatar($UserInfo['uid'],'middle',true);
		}
		return $UserInfo;
	}
	
	/* 活动详情 */
	public function GetViewthread($Id){
		$Item = DB::fetch_first('SELECT C.vip_id,C.name,C.xiangqin,H.* FROM '.DB::table($this->TableHd).' H LEFT JOIN '.DB::table($this->TableClass).' C on C.id = H.classid where H.display = 1 and H.id = '.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['param']['content'] = stripslashes($Item['param']['content']);
			$Item['param']['review'] = stripslashes($Item['param']['review']);
			$Item['week'] = $this->Config['LangVar']['WeekArray'][date('w',$Item['start_time'])];
			$Item['param']['custom_explain'] = array_filter(explode("\r\n",$Item['param']['custom_explain']));

			if($Item['param']['payment_type'] == 1){//现金费用
				$Item['cost'] = $Item['param']['money'];
				if($Item['param']['vip_money']){
					$Item['vip'] = true;
					$Item['vip_cost'] = $Item['param']['vip_money'];
					$Item['vip_count_cost'] = $Item['param']['money'] - $Item['param']['vip_money'];
				}
			}else if($Item['param']['payment_type'] == 2){//积分费用
				$Item['cost'] = $Item['param']['extcredits'];
				if($Item['param']['vip_extcredits']){
					$Item['vip'] = true;
					$Item['vip_cost'] = $Item['param']['vip_extcredits'];
					$Item['vip_count_cost'] = $Item['param']['extcredits'] - $Item['param']['vip_extcredits'];
				}
			}
			//活动状态
			if($Item['sign_up_start_time'] > time()){
				$State = 0;
			}elseif(time() > $Item['sign_up_start_time']  && time() < $Item['sign_up_end_time']){
				if($this->GetSignUpCount(' and examine  = 1 and aid = '.$Item['id']) >= $Item['param']['people'] && $Item['param']['people']){
					$State = 2;
				}else{
					$State = 1;
				}
			}else if(time() > $Item['sign_up_end_time'] && time() < $Item['start_time']){
				$State = 2;
			}else if(time() > $Item['start_time']  && time() < $Item['end_time']){
				$State = 3;
			}else{
				$State = 4;
			}
			$Item['state'] = $State;
		}
		return $Item;
	}
	
	//活动列表
	public function GetAjaxList($Get){
		global $_G;
		$Results = array();
		$Get = StrToGBK($Get);
		$Page = $Get['page'] ? intval($Get['page']):0;
		$Where = ' and H.display = 1';
		$Order = 'H.'.$this->Config['PluginVar']['ListOrder'];
		
		if($_GET['type']){
			$Where .= ' and H.type = '.intval($_GET['type']);
		}

		if($_GET['classid']){
			$Where .= ' and H.classid IN ('.addslashes(strip_tags($_GET['classid'])).')';
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$FetchSql = 'SELECT C.name,C.xiangqin,H.* FROM '.DB::table($this->TableHd).' H LEFT JOIN '.DB::table($this->TableClass).' C on C.id = H.classid '.$Where .' order by '.$Order.' desc '.$Limit;
		$Results = $this->ListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}

	/* 我参与的 */
	public function GetAjaxJoinList($Get){
		global $_G;
		$Results = array();
		
		$Page = $Get['page'] ? intval($Get['page']):0;

		$this->Config['PluginVar']['ListNum'] = $this->Config['PluginVar']['ListNum'] ? $this->Config['PluginVar']['ListNum'] : 10;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['ListNum']).','.$this->Config['PluginVar']['ListNum'];

		$FetchSql = 'SELECT H.*,S.dateline as sign_up_dateline,S.display as sign_up_display,S.examine,S.id as sid FROM '.DB::table($this->TableSignUp).' S LEFT JOIN `'.DB::table($this->TableHd).'` H on H.id = S.aid WHERE S.uid = '.intval($_G['uid']).' order by S.dateline desc '.$Limit;
		$Results = $this->ListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}

	/* 列表格式转换 */
	public function ListFormat($Array){
		global $_G;
		@require_once libfile('function/forum');
		foreach ($Array as $Key => $Val) {
			$Val['param'] = unserialize($Val['param']);
			$Array[$Key]['param'] = $Val['param'];
			$Array[$Key]['face'] = discuz_uc_avatar($Val['uid'],'middle',true);
			$Array[$Key]['start_time'] = date('Y-m-d H:i',$Val['start_time']);
			$Array[$Key]['sign_up_dateline'] = date('Y-m-d',$Val['sign_up_dateline']);
			$Array[$Key]['sign_up_count'] = $this->GetSignUpCount(' and aid = '.$Val['id']);
			$Array[$Key]['sign_up_count_text'] = str_replace(array("{Count}"),array($this->GetSignUpCount(' and aid = '.$Val['id'])),$this->Config['LangVar']['SignUpCountText']);
			$Array[$Key]['week'] = $this->Config['LangVar']['WeekArray'][date('w',$Val['start_time'])];
		
			if($Val['sign_up_start_time'] > time()){
				$State = 0;
			}else if(time() > $Val['sign_up_start_time']  && time() < $Val['sign_up_end_time']){
				if($this->GetSignUpCount(' and examine  = 1 and aid = '.$Val['id']) >= $Val['param']['people'] && $Val['param']['people']){
					$State = 2;
				}else{
					$State = 1;
				}
			}else if(time() > $Val['sign_up_end_time'] && time() < $Val['start_time']){
				$State = 2;
			}else if(time() > $Val['start_time']  && time() < $Val['end_time']){
				$State = 3;
			}else{
				$State = 4;
			}
			$Array[$Key]['state'] = $State;
			$Array[$Key]['state_text'] = $this->Config['LangVar']['StateArray'][$State];
			$Array[$Key]['type_text'] = $this->Config['LangVar']['TypeArray'][$Val['type']].$this->Config['LangVar']['ActivityTitle'];
			if($Val['param']['more_cost_list'] || ($Val['xiangqin'] && $Val['param']['xiangqin_more_cost'])){
				$Array[$Key]['cost_text'] = $this->Config['LangVar']['SelfSelection'];
			}else{
				if($Val['param']['payment_type'] == 2){
					$Array[$Key]['cost_text'] = $Val['param']['extcredits'] ? $Val['param']['extcredits'].$Val['param']['extcredits_title'] : $this->Config['LangVar']['FreeAdmission'];
				}else if($Val['param']['payment_type'] == 1){
					$Array[$Key]['cost_text'] = $Val['param']['money'] ? $Val['param']['money'] : $this->Config['LangVar']['FreeAdmission'];
				}
			}
		}
		return $Array;
	}
	
	//分类列表
	public function GetClassList($Type=null){
		//$Where = $Type ? ' and type = '.intval($Type) : '';
		return DB::fetch_all('SELECT * FROM '.DB::table($this->TableClass).' where display = 1 '.$Where.' order by displayorder asc','','id');
	}

	//报名表单列表
	public function GetFieldList(){
		$FieldList = DB::fetch_all('SELECT * FROM '.DB::table($this->TableField).' order by displayorder asc','','id');
		foreach($FieldList as $Key => $Val){
			$FieldList[$Key]['choices'] = unserialize($Val['choices']);
		}
		return $FieldList;
	}
	
	//报名统计
	public function GetSignUpCount($Where=null){
		$Count = DB::result_first('SELECT sum(count) FROM '.DB::table($this->TableSignUp).' where display = 1 '.$Where);
		return $Count ? $Count : 0;
	}

	/* 报名列表 */
	public function GetAjaxSignUpList($Get){
		global $_G;
		$Results = array();
		$Page = $Get['page'] ? intval($Get['page']):0;
		$Where = ' and S.display = 1';
		$Order = 'S.id';
		
		if(in_array($Get['type'],array('0','1'))){
			$Where .= ' and S.examine = '.intval($Get['type']);
		}

		if($Get['aid']){
			$Where .= ' and S.aid = '.intval($Get['aid']);
		}
		
		$Where = preg_replace('/and/','where',$Where,1);
		$this->Config['PluginVar']['SignUpListNum'] = $Get['limit'] ? $Get['limit'] : $this->Config['PluginVar']['SignUpListNum'];
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['SignUpListNum']).','.$this->Config['PluginVar']['SignUpListNum'];
		
		$Results =  DB::fetch_all('SELECT C.xiangqin,S.* FROM '.DB::table($this->TableSignUp).' S LEFT JOIN '.DB::table($this->TableHd).' H on H.id = S.aid LEFT JOIN '.DB::table($this->TableClass).' C on C.id = H.classid '.$Where .' order by '.$Order.' desc '.$Limit);

		foreach($Results as $Key => $Val) {
			$Results[$Key]['param'] = unserialize($Val['param']);
			$Results[$Key]['dateline'] = date('Y-m-d H:i',$Val['dateline']);
//			if($Val['xiangqin']){
//				$XiangQinUserInfo = $this->Fn_XiangQin->GetUserInfo($Val['uid']);
//				$Results[$Key]['username'] = $XiangQinUserInfo['name'] ? $XiangQinUserInfo['name'] : $Val['username'];
//				$Results[$Key]['face'] = $XiangQinUserInfo['face'] ? $XiangQinUserInfo['face'] : discuz_uc_avatar($Val['uid'],'middle',true);
//			}else{
				$Results[$Key]['face'] = discuz_uc_avatar($Val['uid'],'middle',true);
			//}
		}

		return $Results;
	}

	/* 报名详情 */
	public function GetSignUp($AId=Null,$Id=null,$Uid=true){
		global $_G;
		$Where .= $AId ? ' and S.aid = '.intval($AId) : '';
		$Where .= $Id ? ' and S.id = '.intval($Id) : '';
		$Where .= $Uid ? ' and S.uid = '.intval($_G['uid']) : '';
		$Where = preg_replace('/and/','where',$Where,1);
		$Item = DB::fetch_first('SELECT C.xiangqin,H.title,H.start_time,H.username as leader,H.param as hparam,S.* FROM '.DB::table($this->TableSignUp).' S LEFT JOIN '.DB::table($this->TableHd).' H on H.id = S.aid LEFT JOIN '.DB::table($this->TableClass).' C on C.id = H.classid '.$Where);
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['hparam'] = unserialize($Item['hparam']);
//			if($Item['xiangqin']){
//				$XiangQinUserInfo = $this->Fn_XiangQin->GetUserInfo($Item['uid']);
//				$Item['username'] = $XiangQinUserInfo['name'] ? $XiangQinUserInfo['name'] : $Item['username'];
//				$Item['face'] = $XiangQinUserInfo['face'] ? $XiangQinUserInfo['face'] : discuz_uc_avatar($Item['uid'],'middle',true);
//			}else{
				$Item['face'] = discuz_uc_avatar($Item['uid'],'middle',true);
			//}
		}
		return $Item;
	}

	/* 报名 */
	public function GetAjaxSignUp($Get){
		global $_G;
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->GetViewthread($Get['aid']);
		$Data = array();
		if($Item){
			
			//报名是否开始或结束
			if(in_array($Item['state'],array('0'))){
				$Msg = $this->Config['LangVar']['StateArray'][$Item['state']];
			}else if($Item['state'] != 1){
				$Msg = $this->Config['LangVar']['StateArray'][2];
			}
			if($Msg){
				$Data['Msg'] = urlencode($Msg);
				return $Data;
			}
			//报名是否开始或结束 End
			
			/*if($Item['xiangqin'] && $Item['param']['xiangqin_more_cost_list'] && ($Item['param']['male_people'] || $Item['param']['female_people'])){
				if($Item['param']['male_people'] && $this->GetSignUpCount(' and aid = '.$Item['id'].' and examine = 1 and sex = 1') >= $Item['param']['male_people']){//男士人数判断
					$Data['Msg'] = urlencode(str_replace(array('{Num}'),array($Item['param']['male_people']),$this->Config['LangVar']['MaleLimitPeopleErr']));
					return $Data;
				}

				if($Item['param']['female_people'] && $this->GetSignUpCount(' and aid = '.$Item['id'].' and examine = 1 and sex = 2') >= $Item['param']['female_people']){//女士人数判断
					$Data['Msg'] = urlencode(str_replace(array('{Num}'),array($Item['param']['female_people']),$this->Config['LangVar']['FemaleLimitPeopleErr'])); 
					return $Data;
				}
			}*/
			
			if($this->GetSignUpCount(' and aid = '.$Item['id'].' and (examine = 1 or examine = 0)') >= $Item['param']['people'] && $Item['param']['people']){//人数判断
				$Data['Msg'] = urlencode(str_replace(array('{Num}'),array($Item['param']['people']),$this->Config['LangVar']['PeopleErr']));    
				return $Data;
			}
			
			$SignUpItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSignUp).' where aid = '.intval($Item['id']).' and id = '.intval($Get['sid']).' and uid = '.intval($_G['uid']));

			if($SignUpItem['examine'] == 1){
				$Data['Msg'] = urlencode($this->Config['LangVar']['EditExamineErr']);
				return $Data;
			}
			
			$FieldList = $this->GetFieldList();
			$FormList = array();
			$Cost = '';
			if($Item['param']['more_cost_list'] && !$Item['xiangqin']){
				if($Item['param']['sign_up_data_switch']){
					foreach($Item['param']['more_cost_list'] as $Key => $Val){
						$Cost += $Get['more_cost'][$Key] * $Val['value'];
						$Value[] = $Get['more_cost'][$Key] ? $Val['title'].$Get['more_cost'][$Key].$this->Config['LangVar']['Ren'] : '';
						$Param['more_cost_list'][$Key] = intval($Get['more_cost'][$Key]);
					}
					$FormList[1]['more_cost']['value'] = implode($this->Config['LangVar']['DouHao'],array_filter($Value));
					$FormList[1]['more_cost']['title'] = $this->Config['LangVar']['SignUpType'];
					
				}else{
					foreach(explode(";",$Get['more_cost'][0]) as $Key => $Val){
						$FormList[$Key+1]['more_cost']['value'] = $Item['param']['more_cost_list'][$Val]['title'];
						$FormList[$Key+1]['more_cost']['val'] = $Val;
						$FormList[$Key+1]['more_cost']['title'] = $this->Config['LangVar']['SignUpType'];
						$Cost += $Item['param']['more_cost_list'][$Val]['value'];//多项目费用
					}		
				}
			}
//			$XiangQinUserInfo = $Item['xiangqin'] ? $this->Fn_XiangQin->GetUserInfo($_G['uid']) : '';
//			if($Item['xiangqin']){
//				$FormList[1]['name']['title'] = addslashes(strip_tags($this->Fn_XiangQin->Config['LangVar']['NameTitle']));
//				$FormList[1]['name']['value'] = censor(addslashes(strip_tags($XiangQinUserInfo['name'])));
//				$FormList[1]['mobile']['title'] = addslashes(strip_tags($this->Fn_XiangQin->Config['LangVar']['MobileTitle']));
//				$FormList[1]['mobile']['value'] = censor(addslashes(strip_tags($XiangQinUserInfo['mobile'])));
//				$FormList[1]['sex']['title'] = addslashes(strip_tags($this->Fn_XiangQin->Config['LangVar']['SexTitle']));
//				$FormList[1]['sex']['value'] = censor(addslashes(strip_tags($this->Fn_XiangQin->Config['LangVar']['SexArray'][$XiangQinUserInfo['sex']])));
//				$FormList[1]['age']['title'] = addslashes(strip_tags($this->Fn_XiangQin->Config['LangVar']['AgeTitle']));
//				$FormList[1]['age']['value'] = intval($XiangQinUserInfo['age']);
//
//				$FormList[1]['month_income']['title'] = addslashes(strip_tags($this->Fn_XiangQin->Config['LangVar']['MonthIncomeTitle']));
//				$FormList[1]['month_income']['value'] = censor(addslashes(strip_tags($this->Fn_XiangQin->Config['LangVar']['MonthIncomeArray'][$XiangQinUserInfo['month_income']])));
//
//				$FormList[1]['height']['title'] = addslashes(strip_tags($this->Fn_XiangQin->Config['LangVar']['HeightTitle']));
//				$FormList[1]['height']['value'] = censor(addslashes(strip_tags($this->Fn_XiangQin->Config['LangVar']['UserInfoHeightArray'][$XiangQinUserInfo['height']])));
//
//				$FormList[1]['weight']['title'] = addslashes(strip_tags($this->Fn_XiangQin->Config['LangVar']['WeightTitle']));
//				$FormList[1]['weight']['value'] = censor(addslashes(strip_tags($this->Fn_XiangQin->Config['LangVar']['UserInfoWeightArray'][$XiangQinUserInfo['weight']])));
//			
//			}else{
				foreach($Item['param']['sign_up_form'] as $Key => $Val){
					
					foreach(explode(";",$Get[$FieldList[$Val]['name']][0]) as $K => $V){
						$FileArray = explode(";",$Get['new_'.$FieldList[$Val]['name']][0]);
						if($FieldList[$Val]['required'] && in_array($FieldList[$Val]['formtype'],array('file')) && !$FileArray[$K]){//图片类型判断
							$Data['Msg'] = urlencode(str_replace(array('{Name}'),array($FieldList[$Val]['title']),$this->Config['LangVar']['SignUpFormFileErr']));
							return $Data;
							break;
						}else if($FieldList[$Val]['required'] && !$V && !in_array($FieldList[$Val]['formtype'],array('file'))){
							$Data['Msg'] = urlencode(str_replace(array('{Name}'),array($FieldList[$Val]['title']),$this->Config['LangVar']['SignUpFormErr']));
							return $Data;
							break;
						}else if(dstrlen($V) >= $FieldList[$Val]['size'] && $FieldList[$Val]['size']){
							$Data['Msg'] = urlencode(str_replace(array('{Name}','{Size}'),array($FieldList[$Val]['title'],$FieldList[$Val]['size']),$this->Config['LangVar']['SignUpFormLengthErr']));
							return $Data;
							break;
						}else if(!preg_match("/".$FieldList[$Val]['match']."/",$V) && $FieldList[$Val]['match']){
							$Data['Msg'] = urlencode(str_replace(array('{Name}'),array($FieldList[$Val]['title']),$this->Config['LangVar']['SignUpFormMatchErr']));
							return $Data;
							break;
						}else{
							if(in_array($FieldList[$Val]['formtype'],array('file'))){
								$V = $FileArray[$K];
								if($V){
									$V = strpos($V,'http') !== false ? $V : $_G['siteurl'].$V;
								}
								$FormList[$K+1][$FieldList[$Val]['name']]['file'] = true;
							}

							$FormList[$K+1][$FieldList[$Val]['name']]['value'] = addslashes(strip_tags($V));

							$FormList[$K+1][$FieldList[$Val]['name']]['title'] = addslashes(strip_tags($FieldList[$Val]['title']));
						}
					}
				}
//			}
			if($Item['param']['sign_up_data_switch'] && $Get['number'] > $Item['param']['limit_people']){//人数判断
				$Data['Msg'] = str_replace(array("{Num}"),array($Item['param']['limit_people']),$this->Config['LangVar']['LimitPeopleErr']);
				return $Data;
			}

			if(!$Item['param']['sign_up_data_switch'] && count($FormList) > $Item['param']['limit_people']){//人数判断
				$Data['Msg'] = str_replace(array("{Num}"),array($Item['param']['limit_people']),$this->Config['LangVar']['LimitPeopleErr']);
				return $Data;
			}

			$UpData['count'] = $Item['param']['sign_up_data_switch'] ? $Get['number'] : intval(count($FormList));

			
			if(!$Item['param']['more_cost_list'] || $Item['xiangqin']){//非多项目的费用
				if($Item['xiangqin'] && $Item['param']['xiangqin_more_cost_list']){//相亲多项目费用
					$Cost = $Item['param']['xiangqin_more_cost_list'][$XiangQinUserInfo['sex']];
				}else{
					if($Item['param']['payment_type'] == 2){
						$Cost = $Item['param']['extcredits'] * $UpData['count'];
					}else if($Item['param']['payment_type'] == 1){
						$Cost = $Item['param']['money'] * $UpData['count'];
					}
				}
				
			}

			$VipMember = $this->GetVipMember($Item['vip_id']);
			if(($VipMember['is_vip'] && !$Item['xiangqin']) || ($XiangQinUserInfo['vip'])){//vip优惠后的价格
				if($Item['param']['payment_type'] == 2 && $Item['param']['vip_extcredits'] <= $Cost){
					$Cost = $Cost - $Item['param']['vip_extcredits'];
				}else if($Item['param']['payment_type'] == 1 && $Item['param']['vip_money'] <= $Cost){
					$Cost = $Cost - $Item['param']['vip_money'];
				}
			}
	
			if($Item['param']['payment_type'] == 2 && $Cost && !$SignUpItem){//积分判断
				$UserInfo = $this->GetUserInfo();
				if($UserInfo['extcredits'.$Item['param']['extcredits_type']] < $Cost){
					if($this->Config['PluginVar']['ExtcreditsLink']){
						$Data['State'] = 201;
						$Data['Msg'] = urlencode(str_replace(array('{ExtcreditsTitle}'),array($Item['param']['extcredits_title']),$this->Config['LangVar']['ExtcreditsLinkErr']));
					}else{
						$Data['Msg'] = urlencode(str_replace(array('{ExtcreditsTitle}'),array($Item['param']['extcredits_title']),$this->Config['LangVar']['ExtcreditsErr']));
					}
					return $Data;
				}
			}

			//是否已经报名
			$CheCkSignUp = $this->GetSignUp($Item['id']);
			if($CheCkSignUp && !$SignUpItem){
				$UpData['updateline'] = time();
				$Param['form_list'] = $FormList;
				$Param['cost'] = $Cost;
				$UpData['param'] = serialize($Param);
				DB::update($this->TableSignUp,$UpData,'id = '.intval($CheCkSignUp['id']));
				if($CheCkSignUp['id'] && $Item['param']['payment_type'] == 1 && $Cost){//现金支付
					$Data['sid'] = $CheCkSignUp['id'];
					$Data['money'] = $Cost;
					$PayLog = $this->GetAjaxPayLog(array('event'=>'sign_up','sid'=>$Data['sid'],'money'=>$Data['money']));
					$Data['pay_id'] = $PayLog['Id'];
					$Data['State'] = 202;
					return $Data;
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['SignUpRepeat']);
					return $Data;
				}
			}
			//是否已经报名 End
			
			$UpData['aid'] = intval($Item['id']);
			$UpData['uid'] = intval($_G['uid']);
			$UpData['username'] = addslashes(strip_tags($_G['username']));

			$UpData['sex'] = $Item['xiangqin'] ? $XiangQinUserInfo['sex'] : 0;

			$Param['form_list'] = $FormList;
			$Param['cost'] = $Cost;
			$UpData['param'] = serialize($Param);
			if($SignUpItem){//更新活动
				$UpData['updateline'] = time();
				DB::update($this->TableSignUp,$UpData,'id = '.intval($SignUpItem['id']));
				$Data['sid'] = $SignUpItem['id'];
//				if($Data['sid'] && $Item['param']['payment_type'] == 1 && $Item['param']['money']){//现金支付
//					$Data['money'] = $Item['param']['money'] * $SignUpItem['count'];
//					$PayLog = $this->GetAjaxPayLog(array('event'=>'sign_up','sid'=>$Data['sid'],'money'=>$Data['money']));
//					$Data['pay_id'] = $PayLog['Id'];
//					$Data['State'] = 202;
//				}else{
					$Data['State'] = 200;
					$Data['Msg'] = App ? urlencode($this->Config['LangVar']['SignUpEditAppOk']) : urlencode($this->Config['LangVar']['SignUpEditOk']);
//				}

			}else{
				$UpData['examine'] = $Item['param']['sign_up_switch'] ? 1 : 0;
				$UpData['display'] = $Item['param']['payment_type'] == 1 && $Cost ? 0 : 1;
				$UpData['dateline'] = $UpData['updateline'] = time();

				for($I = 0;$I < 100;$I++){//核销码
					$UpData['code'] = rand(1000,99999999);
					if(!DB::fetch_first('SELECT * FROM '.DB::table($this->TableSignUp).' where aid = '.intval($Item['id']).' and code = '.intval($UpData['code']))){
						break;
					};
				}

				$Data['sid'] = DB::insert($this->TableSignUp,$UpData,true);
				$Data['State'] = 200;
				$Data['Msg'] = App ? urlencode($this->Config['LangVar']['SignUpAppOk']) : urlencode($this->Config['LangVar']['SignUpOk']);

				if($Data['sid'] && $Item['param']['payment_type'] == 2 && $Cost){//减少积分操作
					updatemembercount($_G['uid'],array("extcredits".$Item['param']['extcredits_type'] => - $Cost));
				}else if($Data['sid'] && $Item['param']['payment_type'] == 1 && $Cost){//现金支付
					$Data['money'] = $Cost;
					$PayLog = $this->GetAjaxPayLog(array('event'=>'sign_up','sid'=>$Data['sid'],'money'=>$Data['money']));
					$Data['pay_id'] = $PayLog['Id'];
					$Data['State'] = 202;
				}
			}
			return $Data;

		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoDataErr']);
			return $Data;
		}
	}

	/* 未支付再次支付 */
	public function GetAjaxSignUpPayment($AId,$Id){
		global $_G;
		$Item = $this->GetSignUp($AId,$Id);
		if($Item){
			if($this->GetSignUpCount(' and aid = '.$AId.' and (examine = 1 or examine = 0)') >= $Item['hparam']['people'] && $Item['hparam']['people']){//人数判断
				$Data['Msg'] = urlencode(str_replace(array('{Num}'),array($Item['hparam']['people']),$this->Config['LangVar']['PeopleErr']));    
				return $Data;
			}
			if($Item['hparam']['payment_type'] == 2 && $Item['param']['cost']){//积分判断
				$UserInfo = $this->GetUserInfo();
				if($UserInfo['extcredits'.$Item['hparam']['extcredits_type']] < $Item['param']['cost']){
					if($this->Config['PluginVar']['ExtcreditsLink']){
						$Data['State'] = 201;
						$Data['Msg'] = urlencode(str_replace(array('{ExtcreditsTitle}'),array($Item['hparam']['extcredits_title']),$this->Config['LangVar']['ExtcreditsLinkErr']));
					}else{
						$Data['Msg'] = urlencode(str_replace(array('{ExtcreditsTitle}'),array($Item['hparam']['extcredits_title']),$this->Config['LangVar']['ExtcreditsErr']));
					}
					return $Data;
				}
				
				$UpData = array('display'=>1);
				DB::update($this->TableSignUp,$UpData,'id = '.intval($Item['id']));
				updatemembercount($_G['uid'],array("extcredits".$Item['hparam']['extcredits_type'] => -$Item['param']['cost']));//减少积分操作
				$Data['State'] = 200;
				$Data['Msg'] =  urlencode($this->Config['LangVar']['PaymentOk']);
			}else if($Item['hparam']['payment_type'] == 1 && $Item['param']['cost']){
				$Data['sid'] = $Item['id'];
				$Data['money'] = $Item['param']['cost'];
				$PayLog = $this->GetAjaxPayLog(array('event'=>'sign_up','sid'=>$Data['sid'],'money'=>$Data['money']));
				$Data['pay_id'] = $PayLog['Id'];
				$Data['State'] = 202;
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoDataSignUp']);
			return $Data;
		}
	}

	/* 核销检测 */
	public function GetAjaxSignUpUse($AId,$Id){
		global $_G;
		$Item = $this->GetSignUp($AId,$Id);
		$Data['State'] = $Item['state'] == 1 ? 200 : 0;
		return $Data;
	}

	/* 核销码查询 */
	public function GetAjaxVerificationSearch($AId,$Code){
		global $_G;
		$Item = $this->GetViewthread($AId);
		if($Item){
			
			if(!in_array($_G['uid'],array_filter(explode(",",$Item['param']['v_uids'])))){//权限判断
				$Data['Msg'] = urlencode($this->Config['LangVar']['NoJurisdiction']);
				return $Data;
			}
			
			if(!$Code){//核销码判断
				$Data['Msg'] = urlencode($this->Config['LangVar']['VerificationCodePlaceholder']);
				return $Data;
			}

			$SignUpItem = DB::fetch_first('SELECT * FROM '.DB::table($this->TableSignUp).' where aid = '.intval($Item['id']).' and code = '.intval($Code).' and display = 1');

			if($SignUpItem){
				$Data['State'] = 200;
				$Data['Id'] = $SignUpItem['id'];
				return $Data;
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['VerificationCodeErr']);
				return $Data;
			}
			
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoDataErr']);
			return $Data;
		}
	}

	/* 核销 */
	public function GetAjaxVerification($AId,$Id){
		global $_G;
		$Item = DB::fetch_first('SELECT H.title,H.start_time,H.username as leader,H.param as hparam,S.* FROM '.DB::table($this->TableSignUp).' S LEFT JOIN '.DB::table($this->TableHd).' H on H.id = S.aid where S.aid = '.intval($AId).' and S.id ='.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Item['hparam'] = unserialize($Item['hparam']);
			if(!in_array($_G['uid'],array_filter(explode(",",$Item['hparam']['v_uids'])))){
				$Data['Msg'] = urlencode($this->Config['LangVar']['NoJurisdiction']);
				return $Data;
			}

			if($Item['state'] == 1){
				$Data['Msg'] = urlencode($this->Config['LangVar']['UseErr']);
				return $Data;
			}

			$UpData['state'] = 1;
			$UpData['statedateline'] = time();
			$UpData['v_uid'] = intval($_G['uid']);
			$UpData['v_username'] = addslashes(strip_tags($_G['username']));
			DB::update($this->TableSignUp,$UpData,'id = '.intval($Item['id']));
			$Data['State'] = 200;
			$Data['Msg'] = urlencode($this->Config['LangVar']['VerificationOk']);
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoTicketErr']);
			return $Data;
		}
	}
	/* 删除自己报名 */
	public function GetAjaxDelSignUp($AId,$Id){
		global $_G;
		$Item = $this->GetSignUp($AId,$Id);
		if($Item){
			if(DB::delete($this->TableSignUp,'id ='.$Item['id'])){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelSignUpOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelSignUpErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoDataSignUp']);
			return $Data;
		}
	}
	/* 管理员报名操作 */
	public function GetAjaxSignUpOp($AId,$Id,$Type){
		global $_G;
		$Item = $this->GetSignUp($AId,$Id,false);
		if($Item){
			if(!in_array($_G['uid'],array_filter(explode(",",$Item['hparam']['v_uids'])))){
				$Data['Msg'] = urlencode($this->Config['LangVar']['NoJurisdiction']);
				return $Data;
			}
			if(in_array($Type,array('Examine1','Examine0'))){
				if($Type == 'Examine1'){
					$Value = 1;
					$Data['Msg'] = urlencode($this->Config['LangVar']['SignUpOpExamine1Ok']);
				}else if($Type == 'Examine0'){
					$Value = 0;
					$Data['Msg'] = urlencode($this->Config['LangVar']['SignUpOpExamine0Ok']);
				}
				$UpData['examine'] = $Value;
				DB::update($this->TableSignUp,$UpData,'id = '.$Item['id']);
				$Data['State'] = 200;
			}else if($Type == 'Del'){
				if(DB::delete($this->TableSignUp,'id ='.$Item['id'])){
					$Data['State'] = 201;
					$Data['Msg'] = urlencode($this->Config['LangVar']['DelSignUpOk']);
				}else{
					$Data['Msg'] = urlencode($this->Config['LangVar']['DelSignUpErr']);
				}
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoDataSignUp']);
			return $Data;
		}
	}

	//报名Html
	public function GetFormHtml($Array,$Value=array()){
		$FieldList = $this->GetFieldList();
		$Html = '';
		$FileJs = '';

		//图片上传
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}

		foreach($Array as $Key => $Val){
			$Html .= '<li'.( in_array($FieldList[$Val]['formtype'],array('textarea','file')) ? ' class=NoHeight' : '').'><div class="Title">'.($FieldList[$Val]['required'] ? '<span class=ColorRed>*</span>' : '<span style="margin:0 0.15rem 0 0;"></span>').$FieldList[$Val]['title'].'</div>';
			if(in_array($FieldList[$Val]['formtype'],array('text','tel'))){
				$Html .= '<input type="'.$FieldList[$Val]['formtype'].'" class="Input" name="'.$FieldList[$Val]['name'].'[]" placeholder="'.$FieldList[$Val]['description'].'" value="'.$Value[$FieldList[$Val]['name']]['value'].'">';
			}else if(in_array($FieldList[$Val]['formtype'],array('select'))){
				$Html .= '<div class="Select iconfont"><select name="'.$FieldList[$Val]['name'].'[]">';
				foreach($FieldList[$Val]['choices'] as $K => $V){
					$Html .= '<option value="'.$V.'"'.($V == $Value[$FieldList[$Val]['name']]['value'] ? ' selected="selected"' : '').'>'.$V.'</option>';
				}
				$Html .= '</select></div>';
			}else if(in_array($FieldList[$Val]['formtype'],array('file'))){

				$FileHtml = $Value[$FieldList[$Val]['name']]['value'] ? '<div class="PhotoControl PhotoControlApp"> <span class="Close" style="display:block;"></span> <i class="icon-plus">+</i><div class="FilePic" style="display:block;"><table cellspacing="0" cellpadding="0"><tbody><tr><td><div class="PhotoControlImg" style="background:url('.$Value[$FieldList[$Val]['name']]['value'].') no-repeat center;background-size:contain;"></div><input name="new_'.$FieldList[$Val]['name'].'[]" value="'.$Value[$FieldList[$Val]['name']]['value'].'" class="InputFile" type="hidden"></td></tr></tbody></table></div><input class="ReplaceFiledata" name="ReplaceFiledata[]" type="file"></div>' : '';

				$Html .= '<div class="File">'.$FileHtml.'<div class="PhotoControl '.$FieldList[$Val]['name'].'"><i class="icon-plus">+</i>'.( $UploadConfig['HtmlUpload'] ? '<input type="file" class="Filedata" multiple="multiple" name="Filedata"/>' : '').'<input type="hidden" name="'.$FieldList[$Val]['name'].'[]" value="1"></div></div>';
			
				$FileJs .= '$(".'.$FieldList[$Val]['name'].'").AppUpload({InputName:"new_'.$FieldList[$Val]['name'].'",Multiple:true});';
				

			}else if(in_array($FieldList[$Val]['formtype'],array('textarea'))){
				$Html .= '<textarea placeholder="'.$FieldList[$Val]['description'].'" name="'.$FieldList[$Val]['name'].'[]">'.$Value[$FieldList[$Val]['name']]['value'].'</textarea>';
			}
			$Html .= '</li>';
		}
		$Return['Html'] = $Html;
		$Return['FileJs'] = $FileJs;
		return $Return;
	}

	/* 指定Pid评论列表 */
	public function GetPidPostList($AId,$Pid=null){
		$AId = intval($AId);
		if($Pid){
			$Where = ' and P.pid in('.addslashes(strip_tags($Pid)).')';
		}
		$FetchSql = 'SELECT P.* FROM '.DB::table($this->TablePost).' P LEFT JOIN '.DB::table($this->TableHd).' H on H.id = P.aid LEFT JOIN '.DB::table($this->TableClass).' C on C.id = H.classid where P.aid = '.$AId.' and P.display = 1'.$Where.' order by P.dateline desc';
		$Results = $this->POstListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}

	/* 评论列表 */
	public function GetAjaxPostList($AId,$NoPid=null,$Page=null){
		$Page = $Page ? intval($Page):0;
		$AId = intval($AId);
		if($NoPid){
			$Where = ' and P.pid not in('.addslashes(strip_tags($NoPid)).')';
		}
		$this->Config['PluginVar']['PostNum'] = 5;
		$Limit = 'LIMIT '.($Page * $this->Config['PluginVar']['PostNum']).','.$this->Config['PluginVar']['PostNum'];
		$FetchSql = 'SELECT C.xiangqin,P.* FROM '.DB::table($this->TablePost).' P LEFT JOIN '.DB::table($this->TableHd).' H on H.id = P.aid LEFT JOIN '.DB::table($this->TableClass).' C on C.id = H.classid where P.aid = '.$AId.' and P.display = 1'.$Where.' order by P.dateline desc '.$Limit;
		$Results = $this->POstListFormat(DB::fetch_all($FetchSql));
		return $Results;
	}

	/* 评论列表格式转换 */
	public function PostListFormat($Array,$ContentLength=0){
		foreach ($Array as $Key => $Val) {
			$Array[$Key]['param'] = unserialize($Val['param']);
			$Array[$Key]['dateline'] = FormatDate($Val['dateline']);
			$Array[$Key]['content'] = $ContentLength ? cutstr($Val['content'],$ContentLength) : $Val['content'];
			if($Val['rid']){
				$RPost = DB::fetch_first('SELECT content FROM '.DB::table($this->TablePost).' where pid = '.intval($Val['rid']).' and display = 1');
				$Array[$Key]['rcontent'] = $RPost['content'] ? $this->Config['LangVar']['ReplyTitle'].$this->Config['LangVar']['Mao'].$RPost['content'] : '';
			}else{
				$Array[$Key]['rcontent'] = '';
			}
			
//			if($Val['xiangqin']){
//				$XiangQinUserInfo = $this->Fn_XiangQin->GetUserInfo($Val['uid']);
//				$Array[$Key]['username'] = $XiangQinUserInfo['name'] ? $XiangQinUserInfo['name'] : $Val['username'];
//				$Array[$Key]['face'] = $XiangQinUserInfo['face'] ? $XiangQinUserInfo['face'] : discuz_uc_avatar($Val['uid'],'middle',true);
//			}else{
				$Array[$Key]['face'] = discuz_uc_avatar($Val['uid'],'middle',true);
//			}
		}
		return $Array;
	}

	/* 评论 */
	public function GetAjaxComment($AId,$Content,$Type='Comment',$Rid=null){
		global $_G;
		$Uid = intval($_G['uid']);
		$AId = intval($AId);
		$Rid = intval($Rid);
		$Content = censor(addslashes(strip_tags(StrToGBK($Content))));
		$Data = array();
		$Item = $this->GetViewthread($AId);
		if($Item){
			//用户组判断
			$CommentGroups = array_filter($Item['param']['post_groupid']);
			if($CommentGroups && !in_array($_G['member']['groupid'],$CommentGroups)){//用户组限制
				$Data['Msg'] = $this->Config['LangVar']['CommentGroupsErr'];
				return $Data;
			}
			//违规词
			if($Item['param']['post_violation_word_switch']){
				$censor = discuz_censor::instance();
				$censor->check($Content);
				if($censor->modbanned()){
					$Data['Msg'] = $this->Config['LangVar']['WordBanned'];
					return $Data;
				}
			}
			
			//字符限制
			if($Item['param']['post_min_lenth'] && dstrlen($Content) < $Item['param']['post_min_lenth']){//内容不能为空
				$Data['Msg'] = $this->Config['LangVar']['CommentMinLengthErr'];
				return $Data;
			}

			//时间限制
			if($Uid){
				$MyComment = DB::fetch_first('SELECT * FROM '.DB::table($this->TablePost).' where uid = '.$Uid.' order by pid DESC');
			}

			if($Item['param']['post_time'] && time() < strtotime("+".$Item['param']['post_time']." second",$MyComment['dateline'])){
				$TIME = $Item['param']['post_time'] - (time() - $MyComment['dateline']);
				$Data['Msg'] = str_replace('{TIME}',$TIME,$this->Config['LangVar']['CommentTimeErr']);
				return $Data;
			}
			

			$Pid = DB::insert($this->TablePostTableId,array('pid'=>''),true);
			$InsData['pid'] = intval($Pid);
			$InsData['aid'] = $AId;
			$InsData['rid'] = $Rid;
			$InsData['content'] = $Content;
			$InsData['uid'] = $Uid;
			$InsData['username'] = addslashes(strip_tags($_G['username']));
			$InsData['display'] = $Item['param']['post_examine_switch'] ? 0 : 1;
			$InsData['dateline'] = time();
			$InsData['useip'] = addslashes(strip_tags($_G['clientip']));
			$InsData['floor_host'] = $Uid && $Uid == $Item['uid'] ? 1 : 0;
			if(DB::insert($this->TablePost,$InsData)){
				if($Rid && $RPost = DB::fetch_first('SELECT * FROM '.DB::table($this->TablePost).' where pid = '.$Rid.' and display = 1')){
					DB::query("UPDATE ".DB::table($this->TablePost)." SET reply_count = reply_count+1 WHERE pid=".$Rid);
					$Data['rcontent'] = $this->Config['LangVar']['ReplyTitle'].$this->Config['LangVar']['Mao'].$RPost['content'];
				}
				$Data['State'] = 200;
				$Data['dateline'] = FormatDate($InsData['dateline']);
				$Data['content'] = $InsData['content'];
//				if($Item['xiangqin']){
//					$XiangQinUserInfo = $this->Fn_XiangQin->GetUserInfo($Uid);
//					$Data['username'] = $XiangQinUserInfo['name'];
//					$Data['face'] = $XiangQinUserInfo['face'];
//				}else{
					$Data['username'] = $InsData['username'];
					$Data['face'] = discuz_uc_avatar($Uid,'middle',true);
//				}

				return $Data;
			}else{
				$Data['Msg'] = $this->Config['LangVar']['CommentErr'];
				return $Data;
			}
			
		}else{
			$Data['Msg'] = $this->Config['LangVar']['NoDataErr'];
			return $Data;
		}
	}

	/* 管理员操作评论 */
	public function GetAjaxAdminOpPost($Op,$AId,$Id){
		global $_G;
		$Id = intval($Id);
		$AId = intval($AId);
		$Item = $this->GetViewthread($AId);
		if(!in_array($_G['uid'],array_filter(explode(",",$Item['param']['v_uids'])))){
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}
		$Post = DB::fetch_first('SELECT * FROM '.DB::table($this->TablePost).' where pid = '.$Id);
		if(!$Post){
			$Data['Msg'] = $this->Config['LangVar']['CommentNullErr'];
			return $Data;
		}
		if($Op == 'Del'){
			if(DB::delete($this->TablePost,'pid ='.$Id)){
				if($Post['rid']){
					DB::query("UPDATE ".DB::table($this->TablePost)." SET reply_count = reply_count-1 WHERE pid=".intval($Post['rid']));
				}
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelOk']);
			}else{
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['DelErr']);
			}
			return $Data;
		}else if($Op == 'Display'){
			if(DB::update($this->TablePost,array('display'=>0),'pid = '.$Id)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['UpdateErr']);
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['AdminOpErr']);
			return $Data;
		}

	}

	/* 创建支付记录 */
	public function GetAjaxPayLog($Get){
		global $_G;
		$Get = StrToGBK($Get);
		$Param['event'] = addslashes(strip_tags($Get['event']));
		if($Param['event'] == 'sign_up'){
			$Param['sid'] = intval($Get['sid']);
			$Content = $this->Config['LangVar']['RegistrationInformation'].'ID:'.$Get['sid'];
		}else if($Param['event'] == 'buy_vip'){
			$VipItem = $this->GetVipView($Get['vip_id']);
			$VipMember = $this->GetVipMember($Get['vip_id']);
			$Param['vip_id'] = intval($Get['vip_id']);
			$Param['uid'] = intval($_G['uid']);
			$Param['username'] = addslashes(strip_tags($_G['username']));
			$Param['existence'] = $VipMember ? true : false;//是否已存在
			$Param['expire_dateline'] = $VipMember['is_vip'] ? strtotime("+1 years",$VipMember['expire_dateline']) : strtotime("+1 years",time());
			$VipContent = $VipMember['is_vip'] ? $this->Config['LangVar']['IsVipPayTitle'] : $this->Config['LangVar']['VipPayTitle'];
			$Content = str_replace(array("{Title}"),array($VipItem['title']),$VipContent);
		}

		return $this->Pay->PayLogInsert($Get['money'],$Param,$Content,'fn_hd');

	}

	/* 查询单个 */
	public function QueryOne($TableName=null,$Id=null,$Where=null){
		$FirstSql = 'SELECT * FROM '.DB::table($TableName).' where id = '.$Id.' '.$Where;
		return DB::fetch_first($FirstSql);	
	}

	public function PregMatchMobile($Mobile){
		return preg_match('#^1[3-9]{1}[0-9]{9}$#',$Mobile) ? true : false;
	}
	
	/* 会员卡详情 */
	public function GetVipView($Id){
		$Item = DB::fetch_first('SELECT * FROM '.DB::table($this->TableVip).' where display = 1 and id = '.intval($Id));
		if($Item){
			$Item['param'] = unserialize($Item['param']);
		}
		return $Item;
	}

	/* VIP卡列表 */
	public function GetVipList(){
		$FieldList = DB::fetch_all('SELECT * FROM '.DB::table($this->TableVip).' where display = 1 order by id asc','','id');
		foreach($FieldList as $Key => $Val){
			$FieldList[$Key]['param'] = unserialize($Val['param']);
		}
		return $FieldList;
	}
	
	public function GetVipMember($VipId,$Uid=null){
		global $_G;
		$Uid = $Uid ? $Uid : $_G['uid'];
		$VipMember = DB::fetch_first('SELECT V.title,M.* FROM '.DB::table($this->TableVipMember).' M LEFT JOIN `'.DB::table($this->TableVip).'` V on V.id = M.vip_id  where M.uid = '.intval($Uid).' and M.vip_id = '.intval($VipId));
		if($VipMember){
			$VipMember['is_vip'] = $VipMember['expire_dateline'] >= time() ? true : false;
		}
		return $VipMember;
	}

	public function GetVipMemberCount($VipId,$Where=null){
		return DB::result_first('SELECT COUNT(*) FROM '.DB::table($this->TableVipMember).' where vip_id = '.intval($VipId));
	}

	/* 购买会员卡 */
	public function GetAjaxBuyVip($Get){
		global $_G;
		$Get = StrToGBK($Get);
		$Item = $this->GetVipView($Get['vip_id']);
		if($Item){
			$PayLog = $this->GetAjaxPayLog(array('event'=>'buy_vip','vip_id'=>$Item['id'],'money'=>$Item['money']));
			$Data['pay_id'] = $PayLog['Id'];
			$Data['money'] = $Item['money'];
			$Data['State'] = 200;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoDataVipErr']);
		}
		return $Data;
	}
	
}

$Fn_Hd = new Fn_Hd;

?>