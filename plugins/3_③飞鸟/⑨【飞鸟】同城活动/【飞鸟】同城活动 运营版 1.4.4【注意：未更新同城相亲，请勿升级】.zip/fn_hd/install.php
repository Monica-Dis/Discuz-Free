<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_fn_hd` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `classid` int(11) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `start_time` int(11) unsigned NOT NULL,
  `end_time` int(11) unsigned NOT NULL,
  `sign_up_start_time` int(11) unsigned NOT NULL,
  `sign_up_end_time` int(11) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `displayorder` tinyint(4) unsigned NOT NULL,
  `click` int(11) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_hd_class` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `bclassid` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL,
  `ico` varchar(255) NOT NULL DEFAULT '',
  `vip_id` tinyint(3) unsigned NOT NULL,
  `xiangqin` tinyint(1) unsigned NOT NULL,
  `displayorder` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `param` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_hd_field` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `formtype` varchar(30) NOT NULL,
  `required` tinyint(1) unsigned NOT NULL,
  `size` int(8) unsigned NOT NULL,
  `match` varchar(30) NOT NULL,
  `choices` mediumtext NOT NULL,
  `displayorder` tinyint(4) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;


CREATE TABLE IF NOT EXISTS `pre_fn_hd_sign_up` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `v_uid` int(11) unsigned NOT NULL,
  `v_username` varchar(50) NOT NULL,
  `code` int(11) unsigned NOT NULL,
  `sex` tinyint(1) unsigned NOT NULL,
  `count` tinyint(4) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `examine` tinyint(1) unsigned NOT NULL,
  `state` tinyint(1) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `statedateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_hd_post` (
  `pid` int(11) unsigned NOT NULL,
  `aid` int(11) unsigned NOT NULL,
  `rid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(11) NOT NULL,
  `content` mediumtext NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `useip` varchar(30) NOT NULL,
  `reply_count` int(11) unsigned NOT NULL,
  `support_count` int(11) unsigned NOT NULL,
  `floor_host` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `position` int(11) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`aid`,`position`),
  KEY `uid` (`uid`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_hd_post_tableid` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_hd_vip` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `money` decimal(11,2) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_hd_vip_member` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vip_id` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(50) NOT NULL,
  `expire_dateline` int(11) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
?>