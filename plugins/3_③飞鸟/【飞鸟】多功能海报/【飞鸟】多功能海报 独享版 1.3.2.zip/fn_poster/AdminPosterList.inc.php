<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_poster/Function.inc.php');

$Operation = in_array($_GET['Operation'], array('Del')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'];
$OpItemCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminPoster';
$OpPosterLogCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminPosterLog';
$OpPosterShareCpUrl = ADMINSCRIPT.'?'.'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=AdminShareList';

if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ��ѯ���� */
		$MpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = 'P.displayorder';
		$Limit = 30;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		$TdStyle = array('width="60"','');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'Module', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader('');
		showsubtitle(array(
			$Fn_Poster->Config['LangVar']['DisplayOrder'],
			$Fn_Poster->Config['LangVar']['Title'],
			$Fn_Poster->Config['LangVar']['PluginLink'],
			$Fn_Poster->Config['LangVar']['ParticipateCount'],
			$Fn_Poster->Config['LangVar']['DisplayTitle'],
			$Fn_Poster->Config['LangVar']['TimeTitle'],
			$Fn_Poster->Config['LangVar']['OperationTitle']
		), 'header tbm',$TdStyle);
		$RankingList = GetModulesList($Page,$Limit,$Where,$Order);
		$OpCpUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		foreach ($RankingList as $Module) {
			$ParticipateCount = DB::fetch_all("SELECT L.uid FROM ".DB::table($Fn_Poster->TablePosterLog)." L Where L.aid = ".$Module['id']." GROUP BY L.uid");
			showtablerow('', array('class="td25"'), array(
				'<input type="text" size="3" name="displayorder['.$Module['id'].']" value='.$Module['displayorder'].'>',
				'<input type="text" size="25" name="title['.$Module['id'].']" value='.$Module['title'].'>',
				'<input type="text" size="40" value='.$Fn_Poster->Config['Url'].'&aid='.$Module['id'].' readonly>',
				count($ParticipateCount),
				$Module['display'] ? $Fn_Poster->Config['LangVar']['Yes'] : '<span style="color:red">'.$Fn_Poster->Config['LangVar']['No'].'</span>',
				date('Y-m-d H:i',$Module['dateline']),
				'<a href="'.$Fn_Poster->Config['Url'].'&aid='.$Module['id'].'" target="_blank">'.cplang('view').'</a>&nbsp;&nbsp;<a href="'.$OpItemCpUrl.'&aid='.$Module['id'].'">'.$Fn_Poster->Config['LangVar']['EditTitle'].'</a>&nbsp;&nbsp;<a href="'.$OpPosterLogCpUrl.'&aid='.$Module['id'].'">'.$Fn_Poster->Config['LangVar']['ParticipateLog'].'</a>&nbsp;&nbsp;<a href="'.$OpPosterShareCpUrl.'&aid='.$Module['id'].'">'.$Fn_Poster->Config['LangVar']['ShareList'].'</a>&nbsp;&nbsp;<a href="'.$OpCpUrl.'&Operation=Del&aid='.$Module['id'].'&formhash='.FORMHASH.'">'.$Fn_Poster->Config['LangVar']['DelTitle'].'</a>',
			));
		}
		showsubmit('Submit','submit','','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter();/*Dism��taobao��com*/
		/*Dism_taobao_com*/showformfooter();
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['displayorder']) && is_array($_GET['displayorder'])){
			foreach($_GET['displayorder'] as $Id => $Val) {
				$Id = intval($Id);
				$Data['displayorder'] = intval($Val);
				$Data['title'] = addslashes(strip_tags($_GET['title'][$Id]));
				DB::update($Fn_Poster->TablePoster,$Data,'id = '.$Id);
			}
			cpmsg($Fn_Poster->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
		}
	}
}else if($Operation == 'Del' && $_GET['formhash'] == formhash() && $_GET['aid']){//ɾ��
	$AId = intval($_GET['aid']);
	DB::delete($Fn_Poster->TablePoster,'id ='.$AId);
	DB::delete($Fn_Poster->TablePosterLog,'aid ='.$AId);
	DB::delete($Fn_Poster->TableShare,'aid ='.$AId);
	cpmsg($Fn_Poster->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
}
/* �б� */
function GetModulesList($Page,$Limit,$Where=null,$Order){
	global $Fn_Poster;
	$FetchSql = 'SELECT P.* FROM '.DB::table($Fn_Poster->TablePoster).' P '.$Where.' order by '.$Order.' asc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where=null){
	global $Fn_Poster;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Poster->TablePoster).' P '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao-com
?>