<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once libfile('function/core','plugin/fn_assembly');
@require_once libfile('class/magapp','plugin/fn_assembly');
@require_once libfile('class/qfapp','plugin/fn_assembly');

class Fn_Poster{
	public function __construct() {
		global $_G,$plugin;
		loadcache('plugin');
		$this->Config['PluginVar'] = (array) $_G['cache']['plugin']['fn_poster'];
		$this->Config['LangVar'] = lang('plugin/fn_poster');
		$this->Config['Path'] = 'source/plugin/fn_poster';
		$this->Config['StaticPath'] = $this->Config['Path'].'/static';
		$this->Config['StaticPicPath'] = $this->Config['Path'].'/attachment/';
		$this->Config['Url'] = $_G['siteurl'].'plugin.php?id=fn_poster';
		$this->Config['PosterUrl'] = $this->Config['Url'].'&m=poster';
		$this->Config['ImgUrl'] = $this->Config['Url'].':get_img&aid=';
		$this->Config['AjaxUrl'] =  'plugin.php?id=fn_poster:Ajax';
		$this->Config['WxShare'] = array(
			'WxTitle' => $this->Config['PluginVar']['WxTitle'],
			'WxDes' => $this->Config['PluginVar']['WxDes'],
			'WxImg' => strpos($this->Config['PluginVar']['WxImg'],'http') !== false ? $this->Config['PluginVar']['WxImg'] : $_G['siteurl'].$this->Config['PluginVar']['WxImg'],
			'WxUrl' => $this->GetRandShare() ? $this->GetRandShare().'plugin.php?id=fn_poster' : $this->Config['Url']
		);
		if(!is_dir(DISCUZ_ROOT.$this->Config['StaticPicPath'])){
			dmkdir(DISCUZ_ROOT.$this->Config['StaticPicPath']);
		}
		$this->TablePoster = 'fn_poster';
		$this->TablePosterLogTableId = 'fn_poster_log_tableid';
		$this->TablePosterLog = 'fn_poster_log';
		$this->TableShare = 'fn_poster_share';

		$this->MagApp = new MagApp();
		$this->QHApp = new QHApp();
	}
	
	/* 随机分享域名 */
	public function GetRandShare(){
		$ShareDomainArr = array_filter(explode("\r\n",$this->Config['PluginVar']['ShareDomain']));
		if($ShareDomainArr){
			return $ShareDomainArr[rand(0,count($ShareDomainArr) - 1)].'/';
		}
	}

	
	/* 查询海报记录 */
	public function GetPosterLogFirst($Aid,$Lid){
		$Lid = intval($Lid);
		$Aid = intval($Aid);
		$PosterLog = DB::fetch_first('SELECT * FROM '.DB::table($this->TablePosterLog).' where aid = '.$Aid.' and lid = '.$Lid);
		$PosterLog['param'] = unserialize($PosterLog['param']);
		return $PosterLog;
	}
	/* 添加海报记录 */
	public function GetAjaxPosterLog($Get){
		global $_G;
		$Uid = intval($_G['uid']);
		$Get = EncodeURIToUrldeCode($Get);
		$Item = $this->QueryOne($this->TablePoster,intval($Get['aid']),' and display = 1');
		if($Item){
			$Item['param'] = unserialize($Item['param']);
			$Array = array_filter(explode("\r\n",$Item['param']['form_fields']));
			foreach($Array as $Key=>$Val){
				$ToArray = array_filter(explode("|",$Val));
				if($ToArray[4] && (!$Get[$ToArray[1]] || !$Get[$ToArray[1]][0])){
					$Data['Msg'] = urlencode($ToArray[5]);
					return $Data;
					break;
				}else if($ToArray[0] == 'text' && $ToArray[6] && dstrlen($Get[$ToArray[1]]) > $ToArray[6]){
					$Data['Msg'] = urlencode($ToArray[7]);
					return $Data;
					break;
				}else if($ToArray[0] == 'checkbox'){
					$Param['value'][$ToArray[1]] = $Get[$ToArray[1]];
					$Param['title'][$ToArray[1]] = $ToArray[2];
					$Param['filevalue'][$ToArray[1]] = '';
				}else if($ToArray[0] == 'file'){
					$Param['value'][$ToArray[1]] = addslashes(strip_tags($Get[$ToArray[1]][0]));
					$Param['title'][$ToArray[1]] = $ToArray[2];
					$Param['filevalue'][$ToArray[1]] = 1;
				}else{
					$Param['value'][$ToArray[1]] = censor(addslashes(strip_tags($Get[$ToArray[1]])));
					$Param['title'][$ToArray[1]] = $ToArray[2];
					$Param['filevalue'][$ToArray[1]] = '';
				}
			}
			
			$PosterLog = $Uid ? DB::fetch_first('SELECT * FROM '.DB::table($this->TablePosterLog).' where aid = '.$Item['id'].' and uid = '.$Uid) : '';

			if($Item['param']['more_poster_bg']){
				$MorePosterBg = array_filter(explode("\r\n",$Item['param']['more_poster_bg']));
				$Param['poster_bg'] = $MorePosterBg[rand(0,(count($MorePosterBg)-1))];
			}else{
				$Param['poster_bg'] = $Item['param']['poster_bg'];
			}

			if($PosterLog){
				$Param['poster_file'] = '';
				$UpData['param'] = serialize($Param);
				$UpData['updateline'] = time();
				$UpData['useip'] = addslashes(strip_tags($_G['clientip']));
				DB::update($this->TablePosterLog,$UpData,'lid='.intval($PosterLog['lid']).' and aid = '.$Item['id']);
				$Data['State'] = 200;
				$Data['Lid'] = $PosterLog['lid'];
			}else{
				if($this->Config['PluginVar']['MysqlType']){
					$Position = DB::fetch_first('SELECT position FROM '.DB::table($this->TablePosterLog).' where aid = '.$Item['id'].' order by position desc');
					$UpData['position'] = $Position['position'] + 1;
				}
				$UpData['lid'] = $Data['Lid'] = DB::insert($this->TablePosterLogTableId,array('lid'=>''),true);
				$UpData['uid'] = $Uid;
				$UpData['aid'] = $Item['id'];
				$UpData['useip'] = addslashes(strip_tags($_G['clientip']));
				$UpData['username'] = addslashes(strip_tags($_G['username']));
				$UpData['param'] = serialize($Param);
				$UpData['dateline'] = $UpData['updateline'] = time();
				$UpData['position'] = DB::insert($this->TablePosterLog,$UpData,true);
				$Data['State'] = 200;
			}
			return $Data;
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['NoActivity']);
			return $Data;
		}
	}
	/* 表单字段Html */
	public function GetFormFieldHtml($Content){
		$Array = array_filter(explode("\r\n",$Content));
		$Html = '';
		//图片上传
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}
		foreach($Array as $Key=>$Val){
			$ToArray = array_filter(explode("|",$Val));
			$Title = $ToArray[2];
			if($ToArray[0] == 'text'){//输入框
				$FormHtml = '<div class="Input"><input name="'.$ToArray[1].'" placeholder="'.$ToArray[3].'" type="'.$ToArray[0].'" value=""></div>';
			}else if($ToArray[0] == 'radio'){
				$TextArray = array_filter(explode("*",$ToArray[3]));
				$Label = '';
				foreach($TextArray as $K=>$V){//单选框
					$Label .= '<label><input type="'.$ToArray[0].'" value="'.$V.'" name="'.$ToArray[1].'"><span class="iconfont"></span><em>'.$V.'</em></label>';
				}
				$FormHtml = '<div class="Radio">'.$Label.'</div>';
			}else if($ToArray[0] == 'checkbox'){//多选框
				$TextArray = array_filter(explode("*",$ToArray[3]));
				$Label = '';
				foreach($TextArray as $K=>$V){
					$Label .= '<label><input type="'.$ToArray[0].'" value="'.$V.'" name="'.$ToArray[1].'[]"><span class="iconfont"></span><em>'.$V.'</em></label>';
				}
				$FormHtml = '<div class="Checkbox">'.$Label.'</div>';
			}else if($ToArray[0] == 'select'){//下拉框
				$SelectHtml = '<select name="'.$ToArray[1].'"><option value ="">'.$this->Config['LangVar']['ToSelectNull'].'</option>';
				$TextArray = array_filter(explode("*",$ToArray[3]));
				foreach($TextArray as $K=>$V){
					$SelectHtml .= '<option value ="'.$V.'">'.$V.'</option>';
				}
				$SelectHtml .= '</select>';
				$FormHtml = '<div class="Select">'.$SelectHtml.'</div>';
			}else if($ToArray[0] == 'textarea'){//内容框
				$FormHtml = '<div class="Textarea"><textarea name="'.$ToArray[1].'" placeholder="'.$ToArray[3].'"></textarea></div>';
			}else if($ToArray[0] == 'file'){//上传图片
				$FormHtml = '<div class="File"><div class="PhotoControl" id="'.$ToArray[1].'"><i class="icon-plus">+</i>'.( $UploadConfig['HtmlUpload'] ? '<input type="file" class="Filedata" multiple="multiple" name="Filedata"/>' : '').'</div><script>$("#'.$ToArray[1].'").AppUpload({InputName:"'.$ToArray[1].'",Multiple:true})</script></div>';
			}else if($ToArray[0] == 'date' || $ToArray[0] == 'datetime'){//选择时间
				$FormHtml = '<div class="Input"><input name="'.$ToArray[1].'" placeholder="'.$ToArray[3].'" type="'.$ToArray[0].'" value="" readonly="readonly" id="'.$ToArray[1].'"></div><script>
				$("#'.$ToArray[1].'").mobiscroll().'.$ToArray[0].'({
					theme: "android-holo-light",
					mode: "scroller",
					display: "bottom",
					lang: "zh", 
					minDate: new Date("1970/1/1"),
					maxDate: new Date(new Date().setMonth(new Date().getMonth() + 36)),
					dateFormat: "yyyy-mm-dd",
					timeFormat: "HH:ii",
					stepMinute: 1,
					onSelect:function(ValueText,Inst){
						ValueText = ValueText.replace(/T/ig," ");
						ValueText = ValueText.replace(/Z/ig,"");
						$("#'.$ToArray[1].'").val(ValueText);
					}
				});
				</script>';
			}else{
				$FormHtml = '';
			}

			$Html .= $FormHtml ? '<li><span class="Title">'.($ToArray[4] ? '<em>*</em>' : '<em class="No"></em>').$Title.'</span>'.$FormHtml.'</li>' : '';
		}
		return $Html;
	}
	
	/* 分享 */
	public function GetAjaxShare($Aid,$Type){
		global $_G;
		$Aid = intval($Aid);
		$Uid = intval($_G['uid']);
		$Item = $this->QueryOne($this->TablePoster,$Aid);
		$AGENT = $_SERVER["HTTP_USER_AGENT"];
		if((strpos($AGENT,'Appbyme') !== false || strpos($AGENT,'MAGAPPX') !== false || strpos($AGENT,'QianFan') !== false || strpos($AGENT,'MicroMessenger') !== false) && $Item){
			$InsData['aid'] = $Aid;
			$InsData['uid'] = $Uid;
			$InsData['username'] = addslashes(strip_tags($_G['username']));
			$InsData['type'] = addslashes(strip_tags($Type));
			$InsData['dateline'] = time();
			if(DB::insert($this->TableShare,$InsData)){
				$Data['State'] = 200;
				$Data['Msg'] = urlencode($this->Config['LangVar']['ShareOk']);
			}else{
				$Data['Msg'] = urlencode($this->Config['LangVar']['ShareErr']);
			}
		}else{
			$Data['Msg'] = urlencode($this->Config['LangVar']['ShareErr']);
		}
		return $Data;
	}
	
	/* 查询单个 */
	public function QueryOne($TableName=null,$Id=null,$Where=null){
		$FirstSql = 'SELECT * FROM '.DB::table($TableName).' where id = '.$Id.' '.$Where;
		return DB::fetch_first($FirstSql);	
	}

   /**
	* 十六进制 转 RGB
   */
   public function Hex2Rgb($hexColor) {
        $color = str_replace('#','',$hexColor);
        if (strlen($color) > 3) {
            $rgb = array(
                'r' => hexdec(substr($color, 0, 2)),
                'g' => hexdec(substr($color, 2, 2)),
                'b' => hexdec(substr($color, 4, 2))
            );
        } else {
            $color = $hexColor;
            $r = substr($color, 0, 1) . substr($color, 0, 1);
            $g = substr($color, 1, 1) . substr($color, 1, 1);
            $b = substr($color, 2, 1) . substr($color, 2, 1);
            $rgb = array(
                'r' => hexdec($r),
                'g' => hexdec($g),
                'b' => hexdec($b)
            );
        }
		return $rgb;
	}
	
}
$Fn_Poster = new Fn_Poster;
?>