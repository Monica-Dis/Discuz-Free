<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

mb_internal_encoding("UTF-8"); // ���ñ���

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_poster/Function.inc.php');

$Item = $Fn_Poster->QueryOne($Fn_Poster->TablePoster,intval($_GET['aid']),' and display = 1');
if($Item){
	$Item['param'] = unserialize($Item['param']);
	$PosterLog = DB::fetch_first('SELECT * FROM '.DB::table($Fn_Poster->TablePosterLog).' where aid = '.intval($Item['id']).' and lid = '.intval($_GET['lid']));//���ɼ�¼
	$PosterLog['param'] = unserialize($PosterLog['param']);
	if($PosterLog['param']['poster_file'] && file_exists(DISCUZ_ROOT.$PosterLog['param']['poster_file'])){
		$fileDir = $PosterLog['param']['poster_file'];
	}else{
		if($PosterLog['param']['poster_bg']){
			$Item['param']['poster_bg'] = $PosterLog['param']['poster_bg'];
		}else if($Item['param']['more_poster_bg']){
			$MorePosterBg = array_filter(explode("\r\n",$Item['param']['more_poster_bg']));
			$Item['param']['poster_bg'] = $MorePosterBg[rand(0,(count($MorePosterBg)-1))];
		}

		$BigImgPath = strpos($Item['param']['poster_bg'],'http') !== false ? $Item['param']['poster_bg'] : $_G['siteurl'].$Item['param']['poster_bg'];
		$WinBigImgPath = strpos($Item['param']['poster_bg'],'http') !== false ? $Item['param']['poster_bg'] : DISCUZ_ROOT.$Item['param']['poster_bg'];
		
		ob_start();
		switch (array_pop(explode('.',$Item['param']['poster_bg']))) {
			case 'gif': //gif
				$Bg = @imagecreatefromgif($WinBigImgPath);
				$Bg = $Bg ? $Bg : getimagecreatefromstring($BigImgPath);
				break;
			case 'jpg': //jpg
				$Bg = @imagecreatefromjpeg($WinBigImgPath);
				$Bg = $Bg ? $Bg : getimagecreatefromstring($BigImgPath);
				break;
			case 'jpeg': //jpeg
				$Bg = @imagecreatefromjpeg($WinBigImgPath);
				$Bg = $Bg ? $Bg : getimagecreatefromstring($BigImgPath);
				break;
			case 'png': //png
				$Bg = @imagecreatefrompng($WinBigImgPath);
				$Bg = $Bg ? $Bg : getimagecreatefromstring($BigImgPath);
				break;
			default:
				$BgContent = dfsockopen($BigImgPath);
				$BgContent = $BgContent ? $BgContent : file_get_contents($BigImgPath);
				$Bg = getimagecreatefromstring($BigImgPath);
				break;
		
		}
		list($BgWidth, $BgHeight,$BgType) = getimagesize($Item['param']['poster_bg']);
		if(!$BgType){
			list($BgWidth, $BgHeight,$BgType) = getimagesize($BigImgPath);
			if(!$BgType){
				list($BgWidth, $BgHeight,$BgType) = getimagesizefromstring(dfsockopen($BigImgPath));
			}
		}
		$Img = imagecreatetruecolor($BgWidth, $BgHeight);//��������
		imagecopy($Img,$Bg,0,0,0,0,$BgWidth,$BgHeight);//�����������Ʊ���ͼ
		imagedestroy($Bg);//���ٱ���ͼ


		//����ͼ������
		$OtherPosterArr = array_filter(explode("\n",$Item['param']['other_poster']));
		foreach($OtherPosterArr as $Key=>$Val){
			$Array = array_filter(explode("|",$Val));
			$FontSize = $Array[0];
			$Slope = $Array[1];
			$Left = $Array[2];
			$Top = $Array[3];
			$Hex2Rgb = $Fn_Poster->Hex2Rgb($Array[4]);
			$Black = imagecolorallocate($Img,$Hex2Rgb['r'],$Hex2Rgb['g'],$Hex2Rgb['b']);
			$Font = $Fn_Poster->Config['StaticPath'].'/font/'.$Array[5].'.ttf';
			$AutoWidth = $Array[7];
			
			$RandArray = array_filter(explode("-",$Item['param']['rand']));
			$StayArray = array('{Time}','{Num}','{Rand}');
			$StartArray = array(date('Y-m-d',time()),($PosterLog['position']+$Item['param']['initialization_num']),rand($RandArray[0],$RandArray[1]));
			foreach($PosterLog['param']['value'] as $Key=>$Val){//��������
				if(!$PosterLog['param']['filevalue'][$Key]){
					$StayArray[] = '{'.$Key.'}';
					$StartArray[] = is_array($Val) ? implode('/',$Val) : $Val;
				}
			}
			
			$TextArr = array_filter(explode("*",$Array[6]));
			$Text = diconv(str_replace($StayArray,$StartArray,$TextArr[rand(0,(count($TextArr)-1))]),CHARSET,'UTF-8');
			
			$Text = $AutoWidth ? GetAutoWrap($FontSize,$Slope,$Font,$Text,$AutoWidth) : $Text;

			if($Left == 'center'){
				$FontBox = imagettfbbox($FontSize,$Slope,$Font, $Text);//����ˮƽ����ʵ��
				$Left = ceil(($BgWidth - $FontBox[2]) / 2);
			}

			imagettftext($Img,$FontSize,$Slope,$Left,$Top,$Black,$Font,$Text);
		}
		//����ͼ������End

		//����ͼ��ͼƬ
		$OtherPosterImgArr = array_filter(explode("\n",$Item['param']['other_poster_img']));
		foreach($OtherPosterImgArr as $Key=>$Val){
			$Array = array_filter(explode("|",$Val));
			$Left = $Array[0];
			$Top = $Array[1];
			$Transparency = $Array[2];
			$File = $FormName = $QrcodeName = $Array[3];
			if($QrcodeName == 'qrcode' && $Item['param']['qr_code_switch']){
				$Dir = 'data/cache/qrcode/';//�洢·��
				$File = DISCUZ_ROOT.$Dir.'fn_poster_'.$Item['id'].'.jpg';
				if(!file_exists($File) || !filesize($File) || (filesize($File) && file_exists($File) && filemtime($File) + 2592000 <= time())) {
					dmkdir($Dir);
					@require_once libfile('class/wechat','plugin/fn_assembly');
					$WechatClient = new Fn_WeChatClient($Fn_Poster->Config['PluginVar']['WxAppid'] ? $Fn_Poster->Config['PluginVar']['WxAppid'] : $Config['PluginVar']['WxAppid'] , $Fn_Poster->Config['PluginVar']['WxSecret'] ? $Fn_Poster->Config['PluginVar']['WxSecret'] : $Config['PluginVar']['WxSecret']);
					$QrUrl = $WechatClient->getQrcodeImgUrlByTicket($WechatClient->getQrcodeTicket(array('scene_str'=>reset(array_filter(explode(":",$_GET['id']))).'____index____'.$Item['id'],'expire'=>2592000)));
					$return_content = dfsockopen($QrUrl);
					$return_content = $return_content ? $return_content : file_get_contents($QrUrl);
					$return_content = $return_content ? $return_content : CurlGet($QrUrl);
					$fp = @fopen($File,"a"); //���ļ��󶨵���
					fwrite($fp,$return_content); //д���ļ� 
				}
				$File = $Dir.'fn_poster_'.$Item['id'].'.jpg';
				$Array[4] = $Array[4] * 100 . '-' . $Array[4] * 100;
			}else if($QrcodeName == 'qrcode'){
				$QrUrl = $Fn_Poster->Config['WxShare']['WxUrl'].'&m=poster&aid='.$Item['id'].'&lid='.intval($PosterLog['lid']);
				$Dir = 'data/cache/qrcode/';//�洢·��
				$File = $Dir.'fn_poster_'.$Item['id'].'_'.intval($PosterLog['uid']).'.jpg';
				$Size = $Array[4] ? $Array[4] : 4;
				if(!file_exists($File) || !filesize($File)) {
					dmkdir($Dir);
					@require_once libfile('class/qrcode','plugin/fn_assembly');
					QRcode::png($QrUrl,$File,QR_ECLEVEL_L,$Size,2);
				}
			}else if($PosterLog['param']['value'][$FormName]){
				$File = $PosterLog['param']['value'][$FormName];
			}
			
			$UrlFile = strpos($File,'http') !== false ? $File : $_G['siteurl'].$File;

			if($PosterLog['param']['value'][$FormName] || ($QrcodeName == 'qrcode' && $Item['param']['qr_code_switch'] && $UrlFile)){//����ͼƬ ����ͼƬ
				$WH = array_filter(explode("-",$Array[4]));
				if($WH[0] && $WH[1]){
					$MaxWidth = $ImgBgWidth = $WH[0];
					$MaxHeight = $ImgBgHeight = $WH[1];
					$Circular = $WH[2];

					$Src = imagecreatefromstring(file_get_contents($UrlFile));
					$W = imagesx($Src);
					$H = imagesy($Src);
					$H = imagesy($Src);


					/* ����ü����Ⱥ͸߶� */
					$Judge = (($W / $H) > ($MaxWidth / $MaxHeight));
					$Resize_w = $Judge ? ($W * $MaxHeight) / $H : $MaxWidth;
					$Resize_h = !$Judge ? ($H * $MaxWidth) / $W : $MaxHeight;
					$Start_x = $Judge ? ($Resize_w - $MaxWidth) / 2 : 0;
					$Start_y = !$Judge ? ($Resize_h - $MaxHeight) / 2 : 0;
					
					$Resize_img = imagecreatetruecolor($Resize_w, $Resize_h);
					imagecopyresampled($Resize_img, $Src, 0, 0, 0, 0, $Resize_w, $Resize_h, $W, $H);

					$ImgBg = imagecreatetruecolor($MaxWidth, $MaxHeight);
					$Color = imagecolorallocate($ImgBg,255,255,255);
					imagefill($ImgBg,0 ,0,$Color);
					imagecopy($ImgBg, $Resize_img, 0, 0, $Start_x, $Start_y, $Resize_w, $Resize_h);

					//Բ��ͷ��
					if($Circular == 1 && $MaxWidth == $MaxHeight){
						$CircularWidth = min($MaxWidth, $MaxHeight);
						$CircularHeight = $CircularWidth;

						$CircularImgBg = imagecreatetruecolor($CircularWidth, $CircularHeight);
						$Color = imagecolorallocate($CircularImgBg,255,255,255);
						imagefill($CircularImgBg,0 ,0,$Color);
						imagecopy($CircularImgBg, $ImgBg, 0, 0, 0, 0, $CircularWidth, $CircularHeight);

						imagedestroy($ImgBg);//����

						$ImgBg = imagecreatetruecolor($CircularWidth,$CircularHeight);
						$Color = imagecolorallocatealpha($ImgBg, 255,255,255);
						imagefill($ImgBg, 0, 0, $Color);
						imagecolortransparent($ImgBg,$Color);

						$CircularR = $CircularWidth / 2; //Բ�뾶
						$CircularX = $CircularR; //Բ��X����
						$CircularY = $CircularR; //Բ��Y����
						for($CircularX = 0; $CircularX < $CircularWidth; $CircularX++) {
							for ($CircularY = 0; $CircularY < $CircularHeight; $CircularY++) {
								$RgbColor = imagecolorat($CircularImgBg, $CircularX, $CircularY);
								if (((($CircularX - $CircularR) * ($CircularX - $CircularR) + ($CircularY - $CircularR) * ($CircularY - $CircularR)) < ($CircularR * $CircularR))) {
									imagesetpixel($ImgBg, $CircularX, $CircularY, $RgbColor);
								}
							}
						}

						imagedestroy($CircularImgBg);
					}
					//Բ��ͷ��End

					imagedestroy($Src);

				}else{
					$ImgBgContent = dfsockopen($UrlFile);
					$ImgBgContent = $ImgBgContent ? $ImgBgContent : file_get_contents($UrlFile);
					$ImgBg = imagecreatefromstring($ImgBgContent);
					list($ImgBgWidth, $ImgBgHeight,$ImgBgType) = getimagesize($UrlFile);
				}

			}else{
				$ImgBgContent = dfsockopen($UrlFile);
				$ImgBgContent = $ImgBgContent ? $ImgBgContent : file_get_contents($UrlFile);
				$ImgBg = imagecreatefromstring($ImgBgContent);
				list($ImgBgWidth, $ImgBgHeight,$ImgBgType) = getimagesize($UrlFile);
			}
		
			imagecopymerge($Img,$ImgBg,$Left,$Top,0,0,$ImgBgWidth,$ImgBgHeight,$Transparency);//�����������Ʊ���ͼ
			imagedestroy($ImgBg);//���ٱ���ͼ
			if($QrcodeName == 'qrcode' && !$Item['param']['qr_code_switch']){
				unlink($File);
			}
		}
		//����ͼ��ͼƬEnd
		ob_clean();
		$fileName = uniqid(time());
		$fileDir = $Fn_Poster->Config['StaticPicPath'].$Item['id'].'_'.uniqid(time()).'.'.array_pop(explode('.',$Item['param']['poster_bg']));
		switch ($BgType) {
			case 1: //gif
				imagegif($Img,DISCUZ_ROOT.$fileDir);
				break;
			case 2: //jpg
				imagejpeg($Img,DISCUZ_ROOT.$fileDir);
				break;
			case 3: //jpg
				imagepng($Img,DISCUZ_ROOT.$fileDir);
				break;
			default:
				break;
		}
		imagedestroy($Img);
		$PosterLog['param']['poster_file'] = $fileDir;
		$UpData['param'] = serialize($PosterLog['param']);
		DB::update($Fn_Poster->TablePosterLog,$UpData,'aid = '.intval($Item['id']).' and lid = '.intval($_GET['lid']));
	}
	dheader('Location:'.$fileDir);
}else{
	exit('No Data');
}

function GetAutoWrap($Fontsize,$Angle,$Fontface,$String,$Width) {
	// �⼸�������ֱ��� �����С, �Ƕ�, ��������, �ַ���, Ԥ�����
	$Content = "";
	// ���ַ�����ֳ�һ�������� ���浽���� letter ��
	for($I = 0; $I < mb_strlen($String); $I++) {
		$Letter[] = mb_substr($String, $I, 1);
	}

	foreach($Letter as $L) {
		$Teststr = $Content." ".$L;
		$Testbox = imagettfbbox($Fontsize, $Angle, $Fontface, $Teststr);
		// �ж�ƴ�Ӻ���ַ����Ƿ񳬹�Ԥ��Ŀ���
		if(($Testbox[2] > $Width) && ($Content !== "")) {
			 $Content .= "\n";
		}
		$Content .= $L;
	}
	return $Content;
}

function getimagecreatefromstring($url){
	$content = dfsockopen($url);
	$content = $content ? $content : file_get_contents($url);
	return imagecreatefromstring($content);
}
//From: Dism��taobao-com
?>