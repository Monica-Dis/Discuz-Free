<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_fn_poster` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `displayorder` tinyint(4) unsigned NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `click` int(11) unsigned NOT NULL,
  `param` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_poster_log_tableid` (
  `lid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_poster_log` (
  `lid` int(11) unsigned NOT NULL,
  `aid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `useip` varchar(30) NOT NULL,
  `param` mediumtext NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  `updateline` int(11) unsigned NOT NULL,
  `position` int(11) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`aid`,`position`),
  UNIQUE KEY `lid` (`lid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_fn_poster_share` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `dateline` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
?>