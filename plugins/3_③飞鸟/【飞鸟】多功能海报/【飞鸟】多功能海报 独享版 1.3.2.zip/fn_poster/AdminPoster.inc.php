<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
require_once (DISCUZ_ROOT .'./source/plugin/fn_poster/Function.inc.php');

$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&aid='.$_GET['aid'];
$AId = intval($_GET['aid']);
$Item = $AId ? $Fn_Poster->QueryOne($Fn_Poster->TablePoster,$AId) : array();
if($Item['param']){$Item['param'] = unserialize($Item['param']);}
$OpTitle = $Fn_Poster->Config['LangVar']['AddTitle'];
if(!submitcheck('DetailSubmit')) {
	if($Item) {
		$OpTitle = $Fn_Poster->Config['LangVar']['EditTitle'];
	}

	$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
	showformheader($FormUrl,'enctype');
	showtableheader();
	showtitle($OpTitle);
	showsetting($Fn_Poster->Config['LangVar']['Title'], 'title', $Item['title'], 'text');
	if($Item['param']['bg']) {
		$BgHtml = '<label><input type="checkbox" class="checkbox" name="delbg" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Item['param']['bg'].'" target="_blank"><img src="'.$Item['param']['bg'].'" width="100"/></a><input type="hidden" value="'.$Item['param']['bg'].'" name="bg"><br />'.$Fn_Poster->Config['LangVar']['HomeBgPrompt'];
	}else{
		$BgHtml = $Fn_Poster->Config['LangVar']['HomeBgPrompt'];
	}
	showsetting($Fn_Poster->Config['LangVar']['HomeBg'], 'bgnew','', 'filetext', '', 0, $BgHtml);
		
	showsetting($Fn_Poster->Config['LangVar']['FormTop'], 'form_top', $Item['param']['form_top'], 'text','','',$Fn_Poster->Config['LangVar']['FormTopPrompt']);

	showsetting($Fn_Poster->Config['LangVar']['FormFields'], 'form_fields', $Item['param']['form_fields'], 'textarea','','',$Fn_Poster->Config['LangVar']['FormFieldsPrompt']);

	showsetting($Fn_Poster->Config['LangVar']['FormStyle'],array('form_style',DyadicArray($Fn_Poster->Config['LangVar']['FormStyleArray'])),$Item['param']['form_style'],'select','','',$Fn_Poster->Config['LangVar']['FormStylePrompt']);

	showsetting($Fn_Poster->Config['LangVar']['PosterBtn'], 'poster_btn', $Item['param']['poster_btn'] ? $Item['param']['poster_btn'] : $Fn_Poster->Config['LangVar']['PosterBtnDefault'], 'text');

	if($Item['param']['poster_img_btn']) {
		$PosterImgBtnHtml = '<label><input type="checkbox" class="checkbox" name="del_poster_img_btn" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Item['param']['poster_img_btn'].'" target="_blank"><img src="'.$Item['param']['poster_img_btn'].'" width="100"/></a><input type="hidden" value="'.$Item['param']['poster_img_btn'].'" name="poster_img_btn"><br />'.$Fn_Poster->Config['LangVar']['PosterImgBtnTpis'];
	}else{
		$PosterImgBtnHtml = $Fn_Poster->Config['LangVar']['PosterImgBtnTpis'];
	}
	showsetting($Fn_Poster->Config['LangVar']['PosterImgBtn'], 'poster_img_btn_new',$Item['param']['poster_img_btn'], 'filetext', '', 0, $PosterImgBtnHtml);

	showsetting($Fn_Poster->Config['LangVar']['MusicTitle'], 'music', $Item['param']['music'], 'text','','',$Fn_Poster->Config['LangVar']['MusicPrompt']);
	
	if($Item['param']['poster_bg']) {
		$PosterBgHtml = '<label><input type="checkbox" class="checkbox" name="delposterbg" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Item['param']['poster_bg'].'" target="_blank"><img src="'.$Item['param']['poster_bg'].'" width="100"/></a><input type="hidden" value="'.$Item['param']['poster_bg'].'" name="poster_bg"><br />'.$Fn_Poster->Config['LangVar']['PosterBgPrompt'];
	}else{
		$PosterBgHtml = $Fn_Poster->Config['LangVar']['PosterBgPrompt'];
	}
	showsetting($Fn_Poster->Config['LangVar']['PosterBg'], 'posterbgnew',$Item['param']['poster_bg'], 'filetext', '', 0, $PosterBgHtml);

	showsetting($Fn_Poster->Config['LangVar']['MorePosterBg'], 'more_poster_bg', $Item['param']['more_poster_bg'], 'textarea','','',$Fn_Poster->Config['LangVar']['MorePosterBgPrompt']);

	showsetting($Fn_Poster->Config['LangVar']['OtherPoster'], 'other_poster',$Item['param']['other_poster'], 'textarea','','',$Fn_Poster->Config['LangVar']['OtherPosterPrompt']);

	showsetting($Fn_Poster->Config['LangVar']['Rand'], 'rand', $Item['param']['rand'] ? $Item['param']['rand'] : '1-100', 'text','','',$Fn_Poster->Config['LangVar']['RandPrompt']);

	showsetting($Fn_Poster->Config['LangVar']['OtherPosterImg'], 'other_poster_img',$Item['param']['other_poster_img'], 'textarea','','',$Fn_Poster->Config['LangVar']['OtherPosterImgPrompt']);

	showsetting($Fn_Poster->Config['LangVar']['BottomText'], 'bottom_text', $Item['param']['bottom_text'] ? $Item['param']['bottom_text'] : $Fn_Poster->Config['LangVar']['BottomTextDefault'], 'text');

	showsetting($Fn_Poster->Config['LangVar']['BottomTextPosition'], array('bottom_text_position',DyadicArray($Fn_Poster->Config['LangVar']['BottomTextPositionArray'])),$Item['param']['bottom_text_position'],'select');

	showsetting($Fn_Poster->Config['LangVar']['BottomShareBtn'], 'bottom_share_btn', $Item['param']['bottom_share_btn'] ? $Item['param']['bottom_share_btn'] : $Fn_Poster->Config['LangVar']['BottomShareBtnDefault'], 'text');

	showsetting($Fn_Poster->Config['LangVar']['ShareMode'],array('sharemode',DyadicArray($Fn_Poster->Config['LangVar']['ShareModeArr'])),$Game['param']['sharemode'],'select','','',$Fn_Poster->Config['LangVar']['ShareModePrompt']);

	showsetting($Fn_Poster->Config['LangVar']['FixedBottomBtn'], 'bottom_btn', $Item['param']['bottom_btn'] ? $Item['param']['bottom_btn'] : $Fn_Poster->Config['LangVar']['FixedBottomBtnDefault'], 'text');

	showsetting($Fn_Poster->Config['LangVar']['InitializationNum'], 'initialization_num', $Item['param']['initialization_num'], 'text','','',$Fn_Poster->Config['LangVar']['InitializationNumPrompt']);

	showsetting($Fn_Poster->Config['LangVar']['BackSwitch'], 'back', $Item['param']['back'], 'radio','','',$Fn_Poster->Config['LangVar']['BackSwitchPrompt']);

	showsetting($Fn_Poster->Config['LangVar']['BackBtn'], 'back_btn', $Item['param']['back_btn'] ? $Item['param']['back_btn'] : $Fn_Poster->Config['LangVar']['Back'], 'text');

	showsetting($Fn_Poster->Config['LangVar']['BackLink'], 'back_link', $Item['param']['back_link'] ? $Item['param']['back_link'] : $_G['siteurl'], 'text');
	
	showsetting($Fn_Poster->Config['LangVar']['HomeBtnSwitch'], 'home_btn_switch', $Item['param']['home_btn_switch'], 'radio','','',$Fn_Poster->Config['LangVar']['HomeBtnSwitchPrompt']);

	showsetting($Fn_Poster->Config['LangVar']['HomeBtnLink'], 'home_btn_link', $Item['param']['home_btn_link'], 'text');

	showsetting($Fn_Poster->Config['LangVar']['HomeBtnText'], 'home_btn_text', $Item['param']['home_btn_text'], 'text');

	showsetting($Fn_Poster->Config['LangVar']['HomeBtnColor'], 'home_btn_color', $Item['param']['home_btn_color'], 'color');

	if($Item['param']['home_img_btn_text']) {
		$HomeImgBtnTextHtml = '<label><input type="checkbox" class="checkbox" name="del_home_img_btn_text" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Item['param']['home_img_btn_text'].'" target="_blank"><img src="'.$Item['param']['home_img_btn_text'].'" width="100"/></a><input type="hidden" value="'.$Item['param']['home_img_btn_text'].'" name="home_img_btn_text"><br />'.$Fn_Poster->Config['LangVar']['HomeImgBtnTextTips'];
	}else{
		$HomeImgBtnTextHtml = $Fn_Poster->Config['LangVar']['HomeImgBtnTextTips'];
	}
	showsetting($Fn_Poster->Config['LangVar']['HomeImgBtnText'], 'home_img_btn_text_new',$Item['param']['home_img_btn_text'], 'filetext', '', 0, $HomeImgBtnTextHtml);

	showsetting($Fn_Poster->Config['LangVar']['IsLogin'], 'login',$Item ? $Item['param']['login'] : 1, 'radio');

	showsetting($Fn_Poster->Config['LangVar']['IsApp'], 'app', $Item['param']['app'], 'radio');

	showsetting($Fn_Poster->Config['LangVar']['AppPrompt'], 'app_prompt', $Item['param']['app_prompt'] ? $Item['param']['app_prompt'] : $Fn_Poster->Config['LangVar']['AppPromptDefault'], 'text');
	
	showsetting($Fn_Poster->Config['LangVar']['ParametricQRCodeSwitch'], 'qr_code_switch',$Item['param']['qr_code_switch'], 'radio','','',$Fn_Poster->Config['LangVar']['ParametricQRCodeSwitchTips']);

	//��ע�����
	showsetting($Fn_Poster->Config['LangVar']['ServiceNumberSwitch'],array('service_number_switch', array(
    array('1',$Fn_Poster->Config['LangVar']['Yes'], array('service_number_table' => '', 'service_number_table_no' => 'none')),
    array('0',$Fn_Poster->Config['LangVar']['No'], array('service_number_table'=> 'none', 'service_number_table_no' => ''))
	), TRUE),$Item['param']['service_number_switch'], 'mradio','','',$Fn_Poster->Config['LangVar']['ServiceNumberSwitchPrompt']);

	$ServiceNumberDisplay = $Item['param']['service_number_switch'] ? true : false;
	showtagheader('tbody', 'service_number_table', $ServiceNumberDisplay, 'sub');
	showsetting($Fn_Poster->Config['LangVar']['ServiceNumberAppId'], 'service_number_appid', $Item['param']['service_number_appid'], 'text');
	showsetting($Fn_Poster->Config['LangVar']['ServiceNumberAppSecret'], 'service_number_secret', $Item['param']['service_number_secret'], 'text');
	showsetting($Fn_Poster->Config['LangVar']['ServiceNumberOAuth'], 'service_number_oauth', $Item['param']['service_number_oauth'], 'text','','',$Fn_Poster->Config['LangVar']['ServiceNumberOAuthPrompt']);
	showsetting($Fn_Poster->Config['LangVar']['ServiceNumberText'], 'service_number_text', $Item['param']['service_number_text'] ? $Item['param']['service_number_text'] : $Fn_Poster->Config['LangVar']['ServiceNumberTextDefault'], 'text');
	if($Item['param']['service_number_img']) {
		$ServiceNumberImgHtml = '<label><input type="checkbox" class="checkbox" name="del_service_number_img" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Item['param']['service_number_img'].'" target="_blank"><img src="'.$Item['param']['service_number_img'].'" width="100"/></a><input type="hidden" value="'.$Item['param']['service_number_img'].'" name="service_number_img"><br />';
	}
	showsetting($Fn_Poster->Config['LangVar']['ServiceNumberImg'], 'new_service_number_img',$Item['param']['service_number_img'], 'filetext', '', 0, $ServiceNumberImgHtml);
	showtagfooter('tbody');
	//��ע�����End

	showsetting($Fn_Poster->Config['LangVar']['ShareTitle'], 'sharetitle', $Item['param']['sharetitle'], 'text');
	showsetting($Fn_Poster->Config['LangVar']['ShareDesc'], 'sharedesc', $Item['param']['sharedesc'], 'textarea');
	showsetting($Fn_Poster->Config['LangVar']['PosterShareTitle'], 'postersharetitle', $Item['param']['postersharetitle'], 'text','','',$Fn_Poster->Config['LangVar']['PosterSharePrompt']);
	showsetting($Fn_Poster->Config['LangVar']['PosterShareDesc'], 'postersharedesc', $Item['param']['postersharedesc'], 'textarea','','',$Fn_Poster->Config['LangVar']['PosterSharePrompt']);

	if($Item['param']['sharelogo']) {
		$ShareLogoHtml = '<label><input type="checkbox" class="checkbox" name="delsharelogo" value="yes" /> '.$lang['delete'].'</label><br /><a href="'.$Item['param']['sharelogo'].'" target="_blank"><img src="'.$Item['param']['sharelogo'].'" width="100"/></a><input type="hidden" value="'.$Item['param']['sharelogo'].'" name="sharelogo"><br />'.$Fn_Poster->Config['LangVar']['ShareLogoPrompt'];
	}else{
		$ShareLogoHtml = $Fn_Poster->Config['LangVar']['ShareLogoPrompt'];
	}
	showsetting($Fn_Poster->Config['LangVar']['ShareLogo'], 'sharelogonew',$Item['param']['sharelogo'], 'filetext', '', 0, $ShareLogoHtml);

	showsetting($Fn_Poster->Config['LangVar']['Color'], 'color', $Item['param']['color'] ? $Item['param']['color'] : '#d0b500', 'color');

	showsetting($Fn_Poster->Config['LangVar']['DisplayOrder'], 'displayorder', $Item['displayorder'], 'text');
	
	showsetting($Fn_Poster->Config['LangVar']['DisplayTitle'], 'display', $Item ? $Item['display'] : 1, 'radio');
	if($Item['dateline']){
		showsetting($Fn_Poster->Config['LangVar']['TimeTitle'], 'dateline',date('Y-m-d H:i',$Item['dateline']), 'calendar','','','',1);
	}
	showtablefooter();/*Dism��taobao��com*/
	showsubmit('DetailSubmit');
	/*Dism_taobao_com*/showformfooter();
	echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
}else{
	
	$Data['title'] = addslashes(strip_tags($_GET['title']));
	$Data['display'] = intval($_GET['display']);
	$Data['displayorder'] = intval($_GET['displayorder']);
	
	$Param['form_top'] = addslashes(strip_tags($_GET['form_top']));
	$Param['form_fields'] = addslashes(strip_tags($_GET['form_fields']));
	$Param['form_style'] = intval($_GET['form_style']);
	$Param['poster_btn'] = addslashes(strip_tags($_GET['poster_btn']));
	$Param['music'] = addslashes(strip_tags($_GET['music']));
	
	$Param['more_poster_bg'] = addslashes(strip_tags($_GET['more_poster_bg']));
	$Param['other_poster'] = addslashes(strip_tags($_GET['other_poster']));
	$Param['rand'] = addslashes(strip_tags($_GET['rand']));
	$Param['other_poster_img'] = addslashes(strip_tags($_GET['other_poster_img']));
	
	$Param['bottom_text'] = addslashes(strip_tags($_GET['bottom_text']));
	$Param['bottom_text_position'] = addslashes(strip_tags($_GET['bottom_text_position']));
	$Param['bottom_share_btn'] = addslashes(strip_tags($_GET['bottom_share_btn']));
	$Param['sharemode'] = intval($_GET['sharemode']);

	$Param['bottom_btn'] = addslashes(strip_tags($_GET['bottom_btn']));
	$Param['initialization_num'] = intval($_GET['initialization_num']);
	
	$Param['back'] = intval($_GET['back']);
	$Param['back_btn'] = addslashes(strip_tags($_GET['back_btn']));
	$Param['back_link'] = addslashes(strip_tags($_GET['back_link']));
	
	$Param['home_btn_switch'] = intval($_GET['home_btn_switch']);
	$Param['home_btn_text'] = addslashes(strip_tags($_GET['home_btn_text']));
	$Param['home_btn_link'] = addslashes(strip_tags($_GET['home_btn_link']));
	$Param['home_btn_color'] = addslashes(strip_tags($_GET['home_btn_color']));
	
	$Param['login'] = intval($_GET['login']);
	$Param['app'] = intval($_GET['app']);
	$Param['app_prompt'] = addslashes(strip_tags($_GET['app_prompt']));
	
	$Param['qr_code_switch'] = intval($_GET['qr_code_switch']);
	$Param['service_number_switch'] = intval($_GET['service_number_switch']);
	$Param['service_number_appid'] = addslashes(strip_tags($_GET['service_number_appid']));
	$Param['service_number_secret'] = addslashes(strip_tags($_GET['service_number_secret']));
	$Param['service_number_oauth'] = addslashes(strip_tags($_GET['service_number_oauth']));
	$Param['service_number_text'] = addslashes($_GET['service_number_text']);

	$Param['sharetitle'] = addslashes(strip_tags($_GET['sharetitle']));
	$Param['sharedesc'] = addslashes(strip_tags($_GET['sharedesc']));
	$Param['postersharetitle'] = addslashes(strip_tags($_GET['postersharetitle']));
	$Param['postersharedesc'] = addslashes(strip_tags($_GET['postersharedesc']));
	$Param['color'] = addslashes(strip_tags($_GET['color']));
	$Param['n'] = addslashes(strip_tags($_GET['color']));

	/* ��ҳ����ͼ */
	if($_GET['delbg'] == 'yes'){
		if(preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$Item['param']['bg'])){
			unlink(DISCUZ_ROOT.$Item['param']['bg']);
		}
		$Param['bg'] = '';
	}else{
		$Param['bg'] = addslashes(strip_tags($_GET['bg']));
	}
	if($_FILES['bgnew']['size']){
		$BgFile = Fn_Upload($_FILES['bgnew'],$Item['param']['bg']);
		if($BgFile['Errorcode']){
			cpmsg($Fn_Poster->Config['LangVar']['ImgErr'],'','error');
		}else{
			$Param['bg']  = $BgFile['Path'];
		}
	}else if($_GET['bgnew']){
		if(preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET['bgnew'])){
			$Param['bg'] = addslashes(strip_tags($_GET['bgnew']));
		}else{
			cpmsg($Fn_Poster->Config['LangVar']['ImgErr'],'','error');
		}
		
	}
	/* ��ҳ����ͼ End */

	/* ��ť����ͼ */
	if($_GET['del_poster_img_btn'] == 'yes'){
		if(preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$Item['param']['poster_img_btn'])){
			unlink(DISCUZ_ROOT.$Item['param']['poster_img_btn']);
		}
		$Param['poster_img_btn'] = '';
	}else{
		$Param['poster_img_btn'] = addslashes(strip_tags($_GET['poster_img_btn']));
	}
	if($_FILES['poster_img_btn_new']['size']){
		$PosterImgBtnFile = Fn_Upload($_FILES['poster_img_btn_new'],$Item['param']['poster_img_btn']);
		if($PosterImgBtnFile['Errorcode']){
			cpmsg($Fn_Poster->Config['LangVar']['ImgErr'],'','error');
		}else{
			$Param['poster_img_btn']  = $PosterImgBtnFile['Path'];
		}
	}else if($_GET['poster_img_btn_new']){
		if(preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET['poster_img_btn_new'])){
			$Param['poster_img_btn'] = addslashes(strip_tags($_GET['poster_img_btn_new']));
		}else{
			cpmsg($Fn_Poster->Config['LangVar']['ImgErr'],'','error');
		}
	}
	/* ��ť����ͼ End */

	/* ��ҳ��ť����ͼƬ */
	if($_GET['del_home_img_btn_text'] == 'yes'){
		if(preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$Item['param']['home_img_btn_text'])){
			unlink(DISCUZ_ROOT.$Item['param']['home_img_btn_text']);
		}
		$Param['home_img_btn_text'] = '';
	}else{
		$Param['home_img_btn_text'] = addslashes(strip_tags($_GET['home_img_btn_text']));
	}
	if($_FILES['home_img_btn_text_new']['size']){
		$HomeImgBtnFile = Fn_Upload($_FILES['home_img_btn_text_new'],$Item['param']['home_img_btn_text']);
		if($HomeImgBtnFile['Errorcode']){
			cpmsg($Fn_Poster->Config['LangVar']['ImgErr'],'','error');
		}else{
			$Param['home_img_btn_text']  = $HomeImgBtnFile['Path'];
		}
	}else if($_GET['home_img_btn_text_new']){
		if(preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET['home_img_btn_text_new'])){
			$Param['home_img_btn_text'] = addslashes(strip_tags($_GET['home_img_btn_text_new']));
		}else{
			cpmsg($Fn_Poster->Config['LangVar']['ImgErr'],'','error');
		}
	}
	/* ��ҳ��ť����ͼƬ End */

	/* ��������ͼ */
	if($_GET['delposterbg'] == 'yes'){
		if(preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$Item['param']['poster_bg'])){
			unlink(DISCUZ_ROOT.$Item['param']['poster_bg']);
		}
		$Param['poster_bg'] = '';
	}else{
		$Param['poster_bg'] = addslashes(strip_tags($_GET['poster_bg']));
	}
	if($_FILES['posterbgnew']['size']){
		$PosterBgFile = Fn_Upload($_FILES['posterbgnew'],$Item['param']['poster_bg']);
		if($PosterBgFile['Errorcode']){
			cpmsg($Fn_Poster->Config['LangVar']['ImgErr'],'','error');
		}else{
			$Param['poster_bg']  = $PosterBgFile['Path'];
		}
	}else if($_GET['posterbgnew']){
		if(preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET['posterbgnew'])){
			$Param['poster_bg'] = addslashes(strip_tags($_GET['posterbgnew']));
		}else{
			cpmsg($Fn_Poster->Config['LangVar']['ImgErr'],'','error');
		}
	}
	/* ��������ͼ End */

	/* ����Ŷ�ά�� */
	if($_GET['del_service_number_img'] == 'yes'){
		if(preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$Item['param']['service_number_img'])){
			unlink(DISCUZ_ROOT.$Item['param']['service_number_img']);
		}
		$Param['service_number_img'] = '';
	}else{
		$Param['service_number_img'] = addslashes(strip_tags($_GET['service_number_img']));
	}
	if($_FILES['new_service_number_img']['size']){
		$ServiceNumberImgFile = Fn_Upload($_FILES['new_service_number_img'],$Item['param']['service_number_img']);
		if($ServiceNumberImgFile['Errorcode']){
			cpmsg($Fn_Poster->Config['LangVar']['ImgErr'],'','error');
		}else{
			$Param['service_number_img']  = $ServiceNumberImgFile['Path'];
		}
	}else if($_GET['new_service_number_img']){
		if(preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET['new_service_number_img'])){
			$Param['service_number_img'] = addslashes(strip_tags($_GET['new_service_number_img']));
		}else{
			cpmsg($Fn_Poster->Config['LangVar']['ImgErr'],'','error');
		}
	}
	/* ����Ŷ�ά�� End */

	/* ����ͼƬ */
	if($_GET['delsharelogo'] == 'yes'){
		if(preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$Item['param']['sharelogo'])){
			unlink(DISCUZ_ROOT.$Item['param']['sharelogo']);
		}
		$Param['sharelogo'] = '';
	}else{
		$Param['sharelogo'] = addslashes(strip_tags($_GET['sharelogo']));
	}
	if($_FILES['sharelogonew']['size']){
		$ShareLogFile = Fn_Upload($_FILES['sharelogonew'],$Item['param']['sharelogo']);
		if($ShareLogFile['Errorcode']){
			cpmsg($Fn_Poster->Config['LangVar']['ImgErr'],'','error');
		}else{
			$Param['sharelogo']  = $ShareLogFile['Path'];
		}
	}else if($_GET['sharelogonew']){
		if(preg_match('/.*(\.png|\.jpg|\.jpeg|\.gif)$/',$_GET['sharelogonew'])){
			$Param['sharelogo'] = addslashes(strip_tags($_GET['sharelogonew']));
		}else{
			cpmsg($Fn_Poster->Config['LangVar']['ImgErr'],'','error');
		}
	}
	/* ����ͼƬ End */

	$Data['param'] = serialize($Param);
	
	if($Item){
		$Data['dateline'] = strtotime($_GET['dateline']);
		DB::update($Fn_Poster->TablePoster,$Data,'id = '.$AId);
	}else{
		$Data['dateline'] = time();
		DB::insert($Fn_Poster->TablePoster,$Data);
	}
	cpmsg($Fn_Poster->Config['LangVar']['UpdateOk'],$CpMsgUrl,'succeed');
}
//From: Dism��taobao-com
?>