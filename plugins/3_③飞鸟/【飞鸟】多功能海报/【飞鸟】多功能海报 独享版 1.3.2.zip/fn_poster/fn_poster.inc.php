<?php
/**
 *	[���������ɺ���(fn_poster.{modulename})] (C)2016-2099 Powered by ��������.
 *	Version: 1.0
 *	Date: 2018-6-26 10:27
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

@require_once (DISCUZ_ROOT .'./source/plugin/fn_assembly/app.inc.php');
@require_once (DISCUZ_ROOT .'./source/plugin/fn_poster/Function.inc.php');

$Item = $_GET['aid'] ? $Fn_Poster->QueryOne($Fn_Poster->TablePoster,intval($_GET['aid']),' and display = 1') : DB::fetch_first('SELECT * FROM '.DB::table($Fn_Poster->TablePoster).' where display = 1 order by displayorder ASC');

if($Item){
	$_GET['m'] = empty($_GET['m']) ? 'index' : $_GET['m'];//��ʼ��ģ��
	$Item['param'] = unserialize($Item['param']);
	$Fn_Poster->Config['PluginVar']['Color'] = $Item['param']['color'];
	$navtitle = $metakeywords = $metadescription = $Item['title'];
	
	$AppSwitch = $Item['param']['app'] && !App ? true : false;

	if(!$_G['uid'] && in_array($_GET['m'],array('index')) && !$AppSwitch && $Item['param']['login']){
		Fn_Login();
	}

	//����
	$Fn_Poster->Config['WxShare']['WxUrl'] = $Fn_Poster->Config['WxShare']['WxUrl'].'&aid='.$Item['id'];
	$Fn_Poster->Config['WxShare']['WxTitle'] = $Item['param']['sharetitle'] ? $Item['param']['sharetitle'] : $Item['title'];
	$Fn_Poster->Config['WxShare']['WxDes'] = $Item['param']['sharedesc'] ? $Item['param']['sharedesc'] : $Item['title'];
	$Fn_Poster->Config['WxShare']['WxImg'] = $Item['param']['sharelogo'] ? $Item['param']['sharelogo'] : $Item['bg'];
	$Fn_Poster->Config['WxShare']['WxImg'] = strpos($Fn_Poster->Config['WxShare']['WxImg'],'http') !== false ? $Fn_Poster->Config['WxShare']['WxImg'] : $_G['siteurl'].$Fn_Poster->Config['WxShare']['WxImg'];
	//���� End

	if($_GET['m'] == 'index'){
		$FormFieldHtml = $Fn_Poster->GetFormFieldHtml($Item['param']['form_fields']);
		$Item['param']['form_style'] = $Item['param']['form_style'] ? $Item['param']['form_style'] : 1;

		//��ע����Ų���
		if($Item['param']['service_number_switch'] && WxApp && !$Item['param']['app'] && $_G['uid']){
			if($_GET['code']){
				@require_once libfile('class/wechat','plugin/fn_assembly');
				$WechatClient = new Fn_WeChatClient($Item['param']['service_number_appid'],$Item['param']['service_number_secret']);
				$Token = $WechatClient->GetAccessTokenByCode($_GET['code']);
				if($Token['openid']){
					$WeChatUserInfo = $WechatClient->getUserInfoById($Token['openid'],'zh_CN');
				}else{
					if(strpos($Item['param']['service_number_oauth'],'oauth2.htm') !== false) {
						 $LoginUrl = $Item['param']['service_number_oauth'].'?appid='.$Item['param']['service_number_appid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.urlencode($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"]);
					}else{
						$LoginUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$Item['param']['service_number_appid'].'&redirect_uri=' . urlencode($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"]).'&response_type=code&scope=snsapi_userinfo&state='. md5(FORMHASH).'#wechat_redirect';
					}
					dheader('Location:'.$LoginUrl);
				}
			}else{
				if(strpos($Item['param']['service_number_oauth'],'oauth2.htm') !== false) {
					 $LoginUrl = $Item['param']['service_number_oauth'].'?appid='.$Item['param']['service_number_appid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.urlencode($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"]);
				}else{
					$LoginUrl = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$Item['param']['service_number_appid'].'&redirect_uri=' .urlencode($_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"]).'&response_type=code&scope=snsapi_userinfo&state='. md5(FORMHASH).'#wechat_redirect';
				}
				dheader('Location:'.$LoginUrl);
			}
		}

		//ͼƬ�ϴ�
		if(file_exists(DISCUZ_ROOT.'./source/plugin/fn_assembly/class/class_upload.php')){
			@require_once libfile('class/upload','plugin/fn_assembly');
			$UploadConfig = fn_upload::Config();
		}


	}else if($_GET['m'] == 'poster'){
		
		$PosterLog = $Fn_Poster->GetPosterLogFirst($Item['id'],$_GET['lid']);
		if($PosterLog){
	
			$StayArray = array('{Num}');
			$StartArray = array(($PosterLog['position']+$Item['param']['initialization_num']));
			foreach($PosterLog['param']['value'] as $Key=>$Val){//��������
				$StayArray[] = '{'.$Key.'}';
				$StartArray[] = is_array($Val) ? implode('/',$Val) : $Val;
			}
			$Fn_Poster->Config['WxShare']['WxUrl'] = $Fn_Poster->Config['WxShare']['WxUrl'].'&m=poster&aid='.$Item['id'].'&lid='.$PosterLog['lid'];
			$Fn_Poster->Config['WxShare']['WxTitle'] = $Item['param']['postersharetitle'] ? str_replace($StayArray,$StartArray,$Item['param']['postersharetitle']) : $Fn_Poster->Config['WxShare']['WxTitle'];
			$Fn_Poster->Config['WxShare']['WxDes'] = $Item['param']['postersharedesc'] ? str_replace($StayArray,$StartArray,$Item['param']['postersharedesc']) : $Fn_Poster->Config['WxShare']['WxDes'];
			
			$Time = time();

		}else{
			exit('No Data');
		}
	}

	if(!in_array($_GET['m'],array('index','poster'))){
		exit('No Data');
	}
}else{
	exit('No Data');
}

include template('fn_poster:'.$_GET['m']);
?>