<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

require_once (DISCUZ_ROOT .'./source/plugin/fn_poster/Function.inc.php');

$Operation = in_array($_GET['Operation'], array('Del')) ? $_GET['Operation'] : 'List';
$CpMsgUrl = 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&page='.$_GET['page'].'&keyword='.$_GET['keyword'].'&aid='.$_GET['aid'];
if($Operation == 'List'){//�б�
	if(!submitcheck('Submit')) {
		/* ���� */
		$SearUrl = ADMINSCRIPT.'?'.rawurldecode(cpurl());
		$StateSelected = array($_GET['state']=>' selected');
		$OrderSelected = array($_GET['order']=>' selected');
		echo <<<SEARCH
		<form method="post" autocomplete="off" action="$SearUrl" id="tb_search">
			<div style="margin-top:8px;">
				<table cellspacing="4" cellpadding="4">
					<tr>
						<th>{$Fn_Poster->Config['LangVar']['KeywordTitle']}</th><td><input type="text" class="txt" name="keyword" value="{$_GET['keyword']}"></td>
						<th>{$Fn_Poster->Config['LangVar']['PosterId']}</th><td><input type="text" class="txt" name="aid" value="{$_GET['aid']}"></td>
						<th>{$Fn_Poster->Config['LangVar']['SortTitle']}</th><td colspan="3"><select name="order">
						<option value="lid"{$OrderSelected['id']}>id</option>
						<option value="updateline"{$OrderSelected['updateline']}>{$Fn_Poster->Config['LangVar']['UpdateTime']}</option>
						</select>&nbsp;&nbsp;<input name="SearchSubmit" value="{$Fn_Poster->Config['LangVar']['SearchSubmit']}" class="btn" type="submit"></td>
					</tr>
				</table>
			</div>
		</form>
SEARCH;
		/* ���� End */
		/* ��ѯ���� */
		$MpUrl = $SearUrl;
		foreach($_GET as $key => $val){
			$MpUrl.= '&'.$key.'='.$val;
		}
		$Where = '';
		$Order = in_array($_GET['order'], array('lid','updateline')) ? 'L.'.addslashes(dhtmlspecialchars($_GET['order'])) : 'L.lid';
		if($_GET['aid']){
			$Where .= ' and L.aid = '.intval($_GET['aid']);
		}
		if($_GET['keyword']){
			$Where .= ' and concat(L.uid,L.username) like(\'%'.addslashes(dhtmlspecialchars($_GET['keyword'])).'%\')';
		}
		$Where = preg_replace('/and/','where',$Where,1);
		$Limit = 20;
		$Page = $_GET['page']?intval($_GET['page']):1;
		/* ��ѯ���� End */
		/* ģ����� */
		$TdStyle = array('width="20"','');
		$FormUrl = ltrim(rawurldecode(cpurl()),'action=');
		showtagheader('div', 'Module', true);
		showformheader($FormUrl,'enctype="multipart/form-data"');
		showtableheader($Fn_Poster->Config['LangVar']['InfoListTitle']);
		showsubtitle(array(
            'ID',
			$Fn_Poster->Config['LangVar']['Title'],
			'Uid/'.$Fn_Poster->Config['LangVar']['UserNameTitle'],
			'IP',
			$Fn_Poster->Config['LangVar']['Content'],
			$Fn_Poster->Config['LangVar']['Position'],
			$Fn_Poster->Config['LangVar']['TimeTitle'],
			$Fn_Poster->Config['LangVar']['UpdateTime']
		), 'header tbm',$TdStyle);
		$ModulesList = GetModulesList($Page,$Limit,$Where,$Order);
		foreach ($ModulesList as $Module) {
			$Module['param'] = unserialize($Module['param']);
			$FormHtml = '';
			foreach($Module['param']['value'] as $Key=>$Val){//��������
				if($Module['param']['filevalue'][$Key]){
					$FormHtml .= $Module['param']['title'][$Key].':'.($Val ? '<img src="'.$Val.'" style="height:30px;">' : '').'<br>';
				}else{
					$FormHtml .= $Module['param']['title'][$Key].':'.(is_array($Val) ? implode('/',$Val) : $Val).'<br>';
				}
				
			}
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$Module['lid'].'" />'.$Module['lid'],
				'<a href="'.$Fn_Poster->Config['PosterUrl'].'&aid='.$Module['aid'].'&lid='.$Module['lid'].'" target="_blank">'.$Module['title'].'</a>',
				$Module['uid'] ? $Module['uid'].'/'.$Module['username'] : '' ,
				$Module['useip'],
				$FormHtml,
				$Module['position'],
				date('Y-m-d H:i',$Module['dateline']),
				$Module['updateline'] ? date('Y-m-d H:i',$Module['updateline']) : ''
			));
		}
		showsubmit('Submit','submit','del','',multi(GetModulesCount($Where),$Limit,$Page,$MpUrl));
        showtablefooter();/*Dism��taobao��com*/
		/*Dism_taobao_com*/showformfooter();
		showtagfooter('div');
		/* ģ����� End */
	}else{
		if(isset($_GET['delete']) && is_array($_GET['delete'])){
			foreach($_GET['delete'] as $Key => $Val) {
				$Val = intval($Val);
				DB::delete($Fn_Poster->TablePosterLog,'lid ='.$Val);
			}
			cpmsg($Fn_Poster->Config['LangVar']['DelOk'],$CpMsgUrl,'succeed');
		}else{
			cpmsg($Fn_Poster->Config['LangVar']['DelErr'],'','error');
		}
	}
}
/* �б� */
function GetModulesList($Page,$Limit,$Where,$Order){
	global $Fn_Poster;
	$FetchSql = 'SELECT P.title,L.* FROM '.DB::table($Fn_Poster->TablePosterLog).' L LEFT JOIN '.DB::table($Fn_Poster->TablePoster).' P on P.id = L.aid '.$Where.' order by '.$Order.' desc LIMIT '.(($Page - 1) * $Limit).','.$Limit;
	return DB::fetch_all($FetchSql);//��������
}

/* ���� */
function GetModulesCount($Where){
	global $Fn_Poster;
	$FetchSql = 'SELECT COUNT(*) FROM '.DB::table($Fn_Poster->TablePosterLog).' L '.$Where;
	return DB::result_first($FetchSql);//��������
}
//From: Dism��taobao-com
?>