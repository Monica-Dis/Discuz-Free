<?php

/**
*	[DisM!] (C)2001-2099 DisM Inc.
*	Version: 1.0
*	Date: 2019-1-6 20:00
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_pn_homepage {
	function  global_header_mobile() {
		global $_G;
		$PHP_SELF=$_SERVER['PHP_SELF'];
		$urlroot=substr($PHP_SELF,0,strrpos($PHP_SELF,'/')+1);
		if(($_SERVER['REQUEST_URI']==$urlroot || $PHP_SELF==$urlroot.'index.php')  &&  $_G['cache']['plugin']['pn_homepage']['homepage']){
			dheader('location:'.$_G['cache']['plugin']['pn_homepage']['homepage']);
		}
	}
}
//From: Dism_taobao-com
?>