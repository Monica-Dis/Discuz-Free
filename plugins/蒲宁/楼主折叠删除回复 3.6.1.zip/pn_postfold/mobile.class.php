<?php

/**
*      $Id: 2019-3-5 01:04:24Z puning $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class mobileplugin_pn_postfold {
	function __construct(){
		if(CURMODULE=='viewthread'){
			global $_G;
			$this->foldstting = C::t('#pn_postfold#pn_postfold_forums')->fetch_info_by_fid($_G['fid']);
			if($this->foldstting['off']){
				$this->foldcount = DB::result_first('SELECT count(*) FROM %t WHERE tid=%d AND status=1', array('forum_post',$_G['tid']));

			}
		}
	}

}

class mobileplugin_pn_postfold_forum extends mobileplugin_pn_postfold {

	function viewthread_posttop_mobile_output() {
		global $_G,$postlist,$page;
		$adminhtml = array();
		if($this->foldstting['autofold'] && $page==1 && !$_GET['autofold'] && $_GET['viewmode'] !='fold'){
			foreach($postlist as $id => $post) {
				if (!$post['first']) {

					unset($postlist[$id]);
				}
			}
		}else{
			if($this->foldstting['off']){
				include_once template('pn_postfold:showmenu');
				foreach($postlist as $id => $post) {
					if (!$post['first']) {
						if($post['status'] == 1 && $_GET['viewmode']!='fold'){
							//unset($postlist[$id]);
						}else{
							if($_G['uid'] == $_G['forum_thread']['authorid']){
								$fold=$_GET['viewmode'] =='fold' && $this->foldcount ? 1 : 0;
								$lockuids = C::t('#pn_postfold#pn_postfold_lockuser')->fetch_info_by_tid($post['tid']);
								$lock = in_array($post['authorid'],unserialize($lockuids['uids'])) ? 1 : 0;
								$adminhtml[] = pn_postfold_showadmin($id,$fold,$this->foldstting['del'],$this->foldstting['lockuser'],$lock);
							}else{
								$adminhtml[]='';
							}
						}
					}else{
						$adminhtml[]='';
					}
				}
			}
		}
		return $adminhtml;
	}

	function viewthread_bottom_mobile_output() {
		global $_G,$page,$thread;
		if($this->foldstting['autofold'] && $page==1 && !$_GET['autofold']){
			include_once template('pn_postfold:showmenu');

			$autofoldhtml=pn_postfold_showautofold();

		}
		if($this->foldstting['off'] && (ceil($_G['forum_thread']['replies']/$_G['ppp']) == $page)){
			include_once template('pn_postfold:showmenu');
			$shownavpage = 'forum.php?mod=viewthread&tid='.$_G['tid'].
			($_GET['viewmode']!='fold' ? '&viewmode=fold' : '').
			($_G['forum_thread']['is_archived'] ? '&archive='.$_G['forum_thread']['archiveid'] : '').
			'&amp;extra='.$_GET['extra'].
			($ordertype && $ordertype != getstatus($_G['forum_thread']['status'], 4) ? '&amp;ordertype='.$ordertype : '').
			(isset($_GET['highlight']) ? '&amp;highlight='.rawurlencode($_GET['highlight']) : '').
			(!empty($_GET['authorid']) ? '&amp;authorid='.$_GET['authorid'] : '').
			(!empty($_GET['from']) ? '&amp;from='.$_GET['from'] : '').
			(!empty($_GET['checkrush']) ? '&amp;checkrush='.$_GET['checkrush'] : '').
			(!empty($_GET['modthreadkey']) ? '&amp;modthreadkey='.rawurlencode($_GET['modthreadkey']) : '');
			if($_GET['viewmode']!='fold'){
				$navhtml= pn_postfold_shownav($this->foldcount,1,$shownavpage);
			}else{
				$navhtml= pn_postfold_shownav($this->foldcount,0,$shownavpage);
			}
		}
		return $autofoldhtml.$navhtml;

	}

	function viewthread(){
		global $_G, $postlist, $specialextra, $threadplughtml, $postno, $page, $post, $modmenu, $thread, $allowpostreply, $needhiddenreply, $summary, $aimgs;
		if($this->foldstting['off']){
			if($this->foldcount){
				include_once DISCUZ_ROOT.'./source/plugin/pn_postfold/module/forum/forum_viewthread.php';
				exit;
			}
		}
	}

	function post(){
		global $_G;

		if(CURMODULE=='post' && $_GET['action']=='reply' ){
			$lockuids = C::t('#pn_postfold#pn_postfold_lockuser')->fetch_info_by_tid($_GET['tid']);
			if(in_array($_G['uid'],unserialize($lockuids['uids']))){
				showmessage(lang('plugin/pn_postfold', 'error_nopostpem'));
				exit;
			}

		}
	}
}