<?php



if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_forum_post_status extends discuz_table
{
	private static $_tableid_tablename = array();

	public function __construct() {

		$this->_table = 'forum_post';
		$this->_pk    = 'pid';
		parent::__construct(); /*dism _ taobao _ com*/
	}



	public function fetch_all_common_viewthread_by_tid($tid, $visibleallflag, $authorid, $forum_pagebydesc, $ordertype, $count, $start, $limit,$status) {
		$data = array();
		$storeflag = false;
		if($this->_allowmem) {
			if($ordertype != 1 && !$forum_pagebydesc && !$start && $count > $limit) {
				$data = $this->fetch_cache($tid, $this->_pre_cache_key.'tid_');
				if($data && count($data) == $limit) {
					$delauthorid = $this->fetch_cache('delauthorid');
					$updatefid = $this->fetch_cache('updatefid');
					$delpid = $this->fetch_cache('delpid');
					foreach($data as $k => $post) {
						if(in_array($post['pid'], $delpid) || $post['invisible'] < 0 || in_array($post['authorid'], $delauthorid)) {
							$data[$k]['invisible'] = 0;
							$data[$k]['authorid'] = 0;
							$data[$k]['useip'] = '';
							$data[$k]['dateline'] = 0;
							$data[$k]['pid'] = 0;
							$data[$k]['message'] =lang('forum/misc', 'post_deleted');
						}
						if(isset($updatefid[$post['fid']]) && $updatefid[$post['fid']]['dateline'] > $post['dateline']) {
							$data[$k]['fid'] = $updatefid[$post['fid']]['fid'];
						}
					}
					return $data;
				}
				$storeflag = true;
			}
		}
		$parameter = $this->handle_viewthread_parameter($visibleallflag, $authorid, $forum_pagebydesc, $ordertype);
		$query = DB::query('SELECT * FROM %t WHERE tid=%d %i '.
		($parameter['invisible'] ? ' AND '.$parameter['invisible'] : '').($parameter['authorid'] ? ' AND '.$parameter['authorid'] : '').
		' '.$parameter['orderby'].
		' '.DB::limit($start, $limit),
		array(self::get_tablename('tid:'.$tid), $tid,($status ? ' AND status=1 ' : '')));
		while($post = DB::fetch($query)) {
			$data[$post['pid']] = $post;
		}
		if($storeflag) {
			$this->store_cache($tid, $data, $this->_cache_ttl, $this->_pre_cache_key.'tid_');
		}
		return $data;
	}

	public function fetch_all_by_tid_range_position($tableid, $tid, $start, $end, $maxposition, $ordertype = 0 ,$status) {
		$storeflag = false;
		if($this->_allowmem) {
			if($ordertype != 1 && $start == 1 && $maxposition > ($end - $start)) {
				$data = $this->fetch_cache($tid, $this->_pre_cache_key.'tid_');
				if($data && count($data) == ($end - $start)) {
					$delauthorid = $this->fetch_cache('delauthorid');
					$updatefid = $this->fetch_cache('updatefid');
					$delpid = $this->fetch_cache('delpid');
					foreach($data as $k => $post) {
						if(in_array($post['pid'], $delpid) || $post['invisible'] < 0 || in_array($post['authorid'], $delauthorid)) {
							$data[$k]['invisible'] = 0;
							$data[$k]['authorid'] = 0;
							$data[$k]['useip'] = '';
							$data[$k]['dateline'] = 0;
							$data[$k]['pid'] = 0;
							$data[$k]['message'] = lang('forum/misc', 'post_deleted');
						}
						if(isset($updatefid[$post['fid']]) && $updatefid[$post['fid']]['dateline'] > $post['dateline']) {
							$data[$k]['fid'] = $updatefid[$post['fid']]['fid'];
						}
					}
					return $data;
				}
				$storeflag = true;
			}
		}
		$data = DB::fetch_all('SELECT * FROM %t WHERE tid=%d %i AND position>=%d AND position<%d ORDER BY position'.($ordertype == 1 ? ' DESC' : ''), array(self::get_tablename($tableid), $tid, ($status ? ' AND status=1 ' : ''),$start, $end), 'pid');
		if($storeflag) {
			$this->store_cache($tid, $data, $this->_cache_ttl, $this->_pre_cache_key.'tid_');
		}
		return $data;
	}
	public static function get_tablename($tableid, $primary = 0) {
		list($type, $tid) = explode(':', $tableid);
		if(!isset(self::$_tableid_tablename[$tableid])) {
			if($type == 'tid') {
				self::$_tableid_tablename[$tableid] = self::getposttablebytid($tid, $primary);
			} else {
				self::$_tableid_tablename[$tableid] = self::getposttable($type);
			}
		}
		return self::$_tableid_tablename[$tableid];
	}
	private function handle_viewthread_parameter($visibleallflag, $authorid, $forum_pagebydesc, $ordertype, $alias = '') {
		$return = array();
		if(!$visibleallflag) {
			$return['invisible'] = $alias.DB::field('invisible', 0);
		}
		if($authorid) {
			$return['authorid'] = $alias.DB::field('authorid', $authorid);
		}
		if($forum_pagebydesc) {
			if($ordertype != 1) {
				$return['orderby'] = 'ORDER BY '.$alias.'dateline DESC';
			} else {
				$return['orderby'] = 'ORDER BY '.$alias.'dateline ASC';
			}
		} else {
			if($ordertype != 1) {
				$return['orderby'] = 'ORDER BY '.$alias.'dateline';
			} else {
				$return['orderby'] = 'ORDER BY '.$alias.'dateline DESC';
			}
		}
		return $return;
	}
	public static function getposttable($tableid = 0, $prefix = false) {
		global $_G;
		$tableid = intval($tableid);
		if($tableid) {
			loadcache('posttableids');
			$tableid = $_G['cache']['posttableids'] && in_array($tableid, $_G['cache']['posttableids']) ? $tableid : 0;
			$tablename = 'forum_post'.($tableid ? "_$tableid" : '');
		} else {
			$tablename = 'forum_post';
		}
		if($prefix) {
			$tablename = DB::table($tablename);
		}
		return $tablename;
	}
	public static function getposttablebytid($tids, $primary = 0) {

		$isstring = false;
		if(!is_array($tids)) {
			$thread = getglobal('thread');
			if(!empty($thread) && isset($thread['posttableid']) && $tids == $thread['tid']) {
				return 'forum_post'.(empty($thread['posttableid']) ? '' : '_'.$thread['posttableid']);
			}
			$tids = array(intval($tids));
			$isstring = true;
		}
		$tids = array_unique($tids);
		$tids = array_flip($tids);
		if(!$primary) {
			loadcache('threadtableids');
			$threadtableids = getglobal('threadtableids', 'cache');
			empty($threadtableids) && $threadtableids = array();
			if(!in_array(0, $threadtableids)) {
				$threadtableids = array_merge(array(0), $threadtableids);
			}
		} else {
			$threadtableids = array(0);
		}
		$tables = array();
		$posttable = '';
		foreach($threadtableids as $tableid) {
			$threadtable = $tableid ? "forum_thread_$tableid" : 'forum_thread';
			$query = DB::query("SELECT tid, posttableid FROM ".DB::table($threadtable)." WHERE tid IN(".dimplode(array_keys($tids)).")");
			while ($value = DB::fetch($query)) {
				$posttable = 'forum_post'.($value['posttableid'] ? "_$value[posttableid]" : '');
				$tables[$posttable][$value['tid']] = $value['tid'];
				unset($tids[$value['tid']]);
			}
			if(!count($tids)) {
				break;
			}
		}
		if(empty($posttable)) {
			$posttable = 'forum_post';
			$tables[$posttable] = array_flip($tids);
		}
		return $isstring ? $posttable : $tables;
	}

	public function count_by_tid_invisible_authorid($tid, $authorid ,$status) {
		return DB::result_first('SELECT COUNT(*) FROM %t WHERE tid=%d AND invisible=0 AND authorid=%d %i',
		array(self::get_tablename('tid:'.$tid), $tid, $authorid,($status ? ' AND status=1 ' : '')));
	}

	public function count_visiblepost_by_tid($tid,$status) {
		return DB::result_first('SELECT COUNT(*) FROM %t WHERE tid=%d AND invisible=0 %i', array(self::get_tablename('tid:'.$tid), $tid,($status ? ' AND status=1 ' : '')));
	}

	public function count_by_tid_dateline($tableid, $tid, $dateline,$status) {
		return DB::result_first('SELECT COUNT(*) FROM %t WHERE tid=%d AND invisible=0 %i AND dateline<=%d',
		array(self::get_tablename($tableid), $tid,($status ? ' AND status=1 ' : ''), $dateline));
	}
	public function fetch_all_tradepost_viewthread_by_tid($tid, $visibleallflag, $authorid, $pids, $forum_pagebydesc, $ordertype, $start, $limit,$status) {
		if(empty($pids)) {
			return array();
		}
		$data = array();
		$parameter = $this->handle_viewthread_parameter($visibleallflag, $authorid, $forum_pagebydesc, $ordertype);
		$query = DB::query('SELECT * FROM %t WHERE tid=%d'.
		($parameter['invisible'] ? ' AND '.$parameter['invisible'] : '').($parameter['authorid'] ? ' AND '.$parameter['authorid'] : '').
		' AND pid NOT IN ('.dimplode($pids).') %i'.
		' '.$parameter['orderby'].
		' '.DB::limit($start, $limit),
		array(self::get_tablename('tid:'.$tid), $tid,($status ? ' AND status=1 ' : '')));
		while($post = DB::fetch($query)) {
			$data[$post['pid']] = $post;
		}
		return $data;
	}

	public function fetch_all_debatepost_viewthread_by_tid($tid, $visibleallflag, $authorid, $stand, $forum_pagebydesc, $ordertype, $start, $limit,$status) {
		$data = array();
		$parameter = $this->handle_viewthread_parameter($visibleallflag, $authorid, $forum_pagebydesc, $ordertype, 'p.');
		$query = DB::query("SELECT dp.*, p.* FROM %t p LEFT JOIN %t dp ON p.pid=dp.pid WHERE p.tid=%d %i".
		($parameter['invisible'] ? ' AND '.$parameter['invisible'] : '').($parameter['authorid'] ? ' AND '.$parameter['authorid'] : '').
		(isset($stand) ? ($stand ? ' AND (dp.stand='.intval($stand).' OR p.first=1)' : ' AND (dp.stand=0 OR dp.stand IS NULL OR p.first=1)') : '').
		' '.$parameter['orderby'].
		' '.DB::limit($start, $limit),
		array(self::get_tablename('tid:'.$tid), 'forum_debatepost', $tid,($status ? ' AND status=1 ' : '')));
		while($post = DB::fetch($query)) {
			$data[$post['pid']] = $post;
		}
		return $data;
	}

	public function fetch_all_by_tid_position($tableid, $tid, $position,$status) {
		return DB::fetch_all('SELECT * FROM %t WHERE tid=%d %i AND '.DB::field('position', $position), array(self::get_tablename($tableid), $tid,($status ? ' AND status=1 ' : '')));
	}

	public function fetch_all_by_pid($tableid, $pids, $outmsg = true, $order = '', $start = 0, $limit = 0, $fid = null, $invisible = null,$status) {
		$postlist = $sql = array();
		if($fid !== null) {
			$sql[] = DB::field('fid', $fid);
		}
		if($invisible !== null) {
			$sql[] = DB::field('invisible', $invisible);
		}
		$query = DB::query('SELECT * FROM %t WHERE '.DB::field('pid', $pids).' %i  %i '.($order ? 'ORDER BY dateline '.$order : '').' '.DB::limit($start, $limit),
		array(self::get_tablename($tableid), ($status ? ' AND status=1 ' : ''),($sql ? 'AND '.implode(' AND ', $sql) : '')));
		while($post = DB::fetch($query)) {
			if(!$outmsg) {
				unset($post['message']);
			}
			$postlist[$post[$this->_pk]] = $post;
		}
		return $postlist;
	}
}
//From: dis'.'m.tao'.'bao.com
?>