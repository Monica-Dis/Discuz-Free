<?php
/**
*      $Id: 2018-11-22 01:04:24Z puning $
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$query = C::t('forum_forum')->fetch_all_forum_for_sub_order();
$foldstting= DB::fetch_all('SELECT * FROM %t WHERE 1=1', array('pn_postfold_forums'));

$groups = $forums = $subs = $fids = $showed = $folds=array();
foreach($foldstting as $fold){
	$folds[$fold['fid']]=$fold;
}

foreach($query as $forum) {
	$forum['off']=$folds[$forum['fid']]['off'];
	$forum['fold']=$folds[$forum['fid']]['fold'];
	$forum['del']=$folds[$forum['fid']]['del'];
	$forum['lockuser']=$folds[$forum['fid']]['lockuser'];
	$forum['autofold']=$folds[$forum['fid']]['autofold'];
	$forum['gid']=$folds[$forum['fid']]['gid'];
	if($forum['type'] == 'group') {
		$groups[$forum['fid']] = $forum;
	} elseif($forum['type'] == 'sub') {
		$subs[$forum['fup']][] = $forum;
	} else {
		$forums[$forum['fup']][] = $forum;
	}
	$fids[] = $forum['fid'];
}


if(!submitcheck('editsubmit')) {
	showformheader('plugins&operation=config&identifier=pn_postfold&pmod=admin_setting');
	echo '<div style="height:30px;line-height:30px;"><a href="javascript:;" onclick="show_all()">'.cplang('show_all').'</a> | <a href="javascript:;" onclick="hide_all()">'.cplang('hide_all').'</a></div>';
	showtableheader('');
	showsubtitle(array( 'forums_admin_name', '', lang('plugin/pn_postfold', 'op_off'), lang('plugin/pn_postfold', 'op_fold'), lang('plugin/pn_postfold', 'op_del'), lang('plugin/pn_postfold', 'op_lock'), lang('plugin/pn_postfold', 'op_gid'), lang('plugin/pn_postfold', 'auto_fold')));
	foreach ($groups as $id => $gforum) {
		$toggle = $forumcount > 50 && count($forums[$id]) > 2;
		$showed[] = showforum($gforum, 'group', '', $toggle);
		if(!empty($forums[$id])) {
			foreach ($forums[$id] as $forum) {
				$showed[] = showforum($forum);
				$lastfid = 0;
				if(!empty($subs[$forum['fid']])) {
					foreach ($subs[$forum['fid']] as $sub) {
						$showed[] = showforum($sub, 'sub');
						$lastfid = $sub['fid'];
					}
				}
				showforum($forum, $lastfid, 'lastchildboard');
			}
		}
		showforum($gforum, '', 'lastboard');
	}

	showsubmit('editsubmit');
	showtablefooter(); /*Dism��taobao��com*/
	showformfooter(); /*Dism_taobao_com*/
}else{

	foreach($fids as $fid){
		$off=$_GET['off'][$fid] ? 1 : 0;
		$fold=$_GET['fold'][$fid] ? 1 : 0;
		$del=$_GET['del'][$fid] ? 1 : 0;
		$lock=$_GET['lock'][$fid] ? 1 : 0;
		$autofold=$_GET['autofold'][$fid] ? 1 : 0;
		$gid=$_GET['gid'][$fid] ? $_GET['gid'][$fid] : 0;
		$data[]='('.$fid.','.$off.','.$fold.','.$del.','.$lock.',\''.$gid.'\','.$autofold.')';
	}
	if($data){
		DB::query('REPLACE INTO %t (fid,off,fold,del,lockuser,gid,autofold) VALUES '.implode(',', $data), array('pn_postfold_forums'));
	}


	cpmsg(lang('plugin/pn_postfold', 'success_setting'), 'action=plugins&operation=config&identifier=pn_postfold&pmod=admin_setting', 'succeed');

}


function showforum(&$forum, $type = '', $last = '', $toggle = false) {

	global $_G;

	if($last == '') {

		$navs = array();
		foreach(C::t('common_nav')->fetch_all_by_navtype_type(0, 5) as $nav) {
			$navs[] = $nav['identifier'];
		}
		$return = '<tr class="hover"><td>';
		if($type == 'group') {
			$return .= '<div class="parentboard">';
			$_G['fg'] = !empty($_G['fg']) ? intval($_G['fg']) : 0;
			$_G['fg']++;
		} elseif($type == '') {
			$return .= '<div class="board">';
		} elseif($type == 'sub') {
			$return .= '<div id="cb_'.$forum['fid'].'" class="childboard">';
		}

		$boardattr = '';
		if(!$forum['status']  || $forum['password'] || $forum['redirect'] || in_array($forum['fid'], $navs)) {
			$boardattr = '<div class="boardattr">';
			$boardattr .= $forum['status'] ? '' : cplang('forums_admin_hidden');
			$boardattr .= !$forum['password'] ? '' : ' '.cplang('forums_admin_password');
			$boardattr .= !$forum['redirect'] ? '' : ' '.cplang('forums_admin_url');
			$boardattr .= !in_array($forum['fid'], $navs) ? '' : ' '.cplang('misc_customnav_parent_top');
			$boardattr .= '</div>';
		}
		$off =	$forum['off'] ? 'checked="checked"' : '';
		$fold =	$forum['fold'] ? 'checked="checked"' : '';
		$del =	$forum['del'] ? 'checked="checked"' : '';
		$lock =	$forum['lockuser'] ? 'checked="checked"' : '';
		$gid =	$forum['gid'] ? $forum['gid'] : '';
		$autofold =	$forum['autofold'] ? 'checked="checked"' : '';
		$return .= dhtmlspecialchars($forum['name']).
		'</div>'.$boardattr.
		'</td><td align="right" class="td23 lightfont">('.($type == 'group' ? 'gid:' : 'fid:').$forum['fid'].')</td>'.
		'<td>'.($type != 'group' ? '<input name="off['.$forum['fid'].']" class="checkbox" value="1" type="checkbox" '.$off.'>' : '').'</td>'.
		'<td>'.($type != 'group' ? '<input name="fold['.$forum['fid'].']" class="checkbox" value="1" type="checkbox" '.$fold.'>' : '').'</td>'.
		'<td>'.($type != 'group' ? '<input name="del['.$forum['fid'].']" class="checkbox" value="1" type="checkbox" '.$del.'>' : '').'</td>'.
		'<td>'.($type != 'group' ? '<input name="lock['.$forum['fid'].']" class="checkbox" value="1" type="checkbox" '.$lock.'>' : '').'</td>'.
		'<td>'.($type != 'group' ? '<input name="gid['.$forum['fid'].']" class="txt" value="'.$gid.'" type="text" placeholder="'.lang('plugin/pn_postfold', 'gidshow').'">' : '').'</td>'.
		'<td>'.($type != 'group' ? '<input name="autofold['.$forum['fid'].']" class="checkbox" value="1" type="checkbox" '.$autofold.'>' : '').'</td>';		
		if($type == 'group') $return .= '<tbody id="group_'.$forum['fid'].'"'.($toggle ? ' style="display:none;"' : '').'>';
	} else {
		if($last == 'lastboard') {
			$return = '</tbody>';
		} elseif($last == 'lastchildboard' && $type) {
			$return = '<script type="text/JavaScript">$(\'cb_'.$type.'\').className = \'lastchildboard\';</script>';
		} elseif($last == 'last') {
			$return = '</tbody>';
		}
	}

	echo  $return = isset($return) ? $return : '';

	return $forum['fid'];
}

function showforum_moderators($forum) {
	global $_G;
	if($forum['moderators']) {
		$moderators = explode("\t", $forum['moderators']);
		$count = count($moderators);
		$max = $count > 2 ? 2 : $count;
		$mods = array();
		for($i = 0;$i < $max;$i++) {
			$mods[] = $forum['inheritedmod'] ? '<b>'.$moderators[$i].'</b>' : $moderators[$i];
		}
		$r = implode(', ', $mods);
		if($count > 2) {
			$r = '<span onmouseover="showMenu({\'ctrlid\':this.id})" id="mods_'.$forum['fid'].'">'.$r.'</span>';
			$mods = array();
			foreach($moderators as $moderator) {
				$mods[] = $forum['inheritedmod'] ? '<b>'.$moderator.'</b>' : $moderator;
			}
			$r = '<a href="'.ADMINSCRIPT.'?action=forums&operation=moderators&fid='.$forum['fid'].'" title="'.cplang('forums_moderators_comment').'">'.$r.' &raquo;</a>';
			$r .= '<div class="dropmenu1" id="mods_'.$forum['fid'].'_menu" style="display: none">'.implode('<br />', $mods).'</div>';
		} else {
			$r = '<a href="'.ADMINSCRIPT.'?action=forums&operation=moderators&fid='.$forum['fid'].'" title="'.cplang('forums_moderators_comment').'">'.$r.' &raquo;</a>';
		}

	} else {
		$r = '<a href="'.ADMINSCRIPT.'?action=forums&operation=moderators&fid='.$forum['fid'].'" title="'.cplang('forums_moderators_comment').'">'.cplang('forums_admin_no_moderator').'</a>';
	}
	return $r;
}


function get_subfids($fid) {
	global $subfids, $_G;
	$subfids[] = $fid;
	foreach($_G['cache']['forums'] as $key => $value) {
		if($value['fup'] == $fid) {
			get_subfids($value['fid']);
		}
	}
}
//From: Dism_taobao-com
?>