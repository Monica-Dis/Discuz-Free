<?php
/**
*      $Id: 2019-3-5 01:04:24Z puning $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}

if(!$_GET['pid']){
	showmessage(lang('plugin/pn_postfold', 'error_pid'));
}

$thread = DB::fetch_first('SELECT * FROM %t WHERE pid=%d', array('forum_post',$_GET['pid']));
$foldseting = C::t('#pn_postfold#pn_postfold_forums')->fetch_info_by_fid($thread['fid']);
if(!$foldseting['off']){
	showmessage(lang('plugin/pn_postfold', 'error_nopem'));
}
$authorid = DB::result_first('SELECT authorid FROM %t WHERE tid=%d', array('forum_thread',$thread['tid']));
if($_G['uid'] != $authorid){
	showmessage(lang('plugin/pn_postfold', 'error_pem'));
}
$gorupids = explode(",",$foldseting['lock']);
if($gorupids && !in_array($_G['gorupid'],$gorupids) && !array_intersect($gorupids,explode("\t",$_G['member']['extgroupids']))){
	showmessage(lang('plugin/pn_postfold', 'error_nogidpem'));
}
if(submitcheck('delsubmit')){
	if(!$foldseting['del']){
		showmessage(lang('plugin/pn_postfold', 'error_nopem'));
	}
	$pids = array($thread['pid']);

	if($pids && !$thread['first']) {
		require_once libfile('function/delete');
		if($_G['forum']['recyclebin']) {
			deletepost($pids, 'pid', true, false, true);
			manage_addnotify('verifyrecyclepost', $modpostsnum);
		} else {
			$logs = array();
			$ratelog = C::t('forum_ratelog')->fetch_all_by_pid($pids);
			$rposts = C::t('forum_post')->fetch_all('tid:'.$_GET['tid'], $pids, false);
			foreach(C::t('forum_ratelog')->fetch_all_by_pid($pids) as $rpid => $author) {
				if($author['score'] > 0) {
					$rpost = $rposts[$rpid];
					updatemembercount($rpost['authorid'], array($author['extcredits'] => -$author['score']));
					$author['score'] = $_G['setting']['extcredits'][$id]['title'].' '.-$author['score'].' '.$_G['setting']['extcredits'][$id]['unit'];
					$logs[] = dhtmlspecialchars("$_G[timestamp]\t{$_G[member][username]}\t$_G[adminid]\t$rpost[author]\t$author[extcredits]\t$author[score]\t$thread[tid]\t$thread[subject]\t$delpostsubmit");
				}
			}
			if(!empty($logs)) {
				writelog('ratelog', $logs);
				unset($logs);
			}
			deletepost($pids, 'pid', true);
		}
		updatethreadcount($thread['tid'], 1);
		updateforumcount($thread['fid']);

		deletethreadcaches($thread['tid']);
	}

	showmessage(lang('plugin/pn_postfold', 'success_del'),'forum.php?mod=viewthread&tid='.$thread['tid'],array(),array('showmsg'=>true));


}elseif(submitcheck('foldsubmit')){
	if(!$foldseting['fold']){
		showmessage(lang('plugin/pn_postfold', 'error_nopem'));
	}
	DB::query('update %t set status=%d where pid=%d',array('forum_post',1,$_GET['pid']));
	showmessage(lang('plugin/pn_postfold', 'success_fold'), 'forum.php?mod=viewthread&tid='.$thread['tid'],array(),array('showmsg'=>true));

}elseif(submitcheck('unfoldsubmit')){
	if(!$foldseting['fold']){
		showmessage(lang('plugin/pn_postfold', 'error_nopem'));
	}
	DB::query('update %t set status=%d where pid=%d',array('forum_post',0,$_GET['pid']));
	showmessage(lang('plugin/pn_postfold', 'success_unfold'), 'forum.php?mod=viewthread&tid='.$thread['tid'],array(),array('showmsg'=>true));
}elseif(submitcheck('locksubmit')){
	if(!$foldseting['lockuser']){
		showmessage(lang('plugin/pn_postfold', 'error_nopem'));
	}
	$lockuids = DB::fetch_first('SELECT * FROM %t WHERE tid=%d', array('pn_postfold_lockuser',$thread['tid']));
	$pid=$_GET['pid'];
	$lockuid=DB::result_first("SELECT authorid FROM ".DB::table('forum_post')." WHERE pid='$pid' AND tid='{$thread['tid']}'");

	if($lockuid){
	if($lockuids){
		$uids=unserialize($lockuids['uids']);
	}
	if($uids){
		$uids =array_unique(array_merge($uids, array($lockuid)));
	}else{
		$uids =array($lockuid);
	}
	DB::query('REPLACE INTO %t (tid,fid,uids) VALUES ('.$thread['tid'].','.$thread['fid'].",'".serialize($uids)."')", array('pn_postfold_lockuser'));
	showmessage(lang('plugin/pn_postfold', 'success_lock'), 'forum.php?mod=viewthread&tid='.$thread['tid'],array(),array('showmsg'=>true));		
	}else{
	showmessage(lang('plugin/pn_postfold', 'error_uid'), 'forum.php?mod=viewthread&tid='.$thread['tid'],array(),array('showmsg'=>true));		
	}

}elseif(submitcheck('unlocksubmit')){
	if(!$foldseting['lockuser']){
		showmessage(lang('plugin/pn_postfold', 'error_nopem'));
	}
	$lockuids = DB::fetch_first('SELECT * FROM %t WHERE tid=%d', array('pn_postfold_lockuser',$thread['tid']));
	$pid=$_GET['pid'];
	$lockuid=DB::result_first("SELECT authorid FROM ".DB::table('forum_post')." WHERE pid='$pid' AND tid='{$thread['tid']}'");

	if($lockuid){
	if($lockuids){
		$uids=unserialize($lockuids['uids']);
	}
	if($uids){
		$uids = array_diff($uids, array($lockuid));
	}else{
		$uids =array($lockuid);
	}

	DB::query('REPLACE INTO %t (tid,fid,uids) VALUES ('.$thread['tid'].','.$thread['fid'].",'".serialize($uids)."')", array('pn_postfold_lockuser'));
	showmessage(lang('plugin/pn_postfold', 'success_unlock'), 'forum.php?mod=viewthread&tid='.$thread['tid'],array(),array('showmsg'=>true));
	}else{
	showmessage(lang('plugin/pn_postfold', 'error_uid'), 'forum.php?mod=viewthread&tid='.$thread['tid'],array(),array('showmsg'=>true));		
	}
}
//From: dis'.'m.tao'.'bao.com
?>