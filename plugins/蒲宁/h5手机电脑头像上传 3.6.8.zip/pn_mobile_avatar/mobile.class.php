<?php

/**
*	[h5手机电脑头像上传(pn_mobile_avatar)] (C)2013-2099 Powered by dis'.'m.tao'.'bao.com.
*	Version: 1.0
*	Date: 2017-10-20 20:00
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_pn_mobile_avatar {

	function  global_footer_mobile() {
		global $_G;
		if($_G['cache']['plugin']['pn_mobile_avatar']['offmb']){

			if(CURMODULE=='space' && $_G['basescript']=='home' && $_GET['do']=='profile' && $_GET['mycenter'] && $_GET['uid']==$_G['uid']){
				$js =$js.'<script>$(".myinfo_list ul").append("<li><a href=\'home.php?mod=spacecp&ac=avatar&mobile=2\'>'.lang('plugin/pn_mobile_avatar','myavatar').'</a></li>")</script>';
			}
			return($js);
		}
	}
}

class mobileplugin_pn_mobile_avatar_home{

	function spacecp_avatar() {
		global $_G,$space;
		if($_G['cache']['plugin']['pn_mobile_avatar']['offmb']){
			$_G['cache']['plugin']['pn_mobile_avatar']['setAspectRatio'] = 	$_G['cache']['plugin']['pn_mobile_avatar']['setAspectRatio'] ? $_G['cache']['plugin']['pn_mobile_avatar']['setAspectRatio'] : 0;

			$_G['setting']['avatarmethod']=1;
			$ucenterurl = empty($ucenterurl) ? $_G['setting']['ucenterurl'] : $ucenterurl;
			require_once libfile('function/spacecp');
			require_once libfile('function/magic');

			$acs = array('space', 'doing', 'upload', 'comment', 'blog', 'album', 'relatekw', 'common', 'class',
			'swfupload', 'poke', 'friend', 'eccredit', 'favorite', 'follow',
			'avatar', 'profile', 'theme', 'feed', 'privacy', 'pm', 'share', 'invite','sendmail',
			'credit', 'usergroup', 'domain', 'click','magic', 'top', 'videophoto', 'index', 'plugin', 'search', 'promotion');

			$_GET['ac'] = $ac = (empty($_GET['ac']) || !in_array($_GET['ac'], $acs))?'profile':$_GET['ac'];
			$op = empty($_GET['op'])?'':$_GET['op'];
			if(!in_array($ac, array('doing', 'upload', 'blog', 'album'))) {
				$_G['mnid'] = 'mn_common';
			}


			if($ac != 'comment' || !$_G['group']['allowcomment']) {
				if(empty($_G['uid'])) {
					if($_SERVER['REQUEST_METHOD'] == 'GET') {
						dsetcookie('_refer', rawurlencode($_SERVER['REQUEST_URI']));
					} else {
						dsetcookie('_refer', rawurlencode('home.php?mod=spacecp&ac='.$ac));
					}
					showmessage('to_login', '', array(), array('showmsg' => true, 'login' => 1));
				}

				$space = getuserbyuid($_G['uid']);
				if(empty($space)) {
					showmessage('space_does_not_exist');
				}
				space_merge($space, 'field_home');

				if(($space['status'] == -1 || in_array($space['groupid'], array(4, 5, 6))) && $ac != 'usergroup') {
					showmessage('space_has_been_locked');
				}
			}
			$actives = array($ac => ' class="a"');

			list($seccodecheck, $secqaacheck) = seccheck('publish');

			$navtitle = lang('core', 'title_setup');
			if(lang('core', 'title_memcp_'.$ac)) {
				$navtitle = lang('core', 'title_memcp_'.$ac);
			}

			$_G['disabledwidthauto'] = 0;
			dsetcookie('avatar_refer', 3);

			require_once libfile('spacecp_avatar', 'plugin/pn_mobile_avatar/include');
			exit;
		}
	}

}
//dis'.'m.tao'.'bao.com
?>