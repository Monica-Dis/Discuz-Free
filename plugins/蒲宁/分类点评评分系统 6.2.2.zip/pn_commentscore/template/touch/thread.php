<?php exit;?>

{eval
function tpl_pn_commentsocre_forumdisplay_filter_extra_output($scoreidentifier,$commentsearch,$sfiltername,$cfiltername) {
}
{eval global $_G;}
<!--{block return}-->
<!--{if $scoreidentifier}-->
<a id="filter_score" href="javascript:;" class="showmenu xi2{if in_array($_GET['orderby'],$scoreidentifier)} xw1{/if}" onclick="showMenu(this.id)">{if $sfiltername}$sfiltername{else}{lang pn_commentscore:scorefilter}{/if}</a>&nbsp;
<!--{/if}-->
<!--{loop $commentsearch $option}-->
<a id="filter_{$option[identifier]}" href="javascript:;" class="showmenu xi2{if $_GET[''.$option[identifier]]} xw1{/if}" onclick="showMenu(this.id)">{if $cfiltername[$option[identifier]]}$cfiltername[$option[identifier]]{else}$option[title]{/if}</a>&nbsp;
<!--{/loop}-->

<!--{/block}-->
{eval return $return;}

{eval
}
function tpl_pn_commentsocre_forumdisplay_top_output($scoresearch,$commentsearch,$c_sorturladdarray,$allurladd) {
}
{eval global $_G;}
<!--{block return}-->
<div id="filter_score_menu" class="p_pop" style="display:none" change="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter='+$('filter_special').value">
	<ul>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort$allurladd" class="xi2">{lang default}</a></li>

		<!--{loop $scoresearch $option}-->
		<li{if isset($_GET['orderby'])&&$_GET['orderby']=$option[identifier]} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G['fid']&filter=scsort&orderby=$option[identifier]$allurladd">$option[title]</a></li>
		<!--{/loop}-->
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&orderby=numasc$allurladd" class="xi2{if $_GET['filter'] == 'lastpost'} xw1{/if}">{lang pn_commentscore:numasc}</a></li>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&orderby=numdesc$allurladd" class="xi2{if $_GET['filter'] == 'lastpost'} xw1{/if}">{lang pn_commentscore:numdesc}</a></li>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&orderby=lastpost$allurladd" class="xi2{if $_GET['filter'] == 'lastpost'} xw1{/if}">{lang pn_commentscore:latest}</a></li>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&orderby=heats$forumdisplayadd[heat]$allurladd" class="xi2{if $_GET['filter'] == 'heat'} xw1{/if}">{lang pn_commentscore:order_heats}</a></li>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&digest=1$forumdisplayadd[digest]$allurladd" class="xi2{if $_GET['filter'] == 'digest'} xw1{/if}">{lang pn_commentscore:digest_posts}</a></li>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&orderby=replies$forumdisplayadd[reply]$allurladd" {if $_GET['orderby'] == 'replies'}class="xw1"{/if}>{lang pn_commentscore:replies}</a></li>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&orderby=views$forumdisplayadd[view]$allurladd" {if $_GET['orderby'] == 'views'}class="xw1"{/if}>{lang pn_commentscore:views}</a></li>
	</ul>
</div>
<!--{loop $commentsearch $optionid $option}-->
<div id="filter_{$option[identifier]}_menu" class="p_pop" style="display:none" change="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter='+$('filter_special').value">
	<ul>
		<li{if !isset($_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&$option[identifier]=all$c_sorturladdarray[$option[identifier]]" class="xi2">{lang pn_commentscore:unlimited}</a></li>
		<!--{if $option[type] == 'select'}-->
		<!--{loop $option[choices] $id $value}-->
		<!--{if $value[foptionid] == 0}-->
		<li{if preg_match('/^'.$value[optionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[optionid].'$/i', $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&$option[identifier]=$id$c_sorturladdarray[$option[identifier]]" class="xi2">$value[content]</a></li>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{if !($_GET[''.$option[identifier]] == 'all' || !isset($_GET[''.$option[identifier]]))}-->
		<!--{loop $option[choices] $id $value}-->
		<!--{if (preg_match('/^'.$value[foptionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[foptionid].'$/i', $_GET[''.$option[identifier]])) && ($showoption[$value[count]][$id] = $value)}-->
		<!--{/if}-->
		<!--{/loop}-->
		<!--{if ksort($showoption)}--><!--{/if}-->
		<!--{loop $showoption $optioncount $values}-->
		<!--{if $tmpcount != $optioncount && ($tmpcount = $optioncount)}-->
	</ul><ul class="subtsm cl">
		<!--{loop $values $id $value}-->
		<li{if preg_match('/^'.$value[optionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[optionid].'$/i', $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&$option[identifier]=$id$c_sorturladdarray[$option[identifier]]" class="xi2">$value[content]</a></li>
		<!--{/loop}-->
	</ul><ul>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
		<!--{else}-->
		<!--{loop $option[choices] $id $value}-->
		<li{if $_GET[''.$option[identifier]] && !strcmp($id, $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&$option[identifier]=$id$c_sorturladdarray[$option[identifier]]" class="xi2">$value</a></li>
		<!--{/loop}-->
		<!--{/if}-->
	</ul>
</div>
<!--{/loop}-->

<!--{/block}-->
{eval return $return;}


{eval
}
function tpl_pn_commentsocre_viewthread_beginline_output($functionname, $showtype, $othervalue) {
}
{eval global $_G;}

<!--{if $functionname=='commentshow'}-->
<!--{block return}-->
<!--{if $showtype=='pc'}-->
<table cellspacing="0"  class="comment cgtl mbm"><tbody>
	<!--{loop $_G[pn_comment_option] $key $option}-->
	<!--{if $option[type] != 'info'}-->
	<tr id="{$key}"><th>{$option[title]}&nbsp;:&nbsp;</th><td>
		<!--{if $option[value] || ($option[type] == 'number' && $option[value] !== '')}-->
		{$option[value]} {$option[unit]}
		<!--{else}-->
		-
		<!--{/if}-->
	</td></tr>
	<!--{/if}-->
	<!--{/loop}-->
</tbody></table>
<!--{elseif $showtype=='mobile'}-->
<div class="box box_ex2 viewsort viewcomment" id="{$key}">
	<!--{loop $_G[pn_comment_option]  $option}-->
	<!--{if $option[type] != 'info'}-->
	{$option[title]}&nbsp;:&nbsp;
	<!--{if $option[value] || ($option[type] == 'number' && $option[value] !== '')}-->
	{$option[value]} {$option[unit]}
	<!--{else}-->
	-
	<!--{/if}-->
	<br>
	<!--{/if}-->
	<!--{/loop}-->
</div>
<!--{/if}-->

<!--{elseif $functionname=='scoreshow'}-->
<div class="starnum">
	<div class="stars">
		<!--{loop $_G[pn_score_option] $key $option}-->
		<!--{if $option[type]=='range'}-->
		<div class="sstar" id="{$key}"><dl><dt>{$option[title]}&nbsp;:&nbsp;</dt><dl>
			{$option[value]}
		</dl></dl></div>
		<!--{/if}-->
		<!--{/loop}-->
	</div>
	<div class="snums">
		<!--{loop $_G[pn_score_option] $key $option}-->
		<!--{if $option[type]=='number'}-->
		<div class="snum" id="{$key}"><dl><dt>{$option[title]}&nbsp;:&nbsp;</dt><dl>
			{$option[value]}
		</dl></dl></div>
		<!--{/if}-->
		<!--{/loop}-->
	</div>
</div>

<!--{elseif $functionname=='scthreadshowcomment'}-->
<div id="tcomment"><div class="tranges">
	<!--{loop $_G[pn_comment_option] $key $option}-->
	<!--{if $option[type]=='range'}-->
	<div class="trange" id="{$key}"><dl><dt>{$option[title]}&nbsp;:&nbsp;</dt><dl><dl>
		<dd class="trangevalue">{$option[value]} {$option[unit]}</dd>
	</dl></dl></dl></div>
	<!--{/if}-->
	<!--{/loop}-->
</div></div>

<!--{elseif $functionname=='scthreadshowtotal'}-->
<div id="scorecount">(<em>{$othervalue}</em>  {lang pn_commentscore:totalnum})</div>
<!--{/if}-->
<!--{/block}-->

{eval return $return;}
{eval
}
}






