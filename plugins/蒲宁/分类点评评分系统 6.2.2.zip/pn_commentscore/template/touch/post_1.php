<?php exit;?>
<!--{template common/header}-->

<body>
	<style>
		.post_msg_from li, .post_from li{line-height:unset;}
		.xl2 li{width:50%;display: inline-block;width: 40%;}
		.tfm,.tfm tr,.tfm td{width:100%;}
		.post_imglist li .del1 {position: absolute;left: -5px;top: -10px;}
		.post_types{clear: right;}
		.post_from li.bl_line{padding:5px;min-height:60px;}
		.d{color:#999;}

		@font-face {
			font-family:'pn_iconfont';
			src:url('pn_font.eot');
			src:url('pn_font.eot?#iefix') format('embedded-opentype'),
			url('source/plugin/pn_commentscore/template/fonts/pn_font.svg#pn_iconfont') format('svg'),
			url('source/plugin/pn_commentscore/template/fonts/pn_font.woff') format('woff'),
			url('source/plugin/pn_commentscore/template/fonts/pn_font.ttf') format('truetype');
		}
		.pn_iconfont {
			font-family:"pn_iconfont" !important;
			font-size:16px;
			font-style:normal;
			-webkit-font-smoothing:antialiased;
			-webkit-text-stroke-width:0px;
			-moz-osx-font-smoothing:grayscale;
		}

		.headerleftbtn {
			position: absolute;
			left: 0;
			top: 0;
			width: auto;
			height: 45px;
			margin-left: 10px;
			display: block;
			cursor: pointer;
		}
		.headerrightbtn{
			position: absolute;
			right: 0;
			top: 0;
			width: auto;
			height: 45px;
			margin-right: 10px;
			display: block;
			cursor: pointer;
		}
		.icon-home{color:#fff;}
		.backbtn {
			background-position: -6px 11px;
			background-size: 22px auto;
			color: #fff;
			font-size: 16px;
		}
		.userinfo th{width:72px;}
		.header{height:0;line-height:0;}
		.pnnav{width: 100%;
			height: 45px;
			line-height: 45px;
			color: #ffffff;
			font-size: 19px;
			text-align: center;
			z-index: 99;
			background: {$_G['cache']['plugin']['pn_commentscore']['templatecolor']};
			position: fixed;
			top: 0;
		}
		.pnpn{
			width: 100%;
			height: 40px;
			line-height: 40px;
			text-align: center;
			font-size:16px;
			border-radius: 4px;
			color: #ffffff;
			border: 0;
			background: {$_G['cache']['plugin']['pn_commentscore']['templatecolor']};
		}
		.px{
			width: 100%;
			height: 40px;
			line-height: 20px;
			padding: 10px;
			border-radius: 4px;
			-moz-box-sizing: border-box;
			-webkit-box-sizing: border-box;
			box-sizing: border-box;
		}
		.vm{border: 0;}

	</style>
	<header class="header">
		<div id="ajaxhtml" style="display:none"></div>
		<div class="pnnav">
			<a href="javascript:history.back();" class="headerleftbtn">

				<div class="backbtn"><i class="pn_iconfont">&#xe60d;</i></div>
			</a>
			<span>{$scname}</span>
			<a href="./" class="headerrightbtn" data-fwpageload="1">
				<i class="icon pn_iconfont icon-home">&#xe662;</i>
			</a>
		</div>
	</header>

	<script type="text/javascript">
		function browserVersion(types) {
			var other = 1;
			for(i in types) {
				var v = types[i] ? types[i] : i;
				if(USERAGENT.indexOf(v) != -1) {
					var re = new RegExp(v + '(\\/|\\s|:)([\\d\\.]+)', 'ig');
					var matches = re.exec(USERAGENT);
					var ver = matches != null ? matches[2] : 0;
					other = ver !== 0 && v != 'mozilla' ? 0 : other;
				}else {
					var ver = 0;
				}
				eval('BROWSER.' + i + '= ver');
			}
			BROWSER.other = other;
		}

		var BROWSER = {};
		var USERAGENT = navigator.userAgent.toLowerCase();
		browserVersion({'ie':'msie','firefox':'','chrome':'','opera':'','safari':'','mozilla':'','webkit':'','maxthon':'','qq':'qqbrowser','rv':'rv'});
		if(BROWSER.safari || BROWSER.rv) {
			BROWSER.firefox = true;
		}
		BROWSER.opera = BROWSER.opera ? opera.version() : 0;
	</script>
	<div class="wp">
		<div class="post_from" style="margin-top: 50px;">
			<form method="post" autocomplete="off" id="commentform" action="plugin.php?id=pn_commentscore:post&tid={$tid}&scoresortid={$scoresortid}&commentsortid={$commentsortid}" onsubmit="return validateextra()">
				<script type="text/javascript">
					var forum_optionlist = <!--{if $forum_optionlist}-->'$forum_optionlist'<!--{else}-->''<!--{/if}-->;
					</script>
					<script type="text/javascript" src="{$_G['setting']['jspath']}threadsort.js?{VERHASH}"></script>
					<style type="text/css">
						<!--{eval include_once template('pn_commentscore:css');}-->
						<!--{eval $css=post_m_css($icon);}-->
						{$css}
					</style>

					<div class="f_c">

						<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
						<input type="hidden" name="handlekey" value="$_GET['handlekey']" />
						<div class="c">
							<!--{eval $extname=rand();}-->
							<!--{loop $_G['forum_scoreoptionlist'] $optionid $option}-->
							<li class="bl_line">

								<dt><!--{if $option['required']}--><span class="rq">*</span><!--{/if}-->$option[title]</dt>
								<dd id="select_$option[identifier]">
									<div id="select_$option[identifier]">
										<!--{if $option['type'] == 'range'}-->
										<div id="{$option[identifier]}{$extname}" class="star" onclick="checkoption('$option[identifier]', '$option[required]', '$option[type]')">$option[template]</div>
										<!--{/if}-->
										<!--{if $option['type'] == 'number'}-->
										<div id="{$option[identifier]}{$extname}" class="num" onclick="checkoption('$option[identifier]', '$option[required]', '$option[type]')">$option[template]</div>
										<!--{/if}-->
										<input type="hidden" name="typeoption[{$option[identifier]}]" id="typeoption_$option['identifier']" value="">
									</div>
								</dd>
								<span id="check{$option[identifier]}"></span>
								<!--{if $option[description]}-->
								<br/>
								<span>$option[description]</span>
								<!--{/if}-->
							</li>
							<!--{/loop}-->
							<!--{loop $_G['forum_commentoptionlist'] $optionid $option}-->
							<li class="bl_line">
								<!--{if in_array($option['type'], array('select','image','checkbox', 'radio','upload'))}-->
								<dt><!--{if $option['required']}--><span class="rq">*</span><!--{/if}-->$option[title]</dt>
								<!--{/if}-->
								<dd id="select_$option[identifier]">
									<!--{if in_array($option['type'], array('number', 'text', 'email', 'calendar', 'image', 'url', 'upload', 'range'))}-->
									<!--{if $option['type'] == 'calendar'}-->
									<input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" placeholder="<!--{if $option['required']}-->*<!--{/if}-->$option[title]" tabindex="1" size="$option[inputsize]" onchange="checkoption('$option[identifier]', '$option[required]', '$option[type]')" value="$option[value]" onclick="showcalendar(event, this, false)" $option[unchangeable] class="px"/>
									<!--{elseif $option['type'] == 'image'}-->
									<!--{if !($option[unchangeable] && $option['value'])}-->
									<button type="button" class="pn" style="width:100%" onclick="uploadwindow();$('#imglistid').val('{$option[identifier]}');"><em><!--{if $option['value']}-->{lang update}<!--{else}-->{lang upload}<!--{/if}--></em></button>
									<input type="hidden" name="typeoption[{$option[identifier]}][aid]" value="$option[value][aid]" id="sortaid_{$option[identifier]}" />
									<input type="hidden" name="sortaid_{$option[identifier]}_url" id="sortaid_{$option[identifier]}_url" />
									<!--{if $option[value]}--><input type="hidden" name="oldsortaid[{$option[identifier]}]" value="$option[value][aid]" tabindex="1" /><!--{/if}-->
									<input type="hidden" name="typeoption[{$option[identifier]}][url]" id="sortattachurl_{$option[identifier]}" {if $option[value][url]}value="$option[value][url]"{/if} tabindex="1" />
									<!--{/if}-->
									<ul id="{$option[identifier]}imglist" class="post_imglist cl">
										<!--{if $option['value']['url']}-->
										<li><span id="{$option[identifier]}del" imglistid="{$option[identifier]}" aid="{$option[value][aid]}" class="del1"><a href="javascript:;"><img src="{STATICURL}image/mobile/images/icon_del.png"></a></span><span class="p_img"><a href="javascript:;"><img style="height:54px;width:54px;" id="aimg_{$option[value][aid]}" title="{$option[value][name]}" src="{$option[value][url]}" /></a></span><input type="hidden" name="attachnew[{$option[value][aid]}][description]" /></li>
										<!--{/if}-->

									</ul>

									<!--{else}-->
									<input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" placeholder="<!--{if $option['required']}-->*<!--{/if}-->$option[title]" class="px" tabindex="1" size="$option[inputsize]" onBlur="checkoption('$option[identifier]', '$option[required]', '$option[type]'{if $option[maxnum]}, '$option[maxnum]'{else}, '0'{/if}{if $option[minnum]}, '$option[minnum]'{else}, '0'{/if}{if $option[maxlength]}, '$option[maxlength]'{/if})" value="{if $_G['tid']}$option[value]{else}{if $member_profile[$option['profile']]}$member_profile[$option['profile']]{else}$option['defaultvalue']{/if}{/if}" $option[unchangeable] />
									<!--{/if}-->
									<!--{elseif in_array($option['type'], array('radio', 'checkbox', 'select'))}-->
									<!--{if $option[type] == 'select'}-->
									<!--{loop $option['value'] $selectedkey $selectedvalue}-->
									<!--{if $selectedkey}-->
									<script type="text/javascript">
										changeselectthreadsort('$selectedkey', $optionid, 'update');
									</script>
									<!--{else}-->
									<select tabindex="1" onchange="changeselectthreadsort(this.value, '$optionid');checkoption('$option[identifier]', '$option[required]', '$option[type]')" $option[unchangeable] class="ps">
										<option value="0">{lang please_select}</option>
										<!--{loop $option['choices'] $id $value}-->
										<!--{if !$value[foptionid]}-->
										<option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
										<!--{/if}-->
										<!--{/loop}-->
									</select>
									<!--{/if}-->
									<!--{/loop}-->
									<!--{if !is_array($option['value'])}-->
									<select tabindex="1" onchange="changeselectthreadsort(this.value, '$optionid');checkoption('$option[identifier]', '$option[required]', '$option[type]')" $option[unchangeable] class="ps">
										<option value="0">{lang please_select}</option>
										<!--{loop $option['choices'] $id $value}-->
										<!--{if !$value[foptionid]}-->
										<option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
										<!--{/if}-->
										<!--{/loop}-->
									</select>
									<!--{/if}-->
									<!--{elseif $option['type'] == 'radio'}-->
									<ul class="xl2">
										<!--{loop $option['choices'] $id $value}-->
										<li><label><input type="radio" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" class="pr" tabindex="1" onclick="checkoption('$option[identifier]', '$option[required]', '$option[type]')" value="$id" $option['value'][$id] $option[unchangeable] class="pr"> $value</label></li>
										<!--{/loop}-->
									</ul>
									<!--{elseif $option['type'] == 'checkbox'}-->
									<ul class="xl2">
										<!--{loop $option['choices'] $id $value}-->
										<li><label><input type="checkbox" name="typeoption[{$option[identifier]}][]" id="typeoption_$option[identifier]" class="pc" tabindex="1" onclick="checkoption('$option[identifier]', '$option[required]', '$option[type]')" value="$id" $option['value'][$id][$id] $option[unchangeable] class="pc"> $value</label></li>
										<!--{/loop}-->
									</ul>
									<!--{/if}-->
									<!--{elseif in_array($option['type'], array('textarea'))}-->
									<textarea name="typeoption[{$option[identifier]}]" tabindex="1" id="typeoption_$option[identifier]" rows="$option[rowsize]" cols="$option[colsize]" onBlur="checkoption('$option[identifier]', '$option[required]', '$option[type]', 0, 0{if $option[maxlength]}, '$option[maxlength]'{/if})" $option[unchangeable] class="pt">$option[value]</textarea>
									<!--{/if}-->
									$option[unit]
								</dd>
								<!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->
								<div class="d">
									<!--{if $option['maxnum']}-->
									&#x6700;&#x5927;&#x503C; $option[maxnum]&nbsp;
									<!--{/if}-->
									<!--{if $option['minnum']}-->
									&#x6700;&#x5C0F;&#x503C; $option[minnum]&nbsp;
									<!--{/if}-->
									<!--{if $option['maxlength']}-->
									&#x6700;&#x5927;&#x957F;&#x5EA6; $option[maxlength]&nbsp;
									<!--{/if}-->
									<!--{if $option['unchangeable']}-->
									&#x4E0D;&#x53EF;&#x4FEE;&#x6539;&nbsp;
									<!--{/if}-->
									<!--{if $option[description]}-->
									$option[description]
									<!--{/if}-->
								</div>
								<!--{/if}-->
								<span id="check{$option[identifier]}"></span>
							</li>
							<!--{/loop}-->
							<div class="tedt">

								<div class="area">
									<br/>
									<textarea rows="2" name="message" id="commentmessage{$extname}" tabindex="2" class="pt msg" style="overflow: auto"></textarea>
									<span class="">{lang pn_commentscore:maxlength} <strong id="checklen">{$commentstrmax[$ftsid]}</strong> {lang pn_commentscore:comment_message2}</span>

								</div>

							</div>
						</div>
					</div>
					<div class="o pns cl{if empty($_GET['infloat'])} mtm{/if}">
						<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
					</div>
					<div style="padding:0 10px;">
						<input type="hidden" id="imglistid" value="">

						<button type="submit" id="commentsubmit" class="pnpn" value="true" name="commentsubmit"><span>{lang publish}</span></button>
					</div>
				</form>
			</div>
		</div>
		<div id="append_parent"><div>
			<div id="append_calendar"></div>
			<script type="text/javascript" src="{STATICURL}js/mobile/ajaxfileupload.js?{VERHASH}"></script>
			<script type="text/javascript" src="{STATICURL}js/mobile/buildfileupload.js?{VERHASH}"></script>
			<script type="text/javascript">
				var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png,rar' : imgexts;
				var STATUSMSG = {
					'-1' : '{lang uploadstatusmsgnag1}',
					'0' : '{lang uploadstatusmsg0}',
					'1' : '{lang uploadstatusmsg1}',
					'2' : '{lang uploadstatusmsg2}',
					'3' : '{lang uploadstatusmsg3}',
					'4' : '{lang uploadstatusmsg4}',
					'5' : '{lang uploadstatusmsg5}',
					'6' : '{lang uploadstatusmsg6}',
					'7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
					'8' : '{lang uploadstatusmsg8}',
					'9' : '{lang uploadstatusmsg9}',
					'10' : '{lang uploadstatusmsg10}',
					'11' : '{lang uploadstatusmsg11}'
				};
				var form = $('#postform');

				<!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
				geo.getcurrentposition();
				<!--{/if}-->
				$('#postsubmit').on('click', function() {
					var obj = $(this);
					//if(obj.attr('disable') == 'true') {
					//	return false;
					//}
					<!--{if $_GET[action] == 'newthread' || ($_GET[action] == 'edit' && $isfirstpost)}-->

					if($('#needsubject').val()==''){
						popup.open('{lang pn_mobile_threadtypes:needsubject}', 'alert');
						return false;
					}
					<!--{/if}-->

					if($('#needmessage').val()==''){
						popup.open('{lang pn_mobile_threadtypes:needmessage}', 'alert');

						return false;
					}
					if(!validateextra()){return false;}
					//obj.attr('disable', 'true').removeClass('btn_pn_blue').addClass('btn_pn_grey');
					popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

					var postlocation = '';
					if(geo.errmsg === '' && geo.loc) {
						postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
					}

					$.ajax({
						type:'POST',
						url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
						data:form.serialize(),
						dataType:'xml'
					})
					.success(function(s) {
						popup.open(s.lastChild.firstChild.nodeValue);
					})
					.error(function() {
						popup.open('{lang networkerror}', 'alert');
					});
					return false;
				});

				$(document).on('click', '.del', function() {
					var obj = $(this);
					$.ajax({
						type:'GET',
						url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
					})
					.success(function(s) {
						obj.parent().remove();
					})
					.error(function() {
						popup.open('{lang networkerror}', 'alert');
					});
					return false;
				});

				$(document).on('click', '.del1', function() {
					var obj = $(this);
					$.ajax({
						type:'GET',
						url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
					})
					.success(function(s) {
						obj.parent().remove();
						$('#sortaid_'+obj.attr("imglistid")).val('');
						$('#sortaid_'+obj.attr("imglistid")+'_url').val('');
						$('#sortattachurl_'+obj.attr("imglistid")).val('');

					})
					.error(function() {
						popup.open('{lang networkerror}', 'alert');
					});
					return false;
				});
				$(document).on('change', '#filedata', function() {uploadimge(this)});

				function uploadimge(fileobj) {
					popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

					uploadsuccess = function(data) {
						if(data == '') {
							popup.open('{lang uploadpicfailed}', 'alert');
						}
						var dataarr = data.split('|');
						if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
							if($('#imglistid').val()==''){
								$('#imglist').append('<li><span aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><img src="{STATICURL}image/mobile/images/icon_del.png"></a></span><span class="p_img"><a href="javascript:;"><img style="height:54px;width:54px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
							}else{
								obj = $('#'+$('#imglistid').val()+'del');
								$.ajax({
									type:'GET',
									url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
								})
								.success(function(s) {
									obj.parent().remove();
									$('#sortaid_'+obj.attr("imglistid")).val('');
									$('#sortaid_'+obj.attr("imglistid")+'_url').val('');
									$('#sortattachurl_'+obj.attr("imglistid")).val('');
									$('#'+$('#imglistid').val()+'imglist').append('<li><span id="'+$('#imglistid').val()+'del" imglistid="'+$('#imglistid').val()+'" aid="'+dataarr[3]+'" class="del1"><a href="javascript:;"><img src="{STATICURL}image/mobile/images/icon_del.png"></a></span><span class="p_img"><a href="javascript:;"><img style="height:54px;width:54px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
									$('#sortaid_'+$('#imglistid').val()).val(dataarr[3]);
									$('#sortaid_'+$('#imglistid').val()+'_url').val(dataarr[5]);
									$('#sortattachurl_'+$('#imglistid').val()).val('{$_G[setting][attachurl]}forum/'+dataarr[5]);

								})
								.error(function() {
									popup.open('{lang networkerror}', 'alert');
									return false;
								});
							}
							popup.close();
						} else {
							var sizelimit = '';
							if(dataarr[7] == 'ban') {
								sizelimit = '{lang uploadpicatttypeban}';
							} else if(dataarr[7] == 'perday') {
								sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
							} else if(dataarr[7] > 0) {
								sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
							}
							popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
						}

					};

					if(typeof FileReader != 'undefined' && fileobj.files[0]) {
						$.buildfileupload({
							uploadurl:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
							files:fileobj.files,
							uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
							uploadinputname:'Filedata',
							maxfilesize:"$swfconfig[max]",
							success:uploadsuccess,
							error:function() {
								popup.open('{lang uploadpicfailed}', 'alert');
							}
						});

					} else {
						$.ajaxfileupload({
							url:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
							data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
							dataType:'text',
							fileElementId:'filedata',
							success:uploadsuccess,
							error: function() {
								popup.open('{lang uploadpicfailed}', 'alert');
							}
						});
					}
				}

				function uploadwindow(){
					popup.open('<div class="tip"><input type="file" name="Filedata" id="filedata" style="width:50%;margin-top:60px;"></div>');
				}

			</script>

			<script type="text/javascript" reload="1">
				var scriptarg={{$scriptarg}};
				var iStar={};
				for ( var divid in scriptarg ) {
					initStar(divid);
				}
				function initStar(divid){
					var oStar = document.getElementById(divid+{$extname});
					var aLi = oStar.getElementsByTagName("li");
					var oUl = oStar.getElementsByTagName("ul")[0];
					var i = iScore = iStar = 0;

					for (i = 1; i <= aLi.length; i++)
					{
						aLi[i - 1].index = i;
						aLi[i - 1].onmouseover = function (){
							fnPoint(this.index,divid);
						};
						aLi[i - 1].onmouseout = function (){
							fnPoint('',divid);
						};
						aLi[i - 1].onclick = function (){
							scriptarg[divid] = this.index;
							document.getElementById('typeoption_'+divid).value = this.index;
						}
					}
					function fnPoint(iArg,divid){
						iArg = iArg || scriptarg[divid];
						for (i = 0; i < aLi.length; i++) aLi[i].className = i < iArg ? "on" : "";
					}
				}

				var CHECKALLSORT = false;

				function warning(obj, msg) {
					obj.style.display = '';
					obj.innerHTML = '<img src="{IMGDIR}/check_error.gif" width="16" height="16" class="vm" /> ' + msg;
					obj.className = "warning";
					if(CHECKALLSORT) {
						showDialog(msg);
					}
				}

				//EXTRAFUNC['validator']['special'] = 'validateextra';
				function validateextra() {
					CHECKALLSORT = true;
					<!--{loop $_G['forum_scoreoptionlist'] $optionid $option}-->
					if(!checkoption('$option[identifier]', '$option[required]', '$option[type]')) {
						return false;
					}
					<!--{/loop}-->
					<!--{loop $_G['forum_commentoptionlist'] $optionid $option}-->
					if(!checkoption('$option[identifier]', '$option[required]', '$option[type]')) {
						return false;
					}
					<!--{/loop}-->
					return true;
				}

				<!--{if $_G['forum']['threadsorts']['expiration'][$_G['forum_selectsortid']]}-->
				simulateSelect('typeexpiration');
				<!--{/if}-->

				function mb_strlen(str) {
					var len = 0;
					for(var i = 0; i < str.length; i++) {
						len += str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255 ? (charset == 'utf-8' ? 3 : 2) : 1;
					}
					return len;
				}

				function xmlobj() {
					var obj = new Object();
					obj.createXMLDoc = function(xmlstring) {
						var xmlobj = false;
						if(window.DOMParser && document.implementation && document.implementation.createDocument) {
							try{
								var domparser = new DOMParser();
								xmlobj = domparser.parseFromString(xmlstring, 'text/xml');
							} catch(e) {
							}
						} else if(window.ActiveXObject) {
							var versions = ["MSXML2.DOMDocument.5.0", "MSXML2.DOMDocument.4.0", "MSXML2.DOMDocument.3.0", "MSXML2.DOMDocument", "Microsoft.XmlDom"];
							for(var i=0; i<versions.length; i++) {
								try {
									xmlobj = new ActiveXObject(versions[i]);
									if(xmlobj) {
										xmlobj.async = false;
										xmlobj.loadXML(xmlstring);
									}
								} catch(e) {}
								}
							}
							return xmlobj;
						};

						obj.xml2json = function(xmlobj, node) {
							var nodeattr = node.attributes;
							if(nodeattr != null) {
								if(nodeattr.length && xmlobj == null) {
									xmlobj = new Object();
								}
								for(var i = 0;i < nodeattr.length;i++) {
									xmlobj[nodeattr[i].name] = nodeattr[i].value;
								}
							}
							var nodetext = "text";
							if(node.text == null) {
								nodetext = "textContent";
							}

							var nodechilds = node.childNodes;
							if(nodechilds != null) {
								if(nodechilds.length && xmlobj == null) {
									xmlobj = new Object();
								}
								for(var i = 0;i < nodechilds.length;i++) {
									if(nodechilds[i].tagName != null) {
										if(nodechilds[i].childNodes[0] != null && nodechilds[i].childNodes.length <= 1 && (nodechilds[i].childNodes[0].nodeType == 3 || nodechilds[i].childNodes[0].nodeType == 4)) {
											if(xmlobj[nodechilds[i].tagName] == null) {
												xmlobj[nodechilds[i].tagName] = nodechilds[i][nodetext];
											} else {
												if(typeof(xmlobj[nodechilds[i].tagName]) == "object" && xmlobj[nodechilds[i].tagName].length) {
													xmlobj[nodechilds[i].tagName][xmlobj[nodechilds[i].tagName].length] = nodechilds[i][nodetext];
												} else {
													xmlobj[nodechilds[i].tagName] = [xmlobj[nodechilds[i].tagName]];
													xmlobj[nodechilds[i].tagName][1] = nodechilds[i][nodetext];
												}
											}
										} else {
											if(nodechilds[i].childNodes.length) {
												if(xmlobj[nodechilds[i].tagName] == null) {
													xmlobj[nodechilds[i].tagName] = new Object();
													this.xml2json(xmlobj[nodechilds[i].tagName], nodechilds[i]);
												} else {
													if(xmlobj[nodechilds[i].tagName].length) {
														xmlobj[nodechilds[i].tagName][xmlobj[nodechilds[i].tagName].length] = new Object();
														this.xml2json(xmlobj[nodechilds[i].tagName][xmlobj[nodechilds[i].tagName].length-1], nodechilds[i]);
													} else {
														xmlobj[nodechilds[i].tagName] = [xmlobj[nodechilds[i].tagName]];
														xmlobj[nodechilds[i].tagName][1] = new Object();
														this.xml2json(xmlobj[nodechilds[i].tagName][1], nodechilds[i]);
													}
												}
											} else {
												xmlobj[nodechilds[i].tagName] = nodechilds[i][nodetext];
											}
										}
									}
								}
							}
						};
						return obj;
					}

					var xml = new xmlobj();
					var xmlpar = xml.createXMLDoc(forum_optionlist);
					var forum_optionlist_obj = new Object();
					xml.xml2json(forum_optionlist_obj, xmlpar);

					function changeselectthreadsort(selectchoiceoptionid, optionid, type) {
						if(selectchoiceoptionid == '0') {
							return;
						}
						var soptionid = 's' + optionid;
						var sselectchoiceoptionid = 's' + selectchoiceoptionid;

						forum_optionlist = forum_optionlist_obj['forum_optionlist'];
						var choicesarr = forum_optionlist[soptionid]['schoices'];
						var lastcount = 1;
						var name = issearch = id = nameid = '';
						if(type == 'search') {
							issearch = ', \'search\'';
							name = ' name="searchoption[' + optionid + '][value]"';
							id = 'id="' + forum_optionlist[soptionid]['sidentifier'] + '"';
						} else {
							name = ' name="typeoption[' + forum_optionlist[soptionid]['sidentifier'] + ']"';
							id = 'id="typeoption_' + forum_optionlist[soptionid]['sidentifier'] + '"';
						}
						if((choicesarr[sselectchoiceoptionid]['slevel'] == 1 || type == 'search') && choicesarr[sselectchoiceoptionid]['scount'] == 1) {
							nameid = name + ' ' + id;
						}
						var selectoption = '<select' + nameid + ' class="ps vm" onchange="changeselectthreadsort(this.value, \'' + optionid + '\',\'' + type + '\');checkoption(\'' + forum_optionlist[soptionid]['sidentifier'] + '\', \'' + forum_optionlist[soptionid]['srequired'] + '\', \'' + forum_optionlist[soptionid]['stype'] + '\')" ' + ((forum_optionlist[soptionid]['sunchangeable'] == 1 && type == 'update') ? 'disabled' : '') + '><option value="0">&#x8BF7;&#x9009;&#x62E9;</option>';
						for(var i in choicesarr) {
							nameid = '';
							if((choicesarr[sselectchoiceoptionid]['slevel'] == 1 || type == 'search') && choicesarr[i]['scount'] == choicesarr[sselectchoiceoptionid]['scount']) {
								nameid = name + ' ' + id;
							}
							if(choicesarr[i]['sfoptionid'] != '0') {
								var patrn1 = new RegExp("^" + choicesarr[i]['sfoptionid'] + "\\.", 'i');
								var patrn2 = new RegExp("^" + choicesarr[i]['sfoptionid'] + "$", 'i');
								if(selectchoiceoptionid.match(patrn1) == null && selectchoiceoptionid.match(patrn2) == null) {
									continue;
								}
							}
							if(choicesarr[i]['scount'] != lastcount) {
								if(parseInt(choicesarr[i]['scount']) >= (parseInt(choicesarr[sselectchoiceoptionid]['scount']) + parseInt(choicesarr[sselectchoiceoptionid]['slevel']))) {
									break;
								}
								selectoption += '</select>' + "\r\n" + '<select' + nameid + ' class="ps vm" onchange="changeselectthreadsort(this.value, \'' + optionid + '\',\'' + type + '\');checkoption(\'' + forum_optionlist[soptionid]['sidentifier'] + '\', \'' + forum_optionlist[soptionid]['srequired'] + '\', \'' + forum_optionlist[soptionid]['stype'] + '\')" ' + ((forum_optionlist[soptionid]['sunchangeable'] == 1 && type == 'update') ? 'disabled' : '') + '><option value="0">请选择</option>';

								lastcount = parseInt(choicesarr[i]['scount']);
							}
							var patrn1 = new RegExp("^" + choicesarr[i]['soptionid'] + "\\.", 'i');
							var patrn2 = new RegExp("^" + choicesarr[i]['soptionid'] + "$", 'i');
							var isnext = '';
							if(parseInt(choicesarr[i]['slevel']) != 1) {
								isnext = '&raquo;';
							}
							if(type == 'update' ){
								if(selectchoiceoptionid.match(patrn1) != null || selectchoiceoptionid.match(patrn2) != null) {
									selectoption += "\r\n" + '<option value="' + choicesarr[i]['soptionid'] + '" selected="selected">' + choicesarr[i]['scontent']['scontent'] + isnext + '</option>';
								} else {
									selectoption += "\r\n" + '<option value="' + choicesarr[i]['soptionid'] + '">' + choicesarr[i]['scontent']['scontent'] + isnext + '</option>';
								}
							}else{
								if(selectchoiceoptionid.match(patrn1) != null || selectchoiceoptionid.match(patrn2) != null) {
									selectoption += "\r\n" + '<option value="' + choicesarr[i]['soptionid'] + '" selected="selected">' + choicesarr[i]['scontent'] + isnext + '</option>';
								} else {
									selectoption += "\r\n" + '<option value="' + choicesarr[i]['soptionid'] + '">' + choicesarr[i]['scontent'] + isnext + '</option>';
								}


							}
						}
						selectoption += '</select>';
						if(type == 'search') {
							selectoption  += "\r\n" + '<input type="hidden" name="searchoption[' + optionid + '][type]" value="select">';
						}
						document.getElementById('select_' + forum_optionlist[soptionid]['sidentifier']).innerHTML = selectoption;
					}

					function checkoption(identifier, required, checktype, checkmaxnum, checkminnum, checkmaxlength) {
						if(checktype != 'image' && checktype != 'select' && !document.getElementById('typeoption_' + identifier) || !document.getElementById('check' + identifier)) {
							return true;
						}

						var ce = document.getElementById('check' + identifier);
						ce.innerHTML = '';

						if(checktype == 'select') {
							if(required != '0' && (document.getElementById('typeoption_' + identifier) == null || document.getElementById('typeoption_' + identifier).value == '0')) {
								warning(ce, '&#x5FC5;&#x586B;&#x9879;&#x76EE;&#x6CA1;&#x6709;&#x586B;&#x5199;');
								return false;
							} else if(required == '0' && (document.getElementById('typeoption_' + identifier) == null || document.getElementById('typeoption_' + identifier).value == '0')) {
								ce.innerHTML = '<img src="' + IMGDIR + '/check_error.gif" width="16" height="16" class="vm" /> &#x8BF7;&#x9009;&#x62E9;&#x4E0B;&#x4E00;&#x7EA7;';
								ce.className = "warning";
								return true;
							}
						}

						if(checktype == 'radio' || checktype == 'checkbox') {
							var nodes = document.getElementById('typeoption_' + identifier).parentNode.parentNode.parentNode.getElementsByTagName('INPUT');
							var nodechecked = false;
							for(var i=0; i<nodes.length; i++) {
								if(nodes[i].id == 'typeoption_' + identifier) {
									if(nodes[i].checked) {
										nodechecked = true;
									}
								}
							}
							if(!nodechecked && required != '0') {
								warning(ce, '&#x5FC5;&#x586B;&#x9879;&#x76EE;&#x6CA1;&#x6709;&#x586B;&#x5199;');
								return false;
							}
						}

						if(checktype == 'image') {
							var checkvalue = document.getElementById('sortaid_' + identifier).value;
						} else {
							var checkvalue = document.getElementById('typeoption_' + identifier).value;
						}

						if(required != '0') {
							if(checkvalue == '') {
								warning(ce, '&#x5FC5;&#x586B;&#x9879;&#x76EE;&#x6CA1;&#x6709;&#x586B;&#x5199;');
								return false;
							} else {
								ce.innerHTML = '<img src="' + IMGDIR + '/check_right.gif" width="16" height="16" class="vm" />';
							}
						}

						if(checkvalue) {
							if(checktype == 'email' && !(/^[\-\.\w]+@[\.\-\w]+(\.\w+)+$/.test(checkvalue))) {
								warning(ce, '&#x90AE;&#x4EF6;&#x5730;&#x5740;&#x4E0D;&#x6B63;&#x786E;');
								return false;
							} else if((checktype == 'text' || checktype == 'textarea') && checkmaxlength != '0' && mb_strlen(checkvalue) > checkmaxlength) {
								warning(ce, '&#x586B;&#x5199;&#x9879;&#x76EE;&#x957F;&#x5EA6;&#x8FC7;&#x957F;');
								return false;
							} else if((checktype == 'number' || checktype == 'range')) {
								if(isNaN(checkvalue)) {
									warning(ce, '&#x6570;&#x5B57;&#x586B;&#x5199;&#x4E0D;&#x6B63;&#x786E;');
									return false;
								} else if(checkmaxnum != '0' && parseInt(checkvalue) > parseInt(checkmaxnum)) {
									warning(ce, '&#x5927;&#x4E8E;&#x8BBE;&#x7F6E;&#x6700;&#x5927;&#x503C;');
									return false;
								} else if(checkminnum != '0' && parseInt(checkvalue) < parseInt(checkminnum)) {
									warning(ce, '&#x5C0F;&#x4E8E;&#x8BBE;&#x7F6E;&#x6700;&#x5C0F;&#x503C;');
									return false;
								}
							} else if(checktype == 'url' && !(/(http[s]?|ftp):\/\/[^\/\.]+?\..+\w[\/]?$/i.test(checkvalue))) {
								warning(ce, '&#x8BF7;&#x6B63;&#x786E;&#x586B;&#x5199;&#x4EE5;http://&#x5F00;&#x5934;&#x7684;URL&#x5730;&#x5740;');
								return false;
							}
							ce.innerHTML = '<img src="' + IMGDIR + '/check_right.gif" width="16" height="16" class="vm" />';
						}
						return true;
					}

					function obj2string(o){
						var r=[];
						if(typeof o=="string"){
							return "\""+o.replace(/([\'\"\\])/g,"\\$1").replace(/(\n)/g,"\\n").replace(/(\r)/g,"\\r").replace(/(\t)/g,"\\t")+"\"";
						}
						if(typeof o=="object"){
							if(!o.sort){
								for(var i in o){
									r.push(i+":"+obj2string(o[i]));
								}
								if(!!document.all&&!/^\n?function\s*toString\(\)\s*\{\n?\s*\[native code\]\n?\s*\}\n?\s*$/.test(o.toString)){
									r.push("toString:"+o.toString.toString());
								}
								r="{"+r.join()+"}";
							}else{
								for(var i=0;i<o.length;i++){
									r.push(obj2string(o[i]))
								}
								r="["+r.join()+"]";
							}
							return r;
						}
						return o.toString();
					}



				</script>


				<!--{eval $nofooter = true;}-->
				<!--{template common/footer}-->