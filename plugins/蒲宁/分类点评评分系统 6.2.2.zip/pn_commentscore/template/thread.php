<?php exit;?>

{eval
function tpl_pn_commentsocre_forumdisplay_filter_extra_output($scoreidentifier,$commentsearch,$sfiltername,$cfiltername) {
}
{eval global $_G;}
<!--{block return}-->
<!--{if $scoreidentifier}-->
<a id="filter_score" href="javascript:;" class="showmenu xi2{if in_array($_GET['orderby'],$scoreidentifier)} xw1{/if}" onclick="showMenu(this.id)">{if $sfiltername}$sfiltername{else}{lang pn_commentscore:scorefilter}{/if}</a>&nbsp;
<!--{/if}-->
<!--{loop $commentsearch $option}-->
<a id="filter_{$option[identifier]}" href="javascript:;" class="showmenu xi2{if $_GET[''.$option[identifier]]} xw1{/if}" onclick="showMenu(this.id)">{if $cfiltername[$option[identifier]]}$cfiltername[$option[identifier]]{else}$option[title]{/if}</a>&nbsp;
<!--{/loop}-->

<!--{/block}-->
{eval return $return;}

{eval
}
function tpl_pn_commentsocre_forumdisplay_top_output($scoresearch,$commentsearch,$c_sorturladdarray,$allurladd) {
}
{eval global $_G;}
<!--{block return}-->
<div id="filter_score_menu" class="p_pop" style="display:none" change="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter='+$('filter_special').value">
	<ul>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort$allurladd" class="xi2">{lang default}</a></li>

		<!--{loop $scoresearch $option}-->
		<li{if isset($_GET['orderby'])&&$_GET['orderby']=$option[identifier]} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G['fid']&filter=scsort&orderby=$option[identifier]$allurladd">$option[title]</a></li>
		<!--{/loop}-->
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&orderby=numasc$allurladd" class="xi2{if $_GET['filter'] == 'lastpost'} xw1{/if}">{lang pn_commentscore:numasc}</a></li>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&orderby=numdesc$allurladd" class="xi2{if $_GET['filter'] == 'lastpost'} xw1{/if}">{lang pn_commentscore:numdesc}</a></li>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&orderby=lastpost$allurladd" class="xi2{if $_GET['filter'] == 'lastpost'} xw1{/if}">{lang pn_commentscore:latest}</a></li>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&orderby=heats$forumdisplayadd[heat]$allurladd" class="xi2{if $_GET['filter'] == 'heat'} xw1{/if}">{lang pn_commentscore:order_heats}</a></li>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&digest=1$forumdisplayadd[digest]$allurladd" class="xi2{if $_GET['filter'] == 'digest'} xw1{/if}">{lang pn_commentscore:digest_posts}</a></li>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&orderby=replies$forumdisplayadd[reply]$allurladd" {if $_GET['orderby'] == 'replies'}class="xw1"{/if}>{lang pn_commentscore:replies}</a></li>
		<li{if !isset($_GET[orderby])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&orderby=views$forumdisplayadd[view]$allurladd" {if $_GET['orderby'] == 'views'}class="xw1"{/if}>{lang pn_commentscore:views}</a></li>
	</ul>
</div>
<!--{loop $commentsearch $optionid $option}-->
<div id="filter_{$option[identifier]}_menu" class="p_pop" style="display:none" change="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter='+$('filter_special').value">
	<ul>
		<li{if !isset($_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&$option[identifier]=all$c_sorturladdarray[$option[identifier]]" class="xi2">{lang pn_commentscore:unlimited}</a></li>
		<!--{if $option[type] == 'select'}-->
		<!--{loop $option[choices] $id $value}-->
		<!--{if $value[foptionid] == 0}-->
		<li{if preg_match('/^'.$value[optionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[optionid].'$/i', $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&$option[identifier]=$id$c_sorturladdarray[$option[identifier]]" class="xi2">$value[content]</a></li>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{if !($_GET[''.$option[identifier]] == 'all' || !isset($_GET[''.$option[identifier]]))}-->
		<!--{loop $option[choices] $id $value}-->
		<!--{if (preg_match('/^'.$value[foptionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[foptionid].'$/i', $_GET[''.$option[identifier]])) && ($showoption[$value[count]][$id] = $value)}-->
		<!--{/if}-->
		<!--{/loop}-->
		<!--{if ksort($showoption)}--><!--{/if}-->
		<!--{loop $showoption $optioncount $values}-->
		<!--{if $tmpcount != $optioncount && ($tmpcount = $optioncount)}-->
	</ul><ul class="subtsm cl">
		<!--{loop $values $id $value}-->
		<li{if preg_match('/^'.$value[optionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[optionid].'$/i', $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&$option[identifier]=$id$c_sorturladdarray[$option[identifier]]" class="xi2">$value[content]</a></li>
		<!--{/loop}-->
	</ul><ul>
		<!--{/if}-->
		<!--{/loop}-->
		<!--{/if}-->
		<!--{else}-->
		<!--{loop $option[choices] $id $value}-->
		<li{if $_GET[''.$option[identifier]] && !strcmp($id, $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=scsort&$option[identifier]=$id$c_sorturladdarray[$option[identifier]]" class="xi2">$value</a></li>
		<!--{/loop}-->
		<!--{/if}-->
	</ul>
</div>
<!--{/loop}-->

<!--{/block}-->
{eval return $return;}


{eval
}
function tpl_pn_commentsocre_viewthread_beginline_output($functionname, $showtype, $othervalue) {
}
{eval global $_G;}

<!--{if $functionname=='commentshow'}-->
<!--{block return}-->
<!--{if $showtype=='pc'}-->
<table cellspacing="0"  class="comment cgtl mbm"><tbody>
	<!--{loop $_G[pn_comment_option] $key $option}-->
	<!--{if $option[type] != 'info'}-->
	<tr id="{$key}"><th>{$option[title]}&nbsp;:&nbsp;</th><td>
		<!--{if $option[value] || ($option[type] == 'number' && $option[value] !== '')}-->
		{$option[value]} {$option[unit]}
		<!--{else}-->
		-
		<!--{/if}-->
	</td></tr>
	<!--{/if}-->
	<!--{/loop}-->
</tbody></table>
<!--{elseif $showtype=='mobile'}-->
<div class="box box_ex2 viewsort viewcomment" id="{$key}">
	<!--{loop $_G[pn_comment_option]  $option}-->
	<!--{if $option[type] != 'info'}-->
	{$option[title]}&nbsp;:&nbsp;
	<!--{if $option[value] || ($option[type] == 'number' && $option[value] !== '')}-->
	{$option[value]} {$option[unit]}
	<!--{else}-->
	-
	<!--{/if}-->
	<br>
	<!--{/if}-->
	<!--{/loop}-->
</div>
<!--{/if}-->

<!--{elseif $functionname=='scoreshow'}-->
<div class="starnum">
	<div class="stars">
		<!--{loop $_G[pn_score_option] $key $option}-->
		<!--{if $option[type]=='range'}-->
		<div class="sstar" id="{$key}"><dl><dt>{$option[title]}&nbsp;:&nbsp;</dt><dl>
			{$option[value]}
		</dl></dl></div>
		<!--{/if}-->
		<!--{/loop}-->
	</div>
	<div class="snums">
		<!--{loop $_G[pn_score_option] $key $option}-->
		<!--{if $option[type]=='number'}-->
		<div class="snum" id="{$key}"><dl><dt>{$option[title]}&nbsp;:&nbsp;</dt><dl>
			{$option[value]}
		</dl></dl></div>
		<!--{/if}-->
		<!--{/loop}-->
	</div>
</div>

<!--{elseif $functionname=='scthreadshowcomment'}-->
<div id="tcomment"><div class="tranges">
	<!--{loop $_G[pn_comment_option] $key $option}-->
	<!--{if $option[type]=='range'}-->
	<div class="trange" id="{$key}"><dl><dt>{$option[title]}&nbsp;:&nbsp;</dt><dl><dl>
		<dd class="trangevalue">{$option[value]} {$option[unit]}</dd>
	</dl></dl></dl></div>
	<!--{/if}-->
	<!--{/loop}-->
</div></div>

<!--{elseif $functionname=='scthreadshowtotal'}-->
<div id="scorecount">
(<em>{$othervalue}</em>  {lang pn_commentscore:totalnum})
</div>
<!--{/if}-->
<!--{/block}-->

{eval return $return;}
{eval
}
}

{eval
function tpl_pn_commentsocre_diythreads($threadlist,$scorecomments,$tdstyle,$picwidth=216,$picheight=198) {
}
{eval global $_G;}
<!--{block return}-->
	<!--{if $tdstyle==1}-->
<div class="module cl xl xl1"> <ul> <!--{loop $threadlist $thread}--> <li><p>{$scorecomments[$thread['tid']]}</p><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></li> <!--{/loop}--> </ul> </div>
<!--{elseif $tdstyle==2}-->

<div class="module cl xl xl1"> <ul> <!--{loop $threadlist $thread}--> <li><p>{$scorecomments[$thread['tid']]}</p><em>{$thread['replies']}</em><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></li> <!--{/loop}--> </ul> </div>
<!--{elseif $tdstyle==3}-->

<div class="module cl xl xl1"> <ul> <!--{loop $threadlist $thread}--> <li><p>{$scorecomments[$thread['tid']]}</p><em>{$thread['views']}</em><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></li> <!--{/loop}--> </ul> </div>
<!--{elseif $tdstyle==4}-->

<div class="module cl xl xl1"> <ul> <!--{loop $threadlist $thread}--> <li><p>{$scorecomments[$thread['tid']]}</p><em>{$thread['heats']}</em><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></li> <!--{/loop}--> </ul> </div>
<!--{elseif $tdstyle==5}-->

<div class="module cl xl xl1"> <ul> <!--{loop $threadlist $thread}--> <li><p>{$scorecomments[$thread['tid']]}</p><em>{$thread['dateline']}</em><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></li> <!--{/loop}--> </ul> </div>
<!--{elseif $tdstyle==6}-->

<div class="module cl xl xl1"> <ul> <!--{loop $threadlist $thread}--> <li><p>{$scorecomments[$thread['tid']]}</p><em>{$thread['lastpost']}</em><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></li> <!--{/loop}--> </ul> </div>
<!--{elseif $tdstyle==7}-->

<div class="module cl xl xl1"> <ul> <!--{loop $threadlist $thread}--> <li><p>{$scorecomments[$thread['tid']]}</p><em><a href="home.php?mod=space&uid={thread['authorid']}">{$thread['author']}</a></em><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></li> <!--{/loop}--> </ul> </div>
<!--{elseif $tdstyle==8}-->

<div class="module cl xld"> <!--{loop $threadlist $thread}--><p>{$scorecomments[$thread['tid']]}</p> <dl class="cl"> <dt><em class="y xg1 xw0"><a href="home.php?mod=space&uid={thread['authorid']}">{$thread['author']}</a></em><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></dt> <dd>{$thread['summary']}</dd> </dl> <!--{/loop}--> </div>
<!--{elseif $tdstyle==9}-->

<div class="module cl xld"> <!--{loop $threadlist $thread}--> <p>{$scorecomments[$thread['tid']]}</p><dl class="cl"> <dt><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></dt> <dd>{$thread['summary']}</dd> </dl> <!--{/loop}--> </div>
<!--{elseif $tdstyle==10}-->

<div class="module cl xld fcs"> <!--{loop $threadlist $thread}--><p>{$scorecomments[$thread['tid']]}</p> <dl class="cl"> <dt><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></dt> <dd>{$thread['summary']}</dd> </dl> <!--{/loop}--> </div>
<!--{elseif $tdstyle==11}-->

<div class="module cl xl"> <ul> <!--{loop $threadlist $thread}--> <li><p>{$scorecomments[$thread['tid']]}</p><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></li> <!--{/loop}--> [order=1] <li> <dl class="cl xld"> <dt><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></dt> <dd>{$thread['summary']}</dd> </dl> <hr class="da" /> </li> [/order] </ul> </div>
<!--{elseif $tdstyle==12}-->

<!--{elseif $tdstyle==13}-->

<div class="module cl xl xl1"> <ul> <!--{loop $threadlist $thread}--> <li><p>{$scorecomments[$thread['tid']]}</p><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a>{$thread['summary']}</li> <!--{/loop}--> </ul> </div>
<!--{elseif $tdstyle==14}-->

<div class="module cl xld"> <!--{loop $threadlist $thread}--> <dl><p>{$scorecomments[$thread['tid']]}</p> <dd style="margin-bottom: 0; font-size: 12px; color: #369">{$thread['author']} &#8250;</dd> <dt style="padding: 0;"><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></dt> <dd style="margin-bottom: 0;">{$thread['summary']}</dd> </dl> <!--{/loop}--> </div>
<!--{elseif $tdstyle==15}-->

<div class="module cl xld b_poll"> <!--{loop $threadlist $thread}--> <dl><p>{$scorecomments[$thread['tid']]}</p> <dt class="xs2"><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></dt> <dd>{$thread['summary']}</dd> </dl> <!--{/loop}--> </div>
<!--{elseif $tdstyle==16}-->

<div class="module cl xld b_debate"> <!--{loop $threadlist $thread}--> <dl><p>{$scorecomments[$thread['tid']]}</p> <dt class="xs2"><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></dt> <dd>{$thread['summary']}</dd> </dl> <!--{/loop}--> </div>
<!--{elseif $tdstyle==17}-->

<div class="module cl xld"> <!--{loop $threadlist $thread}--> <dl class="cl"><p>{$scorecomments[$thread['tid']]}</p> <dd class="m"><a href="{$thread['url']}"><img src="data/attachment/forum/{$thread['pic']}" width="{$picwidth}" height="{$picheight}" alt="{$thread['subject']}" /></a></dd> <dt><em class="y xg1 xw0"><a href="home.php?mod=space&uid={thread['authorid']}">{$thread['author']}</a></em><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></dt> <dd>{$thread['summary']}</dd> </dl> <!--{/loop}--> </div>
<!--{elseif $tdstyle==18}-->

<div class="bm bw0"> [index=1] <dl class="cl xld"><p>{$scorecomments[$thread['tid']]}</p> <dt><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></dt> <dd>{$thread['summary']}</dd> </dl> <hr class="da" /> [/index] <ul class="xl xl2 cl"> <!--{loop $threadlist $thread}--><li><a href="{$thread['url']}" title="{$thread['subject']}">{$thread['subject']}</a></li><!--{/loop}--> </ul> </div>
<!--{elseif $tdstyle==19}-->

<div class="module cl slidebox"> <ul class="slideshow"> <!--{loop $threadlist $thread}--> <li style="width: {$picwidth}px; height: {$picheight}px;"><a href="{$thread['url']}"><img src="data/attachment/forum/{$thread['pic']}" width="{$picwidth}" height="{$picheight}" /></a><span class="title"><p>{$scorecomments[$thread['tid']]}</p>{$thread['subject']}</span></li> <!--{/loop}--> </ul> </div> <script type="text/javascript"> runslideshow(); </script>
<!--{elseif $tdstyle==20}-->

<div class="module cl ml"> <ul> <!--{loop $threadlist $thread}--> <li style="width: {$picwidth}px;"> <a href="{$thread['url']}"><img src="data/attachment/forum/{$thread['pic']}" width="{$picwidth}" height="{$picheight}" alt="{$thread['subject']}" /></a> <p><a href="{$thread['url']}" title="{$thread['subject']}"><p>{$scorecomments[$thread['tid']]}</p>{$thread['subject']}</a></p> </li> <!--{/loop}--> </ul> </div>
<!--{/if}-->

<!--{/block}-->
{eval return $return;}

{eval
}
}


