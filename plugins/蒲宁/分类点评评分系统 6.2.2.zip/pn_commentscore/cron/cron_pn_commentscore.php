<?php
/**
*	[�������ֵ������(pn_commentscore)] [DisM!] (C)2001-2099 DisM Inc.
*	Version: 1.0
*	Date: 2019-10-19 19:00
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$blocks = DB::fetch_all('SELECT * FROM %t WHERE 1=1', array('plugin_pn_commentscore_diy',$noticetime));
include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/diy.func.php';

foreach($blocks as $block){
	$_GET=unserialize($block['getvalue']);
	updiy($_GET);
}
//From: Dism_taobao_com
?>