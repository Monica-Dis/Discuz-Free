<?php
/**
*	[分类评分点评插件(pn_commentscore)] [DisM!] (C)2001-2099 DisM Inc.
*	Version: 1.0
*	Date: 2013-12-8 20:00
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function commentshow($sortid, $pids, $tid, $showtype='pc') {
	global $_G;
	include_once libfile('function/threadsort');
	$sortoptionarray=array();
	loadcache(array('threadsort_option_'.$sortid, 'threadsort_template_'.$sortid));
	$sortoptionarray = $_G['cache']['threadsort_option_'.$sortid];
	$templatearray = $_G['cache']['threadsort_template_'.$sortid];
	if($sortoptionarray) {
		$comments = $optiondata = $searchtitle = $searchvalue = $searchunit = $memberinfofield = $_G['pn_comment_option'] = array();
		$pidstr=implode(',', $pids) ;
		$pidstr&&$commentposts = DB::fetch_all("SELECT pid,comment FROM ".DB::table('plugin_pn_commentscore_post')." WHERE pid in ($pidstr)");
		$_G['pn_comment_option']=array();

		foreach($commentposts as $post){
			$comment = unserialize($post['comment']);
			if($comment){
				$pid = $post['pid'];
				foreach($comment as $id => $option) {
					$optiondata[$id]['value'] = $option;
					$optiondata[$id]['expiration'] = 0;
				}
				$sortdataexpiration = 0;

				foreach($sortoptionarray as $optionid => $option) {
					$_G['pn_comment_option'][$option['identifier']]['title'] = $option['title'];
					$_G['pn_comment_option'][$option['identifier']]['unit'] = $option['unit'];
					$_G['pn_comment_option'][$option['identifier']]['type'] = $option['type'];
					if(($option['expiration'] && !$optiondata[$optionid]['expiration']) || empty($option['expiration'])) {
						if(!protectguard($option['protect'])) {
							if($option['type'] == 'checkbox') {
								$_G['pn_comment_option'][$option['identifier']]['value'] = '';
								foreach(explode("\t", $optiondata[$optionid]['value']) as $choiceid) {
									$_G['pn_comment_option'][$option['identifier']]['value'] .= $option['choices'][$choiceid].'&nbsp;';
								}
							} elseif($option['type'] == 'radio') {
								$_G['pn_comment_option'][$option['identifier']]['value'] = $option['choices'][$optiondata[$optionid]['value']];
							} elseif($option['type'] == 'select') {
								$tmpchoiceid = $tmpidentifiervalue = array();
								foreach(explode('.', $optiondata[$optionid]['value']) as $choiceid) {
									$tmpchoiceid[] = $choiceid;
									$tmpidentifiervalue[] = $option['choices'][implode('.', $tmpchoiceid)];
								}
								$_G['pn_comment_option'][$option['identifier']]['value'] = implode(' &raquo; ', $tmpidentifiervalue);
								unset($tmpchoiceid, $tmpidentifiervalue);
							} elseif($option['type'] == 'image') {
								$imgoptiondata = dunserialize($optiondata[$optionid]['value']);
								$comments[$pid]['sortaids'][] = $imgoptiondata['aid'];
								if(empty($templatearray['viewthread'])) {
									$maxwidth = $option['maxwidth'] ? 'width="'.$option['maxwidth'].'"' : '';
									$maxheight = $option['maxheight'] ? 'height="'.$option['maxheight'].'"' : '';
									if(!defined('IN_MOBILE')) {
										$_G['pn_comment_option'][$option['identifier']]['value'] = $imgoptiondata['url'] ? "<img src=\"".$imgoptiondata['url']."\" onload=\"thumbImg(this)\" $maxwidth $maxheight border=\"0\">" : '';
									} else {
										$_G['pn_comment_option'][$option['identifier']]['value'] = $imgoptiondata['url'] ? "<a href=\"".$imgoptiondata['url']."\" target=\"_blank\">".lang('forum/misc', 'click_view')."</a>" : '';
									}
								} else {
									$_G['pn_comment_option'][$option['identifier']]['value'] = $imgoptiondata['url'] ? $imgoptiondata['url'] : './static/image/common/nophoto.gif';
								}
							} elseif($option['type'] == 'url') {
								$_G['pn_comment_option'][$option['identifier']]['value'] = $optiondata[$optionid]['value'] ? "<a href=\"".$optiondata[$optionid]['value']."\" target=\"_blank\">".$optiondata[$optionid]['value']."</a>" : '';
							} elseif($option['type'] == 'number') {
								$_G['pn_comment_option'][$option['identifier']]['value'] = $optiondata[$optionid]['value'];
							} else {
								if($option['protect']['status'] && $optiondata[$optionid]['value']) {
									$optiondata[$optionid]['value'] = $option['protect']['mode'] == 1 ? '<image src="'.stringtopic($optiondata[$optionid]['value']).'">' : (!defined('IN_MOBILE') ? '<span id="sortmessage_'.$option['identifier'].'"><a href="###" onclick="ajaxget(\'forum.php?mod=misc&action=protectsort&tid='.$tid.'&optionid='.$optionid.'\', \'sortmessage_'.$option['identifier'].'\');return false;">'.lang('forum/misc', 'click_view').'</a></span>' : $optiondata[$optionid]['value']);
									$_G['pn_comment_option'][$option['identifier']]['value'] = $optiondata[$optionid]['value'] ? $optiondata[$optionid]['value'] : $option['defaultvalue'];
								} elseif($option['type'] == 'textarea') {
									$_G['pn_comment_option'][$option['identifier']]['value'] = $optiondata[$optionid]['value'] ? nl2br($optiondata[$optionid]['value']) : '';
								} else {
									$_G['pn_comment_option'][$option['identifier']]['value'] = $optiondata[$optionid]['value'] ? $optiondata[$optionid]['value'] : $option['defaultvalue'];
								}
							}
						} else {
							if(empty($option['permprompt'])) {
								$_G['pn_comment_option'][$option['identifier']]['value'] = lang('forum/misc', 'view_noperm');
							} else {
								$_G['pn_comment_option'][$option['identifier']]['value'] = $option['permprompt'];
							}

						}
					} else {
						$_G['pn_comment_option'][$option['identifier']]['value'] = lang('forum/misc', 'has_expired');
					}
				}

				$typetemplate = '';
				if($templatearray['viewthread']) {
					foreach($sortoptionarray as $option) {
						$searchtitle[] = '/{('.$option['identifier'].')}/e';
						$searchvalue[] = '/\[('.$option['identifier'].')value\]/e';
						$searchvalue[] = '/{('.$option['identifier'].')_value}/e';
						$searchunit[] = '/\[('.$option['identifier'].')unit\]/e';
						$searchunit[] = '/{('.$option['identifier'].')_unit}/e';
					}

					$threadexpiration = $sortdataexpiration ? dgmdate($sortdataexpiration) : lang('forum/misc', 'never_expired');
					$template=explode('<!---->',$templatearray['viewthread']);
					$typetemplate = preg_replace(array("/\{expiration\}/i"), array($threadexpiration), stripslashes($template[1]));
					$typetemplate = preg_replace($searchtitle, "showscoption('\\1', 'title','comment')", $typetemplate);
					$typetemplate = preg_replace($searchvalue, "showscoption('\\1', 'value','comment')", $typetemplate);
					$typetemplate = preg_replace($searchunit, "showscoption('\\1', 'unit','comment')", $typetemplate);
					if($typetemplate){
						$comments[$pid] = $typetemplate;
					}
				}else{
					if($showtype=='mobile'){
						$comments[$pid] =tpl_pn_commentsocre_viewthread_beginline_output('commentshow','mobile','');
					}else{
						$comments[$pid] =tpl_pn_commentsocre_viewthread_beginline_output('commentshow','pc','');
					}
				}
			}
		}
	}
	return $comments;
}

function scoreshow($sortid,$pids,$tid,$scorecount){
	global $_G;
	$scores=$score=$sortoptionarray=array();

	loadcache(array('threadsort_option_'.$sortid, 'threadsort_template_'.$sortid));
	$sortoptionarray = $_G['cache']['threadsort_option_'.$sortid];
	$templatearray = $_G['cache']['threadsort_template_'.$sortid];
	$tscorepost = DB::fetch_first("SELECT pid,scorenum,commentnum FROM ".DB::table('plugin_pn_commentscore_thread')." WHERE tid='$tid'");
	$tpid=$tscorepost['pid'];

	$pidstr=implode(',', $pids) ;

	$pidstr&&$scorepost = DB::fetch_all("SELECT pid,score FROM ".DB::table('plugin_pn_commentscore_post')." WHERE pid in ($pidstr)");
	foreach($scorepost as $post){
		$score = unserialize($post['score']);
		if($score){
			$pid = $post['pid'];
			foreach($score as $id => $option) {
				$optiondata[$id]['value'] = $option;
				$optiondata[$id]['expiration'] = 0;
			}
			$sortdataexpiration = 0;
			$_G['pn_score_option']=array();

			foreach($sortoptionarray as $optionid => $option) {
				$_G['pn_score_option'][$option['identifier']]['title'] = $option['title'];
				$_G['pn_score_option'][$option['identifier']]['unit'] = $option['unit'];
				$_G['pn_score_option'][$option['identifier']]['type'] = $option['type'];
				if(($option['expiration'] && !$optiondata[$optionid]['expiration']) || empty($option['expiration'])) {
					if(!protectguard($option['protect'])) {
						$html='';
						if($option['type']=='range'){
							for($i=1;$i<=$option['maxnum'];$i++){
								if($i<=$optiondata[$optionid]['value']){
									$html.='<dd class="bstar">'.$i.'</dd>';
								}else{
									$html.='<dd class="dstar">'.$i.'</dd>';
								}
							}
							$html='<dl>'.$html.'</dl>';
						}elseif($option['type']=='number'){
							$html='<dl><dd class="bnum">'.round($optiondata[$optionid]['value']*$scorecount/$option['maxnum'],1).'</dd></dl>';
						}
						$_G['pn_score_option'][$option['identifier']]['value']=$html;
					} else {
						if(empty($option['permprompt'])) {
							$_G['pn_score_option'][$option['identifier']]['value'] = lang('forum/misc', 'view_noperm');
						} else {
							$_G['pn_score_option'][$option['identifier']]['value'] = $option['permprompt'];
						}

					}
				} else {
					$_G['pn_score_option'][$option['identifier']]['value'] = lang('forum/misc', 'has_expired');
				}

			}

			$typetemplate = $html ='';
			if($templatearray['viewthread']) {
				foreach($sortoptionarray as $option) {
					$searchtitle[] = '/{('.$option['identifier'].')}/e';
					$searchvalue[] = '/\[('.$option['identifier'].')value\]/e';
					$searchvalue[] = '/{('.$option['identifier'].')_value}/e';
					$searchunit[] = '/\[('.$option['identifier'].')unit\]/e';
					$searchunit[] = '/{('.$option['identifier'].')_unit}/e';
				}

				$threadexpiration = $sortdataexpiration ? dgmdate($sortdataexpiration) : lang('forum/misc', 'never_expired');
				$template=explode('<!---->',$templatearray['viewthread']);

				$typetemplate = preg_replace(array("/\{expiration\}/i"), array($threadexpiration), stripslashes($template[1]));
				$typetemplate = preg_replace($searchtitle, "showscoption('\\1', 'title' ,'score')", $typetemplate);
				$typetemplate = preg_replace($searchvalue, "showscoption('\\1', 'value','score')", $typetemplate);
				$typetemplate = preg_replace($searchunit, "showscoption('\\1', 'unit','score')", $typetemplate);
				if($typetemplate){
					$scores[$pid] = $typetemplate;
				}
			}else{
				$scores[$pid] =tpl_pn_commentsocre_viewthread_beginline_output('scoreshow','','');
			}
		}
		$optiondata = array();
	}
	return $scores;
}

function scthreadshow($ssortid,$csortid,$tid,$scorecount,$templatetype,$scname){
	$tscpost = DB::fetch_first("SELECT pid,total,scorenum,commentnum FROM ".DB::table('plugin_pn_commentscore_thread')." WHERE tid=$tid");
	$tpid=$tscpost['pid'];
	$total=$tscpost['total'] ? $tscpost['total'] : 0;

	$ssortid && $score = DB::fetch_first("SELECT * FROM ".DB::table('forum_optionvalue'.$ssortid)." WHERE tid=$tid");
	$csortid && $comment = DB::fetch_first("SELECT * FROM ".DB::table('forum_optionvalue'.$csortid)." WHERE tid=$tid");

	return scshow($total,$ssortid,$csortid,$score,$comment,$scorecount,$templatetype,$tid,$scname);

}

function scshow($total,$ssortid,$csortid,$score,$comment,$scorecount,$templatetype,$tid,$scname){
	global $_G;
	include_once libfile('function/threadsort');
	$sortdataexpiration = 0;
	$ssortoptionarray =$stemplatearray =$csortoptionarray =$ctemplatearray =array();
	if($ssortid){
		loadcache(array('threadsort_option_'.$ssortid, 'threadsort_template_'.$ssortid));
		$ssortoptionarray = $_G['cache']['threadsort_option_'.$ssortid];
		$stemplatearray = $_G['cache']['threadsort_template_'.$ssortid];
		if($ssortoptionarray) {

			$_G['pn_score_option']=array();

			foreach($ssortoptionarray as $optionid => $option) {
				if($option['type']=='range'||$option['type']=='number'){
					$optiondata[$optionid]['value'] = $score[$option['identifier']];
					$optiondata[$optionid]['expiration'] = 0;
					$_G['pn_score_option'][$option['identifier']]['title'] = $option['title'];
					$_G['pn_score_option'][$option['identifier']]['unit'] = $option['unit'];
					$_G['pn_score_option'][$option['identifier']]['type'] = $option['type'];
					if(($option['expiration'] && !$optiondata[$optionid]['expiration']) || empty($option['expiration'])) {
						if(!protectguard($option['protect'])) {
							$html='';
							$scorevalue=$optiondata[$optionid]['value']/10;
							if($option['type']=='range'){
								for($i=1;$i<=$option['maxnum'];$i++){
									if($i <= $scorevalue){
										$html.='<dd class="bstar">'.$i.'</dd>';
									}elseif(($i-0.5 )<= $scorevalue){
										$html.='<dd class="hstar">'.$i.'</dd>';
									}else{
										$html.='<dd class="dstar">'.$i.'</dd>';
									}
								}
								$html='<dl>'.$html.'<ct class="optv">&nbsp;&nbsp;'.$scorevalue.'&#x5206;</ct></dl>';
							}elseif($option['type']=='number'){
								$html='<dl><dd class="bnum">'.round($scorevalue*$scorecount/$option['maxnum'],1).'</dd></dl>';
							}
							$_G['pn_score_option'][$option['identifier']]['value']=$html;
						} else {
							if(empty($option['permprompt'])) {
								$_G['pn_score_option'][$option['identifier']]['value'] = lang('forum/misc', 'view_noperm');
							} else {
								$_G['pn_score_option'][$option['identifier']]['value'] = $option['permprompt'];
							}

						}
					} else {
						$_G['pn_score_option'][$option['identifier']]['value'] = lang('forum/misc', 'has_expired');
					}
				}
			}
		}
	}
	if($csortid){
		loadcache(array('threadsort_option_'.$csortid, 'threadsort_template_'.$csortid));
		$csortoptionarray = $_G['cache']['threadsort_option_'.$csortid];
		$ctemplatearray = $_G['cache']['threadsort_template_'.$csortid];

		if($csortoptionarray) {
			$_G['pn_comment_option']=array();
			foreach($csortoptionarray as $optionid => $option) {
				if($option['type']=='range'){
					$__show=1;
					$optiondata[$optionid]['value'] = $comment[$option['identifier']];;
					$optiondata[$optionid]['expiration'] = 0;
					$_G['pn_comment_option'][$option['identifier']]['title'] = $option['title'];
					$_G['pn_comment_option'][$option['identifier']]['unit'] = $option['unit'];
					$_G['pn_comment_option'][$option['identifier']]['type'] = $option['type'];
					if(($option['expiration'] && !$optiondata[$optionid]['expiration']) || empty($option['expiration'])) {
						if(!protectguard($option['protect'])) {
							if($option['type']=='range'){
								$_G['pn_comment_option'][$option['identifier']]['value']=$optiondata[$optionid]['value'];
							}
						} else {
							if(empty($option['permprompt'])) {
								$_G['pn_comment_option'][$option['identifier']]['value'] = lang('forum/misc', 'view_noperm');
							} else {
								$_G['pn_comment_option'][$option['identifier']]['value'] = $option['permprompt'];
							}

						}
					} else {
						$_G['pn_comment_option'][$option['identifier']]['value'] = lang('forum/misc', 'has_expired');
					}

				}
			}

		}
	}
	$typetemplate = $html ='';
	if($stemplatearray[$templatetype]||$ctemplatearray[$templatetype]) {
		$sortoptionarray=array_merge($ssortoptionarray,$ssortoptionarray);
		foreach($sortoptionarray as $option) {
			$searchtitle[] = '/{('.$option['identifier'].')}/e';
			$searchvalue[] = '/\[('.$option['identifier'].')value\]/e';
			$searchvalue[] = '/{('.$option['identifier'].')_value}/e';
			$searchunit[] = '/\[('.$option['identifier'].')unit\]/e';
			$searchunit[] = '/{('.$option['identifier'].')_unit}/e';
		}

		$threadexpiration = $sortdataexpiration ? dgmdate($sortdataexpiration) : lang('forum/misc', 'never_expired');
		if($stemplatearray[$templatetype]){
			$template=explode('<!---->',$stemplatearray[$templatetype]);
		}elseif($ctemplatearray[$templatetype]){
			$template=explode('<!---->',$ctemplatearray[$templatetype]);
		}
		$typetemplate = preg_replace(array("/\{expiration\}/i"), array($threadexpiration), stripslashes($template[0]));
		if($ssortoptionarray ){
			$typetemplate = preg_replace($searchtitle, "showscoption('\\1', 'title' ,'score')", $typetemplate);
			$typetemplate = preg_replace($searchvalue, "showscoption('\\1', 'value','score')", $typetemplate);
			$typetemplate = preg_replace($searchunit, "showscoption('\\1', 'unit','score')", $typetemplate);
		}
		if($csortoptionarray ){
			$typetemplate = preg_replace($searchtitle, "showscoption('\\1', 'title' ,'comment')", $typetemplate);
			$typetemplate = preg_replace($searchvalue, "showscoption('\\1', 'value','comment')", $typetemplate);
			$typetemplate = preg_replace($searchunit, "showscoption('\\1', 'unit','comment')", $typetemplate);
		}
		$typetemplate = str_replace('{total}',$total, $typetemplate);
		if($typetemplate){
			$scthread = $typetemplate;
		}
	}else{
		$html=$html1=$scthread='';
		if($ssortoptionarray ){
			$scthread.= tpl_pn_commentsocre_viewthread_beginline_output('scoreshow','','');
		}
		if($csortoptionarray && $__show){
			$scthread.= tpl_pn_commentsocre_viewthread_beginline_output('scthreadshowcomment','','');
		}
		if($templatetype=='viewthread'){
			if( defined('IN_MOBILE')){
				$button = '<button id="scbutton" onclick="javascript:window.location.href=this.value;" type="button" value="plugin.php?id=pn_commentscore:post&tid='.$tid.'"><strong>'.$scname.'</strong></button>';
			}else{
				$button = '<button id="scbutton" onclick="showWindow(\'comment\', this.value, \'get\', 0);" type="button" value="plugin.php?id=pn_commentscore:post&tid='.$tid.'"><strong>'.$scname.'</strong></button>';
			}
		}

		$scthread = '<div class="tscbox"><div class="csbox_z"><div class="bxy">'.tpl_pn_commentsocre_viewthread_beginline_output('scthreadshowtotal','',$total).'</div></div><div class="csbox_y">'.$scthread.$button.'</div></div>';

	}


	return $scthread;
}

function threadlistscoreshow($scoresortids,$commentsortids,$tids,$scorecounts,$allowview){
	global $_G;
	if(!empty($tids)) {
	$scores=array();
	$tidstr=implode(',',$tids);

	$scorethread = DB::fetch_all("SELECT tid,fid,typeid,sortid,scorenum,commentnum FROM ".DB::table('plugin_pn_commentscore_thread')." WHERE tid in ($tidstr)");
	foreach($scorethread as $thread){
		$tid = $thread['tid'];
		$typeid = $thread['typeid'];
		$sortid = $thread['sortid'];
		$ftsid =getftsid($thread['fid'],$typeid,$sortid);
		if($allowview[$ftsid]){
			$scorecount=$scorecounts[$ftsid];
			$score = $thread['score'];
			//			$scorenum = $thread['scorenum'];
			//			$commentnum = $thread['commentnum'];
			$ssortid=$scoresortids[$ftsid];
			$csortid=$commentsortids[$ftsid];
			$scorecomments[$tid]=scthreadshow($ssortid,$csortid,$tid,$scorecount,'subject','');
		}
	}
		return $scorecomments;

}
	return array();
}

function commentscoresort_validator($sortoption, $tid) {
	global $_G, $var;
	$postaction = 'forum.php?mod=viewthread&tid='.$tid;
	$_G['forum_optiondata'] = array();
	foreach($_G['forum_checkoption'] as $var => $option) {
		if($_G['forum_checkoption'][$var]['required'] && (($sortoption[$var] === '' && $_G['forum_checkoption'][$var]['type'] != 'number') || (!$sortoption[$var] && $_G['forum_checkoption'][$var]['type'] == 'number'))) {
			showmessage('threadtype_required_invalid', $postaction, array('typetitle' => $_G['forum_checkoption'][$var]['title']));
		} elseif($sortoption[$var] && ($_G['forum_checkoption'][$var]['type'] == 'number' && !is_numeric($sortoption[$var]) || $_G['forum_checkoption'][$var]['type'] == 'email' && !isemail($sortoption[$var]))){
			showmessage('threadtype_format_invalid', $postaction, array('typetitle' => $_G['forum_checkoption'][$var]['title']));
		} elseif($sortoption[$var] && $_G['forum_checkoption'][$var]['maxlength'] && strlen($sortoption[$var]) > $_G['forum_checkoption'][$var]['maxlength']) {
			showmessage('threadtype_toolong_invalid', $postaction, array('typetitle' => $_G['forum_checkoption'][$var]['title']));
		} elseif($sortoption[$var] && (($_G['forum_checkoption'][$var]['maxnum'] && $sortoption[$var] > $_G['forum_checkoption'][$var]['maxnum']) || ($_G['forum_checkoption'][$var]['minnum'] && $sortoption[$var] < $_G['forum_checkoption'][$var]['minnum']))) {
			showmessage('threadtype_num_invalid', $postaction, array('typetitle' => $_G['forum_checkoption'][$var]['title']));
		} elseif($sortoption[$var] && $_G['forum_checkoption'][$var]['unchangeable'] && !($_G['tid'] && $pid)) {
			showmessage('threadtype_unchangeable_invalid', $postaction, array('typetitle' => $_G['forum_checkoption'][$var]['title']));
		} elseif($sortoption[$var] && ($_G['forum_checkoption'][$var]['type'] == 'select')) {
			if($_G['forum_optionlist'][$_G['forum_checkoption'][$var]['optionid']]['choices'][$sortoption[$var]]['level'] != 1) {
				showmessage('threadtype_select_invalid', $postaction, array('typetitle' => $_G['forum_checkoption'][$var]['title']));
			}
		}
		if($_G['forum_checkoption'][$var]['type'] == 'checkbox') {
			$sortoption[$var] = $sortoption[$var] ? implode("\t", $sortoption[$var]) : '';
		} elseif($_G['forum_checkoption'][$var]['type'] == 'url') {
			$sortoption[$var] = $sortoption[$var] ? (substr(strtolower($sortoption[$var]), 0, 4) == 'www.' ? 'http://'.$sortoption[$var] : $sortoption[$var]) : '';
		}

		if($_G['forum_checkoption'][$var]['type'] == 'image') {
			if($sortoption[$var]['aid']) {
				$_GET['attachnew'][$sortoption[$var]['aid']] = $sortoption[$var];
			}
			$sortoption[$var] = serialize($sortoption[$var]);
		} elseif($_G['forum_checkoption'][$var]['type'] == 'select') {
			$sortoption[$var] = censor(trim($sortoption[$var]));
		} else {
			$sortoption[$var] = dhtmlspecialchars(censor(trim($sortoption[$var])));
		}
		$_G['forum_optiondata'][$_G['forum_checkoption'][$var]['optionid']]['value'] = $sortoption[$var];
		$_G['forum_optiondata'][$_G['forum_checkoption'][$var]['optionid']]['identifier'] = $var;
		$_G['forum_optiondata'][$_G['forum_checkoption'][$var]['optionid']]['type'] = $_G['forum_checkoption'][$var]['type'];
	}

	return $_G['forum_optiondata'];
}

function getcommentsortedoptionlist() {
	global $_G;
	$forum_optionlist = $_G['forum_commentoptionlist'];
	foreach($_G['forum_commentoptionlist'] as $key => $value) {
		$choicesarr = $value['choices'];
		uksort($choicesarr, 'cmpchoicekey');
		$forum_optionlist[$key]['choices'] = $choicesarr;
	}
	$forum_optionlist = optionlistxml($forum_optionlist, 's');
	$forum_optionlist = '<?xml version="1.0" encoding="'.CHARSET.'"?>'."".'<forum_optionlist>'.$forum_optionlist.'</forum_optionlist>';
	return $forum_optionlist;
}

function showscoption($var, $type, $sc) {
	global $_G;
	if($sc=='comment'){
		if($_G['pn_comment_option'][$var][$type]) {
			return $_G['pn_comment_option'][$var][$type];
		}
	}elseif($sc=='score'){
		if($_G['pn_score_option'][$var][$type]) {
			return $_G['pn_score_option'][$var][$type];
		}
	}
	return '';
}


function scsortsearch($csortid, $ssortid, $selecturladd = array(), $sortfid = 0) {
	global $_G;
	$csortid = intval($csortid);
	$selectsql = '';
	$optionide = $searchsorttids = $csortoptionarray =$ssortoptionarray = array();
	if($csortid){
		if(!$_G['cache']['threadsort_option_'.$csortid]){
			loadcache(array('threadsort_option_'.$csortid));
			sortthreadsortselectoption($csortid);
			$csortoptionarray = $_G['cache']['threadsort_option_'.$csortid];
		}else{
			$csortoptionarray = $_G['cache']['threadsort_option_'.$csortid];
		}

		if($selecturladd) {
			foreach($csortoptionarray as $optionid => $option) {
				if(in_array($option['type'], array('checkbox', 'radio', 'select','range'))) {
					$optionide[$option['identifier']] = $option['type'];
				}
			}
			foreach($selecturladd as $fieldname => $value) {
				$fieldname=str_replace('c_','',$fieldname);
				if($optionide[$fieldname] && $value != 'all') {
					if($optionide[$fieldname] == 'range') {
						$value = explode('|', $value);
						if($value[0] == 'd') {
							$sql = "$fieldname<".intval($value[1]);
						} elseif($value[0] == 'u') {
							$sql = "$fieldname>".intval($value[1]);
						} else {
							$sql = "($fieldname BETWEEN ".intval($value[0])." AND ".intval($value[1]).")";
						}
						$orderby=($_GET['orderby']=='numasc') ? "ORDER BY $fieldname ASC " : "ORDER BY $fieldname DESC ";
					} elseif($optionide[$fieldname] == 'select') {
						$subvalues = $currentchoices = $sqlarr = array();
						$sql='';
						if(!empty($csortoptionarray)) {
							foreach($csortoptionarray as $subkey => $subvalue) {
								if($subvalue['identifier'] == $fieldname) {
									$currentchoices = $subvalue['choices'];
									break;
								}
							}
						}
						if(!empty($currentchoices)) {
							foreach($currentchoices as $subkey => $subvalue) {
								if(preg_match('/^'.$value.'\.'.'/i', $subkey) || preg_match('/^'.$value.'$'.'/i', $subkey)) {
									$sqlarr[] = DB::field($fieldname, $subkey).
									' OR '.DB::field($fieldname, "$subkey\t%", 'like').
									' OR '.DB::field($fieldname, "%\t$subkey", 'like').
									' OR '.DB::field($fieldname, "%\t$subkey\t%", 'like');
								}
							}
							$sql = '('.implode(' OR ',$sqlarr).')';
						}
					} else {
						$sql = '('.DB::field($fieldname, $value).
						' OR '.DB::field($fieldname, "$value\t%", 'like').
						' OR '.DB::field($fieldname, "%\t$value", 'like').
						' OR '.DB::field($fieldname, "%\t$value\t%", 'like').')';
					}
					$selectsql .= "AND $sql ";
				}
			}
		}
		$searchsorttids = C::t('forum_optionvalue')->fetch_all_tid($csortid, "WHERE 1 $selectsql ".($sortfid ? "AND fid='$sortfid'" : '').$orderby);
	}
	if($ssortid){
		if(!$_G['cache']['threadsort_option_'.$ssortid]){
			loadcache(array('threadsort_option_'.$ssortid));
			$ssortoptionarray = $_G['cache']['threadsort_option_'.$ssortid];
			$orderbyarr=array();
		}else{
			$ssortoptionarray = $_G['cache']['threadsort_option_'.$ssortid];
		}
		foreach($ssortoptionarray as $option){
			$orderbyarr[]='s_'.$option['identifier'];
		}
		if(in_array($_GET['orderby'],$orderbyarr)){
			$orderby="ORDER BY ".str_replace('s_','',$_GET['orderby'])." ASC ";
			$_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
			$start_limit = ($_GET['page'] - 1) * $_G['tpp'];
			
			if($searchsorttids){
			$searchsorttids = C::t('forum_optionvalue')->fetch_all_tid($ssortid, "WHERE 1 ".($sortfid ? "AND fid='$sortfid' " : ' ')."AND tid in (".implode(',',$searchsorttids).") ".$orderby.DB::limit($start_limit, $_G['tpp']));
			}else{
			$searchsorttids = C::t('forum_optionvalue')->fetch_all_tid($ssortid, "WHERE 1 ".($sortfid ? "AND fid='$sortfid' " : ' ').$orderby.DB::limit($start_limit, $_G['tpp']));

			}
		}
	}
	return $searchsorttids;

}

function scorecalc($sortid,$tid) {
	global $_G;
	$scoreoptionlist=$scorethread=$scorecalc=array();
	loadcache(array('threadsort_option_'.$sortid));
	$scoreoptionlist = $_G['cache']['threadsort_option_'.$sortid];
	if(!is_array($tid) && $tid!=''){
		$scorethread = DB::fetch_all("SELECT tid FROM ".DB::table('forum_optionvalue'.$sortid)." WHERE tid='$tid'");
		$scorethread = $scorethread ? $scorethread : array('0'=>array('tid'=>$tid));
	}else{
		if(is_array($tid)){
			$tid=implode(',',$tid);
			$scorethread = DB::fetch_all("SELECT tid FROM ".DB::table('forum_optionvalue'.$sortid)." WHERE tid in ($tid)");
		}else{
			$scorethread = DB::fetch_all("SELECT tid FROM ".DB::table('forum_optionvalue'.$sortid)." WHERE 1>0");
		}
	}

	foreach($scorethread as $thread){
		$updatescorearr=$updatescorecount=array();
		foreach($scoreoptionlist as $id => $option){
			$scorethreadoption =array();
			$scorethreadoption = DB::fetch_all("SELECT value FROM ".DB::table('plugin_pn_commentscore_typeoptionvar')." WHERE tid={$thread['tid']} AND optionid=$id");
			$updatescorearr[$option['identifier']]=0;
			if($scorethreadoption){
				foreach($scorethreadoption as $soption){
					for($i=1;$i<=$option['maxnum'];$i++){
						if($soption['value']==$i){
							$updatescorecount[$id][$i]+=1;
							break;
						}
					}
					$updatescorearr[$option['identifier']]+=$soption['value'];
				}
			}
			$updatescorearr[$option['identifier']]=round($updatescorearr[$option['identifier']]/count($scorethreadoption),1)*10;
		}
		$scorecalc[$thread['tid']]['value']=$updatescorearr;
		$scorecalc[$thread['tid']]['scorenum']=count($scorethreadoption);
		$scorecalc[$thread['tid']]['scorecount']=serialize($updatescorecount);
	}

	return $scorecalc;
}

function commentcalc($sortid,$tid) {
	global $_G;
	$commentoptionlist=$commentthread=$commentcalc=array();
	loadcache(array('threadsort_option_'.$sortid));

	$commentoptionlist = $_G['cache']['threadsort_option_'.$sortid];

	foreach($commentoptionlist as $id=>$option){
		if($option['search']) {
			if(!empty($option['searchtxt'])){
				$choices = array();
				$prevs = 'd';
				foreach($option['searchtxt'] as $choice) {
					$value = "$prevs|$choice";
					if($choice){
						$commentoptionlist[$id]['choices'][$value]= $choice;
						$prevs = $choice;
					}
					$max = $choice;
				}
				$value = "u|$choice";
				$commentoptionlist[$id]['choices'][$value] = $max;
			}
		}
	}
	if(!is_array($tid) && $tid!=''){
		$commentthread = DB::fetch_all("SELECT tid FROM ".DB::table('forum_optionvalue'.$sortid)." WHERE tid=$tid");
		$commentthread = $scorethread ? $scorethread : array('0'=>array('tid'=>$tid));
	}else{
		if(is_array($tid)){
			$tid = implode(',',$tid);
			$commentthread = DB::fetch_all("SELECT tid FROM ".DB::table('forum_optionvalue'.$sortid)." WHERE tid in ($tid)");
		}else{
			$commentthread = DB::fetch_all("SELECT tid FROM ".DB::table('forum_optionvalue'.$sortid)." WHERE 1>0");
		}
	}
	foreach($commentthread as $thread){
		$updatecommentarr=$updatecommentcount=array();
		foreach($commentoptionlist as $id => $option){
			$commentthreadoption=array();
			$commentthreadoption = DB::fetch_all("SELECT value FROM ".DB::table('plugin_pn_commentscore_typeoptionvar')." WHERE tid={$thread['tid']} AND optionid=$id");
			if($commentthreadoption){
				if($option['type']=='range'){
					$updatecommentarr[$option['identifier']]=0;
					foreach($commentthreadoption as $soption){
						foreach($option['choices'] as $cid=>$choice) {
							$value = explode('|', $cid);
							if($value[0] == 'd') {
								if($soption['value'] < intval($value[1])){
									$updatecommentcount[$id][$cid]+=1;
									break;
								}
							} elseif($value[0] == 'u') {
								if($soption['value'] > intval($value[1])){
									$updatecommentcount[$id][$cid]+=1;
									break;
								}
							} else {
								if(($soption['value'] < intval($value[1]))&&($soption['value'] > intval($value[0]))){
									$updatecommentcount[$id][$cid]+=1;
									break;
								}
							}
						}

						$updatecommentarr[$option['identifier']] += $soption['value'];
					}
					$updatecommentarr[$option['identifier']] = floor($updatecommentarr[$option['identifier']]/count($commentthreadoption));
				}elseif($option['type']=='select'){
					$valuearr=array();
					foreach($commentthreadoption as $soption){
						foreach($option['choices'] as $subkey => $subvalue) {
							if(preg_match('/^'.$subkey.'\.'.'/i', $soption['value']) || preg_match('/^'.$subkey.'$'.'/i', $soption['value'])) {
								$updatecommentcount[$id][$subkey]+=1;
							}
						}
						!in_array($soption['value'],$valuearr) && ($valuearr[]=$soption['value']);
					}
					$updatecommentarr[$option['identifier']] = ($commentthreadoption ? implode("\t",$valuearr) : '');
				}elseif($option['type']=='checkbox'){
					$valuearr=array();
					foreach($commentthreadoption as $soption){
						$schoices=explode("\t",$soption['value']);
						foreach($schoices as $schoice){
							foreach($option['choices'] as $cid=>$choice) {
								if($schoice==$cid){
									$updatecommentcount[$id][$cid]+=1;
									break;
								}
							}
						}
						$valuearr=array_merge($valuearr,$schoices);
						$valuearr=array_unique($valuearr);
					}
					$updatecommentarr[$option['identifier']] = $commentthreadoption ? implode("\t",$valuearr) : '';
				}elseif($option['type']=='radio'){
					$valuearr=array();
					foreach($commentthreadoption as $soption){
						foreach($option['choices'] as $cid=>$choice) {
							if($cid==$soption['value']){
								$updatecommentcount[$id][$cid]+=1;
								break;
							}
						}
						!in_array($soption['value'],$valuearr) && ($valuearr[]=$soption['value']);
					}
					$updatecommentarr[$option['identifier']] = $commentthreadoption ? implode("\t",$valuearr) : '';
				}
			}else{

				$updatecommentarr[$option['identifier']]='';
			}

		}
		$commentcalc[$thread['tid']]['value']=$updatecommentarr;
		$commentcalc[$thread['tid']]['commentnum']=count($commentthreadoption);
		$commentcalc[$thread['tid']]['commentcount']=serialize($updatecommentcount);
	}
	return $commentcalc;
}

function scorecommentcount($fid=0,$typeid=0,$sortid=0,$ssortid=0,$csortid=0) {
	global $_G;
	$scthread = DB::fetch_all("SELECT * FROM ".DB::table('plugin_pn_commentscore_thread')." WHERE fid=$fid AND typeid=$typeid AND sortid=$sortid");
	if($ssortid){
		$scoreoptionlist=$scorethread=$scorecalc=array();
		loadcache(array('threadsort_option_'.$ssortid));
		$scoreoptionlist = $_G['cache']['threadsort_option_'.$ssortid];
		$updatescoretotal = array();
		$updatescorenum = 0;
		foreach($scthread as $thread){
			$updatescorearr=$scorethreadoption=array();
			$scorethreadoption = DB::fetch_first("SELECT * FROM ".DB::table('forum_optionvalue'.$ssortid)." WHERE tid={$thread['tid']}");
			foreach($scoreoptionlist as $id => $option){
				$optionchoice=$scorethreadoption[$option['identifier']];
				if($scorethreadoption){
					for($i=1;$i<=$option['maxnum'];$i++){
						if(round($optionchoice/10)==$i){
							$updatescoretotal[$id][$i]+=1;
							break;
						}
					}
				}
			}
		}
		$scorecount=serialize($updatescoretotal);
	}

	if($csortid){
		global $_G;
		$commentoptionlist=$commentthread=$commentcalc=array();
		loadcache(array('threadsort_option_'.$csortid));

		$commentoptionlist = $_G['cache']['threadsort_option_'.$csortid];

		foreach($commentoptionlist as $id=>$option){
			if($option['search']) {
				if(!empty($option['searchtxt'])){
					$choices = array();
					$prevs = 'd';
					foreach($option['searchtxt'] as $choice) {
						$value = "$prevs|$choice";
						if($choice){
							$commentoptionlist[$id]['choices'][$value]= $choice;
							$prevs = $choice;
						}
						$max = $choice;
					}
					$value = "u|$choice";
					$commentoptionlist[$id]['choices'][$value] = $max;
				}
			}
		}
		$commentthread = DB::fetch_all("SELECT * FROM ".DB::table('plugin_pn_commentscore_thread')." WHERE fid=$fid AND typeid=$typeid AND sortid=$sortid");
		$updatecommenttotal=array();
		$updatecommentnum=0;
		foreach($scthread as $thread){
			$updatecommentarr=$commentthreadoption=$updatecommentcount=array();
			$commentthreadoption = DB::fetch_first("SELECT * FROM ".DB::table('forum_optionvalue'.$csortid)." WHERE tid={$thread['tid']}");
			foreach($commentoptionlist as $id => $option){
				$optionchoice=$commentthreadoption[$option['identifier']];
				if($optionchoice){
					if($option['type']=='range'){
						$updatecommentarr[$option['identifier']]=0;
						if($commentthreadoption){
							foreach($option['choices'] as $cid=>$choice) {
								$value = explode('|', $cid);
								if($value[0] == 'd') {
									if($optionchoice < intval($value[1])){
										$updatecommentcount[$id][$cid]+=1;
										$updatecommenttotal[$id][$cid]+=1;
										break;
									}
								} elseif($value[0] == 'u') {
									if($optionchoice > intval($value[1])){
										$updatecommenttotal[$id][$cid]+=1;
										break;
									}
								} else {
									if(($optionchoice < intval($value[1]))&&($optionchoice > intval($value[0]))){
										$updatecommenttotal[$id][$cid]+=1;
										break;
									}
								}
							}
						}
					}elseif($option['type']=='select'){
						$valuearr=array();
						foreach($option['choices'] as $subkey => $subvalue) {
							if(preg_match('/^'.$subkey.'\.'.'/i', $optionchoice) || preg_match('/^'.$subkey.'$'.'/i', $optionchoice)) {
								$updatecommenttotal[$id][$subkey]+=1;
							}
						}
					}elseif($option['type']=='checkbox' || $option['type']=='radio'){
						$valuearr=array();
						$schoices=explode("\t",$optionchoice);
						foreach($schoices as $schoice){
							foreach($option['choices'] as $cid=>$choice) {
								if($schoice==$cid){
									$updatecommenttotal[$id][$cid]+=1;
									break;
								}
							}
						}
					}
				}
			}

		}
		$commentcount=serialize($updatecommenttotal);
	}
	$count['scorecount']=$scorecount;
	$count['commentcount']=$commentcount;
	$count['total']=count($scthread);
	return $count;
}
//From: Dism_taobao_com
?>