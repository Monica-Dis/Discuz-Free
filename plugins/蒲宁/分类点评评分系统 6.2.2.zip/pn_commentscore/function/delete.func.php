<?php
/**
*	[分类评分点评插件(pn_commentscore)] [DisM!] (C)2001-2099 DisM Inc.
*	Version: 1.0
*	Date: 2013-12-8 20:00
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


function deletescpost($params,$scoresortid,$commentsortid) {
	global $_G;

	include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/dataconvert.func.php';
	include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/thread.func.php';
	$pids = $params['param'][0];
	$idtype = $params['param'][1];
	$step = $params['step'];
	$scorepost=$tids=$delpostarr=$threadarr=$tscorepost=$tpids=array();
	if($step == 'delete' && $idtype == 'pid' && is_array($pids)){
		$scorepost = DB::fetch_all("SELECT pid,tid,score,comment FROM ".DB::table('plugin_pn_commentscore_post')." WHERE pid in (".implode(',',$pids).")");
		if(is_array($scorepost)){
			foreach($scorepost as $post){
				$delpids[]=$post['pid'];
				if(!in_array($post['tid'],$tids)){
					$tids[]=$post['tid'];
				}
			}
			if($delpids){

				DB::query("DELETE FROM ".DB::table('plugin_pn_commentscore_post')." WHERE pid IN (".implode(',',$delpids).")",null,'SILENT');
				DB::query("DELETE FROM ".DB::table('plugin_pn_commentscore_typeoptionvar')." WHERE pid IN (".implode(',',$delpids).")",null,'SILENT');
				foreach($tids as $tid){
					DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_post')."` t1 LEFT JOIN `".DB::table('forum_post')."` t2 ON t1.pid=t2.pid WHERE (t2.pid IS NULL OR t2.invisible<0) AND t1.tid=$tid");
					DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_post')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_thread')."` t2 ON t1.tid=t2.tid WHERE t2.tid IS NULL  AND t1.tid=$tid");
					DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_typeoptionvar')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_post')."` t2 ON t1.pid=t2.pid WHERE t2.pid IS NULL AND t1.tid=$tid");
					DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_post')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_typeoptionvar')."` t2 ON t1.pid=t2.pid WHERE t2.pid IS NULL AND t1.tid=$tid");

					$thread = DB::fetch_first("SELECT fid,typeid,sortid,uid FROM ".DB::table('plugin_pn_commentscore_thread')." WHERE tid = $tid");
					$sortid = $thread['sortid'];
					$typeid = $thread['typeid'];
					$fid = $thread['fid'];
					$ftsid = getftsid($fid,$typeid,$sortid);
					if($scoresortid[$ftsid]){
						$scorecalc=array();
						$scorecalc=scorecalc($scoresortid[$ftsid],$tid);
						DB::update('forum_optionvalue'.$scoresortid[$ftsid], $scorecalc[$tid]['value'], array('tid' => $tid));
						DB::update('plugin_pn_commentscore_thread', array('scorenum'=>$scorecalc[$tid]['scorenum'],'scorecount'=>$scorecalc[$tid]['scorecount']), array('tid' => $tid));
					}
					if($commentsortid[$ftsid]){
						$commentcalc=array();
						$commentcalc=commentcalc($commentsortid[$ftsid],$tid);
						DB::update('forum_optionvalue'.$commentsortid[$ftsid], $commentcalc[$tid]['value'], array('tid' => $tid));
						DB::update('plugin_pn_commentscore_thread', array('commentnum'=>$commentcalc[$tid]['commentnum'],'commentcount'=>$commentcalc[$tid]['commentcount']), array('tid' => $tid));
					}
					$sctotal = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_pn_commentscore_post')." WHERE tid=$tid");
					DB::update('plugin_pn_commentscore_thread', array('total'=>$sctotal), array('tid' => $tid));
					$sccount=scorecommentcount($fid,$thread['typeid'],$thread['sortid'],$scoresortid[$ftsid],$commentsortid[$ftsid]);
					DB::update('plugin_pn_commentscore_sort', array('total'=>$sccount['total'],'scorecount'=>$sccount['scorecount'],'commentcount'=>$sccount['commentcount'],'dateline'=>$_G['timestamp']), array('ftsid' => $ftsid));
					$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_pn_commentscore_thread')." WHERE tid=$tid AND total=0");
					if($conut){
						DB::query("DELETE FROM `".DB::table('plugin_pn_commentscore_thread')."` WHERE tid=$tid");
						DB::query("DELETE FROM `".DB::table('plugin_pn_commentscore_post')."` WHERE tid=$tid");
						DB::query("DELETE FROM `".DB::table('plugin_pn_commentscore_typeoptionvar')."` WHERE tid=$tid");
					}
				}
			}
		}
	}
}

function deletescthread($params,$scoresortid,$commentsortid){
	include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/dataconvert.func.php';
	include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/thread.func.php';

	$tids = $params['param'][0];
	$step = $params['step'];
	if($step == 'delete' && is_array($tids)) {
		DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_thread')."` t1 LEFT JOIN `".DB::table('forum_thread')."` t2 ON t1.tid=t2.tid WHERE t2.tid IS NULL OR t2.displayorder<0");

		foreach($tids as $tid){
			$thread = DB::fetch_first("SELECT fid,typeid,sortid FROM ".DB::table('plugin_pn_commentscore_thread')." WHERE tid = $tid");
			$typeid = $thread['typeid'];
			$sortid = $thread['sortid'];
			$ftsid = getftsid($thread['fid'],$typeid,$sortid);
			if($scoresortid[$ftsid]||$commentsortid[$ftsid]){
				DB::query("DELETE FROM ".DB::table('plugin_pn_commentscore_post')." WHERE tid=$tid",null,'SILENT');
				DB::query("DELETE FROM ".DB::table('plugin_pn_commentscore_thread')." WHERE tid=$tid",null,'SILENT');
				DB::query("DELETE FROM ".DB::table('plugin_pn_commentscore_typeoptionvar')." WHERE tid=$tid",null,'SILENT');

				if($scoresortid[$ftsid]){
					DB::query("DELETE FROM ".DB::table('forum_optionvalue'.$scoresortid[$ftsid])." WHERE tid=$tid",null,'SILENT');
				}
				if($commentsortid[$ftsid]){
					DB::query("DELETE FROM ".DB::table('forum_optionvalue'.$commentsortid[$ftsid])." WHERE tid=$tid",null,'SILENT');
				}
				$sccount=scorecommentcount($fid,$thread['typeid'],$thread['sortid'],$scoresortid[$ftsid],$commentsortid[$ftsid]);
				DB::update('plugin_pn_commentscore_sort', array('total'=>$sccount['total'],'scorecount'=>$sccount['scorecount'],'commentcount'=>$sccount['commentcount'],'dateline'=>$_G['timestamp']), array('ftsid' => $ftsid));

			}
		}
	}



}



?>