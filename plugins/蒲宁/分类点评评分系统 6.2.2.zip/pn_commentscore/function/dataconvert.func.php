<?php
/**
*	[分类评分点评插件(pn_commentscore)] [DisM!] (C)2001-2099 DisM Inc.
*	Version: 1.0
*	Date: 2013-12-8 20:00
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


function getftsid($fid,$typeid,$sortid){
	return $fid . ($typeid ? '.'.$typeid.($sortid ? '.'.$sortid : '') : ($sortid ? '..'.$sortid : ''));
}

function commentsearch($commentsortid,$ftsid){
	global $_G;
	loadcache(array('threadsort_option_'.$commentsortid));
	include_once libfile('function/threadsort');
	sortthreadsortselectoption($commentsortid);
	$commentsortoptionarr = $_G['cache']['threadsort_option_'.$commentsortid];
	$commentsearch=array();
	$commentcount = DB::result_first("SELECT commentcount FROM ".DB::table('plugin_pn_commentscore_sort')." WHERE ftsid='$ftsid'");
	$commentcount = unserialize($commentcount);
	foreach($commentsortoptionarr as $id=>$option){
		if($option['search']) {
			$commentsearch[$id]['title'] = $option['title'];
			$commentsearch[$id]['identifier'] = 'c_'.$option['identifier'];
			$commentsearch[$id]['unit'] = $option['unit'];
			$commentsearch[$id]['type'] = $option['type'];
			$commentsearch[$id]['search'] = $option['search'];
			if(in_array($option['type'], array('radio', 'select', 'checkbox'))) {
				$commentsearch[$id]['choices'] = $option['choices'];
				foreach($option['choices'] as $cid=>$choice){
					if($option['type']=='select'){
						$commentsearch[$id]['choices'][$cid]['content'].=' ('.($commentcount[$id][$cid] ? $commentcount[$id][$cid] : 0).')';
					}else{
						$commentsearch[$id]['choices'][$cid].=' ('.($commentcount[$id][$cid] ? $commentcount[$id][$cid] : 0).')';
					}
					
				}
			}elseif(!empty($option['searchtxt'])){
				$choices = array();
				$prevs = 'd';
				foreach($option['searchtxt'] as $choice) {
					$value = "$prevs|$choice";
					if($choice) {
						$commentsearch[$id]['choices'][$value]= $prevs == 'd' ? lang('forum/misc', 'lower').$choice.$option['unit'] : $prevs.'-'.$choice.$option['unit'];
						$commentsearch[$id]['choices'][$value] .= ' ('.($commentcount[$id][$value] ? $commentcount[$id][$value] : 0).')';
						$prevs = $choice;
					}
					$max = $choice;
				}
				$value = "u|$choice";
				$commentsearch[$id]['choices'][$value] = lang('forum/misc', 'higher').$max.$option['unit'];
				$commentsearch[$id]['choices'][$value] .= ' ('.($commentcount[$id][$value] ? $commentcount[$id][$value] : 0).')';
			}
		}
	}
	return $commentsearch;
}

function scoresearch($scoresortid){
	global $_G;
	loadcache(array('threadsort_option_'.$scoresortid));
	$scoresortoptionarr = $_G['cache']['threadsort_option_'.$scoresortid];
	foreach($scoresortoptionarr as $id=>$option){
		if($option['search']) {
			if(in_array($option['type'],array('number','range'))){
				$scoresearch[$id]['title'] = $option['title'];
				$scoresearch[$id]['identifier'] = 's_'.$option['identifier'];
			}
		}
	}
	return $scoresearch;
}
//From: Dism_taobao_com
?>