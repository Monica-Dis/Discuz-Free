<?php

/**
*	[分类评分点评插件(pn_commentscore)] [DisM!] (C)2001-2099 DisM Inc.
*	Version: 1.0
*	Date: 2013-12-8 20:00
*/

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$tid = intval($_GET['tid']);
include_once libfile('function/forum');
include_once libfile('function/forumlist');
include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/dataconvert.func.php';

$thread = get_thread_by_tid($tid);
$tuid = $thread['authorid'];

if(!$thread){
	showmessage(lang('plugin/pn_commentscore', 'error_threadnone'), '', '', array('showdialog' => true));
}

$scpostself = $_G['cache']['plugin']['pn_commentscore']['sc_postself'];
if(!$scpostself&&$_G['uid']==$tuid){
	showmessage(lang('plugin/pn_commentscore', 'error_postself'), '', '', array('showdialog' => true));
}


$fid = $thread['fid'];
$ftsid = getftsid($thread['fid'],$thread['typeid'],$thread['sortid']);

$scthread = DB::fetch_first("SELECT fid,typeid,sortid FROM ".DB::table('plugin_pn_commentscore_thread')." WHERE tid=$tid");
$scftsid = getftsid($scthread['fid'],$scthread['typeid'],$scthread['sortid']);

if($ftsid!=$scftsid){
	$scnum = DB::fetch_first("SELECT scorenum,commentnum FROM ".DB::table('plugin_pn_commentscore_thread')." WHERE tid=$tid");
	if($scnum['socrenum']||$scnum['commentnum']){
		showmessage(lang('plugin/pn_commentscore', 'error_ftsid'), '', '', array('showdialog' => true));
	}
}

$scoresetarr = explode("\n", str_replace(array("\r\n","\r","\n"), "\n", $_G['cache']['plugin']['pn_commentscore']['fids_sorids']));
$fids = array();

loadforum($fid,$tid);
$_G['forum']['allowreply'] = isset($_G['forum']['allowreply']) ? $_G['forum']['allowreply'] : '';
$_G['forum']['allowpost'] = isset($_G['forum']['allowpost']) ? $_G['forum']['allowpost'] : '';
$classusergroups = explode("\n", str_replace(array("\r\n","\r","\n"), "\n",$_G['cache']['plugin']['pn_commentscore']['class_usergroups']));
foreach($classusergroups as $row){
	$usergroup=explode('=',$row);
	$postusergroup[$usergroup[0]]=explode(',',$usergroup[1]);
}
foreach($scoresetarr as $set){
	if($set){
		$setarr = explode("|",$set);
		$fids[]=$setarr[0];
		$setsortid=explode(",",$setarr[1]);
		$scoresortid[$setarr[0]]=$setsortid[0];
		$commensortid[$setarr[0]]=$setsortid[1];
		$scname[$setarr[0]]=$setarr[3];
		$limit=explode(',',$setarr[4]);
		$usergrouplimit=explode('/',$limit[0]);
		if($usergrouplimit[0]){
			$allowpostreply[$setarr[0]] = (in_array($_G['groupid'],$postusergroup[$usergrouplimit[0]]) || array_intersect($postusergroup[$usergrouplimit[0]],explode("\t",$_G['member']['extgroupids']))) && (!$_G['forum_thread']['closed'] && !checkautoclose($_G['forum_thread']));
		}else{
			$allowpostreply[$setarr[0]] = ($_G['forum']['allowreply'] != -1) && (($_G['forum_thread']['isgroup'] || (!$_G['forum_thread']['closed'] && !checkautoclose($_G['forum_thread']))) || $_G['forum']['ismoderator']) && ((!$_G['forum']['replyperm'] && $_G['group']['allowreply']) || ($_G['forum']['replyperm'] && forumperm($_G['forum']['replyperm'])) || $_G['forum']['allowreply']);
		}
		$commentstrlimit=explode('/',$limit[1]);
		$commentstrmin[$setarr[0]]=($commentstrlimit[0]!='') ? $commentstrlimit[0] : (!IN_MOBILE || !$_G['setting']['minpostsize_mobile'] ? $_G['setting']['minpostsize'] : $_G['setting']['minpostsize_mobile']);
		$commentstrmax[$setarr[0]]=$commentstrlimit[1] ? $commentstrlimit[1] : $_G['setting']['maxpostsize'];
		$limittime=explode('/',$limit[2]);
		$posttime[$setarr[0]]=$limittime[0];
		$postnum[$setarr[0]]=$limittime[1];
	}
}

if(!in_array($ftsid,$fids)){
	showmessage(lang('plugin/pn_commentscore', 'error_fids'), '', '', array('showdialog' => true));
}

if(!$allowpostreply[$ftsid]){
	showmessage(lang('plugin/pn_commentscore', 'error_groupids'), '', '', array('showdialog' => true));
}


if($posttime[$ftsid]){
	$count = DB::result_first('SELECT COUNT(*) FROM '.DB::table('plugin_pn_commentscore_post')." WHERE tid=$tid AND uid={$_G['uid']} AND dateline>".(TIMESTAMP-$posttime[$ftsid]));
	if($count>=$postnum[$ftsid]){
		showmessage(lang('plugin/pn_commentscore', 'error_postnum'), '', '', array('showdialog' => true));
	}
}

$scoresortid=$scoresortid[$ftsid];
$commentsortid=$commensortid[$ftsid];
include_once libfile('function/threadsort');
include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/thread.func.php';
if($scoresortid){
	loadcache(array('threadsort_option_'.$scoresortid));
	$_G['forum_scoreoptionlist'] = $_G['cache']['threadsort_option_'.$scoresortid];
}else{
	$_G['forum_scoreoptionlist'] = array();
}
if($commentsortid){
	loadcache(array('threadsort_option_'.$commentsortid));
	sortthreadsortselectoption($commentsortid);
	$_G['forum_commentoptionlist'] = $_G['cache']['threadsort_option_'.$commentsortid];
	$forum_optionlist = getcommentsortedoptionlist();
}else{
	$_G['forum_commentopoptionlist'] = array();
}


if(!submitcheck('commentsubmit')) {
	$defaultscname = $_G['cache']['plugin']['pn_commentscore']['sc_name'];
	$scname=$scname[$ftsid] ? $scname[$ftsid] : $defaultscname;
	$scorehtml='';
	foreach($_G['forum_scoreoptionlist'] as $optionid => $option) {
		for($i=1;$i<=$option['maxnum'];$i++){
			$_G['forum_scoreoptionlist'][$optionid]['template'].='<li>'.$i.'</li>';
		}
		$_G['forum_scoreoptionlist'][$optionid]['template']='<ul>'.$_G['forum_scoreoptionlist'][$optionid]['template'].'</ul>';

		$scriptarg.= $option[identifier].":0,";
	}
	$scriptarg = rtrim($scriptarg,',');
		if($_G['cache']['plugin']['pn_commentscore']['icon']==2){
				$icon = 'heart.png';
		}elseif($_G['cache']['plugin']['pn_commentscore']['icon']==3){
				$icon = 'flower.png';
		}else{
			  $icon = 'star.png';
		}

	if($_G['cache']['plugin']['pn_commentscore']['template']==2 && defined('IN_MOBILE')){
		include template('pn_commentscore:post_1');
	}else{
		include template('pn_commentscore:post');
	}
}else{
	if(isset($_GET['formhash']) && $_GET['formhash'] == formhash()) {
		$temparr=array();
		if($scoresortid){
			threadsort_checkoption($scoresortid);
			$temparr=$_G['forum_checkoption'];
		}
		if($commentsortid){
			threadsort_checkoption($commentsortid);
			$_G['forum_checkoption']=array_merge($temparr,$_G['forum_checkoption']);
		}
		$forum_optiondata = commentscoresort_validator($_POST['typeoption'], $tid);
		if(strlen(preg_replace("/\[quote\].+?\[\/quote\]/is", '', $_POST['message'])) < $commentstrmin[$ftsid] || strlen(preg_replace("/\[postbg\].+?\[\/postbg\]/is", '', $_POST['message'])) < $minpostsize) {
			showmessage(lang('plugin/pn_commentscore', 'post_message_tooshort'), 'forum.php?mod=viewthread&tid='.$tid ,array('minpostsize'=>$commentstrmin[$ftsid]));
		}

		if(strlen($_POST['message'])>$commentstrmax[$ftsid]){
			showmessage(lang('plugin/pn_commentscore', 'post_message_tooshort'), 'forum.php?mod=viewthread&tid='.$tid ,array('maxpostsize'=>$commentstrmax[$ftsid]));
		}
		if(is_array($forum_optiondata)) {


			$subject = isset($_GET['subject']) ? dhtmlspecialchars(censor(trim($_GET['subject']))) : '';
			$subject = !empty($subject) ? str_replace("\t", ' ', $subject) : $subject;
			$message = (isset($_GET['message']) && !empty(censor($_GET['message']))) ? censor($_GET['message']) : $_G['cache']['plugin']['pn_commentscore']['def_comment'];
			$params = array(
			'subject' => $subject,
			'message' => $message,
			'special' => $special,
			'extramessage' => $extramessage,
			'bbcodeoff' => $_GET['bbcodeoff'],
			'smileyoff' => $_GET['smileyoff'],
			'htmlon' => $_GET['htmlon'],
			'parseurloff' => $_GET['parseurloff'],
			'usesig' => $_GET['usesig'],
			'isanonymous' => $_GET['isanonymous'],
			'noticetrimstr' => $_GET['noticetrimstr'],
			'noticeauthor' => $_GET['noticeauthor'],
			'from' => $_GET['from'],
			'sechash' => $_GET['sechash'],
			'geoloc' => diconv($_GET['geoloc'], 'UTF-8'),
			'status' =>0,
			);
			$modpost = C::m('forum_post', $_G['tid']);
			$return = $modpost->newreply($params);
			$pid = $modpost->pid;
			$tpid = DB::result_first("SELECT pid FROM ".DB::table('forum_post')." WHERE tid=$tid AND first=1");

			if($scoresortid){
				$tscorepost = DB::fetch_first("SELECT * FROM ".DB::table('forum_optionvalue'.$scoresortid)." WHERE tid=$tid");
				$scoresortkeys=array_keys($_G['forum_scoreoptionlist']);
			}

			if($commentsortid){
				$tcommentpost = DB::fetch_first("SELECT * FROM ".DB::table('forum_optionvalue'.$commentsortid)." WHERE tid=$tid");
				$commentsortkeys=array_keys($_G['forum_commentoptionlist']);
			}

			DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_post')."` t1 LEFT JOIN `".DB::table('forum_post')."` t2 ON t1.pid=t2.pid WHERE (t2.pid IS NULL OR t2.invisible<0) AND t1.tid=$tid");
			DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_post')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_thread')."` t2 ON t1.tid=t2.tid WHERE t2.tid IS NULL  AND t1.tid=$tid");
			DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_typeoptionvar')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_post')."` t2 ON t1.pid=t2.pid WHERE t2.pid IS NULL AND t1.tid=$tid");
			DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_post')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_typeoptionvar')."` t2 ON t1.pid=t2.pid WHERE t2.pid IS NULL AND t1.tid=$tid");

			foreach($forum_optiondata as $optionid => $value) {
				if($value['value']) {
					if($scoresortid&&in_array($optionid,$scoresortkeys)){
						$scorelist[$optionid] = $value['value'];
						$sortid=$scoresortid;
					}elseif($commentsortid&&in_array($optionid,$commentsortkeys)){
						$commentlist[$optionid] = $value['value'];
						$sortid=$commentsortid;
					}
					DB::query("INSERT INTO ".DB::table('plugin_pn_commentscore_typeoptionvar')." (sortid,tid,pid,fid,optionid,expiration,value) VALUES ('$sortid','$tid','$pid','$fid','$optionid','0','{$value['value']}')");
				}
			}

			$updateotherfieldarr=array('tid'=>$tid,'fid'=>$fid,'dateline'=>$_G['timestamp'],'expiration'=>0);
			if($scoresortid){
				$scorecalc=array();

				$scorecalc=scorecalc($scoresortid,$tid);
				$scorenum = $scorecalc[$tid]['scorenum'];
				foreach($scorecalc[$tid]['value'] as $field=>$value){
					$updatescorearr[$field]=$value;
				}
				$updatescorearr=array_merge($updatescorearr,$updateotherfieldarr);
				$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_optionvalue'.$scoresortid)." WHERE tid='$tid'");
				if($updatescorearr){
					if($count){
						DB::update('forum_optionvalue'.$scoresortid, $updatescorearr, array('tid' => $tid));
					}else{
						DB::insert('forum_optionvalue'.$scoresortid, $updatescorearr,false,true);
					}
				}

			}

			if($commentsortid){
				$commentcalc=array();

				$commentcalc=commentcalc($commentsortid,$tid);
				$commentnum = $commentcalc[$tid]['commentnum'];

				foreach($commentcalc[$tid]['value'] as $field=>$value){
					$updatecommentarr[$field]=$value;
				}
				$updatecommentarr=array_merge($updatecommentarr,$updateotherfieldarr);
				$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('forum_optionvalue'.$commentsortid)." WHERE tid='$tid'");
				if($updatecommentarr){
					if($count){
						DB::update('forum_optionvalue'.$commentsortid, $updatecommentarr, array('tid' => $tid));
					}else{
						DB::insert('forum_optionvalue'.$commentsortid, $updatecommentarr,false,true);
					}
				}
			}

			DB::query("INSERT INTO ".DB::table('plugin_pn_commentscore_post')." (pid,tid,fid,uid,score,comment,dateline) VALUES ('$pid','$tid','$fid','{$_G['uid']}','".daddslashes(serialize($scorelist))."','".daddslashes(serialize($commentlist))."','{$_G['timestamp']}')");
			$total = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_pn_commentscore_post')." WHERE tid=$tid");
			DB::query("REPLACE INTO ".DB::table('plugin_pn_commentscore_thread')." (tid,pid,fid,uid,typeid,sortid,total,scorenum,commentnum,scorecount,commentcount,dateline) VALUES ('$tid','$tpid','$fid','{$thread['authorid']}','{$thread['typeid']}','{$thread['sortid']}','$total','$scorenum','$commentnum','{$scorecalc[$tid]['scorecount']}','{$commentcalc[$tid]['commentcount']}','{$_G['timestamp']}')");

			$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_pn_commentscore_sort')." WHERE ftsid='$ftsid'");
			$sccount = scorecommentcount($fid,$thread['typeid'],$thread['sortid'],$scoresortid,$commentsortid);
			if($count){
				DB::update('plugin_pn_commentscore_sort', array('total'=>$sccount['total'],'scorecount'=>$sccount['scorecount'],'commentcount'=>$sccount['commentcount'],'dateline'=>$_G['timestamp']), array('ftsid' => $ftsid));
			}else{
				DB::insert('plugin_pn_commentscore_sort', array('ftsid'=>$ftsid,'total'=>$sccount['total'],'scorecount'=>$sccount['scorecount'],'commentcount'=>$sccount['commentcount'],'dateline'=>$_G['timestamp']));
			}


			showmessage(lang('plugin/pn_commentscore', 'success_post'), 'forum.php?mod=viewthread&tid='.$tid);
		}
	}
	showmessage(lang('plugin/pn_commentscore', 'error_post'), 'forum.php?mod=viewthread&tid='.$tid);
}
//From: Dism_taobao_com
?>