<?php

/**
*	[分类评分点评插件(pn_commentscore)] [DisM!] (C)2001-2099 DisM Inc.
*	Version: 1.0
*	Date: 2013-12-8 20:00
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class mobileplugin_pn_commentscore {
	function __construct(){
		global $_G;
		if($_G['forum']){
			include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/dataconvert.func.php';
			include_once libfile('function/forum');
			include_once libfile('function/forumlist');

			$this->defaultscname = $_G['cache']['plugin']['pn_commentscore']['sc_name'];
			$scoresetarr = explode("\n", str_replace(array("\r\n","\r","\n"), "\n", $_G['cache']['plugin']['pn_commentscore']['fids_sorids']));
			$classusergroups = explode("\n", str_replace(array("\r\n","\r","\n"), "\n",$_G['cache']['plugin']['pn_commentscore']['class_usergroups']));
			foreach($classusergroups as $row){
				$usergroup=explode('=',$row);
				$viewusergroup[$usergroup[0]]=explode(',',$usergroup[1]);
			}
			foreach($scoresetarr as $set){
				if($set){
					$setarr = explode('|',$set);
					$this->ftsids[]=$setarr[0];
					$setsortid=explode(',',$setarr[1]);
					$this->scoresortid[$setarr[0]]=$setsortid[0];
					$this->commentsortid[$setarr[0]]=$setsortid[1];
					$this->scorecount[$setarr[0]]=$setarr[2] ? $setarr[2] : 10;
					$this->scname[$setarr[0]]=$setarr[3];
					$limit=explode(',',$setarr[4]);
					$grouplimit=explode('/',$limit[0]);
					if($grouplimit[1]){
						$this->allowview[$setarr[0]] = in_array($_G['groupid'],$viewusergroup[$grouplimit[1]]) && $_G['group']['readaccess'] && ($_G['forum']['allowview'] != -1);
					}else{
						$this->allowview[$setarr[0]] = !((empty($_G['forum']['allowview']) && (!$_G['forum']['viewperm'] && !$_G['group']['readaccess'] || $_G['forum']['viewperm'] && !forumperm($_G['forum']['viewperm'])))|| ($_G['forum']['allowview'] == -1));
					}

					if($grouplimit[0]){
						$this->allowpost[$setarr[0]] = (in_array($_G['groupid'],$viewusergroup[$grouplimit[0]]) || array_intersect($viewusergroup[$grouplimit[0]],explode("\t",$_G['member']['extgroupids']))) && (!$_G['forum_thread']['closed'] && !checkautoclose($_G['forum_thread']));
					}else{
						$this->allowpost[$setarr[0]] = ! ($_G['forum']['allowreply'] != -1) && (($_G['forum_thread']['isgroup'] || (!$_G['forum_thread']['closed'] && !checkautoclose($_G['forum_thread']))) || $_G['forum']['ismoderator']) && ((!$_G['forum']['replyperm'] && $_G['group']['allowreply']) || ($_G['forum']['replyperm'] && forumperm($_G['forum']['replyperm'])) || $_G['forum']['allowreply']);
					}
				}
			}

			$this->fid = $_G['fid'];

			if(CURMODULE=='viewthread'){
				$this->tid = $_G['tid'];
				$typeid = $_G['forum_thread']['typeid'];
				$sortid = $_G['forum_thread']['sortid'];
				$this->ftsid = getftsid($_G['fid'],$typeid,$sortid);
			}

			if(CURMODULE=='forumdisplay'){
				$typeid=intval($_GET['typeid']);
				$sortid=intval($_GET['sortid']);
				$this->ftsid = getftsid($_G['fid'],$typeid,$sortid);

				if(in_array($this->ftsid , $this->ftsids)){
					if($this->scoresortid[$this->ftsid]){
						$scoresearch=scoresearch($this->scoresortid[$this->ftsid]);
					}
					if($this->commentsortid[$this->ftsid]){
						$commentsearch=commentsearch($this->commentsortid[$this->ftsid],$this->ftsid);
					}
				}
			}

			$this->typeid = $typeid;
			$this->sortid = $sortid;
			include_once template('pn_commentscore:thread');
		}


	}

	public function deletepost($params) {
		include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/delete.func.php';
		deletescpost($params,$this->scoresortid,$this->commentsortid);

	}

	public function deletethread($params) {
		include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/delete.func.php';
		deletescthread($params);
	}
}

class mobileplugin_pn_commentscore_forum extends mobileplugin_pn_commentscore {
	function viewthread_top_mobile_output(){
		global $_G,$postlist;
		if(is_array($postlist) && in_array($this->ftsid , $this->ftsids) && ($this->scoresortid[$this->ftsid] || $this->commentsorttid[$this->ftsid])){
			if($this->allowview[$this->ftsid] && $this->allowpost[$this->ftsid]){

				include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/thread.func.php';
				include_once libfile('function/threadsort');

				if($this->scoresortid[$this->ftsid]){
					$score = scoreshow($this->scoresortid[$this->ftsid] , array_keys($postlist) , $this->tid , intval($this->scorecount[$this->ftsid]));
				}else{
					$score=array();
				}
				if($this->commentsortid[$this->ftsid]){
					$comment = commentshow($this->commentsortid[$this->ftsid] , array_keys($postlist), $this->tid, 'mobile');
				}else{
					$comment = array();
				}
				if($this->commentsortid[$this->ftsid]||$this->scoresortid[$this->ftsid]){
					foreach($postlist as $id => $post) {
						if ($post['first']) {
							$scname = $this->scname[$this->ftsid] ? $this->scname[$this->ftsid] : $this->defaultscname;
							$scthread=scthreadshow($this->scoresortid[$this->ftsid] ,$this->commentsortid[$this->ftsid], $this->tid , intval($this->scorecount[$this->ftsid]),'viewthread',$scname);
							//$button = '<button id="scbutton" class="post_pn" onclick="javascript:window.location.href=this.value;" type="button" value="plugin.php?id=pn_commentscore:post&tid='.$this->tid.'"><strong>'.$scname.'</strong></button>';
							$postlist[$id]['message']=$postlist[$id]['message'].$scthread.$button;
						}
						else {
							$postlist[$id]['message']=$score[$id].$comment[$id].$postlist[$id]['message'];
						}
					}
				}
			}
			elseif(!$this->allowview[$this->ftsid] && $this->allowpost[$this->ftsid]){
				foreach($postlist as $id => $post) {
					if ($post['first']) {
						$scname = $this->scname[$this->ftsid] ? $this->scname[$this->ftsid] : $this->defaultscname;
						$postlist[$id]['message'] = "<a href=\"plugin.php?id=pn_commentscore:post&tid={$this->tid}\"><button id=\"scbutton\" class=\"scbutton\" type=\"button\" style=\"width:100%;background:{$_G['cache']['plugin']['pn_commentscore']['templatecolor']};border:0;color:#fff;border-radius: 4px;\">$scname</button></a>".$postlist[$id]['message'];
					}
				}
			}
			if($_G['cache']['plugin']['pn_commentscore']['icon']==2){
				$icon = 'heart.png';
			}elseif($_G['cache']['plugin']['pn_commentscore']['icon']==3){
				$icon = 'flower.png';
			}else{
				$icon = 'star.png';
			}
			if($_G['cache']['plugin']['pn_commentscore']['css']==2){
				$cn=1;
			}
			include_once template('pn_commentscore:css'.$cn);
			$css = show_m_css($icon);

			$css = '<style>'.$css.'</style>';
			return $css;
		}
		return;
	}

	function forumdisplay_top_mobile_output() {
		global $_G;
		$css='';
		if(in_array($this->ftsid , $this->ftsids) && is_array($_G['forum_threadlist']) && $this->allowview[$this->ftsid]){
			if($_G['cache']['plugin']['pn_commentscore']['css']==2){
				$cn=1;
			}
			if($_G['cache']['plugin']['pn_commentscore']['icon']==2){
				$icon = 'heart.png';
			}elseif($_G['cache']['plugin']['pn_commentscore']['icon']==3){
				$icon = 'flower.png';
			}else{
				$icon = 'star.png';
			}
			include_once template('pn_commentscore:css'.$cn);
			$css = show_mt_css($icon);

			$css = '<style>' . $css . '</style>';

			$tids=$return=array();
			foreach($_G['forum_threadlist'] as $thread) {
				$tids[]=$thread['tid'];
			}
			if($tids){
				include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/thread.func.php';
				$scorecomments = threadlistscoreshow($this->scoresortid, $this->commentsortid, $tids, $this->scorecount, $this->allowview);
				$i=0;
				foreach($_G['forum_threadlist'] as $id => $thread){
					$_G['forum_threadlist'][$id]['subject'] = ($scorecomments[$thread['tid']] ? $scorecomments[$thread['tid']] : '').$thread['subject'];
				}
			}

			return $css;
		}
		return;
	}

	//	function forumdisplay_thread_mobile_output(){
	//		global $_G;
	//		if(in_array($this->ftsid , $this->ftsids) && is_array($_G['forum_threadlist']) && $this->allowview[$this->ftsid]){
	//			$tids=$return=array();
	//			foreach($_G['forum_threadlist'] as $thread) {
	//				$tids[]=$thread['tid'];
	//			}
	//			if($tids){
	//				include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/thread.func.php';
	//				$scorecomments = threadlistscoreshow($this->scoresortid, $this->commentsortid, $tids, $this->scorecount, $this->allowview);
	//				$i=0;
	//				foreach($_G['forum_threadlist'] as $id => $thread){
	//					$return[$i] = $scorecomments[$thread['tid']] ? $scorecomments[$thread['tid']] : '';
	//					$i+=1;
	//				}
	//				return $return;
	//			}
	//		}
	//		return array();
	//	}

}
//From: Dism_taobao_com
?>