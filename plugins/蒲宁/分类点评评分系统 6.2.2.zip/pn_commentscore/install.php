<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access denied');
}
$sql = <<<EOT

CREATE TABLE IF NOT EXISTS `pre_plugin_pn_commentscore_diy` (
  `bid` int(10) NOT NULL,
  `csstyleid` mediumint(8) NOT NULL,
  `tdstyleid` mediumint(8) NOT NULL,
  `css` mediumtext NOT NULL,
  `html` mediumtext NOT NULL,
  `getvalue` mediumtext NOT NULL,
  PRIMARY KEY (`bid`)
);


CREATE TABLE IF NOT EXISTS `pre_plugin_pn_commentscore_post` (
  `pid` int(10) UNSIGNED NOT NULL,
  `tid` mediumint(8) UNSIGNED NOT NULL,
  `fid` mediumint(8) UNSIGNED NOT NULL,
  `uid` mediumint(8) NOT NULL,
  `score` text NOT NULL,
  `comment` text NOT NULL,
  `dateline` int(10) NOT NULL,
  PRIMARY KEY (`pid`),
  KEY `tid` (`tid`),
  KEY `uid` (`uid`),
  KEY `dateline` (`dateline`)
);


CREATE TABLE IF NOT EXISTS `pre_plugin_pn_commentscore_sort` (
  `ftsid` varchar(26) NOT NULL,
  `total` int(10) NOT NULL,
  `scorecount` mediumtext NOT NULL,
  `commentcount` mediumtext NOT NULL,
  `dateline` int(10) NOT NULL,
  KEY `ftsid` (`ftsid`)
);


CREATE TABLE IF NOT EXISTS `pre_plugin_pn_commentscore_thread` (
  `tid` mediumint(8) NOT NULL,
  `pid` int(10) NOT NULL,
  `fid` mediumint(8) NOT NULL,
  `uid` mediumint(8) NOT NULL,
  `typeid` smallint(6) NOT NULL,
  `sortid` smallint(6) NOT NULL,
  `total` mediumint(8) NOT NULL,
  `zonghepingfen` int(11) NOT NULL,
  `scorenum` mediumint(8) NOT NULL,
  `commentnum` mediumint(8) NOT NULL,
  `scorecount` mediumtext NOT NULL,
  `commentcount` mediumtext NOT NULL,
  `dateline` int(10) NOT NULL,
  PRIMARY KEY (`tid`)
);


CREATE TABLE IF NOT EXISTS `pre_plugin_pn_commentscore_typeoptionvar` (
  `sortid` smallint(6) UNSIGNED NOT NULL DEFAULT 0,
  `pid` mediumint(10) NOT NULL,
  `tid` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `fid` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `optionid` smallint(6) UNSIGNED NOT NULL DEFAULT 0,
  `expiration` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `value` mediumtext NOT NULL,
  KEY `sortid` (`sortid`),
  KEY `tid` (`tid`),
  KEY `fid` (`fid`)
);


EOT;

runquery($sql);
$finish = true;
?>
