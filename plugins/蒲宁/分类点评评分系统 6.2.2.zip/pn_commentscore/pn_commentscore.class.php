<?php

/**
*	[分类评分点评插件(pn_commentscore)] [DisM!] (C)2001-2099 DisM Inc.
*	Version: 1.0
*	Date: 2013-12-8 20:00
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_pn_commentscore {
	function __construct()
	{
		global $_G;
		if($_G['forum']){
			include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/dataconvert.func.php';
			include_once libfile('function/forum');
			include_once libfile('function/forumlist');
			$this->defaultscname = $_G['cache']['plugin']['pn_commentscore']['sc_name'];
			$scoresetarr = explode("\n", str_replace(array("\r\n","\r","\n"), "\n", $_G['cache']['plugin']['pn_commentscore']['fids_sorids']));
			$classusergroups = explode("\n", str_replace(array("\r\n","\r","\n"), "\n",$_G['cache']['plugin']['pn_commentscore']['class_usergroups']));
			foreach($classusergroups as $row){
				$usergroup=explode('=',$row);
				$viewusergroup[$usergroup[0]]=explode(',',$usergroup[1]);
			}
			foreach($scoresetarr as $set){
				if($set){
					$setarr = explode('|',$set);
					$this->ftsids[]=$setarr[0];
					$this->allowfilller[$setarr[0]]= $setarr[5] ? true : false;
					$setsortid=explode(',',$setarr[1]);
					$this->scoresortid[$setarr[0]]=$setsortid[0];
					$this->commentsortid[$setarr[0]]=$setsortid[1];
					$this->scorecount[$setarr[0]]=$setarr[2] ? $setarr[2] : 10;
					$this->scname[$setarr[0]]=$setarr[3];
					$limit=explode(',',$setarr[4]);
					$grouplimit=explode('/',$limit[0]);
					if($grouplimit[1]){
						$this->allowview[$setarr[0]] = (in_array($_G['groupid'],$viewusergroup[$grouplimit[1]]) ||  array_intersect($viewusergroup[$grouplimit[1]],explode("\t",$_G['member']['extgroupids']))) && $_G['group']['readaccess'] && ($_G['forum']['allowview'] != -1);
					}else{
						$this->allowview[$setarr[0]] = !((empty($_G['forum']['allowview']) && (!$_G['forum']['viewperm'] && !$_G['group']['readaccess'] || $_G['forum']['viewperm'] && !forumperm($_G['forum']['viewperm'])))|| ($_G['forum']['allowview'] == -1));
					}

					if($grouplimit[0]){
						$this->allowpost[$setarr[0]] = (in_array($_G['groupid'],$viewusergroup[$grouplimit[0]]) || array_intersect($viewusergroup[$grouplimit[0]],explode("\t",$_G['member']['extgroupids']))) && (!$_G['forum_thread']['closed'] && !checkautoclose($_G['forum_thread']));
					}else{
						$this->allowpost[$setarr[0]] = ! ($_G['forum']['allowreply'] != -1) && (($_G['forum_thread']['isgroup'] || (!$_G['forum_thread']['closed'] && !checkautoclose($_G['forum_thread']))) || $_G['forum']['ismoderator']) && ((!$_G['forum']['replyperm'] && $_G['group']['allowreply']) || ($_G['forum']['replyperm'] && forumperm($_G['forum']['replyperm'])) || $_G['forum']['allowreply']);
					}
					$commentstrlimit=explode('/',$limit[1]);
					$this->commentstrmin[$setarr[0]]=($commentstrlimit[0]!='') ? $commentstrlimit[0] : (!IN_MOBILE || !$_G['setting']['minpostsize_mobile'] ? $_G['setting']['minpostsize'] : $_G['setting']['minpostsize_mobile']);

				}
			}
			$this->fid = $_G['fid'];
			if(CURMODULE=='viewthread'){
				$this->tid = $_G['tid'];
				$typeid = $_G['forum_thread']['typeid'];
				$sortid = $_G['forum_thread']['sortid'];
				$this->ftsid = getftsid($_G['fid'],$typeid,$sortid);
			}
			if(CURMODULE=='forumdisplay'){
				$typeid=intval($_GET['typeid']);
				$sortid=intval($_GET['sortid']);
				$this->ftsid = getftsid($_G['fid'],$typeid,$sortid);

				if(in_array($this->ftsid , $this->ftsids)){
					if($this->scoresortid[$this->ftsid]){
						$scoresearch=scoresearch($this->scoresortid[$this->ftsid]);
					}
					if($this->commentsortid[$this->ftsid]){
						$commentsearch=commentsearch($this->commentsortid[$this->ftsid],$this->ftsid);
					}
					$this->scoresearch = $scoresearch;
					$this->commentsearch = $commentsearch;
					if($query_string = $_SERVER['QUERY_STRING']) {
						$query_string = substr($query_string, (strpos($query_string, "&") + 1));
						parse_str($query_string, $geturl);
						$this->geturl = daddslashes($geturl, 1);
					}
				}
			}
			$this->typeid = $typeid;
			$this->sortid = $sortid;
			include_once template('pn_commentscore:thread');
		}

	}

	public function deletepost($params) {
		include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/delete.func.php';
		deletescpost($params,$this->scoresortid,$this->commentsortid);
	}

	public function deletethread($params) {
		include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/delete.func.php';
		deletescthread($params,$this->scoresortid,$this->commentsortid);
	}

}

class plugin_pn_commentscore_forum extends plugin_pn_commentscore {
	function viewthread_beginline_output() {
		global $_G,$postlist;
		if(is_array($postlist) && in_array($this->ftsid , $this->ftsids) && ($this->scoresortid[$this->ftsid] || $this->commentsorttid[$this->ftsid])){
			if($this->allowview[$this->ftsid] && $this->allowpost[$this->ftsid]){
				include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/thread.func.php';
				include_once libfile('function/threadsort');

				if($this->scoresortid[$this->ftsid]){
					$score = scoreshow($this->scoresortid[$this->ftsid] , array_keys($postlist) , $this->tid , intval($this->scorecount[$this->ftsid]));
				}else{
					$score=array();
				}
				if($this->commentsortid[$this->ftsid]){
					$comment = commentshow($this->commentsortid[$this->ftsid] , array_keys($postlist), $this->tid);
				}else{
					$comment = array();
				}
				foreach($postlist as $id => $post) {
					if ($post['first']) {
						$scname = $this->scname[$this->ftsid] ? $this->scname[$this->ftsid] : $this->defaultscname;
						$scthread=scthreadshow($this->scoresortid[$this->ftsid] ,$this->commentsortid[$this->ftsid], $this->tid , intval($this->scorecount[$this->ftsid]),'viewthread',$scname);
						//$button = '<button id="scbutton" class="pn pnc vm" onclick="showWindow(\'comment\', this.value, \'get\', 0);" type="button" value="plugin.php?id=pn_commentscore:post&tid='.$this->tid.'"><strong>'.$scname.'</strong></button>';
						$postlist[$id]['message'] = $scthread.$button.$postlist[$id]['message'];
					}
					else {
						$postlist[$id]['message'] = $score[$id].$comment[$id].$postlist[$id]['message'];
					}
				}
			}
			elseif(!$this->allowview[$this->ftsid] && $this->allowpost[$this->ftsid]){
				foreach($postlist as $id => $post) {
					if ($post['first']) {
						$scname = $this->scname[$this->ftsid] ? $this->scname[$this->ftsid] : $this->defaultscname;
						$postlist[$id]['message'] = "<button id=\"scbutton\" onclick=\"showWindow('comment', this.value, 'get', 0);\" type=\"button\" value=\"plugin.php?id=pn_commentscore:post&tid={$this->tid}\"><strong>$scname</strong></button><br>".$postlist[$id]['message'];
					}
				}
			}

			if($_G['cache']['plugin']['pn_commentscore']['icon']==2){
				$icon = 'heart.png';
			}elseif($_G['cache']['plugin']['pn_commentscore']['icon']==3){
				$icon = 'flower.png';
			}else{
				$icon = 'star.png';
			}

			$cn='';
			if($_G['cache']['plugin']['pn_commentscore']['css']==2){
				$cn=1;
			}
			include_once template('pn_commentscore:css'.$cn);
			$css=post_css($icon);
			$css .= show_css($icon);

			$css = '<style>'.$css.'</style>';
			return $css;
		}
		return '';
	}

	function viewthread_useraction_output() {
		if(in_array($this->ftsid , $this->ftsids) && $this->allowpost[$this->ftsid] && ($this->scoresortid[$this->ftsid] || $this->commentsorttid[$this->ftsid])){
			$scname = $this->scname[$this->ftsid] ? $this->scname[$this->ftsid] : $this->defaultscname;
			return '<a title="" onclick="showWindow(\'comment\', this.href, \'get\', 0);" href="plugin.php?id=pn_commentscore:post&tid='.$this->tid.'"><i><img alt="" src="source/plugin/pn_commentscore/template/image/magic.png">'.$scname.'</i></a>';
		}
		return '';
	}

	function viewthread_fastpost_btn_extra_output() {
		if(in_array($this->ftsid , $this->ftsids) && $this->allowpost[$this->ftsid] && ($this->scoresortid[$this->ftsid] || $this->commentsorttid[$this->ftsid])){
			$scname = $this->scname[$this->ftsid] ? $this->scname[$this->ftsid] : $this->defaultscname;
			return '<button tabindex="5" class="pn pnc vm" onclick="showWindow(\'comment\', this.value, \'get\', 0);" type="button" value="plugin.php?id=pn_commentscore:post&tid='.$this->tid.'"><strong>'.$scname.'</strong></button>';
		}
		return '';
	}

	function forumdisplay_top_output() {
		global $_G;
		if(in_array($this->ftsid , $this->ftsids) && is_array($_G['forum_threadlist']) && $this->allowview[$this->ftsid]){
			$popmenu='';

			if($this->allowfilller){
				if($this->geturl && is_array($this->geturl)) {
					$allowscorderby = $allowscsearch = false;
					//if(is_array($this->scoresearch)) {
					//foreach($this->scoresearch as $option) {
					//$sidentifier[]=$option['identifier'];
					//}
					//}
					foreach($this->geturl as $option => $value) {
						$allurladd .= !in_array($option, array('orderby', 'fid' ,'filter')) ? '&amp;'.rawurlencode($option).'='.rawurlencode($value) : '';
					}
					if(is_array($this->commentsearch)) {
						foreach($this->commentsearch as $option) {
							$identifier = $option['identifier'];
							foreach($this->geturl as $option => $value) {
								$c_sorturladdarray[$identifier] .= !in_array($option, array('fid','searchscsort','filter', $identifier)) ? '&amp;'.rawurlencode($option).'='.rawurlencode($value) : '';
							}
						}
					}
				}
				$popmenu=tpl_pn_commentsocre_forumdisplay_top_output($this->scoresearch,$this->commentsearch,$c_sorturladdarray,$allurladd);
			}
			$cn='';
			if($_G['cache']['plugin']['pn_commentscore']['css']==2){
				$cn=1;
			}
			if($_G['cache']['plugin']['pn_commentscore']['icon']==2){
				$icon = 'heart.png';
			}elseif($_G['cache']['plugin']['pn_commentscore']['icon']==3){
				$icon = 'flower.png';
			}else{
				$icon = 'star.png';
			}
			include_once template('pn_commentscore:css'.$cn);
			$css = show_t_css($icon);
			$css = '<style>'.$css.'</style>';
			//			$tids=$return=array();
			//			foreach($_G['forum_threadlist'] as $thread) {
			//				$tids[]=$thread['tid'];
			//			}
			//			if($tids){
			//				include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/thread.func.php';
			//				$scorecomments = threadlistscoreshow($this->scoresortid, $this->commentsortid, $tids, $this->scorecount, $this->allowview);
			//				$i=0;
			//				foreach($_G['forum_threadlist'] as $id => $thread){
			//					$_G['forum_threadlist'][$id]['subject'] = ($scorecomments[$thread['tid']] ? $scorecomments[$thread['tid']] : '').$thread['subject'];
			//				}
			//			}
			return $css.$popmenu;
		}
		return '';
	}

	//	function  forumdisplay_thread_subject_output() {
	//		global $_G;
	//		if(in_array($this->ftsid , $this->ftsids) && is_array($_G['forum_threadlist']) && $this->allowview[$this->ftsid] && (empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle'])){
	//			$tids=array();
	//			foreach($_G['forum_threadlist'] as $thread) {
	//				$tids[]=$thread['tid'];
	//			}
	//			if($tids){
	//				include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/thread.func.php';
	//				$scorecomments = threadlistscoreshow($this->scoresortid, $this->commentsortid, $tids, $this->scorecount, $this->allowview);
	//				$i=0;
	//				foreach($_G['forum_threadlist'] as $id => $thread){
	//					$return[$i] = $scorecomments[$thread['tid']] ? $scorecomments[$thread['tid']] : '';
	//					$i+=1;
	//				}
	//				return $return;
	//			}
	//		}
	//	}

	function  forumdisplay_thread_output() {
		global $_G;
		if(in_array($this->ftsid , $this->ftsids) && is_array($_G['forum_threadlist']) && $this->allowview[$this->ftsid]){
			$tids=array();
			foreach($_G['forum_threadlist'] as $thread) {
				$tids[]=$thread['tid'];
			}
			if($tids){
				include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/thread.func.php';
				$scorecomments = threadlistscoreshow($this->scoresortid, $this->commentsortid, $tids, $this->scorecount, $this->allowview);
				$i=0;
				foreach($_G['forum_threadlist'] as $id => $thread){
					$return[$i] = $scorecomments[$thread['tid']] ? $scorecomments[$thread['tid']] : '';
					$i+=1;
				}
				return $return;
			}
		}
		return array();
	}

	function forumdisplay() {
		global $_G;
		if(in_array($this->ftsid , $this->ftsids) && $this->allowview[$this->ftsid] && $_GET['filter']=='scsort' && $this->allowfilller[$this->ftsid]){
			include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/thread.func.php';
			include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/module/forum_forumdisplay.php';
			exit;
		}
	}

	function forumdisplay_filter_extra_output(){
		if($this->allowfilller){
			global $_G;
			if(in_array($this->ftsid , $this->ftsids) && is_array($_G['forum_threadlist']) && $this->allowview[$this->ftsid] && $this->allowfilller[$this->ftsid]){
				foreach($this->commentsearch as $coption){
					foreach($this->geturl as $option => $value) {
						if($coption['type']=='select'){
							$cfiltername[$coption['identifier']] = ($coption['identifier']==$option) ? $coption['choices'][$value]['content'] : '';
						}else{
							$cfiltername[$coption['identifier']] = ($coption['identifier']==$option) ? $coption['choices'][$value] : '';
						}
						if($cfiltername[$coption['identifier']]) break;
					}
				}
				foreach($this->scoresearch as $soption){
					foreach($this->geturl as $option => $value) {
						$sfiltername = ($soption['identifier']==$value && $option=='orderby') ? $soption['title'] : '';
						if($sfiltername) break;
					}
					if($sfiltername) break;
				}
				foreach($this->scoresearch as $option){
					$scoreidentifier[]=$option['identifier'];
				}
				return tpl_pn_commentsocre_forumdisplay_filter_extra_output($scoreidentifier,$this->commentsearch,$sfiltername,$cfiltername);
			}
		}
		return '';
	}
}
//From: Dism_taobao_com
?>