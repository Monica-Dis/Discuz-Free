<?php
/**
*	[分类评分点评插件(pn_commentscore)] [DisM!] (C)2001-2099 DisM Inc.
*	Version: 1.0
*	Date: 2013-12-8 20:00
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
if(!submitcheck('updatesubmit')){
	showtips(lang('plugin/pn_commentscore', 'update_tips'));
	showformheader('plugins&operation=config&identifier=pn_commentscore&pmod=update');
	showtableheader('');
	showsubmit('updatesubmit');
	showtablefooter();
	showformfooter();
} else {
	global $_G;
	loadcache('plugin');
	DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_thread')."` t1 LEFT JOIN `".DB::table('forum_thread')."` t2 ON t1.tid=t2.tid WHERE t2.tid IS NULL OR t2.displayorder<0");
	DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_post')."` t1 LEFT JOIN `".DB::table('forum_post')."` t2 ON t1.pid=t2.pid WHERE t2.pid IS NULL OR t2.invisible<0");
	DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_post')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_thread')."` t2 ON t1.tid=t2.tid WHERE t2.tid IS NULL");
	DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_thread')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_post')."` t2 ON t1.tid=t2.tid WHERE t2.tid IS NULL");
	DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_typeoptionvar')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_post')."` t2 ON t1.pid=t2.pid WHERE t2.pid IS NULL");
	DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_post')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_typeoptionvar')."` t2 ON t1.pid=t2.pid WHERE t2.pid IS NULL");

	$scoresetarr = explode("\n", str_replace(array("\r\n","\r","\n"), "\n", $_G['cache']['plugin']['pn_commentscore']['fids_sorids']));

	foreach($scoresetarr as $set){
		if($set){
			$setarr = explode("|",$set);
			$setsortid=explode(",",$setarr[1]);
			$scsortids[$setarr[0]]['s']=$setsortid[0];
			$scsortids[$setarr[0]]['c']=$setsortid[1];
		}
	}
	$scoresortid=array_unique($scoresortid);
	$commentsortid=array_unique($commentsortid);
	$scsortid=array_merge($scoresortid,$commentsortid);
	foreach($scsortid as $sortid){
		DB::query("DELETE t1 FROM `".DB::table('forum_optionvalue'.$sortid)."` t1 LEFT JOIN `".DB::table('forum_thread')."` t2 ON t1.tid=t2.tid WHERE t2.tid IS NULL");
		DB::query("DELETE t1 FROM `".DB::table('forum_optionvalue'.$sortid)."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_thread')."` t2 ON t1.tid=t2.tid WHERE t2.tid IS NULL");
	}

	include_once DISCUZ_ROOT.'./source/plugin/pn_commentscore/function/thread.func.php';

	foreach($scsortids as $ftsid=>$scsortid){
		if($scsortid['s']){
			$scorecalc=scorecalc($scsortid['s'],'');
			foreach($scorecalc as $tid=>$option){
				DB::update('forum_optionvalue'.$scsortid['s'], $option['value'], array('tid' => $tid));
				DB::update('plugin_pn_commentscore_thread', array('scorenum'=>$option['scorenum'],'scorecount'=>$option['scorecount']), array('tid' => $tid));
			}


		}
		if($scsortid['c']){
			$commentcalc=commentcalc($scsortid['c'],'');
			foreach($commentcalc as $tid=>$option){
				DB::update('forum_optionvalue'.$scsortid['c'], $option['value'], array('tid' => $tid));
				DB::update('plugin_pn_commentscore_thread', array('commentnum'=>$option['commentnum'],'commentcount'=>$option['commentcount']), array('tid' => $tid));
			}


		}
		$fts = explode('.',$ftsid);
		$fts[0]=$fts[0] ? $fts[0] : 0;
		$fts[1]=$fts[1] ? $fts[1] : 0;
		$fts[2]=$fts[2] ? $fts[2] : 0;
		$count=scorecommentcount($fts[0],$fts[1],$fts[2],$scsortid['s'],$scsortid['c']);
		DB::update('plugin_pn_commentscore_sort', array('total'=>$count['total'],'scorecount'=>$count['scorecount'],'commentcount'=>$count['commentcount'],'dateline'=>$_G['timestamp']), array('ftsid' => $ftsid));

	}

	$scthread = DB::fetch_all("SELECT tid FROM ".DB::table('plugin_pn_commentscore_thread')." WHERE 1>0");
	foreach($scthread as $thread){
		$tid=$thread['tid'];
		$sctotal = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_pn_commentscore_post')." WHERE tid='$tid'");
		DB::update('plugin_pn_commentscore_thread', array('total'=>$sctotal,'dateline'=>$_G['timestamp']), array('tid' => $tid));
	}
	DB::query("DELETE FROM `".DB::table('plugin_pn_commentscore_thread')."` WHERE total=0");
	DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_post')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_thread')."` t2 ON t1.tid=t2.tid WHERE t2.tid IS NULL");
	DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_thread')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_post')."` t2 ON t1.tid=t2.tid WHERE t2.tid IS NULL");
	DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_typeoptionvar')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_post')."` t2 ON t1.pid=t2.pid WHERE t2.pid IS NULL");
	DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_post')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_typeoptionvar')."` t2 ON t1.pid=t2.pid WHERE t2.pid IS NULL");
//	DB::query("DELETE t1 FROM `".DB::table('plugin_pn_commentscore_atuser')."` t1 LEFT JOIN `".DB::table('plugin_pn_commentscore_thread')."` t2 ON t1.tid=t2.tid WHERE t2.tid IS NULL");
	cpmsg(lang('plugin/pn_commentscore', 'success_update'),'action=plugins&operation=config&identifier=pn_commentscore&pmod=update','succeed');
}

//From: Dism_taobao-com
?>
