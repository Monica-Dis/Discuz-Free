<?php

/**
 *      $Id: 2018-08-24 01:04:24Z puning $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


class mobileplugin_pn_readperm_forum {

	function post_mobile_pn_readperm_message($params) {
		if($params['param'][0] != 'post_newthread_succeed'){
			return false;
		}
		$threadValue = $params['param'][2];
		global $_G;	
		$forumset =array();
		$forumset = explode("\n", str_replace(array("\r\n","\r","\n"), "\n", $_G['cache']['plugin']['pn_readperm']['forumset']));
		foreach($forumset as $items) {
			$forums_item = explode('|', $items);
			if($threadValue['fid']==$forums_item[0]){
				DB::update('forum_thread', array('readperm' => $forums_item[1],'status' => $forums_item[2]), array('tid'=>$threadValue['tid']));
				break;
			}
		}
		return true;
	}

}
//From: Dism_taobao-com
?>
