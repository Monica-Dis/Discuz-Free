<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ') ) {
	exit('Access Denied');
}


global $_G;
loadcache('plugin');
$config = $_G['cache']['plugin']['zhuan_tbkmall'];

$nav = $config['nav'];
$focus = $config['focus'];
$focus_arr = explode("\n",$focus);

$miaosha = $config['miaosha'];
$haibao = $config['haibao'];
$haibao_arr = explode("\n",$haibao);
$newhaibaoitem=array();
foreach($haibao_arr as $key=>$val){
	$item = explode("|",$val);
	$newhaibaoitem[]=$item;
}

$nav_arr = explode("\n",$nav);

$charset = $_G['config']['output']['charset'];
if($charset!="gbk"){
	$charset="utf8";
}

$newitem=array();
foreach($nav_arr as $key=>$val){
	$item = explode("|",$val);
	$newitem[]=$item;
}

require_once DISCUZ_ROOT."./source/plugin/zhuan_tbkmall/class/class_tbk.php";
$tbk = new tbk();
$res = $tbk->Material();

//print_r($res);

$recommand=array();
$goods=array();
foreach($res['data'] as $k=>$v){
	$id = $v['id'];

	$privilege = $tbk->privilege($id);
	
	$priv = json_decode($privilege,true);
	
	//print_r($priv);
	
	$array['title'] = $v['title'];
	$array['upgradMoney'] = $v['upgradMoney'];
	$array['soldCount'] = $v['soldCount'];
	$array['image'] = $v['imgs'][0]['image'];
	$array['oldPrice'] = $v['oldPrice'];

	$array['coupon_click_url'] = $priv['result']['data']['coupon_click_url'];
	$array['coupon_remain_count'] = $priv['result']['data']['coupon_remain_count'];
	$array['coupon_end_time'] = $priv['result']['data']['coupon_end_time'];
	$array['item_url'] = $priv['result']['data']['item_url'];
	$array['coupon_info'] = $priv['result']['data']['coupon_info'];

	preg_match_all("/(\d+)/",$priv['result']['data']['coupon_info'],$match);
	$array['coupon'] = $match[0][1];	
	$array['price'] = $v['oldPrice'] - $array['coupon'];
	
	if($k < 4){
		$recommand[]=$array;
	}else{
		$goods[]=$array;
	}
	
}

include template("zhuan_tbkmall:$charset/nav");

?>