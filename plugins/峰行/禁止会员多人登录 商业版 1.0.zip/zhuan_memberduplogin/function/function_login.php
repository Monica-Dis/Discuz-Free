<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

  function banuser($uid, $bangroupid = 4) {

  	DB::query("UPDATE ".DB::table('common_member')." SET adminid = -1,groupid = 4  WHERE uid='$uid'");  
  	       
    return true;
  }     
  
  
  	function exitdiscuz()
	{
				global $_G;
				loadcache('plugin');
				$config = $_G['cache']['plugin']['zhuan_memberduplogin'];
				$offline = $config['offline'];

				$uid = $_G['uid'];

				require_once libfile('function/misc');
				require_once libfile('function/member'); 
				require_once libfile('class/member'); 
 				
				$_GET['formhash'] = $_G['formhash']; 
 				
				require_once libfile('function/misc');
				loaducenter();
				
				$ucsynlogout = $setting['allowsynlogin'] ? uc_user_synlogout() : '';
				
				echo $_GET['formhash'];
				echo $_G['formhash'];
				
				if($_GET['formhash'] != $_G['formhash']) {
					showmessage('logout_succeed', dreferer(), array('formhash' => FORMHASH, 'ucsynlogout' => $ucsynlogout, 'referer' => rawurlencode(dreferer())));
				}
				
				clearcookies();
				
				$_G['groupid'] = $_G['member']['groupid'] = 7;
				$_G['uid'] = $_G['member']['uid'] = 0;
				$_G['username'] = $_G['member']['username'] = $_G['member']['password'] = '';
				$_G['setting']['styleid'] = $setting['styleid'];
				$_G['cookie']['sid1'] = '';

				showmessage('logout_succeed', dreferer(), array('formhash' => FORMHASH, 'ucsynlogout' => $ucsynlogout, 'referer' => rawurlencode(dreferer())));

				showmessage($offline);
	}
	
	
	function userrecord()
	{
		global $_G;
		$uid = $_G['uid'];
		$ip = $_G['clientip'];
		$authkey = $_G['cookie']['auth'];

		if($uid){

			$fetch = DB::fetch_first("SELECT * FROM ".DB::table('zhuan_memberduplogin')." WHERE uid = '$uid' and authkey='$authkey'");
			if($fetch){ //�Ѿ���¼
				return $fetch['id'];
			}
		}

		return 0;
	}
	
	/*�û�ָ��*/
	function userfinger($uid)
	{
		if($uid > 0){
			$fetch = DB::fetch_first("SELECT * FROM ".DB::table('zhuan_memberduplogin')." WHERE uid = '$uid' order by id desc");
			return $fetch['id'];
		}else{
			return 0;
		}

	}
	function updateuser()
	{
		global $_G;
		$uid = $_G['uid'];
		$ip = $_G['clientip'];
		$authkey = $_G['cookie']['auth'];

		if($uid){

			$fetch = DB::update("zhuan_memberduplogin",array('authkey'=>$authkey,
			'ip'=>$ip),array('uid'=>$uid));
			
		}

		return 0;
	}
	
	function userlog()
	{
		global $_G;
		$uid = $_G['uid'];
		$ip = $_G['clientip'];
		$authkey = $_G['cookie']['auth'];
		$user = getuserbyuid($uid);
		

			$fetch = DB::fetch_first("SELECT * FROM ".DB::table('zhuan_memberduplogin')." WHERE uid = '$uid'");
			
			DB::insert('zhuan_memberduplogin_log',array('offuid'=>$uid,
			'offtime'=>dgmdate(TIMESTAMP),
			'loginip'=>$ip,
			'loginauth'=>$authkey,
			'offip'=>$fetch['ip'],
			'offauth'=>$fetch['authkey'],
			'username'=>$user['username'],
			));

	}
	
	function insertuser()
	{
		global $_G;
		$uid = $_G['uid'];
		$ip = $_G['clientip'];
		$authkey = $_G['cookie']['auth'];
		
		if($uid > 0){
				$insert = DB::insert('zhuan_memberduplogin',array('authkey'=>$authkey,
				'uid'=>$uid,
				'useragent'=>$_SERVER['HTTP_USER_AGENT'],
				'ip'=>$_G['clientip'],
				'createtime'=>dgmdate(TIMESTAMP)),true);
		}

		
		return $insert;
	}
	
?>