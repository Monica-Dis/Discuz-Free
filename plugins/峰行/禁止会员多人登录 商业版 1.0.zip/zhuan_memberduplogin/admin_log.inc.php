<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$mod=$_GET['mod'];
$formhash=$_GET['formhash'];

if(submitcheck('delete')&&$_GET['ids']){
	$list = dimplode($_GET['ids']);

	DB::query("DELETE FROM ".DB::table('zhuan_memberduplogin_log')." WHERE id in(".dimplode($_GET['ids']).")");
	
	cpmsg(plang('success'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=zhuan_memberduplogin&pmod=admin_log', 'succeed');
	
}
else{
$ukey = daddslashes($_GET['ukey']);
$perpage = 20;
$start = ($page-1)*$perpage;
$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=zhuan_memberduplogin&pmod=admin_log';

if(!empty($ukey)){
$query=DB::query("SELECT * FROM ".DB::table('zhuan_memberduplogin_log')." WHERE username LIKE '%$ukey%' ");
$count = 1;
}
else{
$query=DB::query("SELECT * FROM ".DB::table('zhuan_memberduplogin_log')." ORDER BY id DESC LIMIT $start,$perpage");
$count = DB::num_rows(DB::query('SELECT id FROM '.DB::table('zhuan_memberduplogin_log')));
}
showtips(plang('info'));


showformheader('plugins&operation=config&do='.$pluginid.'&identifier=zhuan_memberduplogin&pmod=admin_log');
$html = <<<EOF
<div style="float:right;">
<input type="hidden" name="id" value="index">
<input type="hidden" name="FORMHASH" value="{FORMHASH}">
<div class="m_fr tuansearch">&#x641C;&#x7D22;&#x8D26;&#x6237; <input type="text" name="ukey" value="{$ukey}"> 
	<select name="searchtype">
	<option value="0">&#x8D26;&#x6237;</option>
	</select> 
	<input type="submit" class="plr5 pn pnc" name="searchsubmit" id="editsubmit" value="&#x641C;&#x7D22;">
</div>
</div>
EOF;
    
echo $html;
showformfooter();
showtablefooter();/*Dism��taobao-com*/

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=zhuan_memberduplogin&pmod=admin_log');
showtableheader(plang('admin_info'), '');

showsubtitle(array('','ID','UID',plang('offlinetime'), plang('offlineuser'),plang('loginip'),plang('offlineip'), plang('userstatus')));

if($count){
	while($r = DB::fetch($query)) {
		$userlist[$r['uid']] = $r['uid'];
		$grouplist[$r['buygroup']] = $r['buygroup'];
		$cardlist[] = $r;
	}
	if($userlist) {
		$members = C::t('common_member')->fetch_all($userlist);
		unset($userlist);
	}

	if($grouplist){
		$glt = C::t('common_usergroup')->fetch_all($grouplist);
		unset($grouplist);
	}

	foreach($cardlist AS $key => $val) {
		$offuid = getuserbyuid($val['offuid']);

		showtablerow('', array('class="smallefont"', '', '', '', '', '', ''), array(
						"<input type=\"checkbox\" class=\"checkbox\" name=\"ids[]\" value=\"$val[id]\">",
						$val['id'],
						$val['offuid'],
						dgmdate($val['offtime']),
						$val['username'],
						$val['loginip'],
						$val['offip'],
						$offuid['groupid']
						)
					);
	
	}
	$multipage = multi($count, $perpage, $page, $mpurl);
		
	showsubmit('', '', '', '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" /><label for="chkall">'.plang('admin_delete').'</label>&nbsp;&nbsp;
					<input type="submit" class="btn" name="delete" value="'.plang('admin_submit').'" onclick="if(confirm(\''.plang('admin_del').'\')){this.form.submit();}else {return false;}"/>&nbsp;&nbsp;', $multipage);
					

	
}
showtablefooter();/*Dism��taobao-com*/
showformfooter();

	
}

function plang($str) {
	return lang('plugin/zhuan_memberduplogin', $str);
}

//From: Dism_taobao-com
?>