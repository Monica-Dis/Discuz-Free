<?php
/**
 * Copyright 2001-2099 DisM!(dism.taobao.com)
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (! defined ( 'IN_DISCUZ' ) || ! defined ( 'IN_ADMINCP' )) {
	exit ( 'Access Denied' );
}
$sql = <<<EOF
DROP TABLE IF EXISTS `pre_sunju_adfloor`;
CREATE TABLE `pre_sunju_adfloor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ad_title` varchar(50) NOT NULL,
  `ad_path` varchar(50) NOT NULL,
  `ad_target` varchar(100) NOT NULL,
  `ad_type` tinyint(1) NOT NULL,
  `ad_pos` tinyint(1) NOT NULL,
  `ad_show` tinyint(1) NOT NULL DEFAULT '1',
  `ad_sort` tinyint(4) NOT NULL DEFAULT '0',
  `ad_op_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27;

DROP TABLE IF EXISTS `pre_sunju_adfloor_config`;
CREATE TABLE `pre_sunju_adfloor_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ad_config` varchar(100) NOT NULL,
  `ad_type` tinyint(1) NOT NULL DEFAULT '0',
  `ad_flag` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5;

INSERT INTO `pre_sunju_adfloor_config` VALUES ('1', '{$installlang["config_1"]}', '100', 'tit_left');
INSERT INTO `pre_sunju_adfloor_config` VALUES ('2', '{$installlang["config_2"]}', '100', 'tit_right');
INSERT INTO `pre_sunju_adfloor_config` VALUES ('3', '{$installlang["config_3"]}', '101', 'tit_left');
INSERT INTO `pre_sunju_adfloor_config` VALUES ('4', '{$installlang["config_4"]}', '101', 'tit_right');

INSERT INTO `pre_sunju_adfloor` VALUES ('1', '{$installlang["title_1"]}', '2017-06-23/594cee4d87e5a.jpg', 'javascript:void(0)', '1', '1', '1', '0', '1498213969');
INSERT INTO `pre_sunju_adfloor` VALUES ('2', '{$installlang["title_2"]}', '2017-06-23/594cee60cdbf1.png', 'javascript:void(0)', '1', '2', '1', '0', '1498213991');
INSERT INTO `pre_sunju_adfloor` VALUES ('3', '', '2017-06-23/594cee76b852f.png', 'javascript:void(0)', '1', '3', '1', '0', '1498214008');
INSERT INTO `pre_sunju_adfloor` VALUES ('4', '', '2017-06-23/594cee84a191a.png', 'javascript:void(0)', '1', '3', '1', '0', '1498214023');
INSERT INTO `pre_sunju_adfloor` VALUES ('5', '', '2017-06-23/594cee9057c1f.png', 'javascript:void(0)', '1', '3', '1', '0', '1498214035');
INSERT INTO `pre_sunju_adfloor` VALUES ('6', '', '2017-06-23/594cee9d37777.png', 'javascript:void(0)', '1', '3', '1', '0', '1498214047');
INSERT INTO `pre_sunju_adfloor` VALUES ('7', '', '2017-06-23/594ceea90ca9c.png', 'javascript:void(0)', '1', '3', '1', '0', '1498214059');
INSERT INTO `pre_sunju_adfloor` VALUES ('8', '', '2017-06-23/594ceeb5d21b8.png', 'javascript:void(0)', '1', '3', '1', '0', '1498214072');
INSERT INTO `pre_sunju_adfloor` VALUES ('9', '', '2017-06-23/594ceed0071a9.png', 'javascript:void(0)', '1', '3', '1', '0', '1498214098');
INSERT INTO `pre_sunju_adfloor` VALUES ('10', '', '2017-06-23/594ceee0d69d5.png', 'javascript:void(0)', '1', '3', '1', '0', '1498214115');
INSERT INTO `pre_sunju_adfloor` VALUES ('11', '', '2017-06-23/594ceeecb39fb.png', 'javascript:void(0)', '1', '3', '1', '0', '1498214127');
INSERT INTO `pre_sunju_adfloor` VALUES ('12', '', '2017-06-23/594ceefc33e90.png', 'javascript:void(0)', '1', '3', '1', '0', '1498214142');
INSERT INTO `pre_sunju_adfloor` VALUES ('13', '', '2017-06-23/594cef0939b51.png', 'javascript:void(0)', '1', '3', '1', '0', '1498214155');
INSERT INTO `pre_sunju_adfloor` VALUES ('14', '{$installlang["title_3"]}', '2017-06-23/594cef23bf227.jpg', 'javascript:void(0)', '2', '1', '1', '0', '1498214182');
INSERT INTO `pre_sunju_adfloor` VALUES ('15', '{$installlang["title_4"]}', '2017-06-23/594cef3292e87.jpg', 'javascript:void(0)', '2', '2', '1', '0', '1498214197');
INSERT INTO `pre_sunju_adfloor` VALUES ('16', '', '2017-06-23/594cef56c8e17.jpg', 'javascript:void(0)', '2', '3', '1', '0', '1498214233');
INSERT INTO `pre_sunju_adfloor` VALUES ('17', '', '2017-06-23/594cef5fb8e46.jpg', 'javascript:void(0)', '2', '3', '1', '0', '1498214241');
INSERT INTO `pre_sunju_adfloor` VALUES ('18', '', '2017-06-23/594cef69d51c0.jpg', 'javascript:void(0)', '2', '3', '1', '0', '1498214251');
INSERT INTO `pre_sunju_adfloor` VALUES ('19', '', '2017-06-23/594cef751deac.jpg', 'javascript:void(0)', '2', '3', '1', '0', '1498214263');
INSERT INTO `pre_sunju_adfloor` VALUES ('20', '', '2017-06-23/594cef820149d.jpg', 'javascript:void(0)', '2', '3', '1', '0', '1498214276');
INSERT INTO `pre_sunju_adfloor` VALUES ('21', '', '2017-06-23/594cef8ae6e7c.jpg', 'javascript:void(0)', '2', '3', '1', '0', '1498214284');
INSERT INTO `pre_sunju_adfloor` VALUES ('22', '', '2017-06-23/594cf04fa2da0.jpg', 'javascript:void(0)', '2', '3', '1', '0', '1498214481');
INSERT INTO `pre_sunju_adfloor` VALUES ('23', '', '2017-06-23/594cf05e47bf4.jpg', 'javascript:void(0)', '2', '3', '1', '0', '1498214495');
INSERT INTO `pre_sunju_adfloor` VALUES ('24', '', '2017-06-23/594cf068b544a.jpg', 'javascript:void(0)', '2', '3', '1', '0', '1498214506');
INSERT INTO `pre_sunju_adfloor` VALUES ('25', '', '2017-06-23/594cf072eae0b.jpg', 'javascript:void(0)', '2', '3', '1', '0', '1498214516');
INSERT INTO `pre_sunju_adfloor` VALUES ('26', '', '2017-06-23/594cf08ec1462.jpg', 'javascript:void(0)', '2', '3', '1', '0', '1498214544');
EOF;

runquery ( $sql );

$finish = TRUE;
?>