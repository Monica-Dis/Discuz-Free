<?php
/**
 * Copyright 2001-2099 DisM!(dism.taobao.com)
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (! defined ( 'IN_DISCUZ' )) {
	exit ( 'Access Denied' );
}

if(defined('IN_ADMINCP')) loadcache('plugin');

class SUNJU_ADFLOOR {

	public static $PL_G, $PL_NAME, $PL_STATIC, $PL_UPLOAD_PATH;

	public function __construct($PL_NAME) {
		self::init($PL_NAME);
	}

	public static function init($PL_NAME) {
		global $_G;
		self::$PL_NAME = $PL_NAME;
		self::$PL_G    = $_G['cache']['plugin'][self::$PL_NAME];
		self::$PL_STATIC = 'source/plugin/'.self::$PL_NAME.'/public/';
		self::$PL_UPLOAD_PATH = self::$PL_STATIC."/upload/";
	}
	
	public static function doUpdateById($data, $id){
		if(empty($id) || empty($data)) return false;
		$field = array("ad_title","ad_path","ad_target","ad_type","ad_pos","ad_show","ad_sort");
		foreach($data as $k=>$v){
			if(in_array($k,$field)){
				$update[$k] = $data[$k];
			}
		}
		if(isset($update)){
			$re = DB::update('sunju_adfloor', $update, "id=".$id);
			return $re === false ? false : true;
		}else{
			return false;
		}
	}
	
	public static function doGetSourceList($param){
		if(!is_array($param)) return false;
    	$options = array (
    			'id' 		=> '',
    			'ad_type' 	=> '',
    			'ad_pos' 	=> '',
    			'ad_show' 	=> '',
    			'isCount' 	=> 0,
    			'limit' 	=> 10,
    	);
    	$param = array_merge($options, $param);
    	$wheres = 'WHERE 1';
    	if($param['id']){
    		$wheres .= " AND id = {$param['id']}";
    	}
		if($param['ad_type']){
    		$wheres .= " AND ad_type = {$param['ad_type']}";
    	}
    	if($param['ad_pos']){
    		$wheres .= " AND ad_pos = {$param['ad_pos']}";
    	}
    	if($param['ad_show']){
    		$wheres .= " AND ad_show = {$param['ad_show']}";
    	}

    	$order = "ORDER BY ad_sort ASC,id DESC";
		if ($param['isCount'] == 1) {
    		$result = DB::result_first("SELECT COUNT(1) FROM ".DB::table('sunju_adfloor')." {$wheres}");
    	} else {
    		$page  = max(intval($_GET['page']), 1);
    		$start = ($page - 1) * $param['limit'];
	    	$result = DB::fetch_all("SELECT * FROM ".DB::table('sunju_adfloor')." {$wheres} {$order}".DB::limit($start, $param['limit']));
    	}
    	return $result;
	}
	
	public static function doGetConfigByType($type){
		if(empty($type)) return array();
		return DB::fetch_all("SELECT * FROM ".DB::table('sunju_adfloor_config')." WHERE ad_type = {$type}");
	}
	
	public static function doUpdateConfigById($data, $id){
		if(empty($id) || empty($data)) return false;
		$field = array("ad_config","ad_type","ad_flag");
		foreach($data as $k=>$v){
			if(in_array($k,$field)){
				$update[$k] = $data[$k];
			}
		}
		if(isset($update)){
			$re = DB::update('sunju_adfloor_config', $update, "id=".$id);
			return $re === false ? false : true;
		}else{
			return false;
		}
	}
	
	public static function doAjaxReturn($code,$msg="return",$data=array()){
		array_push($data,array("formhash"=>FORMHASH));
		return urldecode(json_encode(array("code"=>$code,"data"=>$data,"msg"=>urlencode($msg))));
	}
	
	public function debug(){
		error_reporting(E_ALL ^ E_NOTICE);
		ini_set('display_errors', 1);
	}
}
