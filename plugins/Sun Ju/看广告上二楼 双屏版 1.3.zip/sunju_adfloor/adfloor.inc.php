<?php
/**
 * Copyright 2001-2099 DisM!(dism.taobao.com)
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (! defined ( 'IN_DISCUZ' ) || ! defined ( 'IN_ADMINCP' )) {
	exit ( 'Access Denied' );
}

$SJ_PL_ROOT = explode(DIRECTORY_SEPARATOR, dirname(__FILE__));
$PL_NAME 	= trim(end($SJ_PL_ROOT));
require_once DISCUZ_ROOT."source/plugin/{$PL_NAME}/sunju_class.php";
$SUNJU_ADFLOOR = new SUNJU_ADFLOOR($PL_NAME);

$PL_ADMIN_URL 	= ADMINSCRIPT."?action=plugins&identifier={$PL_NAME}&pmod=adfloor&op=";
$PL_ADMIN_OP_URL 	= ADMINSCRIPT."?action=plugins&identifier={$PL_NAME}&pmod=adfloor_op&op=";
$PL_STATIC 		= SUNJU_ADFLOOR::$PL_STATIC;
$PL_UPLOAD_PATH = SUNJU_ADFLOOR::$PL_UPLOAD_PATH;
$op 			= isset($_GET['op']) ? $_GET['op'] : "";

if("updateSort" == $op){
	if($_GET['formhash'] != FORMHASH){
		exit(SUNJU_ADFLOOR::doAjaxReturn(0,"Illegal operation"));
	}
	$id = (int)$_POST['id'];
	if($id == 0){
		exit(SUNJU_ADFLOOR::doAjaxReturn(0,"Illegal operation"));
	}
	$data = array("ad_sort" => intval($_POST['val']));
	if(SUNJU_ADFLOOR::doUpdateById($data,$id)){
		exit(SUNJU_ADFLOOR::doAjaxReturn(200));
	}else{
		exit(SUNJU_ADFLOOR::doAjaxReturn(0, lang("plugin/{$PL_NAME}", "op_e") ));
	}
}

if("updateShow" == $op){
	if($_GET['formhash'] != FORMHASH){
		exit(SUNJU_ADFLOOR::doAjaxReturn(0,"Illegal operation"));
	}
	$id = (int)$_POST['id'];
	if($id == 0){
		exit(SUNJU_ADFLOOR::doAjaxReturn(0,"Illegal operation"));
	}
	$data = array("ad_show" => intval($_POST['val']));
	if(SUNJU_ADFLOOR::doUpdateById($data,$id)){
		exit(SUNJU_ADFLOOR::doAjaxReturn(200));
	}else{
		exit(SUNJU_ADFLOOR::doAjaxReturn(0, lang("plugin/{$PL_NAME}", "op_e") ));
	}
}

for($i=5;$i<=15;$i++){
    $sj_tpl_lang["list_".$i] = lang("plugin/{$PL_NAME}", "list_".$i);
}

$s_tmp = array("update_s","list_nav_title","list_nav_list","list_btn_edit","list_btn_search");
foreach ($s_tmp as $v){
    $sj_tpl_lang[$v] = lang("plugin/{$PL_NAME}", $v);
}

$sj_tpl_lang['type'] = array(
	1 => lang("plugin/{$PL_NAME}", "type_1"),
	2 => lang("plugin/{$PL_NAME}", "type_2"),
);
$sj_tpl_lang['pos'] = array(
	1 => lang("plugin/{$PL_NAME}", "pos_1"),
	2 => lang("plugin/{$PL_NAME}", "pos_2"),
	3 => lang("plugin/{$PL_NAME}", "pos_3"),
);
$sj_tpl_lang['status'] = array(
	1 => lang("plugin/{$PL_NAME}", "status_show"),
	2 => lang("plugin/{$PL_NAME}", "status_hide"),
);

$param = array(
	"ad_type" 	=> (int)$_GET['ad_type'],
	"ad_pos" 	=> (int)$_GET['ad_pos'],
	"ad_show" 	=> (int)$_GET['ad_show'],
	"isCount" 	=> 1,
	"limit" 	=> 20
);

$total = SUNJU_ADFLOOR::doGetSourceList($param);
$multipage = multi ( $total, 20, (int)$_GET ['page'] , $PL_ADMIN_URL, $maxpages = 0, $page = 6, $autogoto = FALSE, $simple = TRUE );

$param['isCount'] = 0;
$list = SUNJU_ADFLOOR::doGetSourceList($param);

include template($PL_NAME.':admin/list');
?>