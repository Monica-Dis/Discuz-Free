<?php
/**
 * Copyright 2001-2099 DisM!(dism.taobao.com)
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (! defined ( 'IN_DISCUZ' ) || ! defined ( 'IN_ADMINCP' )) {
	exit ( 'Access Denied' );
}
$SJ_PL_ROOT = explode(DIRECTORY_SEPARATOR, dirname(__FILE__));
$PL_NAME 	= trim(end($SJ_PL_ROOT));
require_once DISCUZ_ROOT."source/plugin/{$PL_NAME}/sunju_class.php";
$SUNJU_ADFLOOR = new SUNJU_ADFLOOR($PL_NAME);

$PL_ADMIN_URL 	= ADMINSCRIPT."?action=plugins&identifier={$PL_NAME}&pmod=adfloor_op&op=";
$PL_STATIC 		= SUNJU_ADFLOOR::$PL_STATIC;
$PL_UPLOAD_PATH = SUNJU_ADFLOOR::$PL_UPLOAD_PATH;
$op 			= isset($_GET['op']) ? $_GET['op'] : "";

if("upload" == $op){
	require_once DISCUZ_ROOT."source/plugin/{$PL_NAME}/upload.php";
	$SU = new SUN_JU_Upload(array("rootPath"=>$PL_UPLOAD_PATH));
	$re = $SU->upload();
	if($re){
		$src = $re['download']['savepath'].$re['download']['savename'];
		exit($SUNJU_ADFLOOR->doAjaxReturn(99,lang("plugin/{$PL_NAME}", "upload_s"),array("src"=>$src)));
	}else{
		exit($SUNJU_ADFLOOR->doAjaxReturn(1,lang("plugin/{$PL_NAME}", "upload_e").$SU->getError()));
	}
}

if("add" == $op){
	if($_GET['formhash'] != FORMHASH){
		exit(SUNJU_ADFLOOR::doAjaxReturn(0,"Illegal operation"));
	}
	
	$field = array("ad_title","ad_path","ad_target","ad_type","ad_pos","ad_show","ad_sort");
	foreach($field as $v){
		isset($_GET[$v]) && $data[$v] = in_array($v,array("ad_type","ad_pos","ad_show","ad_sort")) ? (int)$_GET[$v] : trim($_GET[$v]);
	}
	$data["ad_op_time"] = time();
	$re = DB::insert('sunju_adfloor', $data);
	if($re){
		cpmsg ( "", '', 'success', '', '<p class="infotitle2">'.lang("plugin/{$PL_NAME}", "add_s").'<p>', TRUE );
	}else{
		cpmsg ( "", '', 'error', '', '<p class="infotitle3">'.lang("plugin/{$PL_NAME}", "add_e").'<p>', TRUE );
	}
	exit();
}

if("edit" == $op){
	$id 	= (int)$_GET['SJ_Sid'];
	if($id){
		$info = SUNJU_ADFLOOR::doGetSourceList(array("id"=>$id,"limit"=>1));
		if($info){
			$info = array_pop($info);
		}else{
        	cpmsg ( "", '', 'error', '', '<p class="infotitle3">Illegal operation<p>', TRUE );
        	exit();
		}
	}else{
    	cpmsg ( "", '', 'error', '', '<p class="infotitle3">Illegal operation<p>', TRUE );
    	exit();
	}
}

if("doedit" == $op){
	$id 	= (int)$_GET['id'];
	if($id == 0 || $_GET['formhash'] != FORMHASH){
		cpmsg ( "", '', 'error', '', '<p class="infotitle3">Illegal operation<p>', TRUE );
		exit();
	}
	
	$field = array("ad_title","ad_path","ad_target","ad_type","ad_pos","ad_show","ad_sort");
	foreach($field as $v){
		isset($_GET[$v]) && $data[$v] = in_array($v,array("ad_type","ad_pos","ad_show","ad_sort")) ? (int)$_GET[$v] : trim($_GET[$v]);
	}
	$re = DB::update('sunju_adfloor', $data, "id=".$id);
	if($re === false){
		cpmsg ( "", 'admin.php', 'error', '', '<p class="infotitle3">'.lang("plugin/{$PL_NAME}", "update_e").'<p>', TRUE );
	}else{
		cpmsg ( "", "?frames=no&action=plugins&identifier={$PL_NAME}&pmod=adfloor", 'success', '', '<p class="infotitle2">'.lang("plugin/{$PL_NAME}", "update_s").'<p>', TRUE );
	}
	exit();
}

for($i=1;$i<=19;$i++){
    $sj_tpl_lang["op_".$i] = lang("plugin/{$PL_NAME}", "op_".$i);
}
$s_tmp = array("type_1","type_2","pos_1","pos_2","pos_3","op_nav_add","op_nav_edit","op_btn_add","op_btn_save","op_e");
foreach ($s_tmp as $v){
    $sj_tpl_lang[$v] = lang("plugin/{$PL_NAME}", $v);
}

if(isset($info)){
    include template($PL_NAME.':admin/edit');
}else{
    include template($PL_NAME.':admin/add');
}
//From: Dism_taobao_com
?>