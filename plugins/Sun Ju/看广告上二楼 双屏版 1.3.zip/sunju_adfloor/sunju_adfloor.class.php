<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$SJ_PL_ROOT = explode(DIRECTORY_SEPARATOR, dirname(__FILE__));
$PL_NAME 	= trim(end($SJ_PL_ROOT));
require_once DISCUZ_ROOT."source/plugin/{$PL_NAME}/sunju_class.php";
$SUNJU_ADFLOOR = new SUNJU_ADFLOOR($PL_NAME);

class plugin_sunju_adfloor{

	function global_header() {
		$PL_G 	= SUNJU_ADFLOOR::$PL_G;
		$pages  = unserialize($PL_G['pages']);
        if(!(count($pages) == 1 && $pages[0] == '0')) {
            if(CURSCRIPT == 'forum' && CURMODULE == 'index' && !in_array(1, $pages)) {
                return '';
            } elseif(CURSCRIPT == 'portal' && CURMODULE == 'index' && !in_array(2, $pages)) {
                return '';
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay' && !in_array(3, $pages)) {
                return '';
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'viewthread' && !in_array(4, $pages)) {
                return '';
            } elseif(!(CURSCRIPT == 'forum' && in_array(CURMODULE, array('index', 'forumdisplay', 'viewthread'))) && !(CURSCRIPT == 'portal' && in_array(CURMODULE, array('index'))) && !in_array(5, $pages)) {
                return '';
            }
        }
		// slide_one
		$param = array("ad_type" => 1,"ad_show" => 1,"limit" => 1);
		$param["ad_pos"] = 1;
		$PL_SOURCE["one"]["big"] = $this->_formatData(SUNJU_ADFLOOR::doGetSourceList($param),"big");
		if($PL_SOURCE["one"]["big"]){
			$param["ad_pos"] = 2;
			$PL_SOURCE["one"]["mid"]     = $this->_formatData(SUNJU_ADFLOOR::doGetSourceList($param),"mid");
			$param["ad_pos"] = 3;$param["limit"] = 11;
			$PL_SOURCE["one"]["small"]   = $this->_formatData(SUNJU_ADFLOOR::doGetSourceList($param),"small");
			$PL_SOURCE["one"]["config"]  = $this->_formatData(SUNJU_ADFLOOR::doGetConfigByType(100),"config");
		}else{
			unset($PL_SOURCE["one"]);
		}
		
		// slide_two
		$param = array("ad_type" => 2,"ad_show" => 1,"limit" => 1);
		$param["ad_pos"] = 1;
		$PL_SOURCE["two"]["big"] = $this->_formatData(SUNJU_ADFLOOR::doGetSourceList($param),"big");
		if($PL_SOURCE["two"]["big"]){
			$param["ad_pos"] = 2;
			$PL_SOURCE["two"]["mid"]     = $this->_formatData(SUNJU_ADFLOOR::doGetSourceList($param),"mid");
			$param["ad_pos"] = 3;$param["limit"] = 11;
			$PL_SOURCE["two"]["small"]   = $this->_formatData(SUNJU_ADFLOOR::doGetSourceList($param),"small");
			$PL_SOURCE["two"]["config"]  = $this->_formatData(SUNJU_ADFLOOR::doGetConfigByType(101),"config");
		}else{
			unset($PL_SOURCE["two"]);
		}
		
		if(isset($PL_SOURCE["one"]) || isset($PL_SOURCE["two"])){
			$sj_tpl_lang = array(
				"up" 			=> lang("plugin/".SUNJU_ADFLOOR::$PL_NAME, "up"),
				"click_tips" 	=> lang("plugin/".SUNJU_ADFLOOR::$PL_NAME, "click_tips"),
			);
			$PL_STATIC 		= SUNJU_ADFLOOR::$PL_STATIC;
			$PL_UPLOAD_PATH = SUNJU_ADFLOOR::$PL_UPLOAD_PATH;
			$PL_SLIDER_NUM 	= count($PL_SOURCE);
			include template(SUNJU_ADFLOOR::$PL_NAME.':suntpl');
			
            $SJ_PL_TPL 	= preg_replace(array('~>\s+<~','~>(\s+\n|\r)~'), array('><','>'), $SJ_PL_TPL);
            include template(SUNJU_ADFLOOR::$PL_NAME.':sunjs');
            
			return $SJ_PL_JS;
		}
		return "";
	}
	
	private function _formatData($data,$key=""){
		if(empty($data) || empty($key)) return $data;
		if("big" == $key || "mid" == $key){
			return array_pop($data);
		}
		if("small" == $key){
			$re['top'] = array_slice($data,0,6,true);
			$re['bot_l'] = array_slice($data,6,4,true);
			$re['bot_r'] = array_pop(array_slice($data,10,1,true));
			return $re;
		}
		if("config" == $key){
			foreach($data as $v){
				$re[$v['ad_flag']] = $v['ad_config'];
			}
			return $re;
		}
		return "";
	}

}
