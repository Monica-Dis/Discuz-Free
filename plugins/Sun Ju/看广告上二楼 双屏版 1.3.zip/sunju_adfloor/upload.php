<?php
/**
 * Copyright 2001-2099 DisM!(dism.taobao.com)
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (! defined ( 'IN_DISCUZ' ) || ! defined ( 'IN_ADMINCP' )) {
	exit ( 'Access Denied' );
}

class SUN_JU_Upload{
    private $config = array(
        'mimes'         =>  array(),
        'maxSize'       =>  0,
        'exts'          =>  array("jpg","png","gif","jpeg","bmp"),
        'autoSub'       =>  true,
        'subName'       =>  array('date', 'Y-m-d'),
        'rootPath'      =>  '',
        'savePath'      =>  '',
        'saveName'      =>  array('uniqid', ''),
    );

	private $error = '';
	
	public function __construct($config = array()){
        $this->config   =   array_merge($this->config, $config);

        if(!empty($this->config['mimes'])){
            if(is_string($this->mimes)) {
                $this->config['mimes'] = explode(',', $this->mimes);
            }
            $this->config['mimes'] = array_map('strtolower', $this->mimes);
        }
        if(!empty($this->config['exts'])){
            if (is_string($this->exts)){
                $this->config['exts'] = explode(',', $this->exts);
            }
            $this->config['exts'] = array_map('strtolower', $this->exts);
        }
    }
    
    public function __get($name) {
        return $this->config[$name];
    }

    public function __set($name,$value){
        if(isset($this->config[$name])) {
            $this->config[$name] = $value;
        }
    }

    public function __isset($name){
        return isset($this->config[$name]);
    }

    public function upload($files='') {
        if('' === $files){
            $files  =   $_FILES;
        }
        if(empty($files)){
            $this->error = 'No uploaded files';
            return false;
        }

        if(!$this->checkRootPath($this->rootPath)){
            $this->error = $this->getError();
            return false;
        }

        if(!$this->checkSavePath($this->savePath)){
            $this->error = $this->getError();
            return false;
        }
        
        $info    =  array();
        if(function_exists('finfo_open')){
            $finfo   =  finfo_open ( FILEINFO_MIME_TYPE );
        }
        $files   =  $this->dealFiles($files);
        foreach ($files as $key => $file) {
            $file['name']  = strip_tags($file['name']);
            if(!isset($file['key']))   $file['key']    =   $key;
            if(isset($finfo)){
                $file['type']   =   finfo_file ( $finfo ,  $file['tmp_name'] );
            }

            $file['ext']    =   pathinfo($file['name'], PATHINFO_EXTENSION);

            if (!$this->check($file)){
                continue;
            }

            if($this->hash){
                $file['md5']  = md5_file($file['tmp_name']);
                $file['sha1'] = sha1_file($file['tmp_name']);
            }

            $savename = $this->getSaveName($file);
            if(false == $savename){
                continue;
            } else {
                $file['savename'] = $savename;
            }

            $subpath = $this->getSubPath($file['name']);
            if(false === $subpath){
                continue;
            } else {
                $file['savepath'] = $this->savePath . $subpath;
            }

            $ext = strtolower($file['ext']);
            if(in_array($ext, array('gif','jpg','jpeg','bmp','png','swf'))) {
                $imginfo = getimagesize($file['tmp_name']);
                if(empty($imginfo) || ($ext == 'gif' && empty($imginfo['bits']))){
                    $this->error = 'Illegal image file';
                    continue;
                }
                
                $file['width'] = $imginfo[0];
                $file['height'] = $imginfo[1];
            }

            if ($this->save($file,$this->replace)) {
                unset($file['error'], $file['tmp_name']);
                $info[$key] = $file;
            } else {
                $this->error = $this->getError();
            }
        }
        if(isset($finfo)){
            finfo_close($finfo);
        }
        return empty($info) ? false : $info;
    }

    private function dealFiles($files) {
        $fileArray  = array();
        $n          = 0;
        foreach ($files as $key=>$file){
            if(is_array($file['name'])) {
                $keys       =   array_keys($file);
                $count      =   count($file['name']);
                for ($i=0; $i<$count; $i++) {
                    $fileArray[$n]['key'] = $key;
                    foreach ($keys as $_key){
                        $fileArray[$n][$_key] = $file[$_key][$i];
                    }
                    $n++;
                }
            }else{
               $fileArray = $files;
               break;
            }
        }
       return $fileArray;
    }

    private function check($file) {
        if ($file['error']) {
            $this->error($file['error']);
            return false;
        }

        if (empty($file['name'])){
            $this->error = 'Unknown upload error';
        }

        if (!is_uploaded_file($file['tmp_name'])) {
            $this->error = 'Illegal uploading files';
            return false;
        }

        if (!$this->checkSize($file['size'])) {
            $this->error = 'Upload file size does not match';
            return false;
        }

        if (!$this->checkMime($file['type'])) {
            $this->error = 'Upload file type does not allow MIME';
            return false;
        }

        if (!$this->checkExt($file['ext'])) {
            $this->error = 'Upload file suffix is not allowed';
            return false;
        }

        return true;
    }

    private function error($errorNo) {
        switch ($errorNo) {
            case 1:
                $this->error = 'The uploaded file exceeds the value limited by the upload_max_filesize option in php.ini';
                break;
            case 2:
                $this->error = 'The size of the uploaded file exceeds the value specified in the MAX_FILE_SIZE option in the HTML form';
                break;
            case 3:
                $this->error = 'Only part of the file was uploaded';
                break;
            case 4:
                $this->error = 'No files were uploaded';
                break;
            case 6:
                $this->error = 'Temporary folder not found';
                break;
            case 7:
                $this->error = 'File write failed';
                break;
            default:
                $this->error = 'Unknown upload error';
        }
    }

    private function checkSize($size) {
        return !($size > $this->maxSize) || (0 == $this->maxSize);
    }

    private function checkMime($mime) {
        return empty($this->config['mimes']) ? true : in_array(strtolower($mime), $this->mimes);
    }

    private function checkExt($ext) {
        return empty($this->config['exts']) ? true : in_array(strtolower($ext), $this->exts);
    }

    private function getSaveName($file) {
        $rule = $this->saveName;
        if (empty($rule)) {
            $filename = substr(pathinfo("_{$file['name']}", PATHINFO_FILENAME), 1);
            $savename = $filename;
        } else {
            $savename = $this->getName($rule, $file['name']);
            if(empty($savename)){
                $this->error = 'File naming rule error';
                return false;
            }
        }

        return $savename . '.' . $file['ext'];
    }

    private function getSubPath($filename) {
        $subpath = '';
        $rule    = $this->subName;
        if ($this->autoSub && !empty($rule)) {
            $subpath = $this->getName($rule, $filename) . '/';

            if(!empty($subpath) && !$this->mkdir($this->savePath . $subpath)){
                $this->error = $this->getError();
                return false;
            }
        }
        return $subpath;
    }

    private function getName($rule, $filename){
        $name = '';
        if(is_array($rule)){
            $func     = $rule[0];
            $param    = (array)$rule[1];
            foreach ($param as &$value) {
               $value = str_replace('__FILE__', $filename, $value);
            }
            $name = call_user_func_array($func, $param);
        } elseif (is_string($rule)){
            if(function_exists($rule)){
                $name = call_user_func($rule);
            } else {
                $name = $rule;
            }
        }
        return $name;
    }

    public function checkRootPath($rootpath){
        if(!(is_dir($rootpath) && is_writable($rootpath))){
            $this->error = 'The upload root does not exist. Please try to manually create it:'.$rootpath;
            return false;
        }
        $this->rootPath = $rootpath;
        return true;
    }

    public function checkSavePath($savepath){
        if (!$this->mkdir($savepath)) {
            return false;
        } else {
            if (!is_writable($this->rootPath . $savepath)) {
                $this->error = 'Upload Directory ' . $savepath . ' not writable';
                return false;
            } else {
                return true;
            }
        }
    }

    public function save($file, $replace=true) {
        $filename = $this->rootPath . $file['savepath'] . $file['savename'];

        if (!$replace && is_file($filename)) {
            $this->error = 'Existing name file' . $file['savename'];
            return false;
        }

        if (!move_uploaded_file($file['tmp_name'], $filename)) {
            $this->error = 'Save the file upload error';
            return false;
        }
        
        return true;
    }

    public function mkdir($savepath){
        $dir = $this->rootPath . $savepath;
        if(is_dir($dir)){
            return true;
        }

        if(mkdir($dir, 0777, true)){
            return true;
        } else {
            $this->error = "catalog {$savepath} Create failure";
            return false;
        }
    }

    public function getError(){
        return $this->error;
    }
}
