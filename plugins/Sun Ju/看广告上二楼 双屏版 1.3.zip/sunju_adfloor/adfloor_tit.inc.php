<?php
/**
 * Copyright 2001-2099 DisM!(dism.taobao.com)
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (! defined ( 'IN_DISCUZ' ) || ! defined ( 'IN_ADMINCP' )) {
	exit ( 'Access Denied' );
}

$SJ_PL_ROOT = explode(DIRECTORY_SEPARATOR, dirname(__FILE__));
$PL_NAME 	= trim(end($SJ_PL_ROOT));
require_once DISCUZ_ROOT."source/plugin/{$PL_NAME}/sunju_class.php";
$SUNJU_ADFLOOR = new SUNJU_ADFLOOR($PL_NAME);

$PL_ADMIN_URL 	= ADMINSCRIPT."?action=plugins&identifier={$PL_NAME}&pmod=adfloor_tit&op=";
$PL_STATIC 		= SUNJU_ADFLOOR::$PL_STATIC;
$op 			= isset($_GET['op']) ? $_GET['op'] : "";

if("updateConfig" == $op){
	if($_GET['formhash'] != FORMHASH){
		exit(SUNJU_ADFLOOR::doAjaxReturn(0,"Illegal operation"));
	}
	
	SUNJU_ADFLOOR::doUpdateConfigById(array("ad_config" => trim($_POST['ad_config_1'])),1);
	SUNJU_ADFLOOR::doUpdateConfigById(array("ad_config" => trim($_POST['ad_config_2'])),2);
	SUNJU_ADFLOOR::doUpdateConfigById(array("ad_config" => trim($_POST['ad_config_3'])),3);
	SUNJU_ADFLOOR::doUpdateConfigById(array("ad_config" => trim($_POST['ad_config_4'])),4);
	
	cpmsg ( "", "?frames=no&action=plugins&identifier={$PL_NAME}&pmod=adfloor_tit", 'success', '', '<p class="infotitle2">'.lang("plugin/{$PL_NAME}", "update_s").'<p>', TRUE );
	exit();
}

for($i=1;$i<=4;$i++){
    $sj_tpl_lang["list_".$i] = lang("plugin/{$PL_NAME}", "list_".$i);
}
$sj_tpl_lang["list_nav_title"] = lang("plugin/{$PL_NAME}", "list_nav_title");
$sj_tpl_lang["op_btn_save"] = lang("plugin/{$PL_NAME}", "op_btn_save");

$config = SUNJU_ADFLOOR::doGetConfigByType(100);
if($config){
	foreach($config as $v){
		$config_1[$v['ad_flag']] = array(
			"id" => $v['id'],
			"ad_config" => $v['ad_config'],
		);
	}
}else $config_1 = array();

$config = SUNJU_ADFLOOR::doGetConfigByType(101);
if($config){
	foreach($config as $v){
		$config_2[$v['ad_flag']] = array(
			"id" => $v['id'],
			"ad_config" => $v['ad_config'],
		);
	}
}else $config_2 = array();
include template($PL_NAME.':admin/tit');
?>