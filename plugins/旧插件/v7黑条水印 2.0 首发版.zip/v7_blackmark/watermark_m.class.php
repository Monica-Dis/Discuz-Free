<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_v7_blackmark {
	protected $v7_blackmark;
	
	public function __construct() {
		global $_G;
		$this->v7_blackmark = $_G['cache']['plugin']['v7_blackmark'];
	}
 	function common() {
 		global $_G;
		
 		if (empty($_FILES) || $_GET['mod'] != 'swfupload') return false;
 		$_G['uid'] = intval($_POST['uid']);
		
 		if((empty($_G['uid']) && $_GET['operation'] != 'upload') || $_POST['hash'] != md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid'])) {
 			exit;
 		} else {
 		}
 		
 		if($_GET['operation'] == 'upload') {
 			if(empty($_GET['simple'])) {
 				$_FILES['Filedata']['name'] = addslashes(diconv(urldecode($_FILES['Filedata']['name']), 'UTF-8'));
 				$_FILES['Filedata']['type'] = $_GET['filetype'];
 			}
 			require_once DISCUZ_ROOT.'./source/plugin/v7_blackmark/upload.class.php';
 			$upload = new plugin_forum_upload;
 		}
 	}
}

class mobileplugin_v7_blackmark_forum extends mobileplugin_v7_blackmark {

}