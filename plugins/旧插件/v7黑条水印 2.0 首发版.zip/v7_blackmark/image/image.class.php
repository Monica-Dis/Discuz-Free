<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_image extends image{
	protected $watermarktrans = 50;
	protected $recwater = 0;
	public $preview = 0;
	protected $watermarkquality = 100;
	
	public function Watermark($source) {
		global $_G;
		loadcache('plugin');
		$v7 = $_G['cache']['plugin']['v7_blackmark'];
		$return = $this->init('watermask', $source,($this->preview ? 'tmp' : ''));
		if($return <= 0) {
			return $this->returncode($return);
		}
		
		if(function_exists('imagecopy') && function_exists('imagealphablending') && function_exists('imagecopymerge')&&!$this->imginfo['animated']) {
			$dst_photo = imagecreatetruecolor($this->imginfo['width'], $this->imginfo['height']+$v7['b_height']);//debug($this);
			$imagecreatefromfunc = &$this->imagecreatefromfunc;
			$target_photo = @$imagecreatefromfunc($this->preview ? $this->source : $this->target);
			@imageCopy($dst_photo, $target_photo, 0, 0, 0, 0, $this->imginfo['width'], $this->imginfo['height']);
			
				$color = array('r' => 255, 'g' => 255, 'b' => 255);
				$water_color = imagecolorallocate($dst_photo, $color['r'], $color['g'], $color['b']);
			
				$water_font = DISCUZ_ROOT.'./source/plugin/v7_blackmark/font/'.$v7['font_name'];

				$water_size = $v7['font_size'];
				$username=diconv($_G['username'], CHARSET, 'UTF-8');
				$tid='12345';
				$sitename=diconv($_G['setting']['sitename'], CHARSET, 'UTF-8');

				$siteurl_r=substr($_G['siteurl'],strpos($_G['siteurl'],"//")+2);
				$siteurl=substr($siteurl_r,0,strpos($siteurl_r,"/"));
				$water_text = diconv($v7['text'], CHARSET, 'UTF-8');
				$water_text = str_replace("{tid}",$tid,$water_text);
				$water_text = str_replace("{username}",$username,$water_text);
				$water_text = str_replace("{sitename}",$sitename,$water_text);
				$water_text = str_replace("{siteurl}",$siteurl,$water_text);
				$water_text = str_replace("{time}",date('Y-m-d H:i:s'),$water_text);
				$w_b = imagettfbbox($water_size, 0, $water_font, $water_text);
				if ($this->imginfo['width'] < 360) {
					return $this->returncode(-101);
				}
				imagettftext($dst_photo, $water_size, 0, 3, $this->imginfo['height'] + 13 + $v7['top'], $water_color, $water_font, $water_text);

			$this->target = !$this->preview ? $this->target : DISCUZ_ROOT.'./source/plugin/v7_blackmark/temp/watermark.jpg';
			clearstatcache();
			$imagefunc = &$this->imagefunc;
			if($this->imginfo['mime'] == 'image/jpeg') {
				$imagefunc($dst_photo, $this->target, $this->watermarkquality);
			} else {
				$imagefunc($dst_photo, $this->target);
			}
			return $this->sleep(0);
		}
	}
}
