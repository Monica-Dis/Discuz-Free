<?PHP

/**
 * 
 * Ψ�����������Ʒ
 * 
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo "<script>window.location.href='http://addon.discuz.com/?@18143.developer';</script>";
