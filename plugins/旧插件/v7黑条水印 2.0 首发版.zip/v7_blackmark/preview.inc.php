<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/v7_blackmark/image/image.class.php';
$images = new plugin_image;
$images->preview = 1;
$images->Watermark(DISCUZ_ROOT.'./source/plugin/v7_blackmark/image/preview.jpg');
//debug($images);
echo '<img src="source/plugin/v7_blackmark/temp/watermark.jpg?t='.TIMESTAMP.'" title="preview"/>';

?>
