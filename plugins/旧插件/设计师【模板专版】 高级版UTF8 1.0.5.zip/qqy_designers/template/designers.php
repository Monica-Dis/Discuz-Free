<?php exit('全球鹰QQ:641500953 商业保护！请到官网上购买正版 <a href="https://dism.taobao.com/?@qqy_designers.plugin" >https://dism.taobao.com/?@qqy_designers.plugin</a>');?>
<!--{template common/header}-->
</div>
<script type="text/javascript" src="{$static_dir}/jquery-1.7.2.min.js?{VERHASH}"></script>
<link rel="stylesheet" type="text/css"  href="{$static_dir}/qqy_designers.css?{VERHASH}" />

<style type="text/css">
#wp{ display:none;}
.wp{ width:{$wp_wid}px;}
</style>

<script>
var jq=jQuery.noConflict();
</script>

<div class="wp">	
	
</div>

<div class="wp mtw cl">

	<div class="qqy_designers">
		
		<div class="qqy_designers_nav cl">
			<a href="$want_show['1']" class="qqy_want_show" target="_blank">$want_show['0']</a>
			<!--{if $types}-->
			<!--{loop $types $val}-->
				<a href="plugin.php?id=qqy_designers&type={$val['type']}" {if $val['type']==$curType } class="a"{/if} hidefocus="true">{$val['name']}</a>
			<!--{/loop}-->			
			<!--{/if}-->
		</div>

		<!--{if $designers}-->
		<!--{loop $designers $designer}-->
			<div class="qqy_designer_list cl">
				<div class="mbn cl">
			
				<div class="left_avatar">
					<a href="home.php?mod=space&uid={$designer['uid']}" target="_blank" hideFocus="true">
						<!--{avatar($designer['uid'],middle)}-->
					</a>
				</div>
				
				<div class="left_info">
					<h2 class="mbn">$designer['username']</h2>
					<p class="qqy_location">{if $designer['info']['resideprovince']}$designer['info']['resideprovince']{else}中国{/if}</p>
					<p class="qqy_count">作品：<em>$designer['count']['threads']</em>&nbsp; &nbsp; 粉丝：<em>$designer['count']['follower']</em></p>
					<p class="qqy_action">
						<!--{if $designer['uid']!=$_G[uid]}-->
							<a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$uid&touid=$designer['uid']&pmid=0&daterange=2" onclick="showWindow('sendpm', this.href);" title="发私信" class="home_sendpm" hideFocus="true">发私信</a>	
							<a href="home.php?mod=spacecp&ac=friend&op=add&uid=$designer['uid']&handlekey=addfriendhk_{$designer['uid']}" id="a_friend_li_{$designer['uid']}" onclick="showWindow(this.id, this.href, 'get', 0);" class="home_addfriend" hideFocus="true">加好友</a>
							<!--{if helper_access::check_module('follow')}-->
							<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$designer['uid']" id="followmod_{$designer['uid']}" title="加关注" class="home_follow" onclick="showWindow('followmod', this.href, 'get', 0);" hideFocus="true">加关注</a>
							<!--{/if}-->
						<!--{else}-->
						<a href="home.php?mod=spacecp" hidefocus="true">个人设置</a>
						<a href="forum.php?mod=guide&view=my" hidefocus="true">我的帖子</a>
						<a href="home.php?mod=space&do=favorite&view=me" hidefocus="true">我的收藏</a>			
						<!--{/if}-->
					</p>
							
				</div>
				
				
				
				<!--{loop $loop3 $i}-->
				<div class="qqy_right">
					<!--{if $designer['threads'][$i]}-->
						<a href="forum.php?mod=viewthread&tid={$designer['threads'][$i]['tid']}" target="_blank" hidefocus="true">
							 <img src="{echo $designer['threads'][$i]['coverpath'] = getthreadcover($designer['threads'][$i]['tid'], $designer['threads'][$i]['cover']);}" />
						</a>
					<!--{else}-->
						<div class="qqy_no_img"></div>
					<!--{/if}-->
				</div>	
				<!--{/loop}-->
				
				</div>
				
				{if $designer['info']['bio']}
				<div class="bio cl">
					<p>{if $designer['info']['bio']}$designer['info']['bio']{else}$designer['info']['gender']还没有设置自我介绍{/if}</p>
				</div>
				{/if}
				
			</div>
		<!--{/loop}-->
		
		<!--{else}-->
			<p class="qqy_designers_empty">抱歉，没有找到相应的设计师</p>
		<!--{/if}-->
	</div>
</div>

<div class="wp qqy_des_page mbw cl">
	$multipage
</div>

<script>
var isOut = false;

jq("body").mousedown(function(){
	if(isOut){
		jq(".ul_div").hide();
	}
});


</script>

<div class="wp cl">
<!--{template common/footer}-->