<?php 
/**
 * Plugin For Discuz! X2.5-X3.2
 
 * [DisM!] (C)2001-2099 DisM Inc.

 * 应用更新支持：https://dism.taobao.com
 
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 
 * 网站:      dism.taobao.com
  
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

	$uid = (int)$_G['uid'];
	$user_group = (int)$_G['groupid'];
	$view_groups = (array)unserialize($_G['cache']['plugin']['qqy_designers']['view_groups']);
	if( !in_array($user_group, $view_groups) ){
		if(!$uid){
			showmessage('抱歉，您尚未登录，请先登录！', NULL, array(), array('login' => 1));	
		}else{
			showmessage('抱歉，你所在的用户组没有查看权限！', NULL, array());
		}	
	}
	//插件配置初始化
	$static_dir = 'source/plugin/qqy_designers/static';
	$url = 'plugin.php?id=qqy_designers';
	//插件设置初始化
	$navtitle  = trim($_G['cache']['plugin']['qqy_designers']['seo_title']);
	$metakeywords = trim($_G['cache']['plugin']['qqy_designers']['seo_key']);
	$metadescription = trim($_G['cache']['plugin']['qqy_designers']['seo_desc']);
	
	$show_groups = (array)unserialize($_G['cache']['plugin']['qqy_designers']['user_groups']);
	$show_groups && $show_groups = implode(",", $show_groups);
	$show_groups = trim($show_groups,",");
	
	$wp_wid = (int)$_G['cache']['plugin']['qqy_designers']['width'];
	$wp_wid = ($wp_wid && $wp_wid>950)?$wp_wid:980;
	
	//分类栏目初始化
	$all_types = array('credits','digestposts','threads','regdate','follower','rcmd');
	$types = $search_type = array();
	$set_types = $_G['cache']['plugin']['qqy_designers']['set_type'];
	$set_types && $set_types = explode("\n",$set_types);
	if($set_types){
		foreach ($set_types as $key=>$val){
			$val= explode("|",trim($val));
			if(count($val)==2){
				in_array($val['1'],$all_types) && $search_type[] = $val['1'];
				$types[$key]['name']= $val['0'];
				$types[$key]['type']= $val['1'];  
			}
		}	
	}
	//作品来源初始化
	$user_fids = (array)unserialize($_G['cache']['plugin']['qqy_designers']['user_fids']);
	$user_fids && $user_fids = implode(",", $user_fids);
	$user_fids = trim($user_fids,",");
	//我要上榜初始化
	$want_show = trim($_G['cache']['plugin']['qqy_designers']['want_show']);
	$want_show = explode("|", $want_show);
	//查询条件
	$type = in_array($_GET['type'],$search_type)?$_GET['type']:'';
	$type && $url.='&type='.$type;
	$curType = $type?$type:'regdate';
	
	$perpage = (int)$_G['cache']['plugin']['qqy_designers']['perpage'];
	$perpage<1 && $perpage=12;
	$page = $_GET['page']>1?(int)$_GET['page']:1;
	$start = ($page-1)*$perpage;
	$thread_orderby = 'dateline';
    if($type==='rcmd'){
		$user_rcmd = $_G['cache']['plugin']['qqy_designers']['user_rcmd'];
		$user_rcmd = explode("\n", $user_rcmd);
		if($user_rcmd && is_array($user_rcmd)){
			foreach ($user_rcmd as $k=>$v){			
				$user_rcmd[$k] = trim($v);
			}
			$user_rcmd = implode(",", $user_rcmd);			
		}
		$designers = DB::fetch_all("SELECT uid,username FROM ".DB::table('common_member')." WHERE uid IN ($user_rcmd)");		
		$countsql = "SELECT count(*) FROM ".DB::table('common_member')." WHERE uid IN ($user_rcmd)";
	}else{	
		$where = ' WHERE 1 ';
		$join = ' LEFT JOIN ';
		$search = 0;
		$show_groups && $where.=" AND M.groupid IN ($show_groups)";
		$user_fids && $where.= "  AND T.fid IN ($user_fids)";
		$user_fids && $join = " JOIN ";
		$typeby =  $type?$type:'regdate';
		switch($typeby){
			case 'credits'://积分
				$sql = 'SELECT DISTINCT M.uid,M.username FROM '.DB::table('common_member')." M $join ".DB::table('forum_thread')." T ON T.authorid=M.uid $where ORDER BY M.credits DESC LIMIT ".$start.','.$perpage;
				$countsql = 'SELECT count(DISTINCT M.uid) FROM '.DB::table('common_member')." M $join ".DB::table('forum_thread')." T ON T.authorid=M.uid $where ";
				break;
			case 'digestposts'://精华主题
				$sql = 'SELECT DISTINCT M.uid,M.username FROM '.DB::table('common_member')." M $join ".DB::table('forum_thread')." T ON T.authorid=M.uid JOIN ".DB::table('common_member_count')." C ON M.uid=C.uid $where ORDER BY C.digestposts DESC LIMIT ".$start.','.$perpage;
				$countsql = 'SELECT count(DISTINCT M.uid) FROM '.DB::table('common_member')." M $join ".DB::table('forum_thread')." T ON T.authorid=M.uid $where ";
				break;
			case 'threads'://主题数
				$sql = 'SELECT DISTINCT M.uid,M.username FROM '.DB::table('common_member')." M $join ".DB::table('forum_thread')." T ON T.authorid=M.uid JOIN ".DB::table('common_member_count')." C ON M.uid=C.uid $where ORDER BY C.threads DESC LIMIT $start,$perpage";
				$countsql = 'SELECT count(DISTINCT M.uid) FROM '.DB::table('common_member')." M $join".DB::table('forum_thread')." T ON T.authorid=M.uid $where ";
				break;
			case 'regdate'://注册时间
				$sql = 'SELECT DISTINCT M.uid,M.username FROM '.DB::table('common_member')." M $join ".DB::table('forum_thread')." T ON T.authorid=M.uid $where ORDER BY M.regdate  LIMIT ".$start.','.$perpage;
				$countsql = 'SELECT count(DISTINCT M.uid) FROM '.DB::table('common_member')." M $join ".DB::table('forum_thread')." T ON T.authorid=M.uid $where ";
				break;
			case 'follower'://粉丝数
				$sql = 'SELECT DISTINCT M.uid,M.username FROM '.DB::table('common_member')." M $join ".DB::table('forum_thread')." T ON T.authorid=M.uid JOIN ".DB::table('common_member_count')." C ON M.uid=C.uid $where ORDER BY C.follower DESC LIMIT $start,$perpage";
				$countsql = 'SELECT count(DISTINCT M.uid) FROM '.DB::table('common_member')." M $join ".DB::table('forum_thread')." T ON T.authorid=M.uid $where ";
				break;
			default:
				break;
		}
		$designers = DB::fetch_all($sql);		
	}
	
	if($designers && is_array($designers)){
		require_once(DISCUZ_ROOT."./source/function/function_forum.php");
		foreach ($designers as $key=>$val){
			$designers[$key]['threads'] = DB::fetch_all('SELECT subject,tid,cover FROM '.DB::table('forum_thread').' WHERE authorid='.(int)$val['uid'].' AND `displayorder`>=0 AND  `cover`<>0 ORDER BY '.$thread_orderby.' DESC LIMIT 3');
			$designers[$key]['info']=DB::fetch_first('SELECT gender,resideprovince,bio FROM '.DB::table('common_member_profile').' WHERE uid='.(int)$val['uid']);
			$designers[$key]['info']['gender'] =  ($designers[$key]['info']['gender']==2)?'她':'他';
			$designers[$key]['count'] = DB::fetch_first('SELECT following,follower,threads FROM '.DB::table('common_member_count').' WHERE uid='.(int)$val['uid']);
			$designers[$key]['emailstatus'] =  DB::result_first('SELECT emailstatus FROM '.DB::table('common_member').' WHERE uid='.(int)$val['uid']);
		}
		$loop3 = array(0,1,2);
		$count = $countsql?DB::result_first($countsql):1;		
	}else{
		$count = 0;
		$loop3 = array(0,1,2);
	}
	$multipage = multi($count,$perpage,$page,$url,$_G['setting']['threadmaxpages']);

	//支持diy
	if (!defined('TPL_DEFAULT')) define('TPL_DEFAULT', TRUE);
	$plugname = 'qqy_designers';
	$tmpname = 'designers';
	$diydir = 'source/plugin/'.$plugname.'/template/';
	include template('diy:'.$tmpname, '', $diydir);
	
	//include template('qqy_designers:designers');
?>