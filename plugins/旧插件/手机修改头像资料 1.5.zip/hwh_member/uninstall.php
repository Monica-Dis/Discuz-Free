<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$wsq_file = DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';

if (file_exists($wsq_file)) {
	require_once $wsq_file;
	WeChatHook::delAPIHook('hwh_member');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_hwh_member_resetname`;
ALTER TABLE `pre_common_member_profile` DROP `hwh_wechat`;

EOF;
runquery($sql);

$finish = TRUE;
