<?php

if( !defined('IN_DISCUZ') ) {
	exit('Access Denied');
}

class table_hwh_member_resetname extends discuz_table {

	public function __construct() {
		$this->_table = 'hwh_member_resetname';
		$this->_pk    = 'id';
		parent::__construct();
	}

	public function fetch_all_rename($sort='') {
		return DB::fetch_all('SELECT * FROM %t'.($sort ? ' ORDER BY '.DB::order($this->_pk, $sort) : ''),array($this->_table));
	}

	public function range_rename($start=0,$limit=0,$condition='',$sort=''){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).($condition ? ' WHERE '.$condition.' ' : '').($sort ? ' ORDER BY '.$sort : '').DB::limit($start, $limit), null, $this->_pk ? $this->_pk : '');
	}

	public function fetch_first_by_uid($uid) {
		return DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array($this->_table,$uid));
	}

}

//From: Dism_taobao��com

?>