$(function(){

    if (recavatar_item.length) {
        $(document).on('tap','.show_recavatar', function() {
            $('#show_avatar,#reset_profile,header').fadeOut('fast', function() {
                $('#rec_avatar').fadeIn('fast');
            });
            showRecavatar();
            if (recavatar_item.length>1) {
                if (!getCookie('hwh_shake_tip')) {
                    $('#rec_avatar>h6').show();
                    setTimeout(function(){
                    $('#rec_avatar>h6').fadeOut();
                    },3000);
                    var exp = new Date();
                    exp.setTime(exp.getTime() + 30*24*60*60*1000);
                    document.cookie="hwh_shake_tip=1;expires="+exp.toGMTString();
                }
                var hwhShakeEvent = new Shake({ threshold: 15 });
                hwhShakeEvent.start();
                window.addEventListener('shake',showRecavatarAudio,false);
            }
        });
    }

    $(document).on('tap','#rec_avatar>div>img', function() {
        var fileneme = $(this).data('fileneme');
        $.ajax({
        type:'GET',
        url:jsvar['appurl']+'&m=recavatar',
        data:{fileneme:fileneme},
        dataType: 'JSON',
        beforeSend: function(XMLHttpRequest){
            $('.canvas_lazy_cover,.canvas_lazy_tip').show();
        }, success:function(data) {
            if (data.status) {
                $('body').scrollTop(0);
                $('#rec_avatar').fadeOut('fast', function() {
                    $('header img,#show_avatar img').attr('src',jsvar['siteurl']+'source/plugin/hwh_member/static/images/avatar/'+fileneme);
                    $('#show_avatar,#reset_profile,header').fadeIn('fast');
                });
                $('.canvas_lazy_cover,.canvas_lazy_tip').hide();
            }
        }, error:function(){
            alert('error');
        }
        });
    });

    $(document).on('tap','#rec_avatar>.btn', function() {
        $('#rec_avatar').fadeOut('fast', function() {
            $('#show_avatar,#reset_profile,header').fadeIn('fast');
        });
    });

    $(document).on('tap','.head_portrait', function() {
        $('#file').click();
    });
})

need_rotate = 0;

var photoClip=$("#canvas_area").photoClip({

            width:200,
            height:200,
            file: "#file",
            view: "#canvas_view",
            ok: "#finish",
            loadStart: function () {

                $('.canvas_lazy_tip span').text('');
                $('.canvas_lazy_cover,.canvas_lazy_tip').show();

                oFile = file.files['0'];
                EXIF.getData(oFile, function() {
                    EXIF.getAllTags(this);
                    var orientation = EXIF.getTag(this,'Orientation');

                    if (orientation>1) { need_rotate = 1; }
                });
            },
            loadComplete: function () {
                if (need_rotate) {
                    oFile = file.files['0'];
                    var resImg = document.getElementById('canvas_preview');
                    var mpImg = new MegaPixImage(oFile,canvasToImage);
                        mpImg.render(resImg,{
                        orientation: orientation,
                        quality: 1
                    });
                }else{
                    canvasShow();
                }
            },
            clipFinish: function (dataURL) {
                uploadImage(dataURL);
            }

    });

function canvasShow(){
    $('.canvas_lazy_cover,.canvas_lazy_tip').hide();
    $('#canvas_fullscreen').show();
    $('html,body').addClass("hidden");
}

function canvasToImage(base64){
    var imgData = base64 || document.getElementById('canvas_preview').toDataURL('image/jpeg',1);
    $('.photo-clip-rotateLayer img').attr('src',imgData);
    canvasShow();
}

function uploadImage(img_data) {
    $.ajax({
        type:'POST',
        url:jsvar['appurl']+'&m=avatar',
        data:{image_file:img_data,formhash:jsvar['formhash']},
        // dataType: 'XML',
        beforeSend: function(XMLHttpRequest){
            $('.canvas_lazy_cover,.canvas_lazy_tip').show();
        }, success:function(data) {
             $('header img,#show_avatar img').attr('src',img_data);
             $('#canvas_fullscreen,.canvas_lazy_cover,.canvas_lazy_tip').hide();
             $('html,body').removeClass('hidden');
        }, error:function(){
            alert('error');
        }
        });
}

function showRecavatarAudio(){
    document.getElementById('shake_audio').play();
    showRecavatar();
}

function showRecavatar(){
    var random_num = Math.floor(Math.random()*recavatar_item.length),
        recavatar = recavatar_item[random_num].split(','),
        css = '';
        for (var i=1; i<=recavatar.length;i++) {
            var second = i/10;
            css+='#rec_avatar>div>img:nth-child('+i+'){animation-delay: '+second+'s;-moz-animation-delay: '+second+'s;-webkit-animation-delay: '+second+'s;}';//推荐头像弹出动画css
        }
        $('style').append(css);
        $('#rec_avatar>div').html('');
    if (recavatar_item.length<=1) {
        recavatar = recavatar.sort(function(){ return 0.5 - Math.random();})
    }
    $.each(recavatar,function(index,val) {
         $('#rec_avatar>div').append('<img class="duang" src="'+jsvar['siteurl']+'source/plugin/hwh_member/static/images/avatar/'+val+'" data-fileneme="'+val+'">');
    });
}

function getCookie(name){
var arr,reg = new RegExp("(^| )"+name+"=([^;]*)(;|$)");
if(arr=document.cookie.match(reg))
return unescape(arr[2]);
else
return null;
}