$(function(){

    $(document).on('tap','ul>li:first>a', function() {
        $('#reset_name').fadeIn();
        $('#reset_name>span').text(lang._32);
    });

    $(document).on('tap', '#cancel_rn', function() {
       $('#reset_name>input').val('');
       $('#reset_name').fadeOut();
    });

    $(document).on('click','#post_rn', function() {
        if (!confirm(lang._41+jsvar['reset_name_num']+lang._40+','+lang._39+jsvar['done_num']+lang._40+','+lang._38)) {
            return;
        }else{
            $.post(jsvar['appurl']+'&m=resetname', {newname:$('#reset_name>input').val(),formhash:jsvar['formhash']}, function (data) {
            var data = $.parseJSON(data);
            if (data.status) {
                $('#reset_name>input').val('');
                $('#reset_name').fadeOut();
                $('#main>ul>li:first>a').remove();
                 alert(lang._37);
                }
            });
        }
    });

    $('header>div>img').on('tap',function() {
        var big_avatar = jsvar['avatar_big']+'&rand='+Math.random()*1000;
        $('body').append('<div id="view_avatar"><img src="'+big_avatar+'"><a><i class="icon iconfont">&#xf0006;</i></a></div>');
        $('#view_avatar').fadeIn();
    });

    $(document).on('tap','#view_avatar',function() {
        $(this).fadeOut(function() {
            $(this).remove();
        });
    });

    $(".gender>a").on("tap",function(){
        $(this).siblings().removeClass('on').end().addClass('on');
        var sexId = $(this).data('value');
        $('input[name="gender"]').val(sexId);
        $('#gender').removeClass().addClass('sex_'+sexId);
    });

    var sex = jsvar['gender'];
    $(".gender>a").eq(sex-1).addClass('on');

    $('header>div').fadeIn('slow',function(){
        $('header>div>a').animate({top:'67px'});
        $('header>div>.show_recavatar').animate({top:'-10px'});//推荐头像的按钮
    });

    var myText = new Array([lang._27],[lang._28],[lang._29]);
    $.ms_DatePicker({
            YearSelector: "#birthyear",
            MonthSelector: "#birthmonth",
            DaySelector: "#birthday",
            FirstText: myText,
            StartYear:1916
    });

    showdistrict('address',['resideprovince','residecity','residedist','residecommunity'],4,'','reside');

    $.Tipmsg.r=null;

    var showmsg=function(msg){
    alert(msg);
    }

    $("#main").Validform({
        tiptype:function(msg){
            showmsg(msg);
        },
        datatype:{
            "zh2-4":/^[\u4E00-\u9FA5\uf900-\ufa2d]{2,4}$/,
        },beforeSubmit:function(curform){
        $('button[type="submit"]').attr('disabled',1).text(lang._30);
    },
        tipSweep:true,
        ajaxPost:false,
    });


})

    function _$(id) {
        return document.getElementById(id);
    }

    function showdistrict(container, elems, totallevel, changelevel, containertype) {
    var getdid = function(elem) {
        var op = elem.options[elem.selectedIndex];
        return op['did'] || op.getAttribute('did') || '0';
    };
    var pid = changelevel >= 1 && elems[0] && _$(elems[0]) ? getdid(_$(elems[0])) : 0;
    var cid = changelevel >= 2 && elems[1] && _$(elems[1]) ? getdid(_$(elems[1])) : 0;
    var did = changelevel >= 3 && elems[2] && _$(elems[2]) ? getdid(_$(elems[2])) : 0;
    var coid = changelevel >= 4 && elems[3] && _$(elems[3]) ? getdid(_$(elems[3])) : 0;
    var url = jsvar['siteurl']+"home.php?mod=misc&ac=ajax&op=district&container="+container+"&containertype="+containertype
        +"&province="+elems[0]+"&city="+elems[1]+"&district="+elems[2]+"&community="+elems[3]
        +"&pid="+pid + "&cid="+cid+"&did="+did+"&coid="+coid+'&level='+totallevel+'&handlekey='+container+'&inajax=1'+(!changelevel ? '&showdefault=1' : '');
    $.ajax({
        type: "GET",
        url: url,
        cache:false,
        dataType:'xml',
        success: function(data){
            var content = $(data).find("root").text();
            content = content.replace(/&nbsp;&nbsp;/ig, "");
           $('#'+container).html('<span>'+lang._31+'</span>'+content);
        }
    });
}

function trim(str) {
        return str.replace(/^\s*(.*?)[\s\n]*$/g, '$1');
    }

function check_username(obj){
    var msg = _$('info_rn');
    var button = _$('post_rn');
    var username = trim(obj.value);

    if(username.match(/<|"/ig)) {
        msg.innerHTML = lang._33;
        button.disabled = true;
        return;
    }else{
        msg.innerHTML = '';
    }

    var unlen = username.replace(/[^\x00-\xff]/g, "**").length;
    if(unlen < 3 || unlen > 15) {
        msg.innerHTML=unlen < 3 ? lang._34 : lang._35;
        button.disabled=true;
        return;
    }else{
        msg.innerHTML='';
    }

    $.ajax({
        type:'GET',
        url:jsvar['siteurl']+'forum.php?mod=ajax&inajax=yes&infloat=register&handlekey=register&ajaxmenu=1&action=checkusername&username',
        data:{username:document.charset == 'utf-8' ? encodeURIComponent(username) : username.replace(/%/g, '%25').replace(/#/g, '%23')},
        dataType: 'XML',
        beforeSend: function(XMLHttpRequest){
             button.disabled=true;
        },
        success:function(xml) {
         var html = $(xml).find('root').text();
         var status_info = $(html).find('p:eq(0)').text();
         if (status_info!='succeed') {
                button.disabled=true;
                msg.innerHTML=status_info;
         }else{
                button.disabled=false;
                msg.innerHTML='';
            }
        }, error:function(){
                alert('error');
        }
    });

}