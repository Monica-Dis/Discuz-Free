<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
defined('IN_DISCUZ') or exit('Powered by Hymanwu.Com');

function noPageUrl($url){
return preg_replace('/&page=\d*/is','',$url);
};

function uid_to_username($uid,$nouid_text){
$info = getuserbyuid($uid);
$username = $uid ? $info['username'] : $username = $nouid_text;
return $username;
}

function jump($str,$type=1,$url=APP_URL){
if ($type) {
	echo '<script>alert("'.$str.'");window.history.go(-1);</script>';
} else {
	echo '<script>alert("'.$str.'");window.location.href="'.$url.'";</script>';
}
exit;
}

function img_to_hex($filename){
    $file = file_get_contents($filename);
    $code = strtoupper(bin2hex($file));
    return $code;
}

function uc_avatar_code($uid, $type='virtual'){
    $uid = intval($uid);
    $uc_input = uc_api_input('uid='.$uid);
    $input = str_replace('25','',$uc_input);
    return $input;
}

function upload_avatar($uid,$tmpAvatar,$delTmp=true){
    global $_G;
    $uid = intval($uid);
    $attachdir = DISCUZ_ROOT.$_G['setting']['attachurl'];
    @dmkdir($attachdir.APP_ID);
    $imgB_path = $attachdir.APP_ID.'/'.$uid.'_big.jpg';
    $imgM_path = $attachdir.APP_ID.'/'.$uid.'_middle.jpg';
    $imgS_path = $attachdir.APP_ID.'/'.$uid.'_small.jpg';
    image_resize($tmpAvatar,$imgB_path, 200, 200);
    image_resize($tmpAvatar,$imgM_path, 120, 120);
    image_resize($tmpAvatar,$imgS_path, 48, 48);
    $input = uc_avatar_code($uid);
    $action = UC_API.'/index.php?m=user&inajax=1&a=rectavatar&appid='.UC_APPID.'&input='.$input.'&avatartype=virtual';
    $formvars = array(
        'avatar1' => img_to_hex($imgB_path),
        'avatar2' => img_to_hex($imgM_path),
        'avatar3' => img_to_hex($imgS_path)
    );
    $formvars = http_build_query($formvars);
    $options = array(
        'http' => array(
            'method' => 'POST',
            'user_agent'=>$_SERVER['HTTP_USER_AGENT'],
            'content' => $formvars
        )
    );
    @fopen($action,'b', false, stream_context_create($options));
    if ($delTmp) {
        @unlink($tmpAvatar);
    }
    @unlink($imgB_path);
    @unlink($imgM_path);
    @unlink($imgS_path);
    C::t('common_member')->update(array('uid'=>$uid),array('avatarstatus'=>1));
}

function image_resize($source_path, $target_path='', $target_width = 200, $target_height = 200, $fixed_orig = ''){
    $source_info = getimagesize($source_path);
    $source_width = $source_info[0];
    $source_height = $source_info[1];
    $source_mime = $source_info['mime'];
    $ratio_orig = $source_width / $source_height;
    if ($fixed_orig == 'width'){
        $target_height = $target_width / $ratio_orig;
    }elseif ($fixed_orig == 'height'){
        $target_width = $target_height * $ratio_orig;
    }else{
        if ($target_width / $target_height > $ratio_orig){
            $target_width = $target_height * $ratio_orig;
        }else{
            $target_height = $target_width / $ratio_orig;
        }
    }
    $source_image = imagecreatefromjpeg($source_path);
    $target_image = imagecreatetruecolor($target_width, $target_height);
    imagecopyresampled($target_image, $source_image, 0, 0, 0, 0, $target_width, $target_height, $source_width, $source_height);
    //header('Content-type: image/jpeg');
    imagejpeg($target_image, $target_path, 100);
}

function changename_for_dz($old_username,$new_newname){

    $had_member = DB::fetch_first("SELECT * FROM " . DB::table('common_member') . " WHERE username='$old_username'");

    if($had_member){

        DB::query("UPDATE " . DB::table('common_adminnote') . " SET admin='$new_newname' WHERE admin='$old_username'");
        DB::query("UPDATE " . DB::table('common_block') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('common_block_item') . " SET title='$new_newname' WHERE title='$old_username'");
        DB::query("UPDATE " . DB::table('common_block_item_data') . " SET title='$new_newname' WHERE title='$old_username'");
        DB::query("UPDATE " . DB::table('common_card_log') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('common_failedlogin') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('common_grouppm') . " SET author='$new_newname' WHERE author='$old_username'");
        DB::query("UPDATE " . DB::table('common_invite') . " SET fusername='$new_newname' WHERE fusername='$old_username'");
        DB::query("UPDATE " . DB::table('common_member') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('common_member_security') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('common_member_validate') . " SET admin='$new_newname' WHERE admin='$old_username'");
        DB::query("UPDATE " . DB::table('common_member_verify_info') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('common_member_security') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('common_mytask') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('common_report') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('common_session') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('common_word') . " SET admin='$new_newname' WHERE admin='$old_username'");
        DB::query("UPDATE " . DB::table('forum_activityapply') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_announcement') . " SET author='$new_newname' WHERE author='$old_username'");
        DB::query("UPDATE " . DB::table('forum_collection') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_collectioncomment') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_collectionfollow') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_collectionteamworker') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_forumrecommend') . " SET author='$new_newname' WHERE author='$old_username'");
        DB::query("UPDATE " . DB::table('forum_groupuser') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_imagetype') . " SET name='$new_newname' WHERE name='$old_username'");
        DB::query("UPDATE " . DB::table('forum_order') . " SET buyer='$new_newname' WHERE buyer='$old_username'");
        DB::query("UPDATE " . DB::table('forum_order') . " SET admin='$new_newname' WHERE admin='$old_username'");
        DB::query("UPDATE " . DB::table('forum_pollvoter') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_post') . " SET author='$new_newname' WHERE author='$old_username'");
        DB::query("UPDATE " . DB::table('forum_postcomment') . " SET author='$new_newname' WHERE author='$old_username'");
        DB::query("UPDATE " . DB::table('forum_promotion') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_ratelog') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_rsscache') . " SET author='$new_newname' WHERE author='$old_username'");
        DB::query("UPDATE " . DB::table('forum_thread') . " SET author='$new_newname' WHERE author='$old_username'");
        DB::query("UPDATE " . DB::table('forum_threadmod') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_trade') . " SET seller='$new_newname' WHERE seller='$old_username'");
        DB::query("UPDATE " . DB::table('forum_tradelog') . " SET seller='$new_newname' WHERE seller='$old_username'");
        DB::query("UPDATE " . DB::table('forum_tradelog') . " SET buyer='$new_newname' WHERE buyer='$old_username'");
        DB::query("UPDATE " . DB::table('forum_warning') . " SET author='$new_newname' WHERE author='$old_username'");
        DB::query("UPDATE " . DB::table('home_album') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_blog') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_clickuser') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_comment') . " SET author='$new_newname' WHERE author='$old_username'");
        DB::query("UPDATE " . DB::table('home_docomment') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_doing') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_feed') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_feed_app') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_follow') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_follow') . " SET fusername='$new_newname' WHERE fusername='$old_username'");
        DB::query("UPDATE " . DB::table('home_follow_feed') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_follow_feed_archiver') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_friend') . " SET fusername='$new_newname' WHERE fusername='$old_username'");
        DB::query("UPDATE " . DB::table('home_friend_request') . " SET fusername='$new_newname' WHERE fusername='$old_username'");
        DB::query("UPDATE " . DB::table('home_notification') . " SET author='$new_newname' WHERE author='$old_username'");
        DB::query("UPDATE " . DB::table('home_pic') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_poke') . " SET fromusername='$new_newname' WHERE fromusername='$old_username'");
        DB::query("UPDATE " . DB::table('home_share') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_show') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_specialuser') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_visitor') . " SET vusername='$new_newname' WHERE vusername='$old_username'");
        DB::query("UPDATE " . DB::table('home_specialuser') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('portal_article_title') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('portal_comment') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('portal_rsscache') . " SET author='$new_newname' WHERE author='$old_username'");
        DB::query("UPDATE " . DB::table('portal_topic') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('portal_topic_pic') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_collection') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_collectioncomment') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_collectionfollow') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('forum_collectionteamworker') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_follow') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_follow') . " SET username='$fusername' WHERE username='$fusername'");
        DB::query("UPDATE " . DB::table('home_follow_feed') . " SET username='$new_newname' WHERE username='$old_username'");
        DB::query("UPDATE " . DB::table('home_follow_feed_archiver') . " SET username='$new_newname' WHERE username='$old_username'");

    }

    return $had_member;

}



function changename_for_uc($old_username, $new_newname){

    DB::query("UPDATE " . UC_DBTABLEPRE . "admins SET username='$new_newname' WHERE username='$old_username'");
    DB::query("UPDATE " . UC_DBTABLEPRE . "badwords SET admin='$new_newname' WHERE admin='$old_username'");
    DB::query("UPDATE " . UC_DBTABLEPRE . "feeds SET username='$new_newname' WHERE username='$old_username'");
    DB::query("UPDATE " . UC_DBTABLEPRE . "members SET username='$new_newname' WHERE username='$old_username'");
    DB::query("UPDATE " . UC_DBTABLEPRE . "mergemembers SET username='$new_newname' WHERE username='$old_username'");
    DB::query("UPDATE " . UC_DBTABLEPRE . "protectedmembers SET username='$new_newname' WHERE username='$old_username'");

}
//From: Dism��taobao��com
?>