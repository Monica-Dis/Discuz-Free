<?php
/**
 * 
 * DisM!出品 必属精品
 * DisM!应用中心所有 https://dism.Taobao.Com
 * 专业Discuz!应用插件、模板正版采购提供代下载服务、技术支持等全方位服务...
 * 我们致力于为站长提供正版Discuz!应用而努力
 * E-mail: dism.taobao@qq.com
 * 工作时间: 周一到周五早上09:00-12:00, 下午13:00-18:00, 晚上19:30-23:30(周六、日休息)
 * DisM!用户交流群: ①群778390776
 * 
 */
defined('IN_DISCUZ') or exit('Powered by Hymanwu.Com');

$pluginid = 'hwh_member';
$wsq_setting = !empty($_G['setting']['mobilewechat']) ? unserialize($_G['setting']['mobilewechat']) : array();//微社区配置

if ($wsq_setting['wsq_allow']) {//开启微社区则注册接口

$Hooks = array(
	'profile_variables',
	'profile_extraInfo',
	'profile_authorInfo'
);

$data = array();
foreach($Hooks as $Hook) {
	$data[] = array($Hook => array(
		'plugin' => $pluginid,
		'include' => 'api.class.php',
		'class' => $pluginid.'_api',
		'method' => $Hook
		)
	);
}

require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::updateAPIHook($data);

}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_hwh_member_resetname` (
  `id` mediumint(8) NOT NULL auto_increment,
  `uid` mediumint(8) NOT NULL,
  `doing` mediumint(8) NOT NULL,
  `done` mediumint(8) NOT NULL,
  `newname` varchar(15) NOT NULL,
  `oldname` varchar(500) NOT NULL,
  `dateline` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 ;

ALTER TABLE `pre_common_member_profile` ADD `hwh_wechat` VARCHAR(255) NOT NULL;

EOF;
runquery($sql);

$finish = TRUE;

?>
