<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class hwh_member_api{

	protected $lang = null;

	public function __construct(){
		include 'language/'.currentlang().'.php';
	 	$this->lang = $language['php'];
	 }

	public function profile_extraInfo(){
		global $_G;
		$link = $_G['siteurl'].'plugin.php?id=hwh_member';
		$html = array(
		  array(
		    'name' =>'<a href="'.$link.'&m=profile">'.$this->lang['008'].'</a>',
		    'link' =>$link.'&m=profile',
		  ),
		  array(
		    'name' =>'<a href="'.$link.'&m=avatar">'.$this->lang['009'].'</a>',
		    'link' =>$link.'&m=avatar',
		  )
		);

		if ( empty($_GET['uid']) || $_GET['uid'] == $_G['uid'] ) {
			return $html;
		}

	}

	public function profile_variables(&$variables) {
		// require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
		$variables['function'] = array(
		    'hwh_show_avatar' => array('WSQ.show', array('hwh_show_avatar')),
		    'hwh_hide_avatar' => array('WSQ.hide', array('hwh_show_avatar')),
		    'hwh_get_avatar' => array('WSQ.ajaxget', array('id=hwh_member&m=getavatar&uid='.$_GET['uid'],'avatar_output')),
		);
	}

	public function profile_authorInfo(){
		global $_G;
		$css_1 ='font-style:normal;font-size:1em;color:#5A85CE;';
		$css_2 ='display: block;z-index:997; position: absolute;left: 10px;top: 10px;height: 35px;width: 35px;';
		$css_3 ='height: 200px;width: 200px;line-height: 200px;text-align: center;display: none;z-index:998;padding:5px;background:rgba(255,255,255,1);box-shadow:0 1px 2px rgba(0,0,0,.3);margin:auto;position:fixed;top:35%;left:50%;-webkit-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);transform:translate(-50%,-50%)"><a click="hwh_hide_avatar()" style="z-index:999;box-shadow:0 1px 1px rgba(0,0,0,.3);text-align:center;line-height:28px;top:-9px;right:-9px;display:block;width:28px;height:28px;border-radius:50%;color:#FFF;position:absolute;font-size:18px;background:rgba(0,0,0,.9);font-style: normal';

		$avatar_html = '<a click="hwh_get_avatar()" style="'.$css_2.'"></a><div id="hwh_show_avatar" style="'.$css_3.'">X</a><div id="avatar_output">loading...</div></div>';

		if ( empty($_GET['uid']) || $_GET['uid'] == $_G['uid'] ) {
			$html = '<br><a href="'.$_G['siteurl'].'plugin.php?id=hwh_member&m=profile" style="'.$css_1.'">'.$this->lang['008'].'</a> / <a href="'.$_G['siteurl'].'plugin.php?id=hwh_member&m=avatar" style="'.$css_1.'">'.$this->lang['009'].'</a>';
		} else {
			$uid = intval($_GET['uid']);
			$profile = C::t('common_member_profile')->fetch(array('uid'=>$uid));
			$genderHtml = $this->genderStr($profile['gender']);
			$wechatHtml = '<br><span style="font-style:normal; color:#8DC56A; font-size:12px; padding-left:2px; background:#FFF;border-radius:2px;border:1px solid #8DC56A;">'.$this->lang['010'].'<span style="background:#8DC56A; margin-left:2px; color:#FFF; padding:0 2px 0 3px;">'.$profile['hwh_wechat'].'</span></span>';
			$html = empty($profile['hwh_wechat']) ? $genderHtml : $genderHtml.$wechatHtml;
		}

		return $avatar_html.$html;
	}

	public function genderStr($gender){
		$html='';
		$css_1 = 'font-style:normal; color:#FFF; font-size:10px;';
		if($gender==1){
			$html = '<span class="gBg1" style="'.$css_1.'background:#2776DB;">'.$this->lang['011'].'</span>';
		}elseif ($gender==2) {
			$html = '<span class="gBg1" style="'.$css_1.'background:#F0598C;">'.$this->lang['012'].'</span>';
		}

		return $html;
	}

}
//From: Dism��taobao��com
?>