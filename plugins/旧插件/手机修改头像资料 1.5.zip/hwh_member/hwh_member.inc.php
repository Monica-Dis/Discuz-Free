<?php

/*
+------------------------------------------------------------------------------------------------
|
|   Copyright (c) 2015 by H.W.H
|   http://www.hymanwu.com  http://addon.discuz.com/?@19547.developer
|   Support: five5@vip.qq.com QQ:304916488 QQgroup:58367645
|   Please don't change the copyright, This is NOT a freeware!
|
+------------------------------------------------------------------------------------------------
*/

defined('IN_DISCUZ') or exit('Powered by Hymanwu.Com');
include 'language/'.currentlang().'.php';
$plang = $language['php'];
$hlang = $language['html'];
if (!$_G['uid']) { showmessage($plang['001'],null,array(),array('login' =>1)); }
define('APP_ID','hwh_member');
define('APP_DIR','source/plugin/'.APP_ID);
define('APP_URL',$_G['siteurl'].'plugin.php?id='.APP_ID);
define('CUR_PAGE','http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
$config = $_G['cache']['plugin'][APP_ID];
include 'common.func.php';
include 'core.inc.php';

?>