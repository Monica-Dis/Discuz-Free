<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$pluginid = 'hwh_member';
$wsq_setting = !empty($_G['setting']['mobilewechat']) ? unserialize($_G['setting']['mobilewechat']) : array();//微社区配置
$pre = DB::table();//pre_

if ($wsq_setting['wsq_allow'] ) {//开启微社区则注册接口

$Hooks = array(
	'profile_variables',
	'profile_extraInfo',
	'profile_authorInfo'
);

$data = array();
foreach($Hooks as $Hook) {
  $data[] = array($Hook => array(
    'plugin' => $pluginid,
    'include' => 'api.class.php',
    'class' => $pluginid.'_api',
    'method' => $Hook
    )
  );
}

require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::updateAPIHook($data);

}

$sql = array(
	'1.2'=>"CREATE TABLE `".$pre."hwh_member_resetname` (
			`id` mediumint(8) NOT NULL auto_increment,
			`uid` mediumint(8) NOT NULL,
			`doing` mediumint(8) NOT NULL,
			`done` mediumint(8) NOT NULL,
			`newname` varchar(15) NOT NULL,
			`oldname` varchar(500) NOT NULL,
			`dateline` int(10) NOT NULL,
			PRIMARY KEY (`id`)
			) ENGINE=MyISAM AUTO_INCREMENT=1 ;",
);

foreach ($sql as $v) {
	DB::query($v,'SILENT');
}

$finish = TRUE;

?>