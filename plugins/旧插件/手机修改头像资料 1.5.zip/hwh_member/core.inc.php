<?php

defined('IN_DISCUZ') or exit('Powered by Hymanwu.Com');

$uid = $_G['uid'];
$profile = C::t('common_member_profile')->fetch(array('uid'=>$uid));
$profile['username'] = $_G['member']['username'];
$profile['email'] = $_G['member']['email'];
$avatar_rand = '&time='.time();
$profile['avatar'] = avatar($uid,'middle',true).$avatar_rand;
$profile['avatar_small'] = avatar($uid,'small',true).$avatar_rand;
$profile['avatar_big'] = avatar($uid,'big',true).$avatar_rand;
$reset_name_groops = dunserialize($config['reset_name_groops']);
$rename_info = C::t('#'.APP_ID.'#hwh_member_resetname')->fetch_first_by_uid($uid);
$can_rename = !$rename_info['doing'] && $rename_info['done']<$config['reset_name_num'] ? true : false;
$price_type = $_G['setting']['extcredits'][$config['price_type']]['title'];
$price = intval(round($config['price']));
$have_price = getuserprofile('extcredits'.$config['price_type']);
$recavatar_item = str_replace("\r\n",'|',str_replace(" ",'',$config['recavatar']));
loaducenter();

switch ($_GET['m']) {
    case 'profile':
        if ($_GET['formhash'] == FORMHASH){
            $newpassword = daddslashes(dhtmlspecialchars($_GET['newpassword']));
            if ($_GET['newpassword']!=$newpassword) {
                jump($plang['002']);
            }elseif(!empty($_GET['newpassword']) && strlen($_GET['newpassword'])<6){
                jump($plang['003']);
            }elseif( !empty($_GET['hwh_wechat']) && (strlen($_GET['hwh_wechat'])>20 || strlen($_GET['hwh_wechat'])<6)){
                jump($plang['004']);
            }elseif( !empty($_GET['qq']) && (strlen($_GET['qq'])<5 || strlen($_GET['qq'])>10) ){
                jump($plang['005']);
            }

            $data = array(
                'realname'        =>$_GET['realname'],
                'gender'          =>$_GET['gender'],
                'hwh_wechat'      =>$_GET['hwh_wechat'],
                'qq'              =>$_GET['qq'],
                'mobile'          =>$_GET['mobile'],
                'birthyear'       =>$_GET['birthyear'],
                'birthmonth'      =>$_GET['birthmonth'],
                'birthday'        =>$_GET['birthday'],
                'resideprovince'  =>$_GET['resideprovince'],
                'residecity'      =>$_GET['residecity'],
                'residedist'      =>$_GET['residedist'],
                'residecommunity' =>$_GET['residecommunity']
            );

            C::t('common_member_profile')->update(array('uid' =>$uid),$data);
            C::t('common_member')->update(array('uid' =>$uid),array('email' =>$_GET['email']));

            if(!empty($_GET['newpassword'])) {
                $ucresult = uc_user_edit($_G['username'],'',$newpassword,$_GET['email'],1);
            }else{
                $ucresult = uc_user_edit($_G['username'],'','',$_GET['email'],1);
            }

            jump($plang['006'],0);
        }else{
            defined('IN_MOBILE') ? include template('hwh_member:index') : header('Location: '.$_G['siteurl'].'home.php?mod=spacecp');
        }
        break;

    case 'avatar':
        if ($_GET["image_file"] && $_GET['formhash'] == FORMHASH){
            $imgdata = explode(',',$_GET['image_file']);
            $imgdata = base64_decode($imgdata[1]);
            $tmpAvatar = DISCUZ_ROOT.$_G['setting']['attachurl'].APP_ID.'/'.$uid.'.jpg';
            file_exists($tmpAvatar) && @unlink($tmpAvatar);
            file_put_contents($tmpAvatar,$imgdata);
            upload_avatar($uid,$tmpAvatar);
        }else{
            defined('IN_MOBILE') ? include template('hwh_member:avatar') : header('Location: '.$_G['siteurl'].'home.php?mod=spacecp&ac=avatar');
        }
        break;

    case 'resetname':
        if ($_GET['formhash'] == FORMHASH){
            $data = array(
                'uid'=>$uid,
                'doing'=>1,
                'newname'=>$_GET['newname'],
                'dateline'=>TIMESTAMP
            );
            $had = C::t('#'.APP_ID.'#hwh_member_resetname')->fetch_first_by_uid($uid);
            $idNum = $had ? C::t('#'.APP_ID.'#hwh_member_resetname')->update(array('id'=>$had['id']),$data) : C::t('#'.APP_ID.'#hwh_member_resetname')->insert($data);
            notification_add(1,'system', $plang['031'].'<a href="admin.php?action=plugins&operation=config&identifier=hwh_member&pmod=admincp&m=rename" target="_blank">'.$plang['032'].'</a>', array());
            echo json_encode(array('status'=>$idNum ? 1 : 0));
        }
        break;

    case 'recavatar':
        if ($_GET['fileneme']) {
            $tmpAvatar = DISCUZ_ROOT.'source/plugin/hwh_member/static/images/avatar/'.$_GET['fileneme'];
            upload_avatar($uid,$tmpAvatar,false);
            echo json_encode(array('status'=>1));
        }
        break;

    case 'getavatar':
        $view_uid = $_GET['uid'] ? intval($_GET['uid']) : $_G['uid'];
        $variable = '<img src="'.avatar($view_uid,'big',true).'"><wsqscript>hwh_show_avatar();</wsqscript>';
        json_output();
        break;

    default:
        if ($config['alone_avatar']) {
            defined('IN_MOBILE') ? include template('hwh_member:avatar') : header('Location: '.$_G['siteurl'].'home.php?mod=spacecp&ac=avatar');
        } else {
            defined('IN_MOBILE') ? include template('hwh_member:index') : header('Location: '.$_G['siteurl'].'home.php?mod=spacecp');
        }

}

?>