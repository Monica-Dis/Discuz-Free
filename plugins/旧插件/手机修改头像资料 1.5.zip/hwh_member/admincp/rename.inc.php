<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
defined('IN_DISCUZ') or exit('Powered by Hymanwu.Com');

loadcache('plugin');
$config = $_G['cache']['plugin']['hwh_member'];
$id = intval($_GET['id']);

switch ($_GET['a']) {

  case 'delete':
    C::t('#'.APP_ID.'#hwh_member_resetname')->update(array('id'=>$id),array('doing'=>0));
    $rename_info = C::t('#'.APP_ID.'#hwh_member_resetname')->fetch($id);
    notification_add($rename_info['uid'],'system',$plang['034'], array(),1);
    cpmsg($plang['022'],dreferer(),'succeed');

  break;

  case 'editneme':
  $rename_info = C::t('#'.APP_ID.'#hwh_member_resetname')->fetch($id);

  if (submitcheck('formhash')) {
    loaducenter();
    $new_username = CHARSET=='gbk' ? daddslashes(dhtmlspecialchars($_GET['newname'],ENT_COMPAT,'GB2312')) : daddslashes(dhtmlspecialchars($_GET['newname'],ENT_COMPAT,'utf-8'));
    $check = uc_user_checkname($new_username);
    $error_info = array(
        '-1' =>$plang['024'],
        '-2' =>$plang['025'],
        '-3' =>$plang['026'],
      );
    if ($check != 1) {
        cpmsg($error_info[$check],dreferer(),'error');
      }else{
        C::t('#'.APP_ID.'#hwh_member_resetname')->update($_GET['id'],array('newname'=>$new_username));
        cpmsg($plang['029'],'action='.APP_MANAGE_URL.'&m=rename','succeed');
      }

  } else {
    showformheader(APP_MANAGE_URL.'&a=editneme');
    showtableheader('edit');
    showhiddenfields(array('id'=>$id));
    showsetting($plang['013'],'newname', $rename_info['newname'],'text');
    showsubmit('submit');
    showtablefooter();/*Dism-taobao_com*/
    showformfooter();
  }

  break;

  case 'dorename':
    $price = intval(round($config['price']));
    $rename_info = C::t('#'.APP_ID.'#hwh_member_resetname')->fetch($id);
    $have_price = DB::result_first('SELECT extcredits'.$config['price_type'].' FROM '.DB::table('common_member_count').' WHERE uid='.$rename_info['uid']);
    if (!$config['price_type'] || !$price || $have_price>=$price) {
      loaducenter();
      $old_username = uid_to_username($rename_info['uid']);
      $new_username = CHARSET=='gbk' ? daddslashes(dhtmlspecialchars($rename_info['newname'],ENT_COMPAT,'GB2312')) : daddslashes(dhtmlspecialchars($rename_info['newname'],ENT_COMPAT,'utf-8'));
      $check = uc_user_checkname($new_username);
      $error_info = array(
          '-1' =>$plang['024'],
          '-2' =>$plang['025'],
          '-3' =>$plang['026'],
        );
      if ($check != 1) {
          cpmsg($error_info[$check],dreferer(),'error');
      }else{
          changename_for_dz($old_username,$new_username);
          changename_for_uc($old_username,$new_username);
          DB::query('UPDATE '.DB::table('hwh_member_resetname').' SET `done`=`done`+1,`doing`=0,`oldname`=\''.$rename_info['oldname'].' , '.$old_username.'\' WHERE id='.$id);
            updatemembercount($rename_info['uid'], array('extcredits'.$config['price_type'] => -$config['price']), true, '', 0, '',$plang['036'].$new_username);
          notification_add($rename_info['uid'],'system',$plang['033'], array(),1);
          cpmsg($plang['021'],dreferer(),'succeed');
       }
    } else {
      cpmsg($plang['035'],dreferer(),'error');
    }

  break;

  default:
  //#page set
  $curpage = $_G['page'];
  $limit = 20;
  $start = ($curpage-1)*$limit;
  $condition = $_GET['done'] ? 'done>0' : 'doing=1';
  $count = getcount('hwh_member_resetname',$condition);
  $pagelink = noPageUrl(CUR_PAGE);
  $tpl_page = multi($count,$limit,$curpage,$pagelink);
  #\\
  $tpl_list = C::t('#'.APP_ID.'#hwh_member_resetname')->range_rename($start,$limit,$condition,'doing DESC,dateline DESC');
  if (count($tpl_list) && $config['price_type']) {
    foreach ($tpl_list as $v) {
       $uids .= $comma.$v['uid'];
       $comma = ',';
    }
    $price_type = 'extcredits'.$config['price_type'];
    $all_money = DB::fetch_all('SELECT uid,'.$price_type.' FROM '.DB::table('common_member_count').' WHERE uid IN ('.$uids.')');
    foreach ($all_money as $k => $v) {
      $money[$v['uid']] = $v[$price_type];
    }
  }

  foreach ($tpl_list as $key => $value) {
      $tr_rows .= showtablerow('', array('class="td23"','width="200"','','width="150"','width="150"'), array(
      $value['uid'],
      '<a href="'.$_G['siteurl'].'?'.$value['uid'].'" target="_blcnk">'.uid_to_username($value['uid']).'</a>',
      $_GET['done'] ? ltrim($value['oldname'],' , ') : '<font color="green" size="4" >'.$value['newname'].'</font> <a href="'.APP_URL.'&m=rename&a=editneme&id='.$value['id'].'">['.$plang['023'].']</a>',
      $money[$value['uid']] >= $config['price'] ? '<font color="green">'.$money[$value['uid']].'</font>' : '<font color="red">'.$money[$value['uid']].'</font>',
      $value['done'],
      dgmdate($value['dateline'],'u'),
      $_GET['done'] ? '' : '<a class="btn" onclick="return sure();" href="'.APP_URL.'&m=rename&a=dorename&id='.$value['id'].'">'.$plang['017'].'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a class="btn" href="'.APP_URL.'&m=rename&a=delete&id='.$value['id'].'">'.$plang['018'].'</a>'),
      true);
  }

  $_GET['done'] ? showtableheader('<a href="'.APP_URL.'&m=rename">'.$plang['019'].'</a>/'.$plang['020']) : showtableheader($plang['019'].'/<a href="'.APP_URL.'&m=rename&done=1">'.$plang['020'].'</a>');
  showsubtitle(array('uid',
    'username',
    $_GET['done'] ? $plang['027'] : $plang['013'],
    $config['price_type'] ? $_G['setting']['extcredits'][$config['price_type']]['title'] : '',
    $plang['014'],
    $_GET['done'] ? $plang['028'] : $plang['015']
    ));
  echo $tr_rows;
  showsubmit('','','','',$tpl_page);
  showtablefooter();/*Dism-taobao_com*/

}
//From: Dism��taobao��com
?>