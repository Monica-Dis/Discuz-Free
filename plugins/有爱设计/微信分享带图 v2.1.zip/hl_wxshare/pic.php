<?php
/**
 * 
 * DisM!出品 必属精品
 * DisM!应用中心所有 https://dism.Taobao.Com
 * 专业Discuz!应用插件、模板正版采购提供代下载服务、技术支持等全方位服务...
 * 我们致力于为站长提供正版Discuz!应用而努力
 * E-mail: dism.taobao@qq.com
 * 工作时间: 周一到周五早上09:00-12:00, 下午13:00-18:00, 晚上19:30-23:30(周六、日休息)
 * DisM!用户交流群: ①群778390776
 * 
 */
defined('IN_DISCUZ') || exit('Powered by Hymanwu.Com');

/*获取帖子图片*/
function get_thread_img($data=array(),$cfg=array(),$size=array()){
	$dft = array(
		'width'=>200,
		'height'=>100,
		'num'=>999999,
		'webimg'=>false,
		);

	$cfg = array_merge($dft,$cfg);

	if ($data) {
		foreach ($data as $k => $v) {
			$tids[] = $v['tid'];
		}
	}else{
		return false;
	}

	require_once libfile('function/post');
	$query = DB::query('SELECT * FROM %t WHERE `tid` IN (%n)',array('forum_attachment',(array)$tids));
    while($row = DB::fetch($query)) {
        $tableids[$row['tableid']][] = $row['aid'];
    }

    $att_img_temp = array();
    foreach ($tableids as $tableid => $aids) {
        $att_img_temp = array_merge($att_img_temp, C::t('forum_attachment_n')->fetch_all($tableid, $aids, false, true));
    }
    foreach ($att_img_temp as $v) {
        $imgaids[] = $v['aid'];
        $tempdata[$v['tid']]['imgattachs'][] = $v['aid'];
    }

    $post = C::t('forum_post')->fetch_all_by_tid('', $tids, true, '', 0, 0, 1);

    foreach ($post as $v) {
        $regex1 = "/(\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\])|(\[img=(\d{1,4})[x|\,](\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\/img\])|(\[attach\]\s*([^\[\<\r\n]+?)\s*\[\/attach\])/ies";
        $regex2 = "/\](.*)\[\//ies";
        preg_match_all($regex1, $v['message'], $message_imgs);
        if ($message_imgs['0']) {
            foreach ($message_imgs['0'] as $vvv) {
                preg_match($regex2, $vvv, $img_or_url);
                $web_img = $cfg['webimg'] && !is_numeric($img_or_url[1]) ? $img_or_url[1] : '';
                $tempdata[$v['tid']]['messageimg'][] = in_array($img_or_url[1],$imgaids) ? $img_or_url[1] : $web_img;
            }
        }

        if (!$tempdata[$v['tid']]['messageimg']) $tempdata[$v['tid']]['messageimg'] = array();
        if (!$tempdata[$v['tid']]['imgattachs']) $tempdata[$v['tid']]['imgattachs'] = array();
        $all_img = array_filter(array_unique(array_merge($tempdata[$v['tid']]['messageimg'], array_reverse($tempdata[$v['tid']]['imgattachs']))));
        $tempdata[$v['tid']]['allimg'] = array_slice($all_img, 0, $cfg_img_num);
        $tempdata[$v['tid']]['allimg_count'] = count($all_img);
    }

    $img_arr_temp = array();
    foreach ($data as $v) {
    	$img_arr_temp[$v['tid']] = $tempdata[$v['tid']]['allimg'];
    }

    foreach ($img_arr_temp as $k => $v) {
    	if (!$img_arr_temp[$k]) {
    		$img_arr[$k] = array();
    	}
    	$img_num = count($v);
    	if (in_array($img_num,array_keys($size))) {
    		list($w,$h) = explode('|',$size[$img_num]);
    		foreach ($v as $vv) {
    			$img_arr[$k][] = is_numeric($vv) ? getforumimg($vv, 0, $w, $h, '') : $vv;
    		}
    	}else{
    		foreach ($v as $vv) {
    			$img_arr[$k][] = is_numeric($vv) ? getforumimg($vv, 0, $cfg['width'], $cfg['height'], '') : $vv;
    		}
    	}
    }

	return $img_arr;
}
