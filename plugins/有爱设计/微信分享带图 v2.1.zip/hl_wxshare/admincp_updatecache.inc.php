<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$step = max(1, intval($_GET['step']));
shownav('tools', 'nav_updatecache');
showsubmenusteps('nav_updatecache', array(
	array('nav_updatecache_confirm', $step == 1),
	array('nav_updatecache_completed', $step == 2)
));

if($step == 1) {
	cpmsg("$lang[nav_updatecache_confirm]", 'action=plugins&operation=config&identifier=hl_wxshare&pmod=admincp_updatecache&step=2', 'form', '', FALSE);
} elseif($step == 2) {
	savecache('hl_wxshare_jsapi', array('expire_time' => '', 'jsapi_ticket' => ''));
	savecache('hl_wxshare_access', array('expire_time' => '', 'access_token' => ''));
	cpmsg('update_cache_succeed', '', 'succeed', '', FALSE);
}
//From: Dism_taobao_com
?>