<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once "jssdk.php";

class mobileplugin_hl_wxshare {
	function global_header_mobile(){
        global $_G, $postlist,$list;
		$_C=$_G['cache']['plugin']['hl_wxshare'];
		$jssdk = new JSSDK($_C['hl_wx_appid'], $_C['hl_wx_appsecret']);
		$signPackage = $jssdk->GetSignPackage();
		$cackprotocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		$hlurl = "$cackprotocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			if($_G['basescript'] == 'forum' && CURMODULE =='viewthread' && $_G['forum_thread']['tid'] && $_G['forum_thread']['authorid']) {
				require_once "pic.php";
				require_once(DISCUZ_ROOT."./source/function/function_post.php");
				foreach ($postlist as $thread) {
					$hl_des = str_replace(array("\r", "\n", " "), '', messagecutstr(DB::result_first('SELECT `message` FROM '.DB::table('forum_post').' WHERE `tid` ='.$thread['tid'].' AND `first` =1'),120));
				}
				 if($_G['forum_thread']['attachment']== '2'){
					foreach ($postlist as $thread) {
						$thread_img = get_thread_img($postlist,array('width'=>100,'height'=>100,'webimg'=>1));
						$thread_img[$thread['tid']] = array_slice($thread_img[$thread['tid']],0,1);
						foreach ($thread_img[$thread['tid']] as $img) {
							$hlpic = $_G['siteurl'].$img;
						}
					}
				}
				elseif($_G['forum_thread']['attachment']== '0'){
					foreach ($postlist as $thread) {
						$thread_img = get_thread_img($postlist,array('width'=>100,'height'=>100,'webimg'=>1));
						$thread_img[$thread['tid']] = array_slice($thread_img[$thread['tid']],0,1);
						foreach ($thread_img[$thread['tid']] as $img) {
							$hlpic = $img;
						}
					}
				}
				$hltitle = $_G['forum_thread']['subject'];
			}else if($_G['basescript'] == 'forum' && CURMODULE =='forumdisplay') {
				$hltitle = $_G['forum']['name'];
				$hl_des = $_G['forum']['description'];
				if ($_G['forum']['icon']) {
					$hlpic = $_G['siteurl'].'data/attachment/common/'.$_G['forum']['icon'];
				} else {
					$hlpic = $_C['hl_wx_appicon'];
				}
			}else if($_G['basescript'] == 'portal' && CURMODULE =='view') {
				$articletable = DB::fetch_all('SELECT * FROM '.DB::table('portal_article_title').' WHERE aid = '.intval($_GET['aid']).' LIMIT  0 ,'. 1 );
				if($articletable['0']['pic']){
					if ($_C['hl_cdn']) {
						$hlpic = $_C['hl_cdn'].'portal/'.$articletable['0']['pic'];
					} else {
						$hlpic = $_G['siteurl'].'data/attachment/'.$articletable['0']['pic'];
					}
				}
				$hltitle = $articletable['0']['title'];
				$hl_des = str_replace(array("\r", "\n", " "), '', $articletable['0']['summary']);
			}

		if(!$hlpic){
			$hlpic = $_C['hl_wx_appicon'];
		}
		// debug($_C['hl_sdk']);
		if ($_C['hl_sdk'] == 1) {
			include template('hl_wxshare:jssdk');
		} elseif ($_C['hl_sdk'] == 2){
			include template('hl_wxshare:hook');
		}
		else{
			include template('hl_wxshare:jssdk');
		}
        return $hl_mobole;
	}
}