<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once dirname(__FILE__) . '/class/hl_vip.class.php';
$hl_lang = lang('plugin/hl_vip');

	$vip_id = intval($_GET['vip_id']);
	$pay_type = daddslashes($_GET['pay_type']);
	$ismoey = floatval($_GET['moey']);
	$arr = array();
	if (!$_G['uid']){
		$arr['log'] = $hl_lang['log'];
		$HlVip->arrjson_iconv($arr);
	}
	if ($_G['uid'] == 1 && empty($ismoey)){
		$arr['admin'] = $hl_lang['admin'];
		$HlVip->arrjson_iconv($arr);
	}
	// debug($pay_type);
 	if($_GET['formhash'] != FORMHASH || !$vip_id || !$pay_type){
		$arr['error'] = $hl_lang['error'];
		$HlVip->arrjson_iconv($arr);
	}
	
	if($pay_type == 'alipay'){
		$pay_type = 'alipay';
	}else if($pay_type == 'f2fpay'){
		$pay_type = 'f2fpay';
	}else if($pay_type == 'wx'){
		$pay_type = 'wx';
	}else if($pay_type == 'Appbyme_zfb'){
		$pay_type = 'Appbyme_zfb';
	}else if($pay_type == 'Appbyme_wx'){
		$pay_type = 'Appbyme_wx';
	}else if($pay_type == 'magappx'){
		$pay_type = 'magappx';
	}else if($pay_type == 'QianFan'){
		$pay_type = 'QianFan';
	}
	if(!empty($ismoey)){
		$isbuy_vip = false;
		$moey = $ismoey;
		$where = array('uid'=> $_G['uid'],'pay_status'=> -1,'vip_id'=> $vip_id,'deal_pyte'=> 'buy_credits');
		$url = $HlVip->siteurl.'plugin.php?id=hl_vip';
	}else {
		$isbuy_vip = true;
		$moey = null;
		$where = array('uid'=> $_G['uid'],'pay_status'=> -1,'vip_id'=> $vip_id,'deal_pyte_no'=> 'buy_credits');
		$url = $HlVip->siteurl.'plugin.php?id=hl_vip';
	}
	$buy = $HlVip->get_Creation_pay($isbuy_vip,$pay_type,$vip_id,$url,$moey);
	
	$order = C::t('#hl_vip#hl_vip_paylog')->get_payrecord_log_first($where);
	if ($buy && $order['out_trade_no']){
		$arr['url'] = $HlVip->siteurl.'plugin.php?id=hl_vip:pay&out_trade_no='.$order['out_trade_no'];
		$arr['wxsm'] = $order['pay_pyte'];
		$arr['out_trade_no'] = $order['out_trade_no'];
		$arr['nurl'] = $order['jump_url'];
		$HlVip->arrjson_iconv($arr);
		// arrjson_iconv($arr);
	}else{
		$arr['error'] = '"out_trade_no" or "buy" no value';
		$HlVip->arrjson_iconv($arr);
	}