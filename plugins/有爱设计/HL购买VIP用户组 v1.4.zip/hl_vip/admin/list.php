<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$act = daddslashes($_GET['act']);
// $group = DB::fetch_all("SELECT groupid,grouptitle FROM ".DB::table('common_usergroup')." WHERE type='special'");
$group = C::t('common_usergroup')->fetch_all_by_type(array('special'), 0);
if (!$act) {
	$perpage = 10;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage-1)*$perpage;
	$count = C::t('#hl_vip#hl_vip_list')->get_viplist_count();
	$mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=hl_vip&pmod=admin&mod=list";
	$multipage = multi($count, $perpage,$curpage,$mpurl, 0, 5);
	$vip_list = C::t('#hl_vip#hl_vip_list')->get_viplist($start,$perpage);
	if (!$count){
		cpmsg($hl_lang['error_lists'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=hl_vip&pmod=admin&mod=list&act=add', 'succeed');
	}
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=hl_vip&pmod=admin&mod=list&act=del','enctype');
	showtableheader($hl_lang['infolist']);
		showtablerow('',array(),array(
			'<input type="checkbox" name="chkall" class="checkbox" onclick="checkall(this.form,\'delete\')" />'.$hl_lang['full'].'',
			'ID',
			$hl_lang['vip_name'],
			$hl_lang['vip_group'],
			$hl_lang['vip_time'].'/'.$hl_lang['tian'],
            $hl_lang['vip_prime'].'/'.$hl_lang['vip_price'],
            $hl_lang['vip_credits_presentp'].'/'.$hl_lang['credits_type'],
			$hl_lang['vip_restrict_amount'],
			$hl_lang['vip_discount_valuep'],
			$hl_lang['hl_order'],
			$hl_lang['caozuo']
		));
		foreach ($vip_list as $v) {
			$grouplist = C::t('common_usergroup')->fetch($v['group']);
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				'<input class="checkbox" type="checkbox" name="delete['.$v['id'].']" value="' .$v['id'].'">',
				$v['id'],
				$v['name'],
				$grouplist['grouptitle'],
				$v['time'],
				$v['prime'].'/'.$v['price'],
				$v['credits_present'].'/'.$_G['setting']['extcredits'][$v['credits_present_type']]['title'],
				$v['restrict_amount'],
				$v['discount_value'],
				$v['display'],
				'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do=$pluginid&identifier=hl_vip&pmod=admin&mod=list&act=edit&id='.$v['id'].'">'.$hl_lang['hl_edit'].'</a>'
			));
		}
		$addt = '<input type="button" class="btn" onclick="location.href=\'' . ADMINSCRIPT . '?action=plugins&operation=config&do='.$pluginid. '&identifier=hl_vip&pmod=admin&mod=list&act=add\'" value="'.$hl_lang['hl_new'].'" />';
		showsubmit('submit', $hl_lang['hl_del'], '',$addt, $multipage);
	showtablefooter(); //Dism��taobao��com
	showformfooter(); //Dism_taobao_com
}else if($act == 'add'){
    if (submitcheck('submit')){
        $data = array();
        $data['name'] = daddslashes($_POST['name']);
        $data['group'] = intval($_POST['group']);
		$data['time'] = intval($_POST['time']);
		$data['prime'] = floatval($_POST['prime']);
		$data['price'] = floatval($_POST['price']);
		$data['present_open'] = intval($_POST['present_open']);
		$data['credits_present'] = intval($_POST['credits_present']);
		$data['credits_present_type'] = intval($_POST['credits_present_type']);
		$data['restrict_group'] = serialize(daddslashes($_POST['restrict_group']));
		$data['restrict_amount'] = intval($_POST['restrict_amount']);
		$data['discount'] = intval($_POST['discount']);
		$data['discount_value'] = floatval($_POST['discount_value']);
		$data['discount_group'] = serialize(daddslashes($_POST['discount_group']));
		$data['content'] = $_POST['content'];
		$data['display'] = intval($_POST['display']);
		$data['dateline'] = time();
        C::t('#hl_vip#hl_vip_list')->insert($data);
        cpmsg($hl_lang['success'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=hl_vip&pmod=admin&mod=list', 'succeed');
	}else{
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=hl_vip&pmod=admin&mod=list&act=add', 'enctype');
        showtableheader($hl_lang['newinfo']);
			showsetting($hl_lang['vip_name'], 'name','', 'text', '', '',$hl_lang['vip_names']);
		    showsetting($hl_lang['vip_group'], array('group',$group), '', 'select','','',$hl_lang['vip_groups']);
			showsetting($hl_lang['vip_time'], 'time','', 'text', '', '',$hl_lang['vip_times']);
			showsetting($hl_lang['vip_prime'], 'prime','', 'text', '', '',$hl_lang['vip_primes']);
			showsetting($hl_lang['vip_price'], 'price','', 'text', '', '',$hl_lang['vip_prices']);
			showsetting($hl_lang['vip_present_open'], 'present_open','', 'radio', '', '',$hl_lang['vip_present_opens']);
			showsetting($hl_lang['vip_credits_present'], 'credits_present','', 'text', '', '',$hl_lang['vip_credits_presents']);
			showsetting($hl_lang['vip_credits_present_type'], 'credits_present_type','', '<select name="credits_present_type" style="width:80px">'.$HlVip->get_extcredits_selected().'</select>', '', '',$hl_lang['vip_credits_present_types']);
			showsetting($hl_lang['vip_restrict_group'], 'restrict_group', '', '<select name="restrict_group[]"  multiple="multiple" size="10">'.$HlVip->get_group_selected().'</select><td class="vtop tips2" s="1">'.$hl_lang['vip_restrict_groups'].'</td>');
			showsetting($hl_lang['vip_restrict_amount'], 'restrict_amount','', 'text', '', '',$hl_lang['vip_restrict_amounts']);
			showsetting($hl_lang['vip_discount'], 'discount','', 'radio', '', '',$hl_lang['vip_discounts']);
			showsetting($hl_lang['vip_discount_value'], 'discount_value','', 'text', '', '',$hl_lang['vip_discount_values']);
			showsetting($hl_lang['vip_discount_group'], 'discount_group', '', '<select name="discount_group[]"  multiple="multiple" size="10">'.$HlVip->get_group_selected().'</select><td class="vtop tips2" s="1">'.$hl_lang['vip_discount_groups'].'</td>');
			showsetting($hl_lang['vip_html'], 'content','', 'text', '', '',$hl_lang['vip_htmls']);
			showsetting($hl_lang['hl_order'], 'display','', 'text');
        showsubmit('submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
	}
}else if ($act == 'edit'){
    if (submitcheck('submit')){
        $new_data = array();
        $new_data['name'] = daddslashes($_POST['name']);
        $new_data['group'] = intval($_POST['group']);
		$new_data['time'] = intval($_POST['time']);
		$new_data['prime'] = floatval($_POST['prime']);
		$new_data['price'] = floatval($_POST['price']);
		$new_data['present_open'] = intval($_POST['present_open']);
		$new_data['credits_present'] = intval($_POST['credits_present']);
		$new_data['credits_present_type'] = intval($_POST['credits_present_type']);
		$new_data['restrict_group'] = serialize(daddslashes($_POST['restrict_group']));
		$new_data['restrict_amount'] = intval($_POST['restrict_amount']);
		$new_data['discount'] = intval($_POST['discount']);
		$new_data['discount_value'] = floatval($_POST['discount_value']);
		$new_data['discount_group'] = serialize(daddslashes($_POST['discount_group']));
		$new_data['content'] = $_POST['content'];
		$new_data['display'] = intval($_POST['display']);
        $new_data['dateline'] = time();
        // debug($new_data);
		C::t('#hl_vip#hl_vip_list')->update($new_data, array('id' => intval($_POST['id'])));
        cpmsg($hl_lang['success'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=hl_vip&pmod=admin&mod=list', 'succeed');
	}else{
		$vip_id = intval($_GET['id']);
        $vip_list = C::t('#hl_vip#hl_vip_list')->get_viplist_first($vip_id);
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=hl_vip&pmod=admin&mod=list&act=edit', 'enctype');
		echo '<input type="hidden" name="id" value="'.$vip_list['id'].'"/>';
        showtableheader($hl_lang['editinfo']);
			showsetting($hl_lang['vip_name'], 'name',$vip_list['name'], 'text', '', '',$hl_lang['vip_names']);
		    showsetting($hl_lang['vip_group'], array('group',$group), $vip_list['group'], 'select','','',$hl_lang['vip_groups']);
			showsetting($hl_lang['vip_time'], 'time',$vip_list['time'], 'text', '', '',$hl_lang['vip_times']);
			showsetting($hl_lang['vip_prime'], 'prime',$vip_list['prime'], 'text', '', '',$hl_lang['vip_primes']);
			showsetting($hl_lang['vip_price'], 'price',$vip_list['price'], 'text', '', '',$hl_lang['vip_prices']);
			showsetting($hl_lang['vip_present_open'], 'present_open',$vip_list['present_open'], 'radio', '', '',$hl_lang['vip_present_opens']);
			showsetting($hl_lang['vip_credits_present'], 'credits_present',$vip_list['credits_present'], 'text', '', '',$hl_lang['vip_credits_presents']);
			showsetting($hl_lang['vip_credits_present_type'], 'credits_present_type','', '<select name="credits_present_type" style="width:80px">'.$HlVip->get_extcredits_selected($vip_list['credits_present_type']).'</select>', '', '',$hl_lang['vip_credits_present_types']);
			showsetting($hl_lang['vip_restrict_group'], 'restrict_group', '', '<select name="restrict_group[]"  multiple="multiple" size="10">'.$HlVip->get_group_selected($vip_list['restrict_group']).'</select><td class="vtop tips2" s="1">'.$hl_lang['vip_restrict_groups'].'</td>');
			showsetting($hl_lang['vip_restrict_amount'],'restrict_amount',$vip_list['restrict_amount'], 'text', '', '',$hl_lang['vip_restrict_amounts']);
			showsetting($hl_lang['vip_discount'], 'discount',$vip_list['discount'], 'radio', '', '',$hl_lang['vip_discounts']);
			showsetting($hl_lang['vip_discount_value'],'discount_value',$vip_list['discount_value'], 'text', '', '',$hl_lang['vip_discount_values']);
			showsetting($hl_lang['vip_discount_group'], 'discount_group','','<select name="discount_group[]"  multiple="multiple" size="10">'.$HlVip->get_group_selected($vip_list['discount_group']).'</select><td class="vtop tips2" s="1">'.$hl_lang['vip_discount_groups'].'</td>');
			showsetting($hl_lang['vip_html'], 'content',$vip_list['content'], 'text', '', '',$hl_lang['vip_htmls']);
			showsetting($hl_lang['hl_order'], 'display',$vip_list['display'], 'text');
        showsubmit('submit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com
	}
}else if ($act == 'del'){
    if (submitcheck('submit')){
		if (empty($_POST['delete'])){
			cpmsg($hl_lang['error_list'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=hl_vip&pmod=admin&mod=list', 'succeed');
		}else{
			foreach ($_POST['delete'] as $del){
				C::t('#hl_vip#hl_vip_list')->delete(array('id' => $del));
			}
			cpmsg($hl_lang['success'],'action=plugins&operation=config&do='.$pluginid.'&identifier=hl_vip&pmod=admin&mod=list', 'succeed');
		}
    }
}
//From: Dism_taobao-com
?>