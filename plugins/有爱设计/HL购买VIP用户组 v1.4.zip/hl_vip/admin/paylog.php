<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

    $act = daddslashes($_GET['act']);
	if ($act == 'empty' && submitcheck('submit')){
		$d = C::t('#hl_vip#hl_vip_paylog')->delete(array('pay_status' => -1));
		cpmsg($hl_lang['success'],'action=plugins&operation=config&do='.$pluginid.'&identifier=hl_vip&pmod=admin&mod=paylog', 'succeed');
	}
	$perpage = 20;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage-1)*$perpage;
	$pdeal_pyte = daddslashes($_GET['deal_pyte']);
	$ppay_status = daddslashes($_GET['pay_status']);
	$pay_pytes = daddslashes($_GET['pay_pyte']);
	$dateline = dmktime($_GET['dateline']);
	$dateline2 = dmktime($_GET['dateline2']);
    $where = array();
	if ($pdeal_pyte){
		$where['deal_pyte'] = $pdeal_pyte;
	}
	if($ppay_status){
		$where['pay_status'] = $ppay_status;
	}
	if ($pay_pytes){
		$where['pay_pyte'] = $pay_pytes;
	}
	if ($_GET['uid']){
		$uid = ($uids = C::t('common_member')->fetch_uid_by_username($_GET['uid'])) ? $uids : $_GET['uid'];
		$uid = is_numeric($uid) ? $uid : -1;
		$where['uid'] = intval($uid);
	}
	if($dateline){
		$date = strtotime(date('Y-m-d',$dateline));
        $where['dateline'] = $date;
	}
	if($dateline2){
		$date2 = strtotime(date('Y-m-d',strtotime( "+1 day",$dateline2)));
        $where['dateline2'] = $date2;
	}
	$count = C::t('#hl_vip#hl_vip_paylog')->get_payrecord_log_count($where);
	$mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=hl_vip&pmod=admin&mod=paylog&deal_pyte=".$pdeal_pyte."&pay_status=".$ppay_status."&pay_pyte=".$pay_pytes."&uid=".$uid."&dateline=".$dateline."&dateline2=".$dateline2;
	$multipage = multi($count, $perpage,$curpage,$mpurl, 0, 5);
	$vip_list = C::t('#hl_vip#hl_vip_paylog')->get_payrecord_log_list($start,$perpage,$where);
	$bnt = $hl_lang['search'];
    $screen = $hl_lang['screen'];
    $pay_statu = $hl_lang['pay_statuss'];
    $uids = $hl_lang['username'];
    $datelines = $hl_lang['payrecord5'];
    $pay_pytemc = $hl_lang['pay_statuss'];

	$pay_pyte = array();
	$pay_pyte[] = array('alipay_pc',$hl_lang['type2']);
	$pay_pyte[] = array('alipay_web',$hl_lang['type8']);
	$pay_pyte[] = array('wx_pc',$hl_lang['type3']);
	$pay_pyte[] = array('wx_h5',$hl_lang['type9']);
	$pay_pyte[] = array('wx_gzh',$hl_lang['type10']);
	$pay_pyte[] = array('f2fpay',$hl_lang['type16']);


	$deal_pyte = array();
	$deal_pyte[] = array('buy_vip',$hl_lang['deal_pyte_vip']);
	$deal_pyte[] = array('vip_renew',$hl_lang['deal_pyte_renew']);
	
	$pay_statuss = array();
	$pay_statuss[] = array(-1, $hl_lang['pay_isno']);
	$pay_statuss[] = array(1, $hl_lang['pay_isok']);

	$deal_pyte = $HlVip->get_select('deal_pyte', $deal_pyte, $pdeal_pyte, array(0,$hl_lang['isscreen']));
	$status_pyte = $HlVip->get_select('pay_status', $pay_statuss, $ppay_status, array(0,$hl_lang['isscreen']));
	$pay_pyte = $HlVip->get_select('pay_pyte', $pay_pyte, $pay_pytes, array(0,$hl_lang['isscreen']));

echo <<<SEARCH
        <script src="static/js/calendar.js" type="text/javascript"></script>
		<form method="post" autocomplete="off" id="tb_search" action="$mpurl">
		<table style="padding:10px 0;">
			<tbody>
				<tr>
				<td>&nbsp;$screen&nbsp;&nbsp;$deal_pyte</td>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;$pay_statu&nbsp;&nbsp;&nbsp;$status_pyte&nbsp;&nbsp;&nbsp;</td>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;$pay_pytemc&nbsp;&nbsp;&nbsp;$pay_pyte&nbsp;&nbsp;&nbsp;</td>
				<td>&nbsp;&nbsp;&nbsp;&nbsp;$uids&nbsp;&nbsp;&nbsp;<input type="text" class="txt" name="uid" value="" style="width:80px;">&nbsp;&nbsp;&nbsp;</td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$datelines</td><td>&nbsp;<td>
                  <input type="text" class="txt" name="dateline" value="{$_GET['dateline']}" onclick="showcalendar(event, this)">~
                  <input type="text" class="txt" name="dateline2" value="{$_GET['dateline2']}" onclick="showcalendar(event, this)">
				</td>
				<td>&nbsp;&nbsp;<input type="submit" class="btn" value="$bnt"></td>
				</tr>
			</tbody>
		</table>
		</form>
SEARCH;

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=hl_vip&pmod=admin&mod=paylog&act=empty','enctype');//
showtableheader($hl_lang['infolist']);
		showtablerow('',array('class="td25"', 'class="td28"'),array(
			'ID',
			$hl_lang['pay_statuss'],
			$hl_lang['screen'],
		    $hl_lang['user'],
			$hl_lang['payrecord2'],
			$hl_lang['pay_statuss'],
			$hl_lang['payrecord3'],
			$hl_lang['payrecord4'],
			$hl_lang['payrecord5']
		));
		foreach ($vip_list as $v) {
			$get_name = getuserbyuid($v['uid']);
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				$v['log_id'],
				$HlVip->get_type($v['pay_pyte']),
				$HlVip->get_type($v['deal_pyte']),
				'<a href="home.php?mod=space&uid='.$v['uid'].'" target ="_blank">'.$get_name['username'].'</a>',
				$money = $v['money'] != 0 ? round($v['money'],2).'/'.$hl_lang['yuan'] : intval($v['credits_present']).'/'.$_G['setting']['extcredits'][$v['credits_type']]['title'],
				$pay_status = $v['pay_status'] == 1 ? '<span style="color:#f00;">'.$hl_lang['pay_isok'].'</span>' : $hl_lang['pay_isno'],
				$trade_no = $v['trade_no'] ? $v['trade_no'] : '--',
				$pay_dateline = $v['pay_dateline'] ? dgmdate($v['pay_dateline'],'Y-m-d H:i:s') : '--',
				dgmdate($v['dateline'],'Y-m-d H:i:s'),
			));
		}
		showsubmit('submit', $hl_lang['empty'],'','',$multipage);
	showtablefooter(); //Dism��taobao��com
showformfooter(); //Dism_taobao_com
?>