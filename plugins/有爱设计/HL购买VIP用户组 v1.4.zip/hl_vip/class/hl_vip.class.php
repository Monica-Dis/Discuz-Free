<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class HlVip {

    public $config = [];
    public $version = '1.0';
    private static $instance;
    final private function __construct()
    {
        global $_G;
        if (!isset($_G['cache']['plugin'])) {
            loadcache('plugin');
        }

        $this->config = $_G['cache']['plugin']['hl_vip'];
        $this->hl_lang = lang('plugin/hl_vip');
        $this->siteurl = $_G['siteurl'];
        // $isFromWeixin = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;
        // $isMobile = checkmobile();
        foreach ($this->config as $k => $v) {
            //转换数组
            if (in_array($k, $this->explode_config)) {
                unset($this->config[$k]);
                foreach (explode("\n", str_replace("\r", '', $v)) as $vs) {
                    list($key, $value)            = explode('=', $vs);
                    $this->config[$k][trim($key)] = trim($value);
                }
            }
        }

    }

    public static function getInstance(){
        if (empty(self::$instance)) {
            self::$instance = new HlVip();
        }
        return self::$instance;
    }
    /* 查询单个支付记录 */
	public function GetPayFirst($Id){
		$Id = $this->ArrayAddslashes($Id);
		return DB::fetch_first('select * from %t where id=%d',array($this->Table,$Id));
    }
    /* 更新支付记录 */
	public function UpdatePay($Id,$Array){
		$Id = $this->ArrayAddslashes($Id);
		$Array = $this->ArrayAddslashes($Array);
		return DB::update($this->Table,$Array,'id='.$Id);
	}
    /* 判断curl是否开启 */
    public function CurlVersion(){
        if(!function_exists('curl_version')){
            exit('Please open curl extension');
        }
    }
    /* 支付方式 */
	public function GetPayList(){
		$PayList = array();
		$WxBrowser = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;
		$AppBymeBrowser = strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false;
		if($this->config['alipay_switch'] && !$WxBrowser && $this->config['alipay_partner'] && $this->config['alipay_key']){
			$PayList['AliPay']['Logo'] = 'source/plugin/hl_vip/static/img/alipay.png';
			$PayList['AliPay']['Name'] = $this->hl_lang['type14'];
			$PayList['AliPay']['Type'] = 'alipay';
        }
        if($this->config['open_f2fpay'] && !$WxBrowser && $this->config['app_id'] && $this->config['f2fpay_private_key'] && $this->config['f2fpay_public_key']){
			$PayList['AliPay']['Logo'] = 'source/plugin/hl_vip/static/img/alipay.png';
			$PayList['AliPay']['Name'] = $this->hl_lang['type16'];
			$PayList['AliPay']['Type'] = 'f2fpay';
		}
		if($this->config['wx_switch'] && $this->config['wx_appid'] && $this->config['wx_secret'] && $this->config['wx_mchid'] && $this->config['wx_key']){
			if(!checkmobile() || $WxBrowser){
				$PayList['WxPay']['Logo'] = 'source/plugin/hl_vip/static/img/wx.png';
				$PayList['WxPay']['Name'] = $this->hl_lang['type15'];
				$PayList['WxPay']['Type'] = 'wx';
			}
		}

		if($this->config['wx_switch'] && $this->config['wx_h5_switch'] && $this->config['wx_appid'] && $this->config['wx_key'] && $this->config['wx_mchid']){
			if(checkmobile() && !$WxBrowser){
				$PayList['WxPay']['Logo'] = 'source/plugin/hl_vip/static/img/wx.png';
				$PayList['WxPay']['Name'] = $this->hl_lang['type15'];
				$PayList['WxPay']['Type'] = 'wx_h5';
			}
		}

		if($this->config['app_wx_switch'] && $this->config['app_wx_appid'] && $this->config['app_wx_key'] && $this->config['app_wx_mchid']){
			if($AppBymeBrowser){
				$PayList['WxPay']['Logo'] = 'source/plugin/hl_vip/static/img/wx.png';
				$PayList['WxPay']['Name'] = $this->hl_lang['type15'];
				$PayList['WxPay']['Type'] = 'appbyme_wx';
			}
		}

		return $PayList;
	}
    /**
     * 数组字符集转换
     * @param  [type] $data        数据源
     * @param  [type] $in_charset  输入字符集
     * @param  [type] $out_charset 输出字符集
     */
    public function hiconv($data, $in_charset, $out_charset) {
        if(is_array($data)) {
            foreach($data AS $key => $val) {
                $data[$key] = hiconv($val, $in_charset, $out_charset);
            }
        } else {
            $data = diconv($data, $in_charset, $out_charset);
        }
        return $data;
    }
    
    public function get_group_selected($groupid=null){
        global $lang;
        $groupselect = array(); 
        $group_list = C::t('common_usergroup')->range();
        foreach($group_list as $group){
            $course = unserialize($groupid);
            $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
            if(in_array($group['groupid'], $course)) {
                $groupselect[$group['type']] .= '<option value="'.$group['groupid'].'" selected >'.$group['grouptitle'].'</option>';
            } else {
                $groupselect[$group['type']] .= '<option value="'.$group['groupid'].'">'.$group['grouptitle'].'</option>';
            }
        }
        $groupselect = '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'
        .($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '')
        .($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '')
        .'<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup>';
        return $groupselect;
    }
    
    public function get_extcredits_selected($extcreditsid=null){
        global $_G;
        for($i=1;$i<=8;$i++){
            if($_G['setting']['extcredits'][$i]['title']!=''){
                if ($i == $extcreditsid){
                    $tmpoption.='<option value="'.$i.'" selected >'.$_G['setting']['extcredits'][$i]['title'].'</option>';
                }else{
                    $tmpoption.='<option value="'.$i.'" >'.$_G['setting']['extcredits'][$i]['title'].'</option>';	
                }
            }
        }
        return $tmpoption;
    }
    
    public function get_Creation_pay($isbuy_vip = true,$pay_type,$vip_id,$jump_url,$moey=null){

        global $_G,$isFromWeixin,$isMobile;
        $isFromWeixin = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;
        $isMobile = checkmobile();
        $orderno = date('Ymd',$_G['timestamp']).$this->get_randChar(12);
        $vip_list = C::t('#hl_vip#hl_vip_list')->get_viplist_first($vip_id);
      
        if($isbuy_vip && !empty($vip_id)){
            $data = array();
            $data['vip_id'] = $vip_id;
            $data['out_trade_no'] = $orderno;
                if ($pay_type =='jf'){
                    $data['pay_pyte'] = 'credits_pay';
                }else if($pay_type =='alipay' && !$isMobile){
                    $data['pay_pyte'] = 'alipay_pc';
                }else if($pay_type =='alipay' && $isMobile && !$isFromWeixin){
                    $data['pay_pyte'] = 'alipay_web';
                }else if($pay_type =='wx' && !$isMobile){
                    $data['pay_pyte'] = 'wx_pc';
                }else if($pay_type =='wx_h5' && $isMobile && !$isFromWeixin){
                    $data['pay_pyte'] = 'wx_h5';
                }else if($pay_type =='wx' && $isMobile && $isFromWeixin){
                    $data['pay_pyte'] = 'wx_gzh';
                }else if($pay_type =='appbyme_wx'){
                    $data['pay_pyte'] = 'appbyme_wx';
                }else if($pay_type =='f2fpay'){
                    $data['pay_pyte'] = 'f2fpay';
                }
            $vip_discounts = C::t('#hl_vip#hl_vip_paylog')->get_payrecord_log_count(array('uid'=> $_G['uid'],'pay_status'=> 1,'vip_id'=> $vip_id));
            $data['deal_pyte'] = $deal_pyte = $vip_discounts ? 'vip_renew' : 'buy_vip';
            $data['uid'] = $_G['uid'];
            $data['groupid_new'] = $vip_list['group'];
            
            $restrict_group = unserialize($vip_list['restrict_group']);
                if (!in_array($_G['groupid'],$restrict_group) && $vip_list['present_open'] && ($vip_discounts <= $vip_list['restrict_amount'])){
                    $vip_time = $vip_list['time'] + $vip_list['present_date'];
                    $data['groupid_overdue'] = TIMESTAMP + $vip_time*86400;

                }else{
                    $data['groupid_overdue'] = TIMESTAMP + $vip_list['time']*86400;
                }
            $data['credits_type'] = $vip_list['credits_type'];
            $data['credits_present'] = $pay_type =='jf' ? $vip_list['credits_price'] : '0';
            
            $groupid_discount = unserialize($vip_list['discount_group']);
            if ($pay_type !='jf'){
                if (in_array($_G['groupid'],$groupid_discount) && $vip_list['discount'] && $vip_discounts){
                    $data['money'] = round($vip_list['price'] * $vip_list['discount_value'],2);

                }else{
                    $data['money'] = round($vip_list['price'],2);
                    // debug($data['money']);
                }
            }else{
                $data['money'] = '0';
            }	
            $data['pay_status'] = -1;
            $data['pay_dateline'] = '0';
            $data['trade_no'] = '0';
            $data['dateline'] = $_G['timestamp'];
            $data['jump_url'] = $jump_url;
            
            $result = C::t('#hl_vip#hl_vip_paylog')->get_payrecord_log_first(array('uid'=> $_G['uid'],'pay_status'=> -1,'vip_id'=> $vip_id,'deal_pyte_no'=> 'buy_credits'));
                if($vip_discounts){
                    $memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
                    $groupterms = dunserialize($memberfieldforum['groupterms']);
                    $data['groupid_overdue'] = ($data['groupid_overdue'] - TIMESTAMP) + $groupterms['ext'][$vip_list['group']];
                }
                if($result){
                    $data['pay_status'] = -1;
                    C::t('#hl_vip#hl_vip_paylog')->update($data,array('out_trade_no'=> $result['out_trade_no']));
                   return true;
                }else{
                    C::t('#hl_vip#hl_vip_paylog')->insert($data);
                    return true;
                }
        }
    }
    
    public function get_randChar($length){
        $str = null;
        $strPol = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $max = strlen($strPol)-1;
        for($i=0;$i<$length;$i++){
        $str.=$strPol[rand(0,$max)];
        }
        return $str;
    }
    public function https(){
        if(!isset($_SERVER['HTTPS'])) return false;
            if($_SERVER['HTTPS'] === 1){
                return true;
            }else if($_SERVER['HTTPS'] === 'on'){
                return true;
            }else if($_SERVER['SERVER_PORT'] == 443){
                return true;
            }
        return false;
    }
    public function update_vip_pay($order, $trade_no=null){
        global $_G;
        $viplist = C::t('#hl_vip#hl_vip_list')->get_viplist_first($order['vip_id']);
        $groupid = $order['groupid_new'];
        $groupid_now = getuserbyuid($order['uid']);
        $restrict_group = unserialize($viplist['restrict_group']);
        $vip_discounts = C::t('#hl_vip#hl_vip_paylog')->get_payrecord_log_count(array('uid'=>$order['uid'],'pay_status'=> 1,'vip_id'=> $order['vip_id'],'deal_pyte_no'=> 'buy_credits'));
        if (!in_array($groupid_now['groupid'],$restrict_group) && $viplist['present_open'] && $vip_discounts <= $viplist['restrict_amount']){
            if ($viplist['credits_present']){
                updatemembercount($order['uid'], array('extcredits'.$viplist['credits_present_type'] => $viplist['credits_present']), true, '',1,1,$this->hl_lang['give1'],$this->hl_lang['give2'].$viplist['name'].$this->hl_lang['give3']);
            }
        }else{
            if($vip_discounts){
                $note_xfmsg = $this->hl_lang['xfmsg'].$viplist['name'].$this->hl_lang['xfmsgok'];
            }else{
                $note_xfmsg = $this->hl_lang['gmmsg'].$viplist['name'].$this->hl_lang['xfmsgok'];
            }
            notification_add($order['uid'],'system',$note_xfmsg,$notevars = array(),1);
        }
        $groupdate = $viplist['time'];
        $data = array();
        $data['pay_status'] = 1;
        $data['pay_dateline'] = TIMESTAMP;
        $data['trade_no'] = $trade_no = $trade_no ? $trade_no :'--';
        $isok = C::t('#hl_vip#hl_vip_paylog')->update($data,array('out_trade_no' => $order['out_trade_no']));
        if($isok){
            $extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
            $extgroupids = array_merge($extgroupids, array($groupid_now['groupid']));

            $memberfieldforum = C::t('common_member_field_forum')->fetch($order['uid']);
            $groupterms = dunserialize($memberfieldforum['groupterms']);
            unset($memberfieldforum);
            require_once libfile('function/forum');
            $extgroupidsarray = array();
            foreach(array_unique(array_merge($extgroupids, array($groupid))) as $extgroupid){
                if($extgroupid && $extgroupid != $groupid) {
                    $extgroupidsarray[] = $extgroupid;
                }
            }
            $extgroupidsnew = implode("\t", $extgroupidsarray);

            if($groupdate != '9999') {
                $groupterms['ext'][$groupid] = ($groupterms['ext'][$groupid] > TIMESTAMP ? $groupterms['ext'][$groupid] : TIMESTAMP) + $groupdate*86400;
                $groupexpirynew = groupexpiry($groupterms);
                // $groupterms['main'] = array('time' => $groupterms['ext'][$groupid]);
                $group = C::t('common_usergroup')->fetch($groupid);
                if($_G['adminid'] > 0 && $group['radminid'] > 0) {
                    $newadminid = $_G['adminid'] < $group['radminid'] ? $_G['adminid'] : $group['radminid'];
                } elseif($_G['adminid'] > 0) {
                    $newadminid = $_G['adminid'];
                } else {
                    $newadminid = $group['radminid'];
                }
                C::t('common_member')->update($order['uid'],array('groupid'=>$groupid, 'adminid'=>$newadminid, 'groupexpiry' => $groupexpirynew, 'extgroupids'=>$extgroupidsnew));
                C::t('common_member_field_forum')->update($order['uid'], array('groupterms' => serialize($groupterms)));
            } else {
                C::t('common_member')->update($order['uid'], array('groupid'=>$groupid, 'extgroupids' => $extgroupidsnew));
            }
            
            $orderdata['groupid_overdue'] = $groupterms['ext'][$groupid];
            C::t('#hl_vip#hl_vip_paylog')->update($orderdata,array('out_trade_no' => $order['out_trade_no']));
            return true;
        }else{
            return false;
        }
    }
    
    public function switchgroup($groupid, $uids){
        $groupid = intval($groupid);
        $extgroupids = $extgroupidsarray = array();
        $themembers = C::t('common_member')->fetch($uids);
        $extgroupids = $themembers['extgroupids'] ? explode('	', $themembers['extgroupids']) : array();
        $ret = array();
        $ret['state'] = 1;
        if (!in_array($groupid, $extgroupids)) {
            $ret['msg'] = lang('plugin/keke_group', 'lang05');
            $ret['state'] = 0;
            return $ret;
        }
        if ($themembers['groupid'] == 4 && $themembers['groupexpiry'] > 0 && $themembers['groupexpiry'] > TIMESTAMP) {
            $ret['msg'] = lang('plugin/keke_group', 'lang06');
            $ret['state'] = 0;
            return $ret;
        }
        $group = C::t('common_usergroup')->fetch($groupid);
        $memberfieldforum = C::t('common_member_field_forum')->fetch($uids);
        $groupterms = dunserialize($memberfieldforum['groupterms']);
        unset($memberfieldforum);
        $extgroupidsnew = $themembers['groupid'];
        $groupexpirynew = $groupterms['ext'][$groupid];
        foreach ($extgroupids as $extgroupid) {
            if ($extgroupid && $extgroupid != $groupid) {
                $extgroupidsnew .= '	' . $extgroupid;
            }
        }
        if ($themembers['adminid'] > 0 && $group['radminid'] > 0) {
            $newadminid = !($themembers['adminid'] >= $group['radminid']) ? $themembers['adminid'] : $group['radminid'];
        } else {
            if ($themembers['adminid'] > 0) {
                $newadminid = $themembers['adminid'];
            } else {
                $newadminid = $group['radminid'];
            }
        }
        C::t('common_member')->update($uids, array('groupid' => $groupid, 'adminid' => $newadminid, 'groupexpiry' => $groupexpirynew, 'extgroupids' => $extgroupidsnew));
        return $ret;
    }
    public function get_vipname($vip_id){
        $viplist = C::t('#hl_vip#hl_vip_list')->get_viplist_first($vip_id);
        return $viplist['name'];
    }
    public function arrjson_iconv($arr_json){
        global $_G;
        if ($_G['charset'] == 'gbk') {
            foreach($arr_json as $k => $v){
              $ret[$k] = diconv($v,'gbk', 'utf-8');
            }
            echo json_encode($ret);exit;
        }else{
            echo json_encode($arr_json);exit;
        }
    }
    
    public function get_uscredits($uid) {
        return DB::fetch_first('SELECT extcredits1,extcredits2,extcredits3,extcredits4,extcredits5,extcredits6,extcredits7,extcredits8 FROM '.DB::table('common_member_count').' WHERE uid='.$uid);
    }
    
    public function get_type($type){
        if ($type =='credits_pay'){
            $type = $this->hl_lang['type1'];
        }else if($type =='alipay_pc'){
            $type = $this->hl_lang['type2'];
        }else if($type =='alipay_web'){
            $type = $this->hl_lang['type8'];
        }else if($type =='f2fpay'){
            $type = $this->hl_lang['type16'];
        }else if($type =='wx_pc'){
            $type = $this->hl_lang['type3'];
        }else if($type =='wx_h5'){
            $type = $this->hl_lang['type9'];
        }else if($type =='wx_gzh'){
            $type = $this->hl_lang['type10'];
        }else if($type =='buy_credits'){
            $type = $this->hl_lang['type4'];
        }else if($type =='vip_renew'){
            $type = $this->hl_lang['deal_pyte_renew'];
        }else if($type =='buy_vip'){
            $type = $this->hl_lang['deal_pyte_vip'];
        }else{
            $type = $this->hl_lang['type7'];
        }
        return $type;
    }
    
    public function get_select($name, $data, $selected, $initial) {
        $select = "<select name='$name' id='$name'>";
        if ($initial) {
            $select.= "<option value='".$initial[0]."'>".$initial[1]."</option>";
        }
        foreach ($data as $v) {
            $sed = $selected == $v[0] ? 'selected' : '';
            $select.= "<option value='".$v[0]."' $sed>".$v[1]."</option>";
        }
        $select.= "</select>";
        return $select;
    }
    
    /**
     * 数组过滤，过滤非法数据
     * @param  [type]  $array 过滤函数（自定义函数先进行声明）
     * @param  integer $type  [description]
     * @return array_map       对数组的每一项进行过滤
     */
    public function check_array( $array,$type=0 ){
        $types = array(
            '0'=>'addslashes',
            '1'=>'intval',
            '2'=>'strtotime',
            '3'=>'dhtmlspecialchars',
            '4'=>'auto_iconv'
            );
        return array_map($types[$type],$array);
    }
   	/*
     * 输出json提示信息
     */
    public function output($success=0, $msg='',$id=0,$status=0) {
        $data['success'] = $success;
        $data['message'] = $msg;
        $data['id'] = $id;
        $data['status'] = $status;
        echo json_encode($data);
        exit;
    }
    //替换全角逗号
    public function DoReplaceQjDh($text){
        return str_replace('，',',',$text);
    }
}
$HlVip = HlVip::getInstance();