<?php

class WxPay{

	private $AppId;
	private $AppSecret;
	private $AppKey;
	private $Mchid;

	public function __construct($AppId=null,$AppSecret=null,$AppKey=null,$Mchid=null) {
		global $_G;
		loadcache('plugin');
		$this->Config = (array) $_G['cache']['plugin']['hl_vip'];
		if(strpos($_SERVER["HTTP_USER_AGENT"],'Appbyme') > 0){
			$this->Config['wx_appid'] = $this->Config['app_wx_appid'];
			$this->Config['wx_key'] = $this->Config['app_wx_key'];
			$this->Config['wx_mchid'] = $this->Config['app_wx_mchid'];
		}else{
			$this->Config['wx_appid'] = $AppId ? $AppId : $this->Config['wx_appid'];
			$this->Config['wx_secret'] = $AppSecret ? $AppSecret : $this->Config['wx_secret'];
			$this->Config['wx_key'] = $AppKey ? $AppKey : $this->Config['wx_key'];
			$this->Config['wx_mchid'] = $Mchid ? $Mchid : $this->Config['wx_mchid'];
		}
	}
	/**
	 *
	 * 网页授权接口微信服务器返回的数据，返回样例如下
	 * {
	 *  "access_token":"ACCESS_TOKEN",
	 *  "expires_in":7200,
	 *  "refresh_token":"REFRESH_TOKEN",
	 *  "openid":"OPENID",
	 *  "scope":"SCOPE",
	 *  "unionid": "o6_bmasdasdsad6_2sgVt7hMZOPfL"
	 * }
	 * 其中access_token可用于获取共享收货地址
	 * openid是微信支付jsapi支付接口必须的参数
	 * @var array
	 */
	public $data = null;

	/**
	 *
	 * 通过跳转获取用户的openid，跳转流程如下：
	 * 1、设置自己需要调回的url及其其他参数，跳转到微信服务器https://open.weixin.qq.com/connect/oauth2/authorize
	 * 2、微信服务处理完成之后会跳转回用户redirect_uri地址，此时会带上一些参数，如：code
	 *
	 * @return 用户的openid
	 */
	public function GetOpenid(){
		//通过code获得openid
		if (!isset($_GET['code'])){
			//触发微信返回code码
			$baseUrl = urlencode($this->IsHttps().$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].$_SERVER['QUERY_STRING']);
			$url = $this->__CreateOauthUrlForCode($baseUrl);
			Header("Location: $url");
			exit();
		} else {
			//获取code码，以获取openid
		    $code = $_GET['code'];
			$openid = $this->getOpenidFromMp($code);
			return $openid;
		}
	}
	/**
	 *
	 * 通过code从工作平台获取openid机器access_token
	 * @param string $code 微信跳转回来带上的code
	 *
	 * @return openid
	 */
	public function GetOpenidFromMp($code){
		$url = $this->__CreateOauthUrlForOpenid($code);
		//初始化curl
		$ch = curl_init();
		//设置超时
		curl_setopt($ch, CURLOPT_TIMEOUT, $this->curl_timeout);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,FALSE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		//运行curl，结果以jason形式返回
		$res = curl_exec($ch);
		curl_close($ch);
		//取出openid
		$data = json_decode($res,true);
		$this->data = $data;
		$openid = $data['openid'];
		return $openid;
	}

	/**
	 *
	 * 拼接签名字符串
	 * @param array $urlObj
	 *
	 * @return 返回已经拼接好的字符串
	 */
	public function ToUrlParams($urlObj,$MakeSign=false){
		$buff = "";
		foreach ($urlObj as $k => $v)
		{
			if($MakeSign == true){
				if($k != "sign" && $v != "" && !is_array($v)){
					$buff .= $k . "=" . $v . "&";
				}
			}else{
				if($k != "sign"){
					$buff .= $k . "=" . $v . "&";
				}
			}
		}

		$buff = trim($buff, "&");
		return $buff;
	}

	/**
	 *
	 * 构造获取code的url连接
	 * @param string $redirectUrl 微信服务器回跳的url，需要url编码
	 *
	 * @return 返回构造好的url
	 */
	public function __CreateOauthUrlForCode($redirectUrl){
		if(strpos($this->Config['WxOauthDomain'],'oauth2.htm') !== false || strpos($this->Config['WxOauthDomain'],'get-weixin-code.html') !== false){
			$Url = $this->Config['WxOauthDomain'].'?appid='.$this->Config['wx_appid'].'&scope=snsapi_userinfo&state='.md5(FORMHASH).'&redirect_uri='.$redirectUrl;
		}else{
			$urlObj["appid"] = $this->Config['wx_appid'];
			$urlObj["redirect_uri"] = "$redirectUrl";
			$urlObj["response_type"] = "code";
			$urlObj["scope"] = "snsapi_base";
			$urlObj["state"] = "STATE"."#wechat_redirect";
			$bizString = $this->ToUrlParams($urlObj);
			$Url = "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
		}
		return $Url;
	}

	/**
	 *
	 * 构造获取open和access_toke的url地址
	 * @param string $code，微信跳转带回的code
	 *
	 * @return 请求的url
	 */
	public function __CreateOauthUrlForOpenid($code){
		$urlObj["appid"] = $this->Config['wx_appid'];
		$urlObj["secret"] = $this->Config['wx_secret'];
		$urlObj["code"] = $code;
		$urlObj["grant_type"] = "authorization_code";
		$bizString = $this->ToUrlParams($urlObj);
		return "https://api.weixin.qq.com/sns/oauth2/access_token?".$bizString;
	}

	/**
	 *
	 * 产生随机字符串，不长于32位
	 * @param int $length
	 * @return 产生的随机字符串
	 */
	public static function getNonceStr($length = 32) {
		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";
		$str ="";
		for ( $i = 0; $i < $length; $i++ )  {
			$str .= substr($chars, mt_rand(0, strlen($chars)-1), 1);
		}
		return $str;
	}

	/**
	 * 生成签名
	 * @return 签名，本函数不覆盖sign成员变量，如要设置签名需要调用SetSign方法赋值
	 */
	public function MakeSign($Obj){
		foreach($Obj as $key => $value){
			$Parameters[$key] = $value;
		}
		//签名步骤一：按字典序排序参数
		ksort($Parameters);
		$string = $this->ToUrlParams($Parameters,true);
		//签名步骤二：在string后加入KEY
		$string = $string . "&key=".$this->Config['wx_key'];
		//签名步骤三：MD5加密
		$string = md5($string);
		//签名步骤四：所有字符转为大写
		$result = strtoupper($string);
		return $result;
	}
	/**
	 * 输出xml字符
	 * @throws WxPayException
	**/
	public function ToXml($Array){
    	$xml = "<xml>";
		foreach ($Array as $key=>$val){
    		if (is_numeric($val)){
    			$xml.="<".$key.">".$val."</".$key.">";
    		}else{
    			$xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
    		}
        }
		$xml.="</xml>";
		return $xml;
	}

	/**
	 * 以post方式提交xml到对应的接口url
	 *
	 * @param string $xml  需要post的xml数据
	 * @param string $url  url
	 * @param bool $useCert 是否需要证书，默认不需要
	 * @param int $second   url执行超时时间，默认30s
	 */
	public function postXmlCurl($xml, $url, $second = 30){
		$ch = curl_init();
		//设置超时
		curl_setopt($ch, CURLOPT_TIMEOUT, $second);
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);//严格校验
		//设置header
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		//要求结果为字符串且输出到屏幕上
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		//post提交方式
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
		//运行curl
		$data = curl_exec($ch);
		//返回结果
		if($data){
			curl_close($ch);
			return $data;
		} else {
			$error = curl_errno($ch);
			curl_close($ch);
			exit("Curl error, error code:$error");
		}
	}

	/**
     * 将xml转为array
     * @param string $xml
     */
	public function FromXml($xml){
        $FromXmlData = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
		return $FromXmlData;
	}

	/**
	 *
	 * 获取jsapi支付的参数
	 * @param array $UnifiedOrderResult 统一支付接口返回的数据
	 * @return Array数组，可直接填入js函数作为参数
	 */
	public function GetJsApiParameters($UnifiedOrderResult,$Type=null){
        $FromXml = $this->FromXml($this->postXmlCurl($this->ToXml($UnifiedOrderResult),"https://api.mch.weixin.qq.com/pay/unifiedorder"));
		if(!array_key_exists("appid", $FromXml)
		|| !array_key_exists("prepay_id", $FromXml)
		|| $FromXml['prepay_id'] == ""){
			print_r($FromXml);
			exit("Parameter error");
		}
		$timeStamp = time();
		$Parameters = array();
		if(in_array($Type,array('appbyme_wx'))){
			$Parameters['appid'] = $this->Config['wx_appid'];
			$Parameters['partnerid'] = $this->Config['wx_mchid'];
			$Parameters['prepayid'] = $FromXml['prepay_id'];
			$Parameters['noncestr'] = $this->getNonceStr();
			$Parameters['timestamp'] = $timeStamp;
			$Parameters['package'] = "Sign=WxPay";
			$Parameters['sign'] = $this->MakeSign($Parameters);
		}else{
			$Parameters['appId'] = $this->Config['wx_appid'];
			$Parameters['timeStamp'] = $timeStamp;
			$Parameters['nonceStr'] = $this->getNonceStr();
			$Parameters['package'] = "prepay_id=".$FromXml['prepay_id'];
			$Parameters['signType'] = "MD5";
			$Parameters["paySign"] = $this->MakeSign($Parameters);
		}
		return $Parameters;
	}
	/**
	 * @param string $out_trade_no  生成订单号
	 * @param string $body  内容
	 * @param int $total_fee  //总金额单位是分，不可以是小数
	 * @param string $trade_type  类型
	*/
	public function GetUnifiedOrderParameters($out_trade_no,$body,$total_fee,$trade_type,$openid=null){
		global $_G; 
		$Parameters = array();
		$Parameters["out_trade_no"] = $out_trade_no; //生成订单号
        $Parameters["body"] = cutstr($body,32,''); //商品描述
        $Parameters["total_fee"] = intval($total_fee * 100);   //总金额单位是分，不可以是小数
        $Parameters["notify_url"] = $_G['siteurl'].'source/plugin/hl_vip/wx_notify.php';  //异步回调地址
        $Parameters["trade_type"] = $trade_type;
        $Parameters["openid"] = $openid;
        $Parameters["appid"] = $this->Config['wx_appid'];
        $Parameters["mch_id"] =  $this->Config['wx_mchid']; //商户号
        $Parameters["spbill_create_ip"] = $_G['clientip'];  //客户端的IP地址
        $Parameters["nonce_str"] =  $this->getNonceStr();  //随机字符串
        $Parameters["sign"] =  $this->MakeSign($Parameters);
		return $Parameters;
	}

	//检测是否https
	public function IsHttps(){
		$Http = ((isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') || (isset($_SERVER['HTTP_X_CLIENT_SCHEME']) && $_SERVER['HTTP_X_CLIENT_SCHEME'] == 'https')) ? 'https://' : 'http://';
		return $Http;
	}
}
//From: Dism_taobao-com
?>