<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);
require '../../../source/class/class_core.php';
$discuz = C::app();
$cachelist = array('plugin', 'diytemplatename');
$discuz->cachelist = $cachelist;
$discuz->init();

require_once dirname(__FILE__) . '/class/hl_vip.class.php';
include_once DISCUZ_ROOT.'./source/plugin/hl_vip/class/alipay_f2fpay.class.php';
//支付宝公钥，账户中心->密钥管理->开放平台密钥，找到添加了支付功能的应用，根据你的加密类型，查看支付宝公钥
$alipayPublicKey = $HlVip->config['f2fpay_public_key'];
$aliPay = new AlipayService($alipayPublicKey);
//验证签名
$result = $aliPay->rsaCheck($_POST,$_POST['sign_type']);
if($result === true){
	$out_trade_no = $_POST['out_trade_no'];//商户订单号
    $trade_no = $_POST['trade_no'];//支付宝交易号
	$trade_status = $_POST['trade_status'];//交易状态
	if ($_POST['trade_status'] == 'TRADE_SUCCESS' || $_POST['trade_status'] == 'TRADE_FINISHED'){
		//判断该笔订单是否在商户网站中已经做过处理
		//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
		//如果有做过处理，不执行商户的业务程序
		$order = C::t('#hl_vip#hl_vip_paylog')->get_payrecord_log_first(array('out_trade_no'=> $out_trade_no));
		
		if ($order['deal_pyte'] == 'buy_credits'){
			$pay_ok = $HlVip->update_credits_pay($order, $trade_no);
		}else{
			$pay_ok = $HlVip->update_vip_pay($order,$trade_no);
		}
		if ($pay_ok){
            echo "success";
        }
		
    }
   
    //处理你的逻辑，例如获取订单号$_POST['out_trade_no']，订单金额$_POST['total_amount']等
    //程序执行完后必须通过 PrintWriter 类打印输出"success"（不包含引号）。如果商户反馈给支付宝的字符不是 success 这7个字符，支付宝服务器会不断重发通知，直到超过 24 小时 22 分钟。一般情况下，25 小时以内完成 8 次通知（通知的间隔频率一般是：4m,10m,10m,1h,2h,6h,15h）；
}
// echo 'success';exit();
