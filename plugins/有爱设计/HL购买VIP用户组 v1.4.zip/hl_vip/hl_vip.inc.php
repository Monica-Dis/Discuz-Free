<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
$hl_lang = lang('plugin/hl_vip');
$hl_vip = $_G['cache']['plugin']['hl_vip'];

if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
$WxBrowser = 1;
}else{
$WxBrowser = 0;
}

require_once dirname(__FILE__) . '/class/hl_vip.class.php';
$STATIC = 'source/plugin/hl_vip/';
$formhash = FORMHASH;
$mod = daddslashes($_GET['mod']) ? daddslashes($_GET['mod'] ): 'index';
$limit = 10;
$pages = intval($_GET['page']);
$pages = max($pages, 1);
$starts = ($pages - 1) * $limit;

$navtitle = $hl_vip['title'];
$metakeywords = $hl_vip['keywords'];
$metadescription = $hl_vip['description'];

if ($_G['uid']){
	$extgroupid = explode("\t", $_G['member']['extgroupids']);
	$extgroupids = array_unique(array_merge($extgroupid, array($_G['groupid'])));
	$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
	$groupterms = dunserialize($memberfieldforum['groupterms']);
	unset($memberfieldforum);
	$group_new = C::t('common_usergroup')->fetch($_G['groupid']);
	$group_new_data = $groupterms['ext'][$group_new['groupid']] ? dgmdate($groupterms['ext'][$group_new['groupid']],'Y-m-d H:i:s') :'';
	$group_new_icon = $group_new['icon'] ? 'data/attachment/common/'.$group_new['icon'] :'';
	$group_list = array();
	foreach($extgroupids as $k => $vf){
		$grouplist = C::t('common_usergroup')->fetch($vf);
		$group_list[$k]['group_new'] = $grouplist['groupid'];
		$group_list[$k]['group_name'] = $grouplist['grouptitle'];
		$group_list[$k]['group_data'] = $groupterms['ext'][$vf] ? dgmdate($groupterms['ext'][$vf],'Y-m-d H:i:s') :'';
		$group_list[$k]['group_icon'] = $grouplist['icon'] ? 'data/attachment/common/'.$grouplist['icon'] :'';
	}
	$groupid_keys = array_keys($groupterms['ext']);
}
if($mod=='index'){
	$PayList = $HlVip->GetPayList();
	$vip_listTmp = C::t('#hl_vip#hl_vip_list')->get_viplist($starts,$limit,$condition);
	$vip_list = array();
    foreach ($vip_listTmp as $key => $value) {
		$vip_list[$key] = $value;    
		$vip_list[$key]['prime'] = ($value['prime'] /1);
		$vip_list[$key]['price'] = ($value['price'] /1);   
		$vip_list[$key]['credits_present_type'] = $_G['setting']['extcredits'][$value['credits_present_type']]['title'];

	}
	if($_G['mobile']){
		include template('hl_vip:index');
	}else{
		include template("diy:index",0,'source/plugin/hl_vip/template');
	}
}else if($mod=='orderlist'){
	if(!$_G['uid'])showmessage('to_login', NULL, array(), array('login' => 1));
	$buy_credits = daddslashes($_GET['buy_credits']);
	if ($buy_credits){
		$condition['uid'] = $_G['uid'];
		$condition['deal_pyte'] = $buy_credits;
	}else{
		$condition['uid'] = $_G['uid'];
		$condition['deal_pyte_no'] = 'buy_credits';
	}
	$count = C::t('#hl_vip#hl_vip_paylog')->get_payrecord_log_count($condition);
	$vip_list = C::t('#hl_vip#hl_vip_paylog')->get_payrecord_log_list($starts,$limit,$condition);
	$log_list = array();
	
	foreach($vip_list as $k => $v){
		$log_list[$k] = $v;
		$log_list[$k]['vip_id'] = $v['vip_id'];
		$log_list[$k]['vip_name'] = $HlVip->get_vipname($v['vip_id']);
		$log_list[$k]['pay_pyte'] = $HlVip->get_type($v['pay_pyte']);
		$log_list[$k]['deal_pyte'] = $HlVip->get_type($v['deal_pyte']);
        $log_list[$k]['groupid_overdue'] = $v['groupid_overdue'] != '0' ? dgmdate($v['groupid_overdue'],'Y-m-d H:i:s') : '--';
        $log_list[$k]['pay_status'] = $v['pay_status'] == 1 ? $hl_lang['pay_isok'] : $hl_lang['pay_isno'];
        $log_list[$k]['dateline'] = dgmdate($v['dateline'],'Y-m-d H:i');
	}

	$multis = multi($count, $limit, $pages, 'plugin.php?id=hl_vip&mod=orderlist');

	if($_G['mobile']){
		include template('hl_vip:order_list');
	}else{
		include template("diy:order_list",0,'source/plugin/hl_vip/template');
	}
}