<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_hl_vip {
	function global_header(){
		global $_G;
		$hl_vip = $_G['cache']['plugin']['hl_vip'];
		if($_G['uid'] && $hl_vip['over'] && $_GET['do']=='expiry'){
			$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
			$groupterms = dunserialize($memberfieldforum['groupterms']);
			unset($memberfieldforum);
			$expgrouparray = $expirylist = $termsarray = array();
		
			if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
				$termsarray = $groupterms['ext'];
			}
			if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
				$termsarray[$_G['groupid']] = $groupterms['main']['time'];
			}
		
			foreach($termsarray as $expgroupid => $expiry) {
				if($expiry <= TIMESTAMP) {
					$expgrouparray[] = $expgroupid;
				}
			}
		
			if($expgrouparray) {
				$extgroupidarray = array();
				$thememberss = C::t('common_member')->fetch($_G['uid']);
				$extgroupidss = $thememberss['extgroupids'] ? explode("\t", $thememberss['extgroupids']) : array();
				foreach($extgroupidss as $extgroupid) {
						if(($extgroupid = intval($extgroupid)) && !in_array($extgroupid, $expgrouparray)) {
								$extgroupidarray[] = $extgroupid;
						}
				}
				
				$groupidnew = $_G['groupid'];
				$adminidnew = $_G['adminid'];
				
				$allusergroup=C::t('common_usergroup')->fetch_all_by_type(array('member','system'),0);
				foreach($allusergroup as $allusergroupval){
					$allgid[]=$allusergroupval['groupid'];
				}
				
				foreach($extgroupidarray as $vals){
				   if(in_array($vals, $allgid)){
					  $membergids=$vals;
				   }
				}
							
				foreach($expgrouparray as $expgroupid) {
					if($expgroupid == $_G['groupid']) {
						if(!empty($groupterms['main']['groupid'])) {
							$groupidnew = $groupterms['main']['groupid'];
							$adminidnew = $groupterms['main']['adminid'];
						} else {
							$groupidnew = $membergids ? $membergids :DB::result_first("SELECT groupid FROM ".DB::table('common_usergroup')." WHERE type='member' AND '".$_G['member']['credits']."'>=creditshigher AND '".$_G['member']['credits']."'<creditslower LIMIT 1");
							if(in_array($_G['adminid'], array(1, 2, 3))) {
									$query = DB::query("SELECT groupid FROM ".DB::table('common_usergroup')." WHERE groupid IN (".dimplode($extgroupidarray).") AND radminid='$_G[adminid]' LIMIT 1");
									$adminidnew = (DB::num_rows($query)) ? $_G['adminid'] : 0;
							} else {
									$adminidnew = 0;
							}
						}
						unset($groupterms['main']);
					}
					unset($groupterms['ext'][$expgroupid]);
				}
				require_once libfile('function/forum');
				$groupexpirynew = groupexpiry($groupterms);
				$extgroupidss[]=$thememberss['groupid'];
				foreach($extgroupidss as $extgroupida){
					if($extgroupida && $extgroupida != $groupidnew) {
						$extgroupidarrays[]=$extgroupida;
					}
				}
				$extgroupidsnew = implode("\t", $extgroupidarrays);
				C::t('common_member')->update($_G['uid'], array('groupid' => $groupidnew, 'adminid' => $adminidnew, 'groupexpiry' => '', 'extgroupids' => $extgroupidsnew));
			}
		
		}
		
	}
}

class mobileplugin_hl_vip extends plugin_hl_vip{
}