<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}

class table_hl_vip_list extends discuz_table{
    public function __construct() {
        $this->_table = 'hl_vip_list';
        $this->_pk = 'id';
        parent::__construct(); //d'.'is'.'m.ta'.'obao.com
    }

    public function get_viplist_count($where = null){
        $sql = "SELECT count(*) as count FROM %t WHERE 1";
        $condition[] = $this->_table;
		if($where['id']){      
            $sql .=" AND id=%d ";
            $condition[] = $where['id'];
        }
        $count = DB::fetch_first($sql,$condition);
        return $count['count'];
    }

	public function get_viplist($start,$size,$where = null){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if($where['id']){      
            $sql .=" AND id=%d ";
            $condition[] = $where['id'];
        }
		$sql .= " ORDER BY display desc LIMIT %d,%d ";
		$condition[] = $start;
		$condition[] = $size;
		return DB::fetch_all($sql,$condition);
	}
	
    public function insert($data){
        return DB::insert($this->_table, $data,true);
    }
	
    public function update($data,$condition){
        return DB::update($this->_table, $data,$condition,true);
    }

    public function delete($condition){
        return DB::delete($this->_table, $condition);
    }

    public function get_viplist_first($id){
        return DB::fetch_first("SELECT * FROM %t WHERE id=%d",array($this->_table,$id));
    }
}
//From: Dism_taobao-com
?>