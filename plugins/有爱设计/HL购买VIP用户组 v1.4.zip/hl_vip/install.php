<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_hl_vip_list` (
	`id` int(10) NOT NULL AUTO_INCREMENT,
	`name` varchar(10) DEFAULT NULL,
	`group` int(10) DEFAULT NULL,
	`time` int(25) DEFAULT NULL,
	`prime` decimal(25,2) DEFAULT NULL,
	`price` decimal(25,2) DEFAULT NULL,
	`present_open` int(10) DEFAULT NULL,
	`credits_present` int(25) DEFAULT NULL,
	`credits_present_type` int(25) DEFAULT NULL,
	`restrict_group` text,
	`restrict_amount` int(10) DEFAULT NULL,
	`discount` int(10) DEFAULT NULL,
	`discount_value` decimal(10,2) DEFAULT NULL,
	`discount_group` text,
	`content` text ,
	`dateline` int(12) DEFAULT NULL,
	`display` int(11) DEFAULT NULL,
	PRIMARY KEY (`id`)
) ENGINE=MyISAM;
CREATE TABLE IF NOT EXISTS `pre_hl_vip_paylog` (
	`log_id` int(50) NOT NULL AUTO_INCREMENT,
	`vip_id` int(10) DEFAULT NULL COMMENT 'vipid',
	`out_trade_no` varchar(50) DEFAULT NULL,
	`pay_pyte` varchar(50) DEFAULT NULL,
	`deal_pyte` varchar(50) DEFAULT NULL,
	`uid` int(10) DEFAULT NULL,
	`groupid_new` int(10) DEFAULT NULL,
	`groupid_overdue` int(15) DEFAULT NULL,
	`credits_type` varchar(60) DEFAULT NULL,
	`credits_present` decimal(25,2) DEFAULT NULL,
	`money` decimal(25,2) DEFAULT NULL,
	`pay_status` int(10) DEFAULT NULL,
	`pay_dateline` int(15) DEFAULT NULL,
	`trade_no` varchar(60) DEFAULT NULL,
	`dateline` int(15) DEFAULT NULL,
	`jump_url` varchar(100) DEFAULT NULL,
	PRIMARY KEY (`log_id`)
) ENGINE=MyISAM;
EOF;
runquery($sql);
$finish =true;
?>