<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once dirname(__FILE__) . '/class/hl_vip.class.php';

if(!function_exists('curl_version')){
	exit('Please open curl extension');
}
$hl_lang = lang('plugin/hl_vip');

if (!$_G['uid']){
	$url = $_G['siteurl'].'member.php?mod=logging&action=login&referer='.urlencode($_G['siteurl'].'plugin.php?id=hl_vip');
	dheader('location: '.$url);exit;
}
$out_trade_no = daddslashes($_GET['out_trade_no']);
$order = C::t('#hl_vip#hl_vip_paylog')->get_payrecord_log_first(array('out_trade_no'=> $out_trade_no));
$viplist = C::t('#hl_vip#hl_vip_list')->get_viplist_first($order['vip_id']);
$get_name = getuserbyuid($_G['uid']);

if ($order['pay_status'] == 1){
	showmessage($hl_lang['pay_oks']);
}
if ($order['deal_pyte'] == 'buy_credits'){
	$subjects = $get_name['username'] .$hl_lang['vip_paylang2'].$order['credits_present'].$_G['setting']['extcredits'][$order['credits_type']]['title'];
}else{
	$subjects = $get_name['username'] .$hl_lang['vip_paylang'].$viplist['name'];
}
unset($viplist);

$subject = cutstr(trim($subjects),20);
if ($_G['charset'] == 'gbk') {  
	$subject = diconv($subject, 'gbk','utf-8');
}

// debug($order['pay_pyte']);
if ($order['pay_pyte'] == 'alipay_pc'){
	$cert = DISCUZ_ROOT.'source'.DIRECTORY_SEPARATOR.'plugin'.DIRECTORY_SEPARATOR.'hl_vip'.DIRECTORY_SEPARATOR.'cacert.pem';
	header("Content-type:text/Html;charset=utf-8");
	include_once DISCUZ_ROOT.'./source/plugin/hl_vip/class/alipay_submit.class.php';
	$alipay_config = array();
	
	$alipay_config["partner"] = trim($HlVip->config['alipay_partner']);
	$alipay_config["seller_email"] = trim($HlVip->config['alipay_id']);
	$alipay_config["key"] = trim($HlVip->config['alipay_key']);
	$alipay_config["sign_type"] = strtoupper('MD5');
	$alipay_config["input_charset"] = 'utf-8';
	$alipay_config["cacert"] = $cert;
	$alipay_config["transport"] = $HlVip->https() ? 'https' : 'http';
	$parameter = array(
		"service" => "create_direct_pay_by_user",
		"partner" => $alipay_config["partner"],
		"seller_email" => $alipay_config["seller_email"],
		"payment_type" => "1",
		"notify_url" => $_G['siteurl'].'source/plugin/hl_vip/notify_url.php',
		"return_url" => $_G['siteurl'].'source/plugin/hl_vip/return_url.php',
		"out_trade_no" => $order['out_trade_no'],
		"subject" => $subject,
		"total_fee" => $order['money'],
		"body" => $subject,
		"show_url" => $_G['siteurl'],
		"anti_phishing_key" => $anti_phishing_key,
		"exter_invoke_ip" => $exter_invoke_ip,
		"_input_charset" => trim(strtolower($alipay_config["input_charset"]))
	);
	$alipaySubmit = new AlipaySubmit($alipay_config);
	$html_text = $alipaySubmit->buildRequestForm($parameter, "get", "pay");
	echo $html_text;
	exit;
}

if($order['pay_pyte'] == 'alipay_web'){
	$cert = DISCUZ_ROOT.'source'.DIRECTORY_SEPARATOR.'plugin'.DIRECTORY_SEPARATOR.'hl_vip'.DIRECTORY_SEPARATOR.'cacert.pem';
	header("Content-type:text/Html;charset=utf-8");
	include_once DISCUZ_ROOT.'./source/plugin/hl_vip/class/alipay_submit.class.php';
	$alipay_config = array();
	$alipay_config['partner'] = trim($HlVip->config['alipay_partner']);
	$alipay_config['seller_id'] = trim($HlVip->config['alipay_id']);
	$alipay_config['key'] =  trim($HlVip->config['alipay_key']);
	$alipay_config['notify_url'] = $_G['siteurl'].'source/plugin/hl_vip/notify_url.php';
	$alipay_config['return_url'] = $_G['siteurl'].'source/plugin/hl_vip/return_url.php';
	$alipay_config['sign_type'] = strtoupper('MD5');
	$alipay_config['input_charset'] = 'utf-8';
	$alipay_config['cacert'] = $cert;
	$alipay_config['transport'] = $HlVip->https() ? 'https' : 'http';
	$alipay_config['payment_type'] = "1";
	$alipay_config['service'] = "alipay.wap.create.direct.pay.by.user";
	$parameter = array(
		"service" => $alipay_config['service'],
		"partner" => $alipay_config['partner'],
		"seller_id" => $alipay_config['seller_id'],
		"payment_type" => $alipay_config['payment_type'],
		"notify_url" => $alipay_config['notify_url'],
		"return_url" => $alipay_config['return_url'],
		"_input_charset" => trim(strtolower($alipay_config["input_charset"])),
		"out_trade_no" => $order['out_trade_no'],
		"subject" => $subject,
		"total_fee" => $order['money'],
		"show_url" => $_G['siteurl'],
		"body" => $subject
	);
	$alipaySubmit = new AlipaySubmit($alipay_config);
	$html_text = $alipaySubmit->buildRequestForm($parameter, "get", "pay");
	echo $html_text;
	exit;
}
if($order['pay_pyte'] == 'f2fpay'){
	include_once DISCUZ_ROOT.'./source/plugin/hl_vip/class/alipay_f2fpay.function.php';
	// require_once("source/plugin/hl_vip/f2fpay.php");
	$appid = $HlVip->config['app_id'];  //https://open.alipay.com 账户中心->密钥管理->开放平台密钥，填写添加了电脑网站支付的应用的APPID
	$notifyUrl = $_G['siteurl'].'source/plugin/hl_vip/notify_url_f2fpay.php';    //付款成功后的异步回调地址
	$outTradeNo = $order['out_trade_no'];     //你自己的商品订单号，不能重复
	$payAmount = $order['money'];          //付款金额，单位:元
	$orderName = $subject;    //订单标题
	$signType = 'RSA2';			//签名算法类型，支持RSA2和RSA，推荐使用RSA2
	$rsaPrivateKey=$HlVip->config['f2fpay_private_key'];
	/*** 配置结束 ***/
	$aliPay = new AlipayService();
	$aliPay->setAppid($appid);
	$aliPay->setNotifyUrl($notifyUrl);
	$aliPay->setRsaPrivateKey($rsaPrivateKey);
	$aliPay->setTotalFee($payAmount);
	$aliPay->setOutTradeNo($outTradeNo);
	$aliPay->setOrderName($orderName);
	$result = $aliPay->doPay();
	$result = $result['alipay_trade_precreate_response'];
	if($result['code'] && $result['code']=='10000'){
		if($_G['mobile']){
			$qrurl = $result['qr_code'];
			// echo $qrurl;
			dheader("location:$qrurl");
		}else{
			//生成二维码
			$qrurl = $result['qr_code'];
			$hash = random(10);
			$qrsize = 5;
			$dir = 'source/plugin/hl_vip/cache/';
			$file = $dir.'hl_vip_'.$hash.'.jpg';
			include_once libfile('class/qrcode','plugin/hl_vip');
			if(!file_exists($file) || !filesize($file)) {
				dmkdir($dir);
				include_once libfile('class/qrcode','plugin/hl_vip');
				QRcode::png($qrurl, $file, QR_ECLEVEL_L, $qrsize);
			}
			$url = base64_encode(file_get_contents($file));
			@unlink($file);
			echo '<img src="data:image/png;base64,'.$url.'" style="width:200px;height:200px;" />';
		}
		
	}else{
		echo $result['msg'].' : '.$result['sub_msg'];
	}

}

if($order['pay_pyte'] == 'wx_pc'){//微信充值
	require_once("source/plugin/hl_vip/class/wx_pay.class.php");
	$WxPay = new WxPay;
	$UnifiedOrderParameters = $WxPay->GetUnifiedOrderParameters($out_trade_no,$subject,$order['money'],'NATIVE');
	$FromXml = $WxPay->FromXml($WxPay->postXmlCurl($WxPay->ToXml($UnifiedOrderParameters),"https://api.mch.weixin.qq.com/pay/unifiedorder"));
	$qrurl = $FromXml['code_url'];
	$hash = random(10);
	$qrsize = 5;
	$dir = 'source/plugin/hl_vip/cache/';
	$file = $dir.'hl_vip_'.$hash.'.jpg';
	if(!file_exists($file) || !filesize($file)) {
		dmkdir($dir);
		include_once libfile('class/qrcode','plugin/hl_vip');
		QRcode::png($qrurl, $file, QR_ECLEVEL_L, $qrsize);
	}
	$url = base64_encode(file_get_contents($file));
	@unlink($file);
	echo '<img src="data:image/png;base64,'.$url.'" style="width:200px;height:200px;" />';
	exit;
}else if($order['pay_pyte'] == 'wx_gzh'){
	require_once("source/plugin/hl_vip/class/wx_pay.class.php");
	$WxPay = new WxPay;
	$openid = $WxPay->GetOpenid();
	$UnifiedOrderParameters = $WxPay->GetUnifiedOrderParameters($out_trade_no,$subject,$order['money'],'JSAPI',$openid);
	$JsApiParameters = $WxPay->GetJsApiParameters($UnifiedOrderParameters);
	include template('hl_vip:wx');
	exit;

}else if($order['pay_pyte'] == 'wx_h5'){//H5微信支付
	require_once("source/plugin/hl_vip/class/wx_pay.class.php");
	$WxPay = new WxPay;
	$UnifiedOrderParameters = $WxPay->GetUnifiedOrderParameters($out_trade_no,$subject,$order['money'],'MWEB');
	$FromXml = $WxPay->FromXml($WxPay->postXmlCurl($WxPay->ToXml($UnifiedOrderParameters),"https://api.mch.weixin.qq.com/pay/unifiedorder"));
	if ($FromXml["return_code"] =='FAIL'){
		echo $FromXml['return_msg'];
	}
	// include template('hl_vip:h5_wx');
	if ($FromXml["return_code"] =='SUCCESS' && $FromXml["result_code"] =='SUCCESS'){
	$mweb_url = $FromXml["mweb_url"];
	dheader("location:$mweb_url&redirect_url=".urlencode($order["jump_url"]));
	}
	exit;
}