
var publicRemPageTool = function(dsize,type){
	this.dsize = dsize;
	this.type = type;
}

publicRemPageTool.prototype =   {
	setbaseFont:function(dsize,type){
		if(type){
			var t = 100, o = dsize,
			e = document.documentElement.clientWidth || window.innerWidth,
			n = Math.max(Math.min(e, 480), 320),
			h = 50;
			320 >= n && (h = n / o * t),
			n > 320 && 362 >= n && (h = n / o * t * 1),
			n > 362 && 375 >= n && (h = n / o * t * 1),	
			n > 375 && (h =n / o * t),
			document.documentElement.style.fontSize = h + "px"
		}else{
			var width = dsize;
			var deviceWidth = document.documentElement.clientWidth;
			deviceWidth = deviceWidth>320?deviceWidth:320;
			if(deviceWidth>width){
				document.documentElement.style.fontSize=width/(width/100)+"px";
			}else{
				document.documentElement.style.fontSize=deviceWidth/(width/100)+"px";
			}
		}
	},
	showProper:function(dsize,type){
		this.setbaseFont(dsize,type);
		var L = this;
		$(window).bind('resize', function (e) {
			setTimeout(function(){
				L.setbaseFont(dsize,type);
			},300)
		});
		L.callbackOnpageshow(dsize,type);
	},
	callbackOnpageshow:function(dsize,type){
		var L = this;
		window.onpageshow = function(event) {
			if (event.persisted || navigator.userAgent.indexOf('iPhone') > -1) {
				setTimeout(function(){
					L.setbaseFont(dsize,type);
					L.setCallbackFactory();
				},200)
			}
		}
	},
	setCallbackFactory:function(){
	}
}
