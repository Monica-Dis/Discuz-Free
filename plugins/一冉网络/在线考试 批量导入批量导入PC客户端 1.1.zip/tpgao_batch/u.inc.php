<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$formhash = $_GET['formhash'];
$paperid = intval($_GET['paperid']);
$mode = intval($_GET['mode']);

if(formhash() == $formhash)
{
	$lang_null = lang('plugin/tpgao_batch','admin_batch_import_select');
	
	$a=array();
	$arr = array('name'=>$lang_null,
	'id'=>0);
	$a[]=$arr;
	
	
	if($mode){

		$query = DB::query("select * from ".DB::table('tpexam_groups')." where paperid = $paperid");
		while($d = DB::fetch($query))
		{
			$arr = array('name'=>$d['subject'],
			'content'=>$d['content'],
			'id'=>$d['id']);
			$a[]=$arr;
		}
	}else{
		$query = DB::query("select * from ".DB::table('tpexam_tiku_yuedulijie')." where belong_paper = $paperid");
		while($d = DB::fetch($query))
		{

			$arr = array('name'=>$d['nickname'],
			'id'=>$d['id']);
			$a[]=$arr;
		}
	}
	
	echo array2json($a);
	
	
}

function array2json($arr) {
    //if(function_exists('json_encode')) return json_encode($arr); //Lastest versions of PHP already has this functionality. 
    $parts = array(); 
    $is_list = false; 

    //Find out if the given array is a numerical array 
    $keys = array_keys($arr); 
    $max_length = count($arr)-1; 
    if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {//See if the first key is 0 and last key is length - 1 
        $is_list = true; 
        for($i=0; $i<count($keys); $i++) { //See if each key correspondes to its position 
            if($i != $keys[$i]) { //A key fails at position check. 
                $is_list = false; //It is an associative array. 
                break; 
            } 
        } 
    } 

    foreach($arr as $key=>$value) { 
        if(is_array($value)) { //Custom handling for arrays 
            if($is_list) $parts[] = array2json($value); /* :RECURSION: */ 
            else $parts[] = '"' . $key . '":' . array2json($value); /* :RECURSION: */ 
        } else { 
            $str = ''; 
            if(!$is_list) $str = '"' . $key . '":'; 

            //Custom handling for multiple data types 
            if(is_numeric($value)) $str .= $value; //Numbers 
            elseif($value === false) $str .= 'false'; //The booleans 
            elseif($value === true) $str .= 'true'; 
            else $str .= '"' . addslashes($value) . '"'; //All other things 
            // :TODO: Is there any more datatype we should be in the lookout for? (Object?) 
			$str = str_replace(array("\r\n","\n"),"\\n", $str);
            $parts[] = $str; 
        } 
    } 
    $json = implode(',',$parts); 
     
    if($is_list) return '[' . $json . ']';//Return numerical JSON 
    return '{ ' . $json . ' }';//Return associative JSON 
}
//From: Dism_taobao-com
?>