<?php
/*
	[DisM!] (C)2001-2099 DisM Inc.
	BY dism.taobao.com  tp
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = '';



$finish = TRUE;

?>