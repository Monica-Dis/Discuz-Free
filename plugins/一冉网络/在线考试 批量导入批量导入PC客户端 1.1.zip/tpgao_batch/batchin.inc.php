<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$paperid = intval($_POST['paperid']);
$score = daddslashes($_POST['score']);
$yuedu = intval($_POST['yuedu']);
$groupid = intval($_POST['groupid']);

$_data  = str_replace('&#160;',' ',$_POST['content']);

if($_G['charset']!='gbk')
	$_data = diconv ( $_data, CHARSET, 'gbk' );


$txtarr = explode("\n", trim($_data));

$nAdd       = 0;
$ExamType   = '';
$LineType   = '';
$insert_eid = 0;

$subject = '';
$item=array();
$parser = '';
$image = '';
$lines=array();

$combine=array('title'=>'','content'=>'','mode'=>0); //�����ģʽ

foreach($txtarr AS $v){
	$line = trim($v);
	$line =preg_replace("/\s|��/","",$line); 
	
	if(empty($line)){

		$insert_eid = 0;
		
		if($combine['mode']){
			$combine['mode']=0;

			$combine['content'] = implode("<br>",$lines);
			
			$$insert_id = DB::insert('tpexam_tiku_yuedulijie', array('ask' =>$combine['content'], 
			'belong_paper'=>$paperid, 
			'nickname'=>$combine['title']
			),1);
			
			$yuedu = $insert_id;
			
			//echo 'yuedu='.$yuedu;
		}
		
		continue;
	}
	
	if($combine['mode']){
		
		if($_G['charset'] != 'gbk'){
			$line = iconv("gbk","utf-8",$line);
		}
		
		$lines[] = $line;
	}
	
	if(preg_match("/^���\s*(?::|��)\s*#(.*)$/", $line, $match))
	{
		if($_G['charset'] != 'gbk'){
			$match[1] = iconv("gbk","utf-8",$match[1]);
		}
		
		$combine['mode'] = 1; //���������ģʽ
		$combine['title'] = $match[1]; //�������

		continue;
	}

	if($insert_eid==0)
	{
		unset($item);
		
		if($_G['charset'] != 'gbk'){
			$line = iconv("gb2312","utf-8",$line);
		}
		$subject  = $line;  //����һ�±���

		$post = array(
			'tid'	 => 0,
			'oid'	 => 0,
			'subject'=> $line,//$_POST['numum'] ? preg_replace("/^[\(��\[]?\s*\d+\s*[\)��\]]?[\.����]\s*/", '' , $line) : $line,
			'addtime'=> $_SERVER['REQUEST_TIME'],
		);
		$insert_eid = DB::insert('tpexam_tiku', $post, true);
		DB::update('tpexam_tiku',array('eid'=>$insert_eid),"id=$insert_eid");
		
		$ExamType  = preg_match("/(_{4,})|(\(\s{4,}\))/", $line, $match) ? 'BLANK' : 'ASK';
		
		while(preg_match("/(_{4,})|(\(\s{4,}\))/", $line, $match)){
			$line = tian($line);
		}
	
		$subject = $line;
		
		$nAdd++;
		$LineType   = 'subject';
	}
	elseif(preg_match("/^��\s*(?::|��)\s*(.*)/", $line, $match))
	{
		$LineType   = 'result';
		$line = $match[1];
		
		if(preg_match("/^(��ȷ|��|��|��)$/", $line, $match))//�ж���
		{
			
			$oid = DB::insert('tpexam_tiku_panduan', array('tid' => 0, 
			'ask'=>$subject, 
			'score'=>$score,
			'belong_paper'=>$paperid,
			'answer_parser'=>$parser,
			'eid'=>$insert_eid,
			'yuedulijie_timutype'=>$yuedu,
			'data'=>TIMESTAMP,
			'answer' => 1,
			'groupid' => $groupid
			),1); 
			
			//$oid = mysql_insert_id();
			
			DB::update('tpexam_tiku', array('tid' => 3,'oid'=>$oid, 'groupid' => $groupid,'paperid'=>$paperid,'result' => 1), "eid='$insert_eid'"); 
			
			$ExamType = "SELECT";
		}
		elseif(preg_match("/^(����|��|��|��)$/", $line, $match))//�ж���
		{
			
			
			$oid = DB::insert('tpexam_tiku_panduan', array('tid' => 0, 
			'ask'=>$subject, 
			'score'=>$score,
			'belong_paper'=>$paperid,
			'answer_parser'=>$parser,
			'eid'=>$insert_eid,
			'data'=>TIMESTAMP,
			'yuedulijie_timutype'=>$yuedu,
			'answer' => 0,
			'groupid' => $groupid),1); 
			
			//$oid = mysql_insert_id();
			DB::update('tpexam_tiku', array('tid' => 3, 'oid'=>$oid,'groupid' => $groupid,'paperid'=>$paperid,'result' => 0,'score'=>$score), "eid='$insert_eid'"); 
			
			$ExamType = "SELECT";
		}
		elseif(preg_match("/^([A-Z])$/", $line, $match))//��ѡ��
		{
					
			$oid = DB::insert('tpexam_tiku_danxuan', array('tid' => 0, 'ask'=>$subject, 
			'option1'=>$item[0],
			'option2'=>$item[1],
			'option3'=>$item[2],
			'option4'=>$item[3],
			'option5'=>$item[4],
			'option6'=>$item[5],
			'option7'=>$item[6],
			'score'=>$score,
			'belong_paper'=>$paperid,
			'answer_parser'=>$parser,
			'yuedulijie_timutype'=>$yuedu,
			'data'=>TIMESTAMP,
			'answer' => $match[1],
			'groupid' => $groupid,
			'eid'=>$insert_eid),1); 
			
			//$oid = mysql_insert_id();
			
			$option = implode("\r\n",$item);
						
			DB::update('tpexam_tiku', array('tid' => 1, 'oid'=>$oid, 'groupid' => $groupid,'paperid'=>$paperid,'option'=>$option, 'result' => $match[1],'score'=>$score), "eid='$insert_eid'"); 
			
			$ExamType = "SINGLE";
		}
		elseif(preg_match("/^([A-Z]{1,26})#?$/", $line, $match))//��ѡ��
		{
			
			unset($answerarr);
			for($i=0;$i<strlen($match[1]);$i++){
				$answerarr[] = $match[1][$i];
			}
			
			$oid = DB::insert('tpexam_tiku_duoxuan', array('tid' => 0, 'ask'=>$subject, 
			'option1'=>$item[0],
			'option2'=>$item[1],
			'option3'=>$item[2],
			'option4'=>$item[3],
			'option5'=>$item[4],
			'option6'=>$item[5],
			'option7'=>$item[6],
			'score'=>$score,
			'belong_paper'=>$paperid,
			'answer_parser'=>$parser,
			'answer1' => $answerarr[0],
			'answer2' => $answerarr[1],
			'answer3' => $answerarr[2],
			'answer4' => $answerarr[3],
			'answer5' => $answerarr[4],
			'answer6' => $answerarr[5],
			'answer7' => $answerarr[6],
			'data'=>TIMESTAMP,
			'yuedulijie_timutype'=>$yuedu,
			'groupid' => $groupid,
			'eid'=>$insert_eid),1);
			
			//$oid = mysql_insert_id();
			
			$option = implode("\r\n",$item);
			
			DB::update('tpexam_tiku', array('tid' => 2,'oid'=>$oid, 'groupid' => $groupid,'paperid'=>$paperid,'option'=>$option, 'result' => $match[1],'score'=>$score), "eid='$insert_eid'"); 
			
			$ExamType = "MULTI";
		}
		elseif($ExamType=='BLANK')
		{
			$answer = preg_replace("/\s+/","\n",$line);
			if($_G['charset'] != 'gbk'){
			$answer = iconv("gb2312","utf-8",$answer);
			}
			
			$oid = DB::insert('tpexam_tiku_tiankong', array('tid' => 0,
			 'ask'=>$subject,
			 'score'=>$score,
			 'belong_paper'=>$paperid,
			 'answer' => $answer, 
			 'answer_parser'=>$parser,
			 'yuedulijie_timutype'=>$yuedu,
			 'data'=>TIMESTAMP,
			 'eid'=>$insert_eid,
			 'groupid' => $groupid),1);
			
			//$oid = mysql_insert_id();
			
			DB::update('tpexam_tiku', array('tid' => 4, 'oid'=>$oid,'groupid' => $groupid,'paperid'=>$paperid,'option' => $answer,'score'=>$score), "eid='$insert_eid'");
			
			$LineType = 'option';
		}
		elseif($ExamType=='ASK')
		{
			$answer = preg_replace("/\s+/","\n",$line);
			
			if($_G['charset'] != 'gbk'){
				$answer = iconv("gb2312","utf-8",$answer);
			}
			
			
			$oid = DB::insert('tpexam_tiku_wenda', array('tid' => 0, 
			'ask'=>$subject,  
			'belong_paper'=>$paperid,
			'score'=>$score,
			'answer'=>$answer,
			'answer_parser' => $parser,
			'yuedulijie_timutype'=>$yuedu,
			'data'=>TIMESTAMP,
			'groupid' => $groupid,
			'eid'=>$insert_eid),1);
			//$oid = mysql_insert_id();
			
			DB::update('tpexam_tiku', array('tid' => 6, 'oid'=>$oid,'groupid' => $groupid,'paperid'=>$paperid,'option' => $line,'score'=>$score), "eid='$insert_eid'");
			
			$LineType = 'data';
		}
		
		$subject = '';
		unset($item);
		$parser = '';
		
	}
	elseif(preg_match("/^ͼƬ\s*(?::|��)\s*(.+)/", $line, $match))
	{
		DB::update('tpexam_tiku', array('image' =>$match[1]), "eid='$insert_eid'"); 
		$image = $match[1];
		$LineType = 'image';
	}
	elseif(preg_match("/^��ֵ\s*(?::|��)\s*(.+)/", $line, $match))
	{
		DB::update('tpexam_tiku', array('score' =>$match[1]), "eid='$insert_eid'"); 
		ProcessScore($ExamType,$match[1],$insert_eid);
		$LineType = 'score';
	}
	elseif(preg_match("/^��������\s*(?::|��)\s*(.+)/", $line, $match))
	{
		DB::update('tpexam_tiku', array('viewParser_credits' =>$match[1]), "eid='$insert_eid'"); 
		ProcessCredit($ExamType,$match[1],$insert_eid);
		$LineType = 'ParserCredit';
	}
	elseif(preg_match("/^����\s*(?::|��)\s*(.+)/", $line, $match))
	{
		
		if($_G['charset'] != 'gbk'){
			$match[1] = iconv("gb2312","utf-8",$match[1]);
		}

		DB::update('tpexam_tiku', array('parser' =>$match[1]), "eid='$insert_eid'"); 
		

		ProcessParser($ExamType,$match[1],$insert_eid);
		ProcessImage($ExamType,$image,$insert_eid);
		
		$parser = $match[1]; //����һ�½���
		
		$LineType = 'parser';
	}
	elseif($LineType == 'subject' && preg_match("/^[A-Z]\s*(?:\.|��|��|:|��)\s*(.*)$/", $line, $match))//ѡ�����ѡ��
	{
		if($_G['charset'] != 'gbk'){
			$match[1] = iconv("gb2312","utf-8",$match[1]);
		}
		
		$item[]=$match[1];

	}
	elseif($LineType == 'option' || $LineType == 'parser' || $LineType == 'subject')
	{
		
		if($_G['charset'] != 'gbk'){
			$line = iconv("gb2312","utf-8",$line);
		}
		
		$note[]=$line;
		
	}


}


function ProcessParser($examtype,$parser,$eid){
	 
	if(trim($examtype) == "SINGLE"){
		DB::update('tpexam_tiku_danxuan', array('answer_parser'  =>$parser), "eid='$eid'"); 
	}elseif(trim($examtype) == "MULTI"){
		DB::update('tpexam_tiku_duoxuan', array('answer_parser'  =>$parser), "eid='$eid'"); 
	}elseif(trim($examtype) == "SELECT"){
		DB::update('tpexam_tiku_panduan', array('answer_parser'  =>$parser), "eid='$eid'"); 
	}elseif(trim($examtype) == "BLANK"){
		DB::update('tpexam_tiku_tiankong', array('answer_parser'  =>$parser), "eid='$eid'"); 
	}elseif(trim($examtype) == "ASK"){
		DB::update('tpexam_tiku_wenda', array('answer_parser'  =>$parser), "eid='$eid'"); 
	}
	
}

function ProcessImage($examtype,$image,$eid){
	
	if(trim($examtype) == "SINGLE"){
		DB::update('tpexam_tiku_danxuan', array('image'  =>$image), "eid='$eid'"); 
	}elseif(trim($examtype) == "MULTI"){
		DB::update('tpexam_tiku_duoxuan', array('image'  =>$image), "eid='$eid'"); 
	}elseif(trim($examtype) == "SELECT"){
		DB::update('tpexam_tiku_panduan', array('image'  =>$image), "eid='$eid'"); 
	}elseif(trim($examtype) == "BLANK"){
		DB::update('tpexam_tiku_tiankong', array('image'  =>$image), "eid='$eid'"); 
	}elseif(trim($examtype) == "ASK"){
		DB::update('tpexam_tiku_wenda', array('image'  =>$image), "eid='$eid'"); 
	}
}

function ProcessScore($examtype,$score,$eid){
	 
	if(trim($examtype) == "SINGLE"){
		DB::update('tpexam_tiku_danxuan', array('score'  =>$score), "eid='$eid'"); 
	}elseif(trim($examtype) == "MULTI"){
		DB::update('tpexam_tiku_duoxuan', array('score'  =>$score), "eid='$eid'"); 
	}elseif(trim($examtype) == "SELECT"){
		DB::update('tpexam_tiku_panduan', array('score'  =>$score), "eid='$eid'"); 
	}elseif(trim($examtype) == "BLANK"){
		DB::update('tpexam_tiku_tiankong', array('score'  =>$score), "eid='$eid'"); 
	}elseif(trim($examtype) == "ASK"){
		DB::update('tpexam_tiku_wenda', array('score'  =>$score), "eid='$eid'"); 
	}
	
	DB::update('tpexam_tiku', array('score'  =>$score), "eid='$eid'"); 
			
}

function ProcessCredit($examtype,$credit,$eid)
{
	if(trim($examtype) == "SINGLE"){
		DB::update('tpexam_tiku_danxuan', array('viewParser_credits'  =>$credit), "eid='$eid'"); 
	}elseif(trim($examtype) == "MULTI"){
		DB::update('tpexam_tiku_duoxuan', array('viewParser_credits'  =>$credit), "eid='$eid'"); 
	}elseif(trim($examtype) == "SELECT"){
		DB::update('tpexam_tiku_panduan', array('viewParser_credits'  =>$credit), "eid='$eid'"); 
	}elseif(trim($examtype) == "BLANK"){
		DB::update('tpexam_tiku_tiankong', array('viewParser_credits'  =>$credit), "eid='$eid'"); 
	}elseif(trim($examtype) == "ASK"){
		DB::update('tpexam_tiku_wenda', array('viewParser_credits'  =>$credit), "eid='$eid'"); 
	}
}

	function tian($s){
		$len =  _getLength($s,strpos($s,"_"));

		$s = preg_replace("/(_{4,})|(\(\s{4,}\))/","#".$len,$s,1);
		
		return $s;
	}

	function _getLength($s,$pos)
	{
		$l = 0;
		while($s[$pos+$l] == "_")
		{
			$l ++;
		}
		return $l;
	}
	
$in_submit_ok = 1;

$admin_submit_data = lang('plugin/tpgao_batch','admin_submit_data');

showmessage($admin_submit_data, 'plugin.php?id=tpgao_batch:batch&step=one');

?>