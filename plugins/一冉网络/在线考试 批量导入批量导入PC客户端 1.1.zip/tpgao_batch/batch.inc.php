<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-10-20
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

	$config = array();
	$config = $_G['cache']['plugin']['tpgao_batch'];
	$template = $config['template'];
	$usepapergroups = $config['usepapergroups'];

	$is_store = false;
	$store_group = $_G['cache']['plugin']['tpgao_batch']['frontgroup'];

	$store = unserialize($store_group);

	foreach($store as $k=>$val)
	{
		if($val == $_G['group']['groupid']){
			$is_store = true;
			break;
		}	
	}

	if(!$is_store && $_G['adminid']!=1){
		showmessage(lang('plugin/tpgao_batch','frontgroup_nopermisstion'));
	}
	
	$firstpaperid = 0;
	$paperlist=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." order by id desc");
	while($data = DB::fetch($query)){
		$paperlist[]= $data;
	}

	$firstpaperid = $paperlist[0]['id'];
	

	//本试卷复合题
	$fuhelist=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_yuedulijie')." where belong_paper = $firstpaperid order by id asc");
	while($data = DB::fetch($query)){
		$fuhelist[]= $data;	
	}


	//本试卷题组
	$papergroups=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_groups')." where paperid = $firstpaperid order by id asc");
	while($data = DB::fetch($query)){
		$papergroups[]= $data;	
	}
	
	$admin_submit =  lang('plugin/tpgao_batch','admin_submit');


	
	include template('tpgao_batch:one');


?>