<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


	$exam = GetExamByPaperID($item);
	$needlogin = GetNeedLogin($item);
	$needPractise = GetNeedPractise($item);
	$needpay = GetNeedPay($item);
	$paper_no_pause = DB::result_first("SELECT paper_no_pause FROM ".DB::table('tpexam_paper')." where id='$item'");

	//�ж��Ƿ��շ�
	if($needpay)
	{
		//header("Location: plugin.php?id=tpgao_m:pay&needpay=$item");
		$mexam_login_tips = lang('plugin/tpgao_m','mexam_login_tips');
		echo $mexam_login_tips;
		exit;
	}
	
	//�жϹ������
	session_start();
	$needcredit = GetNeedCredits($item);
	$buyed = GetUserBuyedPaper($_G['uid'],$item);

	if($needcredit[0] && $_SESSION['credits_buyed_'.$item]!=1 ){
		if(!$buyed){
				header("Location: plugin.php?id=tpgao_m:buycred&needpay=$item");
				exit;
		}elseif($buyed){
			
			if($needcredit[2] == 1){
				header("Location: plugin.php?id=tpgao_m:buycred&needpay=$item");
				exit;
			}
		}
	}
	$_SESSION['credits_buyed_'.$item]=0;
	
	
//	�ж��Ƿ���Ҫ��֤����ʱ��
	$ret = CheckOnlinetime($_G['uid'],$item);
	if(!$ret['oltime'])
	{
		showmessage($ret['moduletips']);
	}
	
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/paperctrl.inc.php";

			
	$question_config = $_G['cache']['plugin']['tpgao_questionsyn'];
	$questionsyn = $question_config['start'];
	
	
	if(!canExamPaper($item))
	{
		$config = array();
		$config = $_G['cache']['plugin']['tp_exam'];
		$tips = $config['exam_paper_denid_tips'];

		$tip_arr = explode("|",$tips);
		
		require_once libfile ( 'function/discuzcode' );
		$tips = discuzcode ( $tip_arr[0], 0, 0, 0, 1, 1, 1, 0, 0, 0, 0 ); 
		if(strlen($tip_arr[1])>0)
		showmessage($tips,$tip_arr[1]);
		else
		showmessage($tips,'plugin.php?id=tpgao_m:m');
	}
	
	$uid = $_G['uid'];
	$cookie = "tpexam_login_".$item."_".$uid;
	$logined = $_COOKIE[$cookie];

	$showanswer = GetPaperShowAnswer($item);
	$PaperInfo = GetPaperInfo($item);
	$paper_item_timu_desc_arr = GetPaperItemTimuDesc($item);
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='nocopy'");
	$nocopy = $skey['nocopy'];

	$examtime = $exam['papertime'];	
	
	if(!$open_weixin){
		if($needlogin && $logined != 'true')
		{
			//setcookie($cookie,'false');
			//header("Location: plugin.php?id=tp_exam:index&mod=login&item=$item");
			if($open_weixin){
				
			}else{
				$mexam_login_tips = lang('plugin/tpgao_m','mexam_login_tips');
				
				showmessage($mexam_login_tips);
				exit;
			}
		}
		else
		{
			setcookie($cookie,'false', time()+3600);
		}
	}


?>