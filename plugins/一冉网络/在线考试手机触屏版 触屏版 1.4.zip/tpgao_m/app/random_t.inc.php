<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


		$total_number = $randmod;
		$maxitem=array();
		$max=array();
		$maxitem[0] = GetDanxuanCount($item);
		$maxitem[1] = GetDuoxuanCount($item);
		$maxitem[2] = GetPanduanCount($item);
		$maxitem[3] = GetTiankongCount($item);
		$maxitem[4] = GetWendaCount($item);
	
		$min=array(0,0,0,0,0);
		$randomnumber = 5;
		
		$needrandom=array();
		$skey = DB::result_first("SELECT random_item FROM ".DB::table('tpexam_paper')." where id='$item'");
		$random_arr = explode(",",$skey);
		
		if($random_arr[0] == -1 &&
		$random_arr[1] == -1 &&
		$random_arr[2] == -1 &&
		$random_arr[3] == -1 &&
		$random_arr[4] == -1 ){
			
			$tiku_num = GetRandomByTotal($min,$maxitem,$randmod,5);

		}else{
			foreach($random_arr as $k=>$v){
				if($v==-1)
					$tiku_num[$k] = 0;
				else
					$tiku_num[$k] = $v;
			}
		}


	if(empty($tiku_num[0])) {
			$tiku_num[0] = 0;
		}
		$danxuan = GetDaXuanByRand($item,$tiku_num[0]);
		if(empty($tiku_num[1])) {
			$tiku_num[1] = 0;
		}
		$duoxuan = GetDuoXuanByRand($item,$tiku_num[1]);
		if(empty($tiku_num[2])) {
			$tiku_num[2] = 0;
		}
		$panduan = GetPanduanByRand($item,$tiku_num[2]);
		if(empty($tiku_num[3])) {
			$tiku_num[3] = 0;
		}
		$tiankong = GetTiankongByRand($item,$tiku_num[3]);
		$tiankong_ask = GetTiankongAsk($tiankong);

		if(empty($tiku_num[4])) {
			$tiku_num[4] = 0;
		}
		$wenda = GetWendaByRand($item,$tiku_num[4]);


?>