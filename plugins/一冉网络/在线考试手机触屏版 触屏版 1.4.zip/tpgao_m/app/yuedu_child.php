<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


				$q1 = GetYueduQuesion1($v['id']);
				$index++;
				foreach($q1 as $n=>$value){
					$type = 1;
					$id = $index;
					$oid = $value['id'];
					$eid = $value['eid'];
					$score = $value['score'];
					$subject = $v['ask'].'<br>'.$value['ask'];
					$image = $value['image'];
					$parserimage = $value['parser_img_path'];
					
					$data = $value['option1']."\r\n".$value['option2']."\r\n".$value['option3']."\r\n".$value['option4'];
					if($value['option5']!='') $data .= "\r\n".$value['option5'];
					if($value['option6']!='') $data .= "\r\n".$value['option6'];
					if($value['option7']!='') $data .= "\r\n".$value['option7'];
					$arr = array('type'=>1,'id'=>$id,'eid'=>$eid,'oid'=>$oid,'image'=>$image,'parserimage'=>$parserimage,'subject'=>$subject,'score'=>$score,'data'=>$data);
					$groups[]=$arr;
					$index++;
				}
				
				$q2 = GetYueduQuesion2($v['id']);
				$index++;
				foreach($q2 as $n=>$value){
					$type = 2;
					$id = $index;
					$eid = $value['eid'];
					$score = $value['score'];
					$subject = $v['ask'].'<br>'.$value['ask'];
					$oid = $value['id'];
					$image = $value['image'];
					$parserimage = $value['parser_img_path'];
					
					$data = $value['option1']."\r\n".$value['option2']."\r\n".$value['option3']."\r\n".$value['option4'];
					if($value['option5']!='') $data .= "\r\n".$value['option5'];
					if($value['option6']!='') $data .= "\r\n".$value['option6'];
					if($value['option7']!='') $data .= "\r\n".$value['option7'];
					
					$arr = array('type'=>$type,'id'=>$id,'eid'=>$eid,'oid'=>$oid,'image'=>$image,'parserimage'=>$parserimage,'subject'=>$subject,'score'=>$score,'data'=>$data);
					$groups[]=$arr;
					$index++;
				}
				$q3 = GetYueduQuesion3($v['id']);
				$index++;
				foreach($q3 as $n=>$value){
					$type = 3;
					$id = $index;
					$eid = $value['eid'];
					$score = $value['score'];
					$subject = $v['ask'].'<br>'.$value['ask'];
					$data = '';
					$oid = $value['id'];
					$image = $value['image'];
					$parserimage = $v['parser_img_path'];
			 	
					$arr = array('type'=>$type,'id'=>$id,'eid'=>$eid,'oid'=>$oid,'image'=>$image,'parserimage'=>$parserimage,'subject'=>$subject,'score'=>$score,'data'=>$data);
					$groups[]=$arr;
					$index++;
				}
				
				$q4 = GetYueduQuesion4($v['id']);
				$index++;
				foreach($q4 as $n=>$value){
					$type = 4;
					$id = $index;
					$eid = $v['eid'];
					$score = $v['score'];
					$subject = $v['ask'].'<br>'.$value['ask'];
					$data = '';
					$oid = $v['id'];
					$image = $v['image'];
					$parserimage = $v['parser_img_path'];
			 	
					$arr = array('type'=>$type,'id'=>$id,'eid'=>$eid,'oid'=>$oid,'image'=>$image,'parserimage'=>$parserimage,'subject'=>$subject,'score'=>$score,'data'=>$data);
					$groups[]=$arr;
					$index++;
				}
				
				$q5 = GetYueduQuesion5($v['id']);
				$index++;
				foreach($q5 as $n=>$value){
					$type = 5;
					$id = $index;
					$eid = $value['eid'];
					$score = $value['score'];
					$subject = $v['ask'].'<br>'.$value['ask'];
					$data = '';
					$oid = $value['id'];
					$image = $value['image'];
					$parserimage = $value['parser_img_path'];
			  	
					$arr = array('type'=>$type,'id'=>$id,'eid'=>$eid,'oid'=>$oid,'image'=>$image,'parserimage'=>$parserimage,'subject'=>$subject,'score'=>$score,'data'=>$data);
					$groups[]=$arr;
					$index++;
				}
				

?>