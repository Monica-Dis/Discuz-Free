<?php
/*
	[dxtm.net!] (C)2001-2013 Inc.
	BY QQ:155121944  tp
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = '';



$pluginid = 'tpgao_m';

require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::delAPIHook($pluginid);


$finish = TRUE;

?>