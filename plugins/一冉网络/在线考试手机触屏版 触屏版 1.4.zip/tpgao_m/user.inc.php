<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam_paper_func.php";

	$v = daddslashes($_POST['ser']);
	$paperid = intval($_POST['paperid']);
	$recordid = intval($_POST['recordid']);
	
	$formhash = $_POST['formhash'];
	
	if(formhash() == $formhash){
		
	$danxuan_a=array();
	$duoxuan_a=array();
	$panduan_a=array();
	$tiankong_a=array();
	$wenda_a=array();
	
	foreach($v as $k=>$value){
		
		switch($value['type']){
			case 1:
				$tmp[] = -1;
				$tmp[] = $value['answer'];
				$danxuan_a[]=$tmp;
				$tm;
			break;
			case 2:
				$tmp[] = -1;
				$tmp[] = $value['answer'];
				$duoxuan_a[]=$tmp;;
			break;
			case 3:
				$tmp[] = -1;
				$tmp[] = $value['answer'];
				$panduan_a[]=$tmp;
			break;
			case 4:
				$tmp[] = -1;
				$tmp[] = $value['answer'];
				$tiankong_a[]=$tmp;
			break;
			case 5:{
				$tmp['answer'] = $value['answer'];
				$tmp['answerimage'] = $value['answerimage'];
				$wenda_a[]= $tmp;
			}
			break;
		}
		
	}
	
		saveuseranswer($danxuan_a,$duoxuan_a,$panduan_a,$tiankong_a,$wenda_a,$wenda_user_image,$recordid);
	
	}

	//echo json_encode($v);
	
?>