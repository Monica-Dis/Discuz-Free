<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}

$ismobile = checkmobile();
if (!$ismobile) {
	$item = intval($_GET['item']);
	$mod = $_GET['mod'];
	if($mod == 'exam'){
		dheader('location: plugin.php?id=tp_exam:index&mod=exam&item='.$item);
 		exit;	
	}
 	
}

function GetNextType($mtype)
{
	$next=array();
	$sql = DB::query("SELECT * FROM ".DB::table('tpexam_type')." where parent = '$mtype' order by sort asc");
	while($info = DB::fetch($sql))
	{
		$next[]=$info;
	}
	return $next;
	
}


function GteParentType($mtype)
{
	$parent=array();
	$sql = DB::query("SELECT * FROM ".DB::table('tpexam_type')." where id = '$mtype' order by sort asc");
	while($info = DB::fetch($sql))
	{
		$parent=$info;
	}
	return $parent;	
}

function GetChildTypeIdArray($typeid){
	
	$idarr=array();
	
	//����1��
	$query = DB::query("SELECT * FROM ".DB::table("tpexam_type")." where parent = '$typeid'");
	while($data = DB::fetch($query))
	{
		$idarr[]=$data['id'];
	}

	if(count($idarr)>0){
		$idlist = implode(",",$idarr);

		//����2��
		$query = DB::query("SELECT * FROM ".DB::table("tpexam_type")." where parent  IN ($idlist) ");
		while($data = DB::fetch($query))
		{
			$idarr[]=$data['id'];
		}
	}
	
	$idarr[]=$typeid;
	
	return $idarr;
}

function GetPaperList($mtype = 0){
	$paper = array();
	
	$where = '';
	
	if($mtype == 0){
		$where = ' where belong = 0';
	}else{

		$ChildId = GetChildTypeIdArray($mtype);
		$ChildId = array_filter($ChildId); 
		$list = implode(",", $ChildId);
		$where = " where belong IN($list)  order by sort asc";
	}
	
		$sql = DB::query("SELECT * FROM ".DB::table('tpexam_paper') . $where );
		while($info = DB::fetch($sql))
		{
			$paper[]=$info;
		}
	
	
	return $paper;
}


function GetTidByEid($eid){
	$sql = DB::query("SELECT * FROM ".DB::table('tpexam_tiku')." where eid = $eid");
	while($info = DB::fetch($sql))
	{
		return $info;
	}
}


function SaveUserExam($uid,$paperid,$usetime,$score)
{
		DB::insert('tpexam_examrecord', array(
				'uid'=>$uid,
				'exam_type' => $paperid,
				'usetime' => $usetime,
				'date' => TIMESTAMP,
				'score'=> $score
		));
}


function GetUniqueCode ($openid){
	$query = DB::query("select * from ".DB::table('tpexam_verify_data')." where uniquecode = '$openid'");
	if($d = DB::fetch($query)){
		return $d['uniquecode'];
	}
	
	return 0;
}


function GetYueduQuesion1($yid)
{
	$tiku=array();

	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where  yuedulijie_timutype = $yid ");
	//tpexam_tiku_danxuan
	
	while($data = DB::fetch($query))
	{
		$data['ask']=str_replace("\'","'",$data['ask']);//����
		$data['option1']=str_replace("\'","'",$data['option1']);//����
		$data['option2']=str_replace("\'","'",$data['option2']);//����
		$data['option3']=str_replace("\'","'",$data['option3']);//����
		$data['option4']=str_replace("\'","'",$data['option4']);//����
		$data['option5']=str_replace("\'","'",$data['option5']);//����
		$data['option6']=str_replace("\'","'",$data['option6']);//����
		$data['option7']=str_replace("\'","'",$data['option7']);//����
		
		require_once libfile ( 'function/discuzcode' );
		$data['option1']  = discuzcode ( $data['option1'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option2']  = discuzcode ( $data['option2'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option3']  = discuzcode ( $data['option3'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option4']  = discuzcode ( $data['option4'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option5']  = discuzcode ( $data['option5'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option6']  = discuzcode ( $data['option6'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option7']  = discuzcode ( $data['option7'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);

		
		$data['image']=trim($data['image']);//����
		 $tiku[] = $data;
	}
	
	return $tiku;
}

function GetYueduQuesion2($yid)
{
	$tiku=array();

	$where = "where  yuedulijie_timutype = $yid ";

	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." $where order by id asc" );

	while($data = DB::fetch($query))
	{
		$data['ask']=str_replace("\'","'",$data['ask']);//����
		$data['option1']=str_replace("\'","'",$data['option1']);//����
		$data['option2']=str_replace("\'","'",$data['option2']);//����
		$data['option3']=str_replace("\'","'",$data['option3']);//����
		$data['option4']=str_replace("\'","'",$data['option4']);//����
		$data['option5']=str_replace("\'","'",$data['option5']);//����
		
		require_once libfile ( 'function/discuzcode' );
		$data['option1']  = discuzcode ( $data['option1'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option2']  = discuzcode ( $data['option2'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option3']  = discuzcode ( $data['option3'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option4']  = discuzcode ( $data['option4'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option5']  = discuzcode ( $data['option5'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option6']  = discuzcode ( $data['option6'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option7']  = discuzcode ( $data['option7'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		
		 $tiku[] = $data;
	}
	
	return $tiku;
}

function GetYueduQuesion3($yid)
{
	$tiku=array();

		$where = "where  yuedulijie_timutype = $yid  ";


	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." $where order by id asc");

	while($data = DB::fetch($query))
	{
		$data['ask']=str_replace("\'","'",$data['ask']);//����
		
		 $tiku[] = $data;
	}
	
	return $tiku;
}

function GetYueduQuesion4($yid)
{
	$tiku=array();

	$where = "where yuedulijie_timutype = $yid   ";


	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." $where order by id asc");

	while($data = DB::fetch($query))
	{
		  $data['ask']=str_replace("\'","'",$data['ask']);//����

		 $tiku[] = $data;
	}
	
	return $tiku;
}

function GetYueduQuesion5($yid)
{
	$tiku=array();

	$where = "where  yuedulijie_timutype = $yid  ";

	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda')." $where order by id asc");

	while($data = DB::fetch($query))
	{
		 $data['ask']=str_replace("\'","'",$data['ask']);//����	
		 $tiku[] = $data;
	}
	
	return $tiku;
}
//From: dis'.'m.t'.'ao'.'bao.com
?>