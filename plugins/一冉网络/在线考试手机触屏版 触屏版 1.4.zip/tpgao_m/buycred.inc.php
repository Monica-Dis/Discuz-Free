<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

/*
//--------------Tall us what you think!----------------------------------
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	//��ȡ������Ϣ
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam_paper_func.php";
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam.rand.func.php";
	
	$needpay = intval($_GET['needpay']);
	
	
	if(!submitcheck('submit')){
	//�жϹ������
	session_start();
	$needcredit = GetNeedCredits($needpay);
	
		$config = array();
		global $_G;
		$config = $_G['cache']['plugin']['tp_exam'];
		$buypaper_credit_type=$config['buypaper_credit_type'];

		$addcredit = 'extcredits'.$buypaper_credit_type;
		$extcredit = GetCurrentCreditsbyExt($_G['uid'],$addcredit);
		

	include template('tpgao_m:mbuycred');
}else{
	
		$item = intval($_POST['item']);
		session_start();
		$config = array();
		global $_G;
		$config = $_G['cache']['plugin']['tp_exam'];
		$buypaper_credit_type=$config['buypaper_credit_type'];
		$admin_tpgao_use_credits_low = lang('plugin/tp_exam','admin_tpgao_use_credits_low');
	
		$addcredit = 'extcredits'.$buypaper_credit_type;
		$buy_credits_number = intval($_GET['buy_credits_number']);
		
		$uid = $_G['uid'];

		$credits = DB::result_first("SELECT ".$addcredit." FROM ".DB::table('common_member_count')." where uid = $_G[uid]");

		if($credits < $buy_credits_number){
			showmessage($admin_tpgao_use_credits_low, "plugin.php?id=tpgao_m:m", 'succeed');
		}
	
		updatemembercount($uid, array($addcredit => -$buy_credits_number));
		
		$_SESSION['credits_buyed_'.$item]=1;
		
		//���ݿ��¼
		WriteBuyRecordDB($uid,$buypaper_credit_type,$item,$buy_credits_number);
		showmessage(lang('plugin/tp_exam', 'exam_buy_success'), "plugin.php?id=tpgao_m:m&mod=exam&item=".$item, 'succeed');
		
}
//From: Dism_taobao_com
?>