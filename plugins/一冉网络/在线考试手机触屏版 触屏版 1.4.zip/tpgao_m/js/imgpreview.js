

//ͼƬ�ϴ�Ԥ��    IE�������˾���
function previewImage(eid,file)
{
	if(j("#upload_file").val() != ''){
		j("#form_eid").val(eid);
		j("#form_hash").val(formhash);
		j("#submit_form").submit();
	}
/*
	j.post("plugin.php?id=tpgao_m:submit_form_process", {upload_file:file.value},function(data) {
		alert(data);
	});
*/
/*
	var tds = $('nobox:td');
	for(var i=0;i<tds.length;i++){
		var veid = tds[i].getAttribute("eid");
		if(veid == eid){
			tds[i].setAttribute('answerimage', "ppp");
			break;
		}
	}*/

}

function setAnswerImage(eid,uImage)
{
	var tds = $('nobox:td');
	for(var i=0;i<tds.length;i++){
		var veid = tds[i].getAttribute("eid");
		if(veid == eid){
			tds[i].setAttribute('answerimage', uImage);
			break;
		}
	}
}

function clacImgZoomParam( maxWidth, maxHeight, width, height ){
    var param = {top:0, left:0, width:width, height:height};
    if( width>maxWidth || height>maxHeight )
    {
        rateWidth = width / maxWidth;
        rateHeight = height / maxHeight;
        
        if( rateWidth > rateHeight )
        {
            param.width =  maxWidth;
            param.height = Math.round(height / rateWidth);
        }else
        {
            param.width = Math.round(width / rateHeight);
            param.height = maxHeight;
        }
    }
    
    param.left = Math.round((maxWidth - param.width) / 2);
    param.top = Math.round((maxHeight - param.height) / 2);
    return param;
}