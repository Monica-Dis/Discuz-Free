function addEventHandler(obj, eventName, fun, param){
	var fn = fun;
	if(param){
		fn = function(e)
		{
			fun.call(this, param);
		}
	}
	if(obj.attachEvent){
		obj.attachEvent('on'+eventName,fn);
	}else if(obj.addEventListener){
		obj.addEventListener(eventName,fn,false);
	}else{
		obj["on" + eventName] = fn;
	}
}

function $(id){
				
	if(typeof(id) != 'undefined'){
		var a = id.toString().split(':');
		if(a.length==2 && a[0].length < 20 )
			return document.getElementById(a[0]).getElementsByTagName(a[1]);
		else 
			return document.getElementById(id);
	}
}

function httpRequest(){
	var xmlHttp = false;
	if(window.XMLHttpRequest) {
		xmlHttp = new XMLHttpRequest();
		xmlHttp.overrideMimeType && xmlHttp.overrideMimeType('text/xml');
	}else if(window.ActiveXObject) {
		var versions = ['Microsoft.XMLHTTP', 'MSXML.XMLHTTP', 'Microsoft.XMLHTTP', 'Msxml2.XMLHTTP.7.0', 'Msxml2.XMLHTTP.6.0', 'Msxml2.XMLHTTP.5.0', 'Msxml2.XMLHTTP.4.0', 'MSXML2.XMLHTTP.3.0', 'MSXML2.XMLHTTP'];
		for(var i=0 in versions) {
			try {
				xmlHttp = new ActiveXObject(versions[i]);
				break;
			} catch(e) {/*alert(e.message);*/}
		}
	}
	return xmlHttp;
}

function ajaxget(url, callback){
	var xmlHttp = httpRequest();
	if(xmlHttp){
		xmlHttp.onreadystatechange = function(){
			if(xmlHttp.readyState == 4){
				if(xmlHttp.status == 200){
					if(typeof callback=="function"){
						callback(xmlHttp.responseText); 
					}
				}
			}
		};
		xmlHttp.open("get", url, true);
		xmlHttp.send(null);
	}
}


function ding(the){the.className = the.className!='ding_on' ? 'ding_on' : 'ding_off';}

function cal_score(){
	
	var tds = $('nobox:td'), total = 0;
	var error=new Array();
	
	var total_num = tds.length;
	var correct_num = 0;
	
	for(var i = 0; i<tds.length; i++){
		var td = tds[i];		
		var type   = td.getAttribute('type');
		var result = td.getAttribute('result');
		var answer = td.getAttribute('answer');
		var eid   = td.getAttribute('eid');
		var tikuid   = td.getAttribute('tikuid');
		var optionscore = td.getAttribute('optionscore');
		
		
		if(answer!=''){
			if(type<=3)
			{
				console.log("type=" + type);
				console.log("singleoptionscore=" + singleoptionscore);
				
				if (type == 1 && singleoptionscore == 1) {
					console.log("answer=" + answer);
					console.log("optionscore=" + optionscore);
					
					var arr = optionscore.split("\n");
					var opscore = 0;
					var nA = 65;
					for(var k=0 in arr){
						var A = String.fromCharCode(nA++);
						console.log("A=" + A);
						if (answer == A) {
							opscore = arr[k];
							console.log("opscore=" + opscore);
							total += parseFloat(opscore);
							break;
						}
					}
					
					correct_num++;
					td.style.textDecoration = '';
					td.style.color = 'green';
					correct_num++;
				}else if(result==answer){
					total += parseFloat(td.getAttribute('score'));
					td.style.textDecoration = '';
					td.style.color = 'green';
					correct_num++;

				}else{
					td.style.textDecoration = 'line-through';
					td.style.color = 'red';
					var ask = tikuid ;
					error.push(ask);
				}
				
			}else if(type==4){
						var arr1 = answer.split(",");
						var arr2 = result.split("|");
						if(arr1.sort().toString() == arr2.sort().toString()){
							total += parseFloat(td.getAttribute('score'));
							correct_num++;
							td.style.textDecoration = 'none';
							td.style.color = '';
						}else{
							td.style.textDecoration = 'line-through';
							td.style.color = 'red';
							var ask = tikuid ;
							error.push(ask);
						}
				
			}else{
					total += parseFloat(td.getAttribute('score'));
					correct_num++;
					td.style.textDecoration = 'none';
					td.style.color = '';
			}
		}
		else{
			td.style.textDecoration = 'line-through';
		}
	}
	
	var str=error.join(";");

	correct_ratio = (correct_num / total_num) * 100;
	
	//��������
	ajaxget('plugin.php?id=tpgao_m:m'+'&errordata='+str+'&item='+item+'&'+Math.random(), function(v){
	});
	
	console.log("total=" + total);
	
	return total;
}

function showsubmit(obj,alerttitle,alertcontent,alert_completetiku,alertyesText,alertnoText,showrequest){
			//�����Ƿ�����
			var tds = $('nobox:td'), total = 0;
			var complete = 1;
			for(var i = 0; i<tds.length; i++){
				var answer = tds[i].getAttribute('answer');

				if(answer == '') {
					complete = 0;break;
				}
			}
			
			var alerttext = alert_completetiku;
			if(!complete) alerttext = alertcontent;
			
			if(showrequest!=''){
				showrequest =  '<br><input type="checkbox" id="requestcheck">' + showrequest;
			}
			
			ds.dialog({
		   title : alerttitle,
		   content :  alerttext + showrequest ,
		   yesText : alertyesText,
		   onyes:function(){
		   	jq('#1000').unbind( "click" );
		   	document.getElementById("1000").onclick = function(){}
		   	this.close();
			   submit();
			   return false;
		   },
		   noText : alertnoText,
		   onno : function(){
			   this.close();
		   },
		   icon : "source/plugin/tpgao_m/images/question.gif",
		});

		jq('[id^=ds_dialog_]').css('left','20px');
}

function submit(){

	$('numbox').style.display='none';
	var item = $('paperid').getAttribute("value");

	var sb = $('submitbox');
	sb.style.display = sb.style.display=='block' ? 'none' : 'block';

	var arrRecord=new Array();         //��ż�¼
	var wendaadd = new Array();
	var tds = $('nobox:td'), string = '', dot = '';
	for(var i = 0; i<tds.length; i++){
		var td = tds[i];
		var eid = td.getAttribute('oid');
		var type = td.getAttribute('type');
		var answer = td.getAttribute('answer');
		var tikuid = td.getAttribute('tikuid');
		var wendaadditional = td.getAttribute('wendaadditional');
		arrRecord[tikuid] = answer;
		wendaadd[tikuid] = wendaadditional;
		string += dot + type + ',' + eid ;
		dot = ';';
	}
	console.log("string=" + string);
  
  var requesteva = 0;
  /*
  if(document.getElementById("requestcheck").checked){
  	 requesteva = 1;
	}*/
		   	
	ajaxget('plugin.php?id=tpgao_m:m&paperid='+item+'&formhash='+formhash+'&resultdata=' + string + '&' + Math.random(), function(v){

		v = v.replace("/(^\s*)|(\s*$)/g", "");
		v = v.replace(/(\n)+|(\r\n)+/g, "");
		
		//[img]
		v = v.replace(/\[img\]([^[]+)\[\/img\]/g, '<img src=$1> ');
		
		if(v[0]=='[' || v[3] == '['){

			var R = eval( '(' + v + ')' );
			var tds = $('nobox:td');
			for(var i = 0; i<tds.length; i++){
				var td = tds[i],e=R[i];
				var type = td.getAttribute('type');
				td.setAttribute('result', e['result']);
				td.setAttribute('note', e['answer_parser']);
			}

			var total = cal_score();
			var msg = "&#x6211;&#x7684;&#x5F97;&#x5206;: "+total+"&#x5206; &nbsp" + $('summary').innerText + "&#x8BB0;&#x5F55;ID:" ;

			if (openmedal) {
				msg +="<br>";
				msg +="&#x606D;&#x559C;&#x5F97;&#x5230;&#x4E00;&#x4E2A;&#x5956;&#x7AE0;";
			}
			submitpaper = 1;
			$('p_msg').style.display='block';
			show_exam(eidArr[$('seek').innerHTML-1]);
			
			var usetime = $('usetime').getAttribute("value");
			var uniquecode = $('uniquecode').getAttribute("value");
			
			ajaxget('plugin.php?id=tpgao_m:m&formhash='+formhash+'&requestevaluate='+requesteva+'&total=' + total + '&correctratio=' + correct_ratio + '&item='+item+'&usetime='+usetime+ '&u=' + uniquecode + '&'+Math.random(), function(v){
				console.log(v);
					var R = eval( '(' + v + ')' );
					msg += R['recordid'];
					var ser=new Array();
					var tmp = new Array();
					var tds = $('nobox:td') ;
					for(var i = 0; i<tds.length; i++){
					var td = tds[i];
					var answer = td.getAttribute('answer');
					var answerimage = td.getAttribute('answerimage');
					var etype = td.getAttribute('type');
					var tmp  = { 'answer' : answer ,'answerimage': answerimage,'type':etype};
					ser.push(tmp);
				}
				
				if(jiaojuan_start){
					document.getElementById('jiaojuan_content').innerHTML = R['jiaojuantips'];
					document.getElementById('light').style.display='block';document.getElementById('fade').style.display='block';
					document.getElementById('weibo').href = "http://service.weibo.com/share/share.php?title=" + R['cate_act'] + "&url=" + R['share_url'] + "&source=bookmark&appkey=2992571369&pic=&ralateUid=#_loginLayer_1486871877015";
					document.getElementById('qzone').href = "http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?title=" + R['cate_act_utf8'] + "&url=" + R['share_url'] + "&pics=&summary=" + R['cate_act_utf8'];
					document.getElementById('tweibo').href = "http://share.v.t.qq.com/index.php?c=share&a=index&url=" + R['share_url'] + "&appkey=ce7fb946290e4109bdc9175108b6db3a&site=%E5%A4%A7%E5%85%B4%E5%9C%9F%E6%9C%A8%E8%AE%BA%E5%9D%9B&pic=&title="+R['cate_act']+"&from=discuz";
					document.getElementById('weixinapp').innerHTML = R['cate_act'];
					document.getElementById('fe_text').value = R['cate_act'] + R['share_url'];
					//http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url={$share_url}&title={$cate_act_utf8}&pics=&summary={$cate_act}
				}
				

				jq.post("plugin.php?id=tpgao_m:record",{"rid":arrRecord,"wendaadd":wendaadd,"recordid":R['recordid'],"formhash":formhash},function(data){
					
  			});
  
				$('showbox').outerHTML = msg;
			
			});
			
			clearInterval(objTimer);

		}else{
			alert('&#x65E0;&#x6743;&#x9650;&#x4EA4;&#x5377;');
		}
	});
}

function nv_click(mode)
{
	if(mode=='no'){
		$('submitbox').style.display='none';
		var nb = $('numbox');
		nb.style.display = nb.style.display=='block' ? 'none' : 'block';
	}
	else if(mode=='prev'){
		clearNote();
		$('submitbox').style.display='none'; 
		if(!submitpaper){
			$('p_msg').style.display='none';
		}
		var k = Math.max(1, parseInt($('seek').innerHTML)-1);
		show_exam(eidArr[k-1]);
		$('seek').innerHTML = k;
	}
	else if(mode=='next'){
		clearNote();
		$('submitbox').style.display='none';
		if(!submitpaper){
			$('p_msg').style.display='none';
		}
		var k = Math.min(eidArr.length, parseInt($('seek').innerHTML)+1);
		show_exam(eidArr[k-1]);
		$('seek').innerHTML = k;
	}				
}

function clearNote()
{
	$('p_note_image').innerHTML = '';
	$('p_note').innerHTML = '';
}

function elabel(eid, v)
{
	if($('p_msg').style.display=='block')
		return;
	
	var msg = '';
	var td   = $(eid);
	var type = td.getAttribute('type');
	var oid = td.getAttribute('oid');
	var lis  = $('p_data:li');

	if(type==2){
		var str = '';
		for(var i=0;i<lis.length;i++){
			if(lis[i].getAttribute('value')==v){
				lis[i].className =  lis[i].className=='option_on' ? 'option_off' : 'option_on';
			}
			if(lis[i].className=='option_on'){
				var vallis =  lis[i].getAttribute('value');
				str += vallis;
				msg += '<input type="hidden"  name="m_answer[' + oid + '][]" value="' + vallis + '"/>';
			}
		}
		$('m').innerHTML = msg;
		td.setAttribute('answer', str);
	}else{
		for(var i=0;i<lis.length;i++){
			lis[i].className = lis[i].getAttribute('value')==v ? 'check_on' : 'check_off';
		}
		td.setAttribute('answer', v);
		var getid = td.getAttribute('getid');
		$(getid).value = v ;
	}
	td.style.color = 'blue';
}

var eidAnswer  = new Array();
var submitpaper=false;
function echange(obj,eid,order,ele)
{
	var tds = $('nobox:td');
	var msg = '';

	eidAnswer[order-1] = obj.value;
	var j = eidAnswer.join();

	for(var i=0;i<tds.length;i++){
		
		if(tds[i].getAttribute('eid') == eid){
			
			tds[i].setAttribute(ele, j);

			var type = tds[i].getAttribute('type');
			if(type == 4){
				var tikuid = tds[i].getAttribute('tikuid');
				for(var j=0;j<eidAnswer.length;j++){
					var vallis = eidAnswer[j];
					msg += '<input type="hidden"  name="t_answer[' + tikuid + '][]" value="' + vallis + '"/>';
				}
				var getid = tds[i].getAttribute('getid');
				$(getid).innerHTML = msg ;
			}else{
				var getid = tds[i].getAttribute('getid');
				$(getid).value = obj.value ;
			}
			

			//tds[i].setAttribute(ele, j);
			break;
		}
	}

}

function practise(rid)
{
	var td   = $(rid);
	var type = td.getAttribute('type');
	var oid = td.getAttribute('oid');
	
	var ele = document.getElementById("p_msg");

	if(ele.style.display != 'block'){
		ajaxget('plugin.php?id=tpgao_m:m&formhash='+formhash+'&mod=pt&type='+type+'&oid='+oid+'&'+Math.random(), function(v){
		if(v[0]=='{'){
			var R = eval( '(' + v + ')' );
			td.setAttribute('result', R['result']);
			td.setAttribute('note', R['answer_parser']);
			$('p_msg').style.display='block';
			show_exam(rid);
		}
		});
	}else{
		$('p_msg').style.display='none'
	}

}

var type_string = {1:'&#x5355;&#x9009;&#x9898;', 2:'&#x591A;&#x9009;&#x9898;', 3:'&#x5224;&#x65AD;&#x9898;', 4:'&#x586B;&#x7A7A;&#x9898;', 5:'&#x95EE;&#x7B54;&#x9898;',6:'&#x7EC4;&#x5408;&#x9898;'};

function show_exam(eid)
{
	var the    = $(eid);
	var type   = the.getAttribute('type');
	var score  = the.getAttribute('score');
	var result = the.getAttribute('result');
	var answer = the.getAttribute('answer');
	var subject= the.getAttribute('subject');
	var data   = the.getAttribute('data');
	var note   = the.getAttribute('note');
	var image  = the.getAttribute('image');
	var video  = the.getAttribute('video');
	var eeid  = the.getAttribute('eid');
	var oid  = the.getAttribute('oid');
	var tikuid  = the.getAttribute('tikuid');
	var optionscore  = the.getAttribute('optionscore');
	var wendaadditional  = the.getAttribute('wendaadditional');
	
	var answerimage = the.getAttribute("answermage");
	var parserimage  = the.getAttribute('parserimage');
	
	$("wenda").style.display = "none";
	
	if(type==4){

		ajaxget('plugin.php?id=tpgao_m:m'+'&tk=1&formhash='+formhash+'&eid='+eeid + '&oid=' + oid + '&as=' + answer + '&'+ Math.random(), function(v){
			subject = v;
			$('p_subject').innerHTML = '['+type_string[type] +'] '+ subject + '('+score+'&#x5206)';
			
		});
		
	}
	else
		$('p_subject').innerHTML = '['+type_string[type] +'] '+ subject + '('+score+'&#x5206)';
	
	if(image!="")
		$('p_image').innerHTML = '<img src="'+image+'" border=0>';
	else
		$('p_image').innerHTML = '';
	
	if (video!="") {
		$('video').style.display = 'block';
				var newVideoObject = {
					container: '#video',
					variable: 'player',
					autoplay: false,
					video: video
				}

				var player = new ckplayer(newVideoObject);
	}else{
		$('p_video').innerHTML = '';
		$('video').innerHTML = '';
		$('video').style.display = 'none';
	}
	
	$("submit_form").innerHTML = '';
	
	var datastr ='';
	var btnstr='';
	var bPass = false;
	if(type==3){
		datastr += '<li class="'+(answer==1?"check_on":"check_off")+'" value="1" onclick="elabel('+eid+', 1)">&#x6B63;&#x786E;</li>';
		datastr += '<li class="'+(answer==2?"check_on":"check_off")+'" value="2" onclick="elabel('+eid+', 2)">&#x9519;&#x8BEF;</li>';
		bPass = answer && answer == result;
	}
	if(type==1 || type==2){
		
		var arr = data.split("\n");
		var nA = 65;
		
		for(var k=0 in arr){
			var A = String.fromCharCode(nA++);
			if(arr[k]!=""){
				datastr += '<li class="'+(type==1 ? 'check' : 'option')+(answer.indexOf(A)==-1?"_off":"_on")+'" value="'+A+'" onclick="elabel('+eid+',\''+A+'\')">' + A +'. '+ arr[k] + '</li>';
			}
		}
		
		if(type == 1 && optionscore){
			bPass = true;
		}else{
			bPass = answer && answer == result;	
		}
		
	}
	else if(type==4 ){
		var arr1 = answer.split(",");
		var arr2 = result.split("|");
		if(arr1.sort().toString() == arr2.sort().toString()){
			bPass = answer = 1;
		}
	}
	else if( type==5){
		$("wenda").style.display = "block";
		datastr += '&#x81EA;&#x8BC4;&#x5206;:&nbsp&nbsp<input type="text" value="'+wendaadditional+'" onchange="echange(this,'+eeid+',1,\'wendaadditional\');" name="evaluate" style="width:50px;"><br><textarea rows="3" onchange="echange(this,'+eeid+',1,\'answer\');" cols="20">'+answer+'</textarea>';
		bPass = answer = 1;
	}

	$('p_data').innerHTML  = datastr;
	<!--{if !$paperParam[practise]}-->
	$('btnnav').innerHTML  = '<cite onclick="practise('+eid+');" type=' + type + ' oid='+ oid +' style="margin-left:-3px;border-radius: 30px;">&#x67E5;&#x770B;&#x7B54;&#x6848;</cite>';
	<!--{/if}-->
	<!--{if $opensyn}-->
	$('btnsyn').innerHTML  = '<cite onclick="synquestion('+type+','+oid+','+tikuid+');" style="margin-left:-3px;border-radius: 30px;">&#x8BA8;&#x8BBA;&#x8BE5;&#x9898;</cite>';
	<!--{/if}-->
	
	var show  = document.getElementById("showanswer");
	
	if($('p_msg').style.display=='block'){
		$('p_icon').className = bPass? 'icon_right' : 'icon_wrong';
		if(show.value == 1){
			$('p_result').innerHTML = '&#x53C2;&#x8003;&#x7B54;&#x6848;: '+ (type==3?(result==1?'&#x6B63;&#x786E;':'&#x9519;&#x8BEF;'): result);					
			if(note!='') $('p_note').innerHTML = '&#x672C;&#x9898;&#x89E3;&#x91CA;:<br>'+note;
				if(parserimage!="")
					$('p_note_image').innerHTML = '<img src="'+parserimage+'" border=0>';
				else
					$('p_note_image').innerHTML = '';
		}
	}

}

function closeWindow(obj)
{
	$('submitbox').style.display='none';
}

function is_weixin(){
	var ua = navigator.userAgent.toLowerCase();
	if(ua.match(/MicroMessenger/i)=="micromessenger") {
		return true;
 	} else {
		return false;
	}
}

function synquestion(ttype,oid,tikuid){

	var urlpost = 'plugin.php?id=tpgao_questionsyn:syn';

	jq.ajax({
     type : 'POST',
     url : urlpost ,
     data: 'datatype='+ttype+'&dataid=' + oid + '&tikuid=' + tikuid ,
     dataType : 'text',
     async:false,
     success : function(data) {
     	if(data==-1){

				}
     	else
					window.open("forum.php?mod=viewthread"+'&'+"tid=" + data, '_self');
     },
     error : function() {
     } 
   }); 
        
}

function masker(obj){
	if(obj.style.display == 'block'){
		obj.style.display = 'none';
	}
}

function weixinfriend(obj){
	if(!isWeiXin()){
			var wechat_masker = document.getElementById("wechat-masker");
			var other_guider = document.getElementById("other-guider");
			var wechat_guider = document.getElementById("wechat-guider");
			wechat_masker.style.display = 'block';
			other_guider.style.display = 'block';
			wechat_guider.style.display = 'none';

			
	}else{
		var wechat_masker = document.getElementById("wechat-masker");
		var other_guider = document.getElementById("other-guider");
		var wechat_guider = document.getElementById("wechat-guider");
		wechat_masker.style.display = 'block';
		wechat_guider.style.display = 'block';
		other_guider.style.display = 'none';
		document.title = document.getElementById('weixinapp').innerHTML;
			
	}
}

function isWeiXin(){
    var ua = window.navigator.userAgent.toLowerCase();
    if(ua.match(/MicroMessenger/i) == 'micromessenger'){
        return true;
    }else{
        return false;
    }
}

