<?php


	if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
	}
	
	
	showformheader("plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list&app={$app}", 'order_submit');
	showtableheader();

	$admin_exam_timulist_type = lang('plugin/tp_exam', 'admin_exam_timulist_type');
	$timu = lang('plugin/tp_exam', 'timu');
	$admin_exam_timulist_paper = lang('plugin/tp_exam', 'admin_exam_timulist_paper');
	$admin_exam_timulist_score = lang('plugin/tp_exam', 'admin_exam_timulist_score');
	$admin_exam_timulist_pubtime = lang('plugin/tp_exam', 'admin_exam_timulist_pubtime');
	$admin_exam_timulist_pubname = lang('plugin/tp_exam', 'admin_exam_timulist_pubname');
	$admin_common_op = lang('plugin/tp_exam', 'admin_common_op');
	$admin_common_delete = lang('plugin/tp_exam', 'admin_common_delete');
	$admin_common_edit = lang('plugin/tp_exam', 'admin_common_edit');
	$type_arr=array($admin_pub_type1,$admin_pub_type2,$admin_pub_type3,$admin_pub_type4,$admin_pub_type5,$admin_pub_type6,$admin_pub_type7);
	
	showtitle('&nbsp;'.$totalnum);
	showsubtitle(array('id',$admin_exam_timulist_type,$timu,$admin_exam_timulist_paper,$admin_exam_timulist_score,$admin_exam_timulist_pubtime,$admin_exam_timulist_pubname,"<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list&item=all&&type=all&del=all\">".$admin_common_delete."</a>",$admin_common_op));
	
	$tiKu = GetAllTypeTiKu(0,0,0,0,1);

	//��ҳ��Ϣ��ʼ
	$perpage = 15;
	$page = max(1, intval(daddslashes($_GET['page'])));
	$listStart = ($page-1) *$perpage;
	$listEnd = $page*$perpage;
	
	$where = '';
	$totalnum = count($tiKu);

	$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 

	$multi = multi($totalnum, $perpage, $page, ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list",$pagecount);
	
	GetPageList($tiKu,$totalnum, $listStart, $listEnd);
	
	showsubmit('submit', 'submit', 'del', '', $multi);
	
	showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
	showformfooter(); /*dism��taobao��com*/
		
?>