<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(!submitcheck('filestylesubmit')){
	
showtabcss();	
showtableheader('','tp_tuan_tb');
showtablerow('', array(''), 
array('<div class="tp_tuan_tab tp_tuan_min"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_setting&app=styles" class="active"><i></i><ins></ins>&#x57FA;&#x672C;&#x64CD;&#x4F5C;</a></div>'));
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/

$filestyleadv = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." WHERE skey='filestylesadv'");
$filestyleadv = unserialize($filestyleadv);

include_once template('tp_exam:styles/admin_setting_styles');	
}else{
	
	$success = lang('plugin/tp_exam', 'admin_common_success');
	
	$moni = daddslashes($_GET['moni']);
	$zhenti = daddslashes($_GET['zhenti']);
	$nengli = daddslashes($_GET['nengli']);
	
	$arr = array('moni'=>$moni,
	'zhenti'=>$zhenti,
	'nengli'=>$nengli);
	
	$arr = serialize($arr);

	DB::update('tpexam_setting',array('svalue'=>$arr),"skey='filestylesadv'");
	
	cpmsg($success, "action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_setting&app=styles", 'succeed');
}

//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>