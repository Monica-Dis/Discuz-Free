<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$edit = trim(daddslashes($_GET['edit']));
$type = trim(daddslashes($_GET['type']));

if(!submitcheck('submit') ) 
{
			$admin_recipt_tuan_name = lang('plugin/tp_tuangou','admin_recipt_tuan_name');
			$admin_recipt_user_name = lang('plugin/tp_tuangou','admin_recipt_user_name');
			$admin_recipt_user_tele = lang('plugin/tp_tuangou','admin_recipt_user_tele');
			$admin_recipt_user_addr = lang('plugin/tp_tuangou','admin_recipt_user_addr');
			$admin_recipt_user_memo = lang('plugin/tp_tuangou','admin_recipt_user_memo');
			$admin_back_timu_list = lang('plugin/tp_exam','admin_back_timu_list');

			showformheader("plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list&&edit=$edit&type=$type", 'order_submit');
			showhiddenfields(array('orderid' => $row['orderid']));
			showtableheader();
			showtitle(lang('plugin/tp_exam', 'admin_basic_timu_list')."&nbsp;&nbsp;<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list\" class=\"act lightlink normal\">&gt;&gt;".$admin_back_timu_list."</a>");
			
			switch($type)
			{
				case 'danxuan':
				editDanxuan($edit);
				break;
				case 'duoxuan':
				editDuoxuan($edit);
				break;
				case 'panduan':
				editPanduan($edit);
				break;
				case 'tiankong':
				editTiankong($edit);
				break;
				case 'wenda':
				editWenda($edit);
				break;
				case 'yuedu':
				editYuedu($edit);
				break;
				case 'peiwu':
				editPeiwu($edit);
				break;
			}
		
			showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
			showformfooter(); /*dism��taobao��com*/
	
}
else
{
			switch($type)
			{
				case 'danxuan':
				updateDanxuan($edit);
				break;
				case 'duoxuan':
				updateDuoxuan($edit);
				break;
				case 'panduan':
				updatePanduan($edit);
				break;
				case 'tiankong':
				updateTiankong($edit);
				break;
				case 'wenda':
				updateWenda($edit);
				break;
				case 'yuedu':
				updateYuedu($edit);
				break;
				case 'peiwu':
				updatePeiwu($edit);
				break;				
			}
			
			$success = lang('plugin/tp_exam', 'admin_common_success');
			cpmsg($success, "action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list", 'succeed');
}
function editPanduan($edititem)
{
		$admin_common_submit = lang('plugin/tp_exam', 'admin_common_submit');
		$exam_timu_yes = lang('plugin/tp_exam', 'exam_timu_yes');
		$exam_timu_no = lang('plugin/tp_exam', 'exam_timu_no');
		$daan = lang('plugin/tp_exam', 'daan');
		$admin_timulist_video_tip = lang('plugin/tp_exam', 'admin_timulist_video_tip');
		$admin_exam_timulist_score = lang('plugin/tp_exam', 'admin_exam_timulist_score');
		$admin_pubexam_viewanswer_credits = lang('plugin/tp_exam','admin_pubexam_viewanswer_credits');
		
		$exam_timu_item = lang('plugin/tp_exam', 'exam_timu_item');
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." WHERE id='".$edititem."'");
		if($row = DB::fetch($query))
		{	
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$exam_timu_item.":",
							"<textarea type='text' name='ask' cols=40 rows=4 />{$row[ask]}</textarea>"
					));
			
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$admin_exam_timulist_score.":",
							"<input type='text' name='score' value='{$row[score]}'/>"
					));
					
				switch($row['answer'])
				{
					case '1':
						$a_checked = "checked";break;
					case '0':
						$b_checked = "checked";break;
				}

			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$daan,"<lable><input type='radio' name='answer' value='1' $a_checked/>$exam_timu_yes</lable><lable><input type='radio' name='answer' value='0' $b_checked/>$exam_timu_no</lable>"));
		
			
			showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_timulist_image_tip,"<input type='text' name='imageurl' value='{$row[image]}' style='width:300px;'/>"
					));
					
			showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_timulist_video_tip,"<input type='text' name='videourl' value='{$row[video]}' style='width:300px;'/>"
					));
					
			showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_pubexam_viewanswer_credits,"<input type='text' name='viewParser_credits' value='{$row[viewParser_credits]}' style='width:300px;'/>"
					));

			showtablerow('', array('class="td25"', 'class="td28"'), array("<input id='submit' class='btn' type='submit' value='$admin_common_submit'  name='submit'>"));  							
		}						
}

function editDanxuan($edititem)
{
		$exam_timu_item = lang('plugin/tp_exam', 'exam_timu_item');
		$exam_option = lang('plugin/tp_exam', 'exam_option');
		$admin_timulist_image_tip = lang('plugin/tp_exam', 'admin_timulist_image_tip');
		$admin_timulist_video_tip = lang('plugin/tp_exam', 'admin_timulist_video_tip');
		$exam_answer_parser = lang('plugin/tp_exam', 'exam_answer_parser');
		$admin_exam_timulist_score = lang('plugin/tp_exam', 'admin_exam_timulist_score');
		$admin_pubexam_viewanswer_credits = lang('plugin/tp_exam','admin_pubexam_viewanswer_credits');
		
		$admin_common_submit = lang('plugin/tp_exam', 'admin_common_submit');
		$daan = lang('plugin/tp_exam', 'daan');
		
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." WHERE id='".$edititem."'");
		if($row = DB::fetch($query))
		{	
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$exam_timu_item.":",
							"<textarea name='ask' rows=4 cols=40 >{$row[ask]}</textarea>"
					));
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$admin_exam_timulist_score.":",
							"<input type='text' name='score' value='{$row[score]}'/>"
					));
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
		 					$exam_option."A:",
							"<input type='text' name='option1' value='{$row[option1]}'/>"
					));				
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"B","<input type='text' name='option2' value='{$row[option2]}'/>"
					));	
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"C","<input type='text' name='option3' value='{$row[option3]}'/>"
					));				
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"D","<input type='text' name='option4' value='{$row[option4]}'/>"
					));	
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"E","<input type='text' name='option5' value='{$row[option5]}'/>"
					));				
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"F","<input type='text' name='option6' value='{$row[option6]}'/>"
					));
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"G","<input type='text' name='option7' value='{$row[option7]}'/>"
					));
		
		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$exam_answer_parser,"<input type='text' name='answer_parser' value='{$row[answer_parser]}' style='width:300px;'/>"
			));
					
		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_timulist_image_tip,"<input type='text' name='imageurl' value='{$row[image]}' style='width:300px;'/>"
					));

		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_timulist_video_tip,"<input type='text' name='videourl' value='{$row[video]}' style='width:300px;'/>"
					));
					
		switch($row['answer'])
		{
			case 'A':
			$a_checked = "checked";break;
			case 'B':
			$b_checked = "checked";break;
			case 'C':
			$c_checked = "checked";break;
			case 'D':
			$d_checked = "checked";break;
			case 'E':
			$e_checked = "checked";break;
			case 'F':
			$f_checked = "checked";break;
			case 'G':
			$g_checked = "checked";break;
		}
		
		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$daan,"<lable><input type='checkbox' name='answer' value='A' $a_checked/>A</lable><lable><input type='checkbox' name='answer' value='B' $b_checked/>B</lable><lable><input type='checkbox' name='answer' value='C' $c_checked/>C</lable><lable><input type='checkbox' name='answer' value='D' $d_checked/>D</lable><lable><input type='checkbox' name='answer' value='E' $e_checked/>E</lable><lable><input type='checkbox' name='answer' value='F' $f_checked/>F</lable><lable><input type='checkbox' name='answer' value='G' $g_checked/>G</lable>"
					));				
		}
		
		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
				  	$admin_pubexam_viewanswer_credits,"<input type='text' name='viewParser_credits' value='{$row[viewParser_credits]}' style='width:300px;'/>"
		));
					
		showtablerow('', array('class="td25"', 'class="td28"'), array("<input id='submit' class='btn' type='submit' value='$admin_common_submit'  name='submit'>"));  					
}

function editDuoxuan($edititem)
{
		$exam_timu_item = lang('plugin/tp_exam', 'exam_timu_item');
		$exam_option = lang('plugin/tp_exam', 'exam_option');
		
		$admin_common_submit = lang('plugin/tp_exam', 'admin_common_submit');
		$daan = lang('plugin/tp_exam', 'daan');
		$admin_timulist_image_tip = lang('plugin/tp_exam', 'admin_timulist_image_tip');
		$admin_timulist_video_tip = lang('plugin/tp_exam', 'admin_timulist_video_tip');
		$admin_exam_timulist_score = lang('plugin/tp_exam', 'admin_exam_timulist_score');
		$admin_pubexam_viewanswer_credits = lang('plugin/tp_exam','admin_pubexam_viewanswer_credits');
		
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." WHERE id='".$edititem."'");
		if($row = DB::fetch($query))
		{	
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$exam_timu_item.":",
							"<textarea name='ask' cols=40 row=4 >{$row[ask]}</textarea>"
					));
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$admin_exam_timulist_score.":",
							"<input type='text' name='score' value='{$row[score]}'/>"
					));
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
		 					$exam_option."A:",
							"<input type='text' name='option1' value='{$row[option1]}'/>"
					));				
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"B","<input type='text' name='option2' value='{$row[option2]}'/>"
					));	
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"C","<input type='text' name='option3' value='{$row[option3]}'/>"
					));				
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"D","<input type='text' name='option4' value='{$row[option4]}'/>"
					));	
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"E","<input type='text' name='option5' value='{$row[option5]}'/>"
					));				
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"F","<input type='text' name='option6' value='{$row[option6]}'/>"
					));
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"G","<input type='text' name='option7' value='{$row[option7]}'/>"
					));
		
		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_timulist_image_tip,"<input type='text' name='imageurl' value='{$row[image]}' style='width:300px;'/>"
					));

		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_timulist_video_tip,"<input type='text' name='videourl' value='{$row[video]}' style='width:300px;'/>"
					));
					
		for($i=0;$i<8;$i++){

				$param = 'answer'.$i;
			if(!empty($row[$param]))
			{
				if($row[$param]=='A') $a_checked='checked';
				else if($row[$param]=='B') $b_checked='checked';
				else if($row[$param]=='C') $c_checked='checked';	
				else if($row[$param]=='D') $d_checked='checked';
				else if($row[$param]=='E') $e_checked='checked';
				else if($row[$param]=='F') $f_checked='checked';
				else if($row[$param]=='G') $g_checked='checked';
			}
		}
				
		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$daan,"<lable><input type='checkbox' name='answer[]' value='A' $a_checked/>A</lable><lable><input type='checkbox' name='answer[]' value='B' $b_checked />B</lable><lable><input type='checkbox' name='answer[]' value='C' $c_checked/>C</lable><lable><input type='checkbox' name='answer[]' value='D' $d_checked/>D</lable><lable><input type='checkbox' name='answer[]' value='E' $e_checked/>E</lable><lable><input type='checkbox' name='answer[]' value='F' $f_checked/>F</lable><lable><input type='checkbox' name='answer[]' value='G' $g_checked/>G</lable>"
					));																						
		}

		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
				  	$admin_pubexam_viewanswer_credits,"<input type='text' name='viewParser_credits' value='{$row[viewParser_credits]}' style='width:300px;'/>"
		));
		
		showtablerow('', array('class="td25"', 'class="td28"'), array("<input id='submit' class='btn' type='submit' value='$admin_common_submit'  name='submit'>"));  					
}

function editTiankong($edititem)
{
		$exam_timu_item = lang('plugin/tp_exam', 'exam_timu_item');
		$daan = lang('plugin/tp_exam', 'daan');
		$admin_common_submit = lang('plugin/tp_exam', 'admin_common_submit');
		$admin_timulist_image_tip = lang('plugin/tp_exam', 'admin_timulist_image_tip');
		$admin_timulist_video_tip = lang('plugin/tp_exam', 'admin_timulist_video_tip');
		$admin_exam_timulist_score = lang('plugin/tp_exam', 'admin_exam_timulist_score');
		$admin_pubexam_viewanswer_credits = lang('plugin/tp_exam','admin_pubexam_viewanswer_credits');
		$exam_answer_parser = lang('plugin/tp_exam', 'exam_answer_parser');
		$daan = lang('plugin/tp_exam', 'daan');
		
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." WHERE id='".$edititem."'");
		if($row = DB::fetch($query))
		{	
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$exam_timu_item.":",
							"<textarea type='text' name='ask'  rows=4 cols=40 />{$row[ask]}</textarea>"
					));
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$admin_exam_timulist_score.":",
							"<input type='text' name='score' value='{$row[score]}'/>"
					));
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$daan.":",
							"<input type='text' name='answer' value='{$row[answer]}' style='width:250px;'/>"
					));
		
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
					$admin_timulist_image_tip.":",
					"<input type='text' name='image' value='{$row[image]}' style='width:250px;'/>"
			));
			
		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_timulist_video_tip,"<input type='text' name='videourl' value='{$row[video]}' style='width:300px;'/>"
					));

		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$exam_answer_parser,"<input type='text' name='answer_parser' value='{$row[answer_parser]}' style='width:300px;'/>"
			));
			
		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
				  	$admin_pubexam_viewanswer_credits,"<input type='text' name='viewParser_credits' value='{$row[viewParser_credits]}' style='width:300px;'/>"
		));
		
		}
		
		showtablerow('', array('class="td25"', 'class="td28"'), array("<input id='submit' class='btn' type='submit' value='$admin_common_submit'  name='submit'>"));  					
}

function editWenda($edititem){
		$exam_timu_item = lang('plugin/tp_exam', 'exam_timu_item');
		$daan = lang('plugin/tp_exam', 'daan');
		$admin_common_submit = lang('plugin/tp_exam', 'admin_common_submit');
		$admin_timulist_image_tip = lang('plugin/tp_exam', 'admin_timulist_image_tip');
		$admin_timulist_video_tip = lang('plugin/tp_exam', 'admin_timulist_video_tip');
		$admin_exam_timulist_score = lang('plugin/tp_exam', 'admin_exam_timulist_score');
		$admin_pubexam_viewanswer_credits = lang('plugin/tp_exam','admin_pubexam_viewanswer_credits');
		
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda')." WHERE id='".$edititem."'");
		if($row = DB::fetch($query))
		{
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$exam_timu_item.":",
							"<textarea type='text' name='ask' cols=40 rows=4  />{$row[ask]}</textarea>"
					));

			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$admin_exam_timulist_score.":",
							"<input type='text' name='score' value='{$row[score]}'/>"
					));
					
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$daan.":",
							"<input type='text' name='answer' value='{$row[answer]}' style='width:250px;'/>"
					));
		
			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
					$admin_timulist_image_tip.":",
					"<input type='text' name='imageurl' value='{$row[image]}' style='width:250px;'/>"
			));
			
		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_timulist_video_tip,"<input type='text' name='videourl' value='{$row[video]}' style='width:300px;'/>"
					));
					
		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
				  	$admin_pubexam_viewanswer_credits,"<input type='text' name='viewParser_credits' value='{$row[viewParser_credits]}' style='width:300px;'/>"
		));
		
		}
		
		showtablerow('', array('class="td25"', 'class="td28"'), array("<input id='submit' class='btn' type='submit' value='$admin_common_submit'  name='submit'>"));  		
}

function editYuedu($edititem)
{
		$exam_timu_item = lang('plugin/tp_exam', 'exam_timu_item');
		$daan = lang('plugin/tp_exam', 'daan');
		$admin_common_submit = lang('plugin/tp_exam', 'admin_common_submit');
		$admin_timulist_image_tip = lang('plugin/tp_exam', 'admin_timulist_image_tip');
		$admin_timulist_video_tip = lang('plugin/tp_exam', 'admin_timulist_video_tip');
		
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_yuedulijie')." WHERE id='".$edititem."'");
		if($row = DB::fetch($query))
		{	


			showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$exam_timu_item.":",
							"<textarea name='ask' value='' rows=4 cols=40 >{$row[ask]}</textarea>"
					));		

		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_timulist_image_tip,"<input type='text' name='imageurl' value='{$row[image]}' style='width:300px;'/>"
					));

		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_timulist_video_tip,"<input type='text' name='videourl' value='{$row[video]}' style='width:300px;'/>"
					));
		}
		
		showtablerow('', array('class="td25"', 'class="td28"'), array("<input id='submit' class='btn' type='submit' value='$admin_common_submit'  name='submit'>"));  		
		
}

function editPeiwu($edititem){
	
		$exam_timu_item = lang('plugin/tp_exam', 'exam_timu_item');
		$daan = lang('plugin/tp_exam', 'daan');
		$admin_common_submit = lang('plugin/tp_exam', 'admin_common_submit');
		$admin_timulist_image_tip = lang('plugin/tp_exam', 'admin_timulist_image_tip');
		$admin_timulist_video_tip = lang('plugin/tp_exam', 'admin_timulist_video_tip');
		
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_peiwu')." WHERE id='".$edititem."'");
		if($row = DB::fetch($query))
		{	


	showtablerow('', array('class="td32"', '', 'class="td32"', ''), array(
							$exam_timu_item.":",
							"<textarea name='ask' value='' rows=4 cols=40 >{$row[ask]}</textarea>"
					));		
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
		 					$exam_option."A:",
							"<input type='text' name='option1' value='{$row[option1]}'/>"
					));				
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"B","<input type='text' name='option2' value='{$row[option2]}'/>"
					));	
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"C","<input type='text' name='option3' value='{$row[option3]}'/>"
					));				
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"D","<input type='text' name='option4' value='{$row[option4]}'/>"
					));	
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"E","<input type='text' name='option5' value='{$row[option5]}'/>"
					));				
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"F","<input type='text' name='option6' value='{$row[option6]}'/>"
					));
		 showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							"G","<input type='text' name='option7' value='{$row[option7]}'/>"
					));
		
		
		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_timulist_image_tip,"<input type='text' name='imageurl' value='{$row[image]}' style='width:300px;'/>"
					));

		showtablerow('', array('class="td32" style="text-align:right;"', '', 'class="td32"', ''), array(
							$admin_timulist_video_tip,"<input type='text' name='videourl' value='{$row[video]}' style='width:300px;'/>"
					));
		}
		
		showtablerow('', array('class="td25"', 'class="td28"'), array("<input id='submit' class='btn' type='submit' value='$admin_common_submit'  name='submit'>"));  		
		
}

function updateDanxuan($edit)
{
	$ask = trim(daddslashes($_POST['ask']));
	$option1 = trim(daddslashes($_POST['option1']));
	$option2 = trim(daddslashes($_POST['option2']));
	$option3 = trim(daddslashes($_POST['option3']));
	$option4 = trim(daddslashes($_POST['option4']));
	$option5 = trim(daddslashes($_POST['option5']));
	$option6 = trim(daddslashes($_POST['option6']));
	$option7 = trim(daddslashes($_POST['option7']));
	$answer = trim(daddslashes($_POST['answer']));
	$imageurl = trim(daddslashes($_POST['imageurl']));
	$videourl = trim(daddslashes($_POST['videourl']));
	$answer_parser = trim(daddslashes($_POST['answer_parser']));
	$score = trim(daddslashes($_POST['score']));
	$viewParser_credits = trim(intval($_POST['viewParser_credits']));
	
	DB::update('tpexam_tiku_danxuan', array('ask' => $ask,
	'score'=>$score,
	'option1'=>$option1,
	'option2'=>$option2,
	'option3'=>$option3,
	'option4'=>$option4,
	'option5'=>$option5,
	'option6'=>$option6,
	'option7'=>$option7,
	'answer'=>$answer,
	'image'=>$imageurl,
	'video'=>$videourl,
	'answer_parser'=>$answer_parser,
	'viewParser_credits'=>$viewParser_credits,
	), "id=$edit");
	
$option = array($option1,$option2,$option3,$option4,$option5,$option6,$option7);
$tikuid = DB::result_first("SELECT eid FROM ".DB::table('tpexam_tiku_danxuan')." WHERE id='$edit'");

DB::update('tpexam_tiku', array('subject' => $ask,
	'score'=>$score,
	'option'=>implode("\r\n",$option),
	'result'=>$answer,
	'image'=>$imageurl,
	'parser'=>$answer_parser,
	'viewParser_credits'=>$viewParser_credits,
	), "id='$tikuid'");
}

function updateDuoxuan($edit)
{
	$ask = trim(daddslashes($_POST['ask']));
	$option1 = trim(daddslashes($_POST['option1']));
	$option2 = trim(daddslashes($_POST['option2']));
	$option3 = trim(daddslashes($_POST['option3']));
	$option4 = trim(daddslashes($_POST['option4']));
	$option5 = trim(daddslashes($_POST['option5']));
	$option6 = trim(daddslashes($_POST['option6']));
	$option7 = trim(daddslashes($_POST['option7']));
	$imageurl = trim(daddslashes($_POST['imageurl']));
	$score = trim(daddslashes($_POST['score']));
	$viewParser_credits = trim(intval($_POST['viewParser_credits']));
	
	$answer = $_GET['answer'];

	DB::update('tpexam_tiku_duoxuan', array('ask' => $ask,
	'score'=>$score,
	'option1'=>$option1,
	'option2'=>$option2,
	'option3'=>$option3,
	'option4'=>$option4,
	'option5'=>$option5,
	'option6'=>$option6,
	'option7'=>$option7,
	'answer1'=>$answer[0],
	'answer2'=>$answer[1],
	'answer3'=>$answer[2],
	'answer4'=>$answer[3],
	'answer5'=>$answer[4],
	'answer6'=>$answer[5],
	'answer7'=>$answer[6],
	'image'=>$imageurl,
	'video'=>$videourl,
	'viewParser_credits'=>$viewParser_credits,
	), "id=$edit");
	
	$option = array($option1,$option2,$option3,$option4,$option5,$option6,$option7);
	$tikuid = DB::result_first("SELECT eid FROM ".DB::table('tpexam_tiku_duoxuan')." WHERE id='$edit'");

	DB::update('tpexam_tiku', array('subject' => $ask,
	'score'=>$score,
	'option'=>implode("\r\n",$option),
	'result'=>$answer[0].$answer[1].$answer[2].$answer[3].$answer[4].$answer[5].$answer[6],
	'image'=>$imageurl,
	'parser'=>$answer_parser,
	'viewParser_credits'=>$viewParser_credits,
	), "id='$tikuid'");
}

function updatePanduan($edit)
{
	$ask = trim(daddslashes($_POST['ask']));
	$answer = trim(daddslashes($_POST['answer']));
	$imageurl = trim(daddslashes($_POST['imageurl']));
	$score = trim(daddslashes($_POST['score']));
	$viewParser_credits = trim(intval($_POST['viewParser_credits']));
	
	DB::update('tpexam_tiku_panduan', array('ask' => $ask,'answer'=>$answer,
	'score'=>$score,
	'image'=>$imageurl,
	'video'=>$videourl,
	'viewParser_credits'=>$viewParser_credits,
	), "id=$edit");	
}

function updateTiankong($edit)
{
	$ask = trim(daddslashes($_POST['ask']));
	$answer = trim(daddslashes($_POST['answer']));
	$image = trim(daddslashes($_POST['image']));
	$videourl = trim(daddslashes($_POST['videourl']));
	$score = trim(daddslashes($_POST['score']));
	$answer_parser = trim(daddslashes($_POST['answer_parser']));
	$viewParser_credits = trim(intval($_POST['viewParser_credits']));

	DB::update('tpexam_tiku_tiankong', array('ask' => $ask,
	'score'=>$score,
	'answer'=>$answer,
	'image'=>$image,
	'video'=>$videourl,
	'answer_parser'=>$answer_parser,
	'viewParser_credits'=>$viewParser_credits,
	), "id=$edit");		
}

function updateWenda($edit){
	$ask = trim(daddslashes($_POST['ask']));
	$answer = trim(daddslashes($_POST['answer']));
	$imageurl = trim(daddslashes($_POST['imageurl']));
	$score = trim(daddslashes($_POST['score']));
	$viewParser_credits = trim(intval($_POST['viewParser_credits']));

	DB::update('tpexam_tiku_wenda', array('ask' => $ask,
	'score'=>$score,
	'answer'=>$answer,
	'image'=>$imageurl,
	'video'=>$videourl,
	'viewParser_credits'=>$viewParser_credits,
	), "id=$edit");		
}

function updatePeiwu($edit){
	$ask = trim(daddslashes($_POST['ask']));
	$answer = trim(daddslashes($_POST['answer']));
	$imageurl = trim(daddslashes($_POST['imageurl']));
	
	DB::update('tpexam_tiku_peiwu', array('ask' => $ask,
	'score'=>$score,
	'answer'=>$answer,
	'image'=>$imageurl,
	'video'=>$videourl
	), "id=$edit");		
}

function updateYuedu($edit){
	$ask = trim(daddslashes($_POST['ask']));
	$imageurl = trim(daddslashes($_POST['imageurl']));
	
	DB::update('tpexam_tiku_yuedulijie', array('ask' => $ask,
	'score'=>$score,
	'image'=>$imageurl,
	'video'=>$videourl
	), "id=$edit");		
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>