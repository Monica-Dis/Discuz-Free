<?php 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$opactives['order'] = 'class="a"';
require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/tp_exam.func.php';

if(empty($_G['gp_closeorder']) && empty($_G['gp_receorder'])) {
	$filter = trim($_G['gp_filter']);
	$filter = in_array($filter, array('all', 'alpay')) ? $filter : 'all';
 if($filter == 'alpay'){
		$actives['alpay'] = 'class="a"';
		$sqladd = 'and order_state = 1';
	}else if($filter == 'nopay'){
		$actives['nopay'] = 'class="a"';
		$sqladd = 'and order_state = 0';
		
	}else{
		$actives['all'] = 'class="a"';
	}
	
	$admin_record_addition = lang('plugin/tp_exam', 'admin_record_addition');
	
	$page = intval($_G['page']);
	if(empty($page)) $page=1;
	
	$pagenum = 10;
	$limit_start = $pagenum * ($page - 1);
	$totalnum = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_examrecord')." where uid = '$_G[uid]'");
	
	$list = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_examrecord')." where uid = '$_G[uid]' Order By date DESC LIMIT $limit_start,$pagenum");

	while($row = DB::fetch($query)){
	$exam_type = GetExamByPaperID($row['exam_type']);
	$row['subject'] = $exam_type['name'];
	
		$row['examtime'] = dgmdate($row['date']);
		$row['score'] = $row['score'];
		$row['usetime'] = $row['usetime'];
		$row['exam_type'] = $row['exam_type'];
		$row['addition'] = GetAddition($row['id']);
		$list[] = $row;
	}
	
	$multi = multi($totalnum, $pagenum, $page, "plugin.php?id=tp_exam:my&page={$filter}");		
	
	include template('tp_exam:my_order');

}else if(!empty($_G['gp_closeorder'])){
	$orderid = trim($_G['gp_orderid']);
	DB::update('tp_exam', array('status' => '2'), "uid = '$_G[uid]' and orderid = '$orderid'");
	
	echo 'true';
}else if(!empty($_G['gp_receorder'])){
	$orderid = trim($_G['gp_orderid']);
	DB::update('tp_exam', array('status' => '7'), "uid = '$_G[uid]' and orderid = '$orderid'");
	
	echo 'true';
}

function GetAddition($rid)
{
	$list = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_useranswer')." where belongrecord = '$rid'");
	while($row = DB::fetch($query)){
		return $row['addition'];
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>