<?php 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!submitcheck('submit')) {
	
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
	$type = GetPaperType();
	
	foreach($type as $k=>$v)
	{
		$examtype[]=$v['name'];
	}
	
	$filter = trim($_G['gp_app']);
	$filter = in_array($filter, array('all','favorite','pubexam', 'alpay')) ? $filter : 'all';
 if($filter == 'alpay'){
		$actives['alpay'] = 'class="a"';
		$sqladd = 'and order_state = 1';
	}else if($filter == 'nopay'){
		$actives['nopay'] = 'class="a"';
		$sqladd = 'and order_state = 0';
		
	}else if($filter == 'all'){
		$actives['all'] = 'class="a"';
	}
	else if($filter == 'favorite'){
		$opactives['order']='';
		$opunactives['order'] = 'class="a"';
	}
	else if($filter == 'pubexam'){
		$opactives['order']='';
		$opunactives['order'] = '';
		$opactives['tuan'] = 'class="a"';
	}
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='single_five'");
	$single_five = $skey['single_five'];
	
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='support_g'");
	$support_g_permission = $skey;
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='support_g'");
	$support_g = $skey;


	$admin_pub_type1 = lang('plugin/tp_exam', 'admin_pub_type1');
	$admin_pub_type2 = lang('plugin/tp_exam', 'admin_pub_type2');
	$admin_pub_type3 = lang('plugin/tp_exam', 'admin_pub_type3');
	$admin_pub_type4 = lang('plugin/tp_exam', 'admin_pub_type4');
	$admin_pub_type5 = lang('plugin/tp_exam', 'admin_pub_type5');
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='tiankong_p'");
	$tiankong_p = $skey['tiankong_p'];
	if($tiankong_p!=1){$admin_pub_type5 = 'NULL';}
	
	$timu_type=array($admin_pub_type1,$admin_pub_type2,$admin_pub_type3,$admin_pub_type4,$admin_pub_type5);
	
	$exam_timu_backup = lang('plugin/tp_exam', 'exam_timu_backup');
	$exam_timu_corrent = lang('plugin/tp_exam', 'exam_timu_corrent');
	$exam_timu_yes = lang('plugin/tp_exam', 'exam_timu_yes');
	$exam_timu_no = lang('plugin/tp_exam', 'exam_timu_no');
	$exam_timu_wenda_tips = lang('plugin/tp_exam', 'exam_timu_wenda_tips');
	$exam_timu_tiankong_tips1 = lang('plugin/tp_exam', 'exam_timu_tiankong_tips1');
	$exam_timu_tiankong_tips2 = lang('plugin/tp_exam', 'exam_timu_tiankong_tips2');
	$exam_timu_tiankong_tips3 = lang('plugin/tp_exam', 'exam_timu_tiankong_tips3');
	
	include template("tp_exam:my_pubexam");

}
else if(submitcheck('submit')){
	$timu_type = daddslashes($_GET['timutype']);

	switch($timu_type)
	{
		case 0:
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/single_select.inc.php";
		break;
		case 1:
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/multi_select.inc.php";
		break;
		case 2:
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/panduan.inc.php";
		break;
		case 3:
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/wenda.inc.php";
		break;
		case 4:
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tiankong.inc.php";
		break;
	}
	

	showmessage(lang('plugin/tp_exam', 'admin_common_success'), "plugin.php?id=tp_exam:my&app=pubexam", 'succeed');

}
//From: di'.'sm.t'.'aoba'.'o.com
?>