<?php 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!submitcheck('submit')) {
	
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
	$type = GetPaperType();
	
	foreach($type as $k=>$v)
	{
		$examtype[]=$v['name'];
	}
	
	$filter = trim($_G['gp_app']);
	$filter = in_array($filter, array('all','favorite','pubexam', 'paper_pub','alpay')) ? $filter : 'all';
 if($filter == 'alpay'){
		$actives['alpay'] = 'class="a"';
		$sqladd = 'and order_state = 1';
	}else if($filter == 'nopay'){
		$actives['nopay'] = 'class="a"';
		$sqladd = 'and order_state = 0';
		
	}else if($filter == 'all'){
		$actives['all'] = 'class="a"';
	}
	else if($filter == 'favorite'){
		$opactives['order']='';
		$opunactives['order'] = 'class="a"';
	}
	else if($filter == 'pubexam'){
		$opactives['order']='';
		$opunactives['order'] = '';
		$opactives['tuan'] = 'class="a"';
	}
	else if($filter == 'paper_pub'){
		$opactives['order']='';
		$opunactives['order'] = '';
		$opactives['paper_pub'] = 'class="a"';
	}
	
	$admin_exam_paper_name = lang('plugin/tp_exam', 'admin_exam_paper_name');

	$admin_exam_mustlogin = lang('plugin/tp_exam','admin_exam_mustlogin');
	$admin_belongtype = lang('plugin/tp_exam','admin_belongtype');
	$admin_exam_time = lang('plugin/tp_exam','admin_exam_time');
	$admin_view_show_answer = lang('plugin/tp_exam','admin_view_show_answer');
	$admin_view_paper_info = lang('plugin/tp_exam','admin_view_paper_info');
	$admin_paper_rand_mode = lang('plugin/tp_exam','admin_paper_rand_mode');
	$admin_practise_mode = lang('plugin/tp_exam','admin_practise_mode');
	$home_credits_buy_paper = lang('plugin/tp_exam','home_credits_buy_paper');


	include template("tp_exam:my_paper_pub");

}
else if(submitcheck('submit')){
			$papername = daddslashes($_GET['papername']);
			$paperlelong = daddslashes($_GET['paperlelong']);
			$papertime = daddslashes($_GET['papertime']);
			$papershowanswer = daddslashes($_GET['papershowanswer']);
			$paperinfo = daddslashes($_GET['paperinfo']);
			$paperrandmode = daddslashes($_GET['paperrandmode']);
			$paperbuycredits = daddslashes($_GET['paperbuycredits']);
			$paperpractisemode = daddslashes($_GET['paperpractisemode']);
			$admin_exam_mustlogin = daddslashes($_GET['admin_exam_mustlogin']);
			


			$auditing = 1;
			$uid = $_G['uid'];

		if(!empty($papername)) {
				$inserts[] = "('', '$paperlelong','$papername','','$papertime','$admin_exam_mustlogin','$paperpractisemode','$paperrandmode','$papershowanswer','$paperinfo','$auditing','$uid')";
				
				DB::query("INSERT INTO ".DB::table('tpexam_paper')." (id , belong,name, shorturl ,papertime,needlogin,practise,rand,showanswer,paperinfo,auditing ,pubuid) VALUES ".implode(',',$inserts));

			}
			
		showmessage(lang('plugin/tp_exam', 'admin_common_success'), "plugin.php?id=tp_exam:my&app=paper_pub", 'succeed');

}

 ?>