<?php 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/tp_exam.func.php';

if(empty($_G['gp_closeorder']) && empty($_G['gp_receorder'])) {
	$filter = trim($_G['gp_app']);
	$filter = in_array($filter, array('all','favorite', 'mytimu','alpay')) ? $filter : 'all';
 if($filter == 'mytimu'){
		$opactives['mytimu']='class="a"';
	}
	$page = intval($_G['page']);
	if(empty($page)) $page=1;
	
	$pagenum = 10;
	$limit_start = $pagenum * ($page - 1);
	$totalnum = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_favorite')." where uid = '$_G[uid]'");
	
	$list = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_favorite')." where uid = '$_G[uid]' Order By date DESC LIMIT $limit_start,$pagenum");
	
	
	while($row = DB::fetch($query)){
		$exam_type = GetExamByPaperID($row['favorite_belongpaper']);
		$row['subject'] = $exam_type['name'];
		$row['date'] = dgmdate($row['date']);
		$list[] = $row;
	}
	
	$multi = multi($totalnum, $pagenum, $page, "plugin.php?id=tp_exam:my&filter={$filter}");
			
	
	include template('tp_exam:mytimu');

}else if(!empty($_G['gp_closeorder'])){
	$orderid = trim($_G['gp_orderid']);
	DB::update('tp_exam', array('status' => '2'), "uid = '$_G[uid]' and orderid = '$orderid'");
	
	echo 'true';
}else if(!empty($_G['gp_receorder'])){
	$orderid = trim($_G['gp_orderid']);
	DB::update('tp_exam', array('status' => '7'), "uid = '$_G[uid]' and orderid = '$orderid'");
	
	echo 'true';
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>