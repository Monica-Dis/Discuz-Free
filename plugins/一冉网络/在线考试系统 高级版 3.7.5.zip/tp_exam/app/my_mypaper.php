<?php 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$opactives['order'] = '';
require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/tp_exam.func.php';

if(empty($_G['gp_closeorder']) && empty($_G['gp_receorder'])) {
	$filter = trim($_GET['app']);
	$filter = in_array($filter, array('all','favorite', 'mypaper','alpay')) ? $filter : 'all';

	$admin_exam_timulist_pubname = lang('plugin/tp_exam','admin_exam_timulist_pubname');
	$opactives['mypaper']='class="a"';
	
	$page = intval($_G['page']);
	if(empty($page)) $page=1;
	
	$pagenum = 10;
	$limit_start = $pagenum * ($page - 1);
	$totalnum = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_paper')." where pubuid = $_G[uid]");
	
	$list = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where pubuid = '$_G[uid]'");
	
	while($row = DB::fetch($query)){

		$row['date'] = dgmdate($row['date']);
		$list[] = $row;
	}
	
	$multi = multi($totalnum, $pagenum, $page, "plugin.php?id=tp_exam:my&filter={$filter}");
			
	
	include template('tp_exam:mypaper');

}else if(!empty($_G['gp_closeorder'])){
	$orderid = trim($_G['gp_orderid']);
	DB::update('tp_exam', array('status' => '2'), "uid = '$_G[uid]' and orderid = '$orderid'");
	
	echo 'true';
}else if(!empty($_G['gp_receorder'])){
	$orderid = trim($_G['gp_orderid']);
	DB::update('tp_exam', array('status' => '7'), "uid = '$_G[uid]' and orderid = '$orderid'");
	
	echo 'true';
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>