<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if(!submitcheck('submit')) {
	
	$examedid = daddslashes($_GET['examedid']);
	
	$admin_pub_type1 = lang('plugin/tp_exam', 'admin_pub_type1');
	$admin_pub_type2 = lang('plugin/tp_exam', 'admin_pub_type2');
	$admin_pub_type3 = lang('plugin/tp_exam', 'admin_pub_type3');
	$admin_pub_type4 = lang('plugin/tp_exam', 'admin_pub_type4');
	$admin_pub_type5 = lang('plugin/tp_exam', 'admin_pub_type5');
	
	$answer = array();
	
	
	$sql = DB::query("SELECT * FROM ".DB::table('tpexam_useranswer')." where belongrecord = $examedid"); //��ÿ�������������Ծ�
	while($row = DB::fetch($sql)) {
		
		if(!empty($row['serializedata'])){
			$uanswer = unserialize($row['serializedata']);
			$answer=array();
			foreach($uanswer as $k=>$val){
				if(!$row['source']){
					$val = get_object_vars($val);
				}
				$answer[] = $val;
			}
			$opactives['order'] = 'class="a"';
			
			include template("tp_exam:my_answer");
			exit;
		}else{
			$valarr = array();
			$valarr[] = $row['id'];
			$valarr[] = getuseranswer($user_answer,'danxuan');
			$valarr[] = getuseranswer($user_answer,'duoxuan');
			$valarr[] = getuseranswer($user_answer,'panduan');
			$valarr[] = getuseranswer($user_answer,'tiankong');
			$valarr[] = getuseranswer($user_answer,'wenda');
			$valarr[] = '<input type="text" size="5" value="'.$row['addition'].'" name="addition['.$user_answer.']">';
			$valarr[] = "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_examrecord&useranswer=".$row['id']."&delanswer=".$row['id']."\">".$admin_common_delete."</a>";
			showtablerow('id="td_'.$row['id'].'"', array('class="td25"','class="td35"', 'class="td35"','class="td35"','','','',''), $valarr);
			unset($valarr);
		}
	}
	
	include template("tp_exam:my_answer");
	

}
else if(submitcheck('submit')){
	
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>