<?php

/*
�ɼ���ѯģ��
20150205
��Ȩ���У�����ؾ�
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/tp_exam.func.php';

if(!submitcheck('submit')){
	$opactives['scorequery'] = 'class="a"';
	include template('tp_exam:my_scorequery');
}
else{
	
	$admin_common_success = lang('plugin/tp_exam', 'admin_common_success');
	$admin_exam_paper_name = lang('plugin/tp_exam', 'admin_exam_paper_name');
	$admin_exam_time = lang('plugin/tp_exam', 'admin_exam_time');
	$admin_exam_record_score = lang('plugin/tp_exam', 'admin_exam_record_score');

	$q = daddslashes($_POST['q']);
	$record = GetRecord($q);
	$opactives['scorequery'] = 'class="a"';
	
	include template('tp_exam:my_scorequery');
	
}


function GetRecord($q){
	$uid = 0;
	$record=array();
	
	$admin_pub_type1 = lang('plugin/tp_exam', 'admin_pub_type1');
	$admin_pub_type2 = lang('plugin/tp_exam', 'admin_pub_type2');
	$admin_pub_type3 = lang('plugin/tp_exam', 'admin_pub_type3');
	$admin_pub_type4 = lang('plugin/tp_exam', 'admin_pub_type4');
	$admin_pub_type5 = lang('plugin/tp_exam', 'admin_pub_type5');
	$admin_pub_type6 = lang('plugin/tp_exam', 'admin_pub_type6');
	$admin_pub_type7 = lang('plugin/tp_exam', 'admin_pub_type7');

	$type_arr=array($admin_pub_type1,$admin_pub_type2,$admin_pub_type3,$admin_pub_type4,$admin_pub_type5,$admin_pub_type6,$admin_pub_type7);
	
	
	$query = DB::query("SELECT * FROM ".DB::table('common_member'). " where username='$q'");
	while($row = DB::fetch($query)) {
		$uid = $row['uid'];
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_examrecord'). " where uid='$uid'");
	while($row = DB::fetch($query)) {

		$exam_type = GetExamByPaperID($row['exam_type']);
		$row['papername'] = $exam_type['name'];
		
		$record[] = $row;
	}
	
	
	return $record;
}
//From: di'.'sm.t'.'aoba'.'o.com
?>