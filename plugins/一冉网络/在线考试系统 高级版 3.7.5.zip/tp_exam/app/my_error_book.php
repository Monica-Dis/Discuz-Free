<?php

/*
���Ȿģ��
20150205
��Ȩ���У�����ؾ�
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

	require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/comb.func.inc.php';


	$error=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_errorbook')." where uid = '$_G[uid]' order by id desc");
	while($data = DB::fetch($query))
	{
		$error[] = $data;
	}

	require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/tp_exam.func.php';
	
	if(!submitcheck('submit')){
		
	
	$admin_pub_type1 = lang('plugin/tp_exam', 'admin_pub_type1');
	$admin_pub_type2 = lang('plugin/tp_exam', 'admin_pub_type2');
	$admin_pub_type3 = lang('plugin/tp_exam', 'admin_pub_type3');
	$admin_pub_type4 = lang('plugin/tp_exam', 'admin_pub_type4');
	$admin_pub_type5 = lang('plugin/tp_exam', 'admin_pub_type5');
	$admin_pub_type6 = lang('plugin/tp_exam', 'admin_pub_type6');
	$admin_pub_type7 = lang('plugin/tp_exam', 'admin_pub_type7');
	$admin_common_delete = lang('plugin/tp_exam', 'admin_common_delete');
	
	$admin_common_submit = lang('plugin/tp_exam', 'admin_common_submit');
	
	$timu  = lang('plugin/tp_exam', 'timu');
	$type_arr=array($admin_pub_type1,$admin_pub_type2,$admin_pub_type3,$admin_pub_type4,$admin_pub_type5,$admin_pub_type6,$admin_pub_type7);
	
	$opactives['error_book'] = 'class="a"';
	


	$page = intval($_G['page']);
	if(empty($page)) $page=1;
	
	$pagenum = 6;
	$limit_start = $pagenum * ($page - 1);
	
	$limit_end = $limit_start + $pagenum ;
	$totalnum = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_tiku_errorbook')." where uid = '$_G[uid]'");
	
	$list = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_errorbook')." where uid = '$_G[uid]' Order By id desc limit $limit_start,$limit_end ");


	while($row = DB::fetch($query)){
		$exam_type = GetExamByPaperID($row['paperid']);
		$row['errordata'] = dgmdate($row['errordata']);
		$row['errortypedesc'] = GetTypeDesc($row['tikuid'],$type_arr);
		$row['timu'] = GetSubjectById($row['tikuid'],30);
		$row['paperid'] = GetPaperName($row['paperid']);
		$list[] = $row;
	}
	
	//print_r($list);
	
	$multi = multi($totalnum, $pagenum, $page, "plugin.php?id=tp_exam:my&app=error_book");
	
	include template('tp_exam:my_error_book');
	
}
else{
	$admin_common_success = lang('plugin/tp_exam', 'admin_common_success');
	
	$newids = array();
	$delarr = daddslashes($_POST['delete']);
	$retryall = daddslashes($_POST['retryall']);

	if($retryall==1){

		$TimerEvent = 0;
		$item = 1;
		$paper_no_pause = 1;
		$user_center_error_book = lang('plugin/tp_exam','user_center_error_book');
		$exam['name'] = $user_center_error_book;
		$dan_arr=array();
		
		foreach($delarr as $key=>$errorid) {
			if($errorid > 0){
			
			$tikuid = DB::result_first("SELECT tikuid FROM ".DB::table('tpexam_tiku_errorbook')." WHERE id='$errorid'");
			
			$tid = DB::result_first("SELECT tid FROM ".DB::table('tpexam_tiku')." WHERE id='$tikuid'");
			$oid = DB::result_first("SELECT oid FROM ".DB::table('tpexam_tiku')." WHERE id='$tikuid'");

			if($tid > 0 ){
				
				switch($tid){
				case 1:
					$danxuan[] = GetDanxuanById($oid);break;
				case 2:
					$duoxuan[] = GetDuoXuanById($oid);break;
				case 3:
			  	$panduan[] = GetPanduanById($oid);break;
				case 4:$tiankong[] = GetTiankongById($oid);break;
				case 5:$wenda[]=GetWendaById($oid);break;
				}
				
			}
			
			
		}
	}
		
		include template('tp_exam:exam');
	}
	else{
		foreach($delarr as $id=>$v) 
		{

					DB::delete('tpexam_tiku_errorbook', "id IN($v)");


		}
		showmessage(lang('plugin/tp_exam', 'admin_common_success'), 'plugin.php?id=tp_exam:my&app=error_book');
	}
	
	
	
}
function GetTypeDesc($tikuid,$type_arr)
{
	$type = DB::result_first("select tid from ".DB::table('tpexam_tiku')." where id = '$tikuid'");
	
	switch($type)
	{
		case 1:
			return $type_arr[0];
		break;
		case 2:
			return $type_arr[1];
		break;
		case 3:
			return $type_arr[2];
		break;
		case 5:
			return $type_arr[3];
		break;
		case 4:
			return $type_arr[4];
		break;
		case 6:
			return $type_arr[5];
		case 7:
			return $type_arr[6];
	}
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>