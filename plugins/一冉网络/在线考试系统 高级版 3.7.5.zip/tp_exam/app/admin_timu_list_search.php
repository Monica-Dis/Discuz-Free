<?php


	if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
	}
	
	
	showformheader("plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list&app=search", 'order_submit');
	showtableheader();

	$admin_exam_timulist_type = lang('plugin/tp_exam', 'admin_exam_timulist_type');
	$timu = lang('plugin/tp_exam', 'timu');
	$admin_exam_timulist_paper = lang('plugin/tp_exam', 'admin_exam_timulist_paper');
	$admin_exam_timulist_score = lang('plugin/tp_exam', 'admin_exam_timulist_score');
	$admin_exam_timulist_pubtime = lang('plugin/tp_exam', 'admin_exam_timulist_pubtime');
	$admin_exam_timulist_pubname = lang('plugin/tp_exam', 'admin_exam_timulist_pubname');
	$admin_common_op = lang('plugin/tp_exam', 'admin_common_op');
	$admin_common_delete = lang('plugin/tp_exam', 'admin_common_delete');
	$admin_common_edit = lang('plugin/tp_exam', 'admin_common_edit');
	$type_arr=array($admin_pub_type1,$admin_pub_type2,$admin_pub_type3,$admin_pub_type4,$admin_pub_type5,$admin_pub_type6,$admin_pub_type7);
	
if($searchtype == 1){
		$paper = DB::fetch_first("SELECT * FROM ".DB::table('tpexam_paper')." where name = '$ukey' order by id asc");
		if(is_array($paper) && empty($paper)){
			cpmsg('&#x8BD5;&#x5377;&#x672A;&#x627E;&#x5230;', 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_timu_list', 'succeed');
			die();
		}
		showtitle('&nbsp;'.$totalnum);
		showsubtitle(array('id',$admin_exam_timulist_type,$timu,$admin_exam_timulist_paper,$admin_exam_timulist_score,$admin_exam_timulist_pubtime,$admin_exam_timulist_pubname,"<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list&item=all&&type=all&del=all\">".$admin_common_delete."</a>",$admin_common_op));
	
		$paperid = $paper['id'];

		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku')." where paperid = '$paperid' order by id asc");
	
	while($data = DB::fetch($query))
	{
		$ret[] = $data;
		unset($timu);
	}
	
}else{
	showtitle('&nbsp;'.$totalnum);
	showsubtitle(array('id',$admin_exam_timulist_type,$timu,$admin_exam_timulist_paper,$admin_exam_timulist_score,$admin_exam_timulist_pubtime,$admin_exam_timulist_pubname,"<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list&item=all&&type=all&del=all\">".$admin_common_delete."</a>",$admin_common_op));
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku')." where subject like '%".$ukey."%' order by id asc");
	
	while($data = DB::fetch($query))
	{
		$ret[]  = $data;
		unset($timu);
	}
}

		
	
	//��ҳ��Ϣ��ʼ
	$perpage = 15;
	$page = max(1, intval(daddslashes($_GET['page'])));
	$listStart = ($page-1) *$perpage;
	$listEnd = $page*$perpage;
	
	$tiKu = $ret;

	$where = '';
	$totalnum = count($tiKu);

	$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 

	$multi = multi($totalnum, $perpage, $page, ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list",$pagecount);
	
	GetPageList_new($tiKu,$totalnum, $listStart, $listEnd);
	
	showsubmit('submit', 'submit', 'del', '', $multi);
	
	showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
	showformfooter(); /*dism��taobao��com*/


function  GetPageList_new($tiKu,$totalnum, $listStart, $listEnd){

	if($listEnd > $totalnum){
		$listEnd = $totalnum;
	}
	for($i=$listStart;$i<$listEnd;$i++){
		GetSingleRow_new($tiKu,$i);
	}
}

function GetSingleRow_new($tiKu,$i){
		global $type_arr;
		$row = $tiKu[$i];
		
		global $admin_common_delete ;
		global $admin_common_edit ;
	
		$valarr = array();
		$valarr[] = "<input type='checkbox' name='delete[]' value='$row[id]_$row[type]'/>[ID:$row[id]]";
		$valarr[] = GetTypeByTid($row['tid']);
		$valarr[] = cutstr($row['subject'],30,"...");
		$valarr[] = GetPaperName($row['paperid']);
		$valarr[] = $row['score'];
		$valarr[] = date('Y-m-d G:i:s',$row['data']);
		$valarr[] = $row['publish_uid'];
		$valarr[] = "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list&del=".$row['oid']."&type=".GetTypeByTid($row['tid'])."\">".$admin_common_delete."</a>";
		$valarr[] = "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list&edit=".$row['oid']."&type=".GetTypeByTid($row['tid'])."\">".$admin_common_edit."</a>";
		showtablerow('id="td_'.$row['id'].'"', array('class="td45" style="width:120px;"','class="td35"', 'class="td35"','class="td35"','',''), $valarr);
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>