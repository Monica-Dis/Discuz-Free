<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
	
	$company = daddslashes($_POST['company']);
	$name = daddslashes($_POST['name']);
	$needpay = daddslashes($_GET['needpay']);
	$payment = GetPaymentInfo();
	$unseri_pay = unserialize($payment['svalue']);

	$product = GetExamByPaperID($needpay);
	
	$subject    = $product['name'];
	$body    = '';
	$total_fee    = $product['money'];
	$seller_email = $unseri_pay['alipayuser'];

	//$return_url    = $_GET['return_url'];
	//$credit    = $_GET['credit'];
	$uid    = $_G['uid'];
	$notify_url    = trim($_GET['notify_url']);
	
	if(!submitcheck('submit')) {

 	$partner = $unseri_pay['alipayid'];
	$appid = $unseri_pay['tenpayid'];
	$yibaoid = $unseri_pay['yibaoid'];
	
	$express = lang('plugin/tp_tuangou', 'buy_post_come');
	$buy_success_tips = lang('plugin/tp_exam', 'buy_success_tips');
	$buy_fail_jifen_tips = lang('plugin/tp_exam', 'buy_fail_jifen_tips');
	
	$express_fee = 0;
	
	$pay_must_select_one = lang('plugin/tp_exam', 'exam_pay_must_select_one');;
	include template('tp_exam:pay');
}
else
{
	$paytype = daddslashes($_POST['paytype']);
	
		if($paytype == 'alipay')
		{
			$partner = $unseri_pay['alipayid'];
			$key = $unseri_pay['alipaykey'];
			$seller_email = $unseri_pay['alipayuser'];
		
			//ͬ��ҳ�����
			$url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];
			$return_url = dirname($url).'/source/plugin/tp_exam/payment/return_url.php';
					
		
				if($_G['charset'] == 'utf-8')
				{
					$p1 = iconv('utf-8', 'gbk', $subject);
					$p2 = iconv('utf-8', 'gbk', $body);
				}
				else
				{
					$p1 =  $subject;
					$p2 =  $body;
				}
				
			//�жϽӿ�����
			if($unseri_pay['alipaytype'] == 1)
			{
				$url =  'source/plugin/tp_exam/payment/alipayto.php?subject='.urlencode($p1).'&body='.urlencode($p2).'&total_fee='.$order_info['totalprice'].'&partner='.$partner.'&key='.$key.'&seller_email='.$seller_email.'&return_url='.$return_url.'&buy_num='.$buy_num.'&item='.$item.'&paysn='.$paysn;
				header('Location:'.$url);
			}
			else if($unseri_pay['alipaytype'] == 2)
			{
				$subdir = dirname($_SERVER["REQUEST_URI"]);
				if($subdir == "" || strlen($subdir) == 1)
				{
					$notify_url = 'http://'.$_SERVER['SERVER_NAME'].'/source/plugin/tp_exam/payment/alipaysubmit/notify_url.php';
					$return_url = 'http://'.$_SERVER['SERVER_NAME'].'/source/plugin/tp_exam/payment/alipaysubmit/return_url.php';
				}
				else
				{
					$notify_url = 'http://'.$_SERVER['SERVER_NAME'].$subdir.'/source/plugin/tp_exam/payment/alipaysubmit/notify_url.php';
					$return_url = 'http://'.$_SERVER['SERVER_NAME'].$subdir.'/source/plugin/tp_exam/payment/alipaysubmit/return_url.php';
				}
				$url =  'source/plugin/tp_exam/payment/alipaysubmit/alipaySubmit.php?subject='.urlencode($p1).'&body='.urlencode($p2).'&total_fee='.$total_fee.'&return_url='.$return_url.'&notify_url='.$notify_url.'&seller_email='.$seller_email.'&buy_num='.$buy_num.'&item='.$item.'&paysn='.$paysn;
				header('Location:'.$url);
			}
			else if($unseri_pay['alipaytype'] == 3)
			{
				$return_url = dirname($url).'/source/plugin/tp_exam/payment/alipaydual/return_url.php';
				$url =  'source/plugin/tp_exam/payment/alipaydual/alipaydual.php?WIDseller_email='.$seller_email.'&WIDout_trade_no='.$order_info['order_id'].'&WIDsubject='.urlencode($p1).'&WIDprice='.$order_info['totalprice'].'&WIDbody='.urlencode($p2).'&WIDshow_url='.'&WIDreceive_name='.$order_info[''].'&WIDreceive_address='.$p2.'&WIDreceive_phone='.$order_info['phone'].'&WIDreceive_mobile='.$order_info['phone'].'&partner='.$partner.'&key='.$key.'&return_url='.$return_url.'&buy_num='.$buy_num.'&item='.$item;
				header('Location:'.$url);
			}

		}

}
//From: di'.'sm.t'.'aoba'.'o.com
?>