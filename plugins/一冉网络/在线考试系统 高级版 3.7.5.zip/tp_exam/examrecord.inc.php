<?php


if (!defined('IN_DISCUZ')  ) {
    exit('Access Denied');
}


$formhash = daddslashes($_GET['formhash']);
$data = daddslashes($_GET['data']);
$paperid = intval($_GET['paperid']);
$score = floatval($_GET['score']);
$vid = intval($_GET['vid']);

if(formhash()==$formhash){

	
	require_once libfile ( 'include/paperrecord','plugin/tp_exam' );
	
	$uid = $_G['uid'];
	
	$insert = savePaperRecord($uid,
	$paperid,
	0,
	TIMESTAMP,
	$score,
	$vid
	);

	$data = stripslashes($data);
	
	//echo $data;
	
	$json = json_decode($data);
	//$json = json_decode($_REQUEST['data'], true); 
	
	//echo print_r($json);
	
	$serialize = serialize($json);
	saveUserAnswerRecord($insert,'',$serialize);
	
	exit;
		
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>