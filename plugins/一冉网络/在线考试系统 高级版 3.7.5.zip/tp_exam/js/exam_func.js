	function checkPractise(types,obj)
	{
		var answer_cont = document.getElementById('answer-cont_'+types+'_'+obj);
		if(answer_cont)
		{
			var str = answer_cont.style.display;
			if(str == "none")
			{
				answer_cont.style.display = 'block';
			}
			else
			{
				answer_cont.style.display = 'none';
			}
		}
	}
