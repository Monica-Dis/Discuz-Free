var timer = null;
function hideUI()
{
		jQuery('#ln-guild-body').stop(false,true).animate({width: 'hide', opacity: 'hide'}, 'normal',function(){ jQuery('#ln-guild-body').hide(); });
	  jQuery('#ln-guild-body').attr('style','display:none');
	  jQuery('#ln-guild-handler').attr('style','display:block');
}
function showUI()
{
		jQuery('#ln-guild-handler').attr('style','display:none');
		jQuery('#ln-guild-body').stop(false,true).animate({width: 'show', opacity: 'show'}, 'normal',function(){ jQuery('#ln-guild-body').show(); });
	  jQuery('#ln-guild-body').attr('style','display:block');	
}
jQuery(document).ready(function(){
	jQuery('#ln-guild-handler').attr('style','display:none');
	jQuery("#ln-guild-handler").hover(function(){
		timer = setTimeout(function(){
			showUI();
    },2000);	
  },function(){
		clearTimeout(timer);
  });

});
