function addEventHandler(obj, eventName, fun, param){
	var fn = fun;
	if(param){
		fn = function(e)
		{
			fun.call(this, param);
		}
	}
	if(obj.attachEvent){
		obj.attachEvent('on'+eventName,fn);
	}else if(obj.addEventListener){
		obj.addEventListener(eventName,fn,false);
	}else{
		obj["on" + eventName] = fn;
	}
}

function $(id){
	var a = id.toString().split(':');
	if(a.length==2)
		return document.getElementById(a[0]).getElementsByTagName(a[1]);
	else 
		return document.getElementById(id);
}

function httpRequest(){
	var xmlHttp = false;
	if(window.XMLHttpRequest) {
		xmlHttp = new XMLHttpRequest();
		xmlHttp.overrideMimeType && xmlHttp.overrideMimeType('text/xml');
	}else if(window.ActiveXObject) {
		var versions = ['Microsoft.XMLHTTP', 'MSXML.XMLHTTP', 'Microsoft.XMLHTTP', 'Msxml2.XMLHTTP.7.0', 'Msxml2.XMLHTTP.6.0', 'Msxml2.XMLHTTP.5.0', 'Msxml2.XMLHTTP.4.0', 'MSXML2.XMLHTTP.3.0', 'MSXML2.XMLHTTP'];
		for(var i=0 in versions) {
			try {
				xmlHttp = new ActiveXObject(versions[i]);
				break;
			} catch(e) {/*alert(e.message);*/}
		}
	}
	return xmlHttp;
}

function ajaxget(url, callback){
	var xmlHttp = httpRequest();
	if(xmlHttp){
		xmlHttp.onreadystatechange = function(){
			if(xmlHttp.readyState == 4){
				if(xmlHttp.status == 200){
					if(typeof callback=="function"){
						callback(xmlHttp.responseText); 
					}
				}
			}
		};
		xmlHttp.open("get", url, true);
		xmlHttp.send(null);
	}
}
		
/*���ҳ��*/
function ding(the){the.className = the.className!='ding_on' ? 'ding_on' : 'ding_off';}

function cal_score(){
	var tds = $('nobox:td'), total = 0;
	for(var i = 0; i<tds.length; i++){
		var td = tds[i];		
		var type   = td.getAttribute('type');
		var result = td.getAttribute('result');
		var answer = td.getAttribute('answer');
		var eid   = td.getAttribute('eid');
		
		if(answer!=''){
			if(type<=3)
			{
				if(result==answer){
					total += parseFloat(td.getAttribute('score'));
					td.style.textDecoration = '';
					td.style.color = 'green';
					ajaxget('plugin.php?id=tp_exam:e'+'&errordata='+type+','+eid+'&item='+item+'&mode=1'+'&'+Math.random(), function(v){
					});
				}else{
					td.style.textDecoration = 'line-through';
					td.style.color = 'red';
					//��������
					ajaxget('plugin.php?id=tp_exam:e'+'&errordata='+type+','+eid+'&item='+item+'&mode=2'+'&'+Math.random(), function(v){
					});
				}
				
			}else if(type==4){
						var arr1 = answer.split(",");
						var arr2 = result.split("|");
						if(arr1.sort().toString() == arr2.sort().toString()){
							total += parseFloat(td.getAttribute('score'));
							td.style.textDecoration = 'none';
							td.style.color = '';
						}else{
							td.style.textDecoration = 'line-through';
							td.style.color = 'red';
							//��������
							ajaxget('plugin.php?id=tp_exam:e'+'&errordata='+type+','+eid+'&item='+item+'&'+Math.random(), function(v){
							});
						}
				
			}else{
					total += parseFloat(td.getAttribute('score'));
					td.style.textDecoration = 'none';
					td.style.color = '';
			}
		}
		else{
			td.style.textDecoration = 'line-through';
		}
	}
	return total;
}

function submit(){

	$('numbox').style.display='none';
	var sb = $('submitbox');
	sb.style.display = sb.style.display=='block' ? 'none' : 'block';

	var tds = $('nobox:td'), string = '', dot = '';
	for(var i = 0; i<tds.length; i++){
		var td = tds[i];
		var eid = td.getAttribute('oid');
		var type = td.getAttribute('type');
		string += dot + type + ',' + eid ;
		dot = ';';
	}

	ajaxget('plugin.php?id=tp_exam'+'&resultdata='+string+'&'+Math.random(), function(v){
		if(v[0]=='['){
			var R = eval( '(' + v + ')' );
			var tds = $('nobox:td');
			for(var i = 0; i<tds.length; i++){
				var td = tds[i],e=R[i];
				var type = td.getAttribute('type');
				td.setAttribute('result', e['result']);
				td.setAttribute('note', e['answer_parser']);
			}

			var total = cal_score();	
			var msg = "&#x6211;&#x7684;&#x5F97;&#x5206;: "+total+"&#x5206; &nbsp" + $('summary').innerText;

			$('showbox').outerHTML = msg;
			$('p_msg').style.display='block';
			
			submitpaper = 1;
			show_exam(eidArr[$('seek').innerHTML-1]);
			
			var item = $('paperid').getAttribute("value");
			var usetime = $('usetime').getAttribute("value");
			
			ajaxget('plugin.php?id=tp_exam&total='+total+'&item='+item+'&usetime='+usetime+'&'+Math.random(), function(v){
				
			});
			
		}else{
			alert('&#x65E0;&#x6743;&#x9650;&#x4EA4;&#x5377;');
		}
	});
}

function nv_click(mode)
{
	if(mode=='no'){
		$('submitbox').style.display='none';
		var nb = $('numbox');
		nb.style.display = nb.style.display=='block' ? 'none' : 'block';
	}
	else if(mode=='prev'){
		clearNote();
		$('submitbox').style.display='none'; 
		if(!submitpaper){
			$('p_msg').style.display='none';
		}
		var k = Math.max(1, parseInt($('seek').innerHTML)-1);
		show_exam(eidArr[k-1]);
		$('seek').innerHTML = k;
	}
	else if(mode=='next'){
		clearNote();
		$('submitbox').style.display='none';
		if(!submitpaper){
			$('p_msg').style.display='none';
		}
		var k = Math.min(eidArr.length, parseInt($('seek').innerHTML)+1);
		show_exam(eidArr[k-1]);
		$('seek').innerHTML = k;
	}				
}
function clearNote()
{
	$('p_note_image').innerHTML = '';
	$('p_note').innerHTML = '';
}

function elabel(eid, v)
{
	if($('p_msg').style.display=='block')
		return;
		
	var td   = $(eid);
	var type = td.getAttribute('type');
	var lis  = $('p_data:li');

	if(type==2){
		var str = '';
		for(var i=0;i<lis.length;i++){
			if(lis[i].getAttribute('value')==v){
				lis[i].className =  lis[i].className=='option_on' ? 'option_off' : 'option_on';
			}
			if(lis[i].className=='option_on')str += lis[i].getAttribute('value');
		}
		td.setAttribute('answer', str);
	}else{
		for(var i=0;i<lis.length;i++){
			lis[i].className = lis[i].getAttribute('value')==v ? 'check_on' : 'check_off';
		}
		td.setAttribute('answer', v);
	}
	td.style.color = 'blue';
}

var eidAnswer  = new Array();
var submitpaper=false;
function echange(obj,eid,order)
{
	var td   = $(eid);
	eidAnswer[order-1] = obj.value;
	var j = eidAnswer.join();
	td.setAttribute('answer', j);
}

function practise(rid)
{
	var td   = $(rid);
	var type = td.getAttribute('type');
	var eid = td.getAttribute('eid');
	
	ajaxget('plugin.php?id=tp_exam'+'&mod=pt&type='+type+'&eid='+eid+'&'+Math.random(), function(v){
	if(v[0]=='{'){
		var R = eval( '(' + v + ')' );
		td.setAttribute('result', R['result']);
		td.setAttribute('note', R['answer_parser']);
		$('p_msg').style.display='block';
		show_exam(rid);
	}
	});

}

var type_string = {1:'&#x5355;&#x9009;&#x9898;', 2:'&#x591A;&#x9009;&#x9898;', 3:'&#x5224;&#x65AD;&#x9898;', 4:'&#x586B;&#x7A7A;&#x9898;', 5:'&#x95EE;&#x7B54;&#x9898;'};

function show_exam(eid)
{

	var the    = $(eid);
	var type   = the.getAttribute('type');
	var score  = the.getAttribute('score');
	var result = the.getAttribute('result');
	var answer = the.getAttribute('answer');
	var subject= the.getAttribute('subject');
	var data   = the.getAttribute('data');
	var note   = the.getAttribute('note');
	var image  = the.getAttribute('image');
	var eeid  = the.getAttribute('eid');

	var parserimage  = the.getAttribute('parserimage');
	
	if(type==4){

		ajaxget('plugin.php?id=tpgao_m:m'+'&tk=1&eid='+eeid + '&as=' + answer + '&'+ Math.random(), function(v){
			subject = v;
			$('p_subject').innerHTML = '['+type_string[type] +'] '+ subject + '('+score+'&#x5206)';
			
		});
		
	}
	else
		$('p_subject').innerHTML = '['+type_string[type] +'] '+ subject + '('+score+'&#x5206)';
	
	if(image!="")
		$('p_image').innerHTML = '<img src="'+image+'" border=0>';
	else
		$('p_image').innerHTML = '';
	
	var datastr ='';
	var btnstr='';
	var bPass = false;
	if(type==3){

		datastr += '<li class="'+(answer==1?"check_on":"check_off")+'" value="1" onclick="elabel('+eid+', 1)">&#x6B63;&#x786E;</li>';
		datastr += '<li class="'+(answer==2?"check_on":"check_off")+'" value="2" onclick="elabel('+eid+', 2)">&#x9519;&#x8BEF;</li>';
		bPass = answer && answer == result;
	}
	if(type==1 || type==2){
		var arr = data.split("\n");
		var nA = 65;
		for(var k=0 in arr){
			var A = String.fromCharCode(nA++);
			datastr += '<li class="'+(type==1 ? 'check' : 'option')+(answer.indexOf(A)==-1?"_off":"_on")+'" value="'+A+'" onclick="elabel('+eid+',\''+A+'\')">' + A +'. '+ arr[k] + '</li>';
		}
		bPass = answer && answer == result;
	}
	else if(type==4 ){
		var arr1 = answer.split(",");
		var arr2 = result.split("|");
		if(arr1.sort().toString() == arr2.sort().toString()){
			bPass = answer = 1;
		}
	}
	else if( type==5){
		datastr += '<textarea rows="3" onchange="echange(this,'+eid+',1);" cols="20">'+answer+'</textarea>';
		
		bPass = answer = 1;
	}

	$('p_data').innerHTML  = datastr;

	<!--{if $needPractise}-->
	$('btnnav').innerHTML  = '<cite onclick="practise('+eid+');" style="margin-left:-3px;border-radius: 30px;">&#x67E5;&#x770B;&#x7B54;&#x6848;</cite>';
	<!--{/if}-->

	if($('p_msg').style.display=='block'){
		$('p_icon').className = bPass? 'icon_right' : 'icon_wrong';
		$('p_result').innerHTML = '&#x53C2;&#x8003;&#x7B54;&#x6848;: '+ (type==3?(result==1?'&#x6B63;&#x786E;':'&#x9519;&#x8BEF;'): result);					
	if(note!='')$('p_note').innerHTML = '&#x672C;&#x9898;&#x89E3;&#x91CA;:<br>'+note;
		
	if(parserimage!="")
		$('p_note_image').innerHTML = '<img src="'+parserimage+'" border=0>';
	else
		$('p_note_image').innerHTML = '';
	}
}


function closeWindow(obj)
{
	$('submitbox').style.display='none';
	
}
