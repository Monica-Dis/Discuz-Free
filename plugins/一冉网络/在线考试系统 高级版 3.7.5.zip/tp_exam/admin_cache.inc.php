<?php


if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

showtips(lang('plugin/tp_exam', 'admin_cache_update'));

$sql ="ALTER TABLE ".DB::table('tpexam_tiku_danxuan')." ADD `peiwu`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_tiku_duoxuan')." ADD `peiwu`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_paper')." ADD `usescorescheme`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_verify_data')." ADD `uniquecode` varchar(256) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql = "CREATE TABLE IF NOT EXISTS ".DB::table('tpexam_examscore')." (
  `id` int(11) NOT NULL auto_increment,
  `schemename` varchar(256) NOT NULL,
  `right1` double NOT NULL,
  `right2` double NOT NULL,
  `right3` double NOT NULL,
  `right4` double NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM " ;

if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_examscore')." ADD `right1` double  NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_examscore')." ADD `right2` double  NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_examscore')." ADD `right3` double  NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_examscore')." ADD `right4` double  NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

//$sql ="ALTER TABLE ".DB::table('tpexam_setting')." ADD `paper_exam_time_span_msg`  varchar(256) NOT NULL" ;
//if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}
$sql ="SELECT svalue FROM ".DB::table('tpexam_setting')." WHERE skey = 'paper_exam_time_span_msg'" ;
$query = DB::query($sql,'SILENT');
if($query && !DB::fetch($query)){
	$sql ="INSERT INTO ".DB::table('tpexam_setting')." (`skey` ,`svalue` ) VALUES ('paper_exam_time_span_msg',  '');" ;
	if(DB::query($sql,'SILENT')){print('add paper_exam_time_span_msg succeed!<br>');}
}

$sql = "CREATE TABLE IF NOT EXISTS `pre_tpexam_groups` (
  `id` int(11) NOT NULL auto_increment,
  `paperid` int(11) NOT NULL,
  `subject` text NOT NULL,
  `content` int(11) NOT NULL,
  `grouprand` int(11) NOT NULL,
  `displayorder` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM " ;

if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql = "CREATE TABLE IF NOT EXISTS `pre_tpexam_knowledge` (
  `id` int(11) NOT NULL auto_increment,
  `level` int(11) NOT NULL,
  `upid` int(11) NOT NULL,
  `subid` varchar(256) NOT NULL,
  `subject` varchar(256) NOT NULL,
  `displayorder` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM ;" ;

if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="SELECT svalue FROM ".DB::table('tpexam_setting')." WHERE skey = 'opensingleexam'" ;
$query = DB::query($sql,'SILENT');
if($query && !DB::fetch($query)){
	$sql ="INSERT INTO ".DB::table('tpexam_setting')." (`skey` ,`svalue` ) VALUES ('opensingleexam',  '0');" ;
	if(DB::query($sql,'SILENT')){print('add opensingleexam succeed!<br>');}
}

$sql = "ALTER TABLE ".DB::table('tpexam_paper')." ADD `usesysprofile` int(11)  NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="SELECT svalue FROM ".DB::table('tpexam_setting')." WHERE skey = 'questionimg'" ;
$query = DB::query($sql,'SILENT');
if($query && !DB::fetch($query)){
	$sql ="INSERT INTO ".DB::table('tpexam_setting')." (`skey` ,`svalue` ) VALUES ('questionimg',  '0');" ;
	if(DB::query($sql,'SILENT')){print('add questionimg succeed!<br>');}
}

$sql = "ALTER TABLE ".DB::table('pre_tpexam_verify_data')." ADD `identifycode` varchar(512)  NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_tiku_danxuan')." ADD `groupid`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_tiku_duoxuan')." ADD `groupid`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_tiku_panduan')." ADD `groupid`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_tiku_tiankong')." ADD `groupid`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_tiku_wenda')." ADD `groupid`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_tiku')." ADD `groupid`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_tiku')." ADD `viewParser_credits`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_tiku')." ADD `yuedulijie`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_tiku')." ADD `bindid`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_useranswer')." ADD `serializedata` text  NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_paper')." ADD `paperdata` int(11)  NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_setting')." ADD `usegroups` int(11)  NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="SELECT svalue FROM ".DB::table('tpexam_setting')." WHERE skey = 'usegroups'" ;
$query = DB::query($sql,'SILENT');
if($query && !DB::fetch($query)){
	$sql ="INSERT INTO ".DB::table('tpexam_setting')." (`skey` ,`svalue` ) VALUES ('usegroups',  '0');" ;
	if(DB::query($sql,'SILENT')){print('add usegroups succeed!<br>');}
}

$sql ="ALTER TABLE ".DB::table('tpexam_useranswer')." ADD `source` int(11)  NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add bus_routes succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_buy')." ADD `finish`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add finish succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_useranswer')." ADD `wendauserimage`  varchar(256) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add wendauserimage succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_buy')." ADD `orderid`  varchar(256) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add wendauserimage succeed!<br>');}

$sql ="ALTER TABLE ".DB::table('tpexam_tiku_errorbook')." ADD `tikuid`  int(11) NOT NULL" ;
if(DB::query($sql,'SILENT')){print('add tikuid succeed!<br>');}

echo '<br/>repair succeed';

?>