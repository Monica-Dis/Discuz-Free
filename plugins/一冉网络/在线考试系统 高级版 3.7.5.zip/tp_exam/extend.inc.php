<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$f=trim($_GET['f']);
if($f){
	C::import('extend/'.$f,'plugin/tp_exam',false);
	$modstr = 'extend_'.$f;
	if (class_exists($modstr,false)){
		$mobj = new $modstr();
		if(submitcheck('submit',true)&&FORMHASH==$_GET['formhash']){
			if(in_array('run',get_class_methods($mobj))){
				$mobj->run();
			}
			cpmsg(plang('setsucceed'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=dc_vip&pmod=extend', 'succeed');
		}
		
		if(in_array('setting',get_class_methods($mobj))){
			$mobj->setting();
		}
	}
	exit;
}
$entrydir = DISCUZ_ROOT.'source/plugin/tp_exam/extend/';
$extends = array();
if(file_exists($entrydir)) {
	$d = dir($entrydir);
	while($f = $d->read()) {
		if(preg_match('/^extend\_(\w+)?\.php$/', $f, $a)){
			if(!in_array($a[1],array('base'))){
				C::import('extend/'.$a[1],'plugin/tp_exam',false);
				$modstr = 'extend_'.$a[1];
				if (class_exists($modstr,false)){
					$mobj = new $modstr();
					$extends[$a[1]] = array('title'=>plang($mobj->title),'des'=>plang($mobj->des));
				}
			}
		}
	}
}
if(!$extends) cpmsg(plang('no_extends'), '', 'error');

showtableheader(plang('extend_list'));
$cv=explode(',',plang('extend_table'));
showsubtitle(array($cv[0],$cv[1],$cv[2]));

foreach($extends as $k => $v){
	showtablerow('', array('','', 'width="20%"'), array($v['title'],$v['des'], '<a href="?action=plugins&operation=config&identifier=tp_exam&pmod=extend&f='.$k.'">'.plang('extend_config').'</a>'));
}
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/

function plang($str) {
	return lang('plugin/tp_exam', $str);
}
//From: di'.'sm.t'.'aoba'.'o.com
?>