<?php
/**
 *
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


require_once libfile('function/cache');
$s_answer = $_GET['s_answer'];
$m_answer = $_GET['m_answer'];
$p_answer = $_GET['p_answer'];
$t_answer = $_GET['t_answer'];
$w_answer = $_GET['w_answer'];

$uid = intval($_GET['uid']);
$paperid = intval($_GET['paperid']);


$cachearray = array($s_answer,$m_answer,$p_answer,$t_answer,$w_answer);
$cache .= "\$draftcache=".arrayeval($cachearray).";\n";

writetocache("cache_tpexam_draft_".$paperid."_".$uid, $cache);

/*
$c = new draftcache();
$c->writedraftcache($paperid,$cache);
*/
class  draftcache{
	
	function writedraftcache($paperid,$cacheArray){
		$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_tpexam_draft_'.$paperid.'.php';
		writetocache($cache_file, $cacheArray);
	}
	
	function readdraftcache($paperid){
		$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_tpexam_draft_'.$paperid.'.php';
		if(file_exists($cache_file)){
			@include_once DISCUZ_ROOT.'./data/sysdata/cache_tpexam_draft_'.$paperid.'.php';
		}
		return $arraydraft;
	}
	

}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>