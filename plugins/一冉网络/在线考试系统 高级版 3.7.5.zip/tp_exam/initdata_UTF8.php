﻿<?php

$sql = <<<EOF

INSERT INTO `pre_tpexam_verify` (`id`, `uid`, `name`, `company`, `idcard`, `student_id`, `verify_mode`) VALUES
(1, 0, 1, 1, 0, 1, 1);

EOF;
?>