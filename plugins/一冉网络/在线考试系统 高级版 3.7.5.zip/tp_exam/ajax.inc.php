<?php


if (!defined('IN_DISCUZ')  ) {
    exit('Access Denied');
}


$formhash = daddslashes($_GET['formhash']);
$data = daddslashes($_GET['data']);
$paperid = intval($_GET['paperid']);
$mod = $_GET['mod'];
$paperid = intval($_GET['paperid']);

if(!$_G['uid']){
	exit;
}

if($mod == 'getyuedu'){
			
	$fetch = DB::fetch_all("SELECT * FROM ".DB::table('tpexam_tiku_yuedulijie')." WHERE belong_paper = '$paperid'");
	echo array2json($fetch);

}
		
if(formhash()==$formhash){
	
	if(empty($mod)){
				$paper = C::t('#tp_exam#tp_exam_paper')->get_paper_info($paperid);
				
				require_once libfile('include/paperctrl','plugin/tp_exam');
				
				if(checkPaper($paper, $_G['uid'])===true)
				{
					
					$data = explode(',', $data);
					
					$exams = DB::fetch_all("SELECT * FROM %t WHERE  id in (%n)", array('tpexam_tiku', $data), 'id');
				
					foreach($exams AS $k=>$e){
						if($e['tid']==1 || $e['tid']==2){
							$exams[$k]['data'] = '';
						}
					}
				
					echo array2json($exams);
					
					
				}
				else{
					echo 'null';
				}
			
		}
}



function array2json($arr) {
    //if(function_exists('json_encode')) return json_encode($arr); //Lastest versions of PHP already has this functionality. 
    $parts = array(); 
    $is_list = false; 

    //Find out if the given array is a numerical array 
    $keys = array_keys($arr); 
    $max_length = count($arr)-1; 
    if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {//See if the first key is 0 and last key is length - 1 
        $is_list = true; 
        for($i=0; $i<count($keys); $i++) { //See if each key correspondes to its position 
            if($i != $keys[$i]) { //A key fails at position check. 
                $is_list = false; //It is an associative array. 
                break; 
            } 
        } 
    } 

    foreach($arr as $key=>$value) { 
        if(is_array($value)) { //Custom handling for arrays 
            if($is_list) $parts[] = array2json($value); /* :RECURSION: */ 
            else $parts[] = '"' . $key . '":' . array2json($value); /* :RECURSION: */ 
        } else { 
            $str = ''; 
            if(!$is_list) $str = '"' . $key . '":'; 

            //Custom handling for multiple data types 
            if(is_numeric($value)) $str .= $value; //Numbers 
            elseif($value === false) $str .= 'false'; //The booleans 
            elseif($value === true) $str .= 'true'; 
            else $str .= '"' . addslashes($value) . '"'; //All other things 
            // :TODO: Is there any more datatype we should be in the lookout for? (Object?) 
			$str = str_replace(array("\r\n","\n"),"\\n", $str);
            $parts[] = $str; 
        } 
    } 
    $json = implode(',',$parts); 
     
    if($is_list) return '[' . $json . ']';//Return numerical JSON 
    return '{ ' . $json . ' }';//Return associative JSON 
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>