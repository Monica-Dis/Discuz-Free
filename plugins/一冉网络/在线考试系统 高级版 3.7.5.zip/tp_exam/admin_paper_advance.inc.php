<?php

 /*
 ���߿���ϵͳ  tp_exam
 */
 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam_paper_func.php";
	
if(!submitcheck('submit_submit') ) {
	
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_paper&op=advance', 'editsubmit');
	showtableheader();
	
	$admin_paper_adv_random_tip = lang('plugin/tp_exam','admin_paper_adv_random_tip');
	$admin_paper_adv_random_tip_desc = lang('plugin/tp_exam','admin_paper_adv_random_tip_desc');
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_module_item'));
	$module = array();
	while($row = DB::fetch($query))
	{
		$module[] = $row;
	}
	
	$paperid=daddslashes($_GET['id']);
	
	$query = DB::query('SELECT * FROM '.DB::table('tpexam_paper')." where id='$paperid'");
	
	while($data = DB::fetch($query))
	{
		$paper_timu_item_desc = $data['paper_timu_item_desc'];
		$paper_buy_credits = $data['needcredit']."|".$data['buycredits']."|".$data['buyonlyonce'];
	}
	
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='exam_paper_group'");
	$exam_paper_group = $skey['exam_paper_group'];
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='paper_buy_credits'");
	$paper_buy_credits_permission = $skey['paper_buy_credits'];
	
	$usesysprofile = DB::result_first("SELECT usesysprofile FROM ".DB::table('tpexam_paper')." where id='$paperid'");


	$password_permission = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='password'");

	//�û���
	$usergroup=array();
	$customgroup=array();
	$systemgroup=array();
	$elsegroup=array();
	$query = DB::query('SELECT * FROM '.DB::table('common_usergroup'));
	while($data = DB::fetch($query))
	{
		if($data['type'] == 'system')
			$systemgroup[] = $data;
		else
		if($data['type'] == 'special')
			$customgroup[] = $data;
		else
		if($data['type'] == 'member')
			$usergroup[]=$data;
		else
			$elsegroup[]=$data;
	}
	
	//��ѡ��
	$selgroup = DB::result_first("select  examgroup from ".DB::table('tpexam_paper')." where id='$paperid'");
	$selgroup=explode("|",$selgroup);

	//�������
	
	$skey = DB::result_first("SELECT random_item FROM ".DB::table('tpexam_paper')." where id='$paperid'");
	$random_arr = explode(",",$skey);
	if(count($random_arr) == 5)
	$random_item = array($random_arr[0],$random_arr[1],$random_arr[2],$random_arr[3],$random_arr[4]);
	else
	$random_item = array(-1,-1,-1,-1,-1);
	
	$exam_common_null=lang('plugin/tp_exam', 'exam_common_null');
	
	$canexamtime = GetPaperTimes($paperid);
	$usetimespan = GetPaperTimeSpan($paperid);
	
	$startexamtime = date('Y-m-d H:i:s',time());
	$endexamtime = date('Y-m-d H:i:s',time()+1000);
	$paper_exam_time_ctr = 1;
	
	$paper_exam_times_reach_msg = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='paper_exam_times_reach_msg'");
	$paper_exam_time_span_msg = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='paper_exam_time_span_msg'");
	$paper_exam_time_ctr = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='paper_exam_time_ctr'");
	$skey = DB::result_first("SELECT paper_no_pause FROM ".DB::table('tpexam_paper')." where id='$paperid'");
	$paper_no_pause = $skey;
	$paper_password = DB::result_first("SELECT password FROM ".DB::table('tpexam_paper')." where id='$paperid'");
	$paper_score = DB::result_first("SELECT paperscore FROM ".DB::table('tpexam_paper')." where id=$paperid");
	$verifylogintimes = DB::result_first("SELECT verifylogintimes FROM ".DB::table('tpexam_paper')." where id=$paperid");

	include template('tp_exam:admin_paper_advance');
	
	showsubmit('submit', 'submit','','');
}
//From: d'.'is'.'m.tao'.'ba'.'o.com
?>