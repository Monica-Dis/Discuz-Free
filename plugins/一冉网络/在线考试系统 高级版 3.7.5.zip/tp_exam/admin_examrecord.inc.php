<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


$orderid = trim($_G['gp_proid']);
$item = trim($_GET['del']);
$user_answer = trim($_GET['useranswer']);
$act = trim($_GET['act']);
$mod = intval($_GET['mod']);
	
require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/tp_exam.func.php';

if(!submitcheck('submit') && empty($item) && empty($user_answer) && !submitcheck('additionsubmit')) {
	$pmod='admin_examrecord';
	
	$admin_exam_record_tips = lang('plugin/tp_exam', 'admin_exam_record_tips');
	$admin_exam_record_company = lang('plugin/tp_exam', 'admin_exam_record_company');
	$admin_exam_record_name = lang('plugin/tp_exam', 'admin_exam_record_name');
	$admin_exam_record_paper = lang('plugin/tp_exam', 'admin_exam_record_paper');
	$admin_exam_record_usetime = lang('plugin/tp_exam', 'admin_exam_record_usetime');
	$admin_exam_record_timedata = lang('plugin/tp_exam', 'admin_exam_record_timedata');
	$admin_exam_record_score = lang('plugin/tp_exam', 'admin_exam_record_score');
	$admin_record_export = lang('plugin/tp_exam', 'admin_record_export');
	$admin_user_answer = lang('plugin/tp_exam', 'admin_user_answer');
	$admin_common_op = lang('plugin/tp_exam', 'admin_common_op');
	$admin_common_delete = lang('plugin/tp_exam', 'admin_common_delete');
	$admin_user_record_idcard = lang('plugin/tp_exam', 'admin_user_record_idcard');
	$admin_user_record_studentid = lang('plugin/tp_exam', 'admin_user_record_studentid');
	$exam_by_score = lang('plugin/tp_exam', 'exam_by_score');
	$exam_by_examtime = lang('plugin/tp_exam', 'exam_by_examtime');

	showtips($admin_exam_record_tips);


	$perpage = 15;
	$page = max(1, intval($_GET['page']));
	$listStart = ($page-1) *$perpage;
	$totalnum = DB::result_first("SELECT count(*) FROM ".DB::table('tpexam_examrecord'));
	$pagenum = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 
	
	$multi = multi($totalnum, $perpage, $page, ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_examrecord&app={$app}{$linkadd}");

	$where =" order by id asc limit $listStart,$perpage";
	
	
	showformheader("plugins&operation=config&do={$pluginid}&identifier=tp_tuangou&pmod=admin_recipt&app={$app}", 'order_submit');
	showtableheader();
	showtitle('Exam Number'.'&nbsp;'.$totalnum);

	showsubtitle(array('id','uid',$admin_exam_record_company,$admin_exam_record_name,$admin_user_record_idcard,$admin_user_record_studentid,$admin_exam_record_paper,$admin_exam_record_timedata,$admin_exam_record_score,$admin_user_answer,"<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_examrecord&item=all&del=all\">".$admin_common_delete."</a>"));
	
	$limit_start = $pagenum * ($page - 1);
	

		
			$query = DB::query("SELECT * FROM ".DB::table('tpexam_examrecord').$where);
			while($row = DB::fetch($query)) {
				$valarr = array();
				$valarr[] = $row['id'];
				$paperid = $row['exam_type'];
				$verifyid = $row['verifyid'];
				$username = getuserbyuid($row['uid']);
				$valarr[] = $row['uid'].'('.$username['username'].')';
				if(!$row['uid'] > 0){
					$valarr[] = GetVerifyCompanyByUnqiCode($paperid,$row['uniquecode']);
					$valarr[] = GetVerifyNameByUnqiCode($paperid,$row['uniquecode']);
					$valarr[] = GetVerifyIdcardByUnqiCode($paperid,$row['uniquecode']);
					$valarr[] = GetVerifyStudentIdByUnqiCode($paperid,$row['uniquecode']);
				}else{
					$valarr[] = GetVerifyCompany($paperid,$row['uid'],$verifyid);
					$valarr[] = GetVerifyName($paperid,$row['uid'],$verifyid);
					$valarr[] = GetVerifyIdcard($paperid,$row['uid'],$verifyid);
					$valarr[] = GetVerifyStudentId($paperid,$row['uid'],$verifyid);
				}
				$valarr[] = $row['exam_type'];
				$valarr[] = date('Y-m-d G:i:s',$row['date']);
				$valarr[] = $row['score'];
				$valarr[] = "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_examrecord&useranswer=".$row['id']."\">".$admin_user_answer."</a>";
				$valarr[] = "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_examrecord&del=".$row['id']."\">".$admin_common_delete."</a>";
				showtablerow('id="td_'.$row['id'].'"', array('class="td25"','class="td25"', 'class="td25"','class="td25"','','','',''), $valarr);
				unset($valarr);
			}

	showsubmit('', '', 'del', '', $multi);
		
	showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
	showformfooter(); /*dism��taobao��com*/	
	
	echo "<form action='plugin.php?id=tp_exam:export&mode=usereport' method='POST'>";
	echo "<input type='hidden' name='mod' class='btn' value='".$mod."' />";
	echo "<input type='submit' name='submit' class='btn' value='".$admin_record_export."' />";
	echo "</form>";
}
elseif(submitcheck('additionsubmit')){
	
	$addition = intval($_GET['addition']);
	$useranswer = intval($_GET['useranswer']);

	DB::update('tpexam_useranswer',array('addition'=>$addition),"belongrecord='$useranswer'");
	
	cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_examrecord', 'succeed');
}
else
{
			if(!empty($item))
			{
				if($item=='all'){
					DB::query("TRUNCATE TABLE " .DB::table('tpexam_examrecord'));
					DB::query("TRUNCATE TABLE " .DB::table('tpexam_useranswer'));
				}else{
					//ɾ����Ӧ�����
					DB::delete('tpexam_examrecord', "id IN($item)");
					DB::delete('tpexam_useranswer', "id IN($item)");
				}
				cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_examrecord', 'succeed');
			
			}
			else
			{
				require_once DISCUZ_ROOT."./source/plugin/tp_exam/admin_useranswer.inc.php";
			}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>