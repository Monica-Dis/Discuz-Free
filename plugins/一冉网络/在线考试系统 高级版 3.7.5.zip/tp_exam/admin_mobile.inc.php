<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


if(!submitcheck('submit')) {
	
	global $_G;
	
	echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
	
	$admin_buy_uid = lang('plugin/tp_exam', 'admin_buy_uid');
	$admin_buy_paperid = lang('plugin/tp_exam', 'admin_buy_paperid');
	$admin_buy_creditnum = lang('plugin/tp_exam', 'admin_buy_creditnum');
	$admin_buy_time = lang('plugin/tp_exam', 'admin_buy_time');
	$admin_buy_credittype = lang('plugin/tp_exam', 'admin_buy_credittype');

	$perpage = 15;
	$page = max(1, intval(daddslashes($_GET['page'])));
	$start = ($page-1)*$perpage;
	$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_mobile';

	//$query=DB::query("SELECT * FROM ".DB::table('kamigroup_key')." ORDER BY id DESC LIMIT $start,$perpage");
	$count = DB::num_rows(DB::query('SELECT id FROM '.DB::table('tpexam_buy')));
	$multipage = multi($count, $perpage, $page, $mpurl);
	
	showformheader('plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_mobile', 'order_submit');
	showtableheader();
	showsubtitle(array('',lang('plugin/tp_exam', 'admin_buy_uid'), 
	lang('plugin/tp_exam', 'admin_buy_status'), 
	lang('plugin/tp_exam', 'admin_buy_paperid'), 
	lang('plugin/tp_exam', 'admin_buy_creditnum'), 
	lang('plugin/tp_exam', 'admin_buy_time'), 
	lang('plugin/tp_exam', 'admin_buy_credittype')));

$query =  DB::query("SELECT * FROM ".DB::table('tpexam_buy')." order by id desc LIMIT $start,$perpage"); //����ID�� 
while($order = DB::fetch($query))
{
	showtablerow('', '', array("<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$order[id]\" ".('').">",
			getuidname($order['uid']),
			'OK',
			getpapername($order['paperid']),
			$order['buynum'],
			dgmdate($order['buytime']),
			$_G['setting'][extcredits][$order['creditstype']]['title']
		));
}

	showsubmit('submit', 'submit', 'del', '', $multipage);	
	showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
	showformfooter(); /*dism��taobao��com*/	

}
else{

		$admin_common_success = lang('plugin/tp_exam', 'admin_common_success');
		$newids = array();
		$delarr = daddslashes($_GET['delete']);
	
		foreach($delarr as $id=>$v)
		{
			DB::delete('tpexam_buy', "id IN($v)");
		}

		cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_mobile', 'succeed');
}

function getuidname($uid){
	$username = getuserbyuid($uid);
	return 'UID-'.$uid.'('.$username['username'].')';
}

function getpapername($paperid){
	return DB::result_first("SELECT name FROM ".DB::table('tpexam_paper')." WHERE id='$paperid'");
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>