<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class extend_backup{
	var $title='[dxtm]tp_exam&#25968;&#25454;&#22791;&#20221;&#47;&#36824;&#21407;';
	var $des='&#22791;&#20221;&#47;&#36824;&#21407;';
	public function run(){
		global $_G;
		$viphash = md5($_G['config']['security']['authkey'].md5_file(DISCUZ_ROOT.'./source/plugin/tp_exam/template/list.htm'));
		if(!$_GET['import']){
			if(preg_match('/[^A-Za-z0-9_]/', $_GET['filename'])) cpmsg('&#25991;&#20214;&#21517;&#31216;&#21547;&#26377;&#38750;&#27861;&#23383;&#31526;&#65281;');
			$file = DISCUZ_ROOT."./data/tpexam_backup/{$_GET[filename]}.bak";
			@touch($file);
			if(!is_writeable($file)) cpmsg('&#25991;&#20214;&#19981;&#21487;&#20889;&#65292;&#35831;&#26816;&#26597;&#30446;&#24405;&#26435;&#38480;');
			
			$out_arr = array(	'examrecord'=>array(),
			'permission'=>array(),
			'type'=>array(),
			'paper'=>array(),
			'tiki'=>array(),
			'danxuan' => array(),
			'duoxuan' => array(),
			'panduan' => array(),
			'tiankong' => array(),
			'wenda' => array(),
			'yuedu'=>array(),
			'peiwu'=>array(),
			 'main' => array());
			
			$out_arr['examrecord'] = DB::fetch_all('SELECT * FROM '.DB::table('tpexam_examrecord'));
			$out_arr['permission'] = DB::fetch_all('SELECT * FROM '.DB::table('tpexam_permission'));
			$out_arr['type'] = DB::fetch_all('SELECT * FROM '.DB::table('tpexam_type'));
			$out_arr['paper'] = DB::fetch_all('SELECT * FROM '.DB::table('tpexam_paper'));
			$out_arr['tiku'] = DB::fetch_all('SELECT * FROM '.DB::table('tpexam_tiku'));
			$out_arr['danxuan'] = DB::fetch_all('SELECT * FROM '.DB::table('tpexam_tiku_danxuan'));
			$out_arr['duoxuan'] = DB::fetch_all('SELECT * FROM '.DB::table('tpexam_tiku_duoxuan'));
			$out_arr['panduan'] = DB::fetch_all('SELECT * FROM '.DB::table('tpexam_tiku_panduan'));
			$out_arr['tiankong'] = DB::fetch_all('SELECT * FROM '.DB::table('tpexam_tiku_tiankong'));
			$out_arr['wenda'] = DB::fetch_all('SELECT * FROM '.DB::table('tpexam_tiku_wenda'));
			$out_arr['yuedu'] = DB::fetch_all('SELECT * FROM '.DB::table('tpexam_tiku_yuedulijie'));
			$out_arr['peiwu'] = DB::fetch_all('SELECT * FROM '.DB::table('tpexam_tiku_peiwu'));

			$output = serialize($out_arr);
			file_put_contents($file, $output);
			cpmsg('&#22791;&#20221;&#25104;&#21151;&#65281;', 'action=plugins&operation=config&identifier=tp_exam&pmod=extend&f=backup', 'succeed');
			dexit();
		}else{
			$file = DISCUZ_ROOT.'./data/tpexam_backup/'.$_GET['import'].'.bak';
			if(!file_exists($file)) cpmsg('&#22791;&#20221;&#25991;&#20214;&#19981;&#23384;&#22312;&#65281;');
			
			$data_str = file_get_contents($file);
			$data = unserialize($data_str);
			$main = $data['main'];
			
			$examrecord = $data['examrecord'];
			$permission = $data['permission'];
			$type = $data['type'];
			$paper = $data['paper'];
			$tiku = $data['tiku'];
			$danxuan = $data['danxuan'];
			$duoxuan = $data['duoxuan'];
			$panduan = $data['panduan'];
			$tiankong = $data['tiankong'];
			$wenda = $data['wenda'];
			$yuedu = $data['yuedu'];
			$peiwu = $data['peiwu'];
			
			C::t('#tp_exam#tp_exam_examrecord')->truncate();
			C::t('#tp_exam#tp_exam_permission')->truncate();
			C::t('#tp_exam#tp_exam_type')->truncate();
			C::t('#tp_exam#tp_exam_paper')->truncate();
			C::t('#tp_exam#tp_exam_tiku')->truncate();
			C::t('#tp_exam#tp_exam_danxuan')->truncate();
			C::t('#tp_exam#tp_exam_duoxuan')->truncate();
			C::t('#tp_exam#tp_exam_panduan')->truncate();
			C::t('#tp_exam#tp_exam_tiankong')->truncate();
			C::t('#tp_exam#tp_exam_wenda')->truncate();
			C::t('#tp_exam#tp_exam_yuedu')->truncate();
			C::t('#tp_exam#tp_exam_peiwu')->truncate();
			
			foreach ($examrecord as $g){
				C::t('#tp_exam#tp_exam_examrecord')->insert($g);
			}
			foreach ($permission as $g){
				C::t('#tp_exam#tp_exam_permission')->insert($g);
			}
			foreach ($type as $g){
				C::t('#tp_exam#tp_exam_type')->insert($g);
			}
			foreach ($paper as $g){
				C::t('#tp_exam#tp_exam_paper')->insert($g);
			}
			foreach ($tiku as $g){
				C::t('#tp_exam#tp_exam_tiku')->insert($g);
			}
			foreach ($danxuan as $g){
				C::t('#tp_exam#tp_exam_danxuan')->insert($g);
			}
			foreach ($duoxuan as $g){
				C::t('#tp_exam#tp_exam_duoxuan')->insert($g);
			}
			foreach ($panduan as $g){
				C::t('#tp_exam#tp_exam_panduan')->insert($g);
			}
			foreach ($tiankong as $g){
				C::t('#tp_exam#tp_exam_tiankong')->insert($g);
			}
			foreach ($wenda as $g){
				C::t('#tp_exam#tp_exam_wenda')->insert($g);
			}
			foreach ($yuedu as $g){
				C::t('#tp_exam#tp_exam_yuedu')->insert($g);
			}
			foreach ($peiwu as $g){
				C::t('#tp_exam#tp_exam_peiwu')->insert($g);
			}
			cpmsg('&#36824;&#21407;&#25104;&#21151;&#65281;', 'action=plugins&operation=config&identifier=tp_exam&pmod=extend&f=backup', 'succeed');
			dexit();
			
			
			
		}
	}
	public function setting(){
		showtableheader('&#x8003;&#x8BD5;&#x7CFB;&#x7EDF;&#x6570;&#x636E;&#x5907;&#x4EFD;');
		showformheader('plugins&operation=config&identifier=tp_exam&pmod=extend&f=backup');
		showsetting('&#22791;&#20221;&#25991;&#20214;&#21517;&#31216;', 'filename', random(10), 'text', '', '', '&#20648;&#23384;&#22312; /data/tpexam_backup/ &#19979;&#30340;&#25991;&#20214;&#21517;');
		showsubmit('submit', '&#24320;&#22987;&#22791;&#20221;');
		showformfooter(); /*dism��taobao��com*/
		showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
		showtableheader('&#x8003;&#x8BD5;&#x7CFB;&#x7EDF;&#x6570;&#x636E;&#x8FD8;&#x539F;');
		if(!is_dir(DISCUZ_ROOT.'./data/tpexam_backup/')) {
			@mkdir(DISCUZ_ROOT.'./data/tpexam_backup/', 0777);
			@touch(DISCUZ_ROOT."./data/tpexam_backup/index.htm");
		}
		$backup_dir = @dir(DISCUZ_ROOT.'./data/tpexam_backup/');
		while(false !== ($entry = $backup_dir->read())) {
			$file = pathinfo($entry);
			if($file['extension'] == 'bak' && $file['basename']) {
				showtablerow('', '', array(
					'&#22791;&#20221;: '.$file['filename'],
					dgmdate(filemtime(DISCUZ_ROOT.'./data/tpexam_backup/'.$file['basename']), 'u'),
					'<a href="?action=plugins&operation=config&identifier=tp_exam&pmod=extend&f=backup&submit=yes&import='.$file['filename'].'&formhash='.FORMHASH.'">&#24320;&#22987;&#36824;&#21407;</a>',
				));
				$flag = true;
			}
		}
		if(!$flag) showtablerow('', '', array('<font color="red">&#26408;&#26377;&#22791;&#20221;&#20063;~</font>'));
		showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
		}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>